Entrées par matériau (même logique que Interface-QE_v1/inputs)
================================================================

Placez chaque matériau dans un sous-dossier, par exemple :

  inputs/
    Si/
      si_scf.in          ← diamant (primitive, 2 atomes) — SCF exemple
    ZnO/
      zno_scf.in

L’interface THERMO_PW liste ces dossiers et propose les fichiers .in
(le fichier par défaut privilégie *scf*, *relax*, *vc-relax* dans le nom).

Si un dossier existe déjà sous thermo_pw/inputs, la même entrée provenant
de l’interface principale n’est pas dupliquée dans le menu.

Chemins portables (nouveau PC / autre utilisateur)
--------------------------------------------------
Les gabarits sous inpsuts/*/ utilisent des chemins relatifs au dépôt thermo_pw
(ex. pseudo_dir = ./pseudos/PBE/). En enregistrant depuis l’interface, les
chemins absolus corrects sont réécrits selon backend/config.py.

Variables d’environnement utiles : voir env/portable_paths.example.sh
(copie en env/local.sh ; chargée par ./DEMARRER.sh).

Dépannage workflow EOS (pw.x code retour 1)
--------------------------------------------
- Vérifiez que pseudo_dir et le pseudo .UPF (ex. Si.pbe-n-kjpaw) existent ; adaptez
  pseudo_dir dans le .in si besoin.
- outdir = ./out/ (exemple) est créé dans le dossier du calcul.
- Sachez lancer en séquentiel : 1 seul cœur MPI (dans l’interface, « MPI par pw.x »
  = 1) si mpirun -np 4 échoue (pas de OpenMPI, ou sur-abonnement des slots).
- Le message d’erreur côté interface ou dans thermo_pw/work/.../1_eos_volumes/ inclut
  la fin du journal scf_vol_XX.out (cause réelle d’échec de Quantum ESPRESSO).

Export ESPEI / CALPHAD (option P2 — post-traitement)
-----------------------------------------------------
thermo_pw ne lance PAS ESPEI ni pyCalphad automatiquement. L’option P2 « Export
ESPEI + diagramme thermo » écrit seulement des fichiers JSON + un graphique PNG
dans :

  work/<Matériau>/pipeline_P2_.../calphad_espei/
    datasets/*.json       — CPM_FORM, SM_FORM, HM_FORM (QHA DFT)
    plots/phase_thermo_overview.png — diagramme Cp/S/H vs T (section ④ UI)
    manifest.json         — résumé
    espei_in_stub.yaml    — gabarit ESPEI à compléter
    README.txt

Un run P2 = une phase. Un diagramme de phases complet demande plusieurs runs
(phases / compositions) fusionnés dans datasets/.

Comment activer calphad_espei (utilisateur interface)
  A) Nouveau calcul P2
     1. Calculs → profil P2 → cocher « Export ESPEI + diagramme thermo »
     2. Lancer la série → à la fin : calphad_espei/ + tuile graphique en ④

  B) P2 déjà terminé (ex. Si) — NE PAS relancer toute la chaîne
     1. Section ④ → Charger le calcul P2
     2. Terminal :
        python3 scripts/dev/run_espei_export.py <job_id>
        # ou après redémarrage ./DEMARRER.sh :
        curl -X POST http://127.0.0.1:8000/api/pipeline/runs/<job_id>/espei_export
     3. Recharger le job en ④ → diagramme « mono-phase CALPHAD »

Installation ESPEI + pyCalphad (machine CALPHAD, optionnelle)
  Sur ce dépôt (une fois) :
    bash scripts/dev/setup_calphad_venv.sh
    source venv_calphad/bin/activate

  Sur un autre PC (même principe) :
    python3 -m venv ~/venvs/calphad
    source ~/venvs/calphad/bin/activate
    pip install -r backend/requirements-calphad.txt

  Vérifier les jeux exportés :
    cd work/Si/pipeline_P2_.../calphad_espei
    espei --check-datasets datasets/

  Suite (hors thermo_pw) : compléter espei_in_stub.yaml, lancer ESPEI → .tdb,
  puis tracer avec pyCalphad (binplot / equilibrium).

  Opt-in P2 : diagramme thermo mono-phase (Cp/S/H vs T) dans l’UI
  (plots.phase_thermo_overview) — post-traitement rapide (~secondes, ~100 Ko).

  Export manuel depuis l’API (run P2 déjà terminé) :
    POST /api/pipeline/runs/<job_id>/espei_export
    (alias : POST /api/pipeline/jobs/<job_id>/espei_export)

  Si l’API répond {"error":"not found"} : redémarrer le serveur
  (./DEMARRER.sh) pour charger la nouvelle route, ou sans API :
    python3 scripts/dev/run_espei_export.py <job_id>

Copier calphad_espei/ sur une autre machine suffit pour la partie CALPHAD ; le
calcul DFT (QE + thermo_pw) reste sur la machine de calcul.

"""Tests d'intégration PipelineJob ↔ extras P5 (juin 2026).

Couvre :
  * ``PipelineJob.__init__`` : ``extra_whats`` filtrés par le catalogue.
  * ``PipelineJob.to_dict()`` : expose ``extra_whats``, ``extras_catalog``,
    ``default_extra_whats``.
  * ``PipelineJob.from_dict()`` : réhydrate ``extra_whats`` depuis le marker
    disque (reprise après redémarrage).
  * ``from_dict`` filtre les what= hors-catalogue (robustesse si la whitelist
    évolue entre deux versions de l'API).

Note : ces tests NE lancent AUCUN calcul MPI. On vérifie uniquement la
plomberie d'orchestration (sérialisation, hydratation, validation).
"""
from __future__ import annotations

import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_BACKEND = os.path.dirname(_HERE)
if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)

import pytest

import pipeline
from pipeline import PipelineJob


# stub profile_id/path pour éviter d'écrire dans le WORK_ROOT
MATERIAL = "Si"  # doit exister dans inputs/<mat>/ quelque part (on ne lance rien)


@pytest.fixture
def scf_basename():
    return "si_scf.in"


def test_pipeline_job_default_extra_whats_p5(scf_basename):
    """P5 + extra_whats=None ⇒ applique default_extra_whats (plot_bz)."""
    job = PipelineJob(
        material_id=MATERIAL,
        profile_id="P5",
        scf_in_basename=scf_basename,
        nproc=1,
        extra_whats=None,
    )
    assert job.extra_whats == ["plot_bz"]


def test_pipeline_job_extra_whats_filtered(scf_basename):
    """``extra_whats`` avec entrée hors-catalogue → silencieusement filtrée."""
    job = PipelineJob(
        material_id=MATERIAL,
        profile_id="P5",
        scf_in_basename=scf_basename,
        nproc=1,
        extra_whats=["plot_bz", "totally_bogus", "magnetic_susceptibility"],
    )
    assert job.extra_whats == ["plot_bz", "magnetic_susceptibility"]


def test_pipeline_job_non_p5_ignores_default(scf_basename):
    """P2 (skip_thermo_pw=False) ne tire PAS les default_extra_whats de P5."""
    job = PipelineJob(
        material_id=MATERIAL,
        profile_id="P2",
        scf_in_basename=scf_basename,
        nproc=1,
    )
    assert job.extra_whats == []


def test_to_dict_exposes_extras_catalog_and_defaults(scf_basename):
    job = PipelineJob(
        material_id=MATERIAL,
        profile_id="P5",
        scf_in_basename=scf_basename,
        nproc=1,
        extra_whats=["plot_bz", "scf_dielectric"],
    )
    d = job.to_dict()
    # scf_dielectric retiré du catalogue (ε∞ = ph.out) — filtré à l'init.
    assert d["extra_whats"] == ["plot_bz"]
    assert d["default_extra_whats"] == ["plot_bz"]
    assert isinstance(d["extras_catalog"], list)
    catalog_whats = {entry["what"] for entry in d["extras_catalog"]}
    assert catalog_whats == set(pipeline.PROFILES["P5"]["allowed_extra_whats"])
    # Chaque entrée du catalogue porte les champs attendus par l'UI.
    for entry in d["extras_catalog"]:
        assert {"label", "tooltip", "group"} <= set(entry.keys())


def test_from_dict_rehydrates_and_filters(scf_basename):
    """from_dict : la liste disque est re-normalisée via le catalogue."""
    job = PipelineJob(
        material_id=MATERIAL,
        profile_id="P5",
        scf_in_basename=scf_basename,
        nproc=1,
        extra_whats=["plot_bz"],
    )
    d = job.to_dict()
    # On injecte une entrée hors-catalogue comme si le marker disque datait
    # d'une version antérieure où la whitelist acceptait ``mur_lc_t``.
    d["extra_whats"] = ["plot_bz", "mur_lc_t"]
    restored = PipelineJob.from_dict(d)
    assert restored.extra_whats == ["plot_bz"]
    assert restored.material_id == MATERIAL
    assert restored.profile_id == "P5"


def test_normalize_orphan_running_in_memory(scf_basename):
    """Régression : job en mémoire ``running`` sans thread → ``interrupted``."""
    job = PipelineJob(
        material_id=MATERIAL,
        profile_id="P5",
        scf_in_basename=scf_basename,
        nproc=1,
    )
    job.results = {"dielectric": {"epsilon_xx": 13.0}}
    job.status = "running"
    job._thread = None
    assert job._normalize_orphan_running_status() is True
    assert job.status == "interrupted"
    assert "Reprendre thermo_pw" in (job.message or "")


def test_normalize_orphan_skips_live_thread(scf_basename):
    """Un thread vivant ne doit pas être converti en ``interrupted``."""
    import threading

    job = PipelineJob(
        material_id=MATERIAL,
        profile_id="P5",
        scf_in_basename=scf_basename,
        nproc=1,
    )
    job.status = "running"
    job._thread = threading.Thread(target=lambda: None, daemon=True)
    job._thread.start()
    job._thread.join(timeout=2.0)
    # Thread terminé mais objet encore présent : orphelin → interrupted.
    assert job._normalize_orphan_running_status() is True
    assert job.status == "interrupted"


def test_from_dict_running_orphan_p5_has_results_before_message(scf_basename):
    """Régression : from_dict ne doit pas lire ``results`` avant initialisation."""
    job = PipelineJob(
        material_id=MATERIAL,
        profile_id="P5",
        scf_in_basename=scf_basename,
        nproc=1,
    )
    job.results = {"dielectric": {"epsilon_xx": 13.0}}
    d = job.to_dict()
    d["status"] = "running"
    restored = PipelineJob.from_dict(d)
    assert restored.status == "interrupted"
    assert restored.results.get("dielectric", {}).get("epsilon_xx") == 13.0
    assert "ph.out" in (restored.message or "")


def test_profile_p5_metadata_complete():
    """PROFILES['P5'] expose default_extra_whats + allowed_extra_whats."""
    p5 = pipeline.PROFILES["P5"]
    assert isinstance(p5.get("default_extra_whats"), list)
    assert "plot_bz" in p5["default_extra_whats"]
    assert isinstance(p5.get("allowed_extra_whats"), list)
    # Au moins 5 whitelisted (la doc thermo_pw ug.1.5.0 documente ces 5).
    assert len(p5["allowed_extra_whats"]) >= 5

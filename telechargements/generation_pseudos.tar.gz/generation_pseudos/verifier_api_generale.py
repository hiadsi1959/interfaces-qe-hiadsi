#!/usr/bin/env python3
"""Wrapper — voir tests/verifier_api_generale.py"""
import runpy
from pathlib import Path
runpy.run_path(str(Path(__file__).resolve().parent / "tests" / "verifier_api_generale.py"), run_name="__main__")

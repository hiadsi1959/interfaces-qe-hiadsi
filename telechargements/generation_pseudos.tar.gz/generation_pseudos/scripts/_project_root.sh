# shellcheck shell=bash
# Racine du projet (parent du dossier scripts/) — à sourcer depuis scripts/*.sh
if [ -z "${GEN_PSEUDOS_ROOT:-}" ]; then
    _gp_here="${BASH_SOURCE[1]:-${BASH_SOURCE[0]}}"
    GEN_PSEUDOS_ROOT="$(cd "$(dirname "$_gp_here")/.." && pwd)"
fi
HERE="${GEN_PSEUDOS_ROOT}"
BASE_DIR="${GEN_PSEUDOS_ROOT}"
SCRIPT_DIR="${GEN_PSEUDOS_ROOT}"
ROOT="${GEN_PSEUDOS_ROOT}"

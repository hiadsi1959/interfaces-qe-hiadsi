#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
#  TRANSFERER_VERS_AUTRE_PC.sh — Archive tar + envoi réseau + installation distante
# ═══════════════════════════════════════════════════════════════════════════════
#
#  Étapes automatiques :
#    1. tar czf → dist/generation_pseudos_YYYYMMDD.tar.gz
#    2. scp vers user@hôte:~/  (ou copie vers un dossier local / clé USB)
#    3. (optionnel) ssh : extraction + DEPLOYER_AUTRE_PC.sh + rappel URL
#
#  Usage :
#    ./TRANSFERER_VERS_AUTRE_PC.sh
#    ./TRANSFERER_VERS_AUTRE_PC.sh --leger --dest user@192.168.1.50
#    ./TRANSFERER_VERS_AUTRE_PC.sh --dest user@pc --qe-remote ~/q-e-qe-7.5/bin
#    ./TRANSFERER_VERS_AUTRE_PC.sh --archive-only --leger
#    ./TRANSFERER_VERS_AUTRE_PC.sh --copy-to /media/usb/
#
#  Options :
#    --leger              Archive sans pseudos/ ni third_party/
#    --dest USER@HOST     Destination scp + ssh (réseau)
#    --copy-to CHEMIN     Copie l’archive vers un dossier (USB, autre disque)
#    --remote-dir DIR     Répertoire distant (défaut : ~)
#    --qe-remote CHEMIN   Lance DEPLOYER sur le PC distant avec ce qe_bin
#    --no-deploy          N’exécute pas DEPLOYER (seulement tar + envoi)
#    --no-extract         N’extrait pas l’archive sur le distant (scp seulement)
#    --archive-only       Crée l’archive et s’arrête
#    -y                   Sans confirmation interactive
#    -h, --help           Aide
#
# ═══════════════════════════════════════════════════════════════════════════════
set -euo pipefail

# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
cd "$HERE"

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'; RED='\033[0;31m'; NC='\033[0m'

LIGHT=0
DEST=""
COPY_TO=""
REMOTE_DIR=""
QE_REMOTE=""
NO_DEPLOY=0
NO_EXTRACT=0
ARCHIVE_ONLY=0
ASSUME_YES=0
NAME="$(basename "$HERE")"

usage() {
    sed -n '6,28p' "$0" | sed 's/^# //'
    exit 0
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --leger|--light|--sans-pseudos) LIGHT=1; shift ;;
        --dest) DEST="${2:-}"; shift 2 ;;
        --copy-to) COPY_TO="${2:-}"; shift 2 ;;
        --remote-dir) REMOTE_DIR="${2:-}"; shift 2 ;;
        --qe-remote) QE_REMOTE="${2:-}"; shift 2 ;;
        --no-deploy) NO_DEPLOY=1; shift ;;
        --no-extract) NO_EXTRACT=1; shift ;;
        --archive-only) ARCHIVE_ONLY=1; shift ;;
        -y|--yes) ASSUME_YES=1; shift ;;
        -h|--help) usage ;;
        *) echo -e "${RED}Option inconnue : $1${NC}" >&2; usage ;;
    esac
done

# ── 1. Archive tar ───────────────────────────────────────────────────────────
echo -e "${CYAN}══ Étape 1/3 — Archive tar ══${NC}"
TAR_ARGS=(--print-path --quiet)
if [ "$LIGHT" = 1 ]; then
    TAR_ARGS+=(--leger)
else
    TAR_ARGS+=(--complet)
fi

ARCHIVE="$("$HERE/scripts/emballer.sh" "${TAR_ARGS[@]}")"
ARCHIVE_NAME="$(basename "$ARCHIVE")"

if [ ! -f "$ARCHIVE" ]; then
    echo -e "${RED}❌ Archive absente : $ARCHIVE${NC}" >&2
    exit 1
fi
ls -lh "$ARCHIVE"
echo -e "${GREEN}✅ Archive : $ARCHIVE${NC}"
echo ""

if [ "$ARCHIVE_ONLY" = 1 ]; then
    echo "Mode --archive-only : terminé."
    exit 0
fi

# ── Destination interactive si non fournie ─────────────────────────────────────
if [ -z "$DEST" ] && [ -z "$COPY_TO" ]; then
    echo -e "${CYAN}Destination du transfert :${NC}"
    echo "  1) Réseau (scp + ssh) — user@adresse_ip"
    echo "  2) Dossier local / clé USB — chemin absolu"
    echo "  3) Arrêter (archive déjà dans dist/)"
    read -rp "Choix [1/2/3] : " _choix
    case "${_choix:-3}" in
        1)
            read -rp "Utilisateur@hôte (ex. prof@192.168.1.50) : " DEST
            ;;
        2)
            read -rp "Chemin (ex. /media/usb ou ~/Bureau) : " COPY_TO
            COPY_TO="${COPY_TO/#\~/$HOME}"
            ;;
        *)
            echo -e "${YELLOW}Archive laissée dans dist/. Copiez-la manuellement.${NC}"
            echo "  docs/TRANSFERT_AUTRE_PC.md"
            exit 0
            ;;
    esac
    echo ""
fi

# ── 2A. Copie locale (USB) ───────────────────────────────────────────────────
if [ -n "$COPY_TO" ]; then
    echo -e "${CYAN}══ Étape 2/3 — Copie vers $COPY_TO ══${NC}"
    if [ ! -d "$COPY_TO" ]; then
        echo -e "${RED}❌ Dossier inexistant : $COPY_TO${NC}" >&2
        exit 1
    fi
    cp -f "$ARCHIVE" "$COPY_TO/"
    echo -e "${GREEN}✅ Copié : $COPY_TO/$ARCHIVE_NAME${NC}"
    echo ""
    echo "Sur l’autre PC :"
    echo "  tar xzf ~/$ARCHIVE_NAME"
    echo "  cd ~/$NAME && ./configure.sh && ./DEMARRER.sh"
    exit 0
fi

# ── 2B. Transfert réseau scp ─────────────────────────────────────────────────
if [ -z "$DEST" ]; then
    echo -e "${YELLOW}Aucune destination — archive dans dist/ uniquement.${NC}"
    exit 0
fi

RDIR="${REMOTE_DIR:-~}"
echo -e "${CYAN}══ Étape 2/3 — Envoi scp vers ${DEST}:${RDIR} ══${NC}"

if [ "$ASSUME_YES" != 1 ]; then
    read -rp "Confirmer l’envoi de $(du -h "$ARCHIVE" | cut -f1) vers ${DEST} ? [o/N] " _ok
    case "${_ok:-n}" in
        o|O|y|Y) ;;
        *) echo "Annulé."; exit 0 ;;
    esac
fi

if ! command -v scp >/dev/null 2>&1; then
    echo -e "${RED}❌ scp introuvable${NC}" >&2
    exit 1
fi

scp "$ARCHIVE" "${DEST}:${RDIR}/"
echo -e "${GREEN}✅ Fichier envoyé : ${RDIR}/${ARCHIVE_NAME}${NC}"
echo ""

if [ "$NO_EXTRACT" = 1 ]; then
    echo "Mode --no-extract : arrêt après scp."
    exit 0
fi

# ── 3. Installation distante ─────────────────────────────────────────────────
echo -e "${CYAN}══ Étape 3/3 — Extraction (et déploiement) sur le PC distant ══${NC}"

if [ "$ASSUME_YES" != 1 ] && [ "$NO_DEPLOY" = 0 ]; then
    read -rp "Extraire et configurer sur ${DEST} ? [o/N] " _ok2
    case "${_ok2:-n}" in
        o|O|y|Y) ;;
        *) NO_DEPLOY=1 ;;
    esac
fi

REMOTE_QE="${QE_REMOTE:-}"
if [ "$NO_DEPLOY" = 0 ] && [ -z "$REMOTE_QE" ]; then
    echo -e "${YELLOW}Chemin QE sur le PC distant (Entrée = détection auto) :${NC}"
    read -rp "  --qe " REMOTE_QE
fi

# Script exécuté à distance (variables injectées)
REMOTE_SCRIPT=$(cat <<EOS
set -e
cd ${RDIR}
echo "── Extraction ${ARCHIVE_NAME} ──"
tar xzf ${ARCHIVE_NAME}
cd ${NAME}
chmod +x DEMARRER.sh configure.sh GenerationPseudos ARRETER.sh 2>/dev/null || true
EOS
)

if [ "$NO_DEPLOY" = 1 ]; then
    REMOTE_SCRIPT+=$(printf '\n%s' "echo 'Extraction OK — lancez : cd ~/${NAME} && ./configure.sh && ./DEMARRER.sh'")
else
    DEPLOY_CMD="./configure.sh -y && ./DEMARRER.sh"
    if [ -n "$REMOTE_QE" ]; then
        DEPLOY_CMD="./configure.sh --qe ${REMOTE_QE} -y && ./DEMARRER.sh"
    fi
    REMOTE_SCRIPT+=$(printf '\n%s' "echo '── Configuration + démarrage ──'")
    REMOTE_SCRIPT+=$(printf '\n%s' "$DEPLOY_CMD")
fi

REMOTE_SCRIPT+=$(printf '\n%s' "echo ''")
REMOTE_SCRIPT+=$(printf '\n%s' "echo 'Interface : http://127.0.0.1:5008/'")

if ! command -v ssh >/dev/null 2>&1; then
    echo -e "${YELLOW}⚠ ssh absent — commandes manuelles sur le PC distant :${NC}"
    echo "  cd ${RDIR} && tar xzf ${ARCHIVE_NAME} && cd ${NAME} && ./configure.sh && ./DEMARRER.sh"
    exit 0
fi

echo -e "${CYAN}Connexion ssh ${DEST}…${NC}"
if ssh -o BatchMode=yes -o ConnectTimeout=8 "$DEST" "echo ok" >/dev/null 2>&1; then
    ssh "$DEST" "bash -s" <<< "$REMOTE_SCRIPT"
    echo ""
    echo -e "${GREEN}✅ Transfert et installation distante terminés${NC}"
else
    echo -e "${YELLOW}⚠ Connexion ssh interactive (mot de passe possible)…${NC}"
    ssh "$DEST" "bash -s" <<< "$REMOTE_SCRIPT" || {
        echo -e "${RED}❌ Échec ssh. Sur le PC distant, exécutez :${NC}"
        echo "  cd ${RDIR} && tar xzf ${ARCHIVE_NAME} && cd ${NAME} && ./configure.sh --qe /chemin/qe/bin -y && ./DEMARRER.sh"
        exit 1
    }
    echo -e "${GREEN}✅ Terminé${NC}"
fi

echo ""
echo -e "Sur ${DEST} : ${CYAN}http://127.0.0.1:5008/${NC}"
echo -e "Doc : ${HERE}/docs/TRANSFERT_AUTRE_PC.md"

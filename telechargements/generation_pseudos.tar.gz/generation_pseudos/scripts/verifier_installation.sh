#!/bin/bash
# Vérifie qu’une installation (dossier ou fichier unique) est prête sur ce PC.
set -euo pipefail
# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
cd "$SCRIPT_DIR"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
fail=0
ok() { echo -e "  ${GREEN}✅${NC} $*"; }
warn() { echo -e "  ${YELLOW}⚠️${NC}  $*"; fail=1; }
bad() { echo -e "  ${RED}❌${NC} $*"; fail=1; }

echo -e "${CYAN}Vérification installation — $SCRIPT_DIR${NC}"
echo ""

# Fichiers interface
bash "$SCRIPT_DIR/scripts/verifier_chemins_ui.sh" || fail=1
echo ""

# Python / Flask
if command -v python3 >/dev/null; then
    ok "python3 $(python3 --version 2>&1 | awk '{print $2}')"
else
    bad "python3 absent"
fi
if python3 -c "import flask, flask_cors" 2>/dev/null; then
    ok "Flask + flask-cors"
else
    warn "Flask absent — lancez : ./configure.sh"
fi

# Config
CFG="$SCRIPT_DIR/api_config.json"
if [ -f "$CFG" ]; then
    ok "api_config.json présent"
    python3 - <<PY || warn "api_config.json illisible"
import json, os, sys
c = json.load(open("$CFG", encoding="utf-8"))
root = "$SCRIPT_DIR"
qe = (c.get("qe_bin") or "").strip()
if qe and not os.path.isfile(os.path.join(qe, "pw.x")):
    print(f"qe_bin invalide sur ce PC : {qe}")
    sys.exit(1)
if qe:
    print(f"QE : {qe}")
PY
else
    warn "api_config.json absent — lancez : ./configure.sh"
fi

# API en ligne ?
PORT="${GEN_PORT:-5008}"
if command -v curl >/dev/null 2>&1; then
    if curl -fsS --max-time 3 "http://127.0.0.1:${PORT}/health" >/dev/null 2>&1; then
        ok "API en ligne (port ${PORT})"
        TAG=$(curl -fsS --max-time 3 "http://127.0.0.1:${PORT}/api/pseudos/version" 2>/dev/null \
            | sed -n 's/.*"build_tag"[ ]*:[ ]*"\([^"]*\)".*/\1/p' || true)
        [ -n "$TAG" ] && ok "build_tag API : $TAG"
    else
        warn "API hors ligne (port ${PORT}) — lancez : ./DEMARRER.sh ou ./GenerationPseudos"
    fi
else
    warn "curl absent — impossible de tester l’API"
fi

# Binaires optionnels (via api_config.json)
_check_bin() {
    local label="$1" key="$2"
    local path=""
    if [ -f "$CFG" ]; then
        path=$(python3 -c "import json;print(json.load(open('$CFG')).get('$key','') or '')" 2>/dev/null || true)
    fi
    if [ -n "$path" ] && [ -x "$path" ]; then
        ok "$label → $path"
    else
        warn "$label non configuré (optionnel)"
    fi
}
[ -f "$CFG" ] && _check_bin "ONCVPSP" oncvpsp_bin
[ -f "$CFG" ] && _check_bin "APE" ape_bin
[ -f "$CFG" ] && _check_bin "ATOMPAW" atompaw_bin
if [ -f "$CFG" ]; then
    qe=$(python3 -c "import json;print(json.load(open('$CFG')).get('qe_bin','') or '')" 2>/dev/null || true)
    if [ -n "$qe" ] && [ -x "$qe/pw.x" ]; then ok "Quantum ESPRESSO → $qe"; else warn "QE non configuré (ld1.x indisponible)"; fi
fi

echo ""
if [ "$fail" -eq 0 ]; then
    echo -e "${GREEN}→ Installation OK.${NC}"
    echo "  Interface : http://127.0.0.1:${PORT}/"
    exit 0
fi
echo -e "${YELLOW}→ Corrigez les points ci-dessus : ./configure.sh puis ./DEMARRER.sh${NC}"
exit 1

#!/usr/bin/env bash
# Télécharge les bibliothèques de pseudopotentiels manquantes (SSSP, SG15, GBRV, PseudoDojo…).
set -euo pipefail

# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
cd "$HERE"

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m'

PSEUDOS_DIR="${PSEUDOS_DIR:-$HERE/pseudos}"
export PSEUDOS_DIR

echo -e "${CYAN}📥 Téléchargement des bibliothèques de pseudopotentiels${NC}"
echo -e "    Cible : ${PSEUDOS_DIR}"
echo

python3 "$HERE/tools/telecharger_bibliotheques_manquantes.py" "$@"

echo
echo -e "${GREEN}✅ Terminé.${NC}"
echo -e "   Interface : ./DEMARRER.sh → http://127.0.0.1:5008/"
echo -e "   Relancer avec --with-pslibrary pour compléter PSLibrary (lent)."

#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
#  RELANCER.sh — redémarre le générateur autonome PROPREMENT et vérifie que la
#  version servie sur le port correspond bien au code source actuel.
#
#  Utilisez ce script si vous voyez « Le serveur sur ce port est OBSOLÈTE »
#  dans l'interface, ou si POST /api/inputs/save_pseudo_generator renvoie 405.
# ─────────────────────────────────────────────────────────────────────────────
set -e
# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
cd "$HERE"

PORT="${GEN_PORT:-5008}"
URL="http://127.0.0.1:${PORT}/"

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'; RED='\033[0;31m'; NC='\033[0m'
hr() { printf '%s\n' "────────────────────────────────────────────────────────────"; }

EXPECTED_TAG=$(grep -m1 '^API_BUILD_TAG' "$HERE/api_pseudos_standalone.py" | sed -E 's/.*"([^"]+)".*/\1/')
echo -e "${CYAN}Build attendu : ${EXPECTED_TAG}${NC}"
hr

# ── 1. Identifier qui occupe 5008 ───────────────────────────────────────────
echo -e "${CYAN}[1/5] État actuel du port ${PORT}${NC}"
if command -v ss >/dev/null 2>&1; then
    ss -ltnp "( sport = :${PORT} )" 2>/dev/null | sed -n '2,$p' || true
fi
if command -v lsof >/dev/null 2>&1; then
    lsof -i :"${PORT}" 2>/dev/null | sed -n '2,$p' || true
fi

CUR_TAG=""
if command -v curl >/dev/null 2>&1; then
    CUR_TAG=$(curl -fsS --max-time 2 "http://127.0.0.1:${PORT}/api/pseudos/version" 2>/dev/null \
        | sed -n 's/.*"build_tag"[ ]*:[ ]*"\([^"]*\)".*/\1/p' || true)
fi
echo -e "    Build en mémoire : ${CUR_TAG:-(introuvable / serveur muet)}"

if [ -n "$CUR_TAG" ] && [ "$CUR_TAG" = "$EXPECTED_TAG" ]; then
    echo -e "${GREEN}    ✅ Déjà à jour — aucun redémarrage nécessaire.${NC}"
    echo -e "${GREEN}🌐${NC} Interface : ${URL}"
    exit 0
fi

hr
echo -e "${CYAN}[2/5] Tuer tous les processus liés${NC}"

# Tuer toute instance du standalone, quelle que soit la ligne de commande
pkill -TERM -f 'api_pseudos_standalone\.py'      2>/dev/null || true
sleep 0.4
pkill -KILL -f 'api_pseudos_standalone\.py'      2>/dev/null || true

# Libérer le port (peut-être occupé par autre chose qu'un standalone)
if command -v fuser >/dev/null 2>&1; then
    fuser -k -TERM "${PORT}/tcp" 2>/dev/null || true
    sleep 0.3
    fuser -k -KILL "${PORT}/tcp" 2>/dev/null || true
fi
if command -v lsof >/dev/null 2>&1; then
    PIDS=$(lsof -ti :"${PORT}" 2>/dev/null || true)
    if [ -n "$PIDS" ]; then
        echo -e "${YELLOW}   PIDs restants sur ${PORT} : ${PIDS} — SIGKILL${NC}"
        echo "$PIDS" | xargs -r kill -9 2>/dev/null || true
    fi
fi
sleep 0.5

# Confirmer
LEFT=""
if command -v lsof >/dev/null 2>&1; then
    LEFT=$(lsof -ti :"${PORT}" 2>/dev/null || true)
fi
if [ -z "$LEFT" ] && command -v ss >/dev/null 2>&1; then
    if ss -ltn "( sport = :${PORT} )" 2>/dev/null | grep -q ":${PORT}"; then
        LEFT="(port encore en LISTEN mais pas de PID identifiable)"
    fi
fi
if [ -n "$LEFT" ]; then
    echo -e "${RED}   ⚠️  Port ${PORT} encore occupé : ${LEFT}${NC}"
    echo -e "${RED}      Privilèges supérieurs probablement nécessaires :${NC}"
    echo -e "${RED}        sudo fuser -k ${PORT}/tcp${NC}"
    echo -e "${RED}        sudo lsof -i :${PORT}${NC}"
    exit 2
fi
echo -e "${GREEN}   ✅ Port ${PORT} libre.${NC}"

hr
echo -e "${CYAN}[3/5] Purger __pycache__${NC}"
rm -rf "$HERE/__pycache__" 2>/dev/null && echo -e "${GREEN}   ✅ __pycache__ supprimé${NC}" \
                                       || echo -e "   (rien à supprimer)"

hr
echo -e "${CYAN}[4/5] Redémarrer toutes les APIs (./DEMARRER.sh)${NC}"
SKIP_LEGACY_API="${SKIP_LEGACY_API:-}"
export GEN_PORT="$PORT"
bash "$HERE/DEMARRER.sh" || exit 4
# DEMARRER a déjà relancé 5008 ; on saute la double mise en route ci-dessous si OK
if curl -fsS --max-time 2 "http://127.0.0.1:${PORT}/api/pseudos/version" -o /dev/null 2>/dev/null; then
    NEW_TAG=$(curl -fsS --max-time 2 "http://127.0.0.1:${PORT}/api/pseudos/version" 2>/dev/null \
        | sed -n 's/.*"build_tag"[ ]*:[ ]*"\([^"]*\)".*/\1/p' || true)
    if [ "$NEW_TAG" = "$EXPECTED_TAG" ]; then
        echo -e "${GREEN}✅ RELANCER terminé via DEMARRER.sh${NC}"
        exit 0
    fi
fi

hr
echo -e "${CYAN}[4b/5] Démarrage direct (secours)${NC}"
PY="$(command -v python3 || command -v python)"
mkdir -p "$HERE/logs"
LOG="$HERE/logs/api_pseudos_standalone.log"
: > "$LOG"

nohup env ONCVPSP_BIN="${ONCVPSP_BIN:-}" ONCVPSP_ROOT="${ONCVPSP_ROOT:-}" \
    APE_BIN="${APE_BIN:-}" ATOMPAW_BIN="${ATOMPAW_BIN:-}" \
    "$PY" "$HERE/api_pseudos_standalone.py" --port "$PORT" > "$LOG" 2>&1 &
PID=$!
echo "$PID" > "$HERE/logs/api_pseudos_standalone.pid"
echo -e "    PID ${PID}    log ${LOG}"

for i in $(seq 1 50); do
    sleep 0.2
    if command -v curl >/dev/null 2>&1; then
        if curl -fsS "http://127.0.0.1:${PORT}/api/pseudos/version" -o /dev/null 2>/dev/null; then
            break
        fi
    fi
    if ! kill -0 "$PID" 2>/dev/null; then
        echo -e "${RED}❌ Le serveur s'est arrêté immédiatement — log :${NC}"
        tail -n 40 "$LOG"
        exit 3
    fi
done

hr
echo -e "${CYAN}[5/5] Vérifier que la nouvelle version est servie${NC}"
NEW_TAG=$(curl -fsS --max-time 2 "http://127.0.0.1:${PORT}/api/pseudos/version" 2>/dev/null \
    | sed -n 's/.*"build_tag"[ ]*:[ ]*"\([^"]*\)".*/\1/p' || true)
echo -e "    Build servi   : ${NEW_TAG:-(vide)}"
echo -e "    Build attendu : ${EXPECTED_TAG}"

# Probe explicite POST sur les deux routes critiques
PROBE_BODY='{"generator":"atompaw","element":"Cu","xc":"gga_pbe","pp_type":"vanderbilt","content":"Cu 29\nGGA-PBE\nProbe RELANCER\n"}'
P1=$(curl -fsS --max-time 3 -o /dev/null -w '%{http_code}' \
        -X POST "http://127.0.0.1:${PORT}/api/inputs/save_pseudo_generator" \
        -H 'Content-Type: application/json' -d "$PROBE_BODY" 2>/dev/null || echo '000')
P2=$(curl -fsS --max-time 3 -o /dev/null -w '%{http_code}' \
        -X POST "http://127.0.0.1:${PORT}/api/pseudos/save_local_input" \
        -H 'Content-Type: application/json' -d "$PROBE_BODY" 2>/dev/null || echo '000')
echo -e "    POST /api/inputs/save_pseudo_generator → ${P1}"
echo -e "    POST /api/pseudos/save_local_input     → ${P2}"

if [ "$NEW_TAG" = "$EXPECTED_TAG" ] && [ "$P1" = "200" ] && [ "$P2" = "200" ]; then
    echo
    echo -e "${GREEN}✅ TOUT EST EN ORDRE.${NC}"
    echo -e "${GREEN}🌐${NC} Ouvrez (ou actualisez Ctrl+Shift+R) : ${URL}"
    echo -e "    Arrêt   : ./ARRETER.sh"
    echo -e "    Logs    : ${LOG}"
    for b in firefox xdg-open google-chrome chromium-browser; do
        if command -v "$b" >/dev/null 2>&1; then
            DISPLAY="${DISPLAY:-:0}" nohup "$b" "${URL}" > /dev/null 2>&1 &
            exit 0
        fi
    done
    exit 0
fi

echo
echo -e "${RED}❌ Le nouveau serveur ne répond pas comme attendu :${NC}"
echo -e "${RED}    build_tag servi=${NEW_TAG:-vide}  P1=${P1}  P2=${P2}${NC}"
echo -e "${YELLOW}Conseils :${NC}"
echo -e "   - regardez les 50 dernières lignes du log :  tail -n 50 ${LOG}"
echo -e "   - si build_tag servi est vide mais POST renvoie 405, un AUTRE serveur Flask"
echo -e "     a pris le port avant nous — exécuter :"
echo -e "       sudo ss -ltnp '( sport = :${PORT} )'"
echo -e "     pour identifier le processus, puis le tuer manuellement."
exit 4

#!/usr/bin/env bash
# Alias rétrocompatible — préférez ./configure.sh
exec "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/configure.sh" "$@"

#!/usr/bin/env bash
# Compile et installe APE + ATOMPAW sous ce dossier (third_party/) et expose les exécutables via bin/.
# Prérequis Ubuntu typiques : build-essential cmake ninja-build gfortran git
#   libgsl-dev libxc-dev libblas-dev liblapack-dev pkg-config
#   autoconf automake libtool libfftw3-dev (souvent utile pour ATOMPAW)
#
# Usage :
#   bash install_ape_atompaw.sh              # tout (sudo apt si disponible)
#   bash install_ape_atompaw.sh --no-apt    # sans installer les paquets système
#   bash install_ape_atompaw.sh ape          # seulement APE
#   bash install_ape_atompaw.sh atompaw     # seulement ATOMPAW
#   bash install_ape_atompaw.sh --force     # recompiler même si déjà présent
#
set -euo pipefail

# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
DO_APT=1
FORCE=0
TARGET="all"

for arg in "$@"; do
  case "$arg" in
    --no-apt) DO_APT=0 ;;
    --force) FORCE=1 ;;
    ape|atompaw|all) TARGET="$arg" ;;
    -h|--help)
      grep '^#' "$0" | grep -v '^#!/' | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    *) echo "Option inconnue : $arg (voir --help)" >&2; exit 1 ;;
  esac
done

SRC="$HERE/third_party/src"
APE_BUILD="$HERE/third_party/build/ape"
APE_PREFIX="$HERE/third_party/ape"
AP_SRC="$SRC/ape"
APAW_SRC="$SRC/atompaw"
APAW_BUILD="$HERE/third_party/build/atompaw"
APAW_PREFIX="$HERE/third_party/atompaw"
BIN_DIR="$HERE/bin"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 4)}"

mkdir -p "$SRC" "$BIN_DIR"

# APE impose Ninja avec gfortran ; les paquets -dev sont nécessaires pour CMake.
ensure_ninja_in_path() {
  export PATH="${HOME}/.local/bin:${HERE}/third_party/bin:${PATH}"
  if command -v ninja &>/dev/null; then
    return 0
  fi
  echo "[install] Ninja absent — téléchargement vers ${HERE}/third_party/bin …"
  mkdir -p "${HERE}/third_party/bin"
  local zip="/tmp/ninja-linux-ape.$$.$RANDOM.zip"
  curl -fsSL -o "$zip" https://github.com/ninja-build/ninja/releases/latest/download/ninja-linux.zip
  unzip -qo "$zip" -d "${HERE}/third_party/bin"
  chmod +x "${HERE}/third_party/bin/ninja"
  rm -f "$zip"
  export PATH="${HERE}/third_party/bin:${PATH}"
}

check_ape_dev_libs() {
  local miss=()
  [[ -f /usr/include/gsl/gsl_version.h ]] || miss+=(libgsl-dev)
  local xc_ok=0
  pkg-config --exists libxc 2>/dev/null && xc_ok=1
  [[ -f /usr/include/xc.h ]] && xc_ok=1
  if [[ "$xc_ok" != 1 ]]; then
    local f
    for f in /usr/include/xc*.h; do
      [[ -f "$f" ]] && xc_ok=1 && break
    done
  fi
  [[ "$xc_ok" = 1 ]] || miss+=(libxc-dev)
  if ((${#miss[@]})); then
    echo "[install] ❌ Bibliothèques de développement manquantes pour APE : ${miss[*]}" >&2
    echo "        Installez-les puis relancez ce script, par exemple :" >&2
    echo "        sudo apt-get install -y ${miss[*]}" >&2
    exit 1
  fi
}

run_apt() {
  if [ "$DO_APT" != 1 ]; then
    echo "[install] --no-apt : saute les paquets Debian/Ubuntu."
    return 0
  fi
  if ! command -v apt-get &>/dev/null; then
    echo "[install] apt-get absent — installez les dépendances à la main."
    return 0
  fi
  echo "[install] sudo apt-get install … (mot de passe possible)"
  sudo apt-get update -qq
  sudo apt-get install -y \
    build-essential cmake ninja-build pkg-config git \
    gfortran gcc \
    libgsl-dev libxc-dev libblas-dev liblapack-dev \
    libfftw3-dev \
    autoconf automake libtool
}

symlink_tools() {
  mkdir -p "$BIN_DIR"
  if [ -x "$APE_PREFIX/bin/ape" ]; then
    ln -sf "$APE_PREFIX/bin/ape" "$BIN_DIR/ape"
    echo "[install] lien : $BIN_DIR/ape -> $APE_PREFIX/bin/ape"
  fi
  local paw=""
  for cand in atompaw AtomPAW atompaw.x; do
    if [ -x "$APAW_PREFIX/bin/$cand" ]; then
      paw="$cand"
      break
    fi
  done
  if [ -n "$paw" ]; then
    ln -sf "$APAW_PREFIX/bin/$paw" "$BIN_DIR/atompaw"
    echo "[install] lien : $BIN_DIR/atompaw -> $APAW_PREFIX/bin/$paw"
  fi
}

build_ape() {
  cd "$HERE"
  if [ "$FORCE" != 1 ] && [ -x "$APE_PREFIX/bin/ape" ]; then
    echo "[install] APE déjà installé : $APE_PREFIX/bin/ape (utilisez --force pour refaire)"
    return 0
  fi
  ensure_ninja_in_path
  check_ape_dev_libs
  rm -rf "$APE_BUILD"
  mkdir -p "$APE_BUILD"
  if [ ! -f "$AP_SRC/CMakeLists.txt" ]; then
    echo "[install] clone APE (gitlab)…"
    rm -rf "$AP_SRC"
    git clone --depth 1 https://gitlab.com/ape/ape.git "$AP_SRC"
  fi
  echo "[install] CMake + build APE (ninja obligatoire avec gfortran)…"
  export CC="${CC:-gcc}"
  export FC="${FC:-gfortran}"
  if ! command -v ninja &>/dev/null; then
    echo "[install] ❌ ninja toujours introuvable après téléchargement automatique." >&2
    exit 1
  fi
  # Forcer Libxc « système » (/usr) si présent : évite un lien vers ~/.local/lib (ABI .so différente).
  local xcroot=()
  if [[ -f /usr/include/xc.h ]]; then
    xcroot=( -DLibxc_ROOT=/usr )
  fi
  cmake -G Ninja -B "$APE_BUILD" -S "$AP_SRC" \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX="$APE_PREFIX" \
    -DCMAKE_C_COMPILER="$CC" \
    -DCMAKE_Fortran_COMPILER="$FC" \
    -DCMAKE_C_FLAGS="-std=gnu89" \
    "${xcroot[@]}"
  cmake --build "$APE_BUILD" -j"$JOBS"
  cmake --install "$APE_BUILD" --prefix "$APE_PREFIX"
  echo "[install] APE OK : $APE_PREFIX/bin/ape"
}

build_atompaw() {
  cd "$HERE"
  if [ "$FORCE" != 1 ]; then
    local existing=""
    for cand in atompaw AtomPAW atompaw.x; do
      if [ -x "$APAW_PREFIX/bin/$cand" ]; then existing=1; break; fi
    done
    if [ -n "$existing" ]; then
      echo "[install] ATOMPAW déjà présent sous $APAW_PREFIX/bin (utilisez --force pour refaire)"
      return 0
    fi
  fi
  if [ "$FORCE" = 1 ]; then
    rm -rf "$APAW_BUILD"
  fi
  if [ ! -f "$APAW_SRC/configure.ac" ] && [ ! -f "$APAW_SRC/configure" ]; then
    echo "[install] clone ATOMPAW (github)…"
    rm -rf "$APAW_SRC"
    git clone --depth 1 https://github.com/atompaw/atompaw.git "$APAW_SRC"
  fi
  cd "$APAW_SRC"
  if [ ! -f ./configure ]; then
    echo "[install] bootstrap ATOMPAW…"
    ./bootstrap.sh
  fi
  mkdir -p "$APAW_BUILD"
  cd "$APAW_BUILD"
  echo "[install] configure ATOMPAW…"
  "$APAW_SRC/configure" \
    --prefix="$APAW_PREFIX" \
    --enable-libxc \
    --with-libxc-prefix=/usr \
    FC=gfortran FCFLAGS="-O2 -ffree-line-length-none"
  make -j"$JOBS"
  make install
  cd "$HERE"
  echo "[install] ATOMPAW OK (préfixe) : $APAW_PREFIX/bin/"
}

print_api_hint() {
  echo ""
  echo "── Prochaines étapes ──"
  echo "1) Redémarrer l’API (port 5007) après installation."
  echo "2) Optionnel dans Interface-QE_v1/api_config.json :"
  echo '   "ape_bin": "'"$BIN_DIR/ape"'",'
  echo '   "atompaw_bin": "'"$BIN_DIR/atompaw"'",'
  echo "   L’API détecte aussi automatiquement « generation_pseudos/bin/ » si pseudo_interface_dir pointe ici."
  echo "3) APE ne gère pas « --version » : il lit d’abord « inp.ape » dans le répertoire courant,"
  echo "   sinon l’entrée standard (terminal = attente). Lancez avec un fichier : cd dossier && ape"
  echo "   ou test rapide : cd /tmp && ape </dev/null   (doit afficher une erreur et quitter)."
}

run_apt

case "$TARGET" in
  all)
    build_ape
    build_atompaw
    ;;
  ape)
    build_ape
    ;;
  atompaw)
    build_atompaw
    ;;
esac

symlink_tools
print_api_hint

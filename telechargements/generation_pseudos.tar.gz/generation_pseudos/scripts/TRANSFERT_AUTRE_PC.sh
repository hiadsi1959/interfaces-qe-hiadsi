#!/bin/bash
# Alias rétrocompatible — préférez ./emballer.sh
# Usage identique ; sans --leger ni --complet → archive complète (comportement historique).
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ARGS=()
HAS_MODE=0
for arg in "$@"; do
    case "$arg" in
        --leger|--light|--sans-pseudos|--complet|--full|--avec-pseudos) HAS_MODE=1 ;;
    esac
done
if [ "$HAS_MODE" = 0 ]; then
    ARGS+=(--complet)
fi
exec "$SCRIPT_DIR/emballer.sh" "${ARGS[@]}" "$@"

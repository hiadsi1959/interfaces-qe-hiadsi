#!/usr/bin/env bash
# Télécharge les pseudos NC PBE (ONCVPSP / PseudoDojo v0.4) pour les lanthanides La–Lu
# et génère les UPF Quantum ESPRESSO à partir des entrées .in officielles.
set -euo pipefail

# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"

PSEUDOS_DIR="${PSEUDOS_DIR:-$HERE/pseudos}"
DEST="${DEST:-$PSEUDOS_DIR/PseudoDojo_standard}"
LAN_DIR="${LAN_DIR:-$PSEUDOS_DIR/Lanthanides_NC_PBE}"
TMP="${TMPDIR:-/tmp}/pdj_lanthanides_$$"
ZIP_URL="https://github.com/PseudoDojo/ONCVPSP-PBE-PDv0.4/archive/refs/heads/master.zip"
ONCV_BIN="${ONCVPSP_BIN:-$HOME/oncvpsp/build/bin/oncvpsp.x}"

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m'

LANTHANIDES=(La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu)

mkdir -p "$DEST" "$LAN_DIR" "$TMP"
cd "$TMP"

if [ ! -x "$ONCV_BIN" ]; then
  for c in "$HERE/oncvpsp-master/build/bin/oncvpsp.x" "$HOME/oncvpsp/build/bin/oncvpsp.x"; do
    [ -x "$c" ] && ONCV_BIN="$c" && break
  done
fi

echo -e "${CYAN}══ Téléchargement PseudoDojo ONCVPSP-PBE-PDv0.4 (NC, lanthanides) ══${NC}"
echo -e "    Archive : ${ZIP_URL}"
echo -e "    Cible UPF : ${LAN_DIR}"
echo

if [ ! -d ONCVPSP-PBE-PDv0.4-master ]; then
  curl -L --connect-timeout 60 --retry 3 -o ONCVPSP-PBE.zip "$ZIP_URL"
  unzip -q ONCVPSP-PBE.zip
fi
REPO="$TMP/ONCVPSP-PBE-PDv0.4-master"

ok=0
skip=0
fail=0
missing=0

convert_in() {
  local infile="$1"
  local sym="$2"
  local tag="$3"
  local work="$TMP/work_${sym}_${tag}"
  mkdir -p "$work"
  sed 's/\bpsp8\b/both/I' "$infile" > "$work/run.in"
  if [ ! -x "$ONCV_BIN" ]; then
    echo -e "${YELLOW}   ⚠ oncvpsp.x absent — copie .psp8 seulement pour ${sym}/${tag}${NC}"
    return 2
  fi
  local outlog="$work/oncv.out"
  if ! (cd "$work" && "$ONCV_BIN" < run.in > oncv.out 2>&1); then
    return 1
  fi
  if ! grep -qi '<UPF' "$outlog" 2>/dev/null; then
    return 1
  fi
  python3 - "$outlog" "$LAN_DIR/${sym}_${tag}.UPF" <<'PY'
import re, sys
from pathlib import Path
raw = Path(sys.argv[1]).read_text(encoding='utf-8', errors='replace')
dest = Path(sys.argv[2])
m = re.search(r'(<UPF\s+version.*?</UPF>)', raw, re.DOTALL | re.IGNORECASE)
if not m:
    sys.exit(1)
block = m.group(1).strip()
if not block.lstrip().startswith('<?xml'):
    block = '<?xml version="1.0" encoding="UTF-8"?>\n' + block
dest.write_text(block + '\n', encoding='utf-8')
PY
}

for sym in "${LANTHANIDES[@]}"; do
  eldir="$REPO/$sym"
  if [ ! -d "$eldir" ]; then
    echo -e "${RED}   ✗ $sym : absent du dépôt PseudoDojo${NC}"
    missing=$((missing + 1))
    continue
  fi
  echo -e "${CYAN}▶ $sym${NC}"
  for psp in "$eldir"/*.psp8; do
    [ -f "$psp" ] || continue
    base="$(basename "$psp" .psp8)"
    tag="${base#${sym}-}"
    tag="${tag//+/_}"
    cp -f "$psp" "$DEST/${sym}_ONCV_${tag}.psp8"
    cp -f "$psp" "$LAN_DIR/${sym}_${tag}.psp8"
    infile="$eldir/${base}.in"
    if [ ! -f "$infile" ]; then
      echo -e "${YELLOW}     · ${base}.psp8 (pas de .in — pas de conversion UPF)${NC}"
      skip=$((skip + 1))
      continue
    fi
    if convert_in "$infile" "$sym" "$tag"; then
      cp -f "$LAN_DIR/${sym}_${tag}.UPF" "$DEST/${sym}_ONCV_${tag}.UPF" 2>/dev/null || true
      sz=$(stat -c%s "$LAN_DIR/${sym}_${tag}.UPF" 2>/dev/null || echo 0)
      echo -e "${GREEN}     ✓ ${sym}_${tag}.UPF (${sz} o)${NC}"
      ok=$((ok + 1))
    else
      echo -e "${RED}     ✗ ${sym}_${tag} — échec ONCV (voir log)${NC}"
      fail=$((fail + 1))
    fi
  done
done

echo
echo -e "${CYAN}══ Résumé ══${NC}"
echo -e "   UPF générés : ${GREEN}${ok}${NC}"
echo -e "   Échecs ONCV  : ${RED}${fail}${NC}"
echo -e "   Sans .in     : ${YELLOW}${skip}${NC}"
echo -e "   Éléments absents : ${missing}"
echo -e "   Dossiers :"
echo -e "     ${LAN_DIR}"
echo -e "     ${DEST}"
echo
ls -1 "$LAN_DIR"/*.UPF 2>/dev/null | wc -l | xargs -I{} echo -e "   Total UPF dans Lanthanides_NC_PBE : {}"
echo -e "${GREEN}✅ Terminé. Relancez ./DEMARRER.sh pour rafraîchir l'API.${NC}"

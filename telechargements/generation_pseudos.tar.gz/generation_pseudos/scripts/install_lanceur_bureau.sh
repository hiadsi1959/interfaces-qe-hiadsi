#!/bin/bash
# Installe un raccourci bureau / menu pour GenerationPseudos (double-clic).
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
LAUNCHER="$HERE/GenerationPseudos"
DESKTOP_SRC="$HERE/GenerationPseudos.desktop.in"
ICON="$HERE/favicon.svg"

if [ ! -x "$LAUNCHER" ]; then
    chmod +x "$LAUNCHER" "$HERE/ArreterGenerationPseudos" 2>/dev/null || true
fi

if [ ! -f "$LAUNCHER" ]; then
    echo "❌ GenerationPseudos introuvable dans $HERE" >&2
    exit 1
fi

gen_desktop() {
    local dest="$1"
    sed -e "s|@APP_ROOT@|$HERE|g" \
        -e "s|@ICON@|$ICON|g" \
        "$DESKTOP_SRC" > "$dest"
    chmod +x "$dest"
    echo "   ✓ $dest"
}

mkdir -p "$HOME/.local/share/applications"
gen_desktop "$HOME/.local/share/applications/generation-pseudos.desktop"

if [ -d "$HOME/Desktop" ]; then
    gen_desktop "$HOME/Desktop/GenerationPseudos.desktop"
elif [ -d "$HOME/Bureau" ]; then
    gen_desktop "$HOME/Bureau/GenerationPseudos.desktop"
fi

if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true
fi

echo ""
echo "✅ Raccourci installé."
echo "   Double-cliquez « Génération des Pseudopotentiels » sur le bureau"
echo "   ou cherchez-le dans le menu applications."
echo ""
echo "   Lancement manuel : $LAUNCHER"
echo "   Reconfiguration  : $LAUNCHER --reconfig"

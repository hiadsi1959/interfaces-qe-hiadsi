#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
#  emballer.sh — Compacter le projet en archive tar.gz (dist/)
# ═══════════════════════════════════════════════════════════════════════════════
#
#  Usage (sur ce PC) :
#    ./emballer.sh                  # léger (~ quelques Mo, sans pseudos/ ni third_party/)
#    ./emballer.sh --complet        # avec pseudos/ et third_party/ (peut être très lourd)
#    ./emballer.sh --output ~/Bureau/mon_archive.tar.gz
#
#  Sur l'autre PC :
#    tar xzf generation_pseudos_*.tar.gz && cd generation_pseudos
#    ./configure.sh && ./DEMARRER.sh
#
#  Options :
#    --leger          Sans pseudos/ ni third_party/ (défaut)
#    --complet        Archive complète (inclut pseudos/ et third_party/)
#    --output PATH    Chemin de sortie (défaut : dist/generation_pseudos_AAAA-MM-JJ.tar.gz)
#    --print-path     Affiche uniquement le chemin de l’archive
#    --quiet          Moins de messages
#    -h, --help       Aide
#
# ═══════════════════════════════════════════════════════════════════════════════
set -euo pipefail

# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
cd "$HERE"

GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m'

LIGHT=1
PRINT_PATH=0
QUIET=0
OUT=""
STAMP="$(date +%Y%m%d)"

usage() {
    sed -n '6,22p' "$0" | sed 's/^# //'
    exit 0
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --leger|--light|--sans-pseudos) LIGHT=1; shift ;;
        --complet|--full|--avec-pseudos) LIGHT=0; shift ;;
        --output|-o) OUT="${2:-}"; shift 2 ;;
        --print-path) PRINT_PATH=1; shift ;;
        --quiet) QUIET=1; shift ;;
        -h|--help) usage ;;
        *) echo -e "${YELLOW}Option inconnue : $1${NC}" >&2; usage ;;
    esac
done

log() { [ "$QUIET" = 1 ] || echo -e "$@"; }

DIST="$HERE/dist"
mkdir -p "$DIST"
if [[ -z "$OUT" ]]; then
    OUT="$DIST/generation_pseudos_${STAMP}.tar.gz"
else
    OUT="$(readlink -f "$OUT" 2>/dev/null || echo "$OUT")"
    mkdir -p "$(dirname "$OUT")"
fi

PARENT="$(dirname "$HERE")"
NAME="$(basename "$HERE")"

EXCLUDES=(
    --exclude='logs/*.log'
    --exclude='logs/*.pid'
    --exclude='CRASH'
    --exclude='tmp/*'
    --exclude='archive'
    --exclude='_work/*'
    --exclude='dist'
    --exclude='oncvpsp-master'
    --exclude='oncvpsp-master.zip'
    --exclude='.git'
    --exclude='__pycache__'
    --exclude='*.pyc'
    --exclude='api.pid'
    --exclude='server.pid'
    --exclude='pseudos_telechargés*'
    --exclude='pseudos-*/_runs/*'
    --exclude='pseudos_generes/*'
)
if [ "$LIGHT" = 1 ]; then
    EXCLUDES+=(--exclude='pseudos' --exclude='third_party')
fi

if [ "$PRINT_PATH" = 0 ]; then
    log "${CYAN}${BOLD}📦 Emballage du projet${NC}"
    log "   Source : $HERE"
    log "   Cible  : $OUT"
    if [ "$LIGHT" = 1 ]; then
        log "   Mode   : ${GREEN}léger${NC} (sans pseudos/ ni third_party/)"
    else
        log "   Mode   : ${YELLOW}complet${NC} (peut prendre plusieurs minutes)"
    fi
    log ""
fi

tar czf "$OUT" "${EXCLUDES[@]}" -C "$PARENT" "$NAME"

if [ ! -f "$OUT" ]; then
    echo "❌ Échec : archive introuvable." >&2
    exit 1
fi

if [ "$PRINT_PATH" = 1 ]; then
    echo "$OUT"
    exit 0
fi

SIZE="$(du -h "$OUT" | cut -f1)"
log "${GREEN}✅ Archive créée (${SIZE})${NC}"
log "   $OUT"
log ""
log "${BOLD}── Sur l’autre PC ──${NC}"
log "   tar xzf $(basename "$OUT")"
log "   cd ${NAME} && ./configure.sh && ./DEMARRER.sh"
log ""
log "   Envoi réseau : ./TRANSFERER_VERS_AUTRE_PC.sh --dest user@IP"
log "   Doc          : docs/TRANSFERT_AUTRE_PC.md"

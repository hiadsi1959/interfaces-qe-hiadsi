#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
#  Arrêt de l'API autonome du générateur de pseudopotentiels (port 5008)
# ─────────────────────────────────────────────────────────────────────────────
# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'; NC='\033[0m'
GEN_PORT="${GEN_PORT:-5008}"

echo -e "\n${RED}🛑 Arrêt de l'API pseudopotentiels (port ${GEN_PORT})…${NC}\n"

if [ -f "$BASE_DIR/logs/api_pseudos_standalone.pid" ]; then
    PID=$(cat "$BASE_DIR/logs/api_pseudos_standalone.pid")
    if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
        kill "$PID" 2>/dev/null && echo -e "   ✅ API standalone (PID $PID)"
    fi
    rm -f "$BASE_DIR/logs/api_pseudos_standalone.pid"
fi
pkill -TERM -f 'api_pseudos_standalone\.py' 2>/dev/null || true
sleep 0.3
if command -v lsof >/dev/null 2>&1; then
    OLD=$(lsof -ti:"$GEN_PORT" 2>/dev/null || true)
    [ -n "$OLD" ] && kill $OLD 2>/dev/null && echo -e "   ✅ Port $GEN_PORT libéré"
fi

for f in api.pid server.pid http.pid; do
    if [ -f "$BASE_DIR/$f" ]; then
        PID=$(cat "$BASE_DIR/$f")
        kill -0 "$PID" 2>/dev/null && kill "$PID" 2>/dev/null
        rm -f "$BASE_DIR/$f"
    fi
done

echo -e "\n${GREEN}✅ API arrêtée (port ${GEN_PORT}).${NC}\n"

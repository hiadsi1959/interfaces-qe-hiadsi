#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
#  build_installer.sh — Produit UN seul fichier exécutable : dist/generation_pseudos
#
#  Ce fichier contient l’interface + l’API. Sur un autre PC :
#    chmod +x generation_pseudos
#    ./generation_pseudos
#  → installation dans ~/.local/share/generation_pseudos/
#  → auto-configuration des chemins (QE, ONCV, …)
#  → démarrage + navigateur
#
#  Usage :
#    ./scripts/build_installer.sh
#    ./scripts/build_installer.sh --output ~/Bureau/generation_pseudos
# ═══════════════════════════════════════════════════════════════════════════════
set -euo pipefail

HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$HERE"

OUTPUT="${HERE}/dist/generation_pseudos"
VERSION="$(date +%Y%m%d)"
BUILD_ID="gp-${VERSION}"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --output|-o) OUTPUT="$(readlink -f "${2:?}")"; shift 2 ;;
        --version) VERSION="${2:?}"; BUILD_ID="gp-${VERSION}"; shift 2 ;;
        -h|--help)
            sed -n '3,14p' "$0" | sed 's/^# //'
            exit 0
            ;;
        *) echo "Option inconnue : $1" >&2; exit 1 ;;
    esac
done

command -v tar >/dev/null || { echo "tar requis." >&2; exit 1; }

STAGE="$(mktemp -d "${TMPDIR:-/tmp}/gp_build.XXXXXX")"
PAYLOAD=""
trap 'rm -rf "$STAGE"; [ -n "$PAYLOAD" ] && rm -f "$PAYLOAD"' EXIT

echo "📦 Construction de l’installateur (${BUILD_ID})…"
echo "   Source : $HERE"
echo "   Cible  : $OUTPUT"

# ── Fichiers embarqués (interface + API, sans pseudos/ ni third_party/) ───────
copy_item() {
    local src="$1"
    [ -e "$HERE/$src" ] || return 0
    local dest="$STAGE/$src"
    mkdir -p "$(dirname "$dest")"
    if [ -d "$HERE/$src" ]; then
        cp -a "$HERE/$src" "$dest"
    else
        cp -a "$HERE/$src" "$dest"
    fi
}

ROOT_FILES=(
    api_pseudos_standalone.py
    generator_guide.py
    pseudo_auto_inputs.py
    pseudo_libraries.py
    lanthanide_nc.py
    transition_3d_nc.py
    elements_physics_db.py
    index.html
    pseudo_wizard.html
    favicon.svg
    requirements.txt
    api_config.local.json.example
    GenerationPseudos
    ArreterGenerationPseudos
    DEMARRER.sh
    ARRETER.sh
    configure.sh
    config_pc.sh
    GenerationPseudos.desktop.in
    utils_dom_safe.js
    config_chemins.js
    qe_paths_setup.js
    script_api_autostart.js
    script_bases_externes.js
    script_elements_pseudos.js
    script_generateur_ape_atompaw.js
    script_generateur_ape_panel.js
    script_generateur_ld1.js
    script_generateur_oncvpsp_panel.js
    script_historique_runs.js
    script_compare_upf.js
    script_tableau_periodique.js
)

for f in "${ROOT_FILES[@]}"; do
    copy_item "$f"
done

copy_item data/oncv
copy_item oncv_templates_3d
copy_item pseudo_generator_templates
copy_item scripts

# Gabarits ONCV à la racine (attendus par l’UI)
for dat in data/oncv/oncv_default_14_Si.dat data/oncv/oncv_default_Cu.dat; do
    if [ -f "$HERE/$dat" ]; then
        cp -a "$HERE/$dat" "$STAGE/$(basename "$dat")"
    fi
done

# Dossiers vides requis
mkdir -p "$STAGE"/{pseudos-ld1,pseudos-APE,pseudos-atompaw,pseudos-oncvpsp,pseudos-telecharges,pseudos,logs,_work}
touch "$STAGE/_work/.gitkeep"
for d in pseudos-ld1 pseudos-APE pseudos-atompaw pseudos-oncvpsp; do
    touch "$STAGE/$d/.gitkeep"
    mkdir -p "$STAGE/$d/_runs"
done

cat > "$STAGE/BUILD_INFO.json" <<EOF
{
  "name": "generation_pseudos",
  "build_id": "${BUILD_ID}",
  "version": "${VERSION}",
  "built_from": "${HERE}"
}
EOF

# Ne pas embarquer les gros dossiers
rm -rf "$STAGE/scripts/__pycache__" 2>/dev/null || true
find "$STAGE" -name '__pycache__' -type d -exec rm -rf {} + 2>/dev/null || true

PAYLOAD="$(mktemp "${TMPDIR:-/tmp}/gp_payload.XXXXXX.tar.gz")"
tar czf "$PAYLOAD" -C "$STAGE" .
mkdir -p "$(dirname "$OUTPUT")"

# ── En-tête exécutable (self-extractor + lanceur) ───────────────────────────
cat > "$OUTPUT" <<'STUB_HEAD'
#!/usr/bin/env bash
# generation_pseudos — installateur autonome (fichier unique)
# Interface + API Quantum ESPRESSO · ld1 · APE · ATOMPAW · ONCVPSP
set -euo pipefail

SELF="${BASH_SOURCE[0]}"
while [ -L "$SELF" ]; do SELF="$(readlink "$SELF")"; done
SELF="$(cd "$(dirname "$SELF")" && pwd)/$(basename "$SELF")"

INSTALL_BASE="${GEN_PSEUDOS_INSTALL:-${XDG_DATA_HOME:-$HOME/.local/share}/generation_pseudos}"
APP_DIR="$INSTALL_BASE/app"
VERSION="__GP_VERSION__"
BUILD_ID="__GP_BUILD_ID__"
VER_FILE="$INSTALL_BASE/.installed_version"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

usage() {
    cat <<EOF
generation_pseudos — installateur autonome (fichier unique)

  ./generation_pseudos              Installer si besoin, configurer ce PC, démarrer
  ./generation_pseudos --install    Copier dans ~/.local/bin/ (commande globale)
  ./generation_pseudos --reinstall  Ré-extraire l’application
  ./generation_pseudos --reconfig   Reconfigurer les chemins (QE, ONCV, …)
  ./generation_pseudos --uninstall  Supprimer l’installation locale
  ./generation_pseudos --help

Installation : $INSTALL_BASE/app
Config       : $APP_DIR/api_config.json
Interface    : http://127.0.0.1:5008/

Quantum ESPRESSO / ONCV / APE / ATOMPAW doivent être installés sur la machine ;
seuls les chemins sont détectés automatiquement.
EOF
}

_gui() {
    command -v zenity >/dev/null && zenity --info --title="${1:-Info}" --text="$2" --width=440 2>/dev/null && return
    command -v kdialog >/dev/null && kdialog --msgbox "$2" --title "${1:-Info}" 2>/dev/null && return
    echo "$2"
}

_need_extract() {
    [ ! -f "$APP_DIR/api_pseudos_standalone.py" ] && return 0
    [ ! -f "$VER_FILE" ] && return 0
    [ "$(cat "$VER_FILE" 2>/dev/null || echo '')" != "$VERSION" ] && return 0
    return 1
}

_do_extract() {
    echo -e "${CYAN}📦 Installation de l’interface dans :${NC}"
    echo "   $APP_DIR"
    mkdir -p "$INSTALL_BASE"
    rm -rf "$APP_DIR"
    mkdir -p "$APP_DIR"
    local line
    line=$(awk '/^__GENPSEUDO_ARCHIVE__$/ {print NR + 1; exit 0; }' "$SELF")
    if [ -z "$line" ]; then
        echo -e "${RED}❌ Archive interne corrompue.${NC}" >&2
        exit 1
    fi
    tail -n +"$line" "$SELF" | tar xzf - -C "$APP_DIR"
    echo "$VERSION" > "$VER_FILE"
    chmod +x "$APP_DIR/GenerationPseudos" "$APP_DIR/ArreterGenerationPseudos" 2>/dev/null || true
    chmod +x "$APP_DIR"/*.sh "$APP_DIR/scripts"/*.sh 2>/dev/null || true
    echo -e "${GREEN}✅ Installation terminée (${BUILD_ID})${NC}"
}

_do_install_bin() {
    mkdir -p "$HOME/.local/bin"
    cp -f "$SELF" "$HOME/.local/bin/generation_pseudos"
    chmod +x "$HOME/.local/bin/generation_pseudos"
    echo -e "${GREEN}✅ Commande installée : ~/.local/bin/generation_pseudos${NC}"
    case ":$PATH:" in *":$HOME/.local/bin:"*) ;;
        *) echo -e "${YELLOW}   Ajoutez à PATH : export PATH=\"\$HOME/.local/bin:\$PATH\"${NC}" ;;
    esac
}

_do_uninstall() {
    rm -rf "$INSTALL_BASE"
    rm -f "$HOME/.local/bin/generation_pseudos"
    echo -e "${GREEN}✅ Désinstallation terminée.${NC}"
    exit 0
}

ACTION=run
EXTRA=()
for arg in "$@"; do
    case "$arg" in
        --install) ACTION=install ;;
        --reinstall) ACTION=reinstall ;;
        --reconfig) EXTRA+=(--reconfig) ;;
        --uninstall) ACTION=uninstall ;;
        -h|--help) usage; exit 0 ;;
        *) EXTRA+=("$arg") ;;
    esac
done

case "$ACTION" in
    uninstall) _do_uninstall ;;
    reinstall) _do_extract ;;
    install)
        _need_extract && _do_extract || true
        _do_install_bin
        _gui "Installé" "generation_pseudos est prêt.\n\nLancez : generation_pseudos\nou depuis le terminal : ~/.local/bin/generation_pseudos"
        exit 0
        ;;
esac

if _need_extract; then
    _do_extract
fi

export GEN_PSEUDOS_ROOT="$APP_DIR"
export GEN_PSEUDOS_INSTALL="$INSTALL_BASE"
cd "$APP_DIR"

if [ ! -x "$APP_DIR/GenerationPseudos" ]; then
    echo -e "${RED}❌ Fichiers d’application incomplets dans $APP_DIR${NC}" >&2
    exit 1
fi

exec "$APP_DIR/GenerationPseudos" "${EXTRA[@]}"
STUB_HEAD

# Injecter version dans le stub
sed -i "s/__GP_VERSION__/${VERSION}/g; s/__GP_BUILD_ID__/${BUILD_ID}/g" "$OUTPUT"

echo "__GENPSEUDO_ARCHIVE__" >> "$OUTPUT"
cat "$PAYLOAD" >> "$OUTPUT"
chmod +x "$OUTPUT"

FINAL_SIZE=$(wc -c < "$OUTPUT" | tr -d ' ')
echo ""
echo "✅ Installateur créé :"
echo "   $OUTPUT"
echo "   Taille : $(numfmt --to=iec-i --suffix=B "$FINAL_SIZE" 2>/dev/null || echo "${FINAL_SIZE} o")"
echo ""
echo "Sur un autre PC :"
echo "   chmod +x generation_pseudos"
echo "   ./generation_pseudos"
echo "   ./generation_pseudos --install   # optionnel : commande globale"

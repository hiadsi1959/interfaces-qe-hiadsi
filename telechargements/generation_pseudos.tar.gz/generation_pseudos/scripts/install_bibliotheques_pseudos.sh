#!/bin/bash
# Crée l'arborescence PSLibrary / PseudoDojo / SSSP, relie les archives existantes,
# synchronise PBE/LDA legacy et UPF isolés à la racine.
set -e
# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
cd "$HERE"

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'; NC='\033[0m'
PSEUDOS_DIR="${PSEUDOS_DIR:-$HERE/pseudos}"
mkdir -p "$PSEUDOS_DIR"

echo -e "${CYAN}📚 Bibliothèques de pseudopotentiels${NC}"
echo -e "    Cible : ${PSEUDOS_DIR}"
echo

python3 -c "import pseudo_libraries as pl; c=pl.ensure_library_tree('$PSEUDOS_DIR'); print('Dossiers créés:', c or '(déjà présents)')"

SOURCES=(
    "$HOME/Interface-QE-old/pseudos"
    "$HOME/Interface-QE/pseudos"
    "$HOME/Interface-QE_v1/pseudos"
)

link_if_missing() {
    local src="$1" name="$2"
    local dst="$PSEUDOS_DIR/$name"
    if [ -d "$src/$name" ] && [ ! -e "$dst" ]; then
        ln -sf "$src/$name" "$dst"
        echo -e "${GREEN}   ✅ Lien : $name → $src/$name${NC}"
        return 0
    fi
    return 1
}

echo -e "${CYAN}▶ Liens vers archives déjà installées ailleurs${NC}"
LIBS=(
    PSLibrary_NC_PBE PSLibrary_NC_LDA PSLibrary_NC_PBEsol
    PSLibrary_USPP_PBE PSLibrary_USPP_LDA PSLibrary_USPP_PBEsol
    PSLibrary_PAW_PBE PSLibrary_PAW_LDA PSLibrary_PAW_PBEsol
    PseudoDojo_standard PseudoDojo_stringent Lanthanides_NC_PBE
    SSSP_efficiency SSSP_precision
)
linked=0
for src in "${SOURCES[@]}"; do
    [ -d "$src" ] || continue
    for name in "${LIBS[@]}"; do
        link_if_missing "$src" "$name" && linked=$((linked + 1)) || true
    done
done
[ "$linked" -eq 0 ] && echo -e "${YELLOW}   (aucun lien externe — normal si première install)${NC}"

echo -e "${CYAN}▶ Synchronisation PBE/USPP/PAW + fichiers racine${NC}"
python3 <<PY
import pseudo_libraries as pl
r = pl.organize_libraries("$PSEUDOS_DIR", copy_files=True)
print(f"   {r['action_count']} opération(s)")
for a in r["actions"][:12]:
    print(f"      {a}")
if r["action_count"] > 12:
    print(f"      … et {r['action_count'] - 12} de plus")
PY

echo
echo -e "${CYAN}▶ Inventaire (exemple Mn)${NC}"
python3 <<PY
import pseudo_libraries as pl
for fam, lib_id in [
    ("pslibrary", "PSLibrary_PAW_PBE"),
    ("pseudodojo", "PseudoDojo_standard"),
    ("sssp", "SSSP_efficiency"),
]:
    r = pl.scan_library("$PSEUDOS_DIR", lib_id, "Mn")
    names = [f["name"] for f in r.get("files", [])]
    print(f"  Mn @ {lib_id}: {r['file_count']} — {', '.join(names) or '—'}")
PY

echo
echo -e "${GREEN}✅ Terminé.${NC}"
echo -e "   Téléchargements : voir pseudos/README_BIBLIOTHEQUES.md"
echo -e "   Interface       : ./DEMARRER.sh → http://127.0.0.1:5008/"
echo -e "   Bouton UI       : « Synchroniser maintenant » dans les onglets bibliothèques"

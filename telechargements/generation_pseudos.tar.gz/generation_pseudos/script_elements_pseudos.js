// ═══════════════════════════════════════════════════════════════════════════
// GESTION DES ÉLÉMENTS ET PSEUDO-POTENTIELS DYNAMIQUES (V2)
// Après ntyp: Ajouter les noms des éléments et afficher leurs pseudos
// ═══════════════════════════════════════════════════════════════════════════

/**
 * BASE DE DONNÉES DES PSEUDO-POTENTIELS
 */
const PSEUDOS_DATABASE = {
    'H': { mass: 1.008, pseudo: 'H.pbe-rrkjus_psl.1.0.0.UPF' },
    'He': { mass: 4.003, pseudo: 'He.pbe-rrkjus_psl.1.0.0.UPF' },
    'Li': { mass: 6.941, pseudo: 'Li.pbe-s-rrkjus_psl.1.0.0.UPF' },
    'Be': { mass: 9.012, pseudo: 'Be.pbe-s-rrkjus_psl.1.0.0.UPF' },
    'B': { mass: 10.811, pseudo: 'B.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'C': { mass: 12.011, pseudo: 'C.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'N': { mass: 14.007, pseudo: 'N.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'O': { mass: 15.999, pseudo: 'O.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'F': { mass: 18.998, pseudo: 'F.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'Ne': { mass: 20.180, pseudo: 'Ne.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'Na': { mass: 22.990, pseudo: 'Na.pbe-s-rrkjus_psl.1.0.0.UPF' },
    'Mg': { mass: 24.305, pseudo: 'Mg.pbe-s-rrkjus_psl.1.0.0.UPF' },
    'Al': { mass: 26.982, pseudo: 'Al.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'Si': { mass: 28.085, pseudo: 'Si.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'P': { mass: 30.974, pseudo: 'P.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'S': { mass: 32.065, pseudo: 'S.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'Cl': { mass: 35.453, pseudo: 'Cl.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'Ar': { mass: 39.948, pseudo: 'Ar.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'K': { mass: 39.098, pseudo: 'K.pbe-s-rrkjus_psl.1.0.0.UPF' },
    'Ca': { mass: 40.078, pseudo: 'Ca.pbe-s-rrkjus_psl.1.0.0.UPF' },
    'Sc': { mass: 44.956, pseudo: 'Sc.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Ti': { mass: 47.867, pseudo: 'Ti.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'V': { mass: 50.942, pseudo: 'V.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Cr': { mass: 51.996, pseudo: 'Cr.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Mn': { mass: 54.938, pseudo: 'Mn.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Fe': { mass: 55.845, pseudo: 'Fe.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Co': { mass: 58.933, pseudo: 'Co.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Ni': { mass: 58.693, pseudo: 'Ni.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Cu': { mass: 63.546, pseudo: 'Cu.pbe-dn-rrkjus_psl.1.0.0.UPF' },
    'Zn': { mass: 65.380, pseudo: 'Zn.pbe-dn-rrkjus_psl.1.0.0.UPF' },
    'Ga': { mass: 69.723, pseudo: 'Ga.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'Ge': { mass: 72.640, pseudo: 'Ge.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'As': { mass: 74.922, pseudo: 'As.pbe-n-kjpaw_psl.1.0.0.UPF' },
    'Se': { mass: 78.960, pseudo: 'Se.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'Br': { mass: 79.904, pseudo: 'Br.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'Ba': { mass: 137.327, pseudo: 'Ba.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'La': { mass: 138.905, pseudo: 'La.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Ce': { mass: 140.116, pseudo: 'Ce.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Pr': { mass: 140.908, pseudo: 'Pr.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Nd': { mass: 144.242, pseudo: 'Nd.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Sm': { mass: 150.360, pseudo: 'Sm.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Eu': { mass: 151.964, pseudo: 'Eu.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Gd': { mass: 157.250, pseudo: 'Gd.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Tb': { mass: 158.925, pseudo: 'Tb.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Dy': { mass: 162.500, pseudo: 'Dy.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Ho': { mass: 164.930, pseudo: 'Ho.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Er': { mass: 167.259, pseudo: 'Er.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Tm': { mass: 168.934, pseudo: 'Tm.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Yb': { mass: 173.040, pseudo: 'Yb.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Lu': { mass: 174.967, pseudo: 'Lu.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Hf': { mass: 178.492, pseudo: 'Hf.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Ta': { mass: 180.948, pseudo: 'Ta.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'W': { mass: 183.840, pseudo: 'W.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Re': { mass: 186.207, pseudo: 'Re.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Os': { mass: 190.230, pseudo: 'Os.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Ir': { mass: 192.217, pseudo: 'Ir.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Pt': { mass: 195.084, pseudo: 'Pt.pbe-d-rrkjus_psl.1.0.0.UPF' },
    'Au': { mass: 196.967, pseudo: 'Au.pbe-d-rrkjus_psl.1.0.0.UPF' },
    'Hg': { mass: 200.592, pseudo: 'Hg.pbe-dn-rrkjus_psl.1.0.0.UPF' },
    'Tl': { mass: 204.383, pseudo: 'Tl.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'Pb': { mass: 207.200, pseudo: 'Pb.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'Bi': { mass: 208.980, pseudo: 'Bi.pbe-dn-kjpaw_psl.1.0.0.UPF' }
};

// Stockage global
let atomicSpeciesGlobal = '';

/**
 * Créer la section pour les noms des éléments APRÈS ntyp
 * DYNAMIQUE en fonction de ntyp
 */
function creerSectionNomElements() {
    console.log('⚛️ Création de la section noms d\'éléments...');
    
    // Chercher le champ ntyp
    const ntypInput = document.getElementById('ntyp');
    if (!ntypInput) {
        console.warn('⚠️ Champ ntyp non trouvé');
        return;
    }
    
    // Ajouter un écouteur au changement de ntyp
    ntypInput.addEventListener('change', reconstruireChampElements);
    ntypInput.addEventListener('input', reconstruireChampElements);
    
    // Créer la section initiale
    reconstruireChampElements();
    
    console.log('✅ Section noms d\'éléments créée (dynamique)');
}

/**
 * Reconstruire les champs d'éléments en fonction de ntyp
 */
function reconstruireChampElements() {
    const ntypInput = document.getElementById('ntyp');
    const ntyp = parseInt(ntypInput?.value) || 0;
    
    console.log(`🔨 reconstruireChampElements() - ntyp=${ntyp}`);
    
    if (ntyp <= 0) {
        const section = document.getElementById('section_elements');
        if (section) section.innerHTML = '';
        return;
    }
    
    // Chercher le conteneur correct: section_elements (dans section_3_especes)
    let section = document.getElementById('section_elements');
    
    if (!section) {
        console.warn('⚠️ section_elements NOT FOUND - On essaie de le créer');
        section = document.createElement('div');
        section.id = 'section_elements';
        
        // L'insérer dans section_3_especes s'il existe
        const container3 = document.getElementById('section_3_especes');
        if (container3) {
            container3.appendChild(section);
        } else {
            console.error('❌ section_3_especes NOT FOUND');
            return;
        }
    }
    
    // Construire les champs d'entrée dynamiquement
    let champsHTML = `<h4 style="color: #6a1b9a; margin: 0 0 15px 0;">⚛️ Noms des Éléments (${ntyp})</h4>`;
    champsHTML += `<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 10px; margin-bottom: 20px;">`;
    
    for (let i = 1; i <= ntyp; i++) {
        champsHTML += `
            <div>
                <label style="font-weight: bold; color: #6a1b9a; display: block; margin-bottom: 5px;">Élément ${i}:</label>
                <input type="text" id="element_${i}" placeholder="Ex: Ba" 
                       onchange="genererAtomicSpecies()" oninput="genererAtomicSpecies()"
                       style="width: 100%; padding: 8px; border: 1px solid #9c27b0; border-radius: 5px;">
            </div>
        `;
    }
    
    champsHTML += `</div>`;
    
    // Ajouter la section ATOMIC_SPECIES - TOUJOURS VISIBLE dans la zone principale
    champsHTML += `
        <div style="margin-top: 20px; padding: 20px; background: #f8f9fa; border-radius: 10px; border: 2px solid #9c27b0;">
            <h3 style="color: #6a1b9a; margin: 0 0 15px 0; font-size: 1.2em;">
                📝 ATOMIC_SPECIES (Format QE)
            </h3>
            
            <div id="atomic_species_format" style="
                font-family: 'Courier New', Consolas, monospace;
                font-size: 1em;
                line-height: 1.8;
                background: white;
                padding: 15px;
                border-radius: 8px;
                border: 2px solid #ddd;
                color: #000;
                overflow-x: auto;
                white-space: pre;
                min-height: 100px;
                box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);
            "><span style="color: #999;">En attente des éléments...</span></div>
            
            <div style="margin-top: 15px; display: flex; gap: 10px; align-items: center;">
                <button id="copy_button" onclick="copierAtomicSpecies()" style="
                    padding: 12px 25px;
                    background: #9c27b0;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    cursor: pointer;
                    font-weight: bold;
                    font-size: 1em;
                    box-shadow: 0 2px 5px rgba(156, 39, 176, 0.3);
                    transition: all 0.3s;
                " onmouseover="this.style.background='#7b1fa2'" onmouseout="this.style.background='#9c27b0'">
                    📋 Copier ATOMIC_SPECIES
                </button>
                <span id="copy_status" style="color: #4caf50; font-weight: bold;"></span>
            </div>
            
            <div id="pseudos_list" style="
                margin-top: 15px;
                padding: 10px;
                background: #fff3e0;
                border-radius: 5px;
                border-left: 4px solid #ff9800;
                font-family: monospace;
                font-size: 0.9em;
                line-height: 1.6;
                color: #333;
                display: none;
            "></div>
        </div>
    `;
    
    section.innerHTML = champsHTML;
    
    console.log(`✅ ${ntyp} champs d'éléments créés dans section_elements`);
}

/**
 * Générer ATOMIC_SPECIES à partir des éléments
 * Cherche dans element_${i} OU elem_${i}
 */
function genererAtomicSpecies() {
    const ntypInput = document.getElementById('ntyp');
    const ntyp = parseInt(ntypInput?.value) || 0;
    
    console.log(`\n🔧 genererAtomicSpecies() - ntyp=${ntyp}`);
    
    // Récupérer tous les éléments
    // IMPORTANT: Chercher dans element_${i} (entrée manuelle) OU elem_${i} (selects table positions)
    const elements = [];
    for (let i = 1; i <= ntyp; i++) {
        // Chercher d'abord dans element_${i} (champs de la section des éléments)
        let value = document.getElementById(`element_${i}`)?.value.trim() || '';
        
        // Si vide, chercher dans elem_${i} (selects de la table positions)
        if (!value) {
            value = document.getElementById(`elem_${i}`)?.value.trim() || '';
            if (value) {
                console.log(`  element_${i}: VIDE → récupéré depuis elem_${i}: ${value}`);
            }
        } else {
            console.log(`  element_${i}: ${value}`);
        }
        
        if (value) {
            elements.push(value);
        }
    }
    
    console.log(`Éléments trouvés: [${elements.join(', ')}]`);
    
    const pseudosList_div = document.getElementById('pseudos_list');
    const atomicSpeciesDiv = document.getElementById('atomic_species_format');
    
    if (elements.length === 0) {
        console.warn('⚠️ Aucun élément trouvé!');
        if (atomicSpeciesDiv) {
            atomicSpeciesDiv.innerHTML = '<span style="color: #999;">En attente des éléments...</span>';
        }
        window.atomicSpeciesGlobal = '';
        return;
    }
    
    // Générer la liste des pseudo-potentiels
    let pseudosList = '';
    let atomicSpecies = '';
    let allFound = true;
    
    elements.forEach((element) => {
        const data = PSEUDOS_DATABASE[element];
        if (data) {
            pseudosList += `<div><strong>${element}</strong> ${data.mass.toFixed(3)} ${data.pseudo}</div>`;
            
            // Format QE correct: Symbol Mass Pseudopotential
            const mass = data.mass.toFixed(3);
            atomicSpecies += `${element.padEnd(2)}   ${mass.padStart(8)}  ${data.pseudo}\n`;
        } else {
            pseudosList += `<div style="color: #d32f2f;"><strong>${element}</strong> <em>(Non trouvé)</em></div>`;
            allFound = false;
        }
    });
    
    // Mise à jour DOM
    if (pseudosList_div) {
        pseudosList_div.innerHTML = pseudosList;
        
        // Ajouter le résumé
        const summary = document.createElement('div');
        summary.style.cssText = 'margin-top: 10px; padding-top: 10px; border-top: 1px solid #ff9800; color: #e65100; font-weight: bold;';
        summary.innerHTML = `✅ ${elements.length} élément(s) détecté(s)${allFound ? ' ✓' : ' ⚠️'}`;
        pseudosList_div.appendChild(summary);
        
        // ⭐ TOUJOURS AFFICHER pour que l'utilisateur vérifie avant génération
        pseudosList_div.style.display = 'block';
    }
    
    // Stocker le contenu globalement
    window.atomicSpeciesGlobal = atomicSpecies.trim();
    
    console.log('🔍 DEBUG - Vérification atomicSpeciesGlobal:');
    console.log('  Type:', typeof window.atomicSpeciesGlobal);
    console.log('  Longueur:', window.atomicSpeciesGlobal.length);
    console.log('  Contenu:');
    console.log(window.atomicSpeciesGlobal);
    console.log('  window.atomicSpeciesGlobal:', window.atomicSpeciesGlobal);
    
    // ⭐ AFFICHER ATOMIC_SPECIES dans une section visible
    if (atomicSpeciesDiv) {
        // Créer un affichage formaté et visible
        atomicSpeciesDiv.innerHTML = `
            <div style="background: #fff3e0; padding: 15px; border-radius: 8px; border-left: 4px solid #ff9800; margin-top: 15px;">
                <h4 style="color: #e65100; margin: 0 0 10px 0; font-size: 1.1em;">
                    📋 ATOMIC_SPECIES Généré (sera copié dans l'input):
                </h4>
                <pre style="background: #263238; color: #aed581; padding: 15px; border-radius: 5px; overflow-x: auto; font-family: 'Courier New', monospace; font-size: 0.95em; margin: 0;">${window.atomicSpeciesGlobal}</pre>
                <small style="color: #666; display: block; margin-top: 10px;">
                    💡 Vérifiez que les pseudopotentiels correspondent à vos éléments
                </small>
            </div>
        `;
        console.log('  ✓ Affichage VISIBLE dans atomic_species_format');
    } else {
        console.warn('  ❌ atomic_species_format NOT FOUND');
    }
    
    // AJOUTER: Vérifier les pseudos manquants
    if (typeof creerSectionPseudosMissing === 'function') {
        console.log('🔍 Vérification des pseudos manquants...');
        creerSectionPseudosMissing();
    }
}

/**
 * Copier ATOMIC_SPECIES dans le presse-papiers
 */
function copierAtomicSpecies() {
    console.log('📋 Tentative de copie. Contenu:', window.atomicSpeciesGlobal);
    
    if (!window.atomicSpeciesGlobal || window.atomicSpeciesGlobal.trim() === '') {
        alert('❌ Aucun contenu à copier.\n\nVeuillez:\n1. Entrer ntyp\n2. Entrer les noms des éléments (Ba, Ti, O...)\n3. Les pseudo-potentiels vont s\'afficher automatiquement');
        return;
    }
    
    // Récupérer le bouton
    const btn = document.getElementById('copy_button');
    
    try {
        // Essayer Clipboard API
        if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
            navigator.clipboard.writeText(window.atomicSpeciesGlobal).then(() => {
                console.log('✅ Copie réussie via Clipboard API');
                afficherSuccess(btn);
            }).catch((err) => {
                console.warn('⚠️ Clipboard API échouée:', err);
                fallbackCopy(window.atomicSpeciesGlobal, btn);
            });
        } else {
            console.warn('⚠️ Clipboard API non disponible');
            fallbackCopy(window.atomicSpeciesGlobal, btn);
        }
    } catch (err) {
        console.error('❌ Erreur:', err);
        fallbackCopy(window.atomicSpeciesGlobal, btn);
    }
}

/**
 * Afficher message de succès
 */
function afficherSuccess(btn) {
    if (!btn) return;
    
    const originalText = btn.textContent;
    btn.textContent = '✅ Copié!';
    btn.style.background = '#4caf50';
    
    // Afficher aussi dans le span de statut
    const statusSpan = document.getElementById('copy_status');
    if (statusSpan) {
        statusSpan.textContent = '✅ Copié dans le presse-papiers!';
        setTimeout(() => {
            statusSpan.textContent = '';
        }, 3000);
    }
    
    setTimeout(() => {
        btn.textContent = originalText;
        btn.style.background = '#9c27b0';
    }, 2000);
}

/**
 * Fallback: Copie manuelle
 */
function fallbackCopy(content, btn) {
    try {
        const textarea = document.createElement('textarea');
        textarea.value = content;
        textarea.style.position = 'fixed';
        textarea.style.top = '0';
        textarea.style.left = '0';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        
        textarea.focus();
        textarea.select();
        
        const success = document.execCommand('copy');
        document.body.removeChild(textarea);
        
        if (success) {
            console.log('✅ Copie réussie via fallback');
            afficherSuccess(btn);
            alert('✅ ATOMIC_SPECIES copié avec succès!');
        } else {
            alert('❌ Erreur: Impossible de copier');
        }
    } catch (err) {
        console.error('❌ Erreur fallback:', err);
        alert('❌ Erreur lors de la copie: ' + err.message);
    }
}

/**
 * Initialiser la section des noms d'éléments
 */
function initialiserNomElements() {
    console.log('🔧 Initialisation noms d\'éléments...');
    
    setTimeout(() => {
        creerSectionNomElements();
        console.log('✅ Noms d\'éléments initialisés');
    }, 300);
}

// Exécuter au chargement
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialiserNomElements);
} else {
    initialiserNomElements();
}

console.log('✅ Script noms éléments et pseudo-potentiels (V2) chargé');

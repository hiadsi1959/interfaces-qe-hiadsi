# Génération des pseudopotentiels — Quantum ESPRESSO

Interface web **autonome** : tableau périodique, **ld1.x**, **APE**, **ATOMPAW**, **ONCVPSP**, bibliothèques PSLibrary / PseudoDojo / SSSP.

Une seule API Flask (`api_pseudos_standalone.py`) sert l’interface et tous les calculs sur le port **5008**. Ne pas ouvrir `index.html` en `file://`.

---

## Fichier unique installable (recommandé pour un autre PC)

Au lieu de copier tout le dossier du projet, vous pouvez produire **un seul fichier exécutable** (~220 Ko) contenant l’interface et l’API. Sur un autre PC, ce fichier s’installe, **s’auto-configure** selon la machine et démarre l’application — l’équivalent pratique d’un « `.exe` » sous Linux.

### Construire l’installateur (PC de développement, une fois)

```bash
cd generation_pseudos
chmod +x build_installer.sh
./build_installer.sh
```

Résultat : **`dist/generation_pseudos`** — un seul fichier à copier (clé USB, e-mail, `scp`, etc.).

Options de build :

```bash
./build_installer.sh --output ~/Bureau/generation_pseudos   # chemin de sortie personnalisé
./build_installer.sh --help
```

### Utiliser sur un autre PC

```bash
chmod +x generation_pseudos
./generation_pseudos
```

Installation permanente (commande disponible partout) :

```bash
./generation_pseudos --install
generation_pseudos          # depuis n’importe quel terminal
```

### Ce que fait le programme automatiquement

| Étape | Action |
|-------|--------|
| **1. Installation** | Extraction dans `~/.local/share/generation_pseudos/app/` |
| **2. Auto-configuration** | Détection de Quantum ESPRESSO, ONCVPSP, APE, ATOMPAW → écriture de `api_config.json` |
| **3. Démarrage** | Lancement de l’API (port **5008**) + ouverture du navigateur sur http://127.0.0.1:5008/ |

Au **premier lancement sur chaque machine**, les chemins sont détectés selon ce qui est installé sur ce PC. Si vous changez de machine ou déplacez QE, relancez avec `--reconfig`.

### Ce qui est inclus dans le fichier unique

| Inclus | Détail |
|--------|--------|
| Interface web | `index.html`, tous les `script_*.js`, assistant guidé |
| API Flask | `api_pseudos_standalone.py` et modules Python associés |
| Gabarits | Entrées ONCV (`.dat`), templates 3d, modèles APE/ATOMPAW |
| Scripts | Configuration, démarrage, arrêt |
| Dossiers de sortie | Création de `pseudos-ld1/`, `pseudos-APE/`, `pseudos-atompaw/`, `pseudos-oncvpsp/` |

### Ce qui reste à installer sur chaque PC (hors du fichier)

| Composant | Obligatoire | Rôle |
|-----------|-------------|------|
| **Python 3** + `flask`, `flask-cors` | oui | Installés automatiquement si absents |
| **Quantum ESPRESSO** (`pw.x`, `ld1.x`) | oui pour ld1.x | Génération native QE — **non embarqué** (plusieurs centaines de Mo) |
| **ONCVPSP** (`oncvpsp.x`) | optionnel | Onglet ONCVPSP |
| **APE** / **ATOMPAW** | optionnel | Onglets correspondants |
| **Bibliothèques UPF** (`pseudos/`, plusieurs Go) | optionnel | Téléchargement via l’onglet *Autres bases* ou `./TELECHARGER_BASES.sh` |

Le programme **ne copie pas** QE ni les générateurs dans le fichier unique : il **détecte leurs chemins** déjà présents sur la machine (PATH, emplacements usuels, `~/oncvpsp/`, etc.).

### Comparaison avec un `.exe` Windows

Sous Linux, on ne peut pas raisonnablement mettre Quantum ESPRESSO **et** toute la bibliothèque de pseudos **dans** un seul binaire sans atteindre plusieurs gigaoctets. Le fichier `generation_pseudos` regroupe :

- l’**interface complète** ;
- l’**API** ;
- la **configuration automatique** des chemins ;
- le **démarrage** et l’ouverture du navigateur.

Les outils scientifiques externes (QE, ONCV, APE, ATOMPAW) restent installés séparément sur chaque poste, comme pour la plupart des logiciels de calcul scientifique.

### Commandes de l’installateur

```bash
./generation_pseudos                  # installer (si besoin), configurer, démarrer
./generation_pseudos --install        # copier dans ~/.local/bin/generation_pseudos
./generation_pseudos --reconfig       # reconfigurer les chemins sur ce PC
./generation_pseudos --reinstall      # ré-extraire l’application
./generation_pseudos --uninstall      # supprimer ~/.local/share/generation_pseudos/
./generation_pseudos --help           # aide
```

### Chemins après installation (fichier unique)

| Élément | Emplacement |
|---------|-------------|
| Application | `~/.local/share/generation_pseudos/app/` |
| Configuration | `~/.local/share/generation_pseudos/app/api_config.json` |
| UPF générés | `~/.local/share/generation_pseudos/app/pseudos-ld1/` (etc.) |
| Bibliothèque pw.x | `~/.local/share/generation_pseudos/app/pseudos/` |
| Commande globale | `~/.local/bin/generation_pseudos` (après `--install`) |
| Interface web | http://127.0.0.1:5008/ |
| Logs | `~/.local/share/generation_pseudos/app/logs/api_pseudos_standalone.log` |

Variable pour changer le dossier d’installation :

```bash
export GEN_PSEUDOS_INSTALL="$HOME/.local/share/generation_pseudos"
./generation_pseudos
```

---

## Lancement depuis le dossier du projet (PC de développement)

Si vous travaillez directement dans le dossier `generation_pseudos` (sans fichier unique) :

### Option A — Lanceur intégré au dossier

```bash
chmod +x GenerationPseudos ArreterGenerationPseudos
./GenerationPseudos
```

- Premier lancement sur ce PC : configuration automatique + démarrage
- Lancements suivants : démarrage direct
- Raccourci bureau : `bash scripts/install_lanceur_bureau.sh`

```bash
./GenerationPseudos --reconfig      # reconfigurer les chemins
./GenerationPseudos --config-only     # config sans démarrer
./ArreterGenerationPseudos            # arrêter l’API
```

### Option B — Copie du dossier (deux scripts)

Sur le **nouveau PC**, après extraction ou copie du dossier :

```bash
chmod +x configure.sh DEMARRER.sh
./configure.sh    # une fois : chemins QE, ONCV, APE, ATOMPAW
./DEMARRER.sh     # à chaque utilisation → http://127.0.0.1:5008/
```

Variantes de `configure.sh` :

```bash
./configure.sh --qe ~/q-e-qe-7.5/bin -y   # chemins explicites, sans questions
./configure.sh --check-only               # diagnostic sans modification
./configure.sh --start                    # configure et démarre (équivalent configure + DEMARRER)
```

`config_pc.sh` reste disponible comme alias de `configure.sh`.

Guide : **[docs/TRANSFERT_AUTRE_PC.md](docs/TRANSFERT_AUTRE_PC.md)**

```bash
./TRANSFERER_VERS_AUTRE_PC.sh --leger --dest user@IP_AUTRE_PC -y
# ou archive seule :
./emballer.sh
```

Guide installation : **[docs/INSTALLATION_AUTRE_PC.md](docs/INSTALLATION_AUTRE_PC.md)**

---

## Dossiers de sortie (4 générateurs)

Chaque outil enregistre ses UPF conformes QE dans son propre dossier :

| Générateur | Dossier |
|------------|---------|
| **ld1.x** | `pseudos-ld1/` |
| **APE** | `pseudos-APE/` |
| **ATOMPAW** | `pseudos-atompaw/` |
| **ONCVPSP** | `pseudos-oncvpsp/` |

Les UPF utilisables par `pw.x` sont aussi copiés dans `pseudos/`.  
Téléchargements catalogue : `pseudos-telecharges/`.  
Le dossier `pseudos_generes/` est **obsolète** (rétrocompatibilité uniquement).

---

## Vérification rapide

```bash
./configure.sh --check-only
./generation_pseudos --reconfig --config-only   # si installé via fichier unique
python3 tests/verifier_api_generale.py
./scripts/verifier_chemins_ui.sh
```

---

## Arborescence (essentiel)

| Emplacement | Rôle |
|-------------|------|
| **Racine** | `index.html`, `script_*.js`, `api_pseudos_standalone.py`, `api_config.json` |
| `dist/generation_pseudos` | **Fichier unique** à distribuer sur un autre PC |
| `scripts/` | `build_installer.sh`, `DEMARRER.sh`, `configure.sh`, nettoyage |
| `pseudos-*/` | Sorties UPF par générateur |
| `pseudos/` | Bibliothèque pour `pw.x` |
| `tests/` | `verifier_api_generale.py` |
| `docs/` | Installation, structure, chemins interface |

Détail : **[docs/STRUCTURE.md](docs/STRUCTURE.md)** — chemins UI : **[docs/CHEMINS_INTERFACE.md](docs/CHEMINS_INTERFACE.md)**

---

## Configuration manuelle (`api_config.json`)

```json
{
  "qe_bin": "/home/user/q-e-qe-7.5/bin",
  "pseudos_dir": "/home/user/generation_pseudos/pseudos",
  "oncvpsp_bin": "/home/user/oncvpsp/build/bin/oncvpsp.x",
  "ape_bin": "/home/user/generation_pseudos/third_party/ape/bin/ape",
  "atompaw_bin": "/home/user/generation_pseudos/third_party/atompaw/bin/atompaw",
  "oncv_default_target": "qe"
}
```

Variables utiles : `QE_BIN`, `GEN_PORT`, `ONCVPSP_BIN`, `GEN_PSEUDOS_INSTALL`, `SKIP_LEGACY_API=1`.

---

## Scripts (liste utile uniquement)

### À la racine — usage courant

| Script | Rôle |
|--------|------|
| **`generation_pseudos`** | Fichier unique (après `./build_installer.sh`) — install + config + démarrage |
| **`GenerationPseudos`** | Lanceur dans le dossier projet |
| **`build_installer.sh`** | Construit `dist/generation_pseudos` |
| **`configure.sh`** | Configure ce PC (`api_config.json`, dossiers, binaires QE/ONCV/…) |
| **`DEMARRER.sh`** | Démarre l’API (port 5008) |
| **`ARRETER.sh`** | Arrête l’API |
| **`verifier_installation.sh`** | Diagnostic complet sur ce PC |
| **`TELECHARGER_BASES.sh`** | Télécharge les bibliothèques UPF |
| **`emballer.sh`** | Compacter le projet en `dist/*.tar.gz` (défaut : mode léger) |
| **`TRANSFERER_VERS_AUTRE_PC.sh`** | Archive + envoi réseau vers un autre PC |

### Dans `scripts/` — maintenance

| Script | Rôle |
|--------|------|
| `scripts/RELANCER.sh` | Redémarre l’API si version obsolète |
| `scripts/emballer.sh` | Compacter en `dist/*.tar.gz` |
| `scripts/TRANSFERT_AUTRE_PC.sh` | Alias (mode complet par défaut) |
| `scripts/install_ape_atompaw.sh` | Compile APE / ATOMPAW dans `third_party/` |
| `scripts/install_bibliotheques_pseudos.sh` | Installe l’arborescence bibliothèques |
| `scripts/telecharger_lanthanides_nc.sh` | Gabarits lanthanides |
| `scripts/nettoyer_projet.sh` | Nettoie `_work/`, caches |
| `scripts/install_lanceur_bureau.sh` | Raccourci bureau |

Scripts supprimés (doublons) : `DEPLOYER_AUTRE_PC.sh`, `CONFIGURER.sh`, `INSTALLER.sh`, `EXPORTER_MINIMAL.sh` — remplacés par `configure.sh`, `GenerationPseudos` ou `build_installer.sh`. `config_pc.sh` = alias de `configure.sh`.

---

## Dépannage sur un autre PC

| Problème | Cause fréquente | Action |
|----------|-----------------|--------|
| « API hors ligne » / port 5007 | Ancienne config navigateur | `./configure.sh` puis `./DEMARRER.sh` et **Ctrl+F5** |
| Page blanche / pas de tableau | Ouverture en `file://` | Utiliser http://127.0.0.1:5008/ |
| Chemins `/home/hiadsi/...` | localStorage ou ancien profil | Ctrl+F5 ; `./configure.sh` |
| Flask / pip refusé (Ubuntu 24+) | PEP 668 | `./configure.sh` (corrige automatiquement) |
| ld1.x introuvable | QE non installé sur ce PC | Installer QE puis `./configure.sh --qe /chemin/bin` |
| APE / ATOMPAW absents | Non compilés | `bash scripts/install_ape_atompaw.sh` |

---

## Téléchargement des bibliothèques externes

```bash
./TELECHARGER_BASES.sh --quick
./TELECHARGER_BASES.sh --all
```

Ou via l’onglet **Autres bases** dans l’interface web.

---

## Nettoyage local

```bash
./scripts/nettoyer_projet.sh
./scripts/nettoyer_projet.sh --work-only
```

---

## Architecture

```
Navigateur → http://127.0.0.1:5008/
        ↕
api_pseudos_standalone.py (Flask + fichiers statiques)
        ↕
QE (ld1.x) · ONCVPSP · APE · ATOMPAW  (installés sur la machine)
        ↓
pseudos-ld1/ · pseudos-APE/ · pseudos-atompaw/ · pseudos-oncvpsp/
```

---

## Prérequis

- Python 3 + `flask`, `flask-cors` (installés auto si besoin)
- Quantum ESPRESSO (`pw.x`, `ld1.x` pour l’onglet ld1)
- ONCVPSP / APE / ATOMPAW : optionnels selon l’onglet

---

## Dépannage

| Problème | Action |
|----------|--------|
| Premier lancement sur nouveau PC | `./configure.sh` puis `./DEMARRER.sh` (ou `./generation_pseudos`) |
| Chemins incorrects / port 5007 | `./configure.sh` puis **Ctrl+F5** dans le navigateur |
| API hors ligne | `./DEMARRER.sh` — `lsof -i:5008` |
| CSS / tableau absent | URL `http://127.0.0.1:5008/`, pas `file://` |
| `ld1.x` introuvable | `./configure.sh --qe /chemin/qe/bin` |
| ONCV / APE / ATOMPAW absents | Installer binaire, puis `--reconfig` |
| Désinstaller le fichier unique | `./generation_pseudos --uninstall` |
| Diagnostic complet | `./verifier_installation.sh` |

Logs (dossier projet) : `logs/api_pseudos_standalone.log`  
Logs (fichier unique) : `~/.local/share/generation_pseudos/app/logs/api_pseudos_standalone.log`

---

Prof. S. Hiadsi — LMESM, USTO-MB — said.hiadsi@univ-usto.dz

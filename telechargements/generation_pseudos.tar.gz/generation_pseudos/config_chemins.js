// Configuration des chemins — interface autonome generation_pseudos (port 5008)
(function() {
    'use strict';

    window.QE_API_PORT = 5008;
    window.QE_API_URL = 'http://127.0.0.1:5008';
    if (typeof window.API_PSEUDOS_ORIGIN === 'undefined') {
        window.API_PSEUDOS_ORIGIN = 'http://127.0.0.1:5008';
    }
    if (typeof window.GENERATION_PSEUDOS_API_ORIGIN === 'undefined') {
        window.GENERATION_PSEUDOS_API_ORIGIN = window.API_PSEUDOS_ORIGIN;
    }

    if (!window.QE_CONFIG || !window.QE_CONFIG.QE_BIN_DIR) {
        window.QE_CONFIG = Object.assign(window.QE_CONFIG || {}, {
            WORK_DIR: '',
            INPUTS_DIR: '',
            OUTPUTS_DIR: '',
            PSEUDO_DIR: '',
            CIF_DIR: '',
            QE_BIN_DIR: '',
            AUTO_REFRESH_INTERVAL: 3000,
            AUTO_START_API: false
        });
    }

    window.detecterCheminsAuto = async function() {
        var base = (typeof getApiPseudosGenerationBase === 'function')
            ? getApiPseudosGenerationBase()
            : (window.API_PSEUDOS_ORIGIN || 'http://127.0.0.1:5008');
        try {
            var response = await fetch(base.replace(/\/+$/, '') + '/api/chemins', { cache: 'no-store' });
            if (response.ok) {
                var data = await response.json();
                if (data.qe_bin) window.QE_CONFIG.QE_BIN_DIR = data.qe_bin;
                if (data.pseudos) window.QE_CONFIG.PSEUDO_DIR = data.pseudos;
                console.log('✅ Chemins chargés depuis l’API:', data.qe_bin || '(QE à configurer)');
                return true;
            }
        } catch (error) {
            console.warn('⚠️ API non joignable — lancez ./DEMARRER.sh ou ./GenerationPseudos');
        }
        return false;
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            window.detecterCheminsAuto();
        });
    } else {
        window.detecterCheminsAuto();
    }
})();

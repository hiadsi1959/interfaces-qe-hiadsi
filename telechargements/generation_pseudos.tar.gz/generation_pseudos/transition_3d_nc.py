# -*- coding: utf-8 -*-
"""
Gabarits ONCVPSP (.dat) pour métaux de transition 3d (Sc–Zn).

ONCVPSP ne fournit dans tests/data que Ti (22) et Cu (29) ; pour Mn, Fe, etc.
on génère une entrée au format 22_Ti.dat / 29_Cu.dat (cœur 1s–2p + valence 3s–4s).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

try:
    from pseudo_auto_inputs import _TRANSITION_3D, normalize_symbol, atomic_number
    from pseudo_auto_inputs import _generation_valence_context
except ImportError:
    _TRANSITION_3D = frozenset(
        {"Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn"}
    )

    def normalize_symbol(sym: str) -> str:
        s = (sym or "").strip()
        return s.upper() if len(s) == 1 else s[0].upper() + s[1:].lower()

    def atomic_number(sym: str) -> int:
        return 0

    def _generation_valence_context(sym, semicore, f_treatment):
        return {"valence": {}}

_ONCV_IEXC = {
    "lda_pw": 3,
    "lda_pz": 3,
    "gga_pbe": 3,
    "gga_pbesol": 3,
    "pbe": 3,
    "pbesol": 3,
}

# Cœur minimal ONCV (comme 22_Ti.dat) : 1s + 2s + 2p
_CORE_MINI: tuple[tuple[int, int, float], ...] = (
    (1, 0, 2.0),
    (2, 0, 2.0),
    (2, 1, 6.0),
)

# Éléments déjà couverts par tests/data officiels
_OFFICIAL_ONCV_3D = frozenset({"Ti", "Cu"})

TRANSITION_3D_SYMBOLS: tuple[str, ...] = (
    "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
)


def is_transition_3d(sym: str) -> bool:
    s = normalize_symbol(sym)
    return s in _TRANSITION_3D


def needs_generated_dat(sym: str) -> bool:
    """True si pas de .dat officiel dans oncvpsp/tests/data (ex. Mn, Fe)."""
    s = normalize_symbol(sym)
    return s in _TRANSITION_3D and s not in _OFFICIAL_ONCV_3D


def get_guide(sym: str) -> dict[str, Any]:
    sym = normalize_symbol(sym)
    return {
        "element": sym,
        "is_transition_3d": True,
        "has_official_dat": sym in _OFFICIAL_ONCV_3D,
        "valence_note": "Valence type Ti/Cu : 3s, 3p, 3d, 4s après cœur 1s–2p",
        "oncv_recommended": "moderee",
        "message": (
            f"{sym} : gabarit ONCV généré localement (format tests/data Ti/Cu). "
            "Valider ghost states / transfert ; sinon PseudoDojo ou ATOMPAW."
        ),
        "pseudodojo_url": "https://www.pseudo-dojo.org/",
    }


def _valence_lines(sym: str) -> list[tuple[int, int, float]]:
    ctx = _generation_valence_context(sym, semicore=False, f_treatment=None)
    val = ctx.get("valence") or {}
    core_set = {(n, l) for n, l, _ in _CORE_MINI}
    lines = [
        (n, l, float(e))
        for (n, l), e in sorted(val.items())
        if e > 0 and (n, l) not in core_set
    ]
    if not lines:
        Z = atomic_number(sym)
        import pseudo_auto_inputs as pai

        total = pai.neutral_configuration(Z)
        core_occ = pai.neutral_configuration(10)  # Ne
        for n, l, o in _CORE_MINI:
            core_occ[(n, l)] = int(o)
        for (n, l), occ in sorted(total.items()):
            rem = occ - core_occ.get((n, l), 0)
            if rem > 0 and (n, l) not in core_set:
                lines.append((n, l, float(rem)))
    return lines


def _rc_for_l(sym: str, l: int, scale: float = 1.0) -> float:
    try:
        from elements_physics_db import get_rc_for_orbital

        return get_rc_for_orbital(sym, max(3, 4), l, scale)
    except ImportError:
        defaults = {0: 1.85, 1: 2.05, 2: 2.05}
        return round(defaults.get(l, 2.0) * scale, 2)


def generate_oncv_dat(
    sym: str,
    xc: str = "gga_pbe",
    rc_scale: float = 1.0,
    psfile: str = "both",
) -> str:
    """
    Entrée ONCV NC pour un métal 3d (sauf Ti/Cu déjà officiels).
    psfile=both → UPF + psp8 pour Quantum ESPRESSO.
    """
    sym = normalize_symbol(sym)
    if not is_transition_3d(sym):
        raise ValueError(f"{sym} n'est pas un métal 3d (Sc–Zn).")
    if sym in _OFFICIAL_ONCV_3D:
        raise ValueError(f"{sym} : utiliser le fichier tests/data officiel.")

    Z = atomic_number(sym)
    iexc = _ONCV_IEXC.get((xc or "gga_pbe").lower(), 3)
    val_lines = _valence_lines(sym)
    core_lines = list(_CORE_MINI)
    nc = len(core_lines)
    nv = len(val_lines)
    lmax = max((l for _, l, _ in val_lines), default=2)
    lmax = max(lmax, 2)

    rc_s = _rc_for_l(sym, 0, rc_scale)
    rc_p = _rc_for_l(sym, 1, rc_scale)
    rc_d = _rc_for_l(sym, 2, rc_scale)
    # ONCV test_data : chaque rc(l) doit être >= rc(lloc) (affiché à 0.1 près).
    rc_local = round(min(rc_s, rc_p, rc_d), 1)
    rc_s = max(round(rc_s, 2), rc_local)
    rc_p = max(round(rc_p, 2), rc_local)
    rc_d = max(round(rc_d, 2), rc_local)

    rc_channels = [
        (0, rc_s, 0.00, 5, 8, 6.00),
        (1, rc_p, 0.00, 5, 8, 7.00),
        (2, rc_d, 0.00, 5, 9, 8.00),
    ]
    rc_lines = [
        f"    {l}    {rc:.2f}   {ep:5.2f}    {ncon}    {nbas}   {qcut:.2f}"
        for l, rc, ep, ncon, nbas, qcut in rc_channels
    ]

    proj = ["    0    2    1.50", "    1    2    1.50", "    2    2    1.00"]

    ps = (psfile or "both").strip().lower()
    if ps not in ("upf", "both", "psp8"):
        ps = "both"

    atsym = sym.lower()[:2]
    val_str = " ".join(f"{n}{'spdf'[l]}{int(o)}" for n, l, o in val_lines)

    header = (
        "# ONCVPSP — métal 3d NC (generation_pseudos/transition_3d_nc.py)\n"
        f"# Élément {sym} Z={Z} — valence {val_str}\n"
        f"# Cible QE : psfile={ps} — modèle type 22_Ti.dat / 29_Cu.dat\n"
        "#\n"
        "# ATOM AND REFERENCE CONFIGURATION\n"
        "# atsym, z, nc, nv, iexc   psfile\n"
        f"  {atsym}  {float(Z):.1f}   {nc}   {nv}   {iexc}   {ps}\n"
        "#\n"
        "# n, l, f  (nc+nv lines)\n"
    )
    elec = [f"    {n}    {l}    {occ:.1f}" for n, l, occ in core_lines + val_lines]
    opt = (
        "#\n# PSEUDOPOTENTIAL AND OPTIMIZATION\n# lmax\n"
        f"    {lmax}\n#\n# l, rc, ep, ncon, nbas, qcut  (lmax+1 lines, l's must be in order)\n"
        + "\n".join(rc_lines)
        + "\n#\n# LOCAL POTENTIAL\n# lloc, lpopt, rc(5), dvloc0\n"
        f"    4    5    {rc_local:.1f}    0.0\n#\n"
        "# VANDERBILT-KLEINMAN-BYLANDER PROJECTORs\n# l, nproj, debl  (lmax+1 lines, l's in order)\n"
        + "\n".join(proj)
        + "\n#\n# MODEL CORE CHARGE\n# icmod, fcfact\n    0    0.0\n#\n"
        "# LOG DERIVATIVE ANALYSIS\n# epsh1, epsh2, depsh\n   -3.0  2.0  0.02\n#\n"
        "# OUTPUT GRID\n# rlmax, drl\n    5.0  0.01\n#\n# TEST CONFIGURATIONS\n# ncnf\n    0\n"
    )
    return header + "\n".join(elec) + "\n" + opt


def ensure_cached_templates(project_root: str | Path) -> list[str]:
    """Écrit oncv_templates_3d/<Sym>.dat pour Sc–Zn (sauf Ti, Cu officiels)."""
    root = Path(project_root).expanduser().resolve()
    cache = root / "oncv_templates_3d"
    cache.mkdir(parents=True, exist_ok=True)
    written: list[str] = []
    for sym in TRANSITION_3D_SYMBOLS:
        if not needs_generated_dat(sym):
            continue
        path = cache / f"{sym}.dat"
        if path.is_file() and path.stat().st_size > 200:
            continue
        try:
            path.write_text(generate_oncv_dat(sym), encoding="utf-8")
            written.append(sym)
        except Exception:
            pass
    return written

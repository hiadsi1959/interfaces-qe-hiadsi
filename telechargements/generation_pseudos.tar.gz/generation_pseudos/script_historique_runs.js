/**
 * Historique des runs — GET /api/pseudos/history + export .zip
 */
(function () {
    'use strict';

    function apiBase() {
        if (typeof window.getApiPseudosBase === 'function') {
            try { return String(window.getApiPseudosBase()).replace(/\/$/, ''); } catch (e) { /* ignore */ }
        }
        return String(window.API_PSEUDOS_ORIGIN || 'http://127.0.0.1:5008').replace(/\/$/, '');
    }

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function injectCss() {
        if (document.getElementById('gp-hist-css')) return;
        var st = document.createElement('style');
        st.id = 'gp-hist-css';
        st.textContent =
            '#gp_hist_overlay{position:fixed;inset:0;background:rgba(15,23,42,.88);z-index:100050;display:flex;align-items:center;justify-content:center;padding:16px;}' +
            '#gp_hist_box{background:#0f172a;color:#e2e8f0;width:min(960px,96vw);max-height:88vh;overflow:auto;border-radius:12px;border:1px solid #334155;padding:18px 20px;font-family:system-ui,sans-serif;}' +
            '#gp_hist_box h2{margin:0 0 12px;color:#7dd3fc;font-size:1.15rem;}' +
            '#gp_hist_filters{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;align-items:center;}' +
            '#gp_hist_filters input,#gp_hist_filters select{padding:6px 10px;border-radius:8px;border:1px solid #475569;background:#1e293b;color:#f8fafc;}' +
            '#gp_hist_table{width:100%;border-collapse:collapse;font-size:0.86rem;}' +
            '#gp_hist_table th,#gp_hist_table td{padding:8px 10px;border-bottom:1px solid #334155;text-align:left;vertical-align:top;}' +
            '#gp_hist_table th{color:#94a3b8;font-weight:600;position:sticky;top:0;background:#0f172a;}' +
            '#gp_hist_table code{color:#a5f3fc;font-size:0.8rem;}' +
            '.gp-hist-badge{display:inline-block;padding:2px 8px;border-radius:999px;font-size:0.75rem;font-weight:600;}' +
            '.gp-hist-upf{background:#14532d;color:#bbf7d0;}' +
            '.gp-hist-log{background:#713f12;color:#fde68a;}' +
            '.gp-hist-empty{background:#3f3f46;color:#d4d4d8;}' +
            '#gp_hist_actions{display:flex;gap:8px;margin-top:14px;flex-wrap:wrap;}' +
            '#gp_hist_actions button,.gp-hist-btn{padding:6px 10px;border-radius:8px;border:none;cursor:pointer;font-weight:600;font-size:0.78rem;}' +
            '.gp-hist-primary{background:#0e7490;color:#fff;}' +
            '.gp-hist-ghost{background:#334155;color:#e2e8f0;}';
        document.head.appendChild(st);
    }

    function statusBadge(st) {
        if (st === 'upf') return '<span class="gp-hist-badge gp-hist-upf">UPF</span>';
        if (st === 'log_only') return '<span class="gp-hist-badge gp-hist-log">log</span>';
        return '<span class="gp-hist-badge gp-hist-empty">vide</span>';
    }

    async function fetchHistory(element, generator) {
        var q = new URLSearchParams({ limit: '80' });
        if (element) q.set('element', element);
        if (generator) q.set('generator', generator);
        var r = await fetch(apiBase() + '/api/pseudos/history?' + q.toString(), { cache: 'no-store' });
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
    }

    function exportUrl(runDir) {
        return apiBase() + '/api/pseudos/export_run?run_dir=' + encodeURIComponent(runDir);
    }

    function renderRows(entries) {
        if (!entries || !entries.length) {
            return '<tr><td colspan="5" style="color:#94a3b8;">Aucun run trouvé. Générez un pseudo puis rouvrez l’historique.</td></tr>';
        }
        return entries.map(function (e) {
            var upf = (e.upf_files || []).join(', ') || '—';
            var dir = e.run_dir || '';
            var upfPath = (e.upf_files && e.upf_files[0] && dir)
                ? (dir.replace(/\/+$/, '') + '/' + e.upf_files[0]) : '';
            return '<tr>' +
                '<td><strong>' + esc(e.element || '?') + '</strong></td>' +
                '<td>' + esc(e.generator || '') + '</td>' +
                '<td>' + esc(e.timestamp || e.time || '') + '</td>' +
                '<td>' + statusBadge(e.status) + ' <code>' + esc(upf) + '</code></td>' +
                '<td style="white-space:nowrap;">' +
                '<button type="button" class="gp-hist-btn gp-hist-ghost" data-copy="' + esc(dir) + '">Copier</button> ' +
                '<a class="gp-hist-btn gp-hist-primary" style="display:inline-block;text-decoration:none;" href="' +
                esc(exportUrl(dir)) + '" download>ZIP</a> ' +
                (upfPath
                    ? '<button type="button" class="gp-hist-btn gp-hist-ghost" data-cmp="' + esc(upfPath) + '">Comparer</button>'
                    : '') +
                '</td></tr>';
        }).join('');
    }

    window.openRunsHistory = async function () {
        injectCss();
        var old = document.getElementById('gp_hist_overlay');
        if (old) old.remove();

        var o = document.createElement('div');
        o.id = 'gp_hist_overlay';
        o.innerHTML =
            '<div id="gp_hist_box">' +
            '<h2>Historique des générations</h2>' +
            '<div id="gp_hist_filters">' +
            '<input type="text" id="gp_hist_el" placeholder="Élément (ex. Si)" style="width:110px;" />' +
            '<select id="gp_hist_gen">' +
            '<option value="">Tous générateurs</option>' +
            '<option value="ld1">ld1</option>' +
            '<option value="ape">APE</option>' +
            '<option value="atompaw">ATOMPAW</option>' +
            '<option value="oncvpsp">ONCVPSP</option>' +
            '</select>' +
            '<button type="button" class="gp-hist-primary" id="gp_hist_refresh">Actualiser</button>' +
            '</div>' +
            '<div id="gp_hist_status" style="color:#94a3b8;font-size:0.85rem;margin-bottom:8px;">Chargement…</div>' +
            '<table id="gp_hist_table"><thead><tr>' +
            '<th>Élément</th><th>Générateur</th><th>Horodatage</th><th>Statut / UPF</th><th>Actions</th>' +
            '</tr></thead><tbody id="gp_hist_tbody"></tbody></table>' +
            '<div id="gp_hist_actions">' +
            '<button type="button" class="gp-hist-ghost" id="gp_hist_close">Fermer</button>' +
            '</div></div>';
        document.body.appendChild(o);

        async function reload() {
            var el = (document.getElementById('gp_hist_el') || {}).value || '';
            var gen = (document.getElementById('gp_hist_gen') || {}).value || '';
            var st = document.getElementById('gp_hist_status');
            var tb = document.getElementById('gp_hist_tbody');
            st.textContent = 'Chargement…';
            try {
                var data = await fetchHistory(el.trim(), gen);
                tb.innerHTML = renderRows(data.history || []);
                st.textContent = (data.returned || 0) + ' run(s) affiché(s)' +
                    (data.total > data.returned ? ' / ' + data.total + ' au total' : '');
                tb.querySelectorAll('[data-copy]').forEach(function (btn) {
                    btn.onclick = function () {
                        var p = btn.getAttribute('data-copy') || '';
                        if (navigator.clipboard && p) {
                            navigator.clipboard.writeText(p).then(function () {
                                btn.textContent = 'OK';
                                setTimeout(function () { btn.textContent = 'Copier'; }, 1000);
                            });
                        }
                    };
                });
                tb.querySelectorAll('[data-cmp]').forEach(function (btn) {
                    btn.onclick = function () {
                        var p = btn.getAttribute('data-cmp') || '';
                        if (typeof window.openUpfCompare === 'function') {
                            window.openUpfCompare(p, '');
                        }
                    };
                });
            } catch (err) {
                st.textContent = 'Erreur : ' + (err.message || err) + ' — API démarrée ? ./DEMARRER.sh';
                tb.innerHTML = '';
            }
        }

        document.getElementById('gp_hist_refresh').onclick = reload;
        document.getElementById('gp_hist_close').onclick = function () { o.remove(); };
        o.addEventListener('click', function (ev) { if (ev.target === o) o.remove(); });
        reload();
    };
})();

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Vérifie les 4 générateurs pour un élément via l'API live."""
from __future__ import annotations

import argparse
import json
import sys
import urllib.request
from pathlib import Path

API = "http://127.0.0.1:5008"
TIMEOUT = 360
ROOT = Path(__file__).resolve().parent.parent

LD1_INPUTS = {
    "Si": """ &input
    title='Si',
    zed=14.0,
    rel=0,
    config='[Ne] 3s2 3p2',
    iswitch=3,
    dft='PBE'
 /
 &inputp
   pseudotype=1,
   file_pseudopw='Si.pbe-nc.UPF',
   author='test_si',
   lloc=-1,
   rcloc=1.8,
   new_core_ps=.true.,
   rho0=0.001,
   tm=.true.
 /
 3
 3  0  2  0.00  0.00  1.8  1.8  0.0
 3  1  2  0.00  0.00  1.8  1.8  0.0
 3  2  0  0.00  0.00  1.8  1.8  0.0
""",
    "Fe": """ &input
    title='Fe',
    zed=26.0,
    rel=1,
    config='[Ar] 3d6 4s2',
    iswitch=3,
    dft='PBE'
 /
 &inputp
   pseudotype=2,
   file_pseudopw='Fe.pbe-us.UPF',
   author='test_fe',
   lloc=-1,
   rcloc=2.2,
   new_core_ps=.true.,
   tm=.true.
 /
 4
 3  2  6  0.00  0.00  2.0  2.0  0.0
 4  0  2  0.00  0.00  2.2  2.2  0.0
 3  1  0  0.00  0.00  2.0  2.0  0.0
 3  0  0  0.00  0.00  2.0  2.0  0.0
 &test
   nconf=1
   file_pseudo='Fe.pbe-us.UPF'
   configts(1)='3d6 4s2'
 /
""",
    "Cr": """ &input
    title='Cr',
    zed=24.0,
    rel=1,
    config='[Ar] 3d4 4s2',
    iswitch=3,
    dft='PBE'
 /
 &inputp
   pseudotype=2,
   file_pseudopw='Cr.pbe-us.UPF',
   author='test_cr',
   lloc=-1,
   rcloc=2.2,
   new_core_ps=.true.,
   tm=.true.
 /
 4
 3  2  2  0.00  0.00  2.2  2.2  0.0
 3  2  4  0.00  0.00  1.6  1.6  0.0
 4  0  2  0.00  0.00  2.2  2.2  0.0
 3  1  0  0.00  0.00  2.0  2.0  0.0
 &test
   nconf=1
   file_pseudo='Cr.pbe-us.UPF'
   configts(1)='3d4 4s2'
 /
""",
}

Z_MAP = {"Si": 14, "Fe": 26, "Cr": 24}


def http_get(path: str) -> tuple[int, str]:
    with urllib.request.urlopen(urllib.request.Request(API + path), timeout=60) as r:
        return r.status, r.read().decode("utf-8", errors="replace")


def http_post(path: str, body: dict) -> tuple[int, dict]:
    req = urllib.request.Request(
        API + path,
        data=json.dumps(body).encode(),
        method="POST",
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        raw = r.read().decode("utf-8", errors="replace")
        try:
            return r.status, json.loads(raw)
        except json.JSONDecodeError:
            return r.status, {"_raw": raw[:2000]}


def fetch_oncv_template(sym: str, z: int) -> str:
    try:
        code, txt = http_get(f"/api/pseudos/oncv_input_template?element={sym}&z={z}")
        if code == 200 and "# ATOM AND REFERENCE" in txt:
            return txt
    except Exception:
        pass
    for name in (f"oncv_default_{sym}.dat", f"oncv_templates_3d/{sym}.dat", f"oncv_default_14_Si.dat"):
        p = ROOT / name
        if p.is_file():
            return p.read_text(encoding="utf-8")
    return ""


def run_element(sym: str) -> dict[str, dict]:
    z = Z_MAP.get(sym, 14)
    print(f"\n{'#' * 72}\n# {sym} (Z={z})\n{'#' * 72}")

    _, raw = http_get(f"/api/pseudos/auto_inputs?element={sym}")
    auto = json.loads(raw)
    ape_in = (auto.get("ape_input") or "").strip()
    aw_in = (auto.get("atompaw_input") or "").strip()
    oncv_tpl = fetch_oncv_template(sym, z)
    ld1_in = LD1_INPUTS.get(sym, LD1_INPUTS["Si"].replace("Si", sym).replace("14.0", f"{z}.0"))

    print(f"  Gabarits : APE={len(ape_in)}c  ATOMPAW={len(aw_in)}c  ONCV={len(oncv_tpl)}c")
    if auto.get("note"):
        print(f"  Note : {auto['note'][:100]}")

    results: dict[str, dict] = {}

    _, results["ld1.x"] = http_post("/api/pseudos/generer_ld1", {"element": sym, "input": ld1_in})
    _, results["APE"] = http_post("/api/pseudos/run_ape", {"element": sym, "input": ape_in, "xc": "lda_pw"})
    _, results["ATOMPAW"] = http_post(
        "/api/pseudos/run_atompaw", {"element": sym, "input": aw_in, "format": "interactive"}
    )
    _, results["ONCVPSP"] = http_post("/api/pseudos/run_oncvpsp", {"element": sym, "input": oncv_tpl})

    print(f"\n  {'Générateur':<12} {'OK':<6} {'UPF / sortie'}")
    print("  " + "-" * 60)
    for key in ("ld1.x", "APE", "ATOMPAW", "ONCVPSP"):
        j = results[key]
        ok = "oui" if j.get("success") else "non"
        out = j.get("upf_path") or j.get("upf_genere") or ""
        if key == "ONCVPSP" and j.get("psp8_in_stdout") and not out:
            out = "psp8 stdout"
        if not out and j.get("work_dir"):
            out = str(j["work_dir"])[-40:]
        err = ""
        if not j.get("success"):
            err = (j.get("error") or j.get("hint") or "")[:45]
        print(f"  {key:<12} {ok:<6} {str(out)[:42]:<42} {err}")
    return results


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("elements", nargs="*", default=["Si", "Fe"], help="Symboles (ex. Si Fe Cr)")
    args = p.parse_args()

    try:
        http_get("/health")
    except Exception as e:
        print(f"API indisponible ({API}) : {e}")
        return 1

    all_results: dict[str, dict[str, dict]] = {}
    for sym in args.elements:
        all_results[sym] = run_element(sym)

    print(f"\n{'=' * 72}")
    print("SYNTHÈSE GLOBALE")
    print(f"{'=' * 72}")
    print(f"{'Élément':<8} {'ld1.x':<8} {'APE':<8} {'ATOMPAW':<10} {'ONCVPSP':<8}")
    print("-" * 48)
    for sym, res in all_results.items():
        row = [sym]
        for k in ("ld1.x", "APE", "ATOMPAW", "ONCVPSP"):
            row.append("OK" if res.get(k, {}).get("success") else "—")
        print(f"{row[0]:<8} {row[1]:<8} {row[2]:<8} {row[3]:<10} {row[4]:<8}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Vérifie les 4 générateurs pour Cr (Chrome, Z=24) via l'API live."""
from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request
from pathlib import Path

API = "http://127.0.0.1:5008"
ELEMENT = "Cr"
TIMEOUT = 360


def http_get(path: str) -> tuple[int, str]:
    req = urllib.request.Request(API + path, method="GET")
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.status, r.read().decode("utf-8", errors="replace")


def http_post(path: str, body: dict) -> tuple[int, dict]:
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        API + path,
        data=data,
        method="POST",
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        raw = r.read().decode("utf-8", errors="replace")
        try:
            return r.status, json.loads(raw)
        except json.JSONDecodeError:
            return r.status, {"_raw": raw[:2000]}


def section(title: str) -> None:
    print()
    print("=" * 72)
    print(title)
    print("=" * 72)


def main() -> int:
    fails: list[str] = []
    warns: list[str] = []

    # ── Santé API ─────────────────────────────────────────────────────────
    section("0. API")
    try:
        code, body = http_get("/health")
        print(f"GET /health → {code} {body[:80]}")
        if code != 200:
            fails.append("health")
    except Exception as e:
        print(f"API inaccessible sur {API} : {e}")
        print("→ Lancez : ./DEMARRER.sh")
        return 1

    # ── Binaires ────────────────────────────────────────────────────────────
    section("1. Statut binaires")
    bins = {
        "ld1.x": None,
        "APE": "/api/pseudos/ape_status",
        "ATOMPAW": "/api/pseudos/atompaw_status",
        "ONCVPSP": "/api/pseudos/oncv_status",
    }
    for name, route in bins.items():
        if route is None:
            try:
                sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
                import api_pseudos_standalone as api

                ld1 = api.qe_bin("ld1.x")
                ok = bool(ld1) and Path(ld1).is_file()
                print(f"  ld1.x : {'OK' if ok else 'ABSENT'} → {ld1}")
                if not ok:
                    fails.append("ld1.x binaire")
            except Exception as ex:
                print(f"  ld1.x : erreur import — {ex}")
                fails.append("ld1.x check")
            continue
        try:
            code, raw = http_get(route)
            j = json.loads(raw)
            ok = bool(j.get("available"))
            print(f"  {name} : {'OK' if ok else 'ABSENT'} → {j.get('path')}")
            if not ok:
                warns.append(f"{name} binaire absent")
        except Exception as ex:
            print(f"  {name} : erreur — {ex}")
            fails.append(f"status {name}")

    # ── Gabarits ────────────────────────────────────────────────────────────
    section(f"2. Gabarits entrée — {ELEMENT}")
    auto: dict = {}
    try:
        code, raw = http_get(f"/api/pseudos/auto_inputs?element={ELEMENT}")
        auto = json.loads(raw)
        ape_in = (auto.get("ape_input") or "").strip()
        aw_in = (auto.get("atompaw_input") or "").strip()
        print(f"  auto_inputs HTTP {code}")
        print(f"  APE inp.ape      : {len(ape_in)} car. — {'OK' if 'NuclearCharge' in ape_in else 'VIDE/INVALIDE'}")
        print(f"  ATOMPAW stdin    : {len(aw_in)} car. — {'OK' if aw_in and ELEMENT in aw_in else 'VIDE/INVALIDE'}")
        if not ape_in:
            fails.append("gabarit APE")
        if not aw_in:
            fails.append("gabarit ATOMPAW")
        note = auto.get("note") or ""
        if note:
            print(f"  Note API : {note[:120]}")
    except Exception as ex:
        print(f"  auto_inputs : {ex}")
        fails.append("auto_inputs")

    oncv_tpl = ""
    try:
        code, oncv_tpl = http_get(f"/api/pseudos/oncv_input_template?element={ELEMENT}&z=24")
        valid = "# ATOM AND REFERENCE" in oncv_tpl and "psp8" in oncv_tpl.lower() or "both" in oncv_tpl
        print(f"  ONCV .dat HTTP {code} — {len(oncv_tpl)} car. — {'OK' if valid else 'INVALIDE'}")
        if not valid:
            root = Path(__file__).resolve().parent.parent / "oncv_templates_3d" / f"{ELEMENT}.dat"
            if root.is_file():
                oncv_tpl = root.read_text(encoding="utf-8")
                print(f"  → repli fichier local {root}")
            else:
                fails.append("gabarit ONCV")
    except Exception as ex:
        print(f"  ONCV template : {ex}")
        root = Path(__file__).resolve().parent.parent / "oncv_templates_3d" / f"{ELEMENT}.dat"
        if root.is_file():
            oncv_tpl = root.read_text(encoding="utf-8")
            print(f"  → repli fichier local {root}")
        else:
            fails.append("gabarit ONCV")

    # ld1 : entrée USPP (plus fiable que NC pour Cr 3d)
    ld1_input = """ &input
    title='Cr',
    zed=24.0,
    rel=1,
    config='[Ar] 3d4 4s2',
    iswitch=3,
    dft='PBE'
 /
 &inputp
   pseudotype=2,
   file_pseudopw='Cr.pbe-us.UPF',
   author='test_cr',
   lloc=-1,
   rcloc=2.2,
   new_core_ps=.true.,
   tm=.true.
 /
 4
 3  2  2  0.00  0.00  2.2  2.2  0.0
 3  2  4  0.00  0.00  1.6  1.6  0.0
 4  0  2  0.00  0.00  2.2  2.2  0.0
 3  1  0  0.00  0.00  2.0  2.0  0.0
 &test
   nconf=1
   file_pseudo='Cr.pbe-us.UPF'
   configts(1)='3d4 4s2'
 /
"""
    print(f"  ld1.in (USPP test) : {len(ld1_input)} car.")

    # ── Exécutions ──────────────────────────────────────────────────────────
    results: dict[str, dict] = {}

    section(f"3. Exécution ld1.x — {ELEMENT}")
    try:
        code, j = http_post("/api/pseudos/generer_ld1", {"element": ELEMENT, "input": ld1_input})
        results["ld1.x"] = j
        ok = bool(j.get("success"))
        upf = j.get("upf_path") or j.get("upf_genere")
        print(f"  HTTP {code} | success={ok} | returncode={j.get('returncode')}")
        print(f"  UPF : {upf}")
        if j.get("error"):
            print(f"  error : {j['error'][:200]}")
        if j.get("diagnostics", {}).get("summary"):
            print(f"  diag  : {j['diagnostics']['summary'][:200]}")
        if not ok:
            warns.append("ld1.x Cr USPP — pas de UPF (attendu possible pour 3d NC; testé en USPP)")
    except Exception as ex:
        print(f"  ERREUR : {ex}")
        fails.append("run ld1.x")

    section(f"4. Exécution APE — {ELEMENT}")
    try:
        code, j = http_post(
            "/api/pseudos/run_ape",
            {"element": ELEMENT, "input": auto.get("ape_input", ""), "xc": "lda_pw"},
        )
        results["APE"] = j
        ok = bool(j.get("success"))
        upf = j.get("upf_path") or j.get("upf_genere")
        print(f"  HTTP {code} | success={ok} | returncode={j.get('returncode')}")
        print(f"  UPF : {upf}")
        if j.get("error"):
            print(f"  error : {str(j['error'])[:200]}")
        if j.get("hint"):
            print(f"  hint  : {j['hint'][:200]}")
        if not ok:
            warns.append("APE Cr — échec attendu possible (NC + 3d)")
    except Exception as ex:
        print(f"  ERREUR : {ex}")
        fails.append("run APE")

    section(f"5. Exécution ATOMPAW — {ELEMENT}")
    try:
        code, j = http_post(
            "/api/pseudos/run_atompaw",
            {"element": ELEMENT, "input": auto.get("atompaw_input", ""), "format": "interactive"},
        )
        results["ATOMPAW"] = j
        ok = bool(j.get("success"))
        upf = j.get("upf_path") or j.get("upf_genere")
        print(f"  HTTP {code} | success={ok} | returncode={j.get('returncode')}")
        print(f"  UPF : {upf}")
        if j.get("error"):
            print(f"  error : {str(j['error'])[:200]}")
        if not ok:
            warns.append("ATOMPAW Cr — échec")
    except Exception as ex:
        print(f"  ERREUR : {ex}")
        fails.append("run ATOMPAW")

    section(f"6. Exécution ONCVPSP — {ELEMENT}")
    try:
        code, j = http_post(
            "/api/pseudos/run_oncvpsp",
            {"element": ELEMENT, "input": oncv_tpl},
        )
        results["ONCVPSP"] = j
        ok = bool(j.get("success"))
        upf = j.get("upf_path")
        print(f"  HTTP {code} | success={ok} | returncode={j.get('returncode')}")
        print(f"  UPF disque : {upf}")
        if j.get("psp8_in_stdout"):
            print("  Sortie psp8 dans stdout (normal pour exemples ONCV)")
        if j.get("note"):
            print(f"  note : {j['note'][:200]}")
        if j.get("error"):
            print(f"  error : {str(j['error'])[:200]}")
        if not ok and not j.get("psp8_in_stdout"):
            warns.append("ONCVPSP Cr — échec")
    except Exception as ex:
        print(f"  ERREUR : {ex}")
        fails.append("run ONCVPSP")

    # ── Synthèse ────────────────────────────────────────────────────────────
    section("7. Synthèse Cr (Z=24)")
    print(f"{'Générateur':<12} {'API OK':<8} {'UPF / sortie':<40} {'Remarque'}")
    print("-" * 72)
    labels = {
        "ld1.x": "ld1.x",
        "APE": "APE",
        "ATOMPAW": "ATOMPAW",
        "ONCVPSP": "ONCVPSP",
    }
    for key, label in labels.items():
        j = results.get(key, {})
        api_ok = "oui" if j.get("success") else "non"
        out = j.get("upf_path") or j.get("upf_genere") or ""
        if key == "ONCVPSP" and j.get("psp8_in_stdout"):
            out = out or "psp8 dans stdout"
        if not out and j.get("work_dir"):
            out = str(j.get("work_dir"))[-36:]
        remark = ""
        if not j.get("success"):
            remark = (j.get("error") or j.get("hint") or "voir logs")[:50]
        print(f"{label:<12} {api_ok:<8} {str(out)[:40]:<40} {remark}")

    print()
    if fails:
        print(f"ÉCHECS bloquants ({len(fails)}) : {', '.join(fails)}")
    if warns:
        print(f"Avertissements ({len(warns)}) : {', '.join(warns)}")
    if not fails:
        print("Chaîne API + gabarits : opérationnelle pour les 4 générateurs.")
        print("Note : Cr (3d) peut échouer en ld1 NC / APE NC — ATOMPAW et ONCVPSP sont les voies recommandées.")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Vérification générale de l'API générateur (sans navigateur).
Usage : python3 verifier_api_generale.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main() -> int:
    sys.path.insert(0, str(ROOT))
    try:
        import api_pseudos_standalone as api
    except ImportError as e:
        print(f"FAIL import api: {e}")
        return 1

    client = api.app.test_client()
    fails: list[str] = []
    oks: list[str] = []

    def check(name: str, cond: bool, detail: str = "") -> None:
        line = f"{'OK' if cond else 'FAIL'}  {name}"
        if detail:
            line += f" — {detail}"
        print(line)
        if cond:
            oks.append(name)
        else:
            fails.append(name)

    # Build tag
    r = client.get("/api/pseudos/version")
    check("GET /api/pseudos/version", r.status_code == 200)
    ver = r.get_json() or {}
    check("build_tag défini", bool(ver.get("build_tag")), ver.get("build_tag", "?"))

    r = client.get("/health")
    check("GET /health", r.status_code == 200)

    for route in ("/api/pseudos/ape_status", "/api/pseudos/atompaw_status", "/api/pseudos/oncv_status"):
        r = client.get(route)
        j = r.get_json() or {}
        check(route, r.status_code == 200 and "available" in j, str(j.get("path") or j.get("available")))

    # Gabarit ONCV Ni (3d)
    r = client.get("/api/pseudos/oncv_input_template?element=Ni&z=28")
    body = (r.get_data(as_text=True) or "")[:500]
    check(
        "ONCV template Ni",
        r.status_code == 200 and "Ni" in body and "ATOM AND REFERENCE" in body,
        f"{len(body)} chars",
    )

    r = client.get("/oncv_templates_3d/Ni.dat")
    check("static oncv_templates_3d/Ni.dat", r.status_code == 200, f"HTTP {r.status_code}")

    # Validation UPF (échantillon local si présent)
    samples = [
        ROOT / "tests/fixtures/ape_try_Si/Si.UPF",
        ROOT / "oncv_templates_3d/Ni.dat",
    ]
    for p in samples:
        if not p.is_file():
            continue
        if p.suffix.lower() == ".upf":
            v = api._validate_upf_qe(p, p.stem[:2])
            check(f"validate UPF {p.name}", v.get("conform_qe") is True, v.get("format", ""))

    # Bibliothèques
    r = client.get("/api/pseudos/libraries/ensure_dirs")
    check("libraries/ensure_dirs", r.status_code == 200)

    # verifier_upf_qe route
    si_upf = ROOT / "tests/fixtures/ape_try_Si/Si.UPF"
    if si_upf.is_file():
        r = client.post(
            "/api/pseudos/verifier_upf_qe",
            json={"path": str(si_upf), "element": "Si"},
        )
        j = r.get_json() or {}
        check("POST verifier_upf_qe Si", j.get("conform_qe") is True, j.get("validation", {}).get("format", ""))

    # Modèle APE exemple (preset Li)
    r = client.get("/api/pseudos/ape_input_template?preset=li_ae")
    txt = r.get_data(as_text=True) or ""
    check(
        "ape_input_template (li_ae)",
        r.status_code == 200 and "CalculationMode" in txt and "NuclearCharge" in txt,
    )

    # Entrée auto Si via element_info / génération interne
    try:
        import pseudo_auto_inputs as pai

        inp = pai.generate_ape_input("Si", xc="gga_pbe")
        check(
            "generate_ape_input Si",
            "PPOutputFileFormat" in inp and "CalculationMode" in inp,
        )
    except Exception as ex:
        check("generate_ape_input Si", False, str(ex))

    try:
        from generator_guide import classify_qe_status, tab_guide

        s = classify_qe_status(
            "ape",
            upf_qe_ready=False,
            upf_found=False,
            run_completed=True,
            returncode=0,
            fatal_errors=["Crash mémoire APE"],
            element="Mn",
        )
        check("classify_qe_status Mn APE", s.get("level") == "cannot_generate", s.get("level", ""))
        g = tab_guide("atompaw", "Fe")
        check("tab_guide atompaw capabilities", bool(g.get("capabilities")), str(len(g.get("capabilities") or [])))
    except Exception as ex:
        check("generator_guide classify", False, str(ex))

    print()
    print(f"Résumé : {len(oks)} OK, {len(fails)} échec(s)")
    if fails:
        print("Échecs :", ", ".join(fails))
        print("\n→ Relancez : ./DEMARRER.sh  puis revérifiez.")
        return 1
    print("→ API prête. Ouvrez http://127.0.0.1:5008/ après ./DEMARRER.sh")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

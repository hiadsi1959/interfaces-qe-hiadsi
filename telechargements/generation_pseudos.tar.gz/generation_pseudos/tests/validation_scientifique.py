#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Validation scientifique multi-familles via Flask test_client.

Matrice recommandée (couverture chimique minimale) :
  - élément léger / p-bloc  : Al
  - métal de transition 3d  : Fe
  - terre rare / lanthanide : La

Critères par génération :
  - binaire disponible
  - success / returncode == 0
  - UPF produit *pendant* le run (mtime ≥ t0)
  - conformité QE (_validate_upf_qe)
  - archivage dans pseudos-<générateur>/
  - métadonnées (format, z_valence, taille)

Usage :
  python3 tests/validation_scientifique.py
  python3 tests/validation_scientifique.py Al Fe La
"""
from __future__ import annotations

import json
import os
import re
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# Préserver les symboles CLI avant que l’import API ne consomme sys.argv
_CLI_ELEMENTS = [a for a in sys.argv[1:] if not a.startswith("-") and re.match(r"^[A-Za-z]{1,3}$", a)]
_saved_argv = sys.argv[:]
sys.argv = ["api_pseudos_standalone", "--port", "5008"]

import api_pseudos_standalone as api  # noqa: E402

sys.argv = _saved_argv

# Entrées ld1 au format QE 7.x (labels 3S/3P/… — pas n l occ seuls)
# Sources : pseudo_library QE + paw_examples/Fe.in (sans sous-dossier prefix)
LD1 = {
    "Al": """ &input
    title='Al',
    zed=13.0,
    rel=1,
    config='[Ne] 3s2 3p1 3d-2',
    iswitch=3,
    dft='PBE'
 /
 &inputp
   lloc=2,
   pseudotype=1,
   file_pseudopw='Al.pbe-nc.UPF',
   author='validation_sci',
   new_core_ps=.true.,
   rho0=0.001,
 /
3
3S  1  0  2.00  0.00  2.40  2.40
3P  2  1  1.00  0.00  2.40  2.40
3D  3  2 -2.00  0.15  2.40  2.40
""",
    "Si": """ &input
    title='Si',
    zed=14.0,
    rel=0,
    config='[Ne] 3s2 3p2 3d-2',
    iswitch=3,
    dft='PBE'
 /
 &inputp
   lloc=2,
   pseudotype=1,
   file_pseudopw='Si.pbe-nc.UPF',
   author='validation_sci',
   new_core_ps=.true.,
   rho0=0.001,
 /
3
3S  1  0  2.00  0.00  1.80  1.80
3P  2  1  2.00  0.00  1.80  1.80
3D  3  2 -2.00  0.15  1.80  1.80
""",
    "Fe": """ &input
    title='Fe',
    zed=26,
    config='[Ar] 4s2 3d6 4p0',
    iswitch=3,
    dft='PBE',
    nld=3,
    eminld=-10,
    emaxld=10,
    deld=0.01d0,
    rlderiv=2.3,
 /
 &inputp
   pseudotype=3,
   nlcc=.true.,
   new_core_ps=.true.,
   rcore=1.2000,
   lloc=-2,
   rcloc=2.2000,
   file_pseudopw='Fe.pbe-paw_kj.UPF',
   zval=8,
   lpaw=.true.,
   lnc2paw=.false.,
   which_augfun='BESSEL',
   rmatch_augfun=2.3000,
   author='validation_sci',
   tm=.true.,
 /
6
3D  3 2 6.00    0.00    1.50    2.2000
3D  3 2 0.00   -0.40    1.50    2.2000
4S  1 0 2.00    0.00    1.50    2.2000
4S  1 0 0.00    0.30    1.50    2.2000
4P  2 1 0.00    0.00    1.50    2.2000
4P  2 1 0.00    0.70    1.50    2.2000
""",
}

# Familles pour le rapport (informatives)
FAMILLE = {
    "Al": "léger / p-bloc",
    "Si": "léger / p-bloc",
    "C": "léger / p-bloc",
    "O": "léger / p-bloc",
    "Fe": "métal de transition 3d",
    "Ti": "métal de transition 3d",
    "Cr": "métal de transition 3d",
    "La": "terre rare (lanthanide)",
    "Ce": "terre rare (lanthanide)",
    "Gd": "terre rare (lanthanide)",
}


def _zval(path: str | None) -> float | None:
    if not path or not os.path.isfile(path):
        return None
    try:
        raw = Path(path).read_text(encoding="utf-8", errors="replace")[:80000]
    except OSError:
        return None
    m = re.search(r'z_valence\s*=\s*["\']?([0-9.eE+-]+)', raw, re.I)
    if m:
        try:
            return float(m.group(1))
        except ValueError:
            return None
    return None


def _fresh_upf(path: str | None, t0: float) -> bool:
    if not path or not os.path.isfile(path):
        return False
    try:
        return os.path.getmtime(path) >= (t0 - 2.0)
    except OSError:
        return False


def _score_row(j: dict, upf_path: str | None, t0: float) -> dict:
    qv = j.get("qe_validation") or {}
    if upf_path and os.path.isfile(upf_path) and not qv:
        qv = api._validate_upf_qe(upf_path)
    rc = j.get("returncode")
    ok_api = bool(j.get("success"))
    fresh = _fresh_upf(upf_path, t0)
    conform = bool(qv.get("conform_qe") or j.get("upf_qe_ready"))
    # Strict : succès API + UPF frais (mtime) + conforme QE.
    # Sans `fresh`, un vieux fichier en _work peut faire un faux positif.
    ok_sci = ok_api and fresh and conform and (rc is None or rc == 0)
    archived = bool(j.get("copied_to_pseudos_generes"))
    size = 0
    if upf_path and os.path.isfile(upf_path):
        size = os.path.getsize(upf_path)
    return {
        "success": ok_api,
        "ok_scientifique": ok_sci,
        "fresh_upf": fresh,
        "upf_path": upf_path or "",
        "conform_qe": conform,
        "format": qv.get("format"),
        "z_valence": _zval(upf_path),
        "size_kb": round(size / 1024, 1) if size else 0,
        "archived": archived,
        "bucket": j.get("pseudos_generes_dir") or j.get("pseudos_bucket") or "",
        "error": (j.get("error") or j.get("hint") or j.get("diagnostic_summary") or "")[:160],
        "returncode": rc,
    }


def _oncv_input(client, element: str, z: int) -> str:
    """Priorité aux gabarits locaux de l’élément — jamais de repli Si implicite."""
    candidates = [
        ROOT / "data" / "oncvpsp_tests_data" / f"{z}_{element}.dat",
        ROOT / f"oncv_default_{element}.dat",
        ROOT / "oncv_templates_3d" / f"{element}.dat",
        ROOT / "data" / "oncv" / f"oncv_default_{element}.dat",
        ROOT / "data" / "oncv" / f"oncv_default_{z}_{element}.dat",
    ]
    for p in sorted(ROOT.glob("data/**/*.dat")):
        name = p.name.lower()
        if element.lower() in name and (str(z) in name or f"_{element.lower()}" in name):
            candidates.insert(0, p)
    for cand in candidates:
        if cand.is_file():
            txt = cand.read_text(encoding="utf-8")
            # Refuser un fichier clairement pour un autre symbole
            head = "\n".join(txt.splitlines()[:8]).lower()
            if re.search(rf"\b{element.lower()}\b", head) or f"{z}." in cand.name or f"{z}_" in cand.name:
                return txt
            if element.lower() in cand.name.lower():
                return txt
    r_oncv = client.get(f"/api/pseudos/oncv_input_template?element={element}&z={z}")
    oncv_tpl = r_oncv.data.decode("utf-8", errors="replace") if r_oncv.status_code == 200 else ""
    if "# ATOM" in oncv_tpl and f"« {element} »" not in oncv_tpl:
        # API peut renvoyer un template Si avec garde — on ne l’accepte que si symbole OK
        head = "\n".join(oncv_tpl.splitlines()[:12]).lower()
        if re.search(rf"\b{element.lower()}\b", head):
            return oncv_tpl
    return ""


def run_one(client, element: str) -> dict[str, dict]:
    fam = FAMILLE.get(element, "?")
    print(f"\n{'=' * 72}\n  Élément {element}  ({fam})\n{'=' * 72}")
    out: dict[str, dict] = {}

    r = client.get(f"/api/pseudos/auto_inputs?element={element}")
    auto = r.get_json() or {}
    ape_in = (auto.get("ape_input") or "").strip()
    aw_in = (auto.get("atompaw_input") or "").strip()

    z = {"Al": 13, "Si": 14, "Fe": 26, "Ti": 22, "La": 57, "Ce": 58, "C": 6}.get(element, 14)
    oncv_tpl = _oncv_input(client, element, z)

    ld1_in = LD1.get(element, "")
    if not ld1_in:
        print(f"  ⚠ Pas d’entrée ld1 dédiée pour {element} — ld1 ignoré")

    if ld1_in:
        t0 = time.time()
        print("  → ld1.x …", flush=True)
        resp = client.post("/api/pseudos/generer_ld1", json={"element": element, "input": ld1_in})
        j = resp.get_json() or {}
        upf = j.get("upf_path") or ""
        if not upf and j.get("upf_genere") and j.get("pseudos_dir"):
            upf = str(Path(j["pseudos_dir"]) / j["upf_genere"])
        row = _score_row(j, upf, t0)
        row["dt_s"] = round(time.time() - t0, 1)
        out["ld1.x"] = row
        print(
            f"     api={row['success']} sci={row['ok_scientifique']} "
            f"fresh={row['fresh_upf']} conform={row['conform_qe']} "
            f"z={row['z_valence']} {row['size_kb']} KB  ({row['dt_s']}s)"
        )
        if not row["ok_scientifique"]:
            print(f"     err: {row['error']}")

    t0 = time.time()
    print("  → APE …", flush=True)
    resp = client.post("/api/pseudos/run_ape", json={
        "element": element, "input": ape_in, "xc": "lda_pw", "auto_generate": not bool(ape_in),
    })
    j = resp.get_json() or {}
    # APE 2 étapes : ae puis pp via continue_dir
    wd = j.get("work_dir") or j.get("continue_dir") or j.get("run_dir")
    if (not j.get("success")) and wd and (
        "continue_dir" in (j.get("hint") or j.get("error") or "").lower()
        or "étape ae" in (j.get("hint") or j.get("error") or "").lower()
    ):
        print(f"     (continue_dir → {wd})", flush=True)
        resp = client.post("/api/pseudos/run_ape", json={
            "element": element, "input": ape_in, "xc": "lda_pw",
            "continue_dir": wd, "auto_generate": False,
        })
        j = resp.get_json() or {}
    row = _score_row(j, j.get("upf_path"), t0)
    row["dt_s"] = round(time.time() - t0, 1)
    out["APE"] = row
    print(
        f"     api={row['success']} sci={row['ok_scientifique']} "
        f"fresh={row['fresh_upf']} conform={row['conform_qe']} "
        f"z={row['z_valence']} {row['size_kb']} KB  ({row['dt_s']}s)"
    )
    if not row["ok_scientifique"]:
        print(f"     err: {row['error'] or j.get('hint') or ''}")

    t0 = time.time()
    print("  → ATOMPAW …", flush=True)
    resp = client.post("/api/pseudos/run_atompaw", json={
        "element": element, "input": aw_in, "format": "interactive",
        "auto_generate": not bool(aw_in),
    })
    j = resp.get_json() or {}
    row = _score_row(j, j.get("upf_path"), t0)
    row["dt_s"] = round(time.time() - t0, 1)
    out["ATOMPAW"] = row
    print(
        f"     api={row['success']} sci={row['ok_scientifique']} "
        f"fresh={row['fresh_upf']} conform={row['conform_qe']} "
        f"z={row['z_valence']} {row['size_kb']} KB  ({row['dt_s']}s)"
    )
    if not row["ok_scientifique"]:
        print(f"     err: {row['error']}")

    t0 = time.time()
    print("  → ONCVPSP …", flush=True)
    if not oncv_tpl:
        out["ONCVPSP"] = {
            "success": False, "ok_scientifique": False, "fresh_upf": False,
            "conform_qe": False, "error": "pas de template ONCV", "dt_s": 0,
            "z_valence": None, "size_kb": 0, "archived": False, "returncode": None,
            "upf_path": "",
        }
        print("     err: pas de template ONCV")
    else:
        resp = client.post("/api/pseudos/run_oncvpsp", json={"element": element, "input": oncv_tpl})
        j = resp.get_json() or {}
        row = _score_row(j, j.get("upf_path"), t0)
        row["dt_s"] = round(time.time() - t0, 1)
        row["psp8"] = bool(j.get("psp8_in_stdout"))
        out["ONCVPSP"] = row
        print(
            f"     api={row['success']} sci={row['ok_scientifique']} "
            f"fresh={row['fresh_upf']} conform={row['conform_qe']} "
            f"z={row['z_valence']} {row['size_kb']} KB  ({row['dt_s']}s)"
        )
        if not row["ok_scientifique"]:
            print(f"     err: {row['error']}")

    return out


def main() -> int:
    # Matrice minimale scientifiquement défendable
    elements = _CLI_ELEMENTS or ["Al", "Fe", "La"]
    print("VALIDATION SCIENTIFIQUE — familles chimiques")
    print(f"Projet : {ROOT}")
    print(f"Build  : {api.API_BUILD_TAG}")
    print(f"QE     : {api.QE_BIN}")
    print(f"APE    : {api._resolve_ape_bin_sa()}")
    print(f"ATOMPAW: {api._resolve_atompaw_bin_sa()}")
    print(f"ONCV   : {api._resolve_oncvpsp_bin()}")
    print("Éléments :", ", ".join(f"{e} ({FAMILLE.get(e, '?')})" for e in elements))

    bins = {
        "ld1.x": bool(api.QE_BIN and os.path.isfile(os.path.join(api.QE_BIN, "ld1.x"))),
        "APE": bool(api._resolve_ape_bin_sa()),
        "ATOMPAW": bool(api._resolve_atompaw_bin_sa()),
        "ONCVPSP": bool(api._resolve_oncvpsp_bin()),
    }
    print("Binaires :", ", ".join(f"{k}={'OK' if v else 'ABSENT'}" for k, v in bins.items()))

    client = api.app.test_client()
    all_res: dict[str, dict[str, dict]] = {}
    for el in elements:
        all_res[el] = run_one(client, el)

    print(f"\n{'=' * 72}")
    print("SYNTHÈSE — critères scientifiques (frais + conforme QE)")
    print(f"{'=' * 72}")
    print(f"{'Élément':<6} {'Famille':<24} {'Outil':<10} {'Sci':<5} {'QE':<5} {'z_val':<7} {'ko':<7} {'t(s)':<6}")
    print("-" * 78)
    n_ok = n_tot = 0
    by_el: dict[str, int] = {}
    for el, tools in all_res.items():
        by_el[el] = 0
        for name, row in tools.items():
            n_tot += 1
            sci = row.get("ok_scientifique")
            if sci:
                n_ok += 1
                by_el[el] += 1
            print(
                f"{el:<6} {FAMILLE.get(el, '?'):<24} {name:<10} "
                f"{'OK' if sci else '—':<5} "
                f"{'OK' if row.get('conform_qe') else '—':<5} "
                f"{str(row.get('z_valence') or '—'):<7} "
                f"{str(row.get('size_kb') or '—'):<7} "
                f"{row.get('dt_s', '—')}"
            )
            if not sci and row.get("error"):
                print(f"       └ {row['error'][:90]}")

    print(f"\nScore strict (UPF frais + conforme QE) : {n_ok}/{n_tot}")
    for el, k in by_el.items():
        tot_el = len(all_res[el])
        print(f"  {el} ({FAMILLE.get(el, '?')}): {k}/{tot_el}")

    # Verdict : chaque famille doit avoir ≥ 2 générateurs OK
    familles_ok = sum(1 for el, k in by_el.items() if k >= 2)
    verdict = (
        "VALIDATION PARTIELLE ACCEPTABLE"
        if familles_ok == len(elements) and n_ok >= max(3, n_tot // 2)
        else "VALIDATION INSUFFISANTE — ne pas conclure à une validité générale"
    )
    if familles_ok == len(elements) and n_ok >= int(0.75 * n_tot):
        verdict = "VALIDATION MULTI-FAMILLES RÉUSSIE (génération + conformité UPF)"
    print(f"\nVerdict : {verdict}")
    print(
        "Note : ceci valide la *chaîne de génération UPF*, pas la qualité "
        "physique (courbes log-dérivées, tests solides, ΔE, phonon)."
    )

    report = {
        "build_tag": api.API_BUILD_TAG,
        "binaries": bins,
        "elements": elements,
        "familles": {e: FAMILLE.get(e) for e in elements},
        "results": all_res,
        "score_ok_qe": n_ok,
        "score_total": n_tot,
        "familles_ok": familles_ok,
        "verdict": verdict,
    }
    out_path = ROOT / "logs" / "validation_scientifique.json"
    out_path.parent.mkdir(exist_ok=True)
    out_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    log_path = ROOT / "logs" / "validation_scientifique.log"
    # le stdout a déjà tout ; on laisse aussi un marqueur
    log_path.write_text(
        f"score={n_ok}/{n_tot}\nverdict={verdict}\nvoir aussi {out_path}\n",
        encoding="utf-8",
    )
    print(f"Rapport JSON : {out_path}")

    return 0 if familles_ok == len(elements) and n_ok >= max(3, n_tot // 2) else 1


if __name__ == "__main__":
    raise SystemExit(main())

/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * GÉNÉRATEUR DE PSEUDOPOTENTIELS - ld1.x
 * Génère des fichiers ld1.in pour Quantum ESPRESSO
 * ═══════════════════════════════════════════════════════════════════════════════
 */

// Configuration — chemins depuis window.QE_CONFIG (rempli par /api/chemins). Pas de chemins /home/hiadsi.
var LD1_CONFIG_FALLBACK = {
    QE_BIN: '',
    PSEUDO_DIR: '',
    PSEUDO_GENERES_DIR: '',
    LD1_INPUTS_DIR: '',
    INPUTS_DIR: ''
};
function resolveLD1Config() {
    var q = typeof window !== 'undefined' && window.QE_CONFIG;
    if (!q) return LD1_CONFIG_FALLBACK;
    var qeBin = String(q.QE_BIN_DIR || '').replace(/\/+$/, '');
    var main = String(q.WORK_DIR || q.PROJECT_MAIN || '').replace(/\/+$/, '');
    var pseudo = String(q.PSEUDO_DIR || '').replace(/\/+$/, '');
    return {
        QE_BIN: qeBin,
        PSEUDO_DIR: pseudo || (main ? main + '/pseudos' : ''),
        PSEUDO_GENERES_DIR: q.PSEUDO_GENERES_DIR || (main ? main + '/pseudos-ld1' : ''),
        LD1_INPUTS_DIR: q.LD1_INPUTS_DIR || (main ? main + '/pseudos-ld1' : ''),
        INPUTS_DIR: q.INPUTS_DIR || (main ? main + '/inputs' : '')
    };
}
var LD1_CONFIG = new Proxy({}, {
    get: function (_t, prop) {
        return resolveLD1Config()[prop];
    }
});

/** Base URL de l'API Flask pseudos — alignée sur index.html getApiPseudosBase quand disponible. */
function apiPseudosBase() {
    if (typeof window !== 'undefined' && typeof window.getApiPseudosBase === 'function') {
        try {
            return String(window.getApiPseudosBase()).replace(/\/$/, '');
        } catch (e) { /* ignore */ }
    }
    if (typeof window !== 'undefined' && window.API_PSEUDOS_ORIGIN) {
        return String(window.API_PSEUDOS_ORIGIN).replace(/\/$/, '');
    }
    return 'http://127.0.0.1:5008';
}

function _escapeHtmlLd1(s) {
    if (s == null) return '';
    return String(s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

/**
 * Base de données complète des éléments avec configurations électroniques
 * et paramètres recommandés pour ld1.x
 */
const ELEMENTS_LD1 = {
    // Période 1
    'H':  { Z: 1,  config: '1s1', core: '', valence: '1s1', rcut: [1.0], orbitals: ['1S'] },
    'He': { Z: 2,  config: '1s2', core: '', valence: '1s2', rcut: [1.2], orbitals: ['1S'] },
    
    // Période 2
    'Li': { Z: 3,  config: '[He] 2s1', core: '1s2', valence: '2s1', rcut: [2.0, 2.0], orbitals: ['2S', '2P'] },
    'Be': { Z: 4,  config: '[He] 2s2', core: '1s2', valence: '2s2', rcut: [1.8, 1.8], orbitals: ['2S', '2P'] },
    'B':  { Z: 5,  config: '[He] 2s2 2p1', core: '1s2', valence: '2s2 2p1', rcut: [1.6, 1.6], orbitals: ['2S', '2P'] },
    'C':  { Z: 6,  config: '[He] 2s2 2p2', core: '1s2', valence: '2s2 2p2', rcut: [1.5, 1.5], orbitals: ['2S', '2P'] },
    'N':  { Z: 7,  config: '[He] 2s2 2p3', core: '1s2', valence: '2s2 2p3', rcut: [1.4, 1.4], orbitals: ['2S', '2P'] },
    'O':  { Z: 8,  config: '[He] 2s2 2p4', core: '1s2', valence: '2s2 2p4', rcut: [1.4, 1.4], orbitals: ['2S', '2P'] },
    'F':  { Z: 9,  config: '[He] 2s2 2p5', core: '1s2', valence: '2s2 2p5', rcut: [1.3, 1.3], orbitals: ['2S', '2P'] },
    'Ne': { Z: 10, config: '[He] 2s2 2p6', core: '1s2', valence: '2s2 2p6', rcut: [1.3, 1.3], orbitals: ['2S', '2P'] },
    
    // Période 3
    'Na': { Z: 11, config: '[Ne] 3s1', core: '1s2 2s2 2p6', valence: '3s1', rcut: [2.2, 2.2], orbitals: ['3S', '3P'] },
    'Mg': { Z: 12, config: '[Ne] 3s2', core: '1s2 2s2 2p6', valence: '3s2', rcut: [2.0, 2.0], orbitals: ['3S', '3P'] },
    'Al': { Z: 13, config: '[Ne] 3s2 3p1', core: '1s2 2s2 2p6', valence: '3s2 3p1', rcut: [2.0, 2.0], orbitals: ['3S', '3P'] },
    'Si': { Z: 14, config: '[Ne] 3s2 3p2', core: '1s2 2s2 2p6', valence: '3s2 3p2', rcut: [1.8, 1.8], orbitals: ['3S', '3P'] },
    'P':  { Z: 15, config: '[Ne] 3s2 3p3', core: '1s2 2s2 2p6', valence: '3s2 3p3', rcut: [1.8, 1.8], orbitals: ['3S', '3P'] },
    'S':  { Z: 16, config: '[Ne] 3s2 3p4', core: '1s2 2s2 2p6', valence: '3s2 3p4', rcut: [1.7, 1.7], orbitals: ['3S', '3P'] },
    'Cl': { Z: 17, config: '[Ne] 3s2 3p5', core: '1s2 2s2 2p6', valence: '3s2 3p5', rcut: [1.6, 1.6], orbitals: ['3S', '3P'] },
    'Ar': { Z: 18, config: '[Ne] 3s2 3p6', core: '1s2 2s2 2p6', valence: '3s2 3p6', rcut: [1.6, 1.6], orbitals: ['3S', '3P'] },
    
    // Période 4 - Métaux de transition
    'K':  { Z: 19, config: '[Ar] 4s1', core: '[Ne] 3s2 3p6', valence: '3s2 3p6 4s1', rcut: [2.5, 2.5, 2.5], orbitals: ['3S', '3P', '4S'] },
    'Ca': { Z: 20, config: '[Ar] 4s2', core: '[Ne] 3s2 3p6', valence: '3s2 3p6 4s2', rcut: [2.3, 2.3, 2.3], orbitals: ['3S', '3P', '4S'] },
    'Sc': { Z: 21, config: '[Ar] 3d1 4s2', core: '[Ne] 3s2 3p6', valence: '3d1 4s2', rcut: [2.2, 2.2, 2.2], orbitals: ['3D', '4S', '4P'] },
    'Ti': { Z: 22, config: '[Ar] 3d2 4s2', core: '[Ne] 3s2 3p6', valence: '3d2 4s2', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'V':  { Z: 23, config: '[Ar] 3d3 4s2', core: '[Ne] 3s2 3p6', valence: '3d3 4s2', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Cr': { Z: 24, config: '[Ar] 3d5 4s1', core: '[Ne] 3s2 3p6', valence: '3d5 4s1', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Mn': { Z: 25, config: '[Ar] 3d5 4s2', core: '[Ne] 3s2 3p6', valence: '3d5 4s2', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Fe': { Z: 26, config: '[Ar] 3d6 4s2', core: '[Ne] 3s2 3p6', valence: '3d6 4s2', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Co': { Z: 27, config: '[Ar] 3d7 4s2', core: '[Ne] 3s2 3p6', valence: '3d7 4s2', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Ni': { Z: 28, config: '[Ar] 3d8 4s2', core: '[Ne] 3s2 3p6', valence: '3d8 4s2', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Cu': { Z: 29, config: '[Ar] 3d10 4s1', core: '[Ne] 3s2 3p6', valence: '3d10 4s1', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Zn': { Z: 30, config: '[Ar] 3d10 4s2', core: '[Ne] 3s2 3p6', valence: '3d10 4s2', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Ga': { Z: 31, config: '[Ar] 3d10 4s2 4p1', core: '[Ar] 3d10', valence: '4s2 4p1', rcut: [2.2, 2.2], orbitals: ['4S', '4P'] },
    'Ge': { Z: 32, config: '[Ar] 3d10 4s2 4p2', core: '[Ar] 3d10', valence: '4s2 4p2', rcut: [2.1, 2.1], orbitals: ['4S', '4P'] },
    'As': { Z: 33, config: '[Ar] 3d10 4s2 4p3', core: '[Ar] 3d10', valence: '4s2 4p3', rcut: [2.0, 2.0], orbitals: ['4S', '4P'] },
    'Se': { Z: 34, config: '[Ar] 3d10 4s2 4p4', core: '[Ar] 3d10', valence: '4s2 4p4', rcut: [2.0, 2.0], orbitals: ['4S', '4P'] },
    'Br': { Z: 35, config: '[Ar] 3d10 4s2 4p5', core: '[Ar] 3d10', valence: '4s2 4p5', rcut: [1.9, 1.9], orbitals: ['4S', '4P'] },
    'Kr': { Z: 36, config: '[Ar] 3d10 4s2 4p6', core: '[Ar] 3d10', valence: '4s2 4p6', rcut: [1.9, 1.9], orbitals: ['4S', '4P'] },
    
    // Période 5
    'Rb': { Z: 37, config: '[Kr] 5s1', core: '[Ar] 3d10 4s2 4p6', valence: '5s1', rcut: [2.8], orbitals: ['5S'] },
    'Sr': { Z: 38, config: '[Kr] 5s2', core: '[Ar] 3d10 4s2 4p6', valence: '5s2', rcut: [2.6], orbitals: ['5S'] },
    'Y':  { Z: 39, config: '[Kr] 4d1 5s2', core: '[Kr]', valence: '4d1 5s2', rcut: [2.4, 2.4, 2.4], orbitals: ['4D', '5S', '5P'] },
    'Zr': { Z: 40, config: '[Kr] 4d2 5s2', core: '[Kr]', valence: '4d2 5s2', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Nb': { Z: 41, config: '[Kr] 4d4 5s1', core: '[Kr]', valence: '4d4 5s1', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Mo': { Z: 42, config: '[Kr] 4d5 5s1', core: '[Kr]', valence: '4d5 5s1', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Tc': { Z: 43, config: '[Kr] 4d5 5s2', core: '[Kr]', valence: '4d5 5s2', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Ru': { Z: 44, config: '[Kr] 4d7 5s1', core: '[Kr]', valence: '4d7 5s1', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Rh': { Z: 45, config: '[Kr] 4d8 5s1', core: '[Kr]', valence: '4d8 5s1', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Pd': { Z: 46, config: '[Kr] 4d10', core: '[Kr]', valence: '4d10', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Ag': { Z: 47, config: '[Kr] 4d10 5s1', core: '[Kr]', valence: '4d10 5s1', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Cd': { Z: 48, config: '[Kr] 4d10 5s2', core: '[Kr]', valence: '4d10 5s2', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'In': { Z: 49, config: '[Kr] 4d10 5s2 5p1', core: '[Kr] 4d10', valence: '5s2 5p1', rcut: [2.4, 2.4], orbitals: ['5S', '5P'] },
    'Sn': { Z: 50, config: '[Kr] 4d10 5s2 5p2', core: '[Kr] 4d10', valence: '5s2 5p2', rcut: [2.3, 2.3], orbitals: ['5S', '5P'] },
    'Sb': { Z: 51, config: '[Kr] 4d10 5s2 5p3', core: '[Kr] 4d10', valence: '5s2 5p3', rcut: [2.2, 2.2], orbitals: ['5S', '5P'] },
    'Te': { Z: 52, config: '[Kr] 4d10 5s2 5p4', core: '[Kr] 4d10', valence: '5s2 5p4', rcut: [2.2, 2.2], orbitals: ['5S', '5P'] },
    'I':  { Z: 53, config: '[Kr] 4d10 5s2 5p5', core: '[Kr] 4d10', valence: '5s2 5p5', rcut: [2.1, 2.1], orbitals: ['5S', '5P'] },
    'Xe': { Z: 54, config: '[Kr] 4d10 5s2 5p6', core: '[Kr] 4d10', valence: '5s2 5p6', rcut: [2.1, 2.1], orbitals: ['5S', '5P'] },
    
    // Période 6 - incluant lanthanides
    'Cs': { Z: 55, config: '[Xe] 6s1', core: '[Xe]', valence: '6s1', rcut: [3.0], orbitals: ['6S'] },
    'Ba': { Z: 56, config: '[Xe] 6s2', core: '[Xe]', valence: '6s2', rcut: [2.8], orbitals: ['6S'] },
    'La': { Z: 57, config: '[Xe] 5d1 6s2', core: '[Xe]', valence: '5d1 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['5D', '6S', '6P'] },
    'Ce': { Z: 58, config: '[Xe] 4f1 5d1 6s2', core: '[Xe]', valence: '4f1 5d1 6s2', rcut: [2.5, 2.5, 2.5, 2.5], orbitals: ['4F', '5D', '6S', '6P'] },
    'Pr': { Z: 59, config: '[Xe] 4f3 6s2', core: '[Xe]', valence: '4f3 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Nd': { Z: 60, config: '[Xe] 4f4 6s2', core: '[Xe]', valence: '4f4 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Pm': { Z: 61, config: '[Xe] 4f5 6s2', core: '[Xe]', valence: '4f5 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Sm': { Z: 62, config: '[Xe] 4f6 6s2', core: '[Xe]', valence: '4f6 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Eu': { Z: 63, config: '[Xe] 4f7 6s2', core: '[Xe]', valence: '4f7 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Gd': { Z: 64, config: '[Xe] 4f7 5d1 6s2', core: '[Xe]', valence: '4f7 5d1 6s2', rcut: [2.5, 2.5, 2.5, 2.5], orbitals: ['4F', '5D', '6S', '6P'] },
    'Tb': { Z: 65, config: '[Xe] 4f9 6s2', core: '[Xe]', valence: '4f9 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Dy': { Z: 66, config: '[Xe] 4f10 6s2', core: '[Xe]', valence: '4f10 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Ho': { Z: 67, config: '[Xe] 4f11 6s2', core: '[Xe]', valence: '4f11 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Er': { Z: 68, config: '[Xe] 4f12 6s2', core: '[Xe]', valence: '4f12 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Tm': { Z: 69, config: '[Xe] 4f13 6s2', core: '[Xe]', valence: '4f13 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Yb': { Z: 70, config: '[Xe] 4f14 6s2', core: '[Xe]', valence: '4f14 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Lu': { Z: 71, config: '[Xe] 4f14 5d1 6s2', core: '[Xe] 4f14', valence: '5d1 6s2', rcut: [2.4, 2.4, 2.4], orbitals: ['5D', '6S', '6P'] },
    'Hf': { Z: 72, config: '[Xe] 4f14 5d2 6s2', core: '[Xe] 4f14', valence: '5d2 6s2', rcut: [2.3, 2.3, 2.3], orbitals: ['5D', '6S', '6P'] },
    'Ta': { Z: 73, config: '[Xe] 4f14 5d3 6s2', core: '[Xe] 4f14', valence: '5d3 6s2', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'W':  { Z: 74, config: '[Xe] 4f14 5d4 6s2', core: '[Xe] 4f14', valence: '5d4 6s2', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'Re': { Z: 75, config: '[Xe] 4f14 5d5 6s2', core: '[Xe] 4f14', valence: '5d5 6s2', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'Os': { Z: 76, config: '[Xe] 4f14 5d6 6s2', core: '[Xe] 4f14', valence: '5d6 6s2', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'Ir': { Z: 77, config: '[Xe] 4f14 5d7 6s2', core: '[Xe] 4f14', valence: '5d7 6s2', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'Pt': { Z: 78, config: '[Xe] 4f14 5d9 6s1', core: '[Xe] 4f14', valence: '5d9 6s1', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'Au': { Z: 79, config: '[Xe] 4f14 5d10 6s1', core: '[Xe] 4f14', valence: '5d10 6s1', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'Hg': { Z: 80, config: '[Xe] 4f14 5d10 6s2', core: '[Xe] 4f14', valence: '5d10 6s2', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'Tl': { Z: 81, config: '[Xe] 4f14 5d10 6s2 6p1', core: '[Xe] 4f14 5d10', valence: '6s2 6p1', rcut: [2.5, 2.5], orbitals: ['6S', '6P'] },
    'Pb': { Z: 82, config: '[Xe] 4f14 5d10 6s2 6p2', core: '[Xe] 4f14 5d10', valence: '6s2 6p2', rcut: [2.4, 2.4], orbitals: ['6S', '6P'] },
    'Bi': { Z: 83, config: '[Xe] 4f14 5d10 6s2 6p3', core: '[Xe] 4f14 5d10', valence: '6s2 6p3', rcut: [2.4, 2.4], orbitals: ['6S', '6P'] },
    'Po': { Z: 84, config: '[Xe] 4f14 5d10 6s2 6p4', core: '[Xe] 4f14 5d10', valence: '6s2 6p4', rcut: [2.3, 2.3], orbitals: ['6S', '6P'] },
    'At': { Z: 85, config: '[Xe] 4f14 5d10 6s2 6p5', core: '[Xe] 4f14 5d10', valence: '6s2 6p5', rcut: [2.3, 2.3], orbitals: ['6S', '6P'] },
    'Rn': { Z: 86, config: '[Xe] 4f14 5d10 6s2 6p6', core: '[Xe] 4f14 5d10', valence: '6s2 6p6', rcut: [2.3, 2.3], orbitals: ['6S', '6P'] },
    
    // Période 7 - Actinides
    'Fr': { Z: 87, config: '[Rn] 7s1', core: '[Rn]', valence: '7s1', rcut: [3.2], orbitals: ['7S'] },
    'Ra': { Z: 88, config: '[Rn] 7s2', core: '[Rn]', valence: '7s2', rcut: [3.0], orbitals: ['7S'] },
    'Ac': { Z: 89, config: '[Rn] 6d1 7s2', core: '[Rn]', valence: '6d1 7s2', rcut: [2.8, 2.8, 2.8], orbitals: ['6D', '7S', '7P'] },
    'Th': { Z: 90, config: '[Rn] 6d2 7s2', core: '[Rn]', valence: '6d2 7s2', rcut: [2.6, 2.6, 2.6], orbitals: ['6D', '7S', '7P'] },
    'Pa': { Z: 91, config: '[Rn] 5f2 6d1 7s2', core: '[Rn]', valence: '5f2 6d1 7s2', rcut: [2.6, 2.6, 2.6, 2.6], orbitals: ['5F', '6D', '7S', '7P'] },
    'U':  { Z: 92, config: '[Rn] 5f3 6d1 7s2', core: '[Rn]', valence: '5f3 6d1 7s2', rcut: [2.5, 2.5, 2.5, 2.5], orbitals: ['5F', '6D', '7S', '7P'] },
    'Np': { Z: 93, config: '[Rn] 5f4 6d1 7s2', core: '[Rn]', valence: '5f4 6d1 7s2', rcut: [2.5, 2.5, 2.5, 2.5], orbitals: ['5F', '6D', '7S', '7P'] },
    'Pu': { Z: 94, config: '[Rn] 5f6 7s2', core: '[Rn]', valence: '5f6 7s2', rcut: [2.5, 2.5, 2.5], orbitals: ['5F', '7S', '7P'] },
    'Am': { Z: 95, config: '[Rn] 5f7 7s2', core: '[Rn]', valence: '5f7 7s2', rcut: [2.5, 2.5, 2.5], orbitals: ['5F', '7S', '7P'] },
    'Cm': { Z: 96, config: '[Rn] 5f7 6d1 7s2', core: '[Rn]', valence: '5f7 6d1 7s2', rcut: [2.5, 2.5, 2.5, 2.5], orbitals: ['5F', '6D', '7S', '7P'] },
};

/**
 * Type de pseudo par défaut (aligné sur genererLD1Input : US si électrons d ou Z ≥ 37).
 */
function defaultPseudoTypeForElement(element) {
    const elem = ELEMENTS_LD1[element];
    if (!elem) return 'NC';
    const val = (elem.valence || '').toLowerCase();
    if (/\dd/.test(val) || /d\d/.test(val)) return 'US';
    if (elem.Z >= 37) return 'US';
    // Ga–Kr (Z 31–36) : valence typiquement s/p sans d explicite — ld1 NC peut passer ld1_setup puis échouer au test PS-KS
    if (elem.Z >= 31 && elem.Z <= 36 && !/[0-9]d/.test(val)) return 'US';
    return 'NC';
}

/**
 * Guide contextuel (affiché dans la modale) : orientation type de pseudo + ressources externes
 * selon Z et la valence (d/f).
 * @param {string} element Symbole (ex. 'Co')
 * @param {object} elem Entrée ELEMENTS_LD1 ou objet minimal { Z, valence, config }
 */
function buildHtmlGuideRecommandationPseudo(element, elem) {
    if (!elem || typeof elem.Z !== 'number') return '';
    const Z = elem.Z;
    const val = (elem.valence || '').toLowerCase();
    const hasDval = /\dd/.test(val) || /d\d/.test(val);
    const hasFval = /\df/.test(val) || /f\d/.test(val) || /[0-9]f/.test(val);

    let tier = '';
    let recoType = '';
    let ld1Note = '';
    let extra = '';

    if (Z >= 89) {
        tier = 'Actinides (Z ≥ 89)';
        recoType = 'US ou PAW ; génération ld1.x souvent délicate — catalogues spécialisés recommandés.';
        ld1Note = 'Pour du NC ou des jeux validés, préférez des bibliothèques (PseudoDojo, littérature) plutôt qu’une génération seule.';
    } else if (Z >= 57 && Z <= 71) {
        tier = 'Lanthanides (Z 57–71)';
        recoType = 'US ou PAW ; 4f/5d demandent des pseudos soigneusement testés.';
        ld1Note = 'Les jeux pré-construits (PseudoDojo, SSSP) sont en général plus sûrs que ld1.x « from scratch ».';
    } else if (Z >= 21 && Z <= 30) {
        tier = 'Série 3d (Sc–Zn)';
        recoType = 'US ou PAW : choix le plus robuste avec ld1.x pour les solides. Le NC est possible (sélection manuelle) mais échoue fréquemment au test PS-KS.';
        ld1Note = 'Pour un NC fiable : PseudoDojo / PSLibrary NC. Vous pouvez quand même générer un ld1.in NC ici (avertissement affiché).';
    } else if (Z >= 39 && Z <= 48) {
        tier = 'Série 4d (Y–Cd)';
        recoType = hasDval || Z <= 46 ? 'US ou PAW recommandés (valence d).' : 'NC souvent possible ; US reste une option sûre pour les métaux.';
        ld1Note = hasDval ? 'ld1.x + NC peut être instable : envisager US/PAW ou un pseudo catalogue.' : '';
    } else if (Z >= 72 && Z <= 80) {
        tier = 'Série 5d (Hf–Hg)';
        recoType = 'US ou PAW ; relativité scalaire (rel=1) adaptée.';
        ld1Note = 'Vérifier ecutwfc et la convergence ; catalogues (PseudoDojo, SSSP) utiles en complément.';
    } else if (Z >= 81) {
        tier = 'Éléments lourds (Z ≥ 81)';
        recoType = 'US ou PAW ; NC seulement via pseudos éprouvés (bibliothèques).';
        ld1Note = 'Relativité scalaire en général nécessaire (Z élevé).';
    } else if (Z >= 31 && Z <= 36) {
        tier = 'Fin 3e / 4e période (Ga–Kr)';
        recoType = 'NC généralement adapté pour ld1 ; US possible si besoin de basse coupure en énergie.';
        ld1Note = '';
    } else if (Z <= 20) {
        tier = 'Éléments légers à alcalino-terreux (Z ≤ 20)';
        recoType = 'NC très courant et adapté ; US/PAW si vous optimisez le coût en ecutwfc.';
        ld1Note = '';
    } else {
        tier = 'Bloc p / principal (autres Z)';
        recoType = 'NC souvent suffisant ; passez à US/PAW si la valence contient des électrons d ou f.';
        ld1Note = hasDval || hasFval ? 'Présence d’ou f dans la valence : privilégier US/PAW ou pseudos catalogue.' : '';
    }

    if (hasFval) {
        extra = '<p class="ld1-reco-fblock"><strong>f</strong> en valence : pseudos très sensibles — utilisez des jeux validés (PseudoDojo, articles) et vérifiez toujours la convergence.</p>';
    }

    const biblio = `
        <ul class="ld1-reco-links">
            <li><a href="https://www.pseudo-dojo.org/" target="_blank" rel="noopener noreferrer">PseudoDojo</a> — pseudos norme-conservants et variantes (UPF), largement utilisés avec Quantum ESPRESSO.</li>
            <li><a href="https://www.materialscloud.org/work/tools/sssp" target="_blank" rel="noopener noreferrer">SSSP (Materials Cloud)</a> — jeux PBE testés pour <code>pw.x</code>.</li>
            <li><a href="https://www.quantum-espresso.org/pseudopotentials" target="_blank" rel="noopener noreferrer">Quantum ESPRESSO — Pseudopotentials</a> — point d’entrée officiel et bibliothèques.</li>
        </ul>
    `;

    return `
        <div id="pseudo_reco_guide_z" class="ld1-reco-guide">
            <div class="ld1-reco-guide-head">
                <span class="ld1-reco-icon" aria-hidden="true">🧭</span>
                <strong class="ld1-reco-title">Quel pseudo pour ${element} ?</strong>
                <span class="ld1-reco-tier">${tier}</span>
            </div>
            <p class="ld1-reco-main">
                <strong>Recommandation</strong> — ${recoType}
            </p>
            ${ld1Note ? `<p class="ld1-reco-note">${ld1Note}</p>` : ''}
            ${extra}
            <div class="ld1-reco-biblio-wrap">
                <div class="ld1-reco-biblio-title">Hors génération ld1.x — pseudos catalogue (NC testés, SSSP, etc.)</div>
                ${biblio}
            </div>
        </div>
    `;
}

/**
 * Types de pseudopotentiels disponibles dans Quantum ESPRESSO
 * pseudotype dans ld1.x: 1=NC, 2=US, 3=PAW
 */
const PSEUDO_TYPES = {
    // Norm-Conserving
    'NC': { 
        name: 'Norm-Conserving (NC)', 
        code: 1,
        description: 'Standard, très précis, ecutwfc typique: 60-80 Ry',
        suffix: 'nc'
    },
    'NCPP': { 
        name: 'Norm-Conserving (NCPP)', 
        code: 1,
        description: 'Identique à NC, notation alternative',
        suffix: 'ncpp'
    },
    'TM': { 
        name: 'Troullier-Martins', 
        code: 1,
        description: 'NC avec schéma Troullier-Martins, très lisse',
        suffix: 'tm'
    },
    'RRKJ': { 
        name: 'RRKJ (Rappe-Rabe-Kaxiras-Joannopoulos)', 
        code: 1,
        description: 'NC optimisé pour la transférabilité',
        suffix: 'rrkj'
    },
    'MT': { 
        name: 'Martins-Troullier', 
        code: 1,
        description: 'Variante MT du NC',
        suffix: 'mt'
    },
    
    // Ultrasoft
    'US': { 
        name: 'Ultrasoft (US)', 
        code: 2,
        description: 'ecutwfc plus bas (25-40 Ry), bon pour métaux de transition',
        suffix: 'us'
    },
    'USPP': { 
        name: 'Ultrasoft (USPP)', 
        code: 2,
        description: 'Identique à US, notation Vanderbilt',
        suffix: 'uspp'
    },
    'RRKJUS': { 
        name: 'RRKJ Ultrasoft', 
        code: 2,
        description: 'Ultrasoft avec optimisation RRKJ',
        suffix: 'rrkjus'
    },
    
    // PAW
    'PAW': { 
        name: 'PAW (Projector Augmented Wave)', 
        code: 3,
        description: 'Très précis, reconstruit la fonction d\'onde all-electron',
        suffix: 'paw'
    },
    'KJPAW': { 
        name: 'Kresse-Joubert PAW', 
        code: 3,
        description: 'PAW avec formulation KJ',
        suffix: 'kjpaw'
    },
    
    // Coulomb
    'COULOMB': { 
        name: 'Coulomb (All-Electron)', 
        code: 0,
        description: 'Potentiel coulombien pur, pas de pseudo',
        suffix: 'ae'
    }
};

/**
 * Fonctionnelles d'échange-corrélation disponibles dans Quantum ESPRESSO
 * Référence: Modules/funct.f90 dans QE
 */
const FUNCTIONALS = {
    // LDA (Local Density Approximation)
    'LDA': { 
        name: 'LDA (Perdew-Zunger)', 
        dft: 'PZ',
        iexch: 1, icorr: 1, igcx: 0, igcc: 0,
        description: 'LDA standard Perdew-Zunger 1981'
    },
    'PZ': { 
        name: 'Perdew-Zunger', 
        dft: 'PZ',
        iexch: 1, icorr: 1, igcx: 0, igcc: 0,
        description: 'LDA Perdew-Zunger (identique à LDA)'
    },
    'VWN': { 
        name: 'Vosko-Wilk-Nusair', 
        dft: 'VWN',
        iexch: 1, icorr: 4, igcx: 0, igcc: 0,
        description: 'LDA VWN'
    },
    'PW': { 
        name: 'Perdew-Wang', 
        dft: 'PW',
        iexch: 1, icorr: 4, igcx: 0, igcc: 0,
        description: 'LDA Perdew-Wang 1992'
    },
    
    // GGA (Generalized Gradient Approximation)
    'PBE': { 
        name: 'PBE', 
        dft: 'PBE',
        iexch: 1, icorr: 4, igcx: 3, igcc: 4,
        description: 'GGA Perdew-Burke-Ernzerhof 1996 - Le plus utilisé'
    },
    'PBEsol': { 
        name: 'PBEsol', 
        dft: 'PBESOL',
        iexch: 1, icorr: 4, igcx: 10, igcc: 8,
        description: 'PBE révisé pour les solides - meilleurs paramètres de maille'
    },
    'revPBE': { 
        name: 'revPBE', 
        dft: 'REVPBE',
        iexch: 1, icorr: 4, igcx: 4, igcc: 4,
        description: 'PBE révisé Zhang-Yang'
    },
    'RPBE': { 
        name: 'RPBE', 
        dft: 'RPBE',
        iexch: 1, icorr: 4, igcx: 1, igcc: 4,
        description: 'PBE révisé Hammer-Hansen-Nørskov'
    },
    'PW91': { 
        name: 'PW91', 
        dft: 'PW91',
        iexch: 1, icorr: 4, igcx: 2, igcc: 2,
        description: 'GGA Perdew-Wang 1991'
    },
    'BLYP': { 
        name: 'BLYP', 
        dft: 'BLYP',
        iexch: 1, icorr: 3, igcx: 1, igcc: 3,
        description: 'Becke exchange + Lee-Yang-Parr correlation'
    },
    'BP': { 
        name: 'BP86', 
        dft: 'BP',
        iexch: 1, icorr: 4, igcx: 1, igcc: 1,
        description: 'Becke88 exchange + Perdew86 correlation'
    },
    'HCTH': { 
        name: 'HCTH', 
        dft: 'HCTH',
        iexch: 0, icorr: 0, igcx: 5, igcc: 5,
        description: 'Hamprecht-Cohen-Tozer-Handy'
    },
    'OLYP': { 
        name: 'OLYP', 
        dft: 'OLYP',
        iexch: 0, icorr: 3, igcx: 6, igcc: 3,
        description: 'OPTX exchange + LYP correlation'
    },
    'WC': { 
        name: 'Wu-Cohen', 
        dft: 'WC',
        iexch: 1, icorr: 4, igcx: 11, igcc: 4,
        description: 'GGA Wu-Cohen - bon pour ferroélectriques'
    },
    'SOGGA': { 
        name: 'SOGGA', 
        dft: 'SOGGA',
        iexch: 1, icorr: 4, igcx: 12, igcc: 4,
        description: 'Second-order GGA'
    },
    'Q2D': { 
        name: 'Q2D', 
        dft: 'Q2D',
        iexch: 1, icorr: 4, igcx: 19, igcc: 4,
        description: 'GGA pour systèmes quasi-2D'
    },
    
    // Meta-GGA
    'TPSS': { 
        name: 'TPSS', 
        dft: 'TPSS',
        iexch: 1, icorr: 4, igcx: 7, igcc: 6,
        description: 'Meta-GGA Tao-Perdew-Staroverov-Scuseria'
    },
    'M06L': { 
        name: 'M06-L', 
        dft: 'M06L',
        iexch: 0, icorr: 0, igcx: 0, igcc: 0,
        description: 'Meta-GGA Minnesota M06-L'
    },
    'TB09': { 
        name: 'TB09 (mBJ)', 
        dft: 'TB09',
        iexch: 0, icorr: 0, igcx: 0, igcc: 0,
        description: 'Tran-Blaha modified Becke-Johnson - bon pour band gaps'
    },
    'SCAN': { 
        name: 'SCAN', 
        dft: 'SCAN',
        iexch: 0, icorr: 0, igcx: 0, igcc: 0,
        description: 'Strongly Constrained and Appropriately Normed'
    },
    'R2SCAN': { 
        name: 'r2SCAN', 
        dft: 'R2SCAN',
        iexch: 0, icorr: 0, igcx: 0, igcc: 0,
        description: 'Regularized SCAN - plus stable'
    },
    
    // Hybrides (pour référence, pas pour ld1.x)
    'PBE0': { 
        name: 'PBE0', 
        dft: 'PBE0',
        iexch: 6, icorr: 4, igcx: 8, igcc: 4,
        description: 'Hybride PBE avec 25% HF exchange'
    },
    'B3LYP': { 
        name: 'B3LYP', 
        dft: 'B3LYP',
        iexch: 7, icorr: 0, igcx: 0, igcc: 0,
        description: 'Hybride Becke 3-parameter'
    },
    'HSE': { 
        name: 'HSE06', 
        dft: 'HSE',
        iexch: 0, icorr: 0, igcx: 0, igcc: 0,
        description: 'Hybride range-separated Heyd-Scuseria-Ernzerhof'
    },
    
    // Van der Waals (vdW-DF)
    'VDW-DF': { 
        name: 'vdW-DF', 
        dft: 'VDW-DF',
        iexch: 1, icorr: 4, igcx: 4, igcc: 0,
        description: 'Van der Waals density functional'
    },
    'VDW-DF2': { 
        name: 'vdW-DF2', 
        dft: 'VDW-DF2',
        iexch: 1, icorr: 4, igcx: 13, igcc: 0,
        description: 'vdW-DF version 2'
    },
    'RVDW-DF2': { 
        name: 'rev-vdW-DF2', 
        dft: 'RVVDW-DF2',
        iexch: 1, icorr: 4, igcx: 13, igcc: 0,
        description: 'vdW-DF2 révisé'
    },
    'VDW-DF-C09': { 
        name: 'vdW-DF-C09', 
        dft: 'VDW-DF-C09',
        iexch: 1, icorr: 4, igcx: 16, igcc: 0,
        description: 'vdW-DF avec exchange C09'
    },
    'VDW-DF-OB86': { 
        name: 'vdW-DF-optB86b', 
        dft: 'VDW-DF-OB86',
        iexch: 1, icorr: 4, igcx: 22, igcc: 0,
        description: 'vdW-DF avec optB86b exchange'
    },
    'VDW-DF-OBK8': { 
        name: 'vdW-DF-optB88', 
        dft: 'VDW-DF-OBK8',
        iexch: 1, icorr: 4, igcx: 23, igcc: 0,
        description: 'vdW-DF avec optB88 exchange'
    },
    'RVV10': { 
        name: 'rVV10', 
        dft: 'RVV10',
        iexch: 1, icorr: 4, igcx: 13, igcc: 0,
        description: 'Revised VV10 non-local correlation'
    }
};

/**
 * Générer le fichier ld1.in pour un élément
 */
function genererLD1Input(element, options = {}) {
    const elem = ELEMENTS_LD1[element];
    if (!elem) {
        console.error(`Élément ${element} non trouvé dans la base de données`);
        genererLD1Input.lastMeta = { warnings: [], error: 'unknown_element' };
        return null;
    }

    genererLD1Input.lastMeta = {
        warnings: [],
        upgradedFromNC: false,
        pseudoTypeRequested: options.pseudoType,
        pseudoTypeEffective: null
    };
    
    // Par défaut : même logique que defaultPseudoTypeForElement (évite duplication)
    const defaultPseudoType = options.pseudoType ? options.pseudoType : defaultPseudoTypeForElement(element);

    // Métaux 3d (Sc–Zn) : ld1.x + NC échoue souvent au test PS-KS — on avertit mais on respecte le choix explicite.
    const is3dMetal = elem.Z >= 21 && elem.Z <= 30;
    const explicitPseudoChoice = options.pseudoType != null && String(options.pseudoType).trim() !== '';
    let effectivePseudoType = defaultPseudoType;
    if (effectivePseudoType === 'NC' && is3dMetal) {
        if (explicitPseudoChoice || options.forceNC3d) {
            genererLD1Input.lastMeta.warnings.push(
                'Métaux 3d (Sc–Zn) en NC : ld1.x échoue souvent au test PS-KS — préférez US/PAW ou un NC catalogue (PseudoDojo, PSLibrary NC).'
            );
        } else if (!options.forceNC3d) {
            effectivePseudoType = 'US';
            genererLD1Input.lastMeta.upgradedFromNC = true;
            genererLD1Input.lastMeta.warnings.push(
                'Type par défaut NC remplacé par US pour Sc–Zn (ld1.x NC instable). Choisissez explicitement NC dans la liste pour forcer le norme-conservant.'
            );
        }
    }
    genererLD1Input.lastMeta.pseudoTypeEffective = effectivePseudoType;

    const elemWork = Object.assign({}, elem);
    if (isLanthanideZ(elem.Z)) {
        elemWork.valence = getLanthanideValenceForLd1(elem);
        if (effectivePseudoType === 'NC' && !options.relativistic) {
            options.relativistic = 'full';
            genererLD1Input.lastMeta.warnings.push(
                'Lanthanide NC : relativité « full » (rel=2) activée — indispensable pour 4f/5d.'
            );
        }
        genererLD1Input.lastMeta.warnings.push(
            'Lanthanide : r_c(4f) cible 1.8–2.3 bohr ; si ghost dans ld1.out, ajuster ou utiliser ONCVPSP / PseudoDojo.'
        );
    }

    // Options par défaut (effectivePseudoType prime sur options.pseudoType si upgrade NC→US)
    const config = {
        ...options,
        pseudoType: effectivePseudoType,
        functional: options.functional || 'PBE',
        relativistic: options.relativistic || (elemWork.Z > 36 ? 'scalar' : 'no'),
        rcut: options.rcut || elemWork.rcut,
        ecutwfc: options.ecutwfc || 60,
        ecutrho: options.ecutrho || 600
    };
    
    const func = FUNCTIONALS[config.functional];
    const dftName = (func && func.dft) ? func.dft : config.functional;
    // Tag pour le nom de fichier (QE Library utilise pz pour LDA)
    const functionalTag = (() => {
        const d = String(dftName || config.functional || '').toLowerCase();
        if (d === 'pbesol') return 'pbesol';
        if (d === 'pz' || d === 'lda') return 'pz';
        if (d === 'pbe') return 'pbe';
        return String(config.functional || '').toLowerCase();
    })();
    
    // Construire le fichier ld1.in basé sur les exemples QE (pseudo_library)
    // pseudotype: 1=NC, 2=US (RRKJ), 3=PAW
    // lloc: canal local (généralement 2=d)
    const isPAW = config.pseudoType === 'PAW';
    const isUS = config.pseudoType === 'US' || config.pseudoType === 'RRKJ';
    const isNC = config.pseudoType === 'NC';
    const isLanth = isLanthanideZ(elemWork.Z);

    // Déterminer le type numérique
    let pseudoTypeNum = 2;  // US par défaut
    if (isPAW) pseudoTypeNum = 3;
    else if (isNC) pseudoTypeNum = 1;
    else if (isUS) pseudoTypeNum = 2;
    
    // Déterminer le suffixe du nom de fichier selon le type
    let suffix = 'us';  // Par défaut
    if (pseudoTypeNum === 3) suffix = 'paw';
    else if (pseudoTypeNum === 1) suffix = 'nc';
    else if (pseudoTypeNum === 2) suffix = 'us';
    
    // lloc = 2 (d comme canal local) comme dans les exemples QE
    const lloc = 2;

    let rclocBase = config.rcut ? config.rcut[0] || 2.0 : 2.0;
    if (is3dMetal) {
        rclocBase = Math.max(rclocBase, isNC ? 2.55 : 2.2);
    }
    
    // Formater la config comme QE: "[Ne] 3s2.0 3p2.0 3d-2.0" avec décimaux
    let configFormatted = formatConfigQE(elemWork);
    // Si genererSectionOrbitales ajoute une coquille p vide (métaux d), la même coquille doit
    // apparaître dans config= pour que ld1 trouve l’onde AE (sinon erreur ld1_setup :
    // "no all electron for this ps", voir QE atomic/src/ld1_setup.f90).
    configFormatted = augmenterConfigPourOrbitalesSynthetiques(elemWork, configFormatted);
    
    // Relativistic: 0=non-rel, 1=scalar, 2=full (lanthanides NC : rel=2 recommandé)
    let relNum = config.relativistic === 'full' ? 2 : (config.relativistic === 'scalar' || elemWork.Z > 36 ? 1 : 0);
    if (isLanth && isNC && relNum < 2) relNum = 2;
    
    // Format exact comme les exemples QE
    let ld1Input = ` &input
    title='${element}',
    zed=${elem.Z}.0,
    rel=${relNum},
    config='${configFormatted}',
    iswitch=3,
    dft='${dftName}'
 /
 &inputp
   pseudotype=${pseudoTypeNum},
   file_pseudopw='${element}.${functionalTag}-${suffix}.UPF',
   author='QE Interface',
   lloc=-1,
   rcloc=${rclocBase},
   new_core_ps=.true.${(isUS || isPAW) ? ',\n   tm=.true.' : ''}${isNC ? ',\n   rho0=0.001' : ''}${isNC && is3dMetal ? ',\n   tm=.true.' : ''}
 /
`;

    // Ajouter les orbitales (toujours nécessaires, même pour PAW)
    // NOTE: genererSectionOrbitales() ne termine pas par \n (pour éviter une ligne vide finale),
    // donc si on ajoute une section après, il faut insérer un saut de ligne.
    ld1Input += genererSectionOrbitales(elemWork, config);
    
    // Section &test: seulement pour US/PAW, pas pour NC
    // D'après FORMAT_LD1_CORRECT.md, avec iswitch=3, &test n'est pas nécessaire pour NC
    // et peut causer des erreurs "Errors in PS-KS equation"
    if (!isNC) {
        const testConfig = elemWork.valence || elemWork.config || 'default';
        ld1Input += `\n &test
   nconf=1
   file_pseudo='${element}.${functionalTag}-${suffix}.UPF'
   configts(1)='${testConfig}'
 /
`;
    }
    
    return ld1Input;
}

/**
 * Pour chaque orbitale de computeAllOrbitalsForLd1 avec occupation ≤ 0 (coquille vide ou non liée),
 * garantit la présence dans config= d’un état « nlx0 » correspondant si la coquille n’y figure pas déjà
 * (ex. 3d10 compte pour n=3,l=d — pas besoin de 3d0 en plus).
 * Évite ld1_setup : « no all electron for this ps » pour tout élément (atomic/src/ld1_setup.f90).
 */
function augmenterConfigPourOrbitalesSynthetiques(elem, configFormatted) {
    let out = (configFormatted || '').trim();
    const lLetters = ['s', 'p', 'd', 'f'];
    const orbs = computeAllOrbitalsForLd1(elem);

    for (const orb of orbs) {
        if (orb.occ > 0) continue;
        const L = lLetters[orb.lNum] || 's';
        const re = new RegExp('(^|\\s)' + orb.n + L + '[0-9.]', 'i');
        if (!re.test(out)) {
            out = (out + ' ' + orb.n + L + '0').trim();
        }
    }
    return out;
}

/**
 * Formater la configuration électronique au format QE
 * Exemple: "[Ar] 3d10.0 4s2.0 4p1.0 4d-2.0" (avec décimaux, format QE standard)
 */
function formatConfigQE(elem) {
    // ld1.x peut échouer si config contient un core du style "[Ar] 3d10 4s1".
    // On convertit donc les cores [He]/[Ne]/[Ar]/[Kr]/[Xe]/[Rn] en configuration explicite
    // et on évite d'ajouter des orbitales "unbound" (ex: 4d-2) dans config=.
    const fullConfig = (elem && elem.config) ? String(elem.config).trim() : '';

    const CORE_MAP = {
        'He': '1s2',
        'Ne': '1s2 2s2 2p6',
        'Ar': '1s2 2s2 2p6 3s2 3p6',
        'Kr': '1s2 2s2 2p6 3s2 3p6 3d10 4s2 4p6',
        'Xe': '1s2 2s2 2p6 3s2 3p6 3d10 4s2 4p6 4d10 5s2 5p6',
        'Rn': '1s2 2s2 2p6 3s2 3p6 3d10 4s2 4p6 4d10 4f14 5s2 5p6 5d10 6s2 6p6'
    };

    let expandedCore = '';
    let rest = fullConfig;
    const coreMatch = rest.match(/\[([A-Za-z]+)\]/);
    if (coreMatch) {
        const coreSym = coreMatch[1];
        expandedCore = CORE_MAP[coreSym] || '';
        rest = rest.replace(/\[.*?\]\s*/, '').trim();
    }

    const tokens = [];
    if (expandedCore) tokens.push(...expandedCore.split(/\s+/).filter(Boolean));

    // Orbitales restantes: tolère 3d10, 3d10.0, 4d-2
    const orbRegex = /(\d+)\s*([spdfSPDF])\s*([+-]?\d+(?:\.\d+)?)/g;
    let m;
    while ((m = orbRegex.exec(rest)) !== null) {
        const n = m[1];
        const l = m[2].toLowerCase();
        const occRaw = String(m[3]).replace(/\.0+$/, '');
        // Éviter les occupations négatives dans config= (les états unbound doivent être gérés dans la section orbitales)
        if (occRaw.startsWith('-')) continue;
        tokens.push(`${n}${l}${occRaw}`);
    }

    return tokens.join(' ').trim();
}

/**
 * Lanthanides / actinides, f en valence, sans d en valence (ex. Eu 4f7 6s2) :
 * ne pas ajouter un 6D vide (souvent compute_phi / compute_chi en US/PAW).
 */
function isLanthOrActinOpenFWithoutValenceD(elem) {
    const v = String(elem.valence || '').replace(/\s+/g, '');
    const Z = elem.Z;
    const hasF = /\d[fF]\d/.test(v);
    const hasD = /\d[dD]\d/.test(v);
    if (!hasF || hasD) return false;
    return (Z >= 58 && Z <= 70) || (Z >= 90 && Z <= 102);
}

/** Traitement 4f pour lanthanides NC : ``valence_f`` | ``open_core`` (window.gpLanthanideFTreatment). */
window.gpLanthanideFTreatment = window.gpLanthanideFTreatment || 'valence_f';

function isLanthanideZ(Z) {
    return Z >= 57 && Z <= 71;
}

function getLanthanideValenceForLd1(elem) {
    if (!elem || !isLanthanideZ(elem.Z)) return elem.valence || '';
    var mode = (window.gpLanthanideFTreatment || 'valence_f').toLowerCase();
    var openCore = {
        La: '5d1 6s2', Ce: '5d1 6s2', Pr: '6s2', Nd: '6s2', Pm: '6s2', Sm: '6s2', Eu: '6s2',
        Gd: '5d1 6s2', Tb: '6s2', Dy: '6s2', Ho: '6s2', Er: '6s2', Tm: '6s2', Yb: '6s2', Lu: '5d1 6s2'
    };
    var valF = {
        La: '5d1 6s2', Ce: '4f1 5d1 6s2', Pr: '4f3 6s2', Nd: '4f4 6s2', Pm: '4f5 6s2', Sm: '4f6 6s2',
        Eu: '4f7 6s2', Gd: '4f7 5d1 6s2', Tb: '4f9 6s2', Dy: '4f10 6s2', Ho: '4f11 6s2', Er: '4f12 6s2',
        Tm: '4f13 6s2', Yb: '4f14 6s2', Lu: '5d1 6s2'
    };
    var sym = Object.keys(ELEMENTS_LD1).find(function (k) { return ELEMENTS_LD1[k] === elem; });
    if (!sym && elem.Z) {
        sym = Object.keys(ELEMENTS_LD1).find(function (k) { return ELEMENTS_LD1[k].Z === elem.Z; });
    }
    if (!sym) return elem.valence || '';
    if (mode === 'open_core' || mode === 'open' || mode === 'core') return openCore[sym] || elem.valence;
    return valF[sym] || elem.valence;
}

/** Terres rares / actinides avec f en valence : rcut f réduits. */
function isLanthActinWithValenceF(elem) {
    const v = String(elem.valence || '').replace(/\s+/g, '');
    const Z = elem.Z;
    if (!/\d[fF]\d/.test(v)) return false;
    return (Z >= 58 && Z <= 70) || (Z >= 90 && Z <= 102);
}

/**
 * Liste des orbitales pour ld1 (même logique partout) : valence, coquilles non liées,
 * d vide si absent, p vide si d sans p. Tri n puis l.
 * Doit rester alignée avec augmenterConfigPourOrbitalesSynthetiques (ld1_setup).
 */
function computeAllOrbitalsForLd1(elem) {
    const valenceOrbitals = parseValenceConfig(elem.valence || '');

    const configFormatted = formatConfigQE(elem);
    const configOrbitals = parseValenceConfigWithUnbound(configFormatted);

    const allOrbitals = [...valenceOrbitals];

    configOrbitals.forEach(orb => {
        if (orb.occ <= 0) {
            const existsSameL = allOrbitals.some(o => o.lNum === orb.lNum);
            if (!existsSameL) {
                allOrbitals.push(orb);
            }
        }
    });

    const hasD = allOrbitals.some(o => o.lNum === 2);
    if (!hasD && !isLanthOrActinOpenFWithoutValenceD(elem)) {
        const nMax = Math.max(...allOrbitals.map(o => o.n), 2);
        allOrbitals.push({
            n: nMax,
            l: 'D',
            lNum: 2,
            occ: 0.0
        });
    }

    const hasP = allOrbitals.some(o => o.lNum === 1);
    if (hasD && !hasP) {
        const nMax = Math.max(...allOrbitals.map(o => o.n), 2);
        allOrbitals.push({
            n: nMax,
            l: 'P',
            lNum: 1,
            occ: 0.0
        });
    }

    allOrbitals.sort((a, b) => {
        if (a.n !== b.n) return a.n - b.n;
        return a.lNum - b.lNum;
    });

    return allOrbitals;
}

/**
 * Générer la section des orbitales pour ld1.in (format QE)
 * Format: nl  n  l  occ  E  rcut  rcutus
 */
function genererSectionOrbitales(elem, config) {
    const allOrbitals = computeAllOrbitalsForLd1(elem);
    const lowFrcut = isLanthActinWithValenceF(elem);

    let section = `${allOrbitals.length}\n`;
    
    allOrbitals.forEach((orb, i) => {
        // Rayons de coupure appropriés selon l'orbitale
        // IMPORTANT: Augmenter significativement pour éviter l'erreur "phi has nodes before r_c"
        // Les orbitales peuvent avoir des nœuds, donc rcut doit être suffisamment grand
        let rcut;
        
        // Base selon le type d'orbitale (valeurs augmentées pour éviter les nœuds)
        if (orb.lNum === 0) {
            // Orbitales s: les plus susceptibles d'avoir des nœuds
            // IMPORTANT: Pour NC, rcut doit être très grand pour éviter "phi has nodes before r_c"
            // Augmenter significativement selon n pour garantir qu'on dépasse tous les nœuds
            if (orb.n >= 5) rcut = 4.00;      // n=5,6,7... (éléments lourds) - augmenté à 4.0
            else if (orb.n >= 4) rcut = 3.50; // n=4 - augmenté à 3.5
            else if (orb.n >= 3) rcut = 3.00; // n=3 - augmenté à 3.0
            else rcut = 2.50;                  // n=1,2
        } else if (orb.lNum === 1) {
            // Orbitales p
            if (orb.n >= 5) rcut = 3.20;
            else if (orb.n >= 4) rcut = 2.80;
            else if (orb.n >= 3) rcut = 2.60;
            else rcut = 2.30;
        } else if (orb.lNum === 2) {
            // Orbitales d
            if (orb.n >= 5) rcut = 3.00;
            else if (orb.n >= 4) rcut = 2.60;
            else if (orb.n >= 3) rcut = 2.50;
            else rcut = 2.40;
        } else {
            // Orbitales f — lanthanides NC : plage méthodologique 1.8–2.3 bohr (ONCV / PseudoDojo)
            if (lowFrcut && isLanthanideZ(elem.Z)) {
                rcut = orb.n >= 4 ? 2.10 : 2.00;
                rcut = Math.max(1.80, Math.min(2.30, rcut));
            } else if (lowFrcut) {
                if (orb.n >= 5) rcut = 2.80;
                else if (orb.n >= 4) rcut = 2.55;
                else rcut = 2.45;
            } else {
                if (orb.n >= 5) rcut = 3.50;
                else if (orb.n >= 4) rcut = 3.20;
                else rcut = 2.80;
            }
        }
        
        if (elem.Z > 50) {
            if (orb.lNum === 3 && lowFrcut) {
                rcut += 0.05;
            } else {
                rcut += 0.3;
            }
        }
        
        // Override avec config si fourni (mais utiliser au minimum les valeurs ci-dessus)
        if (config.rcut && config.rcut[i]) {
            rcut = Math.max(rcut, config.rcut[i]);
        }

        // Métaux 3d (Sc–Zn) : rc plus grands (NC, US, PAW) pour limiter nœuds / PS-KS
        if (elem.Z >= 21 && elem.Z <= 30) {
            if (orb.lNum === 0 && orb.n >= 4) rcut = Math.max(rcut, 4.25);
            if (orb.lNum === 1 && orb.n >= 4) rcut = Math.max(rcut, 3.1);
            if (orb.lNum === 2 && orb.n === 3) rcut = Math.max(rcut, 2.85);
        }
        
        // IMPORTANT: Pour les orbitales non liées (occ <= 0), l'occupation doit être 0.00
        // ld1.x exige que les états "unbound" soient vides
        const occValue = orb.occ <= 0 ? 0.00 : orb.occ;
        const energy = orb.occ <= 0 ? -0.05 : 0.00;  // Energie pour orbitales non liées (-0.05)
        
        // Format QE complet: Label  n  l  occ  energy  rcut1  rcut2  rcutus
        // IMPORTANT: n est le nombre quantique principal (orb.n), pas un index !
        // Dernier champ est rcutus (0.00 pour non-ultrasoft, ou valeur si ultrasoft)
        const rcutus = 0.00;  // Rayon pour ultrasoft (0.00 par défaut)
        section += `${orb.n}${orb.l}  ${orb.n}  ${orb.lNum}  ${occValue.toFixed(2)}  ${energy.toFixed(2)}  ${rcut.toFixed(2)}  ${rcut.toFixed(2)}  ${rcutus.toFixed(2)}`;
        if (i < allOrbitals.length - 1) section += '\n';  // Pas de ligne vide à la fin
    });
    
    return section;
}

/**
 * Parser la configuration de valence
 */
function parseValenceConfig(valence) {
    const orbitals = [];
    const regex = /(\d)([spdf])(\d+)?/gi;
    let match;
    
    while ((match = regex.exec(valence)) !== null) {
        const n = parseInt(match[1]);
        const l = match[2].toLowerCase();
        const occ = match[3] ? parseInt(match[3]) : 1;
        
        const lMap = { 's': 0, 'p': 1, 'd': 2, 'f': 3 };
        const maxOcc = { 's': 2, 'p': 6, 'd': 10, 'f': 14 };
        
        orbitals.push({
            n: n,
            l: l.toUpperCase(),
            lNum: lMap[l],
            occ: Math.min(occ, maxOcc[l])
        });
    }
    
    return orbitals;
}

/**
 * Parser la configuration incluant les orbitales non liées (comme 4d-2)
 * Supporte les formats: "3d5", "4d-2", "4d-2.0"
 */
function parseValenceConfigWithUnbound(config) {
    const orbitals = [];
    // Regex pour capturer: nombre, lettre, nombre (positif ou négatif), optionnellement .nombre
    const regex = /(\d)([spdf])(-?\d+(?:\.\d+)?)/gi;
    let match;
    
    while ((match = regex.exec(config)) !== null) {
        const n = parseInt(match[1]);
        const l = match[2].toLowerCase();
        const occ = parseFloat(match[3]);  // Peut être négatif pour les orbitales non liées
        
        const lMap = { 's': 0, 'p': 1, 'd': 2, 'f': 3 };
        
        orbitals.push({
            n: n,
            l: l.toUpperCase(),
            lNum: lMap[l],
            occ: occ  // Conserver la valeur négative pour les orbitales non liées
        });
    }
    
    return orbitals;
}

/**
 * Thème modales ld1 : grille, dégradé « lab », typo lisible (system-ui + mono pour code).
 */
function ensureLd1ModalScienceStyles() {
    if (document.getElementById('ld1-modal-science-css')) return;
    const s = document.createElement('style');
    s.id = 'ld1-modal-science-css';
    s.textContent = `
@keyframes ld1-spin { to { transform: rotate(360deg); } }
.ld1-modal-backdrop {
  position: fixed; inset: 0;
  background: rgba(15, 23, 42, 0.82);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10000;
  padding: clamp(14px, 3vw, 28px);
  font-family: 'IBM Plex Sans', system-ui, sans-serif;
  font-size: 14px;
  line-height: 1.55;
  letter-spacing: 0.01em;
  color: #d8e6f0;
  -webkit-font-smoothing: antialiased;
}
#modal_readme_pseudos.ld1-modal-backdrop { z-index: 10002; }
#modal_generation.ld1-modal-backdrop { z-index: 10001; }
.ld1-modal-panel {
  position: relative;
  max-width: 1000px;
  width: min(96vw, 1000px);
  max-height: min(92vh, 920px);
  overflow: auto;
  padding: 22px 26px 20px;
  border-radius: 6px;
  border: 1px solid #3a5a7a;
  box-shadow: 0 8px 32px rgba(12, 35, 64, 0.35);
  background-color: #0c2340;
  background-image: linear-gradient(180deg, #0c2340 0%, #152d4a 100%);
}
.ld1-modal-panel ::selection {
  background: rgba(14, 116, 144, 0.35);
  color: #f8fafc;
}
.ld1-modal-title {
  margin: 0 0 10px 0;
  color: #e8eef8;
  font-size: 1.38rem;
  font-weight: 600;
  letter-spacing: -0.025em;
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
  line-height: 1.35;
}
.ld1-modal-title .ld1-atom-emoji { font-size: 1.35em; line-height: 1; opacity: 0.95; }
.ld1-modal-title-badge {
  font-size: 0.56em;
  font-weight: 500;
  color: #94a3b8;
  letter-spacing: 0.02em;
  padding: 4px 10px;
  border-radius: 999px;
  background: rgba(30, 41, 59, 0.85);
  border: 1px solid rgba(100, 116, 139, 0.35);
}
.ld1-modal-sub { margin: 0; color: #94a3b8; font-size: 0.94rem; line-height: 1.58; max-width: 62rem; }
.ld1-modal-sub code { font-family: "IBM Plex Mono", Consolas, monospace; font-size: 0.86em; color: #a8c8e0; background: #1a3a5c; padding: 2px 6px; border-radius: 2px; border: 1px solid #3a5a7a; }
.ld1-steps-strip {
  display: flex; flex-wrap: wrap; gap: 8px; align-items: center;
  margin: 16px 0 10px; padding: 12px 16px;
  background: rgba(17, 24, 39, 0.75);
  border: 1px solid rgba(71, 85, 105, 0.35);
  border-radius: 12px;
  font-size: 0.89rem;
}
.ld1-steps-strip .ld1-muted { color: #5c6d82; }
.ld1-section {
  background: rgba(17, 28, 45, 0.72);
  border: 1px solid rgba(100, 116, 139, 0.25);
  border-radius: 14px;
  padding: 20px 22px;
  margin: 20px 0;
}
.ld1-section.ld1-accent-blue { border-left: 4px solid #58a6ff; }
.ld1-section.ld1-accent-green { border-left: 4px solid #3fb950; }
.ld1-section.ld1-accent-amber { border-left: 4px solid #f0883e; }
.ld1-section-h3 { margin: 0 0 12px; font-size: 1.06rem; font-weight: 600; letter-spacing: -0.01em; }
.ld1-section.ld1-accent-blue .ld1-section-h3 { color: #fcd34d; }
.ld1-section.ld1-accent-green .ld1-section-h3 { color: #86efac; }
.ld1-section.ld1-accent-amber .ld1-section-h3 { color: #fdba74; }
.ld1-identity-table { width: 100%; border-collapse: collapse; font-size: 0.95rem; margin-top: 10px; }
.ld1-identity-table td { padding: 10px 12px; border-bottom: 1px solid rgba(80, 120, 180, 0.2); vertical-align: top; }
.ld1-identity-table td:first-child { color: #79c0ff; width: 38%; }
.ld1-identity-table code {
  font-family: "JetBrains Mono", "Fira Code", Consolas, monospace;
  font-size: 0.9rem;
  background: rgba(0, 0, 0, 0.28);
  padding: 6px 10px;
  border-radius: 6px;
  color: #d2a8ff;
  word-break: break-word;
}
.ld1-readme-inline {
  background: rgba(10, 20, 36, 0.75);
  padding: 16px 18px;
  border-radius: 12px;
  margin: 14px 0;
  border: 1px solid rgba(80, 140, 200, 0.22);
}
.ld1-readme-inline .ld1-readme-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; flex-wrap: wrap; margin-bottom: 8px; }
.ld1-readme-inline .ld1-readme-title { color: #a5d6ff; font-weight: 600; }
.ld1-qelib-box {
  margin-top: 16px;
  background: rgba(8, 16, 28, 0.75);
  border: 1px solid rgba(80, 140, 200, 0.22);
  padding: 14px 16px;
  border-radius: 10px;
}
.ld1-btn-ghost {
  background: rgba(40, 80, 130, 0.4);
  color: #e6edf3;
  border: 1px solid rgba(100, 160, 220, 0.35);
  padding: 8px 14px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.9rem;
}
.ld1-btn-ghost:hover { background: rgba(50, 100, 160, 0.55); }
.ld1-modal-panel label { color: #8ab4ff; display: block; margin-bottom: 8px; font-size: 0.92rem; }
.ld1-modal-panel select,
.ld1-modal-panel input[type="number"] {
  width: 100%;
  padding: 11px 12px;
  font-size: 14px;
  border-radius: 8px;
  background: rgba(8, 16, 30, 0.9);
  color: #e6edf3;
  border: 1px solid rgba(90, 150, 220, 0.35);
}
.ld1-modal-panel select:focus,
.ld1-modal-panel input[type="number"]:focus {
  outline: none;
  border-color: #58a6ff;
  box-shadow: 0 0 0 2px rgba(88, 166, 255, 0.25);
}
.ld1-modal-panel small { color: #7d8fa3; font-size: 0.84rem; display: block; margin-top: 6px; }
.ld1-preview-pre {
  background: #050a10;
  color: #b8e8c8;
  padding: 14px;
  border-radius: 4px;
  font-family: "IBM Plex Mono", Consolas, monospace;
  font-size: 12px;
  line-height: 1.5;
  overflow-x: auto;
  max-height: 320px;
  margin: 0;
  border: 1px solid rgba(60, 120, 180, 0.35);
  tab-size: 2;
}
#ld1_gen_notice.ld1-notice-visible { display: block !important; }
.ld1-folder-block {
  background: rgba(12, 22, 38, 0.75);
  padding: 16px 18px;
  border-radius: 10px;
  margin-top: 16px;
  border: 1px solid rgba(80, 130, 200, 0.2);
}
.ld1-folder-block strong { color: #f0c674; }
.ld1-cmd-block {
  background: linear-gradient(165deg, #1e293b 0%, #0f172a 55%, #020617 100%);
  padding: 14px 16px;
  border-radius: 10px;
  margin-top: 14px;
  border: 1px solid rgba(148, 163, 184, 0.45);
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.06);
}
.ld1-modal-panel .ld1-cmd-block code {
  font-family: "JetBrains Mono", Consolas, monospace;
  display: block;
  margin-top: 10px;
  padding: 12px 14px;
  border-radius: 8px;
  font-size: 13px;
  line-height: 1.55;
  word-break: break-all;
  white-space: pre-wrap;
  color: #fef08a;
  background: rgba(2, 6, 23, 0.92);
  border: 1px solid rgba(250, 204, 21, 0.35);
}
.ld1-btn-primary { background: #1e4976; color: #f0f4f8; border: 1px solid #0c2340; padding: 8px 14px; border-radius: 3px; cursor: pointer; font-weight: 500; }
.ld1-btn-primary:hover { background: #2e6da4; }
.ld1-btn-action-save {
  background: #1e4976;
  color: #f0f4f8;
  border: 1px solid #0c2340;
  padding: 16px 14px;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 600;
  font-size: 0.92rem;
}
.ld1-btn-action-run {
  background: #1a7f5a;
  color: #f0f4f8;
  border: 1px solid #0c4a32;
  padding: 16px 14px;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 600;
  font-size: 0.92rem;
}
.ld1-btn-close {
  background: rgba(45, 65, 95, 0.8);
  color: #e6edf3;
  border: 1px solid rgba(100, 140, 190, 0.35);
  padding: 12px 28px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.95rem;
}
.ld1-btn-close:hover { background: rgba(55, 80, 115, 0.95); }
.ld1-reco-guide {
  background: linear-gradient(145deg, rgba(16, 32, 56, 0.85) 0%, rgba(10, 20, 36, 0.92) 100%);
  padding: 16px 18px;
  border-radius: 12px;
  margin: 14px 0 6px;
  border: 1px solid rgba(80, 140, 210, 0.28);
  border-left: 4px solid #58a6ff;
}
.ld1-reco-guide-head { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; }
.ld1-reco-icon { font-size: 1.25em; }
.ld1-reco-title { color: #a5d6ff; font-size: 1.05em; }
.ld1-reco-tier { color: #7d8fa3; font-size: 0.88em; }
.ld1-reco-main { margin: 0 0 8px; color: #c9d1d9; line-height: 1.65; }
.ld1-reco-main strong { color: #7ee787; }
.ld1-reco-note { margin: 0 0 8px; color: #8b9eb3; line-height: 1.6; font-size: 0.92rem; }
.ld1-reco-fblock { margin: 10px 0 0; color: #ffa657; line-height: 1.55; }
.ld1-reco-biblio-wrap { margin-top: 12px; padding-top: 12px; border-top: 1px solid rgba(80, 120, 180, 0.25); }
.ld1-reco-biblio-title { color: #ffa657; font-weight: 600; margin-bottom: 6px; font-size: 0.95rem; }
.ld1-reco-links { margin: 8px 0 0; padding-left: 1.2em; line-height: 1.65; color: #c9d1d9; }
.ld1-reco-links a { color: #58a6ff; text-decoration: underline; text-underline-offset: 2px; }
.ld1-reco-links code { font-family: "JetBrains Mono", Consolas, monospace; font-size: 0.88em; color: #f0c674; background: rgba(0,0,0,0.25); padding: 1px 5px; border-radius: 4px; }
.ld1-guide-modal-panel .ld1-guide-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; align-items: end; margin-top: 18px; }
@media (max-width: 720px) { .ld1-guide-modal-panel .ld1-guide-grid { grid-template-columns: 1fr; } }
.ld1-guide-modal-panel label { color: #8ab4ff; font-weight: 600; display: block; margin-bottom: 6px; font-size: 0.92rem; }
.ld1-guide-modal-panel select,
.ld1-guide-modal-panel input[readonly] {
  width: 100%; padding: 10px 12px; border-radius: 8px;
  border: 1px solid rgba(90, 150, 220, 0.35);
  background: rgba(6, 14, 26, 0.95);
  color: #e6edf3;
  font-size: 14px;
}
.ld1-guide-principle { margin-top: 16px; padding: 14px 16px; border-radius: 10px; background: rgba(8, 18, 32, 0.85); border: 1px solid rgba(80, 130, 200, 0.22); }
.ld1-guide-principle h4 { color: #86efac; margin: 0 0 10px; font-size: 0.98rem; font-weight: 600; }
.ld1-guide-doc { margin-top: 16px; padding: 14px 16px; border-radius: 12px; background: rgba(17, 28, 45, 0.72); border: 1px solid rgba(100, 116, 139, 0.28); border-left: 4px solid #34d399; }
.ld1-guide-doc h4 { color: #86efac; margin: 0 0 8px; font-size: 0.98rem; font-weight: 600; }
.ld1-guide-principle-body { color: #cbd5e1; line-height: 1.65; font-size: 0.95rem; }
.ld1-guide-principle-body code {
  font-family: "JetBrains Mono", Consolas, monospace;
  color: #fde047;
  background: rgba(15, 23, 42, 0.65);
  padding: 2px 7px;
  border-radius: 5px;
  border: 1px solid rgba(71, 85, 105, 0.45);
}
.ld1-guide-doc-body { color: #cbd5e1; font-size: 0.92rem; line-height: 1.55; }
.ld1-guide-doc-body code {
  font-family: "JetBrains Mono", Consolas, monospace;
  color: #fde047;
  background: rgba(15, 23, 42, 0.55);
  padding: 2px 7px;
  border-radius: 5px;
  border: 1px solid rgba(71, 85, 105, 0.35);
}
.ld1-guide-reco-card {
  padding: 14px 16px;
  border-radius: 14px;
  background: rgba(17, 28, 45, 0.72);
  border: 1px solid rgba(100, 116, 139, 0.28);
  border-left: 4px solid #58a6ff;
}
.ld1-guide-reco-head { display: flex; gap: 12px; align-items: flex-start; justify-content: space-between; flex-wrap: wrap; }
.ld1-guide-reco-symbol { color: #fcd34d; font-weight: 700; font-size: 1.05em; letter-spacing: -0.02em; }
.ld1-guide-reco-meta { color: #e2e8f0; margin-top: 6px; line-height: 1.7; font-size: 0.95rem; }
.ld1-guide-reco-meta code {
  font-family: "JetBrains Mono", Consolas, monospace;
  color: #fde047;
  background: rgba(15, 23, 42, 0.55);
  padding: 2px 7px;
  border-radius: 5px;
  font-size: 0.92em;
}
.ld1-guide-params { min-width: 280px; }
.ld1-guide-params-title { color: #86efac; font-weight: 700; margin-bottom: 8px; font-size: 0.95rem; }
.ld1-guide-params-body { color: #e2e8f0; font-family: "JetBrains Mono", Consolas, monospace; font-size: 13px; line-height: 1.8; }
.ld1-guide-notes { margin-top: 12px; padding: 12px 14px; border-radius: 10px; background: rgba(8, 16, 28, 0.88); border: 1px solid rgba(71, 85, 105, 0.35); }
.ld1-guide-notes-title { color: #7dd3fc; font-weight: 700; margin-bottom: 6px; font-size: 0.95rem; }
.ld1-guide-notes ul { margin: 0; padding-left: 18px; color: #cbd5e1; line-height: 1.7; }
.ld1-gen-status { background: rgba(12, 24, 42, 0.75); padding: 20px; border-radius: 12px; margin: 18px 0; border: 1px solid rgba(80, 140, 200, 0.22); }
.ld1-spinner {
  width: 32px; height: 32px;
  border: 3px solid rgba(80, 130, 200, 0.35);
  border-top-color: #58a6ff;
  border-radius: 50%;
  animation: ld1-spin 0.9s linear infinite;
  flex-shrink: 0;
}
`;
    document.head.appendChild(s);
}

/**
 * Afficher le générateur de pseudopotentiel dans une modale
 * @param {string} element - Symbole de l'élément (ex: 'Si', 'Fe')
 * @param {number} Z - Numéro atomique (optionnel, sera récupéré de la base)
 * @param {number} masse - Masse atomique (optionnel)
 * @param {number} valence - Nombre d'électrons de valence (optionnel)
 */
function afficherGenerateurPseudo(element, Z, masse, valence) {
    // Supprimer l'ancienne modale si elle existe
    const oldModal = document.getElementById('modal_generateur_pseudo');
    if (oldModal) oldModal.remove();

    // Mémoriser l'élément courant (utile pour des callbacks onchange)
    window.__ld1_current_element = element;
    
    let elem = ELEMENTS_LD1[element];
    
    // Si l'élément n'est pas dans la base, créer une entrée basique
    if (!elem) {
        if (Z) {
            elem = {
                Z: Z,
                config: `[...] valence: ${valence || '?'}`,
                valence: `${valence || 0} électrons`,
                rcut: [2.0],
                orbitals: ['S', 'P']
            };
        } else {
            alert(`❌ Élément ${element} non supporté pour la génération ld1.x`);
            return;
        }
    }
    
    // Créer la modale
    ensureLd1ModalScienceStyles();
    const modal = document.createElement('div');
    modal.id = 'modal_generateur_pseudo';
    modal.className = 'ld1-modal-backdrop';

    // 📘 Bloc README affiché automatiquement à l'ouverture du générateur
    const val = (elem.valence || '').toLowerCase();
    const hasD = /\dd/.test(val) || /d\d/.test(val);
    const isHeavy = elem.Z > 36;
    const autoType = (hasD || isHeavy) ? 'US/USPP' : 'NC';
    const relReco = isHeavy ? 'rel=1 (scalaire)' : 'rel=0 (non-rel)';
    const rclocReco = (elem.rcut && elem.rcut[0]) ? elem.rcut[0] : 2.2;
    const readmeInlineHTML = `
        <details class="ld1-readme-inline" style="margin:14px 0;">
            <summary class="ld1-readme-title" style="cursor:pointer;color:#a8c8e0;font-weight:600;font-size:0.88em;">
                Aide rapide ld1.x (types NC / US / PAW)
            </summary>
            <div style="color:#c9d1d9; line-height:1.6; margin-top:10px; font-size:0.86em;">
                <p style="margin:0 0 8px;"><strong style="color:#74c69d;">${element}</strong> — type suggéré : <strong style="color:#d8e6f0;">${autoType}</strong>, ${relReco}, r<sub>c</sub> ≈ ${rclocReco} a.u.</p>
                <ul style="margin:0;padding-left:1.2em;">
                    <li><strong>US/USPP</strong> : robuste pour métaux 3d et éléments lourds.</li>
                    <li><strong>NC</strong> : précis mais peut échouer (PS-KS) sur certains éléments.</li>
                    <li><strong>PAW</strong> : haute précision ; fallback QE Library si ld1.x échoue.</li>
                </ul>
                <button type="button" class="ld1-btn-ghost" style="margin-top:10px;" onclick="event.preventDefault();ouvrirGuidePseudosLD1('${element}')">Guide détaillé</button>
            </div>
        </details>
    `;
    
    const defPt = defaultPseudoTypeForElement(element);
    
    modal.innerHTML = `
        <div class="ld1-modal-panel">
            <h2 class="ld1-modal-title">
                <span>Générateur ld1.x — <strong style="color:#f0f4f8;font-weight:600;">${element}</strong></span>
                <span class="ld1-modal-title-badge">Quantum ESPRESSO · atomic</span>
            </h2>
            <p class="ld1-modal-sub">
                Étapes : identité de l’élément → paramètres physiques (<code>&amp;input</code>, <code>&amp;inputp</code>) → fichier <code>ld1.in</code> → exécution <code>ld1.x</code> → fichier <code>.UPF</code>.
            </p>
            <div class="ld1-steps-strip">
                <span style="color:#818cf8;font-weight:600;">Parcours</span>
                <span class="ld1-muted">|</span>
                <span style="color:#86efac;font-weight:500;">① Identité</span>
                <span class="ld1-muted">→</span>
                <span style="color:#cbd5e1;">② XC · pseudo · relativité · r<sub>c</sub></span>
                <span class="ld1-muted">→</span>
                <span style="color:#cbd5e1;">③ Aperçu <code style="font-size:0.88em;">ld1.in</code></span>
                <span class="ld1-muted">→</span>
                <span style="color:#fdba74;font-weight:500;">④ Sauvegarde · API</span>
            </div>
            
            <!-- Étape 1 -->
            <div class="ld1-section ld1-accent-blue">
                <h3 class="ld1-section-h3">Étape 1 — Identité atomique et configuration</h3>
                <table class="ld1-identity-table">
                    <tr>
                        <td>Symbole</td>
                        <td style="font-weight:600;color:#e6edf3;">${element}</td>
                    </tr>
                    <tr>
                        <td>Numéro atomique <em>Z</em></td>
                        <td>${elem.Z}</td>
                    </tr>
                    <tr>
                        <td>Configuration (réf.)</td>
                        <td><code>${elem.config}</code></td>
                    </tr>
                    <tr>
                        <td>Sous-espace actif (valence)</td>
                        <td><code>${elem.valence}</code></td>
                    </tr>
                </table>
                ${buildHtmlGuideRecommandationPseudo(element, elem)}
            </div>

            ${readmeInlineHTML}
            
            <!-- Étape 2 -->
            <div class="ld1-section ld1-accent-green">
                <h3 class="ld1-section-h3">Étape 2 — Paramètres physiques (&amp;input, &amp;inputp)</h3>
                <p style="color:#8b9eb3;font-size:0.9rem;margin:6px 0 14px;">Type par défaut pour cet élément : <strong style="color:#e6edf3;">${defPt}</strong> (cohérent avec la logique de génération — modifiable ci-dessous).</p>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                    <!-- Type de pseudo -->
                    <div>
                        <label>Type de pseudopotentiel <span style="color:#7d8fa3;font-weight:normal;">(pseudotype)</span></label>
                        <select id="pseudo_type" onchange="updatePseudoTypeInfo(); actualiserPreviewLD1('${element}')">
                            <optgroup label="Norm-Conserving">
                                <option value="NC" ${defPt === 'NC' ? 'selected' : ''}>NC - Norm-Conserving (standard)</option>
                                <option value="TM">TM - Troullier-Martins</option>
                                <option value="RRKJ">RRKJ - Rappe-Rabe-Kaxiras-Joannopoulos</option>
                                <option value="MT">MT - Martins-Troullier</option>
                            </optgroup>
                            <optgroup label="Ultrasoft">
                                <option value="US" ${defPt === 'US' ? 'selected' : ''}>US - Ultrasoft (Vanderbilt)</option>
                                <option value="RRKJUS">RRKJUS - RRKJ Ultrasoft</option>
                            </optgroup>
                            <optgroup label="PAW">
                                <option value="PAW" ${defPt === 'PAW' ? 'selected' : ''}>PAW - Projector Augmented Wave</option>
                                <option value="KJPAW">KJPAW - Kresse-Joubert PAW</option>
                            </optgroup>
                        </select>
                        <small id="pseudo_type_desc">Standard, très précis, ecutwfc typique: 60-80 Ry</small>
                    </div>
                    
                    <!-- Fonctionnelle -->
                    <div>
                        <label>Fonctionnelle XC</label>
                        <select id="pseudo_functional" onchange="updateFunctionalInfo(); actualiserPreviewLD1('${element}')">
                            <optgroup label="LDA (Local Density)">
                                <option value="LDA">LDA - Perdew-Zunger</option>
                                <option value="PZ">PZ - Perdew-Zunger</option>
                                <option value="VWN">VWN - Vosko-Wilk-Nusair</option>
                                <option value="PW">PW - Perdew-Wang</option>
                            </optgroup>
                            <optgroup label="GGA (Gradient)">
                                <option value="PBE" selected>PBE - Le plus utilisé ⭐</option>
                                <option value="PBEsol">PBEsol - Meilleur pour solides</option>
                                <option value="revPBE">revPBE - Zhang-Yang</option>
                                <option value="RPBE">RPBE - Hammer-Hansen-Nørskov</option>
                                <option value="PW91">PW91 - Perdew-Wang 1991</option>
                                <option value="BLYP">BLYP - Becke-Lee-Yang-Parr</option>
                                <option value="BP">BP86 - Becke-Perdew</option>
                                <option value="WC">WC - Wu-Cohen (ferroélectriques)</option>
                                <option value="HCTH">HCTH</option>
                                <option value="OLYP">OLYP</option>
                            </optgroup>
                            <optgroup label="Meta-GGA">
                                <option value="TPSS">TPSS</option>
                                <option value="SCAN">SCAN</option>
                                <option value="R2SCAN">r2SCAN</option>
                            </optgroup>
                            <optgroup label="Van der Waals">
                                <option value="VDW-DF">vdW-DF</option>
                                <option value="VDW-DF2">vdW-DF2</option>
                                <option value="RVV10">rVV10</option>
                            </optgroup>
                        </select>
                        <small id="func_desc">GGA Perdew-Burke-Ernzerhof 1996 - Le plus utilisé</small>
                    </div>
                    
                    <!-- Relativiste -->
                    <div>
                        <label>Effets relativistes</label>
                        <select id="pseudo_rel" onchange="actualiserPreviewLD1('${element}')">
                            <option value="no" ${elem.Z <= 36 ? 'selected' : ''}>Non (Z ≤ 36)</option>
                            <option value="scalar" ${elem.Z > 36 ? 'selected' : ''}>Scalaire (recommandé Z > 36)</option>
                            <option value="full">Complet (spin-orbite)</option>
                        </select>
                    </div>
                    
                    <!-- Rayon de coupure -->
                    <div>
                        <label>Rayon de coupure (a.u.)</label>
                        <input type="number" id="pseudo_rcut" value="${elem.rcut[0]}" step="0.1" min="0.5" max="4.0"
                               onchange="actualiserPreviewLD1('${element}')">
                        <small>Plus petit = plus précis mais ecutwfc plus élevé</small>
                    </div>
                </div>

                <!-- Disponibilité QE Library (PSlibrary) -->
                <div id="qe_library_availability" class="ld1-qelib-box">
                    <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap;">
                        <div style="font-weight: 600; color: #a8c8e0;">QE Library (PSlibrary)</div>
                        <button type="button" class="ld1-btn-ghost" onclick="actualiserDisponibiliteQELibrary(true)">Vérifier</button>
                    </div>
                    <div id="qe_library_availability_text" style="margin-top: 10px; color:#c9d1d9;">
                        ⏳ Vérification…
                    </div>
                    <div style="margin-top: 8px; color:#7d8fa3; font-size: 0.84rem;">
                        Note : la bibliothèque contient surtout des variantes <strong>PBE</strong>. Si la combinaison n’existe pas, un pseudo « proche » peut être utilisé en fallback.
                    </div>
                </div>
            </div>
            
            <!-- Étape 3 -->
            <div class="ld1-section ld1-accent-amber">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; flex-wrap: wrap; gap: 10px;">
                    <h3 class="ld1-section-h3" style="margin:0;">Étape 3 — Fichier d’entrée <code style="font-size:0.95em;">ld1.in</code></h3>
                    <button type="button" class="ld1-btn-primary" onclick="actualiserPreviewLD1('${element}')">Actualiser l'aperçu</button>
                </div>
                <div id="ld1_gen_notice" style="display:none; margin-bottom:12px; padding:12px 14px; border-radius:10px; background:rgba(60,40,20,0.65); border:1px solid rgba(255,166,87,0.45); color:#ffa657; font-size:0.9rem; line-height:1.45;"></div>
                <pre id="preview_ld1" class="ld1-preview-pre">${genererLD1Input(element, { pseudoType: defPt })}</pre>
            </div>
            
            <!-- Étape 4 -->
            <div style="margin-top: 10px; padding: 4px 0 8px; color:#8b9eb3; font-size:0.92rem;">Étape 4 — Sauvegarde locale et exécution de <code style="color:#f0c674; background:rgba(0,0,0,0.25); padding:2px 6px; border-radius:4px;">ld1.x</code> via l’API</div>
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-top: 12px;">
                <button type="button" class="ld1-btn-action-save" onclick="sauvegarderInputEtScript('${element}')">
                    Sauvegarder ld1.in
                    <small style="display:block;font-weight:400;opacity:0.85;margin-top:4px;font-size:0.78em;">dossier ld1_inputs/</small>
                </button>
                <button type="button" class="ld1-btn-action-run" onclick="genererEtVisualiser('${element}')">
                    Lancer ld1.x (API)
                    <small style="display:block;font-weight:400;opacity:0.85;margin-top:4px;font-size:0.78em;">génération .UPF</small>
                </button>
            </div>
            
            <!-- Structure des dossiers -->
            <div class="ld1-folder-block">
                <strong>📁 Structure des dossiers</strong>
                <div style="margin-top: 12px; font-family: 'JetBrains Mono', Consolas, monospace; font-size: 0.88rem; line-height: 1.6;">
                    <div style="color: #58a6ff;">📂 ${LD1_CONFIG.PSEUDO_GENERES_DIR}/</div>
                    <div style="color: #7ee787; padding-left: 18px;">
                        📁 ld1_inputs/ <span style="color: #7d8fa3;">← fichiers .ld1.in et .sh</span>
                    </div>
                    <div style="color: #f0c674; padding-left: 18px;">
                        📄 *.UPF <span style="color: #7d8fa3;">← pseudopotentiels générés</span>
                    </div>
                </div>
            </div>
            
            <!-- Commande terminal -->
            <div class="ld1-cmd-block">
                <strong style="color: #fde047;">💻 Commande terminal</strong>
                <code id="cmd_ld1">
cd ${LD1_CONFIG.PSEUDO_DIR} && ${LD1_CONFIG.QE_BIN}/ld1.x < ${element}.ld1.in > ${element}.ld1.out
                </code>
            </div>
            
            <div style="text-align: right; margin-top: 22px;">
                <button type="button" class="ld1-btn-close" onclick="document.getElementById('modal_generateur_pseudo').remove()">Fermer</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);

    // Aligner prévisualisation / descriptions sur le type par défaut (defPt)
    actualiserPreviewLD1(element);
    updatePseudoTypeInfo();
    updateFunctionalInfo();

    // Vérifier la dispo QE Library dès l'ouverture
    actualiserDisponibiliteQELibrary(true);
}

/**
 * Actualiser la prévisualisation du fichier ld1.in
 */
function actualiserPreviewLD1(element) {
    const pseudoType = document.getElementById('pseudo_type')?.value || 'NC';
    const functional = document.getElementById('pseudo_functional')?.value || 'PBE';
    const relativistic = document.getElementById('pseudo_rel')?.value || 'no';
    const rcut = parseFloat(document.getElementById('pseudo_rcut')?.value) || 2.0;
    
    const ld1Content = genererLD1Input(element, {
        pseudoType,
        functional,
        relativistic,
        rcut: [rcut],
        forceNC3d: pseudoType === 'NC'
    });
    
    document.getElementById('preview_ld1').textContent = ld1Content;

    const noticeEl = document.getElementById('ld1_gen_notice');
    const meta = typeof genererLD1Input.lastMeta === 'object' ? genererLD1Input.lastMeta : null;
    if (noticeEl) {
        if (meta && meta.warnings && meta.warnings.length) {
            noticeEl.style.display = 'block';
            noticeEl.textContent = meta.warnings.join(' ');
            // Ne pas modifier le <select> : l'utilisateur garde NC/US/PAW tel qu'il l'a choisi.
        } else {
            noticeEl.style.display = 'none';
            noticeEl.textContent = '';
        }
    }

    // Mettre à jour l'indicateur QE Library quand les paramètres changent
    actualiserDisponibiliteQELibrary(false);
    
    // Mettre à jour la commande
    const cmd = `cd ${LD1_CONFIG.PSEUDO_DIR} && ${LD1_CONFIG.QE_BIN}/ld1.x < ${element}.ld1.in > ${element}.ld1.out`;
    document.getElementById('cmd_ld1').textContent = cmd;
}

/**
 * Copier le fichier ld1.in dans le presse-papier
 */
function copierLD1(element) {
    const content = document.getElementById('preview_ld1').textContent;
    navigator.clipboard.writeText(content).then(() => {
        alert('✅ Fichier ld1.in copié dans le presse-papier!');
    }).catch(err => {
        console.error('Erreur copie:', err);
        // Fallback
        const textarea = document.createElement('textarea');
        textarea.value = content;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        alert('✅ Copié!');
    });
}

/**
 * Télécharger le fichier ld1.in
 */
function telechargerLD1(element) {
    const content = document.getElementById('preview_ld1').textContent;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${element}.ld1.in`;
    a.click();
    URL.revokeObjectURL(url);
}

/**
 * Lancer la génération du pseudopotentiel via l'API ou afficher la commande
 */
async function lancerGenerationPseudo(element) {
    const content = document.getElementById('preview_ld1').textContent;
    const functional = document.getElementById('pseudo_functional')?.value || 'PBE';
    const pseudoType = document.getElementById('pseudo_type')?.value || 'NC';
    
    // Essayer via l'API
    try {
        // 1. Sauvegarder le fichier ld1.in
        const saveResponse = await fetch(apiPseudosBase() + '/api/sauvegarder_input', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                filename: `${element}.ld1.in`,
                content: content
            })
        });
        
        if (!saveResponse.ok) throw new Error('Sauvegarde échouée');
        
        alert(`✅ Fichier ${element}.ld1.in sauvegardé!\n\n` +
              `Pour générer le pseudo, exécutez dans un terminal:\n\n` +
              `cd ${LD1_CONFIG.PSEUDO_DIR}\n` +
              `${LD1_CONFIG.QE_BIN}/ld1.x < ${LD1_CONFIG.INPUTS_DIR}/${element}.ld1.in > ${element}.ld1.out\n\n` +
              `Le fichier ${element}.${functional}-${pseudoType.toLowerCase()}.UPF sera créé.`);
        
    } catch (error) {
        // Fallback: afficher les instructions
        const instructions = `
═══════════════════════════════════════════════════════════════════
  GÉNÉRATION DU PSEUDOPOTENTIEL - ${element}
═══════════════════════════════════════════════════════════════════

1. Sauvegardez le fichier ld1.in ci-dessus

2. Dans un terminal, exécutez:

   cd ${LD1_CONFIG.PSEUDO_DIR}
   ${LD1_CONFIG.QE_BIN}/ld1.x < ${element}.ld1.in > ${element}.ld1.out

3. Le fichier UPF sera généré: ${element}.${functional}-${pseudoType.toLowerCase()}.UPF

═══════════════════════════════════════════════════════════════════
        `;
        
        alert(instructions);
    }
}

/**
 * Mettre à jour la description du type de pseudo
 */
function updatePseudoTypeInfo() {
    const select = document.getElementById('pseudo_type');
    const desc = document.getElementById('pseudo_type_desc');
    if (select && desc && PSEUDO_TYPES[select.value]) {
        desc.textContent = PSEUDO_TYPES[select.value].description;
    }
    actualiserDisponibiliteQELibrary(false);
}

/**
 * Mettre à jour la description de la fonctionnelle
 */
function updateFunctionalInfo() {
    const select = document.getElementById('pseudo_functional');
    const desc = document.getElementById('func_desc');
    if (select && desc && FUNCTIONALS[select.value]) {
        desc.textContent = FUNCTIONALS[select.value].description;
    }
    actualiserDisponibiliteQELibrary(false);
}

// --- QE Library availability indicator (local + remote) ---
let __qeLibAvailabilityTimer = null;

function _qeLibBuildCandidateFilenames(element, functionalLower, pseudoType) {
    const func = (functionalLower || 'pbe').toLowerCase();
    const pt = (pseudoType || 'NC').toUpperCase();

    const isNC = ['NC', 'TM', 'RRKJ', 'MT'].includes(pt);
    const isUS = ['US', 'RRKJUS'].includes(pt);
    const isPAW = ['PAW', 'KJPAW'].includes(pt);

    const names = [];

    // PAW (KJPAW)
    if (isPAW) {
        names.push(`${element}.${func}-n-kjpaw_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-n-kjpaw_psl.0.3.1.UPF`);
        names.push(`${element}.${func}-spdn-kjpaw_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-spdn-kjpaw_psl.0.3.1.UPF`);
    }

    // USPP (RRKJUS)
    if (isUS || isPAW) {
        names.push(`${element}.${func}-spn-rrkjus_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-n-rrkjus_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-dn-rrkjus_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-spdfn-rrkjus_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-spn-rrkjus_psl.0.3.1.UPF`);
        names.push(`${element}.${func}-n-rrkjus_psl.0.3.1.UPF`);
        names.push(`${element}.${func}-dn-rrkjus_psl.0.3.1.UPF`);
    }

    // NC (RRKJ) — quand dispo
    if (isNC) {
        names.push(`${element}.${func}-n-rrkj_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-spn-rrkj_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-dn-rrkj_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-n-rrkj_psl.0.3.1.UPF`);
        names.push(`${element}.${func}-spn-rrkj_psl.0.3.1.UPF`);
        names.push(`${element}.${func}-dn-rrkj_psl.0.3.1.UPF`);
    }

    // FHI (souvent NC)
    names.push(`${element}.${func}-mt_fhi.UPF`);

    // De-dup
    return Array.from(new Set(names));
}

async function _qeLibCheckLocal(filename) {
    try {
        const resp = await fetch(`${apiPseudosBase()}/api/pseudos/verifier/${encodeURIComponent(filename)}`);
        const json = await resp.json();
        return !!json.exists;
    } catch (e) {
        return false;
    }
}

async function _qeLibCheckRemote(filename) {
    try {
        const resp = await fetch(`${apiPseudosBase()}/api/pseudos/verifier_qelibrary/${encodeURIComponent(filename)}`);
        const json = await resp.json();
        return !!json.exists;
    } catch (e) {
        return false;
    }
}

function actualiserDisponibiliteQELibrary(force = false) {
    const box = document.getElementById('qe_library_availability');
    const text = document.getElementById('qe_library_availability_text');
    if (!box || !text) return;

    // Debounce (éviter de spammer pendant que l'utilisateur change des paramètres)
    if (__qeLibAvailabilityTimer) clearTimeout(__qeLibAvailabilityTimer);
    __qeLibAvailabilityTimer = setTimeout(async () => {
        try {
            const element = window.__ld1_current_element;
            const functional = document.getElementById('pseudo_functional')?.value || 'PBE';
            const pseudoType = document.getElementById('pseudo_type')?.value || 'NC';

            if (!element) {
                text.innerHTML = `⚠️ Élément non défini.`;
                return;
            }

            text.innerHTML = `⏳ Vérification pour <strong>${element}</strong> / <strong>${pseudoType}</strong> / <strong>${functional}</strong>…`;

            const candidates = _qeLibBuildCandidateFilenames(element, functional.toLowerCase(), pseudoType).slice(0, 14);

            // 1) local d'abord
            for (const name of candidates) {
                // Si pas force, on limite un peu le coût: on teste 6 noms en local max
                if (!force && candidates.indexOf(name) >= 6) break;
                const okLocal = await _qeLibCheckLocal(name);
                if (okLocal) {
                    text.innerHTML = `✅ Déjà présent localement: <code style="color:#f9e2af;">${name}</code>`;
                    return;
                }
            }

            // 2) remote ensuite
            for (const name of candidates) {
                const okRemote = await _qeLibCheckRemote(name);
                if (okRemote) {
                    text.innerHTML = `✅ Disponible dans QE Library: <code style="color:#f9e2af;">${name}</code>`;
                    return;
                }
            }

            text.innerHTML = `❌ Aucune variante trouvée dans QE Library pour cette combinaison. <span style="color:#6c7086;">(Souvent, <strong>PBE</strong> est le mieux fourni.)</span>`;
        } catch (e) {
            text.innerHTML = `⚠️ Vérification impossible (réseau/API).`;
        }
    }, force ? 50 : 350);
}

/**
 * Vérifier si l'élément est difficile à générer (lanthanides, actinides)
 */
function estElementDifficile(element) {
    const elem = ELEMENTS_LD1[element];
    if (!elem) return false;
    const Z = elem.Z;
    // Lanthanides: 57-71, Actinides: 89-103
    return (Z >= 57 && Z <= 71) || (Z >= 89 && Z <= 103);
}

/** Métaux de transition 3d (Sc–Zn) : ld1.x NC → échec PS-KS quasi systématique. */
function estMetal3d(element) {
    const elem = ELEMENTS_LD1[element];
    return elem && elem.Z >= 21 && elem.Z <= 30;
}

/**
 * Télécharger un pseudo depuis la bibliothèque QE pour les éléments difficiles
 */
async function telechargerPseudoQELibrary(element) {
    const functional = document.getElementById('pseudo_functional')?.value || 'PBE';
    const pseudoType = document.getElementById('pseudo_type')?.value || 'NC';
    
    // URLs possibles pour les pseudos PSL
    const urls = [
        `https://pseudopotentials.quantum-espresso.org/upf_files/${element}.pbe-spdn-kjpaw_psl.1.0.0.UPF`,
        `https://pseudopotentials.quantum-espresso.org/upf_files/${element}.pbe-spdfn-rrkjus_psl.1.0.0.UPF`,
        `https://pseudopotentials.quantum-espresso.org/upf_files/${element}.pbe-spdn-rrkjus_psl.1.0.0.UPF`,
        `https://pseudopotentials.quantum-espresso.org/upf_files/${element}.pbe-n-kjpaw_psl.1.0.0.UPF`
    ];
    
    try {
        const response = await fetch(apiPseudosBase() + '/api/pseudos/telecharger', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                element: element,
                functional: functional.toLowerCase(),
                type: pseudoType.toLowerCase(),
                destination: LD1_CONFIG.PSEUDO_GENERES_DIR
            })
        });
        
        const result = await response.json();
        if (result.success) {
            return { success: true, filename: result.filename, path: result.path };
        }
    } catch (error) {
        console.error('Erreur téléchargement:', error);
    }
    
    return { success: false };
}

/**
 * BOUTON 1: Sauvegarder input ld1.in ET le script shell
 * Sauvegarde dans /Pseudo_generes/ld1_inputs/
 */
function conseilLanthanidePourLd1(element) {
    if (!estElementDifficile(element)) return;
    var isLanth = ELEMENTS_LD1[element] && ELEMENTS_LD1[element].Z >= 57 && ELEMENTS_LD1[element].Z <= 71;
    var msg = isLanth
        ? element + ' (lanthanide) : ld1.x NC échoue souvent. Préférez l’onglet ONCVPSP (psfile=both) ou PseudoDojo, puis « Recharger entrée ONCV ».'
        : element + ' (actinide) : ld1.x est difficile — ONCVPSP ou bibliothèques recommandées.';
    if (typeof _showToast === 'function') {
        _showToast(msg, '#0891b2', 7000);
    } else {
        console.warn(msg);
    }
}

async function sauvegarderInputEtScript(element) {
    conseilLanthanidePourLd1(element);
    
    // Actualiser la preview d'abord
    actualiserPreviewLD1(element);
    
    const content = document.getElementById('preview_ld1').textContent;
    const functional = document.getElementById('pseudo_functional')?.value || 'PBE';
    const pseudoType = document.getElementById('pseudo_type')?.value || 'NC';
    
    const baseFilename = `${element}.${functional.toLowerCase()}-${pseudoType.toLowerCase()}`;
    const ld1Filename = `${baseFilename}.ld1.in`;
    const shFilename = `${baseFilename}.ld1.sh`;
    
    // Créer le script shell - génère DANS Pseudo_generes directement
    const scriptContent = `#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
# Script de génération de pseudopotentiel pour ${element}
# Type: ${pseudoType} | Fonctionnelle: ${functional}
# Généré le: ${new Date().toLocaleString('fr-FR')}
# ═══════════════════════════════════════════════════════════════════════════════

# Configuration
QE_BIN="${LD1_CONFIG.QE_BIN}"
LD1_DIR="${LD1_CONFIG.LD1_INPUTS_DIR}"
PSEUDO_DIR="${LD1_CONFIG.PSEUDO_GENERES_DIR}"
INPUT_FILE="${ld1Filename}"

# Vérifier que ld1.x existe
if [ ! -f "$QE_BIN/ld1.x" ]; then
    echo "❌ Erreur: ld1.x non trouvé dans $QE_BIN"
    exit 1
fi

# Vérifier que le fichier input existe
if [ ! -f "$LD1_DIR/$INPUT_FILE" ]; then
    echo "❌ Erreur: Fichier input non trouvé: $LD1_DIR/$INPUT_FILE"
    exit 1
fi

echo "═══════════════════════════════════════════════════════════════════"
echo "  🔬 Génération du pseudopotentiel ${element}"
echo "═══════════════════════════════════════════════════════════════════"
echo ""
echo "📄 Input: $LD1_DIR/$INPUT_FILE"
echo "📁 Output: $PSEUDO_DIR/"
echo ""

# Aller dans le dossier de sortie (Pseudo_generes) pour que le UPF y soit créé
cd "$PSEUDO_DIR"

# Lancer ld1.x avec le chemin complet vers l'input
echo "🚀 Lancement de ld1.x..."
$QE_BIN/ld1.x < "$LD1_DIR/$INPUT_FILE" > "$LD1_DIR/${element}.ld1.out" 2>&1
EXIT_CODE=$?

# Déplacer les fichiers temporaires vers ld1_inputs
mv ld1.test ld1.wfc ld1ps.wfc vx.pot "$LD1_DIR/" 2>/dev/null

# Vérifier le résultat
if [ \$EXIT_CODE -eq 0 ]; then
    echo ""
    echo "✅ Génération terminée avec succès!"
    echo ""
    
    # Lister les fichiers UPF générés
    UPF_FILES=\$(ls *.UPF 2>/dev/null | grep -i "${element}")
    if [ -n "\$UPF_FILES" ]; then
        echo "📦 Pseudopotentiel(s) généré(s):"
        for f in \$UPF_FILES; do
            SIZE=\$(ls -lh "\$f" | awk '{print \$5}')
            echo "   ✓ $PSEUDO_DIR/\$f (\$SIZE)"
        done
    else
        # Chercher tous les UPF créés récemment
        NEW_UPF=\$(find . -name "*.UPF" -mmin -1 2>/dev/null | head -1)
        if [ -n "\$NEW_UPF" ]; then
            echo "📦 Pseudopotentiel généré: \$NEW_UPF"
        else
            echo "⚠️ Aucun fichier .UPF trouvé"
            echo "   Vérifiez le log: $LD1_DIR/${element}.ld1.out"
        fi
    fi
else
    echo ""
    echo "❌ Erreur lors de la génération (code: \$EXIT_CODE)"
    echo ""
    echo "📋 Dernières lignes du log:"
    tail -25 "$LD1_DIR/${element}.ld1.out" 2>/dev/null
fi

echo ""
echo "═══════════════════════════════════════════════════════════════════"
`;

    try {
        // Sauvegarder le fichier ld1.in
        const response1 = await fetch(apiPseudosBase() + '/api/sauvegarder_input', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                filename: ld1Filename,
                content: content,
                directory: LD1_CONFIG.LD1_INPUTS_DIR
            })
        });
        
        // Sauvegarder le script shell
        const response2 = await fetch(apiPseudosBase() + '/api/sauvegarder_input', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                filename: shFilename,
                content: scriptContent,
                directory: LD1_CONFIG.LD1_INPUTS_DIR
            })
        });
        
        const result1 = await response1.json();
        const result2 = await response2.json();
        
        if (result1.success && result2.success) {
            alert(`✅ Fichiers sauvegardés!\n\n` +
                  `📁 ${LD1_CONFIG.LD1_INPUTS_DIR}/\n` +
                  `   📄 ${ld1Filename}\n` +
                  `   📜 ${shFilename}\n\n` +
                  `Pour générer le pseudo:\n` +
                  `chmod +x ${LD1_CONFIG.LD1_INPUTS_DIR}/${shFilename}\n` +
                  `${LD1_CONFIG.LD1_INPUTS_DIR}/${shFilename}`);
        } else {
            throw new Error('Erreur sauvegarde');
        }
    } catch (error) {
        console.error('Erreur:', error);
        // Fallback: télécharger les deux fichiers
        telechargerLD1(element);
        
        // Télécharger aussi le script
        const blob = new Blob([scriptContent], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = shFilename;
        a.click();
        URL.revokeObjectURL(url);
        
        alert('📥 Fichiers téléchargés (API non disponible)');
    }
}

/**
 * BOUTON 2: Générer et Visualiser
 * Lance ld1.x et affiche le résultat
 */
async function genererEtVisualiser(element) {
    const functional = document.getElementById('pseudo_functional')?.value || 'PBE';
    const pseudoType = document.getElementById('pseudo_type')?.value || 'NC';
    const baseFilename = `${element}.${functional.toLowerCase()}-${pseudoType.toLowerCase()}`;
    
    conseilLanthanidePourLd1(element);
    var pseudoTypeLd1 = document.getElementById('pseudo_type')?.value || 'NC';
    if (estElementDifficile(element) && pseudoTypeLd1 === 'NC' && ELEMENTS_LD1[element] && ELEMENTS_LD1[element].Z >= 57 && ELEMENTS_LD1[element].Z <= 71) {
        var goOncv = window.confirm(
            element + ' — ld1.x NC pour les lanthanides échoue presque toujours.\n\n' +
            'Recommandé : onglet ONCVPSP (entrée Gd auto, psfile=both) ou PseudoDojo.\n\n' +
            'Continuer quand même avec ld1.x ?\n[OK] = Oui, tenter ld1.x\n[Annuler] = Arrêter (allez sur ONCVPSP)'
        );
        if (!goOncv) return;
    }
    if (estMetal3d(element) && pseudoTypeLd1 === 'NC') {
        var go3dNc = window.confirm(
            element + ' — métal 3d en NC avec ld1.x : échec « Errors in PS-KS equation » très fréquent.\n\n' +
            'Recommandé : type US ou PAW (génération ld1.x fiable).\n' +
            'Pour un NC catalogue : PseudoDojo / PSLibrary (pas ld1.x).\n\n' +
            'Continuer quand même en NC ?\n[OK] = Tenter NC\n[Annuler] = Revenir (choisir US ou PAW)'
        );
        if (!go3dNc) return;
    }
    
    // Actualiser la preview
    actualiserPreviewLD1(element);
    const ld1Content = document.getElementById('preview_ld1').textContent;
    
    // Créer une modale avec état de génération
    ensureLd1ModalScienceStyles();
    const modal = document.createElement('div');
    modal.id = 'modal_generation';
    modal.className = 'ld1-modal-backdrop';
    
    modal.innerHTML = `
        <div class="ld1-modal-panel" style="max-width:820px;">
            <h3 class="ld1-modal-title" style="font-size:1.15rem;">🚀 Génération automatique — ${element}</h3>
            
            <div id="generation_status" class="ld1-gen-status">
                <div style="display: flex; align-items: center; gap: 16px;">
                    <div class="ld1-spinner" aria-hidden="true"></div>
                    <div>
                        <div style="color: #f0c674; font-weight: 600;">⏳ Génération en cours…</div>
                        <div style="color: #8b9eb3; font-size: 0.9rem; margin-top: 6px;">Exécution de ld1.x (souvent 30–60 secondes)</div>
                    </div>
                </div>
            </div>
            
            <div id="generation_result" style="display: none;"></div>
            
            <div style="text-align: right; margin-top: 22px;">
                <button type="button" id="btn_fermer_gen" class="ld1-btn-close" onclick="document.getElementById('modal_generation').remove()" disabled>
                    ⏳ Génération en cours…
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Lancer la génération automatique via l'API
    try {
        const response = await fetch(apiPseudosBase() + '/api/pseudos/generer_ld1', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                element: element,
                input: ld1Content,
                ld1_content: ld1Content,
                filename: `${baseFilename}.ld1.in`
            })
        });
        
        const result = await response.json();
        
        const statusDiv = document.getElementById('generation_status');
        const resultDiv = document.getElementById('generation_result');
        const btnFermer = document.getElementById('btn_fermer_gen');
        
        if (result.success || (result.returncode === 0 && result.upf_genere)) {
            const source = (result.source || '').toString();
            const isDownload = source.toLowerCase().includes('qe library');
            const requestedUpf = (ld1Content.match(/file_pseudopw\s*=\s*['"]([^'"]+)['"]/i) || [])[1] || '';
            const requestedDft = (ld1Content.match(/dft\s*=\s*['"]([^'"]+)['"]/i) || [])[1] || '';
            const requestedPseudotype = (ld1Content.match(/pseudotype\s*=\s*(\d+)/i) || [])[1] || '';
            const qeReady = result.upf_qe_ready || (result.qe_validation && result.qe_validation.conform_qe);
            const obtainedFile = result.upf_genere || result.upf_file
                || (result.upf_path ? result.upf_path.split('/').pop() : '') || '';
            const upfFullPath = result.upf_path || ((result.pseudos_dir && obtainedFile)
                ? String(result.pseudos_dir).replace(/\/$/, '') + '/' + obtainedFile : '');

            statusDiv.innerHTML = `
                <div style="display: flex; align-items: center; gap: 15px;">
                    <div style="font-size: 2em;">${qeReady ? '✅' : '⚠️'}</div>
                    <div>
                        <div style="color: ${qeReady ? '#a6e3a1' : '#f9e2af'}; font-weight: bold;">
                            ${isDownload ? 'Pseudopotentiel téléchargé (QE Library)' : (qeReady ? 'Pseudopotentiel généré et conforme QE' : 'Calcul ld1.x terminé — UPF à vérifier')}
                        </div>
                        ${source ? `<div style="color: #6c7086; font-size: 0.9em; margin-top: 6px;">Source: ${_escapeHtmlLd1(source)}</div>` : ''}
                    </div>
                </div>
            `;

            const payload = Object.assign({}, result, {
                generator: 'ld1',
                success: !!result.success || !!qeReady,
                run_completed: true,
                upf_path: upfFullPath || result.upf_path || '',
                upf_genere: obtainedFile || result.upf_genere,
                note: isDownload ? 'Source : QE Library (fallback)' : (result.note || ''),
            });

            let extras = '';
            if (result.ld1_input || result.log_file) {
                extras += `<div style="margin-top:12px;padding:12px;border-radius:8px;background:#11111b;border:1px solid #45475a;">
                    <div style="color:#89b4fa;font-weight:bold;margin-bottom:6px;">Fichiers ld1.x</div>
                    <div style="font-family:monospace;font-size:13px;line-height:1.9;color:#cdd6f4;">
                        ${result.ld1_input ? `<div>Input : ${_escapeHtmlLd1(result.ld1_input)}</div>` : ''}
                        ${result.log_file ? `<div>Log : ${_escapeHtmlLd1(result.log_file)}</div>` : ''}
                    </div></div>`;
            }
            if (isDownload && requestedUpf && upfFullPath && !String(upfFullPath).endsWith('/' + requestedUpf)) {
                extras += `<div style="margin-top:12px;padding:12px;border-radius:8px;background:#3a2a1a;border:1px solid #f9e2af;color:#cdd6f4;font-size:12px;">
                    <strong style="color:#f9e2af;">Fichier obtenu ≠ demande</strong><br>
                    Demandé : ${_escapeHtmlLd1(requestedUpf)} (dft=${_escapeHtmlLd1(requestedDft || '?')}, type=${_escapeHtmlLd1(requestedPseudotype || '?')})<br>
                    Obtenu : ${_escapeHtmlLd1(obtainedFile || upfFullPath)}
                </div>`;
            }

            resultDiv.style.display = 'block';
            if (typeof window.renderGeneratorRunResult === 'function') {
                resultDiv.innerHTML = window.renderGeneratorRunResult(payload, { label: 'ld1.x' }) + extras;
            } else {
                resultDiv.innerHTML = `<div style="padding:16px;border:1px solid #a6e3a1;border-radius:10px;margin-top:12px;">
                    <strong style="color:#a6e3a1;">ld1.x</strong>
                    <div style="font-family:monospace;margin-top:8px;color:#cdd6f4;">${_escapeHtmlLd1(upfFullPath || obtainedFile || '(UPF)')}</div>
                    ${extras}
                </div>`;
            }
        } else {
            const logComb = result.log || [result.stderr, result.output].filter(Boolean).join('\n---\n') || '';
            statusDiv.innerHTML = `
                <div style="display: flex; align-items: center; gap: 15px;">
                    <div style="font-size: 2em;">❌</div>
                    <div>
                        <div style="color: #f38ba8; font-weight: bold;">Échec de la génération</div>
                        <div style="color: #cdd6f4; margin-top: 5px;">${_escapeHtmlLd1(
                            result.error
                            || (result.fatal_errors && result.fatal_errors.length ? result.fatal_errors.join(' ') : '')
                            || (logComb.includes('PS-KS') ? 'Échec test PS-KS — pour les métaux 3d (ex. Mn), utilisez US ou PAW, ou un NC PseudoDojo.' : '')
                            || 'Erreur inconnue — voir le log ci-dessous.'
                        )}</div>
                    </div>
                </div>
            `;
            const diag3dHint = (estMetal3d(element) && pseudoTypeLd1 === 'NC')
                ? `<div style="margin-top:12px;padding:12px;border-radius:8px;background:#1e3a5c;border:1px solid #3b82f6;color:#e2e8f0;font-size:0.9em;">
                        <strong>${element} (3d) + NC :</strong> ld1.x échoue au test PS-KS. Relancez en <strong>US</strong> ou <strong>PAW</strong> (validé pour ${element}),
                        ou importez un NC depuis <strong>PseudoDojo</strong> (onglet bibliothèques).
                   </div>`
                : '';
            if (logComb || result.diagnostics) {
                // Diagnostics (où est le problème dans ld1.in + corrections proposées)
                let diagHtml = '';
                if (result.diagnostics && (result.diagnostics.issues || []).length) {
                    const issues = result.diagnostics.issues;
                    const issuesHtml = issues.map((it, idx) => {
                        const lines = (it.lines || []).map(l => `${String(l.line_no).padStart(4, ' ')} | ${l.text}`).join('\n');
                        return `
                            <div style="background:#11111b; border:1px solid #45475a; border-radius:10px; padding:12px; margin-top:12px;">
                                <div style="color:#f9e2af; font-weight:bold;">${idx + 1}. ${it.title}</div>
                                <div style="color:#cdd6f4; margin-top:6px; line-height:1.6;">${it.details}</div>
                                ${lines ? `<pre style="margin-top:10px; color:#a6e3a1; font-size:12px; overflow-x:auto; white-space:pre;">${lines}</pre>` : ''}
                                <div style="color:#89b4fa; margin-top:8px;"><strong>✅ Correction proposée:</strong> ${it.suggestion}</div>
                            </div>
                        `;
                    }).join('');
                    diagHtml = `
                        <div style="background:#2a213a; border:1px solid #b4befe; padding:15px; border-radius:10px; margin-top:15px;">
                            <h4 style="color:#b4befe; margin-top:0;">🩺 Diagnostic automatique (ld1.in)</h4>
                            <div style="color:#cdd6f4; margin-top:6px;">${result.diagnostics.summary || ''}</div>
                            ${issuesHtml}
                        </div>
                    `;
                }
                resultDiv.style.display = 'block';
                resultDiv.innerHTML = `
                    <div style="background: #3a1a1a; border: 1px solid #f38ba8; padding: 15px; border-radius: 10px; margin-top: 15px;">
                        <h4 style="color: #f38ba8; margin-top: 0;">📋 Sortie ld1.x / diagnostic</h4>
                        <pre style="color: #cdd6f4; font-size: 11px; overflow-x: auto; white-space: pre-wrap;">${_escapeHtmlLd1(logComb)}</pre>
                    </div>
                    ${diagHtml}
                    ${diag3dHint}
                    <div style="background: #313244; padding: 15px; border-radius: 8px; margin-top: 15px;">
                        <strong style="color: #f9e2af;">💡 Suggestion:</strong>
                        <p style="color: #cdd6f4; margin: 10px 0 0 0;">
                            Pour les éléments difficiles, essayez de télécharger depuis la bibliothèque QE:<br>
                            <button onclick="telechargerPseudoQELibrary('${element}')" style="margin-top: 10px; background: #89b4fa; color: #1e1e2e; border: none; padding: 8px 15px; border-radius: 5px; cursor: pointer;">
                                📥 Télécharger depuis QE Library
                            </button>
                        </p>
                    </div>
                `;
            }
        }
        
        btnFermer.disabled = false;
        btnFermer.textContent = 'Fermer';
        
    } catch (error) {
        console.error('Erreur génération:', error);
        document.getElementById('generation_status').innerHTML = `
            <div style="display: flex; align-items: center; gap: 15px;">
                <div style="font-size: 2em;">⚠️</div>
                <div>
                    <div style="color: #f38ba8; font-weight: bold;">Erreur de connexion</div>
                    <div style="color: #cdd6f4; margin-top: 5px;">${error.message}</div>
                    <div style="color: #6c7086; margin-top: 5px;">Vérifiez que l’API pseudos est en ligne (port 5008 par défaut) : <code style="color:#a6e3a1;">python3 api_pseudos_standalone.py</code></div>
                </div>
            </div>
        `;
        document.getElementById('btn_fermer_gen').disabled = false;
        document.getElementById('btn_fermer_gen').textContent = 'Fermer';
    }
}

/**
 * 📘 README / Guide: principe + recommandations (par élément et type)
 */
function ouvrirGuidePseudosLD1(element = null) {
    const el = element || (document.getElementById('pseudo_valence') ? (document.querySelector('#pseudo_valence')?.closest('[data-element]')?.dataset?.element || null) : null) || 'Si';
    const elem = ELEMENTS_LD1[el] || null;
    const currentFunctional = (document.getElementById('pseudo_functional')?.value || 'PBE').toUpperCase();
    const currentType = (document.getElementById('pseudo_type')?.value
        || document.querySelector('input[name="pseudo_type"]:checked')?.value
        || 'NC').toUpperCase();
    
    // Construire options éléments depuis la base
    const elementOptions = Object.keys(ELEMENTS_LD1)
        .sort((a, b) => (ELEMENTS_LD1[a].Z || 0) - (ELEMENTS_LD1[b].Z || 0))
        .map(sym => `<option value="${sym}" ${sym === el ? 'selected' : ''}>${sym} (Z=${ELEMENTS_LD1[sym].Z})</option>`)
        .join('');
    
    ensureLd1ModalScienceStyles();
    const modal = document.createElement('div');
    modal.id = 'modal_readme_pseudos';
    modal.className = 'ld1-modal-backdrop';
    
    modal.innerHTML = `
        <div class="ld1-modal-panel ld1-guide-modal-panel" style="max-width:1000px;">
            <div style="display:flex; align-items:flex-start; justify-content: space-between; gap: 16px; flex-wrap:wrap;">
                <div>
                    <h3 class="ld1-modal-title" style="margin:0;">📘 README / Guide — Génération des pseudos <span class="ld1-modal-title-badge">ld1.x · aide</span></h3>
                    <p class="ld1-modal-sub" style="margin-top:8px;">Principe (ld1.x vs QE Library) et paramètres recommandés par élément et type.</p>
                </div>
                <button type="button" class="ld1-btn-close" onclick="document.getElementById('modal_readme_pseudos')?.remove()">Fermer</button>
            </div>
            
            <div class="ld1-guide-grid">
                <div>
                    <label for="guide_element_select">Élément</label>
                    <select id="guide_element_select">
                        ${elementOptions}
                    </select>
                </div>
                <div>
                    <label for="guide_type_select">Type</label>
                    <select id="guide_type_select">
                        <option value="NC" ${currentType === 'NC' ? 'selected' : ''}>NC (pseudotype=1)</option>
                        <option value="US" ${currentType === 'US' ? 'selected' : ''}>US/USPP (pseudotype=2)</option>
                        <option value="PAW" ${currentType === 'PAW' ? 'selected' : ''}>PAW (pseudotype=3)</option>
                        <option value="RRKJ" ${currentType === 'RRKJ' ? 'selected' : ''}>RRKJ (NC/US selon lib)</option>
                    </select>
                </div>
                <div>
                    <label for="guide_dft_input">Fonctionnelle</label>
                    <input id="guide_dft_input" value="${currentFunctional}" readonly>
                </div>
            </div>
            
            <div class="ld1-guide-principle">
                <h4>Principe</h4>
                <div class="ld1-guide-principle-body">
                    - <strong>Mode ld1.x</strong> : exécution de <code>ld1.x</code> avec un <code>ld1.in</code> pour produire un <code>.UPF</code>.<br>
                    - <strong>Fallback QE Library</strong> : si ld1.x échoue (souvent sur métaux de transition ou éléments lourds), l’interface peut télécharger un pseudo pré-généré (QE Library).<br>
                    - Le fichier obtenu peut différer du type demandé (ex. NC demandé → USPP fourni).
                </div>
            </div>
            
            <div id="guide_recos" style="margin-top:16px;"></div>

            <div id="guide_reco_insert" style="margin-top:16px;"></div>
            
            <div class="ld1-guide-doc">
                <h4>Documentation</h4>
                <div class="ld1-guide-doc-body">
                    Guide projet : <code>README_GENERATION_PSEUDOS_LD1.md</code> (dépôt interface)
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    const render = () => {
        const sym = document.getElementById('guide_element_select').value;
        const type = document.getElementById('guide_type_select').value;
        const e = ELEMENTS_LD1[sym];
        if (!e) return;

        const rel = (e.Z > 36) ? 'scalar (rel=1)' : 'none (rel=0)';
        const hasD = /\dd/.test((e.valence || '').toLowerCase()) || /d\d/.test((e.valence || '').toLowerCase());
        
        // Recommandations (heuristiques simples et lisibles)
        let recommended = {
            prefer: 'QE Library',
            pseudoType: type,
            rcloc: (e.rcut && e.rcut[0]) ? e.rcut[0] : 2.2,
            rcut_s:  (e.Z > 36) ? 4.0 : 3.0,
            rcut_p:  (e.Z > 36) ? 3.2 : 2.8,
            rcut_d:  (e.Z > 36) ? 3.0 : 2.6,
            nlcc: hasD || e.Z > 20,
            ecutwfc: (type === 'NC') ? 80 : (type === 'PAW' ? 60 : 45),
            ecutrho: (type === 'NC') ? 800 : (type === 'PAW' ? 480 : 400),
            notes: []
        };
        
        if (hasD && type === 'NC') {
            recommended.notes.push("Pour les métaux de transition (d), la génération NC via ld1.x échoue souvent; US/USPP est plus robuste.");
        }
        if (e.Z > 36) {
            recommended.notes.push("Élément lourd: relativité scalaire recommandée (rel=1).");
        }
        recommended.notes.push("Si ld1.x échoue: accepter le fallback QE Library (PSlibrary/FHI).");
        
        const html = `
            <div class="ld1-guide-reco-card">
                <div class="ld1-guide-reco-head">
                    <div>
                        <div class="ld1-guide-reco-symbol">${sym} (Z=${e.Z})</div>
                        <div class="ld1-guide-reco-meta">
                            <div><strong>Config référence:</strong> <code>${e.config}</code></div>
                            <div><strong>Valence:</strong> <code>${e.valence || ''}</code></div>
                            <div><strong>Relativité:</strong> ${rel}</div>
                        </div>
                    </div>
                    <div class="ld1-guide-params">
                        <div class="ld1-guide-params-title">🎯 Paramètres recommandés (départ)</div>
                        <div class="ld1-guide-params-body">
                            type: ${type}<br>
                            rcloc: ${recommended.rcloc} a.u.<br>
                            rcut(s/p/d): ${recommended.rcut_s}/${recommended.rcut_p}/${recommended.rcut_d} a.u.<br>
                            NLCC: ${recommended.nlcc ? 'true' : 'false'}<br>
                            ecutwfc: ${recommended.ecutwfc} Ry<br>
                            ecutrho: ${recommended.ecutrho} Ry
                        </div>
                    </div>
                </div>
                ${recommended.notes.length ? `
                    <div class="ld1-guide-notes">
                        <div class="ld1-guide-notes-title">📝 Notes</div>
                        <ul>
                            ${recommended.notes.map(n => `<li>${n}</li>`).join('')}
                        </ul>
                    </div>
                ` : ''}
            </div>
        `;
        
        document.getElementById('guide_recos').innerHTML = html;

        const ins = document.getElementById('guide_reco_insert');
        if (ins && typeof buildHtmlGuideRecommandationPseudo === 'function') {
            ins.innerHTML = buildHtmlGuideRecommandationPseudo(sym, e);
        }
    };
    
    document.getElementById('guide_element_select').addEventListener('change', render);
    document.getElementById('guide_type_select').addEventListener('change', render);
    render();
}

/**
 * BOUTON 3: Archiver un UPF généré vers pseudos-ld1/ (API sans shell)
 */
async function sauvegarderPseudoGenere(element) {
    try {
        const cfg = resolveLD1Config();
        const response = await fetch(apiPseudosBase() + '/api/pseudos/archive_generated_upf', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                element: element,
                generator: 'ld1',
                ld1_inputs_dir: cfg.LD1_INPUTS_DIR || '',
                pseudo_generes_dir: cfg.PSEUDO_GENERES_DIR || '',
            }),
        });
        const result = await response.json();
        if (result.success) {
            const dest = result.pseudos_generes_dir
                || result.saved_to_pseudos_dir
                || 'pseudos-ld1/';
            const name = (result.copied_to_pseudos_generes && result.copied_to_pseudos_generes[0])
                || (result.source_path ? String(result.source_path).split('/').pop() : element + '.UPF');
            alert(`✅ Pseudopotentiel archivé!\n\n📦 ${dest}\n📄 ${name}`);
        } else {
            alert(`⚠️ ${result.error || 'Aucun fichier .UPF trouvé.'}\n\n` +
                  (result.hint || 'Générez d’abord le pseudo avec ld1.x (bouton Générer), puis réessayez.'));
        }
    } catch (error) {
        console.error('Erreur:', error);
        alert(`❌ Erreur lors de l’archivage UPF.\n\n` +
              `Vérifiez que l’API est en ligne (port 5008) : ./DEMARRER.sh`);
    }
}

// Exposer les fonctions globalement
window.afficherGenerateurPseudo = afficherGenerateurPseudo;
window.genererLD1Input = genererLD1Input;
window.actualiserPreviewLD1 = actualiserPreviewLD1;
window.copierLD1 = copierLD1;
window.telechargerLD1 = telechargerLD1;
window.lancerGenerationPseudo = lancerGenerationPseudo;
window.sauvegarderLD1 = sauvegarderLD1;
window.genererEtSauvegarder = genererEtSauvegarder;
window.updatePseudoTypeInfo = updatePseudoTypeInfo;
window.updateFunctionalInfo = updateFunctionalInfo;
window.defaultPseudoTypeForElement = defaultPseudoTypeForElement;
window.ELEMENTS_LD1 = ELEMENTS_LD1;
window.computeAllOrbitalsForLd1 = computeAllOrbitalsForLd1;
window.PSEUDO_TYPES = PSEUDO_TYPES;
window.FUNCTIONALS = FUNCTIONALS;
window.buildHtmlGuideRecommandationPseudo = buildHtmlGuideRecommandationPseudo;
window.ouvrirGuidePseudosLD1 = ouvrirGuidePseudosLD1;

console.log('✅ Script Générateur LD1 chargé');
console.log('   📊 Éléments supportés:', Object.keys(ELEMENTS_LD1).length);
console.log('   🔧 Types de pseudo:', Object.keys(PSEUDO_TYPES).length);
console.log('   ⚗️ Fonctionnelles:', Object.keys(FUNCTIONALS).length);


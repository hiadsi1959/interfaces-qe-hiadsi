/**
 * Modales « générateur complet » APE / ATOMPAW (alignées sur l’expérience ld1.x).
 */
(function () {
    'use strict';

    function safeSym(s) {
        return String(s || '').replace(/[^A-Za-z]/g, '').slice(0, 8);
    }

    function _gpVisibleModalRoot(rootId) {
        var root = document.getElementById(rootId);
        if (!root) return false;
        try {
            var st = window.getComputedStyle(root);
            return st.display !== 'none' && st.visibility !== 'hidden';
        } catch (e) {
            return false;
        }
    }

    function _gpResolvePseudoInput(modalId, modalRootId) {
        var modal = document.getElementById(modalId);
        if (_gpVisibleModalRoot(modalRootId) && modal) return modal;
        return modal;
    }

    window.gpGetApeTextarea = function () {
        return _gpResolvePseudoInput('gp_ape_input_modal', 'modal_generateur_ape_complet');
    };

    window.gpGetApeOutputEl = function () {
        if (_gpVisibleModalRoot('modal_generateur_ape_complet')) {
            var m = document.getElementById('gp_ape_output_modal');
            if (m) return m;
        }
        return document.getElementById('gp_ape_output_modal');
    };

    window.gpGetAtompawTextarea = function () {
        return _gpResolvePseudoInput('gp_atompaw_input_modal', 'modal_generateur_atompaw_complet');
    };

    window.gpGetAtompawOutputEl = function () {
        if (_gpVisibleModalRoot('modal_generateur_atompaw_complet')) {
            var m = document.getElementById('gp_atompaw_output_modal');
            if (m) return m;
        }
        return document.getElementById('gp_atompaw_output_modal');
    };

    window.fermerGenerateurAPEComplet = function () {
        var b = document.getElementById('modal_generateur_ape_complet');
        if (b) b.remove();
    };

    window.fermerGenerateurATOMPAWComplet = function () {
        var b = document.getElementById('modal_generateur_atompaw_complet');
        if (b) b.remove();
    };

    window.ouvrirGenerateurAPEComplet = function (symbo) {
        if (typeof ensureLd1ModalScienceStyles === 'function') ensureLd1ModalScienceStyles();
        var sym = safeSym(symbo);
        if (!sym) {
            alert('Sélectionnez d’abord un élément dans le tableau de Mendeleïev.');
            return;
        }
        window.fermerGenerateurAPEComplet();

        var elData = window.ELEMENTS && window.ELEMENTS[sym];
        var nom = elData ? String(elData.nom || '').replace(/</g, '&lt;').replace(/&/g, '&amp;') : '';

        var backdrop = document.createElement('div');
        backdrop.id = 'modal_generateur_ape_complet';
        backdrop.className = 'ld1-modal-backdrop';
        backdrop.style.zIndex = '10005';
        backdrop.addEventListener('click', function (ev) {
            if (ev.target === backdrop) window.fermerGenerateurAPEComplet();
        });

        backdrop.innerHTML =
            '<div class="ld1-modal-panel" style="max-width:min(1080px,96vw);max-height:92vh;overflow:auto;" onclick="event.stopPropagation()">' +
            '<h2 class="ld1-modal-title">APE' +
            ' <span class="ld1-modal-title-badge">' + sym + '</span>' +
            (nom ? ' <span style="font-weight:500;color:#94a3b8;font-size:0.85em;">— ' + nom + '</span>' : '') +
            '</h2>' +
            '<p class="ld1-modal-sub">Éditez ci-dessous le fichier <code>inp.ape</code> envoyé au serveur. '
            + 'Cliquez « Rafraîchir gabarit » pour recharger les paramètres depuis l’API.</p>' +
            '<div class="ld1-steps-strip" style="margin-bottom:12px;">' +
            '<span style="color:#86efac;font-weight:600;">① Élément</span> <span style="color:#64748b;">→</span> ' +
            '<span style="color:#cbd5e1;">② Paramètres XC</span> <span style="color:#64748b;">→</span> ' +
            '<span style="color:#cbd5e1;">③ inp.ape</span> <span style="color:#64748b;">→</span> ' +
            '<span style="color:#fdba74;font-weight:600;">④ Générer</span>' +
            '</div>' +
            '<p id="gp_ape_auto_summary_modal" style="font-size:0.88rem;margin:8px 0;color:#cbd5e1;line-height:1.45;">…</p>' +
            '<details style="margin:8px 0;border:1px solid rgba(30,73,118,0.35);border-radius:10px;padding:10px;background:rgba(15,23,42,0.45);">' +
            '<summary style="cursor:pointer;font-weight:600;color:#cbd5e1;font-size:0.82rem;">Synthèse · base × paramètres</summary>' +
            '<div id="gp_ape_breakdown_body_modal" style="margin-top:8px;color:#cbd5e1;"></div></details>' +
            '<p id="gp_ape_status_line_modal" style="font-size:0.84rem;margin-bottom:10px;color:#94a3b8;">…</p>' +
            '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px;align-items:center;">' +
            '<button type="button" id="gp_btn_ape_run_modal" class="btn-action btn-primary-act">Générer (APE)</button>' +
            '<button type="button" id="gp_btn_ape_regen_modal" class="btn-action btn-secondary-act">Rafraîchir gabarit</button>' +
            '<button type="button" id="gp_btn_ape_li_ae_modal" class="btn-action btn-secondary-act">Li — ae</button>' +
            '<button type="button" id="gp_btn_ape_li_pp_modal" class="btn-action btn-secondary-act">Li — pp</button>' +
            '<button type="button" class="btn-action btn-secondary-act" onclick="fermerGenerateurAPEComplet()">Fermer</button>' +
            '</div>' +
            '<label style="display:flex;align-items:center;gap:8px;font-size:0.85rem;color:#8ab4ff;margin-bottom:10px;cursor:pointer;">' +
            '<input type="checkbox" id="gp_ape_reuse_workdir_modal"> Réutiliser le dernier dossier (<code>continue_dir</code>)</label>' +
            '<label style="display:block;font-size:0.85rem;color:#8ab4ff;margin-bottom:6px;">Contenu <code>inp.ape</code> (éditable)</label>' +
            '<textarea id="gp_ape_input_modal" spellcheck="false" style="width:100%;min-height:420px;font-family:JetBrains Mono,Consolas,monospace;font-size:0.78rem;padding:12px;border-radius:10px;border:2px solid rgba(91,33,182,0.45);background:#0f172a;color:#e2e8f0;"></textarea>' +
            '<div id="gp_ape_output_modal" style="margin-top:14px;"></div>' +
            '</div>';

        document.body.appendChild(backdrop);

        if (typeof window.gpFetchAutoInputs === 'function') {
            window.gpFetchAutoInputs(sym, 'ape');
        }

        var elSym = sym.slice(0, 8) || 'X';
        document.getElementById('gp_btn_ape_run_modal').onclick = function () {
            if (typeof window.gpRunApe === 'function') window.gpRunApe(elSym);
        };
        document.getElementById('gp_btn_ape_regen_modal').onclick = function () {
            if (typeof window.gpInvalidateAutoInputsCacheForSym === 'function')
                window.gpInvalidateAutoInputsCacheForSym(sym);
            else if (typeof window.gpAutoCache === 'object')
                delete window.gpAutoCache[sym];
            if (typeof window.gpFetchAutoInputs === 'function')
                window.gpFetchAutoInputs(sym, 'ape', true);
        };
        document.getElementById('gp_btn_ape_li_ae_modal').onclick = function () {
            if (typeof window.gpLoadApePreset === 'function') window.gpLoadApePreset('li_ae');
        };
        document.getElementById('gp_btn_ape_li_pp_modal').onclick = function () {
            if (typeof window.gpLoadApePreset === 'function') window.gpLoadApePreset('li_pp');
        };

        if (typeof window.gpRefreshApeStatus === 'function') window.gpRefreshApeStatus();
    };

    window.ouvrirGenerateurATOMPAWComplet = function (symbo) {
        if (typeof ensureLd1ModalScienceStyles === 'function') ensureLd1ModalScienceStyles();
        var sym = safeSym(symbo);
        if (!sym) {
            alert('Sélectionnez d’abord un élément dans le tableau de Mendeleïev.');
            return;
        }
        window.fermerGenerateurATOMPAWComplet();

        var elData = window.ELEMENTS && window.ELEMENTS[sym];
        var nom = elData ? String(elData.nom || '').replace(/</g, '&lt;').replace(/&/g, '&amp;') : '';

        var backdrop = document.createElement('div');
        backdrop.id = 'modal_generateur_atompaw_complet';
        backdrop.className = 'ld1-modal-backdrop';
        backdrop.style.zIndex = '10005';
        backdrop.addEventListener('click', function (ev) {
            if (ev.target === backdrop) window.fermerGenerateurATOMPAWComplet();
        });

        backdrop.innerHTML =
            '<div class="ld1-modal-panel" style="max-width:min(1080px,96vw);max-height:92vh;overflow:auto;" onclick="event.stopPropagation()">' +
            '<h2 class="ld1-modal-title">ATOMPAW' +
            ' <span class="ld1-modal-title-badge">' + sym + '</span>' +
            (nom ? ' <span style="font-weight:500;color:#94a3b8;font-size:0.85em;">— ' + nom + '</span>' : '') +
            '</h2>' +
            '<p class="ld1-modal-sub">Éditez le flux <code>stdin</code> envoyé à ATOMPAW. '
            + 'Choisissez le format d’entrée puis cliquez « Rafraîchir gabarit » pour resynchroniser.</p>' +
            '<div class="ld1-steps-strip" style="margin-bottom:12px;">' +
            '<span style="color:#86efac;font-weight:600;">① Élément</span> <span style="color:#64748b;">→</span> ' +
            '<span style="color:#cbd5e1;">② Format / XC</span> <span style="color:#64748b;">→</span> ' +
            '<span style="color:#cbd5e1;">③ stdin</span> <span style="color:#64748b;">→</span> ' +
            '<span style="color:#fdba74;font-weight:600;">④ Générer</span>' +
            '</div>' +
            '<p id="gp_atompaw_auto_summary_modal" style="font-size:0.88rem;margin:8px 0;color:#cbd5e1;line-height:1.45;">…</p>' +
            '<details style="margin:8px 0;border:1px solid rgba(157,23,77,0.35);border-radius:10px;padding:10px;background:rgba(15,23,42,0.45);">' +
            '<summary style="cursor:pointer;font-weight:600;color:#fce7f3;font-size:0.82rem;">Synthèse · base × paramètres</summary>' +
            '<div id="gp_atompaw_breakdown_body_modal" style="margin-top:8px;color:#cbd5e1;"></div></details>' +
            '<p id="gp_atompaw_status_line_modal" style="font-size:0.84rem;margin-bottom:10px;color:#94a3b8;">…</p>' +
            '<label style="display:flex;flex-direction:column;gap:6px;font-size:0.85rem;color:#8ab4ff;margin-bottom:12px;max-width:420px;">' +
            '<span style="font-weight:700;">Format entrée ATOMPAW</span>' +
            '<select id="gp_atompaw_format_modal" style="padding:8px 10px;border-radius:8px;border:1px solid rgba(157,23,77,0.45);background:#0f172a;color:#e2e8f0;">' +
            '<option value="interactive">Interactif (stdin)</option>' +
            '<option value="qe_file">Fichier compact</option>' +
            '</select></label>' +
            '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px;align-items:center;">' +
            '<button type="button" id="gp_btn_atompaw_run_modal" class="btn-action btn-primary-act">Générer (ATOMPAW)</button>' +
            '<button type="button" id="gp_btn_atompaw_regen_modal" class="btn-action btn-secondary-act">Rafraîchir gabarit</button>' +
            '<button type="button" id="gp_btn_atompaw_tpl_modal" class="btn-action btn-secondary-act">Squelette générique</button>' +
            '<button type="button" class="btn-action btn-secondary-act" onclick="fermerGenerateurATOMPAWComplet()">Fermer</button>' +
            '</div>' +
            '<label style="display:flex;align-items:center;gap:8px;font-size:0.85rem;color:#8ab4ff;margin-bottom:10px;cursor:pointer;">' +
            '<input type="checkbox" id="gp_atompaw_reuse_workdir_modal"> Réutiliser le dernier dossier (<code>continue_dir</code>)</label>' +
            '<label style="display:block;font-size:0.85rem;color:#8ab4ff;margin-bottom:6px;">stdin ATOMPAW (éditable)</label>' +
            '<textarea id="gp_atompaw_input_modal" spellcheck="false" style="width:100%;min-height:420px;font-family:JetBrains Mono,Consolas,monospace;font-size:0.78rem;padding:12px;border-radius:10px;border:2px solid rgba(157,23,77,0.45);background:#0f172a;color:#e2e8f0;"></textarea>' +
            '<div id="gp_atompaw_output_modal" style="margin-top:14px;"></div>' +
            '</div>';

        document.body.appendChild(backdrop);

        backdrop.addEventListener('change', function (ev) {
            if (!ev.target || ev.target.id !== 'gp_atompaw_format_modal') return;
            if (typeof window.gpApplyAtompawFormatFromCache === 'function')
                window.gpApplyAtompawFormatFromCache(sym);
        });

        if (typeof window.gpFetchAutoInputs === 'function') {
            window.gpFetchAutoInputs(sym, 'atompaw');
        }

        var elSym = sym.slice(0, 8) || 'X';
        document.getElementById('gp_btn_atompaw_run_modal').onclick = function () {
            if (typeof window.gpRunAtompaw === 'function') window.gpRunAtompaw(elSym);
        };
        document.getElementById('gp_btn_atompaw_regen_modal').onclick = function () {
            if (typeof window.gpInvalidateAutoInputsCacheForSym === 'function')
                window.gpInvalidateAutoInputsCacheForSym(sym);
            else if (typeof window.gpAutoCache === 'object')
                delete window.gpAutoCache[sym];
            if (typeof window.gpFetchAutoInputs === 'function')
                window.gpFetchAutoInputs(sym, 'atompaw', true);
        };
        document.getElementById('gp_btn_atompaw_tpl_modal').onclick = function () {
            if (typeof window.gpLoadAtompawTemplate === 'function') window.gpLoadAtompawTemplate();
        };

        if (typeof window.gpRefreshAtompawStatus === 'function') window.gpRefreshAtompawStatus();
    };
})();

#!/usr/bin/env bash
exec "$(cd "$(dirname "$0")" && pwd)/scripts/TRANSFERER_VERS_AUTRE_PC.sh" "$@"

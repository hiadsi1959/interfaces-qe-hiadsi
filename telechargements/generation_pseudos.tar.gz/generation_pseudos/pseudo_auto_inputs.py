# -*- coding: utf-8 -*-
"""
Entrées APE / ATOMPAW générées automatiquement (atome neutre, Aufbau / Madelung).

Contexte DFT
------------
Les pseudopotentiels remplacent le cœur inerte par un potentiel effectif « doux » pour réduire
le coût tout en gardant une physique de valence correcte.

- **APE (Atomic Pseudopotential Engine)** : orienté pseudos **norm-conserving** (NC) ; résout les
  équations type Kohn-Sham pour la configuration demandée ; sorties typiques : potentiel ionique,
  pseudo-orbitales radiales, densité — formats utilisables avec **Quantum ESPRESSO** selon version.

- **ATOMPAW** : construit les données **PAW** (pseudo-partie douce pour r < r_c, raccord avec le
  tout-électron au-delà). Chaîne usuelle : ABINIT / XML / **UPF** pour QE (`PWSCFOUT`, etc.) selon
  options du jeu interactif.

Les entrées produites ici sont un **point de départ** : la génération de pseudos de qualité reste
**itérative** (ajuster r_c / semi-cœur / XC, contrôler transférabilité, ghost states, convergence SCF).
"""

from __future__ import annotations

from typing import Any

# Ordre standard 118 éléments (symbole → numéro atomique = index + 1)
_PERIODIC_SYMBOLS: tuple[str, ...] = (
    "H",
    "He",
    "Li",
    "Be",
    "B",
    "C",
    "N",
    "O",
    "F",
    "Ne",
    "Na",
    "Mg",
    "Al",
    "Si",
    "P",
    "S",
    "Cl",
    "Ar",
    "K",
    "Ca",
    "Sc",
    "Ti",
    "V",
    "Cr",
    "Mn",
    "Fe",
    "Co",
    "Ni",
    "Cu",
    "Zn",
    "Ga",
    "Ge",
    "As",
    "Se",
    "Br",
    "Kr",
    "Rb",
    "Sr",
    "Y",
    "Zr",
    "Nb",
    "Mo",
    "Tc",
    "Ru",
    "Rh",
    "Pd",
    "Ag",
    "Cd",
    "In",
    "Sn",
    "Sb",
    "Te",
    "I",
    "Xe",
    "Cs",
    "Ba",
    "La",
    "Ce",
    "Pr",
    "Nd",
    "Pm",
    "Sm",
    "Eu",
    "Gd",
    "Tb",
    "Dy",
    "Ho",
    "Er",
    "Tm",
    "Yb",
    "Lu",
    "Hf",
    "Ta",
    "W",
    "Re",
    "Os",
    "Ir",
    "Pt",
    "Au",
    "Hg",
    "Tl",
    "Pb",
    "Bi",
    "Po",
    "At",
    "Rn",
    "Fr",
    "Ra",
    "Ac",
    "Th",
    "Pa",
    "U",
    "Np",
    "Pu",
    "Am",
    "Cm",
    "Bk",
    "Cf",
    "Es",
    "Fm",
    "Md",
    "No",
    "Lr",
    "Rf",
    "Db",
    "Sg",
    "Bh",
    "Hs",
    "Mt",
    "Ds",
    "Rg",
    "Cn",
    "Nh",
    "Fl",
    "Mc",
    "Lv",
    "Ts",
    "Og",
)

_TRANSITION_3D: frozenset[str] = frozenset(
    _PERIODIC_SYMBOLS[_PERIODIC_SYMBOLS.index("Sc") : _PERIODIC_SYMBOLS.index("Zn") + 1]
)

SYMBOL_TO_Z: dict[str, int] = {s: i + 1 for i, s in enumerate(_PERIODIC_SYMBOLS)}

_NOBLE_ZS = (2, 10, 18, 36, 54, 86)
_NOBLE_SYM = {2: "He", 10: "Ne", 18: "Ar", 36: "Kr", 54: "Xe", 86: "Rn"}


def _madelung_nl_order() -> list[tuple[int, int]]:
    """(n,l) en ordre d’occupation type Madelung (n+l puis n croissant)."""
    seen: set[tuple[int, int]] = set()
    out: list[tuple[int, int]] = []
    for s in range(1, 28):
        for n in range(1, 18):
            l = s - n
            if l < 0 or l > 6:
                continue
            if n <= l:
                continue
            p = (n, l)
            if p not in seen:
                seen.add(p)
                out.append(p)
    return out


_M_ORDER = _madelung_nl_order()


def normalize_symbol(sym: str) -> str:
    s = (sym or "").strip()
    if not s:
        raise ValueError("Symbole vide")
    if len(s) == 1:
        key = s.upper()
    else:
        key = s[0].upper() + s[1:].lower()
    if key not in SYMBOL_TO_Z:
        raise ValueError(f"Symbole inconnu : {sym!r}")
    return key


def atomic_number(sym: str) -> int:
    return SYMBOL_TO_Z[normalize_symbol(sym)]


def neutral_configuration(Z: int) -> dict[tuple[int, int], int]:
    """Occupations électroniques par sous-couche (n,l), atome neutre."""
    if Z <= 0:
        return {}
    rem = Z
    occ: dict[tuple[int, int], int] = {}
    for n, l in _M_ORDER:
        if rem <= 0:
            break
        cap = 2 * (2 * l + 1)
        take = min(cap, rem)
        if take > 0:
            occ[(n, l)] = take
        rem -= take
    return occ


def _prev_noble(Z: int) -> tuple[int, str | None]:
    cz = 0
    name: str | None = None
    for zn in _NOBLE_ZS:
        if zn < Z:
            cz = zn
            name = _NOBLE_SYM[zn]
        else:
            break
    return cz, name


def _ape_auto_semicore(sym: str) -> bool:
    """Semi-cœur recommandé (3d, lanthanides, …) si la base élément le définit."""
    try:
        from elements_physics_db import get_element_info

        return bool(get_element_info(sym).get("semicore"))
    except ImportError:
        return False


def _orbitals_spin_lines_from_valence(
    valence: dict[tuple[int, int], int],
    noble_sym: str | None = None,
) -> str:
    """Bloc %Orbitals à partir d'une table de valence (n,l) → électrons."""
    lines: list[str] = []
    if noble_sym:
        lines.append(f'"{noble_sym}"')
    for (n, l), e in sorted(valence.items()):
        if e <= 0:
            continue
        if e % 2 == 0:
            lines.append(f"  {n} | {l} | {e // 2} | {e // 2}")
        else:
            lines.append(f"  {n} | {l} | {(e + 1) // 2} | {e // 2}")
    body = "\n".join(lines)
    return f"%Orbitals\n{body}\n%\n"


def _orbitals_spin_lines_valence(Z: int, noble_z: int, noble_sym: str | None) -> str:
    """Bloc %Orbitals au format n | l | up | down (Schrodinger non polarisé)."""
    total = neutral_configuration(Z)
    lines: list[str] = []
    if noble_z <= 0 or noble_sym is None:
        for (n, l), e in sorted(total.items()):
            if e % 2 == 0:
                lines.append(f"  {n} | {l} | {e // 2} | {e // 2}")
            else:
                lines.append(f"  {n} | {l} | {(e + 1) // 2} | {e // 2}")
        body = "\n".join(lines)
        return f"%Orbitals\n{body}\n%\n"

    core_occ = neutral_configuration(noble_z)
    valence: dict[tuple[int, int], int] = {}
    for k, v in total.items():
        dv = v - core_occ.get(k, 0)
        if dv > 0:
            valence[k] = dv
    orb_lines = [f'"{noble_sym}"']
    for (n, l), e in sorted(valence.items()):
        if e % 2 == 0:
            orb_lines.append(f"  {n} | {l} | {e // 2} | {e // 2}")
        else:
            orb_lines.append(f"  {n} | {l} | {(e + 1) // 2} | {e // 2}")
    return "%Orbitals\n" + "\n".join(orb_lines) + "\n%\n"


def _l_char(l: int) -> str:
    letters = "spdfghi"
    return letters[l] if 0 <= l < len(letters) else f"l{l}"


def _pp_components(valence_occ: dict[tuple[int, int], int]) -> str:
    lines = []
    for (n, l), e in sorted(valence_occ.items()):
        if e <= 0:
            continue
        rc = round(1.12 + 0.18 * l + 0.035 * n, 2)
        lines.append(f"  {n} | {l} | {rc} | ham")
    body = "\n".join(lines)
    return f"%PPComponents\n{body}\n%\n"


def _generation_valence_context(
    sym: str,
    semicore: bool,
    f_treatment: str | None = None,
) -> dict[str, Any]:
    """
    Cœur chimique + option semi-cœur (données DB) : même logique pour APE et ATOMPAW.

    Retourne notamment ``valence`` : occupations par (n,l) utilisées pour %PPComponents APE
    et pour les rayons de la queue interactive ATOMPAW.
    """
    sym = normalize_symbol(sym)
    Z = SYMBOL_TO_Z[sym]
    total = neutral_configuration(Z)
    semicore_eff = semicore or _ape_auto_semicore(sym)

    ft_label = None
    is_lanthanide = False
    try:
        import lanthanide_nc as lnc

        is_lanthanide = lnc.is_lanthanide(sym)
        if is_lanthanide:
            ft_label = lnc.normalize_f_treatment(f_treatment)
            valence = lnc.valence_occ_dict(sym, f_treatment)
            noble_z = 54
            noble_sym = "Xe"
            core_occ = neutral_configuration(noble_z)
        else:
            noble_z, noble_sym = _prev_noble(Z)
            core_occ = neutral_configuration(noble_z) if noble_z > 0 else {}
            valence = {}
            for k, v in total.items():
                dv = v - core_occ.get(k, 0)
                if dv > 0:
                    valence[k] = dv
    except ImportError:
        noble_z, noble_sym = _prev_noble(Z)
        core_occ = neutral_configuration(noble_z) if noble_z > 0 else {}
        valence = {}
        for k, v in total.items():
            dv = v - core_occ.get(k, 0)
            if dv > 0:
                valence[k] = dv

    has_db = False
    if semicore_eff:
        try:
            from elements_physics_db import get_element_info

            has_db = True
            info = get_element_info(sym)
            if not is_lanthanide:
                core_occ = neutral_configuration(noble_z) if noble_z > 0 else {}
            for (n, l) in info.get("semicore", []):
                if (n, l) in core_occ and core_occ[(n, l)] > 0:
                    valence[(n, l)] = core_occ[(n, l)]
        except ImportError:
            pass

    if semicore_eff and has_db:
        noble_z_orb = 0
        noble_sym_orb = None
    else:
        noble_z_orb = noble_z
        noble_sym_orb = noble_sym

    return {
        "sym": sym,
        "Z": Z,
        "noble_z": noble_z,
        "noble_sym": noble_sym,
        "noble_z_orb": noble_z_orb,
        "noble_sym_orb": noble_sym_orb,
        "total": total,
        "core_occ": core_occ,
        "valence": valence,
        "semicore_active": bool(semicore_eff and has_db),
        "semicore_auto": bool(semicore_eff and not semicore),
        "f_treatment": ft_label,
        "is_lanthanide": is_lanthanide or ft_label is not None,
    }


def generate_ape_input(
    sym: str,
    xc: str = "lda_pw",
    pp_type: str = "troullier",
    relativistic: bool = False,
    semicore: bool = False,
    rc_scale: float = 1.0,
    l_local: int | None = None,
    f_treatment: str | None = None,
) -> str:
    """
    Génère l'input APE complet.

    Paramètres
    ----------
    xc         : clé XC_DEFS (lda_pw, lda_pz, gga_pbe, gga_pbesol)
    pp_type    : clé PP_TYPE_APE (troullier, hamann)
    relativistic: True → WaveEquation = scalar_rel (APE)
    semicore   : True → inclut les couches semi-cœur recommandées
    rc_scale   : facteur multiplicatif sur tous les rc
    l_local    : surcharge du canal local (None = auto)
    """
    try:
        from elements_physics_db import XC_DEFS, PP_TYPE_APE, get_rc_for_orbital, get_element_info
        _HAS_DB = True
    except ImportError:
        _HAS_DB = False

    sym = normalize_symbol(sym)
    ctx = _generation_valence_context(sym, semicore, f_treatment)
    Z = ctx["Z"]
    valence = ctx["valence"]
    if ctx["noble_sym_orb"]:
        orb_block = _orbitals_spin_lines_from_valence(valence, ctx["noble_sym_orb"])
    elif ctx["noble_z_orb"] <= 0:
        orb_block = _orbitals_spin_lines_from_valence(valence, None)
    else:
        orb_block = _orbitals_spin_lines_valence(Z, ctx["noble_z_orb"], ctx["noble_sym_orb"])
    if ctx.get("is_lanthanide") and not relativistic:
        relativistic = True

    # XC
    xc_block = " lda_x\n lda_c_pw"
    if _HAS_DB and xc in XC_DEFS:
        xc_block = XC_DEFS[xc]["ape_block"]

    # Type pseudo
    pp_tag = "tm"
    if _HAS_DB and pp_type in PP_TYPE_APE:
        pp_tag = PP_TYPE_APE[pp_type]

    # Équation d'onde
    wave_eq = "scalar_rel" if relativistic else "schrodinger"

    # rc par orbital (avec scale)
    def _rc_for(n: int, l: int) -> float:
        if l == 3 and ctx.get("is_lanthanide"):
            try:
                import lanthanide_nc as lnc

                return lnc.rc_f_bohr(rc_scale)
            except ImportError:
                pass
        if _HAS_DB:
            return get_rc_for_orbital(sym, n, l, rc_scale)
        return round((1.12 + 0.18 * l + 0.035 * n) * rc_scale, 2)

    # %PPComponents avec rc physiques
    pp_lines = []
    for (n, l), e in sorted(valence.items()):
        if e <= 0:
            continue
        rc = _rc_for(n, l)
        pp_lines.append(f"  {n} | {l} | {rc} | {pp_tag}")
    pp_block = "%PPComponents\n" + "\n".join(pp_lines) + "\n%\n"

    # Canal local
    if l_local is None and _HAS_DB:
        info = get_element_info(sym)
        l_local_use = info.get("l_local", 2) if info else 2
    else:
        l_local_use = l_local if l_local is not None else 2

    local_line = ""
    if l_local_use >= 0:
        local_line = f"\nLocalComponent = {l_local_use}"

    xc_label = xc if not _HAS_DB else XC_DEFS.get(xc, {}).get("label", xc)
    rel_label = " scalar-rel" if relativistic else ""
    sc_label = " + semi-cœur (DB)" if ctx["semicore_active"] else (" + semi-cœur (case cochée, pas de DB)" if semicore else "")
    noble_hint = f"[{ctx['noble_sym']}]" if ctx["noble_sym"] else "pas de gaz noble explicite"

    xc_human_map = {
        "lda_pw": "LDA (PW92)",
        "lda_pz": "LDA (PZ81)",
        "gga_pbe": "PBE",
        "gga_pbesol": "PBEsol",
    }
    xc_human = xc_human_map.get(xc, xc_label)

    pp_human = "Troullier-Martins"
    if pp_tag == "ham":
        pp_human = "Hamann"
    elif pp_tag != "tm":
        pp_human = str(pp_tag)

    rc_per_l: dict[int, float] = {}
    for (n, l), e in sorted(valence.items()):
        if e <= 0:
            continue
        r = _rc_for(n, l)
        rc_per_l[l] = max(rc_per_l.get(l, 0.0), r)

    doc: list[str] = [
        "# --- Résumé projet (commentaires uniquement) — syntaxe APE exécutable après ce bloc ---",
        "# Atome et fonctionnelle",
        f"#   atom {sym}   |   Z = {Z}",
        f"#   cœur de référence : {noble_hint}",
        f"#   XC {xc_human}",
        "#",
        "# Configuration de valence (alignée sur %Orbitals / %PPComponents ci-dessous)",
        "#   n   l   occupation",
    ]
    for (n, l), e in sorted(valence.items()):
        if e <= 0:
            continue
        occ_f = float(e)
        occ_str = str(int(occ_f)) if abs(occ_f - round(occ_f)) < 1e-9 else repr(occ_f)
        doc.append(f"#   {n}   {l}   {occ_str}     # canal {_l_char(l)}")
    doc.extend(
        [
            "#",
            "# Méthode de génération",
            f"#   pseudopotential {pp_human} (norme conservée)",
            "#",
            "# Rayons de coupure r_c (Bohr) par nombre quantique l — détail par (n,l) dans %PPComponents",
            "#   l   r_c",
        ]
    )
    for l_key in sorted(rc_per_l.keys()):
        doc.append(f"#   {l_key}   {rc_per_l[l_key]:.2f}     # {_l_char(l_key)}")
    doc.extend(
        [
            "#",
            "# Options",
            "#   LocalComponent (canal local APE) : " + str(l_local_use),
            "#   relativity " + ("scalar (WaveEquation = scalar_rel)" if relativistic else "nonrel (schrodinger)"),
        ]
    )
    if ctx.get("semicore_auto"):
        doc.append("#   semi-cœur : activé automatiquement (métaux 3d / lanthanides — stabilité APE + QE)")
    elif ctx["semicore_active"]:
        doc.append("#   semi-cœur : couches issues de la base élément incluses dans la valence")
    doc.extend(
        [
            "#   nlcc : désactivé par défaut — activer seulement si votre protocole APE le requiert",
            "#",
            "# Sortie pour Quantum ESPRESSO",
            "#   output UPF (via chaîne APE applicable à votre installation)",
            f"#   (réglages effectifs : {xc_label}{rel_label}{sc_label})",
            "# --- Fin du résumé commenté ---",
            "",
        ]
    )
    doc_block = "\n".join(doc)

    return f"""{doc_block}Title = "{sym}"
CalculationMode = ae + pp
Verbose = 40

WaveEquation = {wave_eq}
SpinMode = unpolarized

%XCFunctionals
{xc_block}
%

NuclearCharge = {Z}
{local_line}
{orb_block}
{pp_block}
PPOutputFileFormat = upf

PPCalculationTolerance = 1e-6

EigenSolverTolerance = 1e-8
ODEIntTolerance = 1e-12
"""


def _atompaw_orbital_order(npv: list[int]) -> list[tuple[int, int]]:
    out: list[tuple[int, int]] = []
    for ll in range(5):
        nn = npv[ll]
        if nn <= 0:
            continue
        for ii in range(ll + 1, nn + 1):
            out.append((ii, ll))
    return out


def _compute_np(total_occ: dict[tuple[int, int], int]) -> list[int]:
    npv = [0, 0, 0, 0, 0]
    for (n, l), e in total_occ.items():
        if e > 0 and l < 5:
            npv[l] = max(npv[l], n)
    return npv


def _atompaw_occ_mod_lines(npv: list[int], total_occ: dict[tuple[int, int], int]) -> list[str]:
    lines: list[str] = []
    for ll in range(5):
        nn = npv[ll]
        if nn <= 0:
            continue
        for ii in range(ll + 1, nn + 1):
            cap = 2 * (2 * ll + 1)
            occ = float(total_occ.get((ii, ll), 0))
            if abs(occ - float(cap)) > 1e-9:
                if abs(occ - round(occ)) < 1e-9:
                    lines.append(f"{ii} {ll} {int(round(occ))}")
                else:
                    lines.append(f"{ii} {ll} {occ}")
    lines.append("0 0 0")
    return lines


def _atompaw_cv_block(Z: int, npv: list[int], noble_z: int) -> str:
    total = neutral_configuration(Z)
    core_occ = neutral_configuration(noble_z) if noble_z > 0 else {}
    chars: list[str] = []
    if Z == 3:
        return "\n".join(["v"] * len(_atompaw_orbital_order(npv)))
    for n, l in _atompaw_orbital_order(npv):
        te = total.get((n, l), 0)
        ce = core_occ.get((n, l), 0)
        if noble_z > 0 and ce > 0 and te == ce:
            chars.append("c")
        else:
            chars.append("v")
    return "\n".join(chars)


# Queues « projet » adaptées des exemples Li / F / Na du dépôt ATOMPAW (non relativistes, LDA-PW).
_TAIL_Z_LE10 = """1
1.6
n 
y
0.0
n 
VANDERBILT
2 0
1.4
1.6
1.6
ABINITOUT
default
XMLOUT
default
PWSCFOUT
UPFDX  0.008d0   UPFXMIN   -7.d0     UPFZMESH 3.d0
PWPAWOUT
END
0
"""

_TAIL_Z_6_10 = """1
1.5
y 
2 
n
y
2 
n 
VANDERBILT   
2 0
1.5
1.5
1.5
1.5
ABINITOUT
default
XMLOUT
default
PWSCFOUT
UPFDX  0.008d0   UPFXMIN   -7.d0     UPFZMESH 9.d0
PWPAWOUT
END
"""

_TAIL_GE11 = """1
1.7   1.5   1.7    1.7
n
y
4.6
n
VANDERBILT  Besselshape
2 0   MTROULLIER
1.5
1.7
1.5
1.7
XMLOUT
default
PWPAWOUT
ABINITOUT
default
PWSCFOUT
UPFDX  0.0125d0   UPFXMIN   -7.d0     UPFZMESH 11.d0
END
"""


def _atompaw_tail(Z: int) -> str:
    if Z <= 5:
        return _TAIL_Z_LE10
    if Z <= 10:
        return _TAIL_Z_6_10
    return _TAIL_GE11


def atompaw_input_is_obsolete(text: str) -> bool:
    """Détecte les anciennes entrées (queue rc/lmax ou grille collée) à régénérer."""
    if not text or not str(text).strip():
        return False
    t = str(text)
    if "loggridv4scalarrel" in t.replace(" ", "").lower():
        return True
    if "rc(Vloc) is missing" in t:
        return True
    lines = t.strip().splitlines()
    for i, line in enumerate(lines):
        if line.strip().lower().startswith("v") and i + 1 < len(lines):
            nxt = lines[i + 1].strip()
            parts = nxt.split()
            if len(parts) == 1 and parts[0].isdigit():
                return True
            if len(parts) == 2 and not any(k in t for k in ("MTROULLIER", "PWSCFOUT")):
                try:
                    float(parts[0])
                    float(parts[1])
                    if i + 2 < len(lines) and lines[i + 2].strip().lower() in ("n", "y"):
                        return False
                    return True
                except ValueError:
                    pass
    return False


def _atompaw_lmax_from_valence(valence_occ: dict) -> int:
    ls = [l for (n, l), e in valence_occ.items() if e > 0]
    return max(ls) if ls else 0


def _atompaw_tail_parametric(
    Z: int,
    pp_type: str,
    rc_scale: float,
    sym: str,
    valence_occ: dict,
    npv: list[int],
) -> str:
    """
    Queue stdin ATOMPAW 4.2 après le bloc c/v du fichier interactif.

    Ordre attendu : lmax → rc rc_shap rc_vloc rc_core → (n|y+ε) pour l=0..lmax
    → VANDERBILT Besselshape → l ε MTROULLIER → r_c par orbitale de valence → sorties PWSCFOUT.
    """
    try:
        from elements_physics_db import PP_TYPE_ATOMPAW, get_rc_for_orbital
        pp_kw = PP_TYPE_ATOMPAW.get(pp_type, "VANDERBILT Besselshape")
    except ImportError:
        pp_kw = "VANDERBILT Besselshape"
        get_rc_for_orbital = lambda s, n, l, sc: round((1.12 + 0.18 * l + 0.035 * n) * sc, 3)

    if "Besselshape" not in pp_kw:
        pp_kw = pp_kw.strip() + " Besselshape"

    lmax = _atompaw_lmax_from_valence(valence_occ)
    noble_z, _ = _prev_noble(Z)
    cv_chars = _atompaw_cv_block(Z, npv, noble_z).splitlines()
    valence_orbitals = [
        (n, l)
        for (n, l), cv in zip(_atompaw_orbital_order(npv), cv_chars)
        if cv.strip().lower() == "v"
    ]
    val_rc = [
        float(get_rc_for_orbital(sym, n, l, rc_scale))
        for n, l in valence_orbitals
    ]
    rc_main = max(val_rc) if val_rc else round(1.2 * rc_scale, 3)
    # ATOMPAW exige rc_shap, rc_vloc, rc_core strictement < rc (1er nombre).
    rc_shap = round(rc_main * 0.98, 3)
    rc_vloc = round(rc_main * 0.97, 3)
    rc_core = round(rc_main * 0.85, 3)

    lines: list[str] = [
        str(lmax),
        f"{rc_main:.3f} {rc_shap:.3f} {rc_vloc:.3f} {rc_core:.3f}",
    ]
    for _l in range(lmax + 1):
        lines.append("n")

    vloc_l = _atompaw_lmax_from_valence(valence_occ)
    lines.append(pp_kw)
    lines.append(f"{vloc_l} 0.0 MTROULLIER")

    for n, l in valence_orbitals:
        lines.append(f"{get_rc_for_orbital(sym, n, l, rc_scale):.3f}")

    zmesh = round(max(3.0, float(Z) * 0.15), 1)
    upfdx = "0.008d0" if Z <= 10 else "0.0125d0"
    # Phase post-calcul (stdin) : uniquement PWSCFOUT → options UPF → END.
    # XMLOUT/ABINITOUT/default intercalés provoquent « Option not recognized » sans .UPF.
    lines.extend([
        "PWSCFOUT",
        f"UPFDX  {upfdx}   UPFXMIN   -7.d0     UPFZMESH {zmesh:.1f}d0",
        "END",
    ])
    return "\n".join(lines) + "\n"


def generate_atompaw_input_qe_file(
    sym: str,
    xc: str = "lda_pw",
    pp_type: str = "vanderbilt",
    relativistic: bool = False,
    semicore: bool = False,
    rc_scale: float = 1.0,
    f_treatment: str | None = None,
) -> str:
    """
    Entrée ATOMPAW « fichier » pour usage type ``atompaw < fichier`` (QE / UPF).

    Structure voisine des exemples cours : symbole Z, XC + relativité, cœur noble entre
    crochets, occupations valence, deux projecteurs par canal (occupé + 0.0), Vanderbilt,
    liste des r_c, potentiel local, puis ``shape``, ``log``, ``2``, ``upf``, ``default``, ``0``.

    Les rayons viennent de ``elements_physics_db`` lorsque disponible, × ``rc_scale``.
    Les versions ATOMPAW peuvent différer : valider sur votre binaire.
    """
    sym = normalize_symbol(sym)
    Z = SYMBOL_TO_Z[sym]
    ctx = _generation_valence_context(sym, semicore, f_treatment)
    noble_sym = ctx["noble_sym"]
    core_line = f"[{noble_sym}]" if noble_sym else ""
    if ctx.get("is_lanthanide") and not relativistic:
        relativistic = True

    try:
        from elements_physics_db import get_rc_for_orbital
        _HAS_DB = True
    except ImportError:
        _HAS_DB = False

        def get_rc_for_orbital(_s: str, n: int, l: int, scale: float) -> float:
            return round((1.12 + 0.18 * l + 0.035 * n) * scale, 3)

    xc_qe = {
        "lda_pw": "lda pw",
        "lda_pz": "lda pz",
        "gga_pbe": "pbe",
        "gga_pbesol": "pbesol",
    }
    xc_tok = xc_qe.get(xc, "lda pw")
    rel_tok = "scalarrel" if relativistic else "nonrel"

    pp_qe = {
        "vanderbilt": "vanderbilt",
        "bloechl": "bloechl",
        "vanderbilt_tm": "vanderbilt",
    }
    pp_lower = pp_qe.get(pp_type, "vanderbilt")

    valence_rows = sorted((n, l, e) for (n, l), e in ctx["valence"].items() if e > 0)

    def _occ_token(val: float) -> str:
        v = float(val)
        if abs(v - round(v)) < 1e-9:
            return f"{int(round(v))}.0"
        t = f"{v:.6f}".rstrip("0").rstrip(".")
        return t if t else "0.0"

    config_lines = "\n".join(f"{n} {l} {_occ_token(float(e))}" for n, l, e in valence_rows)

    proj_lines: list[str] = []
    rc_list: list[float] = []
    for n, l, e in valence_rows:
        proj_lines.append(f"{n} {l} {_occ_token(float(e))}")
        proj_lines.append(f"{n} {l} 0.0")
        rc_v = float(get_rc_for_orbital(sym, n, l, rc_scale))
        rc_list.extend([rc_v, rc_v])

    if not valence_rows:
        raise ValueError(f"Aucune orbitale de valence pour {sym} — vérifiez Z et semi-cœur.")

    n_proj = len(rc_list)
    proj_block = "\n".join(proj_lines)
    rc_joined = " ".join(f"{r:.2f}" for r in rc_list)
    rc_local = round(max(rc_list) * 1.08, 2) if rc_list else 2.0
    rc_local = max(rc_local, 1.2)

    return (
        f"{sym} {Z}\n"
        f"{xc_tok} {rel_tok}\n"
        f"{core_line}\n"
        f"{config_lines}\n"
        f"0 0 0\n"
        f"{n_proj}\n"
        f"{proj_block}\n"
        f"{pp_lower}\n"
        f"{rc_joined}\n"
        f"{rc_local:.2f}\n"
        f"shape\n"
        f"log\n"
        f"2\n"
        f"upf\n"
        f"default\n"
        f"0\n"
    )


def generate_atompaw_input(
    sym: str,
    xc: str = "lda_pw",
    pp_type: str = "vanderbilt",
    relativistic: bool = False,
    semicore: bool = False,
    rc_scale: float = 1.0,
    l_local: int | None = None,
    f_treatment: str | None = None,
) -> str:
    """
    Génère l'input ATOMPAW (lu par stdin).

    Paramètres
    ----------
    xc          : clé XC_DEFS (lda_pw, lda_pz, gga_pbe, gga_pbesol)
    pp_type     : clé PP_TYPE_ATOMPAW (vanderbilt, bloechl, vanderbilt_tm)
    relativistic: True → loggridv4 scalarrelativistic
    semicore    : True → couches semi-cœur recommandées traitées en valence
    rc_scale    : facteur multiplicatif sur tous les rc
    l_local     : non utilisé pour ATOMPAW (conservé pour cohérence API)
    """
    try:
        from elements_physics_db import XC_DEFS, get_element_info
        xc_kw = XC_DEFS.get(xc, XC_DEFS["lda_pw"])["atompaw_kw"]
    except ImportError:
        xc_kw = "LDA-PW"
        get_element_info = lambda s: {}

    sym = normalize_symbol(sym)
    Z = SYMBOL_TO_Z[sym]
    noble_z, _ = _prev_noble(Z)
    total = neutral_configuration(Z)

    if semicore:
        info = get_element_info(sym)
        core_occ_base = neutral_configuration(noble_z) if noble_z > 0 else {}
        extra = {(n, l): core_occ_base.get((n, l), 0)
                 for (n, l) in info.get("semicore", [])
                 if core_occ_base.get((n, l), 0) > 0}
        # Ajouter les couches semi-cœur à total pour le calcul npv
        total_ext = dict(total)
        total_ext.update(extra)
        npv = _compute_np(total_ext)
        noble_z_adj = 0
    else:
        npv = _compute_np(total)
        noble_z_adj = noble_z
        total_ext = total

    occ_lines = _atompaw_occ_mod_lines(npv, total_ext)
    cv = _atompaw_cv_block(Z, npv, noble_z_adj)
    np_str = " ".join(str(x) for x in npv)
    block_occ = "\n".join(occ_lines)

    ctx_aw = _generation_valence_context(sym, semicore, f_treatment)
    if ctx_aw.get("is_lanthanide") and not relativistic:
        relativistic = True
    grid_type = "loggridv4 scalarrelativistic" if relativistic else "loggridv4"
    tail = _atompaw_tail_parametric(Z, pp_type, rc_scale, sym, ctx_aw["valence"], npv)
    head = f"{sym} {Z}\n{xc_kw} {grid_type} 2001\n{np_str}\n{block_occ}\n{cv}\n"
    return head + tail


def qe_route_hint(sym: str) -> dict[str, Any]:
    """Recommandation Quantum ESPRESSO selon la famille d'éléments."""
    sym_n = normalize_symbol(sym)
    z = atomic_number(sym_n)
    hint: dict[str, Any] = {
        "element": sym_n,
        "Z": z,
        "ape_nc": "standard",
        "recommended_generators": ["ape", "atompaw", "ld1"],
        "message": "APE NC + sortie UPF (PPOutputFileFormat=upf) adapté à pw.x.",
    }
    try:
        import lanthanide_nc as lnc

        if lnc.is_lanthanide(sym_n):
            hint.update(
                {
                    "ape_nc": "difficile",
                    "recommended_generators": ["oncvpsp", "atompaw", "pseudodojo"],
                    "message": (
                        "Lanthanide (4f) : APE NC converge souvent mal — "
                        "ONCVPSP (psfile=both) ou PseudoDojo, PAW via ATOMPAW pour QE."
                    ),
                }
            )
            return hint
    except ImportError:
        pass
    if sym_n in _TRANSITION_3D:
        hint.update(
            {
                "ape_nc": "difficile",
                "recommended_generators": ["atompaw", "oncvpsp", "pseudodojo", "ld1"],
                "message": (
                    "Métal 3d (Sc–Zn) : APE NC instable (crash ou GSL) — "
                    "privilégier ATOMPAW (PAW → UPF QE) ou bibliothèques NC (PseudoDojo)."
                ),
            }
        )
    return hint


def inputs_breakdown(
    sym: str,
    xc: str,
    pp_type_ape: str,
    pp_type_atompaw: str,
    relativistic: bool,
    semicore: bool,
    rc_scale: float,
    l_local: int | None,
    f_treatment: str | None = None,
) -> dict[str, Any]:
    """
    Synthèse JSON pour l’interface : contenu issu de ``elements_physics_db`` (rc, semi-cœur, …)
    croisé avec les paramètres utilisateur (xc, rc_scale, …) et les grandeurs effectivement
    injectées dans les entrées APE / ATOMPAW.
    """
    sym_n = normalize_symbol(sym)
    ctx = _generation_valence_context(sym_n, semicore, f_treatment)
    Z = ctx["Z"]
    lanth_guide: dict[str, Any] = {}
    try:
        import lanthanide_nc as lnc

        if lnc.is_lanthanide(sym_n):
            lanth_guide = lnc.get_guide(sym_n, f_treatment)
    except ImportError:
        pass

    try:
        from elements_physics_db import (
            PP_TYPE_APE,
            PP_TYPE_ATOMPAW,
            XC_DEFS,
            get_element_info,
            get_rc_for_orbital,
        )

        _HAS_DB = True
    except ImportError:
        XC_DEFS = {}
        PP_TYPE_APE = {}
        PP_TYPE_ATOMPAW = {}

        def get_element_info(_s: str) -> dict:
            return {}

        def get_rc_for_orbital(_s: str, n: int, l: int, scale: float) -> float:
            return round((1.12 + 0.18 * l + 0.035 * n) * scale, 3)

        _HAS_DB = False

    info_el = get_element_info(sym_n) if _HAS_DB else {}

    pp_tag = PP_TYPE_APE.get(pp_type_ape, "tm") if _HAS_DB else "tm"
    ape_rows: list[dict[str, Any]] = []
    for (n, l), e in sorted(ctx["valence"].items()):
        if e <= 0:
            continue
        base = round(float(get_rc_for_orbital(sym_n, n, l, 1.0)), 3)
        eff = round(float(base) * rc_scale, 3)
        ape_rows.append(
            {
                "n": n,
                "l": l,
                "l_label": _l_char(l),
                "electrons": e,
                "rc_bohr_from_db_unit": base,
                "rc_bohr_effective": eff,
                "pp_scheme_token": pp_tag,
            }
        )

    if l_local is None and _HAS_DB:
        l_loc_eff = int(info_el.get("l_local", 2)) if info_el else 2
    else:
        l_loc_eff = int(l_local) if l_local is not None else 2

    db_snap: dict[str, Any] = {}
    if _HAS_DB and info_el:
        db_snap = {
            "rc_default_bohr": info_el.get("rc_default"),
            "rc_by_l_bohr": {str(k): v for k, v in info_el.get("rc_by_l", {}).items()},
            "l_local_recommended": info_el.get("l_local"),
            "scalar_rel_recommended": info_el.get("scalar_rel"),
            "semicore_shells": [[a, b] for a, b in info_el.get("semicore", [])],
            "note": info_el.get("note", ""),
        }

    ls_tail = sorted({l for (_, l) in ctx["valence"].keys()})
    atompaw_tail_rc: list[dict[str, Any]] = []
    for l in ls_tail:
        atompaw_tail_rc.append(
            {
                "l": l,
                "l_label": _l_char(l),
                "rc_bohr_effective": round(float(get_rc_for_orbital(sym_n, 0, l, rc_scale)), 3),
            }
        )

    xc_label = XC_DEFS.get(xc, {}).get("label", xc) if _HAS_DB else xc
    lda = XC_DEFS.get("lda_pw", {}) if _HAS_DB else {}
    aw_kw = XC_DEFS.get(xc, lda).get("atompaw_kw", "LDA-PW") if _HAS_DB else "LDA-PW"
    pp_aw_kw = PP_TYPE_ATOMPAW.get(pp_type_atompaw, "VANDERBILT") if _HAS_DB else "VANDERBILT"

    return {
        "element": sym_n,
        "Z": Z,
        "qe_route": qe_route_hint(sym_n),
        "noble_core_label": (f"[{ctx['noble_sym']}]" if ctx["noble_sym"] else None),
        "semicore_active": ctx["semicore_active"],
        "user_params": {
            "xc": xc,
            "pp_type_ape": pp_type_ape,
            "pp_type_atompaw": pp_type_atompaw,
            "relativistic": relativistic,
            "semicore_requested": semicore,
            "rc_scale": rc_scale,
            "l_local_override": l_local,
        },
        "database_element": db_snap,
        "ape": {
            "wave_equation": "scalar_rel" if relativistic else "schrodinger",
            "xc_label": xc_label,
            "local_component_l": l_loc_eff,
            "full_atom_orbital_listing": ctx["semicore_active"],
            "pp_components": ape_rows,
        },
        "lanthanide_nc": lanth_guide,
        "atompaw": {
            "xc_keyword": aw_kw,
            "grid": "loggridv4 scalarrelativistic" if relativistic else "loggridv4",
            "pp_type_keyword": pp_aw_kw,
            "tail_rc_one_per_valence_l_channel": atompaw_tail_rc,
            "stdin_note": (
                "Ne pas ajouter de lignes commentées (#) dans l’entrée ATOMPAW pour le binaire ; "
                "le détail physique est dans input_breakdown (API) et dans l’assistant web."
            ),
            "qe_file_hint": (
                "Format alternatif JSON ``atompaw_input_qe`` : fichier court pour ``atompaw < entrée`` "
                "(à valider avec votre version ATOMPAW)."
            ),
        },
    }

#!/usr/bin/env bash
# Alias rétrocompatible — préférez ./configure.sh
exec "$(cd "$(dirname "$0")" && pwd)/scripts/configure.sh" "$@"

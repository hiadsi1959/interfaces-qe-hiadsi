#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Téléchargement complet des pseudopotentiels — Tous les éléments, tous les types
Source : Bibliothèque officielle Quantum ESPRESSO (PSLibrary 1.0.0)
         + SG15 ONCVPSP (Norm-Conserving, optimisés)
         + SSSP Efficiency & Precision (si disponibles)

Répertoire de sortie : generation_pseudos/pseudos/
Sous-dossiers : PBE/PAW/, PBE/USPP/, PBE/NC/
"""

import os, sys, time, json
import urllib.request
import urllib.error
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock

# ── Configuration ──────────────────────────────────────────────────────────────
BASE_DIR    = Path(__file__).parent
PSEUDOS_DIR = BASE_DIR / "pseudos"
LOG_FILE    = BASE_DIR / "logs" / "download_pseudos.log"

QE_BASE_URL = "https://pseudopotentials.quantum-espresso.org/upf_files"
SG15_URL    = "http://www.quantum-simulation.org/potentials/sg15_oncv/upf"

MAX_WORKERS = 6   # téléchargements parallèles
TIMEOUT     = 60  # secondes par fichier

# ── Tous les éléments du tableau périodique ────────────────────────────────────
ELEMENTS = [
    "H",  "He",
    "Li", "Be", "B",  "C",  "N",  "O",  "F",  "Ne",
    "Na", "Mg", "Al", "Si", "P",  "S",  "Cl", "Ar",
    "K",  "Ca", "Sc", "Ti", "V",  "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
    "Ga", "Ge", "As", "Se", "Br", "Kr",
    "Rb", "Sr", "Y",  "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd",
    "In", "Sn", "Sb", "Te", "I",  "Xe",
    "Cs", "Ba",
    "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy",
    "Ho", "Er", "Tm", "Yb", "Lu",
    "Hf", "Ta", "W",  "Re", "Os", "Ir", "Pt", "Au", "Hg",
    "Tl", "Pb", "Bi", "Po", "At", "Rn",
    "Fr", "Ra",
    "Ac", "Th", "Pa", "U",  "Np", "Pu",
]

# ── Patterns de noms PSLibrary 1.0.0 ──────────────────────────────────────────
# Chaque tuple : (suffixe, sous-dossier, description)
PSLIB_PATTERNS = [
    # PAW PBE
    ("pbe-n-kjpaw_psl.1.0.0.UPF",        "PBE/PAW", "PAW PBE scalar"),
    ("pbe-spn-kjpaw_psl.1.0.0.UPF",      "PBE/PAW", "PAW PBE spin"),
    ("pbe-dn-kjpaw_psl.1.0.0.UPF",       "PBE/PAW", "PAW PBE spin+d"),
    ("pbe-n-rrkjus_psl.1.0.0.UPF",       "PBE/USPP", "USPP PBE scalar"),
    ("pbe-rrkjus_psl.1.0.0.UPF",         "PBE/USPP", "USPP PBE"),
    ("pbe-spn-rrkjus_psl.1.0.0.UPF",     "PBE/USPP", "USPP PBE spin"),
    ("pbe-dn-rrkjus_psl.1.0.0.UPF",      "PBE/USPP", "USPP PBE spin+d"),
    # PAW LDA
    ("lda-n-kjpaw_psl.1.0.0.UPF",        "LDA/PAW", "PAW LDA scalar"),
    ("lda-spn-kjpaw_psl.1.0.0.UPF",      "LDA/PAW", "PAW LDA spin"),
    ("lda-dn-kjpaw_psl.1.0.0.UPF",       "LDA/PAW", "PAW LDA spin+d"),
    ("lda-n-rrkjus_psl.1.0.0.UPF",       "LDA/USPP", "USPP LDA scalar"),
    ("lda-rrkjus_psl.1.0.0.UPF",         "LDA/USPP", "USPP LDA"),
    ("lda-spn-rrkjus_psl.1.0.0.UPF",     "LDA/USPP", "USPP LDA spin"),
    ("lda-dn-rrkjus_psl.1.0.0.UPF",      "LDA/USPP", "USPP LDA spin+d"),
    # Versions antérieures (certains éléments n'ont que celles-ci)
    ("pbe-n-kjpaw_psl.0.1.UPF",          "PBE/PAW", "PAW PBE v0.1"),
    ("pbe-spn-kjpaw_psl.0.2.3.UPF",      "PBE/PAW", "PAW PBE v0.2.3"),
    ("pbe-rrkjus_psl.0.2.3.UPF",         "PBE/USPP", "USPP PBE v0.2.3"),
    ("pbe-spn-rrkjus_psl.0.2.3.UPF",     "PBE/USPP", "USPP PBE spin v0.2.3"),
]

# ── Compteurs globaux ───────────────────────────────────────────────────────────
lock         = Lock()
stats        = {"ok": 0, "skip": 0, "fail": 0, "size": 0}
log_lines    = []

# ── Fonctions utilitaires ───────────────────────────────────────────────────────

def log(msg, end="\n"):
    with lock:
        print(msg, end=end, flush=True)
        log_lines.append(msg)

def human_size(b):
    for u in ["B","KB","MB","GB"]:
        if b < 1024: return f"{b:.1f} {u}"
        b /= 1024
    return f"{b:.1f} GB"

def url_exists_and_download(url, dest_path):
    """Télécharge l'URL si elle répond 200. Retourne (ok, taille, erreur)."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            if resp.status != 200:
                return False, 0, f"HTTP {resp.status}"
            data = resp.read()
            if len(data) < 500:
                return False, 0, "fichier trop petit (probablement 404 HTML)"
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            dest_path.write_bytes(data)
            return True, len(data), None
    except urllib.error.HTTPError as e:
        return False, 0, f"HTTP {e.code}"
    except Exception as e:
        return False, 0, str(e)[:60]

def telecharger_pslib(element, suffix, subdir):
    """Télécharge un pseudo PSLibrary pour un élément donné."""
    filename  = f"{element}.{suffix}"
    dest_path = PSEUDOS_DIR / subdir / filename
    url       = f"{QE_BASE_URL}/{filename}"

    if dest_path.exists() and dest_path.stat().st_size > 500:
        with lock:
            stats["skip"] += 1
        return ("skip", element, filename, dest_path.stat().st_size)

    ok, size, err = url_exists_and_download(url, dest_path)
    with lock:
        if ok:
            stats["ok"]   += 1
            stats["size"] += size
            return ("ok", element, filename, size)
        else:
            stats["fail"] += 1
            return ("fail", element, filename, err)

def telecharger_sg15(element):
    """Télécharge le pseudo SG15 ONCVPSP (NC) pour un élément."""
    results = []
    for variant in [f"{element}_ONCV_PBE-1.2.upf",
                    f"{element}_ONCV_PBE_sr.upf",
                    f"{element}.oncvpsp.upf"]:
        dest_path = PSEUDOS_DIR / "PBE" / "NC" / variant
        if dest_path.exists() and dest_path.stat().st_size > 500:
            with lock:
                stats["skip"] += 1
            results.append(("skip", element, variant, dest_path.stat().st_size))
            break
        url = f"{SG15_URL}/{variant}"
        ok, size, err = url_exists_and_download(url, dest_path)
        with lock:
            if ok:
                stats["ok"]   += 1
                stats["size"] += size
                results.append(("ok", element, variant, size))
                break
            else:
                stats["fail"] += 1
    return results

def tache(args):
    """Fonction exécutée par le pool de threads."""
    kind, *rest = args
    if kind == "pslib":
        element, suffix, subdir = rest
        return [telecharger_pslib(element, suffix, subdir)]
    elif kind == "sg15":
        element, = rest
        return telecharger_sg15(element)

# ── Affichage barre de progression ─────────────────────────────────────────────

def barre(done, total, width=40):
    pct   = done / total if total else 0
    rempli = int(pct * width)
    return f"[{'█' * rempli}{'░' * (width - rempli)}] {done}/{total} ({pct*100:.1f}%)"

# ── Programme principal ─────────────────────────────────────────────────────────

def main():
    print()
    print("═" * 65)
    print("  📦 Téléchargement des pseudopotentiels — Quantum ESPRESSO")
    print("  Source : PSLibrary 1.0.0 + SG15 ONCVPSP")
    print("═" * 65)
    print(f"  Répertoire : {PSEUDOS_DIR}")
    print(f"  Éléments   : {len(ELEMENTS)}")
    print(f"  Types      : PAW PBE/LDA + USPP PBE/LDA + NC PBE (SG15)")
    print(f"  Parallèle  : {MAX_WORKERS} téléchargements simultanés")
    print()

    # Créer les sous-dossiers
    for sub in ["PBE/PAW", "PBE/USPP", "PBE/NC", "LDA/PAW", "LDA/USPP"]:
        (PSEUDOS_DIR / sub).mkdir(parents=True, exist_ok=True)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

    # Construire la liste des tâches
    tasks = []
    for el in ELEMENTS:
        for suffix, subdir, _ in PSLIB_PATTERNS:
            tasks.append(("pslib", el, suffix, subdir))
        tasks.append(("sg15", el))

    total = len(tasks)
    done  = 0
    t0    = time.time()

    print(f"  {total} vérifications à effectuer...")
    print()

    resultats_ok  = []
    resultats_err = []

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
        futures = {pool.submit(tache, t): t for t in tasks}
        for future in as_completed(futures):
            done += 1
            results = future.result()
            for r in results:
                status, el, fname, info = r
                if status == "ok":
                    resultats_ok.append((el, fname, info))
                    log(f"  ✅ {fname:<55} {human_size(info)}")
                elif status == "skip":
                    pass  # déjà présent, silencieux
                # fail : silencieux (attendu pour patterns non applicables)

            # Mettre à jour la barre toutes les 10 tâches
            if done % 10 == 0 or done == total:
                elapsed = time.time() - t0
                bar = barre(done, total)
                with lock:
                    print(f"\r  {bar}  {elapsed:.0f}s ", end="", flush=True)

    elapsed = time.time() - t0
    print(f"\r  {barre(total, total)}  {elapsed:.0f}s ")
    print()
    print("═" * 65)
    print(f"  ✅ Téléchargés  : {stats['ok']} fichiers")
    print(f"  ⏭️  Déjà présents : {stats['skip']} fichiers")
    print(f"  📦 Taille totale : {human_size(stats['size'])}")
    print(f"  ⏱️  Durée totale  : {elapsed:.0f}s")
    print("═" * 65)
    print()

    if resultats_ok:
        print("  Fichiers téléchargés :")
        for el, fname, size in sorted(resultats_ok):
            print(f"    {fname:<55} {human_size(size)}")
        print()

    # Compter par sous-dossier
    print("  Résumé par dossier :")
    for sub in ["PBE/PAW", "PBE/USPP", "PBE/NC", "LDA/PAW", "LDA/USPP"]:
        d = PSEUDOS_DIR / sub
        n = len(list(d.glob("*.UPF")) + list(d.glob("*.upf"))) if d.exists() else 0
        print(f"    {sub:<15} : {n} fichier(s)")
    print()

    # Sauvegarder le log
    with open(LOG_FILE, "w") as f:
        f.write("\n".join(log_lines))
    print(f"  📄 Log sauvegardé : {LOG_FILE}")
    print()

if __name__ == "__main__":
    main()

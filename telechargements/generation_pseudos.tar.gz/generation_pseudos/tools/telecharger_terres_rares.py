#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Téléchargement des pseudopotentiels — Terres rares + Actinides
Sources :
  - GBRV (Ultrasoft PBE, Rutgers) — tous les lanthanides + actinides
  - SG15 ONCVPSP (NC, si disponible)
  - QE Library (PAW/USPP PSLibrary, si disponible)
"""

import os, urllib.request, urllib.error, time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock

BASE_DIR    = Path(__file__).parent
PSEUDOS_DIR = BASE_DIR / "pseudos"
LOG_FILE    = BASE_DIR / "logs" / "download_terres_rares.log"

MAX_WORKERS = 6
TIMEOUT     = 60

# Terres rares (lanthanides) + actinides
TERRES_RARES = [
    "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu",
    "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu",
]
ACTINIDES = ["Ac", "Th", "Pa", "U", "Np", "Pu"]
ELEMENTS_SPECIAUX = TERRES_RARES + ACTINIDES

# URLs GBRV (Ultrasoft PBE)
GBRV_BASE = "https://www.physics.rutgers.edu/gbrv"
GBRV_VERS = ["v1.2", "v1.4", "v1.5"]

# URL SG15 ONCVPSP (NC PBE)
SG15_BASE = "http://www.quantum-simulation.org/potentials/sg15_oncv/upf"

# URL QE Library
QE_BASE   = "https://pseudopotentials.quantum-espresso.org/upf_files"

# Patterns PSLibrary pour terres rares (relativistes)
PSLIB_SUFFIXES = [
    ("pbe-spn-kjpaw_psl.1.0.0.UPF",   "PBE/PAW"),
    ("pbe-spn-rrkjus_psl.1.0.0.UPF",  "PBE/USPP"),
    ("pbe-dn-kjpaw_psl.1.0.0.UPF",    "PBE/PAW"),
    ("pbe-dn-rrkjus_psl.1.0.0.UPF",   "PBE/USPP"),
    ("pbe-spn-kjpaw_psl.0.2.3.UPF",   "PBE/PAW"),
    ("pbe-spn-rrkjus_psl.0.2.3.UPF",  "PBE/USPP"),
]

lock     = Lock()
stats    = {"ok": 0, "skip": 0, "fail": 0, "size": 0}
log_lines = []

def log(msg):
    with lock:
        print(msg, flush=True)
        log_lines.append(msg)

def human_size(b):
    for u in ["B","KB","MB","GB"]:
        if b < 1024: return f"{b:.1f} {u}"
        b /= 1024
    return f"{b:.1f} GB"

def download(url, dest):
    if dest.exists() and dest.stat().st_size > 500:
        with lock: stats["skip"] += 1
        return "skip", dest.stat().st_size, None
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            if r.status != 200:
                return "fail", 0, f"HTTP {r.status}"
            data = r.read()
            if len(data) < 500:
                return "fail", 0, "fichier trop petit"
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
            with lock:
                stats["ok"]   += 1
                stats["size"] += len(data)
            return "ok", len(data), None
    except urllib.error.HTTPError as e:
        return "fail", 0, f"HTTP {e.code}"
    except Exception as e:
        return "fail", 0, str(e)[:50]

def tache(element):
    resultats = []

    # 1. GBRV Ultrasoft PBE (source principale pour terres rares)
    el_low = element.lower()
    for ver in GBRV_VERS:
        nom  = f"{el_low}_pbe_{ver}.uspp.F.UPF"
        dest = PSEUDOS_DIR / "PBE" / "USPP" / f"{element}_GBRV_{ver}.UPF"
        url  = f"{GBRV_BASE}/{nom}"
        st, sz, err = download(url, dest)
        if st in ("ok", "skip"):
            if st == "ok":
                log(f"  ✅ {element} GBRV {ver} USPP PBE           {human_size(sz)}")
            resultats.append((st, element, dest.name, sz))
            break
        # Essayer aussi LDA
    for ver in GBRV_VERS:
        nom  = f"{el_low}_lda_{ver}.uspp.F.UPF"
        dest = PSEUDOS_DIR / "LDA" / "USPP" / f"{element}_GBRV_{ver}_LDA.UPF"
        url  = f"{GBRV_BASE}/{nom}"
        st, sz, err = download(url, dest)
        if st in ("ok", "skip"):
            if st == "ok":
                log(f"  ✅ {element} GBRV {ver} USPP LDA           {human_size(sz)}")
            resultats.append((st, element, dest.name, sz))
            break

    # 2. SG15 ONCVPSP NC PBE
    for variant in [f"{element}_ONCV_PBE-1.2.upf",
                    f"{element}_ONCV_PBE_sr.upf",
                    f"{element}.oncvpsp.upf"]:
        dest = PSEUDOS_DIR / "PBE" / "NC" / variant
        url  = f"{SG15_BASE}/{variant}"
        st, sz, err = download(url, dest)
        if st == "ok":
            log(f"  ✅ {element} SG15 ONCVPSP NC PBE              {human_size(sz)}")
            resultats.append((st, element, variant, sz))
            break
        elif st == "skip":
            resultats.append((st, element, variant, sz))
            break

    # 3. PSLibrary QE (PAW/USPP) — souvent absent pour terres rares
    for suffix, subdir in PSLIB_SUFFIXES:
        nom  = f"{element}.{suffix}"
        dest = PSEUDOS_DIR / subdir / nom
        url  = f"{QE_BASE}/{nom}"
        st, sz, err = download(url, dest)
        if st == "ok":
            log(f"  ✅ {nom:<50} {human_size(sz)}")
            resultats.append((st, element, nom, sz))
        elif st == "skip":
            resultats.append((st, element, nom, sz))

    return resultats

def main():
    print()
    print("═" * 65)
    print("  🌟 Téléchargement — Terres Rares + Actinides")
    print("  Sources : GBRV (Rutgers) + SG15 ONCVPSP + QE Library")
    print("═" * 65)
    print(f"  Lanthanides : {' '.join(TERRES_RARES)}")
    print(f"  Actinides   : {' '.join(ACTINIDES)}")
    print()

    for sub in ["PBE/USPP", "PBE/NC", "PBE/PAW", "LDA/USPP", "LDA/PAW"]:
        (PSEUDOS_DIR / sub).mkdir(parents=True, exist_ok=True)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

    t0 = time.time()
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
        futures = {pool.submit(tache, el): el for el in ELEMENTS_SPECIAUX}
        for future in as_completed(futures):
            _ = future.result()

    elapsed = time.time() - t0
    print()
    print("═" * 65)
    print(f"  ✅ Téléchargés   : {stats['ok']} fichiers")
    print(f"  ⏭️  Déjà présents : {stats['skip']} fichiers")
    print(f"  📦 Taille totale : {human_size(stats['size'])}")
    print(f"  ⏱️  Durée         : {elapsed:.0f}s")
    print()
    print("  Résumé par dossier :")
    for sub in ["PBE/PAW", "PBE/USPP", "PBE/NC", "LDA/USPP"]:
        d = PSEUDOS_DIR / sub
        n = len(list(d.glob("*.UPF")) + list(d.glob("*.upf"))) if d.exists() else 0
        print(f"    {sub:<15} : {n} fichier(s)")
    print()
    total = len(list((PSEUDOS_DIR).rglob("*.UPF")) + list((PSEUDOS_DIR).rglob("*.upf")))
    print(f"  TOTAL pseudos dans /generation_pseudos/pseudos/ : {total}")
    print("═" * 65)
    print()

    LOG_FILE.write_text("\n".join(log_lines))
    print(f"  📄 Log : {LOG_FILE}")
    print()

if __name__ == "__main__":
    main()

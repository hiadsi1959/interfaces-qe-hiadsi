#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Télécharge et installe les bibliothèques de pseudopotentiels manquantes.

Étapes :
  1. Crée l'arborescence standard (ensure_library_tree)
  2. Synchronise PBE/LDA legacy → PSLibrary_* (organize_libraries)
  3. Télécharge les archives connues (SSSP, SG15, GBRV, PseudoDojo…)
  4. Optionnel : PSLibrary fichier par fichier (QE upf_files)

Usage :
  python3 tools/telecharger_bibliotheques_manquantes.py --quick
  python3 tools/telecharger_bibliotheques_manquantes.py --lib SSSP_efficiency
  python3 tools/telecharger_bibliotheques_manquantes.py --dry-run
"""

from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pseudo_libraries as pl  # noqa: E402

PSEUDOS_DIR = Path(
    __import__("os").environ.get("PSEUDOS_DIR", str(ROOT / "pseudos"))
).expanduser().resolve()

MATERIALS_CLOUD = (
    "https://archive.materialscloud.org/api/records/rcyfm-68h65/files"
)
PSEUDODOJO_BASE = "https://www.pseudo-dojo.org/pseudos"
QE_UPF_BASE = "https://pseudopotentials.quantum-espresso.org/upf_files"
THEOS_BASE = "https://theos-wiki.epfl.ch/public/Main/NoBackup"

TIMEOUT = 120
USER_AGENT = "generation_pseudos/1.0 (Mozilla/5.0 compatible)"
PSLIB_WORKERS = 8

# Archives vérifiées (HTTP 200) — lib_id → spec
ARCHIVE_SOURCES: dict[str, dict[str, Any]] = {
    "SG15_NC_PBE": {
        "url": (
            "http://www.quantum-simulation.org/potentials/sg15_oncv/"
            "sg15_oncv_upf_2020-02-06.tar.gz"
        ),
        "quick": True,
        "min_expected": 40,
    },
    "GBRV_USPP_PBE": {
        "url": "https://www.physics.rutgers.edu/gbrv/all_pbe_UPF_v1.5.tar.gz",
        "quick": True,
        "min_expected": 50,
    },
    "SSSP_efficiency": {
        "url": f"{MATERIALS_CLOUD}/SSSP_1.1.2_PBE_efficiency.tar.gz/content",
        "quick": True,
        "min_expected": 50,
    },
    "SSSP_precision": {
        "url": f"{MATERIALS_CLOUD}/SSSP_1.1.2_PBE_precision.tar.gz/content",
        "quick": False,
        "min_expected": 50,
    },
    "SSSP_PBEsol_efficiency": {
        "url": f"{MATERIALS_CLOUD}/SSSP_1.1.2_PBEsol_efficiency.tar.gz/content",
        "quick": False,
        "min_expected": 50,
    },
    "SSSP_PBEsol_precision": {
        "url": f"{MATERIALS_CLOUD}/SSSP_1.1.2_PBEsol_precision.tar.gz/content",
        "quick": False,
        "min_expected": 50,
    },
    "PseudoDojo_standard": {
        "url": f"{PSEUDODOJO_BASE}/nc-sr-04_pbe_standard_upf.tgz",
        "quick": True,
        "min_expected": 50,
    },
    "PseudoDojo_stringent": {
        "url": f"{PSEUDODOJO_BASE}/nc-sr-04_pbe_stringent_upf.tgz",
        "quick": True,
        "min_expected": 50,
    },
    "PseudoDojo_PBEsol_standard": {
        "url": f"{PSEUDODOJO_BASE}/nc-sr-04_pbesol_standard_upf.tgz",
        "quick": False,
        "min_expected": 50,
    },
    "PseudoDojo_PBEsol_stringent": {
        "url": f"{PSEUDODOJO_BASE}/nc-sr-04_pbesol_stringent_upf.tgz",
        "quick": False,
        "min_expected": 50,
    },
    "PseudoDojo_LDA_standard": {
        "url": f"{PSEUDODOJO_BASE}/paw-sr-11_lda_standard_upf.tgz",
        "quick": False,
        "min_expected": 50,
    },
    "PseudoDojo_LDA_stringent": {
        "url": f"{PSEUDODOJO_BASE}/paw-sr-11_lda_stringent_upf.tgz",
        "quick": False,
        "min_expected": 50,
    },
    "PseudoDojo_PSML": {
        "url": f"{PSEUDODOJO_BASE}/nc-sr-04_pbe_standard_psml.tgz",
        "quick": False,
        "min_expected": 50,
        "extract_extensions": (".psml", ".PSML", ".xml", ".XML"),
    },
}

# Archive THEOS PSlibrary 0.3.1 LDA (pz) — alimente les 3 dossiers PSLibrary_*_LDA
THEOS_LDA_ARCHIVE = {
    "url": f"{THEOS_BASE}/pz.0.3.1.tgz",
    "targets": ("PSLibrary_NC_LDA", "PSLibrary_USPP_LDA", "PSLibrary_PAW_LDA"),
    "min_expected": 20,
}
THEOS_PBE_ARCHIVE = {
    "url": f"{THEOS_BASE}/pbe.0.3.1.tgz",
    "target": "THEOS_NC_PBE",
    "min_expected": 50,
}

QUICK_ARCHIVE_LIBS = [k for k, v in ARCHIVE_SOURCES.items() if v.get("quick")]

# PSLibrary : suffixes QE (archives tar.gz souvent 404)
PSLIB_SUFFIXES: dict[str, list[tuple[str, str]]] = {
    "PSLibrary_NC_PBE": [
        ("pbe-n-rrkjus_psl.1.0.0.UPF", "NC"),
        ("pbe-rrkjus_psl.1.0.0.UPF", "NC"),
    ],
    "PSLibrary_NC_LDA": [
        ("lda-n-rrkjus_psl.1.0.0.UPF", "NC"),
        ("lda-rrkjus_psl.1.0.0.UPF", "NC"),
    ],
    "PSLibrary_USPP_PBE": [
        ("pbe-n-rrkjus_psl.1.0.0.UPF", "USPP"),
        ("pbe-rrkjus_psl.1.0.0.UPF", "USPP"),
        ("pbe-spn-rrkjus_psl.1.0.0.UPF", "USPP"),
    ],
    "PSLibrary_USPP_LDA": [
        ("lda-n-rrkjus_psl.1.0.0.UPF", "USPP"),
        ("lda-rrkjus_psl.1.0.0.UPF", "USPP"),
    ],
    "PSLibrary_PAW_PBE": [
        ("pbe-n-kjpaw_psl.1.0.0.UPF", "PAW"),
        ("pbe-spn-kjpaw_psl.1.0.0.UPF", "PAW"),
        ("pbe-dn-kjpaw_psl.1.0.0.UPF", "PAW"),
    ],
    "PSLibrary_PAW_LDA": [
        ("lda-n-kjpaw_psl.1.0.0.UPF", "PAW"),
        ("lda-spn-kjpaw_psl.1.0.0.UPF", "PAW"),
    ],
    "PSLibrary_NC_PBEsol": [
        ("pbesol-n-rrkjus_psl.1.0.0.UPF", "NC"),
        ("pbesol-rrkjus_psl.1.0.0.UPF", "NC"),
    ],
    "PSLibrary_USPP_PBEsol": [
        ("pbesol-n-rrkjus_psl.1.0.0.UPF", "USPP"),
        ("pbesol-rrkjus_psl.1.0.0.UPF", "USPP"),
    ],
    "PSLibrary_PAW_PBEsol": [
        ("pbesol-n-kjpaw_psl.1.0.0.UPF", "PAW"),
        ("pbesol-spn-kjpaw_psl.1.0.0.UPF", "PAW"),
    ],
}

VANDERBILT_GBRV_PAGE = "https://www.physics.rutgers.edu/gbrv/"

FILE_BY_FILE_SOURCES: dict[str, dict[str, Any]] = {
    "HGH_NC_PBE": {
        "kind": "qe_pattern",
        "patterns": ["{el}.pbe-hgh.UPF", "{el}.pbe-sp-hgh.UPF"],
        "min_expected": 20,
    },
    "THEOS_NC_PBE": {
        "kind": "theos_mirror",
        "min_expected": 50,
    },
    "Vanderbilt_USPP_PBE": {
        "kind": "vanderbilt_gbrv_page",
        "min_expected": 50,
    },
}

ELEMENTS = list(pl.SYMBOLS_Z[:98])  # H–Cf (usage courant)


def human_size(num: int) -> str:
    val = float(num)
    for unit in ("B", "KB", "MB", "GB"):
        if val < 1024:
            return f"{val:.1f} {unit}"
        val /= 1024
    return f"{val:.1f} GB"


def count_upf(lib_id: str) -> int:
    return pl.scan_library(PSEUDOS_DIR, lib_id).get("file_count", 0)


def needs_download(lib_id: str, min_upf: int, force: bool) -> bool:
    if force:
        return True
    return count_upf(lib_id) < min_upf


def download_url(url: str, dest: Path, dry_run: bool) -> tuple[bool, int, str | None]:
    if dry_run:
        return True, 0, None
    dest.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            data = resp.read()
    except urllib.error.HTTPError as exc:
        return False, 0, f"HTTP {exc.code}"
    except Exception as exc:  # noqa: BLE001
        return False, 0, str(exc)[:120]
    if len(data) < 1024:
        return False, 0, "réponse trop petite (probable erreur)"
    dest.write_bytes(data)
    return True, len(data), None


def extract_archive_files(
    archive: Path,
    dest_dir: Path,
    dry_run: bool,
    extensions: tuple[str, ...] = (".upf", ".UPF"),
) -> int:
    """Extrait les fichiers ciblés d'une archive vers dest_dir (aplatit)."""
    if dry_run:
        return 0
    dest_dir.mkdir(parents=True, exist_ok=True)
    copied = 0
    name = archive.name.lower()
    ext_set = {e.lower() for e in extensions}

    def _matches(path: Path) -> bool:
        low = path.name.lower()
        return any(low.endswith(ext) for ext in ext_set)

    def _copy_member(src_path: Path) -> None:
        nonlocal copied
        if not src_path.is_file() or not _matches(src_path):
            return
        target = dest_dir / src_path.name
        if target.is_file():
            return
        shutil.copy2(src_path, target)
        copied += 1

    with tempfile.TemporaryDirectory(prefix="gp_extract_") as tmp:
        tmp_path = Path(tmp)
        opened = False
        if tarfile.is_tarfile(archive):
            with tarfile.open(archive, "r:*") as tar:
                try:
                    tar.extractall(tmp_path, filter="data")
                except TypeError:
                    tar.extractall(tmp_path)
            opened = True
        elif name.endswith(".zip") or zipfile.is_zipfile(archive):
            with zipfile.ZipFile(archive) as zf:
                zf.extractall(tmp_path)
            opened = True
        if not opened:
            return 0
        for fp in tmp_path.rglob("*"):
            _copy_member(fp)
    return copied


def install_archive(lib_id: str, spec: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    dest = PSEUDOS_DIR / lib_id
    label = next(
        (x["label"] for x in pl.LIBRARY_CATALOG if x["id"] == lib_id),
        lib_id,
    )
    min_exp = int(spec.get("min_expected", args.min_upf))
    result: dict[str, Any] = {
        "lib_id": lib_id,
        "label": label,
        "status": "skip",
        "before": count_upf(lib_id),
        "after": count_upf(lib_id),
        "copied": 0,
        "bytes": 0,
        "error": None,
    }

    if not needs_download(lib_id, min_exp, args.force):
        result["status"] = "ok_present"
        result["after"] = result["before"]
        print(f"  ⏭️  {lib_id} — déjà {result['before']} UPF (seuil {min_exp})")
        return result

    url = spec["url"]
    print(f"  ⬇️  {lib_id} — {url}")
    if args.dry_run:
        result["status"] = "dry_run"
        print(f"      (dry-run) → {dest}")
        return result

    cache = ROOT / "data" / "download_cache"
    cache.mkdir(parents=True, exist_ok=True)
    if spec.get("cache_name"):
        archive_name = spec["cache_name"]
    elif "/files/" in url and url.rstrip("/").endswith("/content"):
        # Materials Cloud : …/files/SSSP_….tar.gz/content
        archive_name = url.rstrip("/").split("/files/")[-1].split("/")[0]
    else:
        archive_name = url.rstrip("/").split("/")[-1].split("?")[0] or f"{lib_id}.tar.gz"
    archive_path = cache / archive_name

    if not archive_path.is_file() or archive_path.stat().st_size < 1024:
        ok, size, err = download_url(url, archive_path, dry_run=False)
        if not ok:
            result["status"] = "error"
            result["error"] = err
            print(f"      ❌ échec téléchargement : {err}")
            return result
        result["bytes"] = size
        print(f"      📦 {human_size(size)} → {archive_path.name}")
    else:
        result["bytes"] = archive_path.stat().st_size
        print(f"      📦 cache local ({human_size(result['bytes'])})")

    exts = spec.get("extract_extensions", (".upf", ".UPF"))
    copied = extract_archive_files(archive_path, dest, dry_run=False, extensions=exts)
    result["copied"] = copied
    result["after"] = count_upf(lib_id)
    if result["after"] >= min_exp:
        result["status"] = "ok"
        print(f"      ✅ {copied} fichier(s) extraits — inventaire : {result['after']} UPF")
    elif copied > 0:
        result["status"] = "partial"
        print(
            f"      ⚠️  {copied} extrait(s) mais seulement {result['after']} UPF "
            f"(attendu ≥ {min_exp})"
        )
    else:
        result["status"] = "error"
        result["error"] = "aucun UPF extrait"
        print("      ❌ aucun UPF extrait de l'archive")
    return result


def download_pslibrary(lib_id: str, args: argparse.Namespace) -> dict[str, Any]:
    patterns = PSLIB_SUFFIXES.get(lib_id)
    label = lib_id
    result: dict[str, Any] = {
        "lib_id": lib_id,
        "label": label,
        "status": "skip",
        "before": count_upf(lib_id),
        "after": count_upf(lib_id),
        "copied": 0,
        "bytes": 0,
        "error": None,
    }
    if not patterns:
        return result

    if not needs_download(lib_id, args.min_upf, args.force):
        result["status"] = "ok_present"
        result["after"] = result["before"]
        print(f"  ⏭️  {lib_id} — déjà {result['before']} UPF")
        return result

    dest = PSEUDOS_DIR / lib_id
    dest.mkdir(parents=True, exist_ok=True)
    print(f"  ⬇️  {lib_id} — PSLibrary fichier par fichier (QE)")

    if args.dry_run:
        result["status"] = "dry_run"
        return result

    ok_count = 0
    tasks: list[tuple[str, str, str]] = []
    for element in ELEMENTS:
        for suffix, ptype in patterns:
            fname = f"{element}.{suffix}"
            fpath = dest / fname
            if fpath.is_file() and fpath.stat().st_size > 500:
                continue
            if not pl._is_pslibrary_upf(fname, ptype):  # noqa: SLF001
                continue
            tasks.append((fname, str(fpath), f"{QE_UPF_BASE}/{fname}"))

    def _dl(item: tuple[str, str, str]) -> tuple[bool, int]:
        fname, fpath_s, url = item
        got, size, _ = download_url(url, Path(fpath_s), dry_run=False)
        return got and size > 500, size if got else 0

    with ThreadPoolExecutor(max_workers=PSLIB_WORKERS) as pool:
        futures = [pool.submit(_dl, t) for t in tasks]
        for fut in as_completed(futures):
            got, size = fut.result()
            if got:
                ok_count += 1
                result["bytes"] += size

    result["copied"] = ok_count
    result["after"] = count_upf(lib_id)
    result["status"] = "ok" if result["after"] >= args.min_upf else "partial"
    print(f"      ✅ {ok_count} nouveau(x) — inventaire : {result['after']} UPF")
    return result


def _fetch_page_links(url: str, pattern: str) -> list[str]:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        html = resp.read().decode("utf-8", errors="replace")
    return sorted(set(re.findall(pattern, html, flags=re.IGNORECASE)))


def install_theos_lda_pslibrary(args: argparse.Namespace) -> list[dict[str, Any]]:
    """Extrait pz.0.3.1.tgz (THEOS) vers PSLibrary_NC/USPP/PAW_LDA."""
    results: list[dict[str, Any]] = []
    targets = THEOS_LDA_ARCHIVE["targets"]
    min_exp = int(THEOS_LDA_ARCHIVE.get("min_expected", args.min_upf))
    if all(not needs_download(t, min_exp, args.force) for t in targets):
        print("  ⏭️  PSLibrary_*_LDA — déjà remplies (THEOS pz.0.3.1)")
        return results

    print("  ⬇️  PSLibrary_*_LDA — archive THEOS pz.0.3.1.tgz")
    if args.dry_run:
        return results

    cache = ROOT / "data" / "download_cache"
    cache.mkdir(parents=True, exist_ok=True)
    archive_path = cache / "pz.0.3.1.tgz"
    if not archive_path.is_file() or archive_path.stat().st_size < 1_000_000:
        ok, size, err = download_url(THEOS_LDA_ARCHIVE["url"], archive_path, dry_run=False)
        if not ok:
            print(f"      ❌ {err}")
            return results
        print(f"      📦 {human_size(size)}")

    with tempfile.TemporaryDirectory(prefix="gp_pz_") as tmp:
        tmp_path = Path(tmp)
        with tarfile.open(archive_path, "r:*") as tar:
            try:
                tar.extractall(tmp_path, filter="data")
            except TypeError:
                tar.extractall(tmp_path)
        upfs = list(tmp_path.rglob("*.UPF")) + list(tmp_path.rglob("*.upf"))
        counts = {t: 0 for t in targets}
        for fp in upfs:
            name = fp.name
            for lib_id, ptype in (
                ("PSLibrary_NC_LDA", "NC"),
                ("PSLibrary_USPP_LDA", "USPP"),
                ("PSLibrary_PAW_LDA", "PAW"),
            ):
                if not pl._is_pslibrary_upf(name, ptype):  # noqa: SLF001
                    continue
                dest = PSEUDOS_DIR / lib_id / name
                if dest.is_file():
                    continue
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(fp, dest)
                counts[lib_id] += 1
        for lib_id in targets:
            after = count_upf(lib_id)
            print(f"      ✅ {lib_id}: +{counts[lib_id]} → {after} UPF")
            results.append({"lib_id": lib_id, "after": after, "copied": counts[lib_id]})
    return results


def install_theos_pbe_mirror(args: argparse.Namespace) -> dict[str, Any]:
    """Remplit THEOS_NC_PBE depuis l'archive THEOS pbe.0.3.1.tgz."""
    lib_id = THEOS_PBE_ARCHIVE["target"]
    min_exp = int(THEOS_PBE_ARCHIVE.get("min_expected", args.min_upf))
    result: dict[str, Any] = {"lib_id": lib_id, "copied": 0, "after": count_upf(lib_id)}
    if not needs_download(lib_id, min_exp, args.force):
        print(f"  ⏭️  {lib_id} — déjà {result['after']} UPF")
        return result
    print(f"  ⬇️  {lib_id} — archive THEOS pbe.0.3.1.tgz")
    if args.dry_run:
        return result
    dest = PSEUDOS_DIR / lib_id
    dest.mkdir(parents=True, exist_ok=True)
    cache = ROOT / "data" / "download_cache"
    cache.mkdir(parents=True, exist_ok=True)
    archive_path = cache / "pbe.0.3.1.tgz"
    if not archive_path.is_file() or archive_path.stat().st_size < 1_000_000:
        ok, size, err = download_url(THEOS_PBE_ARCHIVE["url"], archive_path, dry_run=False)
        if not ok:
            print(f"      ❌ {err}")
            return result
        print(f"      📦 {human_size(size)}")
    copied = 0
    with tempfile.TemporaryDirectory(prefix="gp_theos_pbe_") as tmp:
        tmp_path = Path(tmp)
        with tarfile.open(archive_path, "r:*") as tar:
            try:
                tar.extractall(tmp_path, filter="data")
            except TypeError:
                tar.extractall(tmp_path)
        for fp in list(tmp_path.rglob("*.UPF")) + list(tmp_path.rglob("*.upf")):
            if not pl._is_theos_upf(fp.name):  # noqa: SLF001
                continue
            target = dest / fp.name
            if target.is_file():
                continue
            shutil.copy2(fp, target)
            copied += 1
    result["copied"] = copied
    result["after"] = count_upf(lib_id)
    print(f"      ✅ {copied} fichier(s) — inventaire : {result['after']} UPF")
    return result


def download_special(lib_id: str, spec: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    min_exp = int(spec.get("min_expected", args.min_upf))
    result: dict[str, Any] = {
        "lib_id": lib_id,
        "status": "skip",
        "before": count_upf(lib_id),
        "after": count_upf(lib_id),
        "copied": 0,
        "bytes": 0,
    }
    if not needs_download(lib_id, min_exp, args.force):
        print(f"  ⏭️  {lib_id} — déjà {result['before']} fichiers")
        result["status"] = "ok_present"
        return result

    dest = PSEUDOS_DIR / lib_id
    dest.mkdir(parents=True, exist_ok=True)
    kind = spec.get("kind")
    print(f"  ⬇️  {lib_id} — source {kind}")

    if args.dry_run:
        result["status"] = "dry_run"
        return result

    ok_count = 0
    if kind == "qe_pattern":
        for element in ELEMENTS:
            for pattern in spec.get("patterns", []):
                fname = pattern.format(el=element)
                fpath = dest / fname
                if fpath.is_file() and fpath.stat().st_size > 500:
                    continue
                url = f"{QE_UPF_BASE}/{fname}"
                got, size, _ = download_url(url, fpath, dry_run=False)
                if got and size > 500:
                    ok_count += 1
                    result["bytes"] += size
    elif kind == "theos_mirror":
        return install_theos_pbe_mirror(args)
    elif kind == "vanderbilt_gbrv_page":
        # Miroir USPP Rutgers (fichiers .uspp.F.UPF sur la page GBRV)
        gbrv_src = PSEUDOS_DIR / "GBRV_USPP_PBE"
        if gbrv_src.is_dir() and any(gbrv_src.glob("*.UPF")):
            for src in gbrv_src.glob("*.UPF"):
                if "uspp" not in src.name.lower():
                    continue
                dst = dest / src.name
                if dst.is_file():
                    continue
                shutil.copy2(src, dst)
                ok_count += 1
        else:
            links = _fetch_page_links(
                VANDERBILT_GBRV_PAGE,
                r'href="([^"]+\.UPF)"',
            )
            for fname in links:
                fpath = dest / fname
                if fpath.is_file() and fpath.stat().st_size > 500:
                    continue
                url = f"{VANDERBILT_GBRV_PAGE.rstrip('/')}/{fname}"
                got, size, _ = download_url(url, fpath, dry_run=False)
                if got and size > 500:
                    ok_count += 1
                    result["bytes"] += size

    result["copied"] = ok_count
    result["after"] = count_upf(lib_id)
    result["status"] = "ok" if result["after"] >= min_exp else "partial"
    print(f"      ✅ {ok_count} fichier(s) — inventaire : {result['after']}")
    return result


def run_lanthanides(args: argparse.Namespace) -> None:
    lib_id = "Lanthanides_NC_PBE"
    if not needs_download(lib_id, 15, args.force):
        print(f"  ⏭️  {lib_id} — déjà {count_upf(lib_id)} UPF")
        return
    script = ROOT / "scripts" / "telecharger_lanthanides_nc.sh"
    if not script.is_file():
        print(f"  ⚠️  Script absent : {script}")
        return
    if args.dry_run:
        print(f"  (dry-run) exécuterait {script}")
        return
    print(f"  ▶ {script.name}")
    env = {**__import__("os").environ, "PSEUDOS_DIR": str(PSEUDOS_DIR)}
    subprocess.run([str(script)], cwd=str(ROOT), env=env, check=False)


def prepare_tree(dry_run: bool) -> None:
    print("▶ Arborescence + synchronisation legacy")
    if dry_run:
        print("  (dry-run) ensure_library_tree + organize_libraries")
        return
    created = pl.ensure_library_tree(PSEUDOS_DIR)
    if created:
        print(f"  Dossiers créés : {', '.join(created)}")
    else:
        print("  Arborescence déjà en place")
    org = pl.organize_libraries(PSEUDOS_DIR, copy_files=True)
    print(f"  Synchronisation : {org['action_count']} opération(s)")


def print_summary(results: list[dict[str, Any]]) -> None:
    print()
    print("═" * 60)
    print("  Inventaire après téléchargement")
    print("═" * 60)
    filled = 0
    for lib in pl.LIBRARY_CATALOG:
        n = count_upf(lib["id"])
        if n > 0:
            filled += 1
        marker = "✅" if n >= 5 else ("⚠️ " if n > 0 else "— ")
        print(f"  {marker} {lib['id']:<28} {n:>4} UPF")
    print(f"\n  Bibliothèques non vides : {filled}/{len(pl.LIBRARY_CATALOG)}")
    print("═" * 60)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Télécharge les bibliothèques de pseudopotentiels manquantes.",
    )
    p.add_argument(
        "--pseudos-dir",
        default=str(PSEUDOS_DIR),
        help=f"Dossier cible (défaut : {PSEUDOS_DIR})",
    )
    p.add_argument(
        "--lib",
        action="append",
        dest="libs",
        metavar="ID",
        help="Bibliothèque précise (répétable). Ex. SSSP_efficiency",
    )
    p.add_argument(
        "--quick",
        action="store_true",
        help="Archives prioritaires seulement (SSSP eff., SG15, GBRV, PseudoDojo PBE)",
    )
    p.add_argument(
        "--all",
        action="store_true",
        help="Tout télécharger : archives + PSLibrary + HGH/THEOS/Vanderbilt",
    )
    p.add_argument(
        "--with-pslibrary",
        action="store_true",
        help="Inclure PSLibrary fichier par fichier (lent)",
    )
    p.add_argument(
        "--min-upf",
        type=int,
        default=5,
        metavar="N",
        help="Seuil minimal pour considérer une bibliothèque remplie (défaut : 5)",
    )
    p.add_argument("--force", action="store_true", help="Retélécharger même si déjà rempli")
    p.add_argument("--dry-run", action="store_true", help="Simuler sans écrire")
    p.add_argument(
        "--skip-lanthanides",
        action="store_true",
        help="Ne pas lancer telecharger_lanthanides_nc.sh",
    )
    return p


def main() -> int:
    global PSEUDOS_DIR  # noqa: PLW0603

    args = build_parser().parse_args()
    PSEUDOS_DIR = Path(args.pseudos_dir).expanduser().resolve()

    print()
    print("═" * 60)
    print("  Téléchargement des bibliothèques de pseudopotentiels")
    print("═" * 60)
    print(f"  Cible : {PSEUDOS_DIR}")
    print(f"  Mode  : {'dry-run' if args.dry_run else 'écriture'}")
    if args.all:
        print("  Jeux  : complet (26 bibliothèques)")
    elif args.quick:
        print("  Jeux  : rapides (archives prioritaires)")
    print()

    t0 = time.time()
    prepare_tree(args.dry_run)

    do_all = args.all
    do_pslib = (
        args.with_pslibrary
        or do_all
        or bool(args.libs and any(l in PSLIB_SUFFIXES for l in args.libs))
    )

    # Sélection des archives
    if args.libs:
        archive_ids = [lid for lid in args.libs if lid in ARCHIVE_SOURCES]
        for lid in args.libs:
            if lid not in ARCHIVE_SOURCES and lid not in PSLIB_SUFFIXES:
                if lid not in FILE_BY_FILE_SOURCES and lid != "Lanthanides_NC_PBE":
                    print(f"  ⚠️  ID inconnu : {lid}")
    elif args.quick:
        archive_ids = list(QUICK_ARCHIVE_LIBS)
    else:
        archive_ids = list(ARCHIVE_SOURCES.keys())

    print()
    print(f"▶ Archives ({len(archive_ids)} jeu(x))")
    results: list[dict[str, Any]] = []
    for lib_id in archive_ids:
        results.append(install_archive(lib_id, ARCHIVE_SOURCES[lib_id], args))

    if do_pslib and not args.quick:
        print()
        print("▶ PSLibrary (fichier par fichier — QE)")
        for lib_id in PSLIB_SUFFIXES:
            if args.libs and lib_id not in args.libs:
                continue
            if lib_id.endswith("_LDA"):
                continue
            results.append(download_pslibrary(lib_id, args))
        if do_all or (args.libs and any(l.endswith("_LDA") for l in (args.libs or []))):
            print()
            print("▶ PSLibrary LDA (archive THEOS pz.0.3.1)")
            results.extend(install_theos_lda_pslibrary(args))

    if do_all or (args.libs and any(l in FILE_BY_FILE_SOURCES for l in (args.libs or []))):
        print()
        print("▶ Sources spécialisées (HGH, THEOS, Vanderbilt)")
        special_ids = list(FILE_BY_FILE_SOURCES.keys())
        if args.libs:
            special_ids = [lid for lid in special_ids if lid in args.libs]
        for lib_id in special_ids:
            results.append(download_special(lib_id, FILE_BY_FILE_SOURCES[lib_id], args))

    if not args.skip_lanthanides and (do_all or not args.libs or "Lanthanides_NC_PBE" in (args.libs or [])):
        print()
        print("▶ Lanthanides NC PBE")
        run_lanthanides(args)

    if not args.dry_run:
        print()
        print("▶ Re-synchronisation finale")
        org = pl.organize_libraries(PSEUDOS_DIR, copy_files=True)
        print(f"  {org['action_count']} opération(s)")

    print_summary(results)
    elapsed = time.time() - t0
    print(f"\n  Durée : {elapsed:.0f}s")
    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

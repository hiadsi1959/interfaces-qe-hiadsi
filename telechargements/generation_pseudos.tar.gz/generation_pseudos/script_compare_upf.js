/**
 * Comparaison de deux UPF — POST /api/pseudos/compare_upf
 */
(function () {
    'use strict';

    function apiBase() {
        if (typeof window.getApiPseudosBase === 'function') {
            try { return String(window.getApiPseudosBase()).replace(/\/$/, ''); } catch (e) { /* ignore */ }
        }
        return String(window.API_PSEUDOS_ORIGIN || 'http://127.0.0.1:5008').replace(/\/$/, '');
    }

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function injectCss() {
        if (document.getElementById('gp-cmp-css')) return;
        var st = document.createElement('style');
        st.id = 'gp-cmp-css';
        st.textContent =
            '#gp_cmp_overlay{position:fixed;inset:0;background:rgba(15,23,42,.88);z-index:100060;display:flex;align-items:center;justify-content:center;padding:16px;}' +
            '#gp_cmp_box{background:#0f172a;color:#e2e8f0;width:min(760px,96vw);max-height:88vh;overflow:auto;border-radius:12px;border:1px solid #334155;padding:18px 20px;font-family:system-ui,sans-serif;}' +
            '#gp_cmp_box h2{margin:0 0 12px;color:#7dd3fc;font-size:1.15rem;}' +
            '#gp_cmp_box label{display:block;font-size:0.8rem;color:#94a3b8;margin:8px 0 4px;}' +
            '#gp_cmp_box input{width:100%;box-sizing:border-box;padding:8px 10px;border-radius:8px;border:1px solid #475569;background:#1e293b;color:#f8fafc;font-size:0.85rem;}' +
            '#gp_cmp_actions{display:flex;gap:8px;margin-top:14px;flex-wrap:wrap;}' +
            '#gp_cmp_actions button{padding:8px 14px;border-radius:8px;border:none;cursor:pointer;font-weight:600;}' +
            '.gp-cmp-primary{background:#0e7490;color:#fff;}' +
            '.gp-cmp-ghost{background:#334155;color:#e2e8f0;}' +
            '#gp_cmp_table{width:100%;border-collapse:collapse;font-size:0.84rem;margin-top:14px;}' +
            '#gp_cmp_table th,#gp_cmp_table td{padding:7px 8px;border-bottom:1px solid #334155;text-align:left;}' +
            '#gp_cmp_table th{color:#94a3b8;}' +
            '.gp-cmp-diff{background:rgba(185,28,28,0.18);}' +
            '.gp-cmp-ok{color:#86efac;}' +
            '.gp-cmp-bad{color:#fca5a5;}' +
            '#gp_cmp_box .hide{display:none!important;}';
        document.head.appendChild(st);
    }

    function row(label, a, b) {
        var same = String(a) === String(b);
        return '<tr class="' + (same ? '' : 'gp-cmp-diff') + '"><th>' + esc(label) + '</th><td>' +
            esc(a == null ? '—' : a) + '</td><td>' + esc(b == null ? '—' : b) + '</td></tr>';
    }

    window.openUpfCompare = function (pathA, pathB) {
        injectCss();
        var old = document.getElementById('gp_cmp_overlay');
        if (old) old.remove();
        var o = document.createElement('div');
        o.id = 'gp_cmp_overlay';
        o.innerHTML =
            '<div id="gp_cmp_box">' +
            '<h2>Comparer deux UPF</h2>' +
            '<p style="color:#94a3b8;font-size:0.85rem;margin:0 0 8px;">Chemins complets ou noms dans la bibliothèque <code>pseudos/</code>.</p>' +
            '<label>UPF A</label><input type="text" id="gp_cmp_a" placeholder="/chemin/Si.UPF" />' +
            '<label>UPF B</label><input type="text" id="gp_cmp_b" placeholder="/chemin/Si_autre.UPF" />' +
            '<div id="gp_cmp_actions">' +
            '<button type="button" class="gp-cmp-primary" id="gp_cmp_go">Comparer</button>' +
            '<button type="button" class="gp-cmp-ghost" id="gp_cmp_close">Fermer</button>' +
            '</div>' +
            '<div id="gp_cmp_status" style="margin-top:10px;color:#94a3b8;font-size:0.85rem;"></div>' +
            '<table id="gp_cmp_table" class="hide"><thead><tr><th>Champ</th><th>A</th><th>B</th></tr></thead>' +
            '<tbody id="gp_cmp_tbody"></tbody></table>' +
            '</div>';
        document.body.appendChild(o);
        if (pathA) document.getElementById('gp_cmp_a').value = pathA;
        if (pathB) document.getElementById('gp_cmp_b').value = pathB;

        document.getElementById('gp_cmp_close').onclick = function () { o.remove(); };
        o.addEventListener('click', function (ev) { if (ev.target === o) o.remove(); });

        document.getElementById('gp_cmp_go').onclick = async function () {
            var a = (document.getElementById('gp_cmp_a').value || '').trim();
            var b = (document.getElementById('gp_cmp_b').value || '').trim();
            var st = document.getElementById('gp_cmp_status');
            var tb = document.getElementById('gp_cmp_tbody');
            var table = document.getElementById('gp_cmp_table');
            if (!a || !b) { st.textContent = 'Indiquez les deux chemins.'; return; }
            st.textContent = 'Comparaison…';
            try {
                var r = await fetch(apiBase() + '/api/pseudos/compare_upf', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ path_a: a, path_b: b })
                });
                var j = await r.json();
                if (!r.ok || !j.success) throw new Error(j.error || ('HTTP ' + r.status));
                table.classList.remove('hide');
                var A = j.a || {}, B = j.b || {};
                tb.innerHTML =
                    row('Nom', A.name, B.name) +
                    row('Élément', A.element, B.element) +
                    row('Format', A.format, B.format) +
                    row('Conforme QE', A.conform_qe, B.conform_qe) +
                    row('z_valence', A.z_valence, B.z_valence) +
                    row('Type', A.pseudo_type, B.pseudo_type) +
                    row('Fonctionnelle', A.functional, B.functional) +
                    row('Taille (octets)', A.size_bytes, B.size_bytes) +
                    row('Chemin', A.path, B.path);
                st.innerHTML = j.identical_meta
                    ? '<span class="gp-cmp-ok">Métadonnées identiques (' + (j.diffs || []).length + ' diff.)</span>'
                    : '<span class="gp-cmp-bad">' + (j.diffs || []).length + ' différence(s) de métadonnées</span>';
            } catch (err) {
                st.textContent = 'Erreur : ' + (err.message || err);
                table.classList.add('hide');
            }
        };
    };
})();

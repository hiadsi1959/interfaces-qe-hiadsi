/**
 * Configuration des chemins — interface autonome generation_pseudos (port 5008).
 * Source de vérité : API /api/chemins (+ api_config.json côté serveur).
 * localStorage ne sert qu’à mémoriser l’URL API / port, pas des chemins /home/hiadsi.
 */
(function () {
    'use strict';

    var STORAGE_KEY = 'qe_unified_paths_v1';
    /** Incrémenter pour invalider les anciens profils « hiadsi » / Interface-QE */
    var SCHEMA_VERSION = 4;

    function resolvePseudosApiOrigin() {
        try {
            var loc = window.location;
            if (loc.protocol === 'http:' || loc.protocol === 'https:') {
                var port = String(loc.port || '');
                if (port === '5008' || port === '5009') {
                    return loc.origin.replace(/\/$/, '');
                }
            }
        } catch (e) { /* ignore */ }
        return 'http://127.0.0.1:5008';
    }

    var PRESET_STANDALONE = {
        profile: 'standalone',
        PROJECT_MAIN: '',
        PROJECT_INPUTS_APP: '',
        PROJECT_PSEUDOS_UI: '',
        QE_BIN_DIR: '',
        QE_API_PORT: 5008,
        API_PSEUDOS_ORIGIN: 'http://127.0.0.1:5008',
        schemaVersion: SCHEMA_VERSION
    };

    function trimSlash(p) {
        return String(p || '').replace(/\/+$/, '');
    }

    function deriveFull(cfg) {
        var main = trimSlash(cfg.PROJECT_MAIN);
        var inApp = trimSlash(cfg.PROJECT_INPUTS_APP);
        var qeBin = trimSlash(cfg.QE_BIN_DIR);
        var out = {
            WORK_DIR: main,
            PROJECT_MAIN: main,
            INPUTS_DIR: main ? main + '/inputs' : '',
            OUTPUTS_DIR: main ? main + '/outputs' : '',
            PSEUDO_DIR: main ? main + '/pseudos' : '',
            CIF_DIR: main ? main + '/fichiers_cif' : '',
            TMP_DIR: main ? main + '/tmp' : '',
            INPUTS_GENERES_DIR: inApp ? inApp + '/inputs_générés' : '',
            PSEUDO_GENERES_DIR: main ? main + '/pseudos-ld1' : '',
            LD1_INPUTS_DIR: main ? main + '/pseudos-ld1' : '',
            QE_BIN_DIR: qeBin,
            PROJECT_INPUTS_APP: inApp,
            PROJECT_PSEUDOS_UI: trimSlash(cfg.PROJECT_PSEUDOS_UI),
            AUTO_REFRESH_INTERVAL: 3000,
            AUTO_START_API: true
        };
        return out;
    }

    function syncInputsLocalStorage(full) {
        try {
            localStorage.setItem('qe_inputs_config', JSON.stringify({
                INPUTS_GENERES_DIR: full.INPUTS_GENERES_DIR,
                INPUTS_DIR: full.INPUTS_DIR,
                OUTPUTS_DIR: full.OUTPUTS_DIR,
                PSEUDO_DIR: full.PSEUDO_DIR,
                CIF_DIR: full.CIF_DIR,
                QE_BIN_DIR: full.QE_BIN_DIR,
                WORK_DIR: full.WORK_DIR
            }));
        } catch (e) {
            console.warn('qe_paths_setup: synchro qe_inputs_config impossible', e);
        }
    }

    window.applyUnifiedQEPaths = function (raw, opt) {
        opt = opt || {};
        var merged = Object.assign({}, PRESET_STANDALONE, raw || {});
        if (merged.profile === 'hiadsi') {
            merged = Object.assign({}, PRESET_STANDALONE);
        }
        merged.schemaVersion = SCHEMA_VERSION;
        merged.QE_API_PORT = 5008;
        if (!merged.API_PSEUDOS_ORIGIN) {
            merged.API_PSEUDOS_ORIGIN = resolvePseudosApiOrigin();
        }
        var full = deriveFull(merged);
        window.QE_CONFIG = full;
        window.QE_API_PORT = 5008;
        window.QE_API_URL = 'http://127.0.0.1:5008';
        window.API_PSEUDOS_ORIGIN = trimSlash(merged.API_PSEUDOS_ORIGIN) || resolvePseudosApiOrigin();
        window.GENERATION_PSEUDOS_API_ORIGIN = window.API_PSEUDOS_ORIGIN;
        if (!opt.skipStorage) {
            try {
                localStorage.setItem(STORAGE_KEY, JSON.stringify({
                    profile: 'standalone',
                    QE_BIN_DIR: merged.QE_BIN_DIR || '',
                    QE_API_PORT: 5008,
                    API_PSEUDOS_ORIGIN: window.API_PSEUDOS_ORIGIN,
                    schemaVersion: SCHEMA_VERSION
                }));
            } catch (e) {
                console.warn('qe_paths_setup: sauvegarde impossible', e);
            }
            syncInputsLocalStorage(full);
        }
        window.__QE_PATHS_READY__ = true;
        window.dispatchEvent(new CustomEvent('qe-paths-ready', { detail: full }));
        console.log('✅ Chemins QE (standalone 5008):', full.QE_BIN_DIR || '(via API)', '| pseudos:', full.PSEUDO_DIR || '(via API)');
    };

    window.loadUnifiedQEPathsFromStorage = function () {
        try {
            var s = localStorage.getItem(STORAGE_KEY);
            if (!s) return null;
            return JSON.parse(s);
        } catch (e) {
            return null;
        }
    };

    function qeEscapeHtml(s) {
        return String(s || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    function hideMismatchBanner() {
        var b = document.getElementById('qe_paths_mismatch_banner');
        if (b) b.remove();
    }

    function showMismatchBanner(srv, loc) {
        injectModalStyles();
        hideMismatchBanner();
        var b = document.createElement('div');
        b.id = 'qe_paths_mismatch_banner';
        b.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:99999;background:#d97706;color:#1f2937;padding:10px 16px;font-size:0.88rem;display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;font-family:system-ui,sans-serif;';
        b.innerHTML =
            '<span><strong>Chemins navigateur ≠ API</strong> — navigateur : <code style="background:rgba(255,255,255,.45);padding:2px 6px;border-radius:4px;">' +
            qeEscapeHtml(loc) +
            '</code> · API : <code style="background:rgba(255,255,255,.45);padding:2px 6px;border-radius:4px;">' +
            qeEscapeHtml(srv) +
            '</code></span>' +
            '<button type="button" id="qe_paths_banner_cfg" style="padding:6px 14px;border-radius:8px;border:none;background:#1e293b;color:#fff;font-weight:600;cursor:pointer;">Configurer</button>' +
            '<button type="button" id="qe_paths_banner_x" style="padding:6px 10px;border-radius:8px;border:1px solid #1e293b;background:transparent;cursor:pointer;">Fermer</button>';
        if (document.body) {
            document.body.insertBefore(b, document.body.firstChild);
            var cfg = document.getElementById('qe_paths_banner_cfg');
            if (cfg) cfg.onclick = function () { openQEPathsWizard(true); };
            var x = document.getElementById('qe_paths_banner_x');
            if (x) x.onclick = function () { b.remove(); };
        }
    }

    function loadCheminsFromStandaloneApi() {
        var base = trimSlash(window.API_PSEUDOS_ORIGIN) || 'http://127.0.0.1:5008';
        return fetch(base + '/api/chemins', { cache: 'no-store' })
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (data) {
                if (!data) return null;
                window.QE_CONFIG = window.QE_CONFIG || {};
                if (data.qe_bin) window.QE_CONFIG.QE_BIN_DIR = trimSlash(data.qe_bin);
                if (data.pseudos) window.QE_CONFIG.PSEUDO_DIR = trimSlash(data.pseudos);
                if (data.inputs) window.QE_CONFIG.INPUTS_DIR = trimSlash(data.inputs);
                if (data.outputs) window.QE_CONFIG.OUTPUTS_DIR = trimSlash(data.outputs);
                if (data.work_dir || data.projet) {
                    window.QE_CONFIG.WORK_DIR = trimSlash(data.work_dir || data.projet);
                    window.QE_CONFIG.PROJECT_MAIN = window.QE_CONFIG.WORK_DIR;
                }
                window.GENERATION_PSEUDOS_API_ORIGIN = base;
                var el = document.getElementById('pseudos_path_display');
                if (el && data.pseudos) el.textContent = data.pseudos;
                console.log('✅ Chemins API:', data.qe_bin || '(QE à configurer)', data.pseudos || '');
                return data;
            })
            .catch(function () { return null; });
    }

    function verifyStandaloneApi() {
        var base = trimSlash(window.API_PSEUDOS_ORIGIN) || 'http://127.0.0.1:5008';
        fetch(base + '/health', { method: 'GET', cache: 'no-store' })
            .then(function (r) {
                if (!r.ok) throw new Error('health');
                return loadCheminsFromStandaloneApi();
            })
            .then(function () { hideMismatchBanner(); })
            .catch(function () {
                if (window.location.protocol === 'file:') return;
                console.warn('API (5008) non joignable — ./DEMARRER.sh ou ./configure.sh puis ./DEMARRER.sh');
            });
    }

    function verifyServerPaths() {
        verifyStandaloneApi();
    }

    window.verifierCheminsAvecAPI = verifyServerPaths;

    function injectModalStyles() {
        if (document.getElementById('qe-paths-setup-css')) return;
        var st = document.createElement('style');
        st.id = 'qe-paths-setup-css';
        st.textContent =
            '#qe_paths_modal_overlay{position:fixed;inset:0;background:rgba(15,23,42,.92);z-index:100000;display:flex;align-items:center;justify-content:center;padding:16px;font-family:system-ui,Segoe UI,sans-serif;}' +
            '#qe_paths_modal_box{background:#1e293b;color:#e2e8f0;max-width:520px;width:100%;border-radius:14px;padding:22px 24px;border:1px solid #334155;}' +
            '#qe_paths_modal_box h2{margin:0 0 10px 0;font-size:1.15rem;color:#93c5fd;}' +
            '#qe_paths_modal_box p{font-size:0.9rem;line-height:1.5;color:#94a3b8;margin:8px 0 14px 0;}' +
            '#qe_paths_modal_box label{display:block;font-size:0.82rem;color:#cbd5e1;margin-bottom:4px;}' +
            '#qe_paths_modal_box input[type=text]{width:100%;box-sizing:border-box;padding:8px 10px;border-radius:8px;border:1px solid #475569;background:#0f172a;color:#f8fafc;margin-bottom:12px;font-size:0.88rem;}' +
            '#qe_paths_modal_actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px;}' +
            '#qe_paths_modal_actions button{padding:9px 16px;border-radius:8px;border:none;cursor:pointer;font-weight:600;font-size:0.9rem;}' +
            '.qe_btn_primary{background:#0e7490;color:#fff;}' +
            '.qe_btn_ghost{background:#334155;color:#e2e8f0;}';
        document.head.appendChild(st);
    }

    function openQEPathsWizard(force) {
        injectModalStyles();
        var existing = document.getElementById('qe_paths_modal_overlay');
        if (existing) existing.remove();

        var stored = window.loadUnifiedQEPathsFromStorage() || {};
        var o = document.createElement('div');
        o.id = 'qe_paths_modal_overlay';
        o.innerHTML =
            '<div id="qe_paths_modal_box">' +
            '<h2>Chemins sur ce PC</h2>' +
            '<p>Les chemins effectifs viennent de <code>api_config.json</code> (script <code>./configure.sh</code>). ' +
            'Ici vous pouvez forcer le dossier <code>bin/</code> QE vu par le navigateur, ou laisser l’API les détecter.</p>' +
            '<label>Répertoire <code>bin</code> Quantum ESPRESSO (pw.x, ld1.x) — optionnel</label>' +
            '<input type="text" id="qe_in_qebin" placeholder="~/q-e-qe-7.5/bin ou laisser vide (détection API)" />' +
            '<label>URL API (port 5008)</label>' +
            '<input type="text" id="qe_in_pseudosapi" value="http://127.0.0.1:5008" />' +
            '<p style="font-size:0.82rem;">Sur un nouveau PC : <code>./configure.sh</code> puis <code>./DEMARRER.sh</code>.</p>' +
            '<div id="qe_paths_modal_actions">' +
            '<button type="button" class="qe_btn_primary" id="qe_paths_ok">Enregistrer</button>' +
            '<button type="button" class="qe_btn_ghost" id="qe_paths_reload">Recharger depuis l’API</button>' +
            (force ? '<button type="button" class="qe_btn_ghost" id="qe_paths_cancel">Annuler</button>' : '') +
            '</div></div>';
        document.body.appendChild(o);

        var qb = o.querySelector('#qe_in_qebin');
        if (qb) qb.value = (window.QE_CONFIG && window.QE_CONFIG.QE_BIN_DIR) || stored.QE_BIN_DIR || '';
        var ps = o.querySelector('#qe_in_pseudosapi');
        if (ps) ps.value = stored.API_PSEUDOS_ORIGIN || window.API_PSEUDOS_ORIGIN || 'http://127.0.0.1:5008';

        o.querySelector('#qe_paths_ok').onclick = function () {
            var qeb = (o.querySelector('#qe_in_qebin') || {}).value || '';
            var papi = (o.querySelector('#qe_in_pseudosapi') || {}).value || 'http://127.0.0.1:5008';
            window.applyUnifiedQEPaths({
                profile: 'standalone',
                QE_BIN_DIR: trimSlash(qeb),
                QE_API_PORT: 5008,
                API_PSEUDOS_ORIGIN: trimSlash(papi),
                schemaVersion: SCHEMA_VERSION
            });
            hideMismatchBanner();
            setTimeout(verifyServerPaths, 300);
            o.remove();
        };
        o.querySelector('#qe_paths_reload').onclick = function () {
            loadCheminsFromStandaloneApi().then(function (data) {
                if (data) {
                    alert('Chemins API rechargés.\nQE : ' + (data.qe_bin || '(non détecté)') +
                        '\nPseudos : ' + (data.pseudos || ''));
                } else {
                    alert('API non joignable — lancez ./DEMARRER.sh');
                }
            });
        };
        var cxl = o.querySelector('#qe_paths_cancel');
        if (cxl) cxl.onclick = function () { o.remove(); };
    }

    window.openQEPathsWizard = function (force) {
        openQEPathsWizard(!!force);
    };
    window.openStandaloneConfigWizard = window.openQEPathsWizard;

    // Bootstrap : toujours standalone 5008 ; invalider anciens profils hiadsi
    var saved = window.loadUnifiedQEPathsFromStorage();
    if (saved && (saved.profile === 'hiadsi' || Number(saved.schemaVersion || 0) < SCHEMA_VERSION)) {
        try { localStorage.removeItem(STORAGE_KEY); } catch (e) { /* ignore */ }
        saved = null;
    }
    if (saved && saved.profile === 'standalone') {
        window.applyUnifiedQEPaths(Object.assign({}, PRESET_STANDALONE, saved), { skipStorage: true });
    } else {
        window.applyUnifiedQEPaths(PRESET_STANDALONE, { skipStorage: true });
    }
    window.API_PSEUDOS_ORIGIN = resolvePseudosApiOrigin();
    window.GENERATION_PSEUDOS_API_ORIGIN = window.API_PSEUDOS_ORIGIN;
    setTimeout(verifyServerPaths, 400);
})();

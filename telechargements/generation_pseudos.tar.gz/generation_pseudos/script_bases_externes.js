/**
 * Onglet « Autres bases » — hub PSLibrary / PseudoDojo / SSSP (+ GBRV, SG15…)
 * Utilise /api/pseudos/libraries/catalog et /api/pseudos/libraries/search
 */
(function () {
    'use strict';

    var FAMILY_META = {
        pslibrary: {
            title: 'PSLibrary',
            subtitle: 'Dal Corso — bibliothèque officielle Quantum ESPRESSO',
            icon: '📚',
            color: '#1d4ed8',
            bg: 'linear-gradient(135deg,#eff6ff 0%,#dbeafe 100%)',
            border: '#93c5fd',
            site: 'https://pseudopotentials.quantum-espresso.org',
            siteLabel: 'Portail QE',
            types: ['NC', 'USPP', 'PAW'],
            xc: ['PBE', 'LDA', 'PBEsol'],
        },
        pseudodojo: {
            title: 'PseudoDojo',
            subtitle: 'ONCVPSP — jeux standard & stringent, validation automatisée',
            icon: '🌐',
            color: '#047857',
            bg: 'linear-gradient(135deg,#ecfdf5 0%,#d1fae5 100%)',
            border: '#6ee7b7',
            site: 'https://www.pseudo-dojo.org/',
            siteLabel: 'pseudo-dojo.org',
            types: ['NC'],
            xc: ['PBE', 'PBEsol', 'LDA'],
        },
        sssp: {
            title: 'SSSP',
            subtitle: 'Materials Cloud — sélection curatée Efficiency / Precision',
            icon: '📊',
            color: '#c2410c',
            bg: 'linear-gradient(135deg,#fff7ed 0%,#ffedd5 100%)',
            border: '#fdba74',
            site: 'https://www.materialscloud.org/discover/sssp/table',
            siteLabel: 'Table SSSP',
            types: ['NC', 'USPP', 'PAW'],
            xc: ['PBE'],
        },
        gbrv: {
            title: 'GBRV',
            subtitle: 'USPP Vanderbilt — Rutgers (oxydes, TM)',
            icon: '⚗️',
            color: '#166534',
            bg: 'linear-gradient(135deg,#f0fdf4 0%,#dcfce7 100%)',
            border: '#86efac',
            site: 'https://www.physics.rutgers.edu/gbrv/',
            siteLabel: 'GBRV Library',
            types: ['USPP'],
            xc: ['PBE'],
        },
        sg15: {
            title: 'SG15',
            subtitle: 'Schlipf-Gygi — ONCVPSP NC optimisés',
            icon: '🔬',
            color: '#92400e',
            bg: 'linear-gradient(135deg,#fffbeb 0%,#fef3c7 100%)',
            border: '#fcd34d',
            site: 'http://www.quantum-simulation.org/potentials/sg15_oncv/',
            siteLabel: 'SG15 ONCV',
            types: ['NC'],
            xc: ['PBE'],
        },
    };

    function esc(s) {
        if (s == null) return '';
        return String(s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function apiBase() {
        return typeof getApiPseudosBase === 'function' ? getApiPseudosBase() : 'http://127.0.0.1:5008';
    }

    window._fetchLibrariesCatalog = async function () {
        try {
            var r = await fetch(apiBase() + '/api/pseudos/libraries/catalog', { cache: 'no-store' });
            var j = await r.json();
            if (!r.ok || !j.success) return { ok: false, error: j.error || 'Catalogue indisponible' };
            return { ok: true, data: j };
        } catch (e) {
            return { ok: false, error: (e && e.message) || 'Réseau' };
        }
    };

    window._fetchLibrariesSearch = async function (symbole, opts) {
        opts = opts || {};
        var q = 'element=' + encodeURIComponent(symbole || '');
        if (opts.family) q += '&family=' + encodeURIComponent(opts.family);
        if (opts.library) q += '&library=' + encodeURIComponent(opts.library);
        try {
            var r = await fetch(apiBase() + '/api/pseudos/libraries/search?' + q, { cache: 'no-store' });
            var j = await r.json();
            if (!r.ok || !j.success) return { ok: false, error: j.error || 'Recherche échouée' };
            return { ok: true, data: j };
        } catch (e) {
            return { ok: false, error: (e && e.message) || 'Réseau' };
        }
    };

    function typeBadge(t) {
        var colors = { NC: '#3b82f6', USPP: '#10b981', PAW: '#f59e0b', mixed: '#8b5cf6' };
        var c = colors[t] || '#64748b';
        return '<span style="display:inline-block;padding:2px 8px;border-radius:6px;font-size:0.68em;font-weight:700;background:'
            + c + '22;color:' + c + ';border:1px solid ' + c + '55;">' + esc(t || '?') + '</span>';
    }

    function familyHero(fam) {
        var m = FAMILY_META[fam] || { title: fam, subtitle: '', icon: '📦', color: '#475569', bg: '#f8fafc', border: '#cbd5e1' };
        return ''
            + '<div class="lib-family-hero" data-family="' + esc(fam) + '" style="background:' + m.bg + ';border:2px solid ' + m.border
            + ';border-radius:14px;padding:16px 18px;margin-bottom:14px;">'
            + '<div style="display:flex;align-items:flex-start;gap:14px;flex-wrap:wrap;">'
            + '<span style="font-size:2.2em;line-height:1;">' + m.icon + '</span>'
            + '<div style="flex:1;min-width:200px;">'
            + '<h3 style="margin:0 0 4px 0;color:' + m.color + ';font-size:1.05em;">' + esc(m.title) + '</h3>'
            + '<p style="margin:0;font-size:0.82em;color:#475569;line-height:1.5;">' + esc(m.subtitle) + '</p>'
            + '<div style="margin-top:8px;display:flex;flex-wrap:wrap;gap:6px;">'
            + (m.types || []).map(typeBadge).join('')
            + '</div></div>'
            + (m.site ? '<a href="' + esc(m.site) + '" target="_blank" rel="noopener" class="portal-btn prim" style="align-self:center;">'
            + esc(m.siteLabel || 'Site officiel') + ' ↗</a>' : '')
            + '</div></div>';
    }

    function libCard(lib, symbole, pseudosRoot) {
        var n = lib.file_count || 0;
        var installed = lib.dirs_present !== false && (lib.dirs_present || n > 0);
        var statusColor = n > 0 ? '#059669' : (installed ? '#d97706' : '#94a3b8');
        var statusLabel = n > 0 ? (n + ' UPF' + (symbole ? ' pour ' + symbole : '')) : (installed ? 'Dossier vide' : 'Non installé');
        var files = lib.files || [];
        var filesHtml = '';
        if (files.length > 0) {
            filesHtml = '<div style="margin-top:10px;border-top:1px dashed #e2e8f0;padding-top:8px;">'
                + files.slice(0, 6).map(function (f) {
                    var name = f.name || f;
                    var path = f.path || (pseudosRoot + '/' + lib.id + '/' + name);
                    return '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-top:6px;">'
                        + '<code style="font-size:0.72em;word-break:break-all;flex:1;color:#334155;">' + esc(name) + '</code>'
                        + '<button type="button" class="btn-mini btn-blue" onclick="if(typeof utiliserPseudo===\'function\')utiliserPseudo(\''
                        + esc(symbole) + '\',\'' + esc(lib.id) + '\',\'' + esc(name).replace(/'/g, "\\'") + '\')">Utiliser</button>'
                        + '</div>';
                }).join('')
                + (files.length > 6 ? '<div style="font-size:0.72em;color:#94a3b8;margin-top:6px;">+' + (files.length - 6) + ' autres…</div>' : '')
                + '</div>';
        }
        return ''
            + '<article class="lib-catalog-card" style="border:1px solid #e2e8f0;border-radius:12px;padding:14px;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,0.04);">'
            + '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">'
            + '<div><div style="font-weight:700;font-size:0.88em;color:#1e293b;">' + esc(lib.label || lib.id) + '</div>'
            + '<div style="margin-top:6px;display:flex;flex-wrap:wrap;gap:5px;">'
            + typeBadge(lib.type) + '<span style="font-size:0.7em;color:#64748b;padding:2px 6px;">' + esc(lib.functional || '') + '</span>'
            + (lib.ecut_hint_ry ? '<span style="font-size:0.68em;color:#94a3b8;">ecut ~' + esc(lib.ecut_hint_ry) + ' Ry</span>' : '')
            + '</div></div>'
            + '<span style="font-size:0.72em;font-weight:700;color:' + statusColor + ';white-space:nowrap;">● ' + esc(statusLabel) + '</span>'
            + '</div>'
            + '<code style="display:block;margin-top:8px;font-size:0.7em;color:#64748b;word-break:break-all;">' + esc(pseudosRoot + '/' + lib.id + '/') + '</code>'
            + filesHtml
            + '<div style="margin-top:10px;display:flex;flex-wrap:wrap;gap:6px;">'
            + (lib.download_url ? '<a href="' + esc(lib.download_url) + '" target="_blank" rel="noopener" class="btn-mini btn-blue" style="text-decoration:none;">Télécharger</a>' : '')
            + '<button type="button" class="btn-mini btn-gray" onclick="if(typeof copyPseudosPathLine===\'function\')copyPseudosPathLine('
            + JSON.stringify((pseudosRoot || '') + '/' + lib.id + '/') + ')">Copier chemin</button>'
            + '</div>'
            + (lib.install_note ? '<p style="margin:8px 0 0 0;font-size:0.72em;color:#64748b;line-height:1.45;">' + esc(lib.install_note) + '</p>' : '')
            + '</article>';
    }

    window._basesEnsureDirs = async function () {
        try {
            var r = await fetch(apiBase() + '/api/pseudos/libraries/ensure_dirs', { method: 'POST' });
            var j = await r.json();
            if (j.success) {
                if (typeof _showToast === 'function') _showToast('Dossiers créés : ' + ((j.created || []).join(', ') || 'déjà présents'), '#059669', 3500);
                return true;
            }
            alert(j.error || 'Échec');
        } catch (e) {
            alert('Erreur : ' + (e.message || e));
        }
        return false;
    };

    window._basesOrganize = async function () {
        try {
            if (typeof _showToast === 'function') _showToast('Organisation en cours…', '#1d4ed8', 2000);
            var r = await fetch(apiBase() + '/api/pseudos/libraries/organize', { method: 'POST' });
            var j = await r.json();
            if (j.success) {
                if (typeof _showToast === 'function') _showToast('Bibliothèques synchronisées', '#059669', 3000);
                return true;
            }
            alert(j.error || 'Échec');
        } catch (e) {
            alert('Erreur : ' + (e.message || e));
        }
        return false;
    };

    window.renderTabAutresBases = async function (container, symbole, element) {
        if (!container) return;
        container.innerHTML = '<div style="padding:20px;text-align:center;color:#94a3b8;">Chargement des bibliothèques…</div>';

        var catalog = await window._fetchLibrariesCatalog();
        if (!catalog.ok) {
            container.innerHTML = ''
                + '<div style="padding:24px;border:2px dashed #fecaca;border-radius:12px;background:#fef2f2;color:#991b1b;text-align:center;">'
                + '<div style="font-size:2em;margin-bottom:8px;">⚠️</div>'
                + '<strong>API bibliothèques indisponible</strong>'
                + '<p style="font-size:0.88em;margin:12px 0 0 0;">' + esc(catalog.error) + '</p>'
                + '<p style="font-size:0.82em;margin-top:10px;">Lancez <code>./DEMARRER.sh</code> puis ouvrez <a href="http://127.0.0.1:5008/">http://127.0.0.1:5008/</a></p>'
                + '</div>';
            return;
        }

        var root = catalog.data.pseudos_root || '';
        var inv = (catalog.data.inventory && catalog.data.inventory.libraries) || [];
        var libsMeta = catalog.data.libraries || [];

        var search = null;
        if (symbole) {
            search = await window._fetchLibrariesSearch(symbole, {});
        }
        var searchLibs = search && search.ok ? (search.data.libraries || []) : [];
        var searchMap = {};
        searchLibs.forEach(function (l) { searchMap[l.id] = l; });

        var families = ['pslibrary', 'pseudodojo', 'sssp', 'gbrv', 'sg15'];
        var activeFam = window.__basesActiveFamily || 'pslibrary';

        var toolbar = ''
            + '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px;align-items:center;">'
            + '<button type="button" class="btn-action btn-secondary-act" style="width:auto;padding:8px 14px;font-size:0.8em;" onclick="_basesEnsureDirs().then(function(ok){if(ok&&window.__basesRefresh)window.__basesRefresh();})">📁 Créer l’arborescence</button>'
            + '<button type="button" class="btn-action btn-secondary-act" style="width:auto;padding:8px 14px;font-size:0.8em;" onclick="_basesOrganize().then(function(ok){if(ok&&window.__basesRefresh)window.__basesRefresh();})">🔄 Organiser / sync</button>'
            + '<code style="font-size:0.72em;color:#64748b;word-break:break-all;flex:1;min-width:180px;">' + esc(root) + '</code>'
            + '</div>';

        var chips = '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px;" role="tablist">'
            + families.map(function (f) {
                var m = FAMILY_META[f] || {};
                var on = f === activeFam;
                return '<button type="button" role="tab" onclick="window.__basesActiveFamily=\'' + f + '\';window.__basesRefresh();" '
                    + 'style="padding:8px 14px;border-radius:20px;border:2px solid ' + (on ? (m.color || '#0f172a') : '#e2e8f0')
                    + ';background:' + (on ? (m.bg || '#fff') : '#fff') + ';color:' + (on ? (m.color || '#0f172a') : '#64748b')
                    + ';font-weight:' + (on ? '700' : '600') + ';cursor:pointer;font-size:0.8em;font-family:inherit;">'
                    + (m.icon || '') + ' ' + esc(m.title || f) + '</button>';
            }).join('')
            + '</div>';

        var hero = familyHero(activeFam);

        var famLibs = libsMeta.filter(function (l) { return (l.family || '').toLowerCase() === activeFam; });
        var cards = famLibs.map(function (meta) {
            var invRow = inv.find(function (x) { return x.id === meta.id; }) || searchMap[meta.id] || meta;
            invRow.label = invRow.label || meta.label;
            invRow.type = invRow.type || meta.type;
            invRow.functional = invRow.functional || meta.functional;
            invRow.ecut_hint_ry = invRow.ecut_hint_ry || meta.ecut_hint_ry;
            invRow.download_url = invRow.download_url || meta.download_url;
            invRow.install_note = invRow.install_note || meta.install_note;
            if (searchMap[meta.id]) {
                invRow.files = searchMap[meta.id].files;
                invRow.file_count = searchMap[meta.id].file_count;
            }
            return libCard(invRow, symbole, root);
        }).join('');

        var elemBanner = '';
        if (symbole && element) {
            var total = search && search.ok ? (search.data.total_matching_files || 0) : 0;
            elemBanner = ''
                + '<div style="background:linear-gradient(135deg,#0f172a,#1e3a5f);color:#e2e8f0;border-radius:12px;padding:14px 18px;margin-bottom:16px;">'
                + '<div style="font-size:0.72em;text-transform:uppercase;letter-spacing:0.06em;color:#67e8f9;">Élément sélectionné</div>'
                + '<div style="font-size:1.35em;font-weight:800;margin-top:4px;">' + esc(symbole) + ' <span style="font-weight:500;font-size:0.75em;color:#94a3b8;">— '
                + esc(element.nom || '') + '</span></div>'
                + '<div style="font-size:0.82em;margin-top:6px;color:#cbd5e1;">'
                + (total > 0 ? '✅ <strong>' + total + '</strong> fichier(s) UPF trouvé(s) localement' : '⚠️ Aucun UPF local — téléchargez depuis les liens ci-dessous')
                + '</div></div>';
        }

        container.innerHTML = ''
            + '<div class="gen-autresbases-tab" style="padding:16px 18px;">'
            + elemBanner
            + '<div style="margin-bottom:12px;">'
            + '<h3 style="margin:0 0 6px 0;font-size:1em;color:#0f172a;">📦 Bibliothèques externes</h3>'
            + '<p style="margin:0;font-size:0.82em;color:#64748b;line-height:1.55;">Jeux curatés (PSLibrary, PseudoDojo, SSSP…) à placer sous votre dossier <code>pseudos</code>. '
            + 'Une fois copiés, les fichiers apparaissent ici et peuvent être assignés à l’élément actif.</p>'
            + '</div>'
            + toolbar + chips + hero
            + '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px;">' + cards + '</div>'
            + '</div>';

        window.__basesRefresh = function () {
            window.renderTabAutresBases(container, symbole, element);
        };
    };
})();

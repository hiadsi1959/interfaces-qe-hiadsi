# -*- coding: utf-8 -*-
"""
Catalogue et indexation des bibliothèques PSLibrary, PseudoDojo et SSSP.

Structure attendue sous le dossier pseudos de l'API :
  PSLibrary_{NC,USPP,PAW}_{LDA,PBE,PBEsol}/
  PseudoDojo_{standard,stringent}/
  SSSP_{efficiency,precision}/
  (+ arborescence legacy PBE/NC, PBE/USPP, … reconnue en secours)
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

# 1–118 (symboles usuels)
SYMBOLS_Z: tuple[str, ...] = (
    "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne",
    "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca",
    "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
    "Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr",
    "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn",
    "Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd",
    "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb",
    "Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg",
    "Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th",
    "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm",
    "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds",
    "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og",
)

# Mapping legacy PBE/ → dossiers standard (synchronisation install_bibliotheques_pseudos.sh)
_LEGACY_SYNC_MAP: tuple[tuple[str, str, str], ...] = (
    ("PBE/NC", "PSLibrary_NC_PBE", "NC"),
    ("PBE/USPP", "PSLibrary_USPP_PBE", "USPP"),
    ("PBE/PAW", "PSLibrary_PAW_PBE", "PAW"),
    ("LDA/NC", "PSLibrary_NC_LDA", "NC"),
    ("LDA/USPP", "PSLibrary_USPP_LDA", "USPP"),
    ("LDA/PAW", "PSLibrary_PAW_LDA", "PAW"),
)

LIBRARY_CATALOG: list[dict[str, Any]] = [
    {
        "id": "PSLibrary_NC_PBE",
        "label": "PSLibrary NC — PBE",
        "family": "pslibrary",
        "type": "NC",
        "functional": "PBE",
        "ecut_hint_ry": "60–90",
        "search_dirs": ["PSLibrary_NC_PBE"],
        "fallback_dirs": ["PBE/NC"],
        "include_patterns": [],
        "exclude_patterns": ["ONCV", "GBRV", "sg15"],
        "download_url": "https://pseudopotentials.quantum-espresso.org/upf_files/psl.nc.PBE.UPF.tar.gz",
        "wget_hint": "wget -O psl.nc.PBE.UPF.tar.gz 'https://pseudopotentials.quantum-espresso.org/upf_files/psl.nc.PBE.UPF.tar.gz'",
        "install_note": "Décompresser dans pseudos/PSLibrary_NC_PBE/",
        "recursive_fallback": True,
        "scan_loose_root": True,
    },
    {
        "id": "PSLibrary_NC_LDA",
        "label": "PSLibrary NC — LDA",
        "family": "pslibrary",
        "type": "NC",
        "functional": "LDA",
        "ecut_hint_ry": "60–90",
        "search_dirs": ["PSLibrary_NC_LDA"],
        "fallback_dirs": ["LDA/NC"],
        "exclude_patterns": ["ONCV", "GBRV"],
        "download_url": "https://pseudopotentials.quantum-espresso.org/upf_files/psl.nc.LDA.UPF.tar.gz",
        "install_note": "Décompresser dans pseudos/PSLibrary_NC_LDA/",
    },
    {
        "id": "PSLibrary_NC_PBEsol",
        "label": "PSLibrary NC — PBEsol",
        "family": "pslibrary",
        "type": "NC",
        "functional": "PBEsol",
        "ecut_hint_ry": "60–90",
        "search_dirs": ["PSLibrary_NC_PBEsol"],
        "exclude_patterns": ["ONCV"],
        "download_url": "https://pseudopotentials.quantum-espresso.org/upf_files/psl.nc.PBEsol.UPF.tar.gz",
        "install_note": "Décompresser dans pseudos/PSLibrary_NC_PBEsol/",
    },
    {
        "id": "PSLibrary_USPP_PBE",
        "label": "PSLibrary USPP — PBE",
        "family": "pslibrary",
        "type": "USPP",
        "functional": "PBE",
        "ecut_hint_ry": "30–50",
        "search_dirs": ["PSLibrary_USPP_PBE"],
        "fallback_dirs": ["PBE/USPP"],
        "exclude_patterns": ["ONCV", "GBRV"],
        "download_url": "https://pseudopotentials.quantum-espresso.org/upf_files/psl.uspp.PBE.UPF.tar.gz",
        "install_note": "Décompresser dans pseudos/PSLibrary_USPP_PBE/",
    },
    {
        "id": "PSLibrary_USPP_LDA",
        "label": "PSLibrary USPP — LDA",
        "family": "pslibrary",
        "type": "USPP",
        "functional": "LDA",
        "ecut_hint_ry": "30–50",
        "search_dirs": ["PSLibrary_USPP_LDA"],
        "fallback_dirs": ["LDA/USPP"],
        "exclude_patterns": ["ONCV", "GBRV"],
        "download_url": "https://pseudopotentials.quantum-espresso.org/upf_files/psl.uspp.LDA.UPF.tar.gz",
        "install_note": "Décompresser dans pseudos/PSLibrary_USPP_LDA/",
    },
    {
        "id": "PSLibrary_USPP_PBEsol",
        "label": "PSLibrary USPP — PBEsol",
        "family": "pslibrary",
        "type": "USPP",
        "functional": "PBEsol",
        "ecut_hint_ry": "30–50",
        "search_dirs": ["PSLibrary_USPP_PBEsol"],
        "exclude_patterns": ["ONCV"],
        "download_url": "https://pseudopotentials.quantum-espresso.org/upf_files/psl.uspp.PBEsol.UPF.tar.gz",
        "install_note": "Décompresser dans pseudos/PSLibrary_USPP_PBEsol/",
    },
    {
        "id": "PSLibrary_PAW_PBE",
        "label": "PSLibrary PAW — PBE",
        "family": "pslibrary",
        "type": "PAW",
        "functional": "PBE",
        "ecut_hint_ry": "40–80",
        "search_dirs": ["PSLibrary_PAW_PBE"],
        "fallback_dirs": ["PBE/PAW"],
        "exclude_patterns": ["ONCV", "GBRV"],
        "download_url": "https://pseudopotentials.quantum-espresso.org/upf_files/psl.paw.PBE.UPF.tar.gz",
        "install_note": "Décompresser dans pseudos/PSLibrary_PAW_PBE/",
    },
    {
        "id": "PSLibrary_PAW_LDA",
        "label": "PSLibrary PAW — LDA",
        "family": "pslibrary",
        "type": "PAW",
        "functional": "LDA",
        "ecut_hint_ry": "40–80",
        "search_dirs": ["PSLibrary_PAW_LDA"],
        "fallback_dirs": ["LDA/PAW"],
        "exclude_patterns": ["ONCV"],
        "download_url": "https://pseudopotentials.quantum-espresso.org/upf_files/psl.paw.LDA.UPF.tar.gz",
        "install_note": "Décompresser dans pseudos/PSLibrary_PAW_LDA/",
    },
    {
        "id": "PSLibrary_PAW_PBEsol",
        "label": "PSLibrary PAW — PBEsol",
        "family": "pslibrary",
        "type": "PAW",
        "functional": "PBEsol",
        "ecut_hint_ry": "40–80",
        "search_dirs": ["PSLibrary_PAW_PBEsol"],
        "exclude_patterns": ["ONCV"],
        "download_url": "https://pseudopotentials.quantum-espresso.org/upf_files/psl.paw.PBEsol.UPF.tar.gz",
        "install_note": "Décompresser dans pseudos/PSLibrary_PAW_PBEsol/",
    },
    {
        "id": "PseudoDojo_standard",
        "label": "PseudoDojo — standard (ONCVPSP)",
        "family": "pseudodojo",
        "type": "NC",
        "functional": "PBE",
        "ecut_hint_ry": "40–80",
        "search_dirs": ["PseudoDojo_standard"],
        "fallback_dirs": ["PBE/NC"],
        "include_patterns": [],
        "exclude_patterns": ["psl.", "kjpaw", "rrkjus", "GBRV"],
        "download_url": "https://www.pseudo-dojo.org/",
        "install_note": "Télécharger le jeu standard (PBE) et copier les .upf dans PseudoDojo_standard/",
    },
    {
        "id": "PseudoDojo_stringent",
        "label": "PseudoDojo — stringent (ONCVPSP)",
        "family": "pseudodojo",
        "type": "NC",
        "functional": "PBE",
        "ecut_hint_ry": "50–100",
        "search_dirs": ["PseudoDojo_stringent"],
        "include_patterns": [],
        "exclude_patterns": ["psl.", "kjpaw", "rrkjus"],
        "download_url": "https://www.pseudo-dojo.org/",
        "install_note": "Jeu stringent — dossier PseudoDojo_stringent/",
    },
    {
        "id": "Lanthanides_NC_PBE",
        "label": "Lanthanides NC PBE (La–Lu, PseudoDojo v0.4)",
        "family": "pseudodojo",
        "type": "NC",
        "functional": "PBE",
        "ecut_hint_ry": "50–100",
        "search_dirs": ["Lanthanides_NC_PBE"],
        "fallback_dirs": ["PseudoDojo_standard"],
        "include_patterns": [],
        "exclude_patterns": ["psl.", "kjpaw", "rrkjus", "paw", "uspp"],
        "download_url": "https://github.com/PseudoDojo/ONCVPSP-PBE-PDv0.4",
        "install_note": "Exécuter ./telecharger_lanthanides_nc.sh (UPF QE + variantes sp / f-in-core).",
    },
    {
        "id": "SSSP_efficiency",
        "label": "SSSP — Efficiency",
        "family": "sssp",
        "type": "mixed",
        "functional": "PBE",
        "ecut_hint_ry": "voir cutoffs SSSP",
        "search_dirs": ["SSSP_efficiency"],
        "include_patterns": [],
        "exclude_patterns": [],
        "download_url": "https://www.materialscloud.org/discover/sssp",
        "install_note": "Archive PBE efficiency → pseudos/SSSP_efficiency/",
    },
    {
        "id": "SSSP_precision",
        "label": "SSSP — Precision",
        "family": "sssp",
        "type": "mixed",
        "functional": "PBE",
        "ecut_hint_ry": "voir cutoffs SSSP",
        "search_dirs": ["SSSP_precision"],
        "include_patterns": [],
        "exclude_patterns": [],
        "download_url": "https://www.materialscloud.org/discover/sssp",
        "install_note": "Archive PBE precision → pseudos/SSSP_precision/",
        "wget_hint": "pip install aiida-sssp && verdi data sssp install --functional PBE --protocol precision",
    },
    # ═══════════════════════════════════════════════════════════════════════
    # GBRV — Garrity-Bennett-Rabe-Vanderbilt (USPP, UPF)
    # ═══════════════════════════════════════════════════════════════════════
    {
        "id": "GBRV_USPP_PBE",
        "label": "GBRV USPP — PBE (USPP Vanderbilt)",
        "family": "gbrv",
        "type": "USPP",
        "functional": "PBE",
        "ecut_hint_ry": "25–50",
        "search_dirs": ["GBRV_USPP_PBE"],
        "fallback_dirs": [],
        "include_patterns": [],
        "exclude_patterns": ["psl.", "ONCV", "sg15", "dojo"],
        "download_url": "https://www.physics.rutgers.edu/gbrv/",
        "wget_hint": "wget -r -np -nH --cut-dirs=2 -A '*.UPF' 'https://www.physics.rutgers.edu/gbrv/'",
        "install_note": "Télécharger depuis physics.rutgers.edu/gbrv/ et copier les .UPF dans GBRV_USPP_PBE/",
        "scan_loose_root": True,
    },
    # ═══════════════════════════════════════════════════════════════════════
    # SG15 — Schlipf-Gygi (ONCVPSP NC, UPF)
    # ═══════════════════════════════════════════════════════════════════════
    {
        "id": "SG15_NC_PBE",
        "label": "SG15 NC — PBE (ONCVPSP)",
        "family": "sg15",
        "type": "NC",
        "functional": "PBE",
        "ecut_hint_ry": "40–80",
        "search_dirs": ["SG15_NC_PBE"],
        "fallback_dirs": [],
        "include_patterns": [],
        "exclude_patterns": ["psl.", "GBRV", "dojo"],
        "download_url": "http://www.quantum-simulation.org/potentials/sg15_oncv/",
        "wget_hint": "wget http://www.quantum-simulation.org/potentials/sg15_oncv/sg15_oncv_upf_2020-02-06.tar.gz && tar -xzf sg15_oncv_upf_2020-02-06.tar.gz -C SG15_NC_PBE/",
        "install_note": "Télécharger sg15_oncv_upf_2020-02-06.tar.gz, décompresser dans SG15_NC_PBE/",
        "scan_loose_root": True,
    },
    # ═══════════════════════════════════════════════════════════════════════
    # PseudoDojo PSML — format PSML pour QE (via upfconv)
    # ═══════════════════════════════════════════════════════════════════════
    {
        "id": "PseudoDojo_PSML",
        "label": "PseudoDojo — PSML (format portable)",
        "family": "pseudodojo",
        "type": "NC",
        "functional": "PBE",
        "ecut_hint_ry": "40–80",
        "search_dirs": ["PseudoDojo_PSML"],
        "include_patterns": [],
        "exclude_patterns": ["psl.", "kjpaw", "rrkjus"],
        "download_url": "https://www.pseudo-dojo.org/",
        "install_note": "Format PSML — nécessite psml2upf.x ou upfconv.py pour conversion QE. Télécharger depuis pseudo-dojo.org.",
    },
    # ═══════════════════════════════════════════════════════════════════════
    # PseudoDojo LDA — standard & stringent
    # ═══════════════════════════════════════════════════════════════════════
    {
        "id": "PseudoDojo_LDA_standard",
        "label": "PseudoDojo — LDA standard (ONCVPSP)",
        "family": "pseudodojo",
        "type": "NC",
        "functional": "LDA",
        "ecut_hint_ry": "40–80",
        "search_dirs": ["PseudoDojo_LDA_standard"],
        "include_patterns": [],
        "exclude_patterns": ["psl.", "kjpaw", "rrkjus", "GBRV", "PBE", "PBEsol"],
        "download_url": "https://www.pseudo-dojo.org/",
        "install_note": "Jeu LDA standard — télécharger les .upf depuis pseudo-dojo.org et copier dans PseudoDojo_LDA_standard/",
    },
    {
        "id": "PseudoDojo_LDA_stringent",
        "label": "PseudoDojo — LDA stringent (ONCVPSP)",
        "family": "pseudodojo",
        "type": "NC",
        "functional": "LDA",
        "ecut_hint_ry": "50–100",
        "search_dirs": ["PseudoDojo_LDA_stringent"],
        "include_patterns": [],
        "exclude_patterns": ["psl.", "kjpaw", "rrkjus", "PBE", "PBEsol"],
        "download_url": "https://www.pseudo-dojo.org/",
        "install_note": "Jeu LDA stringent — dossier PseudoDojo_LDA_stringent/",
    },
    # ═══════════════════════════════════════════════════════════════════════
    # PseudoDojo PBEsol — standard & stringent
    # ═══════════════════════════════════════════════════════════════════════
    {
        "id": "PseudoDojo_PBEsol_standard",
        "label": "PseudoDojo — PBEsol standard (ONCVPSP)",
        "family": "pseudodojo",
        "type": "NC",
        "functional": "PBEsol",
        "ecut_hint_ry": "40–80",
        "search_dirs": ["PseudoDojo_PBEsol_standard"],
        "include_patterns": [],
        "exclude_patterns": ["psl.", "kjpaw", "rrkjus", "GBRV", "PBE", "LDA"],
        "download_url": "https://www.pseudo-dojo.org/",
        "install_note": "Jeu PBEsol standard — dossier PseudoDojo_PBEsol_standard/",
    },
    {
        "id": "PseudoDojo_PBEsol_stringent",
        "label": "PseudoDojo — PBEsol stringent (ONCVPSP)",
        "family": "pseudodojo",
        "type": "NC",
        "functional": "PBEsol",
        "ecut_hint_ry": "50–100",
        "search_dirs": ["PseudoDojo_PBEsol_stringent"],
        "include_patterns": [],
        "exclude_patterns": ["psl.", "kjpaw", "rrkjus", "PBE", "LDA"],
        "download_url": "https://www.pseudo-dojo.org/",
        "install_note": "Jeu PBEsol stringent — dossier PseudoDojo_PBEsol_stringent/",
    },
    # ═══════════════════════════════════════════════════════════════════════
    # SSSP PBEsol — efficiency & precision
    # ═══════════════════════════════════════════════════════════════════════
    {
        "id": "SSSP_PBEsol_efficiency",
        "label": "SSSP — PBEsol Efficiency",
        "family": "sssp",
        "type": "mixed",
        "functional": "PBEsol",
        "ecut_hint_ry": "voir cutoffs SSSP",
        "search_dirs": ["SSSP_PBEsol_efficiency"],
        "include_patterns": ["PBEsol"],
        "exclude_patterns": [],
        "download_url": "https://www.materialscloud.org/discover/sssp",
        "install_note": "Archive PBEsol efficiency → pseudos/SSSP_PBEsol_efficiency/",
    },
    {
        "id": "SSSP_PBEsol_precision",
        "label": "SSSP — PBEsol Precision",
        "family": "sssp",
        "type": "mixed",
        "functional": "PBEsol",
        "ecut_hint_ry": "voir cutoffs SSSP",
        "search_dirs": ["SSSP_PBEsol_precision"],
        "include_patterns": ["PBEsol"],
        "exclude_patterns": [],
        "download_url": "https://www.materialscloud.org/discover/sssp",
        "install_note": "Archive PBEsol precision → pseudos/SSSP_PBEsol_precision/",
    },
    # ═══════════════════════════════════════════════════════════════════════
    # Vanderbilt USPP — bibliothèque originale ultrasoft (Rutgers)
    # ═══════════════════════════════════════════════════════════════════════
    {
        "id": "Vanderbilt_USPP_PBE",
        "label": "Vanderbilt USPP — PBE (ultrasoft originaux)",
        "family": "vanderbilt",
        "type": "USPP",
        "functional": "PBE",
        "ecut_hint_ry": "25–50",
        "search_dirs": ["Vanderbilt_USPP_PBE"],
        "fallback_dirs": [],
        "include_patterns": [],
        "exclude_patterns": ["psl.", "ONCV", "sg15", "dojo", "GBRV"],
        "download_url": "https://www.physics.rutgers.edu/~dhv/uspp/",
        "wget_hint": "wget -r -np -nH --cut-dirs=2 -A '*.UPF,*UPF' 'https://www.physics.rutgers.edu/~dhv/uspp/'",
        "install_note": "Bibliothèque USPP originale de Vanderbilt — fichiers plus anciens. Télécharger et copier dans Vanderbilt_USPP_PBE/",
        "scan_loose_root": True,
    },
    # ═══════════════════════════════════════════════════════════════════════
    # THEOS EPFL — pseudos UPF maintenus par le groupe THEOS (EPFL)
    # ═══════════════════════════════════════════════════════════════════════
    {
        "id": "THEOS_NC_PBE",
        "label": "THEOS EPFL NC — PBE (ONCVPSP)",
        "family": "theos",
        "type": "NC",
        "functional": "PBE",
        "ecut_hint_ry": "40–80",
        "search_dirs": ["THEOS_NC_PBE"],
        "fallback_dirs": [],
        "include_patterns": [],
        "exclude_patterns": ["dojo", "GBRV", "sg15", "oncv"],
        "download_url": "https://theos-wiki.epfl.ch/Main/Pseudopotentials",
        "wget_hint": "Voir https://theos-wiki.epfl.ch/Main/Pseudopotentials pour les instructions de téléchargement",
        "install_note": "Télécharger les .UPF depuis theos-wiki.epfl.ch et copier dans THEOS_NC_PBE/",
        "scan_loose_root": True,
    },
    # ═══════════════════════════════════════════════════════════════════════
    # HGH — Hartwigsen-Goedecker-Hutter (NC, legacy QE)
    # ═══════════════════════════════════════════════════════════════════════
    {
        "id": "HGH_NC_PBE",
        "label": "HGH NC — PBE (Hartwigsen-Goedecker-Hutter)",
        "family": "hgh",
        "type": "NC",
        "functional": "PBE",
        "ecut_hint_ry": "40–80",
        "search_dirs": ["HGH_NC_PBE"],
        "fallback_dirs": [],
        "include_patterns": [],
        "exclude_patterns": ["psl.", "dojo", "ONCV", "GBRV", "sg15"],
        "download_url": "https://pseudopotentials.quantum-espresso.org/legacy_tables",
        "wget_hint": "Télécharger depuis le portail QE Legacy tables : https://pseudopotentials.quantum-espresso.org/legacy_tables",
        "install_note": "Pseudos HGH NC norm-conserving (analytiques Gaussiennes). Télécharger et copier dans HGH_NC_PBE/. Peut nécessiter upftools/ pour conversion.",
        "scan_loose_root": True,
    },
]

for _lib in LIBRARY_CATALOG:
    fam = (_lib.get("family") or "").lower()
    if fam == "pslibrary":
        _lib.setdefault("recursive_fallback", bool(_lib.get("fallback_dirs")))
        _lib.setdefault("scan_loose_root", True)
    elif fam == "pseudodojo":
        _lib.setdefault("recursive_fallback", bool(_lib.get("fallback_dirs")))
    elif fam == "sssp":
        _lib.setdefault("scan_loose_root", True)

STANDARD_SUBDIRS: tuple[str, ...] = tuple(lib["id"] for lib in LIBRARY_CATALOG)

DOWNLOAD_PORTAL: dict[str, dict[str, str]] = {
    "pslibrary": {
        "title": "PSLibrary (Quantum ESPRESSO)",
        "portal": "https://pseudopotentials.quantum-espresso.org/",
        "legacy": "https://pseudopotentials.quantum-espresso.org/legacy_tables",
        "script": "./install_bibliotheques_pseudos.sh",
    },
    "pseudodojo": {
        "title": "PseudoDojo (ONCVPSP)",
        "portal": "https://www.pseudo-dojo.org/",
        "lanthanides": "https://github.com/PseudoDojo/ONCVPSP-PBE-PDv0.4",
        "script": "./TELECHARGER_BASES.sh --quick",
    },
    "sssp": {
        "title": "SSSP (Materials Cloud)",
        "portal": "https://www.materialscloud.org/discover/sssp",
        "table": "https://www.materialscloud.org/discover/sssp/table",
        "script": "./TELECHARGER_BASES.sh --quick",
    },
    "gbrv": {
        "title": "GBRV (Rutgers)",
        "portal": "https://www.physics.rutgers.edu/gbrv/",
        "description": "Ultrasoft (USPP) — Bennett, Garrity, Rabe, Vanderbilt. Couvre la majorité du tableau périodique. Format UPF natif pour QE.",
        "upf_url": "https://www.physics.rutgers.edu/gbrv/all_pbe_UPF_v1.5.tar.gz",
        "script": "./TELECHARGER_BASES.sh --lib GBRV_USPP_PBE",
    },
    "sg15": {
        "title": "SG15 (Schlipf-Gygi)",
        "portal": "http://www.quantum-simulation.org/potentials/sg15_oncv/",
        "upf_url": "http://www.quantum-simulation.org/potentials/sg15_oncv/sg15_oncv_upf_2020-02-06.tar.gz",
        "description": "ONCVPSP NC optimisés — UPF natif pour QE. Éléments H–Pu, PBE, 2 énergies de référence par canal.",
        "script": "./TELECHARGER_BASES.sh --lib SG15_NC_PBE",
    },
    "oncvpsp": {
        "title": "ONCVPSP (Hamann)",
        "portal": "https://github.com/oncvpsp/oncvpsp",
        "description": "Générateur NC optimisé de D.R. Hamann. Base de PseudoDojo et SG15. Produit des UPF pour QE (psfile=both).",
    },
    "vanderbilt": {
        "title": "Vanderbilt USPP (Rutgers)",
        "portal": "https://www.physics.rutgers.edu/~dhv/uspp/",
        "description": "Bibliothèque USPP originale de David Vanderbilt — fondation des pseudos ultrasoft. Nécessite parfois validation avec QE moderne.",
        "script": "wget -r -np -nH --cut-dirs=2 -A '*.UPF' 'https://www.physics.rutgers.edu/~dhv/uspp/'",
    },
    "theos": {
        "title": "THEOS EPFL (UPF)",
        "portal": "https://theos-wiki.epfl.ch/Main/Pseudopotentials",
        "description": "Groupe THEOS — pseudopotentiels NC en format UPF pour QE. Recommandent SSSP pour les calculs haute précision.",
        "script": "Voir https://theos-wiki.epfl.ch/Main/Pseudopotentials",
    },
    "hgh": {
        "title": "HGH (Hartwigsen-Goedecker-Hutter)",
        "portal": "https://pseudopotentials.quantum-espresso.org/legacy_tables",
        "description": "Pseudos NC analytiques (Gaussiennes) — table legacy QE. Norm-conserving, multi-élément. Disponible via la page Legacy Tables du portail QE.",
        "script": "Télécharger depuis https://pseudopotentials.quantum-espresso.org/legacy_tables",
    },
}


def _norm_sym(symbol: str) -> str:
    s = (symbol or "").strip()
    if len(s) == 1:
        return s.upper()
    return s[0].upper() + s[1:].lower() if len(s) >= 2 else s.upper()


def _match_element(filename: str, symbol: str) -> bool:
    sym = _norm_sym(symbol)
    if len(sym) < 1 or len(sym) > 3:
        return False
    low = filename.lower()
    s = sym.lower()
    if low.startswith(s + ".") or low.startswith(s + "_") or low.startswith(s + "-"):
        return True
    # SSSP / variantes : upf_Mn_PBE… ou Mn.upf
    if re.search(rf"(^|[_.-]){re.escape(s)}([_.-]|\.upf)", low):
        return True
    return False


def _name_l(name: str) -> str:
    return name.lower()


def _is_pslibrary_upf(name: str, ptype: str) -> bool:
    n = _name_l(name)
    if any(x in n for x in ("oncv", "gbrv", "sg15", "dojo")):
        return False
    if ptype == "NC":
        return "psl" in n or ("rrkjus" in n and "paw" not in n and "us" not in n and "uspp" not in n)
    if ptype == "USPP":
        return any(x in n for x in ("rrkjus", "uspp", ".us.", "-us", "_us", "ultrasoft"))
    if ptype == "PAW":
        return any(x in n for x in ("paw", "kjpaw", "pbe-paw", "-paw"))
    return "psl" in n


def _is_pseudodojo_upf(name: str) -> bool:
    n = _name_l(name)
    if "psl" in n and "oncv" not in n and not n.endswith(".psml"):
        return False
    if any(x in n for x in ("oncv", "dojo", "pdojo", "sg15", "psml")):
        return True
    # Archives nc-sr-04_*_upf.tgz : Ag.upf, Si.upf, …
    return bool(re.match(r"^[a-z]{1,2}\.upf$", n))


def _is_psml_file(name: str) -> bool:
    return _name_l(name).endswith(".psml") or _name_l(name).endswith(".xml")


def _is_vanderbilt_uspp(name: str) -> bool:
    n = _name_l(name)
    if any(x in n for x in ("psl.", "oncv", "sg15", "dojo", "gbrv")):
        return False
    return "uspp" in n


def _is_theos_upf(name: str) -> bool:
    n = _name_l(name)
    if any(x in n for x in ("oncv", "sg15", "dojo", "gbrv", "hgh")):
        return False
    return "kjpaw" in n or ("psl" in n and "pbe" in n)


def _is_hgh_upf(name: str) -> bool:
    return "-hgh" in _name_l(name) or ".hgh." in _name_l(name)


def _is_sssp_upf(name: str) -> bool:
    # Jeux SSSP : mélange ONCV, PSLibrary, GBRV, etc.
    return True


def _is_gbrv_upf(name: str) -> bool:
    n = _name_l(name)
    if any(x in n for x in ("psl.", "oncv", "sg15", "dojo")):
        return False
    return "uspp" in n and "_pbe_" in n


def _is_sg15_upf(name: str) -> bool:
    n = _name_l(name)
    if any(x in n for x in ("psl.", "gbrv", "dojo")):
        return False
    return "oncv" in n and "pbe" in n


def _passes_filters(name: str, lib: dict[str, Any]) -> bool:
    nlow = _name_l(name)
    family = (lib.get("family") or "").lower()
    ptype = (lib.get("type") or "").upper()
    if family == "pslibrary" and not _is_pslibrary_upf(name, ptype):
        return False
    if lib.get("id") == "PseudoDojo_PSML":
        if not _is_psml_file(name):
            return False
    elif family == "pseudodojo" and not _is_pseudodojo_upf(name):
        return False
    if family == "sssp" and not _is_sssp_upf(name):
        return False
    if family == "gbrv" and not _is_gbrv_upf(name):
        return False
    if family == "sg15" and not _is_sg15_upf(name):
        return False
    if family == "vanderbilt" and not _is_vanderbilt_uspp(name):
        return False
    if family == "theos" and not _is_theos_upf(name):
        return False
    if family == "hgh" and not _is_hgh_upf(name):
        return False
    for pat in lib.get("include_patterns") or []:
        if pat.lower() not in nlow:
            return False
    for pat in lib.get("exclude_patterns") or []:
        if pat.lower() in nlow:
            return False
    return True


def _iter_upf_in_dir(
    directory: Path,
    recursive: bool = False,
    extra_globs: tuple[str, ...] = (),
) -> list[Path]:
    if not directory.is_dir():
        return []
    out: list[Path] = []
    globs = ("*.UPF", "*.upf") + extra_globs
    if recursive:
        for pat in tuple(f"**/{g}" for g in globs):
            out.extend(directory.glob(pat))
    else:
        for pat in globs:
            out.extend(directory.glob(pat))
    return out


def _resolve_search_paths(root: Path, lib: dict[str, Any]) -> list[Path]:
    paths: list[Path] = []
    seen: set[str] = set()
    for key in ("search_dirs", "fallback_dirs"):
        for rel in lib.get(key) or []:
            p = (root / rel).resolve()
            key_s = str(p)
            if key_s not in seen and p.is_dir():
                seen.add(key_s)
                paths.append(p)
    return paths


def _loose_root_matches_lib(name: str, lib: dict[str, Any]) -> bool:
    """Évite de classer un même UPF PBE dans PAW_LDA / PAW_PBEsol, etc."""
    func = (lib.get("functional") or "PBE").lower()
    n = _name_l(name)
    if func == "pbesol":
        return "pbesol" in n
    if func == "lda":
        return ("lda" in n or ".lda." in n) and "pbe" not in n
    # PBE par défaut
    return "pbesol" not in n and not (("lda" in n or ".lda." in n) and "pbe" not in n)


def _append_file_entry(
    files: list[dict[str, Any]],
    fp: Path,
    root: Path,
    dpath: Path,
    lib: dict[str, Any],
    element: str | None,
    from_loose_root: bool = False,
) -> None:
    name = fp.name
    if element and not _match_element(name, element):
        return
    if from_loose_root and not _loose_root_matches_lib(name, lib):
        return
    if not _passes_filters(name, lib):
        return
    try:
        rel = str(fp.relative_to(root))
    except ValueError:
        rel = str(fp)
    try:
        lib_rel = str(dpath.relative_to(root))
    except ValueError:
        lib_rel = str(dpath)
    files.append({
        "name": name,
        "path": str(fp.resolve()),
        "relative": rel,
        "size": fp.stat().st_size,
        "library_dir": lib_rel,
    })


def scan_library(root: str | Path, lib_id: str, element: str | None = None) -> dict[str, Any]:
    """Scanne une bibliothèque ; si element est fourni, ne retourne que ses fichiers."""
    root = Path(root).expanduser().resolve()
    lib = next((x for x in LIBRARY_CATALOG if x["id"] == lib_id), None)
    if lib is None:
        return {"id": lib_id, "error": "Bibliothèque inconnue", "files": []}

    files: list[dict[str, Any]] = []
    dirs_ok: list[str] = []
    recursive_fb = bool(lib.get("recursive_fallback"))
    extra_globs: tuple[str, ...] = ()
    if lib.get("id") == "PseudoDojo_PSML":
        extra_globs = ("*.psml", "*.PSML", "*.xml", "*.XML")
    for dpath in _resolve_search_paths(root, lib):
        try:
            dirs_ok.append(str(dpath.relative_to(root)))
        except ValueError:
            dirs_ok.append(str(dpath))
        is_fallback = any(
            (dpath.resolve() == (root / rel).resolve())
            for rel in (lib.get("fallback_dirs") or [])
        )
        for fp in _iter_upf_in_dir(dpath, recursive=is_fallback and recursive_fb, extra_globs=extra_globs):
            _append_file_entry(files, fp, root, dpath, lib, element, False)

    if lib.get("scan_loose_root"):
        for fp in _iter_upf_in_dir(root, recursive=False):
            _append_file_entry(files, fp, root, root, lib, element, True)

    seen_names: set[str] = set()
    unique: list[dict[str, Any]] = []
    for f in files:
        if f["name"] in seen_names:
            continue
        seen_names.add(f["name"])
        unique.append(f)

    return {
        "id": lib_id,
        "label": lib["label"],
        "family": lib["family"],
        "type": lib["type"],
        "functional": lib["functional"],
        "ecut_hint_ry": lib.get("ecut_hint_ry"),
        "dirs_present": dirs_ok,
        "file_count": len(unique),
        "files": unique,
        "download_url": lib.get("download_url"),
        "install_note": lib.get("install_note"),
        "wget_hint": lib.get("wget_hint"),
    }


def scan_all_libraries(root: str | Path, element: str | None = None) -> dict[str, Any]:
    root = Path(root).expanduser().resolve()
    libraries = []
    total_files = 0
    for lib in LIBRARY_CATALOG:
        row = scan_library(root, lib["id"], element)
        libraries.append(row)
        total_files += row.get("file_count", 0)

    coverage: dict[str, list[str]] = {}
    if element:
        for lib in libraries:
            if lib.get("file_count", 0) > 0:
                coverage.setdefault(element, []).append(lib["id"])

    return {
        "pseudos_root": str(root),
        "element": element,
        "libraries": libraries,
        "total_matching_files": total_files,
        "standard_subdirs": STANDARD_SUBDIRS,
        "elements_indexed": list(SYMBOLS_Z),
    }


def ensure_library_tree(root: str | Path) -> list[str]:
    """Crée les sous-dossiers standard + README."""
    root = Path(root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    created: list[str] = []
    readme = (
        "# Bibliothèques de pseudopotentiels Quantum ESPRESSO\n\n"
        "Placez les archives téléchargées dans les sous-dossiers correspondants.\n"
        "Voir pseudo_libraries.py et ./install_bibliotheques_pseudos.sh\n"
    )
    if not (root / "README_BIBLIOTHEQUES.md").is_file():
        (root / "README_BIBLIOTHEQUES.md").write_text(readme, encoding="utf-8")
        created.append("README_BIBLIOTHEQUES.md")

    for sub in STANDARD_SUBDIRS:
        d = root / sub
        if not d.is_dir():
            d.mkdir(parents=True, exist_ok=True)
            created.append(sub)
        note = d / "LISEZMOI.txt"
        if not note.is_file():
            lib = next(x for x in LIBRARY_CATALOG if x["id"] == sub)
            note.write_text(
                f"{lib['label']}\n\n{lib.get('install_note', '')}\n"
                f"Téléchargement : {lib.get('download_url', '')}\n",
                encoding="utf-8",
            )
    return created


def get_catalog_metadata() -> dict[str, Any]:
    """Métadonnées pour l'UI (sans scan disque)."""
    return {
        "libraries": [
            {k: lib[k] for k in (
                "id", "label", "family", "type", "functional",
                "ecut_hint_ry", "download_url", "install_note", "wget_hint",
            ) if k in lib}
            for lib in LIBRARY_CATALOG
        ],
        "elements": list(SYMBOLS_Z),
        "families": {
            "pslibrary": "Dal Corso — NC / USPP / PAW (QE officiel)",
            "pseudodojo": "ONCVPSP — jeux standard & stringent",
            "sssp": "Materials Cloud — sélection curatée PBE",
            "gbrv": "Garrity-Bennett-Rabe-Vanderbilt — USPP (Rutgers)",
            "sg15": "Schlipf-Gygi — ONCVPSP NC optimisés",
            "vanderbilt": "Vanderbilt USPP originaux — USPP (Rutgers)",
            "theos": "THEOS EPFL — NC UPF pour QE",
            "hgh": "HGH — NC analytiques Gaussiennes (legacy QE)",
        },
        "download_portals": DOWNLOAD_PORTAL,
    }


def organize_libraries(root: str | Path, copy_files: bool = True) -> dict[str, Any]:
    """
    Synchronise PBE/LDA legacy → PSLibrary_* et classe les UPF isolés à la racine.
    Copie (pas de lien) pour que l’inventaire reste stable.
    """
    root = Path(root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    actions: list[str] = []

    def _place(src: Path, dest_dir: Path, ptype: str) -> None:
        if not src.is_file() or not _is_pslibrary_upf(src.name, ptype):
            return
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / src.name
        if dest.resolve() == src.resolve():
            return
        if dest.is_file():
            return
        if copy_files:
            import shutil
            shutil.copy2(src, dest)
            actions.append(f"copy {src.name} → {dest_dir.name}/")
        else:
            actions.append(f"would copy {src.name} → {dest_dir.name}/")

    for leg, std_id, ptype in _LEGACY_SYNC_MAP:
        leg_path = root / leg
        lib = next((x for x in LIBRARY_CATALOG if x["id"] == std_id), None)
        if not lib or not leg_path.is_dir():
            continue
        dest = root / std_id
        for fp in _iter_upf_in_dir(leg_path, recursive=True):
            _place(fp, dest, ptype)

    for fp in _iter_upf_in_dir(root, recursive=False):
        name = fp.name
        if not name.lower().endswith((".upf",)):
            continue
        if _is_pslibrary_upf(name, "PAW"):
            _place(fp, root / "PSLibrary_PAW_PBE", "PAW")
        elif _is_pslibrary_upf(name, "USPP"):
            _place(fp, root / "PSLibrary_USPP_PBE", "USPP")
        elif _is_pslibrary_upf(name, "NC"):
            _place(fp, root / "PSLibrary_NC_PBE", "NC")
        elif _is_pseudodojo_upf(name):
            _place_dojo = root / "PseudoDojo_standard"
            dest = _place_dojo / name
            if not dest.is_file() and copy_files:
                import shutil
                _place_dojo.mkdir(parents=True, exist_ok=True)
                shutil.copy2(fp, dest)
                actions.append(f"copy {name} → PseudoDojo_standard/")

    oncv_nc = root / "PBE" / "NC"
    if oncv_nc.is_dir():
        dest = root / "PseudoDojo_standard"
        dest.mkdir(parents=True, exist_ok=True)
        for fp in _iter_upf_in_dir(oncv_nc, recursive=False):
            if not _is_pseudodojo_upf(fp.name):
                continue
            target = dest / fp.name
            if target.is_file():
                continue
            if copy_files:
                import shutil
                shutil.copy2(fp, target)
                actions.append(f"sync ONCV {fp.name} → PseudoDojo_standard/")

    return {
        "pseudos_root": str(root),
        "actions": actions,
        "action_count": len(actions),
    }

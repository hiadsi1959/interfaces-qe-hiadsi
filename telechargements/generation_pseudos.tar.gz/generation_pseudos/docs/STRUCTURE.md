# Arborescence du projet

Organisation par **type de fichier**. Les chemins servis par l’interface (`index.html`, scripts JS, gabarits ONCV) restent **accessibles à la racine** (fichiers réels ou liens symboliques).

## Racine (interface + API)

| Fichier / dossier | Rôle |
|-------------------|------|
| `index.html`, `pseudo_wizard.html` | Pages web |
| `script_*.js`, `utils_dom_safe.js`, `config_chemins.js`, `qe_paths_setup.js` | JavaScript (servi par Flask) |
| `logo_usto.png` | Image |
| `api_pseudos_standalone.py` | API Flask (port 5008) |
| `*.py` (modules API) | `generator_guide.py`, `pseudo_libraries.py`, `lanthanide_nc.py`, … |
| `api_config.json` | Configuration binaires QE / ONCV |
| `oncv_default_*.dat` | Liens → `data/oncv/` (fetch UI) |
| `oncv_templates_3d/` | Gabarits métaux 3d |
| `DEMARRER.sh`, `GenerationPseudos`, `configure.sh`, … | Wrappers → `scripts/` |

## Par type

```
generation_pseudos/
├── scripts/          # Shell : démarrage, configure.sh, TRANSFERER, déploiement, nettoyage
├── tools/            # Python utilitaires (téléchargements massifs)
├── tests/            # verifier_api_generale.py, fixtures/
├── docs/             # Installation, chemins UI, archive
├── data/
│   ├── oncv/         # oncv_default_*.dat
│   └── oncvpsp_tests_data/
├── pseudos-ld1/      # Sorties ld1.x
├── pseudos-APE/      # Sorties APE
├── pseudos-atompaw/  # Sorties ATOMPAW
├── pseudos-oncvpsp/  # Sorties ONCVPSP
├── pseudos-telecharges/  # Imports catalogue
├── pseudos/          # Bibliothèque UPF pour pw.x
├── pseudo_generator_templates/
├── third_party/      # APE, ATOMPAW (optionnel)
├── _work/            # Runs temporaires API
├── archive/          # Anciens fichiers (supprimable)
├── inputs/, outputs/ # ld1 / calculs (si utilisés)
└── logs/
```

## Démarrage

```bash
./configure.sh                   # configuration nouvel ordinateur (une fois)
./DEMARRER.sh                    # démarrage API
python3 tests/verifier_api_generale.py
./scripts/verifier_chemins_ui.sh
```

## Règle

Ne déplacez **pas** sans lien symbolique : `index.html`, les `script_*.js`, `oncv_default_*.dat`, `api_pseudos_standalone.py`. Détail : [CHEMINS_INTERFACE.md](CHEMINS_INTERFACE.md).

# Dossier `archive/`

Ce répertoire regroupe des **artefacts déplacés** lors du rangement du dépôt. Il n’est **pas lu** par l’interface ni par l’API.

## Contenu typique

| Sous-dossier | Contenu |
|--------------|---------|
| `work_runs/` | Anciens dossiers `_work/ape_*`, `atompaw_*`, `oncv_*` |
| `root_misc/` | UPF / `.wfc` / tests laissés à la racine |
| `legacy_api/` | Ancien `api/api_qe_ubuntu.py` (remplacé par `api_pseudos_standalone.py`) |
| `pseudos_telecharges_ancien/` | Doublon de téléchargements (nom avec espace) |

## Suppression

```bash
rm -rf archive/
```

Libère de l’espace disque sans affecter `http://127.0.0.1:5008/`.

## Ne pas y déplacer

Les fichiers listés dans [CHEMINS_INTERFACE.md](CHEMINS_INTERFACE.md) (`index.html`, `oncv_default_*.dat`, scripts JS, `pseudos_generes/`, etc.).

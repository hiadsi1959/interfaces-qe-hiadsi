# Installation sur un autre PC Linux (avec Quantum ESPRESSO)

Interface **autonome** : une seule API sur le port **5008** sert l’interface web et toutes les fonctions (ld1, APE, ATOMPAW, ONCV, bibliothèques). Aucune dépendance à Interface-QE ni au port 5007.

## Prérequis

| Composant | Obligatoire | Rôle |
|-----------|-------------|------|
| **Linux** (Ubuntu / Debian recommandé) | oui | Environnement cible |
| **Python 3** + `flask`, `flask-cors` | oui | API `api_pseudos_standalone.py` |
| **Quantum ESPRESSO** (`pw.x`, `ld1.x` minimum) | oui pour ld1 | Génération native QE |
| **ONCVPSP** (`oncvpsp.x`) | optionnel | Onglet ONCV |
| **APE** / **ATOMPAW** | optionnel | Onglets correspondants |

## 1. Transférer sur l’autre PC

### Option A — Un seul fichier (recommandé)

Sur le PC source :

```bash
./build_installer.sh
# → dist/generation_pseudos  (≈ 220 Ko, interface + API)
```

Copiez **ce fichier seul** (USB, scp, e-mail…).

Sur le PC cible :

```bash
chmod +x generation_pseudos
./generation_pseudos
# installation permanente dans ~/.local/bin/ :
./generation_pseudos --install
```

L’application s’installe dans `~/.local/share/generation_pseudos/app/` et se configure automatiquement (chemins QE, ONCV, APE, ATOMPAW).

### Option B — Copie du dossier complet

**Guide :** **[TRANSFERT_AUTRE_PC.md](TRANSFERT_AUTRE_PC.md)**

```bash
./TRANSFERER_VERS_AUTRE_PC.sh --leger --dest utilisateur@IP -y
```

Sur le PC cible :

```bash
tar xzf generation_pseudos_*.tar.gz && cd generation_pseudos
./GenerationPseudos
```

## 2. Configurer le nouveau PC

Workflow simple (dossier copié) :

```bash
chmod +x configure.sh DEMARRER.sh
./configure.sh    # une fois
./DEMARRER.sh     # à chaque utilisation
```

`configure.sh` :

1. Vérifie Python et installe Flask si besoin  
2. Détecte `pw.x` / `ld1.x` (Quantum ESPRESSO)  
3. Détecte ONCVPSP, APE, ATOMPAW (optionnels)  
4. Crée les **4 dossiers de sortie** : `pseudos-ld1/`, `pseudos-APE/`, `pseudos-atompaw/`, `pseudos-oncvpsp/`  
5. Met à jour `api_config.json`  
6. Vérifie les fichiers requis par l’interface  

Variantes :

```bash
# Chemins explicites, sans questions
./configure.sh --qe ~/q-e-qe-7.5/bin --pseudos ~/generation_pseudos/pseudos -y

# Configure et démarre en une commande
./configure.sh --start

# Diagnostic seulement
./configure.sh --check-only
```

`config_pc.sh` est un alias de `configure.sh` (rétrocompatibilité).

## 3. Configuration manuelle (`api_config.json`)

```bash
cp api_config.local.json.example api_config.json
# éditer qe_bin, oncvpsp_bin, ape_bin, atompaw_bin, pseudos_dir
```

Variables d’environnement (alternative) :

```bash
export QE_BIN=~/q-e-qe-7.5/bin
export GEN_PORT=5008
export ONCVPSP_BIN=~/oncvpsp/build/bin/oncvpsp.x
./DEMARRER.sh
```

## 4. Utilisation

1. `./DEMARRER.sh`  
2. Ouvrir **http://127.0.0.1:5008/**  
3. Ne **pas** ouvrir `index.html` en `file://`  

Arrêt : `./ARRETER.sh`

## 5. Structure des sauvegardes

| Dossier | Contenu |
|---------|---------|
| `pseudos-ld1/` | UPF générés par ld1.x |
| `pseudos-APE/` | UPF générés par APE |
| `pseudos-atompaw/` | UPF générés par ATOMPAW |
| `pseudos-oncvpsp/` | UPF générés par ONCVPSP |
| `pseudos-telecharges/` | Imports catalogue (PseudoDojo, SSSP, …) |
| `pseudos/` | Bibliothèque commune pour `pw.x` |

Fichiers non conformes QE : `pseudos-*/_non_conforme_QE/`.  
Archives de runs : `pseudos-*/_runs/`.

## 6. Dépannage

| Problème | Action |
|----------|--------|
| Page blanche / pas de CSS | `http://127.0.0.1:5008/`, pas `file://` |
| « API hors ligne » | `lsof -i:5008` puis `./DEMARRER.sh` |
| `ld1.x non trouvé` | `./configure.sh --qe /chemin/qe/bin` |
| ONCV indisponible | `./configure.sh` ou `oncvpsp_bin` dans `api_config.json` |
| Fichiers UI manquants | `./configure.sh --check-only` |

Logs : `logs/api_pseudos_standalone.log`

## Contact

Prof. S. Hiadsi — LMESM, USTO-MB — said.hiadsi@univ-usto.dz

# Chemins requis par l’interface (ne pas déplacer)

L’interface est servie par `api_pseudos_standalone.py` à la **racine du projet** (`_STATIC_ROOT`). Les chemins ci-dessous sont codés en dur dans `index.html`, les scripts JS ou l’API. Les déplacer **casse** le tableau périodique, les gabarits ONCV ou la sauvegarde des UPF.

## Fichiers statiques (racine)

Servis en GET `http://127.0.0.1:5008/<fichier>` :

| Fichier / dossier | Usage |
|-------------------|--------|
| `index.html` | Page principale |
| `pseudo_wizard.html` | Assistant guidé |
| `logo_usto.png` | Logo |
| `utils_dom_safe.js`, `qe_paths_setup.js`, `config_chemins.js` | Utilitaires |
| `script_api_autostart.js`, `script_elements_pseudos.js` | API / éléments |
| `script_tableau_periodique.js` | **Tableau périodique** |
| `script_generateur_ld1.js`, `script_generateur_ape_atompaw.js` | Générateurs |

## Gabarits ONCV (fetch navigateur)

Dans `index.html`, chargement direct par URL relative :

- `oncv_default_<Symbole>.dat` (ex. `oncv_default_Cu.dat`) — fichier ou lien → `data/oncv/`
- `oncv_default_14_Si.dat` (cas Si)
- `oncv_templates_3d/<Symbole>.dat`

→ **Rester à la racine** ou sous `oncv_templates_3d/`, pas dans `archive/` ni `data/`.

## Dossiers de sortie / entrées (API)

| Dossier | Rôle |
|---------|------|
| `pseudos_generes/` | Archive UPF conformes QE (messages UI « Sauvegardé ») |
| `pseudos-oncvpsp/`, `pseudos-ld1/`, `pseudos-APE/`, `pseudos-atompaw/`, `pseudos-telecharges/` | Sorties par générateur |
| `pseudo_generator_templates/ape/`, `…/atompaw/` | Entrées éditées (POST save) |
| `pseudos/` | Bibliothèque catalogue |
| `_work/` | Runs APE/ATOMPAW/ONCV (peut être vidé, pas supprimé) |
| `third_party/ape`, `third_party/atompaw` | Binaires (chemins `api_config.json`) |

## Supprimable sans impact UI

- `archive/` — anciens tests et fichiers déplacés
- `logs/*.log` (sauf en cours d’utilisation)
- `__pycache__/`, `api.pid`, `server.pid`
- Contenu de `_work/*` (sauf pendant un calcul en cours)

## Vérification après nettoyage

```bash
./DEMARRER.sh
python3 verifier_api_generale.py
```

Puis dans le navigateur : `http://127.0.0.1:5008/` — le tableau périodique et l’onglet ONCV doivent répondre sans erreur console.

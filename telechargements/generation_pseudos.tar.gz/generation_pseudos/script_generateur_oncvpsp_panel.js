/**
 * Onglet ONCVPSP (présentation scientifique) + modale générateur complet.
 */
(function () {
    'use strict';

    function esc(s) {
        if (s == null) return '';
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function apiBase() {
        return typeof getApiPseudosBase === 'function' ? getApiPseudosBase() : 'http://127.0.0.1:5008';
    }

    function safeSym(s) {
        return String(s || '').replace(/[^A-Za-z]/g, '').slice(0, 8);
    }

    function _oncvTemplateLooksValid(txt) {
        return !!(txt && txt.indexOf('# ATOM AND REFERENCE') >= 0 && txt.indexOf('psp8') >= 0);
    }

    async function fetchOncvTemplateText(base, symbole, Z) {
        var urls = [
            base + '/api/pseudos/oncv_input_template?element=' + encodeURIComponent(symbole) + '&z=' + Z,
            base + '/api/pseudos/oncv_input_template?element=Si&z=14',
        ];
        var i, r, txt;
        for (i = 0; i < urls.length; i++) {
            try {
                r = await fetch(urls[i], { cache: 'no-store' });
                if (r.ok) {
                    txt = await r.text();
                    if (_oncvTemplateLooksValid(txt)) return txt;
                }
            } catch (e) { /* réseau */ }
        }
        var staticNames = ['oncv_default_' + symbole + '.dat', 'oncv_default_14_Si.dat'];
        for (i = 0; i < staticNames.length; i++) {
            try {
                r = await fetch(new URL(staticNames[i], window.location.href).toString(), { cache: 'no-store' });
                if (r.ok) {
                    txt = await r.text();
                    if (_oncvTemplateLooksValid(txt)) return txt;
                }
            } catch (e) { /* file:// ou 404 */ }
        }
        return '';
    }

    async function fetchOncvStatus() {
        var st = { available: false, path: null, tests_data: null, ld_local_lib: null };
        try {
            var rs = await fetch(apiBase() + '/api/pseudos/oncv_status');
            if (rs.ok) st = await rs.json();
            else if (rs.status === 404) st._routeMissing = true;
        } catch (e) { /* API hors ligne */ }
        return st;
    }

    function oncvStatusHtml(st) {
        if (st._routeMissing) {
            return '<div class="ld1-modal-hint" style="border-color:#fdba74;background:#fff7ed;color:#9a3412;margin-bottom:12px;">'
                + '<strong>API trop ancienne (404 sur <code>/api/pseudos/oncv_status</code>).</strong> '
                + 'Redémarrez l’API : <code>bash scripts/assure_api_qe.sh</code>, puis rechargez la page.'
                + '</div>';
        }
        if (st.available) {
            return '<div class="ld1-modal-hint" style="border-color:#6ee7b7;background:#ecfdf5;color:#065f46;margin-bottom:12px;">'
                + '<strong>oncvpsp.x détecté</strong> : <code style="word-break:break-all;">' + esc(st.path || '') + '</code>'
                + (st.tests_data ? '<br><span style="color:#047857;">tests/data : ' + esc(st.tests_data) + '</span>' : '')
                + '</div>';
        }
        return '<div class="ld1-modal-hint" style="border-color:#fecaca;background:#fef2f2;color:#991b1b;margin-bottom:12px;">'
            + '<strong>Binaire introuvable côté serveur.</strong> Compilez ONCVPSP dans <code>~/oncvpsp/build</code> '
            + 'ou définissez <code>ONCVPSP_BIN</code> / <code>api_config.json</code>, puis redémarrez l’API.'
            + '</div>';
    }

    window.rechargerModeleOncv = async function () {
        var panel = document.getElementById('gen_panel');
        var symbole = panel && panel.getAttribute('data-element');
        var element = symbole && window.ELEMENTS && window.ELEMENTS[symbole];
        if (!symbole) return;
        var Z = (element && element.numero) ? parseInt(element.numero, 10) : 14;
        if (isNaN(Z)) Z = 14;
        var ta = document.getElementById('oncv_input_area_modal') || document.getElementById('oncv_input_area');
        if (!ta) return;
        ta.value = 'Chargement…';
        try {
            var tpl = await fetchOncvTemplateText(apiBase(), symbole, Z);
            if (tpl) {
                ta.value = tpl;
                if (typeof _showToast === 'function') _showToast('Modèle .dat chargé', '#0d9488', 2200);
            } else {
                ta.value = '# Aucun modèle disponible. Vérifiez l’API (tests/data) ou placez oncv_default_' + symbole + '.dat à côté de index.html.\n';
                if (typeof _showToast === 'function') _showToast('Aucun .dat valide', '#ca8a04', 4000);
            }
        } catch (e) {
            ta.value = '# Erreur chargement. Collez un fichier .dat officiel (oncvpsp/tests/data).\n';
            if (typeof _showToast === 'function') _showToast('Erreur réseau', '#dc2626', 2800);
        }
    };

    window.lancerOncvpspDepuisOnglet = async function () {
        var panel = document.getElementById('gen_panel');
        var symbole = (panel && panel.getAttribute('data-element')) || 'X';
        var ta = document.getElementById('oncv_input_area_modal') || document.getElementById('oncv_input_area');
        var out = document.getElementById('oncv_run_output_modal') || document.getElementById('oncv_run_output');
        var btn = document.getElementById('oncv_btn_run_modal') || document.getElementById('oncv_btn_run');
        if (!ta || !out) return;
        var input = (ta.value || '').trim();
        if (!input) {
            out.textContent = 'Saisissez un fichier d’entrée .dat (ou cliquez sur Recharger modèle).';
            return;
        }
        if (btn) { btn.disabled = true; btn.textContent = 'Exécution…'; }
        if (typeof window.renderGeneratorRunResult === 'function') {
            out.innerHTML = '<div class="gen-run-result gen-run-result--loading">Lancement oncvpsp.x côté serveur…</div>';
        } else {
            out.textContent = 'Lancement oncvpsp.x côté serveur…';
        }
        try {
            var r = await fetch(apiBase() + '/api/pseudos/run_oncvpsp', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ input: input, element: symbole }),
            });
            if (r.status === 404) {
                out.innerHTML = '<div class="gen-run-result gen-run-result__box gen-run-result__box--err">Route /api/pseudos/run_oncvpsp absente (404) — redémarrez l’API après mise à jour.</div>';
                return;
            }
            var d = await r.json();
            if (typeof window.renderGeneratorRunResult === 'function') {
                out.innerHTML = window.renderGeneratorRunResult(d, { label: 'ONCVPSP' });
            } else {
                var lines = [];
                lines.push('returncode=' + (d.returncode != null ? d.returncode : '?'));
                if (d.work_dir) lines.push('Répertoire : ' + d.work_dir);
                if (d.upf_path) lines.push('UPF : ' + d.upf_path);
                if (d.output) lines.push('--- stdout ---\n' + d.output);
                if (d.stderr) lines.push('--- stderr ---\n' + d.stderr);
                out.textContent = lines.join('\n');
            }
            if (typeof window.gpRunResultToast === 'function') {
                window.gpRunResultToast(d, 'ONCVPSP');
            } else if (d.success && typeof _showToast === 'function') {
                _showToast(d.upf_path ? 'Terminé — .UPF généré' : 'ONCVPSP terminé — voir sortie', '#16a34a', 4000);
            } else if (typeof _showToast === 'function') {
                _showToast('Erreur de calcul — voir détails', '#dc2626', 5000);
            }
        } catch (e) {
            out.innerHTML = '<div class="gen-run-result gen-run-result__box gen-run-result__box--err">Erreur réseau : ' + esc(e && e.message ? e.message : e) + '</div>';
        } finally {
            if (btn) { btn.disabled = false; btn.textContent = 'Lancer oncvpsp.x'; }
        }
    };

    window.fermerGenerateurONCVPSP = function () {
        var b = document.getElementById('modal_generateur_oncvpsp');
        if (b) b.remove();
    };

    window.ouvrirGenerateurONCVPSPComplet = async function (symbo) {
        if (typeof ensureLd1ModalScienceStyles === 'function') ensureLd1ModalScienceStyles();
        var sym = safeSym(symbo);
        if (!sym) {
            alert('Sélectionnez d’abord un élément dans le tableau de Mendeleïev.');
            return;
        }
        window.fermerGenerateurONCVPSP();

        var elData = window.ELEMENTS && window.ELEMENTS[sym];
        var nom = elData ? String(elData.nom || '').replace(/</g, '&lt;').replace(/&/g, '&amp;') : '';
        var Z = (elData && elData.numero) ? parseInt(elData.numero, 10) : 14;
        if (isNaN(Z)) Z = 14;

        var st = await fetchOncvStatus();
        var tplText = await fetchOncvTemplateText(apiBase(), sym, Z);
        if (!tplText.trim()) {
            tplText = '# Aucun modèle chargé. Collez un .dat valide (ex. depuis oncvpsp/tests/data).\n';
        }

        var backdrop = document.createElement('div');
        backdrop.id = 'modal_generateur_oncvpsp';
        backdrop.className = 'ld1-modal-backdrop';
        backdrop.style.zIndex = '10005';
        backdrop.addEventListener('click', function (ev) {
            if (ev.target === backdrop) window.fermerGenerateurONCVPSP();
        });

        backdrop.innerHTML = ''
            + '<div class="ld1-modal-panel" style="max-width:min(1080px,96vw);max-height:92vh;overflow:auto;" onclick="event.stopPropagation()">'
            + '<h2 class="ld1-modal-title">ONCVPSP'
            + ' <span class="ld1-modal-title-badge">' + sym + '</span>'
            + (nom ? ' <span style="font-weight:500;color:#94a3b8;font-size:0.85em;">— ' + nom + '</span>' : '')
            + '</h2>'
            + '<p class="ld1-modal-sub">Éditez l’entrée <code>.dat</code> puis lancez <code>oncvpsp.x</code> sur le serveur API. '
            + 'Téléchargements PseudoDojo / SG15 : onglet <em>Autres bases</em>.</p>'
            + '<div class="ld1-steps-strip" style="margin-bottom:12px;">'
            + '<span style="color:#86efac;font-weight:600;">① Élément</span> <span style="color:#64748b;">→</span> '
            + '<span style="color:#cbd5e1;">② Modèle .dat</span> <span style="color:#64748b;">→</span> '
            + '<span style="color:#cbd5e1;">③ Édition</span> <span style="color:#64748b;">→</span> '
            + '<span style="color:#fdba74;font-weight:600;">④ oncvpsp.x</span>'
            + '</div>'
            + oncvStatusHtml(st)
            + '<div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:10px;">'
            + '<button type="button" class="btn-action btn-primary-act" id="oncv_btn_run_modal" onclick="lancerOncvpspDepuisOnglet()">Lancer oncvpsp.x</button>'
            + '<button type="button" class="btn-action btn-secondary-act" onclick="rechargerModeleOncv()">Recharger modèle</button>'
            + '<button type="button" class="btn-action btn-secondary-act" onclick="navigator.clipboard.writeText(document.getElementById(\'oncv_input_area_modal\').value).then(function(){if(typeof _showToast===\'function\')_showToast(\'Entrée copiée\',\'#6366f1\',2000);})">Copier l’entrée</button>'
            + '<button type="button" class="btn-action btn-secondary-act" onclick="fermerGenerateurONCVPSP()">Fermer</button>'
            + '</div>'
            + '<label style="display:block;font-size:0.85rem;color:#8ab4ff;margin-bottom:6px;">Entrée <code>.dat</code> pour <strong>' + esc(sym) + '</strong> (Z=' + Z + ')</label>'
            + '<textarea id="oncv_input_area_modal" spellcheck="false" style="width:100%;min-height:280px;font-family:var(--font-mono),JetBrains Mono,monospace;font-size:0.78rem;padding:12px;border-radius:10px;border:2px solid rgba(30,73,118,0.45);background:#0f172a;color:#e2e8f0;"></textarea>'
            + '<div style="margin-top:12px;">'
            + '<div style="color:#94a3b8;font-size:0.8em;margin-bottom:6px;">Résultat de l\'exécution</div>'
            + '<div id="oncv_run_output_modal" class="gen-run-result" style="min-height:48px;">'
            + (st._routeMissing ? 'Routes ONCV absentes (404). Redémarrez l’API.' : (st.available ? 'Prêt. Ajustez l’entrée puis lancez.' : 'Binaire non signalé — lancement possible (erreur 503 si absent).'))
            + '</div></div>'
            + '<p style="font-size:0.72em;color:#94a3b8;margin:10px 0 0 0;">Libxc : <code>~/.local/lib</code> (LD_LIBRARY_PATH enrichi par l’API si présent).</p>'
            + '</div>';

        document.body.appendChild(backdrop);
        var tae = document.getElementById('oncv_input_area_modal');
        if (tae) tae.value = tplText;
    };

    window.ouvrirGenerateurONCVPSP = function (symbole) {
        var el = window.ELEMENTS && window.ELEMENTS[symbole];
        if (!el) return;
        if (typeof switchGenTab === 'function') switchGenTab('oncvpsp', symbole, el);
        if (typeof window.ouvrirGenerateurONCVPSPComplet === 'function') window.ouvrirGenerateurONCVPSPComplet(symbole);
    };

    window.renderTabONCVPSP = function (container, symbole, element) {
        var zLine = 'Z = ' + (element && element.numero ? element.numero : '?');
        if (element && element.nom) zLine += ' · ' + esc(element.nom);
        container.innerHTML = ''
            + '<div class="gen-ld1-tab">'
            + '<div class="gen-ld1-intro" style="border-left-color:#0d9488;">'
            + '<div style="font-size:0.72em;font-family:var(--font-mono);color:#0d9488;font-weight:600;margin-bottom:6px;">ONCVPSP · Optimized Norm-Conserving</div>'
            + '<strong>ONCVPSP</strong> génère des pseudopotentiels norme-conservants optimisés '
            + '(formats <code>psp8</code> ou <code>.UPF</code> selon la sortie). '
            + 'Sortie : <code>pseudos-oncvpsp/</code>. '
            + 'L’exécution se fait sur la machine de l’API, pas dans le navigateur.'
            + '</div>'
            + '<div class="gen-ld1-steps">'
            + '<span>① Identité</span><span>② Modèle .dat</span><span>③ Édition</span><span>④ API oncvpsp.x</span>'
            + '</div>'
            + '<p style="font-size:0.78em;color:#4a5f73;margin:0 0 12px;">' + zLine + '</p>'
            + '<div class="gen-ld1-actions">'
            + '<button type="button" class="btn-action btn-primary-act" onclick="ouvrirGenerateurONCVPSP(\'' + esc(symbole) + '\')">'
            + 'Ouvrir le générateur complet</button>'
            + '<a class="btn-action btn-secondary-act" style="text-decoration:none;" href="https://github.com/oncvpsp/oncvpsp" target="_blank" rel="noopener">Documentation</a>'
            + '</div></div>';
    };
})();

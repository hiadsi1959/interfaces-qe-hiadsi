#!/usr/bin/env bash

# --- Protection HIADSI (anti-modification, usage libre) ---
HIADSI_ROOT="/home/hiadsi/5-Interfaces-hiadsi/generation_pseudos"
if [[ -f "$HIADSI_ROOT/protection_hiadsi.py" ]]; then
  python3 "$HIADSI_ROOT/protection_hiadsi.py" check --root "$HIADSI_ROOT" || exit $?
fi
# --- Fin protection HIADSI ---
exec "$(cd "$(dirname "$0")" && pwd)/scripts/DEMARRER.sh" "$@"

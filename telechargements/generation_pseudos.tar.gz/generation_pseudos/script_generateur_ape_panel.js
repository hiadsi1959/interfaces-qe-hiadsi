/**
 * Onglets APE / ATOMPAW (présentation scientifique) + fonctions gp* pour les modales.
 */
(function () {
    'use strict';

    window.gpAutoCache = window.gpAutoCache || {};

    function apiBase() {
        return typeof getApiPseudosBase === 'function' ? getApiPseudosBase() : 'http://127.0.0.1:5008';
    }

    function esc(s) {
        if (s == null) return '';
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function ensureGenRunResultStyles() {
        if (document.getElementById('gen-run-result-css')) return;
        if (typeof ensureLd1ModalScienceStyles === 'function') ensureLd1ModalScienceStyles();
        var s = document.createElement('style');
        s.id = 'gen-run-result-css';
        s.textContent = ''
            + '.gen-run-result{margin-top:12px;font-size:0.88rem;line-height:1.5;color:#cbd5e1;}'
            + '.gen-run-result--loading{padding:12px 14px;border-radius:10px;background:rgba(30,41,59,0.65);border:1px solid rgba(100,116,139,0.35);}'
            + '.gen-run-result__head{display:flex;align-items:flex-start;gap:12px;margin-bottom:12px;}'
            + '.gen-run-result__icon{font-size:1.6em;line-height:1;}'
            + '.gen-run-result__title{font-weight:600;font-size:1.02em;}'
            + '.gen-run-result__sub{color:#94a3b8;font-size:0.86em;margin-top:4px;}'
            + '.gen-run-result__box{padding:14px 16px;border-radius:10px;margin-top:10px;}'
            + '.gen-run-result__box--ok{background:#1a3a1a;border:1px solid #3fb950;}'
            + '.gen-run-result__box--warn{background:#2a2a1a;border:1px solid #f9e2af;}'
            + '.gen-run-result__box--err{background:#2a1a1a;border:1px solid #f38ba8;}'
            + '.gen-run-result__box--info{background:#1e3a5c;border:1px solid #3b82f6;}'
            + '.gen-run-result__box h4{margin:0 0 8px;font-size:0.95em;font-weight:600;}'
            + '.gen-run-result__paths{font-family:var(--font-mono,JetBrains Mono,monospace);font-size:0.78em;line-height:1.85;word-break:break-all;}'
            + '.gen-run-result__paths dt{color:#6c7086;margin-top:6px;}'
            + '.gen-run-result__paths dd{margin:2px 0 0;color:#e2e8f0;}'
            + '.gen-run-result__actions{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px;}'
            + '.gen-run-result__actions button{font-size:0.72em;padding:4px 10px;}'
            + '.gen-run-result details{margin-top:10px;}'
            + '.gen-run-result details summary{cursor:pointer;color:#89b4fa;font-size:0.86em;}'
            + '.gen-run-result pre{margin:8px 0 0;padding:10px;border-radius:8px;background:#11111b;border:1px solid #45475a;'
            + 'color:#cdd6f4;font-size:0.72em;white-space:pre-wrap;word-break:break-word;max-height:240px;overflow:auto;}';
        document.head.appendChild(s);
    }

    function jsStr(s) {
        return String(s || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    }

    function pathRow(label, value) {
        if (!value) return '';
        return '<dt>' + esc(label) + '</dt><dd>' + esc(value) + '</dd>';
    }

    window.renderGeneratorRunResult = function (j, opts) {
        ensureGenRunResultStyles();
        opts = opts || {};
        var engine = opts.label || (j.generator === 'ape' ? 'APE'
            : j.generator === 'atompaw' ? 'ATOMPAW'
            : j.generator === 'oncvpsp' ? 'ONCVPSP' : 'Générateur');
        var ok = !!j.success;
        var qeOk = !!(j.upf_qe_ready || (j.qe_validation && j.qe_validation.conform_qe));
        var runDone = !!(j.run_completed || j.run_ok || (j.returncode === 0 && !j.error));
        var upfPath = j.upf_path || '';
        var upfName = j.upf_genere || (upfPath ? String(upfPath).split('/').pop() : '');
        var qeFmt = (j.qe_validation && j.qe_validation.format) || '';
        var icon, title, titleColor, boxClass;

        if (ok) {
            icon = '✅';
            title = engine + ' — succès';
            titleColor = '#a6e3a1';
            boxClass = 'gen-run-result__box--ok';
        } else if (runDone && upfPath) {
            icon = '⚠️';
            title = engine + ' — UPF produit (vérification QE)';
            titleColor = '#f9e2af';
            boxClass = 'gen-run-result__box--warn';
        } else if (runDone) {
            icon = '⚠️';
            title = engine + ' — calcul terminé, pas de UPF conforme';
            titleColor = '#f9e2af';
            boxClass = 'gen-run-result__box--warn';
        } else {
            icon = '❌';
            title = engine + ' — échec';
            titleColor = '#f38ba8';
            boxClass = 'gen-run-result__box--err';
        }

        var subParts = [];
        if (j.diagnostic_summary) subParts.push(esc(j.diagnostic_summary));
        else if (j.error) subParts.push(esc(j.error));
        else if (j.fatal_errors && j.fatal_errors.length) subParts.push(esc(j.fatal_errors.join(' · ')));
        if (j.ape_stage) subParts.push('Étape APE : <strong>' + esc(j.ape_stage) + '</strong>');
        if (j.returncode != null) subParts.push('Code retour : <strong>' + esc(j.returncode) + '</strong>');

        var actions = '';
        if (upfPath) {
            actions += '<button type="button" class="btn-action btn-secondary-act" onclick="navigator.clipboard.writeText(\''
                + jsStr(upfPath) + '\').then(function(){if(typeof _showToast===\'function\')_showToast(\'Chemin UPF copié\',\'#6366f1\',2000);})">Copier chemin UPF</button>';
        }
        if (upfName && typeof voirContenuPseudo === 'function') {
            actions += '<button type="button" class="btn-action btn-secondary-act" onclick="voirContenuPseudo(\''
                + jsStr(upfName) + '\')">Aperçu UPF</button>';
        }

        var saveHtml = '';
        if (j.copied_to_pseudos_generes && j.copied_to_pseudos_generes.length) {
            var bucketLabel = j.pseudos_bucket ? String(j.pseudos_bucket).split('/').pop() : 'dossier générateur';
            saveHtml = '<div class="gen-run-result__box gen-run-result__box--info">'
                + '<h4 style="color:#93c5fd;">Sauvegarde — <code>' + esc(bucketLabel) + '</code></h4>'
                + '<dl class="gen-run-result__paths">'
                + pathRow('Dossier', j.pseudos_generes_dir || j.pseudos_bucket)
                + pathRow('Fichier UPF', j.copied_to_pseudos_generes.join(', '))
                + pathRow('Bibliothèque pw.x', j.saved_to_pseudos_dir)
                + '</dl></div>';
        } else if (qeOk && j.saved_to_pseudos_dir) {
            saveHtml = '<div class="gen-run-result__box gen-run-result__box--info">'
                + '<h4 style="color:#93c5fd;">Enregistré dans la bibliothèque</h4>'
                + '<dl class="gen-run-result__paths">' + pathRow('Bibliothèque pw.x', j.saved_to_pseudos_dir) + '</dl></div>';
        } else if (runDone && upfPath && !qeOk) {
            saveHtml = '<p style="color:#f38ba8;font-size:0.82em;margin:8px 0 0;">UPF non conforme QE — non archivé automatiquement.</p>';
        }

        var warnHtml = '';
        var warns = [].concat(j.warnings || [], j.note ? [j.note] : []);
        if (warns.length) {
            warnHtml = '<div style="margin-top:10px;padding:10px 12px;border-radius:8px;background:rgba(42,32,16,0.55);border:1px solid #f9e2af;">'
                + '<div style="color:#f9e2af;font-weight:600;font-size:0.84em;margin-bottom:4px;">Avertissements</div>'
                + '<ul style="margin:0;padding-left:18px;color:#e2e8f0;font-size:0.82em;">'
                + warns.map(function (w) { return '<li>' + esc(w) + '</li>'; }).join('')
                + '</ul></div>';
        }

        var hintHtml = '';
        if (j.hint) {
            hintHtml = '<p style="margin:10px 0 0;padding:10px 12px;border-radius:8px;background:rgba(30,58,95,0.45);'
                + 'border:1px solid rgba(59,130,246,0.35);color:#93c5fd;font-size:0.82em;">'
                + '<strong>Conseil :</strong> ' + esc(j.hint) + '</p>';
        }

        var oncvFlags = '';
        if (j.generator === 'oncvpsp') {
            var flags = [];
            if (j.upf_in_stdout) flags.push('UPF (XML) détecté dans stdout');
            if (j.psp8_in_stdout) flags.push('Format psp8 dans stdout');
            if (j.psfile_used) flags.push('psfile : ' + j.psfile_used);
            if (flags.length) {
                oncvFlags = '<p style="color:#6c7086;font-size:0.8em;margin:6px 0 0;">' + esc(flags.join(' · ')) + '</p>';
            }
        }

        var files = j.files_in_workdir || j.files_in_tmp || [];
        var filesHtml = '';
        if (files.length) {
            var fileLines = files.slice(0, 12).map(function (f) {
                var nm = f.name || f;
                var p = f.path || '';
                var sz = f.size != null ? ' (' + f.size + ' o)' : '';
                return esc(nm + sz + (p ? ' → ' + p : ''));
            }).join('\n');
            if (files.length > 12) fileLines += '\n… +' + (files.length - 12) + ' fichier(s)';
            filesHtml = '<details><summary>Fichiers dans le répertoire de travail (' + files.length + ')</summary>'
                + '<pre>' + esc(fileLines) + '</pre></details>';
        }

        var logText = '';
        if (j.output && j.stderr) logText = String(j.output) + '\n--- stderr ---\n' + String(j.stderr);
        else logText = String(j.output || j.stderr || j.log || '').trim();
        var logHtml = logText
            ? '<details><summary>Journal d\'exécution (stdout / stderr)</summary><pre>' + esc(logText) + '</pre></details>'
            : '';

        return ''
            + '<div class="gen-run-result">'
            + '<div class="gen-run-result__head">'
            + '<div class="gen-run-result__icon">' + icon + '</div>'
            + '<div><div class="gen-run-result__title" style="color:' + titleColor + ';">' + esc(title) + '</div>'
            + (subParts.length ? '<div class="gen-run-result__sub">' + subParts.join(' · ') + '</div>' : '')
            + '</div></div>'
            + '<div class="gen-run-result__box ' + boxClass + '">'
            + '<h4 style="color:' + titleColor + ';">Fichier UPF</h4>'
            + '<dl class="gen-run-result__paths">'
            + pathRow('Nom', upfName || '(non détecté)')
            + pathRow('Chemin complet', upfPath || '(voir journal ci-dessous)')
            + (qeFmt ? pathRow('Format QE', qeFmt) : '')
            + pathRow('Répertoire de travail', j.work_dir)
            + pathRow('Entrée', j.input_file)
            + pathRow('Journal', j.log_file || j.output_file)
            + '</dl>'
            + oncvFlags
            + (actions ? '<div class="gen-run-result__actions">' + actions + '</div>' : '')
            + '</div>'
            + saveHtml
            + warnHtml
            + hintHtml
            + filesHtml
            + logHtml
            + '</div>';
    };

    window.gpRunResultToast = function (j, label) {
        if (typeof _showToast !== 'function') return;
        var short = j.upf_genere || (j.upf_path ? String(j.upf_path).split('/').pop() : '');
        if (j.success && short) {
            _showToast(label + ' — ' + short, '#059669', 4500);
        } else if (j.run_completed && (j.hint || !j.success)) {
            _showToast(label + ' — voir détails ci-dessous', '#ca8a04', 4500);
        } else if (j.success) {
            _showToast(label + ' terminé', '#059669', 3000);
        } else {
            var err = (j.fatal_errors && j.fatal_errors[0]) || j.error || j.diagnostic_summary || 'échec';
            _showToast(label + ' : ' + String(err).slice(0, 100), '#dc2626', 5500);
        }
    };

    function safeSym(s) {
        return String(s || '').replace(/[^A-Za-z]/g, '').slice(0, 8);
    }

    function apeTextarea() {
        return document.getElementById('gp_ape_input_modal') || document.getElementById('gp_ape_input');
    }

    function atompawTextarea() {
        return document.getElementById('gp_atompaw_input_modal') || document.getElementById('gp_atompaw_input');
    }

    window.gpGetAtompawFormatEl = function () {
        return document.getElementById('gp_atompaw_format_modal') || document.getElementById('gp_atompaw_format');
    };

    window.gpApplyAtompawFormatFromCache = function (sym) {
        sym = safeSym(sym);
        var c = window.gpAutoCache && window.gpAutoCache[sym];
        if (!c || !c.atompaw) return;
        window.gpApplyAutoInputs(sym, 'atompaw', c.atompaw);
    };

    window.gpInvalidateAutoInputsCacheForSym = function (sym) {
        if (window.gpAutoCache) delete window.gpAutoCache[sym];
    };

    window.gpFetchAutoInputs = async function (sym, engine, force) {
        sym = safeSym(sym);
        engine = engine || 'ape';
        if (!force && window.gpAutoCache[sym] && window.gpAutoCache[sym][engine]) {
            window.gpApplyAutoInputs(sym, engine, window.gpAutoCache[sym][engine]);
            return;
        }
        try {
            var url = apiBase() + '/api/pseudos/auto_inputs?element=' + encodeURIComponent(sym) + '&engine=' + encodeURIComponent(engine);
            var r = await fetch(url, { cache: 'no-store' });
            var j = await r.json();
            if (!r.ok) throw new Error(j.error || 'HTTP ' + r.status);
            if (!window.gpAutoCache[sym]) window.gpAutoCache[sym] = {};
            window.gpAutoCache[sym][engine] = j;
            window.gpApplyAutoInputs(sym, engine, j);
        } catch (e) {
            var ta = engine === 'atompaw' ? atompawTextarea() : apeTextarea();
            if (ta) ta.value = '# Erreur chargement gabarit : ' + (e.message || e) + '\n';
        }
    };

    window.gpApplyAutoInputs = function (sym, engine, data) {
        var input = '';
        var summary = data.summary || data.hint || data.note || '';
        if (engine === 'ape') {
            input = data.ape_input || data.input || data.content || data.template || '';
        } else if (engine === 'atompaw') {
            var fmtEl = window.gpGetAtompawFormatEl();
            var fmt = fmtEl ? fmtEl.value : 'interactive';
            input = (fmt === 'qe_file' ? (data.atompaw_input_qe || data.atompaw_input) : data.atompaw_input)
                || data.input || data.content || data.template || '';
        } else {
            input = data.input || data.content || data.template || '';
        }
        if (engine === 'ape') {
            var ta = apeTextarea();
            var su = document.getElementById('gp_ape_auto_summary_modal') || document.getElementById('gp_ape_auto_summary');
            var sm = document.getElementById('gp_ape_auto_summary_modal');
            if (ta && input) ta.value = input;
            if (su && summary) su.innerHTML = summary;
            if (sm && summary) sm.innerHTML = summary;
            var bdm = document.getElementById('gp_ape_breakdown_body_modal');
            if (data.input_breakdown && bdm) {
                bdm.innerHTML = '<pre style="font-size:0.75em;white-space:pre-wrap;">' + esc(JSON.stringify(data.input_breakdown, null, 2)) + '</pre>';
            }
        } else {
            var ta2 = atompawTextarea();
            var su2 = document.getElementById('gp_atompaw_auto_summary_modal') || document.getElementById('gp_atompaw_auto_summary');
            var sm2 = document.getElementById('gp_atompaw_auto_summary_modal');
            if (ta2 && input) ta2.value = input;
            if (su2 && summary) su2.innerHTML = summary;
            if (sm2 && summary) sm2.innerHTML = summary;
        }
    };

    window.gpRefreshApeStatus = async function () {
        var el = document.getElementById('gp_ape_status_line_modal') || document.getElementById('gp_ape_status_line');
        if (!el) return;
        try {
            var r = await fetch(apiBase() + '/api/pseudos/ape_status', { cache: 'no-store' });
            var j = await r.json();
            var ok = j.available || j.installed;
            el.innerHTML = ok
                ? 'APE détecté : <code>' + esc(j.path || j.bin || 'ape') + '</code>'
                : 'APE non trouvé — <code>./install_ape_atompaw.sh</code>';
            el.style.color = ok ? '#059669' : '#b45309';
        } catch (e) {
            el.textContent = 'Statut APE indisponible (API hors ligne)';
            el.style.color = '#94a3b8';
        }
    };

    window.gpRefreshAtompawStatus = async function () {
        var el = document.getElementById('gp_atompaw_status_line_modal') || document.getElementById('gp_atompaw_status_line');
        if (!el) return;
        try {
            var r = await fetch(apiBase() + '/api/pseudos/atompaw_status', { cache: 'no-store' });
            var j = await r.json();
            var ok = j.available || j.installed;
            el.innerHTML = ok
                ? 'ATOMPAW détecté : <code>' + esc(j.path || j.bin || 'atompaw') + '</code>'
                : 'ATOMPAW non trouvé — <code>./install_ape_atompaw.sh</code>';
            el.style.color = ok ? '#059669' : '#b45309';
        } catch (e) {
            el.textContent = 'Statut ATOMPAW indisponible (API hors ligne)';
            el.style.color = '#94a3b8';
        }
    };

    window.gpRunApe = async function (sym) {
        sym = safeSym(sym) || 'X';
        var ta = typeof window.gpGetApeTextarea === 'function' ? window.gpGetApeTextarea() : apeTextarea();
        var out = typeof window.gpGetApeOutputEl === 'function' ? window.gpGetApeOutputEl() : document.getElementById('gp_ape_output_modal');
        var input = ta ? String(ta.value || '').trim() : '';
        if (!input) {
            alert('Zone inp.ape vide — cliquez « Rafraîchir gabarit ».');
            return;
        }
        if (out) out.innerHTML = '<div class="gen-run-result gen-run-result--loading">Exécution APE en cours…</div>';
        ensureGenRunResultStyles();
        var reuse = document.getElementById('gp_ape_reuse_workdir_modal') || document.getElementById('gp_ape_reuse_workdir');
        var body = { element: sym, input: input };
        if (reuse && reuse.checked) body.continue_dir = true;
        try {
            var r = await fetch(apiBase() + '/api/pseudos/run_ape', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });
            var j = await r.json();
            if (out) {
                out.innerHTML = typeof window.renderGeneratorRunResult === 'function'
                    ? window.renderGeneratorRunResult(j, { label: 'APE' })
                    : '<pre>' + esc(j.output || j.error || JSON.stringify(j, null, 2)) + '</pre>';
            }
            window.gpRunResultToast(j, 'APE');
        } catch (e) {
            if (out) out.innerHTML = '<div class="gen-run-result gen-run-result__box gen-run-result__box--err">Erreur réseau : ' + esc(e.message || e) + '</div>';
        }
    };

    window.gpRunAtompaw = async function (sym) {
        sym = safeSym(sym) || 'X';
        var ta = typeof window.gpGetAtompawTextarea === 'function' ? window.gpGetAtompawTextarea() : atompawTextarea();
        var out = typeof window.gpGetAtompawOutputEl === 'function' ? window.gpGetAtompawOutputEl() : document.getElementById('gp_atompaw_output_modal');
        var input = ta ? String(ta.value || '').trim() : '';
        if (!input) {
            alert('stdin ATOMPAW vide — cliquez « Rafraîchir gabarit ».');
            return;
        }
        if (out) out.innerHTML = '<div class="gen-run-result gen-run-result--loading">Exécution ATOMPAW en cours…</div>';
        ensureGenRunResultStyles();
        var reuse = document.getElementById('gp_atompaw_reuse_workdir_modal') || document.getElementById('gp_atompaw_reuse_workdir');
        var fmt = window.gpGetAtompawFormatEl();
        var body = { element: sym, input: input, format: fmt ? fmt.value : 'interactive' };
        if (reuse && reuse.checked) body.continue_dir = true;
        try {
            var r = await fetch(apiBase() + '/api/pseudos/run_atompaw', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });
            var j = await r.json();
            if (out) {
                out.innerHTML = typeof window.renderGeneratorRunResult === 'function'
                    ? window.renderGeneratorRunResult(j, { label: 'ATOMPAW' })
                    : '<pre>' + esc(j.output || j.error || JSON.stringify(j, null, 2)) + '</pre>';
            }
            window.gpRunResultToast(j, 'ATOMPAW');
        } catch (e) {
            if (out) out.innerHTML = '<div class="gen-run-result gen-run-result__box gen-run-result__box--err">Erreur réseau : ' + esc(e.message || e) + '</div>';
        }
    };

    window.gpLoadApePreset = function (preset) {
        var ta = apeTextarea();
        if (!ta) return;
        fetch(apiBase() + '/api/pseudos/auto_inputs?preset=' + encodeURIComponent(preset || 'li_ae'), { cache: 'no-store' })
            .then(function (r) { return r.json(); })
            .then(function (j) {
                if (j.input) ta.value = j.input;
            })
            .catch(function () {});
    };

    window.gpLoadAtompawTemplate = function () {
        var sym = (document.getElementById('gen_panel') && document.getElementById('gen_panel').getAttribute('data-element')) || 'Si';
        window.gpFetchAutoInputs(sym, 'atompaw', true);
    };

    function renderSciTab(container, opts) {
        var symbole = opts.symbole;
        var zLine = 'Z = ' + (opts.z || '?');
        if (opts.nom) zLine += ' · ' + esc(opts.nom);
        container.innerHTML = ''
            + '<div class="gen-ld1-tab">'
            + '<div class="gen-ld1-intro" style="border-left-color:' + opts.accent + ';">'
            + '<div style="font-size:0.72em;font-family:var(--font-mono);color:' + opts.accent + ';font-weight:600;margin-bottom:6px;">' + esc(opts.label) + '</div>'
            + opts.intro
            + '</div>'
            + '<div class="gen-ld1-steps">'
            + opts.steps
            + '</div>'
            + '<p style="font-size:0.78em;color:#4a5f73;margin:0 0 12px;">' + zLine + '</p>'
            + '<div class="gen-ld1-actions">'
            + '<button type="button" class="btn-action btn-primary-act" onclick="' + opts.openFn + '(\'' + esc(symbole) + '\')">'
            + 'Ouvrir le générateur complet</button>'
            + (opts.docUrl
                ? '<a class="btn-action btn-secondary-act" style="text-decoration:none;" href="' + opts.docUrl + '" target="_blank" rel="noopener">Documentation</a>'
                : '')
            + '</div></div>';
    }

    window.ouvrirGenerateurAPE = function (symbole) {
        var el = window.ELEMENTS && window.ELEMENTS[symbole];
        if (!el) return;
        if (typeof switchGenTab === 'function') switchGenTab('ape', symbole, el);
        if (typeof window.ouvrirGenerateurAPEComplet === 'function') window.ouvrirGenerateurAPEComplet(symbole);
    };

    window.ouvrirGenerateurATOMPAW = function (symbole) {
        var el = window.ELEMENTS && window.ELEMENTS[symbole];
        if (!el) return;
        if (typeof switchGenTab === 'function') switchGenTab('atompaw', symbole, el);
        if (typeof window.ouvrirGenerateurATOMPAWComplet === 'function') window.ouvrirGenerateurATOMPAWComplet(symbole);
    };

    window.renderTabAPE = function (container, symbole, element) {
        renderSciTab(container, {
            symbole: symbole,
            z: element && element.numero,
            nom: element && element.nom,
            label: 'APE · Atomic Pseudopotential Engine',
            accent: '#5b21b6',
            intro: '<strong>APE</strong> produit des pseudopotentiels <strong>norme-conservants (NC)</strong> '
                + 'au format <code>.UPF</code> pour Quantum ESPRESSO. '
                + 'Sortie : <code>pseudos-APE/</code>. '
                + 'Éléments 3d / 4f : souvent préférer <strong>ATOMPAW</strong> ou une bibliothèque externe.',
            steps: '<span>① Identité</span><span>② Paramètres XC</span><span>③ inp.ape</span><span>④ API APE</span>',
            openFn: 'ouvrirGenerateurAPE',
            docUrl: 'https://wiki.fysik.dtu.dk/ape/',
        });
    };

    window.renderTabAtompaw = function (container, symbole, element) {
        renderSciTab(container, {
            symbole: symbole,
            z: element && element.numero,
            nom: element && element.nom,
            label: 'ATOMPAW · Projector Augmented Wave',
            accent: '#9d174d',
            intro: '<strong>ATOMPAW</strong> génère des jeux <strong>PAW</strong> convertibles en <code>.UPF</code>. '
                + 'Sortie : <code>pseudos-atompaw/</code>. '
                + 'Recommandé pour métaux de transition, éléments lourds et calculs exigeant la précision PAW.',
            steps: '<span>① Identité</span><span>② Format / XC</span><span>③ stdin</span><span>④ API ATOMPAW</span>',
            openFn: 'ouvrirGenerateurATOMPAW',
            docUrl: 'https://users.wfu.edu/natalieb3/atompaw/',
        });
    };
})();

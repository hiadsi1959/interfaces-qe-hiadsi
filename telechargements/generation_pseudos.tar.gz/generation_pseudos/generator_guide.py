# -*- coding: utf-8 -*-
"""
Guide par onglet générateur — fiabilité QE selon la famille d'éléments (pas « tout ou rien »).
"""

from __future__ import annotations

from typing import Any

try:
    from pseudo_auto_inputs import normalize_symbol, atomic_number, qe_route_hint
    from pseudo_auto_inputs import _TRANSITION_3D
except ImportError:
    _TRANSITION_3D = frozenset()

    def normalize_symbol(s: str) -> str:
        s = (s or "").strip()
        return s.upper() if len(s) == 1 else s[0].upper() + s[1:].lower()

    def atomic_number(sym: str) -> int:
        return 0

    def qe_route_hint(sym: str) -> dict[str, Any]:
        return {"message": ""}


def _is_lanthanide(sym: str) -> bool:
    try:
        import lanthanide_nc as lnc

        return lnc.is_lanthanide(sym)
    except ImportError:
        return sym in {
            "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy",
            "Ho", "Er", "Tm", "Yb", "Lu",
        }


# Quatre dossiers de sortie — un par générateur local (racine du projet)
OUTPUT_DIR_BY_GENERATOR: dict[str, str] = {
    "oncvpsp": "pseudos-oncvpsp",
    "oncv": "pseudos-oncvpsp",
    "ape": "pseudos-APE",
    "atompaw": "pseudos-atompaw",
    "ld1": "pseudos-ld1",
    "ld1.x": "pseudos-ld1",
    "ld1x": "pseudos-ld1",
    "bibliotheque": "pseudos-telecharges",
    "telechargement": "pseudos-telecharges",
    "pseudodojo": "pseudos-telecharges",
    "pslibrary": "pseudos-telecharges",
    "sssp": "pseudos-telecharges",
    "unknown": "pseudos_generes",
}

# Les 4 générateurs locaux (ordre d’affichage UI / scripts)
GENERATOR_OUTPUT_DIRS: list[str] = [
    "pseudos-ld1",
    "pseudos-APE",
    "pseudos-atompaw",
    "pseudos-oncvpsp",
]

GENERATOR_OUTPUT_LABELS: dict[str, str] = {
    "pseudos-ld1": "ld1.x (Quantum ESPRESSO)",
    "pseudos-APE": "APE",
    "pseudos-atompaw": "ATOMPAW",
    "pseudos-oncvpsp": "ONCVPSP",
}

TAB_META: dict[str, dict[str, str]] = {
    "ld1x": {
        "title": "ld1.x (Quantum ESPRESSO)",
        "role": "Génération locale NC / USPP / PAW → UPF pour pw.x",
    },
    "atompaw": {
        "title": "ATOMPAW",
        "role": "PAW → UPF QE ; recommandé pour métaux 3d et calculs précis",
    },
    "ape": {
        "title": "APE (Atomic Pseudopotential Engine)",
        "role": "NC uniquement — excellente précision, domaine strict (voir capacités)",
    },
    "oncvpsp": {
        "title": "ONCVPSP",
        "role": "NC optimisé → UPF (psfile=both) ; modèle .dat requis par élément",
    },
    "pseudodojo": {
        "title": "PseudoDojo",
        "role": "Bibliothèque ONCV déjà validée — import UPF (pas de génération locale)",
    },
    "pslibrary": {
        "title": "PSLibrary",
        "role": "Bibliothèque QE (NC / USPP / PAW) — import UPF",
    },
    "sssp": {
        "title": "SSSP",
        "role": "Jeux curatés Materials Cloud — import UPF",
    },
}


APE_CAPABILITIES: list[str] = [
    "Pseudopotentiels à norme conservée (Norm-Conserving, NC) uniquement — pas de PAW ni USPP.",
    "Schémas Troullier-Martins et Hamann.",
    "Relativité : non-relativiste, scalaire-relativiste, et pleinement relativiste (fully relativistic, couplage spin-orbite dans QE).",
    "Corrections de cœur non-linéaires (NLCC).",
    "États de semi-cœur (semi-core states).",
    "Sortie Quantum ESPRESSO : PPOutputFileFormat = upf (interface).",
]

APE_ALTERNATIVES_DEFAULT: list[dict[str, str]] = [
    {"tab": "atompaw", "label": "ATOMPAW (PAW → UPF QE)", "reason": "Robuste pour 3d, 4f et structures exigeantes."},
    {"tab": "oncvpsp", "label": "ONCVPSP (NC optimisé)", "reason": "Gabarit .dat + psfile=both → UPF pw.x."},
    {"tab": "pseudodojo", "label": "PseudoDojo", "reason": "UPF ONCV déjà validés (import)."},
    {"tab": "pslibrary", "label": "PSLibrary", "reason": "Jeux QE officiels NC / USPP / PAW."},
]


def ape_feasibility(sym: str | None) -> str:
    """
    Niveau a priori pour APE sur un élément.
    recommended | caution | blocked
    """
    if not sym:
        return "caution"
    sym_n = normalize_symbol(sym)
    route = qe_route_hint(sym_n)
    if route.get("ape_nc") == "difficile":
        return "blocked"
    z = atomic_number(sym_n)
    if sym_n in _TRANSITION_3D or (sym_n and _is_lanthanide(sym_n)) or (z and z >= 39):
        return "caution" if sym_n not in _TRANSITION_3D and not _is_lanthanide(sym_n) else "blocked"
    return "recommended"


def ape_alternatives(sym: str | None) -> list[dict[str, str]]:
    sym_n = normalize_symbol(sym) if sym else None
    route = qe_route_hint(sym_n) if sym_n else {}
    order = route.get("recommended_generators") or ["atompaw", "oncvpsp", "pseudodojo"]
    tab_labels = {
        "atompaw": "ATOMPAW (PAW → UPF QE)",
        "oncvpsp": "ONCVPSP (NC, psfile=both)",
        "pseudodojo": "PseudoDojo (import UPF)",
        "pslibrary": "PSLibrary (import UPF)",
        "ld1": "ld1.x (QE, US/PAW si NC échoue)",
    }
    out: list[dict[str, str]] = []
    for g in order:
        if g == "ape":
            continue
        tab = "ld1x" if g in ("ld1", "ld1.x") else g
        out.append({
            "tab": tab,
            "label": tab_labels.get(g, g),
            "reason": route.get("message", "")[:120] if g == order[0] else "",
        })
    if not out:
        return list(APE_ALTERNATIVES_DEFAULT)
    return out[:4]


ATOMPAW_CAPABILITIES: list[str] = [
    "Pseudopotentiels PAW (Projector Augmented Wave) — précision proche du tout-électron.",
    "Sortie UPF Quantum ESPRESSO via option PWSCFOUT (pas de conversion paw_generate).",
    "Recommandé pour métaux 3d, lanthanides et calculs exigeants.",
    "Réglage des rayons rc(Vloc), projecteurs et semi-cœur.",
]

ONCV_CAPABILITIES: list[str] = [
    "Pseudopotentiels NC optimisés (ONCVPSP) — très utilisés (PseudoDojo, SSSP).",
    "Cible Quantum ESPRESSO : psfile=both ou upf dans le .dat → UPF XML dans stdout.",
    "Gabarit .dat obligatoire par élément (génération locale 3d / lanthanides).",
    "Alternative ABINIT : psfile=psp8.",
]

QE_STATUS_LEGEND: dict[str, str] = {
    "conform_qe": "Vert — UPF conforme Quantum ESPRESSO (pw.x).",
    "non_conforme": (
        "Jaune — non conforme Quantum ESPRESSO (pw.x) ; "
        "un autre format (ex. ABINIT psp8) peut être mentionné s’il est détecté."
    ),
    "cannot_generate": "Rouge — génération impossible ou déconseillée ; autre générateur.",
}

_HARD_FAIL_PATTERNS = (
    "malloc", "sigabrt", "multiroot", "unbound", "fatal error",
    "interrompu", "gsl", "crash", "program will stop", "test_data",
    "upf file not created", "mpi_abort",
)


def generator_alternatives(generator: str, sym: str | None) -> list[dict[str, str]]:
    gen = (generator or "").strip().lower()
    if gen == "ape":
        return ape_alternatives(sym)
    sym_n = normalize_symbol(sym) if sym else None
    route = qe_route_hint(sym_n) if sym_n else {}
    if gen == "atompaw":
        order = ["pseudodojo", "oncvpsp", "pslibrary", "ape"]
    elif gen in ("oncvpsp", "oncv"):
        order = [g for g in (route.get("recommended_generators") or []) if g != "oncvpsp"]
        order += ["pseudodojo", "atompaw", "pslibrary"]
    else:
        order = ["pseudodojo", "pslibrary", "atompaw", "oncvpsp"]
    labels = {
        "atompaw": "ATOMPAW (PAW → UPF QE)",
        "oncvpsp": "ONCVPSP (NC, psfile=both)",
        "pseudodojo": "PseudoDojo (import UPF)",
        "pslibrary": "PSLibrary (import UPF)",
        "ape": "APE (NC, éléments légers)",
        "ld1": "ld1.x (QE)",
    }
    seen: set[str] = set()
    out: list[dict[str, str]] = []
    for g in order:
        if g == gen:
            continue
        tab = "ld1x" if g in ("ld1", "ld1.x") else g
        if tab in seen or tab == gen:
            continue
        seen.add(tab)
        out.append({"tab": tab, "label": labels.get(g, g), "reason": ""})
        if len(out) >= 4:
            break
    return out


def detect_pseudo_formats_from_text(text: str | None) -> dict[str, Any]:
    """
    Détecte conformité QE et formats utiles pour d'autres codes (ABINIT, etc.).
    """
    import re as _re

    out: dict[str, Any] = {
        "conform_qe": False,
        "qe_format": None,
        "other_codes": [],
    }
    if not text:
        return out
    if len(text) < 24 and "Begin PSPCODE8" not in text and "Begin PSP_UPF" not in text:
        return out
    raw = text
    other: list[dict[str, str]] = []

    has_v2 = bool(_re.search(r"<UPF\s+version", raw, _re.IGNORECASE))
    has_v1 = "Begin PSP_UPF" in raw and "End PSP_UPF" in raw
    has_ape = "<PP_HEADER>" in raw and "<PP_INFO>" in raw and (
        "<PP_MESH>" in raw or "<PP_RHOATOM>" in raw
    )
    if has_v2 and ("</UPF>" in raw or "<PP_HEADER" in raw):
        out["conform_qe"] = True
        out["qe_format"] = "UPF v2 (XML) — Quantum ESPRESSO"
    elif has_ape:
        out["conform_qe"] = True
        out["qe_format"] = "UPF APE (PP_HEADER) — Quantum ESPRESSO"
    elif has_v1:
        out["conform_qe"] = True
        out["qe_format"] = "UPF v1 (PSP_UPF) — Quantum ESPRESSO"
    elif "Begin PSP_UPF" in raw:
        other.append({
            "code": "qe_partial",
            "label": "Quantum ESPRESSO",
            "format": "UPF v1 incomplet (End PSP_UPF manquant)",
        })

    if "Begin PSPCODE8" in raw or _re.search(r"PSPCODE\s*8", raw, _re.IGNORECASE):
        other.append({
            "code": "abinit",
            "label": "ABINIT",
            "format": "psp8 (PSPCODE8)",
        })
    if _re.search(r"\.psp8\b", raw, _re.IGNORECASE) and not any(c["code"] == "abinit" for c in other):
        other.append({
            "code": "abinit",
            "label": "ABINIT",
            "format": "fichier .psp8",
        })
    if _re.search(r"<paw_pseudo", raw, _re.IGNORECASE) or "PAW dataset" in raw:
        other.append({
            "code": "abinit_paw",
            "label": "ABINIT (PAW XML)",
            "format": "XML PAW",
        })
    if _re.search(r"FHI|fhi99|fhi pp", raw, _re.IGNORECASE):
        other.append({
            "code": "fhi",
            "label": "FHI-aims / format FHI",
            "format": "FHI",
        })

    # Dédupliquer par code
    seen: set[str] = set()
    uniq: list[dict[str, str]] = []
    for c in other:
        if c["code"] in seen:
            continue
        seen.add(c["code"])
        uniq.append(c)
    out["other_codes"] = uniq
    return out


def format_other_codes_note(other_codes: list[dict[str, str]] | None) -> str:
    """Phrase pour l'UI : non conforme QE mais OK pour un autre code."""
    if not other_codes:
        return ""
    parts = [
        f"utilisable pour {c['label']} ({c['format']})"
        for c in other_codes
        if c.get("code") != "qe_partial"
    ]
    if not parts:
        return ""
    return (
        "Non conforme Quantum ESPRESSO (pw.x), mais "
        + " ; ".join(parts)
        + "."
    )


def _generator_capabilities(generator: str) -> list[str]:
    g = (generator or "").strip().lower()
    if g == "ape":
        return APE_CAPABILITIES
    if g == "atompaw":
        return ATOMPAW_CAPABILITIES
    if g in ("oncvpsp", "oncv"):
        return ONCV_CAPABILITIES
    return []


def classify_qe_status(
    generator: str,
    *,
    upf_qe_ready: bool,
    upf_found: bool,
    run_completed: bool,
    returncode: int | None,
    fatal_errors: list[str] | None,
    element: str | None = None,
    other_codes: list[dict[str, str]] | None = None,
) -> dict[str, Any]:
    """
    Trois niveaux UI : conform_qe | non_conforme | cannot_generate
    """
    gen = (generator or "ape").strip().lower()
    fatal = list(fatal_errors or [])
    rc = 0 if returncode is None else int(returncode)
    alts = generator_alternatives(gen, element)
    feasibility = ape_feasibility(element) if gen == "ape" else "recommended"

    hard_fail = rc != 0
    if fatal:
        hard_fail = hard_fail or any(
            any(p in f.lower() for p in _HARD_FAIL_PATTERNS) for f in fatal
        )

    gen_titles = {
        "ape": "APE",
        "atompaw": "ATOMPAW",
        "oncvpsp": "ONCVPSP",
        "oncv": "ONCVPSP",
    }
    gtitle = gen_titles.get(gen, gen.upper())

    if upf_qe_ready:
        return {
            "level": "conform_qe",
            "label": f"{gtitle} — conforme Quantum ESPRESSO",
            "color": "green",
            "short": "UPF validé pour pw.x — sauvegardé dans la bibliothèque.",
            "alternatives": [],
            "feasibility": feasibility,
            "generator": gen,
        }

    blocked_ape = gen == "ape" and feasibility == "blocked" and not upf_found
    if hard_fail or blocked_ape:
        shorts = {
            "ape": "APE NC ne produit pas d'UPF QE fiable — changez de générateur.",
            "atompaw": "ATOMPAW n'a pas produit d'UPF QE — vérifiez PWSCFOUT, rc(Vloc) et le log.",
            "oncvpsp": "ONCVPSP a échoué — régénérez le .dat, psfile=both, ou importez PseudoDojo.",
        }
        return {
            "level": "cannot_generate",
            "label": f"{gtitle} — génération impossible",
            "color": "red",
            "short": fatal[0] if fatal else shorts.get(gen, "Pas d'UPF QE — autre générateur recommandé."),
            "alternatives": alts,
            "feasibility": feasibility,
            "generator": gen,
        }

    partial_shorts = {
        "ape": (
            "Calcul terminé (code 0) sans fichier utilisable par pw.x — réutilisez le dossier (ae→pp) ou ajustez r_c."
            if run_completed and rc == 0 else "Échec partiel APE — voir le journal."
        ),
        "atompaw": (
            "Code 0 sans pseudo conforme pw.x — queue PWSCFOUT + END, rc(Vloc), semi-cœur."
            if run_completed and rc == 0 else "Échec partiel ATOMPAW — voir le journal."
        ),
        "oncvpsp": (
            "ONCV terminé sans UPF pour pw.x — psfile=both, extraction stdout, ou .dat incohérent."
            if run_completed and rc == 0 else "Échec partiel ONCV — voir oncv_*.out."
        ),
    }
    short = partial_shorts.get(gen, "Pas de pseudo utilisable par pw.x.")
    other_note = format_other_codes_note(other_codes)
    if other_note:
        short = other_note
    elif upf_found and not upf_qe_ready:
        short = (
            "Non conforme Quantum ESPRESSO (pw.x) — fichier produit mais rejeté par la validation UPF."
        )
    return {
        "level": "non_conforme",
        "label": f"{gtitle} — non conforme Quantum ESPRESSO",
        "color": "yellow",
        "short": short,
        "other_codes": other_codes or [],
        "alternatives": alts[:3],
        "feasibility": feasibility,
        "generator": gen,
    }


def classify_ape_qe_status(
    *,
    upf_qe_ready: bool,
    upf_found: bool,
    run_completed: bool,
    returncode: int | None,
    fatal_errors: list[str] | None,
    element: str | None = None,
) -> dict[str, Any]:
    return classify_qe_status(
        "ape",
        upf_qe_ready=upf_qe_ready,
        upf_found=upf_found,
        run_completed=run_completed,
        returncode=returncode,
        fatal_errors=fatal_errors,
        element=element,
    )


def output_dir_name(generator: str) -> str:
    key = (generator or "unknown").strip().lower()
    return OUTPUT_DIR_BY_GENERATOR.get(key, "pseudos_generes")


def generator_bucket_for_tab(tab_id: str) -> str:
    """Mappe un onglet UI (ld1x, ape, …) vers le dossier de sortie."""
    tab = (tab_id or "").strip().lower()
    mapping = {
        "ld1x": "ld1",
        "ld1": "ld1",
        "ape": "ape",
        "atompaw": "atompaw",
        "oncvpsp": "oncvpsp",
        "oncv": "oncvpsp",
    }
    return output_dir_name(mapping.get(tab, tab))


def tab_guide(tab_id: str, sym: str | None = None) -> dict[str, Any]:
    """
    Conseils affichés lors du choix d'un onglet générateur.
    La fiabilité dépend de la famille (3d, 4f), pas d'une règle unique pour tout le tableau.
    """
    tab = (tab_id or "").strip().lower()
    sym_n = normalize_symbol(sym) if sym else None
    z = atomic_number(sym_n) if sym_n else 0
    route = qe_route_hint(sym_n) if sym_n else {}
    meta = TAB_META.get(tab, {"title": tab, "role": ""})

    out: dict[str, Any] = {
        "tab": tab,
        "element": sym_n,
        "Z": z if sym_n else None,
        "title": meta.get("title", tab),
        "role": meta.get("role", ""),
        "save_folder": generator_bucket_for_tab(tab),
        "scope_note": (
            "Ces remarques décrivent des tendances par famille chimique (3d, 4f, gaz noble, …), "
            "pas une interdiction pour tout le tableau périodique."
        ),
    }

    if tab in ("pseudodojo", "pslibrary", "sssp"):
        out["reliability"] = "elevee"
        out["message"] = (
            "Fichiers UPF déjà testés pour Quantum ESPRESSO — dossier "
            f"{output_dir_name('telechargement')}/ après import."
        )
        out["recommended"] = True
        return out

    if tab == "ld1x":
        if sym_n in _TRANSITION_3D:
            out.update(
                reliability="moderee",
                recommended=False,
                message=(
                    f"{sym_n} (métal 3d) : NC en ld1.x souvent en échec (PS-KS). "
                    "Pour QE : USPP, PAW, ou PseudoDojo / ONCV."
                ),
            )
        elif sym_n and _is_lanthanide(sym_n):
            out.update(
                reliability="faible",
                recommended=False,
                message=(
                    f"{sym_n} (lanthanide) : ld1.x NC difficile — ONCVPSP ou import "
                    "Lanthanides_NC_PBE / PseudoDojo."
                ),
            )
        else:
            out.update(
                reliability="bonne",
                recommended=True,
                message="ld1.x convient à beaucoup d'éléments principaux — sortie UPF dans pseudos-ld1/.",
            )
        return out

    if tab == "atompaw":
        out["capabilities"] = ATOMPAW_CAPABILITIES
        out["qe_status_legend"] = QE_STATUS_LEGEND
        out["alternatives"] = generator_alternatives("atompaw", sym_n)
        out.update(
            reliability="bonne",
            recommended=True,
            proactive_level="conform_qe",
            message=(
                "ATOMPAW : voie la plus robuste pour 3d et structures exigeantes — "
                f"UPF dans {output_dir_name('atompaw')}/."
            ),
        )
        if sym_n and _is_lanthanide(sym_n):
            out["message"] += " Lanthanides : valider r_c et relativité."
            out["proactive_level"] = "non_conforme"
        return out

    if tab == "ape":
        feas = ape_feasibility(sym_n) if sym_n else "caution"
        out["capabilities"] = APE_CAPABILITIES
        out["feasibility"] = feas
        out["alternatives"] = ape_alternatives(sym_n)
        out["qe_status_legend"] = QE_STATUS_LEGEND
        if feas == "blocked":
            out.update(
                reliability="faible",
                recommended=False,
                message=route.get("message", "APE NC déconseillé pour cet élément."),
                proactive_level="cannot_generate",
            )
        elif feas == "caution":
            out.update(
                reliability="moderee",
                recommended=False,
                message=(
                    f"{sym_n or 'Élément'} : APE NC possible mais souvent fragile — "
                    "préférez ATOMPAW ou bibliothèque si échec."
                ),
                proactive_level="non_conforme",
            )
        else:
            out.update(
                reliability="bonne",
                recommended=True,
                message=(
                    "APE adapté (Si, Al, O, …) — UPF QE dans "
                    f"{output_dir_name('ape')}/."
                ),
            )
        return out

    if tab == "oncvpsp":
        out["capabilities"] = ONCV_CAPABILITIES
        out["qe_status_legend"] = QE_STATUS_LEGEND
        out["alternatives"] = generator_alternatives("oncvpsp", sym_n)
        if sym_n and _is_lanthanide(sym_n):
            out.update(
                reliability="moderee",
                recommended=True,
                message=(
                    f"{sym_n} : gabarit ONCV local (4f) — si échec, bouton « Importer PseudoDojo » "
                    f"ou dossier pseudos-telecharges/. Génération locale → {output_dir_name('oncvpsp')}/."
                ),
            )
        elif sym_n in _TRANSITION_3D:
            try:
                import transition_3d_nc as t3d

                gen = t3d.needs_generated_dat(sym_n)
            except ImportError:
                gen = sym_n not in ("Ti", "Cu")
            msg = (
                f"{sym_n} : gabarit ONCV local (3d, type Ti/Cu) — valider l’UPF QE après calcul. "
                f"Sauvegarde : {output_dir_name('oncvpsp')}/."
            )
            if not gen:
                msg = (
                    f"{sym_n} : modèle officiel tests/data — psfile=both pour UPF QE. "
                    f"Sauvegarde : {output_dir_name('oncvpsp')}/."
                )
            out.update(
                reliability="moderee",
                recommended=gen,
                message=msg,
            )
        else:
            out.update(
                reliability="bonne",
                recommended=True,
                proactive_level="conform_qe",
                message=(
                    "ONCV + psfile=both → UPF QE si le .dat correspond à l'élément. "
                    f"Sauvegarde : {output_dir_name('oncvpsp')}/."
                ),
            )
        if "proactive_level" not in out:
            out["proactive_level"] = "non_conforme" if out.get("reliability") == "moderee" else "conform_qe"
        return out

    out["message"] = meta.get("role", "")
    out["reliability"] = "variable"
    out["recommended"] = True
    return out

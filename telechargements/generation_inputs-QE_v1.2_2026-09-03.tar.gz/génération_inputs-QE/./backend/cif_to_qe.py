"""
cif_to_qe.py — Conversion de fichiers CIF en inputs Quantum ESPRESSO (pw.x)

Rôle principal :
  Analyser un fichier CIF (Crystallographic Information File) et générer
  un fichier d'entrée formaté pour pw.x (Quantum ESPRESSO).

Fonctionnalités clés :
  ● Détection automatique du réseau de Bravais (ibrav) à partir du groupe d'espace
  ● Support DFT+U (Hubbard) — syntaxes legacy (QE < 7.3.1) et carte HUBBARD (QE ≥ 7.3.1)
  ● Ordres magnétiques AFM (colinéaire) avec sous-réseaux X1/X2
  ● Supercellules pour ordres magnétiques complexes
  ● Deux backends : pymatgen (préféré) ou ase + spglib (fallback)

Table de correspondance ibrav :

  Système        | N° groupe espace | Centrage | ibrav
  ---------------+------------------+----------+-----------------
  Cubique         | 195 – 230        | P / F / I | 1 / 2 / 3
  Hexagonal       | 168 – 194        | P         | 4
  Trigonal        | 143 – 167        | R / P     | 5 / 4
  Tétragonal      |  75 – 142        | P / I     | 6 / 7
  Orthorhombique  |  16 –  74        | P/C/F/I/A | 8/9/10/11/91
  Monoclinique    |   3 –  15        | P / C / A | 12 / 13 / 91
  Triclinique     |   1 –   2        | P         | 14

Dépendances : pymatgen (préféré) ou ase + spglib en fallback.
Module 100 % autonome : aucune dépendance à thermo_pw ni Interface-QE_v1.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ── PROFILS DE CONVERGENCE OPTIMAUX PAR TYPE DE MATÉRIAU ET TYPE DE CALCUL ──
# Ces profils sont établis à partir de la pratique DFT et de l'expérience
# sur des milliers de calculs Quantum ESPRESSO. Ils garantissent un bon
# compromis précision/stabilité/vitesse.

from enum import Enum

class MaterialClass(Enum):
    """Classification des matériaux selon leurs propriétés électroniques et magnétiques."""
    METAL = "metal"           # Métal simple (bon conducteur, DOS élevé au niveau de Fermi)
    INSULATOR = "insulator"     # Isolant (gap > 3 eV)
    SEMICONDUCTOR = "semiconductor"  # Semi-conducteur (gap modéré)
    MAGNETIC_METAL = "mag_metal"     # Métal magnétique (Fe, Co, Ni, etc.)
    MAGNETIC_INSULATOR = "mag_insulator"  # Isolant magnétique (oxydes de métaux de transition)
    RARE_EARTH = "rare_earth"    # Terre rare / f-electron (forte corrélation)
    ORGANIC = "organic"          # Matériau organique / moléculaire
    UNKNOWN = "unknown"          # Non déterminé


@dataclass
class ConvergenceProfile:
    """
    Profil de paramètres de convergence optimaux pour un type de matériau
    et un type de calcul donné.

    Chaque valeur est choisie pour garantir la convergence du cycle SCF
    avec un minimum d'itérations, adaptée à la physique du matériau.
    """
    material_class: MaterialClass
    calculation_type: str  # 'scf', 'relax', 'vc-relax', 'nscf', 'bands', 'md'
    ecutwfc: float        # Ry
    ecutrho: float         # Ry
    conv_thr: str          # format Fortran '1.0d-8'
    mixing_beta: float
    occupations: str       # 'smearing', 'fixed', 'tetrahedra'
    smearing: str         # 'gaussian', 'methfessel-paxton', 'marzari-vanderbilt', 'cold', 'fermi-dirac'
    degauss: float        # Ry
    kpoints_grid: tuple   # (kx, ky, kz)
    forc_conv_thr: str = "1.0d-4"  # Ry/Bohr (pour relax/vc-relax)
    press_conv_thr: str = "0.5"    # kbar (pour vc-relax)
    diagonalization: str = "david"
    mixing_mode: str = "plain"
    electron_maxstep: int = 100
    note: str = ""


# ── Base de données des profils de convergence ──
# Organisée par type de matériau puis par type de calcul

CONVERGENCE_PROFILES: dict[str, dict[str, ConvergenceProfile]] = {
    # ─── Métal (bon conducteur) ───
    "metal": {
        "scf": ConvergenceProfile(
            material_class=MaterialClass.METAL, calculation_type="scf",
            ecutwfc=55.0, ecutrho=440.0, conv_thr="1.0d-8",
            mixing_beta=0.5, occupations="smearing", smearing="methfessel-paxton",
            degauss=0.02, kpoints_grid=(8, 8, 8),
            electron_maxstep=150,
            note="Métal : smearing MP pour DOS fin, mixing_beta modéré (0.5)"
        ),
        "relax": ConvergenceProfile(
            material_class=MaterialClass.METAL, calculation_type="relax",
            ecutwfc=65.0, ecutrho=520.0, conv_thr="1.0d-9",
            mixing_beta=0.4, occupations="smearing", smearing="methfessel-paxton",
            degauss=0.02, kpoints_grid=(6, 6, 6),
            forc_conv_thr="1.0d-4",
            note="Métal relax : ecutwfc +10 Ry pour forces précises, mixing_beta réduit"
        ),
        "vc-relax": ConvergenceProfile(
            material_class=MaterialClass.METAL, calculation_type="vc-relax",
            ecutwfc=75.0, ecutrho=600.0, conv_thr="1.0d-9",
            mixing_beta=0.3, occupations="smearing", smearing="methfessel-paxton",
            degauss=0.02, kpoints_grid=(8, 8, 8),
            forc_conv_thr="1.0d-4", press_conv_thr="0.5",
            electron_maxstep=200,
            note="Métal vc-relax : ecutwfc bien convergé, mixing_beta bas (0.3)"
        ),
        "nscf": ConvergenceProfile(
            material_class=MaterialClass.METAL, calculation_type="nscf",
            ecutwfc=55.0, ecutrho=440.0, conv_thr="1.0d-10",
            mixing_beta=0.5, occupations="tetrahedra", smearing="gaussian",
            degauss=0.02, kpoints_grid=(12, 12, 12),
            note="NSCF métal : grille k très dense (12×12×12), occupations tetrahedra"
        ),
        "bands": ConvergenceProfile(
            material_class=MaterialClass.METAL, calculation_type="bands",
            ecutwfc=55.0, ecutrho=440.0, conv_thr="1.0d-10",
            mixing_beta=0.5, occupations="smearing", smearing="methfessel-paxton",
            degauss=0.02, kpoints_grid=(8, 8, 8),
            note="BANDS métal : mêmes paramètres que SCF"
        ),
        "md": ConvergenceProfile(
            material_class=MaterialClass.METAL, calculation_type="md",
            ecutwfc=40.0, ecutrho=320.0, conv_thr="1.0d-7",
            mixing_beta=0.5, occupations="smearing", smearing="methfessel-paxton",
            degauss=0.02, kpoints_grid=(2, 2, 2),
            note="MD métal : ecutwfc réduit pour vitesse, conv_thr relâché"
        ),
    },

    # ─── Isolant (gap > 3 eV) ───
    "insulator": {
        "scf": ConvergenceProfile(
            material_class=MaterialClass.INSULATOR, calculation_type="scf",
            ecutwfc=45.0, ecutrho=360.0, conv_thr="1.0d-8",
            mixing_beta=0.7, occupations="fixed", smearing="cold",
            degauss=0.005, kpoints_grid=(4, 4, 4),
            note="Isolant : occupations fixed, convergence facile, grille modérée"
        ),
        "relax": ConvergenceProfile(
            material_class=MaterialClass.INSULATOR, calculation_type="relax",
            ecutwfc=55.0, ecutrho=440.0, conv_thr="1.0d-9",
            mixing_beta=0.5, occupations="fixed", smearing="cold",
            degauss=0.005, kpoints_grid=(4, 4, 4),
            forc_conv_thr="1.0d-4",
            note="Isolant relax : ecutwfc modéré, occupations fixed pour stabilité"
        ),
        "vc-relax": ConvergenceProfile(
            material_class=MaterialClass.INSULATOR, calculation_type="vc-relax",
            ecutwfc=65.0, ecutrho=520.0, conv_thr="1.0d-9",
            mixing_beta=0.4, occupations="fixed", smearing="cold",
            degauss=0.005, kpoints_grid=(6, 6, 6),
            forc_conv_thr="1.0d-4", press_conv_thr="0.5",
            note="Isolant vc-relax : paramètres standards, mélange stable"
        ),
        "nscf": ConvergenceProfile(
            material_class=MaterialClass.INSULATOR, calculation_type="nscf",
            ecutwfc=45.0, ecutrho=360.0, conv_thr="1.0d-10",
            mixing_beta=0.7, occupations="tetrahedra", smearing="cold",
            degauss=0.005, kpoints_grid=(8, 8, 8),
            note="NSCF isolant : grille 8×8×8 suffisante pour DOS précise"
        ),
        "bands": ConvergenceProfile(
            material_class=MaterialClass.INSULATOR, calculation_type="bands",
            ecutwfc=45.0, ecutrho=360.0, conv_thr="1.0d-10",
            mixing_beta=0.7, occupations="fixed", smearing="cold",
            degauss=0.005, kpoints_grid=(4, 4, 4),
            note="BANDS isolant : paramètres SCF"
        ),
        "md": ConvergenceProfile(
            material_class=MaterialClass.INSULATOR, calculation_type="md",
            ecutwfc=35.0, ecutrho=280.0, conv_thr="1.0d-7",
            mixing_beta=0.7, occupations="fixed", smearing="cold",
            degauss=0.005, kpoints_grid=(2, 2, 2),
            note="MD isolant : occupations fixed pour éviter les problèmes de smearing"
        ),
    },

    # ─── Semi-conducteur (gap 0.5-3 eV) ───
    "semiconductor": {
        "scf": ConvergenceProfile(
            material_class=MaterialClass.SEMICONDUCTOR, calculation_type="scf",
            ecutwfc=50.0, ecutrho=400.0, conv_thr="1.0d-8",
            mixing_beta=0.7, occupations="cold", smearing="cold",
            degauss=0.01, kpoints_grid=(6, 6, 6),
            note="Semiconductor SCF : cold smearing, bonne grille k"
        ),
        "relax": ConvergenceProfile(
            material_class=MaterialClass.SEMICONDUCTOR, calculation_type="relax",
            ecutwfc=60.0, ecutrho=480.0, conv_thr="1.0d-9",
            mixing_beta=0.5, occupations="cold", smearing="cold",
            degauss=0.01, kpoints_grid=(4, 4, 4),
            forc_conv_thr="1.0d-4",
            note="Semiconductor relax : ecutwfc 60 Ry pour forces fiables"
        ),
        "vc-relax": ConvergenceProfile(
            material_class=MaterialClass.SEMICONDUCTOR, calculation_type="vc-relax",
            ecutwfc=70.0, ecutrho=560.0, conv_thr="1.0d-9",
            mixing_beta=0.35, occupations="cold", smearing="cold",
            degauss=0.01, kpoints_grid=(6, 6, 6),
            forc_conv_thr="1.0d-4", press_conv_thr="0.5",
            note="Semiconductor vc-relax : mixing_beta 0.35 pour stabilité"
        ),
        "nscf": ConvergenceProfile(
            material_class=MaterialClass.SEMICONDUCTOR, calculation_type="nscf",
            ecutwfc=50.0, ecutrho=400.0, conv_thr="1.0d-10",
            mixing_beta=0.7, occupations="tetrahedra", smearing="cold",
            degauss=0.01, kpoints_grid=(10, 10, 10),
            note="NSCF semiconductor : grille 10×10×10, occupations tetrahedra"
        ),
        "bands": ConvergenceProfile(
            material_class=MaterialClass.SEMICONDUCTOR, calculation_type="bands",
            ecutwfc=50.0, ecutrho=400.0, conv_thr="1.0d-10",
            mixing_beta=0.7, occupations="cold", smearing="cold",
            degauss=0.01, kpoints_grid=(6, 6, 6),
            note="BANDS semiconductor : paramètres SCF"
        ),
        "md": ConvergenceProfile(
            material_class=MaterialClass.SEMICONDUCTOR, calculation_type="md",
            ecutwfc=40.0, ecutrho=320.0, conv_thr="1.0d-7",
            mixing_beta=0.7, occupations="cold", smearing="cold",
            degauss=0.01, kpoints_grid=(2, 2, 2),
            note="MD semiconductor : paramètres légers pour vitesse"
        ),
    },

    # ─── Métal magnétique (Fe, Co, Ni, etc.) ───
    "mag_metal": {
        "scf": ConvergenceProfile(
            material_class=MaterialClass.MAGNETIC_METAL, calculation_type="scf",
            ecutwfc=60.0, ecutrho=480.0, conv_thr="1.0d-9",
            mixing_beta=0.3, occupations="smearing", smearing="methfessel-paxton",
            degauss=0.02, kpoints_grid=(8, 8, 8),
            note="Métal magnétique SCF : mixing_beta bas (0.3) pour stabilité spin"
        ),
        "relax": ConvergenceProfile(
            material_class=MaterialClass.MAGNETIC_METAL, calculation_type="relax",
            ecutwfc=70.0, ecutrho=560.0, conv_thr="1.0d-9",
            mixing_beta=0.25, occupations="smearing", smearing="methfessel-paxton",
            degauss=0.02, kpoints_grid=(6, 6, 6),
            forc_conv_thr="1.0d-4",
            note="Métal magnétique relax : mixing_beta 0.25 pour oscillation spin"
        ),
        "vc-relax": ConvergenceProfile(
            material_class=MaterialClass.MAGNETIC_METAL, calculation_type="vc-relax",
            ecutwfc=80.0, ecutrho=640.0, conv_thr="1.0d-10",
            mixing_beta=0.2, occupations="smearing", smearing="methfessel-paxton",
            degauss=0.02, kpoints_grid=(8, 8, 8),
            forc_conv_thr="1.0d-5", press_conv_thr="0.5",
            electron_maxstep=200,
            note="MÉTAL MAG vc-relax : ecutwfc 80 Ry ! mixing_beta très bas (0.2) ! conv_thr strict"
        ),
        "nscf": ConvergenceProfile(
            material_class=MaterialClass.MAGNETIC_METAL, calculation_type="nscf",
            ecutwfc=60.0, ecutrho=480.0, conv_thr="1.0d-10",
            mixing_beta=0.3, occupations="tetrahedra", smearing="methfessel-paxton",
            degauss=0.02, kpoints_grid=(12, 12, 12),
            note="NSCF métal magnétique : grille très dense"
        ),
        "bands": ConvergenceProfile(
            material_class=MaterialClass.MAGNETIC_METAL, calculation_type="bands",
            ecutwfc=60.0, ecutrho=480.0, conv_thr="1.0d-10",
            mixing_beta=0.3, occupations="smearing", smearing="methfessel-paxton",
            degauss=0.02, kpoints_grid=(8, 8, 8),
            note="BANDS métal magnétique"
        ),
        "md": ConvergenceProfile(
            material_class=MaterialClass.MAGNETIC_METAL, calculation_type="md",
            ecutwfc=45.0, ecutrho=360.0, conv_thr="1.0d-7",
            mixing_beta=0.3, occupations="smearing", smearing="methfessel-paxton",
            degauss=0.02, kpoints_grid=(2, 2, 2),
            note="MD métal magnétique : paramètres allégés"
        ),
    },

    # ─── Isolant magnétique (oxydes TM : NiO, Fe2O3, etc.) ───
    "mag_insulator": {
        "scf": ConvergenceProfile(
            material_class=MaterialClass.MAGNETIC_INSULATOR, calculation_type="scf",
            ecutwfc=55.0, ecutrho=440.0, conv_thr="1.0d-9",
            mixing_beta=0.3, occupations="cold", smearing="cold",
            degauss=0.01, kpoints_grid=(6, 6, 6),
            electron_maxstep=150,
            note="Isolant magnétique SCF : mixing_beta bas (0.3), cold smearing"
        ),
        "relax": ConvergenceProfile(
            material_class=MaterialClass.MAGNETIC_INSULATOR, calculation_type="relax",
            ecutwfc=65.0, ecutrho=520.0, conv_thr="1.0d-9",
            mixing_beta=0.25, occupations="cold", smearing="cold",
            degauss=0.01, kpoints_grid=(4, 4, 4),
            forc_conv_thr="1.0d-5", electron_maxstep=200,
            note="Isolant magnétique relax : forc_conv_thr strict (1d-5)"
        ),
        "vc-relax": ConvergenceProfile(
            material_class=MaterialClass.MAGNETIC_INSULATOR, calculation_type="vc-relax",
            ecutwfc=75.0, ecutrho=600.0, conv_thr="1.0d-10",
            mixing_beta=0.2, occupations="cold", smearing="cold",
            degauss=0.01, kpoints_grid=(6, 6, 6),
            forc_conv_thr="1.0d-5", press_conv_thr="0.5",
            electron_maxstep=250,
            note="Isolant magnétique vc-relax : très strict, mixing_beta très bas"
        ),
        "nscf": ConvergenceProfile(
            material_class=MaterialClass.MAGNETIC_INSULATOR, calculation_type="nscf",
            ecutwfc=55.0, ecutrho=440.0, conv_thr="1.0d-10",
            mixing_beta=0.3, occupations="tetrahedra", smearing="cold",
            degauss=0.01, kpoints_grid=(8, 8, 8),
            note="NSCF isolant magnétique"
        ),
        "bands": ConvergenceProfile(
            material_class=MaterialClass.MAGNETIC_INSULATOR, calculation_type="bands",
            ecutwfc=55.0, ecutrho=440.0, conv_thr="1.0d-10",
            mixing_beta=0.3, occupations="cold", smearing="cold",
            degauss=0.01, kpoints_grid=(6, 6, 6),
            note="BANDS isolant magnétique"
        ),
        "md": ConvergenceProfile(
            material_class=MaterialClass.MAGNETIC_INSULATOR, calculation_type="md",
            ecutwfc=40.0, ecutrho=320.0, conv_thr="1.0d-7",
            mixing_beta=0.4, occupations="cold", smearing="cold",
            degauss=0.01, kpoints_grid=(2, 2, 2),
            note="MD isolant magnétique"
        ),
    },

    # ─── Terre rare / f-electron (Gd, Dy, Ce, etc.) ───
    "rare_earth": {
        "scf": ConvergenceProfile(
            material_class=MaterialClass.RARE_EARTH, calculation_type="scf",
            ecutwfc=65.0, ecutrho=520.0, conv_thr="1.0d-9",
            mixing_beta=0.25, occupations="cold", smearing="cold",
            degauss=0.01, kpoints_grid=(6, 6, 6),
            electron_maxstep=200,
            note="Terre rare SCF : mixing_beta TRÈS bas (0.25) ! convergence difficile, + Hubbard U"
        ),
        "relax": ConvergenceProfile(
            material_class=MaterialClass.RARE_EARTH, calculation_type="relax",
            ecutwfc=75.0, ecutrho=600.0, conv_thr="1.0d-10",
            mixing_beta=0.2, occupations="cold", smearing="cold",
            degauss=0.01, kpoints_grid=(4, 4, 4),
            forc_conv_thr="1.0d-5", electron_maxstep=250,
            note="Terre rare relax : mixing_beta très bas (0.2), forc_conv_thr strict"
        ),
        "vc-relax": ConvergenceProfile(
            material_class=MaterialClass.RARE_EARTH, calculation_type="vc-relax",
            ecutwfc=85.0, ecutrho=680.0, conv_thr="1.0d-10",
            mixing_beta=0.15, occupations="cold", smearing="cold",
            degauss=0.01, kpoints_grid=(6, 6, 6),
            forc_conv_thr="1.0d-5", press_conv_thr="0.5",
            electron_maxstep=300,
            note="TERRE RARE vc-relax : ecutwfc 85 Ry, mixing_beta 0.15, max 300 itérations!"
        ),
        "nscf": ConvergenceProfile(
            material_class=MaterialClass.RARE_EARTH, calculation_type="nscf",
            ecutwfc=65.0, ecutrho=520.0, conv_thr="1.0d-10",
            mixing_beta=0.25, occupations="tetrahedra", smearing="cold",
            degauss=0.01, kpoints_grid=(8, 8, 8),
            note="NSCF terre rare"
        ),
        "bands": ConvergenceProfile(
            material_class=MaterialClass.RARE_EARTH, calculation_type="bands",
            ecutwfc=65.0, ecutrho=520.0, conv_thr="1.0d-10",
            mixing_beta=0.25, occupations="cold", smearing="cold",
            degauss=0.01, kpoints_grid=(6, 6, 6),
            note="BANDS terre rare"
        ),
        "md": ConvergenceProfile(
            material_class=MaterialClass.RARE_EARTH, calculation_type="md",
            ecutwfc=45.0, ecutrho=360.0, conv_thr="1.0d-7",
            mixing_beta=0.35, occupations="cold", smearing="cold",
            degauss=0.01, kpoints_grid=(2, 2, 2),
            note="MD terre rare : paramètres allégés"
        ),
    },

    # ─── Organique / Moléculaire ───
    "organic": {
        "scf": ConvergenceProfile(
            material_class=MaterialClass.ORGANIC, calculation_type="scf",
            ecutwfc=40.0, ecutrho=320.0, conv_thr="1.0d-8",
            mixing_beta=0.5, occupations="fixed", smearing="gaussian",
            degauss=0.005, kpoints_grid=(2, 2, 2),
            note="Organique SCF : grille k clairsemée (cellule grande), occupations fixed"
        ),
        "relax": ConvergenceProfile(
            material_class=MaterialClass.ORGANIC, calculation_type="relax",
            ecutwfc=50.0, ecutrho=400.0, conv_thr="1.0d-9",
            mixing_beta=0.4, occupations="fixed", smearing="gaussian",
            degauss=0.005, kpoints_grid=(1, 1, 1),
            forc_conv_thr="1.0d-4",
            note="Organique relax : point Γ seulement pour grandes cellules"
        ),
        "vc-relax": ConvergenceProfile(
            material_class=MaterialClass.ORGANIC, calculation_type="vc-relax",
            ecutwfc=55.0, ecutrho=440.0, conv_thr="1.0d-9",
            mixing_beta=0.35, occupations="fixed", smearing="gaussian",
            degauss=0.005, kpoints_grid=(1, 1, 1),
            forc_conv_thr="1.0d-4", press_conv_thr="0.5",
            note="Organique vc-relax"
        ),
        "nscf": ConvergenceProfile(
            material_class=MaterialClass.ORGANIC, calculation_type="nscf",
            ecutwfc=40.0, ecutrho=320.0, conv_thr="1.0d-10",
            mixing_beta=0.5, occupations="tetrahedra", smearing="gaussian",
            degauss=0.005, kpoints_grid=(4, 4, 4),
            note="NSCF organique"
        ),
        "bands": ConvergenceProfile(
            material_class=MaterialClass.ORGANIC, calculation_type="bands",
            ecutwfc=40.0, ecutrho=320.0, conv_thr="1.0d-10",
            mixing_beta=0.5, occupations="fixed", smearing="gaussian",
            degauss=0.005, kpoints_grid=(2, 2, 2),
            note="BANDS organique"
        ),
        "md": ConvergenceProfile(
            material_class=MaterialClass.ORGANIC, calculation_type="md",
            ecutwfc=30.0, ecutrho=240.0, conv_thr="1.0d-7",
            mixing_beta=0.5, occupations="fixed", smearing="gaussian",
            degauss=0.005, kpoints_grid=(1, 1, 1),
            note="MD organique : point Γ, ecutwfc réduit"
        ),
    },

    # ─── Inconnu (valeurs par défaut prudentes) ───
    "unknown": {
        "scf": ConvergenceProfile(
            material_class=MaterialClass.UNKNOWN, calculation_type="scf",
            ecutwfc=50.0, ecutrho=400.0, conv_thr="1.0d-8",
            mixing_beta=0.7, occupations="smearing", smearing="cold",
            degauss=0.02, kpoints_grid=(6, 6, 6),
            note="Défaut : paramètres génériques, tester convergence!"
        ),
        "relax": ConvergenceProfile(
            material_class=MaterialClass.UNKNOWN, calculation_type="relax",
            ecutwfc=60.0, ecutrho=480.0, conv_thr="1.0d-9",
            mixing_beta=0.5, occupations="smearing", smearing="cold",
            degauss=0.02, kpoints_grid=(4, 4, 4),
            forc_conv_thr="1.0d-4",
            note="Défaut relax : paramètres prudents"
        ),
        "vc-relax": ConvergenceProfile(
            material_class=MaterialClass.UNKNOWN, calculation_type="vc-relax",
            ecutwfc=70.0, ecutrho=560.0, conv_thr="1.0d-9",
            mixing_beta=0.35, occupations="smearing", smearing="cold",
            degauss=0.02, kpoints_grid=(6, 6, 6),
            forc_conv_thr="1.0d-4", press_conv_thr="0.5",
            note="Défaut vc-relax"
        ),
        "nscf": ConvergenceProfile(
            material_class=MaterialClass.UNKNOWN, calculation_type="nscf",
            ecutwfc=50.0, ecutrho=400.0, conv_thr="1.0d-10",
            mixing_beta=0.7, occupations="tetrahedra", smearing="cold",
            degauss=0.02, kpoints_grid=(10, 10, 10),
            note="Défaut NSCF"
        ),
        "bands": ConvergenceProfile(
            material_class=MaterialClass.UNKNOWN, calculation_type="bands",
            ecutwfc=50.0, ecutrho=400.0, conv_thr="1.0d-10",
            mixing_beta=0.7, occupations="smearing", smearing="cold",
            degauss=0.02, kpoints_grid=(6, 6, 6),
            note="Défaut BANDS"
        ),
        "md": ConvergenceProfile(
            material_class=MaterialClass.UNKNOWN, calculation_type="md",
            ecutwfc=40.0, ecutrho=320.0, conv_thr="1.0d-7",
            mixing_beta=0.7, occupations="smearing", smearing="cold",
            degauss=0.02, kpoints_grid=(2, 2, 2),
            note="Défaut MD"
        ),
    },
}


def get_convergence_profile(material_class: str, calculation: str) -> ConvergenceProfile:
    """
    Récupère le profil de convergence optimal pour une classe de matériau
    et un type de calcul donnés. Retourne le profil 'unknown' si la classe
    ou le type de calcul n'est pas disponible.
    """
    mc = (material_class or "unknown").strip().lower()
    calc = (calculation or "scf").strip().lower()
    calc_map = {"scf", "relax", "vc-relax", "nscf", "bands", "md", "vc-md", "scf_berry", "scf_born"}
    if calc not in calc_map:
        calc = "scf"
    profiles = CONVERGENCE_PROFILES.get(mc, CONVERGENCE_PROFILES["unknown"])
    return profiles.get(calc, CONVERGENCE_PROFILES["unknown"]["scf"])


def detect_material_class(formula: str, atomic_species: list[str]) -> MaterialClass:
    """
    Détecte la classe d'un matériau à partir de sa formule chimique
    et de la liste des espèces atomiques.

    Logique :
      1. Présence de terres rares (Gd, Dy, Ce…) → RARE_EARTH
      2. Éléments magnétiques 3d (Fe, Co, Ni, Cr, Mn) + oxygène → MAGNETIC_INSULATOR
      3. Éléments magnétiques 3d sans oxygène → MAGNETIC_METAL
      4. Présence de C, H, N, O dans une molécule → ORGANIC
      5. Oxygène présent mais sans métal de transition → INSULATOR
      6. Métal alcalin, alcalino-terreux → METAL
      7. Par défaut → SEMICONDUCTOR (hypothèse prudente)
    """
    formula_upper = (formula or "").upper()
    bases = set()
    for s in (atomic_species or []):
        base = _chem_base_symbol(str(s))
        if base:
            bases.add(base)

    has_oxygen = "O" in bases
    has_carbon = "C" in bases
    has_hydrogen = "H" in bases

    # Ensembles d'éléments
    rare_earth_elements = {"Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Ce", "Pr", "Nd", "Sm", "Eu", "La"}
    transition_metals = {"Fe", "Co", "Ni", "Mn", "Cr", "V", "Cu", "Zn"}
    alkali_alkaline = {"Li", "Na", "K", "Rb", "Cs", "Be", "Mg", "Ca", "Sr", "Ba"}
    semiconductors_classic = {"Si", "Ge", "Ga", "As", "In", "P", "Sb"}
    halogens = {"F", "Cl", "Br", "I"}

    found_rare_earth = bool(bases & rare_earth_elements)
    found_transition = bool(bases & transition_metals)
    found_alkali = bool(bases & alkali_alkaline)
    found_semi = bool(bases & semiconductors_classic)
    found_halogen = bool(bases & halogens)

    # Détection organique : présence de C et H ensemble
    if has_carbon and has_hydrogen and (found_halogen or has_oxygen):
        return MaterialClass.ORGANIC

    # Terre rare → priorité haute (convergence difficile)
    if found_rare_earth:
        return MaterialClass.RARE_EARTH

    # Transition metal + oxygène → oxyde magnétique
    if found_transition and has_oxygen:
        return MaterialClass.MAGNETIC_INSULATOR

    # Transition metal sans oxygène → métal magnétique
    if found_transition:
        return MaterialClass.MAGNETIC_METAL

    # Oxygène + alcalin → isolant
    if has_oxygen and found_alkali:
        return MaterialClass.INSULATOR

    # Oxygène seul (ex: O2) ou avec halogènes → isolant
    if has_oxygen and not found_transition:
        return MaterialClass.INSULATOR

    # Métaux alcalins/alcalino-terreux purs
    if found_alkali:
        return MaterialClass.METAL

    # Semi-conducteurs classiques (Si, Ge, GaAs, etc.)
    if found_semi:
        return MaterialClass.SEMICONDUCTOR

    # Par défaut
    return MaterialClass.SEMICONDUCTOR


def get_profile_for_formula(formula: str, atomic_species: list[str], calculation: str) -> ConvergenceProfile:
    """
    Fonction de commodité : détecte la classe du matériau et retourne
    le profil de convergence optimal pour le type de calcul demandé.
    """
    mc = detect_material_class(formula, atomic_species)
    return get_convergence_profile(mc.value, calculation)


def profile_to_dict(profile: ConvergenceProfile) -> dict:
    """Convertit un ConvergenceProfile en dictionnaire JSON-serializable."""
    return {
        "material_class": profile.material_class.value,
        "calculation_type": profile.calculation_type,
        "ecutwfc": profile.ecutwfc,
        "ecutrho": profile.ecutrho,
        "conv_thr": profile.conv_thr,
        "mixing_beta": profile.mixing_beta,
        "occupations": profile.occupations,
        "smearing": profile.smearing,
        "degauss": profile.degauss,
        "kpoints_grid": list(profile.kpoints_grid),
        "forc_conv_thr": profile.forc_conv_thr,
        "press_conv_thr": profile.press_conv_thr,
        "diagonalization": profile.diagonalization,
        "mixing_mode": profile.mixing_mode,
        "electron_maxstep": profile.electron_maxstep,
        "note": profile.note,
    }


def get_all_material_classes() -> list[dict]:
    """Retourne la liste de toutes les classes de matériaux disponibles."""
    return [
        {"id": "metal", "name": "Métal", "description": "Bon conducteur (Cu, Al, Na…)"},
        {"id": "insulator", "name": "Isolant", "description": "Gap > 3 eV (MgO, NaCl, BaTiO₃…)"},
        {"id": "semiconductor", "name": "Semi-conducteur", "description": "Gap 0.5-3 eV (Si, GaAs…)"},
        {"id": "mag_metal", "name": "Métal magnétique", "description": "Fe, Co, Ni, Mn, alliages ferromagnétiques"},
        {"id": "mag_insulator", "name": "Isolant magnétique", "description": "Oxydes magnétiques (NiO, Fe₂O₃, LaVO₃…)"},
        {"id": "rare_earth", "name": "Terre rare / f-electron", "description": "Gd, Dy, Ce… forts corrélations, Hubbard U"},
        {"id": "organic", "name": "Organique / Moléculaire", "description": "Polymères, cristaux moléculaires"},
        {"id": "unknown", "name": "Inconnu", "description": "Paramètres par défaut prudents"},
    ]


# ── Constantes de conversion d'unités ──
# Bohr (unité atomique) ↔ Angström (unité cristallographique courante)
# 1 Bohr = 0.529177210903 Å  (valeur CODATA 2018)
BOHR_TO_ANG = 0.529177210903
ANG_TO_BOHR = 1.0 / BOHR_TO_ANG


@dataclass
class CifAnalysis:
    """
    Résultat d'analyse d'un fichier CIF, prêt à être injecté dans un input QE.

    Cette dataclass stocke toutes les informations cristallographiques extraites
    du fichier CIF après analyse par pymatgen ou ase+spglib. Elle sert de format
    d'échange entre la phase d'analyse (analyze_cif) et la génération d'input (build_pw_input).

    Attributs :
        formula : Formule chimique réduite (ex. "GdVO3")
        formula_cell : Composition totale de la maille (ex. "Gd4V4O12")
        spacegroup_number : Numéro du groupe d'espace (1-230)
        spacegroup_symbol : Symbole Hermann-Mauguin (ex. "Pnma")
        crystal_system : Système cristallin (cubic, hexagonal, trigonal, etc.)
        centering : Type de centrage (P, I, F, C, A, R)
        ibrav : Index du réseau de Bravais QE (1-14, 91)
        a, b, c : Paramètres de maille en Å
        alpha_deg, beta_deg, gamma_deg : Angles en degrés
        celldim : Paramètres celldim(1..6) pour QE (en unités atomiques)
        nat : Nombre total d'atomes dans la maille
        ntyp : Nombre de types d'atomes (espèces)
        atomic_species : Liste des espèces chimiques (ex. ["Gd", "V", "O"])
        atomic_positions_crystal : Positions fractionnaires [(sym, x, y, z), ...]
        cell_parameters_angstrom : Matrice 3x3 des vecteurs de maille
        backend : Backend utilisé ("pymatgen" ou "ase+spglib")
        notes : Messages d'information/debug de l'analyse
        formula_units_z : Nombre d'unités formulaires dans la maille (Z ≥ 1)
    """

    # Formule chimique réduite (ex. "GdVO3")
    formula: str
    # Numéro du groupe d'espace (1-230)
    spacegroup_number: int
    # Symbole Hermann-Mauguin (ex. "Pnma")
    spacegroup_symbol: str
    # Système cristallin ("cubic", "hexagonal", "trigonal", etc.)
    crystal_system: str
    # Type de centrage ("P", "I", "F", "C", "A", "R")
    centering: str
    # Index ibrav pour QE (1-14 ou 91)
    ibrav: int
    # Paramètres de maille en Ångströms
    a: float
    b: float
    c: float
    # Angles en degrés
    alpha_deg: float
    beta_deg: float
    gamma_deg: float
    # Paramètres celldim(1..6) pour l'input QE (en unités atomiques)
    celldm: dict = field(default_factory=dict)
    # Nombre total d'atomes dans la maille
    nat: int = 0
    # Nombre de types d'atomes différents
    ntyp: int = 0
    # Liste des espèces chimiques (symbole, ex. "Gd", "V1", "O")
    atomic_species: list = field(default_factory=list)
    # Positions atomiques en coordonnées fractionnaires [(sym, x, y, z), ...]
    atomic_positions_crystal: list = field(default_factory=list)
    # Matrice 3x3 des vecteurs de maille en Å
    cell_parameters_angstrom: list = field(default_factory=list)
    # Backend utilisé lors de l'analyse ("pymatgen" ou "ase+spglib")
    backend: str = ""
    # Notes et messages d'information de l'analyse
    notes: list = field(default_factory=list)
    # Nombre d'unités formulaires réduites dans la maille (Z ≥ 1)
    formula_units_z: int = 1
    # Composition chimique totale de la maille (ex. Dy4O12V4)
    # Distincte de ``formula`` qui est la formule réduite
    formula_cell: str = ""

    def to_dict(self) -> dict:
        return {
            "formula": self.formula,
            "formula_cell": self.formula_cell or self.formula,
            "spacegroup_number": self.spacegroup_number,
            "spacegroup_symbol": self.spacegroup_symbol,
            "crystal_system": self.crystal_system,
            "centering": self.centering,
            "ibrav": self.ibrav,
            "a": self.a,
            "b": self.b,
            "c": self.c,
            "alpha_deg": self.alpha_deg,
            "beta_deg": self.beta_deg,
            "gamma_deg": self.gamma_deg,
            "celldm": {str(k): v for k, v in self.celldm.items()},
            "nat": self.nat,
            "ntyp": self.ntyp,
            "atomic_species": list(self.atomic_species),
            "atomic_positions_crystal": [
                {"symbol": s, "x": x, "y": y, "z": z}
                for (s, x, y, z) in self.atomic_positions_crystal
            ],
            "cell_parameters_angstrom": [
                list(row) for row in self.cell_parameters_angstrom
            ],
            "backend": self.backend,
            "notes": list(self.notes),
            "formula_units_z": int(self.formula_units_z),
        }


def _formulas_from_counts(symbols: list[str]) -> tuple[str, str, int]:
    """(formule_réduite, formule_maille, Z) à partir de la liste d’atomes."""
    ct: dict[str, int] = {}
    for s in symbols:
        ct[s] = ct.get(s, 0) + 1
    if not ct:
        return "?", "?", 1
    try:
        from pymatgen.core import Composition  # type: ignore

        comp = Composition({k: v for k, v in ct.items()})
        red = str(comp.reduced_formula)
        cell = str(comp.formula).replace(" ", "")
        _r, factor = comp.get_reduced_composition_and_factor()
        z = max(1, int(round(float(factor))))
        return red, cell, z
    except Exception:
        pass
    from functools import reduce
    from math import gcd

    g = reduce(gcd, ct.values())
    z = g

    def _fmt(ct_map: dict[str, int], div: int) -> str:
        non_o = sorted(k for k in ct_map if k != "O")
        order = non_o + (["O"] if "O" in ct_map else [])
        parts = []
        for el in order:
            n = ct_map[el] // div if div else ct_map[el]
            parts.append(f"{el}{n}" if n != 1 else el)
        return "".join(parts)

    return _fmt(ct, g), _fmt(ct, 1), max(1, z)


def _formulas_from_pymatgen_structure(structure) -> tuple[str, str, int]:
    """
    Extrait les formules (réduite, maille, Z) depuis une structure pymatgen.

    Utilise la méthode get_reduced_composition_and_factor() qui calcule
    automatiquement le PGCD des stœchiométries élémentaires.
    """
    comp = structure.composition
    red = str(comp.reduced_formula)
    cell = str(comp.formula).replace(" ", "")
    _r, factor = comp.get_reduced_composition_and_factor()
    z = max(1, int(round(float(factor))))
    return red, cell, z


def _formulas_from_ase_atoms(atoms) -> tuple[str, str, int]:
    """
    Extrait les formules depuis un objet ASE Atoms.

    Essaie pymatgen en premier (si disponible), sinon utilise
    _formulas_from_counts comme fallback.
    """
    cell = str(atoms.get_chemical_formula())
    try:
        from pymatgen.core import Composition  # type: ignore

        comp = Composition(str(atoms.symbols))
        red = str(comp.reduced_formula)
        _r, factor = comp.get_reduced_composition_and_factor()
        z = max(1, int(round(float(factor))))
        return red, cell, z
    except Exception:
        red, _cell_fallback, z = _formulas_from_counts(list(atoms.get_chemical_symbols()))
        return red, cell or _cell_fallback, z


def _formula_units_in_cell_pymatgen(structure) -> int:
    """Z = nb d’atomes / formule réduite (entier arrondi), min 1."""
    try:
        comp = structure.composition
        _red, factor = comp.get_reduced_composition_and_factor()
        fz = float(factor)
        if fz > 0 and math.isfinite(fz):
            return max(1, int(round(fz)))
    except Exception:
        pass
    return 1


def _formula_units_in_cell_ase(atoms) -> int:
    """
    Calcule Z (unités formulaires) depuis un objet ASE Atoms.

    Utilise pymatgen si disponible, sinon calcule par PGCD des comptages.
    """
    try:
        from pymatgen.core import Composition  # type: ignore

        f = str(atoms.symbols)
        comp = Composition(f)
        _red, factor = comp.get_reduced_composition_and_factor()
        fz = float(factor)
        if fz > 0 and math.isfinite(fz):
            return max(1, int(round(fz)))
    except Exception:
        pass
    try:
        n = len(atoms)
        if n <= 0:
            return 1
        sym = atoms.get_chemical_symbols()
        from math import gcd
        from functools import reduce

        ct: dict[str, int] = {}
        for s in sym:
            ct[s] = ct.get(s, 0) + 1
        g = reduce(gcd, ct.values()) if ct else 1
        base = sum(v // g for v in ct.values())
        return max(1, n // base) if base > 0 else 1
    except Exception:
        return 1


def _ibrav_from_sg(sg_number: int, hm_symbol: str):
    """
    Détermine ibrav, le système cristallin et le centrage à partir du groupe d'espace.

    Arguments :
        sg_number : Numéro de groupe d'espace (1-230)
        hm_symbol : Symbole Hermann-Mauguin (ex. "Pnma", "Fm-3m")

    Retourne :
        (ibrav, crystal_system, centering)
        ibrav = 0 si inconnu

    La correspondance suit la convention Quantum ESPRESSO :
    - ibrav 1-14 : réseaux de Bravais standards
    - ibrav 91 : orthorhombique centré A (cas spécial)
    - ibrav -3, -5, -9, -12, -13 : variantes avec origine différente
    """
    hm = (hm_symbol or "").strip()
    centering = (hm[0] if hm else "P").upper()
    if centering not in {"P", "F", "I", "C", "A", "B", "R"}:
        centering = "P"

    if 195 <= sg_number <= 230:
        if centering == "P":
            return 1, "cubic", centering
        if centering == "F":
            return 2, "cubic", centering
        if centering == "I":
            return 3, "cubic", centering
        return 1, "cubic", centering

    if 168 <= sg_number <= 194:
        return 4, "hexagonal", "P"

    if 143 <= sg_number <= 167:
        if centering == "R":
            return 5, "trigonal", "R"
        return 4, "trigonal", "P"

    if 75 <= sg_number <= 142:
        if centering == "I":
            return 7, "tetragonal", centering
        return 6, "tetragonal", "P"

    if 16 <= sg_number <= 74:
        if centering == "P":
            return 8, "orthorhombic", centering
        if centering == "C":
            return 9, "orthorhombic", centering
        if centering == "A":
            return 91, "orthorhombic", centering
        if centering == "F":
            return 10, "orthorhombic", centering
        if centering == "I":
            return 11, "orthorhombic", centering
        return 8, "orthorhombic", centering

    if 3 <= sg_number <= 15:
        if centering == "C":
            return 13, "monoclinic", centering
        if centering == "A":
            return 91, "monoclinic", centering
        return 12, "monoclinic", "P"

    if 1 <= sg_number <= 2:
        return 14, "triclinic", "P"

    return 0, "unknown", "P"


def _celldm_for_ibrav(ibrav: int, a: float, b: float, c: float,
                      alpha_deg: float, beta_deg: float, gamma_deg: float) -> dict:
    """
    Génère les paramètres celldm(1..6) pour l'input QE, cohérents avec l'ibrav.

    celldm(1) = a (en unités atomiques / Bohr)
    celldm(2) = b/a
    celldm(3) = c/a
    celldm(4) = cos(alpha)
    celldm(5) = cos(beta)
    celldm(6) = cos(gamma)

    Note : QE attend les longueurs en Bohr (a_au = a_Å / 0.529177), mais
    les rapports b/a et c/a sont sans dimension.
    """
    a_au = a * ANG_TO_BOHR
    cos_alpha = math.cos(math.radians(alpha_deg))
    cos_beta = math.cos(math.radians(beta_deg))
    cos_gamma = math.cos(math.radians(gamma_deg))

    cd: dict = {}
    if ibrav in (1, 2, 3, -3):
        cd[1] = a_au
    elif ibrav == 4:
        cd[1] = a_au
        cd[3] = (c / a) if a > 0 else 0.0
    elif ibrav in (5, -5):
        cd[1] = a_au
        cd[4] = cos_alpha
    elif ibrav in (6, 7):
        cd[1] = a_au
        cd[3] = (c / a) if a > 0 else 0.0
    elif ibrav in (8, 9, -9, 10, 11, 91):
        cd[1] = a_au
        cd[2] = (b / a) if a > 0 else 0.0
        cd[3] = (c / a) if a > 0 else 0.0
    elif ibrav in (12, -12, 13, -13):
        cd[1] = a_au
        cd[2] = (b / a) if a > 0 else 0.0
        cd[3] = (c / a) if a > 0 else 0.0
        if ibrav in (-12, -13):
            cd[5] = cos_beta
        else:
            cd[4] = cos_gamma
    elif ibrav == 14:
        cd[1] = a_au
        cd[2] = (b / a) if a > 0 else 0.0
        cd[3] = (c / a) if a > 0 else 0.0
        cd[4] = cos_alpha
        cd[5] = cos_beta
        cd[6] = cos_gamma
    return cd


def analysis_from_workflow_dict(d: dict) -> CifAnalysis:
    """
    Construit un CifAnalysis depuis les champs du workflow direct (UI Tab 1).
    Permet d'utiliser build_pw_input via /api/inputs/build sans fichier CIF.
    """
    ibrav = int(d.get("ibrav", 1) or 1)
    a = float(d.get("a", 5.0) or 5.0)
    b = float(d.get("b", a) or a)
    c = float(d.get("c", a) or a)

    def _angle_deg(key_deg: str, key_cos: str, default: float = 90.0) -> float:
        if d.get(key_deg) is not None:
            try:
                return float(d[key_deg])
            except (TypeError, ValueError):
                pass
        if d.get(key_cos) is not None:
            try:
                cv = float(d[key_cos])
                if -1.0 <= cv <= 1.0:
                    return math.degrees(math.acos(cv))
            except (TypeError, ValueError):
                pass
        return default

    alpha_deg = _angle_deg("alpha_deg", "cosab")
    beta_deg = _angle_deg("beta_deg", "cosac")
    gamma_deg = _angle_deg("gamma_deg", "cosbc")

    positions: list[tuple[str, float, float, float]] = []
    for site in (d.get("atomic_positions_crystal") or []):
        if isinstance(site, dict):
            positions.append((
                str(site.get("symbol", "X")),
                float(site.get("x", 0.0)),
                float(site.get("y", 0.0)),
                float(site.get("z", 0.0)),
            ))
        elif isinstance(site, (list, tuple)) and len(site) >= 4:
            positions.append((
                str(site[0]),
                float(site[1]),
                float(site[2]),
                float(site[3]),
            ))

    # Accepte ["Si", "O"] ou [{"symbol":"Si","mass":…,"pseudo":"…"}, …]
    species: list[str] = []
    for s in (d.get("atomic_species") or []):
        if isinstance(s, dict):
            sym = str(s.get("symbol") or s.get("label") or s.get("name") or "").strip()
            if sym and sym not in species:
                species.append(sym)
        else:
            sym = str(s).strip()
            if sym and not sym.startswith("{") and sym not in species:
                species.append(sym)
    if not species and positions:
        seen: list[str] = []
        for sym, _, _, _ in positions:
            if sym not in seen:
                seen.append(sym)
        species = seen

    nat = int(d.get("nat", len(positions)) or len(positions))
    ntyp = int(d.get("ntyp", len(species)) or len(species) or 1)
    celldm = _celldm_for_ibrav(ibrav, a, b, c, alpha_deg, beta_deg, gamma_deg)

    cell_a: list[tuple[float, float, float]] = []
    for row in (d.get("cell_parameters_angstrom") or []):
        if isinstance(row, (list, tuple)) and len(row) == 3:
            cell_a.append((float(row[0]), float(row[1]), float(row[2])))

    formula = str(d.get("formula") or d.get("prefix") or "material").strip() or "material"

    return CifAnalysis(
        formula=formula,
        formula_cell=str(d.get("formula_cell") or formula),
        spacegroup_number=int(d.get("spacegroup_number", 0) or 0),
        spacegroup_symbol=str(d.get("spacegroup_symbol", "")),
        crystal_system=str(d.get("crystal_system", "unknown")),
        centering=str(d.get("centering", "P")),
        ibrav=ibrav,
        a=a,
        b=b,
        c=c,
        alpha_deg=alpha_deg,
        beta_deg=beta_deg,
        gamma_deg=gamma_deg,
        celldm=celldm,
        nat=nat,
        ntyp=ntyp,
        atomic_species=species,
        atomic_positions_crystal=positions,
        cell_parameters_angstrom=cell_a,
        backend="workflow",
        notes=["analysis_from_workflow_dict"],
        formula_units_z=int(d.get("formula_units_z") or 1),
    )


# ── Ensemble des éléments chimiques magnétiques (portant un moment) ──
# Utilisé pour déterminer quelles espèces peuvent avoir un starting_magnetization
# non nul dans les calculs spin-polarisés.
# Inclut : terres rares (Gd→Yb, Ce→Eu), métaux de transition 3d (Fe→V), La.
_MAGNETIC_ELEMENTS = frozenset({
    "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Ce", "Pr", "Nd", "Sm", "Eu",
    "Fe", "Co", "Ni", "Mn", "Cr", "V", "La",
})


def _chem_base_symbol(sym: str) -> str:
    """
    Extrait le symbole chimique de base depuis un label d'espèce.

    Exemples :
      "Fe1" → "Fe"
      "Fe2" → "Fe"
      "Gd"  → "Gd"
      "V1"  → "V"

    Utile pour retrouver l'élément après un split AFM (X → X1/X2).
    """
    m = re.match(r"^([A-Z][a-z]?)", str(sym or "").strip())
    return m.group(1) if m else str(sym or "").strip()


def _is_magnetic_symbol(sym: str) -> bool:
    """
    Vérifie si un symbole correspond à un élément magnétique.
    Ignore les suffixes de split AFM (ex. "Fe1" → True car "Fe" ∈ _MAGNETIC_ELEMENTS).
    """
    return _chem_base_symbol(sym) in _MAGNETIC_ELEMENTS


def _is_afm_split_label(sym: str) -> bool:
    """
    Détecte si un label d'espèce est le résultat d'un split AFM.

    Exemples : "Fe1", "Fe2", "V1", "Gd2" → True
              "Fe", "Gd", "O" → False

    Utile pour ne pas re-scinder des espèces déjà séparées.
    """
    return bool(re.match(r"^[A-Z][a-z]?[12]$", str(sym or "").strip()))


def _wrap_frac(v: float) -> float:
    """
    Normalise une coordonnée fractionnaire dans [0, 1).

    Gère les valeurs négatives (ex. -0.1 → 0.9) et les valeurs
    très proches de 1.0 qui doivent être ramenées à 0.0.
    """
    x = float(v) % 1.0
    if x < 0.0:
        x += 1.0
    if abs(x - 1.0) < 1e-8:
        x = 0.0
    return x


def _normalize_afm_type(afm_type: Optional[str]) -> str:
    """
    Normalise les aliases UI/API : afm-g → afm_g, AFM_G → afm_g, afm → afm_g.
    """
    afm = str(afm_type or "afm_g").strip().lower().replace("-", "_").replace(" ", "_")
    if not afm.startswith("afm"):
        return "afm_g"
    if afm in ("afm", "afm_gtype", "afm_g_type", "g_type", "gtype"):
        return "afm_g"
    if afm in ("afm_a", "afm_atype", "afm_a_type"):
        return "afm_a"
    if afm in ("afm_c", "afm_ctype", "afm_c_type"):
        return "afm_c"
    if afm in ("afm_e", "afm_etype", "afm_e_type"):
        return "afm_e"
    # afm_g / afm_a / afm_c / afm_e déjà normalisés
    if afm in ("afm_g", "afm_a", "afm_c", "afm_e"):
        return afm
    # Préfixe afm_* inconnu → G-type (comportement historique sûr)
    return "afm_g"


def _afm_sublattice_index(x: float, y: float, z: float, afm_type: str) -> int:
    """
    Détermine l'indice de sous-réseau magnétique (0 ou 1) selon le type d'ordre AFM.

    Les coordonnées sont en repère cristallin (fractionnaire). Le calcul utilise
    la parité des coordonnées normalisées pour assigner chaque site à un sous-réseau.

    Types AFM supportés :
      - afm_g (ou afm / afm-g) : motif G-type (alternance selon x+y)
      - afm_a : motif A-type (alternance selon z)
      - afm_c : motif C-type (alternance selon x)
      - afm_e : motif E-type (alternance selon x+y+z)

    Exemple (afm_g) :
      (0.0, 0.0, 0.0) → sous-réseau 0
      (0.5, 0.0, 0.0) → sous-réseau 1
    """
    afm = _normalize_afm_type(afm_type)
    fx, fy, fz = _wrap_frac(x), _wrap_frac(y), _wrap_frac(z)
    eps = 1e-5
    if afm == "afm_g":
        return (int((fx + eps) * 2) + int((fy + eps) * 2)) % 2
    if afm == "afm_a":
        return int((fz + eps) * 2) % 2
    if afm == "afm_c":
        return int((fx + eps) * 2) % 2
    if afm == "afm_e":
        return (int((fx + eps) * 2) + int((fy + eps) * 2) + int((fz + eps) * 2)) % 2
    return 0


# ── Ensembles pour la détection des sites dans les pérovskites ──

# Terres rares (incluant Y) — utilisées en site A des pérovskites ABO3
_RARE_EARTH = frozenset({
    "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho",
    "Er", "Tm", "Yb", "Lu", "Y",
})
# Métaux de transition 3d (site B des pérovskites) — candidats au split AFM
_BSITE_TM = frozenset({"V", "Cr", "Mn", "Fe", "Co", "Ni"})


def _count_element_positions(cif: CifAnalysis, element: str, *, unsplit_only: bool = False) -> int:
    """
    Compte le nombre de positions atomiques d'un élément donné.

    Arguments :
        cif : Analyse CIF à examiner
        element : Symbole chimique de base (ex. "V", "Fe")
        unsplit_only : Si True, ignore les espèces déjà scindées (Fe1, Fe2)

    Retourne :
        Nombre d'atomes de cet élément dans la maille
    """
    el = str(element or "").strip()
    n = 0
    for sym, _x, _y, _z in cif.atomic_positions_crystal:
        if _chem_base_symbol(sym) != el:
            continue
        if unsplit_only and _is_afm_split_label(sym):
            continue
        n += 1
    return n


def detect_perovskite_bsite_element(cif: CifAnalysis) -> Optional[str]:
    """
    Détecte l'élément du site B dans une pérovskite/oxyde.

    Stratégie :
      1. Vérifie la présence d'oxygène (indice d'un oxyde)
      2. Cherche les métaux de transition (V, Cr, Mn, Fe, Co, Ni) non scindés
      3. S'il y en a plusieurs, priorité : V > Fe > Mn > Co > Ni > Cr

    Retourne :
        Le symbole de l'élément du site B, ou None si non détecté
    """
    bases = {_chem_base_symbol(s) for s in cif.atomic_species}
    if "O" not in bases:
        return None
    unsplit_tms: list[str] = []
    for s in cif.atomic_species:
        base = _chem_base_symbol(s)
        if base in _BSITE_TM and not _is_afm_split_label(s) and base not in unsplit_tms:
            unsplit_tms.append(base)
    if len(unsplit_tms) == 1:
        return unsplit_tms[0]
    if len(unsplit_tms) > 1:
        for pref in ("V", "Fe", "Mn", "Co", "Ni", "Cr"):
            if pref in unsplit_tms:
                return pref
    return None


def should_use_perovskite_bsite_split(cif: CifAnalysis, afm_type: str) -> bool:
    """
    Détermine s'il faut appliquer le split AFM sur le site B d'une pérovskite.

    Conditions requises :
      - Le type d'ordre magnétique commence par "afm"
      - Les espèces ne sont pas déjà scindées (pas de X1/X2)
      - Un site B est détecté (élément de transition + oxygène)
      - Il y a au moins 2 atomes du site B dans la maille
    """
    afm = _normalize_afm_type(afm_type)
    if not str(afm_type or "").strip().lower().startswith("afm"):
        return False
    if any(_is_afm_split_label(s) for s in cif.atomic_species):
        return False
    bsite = detect_perovskite_bsite_element(cif)
    if not bsite:
        return False
    return _count_element_positions(cif, bsite, unsplit_only=True) >= 2


def apply_afm_perovskite_bsite_split(cif: CifAnalysis, afm_type: str) -> CifAnalysis:
    """
    Scinde l'ion du site B (V, Fe, Mn...) en deux espèces X1/X2 pour les calculs AFM.

    Utile pour les pérovskites type RVO₃, LaFeO₃ où le site B (V, Fe) porte
    le moment magnétique et doit être séparé en deux sous-réseaux pour un
    ordre antiferromagnétique colinéaire.

    Exemple : V → V1 (spin up) et V2 (spin down)

    Note : nécessite une maille avec au moins 2 atomes du site B, sinon
    une supercellule est requise.
    """
    if not str(afm_type or "").strip().lower().startswith("afm"):
        return cif
    afm = _normalize_afm_type(afm_type)
    if any(_is_afm_split_label(s) for s in cif.atomic_species):
        cif.notes.append("AFM split site B : X1/X2 déjà présents — étape ignorée.")
        return cif

    bsite = detect_perovskite_bsite_element(cif)
    if not bsite:
        cif.notes.append("AFM split site B ignoré : pas d'ion B (V/Fe/Mn…) + O détecté.")
        return cif
    if _count_element_positions(cif, bsite, unsplit_only=True) < 2:
        cif.notes.append(
            f"AFM split site B ignoré : un seul {bsite} dans la maille — supercellule requise."
        )
        return cif

    orig_species = list(cif.atomic_species)
    orig_positions = list(cif.atomic_positions_crystal)
    new_positions: list = []
    count = [0, 0]
    for sym, x, y, z in orig_positions:
        if _chem_base_symbol(sym) == bsite and not _is_afm_split_label(sym):
            sub = _afm_sublattice_index(x, y, z, afm)
            new_sym = f"{bsite}{sub + 1}"
            count[sub] += 1
            new_positions.append((new_sym, x, y, z))
        else:
            new_positions.append((sym, x, y, z))

    if count[0] == 0 or count[1] == 0:
        cif.notes.append(
            f"AFM split site B ({afm}) : motif {bsite} incomplet (+:{count[0]}, −:{count[1]}) "
            "— autre ordre AFM ou supercellule."
        )
        return cif

    new_species: list = []
    for s in orig_species:
        b = _chem_base_symbol(s)
        if b not in _BSITE_TM and b != "O" and s not in new_species:
            new_species.append(s)
    if f"{bsite}1" not in new_species:
        new_species.extend([f"{bsite}1", f"{bsite}2"])
    for s in orig_species:
        if _chem_base_symbol(s) == "O" and s not in new_species:
            new_species.append(s)

    cif.atomic_species = new_species
    cif.atomic_positions_crystal = new_positions
    cif.ntyp = len(new_species)
    cif.nat = len(new_positions)
    cif.notes.append(
        f"AFM split site B ({afm}) : {bsite} → {bsite}1 (+, {count[0]} at.) "
        f"et {bsite}2 (−, {count[1]} at.) ; site A → starting_mag = 0."
    )
    return cif


def apply_afm_species_split(cif: CifAnalysis, afm_type: str) -> CifAnalysis:
    """
    Duplique une espèce magnétique unique en X1/X2 selon le motif AFM.

    Cas d'usage : matériaux avec une seule espèce magnétique (ex. Fe, Gd)
    après construction d'une supercellule. Chaque atome est assigné à un
    sous-réseau (+ ou -) selon sa position et le type d'ordre AFM.

    Différence avec apply_afm_perovskite_bsite_split :
      - Générique : fonctionne avec n'importe quel élément magnétique
      - Ne nécessite pas la présence d'oxygène
      - Utilisé en fallback quand le split pérovskite n'est pas applicable
    """
    if not str(afm_type or "").strip().lower().startswith("afm"):
        return cif
    afm = _normalize_afm_type(afm_type)

    if any(_is_afm_split_label(s) for s in cif.atomic_species):
        cif.notes.append("AFM split : espèces X1/X2 déjà présentes — étape ignorée.")
        return cif

    mag_bases: list[str] = []
    for s in cif.atomic_species:
        base = _chem_base_symbol(s)
        if _is_magnetic_symbol(base) and base not in mag_bases:
            mag_bases.append(base)

    if len(mag_bases) != 1:
        cif.notes.append(
            f"AFM split ignoré : {len(mag_bases)} type(s) magnétique(s) "
            f"({', '.join(mag_bases) or 'aucun'}) — split auto si une seule espèce (ex. Fe)."
        )
        return cif

    base = mag_bases[0]
    orig_species = list(cif.atomic_species)
    orig_positions = list(cif.atomic_positions_crystal)
    new_positions: list = []
    count = [0, 0]
    for sym, x, y, z in orig_positions:
        if _chem_base_symbol(sym) == base:
            sub = _afm_sublattice_index(x, y, z, afm)
            new_sym = f"{base}{sub + 1}"
            count[sub] += 1
            new_positions.append((new_sym, x, y, z))
        else:
            new_positions.append((sym, x, y, z))

    if count[0] == 0 or count[1] == 0:
        cif.notes.append(
            f"AFM split ({afm}) : maille insuffisante pour {base} "
            f"(sous-réseaux +:{count[0]}, −:{count[1]}) — supercellule requise."
        )
        return cif

    new_species = [f"{base}1", f"{base}2"]
    for s in orig_species:
        if _chem_base_symbol(s) != base and s not in new_species:
            new_species.append(s)

    cif.atomic_species = new_species
    cif.atomic_positions_crystal = new_positions
    cif.ntyp = len(new_species)
    cif.nat = len(new_positions)
    cif.notes.append(
        f"AFM split ({afm}) : {base} → {base}1 (sous-réseau +, {count[0]} at.) "
        f"et {base}2 (sous-réseau −, {count[1]} at.) pour starting_magnetization opposés."
    )
    return cif


def _mass_for_species(sp: str) -> float:
    """
    Récupère la masse atomique d'une espèce chimique.

    Gère les labels scindés (Fe1 → masse de Fe) et les espèces standards.
    Utilise le dictionnaire ATOMIC_MASSES défini en fin de module.
    """
    if sp in ATOMIC_MASSES:
        return ATOMIC_MASSES[sp]
    base = _chem_base_symbol(sp)
    return ATOMIC_MASSES.get(base, 0.0)


def _pseudo_for_species(sp: str, pseudos: dict) -> str:
    """
    Détermine le fichier de pseudopotentiel pour une espèce donnée.

    Logique :
      1. Cherche l'espèce directement (ex. "Fe1")
      2. Cherche le symbole de base (ex. "Fe")
      3. Pour les labels AFM (Fe1), génère "Fe.upf"
      4. Fallback : "{symbole}.upf"
    """
    if sp in pseudos:
        return pseudos[sp]
    base = _chem_base_symbol(sp)
    if base in pseudos:
        return pseudos[base]
    if _is_afm_split_label(sp):
        return f"{base}.upf"
    return pseudos.get(sp, f"{sp}.upf")


def _apply_supercell_pymatgen(structure, supercell_matrix, notes: list):
    """
    Applique une matrice de supercellule 3×3 à une structure pymatgen.

    Utile pour créer des mailles suffisamment grandes pour les ordres AFM
    (ex. une supercellule 2×2×1 double le nombre d'atomes dans le plan xy).

    Args :
        structure : Structure pymatgen d'entrée
        supercell_matrix : Matrice 3×3 d'entiers (ex. [[2,0,0],[0,2,0],[0,0,1]])
        notes : Liste de messages pour tracer l'opération
    """
    import numpy as np

    sm = np.array(supercell_matrix, dtype=int).reshape(3, 3)
    new_s = structure.make_supercell(sm)
    notes.append(
        f"Supercell magnétique appliquée : matrice {sm.tolist()} → {len(new_s)} atomes."
    )
    return new_s


def analyze_cif(
    cif_path,
    sg_symprec: float = 1e-3,
    primitive: bool = False,
    supercell_matrix=None,
    afm_type: Optional[str] = None,
    afm_split_sublattices: bool = False,
) -> CifAnalysis:
    """Analyse un .cif → CifAnalysis. Essaie pymatgen, sinon ase+spglib.

    ``primitive`` : True = petite maille primitive (plus d atomes dans le jeu de données général),
    False = maille standard « conventionnelle » (réglage attendu avec le menu frontend par défaut).

    ``supercell_matrix`` : matrice 3×3 entière (ex. [[2,0,0],[0,2,0],[0,0,1]]) pour ordres AFM.

    ``afm_split_sublattices`` : si True et une seule espèce magnétique, scinde X → X1/X2.
    """
    cif_path = Path(cif_path)
    if not cif_path.is_file():
        raise FileNotFoundError(str(cif_path))

    res: Optional[CifAnalysis] = None
    notes: list = []
    notes.append(
        "Réglage demandé : maille "
        + ("primitive (réduction)." if primitive else "conventionnelle standard (HG).")
    )

    try:
        from pymatgen.io.cif import CifParser  # type: ignore
        from pymatgen.symmetry.analyzer import SpacegroupAnalyzer  # type: ignore

        try:
            parser = CifParser(str(cif_path), occupancy_tolerance=100)
        except TypeError:
            parser = CifParser(str(cif_path))
        try:
            structures = parser.parse_structures(primitive=False)
        except Exception:
            structures = parser.get_structures(primitive=False)
        if not structures:
            raise ValueError("pymatgen : aucun bloc structural exploitable dans le CIF.")
        structure = structures[0]

        # 1ère étape commune : aligner primitive vs conventionnelle avec spglib
        # (robuste vs mélanges pymatgen / fichier CIF, et cohérent avec la branche ASE pure).
        converted_spglib = False
        try:
            import numpy as np
            import spglib as _sgl_std
            from ase import Atoms as _AtomsStd  # type: ignore
            from pymatgen.io.ase import AseAtomsAdaptor  # type: ignore

            zs_arr = np.array([site.specie.Z for site in structure], dtype="intc")
            lat_arr = np.asarray(structure.lattice.matrix, dtype=float)
            frac_arr = np.asarray(structure.frac_coords, dtype=float)
            cell_tuple_std = (lat_arr, frac_arr, zs_arr)
            sc_std = _sgl_std.standardize_cell(
                cell_tuple_std,
                to_primitive=bool(primitive),
                symprec=sg_symprec,
            )
            if sc_std is not None:
                lm_s, frac_s, zn_s = sc_std
                atoms_std = _AtomsStd(
                    numbers=np.asarray(zn_s).ravel(),
                    scaled_positions=np.asarray(frac_s),
                    cell=np.asarray(lm_s),
                    pbc=True,
                )
                structure = AseAtomsAdaptor().get_structure(atoms_std)
                converted_spglib = True
                notes.append(
                    "maille : "
                    + ("primitive" if primitive else "conventionnelle standard")
                    + " via spglib.standardize_cell()"
                )
        except Exception as e_sg_mix:
            notes.append(f"spglib.standardize_cell (voie pymatgen) ignoré ({e_sg_mix}).")

        if not converted_spglib:
            sga_src = SpacegroupAnalyzer(structure, symprec=sg_symprec)
            # Repli ancien comportement pymatgen seul
            if primitive:
                prim_ok = False
                try:
                    structure = sga_src.get_primitive_standard_structure()
                    prim_ok = True
                except Exception as e_prim:
                    notes.append(
                        f"pymatgen : get_primitive_standard_structure() indisponible ({e_prim}) ; "
                        "repli Structure.get_primitive_structure()."
                    )
                    try:
                        structure = structure.get_primitive_structure(symprec=sg_symprec)
                        prim_ok = True
                    except Exception as e_prim2:
                        notes.append(f"pymatgen : get_primitive_structure() échoué ({e_prim2}).")
                if not prim_ok:
                    try:
                        import numpy as np
                        import spglib as _sgl

                        zs = np.asarray([site.specie.Z for site in structure], dtype="intc")
                        fc = np.asarray(structure.frac_coords, dtype=float)
                        lat_m = np.asarray(structure.lattice.matrix, dtype=float)
                        tup = (lat_m, fc, zs)
                        prim_cell = _sgl.standardize_cell(tup, to_primitive=True, symprec=sg_symprec)
                        if prim_cell is not None:
                            lm2, sco, zn2 = prim_cell
                            from ase import Atoms as _Atoms  # type: ignore

                            ase_at = _Atoms(
                                numbers=np.asarray(zn2).ravel(),
                                scaled_positions=np.asarray(sco),
                                cell=np.asarray(lm2),
                                pbc=True,
                            )
                            from pymatgen.io.ase import AseAtomsAdaptor  # type: ignore

                            structure = AseAtomsAdaptor().get_structure(ase_at)
                            prim_ok = True
                            notes.append("maille primitive : spglib + pymatgen (via ASE).")
                    except Exception as e_sp_fallback:
                        notes.append(f"repli primitive spglib+pymatgen impossible ({e_sp_fallback}).")

                if not prim_ok:
                    notes.append(
                        "La maille brute extraite du CIF peut encore être conventionnelle. "
                        "Vérifiez le fichier ou installez ase+pymatgen.io.ase pour le repli spglib → pymatgen."
                    )
                sga = SpacegroupAnalyzer(structure, symprec=sg_symprec)
            else:
                try:
                    structure = sga_src.get_conventional_standard_structure()
                except Exception as e_conv:
                    notes.append(
                        f"pymatgen : get_conventional_standard_structure() indisponible ({e_conv}). "
                        "Maille brute du fichier conservée."
                    )
                sga = SpacegroupAnalyzer(structure, symprec=sg_symprec)
        else:
            sga = SpacegroupAnalyzer(structure, symprec=sg_symprec)
        if supercell_matrix is not None:
            structure = _apply_supercell_pymatgen(structure, supercell_matrix, notes)
            sga = SpacegroupAnalyzer(structure, symprec=sg_symprec)
        sg_number = int(sga.get_space_group_number())
        sg_symbol = str(sga.get_space_group_symbol())
        crystal_system_pm = str(sga.get_crystal_system())

        ibrav, sys_name, centering = _ibrav_from_sg(sg_number, sg_symbol)
        if sys_name == "unknown":
            sys_name = crystal_system_pm

        lattice = structure.lattice
        a = float(lattice.a)
        b = float(lattice.b)
        c = float(lattice.c)
        alpha = float(lattice.alpha)
        beta = float(lattice.beta)
        gamma = float(lattice.gamma)
        cd = _celldm_for_ibrav(ibrav, a, b, c, alpha, beta, gamma)

        species_str: list = []
        for sp in structure.species:
            sym = getattr(sp, "symbol", None) or str(sp)
            species_str.append(str(sym))
        seen: list = []
        for s in species_str:
            if s not in seen:
                seen.append(s)
        atomic_species = seen

        atomic_positions = []
        for sym, frac in zip(species_str, structure.frac_coords):
            atomic_positions.append((sym, float(frac[0]), float(frac[1]), float(frac[2])))

        cell_a = [tuple(float(x) for x in row) for row in lattice.matrix]

        z_cell = _formula_units_in_cell_pymatgen(structure)
        formula_red, formula_cell, _z2 = _formulas_from_pymatgen_structure(structure)
        if z_cell <= 0:
            z_cell = _z2
        notes.append(
            f"Z (formules réduites dans cette maille) ≈ {z_cell} pour {len(structure)} atomes au total."
        )
        notes.append(
            f"Formule réduite : {formula_red} · composition maille : {formula_cell}."
        )

        res = CifAnalysis(
            formula=formula_red,
            formula_cell=formula_cell,
            spacegroup_number=sg_number,
            spacegroup_symbol=sg_symbol,
            crystal_system=sys_name,
            centering=centering,
            ibrav=ibrav,
            a=a, b=b, c=c,
            alpha_deg=alpha, beta_deg=beta, gamma_deg=gamma,
            celldm=cd,
            nat=len(structure),
            ntyp=len(atomic_species),
            atomic_species=atomic_species,
            atomic_positions_crystal=atomic_positions,
            cell_parameters_angstrom=cell_a,
            backend="pymatgen",
            notes=list(notes),
            formula_units_z=z_cell,
        )
    except Exception as e_pm:
        notes.append(f"pymatgen indisponible / erreur : {e_pm}")

    if res is None:
        try:
            from ase.io import read as ase_read  # type: ignore
            import spglib  # type: ignore

            atoms = ase_read(str(cif_path))
            try:
                import numpy as np

                tup_std = (
                    atoms.get_cell(),
                    atoms.get_scaled_positions(),
                    atoms.get_atomic_numbers(),
                )
                std_cell = spglib.standardize_cell(
                    tup_std,
                    to_primitive=bool(primitive),
                    symprec=sg_symprec,
                )
                if std_cell is not None:
                    lat_m, frac_n, zs_n = std_cell
                    from ase import Atoms as _Atoms  # type: ignore

                    atoms = _Atoms(
                        numbers=np.asarray(zs_n).ravel(),
                        scaled_positions=np.asarray(frac_n),
                        cell=np.asarray(lat_m),
                        pbc=True,
                    )
                    notes.append(
                        "ase : maille "
                        + ("primitive (spglib.standardize_cell)."
                           if primitive else "conventionnelle standard (spglib.standardize_cell).")
                    )
                else:
                    notes.append("spglib.standardize_cell a renvoyé None ; maille brute du CIF conservée.")
            except Exception as e_st:
                notes.append(f"spglib.standardize_cell : {e_st}")

            if supercell_matrix is not None:
                import numpy as np
                from ase.build import make_supercell as ase_make_supercell  # type: ignore

                sm = np.array(supercell_matrix, dtype=int).reshape(3, 3)
                atoms = ase_make_supercell(atoms, sm)
                notes.append(
                    f"Supercell magnétique appliquée (ASE) : {sm.tolist()} → {len(atoms)} atomes."
                )

            cell = atoms.get_cell()
            scaled = atoms.get_scaled_positions()
            atomic_numbers = atoms.get_atomic_numbers()
            spg_input = (cell, scaled, atomic_numbers)
            dataset = spglib.get_symmetry_dataset(spg_input, symprec=sg_symprec)
            if dataset is None:
                raise RuntimeError("spglib : impossible de déterminer la symétrie.")
            try:
                sg_number = int(dataset.number)
                sg_symbol = str(dataset.international)
            except AttributeError:
                sg_number = int(dataset["number"])
                sg_symbol = str(dataset["international"])

            ibrav, sys_name, centering = _ibrav_from_sg(sg_number, sg_symbol)
            a, b, c, alpha, beta, gamma = [float(x) for x in cell.cellpar()]
            cd = _celldm_for_ibrav(ibrav, a, b, c, alpha, beta, gamma)

            symbols = atoms.get_chemical_symbols()
            seen2: list = []
            for s in symbols:
                if s not in seen2:
                    seen2.append(s)
            atomic_species = seen2
            atomic_positions = []
            for sym, p in zip(symbols, scaled):
                atomic_positions.append((sym, float(p[0]), float(p[1]), float(p[2])))
            cell_a = [tuple(float(x) for x in row) for row in cell]

            z_cell = _formula_units_in_cell_ase(atoms)
            formula_red, formula_cell, _z2 = _formulas_from_ase_atoms(atoms)
            if z_cell <= 0:
                z_cell = _z2
            notes.append(
                f"Z (formules réduites dans cette maille) ≈ {z_cell} pour {len(atoms)} atomes au total."
            )
            notes.append(
                f"Formule réduite : {formula_red} · composition maille : {formula_cell}."
            )

            res = CifAnalysis(
                formula=formula_red,
                formula_cell=formula_cell,
                spacegroup_number=sg_number,
                spacegroup_symbol=sg_symbol,
                crystal_system=sys_name,
                centering=centering,
                ibrav=ibrav,
                a=a, b=b, c=c,
                alpha_deg=alpha, beta_deg=beta, gamma_deg=gamma,
                celldm=cd,
                nat=len(atoms),
                ntyp=len(atomic_species),
                atomic_species=atomic_species,
                atomic_positions_crystal=atomic_positions,
                cell_parameters_angstrom=cell_a,
                backend="ase+spglib",
                notes=list(notes),
                formula_units_z=z_cell,
            )
        except Exception as e_ase:
            notes.append(f"ase/spglib indisponible / erreur : {e_ase}")

    if res is None:
        raise RuntimeError(
            "Aucune bibliothèque utilisable. Installez : "
            "pip install pymatgen   (ou)   pip install ase spglib   |   "
            + " | ".join(notes)
        )
    if afm_type and str(afm_type).lower().startswith("afm"):
        if should_use_perovskite_bsite_split(res, afm_type):
            res = apply_afm_perovskite_bsite_split(res, afm_type)
        elif afm_split_sublattices:
            res = apply_afm_species_split(res, afm_type)
    return res


DEFAULT_ECUTWFC = 60.0
DEFAULT_ECUTRHO = 480.0
DEFAULT_KGRID = (8, 8, 8)


def _hubbard_lines_for_system(
    species,
    hubbard_u,
    hubbard_j0,
    hubbard_kind,
    hubbard_projection,
    *,
    legacy_verbose: bool = False,
):
    """Bloc DFT+U syntaxe legacy (Hubbard_U(i)/Hubbard_J0(i)) dans &SYSTEM.

    Réservé aux entrées **pré-carte HUBBARD** (QE < 7.3.1) ou reproduction d'anciens fichiers.
    En **QE 7.5**, préférer la carte ``HUBBARD`` (pas de ``lda_plus_u`` / ``lda_plus_u_kind`` dans &SYSTEM).

    Par défaut (legacy_verbose=False) : seulement ``lda_plus_u = .true.`` + les Hubbard_U/J0.
    Si legacy_verbose=True, ajoute lda_plus_u_kind et U_projection_type (gabarits très anciens).
    """
    if not hubbard_u:
        return []
    u_clean = {}
    for sym, val in hubbard_u.items():
        try:
            vf = float(val)
        except (TypeError, ValueError):
            continue
        if vf == 0.0:
            continue
        u_clean[str(sym)] = vf
    if not u_clean:
        return []
    j0_clean = {}
    for sym, val in (hubbard_j0 or {}).items():
        try:
            vf = float(val)
        except (TypeError, ValueError):
            continue
        if vf == 0.0:
            continue
        j0_clean[str(sym)] = vf
    proj = (hubbard_projection or "atomic").strip() or "atomic"
    out: list = ["  lda_plus_u = .true."]
    if legacy_verbose:
        out.extend(
            [
                f"  lda_plus_u_kind = {int(hubbard_kind)}",
                f"  U_projection_type = '{proj}'",
            ]
        )
    for idx, sym in enumerate(species, start=1):
        uval = _hubbard_u_for_species(sym, u_clean)
        if uval is not None and uval != 0.0:
            out.append(f"  Hubbard_U({idx}) = {uval:.6f}")
        jval = _hubbard_u_for_species(sym, j0_clean)
        if jval is not None and jval != 0.0:
            out.append(f"  Hubbard_J0({idx}) = {jval:.6f}")
    return out


def _effective_manifold_for_species(sym: str, fallback: str) -> str:
    """Manifold QE par étiquette d'espèce (Ln → 4f, TM 3d, etc.)."""
    fb = (fallback or "3d").strip() or "3d"
    m = re.match(r"([A-Za-z]+)", str(sym))
    if not m:
        return fb
    el = m.group(1)
    chem = el[0].upper() + el[1].lower() if len(el) > 1 else el.upper()
    lanth = {
        "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho",
        "Er", "Tm", "Yb", "Lu",
    }
    actin = {"Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr"}
    tm_3d = {
        "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
        "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd",
    }
    tm_4d = {"Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I", "Xe"}
    tm_5d = {"Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl", "Pb", "Bi"}
    chalc = {"O", "S", "Se", "Te"}
    if chem in lanth:
        return "4f"
    if chem in actin:
        return "5f"
    if chem in chalc:
        return "2p"
    if chem in tm_3d:
        return "3d"
    if chem in tm_5d:
        return "5d"
    if chem in tm_4d:
        return "4d"
    return fb


def _manifold_for_species(
    sym: str,
    fallback: str,
    manifolds: Optional[dict] = None,
) -> str:
    """Manifold explicite (UI) ou inféré par élément."""
    if manifolds:
        s = str(sym).strip()
        raw = manifolds.get(s) or manifolds.get(s.strip())
        if raw and str(raw).strip():
            return str(raw).strip()
        base = _chem_base_symbol(sym)
        if base:
            raw_b = manifolds.get(base)
            if raw_b and str(raw_b).strip():
                return str(raw_b).strip()
    return _effective_manifold_for_species(sym, fallback)


def _occ_letter_from_manifold(manifold: str) -> str:
    """Lettre Hubbard_occ ('f', 'd', 'p', 's') depuis un manifold type 4f / 3d."""
    m = (manifold or "3d").strip().lower()
    if m in ("f", "4f", "5f"):
        return "f"
    if m in ("d", "3d", "4d", "5d"):
        return "d"
    if m in ("p", "2p", "3p", "4p", "5p", "6p"):
        return "p"
    if m in ("s", "1s", "2s", "3s", "4s", "5s", "6s"):
        return "s"
    if len(m) == 1 and m in "spdf":
        return m
    if m.endswith("f"):
        return "f"
    if m.endswith("d"):
        return "d"
    if m.endswith("p"):
        return "p"
    return "d"


def _hubbard_card_orbital_label(sym: str, manifold: str) -> str:
    """
    Étiquette carte HUBBARD QE 7.5+ : ``Gd-4f``, ``V-3d`` (manifold complet).

    QE 7.5+ accepte ``Gd-f`` (lettre seule) mais le format recommandé
    utilise le manifold complet (ex. ``Gd-4f``, ``V-3d``, ``O-2p``).
    """
    return f"{sym}-{manifold}"


def _hubbard_card_system_lines(
    species,
    hubbard_u,
    hubbard_j0,
    hubbard_manifold,
    hubbard_manifolds: Optional[dict] = None,
):
    """Bloc &SYSTEM pour carte HUBBARD (QE 7.x) : lda_plus_u + Hubbard_occ(i)."""
    if not hubbard_u:
        return []
    u_clean: dict[str, float] = {}
    for sym, val in hubbard_u.items():
        try:
            vf = float(val)
        except (TypeError, ValueError):
            continue
        if vf == 0.0:
            continue
        u_clean[str(sym)] = vf
    if not u_clean:
        return []
    out: list = ["  lda_plus_u = .true."]
    for idx, sym in enumerate(species, start=1):
        if sym not in u_clean:
            continue
        manifold_use = _manifold_for_species(sym, hubbard_manifold, hubbard_manifolds)
        occ = _occ_letter_from_manifold(manifold_use)
        out.append(
            f"  Hubbard_occ({idx}) = '{occ}'  ! {sym}-{manifold_use}"
        )
    return out


def _hubbard_u_for_species(sym: str, hubbard_u: dict) -> Optional[float]:
    """U pour V1/V2 hérité de V, Fe1/Fe2 de Fe, etc."""
    if not hubbard_u:
        return None
    if sym in hubbard_u:
        try:
            return float(hubbard_u[sym])
        except (TypeError, ValueError):
            return None
    base = _chem_base_symbol(sym)
    if base in hubbard_u:
        try:
            return float(hubbard_u[base])
        except (TypeError, ValueError):
            return None
    return None


def _hubbard_card(
    species,
    hubbard_u,
    hubbard_j0,
    hubbard_manifold,
    hubbard_projection,
    hubbard_manifolds: Optional[dict] = None,
):
    """Carte HUBBARD (QE >= 7.3.1) a placer apres K_POINTS."""
    if not hubbard_u:
        return []
    manifold_default = (hubbard_manifold or "3d").strip() or "3d"
    proj_raw = (hubbard_projection or "ortho-atomic").strip() or "ortho-atomic"
    proj = re.sub(r"[^\w\-]", "", proj_raw)
    rows = []
    for sym in species:
        manifold_use = _manifold_for_species(sym, manifold_default, hubbard_manifolds)
        v = _hubbard_u_for_species(sym, hubbard_u)
        try:
            vf = float(v) if v is not None else None
        except (TypeError, ValueError):
            vf = None
        if vf is None or vf == 0.0:
            continue
        orb = _hubbard_card_orbital_label(sym, manifold_use)
        rows.append(f"U  {orb}  {vf:.6f}")
        vj = _hubbard_u_for_species(sym, hubbard_j0 or {})
        try:
            vjf = float(vj) if vj is not None else None
        except (TypeError, ValueError):
            vjf = None
        if vjf is not None and vjf != 0.0:
            rows.append(f"J0 {orb}  {vjf:.6f}")
    if not rows:
        return []
    return [f"HUBBARD ({proj})"] + rows + [""]


def _species_with_nonzero_hubbard(
    hubbard_u: Optional[dict], hubbard_j0: Optional[dict]
) -> set[str]:
    """Espèces (labels QE, ex. Ni / Ni1) qui ont Hubbard_U ou Hubbard_J0 non nul."""
    out: set[str] = set()
    for bucket in (hubbard_u, hubbard_j0):
        if not isinstance(bucket, dict):
            continue
        for k, val in bucket.items():
            sym = str(k).strip()
            if not sym:
                continue
            try:
                vf = float(val)
            except (TypeError, ValueError):
                continue
            if vf != 0.0:
                out.add(sym)
    return out


def _sanitize_input_dft(s: Optional[str]) -> Optional[str]:
    """Valeur sûre pour input_dft (QE) ou chaîne XC- Libxc."""
    from qe_input_dft_catalog import normalize_input_dft

    return normalize_input_dft(s)


def _default_start_mag(sym: str, fallback: float = 0.45) -> float:
    """Aimantation initiale typique par espèce (colinéaire)."""
    s = str(sym or "").strip()
    if not s:
        return 0.0
    m_split = re.match(r"^([A-Z][a-z]?)([12])$", s, re.I)
    if m_split:
        base, suf = m_split.group(1), m_split.group(2)
        if base.upper() == "V":
            return 0.5 if suf == "1" else -0.5
        mag = 0.5 if base.upper() in ("FE", "MN", "CO", "CR", "NI") else fallback
        return mag if suf == "1" else -abs(mag)
    if re.match(r"^(Gd|Tb|Dy|Ho|Er|Tm)$", s, re.I):
        return 0.0
    if re.match(r"^V$", s, re.I):
        return 0.3
    if re.match(r"^Ni$", s, re.I):
        return 0.31
    if re.match(r"^(Fe|Mn|Co|Cr|Eu|Sm|Nd)$", s, re.I):
        return 0.5
    return 0.0 if s in ("O", "H", "N", "C", "S", "P", "F", "Cl", "Ba", "Sr", "Ca", "La") else fallback


# ── Paramètres d'angles pour la magnétisation non colinéaire (nc + soc) ──
# Ces fonctions déterminent automatiquement angle1(θ) et angle2(φ) selon
# le type d'ordre magnétique et la symétrie cristalline du matériau.

def _noncolin_auto_angles(
    cif: CifAnalysis,
    *,
    afm_type: Optional[str] = None,
    angle1: Optional[dict[str, float]] = None,
    angle2: Optional[dict[str, float]] = None,
    nspin_val: int = 4,
    # start_mags: réservé pour usage futur (corrélation angle/moment)
    start_mags: Optional[dict[str, float]] = None,
) -> tuple[dict[str, float], dict[str, float]]:
    """
    Détermine automatiquement les angles θ (angle1) et φ (angle2) pour un
    calcul non colinéaire (nspin=4) en fonction du matériau.

    Logique d'auto-détection :
      1. Angles explicites > auto-détection
      2. AFM split (X1/X2) : collinéaire le long de Z
         → X1: θ=0, X2: θ=180 (spins opposés)
      3. Hexagonal/trigonal : motif 120° dans le plan XY
         → θ=90 pour tous, φ=0°, 120°, 240° par site
      4. Pérovskite AFM (site B non scindé) : motif G-type
         → θ/φ alternés selon la position cristallographique
      5. Par défaut : θ=0, φ=0 (FM le long de Z)

    Retourne :
        (angle1_dict, angle2_dict) avec les angles en degrés
    """
    nspin4 = nspin_val == 4
    out_a1: dict[str, float] = {}
    out_a2: dict[str, float] = {}

    # Angles explicites → priorité absolue
    if angle1 is not None:
        for sp in cif.atomic_species:
            if sp in angle1:
                out_a1[sp] = float(angle1[sp])
    if angle2 is not None:
        for sp in cif.atomic_species:
            if sp in angle2:
                out_a2[sp] = float(angle2[sp])

    # Si pas nspin=4, on ne génère pas d'angles auto
    if not nspin4:
        return out_a1, out_a2

    # Si tous les angles sont déjà explicites, on retourne
    all_done = all(sp in out_a1 and sp in out_a2 for sp in cif.atomic_species)
    if all_done:
        return out_a1, out_a2

    # Détection du type AFM
    afm = str(afm_type or "").strip().lower() if afm_type else None
    has_afm_split = any(_is_afm_split_label(sp) for sp in cif.atomic_species)

    # Détection du système cristallin
    crystal_sys = (cif.crystal_system or "").strip().lower()
    is_hex = crystal_sys in ("hexagonal", "trigonal")

    # Compte les espèces magnétiques (exclut automatiquement O, N, etc. via _MAGNETIC_ELEMENTS)
    mag_species = [sp for sp in cif.atomic_species if _is_magnetic_symbol(sp)]

    # ── Cas 2 : AFM split (X1/X2) → collinéaire selon Z ──
    if has_afm_split:
        for sp in cif.atomic_species:
            if sp not in out_a1:
                m = re.match(r"^([A-Z][a-z]?)([12])$", sp)
                if m:
                    suf = m.group(2)
                    out_a1[sp] = 0.0 if suf == "1" else 180.0
                    out_a2[sp] = 0.0
                else:
                    out_a1[sp] = 0.0
                    out_a2[sp] = 0.0
        # Completer les non-magnetiques
        for sp in cif.atomic_species:
            if sp not in out_a1:
                out_a1[sp] = 0.0
                out_a2[sp] = 0.0
        return out_a1, out_a2

    # ── Cas 3 : Hexagonal/trigonal → motif 120° dans XY ──
    if is_hex and len(mag_species) >= 1:
        # Si que 2 espèces magnétiques, 180° (AFM dans plan XY)
        if len(mag_species) == 2:
            out_a1[mag_species[0]] = 90.0
            out_a1[mag_species[1]] = 90.0
            out_a2[mag_species[0]] = 0.0
            out_a2[mag_species[1]] = 180.0
        else:
            hex_phis = [0.0, 120.0, 240.0]
            for i, sp in enumerate(mag_species[:3]):
                out_a1[sp] = 90.0
                out_a2[sp] = hex_phis[i % 3]
        # Compléter les autres espèces
        for sp in cif.atomic_species:
            if sp not in out_a1:
                out_a1[sp] = 0.0
                out_a2[sp] = 0.0
        return out_a1, out_a2

    # ── Cas 4 : AFM G-type (pérovskite) ──
    # Pour les pérovskites ABO3 non scindées mais AFM, les spins
    # peuvent être orientés automatiquement selon la position
    if afm and afm.startswith("afm"):
        bsite = detect_perovskite_bsite_element(cif)
        if bsite and bsite in mag_species:
            # Détection des atomes du site B et assignment d'angles alternés
            b_positions = []
            for sym, x, y, z in cif.atomic_positions_crystal:
                if _chem_base_symbol(sym) == bsite:
                    b_positions.append((sym, x, y, z))
            if len(b_positions) >= 2:
                for i, (sym, x, y, z) in enumerate(b_positions):
                    if sym not in out_a1:
                        # Alternance 0°/180° sur θ (collinéaire AFM en nc)
                        sub = _afm_sublattice_index(x, y, z, afm)
                        out_a1[sym] = 0.0 if sub == 0 else 180.0
                        out_a2[sym] = 0.0

    # ── Cas 5 : Défaut → FM le long de Z ──
    for sp in cif.atomic_species:
        if sp not in out_a1:
            out_a1[sp] = 0.0
            out_a2[sp] = 0.0

    return out_a1, out_a2


def build_pw_input(
    cif: CifAnalysis,
    calculation: str = "scf",
    prefix: Optional[str] = None,
    pseudo_dir: str = "./pseudos",
    outdir: str = "./out",
    ecutwfc: float = DEFAULT_ECUTWFC,
    ecutrho: float = DEFAULT_ECUTRHO,
    k_points=(8, 8, 8),
    pseudos: Optional[dict] = None,
    occupations: str = "smearing",
    smearing: str = "marzari-vanderbilt",
    degauss: float = 0.01,
    force_ibrav_zero: bool = False,
    ibrav_override: Optional[int] = None,
    hubbard_u: Optional[dict] = None,
    hubbard_j0: Optional[dict] = None,
    hubbard_syntax: str = "card",
    hubbard_legacy_verbose: bool = False,
    hubbard_kind: int = 0,
    hubbard_projection: str = "ortho-atomic",
    hubbard_manifold: str = "3d",
    hubbard_manifolds: Optional[dict] = None,
    input_dft: Optional[str] = None,
    *,
    # ── Paramètres magnétisme (QE 7.5+) ──
    nspin: Optional[int] = None,          # None = auto-détection, 1/2/4
    noncolin: Optional[bool] = None,      # None = auto (True si nspin=4)
    lspinorb: Optional[bool] = None,      # None = False, True = spin-orbite
    starting_magnetization: Optional[dict] = None,  # {espèce: valeur}
    # ── Angles non colinéaires nc+soc (QE 7.5+) ──
    angle1: Optional[dict[str, float]] = None,     # {espèce: θ en degrés} (0-180)
    angle2: Optional[dict[str, float]] = None,     # {espèce: φ en degrés} (0-360)
    # ── Paramètres d'ordre magnétique ──
    afm_type: Optional[str] = None,         # "afm_g", "afm_a", "afm_c", etc.
    # Paramètres hérités (hubbard_auto_spin conservé pour rétrocompatibilité)
    hubbard_auto_spin: bool = False,
    hubbard_starting_magnetization: float = 0.45,
    ion_dynamics: str = "bfgs",
    cell_dynamics: str = "bfgs",
    press: float = 0.0,
    press_conv_thr: Optional[float] = None,
    forc_conv_thr: float = 1.0e-4,
    mixing_beta: Optional[float] = None,
    nbnd: Optional[int] = None,
    md_tempw: float = 300.0,
    md_dt: float = 20.0,
    md_nstep: int = 1000,
    # ── Polarisation / charges de Born ──
    conv_thr: Optional[str] = None,
    diagonalization: Optional[str] = None,
    lberry: bool = False,
    lelfield: bool = False,
    nppstr: int = 8,
    nberrycyc: Optional[int] = None,
    gdir: int = 3,
) -> str:
    """Construit un input pw.x complet (ibrav auto, forcé à 0, ou surcharge utilisateur)."""
    if prefix is None:
        prefix = re.sub(r"[^A-Za-z0-9_]+", "_", cif.formula or "material") or "material"

    pseudos = pseudos or {sym: f"{sym}.upf" for sym in cif.atomic_species}

    if force_ibrav_zero:
        ibrav = 0
        celldm_out = dict(cif.celldm)
    elif ibrav_override is not None:
        iov = int(ibrav_override)
        if iov == 0:
            ibrav = 0
            celldm_out = dict(cif.celldm)
        else:
            ibrav = iov
            celldm_out = _celldm_for_ibrav(
                ibrav,
                cif.a,
                cif.b,
                cif.c,
                cif.alpha_deg,
                cif.beta_deg,
                cif.gamma_deg,
            )
    else:
        ibrav = cif.ibrav
        celldm_out = dict(cif.celldm)

    lines: list = []
    calc_raw = str(calculation or "scf").strip().lower()
    berry_mode = calc_raw == "scf_berry"
    born_scf_mode = calc_raw == "scf_born"
    if calc_raw in ("scf_berry", "scf_born"):
        calc_low = "scf"
        calc_out = "scf"
    else:
        calc_low = calc_raw
        calc_out = calc_raw
    lines.append("&CONTROL")
    lines.append(f"  calculation = '{calc_out}'")
    lines.append(f"  prefix      = '{prefix}'")
    if calc_low in ("nscf", "bands"):
        lines.append("  restart_mode= 'restart'")
    else:
        lines.append("  restart_mode= 'from_scratch'")
    lines.append(f"  pseudo_dir  = '{pseudo_dir}'")
    lines.append(f"  outdir      = '{outdir}'")
    lines.append("  verbosity   = 'high'")
    lines.append("  tprnfor     = .true.")
    lines.append("  tstress     = .true.")
    if calc_low in ("relax", "vc-relax"):
        lines.append(f"  forc_conv_thr = {forc_conv_thr:.1e}")
    if calc_low in ("md", "vc-md"):
        lines.append("  nstep = " + str(int(md_nstep)))
    lines.append("/")

    lines.append("&SYSTEM")
    try:
        _fz_mail = int(getattr(cif, "formula_units_z", 1) or 1)
    except (TypeError, ValueError):
        _fz_mail = 1
    if _fz_mail > 1:
        _fml_red = str(cif.formula or "").strip() or "?"
        _fml_cell = str(getattr(cif, "formula_cell", "") or "").strip() or _fml_red
        lines.append(
            f"  ! Interface-QE: formule reduite {_fml_red} ; Z ~ {_fz_mail} dans la maille "
            f"({_fml_cell}, {cif.nat} atomes)."
        )
        lines.append(
            "  ! Rappel: la primitive cristallo. (spglib) peut contenir plusieurs unites formula; ibrav + celldm decrivent la meme maille, pas une seule formule chimique minimale."
        )
    lines.append(f"  ibrav = {ibrav}")
    if ibrav != 0:
        for k in sorted(celldm_out.keys()):
            lines.append(f"  celldm({k}) = {celldm_out[k]:.10f}")
    lines.append(f"  nat   = {cif.nat}")
    lines.append(f"  ntyp  = {cif.ntyp}")
    lines.append(f"  ecutwfc = {ecutwfc}")
    lines.append(f"  ecutrho = {ecutrho}")
    if calc_low == "nscf":
        occ_nscf = "tetrahedra"
        lines.append(f"  occupations = '{occ_nscf}'")
    else:
        lines.append(f"  occupations = '{occupations}'")
        if occupations == "smearing":
            lines.append(f"  smearing    = '{smearing}'")
            lines.append(f"  degauss     = {degauss}")
    nbnd_val = nbnd
    if nbnd_val is None and calc_low in ("nscf", "bands"):
        try:
            from qe_input_builders import estimate_nbnd
            nbnd_val = estimate_nbnd(cif.nat, cif.ntyp)
        except ImportError:
            nbnd_val = max(8, int(cif.nat or 1) * 8)
    if nbnd_val is not None and calc_low in ("nscf", "bands"):
        lines.append(f"  nbnd = {int(nbnd_val)}")
    # ── Magnetisme : nspin, noncolin, lspinorb, starting_magnetization ──
    # Determine nspin de maniere auto si non fourni explicitement
    hu_syms = _species_with_nonzero_hubbard(hubbard_u, hubbard_j0)
    if nspin is not None and nspin in (1, 2, 4):
        nspin_val = nspin
    elif noncolin is True:
        nspin_val = 4
    elif hubbard_auto_spin and hu_syms:
        nspin_val = 2
    elif any(_is_afm_split_label(sp) for sp in cif.atomic_species):
        nspin_val = 2
    else:
        nspin_val = 1

    # Determine noncolin / lspinorb (auto si non fourni)
    noncolin_val = bool(noncolin) if noncolin is not None else (nspin_val == 4)
    lspinorb_val = bool(lspinorb) if lspinorb is not None else False

    # ═══════════════════════════════════════════════════════════════════
    # Auto-détection : pseudos .rel- (fully relativistic) → noncolin forcé
    # ═══════════════════════════════════════════════════════════════════
    # QE 7.5 n'accepte PAS nspin=2 avec des pseudopotentiels full-relativistic (.rel-).
    # Si un pseudo contient ".rel-", on force noncolin=.true. et on supprime nspin.
    _has_rel_pseudo = any(".rel-" in str(p).lower() for p in pseudos.values())
    if _has_rel_pseudo and not noncolin_val:
        noncolin_val = True
        lspinorb_val = True   # Les pseudos .rel- impliquent le couplage spin-orbite
        nspin_val = 4          # logique interne ; n'est PAS écrit comme nspin=4 dans l'output

    # Construit le dictionnaire des starting_magnetization explicites
    start_mags: dict[str, float] = {}
    if starting_magnetization is not None:
        for sp in cif.atomic_species:
            if sp in starting_magnetization:
                try:
                    v = float(starting_magnetization[sp])
                    if v != 0.0:
                        start_mags[sp] = v
                except (TypeError, ValueError):
                    pass

    # Auto-detection starting_magnetization pour les especes scindees AFM (X1/X2)
    # Ex: V1 → +0.5, V2 → −0.5
    if nspin_val >= 2:
        for sp in cif.atomic_species:
            if _is_afm_split_label(sp) and sp not in start_mags:
                m_split = re.match(r"^([A-Z][a-z]?)([12])$", sp)
                if m_split:
                    suf = m_split.group(2)
                    start_mags[sp] = 0.5 if suf == "1" else -0.5

    # Retrocompatibilite : hubbard_auto_spin genere starting_mag pour les especes Hubbard
    if hubbard_auto_spin and nspin_val >= 2:
        try:
            base_mag = max(0.35, min(0.6, abs(float(hubbard_starting_magnetization))))
        except (TypeError, ValueError):
            base_mag = 0.45
        for sp in cif.atomic_species:
            if sp in hu_syms and sp not in start_mags:
                sm = _default_start_mag(sp, base_mag)
                if sm != 0.0:
                    start_mags[sp] = sm

    # nspin=2 sans starting_magnetization → amorcer les espèces magnétiques / Hubbard
    if nspin_val >= 2 and not noncolin_val and not start_mags:
        try:
            base_mag = max(0.35, min(0.6, abs(float(hubbard_starting_magnetization))))
        except (TypeError, ValueError):
            base_mag = 0.45
        for sp in cif.atomic_species:
            if sp in hu_syms or _is_magnetic_symbol(sp) or _is_afm_split_label(sp):
                sm = _default_start_mag(sp, base_mag)
                if sm != 0.0:
                    start_mags[sp] = sm

    # Ecrit les lignes magnetisme dans &SYSTEM
    # QE 7.5 : nspin=4 n'est PAS accepté — utiliser noncolin=.true. seul
    if noncolin_val:
        lines.append("  noncolin = .true.")
        if lspinorb_val:
            lines.append("  lspinorb = .true.")
    elif nspin_val == 2:
        lines.append("  nspin = 2")
        for idx, sp in enumerate(cif.atomic_species, start=1):
            if sp in start_mags:
                lines.append(f"  starting_magnetization({idx}) = {start_mags[sp]:.6f}")

    # ── Angles non colinéaires (angle1/angle2) : auto-détection → &SYSTEM ──
    # Automatique pour nspin=4, peut être forcé pour nspin=2
    if noncolin_val and nspin_val in (2, 4):
        auto_a1, auto_a2 = _noncolin_auto_angles(
            cif,
            afm_type=afm_type,
            angle1=angle1,
            angle2=angle2,
            nspin_val=nspin_val,
            start_mags=start_mags,
        )
        for idx, sp in enumerate(cif.atomic_species, start=1):
            if sp in auto_a1:
                a1 = float(auto_a1[sp])
                if a1 != 0.0:
                    lines.append(f"  angle1({idx}) = {a1:.6f}")
            if sp in auto_a2:
                a2 = float(auto_a2[sp])
                if a2 != 0.0:
                    lines.append(f"  angle2({idx}) = {a2:.6f}")

    idft = _sanitize_input_dft(input_dft)
    if idft:
        lines.append(f"  input_dft = '{idft}'")
    hs_low = str(hubbard_syntax).strip().lower() or "card"
    if hubbard_u and hs_low == "legacy":
        for hline in _hubbard_lines_for_system(
            cif.atomic_species,
            hubbard_u,
            hubbard_j0,
            hubbard_kind,
            hubbard_projection,
            legacy_verbose=bool(hubbard_legacy_verbose),
        ):
            lines.append(hline)
    # QE >= 7.3.1 (carte HUBBARD) : pas de lda_plus_u / Hubbard_occ dans &SYSTEM
    lines.append("/")

    mix_beta = mixing_beta
    if mix_beta is None:
        mix_beta = 0.3 if hu_syms else 0.7
    lines.append("&ELECTRONS")
    ct_val = conv_thr
    if ct_val is None and born_scf_mode:
        ct_val = "1.0d-12"
    if ct_val is None:
        ct_val = "1.0d-9"
    lines.append(f"  conv_thr    = {ct_val}")
    lines.append(f"  mixing_beta = {mix_beta}")
    diag = str(diagonalization or "").strip()
    if diag and diag.lower() not in {"", "auto", "default"}:
        lines.append(f"  diagonalization = '{diag}'")
    lines.append("/")

    if berry_mode or lberry:
        npp = int(nppstr if nberrycyc is None else nberrycyc)
        if npp < 1:
            npp = 8
        lines.append("")
        lines.append("! Phase de Berry (polarisation spontanee) — namelist &BP (QE 7.x)")
        lines.append("&BP")
        lines.append("  lberry = .true.")
        lines.append(f"  gdir   = {int(gdir)}")
        lines.append(f"  nppstr = {npp}")
        lines.append("/")
    elif lelfield:
        lines.append("")
        lines.append("! Champ electrique homogene — namelist &ELECTRIC (incompatible avec lberry)")
        lines.append("&ELECTRIC")
        lines.append("  lelfield = .true.")
        lines.append("/")

    if calc_low in ("relax", "vc-relax"):
        idyn = str(ion_dynamics or "bfgs").strip() or "bfgs"
        lines.append("")
        lines.append("&IONS")
        lines.append(f"  ion_dynamics = '{idyn}'")
        lines.append("/")
    elif calc_low == "md":
        lines.append("")
        lines.append("&IONS")
        lines.append("  ion_dynamics = 'verlet'")
        lines.append(f"  tempw        = {md_tempw}")
        lines.append(f"  dt           = {md_dt}")
        lines.append(f"  nstep        = {md_nstep}")
        lines.append("/")
    elif calc_low == "vc-md":
        lines.append("")
        lines.append("&IONS")
        lines.append("  ion_dynamics = 'verlet'")
        lines.append(f"  tempw        = {md_tempw}")
        lines.append(f"  dt           = {md_dt}")
        lines.append(f"  nstep        = {md_nstep}")
        lines.append("/")
        cdyn = str(cell_dynamics or "bfgs").strip() or "bfgs"
        lines.append("")
        lines.append("&CELL")
        lines.append(f"  cell_dynamics = '{cdyn}'")
        lines.append(f"  press = {press}")
        pct = 0.5 if press_conv_thr is None else press_conv_thr
        lines.append(f"  press_conv_thr = {pct}")
        lines.append("/")
    if calc_low == "vc-relax":
        cdyn = str(cell_dynamics or "bfgs").strip() or "bfgs"
        lines.append("")
        lines.append("&CELL")
        lines.append(f"  cell_dynamics = '{cdyn}'")
        lines.append(f"  press = {press}")
        pct = 0.5 if press_conv_thr is None else press_conv_thr
        lines.append(f"  press_conv_thr = {pct}")
        lines.append("/")

    lines.append("")
    lines.append("ATOMIC_SPECIES")
    for sp in cif.atomic_species:
        mass = _mass_for_species(sp)
        upf = _pseudo_for_species(sp, pseudos)
        lines.append(f"  {sp:<3} {mass:>9.4f}  {upf}")
    lines.append("")

    if ibrav == 0:
        lines.append("CELL_PARAMETERS angstrom")
        for row in cif.cell_parameters_angstrom:
            lines.append(f"  {row[0]:18.10f} {row[1]:18.10f} {row[2]:18.10f}")
        lines.append("")

    lines.append("ATOMIC_POSITIONS crystal")
    for sym, x, y, z in cif.atomic_positions_crystal:
        lines.append(f"  {sym:<3} {x:14.10f} {y:14.10f} {z:14.10f}")
    lines.append("")

    if calc_low == "bands":
        try:
            from qe_input_builders import bands_kpath_crystal_b
            lines.append(bands_kpath_crystal_b(ibrav))
        except ImportError:
            lines.append("K_POINTS crystal_b")
            lines.append("4")
            lines.append("0.0000 0.0000 0.0000 50  ! Gamma")
            lines.append("0.5000 0.0000 0.0000 50  ! X")
            lines.append("0.5000 0.5000 0.0000 50  ! M")
            lines.append("0.0000 0.0000 0.0000 1   ! Gamma")
    else:
        lines.append("K_POINTS automatic")
        kx, ky, kz = k_points
        if calc_low == "nscf":
            kx = max(kx, int(kx * 1.5) if kx > 0 else 12)
            ky = max(ky, int(ky * 1.5) if ky > 0 else 12)
            kz = max(kz, int(kz * 1.5) if kz > 0 else 12)
        lines.append(f"  {kx} {ky} {kz}  0 0 0")
    lines.append("")

    if hubbard_u and hs_low == "card":
        for hline in _hubbard_card(
            cif.atomic_species,
            hubbard_u,
            hubbard_j0,
            hubbard_manifold,
            hubbard_projection,
            hubbard_manifolds,
        ):
            lines.append(hline)

    return "\n".join(lines)


ATOMIC_MASSES: dict = {
    "H":   1.00794, "He":  4.0026,  "Li":  6.941,   "Be":  9.0122,  "B": 10.811,
    "C":  12.0107, "N":  14.0067, "O":  15.9994, "F":  18.9984,  "Ne": 20.1797,
    "Na": 22.9898, "Mg": 24.305,  "Al": 26.9815, "Si": 28.0855, "P":  30.9738,
    "S":  32.065,  "Cl": 35.453,  "Ar": 39.948,  "K":  39.0983, "Ca": 40.078,
    "Sc": 44.9559, "Ti": 47.867,  "V":  50.9415, "Cr": 51.9961, "Mn": 54.938,
    "Fe": 55.845,  "Co": 58.9332, "Ni": 58.6934, "Cu": 63.546,  "Zn": 65.38,
    "Ga": 69.723,  "Ge": 72.64,   "As": 74.9216, "Se": 78.96,   "Br": 79.904,
    "Kr": 83.798,  "Rb": 85.4678, "Sr": 87.62,   "Y":  88.9059, "Zr": 91.224,
    "Nb": 92.9064, "Mo": 95.96,   "Tc": 98.0,    "Ru": 101.07,  "Rh": 102.9055,
    "Pd": 106.42,  "Ag": 107.8682,"Cd": 112.411, "In": 114.818, "Sn": 118.71,
    "Sb": 121.76,  "Te": 127.6,   "I":  126.9045,"Xe": 131.293, "Cs": 132.9055,
    "Ba": 137.327, "La": 138.9055,"Ce": 140.116, "Pr": 140.9077,"Nd": 144.242,
    "Pm": 145.0,   "Sm": 150.36,  "Eu": 151.964, "Gd": 157.25,  "Tb": 158.9254,
    "Dy": 162.5,   "Ho": 164.9303,"Er": 167.259, "Tm": 168.9342,"Yb": 173.054,
    "Lu": 174.9668,"Hf": 178.49,  "Ta": 180.9479,"W":  183.84,  "Re": 186.207,
    "Os": 190.23,  "Ir": 192.217, "Pt": 195.084, "Au": 196.9666,"Hg": 200.59,
    "Tl": 204.3833,"Pb": 207.2,   "Bi": 208.9804,"Po": 209.0,   "At": 210.0,
    "Rn": 222.0,   "Fr": 223.0,   "Ra": 226.0,   "Ac": 227.0,   "Th": 232.0381,
    "Pa": 231.0359,"U":  238.0289,"Np": 237.0,   "Pu": 244.0,
}

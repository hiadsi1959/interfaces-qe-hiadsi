/**
 * Correctif layout Chrome — annule l'ancien --qe-sb / padding-inline-start
 * et recentre .container si un décalage résiduel (cache CSS) reste.
 */
(function () {
    'use strict';

    function setImp(el, prop, value) {
        if (!el) return;
        try {
            el.style.setProperty(prop, value, 'important');
        } catch (_e) { /* ignore */ }
    }

    function clearPad(el) {
        if (!el) return;
        try {
            el.style.removeProperty('--qe-sb');
            el.style.setProperty('--qe-sb', '0px');
            setImp(el, 'padding-inline-start', '0px');
            setImp(el, 'padding-inline-end', '0px');
            setImp(el, 'padding-left', '0px');
            setImp(el, 'padding-right', '0px');
            setImp(el, 'margin-left', '0px');
            setImp(el, 'margin-right', '0px');
            el.removeAttribute('data-qe-sb');
        } catch (_e) { /* ignore */ }
    }

    function forceLayout() {
        var root = document.documentElement;
        var body = document.body;
        clearPad(root);

        if (body) {
            setImp(body, 'display', 'block');
            setImp(body, 'align-items', 'stretch');
            setImp(body, 'justify-content', 'flex-start');
            setImp(body, 'margin', '0');
            setImp(body, 'padding', '12px');
            setImp(body, 'width', '100%');
            setImp(body, 'max-width', '100%');
            setImp(body, 'transform', 'none');
            setImp(body, 'left', 'auto');
            setImp(body, 'right', 'auto');
            setImp(body, 'overflow-x', 'hidden');
        }

        var c = document.querySelector('.container');
        if (!c) return;

        setImp(c, 'display', 'block');
        setImp(c, 'width', '100%');
        setImp(c, 'max-width', '1800px');
        setImp(c, 'margin', '0 auto');
        setImp(c, 'margin-left', 'auto');
        setImp(c, 'margin-right', 'auto');
        setImp(c, 'padding', '0');
        setImp(c, 'left', 'auto');
        setImp(c, 'right', 'auto');
        setImp(c, 'float', 'none');
        setImp(c, 'position', 'relative');
        setImp(c, 'transform', 'none');

        if (window.scrollX) {
            try { window.scrollTo(0, window.scrollY); } catch (_e) { /* ignore */ }
        }

        // Auto-heal : si encore décalé à droite (CSS en cache), tirer vers la gauche.
        requestAnimationFrame(function () {
            var rect = c.getBoundingClientRect();
            var left = rect.left;
            var rightGap = window.innerWidth - rect.right;
            // Décalage typique : grand vide à gauche, collé à droite
            if (left > 120 && rightGap < 8 && left > rightGap * 4) {
                clearPad(root);
                setImp(c, 'margin-left', '0');
                setImp(c, 'margin-right', '0');
                setImp(c, 'width', '100%');
                setImp(c, 'transform', 'none');
                requestAnimationFrame(function () {
                    var left2 = c.getBoundingClientRect().left;
                    if (left2 > 48) {
                        var pull = Math.round(left2 - 12);
                        setImp(c, 'transform', 'translateX(-' + pull + 'px)');
                    }
                });
            }
        });
    }

    forceLayout();
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', forceLayout);
    }
    window.addEventListener('load', forceLayout);
    window.addEventListener('resize', forceLayout);
    // Rejouer après styles tardifs / fragments
    setTimeout(forceLayout, 0);
    setTimeout(forceLayout, 250);
    setTimeout(forceLayout, 1000);
})();

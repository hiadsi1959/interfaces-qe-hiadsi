/**
 * standalone_mode.js — Mode autonome pour le paquet portable génération_inputs-QE.
 *
 * Rôle :
 *   Détecte si la page est servie depuis le serveur Flask autonome (port 5012)
 *   plutôt que depuis l'interface complète Interface-QE_v1 (port 5007).
 *
 * Fonctionnalités :
 *   1. Détection automatique du mode (port 5012) ou forcé via localStorage
 *   2. Blocage des appels fetch() vers le port 5007 avec un message d'erreur clair
 *   3. Injection d'un bandeau d'information jaune en haut de page
 *   4. Exposition de variables globales (window.__GEN_INPUTS_STANDALONE__, etc.)
 *      pour que les autres scripts puissent adapter leur comportement
 *
 * Variables globales exposées :
 *   window.__GEN_INPUTS_STANDALONE__          : booléen, mode actif ou non
 *   window.isGenInputsStandaloneMode()        : fonction test
 *   window.genInputsStandaloneBlockedError()  : génère une erreur descriptive
 *   window.isGenInputsStandaloneBlockedError(err) : détecte cette erreur
 *
 * Utilisation :
 *   localStorage.setItem('GEN_INPUTS_FORCE_STANDALONE','1') pour forcer le mode
 *   localStorage.setItem('GEN_INPUTS_BANNER_OPEN','1') pour laisser le bandeau déplié
 */
(function () {
    'use strict';

    /**
     * Détecte si la page est servie depuis le serveur autonome (port 5012).
     * Vérifie l'hostname (localhost/127.0.0.1) et le port.
     * Permet un forçage via localStorage.GEN_INPUTS_FORCE_STANDALONE = '1'.
     * @returns {boolean}
     */
    function detectStandalone() {
        try {
            if (typeof localStorage !== 'undefined' && localStorage.getItem('GEN_INPUTS_FORCE_STANDALONE') === '1') {
                return true;
            }
            var l = window.location;
            if (!l.protocol || !l.protocol.startsWith('http')) return false;
            var h = (l.hostname || '').toLowerCase();
            if (h !== 'localhost' && h !== '127.0.0.1') return false;
            var p = l.port || (l.protocol === 'https:' ? '443' : '80');
            return String(p) === '5012';
        } catch (e) {
            return false;
        }
    }

    /**
     * Vérifie si une URL cible l'API complète (port 5007) qui doit être bloquée.
     * @param {string} urlStr - L'URL à tester
     * @returns {boolean}
     */
    function isBlockedQeFullApiUrl(urlStr) {
        if (!urlStr || typeof urlStr !== 'string') return false;
        return /(^|[/:])127\.0\.0\.1:5007(\/|$|:|\?|#)/.test(urlStr)
            || /(^|[/:])localhost:5007(\/|$|:|\?|#)/.test(urlStr)
            || /:5007(\/|\?|#|$)/.test(urlStr);
    }

    /**
     * Crée une erreur descriptive pour les appels bloqués vers le port 5007.
     * Explique le mode autonome et comment installer Interface-QE_v1.
     * @returns {Error}
     */
    function standaloneBlockedError() {
        var e = new Error(
            "Mode autonome : cette action nécessite l'API Interface-QE (port 5007). "
            + "Ce paquet portable sert à générer et sauvegarder des inputs (API 5012). "
            + "Pour calculs / pseudos / sorties depuis l'interface complète, installez et lancez Interface-QE_v1 ailleurs."
        );
        e.name = 'StandaloneBlockedError';
        return e;
    }

    var STANDALONE = detectStandalone();
    window.__GEN_INPUTS_STANDALONE__ = STANDALONE;
    window.isGenInputsStandaloneMode = function () { return !!window.__GEN_INPUTS_STANDALONE__; };
    window.genInputsStandaloneBlockedError = standaloneBlockedError;
    window.isGenInputsStandaloneBlockedError = function (err) {
        if (!err) return false;
        if (err.name === 'StandaloneBlockedError') return true;
        return /Mode autonome\s*:/i.test(String(err.message || ''));
    };

    if (!STANDALONE) return;

    /** Pas de suivi calculs en mode autonome (API 5007 absente). */
    window.listerCalculsEnCours = async function listerCalculsEnCoursStandalone() {
        return;
    };

    document.documentElement.classList.add('gen-inputs-standalone');

    var origFetch = window.fetch;
    window.fetch = function (input, init) {
        var url = '';
        try {
            if (typeof input === 'string') {
                url = input;
            } else if (input && typeof Request !== 'undefined' && input instanceof Request) {
                url = input.url;
            } else if (input && input.url) {
                url = String(input.url);
            }
        } catch (e) { /* ignore */ }
        if (isBlockedQeFullApiUrl(url)) {
            // Réponse vide plutôt qu'un reject : évite les erreurs non catchées
            // des onglets legacy (phonons / résultats / liste calculs).
            var body = JSON.stringify({
                ok: false,
                standalone_blocked: true,
                error: standaloneBlockedError().message,
                calculs: [],
                items: [],
                files: [],
                results: []
            });
            return Promise.resolve(new Response(body, {
                status: 200,
                headers: { 'Content-Type': 'application/json' }
            }));
        }
        return origFetch.apply(this, arguments);
    };

    function injectBannerStyles() {
        if (document.getElementById('gen-inputs-standalone-banner-css')) return;
        var st = document.createElement('style');
        st.id = 'gen-inputs-standalone-banner-css';
        st.textContent = '#gen-inputs-standalone-banner summary::-webkit-details-marker{display:none;}'
            + '#gen-inputs-standalone-banner summary::marker{content:"";}';
        document.head.appendChild(st);
    }

    function injectBanner() {
        if (document.getElementById('gen-inputs-standalone-banner')) return;
        injectBannerStyles();

        var host = '';
        try {
            host = window.location.host || '';
        } catch (e) { /* ignore */ }

        var details = document.createElement('details');
        details.id = 'gen-inputs-standalone-banner';
        details.setAttribute('role', 'note');
        details.style.cssText = [
            'background:linear-gradient(135deg,#fef3c7 0%,#fde68a 100%)',
            'border-left:4px solid #d97706',
            'color:#78350f',
            'padding:10px 14px 12px',
            'margin:0',
            'border-radius:0',
            'width:100%',
            'box-sizing:border-box',
            'font-size:0.95em',
            'line-height:1.55',
            'box-shadow:none'
        ].join(';');

        try {
            if (typeof localStorage !== 'undefined' && localStorage.getItem('GEN_INPUTS_BANNER_OPEN') === '1') {
                details.open = true;
            }
        } catch (eOpen) { /* ignore */ }

        details.innerHTML = ''
            + '<summary style="cursor:pointer;font-weight:700;list-style:none;display:flex;align-items:center;gap:8px;user-select:none;">'
            + '<span aria-hidden="true" style="font-size:0.75em;opacity:0.85;">▶</span>'
            + '<span>📦 Mode autonome (port ' + (host || '5012') + ')</span>'
            + '<span style="font-weight:500;font-size:0.82em;opacity:0.9;margin-left:auto;">cliquer pour déplier</span>'
            + '</summary>'
            + '<div style="margin-top:10px;padding-top:10px;border-top:1px solid rgba(217,119,6,0.35);">'
            + '<div>Ce mode est pensé pour être <strong>copié sur un autre PC</strong> : génération d’inputs QE (direct → <code style="background:rgba(255,255,255,.6);padding:2px 6px;border-radius:4px;">inputs_générés_direct/</code>, CIF → <code style="background:rgba(255,255,255,.6);padding:2px 6px;border-radius:4px;">inputs_convertis_cif/</code>), sans Interface-QE sur la même machine.</div>'
            + '<div style="margin-top:10px;">Les appels à l’API complète (<strong>port 5007</strong>) sont désactivés ici. Pour lancer <code>pw.x</code>, workflows guidés ou lire les <code>.out</code> via l’API, utilisez <strong>Interface-QE_v1</strong> sur une machine où Quantum ESPRESSO est installé.</div>'
            + '<div style="margin-top:8px;font-size:0.9em;opacity:.95;">Astuce : ouvrez toujours cette page en <code style="background:rgba(255,255,255,.55);padding:2px 6px;border-radius:4px;">http://127.0.0.1:5012</code> (pas en <code>file://</code>). Pour forcer ce mode en test : <code>localStorage.setItem(\'GEN_INPUTS_FORCE_STANDALONE\',\'1\')</code> puis rechargez.</div>'
            + '</div>';

        details.addEventListener('toggle', function () {
            var hint = details.querySelector('summary span:last-child');
            var arrow = details.querySelector('summary span[aria-hidden]');
            try {
                localStorage.setItem('GEN_INPUTS_BANNER_OPEN', details.open ? '1' : '0');
            } catch (eLs) { /* ignore */ }
            if (hint) {
                hint.textContent = details.open ? 'cliquer pour replier' : 'cliquer pour déplier';
            }
            if (arrow) {
                arrow.textContent = details.open ? '▼' : '▶';
            }
        });

        var container = document.querySelector('.container');
        var header = document.querySelector('.container header');
        if (container && header && header.nextSibling) {
            container.insertBefore(details, header.nextSibling);
        } else if (container) {
            container.insertBefore(details, container.firstChild);
        } else {
            document.body.insertBefore(details, document.body.firstChild);
        }

        if (details.open) {
            details.dispatchEvent(new Event('toggle'));
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', injectBanner);
    } else {
        injectBanner();
    }

    console.log('%c📦 génération_inputs-QE — mode autonome actif (fetch → 5007 bloqué)', 'color:#b45309;font-weight:bold;');
})();

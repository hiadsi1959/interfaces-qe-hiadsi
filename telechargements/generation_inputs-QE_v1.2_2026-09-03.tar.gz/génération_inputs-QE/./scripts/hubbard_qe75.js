// ═══════════════════════════════════════════════════════════════════════════
// hubbard_qe75.js — DFT+U helpers (QE 7.5 card/legacy syntax)
// Extracted from index.html for early loading before dependent scripts.
// ═══════════════════════════════════════════════════════════════════════════
(function () {
    function escHtml(t) {
        return String(t == null ? '' : t)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function parseSymbolsFromAtomicSpecies(text) {
        var out = [];
        String(text || '').split('\n').forEach(function (line) {
            var t = line.replace(/!.*$/, '').trim();
            if (!t) return;
            var tok = t.split(/\s+/)[0];
            if (tok && /^[A-Za-z][A-Za-z0-9._-]*$/.test(tok)) out.push(tok);
        });
        // dédupe en gardant l'ordre
        var seen = {};
        var uniq = [];
        for (var i = 0; i < out.length; i++) {
            if (!seen[out[i]]) { seen[out[i]] = 1; uniq.push(out[i]); }
        }
        return uniq;
    }
    window.parseSymbolsFromAtomicSpecies = parseSymbolsFromAtomicSpecies;

    var __HUBBARD_MANIFOLD_OPTIONS = ['2p', '3p', '3d', '4d', '4f', '5d', '5f', '5s', '6p'];
    var __hubbardLnSeriesRe = /^(LA|CE|PR|ND|PM|SM|EU|GD|TB|DY|HO|ER|TM|YB|LU)$/;

    function canonChemSpecies(sym) {
        var m = /^([A-Za-z]+)/.exec(String(sym == null ? '' : sym));
        if (!m) return '';
        var x = m[1];
        if (x.length === 1) return x.toUpperCase();
        return x.charAt(0).toUpperCase() + x.slice(1).toLowerCase();
    }

    /** Manifold orbital par espèce (JSON, Ln→4f, TM→3d/4d/5d, chalcogènes→2p). */
    window.defaultManifoldForSpecies = function (sym) {
        var mfFallback = '3d';
        try {
            var j = window.__hubbard_defaults_loaded;
            var tok = canonChemSpecies(sym);
            var meta = (j && typeof j === 'object') ? (j[sym] || (tok ? j[tok] : null)) : null;
            if (meta != null && typeof meta === 'object' && meta.manifold)
                return String(meta.manifold).trim() || mfFallback;
            if (tok && __hubbardLnSeriesRe.test(tok.toUpperCase()))
                return '4f';
            if (/^(Th|Pa|U|Np|Pu|Am|Cm|Bk|Cf|Es|Fm|Md|No|Lr)$/i.test(tok))
                return '5f';
            if (/^(O|S|Se|Te)$/i.test(tok))
                return '2p';
            var tm3 = /^(Sc|Ti|V|Cr|Mn|Fe|Co|Ni|Cu|Zn|Y|Zr|Nb|Mo|Tc|Ru|Rh|Pd|Ag|Cd)$/i;
            var tm5 = /^(Hf|Ta|W|Re|Os|Ir|Pt|Au|Hg|Tl|Pb|Bi)$/i;
            var tm4 = /^(Ga|Ge|As|Se|Br|Kr|Rb|Sr|In|Sn|Sb|Te|I|Xe)$/i;
            if (tok && tm3.test(tok)) return '3d';
            if (tok && tm5.test(tok)) return '5d';
            if (tok && tm4.test(tok)) return '4d';
        } catch (_eDm) {}
        return mfFallback;
    };

    function buildManifoldSelect(prefix, sym) {
        var mf = window.defaultManifoldForSpecies(sym);
        var html = '<select data-' + prefix + '-mf="' + escHtml(sym) + '" '
            + 'title="Manifold UI (4f, 3d…) — la carte HUBBARD écrit Gd-f, V-d (lettre seule, syntaxe QE 7.x)" '
            + 'style="width:100%;box-sizing:border-box;padding:6px;border-radius:4px;border:1px solid #cbd5e1;font-size:0.88em;">';
        for (var oi = 0; oi < __HUBBARD_MANIFOLD_OPTIONS.length; oi++) {
            var opt = __HUBBARD_MANIFOLD_OPTIONS[oi];
            html += '<option value="' + opt + '"' + (opt === mf ? ' selected' : '') + '>' + opt + '</option>';
        }
        html += '</select>';
        return html;
    }

    function buildSpeciesTable(prefix, symbols) {
        if (!symbols || !symbols.length) {
            return '<div style="padding: 10px; background: #fff; border: 1px dashed #fdba74; border-radius: 6px; color: #78350f; font-size: 0.85em;">Aucune espèce détectée.</div>';
        }
        var html = '<table style="width: 100%; border-collapse: collapse; background: white; border-radius: 6px; overflow: hidden;">';
        html += '<thead><tr style="background: #ffedd5;">';
        html += '<th style="padding: 6px; border: 1px solid #fed7aa; text-align: left;">Élément</th>';
        html += '<th style="padding: 6px; border: 1px solid #fed7aa;">U eff. (eV)</th>';
        html += '<th style="padding: 6px; border: 1px solid #fed7aa;">Manifold (carte)</th>';
        html += '<th style="padding: 6px; border: 1px solid #fed7aa;">J0 (eV) — optionnel</th>';
        html += '</tr></thead><tbody>';
        for (var i = 0; i < symbols.length; i++) {
            var sym = symbols[i];
            html += '<tr>';
            html += '<td style="padding: 6px; border: 1px solid #fed7aa; font-weight: 700; color: #9a3412;">' + escHtml(sym) + '</td>';
            html += '<td style="padding: 2px; border: 1px solid #fed7aa;"><input type="text" data-' + prefix + '-u="' + escHtml(sym) + '" placeholder="—" style="width: 100%; box-sizing: border-box; padding: 6px; border-radius: 4px; border: 1px solid #cbd5e1;"></td>';
            html += '<td style="padding: 2px; border: 1px solid #fed7aa;">' + buildManifoldSelect(prefix, sym) + '</td>';
            html += '<td style="padding: 2px; border: 1px solid #fed7aa;"><input type="text" data-' + prefix + '-j0="' + escHtml(sym) + '" placeholder="—" style="width: 100%; box-sizing: border-box; padding: 6px; border-radius: 4px; border: 1px solid #cbd5e1;"></td>';
            html += '</tr>';
        }
        html += '</tbody></table>';
        html += '<p style="margin:8px 0 0;font-size:0.78em;color:#78350f;line-height:1.4;">'
            + 'Manifold auto&nbsp;: terres rares → <code>4f</code>, transition 3d (V, Fe…) → <code>3d</code>, 5d (W, Pt…) → <code>5d</code>. '
            + 'Ex. <strong>GdVO₃</strong>&nbsp;: Gd=<code>4f</code>, V=<code>3d</code>, O=<code>2p</code>.</p>';
        return html;
    }
    /** Appel hors IIFE legacy (liste CIF fichier) pour remplir <prefix>_hubbard_species_zone */
    window.renderHubbardSpeciesInputs = buildSpeciesTable;

    function collectFromTable(prefix) {
        var u = {};
        var j0 = {};
        var manifolds = {};
        var zone = document.getElementById(prefix + '_hubbard_species_zone');
        if (!zone) return { u: u, j0: j0, manifolds: manifolds };
        zone.querySelectorAll('input[data-' + prefix + '-u]').forEach(function (inp) {
            var sym = inp.getAttribute('data-' + prefix + '-u');
            var v = String(inp.value || '').trim();
            if (v && v !== '0' && v !== '0.0') {
                var num = parseFloat(v);
                if (!isNaN(num) && num !== 0) u[sym] = num;
            }
        });
        zone.querySelectorAll('input[data-' + prefix + '-j0]').forEach(function (inp) {
            var sym = inp.getAttribute('data-' + prefix + '-j0');
            var v = String(inp.value || '').trim();
            if (v && v !== '0' && v !== '0.0') {
                var num = parseFloat(v);
                if (!isNaN(num) && num !== 0) j0[sym] = num;
            }
        });
        zone.querySelectorAll('select[data-' + prefix + '-mf]').forEach(function (sel) {
            var sym = sel.getAttribute('data-' + prefix + '-mf');
            var v = String(sel.value || '').trim();
            if (sym && v) manifolds[sym] = v;
        });
        return { u: u, j0: j0, manifolds: manifolds };
    }

    function hubbardExpandSplitManifolds(man, species) {
        var out = Object.assign({}, man || {});
        (species || []).forEach(function (sp) {
            var m = /^([A-Z][a-z]?)([12])$/.exec(String(sp || '').trim());
            if (m && out[sp] == null && out[m[1]] != null) out[sp] = out[m[1]];
        });
        return out;
    }

    function toggleManifoldVisibility(prefix) {
        var syn = document.getElementById(prefix + '_hubbard_syntax');
        var wrap = document.getElementById(prefix + '_hubbard_manifold_wrap');
        if (syn && wrap) wrap.style.display = syn.value === 'card' ? 'block' : 'none';
        updateHubbardLegacyExpertWrap(prefix);
    }
    window.toggleManifoldVisibility = toggleManifoldVisibility;

    /** Affiche le bloc « ancien gabarit » (lda_plus_u_kind / verbose) uniquement en syntaxe legacy. */
    function updateHubbardLegacyExpertWrap(prefix) {
        var synEl = document.getElementById(prefix + '_hubbard_syntax');
        var legacyWrap = document.getElementById(prefix + '_hubbard_adv_legacy_wrap');
        var advDetails = document.getElementById(prefix + '_hubbard_adv_legacy');
        if (!legacyWrap) return;
        var isLegacy = synEl && synEl.value === 'legacy';
        legacyWrap.style.display = isLegacy ? 'block' : 'none';
        if (advDetails && !isLegacy) advDetails.open = false;
    }

    function lookupDefaultU(sym) {
        var map = window.__hubbard_u_map || {};
        var s = String(sym == null ? '' : sym);
        if (!s) return null;
        if (typeof map[s] === 'number') return map[s];
        var c = canonChemSpecies(s);
        if (c && typeof map[c] === 'number') return map[c];
        return null;
    }

    function hubbardSpeciesForPrefix(prefix) {
        var syms = [];
        var zone = document.getElementById(prefix + '_hubbard_species_zone');
        if (zone) {
            zone.querySelectorAll('input[data-' + prefix + '-u]').forEach(function (inp) {
                var s = inp.getAttribute('data-' + prefix + '-u');
                if (s && syms.indexOf(s) < 0) syms.push(s);
            });
        }
        if (syms.length) return syms;
        if (prefix === 'gen' && typeof window.pwGenCollectSpeciesForHubbard === 'function') {
            try { return window.pwGenCollectSpeciesForHubbard() || []; } catch (_eGs) {}
        }
        if (prefix === 'gen') {
            var ta = document.getElementById('atomic_species');
            var raw = ta ? ta.value : '';
            if ((!raw || !String(raw).trim()) && window.atomicSpeciesGlobal) raw = window.atomicSpeciesGlobal;
            return parseSymbolsFromAtomicSpecies(raw);
        }
        return [];
    }

    function hubbardExpandSplitSpecies(u, species) {
        var out = Object.assign({}, u || {});
        (species || []).forEach(function (sp) {
            var m = /^([A-Z][a-z]?)([12])$/.exec(String(sp || '').trim());
            if (m && out[sp] == null && out[m[1]] != null) out[sp] = out[m[1]];
        });
        return out;
    }

    function hubbardPayloadFromPrefix(prefix) {
        var en = document.getElementById(prefix + '_hubbard_enable');
        if (!en || !en.checked) return null;
        var t = collectFromTable(prefix);
        var u = t.u || {};
        var j0 = t.j0 || {};
        var manifolds = t.manifolds || {};
        var symsExpand = hubbardSpeciesForPrefix(prefix);
        u = hubbardExpandSplitSpecies(u, symsExpand);
        j0 = hubbardExpandSplitSpecies(j0, symsExpand);
        manifolds = hubbardExpandSplitManifolds(manifolds, symsExpand);
        var nu = Object.keys(u).length;
        var nj = Object.keys(j0).length;
        if (!nu && !nj) {
            var syms = hubbardSpeciesForPrefix(prefix);
            var fallbackU = {};
            for (var fi = 0; fi < syms.length; fi++) {
                var vu = lookupDefaultU(syms[fi]);
                if (vu != null && !isNaN(vu) && vu !== 0) fallbackU[syms[fi]] = vu;
            }
            if (Object.keys(fallbackU).length) u = fallbackU;
            else return null;
        }
        var synEl = document.getElementById(prefix + '_hubbard_syntax');
        var kindEl = document.getElementById(prefix + '_hubbard_kind');
        var projEl = document.getElementById(prefix + '_hubbard_projection');
        var manEl = document.getElementById(prefix + '_hubbard_manifold');
        var verboseEl = document.getElementById(prefix + '_hubbard_legacy_verbose');
        var spinCk = document.getElementById(prefix + '_hubbard_auto_spin');
        return {
            hubbard_u: u,
            hubbard_j0: j0,
            hubbard_manifolds: Object.keys(manifolds).length ? manifolds : undefined,
            hubbard_syntax: synEl ? (synEl.value || 'card') : 'card',
            hubbard_kind: kindEl ? (parseInt(kindEl.value || '0', 10) || 0) : 0,
            hubbard_projection: projEl ? (projEl.value || 'ortho-atomic') : 'ortho-atomic',
            hubbard_manifold: manEl ? (manEl.value || '3d') : '3d',
            hubbard_legacy_verbose: !!(verboseEl && verboseEl.checked),
            hubbard_auto_spin: !(spinCk) ? false : !!spinCk.checked,
            hubbard_starting_magnetization: 0.45,
        };
    }

    window.normalizePwInputDft = function (raw) {
        var s = String(raw == null ? '' : raw).trim();
        if (!s) return '';
        if (/^xc-/i.test(s)) {
            var u = s.replace(/[^a-zA-Z0-9\-_]/g, '').toUpperCase();
            return u.length > 0 ? u.slice(0, 140) : '';
        }
        var t = s.toLowerCase().replace(/[^a-z0-9\-_]/g, '');
        if (!t) return '';
        var aliases = window.QE_INPUT_DFT_ALIASES || {
            lda: 'pz', lda_pw: 'pw', q2d: 'pbeq2d', sca0: 'scan0',
            b86bx: 'b86bpbex', bhandhlyp: 'bhahlyp', gaupbe: 'gaup'
        };
        if (aliases[t]) t = aliases[t];
        return t.slice(0, 72);
    };

    window.parseSpeciesFromPwText = function (text) {
        var lines = String(text || '').split(/\r?\n/);
        var startLine = -1;
        for (var i = 0; i < lines.length; i++) {
            if (/^[ \t]*ATOMIC_SPECIES[ \t]*$/i.test(lines[i])) { startLine = i; break; }
        }
        if (startLine < 0) return [];
        var block = [];
        for (var j = startLine + 1; j < lines.length; j++) {
            if (/^[ \t]*(ATOMIC_POSITIONS|[&])/i.test(lines[j])) break;
            block.push(lines[j]);
        }
        return parseSymbolsFromAtomicSpecies(block.join('\n'));
    };

    function stripHubbardCard(t) {
        return String(t || '').replace(
            /\n*[ \t]*HUBBARD[ \t]*\([^)]*\)[^\n]*\n(?:^[ \t]*(?:U|J0)[^\n]+\n?)*/gm,
            '\n');
    }

    function findSystemIndices(lines) {
        var start = -1, close = -1;
        for (var i = 0; i < lines.length; i++) {
            var t = lines[i].trim();
            if (t.toLowerCase().indexOf('&system') === 0) {
                start = i;
                break;
            }
        }
        if (start < 0) return { start: -1, close: -1 };
        for (var j = start + 1; j < lines.length; j++) {
            var tj = lines[j].trim().replace(/^['"]|['"]$/g, '');
            if (/^\/\s*(!|$)/.test(tj) || tj === '/') {
                close = j;
                break;
            }
        }
        return { start: start, close: close };
    }

    function systemLineRemoval(line) {
        var st = line.replace(/^[ \t]*/, '').toLowerCase();
        if (/^!?.*input_dft[ \t]*=/.test(st)) return false;
        if (/^!?.*lda_plus_u_kind/.test(st)) return false;
        if (/^!?.*lda_plus_u\s*=/.test(st)) return false;
        if (/^!?.*hubbard_u\(/.test(st)) return false;
        if (/^!?.*hubbard_j0\(/.test(st)) return false;
        if (/^!?.*hubbard_occ\s*\(/i.test(st)) return false;
        if (/^!?.*u_projection_type/.test(st)) return false;
        /* Conserver nspin / starting_magnetization : ils viennent du formulaire générateur */
        return true;
    }

    function hubbardMergeSpeciesOrder(species, prefix, uMap) {
        var order = (species && species.length) ? species.slice() : hubbardSpeciesForPrefix(prefix);
        var u = uMap || {};
        Object.keys(u).forEach(function (k) {
            if (order.indexOf(k) < 0) order.push(k);
        });
        return order;
    }

    /** Hubbard : espèces avec U≠0 ou J0≠0 (tableau DOM ou défauts JSON). */
    function hubbardSpeciesWithNonzeroU(prefix, speciesOrder) {
        var p = hubbardPayloadFromPrefix(prefix);
        if (!p) return null;
        var t = p.hubbard_u || {};
        var jmap = p.hubbard_j0 || {};
        var order = hubbardMergeSpeciesOrder(speciesOrder, prefix, t);
        var hits = {};
        order.forEach(function (sp) {
            if (Object.prototype.hasOwnProperty.call(t, sp)) {
                var nf = parseFloat(String(t[sp]));
                if (!isNaN(nf) && nf !== 0)
                    hits[sp] = true;
            }
            if (Object.prototype.hasOwnProperty.call(jmap, sp)) {
                var nj = parseFloat(String(jmap[sp]));
                if (!isNaN(nj) && nj !== 0)
                    hits[sp] = true;
            }
        });
        return Object.keys(hits).length ? hits : null;
    }

    /** Réécrit après degauss (ou repli occupations / ecutrho) pour coller au backend. */
    function injectHubbardSpinIntoInner(inner, speciesOrder, prefix) {
        var p = hubbardPayloadFromPrefix(prefix);
        if (!p || !p.hubbard_auto_spin)
            return;
        var hits = hubbardSpeciesWithNonzeroU(prefix, speciesOrder);
        if (!hits)
            return;
        /* Évite doubler nspin / starting_magnetization déjà présents */
        for (var ri = inner.length - 1; ri >= 0; ri--) {
            var raw = inner[ri];
            if (/^[ \t]*!/.test(raw)) continue;
            if (/\bnspin\s*=/i.test(raw) || /\bstarting_magnetization\s*\(/i.test(raw))
                inner.splice(ri, 1);
        }
        var startMag = 0.45;
        try {
            if (typeof p.hubbard_starting_magnetization === 'number' && !isNaN(p.hubbard_starting_magnetization))
                startMag = p.hubbard_starting_magnetization;
        } catch (_sm) {}
        startMag = Math.max(0.35, Math.min(0.6, Math.abs(Number(startMag))));
        var blk = ['    nspin = 2'];
        speciesOrder.forEach(function (sp, ix) {
            var idx = ix + 1;
            blk.push(
                '    starting_magnetization(' + idx + ') = '
                + (hits[sp] ? Number(startMag).toFixed(6) : Number(0).toFixed(6))
            );
        });
        var ins = inner.length;
        var z;
        for (z = inner.length - 1; z >= 0; z--) {
            if (/\bdegauss\b\s*=/i.test(inner[z])) {
                ins = z + 1;
                break;
            }
        }
        if (ins === inner.length) {
            for (z = inner.length - 1; z >= 0; z--) {
                if (/\bsmearing\b\s*=/i.test(inner[z])) {
                    ins = z + 1;
                    break;
                }
            }
        }
        if (ins === inner.length) {
            for (z = inner.length - 1; z >= 0; z--) {
                if (/\boccupations\b\s*=/i.test(inner[z])) {
                    ins = z + 1;
                    break;
                }
            }
        }
        if (ins === inner.length) {
            for (z = inner.length - 1; z >= 0; z--) {
                if (/\becutrho\b\s*=/i.test(inner[z])) {
                    ins = z + 1;
                    break;
                }
            }
        }
        for (z = blk.length - 1; z >= 0; z--)
            inner.splice(ins, 0, blk[z]);
    }

    /** Manifold par espèce — sélecteur tableau, puis JSON / règles élémentaires. */
    function hubbardManifoldForSpecies(prefix, sym) {
        var zone = document.getElementById(prefix + '_hubbard_species_zone');
        if (zone) {
            var selEl = zone.querySelector('select[data-' + prefix + '-mf="' + String(sym).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"]');
            if (selEl && selEl.value) return String(selEl.value).trim();
        }
        return window.defaultManifoldForSpecies(sym);
    }
    window.hubbardManifoldForSpecies = hubbardManifoldForSpecies;

    function hubbardLegacyBlockForSpecies(species, prefix) {
        var p = hubbardPayloadFromPrefix(prefix);
        if (!p || (p.hubbard_syntax !== 'legacy')) return '';
        var u = p.hubbard_u || {};
        var j0 = p.hubbard_j0 || {};
        var order = hubbardMergeSpeciesOrder(species, prefix, u);
        var chunk = '';
        var anyHb = false;
        order.forEach(function (sym, idx) {
            var i = idx + 1;
            if (sym in u) {
                var nf = parseFloat(String(u[sym]));
                if (!isNaN(nf) && nf !== 0) {
                    anyHb = true;
                    chunk += '    Hubbard_U(' + i + ') = ' + Number(u[sym]).toFixed(6) + '\n';
                }
            }
            if (sym in j0) {
                var nj = parseFloat(String(j0[sym]));
                if (!isNaN(nj) && nj !== 0) {
                    anyHb = true;
                    chunk += '    Hubbard_J0(' + i + ') = ' + Number(j0[sym]).toFixed(6) + '\n';
                }
            }
        });
        if (!anyHb) return '';
        var vb = !!(p && p.hubbard_legacy_verbose);
        var head = '    lda_plus_u = .true.\n';
        var extra = vb
            ? ('    lda_plus_u_kind = ' + (parseInt(String(p.hubbard_kind || 0), 10) || 0) + '\n'
                + '    U_projection_type = \''
                + String(p.hubbard_projection || 'atomic').replace(/[^\w\-]/g, '')
                + '\'\n')
            : '';
        return head + extra + chunk;
    }

    function occLetterFromManifold(mf) {
        var m = String(mf || '3d').trim().toLowerCase();
        if (m === 'f' || m === '4f' || m === '5f' || /f$/.test(m)) return 'f';
        if (m === 'd' || m === '3d' || m === '4d' || m === '5d' || /d$/.test(m)) return 'd';
        if (m === 'p' || /p$/.test(m)) return 'p';
        if (m === 's' || /s$/.test(m)) return 's';
        return 'd';
    }

    function hubbardCardOrbitalLabel(sym, mf) {
        return String(sym).trim() + '-' + String(mf).trim();
    }

    window.hubbardOccLetterFromManifold = occLetterFromManifold;
    window.hubbardCardOrbitalLabel = hubbardCardOrbitalLabel;

    function hubbardCardOccBlockForSpecies(species, prefix) {
        /* QE 7.5+ : syntaxe carte HUBBARD (ortho-atomic) — rien dans &SYSTEM */
        return '';
    }

    function hubbardCardBodyForSpecies(species, prefix) {
        var p = hubbardPayloadFromPrefix(prefix);
        if (!p || (p.hubbard_syntax !== 'card')) return '';
        var u = p.hubbard_u || {};
        var j0 = p.hubbard_j0 || {};
        var proj = String(p.hubbard_projection || 'ortho-atomic').replace(/[^\w\-]/g, '') || 'ortho-atomic';
        var order = hubbardMergeSpeciesOrder(species, prefix, u);
        var rows = [];
        var anyHb = false;
        order.forEach(function (sym) {
            var mf = hubbardManifoldForSpecies(prefix, sym);
            var uval = (typeof sym === 'string' && sym in u) ? parseFloat(String(u[sym])) : NaN;
            if (isNaN(uval) || uval === 0) {
                var m = /^([A-Z][a-z]?)([12])$/.exec(String(sym).trim());
                if (m && Object.prototype.hasOwnProperty.call(u, m[1])) {
                    uval = parseFloat(String(u[m[1]]));
                }
            }
            if (!isNaN(uval) && uval !== 0) {
                anyHb = true;
                rows.push('U  ' + hubbardCardOrbitalLabel(sym, mf) + '  ' + Number(uval).toFixed(6));
            }
            var jval = NaN;
            if (sym in j0) jval = parseFloat(String(j0[sym]));
            if ((isNaN(jval) || jval === 0) && /^([A-Z][a-z]?)([12])$/.test(sym)) {
                var mj = /^([A-Z][a-z]?)([12])$/.exec(String(sym).trim());
                if (mj && Object.prototype.hasOwnProperty.call(j0, mj[1])) {
                    jval = parseFloat(String(j0[mj[1]]));
                }
            }
            if (!isNaN(jval) && jval !== 0) {
                anyHb = true;
                rows.push('J0 ' + hubbardCardOrbitalLabel(sym, mf) + '  ' + Number(jval).toFixed(6));
            }
        });
        if (!anyHb) return '';
        return 'HUBBARD (' + proj + ')\n' + rows.join('\n') + '\n';
    }

    window.injectInputDftHubbardIntoPwText = function (text, opts) {
        opts = opts || {};
        var textOrig = String(text || '');
        var linesProbe = textOrig.split(/\r?\n/);
        var idxProbe = findSystemIndices(linesProbe);
        if (idxProbe.start < 0 || idxProbe.close < 0)
            return textOrig;

        var prefix = opts.hubbard_prefix || 'gen';
        var species = opts.species || window.parseSpeciesFromPwText(textOrig);
        if (!species.length && prefix === 'gen' && typeof window.pwGenResolveSpeciesList === 'function') {
            try { species = window.pwGenResolveSpeciesList('') || []; } catch (_eSp) {}
        }
        if (!species.length) {
            species = hubbardSpeciesForPrefix(prefix);
        }
        var pCardProbe = hubbardPayloadFromPrefix(prefix);
        var cBodyProbe = hubbardCardBodyForSpecies(species, prefix);
        var willReplaceCard = !!(pCardProbe && pCardProbe.hubbard_syntax === 'card' && cBodyProbe.trim());
        var text = willReplaceCard ? stripHubbardCard(textOrig) : textOrig;
        var lines = text.split(/\r?\n/);
        var idx = findSystemIndices(lines);
        if (idx.start < 0 || idx.close < 0)
            return textOrig;

        var inner = [];
        for (var k = idx.start + 1; k < idx.close; k++) {
            if (systemLineRemoval(lines[k])) inner.push(lines[k]);
        }

        var dftRaw = opts.input_dft;
        if (dftRaw == null || String(dftRaw) === '') {
            var modalHere = !!document.getElementById('modal_input_existant');
            var me = document.getElementById('modal_pw_input_dft');
            var pe = document.getElementById('pw_input_dft');
            var ce = document.getElementById('cif_input_dft');
            if (modalHere && me) dftRaw = me.value;
            else if (pe) dftRaw = pe.value;
            else if (ce) dftRaw = ce.value;
        }
        var dft = window.normalizePwInputDft(String(dftRaw || ''));
        var ins = inner.length;
        for (var uu = inner.length - 1; uu >= 0; uu--) {
            if (/\bntyp\b\s*=/i.test(inner[uu])) { ins = uu + 1; break; }
        }
        if (dft) inner.splice(ins, 0, '    input_dft = \'' + dft.replace(/'/g, '') + '\'');

        var hBlk = hubbardLegacyBlockForSpecies(species, prefix);
        if (hBlk && hBlk.trim())
            inner = inner.concat(hBlk.trimRight().split(/\r?\n/).filter(Boolean));

        var hOcc = hubbardCardOccBlockForSpecies(species, prefix);
        if (hOcc && hOcc.trim())
            inner = inner.concat(hOcc.trimRight().split(/\r?\n/).filter(Boolean));

        injectHubbardSpinIntoInner(inner, species, prefix);

        var out = [];
        for (var a = 0; a < idx.start; a++) out.push(lines[a]);
        out.push(lines[idx.start]);
        inner.forEach(function (ln) { out.push(ln); });
        out.push(lines[idx.close]);
        for (var b = idx.close + 1; b < lines.length; b++) out.push(lines[b]);
        text = out.join('\n');

        var pCard = hubbardPayloadFromPrefix(prefix);
        var cBody = hubbardCardBodyForSpecies(species, prefix);
        if (pCard && pCard.hubbard_syntax === 'card' && cBody.trim()) {
            text = stripHubbardCard(text).replace(/\s+$/, '') + '\n\n' + cBody;
            if (!/\n$/.test(text)) text += '\n';
        }
        return text;
    };

    // -------- API publique : sérialisation pour l'API /api/inputs/build --------
    window.cifHubbardCollectForApi = function () { return hubbardPayloadFromPrefix('cif'); };
    window.genHubbardCollectForApi = function () { return hubbardPayloadFromPrefix('gen'); };
    window.gestionHubbardCollectForApi = function () { return hubbardPayloadFromPrefix('gestion'); };

    // Texte prêt à coller dans &SYSTEM (legacy) ou la carte HUBBARD (>=7.3.1).
    window.genHubbardBuildLinesForSystem = function (species, hubPrefix) {
        return hubbardLegacyBlockForSpecies(species || [], hubPrefix || 'gen');
    };

    window.genHubbardBuildCard = function (species, hubPrefix) {
        return hubbardCardBodyForSpecies(species || [], hubPrefix || 'gen');
    };

    /** Pseudopotentiel par défaut selon l'espèce (US-PP PBE ou FR si SOC). */
    window.cifDefaultPseudoFilename = function (sym, opts) {
        opts = opts || {};
        var soc = opts.soc === true || opts.fullRelativistic === true;
        var s = String(sym || '').trim();
        if (!s) return '';
        var base = (s.match(/^([A-Z][a-z]?)[12]?$/i) || [])[1] || s;
        if (soc) {
            if (/^O$/i.test(base)) return 'O.rel-pbe-n-kjpaw_psl.1.0.0.UPF';
            if (/^(Cl|Br|I)$/i.test(base)) return base + '.rel-pbe-n-rrkjus_psl.1.0.0.UPF';
            if (/^(Gd|La|Ce|Pr|Nd|Sm|Eu|Tb|Dy|Ho|Er|Tm|Yb|Lu)$/i.test(base)) {
                return base + '.rel-pbe-spfn-rrkjus_psl.1.0.0.UPF';
            }
            if (/^(Ga|Ge|In|Sn|Al|Si)$/i.test(base)) return base + '.rel-pbe-dn-kjpaw_psl.1.0.0.UPF';
            if (/^(V|Fe|Co|Ni|Mn|Cr|Ti|Sc|Y)$/i.test(base)) return base + '.rel-pbe-spfn-rrkjus_psl.1.0.0.UPF';
            return base + '.rel-pbe-spfn-rrkjus_psl.1.0.0.UPF';
        }
        if (/^O$/i.test(base)) return 'O_pbe_v1.2.uspp.F.UPF';
        if (/^(Gd|La|Ce|Pr|Nd|Sm|Eu|Tb|Dy|Ho|Er|Tm|Yb|Lu|Sc|Y)$/i.test(base)) return base + '.pbe-us.UPF';
        return base + '.pbe-us.UPF';
    };

    window.cifSocModeActive = function () {
        var nEl = document.getElementById('cif_nspin') || document.getElementById('nspin');
        if (nEl && String(nEl.value || '').trim() === '4') return true;
        var ls = document.getElementById('cif_lspinorb');
        return !!(ls && String(ls.value || '').trim() === '.true.');
    };

    window.cifKMeshDefaults = function (nat, calc) {
        var n = parseInt(String(nat || '0'), 10) || 0;
        var c = String(calc || 'scf').toLowerCase();
        var relax = c === 'relax' || c === 'vc-relax';
        if (n >= 16 && relax) return [6, 6, 4];
        if (n >= 16) return [4, 4, 4];
        if (n >= 8) return [6, 6, 6];
        return [8, 8, 8];
    };

    window.renderCifPseudoInputs = function (species) {
        if (!species || !species.length) {
            return '<div style="padding:8px;color:#78350f;">Aucune espèce détectée.</div>';
        }
        var html = '<table style="width:100%;border-collapse:collapse;background:#fff;border-radius:6px;">';
        html += '<thead><tr style="background:#dcfce7;"><th style="padding:6px;text-align:left;">Espèce</th><th style="padding:6px;text-align:left;">Fichier .UPF</th></tr></thead><tbody>';
        for (var i = 0; i < species.length; i++) {
            var sym = String(species[i]).replace(/"/g, '&quot;');
            var def = window.cifDefaultPseudoFilename(sym, { soc: window.cifSocModeActive() });
            html += '<tr><td style="padding:6px;border:1px solid #bbf7d0;font-weight:700;">' + sym + '</td>';
            html += '<td style="padding:4px;border:1px solid #bbf7d0;"><input type="text" data-cif-pseudo="' + sym + '" value="' + def.replace(/"/g, '&quot;') + '" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:4px;"></td></tr>';
        }
        html += '</tbody></table>';
        return html;
    };

    window.cifPseudosCollectForApi = function () {
        var out = {};
        document.querySelectorAll('input[data-cif-pseudo]').forEach(function (inp) {
            var sym = inp.getAttribute('data-cif-pseudo');
            var val = String(inp.value || '').trim();
            if (sym && val) out[sym] = val;
        });
        return Object.keys(out).length ? out : null;
    };

    window.ensureCifPseudoRowsFromAnalysis = function (analysis) {
        try {
            var zone = document.getElementById('cif_pseudo_species_zone');
            if (!zone || !analysis || !(analysis.atomic_species && analysis.atomic_species.length)) return;
            if (zone.querySelector('input[data-cif-pseudo]')) return;
            if (typeof window.renderCifPseudoInputs === 'function')
                zone.innerHTML = window.renderCifPseudoInputs(analysis.atomic_species);
            if ((typeof window.cifNoncolinActive === 'function') && window.cifNoncolinActive() &&
                    typeof window.nspin4Flow !== 'undefined' &&
                    typeof window.nspin4Flow.refreshPseudoSuggestionsForSoc === 'function') {
                window.nspin4Flow.refreshPseudoSuggestionsForSoc(false);
            }
            var pf = document.getElementById('cif_prefix');
            if (pf && !String(pf.value || '').trim() && analysis.formula)
                pf.value = String(analysis.formula).replace(/[^A-Za-z0-9]/g, '') || pf.value;
            var nat = parseInt(String(analysis.nat || '0'), 10);
            var calcEl = document.getElementById('cif_calc_type');
            var calcType = calcEl ? String(calcEl.value || 'scf').toLowerCase() : 'scf';
            var kDefs = (typeof window.cifKMeshDefaults === 'function')
                ? window.cifKMeshDefaults(nat, calcType)
                : [4, 4, 4];
            if (nat >= 16) {
                ['cif_kx', 'cif_ky', 'cif_kz'].forEach(function (id, ki) {
                    var el = document.getElementById(id);
                    if (!el) return;
                    var v = String(el.value || '').trim();
                    if (v === '8' || v === '4') el.value = String(kDefs[ki] || kDefs[0]);
                });
            }
        } catch (_ePs) {}
    };

    window.cifCollectBuildOptionsForApi = function (analysis, materialName, opts) {
        opts = opts || {};
        function pick(id, fallback) {
            var el = document.getElementById(id);
            return el ? String(el.value || '').trim() : fallback;
        }
        var nat = parseInt(String((analysis && analysis.nat) || '0'), 10);
        var calcType = opts.calculation
            || (typeof window.resolveCifCalculationType === 'function' ? window.resolveCifCalculationType() : '')
            || pick('cif_calc_type', 'scf');
        calcType = String(calcType || 'scf').trim();
        var kDefArr = (typeof window.cifKMeshDefaults === 'function')
            ? window.cifKMeshDefaults(nat, calcType)
            : (nat >= 16 ? [4, 4, 4] : (nat >= 8 ? [6, 6, 6] : [8, 8, 8]));
        var prefixEl = pick('cif_prefix', '');
        var prefix = prefixEl || (analysis && analysis.formula ? String(analysis.formula).replace(/[^A-Za-z0-9]/g, '') : '') || materialName;
        var kx = parseInt(pick('cif_kx', String(kDefArr[0])), 10) || kDefArr[0];
        var ky = parseInt(pick('cif_ky', String(kDefArr[1])), 10) || kDefArr[1];
        var kz = parseInt(pick('cif_kz', String(kDefArr[2])), 10) || kDefArr[2];
        var mix = parseFloat(pick('cif_mixing_beta', '0.3'));
        var noncolin = (typeof window.cifNoncolinActive === 'function') && window.cifNoncolinActive();
        if (noncolin) {
            if (isNaN(mix) || mix > 0.25) mix = 0.15;
            mix = Math.max(0.15, Math.min(0.25, mix));
        }
        var pseudoDir = pick('cif_pseudo_dir', (window.QE_CONFIG && window.QE_CONFIG.PSEUDO_DIR) || './pseudos');
        if (noncolin && typeof window.pwGenFrPseudoDir === 'function') {
            pseudoDir = window.pwGenFrPseudoDir();
        }
        var fct = pick('cif_forc_conv_thr', '1.0d-4');
        var fctNum = parseFloat(String(fct).replace(/d/i, 'e'));
        var ecutwfc = parseFloat(pick('cif_ecutwfc', '50'));
        var ecutrho = parseFloat(pick('cif_ecutrho', '400'));
        var convThr = pick('cif_conv_thr', '1.0d-8') || '1.0d-8';
        if (isNaN(ecutwfc)) ecutwfc = 50;
        if (isNaN(ecutrho)) ecutrho = 400;
        var body = {
            analysis: analysis,
            calculation: calcType,
            prefix: prefix,
            pseudo_dir: pseudoDir,
            outdir: pick('cif_outdir', './out'),
            k_points: [kx, ky, kz],
            ecutwfc: ecutwfc,
            ecutrho: ecutrho,
            conv_thr: convThr,
            occupations: 'smearing',
            smearing: 'marzari-vanderbilt',
            degauss: 0.01,
            mixing_beta: isNaN(mix) ? (noncolin ? 0.15 : 0.3) : mix,
            forc_conv_thr: isNaN(fctNum) ? 1.0e-4 : fctNum,
            force_ibrav_zero: !!opts.force_ibrav_zero,
        };
        if (opts.ibrav_override !== undefined && opts.ibrav_override !== null && !Number.isNaN(opts.ibrav_override))
            body.ibrav_override = opts.ibrav_override;
        var pseudos = (typeof window.cifPseudosCollectForApi === 'function') ? window.cifPseudosCollectForApi() : null;
        if (pseudos && noncolin && typeof window.pwGenScalarToFullRel === 'function') {
            var upgraded = {};
            Object.keys(pseudos).forEach(function (sym) {
                upgraded[sym] = window.pwGenScalarToFullRel(pseudos[sym]);
            });
            pseudos = upgraded;
        }
        if (pseudos) body.pseudos = pseudos;
        if (noncolin) {
            body.noncolin = true;
            body.lspinorb = true;
            body.nspin = 4;
        } else {
            var nspinEl = document.getElementById('cif_nspin') || document.getElementById('nspin');
            if (nspinEl) {
                var ns = parseInt(nspinEl.value, 10);
                if (ns === 1 || ns === 2 || ns === 4) body.nspin = ns;
            }
        }
        var cifDiag = pick('cif_diagonalization', '') || pick('diagonalization', '');
        if (cifDiag) body.diagonalization = cifDiag;
        if (typeof window.qeCollectPolarizationOptionsForApi === 'function') {
            var polCif = window.qeCollectPolarizationOptionsForApi(calcType);
            Object.keys(polCif).forEach(function (k) { body[k] = polCif[k]; });
        }
        if (calcType === 'scf_berry') {
            body.lberry = true;
            body.gdir = body.gdir != null ? body.gdir : 3;
            body.nppstr = body.nppstr != null ? body.nppstr : 8;
        }
        if (calcType === 'scf_born' && !body.conv_thr) {
            body.conv_thr = '1.0d-12';
        }
        return body;
    };

    /** Si DFT+U CIF activé avant conversion : lignes Hubbard encore vides alors qu'on a déjà atomic_species. */
    window.ensureCifHubbardSpeciesRowsFromAnalysis = async function (analysis) {
        try {
            var en = document.getElementById('cif_hubbard_enable');
            if (!en || !en.checked) return;
            var zone = document.getElementById('cif_hubbard_species_zone');
            if (!zone || !analysis || !(analysis.atomic_species && analysis.atomic_species.length)) return;
            if (zone.querySelector('input[data-cif-u], input[data-cif-j0]')) return;
            if (typeof window.renderHubbardSpeciesInputs === 'function')
                zone.innerHTML = window.renderHubbardSpeciesInputs('cif', analysis.atomic_species);
            if (typeof window.applyHubbardDefaultsFromDbToZone === 'function')
                await window.applyHubbardDefaultsFromDbToZone('cif');
        } catch (_eHb) {}
    };

    /** API legacy : injecte input_dft + Hubbard depuis le même panneau que le flux serveur autonome. */
    window.finalizeCifLegacyInputInject = function (pwText) {
        var txt = pwText || '';
        if (typeof window.injectInputDftHubbardIntoPwText !== 'function') return txt;
        var cidEl = document.getElementById('cif_input_dft');
        var idFt = '';
        try {
            if (cidEl && typeof window.normalizePwInputDft === 'function')
                idFt = window.normalizePwInputDft(cidEl.value || '') || '';
        } catch (__eCf) {}
        try {
            var opts = { hubbard_prefix: 'cif' };
            if (idFt) opts.input_dft = idFt;
            return window.injectInputDftHubbardIntoPwText(txt, opts);
        } catch (__ex) {
            return txt;
        }
    };

    // -------- Détection des espèces --------
    window.cifHubbardDetectFromCif = async function () {
        var zone = document.getElementById('cif_hubbard_species_zone');
        if (!zone) return;
        var enEl = document.getElementById('cif_hubbard_enable');
        if (enEl && !enEl.checked) enEl.checked = true;

        var cifHub = (typeof window.getCifDataCurrent === 'function') ? window.getCifDataCurrent() : (window.cifDataCurrent || null);
        if (!cifHub || !cifHub.content) {
            zone.innerHTML = '<div style="padding: 10px; background: #fff1f2; border: 1px solid #fda4af; border-radius: 6px; color: #9f1239; font-size: 0.85em;">Aucun fichier CIF chargé.</div>';
            return;
        }
        zone.innerHTML = '<div style="padding: 10px; color: #57534e;">⏳ Analyse en cours…</div>';
        try {
            var base = (typeof getGenInputsApiBase === 'function') ? getGenInputsApiBase() : '';
            var ctypeHub = '';
            try {
                var _cth = (typeof window.pickCifUiControl === 'function')
                    ? window.pickCifUiControl('cif_cell_type', 'gestion_cif_cell_type')
                    : (document.getElementById('cif_cell_type') || document.getElementById('gestion_cif_cell_type'));
                ctypeHub = _cth ? _cth.value : '';
            } catch (_eCt) {}
            var _bodyAn = { cif_text: cifHub.content };
            if (ctypeHub)
                _bodyAn.cell_type = ctypeHub;
            var r = await fetch(base + '/api/cif/analyze', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(_bodyAn),
            });
            if (!r.ok) throw new Error('analyze HTTP ' + r.status);
            var d = await r.json();
            var syms = (d && d.analysis && d.analysis.atomic_species) ? d.analysis.atomic_species : [];
            zone.innerHTML = buildSpeciesTable('cif', syms);
            if (typeof window.applyHubbardDefaultsFromDbToZone === 'function')
                await window.applyHubbardDefaultsFromDbToZone('cif');
            if (typeof window.nspin4Flow !== 'undefined') {
                try { window.nspin4Flow.refresh('cif'); } catch (_eN4hub) {}
            }
        } catch (e) {
            console.error(e);
            var _baseTry = (typeof getGenInputsApiBase === 'function') ? getGenInputsApiBase() : '';
            var _help = (typeof window.explainGenApiFetchError === 'function')
                ? window.explainGenApiFetchError(e, _baseTry)
                : escHtml(e.message || String(e));
            zone.innerHTML = '<div style="padding: 12px; background: #fff1f2; border: 1px solid #fda4af; border-radius: 6px; color: #9f1239; font-size: 0.85em; line-height:1.45;">'
                + '<strong>Échec analyse CIF</strong> — ' + _help + '</div>';
        }
    };

    window.genHubbardDetectFromTextarea = async function () {
        var zone = document.getElementById('gen_hubbard_species_zone');
        if (!zone) return;
        var enEl = document.getElementById('gen_hubbard_enable');
        if (enEl) enEl.checked = true;
        if (typeof window.pwGenShowHubbardPanel === 'function') window.pwGenShowHubbardPanel();
        else if (typeof window.pwGenToggleHubbardBlockVisible === 'function') window.pwGenToggleHubbardBlockVisible(true);
        var syms = [];
        if (typeof window.pwGenCollectSpeciesForHubbard === 'function') {
            syms = window.pwGenCollectSpeciesForHubbard();
        } else {
            var ta = document.getElementById('atomic_species');
            var raw = ta ? ta.value : '';
            if ((!raw || !String(raw).trim()) && window.atomicSpeciesGlobal) raw = window.atomicSpeciesGlobal;
            syms = parseSymbolsFromAtomicSpecies(raw);
        }
        if (!syms.length) {
            zone.innerHTML = '<div style="padding:10px;background:#fff;border:1px dashed #fdba74;border-radius:6px;color:#78350f;font-size:0.85em;">'
                + 'Aucune espèce détectée — renseignez <code>ATOMIC_SPECIES</code> ci‑dessus.</div>';
            return;
        }
        zone.innerHTML = buildSpeciesTable('gen', syms);
        if (typeof window.applyHubbardDefaultsFromDbToZone === 'function')
            await window.applyHubbardDefaultsFromDbToZone('gen');
    };

    window.ensureGenHubbardSpeciesRowsFromSymbols = async function (symbols) {
        var zone = document.getElementById('gen_hubbard_species_zone');
        if (!zone || !(symbols && symbols.length)) return;
        var enEl = document.getElementById('gen_hubbard_enable');
        if (enEl) enEl.checked = true;
        zone.innerHTML = buildSpeciesTable('gen', symbols);
        if (typeof window.applyHubbardDefaultsFromDbToZone === 'function')
            await window.applyHubbardDefaultsFromDbToZone('gen');
    };

    document.addEventListener('DOMContentLoaded', function () {
        var cifPseudo = document.getElementById('cif_pseudo_dir');
        if (cifPseudo && !String(cifPseudo.value || '').trim() && window.QE_CONFIG && window.QE_CONFIG.PSEUDO_DIR) {
            cifPseudo.value = window.QE_CONFIG.PSEUDO_DIR;
        }
        var cifOut = document.getElementById('cif_outdir');
        if (cifOut && (!String(cifOut.value || '').trim() || cifOut.value === './out') &&
                window.QE_CONFIG && window.QE_CONFIG.OUTPUTS_DIR) {
            cifOut.value = window.QE_CONFIG.OUTPUTS_DIR;
        }
        toggleManifoldVisibility('cif');
        toggleManifoldVisibility('gen');
        toggleManifoldVisibility('gestion');
        updateHubbardLegacyExpertWrap('cif');
        updateHubbardLegacyExpertWrap('gen');
        updateHubbardLegacyExpertWrap('gestion');
        var sCif = document.getElementById('cif_hubbard_syntax');
        if (sCif) sCif.addEventListener('change', function () { toggleManifoldVisibility('cif'); });
        var sGen = document.getElementById('gen_hubbard_syntax');
        if (sGen) sGen.addEventListener('change', function () { toggleManifoldVisibility('gen'); });
        var sGes = document.getElementById('gestion_hubbard_syntax');
        if (sGes) sGes.addEventListener('change', function () { toggleManifoldVisibility('gestion'); });

        var ghEn = document.getElementById('gen_hubbard_enable');
        if (ghEn) {
            ghEn.addEventListener('change', function () {
                if (typeof window.pwGenShowHubbardPanel === 'function') window.pwGenShowHubbardPanel();
                if (ghEn.checked) {
                    if (typeof window.genHubbardDetectFromTextarea === 'function') {
                        window.genHubbardDetectFromTextarea();
                    }
                }
            });
        }
        if (typeof window.pwGenShowHubbardPanel === 'function') window.pwGenShowHubbardPanel();
        setTimeout(function () {
            try {
                if (typeof window.pwGenRefreshHubbardPanel === 'function') {
                    window.pwGenRefreshHubbardPanel();
                } else if (typeof window.pwGenRefreshHubbardIfMagnetic === 'function') {
                    window.pwGenRefreshHubbardIfMagnetic();
                }
            } catch (_eInitHb) {}
        }, 150);
        var chEn = document.getElementById('cif_hubbard_enable');
        if (chEn) {
            chEn.addEventListener('change', function () {
                if (!chEn.checked || typeof window.cifHubbardDetectFromCif !== 'function') return;
                var zcif = document.getElementById('cif_hubbard_species_zone');
                if (zcif && !zcif.querySelector('input[data-cif-u], input[data-cif-j0]'))
                    window.cifHubbardDetectFromCif();
            });
        }

        if (typeof window.updateCifIbravManualVisibility === 'function')
            window.updateCifIbravManualVisibility();
    });
})();

// ═══════════════════════════════════════════════════════════════════════════
// SCRIPT COMPLET GESTION FICHIERS - ONGLET 2
// ═══════════════════════════════════════════════════════════════════════════

console.log('🔧 Chargement script_gestion_fichiers_complet.js v49 (fix liste CIF visible)...');

const API_BASE_URL = 'http://localhost:5007';

function __gestEscHtml(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

/** Vrai si l'élément est réellement visible (pas seulement display≠none sur lui-même). */
function __gestIsVisible(el) {
    if (!el) return false;
    try {
        var node = el;
        while (node && node !== document.documentElement) {
            var st = window.getComputedStyle(node);
            if (st.display === 'none' || st.visibility === 'hidden') return false;
            node = node.parentElement;
        }
        return el.getClientRects().length > 0;
    } catch (_eVis) {
        return el.offsetParent !== null;
    }
}

function __gestStandaloneOps() {
    if (typeof window !== 'undefined' && window.__GEN_INPUTS_STANDALONE__) return true;
    try {
        var p = String(window.location.port || '');
        if (p === '5012') return true;
    } catch (_e) {}
    return false;
}

/** Cible la bonne zone de liste (accès rapide vs gestion — évite les id dupliqués). */
function __gestListeInputsDiv() {
    var gest = document.getElementById('subsection_gestion');
    if (__gestIsVisible(gest)) {
        var leg = document.getElementById('liste_inputs_existants');
        if (leg) return leg;
    }
    var det = document.getElementById('tab1_autres_entrees');
    var zoneQr = document.getElementById('zone_resultats_fichiers');
    if (__gestIsVisible(zoneQr) && det && det.open) {
        var rap = document.getElementById('liste_inputs_rapide');
        if (rap) return rap;
    }
    return document.getElementById('liste_inputs_rapide')
        || document.getElementById('liste_inputs_existants');
}

function __gestListeCifDiv() {
    var gest = document.getElementById('subsection_gestion');
    if (__gestIsVisible(gest)) {
        var leg = document.getElementById('liste_fichiers_cif');
        if (leg) return leg;
    }
    var det = document.getElementById('tab1_autres_entrees');
    var zoneQr = document.getElementById('zone_resultats_fichiers');
    if (__gestIsVisible(zoneQr) && det && det.open) {
        var rap = document.getElementById('liste_cif_rapide');
        if (rap) return rap;
    }
    return document.getElementById('liste_fichiers_cif')
        || document.getElementById('liste_cif_rapide');
}

function __gestGenApiBase() {
    if (typeof getGenInputsApiBase === 'function') return getGenInputsApiBase();
    return 'http://127.0.0.1:5012';
}

function __gestSafeFileSegment(name) {
    return String(name || '').trim().replace(/[^A-Za-z0-9._-]+/g, '_') || 'material';
}

async function __gestResolveOutputsRoot(forceRefresh, source) {
    var src = String(source || 'direct').toLowerCase();
    var cacheKey = src === 'cif' ? '__gestOutputsRootCif' : '__gestOutputsRootDirect';
    if (!forceRefresh && window[cacheKey]) return window[cacheKey];
    if (!forceRefresh && src === 'direct' && window.__gestOutputsRoot) return window.__gestOutputsRoot;
    var base = __gestGenApiBase();
    try {
        var r = await fetch(base + '/api/paths');
        if (r.ok) {
            var d = await r.json();
            var root = (src === 'cif') ? (d.outputs_root_cif || d.inputs_dir_cif) : (d.outputs_root_direct || d.inputs_dir_direct || d.outputs_root);
            if (root) {
                window[cacheKey] = root;
                if (src === 'direct') window.__gestOutputsRoot = root;
                return root;
            }
        }
    } catch (_ePaths) {}
    try {
        var r2 = await fetch(base + '/api/version');
        if (r2.ok) {
            var d2 = await r2.json();
            var root2 = (src === 'cif') ? d2.outputs_root_cif : (d2.outputs_root_direct || d2.outputs_root);
            if (root2) {
                window[cacheKey] = root2;
                if (src === 'direct') window.__gestOutputsRoot = root2;
                return root2;
            }
        }
    } catch (_eVer) {}
    if (typeof window.qeInputsRootFor === 'function') {
        return window.qeInputsRootFor(src);
    }
    return null;
}

/** Sauvegarde sous inputs_générés_direct/ ou inputs_convertis_cif/ */
window.__gestSaveInputToGenerated = async function __gestSaveInputToGenerated(materialName, calcType, inputContent, source) {
    var src = String(source || 'direct').toLowerCase();
    var mat = __gestSafeFileSegment(materialName);
    var calc = __gestSafeFileSegment(calcType || 'scf');
    var outName = mat + '_' + calc + '.in';
    var relative = mat + '/' + outName;
    var folderLabel = (src === 'cif') ? 'inputs_convertis_cif' : 'inputs_générés_direct';

    if (__gestStandaloneOps()) {
        try {
            var response = await fetch(__gestGenApiBase() + '/api/inputs/save', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    text: inputContent,
                    material: mat,
                    calculation_label: calc,
                    filename: outName,
                    source: src,
                    layout: 'flat'
                })
            });
            var data = await response.json();
            if (!response.ok || !data.ok) {
                return { ok: false, error: (data && data.error) || ('HTTP ' + response.status) };
            }
            return {
                ok: true,
                path: data.path || '',
                relative: data.relative || relative,
                filename: data.filename || outName,
                source: src,
                folder: folderLabel
            };
        } catch (e) {
            return { ok: false, error: e.message || String(e) };
        }
    }

    var legacyRoot = (typeof window.qeInputsRootFor === 'function')
        ? window.qeInputsRootFor(src)
        : ('./' + folderLabel);
    var legacyPath = String(legacyRoot).replace(/\/+$/, '') + '/' + relative;
    try {
        var saveResponse = await fetch(API_BASE_URL + '/api/sauvegarder_fichier', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ fichier: legacyPath, contenu: inputContent })
        });
        var saveData = await saveResponse.json();
        if (saveData.success) {
            return { ok: true, path: legacyPath, relative: relative, filename: outName, source: src, folder: folderLabel };
        }
        return { ok: false, error: saveData.error || saveData.message || 'sauvegarde échouée' };
    } catch (e) {
        return { ok: false, error: e.message || String(e) };
    }
};

/** Sauvegarde automatique après conversion CIF → input (utilisé par convertirCIFversInput). */
window.cifSaveConvertedInput = async function cifSaveConvertedInput(materialName, calcType, inputContent) {
    if (typeof window.__gestSaveInputToGenerated !== 'function') {
        return { ok: false, error: 'Fonction de sauvegarde indisponible.' };
    }
    return window.__gestSaveInputToGenerated(materialName, calcType, inputContent, 'cif');
};

/** Affiche le bandeau + boutons après conversion CIF (aperçu + sauvegarde). */
window.cifRenderConversionResult = function cifRenderConversionResult(opts) {
    opts = opts || {};
    var materialName = opts.materialName || 'material';
    var calcType = opts.calcType || 'scf';
    var inputContent = opts.inputContent || '';
    var analysis = opts.analysis || {};
    var ibravUsed = opts.ibravUsed != null ? opts.ibravUsed : '?';
    var saveResult = opts.saveResult || null;
    var statusDiv = opts.statusDiv || __gestGetStatusDiv();
    if (!statusDiv) return;

    __gestRelocateCifStatusPanel();
    statusDiv = document.getElementById('gestion_fichiers_status') || statusDiv;

    var outName = materialName + '_' + calcType + '.in';
    var savedOk = saveResult && saveResult.ok;
    var saveInfoHtml = savedOk
        ? '<p id="cif_preview_save_info" style="margin:0 0 12px;padding:10px 12px;background:#ecfdf5;border-radius:8px;color:#065f46;font-size:0.9em;line-height:1.5;">'
            + '💾 <strong>Sauvegardé dans</strong> <code>inputs_convertis_cif/' + __gestEscHtml(saveResult.relative || (materialName + '/' + outName)) + '</code></p>'
        : '<p id="cif_preview_save_info" style="margin:0 0 12px;padding:10px 12px;background:#fef3c7;border-radius:8px;color:#92400e;font-size:0.9em;line-height:1.5;">'
            + '⚠️ <strong>Sauvegarde automatique échouée</strong> — cliquez <strong>💾 Sauvegarder</strong> ci-dessous.'
            + (saveResult && saveResult.error ? ' (' + __gestEscHtml(saveResult.error) + ')' : '') + '</p>';

    var prev = String(inputContent).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    statusDiv.innerHTML = ''
        + '<div class="alert alert-success" style="padding:18px;border-radius:10px;line-height:1.5;border:2px solid #22c55e;">'
        + '<h4 style="margin:0 0 8px;color:#166534;">✅ Input QE généré' + (savedOk ? ' et sauvegardé' : '') + ' — ' + __gestEscHtml(analysis.formula || materialName) + '</h4>'
        + '<p style="margin:0 0 12px;color:#334155;font-size:0.92em;">'
        + '<strong>Fichier :</strong> <code>' + __gestEscHtml(outName) + '</code> · '
        + 'ibrav=' + __gestEscHtml(ibravUsed) + ' · ' + __gestEscHtml(analysis.nat || '?') + ' atomes</p>'
        + saveInfoHtml
        + '<p style="margin:0 0 14px;padding:10px 12px;background:#f0fdf4;border-radius:8px;color:#166534;font-size:0.9em;">'
        + '👇 <strong>Aperçu de l\'input</strong> — modifiable avant re-sauvegarde si besoin.</p>'
        + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;">'
        + '<button type="button" id="cif_zone_charger" class="btn btn-success" style="padding:10px 18px;font-weight:bold;">✅ Charger dans l\'éditeur</button>'
        + '<button type="button" id="cif_zone_save" class="btn btn-primary" style="padding:10px 18px;font-weight:bold;">💾 Sauvegarder dans inputs_convertis_cif</button>'
        + '<button type="button" id="cif_zone_copier" class="btn" style="padding:10px 18px;font-weight:bold;background:#ff9800;color:#fff;border:none;border-radius:6px;cursor:pointer;">📋 Copier</button>'
        + '</div>'
        + '<textarea id="cif_zone_preview" style="width:100%;height:320px;font-family:monospace;font-size:0.82em;'
        + 'background:#0f172a;color:#a5d6a7;border:2px solid #22c55e;border-radius:6px;padding:12px;box-sizing:border-box;">'
        + prev + '</textarea>'
        + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;">'
        + '<button type="button" id="cif_zone_xcrysden" class="btn" style="padding:10px 18px;font-weight:bold;background:linear-gradient(135deg,#1565c0,#0d47a1);color:#fff;border:none;border-radius:6px;cursor:pointer;">📐 XCrysDen</button>'
        + '<button type="button" id="cif_zone_vesta" class="btn" style="padding:10px 18px;font-weight:bold;background:linear-gradient(135deg,#e65100,#ff9800);color:#fff;border:none;border-radius:6px;cursor:pointer;">🔬 VESTA</button>'
        + '<button type="button" id="cif_zone_retour" class="btn" style="padding:10px 18px;font-weight:bold;background:#475569;color:#fff;border:none;border-radius:6px;cursor:pointer;">↩️ Retour à l&apos;interface</button>'
        + '</div></div>';

    var previewEl = document.getElementById('cif_zone_preview');
    var getContent = function () {
        return previewEl ? previewEl.value : inputContent;
    };

    document.getElementById('cif_zone_charger').onclick = function () {
        if (typeof window.chargerInputDansEditeur === 'function') {
            window.chargerInputDansEditeur(getContent(), materialName);
        } else {
            alert('Éditeur input non disponible sur cette page.');
        }
    };
    document.getElementById('cif_zone_save').onclick = async function () {
        await __gestTriggerCifSave();
    };
    document.getElementById('cif_zone_copier').onclick = function () {
        var txt = getContent();
        if (navigator.clipboard) {
            navigator.clipboard.writeText(txt).then(function () {
                __gestFlashToast('✅ Input copié dans le presse-papiers', 'success');
            });
        } else {
            alert('Copie non supportée sur ce navigateur.');
        }
    };
    var btnXcd = document.getElementById('cif_zone_xcrysden');
    if (btnXcd) btnXcd.onclick = function () {
        if (typeof window.ouvrirStructureExterne === 'function') {
            window.ouvrirStructureExterne('xcrysden', getContent());
        } else {
            alert('Module visualisation non chargé.');
        }
    };
    var btnVesta = document.getElementById('cif_zone_vesta');
    if (btnVesta) btnVesta.onclick = function () {
        if (typeof window.ouvrirStructureExterne === 'function') {
            window.ouvrirStructureExterne('vesta', getContent());
        } else {
            alert('Module visualisation non chargé.');
        }
    };
    var btnRetour = document.getElementById('cif_zone_retour');
    if (btnRetour) btnRetour.onclick = function () {
        if (typeof window.tab1RevenirInterface === 'function') {
            window.tab1RevenirInterface();
        } else if (typeof window.tab1SwitchMainTab === 'function') {
            window.tab1SwitchMainTab('generation');
        }
    };
    if (typeof window.tab1SetWorkflowStep === 'function') window.tab1SetWorkflowStep(5, 'done');
    if (typeof window.tab1RefreshWorkflowTracker === 'function') window.tab1RefreshWorkflowTracker();
    if (typeof window.afficherVisualisation3D === 'function' && inputContent) {
        try {
            var cifSlot = document.getElementById('cif_embedded_viewer_slot');
            if (!cifSlot) {
                cifSlot = document.createElement('div');
                cifSlot.id = 'cif_embedded_viewer_slot';
                cifSlot.className = 'qe-embedded-viewer-slot';
                var prevTa = document.getElementById('cif_zone_preview');
                if (prevTa && prevTa.parentNode) {
                    prevTa.parentNode.insertBefore(cifSlot, prevTa.nextSibling);
                } else if (statusDiv) {
                    statusDiv.appendChild(cifSlot);
                }
            }
            window.afficherVisualisation3D(inputContent, { parent: cifSlot, scroll: false });
        } catch (_eVisCif) { console.warn(_eVisCif); }
    }
    __gestShowCifFloatingBar(true, 'result');
    __gestScrollToCifSaveResult();
    if (typeof window.tab1ScrollToInputPreview === 'function') {
        window.tab1ScrollToInputPreview({ delay: 150, block: 'center' });
    } else if (previewEl) {
        try { previewEl.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (_eSc) {}
    }
};

/** Résumé formule : réduite (DyVO3) vs composition maille (Dy4O12V4, Z, nat). */
function __gestFormulaSummaryHtml(analysis, materialName) {
    const a = analysis || {};
    const reduced = a.formula || String(materialName || '').replace(/_mp-.*$/i, '').replace(/_primitive$/i, '') || '?';
    const cell = a.formula_cell || '';
    const z = a.formula_units_z;
    const nat = a.nat;
    let html = `<strong>Formule réduite:</strong> ${__gestEscHtml(reduced)}`;
    if (cell && cell !== reduced) {
        html += ` · <strong>Maille (Z≈${z || '?'}):</strong> ${__gestEscHtml(cell)}`;
    } else if (z > 1) {
        html += ` · <strong>Z (maille):</strong> ≈${z}`;
    }
    if (nat) {
        html += ` · <strong>Atomes:</strong> ${nat}`;
    }
    return html;
}

window.formatCifFormulaSummaryHtml = __gestFormulaSummaryHtml;

/** Bloc HTML d'aide : mode autonome vs API complète 5007 */
function __gestApiConnexionHelpInner(error) {
    const msg = __gestEscHtml(error && error.message);
    const blocked = __gestStandaloneOps()
        || (typeof window.isGenInputsStandaloneBlockedError === 'function'
            && window.isGenInputsStandaloneBlockedError(error));
    if (blocked) {
        return ''
            + '<h4>Mode autonome (port 5012)</h4>'
            + '<p><strong>Message :</strong> ' + msg + '</p>'
            + '<p>Si vous voyez encore une mention du <strong>port 5007</strong> alors que vous voulez seulement générer des inputs, vérifiez que cette page est ouverte en <strong>http://127.0.0.1:5012</strong> après <code>./DEMARRER.sh</code>.</p>'
            + '<p><strong>À faire :</strong></p>'
            + '<ol style="margin:8px 0 0 18px;padding:0;">'
            + '<li>Terminal : <code>cd</code> vers le dossier <strong>génération_inputs-QE</strong> puis <code>./DEMARRER.sh</code>.</li>'
            + '<li>Navigateur : <code>http://127.0.0.1:5012</code> (pas <code>file://</code>).</li>'
            + '<li>Réessayez « Ouvrir inputs existants » ou les CIF — ils passent par l’API locale 5012.</li>'
            + '</ol>'
            + '<p style="margin-top:12px;">Le port <strong>5007</strong> sert à l’<em>interface complète</em> (calculs, pseudos, etc.) : optionnel pour ce paquet portable.</p>';
    }
    return ''
        + '<h4>🔧 Solution (API complète 5007)</h4>'
        + '<p><strong>1)</strong> Démarrez l’API QE (port 5007) dans un terminal :</p>'
        + '<pre style="background: #263238; color: #aed581; padding: 15px; border-radius: 5px; margin: 10px 0; overflow-x: auto;">cd Interface-QE_v1\n'
        + './DEMARRER.sh</pre>'
        + '<p><strong>2)</strong> Ouvrez l’interface via <strong>http://localhost:5007/generation-inputs/</strong> (recommandé — évite l’erreur <code>NetworkError</code> avec <code>file://</code>).</p>'
        + '<p>Alternative : <code>cd Interface-QE_v1/api &amp;&amp; python3 api_qe_ubuntu.py</code></p>';
}

// ═══════════════════════════════════════════════════════════════════════════
// UTILITAIRES
// ═══════════════════════════════════════════════════════════════════════════

window.formatFileSize = function(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
};

window.afficherNotificationSucces = function(message) {
    var statusDiv = document.getElementById('gestion_fichiers_status');
    if (statusDiv && statusDiv.querySelector('#cif_zone_preview')) {
        __gestFlashToast(message, 'success');
        return;
    }
    if (statusDiv) {
        statusDiv.innerHTML = '<div class="alert alert-success" style="animation: slideIn 0.5s; background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; margin: 15px 0;">' + message + '</div>';
        setTimeout(function () {
            if (statusDiv.innerHTML.indexOf(message) >= 0 && !statusDiv.querySelector('#cif_zone_preview')) {
                statusDiv.innerHTML = '';
            }
        }, 5000);
    }
};

window.afficherNotificationErreur = function(message) {
    var statusDiv = document.getElementById('gestion_fichiers_status');
    if (statusDiv && statusDiv.querySelector('#cif_zone_preview')) {
        __gestFlashToast(message, 'error');
        return;
    }
    if (statusDiv) {
        statusDiv.innerHTML = '<div class="alert alert-error" style="background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 15px; border-radius: 5px; margin: 15px 0;">' + message + '</div>';
        setTimeout(function () {
            if (statusDiv.innerHTML.indexOf(message) >= 0 && !statusDiv.querySelector('#cif_zone_preview')) {
                statusDiv.innerHTML = '';
            }
        }, 8000);
    }
};

/** Toast flottant — n'écrase pas le panneau résultat CIF (textarea). */
function __gestFlashToast(message, kind) {
    var id = 'gest_fichiers_toast';
    var el = document.getElementById(id);
    if (!el) {
        el = document.createElement('div');
        el.id = id;
        el.className = 'qe-save-toast qe-save-toast--corner';
        document.body.appendChild(el);
    }
    var ok = kind !== 'error';
    el.className = 'qe-save-toast qe-save-toast--corner ' + (ok ? 'qe-save-toast--ok' : 'qe-save-toast--err');
    el.textContent = String(message || '').replace(/<[^>]+>/g, '');
    el.style.opacity = '1';
    clearTimeout(el.__gestToastT);
    el.__gestToastT = setTimeout(function () {
        el.style.opacity = '0';
    }, ok ? 5500 : 8000);
}

// ═══════════════════════════════════════════════════════════════════════════
// FONCTION 1: Lister Inputs Existants
// ═══════════════════════════════════════════════════════════════════════════

window.listerInputsExistants = async function() {
    console.log('📋 Liste des inputs existants...');
    const listeDiv = __gestListeInputsDiv();
    if (!listeDiv) {
        alert('❌ Zone liste_inputs introuvable! Utilisez « Gestion des fichiers CIF » ou ouvrez Gestion fichiers.');
        return;
    }
    
    listeDiv.innerHTML = '<p style="color: #666; text-align: center; padding: 20px;">🔄 Chargement...</p>';
    
    try {
        if (__gestStandaloneOps()) {
            const base = __gestGenApiBase();
            const response = await fetch(`${base}/api/inputs/list`);
            if (!response.ok) throw new Error(`Erreur API: ${response.status}`);
            const data = await response.json();
            if (!data.ok) throw new Error(data.error || 'Liste inputs');
            const inputsOnly = (data.items || []).filter(it => it.path && /\.in$/i.test(it.path));
            const directory = (data.outputs_root_direct && data.outputs_root_cif)
                ? (data.outputs_root_direct + ' + ' + data.outputs_root_cif)
                : (data.outputs_root || 'inputs_générés_direct + inputs_convertis_cif');

            if (inputsOnly.length === 0) {
                listeDiv.innerHTML = `
                <div class="alert alert-warning" style="background: #fff3cd; border: 1px solid #ffc107; color: #856404; padding: 20px; border-radius: 8px;">
                    <h3>📭 Aucun fichier .in trouvé</h3>
                    <p>Répertoire listé : <code>${__gestEscHtml(directory)}</code></p>
                    <p>💡 Générez un input (direct → <code>inputs_générés_direct/</code>, CIF → <code>inputs_convertis_cif/</code>).</p>
                </div>
            `;
                return;
            }

            let html = `
            <div class="alert alert-success" style="background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                ✅ <strong>${inputsOnly.length} input(s) .in</strong> dans <code>${__gestEscHtml(directory)}</code>
            </div>
            <div style="display: grid; gap: 15px;">
        `;

            inputsOnly.forEach((input, idx) => {
                const filepath = input.path;
                const filepathEscaped = filepath.replace(/'/g, "\\'");
                const srcBadge = input.source === 'cif'
                    ? '<span style="background:#0f766e;color:#fff;padding:2px 8px;border-radius:8px;font-size:0.78em;margin-left:6px;">CIF</span>'
                    : '<span style="background:#1d4ed8;color:#fff;padding:2px 8px;border-radius:8px;font-size:0.78em;margin-left:6px;">direct</span>';
                const rel = input.relative || filepath.split('/').pop();
                const nomMateriau = rel.replace(/\.in$/i, '') || 'Input';
                const nomMateriauEscaped = nomMateriau.replace(/'/g, "\\'");
                const taille = input.size != null ? (input.size / 1024).toFixed(1) + ' KB' : 'N/A';

                html += `
                <div class="card" style="background: ${idx % 2 === 0 ? '#f9f9f9' : '#fff'}; border-left: 4px solid #4CAF50; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                        <div style="flex: 1; min-width: 200px;">
                            <h4 style="margin: 0 0 8px 0; color: #333;">📄 ${__gestEscHtml(rel)} ${srcBadge}</h4>
                            <div style="color: #666; font-size: 0.9em; line-height: 1.6;">
                                <strong>Matériau:</strong> ${__gestEscHtml(nomMateriau)}<br>
                                <strong>Taille:</strong> ${taille}<br>
                                <strong>Chemin:</strong> <code style="font-size: 0.85em; background: #eee; padding: 2px 5px; border-radius: 3px;">${__gestEscHtml(filepath)}</code>
                            </div>
                        </div>
                        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                            <button class="btn btn-primary" onclick="ouvrirInputPourEdition('${filepathEscaped}', '${nomMateriauEscaped}')" style="padding: 10px 15px; border-radius: 5px;">
                                ✏️ Éditer
                            </button>
                            <button class="btn" onclick="verifierEtSauvegarderInput('${filepathEscaped}', '${nomMateriauEscaped}')" style="padding: 10px 15px; border-radius: 5px; background: #17a2b8; color: white;">
                                ✅ Vérifier & Sauvegarder
                            </button>
                            <button class="btn" onclick="switchTab(1)" style="padding: 10px 15px; border-radius: 5px; background: #6f42c1; color: white;">
                                📈 Suivi des Calculs
                            </button>
                        </div>
                    </div>
                </div>
            `;
            });

            html += '</div>';
            listeDiv.innerHTML = html;
            return;
        }

        const response = await fetch(`${API_BASE_URL}/api/lister_inputs`);
        if (!response.ok) throw new Error(`Erreur API: ${response.status}`);
        
        const data = await response.json();
        console.log('Inputs trouvés:', data);
        
        if (!data.inputs || data.inputs.length === 0) {
            listeDiv.innerHTML = `
                <div class="alert alert-warning" style="background: #fff3cd; border: 1px solid #ffc107; color: #856404; padding: 20px; border-radius: 8px;">
                    <h3>📭 Aucun input trouvé</h3>
                    <p>Le répertoire <code>${data.directory || 'inputs_générés_direct'}</code> est vide.</p>
                    <p>💡 Générez d'abord des inputs depuis l'<strong>Onglet 1: Génération Inputs</strong></p>
                </div>
            `;
            return;
        }
        
        let html = `
            <div class="alert alert-success" style="background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                ✅ <strong>${data.inputs.length} input(s) trouvé(s)</strong> dans <code>${data.directory}</code>
            </div>
            <div style="display: grid; gap: 15px;">
        `;
        
        data.inputs.forEach((input, idx) => {
            // ✅ L'API retourne 'chemin' pas 'filepath', ‘fichier’ pas 'filename', 'nom' pas 'prefix'
            const filepath = input.chemin || `inputs_générés_direct/${input.fichier || input.nom + '.in'}`;
            const filepathEscaped = filepath.replace(/'/g, "\\'");
            const nomMateriau = input.nom || input.prefix || (input.fichier ? input.fichier.replace('.in', '') : 'Input');
            const nomMateriauEscaped = nomMateriau.replace(/'/g, "\\'");
            
            html += `
                <div class="card" style="background: ${idx % 2 === 0 ? '#f9f9f9' : '#fff'}; border-left: 4px solid #4CAF50; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                        <div style="flex: 1; min-width: 200px;">
                            <h4 style="margin: 0 0 8px 0; color: #333;">📄 ${input.fichier || 'N/A'}</h4>
                            <div style="color: #666; font-size: 0.9em; line-height: 1.6;">
                                <strong>Matériau:</strong> ${nomMateriau}<br>
                                <strong>Type:</strong> ${input.type || 'inconnu'}<br>
                                <strong>Taille:</strong> ${input.taille ? (input.taille / 1024).toFixed(1) + ' KB' : 'N/A'}<br>
                                <strong>Chemin:</strong> <code style="font-size: 0.85em; background: #eee; padding: 2px 5px; border-radius: 3px;">${filepath}</code>
                            </div>
                        </div>
                        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                            <button class="btn btn-primary" onclick="ouvrirInputPourEdition('${filepathEscaped}', '${nomMateriauEscaped}')" style="padding: 10px 15px; border-radius: 5px;">
                                ✏️ Éditer
                            </button>
                            <button class="btn" onclick="verifierEtSauvegarderInput('${filepathEscaped}', '${nomMateriauEscaped}')" style="padding: 10px 15px; border-radius: 5px; background: #17a2b8; color: white;">
                                ✅ Vérifier & Sauvegarder
                            </button>
                            <button class="btn" onclick="switchTab(1)" style="padding: 10px 15px; border-radius: 5px; background: #6f42c1; color: white;">
                                📈 Suivi des Calculs
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        listeDiv.innerHTML = html;
        
    } catch (error) {
        console.error('❌ Erreur:', error);
        const blocked = __gestStandaloneOps()
            || (typeof window.isGenInputsStandaloneBlockedError === 'function'
                && window.isGenInputsStandaloneBlockedError(error));
        const title = blocked ? '❌ Impossible de lister les inputs' : '❌ Erreur de connexion à l\'API';
        listeDiv.innerHTML = `
            <div class="alert alert-error" style="background: #f8d7da; border: 2px solid #f5c6cb; color: #721c24; padding: 20px; border-radius: 8px;">
                <h3>${title}</h3>
                <p><strong>Message:</strong> ${__gestEscHtml(error.message)}</p>
                <hr style="margin: 15px 0;">
                ${__gestApiConnexionHelpInner(error)}
            </div>
        `;
    }
};

// ═══════════════════════════════════════════════════════════════════════════
// FONCTION 2: Éditer un Input
// ═══════════════════════════════════════════════════════════════════════════

window.ouvrirInputPourEdition = async function(filepath, prefix) {
    console.log('✏️ Ouverture input pour édition:', filepath);
    
    try {
        let rawContent = '';
        if (__gestStandaloneOps()) {
            const response = await fetch(`${__gestGenApiBase()}/api/files/read`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ path: filepath })
            });
            if (!response.ok) throw new Error(`Erreur API: ${response.status}`);
            const data = await response.json();
            if (!data.ok) {
                afficherNotificationErreur(`❌ Erreur: ${data.error || 'lecture'}`);
                return;
            }
            rawContent = data.content != null ? String(data.content) : '';
        } else {
            const response = await fetch(`${API_BASE_URL}/api/lire_fichier`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ fichier: filepath })
            });
            if (!response.ok) throw new Error(`Erreur API: ${response.status}`);
            const data = await response.json();
            if (!data.success) {
                afficherNotificationErreur(`❌ Erreur: ${data.message}`);
                return;
            }
            rawContent = data.contenu != null ? String(data.contenu) : '';
        }
        
        let editeurDiv = document.getElementById('editeur_input_zone');
        if (!editeurDiv) {
            const zoneResultats = document.getElementById('zone_resultats_fichiers');
            editeurDiv = document.createElement('div');
            editeurDiv.id = 'editeur_input_zone';
            if (zoneResultats) {
                zoneResultats.appendChild(editeurDiv);
            } else {
                document.body.appendChild(editeurDiv);
            }
        }
        
        editeurDiv.style.display = 'block';
        editeurDiv.innerHTML = `
            <div class="card" style="background: #fff; padding: 25px; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h3 style="margin: 0; color: #333;">✏️ Édition: ${prefix}.in</h3>
                    <button onclick="fermerEditeurInput()" class="btn" style="background: #dc3545; color: white; padding: 8px 15px; border-radius: 5px;">❌ Fermer</button>
                </div>
                
                <textarea id="editeur_input_content" style="width: 100%; height: 500px; font-family: 'Courier New', monospace; font-size: 14px; padding: 15px; border: 2px solid #ddd; border-radius: 5px; resize: vertical;"></textarea>
                
                <div style="margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                    <button onclick="sauvegarderInputEdite('${filepath.replace(/'/g, "\\'")}', '${prefix.replace(/'/g, "\\'")}' )" class="btn btn-primary" style="padding: 12px 25px; font-size: 1em;">Sauvegarder</button>
                    <button onclick="copierInputEditeur()" class="btn" style="background: #17a2b8; color: white; padding: 12px 25px; font-size: 1em;">Copier</button>
                </div>
                
                <input type="hidden" id="editeur_input_filepath" value="">
                <input type="hidden" id="editeur_input_prefix" value="">
            </div>
        `;
        const ta = document.getElementById('editeur_input_content');
        if (ta) ta.value = rawContent;
        const hf = document.getElementById('editeur_input_filepath');
        const hp = document.getElementById('editeur_input_prefix');
        if (hf) hf.value = filepath;
        if (hp) hp.value = prefix;
        
        editeurDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
        
    } catch (error) {
        console.error('❌ Erreur:', error);
        afficherNotificationErreur(`❌ Impossible d'ouvrir l'input: ${error.message}`);
    }
};

window.fermerEditeurInput = function() {
    const editeurDiv = document.getElementById('editeur_input_zone');
    if (editeurDiv) {
        editeurDiv.style.display = 'none';
        editeurDiv.innerHTML = '';
    }
};

window.sauvegarderInputEdite = async function(filepath, prefix) {
    console.log('💾 Sauvegarde input édité:', filepath);
    
    const textarea = document.getElementById('editeur_input_content');
    if (!textarea) {
        alert('❌ Éditeur introuvable!');
        return;
    }
    
    const content = textarea.value;
    
    try {
        if (__gestStandaloneOps()) {
            const response = await fetch(`${__gestGenApiBase()}/api/files/write`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    path: filepath,
                    content: content
                })
            });
            if (!response.ok) throw new Error(`Erreur API: ${response.status}`);
            const data = await response.json();
            if (!data.ok) {
                afficherNotificationErreur(`❌ Erreur: ${data.error || 'sauvegarde'}`);
                return;
            }
            afficherNotificationSucces(`✅ Input sauvegardé: ${prefix}.in`);
            return;
        }

        const response = await fetch(`${API_BASE_URL}/api/sauvegarder_input_edite`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                filepath: filepath,
                content: content
            })
        });
        
        if (!response.ok) throw new Error(`Erreur API: ${response.status}`);
        
        const data = await response.json();
        
        if (data.success) {
            afficherNotificationSucces(`✅ Input sauvegardé: ${prefix}.in`);
        } else {
            afficherNotificationErreur(`❌ Erreur: ${data.message}`);
        }
        
    } catch (error) {
        console.error('❌ Erreur:', error);
        afficherNotificationErreur(`❌ Impossible de sauvegarder: ${error.message}`);
    }
};

window.copierInputEditeur = function() {
    const textarea = document.getElementById('editeur_input_content');
    if (!textarea) {
        alert('❌ Éditeur introuvable!');
        return;
    }
    
    textarea.select();
    document.execCommand('copy');
    afficherNotificationSucces('📋 Contenu copié dans le presse-papier!');
};

// ═══════════════════════════════════════════════════════════════════════════
// FONCTION 2B: Vérifier et Sauvegarder un Input
// ═══════════════════════════════════════════════════════════════════════════

window.verifierEtSauvegarderInput = async function(filepath, prefix) {
    console.log('✅ Vérification et sauvegarde:', filepath);
    
    try {
        if (__gestStandaloneOps()) {
            const readResponse = await fetch(`${__gestGenApiBase()}/api/files/read`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ path: filepath })
            });
            if (!readResponse.ok) throw new Error(`Erreur lecture: ${readResponse.status}`);
            const readData = await readResponse.json();
            if (!readData.ok) throw new Error(readData.error || 'lecture');
            afficherNotificationSucces(`✅ «${prefix}.in» lu. (Vérification syntaxe avancée réservée à l’API 5007.)`);
            return;
        }

        // Lire le contenu actuel de l'input
        const readResponse = await fetch(`${API_BASE_URL}/api/lire_input`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filepath: filepath })
        });
        
        if (!readResponse.ok) throw new Error(`Erreur lecture: ${readResponse.status}`);
        
        const readData = await readResponse.json();
        if (!readData.success) throw new Error(readData.message);
        
        const content = readData.content;
        
        // Vérifier la syntaxe de l'input
        const verifyResponse = await fetch(`${API_BASE_URL}/api/verifier_input`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content: content })
        });
        
        if (!verifyResponse.ok) throw new Error(`Erreur vérification: ${verifyResponse.status}`);
        
        const verifyData = await verifyResponse.json();
        
        if (verifyData.valid) {
            // Input valide - sauvegarder
            afficherNotificationSucces(`✅ Input "${prefix}.in" vérifié et valide! Fichier sauvegardé.`);
        } else {
            // Afficher les erreurs
            let errorMsg = `⚠️ Problèmes détectés dans "${prefix}.in":\n\n`;
            if (verifyData.errors && verifyData.errors.length > 0) {
                verifyData.errors.forEach((err, i) => {
                    errorMsg += `${i+1}. ${err}\n`;
                });
            }
            errorMsg += '\nL\'input a été sauvegardé mais vérifiez les erreurs.';
            alert(errorMsg);
        }
        
    } catch (error) {
        console.error('❌ Erreur:', error);
        // Si l'API de vérification n'existe pas, juste confirmer la lecture
        afficherNotificationSucces(`✅ Input "${prefix}.in" lu avec succès. (Vérification API non disponible)`);
    }
};

// ═══════════════════════════════════════════════════════════════════════════
// FONCTION 3: Lancer un Calcul
// ═══════════════════════════════════════════════════════════════════════════

window.lancerCalculInput = async function(filepath, prefix) {
    console.log('🚀 Lancement calcul:', filepath);
    
    if (!confirm(`🚀 Lancer le calcul pour "${prefix}.in" ?\n\nLe calcul sera exécuté sur Ubuntu avec Quantum ESPRESSO.`)) {
        return;
    }
    
    try {
        // Déterminer les chemins input et output
        // filepath exemple: /home/hiadsi/génération_inputs-QE/inputs_générés_direct/BaTiO3/BaTiO3_relax.in
        const inputDir = filepath.substring(0, filepath.lastIndexOf('/'));
        const outputDir = inputDir.replace('/inputs/', '/outputs/');
        
        const response = await fetch(`${API_BASE_URL}/api/lancer_calcul_custom`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                input_file: filepath,
                output_dir: outputDir,
                prefix: prefix,
                nprocs: 4
            })
        });
        
        if (!response.ok) throw new Error(`Erreur API: ${response.status}`);
        
        const data = await response.json();
        
        if (data.success) {
            afficherNotificationSucces(`✅ Calcul lancé: ${prefix}\n📊 ID: ${data.calcul_id}\n📂 Output: ${data.output_file || outputDir}`);
            
            // Basculer vers l'onglet Suivi des Calculs après 1 seconde
            setTimeout(() => {
                const tabSuivi = document.querySelector('[data-tab="tab3"]');
                if (tabSuivi) {
                    tabSuivi.click();
                } else {
                    const tabs = document.querySelectorAll('.tab');
                    tabs.forEach(tab => {
                        if (tab.textContent.includes('Suivi des Calculs')) {
                            tab.click();
                        }
                    });
                }
                
                // Rafraîchir la liste des calculs après avoir basculé
                setTimeout(() => {
                    if (typeof window.listerCalculsEnCours === 'function') {
                        console.log('🔄 Rafraîchissement automatique de la liste des calculs...');
                        window.listerCalculsEnCours();
                    } else {
                        console.warn('⚠️ listerCalculsEnCours non disponible, rechargez la page');
                    }
                }, 500);
            }, 1000);
        } else {
            afficherNotificationErreur(`❌ Erreur: ${data.message || data.error}`);
        }
        
    } catch (error) {
        console.error('❌ Erreur:', error);
        afficherNotificationErreur(`❌ Impossible de lancer le calcul: ${error.message}`);
    }
};

window.lancerCalculDepuisEditeur = async function(filepath, prefix) {
    // Sauvegarder d'abord
    await sauvegarderInputEdite(filepath, prefix);
    
    // Attendre un peu puis lancer
    setTimeout(() => {
        lancerCalculInput(filepath, prefix);
    }, 500);
};

// ═══════════════════════════════════════════════════════════════════════════
// FONCTION 4: Lister Fichiers CIF
// ═══════════════════════════════════════════════════════════════════════════

window.listerFichiersCIF = async function() {
    console.log('📋 Liste des fichiers CIF...');
    const listeDiv = __gestListeCifDiv();
    if (!listeDiv) {
        alert('❌ Zone liste CIF introuvable! Cliquez « Gestion des fichiers CIF » dans la barre d\'outils.');
        return;
    }
    
    listeDiv.innerHTML = '<p style="color: #666; text-align: center; padding: 20px;">🔄 Chargement...</p>';
    
    try {
        let data;
        let cifRootLabel;

        if (__gestStandaloneOps()) {
            const response = await fetch(`${__gestGenApiBase()}/api/cif/list`, { cache: 'no-store' });
            if (!response.ok) throw new Error(`Erreur API: ${response.status}`);
            data = await response.json();
            if (!data.ok) throw new Error(data.error || 'cif/list');
            cifRootLabel = data.directory || '';
            if (window.QE_CONFIG && data.directory) {
                window.QE_CONFIG.CIF_DIR = data.directory;
            }
        } else {
            const response = await fetch(`${API_BASE_URL}/api/lister_fichiers`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ directory: (typeof window.qeCifSourceDir === 'function' ? window.qeCifSourceDir() : './fichiers_cif') })
            });
            if (!response.ok) throw new Error(`Erreur API: ${response.status}`);
            data = await response.json();
            cifRootLabel = (typeof window.qeCifSourceDir === 'function' ? window.qeCifSourceDir() : './fichiers_cif');
        }

        console.log('CIFs trouvés:', data);

        const files = data.files || [];
        const legacyOk = __gestStandaloneOps() || data.status === 'success';
        if (!legacyOk || files.length === 0) {
            listeDiv.innerHTML = `
                <div class="alert alert-warning" style="background: #fff3cd; border: 1px solid #ffc107; color: #856404; padding: 20px; border-radius: 8px;">
                    <h3>📭 Aucun fichier listé</h3>
                    <p>Répertoire : <code>${__gestEscHtml(cifRootLabel)}</code></p>
                    <p>💡 Ajoutez des fichiers <code>.cif</code> dans ce répertoire sur la machine où tourne l’API 5012.</p>
                    <hr style="margin: 15px 0;">
                    <p><strong>Exemple :</strong></p>
                    <pre style="background: #263238; color: #aed581; padding: 10px; border-radius: 5px;">mkdir -p ${__gestEscHtml(cifRootLabel)}\ncp votre_fichier.cif ${__gestEscHtml(cifRootLabel)}/</pre>
                </div>
            `;
            return;
        }

        const fichiersCif = files.filter(f => f.type === 'file' && f.name && f.name.endsWith('.cif'));

        if (fichiersCif.length === 0) {
            listeDiv.innerHTML = `
                <div class="alert alert-warning" style="background: #fff3cd; border: 1px solid #ffc107; color: #856404; padding: 20px; border-radius: 8px;">
                    <h3>📭 Aucun fichier CIF trouvé</h3>
                    <p>Aucun <code>.cif</code> dans <code>${__gestEscHtml(cifRootLabel)}</code></p>
                </div>
            `;
            return;
        }

        let html = `
            <div class="alert alert-info" style="background:#eff6ff;border:2px solid #3b82f6;color:#1e3a8a;padding:14px;border-radius:8px;margin-bottom:16px;line-height:1.5;font-size:0.92em;">
                ${typeof window.t === 'function' ? window.t('cif.list_steps') : '<strong>2 étapes :</strong> ① cliquez sur un <strong>fichier CIF</strong> · ② réglez maille, calcul, magnétisme, DFT+U · ③ bouton vert <strong>CONVERTIR CIF → INPUT QE</strong>.'}
            </div>
            <div class="alert alert-success" style="background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                ✅ <strong>${typeof window.t === 'function' ? window.t('cif.files_found', { n: fichiersCif.length }) : (fichiersCif.length + ' fichier(s) CIF trouvé(s)')}</strong> — <code>${__gestEscHtml(cifRootLabel)}</code>
            </div>
            <div style="display: grid; gap: 15px;">
        `;

        fichiersCif.forEach((cif, idx) => {
            const filepath = cif.path || (cifRootLabel.replace(/\/+$/, '') + '/' + cif.name);
            const filepathEscaped = filepath.replace(/'/g, "\\'");
            const filenameEscaped = cif.name.replace(/'/g, "\\'");

            html += `
                <div class="card gest-cif-file-card" role="button" tabindex="0"
                    data-cif-path="${encodeURIComponent(filepath)}" data-cif-name="${encodeURIComponent(cif.name)}"
                    title="${typeof window.t === 'function' ? window.t('cif.click_open') : 'Cliquer pour ouvrir la conversion'}"
                    style="background: ${idx % 2 === 0 ? '#fff3e0' : '#fff'}; border-left: 4px solid #ff9800; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); cursor: pointer;">
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                        <div style="flex: 1; min-width: 200px;">
                            <h4 style="margin: 0 0 8px 0; color: #333; font-weight: 700;">🔬 ${__gestEscHtml(cif.name)}</h4>
                            <div style="color: #666; font-size: 0.9em; line-height: 1.6;">
                                <strong>${typeof window.t === 'function' ? window.t('cif.size') : 'Taille:'}</strong> ${cif.size ? (cif.size / 1024).toFixed(1) + ' KB' : 'N/A'}<br>
                                <strong>${typeof window.t === 'function' ? window.t('cif.modified') : 'Modifié:'}</strong> ${__gestEscHtml(cif.modified || 'N/A')}<br>
                                <strong>${typeof window.t === 'function' ? window.t('cif.path') : 'Chemin:'}</strong> <code style="font-size: 0.85em; background: #eee; padding: 2px 5px; border-radius: 3px;">${__gestEscHtml(filepath)}</code>
                            </div>
                        </div>
                        <div>
                            <span class="btn btn-success gest-cif-convert-btn" data-cif-path="${encodeURIComponent(filepath)}" data-cif-name="${encodeURIComponent(cif.name)}" style="display:inline-block;padding: 12px 25px; border-radius: 5px; background: linear-gradient(135deg, #ff9800 0%, #ff5722 100%); pointer-events: none;">
                                ⚙️ ${typeof window.t === 'function' ? window.t('cif.open_conversion') : 'Ouvrir conversion →'}
                            </span>
                        </div>
                    </div>
                </div>
            `;
        });

        html += '</div>';
        listeDiv.innerHTML = html;

    } catch (error) {
        console.error('❌ Erreur:', error);
        const blocked = __gestStandaloneOps()
            || (typeof window.isGenInputsStandaloneBlockedError === 'function'
                && window.isGenInputsStandaloneBlockedError(error));
        const title = blocked ? '❌ Impossible de lister les CIF' : '❌ Erreur de connexion à l\'API';
        listeDiv.innerHTML = `
            <div class="alert alert-error" style="background: #f8d7da; border: 2px solid #f5c6cb; color: #721c24; padding: 20px; border-radius: 8px;">
                <h3>${title}</h3>
                <p><strong>Message:</strong> ${__gestEscHtml(error.message)}</p>
                <hr style="margin: 15px 0;">
                ${__gestApiConnexionHelpInner(error)}
            </div>
        `;
    }
};

// ═══════════════════════════════════════════════════════════════════════════
// CIF — formulaire statique index.html (cache + restauration si DOM effacé)
// ═══════════════════════════════════════════════════════════════════════════

var __CIF_EDITOR_TEMPLATE_HTML = '';

function __cacheCifEditorTemplateOnce() {
    if (__CIF_EDITOR_TEMPLATE_HTML) return;
    try {
        if (typeof window.cacheCifEditorTemplateFromDom === 'function') {
            window.cacheCifEditorTemplateFromDom();
        }
        if (window.__CIF_EDITOR_TEMPLATE_HTML_BOOT) {
            __CIF_EDITOR_TEMPLATE_HTML = window.__CIF_EDITOR_TEMPLATE_HTML_BOOT;
            return;
        }
    } catch (_eBoot) {}
    var z = document.getElementById('editeur_cif_zone');
    if (z && z.innerHTML && z.querySelector('#cif_type_magnetisme_card')) {
        __CIF_EDITOR_TEMPLATE_HTML = z.innerHTML;
    }
}

function __ensureCifEditorDom() {
    __cacheCifEditorTemplateOnce();
    var z = document.getElementById('editeur_cif_zone');
    if (!z) {
        z = __gestInsertCifEditorHost();
    }
    if (!z) return null;
    if (!z.querySelector('#cif_type_magnetisme_card')) {
        var tpl = __CIF_EDITOR_TEMPLATE_HTML || window.__CIF_EDITOR_TEMPLATE_HTML_BOOT || '';
        if (!tpl) {
            z.innerHTML = '<textarea id="editeur_cif_content" style="display:none"></textarea>';
        } else {
            z.innerHTML = tpl;
        }
        try {
            if (typeof window.fillInputDftSelect === 'function') {
                var dftEl = document.getElementById('cif_input_dft');
                if (dftEl) window.fillInputDftSelect(dftEl);
            }
        } catch (_eDft) {}
    }
    return z;
}

/** Recrée #editeur_cif_zone si script_tab1_restructuration l'a effacé. */
function __gestInsertCifEditorHost() {
    var tpl = __CIF_EDITOR_TEMPLATE_HTML || window.__CIF_EDITOR_TEMPLATE_HTML_BOOT || '';
    var host = document.getElementById('subsection_gestion')
        || document.getElementById('zone_resultats_fichiers')
        || document.querySelector('.tab-content')
        || document.body;

    if (!document.getElementById('gestion_fichiers_status')) {
        var st = document.createElement('div');
        st.id = 'gestion_fichiers_status';
        st.style.marginTop = '15px';
        host.appendChild(st);
    }

    var z = document.createElement('div');
    z.id = 'editeur_cif_zone';
    z.style.display = 'none';
    z.style.margin = '25px 0';
    z.innerHTML = tpl || '<textarea id="editeur_cif_content" style="display:none"></textarea>';

    var status = document.getElementById('gestion_fichiers_status');
    if (status && status.parentNode === host) {
        host.insertBefore(z, status);
    } else {
        host.appendChild(z);
    }
    __CIF_EDITOR_TEMPLATE_HTML = tpl || z.innerHTML;
    return z;
}

function __gestGetStatusDiv() {
    var gest = document.getElementById('subsection_gestion');
    if (__gestIsVisible(gest)) {
        var inGest = gest.querySelector('#gestion_fichiers_status') || document.getElementById('gestion_fichiers_status');
        if (inGest) return inGest;
    }
    var qr = document.getElementById('zone_resultats_fichiers');
    if (__gestIsVisible(qr)) {
        var inQr = qr.querySelector('#gestion_fichiers_status');
        if (!inQr) {
            inQr = document.getElementById('gestion_fichiers_status');
            if (!inQr) {
                inQr = document.createElement('div');
                inQr.id = 'gestion_fichiers_status';
            }
            inQr.style.marginTop = '15px';
            qr.appendChild(inQr);
        }
        return inQr;
    }
    var d = document.getElementById('gestion_fichiers_status');
    if (d) return d;
    var host = document.getElementById('subsection_gestion')
        || document.getElementById('zone_resultats_fichiers')
        || document.querySelector('.tab-content');
    if (!host) return null;
    d = document.createElement('div');
    d.id = 'gestion_fichiers_status';
    d.style.marginTop = '15px';
    host.appendChild(d);
    return d;
}

function __gestEnsureHiddenCifTextarea(content) {
    var ta = document.getElementById('editeur_cif_content');
    if (!ta) {
        ta = document.createElement('textarea');
        ta.id = 'editeur_cif_content';
        ta.style.display = 'none';
        var zone = document.getElementById('editeur_cif_zone');
        if (zone) zone.appendChild(ta);
        else document.body.appendChild(ta);
    }
    if (content != null) ta.value = String(content);
    return ta;
}

/** Déplace l'éditeur CIF dans le panneau CIF complet (jamais dans zone_resultats max-height 400px). */
function __gestPlaceCifEditorNearList() {
    var zone = document.getElementById('editeur_cif_zone');
    if (!zone) return;

    var gest = document.getElementById('subsection_gestion');
    if (gest && !__gestIsVisible(gest)) {
        try {
            if (typeof window.tab1SwitchMainTab === 'function') window.tab1SwitchMainTab('cif');
            else if (typeof afficherSousSection === 'function') afficherSousSection('gestion');
        } catch (_eTab) {}
    }

    var host = gest || document.getElementById('subsection_gestion_mount');
    if (!host) return;

    var anchor = document.getElementById('liste_fichiers_cif')
        || document.getElementById('gestion_fichiers_status')
        || gest && gest.querySelector('.card');

    if (zone.parentNode !== host) {
        if (anchor && anchor.parentNode === host) {
            var ref = anchor.nextSibling;
            if (ref && ref.parentNode === host && ref !== zone) {
                host.insertBefore(zone, ref);
            } else {
                host.appendChild(zone);
            }
        } else {
            host.appendChild(zone);
        }
    }

    var st = document.getElementById('gestion_fichiers_status');
    if (st && st.parentNode !== host) {
        host.appendChild(st);
    }

    zone.style.display = 'block';
}

function __gestScrollToCifEditorTop() {
    setTimeout(function () {
        var anchor = document.getElementById('cif_editor_step1_preview')
            || document.getElementById('cif_preview_panel')
            || document.getElementById('cif_contenu_brut')
            || document.getElementById('editeur_cif_zone');
        if (!anchor) return;
        try {
            anchor.scrollIntoView({ behavior: 'smooth', block: 'start' });
        } catch (_eSc) {
            try { anchor.scrollIntoView(true); } catch (_eSc2) {}
        }
    }, 120);
}

function __gestEnsureCifTopActionsBar(zone) {
    if (!zone) zone = document.getElementById('editeur_cif_zone');
    if (!zone || document.getElementById('cif_editor_actions_top')) return;
    var info = document.getElementById('cif_editeur_info');
    var top = document.createElement('section');
    top.id = 'cif_editor_actions_top';
    top.className = 'cif-editor-actions-top';
    top.innerHTML = ''
        + '<p class="cif-editor-actions-top-hint">Remplissez les options ci-dessous, puis cliquez <strong>CONVERTIR</strong> — bouton aussi fixé en bas de l&apos;écran.</p>'
        + '<div class="cif-editor-actions-top-btns">'
        + '<button type="button" class="btn btn-success cif-btn-convert-main" onclick="convertirCIFversInput()">🔄 CONVERTIR CIF → INPUT QE</button>'
        + '<button type="button" id="cif_top_save_btn" class="btn btn-primary cif-btn-save-main" style="display:none;">💾 Sauvegarder l&apos;input</button>'
        + '</div>'
        + '<div id="cif_save_result_mount"></div>';
    if (info && info.parentNode) {
        info.parentNode.insertBefore(top, info.nextSibling);
    } else {
        zone.insertBefore(top, zone.firstChild);
    }
}

function __gestRelocateCifStatusPanel() {
    var mount = document.getElementById('cif_save_result_mount');
    var st = document.getElementById('gestion_fichiers_status');
    if (!mount || !st) return;
    if (st.parentNode !== mount) {
        mount.appendChild(st);
    }
    st.style.marginTop = '0';
}

/** Déclenche la sauvegarde CIF (aperçu éditable ou dernier résultat) avec retour utilisateur. */
async function __gestTriggerCifSave() {
    var previewEl = document.getElementById('cif_zone_preview');
    var last = window.__lastCifConvertedInput || {};
    var materialName = last.materialName || 'material';
    var calcType = last.calcType || 'scf';
    var content = previewEl ? previewEl.value : (last.inputContent || '');
    if (!content || !String(content).trim()) {
        __gestFlashToast(typeof window.t === 'function' ? window.t('cif.save_failed') : 'Sauvegarde échouée — contenu vide.', 'error');
        return { ok: false, error: 'empty content' };
    }
    if (typeof window.cifSaveConvertedInput !== 'function') {
        __gestFlashToast(typeof window.t === 'function' ? window.t('cif.save_failed') : 'Fonction de sauvegarde indisponible.', 'error');
        return { ok: false, error: 'cifSaveConvertedInput missing' };
    }
    var sr = await window.cifSaveConvertedInput(materialName, calcType, content);
    if (sr.ok) {
        var msg = typeof window.t === 'function'
            ? window.t('toast.saved', { path: sr.relative || '' })
            : ('✅ Sauvegardé : inputs_convertis_cif/' + (sr.relative || ''));
        __gestFlashToast(msg, 'success');
        var infoEl = document.getElementById('cif_preview_save_info');
        if (infoEl) {
            var savedLbl = typeof window.t === 'function' ? window.t('cif.saved_to') : 'Sauvegardé dans';
            infoEl.innerHTML = '💾 <strong>' + savedLbl + '</strong> <code>inputs_convertis_cif/' + __gestEscHtml(sr.relative) + '</code>';
            infoEl.style.background = '#ecfdf5';
            infoEl.style.color = '#065f46';
        }
        if (typeof window.listerInputsExistants === 'function') {
            try { window.listerInputsExistants(); } catch (_eLi) {}
        }
    } else {
        var errMsg = typeof window.t === 'function'
            ? window.t('toast.save_error', { error: sr.error || window.t('cif.save_failed') })
            : ('❌ ' + (sr.error || 'Sauvegarde échouée'));
        __gestFlashToast(errMsg, 'error');
    }
    return sr;
}

function __gestSyncCifTopSaveButton(show) {
    var topBtn = document.getElementById('cif_top_save_btn');
    if (!topBtn) return;
    if (show) {
        topBtn.style.display = 'inline-block';
        topBtn.onclick = function () { __gestTriggerCifSave(); };
    } else {
        topBtn.style.display = 'none';
        topBtn.onclick = null;
    }
}

/** Scroll vers le bouton CONVERTIR / sauvegarde (fin du formulaire CIF). */
function __gestScrollToCifConvertButton() {
    setTimeout(function () {
        var anchor = document.getElementById('cif_editor_actions_top')
            || document.getElementById('cif_editor_step3_actions')
            || document.querySelector('#editeur_cif_zone .cif-btn-convert-main');
        if (!anchor) {
            __gestScrollToCifEditorTop();
            return;
        }
        try {
            anchor.scrollIntoView({ behavior: 'smooth', block: 'end' });
        } catch (_eSc) {
            try { anchor.scrollIntoView(false); } catch (_eSc2) {}
        }
    }, 220);
}

function __gestScrollToCifSaveResult() {
    setTimeout(function () {
        var anchor = document.getElementById('cif_save_result_mount')
            || document.getElementById('cif_zone_save')
            || document.getElementById('cif_top_save_btn')
            || document.getElementById('cif_zone_preview')
            || document.querySelector('#gestion_fichiers_status .alert-success')
            || document.getElementById('gestion_fichiers_status');
        if (!anchor) return;
        try {
            anchor.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } catch (_eSc) {
            try { anchor.scrollIntoView(true); } catch (_eSc2) {}
        }
    }, 280);
}

/** Barre fixe en bas : CONVERTIR + sauvegarde toujours visibles pendant l'édition CIF. */
function __gestEnsureCifFloatingBar() {
    var bar = document.getElementById('cif_floating_action_bar');
    if (bar) return bar;

    bar = document.createElement('div');
    bar.id = 'cif_floating_action_bar';
    bar.setAttribute('role', 'toolbar');
    bar.setAttribute('aria-label', 'Actions conversion CIF');
    bar.innerHTML = ''
        + '<div class="cif-floating-bar-inner">'
        + '<span class="cif-floating-bar-label" id="cif_floating_bar_label">' + (typeof window.t === 'function' ? window.t('cif.floating.edit') : 'Étape ③ — Conversion') + '</span>'
        + '<button type="button" id="cif_floating_convert_btn" class="btn btn-success">' + (typeof window.t === 'function' ? window.t('cif.convert') : '🔄 CONVERTIR CIF → INPUT QE') + '</button>'
        + '<button type="button" id="cif_floating_save_btn" class="btn btn-primary" style="display:none;">' + (typeof window.t === 'function' ? window.t('cif.floating.save') : '💾 Sauvegarder l&apos;input') + '</button>'
        + '<button type="button" id="cif_floating_result_btn" class="btn btn-primary" style="display:none;">' + (typeof window.t === 'function' ? window.t('cif.floating.preview') : '👁️ Voir aperçu &amp; sauvegarde') + '</button>'
        + '<button type="button" id="cif_floating_options_btn" class="btn" style="background:#64748b;color:#fff;border:none;border-radius:6px;padding:10px 16px;">' + (typeof window.t === 'function' ? window.t('cif.floating.options') : '↑ Options') + '</button>'
        + '<button type="button" id="cif_floating_close_btn" class="btn btn-secondary">' + (typeof window.t === 'function' ? window.t('cif.floating.close') : '✕ Fermer') + '</button>'
        + '</div>';

    document.body.appendChild(bar);
    if (bar.parentNode !== document.body) {
        document.body.appendChild(bar);
    }

    document.getElementById('cif_floating_convert_btn').onclick = function () {
        if (typeof window.convertirCIFversInput === 'function') {
            window.convertirCIFversInput();
        } else {
            alert('❌ Module conversion CIF non chargé — Ctrl+F5 sur http://127.0.0.1:5012');
        }
    };
    document.getElementById('cif_floating_save_btn').onclick = function () {
        __gestTriggerCifSave();
    };
    document.getElementById('cif_floating_result_btn').onclick = function () {
        __gestScrollToCifSaveResult();
    };
    document.getElementById('cif_floating_options_btn').onclick = function () {
        var step2 = document.getElementById('cif_editor_step2_options');
        if (step2) {
            try { step2.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (_e) { step2.scrollIntoView(true); }
        }
    };
    document.getElementById('cif_floating_close_btn').onclick = function () {
        if (typeof window.fermerEditeurCIF === 'function') window.fermerEditeurCIF();
    };
    return bar;
}

function __gestSetCifFloatingBarMode(mode) {
    var bar = __gestEnsureCifFloatingBar();
    var convertBtn = document.getElementById('cif_floating_convert_btn');
    var saveBtn = document.getElementById('cif_floating_save_btn');
    var resultBtn = document.getElementById('cif_floating_result_btn');
    var label = document.getElementById('cif_floating_bar_label');
    var m = String(mode || 'edit');

    if (m === 'result') {
        if (label) label.textContent = typeof window.t === 'function' ? window.t('cif.floating.result') : '✅ Input généré — sauvegarde';
        if (convertBtn) convertBtn.style.display = 'none';
        if (saveBtn) saveBtn.style.display = 'inline-block';
        if (resultBtn) resultBtn.style.display = 'inline-block';
        __gestSyncCifTopSaveButton(true);
    } else {
        if (label) label.textContent = typeof window.t === 'function' ? window.t('cif.floating.edit') : 'Étape ③ — Conversion';
        if (convertBtn) convertBtn.style.display = 'inline-block';
        if (saveBtn) saveBtn.style.display = 'none';
        if (resultBtn) resultBtn.style.display = 'none';
        __gestSyncCifTopSaveButton(false);
    }
}

function __gestShowCifFloatingBar(show, mode) {
    var bar = __gestEnsureCifFloatingBar();
    var on = !!show;
    bar.classList.toggle('cif-floating-bar--visible', on);
    bar.style.display = on ? 'block' : 'none';
    try {
        document.documentElement.classList.toggle('cif-floating-bar-open', on);
    } catch (_eHtml) {}
    if (on) {
        __gestSetCifFloatingBarMode(mode != null ? mode : 'edit');
    }
}

function __gestInjectCifFormHint(zone) {
    if (!zone) return;
    var step1 = zone.querySelector('#cif_editor_step1_preview');
    var step2 = zone.querySelector('#cif_editor_step2_options');
    var hint = zone.querySelector('#cif_convert_hint_banner');
    if (!hint) {
        hint = document.createElement('div');
        hint.id = 'cif_convert_hint_banner';
        hint.style.cssText = 'margin:0 0 16px;padding:12px 14px;background:#fff7ed;border:2px solid #f97316;border-radius:8px;color:#9a3412;font-size:0.9em;line-height:1.5;';
    }
    hint.innerHTML = '<strong>Actions en haut</strong> — bouton vert <strong>CONVERTIR CIF → INPUT QE</strong> (également fixé en bas de l&apos;écran).<br>'
        + 'Ensuite : maille → <code>ibrav</code> → <code>input_dft</code> → type de calcul → magnétisme → DFT+U (optionnel).';
    if (step2 && step2.parentNode) {
        step2.parentNode.insertBefore(hint, step2);
    } else if (step1 && step1.parentNode) {
        step1.parentNode.insertBefore(hint, step1.nextSibling);
    } else if (zone.firstChild) {
        zone.insertBefore(hint, zone.firstChild);
    } else {
        zone.appendChild(hint);
    }
}

function __applyCifPayload(filepath, filename, cifText) {
    var payload = {
        content: String(cifText || ''),
        filename: filename || 'structure.cif',
        filepath: filepath || '',
    };
    if (typeof window.syncCifDataCurrent === 'function') {
        window.syncCifDataCurrent(payload);
    } else {
        window.cifDataCurrent = payload;
    }
    return payload;
}

/** Affiche le formulaire CIF complet (index.html) et synchronise les données. */
window.__mountCifEditorFromFileImpl = function (filepath, filename, cifText) {
    __applyCifPayload(filepath, filename, cifText);
    __gestEnsureHiddenCifTextarea(cifText);

    var zone = __ensureCifEditorDom();
    if (!zone) {
        console.warn('[CIF] Formulaire absent — conversion possible sans panneau visuel.');
        return true;
    }

    var cd = (typeof window.getCifDataCurrent === 'function') ? window.getCifDataCurrent() : window.cifDataCurrent;

    try {
        if (typeof window.tab1SwitchMainTab === 'function') window.tab1SwitchMainTab('cif');
        else if (typeof afficherSousSection === 'function') afficherSousSection('gestion');
        else __gestShowGestionPane();
    } catch (_eTab) {}

    zone.style.display = 'block';
    __gestPlaceCifEditorNearList();
    __gestEnsureCifTopActionsBar(zone);
    __gestInjectCifFormHint(zone);
    __gestRelocateCifStatusPanel();
    __gestShowCifFloatingBar(true, 'edit');

    var pre = document.getElementById('cif_contenu_brut');
    if (pre && cd) pre.textContent = cd.content;

    var info = document.getElementById('cif_editeur_info');
    if (info) {
        info.innerHTML =
            '<strong>📁 Fichier :</strong> ' + __gestEscHtml(filename) +
            '<br><strong>📂 Chemin :</strong> <code style="font-size:0.88em;">' + __gestEscHtml(filepath) + '</code>';
    }

    var ta = document.getElementById('editeur_cif_content');
    if (!ta) {
        ta = document.createElement('textarea');
        ta.id = 'editeur_cif_content';
        ta.style.display = 'none';
        var card = zone.querySelector('.card');
        (card || zone).appendChild(ta);
    }
    if (cd) ta.value = cd.content;

    try {
        if (typeof window.initCifGestionAfterFragment === 'function') {
            window.initCifGestionAfterFragment();
        } else {
            if (typeof window.populateAllCalcTypeSelects === 'function') window.populateAllCalcTypeSelects();
            if (typeof window.qePolarizationMountPanels === 'function') window.qePolarizationMountPanels();
        }
        if (typeof window.fillInputDftSelect === 'function') {
            var dftEl = document.getElementById('cif_input_dft');
            if (dftEl) window.fillInputDftSelect(dftEl);
        }
        if (typeof window.fillCifIbravPickOptionsOnce === 'function') window.fillCifIbravPickOptionsOnce();
        if (typeof window.updateCifIbravManualVisibility === 'function') window.updateCifIbravManualVisibility();
        if (typeof window.cifSyncTypeMagnetisme === 'function') window.cifSyncTypeMagnetisme();
        if (typeof window.cifSyncOrdreMag === 'function') window.cifSyncOrdreMag();
        if (typeof window.cifOrdreMagSelectSyncRadios === 'function') window.cifOrdreMagSelectSyncRadios();
        if (typeof window.cifUpdateCifMagPanels === 'function') window.cifUpdateCifMagPanels();
        if (typeof window.qePolarizationUpdateVisibility === 'function') {
            var ct = document.getElementById('cif_calc_type');
            window.qePolarizationUpdateVisibility(ct ? ct.value : '');
        }
    } catch (_eMag) {}

    if (cd && cd.content && typeof window.afmApplyStructureGuidance === 'function') {
        window.afmFetchAnalysis(cd.content).then(function (d) {
            window.afmApplyStructureGuidance(d.analysis, { autoMagMode: false });
        }).catch(function () {});
    }

    __gestScrollToCifConvertButton();
    return true;
};
window.mountCifEditorFromFile = window.__mountCifEditorFromFileImpl;

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', __cacheCifEditorTemplateOnce);
} else {
    __cacheCifEditorTemplateOnce();
}

// ═══════════════════════════════════════════════════════════════════════════
// FONCTION 5: Convertir CIF en Input
// ═══════════════════════════════════════════════════════════════════════════

window.ouvrirCIFpourConversion = async function(filepath, filename, opts) {
    opts = opts || {};
    console.log('🔄 Ouverture CIF pour conversion:', filepath);
    
    try {
        if (location.protocol === 'file:') {
            alert('❌ Ouvrez http://127.0.0.1:5012 (./DEMARRER.sh) — pas file://');
            return false;
        }
        __gestShowGestionPane();

        let cifText = '';
        if (__gestStandaloneOps()) {
            const response = await fetch(`${__gestGenApiBase()}/api/files/read`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ path: filepath })
            });
            if (!response.ok) throw new Error(`Erreur API: ${response.status}`);
            const dataRd = await response.json();
            if (!dataRd.ok) {
                afficherNotificationErreur(`❌ Erreur: ${dataRd.error || 'lecture'}`);
                alert('❌ Lecture CIF: ' + (dataRd.error || 'échec'));
                return false;
            }
            cifText = dataRd.content != null ? String(dataRd.content) : '';
        } else {
            const response = await fetch(`${API_BASE_URL}/api/lire_fichier`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ fichier: filepath })
            });
            if (!response.ok) throw new Error(`Erreur API: ${response.status}`);
            const data = await response.json();
            if (!data.success) {
                afficherNotificationErreur(`❌ Erreur: ${data.message}`);
                alert('❌ Lecture CIF: ' + (data.message || 'échec'));
                return false;
            }
            cifText = data.contenu != null ? String(data.contenu) : '';
        }

        if (!cifText || !cifText.trim()) {
            afficherNotificationErreur('❌ Fichier CIF vide.');
            alert('❌ Fichier CIF vide.');
            return false;
        }

        __applyCifPayload(filepath, filename, cifText);
        __gestEnsureHiddenCifTextarea(cifText);
        try {
            delete window.__cifSupercellApplied;
            delete window.__cifLastAnalysis;
        } catch (_eReset) {}

        if (typeof window.mountCifEditorFromFile === 'function') {
            window.mountCifEditorFromFile(filepath, filename, cifText);
        }

        if (!opts.silent) {
            afficherNotificationSucces('✅ CIF chargé — choisissez les options puis convertissez.');
        }
        if (typeof window.tab1SetWorkflowPath === 'function') window.tab1SetWorkflowPath('cif');
        if (typeof window.tab1HighlightWorkflowStep === 'function') window.tab1HighlightWorkflowStep(1);
        return true;
        
    } catch (error) {
        console.error('❌ Erreur:', error);
        var errMsg = (error && error.message) ? error.message : String(error);
        afficherNotificationErreur('❌ Impossible d\'ouvrir le CIF: ' + errMsg);
        if (typeof window.tab1ShowStatus === 'function') {
            window.tab1ShowStatus('error', '❌ Impossible d\'ouvrir le CIF : ' + errMsg);
        }
        return false;
    }
};

/** Bouton liste : ouvre le formulaire complet (choix maille, calcul, magnétisme, U) — conversion au clic vert. */
window.convertirCIFDepuisListe = async function (filepath, filename) {
    try {
        if (typeof window.tab1SwitchMainTab === 'function') {
            window.tab1SwitchMainTab('cif');
        } else if (typeof window.tab1PrepareAutresEntrees === 'function') {
            window.tab1PrepareAutresEntrees();
        }
        var okOpen = await window.ouvrirCIFpourConversion(filepath, filename, { silent: true });
        if (okOpen === false) return;
        var cd = __gestGetCifPayload();
        if (!cd || !cd.content) {
            var msg = '❌ CIF non chargé en mémoire après ouverture.';
            afficherNotificationErreur(msg);
            alert(msg);
            return;
        }
        var statusDiv = __gestGetStatusDiv();
        if (statusDiv) {
            statusDiv.innerHTML = '<div class="alert alert-info" style="padding:14px;border-radius:8px;background:#eff6ff;border:2px solid #3b82f6;color:#1e3a8a;line-height:1.55;font-size:0.92em;">'
                + '<strong>📋 CIF chargé — parcourez le formulaire du haut vers le bas</strong><br>'
                + '① Aperçu CIF · ② Options (maille, calcul, magnétisme, DFT+U…) · ③ Bouton vert <strong>CONVERTIR CIF → INPUT QE</strong>.'
                + '</div>';
        }
        __gestScrollToCifConvertButton();
    } catch (e) {
        console.error('convertirCIFDepuisListe:', e);
        var em = (e && e.message) ? e.message : String(e);
        afficherNotificationErreur('❌ Conversion: ' + em);
        alert('❌ Conversion: ' + em);
    }
};

window.fermerEditeurCIF = function() {
    __gestShowCifFloatingBar(false);
    const editeurDiv = document.getElementById('editeur_cif_zone');
    if (editeurDiv) {
        editeurDiv.style.display = 'none';
    }
    if (typeof window.clearCifDataCurrent === 'function') {
        window.clearCifDataCurrent();
    } else {
        window.cifDataCurrent = null;
    }
};

// Base URL de l'API autonome (port 5012) qui fait la détection ibrav intelligente
const GEN_API_BASE_URL = (function() {
    try {
        if (typeof window !== 'undefined' && window.location && window.location.protocol &&
            window.location.protocol.startsWith('http') && window.location.host) {
            return window.location.protocol + '//' + window.location.host;
        }
    } catch (e) { /* ignore */ }
    return 'http://127.0.0.1:5012';
})();

/** Alignement sur index.html : <code>window.__GEN_INPUTS_API_BASE__</code>, <code>localStorage</code>, etc. */
function resolveGenApiBase() {
    try {
        if (typeof window !== 'undefined' && typeof window.getGenInputsApiBase === 'function')
            return window.getGenInputsApiBase();
    } catch (e) { /* ignore */ }
    return GEN_API_BASE_URL;
}

/** Complète &IONS / &CELL si absents (relax / vc-relax) — filet de sécurité côté client. */
window.ensureCifCalcSections = function ensureCifCalcSections(text, calcType) {
    if (!text || typeof text !== 'string') return text;
    var ct = String(calcType || 'scf').trim().toLowerCase().replace(/_/g, '-');
    if (ct !== 'relax' && ct !== 'vc-relax' && ct !== 'vcrelax') {
        var m = text.match(/^\s*calculation\s*=\s*['"]([^'"]+)['"]/im);
        if (m) {
            ct = String(m[1]).trim().toLowerCase().replace(/_/g, '-');
            if (ct === 'vcrelax') ct = 'vc-relax';
        }
    }
    if (ct !== 'relax' && ct !== 'vc-relax') return text;
    var out = text;
    if (!/\bforc_conv_thr\b/i.test(out) && (ct === 'relax' || ct === 'vc-relax')) {
        out = out.replace(/(\&CONTROL[\s\S]*?)(^\s*\/\s*$)/m, function (_m, before, slash) {
            return before + '  forc_conv_thr = 1.0d-4\n' + slash;
        });
    }
    if (!/\&IONS\b/i.test(out)) {
        var ions = '\n&IONS\n  ion_dynamics = \'bfgs\'\n/\n';
        var elIdx = out.search(/^\s*&ELECTRONS\b/im);
        if (elIdx >= 0) {
            var afterEl = out.slice(elIdx);
            var closeRel = afterEl.search(/^\s*\/\s*$/m);
            if (closeRel >= 0) {
                var insertAt = elIdx + closeRel + afterEl.match(/^\s*\/\s*$/m)[0].length;
                out = out.slice(0, insertAt) + ions + out.slice(insertAt);
            } else {
                out = out.replace(/(\&ELECTRONS[\s\S]*?^\s*\/\s*$)/m, '$1' + ions);
            }
        }
    }
    if (ct === 'vc-relax' && !/\&CELL\b/i.test(out)) {
        var cell = '\n&CELL\n  cell_dynamics = \'bfgs\'\n  press = 0.0\n/\n';
        var ionsIdx = out.search(/^\s*&IONS\b/im);
        if (ionsIdx >= 0) {
            var afterIons = out.slice(ionsIdx);
            var closeIons = afterIons.search(/^\s*\/\s*$/m);
            if (closeIons >= 0) {
                var insCell = ionsIdx + closeIons + afterIons.match(/^\s*\/\s*$/m)[0].length;
                out = out.slice(0, insCell) + cell + out.slice(insCell);
            }
        } else {
            out = out.replace(/(\&ELECTRONS[\s\S]*?^\s*\/\s*$)/m, '$1' + cell);
        }
    }
    return out;
};

/** Remplissage tableau U depuis CIF dans le flux Liste fichiers → conversion (éditeur dynamique #gestion_*) */
window.detectGestionCifHubbardSpecies = async function () {
    const zone = document.getElementById('gestion_hubbard_species_zone');
    if (!zone) return;
    const enEl = document.getElementById('gestion_hubbard_enable');
    if (enEl && !enEl.checked) enEl.checked = true;
    const ta = document.getElementById('editeur_cif_content');
    const cifText = ta ? ta.value : '';
    if (!cifText || !String(cifText).trim()) {
        zone.innerHTML = '<div style="padding:8px;color:#9f1239;">Contenu CIF introuvable.</div>';
        return;
    }
    var fetchBase = resolveGenApiBase();
    zone.innerHTML = '<div style="padding:8px;color:#57534e;">⏳ Analyse…</div>';
    try {
        const r = await fetch(fetchBase + '/api/cif/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify((function(){
                var b = { cif_text: cifText };
                try {
                    var cs = (typeof window.pickCifUiControl === 'function')
                        ? window.pickCifUiControl('cif_cell_type', 'gestion_cif_cell_type', 'gestion')
                        : (document.getElementById('gestion_cif_cell_type')
                            || document.getElementById('cif_cell_type'));
                    if (cs && cs.value) b.cell_type = cs.value;
                } catch (_eGs) {}
                return b;
            })()),
        });
        if (!r.ok) throw new Error('analyze ' + r.status);
        const d = await r.json();
        const syms = (d && d.analysis && d.analysis.atomic_species) ? d.analysis.atomic_species : [];
        if (typeof window.renderHubbardSpeciesInputs === 'function') {
            zone.innerHTML = window.renderHubbardSpeciesInputs('gestion', syms);
            if (typeof window.applyHubbardDefaultsFromDbToZone === 'function')
                await window.applyHubbardDefaultsFromDbToZone('gestion');
        } else {
            zone.innerHTML = '<div style="padding:8px;color:#b45309;">Chargement page incomplet (renderHubbardSpeciesInputs).</div>';
        }
    } catch (e) {
        console.error(e);
        var _helpG = (typeof window.explainGenApiFetchError === 'function')
            ? window.explainGenApiFetchError(e, fetchBase)
            : (e.message || e);
        zone.innerHTML = '<div style="padding:10px;color:#9f1239;font-size:0.85em;line-height:1.45;background:#fff1f2;border:1px solid #fda4af;border-radius:6px;">' + _helpG + '</div>';
    }
};

// Étiquette lisible pour ibrav (locale à ce script)
function _ibravLabelGestion(ibrav) {
    const lut = {
        0: 'libre (CELL_PARAMETERS)',
        1: 'Cubique simple (P)', 2: 'Cubique faces centrées (F)', 3: 'Cubique centré (I)',
        4: 'Hexagonal / Trigonal', 5: 'Rhomboédrique',
        6: 'Tétragonal simple (P)', 7: 'Tétragonal centré (I)',
        8: 'Orthorhombique simple (P)', 9: 'Orthorhombique base C',
        10: 'Orthorhombique faces (F)', 11: 'Orthorhombique centré (I)', 91: 'Orthorhombique base A',
        12: 'Monoclinique simple (P)', 13: 'Monoclinique base C',
        14: 'Triclinique',
    };
    return lut[ibrav] || ('ibrav=' + ibrav);
}

window.convertirCIFenInput = async function(filepath, filename) {
    if (typeof window.convertirCIFversInput === 'function' && document.getElementById('cif_type_magnetisme_card')) {
        return window.convertirCIFversInput();
    }
    console.log('🔄 Conversion CIF en Input:', filepath);
    
    var _cellCtl = typeof window.pickCifUiControl === 'function'
        ? window.pickCifUiControl('cif_cell_type', 'gestion_cif_cell_type', 'gestion')
        : (document.getElementById('gestion_cif_cell_type') || document.getElementById('cif_cell_type'));
    const cellType = _cellCtl && _cellCtl.value ? _cellCtl.value : 'conventional';

    var _calcCtl = typeof window.pickCifUiControl === 'function'
        ? window.pickCifUiControl('cif_calc_type', 'gestion_cif_calc_type', 'gestion')
        : (document.getElementById('gestion_cif_calc_type') || document.getElementById('cif_calc_type'));
    const calcType = _calcCtl && _calcCtl.value ? _calcCtl.value : 'scf';

    var _ibModeEl = typeof window.pickCifUiControl === 'function'
        ? window.pickCifUiControl('cif_ibrav_mode', 'gestion_cif_ibrav_mode', 'gestion')
        : (document.getElementById('gestion_cif_ibrav_mode') || document.getElementById('cif_ibrav_mode'));
    const ibravMode = (_ibModeEl && _ibModeEl.value) ? _ibModeEl.value : 'auto';
    const forceIbravZero = (ibravMode === 'zero');

    // Récupère le contenu CIF depuis le champ caché (rempli par ouvrirCIFpourConversion)
    const cifTextarea = document.getElementById('editeur_cif_content');
    const cifText = cifTextarea ? cifTextarea.value : '';

    afficherNotificationSucces(forceIbravZero
        ? '🔄 Conversion en cours (ibrav forcé à 0)…'
        : '🔄 Conversion en cours (détection automatique de ibrav)…');

    // ────────────────────────────────────────────────────────────────────────
    // 1) Essai API autonome 5012 — ibrav intelligent (selon la structure)
    // ────────────────────────────────────────────────────────────────────────
    let inputContent = null;
    let materialName = filename.replace(/\.cif$/i, '');
    let outputFilepath = ((typeof window.qeInputsCifRoot === 'function') ? window.qeInputsCifRoot() : './inputs_convertis_cif') + '/' + materialName + '/' + materialName + '_' + calcType + '.in';
    let detectedIbrav = null;
    let detectedFormula = null;
    let detectedFormulaCell = null;
    let detectedFormulaZ = null;
    let detectedNat = null;
    let detectedSg = null;

    if (cifText && cifText.trim().length > 0) {
        var genBase = resolveGenApiBase();
        try {
            const aResp = await fetch(`${genBase}/api/cif/analyze`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    cif_text: cifText,
                    cell_type: cellType,
                }),
            });
            if (!aResp.ok) throw new Error('analyze HTTP ' + aResp.status);
            const aData = await aResp.json();
            if (!aData || !aData.analysis) throw new Error('analyze: réponse invalide');
            const analysis = aData.analysis;

            var __gestBuild = (typeof window.cifCollectBuildOptionsForApi === 'function')
                ? window.cifCollectBuildOptionsForApi(analysis, materialName, {
                    calculation: calcType,
                    force_ibrav_zero: forceIbravZero,
                })
                : {
                    analysis: analysis,
                    calculation: calcType,
                    prefix: materialName,
                    pseudo_dir: (window.QE_CONFIG && window.QE_CONFIG.PSEUDO_DIR) || './pseudos',
                    outdir: './out',
                    k_points: [4, 4, 4],
                    ecutwfc: 60.0,
                    ecutrho: 480.0,
                    occupations: 'smearing',
                    smearing: 'marzari-vanderbilt',
                    degauss: 0.01,
                    mixing_beta: 0.3,
                    forc_conv_thr: 1.0e-4,
                    force_ibrav_zero: forceIbravZero,
                };
                var __ghub = (typeof window.gestionHubbardCollectForApi === 'function') ? window.gestionHubbardCollectForApi() : null;
            if (__ghub) {
                __gestBuild.hubbard_u = __ghub.hubbard_u;
                __gestBuild.hubbard_j0 = __ghub.hubbard_j0;
                __gestBuild.hubbard_syntax = __ghub.hubbard_syntax;
                __gestBuild.hubbard_kind = __ghub.hubbard_kind;
                __gestBuild.hubbard_projection = __ghub.hubbard_projection;
                __gestBuild.hubbard_manifold = __ghub.hubbard_manifold;
                if (__ghub.hubbard_manifolds && Object.keys(__ghub.hubbard_manifolds).length)
                    __gestBuild.hubbard_manifolds = __ghub.hubbard_manifolds;
                __gestBuild.hubbard_legacy_verbose = !!__ghub.hubbard_legacy_verbose;
                var __cifNsEl = document.getElementById('cif_nspin');
                var __cifNs = __cifNsEl ? String(__cifNsEl.value || '1').trim() : '1';
                __gestBuild.hubbard_auto_spin = !!__ghub.hubbard_auto_spin && __cifNs === '2';
                if (typeof __ghub.hubbard_starting_magnetization === 'number' && !isNaN(__ghub.hubbard_starting_magnetization))
                    __gestBuild.hubbard_starting_magnetization = __ghub.hubbard_starting_magnetization;
            }
            var __gdfEl = document.getElementById('gestion_pw_input_dft');
            if (__gdfEl && typeof window.normalizePwInputDft === 'function') {
                var __gdfN = window.normalizePwInputDft(__gdfEl.value || '');
                if (__gdfN) __gestBuild.input_dft = __gdfN;
            }
            const bResp = await fetch(`${genBase}/api/inputs/build`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(__gestBuild),
            });
            if (!bResp.ok) throw new Error('build HTTP ' + bResp.status);
            const bData = await bResp.json();
            if (!bData || !bData.text) throw new Error('build: réponse invalide');

            inputContent = bData.text;
            detectedIbrav = forceIbravZero ? 0 : analysis.ibrav;
            detectedFormula = analysis.formula || materialName;
            detectedFormulaCell = analysis.formula_cell || null;
            detectedFormulaZ = analysis.formula_units_z || null;
            detectedNat = analysis.nat;
            detectedSg = analysis.spacegroup_number + ' (' + (analysis.spacegroup_symbol || '?') + ')';
            console.log('✅ API 5012 : conversion réussie, ibrav=', detectedIbrav);
        } catch (err5012) {
            console.warn('⚠️ API autonome 5012 indisponible :', err5012);
            afficherNotificationErreur(
                '❌ Conversion CIF impossible — serveur autonome (port 5012) injoignable.\n\n'
                + 'Lancez : cd ~/génération_inputs-QE && ./DEMARRER.sh\n'
                + 'Puis rechargez http://127.0.0.1:5012 (Ctrl+F5).\n\n'
                + 'Détail : ' + (err5012.message || err5012)
            );
            return;
        }
    }

    if (!inputContent) {
        afficherNotificationErreur(
            '❌ Conversion CIF impossible — contenu CIF vide ou serveur autonome (5012) injoignable.\n'
            + 'Lancez ./DEMARRER.sh puis réessayez.'
        );
        return;
    }

    // (fallback API legacy 5007 supprimé — ibrav=0 forcé, non fiable)

    if (typeof window.applyCifMagnetismPostProcess === 'function' && typeof inputContent === 'string' && inputContent) {
        window.__cifMagnetismApplyScope = 'gestion';
        try {
            inputContent = window.applyCifMagnetismPostProcess(inputContent);
        } catch (_eMagPpG) {
            console.warn(_eMagPpG);
        } finally {
            try {
                delete window.__cifMagnetismApplyScope;
            } catch (_eDm) {}
        }
    }
    if (typeof window.appliquerCompatibiliteQe75 === 'function' && inputContent) {
        try {
            inputContent = window.appliquerCompatibiliteQe75(inputContent, {
                pathPseuodos: (window.QE_CONFIG && window.QE_CONFIG.PSEUDO_DIR) || './pseudos',
                pathOutputs: (window.QE_CONFIG && window.QE_CONFIG.OUTPUTS_DIR) || './out'
            });
        } catch (_eQe75Gest) { console.warn('appliquerCompatibiliteQe75 gestion:', _eQe75Gest); }
    }
    if (typeof window.ensureCifCalcSections === 'function' && inputContent) {
        inputContent = window.ensureCifCalcSections(inputContent, calcType);
    }

    outputFilepath = ((typeof window.qeInputsCifRoot === 'function') ? window.qeInputsCifRoot() : './inputs_convertis_cif') + '/' + materialName + '/' + materialName + '_' + calcType + '.in';

    var saveResult = null;
    try {
        if (typeof window.cifSaveConvertedInput === 'function') {
            saveResult = await window.cifSaveConvertedInput(materialName, calcType, inputContent);
        }
    } catch (_eSv) {
        saveResult = { ok: false, error: _eSv.message || String(_eSv) };
    }

    try {
        fermerEditeurCIF();
        
        // Chercher ou créer la zone d'édition pour l'input généré
        let editeurDiv = document.getElementById('editeur_input_zone');
        if (!editeurDiv) {
            const zoneResultats = document.getElementById('zone_resultats_fichiers');
            editeurDiv = document.createElement('div');
            editeurDiv.id = 'editeur_input_zone';
            if (zoneResultats) {
                zoneResultats.appendChild(editeurDiv);
            } else {
                document.body.appendChild(editeurDiv);
            }
        }
        
        const outputPathEscaped = outputFilepath.replace(/'/g, "\\'");
        const filenameEscaped = filename.replace(/'/g, "\\'");
        const materialEscaped = materialName.replace(/'/g, "\\'");

        // Badge ibrav : violet en auto, orange si forcé/legacy
        const ibravBadgeColor = (detectedIbrav === 0) ? '#b45309' : '#7c3aed';
        const ibravBadgeText = (detectedIbrav === 0)
            ? (forceIbravZero ? 'ibrav=0 (forcé) — ' + _ibravLabelGestion(0)
                              : 'ibrav=0 — ' + _ibravLabelGestion(0))
            : 'ibrav=' + detectedIbrav + ' — ' + _ibravLabelGestion(detectedIbrav);
        const sgInfo = detectedSg ? `<strong>Groupe d'espace:</strong> ${detectedSg} | ` : '';

        // Afficher l'input converti dans l'éditeur principal
        editeurDiv.style.display = 'block';
        editeurDiv.innerHTML = `
            <div class="card" style="background: #fff; padding: 25px; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h3 style="margin: 0; color: #333;">✅ Input Généré depuis CIF: ${filename}</h3>
                    <button onclick="fermerEditeurInput()" class="btn" style="background: #dc3545; color: white; padding: 8px 15px; border-radius: 5px;">❌ Fermer</button>
                </div>
                
                <div class="alert" style="background: ${saveResult && saveResult.ok ? '#ecfdf5' : '#eff6ff'}; border: 1px solid ${saveResult && saveResult.ok ? '#86efac' : '#93c5fd'}; color: ${saveResult && saveResult.ok ? '#065f46' : '#1e40af'}; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                    ${saveResult && saveResult.ok
                        ? '💾 <strong>Conversion réussie — sauvegardé dans inputs_convertis_cif/' + __gestEscHtml(saveResult.relative || '') + '</strong>'
                        : '✅ <strong>Conversion réussie — sauvegarde manuelle requise.</strong>'}
                    <br>
                    📁 <strong>Emplacement :</strong> <code>${outputFilepath}</code><br>
                    🔬 <strong>Matériau:</strong> ${__gestEscHtml(materialName)}<br>
                    🧪 ${__gestFormulaSummaryHtml({ formula: detectedFormula, formula_cell: detectedFormulaCell, formula_units_z: detectedFormulaZ, nat: detectedNat }, materialName)}<br>
                    ${sgInfo}<span style="background:${ibravBadgeColor};color:white;padding:3px 10px;border-radius:12px;font-size:0.9em;">📐 ${ibravBadgeText}</span>
                    <p style="margin:10px 0 0;font-size:0.9em;">Vérifiez l'input ci-dessous puis cliquez <strong>💾 Sauvegarder</strong>.</p>
                </div>
                
                <textarea id="editeur_input_content" style="width: 100%; height: 400px; font-family: 'Courier New', monospace; font-size: 13px; padding: 15px; border: 2px solid #ddd; border-radius: 5px; resize: vertical;">${inputContent}</textarea>
                
                <div style="margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                    <button onclick="sauvegarderInputConverti('${outputPathEscaped}', '${filenameEscaped}')" class="btn btn-primary" style="padding: 12px 25px; font-size: 1em; background: #007bff; color: white; border: none; border-radius: 5px;">💾 Sauvegarder les modifications</button>
                    <button onclick="copierInputEditeur()" class="btn" style="background: #6c757d; color: white; padding: 12px 25px; font-size: 1em; border: none; border-radius: 5px;">📋 Copier</button>
                    <button onclick="fermerEditeurInput()" class="btn" style="background: #28a745; color: white; padding: 12px 25px; font-size: 1em; border: none; border-radius: 5px;">✅ Terminé</button>
                </div>
                
                <input type="hidden" id="editeur_input_filepath" value="${outputFilepath}">
            </div>
        `;
        
        afficherNotificationSucces(saveResult && saveResult.ok
            ? `✅ CIF converti et sauvegardé (${materialName}_${calcType}.in)`
            : `✅ CIF converti — cliquez Sauvegarder (${materialName}_${calcType}.in)`);
        
        if (saveResult && saveResult.ok && typeof window.listerInputsExistants === 'function') {
            try { window.listerInputsExistants(); } catch (_eLi3) {}
        }
        
        // Scroll vers l'éditeur
        editeurDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
        
    } catch (error) {
        console.error('❌ Erreur:', error);
        
        // Afficher le message d'erreur détaillé
        let errorMessage = error.message;
        if (error.message.includes('500')) {
            errorMessage = '❌ Erreur serveur lors de la conversion.\nVérifiez que le fichier CIF est valide.';
        }
        
        afficherNotificationErreur(`❌ Conversion échouée: ${errorMessage}`);
    }
};

window.sauvegarderInputConverti = async function(filepath, filename) {
    console.log('💾 Sauvegarde input converti:', filepath);
    
    const textarea = document.getElementById('editeur_input_content');
    if (!textarea) {
        alert('❌ Éditeur introuvable!');
        return;
    }
    
    const content = textarea.value;
    var mat = (filepath || '').split('/').slice(-2, -1)[0] || 'material';
    var calc = 'scf';
    var fn = (filepath || '').split('/').pop() || '';
    var cm = fn.match(/_([a-z-]+)\.in$/i);
    if (cm) calc = cm[1];

    if (typeof window.cifSaveConvertedInput === 'function') {
        var sr = await window.cifSaveConvertedInput(mat, calc, content);
        if (sr.ok) {
            afficherNotificationSucces('✅ Input sauvegardé: inputs_convertis_cif/' + sr.relative);
            if (typeof window.listerInputsExistants === 'function') {
                try { window.listerInputsExistants(); } catch (_eLi) {}
            }
            return;
        }
    }

    try {
        const response = await fetch(`${API_BASE_URL}/api/sauvegarder_input_edite`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                filepath: filepath,
                content: content
            })
        });
        
        if (!response.ok) throw new Error(`Erreur API: ${response.status}`);
        
        const data = await response.json();
        
        if (data.success) {
            afficherNotificationSucces(`✅ Input sauvegardé: ${filepath}`);
            
            // Recharger la liste des inputs
            setTimeout(() => {
                listerInputsExistants();
            }, 1000);
        } else {
            afficherNotificationErreur(`❌ Erreur: ${data.message}`);
        }
        
    } catch (error) {
        console.error('❌ Erreur:', error);
        afficherNotificationErreur(`❌ Impossible de sauvegarder: ${error.message}`);
    }
};

// ═══════════════════════════════════════════════════════════════════════════
// FONCTION 7B: Tester un Input Converti depuis CIF
// ═══════════════════════════════════════════════════════════════════════════

window.testerInputConverti = async function(filepath, filename, prefix) {
    console.log('🧪 Test de l\'input converti:', filepath);
    
    const textarea = document.getElementById('editeur_input_content');
    const statusDiv = document.getElementById('cif_conversion_status');
    const boutonsActions = document.getElementById('cif_boutons_actions');
    const boutonsSauvegarde = document.getElementById('cif_boutons_sauvegarde');
    const btnTester = document.getElementById('btn_tester_input_cif');
    
    if (!textarea) {
        alert('❌ Éditeur introuvable!');
        return;
    }
    
    const content = textarea.value;
    
    // Changer le bouton en mode "chargement"
    if (btnTester) {
        btnTester.disabled = true;
        btnTester.innerHTML = '⏳ Test en cours...';
    }
    
    try {
        // Vérifier la syntaxe de base de l'input
        let hasErrors = false;
        let errors = [];
        
        // Tests de base sur le contenu
        if (!content || content.trim().length === 0) {
            hasErrors = true;
            errors.push('Le contenu est vide');
        }
        
        if (!content.includes('&CONTROL')) {
            hasErrors = true;
            errors.push('Section &CONTROL manquante');
        }
        
        if (!content.includes('&SYSTEM')) {
            hasErrors = true;
            errors.push('Section &SYSTEM manquante');
        }
        
        if (!content.includes('&ELECTRONS')) {
            hasErrors = true;
            errors.push('Section &ELECTRONS manquante');
        }
        
        if (!content.includes('ATOMIC_SPECIES')) {
            hasErrors = true;
            errors.push('Section ATOMIC_SPECIES manquante');
        }
        
        if (!content.includes('ATOMIC_POSITIONS')) {
            hasErrors = true;
            errors.push('Section ATOMIC_POSITIONS manquante');
        }
        
        // Vérifier les pseudopotentiels mentionnés
        const pseudoMatches = content.match(/\\.UPF/gi);
        if (!pseudoMatches || pseudoMatches.length === 0) {
            errors.push('⚠️ Attention: Aucun fichier .UPF détecté');
        }
        
        if (hasErrors) {
            // Test échoué
            if (statusDiv) {
                statusDiv.style.background = '#f8d7da';
                statusDiv.style.borderColor = '#f5c6cb';
                statusDiv.style.color = '#721c24';
                statusDiv.innerHTML = `
                    ❌ <strong>Test échoué!</strong> Erreurs détectées:<br>
                    <ul style="margin: 10px 0 0 20px;">
                        ${errors.map(e => '<li>' + e + '</li>').join('')}
                    </ul>
                `;
            }
            
            if (btnTester) {
                btnTester.disabled = false;
                btnTester.innerHTML = '🧪 Retester l\'Input';
                btnTester.style.background = '#dc3545';
            }
            
            if (boutonsSauvegarde) {
                boutonsSauvegarde.style.display = 'none';
            }
            
        } else {
            // Test réussi
            if (statusDiv) {
                statusDiv.style.background = '#d4edda';
                statusDiv.style.borderColor = '#c3e6cb';
                statusDiv.style.color = '#155724';
                statusDiv.innerHTML = `
                    ✅ <strong>Test réussi!</strong> L'input semble valide.<br>
                    <strong>Fichier suggéré:</strong> <code>${filepath}</code>
                    ${errors.length > 0 ? '<br><small>' + errors.join(', ') + '</small>' : ''}
                `;
            }
            
            if (btnTester) {
                btnTester.disabled = false;
                btnTester.innerHTML = '✅ Test OK';
                btnTester.style.background = '#28a745';
            }
            
            // Afficher les boutons de sauvegarde
            if (boutonsSauvegarde) {
                boutonsSauvegarde.style.display = 'block';
            }
            
            afficherNotificationSucces('✅ Test réussi! Vous pouvez maintenant sauvegarder.');
        }
        
    } catch (error) {
        console.error('❌ Erreur test:', error);
        
        if (btnTester) {
            btnTester.disabled = false;
            btnTester.innerHTML = '🧪 Retester';
        }
        
        afficherNotificationErreur(`❌ Erreur lors du test: ${error.message}`);
    }
};

window.sauvegarderEtLancerInputConverti = async function(filepath, prefix) {
    console.log('💾+🚀 Sauvegarde et lancement:', filepath, prefix);
    
    // D'abord sauvegarder
    const textarea = document.getElementById('editeur_input_content');
    if (!textarea) {
        alert('❌ Éditeur introuvable!');
        return;
    }
    
    const content = textarea.value;
    
    try {
        // Étape 1: Sauvegarder
        const saveResponse = await fetch(`${API_BASE_URL}/api/sauvegarder_input_edite`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                filepath: filepath,
                content: content
            })
        });
        
        if (!saveResponse.ok) throw new Error(`Erreur sauvegarde: ${saveResponse.status}`);
        
        const saveData = await saveResponse.json();
        
        if (!saveData.success) {
            throw new Error(saveData.message || 'Erreur de sauvegarde');
        }
        
        afficherNotificationSucces(`✅ Input sauvegardé: ${prefix}.in`);
        
        // Étape 2: Lancer le calcul (après 500ms)
        setTimeout(async () => {
            if (!confirm(`🚀 Input sauvegardé!\n\nLancer le calcul pour "${prefix}" maintenant?`)) {
                return;
            }
            
            // Déterminer les chemins
            const inputDir = filepath.substring(0, filepath.lastIndexOf('/'));
            const outputDir = inputDir.replace('/inputs/', '/outputs/');
            
            try {
                const launchResponse = await fetch(`${API_BASE_URL}/api/lancer_calcul_custom`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        input_file: filepath,
                        output_dir: outputDir,
                        prefix: prefix,
                        nprocs: 4
                    })
                });
                
                if (!launchResponse.ok) throw new Error(`Erreur lancement: ${launchResponse.status}`);
                
                const launchData = await launchResponse.json();
                
                if (launchData.success) {
                    afficherNotificationSucces(`✅ Calcul lancé: ${prefix}\n📊 ID: ${launchData.calcul_id}`);
                    
                    // Fermer l'éditeur
                    fermerEditeurInput();
                    
                    // Basculer vers Onglet 3 après 1 seconde
                    setTimeout(() => {
                        const tabSuivi = document.querySelector('[data-tab="tab3"]');
                        if (tabSuivi) {
                            tabSuivi.click();
                        } else {
                            // Si data-tab ne fonctionne pas, essayer par le texte
                            const tabs = document.querySelectorAll('.tab');
                            tabs.forEach((tab, index) => {
                                if (tab.textContent.includes('Suivi des Calculs')) {
                                    tab.click();
                                }
                            });
                        }
                        
                        // Rafraîchir la liste des calculs après avoir basculé
                        setTimeout(() => {
                            if (typeof window.listerCalculsEnCours === 'function') {
                                console.log('🔄 Rafraîchissement automatique de la liste des calculs...');
                                window.listerCalculsEnCours();
                            } else {
                                console.warn('⚠️ listerCalculsEnCours non disponible, rechargez la page');
                            }
                        }, 500);
                    }, 1000);
                } else {
                    afficherNotificationErreur(`❌ Erreur lancement: ${launchData.message || launchData.error}`);
                }
                
            } catch (error) {
                console.error('❌ Erreur lancement:', error);
                afficherNotificationErreur(`❌ Impossible de lancer: ${error.message}`);
            }
        }, 500);
        
    } catch (error) {
        console.error('❌ Erreur:', error);
        afficherNotificationErreur(`❌ Impossible de sauvegarder: ${error.message}`);
    }
};

// ═══════════════════════════════════════════════════════════════════════════
// CONFIRMATION DE CHARGEMENT
// ═══════════════════════════════════════════════════════════════════════════

/** Sync CIF — repli si le gros script inline index.html n'a pas chargé. */
window.syncCifDataCurrent = window.syncCifDataCurrent || function (obj) {
    window.cifDataCurrent = obj || null;
    return window.cifDataCurrent;
};
window.getCifDataCurrent = window.getCifDataCurrent || function () {
    if (window.cifDataCurrent && window.cifDataCurrent.content) return window.cifDataCurrent;
    return null;
};

function __gestShowGestionPane() {
    try {
        if (typeof afficherSousSection === 'function') {
            afficherSousSection('gestion');
        }
    } catch (_eSub) {}
    var g = document.getElementById('subsection_gestion');
    if (g) g.style.display = 'block';
    try {
        var qr = document.getElementById('zone_resultats_fichiers');
        if (qr && typeof afficherZoneFichiers === 'function') afficherZoneFichiers();
        else if (qr) qr.style.display = 'block';
    } catch (_eQr) {}
}

function __gestGetCifPayload() {
    var cd = null;
    try {
        if (typeof window.getCifDataCurrent === 'function') cd = window.getCifDataCurrent();
    } catch (_eG) {}
    if (!cd || !cd.content) cd = window.cifDataCurrent;
    if (!cd || !cd.content) {
        var ta = document.getElementById('editeur_cif_content');
        if (ta && ta.value && String(ta.value).trim()) {
            cd = { content: ta.value, filename: 'structure.cif', filepath: '' };
        }
    }
    return cd;
}

async function __gestFetchJson(url, body, timeoutMs) {
    var ms = timeoutMs || 120000;
    var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var tid = ctrl ? setTimeout(function () { try { ctrl.abort(); } catch (_e) {} }, ms) : null;
    try {
        var opts = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        };
        if (ctrl) opts.signal = ctrl.signal;
        var r = await fetch(url, opts);
        if (!r.ok) throw new Error('HTTP ' + r.status + ' — ' + url);
        return await r.json();
    } finally {
        if (tid) clearTimeout(tid);
    }
}

/**
 * Conversion CIF → input QE (autonome, port 5012).
 * Remplace la version inline si elle est absente ou défaillante.
 */
window.convertirCIFversInput = async function convertirCIFversInput() {
    __gestShowGestionPane();
    var statusDiv = __gestGetStatusDiv();
    if (!statusDiv) {
        alert('❌ Zone de statut absente.\nCtrl+F5 sur http://127.0.0.1:5012');
        return false;
    }
    if (location.protocol === 'file:') {
        alert('❌ Ouvrez http://127.0.0.1:5012 après ./DEMARRER.sh (pas file://).');
        return false;
    }

    var cifData = __gestGetCifPayload();
    if (!cifData || !cifData.content) {
        alert('❌ Aucun CIF chargé.\nCliquez « Convertir en Input » sur un fichier CIF listé.');
        return false;
    }

    var nomFichier = cifData.filename || 'structure.cif';
    var materialName = nomFichier.replace(/\.cif$/i, '');
    var cellEl = document.getElementById('cif_cell_type');
    var calcEl = document.getElementById('cif_calc_type');
    var calcType = (typeof window.resolveCifCalculationType === 'function')
        ? window.resolveCifCalculationType()
        : ((calcEl && calcEl.value) ? calcEl.value : 'scf');
    var ibravModeEl = document.getElementById('cif_ibrav_mode');
    var cellType = (cellEl && cellEl.value) ? cellEl.value : 'conventional';
    var ibravMode = (ibravModeEl && ibravModeEl.value) ? ibravModeEl.value : 'auto';
    var forceIbravZero = (ibravMode === 'zero');
    var ibravOverride = null;
    if (ibravMode === 'manual') {
        var pkEl = document.getElementById('cif_ibrav_pick');
        if (pkEl && pkEl.value !== '') {
            var xi = parseInt(pkEl.value, 10);
            if (!Number.isNaN(xi)) ibravOverride = xi;
        }
    }

    var genBase = resolveGenApiBase();
    if (typeof window.tab1SetWorkflowPath === 'function') window.tab1SetWorkflowPath('cif');
    if (typeof window.tab1SetWorkflowStep === 'function') window.tab1SetWorkflowStep(5, 'generating');
    statusDiv.innerHTML = '<div class="alert alert-info" style="padding:15px;border-radius:8px;background:#e3f2fd;color:#0d47a1;">⏳ Analyse CIF + génération input QE…</div>';
    statusDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

    try {
        var aData = await __gestFetchJson(genBase + '/api/cif/analyze', (typeof window.afmCifAnalyzePayload === 'function')
            ? window.afmCifAnalyzePayload({ cif_text: cifData.content, cell_type: cellType })
            : { cif_text: cifData.content, cell_type: cellType });
        if (!aData || !aData.analysis) throw new Error('Analyse CIF : réponse invalide');
        var analysis = aData.analysis;
        window.__cifLastAnalysis = analysis;
        if (typeof window.afmApplyStructureGuidance === 'function') {
            try { await window.afmApplyStructureGuidance(analysis, { autoMagMode: false }); } catch (_eAg) {}
        }

        if (typeof window.ensureCifHubbardSpeciesRowsFromAnalysis === 'function') {
            try { await window.ensureCifHubbardSpeciesRowsFromAnalysis(analysis); } catch (_eHb) {}
        }
        if (typeof window.ensureCifPseudoRowsFromAnalysis === 'function') {
            try { window.ensureCifPseudoRowsFromAnalysis(analysis); } catch (_ePs) {}
        }

        if (typeof window.cifPrepareNoncolinBeforeBuild === 'function') {
            try { window.cifPrepareNoncolinBeforeBuild(); } catch (_eNcPrep) { console.warn(_eNcPrep); }
        }

        var buildBody = (typeof window.cifCollectBuildOptionsForApi === 'function')
            ? window.cifCollectBuildOptionsForApi(analysis, materialName, {
                calculation: calcType,
                force_ibrav_zero: forceIbravZero,
            })
            : {
            analysis: analysis,
            calculation: calcType,
            prefix: materialName,
            pseudo_dir: (window.QE_CONFIG && window.QE_CONFIG.PSEUDO_DIR) || './pseudos',
            outdir: './out',
            k_points: [4, 4, 4],
            ecutwfc: 60.0,
            ecutrho: 480.0,
            occupations: 'smearing',
            smearing: 'marzari-vanderbilt',
            degauss: 0.01,
            mixing_beta: 0.3,
            forc_conv_thr: 1.0e-4,
            force_ibrav_zero: forceIbravZero,
        };
        if (!forceIbravZero && ibravOverride !== null && !Number.isNaN(ibravOverride)) {
            buildBody.ibrav_override = ibravOverride;
        }

        var hub = null;
        try {
            if (typeof window.cifHubbardCollectForApi === 'function') hub = window.cifHubbardCollectForApi();
        } catch (_eHu) {}
        if (hub) {
            Object.keys(hub).forEach(function (k) { buildBody[k] = hub[k]; });
        }

        var dftEl = document.getElementById('cif_input_dft');
        if (dftEl && typeof window.normalizePwInputDft === 'function') {
            var nd = window.normalizePwInputDft(dftEl.value || '');
            if (nd) buildBody.input_dft = nd;
        }
        var ordMagGest = window.__cifOrdreMagnetisme
            || (document.getElementById('cif_ordre_mag_select') || {}).value
            || '';
        if (ordMagGest && /^afm/.test(String(ordMagGest))) {
            buildBody.afm_type = String(ordMagGest).trim();
        }

        var bData = await __gestFetchJson(genBase + '/api/inputs/build', buildBody);
        if (!bData || !bData.text) throw new Error('Build input : réponse invalide');

        var inputContent = bData.text;
        if (typeof window.applyCifMagnetismPostProcess === 'function') {
            try {
                window.__cifMagnetismApplyScope = 'main';
                inputContent = window.applyCifMagnetismPostProcess(inputContent);
            } catch (_eMag) {
                console.warn(_eMag);
            } finally {
                try { delete window.__cifMagnetismApplyScope; } catch (_eDel) {}
            }
        }
        if (typeof window.appliquerCompatibiliteQe75 === 'function' && inputContent) {
            var _pseudoDirCif = (buildBody && buildBody.pseudo_dir)
                || (window.QE_CONFIG && window.QE_CONFIG.PSEUDO_DIR)
                || './pseudos';
            var _outDirCif = (buildBody && buildBody.outdir)
                || (window.QE_CONFIG && window.QE_CONFIG.OUTPUTS_DIR)
                || './out';
            try {
                inputContent = window.appliquerCompatibiliteQe75(inputContent, {
                    pathPseuodos: _pseudoDirCif,
                    pathOutputs: _outDirCif
                });
            } catch (_eQe75Cif) { console.warn('appliquerCompatibiliteQe75 CIF:', _eQe75Cif); }
        }
        if (typeof window.ensureCifCalcSections === 'function' && inputContent) {
            inputContent = window.ensureCifCalcSections(inputContent, calcType);
        }
        if (typeof window.qeInjectPolarizationIntoPwText === 'function') {
            inputContent = window.qeInjectPolarizationIntoPwText(inputContent, calcType);
        }
        if (calcType === 'scf_berry' && !/^\s*&BP\b/im.test(inputContent)) {
            console.warn('[CIF] scf_berry demandé mais &BP absent — vérifiez le menu « Type de calcul ».');
        }

        var ibravUsed = forceIbravZero ? 0 : (ibravOverride != null ? ibravOverride : analysis.ibrav);
        var outName = materialName + '_' + calcType + '.in';

        var saveResult = null;
        try {
            if (typeof window.cifSaveConvertedInput === 'function') {
                saveResult = await window.cifSaveConvertedInput(materialName, calcType, inputContent);
            }
        } catch (_eSave) {
            saveResult = { ok: false, error: _eSave.message || String(_eSave) };
        }

        window.__lastCifConvertedInput = {
            materialName: materialName,
            calcType: calcType,
            inputContent: inputContent,
            outName: outName,
            formula: analysis.formula || materialName,
            savePath: saveResult && saveResult.ok ? saveResult.path : null
        };

        if (typeof window.cifRenderConversionResult === 'function') {
            window.cifRenderConversionResult({
                materialName: materialName,
                calcType: calcType,
                inputContent: inputContent,
                analysis: analysis,
                ibravUsed: ibravUsed,
                saveResult: saveResult,
                statusDiv: statusDiv
            });
        }

        if (saveResult && saveResult.ok) {
            __gestFlashToast('✅ Input sauvegardé : inputs_convertis_cif/' + saveResult.relative, 'success');
            if (typeof window.tab1ShowStatus === 'function') {
                try {
                    window.tab1ShowStatus('ok',
                        '💾 CIF sauvegardé → <code>inputs_convertis_cif/'
                        + __gestEscHtml(saveResult.relative || '') + '</code>');
                } catch (_eSt) {}
            }
            if (typeof window.listerInputsExistants === 'function') {
                try { window.listerInputsExistants(); } catch (_eLi2) {}
            }
        } else if (saveResult && !saveResult.ok && typeof window.tab1ShowStatus === 'function') {
            try {
                window.tab1ShowStatus('warn',
                    '⚠️ Conversion OK — sauvegarde CIF échouée'
                    + (saveResult.error ? ' : <code>' + __gestEscHtml(saveResult.error) + '</code>' : '')
                    + '. Cliquez <strong>💾 Sauvegarder</strong>.');
            } catch (_eSt2) {}
        }

        __gestShowCifFloatingBar(true, 'result');
        __gestScrollToCifSaveResult();

        var ed = document.getElementById('editeur_cif_zone');
        if (ed) ed.style.display = 'block';
        try {
            var qr = document.getElementById('zone_resultats_fichiers');
            if (qr) qr.style.display = 'block';
        } catch (_eQr) {}
        return true;
    } catch (err) {
        console.error('[convertirCIFversInput]', err);
        var msg = (err && err.name === 'AbortError')
            ? 'Délai dépassé — vérifiez ./DEMARRER.sh (port 5012).'
            : ((err && err.message) ? err.message : String(err));
        statusDiv.innerHTML = '<div class="alert alert-error" style="padding:15px;border-radius:8px;background:#f8d7da;color:#721c24;line-height:1.5;">'
            + '<strong>❌ Conversion échouée</strong><br>' + __gestEscHtml(msg)
            + '<br><small style="margin-top:8px;display:block;">API : ' + __gestEscHtml(genBase)
            + ' — lancez <code>./DEMARRER.sh</code> puis Ctrl+F5.</small></div>';
        if (typeof window.tab1ClearWorkflowForced === 'function') window.tab1ClearWorkflowForced();
        if (typeof window.tab1HighlightWorkflowStep === 'function') window.tab1HighlightWorkflowStep(5);
        alert('❌ Conversion CIF bloquée :\n' + msg + '\n\n→ http://127.0.0.1:5012');
        return false;
    }
};

function __gestOpenCifFromListCard(card) {
    if (!card) return;
    try {
        var fp = decodeURIComponent(card.getAttribute('data-cif-path') || '');
        var fn = decodeURIComponent(card.getAttribute('data-cif-name') || '');
        if (fp && fn && typeof window.convertirCIFDepuisListe === 'function') {
            window.convertirCIFDepuisListe(fp, fn);
        }
    } catch (e) {
        console.error('gest-cif-file-card', e);
        alert('❌ Ouverture conversion CIF : ' + (e.message || e));
    }
}

document.addEventListener('click', function (ev) {
    var card = ev.target && ev.target.closest ? ev.target.closest('.gest-cif-file-card') : null;
    if (!card) return;
    if (ev.target.closest('a')) return;
    ev.preventDefault();
    __gestOpenCifFromListCard(card);
}, true);

document.addEventListener('keydown', function (ev) {
    if (ev.key !== 'Enter' && ev.key !== ' ') return;
    var card = ev.target && ev.target.closest ? ev.target.closest('.gest-cif-file-card') : null;
    if (!card) return;
    ev.preventDefault();
    __gestOpenCifFromListCard(card);
}, true);

function __gestRefreshCifFloatingBarI18n() {
    if (typeof window.t !== 'function') return;
    var bar = document.getElementById('cif_floating_action_bar');
    if (!bar) return;
    var convertBtn = document.getElementById('cif_floating_convert_btn');
    var saveBtn = document.getElementById('cif_floating_save_btn');
    var resultBtn = document.getElementById('cif_floating_result_btn');
    var optionsBtn = document.getElementById('cif_floating_options_btn');
    var closeBtn = document.getElementById('cif_floating_close_btn');
    var label = document.getElementById('cif_floating_bar_label');
    if (convertBtn) convertBtn.textContent = window.t('cif.convert');
    if (saveBtn) saveBtn.textContent = window.t('cif.floating.save');
    if (resultBtn) resultBtn.textContent = window.t('cif.floating.preview');
    if (optionsBtn) optionsBtn.textContent = window.t('cif.floating.options');
    if (closeBtn) closeBtn.textContent = window.t('cif.floating.close');
    if (label) {
        var inResult = saveBtn && saveBtn.style.display !== 'none';
        label.textContent = inResult ? window.t('cif.floating.result') : window.t('cif.floating.edit');
    }
    document.querySelectorAll('.cif-btn-convert-main[data-i18n="cif.convert"]').forEach(function (el) {
        el.textContent = window.t('cif.convert');
    });
    document.querySelectorAll('#cif_top_save_btn[data-i18n="cif.save"]').forEach(function (el) {
        el.textContent = window.t('cif.save');
    });
}
window.__gestRefreshCifFloatingBarI18n = __gestRefreshCifFloatingBarI18n;

document.addEventListener('qe:langchange', function () {
    __gestRefreshCifFloatingBarI18n();
});

console.log('✅ Script gestion_fichiers_complet.js chargé!');
console.log('✅ Fonctions disponibles:', {
    listerInputsExistants: typeof window.listerInputsExistants,
    listerFichiersCIF: typeof window.listerFichiersCIF,
    ouvrirInputPourEdition: typeof window.ouvrirInputPourEdition,
    lancerCalculInput: typeof window.lancerCalculInput,
    ouvrirCIFpourConversion: typeof window.ouvrirCIFpourConversion,
    convertirCIFversInput: typeof window.convertirCIFversInput,
    convertirCIFDepuisListe: typeof window.convertirCIFDepuisListe
});



#!/usr/bin/env bash
# ==========================================================================
#  Supra-QE — Démarrage de l'API et ouverture de l'interface
# ==========================================================================

set -e
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

if [[ -f "$HERE/config.env" ]]; then
    # shellcheck disable=SC1091
    source "$HERE/config.env"
elif [[ ! -f "$HERE/config.env" ]]; then
    echo "[supra-qe] ⚠️  config.env absent — lance d'abord : ./configurer.sh"
fi

PORT="${SUPRA_QE_PORT:-8765}"
HOST="${SUPRA_QE_HOST:-127.0.0.1}"
INPUTS_DIR="${SUPRA_INPUTS_DIR:-$HERE/inputs}"
OUTPUTS_DIR="${SUPRA_OUTPUTS_DIR:-$HERE/outputs}"
LOGS_DIR="${SUPRA_LOGS_DIR:-$HERE/logs}"
TMP_DIR="${SUPRA_TMP_DIR:-$HERE/tmp}"

mkdir -p "$LOGS_DIR" "$TMP_DIR" "$INPUTS_DIR" "$OUTPUTS_DIR" pseudos

# ── venv local uniquement (projet autonome) ──────────────────────────────
PY=""
for c in "$HERE/.venv/bin/python" "$HERE/.venv/bin/python3"; do
    if [[ -x "$c" ]] && "$c" -c "import flask, flask_cors" >/dev/null 2>&1; then
        PY="$c"
        break
    fi
done

if [[ -z "$PY" ]]; then
    echo "[supra-qe] création du venv local $HERE/.venv"
    python3 -m venv "$HERE/.venv"
    "$HERE/.venv/bin/pip" install --upgrade pip >/dev/null
    if "$HERE/.venv/bin/pip" install -r requirements.txt; then
        PY="$HERE/.venv/bin/python"
    else
        echo "[supra-qe] ⚠️ Pas de réseau : impossible d'installer Flask."
        echo "[supra-qe]    Installe manuellement Flask + flask-cors puis relance."
        exit 1
    fi
fi
echo "[supra-qe] Python utilisé : $PY"

# ── Binaires QE / EPW associés au projet (supra-QE/bin/) ─────────────────
if [[ ! -x "$HERE/bin/pw.x" ]] || [[ ! -x "$HERE/bin/epw.x" ]]; then
    if [[ -n "${QE_BIN_DIR:-}" && -x "${QE_BIN_DIR}/pw.x" ]]; then
        echo "[supra-qe] association des binaires QE → $HERE/bin/"
        "$HERE/scripts/associer_binaires_qe.sh" "$QE_BIN_DIR" || true
    elif [[ -x "$HOME/q-e-qe-7.5/bin/pw.x" ]]; then
        echo "[supra-qe] association des binaires QE → $HERE/bin/"
        "$HERE/scripts/associer_binaires_qe.sh" "$HOME/q-e-qe-7.5/bin" || true
    fi
fi
# Après association, privilégier le bin local du projet
if [[ -x "$HERE/bin/pw.x" ]]; then
    export QE_BIN_DIR="$HERE/bin"
fi
if [[ -x "$HERE/bin/epw.x" ]]; then
    echo "[supra-qe] epw.x prêt (WF2) : $HERE/bin/epw.x"
else
    echo "[supra-qe] ℹ️  epw.x non associé — WF2 indisponible tant que :"
    echo "[supra-qe]     ./scripts/installer_epw.sh && ./scripts/associer_binaires_qe.sh"
fi

# ── stop si déjà lancé ───────────────────────────────────────────────────
PIDFILE="$TMP_DIR/supra-qe.pid"
if [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    echo "[supra-qe] API déjà active (PID $(cat "$PIDFILE")) — relance"
    kill "$(cat "$PIDFILE")" 2>/dev/null || true
    sleep 1
fi

# ── lancement de l'API ───────────────────────────────────────────────────
echo "[supra-qe] démarrage API sur http://$HOST:$PORT/"
nohup env \
    SUPRA_QE_HOST="$HOST" \
    SUPRA_QE_PORT="$PORT" \
    QE_BIN_DIR="${QE_BIN_DIR:-}" \
    QE_PSEUDO_DIR="${QE_PSEUDO_DIR:-}" \
    SUPRA_INPUTS_DIR="$INPUTS_DIR" \
    SUPRA_OUTPUTS_DIR="$OUTPUTS_DIR" \
    SUPRA_LOGS_DIR="$LOGS_DIR" \
    SUPRA_TMP_DIR="$TMP_DIR" \
    SUPRA_PSEUDO_DIR_REL="${SUPRA_PSEUDO_DIR_REL:-../../../pseudos/}" \
    "$PY" api/supra_api.py > "$LOGS_DIR/api.log" 2>&1 &
echo $! > "$PIDFILE"

# Attendre que /health réponde (sur 127.0.0.1 si l'écoute est 0.0.0.0)
HEALTH_HOST="$HOST"
[[ "$HOST" == "0.0.0.0" || "$HOST" == "::" ]] && HEALTH_HOST="127.0.0.1"
API_OK=0
for i in $(seq 1 30); do
    if curl -fs "http://$HEALTH_HOST:$PORT/health" >/dev/null 2>&1; then
        echo "[supra-qe] API en ligne (PID $(cat "$PIDFILE"))."
        API_OK=1
        break
    fi
    sleep 0.5
done
if [[ "$API_OK" -ne 1 ]]; then
    echo "[supra-qe] ERREUR : /health injoignable après ~15 s."
    echo "[supra-qe]          logs : tail -f $LOGS_DIR/api.log"
    echo "[supra-qe]          Si HOST=0.0.0.0 : il faut SUPRA_ALLOW_LAN=1 dans config.env"
    exit 1
fi

# ── URL(s) d'accès ───────────────────────────────────────────────────────
URL_LOCAL="http://127.0.0.1:$PORT/interface/"
echo "[supra-qe] interface locale : $URL_LOCAL"
if [[ "$HOST" == "0.0.0.0" || "$HOST" == "::" ]]; then
    echo "[supra-qe] écoute réseau  : $HOST:$PORT (SUPRA_ALLOW_LAN requis)"
    while read -r ip; do
        [[ -n "$ip" ]] && echo "[supra-qe]   → http://$ip:$PORT/interface/"
    done < <(hostname -I 2>/dev/null | tr ' ' '\n' | grep -E '^[0-9]+\.' || true)
    echo "[supra-qe] doc distant    : docs/AUTRE_PC.md"
    echo "[supra-qe] CORS distant   : SUPRA_CORS_ORIGINS=http://IP:PORT (si besoin)"
fi

# ── ouverture du navigateur (toujours en local) ──────────────────────────
# Par défaut : Firefox. Surcharge éventuelle :
#   SUPRA_BROWSER=chrome ./DEMARRER.sh
#   SUPRA_BROWSER=xdg-open ./DEMARRER.sh
URL="$URL_LOCAL"
open_browser() {
    local url="$1"
    local pref="${SUPRA_BROWSER:-firefox}"
    case "$pref" in
        firefox)
            for bin in firefox firefox-esr; do
                if command -v "$bin" >/dev/null 2>&1; then
                    "$bin" --new-window "$url" >/dev/null 2>&1 &
                    echo "[supra-qe] navigateur   : $bin"
                    return 0
                fi
            done
            echo "[supra-qe] Firefox introuvable — repli sur le navigateur par défaut"
            pref="xdg-open"
            ;;
        chrome|google-chrome|chromium)
            for bin in google-chrome-stable google-chrome chromium-browser chromium; do
                if command -v "$bin" >/dev/null 2>&1; then
                    "$bin" --new-window "$url" >/dev/null 2>&1 &
                    echo "[supra-qe] navigateur   : $bin"
                    return 0
                fi
            done
            echo "[supra-qe] Chrome introuvable — repli sur le navigateur par défaut"
            pref="xdg-open"
            ;;
        none|off|no)
            echo "[supra-qe] ouverture navigateur désactivée (SUPRA_BROWSER=$pref)"
            return 0
            ;;
    esac
    if command -v xdg-open >/dev/null; then
        xdg-open "$url" >/dev/null 2>&1 &
        echo "[supra-qe] navigateur   : xdg-open (défaut système)"
    elif command -v gnome-open >/dev/null; then
        gnome-open "$url" >/dev/null 2>&1 &
    elif command -v open >/dev/null; then
        open "$url" >/dev/null 2>&1 &
    else
        echo "[supra-qe] Ouvre manuellement : $url"
    fi
}
open_browser "$URL"

echo "[supra-qe] logs        : tail -f $LOGS_DIR/api.log"
echo "[supra-qe] arrêt        : ./ARRETER.sh"

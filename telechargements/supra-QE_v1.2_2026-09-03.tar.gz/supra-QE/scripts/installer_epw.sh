#!/usr/bin/env bash
# Installe / compile epw.x dans une arborescence Quantum ESPRESSO déjà configurée
# (pw.x / ph.x présents). Cause typique d'échec WF2 : dossier EPW/ absent du tarball.
#
# Usage :
#   export QE_ROOT=/chemin/vers/q-e-qe-7.5   # défaut : $QE_BIN_DIR/..
#   ./scripts/installer_epw.sh
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_SUPRA="$(cd "$SCRIPT_DIR/.." && pwd)"

if [[ -f "$ROOT_SUPRA/config.env" ]]; then
  # shellcheck disable=SC1091
  source "$ROOT_SUPRA/config.env"
fi

if [[ -z "${QE_ROOT:-}" ]]; then
  if [[ -n "${QE_BIN_DIR:-}" ]]; then
    QE_ROOT="$(cd "$QE_BIN_DIR/.." && pwd)"
  else
    QE_ROOT="/home/hiadsi/q-e-qe-7.5"
  fi
fi

TAG="${QE_EPW_TAG:-qe-7.5}"
BIN="$QE_ROOT/bin"

echo "[installer_epw] QE_ROOT=$QE_ROOT  tag=$TAG"

if [[ ! -x "$BIN/pw.x" || ! -x "$BIN/ph.x" ]]; then
  echo "[installer_epw] ERREUR : pw.x / ph.x introuvables dans $BIN — compile d'abord QE (make pw ph)." >&2
  exit 1
fi

if [[ -x "$BIN/epw.x" ]] && "$BIN/epw.x" </dev/null >/dev/null 2>&1; then
  echo "[installer_epw] epw.x déjà présent : $(readlink -f "$BIN/epw.x")"
  exit 0
fi

# Sources EPW manquantes → téléchargement ciblé depuis le tag QE
if [[ ! -d "$QE_ROOT/EPW/src" ]]; then
  echo "[installer_epw] Dossier EPW/ absent — téléchargement ($TAG)…"
  TMP="$(mktemp -d)"
  trap 'rm -rf "$TMP"' EXIT
  curl -fL -o "$TMP/epw.tgz" \
    "https://gitlab.com/QEF/q-e/-/archive/${TAG}/q-e-${TAG}.tar.gz?path=EPW"
  tar xzf "$TMP/epw.tgz" -C "$TMP"
  SRC_EPW="$(find "$TMP" -maxdepth 2 -type d -name EPW | head -1)"
  [[ -n "$SRC_EPW" ]] || { echo "[installer_epw] archive EPW invalide" >&2; exit 1; }
  cp -a "$SRC_EPW" "$QE_ROOT/"
fi

# make.depend requis par EPW/src/Makefile
if [[ ! -f "$QE_ROOT/EPW/src/make.depend" ]]; then
  echo "[installer_epw] make depend…"
  (cd "$QE_ROOT" && make depend)
fi

# Environnement Intel oneAPI si présent
if [[ -f /opt/intel/oneapi/setvars.sh ]]; then
  # shellcheck disable=SC1091
  source /opt/intel/oneapi/setvars.sh >/dev/null 2>&1 || true
fi

echo "[installer_epw] make epw…"
(cd "$QE_ROOT" && make epw -j"${MAKE_JOBS:-2}")

if [[ ! -x "$BIN/epw.x" ]]; then
  echo "[installer_epw] ÉCHEC : epw.x non produit dans $BIN" >&2
  exit 1
fi

echo "[installer_epw] OK → $(readlink -f "$BIN/epw.x")"
echo "[installer_epw] Redémarre Supra-QE (./ARRETER.sh && ./DEMARRER.sh) pour que l’API voie epw.x."
echo "[installer_epw] Rappel WF2 : pseudo NC, ph.x + pp.py (save/), puis epw.x."

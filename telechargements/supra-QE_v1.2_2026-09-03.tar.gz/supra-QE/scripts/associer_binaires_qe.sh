#!/usr/bin/env bash
# ==========================================================================
#  Associe les binaires QE (dont epw.x) au projet Supra-QE via supra-QE/bin/
#
#  L'utilisateur n'a pas à recompiler EPW à chaque fois : on crée des liens
#  symboliques depuis une installation QE déjà compilée (pw.x, ph.x, epw.x…).
#
#  Usage :
#    ./scripts/associer_binaires_qe.sh
#    ./scripts/associer_binaires_qe.sh /chemin/vers/q-e-qe-7.5/bin
#    QE_BIN_DIR=/opt/qe/bin ./scripts/associer_binaires_qe.sh
# ==========================================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$HERE"

if [[ -f "$HERE/config.env" ]]; then
  # shellcheck disable=SC1091
  source "$HERE/config.env"
fi

SRC="${1:-${QE_BIN_DIR:-}}"
if [[ -z "$SRC" ]]; then
  for c in \
      "$HOME/q-e-qe-7.5/bin" \
      "$HOME/q-e-7.5/bin" \
      /opt/qe/bin \
      /usr/local/bin
  do
    if [[ -x "$c/pw.x" ]]; then SRC="$c"; break; fi
  done
fi

if [[ -z "$SRC" || ! -x "$SRC/pw.x" ]]; then
  echo "[associer] ERREUR : précise le dossier QE (pw.x) :" >&2
  echo "  ./scripts/associer_binaires_qe.sh /chemin/vers/qe/bin" >&2
  exit 1
fi
SRC="$(cd "$SRC" && pwd)"

# Si epw.x manque : tenter l'installateur (compile une fois dans l'arbre QE)
if [[ ! -x "$SRC/epw.x" ]]; then
  echo "[associer] epw.x absent de $SRC — tentative ./scripts/installer_epw.sh …"
  if [[ -x "$HERE/scripts/installer_epw.sh" ]]; then
    QE_ROOT="$(cd "$SRC/.." && pwd)" "$HERE/scripts/installer_epw.sh" || true
  fi
fi

mkdir -p "$HERE/bin"
BINS=(pw.x ph.x q2r.x matdyn.x lambda.x alpha2f.x epw.x wannier90.x)
LINKED=()
MISSING=()
for b in "${BINS[@]}"; do
  if [[ -e "$SRC/$b" || -L "$SRC/$b" ]]; then
    ln -sfn "$SRC/$b" "$HERE/bin/$b"
    LINKED+=("$b")
  else
    MISSING+=("$b")
  fi
done

# pp.py (regroupement save/ avant epw) — lien pratique
PP_CAND=(
  "$SRC/../EPW/bin/pp.py"
  "$SRC/pp.py"
)
for pp in "${PP_CAND[@]}"; do
  if [[ -f "$pp" ]]; then
    ln -sfn "$(cd "$(dirname "$pp")" && pwd)/$(basename "$pp")" "$HERE/bin/pp.py"
    LINKED+=("pp.py")
    break
  fi
done

echo "[associer] Source QE : $SRC"
echo "[associer] Liens    → $HERE/bin/"
echo "[associer] Associés : ${LINKED[*]:-aucun}"
[[ ${#MISSING[@]} -gt 0 ]] && echo "[associer] Absents  : ${MISSING[*]}"

# Pointe config.env vers le bin local du projet (portable dans ce dossier)
if [[ -f "$HERE/config.env" ]]; then
  if grep -q '^export QE_BIN_DIR=' "$HERE/config.env" 2>/dev/null; then
    sed -i "s|^export QE_BIN_DIR=.*|export QE_BIN_DIR=\"$HERE/bin\"|" "$HERE/config.env"
  else
    echo "export QE_BIN_DIR=\"$HERE/bin\"" >> "$HERE/config.env"
  fi
  echo "[associer] config.env → QE_BIN_DIR=$HERE/bin"
else
  echo "export QE_BIN_DIR=\"$HERE/bin\"" > "$HERE/config.env"
  echo "[associer] config.env créé avec QE_BIN_DIR=$HERE/bin"
fi

if [[ -x "$HERE/bin/epw.x" ]]; then
  echo "[associer] ✅ epw.x associé — WF2 EPW utilisable sans recompiler."
else
  echo "[associer] ⚠️  epw.x toujours absent — lance : ./scripts/installer_epw.sh"
  echo "           puis relance : ./scripts/associer_binaires_qe.sh"
fi
echo "[associer] Relance l'API : ./ARRETER.sh && ./DEMARRER.sh"

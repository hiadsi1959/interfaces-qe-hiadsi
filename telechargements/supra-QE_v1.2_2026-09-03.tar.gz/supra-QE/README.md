# 🧊 Supra-QE — Propriétés Supraconductrices

**LMESM / USTO-MB · S. Hiadsi** — module autonome pour calculer la température critique
supraconductrice (Tᶜ) avec Quantum ESPRESSO (couplage électron–phonon).

Interface web + API Flask : génération d’inputs, lancement pas à pas, vérification
de la chaîne, exploration des résultats (deux voies).

---

## Vue d’ensemble

Deux workflows indépendants (dossiers séparés `classic/` et `epw/`) :

### Voie classique — ph.x + matdyn / lambda.x

```
vc-relax (prérequis)
    → pw.x SCF  →  pw.x NSCF dense  →  ph.x (elph)
    → q2r.x  →  matdyn.x / lambda.x
    → α²F(ω), λ, ω_log, ⟨ω²⟩^½, Tᶜ (McMillan / Allen–Dynes)
```

### Voie EPW — Wannier + Éliashberg

```
vc-relax (prérequis)
    → pw.x SCF  →  ph.x (dvscf + dyn)  →  [pp.py → save/]
    → pw.x NSCF coarse (nbnd élevé)  →  epw.x
    → Tᶜ, Δ(T), gap anisotrope, Z(0), 2Δ₀/k_B Tᶜ
```

Détail : [docs/workflow_supra.md](docs/workflow_supra.md).

---

## Démarrage rapide

```bash
cd /chemin/vers/supra-QE
./configurer.sh                  # pointe QE + associe pw.x / epw.x → supra-QE/bin/
./DEMARRER.sh                    # API + navigateur → http://127.0.0.1:8765/interface/
```

**EPW sans recompiler à chaque fois** : après une seule compilation QE (`make epw`),
associe les exécutables au projet :

```bash
./scripts/associer_binaires_qe.sh /chemin/vers/q-e-qe-7.5/bin
# si epw.x manque encore :
./scripts/installer_epw.sh && ./scripts/associer_binaires_qe.sh
```

L’API utilise alors `supra-QE/bin/` (liens vers ton QE). Sur un autre PC, relance
`associer_binaires_qe.sh` vers le QE local — pas besoin de recompiler EPW si
`epw.x` y est déjà.

Installation one-shot sur une machine neuve :

```bash
./INSTALL_AUTOMATIQUE.sh --qe-bin /chemin/vers/qe/bin
```

| Commande | Rôle |
|----------|------|
| `./DEMARRER.sh` | Lance l’API et ouvre l’interface dans **Firefox** |
| `./ARRETER.sh` | Arrête l’API |
| `./STATUT.sh` | État API /health |

**Navigateur** : `./DEMARRER.sh` ouvre **Firefox** par défaut. Pour un autre navigateur :

```bash
SUPRA_BROWSER=chrome ./DEMARRER.sh     # Google Chrome / Chromium
SUPRA_BROWSER=xdg-open ./DEMARRER.sh   # navigateur par défaut du système
SUPRA_BROWSER=none ./DEMARRER.sh       # API seule, pas d’ouverture auto
```

On peut aussi fixer `export SUPRA_BROWSER=firefox` dans `config.env`.

**Important** : ouvrir l’interface via `http://…/interface/`, pas le fichier HTML en `file://`.

**Sécurité LAN** : `SUPRA_QE_HOST=0.0.0.0` exige `SUPRA_ALLOW_LAN=1` **et**
un `SUPRA_API_TOKEN` (sinon repli sur `127.0.0.1`). En-tête `X-Supra-Token`
ou champ Chemins. Voir [docs/AUTRE_PC.md](docs/AUTRE_PC.md).

Tests :

```bash
.venv/bin/pip install -r requirements-dev.txt   # si besoin
.venv/bin/pytest tests/ -q
```

---

## Interface

L’UI démarre sur le **Guide**, puis :

| Onglet | Contenu |
|--------|---------|
| **Guide** | Mode d’emploi + accès Calculs / Résultats |
| **Calculs** | Matériau → pseudos NC → prérequis → WF1/WF2 → paramètres → lancement |
| **Résultats** | Exploration des deux voies (4 modules) |
| **Aide** | Comparaison des méthodes, formules, règles |

Autres contrôles (barre du haut) :

- **FR / EN** — bascule de langue
- **📁 Chemins** — URL de l’API + dossiers inputs / outputs / pseudos (autre PC)
- **↻ API** — santé de l’API et binaires QE
- **Tout déplier / Tout replier** — sections (Calculs / Aide) ; chaque carte a aussi ▼ / ▲

### Onglet Résultats — 4 modules

1. **Synthèse & scalaires** — λ, ω_log, ⟨ω²⟩^½, N(E_F), Δ₀, Tᶜ(μ*) Classique vs EPW ; export CSV / LaTeX / rapport
2. **Spectres 2D** — α²F(ω) + λ(ω), F(ω), dispersion pondérée, Δ(T)
3. **Surface de Fermi & anisotropie** — histogramme Δ_k, rapport BCS, self-énergie, λ_qν
4. **Fichiers bruts** — inventaire + aperçu des sorties

Bouton **🔎 Explorer tous les résultats** → `POST /api/results/explore`.

---

## Autre PC / réseau

Deux modes — détail : [docs/AUTRE_PC.md](docs/AUTRE_PC.md).

**A. Projet complet sur la machine de calcul**

```bash
# source
./EMBALLER.sh -o supra-QE.tar.gz
# cible
tar xzf supra-QE.tar.gz && cd supra-QE
./INSTALL_AUTOMATIQUE.sh -y --qe-bin ~/q-e/bin
```

**B. Navigateur distant, API sur le PC de calcul**

```bash
# config.env sur le serveur
export SUPRA_QE_HOST="0.0.0.0"
export SUPRA_QE_PORT="8765"
./DEMARRER.sh   # affiche les URL http://IP:8765/interface/
```

Sur l’autre PC : ouvrir `http://IP:8765/interface/`  
ou `http://IP:8765/interface/?api=http://IP:8765`  
ou **📁 Chemins** → URL API → **Appliquer & tester**.

| Script | Rôle |
|--------|------|
| `EMBALLER.sh` | Archive portable (sans `config.env`, `.venv/`, `logs/`, `outputs/`) |
| `configurer.sh` | QE, pseudos, chemins, venv → `config.env` |
| `INSTALL_AUTOMATIQUE.sh` | Configuration + démarrage |
| `AUTO_TRANSFERT.sh` | Déploiement guidé avec contrôles |

Variables utiles (`config.env`, modèle `config.env.example`) :

`QE_BIN_DIR`, `QE_PSEUDO_DIR`, `SUPRA_QE_HOST`, `SUPRA_QE_PORT`,  
`SUPRA_INPUTS_DIR`, `SUPRA_OUTPUTS_DIR`, `SUPRA_PSEUDO_DIR_REL`.

---

## Arborescence

```
supra-QE/
├── README.md
├── configurer.sh / DEMARRER.sh / ARRETER.sh / STATUT.sh
├── EMBALLER.sh / INSTALL_AUTOMATIQUE.sh / AUTO_TRANSFERT.sh
├── config.env.example
├── requirements.txt / requirements-dev.txt
├── api/
│   ├── supra_api.py          API Flask (jobs, fichiers, résultats)
│   └── supra_results.py      Moments α²F, parseurs, /explore
├── interface/                Scripts JS nécessaires uniquement
│   ├── Interface_Supra_QE.html
│   ├── supra_config.js       Flags UI (ex. SSCHA)
│   ├── supra_inputs.js       Générateurs .in
│   ├── supra_api_client.js   Client HTTP
│   ├── supra_plots.js        Tracés SVG
│   ├── supra_app.js          Logique interface
│   ├── supra_i18n_dict.js
│   └── supra_i18n.js         FR / EN
├── tests/
│   ├── test_api_smoke.py
│   ├── test_api_security.py
│   ├── test_api_endpoints.py
│   └── test_results_explore.py
├── inputs/   outputs/   pseudos/   logs/
└── docs/
    ├── workflow_supra.md
    └── AUTRE_PC.md
```

---

## Règles imposées par l’interface

### 1. Pseudopotentiels Norm-Conserving

Le couplage e–p exige des NC. Les USPP / PAW sont refusés pour `ph.x`.  
Bibliothèque recommandée : [PseudoDojo (NC)](http://www.pseudo-dojo.org/).

### 2. Prérequis

Seul **`vc-relax.out`** (avec structure extractible) est obligatoire dans
`inputs/<matériau>/`. Chaque workflow relance son propre SCF dans son dossier.

### 3. μ\* (écrantage coulombien)

Pré-rempli à **0.10** (typiquement 0.10–0.15). L’onglet Résultats calcule Tᶜ
pour une série de μ\* (McMillan + Allen–Dynes avec f₁, f₂ si ⟨ω²⟩^½ est connu).

### 4. Grilles k vs q

La grille **k** (NSCF) doit être nettement plus dense que la grille **q** (phonons),
avec un ratio entier. L’interface affiche et valide ce ratio.

### 5. Enchaînement

Chaque étape est bloquée tant que l’amont n’a pas `JOB DONE` et les fichiers
intermédiaires requis. Le panneau **Vérification de l’enchaînement** le montre
en direct ; un lancement forcé reste possible avec confirmation.

---

## Sorties exploitables

Après **🔎 Explorer tous les résultats**, les grandeurs typiques sont :

| Grandeur | Classique | EPW |
|----------|-----------|-----|
| λ, ω_log, ⟨ω²⟩^½ | α²F / matdyn / lambda.x | α²F / epw.out |
| Tᶜ(μ\*) | McMillan + Allen–Dynes | idem + Tᶜ code |
| N(E_F), E_F | scf / nscf / lambda | scf / nscf |
| α²F(ω), λ(ω), F(ω) | a2F.dat, phonon.dos | \*.a2f, \*.phdos |
| Dispersion / γ_qν | freq.gp, elph.inp_lambda.\* | — |
| Δ(T), Δ_k, Z(0) | — | epw.out, imag_aniso_\* |

Fichiers sous `outputs/<matériau>/classic/` et `…/epw/` (et parfois `inputs/…`).

---

## Références

- McMillan, *Phys. Rev.* **167**, 331 (1968)
- Allen & Dynes, *Phys. Rev. B* **12**, 905 (1975)
- Giannozzi *et al.*, *J. Phys.: Condens. Matter* **21**, 395502 (2009) — Quantum ESPRESSO
- Poncé *et al.*, *Comput. Phys. Commun.* **209**, 116 (2016) — EPW
- PseudoDojo, *Comp. Mat. Sci.* **154**, 35 (2018)

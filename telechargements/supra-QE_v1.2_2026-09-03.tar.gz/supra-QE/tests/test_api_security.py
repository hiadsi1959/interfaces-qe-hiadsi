#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tests de sécurité — supra-QE (anti-RCE /api/file/save, anti-DoS /api/run)

Ces tests valident les corrections P0 et P1 de l'audit :
  * P0a : /api/file/save ne doit plus permettre l'écrasement de fichiers protégés
         (api/supra_api.py, scripts/*.sh, config.env, interface/*.html, etc.).
  * P0b : /api/file/read refuse config.env, sources, path traversal (une seule
         _safe_path stricte — plus de doublon permissif).
  * P1 : /api/run doit refuser (HTTP 429) les lancements excédant le sémaphore.
  * P2 : LAN (0.0.0.0) exige SUPRA_API_TOKEN ; POST /api/job/<id>/cancel.

Exécuter :
    .venv/bin/pytest tests/test_api_security.py -v
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "api"))

import supra_api  # noqa: E402


# ────────────────────────────  Fixtures  ────────────────────────────────────

@pytest.fixture
def client():
    """Client Flask de test + cleanup des fichiers créés par les tests."""
    supra_api.app.config["TESTING"] = True
    created: list[Path] = []
    yield supra_api.app.test_client(), created
    # Cleanup : efface les fichiers de test écrits sous inputs/
    for p in created:
        try:
            if p.is_file():
                p.unlink()
            elif p.is_dir():
                import shutil
                shutil.rmtree(p, ignore_errors=True)
        except OSError:
            pass


@pytest.fixture(autouse=True)
def _isolate_jobs():
    """Vide le JOBS dict entre tests (évite pollution d'état)."""
    supra_api.JOBS.clear()
    yield
    supra_api.JOBS.clear()


def _post(client, route: str, payload: dict):
    """POST JSON helper (le client est le tuple (test_client, created_list))."""
    return client[0].post(route, data=json.dumps(payload),
                          content_type="application/json")


# ────────────────────────────  P0 : Anti-RCE  ───────────────────────────────

PAYLOADS_BLOCKED_RCE = [
    # Écrasement fichiers de code/config/UI du projet
    ("../../api/supra_api.py",                          "rce"),
    ("../DEMARRER.sh",                                   "rce"),
    ("../../config.env",                                 "secrets"),
    ("../configurer.sh",                                 "rce"),
    ("../../.gitignore",                                 "rce"),
    ("../../interface/Interface_Supra_QE.html",         "xss"),
    ("../../requirements.txt",                           "rce"),
    # Path traversal déguisé
    ("inputs/../../api/supra_api.py",                    "rce"),
    ("outputs/../../../etc/passwd",                      "rce"),
    # Écritures hors zone autorisée
    ("api/test.txt",                                     "zone"),
    ("scripts/test.txt",                                 "zone"),
    ("docs/test.txt",                                    "zone"),
    # Dotfiles interdits
    ("inputs/.env",                                      "secrets"),
    ("outputs/.gitignore",                               "rce"),
    # Extensions sensibles (même sous dossier autorisé)
    ("inputs/test.py",                                   "rce"),
    ("inputs/test.sh",                                   "rce"),
    ("inputs/test.env",                                  "secrets"),
    ("inputs/test.html",                                 "xss"),
    ("inputs/test.js",                                   "xss"),
    ("outputs/test.exe",                                 "rce"),
]

@pytest.mark.parametrize("rel,hint", PAYLOADS_BLOCKED_RCE,
                         ids=[p[0] for p in PAYLOADS_BLOCKED_RCE])
def test_safe_write_path_blocks_rce_attempts(client, rel, hint):
    """Toute tentative de RCE ou d'écriture hors zone doit être refusée (403)."""
    resp = _post(client, "/api/file/save",
                 {"path": rel, "content": "malicious_payload"})
    assert resp.status_code == 403, (
        f"FAIL [{hint}] : {rel!r} aurait dû être bloqué (RCE/zone/extension). "
        f"Reçu : {resp.status_code} {resp.get_data(as_text=True)}"
    )
    body = resp.get_json()
    assert body.get("ok") is False
    assert "error" in body


PAYLOADS_ALLOWED = [
    # Extensions whitelist sous inputs/
    ("inputs/Nb/test.in",                       "qe input"),
    ("inputs/Nb/test.out",                      "qe output"),
    ("inputs/Nb/classic/test.json",             "config"),
    ("inputs/Nb/test.dat",                      "data"),
    ("inputs/Nb/test.save",                     "qe restart"),
    # Dotfile légitime
    ("inputs/.gitkeep",                         "gitkeep"),
    # Sous-dossiers arbitraires (workflow classique + epw)
    ("inputs/Nb/classic/sub/test.in",           "deep nested"),
    ("outputs/Nb/epw/test.dat",                 "epw output"),
]


@pytest.mark.parametrize("rel,hint", PAYLOADS_ALLOWED,
                         ids=[p[0] for p in PAYLOADS_ALLOWED])
def test_safe_write_path_allows_legitimate_writes(client, rel, hint):
    """Les écritures légitimes (inputs/outputs + whitelist) doivent passer (200)."""
    resp = _post(client, "/api/file/save",
                 {"path": rel, "content": "data\n"})
    assert resp.status_code == 200, (
        f"FAIL [{hint}] : {rel!r} aurait dû être autorisé. "
        f"Reçu : {resp.status_code} {resp.get_data(as_text=True)}"
    )
    body = resp.get_json()
    assert body.get("ok") is True
    # Track for cleanup
    target = ROOT / rel
    client[1].append(target)


def test_safe_write_path_symlink_attack(client, tmp_path):
    """Symlink dans inputs/ pointant hors zone : resolve() doit suivre le
    lien et bloquer avec 403, et aucun fichier ne doit être créé.

    Vecteur : inputs/_evil_symlink -> tmp_path/outside_zone/
    POST /api/file/save inputs/_evil_symlink/payload.txt
    Sans protection : payload écrit dans tmp_path (RCE).
    Protection attendue : .resolve() sort de inputs/ -> 403.
    """
    outside_zone = tmp_path / "outside_zone"
    outside_zone.mkdir(exist_ok=True)
    target_outside = outside_zone / "payload.txt"
    # Pre-condition : la cible hors-zone ne doit pas exister
    assert not target_outside.exists(), "pre-condition : cible hors-zone absente"

    symlink = ROOT / "inputs" / "_evil_symlink"
    try:
        symlink.symlink_to(outside_zone)
    except (OSError, NotImplementedError):
        pytest.skip("Symlinks non supportes sur ce FS")

    try:
        resp = _post(client, "/api/file/save",
                     {"path": "inputs/_evil_symlink/payload.txt",
                      "content": "MARKER_RCE_PAYLOAD_xyz123"})
        # 1) L'API doit refuser avec 403
        assert resp.status_code == 403, (
            f"FAIL symlink RCE: pas bloque. Recu: {resp.status_code} "
            f"{resp.get_data(as_text=True)!r}"
        )
        # 2) Aucun fichier ne doit avoir été créé hors inputs/ (preuve d'absence)
        assert not target_outside.exists(), (
            f"FAIL symlink RCE: fichier ecrit hors zone via symlink! -> {target_outside}"
        )
    finally:
        # Cleanup symlink dans inputs/ (évite pollution persistante)
        try:
            if symlink.is_symlink() or symlink.exists():
                symlink.unlink()
        except OSError:
            pass


# ────────────────────────────  P1 : Anti-DoS  ───────────────────────────────

def test_health_exposes_max_concurrent_jobs():
    """/health doit exposer le max_concurrent_jobs (transparence)."""
    client = supra_api.app.test_client()
    # Relâcher tout pour ce test
    while supra_api._job_slots.acquire(blocking=False):
        pass
    supra_api._job_slots.release()

    resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.get_json()
    assert "max_concurrent_jobs" in data
    assert isinstance(data["max_concurrent_jobs"], int)
    assert data["max_concurrent_jobs"] >= 1
    assert data["max_concurrent_jobs"] == supra_api._MAX_CONCURRENT_JOBS


def test_run_endpoint_returns_429_when_saturated(monkeypatch, tmp_path):
    """Si le sémaphore est plein, /api/run doit répondre 429 sans lancer pw.x."""
    # Sature le sémaphore manuellement (simule N jobs en cours)
    for _ in range(supra_api._MAX_CONCURRENT_JOBS):
        assert supra_api._job_slots.acquire(blocking=False)

    # Crée un input factice valide
    fake_input = tmp_path / "fake.in"
    fake_input.write_text("&CONTROL\n/\n")

    # Monkeypatch _safe_path pour pointer vers notre tmp (test isolé)
    real_safe_path = supra_api._safe_path
    def _local_safe_path(rel: str):
        if not rel:
            return None
        return (tmp_path / Path(rel).name).resolve()
    monkeypatch.setattr(supra_api, "_safe_path", _local_safe_path)

    try:
        client = supra_api.app.test_client()
        resp = client.post(
            "/api/run",
            data=json.dumps({
                "program": "pw.x",
                "input": "fake.in",
                "output": "fake.out",
            }),
            content_type="application/json",
        )
        assert resp.status_code == 429, (
            f"Doit refuser avec 429 quand saturé, reçu : {resp.status_code} "
            f"({resp.get_data(as_text=True)})"
        )
        body = resp.get_json()
        assert body.get("ok") is False
        assert "max_concurrent_jobs" in body
        assert body["max_concurrent_jobs"] == supra_api._MAX_CONCURRENT_JOBS
    finally:
        # Libère le sémaphore pour les tests suivants
        for _ in range(supra_api._MAX_CONCURRENT_JOBS):
            supra_api._job_slots.release()
        # Restaure _safe_path
        monkeypatch.setattr(supra_api, "_safe_path", real_safe_path)


def test_run_endpoint_releases_slot_on_validation_error(monkeypatch):
    """Si la validation échoue APRÈS acquire() (programme inconnu), le slot
    doit être libéré (pas de deadlock)."""
    client = supra_api.app.test_client()

    # S'assurer qu'on a TOUS les slots au début
    for _ in range(supra_api._MAX_CONCURRENT_JOBS):
        supra_api._job_slots.acquire(blocking=False)
    for _ in range(supra_api._MAX_CONCURRENT_JOBS):
        supra_api._job_slots.release()

    resp = client.post(
        "/api/run",
        data=json.dumps({"program": "evil_binary", "input": "x.in",
                         "output": "x.out"}),
        content_type="application/json",
    )
    # Validation échoue (programme inconnu) -> 400, slot libéré
    assert resp.status_code == 400

    # Le sémaphore doit être entièrement libre -> on doit pouvoir N fois acquire
    for _ in range(supra_api._MAX_CONCURRENT_JOBS):
        assert supra_api._job_slots.acquire(blocking=False), \
            "Slot non libéré après erreur de validation !"
    for _ in range(supra_api._MAX_CONCURRENT_JOBS):
        supra_api._job_slots.release()


# ────────────────────────  P0b : Anti-lecture sensible  ─────────────────────

PAYLOADS_BLOCKED_READ = [
    ("config.env",                          "secrets"),
    ("../config.env",                       "secrets"),
    ("api/supra_api.py",                    "sources"),
    ("interface/Interface_Supra_QE.html",   "sources"),
    ("interface/supra_app.js",              "sources"),
    ("DEMARRER.sh",                         "scripts"),
    ("README.md",                           "docs"),
    ("requirements.txt",                    "sources"),
    ("inputs/../../api/supra_api.py",       "traversal"),
    ("inputs/../../config.env",             "secrets"),
    ("../../../etc/passwd",                 "traversal"),
    (".venv/pyvenv.cfg",                    "venv"),
    (".git/config",                         "git"),
]


@pytest.mark.parametrize("rel,hint", PAYLOADS_BLOCKED_READ,
                         ids=[p[0] for p in PAYLOADS_BLOCKED_READ])
def test_safe_path_blocks_sensitive_reads(client, rel, hint):
    """Lecture hors inputs/outputs/logs/tmp/pseudos → 404 (pas de fuite)."""
    resp = _post(client, "/api/file/read", {"path": rel})
    assert resp.status_code == 404, (
        f"FAIL [{hint}] : lecture de {rel!r} aurait dû être bloquée. "
        f"Reçu : {resp.status_code} {resp.get_data(as_text=True)}"
    )
    body = resp.get_json()
    assert body.get("ok") is False
    # Ne pas renvoyer le contenu d'un fichier sensible
    assert "content" not in body or not body.get("content")


def test_safe_path_allows_inputs_read(client):
    """Lecture légitime sous inputs/ doit fonctionner."""
    target = ROOT / "inputs" / "_audit_read_ok.txt"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("ok-read\n", encoding="utf-8")
    client[1].append(target)
    resp = _post(client, "/api/file/read", {"path": "inputs/_audit_read_ok.txt"})
    assert resp.status_code == 200
    assert resp.get_json().get("content") == "ok-read\n"


def test_safe_path_unit_rejects_config_env():
    """Contrôle unitaire direct de _safe_path (sans HTTP)."""
    assert supra_api._safe_path("config.env") is None
    assert supra_api._safe_path("api/supra_api.py") is None
    assert supra_api._safe_path("../../../etc/passwd") is None
    # Chemin sous inputs autorisé même s'il n'existe pas encore (résolution OK)
    p = supra_api._safe_path("inputs/phantom.in")
    assert p is not None
    assert p.name == "phantom.in"


# ────────────────────────  Tests de non-régression  ─────────────────────────

def test_health_still_works():
    """/health doit toujours répondre."""
    client = supra_api.app.test_client()
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.get_json().get("service") == "supra-qe"


def test_pseudo_check_still_works(client):
    """L'endpoint /api/pseudo/check ne doit pas être impacté."""
    resp = _post(client, "/api/pseudo/check",
                 {"pseudos": ["Xx.upf"],
                  "pseudo_dir": str(ROOT / "pseudos")})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["all_nc"] is False


def test_grid_validate_still_works(client):
    """L'endpoint /api/grid/validate ne doit pas être impacté."""
    resp = _post(client, "/api/grid/validate",
                 {"k": [24, 24, 24], "q": [4, 4, 4]})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["ok"] is True


# ────────────────────────  P2 : token LAN + cancel  ─────────────────────────

def test_resolve_listen_host_requires_token_on_lan(monkeypatch):
    """0.0.0.0 + ALLOW_LAN sans token → repli 127.0.0.1."""
    monkeypatch.setattr(supra_api, "_ALLOW_LAN", True)
    monkeypatch.setattr(supra_api, "_API_TOKEN", "")
    assert supra_api._resolve_listen_host("0.0.0.0") == "127.0.0.1"
    monkeypatch.setattr(supra_api, "_API_TOKEN", "secret")
    assert supra_api._resolve_listen_host("0.0.0.0") == "0.0.0.0"
    monkeypatch.setattr(supra_api, "_ALLOW_LAN", False)
    assert supra_api._resolve_listen_host("0.0.0.0") == "127.0.0.1"
    assert supra_api._resolve_listen_host("127.0.0.1") == "127.0.0.1"


def test_api_token_gate_rejects_without_header(client, monkeypatch):
    """Avec SUPRA_API_TOKEN, /api/* sans en-tête → 401 ; /health reste libre."""
    monkeypatch.setattr(supra_api, "_API_TOKEN", "test-secret-xyz")
    c = client[0]
    assert c.get("/health").status_code == 200
    resp = _post(client, "/api/grid/validate", {"k": [8, 8, 8], "q": [2, 2, 2]})
    assert resp.status_code == 401
    resp_ok = c.post(
        "/api/grid/validate",
        data=json.dumps({"k": [8, 8, 8], "q": [2, 2, 2]}),
        content_type="application/json",
        headers={"X-Supra-Token": "test-secret-xyz"},
    )
    assert resp_ok.status_code == 200


def test_api_job_cancel_kills_process(client):
    """POST /api/job/<id>/cancel tue le groupe et marque cancelled."""
    import subprocess
    import time as _time

    proc = subprocess.Popen(
        ["sleep", "60"],
        start_new_session=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    jid = "job_cancel_unit"
    supra_api.JOBS[jid] = {
        "program": "pw.x", "status": "running", "progress": 40,
        "message": "running", "pid": proc.pid, "proc": proc, "start": _time.time(),
    }
    try:
        resp = client[0].post(f"/api/job/{jid}/cancel")
        assert resp.status_code == 200
        body = resp.get_json()
        assert body["ok"] is True
        assert body["status"] == "cancelled"
        assert supra_api.JOBS[jid]["status"] == "cancelled"
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            pytest.fail("le processus sleep n'a pas été tué après cancel")
    finally:
        if proc.poll() is None:
            try:
                proc.kill()
            except OSError:
                pass
        supra_api.JOBS.pop(jid, None)


def test_api_job_cancel_unknown(client):
    resp = client[0].post("/api/job/does_not_exist/cancel")
    assert resp.status_code == 404

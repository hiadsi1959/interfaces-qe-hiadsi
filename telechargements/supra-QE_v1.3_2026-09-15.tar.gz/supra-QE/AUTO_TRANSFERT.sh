#!/usr/bin/env bash
# ==========================================================================
#  Supra-QE — AUTO_TRANSFERT.sh : déploiement automatique sur nouveau PC
#
#  À exécuter APRÈS avoir copié et extrait l'archive supra-QE/.
#  Détecte ou demande les binaires QE, configure tout, et démarre l'API.
#
#  Usage :
#    ./AUTO_TRANSFERT.sh                           # déploiement complet
#    ./AUTO_TRANSFERT.sh --config-seulement        # ne démarre pas l'API
#    ./AUTO_TRANSFERT.sh --qe-bin /opt/qe/bin      # forcer le chemin QE
#    ./AUTO_TRANSFERT.sh --host 0.0.0.0 --port 8765
#    ./AUTO_TRANSFERT.sh --yes                     # tout automatique (non-interactif)
# ==========================================================================

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

# Options par défaut
MODE_CONFIG_SEUL=0
MODE_YES=0
PASS_ARGS=()

usage() {
    cat <<'EOF'
Usage : ./AUTO_TRANSFERT.sh [options]

Déploie et démarre Supra-QE automatiquement sur un nouveau PC.

Options :
  --config-seulement     Configure seulement (ne lance pas DEMARRER.sh)
  -y, --yes              Mode non interactif (tout automatique)
  -h, --help             Afficher cette aide

Options transmises à configurer.sh :
  --qe-bin PATH          Dossier des binaires QE
  --pseudo-dir PATH      Dossier des pseudos .upf
  --inputs-dir PATH      Dossier des inputs
  --outputs-dir PATH     Dossier des outputs
  --host ADDR            Hôte API
  --port N               Port API

Exemples :
  ./AUTO_TRANSFERT.sh
  ./AUTO_TRANSFERT.sh -y --qe-bin ~/q-e-qe-7.5/bin
  ./AUTO_TRANSFERT.sh --config-seulement
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --config-seulement) MODE_CONFIG_SEUL=1; shift ;;
        -y|--yes)           MODE_YES=1;         shift ;;
        -h|--help)          usage; exit 0 ;;
        *) PASS_ARGS+=("$1"); shift ;;
    esac
done

# ── Couleurs pour les messages ───────────────────────────────────────────
VERT='\033[0;32m'
BLEU='\033[0;34m'
JAUNE='\033[1;33m'
ROUGE='\033[0;31m'
CYAN='\033[0;36m'
GRAS='\033[1m'
NC='\033[0m' # Pas de couleur

success() { echo -e "${VERT}[ok]${NC} $1"; }
info()    { echo -e "${BLEU}[...]${NC} $1"; }
warn()    { echo -e "${JAUNE}[!]${NC} $1"; }
error()   { echo -e "${ROUGE}[err]${NC} $1" >&2; }

# ── Bannière ─────────────────────────────────────────────────────────────
echo ""
echo -e "  ${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "  ${CYAN}║${NC}  ${GRAS}Supra-QE — Déploiement Automatique${NC}                 ${CYAN}║${NC}"
echo -e "  ${CYAN}║${NC}  Transfert vers nouveau PC                            ${CYAN}║${NC}"
echo -e "  ${CYAN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""
info "Dossier projet : $HERE"
echo ""

# ── 1. Vérification de l'intégrité du projet ─────────────────────────────
info "Vérification de l'intégrité du projet…"

FICHIERS_REQUIS=(
    "README.md"
    "api/supra_api.py"
    "api/supra_results.py"
    "interface/Interface_Supra_QE.html"
    "interface/supra_config.js"
    "interface/supra_app.js"
    "interface/supra_inputs.js"
    "interface/supra_api_client.js"
    "interface/supra_plots.js"
    "interface/supra_i18n.js"
    "interface/supra_i18n_dict.js"
    "configurer.sh"
    "DEMARRER.sh"
    "ARRETER.sh"
    "STATUT.sh"
    "requirements.txt"
)

FICHIERS_MANQUANTS=0
for f in "${FICHIERS_REQUIS[@]}"; do
    if [[ ! -f "$HERE/$f" ]]; then
        error "Fichier manquant : $f"
        FICHIERS_MANQUANTS=1
    fi
done

if [[ "$FICHIERS_MANQUANTS" -eq 1 ]]; then
    error "L'intégrité du projet est compromise."
    error "Ré-extrais l'archive depuis la source ou vérifie le transfert."
    exit 1
fi
success "Intégrité du projet vérifiée (${#FICHIERS_REQUIS[@]} fichiers requis présents)."

# ── 2. Vérification des scripts exécutables ──────────────────────────────
info "Vérification des droits d'exécution…"
chmod +x "$HERE/configurer.sh" "$HERE/DEMARRER.sh" "$HERE/ARRETER.sh" "$HERE/STATUT.sh" \
        "$HERE/INSTALL_AUTOMATIQUE.sh" "$HERE/EMBALLER.sh" 2>/dev/null || true
success "Scripts prêts."

# ── 3. Détection système ────────────────────────────────────────────────
info "Détection du système…"

OS="$(uname -s)"
ARCH="$(uname -m)"
DISTRO=""
PACKAGE_MANAGER=""

if [[ "$OS" == "Linux" ]]; then
    if command -v lsb_release &>/dev/null; then
        DISTRO="$(lsb_release -sd 2>/dev/null || lsb_release -si 2>/dev/null || echo "Linux")"
    elif [[ -f /etc/os-release ]]; then
        DISTRO="$(grep -oP 'PRETTY_NAME="?\K[^"]+' /etc/os-release 2>/dev/null || echo "Linux")"
    elif [[ -f /etc/debian_version ]]; then
        DISTRO="Debian $(cat /etc/debian_version)"
    else
        DISTRO="Linux"
    fi

    if command -v apt-get &>/dev/null; then PACKAGE_MANAGER="apt"
    elif command -v dnf &>/dev/null; then PACKAGE_MANAGER="dnf"
    elif command -v pacman &>/dev/null; then PACKAGE_MANAGER="pacman"
    elif command -v yum &>/dev/null; then PACKAGE_MANAGER="yum"
    elif command -v zypper &>/dev/null; then PACKAGE_MANAGER="zypper"
    fi
elif [[ "$OS" == "Darwin" ]]; then
    DISTRO="macOS $(sw_vers -productVersion 2>/dev/null || echo "?")"
    if command -v brew &>/dev/null; then PACKAGE_MANAGER="brew"; fi
fi

echo "    OS          : $OS $ARCH"
echo "    Distribution: $DISTRO"
echo "    Gestionnaire: ${PACKAGE_MANAGER:-non détecté}"
echo "    Python      : $(python3 --version 2>/dev/null || echo 'non installé')"
echo ""

# ── 4. Vérification des dépendances système ──────────────────────────────
PYTHON_OK=0
if python3 -c "import sys; sys.exit(0 if sys.version_info >= (3,8) else 1)" 2>/dev/null; then
    PYTHON_OK=1
fi

if [[ "$PYTHON_OK" -eq 0 ]]; then
    warn "Python 3.8+ requis mais non trouvé."
    warn "Installe Python 3 avec ton gestionnaire de paquets :"
    case "$PACKAGE_MANAGER" in
        apt)  echo "    sudo apt-get install -y python3 python3-venv python3-pip" ;;
        dnf)  echo "    sudo dnf install -y python3 python3-pip" ;;
        pacman) echo "    sudo pacman -Sy --noconfirm python python-pip" ;;
        brew) echo "    brew install python" ;;
        *)    echo "    Installe python3 manuellement depuis https://python.org" ;;
    esac
    echo ""
    if [[ "$MODE_YES" -eq 0 ]]; then
        read -r -p "  Continuer sans Python 3.8+ ? (o/N) " ans
        if [[ ! "$ans" =~ ^[oOyY] ]]; then
            error "Installation interrompue. Installe Python 3.8+ puis relance."
            exit 1
        fi
    fi
fi

# ── 5. Configuration (délégation à configurer.sh) ────────────────────────
info "Lancement de la configuration…"

CFG_ARGS=()
if [[ "$MODE_YES" -eq 1 ]]; then
    CFG_ARGS+=("-y")
fi
CFG_ARGS+=("${PASS_ARGS[@]}")

echo ""
echo -e "  ${JAUNE}━━━ Configuration de Supra-QE ──────────────────────────${NC}"
echo ""

if [[ -f "$HERE/config.env" ]]; then
    warn "config.env existe déjà."
    if [[ -t 0 ]] && [[ "$MODE_YES" -eq 0 ]]; then
        read -r -p "  Reconfigurer ? (o/N) " ans
        if [[ ! "$ans" =~ ^[oOyY] ]]; then
            info "Utilisation de la configuration existante."
        else
            "$HERE/configurer.sh" "${CFG_ARGS[@]}"
        fi
    elif [[ "$MODE_YES" -eq 1 ]]; then
        info "Mode automatique : reconfiguration."
        "$HERE/configurer.sh" "${CFG_ARGS[@]}"
    fi
else
    "$HERE/configurer.sh" "${CFG_ARGS[@]}"
fi

# ── Recharger la configuration (après reconfiguration éventuelle) ──────
if [[ -f "$HERE/config.env" ]]; then
    # shellcheck disable=SC1091
    source "$HERE/config.env"
fi

# ── 6. Vérification des pseudos ──────────────────────────────────────────
echo ""
info "Vérification des pseudopotentiels…"

PSEUDO_DIR="$HERE/pseudos"
if [[ -n "${QE_PSEUDO_DIR:-}" ]]; then
    PSEUDO_DIR="$QE_PSEUDO_DIR"
fi

NB_UPF=$(find "$PSEUDO_DIR" -maxdepth 2 -iname "*.upf" 2>/dev/null | wc -l | tr -d ' ')
if [[ "$NB_UPF" -eq 0 ]]; then
    warn "Aucun fichier .upf trouvé dans $PSEUDO_DIR"
    echo "  Les pseudopotentiels Norm-Conserving (PseudoDojo) sont nécessaires."
    echo "  Tu peux :"
    echo "    - Les copier depuis une clé USB : cp /media/*.upf $PSEUDO_DIR/"
    echo "    - Les télécharger depuis http://www.pseudo-dojo.org/"
    echo "    - Les importer via l'interface (onglet Pseudos)"
    echo ""
else
    success "$NB_UPF fichier(s) .upf trouvé(s)."
fi

# ── 7. Vérification des binaires QE ──────────────────────────────────────
echo ""
info "Vérification des binaires Quantum ESPRESSO…"

QE_BIN="${QE_BIN_DIR:-}"
# shellcheck disable=SC1091
source "$HERE/scripts/supra_qe_bins.sh" 2>/dev/null || true
BIN_OK=1
for prog in "${SUPRA_QE_BINS_REQUIRED[@]:-pw.x ph.x q2r.x matdyn.x}"; do
    FOUND=0
    if [[ -x "$QE_BIN/$prog" ]]; then
        FOUND=1
    fi
    if [[ "$FOUND" -eq 1 ]]; then
        echo "    ✓ $prog trouvé"
    else
        echo "    ✗ $prog manquant"
        BIN_OK=0
    fi
done

if [[ "$BIN_OK" -eq 0 ]]; then
    warn "Certains binaires QE obligatoires sont manquants."
    echo "  Assure-toi que Quantum ESPRESSO est installé et accessible."
    echo "  Exécute :"
    echo "    ./configurer.sh --qe-bin /chemin/vers/qe/bin"
    echo "  (ou modifie QE_BIN_DIR dans config.env)"
    echo ""
fi

if [[ -n "${SUPRA_QE_BINS_EPW:-}" ]]; then
    echo "  Optionnels (WF2 / post-traitement) :"
    for prog in "${SUPRA_QE_BINS_EPW[@]}" "${SUPRA_QE_BINS_OPTIONAL[@]}"; do
        if [[ -x "$QE_BIN/$prog" ]]; then
            echo "    ✓ $prog"
        else
            echo "    · $prog (absent)"
        fi
    done
    if [[ -x "$QE_BIN/pp.py" || -f "$QE_BIN/pp.py" ]]; then
        echo "    ✓ pp.py"
    else
        echo "    · pp.py (absent — regroupement save/ avant epw)"
    fi
fi

# ── 8. Vérification du service API (si QE OK) ────────────────────────────
if [[ -f "$HERE/config.env" ]]; then
    echo ""
    info "Vérification de la configuration réseau…"
    # shellcheck disable=SC1091
    source "$HERE/config.env"
    echo "    Hôte API : ${SUPRA_QE_HOST:-127.0.0.1}"
    echo "    Port API : ${SUPRA_QE_PORT:-8765}"
fi

# ── 9. Résumé avant démarrage ────────────────────────────────────────────
echo ""
echo "  ┌────────────────────────────────────────────────────────────┐"
echo "  │  Configuration terminée ✓                                  │"
echo "  └────────────────────────────────────────────────────────────┘"
echo ""
echo "  Dossier projet  : $HERE"
echo "  QE_BIN_DIR      : ${QE_BIN_DIR:-non configuré}"
echo "  Pseudos         : $PSEUDO_DIR ($NB_UPF fichiers)"
echo "  Interface       : http://${SUPRA_QE_HOST:-127.0.0.1}:${SUPRA_QE_PORT:-8765}/interface/"
echo ""

# ── 10. Démarrage de l'API ───────────────────────────────────────────────
if [[ "$MODE_CONFIG_SEUL" -eq 1 ]]; then
    success "Mode config seulement. Lance manuellement : ./DEMARRER.sh"
    exit 0
fi

if [[ "$BIN_OK" -eq 0 ]]; then
    warn "Binaires QE manquants — démarrage de l'API possible pour l'interface,"
    warn "mais les calculs ne pourront pas être lancés."
    if [[ -t 0 ]] && [[ "$MODE_YES" -eq 0 ]]; then
        read -r -p "  Démarrer l'API quand même ? (o/N) " ans
        if [[ ! "$ans" =~ ^[oOyY] ]]; then
            info "Annulé. Lance manuellement après installation QE : ./DEMARRER.sh"
            exit 0
        fi
    fi
fi

echo "  ── Démarrage de Supra-QE ─────────────────────────────────────"
echo ""

# ── 11. Test de connectivité préalable ───────────────────────────────────
info "Test de la connectivité (curl)…"
if ! command -v curl &>/dev/null; then
    warn "curl non installé — installation recommandée pour le test de santé."
fi

# ── 12. Lancement de DEMARRER.sh ────────────────────────────────────────
info "Lancement du serveur API…"
if [[ -x "$HERE/DEMARRER.sh" ]]; then
    # On capture le PID du processus DEMARRER.sh qui lance l'API
    "$HERE/DEMARRER.sh"
    DEMARRER_EXIT=$?
    if [[ "$DEMARRER_EXIT" -ne 0 ]]; then
        error "DEMARRER.sh a échoué (code $DEMARRER_EXIT)."
        error "Vérifie les logs : tail -f ${SUPRA_LOGS_DIR:-$HERE/logs}/api.log"
        exit 1
    fi
else
    error "DEMARRER.sh introuvable ou non exécutable."
    exit 1
fi

# ── 13. Vérification finale ─────────────────────────────────────────────
echo ""
info "Vérification de l'état du service…"

HOST="${SUPRA_QE_HOST:-127.0.0.1}"
PORT="${SUPRA_QE_PORT:-8765}"
API_URL="http://$HOST:$PORT"

for i in $(seq 1 15); do
    if curl -fs "$API_URL/health" >/dev/null 2>&1; then
        echo ""
        success "API Supra-QE en ligne ✓"
        echo ""
        echo "  ┌────────────────────────────────────────────────────────────┐"
        echo "  │  🧊 Supra-QE — DÉPLOIEMENT RÉUSSI ✓                      │"
        echo "  ├────────────────────────────────────────────────────────────┤"
        echo "  │  Interface : $API_URL/interface/"
        echo "  │  API root  : $API_URL/"
        echo "  │  Logs      : tail -f $HERE/logs/api.log"
        echo "  │  Manuel    : $HERE/README.md"
        echo "  └────────────────────────────────────────────────────────────┘"
        echo ""
        echo "  Prochaines étapes :"
        echo "    1. Ouvre l'interface dans ton navigateur"
        echo "    2. Importe un vc-relax.out dans le dossier inputs/<matériau>/"
        echo "    3. Configure les pseudos (1b) et choisis un workflow"
        echo "    4. Lance les calculs"
        echo ""
        exit 0
    fi
    sleep 0.5
done

echo ""
warn "L'API semble ne pas répondre après 15 tentatives."
echo "  Vérifie les logs : tail -f $HERE/logs/api.log"
echo "  Démarrage manuel : ./DEMARRER.sh"
echo ""

exit 1

#!/usr/bin/env bash
# Liste canonique des exécutables Quantum ESPRESSO utilisés par Supra-QE.
# Sourcer depuis associer_binaires_qe.sh, configurer.sh, etc.
#
# Obligatoires — WF1 classique (lancement depuis l'interface + /api/run)
SUPRA_QE_BINS_REQUIRED=(pw.x ph.x q2r.x matdyn.x)

# WF2 EPW (epw.x + Wannier90)
SUPRA_QE_BINS_EPW=(epw.x wannier90.x pw2wannier90.x)

# Optionnels — lambda / tétraèdres / surface de Fermi 3D
SUPRA_QE_BINS_OPTIONAL=(lambda.x alpha2f.x fs.x)

SUPRA_QE_BINS_ALL=(
  "${SUPRA_QE_BINS_REQUIRED[@]}"
  "${SUPRA_QE_BINS_EPW[@]}"
  "${SUPRA_QE_BINS_OPTIONAL[@]}"
)

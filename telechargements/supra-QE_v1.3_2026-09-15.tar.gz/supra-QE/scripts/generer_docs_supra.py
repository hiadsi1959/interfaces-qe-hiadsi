#!/usr/bin/env python3
"""Génère Word + PowerPoint Supra-QE v1.1 (anglais et français)."""

from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor as DocxRGB
from pptx import Presentation
from pptx.dml.color import RGBColor as PptRGB
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt as PPt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs"
AUTHOR = "Prof. S. HIADSI — LMESM / Faculté de Physique / USTO-MB, Oran, Algérie"
AUTHOR_EN = "Prof. S. HIADSI — LMESM / Faculty of Physics / USTO-MB, Oran, Algeria"
VERSION = "Supra-QE v1.1"
SITE = "https://hiadsi1959.github.io/interfaces-qe-hiadsi/"

TEAL = PptRGB(0x0D, 0x6E, 0x6E)
TEAL_DARK = PptRGB(0x08, 0x4A, 0x4A)
INK = PptRGB(0x0F, 0x1C, 0x24)
INK_SOFT = PptRGB(0x24, 0x36, 0x42)
COPPER = PptRGB(0xB8, 0x6B, 0x2E)
WHITE = PptRGB(0xFF, 0xFF, 0xFF)
MIST = PptRGB(0xF4, 0xF7, 0xF9)
CARD = PptRGB(0xFF, 0xFF, 0xFF)
WF1_ACCENT = PptRGB(0x08, 0x91, 0xB2)
WF2_ACCENT = PptRGB(0xBE, 0x18, 0x5D)


# ── Word helpers ──────────────────────────────────────────────────────────

def _set_run_font(run, size=11, bold=False, italic=False, color=None):
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.name = "Calibri"
    r = run._element.rPr.rFonts
    r.set(qn("w:eastAsia"), "Calibri")
    if color is not None:
        run.font.color.rgb = color


def add_heading(doc, text, level=1):
    h = doc.add_heading(text, level=level)
    for run in h.runs:
        run.font.color.rgb = DocxRGB(0x0D, 0x4F, 0x6C)
    return h


def add_para(doc, text, *, bold=False, italic=False, size=11, space_after=6, center=False):
    p = doc.add_paragraph()
    if center:
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(text)
    _set_run_font(run, size=size, bold=bold, italic=italic)
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.space_before = Pt(0)
    return p


def add_bullets(doc, items):
    for item in items:
        p = doc.add_paragraph(item, style="List Bullet")
        for run in p.runs:
            _set_run_font(run, size=11)


def add_table(doc, headers, rows):
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = "Table Grid"
    for i, h in enumerate(headers):
        table.rows[0].cells[i].text = h
        for p in table.rows[0].cells[i].paragraphs:
            for run in p.runs:
                _set_run_font(run, size=10, bold=True)
    for r_i, row in enumerate(rows):
        for c_i, val in enumerate(row):
            table.rows[r_i + 1].cells[c_i].text = str(val)
            for p in table.rows[r_i + 1].cells[c_i].paragraphs:
                for run in p.runs:
                    _set_run_font(run, size=10)
    doc.add_paragraph()


def add_formula_block(doc, title, equation, meaning):
    add_para(doc, title, bold=True, size=11, space_after=2, center=True)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(equation)
    _set_run_font(run, size=12, bold=True, italic=True, color=DocxRGB(0x0D, 0x4F, 0x6C))
    p.paragraph_format.space_after = Pt(2)
    add_para(doc, meaning, italic=True, size=10, space_after=12, center=True)


# ── PPT helpers ───────────────────────────────────────────────────────────

def _no_line(shape):
    shape.line.fill.background()


def _fill(shape, rgb):
    shape.fill.solid()
    shape.fill.fore_color.rgb = rgb
    _no_line(shape)


def _set_text_frame(tf, lines, *, size=18, bold=False, color=INK, align=PP_ALIGN.LEFT, italic=False):
    tf.clear()
    tf.word_wrap = True
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = line
        p.font.size = PPt(size)
        p.font.bold = bold
        p.font.italic = italic
        p.font.color.rgb = color
        p.font.name = "Calibri"
        p.alignment = align
        p.space_after = PPt(6)


def _add_textbox(slide, left, top, width, height, lines, **kwargs):
    box = slide.shapes.add_textbox(left, top, width, height)
    _set_text_frame(box.text_frame, lines, **kwargs)
    return box


def _centered_title_bar(slide, prs, title):
    bar = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, Inches(0.95))
    _fill(bar, TEAL)
    _add_textbox(
        slide, Inches(0.4), Inches(0.22), Inches(9.2), Inches(0.55),
        [title], size=24, bold=True, color=WHITE, align=PP_ALIGN.CENTER,
    )


def add_title_slide(prs, title, subtitle_lines):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    _fill(bg, TEAL)
    accent = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, Inches(6.85), prs.slide_width, Inches(0.65))
    _fill(accent, TEAL_DARK)
    _add_textbox(
        slide, Inches(0.6), Inches(2.1), Inches(8.8), Inches(1.2),
        [title], size=40, bold=True, color=WHITE, align=PP_ALIGN.CENTER,
    )
    _add_textbox(
        slide, Inches(0.8), Inches(3.5), Inches(8.4), Inches(2.5),
        subtitle_lines, size=16, color=WHITE, align=PP_ALIGN.CENTER,
    )
    return slide


def add_content_slide(prs, title, bullets, note=None):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    _fill(bg, MIST)
    _centered_title_bar(slide, prs, title)
    body = slide.shapes.add_textbox(Inches(0.7), Inches(1.3), Inches(8.6), Inches(5.0))
    tf = body.text_frame
    tf.word_wrap = True
    tf.clear()
    for i, line in enumerate(bullets):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        indent = line.startswith("  ")
        p.text = ("• " + line.strip()) if not indent else ("    " + line.strip())
        p.font.size = PPt(15 if indent else 17)
        p.font.color.rgb = INK
        p.font.name = "Calibri"
        p.space_after = PPt(8)
    if note:
        _add_textbox(
            slide, Inches(0.7), Inches(6.7), Inches(8.6), Inches(0.45),
            [note], size=12, italic=True, color=COPPER, align=PP_ALIGN.CENTER,
        )
    return slide


def add_formula_slide(prs, slide_title, formulas):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    _fill(bg, MIST)
    _centered_title_bar(slide, prs, slide_title)
    n = len(formulas)
    gap = 0.18
    top0 = 1.2
    avail = 5.8 if n > 3 else 5.5
    h = min(1.35, (avail - gap * (n - 1)) / n)
    for i, (ftitle, eq, meaning) in enumerate(formulas):
        top = top0 + i * (h + gap)
        card = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.55), Inches(top), Inches(8.9), Inches(h)
        )
        _fill(card, CARD)
        card.line.color.rgb = TEAL
        card.line.width = PPt(1.25)
        stripe = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, Inches(0.55), Inches(top), Inches(0.12), Inches(h)
        )
        _fill(stripe, TEAL)
        _add_textbox(
            slide, Inches(0.85), Inches(top + 0.08), Inches(8.3), Inches(0.32),
            [ftitle], size=13, bold=True, color=TEAL, align=PP_ALIGN.CENTER,
        )
        _add_textbox(
            slide, Inches(0.85), Inches(top + 0.38), Inches(8.3), Inches(0.42),
            [eq], size=18 if len(eq) < 70 else 15, bold=True, color=INK, align=PP_ALIGN.CENTER,
        )
        _add_textbox(
            slide, Inches(0.85), Inches(top + h - 0.38), Inches(8.3), Inches(0.32),
            [meaning], size=12, italic=True, color=INK_SOFT, align=PP_ALIGN.CENTER,
        )
    return slide


def add_two_wf_slide(prs, lang="en"):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    _fill(bg, MIST)
    title = (
        "Les deux workflows — WF1 Classique  ·  WF2 EPW"
        if lang == "fr"
        else "The two workflows — WF1 Classic  ·  WF2 EPW"
    )
    _centered_title_bar(slide, prs, title)

    if lang == "fr":
        left_lines = [
            "Méthode : DFPT + α²F → Tc analytique",
            "",
            "Chaîne",
            "  ①  vc-relax.out  (prérequis)",
            "  ②  pw.x  SCF",
            "  ③  pw.x  NSCF dense + la2F",
            "  ④  ph.x  (elph)  ← goulot",
            "  ⑤  q2r.x → matdyn / lambda",
            "",
            "Sorties",
            "  α²F(ω), λ, ω_log, ⟨ω²⟩½",
            "  Tc(μ*) McMillan / Allen–Dynes",
            "",
            "Dossier : outputs/<mat>/classic/",
            "Coût : modéré · criblage / enseignement",
        ]
        right_lines = [
            "Méthode : Wannier + Éliashberg",
            "",
            "Chaîne",
            "  ①  vc-relax.out  (prérequis)",
            "  ②  pw.x  SCF",
            "  ③  ph.x  (dvscf + dyn)",
            "  ④  pp.py → save/",
            "  ⑤  pw.x  NSCF coarse + nbnd",
            "  ⑥  epw.x  (iso / aniso)",
            "",
            "Sorties",
            "  Tc, Δ(T), Δ_k, Z(0), 2Δ₀/kBTc",
            "",
            "Dossier : outputs/<mat>/epw/",
            "Coût : élevé · publications",
        ]
        h1, h2 = "WF1 — Classique", "WF2 — EPW"
    else:
        left_lines = [
            "Method: DFPT + α²F → analytic Tc",
            "",
            "Pipeline",
            "  ①  vc-relax.out  (prerequisite)",
            "  ②  pw.x  SCF",
            "  ③  pw.x  NSCF dense + la2F",
            "  ④  ph.x  (elph)  ← bottleneck",
            "  ⑤  q2r.x → matdyn / lambda",
            "",
            "Outputs",
            "  α²F(ω), λ, ω_log, ⟨ω²⟩½",
            "  Tc(μ*) McMillan / Allen–Dynes",
            "",
            "Folder: outputs/<mat>/classic/",
            "Cost: moderate · screening / teaching",
        ]
        right_lines = [
            "Method: Wannier + Eliashberg",
            "",
            "Pipeline",
            "  ①  vc-relax.out  (prerequisite)",
            "  ②  pw.x  SCF",
            "  ③  ph.x  (dvscf + dyn)",
            "  ④  pp.py → save/",
            "  ⑤  pw.x  NSCF coarse + nbnd",
            "  ⑥  epw.x  (iso / aniso)",
            "",
            "Outputs",
            "  Tc, Δ(T), Δ_k, Z(0), 2Δ₀/kBTc",
            "",
            "Folder: outputs/<mat>/epw/",
            "Cost: high · publication-grade",
        ]
        h1, h2 = "WF1 — Classic", "WF2 — EPW"

    left = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.35), Inches(1.2), Inches(4.5), Inches(5.5))
    _fill(left, CARD)
    left.line.color.rgb = WF1_ACCENT
    left.line.width = PPt(2)
    hdr1 = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.35), Inches(1.2), Inches(4.5), Inches(0.7))
    _fill(hdr1, WF1_ACCENT)
    _add_textbox(slide, Inches(0.45), Inches(1.32), Inches(4.3), Inches(0.5),
                 [h1], size=20, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    _add_textbox(slide, Inches(0.55), Inches(2.05), Inches(4.1), Inches(4.4),
                 left_lines, size=13, color=INK, align=PP_ALIGN.LEFT)

    right = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(5.15), Inches(1.2), Inches(4.5), Inches(5.5))
    _fill(right, CARD)
    right.line.color.rgb = WF2_ACCENT
    right.line.width = PPt(2)
    hdr2 = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(5.15), Inches(1.2), Inches(4.5), Inches(0.7))
    _fill(hdr2, WF2_ACCENT)
    _add_textbox(slide, Inches(5.25), Inches(1.32), Inches(4.3), Inches(0.5),
                 [h2], size=20, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    _add_textbox(slide, Inches(5.35), Inches(2.05), Inches(4.1), Inches(4.4),
                 right_lines, size=13, color=INK, align=PP_ALIGN.LEFT)
    return slide


def add_wf_detail_slide(prs, which, lang="en"):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    _fill(bg, MIST)

    if which == 1:
        accent = WF1_ACCENT
        if lang == "fr":
            title = "WF1 — Chaîne classique (détail)"
            steps = [
                ("01", "Prérequis", "<matériau>.vc-relax.out avec structure extractible"),
                ("02", "SCF  ·  pw.x", "État fondamental métallique (smearing mv/mp)"),
                ("03", "NSCF dense  ·  pw.x", "Grille k dense + la2F pour la surface de Fermi"),
                ("04", "Phonons + e–p  ·  ph.x", "DFPT sur grille q — ~70–90 % du temps wall-clock"),
                ("05", "Post-traitement", "q2r.x → IFC ; matdyn.x / lambda.x → α²F, λ, ω_log"),
                ("06", "Tc dans Résultats", "McMillan & Allen–Dynes pour une série de μ*"),
            ]
            note = "Règle : grille k ≫ grille q, ratio entier (≥ 4 conseillé). Pseudos NC uniquement."
        else:
            title = "WF1 — Classic pipeline (detail)"
            steps = [
                ("01", "Prerequisite", "<material>.vc-relax.out with extractable structure"),
                ("02", "SCF  ·  pw.x", "Metallic ground state (smearing mv/mp)"),
                ("03", "NSCF dense  ·  pw.x", "Dense k-grid + la2F for Fermi surface"),
                ("04", "Phonons + e–ph  ·  ph.x", "DFPT on q-grid — usually 70–90 % of wall time"),
                ("05", "Post-process", "q2r.x → IFCs ; matdyn.x / lambda.x → α²F, λ, ω_log"),
                ("06", "Tc in Results", "McMillan & Allen–Dynes evaluated for a μ* series"),
            ]
            note = "Rule: k-grid ≫ q-grid with integer ratio (recommend ≥ 4). NC pseudos only."
    else:
        accent = WF2_ACCENT
        if lang == "fr":
            title = "WF2 — Chaîne EPW (détail)"
            steps = [
                ("01", "Prérequis", "<matériau>.vc-relax.out avec structure extractible"),
                ("02", "SCF  ·  pw.x", "Même SCF métallique comme point de départ"),
                ("03", "ph.x (avant NSCF)", "dvscf + matrices dynamiques — ne pas écraser outdir"),
                ("04", "save/  ·  pp.py", "Regrouper *.dyn* et *.dvscf* pour EPW (dvscf_dir)"),
                ("05", "NSCF coarse  ·  pw.x", "Grille k modeste + nbnd élevé pour Wannier"),
                ("06", "epw.x", "Wannier → interpolation → Éliashberg → Tc, Δ(T)"),
            ]
            note = "Valider λ et ω_log avec WF1 avant EPW. nk/nq d’epw.x = grilles NSCF / ph."
        else:
            title = "WF2 — EPW pipeline (detail)"
            steps = [
                ("01", "Prerequisite", "<material>.vc-relax.out with extractable structure"),
                ("02", "SCF  ·  pw.x", "Same metallic SCF as starting point"),
                ("03", "ph.x (before NSCF)", "dvscf + dynamical matrices — do not overwrite outdir"),
                ("04", "save/  ·  pp.py", "Gather *.dyn* and *.dvscf* for EPW (dvscf_dir)"),
                ("05", "NSCF coarse  ·  pw.x", "Uniform modest k-grid + high nbnd for Wannier"),
                ("06", "epw.x", "Wannierize → interpolate → solve Eliashberg → Tc, Δ(T)"),
            ]
            note = "Validate λ & ω_log with WF1 before EPW. nk/nq of epw.x must match NSCF / ph grids."

    _centered_title_bar(slide, prs, title)
    strip = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, Inches(0.95), prs.slide_width, Inches(0.08))
    _fill(strip, accent)

    for i, (num, label, desc) in enumerate(steps):
        top = 1.25 + i * 0.82
        badge = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(0.55), Inches(top + 0.08), Inches(0.55), Inches(0.55))
        _fill(badge, accent)
        _add_textbox(slide, Inches(0.55), Inches(top + 0.16), Inches(0.55), Inches(0.4),
                     [num], size=12, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
        card = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE, Inches(1.3), Inches(top), Inches(8.15), Inches(0.72)
        )
        _fill(card, CARD)
        card.line.color.rgb = accent
        card.line.width = PPt(1)
        _add_textbox(slide, Inches(1.5), Inches(top + 0.06), Inches(7.8), Inches(0.28),
                     [label], size=14, bold=True, color=accent, align=PP_ALIGN.LEFT)
        _add_textbox(slide, Inches(1.5), Inches(top + 0.34), Inches(7.8), Inches(0.32),
                     [desc], size=13, color=INK, align=PP_ALIGN.LEFT)

    _add_textbox(slide, Inches(0.55), Inches(6.95), Inches(8.9), Inches(0.35),
                 [note], size=12, italic=True, color=COPPER, align=PP_ALIGN.CENTER)
    return slide


# ── Word builders ─────────────────────────────────────────────────────────

def build_word(path: Path, lang: str = "en") -> None:
    doc = Document()
    for section in doc.sections:
        section.top_margin = Cm(2)
        section.bottom_margin = Cm(2)
        section.left_margin = Cm(2.2)
        section.right_margin = Cm(2.2)

    fr = lang == "fr"
    author = AUTHOR if fr else AUTHOR_EN

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = title.add_run(
        f"{VERSION}\n"
        + ("Température critique supraconductrice\navec Quantum ESPRESSO"
           if fr else "Superconducting Critical Temperature\nwith Quantum ESPRESSO")
    )
    _set_run_font(r, size=18, bold=True, color=DocxRGB(0x0D, 0x4F, 0x6C))

    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = sub.add_run(
        ("Guide d’utilisation et fondements physiques\n" if fr else "User guide & physical background\n")
        + f"{author}\n{SITE}"
    )
    _set_run_font(r, size=11, italic=True)

    nb = doc.add_paragraph()
    nb.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = nb.add_run(
        "N.B. — "
        + ("Si vous utilisez cette interface en recherche ou en enseignement, citez l’auteur : "
           "Prof. S. HIADSI, LMESM / Faculté de Physique, USTO-MB, Oran, Algérie."
           if fr else
           "If you use this interface in research or teaching, please cite the author: "
           "Prof. S. HIADSI, LMESM / Faculty of Physics, USTO-MB, Oran, Algeria.")
    )
    _set_run_font(r, size=10, italic=True, color=DocxRGB(0x6B, 0x3A, 0x1A))

    if fr:
        add_heading(doc, "1. Objet de l’interface", 1)
        add_para(
            doc,
            "Supra-QE est un module web autonome (HTML + API Flask) pour calculer la température "
            "critique supraconductrice conventionnelle Tc à partir du couplage électron–phonon "
            "avec Quantum ESPRESSO (QE). Les calculs s’exécutent localement sur le PC du chercheur ; "
            "le site web ne fait que diffuser l’archive.",
        )
        add_para(doc, "Deux workflows indépendants écrivent dans classic/ et epw/ :")
        add_bullets(doc, [
            "WF1 — Classique : phonons DFPT + α²F(ω) → λ, ω_log → Tc (McMillan / Allen–Dynes).",
            "WF2 — EPW : interpolation Wannier + Éliashberg iso/anisotrope → Tc, Δ(T), anisotropie.",
        ])

        add_heading(doc, "2. Fondements physiques", 1)
        add_heading(doc, "2.1 Supraconductivité médiée par les phonons", 2)
        add_para(
            doc,
            "Dans la théorie BCS / Migdal–Éliashberg conventionnelle, l’appariement est médié par "
            "les vibrations du réseau. La grandeur spectrale centrale est la fonction d’Éliashberg "
            "α²F(ω), qui pondère la densité d’états phononique par les éléments de matrice "
            "électron–phonon près de la surface de Fermi.",
        )
        add_heading(doc, "2.2 Formules — moments de couplage", 2)
        add_formula_block(
            doc,
            "Constante de couplage électron–phonon  λ",
            "λ  =  2  ∫₀^∞  [ α²F(ω) / ω ]  dω",
            "Mesure sans dimension de la force d’appariement à partir de α²F(ω).",
        )
        add_formula_block(
            doc,
            "Fréquence phononique logarithmique moyenne  ω_log",
            "ω_log  =  exp{ (2/λ)  ∫₀^∞  [ α²F(ω) ln(ω) / ω ]  dω }",
            "Échelle d’énergie phononique caractéristique entrant dans le préfacteur de Tc.",
        )
        add_formula_block(
            doc,
            "Moment second  ⟨ω²⟩½  (Allen–Dynes)",
            "⟨ω²⟩½  =  [ (2/λ)  ∫₀^∞  ω α²F(ω)  dω ]½",
            "Intervient dans les facteurs de couplage fort / forme spectrale f₁ et f₂.",
        )
        add_formula_block(
            doc,
            "Pseudopotentiel de Coulomb  μ*",
            "μ*  ≈  0.10 – 0.15     (défaut Supra-QE :  0.10)",
            "Répulsion coulombienne écrantée (Morel–Anderson) ; l’onglet Résultats balaye plusieurs μ*.",
        )

        add_heading(doc, "2.3 Formules — température critique Tc", 2)
        add_formula_block(
            doc,
            "Formule de McMillan (1968)",
            "Tc  =  (ω_log / 1.20)  ·  exp{ − 1.04(1+λ) / [ λ − μ*(1 + 0.62 λ) ] }",
            "Approximation analytique de la théorie d’Éliashberg pour un couplage modéré.",
        )
        add_formula_block(
            doc,
            "Formule d’Allen–Dynes (1975)",
            "Tc^(AD)  =  f₁(λ, μ*)  ·  f₂(λ, μ*, ω₂/ω_log)  ·  Tc^(McMillan)",
            "Corrections de couplage fort (f₁) et de forme spectrale (f₂).",
        )
        add_formula_block(
            doc,
            "Gap d’Éliashberg (EPW / WF2)",
            "Δ(iωₙ) ,  Z(iωₙ)   →   Tc ,  Δ(T) ,  Δ_k ,  2Δ₀ / k_B Tc",
            "Résolution complète sur grilles fines ; isotrope (liso) ou anisotrope (laniso).",
        )

        add_heading(doc, "3. Les deux workflows de calcul", 1)
        add_heading(doc, "3.1 WF1 — Chaîne classique", 2)
        add_para(
            doc,
            "vc-relax (prérequis) → pw.x SCF → pw.x NSCF dense (la2F) → ph.x (elph) "
            "→ q2r.x → matdyn.x / lambda.x → α²F, λ, ω_log, Tc(μ*).",
        )
        add_table(doc, ["Étape", "Code", "Rôle"], [
            ["0", "vc-relax.out", "Structure relaxée (seul fichier obligatoire)"],
            ["1", "pw.x SCF", "État fondamental métallique (smearing)"],
            ["2", "pw.x NSCF", "Grille k dense pour la surface de Fermi + la2F"],
            ["3", "ph.x", "Phonons DFPT + matrices e–p (goulot d’étranglement)"],
            ["4", "q2r.x", "Matrices dynamiques → IFC en espace réel"],
            ["5", "matdyn / lambda", "DOS phononique, α²F(ω), λ, ω_log"],
        ])

        add_heading(doc, "3.2 WF2 — Chaîne EPW", 2)
        add_para(
            doc,
            "vc-relax → pw.x SCF → ph.x (dvscf+dyn) → [pp.py → save/] "
            "→ pw.x NSCF coarse (nbnd élevé) → epw.x → Tc, Δ(T), anisotropie.",
        )
        add_para(
            doc,
            "Important : ph.x doit tourner avant le NSCF coarse (doc. EPW), car le NSCF "
            "écrase les fonctions d’onde dans outdir. Les matrices dynamiques et dvscf sont "
            "regroupées dans save/ avec le script pp.py d’EPW.",
        )

        add_heading(doc, "3.3 Classique vs EPW", 2)
        add_table(doc, ["Aspect", "Classique (WF1)", "EPW (WF2)"], [
            ["Coût", "Modéré", "Élevé (Wannier + Éliashberg)"],
            ["NSCF", "Très dense (ex. 24³)", "Coarse + nbnd élevé"],
            ["Qualité Tc", "Bonne (analytique)", "Excellente (Éliashberg)"],
            ["Gap Δ(T)", "Non", "Oui (iso / aniso)"],
            ["Idéal pour", "Criblage / enseignement", "Publications haut niveau"],
        ])

        add_heading(doc, "4. Utilisation de l’interface", 1)
        add_heading(doc, "4.1 Installation et démarrage", 2)
        add_para(doc, "Sous Ubuntu avec Quantum ESPRESSO 7.x déjà installé :", space_after=4)
        for cmd in [
            "tar -xzf supra-QE_v1.1_2026-08-27.tar.gz",
            "cd supra-QE",
            "./configurer.sh --qe-bin /chemin/vers/qe/bin",
            "./DEMARRER.sh",
            "→ http://127.0.0.1:8765/interface/   (jamais en file://)",
        ]:
            add_para(doc, cmd, italic=True, size=10, space_after=2)
        add_para(
            doc,
            "Installation one-shot : ./INSTALL_AUTOMATIQUE.sh -y --qe-bin /chemin/vers/qe/bin. "
            "Si epw.x manque : ./scripts/installer_epw.sh puis ./scripts/associer_binaires_qe.sh.",
        )

        add_heading(doc, "4.2 Onglets de l’interface", 2)
        add_table(doc, ["Onglet", "Contenu"], [
            ["Guide", "Protocole, chaînes WF1/WF2, ordres de grandeur wall-clock"],
            ["Calculs", "Matériau → pseudos NC → prérequis → WF → paramètres → lancement"],
            ["Résultats", "Quatre modules : scalaires, spectres 2D, anisotropie, fichiers bruts"],
            ["Aide", "Comparaison des méthodes, formules, règles"],
        ])

        add_heading(doc, "4.3 Règles imposées par l’interface", 2)
        add_bullets(doc, [
            "Pseudos .UPF Norm-Conserving uniquement (PseudoDojo / SG15 / ONCV). USPP et PAW refusés.",
            "Seul <matériau>.vc-relax.out (structure extractible) est obligatoire dans inputs/<matériau>/.",
            "Grille k (NSCF) ≫ grille q (phonons), ratio entier (≥ 2 ; ≥ 4 conseillé).",
            "Chaque étape est bloquée tant que JOB DONE et les fichiers amont manquent.",
            "μ* par défaut 0.10 ; Résultats recalcule Tc pour une série de μ*.",
        ])

        add_heading(doc, "4.4 Exploration des résultats", 2)
        add_para(
            doc,
            "Après le calcul (ou copie des .out dans outputs/<mat>/classic/ et …/epw/), "
            "cliquer « Explorer tous les résultats ». Grandeurs typiques :",
        )
        add_table(doc, ["Grandeur", "Classique", "EPW"], [
            ["λ, ω_log, ⟨ω²⟩½", "α²F / matdyn / lambda", "α²F / epw.out"],
            ["Tc(μ*)", "McMillan + Allen–Dynes", "Idem + Tc du code"],
            ["α²F(ω), λ(ω), F(ω)", "a2F.dat, phonon.dos", "*.a2f, *.phdos"],
            ["Δ(T), Δ_k, Z(0)", "—", "epw.out, imag_aniso_*"],
        ])
        add_para(doc, "Exports : CSV, LaTeX et rapport depuis l’onglet Résultats.")

        add_heading(doc, "5. Ordres de grandeur — temps wall-clock", 1)
        add_para(
            doc,
            "Le goulot est presque toujours ph.x (WF1) puis epw.x (WF2). Grilles de référence : "
            "SCF 8³, NSCF 24³, q 4³. Temps indicatifs sur PC fort (ex. i9-14900K, 64 Go+), "
            "nprocs ≈ 16–24 :",
        )
        add_table(doc, ["Complexité", "Exemple", "WF1", "WF2"], [
            ["Très simple", "Nb, Al (1 at.)", "1–4 h", "4–12 h"],
            ["Simple", "Pb, Ta", "4–12 h", "1–2 j"],
            ["Moyen", "Binaire 2–4 at.", "0,5–2 j", "2–5 j"],
            ["Complexe", "8–20 at.", "plusieurs j – 1–2 sem.", "1–3+ sem."],
        ])
        add_para(
            doc,
            "Toujours valider WF1 avant d’ouvrir EPW. Test rapide non publiable : nq = 2³. "
            "Annuler un job long : bouton « Annuler le calcul ».",
        )

        add_heading(doc, "6. Citation et références", 1)
        add_para(doc, "Citez l’auteur de l’interface dans toute publication ou support d’enseignement :")
        add_para(doc, author, bold=True)
        add_para(doc, f"Site : {SITE}", italic=True)
        add_para(doc, "Références scientifiques sélectionnées :", space_after=4)
        add_bullets(doc, [
            "McMillan, Phys. Rev. 167, 331 (1968).",
            "Allen & Dynes, Phys. Rev. B 12, 905 (1975).",
            "Giannozzi et al., J. Phys.: Condens. Matter 21, 395502 (2009) — Quantum ESPRESSO.",
            "Poncé et al., Comput. Phys. Commun. 209, 116 (2016) — EPW.",
            "PseudoDojo, Comp. Mat. Sci. 154, 35 (2018).",
        ])
        footer = doc.add_paragraph()
        footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = footer.add_run(
            "\n— Fin du document —\nLibre pour la recherche et l’enseignement ; "
            "toute modification du code nécessite une collaboration avec l’auteur."
        )
        _set_run_font(r, size=9, italic=True, color=DocxRGB(0x55, 0x55, 0x55))
    else:
        # English (same structure as before, with formula blocks)
        add_heading(doc, "1. Purpose of the interface", 1)
        add_para(
            doc,
            "Supra-QE is a standalone web module (HTML + Flask API) for computing the "
            "conventional superconducting critical temperature Tc from electron–phonon coupling "
            "with Quantum ESPRESSO (QE). Calculations run locally on the researcher’s computer; "
            "the website only distributes the archive.",
        )
        add_para(doc, "Two independent workflows write into separate folders classic/ and epw/:")
        add_bullets(doc, [
            "WF1 — Classic: DFPT phonons + α²F(ω) → λ, ω_log → Tc (McMillan / Allen–Dynes).",
            "WF2 — EPW: Wannier interpolation + isotropic/anisotropic Eliashberg → Tc, Δ(T), anisotropy.",
        ])

        add_heading(doc, "2. Physical background", 1)
        add_heading(doc, "2.1 Electron–phonon mediated superconductivity", 2)
        add_para(
            doc,
            "In conventional BCS / Migdal–Eliashberg theory, pairing is mediated by lattice vibrations. "
            "The central spectral quantity is the Eliashberg function α²F(ω), which weights the phonon "
            "density of states by the electron–phonon matrix elements near the Fermi surface.",
        )
        add_heading(doc, "2.2 Formulas — coupling moments", 2)
        add_formula_block(doc, "Electron–phonon coupling strength  λ",
                          "λ  =  2  ∫₀^∞  [ α²F(ω) / ω ]  dω",
                          "Dimensionless measure of pairing strength from α²F(ω).")
        add_formula_block(doc, "Logarithmic average phonon frequency  ω_log",
                          "ω_log  =  exp{ (2/λ)  ∫₀^∞  [ α²F(ω) ln(ω) / ω ]  dω }",
                          "Characteristic phonon energy scale entering the prefactor of Tc formulas.")
        add_formula_block(doc, "Second moment  ⟨ω²⟩½  (Allen–Dynes)",
                          "⟨ω²⟩½  =  [ (2/λ)  ∫₀^∞  ω α²F(ω)  dω ]½",
                          "Used in the strong-coupling / spectral-shape factors f₁ and f₂.")
        add_formula_block(doc, "Coulomb pseudopotential  μ*",
                          "μ*  ≈  0.10 – 0.15     (default in Supra-QE:  0.10)",
                          "Morel–Anderson screened Coulomb repulsion; Results tab scans several μ*.")

        add_heading(doc, "2.3 Formulas — critical temperature Tc", 2)
        add_formula_block(doc, "McMillan formula (1968)",
                          "Tc  =  (ω_log / 1.20)  ·  exp{ − 1.04(1+λ) / [ λ − μ*(1 + 0.62 λ) ] }",
                          "Analytic approximation to Eliashberg theory for moderate coupling.")
        add_formula_block(doc, "Allen–Dynes formula (1975)",
                          "Tc^(AD)  =  f₁(λ, μ*)  ·  f₂(λ, μ*, ω₂/ω_log)  ·  Tc^(McMillan)",
                          "Strong-coupling (f₁) and shape (f₂) corrections.")
        add_formula_block(doc, "Eliashberg gap (EPW / WF2)",
                          "Δ(iωₙ) ,  Z(iωₙ)   →   Tc ,  Δ(T) ,  Δ_k ,  2Δ₀ / k_B Tc",
                          "Full solution on fine grids; isotropic (liso) or anisotropic (laniso).")

        add_heading(doc, "3. The two computational workflows", 1)
        add_heading(doc, "3.1 WF1 — Classic chain", 2)
        add_para(doc, "vc-relax → pw.x SCF → pw.x NSCF dense (la2F) → ph.x (elph) "
                      "→ q2r.x → matdyn.x / lambda.x → α²F, λ, ω_log, Tc(μ*).")
        add_table(doc, ["Step", "Code", "Role"], [
            ["0", "vc-relax.out", "Relaxed structure (only mandatory input file)"],
            ["1", "pw.x SCF", "Metallic ground state (smearing)"],
            ["2", "pw.x NSCF", "Dense k-grid for Fermi surface + la2F"],
            ["3", "ph.x", "DFPT phonons + e–ph matrix elements (bottleneck)"],
            ["4", "q2r.x", "Dynamical matrices → real-space IFCs"],
            ["5", "matdyn / lambda", "Phonon DOS, α²F(ω), λ, ω_log"],
        ])
        add_heading(doc, "3.2 WF2 — EPW chain", 2)
        add_para(doc, "vc-relax → pw.x SCF → ph.x (dvscf+dyn) → [pp.py → save/] "
                      "→ pw.x NSCF coarse (high nbnd) → epw.x → Tc, Δ(T), anisotropy.")
        add_para(doc, "Important: ph.x must run before the coarse NSCF. Dynamical matrices and "
                      "dvscf files are gathered into save/ with EPW’s pp.py script.")
        add_heading(doc, "3.3 Classic vs EPW", 2)
        add_table(doc, ["Aspect", "Classic (WF1)", "EPW (WF2)"], [
            ["Cost", "Moderate", "High (Wannier + Eliashberg)"],
            ["NSCF", "Very dense (e.g. 24³)", "Coarse + high nbnd"],
            ["Tc quality", "Good (analytic)", "Excellent (Eliashberg)"],
            ["Gap Δ(T)", "No", "Yes (iso / aniso)"],
            ["Best for", "Screening / teaching", "High-level publications"],
        ])

        add_heading(doc, "4. How to use the interface", 1)
        add_heading(doc, "4.1 Installation & start", 2)
        add_para(doc, "On Ubuntu with Quantum ESPRESSO 7.x already installed:", space_after=4)
        for cmd in [
            "tar -xzf supra-QE_v1.1_2026-08-27.tar.gz",
            "cd supra-QE",
            "./configurer.sh --qe-bin /path/to/qe/bin",
            "./DEMARRER.sh",
            "→ http://127.0.0.1:8765/interface/   (never as file://)",
        ]:
            add_para(doc, cmd, italic=True, size=10, space_after=2)
        add_para(doc, "One-shot: ./INSTALL_AUTOMATIQUE.sh -y --qe-bin /path/to/qe/bin. "
                      "If epw.x is missing: ./scripts/installer_epw.sh then ./scripts/associer_binaires_qe.sh.")

        add_heading(doc, "4.2 UI tabs", 2)
        add_table(doc, ["Tab", "Content"], [
            ["Guide", "Protocol, WF1/WF2 pipelines, wall-clock estimates"],
            ["Calculations", "Material → NC pseudos → prerequisites → WF → parameters → run"],
            ["Results", "Four modules: scalars, 2D spectra, Fermi anisotropy, raw files"],
            ["Help", "Method comparison, formulas, rules"],
        ])
        add_heading(doc, "4.3 Mandatory rules enforced by the UI", 2)
        add_bullets(doc, [
            "Norm-Conserving .UPF only (PseudoDojo / SG15 / ONCV). USPP and PAW are rejected.",
            "Only <material>.vc-relax.out with extractable structure under inputs/<material>/.",
            "k-grid (NSCF) ≫ q-grid (phonons), integer ratio (≥ 2; ≥ 4 recommended).",
            "Each step gated by JOB DONE + required intermediate files.",
            "μ* default 0.10; Results recomputes Tc for a μ* series.",
        ])
        add_heading(doc, "4.4 Exploring results", 2)
        add_para(doc, "After the run, click “Explore all results”. Typical quantities:")
        add_table(doc, ["Quantity", "Classic", "EPW"], [
            ["λ, ω_log, ⟨ω²⟩½", "α²F / matdyn / lambda", "α²F / epw.out"],
            ["Tc(μ*)", "McMillan + Allen–Dynes", "Same + code Tc"],
            ["α²F(ω), λ(ω), F(ω)", "a2F.dat, phonon.dos", "*.a2f, *.phdos"],
            ["Δ(T), Δ_k, Z(0)", "—", "epw.out, imag_aniso_*"],
        ])
        add_para(doc, "Exports: CSV, LaTeX, and report from the Results tab.")

        add_heading(doc, "5. Wall-clock orders of magnitude", 1)
        add_para(doc, "Bottleneck: ph.x (WF1) then epw.x (WF2). Reference grids SCF 8³, NSCF 24³, q 4³. "
                      "Indicative times on a strong PC (e.g. i9-14900K, 64 GB+), nprocs ≈ 16–24:")
        add_table(doc, ["Complexity", "Example", "WF1", "WF2"], [
            ["Very simple", "Nb, Al (1 at.)", "1–4 h", "4–12 h"],
            ["Simple", "Pb, Ta", "4–12 h", "1–2 d"],
            ["Medium", "Binary 2–4 at.", "0.5–2 d", "2–5 d"],
            ["Complex", "8–20 at.", "several d – 1–2 wk", "1–3+ wk"],
        ])
        add_para(doc, "Always validate WF1 before EPW. Smoke test: nq = 2³. Cancel: UI button.")

        add_heading(doc, "6. Citation & references", 1)
        add_para(doc, "Please cite the interface author in any publication or teaching material:")
        add_para(doc, author, bold=True)
        add_para(doc, f"Website: {SITE}", italic=True)
        add_para(doc, "Selected scientific references:", space_after=4)
        add_bullets(doc, [
            "McMillan, Phys. Rev. 167, 331 (1968).",
            "Allen & Dynes, Phys. Rev. B 12, 905 (1975).",
            "Giannozzi et al., J. Phys.: Condens. Matter 21, 395502 (2009) — Quantum ESPRESSO.",
            "Poncé et al., Comput. Phys. Commun. 209, 116 (2016) — EPW.",
            "PseudoDojo, Comp. Mat. Sci. 154, 35 (2018).",
        ])
        footer = doc.add_paragraph()
        footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = footer.add_run(
            "\n— End of document —\nFree to use for research & teaching; "
            "code modifications require collaboration with the author."
        )
        _set_run_font(r, size=9, italic=True, color=DocxRGB(0x55, 0x55, 0x55))

    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(path)


# ── PPT builders ──────────────────────────────────────────────────────────

def build_pptx(path: Path, lang: str = "en") -> None:
    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(7.5)
    fr = lang == "fr"
    author = AUTHOR if fr else AUTHOR_EN

    add_title_slide(
        prs,
        "Supra-QE v1.1",
        [
            "Calcul de Tc avec Quantum ESPRESSO" if fr else "Computing Tc with Quantum ESPRESSO",
            "Utilisation et fondements physiques" if fr else "Usage & physical background",
            "",
            author,
            SITE,
        ],
    )

    if fr:
        add_content_slide(prs, "N.B. — Citation", [
            "Si vous utilisez cette interface en recherche ou en enseignement, citez :",
            "  Prof. S. HIADSI — LMESM / Faculté de Physique, USTO-MB, Oran, Algérie",
            "Libre pour la recherche et l’enseignement ; toute modification du code "
            "nécessite une collaboration avec l’auteur.",
        ])
        add_content_slide(prs, "Qu’est-ce que Supra-QE ?", [
            "Interface web locale + API Flask pour la supraconductivité conventionnelle",
            "Couplage électron–phonon avec Quantum ESPRESSO 7.x / 7.5+",
            "Deux voies indépendantes → dossiers classic/ et epw/",
            "  WF1 Classique — α²F(ω) → λ, ω_log → Tc (McMillan / Allen–Dynes)",
            "  WF2 EPW — Wannier + Éliashberg → Tc, Δ(T), anisotropie",
            "Démarrage : ./DEMARRER.sh → http://127.0.0.1:8765/interface/  (pas file://)",
        ])
        add_formula_slide(prs, "Formules physiques — moments de couplage", [
            ("Constante de couplage électron–phonon  λ",
             "λ  =  2  ∫₀^∞  [ α²F(ω) / ω ]  dω",
             "Mesure sans dimension de la force d’appariement à partir de α²F(ω)."),
            ("Fréquence phononique logarithmique moyenne  ω_log",
             "ω_log  =  exp{ (2/λ)  ∫₀^∞  [ α²F(ω) ln(ω) / ω ]  dω }",
             "Échelle d’énergie phononique caractéristique dans le préfacteur de Tc."),
            ("Moment second  ⟨ω²⟩½  (Allen–Dynes)",
             "⟨ω²⟩½  =  [ (2/λ)  ∫₀^∞  ω α²F(ω)  dω ]½",
             "Entre dans les facteurs de couplage fort / forme spectrale f₁ et f₂."),
            ("Pseudopotentiel de Coulomb  μ*",
             "μ*  ≈  0.10 – 0.15     (défaut Supra-QE :  0.10)",
             "Répulsion coulombienne écrantée (Morel–Anderson) ; balayage μ* dans Résultats."),
        ])
        add_formula_slide(prs, "Formules physiques — température critique Tc", [
            ("Formule de McMillan (1968)",
             "Tc  =  (ω_log / 1.20)  ·  exp{ − 1.04(1+λ) / [ λ − μ*(1 + 0.62 λ) ] }",
             "Approximation analytique de la théorie d’Éliashberg (couplage modéré)."),
            ("Formule d’Allen–Dynes (1975)",
             "Tc^(AD)  =  f₁(λ, μ*)  ·  f₂(λ, μ*, ω₂/ω_log)  ·  Tc^(McMillan)",
             "Corrections de couplage fort (f₁) et de forme spectrale (f₂)."),
            ("Gap d’Éliashberg (EPW / WF2)",
             "Δ(iωₙ) ,  Z(iωₙ)   →   Tc ,  Δ(T) ,  Δ_k ,  2Δ₀ / k_B Tc",
             "Résolution complète ; isotrope (liso) ou anisotrope (laniso)."),
        ])
    else:
        add_content_slide(prs, "N.B. — Citation", [
            "If you use this interface in research or teaching, please cite:",
            "  Prof. S. HIADSI — LMESM / Faculty of Physics, USTO-MB, Oran, Algeria",
            "Free for research & teaching; code changes require collaboration with the author.",
        ])
        add_content_slide(prs, "What is Supra-QE?", [
            "Local web UI + Flask API for conventional (phonon-mediated) superconductivity",
            "Electron–phonon coupling with Quantum ESPRESSO 7.x / 7.5+",
            "Two independent routes → folders classic/ and epw/",
            "  WF1 Classic — α²F(ω) → λ, ω_log → Tc (McMillan / Allen–Dynes)",
            "  WF2 EPW — Wannier + Eliashberg → Tc, Δ(T), anisotropy",
            "Start: ./DEMARRER.sh → http://127.0.0.1:8765/interface/  (not file://)",
        ])
        add_formula_slide(prs, "Physical formulas — coupling moments", [
            ("Electron–phonon coupling strength  λ",
             "λ  =  2  ∫₀^∞  [ α²F(ω) / ω ]  dω",
             "Dimensionless measure of pairing strength from the Eliashberg function α²F(ω)."),
            ("Logarithmic average phonon frequency  ω_log",
             "ω_log  =  exp{ (2/λ)  ∫₀^∞  [ α²F(ω) ln(ω) / ω ]  dω }",
             "Characteristic phonon energy scale entering the prefactor of Tc formulas."),
            ("Second moment  ⟨ω²⟩½  (Allen–Dynes)",
             "⟨ω²⟩½  =  [ (2/λ)  ∫₀^∞  ω α²F(ω)  dω ]½",
             "Used in the strong-coupling / spectral-shape factors f₁ and f₂."),
            ("Coulomb pseudopotential  μ*",
             "μ*  ≈  0.10 – 0.15     (default in Supra-QE:  0.10)",
             "Morel–Anderson screened Coulomb repulsion; Results tab scans several μ*."),
        ])
        add_formula_slide(prs, "Physical formulas — critical temperature Tc", [
            ("McMillan formula (1968)",
             "Tc  =  (ω_log / 1.20)  ·  exp{ − 1.04(1+λ) / [ λ − μ*(1 + 0.62 λ) ] }",
             "Analytic approximation to Eliashberg theory for moderate coupling."),
            ("Allen–Dynes formula (1975)",
             "Tc^(AD)  =  f₁(λ, μ*)  ·  f₂(λ, μ*, ω₂/ω_log)  ·  Tc^(McMillan)",
             "Strong-coupling (f₁) and shape (f₂) corrections; preferred when ⟨ω²⟩½ is known."),
            ("Eliashberg gap (EPW / WF2)",
             "Δ(iωₙ) ,  Z(iωₙ)   →   Tc ,  Δ(T) ,  Δ_k ,  2Δ₀ / k_B Tc",
             "Full solution on fine grids; isotropic (liso) or anisotropic (laniso)."),
        ])

    add_two_wf_slide(prs, lang=lang)
    add_wf_detail_slide(prs, 1, lang=lang)
    add_wf_detail_slide(prs, 2, lang=lang)

    if fr:
        add_content_slide(prs, "WF1 vs WF2 — quand utiliser lequel ?", [
            "WF1 Classique — premier contrôle de λ / ω_log ; enseignement ; criblage",
            "WF2 EPW — lorsque Δ(T), l’anisotropie ou Éliashberg publication sont requis",
            "Toujours valider WF1 avant d’ouvrir EPW",
            "WF1 : NSCF très dense (ex. 24³) · q modeste (4³)",
            "WF2 : ph.x avant NSCF coarse · nbnd élevé · nkf/nqf fins (ex. 40³)",
            "EPW est sensible aux fenêtres Wannier (dis_win / dis_froz)",
        ], note="Arbres de sortie séparés : classic/ et epw/ — jamais mélangés.")
        add_content_slide(prs, "Démarrage", [
            "tar -xzf supra-QE_v1.1_2026-08-27.tar.gz && cd supra-QE",
            "./configurer.sh --qe-bin /chemin/vers/qe/bin",
            "  → associe pw.x, ph.x, epw.x dans supra-QE/bin/",
            "./DEMARRER.sh  →  http://127.0.0.1:8765/interface/",
            "One-shot : ./INSTALL_AUTOMATIQUE.sh -y --qe-bin …",
            "Si epw.x manque : ./scripts/installer_epw.sh",
        ])
        add_content_slide(prs, "Flux UI (onglet Calculs)", [
            "1. Valider le nom du matériau",
            "2. Fournir des .UPF Norm-Conserving (PseudoDojo / SG15 / ONCV)",
            "3. Placer <mat>.vc-relax.out dans inputs/<mat>/",
            "4. Choisir WF1 Classique ou WF2 EPW",
            "5. Vérifier k ≫ q (ratio entier), μ*, fenêtres EPW",
            "6. Générer les inputs → lancer une étape ou tout le workflow",
            "Le panneau d’enchaînement suit JOB DONE ; Annuler stoppe un job long",
        ])
        add_content_slide(prs, "Explorateur de résultats", [
            "Module 1 — Scalaires : λ, ω_log, ⟨ω²⟩½, N(EF), Tc(μ*)",
            "Module 2 — Spectres : α²F(ω), λ(ω), F(ω), Δ(T)",
            "Module 3 — Surface de Fermi & anisotropie (surtout EPW)",
            "Module 4 — Inventaire des fichiers bruts + lecture",
            "Exports : CSV · LaTeX · rapport",
        ])
        add_content_slide(prs, "Règles imposées par l’interface", [
            "Pseudos Norm-Conserving uniquement — USPP / PAW refusés pour e–p",
            "Seul vc-relax.out est obligatoire ; chaque WF relance son SCF",
            "Grille k ≫ grille q avec ratio entier (≥ 4 conseillé)",
            "Étapes verrouillées tant que JOB DONE + fichiers amont manquent",
            "LAN (0.0.0.0) exige SUPRA_ALLOW_LAN + SUPRA_API_TOKEN",
        ])
        add_content_slide(prs, "Temps wall-clock (ordres de grandeur)", [
            "PC fort (ex. i9-14900K, 64 Go+), nprocs ≈ 16–24",
            "  Nb / Al (1 at.) :   WF1 1–4 h   ·  WF2 4–12 h",
            "  Pb / Ta :           WF1 4–12 h  ·  WF2 1–2 jours",
            "  Binaire 2–4 at. :   WF1 0,5–2 j ·  WF2 2–5 j",
            "Goulots : ph.x (WF1) puis epw.x (WF2)",
            "Test rapide : nq = 2³ (non publiable)",
        ], note="Toujours terminer WF1 avant d’ouvrir EPW.")
        add_title_slide(prs, "Merci", [
            "Prof. S. HIADSI",
            "LMESM — Faculté de Physique · USTO-MB · Oran, Algérie",
            "",
            SITE,
            "Citez l’auteur lorsque vous utilisez ces interfaces.",
        ])
    else:
        add_content_slide(prs, "WF1 vs WF2 — when to use which", [
            "WF1 Classic — first check of λ / ω_log; teaching; screening materials",
            "WF2 EPW — when Δ(T), anisotropy or publication-grade Eliashberg is needed",
            "Always validate WF1 before opening EPW",
            "WF1: NSCF very dense (e.g. 24³) · q modest (4³)",
            "WF2: ph.x before coarse NSCF · high nbnd · fine nkf/nqf (e.g. 40³)",
            "EPW is sensitive to Wannier energy windows (dis_win / dis_froz)",
        ], note="Separate output trees: classic/ and epw/ — never mixed.")
        add_content_slide(prs, "How to start", [
            "tar -xzf supra-QE_v1.1_2026-08-27.tar.gz && cd supra-QE",
            "./configurer.sh --qe-bin /path/to/qe/bin",
            "  → links pw.x, ph.x, epw.x into supra-QE/bin/",
            "./DEMARRER.sh  →  http://127.0.0.1:8765/interface/",
            "One-shot: ./INSTALL_AUTOMATIQUE.sh -y --qe-bin …",
            "If epw.x is missing: ./scripts/installer_epw.sh",
        ])
        add_content_slide(prs, "UI workflow (Calculations tab)", [
            "1. Validate the material name",
            "2. Provide Norm-Conserving .UPF (PseudoDojo / SG15 / ONCV)",
            "3. Place <mat>.vc-relax.out in inputs/<mat>/",
            "4. Choose WF1 Classic or WF2 EPW",
            "5. Check k ≫ q (integer ratio), μ*, EPW windows",
            "6. Generate inputs → run one step or the full workflow",
            "Chain panel follows JOB DONE; Cancel stops a long job",
        ])
        add_content_slide(prs, "Results explorer", [
            "Module 1 — Scalars: λ, ω_log, ⟨ω²⟩½, N(EF), Tc(μ*)",
            "Module 2 — Spectra: α²F(ω), λ(ω), F(ω), Δ(T)",
            "Module 3 — Fermi surface & anisotropy (mainly EPW)",
            "Module 4 — Raw file inventory + viewer",
            "Exports: CSV · LaTeX · report",
        ])
        add_content_slide(prs, "Hard rules of the interface", [
            "Norm-Conserving pseudos only — USPP / PAW rejected for e–ph",
            "Only vc-relax.out is mandatory; each WF runs its own SCF",
            "k-grid ≫ q-grid with integer ratio (recommend ≥ 4)",
            "Steps locked until JOB DONE + required intermediate files",
            "LAN (0.0.0.0) requires SUPRA_ALLOW_LAN + SUPRA_API_TOKEN",
        ])
        add_content_slide(prs, "Wall-clock estimates (indicative)", [
            "Strong PC (e.g. i9-14900K, 64 GB+), nprocs ≈ 16–24",
            "  Nb / Al (1 at.):   WF1 1–4 h   ·  WF2 4–12 h",
            "  Pb / Ta:           WF1 4–12 h  ·  WF2 1–2 days",
            "  Binary 2–4 at.:    WF1 0.5–2 d ·  WF2 2–5 d",
            "Bottlenecks: ph.x (WF1) then epw.x (WF2)",
            "Smoke test: nq = 2³ (not for publication)",
        ], note="Always finish WF1 before opening EPW.")
        add_title_slide(prs, "Thank you", [
            "Prof. S. HIADSI",
            "LMESM — Faculty of Physics · USTO-MB · Oran, Algeria",
            "",
            SITE,
            "Please cite the author when using these interfaces.",
        ])

    path.parent.mkdir(parents=True, exist_ok=True)
    prs.save(path)


def main():
    targets = [
        ("en", "Supra-QE_v1.1_Usage_and_Physics.docx", "Supra-QE_v1.1_Usage_and_Physics.pptx"),
        ("fr", "Supra-QE_v1.1_Utilisation_et_Physique_FR.docx", "Supra-QE_v1.1_Utilisation_et_Physique_FR.pptx"),
    ]
    desk = Path.home() / "Bureau"
    for lang, doc_name, ppt_name in targets:
        doc_path = OUT / doc_name
        ppt_path = OUT / ppt_name
        build_word(doc_path, lang=lang)
        build_pptx(ppt_path, lang=lang)
        print(f"[{lang}] Word : {doc_path.name} ({doc_path.stat().st_size // 1024} KiB)")
        print(f"[{lang}] PPT  : {ppt_path.name} ({ppt_path.stat().st_size // 1024} KiB)")
        if desk.is_dir():
            import shutil
            shutil.copy2(doc_path, desk / doc_name)
            shutil.copy2(ppt_path, desk / ppt_name)


if __name__ == "__main__":
    main()

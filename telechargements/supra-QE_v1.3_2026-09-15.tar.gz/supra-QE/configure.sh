#!/usr/bin/env bash
# ==========================================================================
#  Supra-QE — configure.sh (alias portable pour transfert sur un autre PC)
#
#  Installe les prérequis système (python3, pip, curl, …) et configure
#  le projet (QE_BIN_DIR, venv, chemins). Délègue à configurer.sh.
#
#  Usage (sur le PC cible, après tar xzf) :
#    ./configure.sh --yes --qe-bin ~/q-e-qe-7.5/bin
#    ./configure.sh --install-prereqs --yes --qe-bin /opt/qe/bin
#    ./configure.sh --help
#
#  Équivalent one-shot avec démarrage :
#    ./INSTALL_AUTOMATIQUE.sh -y --qe-bin ~/q-e-qe-7.5/bin
# ==========================================================================
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

if [[ ! -x "$HERE/configurer.sh" ]]; then
  echo "[configure] ERREUR : configurer.sh introuvable dans $HERE" >&2
  exit 1
fi

HAS_INSTALL=0
for a in "$@"; do
  [[ "$a" == "--install-prereqs" ]] && HAS_INSTALL=1
done
ARGS=("$@")
if [[ "$HAS_INSTALL" -eq 0 ]]; then
  ARGS=(--install-prereqs "$@")
fi

exec "$HERE/configurer.sh" "${ARGS[@]}"

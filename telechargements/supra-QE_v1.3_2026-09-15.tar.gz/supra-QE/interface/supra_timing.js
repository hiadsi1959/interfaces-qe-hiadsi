/* ===========================================================================
 *  supra_timing.js — Estimation grossière des durées QE (matériau, grilles, PC)
 *  Heuristique : ordre de grandeur pour planifier, pas une garantie.
 * ========================================================================= */
(function (global) {
    'use strict';

    const REF_CPU = 8;

    function kProd(k) {
        return Math.max(1, (k[0] || 1) * (k[1] || 1) * (k[2] || 1));
    }

    function parallelScale(ctx) {
        const np = Math.max(1, ctx.nprocs || 1);
        const nt = Math.max(1, ctx.nthreads || 1);
        const cpu = Math.max(1, ctx.cpuLogical || REF_CPU);
        const mpi = Math.sqrt(np) * Math.min(nt, 4) * 0.85;
        const host = Math.max(0.6, cpu / REF_CPU);
        return Math.max(0.35, mpi * host);
    }

    function natScale(nat) {
        const n = Math.max(1, nat || 1);
        return Math.pow(n / 2, 1.4);
    }

    function ecutScale(ecut) {
        const e = Math.max(30, ecut || 60);
        return Math.pow(e / 60, 1.35);
    }

    /**
     * @param {string} type  scf | nscf | ph | q2r | matdyn | epw | …
     * @param {string} wf    classic | epw
     * @param {object} ctx   buildTimingContext() depuis supra_app
     * @returns {{ seconds: number, detail: string }}
     */
    function estimateStep(type, wf, ctx) {
        const scale = parallelScale(ctx);
        const nat = natScale(ctx.nat);
        const ecut = ecutScale(ctx.ecutwfc);
        const kScf = kProd(ctx.kScf || [12, 12, 12]);
        const kNscf = kProd(ctx.kNscf || [24, 24, 24]);
        const kEpw = kProd(ctx.kNscfEpw || [8, 8, 8]);
        const qT = kProd(ctx.qPh || [4, 4, 4]);

        let sec = 600;
        let detail = '';

        switch (type) {
            case 'scf':
                sec = 420 * nat * (kScf / 1728) * ecut / scale;
                detail = `SCF · k³=${kScf} · nat=${ctx.nat || 1}`;
                break;
            case 'nscf':
                sec = 3600 * nat * (kNscf / 13824) * ecut / scale;
                detail = `NSCF dense · k³=${kNscf}`;
                break;
            case 'ph':
                // Calibré ~24 h pour Nb (nat=2, q=4³, k_nscf~24³) sur ~8 cœurs, 1 MPI
                sec = 86400 * nat * nat * (qT / 64) * Math.sqrt(kNscf / 13824) * ecut / scale;
                detail = `ph.x · ${ctx.qPh?.join('×') || '?'} points q · k_NSCF³=${kNscf}`;
                break;
            case 'q2r':
                sec = 90 * (qT / 64) / scale;
                detail = 'q2r.x · post-traitement rapide';
                break;
            case 'matdyn':
                sec = 240 * (qT / 64) / scale;
                detail = 'matdyn.x · DOS / α²F';
                break;
            case 'alpha2f':
                sec = 300;
                detail = 'alpha2f.x';
                break;
            case 'epw':
                sec = 28800 * nat * (kEpw / 512) * (qT / 64) / scale;
                detail = `epw.x · Wannier + Éliashberg · k³=${kEpw}`;
                break;
            case 'pw_forces':
                sec = 7200 * nat * ecut / scale;
                detail = 'pw.x forces (SSCHA)';
                break;
            case 'sscha':
                sec = 3600;
                detail = 'SSCHA';
                break;
            default:
                sec = 1200;
                detail = type;
        }

        if (wf === 'epw' && type === 'ph') {
            sec *= 0.85;
        }

        sec = Math.max(30, Math.min(sec, 86400 * 14));
        return { seconds: sec, detail };
    }

    function estimateWorkflow(wf, stepTypes, ctx) {
        let total = 0;
        const lines = [];
        (stepTypes || []).forEach(t => {
            const e = estimateStep(t, wf, ctx);
            total += e.seconds;
            lines.push({ type: t, ...e });
        });
        return { totalSeconds: total, steps: lines };
    }

    function formatDuration(sec, opts = {}) {
        if (sec == null || !Number.isFinite(sec)) return '—';
        sec = Math.max(0, Math.round(sec));
        if (sec < 90) return `${sec} s`;
        const h = Math.floor(sec / 3600);
        const m = Math.floor((sec % 3600) / 60);
        if (h >= 48 && !opts.precise) return `~${Math.round(h / 24)} j`;
        if (h > 0) return m > 0 ? `${h} h ${m} min` : `${h} h`;
        return `${m} min`;
    }

    function formatDurationRange(sec) {
        const lo = sec * 0.55;
        const hi = sec * 1.8;
        return `${formatDuration(lo)} – ${formatDuration(hi)}`;
    }

    /** Progression lue dans une sortie .out (sans appeler le serveur). */
    function progressFromOutText(type, text, ctx) {
        if (!text) return { fraction: 0.02, detail: '' };
        if (/JOB DONE/i.test(text)) return { fraction: 1, detail: 'terminé' };

        if (type === 'ph') {
            const qT = kProd(ctx.qPh || [4, 4, 4]);
            const nQ = (text.match(/Calculation of q/g) || []).length;
            const fraction = Math.min(0.98, Math.max(0.02, (nQ - 0.35) / qT));
            return {
                fraction,
                detail: `q ${Math.min(nQ, qT)}/${qT}`,
            };
        }
        if (type === 'scf' || type === 'nscf' || type === 'pw_forces') {
            const it = (text.match(/^\s*iteration #\s*\d+/gim) || []).length;
            const frac = it > 0 ? Math.min(0.92, it / 80) : 0.08;
            return { fraction: frac, detail: it ? `${it} itér.` : 'démarrage' };
        }
        if (type === 'epw') {
            const frac = /Electron-phonon coupling/i.test(text) ? 0.75 : 0.12;
            return { fraction: frac, detail: 'epw.x' };
        }
        if (type === 'q2r' || type === 'matdyn') {
            return { fraction: 0.5, detail: type };
        }
        return { fraction: 0.05, detail: '…' };
    }

    function remainingSeconds(clock) {
        if (!clock) return null;
        const elapsed = (Date.now() - clock.startedAtMs) / 1000;
        const f = Math.max(0.02, Math.min(0.99, clock.progressFrac || 0.02));
        let rem;
        if (f >= 0.08) {
            rem = Math.max(0, (elapsed / f) * (1 - f));
        } else {
            rem = Math.max(0, (clock.estimateSec || 0) - elapsed);
        }
        return { elapsed, remaining: rem, progress: f };
    }

    global.SupraTiming = {
        estimateStep,
        estimateWorkflow,
        formatDuration,
        formatDurationRange,
        progressFromOutText,
        remainingSeconds,
        kProd,
    };
})(typeof window !== 'undefined' ? window : globalThis);

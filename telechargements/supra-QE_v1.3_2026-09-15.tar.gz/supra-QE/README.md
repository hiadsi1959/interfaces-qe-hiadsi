# 🧊 Supra-QE — Propriétés Supraconductrices

**LMESM / USTO-MB · S. Hiadsi** — module autonome pour calculer la température critique
supraconductrice (Tᶜ) avec Quantum ESPRESSO (couplage électron–phonon).

Interface web + API Flask : génération d’inputs, lancement pas à pas, vérification
de la chaîne, exploration des résultats (deux voies).

---

## Vue d’ensemble

Deux workflows indépendants (dossiers séparés `classic/` et `epw/`) :

### Voie classique — ph.x + matdyn / lambda.x

```
vc-relax (prérequis)
    → pw.x SCF  →  pw.x NSCF dense  →  ph.x (elph)
    → q2r.x  →  matdyn.x / lambda.x
    → α²F(ω), λ, ω_log, ⟨ω²⟩^½, Tᶜ (McMillan / Allen–Dynes)
```

### Voie EPW — Wannier + Éliashberg

```
vc-relax (prérequis)
    → pw.x SCF  →  ph.x (dvscf + dyn)  →  [pp.py → save/]
    → pw.x NSCF coarse (nbnd élevé)  →  epw.x
    → Tᶜ, Δ(T), gap anisotrope, Z(0), 2Δ₀/k_B Tᶜ
```

Détail : [docs/workflow_supra.md](docs/workflow_supra.md).

---

## Démarrage rapide

```bash
cd /chemin/vers/supra-QE
./configurer.sh                  # pointe QE + associe pw.x / epw.x → supra-QE/bin/
./DEMARRER.sh                    # API + navigateur → http://127.0.0.1:8765/interface/
```

**EPW sans recompiler à chaque fois** : après une seule compilation QE (`make epw`),
associe les exécutables au projet :

```bash
./scripts/associer_binaires_qe.sh /chemin/vers/q-e-qe-7.5/bin
# si epw.x manque encore :
./scripts/installer_epw.sh && ./scripts/associer_binaires_qe.sh
```

L’API utilise alors `supra-QE/bin/` (liens symboliques vers ton QE). La liste
canonique est dans `scripts/supra_qe_bins.sh` :

| Rôle | Binaires |
|------|----------|
| WF1 obligatoires | `pw.x`, `ph.x`, `q2r.x`, `matdyn.x` |
| WF2 EPW | `epw.x`, `wannier90.x`, `pw2wannier90.x` |
| Post-traitement / SF 3D | `lambda.x`, `alpha2f.x`, `fs.x` |
| Script EPW | `pp.py` (regroupement `save/` avant `epw.x`) |

Sur un autre PC, relance `associer_binaires_qe.sh` vers le QE local — pas besoin
de recompiler EPW si `epw.x` y est déjà. Redémarre l’API après association
(`./ARRETER.sh && ./DEMARRER.sh`) pour que `/health` liste tous les binaires.

Installation one-shot sur une machine neuve :

```bash
./INSTALL_AUTOMATIQUE.sh --qe-bin /chemin/vers/qe/bin
```

| Commande | Rôle |
|----------|------|
| `./DEMARRER.sh` | Lance l’API et ouvre l’interface dans **Firefox** |
| `./ARRETER.sh` | Arrête l’API |
| `./STATUT.sh` | État API /health |

**Navigateur** : `./DEMARRER.sh` ouvre **Firefox** par défaut. Pour un autre navigateur :

```bash
SUPRA_BROWSER=chrome ./DEMARRER.sh     # Google Chrome / Chromium
SUPRA_BROWSER=xdg-open ./DEMARRER.sh   # navigateur par défaut du système
SUPRA_BROWSER=none ./DEMARRER.sh       # API seule, pas d’ouverture auto
```

On peut aussi fixer `export SUPRA_BROWSER=firefox` dans `config.env`.

**Important** : ouvrir l’interface via `http://…/interface/`, pas le fichier HTML en `file://`.

**Sécurité LAN** : `SUPRA_QE_HOST=0.0.0.0` exige `SUPRA_ALLOW_LAN=1` **et**
un `SUPRA_API_TOKEN` (sinon repli sur `127.0.0.1`). En-tête `X-Supra-Token`
ou champ Chemins. Voir [docs/AUTRE_PC.md](docs/AUTRE_PC.md).

Tests :

```bash
.venv/bin/pip install -r requirements-dev.txt   # si besoin
.venv/bin/pytest tests/ -q
```

---

## Interface

L’UI démarre sur le **Guide**, puis :

| Onglet | Contenu |
|--------|---------|
| **Guide** | Mode d’emploi + accès Calculs / Résultats |
| **Calculs** | Matériau → pseudos NC → WF1/WF2 → paramètres → lancement |
| **Résultats** | Journal (fiche technique) des deux voies, ouvert dès qu’un matériau est validé |
| **Aide** | Comparaison des méthodes, formules, règles |

Autres contrôles (barre du haut) :

- **Clair / Sombre** et **FR / EN** — dans l’en-tête
- **📁 Chemins** — URL de l’API + dossiers inputs / outputs / pseudos (autre PC)
- **↻ API** — santé de l’API et binaires QE
- **Tout déplier / Tout replier** — sections (Calculs / Aide) ; chaque carte a aussi ▼ / ▲

### Onglet Résultats

Le **Journal** est l’onglet par défaut : fiche technique (chaîne, surface de Fermi,
catalogue des grandeurs, remarques). L’affichage reste à l’écran ; **Ouvrir HTML**
et **Ouvrir PDF** reproduisent la fiche dans une fenêtre séparée.
CSV / LaTeX / rapport texte restent dans **Synthèse**.

| Module | Contenu |
|--------|---------|
| **Journal** | Fiche : avancement des deux voies, analyse à E_F, catalogue, interprétations |
| **1 · Synthèse** | λ, ω_log, ⟨ω²⟩^½, N(E_F), Δ₀, Tᶜ(μ*) Classique vs EPW |
| **2 · Spectres** | α²F(ω) + λ(ω), F(ω), dispersion, Δ(T) |
| **3 · Anisotropie** | Histogramme E−E_F, Δ_k, XCrySDen (`.bxsf`), Wannier |
| **4 · Fichiers** | Inventaire interactif + aperçu des sorties |

Boutons **🔎 Explorer tous les résultats** et **🧊 Surface de Fermi (XCrySDen)**
→ `POST /api/results/explore` (exploration aussi lancée après validation du matériau).

**Surface de Fermi 3D** : pas un graphe dans le navigateur. Workflow QE :

1. **SCF + NSCF** (`JOB DONE`, grille **k régulière** pour `fs.x`).
2. Input **`inputs/<mat>/<voie>/<mat>.fs.in`** généré avec **Générer les inputs**
   (même `prefix` / `outdir` que le SCF).
3. **`fs.x`** → fichier **`.bxsf`** (post-traitement ; **hors** chaîne ph.x / matdyn / epw).
4. **XCrySDen** sur la machine API : `xcrysden --bxsf <prefix>.bxsf` (ou télécharger le `.bxsf`).

L’interface peut **lancer `fs.x` automatiquement** à la fin de la chaîne
(bouton **Fin des calculs — ouvrir Résultats**) ou via **Lancer fs.x** dans
**Résultats → Anisotropie**. Le bouton **Visualiser** reste inactif tant qu’aucun
`.bxsf` n’est détecté. L’histogramme E−E_F est une occupation, pas la géométrie 3D.

---

## Autre PC / réseau

Deux modes — détail : [docs/AUTRE_PC.md](docs/AUTRE_PC.md).

**A. Projet complet sur la machine de calcul**

```bash
# source
./EMBALLER.sh -o supra-QE.tar.gz
# cible
tar xzf supra-QE.tar.gz && cd supra-QE
./INSTALL_AUTOMATIQUE.sh -y --qe-bin ~/q-e/bin
```

**B. Navigateur distant, API sur le PC de calcul**

```bash
# config.env sur le serveur
export SUPRA_QE_HOST="0.0.0.0"
export SUPRA_QE_PORT="8765"
./DEMARRER.sh   # affiche les URL http://IP:8765/interface/
```

Sur l’autre PC : ouvrir `http://IP:8765/interface/`  
ou `http://IP:8765/interface/?api=http://IP:8765`  
ou **📁 Chemins** → URL API → **Appliquer & tester**.

| Script | Rôle |
|--------|------|
| `EMBALLER.sh` | Archive portable (sans `config.env`, `.venv/`, `logs/`, `outputs/`) |
| `configurer.sh` | QE, pseudos, chemins, venv → `config.env` |
| `INSTALL_AUTOMATIQUE.sh` | Configuration + démarrage |
| `AUTO_TRANSFERT.sh` | Déploiement guidé avec contrôles |

Variables utiles (`config.env`, modèle `config.env.example`) :

`QE_BIN_DIR`, `QE_PSEUDO_DIR`, `SUPRA_QE_HOST`, `SUPRA_QE_PORT`,  
`SUPRA_INPUTS_DIR`, `SUPRA_OUTPUTS_DIR`, `SUPRA_PSEUDO_DIR_REL`.

---

## Arborescence

```
supra-QE/
├── README.md
├── configurer.sh / DEMARRER.sh / ARRETER.sh / STATUT.sh
├── EMBALLER.sh / INSTALL_AUTOMATIQUE.sh / AUTO_TRANSFERT.sh
├── config.env.example
├── requirements.txt / requirements-dev.txt
├── api/
│   ├── supra_api.py          API Flask (jobs, fichiers, résultats)
│   └── supra_results.py      Moments α²F, parseurs, /explore
├── interface/                Scripts JS nécessaires uniquement
│   ├── Interface_Supra_QE.html
│   ├── supra_config.js       Flags UI (ex. SSCHA)
│   ├── supra_inputs.js       Générateurs .in
│   ├── supra_api_client.js   Client HTTP
│   ├── supra_plots.js        Tracés SVG
│   ├── supra_app.js          Logique interface
│   ├── supra_i18n_dict.js
│   └── supra_i18n.js         FR / EN
├── scripts/
│   ├── associer_binaires_qe.sh   Liens QE → supra-QE/bin/
│   ├── supra_qe_bins.sh          Liste des exécutables attendus
│   └── installer_epw.sh
├── tests/
│   ├── test_api_smoke.py
│   ├── test_api_security.py
│   ├── test_api_endpoints.py
│   └── test_results_explore.py
├── inputs/   outputs/   pseudos/   logs/
└── docs/
    ├── workflow_supra.md
    └── AUTRE_PC.md
```

---

## Règles imposées par l’interface

### 1. Pseudopotentiels Norm-Conserving

Le couplage e–p exige des NC. Les USPP / PAW sont refusés pour `ph.x`.  
Bibliothèque recommandée : [PseudoDojo (NC)](http://www.pseudo-dojo.org/).

### 2. Prérequis et SCF partagé

Seul **`vc-relax.out`** (structure extractible) est obligatoire dans
`inputs/<matériau>/`. L’input SCF utilisateur (`inputs/<matériau>/<matériau>.scf.in`)
n’est pas réécrit. Chaque voie travaille dans `inputs/<matériau>/<voie>/`,
mais le **SCF est unique** : un `scf.out` `JOB DONE` d’une voie est repris par
l’autre (même densité de départ).

### 3. Métal obligatoire

Après le SCF, l’interface classe métal / isolant (occupations fractionnaires,
flag QE, gap imprimé). Un **gap ≳ 0,15 eV** (isolant) **arrête** nscf / phonons /
EPW / Tᶜ : pas de surface de Fermi, donc pas de paires de Cooper conventionnelles.

### 4. μ\* (écrantage coulombien)

Pré-rempli à **0.10** (typiquement 0.10–0.15). L’onglet Résultats calcule Tᶜ
pour une série de μ\* (McMillan + Allen–Dynes avec f₁, f₂ si ⟨ω²⟩^½ est connu).

### 5. Grilles k vs q

La grille **k** (NSCF) doit être nettement plus dense que la grille **q** (phonons),
avec un ratio entier. L’interface affiche et valide ce ratio.

### 6. Enchaînement

Chaque étape est bloquée tant que l’amont n’a pas `JOB DONE` et les fichiers
intermédiaires requis. Le panneau **Vérification de l’enchaînement** le montre
en direct ; un lancement forcé reste possible avec confirmation.

### 7. Export surface de Fermi (`fs.x`)

`fs.x` n’est **pas** une étape numérotée du workflow Tᶜ, mais l’input
`<mat>.fs.in` est **généré automatiquement** avec la suite (classique et EPW).
Après NSCF terminé, lance `fs.x` (manuellement, via l’UI, ou à la fin de chaîne)
avant d’ouvrir XCrySDen. **XCrySDen** doit être installé sur le PC qui exécute
l’API pour l’ouverture automatique ; sinon copie la commande ou télécharge le `.bxsf`.

---

## Sorties exploitables

Après **🔎 Explorer tous les résultats**, les grandeurs typiques sont :

| Grandeur | Classique | EPW |
|----------|-----------|-----|
| λ, ω_log, ⟨ω²⟩^½ | α²F / matdyn / lambda.x | α²F / epw.out |
| Tᶜ(μ\*) | McMillan + Allen–Dynes | idem + Tᶜ Éliashberg (fermeture Δ) |
| N(E_F), E_F, k sur la SF | scf / nscf | scf / nscf |
| α²F(ω), λ(ω), F(ω) | a2F.dat, phonon.dos | \*.a2f, \*.phdos |
| Dispersion / γ_qν | freq.gp, elph.inp_lambda.\* | — |
| Δ(T), Δ_k, Z(0) | — | epw.out, imag_aniso_\* |
| Surface de Fermi 3D | `fs.x` → `.bxsf` → **XCrySDen** | idem ; `.frmsf` (FermiSurfer) si présent |

Fichiers sous `outputs/<matériau>/classic/` et `…/epw/` (et parfois `inputs/…`).
Fiche HTML / PDF : boutons en tête du journal (en plus de l’affichage).

---

## Références

- McMillan, *Phys. Rev.* **167**, 331 (1968)
- Allen & Dynes, *Phys. Rev. B* **12**, 905 (1975)
- Giannozzi *et al.*, *J. Phys.: Condens. Matter* **21**, 395502 (2009) — Quantum ESPRESSO
- Poncé *et al.*, *Comput. Phys. Commun.* **209**, 116 (2016) — EPW
- Kokalj, *Comput. Mater. Sci.* **28**, 155 (2003) — XCrySDen
- PseudoDojo, *Comp. Mat. Sci.* **154**, 35 (2018)

"""
supra_results.py — extraction et exploitation des résultats de la chaîne QE.

Deux voies produisent des grandeurs supraconductrices :

* voie classique : ``ph.x`` (+ ``elph``) → ``q2r.x`` → ``matdyn.x`` / ``lambda.x``
  → α²F(ω), λ, ω_log, largeurs de raie γ_qν, dispersion de phonons ;
* voie EPW : ``epw.x`` → équations d'Éliashberg, Δ(T), gap anisotrope sur la
  surface de Fermi, self-énergie.

Le module ne fait que lire des fichiers texte : aucune dépendance externe, tout
est calculé en Python pur pour rester installable partout. Les grandeurs
dérivables de α²F(ω) (λ, ω_log, ⟨ω²⟩^½, λ(ω) cumulatif) sont recalculées ici
plutôt que d'être cherchées dans les sorties : c'est ce qui permet d'obtenir Tᶜ
pour plusieurs μ* et d'appliquer les corrections de fort couplage d'Allen-Dynes
même quand la sortie QE ne les imprime pas.
"""

from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

# ─────────────────────────────────────────────────────────────────────────────
#  Conversions d'unités vers le Kelvin (axe des fréquences)
# ─────────────────────────────────────────────────────────────────────────────
K_PER_CM1 = 1.4387768775039337
K_PER_MEV = 11.604518121550082
K_PER_THZ = 47.99243073366221
K_PER_RY = 157887.51240229
K_PER_EV = 11604.518121550082

_UNIT_TO_K = {
    'cm-1': K_PER_CM1, 'cmm1': K_PER_CM1,
    'meV': K_PER_MEV, 'mev': K_PER_MEV,
    'THz': K_PER_THZ, 'thz': K_PER_THZ,
    'Ry': K_PER_RY, 'ry': K_PER_RY,
    'eV': K_PER_EV, 'ev': K_PER_EV,
    'K': 1.0, 'k': 1.0,
}

#: Nombre maximal de points renvoyés par courbe (protège la réponse JSON).
MAX_CURVE_POINTS = 1500
#: Nombre maximal de branches de phonons renvoyées.
MAX_BANDS = 60


def unit_factor(unit: Optional[str]) -> float:
    """Facteur multiplicatif convertissant `unit` en Kelvin."""
    return _UNIT_TO_K.get((unit or '').strip(), K_PER_CM1)


def guess_frequency_unit(omega_max: float) -> str:
    """
    Devine l'unité de l'axe des fréquences à partir de son ordre de grandeur.
    Utilisé seulement quand ni le nom du fichier ni son en-tête ne renseignent.

    Préférence meV (pas THz) dans la zone ~1–15 : les α²F EPW picent souvent
    sous 15 meV ; un faux « THz » fausse λ et Tᶜ d'un facteur ~4.
    """
    if omega_max <= 0:
        return 'cm-1'
    if omega_max < 1.0:            # ~0.01–0.05 Ry
        return 'Ry'
    if omega_max < 400.0:          # 1–300 meV (métaux → hydrures)
        return 'meV'
    return 'cm-1'                  # 200–4000 cm⁻¹


# ─────────────────────────────────────────────────────────────────────────────
#  Lecture de tableaux numériques
# ─────────────────────────────────────────────────────────────────────────────
def read_columns(text: str, min_cols: int = 2) -> List[List[float]]:
    """
    Lit un fichier texte en colonnes numériques, en ignorant les commentaires
    (`#`, `!`, `@`) et les lignes non numériques (en-têtes gnuplot, mots-clés).
    Renvoie une liste de lignes, chacune étant la liste de ses valeurs.
    """
    rows: List[List[float]] = []
    for line in text.splitlines():
        s = line.strip()
        if not s or s[0] in '#!@%':
            continue
        parts = s.replace(',', ' ').split()
        vals: List[float] = []
        for p in parts:
            try:
                vals.append(float(p))
            except ValueError:
                vals = []
                break
        if len(vals) >= min_cols:
            rows.append(vals)
    return rows


def downsample(seq: Sequence[float], limit: int = MAX_CURVE_POINTS) -> List[float]:
    """Sous-échantillonne une courbe en conservant premier et dernier points."""
    n = len(seq)
    if n <= limit:
        return list(seq)
    step = n / float(limit)
    out = [seq[min(int(i * step), n - 1)] for i in range(limit)]
    out[-1] = seq[-1]
    return out


def _downsample_many(limit: int, *series: Sequence[float]) -> List[List[float]]:
    """Sous-échantillonne plusieurs séries de même longueur de façon cohérente."""
    n = min((len(s) for s in series), default=0)
    if n <= limit:
        return [list(s[:n]) for s in series]
    step = n / float(limit)
    idx = [min(int(i * step), n - 1) for i in range(limit)]
    idx[-1] = n - 1
    return [[s[i] for i in idx] for s in series]


# ─────────────────────────────────────────────────────────────────────────────
#  Moments de α²F(ω) : λ, ω_log, ⟨ω²⟩^½ et λ(ω) cumulatif
# ─────────────────────────────────────────────────────────────────────────────
def a2f_moments(omega: Sequence[float], a2f: Sequence[float],
                unit: str = 'cm-1') -> Dict[str, Any]:
    """
    Calcule les moments standard de la fonction d'Éliashberg :

        λ        = 2 ∫ α²F(ω)/ω dω
        ω_log    = exp[ (2/λ) ∫ α²F(ω) ln ω / ω dω ]
        ⟨ω²⟩^½   = sqrt[ (2/λ) ∫ α²F(ω) ω dω ]
        λ(ω)     = 2 ∫₀^ω α²F(ω')/ω' dω'      (couplage cumulatif)

    Les intégrales sont faites par trapèzes sur l'axe converti en Kelvin, en
    ignorant les points ω ≤ 0 (divergence en 1/ω) et les α²F négatifs qui
    apparaissent parfois comme bruit numérique près de Γ.
    """
    f = unit_factor(unit)
    pts: List[Tuple[float, float]] = []
    for w, a in zip(omega, a2f):
        try:
            wk = float(w) * f
            av = float(a)
        except (TypeError, ValueError):
            continue
        if wk <= 0.0 or not math.isfinite(wk) or not math.isfinite(av):
            continue
        pts.append((wk, max(av, 0.0)))
    if len(pts) < 3:
        return {'lambda': None, 'omega_log_K': None, 'omega_2_K': None,
                'lambda_w': [], 'omega_K': [], 'n_points': len(pts)}

    pts.sort(key=lambda t: t[0])
    lam_cum: List[float] = []
    lam = 0.0
    int_log = 0.0
    int_w2 = 0.0
    prev_w, prev_a = pts[0]
    lam_cum.append(0.0)
    for wk, av in pts[1:]:
        dw = wk - prev_w
        if dw <= 0:
            lam_cum.append(lam)
            prev_w, prev_a = wk, av
            continue
        # trapèzes sur les intégrandes
        lam += dw * (prev_a / prev_w + av / wk)                       # ×2 plus bas
        int_log += dw * (prev_a * math.log(prev_w) / prev_w + av * math.log(wk) / wk)
        int_w2 += dw * (prev_a * prev_w + av * wk)
        lam_cum.append(lam)
        prev_w, prev_a = wk, av

    # Le facteur 2 des définitions annule le ½ de la règle des trapèzes :
    # `lam`, `int_log` et `int_w2` valent donc déjà 2∫… .
    omega_log = math.exp(int_log / lam) if lam > 1e-12 else None
    omega_2 = math.sqrt(int_w2 / lam) if lam > 1e-12 and int_w2 > 0 else None

    w_k, a_v, l_w = _downsample_many(MAX_CURVE_POINTS,
                                     [p[0] for p in pts], [p[1] for p in pts], lam_cum)
    return {
        'lambda': lam if lam > 0 else None,
        'omega_log_K': omega_log,
        'omega_2_K': omega_2,
        'lambda_w': l_w,
        'omega_K': w_k,
        'a2f': a_v,
        'n_points': len(pts),
    }


# ─────────────────────────────────────────────────────────────────────────────
#  Températures critiques
# ─────────────────────────────────────────────────────────────────────────────
def tc_mcmillan(lam: Optional[float], omega_log_K: Optional[float],
                mu_star: float) -> Optional[float]:
    """McMillan (1968)."""
    if not lam or not omega_log_K or lam <= mu_star:
        return None
    expo = -1.04 * (1.0 + lam) / (lam - mu_star * (1.0 + 0.62 * lam))
    return (omega_log_K / 1.20) * math.exp(expo)


def allen_dynes_factors(lam: Optional[float], omega_log_K: Optional[float],
                        mu_star: float,
                        omega_2_K: Optional[float] = None) -> Tuple[Optional[float], Optional[float]]:
    """Préfacteurs f₁, f₂ d'Allen–Dynes (f₂ = 1 sans ⟨ω²⟩^½)."""
    if not lam or not omega_log_K:
        return None, None
    lam_1 = 2.46 * (1.0 + 3.8 * mu_star)
    f1 = (1.0 + (lam / lam_1) ** 1.5) ** (1.0 / 3.0)
    if omega_2_K and omega_log_K > 0:
        lam_2 = 1.82 * (1.0 + 6.3 * mu_star) * (omega_2_K / omega_log_K)
        f2 = 1.0 + ((omega_2_K / omega_log_K - 1.0) * lam ** 2 /
                    (lam ** 2 + lam_2 ** 2))
    else:
        f2 = 1.0
    return f1, f2


def tc_allen_dynes(lam: Optional[float], omega_log_K: Optional[float],
                   mu_star: float, omega_2_K: Optional[float] = None) -> Optional[float]:
    """
    Allen–Dynes (1975) avec les préfacteurs de fort couplage f₁ et f₂.
    Sans ⟨ω²⟩^½, f₂ = 1 : la correction de forme du spectre est alors absente.
    """
    if not lam or not omega_log_K or lam <= mu_star:
        return None
    f1, f2 = allen_dynes_factors(lam, omega_log_K, mu_star, omega_2_K)
    if f1 is None or f2 is None:
        return None
    expo = -1.04 * (1.0 + lam) / (lam - mu_star * (1.0 + 0.62 * lam))
    return f1 * f2 * (omega_log_K / 1.20) * math.exp(expo)


DEFAULT_MU_STARS: Tuple[float, ...] = (0.10, 0.11, 0.12, 0.13, 0.14, 0.15)


def tc_sweep(lam: Optional[float], omega_log_K: Optional[float],
             omega_2_K: Optional[float] = None,
             mu_stars: Iterable[float] = DEFAULT_MU_STARS) -> List[Dict[str, Any]]:
    """Tᶜ McMillan et Allen-Dynes pour une série de μ* (0.10 → 0.15 par défaut)."""
    out: List[Dict[str, Any]] = []
    for mu in mu_stars:
        mu = round(float(mu), 4)
        out.append({
            'mu_star': mu,
            'tc_mcmillan_K': tc_mcmillan(lam, omega_log_K, mu),
            'tc_allen_dynes_K': tc_allen_dynes(lam, omega_log_K, mu, omega_2_K),
        })
    return out


def bcs_ratio(gap_meV: Optional[float], tc_K: Optional[float]) -> Optional[float]:
    """Rapport 2Δ₀/k_B Tᶜ (limite BCS faible couplage : 3.53)."""
    if not gap_meV or not tc_K or tc_K <= 0:
        return None
    return 2.0 * gap_meV * K_PER_MEV / tc_K


# ─────────────────────────────────────────────────────────────────────────────
#  Parseurs — voie classique
# ─────────────────────────────────────────────────────────────────────────────
_RE_BROADENING = re.compile(
    r'Broadening\s+([0-9.eEdD+-]+)\s*(?:Ry)?[^\n]*?lambda\s*=?\s*([0-9.eEdD+-]+)'
    r'(?:[^\n]*?dos\(Ef\)\s*=?\s*([0-9.eEdD+-]+))?', re.I)
_RE_LAMBDA_LINE = re.compile(
    r'lambda\s*=?\s*([0-9.eEdD+-]+)\s+omega_log\s*=?\s*([0-9.eEdD+-]+)\s*(K|meV|cm-?1)?', re.I)
_RE_TC_LINE = re.compile(r'T_?c\s*=?\s*([0-9.eEdD+-]+)\s*K', re.I)
_RE_DOS_EF = re.compile(
    r'DOS\s*=\s*([0-9.eEdD+-]+)\s*states?/spin/Ry/Unit\s*Cell\s*at\s*Ef\s*=\s*([0-9.eEdD+-]+)\s*eV', re.I)
_RE_MU = re.compile(r'mu\s*\*?\s*=\s*([0-9.]+)', re.I)


def _f(txt: Optional[str]) -> Optional[float]:
    """Flottant tolérant à la notation Fortran (1.0d-3)."""
    if txt is None:
        return None
    try:
        return float(txt.replace('d', 'e').replace('D', 'E'))
    except ValueError:
        return None


def parse_lambda_out(text: str) -> Dict[str, Any]:
    """
    Sortie de ``lambda.x`` (ou bloc λ d'un ``matdyn.out``).

    ``lambda.x`` imprime un jeu de valeurs par élargissement gaussien : on les
    renvoie toutes (`broadenings`) et on retient la dernière comme référence,
    l'élargissement le plus large étant celui pour lequel la somme sur la grille
    q est la plus stable.
    """
    res: Dict[str, Any] = {
        'lambda': None, 'omega_log_K': None, 'tc_K': None,
        'dos_ef': None, 'ef_eV': None, 'mu_star': None,
        'broadenings': [],
    }

    for m in _RE_BROADENING.finditer(text):
        res['broadenings'].append({
            'sigma_Ry': _f(m.group(1)),
            'lambda': _f(m.group(2)),
            'dos_ef': _f(m.group(3)),
        })

    m = _RE_LAMBDA_LINE.search(text)
    if m:
        res['lambda'] = _f(m.group(1))
        w = _f(m.group(2))
        unit = (m.group(3) or 'K')
        if w is not None:
            res['omega_log_K'] = w * unit_factor('cm-1' if unit.lower().startswith('cm') else unit)
    if res['lambda'] is None:
        # Forme « lambda :   0.85 » de matdyn.x
        m = re.search(r'\blambda\s*[:=]\s*([0-9.eEdD+-]+)', text, re.I)
        if m:
            res['lambda'] = _f(m.group(1))
    if res['lambda'] is None and res['broadenings']:
        res['lambda'] = res['broadenings'][-1].get('lambda')

    if res['omega_log_K'] is None:
        # Forme « <log w> = 412.3 K » ou « <log w> = 286.4 cm-1 » de matdyn.x
        for pat, unit in ((r'<\s*log\s*w\s*>\s*[:=]\s*([0-9.eEdD+-]+)\s*K', 'K'),
                          (r'<\s*log\s*w\s*>\s*[:=]\s*([0-9.eEdD+-]+)\s*cm-?1', 'cm-1'),
                          (r'<\s*log\s*w\s*>\s*[:=]\s*([0-9.eEdD+-]+)\s*meV', 'meV')):
            m = re.search(pat, text, re.I)
            if m:
                w = _f(m.group(1))
                if w is not None:
                    res['omega_log_K'] = w * unit_factor(unit)
                break

    m = _RE_DOS_EF.search(text)
    if m:
        res['dos_ef'] = _f(m.group(1))
        res['ef_eV'] = _f(m.group(2))
    if res['dos_ef'] is None:
        for b in reversed(res['broadenings']):
            if b.get('dos_ef') is not None:
                res['dos_ef'] = b['dos_ef']
                break

    m = _RE_TC_LINE.search(text)
    if m:
        res['tc_K'] = _f(m.group(1))
    m = _RE_MU.search(text)
    if m:
        res['mu_star'] = _f(m.group(1))
    return res


#: Seuil au-delà duquel un gap SCF est considéré isolant (arrêt e–p / Tc).
GAP_STOP_EV = 0.15
_OCC_FRAC_LO = 0.05
_OCC_FRAC_HI = 0.95
_RE_FERMI = re.compile(r'the Fermi energy is\s+([-0-9.]+)\s*ev', re.I)
_RE_HOMO_LUMO = re.compile(
    r'highest occupied,\s*lowest unoccupied level\s*\(ev\):\s*'
    r'([-0-9.]+)\s+([-0-9.]+)',
    re.I,
)
_RE_HOMO_ONLY = re.compile(
    r'highest occupied level\s*\(ev\):\s*([-0-9.]+)',
    re.I,
)
_RE_BAND_GAP = re.compile(r'Band\s+Gap\s*=\s*([-0-9.]+)\s*eV', re.I)
_RE_FLOAT_LINE = re.compile(
    r'^\s*[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eEdD][-+]?\d+)?'
    r'(?:\s+[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eEdD][-+]?\d+)?)*\s*$',
)


def _parse_float_rows(lines: Sequence[str], start: int) -> Tuple[List[float], int]:
    """Lit des lignes de flottants QE à partir de ``start`` ; saute les lignes vides initiales."""
    vals: List[float] = []
    i = start
    n = len(lines)
    while i < n and not lines[i].strip():
        i += 1
    while i < n:
        raw = lines[i]
        if not _RE_FLOAT_LINE.match(raw):
            break
        for tok in raw.split():
            v = _f(tok)
            if v is not None:
                vals.append(v)
        i += 1
    return vals, i


def _last_scf_window(text: str, max_chars: int = 2_000_000) -> str:
    """Dernier cycle SCF (k-points + Fermi) — les gros ``.out`` ne sont pas relus en entier."""
    if not text:
        return ''
    matches = list(_RE_FERMI.finditer(text))
    if matches:
        end = matches[-1].end()
        start = max(0, end - max_chars)
        return text[start:end + 400]
    return text[-max_chars:] if len(text) > max_chars else text


def classify_electronic_character(
    text: str,
    gap_thr_eV: float = GAP_STOP_EV,
) -> Dict[str, Any]:
    """
    Métal vs isolant d'après une sortie ``pw.x`` SCF.

    Un gap électronique ≳ ``gap_thr_eV`` (défaut 0.15 eV) signifie que le
    matériau n'est pas un conducteur : la chaîne e–p / Tc doit s'arrêter,
    même si des étapes suivantes ont déjà été générées ou lancées.

    Signatures QE (par priorité) :
      * « the system is insulating / metallic »
      * ``Band Gap = … eV``
      * HOMO / LUMO
      * occupations fractionnaires ou bandes au niveau de Fermi
    """
    res: Dict[str, Any] = {
        'character': 'unknown',
        'should_stop': False,
        'gap_eV': None,
        'homo_eV': None,
        'lumo_eV': None,
        'ef_eV': None,
        'insulating_flag': False,
        'metallic_flag': False,
        'n_k_parsed': 0,
        'n_fractional_occ': 0,
        'min_gap_eV': None,
        'bands_near_ef': 0,
        'evidence': [],
        'gap_thr_eV': float(gap_thr_eV),
    }
    if not text:
        return res

    low = text.lower()
    if 'the system is insulating' in low:
        res['insulating_flag'] = True
        res['evidence'].append('qe_insulating')
    if 'the system is metallic' in low:
        res['metallic_flag'] = True
        res['evidence'].append('qe_metallic')

    gaps: List[float] = []
    for m in _RE_HOMO_LUMO.finditer(text):
        homo, lumo = _f(m.group(1)), _f(m.group(2))
        if homo is None or lumo is None:
            continue
        res['homo_eV'] = homo
        res['lumo_eV'] = lumo
        gaps.append(lumo - homo)
    if gaps:
        res['gap_eV'] = min(gaps)
        res['evidence'].append('homo_lumo')

    m_gap = _RE_BAND_GAP.search(text)
    if m_gap:
        printed = _f(m_gap.group(1))
        if printed is not None:
            res['gap_eV'] = printed if res['gap_eV'] is None else min(res['gap_eV'], printed)
            res['evidence'].append('band_gap')

    if res['homo_eV'] is None:
        m_h = _RE_HOMO_ONLY.search(text)
        if m_h:
            res['homo_eV'] = _f(m_h.group(1))
            res['evidence'].append('homo_only')

    fermi_hits = list(_RE_FERMI.finditer(text))
    if fermi_hits:
        res['ef_eV'] = _f(fermi_hits[-1].group(1))

    window = _last_scf_window(text)
    lines = window.splitlines()
    i = 0
    min_gap: Optional[float] = None
    while i < len(lines):
        line = lines[i]
        if re.search(r'bands\s*\(ev\)\s*:', line, re.I):
            bands, i = _parse_float_rows(lines, i + 1)
            while i < len(lines) and not lines[i].strip():
                i += 1
            occ: List[float] = []
            if i < len(lines) and re.search(r'occupation numbers', lines[i], re.I):
                occ, i = _parse_float_rows(lines, i + 1)
            if bands:
                res['n_k_parsed'] += 1
                ef = res['ef_eV']
                if ef is not None:
                    near = sum(1 for e in bands if abs(e - ef) < gap_thr_eV)
                    res['bands_near_ef'] += near
                    below = [e for e in bands if e <= ef]
                    above = [e for e in bands if e > ef]
                    if below and above:
                        gk = min(above) - max(below)
                        min_gap = gk if min_gap is None else min(min_gap, gk)
                if occ:
                    n_frac = sum(1 for o in occ if _OCC_FRAC_LO < o < _OCC_FRAC_HI)
                    res['n_fractional_occ'] += n_frac
                    if bands and len(occ) >= len(bands):
                        occupied = [e for e, o in zip(bands, occ) if o >= 0.5]
                        empty = [e for e, o in zip(bands, occ) if o < 0.5]
                        if occupied and empty:
                            gk = min(empty) - max(occupied)
                            min_gap = gk if min_gap is None else min(min_gap, gk)
            continue
        i += 1
    res['min_gap_eV'] = min_gap
    if res['n_fractional_occ']:
        res['evidence'].append('fractional_occ')
    if res['bands_near_ef']:
        res['evidence'].append('bands_at_ef')
    if min_gap is not None:
        res['evidence'].append('kpoint_gap')

    # Décision : un isolant (gap QE) arrête la chaîne ; un métal la continue.
    # Ne pas confondre le min_gap local (certains k d'un métal ont un gros
    # « gap ») avec un vrai gap de bande imprimé par pw.x.
    thr = float(gap_thr_eV)
    reported_gap = res['gap_eV']
    if res['insulating_flag'] and not res['metallic_flag']:
        res['character'] = 'insulator'
    elif res['metallic_flag']:
        res['character'] = 'metal'
    elif reported_gap is not None and reported_gap >= thr:
        res['character'] = 'insulator'
    elif res['n_fractional_occ'] > 0 or res['bands_near_ef'] > 0:
        res['character'] = 'metal'
    elif min_gap is not None and min_gap >= thr:
        res['character'] = 'insulator'
        if res['gap_eV'] is None:
            res['gap_eV'] = min_gap
    elif min_gap is not None:
        res['character'] = 'metal'
    elif 'homo_only' in res['evidence'] and reported_gap is None:
        res['character'] = 'metal'

    res['should_stop'] = res['character'] == 'insulator'
    return res


#: Fenêtre d'analyse autour de E_F (échelle fsthick / états qui portent le couplage).
FERMI_WINDOW_EV = 0.25
_RE_SMEAR = re.compile(
    r'number of k points\s*=\s*(\d+)[^\n]{0,120}?'
    r'(Methfessel-Paxton|Marzari-Vanderbilt|Fermi-Dirac|Gaussian)'
    r'[^\n]{0,80}?width \(Ry\)=\s*([0-9.]+)',
    re.I,
)


def analyze_fermi_surface(
    text: str,
    window_eV: float = FERMI_WINDOW_EV,
    hist_span_eV: float = 1.0,
    n_bins: int = 41,
) -> Dict[str, Any]:
    """
    Cartographie des états électroniques au voisinage de E_F.

    Les paires de Cooper ne se forment que dans une coquille d'épaisseur
    ~ ħω_D autour de E_F : sans surface de Fermi (métal), pas de Tᶜ
    conventionnelle. On compte les k-points qui portent une bande dans
    ``window_eV``, les occupations fractionnaires, et on histograme E−E_F.
    """
    res: Dict[str, Any] = {
        'ef_eV': None, 'smearing': None, 'degauss_Ry': None, 'n_k_header': None,
        'n_k_parsed': 0, 'n_k_on_fs': 0, 'fs_fraction': None,
        'n_fractional_occ': 0, 'n_bands_near_ef': 0, 'n_bands_total': None,
        'min_abs_e_ef': None, 'window_eV': float(window_eV),
        'hist_e_ef': [], 'hist_counts': [], 'n_states_in_window': 0,
        'character': None, 'ready': False,
    }
    if not text:
        return res

    fermi_hits = list(_RE_FERMI.finditer(text))
    if fermi_hits:
        res['ef_eV'] = _f(fermi_hits[-1].group(1))
    sm = _RE_SMEAR.search(text)
    if sm:
        res['n_k_header'] = int(sm.group(1))
        res['smearing'] = sm.group(2)
        res['degauss_Ry'] = _f(sm.group(3))
    else:
        mk = re.search(r'number of k points\s*=\s*(\d+)', text, re.I)
        if mk:
            res['n_k_header'] = int(mk.group(1))

    ef = res['ef_eV']
    if ef is None:
        return res

    window = _last_scf_window(text)
    lines = window.splitlines()
    i = 0
    band_hits: Set[int] = set()
    n_in_win = 0
    min_abs: Optional[float] = None
    # Histogramme E−E_F ∈ [−hist_span, +hist_span]
    span = float(hist_span_eV)
    edges = [(-span + 2 * span * j / n_bins) for j in range(n_bins + 1)]
    counts = [0] * n_bins

    def _bin(de: float) -> None:
        if abs(de) > span:
            return
        idx = int((de + span) / (2 * span) * n_bins)
        idx = max(0, min(n_bins - 1, idx))
        counts[idx] += 1

    while i < len(lines):
        line = lines[i]
        if re.search(r'bands\s*\(ev\)\s*:', line, re.I):
            bands, i = _parse_float_rows(lines, i + 1)
            while i < len(lines) and not lines[i].strip():
                i += 1
            occ: List[float] = []
            if i < len(lines) and re.search(r'occupation numbers', lines[i], re.I):
                occ, i = _parse_float_rows(lines, i + 1)
            if not bands:
                continue
            res['n_k_parsed'] += 1
            if res['n_bands_total'] is None:
                res['n_bands_total'] = len(bands)
            on_fs = False
            for ib, e in enumerate(bands):
                de = e - ef
                ade = abs(de)
                min_abs = ade if min_abs is None else min(min_abs, ade)
                _bin(de)
                if ade < window_eV:
                    n_in_win += 1
                    band_hits.add(ib)
                    on_fs = True
            if occ:
                res['n_fractional_occ'] += sum(
                    1 for o in occ if _OCC_FRAC_LO < o < _OCC_FRAC_HI)
            if on_fs:
                res['n_k_on_fs'] += 1
            continue
        i += 1

    res['n_bands_near_ef'] = len(band_hits)
    res['n_states_in_window'] = n_in_win
    res['min_abs_e_ef'] = min_abs
    if res['n_k_parsed']:
        res['fs_fraction'] = res['n_k_on_fs'] / res['n_k_parsed']
    centres = [0.5 * (edges[j] + edges[j + 1]) for j in range(n_bins)]
    res['hist_e_ef'] = centres
    res['hist_counts'] = counts
    res['ready'] = res['n_k_parsed'] > 0
    if res['n_k_on_fs'] > 0 or res['n_fractional_occ'] > 0:
        res['character'] = 'metal'
    elif min_abs is not None and min_abs >= window_eV:
        res['character'] = 'insulator'
    return res


def fs_x_input_text(prefix: str, outdir: str = './') -> str:
    """
    Input ``fs.x`` (Quantum ESPRESSO / PP).

    ``fs.x`` écrit un fichier ``.bxsf`` (Band-XSF), le format lu par
    **XCrySDen**, le visualiseur de surface de Fermi utilisé avec QE.
    Prérequis : ``pw.x`` SCF + NSCF sur une grille k *régulière*.
    """
    pref = (prefix or 'pw').strip() or 'pw'
    out = (outdir or './').rstrip('/') + '/'
    return (
        "! Surface de Fermi → XCrySDen (standard QE)\n"
        f"! 1. fs.x < {pref}.fs.in > {pref}.fs.out\n"
        f"! 2. xcrysden --bxsf {pref}.bxsf\n"
        "&fermi\n"
        f"  prefix = '{pref}'\n"
        f"  outdir = '{out}'\n"
        "/\n"
    )


def parse_scf_out(text: str) -> Dict[str, Any]:
    """Grandeurs électroniques utiles d'un ``pw.x`` SCF/NSCF."""
    res: Dict[str, Any] = {
        'ef_eV': None, 'n_electrons': None, 'total_energy_Ry': None,
        'n_atoms': None, 'n_kpoints': None, 'dos_ef': None, 'job_done': False,
    }
    m = _RE_FERMI.search(text)
    if m:
        res['ef_eV'] = _f(m.group(1))
    m = re.search(r'number of electrons\s*=\s*([0-9.]+)', text, re.I)
    if m:
        res['n_electrons'] = _f(m.group(1))
    m = re.search(r'number of atoms/cell\s*=\s*(\d+)', text, re.I)
    if m:
        res['n_atoms'] = int(m.group(1))
    m = re.search(r'number of k points\s*=\s*(\d+)', text, re.I)
    if m:
        res['n_kpoints'] = int(m.group(1))
    for m in re.finditer(r'^!?\s*total energy\s*=\s*([-0-9.]+)\s*Ry', text, re.I | re.M):
        res['total_energy_Ry'] = _f(m.group(1))
    m = _RE_DOS_EF.search(text)
    if m:
        res['dos_ef'] = _f(m.group(1))
    res['job_done'] = bool(re.search(r'JOB DONE', text, re.I))
    cls = classify_electronic_character(text)
    for key in (
        'character', 'should_stop', 'gap_eV', 'homo_eV', 'lumo_eV',
        'insulating_flag', 'metallic_flag', 'n_k_parsed', 'n_fractional_occ',
        'min_gap_eV', 'bands_near_ef', 'evidence', 'gap_thr_eV',
    ):
        res[key] = cls.get(key)
    if res['ef_eV'] is None:
        res['ef_eV'] = cls.get('ef_eV')
    return res


def parse_phonon_dos(text: str, unit: Optional[str] = None) -> Dict[str, Any]:
    """DOS phononique F(ω) écrite par ``matdyn.x`` (``dos=.true.``)."""
    rows = read_columns(text, min_cols=2)
    if not rows:
        return {'omega': [], 'dos': [], 'unit': unit or 'cm-1', 'n_points': 0}
    omega = [r[0] for r in rows]
    dos = [r[1] for r in rows]
    u = unit or guess_frequency_unit(max(omega))
    omega, dos = _downsample_many(MAX_CURVE_POINTS, omega, dos)
    return {'omega': omega, 'dos': dos, 'unit': u, 'n_points': len(omega)}


def parse_freq_gp(text: str, unit: Optional[str] = None) -> Dict[str, Any]:
    """
    Dispersion de phonons au format gnuplot de ``matdyn.x`` (``<prefix>.freq.gp``) :
    première colonne = abscisse le long du chemin q, colonnes suivantes = branches.
    """
    rows = read_columns(text, min_cols=2)
    if not rows:
        return {'q': [], 'bands': [], 'n_modes': 0, 'unit': unit or 'cm-1'}
    n_modes = min(min(len(r) for r in rows) - 1, MAX_BANDS)
    q = [r[0] for r in rows]
    bands = [[r[i + 1] for r in rows] for i in range(n_modes)]
    flat = [v for b in bands for v in b]
    u = unit or guess_frequency_unit(max(flat) if flat else 0.0)
    series = _downsample_many(MAX_CURVE_POINTS, q, *bands)
    return {
        'q': series[0], 'bands': series[1:], 'n_modes': n_modes,
        'unit': u,
        'omega_max': max(flat) if flat else None,
        'omega_min': min(flat) if flat else None,
    }


#: ω[cm⁻¹] = sqrt(w2[Ry²]) × RY_TO_CMM1 — QE écrit ω² en unités atomiques dans
#: les fichiers ``elph.inp_lambda.*`` destinés à ``lambda.x``.
RY_TO_CMM1 = 109737.31570111

_RE_ELPH_MODE = re.compile(
    r'lambda\s*\(\s*(\d+)\s*\)\s*=\s*([0-9.eEdD+-]+)\s*'
    r'(?:gamma\s*=\s*([0-9.eEdD+-]+)\s*(GHz|THz|meV|cm-?1)?)?', re.I)
_RE_ELPH_Q = re.compile(r'q\s*=\s*\(?\s*([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+)', re.I)
_RE_ELPH_SIGMA = re.compile(r'Gaussian Broadening:\s*([0-9.eEdD+-]+)\s*Ry', re.I)


def parse_elph_lambda(text: str) -> Dict[str, Any]:
    """
    Fichier ``elph.inp_lambda.<iq>`` (ou bloc e-p d'un ``ph.out``) : couplage
    λ_qν et largeur de raie γ_qν mode par mode, pour chaque élargissement.

    Renvoie les modes du dernier élargissement rencontré (le plus large), et la
    liste complète des élargissements pour information.
    """
    res: Dict[str, Any] = {
        'q': None, 'sigma_Ry': None, 'dos_ef': None, 'ef_eV': None,
        'modes': [], 'blocks': [], 'freqs_cmm1': [],
    }
    m = _RE_ELPH_Q.search(text)
    if m:
        res['q'] = [_f(m.group(1)), _f(m.group(2)), _f(m.group(3))]
    else:
        res['q'] = _leading_qpoint(text)
    res['freqs_cmm1'] = _leading_frequencies(text)
    m = _RE_DOS_EF.search(text)
    if m:
        res['dos_ef'] = _f(m.group(1))
        res['ef_eV'] = _f(m.group(2))

    # Découpe par élargissement gaussien
    marks = [(mm.start(), _f(mm.group(1))) for mm in _RE_ELPH_SIGMA.finditer(text)]
    spans: List[Tuple[Optional[float], str]] = []
    if marks:
        for i, (pos, sigma) in enumerate(marks):
            end = marks[i + 1][0] if i + 1 < len(marks) else len(text)
            spans.append((sigma, text[pos:end]))
    else:
        spans.append((None, text))

    for sigma, chunk in spans:
        modes = []
        for mm in _RE_ELPH_MODE.finditer(chunk):
            modes.append({
                'mode': int(mm.group(1)),
                'lambda': _f(mm.group(2)),
                'gamma': _f(mm.group(3)),
                'gamma_unit': (mm.group(4) or 'GHz'),
            })
        if modes:
            res['blocks'].append({'sigma_Ry': sigma, 'modes': modes})
    if res['blocks']:
        res['sigma_Ry'] = res['blocks'][-1]['sigma_Ry']
        res['modes'] = res['blocks'][-1]['modes']
    for i, md in enumerate(res['modes']):
        if i < len(res['freqs_cmm1']):
            md['omega_cmm1'] = res['freqs_cmm1'][i]
    return res


def _leading_qpoint(text: str) -> Optional[List[float]]:
    """
    Première ligne numérique d'un ``elph.inp_lambda.*`` : ``qx qy qz nsig``.
    """
    for line in text.splitlines():
        s = line.strip()
        if not s or s[0] in '#!@':
            continue
        parts = s.split()
        if len(parts) not in (3, 4):
            return None
        try:
            vals = [float(p) for p in parts[:3]]
        except ValueError:
            return None
        return vals
    return None


def _leading_frequencies(text: str) -> List[float]:
    """
    Bloc de fréquences suivant le q-point dans ``elph.inp_lambda.*``.
    QE y écrit ω² en Ry² ; on convertit alors en cm⁻¹.
    """
    lines = [l.strip() for l in text.splitlines()]
    vals: List[float] = []
    started = False
    for s in lines:
        if not s or s[0] in '#!@':
            continue
        parts = s.split()
        try:
            nums = [float(p) for p in parts]
        except ValueError:
            if started:
                break
            continue
        if not started:
            started = True          # ligne du q-point
            continue
        if len(nums) > 6:
            break
        vals.extend(nums)
        if len(vals) >= 3 * 64:
            break
    if not vals:
        return []
    peak = max(abs(v) for v in vals)
    if peak < 1.0:                  # ω² en Ry²
        return [math.sqrt(v) * RY_TO_CMM1 if v > 0 else 0.0 for v in vals]
    return vals


# ─────────────────────────────────────────────────────────────────────────────
#  Parseurs — voie EPW
# ─────────────────────────────────────────────────────────────────────────────
def parse_epw_output(text: str) -> Dict[str, Any]:
    """
    Sortie ``epw.out`` avec Éliashberg. Extrait λ, ω_log, μ_c, Tᶜ, Δ(T), le
    caractère iso/anisotrope, et les renormalisations de masse Z si présentes.
    """
    res: Dict[str, Any] = {
        'lambda': None, 'omega_log_K': None, 'omega_log_meV': None,
        'omega_2_K': None, 'tc_K': None, 'tc_interp_K': None,
        'gap_meV': None, 'mu_c': None,
        'z_factor': None, 'temp_gap': [], 'is_anisotropic': None,
        'n_temps': 0, 'fsthick_eV': None, 'nbndsub': None,
    }

    m = re.search(r'Electron-phonon coupling strength\s*=?\s*([0-9.]+)', text, re.I)
    if not m:
        m = re.search(r'\blambda\s*=\s*([0-9.]+)', text, re.I)
    if m:
        res['lambda'] = _f(m.group(1))

    m = re.search(r'Logarithmic average phonon frequency\s*=?\s*([0-9.]+)\s*(meV|K|eV)?', text, re.I)
    if m:
        val = _f(m.group(1))
        unit = (m.group(2) or 'meV')
        if val is not None:
            res['omega_log_meV'] = val if unit.lower() == 'mev' else None
            res['omega_log_K'] = val * unit_factor(unit)
    else:
        m = re.search(r'omega_log\s*=?\s*([0-9.]+)\s*(meV|K)?', text, re.I)
        if m:
            val = _f(m.group(1))
            raw_unit = (m.group(2) or '').strip()
            # Sans unité : EPW imprime souvent Kelvin (ex. 220.5) ; meV typique ≪ 50
            if raw_unit:
                unit = raw_unit
            elif val is not None and val >= 30.0:
                unit = 'K'
            else:
                unit = 'meV'
            if val is not None:
                res['omega_log_K'] = val * unit_factor(unit)
                if unit.lower() == 'mev':
                    res['omega_log_meV'] = val

    m = re.search(r'Estimated Allen-Dynes Tc\s*=?\s*([0-9.]+)\s*K', text, re.I)
    if m:
        res['tc_K'] = _f(m.group(1))

    m = re.search(r'muc\s*=\s*([0-9.]+)', text, re.I) or re.search(r'mu_?c\s*=\s*([0-9.]+)', text, re.I)
    if m:
        res['mu_c'] = _f(m.group(1))
    m = re.search(r'fsthick\s*=\s*([0-9.]+)', text, re.I)
    if m:
        res['fsthick_eV'] = _f(m.group(1))
    m = re.search(r'nbndsub\s*=\s*(\d+)', text, re.I)
    if m:
        res['nbndsub'] = int(m.group(1))

    if re.search(r'laniso\s*=\s*\.?true', text, re.I) or re.search(r'anisotropic', text, re.I):
        res['is_anisotropic'] = True
    elif re.search(r'liso\s*=\s*\.?true', text, re.I) or re.search(r'isotropic', text, re.I):
        res['is_anisotropic'] = False

    # Δ(T) : lignes « temp = 5.00 K  ...  Delta = 1.234 meV » sous des formes variées
    pairs: List[List[float]] = []
    for m in re.finditer(
            r'temp(?:erature)?\s*=?\s*([0-9.]+)\s*K[^\n]*?'
            r'(?:max\s*)?(?:Delta|gap|Δ)\s*=?\s*([0-9.]+)\s*(meV|eV)?',
            text, re.I):
        t = _f(m.group(1))
        g = _f(m.group(2))
        if t is None or g is None:
            continue
        if (m.group(3) or 'meV').lower() == 'ev':
            g *= 1000.0
        pairs.append([t, g])
    if not pairs:
        # Tables « T (K)  Delta (meV) » : deux colonnes numériques après un en-tête
        block = re.search(r'(?:Delta|gap)[^\n]*\(meV\)[^\n]*\n((?:\s*[0-9.eEdD+-]+\s+[0-9.eEdD+-]+\s*\n)+)',
                          text, re.I)
        if block:
            for row in read_columns(block.group(1), min_cols=2):
                pairs.append([row[0], row[1]])
    if pairs:
        pairs.sort(key=lambda p: p[0])
        res['temp_gap'] = pairs
        res['n_temps'] = len(pairs)
        res['gap_meV'] = pairs[0][1]
        res['tc_interp_K'] = _tc_from_gap_curve(pairs)
        if res['tc_K'] is None:
            # Convention : plus haute température où le gap est encore ouvert
            open_gap = [t for t, g in pairs if g > 1e-3]
            res['tc_K'] = max(open_gap) if open_gap else None
    if res['tc_K'] is None:
        m = re.search(r'\bTc\s*=\s*([0-9.]+)\s*K', text, re.I)
        if m:
            res['tc_K'] = _f(m.group(1))

    m = re.search(r'Z\s*\(\s*0\s*\)\s*=?\s*([0-9.]+)', text, re.I)
    if m:
        res['z_factor'] = _f(m.group(1))
    elif res['lambda']:
        res['z_factor'] = 1.0 + res['lambda']   # Z(0) = 1 + λ en couplage faible
    return res


def _tc_from_gap_curve(pairs: Sequence[Sequence[float]]) -> Optional[float]:
    """
    Tᶜ = température d'annulation du gap : dernière T où Δ > 1 % de Δ(T→0),
    interpolée linéairement avec la première température où le gap s'effondre.
    """
    if len(pairs) < 2:
        return None
    gap0 = pairs[0][1]
    if gap0 <= 0:
        return None
    thresh = 0.01 * gap0
    prev = pairs[0]
    for cur in pairs[1:]:
        if cur[1] <= thresh:
            if prev[1] == cur[1]:
                return cur[0]
            frac = (prev[1] - thresh) / (prev[1] - cur[1])
            return prev[0] + frac * (cur[0] - prev[0])
        prev = cur
    return pairs[-1][0]


def parse_gap_distribution(text: str, bins: int = 40) -> Dict[str, Any]:
    """
    Distribution du gap sur la surface de Fermi (fichiers ``*imag_aniso_gap0*``
    ou ``*_aniso_gap0_*`` d'EPW) : histogramme des valeurs de Δ_k.

    Le format usuel est « énergie  Δ » ou une simple colonne de Δ ; on prend la
    dernière colonne numérique de chaque ligne comme valeur de gap.
    """
    rows = read_columns(text, min_cols=1)
    vals = [r[-1] for r in rows if r and math.isfinite(r[-1])]
    vals = [v for v in vals if v > 0]
    if len(vals) < 5:
        return {'n_values': len(vals), 'bins': [], 'counts': [],
                'gap_min': None, 'gap_max': None, 'gap_mean': None}
    lo, hi = min(vals), max(vals)
    if hi <= lo:
        hi = lo + 1e-6
    width = (hi - lo) / bins
    counts = [0] * bins
    for v in vals:
        i = min(int((v - lo) / width), bins - 1)
        counts[i] += 1
    centres = [lo + (i + 0.5) * width for i in range(bins)]
    mean = sum(vals) / len(vals)
    return {
        'n_values': len(vals), 'bins': centres, 'counts': counts,
        'gap_min': lo, 'gap_max': hi, 'gap_mean': mean,
        'n_sheets': _count_sheets(counts),
    }


def _count_sheets(counts: Sequence[int]) -> int:
    """
    Nombre de groupes de gap séparés dans l'histogramme ≈ nombre de feuillets
    de la surface de Fermi portant un gap distinct (deux pour un supraconducteur
    à deux gaps comme MgB₂).

    On compte les amas contigus de classes peuplées plutôt que les maxima
    locaux : un plateau au sommet d'un amas ne doit compter que pour un.
    """
    top = max(counts) if counts else 0
    if top <= 0:
        return 0
    thresh = 0.15 * top
    clusters = 0
    inside = False
    for c in counts:
        if c >= thresh and c > 0:
            if not inside:
                clusters += 1
                inside = True
        else:
            inside = False
    return clusters


def parse_xy(text: str, x_col: int = 0, y_col: int = 1) -> Dict[str, Any]:
    """Courbe générique à deux colonnes (specfun, decay, pbnd…)."""
    rows = read_columns(text, min_cols=max(x_col, y_col) + 1)
    if not rows:
        return {'x': [], 'y': [], 'n_points': 0}
    x = [r[x_col] for r in rows]
    y = [r[y_col] for r in rows]
    x, y = _downsample_many(MAX_CURVE_POINTS, x, y)
    return {'x': x, 'y': y, 'n_points': len(x)}


def parse_lambda_pairs(text: str) -> Dict[str, Any]:
    """
    Fichier EPW ``*.lambda_pairs`` (ou voisin) : points (ω, λ).
    Formats usuels : (ω, λ) · (iq, imode, ω, λ) · (…, ω, λ).
    """
    rows = read_columns(text, min_cols=2)
    points: List[Dict[str, float]] = []
    for r in rows:
        if len(r) >= 4:
            om, lam = r[2], r[3]
        elif len(r) >= 3:
            om, lam = r[1], r[2]
        else:
            om, lam = r[0], r[1]
        if om is None or lam is None:
            continue
        points.append({'omega': float(om), 'lambda': float(lam)})
    if len(points) > 4000:
        step = max(1, len(points) // 4000)
        points = points[::step]
    return {'points': points, 'n_points': len(points)}


def frequency_unit_for(name: str) -> Optional[str]:
    """
    Unité de l'axe ω selon le producteur du fichier : ``matdyn.x``/``lambda.x``
    écrivent en cm⁻¹, EPW en meV.
    """
    n = name.lower()
    if n.endswith('.a2f') or '.a2f_' in n or n.endswith('.phdos') or 'a2f_iso' in n:
        return 'meV'
    if 'a2f' in n or n.endswith('.dos') or 'freq' in n:
        return 'cm-1'
    return None


def parse_a2f_table(text: str, unit_hint: Optional[str] = None) -> Dict[str, Any]:
    """
    Fichier α²F : 2 colonnes (ω, α²F) ou 3+ (ω, α²F, λ(ω)).

    QE écrit un fichier par élargissement (``a2F.dos1`` … ``a2F.dos10``) ; EPW
    écrit ``<prefix>.a2f`` dont les colonnes suivantes correspondent aussi à des
    élargissements croissants. Dans les deux cas la colonne 2 est retenue et les
    éventuelles colonnes supplémentaires sont exposées telles quelles.
    """
    rows = read_columns(text, min_cols=2)
    if not rows:
        return {'omega': [], 'a2f': [], 'lambda_w': [], 'n_points': 0,
                'unit': unit_hint or 'cm-1', 'n_columns': 0}
    ncol = min(len(r) for r in rows)
    omega = [r[0] for r in rows]
    a2f = [r[1] for r in rows]
    lam_w = [r[2] for r in rows] if ncol > 2 else []
    unit = unit_hint or guess_frequency_unit(max(omega))
    if lam_w:
        omega, a2f, lam_w = _downsample_many(MAX_CURVE_POINTS, omega, a2f, lam_w)
    else:
        omega, a2f = _downsample_many(MAX_CURVE_POINTS, omega, a2f)
    return {'omega': omega, 'a2f': a2f, 'lambda_w': lam_w,
            'n_points': len(omega), 'unit': unit, 'n_columns': ncol}


# ─────────────────────────────────────────────────────────────────────────────
#  Découverte des fichiers de résultats
# ─────────────────────────────────────────────────────────────────────────────
#: Motifs de fichiers recherchés par voie. `{mat}` est remplacé par le nom du
#: matériau (= prefix QE). L'ordre compte : le premier fichier trouvé sert de
#: source principale, les suivants restent listés dans l'inventaire.
FILE_PATTERNS: Dict[str, List[Tuple[str, str, List[str]]]] = {
    'classic': [
        ('scf_out',    'pw.x SCF',                 ['{mat}.scf.out', 'scf.out']),
        ('nscf_out',   'pw.x NSCF (grille dense)', ['{mat}.nscf.out', 'nscf.out']),
        ('ph_out',     'ph.x + elph',              ['{mat}.ph.out', 'ph.out']),
        ('q2r_out',    'q2r.x',                    ['{mat}.q2r.out', 'q2r.out']),
        ('matdyn_out', 'matdyn.x (λ, ω_log)',      ['{mat}.matdyn.out', 'matdyn.out']),
        ('lambda_out', 'lambda.x',                 ['{mat}.lambda.out', 'lambda.out',
                                                    '{mat}.alpha2f.out', 'alpha2f.out']),
        ('a2f',        'α²F(ω)',                   ['a2F.dat', '{mat}.a2F.dat',
                                                    'a2F_smooth.dat', 'a2F.dos*']),
        ('phdos',      'F(ω) — DOS phononique',    ['phonon.dos', '{mat}.phonon.dos', '{mat}.dos']),
        ('freq',       'Dispersion ω(q)',          ['freq.gp', '{mat}.freq.gp', '{mat}.freq']),
        ('elph',       'γ_qν / λ_qν par mode',     ['elph_dir/elph.inp_lambda.*',
                                                    'elph.inp_lambda.*', '{mat}.elph.*']),
        ('dyn',        'Matrices dynamiques',      ['matdyn*', '{mat}.dyn*']),
        ('modes',      'Vecteurs propres',         ['matdyn.modes', '{mat}.modes']),
        ('bxsf',       'Surface de Fermi (XCrySDen .bxsf)', ['{mat}.bxsf', '*.bxsf']),
        ('fs_in',      'fs.x input',               ['{mat}.fs.in', 'fs.in']),
        ('fs_out',     'fs.x (export BXSF)',       ['{mat}.fs.out', 'fs.out']),
    ],
    'epw': [
        ('scf_out',   'pw.x SCF',                  ['{mat}.scf.out', 'scf.out']),
        ('nscf_out',  'pw.x NSCF coarse',          ['{mat}.nscf.out', 'nscf.out']),
        ('ph_out',    'ph.x (dvscf + dyn)',        ['{mat}.ph.out', 'ph.out']),
        ('epw_out',   'epw.x (Wannier + Éliashberg)', ['{mat}.epw.out', 'epw.out', 'epw1.out']),
        ('a2f',       'α²F(ω) interpolé',          ['{mat}.a2f', '{mat}.a2f_iso',
                                                    '{mat}.a2F.dat']),
        ('phdos',     'F(ω) interpolé',            ['{mat}.phdos', '{mat}.phdos_proj',
                                                    'phonon.dos']),
        ('gap_aniso', 'Δ_k anisotrope sur la SF',  ['{mat}.imag_aniso_gap0_*', '{mat}.imag_aniso_*',
                                                    '{mat}.pade_aniso_gap0_*', '{mat}.acon_aniso_*']),
        ('gap_iso',   'Δ(T) isotrope',             ['{mat}.imag_iso_*', '{mat}.pade_iso_*',
                                                    '{mat}.gap*']),
        ('lambda_pairs', 'λ(q,ν) EPW',             ['{mat}.lambda_pairs', '{mat}.lambda_k_pairs',
                                                    'lambda.phself*']),
        ('specfun',   'Self-énergie / fonction spectrale', ['specfun.elself*', 'specfun_sup.elself*',
                                                            '{mat}.specfun*', 'linewidth.elself*']),
        ('decay',     'Décroissance Wannier',      ['decay.dynmat', 'decay.epmat', 'decay.el']),
        ('pbnd',      'Dispersion renormalisée',   ['pbnd.dat', '{mat}_band.dat', 'band.eig',
                                                    '{mat}.pbnd*']),
        ('bxsf',      'Surface de Fermi (XCrySDen .bxsf)', ['{mat}.bxsf', '*.bxsf']),
        ('fs_in',     'fs.x input',               ['{mat}.fs.in', 'fs.in']),
        ('frmsf',     'Surface de Fermi (FermiSurfer)', ['{mat}.frmsf', '*.frmsf']),
    ],
}

#: Fichiers volumineux (ou binaires de visualisation) : on les référence sans parser.
_INVENTORY_ONLY = {'dyn', 'modes', 'bxsf', 'frmsf'}


def candidate_dirs(material: str, workflow: str, inputs_dir: Path,
                   outputs_dir: Path) -> List[Path]:
    """
    Répertoires où chercher les sorties : QE tourne dans ``inputs/<mat>/<wf>/``
    mais écrit son ``outdir`` dans ``outputs/<mat>/<wf>/`` ; certains fichiers
    atterrissent aussi à la racine du matériau.
    """
    dirs = [
        outputs_dir / material / workflow,
        inputs_dir / material / workflow,
        outputs_dir / material,
        inputs_dir / material,
    ]
    seen: List[Path] = []
    for d in dirs:
        if d.is_dir() and d not in seen:
            seen.append(d)
    return seen


def _a2f_preference_key(path: Path) -> Tuple[int, int, str]:
    """
    Ordre de préférence α²F : fichier lissé / dat d'abord, sinon plus grand
    indice ``a2F.dosN`` (élargissement large, convention lambda.x).
    """
    name = path.name
    low = name.lower()
    if 'smooth' in low:
        return (0, 0, low)
    if low in ('a2f.dat',) or low.endswith('.a2f.dat') or low.endswith('.a2f'):
        return (1, 0, low)
    m = re.search(r'a2f\.dos(\d+)$', low) or re.search(r'\.dos(\d+)$', low)
    if m:
        return (2, -int(m.group(1)), low)  # dos10 avant dos1
    return (3, 0, low)


def _sort_a2f_hits(hits: List[Path]) -> List[Path]:
    return sorted(hits, key=_a2f_preference_key)


def _gamma_to_ghz(value: Optional[float], unit: Optional[str]) -> Optional[float]:
    """Normalise γ_qν vers GHz pour la synthèse."""
    if value is None:
        return None
    u = (unit or 'GHz').strip().lower()
    if u in ('ghz',):
        return value
    if u in ('thz',):
        return value * 1000.0
    if u in ('mhz',):
        return value / 1000.0
    if u in ('cm-1', 'cm⁻¹', 'cmm1'):
        # 1 cm⁻¹ ≈ 29.979 GHz
        return value * 29.9792458
    # Unité inconnue : conserver la valeur (étiquette synthèse = GHz)
    return value


def _gap_aniso_temp_key(path: Path) -> Tuple[float, str]:
    """Préfère le fichier aniso à la plus basse T (gap ≈ Δ₀)."""
    m = re.search(r'_(\d+(?:\.\d+)?)\s*$', path.stem)
    if m:
        return (float(m.group(1)), path.name.lower())
    return (1e9, path.name.lower())


def _text_job_flags(text: str) -> Tuple[bool, bool]:
    """(job_done, has_error) sur une queue de sortie QE."""
    tail = text[-8000:] if len(text) > 8000 else text
    done = bool(re.search(r'JOB DONE', tail, re.I))
    err = bool(re.search(
        r'%%%%%%%%%%%%|Error in routine|stopping \.\.\.|MPI_Abort|SIGSEGV',
        tail, re.I))
    return done, err


def _find_files(dirs: Sequence[Path], patterns: Sequence[str],
                material: str) -> List[Path]:
    """Résout les motifs (avec `*`) dans l'ordre des répertoires candidats."""
    found: List[Path] = []
    for d in dirs:
        for pat in patterns:
            pat = pat.replace('{mat}', material)
            try:
                matches = sorted(d.glob(pat)) if any(c in pat for c in '*?[') else \
                          ([d / pat] if (d / pat).is_file() else [])
            except OSError:
                matches = []
            for p in matches:
                if p.is_file() and p not in found:
                    found.append(p)
    return found


def _rel(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)


def _read(path: Path, max_bytes: int = 12_000_000) -> str:
    """Lecture texte plafonnée (les .out d'EPW peuvent atteindre des centaines de Mo)."""
    size = path.stat().st_size
    with path.open('r', encoding='utf-8', errors='replace') as fh:
        if size <= max_bytes:
            return fh.read()
        head = fh.read(max_bytes // 2)
        fh.seek(max(size - max_bytes // 2, 0))
        return head + '\n' + fh.read()


# ─────────────────────────────────────────────────────────────────────────────
#  Agrégation : tout ce qui est exploitable pour un matériau
# ─────────────────────────────────────────────────────────────────────────────
def explore_route(material: str, workflow: str, inputs_dir: Path, outputs_dir: Path,
                  repo_root: Path, mu_stars: Iterable[float] = DEFAULT_MU_STARS) -> Dict[str, Any]:
    """
    Inventorie et exploite tous les résultats d'une voie (`classic` ou `epw`).

    Renvoie un dictionnaire à quatre volets : `inventory` (fichiers vus),
    `scalars` (grandeurs + provenance), `curves` (données à tracer) et
    `tc_table` (Tᶜ pour chaque μ*).
    """
    dirs = candidate_dirs(material, workflow, inputs_dir, outputs_dir)
    specs = FILE_PATTERNS.get(workflow, [])
    inventory: List[Dict[str, Any]] = []
    files: Dict[str, List[Path]] = {}
    notes: List[str] = []

    for key, label, patterns in specs:
        hits = _find_files(dirs, patterns, material)
        if key == 'a2f' and hits:
            hits = _sort_a2f_hits(hits)
        elif key == 'gap_aniso' and hits:
            hits = sorted(hits, key=_gap_aniso_temp_key)
        if key == 'scf_out' and not hits:
            other = 'epw' if workflow == 'classic' else 'classic'
            extra = [p for p in (
                outputs_dir / material / other,
                inputs_dir / material / other,
            ) if p.is_dir()]
            hits = _find_files(extra, patterns, material)
            if hits:
                notes.append(
                    f"SCF repris de la voie {other} (même calcul de départ, densité partagée).")
        files[key] = hits
        for p in hits:
            try:
                st = p.stat()
            except OSError:
                continue
            entry: Dict[str, Any] = {
                'key': key, 'label': label, 'name': p.name,
                'path': _rel(p, repo_root), 'size': st.st_size,
                'mtime': st.st_mtime, 'parsed': key not in _INVENTORY_ONLY,
            }
            if key.endswith('_out') or key == 'epw_out':
                try:
                    done, err = _text_job_flags(_read(p, max_bytes=200_000))
                    entry['job_done'] = done
                    entry['has_error'] = err
                    if not done:
                        msg = (f"⚠️ {p.name} sans « JOB DONE » — grandeurs extraites "
                               "à traiter avec prudence.")
                        if msg not in notes and sum(1 for n in notes if 'JOB DONE' in n) < 4:
                            notes.append(msg)
                    if err:
                        msg = f"⚠️ {p.name} signale une erreur QE."
                        if msg not in notes:
                            notes.append(msg)
                except OSError:
                    pass
            inventory.append(entry)

    scalars: Dict[str, Any] = {}
    prov: Dict[str, str] = {}
    curves: Dict[str, Any] = {}

    def put(name: str, value: Any, source: Optional[Path] = None) -> None:
        """N'écrase pas une valeur déjà renseignée par une source plus fiable."""
        if value is None or scalars.get(name) is not None:
            return
        scalars[name] = value
        if source is not None:
            prov[name] = _rel(source, repo_root)

    def first(key: str) -> Optional[Path]:
        lst = files.get(key) or []
        return lst[0] if lst else None

    # ── α²F(ω) : source des moments (λ, ω_log, ⟨ω²⟩^½, λ(ω)) ────────────────
    a2f_path = first('a2f')
    if a2f_path:
        tab = parse_a2f_table(_read(a2f_path), frequency_unit_for(a2f_path.name))
        if tab['n_points'] >= 3:
            mom = a2f_moments(tab['omega'], tab['a2f'], tab['unit'])
            curves['a2f'] = {
                'omega': tab['omega'], 'a2f': tab['a2f'], 'unit': tab['unit'],
                'lambda_w': mom['lambda_w'] or tab['lambda_w'],
                'omega_K': mom['omega_K'],
                'n_points': tab['n_points'],
                'source': _rel(a2f_path, repo_root),
                'n_columns': tab['n_columns'],
            }
            put('lambda', mom['lambda'], a2f_path)
            put('omega_log_K', mom['omega_log_K'], a2f_path)
            put('omega_2_K', mom['omega_2_K'], a2f_path)
            put('lambda_source', 'moments de α²F(ω)')
            if len(files.get('a2f') or []) > 1:
                notes.append(
                    f"{len(files['a2f'])} fichiers α²F détectés (élargissements gaussiens) : "
                    f"moments calculés sur {a2f_path.name}.")

    # ── voie classique : matdyn.x / lambda.x / ph.x ─────────────────────────
    if workflow == 'classic':
        for key in ('matdyn_out', 'lambda_out'):
            p = first(key)
            if not p:
                continue
            lam = parse_lambda_out(_read(p))
            put('lambda', lam.get('lambda'), p)
            put('omega_log_K', lam.get('omega_log_K'), p)
            put('dos_ef', lam.get('dos_ef'), p)
            put('ef_eV', lam.get('ef_eV'), p)
            put('tc_reported_K', lam.get('tc_K'), p)
            put('mu_star_reported', lam.get('mu_star'), p)
            if lam.get('broadenings'):
                curves.setdefault('broadenings', {
                    'source': _rel(p, repo_root),
                    'rows': lam['broadenings'],
                })

        p = first('phdos')
        if p:
            dos = parse_phonon_dos(_read(p), frequency_unit_for(p.name))
            if dos['n_points']:
                dos['source'] = _rel(p, repo_root)
                curves['phdos'] = dos

        p = first('freq')
        if p:
            disp = parse_freq_gp(_read(p))
            if disp['n_modes']:
                disp['source'] = _rel(p, repo_root)
                curves['dispersion'] = disp
                if disp.get('omega_min') is not None:
                    put('omega_min', disp['omega_min'], p)
                    scalars['omega_min_unit'] = disp.get('unit') or 'cm-1'
                    if disp['omega_min'] < -1e-6:
                        scalars['soft_modes'] = True
                        notes.append(
                            f"Mode(s) mou(s) : ω_min = {disp['omega_min']:.2f} "
                            f"{disp.get('unit') or 'cm-1'} dans {p.name}. "
                            "Vérifie la stabilité phononique avant d'interpréter Tᶜ.")

        elph_files = files.get('elph') or []
        if elph_files:
            modes_all: List[Dict[str, Any]] = []
            qpoints: List[Dict[str, Any]] = []
            for p in elph_files[:400]:
                el = parse_elph_lambda(_read(p, max_bytes=4_000_000))
                if not el['modes']:
                    continue
                qpoints.append({
                    'q': el['q'], 'sigma_Ry': el['sigma_Ry'],
                    'file': p.name,
                    'lambda_sum': sum(m['lambda'] or 0.0 for m in el['modes']),
                    'modes': el['modes'],
                })
                for m in el['modes']:
                    if m.get('omega_cmm1') is not None:
                        modes_all.append({
                            'omega_cmm1': m['omega_cmm1'],
                            'lambda': m.get('lambda'),
                            'gamma': m.get('gamma'),
                            'gamma_unit': m.get('gamma_unit'),
                            'mode': m.get('mode'),
                        })
                put('dos_ef', el.get('dos_ef'), p)
                put('ef_eV', el.get('ef_eV'), p)
            if qpoints:
                curves['elph'] = {
                    'n_qpoints': len(qpoints), 'qpoints': qpoints[:200],
                    'modes': modes_all[:4000],
                    'source': _rel(elph_files[0].parent, repo_root),
                }
                gammas_ghz = [
                    _gamma_to_ghz(m['gamma'], m.get('gamma_unit'))
                    for m in modes_all if m.get('gamma') is not None
                ]
                gammas_ghz = [g for g in gammas_ghz if g is not None]
                if gammas_ghz:
                    put('gamma_max', max(gammas_ghz), elph_files[0])
                lams = [m['lambda'] for m in modes_all if m.get('lambda')]
                if lams:
                    put('lambda_qnu_max', max(lams), elph_files[0])

    # ── voie EPW ────────────────────────────────────────────────────────────
    if workflow == 'epw':
        p = first('epw_out')
        if p:
            ep = parse_epw_output(_read(p))
            put('lambda', ep.get('lambda'), p)
            put('omega_log_K', ep.get('omega_log_K'), p)
            put('omega_2_K', ep.get('omega_2_K'), p)
            put('tc_reported_K', ep.get('tc_K'), p)
            put('tc_interp_K', ep.get('tc_interp_K'), p)
            put('gap_meV', ep.get('gap_meV'), p)
            put('mu_star_reported', ep.get('mu_c'), p)
            put('z_factor', ep.get('z_factor'), p)
            put('fsthick_eV', ep.get('fsthick_eV'), p)
            put('nbndsub', ep.get('nbndsub'), p)
            scalars['is_anisotropic'] = ep.get('is_anisotropic')
            if ep.get('temp_gap'):
                curves['gap_vs_T'] = {
                    'pairs': ep['temp_gap'], 'n_points': ep['n_temps'],
                    'source': _rel(p, repo_root),
                }
            # BCS : préférer Tᶜ Éliashberg (fermeture du gap) si disponible
            r = bcs_ratio(ep.get('gap_meV'),
                          ep.get('tc_interp_K') or ep.get('tc_K'))
            put('bcs_ratio', r, p)

        p = first('gap_aniso')
        if p:
            hist = parse_gap_distribution(_read(p, max_bytes=6_000_000))
            if hist['n_values']:
                hist['source'] = _rel(p, repo_root)
                hist['n_files'] = len(files['gap_aniso'])
                curves['gap_distribution'] = hist
                put('gap_mean_meV', hist['gap_mean'], p)
                put('gap_min_meV', hist.get('gap_min'), p)
                put('gap_max_meV', hist.get('gap_max'), p)
                put('gap_spread_meV',
                    (hist['gap_max'] - hist['gap_min']) if hist.get('gap_max') is not None
                    and hist.get('gap_min') is not None else None, p)
                if hist.get('n_sheets') is not None:
                    scalars['n_gap_sheets'] = hist['n_sheets']

        p = first('phdos')
        if p:
            dos = parse_phonon_dos(_read(p), frequency_unit_for(p.name))
            if dos['n_points']:
                dos['source'] = _rel(p, repo_root)
                curves['phdos'] = dos

        p = first('specfun')
        if p:
            xy = parse_xy(_read(p, max_bytes=6_000_000))
            if xy['n_points']:
                xy['source'] = _rel(p, repo_root)
                curves['specfun'] = xy

        p = first('pbnd')
        if p:
            xy = parse_xy(_read(p, max_bytes=6_000_000))
            if xy['n_points']:
                xy['source'] = _rel(p, repo_root)
                curves['pbnd'] = xy

        decay_files = files.get('decay') or []
        decay_series: List[Dict[str, Any]] = []
        for dp in decay_files[:6]:
            xy = parse_xy(_read(dp))
            if xy['n_points']:
                decay_series.append({
                    **xy, 'name': dp.name, 'source': _rel(dp, repo_root),
                })
        if decay_series:
            curves['decay'] = {'series': decay_series, 'n_series': len(decay_series)}

        p = first('lambda_pairs')
        if p:
            lp = parse_lambda_pairs(_read(p, max_bytes=8_000_000))
            if lp['n_points']:
                lp['source'] = _rel(p, repo_root)
                curves['lambda_pairs'] = lp

    # ── électronique : N(E_F), E_F, nombre d'électrons ──────────────────────
    for key in ('nscf_out', 'scf_out'):
        p = first(key)
        if not p:
            continue
        el = parse_scf_out(_read(p))
        put('ef_eV', el.get('ef_eV'), p)
        put('n_electrons', el.get('n_electrons'), p)
        put('total_energy_Ry', el.get('total_energy_Ry'), p)
        put('n_atoms', el.get('n_atoms'), p)
        put('dos_ef', el.get('dos_ef'), p)
        put('n_kpoints', el.get('n_kpoints'), p)
        if el.get('character') in ('metal', 'insulator'):
            put('character', el.get('character'), p)
            put('gap_eV', el.get('gap_eV'), p)
            if el.get('should_stop'):
                notes.append(
                    "SCF : gap électronique — matériau non métallique ; "
                    "pas de surface de Fermi, donc pas de paires de Cooper / Tᶜ.")
        if 'fermi' not in curves:
            fs = analyze_fermi_surface(_read(p))
            if fs.get('ready'):
                fs['source'] = _rel(p, repo_root)
                curves['fermi'] = fs
                put('n_k_on_fs', fs.get('n_k_on_fs'), p)
                put('fs_fraction', fs.get('fs_fraction'), p)
                put('n_bands_near_ef', fs.get('n_bands_near_ef'), p)
                put('n_states_in_window', fs.get('n_states_in_window'), p)
                put('degauss_Ry', fs.get('degauss_Ry'), p)
                if fs.get('smearing'):
                    scalars['smearing'] = fs['smearing']
                if fs.get('character') == 'insulator':
                    notes.append(
                        "Aucun état dans la fenêtre ±"
                        f"{fs['window_eV']:.2f} eV autour de E_F : "
                        "la surface de Fermi n'est pas échantillonnée.")
                elif fs.get('fs_fraction') is not None and fs['fs_fraction'] < 0.05:
                    notes.append(
                        f"Surface de Fermi peu échantillonnée "
                        f"({fs['n_k_on_fs']}/{fs['n_k_parsed']} k-points dans "
                        f"±{fs['window_eV']:.2f} eV) : densifier la grille k NSCF.")

    bxsf_path = first('bxsf')
    frmsf_path = first('frmsf') if workflow == 'epw' else None
    fs_in_path = first('fs_in')
    out_guess = str(dirs[0]) if dirs else f'outputs/{material}/{workflow}/'
    if fs_in_path and fs_in_path.is_file():
        try:
            fs_in_text = _read(fs_in_path, max_bytes=64_000)
        except OSError:
            fs_in_text = fs_x_input_text(material, out_guess)
    else:
        fs_in_text = fs_x_input_text(material, out_guess)
    viz = {
        'ready': bool(bxsf_path),
        'bxsf': _rel(bxsf_path, repo_root) if bxsf_path else None,
        'frmsf': _rel(frmsf_path, repo_root) if frmsf_path else None,
        'viewer': 'xcrysden',
        'command': (
            f"xcrysden --bxsf {bxsf_path.name}" if bxsf_path
            else f"xcrysden --bxsf {material}.bxsf"),
        'fs_in': fs_in_text,
        'fs_in_name': f'{material}.fs.in',
        'fs_in_path': _rel(fs_in_path, repo_root) if fs_in_path else None,
    }
    if bxsf_path or frmsf_path or curves.get('fermi') or first('scf_out') or first('nscf_out'):
        curves['fermi_viz'] = viz

    # ── Tᶜ pour la série de μ* ──────────────────────────────────────────────
    tc_table = tc_sweep(scalars.get('lambda'), scalars.get('omega_log_K'),
                        scalars.get('omega_2_K'), mu_stars)
    if scalars.get('omega_log_K'):
        scalars['omega_log_meV'] = scalars['omega_log_K'] / K_PER_MEV
        scalars['omega_log_cmm1'] = scalars['omega_log_K'] / K_PER_CM1
    if scalars.get('omega_2_K'):
        scalars['omega_2_meV'] = scalars['omega_2_K'] / K_PER_MEV
        scalars['omega_ratio'] = scalars['omega_2_K'] / scalars['omega_log_K'] \
            if scalars.get('omega_log_K') else None
    # f₁, f₂ à μ*=0.13 (référence courante pour comparer les voies)
    mu_f = 0.13
    f1, f2 = allen_dynes_factors(
        scalars.get('lambda'), scalars.get('omega_log_K'), mu_f,
        scalars.get('omega_2_K'))
    if f1 is not None:
        scalars['f1'] = f1
        scalars['f2'] = f2
        scalars['mu_star_for_f'] = mu_f
    if scalars.get('gap_meV') and not scalars.get('bcs_ratio'):
        ref_tc = (scalars.get('tc_interp_K') or scalars.get('tc_reported_K')
                  or (tc_table[0]['tc_allen_dynes_K'] if tc_table else None))
        scalars['bcs_ratio'] = bcs_ratio(scalars['gap_meV'], ref_tc)

    if not scalars.get('lambda'):
        notes.append("λ introuvable : lance matdyn.x/lambda.x (voie classique) ou "
                     "epw.x avec eliashberg=.true. (voie EPW), ou vérifie le fichier α²F.")
    if scalars.get('lambda') and not scalars.get('omega_2_K'):
        notes.append("⟨ω²⟩^½ indisponible (pas de fichier α²F exploitable) : "
                     "la correction f₂ d'Allen-Dynes est prise égale à 1.")

    progress = []
    for key, lab, _pat in specs:
        if not key.endswith('_out') and key != 'epw_out':
            continue
        hits = files.get(key) or []
        inv_hits = [e for e in inventory if e['key'] == key]
        done = any(e.get('job_done') for e in inv_hits)
        err = any(e.get('has_error') for e in inv_hits)
        progress.append({
            'key': key, 'label': lab,
            'exists': bool(hits), 'done': done, 'has_error': err,
            'path': _rel(hits[0], repo_root) if hits else None,
        })

    return {
        'workflow': workflow,
        'dirs': [_rel(d, repo_root) for d in dirs],
        'inventory': inventory,
        'progress': progress,
        'scalars': scalars,
        'provenance': prov,
        'curves': curves,
        'tc_table': tc_table,
        'notes': notes,
        'has_data': bool(scalars) or bool(curves) or bool(inventory),
    }


def explore_results(material: str, inputs_dir: Path, outputs_dir: Path,
                    repo_root: Path,
                    mu_stars: Iterable[float] = DEFAULT_MU_STARS) -> Dict[str, Any]:
    """Explore les deux voies et construit le tableau de synthèse comparatif."""
    mu_list = [round(float(m), 4) for m in mu_stars]
    routes = {wf: explore_route(material, wf, inputs_dir, outputs_dir, repo_root, mu_list)
              for wf in ('classic', 'epw')}
    return {
        'ok': True,
        'material': material,
        'mu_stars': mu_list,
        'classic': routes['classic'],
        'epw': routes['epw'],
        'synthesis': build_synthesis(routes, mu_list),
    }


#: Lignes du tableau de synthèse : (clé, libellé, unité, nombre de décimales).
SYNTHESIS_ROWS: List[Tuple[str, str, str, int]] = [
    ('lambda',         'λ (couplage é-ph)',              '',      3),
    ('omega_log_K',    'ω_log',                          'K',     1),
    ('omega_log_meV',  'ω_log',                          'meV',   2),
    ('omega_2_K',      '⟨ω²⟩^½',                         'K',     1),
    ('omega_ratio',    '⟨ω²⟩^½ / ω_log',                 '',      3),
    ('f1',             'f₁ Allen–Dynes (μ*=0.13)',       '',      3),
    ('f2',             'f₂ Allen–Dynes (μ*=0.13)',       '',      3),
    ('dos_ef',         'N(E_F)',                         'états/spin/Ry/maille', 3),
    ('n_k_on_fs',      'k-points sur la SF',             '',      0),
    ('fs_fraction',    'fraction SF / zone de Brillouin','',      3),
    ('n_bands_near_ef','bandes à E_F (±0.25 eV)',        '',      0),
    ('n_states_in_window','états dans ±0.25 eV de E_F',  '',      0),
    ('degauss_Ry',     'smearing (largeur)',             'Ry',    4),
    ('ef_eV',          'E_F',                            'eV',    4),
    ('n_electrons',    'N_e (SCF)',                      '',      2),
    ('total_energy_Ry','E_tot (SCF)',                    'Ry',    6),
    ('gap_meV',        'Δ₀ (T → 0)',                     'meV',   3),
    ('gap_mean_meV',   '⟨Δ_k⟩',                          'meV',   3),
    ('gap_min_meV',    'Δ_k min',                        'meV',   3),
    ('gap_max_meV',    'Δ_k max',                        'meV',   3),
    ('gap_spread_meV', 'Δ_k max − min',                  'meV',   3),
    ('n_gap_sheets',   'nbre de feuillets Δ_k',          '',      0),
    ('bcs_ratio',      '2Δ₀ / k_B Tᶜ',                   '',      2),
    ('z_factor',       'Z(0) = 1 + λ',                   '',      3),
    ('tc_interp_K',    'Tᶜ Éliashberg (fermeture Δ)',    'K',     2),
    ('tc_reported_K',  'Tᶜ annoncée par le code',        'K',     2),
    ('mu_star_reported','μ* / μ_c (Coulomb effectif)',   '',      3),
    ('fsthick_eV',     'fsthick (fenêtre Fermi EPW)',    'eV',    3),
    ('omega_min',      'ω_min (dispersion)',             '',      2),
    ('gamma_max',      'γ_qν max',                       'GHz',   2),
    ('lambda_qnu_max', 'λ_qν max',                       '',      3),
]


def build_synthesis(routes: Dict[str, Dict[str, Any]],
                    mu_stars: Sequence[float]) -> Dict[str, Any]:
    """
    Tableau scalaire comparatif des deux voies + lignes Tᶜ par μ*.
    Chaque ligne porte les valeurs `classic`/`epw` et l'écart relatif.
    """
    rows: List[Dict[str, Any]] = []
    for key, label, unit, digits in SYNTHESIS_ROWS:
        c = routes['classic']['scalars'].get(key)
        e = routes['epw']['scalars'].get(key)
        if c is None and e is None:
            continue
        rows.append({
            'key': key, 'label': label, 'unit': unit, 'digits': digits,
            'classic': c, 'epw': e,
            'delta_pct': (100.0 * (e - c) / c) if (c not in (None, 0) and e is not None) else None,
            'source_classic': routes['classic']['provenance'].get(key),
            'source_epw': routes['epw']['provenance'].get(key),
        })

    tc_rows: List[Dict[str, Any]] = []
    for i, mu in enumerate(mu_stars):
        ct = routes['classic']['tc_table'][i] if i < len(routes['classic']['tc_table']) else {}
        et = routes['epw']['tc_table'][i] if i < len(routes['epw']['tc_table']) else {}
        tc_rows.append({
            'mu_star': mu,
            'classic_mcmillan_K': ct.get('tc_mcmillan_K'),
            'classic_allen_dynes_K': ct.get('tc_allen_dynes_K'),
            'epw_mcmillan_K': et.get('tc_mcmillan_K'),
            'epw_allen_dynes_K': et.get('tc_allen_dynes_K'),
        })

    return {
        'rows': rows,
        'tc_rows': tc_rows,
        'available': {wf: routes[wf]['has_data'] for wf in routes},
        'n_files': {wf: len(routes[wf]['inventory']) for wf in routes},
    }

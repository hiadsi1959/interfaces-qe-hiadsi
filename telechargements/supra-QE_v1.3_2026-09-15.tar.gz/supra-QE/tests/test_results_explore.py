#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tests du module d'exploitation des résultats — supra_results.py.

Couvre :
  * moments de α²F(ω) : λ, ω_log, ⟨ω²⟩^½, λ(ω) cumulatif ;
  * Tᶜ McMillan / Allen-Dynes et balayage de μ* ;
  * parseurs lambda.x, pw.x, phonon.dos, freq.gp, elph.inp_lambda.*,
    distribution de gap anisotrope, epw.out ;
  * endpoint /api/results/explore sur une arborescence de sortie synthétique.

Exécuter :
    .venv/bin/pytest tests/test_results_explore.py -v
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "api"))

import supra_api  # noqa: E402
import supra_results as SR  # noqa: E402


# ════════════════════════════  FIXTURES  ════════════════════════════
@pytest.fixture
def client():
    supra_api.app.config["TESTING"] = True
    with supra_api.app.test_client() as c:
        yield c


@pytest.fixture(autouse=True)
def _isolated_paths(monkeypatch, tmp_path):
    inp = tmp_path / "inputs"
    out = tmp_path / "outputs"
    pse = tmp_path / "pseudos"
    tmp = tmp_path / "tmp"
    logs = tmp_path / "logs"
    for d in (inp, out, pse, tmp, logs):
        d.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(supra_api, "INPUTS_DIR", inp)
    monkeypatch.setattr(supra_api, "OUTPUTS_DIR", out)
    monkeypatch.setattr(supra_api, "PSEUDOS_DIR", pse)
    monkeypatch.setattr(supra_api, "TMP_DIR", tmp)
    monkeypatch.setattr(supra_api, "LOGS_DIR", logs)
    monkeypatch.setattr(supra_api, "REPO_ROOT", tmp_path)
    yield {"inputs": inp, "outputs": out, "pseudos": pse, "tmp": tmp, "logs": logs, "root": tmp_path}


def _post(client, route: str, payload: dict):
    return client.post(route, data=json.dumps(payload), content_type="application/json")


# Rectangle étroit de α²F autour de 200 cm⁻¹ : moments calculables à la main.
def _rect_a2f(amp=0.05, w_lo=190.0, w_hi=210.0, step=1.0):
    omega, a2f = [], []
    w = 100.0
    while w <= 300.0 + 1e-9:
        omega.append(w)
        a2f.append(amp if w_lo <= w <= w_hi else 0.0)
        w += step
    return omega, a2f


FAKE_LAMBDA_OUT = """\
     Program LAMBDA v.7.0 starts ...

 Broadening   0.0050  lambda   0.6421  dos(Ef)   1.339210
 Broadening   0.0100  lambda   0.8452  dos(Ef)   1.341002
 Broadening   0.0150  lambda   0.8871  dos(Ef)   1.342551

 lambda = 0.8871   omega_log = 276.4 K
 mu* = 0.12
 T_c = 8.42 K
"""

FAKE_MATDYN_LA2F_OUT = """\
     Program MATDYN v.7.0 starts ...
     electron-phonon coupling

         lambda :   1.05
       <log w>  =   198.3 cm-1
     DOS = 1.339210 states/spin/Ry/Unit Cell at Ef=  8.321793 eV

     JOB DONE
"""

FAKE_SCF_OUT = """\
     Program PWSCF v.7.0 starts ...

     number of atoms/cell      =            2
     number of electrons       =        26.00
     number of k points        =          145

!    total energy              =    -212.43567890 Ry
     the Fermi energy is     8.3218 ev

     JOB DONE
"""

FAKE_PHONON_DOS = """\
 # omega(cm-1)   DOS(states/cm-1)
    0.000000    0.000000
   50.000000    0.001200
  100.000000    0.004500
  150.000000    0.008900
  200.000000    0.012300
  250.000000    0.003100
  300.000000    0.000000
"""

FAKE_FREQ_GP = """\
   0.000000    0.0000    0.0000    0.0000
   0.100000   45.2000   45.2000   88.1000
   0.200000   92.4000   92.4000  165.300
   0.300000  140.100  140.100  221.700
"""

# elph.inp_lambda.<iq> : q-point, puis ω² en Ry², puis λ/γ par mode.
FAKE_ELPH_LAMBDA = """\
   0.25000000   0.25000000   0.00000000       3
  1.234500e-06  1.234500e-06  4.938000e-06
 Gaussian Broadening:   0.005 Ry, ngauss=   0
 DOS = 1.339210 states/spin/Ry/Unit Cell at Ef=  8.321793 eV
 lambda(    1)=  0.1200   gamma=    1.35 GHz
 lambda(    2)=  0.1200   gamma=    1.35 GHz
 lambda(    3)=  0.4500   gamma=   12.80 GHz
 Gaussian Broadening:   0.010 Ry, ngauss=   0
 DOS = 1.341002 states/spin/Ry/Unit Cell at Ef=  8.321793 eV
 lambda(    1)=  0.1500   gamma=    1.71 GHz
 lambda(    2)=  0.1500   gamma=    1.71 GHz
 lambda(    3)=  0.5100   gamma=   14.20 GHz
"""

FAKE_EPW_OUT = """\
     Program EPW v.5.8 starts ...

     Electron-phonon coupling strength    =   1.20
      omega_log =  220.5 K
      laniso = .true.
      muc = 0.10
      fsthick = 0.4
      nbndsub = 8

      Temperature   1.000 K   max Delta = 4.123 meV
      Temperature   5.000 K   max Delta = 3.987 meV
      Temperature  10.000 K   max Delta = 3.012 meV
      Temperature  15.000 K   max Delta = 1.456 meV
      Temperature  19.500 K   max Delta = 0.345 meV
      Temperature  20.000 K   max Delta = 0.000 meV

     JOB DONE
"""

FAKE_GAP_ANISO = """\
# ik  ibnd   enk-ef[eV]   gap[meV]
   1   3   -0.012000   2.010000
   2   3   -0.008000   2.050000
   3   3    0.004000   2.030000
   4   4   -0.150000   5.900000
   5   4    0.030000   6.010000
   6   4    0.120000   5.950000
   7   3    0.200000   2.100000
   8   4   -0.220000   6.100000
"""


# ══════════════════════  MOMENTS DE α²F  ══════════════════════
def _lambda_rect_ref(amp=0.05, w_lo=190.0, w_hi=210.0, step=1.0):
    """
    λ attendue pour le rectangle échantillonné : la règle des trapèzes ajoute
    une demi-classe à chaque bord, le support effectif est donc élargi de
    step/2 de part et d'autre.
    """
    return 2.0 * amp * math.log((w_hi + step / 2) / (w_lo - step / 2))


def test_a2f_moments_reproduit_lambda_analytique():
    """λ = 2∫α²F/ω dω : rectangle [190,210] cm⁻¹ d'amplitude 0.05."""
    omega, a2f = _rect_a2f()
    mom = SR.a2f_moments(omega, a2f, 'cm-1')
    assert mom['lambda'] == pytest.approx(_lambda_rect_ref(), rel=1e-3)


def test_a2f_moments_omega_log_et_omega2_encadrent_le_pic():
    """Pour un spectre étroit, ω_log ≈ ⟨ω²⟩^½ ≈ ω du pic (converti en K)."""
    omega, a2f = _rect_a2f()
    mom = SR.a2f_moments(omega, a2f, 'cm-1')
    peak_K = 200.0 * SR.K_PER_CM1
    assert mom['omega_log_K'] == pytest.approx(peak_K, rel=0.02)
    assert mom['omega_2_K'] == pytest.approx(peak_K, rel=0.02)
    assert mom['omega_2_K'] >= mom['omega_log_K']       # inégalité générale


def test_a2f_moments_lambda_cumulatif_croissant_et_converge():
    """λ(ω) doit être monotone croissant et finir sur λ total."""
    omega, a2f = _rect_a2f()
    mom = SR.a2f_moments(omega, a2f, 'cm-1')
    lam_w = mom['lambda_w']
    assert lam_w[0] == pytest.approx(0.0)
    assert all(lam_w[i] <= lam_w[i + 1] + 1e-12 for i in range(len(lam_w) - 1))
    assert lam_w[-1] == pytest.approx(mom['lambda'], rel=1e-9)


def test_a2f_moments_tolere_bruit_negatif_et_omega_nul():
    """ω ≤ 0 et α²F < 0 (bruit près de Γ) ne doivent pas casser l'intégration."""
    mom = SR.a2f_moments([0.0, -5.0, 50.0, 100.0, 150.0],
                         [1.0, 1.0, -0.01, 0.05, 0.02], 'cm-1')
    assert mom['lambda'] is not None and mom['lambda'] > 0
    assert math.isfinite(mom['omega_log_K'])


def test_a2f_moments_donnees_insuffisantes():
    mom = SR.a2f_moments([100.0], [0.5], 'cm-1')
    assert mom['lambda'] is None and mom['lambda_w'] == []


def test_unite_meV_change_lechelle_en_kelvin():
    """La même courbe lue en meV donne un ω_log ~8× plus grand qu'en cm⁻¹."""
    omega, a2f = _rect_a2f()
    cm = SR.a2f_moments(omega, a2f, 'cm-1')
    mev = SR.a2f_moments(omega, a2f, 'meV')
    ratio = SR.K_PER_MEV / SR.K_PER_CM1
    assert mev['omega_log_K'] / cm['omega_log_K'] == pytest.approx(ratio, rel=1e-6)


# ══════════════════════  Tᶜ ET BALAYAGE μ*  ══════════════════════
def test_tc_sweep_decroit_avec_mu_star():
    rows = SR.tc_sweep(1.0, 300.0, 450.0, [0.10, 0.12, 0.14])
    tcs = [r['tc_allen_dynes_K'] for r in rows]
    assert all(t is not None for t in tcs)
    assert tcs[0] > tcs[1] > tcs[2]
    assert [r['mu_star'] for r in rows] == [0.10, 0.12, 0.14]


def test_tc_sweep_sans_lambda_renvoie_none():
    rows = SR.tc_sweep(None, 300.0, None, [0.10])
    assert rows[0]['tc_mcmillan_K'] is None
    assert rows[0]['tc_allen_dynes_K'] is None


def test_allen_dynes_f2_utilise_le_rapport_omega2_sur_omega_log():
    """f₂ dépend de ⟨ω²⟩^½/ω_log : ratio 1 ⇒ f₂ = 1."""
    tc_plat = SR.tc_allen_dynes(1.2, 250.0, 0.10, omega_2_K=250.0)
    tc_sans = SR.tc_allen_dynes(1.2, 250.0, 0.10)
    assert tc_plat == pytest.approx(tc_sans, rel=1e-12)


def test_bcs_ratio_limite_faible_couplage():
    """Δ₀ = 1.764 k_B Tᶜ ⇒ 2Δ₀/k_B Tᶜ = 3.53."""
    tc = 20.0
    gap_meV = 1.764 * tc / SR.K_PER_MEV
    assert SR.bcs_ratio(gap_meV, tc) == pytest.approx(3.528, rel=1e-3)
    assert SR.bcs_ratio(None, tc) is None
    assert SR.bcs_ratio(1.0, 0.0) is None


# ══════════════════════  PARSEURS  ══════════════════════
def test_parse_lambda_out_broadenings_et_scalaires():
    p = SR.parse_lambda_out(FAKE_LAMBDA_OUT)
    assert len(p['broadenings']) == 3
    assert p['broadenings'][0]['sigma_Ry'] == pytest.approx(0.005)
    assert p['lambda'] == pytest.approx(0.8871)
    assert p['omega_log_K'] == pytest.approx(276.4)
    assert p['dos_ef'] == pytest.approx(1.342551)
    assert p['mu_star'] == pytest.approx(0.12)
    assert p['tc_K'] == pytest.approx(8.42)


def test_parse_lambda_out_format_matdyn_avec_omega_log_en_cm1():
    p = SR.parse_lambda_out(FAKE_MATDYN_LA2F_OUT)
    assert p['lambda'] == pytest.approx(1.05)
    assert p['omega_log_K'] == pytest.approx(198.3 * SR.K_PER_CM1, rel=1e-6)
    assert p['dos_ef'] == pytest.approx(1.339210)
    assert p['ef_eV'] == pytest.approx(8.321793)


def test_parse_lambda_out_texte_vide():
    p = SR.parse_lambda_out("")
    assert p['lambda'] is None and p['broadenings'] == []


def test_parse_scf_out_extrait_niveau_de_fermi_et_energie():
    p = SR.parse_scf_out(FAKE_SCF_OUT)
    assert p['ef_eV'] == pytest.approx(8.3218)
    assert p['n_electrons'] == pytest.approx(26.0)
    assert p['n_atoms'] == 2
    assert p['n_kpoints'] == 145
    assert p['total_energy_Ry'] == pytest.approx(-212.43567890)
    assert p['job_done'] is True
    assert p['character'] == 'unknown'
    assert p['should_stop'] is False


FAKE_SCF_INSULATOR = """\
     Program PWSCF v.7.0 starts ...
     number of electrons       =        32.00

          k = 0.0000 0.0000 0.0000 (   120 PWs)   bands (ev):

    -8.1000  -6.2000  -4.0000   1.2000   8.4000   9.1000

     occupation numbers
     1.0000   1.0000   1.0000   1.0000   0.0000   0.0000

     the Fermi energy is     4.8000 ev
     highest occupied, lowest unoccupied level (ev):     1.2000    8.4000
     Band Gap                        =     7.2000 eV
     the system is insulating

     JOB DONE
"""

FAKE_SCF_METAL = """\
     Program PWSCF v.7.0 starts ...

          k =-0.0833 0.5833-0.5000 (   998 PWs)   bands (ev):

   -28.6042 -25.8644  -0.1815   0.6845   1.4441   2.6415   3.2775   8.9648
    29.3391  31.1069  31.8299  32.9779  34.2721  35.5412  36.5207  38.1560
    42.2847

     occupation numbers
     1.0000   1.0000   1.0000   1.0000   1.0000   1.0000   1.0000   1.0000
     1.0000   1.0000   1.0000   1.0000   1.0000   0.3646   0.0000   0.0000
     0.0000

     the Fermi energy is    35.5266 ev

     JOB DONE
"""


def test_classify_scf_isolant_arrete_la_chaine():
    c = SR.classify_electronic_character(FAKE_SCF_INSULATOR)
    assert c['character'] == 'insulator'
    assert c['should_stop'] is True
    assert c['gap_eV'] == pytest.approx(7.2)
    assert c['insulating_flag'] is True


def test_classify_scf_metal_fractional_occupations():
    c = SR.classify_electronic_character(FAKE_SCF_METAL)
    assert c['character'] == 'metal'
    assert c['should_stop'] is False
    assert c['n_fractional_occ'] >= 1
    assert c['ef_eV'] == pytest.approx(35.5266)


NB_SCF_OUT = ROOT / 'outputs' / 'Nb' / 'classic' / 'Nb.scf.out'


@pytest.mark.skipif(not NB_SCF_OUT.is_file(), reason='sortie SCF Nb absente')
def test_classify_nb_scf_reel_est_un_metal():
    text = NB_SCF_OUT.read_text(encoding='utf-8', errors='replace')
    c = SR.classify_electronic_character(text)
    assert c['character'] == 'metal'
    assert c['should_stop'] is False
    assert c['n_fractional_occ'] >= 1


def test_analyze_fermi_surface_metal_compte_les_k_a_ef():
    """Un métal a des états dans ±0.25 eV de E_F : c'est la surface de Fermi."""
    fs = SR.analyze_fermi_surface(FAKE_SCF_METAL)
    assert fs['ready'] is True
    assert fs['ef_eV'] == pytest.approx(35.5266)
    assert fs['n_k_parsed'] == 1
    assert fs['n_k_on_fs'] == 1
    assert fs['fs_fraction'] == pytest.approx(1.0)
    assert fs['n_bands_near_ef'] >= 1
    assert fs['n_states_in_window'] >= 1
    assert fs['character'] == 'metal'
    assert fs['n_fractional_occ'] >= 1
    assert sum(fs['hist_counts']) >= 1
    assert len(fs['hist_e_ef']) == len(fs['hist_counts'])


def test_analyze_fermi_surface_isolant_aucune_sf():
    """Gap large : aucun k dans la fenêtre → pas de surface de Fermi."""
    fs = SR.analyze_fermi_surface(FAKE_SCF_INSULATOR)
    assert fs['ready'] is True
    assert fs['n_k_on_fs'] == 0
    assert fs['fs_fraction'] == pytest.approx(0.0)
    assert fs['n_states_in_window'] == 0
    assert fs['character'] == 'insulator'


@pytest.mark.skipif(not NB_SCF_OUT.is_file(), reason='sortie SCF Nb absente')
def test_analyze_fermi_surface_nb_reel_echantillonne_la_sf():
    text = NB_SCF_OUT.read_text(encoding='utf-8', errors='replace')
    fs = SR.analyze_fermi_surface(text)
    assert fs['ready'] is True
    assert fs['n_k_on_fs'] >= 1
    assert fs['character'] == 'metal'
    assert fs['ef_eV'] == pytest.approx(35.53, abs=0.1)
    assert fs['fs_fraction'] is not None and fs['fs_fraction'] > 0


def test_parse_phonon_dos():
    p = SR.parse_phonon_dos(FAKE_PHONON_DOS, SR.frequency_unit_for('phonon.dos'))
    assert p['n_points'] == 7
    assert p['unit'] == 'cm-1'
    assert max(p['dos']) == pytest.approx(0.0123)


def test_frequency_unit_for_distingue_matdyn_et_epw():
    """matdyn.x/lambda.x écrivent en cm⁻¹, EPW en meV."""
    assert SR.frequency_unit_for('a2F.dat') == 'cm-1'
    assert SR.frequency_unit_for('phonon.dos') == 'cm-1'
    assert SR.frequency_unit_for('Nb.a2f') == 'meV'
    assert SR.frequency_unit_for('Nb.phdos') == 'meV'
    assert SR.frequency_unit_for('inconnu.txt') is None


def test_parse_freq_gp_dispersion():
    p = SR.parse_freq_gp(FAKE_FREQ_GP)
    assert p['n_modes'] == 3
    assert len(p['q']) == 4
    assert len(p['bands']) == 3
    assert p['omega_max'] == pytest.approx(221.7)


def test_parse_elph_lambda_modes_et_frequences():
    """Le dernier élargissement sert de référence ; ω² en Ry² → cm⁻¹."""
    p = SR.parse_elph_lambda(FAKE_ELPH_LAMBDA)
    assert p['q'] == [0.25, 0.25, 0.0]
    assert p['sigma_Ry'] == pytest.approx(0.010)
    assert len(p['blocks']) == 2
    assert [m['lambda'] for m in p['modes']] == [0.15, 0.15, 0.51]
    assert p['modes'][2]['gamma'] == pytest.approx(14.20)
    assert p['modes'][2]['gamma_unit'] == 'GHz'
    # sqrt(4.938e-06) × 109737.3 ≈ 243.8 cm⁻¹, soit √4 = 2× le premier mode
    assert p['modes'][2]['omega_cmm1'] == pytest.approx(
        2.0 * p['modes'][0]['omega_cmm1'], rel=1e-6)
    assert p['dos_ef'] == pytest.approx(1.339210)


def test_parse_gap_distribution_detecte_deux_feuillets():
    h = SR.parse_gap_distribution(FAKE_GAP_ANISO, bins=20)
    assert h['n_values'] == 8
    assert h['gap_min'] == pytest.approx(2.01)
    assert h['gap_max'] == pytest.approx(6.10)
    assert h['n_sheets'] == 2            # gap à ~2 meV et à ~6 meV
    assert sum(h['counts']) == 8


def test_parse_epw_output_ajoute_tc_interpole_et_z():
    p = SR.parse_epw_output(FAKE_EPW_OUT)
    assert p['tc_K'] == pytest.approx(19.5)          # plus haute T à gap ouvert
    assert p['tc_interp_K'] > 19.5                   # annulation interpolée
    assert p['z_factor'] == pytest.approx(2.20)      # 1 + λ
    assert p['fsthick_eV'] == pytest.approx(0.4)
    assert p['nbndsub'] == 8
    assert p['is_anisotropic'] is True


# ══════════════════════  EXPLORATION D'ARBORESCENCE  ══════════════════════
def _build_tree(paths, with_epw=True):
    """Écrit une arborescence de sortie synthétique pour le matériau Nb."""
    mat = 'Nb'
    cls = paths['outputs'] / mat / 'classic'
    (cls / 'elph_dir').mkdir(parents=True, exist_ok=True)
    (cls / f'{mat}.scf.out').write_text(FAKE_SCF_OUT, encoding='utf-8')
    (cls / f'{mat}.matdyn.out').write_text(FAKE_MATDYN_LA2F_OUT, encoding='utf-8')
    (cls / f'{mat}.lambda.out').write_text(FAKE_LAMBDA_OUT, encoding='utf-8')
    (cls / 'phonon.dos').write_text(FAKE_PHONON_DOS, encoding='utf-8')
    (cls / 'freq.gp').write_text(FAKE_FREQ_GP, encoding='utf-8')
    (cls / 'elph_dir' / 'elph.inp_lambda.1').write_text(FAKE_ELPH_LAMBDA, encoding='utf-8')
    omega, a2f = _rect_a2f()
    (cls / 'a2F.dat').write_text(
        '# omega(cm-1)  a2F\n' +
        '\n'.join(f'{w:.4f}  {a:.6f}' for w, a in zip(omega, a2f)), encoding='utf-8')
    if with_epw:
        epw = paths['outputs'] / mat / 'epw'
        epw.mkdir(parents=True, exist_ok=True)
        (epw / f'{mat}.epw.out').write_text(FAKE_EPW_OUT, encoding='utf-8')
        (epw / f'{mat}.imag_aniso_gap0_10.00').write_text(FAKE_GAP_ANISO, encoding='utf-8')
        (epw / f'{mat}.a2f').write_text(
            '# omega(meV)  a2F\n' +
            '\n'.join(f'{w/8.0:.4f}  {a:.6f}' for w, a in zip(omega, a2f)), encoding='utf-8')
    return mat


def test_explore_route_classique_agrege_scalaires_et_courbes(_isolated_paths):
    mat = _build_tree(_isolated_paths)
    r = SR.explore_route(mat, 'classic', _isolated_paths['inputs'],
                         _isolated_paths['outputs'], _isolated_paths['root'])
    s = r['scalars']
    # λ vient des moments de α²F (source la plus fiable), pas du texte
    assert s['lambda'] == pytest.approx(_lambda_rect_ref(), rel=1e-3)
    assert s['omega_2_K'] is not None
    assert s['dos_ef'] == pytest.approx(1.339210)
    assert s['ef_eV'] == pytest.approx(8.321793)
    assert r['provenance']['lambda'].endswith('a2F.dat')
    assert set(r['curves']) >= {'a2f', 'phdos', 'dispersion', 'elph', 'broadenings'}
    assert r['curves']['elph']['n_qpoints'] == 1
    assert len(r['tc_table']) == len(SR.DEFAULT_MU_STARS)
    assert {i['key'] for i in r['inventory']} >= {'a2f', 'freq', 'elph', 'matdyn_out'}


def test_explore_route_epw_gap_et_distribution(_isolated_paths):
    mat = _build_tree(_isolated_paths)
    r = SR.explore_route(mat, 'epw', _isolated_paths['inputs'],
                         _isolated_paths['outputs'], _isolated_paths['root'])
    s = r['scalars']
    assert s['gap_meV'] == pytest.approx(4.123)
    assert s['tc_reported_K'] == pytest.approx(19.5)
    assert s.get('tc_interp_K') is not None
    # Rapport BCS : Tᶜ Éliashberg (fermeture Δ) prioritaire sur la Tᶜ imprimée
    tc_ref = s['tc_interp_K'] or s['tc_reported_K']
    assert s['bcs_ratio'] == pytest.approx(2 * 4.123 * SR.K_PER_MEV / tc_ref, rel=1e-6)
    assert s['is_anisotropic'] is True
    assert r['curves']['gap_vs_T']['n_points'] == 6
    assert r['curves']['gap_distribution']['n_sheets'] == 2
    assert 'f1' in s and 'f2' in s


def test_explore_epw_reprend_scf_de_la_voie_classique(_isolated_paths):
    """WF2 sans scf.out propre : le SCF de WF1 est réutilisé."""
    mat = 'Nb'
    cls = _isolated_paths['outputs'] / mat / 'classic'
    cls.mkdir(parents=True, exist_ok=True)
    (cls / f'{mat}.scf.out').write_text(FAKE_SCF_OUT, encoding='utf-8')
    r = SR.explore_route(mat, 'epw', _isolated_paths['inputs'],
                         _isolated_paths['outputs'], _isolated_paths['root'])
    assert any(i['key'] == 'scf_out' for i in r['inventory'])
    assert r['scalars']['ef_eV'] == pytest.approx(8.3218)
    assert any('SCF repris' in n for n in r['notes'])
    assert any(p['key'] == 'scf_out' and p['done'] for p in r['progress'])


def test_explore_route_expose_la_surface_de_fermi(_isolated_paths):
    """Un SCF métallique avec bandes imprimées alimente l'analyse de SF."""
    mat = 'Nb'
    cls = _isolated_paths['outputs'] / mat / 'classic'
    cls.mkdir(parents=True, exist_ok=True)
    (cls / f'{mat}.scf.out').write_text(FAKE_SCF_METAL, encoding='utf-8')
    r = SR.explore_route(mat, 'classic', _isolated_paths['inputs'],
                         _isolated_paths['outputs'], _isolated_paths['root'])
    fs = r['curves']['fermi']
    assert fs['ready'] is True
    assert fs['n_k_on_fs'] == 1
    assert r['scalars']['n_k_on_fs'] == 1
    assert r['scalars']['fs_fraction'] == pytest.approx(1.0)
    assert r['scalars']['n_bands_near_ef'] >= 1
    assert r['scalars']['n_states_in_window'] >= 1


def test_fs_x_input_pointe_xcrysden():
    t = SR.fs_x_input_text('Nb', 'outputs/Nb/classic')
    assert "prefix = 'Nb'" in t
    assert 'xcrysden --bxsf Nb.bxsf' in t
    assert '&fermi' in t


def test_file_patterns_inclut_bxsf_pour_xcrysden():
    classic = {k for k, _, _ in SR.FILE_PATTERNS['classic']}
    epw = {k for k, _, _ in SR.FILE_PATTERNS['epw']}
    assert 'bxsf' in classic and 'bxsf' in epw
    assert 'fs_in' in classic and 'fs_in' in epw


def test_explore_route_trouve_le_bxsf(_isolated_paths):
    mat = 'Nb'
    cls = _isolated_paths['outputs'] / mat / 'classic'
    cls.mkdir(parents=True, exist_ok=True)
    (cls / f'{mat}.scf.out').write_text(FAKE_SCF_METAL, encoding='utf-8')
    (cls / f'{mat}.bxsf').write_text('BEGIN_INFO\nEND_INFO\n', encoding='utf-8')
    r = SR.explore_route(mat, 'classic', _isolated_paths['inputs'],
                         _isolated_paths['outputs'], _isolated_paths['root'])
    viz = r['curves']['fermi_viz']
    assert viz['ready'] is True
    assert viz['bxsf'].endswith('Nb.bxsf')
    assert 'xcrysden --bxsf' in viz['command']
    assert any(i['key'] == 'bxsf' for i in r['inventory'])


def test_explore_route_materiau_absent_reste_silencieux(_isolated_paths):
    r = SR.explore_route('Inconnu', 'classic', _isolated_paths['inputs'],
                         _isolated_paths['outputs'], _isolated_paths['root'])
    assert r['has_data'] is False
    assert r['inventory'] == []
    assert any('λ introuvable' in n for n in r['notes'])


def test_synthese_compare_les_deux_voies(_isolated_paths):
    mat = _build_tree(_isolated_paths)
    payload = SR.explore_results(mat, _isolated_paths['inputs'],
                                 _isolated_paths['outputs'], _isolated_paths['root'],
                                 [0.10, 0.12, 0.14])
    syn = payload['synthesis']
    assert syn['available'] == {'classic': True, 'epw': True}
    assert len(syn['tc_rows']) == 3
    keys = {row['key'] for row in syn['rows']}
    assert {'lambda', 'omega_log_K', 'gap_meV', 'dos_ef'} <= keys
    lam_row = next(r for r in syn['rows'] if r['key'] == 'lambda')
    assert lam_row['classic'] is not None and lam_row['epw'] is not None
    assert lam_row['delta_pct'] is not None


# ══════════════════════  ENDPOINT  ══════════════════════
def test_endpoint_explore_retourne_les_deux_voies(client, _isolated_paths):
    mat = _build_tree(_isolated_paths)
    r = _post(client, '/api/results/explore', {'material': mat})
    assert r.status_code == 200
    d = r.get_json()
    assert d['ok'] is True and d['material'] == mat
    assert d['classic']['scalars']['lambda'] is not None
    assert d['epw']['scalars']['gap_meV'] == pytest.approx(4.123)
    assert d['synthesis']['n_files']['classic'] > 0


def test_endpoint_explore_mu_stars_personnalises(client, _isolated_paths):
    mat = _build_tree(_isolated_paths)
    r = _post(client, '/api/results/explore', {'material': mat, 'mu_stars': [0.13]})
    d = r.get_json()
    assert d['mu_stars'] == [0.13]
    assert len(d['classic']['tc_table']) == 1
    assert d['classic']['tc_table'][0]['mu_star'] == pytest.approx(0.13)


def test_endpoint_explore_refuse_material_invalide(client):
    for bad in ('', '../etc', 'a/b', '.hidden'):
        r = _post(client, '/api/results/explore', {'material': bad})
        assert r.status_code == 400


def test_endpoint_explore_materiau_vide_reste_200(client, _isolated_paths):
    r = _post(client, '/api/results/explore', {'material': 'Rien'})
    assert r.status_code == 200
    d = r.get_json()
    assert d['ok'] is True
    assert d['synthesis']['available'] == {'classic': False, 'epw': False}


def test_file_read_tronque_les_gros_fichiers(client, _isolated_paths):
    big = _isolated_paths['outputs'] / 'gros.out'
    big.write_text('\n'.join(f'ligne {i}' for i in range(5000)), encoding='utf-8')
    r = _post(client, '/api/file/read',
              {'path': 'outputs/gros.out', 'max_bytes': 2000})
    d = r.get_json()
    assert d['ok'] is True and d['truncated'] is True
    assert 'octets omis' in d['content']
    assert len(d['content']) < 4000


def test_file_read_tail_lines(client, _isolated_paths):
    f = _isolated_paths['outputs'] / 'journal.out'
    f.write_text('\n'.join(f'ligne {i}' for i in range(100)), encoding='utf-8')
    r = _post(client, '/api/file/read', {'path': 'outputs/journal.out', 'tail_lines': 10})
    d = r.get_json()
    assert d['content'].splitlines()[0] == 'ligne 90'
    assert d['truncated'] is True


# ══════════════════════  Corrections audit Résultats  ══════════════════════

def test_parse_epw_omega_log_sans_unite_suppose_kelvin():
    """omega_log = 220.5 (sans unité) → Kelvin, pas meV (×11)."""
    text = "Electron-phonon coupling strength = 1.2\n omega_log =  220.5\n"
    p = SR.parse_epw_output(text)
    assert p['omega_log_K'] == pytest.approx(220.5)
    assert p['omega_log_meV'] is None


def test_parse_epw_omega_log_mev_explicite():
    text = "Logarithmic average phonon frequency = 18.99 meV\n"
    p = SR.parse_epw_output(text)
    assert p['omega_log_meV'] == pytest.approx(18.99)
    assert p['omega_log_K'] == pytest.approx(18.99 * SR.K_PER_MEV, rel=1e-6)


def test_guess_frequency_unit_prefere_mev_sous_15():
    assert SR.guess_frequency_unit(8.0) == 'meV'
    assert SR.guess_frequency_unit(250.0) == 'meV'
    assert SR.guess_frequency_unit(800.0) == 'cm-1'


def test_sort_a2f_prefere_dos10_a_dos1(tmp_path):
    d = tmp_path
    (d / 'a2F.dos1').write_text('1 0.01\n')
    (d / 'a2F.dos10').write_text('1 0.10\n')
    (d / 'a2F.dat').write_text('1 0.20\n')
    hits = SR._sort_a2f_hits([d / 'a2F.dos1', d / 'a2F.dos10', d / 'a2F.dat'])
    assert hits[0].name == 'a2F.dat'
    assert hits[1].name == 'a2F.dos10'
    assert hits[2].name == 'a2F.dos1'


def test_explore_prefere_a2f_dos_large(_isolated_paths):
    mat = 'DosPref'
    cls = _isolated_paths['outputs'] / mat / 'classic'
    cls.mkdir(parents=True, exist_ok=True)
    omega, a2f_ok = _rect_a2f(amp=0.05)
    (cls / 'a2F.dos1').write_text(
        '\n'.join(f'{w:.4f}  {0.0001 if 199 <= w <= 201 else 0.0}' for w in omega),
        encoding='utf-8')
    (cls / 'a2F.dos10').write_text(
        '\n'.join(f'{w:.4f}  {a:.6f}' for w, a in zip(omega, a2f_ok)),
        encoding='utf-8')
    r = SR.explore_route(mat, 'classic', _isolated_paths['inputs'],
                         _isolated_paths['outputs'], _isolated_paths['root'])
    assert r['curves']['a2f']['source'].endswith('a2F.dos10')
    lam10 = r['scalars']['lambda']
    assert lam10 is not None and lam10 > 0.005
    # Contrôle : dos1 seul donnerait un λ bien plus petit
    (cls / 'a2F.dos10').unlink()
    r1 = SR.explore_route(mat, 'classic', _isolated_paths['inputs'],
                          _isolated_paths['outputs'], _isolated_paths['root'])
    assert r1['curves']['a2f']['source'].endswith('a2F.dos1')
    assert r1['scalars']['lambda'] < lam10 * 0.2


def test_gamma_to_ghz_thz():
    assert SR._gamma_to_ghz(0.5, 'THz') == pytest.approx(500.0)
    assert SR._gamma_to_ghz(12.0, 'GHz') == pytest.approx(12.0)

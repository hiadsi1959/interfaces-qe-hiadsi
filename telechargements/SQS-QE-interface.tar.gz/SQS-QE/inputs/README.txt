inputs/<Matériau>/<Mat>-vc-relax.in | <Mat>-relax.in | <Mat>-scf.in

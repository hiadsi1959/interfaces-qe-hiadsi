#!/usr/bin/env bash
# Phases / SQS-QE — démarre l’interface (après ./CONFIGURER.sh sur un nouveau PC)
# UI : http://127.0.0.1:5031/  ·  API calculs : http://127.0.0.1:5030/
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

need_configure=0
if [[ ! -f "$HERE/config_local.sh" ]]; then
  echo "  · config_local.sh absent — lancement de CONFIGURER.sh…"
  need_configure=1
elif [[ ! -x "$HERE/.venv/bin/python" ]]; then
  echo "  · venv UI absent — lancement de CONFIGURER.sh…"
  need_configure=1
elif [[ ! -f "$HERE/.sqs_qe_configured" ]]; then
  echo "  · Première utilisation sur ce PC — lancement de CONFIGURER.sh…"
  need_configure=1
fi

if [[ "$need_configure" -eq 1 ]]; then
  if [[ ! -x "$HERE/CONFIGURER.sh" ]]; then
    chmod +x "$HERE/CONFIGURER.sh" 2>/dev/null || true
  fi
  if [[ ! -f "$HERE/CONFIGURER.sh" ]]; then
    echo "  ✗ CONFIGURER.sh introuvable."
    exit 1
  fi
  "$HERE/CONFIGURER.sh" || exit 1
fi

if [[ -f "$HERE/config_local.sh" ]]; then
  # shellcheck disable=SC1091
  source "$HERE/config_local.sh"
else
  echo ""
  echo "  ✗ config_local.sh toujours absent après CONFIGURER.sh"
  echo ""
  exit 1
fi

# Racine = dossier réel (adapté si le dépôt a été copié sur un autre PC)
export SQS_QE_ROOT="$HERE"

HOST="${SQS_QE_HOST:-127.0.0.1}"
PORT="${SQS_QE_PORT:-5031}"
URL="http://${HOST}:${PORT}/"
UPSTREAM="${OPTQ_API_UPSTREAM:-http://127.0.0.1:5030}"
OPTQ_ROOT="${OPTQ_ROOT:-$HOME/optimisation-QE}"
API_HOST="${OPTQ_MAIN_HOST:-127.0.0.1}"
API_PORT="${OPTQ_MAIN_PORT:-5030}"
AUTO_API="${SQS_QE_AUTO_START_API:-1}"

export SQS_QE_ROOT="$HERE"
export QE_BIN_DIR="${QE_BIN_DIR:-$SQS_QE_ROOT/bin}"
export PSEUDO_DIR="${PSEUDO_DIR:-$SQS_QE_ROOT/pseudos}"
export OPTQ_CIF_DIR="$SQS_QE_ROOT/cif"
export OPTQ_CIF_DIRS="${OPTQ_CIF_DIRS:-$SQS_QE_ROOT/cif}"
export OPTQ_INPUTS="$SQS_QE_ROOT/inputs"
export OPTQ_OUTPUTS="$SQS_QE_ROOT/outputs"
mkdir -p "$OPTQ_INPUTS" "$OPTQ_OUTPUTS"
IFS=':' read -ra _OPTQ_CIF_PATHS <<< "${OPTQ_CIF_DIRS:-$OPTQ_CIF_DIR}"
for _cif_d in "${_OPTQ_CIF_PATHS[@]}"; do
  [[ -n "$_cif_d" ]] && mkdir -p "$_cif_d"
done

for libdir in "$HERE/lib" "$OPTQ_ROOT/lib"; do
  if [[ -d "$libdir" && -n "$(ls -A "$libdir" 2>/dev/null)" ]]; then
    export LD_LIBRARY_PATH="$libdir${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
    break
  fi
done

PIDFILE="$HERE/logs/sqs.pid"
LOGFILE="$HERE/logs/sqs.log"
API_PIDFILE="$OPTQ_ROOT/logs/api.pid"
API_LOGFILE="$OPTQ_ROOT/logs/api.log"

SQS_PYTHON="${SQS_QE_PYTHON:-python3}"
[[ -x "$HERE/.venv/bin/python" ]] && SQS_PYTHON="$HERE/.venv/bin/python"
[[ -x "${SQS_QE_PYTHON:-}" ]] && SQS_PYTHON="$SQS_QE_PYTHON"

API_PYTHON="${OPTQ_PYTHON:-python3}"
[[ -x "$OPTQ_ROOT/.venv/bin/python" ]] && API_PYTHON="$OPTQ_ROOT/.venv/bin/python"

if ! "$SQS_PYTHON" -c "import flask" 2>/dev/null; then
  echo "  ✗ Flask manquant pour : $SQS_PYTHON"
  echo "    ./CONFIGURER.sh   ou   pip install flask"
  exit 1
fi

mkdir -p "$HERE/logs"

api_health_ok() {
  curl -sf "${UPSTREAM%/}/api/health" >/dev/null 2>&1
}

start_api() {
  if [[ ! -f "$OPTQ_ROOT/backend/api_server.py" ]]; then
    echo "  ✗ Backend calculs introuvable : $OPTQ_ROOT/backend/api_server.py"
    echo "    Ajustez OPTQ_ROOT dans config_local.sh"
    return 1
  fi
  if ! "$API_PYTHON" -c "import flask, ase, numpy" 2>/dev/null; then
    echo "  ✗ Dépendances API manquantes (flask, ase, numpy) : $API_PYTHON"
    echo "    Installez le venv optimisation-QE ou exportez OPTQ_PYTHON"
    return 1
  fi
  if [[ -f "$API_PIDFILE" ]] && kill -0 "$(cat "$API_PIDFILE")" 2>/dev/null; then
    echo "  ⚠ API déjà active (sans rechargement OPTQ_CIF_*). Si un CIF est « introuvable » :"
    echo "    $OPTQ_ROOT/ARRETER.sh && ./DEMARRER.sh"
    return 0
  fi
  mkdir -p "$OPTQ_ROOT/logs"
  echo "  Démarrage API calculs (optimisation-QE)…"
  echo "  QE_BIN_DIR=$QE_BIN_DIR"
  echo "  PSEUDO_DIR=$PSEUDO_DIR"
  echo "  OPTQ_CIF_DIR=$OPTQ_CIF_DIR"
  echo "  OPTQ_CIF_DIRS=$OPTQ_CIF_DIRS"
  echo "  OPTQ_INPUTS=$OPTQ_INPUTS"
  echo "  OPTQ_OUTPUTS=$OPTQ_OUTPUTS"
  nohup env \
    QE_BIN_DIR="$QE_BIN_DIR" \
    PSEUDO_DIR="$PSEUDO_DIR" \
    OPTQ_CIF_DIR="$OPTQ_CIF_DIR" \
    OPTQ_CIF_DIRS="$OPTQ_CIF_DIRS" \
    OPTQ_INPUTS="$OPTQ_INPUTS" \
    OPTQ_OUTPUTS="$OPTQ_OUTPUTS" \
    LD_LIBRARY_PATH="${LD_LIBRARY_PATH:-}" \
    QEALAMODE_HOST="$API_HOST" \
    QEALAMODE_PORT="$API_PORT" \
    "$API_PYTHON" "$OPTQ_ROOT/backend/api_server.py" >>"$API_LOGFILE" 2>&1 &
  echo $! >"$API_PIDFILE"
  sleep 1
}

if ! api_health_ok; then
  if [[ "$AUTO_API" == "1" ]]; then
    start_api || exit 1
    started=0
    for _ in $(seq 1 40); do
      if api_health_ok; then started=1; break; fi
      sleep 0.3
    done
    if [[ "$started" -eq 0 ]]; then
      echo "  ✗ API inactive après démarrage — voir $API_LOGFILE"
      tail -n 15 "$API_LOGFILE" 2>/dev/null || true
      exit 1
    fi
  else
    echo "  ✗ API optimisation-QE inactive : ${UPSTREAM%/}/api/health"
    echo "    Lancez ${OPTQ_ROOT}/DEMARRER.sh ou SQS_QE_AUTO_START_API=1 ./DEMARRER.sh"
    exit 1
  fi
fi

if [[ ! -x "$QE_BIN_DIR/pw.x" ]]; then
  echo "  ⚠ pw.x absent dans $QE_BIN_DIR — ./CONFIGURER.sh"
fi

export OPTQ_ROOT
export OPTQ_API_UPSTREAM="$UPSTREAM"
export OPTQ_CIF_DIR
export OPTQ_CIF_DIRS
export OPTQ_INPUTS
export OPTQ_OUTPUTS
export SQS_QE_HOST="$HOST"
export SQS_QE_PORT="$PORT"

sqs_serving_ok() {
  curl -sf "$URL" >/dev/null 2>&1 || return 1
  curl -sf "${URL}env.js" 2>/dev/null | grep -qF "window.SQS_QE_ROOT=\"${HERE}\"" || return 1
}

if [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null && sqs_serving_ok; then
  echo "  Phases / SQS déjà active → $URL"
elif ! sqs_serving_ok; then
  if command -v ss >/dev/null 2>&1 && ss -tlnp 2>/dev/null | grep -q ":${PORT} "; then
    echo "  ⚠ Port $PORT : serveur obsolète ou dossier déplacé — arrêt puis relance…"
    "$HERE/ARRETER.sh" || true
    sleep 0.5
  elif [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    echo "  ⚠ Processus SQS sans page d’accueil — redémarrage…"
    "$HERE/ARRETER.sh" || true
    sleep 0.5
  fi
fi

if [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null && sqs_serving_ok; then
  :
else
  echo ""
  echo "  PHASES / SQS-QE — NM · FM · AFM · SQS · inputs QE ≥ 7.5"
  echo "  URL : $URL"
  echo "  API : $UPSTREAM"
  echo ""
  nohup env \
    OPTQ_CIF_DIR="$OPTQ_CIF_DIR" \
    OPTQ_CIF_DIRS="$OPTQ_CIF_DIRS" \
    OPTQ_INPUTS="$OPTQ_INPUTS" \
    OPTQ_OUTPUTS="$OPTQ_OUTPUTS" \
    OPTQ_ROOT="$OPTQ_ROOT" \
    OPTQ_API_UPSTREAM="$UPSTREAM" \
    "$SQS_PYTHON" "$HERE/backend/sqs_server.py" >>"$LOGFILE" 2>&1 &
  echo $! >"$PIDFILE"
  sleep 0.8
fi

open_phases_ui() {
  local browser="${SQS_QE_BROWSER:-firefox}"
  if command -v "$browser" >/dev/null 2>&1; then
    "$browser" "$URL" >/dev/null 2>&1 &
    echo "  Navigateur : $browser"
    return 0
  fi
  if command -v firefox >/dev/null 2>&1; then
    firefox "$URL" >/dev/null 2>&1 &
    echo "  Navigateur : firefox"
    return 0
  fi
  if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$URL" >/dev/null 2>&1 || true
    echo "  Navigateur : xdg-open (navigateur par défaut du système)"
    return 0
  fi
  if command -v sensible-browser >/dev/null 2>&1; then
    sensible-browser "$URL" >/dev/null 2>&1 || true
    return 0
  fi
  echo "  Ouvrez manuellement : $URL"
  return 1
}

if curl -sf "$URL" >/dev/null 2>&1; then
  echo "  Accueil    : $URL"
  echo "  Préparation: ${URL}index.html"
  echo "  Guide      : ${URL}guide.html"
  open_phases_ui || true
else
  echo "  ✗ Le serveur SQS ne répond pas — voir $LOGFILE"
  exit 1
fi

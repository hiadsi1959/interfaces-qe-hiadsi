# Phase / SQS-QE

Interface **Phases_QE · SQS** autonome pour Quantum ESPRESSO **≥ 7.5** :

1. Optimisation de **plusieurs phases** d’un même alliage (NM, puis phase ★ → FM/AFM).
2. **Alliages / mailles distincts** (jobs séparés, NM → magnétisme).
3. **SQS** et **dopages** de phase (supercellules, fractions A/B).

### Inputs magnétiques (tous matériaux du catalogue)

Après un SCF NM (`inputs/materiaux/<Mat>/<Mat>-scf.in`), régénération **FM / AFM viables / NCL** avec supercellules **AFM-A/C (1×1×2, c×2)**, **AFM-B (1×2×1, b×2)**, sous-mailles via `mag_reference.json` (3d, 4f, actinides…) :

```bash
python3 backend/regenerate_mag_inputs.py GdCrO3    # un matériau
python3 backend/regenerate_mag_inputs.py --all     # tout le catalogue
curl -s -X POST http://127.0.0.1:5031/api/mag-inputs/regenerate-catalog
curl -s http://127.0.0.1:5031/api/mag-inputs/audit-catalog
```

L’UI appelle aussi `POST …/mag-orders/regenerate-local` après **Préparer** les ordres magnétiques.

Dans ce dépôt : UI (`interface/`), serveur Flask (`backend/sqs_server.py`), dossiers locaux **`bin/`** (pw.x, …), **`pseudos/`** (UPF), **`cif/`** (structures brutes), **`inputs/`** (fichiers `.in` générés), **`outputs/`** (résultats pw.x). Le générateur d’inputs et l’exécution passent par le backend **optimisation-QE** (proxifié), configuré via `OPTQ_CIF_DIR`, `OPTQ_INPUTS`, `OPTQ_OUTPUTS` dans `config_local.sh`.

## Installation sur un nouveau PC

```bash
cd /chemin/vers/SQS-QE          # clone ou copie du dépôt
chmod +x CONFIGURER.sh DEMARRER.sh ARRETER.sh

./CONFIGURER.sh                 # ① prérequis + adaptation à ce PC
./DEMARRER.sh                   # ② démarre l’interface
```

**`CONFIGURER.sh`** (une fois par machine, ou après déplacement du dépôt) :
- crée `config_local.sh` si besoin (chemins relatifs au dépôt) ;
- détecte `optimisation-QE` (`~/optimisation-QE`, voisin du dépôt, …) ;
- crée `bin/`, `pseudos/`, `cif/`, `inputs/`, `outputs/`, `logs/` ;
- lie `pw.x` et les UPF depuis la source QE / optimisation-QE ;
- installe le venv Python (Flask, numpy) ;
- configure éventuellement le backend optimisation-QE.

**`DEMARRER.sh`** lance l’API calculs si besoin, puis l’UI. S’il manque la config / le venv, il appelle automatiquement `CONFIGURER.sh`.

- **Accueil :** http://127.0.0.1:5031/
- **Préparation :** http://127.0.0.1:5031/index.html
- **Guide :** http://127.0.0.1:5031/guide.html
- **NM / Magnétisme (app principale) :** http://127.0.0.1:5030/

Arrêt UI : `./ARRETER.sh`

## Configuration (`config_local.sh`)

| Variable | Défaut | Rôle |
|----------|--------|------|
| `SQS_QE_PORT` | `5031` | Port UI |
| `QE_BIN_DIR` | `./bin` | Binaires QE |
| `PSEUDO_DIR` | `./pseudos` | Pseudopotentiels |
| `OPTQ_ROOT` | `~/optimisation-QE` | API + générateur inputs QE 7.5+ |
| `OPTQ_CIF_DIR` | `$SQS_QE_ROOT/cif` | Bibliothèque CIF du dépôt courant |
| `OPTQ_CIF_DIRS` | idem | Liste `:` si plusieurs dossiers CIF |
| `OPTQ_INPUTS` | `$SQS_QE_ROOT/inputs` | Inputs QE générés |
| `OPTQ_OUTPUTS` | `$SQS_QE_ROOT/outputs` | Sorties pw.x |
| `OPTQ_API_UPSTREAM` | `http://127.0.0.1:5030` | Proxy API |
| `SQS_QE_AUTO_START_API` | `1` | Lance l’API si elle est arrêtée |

Workflow typique : déposer les `.cif` dans **`cif/`** → dans l’UI, choisir le composé (ex. `GdCrO3`) → **CIF → VC-RELAX** ou **Commencer** (conversion auto vers **`inputs/`**) → lancer la chaîne NM ; les `.out` vont dans **`outputs/`**.

Arrêt UI : `./ARRETER.sh` (l’API optimisation-QE reste active ; arrêt via `~/optimisation-QE/ARRETER.sh` si besoin).

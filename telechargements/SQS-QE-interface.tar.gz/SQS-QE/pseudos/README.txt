Pseudopotentiels UPFD (QE ≥ 7.5) utilisés par le générateur d’inputs.

Remplissage automatique (recommandé) :
  ./CONFIGURER.sh

Manuel : copier ou lier votre bibliothèque, par ex. :
  ln -sf ~/optimisation-QE/pseudos/* ./

Variable d’environnement : PSEUDO_DIR (défaut : ce dossier).

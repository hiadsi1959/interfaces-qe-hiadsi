"""Audit physique des inputs magnétiques QE (aligné sur optimisation-QE/mag_orders.py)."""
from __future__ import annotations

import math
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OPTQ_ROOT = Path(os.environ.get("OPTQ_ROOT", Path.home() / "optimisation-QE")).expanduser()


def _load_mag_orders():
    backend = OPTQ_ROOT / "backend"
    if backend.is_dir() and str(backend) not in sys.path:
        sys.path.insert(0, str(backend))
    import mag_orders  # type: ignore

    return mag_orders


def _parse_position_lines(content: str) -> list[tuple[str, tuple[float, float, float]]]:
    m = re.search(
        r"ATOMIC_POSITIONS\s+\S+\s*(.*?)(?=CELL_PARAMETERS|K_POINTS|\Z)",
        content,
        re.IGNORECASE | re.DOTALL,
    )
    if not m:
        return []
    out: list[tuple[str, tuple[float, float, float]]] = []
    for line in m.group(1).splitlines():
        line = line.split("!")[0].strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) < 4:
            continue
        try:
            x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
        except ValueError:
            continue
        out.append((parts[0], (x, y, z)))
    return out


def _afm_mode(order: str) -> str:
    o = (order or "").strip().lower()
    return {"afm-g": "g", "afm-a": "a", "afm-b": "b", "afm-c": "c"}.get(o, "g")


def _afm_sign_xyz(x: float, y: float, z: float, mode: str) -> int:
    if mode == "g":
        ix = int(round(2.0 * x)) % 2
        iy = int(round(2.0 * y)) % 2
        iz = int(round(2.0 * z)) % 2
        return 1 if (ix + iy + iz) % 2 == 0 else -1
    if mode == "a":
        return 1 if float(z) < 0.5 - 1e-8 else -1
    if mode == "b":
        return 1 if float(y) < 0.5 - 1e-8 else -1
    if mode == "c":
        return 1 if float(x) < 0.5 - 1e-8 else -1
    return 1


def _element_base(symbol: str) -> str:
    sym = (symbol or "").strip()
    m = re.match(r"^([A-Za-z]+)", sym)
    return m.group(1) if m else sym


def _carries_moment(base: str) -> bool:
    try:
        backend = OPTQ_ROOT / "backend"
        if backend.is_dir() and str(backend) not in sys.path:
            sys.path.insert(0, str(backend))
        from mag_reference import element_carries_local_moment  # type: ignore

        return bool(element_carries_local_moment(base))
    except Exception:
        return base not in ("O", "N", "C", "H", "F", "Cl", "Br", "I", "S", "P")


def _afm_site_signs(positions: list[tuple[str, tuple[float, float, float]]], mode: str) -> list[int]:
    signs: list[int] = []
    for sym, (x, y, z) in positions:
        base = _element_base(sym)
        if not _carries_moment(base):
            signs.append(0)
            continue
        signs.append(_afm_sign_xyz(x, y, z, mode))
    mag = [s for s in signs if s]
    if len(mag) >= 2 and all(s == mag[0] for s in mag):
        flip = False
        for i, (sym, _) in enumerate(positions):
            if not signs[i]:
                continue
            signs[i] = -1 if flip else 1
            flip = not flip
    return signs


def _element_splits(
    positions: list[tuple[str, tuple[float, float, float]]], signs: list[int]
) -> dict[str, bool]:
    base_signs: dict[str, set[int]] = {}
    for (sym, _), s in zip(positions, signs):
        if s == 0:
            continue
        base = _element_base(sym)
        base_signs.setdefault(base, set()).add(int(s))
    return {b: len(ss) > 1 for b, ss in base_signs.items()}


def _expected_afm_label(base: str, sign: int, splits: dict[str, bool]) -> str:
    if sign == 0:
        return base
    if not splits.get(base, False):
        return base
    up = f"{base}1" if len(base) <= 2 else f"{base[:2]}1"
    dn = f"{base}2" if len(base) <= 2 else f"{base[:2]}2"
    try:
        mo = _load_mag_orders()
        up, dn = mo._afm_species_labels(base)
    except Exception:
        pass
    return up if sign > 0 else dn


def audit_afm_pattern(content: str, order: str) -> list[str]:
    o = (order or "").strip().lower()
    if not o.startswith("afm-"):
        return []
    positions = _parse_position_lines(content)
    if len(positions) < 2:
        return ["ATOMIC_POSITIONS incomplet pour audit AFM"]
    mode = _afm_mode(o)
    signs = _afm_site_signs(positions, mode)
    mag = [s for s in signs if s]
    if len(mag) < 2:
        return ["AFM : moins de 2 sites magnétiques dans la maille"]
    if all(s == mag[0] for s in mag):
        return ["AFM : motif colinéaire identique sur tous les sites magnétiques"]
    splits = _element_splits(positions, signs)
    issues: list[str] = []
    for i, ((lab, pos), s) in enumerate(zip(positions, signs)):
        base = _element_base(lab)
        exp = _expected_afm_label(base, s, splits)
        if lab != exp:
            issues.append(
                f"site {i + 1} ({base} {pos[0]:.4f},{pos[1]:.4f},{pos[2]:.4f}) : "
                f"étiquette « {lab} », attendu « {exp} » pour {o.upper()}"
            )
            if len(issues) >= 8:
                issues.append("… autres sites incohérents (motif AFM)")
                break
    return issues


def audit_fm_pattern(content: str) -> list[str]:
    species = []
    m = re.search(
        r"ATOMIC_SPECIES\s*(.*?)(?=ATOMIC_POSITIONS|CELL_PARAMETERS|\Z)",
        content,
        re.I | re.S,
    )
    if m:
        for line in m.group(1).splitlines():
            t = line.split("!")[0].strip()
            if t:
                species.append(t.split()[0])
    issues: list[str] = []
    for sym in species:
        if re.match(r"^[A-Za-z]+[12]$", sym) and _carries_moment(_element_base(sym)):
            issues.append(
                f"FM : espèce « {sym} » (sous-maille AFM) — attendu symbole unique (ex. Cr, Gd)"
            )
    block = ""
    sm = re.search(r"&SYSTEM([\s\S]*?)/", content, re.I)
    if sm:
        block = sm.group(1)
    mags: list[float] = []
    for mm in re.finditer(
        r"starting_magnetization\s*\(\s*(\d+)\s*\)\s*=\s*([-+]?\d*\.?\d+(?:[dD][+-]?\d+)?)",
        block,
        re.I,
    ):
        raw = mm.group(2).replace("d", "E").replace("D", "E")
        try:
            mags.append(float(raw))
        except ValueError:
            continue
    nonzero = [v for v in mags if abs(v) > 1e-9]
    if len(nonzero) >= 2 and any(v * nonzero[0] < 0 for v in nonzero[1:]):
        issues.append("FM : starting_magnetization de signes opposés (moments non parallèles)")
    return issues


def _cell_axis_lengths_angstrom(content: str) -> list[float] | None:
    vecs: list[tuple[float, float, float]] = []
    take = False
    for ln in (content or "").splitlines():
        s = ln.strip()
        if re.match(r"^CELL_PARAMETERS\b", s, re.I):
            take = True
            continue
        if not take:
            continue
        if not s or s.startswith("!") or s.startswith("#"):
            continue
        if re.match(r"^[A-Za-z]", s):
            break
        toks = s.replace(",", " ").split()
        if len(toks) < 3:
            break
        try:
            vecs.append(
                tuple(float(t.replace("d", "e").replace("D", "e")) for t in toks[:3])
            )
        except ValueError:
            break
        if len(vecs) == 3:
            break
    if len(vecs) != 3:
        return None
    return [math.sqrt(sum(c * c for c in v)) for v in vecs]


def _parse_nat(content: str) -> int | None:
    m = re.search(r"^\s*nat\s*=\s*(\d+)", content or "", re.I | re.M)
    return int(m.group(1)) if m else None


def audit_afm_supercell(content: str, order: str, nm_content: str | None) -> list[str]:
    o = (order or "").strip().lower()
    if o == "afm-g" or not o.startswith("afm-"):
        return []
    axis = {"afm-a": 2, "afm-b": 1, "afm-c": 2}.get(o)
    if axis is None:
        return []
    issues: list[str] = []
    nat = _parse_nat(content)
    n_pos = len(_parse_position_lines(content))
    nat_eff = nat if nat is not None else n_pos
    nat_nm = _parse_nat(nm_content) if nm_content else None
    n_pos_nm = len(_parse_position_lines(nm_content or ""))
    ref_nat = nat_nm if nat_nm is not None else n_pos_nm
    if ref_nat > 0 and nat_eff < ref_nat * 2 - 2:
        issues.append(
            f"AFM {o.upper()} : {nat_eff} atomes — supercell attendue "
            f"(≈ {2 * ref_nat} atomes, maille NM = {ref_nat})"
        )
    if nm_content:
        lens = _cell_axis_lengths_angstrom(content)
        lens0 = _cell_axis_lengths_angstrom(nm_content)
        if lens and lens0 and len(lens) == 3 and len(lens0) == 3 and lens0[axis] > 1e-6:
            ratio = lens[axis] / lens0[axis]
            if ratio < 1.75:
                ax = ("x", "y", "z")[axis]
                sc = {"afm-a": "1×1×2", "afm-b": "1×2×1", "afm-c": "1×1×2"}.get(o, "")
                issues.append(
                    f"AFM {o.upper()} : supercell {sc} — vecteur {ax} non doublé "
                    f"({lens[axis]:.4f} Å vs {lens0[axis]:.4f} Å NM, ratio {ratio:.2f}, attendu ≈ 2)"
                )
    return issues


def audit_mag_physics(content: str, order: str, nm_content: str | None = None) -> list[str]:
    o = (order or "").strip().lower()
    issues: list[str] = []
    if o.startswith("afm-"):
        issues.extend(audit_afm_supercell(content, o, nm_content))
        issues.extend(audit_afm_pattern(content, o))
    elif o == "fm":
        issues.extend(audit_fm_pattern(content))
    return issues


if __name__ == "__main__":
    import json

    import sqs_server as srv

    print(json.dumps(srv._audit_all_mag_orders_local("GdCrO3"), indent=2, ensure_ascii=False))

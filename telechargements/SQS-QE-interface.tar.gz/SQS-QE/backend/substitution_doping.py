"""Substitution dopant sur une sous-maille : (hôte)₁₋ₓ + (dopant)ₓ — supercellule + répartition SQS simple."""
from __future__ import annotations

import math
import os
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OPTQ = Path(os.environ.get("OPTQ_ROOT", Path.home() / "optimisation-QE")).expanduser()
sys.path.insert(0, str(OPTQ / "backend"))
os.environ.setdefault("OPTQ_INPUTS", str(ROOT / "inputs"))

from mag_orders import _parse_input_text, _replace_card  # type: ignore
from mag_reference import element_base_symbol  # type: ignore
from optim import _namelist_set  # type: ignore
from phases import (  # type: ignore
    find_workflow_input,
    input_filename,
    material_inputs_base,
    material_inputs_root,
    normalize_phase_id,
)

_NM_KINDS = ("vc-relax", "relax", "scf")
_DOP_DIR_RE = re.compile(r"^dop_[A-Za-z0-9]+_[A-Za-z0-9]+_\d+$", re.I)


def _normalize_dopant_fractions(fractions: list[float] | list[int] | list[str]) -> list[float]:
    """Accepte 0,25 ou 25 (%) → fractions strictement entre 0 et 1."""
    out: list[float] = []
    for raw in fractions or []:
        try:
            v = float(raw)
        except (TypeError, ValueError):
            continue
        if not math.isfinite(v) or v <= 0:
            continue
        if v >= 1:  # pourcentages UI (5, 10, 25…)
            if v > 100:
                continue
            v = v / 100.0
        if 0 < v < 1:
            out.append(round(v, 6))
    return sorted(set(out))


def _job_material_dir(job_mat: str) -> Path:
    """Racine inputs/materiaux/<job>/ (pas un sous-dossier dop_* résolu par hasard)."""
    return material_inputs_base(job_mat.strip())


def _doping_input_basename(prefix: str, kind: str) -> str:
    """Nom du fichier .in pour une phase dopée avec préfixe = formule."""
    k = str(kind or "vc-relax").lower().replace("_", "-")
    if k not in _NM_KINDS:
        k = "vc-relax" if "vc" in k else k
    return f"{prefix}-{k}.in"


def _purge_alien_doping_inputs(dst_root: Path, keep_prefix: str, job_mat: str = "") -> None:
    """Supprime d'anciens .in dont le préfixe ≠ formule générale A(1-x)Dx (garde les alias job)."""
    job = (job_mat or "").strip()
    for kind in _NM_KINDS:
        for p in dst_root.glob(f"*-{kind}.in"):
            if "rescue" in p.name.lower() or ".orig" in p.name.lower():
                continue
            if keep_prefix and p.name.startswith(f"{keep_prefix}-"):
                continue
            if job and p.name.startswith(f"{job}-"):
                continue
            try:
                p.unlink()
            except OSError:
                pass


def _input_looks_real(path: Path) -> bool:
    try:
        body = path.read_text(encoding="utf-8")
    except OSError:
        return False
    low = body.lower()
    if "à compléter" in body or "maille / positions" in body:
        return False
    return "&control" in low or "atomic_species" in low or "cell_parameters" in low


def _ensure_vc_relax_namelist(text: str) -> str:
    """Passe un input RELAX (ou autre) en calcul VC-RELAX pour Quantum ESPRESSO."""
    out = _namelist_set(text, "CONTROL", "calculation", "'vc-relax'")
    out = _namelist_set(out, "CONTROL", "tprnfor", ".true.")
    out = _namelist_set(out, "CONTROL", "tstress", ".true.")
    return out


def _doping_dir_has_real_inputs(dst: Path) -> bool:
    if not dst.is_dir():
        return False
    for p in dst.glob("*.in"):
        if "rescue" in p.name.lower() or p.name.startswith("."):
            continue
        if _input_looks_real(p):
            return True
    return False


def _doping_dir_complete(dst: Path, job_mat: str = "") -> bool:
    """Phase dopée utilisable : au moins un VC-RELAX réel dans le dossier."""
    if not dst.is_dir():
        return False
    job = (job_mat or "").strip()
    if job and _input_in_phase_dir(dst, job, "vc-relax"):
        p = _input_in_phase_dir(dst, job, "vc-relax")
        return bool(p and _input_looks_real(p))
    for p in dst.glob("*-vc-relax.in"):
        if p.is_file() and _input_looks_real(p):
            return True
    return False


def _cleanup_empty_dop_dirs(job_mat: str) -> list[str]:
    """Supprime les dop_* vides (souvent créés par erreur sans génération)."""
    job = job_mat.strip()
    root = _job_material_dir(job)
    if not root.is_dir():
        return []
    actions: list[str] = []
    for d in sorted(root.iterdir(), key=lambda p: p.name.lower()):
        if not d.is_dir() or not _DOP_DIR_RE.match(d.name):
            continue
        if any(d.glob("*.in")):
            continue
        try:
            d.rmdir()
            actions.append(f"dossier vide supprimé : {d.name}")
        except OSError:
            pass
    return actions


def _ensure_doped_output_dir(mat: str, phase_id: str) -> Path:
    """Miroir outputs/materiaux/<Mat>/dop_*/optimisation/ (profil Calcul dopé)."""
    pid = normalize_phase_id(phase_id)
    out = ROOT / "outputs" / "materiaux" / mat.strip() / pid / "optimisation"
    out.mkdir(parents=True, exist_ok=True)
    return out


def _host_dopant_from_phase_id(phase_id: str) -> tuple[str, str]:
    """dop_Cr_Ga_25 → (Cr, Ga)."""
    m = re.match(r"^dop_([A-Za-z0-9]+)_([A-Za-z0-9]+)_\d+$", (phase_id or "").strip(), re.I)
    if not m:
        return "", ""
    return m.group(1), m.group(2)


def _detect_formula_prefix(d: Path, job_mat: str = "") -> str:
    """Préfixe des .in : préfère A(1-x)Dx, sinon formule stœchiométrique."""
    job = (job_mat or "").strip()
    # Priorité : formule générale depuis le nom dop_* 
    host, dop = _host_dopant_from_phase_id(d.name if d.is_dir() else "")
    if host and dop:
        return _general_formula_prefix(host, dop)
    scores: dict[str, int] = {}
    for p in d.glob("*.in"):
        name = p.name
        low = name.lower()
        if "rescue" in low or "nscf" in low or ".orig" in low:
            continue
        for kind in _NM_KINDS:
            suf = f"-{kind}.in"
            if not name.endswith(suf):
                continue
            pre = name[: -len(suf)]
            if not pre or pre == job:
                continue
            # Favoriser explicitement A(1-x)Dx
            bonus = 100 if "(1-x)" in pre else 0
            scores[pre] = scores.get(pre, 0) + 1 + bonus
    if not scores:
        return ""
    return max(scores.keys(), key=lambda k: (scores[k], k))


def _sync_doped_folder_layout(dst_root: Path, job_mat: str, file_prefix: str = "") -> list[str]:
    """Alias {job_mat}-{kind}.in + complète les kinds manquants depuis vc-relax (formule)."""
    actions: list[str] = []
    job = (job_mat or "").strip()
    if not dst_root.is_dir() or not job:
        return actions
    prefix = (file_prefix or "").strip() or _detect_formula_prefix(dst_root, job)
    if not prefix:
        return actions

    by_kind: dict[str, Path] = {}
    for kind in _NM_KINDS:
        form = dst_root / _doping_input_basename(prefix, kind)
        alias = dst_root / input_filename(job, kind)
        if form.is_file() and _input_looks_real(form):
            by_kind[kind] = form
        elif alias.is_file() and _input_looks_real(alias):
            by_kind[kind] = alias

    vc = by_kind.get("vc-relax")
    if vc and "relax" not in by_kind:
        dst = dst_root / _doping_input_basename(prefix, "relax")
        if not dst.is_file():
            dst.write_text(vc.read_text(encoding="utf-8"), encoding="utf-8")
            actions.append(f"relax←vc-relax ({dst.name})")
            by_kind["relax"] = dst
    if not vc and by_kind.get("relax"):
        dst = dst_root / _doping_input_basename(prefix, "vc-relax")
        if not dst.is_file() or not _input_looks_real(dst):
            src = by_kind["relax"]
            text = _ensure_vc_relax_namelist(src.read_text(encoding="utf-8"))
            dst.write_text(text, encoding="utf-8")
            actions.append(f"vc-relax←relax ({dst.name})")
            by_kind["vc-relax"] = dst
            vc = dst
    if by_kind.get("relax") and "scf" not in by_kind:
        dst = dst_root / _doping_input_basename(prefix, "scf")
        if not dst.is_file():
            src = by_kind["relax"]
            dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
            actions.append(f"scf←relax ({dst.name})")
            by_kind["scf"] = dst

    for kind in _NM_KINDS:
        src = by_kind.get(kind)
        if not src or not src.is_file():
            continue
        alias = dst_root / input_filename(job, kind)
        if alias.is_file() and _input_looks_real(alias):
            continue
        alias.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
        actions.append(f"alias {alias.name}")
    return actions


def _guarantee_phase_vc_relax(dst_root: Path, job_mat: str, file_prefix: str) -> None:
    """Garantit *-vc-relax.in + alias job dans dop_* (repli depuis RELAX si besoin)."""
    job = (job_mat or "").strip()
    prefix = (file_prefix or "").strip()
    if not dst_root.is_dir() or not job or not prefix:
        return
    form_vc = dst_root / _doping_input_basename(prefix, "vc-relax")
    alias_vc = dst_root / input_filename(job, "vc-relax")
    if form_vc.is_file() and _input_looks_real(form_vc):
        if not alias_vc.is_file() or not _input_looks_real(alias_vc):
            alias_vc.write_text(form_vc.read_text(encoding="utf-8"), encoding="utf-8")
        return
    relax_cands = [
        dst_root / _doping_input_basename(prefix, "relax"),
        dst_root / input_filename(job, "relax"),
    ]
    for src in relax_cands:
        if not src.is_file() or not _input_looks_real(src):
            continue
        text = _ensure_vc_relax_namelist(src.read_text(encoding="utf-8"))
        form_vc.write_text(text, encoding="utf-8")
        alias_vc.write_text(text, encoding="utf-8")
        return


def _validate_doping_job_material(job_mat: str, parent_a: str = "", parent_b: str = "") -> str | None:
    """Job dopé ≠ parents : dop_* uniquement sous inputs/materiaux/<job>/, jamais sous le parent NM."""
    job = (job_mat or "").strip()
    pa = (parent_a or "").strip()
    pb = (parent_b or "").strip()
    if not job:
        return (
            "Indiquez le matériau job (dossier dopé), ex. GdCrO3_doped — "
            "distinct de inputs/materiaux/GdCrO3/ (parent non dopé)."
        )
    if pa and job == pa:
        return (
            f"Le job dopé doit être un dossier séparé du parent non dopé "
            f"(ex. {pa} → job {pa}_doped). Les dop_* ne vont pas sous inputs/materiaux/{pa}/."
        )
    if pb and job == pb:
        return f"Le job « {job} » doit être distinct du parent x = 100 % ({pb})."
    return None


def _relocate_stray_dop_dirs(parent_a: str, job_mat: str) -> list[str]:
    """Déplace dop_* créés par erreur sous le parent NM vers le dossier job dopé."""
    pa = (parent_a or "").strip()
    job = (job_mat or "").strip()
    if not pa or not job or pa == job:
        return []
    parent_root = material_inputs_base(pa)
    job_root = _job_material_dir(job)
    if not parent_root.is_dir():
        return []
    job_root.mkdir(parents=True, exist_ok=True)
    actions: list[str] = []
    for d in sorted(parent_root.iterdir(), key=lambda p: p.name.lower()):
        if not d.is_dir() or not _DOP_DIR_RE.match(d.name):
            continue
        dest = job_root / d.name
        if dest.exists():
            actions.append(f"conserve {d.name} sous {job} (doublon ignoré sous {pa})")
            continue
        shutil.move(str(d), str(dest))
        actions.append(f"déplacé {d.name} : materiaux/{pa}/ → materiaux/{job}/")
    return actions


def _read_existing_formula_title(dst: Path) -> str:
    """Lit ! Title: / ! Formula: déjà présents (conserve A(1-x)Dx · stœchiométrie)."""
    if not dst.is_dir():
        return ""
    try:
        for p in sorted(dst.glob("*.in"), key=lambda x: x.name.lower()):
            if "rescue" in p.name.lower() or ".orig" in p.name.lower():
                continue
            for ln in p.read_text(encoding="utf-8").splitlines():
                s = ln.strip()
                if re.match(r"!\s*Title:", s, re.I):
                    return s.split(":", 1)[1].strip()
            for ln in p.read_text(encoding="utf-8").splitlines():
                s = ln.strip()
                if re.match(r"!\s*Formula:", s, re.I):
                    return s.split(":", 1)[1].strip()
    except OSError:
        return ""
    return ""


def repair_doped_job_layout(mat: str, *, parent_material_a: str = "", prep_mag: bool = True) -> dict:
    """Réaligne inputs/outputs dop_* sous le job dopé (pas sous le parent NM).

    prep_mag=False : utile avant génération NM (évite un plantage mag/numpy qui
    empêcherait d’écrire les .in dopés).
    """
    job = mat.strip()
    pa = (parent_material_a or "").strip()
    actions: list[str] = []
    actions.extend(_cleanup_empty_dop_dirs(job))
    if pa:
        actions.extend(_relocate_stray_dop_dirs(pa, job))
    root = _job_material_dir(job)
    if not root.is_dir():
        root.mkdir(parents=True, exist_ok=True)
    for d in sorted(root.iterdir(), key=lambda p: p.name.lower()):
        if not d.is_dir() or not _DOP_DIR_RE.match(d.name):
            continue
        pid = d.name
        prefix = _detect_formula_prefix(d, job)
        keep_title = _read_existing_formula_title(d)
        actions.extend(_sync_doped_folder_layout(d, job, prefix))
        _guarantee_phase_vc_relax(d, job, prefix)
        actions.extend(_sync_doped_folder_layout(d, job, prefix))
        _ensure_doped_output_dir(job, pid)
        _finalize_doped_phase_inputs(
            d, job, pid, prefix, formula_title=keep_title or prefix
        )
        if prep_mag and _doping_dir_complete(d, job):
            try:
                mag = prepare_magnetic_inputs_for_doped_phase(job, pid)
            except Exception as exc:  # noqa: BLE001
                actions.append(f"mag {pid}: ignoré ({exc})")
                continue
            summ = mag.get("summary") or {}
            if mag.get("ok") and summ.get("n_orders"):
                ords = summ.get("orders") or []
                tail = "…" if len(ords) > 5 else ""
                actions.append(
                    f"mag {pid}: {summ['n_orders']} ordre(s) "
                    f"({', '.join(ords[:5])}{tail}) → dop_*/mag/{{fm,afm*,ncl}}/"
                )
            elif not mag.get("ok"):
                actions.append(f"mag {pid}: {mag.get('error') or 'échec FM/AFM/NCL'}")
    stray_on_job_root = [
        p.name
        for p in root.glob("*.in")
        if p.is_file() and not _DOP_DIR_RE.match(p.name) and p.name.startswith(f"{job}-")
    ]
    note_fr = ""
    if stray_on_job_root and not any(_DOP_DIR_RE.match(x) for x in (p.name for p in root.iterdir() if p.is_dir())):
        note_fr = " Astuce : la chaîne NM du job dopé vit dans dop_* ; les parents restent dans leur dossier."
    return {
        "ok": True,
        "material": job,
        "parent_material_a": pa or None,
        "actions": actions,
        "message_fr": (
            (f"Séparation dopé / non dopé : {len(actions)} action(s)." if actions else "Layout dopé OK.")
            + note_fr
        ),
        "message_en": (
            f"Doped vs undoped layout: {len(actions)} action(s)." if actions else "Doped layout OK."
        ),
    }


def _doped_pw_outdir(job_mat: str, phase_id: str, kind: str, mag_order: str = "") -> Path:
    """outputs/materiaux/<job>/dop_*/optimisation/… ou …/magnetisme/<ordre>/."""
    job = job_mat.strip()
    pid = normalize_phase_id(phase_id)
    k = str(kind or "scf").lower().replace("_", "-")
    slug = {"vc-relax": "vcrelax", "relax": "relax", "scf": "scf", "nscf": "nscf"}.get(
        k, k.replace("-", "")
    )
    base = ROOT / "outputs" / "materiaux" / job / pid
    mo = (mag_order or "").strip().lower()
    if mo and mo != "nm":
        return base / "magnetisme" / mo
    return base / "optimisation" / slug


def _patch_formula_comment(
    text: str,
    formula_title: str,
    *,
    formula_general: str = "",
) -> str:
    """Écrit ! Title: et ! Formula: — formule générale A(1-x)Dx (évent. + stœchiométrie)."""
    if not (formula_title or "").strip() and not (formula_general or "").strip():
        return text
    title = (formula_title or formula_general or "").strip()
    # Formula = partie générale seule si le titre contient aussi la stœchiométrie.
    gen = (formula_general or "").strip()
    if not gen and "·" in title:
        gen = title.split("·", 1)[0].strip()
    if not gen:
        gen = title
    title_line = f"! Title: {title}"
    formula_line = f"! Formula: {gen}"
    lines: list[str] = []
    replaced_f = False
    replaced_t = False
    for ln in text.splitlines():
        s = ln.strip()
        if re.match(r"!\s*Formula:", s, re.I):
            lines.append(formula_line)
            replaced_f = True
        elif re.match(r"!\s*Title:", s, re.I):
            lines.append(title_line)
            replaced_t = True
        else:
            lines.append(ln)
    if not replaced_f or not replaced_t:
        insert_at = 0
        for i, ln in enumerate(lines):
            if "Quantum ESPRESSO" in ln or "Generated by" in ln:
                insert_at = i + 1
        block: list[str] = []
        if not replaced_t:
            block.append(title_line)
        if not replaced_f:
            block.append(formula_line)
        for j, b in enumerate(block):
            lines.insert(insert_at + j, b)
    body = "\n".join(lines)
    return body if body.endswith("\n") else body + "\n"


def _patch_outdir_in_text(text: str, outdir: Path) -> str:
    od = str(outdir.expanduser()).replace("\\", "/")
    if re.search(r"^\s*outdir\s*=", text, re.I | re.M):
        return re.sub(
            r"^\s*outdir\s*=.*$",
            f"  outdir = '{od}'",
            text,
            count=1,
            flags=re.I | re.M,
        )
    return _namelist_set(text, "CONTROL", "outdir", f"'{od}'")


def _insert_species_mag_guide(text: str) -> str:
    """Commentaire d'alignement starting_magnetization(i) ↔ i-ième ligne ATOMIC_SPECIES."""
    try:
        from optim import _namelist_get, _parse_atomic_species_symbols  # type: ignore
    except ImportError:
        return text
    try:
        ns = int(str(_namelist_get(text, "SYSTEM", "nspin") or "1").strip())
    except (TypeError, ValueError):
        ns = 1
    if ns not in (2, 4):
        return text
    species = _parse_atomic_species_symbols(text)
    if not species:
        return text
    guide = "! Ordre des types dans ATOMIC_SPECIES : " + ", ".join(
        f"{i}:{s}" for i, s in enumerate(species, 1)
    )
    out: list[str] = []
    inserted = False
    for ln in text.splitlines():
        if "ATOMIC_SPECIES" in ln and ln.strip().startswith("! Ordre"):
            continue
        if not inserted and re.search(r"starting_magnetization\s*\(\s*1\s*\)", ln, re.I):
            out.append(f"  {guide}")
            inserted = True
        out.append(_label_starting_mag_line(ln, species))
    body = "\n".join(out)
    return body if body.endswith("\n") else body + "\n"


def _label_starting_mag_line(line: str, species: list[str]) -> str:
    m = re.match(
        r"^(\s*starting_magnetization\s*\(\s*(\d+)\s*\)\s*=\s*[^!]+)(?:\s*!.*)?$",
        line,
        re.I,
    )
    if not m:
        return line
    idx = int(m.group(2))
    sym = species[idx - 1] if 0 < idx <= len(species) else "?"
    return f"{m.group(1).rstrip()}  ! {sym}"


def _finalize_doped_input_text(
    text: str,
    *,
    job_mat: str,
    phase_id: str,
    file_prefix: str,
    kind: str,
    mag_order: str = "",
    formula_title: str = "",
    formula_general: str = "",
) -> str:
    fp = (file_prefix or "").strip()
    gen = (formula_general or "").strip() or (
        fp if "(1-x)" in fp else ""
    )
    title = (formula_title or "").strip() or gen or fp
    out = _patch_formula_comment(text, title, formula_general=gen or title)
    out = _patch_outdir_in_text(out, _doped_pw_outdir(job_mat, phase_id, kind, mag_order))
    if fp:
        out = _namelist_set(out, "CONTROL", "prefix", f"'{fp}'")
    out = _insert_species_mag_guide(out)
    return out


def _finalize_doped_phase_inputs(
    dst_root: Path,
    job_mat: str,
    phase_id: str,
    file_prefix: str,
    formula_title: str = "",
    formula_general: str = "",
) -> None:
    """Formule générale A(1-x)Dx en titre + prefix, outdir, commentaires mag."""
    host, dop = _host_dopant_from_phase_id(phase_id or dst_root.name)
    gen = (formula_general or "").strip() or (
        _general_formula(host, dop) if host and dop else ""
    )
    prefix = (
        (file_prefix or "").strip()
        or ( _general_formula_prefix(host, dop) if host and dop else "" )
        or _detect_formula_prefix(dst_root, job_mat)
    )
    title = (formula_title or "").strip() or _read_existing_formula_title(dst_root) or gen or prefix
    if not dst_root.is_dir() or not prefix:
        return
    # Renommer d'anciens *.in stœchiométriques vers A(1-x)Dx-*.in
    for kind in _NM_KINDS:
        target = dst_root / _doping_input_basename(prefix, kind)
        if target.is_file() and _input_looks_real(target):
            continue
        for p in list(dst_root.glob(f"*-{kind}.in")):
            if p.name.startswith(f"{job_mat}-") or p.name.startswith(f"{prefix}-"):
                continue
            if "rescue" in p.name.lower() or ".orig" in p.name.lower():
                continue
            if _input_looks_real(p):
                try:
                    target.write_text(p.read_text(encoding="utf-8"), encoding="utf-8")
                    p.unlink()
                except OSError:
                    pass
                break
    _purge_alien_doping_inputs(dst_root, prefix, job_mat=job_mat)
    finalized_by_kind: dict[str, str] = {}
    for p in sorted(dst_root.glob("*.in"), key=lambda x: x.name.lower()):
        if "rescue" in p.name.lower() or ".orig" in p.name.lower():
            continue
        kind = "scf"
        for k in _NM_KINDS:
            if p.name.endswith(f"-{k}.in"):
                kind = k
                break
        try:
            raw = p.read_text(encoding="utf-8")
        except OSError:
            continue
        new_text = _finalize_doped_input_text(
            raw,
            job_mat=job_mat,
            phase_id=phase_id,
            file_prefix=prefix,
            kind=kind,
            formula_title=title,
            formula_general=gen or prefix,
        )
        # Fichier canonique = A(1-x)Dx-*.in ; alias job = même contenu (prefix aligné).
        want = dst_root / _doping_input_basename(prefix, kind)
        alias = dst_root / input_filename(job_mat, kind) if job_mat else None
        prefer_src = p.name.startswith(f"{prefix}-") or not finalized_by_kind.get(kind)
        if prefer_src or kind not in finalized_by_kind:
            finalized_by_kind[kind] = new_text
        want.write_text(finalized_by_kind[kind], encoding="utf-8")
        if alias is not None:
            alias.write_text(finalized_by_kind[kind], encoding="utf-8")
        if (
            p.resolve() != want.resolve()
            and (alias is None or p.resolve() != alias.resolve())
        ):
            try:
                p.unlink()
            except OSError:
                pass
    mag_root = dst_root / "mag"
    if not mag_root.is_dir():
        return
    for ord_dir in sorted(mag_root.iterdir(), key=lambda p: p.name.lower()):
        if not ord_dir.is_dir():
            continue
        order = ord_dir.name
        for p in sorted(ord_dir.glob("*.in"), key=lambda x: x.name.lower()):
            kind = "scf"
            for k in (*_NM_KINDS, "nscf"):
                if p.name.endswith(f"-{k}.in"):
                    kind = k
                    break
            try:
                raw = p.read_text(encoding="utf-8")
            except OSError:
                continue
            new_text = _finalize_doped_input_text(
                raw,
                job_mat=job_mat,
                phase_id=phase_id,
                file_prefix=prefix,
                kind=kind,
                mag_order=order,
                formula_title=title,
                formula_general=gen or prefix,
            )
            if new_text != raw:
                p.write_text(new_text, encoding="utf-8")


def _mag_prep_summary(prep: dict) -> dict:
    prepared = [p for p in (prep.get("prepared") or []) if p.get("ok")]
    return {
        "ok": bool(prep.get("ok")),
        "orders": [str(p.get("order") or "") for p in prepared if p.get("order")],
        "n_orders": len(prepared),
        "error": prep.get("error"),
        "mag_path": "",
    }


def prepare_magnetic_inputs_for_doped_phase(job_mat: str, phase_id: str) -> dict:
    """FM / AFM (nspin=2) + NCL (nspin=4) sous inputs/…/<job>/dop_*/mag/<ordre>/."""
    job = job_mat.strip()
    pid = normalize_phase_id(phase_id)
    if not job or not pid or not _DOP_DIR_RE.match(pid):
        return {"ok": False, "error": f"Phase dopée invalide « {phase_id} »", "phase_id": pid or phase_id}
    dst = material_inputs_root(job, pid)
    if not _doping_dir_complete(dst, job):
        return {
            "ok": False,
            "error": "Chaîne NM incomplète (VC-RELAX requis avant le magnétisme).",
            "phase_id": pid,
            "material": job,
        }
    host, dop = _host_dopant_from_phase_id(pid)
    prefix = (
        _general_formula_prefix(host, dop)
        if host and dop
        else _detect_formula_prefix(dst, job)
    )
    keep_title = _read_existing_formula_title(dst)
    gen = _general_formula(host, dop) if host and dop else prefix
    if keep_title and gen and gen not in keep_title and "(1-x)" not in keep_title:
        # Ancien titre stœchiométrique seul → reconstruire A(1-x)Dx · stoich
        keep_title = f"{gen}  ·  {keep_title}"
    elif not keep_title:
        keep_title = gen or prefix
    try:
        from mag_orders import prepare_magnetic_scf  # type: ignore

        prep = prepare_magnetic_scf(job, pid)
    except ImportError as exc:
        # numpy / postproc absents : ne pas faire échouer la génération NM dopée
        return {
            "ok": False,
            "error": f"Magnétisme non généré (dépendance manquante : {exc}). Les .in NM restent valides.",
            "phase_id": pid,
            "material": job,
            "summary": {"orders": [], "n_orders": 0, "mag_path": f"inputs/materiaux/{job}/{pid}/mag/"},
        }
    except Exception as exc:  # noqa: BLE001 — isole le mag du flux NM
        return {
            "ok": False,
            "error": f"Magnétisme non généré : {exc}",
            "phase_id": pid,
            "material": job,
            "summary": {"orders": [], "n_orders": 0, "mag_path": f"inputs/materiaux/{job}/{pid}/mag/"},
        }
    _finalize_doped_phase_inputs(
        dst,
        job,
        pid,
        prefix,
        formula_title=keep_title or prefix,
        formula_general=gen or prefix,
    )
    summary = _mag_prep_summary(prep)
    summary["mag_path"] = f"inputs/materiaux/{job}/{pid}/mag/"
    return {
        **prep,
        "material": job,
        "phase_id": pid,
        "summary": summary,
    }


def prepare_magnetic_inputs_for_doped_job(job_mat: str) -> dict:
    """Prépare le magnétisme pour tous les dossiers dop_* du job."""
    job = job_mat.strip()
    root = _job_material_dir(job)
    phases: list[dict] = []
    if not root.is_dir():
        return {"ok": False, "material": job, "error": "Dossier job dopé introuvable.", "phases": []}
    for d in sorted(root.iterdir(), key=lambda p: p.name.lower()):
        if not d.is_dir() or not _DOP_DIR_RE.match(d.name):
            continue
        phases.append(prepare_magnetic_inputs_for_doped_phase(job, d.name))
    ok = bool(phases) and all(p.get("ok") for p in phases)
    return {"ok": ok, "material": job, "phases": phases}


def _ensure_doping_phase_dir(job_mat: str, phase_id: str, *, copy_from: str = "") -> tuple[Path | None, str | None]:
    """Crée inputs/materiaux/<job_dopé>/dop_…/ (sans copier les .in du parent NM)."""
    del copy_from  # structure lue depuis parent_material_a dans generate_doping
    pid = normalize_phase_id(phase_id)
    if not pid or not _DOP_DIR_RE.match(pid):
        return None, f"Nom de dossier dopage invalide « {phase_id} »"
    dst = material_inputs_root(job_mat, pid)
    if dst.is_dir() and _doping_dir_complete(dst, job_mat):
        return dst, None
    dst.mkdir(parents=True, exist_ok=True)
    return dst, None

_ATOMIC_MASS: dict[str, float] = {
    "H": 1.008,
    "Li": 6.94,
    "Be": 9.012,
    "B": 10.81,
    "C": 12.011,
    "N": 14.007,
    "O": 15.999,
    "F": 18.998,
    "Na": 22.99,
    "Mg": 24.305,
    "Al": 26.9815,
    "Si": 28.085,
    "P": 30.974,
    "S": 32.06,
    "Ti": 47.867,
    "V": 50.942,
    "Cr": 51.996,
    "Mn": 54.938,
    "Fe": 55.845,
    "Co": 58.933,
    "Ni": 58.693,
    "Cu": 63.546,
    "Zn": 65.38,
    "Ga": 69.723,
    "Y": 88.906,
    "Zr": 91.224,
    "Nb": 92.906,
    "Mo": 95.95,
    "Ru": 101.07,
    "Rh": 102.906,
    "Pd": 106.42,
    "Ag": 107.868,
    "In": 114.818,
    "Sn": 118.71,
    "La": 138.905,
    "Ce": 140.116,
    "Pr": 140.908,
    "Nd": 144.242,
    "Sm": 150.36,
    "Eu": 151.964,
    "Gd": 157.25,
    "Tb": 158.925,
    "Dy": 162.5,
    "Ho": 164.93,
    "Er": 167.259,
    "Tm": 168.934,
    "Yb": 173.045,
    "Lu": 174.967,
    "Hf": 178.49,
    "Ta": 180.948,
    "W": 183.84,
    "Re": 186.207,
    "Os": 190.23,
    "Ir": 192.217,
    "Pt": 195.084,
    "Au": 196.967,
    "Pb": 207.2,
    "Bi": 208.98,
}


def _safe_element(sym: str) -> str:
    s = re.sub(r"[^A-Za-z]", "", (sym or "").strip())
    if not re.match(r"^[A-Z][a-z]?$", s):
        raise ValueError(f"Symbole chimique invalide : « {sym} »")
    return s


def _input_in_phase_dir(droot: Path, mat: str, kind: str) -> Path | None:
    """Cherche {mat}-{kind}.in puis *-{kind}.in uniquement dans ce dossier phase."""
    if not droot.is_dir():
        return None
    k = str(kind or "").strip().lower().replace("_", "-")
    named = droot / input_filename(mat, k)
    if named.is_file() and named.stat().st_size >= 1:
        return named
    matches = sorted(
        (
            p
            for p in droot.glob(f"*-{k}.in")
            if p.is_file()
            and "rescue" not in p.name.lower()
            and "nscf" not in p.name.lower()
            and ".orig" not in p.name.lower()
        ),
        key=lambda p: p.name.lower(),
    )
    return matches[0] if matches else None


def resolve_material_input_file(mat: str, kind: str, phase_id: str = "") -> Path | None:
    """Chemin d'un .in NM (racine matériau ou dossier dop_* strict)."""
    mat = mat.strip()
    k = str(kind or "").strip().lower().replace("_", "-")
    if k not in _NM_KINDS:
        return None
    pid = normalize_phase_id(phase_id)
    if pid:
        phase_dir = material_inputs_root(mat, pid)
        if _DOP_DIR_RE.match(pid) and phase_dir.is_dir():
            _sync_doped_folder_layout(phase_dir, mat, "")
        p = _input_in_phase_dir(phase_dir, mat, k)
        return p if p and p.is_file() else None
    p = find_workflow_input(mat, k, "", min_bytes=1)
    return p if p and p.is_file() else None


def _find_parent_nm_input(mat: str, kind: str, phase_id: str = "") -> Path | None:
    """Input NM du matériau parent (racine ou sous-dossier phase)."""
    pid = normalize_phase_id(phase_id)
    p = find_workflow_input(mat, kind, pid)
    if p and p.is_file():
        return p
    root = material_inputs_root(mat, pid)
    cand = root / input_filename(mat, kind)
    if cand.is_file():
        return cand
    return None


def _workflow_source_in(mat: str, kind: str, phase_id: str = "") -> Path | None:
    """Input NM du matériau parent (pas le dossier job dopé)."""
    pid = normalize_phase_id(phase_id)
    p = _find_parent_nm_input(mat, kind, pid)
    if p:
        return p
    if kind == "vc-relax":
        return _find_parent_nm_input(mat, "relax", pid)
    if kind == "relax":
        return _find_parent_nm_input(mat, "vc-relax", pid)
    if kind == "scf":
        return _find_parent_nm_input(mat, "relax", pid) or _find_parent_nm_input(mat, "vc-relax", pid)
    return None


def _phase_source_in(mat: str, phase_id: str) -> Path | None:
    pid = normalize_phase_id(phase_id)
    for kind in _NM_KINDS:
        p = find_workflow_input(mat, kind, pid)
        if p and p.is_file():
            return p
    root = material_inputs_root(mat, pid)
    for kind in _NM_KINDS:
        p = root / input_filename(mat, kind)
        if p.is_file():
            return p
    return None


def _resolve_structure_input(mat: str, phase_id: str = "") -> Path | None:
    """Premier input NM trouvé (phase demandée, racine, phase1…)."""
    mat = mat.strip()
    pid = normalize_phase_id(phase_id)
    tried: set[str] = set()
    for cand in (pid, "", "phase1"):
        key = cand or "__root__"
        if key in tried:
            continue
        tried.add(key)
        src = _phase_source_in(mat, cand)
        if src is not None:
            return src
    return None


_ANION_LIKE = frozenset({"O", "F", "Cl", "Br", "I", "N", "S", "P", "H", "C", "Se", "Te"})


def suggest_host_element(
    elements_a: list[str],
    elements_b: list[str] | None,
    dopant: str = "",
) -> str | None:
    """Devine i (ex. Cr) depuis les parents x=0 / x=100 et le dopant."""
    dop = re.sub(r"[^A-Za-z]", "", (dopant or "").strip())
    cations_a = [e for e in elements_a if e not in _ANION_LIKE]
    if not cations_a:
        return None
    if elements_b:
        cations_b = {e for e in elements_b if e not in _ANION_LIKE}
        if dop and dop in cations_b:
            for e in cations_a:
                if e != dop and e not in cations_b:
                    return e
        gone = [e for e in cations_a if e not in cations_b]
        if len(gone) == 1:
            return gone[0]
    if len(cations_a) == 1:
        return cations_a[0]
    return None


def list_host_elements(
    mat: str,
    phase_id: str = "",
    *,
    parent_b: str = "",
    dopant: str = "",
) -> dict:
    """Éléments chimiques substituables (présents dans ATOMIC_SPECIES / positions).
    
    Retourne cations ET anions séparément pour permettre le dopage anionique (O→N, O→C, etc.).
    """
    mat = mat.strip()
    src = _resolve_structure_input(mat, phase_id)
    if src is None:
        return {"ok": False, "error": "Aucun input NM (vc-relax / relax / scf) pour ce matériau."}
    parsed = _parse_input_text(src.read_text(encoding="utf-8"))
    counts: dict[str, int] = {}
    for pos in parsed.get("positions") or []:
        base = element_base_symbol(pos.get("symbol") or "")
        if base:
            counts[base] = counts.get(base, 0) + 1
    elements = sorted(counts.keys())
    
    # Séparer cations et anions pour permettre les deux types de dopage
    cations = sorted(e for e in elements if e not in _ANION_LIKE)
    anions = sorted(e for e in elements if e in _ANION_LIKE)
    
    # Legacy : dopable = cations (rétrocompatibilité)
    dopable = cations or elements
    elements_b: list[str] | None = None
    pb = (parent_b or "").strip()
    if pb:
        src_b = _resolve_structure_input(pb, "")
        if src_b is not None:
            parsed_b = _parse_input_text(src_b.read_text(encoding="utf-8"))
            cb: dict[str, int] = {}
            for pos in parsed_b.get("positions") or []:
                base = element_base_symbol(pos.get("symbol") or "")
                if base:
                    cb[base] = cb.get(base, 0) + 1
            elements_b = sorted(cb.keys())
    suggested = suggest_host_element(dopable, elements_b, dopant)
    species_detail = []
    for sp in parsed.get("species") or []:
        sym = sp.get("symbol") or ""
        base = element_base_symbol(sym)
        species_detail.append(
            {
                "symbol": sym,
                "base": base,
                "count": counts.get(base, 0),
            }
        )
    return {
        "ok": True,
        "material": mat,
        "phase_id": normalize_phase_id(phase_id),
        "source": str(src),
        "elements": elements,
        "dopable_elements": dopable,  # Legacy : cations uniquement
        "cations": cations,  # Nouveau : cations séparément
        "anions": anions,    # Nouveau : anions séparément
        "suggested_host": suggested,
        "parent_b_elements": elements_b,
        "counts": counts,
        "species": species_detail,
        "nat": parsed.get("nat"),
    }


def _sublattice_indices(parsed: dict, host_element: str) -> list[int]:
    host = _safe_element(host_element)
    out: list[int] = []
    for i, pos in enumerate(parsed.get("positions") or []):
        if element_base_symbol(pos.get("symbol") or "") == host:
            out.append(i)
    return out


def _pick_repeat(n_sub: int, fractions: list[float], max_k: int = 12) -> int:
    """Facteur de réplication (nx×ny×nz) minimal pour des effectifs entiers à chaque x."""
    fr = [f for f in fractions if 0 < f < 1]
    if not fr or n_sub < 1:
        return 1
    for k in range(1, max_k + 1):
        total = n_sub * k
        ok = True
        for f in fr:
            nd = round(total * f)
            if abs(nd / total - f) > 1e-5:
                ok = False
                break
        if ok:
            return k
    return max_k


def _grid_factors(k: int) -> tuple[int, int, int]:
    if k <= 1:
        return (1, 1, 1)
    for nx in range(1, k + 1):
        if k % nx:
            continue
        rest = k // nx
        for ny in range(1, rest + 1):
            if rest % ny:
                continue
            nz = rest // ny
            return (nx, ny, nz)
    return (k, 1, 1)


def _expand_supercell(parsed: dict, nx: int, ny: int, nz: int) -> dict:
    """Réplique la maille (positions en coordonnées crystal par défaut)."""
    positions = parsed.get("positions") or []
    unit = (positions[0].get("unit") if positions else "crystal") or "crystal"
    new_pos: list[dict] = []
    sub_map: list[int] = []
    for iz in range(nz):
        for iy in range(ny):
            for ix in range(nx):
                for j, p in enumerate(positions):
                    x, y, z = p["pos"][:3]
                    if unit == "crystal":
                        new_pos.append(
                            {
                                "symbol": p["symbol"],
                                "pos": [
                                    (x + ix) / nx,
                                    (y + iy) / ny,
                                    (z + iz) / nz,
                                ],
                                "unit": unit,
                            }
                        )
                    else:
                        new_pos.append(
                            {
                                "symbol": p["symbol"],
                                "pos": [x + ix, y + iy, z + iz],
                                "unit": unit,
                            }
                        )
                    sub_map.append(j)
    out = dict(parsed)
    out["positions"] = new_pos
    out["nat"] = len(new_pos)
    out["supercell"] = {"nx": nx, "ny": ny, "nz": nz, "repeat": nx * ny * nz}
    return out


def _sublattice_after_expand(parsed: dict, host_element: str) -> list[int]:
    host = _safe_element(host_element)
    return [
        i
        for i, p in enumerate(parsed.get("positions") or [])
        if element_base_symbol(p.get("symbol") or "") == host
    ]


def _assign_dopant_sites(n_sub: int, n_dop: int, *, seed: int = 0) -> set[int]:
    """Répartition quasi-aléatoire déterministe (mélange congruentiel)."""
    if n_dop <= 0:
        return set()
    if n_dop >= n_sub:
        return set(range(n_sub))
    order = list(range(n_sub))
    state = seed & 0xFFFFFFFF
    for i in range(n_sub - 1, 0, -1):
        state = (1103515245 * state + 12345) & 0x7FFFFFFF
        j = state % (i + 1)
        order[i], order[j] = order[j], order[i]
    return set(order[:n_dop])


def _default_mass(sym: str) -> float:
    return _ATOMIC_MASS.get(sym, 1.0)


def _default_pseudo(sym: str) -> str:
    return f"{sym}.UPF"


def _apply_substitution(
    text: str,
    parsed: dict,
    *,
    host_element: str,
    dopant: str,
    dopant_site_indices: set[int],
    sublattice_indices: list[int],
    file_prefix: str = "",
) -> str:
    host = _safe_element(host_element)
    dop = _safe_element(dopant)
    positions = parsed.get("positions") or []
    species = list(parsed.get("species") or [])
    sym_to_type = {sp["symbol"]: i for i, sp in enumerate(species)}

    dop_label = dop
    if dop_label not in sym_to_type:
        ref = next((sp for sp in species if element_base_symbol(sp["symbol"]) == host), None)
        pseudo = ref["pseudo"] if ref else _default_pseudo(dop)
        if ref and ref["pseudo"].endswith(".UPF"):
            pseudo = f"{dop}.UPF"
        species.append({"symbol": dop_label, "mass": _default_mass(dop), "pseudo": pseudo})
        sym_to_type[dop_label] = len(species) - 1

    host_labels = {sp["symbol"] for sp in species if element_base_symbol(sp["symbol"]) == host}

    new_positions: list[dict] = []
    for i, p in enumerate(positions):
        sym = p["symbol"]
        if i in dopant_site_indices:
            sym = dop_label
        elif i in sublattice_indices and element_base_symbol(sym) == host:
            sym = sym if sym in host_labels else next(iter(host_labels), sym)
        new_positions.append({**p, "symbol": sym})

    used_syms = {p["symbol"] for p in new_positions}
    new_species = [sp for sp in species if sp["symbol"] in used_syms]
    nat = len(new_positions)
    ntyp = len(new_species)

    spec_lines = [
        f"  {sp['symbol']:6s} {sp['mass']:8.4f}  {sp['pseudo']}" for sp in new_species
    ]
    pos_unit = (new_positions[0].get("unit") if new_positions else "crystal") or "crystal"
    pos_lines = [
        f"  {p['symbol']:6s} {p['pos'][0]:12.8f} {p['pos'][1]:12.8f} {p['pos'][2]:12.8f}"
        for p in new_positions
    ]

    out = text
    # Mettre à jour le prefix dans &CONTROL avec la formule dopée
    if file_prefix:
        out = _namelist_set(out, "CONTROL", "prefix", f"'{file_prefix}'")
    out = _namelist_set(out, "SYSTEM", "nat", str(nat))
    out = _namelist_set(out, "SYSTEM", "ntyp", str(ntyp))
    out = _replace_card(out, "ATOMIC_SPECIES", "ATOMIC_SPECIES", spec_lines)
    out = _replace_card(
        out,
        "ATOMIC_POSITIONS",
        f"ATOMIC_POSITIONS ({pos_unit})",
        pos_lines,
    )
    return out


def _formula_counts(parsed: dict) -> dict[str, int]:
    c: dict[str, int] = {}
    for p in parsed.get("positions") or []:
        b = element_base_symbol(p.get("symbol") or "")
        if b:
            c[b] = c.get(b, 0) + 1
    return c


def _formula_display(fc: dict[str, int]) -> str:
    return " ".join(f"{k}{v}" if v != 1 else k for k, v in sorted(fc.items()))


def _formula_file_prefix(fc: dict[str, int]) -> str:
    """Préfixe stœchiométrique supercellule (fallback), ex. Cr3GaGd4O12."""
    parts: list[str] = []
    for el in sorted(fc.keys()):
        n = int(fc[el])
        if n <= 0:
            continue
        parts.append(f"{el}{n}" if n != 1 else el)
    raw = "".join(parts)
    safe = re.sub(r"[^\w]", "", raw)
    return (safe[:120] if safe else "doped")


def _general_formula(host: str, dopant: str) -> str:
    """Formule générale de substitution : A(1-x)Dx (ex. Cr(1-x)Gax)."""
    a = _safe_element(host)
    d = _safe_element(dopant)
    if not a or not d:
        return ""
    return f"{a}(1-x){d}x"


def _general_formula_prefix(host: str, dopant: str) -> str:
    """Préfixe fichier / CONTROL = formule générale (caractères sûrs pour pw.x)."""
    g = _general_formula(host, dopant)
    if not g:
        return "doped"
    # Conserve (1-x) demandé ; retire uniquement ce qui casse les chemins.
    safe = re.sub(r"[^\w().\-]", "", g)
    return (safe[:120] if safe else "doped")


def _formula_title_line(host: str, dopant: str, fc: dict[str, int] | None = None) -> str:
    """Titre .in : formule générale + optionnellement la stœchiométrie supercellule."""
    gen = _general_formula(host, dopant)
    stoich = _formula_display(fc) if fc else ""
    if gen and stoich:
        return f"{gen}  ·  {stoich}"
    return gen or stoich or "doped"


def _trial_structure_for_comp(
    expanded: dict,
    sub_idx: list[int],
    *,
    host: str,
    dop: str,
    global_dop: set[int],
) -> dict:
    trial = dict(expanded)
    trial_positions = list(trial.get("positions") or [])
    for gi in global_dop:
        trial_positions[gi] = {**trial_positions[gi], "symbol": dop}
    trial["positions"] = trial_positions
    return trial


def _phase_id_doped(host: str, dop: str, pct: int) -> str:
    h = re.sub(r"[^\w]", "", host)[:8]
    d = re.sub(r"[^\w]", "", dop)[:8]
    return f"dop_{h}_{d}_{pct:02d}"


def preview_doping(
    mat: str,
    *,
    phase_id: str = "",
    host_element: str,
    dopant: str,
    fractions: list[float],
    parent_material_a: str = "",
    parent_material_b: str = "",
) -> dict:
    host = _safe_element(host_element)
    dop = _safe_element(dopant)
    if host == dop:
        return {"ok": False, "error": "L’élément hôte et le dopant doivent être différents."}
    fr = _normalize_dopant_fractions(fractions)
    if not fr:
        return {"ok": False, "error": "Indiquez au moins une fraction x (ex. 25, 50 ou 0,25)."}

    pa = (parent_material_a or "").strip()
    job = mat.strip()
    src_mat = pa or job
    if pa and job == pa:
        return {
            "ok": False,
            "error": "Utilisez un dossier job dopé distinct du parent x = 0 % pour la série dop_*.",
        }
    src = _resolve_structure_input(src_mat, phase_id)
    if src is None:
        return {"ok": False, "error": f"Phase source introuvable pour « {src_mat} » (parent NM)."}
    base_parsed = _parse_input_text(src.read_text(encoding="utf-8"))
    n_sub0 = len(_sublattice_indices(base_parsed, host))
    if n_sub0 < 1:
        return {
            "ok": False,
            "error": f"Aucun site pour l’élément « {host} » dans cette phase.",
        }

    repeat = _pick_repeat(n_sub0, fr)
    nx, ny, nz = _grid_factors(repeat)
    expanded = _expand_supercell(base_parsed, nx, ny, nz) if repeat > 1 else dict(base_parsed)
    sub_idx = _sublattice_after_expand(expanded, host)
    n_sub = len(sub_idx)
    total_nat = int(expanded.get("nat") or len(expanded.get("positions") or []))

    compositions = []
    for f in fr:
        n_dop = round(n_sub * f)
        n_host = n_sub - n_dop
        pct = int(round(f * 100))
        pid = _phase_id_doped(host, dop, pct)
        site_set = _assign_dopant_sites(n_sub, n_dop, seed=pct * 17 + n_sub)
        global_dop = {sub_idx[i] for i in site_set}
        trial = dict(expanded)
        trial_positions = list(trial.get("positions") or [])
        for gi in global_dop:
            trial_positions[gi] = {**trial_positions[gi], "symbol": dop}
        trial["positions"] = trial_positions
        fc = _formula_counts(trial)
        gen = _general_formula(host, dop)
        fprefix = _general_formula_prefix(host, dop)
        compositions.append(
            {
                "phase_id": pid,
                "fraction_dopant": f,
                "fraction_dopant_pct": pct,
                "n_host_sublattice": n_host,
                "n_dopant_sublattice": n_dop,
                "n_sublattice": n_sub,
                "formula": _formula_display(fc),
                "formula_general": gen,
                "formula_title": _formula_title_line(host, dop, fc),
                "file_prefix": fprefix,
                "model": f"{gen}  (x = {pct} % · sous-maille {host})",
            }
        )

    pa = (parent_material_a or src_mat).strip()
    pb = (parent_material_b or "").strip()
    endpoints: list[dict] = [
        {
            "fraction_dopant_pct": 0,
            "fraction_dopant": 0.0,
            "material": pa,
            "role": "parent_x0",
            "phase_id": "",
            "kind": "parent",
            "label_fr": f"x = 0 % — matériau I ({pa}), 100 % {host}",
            "label_en": f"x = 0 % — parent I ({pa}), 100 % {host}",
        }
    ]
    if pb:
        endpoints.append(
            {
                "fraction_dopant_pct": 100,
                "fraction_dopant": 1.0,
                "material": pb,
                "role": "parent_x100",
                "phase_id": "",
                "kind": "parent",
                "label_fr": f"x = 100 % — matériau II ({pb}), 100 % {dop} sur {host}",
                "label_en": f"x = 100 % — parent II ({pb}), 100 % {dop} on {host}",
            }
        )

    gen = _general_formula(host, dop)
    return {
        "ok": True,
        "material": mat,
        "parent_material_a": pa,
        "parent_material_b": pb or None,
        "phase_source": normalize_phase_id(phase_id) or "(racine)",
        "structure_source_material": src_mat,
        "host_element": host,
        "dopant": dop,
        "species_host": host,
        "species_dopant": dop,
        "formula_general": gen,
        "n_atoms_supercell": total_nat,
        "n_sublattice_sites": n_sub,
        "supercell": {"nx": nx, "ny": ny, "nz": nz, "repeat": repeat},
        "endpoints": endpoints,
        "intermediates": compositions,
        "compositions": compositions,
        "message_fr": (
            f"Série {gen or (host + '→' + dop)} · {pa}"
            + (f" → {pb}" if pb else "")
            + f" : {len(endpoints)} extrémité(s), {len(compositions)} intermédiaire(s) "
            f"(supercellule {nx}×{ny}×{nz})."
        ),
        "message_en": (
            f"Series {gen or (host + '→' + dop)} · {pa}"
            + (f" → {pb}" if pb else "")
            + f": {len(endpoints)} endpoint(s), {len(compositions)} intermediate(s) "
            f"(supercell {nx}×{ny}×{nz})."
        ),
    }


def generate_doping(
    mat: str,
    *,
    phase_id: str = "",
    host_element: str,
    dopant: str,
    fractions: list[float],
    parent_material_a: str = "",
    parent_material_b: str = "",
    inputs_root: Path | None = None,
) -> dict:
    job_mat = mat.strip()
    pa = (parent_material_a or "").strip()
    pb = (parent_material_b or "").strip()
    layout_err = _validate_doping_job_material(job_mat, pa, pb)
    if layout_err:
        return {"ok": False, "error": layout_err}
    if not pa:
        return {
            "ok": False,
            "error": (
                "Matériau parent I (x = 0 %) requis — ex. GdCrO3 avec VC-RELAX/RELAX/SCF "
                "sous inputs/materiaux/GdCrO3/ (§1 Matériau I, puis Confirmer A et B)."
            ),
        }
    if inputs_root is not None:
        os.environ["OPTQ_INPUTS"] = str(inputs_root)
    else:
        os.environ.setdefault("OPTQ_INPUTS", str(ROOT / "inputs"))
    inputs_used = os.environ.get("OPTQ_INPUTS", str(ROOT / "inputs"))
    cleanup = _cleanup_empty_dop_dirs(job_mat)
    # Avant écriture NM : ne pas préparer le magnétisme (numpy/postproc optionnels).
    repair_doped_job_layout(job_mat, parent_material_a=pa, prep_mag=False)

    prev = preview_doping(
        job_mat,
        phase_id=phase_id,
        host_element=host_element,
        dopant=dopant,
        fractions=fractions,
        parent_material_a=parent_material_a,
        parent_material_b=parent_material_b,
    )
    if not prev.get("ok"):
        return prev

    src_mat = pa or job_mat
    src = _resolve_structure_input(src_mat, phase_id)
    assert src is not None
    template = src.read_text(encoding="utf-8")
    base_parsed = _parse_input_text(template)
    host = prev["host_element"]
    dop = prev["dopant"]
    sc = prev["supercell"]
    nx, ny, nz = sc["nx"], sc["ny"], sc["nz"]
    expanded = _expand_supercell(base_parsed, nx, ny, nz) if sc["repeat"] > 1 else dict(base_parsed)
    sub_idx = _sublattice_after_expand(expanded, host)

    created: list[dict] = []
    errors: list[str] = []
    src_pid = normalize_phase_id(phase_id)

    work_parsed = expanded
    sub_l = sub_idx

    for comp in prev.get("compositions") or []:
        pid = comp["phase_id"]
        f = comp["fraction_dopant"]
        n_dop = comp["n_dopant_sublattice"]
        pct = comp["fraction_dopant_pct"]
        site_local = _assign_dopant_sites(len(sub_idx), n_dop, seed=pct * 17 + len(sub_idx))
        global_dop = {sub_idx[i] for i in site_local}
        trial = _trial_structure_for_comp(expanded, sub_idx, host=host, dop=dop, global_dop=global_dop)
        fc = _formula_counts(trial)
        file_prefix = (
            comp.get("file_prefix")
            or _general_formula_prefix(host, dop)
            or _formula_file_prefix(fc)
        )
        formula = comp.get("formula") or _formula_display(fc)
        formula_title = comp.get("formula_title") or _formula_title_line(host, dop, fc)
        formula_general = comp.get("formula_general") or _general_formula(host, dop)

        dst_root, err = _ensure_doping_phase_dir(job_mat, pid, copy_from=src_pid)
        if err or dst_root is None:
            errors.append(f"{pid}: {err or 'dossier introuvable'}")
            continue
        _purge_alien_doping_inputs(dst_root, file_prefix, job_mat=job_mat)
        kinds_written: list[str] = []
        for kind in _NM_KINDS:
            src_in = _workflow_source_in(src_mat, kind, src_pid)
            if not src_in or not src_in.is_file():
                continue
            src_kind = kind
            if kind == "vc-relax" and src_in.name.endswith("-relax.in"):
                src_kind = "relax"
            try:
                text = src_in.read_text(encoding="utf-8")
                new_text = _apply_substitution(
                    text,
                    work_parsed,
                    host_element=host,
                    dopant=dop,
                    dopant_site_indices=global_dop,
                    sublattice_indices=sub_l,
                    file_prefix=file_prefix,
                )
                if kind == "vc-relax" and src_kind != "vc-relax":
                    new_text = _ensure_vc_relax_namelist(new_text)
                new_text = _finalize_doped_input_text(
                    new_text,
                    job_mat=job_mat,
                    phase_id=pid,
                    file_prefix=file_prefix,
                    kind=kind,
                    formula_title=formula_title,
                    formula_general=formula_general,
                )
            except (OSError, ValueError) as exc:
                errors.append(f"{pid}/{kind}: {exc}")
                continue
            out_name = _doping_input_basename(file_prefix, kind)
            out_path = dst_root / out_name
            out_path.write_text(new_text, encoding="utf-8")
            kinds_written.append(kind)
        _sync_doped_folder_layout(dst_root, job_mat, file_prefix)
        _guarantee_phase_vc_relax(dst_root, job_mat, file_prefix)
        _sync_doped_folder_layout(dst_root, job_mat, file_prefix)
        _finalize_doped_phase_inputs(
            dst_root,
            job_mat,
            pid,
            file_prefix,
            formula_title=formula_title,
            formula_general=formula_general,
        )
        _ensure_doped_output_dir(job_mat, pid)
        if not _doping_dir_complete(dst_root, job_mat):
            missing = [k for k in _NM_KINDS if k not in kinds_written]
            errors.append(
                f"{pid}: aucun input NM écrit dans {dst_root.name}/ "
                f"(source {src_mat} — manquant: {', '.join(missing) or 'vc-relax, relax, scf'}). "
                "Générez VC-RELAX sur le parent (§2 CIF) puis relancez."
            )
            continue
        mag = prepare_magnetic_inputs_for_doped_phase(job_mat, pid)
        mag_sum = mag.get("summary") or {}
        if not mag.get("ok"):
            errors.append(f"{pid}/mag: {mag.get('error') or 'FM / AFM / NCL non générés'}")
        rel_dir = f"inputs/materiaux/{job_mat}/{pid}/"
        vc_name = _doping_input_basename(file_prefix, "vc-relax")
        created.append(
            {
                "phase_id": pid,
                "fraction_dopant_pct": pct,
                "fraction_dopant": f,
                "formula": formula,
                "formula_general": formula_general,
                "formula_title": formula_title,
                "file_prefix": file_prefix,
                "inputs_path": rel_dir,
                "vc_relax_path": rel_dir + vc_name,
                "kinds_written": kinds_written,
                "mag_ok": bool(mag.get("ok")),
                "mag_orders": mag_sum.get("orders") or [],
                "mag_path": mag_sum.get("mag_path") or rel_dir + "mag/",
            }
        )

    layout = repair_doped_job_layout(job_mat, parent_material_a=pa)
    if cleanup:
        layout.setdefault("actions", []).extend(cleanup)
    out = {
        "ok": bool(created) and not errors,
        "material": job_mat,
        "parent_material_a": pa or None,
        "inputs_root_used": inputs_used,
        "created": created,
        "errors": errors,
        "preview": prev,
        "layout_repair": layout,
        "message_fr": (
            f"{len(created)} phase(s) dopée(s) sous inputs/materiaux/{job_mat}/dop_*/ "
            f"(NM + mag/fm,afm*,ncl — nspin 2/4 — source : {src_mat})."
        ),
        "message_en": (
            f"{len(created)} doped phase(s) under inputs/materiaux/{job_mat}/dop_*/ "
            f"(NM + mag/fm,afm*,ncl — nspin 2/4 — from {src_mat})."
        ),
    }
    if errors and created:
        out["ok"] = True
        out["message_fr"] += " Avertissements : " + "; ".join(errors)
    elif errors:
        out["ok"] = False
        out["error"] = "; ".join(errors)
    elif not created:
        out["ok"] = False
        out["error"] = (
            f"Aucune phase dopée créée sous inputs/materiaux/{job_mat}/. "
            f"Vérifiez fractions, hôte, dopant et la chaîne NM du parent {src_mat}."
        )
    return out

"""Inventaire inputs / outputs aligné sur le profil UI (non dopé / dopé)."""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

_NM_KINDS = ("vc-relax", "relax", "scf", "nscf")
_DOP_DIR_RE = re.compile(r"^dop_[A-Za-z0-9]+_[A-Za-z0-9]+_\d+$", re.I)
_DOP_PREFIX_RE = re.compile(r"^dop_", re.I)
_DOPED_JOB_RE = re.compile(r"_doped$", re.I)


def _looks_like_doped_job(mat: str) -> bool:
    return bool(_DOPED_JOB_RE.search((mat or "").strip()))


def _repo_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _inputs_root() -> Path:
    return Path(os.environ.get("OPTQ_INPUTS", _repo_root() / "inputs")).expanduser()


def _outputs_root() -> Path:
    return _repo_root() / "outputs"


def _rel(path: Path, base: Path) -> str:
    try:
        return str(path.relative_to(base)).replace("\\", "/")
    except ValueError:
        return path.name


def _list_in_files(folder: Path, inputs_root: Path, *, label: str = "") -> list[dict]:
    if not folder.is_dir():
        return []
    rows: list[dict] = []
    for p in sorted(folder.glob("*.in")):
        if not p.is_file() or "rescue" in p.name.lower() or ".orig" in p.name.lower():
            continue
        kind = "input"
        for k in _NM_KINDS:
            if p.name.endswith(f"-{k}.in"):
                kind = k
                break
        rows.append(
            {
                "name": p.name,
                "kind": kind,
                "path": f"inputs/{_rel(p, inputs_root)}",
                "label": label,
            }
        )
    return rows


def _output_branch(folder: Path, outputs_root: Path) -> dict | None:
    if not folder.is_dir():
        return None
    rel = f"outputs/{_rel(folder, outputs_root)}"
    outs = sorted(
        [f.name for f in folder.iterdir() if f.is_file() and f.suffix in (".out", ".json", ".jsonl", ".xml")],
        key=str.lower,
    )
    subdirs = sorted([d.name for d in folder.iterdir() if d.is_dir()], key=str.lower)
    return {"dir": rel, "files": outs[:40], "subdirs": subdirs[:20], "exists": True}


def build_material_io_profile(mat: str) -> dict:
    mat = (mat or "").strip()
    if not mat:
        return {"ok": False, "error": "Matériau requis."}

    inputs_root = _inputs_root()
    outputs_root = _outputs_root()
    mat_in = inputs_root / "materiaux" / mat
    mat_out = outputs_root / "materiaux" / mat

    nm_prep = _list_in_files(mat_in, inputs_root, label="NM")
    cif_path = mat_in / f"{mat}.cif"
    cif = f"inputs/{_rel(cif_path, inputs_root)}" if cif_path.is_file() else None

    mag_prep: list[dict] = []
    mag_root = mat_in / "mag"
    if mag_root.is_dir():
        for order_dir in sorted(mag_root.iterdir(), key=lambda p: p.name.lower()):
            if not order_dir.is_dir():
                continue
            mag_prep.append(
                {
                    "order": order_dir.name,
                    "inputs": _list_in_files(order_dir, inputs_root, label=order_dir.name),
                }
            )

    sqs_prep: list[dict] = []
    if mat_in.is_dir():
        for d in sorted(mat_in.iterdir(), key=lambda p: p.name.lower()):
            if not d.is_dir() or d.name == "mag" or _DOP_PREFIX_RE.match(d.name):
                continue
            files = _list_in_files(d, inputs_root, label=d.name)
            if files:
                sqs_prep.append({"phase_id": d.name, "inputs": files})

    def _doped_phase_prep_rows(job_name: str, job_dir: Path) -> list[dict]:
        rows: list[dict] = []
        if not job_dir.is_dir():
            return rows
        for d in sorted(job_dir.iterdir(), key=lambda p: p.name.lower()):
            if not d.is_dir() or not _DOP_PREFIX_RE.match(d.name):
                continue
            mag_phase: list[dict] = []
            mag_root = d / "mag"
            if mag_root.is_dir():
                for order_dir in sorted(mag_root.iterdir(), key=lambda p: p.name.lower()):
                    if not order_dir.is_dir():
                        continue
                    mag_phase.append(
                        {
                            "order": order_dir.name,
                            "inputs": _list_in_files(
                                order_dir, inputs_root, label=f"{d.name}/{order_dir.name}"
                            ),
                        }
                    )
            rows.append(
                {
                    "phase_id": d.name,
                    "inputs_path": f"inputs/materiaux/{job_name}/{d.name}/",
                    "mag_path": f"inputs/materiaux/{job_name}/{d.name}/mag/",
                    "inputs": _list_in_files(d, inputs_root, label=d.name),
                    "magnetic_orders": mag_phase,
                    "has_magnetic_inputs": bool(mag_phase),
                }
            )
        return rows

    doped_prep: list[dict] = []
    stray_dop_on_parent: list[str] = []
    doped_job_material = mat if _looks_like_doped_job(mat) else ""
    if mat_in.is_dir():
        for d in sorted(mat_in.iterdir(), key=lambda p: p.name.lower()):
            if not d.is_dir() or not _DOP_PREFIX_RE.match(d.name):
                continue
            if _looks_like_doped_job(mat):
                continue
            stray_dop_on_parent.append(d.name)
    if _looks_like_doped_job(mat):
        doped_prep = _doped_phase_prep_rows(mat, mat_in)
    else:
        sibling = f"{mat}_doped"
        sib_in = inputs_root / "materiaux" / sibling
        if sib_in.is_dir():
            doped_job_material = sibling
            doped_prep = _doped_phase_prep_rows(sibling, sib_in)

    nm_calc = _output_branch(mat_out / "optimisation", outputs_root)
    mag_calc: dict[str, dict] = {}
    mag_out = mat_out / "magnetisme"
    if mag_out.is_dir():
        for od in sorted(mag_out.iterdir(), key=lambda p: p.name.lower()):
            if not od.is_dir():
                continue
            br = _output_branch(od, outputs_root)
            if br:
                mag_calc[od.name] = br

    doped_calc: list[dict] = []
    calc_job = doped_job_material or mat
    calc_out = outputs_root / "materiaux" / calc_job
    if calc_out.is_dir():
        for d in sorted(calc_out.iterdir(), key=lambda p: p.name.lower()):
            if not d.is_dir() or not _DOP_PREFIX_RE.match(d.name):
                continue
            br = _output_branch(d, outputs_root)
            doped_calc.append(
                {
                    "phase_id": d.name,
                    "outputs": br
                    or {"dir": f"outputs/materiaux/{calc_job}/{d.name}/", "exists": False},
                }
            )

    jobs: list[dict] = []
    job_root = outputs_root / mat
    if job_root.is_dir():
        for jd in sorted(job_root.iterdir(), key=lambda p: p.name.lower()):
            if not jd.is_dir():
                continue
            qe = jd / "qe"
            jobs.append(
                {
                    "job_id": jd.name,
                    "dir": f"outputs/{_rel(jd, outputs_root)}/",
                    "qe_outputs": sorted([f.name for f in qe.glob("*") if f.is_file()])[:30] if qe.is_dir() else [],
                }
            )

    return {
        "ok": True,
        "material": mat,
        "doped_job_material": doped_job_material or None,
        "inputs_dir": f"inputs/materiaux/{mat}/",
        "outputs_dir": f"outputs/materiaux/{mat}/",
        "profile": {
            "nondoped": {
                "preparation": {
                    "cif": cif,
                    "nm_chain": nm_prep,
                    "magnetic_orders": mag_prep,
                    "sqs_phases": sqs_prep,
                },
                "calculation": {
                    "nm": nm_calc,
                    "magnetism": mag_calc,
                },
            },
            "doped": {
                "preparation": {"phases": doped_prep},
                "calculation": {"phases": doped_calc},
            },
        },
        "jobs": jobs,
        "stray_dop_on_parent": stray_dop_on_parent,
        "guide_fr": (
            "Non dopé : inputs/materiaux/<parent>/ (VC-RELAX, mag/, SQS) — sans dop_*. "
            "Dopé : inputs/materiaux/<job_dopé>/dop_*/ uniquement ; outputs/materiaux/<job_dopé>/dop_*/optimisation/."
            + (
                f" ⚠ dop_* à déplacer depuis {mat}/ : {', '.join(stray_dop_on_parent[:6])}."
                if stray_dop_on_parent
                else ""
            )
        ),
        "guide_en": (
            "Undoped: inputs/materiaux/<parent>/ (VC-RELAX, mag/, SQS) — no dop_*. "
            "Doped: inputs/materiaux/<doped_job>/dop_*/ only; matching outputs under dop_*/optimisation/."
            + (
                f" ⚠ Move dop_* from {mat}/: {', '.join(stray_dop_on_parent[:6])}."
                if stray_dop_on_parent
                else ""
            )
        ),
    }

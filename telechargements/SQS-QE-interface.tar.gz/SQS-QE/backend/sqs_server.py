#!/usr/bin/env python3
"""Serveur UI Phases / SQS — port dédié, proxy API vers optimisation-QE."""
from __future__ import annotations

import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from flask import Flask, Response, request, send_from_directory

# === CONFIGURATION PATHS (AVANT imports upstream) ===
ROOT = Path(__file__).resolve().parent.parent
INTERFACE = ROOT / "interface"
LOGS = ROOT / "logs"
OPTQ_ROOT = Path(os.environ.get("OPTQ_ROOT", Path.home() / "optimisation-QE")).expanduser()

# ⚠️ CRITIQUE : Définir OPTQ_INPUTS AVANT d'importer les modules upstream
#    pour que config.py utilise le bon chemin d'inputs
os.environ["OPTQ_INPUTS"] = str(ROOT / "inputs")
API_UPSTREAM = (os.environ.get("OPTQ_API_UPSTREAM") or "http://127.0.0.1:5030").rstrip("/")
COOKIE_NAME = "optq_token"

# === Imports des modules upstream (après configuration) ===
from mag_physical_audit import audit_mag_physics
from regenerate_mag_inputs import (
    iter_catalog_materials,
    regenerate_catalog,
    regenerate_material,
)
from regenerate_mag_inputs import _nm_scf_path as _nm_scf_path_for_mat
from io_profile import build_material_io_profile
from substitution_doping import (
    _detect_formula_prefix,
    _guarantee_phase_vc_relax,
    _sync_doped_folder_layout,
    generate_doping,
    list_host_elements,
    prepare_magnetic_inputs_for_doped_job,
    prepare_magnetic_inputs_for_doped_phase,
    preview_doping,
    repair_doped_job_layout,
    resolve_material_input_file,
)
HEADER_NAME = "X-OptQ-Token"

HOP_BY_HOP = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailers",
    "transfer-encoding",
    "upgrade",
    "content-encoding",
    "content-length",
}

app = Flask(__name__, static_folder=str(INTERFACE), static_url_path="")


def get_api_token() -> str:
    env = (os.environ.get("OPTQ_API_TOKEN") or "").strip()
    if env:
        return env
    token_file = OPTQ_ROOT / ".api_token"
    if token_file.is_file():
        return token_file.read_text(encoding="utf-8").strip()
    raise RuntimeError(
        f"Token API introuvable — démarrez optimisation-QE ({OPTQ_ROOT}) ou exportez OPTQ_API_TOKEN."
    )


def _host_is_secure() -> bool:
    if request.is_secure:
        return True
    fwd = (request.headers.get("X-Forwarded-Proto") or "").strip().lower()
    return fwd == "https"


def _proxy_path(path: str, body_override: bytes | None = None) -> Response:
    qs = request.query_string.decode("utf-8", errors="replace")
    url = f"{API_UPSTREAM}{path}"
    if qs:
        url = f"{url}?{qs}"

    headers = {}
    for name in (
        "Content-Type",
        "Accept",
        "Cookie",
        HEADER_NAME,
        "Origin",
        "Referer",
    ):
        val = request.headers.get(name)
        if val:
            headers[name] = val
    if not headers.get(HEADER_NAME) and not request.cookies.get(COOKIE_NAME):
        try:
            headers[HEADER_NAME] = get_api_token()
        except RuntimeError:
            pass

    if body_override is not None:
        body = body_override
    else:
        body = request.get_data() if request.method not in ("GET", "HEAD") else None
    req = urllib.request.Request(url, data=body, method=request.method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=600) as upstream:
            data = upstream.read()
            status = upstream.status
            out_headers = []
            for key, val in upstream.headers.items():
                lk = key.lower()
                if lk in HOP_BY_HOP:
                    continue
                out_headers.append((key, val))
    except urllib.error.HTTPError as exc:
        data = exc.read()
        status = exc.code
        out_headers = [(k, v) for k, v in exc.headers.items() if k.lower() not in HOP_BY_HOP]
    except urllib.error.URLError as exc:
        return Response(
            json.dumps({"ok": False, "error": f"API optimisation-QE injoignable ({API_UPSTREAM}): {exc.reason}"}),
            status=502,
            mimetype="application/json",
        )

    resp = Response(data, status=status)
    for key, val in out_headers:
        if key.lower() == "set-cookie":
            continue
        resp.headers[key] = val
    return resp


@app.after_request
def _set_auth_cookie(resp: Response):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    if request.path.endswith((".js", ".css", ".html")) or request.path in ("/", "/index.html"):
        resp.headers["Cache-Control"] = "no-cache, must-revalidate"
    else:
        resp.headers.setdefault("Cache-Control", "no-store")
    if request.path.startswith("/api/"):
        return resp
    try:
        if not request.cookies.get(COOKIE_NAME):
            resp.set_cookie(
                COOKIE_NAME,
                get_api_token(),
                httponly=True,
                samesite="Strict",
                secure=_host_is_secure(),
                path="/",
                max_age=86400 * 30,
            )
    except RuntimeError:
        pass
    return resp


@app.get("/env.js")
def env_js():
    host = os.environ.get("SQS_QE_HOST", "127.0.0.1")
    port = os.environ.get("SQS_QE_PORT", "5031")
    main_host = os.environ.get("OPTQ_MAIN_HOST", "127.0.0.1")
    main_port = os.environ.get("OPTQ_MAIN_PORT", "5030")
    sqs_base = f"http://{host}:{port}/"
    main_base = f"http://{main_host}:{main_port}/"
    qe_bin = (os.environ.get("QE_BIN_DIR") or str(ROOT / "bin")).replace("\\", "\\\\").replace('"', '\\"')
    pseudo = (os.environ.get("PSEUDO_DIR") or str(ROOT / "pseudos")).replace("\\", "\\\\").replace('"', '\\"')
    sqs_root = str(ROOT).replace("\\", "\\\\").replace('"', '\\"')
    body = (
        f'window.SQS_QE_ROOT="{sqs_root}";\n'
        f'window.OPTQE_SQS_APP="{sqs_base}index.html";\n'
        f'window.OPTQE_MAIN_APP="{main_base}index.html";\n'
        f'window.OPTQE_MAIN_GUIDE="{main_base}guide.html#phases";\n'
        f'window.OPTQE_QE_BIN_DIR="{qe_bin}";\n'
        f'window.OPTQE_PSEUDO_DIR="{pseudo}";\n'
        f'window.OPTQE_QE_VERSION="7.5+";\n'
    )
    return Response(body, mimetype="application/javascript; charset=utf-8")


def _safe_mat_name(name: str) -> str:
    return re.sub(r"[^\w\-]", "", (name or "").strip())


def _local_cif_dir() -> Path:
    return Path(os.environ.get("OPTQ_CIF_DIR", ROOT / "cif")).expanduser()


def _local_cif_dirs() -> list[Path]:
    """Dossiers CIF : OPTQ_CIF_DIRS puis OPTQ_CIF_DIR, défaut <racine SQS-QE>/cif."""
    raw = (os.environ.get("OPTQ_CIF_DIRS") or "").strip()
    out: list[Path] = []
    seen: set[str] = set()
    if raw:
        sep = os.pathsep if os.pathsep in raw else ":"
        for part in raw.split(sep):
            if not part.strip():
                continue
            p = Path(part.strip()).expanduser()
            try:
                rp = str(p.resolve())
            except OSError:
                continue
            if p.is_dir() and rp not in seen:
                seen.add(rp)
                out.append(p)
    primary = _local_cif_dir()
    if primary.is_dir():
        try:
            rp = str(primary.resolve())
            if rp not in seen:
                seen.add(rp)
                out.append(primary)
        except OSError:
            pass
    cand = ROOT / "cif"
    try:
        rp = str(cand.resolve())
        if cand.is_dir() and rp not in seen:
            seen.add(rp)
            out.append(cand)
    except OSError:
        pass
    return out


def _is_global_cif_library(root: Path) -> bool:
    try:
        rr = root.resolve()
    except OSError:
        return False
    for d in _local_cif_dirs():
        try:
            if d.resolve() == rr:
                return True
        except OSError:
            continue
    return False


def _local_inputs_dir() -> Path:
    return Path(os.environ.get("OPTQ_INPUTS", ROOT / "inputs")).expanduser()


def list_local_cifs_for_mat(mat: str) -> list[dict]:
    """CIF uniquement dans OPTQ_CIF_DIRS (par défaut <SQS-QE>/cif)."""
    mat = _safe_mat_name(mat)
    if not mat:
        return []
    seen: set[str] = set()
    out: list[dict] = []
    mat_l = mat.lower()
    for root in _local_cif_dirs():
        if not root.is_dir():
            continue
        for p in sorted(root.glob("*.cif")) + sorted(root.glob("*.CIF")):
            if p.stem.lower() != mat_l:
                continue
            key = str(p.resolve())
            if key in seen:
                continue
            seen.add(key)
            try:
                size = p.stat().st_size
            except OSError:
                size = 0
            out.append({"name": p.name, "path": str(p), "size": size, "cif_root": str(root)})
    return out


def list_all_local_cifs() -> list[dict]:
    """Tous les .cif des bibliothèques (pour découverte matériaux)."""
    seen: set[str] = set()
    out: list[dict] = []
    for root in _local_cif_dirs():
        if not root.is_dir():
            continue
        for p in sorted(root.glob("*.cif")) + sorted(root.glob("*.CIF")):
            key = str(p.resolve())
            if key in seen:
                continue
            seen.add(key)
            try:
                size = p.stat().st_size
            except OSError:
                size = 0
            out.append({"name": p.name, "material": _safe_mat_name(p.stem), "path": str(p), "size": size})
    return out


_NM_KINDS = ("vc-relax", "relax", "scf")
_MAG_KINDS = ("vc-relax", "relax", "scf", "nscf")


def _read_nspin_from_in(path: Path) -> int | None:
    try:
        head = path.read_text(encoding="utf-8", errors="replace")[:8000]
    except OSError:
        return None
    return _qe_parse_int_param(_qe_system_block(head), "nspin")


def _qe_system_block(text: str) -> str:
    m = re.search(r"&SYSTEM\s*(.*?)&", text, re.IGNORECASE | re.DOTALL)
    return m.group(1) if m else text[:8000]


def _qe_parse_bool(raw: str) -> bool | None:
    v = raw.strip().lower().replace(".", "")
    if v in ("true", "t"):
        return True
    if v in ("false", "f"):
        return False
    return None


def _qe_parse_int_param(block: str, name: str) -> int | None:
    m = re.search(rf"{re.escape(name)}\s*=\s*(\d+)", block, re.IGNORECASE)
    if not m:
        return None
    try:
        return int(m.group(1))
    except ValueError:
        return None


def _qe_parse_bool_param(block: str, name: str) -> bool | None:
    m = re.search(
        rf"{re.escape(name)}\s*=\s*(\.?true\.?|\.?false\.?|true|false)",
        block,
        re.IGNORECASE,
    )
    if not m:
        return None
    return _qe_parse_bool(m.group(1))


def _expected_mag_qe(order: str) -> dict:
    o = (order or "nm").strip().lower()
    if o == "ncl":
        return {"nspin": 4, "noncolin": True}
    if o == "nm":
        return {"nspin": 1, "noncolin": False}
    return {"nspin": 2, "noncolin": False}


def _parse_atomic_species(content: str) -> list[str]:
    m = re.search(
        r"ATOMIC_SPECIES\s*(.*?)(?=ATOMIC_POSITIONS|CELL_PARAMETERS|K_POINTS|\Z)",
        content,
        re.IGNORECASE | re.DOTALL,
    )
    if not m:
        return []
    out: list[str] = []
    for line in m.group(1).splitlines():
        line = line.split("!")[0].strip()
        if not line:
            continue
        parts = line.split()
        if parts:
            out.append(parts[0])
    return out


def _count_atomic_positions(content: str) -> dict[str, int]:
    m = re.search(
        r"ATOMIC_POSITIONS\s+\S+\s*(.*?)(?=CELL_PARAMETERS|K_POINTS|\Z)",
        content,
        re.IGNORECASE | re.DOTALL,
    )
    if not m:
        return {}
    counts: dict[str, int] = {}
    for line in m.group(1).splitlines():
        line = line.split("!")[0].strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) >= 4:
            sym = parts[0]
            counts[sym] = counts.get(sym, 0) + 1
    return counts


def _parse_starting_mags(block: str) -> dict[int, float]:
    out: dict[int, float] = {}
    for m in re.finditer(
        r"starting_magnetization\s*\(\s*(\d+)\s*\)\s*=\s*([-+]?\d*\.?\d+(?:[dD][+-]?\d+)?)",
        block,
        re.IGNORECASE,
    ):
        idx = int(m.group(1))
        raw = m.group(2).replace("d", "E").replace("D", "E")
        try:
            out[idx] = float(raw)
        except ValueError:
            continue
    return out


def _audit_afm_sublattice(content: str, order: str) -> list[str]:
    """AFM : sous-mailles 1/2 utilisées, moments opposés (ex. GdCrO3 AFM-G)."""
    o = (order or "").strip().lower()
    if not o.startswith("afm-"):
        return []
    issues: list[str] = []
    species = _parse_atomic_species(content)
    pos_counts = _count_atomic_positions(content)
    block = _qe_system_block(content)
    if _qe_parse_bool_param(block, "nosym") is not True:
        issues.append("nosym = .true. requis pour AFM (symétrie spin)")
    mags = _parse_starting_mags(block)
    bases: dict[str, set[str]] = {}
    for sym in species:
        m = re.match(r"^([A-Za-z]+)([12])$", sym)
        if m:
            bases.setdefault(m.group(1), set()).add(m.group(2))
    for sym in species:
        if sym.upper() in ("O", "O1", "O2") or re.fullmatch(r"O\d*", sym, re.I):
            continue
        if pos_counts.get(sym, 0) == 0:
            issues.append(
                f"espèce {sym} déclarée dans ATOMIC_SPECIES mais absente de ATOMIC_POSITIONS"
            )
    species_set = set(species)
    for base, suffixes in bases.items():
        if "1" not in suffixes or "2" not in suffixes:
            continue
        s1, s2 = f"{base}1", f"{base}2"
        if s1 not in species_set or s2 not in species_set:
            continue
        n1, n2 = pos_counts.get(s1, 0), pos_counts.get(s2, 0)
        if n1 == 0 or n2 == 0:
            issues.append(
                f"AFM {base} : {s1} et {s2} doivent porter des atomes (actuel {s1}={n1}, {s2}={n2})"
            )
        i1 = species.index(s1) + 1 if s1 in species else None
        i2 = species.index(s2) + 1 if s2 in species else None
        if i1 and i2 and i1 in mags and i2 in mags:
            if mags[i1] * mags[i2] >= 0 and abs(mags[i1]) > 1e-9 and abs(mags[i2]) > 1e-9:
                issues.append(
                    f"AFM {base} : starting_magnetization({i1}) et ({i2}) doivent être de signes opposés"
                )
    return issues


def _header_matches_mag_order(head: str, order: str) -> bool:
    o = (order or "").strip().lower()
    up = head[:1200].upper()
    if o == "fm":
        return "FM" in up or "FERROMAGN" in up or "FERROMAGNÉTIQUE" in head[:1200].upper()
    if o == "ncl":
        return "NCL" in up or "NON COLIN" in up or "NONCOLIN" in up or "NSPIN = 4" in up
    if o.startswith("afm-"):
        sub = o.split("-", 1)[1].upper()
        return f"AFM-{sub}" in up or f"AFM {sub}" in up or "ANTIFERRO" in up
    return True


def _nm_reference_input_text(mat: str) -> str:
    mat = _safe_mat_name(mat)
    if not mat:
        return ""
    path = _nm_scf_path_for_mat(mat, _local_inputs_dir())
    if path and path.is_file():
        try:
            return path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            pass
    for kind in _NM_KINDS:
        p = _local_inputs_dir() / "materiaux" / mat / f"{mat}-{kind}.in"
        if p.is_file():
            try:
                return p.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
    return ""


def _audit_mag_input_text(content: str, order: str, *, nm_content: str | None = None) -> dict:
    """Vérifie qu'un .in correspond à l'ordre magnétique (tous types de matériaux)."""
    order = (order or "nm").strip().lower()
    exp = _expected_mag_qe(order)
    block = _qe_system_block(content or "")
    head = (content or "")[:1500]
    issues: list[str] = []
    nspin = _qe_parse_int_param(block, "nspin")
    noncolin = _qe_parse_bool_param(block, "noncolin")
    if nspin is None:
        issues.append(f"nspin manquant (attendu {exp['nspin']})")
    elif nspin != exp["nspin"]:
        issues.append(f"nspin = {nspin} (attendu {exp['nspin']})")
    if exp["noncolin"]:
        if noncolin is not True:
            issues.append("noncolin = .true. requis (ordre NCL)")
    else:
        if noncolin is True:
            issues.append("noncolin = .true. interdit pour cet ordre (colinéaire attendu)")
    if "OPTQE-MAG" in head and not _header_matches_mag_order(head, order):
        issues.append(f"en-tête OPTQE-MAG incohérent avec l'ordre « {order} »")
    issues.extend(_audit_afm_sublattice(content or "", order))
    issues.extend(audit_mag_physics(content or "", order, nm_content))
    return {
        "ok": not issues,
        "order": order,
        "issues": issues,
        "nspin_found": nspin,
        "noncolin_found": noncolin,
        "expected_nspin": exp["nspin"],
        "expected_noncolin": exp["noncolin"],
    }


def _mag_order_inputs_dir(mat: str, order: str) -> Path:
    mat = _safe_mat_name(mat)
    order = (order or "").strip().lower()
    return _local_inputs_dir() / "materiaux" / mat / "mag" / order


def _audit_mag_order_chain_local(mat: str, order: str) -> dict:
    mat = _safe_mat_name(mat)
    order = (order or "").strip().lower()
    if not mat or order in ("", "nm"):
        return {"ok": False, "error": "invalid_order", "order": order, "steps": []}
    base = _mag_order_inputs_dir(mat, order)
    nm_text = _nm_reference_input_text(mat)
    steps: list[dict] = []
    all_ok = True
    for kind in _MAG_KINDS:
        path = base / f"{mat}-{kind}.in"
        row: dict = {"kind": kind, "path": str(path), "exists": path.is_file()}
        if not path.is_file():
            row["ok"] = False
            row["issues"] = ["fichier absent"]
            all_ok = False
            steps.append(row)
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            row["ok"] = False
            row["issues"] = [str(exc)]
            all_ok = False
            steps.append(row)
            continue
        aud = _audit_mag_input_text(text, order, nm_content=nm_text or None)
        row["ok"] = aud["ok"]
        row["issues"] = aud.get("issues") or []
        row["nspin"] = aud.get("nspin_found")
        row["noncolin"] = aud.get("noncolin_found")
        if not aud["ok"]:
            all_ok = False
        steps.append(row)
    return {
        "ok": all_ok,
        "material": mat,
        "order": order,
        "steps": steps,
        "kinds_checked": list(_MAG_KINDS),
    }


def _audit_all_mag_orders_local(mat: str, orders: list[str] | None = None) -> dict:
    mat = _safe_mat_name(mat)
    if not mat:
        return {"ok": False, "orders": []}
    if not orders:
        mag_root = _local_inputs_dir() / "materiaux" / mat / "mag"
        if mag_root.is_dir():
            orders = sorted(p.name for p in mag_root.iterdir() if p.is_dir())
        else:
            orders = []
    reports = []
    all_ok = True
    for ord_name in orders:
        o = str(ord_name).strip().lower()
        if not o or o == "nm":
            continue
        rep = _audit_mag_order_chain_local(mat, o)
        reports.append(rep)
        if not rep.get("ok"):
            all_ok = False
    return {"ok": all_ok, "material": mat, "orders": reports}


def list_local_nm_inputs_for_mat(mat: str) -> list[dict]:
    """Inputs NM (vc-relax, relax, scf) sous inputs/materiaux/<Mat>/."""
    mat = _safe_mat_name(mat)
    if not mat:
        return []
    base = _local_inputs_dir() / "materiaux" / mat
    legacy = _local_inputs_dir() / mat
    seen: set[str] = set()
    out: list[dict] = []
    for root in (base, legacy, base / "phase1"):
        if not root.is_dir():
            continue
        for kind in _NM_KINDS:
            name = f"{mat}-{kind}.in"
            path = root / name
            if not path.is_file():
                continue
            key = str(path.resolve())
            if key in seen:
                continue
            seen.add(key)
            try:
                rel = path.relative_to(_local_inputs_dir())
            except ValueError:
                rel = Path(path.name)
            out.append(
                {
                    "kind": kind,
                    "name": name,
                    "path": str(path),
                    "rel_path": str(rel).replace("\\", "/"),
                    "nspin": _read_nspin_from_in(path),
                    "phase_id": "",
                }
            )
    if base.is_dir():
        for d in sorted(base.iterdir(), key=lambda p: p.name.lower()):
            if not d.is_dir() or not _DOPING_DIR_RE.match(d.name):
                continue
            pid = d.name
            for kind in _NM_KINDS:
                cands = sorted(
                    [p for p in d.glob(f"*-{kind}.in") if p.is_file() and "rescue" not in p.name.lower()],
                    key=lambda p: (0 if p.name == f"{mat}-{kind}.in" else 1, p.name.lower()),
                )
                if not cands:
                    continue
                path = cands[0]
                key = str(path.resolve())
                if key in seen:
                    continue
                seen.add(key)
                try:
                    rel = path.relative_to(_local_inputs_dir())
                except ValueError:
                    rel = Path(path.name)
                out.append(
                    {
                        "kind": kind,
                        "name": path.name,
                        "path": str(path),
                        "rel_path": str(rel).replace("\\", "/"),
                        "nspin": _read_nspin_from_in(path),
                        "phase_id": pid,
                    }
                )
    order = {k: i for i, k in enumerate(_NM_KINDS)}
    out.sort(key=lambda x: order.get(x.get("kind"), 99))
    return out


def _proxy_json_get(path: str) -> tuple[dict | None, int]:
    resp = _proxy_path(path)
    try:
        data = json.loads(resp.get_data(as_text=True))
        return data, resp.status_code
    except (json.JSONDecodeError, TypeError, ValueError):
        return None, resp.status_code


@app.get("/api/cif-library")
def api_cif_library():
    """Liste les dossiers CIF actifs et tous les fichiers .cif."""
    dirs = [str(p) for p in _local_cif_dirs()]
    files = list_all_local_cifs()
    return Response(
        json.dumps({"ok": True, "cif_dirs": dirs, "cifs": files, "count": len(files)}),
        mimetype="application/json",
    )


@app.get("/api/materials/<mat>/cifs")
def api_material_cifs_local(mat: str):
    qs = request.query_string.decode("utf-8", errors="replace")
    path = f"/api/materials/{urllib.parse.quote(mat)}/cifs"
    if qs:
        path = f"{path}?{qs}"
    data, status = _proxy_json_get(path)
    if data is None:
        return _proxy_path(path)
    by_name: dict[str, dict] = {}
    for c in list_local_cifs_for_mat(mat):
        if c.get("name"):
            by_name[c["name"]] = c
    for c in data.get("cifs") or []:
        if c.get("name"):
            by_name.setdefault(c["name"], c)
    merged = list(by_name.values())
    data["cifs"] = merged
    data["count"] = len(merged)
    data["ok"] = True
    data["material"] = _safe_mat_name(mat) or mat
    return Response(json.dumps(data), status=status, mimetype="application/json")


@app.get("/api/materials/<mat>/structure-source")
def api_structure_source_local(mat: str):
    qs = request.query_string.decode("utf-8", errors="replace")
    path = f"/api/materials/{urllib.parse.quote(mat)}/structure-source"
    if qs:
        path = f"{path}?{qs}"
    data, status = _proxy_json_get(path)
    if data is None:
        return _proxy_path(path)
    if data.get("vc_relax_exists") or int(data.get("cif_count") or 0) > 0:
        return Response(json.dumps(data), status=status, mimetype="application/json")
    local = list_local_cifs_for_mat(mat)
    if local:
        c = local[0]
        data.update(
            {
                "ok": True,
                "material": _safe_mat_name(mat) or mat,
                "source": "cif",
                "cif_count": len(local),
                "cif_name": c["name"],
                "cif_primary": c["path"],
                "message_fr": f"CIF trouvé ({c['name']}) dans le dossier cif/ — prêt pour VC-RELAX.",
                "message_en": f"CIF found ({c['name']}) in cif/ — ready for VC-RELAX.",
            }
        )
    return Response(json.dumps(data), status=status, mimetype="application/json")


@app.get("/api/materials/<mat>/nm-inputs")
def api_material_nm_inputs_local(mat: str):
    qs = request.query_string.decode("utf-8", errors="replace")
    path = f"/api/materials/{urllib.parse.quote(mat)}/nm-inputs"
    if qs:
        path = f"{path}?{qs}"
    data, status = _proxy_json_get(path)
    if data is None or status >= 400:
        data = {"ok": True, "material": mat, "inputs": []}
    local = list_local_nm_inputs_for_mat(mat)
    by_kind: dict[str, dict] = {}
    for row in data.get("inputs") or []:
        k = row.get("kind")
        if k:
            by_kind[k] = row
    for row in local:
        by_kind.setdefault(row["kind"], row)
    merged = list(by_kind.values())
    merged.sort(key=lambda x: _NM_KINDS.index(x["kind"]) if x.get("kind") in _NM_KINDS else 99)
    data["inputs"] = merged
    data["count"] = len(merged)
    data["ok"] = True
    data["material"] = _safe_mat_name(mat) or mat
    data["inputs_root"] = str(_local_inputs_dir())
    return Response(json.dumps(data), status=200, mimetype="application/json")


@app.get("/api/materials/<mat>/input/<kind>")
def api_get_material_input_local(mat: str, kind: str):
    """Récupère le contenu d'un input (VC-RELAX, RELAX, SCF...) pour une phase (y compris dopées)."""
    mat = _safe_mat_name(mat) or mat
    kind = kind.strip().lower()
    phase_id = (request.args.get("phase_id") or "").strip()
    
    inputs_root = _local_inputs_dir()
    path = resolve_material_input_file(mat, kind, phase_id)
    if path and path.is_file():
        content = path.read_text(encoding="utf-8")
        rel_path = str(path.relative_to(inputs_root))
        return Response(
            json.dumps(
                {
                    "ok": True,
                    "material": mat,
                    "phase_id": phase_id,
                    "kind": kind,
                    "path": f"inputs/{rel_path}",
                    "content": content,
                }
            ),
            status=200,
            mimetype="application/json",
        )

    hint = ""
    if phase_id:
        phase_dir = inputs_root / "materiaux" / mat / phase_id
        if phase_dir.is_dir():
            found = sorted(p.name for p in phase_dir.glob("*.in") if p.is_file())
            if found:
                hint = (
                    f" Attendu *-{kind}.in ou {mat}-{kind}.in dans {phase_id}/ "
                    f"(présents : {', '.join(found[:8])})."
                )
            else:
                hint = " Dossier phase vide — relancez « Générer les phases dopées »."
        else:
            hint = f" Dossier inputs/materiaux/{mat}/{phase_id}/ absent — regénérez la série dopée."
    else:
        hint = f" Attendu inputs/materiaux/{mat}/{mat}-{kind}.in ou dossier dop_*/."

    return Response(
        json.dumps(
            {
                "ok": False,
                "error": f"Input {kind} introuvable pour {mat}"
                + (f" (phase {phase_id})" if phase_id else "")
                + hint,
            }
        ),
        status=404,
        mimetype="application/json",
    )


@app.get("/api/materials/<mat>/mag-orders/<order>/audit")
def api_mag_order_audit(mat: str, order: str):
    """Audit local VC-RELAX / RELAX / SCF pour un ordre magnétique (nspin, noncolin, en-tête)."""
    data = _audit_mag_order_chain_local(mat, order)
    data["ok"] = bool(data.get("ok"))
    return Response(json.dumps(data), status=200, mimetype="application/json")


@app.get("/api/materials/<mat>/mag-orders/audit-all")
def api_mag_orders_audit_all(mat: str):
    raw = (request.args.get("orders") or "").strip()
    orders = [x.strip().lower() for x in raw.split(",") if x.strip()] if raw else None
    data = _audit_all_mag_orders_local(mat, orders)
    return Response(json.dumps(data), status=200, mimetype="application/json")


@app.post("/api/materials/<mat>/mag-orders/regenerate-local")
def api_mag_orders_regenerate_local(mat: str):
    """Régénère mag/* depuis le SCF NM (supercellules AFM, mag_reference, tous ordres viables)."""
    mat = _safe_mat_name(mat) or mat
    body = request.get_json(silent=True) or {}
    phase_id = str(body.get("phase_id") or request.args.get("phase_id") or "").strip()
    if _DOPED_JOB_RE.search(mat):
        if phase_id:
            data = prepare_magnetic_inputs_for_doped_phase(mat, phase_id)
        else:
            data = prepare_magnetic_inputs_for_doped_job(mat)
    else:
        data = regenerate_material(mat, inputs_root=_local_inputs_dir())
    if data.get("ok") and not _DOPED_JOB_RE.search(mat):
        audit = _audit_all_mag_orders_local(mat)
        data["audit"] = audit
        data["audit_ok"] = bool(audit.get("ok"))
    return Response(json.dumps(data), status=200, mimetype="application/json")


@app.post("/api/mag-inputs/regenerate-catalog")
def api_mag_regenerate_catalog():
    """Tous les matériaux du catalogue inputs/materiaux/ avec SCF NM."""
    data = regenerate_catalog(inputs_root=_local_inputs_dir())
    audits = []
    for rep in data.get("materials") or []:
        m = rep.get("material")
        if m and rep.get("ok"):
            audits.append(_audit_all_mag_orders_local(m))
    data["audits"] = audits
    data["audit_ok"] = all(a.get("ok") for a in audits) if audits else False
    return Response(json.dumps(data), status=200, mimetype="application/json")


@app.get("/api/mag-inputs/audit-catalog")
def api_mag_audit_catalog():
    """Audit magnétique pour chaque matériau du catalogue."""
    mats = iter_catalog_materials(_local_inputs_dir())
    reports = []
    all_ok = True
    for m in mats:
        mag_root = _local_inputs_dir() / "materiaux" / m / "mag"
        if not mag_root.is_dir():
            reports.append({"material": m, "ok": False, "skipped": True, "reason": "no_mag_dir"})
            all_ok = False
            continue
        rep = _audit_all_mag_orders_local(m)
        reports.append(rep)
        if not rep.get("ok"):
            all_ok = False
    return Response(
        json.dumps({"ok": all_ok, "materials": mats, "reports": reports}),
        status=200,
        mimetype="application/json",
    )


def _doping_route_response(mat: str, action: str):
    """Gestion locale doping (species / preview / generate) — aussi depuis le proxy catch-all."""
    if action == "species":
        if request.method != "GET":
            return Response(
                json.dumps({"ok": False, "error": "GET requis pour /phases/doping/species"}),
                status=405,
                mimetype="application/json",
            )
        return api_doping_species(mat)
    if action in ("preview", "generate"):
        if request.method != "POST":
            return Response(
                json.dumps({"ok": False, "error": f"POST requis pour /phases/doping/{action}"}),
                status=405,
                mimetype="application/json",
            )
        if action == "preview":
            return api_doping_preview(mat)
        return api_doping_generate(mat)
    return Response(
        json.dumps({"ok": False, "error": f"Action doping inconnue : {action}"}),
        status=404,
        mimetype="application/json",
    )


_DOPING_DIR_RE = re.compile(r"^dop_", re.I)
_DOPED_JOB_RE = re.compile(r"_doped$", re.I)


@app.route("/api/materials/<mat>/io-profile", methods=["GET"])
def api_material_io_profile(mat: str):
    """Inventaire inputs/outputs — profil Préparation / Calcul (non dopé vs dopé)."""
    mat = _safe_mat_name(mat) or mat
    data = build_material_io_profile(mat)
    return Response(json.dumps(data), status=200 if data.get("ok") else 400, mimetype="application/json")


@app.route("/api/materials/<mat>/phases/doping/repair", methods=["POST"])
def api_doping_repair(mat: str):
    """Sépare dop_* du parent NM ; alias job ; outputs/…/optimisation/."""
    mat = _safe_mat_name(mat) or mat
    body = request.get_json(silent=True) or {}
    parent_a = str(body.get("parent_material_a") or body.get("parent_a") or "").strip()
    data = repair_doped_job_layout(mat, parent_material_a=parent_a)
    return Response(json.dumps(data), status=200 if data.get("ok") else 400, mimetype="application/json")


@app.route("/api/materials/<mat>/phases/doping/files", methods=["GET"])
def api_doping_files(mat: str):
    """Liste les dossiers dop_* déjà présents sous inputs/materiaux/<Mat>/ (dépôt SQS-QE)."""
    mat = _safe_mat_name(mat) or mat
    root = _local_inputs_dir() / "materiaux" / mat
    phases: list[dict] = []
    if root.is_dir():
        for d in sorted(root.iterdir(), key=lambda p: p.name.lower()):
            if not d.is_dir() or not _DOPING_DIR_RE.match(d.name):
                continue
            prefix = _detect_formula_prefix(d, mat)
            if prefix:
                _sync_doped_folder_layout(d, mat, prefix)
                _guarantee_phase_vc_relax(d, mat, prefix)
            vc_cands = [
                p
                for p in d.glob("*-vc-relax.in")
                if p.is_file() and "rescue" not in p.name.lower() and ".orig" not in p.name.lower()
            ]
            if not vc_cands:
                alias = d / f"{mat}-vc-relax.in"
                if alias.is_file():
                    vc_cands = [alias]
            if not vc_cands:
                continue
            vc_cands.sort(key=lambda p: (-p.stat().st_mtime, p.name.lower()))
            vc = vc_cands[0]
            file_prefix = vc.name[: -len("-vc-relax.in")]
            rel = f"inputs/materiaux/{mat}/{d.name}/"
            mag_orders = sorted(
                p.name
                for p in (d / "mag").iterdir()
                if (d / "mag").is_dir() and p.is_dir()
            ) if (d / "mag").is_dir() else []
            phases.append(
                {
                    "phase_id": d.name,
                    "file_prefix": file_prefix,
                    "inputs_path": rel,
                    "vc_relax_path": rel + vc.name,
                    "mag_path": rel + "mag/",
                    "mag_orders": mag_orders,
                    "has_magnetic_inputs": bool(mag_orders),
                }
            )
    return Response(
        json.dumps({"ok": True, "material": mat, "phases": phases}),
        status=200,
        mimetype="application/json",
    )


@app.route("/api/materials/<mat>/phases/doping/species", methods=["GET"])
def api_doping_species(mat: str):
    """Éléments substituables dans une phase NM (ATOMIC_SPECIES / positions)."""
    phase_id = (request.args.get("phase_id") or "").strip()
    parent_b = (request.args.get("parent_b") or request.args.get("parent_material_b") or "").strip()
    dopant = (request.args.get("dopant") or "").strip()
    data = list_host_elements(
        _safe_mat_name(mat) or mat,
        phase_id,
        parent_b=parent_b,
        dopant=dopant,
    )
    return Response(json.dumps(data), status=200 if data.get("ok") else 400, mimetype="application/json")


@app.route("/api/materials/<mat>/phases/doping/preview", methods=["POST"])
def api_doping_preview(mat: str):
    body = request.get_json(silent=True) or {}
    phase_id = str(body.get("phase_id") or "").strip()
    host_element = str(body.get("host_element") or "").strip()
    dopant = str(body.get("dopant") or body.get("dopant_element") or "").strip()
    fractions = body.get("fractions") or body.get("fractions_x") or []
    try:
        fr = [float(x) for x in fractions]
    except (TypeError, ValueError):
        fr = []
    parent_a = str(body.get("parent_material_a") or body.get("parent_a") or "").strip()
    parent_b = str(body.get("parent_material_b") or body.get("parent_b") or "").strip()
    data = preview_doping(
        _safe_mat_name(mat) or mat,
        phase_id=phase_id,
        host_element=host_element,
        dopant=dopant,
        fractions=fr,
        parent_material_a=parent_a,
        parent_material_b=parent_b,
    )
    return Response(json.dumps(data), status=200 if data.get("ok") else 400, mimetype="application/json")


@app.route("/api/materials/<mat>/phases/doping/generate", methods=["POST"])
def api_doping_generate(mat: str):
    body = request.get_json(silent=True) or {}
    phase_id = str(body.get("phase_id") or "").strip()
    host_element = str(body.get("host_element") or "").strip()
    dopant = str(body.get("dopant") or body.get("dopant_element") or "").strip()
    fractions = body.get("fractions") or []
    try:
        fr = [float(x) for x in fractions]
    except (TypeError, ValueError):
        fr = []
    parent_a = str(body.get("parent_material_a") or body.get("parent_a") or "").strip()
    parent_b = str(body.get("parent_material_b") or body.get("parent_b") or "").strip()
    try:
        data = generate_doping(
            _safe_mat_name(mat) or mat,
            phase_id=phase_id,
            host_element=host_element,
            dopant=dopant,
            fractions=fr,
            parent_material_a=parent_a,
            parent_material_b=parent_b,
            inputs_root=_local_inputs_dir(),
        )
    except Exception as exc:  # noqa: BLE001 — toujours renvoyer du JSON à l’UI
        data = {
            "ok": False,
            "error": f"Génération dopée interrompue : {exc}",
            "created": [],
            "errors": [str(exc)],
        }
    return Response(json.dumps(data), status=200 if data.get("ok") else 400, mimetype="application/json")


@app.post("/api/materials/<mat>/cif/to-vcrelax")
def api_cif_to_vcrelax_enriched(mat: str):
    """Ajoute cif_path depuis le dossier cif/ local avant envoi à l'API calculs."""
    body = request.get_json(silent=True) or {}
    if not str(body.get("cif_path") or "").strip() and str(body.get("cif_name") or "").strip():
        name = str(body["cif_name"]).strip()
        for c in list_local_cifs_for_mat(mat):
            if c.get("name") == name and c.get("path"):
                body = {**body, "cif_path": c["path"]}
                break
    payload = json.dumps(body).encode("utf-8")
    path = f"/api/materials/{urllib.parse.quote(mat)}/cif/to-vcrelax"
    return _proxy_path(
        path,
        body_override=payload,
    )


_DOPING_SUBPATH_RE = re.compile(
    r"^materials/([^/]+)/phases/doping/(species|preview|generate)$",
    re.I,
)


@app.route("/api/<path:subpath>", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"])
def proxy_api(subpath: str):
    if request.method == "OPTIONS":
        return Response(status=204)
    dm = _DOPING_SUBPATH_RE.match(subpath)
    if dm:
        mat = urllib.parse.unquote(dm.group(1))
        action = dm.group(2).lower()
        return _doping_route_response(mat, action)
    return _proxy_path(f"/api/{subpath}")


@app.route("/inputs/<path:subpath>", methods=["GET", "HEAD"])
def proxy_inputs(subpath: str):
    return _proxy_path(f"/inputs/{subpath}")


@app.route("/outputs/<path:subpath>", methods=["GET", "HEAD"])
def proxy_outputs(subpath: str):
    return _proxy_path(f"/outputs/{subpath}")


def _send_interface(name: str):
    path = INTERFACE / name
    if not path.is_file():
        return Response(
            (
                "<!DOCTYPE html><html><body><h1>Interface absente</h1>"
                f"<p>Fichier manquant : {path}</p>"
                "<p>Relancez depuis le dossier Phases / SQS-QE : ./DEMARRER.sh</p></body></html>"
            ),
            status=503,
            mimetype="text/html; charset=utf-8",
        )
    resp = send_from_directory(INTERFACE, name)
    resp.headers["Cache-Control"] = "no-cache, must-revalidate"
    return resp


@app.get("/")
@app.get("/accueil.html")
def accueil():
    """Page d’accueil — résumé de l’objectif SQS."""
    return _send_interface("accueil.html")


@app.get("/index.html")
@app.get("/app")
def index():
    """Interface de préparation (inputs)."""
    return _send_interface("index.html")


@app.get("/guide.html")
def guide():
    """Guide d’utilisation SQS."""
    return _send_interface("guide.html")


def main() -> None:
    LOGS.mkdir(parents=True, exist_ok=True)
    host = os.environ.get("SQS_QE_HOST", "127.0.0.1")
    port = int(os.environ.get("SQS_QE_PORT", "5031"))
    if not INTERFACE.is_dir():
        print(f"  ✗ Interface absente : {INTERFACE}", file=sys.stderr)
        sys.exit(1)
    print(f"  Phases / SQS → http://{host}:{port}/  (accueil)")
    print(f"  Préparation   → http://{host}:{port}/index.html")
    print(f"  Guide         → http://{host}:{port}/guide.html")
    print(f"  Proxy API      → {API_UPSTREAM}")
    app.run(host=host, port=port, debug=False, threaded=True)


if __name__ == "__main__":
    main()

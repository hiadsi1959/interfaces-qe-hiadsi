#!/usr/bin/env python3
"""Régénère inputs/materiaux/<Mat>/mag/* depuis le SCF NM (optimisation-QE).

Générique : binaire, ternaire, quaternaire — sous-mailles et supercellules AFM-A/B/C
via mag_orders + mag_reference.json (éléments lourds, 3d, 4f…).
"""
from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OPTQ = Path(os.environ.get("OPTQ_ROOT", Path.home() / "optimisation-QE")).expanduser()
sys.path.insert(0, str(OPTQ / "backend"))
os.environ.setdefault("OPTQ_INPUTS", str(ROOT / "inputs"))
os.environ.setdefault("OPTQ_OUTPUTS", str(ROOT / "outputs"))

from mag_orders import apply_magnetic_order, list_viable_afm_orders  # type: ignore
from mag_reference import reference_for  # type: ignore
from optim import sanitize_pw_input  # type: ignore


def _set_calculation(text: str, kind: str) -> str:
    from mag_orders import _set_calculation as sc  # type: ignore

    return sc(text, kind)


def _merge_preserve(old: str, new: str) -> str:
    """Conserve outdir / pseudo_dir / prefix de l'ancien input."""
    out = new
    for key in ("outdir", "pseudo_dir", "prefix"):
        m = re.search(rf"^\s*{key}\s*=\s*['\"]?([^'\"\n]+)", old, re.I | re.M)
        if m:
            val = m.group(1).strip().strip("'\"")
            out = re.sub(
                rf"^\s*{key}\s*=.*$",
                f"  {key} = '{val}'",
                out,
                count=1,
                flags=re.I | re.M,
            )
    return out


def _nm_scf_path(mat: str, inputs_root: Path | None = None) -> Path | None:
    base = (inputs_root or ROOT / "inputs") / "materiaux" / mat
    for rel in (f"{mat}-scf.in", f"phase1/{mat}-scf.in"):
        p = base / rel
        if p.is_file():
            return p
    return None


def _mag_orders_for_source(src_text: str) -> list[str]:
    """FM + AFM viables (motif non trivial) + NCL — comme prepare_magnetic_scf."""
    viable = [v["order"] for v in list_viable_afm_orders(src_text)]
    return ["fm", *viable, "ncl"]


def regenerate_material(mat: str, *, inputs_root: Path | None = None) -> dict:
    mat = mat.strip()
    nm_scf = _nm_scf_path(mat, inputs_root)
    if nm_scf is None:
        return {"ok": False, "material": mat, "error": "SCF NM absent (materiaux/<Mat>/<Mat>-scf.in)"}
    src = nm_scf.read_text(encoding="utf-8")
    ref = reference_for(mat)
    mag_root = (inputs_root or ROOT / "inputs") / "materiaux" / mat / "mag"
    orders = _mag_orders_for_source(src)
    kinds = ("vc-relax", "relax", "scf", "nscf")
    report: dict = {
        "ok": True,
        "material": mat,
        "nm_source": str(nm_scf),
        "mag_reference": (ref.get("classification_en") if ref else None),
        "orders_requested": orders,
        "orders": [],
    }
    for order in orders:
        try:
            base, extra = apply_magnetic_order(src, order)
        except ValueError as exc:
            report["orders"].append({"order": order, "ok": False, "error": str(exc)})
            report["ok"] = False
            continue
        ord_dir = mag_root / order
        ord_dir.mkdir(parents=True, exist_ok=True)
        paths: dict[str, str] = {}
        scf_template: str | None = None
        for kind in kinds:
            dest = ord_dir / f"{mat}-{kind}.in"
            old = dest.read_text(encoding="utf-8", errors="replace") if dest.is_file() else ""
            if kind == "nscf":
                from postproc import (  # type: ignore
                    _dense_grid,
                    _nscf_nbnd,
                    _scf_is_metal,
                    _scf_nelec,
                    generate_nscf_input,
                    nscf_out_dir,
                )

                base_scf = scf_template or _set_calculation(base, "scf")
                base_scf, _ = sanitize_pw_input(base_scf, "scf")
                grid = _dense_grid(mat, base_scf, phase_id="")
                nbnd = _nscf_nbnd(base_scf, _scf_nelec(mat, base_scf, phase_id=""))
                nscf_dir = nscf_out_dir(mat, phase_id="", mag_order=order)
                t = generate_nscf_input(
                    base_scf,
                    outdir=nscf_dir,
                    grid=grid,
                    nbnd=nbnd,
                    force_smearing=_scf_is_metal(mat, base_scf, phase_id=""),
                )
                t, _ = sanitize_pw_input(t, "nscf")
            else:
                t = _set_calculation(base, kind)
                t, _ = sanitize_pw_input(t, kind)
                if kind == "scf":
                    scf_template = t
            if old:
                t = _merge_preserve(old, t)
            dest.write_text(t if t.endswith("\n") else t + "\n", encoding="utf-8")
            paths[kind] = str(dest)
        report["orders"].append(
            {
                "order": order,
                "ok": True,
                "paths": paths,
                "nat": extra.get("nat"),
                "expanded": extra.get("expanded"),
                "supercell": extra.get("supercell"),
            }
        )
    return report


def iter_catalog_materials(inputs_root: Path | None = None) -> list[str]:
    base = (inputs_root or ROOT / "inputs") / "materiaux"
    if not base.is_dir():
        return []
    out: list[str] = []
    for d in sorted(base.iterdir()):
        if not d.is_dir() or d.name.startswith("."):
            continue
        if _nm_scf_path(d.name, inputs_root) is not None:
            out.append(d.name)
    return out


def regenerate_catalog(inputs_root: Path | None = None) -> dict:
    mats = iter_catalog_materials(inputs_root)
    reports = [regenerate_material(m, inputs_root=inputs_root) for m in mats]
    ok = all(r.get("ok") for r in reports) if reports else False
    return {"ok": ok, "count": len(reports), "materials": reports}


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in ("--all", "-a"):
        print(json.dumps(regenerate_catalog(), indent=2, ensure_ascii=False))
    else:
        mat = sys.argv[1] if len(sys.argv) > 1 else "GdCrO3"
        print(json.dumps(regenerate_material(mat), indent=2, ensure_ascii=False))

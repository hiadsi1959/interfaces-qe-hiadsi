#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PIDFILE="$HERE/logs/sqs.pid"
PORT="${SQS_QE_PORT:-5031}"

stopped=0
if [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
  kill "$(cat "$PIDFILE")" 2>/dev/null || true
  stopped=1
fi
rm -f "$PIDFILE"

if command -v ss >/dev/null 2>&1; then
  pid_on_port=$(ss -tlnp 2>/dev/null | grep ":${PORT} " | sed -n 's/.*pid=\([0-9]*\).*/\1/p' | head -1)
  if [[ -n "${pid_on_port:-}" ]]; then
    cmd=$(ps -p "$pid_on_port" -o args= 2>/dev/null || true)
    if [[ "$cmd" == *"sqs_server.py"* ]]; then
      kill "$pid_on_port" 2>/dev/null || true
      stopped=1
    fi
  fi
fi

if [[ "$stopped" -eq 1 ]]; then
  echo "  Phases / SQS arrêté."
else
  echo "  Aucun serveur SQS actif."
fi

#!/usr/bin/env bash
# =============================================================================
# CONFIGURER.sh — Prérequis + adaptation de l’interface au PC courant
#
# À lancer UNE FOIS (ou après déplacement du dépôt / nouvel ordinateur) :
#   ./CONFIGURER.sh
# Puis démarrer l’interface :
#   ./DEMARRER.sh
# =============================================================================
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

echo ""
echo "  ══════════════════════════════════════════════════════"
echo "  SQS-QE — Configuration pour ce PC"
echo "  Racine : $HERE"
echo "  ══════════════════════════════════════════════════════"
echo ""

# ── 1. Scripts exécutables ───────────────────────────────────────────────────
chmod +x "$HERE/CONFIGURER.sh" "$HERE/DEMARRER.sh" "$HERE/ARRETER.sh" 2>/dev/null || true

# ── 2. config_local.sh adapté à ce PC ────────────────────────────────────────
if [[ ! -f "$HERE/config_local.sh" ]]; then
  if [[ ! -f "$HERE/config_local.sh.example" ]]; then
    echo "  ✗ config_local.sh.example manquant — dépôt incomplet."
    exit 1
  fi
  cp "$HERE/config_local.sh.example" "$HERE/config_local.sh"
  echo "  ✓ config_local.sh créé depuis l’exemple (chemins relatifs au dépôt)."
else
  echo "  · config_local.sh déjà présent — conservation des réglages."
fi

# shellcheck disable=SC1091
source "$HERE/config_local.sh"

# Forcer la racine sur le dossier réel (évite un ancien chemin d’un autre PC)
export SQS_QE_ROOT="$HERE"
# Réécrire les exports dérivés si absents ou pointant hors dépôt
export QE_BIN_DIR="${QE_BIN_DIR:-$HERE/bin}"
export PSEUDO_DIR="${PSEUDO_DIR:-$HERE/pseudos}"
export OPTQ_CIF_DIR="${OPTQ_CIF_DIR:-$HERE/cif}"
export OPTQ_CIF_DIRS="${OPTQ_CIF_DIRS:-$HERE/cif}"
export OPTQ_INPUTS="${OPTQ_INPUTS:-$HERE/inputs}"
export OPTQ_OUTPUTS="${OPTQ_OUTPUTS:-$HERE/outputs}"

# ── 3. Détection OPTQ_ROOT (backend calculs) sur ce PC ───────────────────────
detect_optq_root() {
  local c
  for c in \
    "${OPTQ_ROOT:-}" \
    "$HOME/optimisation-QE" \
    "$HOME/Phase/optimisation-QE" \
    "$(dirname "$HERE")/optimisation-QE" \
    "$HERE/../optimisation-QE"
  do
    [[ -z "$c" ]] && continue
    c="$(cd "$c" 2>/dev/null && pwd)" || continue
    if [[ -f "$c/backend/api_server.py" ]]; then
      echo "$c"
      return 0
    fi
  done
  return 1
}

DETECTED_OPTQ="$(detect_optq_root || true)"
if [[ -n "$DETECTED_OPTQ" ]]; then
  OPTQ_ROOT="$DETECTED_OPTQ"
  export OPTQ_ROOT
  # Mettre à jour config_local.sh si OPTQ_ROOT y est encore le défaut non résolu
  if grep -qE '^export OPTQ_ROOT=' "$HERE/config_local.sh" 2>/dev/null; then
    if ! grep -qF "export OPTQ_ROOT=\"$OPTQ_ROOT\"" "$HERE/config_local.sh" 2>/dev/null; then
      # Remplace la ligne OPTQ_ROOT par le chemin détecté (commentaire conservé au-dessus)
      sed -i.bak -E "s|^export OPTQ_ROOT=.*|export OPTQ_ROOT=\"${OPTQ_ROOT}\"|" "$HERE/config_local.sh"
      rm -f "$HERE/config_local.sh.bak"
      echo "  ✓ OPTQ_ROOT adapté dans config_local.sh → $OPTQ_ROOT"
    else
      echo "  · OPTQ_ROOT = $OPTQ_ROOT"
    fi
  else
    echo "  · OPTQ_ROOT = $OPTQ_ROOT"
  fi
else
  OPTQ_ROOT="${OPTQ_ROOT:-$HOME/optimisation-QE}"
  export OPTQ_ROOT
  echo "  ⚠ Backend optimisation-QE introuvable."
  echo "    Attendu : \$HOME/optimisation-QE ou OPTQ_ROOT dans config_local.sh"
  echo "    L’UI peut démarrer, mais les calculs / génération avancée nécessitent ce dépôt."
fi

QE_SOURCE_BIN="${QE_SOURCE_BIN:-}"
QE_SOURCE_PSEUDO="${QE_SOURCE_PSEUDO:-}"
if [[ -z "$QE_SOURCE_BIN" && -x "$OPTQ_ROOT/bin/pw.x" ]]; then
  QE_SOURCE_BIN="$OPTQ_ROOT/bin"
fi
if [[ -z "$QE_SOURCE_PSEUDO" && -d "$OPTQ_ROOT/pseudos" ]]; then
  QE_SOURCE_PSEUDO="$OPTQ_ROOT/pseudos"
fi
# Fallbacks courants sur un nouveau PC
if [[ -z "$QE_SOURCE_BIN" ]]; then
  for c in /usr/local/bin "$HOME/q-e/bin" "$HOME/qe/bin"; do
    if [[ -x "$c/pw.x" ]]; then QE_SOURCE_BIN="$c"; break; fi
  done
fi

# ── 4. Arborescence locale ───────────────────────────────────────────────────
mkdir -p \
  "$HERE/bin" \
  "$HERE/pseudos" \
  "$HERE/cif" \
  "$HERE/inputs/materiaux" \
  "$HERE/outputs/materiaux" \
  "$HERE/logs"
echo "  ✓ Dossiers : bin/ pseudos/ cif/ inputs/ outputs/ logs/"

# ── 5. Binaires Quantum ESPRESSO ─────────────────────────────────────────────
link_bin() {
  local name="$1"
  if [[ -z "$QE_SOURCE_BIN" || ! -x "$QE_SOURCE_BIN/$name" ]]; then
    return 0
  fi
  ln -sfn "$QE_SOURCE_BIN/$name" "$HERE/bin/$name"
}

if [[ -n "$QE_SOURCE_BIN" ]]; then
  echo "  Binaires QE ← $QE_SOURCE_BIN"
  for exe in pw.x ph.x pp.x bands.x dos.x projwfc.x neb.x cp.x ld1.x; do
    link_bin "$exe"
  done
  if [[ -x "$HERE/bin/pw.x" ]]; then
    echo "  ✓ pw.x disponible dans bin/"
  else
    echo "  ⚠ pw.x non lié — vérifiez QE_SOURCE_BIN"
  fi
else
  echo "  ⚠ Aucune source de binaires QE trouvée."
  echo "    Placez pw.x dans $HERE/bin/ ou définissez QE_SOURCE_BIN dans config_local.sh"
fi

# ── 6. Pseudopotentiels ──────────────────────────────────────────────────────
if [[ -n "$QE_SOURCE_PSEUDO" && -d "$QE_SOURCE_PSEUDO" ]]; then
  echo "  Pseudos ← $QE_SOURCE_PSEUDO"
  shopt -s nullglob
  n=0
  for f in "$QE_SOURCE_PSEUDO"/*; do
    base=$(basename "$f")
    [[ "$base" == "README.txt" ]] && continue
    [[ -f "$f" || -L "$f" ]] || continue
    ln -sfn "$f" "$HERE/pseudos/$base"
    n=$((n + 1))
  done
  shopt -u nullglob
  echo "  ✓ $n fichier(s) liés dans pseudos/"
else
  n_local=$(find "$HERE/pseudos" -maxdepth 1 \( -name '*.UPF' -o -name '*.upf' \) 2>/dev/null | wc -l | tr -d ' ')
  if [[ "${n_local:-0}" -gt 0 ]]; then
    echo "  · pseudos/ local : $n_local UPF (conservés)"
  else
    echo "  ⚠ Aucun pseudopotentiel — copiez des *.UPF dans $HERE/pseudos/"
    echo "    ou définissez QE_SOURCE_PSEUDO dans config_local.sh"
  fi
fi

# ── 7. Bibliothèques runtime (MPI / MKL) ─────────────────────────────────────
if [[ -d "$OPTQ_ROOT/lib" && -n "$(ls -A "$OPTQ_ROOT/lib" 2>/dev/null || true)" ]]; then
  ln -sfn "$OPTQ_ROOT/lib" "$HERE/lib"
  echo "  ✓ lib/ → $OPTQ_ROOT/lib"
fi

# ── 8. Python / venv Flask (UI) ──────────────────────────────────────────────
PYTHON_BIN="${SQS_QE_PYTHON:-}"
if [[ -z "$PYTHON_BIN" || ! -x "$PYTHON_BIN" ]]; then
  if command -v python3 >/dev/null 2>&1; then
    PYTHON_BIN="$(command -v python3)"
  else
    echo "  ✗ python3 introuvable — installez Python ≥ 3.10"
    exit 1
  fi
fi

PY_OK="$("$PYTHON_BIN" -c 'import sys; print(1 if sys.version_info >= (3, 10) else 0)' 2>/dev/null || echo 0)"
if [[ "$PY_OK" != "1" ]]; then
  echo "  ✗ Python ≥ 3.10 requis (trouvé : $("$PYTHON_BIN" -V 2>&1))"
  exit 1
fi
echo "  · Python UI : $("$PYTHON_BIN" -V 2>&1) ($PYTHON_BIN)"

if [[ ! -x "$HERE/.venv/bin/python" ]]; then
  echo "  Création venv (.venv)…"
  "$PYTHON_BIN" -m venv "$HERE/.venv"
fi
# pip à jour + dépendances
"$HERE/.venv/bin/pip" install -q --upgrade pip
"$HERE/.venv/bin/pip" install -q -r "$HERE/requirements.txt"
if ! "$HERE/.venv/bin/python" -c "import flask, numpy" 2>/dev/null; then
  echo "  ✗ Échec import flask/numpy dans .venv"
  exit 1
fi
echo "  ✓ venv UI prêt (flask, numpy)"

# Pointer SQS_QE_PYTHON dans config si commenté
if grep -qE '^# export SQS_QE_PYTHON=' "$HERE/config_local.sh" 2>/dev/null; then
  sed -i.bak -E "s|^# export SQS_QE_PYTHON=.*|export SQS_QE_PYTHON=\"${HERE}/.venv/bin/python\"|" "$HERE/config_local.sh"
  rm -f "$HERE/config_local.sh.bak"
elif ! grep -qE '^export SQS_QE_PYTHON=' "$HERE/config_local.sh" 2>/dev/null; then
  echo "export SQS_QE_PYTHON=\"${HERE}/.venv/bin/python\"" >>"$HERE/config_local.sh"
fi

# ── 9. Backend optimisation-QE (si présent) ──────────────────────────────────
if [[ -f "$OPTQ_ROOT/backend/api_server.py" ]]; then
  if [[ -x "$OPTQ_ROOT/CONFIGURER.sh" ]]; then
    echo "  · Configuration optimisation-QE (CONFIGURER.sh)…"
    (cd "$OPTQ_ROOT" && ./CONFIGURER.sh) || echo "  ⚠ CONFIGURER optimisation-QE a signalé des avertissements."
  elif [[ -f "$OPTQ_ROOT/requirements.txt" ]]; then
    if [[ ! -x "$OPTQ_ROOT/.venv/bin/python" ]]; then
      echo "  Création venv optimisation-QE…"
      "$PYTHON_BIN" -m venv "$OPTQ_ROOT/.venv" || true
    fi
    if [[ -x "$OPTQ_ROOT/.venv/bin/pip" ]]; then
      "$OPTQ_ROOT/.venv/bin/pip" install -q --upgrade pip
      "$OPTQ_ROOT/.venv/bin/pip" install -q -r "$OPTQ_ROOT/requirements.txt" || \
        "$OPTQ_ROOT/.venv/bin/pip" install -q flask ase numpy || true
    fi
  fi
  API_PY="$OPTQ_ROOT/.venv/bin/python"
  [[ -x "$API_PY" ]] || API_PY="$PYTHON_BIN"
  if "$API_PY" -c "import flask" 2>/dev/null; then
    echo "  ✓ Backend API : Flask OK ($API_PY)"
  else
    echo "  ⚠ Flask manquant pour l’API — installez les deps dans $OPTQ_ROOT"
  fi
  if "$API_PY" -c "import ase, numpy" 2>/dev/null; then
    echo "  ✓ Backend API : ase + numpy OK"
  else
    echo "  ⚠ ase/numpy manquants pour l’API (génération CIF / SQS limitée)"
  fi
fi

# ── 10. Marqueur + récapitulatif ─────────────────────────────────────────────
cat >"$HERE/.sqs_qe_configured" <<EOF
# Généré par CONFIGURER.sh — $(date -Iseconds 2>/dev/null || date)
SQS_QE_ROOT=$HERE
OPTQ_ROOT=$OPTQ_ROOT
QE_BIN_DIR=$HERE/bin
PSEUDO_DIR=$HERE/pseudos
HOST=$(hostname 2>/dev/null || echo unknown)
EOF

HOST_UI="${SQS_QE_HOST:-127.0.0.1}"
PORT_UI="${SQS_QE_PORT:-5031}"

echo ""
echo "  ──────────────────────────────────────────────────────"
echo "  ✓ Configuration terminée pour ce PC"
echo "  ──────────────────────────────────────────────────────"
echo "  Dépôt SQS-QE     : $HERE"
echo "  Backend OPTQ     : $OPTQ_ROOT"
echo "  Binaires         : $HERE/bin  (pw.x: $([[ -x $HERE/bin/pw.x ]] && echo oui || echo non))"
echo "  Pseudos          : $HERE/pseudos"
echo "  CIF / inputs     : $HERE/cif  ·  $HERE/inputs"
echo "  Python UI        : $HERE/.venv/bin/python"
echo ""
echo "  Prochaine étape :"
echo "    ./DEMARRER.sh"
echo "  Puis ouvrir : http://${HOST_UI}:${PORT_UI}/"
echo ""

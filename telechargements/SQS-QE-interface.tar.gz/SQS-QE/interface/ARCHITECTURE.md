# Interface Phases / SQS

| Fichier | Rôle |
|---------|------|
| `accueil.html` | Page d’accueil — objectif de l’interface |
| `guide.html` | Guide d’utilisation SQS (préparation) |
| `index.html` | Interface de préparation (**PHASES.SQS**) |
| `app.js` | Logique UI (appels `/api/…` via proxy local) |
| `phase.css` | En-tête / navigation |
| `app.css`, `core.js`, `i18n.js`, `theme.js` | Styles, i18n, thème |

Serveur : `../backend/sqs_server.py` — port **`SQS_QE_PORT`** (5031).  
- `/` → accueil · `/index.html` ou `/app` → préparation · `/guide.html` → guide  

`/env.js` injecte les URLs (5030 / 5031), `QE_BIN_DIR`, `PSEUDO_DIR`, cible QE **7.5+**.

Racine autonome : `../bin/` (exécutables), `../pseudos/` (UPF) — remplis via `../CONFIGURER.sh`.

Chargement (app) : `theme.js` → `i18n.js` → `core.js` → **`/env.js`** → `app.js` (defer).

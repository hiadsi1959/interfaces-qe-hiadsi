(() => {
  const KEY = "qealamode.theme";

  function getTheme() {
    return localStorage.getItem(KEY) === "dark" ? "dark" : "light";
  }

  function applyTheme(theme) {
    const next = theme === "dark" ? "dark" : "light";
    document.documentElement.dataset.theme = next;
    document.documentElement.style.colorScheme = next;
  }

  function setTheme(theme) {
    const next = theme === "dark" ? "dark" : "light";
    localStorage.setItem(KEY, next);
    applyTheme(next);
  }

  applyTheme(getTheme());

  function initThemeSwitch() {
    applyTheme(getTheme());
    document.querySelectorAll(".theme-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.theme === getTheme());
      btn.addEventListener("click", () => setTheme(btn.dataset.theme));
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initThemeSwitch);
  } else {
    initThemeSwitch();
  }

  window.qeTheme = { getTheme, setTheme, applyTheme };
})();

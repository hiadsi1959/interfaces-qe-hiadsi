/** Utilitaires DOM partagés (XSS, liens fichiers) — chargé avant app.js. */
(() => {
  "use strict";

  function esc(s) {
    return String(s ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function escAttr(s) {
    return esc(s);
  }

  /** Whitelist chemins relatifs /outputs/… ou /inputs/… (anti javascript:). */
  function safeHref(url) {
    const u = String(url || "").trim();
    if (!u) return "#";
    if (u.startsWith("/outputs/") || u.startsWith("/inputs/")) return u;
    if (u.startsWith("outputs/") || u.startsWith("inputs/")) return "/" + u;
    if (/^https?:\/\//i.test(u)) {
      try {
        const parsed = new URL(u);
        if (parsed.hostname === "127.0.0.1" || parsed.hostname === "localhost") {
          return parsed.pathname + parsed.search;
        }
      } catch (_) {
        /* ignore */
      }
      return "#";
    }
    return "#";
  }

  window.qeCore = { esc, escAttr, safeHref };
})();

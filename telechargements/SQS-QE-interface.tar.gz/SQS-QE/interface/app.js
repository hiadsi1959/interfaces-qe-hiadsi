(() => {
  const $ = (id) => document.getElementById(id);
  const PHASES_ONLY = true;
  /** Phases : préparer NM / FM·AFM·NCL / SQS / dopage — pas de lancement de calcul ; Résultats = inventaire des .in */
  const PHASES_PREP_ONLY = true;
  const MAIN_APP_HREF = String(window.OPTQE_MAIN_APP || "http://127.0.0.1:5030/index.html");
  const PHASES_APP_HREF = String(window.OPTQE_SQS_APP || "http://127.0.0.1:5031/index.html");

  function appHref(base, params = {}) {
    const q = new URLSearchParams();
    const mat = params.material != null ? params.material : material;
    const ph = params.phase != null ? params.phase : phaseId;
    const job = params.job != null ? params.job : jobId;
    if (mat) q.set("material", mat);
    if (ph) q.set("phase", ph);
    if (job) q.set("job", job);
    if (params.tab) q.set("tab", params.tab);
    const qs = q.toString();
    return qs ? `${base}?${qs}` : base;
  }

  function goPhasesApp() {
    window.location.href = appHref(PHASES_APP_HREF);
  }

  function goMainApp(tab) {
    window.location.href = appHref(MAIN_APP_HREF, { tab: tab || "optimisation" });
  }

  function applyUrlSessionParams() {
    applyUrlSessionParams._appliedMat = "";
    try {
      const p = new URLSearchParams(window.location.search);
      const mat = normalizeMaterialInput(p.get("material") || "");
      const ph = (p.get("phase") || "").trim();
      const job = (p.get("job") || "").trim();
      const tab = p.get("tab");
      if (mat) {
        applyUrlSessionParams._appliedMat = mat;
        if ($("material-select")) $("material-select").value = mat;
      }
      if (ph) {
        phaseId = ph;
        localStorage.setItem("optimqe.phase", ph);
      }
      if (job) {
        jobId = job;
        localStorage.setItem("optimqe.job", job);
      }
      if (tab && !PHASES_ONLY) localStorage.setItem("optimqe.tab", normalizeTab(tab));
    } catch (_) {
      /* ignore */
    }
  }

  function syncMainAppNavLinks() {
    if (!PHASES_ONLY) return;
    const mag = $("btn-session-goto-main-mag");
    const back = document.querySelector(".nav-main-app");
    const guide = document.querySelector(".nav-guide");
    if (mag) mag.href = appHref(MAIN_APP_HREF, { tab: "magnetisme" });
    const protoMag = $("btn-protocol-goto-mag");
    if (protoMag) protoMag.href = appHref(MAIN_APP_HREF, { tab: "magnetisme" });
    if (back) back.href = appHref(MAIN_APP_HREF);
    if (guide) {
      // Guide local SQS (préparation) — pas le guide Optimisation-QE
      guide.href = "./guide.html";
    }
  }

  let material = "";
  /** Dernier payload /optim-status (pipeline NM compact). */
  let lastOptimStatus = null;
  let phaseId = localStorage.getItem("optimqe.phase") || "";
  let jobId = "";
  let sessionConfirmed = false;
  let lastStructureSource = null;
  let lastStructureSourceA = null;
  let lastStructureSourceB = null;
  let dualMaterialsValidated = false;
  let singleMaterialValidated = false;
  let lastMagOrders = null;
  let lastMagCasePaintKey = "";
  let materialsCache = [];
  let optimPollTimer = null;
  let runsAutoTimer = null;
  let optimStatusTimer = null;
  /** Après « Arrêter », bloque le poll / le statut « running » fantôme (API lente). */
  let runPollSuppressUntil = 0;
  /** Seuls les calculs démarrés après ce timestamp (s) apparaissent dans Run tracking. */
  let runTrackingSince = 0;
  let magEditOrder = "";
  /** Étape éditée pour un ordre mag : vc-relax | relax | scf */
  let magEditKind = "scf";
  /** Étape éditée chaîne NM (optim-modal). */
  let optimEditKind = "";
  /** Dossier phase ciblé par openPhaseEditor (null = phase active session). */
  let optimEditPhaseId = null;
  /** Matériau job pour édition d'une phase dopée (null = material session). */
  let optimEditPhaseMat = null;
  let lastStructure = null;
  /** Dernier /phase-stability (libellés structure par dossier phase). */
  let lastPhaseStability = null;
  let lastStudy = null;
  let lastMaterialType = null;
  let lastOptimSteps = null;
  let lastNmChainResume = null;
  /** Jobs NM déjà marqués côté serveur pour enchaînement jusqu'à NSCF. */
  const nmAutorunJobs = new Set();
  /** Une reprise auto par matériau + phase et par chargement de page. */
  let autoResumeScope = "";
  /** Références U (base corrélée) pour la phase affichée. */
  let lastHubbardReference = {};
  let lastHubbardKey = "";
  let hubbardRefreshTimer = null;
  /** Bust navigateur / proxies après « Actualiser · purger le cache ». */
  let apiCacheBust = 0;

  const i18nT = (key, vars) =>
    window.qeI18n && window.qeI18n.t ? window.qeI18n.t(key, vars) : key;

  const { esc, escAttr, safeHref } = window.qeCore || {
    esc: (s) => String(s ?? ""),
    escAttr: (s) => String(s ?? ""),
    safeHref: () => "#",
  };

  function logText(msg) {
    if (msg == null) return "";
    if (typeof msg === "string") return msg;
    if (typeof msg === "object") {
      if (msg.message) return String(msg.message);
      if (msg.error) return String(msg.error);
      if (msg.label) return String(msg.label);
      try {
        return JSON.stringify(msg);
      } catch (_) {
        return String(msg);
      }
    }
    return String(msg);
  }

  function showToast(text, ok) {
    const host = $("ui-toast-host") || document.querySelector(".ui-toast-host");
    if (!host) return;
    const line = String(text || "").split("\n")[0].trim().slice(0, 280);
    if (!line) return;
    const el = document.createElement("div");
    el.className = "ui-toast" + (ok === true ? " ok" : ok === false ? " err" : "");
    el.textContent = line;
    host.appendChild(el);
    setTimeout(() => el.remove(), 4500);
  }

  function log(id, msg, ok) {
    const text = logText(msg);
    const el = $(id);
    if (el) {
      el.textContent = text;
      el.className = (el.className || "").replace(/\bstatus-ok\b|\bstatus-err\b/g, "").trim()
        + (ok === true ? " status-ok" : ok === false ? " status-err" : "");
    }
    showToast(text, ok);
  }

  async function api(path, opts = {}) {
    const headers = Object.assign({}, opts.headers || {});
    const isForm = typeof FormData !== "undefined" && opts.body instanceof FormData;
    if (opts.body && !headers["Content-Type"] && !isForm) {
      headers["Content-Type"] = "application/json";
    }
    if (isForm && headers["Content-Type"]) {
      delete headers["Content-Type"];
    }
    let url = path;
    const method = String(opts.method || "GET").toUpperCase();
    if (method === "GET" && apiCacheBust) {
      url += (url.includes("?") ? "&" : "?") + `_cb=${apiCacheBust}`;
    }
    const res = await fetch(url, Object.assign({}, opts, {
      headers,
      credentials: "same-origin",
      cache: "no-store",
    }));
    const ct = (res.headers.get("content-type") || "").toLowerCase();
    let data = {};
    if (ct.includes("application/json")) {
      data = await res.json().catch(() => ({}));
    } else {
      const text = await res.text().catch(() => "");
      if (!res.ok) throw new Error(text.slice(0, 200) || `HTTP ${res.status}`);
      data = { ok: true, raw: text };
    }
    if (!res.ok) {
      const msg = data.error || data.message || `HTTP ${res.status}`;
      if (res.status === 405) {
        throw new Error(
          `${msg} — relancez ./ARRETER.sh puis ./DEMARRER.sh (routes dopage / phases/doping/generate).`
        );
      }
      throw new Error(msg);
    }
    return data;
  }

  function normalizeMaterialInput(raw) {
    return String(raw || "").trim().replace(/[^\w\-]/g, "");
  }

  function sessionStudyIntent() {
    return ($("session-study-intent")?.value
      || localStorage.getItem("optimqe.sessionIntent")
      || "single");
  }

  /** Cas dopage : endpoints (I→II) | single (un matériau, dopant libre). */
  function sessionDopingCase() {
    const checked = document.querySelector('input[name="session-doping-case"]:checked');
    const fromUi = checked?.value || "";
    const stored = localStorage.getItem("optimqe.dopingCase") || "";
    const v = fromUi || stored || "endpoints";
    return v === "single" ? "single" : "endpoints";
  }

  function setSessionDopingCase(caseId, opts = {}) {
    const v = caseId === "single" ? "single" : "endpoints";
    try {
      localStorage.setItem("optimqe.dopingCase", v);
    } catch (_) {}
    const radio = $(v === "single" ? "doping-case-single" : "doping-case-endpoints");
    if (radio) radio.checked = true;
    document.querySelectorAll(".doping-case-card").forEach((card) => {
      const inp = card.querySelector('input[name="session-doping-case"]');
      card.classList.toggle("is-active", !!(inp && inp.checked));
    });
    if (opts.skipPaint) return;
    paintSessionIntentUI();
    paintPhaseDopingFormCompact();
    paintPrepMatSubpanel(sessionPrepSubTab);
  }

  function isDualStudyIntent() {
    const i = sessionStudyIntent();
    if (i === "sqs") return true;
    /* Dopage cas 1 = deux extrémités I/II ; cas 2 = un seul matériau. */
    if (i === "doping") return sessionDopingCase() === "endpoints";
    return false;
  }

  function getDualMaterialA() {
    const el = $("material-select-a");
    return el ? normalizeMaterialInput(el.value) : "";
  }

  function getDualMaterialB() {
    const el = $("material-select-b");
    return el ? normalizeMaterialInput(el.value) : "";
  }

  function getDraftMaterial() {
    if (isDualStudyIntent()) {
      if (sessionStudyIntent() === "doping") {
        const job = (getPhaseDopingJobMaterial() || "").trim();
        if (job) return normalizeMaterialInput(job);
      }
      const compose = $("session-dual-compose");
      if (compose && !compose.hidden) {
        const finalEl = $("material-final");
        return finalEl ? normalizeMaterialInput(finalEl.value) : "";
      }
      const finalEl = $("material-final");
      if (sessionStudyIntent() === "doping" && finalEl && finalEl.value.trim()) {
        return normalizeMaterialInput(finalEl.value);
      }
      return "";
    }
    const el = $("material-select");
    return el ? normalizeMaterialInput(el.value) : "";
  }

  /** Matériau cible pour CIF / VC-RELAX dans le bloc structure. */
  function structureEditMaterial() {
    if (!isDualStudyIntent()) return getDraftMaterial();
    const t = ($("session-dual-cif-target")?.value || "a").toLowerCase();
    return t === "b" ? getDualMaterialB() : getDualMaterialA();
  }

  function activeJobSelect() {
    if (isDualStudyIntent()) {
      const compose = $("session-dual-compose");
      if (compose && !compose.hidden && $("job-select-dual")) return $("job-select-dual");
    }
    return $("job-select");
  }

  function syncJobSelectMirrors() {
    const primary = $("job-select");
    const mirror = $("job-select-dual");
    if (!primary || !mirror) return;
    mirror.innerHTML = primary.innerHTML;
    mirror.value = primary.value;
    mirror.disabled = primary.disabled;
  }

  function getDraftJob() {
    const sel = activeJobSelect();
    return sel ? sel.value || "" : "";
  }

  function allPhaseSelects() {
    return [...document.querySelectorAll("select.phase-select")];
  }

  /** Phase / job de session (pas la barre de l’onglet Phases). */
  function sessionPhaseSelects() {
    return [ $("session-phase-select"), $("session-phase-select-dual") ].filter(Boolean);
  }

  function refreshTabPhaseBar(phases, chosenVal) {
    const tabSel = document.querySelector(".tab-phase-bar select.phase-select");
    if (!tabSel || !sessionConfirmed) return;
    if (!phases || !phases.length) {
      tabSel.innerHTML = `<option value="">${i18nT("phase.none")}</option>`;
      return;
    }
    tabSel.innerHTML = phases
      .map((ph) => {
        const leg = ph.legacy ? ` (${i18nT("phase.legacy")})` : "";
        const folder = ph.id ? ` (${ph.id})` : "";
        return `<option value="${escAttr(ph.id)}">${esc(ph.label)}${esc(folder)}${esc(leg)}</option>`;
      })
      .join("");
    if (phases.some((p) => p.id === chosenVal)) tabSel.value = chosenVal;
    else if (phases.length) {
      const first = phases.find((p) => !p.legacy) || phases[0];
      tabSel.value = first.id || "";
    }
    tabSel.disabled = false;
  }

  async function fetchCifsForMaterial(mat) {
    const m = String(mat || "").trim();
    if (!m) return [];
    const paths = [
      `/api/materials/${encodeURIComponent(m)}/cifs`,
    ];
    const pid = getDraftPhase() || phaseId;
    if (pid) {
      paths.push(
        `/api/materials/${encodeURIComponent(m)}/cifs?phase_id=${encodeURIComponent(pid)}`
      );
    }
    const seen = new Set();
    const out = [];
    for (const p of paths) {
      try {
        const data = await api(p);
        (data.cifs || []).forEach((c) => {
          const name = c.name || "";
          if (!name || seen.has(name)) return;
          seen.add(name);
          out.push(c);
        });
        if (out.length) break;
      } catch {
        /* try next */
      }
    }
    return out;
  }

  function getDraftPhase() {
    const sel = allPhaseSelects()[0];
    return sel ? sel.value || "" : phaseId || "";
  }

  function activePhaseId() {
    return phaseId || getDraftPhase() || "";
  }

  function syncPhaseSelects(value) {
    const v = value == null ? "" : String(value);
    allPhaseSelects().forEach((sel) => {
      if ([...sel.options].some((o) => o.value === v)) sel.value = v;
      else if (!v && sel.options.length) sel.selectedIndex = 0;
    });
    phaseId = v;
    localStorage.setItem("optimqe.phase", phaseId);
    if (sessionConfirmed && material) {
      refreshOutputFooterPaths().catch(() => {});
    }
    if (isDualStudyIntent()) refreshDualStructureStatuses().catch(() => {});
    else refreshStructureSource(getDraftMaterial()).catch(() => {});
  }

  async function refreshOutputFooterPaths() {
    if (!sessionConfirmed || !material) {
      updateOutputFooter(null);
      return;
    }
    try {
      const data = await api(`/api/materials/${encodeURIComponent(material)}/output-layout${phaseQuery()}`);
      const onResults = document.getElementById("page-resultats")?.classList.contains("active");
      if (onResults && $("res-output-layout-body")) paintOutputLayout(data);
      else updateOutputFooter(data);
    } catch {
      updateOutputFooter(null);
    }
  }

  function phaseQuery(qs = "") {
    return phaseQueryFor(activePhaseId(), qs);
  }

  function phaseQueryFor(pidOverride, qs = "") {
    const base = qs || "";
    const pid = pidOverride || activePhaseId();
    if (!pid) return base;
    const sep = base.includes("?") ? "&" : base ? `${base}?` : "?";
    return `${base}${sep}phase_id=${encodeURIComponent(pid)}`;
  }

  function withPhaseBody(body = {}) {
    const o = { ...body };
    if (o.phase_id == null || String(o.phase_id).trim() === "") {
      const pid = activePhaseId();
      if (pid) o.phase_id = pid;
    }
    return o;
  }

  function updatePhaseSelectState() {
    const draft = getDraftMaterial();
    allPhaseSelects().forEach((sel) => { sel.disabled = !draft; });
    document.querySelectorAll(".btn-new-phase").forEach((btn) => { btn.disabled = !draft; });
  }

  async function refreshPhasesForDraft() {
    const mat = getDraftMaterial();
    const selects = sessionPhaseSelects();
    if (!selects.length) return;
    updatePhaseSelectState();
    if (!mat) {
      selects.forEach((sel) => {
        sel.innerHTML = `<option value="">${i18nT("phase.principal")}</option>`;
      });
      return;
    }
    try {
      const data = await api(`/api/materials/${encodeURIComponent(mat)}/phases`);
      const phases = data.phases || [];
      const prev = phaseId || getDraftPhase();
      let html;
      if (!phases.length) {
        html = `<option value="">${i18nT("phase.none")}</option>`;
      } else {
        html = phases
          .map((ph) => {
            const leg = ph.legacy ? ` (${i18nT("phase.legacy")})` : "";
            const folder = ph.id ? ` (${ph.id})` : "";
            return `<option value="${escAttr(ph.id)}">${esc(ph.label)}${esc(folder)}${esc(leg)}</option>`;
          })
          .join("");
      }
      selects.forEach((sel) => {
        sel.innerHTML = html;
        sel.dataset.nextPhase = data.next_phase_id || "";
      });
      let chosenVal = "";
      if (phases.some((p) => p.id === prev)) chosenVal = prev;
      else if (phases.length) {
        const first = phases.find((p) => !p.legacy) || phases[0];
        chosenVal = first.id || "";
      }
      syncPhaseSelects(chosenVal);
      refreshTabPhaseBar(phases, chosenVal);
      populateSqsPhaseSelects(phases, !!mat);
      syncPhaseDopingMaterials();
      updateDopingActionsEnabled();
      refreshDopingHostElements().catch(() => {});
      const chosen = phases.find((p) => p.id === phaseId) || phases[0];
      const dir = (chosen && chosen.inputs_path) || data.inputs_root || "";
      if (dir) {
        paintNspinStatus({
          ok: true,
          nspin: parseNspinChoice(nspinChoice),
          dir,
          files: [],
        });
      }
      refreshStructureSource(mat).catch(() => {});
      refreshCifList(mat).catch(() => {});
    } catch {
      selects.forEach((sel) => {
        sel.innerHTML = `<option value="">${i18nT("phase.principal")}</option>`;
      });
    }
  }

  async function createNewPhase() {
    const mat = getDraftMaterial();
    if (!mat) {
      alert(i18nT("alert.pick_mat"));
      return;
    }
    let suggested = "phase1";
    try {
      const peek = await api(`/api/materials/${encodeURIComponent(mat)}/phases`);
      if (peek.next_phase_id) suggested = peek.next_phase_id;
    } catch {
      /* ignore */
    }
    const id = prompt(i18nT("phase.prompt.id"), suggested);
    if (!id || !String(id).trim()) return;
    const copyFrom = confirm(i18nT("phase.prompt.copy")) ? getDraftPhase() : "";
    const data = await api(`/api/materials/${encodeURIComponent(mat)}/phases`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phase_id: String(id).trim(), copy_from: copyFrom }),
    });
    if (data.ok === false) {
      alert(data.error || "Erreur");
      return;
    }
    await refreshPhasesForDraft();
    syncPhaseSelects(data.phase_id || "");
    if (sessionConfirmed && getDraftMaterial() === material) {
      await onPhaseChangedKeepSession();
    } else {
      markSessionPending();
    }
    log("log-opt", data.message || i18nT("phase.created"), true);
  }

  async function onPhaseChangedKeepSession() {
    resetAutoResumeScope();
    paintSessionStatus();
    lastHubbardKey = "";
    refreshHubbardPanel({ force: true }).catch(() => {});
    applySpinToInputs({ material, silent: true }).catch(() => {});
    refreshOptimStatus().catch(() => {});
    window.setTimeout(() => tryAutoResumeInterrupted().catch(() => {}), 1500);
    refreshStudyGuide().catch(() => {});
    const tab = localStorage.getItem("optimqe.tab") || "optimisation";
    if (tab === "magnetisme") {
      await refreshMagOrders({ autoPrepare: false, skipExtras: true }).catch(() => {});
    }
    if (tab === "phases") {
      refreshPhaseTypePanel().catch(() => {});
      refreshPhaseStability().catch(() => {});
    }
    if (tab === "proprietes") refreshProprietesPage().catch(() => {});
    if (tab === "resultats") refreshResults().catch(() => {});
  }

  function draftsMatchSession() {
    return (
      sessionConfirmed
      && getDraftMaterial() === material
      && getDraftJob() === jobId
      && getDraftPhase() === (phaseId || "")
    );
  }

  /** Réaligne les listes matériau / phase / job sur la session active (après F5 ou redémarrage API). */
  function reconcileSessionDrafts() {
    if (!sessionConfirmed || !material) return false;
    const matSel = $("material-select");
    if (matSel && normalizeMaterialInput(matSel.value) !== material) {
      matSel.value = material;
    }
    const finalEl = $("material-final");
    if (finalEl && isDualStudyIntent() && normalizeMaterialInput(finalEl.value) !== material) {
      finalEl.value = material;
    }
    if (phaseId) syncPhaseSelects(phaseId);
    const sel = $("job-select");
    if (sel && jobId && sel.value !== jobId) {
      if ([...sel.options].some((o) => o.value === jobId)) sel.value = jobId;
      else {
        const opt = document.createElement("option");
        opt.value = jobId;
        opt.textContent = jobId;
        sel.appendChild(opt);
        sel.value = jobId;
      }
    }
    const dp = getDraftPhase();
    if (dp && dp !== phaseId) phaseId = dp;
    return draftsMatchSession();
  }

  function magGeoUsable(geo) {
    geo = geo || {};
    return !!(geo.ready || geo.scf_input_exists || geo.cell_input_exists || geo.scf_converged);
  }

  function magRunBlockedReason(order) {
    if (!sessionConfirmed || !material) return i18nT("alert.confirm_session");
    if (!draftsMatchSession()) return i18nT("alert.session_draft_mismatch");
    const data = lastMagOrders;
    const geo = (data && data.geometry) || {};
    if (!magGeoUsable(geo)) return i18nT("mag.block.no_nm_scf");
    const rows = (data && data.orders) || [];
    const r = rows.find((x) => x.order === order) || {};
    if (r.running || r.nscf_running) return i18nT("mag.block.running");
    const steps = r.steps || {};
    if (Object.values(steps).some((s) => s && s.running)) return i18nT("mag.block.running");
    if ((r.chain_resume || {}).all_done) return i18nT("mag.block.done");
    if (!magOrderInputsPrepared(r)) {
      return i18nT("mag.banner.need_gen");
    }
    if (!isMagInputsVerified(order)) return i18nT("session.mag.need_verify");
    return "";
  }

  const magInputsVerifiedKeys = new Set();

  function magInputsVerifyKey(order) {
    return `${material || ""}|${phaseId || ""}|${String(order || "").toLowerCase()}`;
  }

  function isMagInputsVerified(order) {
    return magInputsVerifiedKeys.has(magInputsVerifyKey(order));
  }

  function markMagInputsVerified(order) {
    if (!order) return;
    magInputsVerifiedKeys.add(magInputsVerifyKey(order));
  }

  function clearMagInputsVerified(order) {
    if (order) magInputsVerifiedKeys.delete(magInputsVerifyKey(order));
    else magInputsVerifiedKeys.clear();
  }

  function magOrderRowFromLast(order) {
    const rows = (lastMagOrders && lastMagOrders.orders) || [];
    return rows.find((r) => r.order === order) || null;
  }

  function magOrderInputsPrepared(row) {
    if (!row) return false;
    if (row.input_exists) return true;
    const steps = row.steps || {};
    const vc = steps["vc-relax"];
    return !!(vc && (vc.input_exists || vc.output_exists));
  }

  function qeSystemBlock(content) {
    const m = String(content || "").match(/&SYSTEM([\s\S]*?)\//i);
    return m ? m[1] : String(content || "");
  }

  function parseQeBoolParam(raw) {
    const v = String(raw || "").trim().toLowerCase().replace(/\./g, "");
    if (v === "true" || v === "t") return true;
    if (v === "false" || v === "f") return false;
    return null;
  }

  function parseNspinFromQeInput(content) {
    const block = qeSystemBlock(content);
    const m = block.match(/^\s*nspin\s*=\s*(\d+)/im) || block.match(/nspin\s*=\s*(\d+)/i);
    return m ? Number(m[1]) : null;
  }

  function parseNoncolinFromQeInput(content) {
    const block = qeSystemBlock(content);
    const m = block.match(/noncolin\s*=\s*(\.?true\.?|\.?false\.?|true|false)/i);
    return m ? parseQeBoolParam(m[1]) : null;
  }

  function expectedMagQeParams(order) {
    const o = String(order || "nm").trim().toLowerCase();
    if (o === "ncl") return { nspin: 4, noncolin: true };
    if (o === "nm") return { nspin: 1, noncolin: false };
    return { nspin: 2, noncolin: false };
  }

  function headerMatchesMagOrder(head, order) {
    const o = String(order || "").trim().toLowerCase();
    const up = String(head || "").slice(0, 1200).toUpperCase();
    if (o === "fm") return up.includes("FM") || up.includes("FERROMAGN");
    if (o === "ncl") return up.includes("NCL") || up.includes("NON COLIN") || up.includes("NONCOLIN");
    if (o.startsWith("afm-")) {
      const sub = o.split("-")[1].toUpperCase();
      return up.includes(`AFM-${sub}`) || up.includes("ANTIFERRO");
    }
    return true;
  }

  function parseAtomicSpecies(content) {
    const m = String(content || "").match(
      /ATOMIC_SPECIES\s*([\s\S]*?)(?=ATOMIC_POSITIONS|CELL_PARAMETERS|K_POINTS|\Z)/i
    );
    if (!m) return [];
    const out = [];
    for (const line of m[1].split("\n")) {
      const t = line.split("!")[0].trim();
      if (!t) continue;
      const parts = t.split(/\s+/);
      if (parts[0]) out.push(parts[0]);
    }
    return out;
  }

  function countAtomicPositions(content) {
    const m = String(content || "").match(
      /ATOMIC_POSITIONS\s+\S+\s*([\s\S]*?)(?=CELL_PARAMETERS|K_POINTS|\Z)/i
    );
    if (!m) return {};
    const counts = {};
    for (const line of m[1].split("\n")) {
      const t = line.split("!")[0].trim();
      if (!t) continue;
      const parts = t.split(/\s+/);
      if (parts.length >= 4) counts[parts[0]] = (counts[parts[0]] || 0) + 1;
    }
    return counts;
  }

  function parseStartingMags(block) {
    const out = {};
    const re = /starting_magnetization\s*\(\s*(\d+)\s*\)\s*=\s*([-+]?\d*\.?\d+(?:[dD][+-]?\d+)?)/gi;
    let mm;
    while ((mm = re.exec(block))) {
      const idx = Number(mm[1]);
      const raw = mm[2].replace(/d/gi, "E");
      const v = Number(raw);
      if (!Number.isNaN(v)) out[idx] = v;
    }
    return out;
  }

  function afmModeFromOrder(order) {
    const o = String(order || "").trim().toLowerCase();
    return { "afm-g": "g", "afm-a": "a", "afm-b": "b", "afm-c": "c" }[o] || "g";
  }

  function elementBaseSymbol(sym) {
    const m = String(sym || "").match(/^([A-Za-z]+)/);
    return m ? m[1] : String(sym || "");
  }

  function afmSignAtSite(x, y, z, mode) {
    const m = mode || "g";
    if (m === "g") {
      const ix = Math.round(2 * x) % 2;
      const iy = Math.round(2 * y) % 2;
      const iz = Math.round(2 * z) % 2;
      return (ix + iy + iz) % 2 === 0 ? 1 : -1;
    }
    if (m === "a") return z < 0.5 - 1e-8 ? 1 : -1;
    if (m === "b") return y < 0.5 - 1e-8 ? 1 : -1;
    if (m === "c") return x < 0.5 - 1e-8 ? 1 : -1;
    return 1;
  }

  function parsePositionLines(content) {
    const m = String(content || "").match(
      /ATOMIC_POSITIONS\s+\S+\s*([\s\S]*?)(?=CELL_PARAMETERS|K_POINTS|\Z)/i
    );
    if (!m) return [];
    const out = [];
    for (const line of m[1].split("\n")) {
      const t = line.split("!")[0].trim();
      if (!t) continue;
      const parts = t.split(/\s+/);
      if (parts.length < 4) continue;
      const x = Number(parts[1]);
      const y = Number(parts[2]);
      const z = Number(parts[3]);
      if ([x, y, z].some((v) => Number.isNaN(v))) continue;
      out.push({ lab: parts[0], pos: [x, y, z] });
    }
    return out;
  }

  function magneticElementCarriesMoment(base) {
    const b = String(base || "").toUpperCase();
    return !["O", "N", "C", "H", "F", "CL", "BR", "I", "S", "P"].includes(b);
  }

  function afmSiteSigns(positions, mode) {
    const signs = positions.map((p) => {
      const base = elementBaseSymbol(p.lab);
      if (!magneticElementCarriesMoment(base)) return 0;
      return afmSignAtSite(p.pos[0], p.pos[1], p.pos[2], mode);
    });
    const mag = signs.filter((s) => s);
    if (mag.length >= 2 && mag.every((s) => s === mag[0])) {
      let flip = false;
      for (let i = 0; i < signs.length; i++) {
        if (!signs[i]) continue;
        signs[i] = flip ? -1 : 1;
        flip = !flip;
      }
    }
    return signs;
  }

  function afmSpeciesLabels(base) {
    const b = String(base || "X");
    if (b.length <= 2) return [`${b}1`, `${b}2`];
    return [`${b.slice(0, 2)}1`, `${b.slice(0, 2)}2`];
  }

  function expectedAfmLabel(base, sign, splits) {
    if (!sign) return base;
    if (!splits[base]) return base;
    const [up, dn] = afmSpeciesLabels(base);
    return sign > 0 ? up : dn;
  }

  function auditAfmPattern(content, order) {
    const o = String(order || "").trim().toLowerCase();
    if (!o.startsWith("afm-")) return [];
    const positions = parsePositionLines(content);
    if (positions.length < 2) return [i18nT("mag.audit.issue.afm_positions")];
    const mode = afmModeFromOrder(o);
    const signs = afmSiteSigns(positions, mode);
    const mag = signs.filter((s) => s);
    if (mag.length < 2) return [i18nT("mag.audit.issue.afm_few_sites")];
    if (mag.every((s) => s === mag[0])) return [i18nT("mag.audit.issue.afm_uniform")];
    const baseSigns = {};
    positions.forEach((p, i) => {
      if (!signs[i]) return;
      const base = elementBaseSymbol(p.lab);
      if (!baseSigns[base]) baseSigns[base] = new Set();
      baseSigns[base].add(signs[i]);
    });
    const splits = {};
    Object.keys(baseSigns).forEach((b) => {
      splits[b] = baseSigns[b].size > 1;
    });
    const issues = [];
    positions.forEach((p, i) => {
      const base = elementBaseSymbol(p.lab);
      const exp = expectedAfmLabel(base, signs[i], splits);
      if (p.lab !== exp) {
        issues.push(
          i18nT("mag.audit.issue.afm_label", {
            n: String(i + 1),
            base,
            found: p.lab,
            expected: exp,
            order: sessionMagOrderShort(o),
          })
        );
      }
    });
    return issues.slice(0, 10);
  }

  function auditFmPattern(content) {
    const species = parseAtomicSpecies(content);
    const issues = [];
    species.forEach((sym) => {
      if (/^[A-Za-z]+[12]$/.test(sym) && magneticElementCarriesMoment(elementBaseSymbol(sym))) {
        issues.push(i18nT("mag.audit.issue.fm_split_species", { sym }));
      }
    });
    const mags = parseStartingMags(qeSystemBlock(content));
    const nonzero = Object.values(mags).filter((v) => Math.abs(v) > 1e-9);
    if (nonzero.length >= 2 && nonzero.some((v) => v * nonzero[0] < 0)) {
      issues.push(i18nT("mag.audit.issue.fm_parallel"));
    }
    return issues;
  }

  function auditAfmSublattice(content, order) {
    const o = String(order || "").trim().toLowerCase();
    if (!o.startsWith("afm-")) return [];
    const issues = [];
    const species = parseAtomicSpecies(content);
    const posCounts = countAtomicPositions(content);
    const block = qeSystemBlock(content);
    const nosymM = block.match(/nosym\s*=\s*(\.?true\.?|\.?false\.?|true|false)/i);
    if (parseQeBoolParam(nosymM && nosymM[1]) !== true) {
      issues.push(i18nT("mag.audit.issue.afm_nosym"));
    }
    const mags = parseStartingMags(block);
    const bases = {};
    for (const sym of species) {
      const m = sym.match(/^([A-Za-z]+)([12])$/);
      if (m) {
        if (!bases[m[1]]) bases[m[1]] = new Set();
        bases[m[1]].add(m[2]);
      }
    }
    const isOxygen = (sym) => /^O\d*$/i.test(sym) || sym.toUpperCase() === "O";
    for (const sym of species) {
      if (isOxygen(sym)) continue;
      if (!(posCounts[sym] > 0)) {
        issues.push(i18nT("mag.audit.issue.afm_species_unused", { sym }));
      }
    }
    const speciesSet = new Set(species);
    for (const base of Object.keys(bases)) {
      const suffixes = bases[base];
      if (!suffixes.has("1") || !suffixes.has("2")) continue;
      const s1 = `${base}1`;
      const s2 = `${base}2`;
      if (!speciesSet.has(s1) || !speciesSet.has(s2)) continue;
      const n1 = posCounts[s1] || 0;
      const n2 = posCounts[s2] || 0;
      if (n1 === 0 || n2 === 0) {
        issues.push(i18nT("mag.audit.issue.afm_pair_missing", { base, s1, n1: String(n1), s2, n2: String(n2) }));
      }
      const i1 = species.indexOf(s1) + 1;
      const i2 = species.indexOf(s2) + 1;
      if (i1 > 0 && i2 > 0 && mags[i1] != null && mags[i2] != null) {
        if (Math.abs(mags[i1]) > 1e-9 && Math.abs(mags[i2]) > 1e-9 && mags[i1] * mags[i2] >= 0) {
          issues.push(i18nT("mag.audit.issue.afm_mag_opposite", { base, i1: String(i1), i2: String(i2) }));
        }
      }
    }
    return issues;
  }

  function cellAxisLengthsAngstrom(content) {
    const m = String(content || "").match(
      /CELL_PARAMETERS\s*\n([\s\S]*?)(?=K_POINTS|\Z)/i
    );
    if (!m) return null;
    const vecs = [];
    for (const line of m[1].split("\n")) {
      const t = line.split("!")[0].trim();
      if (!t || /^[A-Za-z]/.test(t)) break;
      const parts = t.split(/\s+/);
      if (parts.length < 3) break;
      const v = parts.slice(0, 3).map((x) => Number(x.replace(/[dD]/g, "e")));
      if (v.some((n) => Number.isNaN(n))) break;
      vecs.push(v);
      if (vecs.length === 3) break;
    }
    if (vecs.length !== 3) return null;
    return vecs.map((v) => Math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2));
  }

  function parseNatFromQe(content) {
    const m = String(content || "").match(/^\s*nat\s*=\s*(\d+)/im);
    return m ? Number(m[1]) : null;
  }

  function auditAfmSupercell(content, order, nmContent) {
    const o = String(order || "").trim().toLowerCase();
    if (o === "afm-g" || !o.startsWith("afm-") || !nmContent) return [];
    const axis = { "afm-a": 2, "afm-b": 1, "afm-c": 2 }[o];
    if (axis == null) return [];
    const issues = [];
    const nat = parseNatFromQe(content);
    const nPos = parsePositionLines(content).length;
    const natEff = nat != null ? nat : nPos;
    const natNm = parseNatFromQe(nmContent);
    const nPosNm = parsePositionLines(nmContent).length;
    const refNat = natNm != null ? natNm : nPosNm;
    if (refNat > 0 && natEff < refNat * 2 - 2) {
      issues.push(
        i18nT("mag.audit.issue.afm_supercell_nat", {
          order: sessionMagOrderShort(o),
          nat: String(natEff),
          expected: String(refNat * 2),
          ref: String(refNat),
        })
      );
    }
    const lens = cellAxisLengthsAngstrom(content);
    const lens0 = cellAxisLengthsAngstrom(nmContent);
    if (lens && lens0 && lens0[axis] > 1e-6) {
      const ratio = lens[axis] / lens0[axis];
      if (ratio < 1.75) {
        const ax = ["x", "y", "z"][axis];
        issues.push(
          i18nT("mag.audit.issue.afm_supercell_axis", {
            order: sessionMagOrderShort(o),
            axis: ax,
            len: lens[axis].toFixed(4),
            lenNm: lens0[axis].toFixed(4),
            ratio: ratio.toFixed(2),
          })
        );
      }
    }
    return issues;
  }

  let cachedNmInputTextForAudit = null;
  let cachedNmInputTextMat = "";

  async function nmInputTextForMagAudit(mat) {
    const m = String(mat || "").trim();
    if (!m) return "";
    if (cachedNmInputTextForAudit && cachedNmInputTextMat === m) return cachedNmInputTextForAudit;
    try {
      const data = await api(`/api/materials/${encodeURIComponent(m)}/nm-inputs${phaseQuery()}`);
      const scf = (data.inputs || []).find((x) => x.kind === "scf");
      const rel = scf && (scf.rel_path || `materiaux/${m}/${m}-scf.in`);
      if (rel) {
        const t = await fetch(`/inputs/${rel.replace(/^\//, "")}`).then((r) => (r.ok ? r.text() : ""));
        if (t) {
          cachedNmInputTextForAudit = t;
          cachedNmInputTextMat = m;
          return t;
        }
      }
    } catch (_) {
      /* ignore */
    }
    return "";
  }

  function auditMagInputForOrder(content, order, nmContent) {
    const o = String(order || "nm").trim().toLowerCase();
    const exp = expectedMagQeParams(o);
    const issues = [];
    const found = parseNspinFromQeInput(content);
    const noncolin = parseNoncolinFromQeInput(content);
    const head = String(content || "").slice(0, 1500);
    if (found == null) issues.push(i18nT("mag.audit.issue.nspin_missing", { expected: String(exp.nspin) }));
    else if (found !== exp.nspin) {
      issues.push(i18nT("mag.audit.issue.nspin_bad", { found: String(found), expected: String(exp.nspin) }));
    }
    if (exp.noncolin) {
      if (noncolin !== true) issues.push(i18nT("mag.audit.issue.noncolin_true"));
    } else if (noncolin === true) {
      issues.push(i18nT("mag.audit.issue.noncolin_false"));
    }
    if (head.includes("OPTQE-MAG") && !headerMatchesMagOrder(head, o)) {
      issues.push(i18nT("mag.audit.issue.header", { order: sessionMagOrderShort(o) }));
    }
    issues.push(...auditAfmSublattice(content, o));
    if (o.startsWith("afm-")) {
      issues.push(...auditAfmSupercell(content, o, nmContent || ""));
      issues.push(...auditAfmPattern(content, o));
    } else if (o === "fm") issues.push(...auditFmPattern(content));
    const ok = !issues.length;
    const message = ok
      ? i18nT("mag.nspin.audit.ok", { nspin: String(found != null ? found : exp.nspin) })
      : issues.join(" · ");
    return { ok, expected: exp.nspin, found, issues, message, noncolin };
  }

  function auditMagInputNspin(content, order) {
    return auditMagInputForOrder(content, order);
  }

  let lastMagOrderAudit = null;
  let magOrderAuditSeq = 0;

  async function fetchMagOrderChainAudit(order) {
    const mat = String(material || resolveSessionStructureMaterial() || "").trim();
    const o = String(order || "").trim().toLowerCase();
    if (!mat || !o || o === "nm") return { ok: false, skipped: true, order: o };
    try {
      return await api(
        `/api/materials/${encodeURIComponent(mat)}/mag-orders/${encodeURIComponent(o)}/audit${phaseQuery()}`
      );
    } catch (e) {
      return { ok: false, order: o, error: e.message || String(e), steps: [] };
    }
  }

  async function fetchAllMagOrdersAudit(orders) {
    const mat = String(material || resolveSessionStructureMaterial() || "").trim();
    if (!mat) return { ok: false, orders: [] };
    const q = phaseQuery();
    const list = (orders || []).map((x) => String(x).trim().toLowerCase()).filter((x) => x && x !== "nm");
    const extra = list.length ? `${q ? "&" : "?"}orders=${encodeURIComponent(list.join(","))}` : q;
    try {
      return await api(`/api/materials/${encodeURIComponent(mat)}/mag-orders/audit-all${q}${extra}`);
    } catch (e) {
      return { ok: false, error: e.message, orders: [] };
    }
  }

  function formatMagChainAuditHtml(audit) {
    if (!audit || audit.skipped) return "";
    const steps = audit.steps || [];
    if (!steps.length) {
      return `<p class="meta warn">${esc(i18nT("mag.audit.no_files"))}</p>`;
    }
    const lines = steps.map((st) => {
      const lab = String(st.kind || "").toUpperCase();
      if (!st.exists) return `<li class="mag-audit-fail">${esc(lab)} — ${esc(i18nT("mag.audit.missing_file"))}</li>`;
      if (st.ok) return `<li class="mag-audit-ok">${esc(lab)} ✓ · nspin=${esc(String(st.nspin ?? "—"))}</li>`;
      const iss = (st.issues || []).join("; ");
      return `<li class="mag-audit-fail">${esc(lab)} ✗ — ${esc(iss)}</li>`;
    });
    return `<ul class="phases-mag-audit-list">${lines.join("")}</ul>`;
  }

  function applyMagOrderAuditToUi(order, audit) {
    lastMagOrderAudit = audit && !audit.skipped ? { order, ...audit } : lastMagOrderAudit;
    const detail = $("phases-mag-audit-detail");
    const verifyCb = $("phases-mag-inputs-verified");
    const verifyHint = $("phases-mag-verify-hint");
    const lab = sessionMagOrderShort(order);
    const ns = nspinForMagOrder(order);
    if (detail) {
      if (!audit || audit.skipped) {
        detail.innerHTML = "";
        detail.hidden = true;
      } else {
        detail.hidden = false;
        const sum = audit.ok
          ? i18nT("mag.audit.chain_ok", { order: lab })
          : i18nT("mag.audit.chain_fail", { order: lab });
        detail.innerHTML = `<p class="meta${audit.ok ? " status-ok" : " warn"}">${esc(sum)}</p>${formatMagChainAuditHtml(audit)}`;
      }
    }
    if (audit && audit.ok) {
      markMagInputsVerified(order);
      if (verifyCb) {
        verifyCb.checked = true;
        verifyCb.disabled = false;
      }
      if (verifyHint) {
        verifyHint.textContent = i18nT("phases.mag.verify_ok", { order: lab });
        verifyHint.className = "meta phases-mag-verify-hint status-ok";
      }
    } else if (audit && !audit.skipped) {
      clearMagInputsVerified(order);
      if (verifyCb) {
        verifyCb.checked = false;
        verifyCb.disabled = false;
      }
      if (verifyHint) {
        verifyHint.textContent = i18nT("phases.mag.verify_audit_fail", { order: lab, nspin: String(ns) });
        verifyHint.className = "meta phases-mag-verify-hint warn";
      }
    }
    const runBtn = document.querySelector(`#phases-active-mag-chain .btn-mag-run, .mag-case-row[data-order="${CSS.escape(order)}"] .btn-mag-run`);
    if (runBtn && audit && !audit.skipped) {
      const row = magOrderRowFromLast(order);
      const inputsReady = magOrderInputsPrepared(row);
      const verified = isMagInputsVerified(order);
      const anyRun = row && magRowAnyRunning(row);
      const canRun = sessionConfirmed && material && draftsMatchSession();
      const magOpen = canRun && magGeoUsable((lastMagOrders && lastMagOrders.geometry) || {});
      runBtn.disabled = !magOpen || anyRun || !inputsReady || !verified;
    }
  }

  async function refreshMagOrderInputAudit(order) {
    const o = String(order || getSessionMagOrder()).trim().toLowerCase();
    if (!o || o === "nm") return null;
    const seq = ++magOrderAuditSeq;
    const audit = await fetchMagOrderChainAudit(o);
    if (seq !== magOrderAuditSeq) return audit;
    applyMagOrderAuditToUi(o, audit);
    return audit;
  }

  function paintOptimModalNspinAudit(content, order) {
    const el = $("optim-modal-nspin-audit");
    if (!el) return;
    if (!magEditOrder || !order) {
      el.hidden = true;
      el.textContent = "";
      el.className = "meta optim-modal-nspin-audit";
      return;
    }
    const audit = auditMagInputNspin(content, order);
    el.hidden = false;
    el.textContent = audit.message;
    el.className = `meta optim-modal-nspin-audit${audit.ok ? " status-ok" : " warn"}`;
  }

  function magPipeStepState(steps, sk) {
    const s = (steps && steps[sk]) || {};
    if (s.running || s.run_phase === "running") {
      return { cls: "run", icon: "…", lab: i18nT("state.running") };
    }
    if (s.scf_converged || stepConverged(s)) {
      return { cls: "ok", icon: "✓", lab: i18nT("state.converged") };
    }
    if (s.run_phase === "failed") {
      return { cls: "fail", icon: "✗", lab: i18nT("state.failed") || "échec" };
    }
    if (s.run_phase === "stopped") {
      return { cls: "fail", icon: "✗", lab: i18nT("state.stopped") };
    }
    if (s.output_exists) return { cls: "partial", icon: "◐", lab: i18nT("mag.pipe.partial") };
    if (s.input_exists) return { cls: "ready", icon: "○", lab: i18nT("mag.case.ready") };
    return { cls: "idle", icon: "—", lab: "—" };
  }

  function buildMagPipelineOlHtml(r, editDis, failKind) {
    const steps = r.steps || {};
    const kinds = [
      { id: "vc-relax", label: "VC-RELAX" },
      { id: "relax", label: "RELAX" },
      { id: "scf", label: "SCF" },
    ];
    const ordLab = (r.short || r.order || "").replace(/^afm-/i, "AFM-").toUpperCase();
    const nscfSt = r.nscf_running
      ? { cls: "run", icon: "…", lab: i18nT("state.running") }
      : r.nscf_converged
        ? { cls: "ok", icon: "✓", lab: i18nT("state.converged") }
        : r.scf_converged || r.needs_nscf
          ? { cls: "ready", icon: "○", lab: i18nT("mag.pipe.nscf_pending", { order: ordLab }) }
          : { cls: "idle", icon: "—", lab: "—" };
    const pipeActive = magPipeActiveKind(r);
    const cells = kinds.map((k, i) => {
      let stepData = steps[k.id] || {};
      let st = magPipeStepState(steps, k.id);
      let runCls = stepData.running || stepData.run_phase === "running" ? " is-run" : "";
      if (pipeActive && k.id !== pipeActive && runCls) {
        runCls = "";
        stepData = { ...stepData, running: false };
        if (stepData.converged || stepData.scf_converged) {
          st = { cls: "ok", icon: "✓", lab: i18nT("state.converged") };
        } else if (stepData.output_exists) {
          st = { cls: "partial", icon: "◐", lab: i18nT("mag.pipe.partial") };
        } else {
          st = { cls: "idle", icon: "—", lab: "—" };
        }
      }
      const metricsSub = nmStepMetricsLine(stepData, k.id);
      const failCls = failKind === k.id ? " is-fail is-focus" : "";
      return `<li class="mag-pipe-step is-${st.cls}${failCls}${runCls}" data-kind="${k.id}">
        <div class="mag-pipe-head">
          <span class="mag-pipe-num">${i + 1}</span>
          <strong class="mag-pipe-label">${k.label}</strong>
          <span class="mag-pipe-icon" title="${escAttr(st.lab)}">${st.icon}</span>
        </div>
        <span class="mag-pipe-state">${esc(st.lab)}</span>
        ${metricsSub ? `<span class="mag-pipe-metrics run-metrics">${esc(metricsSub)}</span>` : ""}
        ${stepData.percent != null && (stepData.running || stepData.run_phase === "running")
          ? `<div class="run-meter run-meter-compact"><div class="run-meter-fill" style="width:${Math.min(100, stepData.percent)}%"></div></div>`
          : ""}
        <button type="button" class="btn ghost btn-mag-edit" data-order="${escAttr(r.order)}" data-kind="${k.id}" ${editDis} title="${escAttr(i18nT("mag.edit.step", { kind: k.label }))}">${i18nT("btn.edit")}</button>
      </li>
      <li class="mag-pipe-arrow" aria-hidden="true">→</li>`;
    }).join("");
    const nscfStep = steps.nscf || {};
    const nscfRun = !!(r.nscf_running || nscfStep.running || nscfStep.run_phase === "running");
    const nscfLive = nscfRun ? { ...nscfStep, running: true } : nscfStep;
    const nscfMetrics = nmStepMetricsLine(nscfLive, "nscf");
    return `<ol class="mag-pipeline" aria-label="${escAttr(i18nT("mag.chain.title"))}">
      ${cells}
      <li class="mag-pipe-step is-${nscfSt.cls}${nscfRun ? " is-run" : ""}" data-kind="nscf">
        <div class="mag-pipe-head">
          <span class="mag-pipe-num">4</span>
          <strong class="mag-pipe-label">NSCF ${esc(ordLab)}</strong>
          <span class="mag-pipe-icon" title="${escAttr(nscfSt.lab)}">${nscfSt.icon}</span>
        </div>
        <span class="mag-pipe-state">${esc(nscfSt.lab)}</span>
        ${nscfMetrics ? `<span class="mag-pipe-metrics run-metrics">${esc(nscfMetrics)}</span>` : ""}
        ${nscfLive.percent != null && nscfRun
          ? `<div class="run-meter run-meter-compact"><div class="run-meter-fill" style="width:${Math.min(100, nscfLive.percent)}%"></div></div>`
          : ""}
        <button type="button" class="btn ghost btn-mag-edit" data-order="${escAttr(r.order)}" data-kind="nscf" ${editDis} title="${escAttr(i18nT("mag.edit.step", { kind: "NSCF" }))}">${i18nT("btn.edit")}</button>
        <span class="mag-pipe-note">${esc(i18nT("mag.pipe.nscf_auto"))}</span>
      </li>
    </ol>`;
  }

  /** Pipeline VC-RELAX → RELAX → SCF pour une phase cristalline (onglet Phase). */
  function buildPhaseChainPipelineOl(row, failKind) {
    const steps = row.chain_steps || {};
    const kinds = [
      { id: "vc-relax", label: "VC-RELAX" },
      { id: "relax", label: "RELAX" },
      { id: "scf", label: "SCF" },
    ];
    const pipeActive = phaseChainPollKind(row);
    const pid = row.phase_id || "";
    const stLab = row.structure_label || row.label || pid || i18nT("phase.principal");
    const cells = kinds.map((k, i) => {
      let stepData = steps[k.id] || {};
      let st = nmStepState(stepData);
      let runCls = stepData.running || stepData.run_phase === "running" ? " is-run" : "";
      if (pipeActive && k.id !== pipeActive && runCls) {
        runCls = "";
        stepData = { ...stepData, running: false };
        st = nmStepState(stepData);
      }
      const metricsSub = nmStepMetricsLine(stepData, k.id);
      const failCls = failKind === k.id ? " is-fail is-focus" : "";
      return `<li class="mag-pipe-step is-${st.cls}${failCls}${runCls}" data-kind="${k.id}">
        <div class="mag-pipe-head">
          <span class="mag-pipe-num">${i + 1}</span>
          <strong class="mag-pipe-label">${k.label}</strong>
          <span class="mag-pipe-icon" title="${escAttr(st.lab)}">${st.icon}</span>
        </div>
        <span class="mag-pipe-state">${esc(st.lab)}</span>
        ${metricsSub ? `<span class="mag-pipe-metrics run-metrics">${esc(metricsSub)}</span>` : ""}
        ${stepData.percent != null && (stepData.running || stepData.run_phase === "running")
          ? `<div class="run-meter run-meter-compact"><div class="run-meter-fill" style="width:${Math.min(100, stepData.percent)}%"></div></div>`
          : ""}
      </li>
      <li class="mag-pipe-arrow" aria-hidden="true">→</li>`;
    }).join("");
    return `<p class="meta phase-pipe-title">${esc(stLab)} · <code>${esc(pid || "—")}</code></p>
      <ol class="mag-pipeline phase-struct-pipeline" data-phase-id="${escAttr(pid)}" aria-label="${escAttr(i18nT("phase.chain.pipeline.aria"))}">
      ${cells}
    </ol>`;
  }

  function canonicalMagSpinSites(order) {
    const o = String(order || "").toLowerCase();
    if (o === "fm") {
      return [
        { sym: "M", pos: [0.25, 0.25, 0], spin: 1 },
        { sym: "M", pos: [0.75, 0.25, 0], spin: 1 },
        { sym: "M", pos: [0.25, 0.75, 0], spin: 1 },
        { sym: "M", pos: [0.75, 0.75, 0], spin: 1 },
      ];
    }
    if (o === "afm-g") {
      return [
        { sym: "M", pos: [0.25, 0.25, 0], spin: 1 },
        { sym: "M", pos: [0.75, 0.75, 0], spin: -1 },
        { sym: "M", pos: [0.75, 0.25, 0], spin: -1 },
        { sym: "M", pos: [0.25, 0.75, 0], spin: 1 },
      ];
    }
    if (o === "afm-a") {
      return [
        { sym: "M", pos: [0.28, 0.5, 0.12], spin: 1 },
        { sym: "M", pos: [0.72, 0.5, 0.12], spin: 1 },
        { sym: "M", pos: [0.28, 0.5, 0.62], spin: -1 },
        { sym: "M", pos: [0.72, 0.5, 0.62], spin: -1 },
      ];
    }
    if (o === "afm-b") {
      return [
        { sym: "M", pos: [0.5, 0.22, 0.25], spin: 1 },
        { sym: "M", pos: [0.5, 0.78, 0.25], spin: -1 },
        { sym: "M", pos: [0.5, 0.22, 0.75], spin: 1 },
        { sym: "M", pos: [0.5, 0.78, 0.75], spin: -1 },
      ];
    }
    if (o === "afm-c") {
      return [
        { sym: "M", pos: [0.22, 0.5, 0.25], spin: 1 },
        { sym: "M", pos: [0.78, 0.5, 0.25], spin: -1 },
        { sym: "M", pos: [0.22, 0.5, 0.75], spin: 1 },
        { sym: "M", pos: [0.78, 0.5, 0.75], spin: -1 },
      ];
    }
    if (o === "ncl") return [{ sym: "M", pos: [0.5, 0.5, 0.5], spin: 1, ncl: true }];
    return [];
  }

  function magSpinSitesForFigure(order, row) {
    const sites = (row && row.spin_sites) || [];
    if (sites.length) {
      const magnetic = sites.filter((s) => Number(s.spin || 0) !== 0);
      const use = magnetic.length ? magnetic : sites;
      if (use.length <= 32) return sites;
      return magnetic.length ? magnetic : sites.slice(0, 32);
    }
    return canonicalMagSpinSites(order);
  }

  function magSpinSitePlane(sites) {
    const pts = sites.map((s) => s.pos || [0, 0, 0]);
    if (!pts.length) return "xy";
    const span = (idx) => {
      const vals = pts.map((p) => Number(p[idx] || 0));
      return Math.max(...vals) - Math.min(...vals);
    };
    const sx = span(0);
    const sy = span(1);
    const sz = span(2);
    if (sy < 0.07 && sz >= sy) return "xz";
    if (sz < 0.07 && sy >= sz) return "xy";
    if (sz > sy + 0.05) return "xz";
    return "xy";
  }

  function magSpinArrowMark(cx, cy, sign, size) {
    const sz = size || 11;
    const cxF = Number(cx).toFixed(1);
    const cyF = Number(cy).toFixed(1);
    if (!sign) {
      return `<circle class="mag-spin-dot" cx="${cxF}" cy="${cyF}" r="2.4"/>`;
    }
    const up = sign > 0;
    const cls = up ? "mag-spin-up" : "mag-spin-down";
    const y1 = cy + (up ? sz * 0.32 : -sz * 0.32);
    const y2 = cy + (up ? -sz * 0.58 : sz * 0.58);
    const head = up
      ? `${cxF},${y2.toFixed(1)} ${(cx - 3.2).toFixed(1)},${(y2 + 4.8).toFixed(1)} ${(cx + 3.2).toFixed(1)},${(y2 + 4.8).toFixed(1)}`
      : `${cxF},${y2.toFixed(1)} ${(cx - 3.2).toFixed(1)},${(y2 - 4.8).toFixed(1)} ${(cx + 3.2).toFixed(1)},${(y2 - 4.8).toFixed(1)}`;
    return (
      `<g class="mag-spin-arrow ${cls}">` +
      `<circle class="mag-spin-site" cx="${cxF}" cy="${cyF}" r="3.2"/>` +
      `<line x1="${cxF}" y1="${y1.toFixed(1)}" x2="${cxF}" y2="${y2.toFixed(1)}"/>` +
      `<polygon points="${head}"/></g>`
    );
  }

  function magNclFigureMarks(cx, cy, len) {
    const L = len || 20;
    const dirs = [
      { dx: 0, dy: -1, cls: "mag-spin-ncl-a" },
      { dx: 0.866, dy: 0.5, cls: "mag-spin-ncl-b" },
      { dx: -0.866, dy: 0.5, cls: "mag-spin-ncl-c" },
    ];
    let html = `<circle class="mag-spin-site" cx="${cx}" cy="${cy}" r="3.5"/>`;
    dirs.forEach((d) => {
      const x2 = cx + d.dx * L;
      const y2 = cy + d.dy * L;
      const ax = x2 - d.dx * 5;
      const ay = y2 - d.dy * 5;
      const px = -d.dy;
      const py = d.dx;
      const head =
        `${x2.toFixed(1)},${y2.toFixed(1)} ` +
        `${(ax + px * 3.5).toFixed(1)},${(ay + py * 3.5).toFixed(1)} ` +
        `${(ax - px * 3.5).toFixed(1)},${(ay - py * 3.5).toFixed(1)}`;
      html +=
        `<line class="mag-spin-ncl ${d.cls}" x1="${cx}" y1="${cy}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}"/>` +
        `<polygon class="mag-spin-ncl ${d.cls}" points="${head}"/>`;
    });
    return html;
  }

  function buildMagSpinFigureSvg(order, row, opts) {
    opts = opts || {};
    const compact = !!opts.compact;
    const o = String(order || "").toLowerCase();
    const w = compact ? 96 : 132;
    const h = compact ? 58 : 78;
    const pad = compact ? 10 : 14;
    if (o === "ncl") {
      const label = i18nT("mag.spin.fig.ncl");
      return (
        `<svg class="mag-spin-svg mag-spin-svg-ncl${compact ? " is-compact" : ""}" viewBox="0 0 ${w} ${h}" role="img" aria-label="${escAttr(label)}">` +
        `<rect class="mag-spin-bg" x="1" y="1" width="${w - 2}" height="${h - 2}" rx="6"/>` +
        magNclFigureMarks(w / 2, h / 2, compact ? 17 : 23) +
        `</svg>`
      );
    }
    const sites = magSpinSitesForFigure(o, row);
    const plane = magSpinSitePlane(sites);
    const uv = sites.map((s) => {
      const p = s.pos || [0, 0, 0];
      if (plane === "xz") return { u: Number(p[0]), v: Number(p[2]), site: s };
      return { u: Number(p[0]), v: Number(p[1]), site: s };
    });
    let minU = 1;
    let maxU = 0;
    let minV = 1;
    let maxV = 0;
    uv.forEach((pt) => {
      minU = Math.min(minU, pt.u);
      maxU = Math.max(maxU, pt.u);
      minV = Math.min(minV, pt.v);
      maxV = Math.max(maxV, pt.v);
    });
    const du = Math.max(maxU - minU, 0.08);
    const dv = Math.max(maxV - minV, 0.08);
    const innerW = w - 2 * pad;
    const innerH = h - 2 * pad;
    const arrowSize = compact ? 9 : 11;
    const marks = uv.map((pt) => {
      const cx = pad + ((pt.u - minU) / du) * innerW;
      const cy = pad + (1 - (pt.v - minV) / dv) * innerH;
      return magSpinArrowMark(cx, cy, Number(pt.site.spin || 0), arrowSize);
    }).join("");
    const planeLab = plane === "xz" ? "a–c" : "a–b";
    const label = i18nT("mag.spin.fig.collinear", { order: sessionMagOrderShort(o), plane: planeLab });
    return (
      `<svg class="mag-spin-svg${compact ? " is-compact" : ""}" viewBox="0 0 ${w} ${h}" role="img" aria-label="${escAttr(label)}">` +
      `<rect class="mag-spin-bg" x="1" y="1" width="${w - 2}" height="${h - 2}" rx="6"/>` +
      `<text class="mag-spin-plane" x="${w - pad}" y="${h - 4}" text-anchor="end">${esc(planeLab)}</text>` +
      marks +
      `</svg>`
    );
  }

  function magSpinFigureCaption(order, row) {
    const r = row || {};
    if (r.spin_pattern) return String(r.spin_pattern);
    if (r.spin_arrows) {
      return i18nT("mag.spin.fig.arrows", {
        order: sessionMagOrderShort(order),
        arrows: String(r.spin_arrows),
      });
    }
    const o = String(order || "").toLowerCase();
    if (o === "ncl") return i18nT("mag.spin.fig.ncl_caption");
    if (o === "fm") return i18nT("mag.spin.fig.fm_caption");
    if (o.startsWith("afm")) return i18nT("mag.spin.fig.afm_caption", { order: sessionMagOrderShort(o) });
    return "";
  }

  function magSpinOrientationBlock(order, row, opts) {
    const o = String(order || "").toLowerCase();
    if (o === "nm") return "";
    const cap = magSpinFigureCaption(o, row);
    const svg = buildMagSpinFigureSvg(o, row, opts);
    const capHtml = cap ? `<figcaption class="mag-spin-caption meta">${esc(cap)}</figcaption>` : "";
    return `<figure class="mag-spin-orientation">${svg}${capHtml}</figure>`;
  }

  function sessionMagOrderIdsForGallery() {
    const el = $("session-mag-order");
    if (el && el.options && el.options.length) {
      return [...el.options].map((o) => String(o.value || "").trim().toLowerCase()).filter((v) => v && v !== "nm");
    }
    return SESSION_MAG_ORDERS.filter((r) => r.order !== "nm").map((r) => r.order);
  }

  function magSpinGalleryCardsHtml(active, orders) {
    return orders
      .map((ord) => {
        const meta = SESSION_MAG_ORDERS.find((r) => r.order === ord);
        const lab = meta ? meta.short : sessionMagOrderShort(ord);
        const row = magOrderRowFromLast(ord) || { order: ord };
        const fig = magSpinOrientationBlock(ord, row, { compact: true });
        if (!fig) return "";
        const activeCls = ord === active ? " is-active" : "";
        return `<button type="button" class="mag-spin-fig-card${activeCls}" role="listitem" data-order="${escAttr(ord)}" title="${escAttr(lab)}">${fig}<span class="mag-spin-fig-label">${esc(lab)}</span></button>`;
      })
      .filter(Boolean)
      .join("");
  }

  function onMagSpinGalleryPick(order) {
    const sel = $("session-mag-order");
    if (!sel || sel.disabled) return;
    const ord = String(order || "").trim().toLowerCase();
    if (!ord || sel.value === ord) return;
    sel.value = ord;
    onSessionMagOrderChange().catch((e) => alert(e.message));
  }

  function paintSessionMagSpinGallery() {
    if (!PHASES_ONLY) return;
    const active = getSessionMagOrder();
    const orders = sessionMagOrderIdsForGallery();
    const prepWrap = $("session-mag-spin-gallery-wrap");
    const prepGrid = $("session-mag-spin-gallery");
    const calcWrap = $("session-calc-mag-spin-wrap");
    const calcGrid = $("session-calc-mag-spin-gallery");
    const calcActive = $("session-calc-mag-spin-active");
    const calcTitle = $("session-calc-mag-spin-title");
    const cardsHtml = magSpinGalleryCardsHtml(active, orders);
    const hideMag = active === "nm" || !orders.length;

    if (prepWrap && prepGrid) {
      if (hideMag) {
        prepWrap.hidden = true;
        prepGrid.innerHTML = "";
      } else {
        prepWrap.hidden = false;
        prepGrid.innerHTML = cardsHtml;
      }
    }

    if (calcWrap && calcGrid) {
      if (hideMag) {
        calcWrap.hidden = true;
        calcGrid.innerHTML = "";
        if (calcActive) calcActive.innerHTML = "";
      } else {
        calcWrap.hidden = false;
        calcGrid.innerHTML = cardsHtml;
        const row = magOrderRowFromLast(active) || { order: active };
        if (calcActive) {
          calcActive.innerHTML = magSpinOrientationBlock(active, row) || "";
        }
        if (calcTitle) {
          calcTitle.textContent = i18nT("mag.spin.calc.active_title", {
            order: sessionMagOrderShort(active),
          });
        }
      }
    }
  }

  async function ensureMagChainReadyBeforeRun(magOrder) {
    if (!material || !sessionConfirmed) {
      alert(i18nT("alert.confirm_session"));
      return false;
    }
    const afmList = await fetchAvailableAfmOrders(material).catch(() => []);
    const orders = ordersForMagInputRefresh(magOrder, afmList);
    await prepareMagOrders(orders.length ? orders : [magOrder], { silent: true, material }).catch(() => {});
    await refreshMagOrders({ light: true, skipExtras: true, skipCaseRepaint: true }).catch(() => {});
    const audit = await fetchMagOrderChainAudit(magOrder);
    if (!audit.ok) {
      applyMagOrderAuditToUi(magOrder, audit);
      alert(audit.steps && audit.steps.length ? i18nT("mag.audit.block_run", { order: sessionMagOrderShort(magOrder) }) : i18nT("session.mag.need_inputs", { order: sessionMagOrderShort(magOrder) }));
      paintPhasesCalculsChainPanel();
      return false;
    }
    const row = magOrderRowFromLast(magOrder);
    if (!magOrderInputsPrepared(row)) {
      alert(i18nT("session.mag.need_inputs", { order: sessionMagOrderShort(magOrder) }));
      paintPhasesCalculsChainPanel();
      return false;
    }
    if (!isMagInputsVerified(magOrder)) {
      alert(i18nT("session.mag.need_verify", { order: sessionMagOrderShort(magOrder) }));
      paintPhasesCalculsChainPanel();
      return false;
    }
    const blocked = magRunBlockedReason(magOrder);
    if (blocked) {
      alert(blocked);
      return false;
    }
    return true;
  }

  function setWorkspaceActive(active) {
    document.body.classList.toggle("session-active", active);
    document.querySelectorAll(".btn-optim-run, .btn-optim-edit").forEach((b) => {
      b.disabled = !active;
    });
  }

  function rememberStructure(data) {
    if (data && data.structure && (data.structure.label_fr || data.structure.display)) {
      lastStructure = data.structure;
    }
    return lastStructure;
  }

  function structureLabel(data) {
    const s = (data && data.structure) || lastStructure;
    if (!s) return "";
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    return (lang === "en" ? (s.label_en || s.label_fr) : (s.label_fr || s.label_en)) || "";
  }

  function isGenericStructureLabel(lab) {
    const s = String(lab || "").trim().toLowerCase();
    if (!s) return true;
    return s.includes("ibrav = 0") || s.includes("ibrav=0") || s.includes("maille générale")
      || s.includes("general cell");
  }

  /** Nom cristallin de la phase active (ex. orthorhombique) pour les en-têtes de session. */
  function phaseCrystalLabel(data) {
    let lab = structureLabel(data);
    if (isGenericStructureLabel(lab)) lab = "";
    if (lab) return lab;
    const pid = String((data && data.phase_id) || phaseId || "").trim();
    const rows = (lastPhaseStability && lastPhaseStability.phases) || [];
    const row = rows.find((r) => String(r.phase_id || "").trim() === pid);
    if (row) return row.structure_label || row.label || "";
    if (!pid && rows.length === 1) return rows[0].structure_label || rows[0].label || "";
    const mt = lastMaterialType;
    if (mt && mt.ambient_short && !isGenericStructureLabel(mt.ambient_short)) {
      return mt.ambient_short;
    }
    if (mt && Array.isArray(mt.structures)) {
      const hit = mt.structures.find((p) => p.ambient || p.key === mt.ambient_key);
      const pl = hit && (hit.label_fr || hit.short);
      if (pl && !isGenericStructureLabel(pl)) return pl;
    }
    return "";
  }

  function materialDisplay(data) {
    const s = (data && data.structure) || lastStructure;
    if (s && s.display) return s.display;
    const lab = structureLabel(data);
    const name = (data && data.material) || material || "";
    return lab ? `${name} — ${lab}` : name;
  }

  function studyModeValue() {
    return $("study-mode-select")?.value || localStorage.getItem("optimqe.studyMode") || "auto";
  }

  function paintStudyWorkflow(data) {
    const nav = $("study-workflow");
    const stepsEl = $("study-workflow-steps");
    const altEl = $("study-workflow-alt");
    if (!nav || !stepsEl) return;
    if (!sessionConfirmed || !data || !data.ok || !data.workflow) {
      nav.hidden = true;
      return;
    }
    nav.hidden = false;
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    const wf = data.workflow;
    const main = wf.main || [];
    stepsEl.innerHTML = main.map((s) => {
      const lab = lang === "en" ? (s.label_en || s.label_fr) : (s.label_fr || s.label_en);
      const labHtml = lang === "en"
        ? (s.label_html_en || s.label_html_fr)
        : (s.label_html_fr || s.label_html_en);
      const cls = [s.done ? "is-done" : "", s.active ? "is-active" : ""].filter(Boolean).join(" ");
      const body = labHtml || esc(lab || s.id);
      return `<li class="${cls}" data-tab-link="${s.id || ""}"><span class="wf-step-num">${s.index || ""}.</span> ${body}</li>`;
    }).join("");
    const opt = wf.optional_phases || {};
    const alt = lang === "en" ? (opt.label_en || opt.label_fr) : (opt.label_fr || opt.label_en);
    const altHtml = lang === "en"
      ? (opt.label_html_en || opt.label_html_fr)
      : (opt.label_html_fr || opt.label_html_en);
    if (altEl) {
      if (altHtml) altEl.innerHTML = altHtml;
      else altEl.textContent = alt || "";
      altEl.hidden = !(altHtml || alt);
    }
    const tabPh = $("tab-phases");
    if (tabPh) {
      const req = !!opt.required;
      tabPh.classList.toggle("is-optional", !req);
      tabPh.classList.toggle("is-required", req);
      tabPh.title = req ? i18nT("workflow.phases.required") : i18nT("study.phases.optional");
    }
  }

  function paintStudyGuide(data) {
    lastStudy = data || null;
    paintStudyWorkflow(data);
    const conc = $("res-conclusion-body");
    if (conc && data && data.ok && data.conclusion) conc.textContent = data.conclusion;
    const nextLine = $("study-next-line");
    if (nextLine) {
      const msg = data && data.ok ? (data.next_fr || "") : "";
      nextLine.textContent = msg;
      nextLine.hidden = !msg;
    }
    const tabPh = $("tab-phases");
    if (tabPh && !(data && data.workflow)) {
      const known = !!(data && data.mode === "known_phase");
      tabPh.classList.toggle("is-optional", known);
      tabPh.title = known
        ? i18nT("study.phases.optional")
        : "";
    }
    const toMag = $("btn-scf-to-mag");
    if (toMag && data && data.ok) {
      if (data.next_tab === "phases") {
        toMag.setAttribute("data-i18n", "mag.from_scf.phases");
        toMag.textContent = i18nT("mag.from_scf.phases");
      } else {
        toMag.setAttribute("data-i18n", "mag.from_scf");
        toMag.textContent = i18nT("mag.from_scf");
      }
    }
    paintSessionBar();
  }

  async function refreshStudyGuide() {
    if (!material) {
      paintStudyGuide(null);
      return null;
    }
    const mode = studyModeValue();
    const q = phaseQuery(`?mode=${encodeURIComponent(mode)}&light=1`);
    const data = await api(`/api/materials/${encodeURIComponent(material)}/study-plan${q}`);
    paintStudyGuide(data);
    return data;
  }

  function materialTypeLabel(info) {
    if (!info) return "";
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    return (lang === "en" ? (info.type_en || info.type_fr) : (info.type_fr || info.type_en)) || info.type || "";
  }

  function paintMaterialTypeBadge(info) {
    const badge = $("material-type-badge");
    if (!badge) return;
    lastMaterialType = info || null;
    const lab = materialTypeLabel(info);
    if (!lab || !info || info.type === "unknown") {
      badge.hidden = true;
      badge.textContent = "";
      return;
    }
    badge.hidden = false;
    badge.textContent = lab;
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    const fam = lang === "en" ? (info.family_en || info.family_fr) : (info.family_fr || info.family_en);
    const tip = info.summary_fr || info.ambient_short || lab;
    badge.title = fam ? `${fam} — ${tip}` : tip;
  }

  async function refreshMaterialType(matName) {
    const mat = (matName || getDraftMaterial() || material || "").trim();
    if (!mat) {
      paintMaterialTypeBadge(null);
      return null;
    }
    try {
      const data = await api(`/api/materials/${encodeURIComponent(mat)}/material-type`);
      paintMaterialTypeBadge(data);
      if (sessionConfirmed && material === mat) paintSessionBar();
      return data;
    } catch {
      paintMaterialTypeBadge(null);
      return null;
    }
  }

  let materialTypesCache = null;
  let materialFamiliesCache = null;

  async function ensureMaterialTypesLoaded() {
    if (materialTypesCache && materialTypesCache.length) {
      return { types: materialTypesCache, families: materialFamiliesCache || [] };
    }
    const data = await api("/api/material-types");
    materialTypesCache = data.types || [];
    materialFamiliesCache = data.families || [];
    return { types: materialTypesCache, families: materialFamiliesCache };
  }

  function shortSelectLabel(text, maxLen = 72) {
    const t = String(text || "").trim();
    if (t.length <= maxLen) return t;
    return `${t.slice(0, Math.max(0, maxLen - 1))}…`;
  }

  function fillPhaseTypeSelect(types, selectedId, families) {
    const sel = $("phase-type-select");
    if (!sel) return;
    const byId = new Map((types || []).map((t) => [t.id, t]));
    const famList = families && families.length
      ? families
      : (() => {
          const seen = new Map();
          (types || []).forEach((t) => {
            if (!t || !t.id || t.id === "unknown") return;
            const fid = t.family || t.family_fr || "—";
            if (!seen.has(fid)) {
              seen.set(fid, {
                id: fid,
                fr: t.family_fr || fid,
                types: [],
              });
            }
            seen.get(fid).types.push(t.id);
          });
          return [...seen.values()];
        })();
    let html = `<option value="">—</option>`;
    const placed = new Set();
    famList.forEach((fam) => {
      const ids = fam.types || [];
      const rows = ids.map((id) => byId.get(id)).filter((t) => t && t.id !== "unknown");
      if (!rows.length) return;
      const label = fam.fr || fam.en || fam.id || "—";
      html += `<optgroup label="${escAttr(label)}">`;
      rows.forEach((t) => {
        placed.add(t.id);
        const hint = t.formula_general || t.formula_hint || "";
        const lab = shortSelectLabel(hint ? `${t.fr || t.id} — ${hint}` : (t.fr || t.id));
        html += `<option value="${escAttr(t.id)}">${esc(lab)}</option>`;
      });
      html += `</optgroup>`;
    });
    // Types restants non classés en famille
    const rest = (types || []).filter((t) => t && t.id && t.id !== "unknown" && !placed.has(t.id));
    if (rest.length) {
      html += `<optgroup label="Autres">`;
      rest.forEach((t) => {
        const hint = t.formula_general || t.formula_hint || "";
        const lab = shortSelectLabel(hint ? `${t.fr || t.id} — ${hint}` : (t.fr || t.id));
        html += `<option value="${escAttr(t.id)}">${esc(lab)}</option>`;
      });
      html += `</optgroup>`;
    }
    sel.innerHTML = html;
    if (selectedId && [...sel.options].some((o) => o.value === selectedId)) {
      sel.value = selectedId;
    }
  }

  function paintPhaseTypeStructures(info) {
    const box = $("phase-type-structures");
    const status = $("phase-type-status");
    if (!box) return;
    const structs = (info && (info.structures || info.known_phases)) || [];
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    if (status) {
      if (info && info.type_validated) {
        const formula = info.formula_general || info.formula_hint || "";
        let line = i18nT("phase.type.validated", {
          type: lang === "en" ? (info.type_en || info.type_fr) : (info.type_fr || info.type_en),
          n: String(structs.length || info.n_structures || 0),
        });
        if (formula) line += ` · ${formula}`;
        if (info.interests_fr) line += ` — ${info.interests_fr}`;
        status.textContent = line;
        status.className = "meta status-ok";
      } else if (info && (info.detected_type_fr || info.type_fr)) {
        status.textContent = i18nT("phase.type.detected", {
          type: lang === "en"
            ? (info.detected_type_en || info.detected_type_fr || info.type_en)
            : (info.detected_type_fr || info.type_fr),
        });
        status.className = "meta";
      } else {
        status.textContent = "";
      }
    }
    if (!structs.length) {
      box.innerHTML = `<p class="meta">${esc(i18nT("phase.type.structures.empty"))}</p>`;
      return;
    }
    const head = `<tr><th>${esc(i18nT("phase.type.col.structure"))}</th><th>${esc(i18nT("phase.type.col.sg"))}</th><th>${esc(i18nT("phase.type.col.mode"))}</th></tr>`;
    const lines = structs.map((p) => {
      const lab = lang === "en"
        ? (p.label_en || p.short || p.key)
        : (p.label_fr || p.short || p.key);
      const mode = p.generatable
        ? i18nT("phase.type.tag.auto")
        : i18nT("phase.type.tag.manual");
      const amb = p.ambient ? ` · ${i18nT("phase.type.tag.ambient")}` : "";
      return `<tr class="${p.ambient ? "phase-row-stable" : ""}"><td><strong>${esc(lab)}</strong></td><td>${esc(p.spacegroup || "—")}</td><td>${esc(mode)}${esc(amb)}</td></tr>`;
    }).join("");
    box.innerHTML = `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table"><thead>${head}</thead><tbody>${lines}</tbody></table></div>`;
  }

  async function refreshPhaseTypePanel(matName) {
    const mat = (matName || material || getDraftMaterial() || "").trim();
    const sel = $("phase-type-select");
    const btn = $("btn-validate-type");
    const pack = await ensureMaterialTypesLoaded().catch(() => ({ types: [], families: [] }));
    let info = null;
    if (mat) {
      try {
        info = await api(`/api/materials/${encodeURIComponent(mat)}/material-type`);
      } catch {
        info = null;
      }
    }
    fillPhaseTypeSelect(pack.types || [], (info && info.type) || "", pack.families || []);
    if (sel) sel.disabled = false;
    if (btn) btn.disabled = !sessionConfirmed || !(sel && sel.value);
    paintMaterialTypeBadge(info);
    if (sessionConfirmed && mat) {
      await bootstrapNmInputs(mat, { silent: true }).catch(() => {});
    }
    await refreshStartingPhase(mat).catch(() => {});
    await refreshCifList(mat).catch(() => {});
    if (info && info.type_validated) {
      paintPhaseTypeStructures(info);
    } else {
      const box = $("phase-type-structures");
      const status = $("phase-type-status");
      if (status) {
        if (info) {
          const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
          status.textContent = i18nT("phase.type.detected", {
            type: lang === "en"
              ? (info.detected_type_en || info.detected_type_fr || info.type_en)
              : (info.detected_type_fr || info.type_fr),
          });
          status.className = "meta";
        } else {
          status.textContent = "";
        }
      }
      if (box) {
        box.innerHTML = `<p class="meta">${esc(i18nT("phase.type.structures.empty"))}</p>`;
      }
    }
    return info;
  }

  async function validatePhaseType() {
    if (!requireSessionConfirmed()) return;
    const mat = material || getDraftMaterial();
    const sel = $("phase-type-select");
    const tid = sel ? sel.value : "";
    if (!tid) {
      alert(i18nT("phase.type.need_pick"));
      return;
    }
    const startName = ($("phase-start-name")?.value || "").trim();
    const data = await api(`/api/materials/${encodeURIComponent(mat)}/material-type`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        type_id: tid,
        starting_phase_id: activePhaseId() || getDraftPhase() || "",
        starting_phase_name: startName,
        validate: true,
      }),
    });
    log("log-opt", data.message || data, !!data.ok);
    paintMaterialTypeBadge(data);
    paintPhaseTypeStructures(data);
    if (sel && data.type) sel.value = data.type;
    paintStartingPhase(data.starting_phase || data);
    await refreshPhaseStability().catch(() => {});
  }

  function normalizeStartingPhaseInfo(info) {
    if (!info) return null;
    if (info.starting_phase && typeof info.starting_phase === "object") {
      return { ...info.starting_phase, ...info };
    }
    return info;
  }

  function paintStartingPhase(info, opts = {}) {
    const row = normalizeStartingPhaseInfo(info);
    const nameEl = $("phase-start-name");
    const status = $("phase-start-status");
    const btnVal = $("btn-validate-phase");
    const dl = $("phase-start-suggestions");
    const det = row && (row.detected || row.starting_phase_detected);
    const name = (row && (row.starting_phase_name || row.suggested_name || row.name))
      || (det && (det.suggested_name || det.label_fr || det.short || det.formula))
      || "";
    if (nameEl && name) {
      if (opts.force || !nameEl.value || row?.starting_phase_validated) {
        nameEl.value = name;
      }
    }
    if (dl) {
      const opts = [];
      const seen = new Set();
      const push = (v) => {
        const s = String(v || "").trim();
        if (!s || seen.has(s.toLowerCase())) return;
        seen.add(s.toLowerCase());
        opts.push(`<option value="${escAttr(s)}"></option>`);
      };
      push(name);
      (row?.cif_candidates || []).forEach((c) => {
        push(c.suggested_name || c.label_fr || c.short || c.cif_name);
      });
      if (row?.qe_detection) {
        push(row.qe_detection.suggested_name || row.qe_detection.label_fr);
      }
      if (det) {
        push(det.suggested_name || det.label_fr || det.short || det.formula);
      }
      dl.innerHTML = opts.join("");
    }
    if (status) {
      if (!row) {
        status.textContent = "";
        status.className = "meta";
      } else if (row.starting_phase_validated) {
        status.textContent = i18nT("phase.start.validated", { name: name || "—" });
        status.className = "meta status-ok";
      } else if (det || row.message_fr || row.message_en || name) {
        const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
        const src = (det && det.source) || row.source || "—";
        status.textContent = (lang === "en" ? row.message_en : row.message_fr)
          || row.message_fr
          || i18nT("phase.start.ok", { source: src, name: name || "—" });
        status.className = det || name ? "meta" : "meta";
      } else {
        status.textContent = i18nT("phase.start.none");
        status.className = "meta";
      }
    }
    if (btnVal) btnVal.disabled = !sessionConfirmed || !(($("phase-start-name")?.value || "").trim());
  }

  async function refreshStartingPhase(matName) {
    const mat = (matName || material || getDraftMaterial() || "").trim();
    if (!mat) {
      paintStartingPhase(null);
      return null;
    }
    try {
      const data = await api(`/api/materials/${encodeURIComponent(mat)}/starting-phase${phaseQuery()}`);
      paintStartingPhase(data);
      return data;
    } catch {
      paintStartingPhase(null);
      return null;
    }
  }

  /** VC-RELAX depuis .in ou CIF ; RELAX/SCF seulement après convergence. */
  async function bootstrapNmInputs(matName, opts = {}) {
    const mat = (matName || material || getDraftMaterial() || "").trim();
    if (!mat) return null;
    const silent = !!opts.silent;
    try {
      const data = await api(`/api/materials/${encodeURIComponent(mat)}/bootstrap-nm`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(withPhaseBody({
          auto_from_cif: opts.auto_from_cif !== false,
          sync_followups: opts.sync_followups !== false,
        })),
      });
      if (!silent) {
        const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
        const msg = lang === "en"
          ? (data.message_en || data.chain_note_en || data.message_fr)
          : (data.message_fr || data.chain_note_fr || data.message_en);
        log("log-opt", msg, !!data.ok);
      }
      const st = $("phase-cif-status");
      if (st && data.cif_convert) {
        st.textContent = data.cif_convert.message || data.message_fr || "";
        st.className = "meta status-ok";
      }
      await refreshStartingPhase(mat).catch(() => {});
      return data;
    } catch (e) {
      if (!silent) log("log-opt", e.message, false);
      return null;
    }
  }

  async function detectStartingPhase() {
    const mat = (material || getDraftMaterial() || "").trim();
    if (!mat) {
      alert(i18nT("alert.pick_mat"));
      return;
    }
    const data = await api(`/api/materials/${encodeURIComponent(mat)}/starting-phase${phaseQuery()}`);
    paintStartingPhase(data, { force: true });
    log("log-opt", data.message_fr || data.message_en || data, !!data.ok);
  }

  async function validateStartingPhase() {
    if (!requireSessionConfirmed()) return;
    const mat = material || getDraftMaterial();
    const name = ($("phase-start-name")?.value || "").trim();
    if (!name) {
      alert(i18nT("phase.start.need_name"));
      return;
    }
    const data = await api(`/api/materials/${encodeURIComponent(mat)}/starting-phase`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(withPhaseBody({
        name,
        starting_phase_name: name,
        phase_id: activePhaseId() || getDraftPhase() || "",
      })),
    });
    paintStartingPhase(data);
    log("log-opt", data.message_fr || data.message || data, !!data.ok);
  }

  async function refreshCifList(matName) {
    const mat = (matName || material || getDraftMaterial() || "").trim();
    if (!mat) return [];
    try {
      await refreshSessionStructureUI(mat);
      return await fetchCifsForMaterial(mat);
    } catch {
      return [];
    }
  }

  function structurePanelUnlocked() {
    if (sessionConfirmed) return true;
    if (isDualStudyIntent()) return dualMaterialsValidated;
    return singleMaterialValidated;
  }

  let phasesWorkStashed = false;

  function syncPhasesWorkDom(unlocked) {
    if (!PHASES_ONLY) return;
    const stash = $("phases-work-stash");
    const mount = $("session-work-mount");
    const tabs = $("session-work-tabs");
    const panels = document.querySelector(".session-work-panels");
    if (!stash || !mount || !tabs || !panels) return;

    // Les onglets Préparation / Calcul / Résultats restent visibles ; le verrou ne concerne que « Commencer ».
    if (PHASES_ONLY) unlocked = true;

    if (!unlocked) {
      if (!phasesWorkStashed) {
        stash.appendChild(tabs);
        stash.appendChild(panels);
        tabs.hidden = true;
        panels.hidden = true;
        phasesWorkStashed = true;
      }
      return;
    }

    if (phasesWorkStashed) {
      mount.appendChild(tabs);
      mount.appendChild(panels);
      phasesWorkStashed = false;
      requestAnimationFrame(resetPhasesHorizontalScroll);
    } else if (tabs.parentElement !== mount) {
      mount.appendChild(tabs);
      mount.appendChild(panels);
    }
    tabs.hidden = false;
    panels.hidden = false;
  }

  function paintStructurePanelVisibility() {
    const unlocked = structurePanelUnlocked();
    const panel = $("session-structure-panel");
    const wasUnlocked = !!(panel && panel.dataset.unlocked === "1");
    if (panel) {
      panel.hidden = !unlocked;
      if (unlocked) panel.dataset.unlocked = "1";
    }
    const runBlock = $("session-block-run");
    if (runBlock) {
      if (PHASES_ONLY) {
        runBlock.hidden = false;
        runBlock.classList.toggle("session-run-locked", !unlocked);
        const startBtn = $("btn-confirm-session");
        if (startBtn) startBtn.disabled = !unlocked;
      } else {
        runBlock.hidden = !unlocked;
        runBlock.classList.remove("session-run-locked");
      }
    }
    if (PHASES_ONLY) {
      syncPhasesWorkDom(unlocked);
      if (unlocked && !wasUnlocked && $("tab-session-preparation")) {
        switchSessionWorkTab("preparation");
        const prepSub = sessionStudyIntent() === "doping" ? "prep-doped" : "prep-nondope";
        switchSessionSubTab("preparation", prepSub);
        requestAnimationFrame(() => {
          if (sessionStudyIntent() === "doping") {
            $("phase-doping-card")?.scrollIntoView({ behavior: "smooth", block: "start" });
          } else {
            panel?.scrollIntoView({ behavior: "smooth", block: "start" });
          }
        });
      }
    } else {
      const tabs = $("session-work-tabs") || document.querySelector(".session-work-tabs");
      const panels = document.querySelector(".session-work-panels");
      if (tabs) tabs.hidden = false;
      if (panels) panels.hidden = false;
    }
    const genBtn = $("btn-generate-all-inputs");
    if (genBtn) genBtn.disabled = !unlocked;
    paintSessionMagOrderControlsEnabled();
    [ $("session-cif-pick"), $("session-input-pick") ].forEach((el) => {
      if (el) el.disabled = !unlocked;
    });
    if (!unlocked || sessionConfirmed) clearSessionActionPulse();
    paintDualCifSwitch();
  }

  function getSessionChainNspin() {
    const el = $("session-chain-nspin");
    const v = el ? Number(el.value) : 1;
    return v === 2 ? 2 : 1;
  }

  function getSelectedCifName() {
    return ($("session-cif-pick")?.value || "").trim();
  }

  function getSelectedCifPath() {
    const sel = $("session-cif-pick")?.selectedOptions?.[0];
    return (sel?.dataset?.cifPath || "").trim();
  }

  function getSelectedInputKind() {
    return ($("session-input-pick")?.value || "").trim();
  }

  function paintSessionChainPlan() {
    const el = $("session-chain-plan");
    if (!el) return;
    if (PHASES_PREP_ONLY) {
      const magOrder = getSessionMagOrder();
      const intent = sessionStudyIntent();
      el.hidden = false;
      if (magOrder !== "nm") {
        el.textContent = i18nT("session.chain.plan_mag_order_prep", {
          order: sessionMagOrderShort(magOrder),
        });
      } else if (intent === "sqs") {
        el.textContent = i18nT("session.chain.plan_sqs_prep");
      } else if (intent === "doping") {
        el.textContent = i18nT("session.chain.plan_doping_prep");
      } else {
        el.textContent = i18nT("session.chain.plan_nm_prep");
      }
      return;
    }
    const magOrder = getSessionMagOrder();
    if (magOrder !== "nm") {
      el.hidden = false;
      el.textContent = i18nT("session.chain.plan_mag_order", {
        order: sessionMagOrderShort(magOrder),
      });
      return;
    }
    const ns = getSessionChainNspin();
    if (ns !== 1) {
      el.hidden = false;
      el.textContent = i18nT("session.chain.plan_mag");
      return;
    }
    const intent = sessionStudyIntent();
    if (intent === "sqs") {
      el.hidden = false;
      el.textContent = i18nT("session.chain.plan_sqs");
      return;
    }
    if (intent === "doping") {
      el.hidden = false;
      el.textContent = i18nT("session.chain.plan_doping");
      return;
    }
    const cr = lastOptimStatus?.chain_resume;
    if (sessionConfirmed && material && cr && cr.next_kind && !cr.all_done) {
      el.hidden = false;
      el.textContent = i18nT("session.chain.plan_nm_resume", {
        kind: String(cr.next_kind).toUpperCase(),
      });
      return;
    }
    if (sessionConfirmed && material && cr?.all_done) {
      el.hidden = false;
      el.textContent = i18nT("session.chain.plan_nm_done");
      return;
    }
    el.hidden = true;
    el.textContent = "";
  }

  async function fetchNmInputsForMaterial(mat) {
    const m = String(mat || "").trim();
    if (!m) return [];
    try {
      const data = await api(`/api/materials/${encodeURIComponent(m)}/nm-inputs${phaseQuery()}`);
      return data.inputs || [];
    } catch {
      return [];
    }
  }

  async function refreshSessionStructureUI(matName) {
    const mat = (matName || structureEditMaterial() || getDraftMaterial() || "").trim();
    const cifPick = $("session-cif-pick");
    const inPick = $("session-input-pick");
    if (!cifPick || !inPick) return;
    const prevCif = cifPick.value;
    const prevIn = inPick.value;
    cifPick.innerHTML = `<option value="">${esc(i18nT("session.structure.pick_none"))}</option>`;
    inPick.innerHTML = `<option value="">${esc(i18nT("session.input.pick_none"))}</option>`;
    if (!mat || !structurePanelUnlocked()) return;
    const cifs = await fetchCifsForMaterial(mat);
    cifs.forEach((c) => {
      const opt = document.createElement("option");
      opt.value = c.name || "";
      if (c.path) opt.dataset.cifPath = c.path;
      opt.textContent = c.name || c.path || "";
      cifPick.appendChild(opt);
    });
    const inputs = await fetchNmInputsForMaterial(mat);
    inputs.forEach((row) => {
      const opt = document.createElement("option");
      opt.value = row.kind || "";
      const ns = row.nspin != null ? ` · nspin=${row.nspin}` : "";
      opt.textContent = i18nT("session.input.option", {
        name: row.name || `${mat}-${row.kind}.in`,
        ns,
      });
      inPick.appendChild(opt);
    });
    if (prevCif && [...cifPick.options].some((o) => o.value === prevCif)) cifPick.value = prevCif;
    else if (cifs.length) cifPick.value = cifs[0].name || "";
    if (prevIn && [...inPick.options].some((o) => o.value === prevIn)) inPick.value = prevIn;
    else if (inputs.some((r) => r.kind === "vc-relax")) inPick.value = "vc-relax";
    else if (inputs.length) inPick.value = inputs[0].kind || "";
    await refreshSessionMagOrderPick(mat);
    paintSessionChainPlan();
    const data = lastStructureSource || (await fetchStructureSource(mat));
    if (data) paintStructureSource(data);
    paintSessionMagInputMode(mat).catch(() => {});
  }

  function onSessionCifPickChange() {
    paintSessionChainPlan();
    paintGenerateInputsButtonLabel();
  }

  function resolveSessionStructureMaterial() {
    return String(
      (sessionConfirmed && material) || structureEditMaterial() || getDraftMaterial() || ""
    ).trim();
  }

  async function fetchAvailableAfmOrders(mat) {
    const m = String(mat || "").trim();
    if (!m) return ["afm-g", "afm-a", "afm-b", "afm-c"];
    try {
      const pid = activePhaseId();
      let q = phaseQueryFor(pid);
      q += (q ? "&" : "?") + "light=1";
      const data = await api(`/api/materials/${encodeURIComponent(m)}/mag-orders${q}`);
      if (data && data.available_afm && data.available_afm.length) return data.available_afm;
    } catch (_) {
      /* liste par défaut */
    }
    return ["afm-g", "afm-a", "afm-b", "afm-c"];
  }

  /** Ordres à préparer dans mag/ : FM → jeu complet FM+AFM (nspin 2) + NCL (nspin 4). */
  function ordersForMagInputRefresh(order, afmList) {
    const o = String(order || "").trim().toLowerCase();
    if (o === "nm") return [];
    if (o === "fm") {
      const afm = (afmList && afmList.length ? afmList : ["afm-g", "afm-a", "afm-b", "afm-c"]).map((x) =>
        String(x).trim().toLowerCase()
      );
      const uniq = ["fm", ...afm, "ncl"].filter((x, i, a) => a.indexOf(x) === i);
      return uniq;
    }
    return [o];
  }

  async function refreshInputsForSessionMagOrder(opts = {}) {
    const mat = String(opts.material || resolveSessionStructureMaterial()).trim();
    if (!mat || !structurePanelUnlocked()) return { ok: false, skipped: true };
    const order = String(opts.magOrder != null ? opts.magOrder : getSessionMagOrder()).trim().toLowerCase();
    const silent = opts.silent !== false;
    const inputs = await fetchNmInputsForMaterial(mat);
    const src = lastStructureSource || (await fetchStructureSource(mat).catch(() => null));
    const hasVc = inputs.some((r) => r.kind === "vc-relax") || !!src?.vc_relax_exists;
    if (order === "nm") {
      if (!hasVc) return { ok: false, skipped: true, reason: "no_vc" };
      const ns = opts.nspin != null ? Number(opts.nspin) : getSessionChainNspin();
      return applySpinToInputs({ material: mat, silent, nspin: ns });
    }
    if (!hasVc) return { ok: false, skipped: true, reason: "no_vc" };
    const afmList = await fetchAvailableAfmOrders(mat);
    const orders = ordersForMagInputRefresh(order, afmList);
    const prep = await prepareMagOrders(orders, {
      silent,
      material: mat,
      allowBeforeConfirm: true,
    });
    if (prep && prep.ok) {
      return { ...prep, bundle: order === "fm" && orders.length > 1, preparedOrders: orders };
    }
    return prep;
  }

  function paintSessionMagOrderControlsEnabled() {
    const busy = !!sessionMagOrderInputUpdateBusy;
    const order = getSessionMagOrder();
    const magOrderSel = $("session-mag-order");
    if (magOrderSel) magOrderSel.disabled = busy;
    const chainNs = $("session-chain-nspin");
    if (chainNs) chainNs.disabled = busy || order !== "nm";
  }

  function paintSessionMagChainNspinVisibility() {
    const order = getSessionMagOrder();
    const wrap = $("session-chain-nspin-wrap");
    const nspinLine = $("session-mag-order-nspin");
    const intentRow = $("session-intent-mat-row");
    const ns = nspinForMagOrder(order);
    const isNm = order === "nm";
    if (wrap) wrap.hidden = !isNm;
    if (intentRow) intentRow.classList.toggle("session-intent-mat-row-nm-nspin", isNm);
    if (nspinLine) {
      if (isNm) {
        nspinLine.hidden = true;
        nspinLine.textContent = "";
      } else {
        nspinLine.hidden = false;
        nspinLine.textContent = i18nT("session.mag_order.nspin_for", {
          order: sessionMagOrderShort(order),
          nspin: String(ns),
        });
      }
    }
    paintSessionMagOrderControlsEnabled();
    paintSessionStartButtonLabel();
    paintSessionMagSpinGallery();
    paintPhasesCalculsChainPanel();
  }

  function paintSessionStartButtonLabel() {
    const btn = $("btn-confirm-session");
    if (!btn) return;
    const order = getSessionMagOrder();
    if (PHASES_PREP_ONLY || order === "nm") {
      btn.textContent = i18nT("btn.confirm.session");
      btn.title = i18nT("btn.confirm.session.title");
      return;
    }
    const lab = sessionMagOrderShort(order);
    btn.textContent = i18nT("btn.confirm.session_mag", { order: lab });
    btn.title = i18nT("session.chain.start_mag_order", { order: lab });
  }

  /** Onglet Calculs (Phases) : carte FM/AFM/NCL avec pipeline VC-RELAX → … comme NM. */
  function paintPhasesCalculsChainPanel() {
    if (!PHASES_ONLY || PHASES_PREP_ONLY) return;
    const order = getSessionMagOrder();
    const nmCard = $("nm-chain-card");
    let magCard = $("phases-active-mag-chain");
    if (order === "nm") {
      if (nmCard) nmCard.hidden = false;
      if (magCard) magCard.hidden = true;
      if (material) {
        paintNmOptimChain(lastOptimStatus || { steps: {}, chain_resume: {} });
      }
      paintSessionMagSpinGallery();
      return;
    }
    if (nmCard) nmCard.hidden = true;
    const host = $("optim-cards");
    if (!host) return;
    if (!magCard) {
      magCard = document.createElement("article");
      magCard.id = "phases-active-mag-chain";
      magCard.className = "mag-case-row nm-chain-row";
      host.appendChild(magCard);
    }
    magCard.hidden = false;
    const ns = nspinForMagOrder(order);
    const lab = sessionMagOrderShort(order);
    const rows = (lastMagOrders && lastMagOrders.orders) || [];
    const row = rows.find((r) => r.order === order) || { order };
    const steps = row.steps || {};
    const cr = row.chain_resume || {};
    const chainMeta = chainButtonMeta(cr, steps, CHAIN_KINDS_MAG);
    const startKind = chainMeta.startKind || "vc-relax";
    const ordAttr = escAttr(order);
    const geo = (lastMagOrders && lastMagOrders.geometry) || {};
    const canRun = sessionConfirmed && material && draftsMatchSession();
    const magOpen = canRun && magGeoUsable(geo);
    const editDis = magOpen ? "" : "disabled";
    const failKind = chainMeta.retry ? startKind : "";
    const pipelineHtml = buildMagPipelineOlHtml(row, editDis, failKind);
    const inputsReady = magOrderInputsPrepared(row);
    const verified = isMagInputsVerified(order);
    const anyRun = !!(row.running || row.nscf_running || Object.values(steps).some((s) => s && s.running));
    const runDis = !magOpen || anyRun || !!(cr.all_done && !row.needs_nscf) || !inputsReady || !verified;
    const short = (row.short || order).replace("afm-", "AFM-").toUpperCase();
    const rebuild =
      magCard.dataset.order !== order
      || !magCard.querySelector(".phases-mag-pipeline-host")
      || !magCard.querySelector(".phases-mag-spin-host");
    magCard.dataset.order = order;
    if (rebuild) {
      magCard.innerHTML =
        `<div class="phases-mag-spin-host mag-calc-spin-top" aria-hidden="false"></div>
        <div class="calc-row">
          <div class="calc-row-label">
            <strong class="mag-case-name">${esc(lab)}</strong>
            <span class="meta">${esc(i18nT("opt.mag.chain.meta", { order: lab, nspin: String(ns) }))}</span>
          </div>
          <div class="calc-row-actions">
            <button class="btn btn-mag-run" type="button" data-order="${ordAttr}" data-kind="${escAttr(startKind)}">${esc(chainMeta.label)}</button>
            <button class="btn ghost btn-mag-stop" type="button" data-order="${ordAttr}" data-kind="${escAttr(startKind)}" hidden>${esc(i18nT("btn.stop_calc"))}</button>
          </div>
        </div>
        <div class="phases-mag-pipeline-host">${pipelineHtml}</div>
        <p class="meta phases-mag-verify-hint" id="phases-mag-verify-hint"></p>
        <div class="phases-mag-audit meta" id="phases-mag-audit-detail" hidden aria-live="polite"></div>
        <label class="phases-mag-verify meta">
          <input type="checkbox" id="phases-mag-inputs-verified" />
          <span data-phases-mag-verify-label>${esc(i18nT("phases.mag.verify_label"))}</span>
        </label>
        <p class="mag-chain-banner" id="status-mag-${ordAttr}">—</p>
        <p class="meta card-track-kicker">${esc(i18nT("runs.track.live"))}</p>
        <div class="card-track" id="track-mag-${ordAttr}" data-kind="mag" aria-live="polite">
          <div class="track-live" hidden></div>
          <div class="track-history"></div>
        </div>`;
    } else {
      const pipeHost = magCard.querySelector(".phases-mag-pipeline-host");
      if (pipeHost) pipeHost.innerHTML = pipelineHtml;
      const runBtn = magCard.querySelector(".btn-mag-run");
      if (runBtn) {
        runBtn.textContent = chainMeta.label;
        runBtn.title = chainMeta.title;
        runBtn.dataset.kind = startKind;
        runBtn.classList.toggle("btn-chain-retry", !!chainMeta.retry);
      }
    }
    const verifyCb = $("phases-mag-inputs-verified");
    const verifyHint = $("phases-mag-verify-hint");
    if (verifyCb) {
      verifyCb.disabled = !inputsReady || anyRun;
      verifyCb.checked = verified;
      verifyCb.onchange = () => {
        (async () => {
          if (verifyCb.checked) {
            const audit = await fetchMagOrderChainAudit(order);
            if (!audit.ok) {
              verifyCb.checked = false;
              applyMagOrderAuditToUi(order, audit);
              paintPhasesCalculsChainPanel();
              return;
            }
            markMagInputsVerified(order);
          } else {
            clearMagInputsVerified(order);
          }
          paintPhasesCalculsChainPanel();
        })().catch((e) => alert(e.message));
      };
    }
    if (verifyHint) {
      if (!inputsReady) {
        verifyHint.textContent = i18nT("phases.mag.verify_need_inputs", { order: lab, nspin: String(ns) });
        verifyHint.className = "meta phases-mag-verify-hint warn";
      } else if (!verified) {
        verifyHint.textContent = i18nT("phases.mag.verify_need_edit", { order: lab, nspin: String(ns) });
        verifyHint.className = "meta phases-mag-verify-hint warn";
      } else {
        verifyHint.textContent = i18nT("phases.mag.verify_ok", { order: lab });
        verifyHint.className = "meta phases-mag-verify-hint status-ok";
      }
    }
    const runBtn = magCard.querySelector(".btn-mag-run");
    const stopBtn = magCard.querySelector(".btn-mag-stop");
    if (runBtn) {
      runBtn.disabled = runDis;
      runBtn.title = runDis && !inputsReady
        ? i18nT("mag.banner.need_gen")
        : runDis && !verified
          ? i18nT("session.mag.need_verify", { order: lab })
          : chainMeta.title;
    }
    const cardRunning = magRowAnyRunning(row);
    const stopKind = magRowStopKind(row, startKind);
    if (stopBtn) {
      stopBtn.hidden = !cardRunning;
      stopBtn.disabled = false;
      stopBtn.dataset.kind = stopKind;
      stopBtn.textContent = i18nT("btn.stop_calc");
    }
    magCard.classList.toggle("is-running", !!anyRun);
    const actRun = magOrderRunning(row);
    const banner = $(`status-mag-${order}`);
    if (banner) {
      let bannerTxt = chainMeta.title;
      let liveCls = "";
      if (row.nscf_running) {
        bannerTxt = i18nT("phase.nscf.running");
        liveCls = "running";
      } else if (actRun) {
        bannerTxt = i18nT("mag.banner.running", { order: short, step: String(actRun.kind).toUpperCase() });
        liveCls = "running";
      } else if (!inputsReady) {
        bannerTxt = i18nT("mag.banner.need_gen");
      } else if (!verified) {
        bannerTxt = i18nT("phases.mag.banner.verify", { order: lab, nspin: String(ns) });
      } else if (row.scf_converged && cr.all_done && row.nscf_converged) {
        bannerTxt = i18nT("mag.banner.done", { order: short });
        liveCls = "ok";
      } else if (row.input_exists || (steps["vc-relax"] && steps["vc-relax"].input_exists)) {
        bannerTxt = i18nT("mag.banner.ready", { order: short });
      }
      banner.textContent = bannerTxt;
      banner.className = `mag-chain-banner${liveCls ? ` ${liveCls}` : ""}`;
    }
    paintMagLiveFromRow(row);
    syncMagPipeLiveFromRow(row);
    const spinHost = magCard.querySelector(".phases-mag-spin-host");
    if (spinHost) {
      spinHost.hidden = false;
      spinHost.innerHTML = magSpinOrientationBlock(order, row);
    }
    paintPhasesCalcStopBar();
    refreshRuns().catch(() => {});
    if (cardRunning && sessionConfirmed && material && !runsAutoTimer) {
      startRunsAutoRefresh();
    }
    if (inputsReady) refreshMagOrderInputAudit(order).catch(() => {});
    paintSessionMagSpinGallery();
  }

  let sessionMagOrderInputUpdateBusy = false;
  let suppressChainNspinChangeEvent = false;

  async function onSessionMagOrderChange() {
    syncSessionMagOrderFromUi();
    clearMagInputsVerified(getSessionMagOrder());
    paintSessionChainPlan();
    const mat = resolveSessionStructureMaterial();
    if (!mat || !structurePanelUnlocked()) return;
    if (sessionMagOrderInputUpdateBusy) return;
    const status = $("phase-cif-status");
    const order = getSessionMagOrder();
    const orderLab = sessionMagOrderShort(order);
    const ns = nspinForMagOrder(order);
    const isBundle = order === "fm";
    sessionMagOrderInputUpdateBusy = true;
    paintSessionMagOrderControlsEnabled();
    try {
      const inputs = await fetchNmInputsForMaterial(mat);
      const hasVc = inputs.some((r) => r.kind === "vc-relax");
      if (!hasVc) {
        if (status) {
          status.hidden = false;
          status.textContent = i18nT("session.mag_order.need_generate", { order: orderLab });
          status.className = "meta";
        }
        return;
      }
      if (status) {
        status.hidden = false;
        status.textContent = isBundle
          ? i18nT("session.mag_order.updating_bundle")
          : (order === "nm"
            ? i18nT("session.mag_order.updating_nspin", { nspin: String(ns) })
            : i18nT("session.mag_order.updating_order", { order: orderLab, nspin: String(ns) }));
        status.className = "meta";
      }
      const res = await refreshInputsForSessionMagOrder({ material: mat, silent: false });
      await refreshSessionStructureUI(mat);
      await paintSessionMagInputMode(mat).catch(() => {});
      paintPhasesCalculsChainPanel();
      if (status) {
        if (res && res.ok) {
          status.textContent = res.bundle
            ? i18nT(PHASES_PREP_ONLY ? "session.mag_order.ready_bundle_prep" : "session.mag_order.ready_bundle", { order: orderLab })
            : (order === "nm"
              ? i18nT("session.mag_order.ready_nspin", { nspin: String(ns) })
              : i18nT(PHASES_PREP_ONLY ? "session.mag_order.ready_order_prep" : "session.mag_order.ready_order", { order: orderLab, nspin: String(ns) }));
          status.className = "meta status-ok";
        } else if (res && !res.skipped && res.error) {
          status.textContent = res.error;
          status.className = "meta";
        }
      }
    } catch (e) {
      if (status) {
        status.textContent = e.message || String(e);
        status.className = "meta";
      }
    } finally {
      sessionMagOrderInputUpdateBusy = false;
      paintSessionMagOrderControlsEnabled();
    }
    if (structurePanelUnlocked()) {
      await paintSessionNextActionCue(mat, { scroll: false }).catch(() => {});
      await refreshMagOrderInputAudit(getSessionMagOrder()).catch(() => {});
    }
  }

  async function onSessionChainNspinChange() {
    paintSessionChainPlan();
    if (suppressChainNspinChangeEvent) return;
    if (getSessionMagOrder() !== "nm") return;
    const mat = resolveSessionStructureMaterial();
    if (!mat || !structurePanelUnlocked()) return;
    const status = $("phase-cif-status");
    const ns = getSessionChainNspin();
    try {
      if (status) {
        status.hidden = false;
        status.textContent = i18nT("session.mag_order.updating_nspin", { nspin: String(ns) });
        status.className = "meta";
      }
      const res = await refreshInputsForSessionMagOrder({ material: mat, silent: false, nspin: ns });
      await refreshSessionStructureUI(mat);
      if (status && res && res.ok) {
        status.textContent = i18nT("session.mag_order.ready_nspin", { nspin: String(ns) });
        status.className = "meta status-ok";
      }
      if (structurePanelUnlocked()) {
        await paintSessionNextActionCue(mat, { scroll: false }).catch(() => {});
      }
    } catch (e) {
      if (status) {
        status.textContent = e.message || String(e);
        status.className = "meta";
      }
    }
  }

  function onSessionInputPickChange() {
    paintSessionChainPlan();
    const kind = getSelectedInputKind();
    if (kind && lastStructureSource) paintStructureSource(lastStructureSource);
  }

  async function generateAllInputsFromCif(opts = {}) {
    const mat = structureEditMaterial() || getDraftMaterial() || material;
    if (!mat) {
      alert(i18nT("alert.pick_mat"));
      return false;
    }
    const cifName = getSelectedCifName();
    if (!cifName) {
      if (!opts.silent) alert(i18nT("session.cif.need_pick"));
      return false;
    }
    syncSessionMagOrderFromUi();
    const magOrder = getSessionMagOrder();
    const orderLab = sessionMagOrderShort(magOrder);
    const status = $("phase-cif-status");
    if (status) {
      status.hidden = false;
      status.textContent = "…";
    }
    const cifPath = getSelectedCifPath();
    const body = withPhaseBody({
      overwrite: true,
      cif_name: cifName,
      ...(cifPath ? { cif_path: cifPath } : {}),
    });
    const data = await api(`/api/materials/${encodeURIComponent(mat)}/cif/to-vcrelax`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    log("log-opt", data.message || data, !!data.ok);
    if (!data.ok) {
      if (status) {
        status.textContent = data.error || data.message || "";
        status.className = "meta";
      }
      return false;
    }
    if (magOrder === "nm") {
      const derived = await api(
        `/api/materials/${encodeURIComponent(mat)}/derive-from-vcrelax`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(withPhaseBody({ overwrite: true })),
        }
      ).catch(() => ({ ok: false }));
      if (!derived.ok && !opts.silent) {
        log("log-opt", derived.error || i18nT("session.cif.derive_fail"), false);
      }
      if (status) {
        status.textContent = data.message || i18nT("session.cif.generated");
        status.className = "meta status-ok";
      }
      if (!opts.silent) log("log-opt", i18nT("session.cif.generated"), true);
    } else {
      const afmList = await fetchAvailableAfmOrders(mat);
      const orders = ordersForMagInputRefresh(magOrder, afmList);
      const prep = await prepareMagOrders(orders.length ? orders : [magOrder], {
        silent: true,
        material: mat,
        allowBeforeConfirm: true,
      });
      if (!prep || !prep.ok) {
        const err = (prep && prep.error) || i18nT("mag.prepare.fail");
        if (status) {
          status.textContent = err;
          status.className = "meta";
        }
        if (!opts.silent) log("log-opt", err, false);
        return false;
      }
      const msg = magOrder === "fm" && orders.length > 1
        ? i18nT("session.mag_order.ready_bundle", { order: orderLab })
        : i18nT("session.cif.generated_mag", { order: orderLab });
      if (status) {
        status.textContent = msg;
        status.className = "meta status-ok";
      }
      if (!opts.silent) log("log-opt", msg, true);
    }
    await refreshCifList(mat).catch(() => {});
    if (isDualStudyIntent()) {
      await refreshDualStructureStatuses().catch(() => {});
      paintDualCifNextHint();
      // Après mat I prêt : proposer mat II automatiquement si manquant
      const a = getDualMaterialA();
      const b = getDualMaterialB();
      const readyA = !!(lastStructureSourceA && lastStructureSourceA.vc_relax_exists);
      const readyB = !!(lastStructureSourceB && lastStructureSourceB.vc_relax_exists);
      if (readyA && !readyB && structureEditMaterial() === a && b) {
        setDualCifTarget("b");
      }
    } else {
      await refreshStructureSource(mat);
    }
    await refreshSessionStructureUI(structureEditMaterial() || mat);
    await paintSessionMagInputMode(structureEditMaterial() || mat).catch(() => {});
    await refreshMagOrders({ light: true }).catch(() => {});
    await paintSessionNextActionCue(structureEditMaterial() || mat, { scroll: false }).catch(() => {});
    if (magOrder !== "nm") await refreshMagOrderInputAudit(magOrder).catch(() => {});
    return true;
  }

  async function ensureEndpointMaterialReady(endpointMat) {
    const m = String(endpointMat || "").trim();
    if (!m) return false;
    const src = await fetchStructureSource(m, "");
    const inputs = await fetchNmInputsForMaterial(m);
    const hasVc = inputs.some((r) => r.kind === "vc-relax") || !!src?.vc_relax_exists;
    if (hasVc) {
      await bootstrapNmInputs(m, { silent: true, sync_followups: false }).catch(() => {});
      return true;
    }
    return false;
  }

  async function ensureStructureReadyBeforeStart(mat) {
    if (isDualStudyIntent()) {
      if (!String(mat || "").trim()) return false;
      const okA = await ensureEndpointMaterialReady(getDualMaterialA());
      const okB = await ensureEndpointMaterialReady(getDualMaterialB());
      return okA && okB;
    }
    await refreshStructureSource(mat);
    const inputs = await fetchNmInputsForMaterial(mat);
    const hasVc = inputs.some((r) => r.kind === "vc-relax") || !!lastStructureSource?.vc_relax_exists;
    if (hasVc) {
      await bootstrapNmInputs(mat, { silent: true, sync_followups: false }).catch(() => {});
      return true;
    }
    if (getSelectedCifName()) {
      const ok = await generateAllInputsFromCif({ silent: true });
      if (ok) await bootstrapNmInputs(mat, { silent: true, sync_followups: false }).catch(() => {});
      return ok;
    }
    return inputs.some((r) => r.kind === "vc-relax");
  }

  async function prepareDualEndpointInputs() {
    await Promise.all([
      ensureEndpointMaterialReady(getDualMaterialA()),
      ensureEndpointMaterialReady(getDualMaterialB()),
    ]);
  }

  function prefillSqsPhaseSelectsFromEndpoints() {
    const selA = $("sqs-phase-a");
    const selB = $("sqs-phase-b");
    if (!selA || !selB || selA.disabled) return;
    const a = getDualMaterialA().toLowerCase();
    const b = getDualMaterialB().toLowerCase();
    const pickFor = (sym) => {
      for (const opt of selA.options) {
        const v = (opt.value || "").toLowerCase();
        const t = (opt.textContent || "").toLowerCase();
        if (v && (v.includes(sym) || t.includes(sym))) return opt.value;
      }
      return "";
    };
    if (!selA.value && a) selA.value = pickFor(a) || selA.options[1]?.value || "";
    if (!selB.value && b) {
      const vb = pickFor(b);
      if (vb && vb !== selA.value) selB.value = vb;
      else if (selB.options.length > 2) {
        const alt = [...selB.options].find((o) => o.value && o.value !== selA.value);
        if (alt) selB.value = alt.value;
      }
    }
  }

  async function launchSingleMaterialNmChain() {
    await bootstrapNmInputs(material, { silent: true, sync_followups: true }).catch(() => {});
    await refreshOptimStatus().catch(() => {});
    paintSessionChainPlan();
    const steps = lastOptimStatus?.steps || {};
    const cr = lastOptimStatus?.chain_resume || {};
    const kind = chainStartKind(cr, steps, CHAIN_KINDS_NM);
    if (!kind) {
      log("log-opt", i18nT("session.chain.plan_nm_done"), true);
      return;
    }
    log("log-opt", i18nT("session.chain.start_nm", { kind: kind.toUpperCase() }), true);
    await runNmChainKind(kind, { forceServerChain: true });
  }

  function scrollToDopingVerify() {
    $("doping-verify-block")?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  async function beginSqsStudyItinerary() {
    log("log-opt", i18nT("session.chain.start_sqs"), true);
    await prepareDualEndpointInputs();
    await refreshPhasesForDraft();
    prefillSqsPhaseSelectsFromEndpoints();
    if (PHASES_PREP_ONLY) {
      switchSessionWorkTab("preparation");
      switchSessionSubTab("preparation", "prep-nondope");
      requestAnimationFrame(() => {
        $("phase-sqs-card")?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
      await refreshMaterialIoProfile().catch(() => {});
      return;
    }
    paintCalculNondopeLayout();
    await refreshPhaseStability();
    switchSessionWorkTab("calcul");
    switchSessionSubTab("calcul", "calc-nondope");
    requestAnimationFrame(() => {
      $("phase-stability-card")?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
    const rows = (lastPhaseStability && lastPhaseStability.phases) || [];
    const needChain = rows.some(
      (r) => r.phase_id && !(r.chain_resume && r.chain_resume.all_done) && !r.running
    );
    const btnAll = $("btn-phase-chains-all");
    if (needChain && btnAll && !btnAll.disabled) {
      await runAllPhaseChains();
    }
  }

  async function beginDopingStudyItinerary() {
    log("log-opt", i18nT("session.chain.start_doping"), true);
    if (isDualStudyIntent()) await prepareDualEndpointInputs();
    await refreshPhasesForDraft();
    await refreshDopingHostElements().catch(() => {});
    if ($("session-panel-preparation")?.hidden) switchSessionWorkTab("preparation");
    if (sessionPrepSubTab !== "prep-doped") switchSessionSubTab("preparation", "prep-doped");
    requestAnimationFrame(() => {
      $("phase-doping-card")?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
    await refreshPhaseStability().catch(() => {});
  }

  async function startStudyChainFromSession() {
    if (!material || !sessionConfirmed) return;
    if (PHASES_PREP_ONLY) {
      switchSessionWorkTab("resultats");
      await refreshMaterialIoProfile().catch(() => {});
      return;
    }
    syncSessionMagOrderFromUi();
    const magOrder = getSessionMagOrder();
    if (magOrder !== "nm") {
      const ready = await ensureMagChainReadyBeforeRun(magOrder);
      if (!ready) return;
      nspinChoice = String(nspinForMagOrder(magOrder));
      log(
        "log-opt",
        i18nT("session.chain.start_mag_order", { order: sessionMagOrderShort(magOrder) }),
        true
      );
      await runMagOrder(magOrder, "vc-relax").catch((e) => alert(e.message));
      return;
    }
    const ns = getSessionChainNspin();
    nspinChoice = String(ns);
    if (ns === 2) {
      log(
        "log-opt",
        i18nT("session.chain.nspin.note"),
        true
      );
    }
    await applySpinToInputs({ material, silent: false, nspin: ns });
    const intent = sessionStudyIntent();
    if (intent === "sqs") {
      await beginSqsStudyItinerary();
      return;
    }
    if (intent === "doping") {
      await beginDopingStudyItinerary();
      return;
    }
    await launchSingleMaterialNmChain();
  }

  function setSessionValidateStatus(text, extraClass) {
    const st = $("session-validate-status")
      || (isDualStudyIntent() ? $("session-dual-validate-status") : $("session-single-validate-status"));
    if (!st) return;
    st.textContent = text || "";
    st.className = `meta session-validate-status${extraClass ? ` ${extraClass}` : ""}`;
  }

  async function validateSingleMaterial() {
    const m = getDraftMaterial();
    singleMaterialValidated = false;
    localStorage.setItem("optimqe.singleValidated", "0");
    paintStructurePanelVisibility();
    if (!m) {
      setSessionValidateStatus(i18nT("alert.pick_mat"), "warn");
      paintSessionStepHint();
      return false;
    }
    await refreshMaterialType(m).catch(() => {});
    await refreshPhasesForDraft().catch(() => {});
    await refreshJobsForDraft().catch(() => {});
    await refreshCifList(m).catch(() => {});
    await refreshStructureSource(m);
    singleMaterialValidated = true;
    localStorage.setItem("optimqe.singleValidated", "1");
    setSessionValidateStatus(i18nT("session.single.ok"), "status-ok");
    paintStructurePanelVisibility();
    await refreshSessionStructureUI(m);
    paintSessionStepHint();
    const inputs = await fetchNmInputsForMaterial(m);
    const hasVc = inputs.some((r) => r.kind === "vc-relax") || !!lastStructureSource?.vc_relax_exists;
    if (hasVc) {
      await refreshInputsForSessionMagOrder({ material: m, silent: true }).catch(() => {});
      await refreshSessionStructureUI(m);
    }
    await paintSessionNextActionCue(m);
    return true;
  }

  function invalidateSingleMaterial() {
    singleMaterialValidated = false;
    localStorage.setItem("optimqe.singleValidated", "0");
    if (!isDualStudyIntent()) setSessionValidateStatus("", "");
    const stCif = $("phase-cif-status");
    if (stCif) {
      stCif.textContent = "";
      stCif.hidden = true;
    }
    paintStructurePanelVisibility();
    paintSessionStepHint();
  }

  function structureOriginLabel(data) {
    const src = data || lastStructureSource;
    if (!src) return i18nT("session.origin.unknown");
    if (src.vc_relax_exists) return i18nT("session.origin.vcrelax");
    if (src.source === "cif") {
      return i18nT("session.origin.cif_only", { name: src.cif_name || "CIF" });
    }
    return i18nT("session.origin.unknown");
  }

  function paintStructureSourceMini(data, statusId) {
    const el = $(statusId);
    if (!el) return;
    if (!data) {
      el.textContent = i18nT("session.origin.pick_mat");
      el.className = "session-mat-mini-status meta";
      return;
    }
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    const msg = lang === "en" ? (data.message_en || data.message_fr) : (data.message_fr || data.message_en);
    el.textContent = msg || structureOriginLabel(data);
    el.className = data.vc_relax_exists
      ? "session-mat-mini-status meta status-ok"
      : (data.source === "cif" ? "session-mat-mini-status meta warn" : "session-mat-mini-status meta");
  }

  function paintStructureSource(data) {
    const el = $("session-origin-status");
    if (!data) {
      if (el) {
        el.textContent = i18nT("session.origin.pick_mat");
        el.className = "meta session-origin-status";
      }
      return;
    }
    let headline = structureOriginLabel(data);
    if (data.vc_relax_exists) headline = i18nT("session.origin.ready_short");
    else if (data.source === "cif" && data.cif_name) {
      headline = `${i18nT("session.origin.cif_found", { name: data.cif_name })} ${i18nT("session.origin.cif_action_short")}`;
    } else if (data.source === "none" || !data.ok) {
      headline = i18nT("session.origin.need_short");
    }
    if (el) {
      el.textContent = headline;
      el.className = data.vc_relax_exists
        ? "meta session-origin-status status-ok"
        : (data.source === "cif" ? "meta session-origin-status warn" : "meta session-origin-status");
    }
  }

  function paintSessionOriginTarget() {
    const el = $("session-origin-target");
    if (!el) return;
    // Remplacé par le switch Matériau I / II (chips) en mode dual.
    if (!isDualStudyIntent()) {
      el.hidden = true;
      el.textContent = "";
      return;
    }
    el.hidden = true;
    el.textContent = "";
    paintDualCifSwitch();
  }

  function dualCifStatusKey(data, matName) {
    if (!matName) return "session.dual.status.empty";
    if (data && data.vc_relax_exists) return "session.dual.status.ready";
    if (data && data.source === "cif" && data.cif_name) return "session.dual.status.cif";
    return "session.dual.status.need";
  }

  function paintDualCifSwitch() {
    const wrap = $("session-dual-cif-target-wrap");
    if (!wrap) return;
    const dual = isDualStudyIntent() && dualMaterialsValidated && structurePanelUnlocked();
    wrap.hidden = !dual;
    wrap.classList.toggle("is-visible", dual);
    if (!dual) {
      const next = $("session-dual-cif-next");
      if (next) {
        next.hidden = true;
        next.textContent = "";
      }
      return;
    }
    const a = getDualMaterialA();
    const b = getDualMaterialB();
    const sel = $("session-dual-cif-target");
    const side = (sel?.value || "a").toLowerCase() === "b" ? "b" : "a";
    const nameA = $("dual-cif-name-a");
    const nameB = $("dual-cif-name-b");
    const stA = $("dual-cif-status-a");
    const stB = $("dual-cif-status-b");
    const btnA = $("btn-dual-cif-a");
    const btnB = $("btn-dual-cif-b");
    const sideA = $("dual-cif-side-a");
    const sideB = $("dual-cif-side-b");
    const dopingEnds = sessionStudyIntent() === "doping" && sessionDopingCase() === "endpoints";
    if (sideA) {
      sideA.textContent = dopingEnds ? i18nT("session.dual.mat_host") : i18nT("session.dual.target_a");
    }
    if (sideB) {
      sideB.textContent = dopingEnds ? i18nT("session.dual.mat_dopant") : i18nT("session.dual.target_b");
    }
    if (nameA) nameA.textContent = a || "—";
    if (nameB) nameB.textContent = b || "—";
    const keyA = dualCifStatusKey(lastStructureSourceA, a);
    const keyB = dualCifStatusKey(lastStructureSourceB, b);
    if (stA) {
      stA.textContent = i18nT(keyA);
      stA.className = `dual-cif-status meta${keyA.includes("ready") ? " is-ready" : keyA.includes("cif") ? " is-warn" : ""}`;
    }
    if (stB) {
      stB.textContent = i18nT(keyB);
      stB.className = `dual-cif-status meta${keyB.includes("ready") ? " is-ready" : keyB.includes("cif") ? " is-warn" : ""}`;
    }
    if (btnA) {
      btnA.classList.toggle("is-active", side === "a");
      btnA.setAttribute("aria-selected", side === "a" ? "true" : "false");
    }
    if (btnB) {
      btnB.classList.toggle("is-active", side === "b");
      btnB.setAttribute("aria-selected", side === "b" ? "true" : "false");
    }
    if (sel && sel.value !== side) sel.value = side;
    paintDualCifNextHint();
  }

  function paintDualCifNextHint() {
    const next = $("session-dual-cif-next");
    if (!next) return;
    if (!isDualStudyIntent() || !dualMaterialsValidated) {
      next.hidden = true;
      next.textContent = "";
      return;
    }
    const a = getDualMaterialA();
    const b = getDualMaterialB();
    const readyA = !!(lastStructureSourceA && lastStructureSourceA.vc_relax_exists);
    const readyB = !!(lastStructureSourceB && lastStructureSourceB.vc_relax_exists);
    const side = ($("session-dual-cif-target")?.value || "a").toLowerCase() === "b" ? "b" : "a";
    if (readyA && readyB) {
      next.hidden = false;
      next.textContent = i18nT("session.dual.both_ready");
      next.className = "meta session-dual-cif-next status-ok";
      return;
    }
    if (readyA && !readyB && side === "a") {
      next.hidden = false;
      next.textContent = i18nT("session.dual.next_b", { a: a || "I", b: b || "II" });
      next.className = "meta session-dual-cif-next";
      return;
    }
    if (readyB && !readyA && side === "b") {
      next.hidden = false;
      next.textContent = i18nT("session.dual.next_a", { a: a || "I", b: b || "II" });
      next.className = "meta session-dual-cif-next";
      return;
    }
    next.hidden = true;
    next.textContent = "";
  }

  function setDualCifTarget(side, opts = {}) {
    const s = side === "b" ? "b" : "a";
    const sel = $("session-dual-cif-target");
    if (sel) sel.value = s;
    paintDualCifSwitch();
    if (!opts.skipRefresh) {
      refreshDualStructureStatuses().catch(() => {});
    }
  }

  async function fetchStructureSource(mat, phaseOverride) {
    const m = String(mat || "").trim();
    if (!m) return null;
    const pid = phaseOverride != null ? phaseOverride : (getDraftPhase() || phaseId || "");
    const q = pid ? `?phase_id=${encodeURIComponent(pid)}` : "";
    try {
      return await api(`/api/materials/${encodeURIComponent(m)}/structure-source${q}`);
    } catch {
      return null;
    }
  }

  async function refreshDualStructureSide(side) {
    const mat = side === "b" ? getDualMaterialB() : getDualMaterialA();
    const data = await fetchStructureSource(mat, "");
    if (side === "b") lastStructureSourceB = data;
    else lastStructureSourceA = data;
    paintStructureSourceMini(data, side === "b" ? "session-origin-status-b" : "session-origin-status-a");
    return data;
  }

  async function refreshDualStructureStatuses() {
    await Promise.all([
      refreshDualStructureSide("a"),
      refreshDualStructureSide("b"),
    ]);
    const active = structureEditMaterial();
    if (active) {
      const data = await fetchStructureSource(active, "");
      lastStructureSource = data;
      paintStructureSource(data);
      await refreshCifList(active).catch(() => {});
      await refreshSessionStructureUI(active).catch(() => {});
    } else {
      lastStructureSource = null;
      paintStructureSource(null);
    }
    paintSessionOriginTarget();
  }

  async function refreshStructureSource(matName) {
    if (isDualStudyIntent() && !matName) {
      return refreshDualStructureStatuses();
    }
    const mat = (matName || getDraftMaterial() || material || "").trim();
    if (!mat) {
      lastStructureSource = null;
      paintStructureSource(null);
      paintSessionOriginTarget();
      return null;
    }
    const data = await fetchStructureSource(mat);
    lastStructureSource = data;
    paintStructureSource(data);
    paintSessionOriginTarget();
    if (sessionConfirmed && material === mat) paintSessionBar();
    if (structurePanelUnlocked()) refreshSessionStructureUI(mat).catch(() => {});
    return data;
  }

  function paintSessionIntentUI() {
    const intent = sessionStudyIntent();
    const dualMode = isDualStudyIntent();
    const dual = $("session-flow-dual");
    const btnSingle = $("btn-validate-single-material");
    const btnDual = $("btn-validate-dual-materials");
    const leadN = $("session-card-lead-nondope");
    const leadD = $("session-card-lead-doped");
    const composeHint = $("session-compose-hint");
    const labelA = $("session-mat-a-label");
    const labelB = $("session-mat-b-label");
    if (btnSingle) btnSingle.hidden = dualMode;
    if (btnDual) btnDual.hidden = !dualMode;
    if (dual) dual.hidden = !dualMode;
    if (dualMode) setSessionValidateStatus("", "");
    else if (!singleMaterialValidated) setSessionValidateStatus("", "");
    document.querySelectorAll(".session-dual-only").forEach((node) => {
      node.hidden = !dualMode;
    });
    const matSingle = $("session-mat-single-wrap");
    const matA = $("session-mat-a-wrap");
    const matB = $("session-mat-b-wrap");
    const intentRow = $("session-intent-mat-row");
    if (intentRow) intentRow.classList.toggle("session-intent-mat-row-dual", dualMode);
    if (matSingle) matSingle.hidden = dualMode;
    if (matA) matA.hidden = !dualMode;
    if (matB) matB.hidden = !dualMode;
    const dualPhaseWrap = $("session-phase-dual-wrap");
    if (dualPhaseWrap) dualPhaseWrap.hidden = !dualMode;
    const leadSingle = i18nT("session.lead.single");
    if (leadN) {
      leadN.textContent =
        intent === "single" || (intent === "doping" && !dualMode)
          ? leadSingle
          : i18nT("session.prep.lead.nondope");
    }
    if (leadD) {
      leadD.textContent =
        sessionDopingCase() === "single"
          ? i18nT("session.prep.lead.doped_single")
          : i18nT("session.prep.lead.doped");
    }
    const pathHint = $("session-intent-path-hint");
    if (pathHint) {
      pathHint.textContent =
        intent === "doping"
          ? i18nT("session.intent.path.doped")
          : i18nT("session.intent.path.nondope");
    }
    if (composeHint) {
      composeHint.textContent = intent === "doping"
        ? i18nT("session.compose.hint_doping")
        : i18nT("session.compose.hint_sqs");
    }
    if (labelA) {
      labelA.textContent =
        intent === "doping" && sessionDopingCase() === "endpoints"
          ? i18nT("session.dual.mat_host")
          : i18nT("session.dual.mat_a");
    }
    if (labelB) {
      labelB.textContent =
        intent === "doping" && sessionDopingCase() === "endpoints"
          ? i18nT("session.dual.mat_dopant")
          : i18nT("session.dual.mat_b");
    }
    const finalLabel = document.querySelector("#session-dual-compose .session-field-label");
    if (finalLabel) {
      finalLabel.textContent =
        intent === "doping" ? i18nT("session.compose.final_doping") : i18nT("session.compose.final");
    }
    const compose = $("session-dual-compose");
    if (compose) {
      compose.hidden = !isDualStudyIntent() || !dualMaterialsValidated;
    }
    paintSessionStepHint();
    paintSessionOriginTarget();
    paintStructurePanelVisibility();
    paintSessionChainPlan();
    paintPhaseStudyMode();
  }

  function paintPhaseStudyMode() {
    const intent = sessionStudyIntent();
    const sqs = $("phase-sqs-card");
    const dop = $("phase-doping-card");
    const showDoping = intent === "doping";
    const showSqs = intent === "sqs";
    if (sqs) sqs.hidden = !showSqs;
    if (dop) dop.hidden = !showDoping;
    document.querySelectorAll(".phase-allotrope-only").forEach((el) => {
      el.hidden = intent === "doping" || intent === "sqs";
    });
    const stabHead = $("phase-stability-card")?.querySelector(".result-card-head h3");
    const stabNote = $("phase-stability-note");
    if (stabHead && stabNote) {
      if (showDoping && !showSqs) {
        stabHead.textContent = i18nT("phase.stability.title.doping");
        stabNote.textContent = i18nT("phase.stability.hint.doping");
      } else if (showSqs) {
        stabHead.textContent = i18nT("phase.stability.title.sqs");
        stabNote.textContent = i18nT("phase.stability.hint.sqs");
      } else {
        stabHead.textContent = i18nT("phase.stability.title");
        stabNote.textContent = i18nT("phase.stability.hint");
      }
    }
    paintPhaseStabilityHost();
    paintCalcSubTabChrome();
    syncPhaseDopingMaterials();
    paintPhaseDopingFormCompact();
    updateDopingActionsEnabled();
    if (showDoping) refreshDopingDiskListing().catch(() => {});
    updateDopingLaunchGate();
    const calcPanel = $("session-panel-calcul");
    if (calcPanel && !calcPanel.hidden) paintCalculNondopeLayout();
  }

  function dopingVerifyGateActive() {
    if (sessionStudyIntent() !== "doping") return false;
    const card = $("phase-doping-card");
    return !!(card && !card.hidden);
  }

  function isDopingVerifiedForLaunch() {
    if (PHASES_PREP_ONLY) return true;
    if (!dopingVerifyGateActive()) return true;
    return !!($("doping-verified-check") && $("doping-verified-check").checked);
  }

  function updateDopingLaunchGate(hasDopingFiles) {
    const vblock = $("doping-verify-block");
    const msg = $("doping-launch-gate-msg");
    const stab = $("phase-stability-card");
    if (PHASES_PREP_ONLY) {
      if (vblock) vblock.hidden = true;
      if (msg) msg.hidden = true;
      if (stab) stab.classList.remove("doping-launch-locked");
      return;
    }
    const need = dopingVerifyGateActive();
    const verified = isDopingVerifiedForLaunch();
    const hasFiles =
      hasDopingFiles === true ||
      !!($("doping-preview-body") && $("doping-preview-body").querySelector(".doping-row-inter"));
    if (vblock) vblock.hidden = !need || !hasFiles;
    if (msg) msg.hidden = !need || verified || !hasFiles;
    if (stab) stab.classList.toggle("doping-launch-locked", need && hasFiles && !verified);
    if (lastPhaseStability && lastPhaseStability.phases) paintPhaseStability(lastPhaseStability);
  }

  function parseDopingPhasePct(phaseId) {
    const m = String(phaseId || "").match(/_(\d+)$/);
    return m ? parseInt(m[1], 10) : null;
  }

  /** Matériau job dopé (dossier GdCrO3_doped) pour API / mag / inventaire dopé. */
  function studyJobMaterial() {
    const job = (getPhaseDopingJobMaterial() || "").trim();
    if (sessionStudyIntent() === "doping" && job) return job;
    return (material || getDraftMaterial() || "").trim();
  }

  function isDopedPhaseId(pid) {
    return /^dop_/i.test(String(pid || "").trim());
  }

  function getPhaseDopingJobMaterial() {
    const finalJob = ($("material-final")?.value || "").trim();
    const cardJob = ($("phase-doping-material")?.value || "").trim();
    const raw =
      (sessionStudyIntent() === "doping" && (finalJob || cardJob)) ||
      cardJob ||
      finalJob ||
      (sessionStudyIntent() === "doping" ? "" : material) ||
      (sessionStudyIntent() === "doping" ? "" : getDraftMaterial()) ||
      "";
    if (sessionStudyIntent() !== "doping") return String(raw || "").trim();
    return suggestDopedJobFolder(
      getPhaseDopingParentA(),
      raw,
      getPhaseDopingParentB()
    );
  }

  /** Dossier job dopé distinct du parent (ex. GdCrO3 → GdCrO3_doped). */
  function suggestDopedJobFolder(parentA, jobCandidate, parentB) {
    const pa = normalizeMaterialInput(parentA || "");
    const pb = normalizeMaterialInput(parentB || "");
    let job = normalizeMaterialInput(jobCandidate || "");
    if (!pa) return job;
    if (!job || job === pa || (pb && job === pb)) return `${pa}_doped`;
    return job;
  }

  function applyDopedJobMaterialToUi(jobName) {
    const j = normalizeMaterialInput(jobName || "");
    if (!j) return;
    const jobEl = $("phase-doping-material");
    if (jobEl && normalizeMaterialInput(jobEl.value) !== j) jobEl.value = j;
    if (sessionStudyIntent() === "doping") {
      const fin = $("material-final");
      if (fin && normalizeMaterialInput(fin.value) !== j) fin.value = j;
    }
  }

  function normalizeDopedJobFromParents(opts = {}) {
    const silent = opts.silent !== false;
    const pa = getPhaseDopingParentA();
    const pb = getPhaseDopingParentB();
    if (!pa) return false;
    const current = getPhaseDopingJobMaterial();
    const fixed = suggestDopedJobFolder(pa, current, pb);
    if (!fixed || normalizeMaterialInput(current) === fixed) return false;
    applyDopedJobMaterialToUi(fixed);
    if (!silent) {
      const st = $("doping-status");
      if (st) {
        st.textContent = i18nT("phase.doping.job_auto_fixed", { job: fixed, parent: pa });
        st.className = "meta status-ok";
      }
    }
    return true;
  }

  function getPhaseDopingParentA() {
    return (
      ($("phase-doping-parent-a")?.value || "").trim() ||
      getDualMaterialA() ||
      ($("material-select-a")?.value || "").trim() ||
      ($("material-select")?.value || "").trim()
    );
  }

  function getPhaseDopingParentB() {
    return (
      ($("phase-doping-parent-b")?.value || "").trim() ||
      getDualMaterialB() ||
      ($("material-select-b")?.value || "").trim()
    );
  }

  let lastDopingSpecies = null;

  function syncPhaseDopingMaterials() {
    const job = $("phase-doping-material");
    const pa = $("phase-doping-parent-a");
    const pb = $("phase-doping-parent-b");
    const note = $("phase-doping-parents-note");
    const aVal =
      getDualMaterialA() ||
      ($("material-select-a")?.value || "").trim() ||
      ($("material-select")?.value || "").trim();
    const bVal = getDualMaterialB() || ($("material-select-b")?.value || "").trim();
    const compactDop = sessionStudyIntent() === "doping";
    if (pa && aVal && (compactDop || (pa.dataset.userEdited !== "1" && !pa.value.trim()))) pa.value = aVal;
    if (pb && bVal && (compactDop || (pb.dataset.userEdited !== "1" && !pb.value.trim()))) pb.value = bVal;
    let jobDefault = suggestDopedJobFolder(
      aVal,
      ($("material-final")?.value || "").trim() ||
        ($("phase-doping-material")?.value || "").trim() ||
        (aVal ? `${normalizeMaterialInput(aVal)}_doped` : ""),
      bVal
    );
    const fin = ($("material-final")?.value || "").trim();
    const finNorm = fin ? suggestDopedJobFolder(aVal, fin, bVal) : "";
    if (compactDop && finNorm) {
      if (job) job.value = finNorm;
      if ($("material-final") && normalizeMaterialInput(fin) !== finNorm) {
        $("material-final").value = finNorm;
      }
    } else if (job && job.dataset.userEdited !== "1") {
      if (
        !job.value.trim() ||
        (aVal && normalizeMaterialInput(job.value) === normalizeMaterialInput(aVal)) ||
        (bVal && normalizeMaterialInput(job.value) === normalizeMaterialInput(bVal))
      ) {
        job.value = jobDefault;
      }
    } else if (job && job.value.trim()) {
      const fixed = suggestDopedJobFolder(aVal, job.value, bVal);
      if (fixed !== normalizeMaterialInput(job.value)) job.value = fixed;
    }
    if (note) {
      const a = getPhaseDopingParentA();
      const b = getPhaseDopingParentB();
      const jobName = getPhaseDopingJobMaterial();
      if (compactDop && a && b && jobName) {
        note.textContent = i18nT("phase.doping.compact_line", { a, b, job: jobName });
      } else if (a && b) {
        note.textContent = i18nT("phase.doping.parents_line", { a, b });
      } else if (a) {
        note.textContent = i18nT("phase.doping.parent_a_only", { a });
      } else {
        note.textContent = "";
      }
    }
  }

  function paintPhaseDopingFormCompact() {
    const isDop = sessionStudyIntent() === "doping";
    const dopCase = sessionDopingCase();
    const card = $("phase-doping-card");
    if (card) {
      card.classList.toggle("phase-doping-compact", isDop);
      card.classList.toggle("phase-doping-case-endpoints", isDop && dopCase === "endpoints");
      card.classList.toggle("phase-doping-case-single", isDop && dopCase === "single");
    }

    const onDopedPrep = sessionPrepSubTab === "prep-doped";
    /* Ne pas masquer Objectif (barre au-dessus) — uniquement un éventuel champ dans § Matériau. */
    const intentInMat = $("session-block-mat")?.querySelector(".session-field-intent");
    if (intentInMat) intentInMat.hidden = onDopedPrep;

    const casesWrap = $("session-doping-cases");
    if (casesWrap) casesWrap.hidden = !isDop || !onDopedPrep;
    document.querySelectorAll(".doping-case-card").forEach((el) => {
      const inp = el.querySelector('input[name="session-doping-case"]');
      el.classList.toggle("is-active", !!(inp && inp.checked));
    });

    const parentAWrap = $("phase-doping-parent-a-wrap");
    const parentBWrap = $("phase-doping-parent-b-wrap");
    const jobWrap = $("phase-doping-job-wrap");
    const compose = $("session-dual-compose");
    const composeOpen = !!(compose && !compose.hidden);
    const hideDup = isDop && onDopedPrep;

    if (parentAWrap) parentAWrap.hidden = hideDup;
    if (parentBWrap) parentBWrap.hidden = hideDup || (isDop && dopCase === "single");
    if (jobWrap) {
      jobWrap.hidden =
        hideDup &&
        (dopCase === "endpoints"
          ? composeOpen || dualMaterialsValidated
          : singleMaterialValidated || !!(($("material-select")?.value || "").trim()));
    }

    const titleEl = $("phase-doping-card-title");
    const hintEl = $("phase-doping-hint") || card?.querySelector(".phase-doping-hint");
    if (titleEl && isDop) {
      const hostEl = getDopingHostElement();
      const dopEl = getSessionDopantElement();
      const gen =
        hostEl && dopEl && hostEl !== dopEl ? `${hostEl}(1-x)${dopEl}x` : "";
      if (gen) {
        titleEl.textContent = i18nT(
          dopCase === "single"
            ? "phase.doping.title_single_with_formula"
            : "phase.doping.title_endpoints_with_formula",
          { formula: gen }
        );
      } else {
        titleEl.textContent =
          dopCase === "single"
            ? i18nT("phase.doping.title_single")
            : i18nT("phase.doping.title_endpoints");
      }
    }
    if (hintEl && isDop) {
      hintEl.textContent =
        dopCase === "single"
          ? i18nT("phase.doping.hint_single")
          : i18nT("phase.doping.hint_short");
    }

    if (hideDup) syncPhaseDopingMaterials();
  }

  function elementsFromMaterialFormula(name) {
    const s = String(name || "").trim();
    if (!s) return [];
    const out = [];
    const re = /([A-Z][a-z]?)/g;
    let m;
    while ((m = re.exec(s)) !== null) {
      const el = m[1];
      if (!out.includes(el)) out.push(el);
    }
    return out;
  }

  function inferDopingPairFromParents(parentA, parentB) {
    const anionLike = dopingAnionLikeSet();
    const elsA = elementsFromMaterialFormula(parentA).filter((e) => e && !anionLike.has(e));
    const elsB = elementsFromMaterialFormula(parentB).filter((e) => e && !anionLike.has(e));
    if (!elsA.length || !elsB.length) return { host: "", dopant: "" };
    const hostCandidates = elsA.filter((e) => !elsB.includes(e));
    const dopantCandidates = elsB.filter((e) => !elsA.includes(e));
    const shared = elsA.filter((e) => elsB.includes(e));
    return {
      host: hostCandidates[0] || elsA.find((e) => e !== shared[0]) || elsA[0] || "",
      dopant: dopantCandidates[0] || "",
    };
  }

  function ensureDopingHostFromParents() {
    if (getDopingHostElement()) return;
    const pair = inferDopingPairFromParents(getPhaseDopingParentA(), getPhaseDopingParentB());
    if (!pair.host) return;
    const manual = $("doping-host-element-manual");
    const sel = $("doping-host-element");
    if (sel && !sel.hidden && !sel.disabled) {
      const has = [...sel.options].some((o) => o.value === pair.host);
      if (has) sel.value = pair.host;
      else if (manual) {
        manual.hidden = false;
        manual.disabled = false;
        if (!manual.value.trim()) manual.value = pair.host;
      }
    } else if (manual) {
      manual.hidden = false;
      manual.disabled = false;
      if (!manual.value.trim()) manual.value = pair.host;
    }
  }

  function dopingActionsPreviewReady() {
    ensureDopingHostFromParents();
    return !!(
      getPhaseDopingParentA() &&
      getDopingHostElement() &&
      getSessionDopantElement()
    );
  }

  function dopingActionsGenerateReady() {
    return dopingActionsPreviewReady() && selectedDopingFractions().length > 0;
  }

  function resolveDopingJobMaterial() {
    syncPhaseDopingMaterials();
    const pa = getPhaseDopingParentA();
    const pb = getPhaseDopingParentB();
    const before = normalizeMaterialInput(
      ($("material-final")?.value || "").trim() ||
        ($("phase-doping-material")?.value || "").trim() ||
        ""
    );
    const job = suggestDopedJobFolder(pa, before || getPhaseDopingJobMaterial(), pb);
    if (!job) return { job: "", errKey: "phase.doping.pick_job_mat" };
    if (normalizeMaterialInput(before) !== job) {
      applyDopedJobMaterialToUi(job);
      const st = $("doping-status");
      if (st && pa) {
        st.textContent = i18nT("phase.doping.job_auto_fixed", { job, parent: pa });
        st.className = "meta status-ok";
      }
    }
    if (
      (pa && job === normalizeMaterialInput(pa)) ||
      (pb && job === normalizeMaterialInput(pb))
    ) {
      return { job: "", errKey: "phase.doping.job_must_differ" };
    }
    return { job, errKey: "" };
  }

  function dopingApiMaterial(payload) {
    const fromPayload = (payload && payload.job_material || "").trim();
    if (fromPayload) {
      const pa = (payload.parent_material_a || getPhaseDopingParentA() || "").trim();
      if (pa && normalizeMaterialInput(fromPayload) === normalizeMaterialInput(pa)) return "";
      return fromPayload;
    }
    return resolveDopingJobMaterial().job;
  }

  function requireDopingRun() {
    if (!getPhaseDopingParentA()) {
      alert(i18nT("phase.doping.pick_parent_a"));
      return false;
    }
    const { job, errKey } = resolveDopingJobMaterial();
    if (!job) {
      alert(i18nT(errKey || "phase.doping.pick_job_mat"));
      $("phase-doping-material")?.focus();
      return false;
    }
    return true;
  }

  function updateDopingActionsEnabled() {
    const btnP = $("btn-doping-preview");
    const btnG = $("btn-doping-generate");
    if (btnP) btnP.disabled = !dopingActionsPreviewReady();
    if (btnG) btnG.disabled = !dopingActionsGenerateReady();
  }

  function getPhaseChainStartKind() {
    const picked = document.querySelector('input[name="phase-chain-start"]:checked');
    const v = (picked && picked.value) || localStorage.getItem("optimqe.phaseChainStart") || "vc-relax";
    return ["vc-relax", "relax", "scf"].includes(v) ? v : "vc-relax";
  }

  function paintPhaseChainStartChoice() {
    const v = localStorage.getItem("optimqe.phaseChainStart") || "vc-relax";
    document.querySelectorAll('input[name="phase-chain-start"]').forEach((el) => {
      el.checked = el.value === v;
    });
  }

  function phaseEditorMaterial(matOverride) {
    return (
      (matOverride || "").trim() ||
      material ||
      getPhaseDopingJobMaterial() ||
      getDraftMaterial() ||
      ""
    );
  }

  function phaseEditButtonsHtml(pid, jobMat, { compact, doping } = {}) {
    const m = phaseEditorMaterial(jobMat);
    const dis = !m ? "disabled" : "";
    const kinds = doping
      ? [
          ["vc-relax", i18nT("phase.edit.doping_vcrelax")],
          ["relax", i18nT("phase.edit.doping_relax")],
          ["scf", i18nT("phase.edit.doping_scf")],
          ["nscf", i18nT("phase.edit.doping_nscf")],
        ]
      : [
          ["vc-relax", compact ? i18nT("phase.edit.view_vcrelax") : i18nT("phase.edit.vcrelax")],
          ["relax", compact ? i18nT("phase.edit.view_relax") : i18nT("phase.edit.relax")],
          ["scf", compact ? i18nT("phase.edit.view_scf") : i18nT("phase.edit.scf")],
          ["nscf", compact ? i18nT("phase.edit.view_nscf") : i18nT("phase.edit.nscf")],
        ];
    return (
      `<span class="phase-edit-btns${compact ? " phase-edit-btns-inline" : ""}">` +
      kinds
        .map(
          ([k, lab]) =>
            `<button type="button" class="btn ghost btn-phase-edit btn-doping-phase-edit" data-phase="${escAttr(pid)}" data-kind="${escAttr(k)}" data-job-mat="${escAttr(m)}" ${dis} title="${escAttr(lab)}">${esc(lab)}</button>`
        )
        .join("") +
      `</span>`
    );
  }

  async function openPhaseEditor(phaseIdOverride, kind, matOverride) {
    const m = phaseEditorMaterial(matOverride);
    if (!m) {
      alert(i18nT("alert.pick_mat"));
      return;
    }
    const k = String(kind || "vc-relax").toLowerCase();
    const pid = phaseIdOverride != null ? String(phaseIdOverride) : phaseId || "";
    const magOrder = getSessionMagOrder();
    if (isDopedPhaseId(pid) && magOrder && magOrder !== "nm") {
      await openMagEditorForPhase(magOrder, k, m, pid);
      return;
    }
    magEditOrder = "";
    magEditKind = "scf";
    optimEditPhaseId = pid;
    optimEditPhaseMat = m;
    optimEditKind = k;
    const data = await api(
      `/api/materials/${encodeURIComponent(m)}/input/${encodeURIComponent(k)}${phaseQueryFor(pid)}`
    );
    if (data && data.ok === false) {
      alert(data.error || i18nT("alert.pick_mat"));
      return;
    }
    $("optim-modal-title").textContent = isDopedPhaseId(pid)
      ? i18nT("phase.edit.doping_nm_title", {
          phase: pid,
          kind: k.toUpperCase(),
        })
      : i18nT("phase.edit.modal_title", {
          phase: pid || i18nT("phase.principal"),
          kind: k.toUpperCase(),
        });
    $("optim-modal-path").textContent = data.path || "";
    $("optim-modal-text").value = data.content || "";
    paintOptimModalNspinAudit("", "");
    $("optim-modal").hidden = false;
  }

  function paintSessionStepHint() {
    const choiceOk = isDualStudyIntent() ? dualMaterialsValidated : singleMaterialValidated;
    const matBlock = $("session-block-mat");
    const structBlock = $("session-structure-panel");
    if (matBlock) matBlock.classList.toggle("session-block-done", choiceOk || sessionConfirmed);
    if (structBlock) structBlock.classList.toggle("session-block-current", (choiceOk || sessionConfirmed) && !sessionConfirmed);
  }

  function clearSessionActionPulse() {
    $("btn-confirm-session")?.classList.remove("is-session-action-pulse");
    $("btn-generate-all-inputs")?.classList.remove("is-session-action-pulse");
  }

  function nmInputsMatchNspin(inputs, wantNspin) {
    const want = wantNspin === 2 ? 2 : 1;
    const vc = (inputs || []).find((r) => r.kind === "vc-relax");
    const scf = (inputs || []).find((r) => r.kind === "scf");
    const okNs = (row) => {
      if (!row || row.nspin == null) return want === 1;
      return Number(row.nspin) === want;
    };
    return okNs(vc) && (!scf || okNs(scf));
  }

  async function sessionMagInputsMatchOrder(mat, magOrder, cachedInputs) {
    const m = String(mat || "").trim();
    if (!m) return false;
    const inputs = cachedInputs || (await fetchNmInputsForMaterial(m));
    const hasVc = inputs.some((r) => r.kind === "vc-relax") || !!lastStructureSource?.vc_relax_exists;
    if (!hasVc) return false;
    const order = String(magOrder || "nm").trim().toLowerCase();
    if (order === "nm") {
      const hasChain = ["relax", "scf"].every((k) => inputs.some((r) => r.kind === k));
      return hasChain && nmInputsMatchNspin(inputs, getSessionChainNspin());
    }
    await refreshMagOrders({ light: true, skipExtras: true, skipCaseRepaint: true }).catch(() => {});
    return magOrderInputsPrepared(magOrderRowFromLast(order));
  }

  /** Après matériau confirmé : clignoter Générer (pas d’inputs) ou Commencer (inputs + nspin OK). */
  async function paintSessionNextActionCue(matName, opts = {}) {
    if (!PHASES_ONLY) return;
    const choiceOk = isDualStudyIntent() ? dualMaterialsValidated : singleMaterialValidated;
    const mat = String(matName || resolveSessionStructureMaterial() || getDraftMaterial() || "").trim();
    const startBtn = $("btn-confirm-session");
    const genBtn = $("btn-generate-all-inputs");
    const statusEl = $("session-status");
    clearSessionActionPulse();
    if (sessionConfirmed || !choiceOk || !mat) {
      return;
    }
    syncSessionMagOrderFromUi();
    const magOrder = getSessionMagOrder();
    const inputs = await fetchNmInputsForMaterial(mat);
    const hasVc = inputs.some((r) => r.kind === "vc-relax") || !!lastStructureSource?.vc_relax_exists;

    if (!hasVc) {
      genBtn?.classList.add("is-session-action-pulse");
      if (statusEl) statusEl.textContent = i18nT("session.action.generate");
      if (opts.scroll !== false) {
        $("session-structure-panel")?.scrollIntoView({ behavior: "smooth", block: "nearest" });
      }
      return;
    }

    let ready = await sessionMagInputsMatchOrder(mat, magOrder, inputs);
    if (!ready) {
      await refreshInputsForSessionMagOrder({ material: mat, silent: true }).catch(() => {});
      ready = await sessionMagInputsMatchOrder(mat, magOrder);
    }
    if (ready) {
      startBtn?.classList.add("is-session-action-pulse");
      if (statusEl) {
        statusEl.textContent = PHASES_PREP_ONLY
          ? i18nT("session.action.prep_only_ready")
          : magOrder === "nm"
            ? i18nT("session.action.start_nm")
            : i18nT("session.action.start_mag", { order: sessionMagOrderShort(magOrder) });
      }
      if (opts.scroll !== false) {
        $("session-block-run")?.scrollIntoView({ behavior: "smooth", block: "nearest" });
      }
    } else if (statusEl) {
      statusEl.textContent = i18nT("session.action.need_sync");
    }
  }

  async function validateDualMaterials() {
    const a = getDualMaterialA();
    const b = getDualMaterialB();
    dualMaterialsValidated = false;
    const compose = $("session-dual-compose");
    if (compose) compose.hidden = true;
    if (!a || !b) {
      setSessionValidateStatus(i18nT("session.dual.need_both"), "warn");
      paintSessionStepHint();
      return false;
    }
    if (a === b) {
      setSessionValidateStatus(i18nT("session.dual.need_both"), "warn");
      paintSessionStepHint();
      return false;
    }
    await Promise.all([
      refreshDualStructureSide("a"),
      refreshDualStructureSide("b"),
    ]);
    dualMaterialsValidated = true;
    localStorage.setItem("optimqe.dualValidated", "1");
    localStorage.setItem("optimqe.materialA", a);
    localStorage.setItem("optimqe.materialB", b);
    if (compose) compose.hidden = false;
    const finalEl = $("material-final");
    if (sessionStudyIntent() === "sqs") {
      if (finalEl && !finalEl.value.trim()) finalEl.value = `${a}_${b}`;
    } else if (sessionStudyIntent() === "doping") {
      const dopedJob = suggestDopedJobFolder(a, finalEl?.value || "", b);
      applyDopedJobMaterialToUi(dopedJob);
      syncPhaseDopingMaterials();
      paintPhaseDopingFormCompact();
    } else if (finalEl && !finalEl.value.trim()) {
      finalEl.placeholder = `${a}_doped`;
    }
    setSessionValidateStatus(i18nT("session.dual.ok"), "status-ok");
    await refreshPhasesForDraft().catch(() => {});
    await refreshJobsForDraft().catch(() => {});
    paintStructurePanelVisibility();
    await refreshDualStructureStatuses();
    const active = structureEditMaterial();
    if (active) await refreshSessionStructureUI(active);
    paintSessionStepHint();
    if (sessionStudyIntent() === "doping") {
      await refreshDopingHostElements().catch(() => {});
    }
    await paintSessionNextActionCue(active || getDraftMaterial());
    return true;
  }

  function studyModeLabel(mode) {
    const m = mode || studyModeValue();
    if (m === "known") return i18nT("study.mode.known");
    if (m === "search") return i18nT("study.mode.search");
    return i18nT("study.mode.auto");
  }

  function fmMagRow() {
    const rows = (lastMagOrders && lastMagOrders.orders) || [];
    return rows.find((r) => r.order === "fm") || null;
  }

  function fmNeedsResume() {
    const fm = fmMagRow();
    if (!fm) return false;
    if (fm.running) return true;
    const steps = fm.steps || {};
    if (Object.values(steps).some((s) => s && s.running)) return true;
    return !!(fm.input_exists || fm.output_exists || fm.scf_converged);
  }

  function goToMagOrder(order) {
    const ord = (order || "fm").toLowerCase();
    if (!requireSessionConfirmed()) return;
    switchTab("magnetisme");
    refreshMagOrders()
      .then(() => {
        const rows = (lastMagOrders && lastMagOrders.orders) || [];
        const fm = rows.find((r) => r.order === ord) || {};
        const cr = fm.chain_resume || {};
        if (cr.prior_fail || cr.retry) {
          const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
          const msg = lang === "en" ? (cr.message_en || cr.message_fr) : (cr.message_fr || cr.message_en);
          if (msg) log("log-opt", msg, false);
        }
        const row = document.querySelector(`.mag-case-row[data-order="${ord}"]`);
        if (row) row.scrollIntoView({ behavior: "smooth", block: "center" });
      })
      .catch(() => {});
  }

  function paintSessionBar() {
    const setup = $("session-setup");
    const bar = $("matbar");
    // La bannière « Matériau en cours » (raccourcis FM / Changer matériau)
    // a été retirée : le formulaire de session reste donc toujours visible.
    if (setup) setup.hidden = false;
    if (bar) bar.classList.toggle("session-is-active", !!(sessionConfirmed && material));
  }

  function editSession() {
    sessionConfirmed = false;
    dualMaterialsValidated = false;
    invalidateSingleMaterial();
    localStorage.setItem("optimqe.sessionConfirmed", "0");
    localStorage.setItem("optimqe.dualValidated", "0");
    material = "";
    jobId = "";
    setWorkspaceActive(false);
    paintSessionStatus();
    paintSessionBar();
    paintJobPanel();
    $("matbar")?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  /** Vide l’interface de session (champs + état) — ne supprime pas les fichiers sur disque. */
  function refreshClearInterface() {
    const keepKeys = new Set(["optimqe.lang", "optimqe-theme"]);
    const toRemove = [];
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (!k || !k.startsWith("optimqe")) continue;
        if (keepKeys.has(k)) continue;
        toRemove.push(k);
      }
      toRemove.forEach((k) => localStorage.removeItem(k));
    } catch (_) {}

    material = "";
    jobId = "";
    phaseId = "";
    sessionConfirmed = false;
    singleMaterialValidated = false;
    dualMaterialsValidated = false;
    lastStructureSource = null;
    lastDopingSpecies = null;

    const clearVal = (id) => {
      const el = $(id);
      if (el) el.value = "";
    };
    [
      "material-select",
      "material-select-a",
      "material-select-b",
      "material-final",
      "phase-doping-material",
      "phase-doping-parent-a",
      "phase-doping-parent-b",
      "doping-host-element",
      "doping-host-element-manual",
      "doping-dopant-element",
      "doping-frac-custom",
      "sqs-frac-custom",
      "session-cif-pick",
    ].forEach(clearVal);

    document.querySelectorAll(".doping-frac:checked, .sqs-frac:checked").forEach((cb) => {
      cb.checked = false;
    });
    document.querySelectorAll(".sqs-frac").forEach((cb) => {
      if (["25", "50", "75"].includes(cb.value)) cb.checked = true;
    });
    document.querySelectorAll(".doping-frac").forEach((cb) => {
      if (["25", "50", "75"].includes(cb.value)) cb.checked = true;
    });

    const intentSel = $("session-study-intent");
    if (intentSel) intentSel.value = "single";
    try {
      localStorage.setItem("optimqe.sessionIntent", "single");
      localStorage.setItem("optimqe.sessionConfirmed", "0");
      localStorage.setItem("optimqe.singleValidated", "0");
      localStorage.setItem("optimqe.dualValidated", "0");
      localStorage.setItem("optimqe.dopingCase", "endpoints");
    } catch (_) {}
    setSessionDopingCase("endpoints", { skipPaint: true });

    ["doping-preview-body", "sqs-preview-body"].forEach((id) => {
      const el = $(id);
      if (el) el.innerHTML = '<p class="meta">—</p>';
    });
    [
      "doping-status",
      "sqs-status",
      "session-validate-status",
      "session-single-validate-status",
      "session-dual-validate-status",
      "phase-cif-status",
    ].forEach((id) => {
      const el = $(id);
      if (!el) return;
      el.textContent = "";
      el.className = "meta";
      if (id === "phase-cif-status") el.hidden = true;
    });
    const verifyBlock = $("doping-verify-block");
    if (verifyBlock) verifyBlock.hidden = true;
    const verifyCheck = $("doping-verified-check");
    if (verifyCheck) verifyCheck.checked = false;
    const badge = $("material-type-badge");
    if (badge) badge.hidden = true;

    ["phase-doping-material", "phase-doping-parent-a", "phase-doping-parent-b"].forEach((id) => {
      const el = $(id);
      if (el) delete el.dataset.userEdited;
    });

    clearSessionActionPulse();
    resetAutoResumeScope();
    resetRunTracking(true);
    setWorkspaceActive(false);
    stopJobsBoardAutoRefresh();
    stopResultsAutoRefresh();

    sessionPrepSubTab = "prep-nondope";
    sessionCalcSubTab = "calc-nondope";
    resultsSubTab = "res-nondope";
    resultsBrowseMat = "";
    resultsBrowseKind = "";
    const resMatInp = $("results-mat-select");
    if (resMatInp) resMatInp.value = "";
    const resStatus = $("results-refresh-status");
    if (resStatus) resStatus.textContent = "";
    try {
      localStorage.removeItem("optimqe.resultsBrowseMat");
      localStorage.removeItem("optimqe.resultsBrowseKind");
    } catch (_) {}
    paintResultsBrowseChrome();

    paintSessionIntentUI();
    paintPhaseDopingFormCompact();
    switchSessionWorkTab("preparation");
    switchSessionSubTab("preparation", "prep-nondope");
    paintSessionStatus();
    paintSessionBar();
    paintJobPanel();
    paintStructurePanelVisibility();
    paintSessionStepHint();
    updateDopingActionsEnabled();
    updateDopingLaunchGate();

    const st = $("session-validate-status");
    if (st) {
      st.textContent = i18nT("btn.refresh_ui.done");
      st.className = "meta status-ok";
    }
    $("matbar")?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  function paintSessionStatus() {
    const el = $("session-status");
    if (!el) return;
    if (sessionConfirmed && material) {
      const phTxt = phaseId ? phaseId : i18nT("phase.principal");
      el.textContent = i18nT("session.active_phase", {
        material,
        phase: phTxt,
        structure: phaseCrystalLabel() || "—",
      });
      el.className = "session-status meta ok";
    } else {
      el.textContent = i18nT("session.pending");
      el.className = "session-status meta warn";
    }
    paintSessionBar();
  }

  function markSessionPending() {
    if (draftsMatchSession()) return;
    resetAutoResumeScope();
    sessionConfirmed = false;
    localStorage.setItem("optimqe.sessionConfirmed", "0");
    material = "";
    jobId = "";
    setWorkspaceActive(false);
    stopJobsBoardAutoRefresh();
    paintSessionStatus();
    refreshOptimStatus().catch(() => {});
    refreshResults().catch(() => {});
  }

  function updateJobSelectState() {
    const draft = getDraftMaterial();
    [ $("job-select"), $("job-select-dual") ].forEach((sel) => {
      if (sel) sel.disabled = !draft;
    });
    const newBtn = $("btn-new-job");
    if (newBtn) newBtn.disabled = !draft;
    const applyBtn = $("btn-apply-job");
    if (applyBtn) applyBtn.disabled = !draft;
  }

  /** Une seule étape de la chaîne FM/AFM peut être « en cours » (vc-relax | relax | scf). */
  /** Ordres magnétiques dont le SCF est prêt mais le NSCF (DOS / gap) manque encore. */
  function magOrdersPendingNscf(rows) {
    return (rows || []).filter(
      (r) =>
        r.order !== "nm"
        && r.order !== "ncl"
        && (r.scf_converged || r.from_main_scf)
        && !r.nscf_converged
        && !r.nscf_running
    );
  }

  function magOrderNscfLabel(r) {
    if (!r || r.order === "nm") return "NM";
    return String(r.short || r.order).replace(/^afm-/i, "AFM-").toUpperCase();
  }

  function magPipeActiveKind(r) {
    const act = magOrderRunning(r);
    if (act && act.kind && act.kind !== "nscf") return act.kind;
    const steps = (r && r.steps) || {};
    let last = null;
    for (const k of ["vc-relax", "relax", "scf"]) {
      const s = steps[k];
      if (s && (s.running || s.run_phase === "running")) last = k;
    }
    return last;
  }

  function magRowAnyRunning(r) {
    if (!r || r.order === "nm") return false;
    if (r.nscf_running || r.running) return true;
    const steps = r.steps || {};
    return Object.values(steps).some((s) => s && stepIsRunning(s));
  }

  function magRowStopKind(r, fallback) {
    if (!r) return fallback || "vc-relax";
    if (r.nscf_running) return "nscf";
    const steps = r.steps || {};
    for (const k of ["vc-relax", "relax", "scf", "nscf"]) {
      if (stepIsRunning(steps[k])) return k;
    }
    const act = magOrderRunning(r);
    return act ? act.kind : (fallback || "vc-relax");
  }

  function findRunningMagOrderRow() {
    const rows = (lastMagOrders && lastMagOrders.orders) || [];
    return rows.find((r) => r.order !== "nm" && magRowAnyRunning(r)) || null;
  }

  function findPhasesActiveRunTarget() {
    const magR = findRunningMagOrderRow();
    if (magR) {
      const lab = String(magR.short || magR.order).replace(/^afm-/i, "AFM-").toUpperCase();
      return {
        kind: magRowStopKind(magR, "vc-relax"),
        magOrder: magR.order,
        label: i18nT("phases.stop.label_mag", { order: lab }),
      };
    }
    const nmActive = nmActiveStep(lastOptimSteps || {});
    if (nmActive) {
      return { kind: nmActive, magOrder: "", label: i18nT("phases.stop.label_nm") };
    }
    return null;
  }

  function paintPhasesCalcStopBar() {
    if (!PHASES_ONLY) return;
    const row = $("phases-calc-stop-row");
    const btn = $("btn-phases-stop-calc");
    const note = $("phases-calc-stop-note");
    const t = findPhasesActiveRunTarget();
    if (row) row.hidden = !t;
    if (note) note.textContent = (t && t.label) || "";
    if (btn) {
      if (!t) {
        btn.dataset.kind = "";
        btn.dataset.magOrder = "";
        btn.hidden = true;
      } else {
        btn.hidden = false;
        btn.dataset.kind = t.kind;
        btn.dataset.magOrder = t.magOrder || "";
      }
    }
  }

  function magOrderRunning(r) {
    if (!r || r.order === "nm") return null;
    if (r.active_run && r.active_run.kind) {
      const ak = r.active_run.kind;
      const st = (r.steps || {})[ak];
      if (st && !stepIsRunning(st) && st.run_phase === "stopped") return null;
      return {
        kind: ak,
        order: r.order,
        job: r.active_run.job_id || r.job_id || jobId,
      };
    }
    if (r.nscf_running) {
      const ns = (r.steps || {}).nscf;
      if (ns && !stepIsRunning(ns) && ns.run_phase === "stopped") return null;
      return { kind: "nscf", order: r.order, job: r.job_id || jobId };
    }
    const steps = r.steps || {};
    for (const k of ["vc-relax", "relax", "scf"]) {
      if (stepIsRunning(steps[k])) {
        return { kind: k, order: r.order, job: r.job_id || jobId };
      }
    }
    if (r.running && !r.stopped) return { kind: "scf", order: r.order, job: r.job_id || jobId };
    return null;
  }

  async function attachPollIfLiveRunning(mat, kind, jobIdForPoll, magOrder, structurePhaseId, trackId) {
    if (!mat || runPollBlocked() || optimPollTimer) return false;
    try {
      const { live } = await fetchRunLive(
        mat,
        kind,
        jobIdForPoll,
        magOrder || "",
        structurePhaseId || ""
      );
      if (live && live.running) {
        startOptimPoll(mat, kind, jobIdForPoll || live.job_id, magOrder || null, structurePhaseId, trackId);
        if (trackId) paintLiveOnTrack(trackId, live, { kind, magOrder: magOrder || "" });
        return true;
      }
    } catch (_) {
      /* pas de calcul réel */
    }
    return false;
  }

  function magCasePaintKey(data) {
    const rows = (data && data.orders) || [];
    return JSON.stringify(
      rows.map((r) => ({
        o: r.order,
        run: r.running,
        active: r.active_run,
        nscf: r.nscf_running,
        steps: r.steps,
        scf: r.scf_converged,
        e: r.energy_per_atom_ev,
        cr: (r.chain_resume && r.chain_resume.next_kind) || null,
        jid: r.job_id,
        err: r.error,
      }))
    );
  }

  async function continueMagChainPoll(mat, magOrder, jobIdForPoll, finishedKind, live) {
    if (!magOrder || pipelineMode() !== "server" || !live || !live.converged) return false;
    const chainKinds = ["vc-relax", "relax", "scf"];
    const idx = chainKinds.indexOf(finishedKind);
    if (idx < 0 || idx >= chainKinds.length - 1) return false;
    for (let attempt = 0; attempt < 4; attempt += 1) {
      if (attempt) await new Promise((res) => setTimeout(res, 700));
      await refreshMagOrders({ skipCaseRepaint: true }).catch(() => null);
      const rows = (lastMagOrders && lastMagOrders.orders) || [];
      const row = rows.find((x) => x.order === magOrder);
      const run = magOrderRunning(row);
      if (run) {
        startOptimPoll(mat, run.kind, jobIdForPoll || run.job || jobId, magOrder);
        return true;
      }
    }
    return false;
  }

  function startMagRunningPolls(magData) {
    if (!magData || !material || runPollBlocked() || optimPollTimer) return;
    for (const r of magData.orders || []) {
      const run = magOrderRunning(r);
      if (!run) continue;
      if (run.job && run.job !== jobId) setJob(run.job);
      let trackId;
      if (PHASES_ONLY && sessionCalculsPanelVisible() && getSessionMagOrder() === r.order) {
        trackId = `track-mag-${r.order}`;
      }
      attachPollIfLiveRunning(
        material,
        run.kind,
        jobId || run.job,
        run.order,
        activePhaseId(),
        trackId
      ).catch(() => {});
      return;
    }
  }

  function paintJobDraftHint() {
    const st = $("job-panel-status");
    const draft = getDraftJob();
    const sel = $("job-select");
    const nJobs = sel
      ? [...sel.options].filter((o) => o.value).length
      : 0;
    if (!st) return;
    if (!getDraftMaterial()) {
      st.textContent = i18nT("job.need_mat");
      st.className = "meta warn";
      return;
    }
    if (sessionConfirmed && material && getDraftMaterial() === material && draft === jobId) {
      st.textContent = jobId
        ? i18nT("job.applied", { job: jobId })
        : i18nT("job.active.none");
      st.className = "meta status-ok";
      return;
    }
    if (draft) {
      st.textContent = i18nT("job.draft.pending", { job: draft });
      st.className = "meta warn";
      return;
    }
    if (nJobs === 0) {
      st.textContent = i18nT("job.empty.hint");
      st.className = "meta warn";
      return;
    }
    st.textContent = i18nT("job.draft.new");
    st.className = "meta";
  }

  function paintJobPanel() {
    const panel = $("session-job-panel");
    const actions = $("session-job-actions");
    const mat = getDraftMaterial();
    const sessionCompact = sessionConfirmed && material;
    if (panel) panel.hidden = true;
    if (actions) actions.hidden = !mat || sessionCompact;
    updateJobSelectState();
    paintJobDraftHint();
    paintMagJobBanner();
  }

  function orderJobId(r) {
    if (!r) return "";
    if (r.job_id) return String(r.job_id);
    if (r.active_run && r.active_run.job_id) return String(r.active_run.job_id);
    if (r.chain_resume && r.chain_resume.job_id) return String(r.chain_resume.job_id);
    const steps = r.steps || {};
    for (const k of ["vc-relax", "relax", "scf"]) {
      if (steps[k] && steps[k].job_id) return String(steps[k].job_id);
    }
    return "";
  }

  function paintMagJobBanner() {
    const el = $("mag-job-banner");
    if (!el) return;
    if (!sessionConfirmed || !material) {
      el.hidden = true;
      return;
    }
    const rows = (lastMagOrders && lastMagOrders.orders) || [];
    let run = null;
    let runRow = null;
    for (const r of rows) {
      if (r.order === "nm") continue;
      const act = magOrderRunning(r);
      if (act) {
        run = act;
        runRow = r;
        break;
      }
    }
    const fm = fmMagRow();
    const jid = jobId || orderJobId(runRow) || orderJobId(fm) || "";
    let stateKey = "mag.job.state.idle";
    let step = "";
    let orderLab = "—";
    if (run && runRow) {
      stateKey = "mag.job.state.running";
      step = String(run.kind).toUpperCase();
      orderLab = (runRow.short || runRow.order || "").replace("afm-", "AFM-").toUpperCase();
    } else if (fm && fm.scf_converged) {
      stateKey = "mag.job.state.done";
      orderLab = "FM";
    }
    el.textContent = i18nT("mag.job.banner", {
      job: jid || i18nT("label.job.none"),
      order: orderLab,
      state: i18nT(stateKey, { step }),
    });
    el.hidden = false;
    el.className = `mag-job-banner meta${run ? " is-running" : ""}`;
  }

  async function applySelectedJob(opts = {}) {
    const goFm = opts.goFm !== false;
    const goTab = opts.goTab || "";
    const mat = getDraftMaterial();
    if (!mat) {
      alert(i18nT("alert.pick_mat"));
      return;
    }
    await refreshPhasesForDraft();
    const pid = getDraftPhase();
    const jid = getDraftJob();
    syncPhaseSelects(pid);

    await refreshStructureSource(mat);
    if (!lastStructureSource?.vc_relax_exists) {
      await bootstrapNmInputs(mat, {
        silent: true,
        auto_from_cif: true,
        sync_followups: true,
      }).catch(() => {});
      await refreshStructureSource(mat);
    }
    if (!lastStructureSource?.vc_relax_exists && !jid) {
      alert(i18nT("session.origin.need_confirm"));
      return;
    }

    material = mat;
    phaseId = pid;
    jobId = jid;
    sessionConfirmed = true;
    localStorage.setItem("optimqe.material", material);
    localStorage.setItem("optimqe.phase", phaseId);
    localStorage.setItem("optimqe.job", jobId);
    localStorage.setItem("optimqe.sessionConfirmed", "1");
    setWorkspaceActive(true);
    setJob(jid);
    paintSessionStatus();
    paintSessionBar();

    resetAutoResumeScope();
    await refreshOptimStatus();
    await refreshMagOrders().catch(() => {});
    await tryAutoResumeInterrupted();
    startJobsBoardAutoRefresh();
    startMagRunningPolls(lastMagOrders);
    paintJobPanel();
    log(
      "log-opt",
      jid ? i18nT("job.applied", { job: jid }) : i18nT("job.active.none"),
      true
    );

    if (goTab) switchTab(goTab);
    else if (goFm) goToMagOrder("fm");
  }

  async function createNewJob(opts = {}) {
    const mat = getDraftMaterial();
    if (!mat) {
      alert(i18nT("alert.pick_mat"));
      return null;
    }
    const data = await api("/api/jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ material: mat, name: mat }),
    });
    if (!data.job_id) {
      log("log-opt", data.error || "Création job échouée", false);
      return null;
    }
    await refreshJobsForDraft();
    const sel = $("job-select");
    if (sel) {
      // Garantir la présence de l'option même si le filtre API a raté
      if (![...sel.options].some((o) => o.value === data.job_id)) {
        const opt = document.createElement("option");
        opt.value = data.job_id;
        opt.textContent = `${data.job_id} · ${i18nT("job.status.draft")}`;
        sel.appendChild(opt);
      }
      sel.value = data.job_id;
    }
    const applyNow = opts.apply !== false;
    if (applyNow && (sessionConfirmed || opts.forceApply)) {
      if (!sessionConfirmed || material !== mat) {
        await applySelectedJob({ goFm: false, goTab: "" }).catch(() => {});
      } else {
        setJob(data.job_id);
        resetRunTracking();
        paintJobPanel();
      }
      log("log-opt", i18nT("job.new.created", { id: data.job_id }), true);
      await refreshOptimStatus().catch(() => {});
    } else {
      paintJobPanel();
      log("log-opt", i18nT("job.new.draft", { id: data.job_id }), true);
    }
    return data.job_id;
  }

  /**
   * Options du sélecteur de job, groupées par (phase × ordre magnétique).
   * Un matériau a beaucoup de calculs (NM + FM + AFM…) : chaque job est
   * étiqueté avec sa phase, ses ordres magnétiques et son avancement.
   */
  function jobsBoardOptions(jobs) {
    if (!jobs || !jobs.length) return "";
    const groups = new Map();
    for (const j of jobs) {
      const pid = j.phase_id || j.structure_phase_id || "";
      const orders = (j.mag_orders || []).map((o) => String(o).toUpperCase());
      const isDraft = !!j.draft || !(j.total_steps > 0);
      const key = isDraft
        ? `\u0000draft`
        : `${pid}\u0000${orders.join("/")}`;
      if (!groups.has(key)) {
        groups.set(key, {
          pid,
          orders,
          draft: isDraft,
          items: [],
        });
      }
      groups.get(key).items.push(j);
    }
    const phaseLbl = (pid) => pid || i18nT("jobs.phase.main");
    const stateIcon = (j) => {
      if (j.running) return "⏳ ";
      if (j.draft || !(j.total_steps > 0)) return "○ ";
      if (j.status === "done") return "✔ ";
      if (j.status === "failed") return "✖ ";
      if (j.status === "partial") return "◐ ";
      return "";
    };
    let html = "";
    for (const g of groups.values()) {
      const tag = g.draft
        ? i18nT("job.group.draft")
        : (g.orders.length ? g.orders.join(" / ") : "NM");
      const label = g.draft ? tag : `${phaseLbl(g.pid)} · ${tag}`;
      html += `<optgroup label="${escAttr(label)}">`;
      html += g.items
        .map((j) => {
          const n = `${j.done_steps || 0}/${j.total_steps || 0}`;
          const extra = (j.draft || !(j.total_steps > 0))
            ? i18nT("job.status.draft")
            : i18nT("jobs.steps", { n });
          return `<option value="${escAttr(j.id)}">${esc(stateIcon(j))}${esc(j.id)} · ${esc(extra)}</option>`;
        })
        .join("");
      html += `</optgroup>`;
    }
    return html;
  }

  async function refreshJobsForDraft() {
    const sel = $("job-select");
    if (!sel) return;
    const draftMat = getDraftMaterial();
    updateJobSelectState();
    let jobs = [];
    try {
      const data = await api(
        draftMat
          ? `/api/jobs?material=${encodeURIComponent(draftMat)}`
          : "/api/jobs"
      );
      jobs = (data.jobs || []).filter(
        (j) => !draftMat || (j.material || "") === draftMat
      );
    } catch (err) {
      log("log-opt", err.message || String(err), false);
    }
    const prev = sel.value;
    const emptyLab = i18nT("label.job.none");
    sel.innerHTML =
      `<option value="">— ${esc(emptyLab)} —</option>` +
      jobsBoardOptions(jobs);
    if (prev && [...sel.options].some((o) => o.value === prev)) {
      sel.value = prev;
    } else if (sessionConfirmed && jobId && draftMat === material) {
      if ([...sel.options].some((o) => o.value === jobId)) sel.value = jobId;
      else {
        const opt = document.createElement("option");
        opt.value = jobId;
        opt.textContent = `${jobId} · ${i18nT("job.status.active")}`;
        sel.appendChild(opt);
        sel.value = jobId;
      }
    } else if (jobs.length === 1) {
      // Un seul job pour ce matériau → le sélectionner (manipulation plus simple)
      sel.value = jobs[0].id || "";
    }
    syncJobSelectMirrors();
    paintJobPanel();
  }

  /**
   * Tableau des jobs du matériau : un cas par (phase × ordre magnétique),
   * avec la chaîne VC-RELAX → RELAX → SCF (+ NSCF) et l'état de chaque run.
   * Un matériau a beaucoup de calculs (NM + FM + AFM…) : ce tableau les
   * réunit au même endroit pour ne rien perdre.
   */
  let jobsBoardTs = 0;
  let jobsBoardTimer = null;
  let lastMagOrdersRefresh = 0;
  let magOrdersBusy = false;
  let sessionMagPrepareBannerText = "";

  function sessionCalculsPanelVisible() {
    if (!PHASES_ONLY) return false;
    const main = $("session-panel-calcul");
    const sub = $("session-subpanel-calc-nondope");
    const calc = $("session-panel-calculs");
    return !!(main && !main.hidden && sub && !sub.hidden && calc);
  }

  function sessionPhasePanelVisible() {
    if (!PHASES_ONLY) return false;
    const main = $("session-panel-calcul");
    if (!main || main.hidden) return false;
    const stab = $("phase-stability-card");
    if (!stab || stab.hidden) return false;
    const subD = $("session-subpanel-calc-doped");
    const subN = $("session-subpanel-calc-nondope");
    if (stab.closest("#session-subpanel-calc-doped")) return !!(subD && !subD.hidden);
    if (stab.closest("#session-subpanel-calc-nondope")) return !!(subN && !subN.hidden);
    return false;
  }

  function sessionPreparationPanelVisible() {
    if (!PHASES_ONLY) return false;
    const prep = $("session-panel-preparation");
    return !!(prep && !prep.hidden);
  }

  function normalizeSessionWorkTab(tab) {
    const t = String(tab || "preparation");
    if (t === "home" || t === "accueil") return "accueil";
    if (t === "calculs") return PHASES_PREP_ONLY ? "resultats" : "calcul";
    if (t === "phase") return "preparation";
    if (t === "calcul" && PHASES_PREP_ONLY) return "resultats";
    if (t === "accueil" || t === "preparation" || t === "calcul" || t === "resultats") return t;
    return "preparation";
  }

  function paintPhasesPrepOnlyChrome() {
    if (!PHASES_ONLY || !PHASES_PREP_ONLY) return;
    document.body.classList.add("phases-prep-only");
    const btnCalc = $("tab-session-calcul");
    const panelCalc = $("session-panel-calcul");
    if (btnCalc) {
      btnCalc.hidden = true;
      btnCalc.setAttribute("aria-hidden", "true");
    }
    if (panelCalc) {
      panelCalc.hidden = true;
      panelCalc.setAttribute("aria-hidden", "true");
    }
    document.querySelectorAll(".prep-only-hide").forEach((el) => {
      el.hidden = true;
    });
    const tabs = $("session-work-tabs");
    if (tabs) tabs.setAttribute("aria-label", i18nT("session.tablist.prep_only"));
    const btnHome = $("tab-session-accueil");
    if (btnHome) btnHome.hidden = false;
  }

  let sessionPrepSubTab = "prep-nondope";
  let sessionCalcSubTab = "calc-nondope";
  let resultsSubTab = "res-nondope";
  /** Matériau sélectionné dans l’onglet Résultats (parcours browse). */
  let resultsBrowseMat = "";
  /** '' | 'nondope' | 'doped' — type affiché après le choix du matériau. */
  let resultsBrowseKind = "";

  function paintPhaseStabilityHost() {
    const stab = $("phase-stability-card");
    const hostN = $("session-stability-host-nondope");
    const hostD = $("session-stability-host-doped");
    if (!stab || !hostN || !hostD) return;
    const intent = sessionStudyIntent();
    const onDopedCalc = sessionCalcSubTab === "calc-doped";
    const target =
      intent === "doping" && onDopedCalc ? hostD : hostN;
    if (stab.parentElement !== target) target.appendChild(stab);
  }

  /** Sous-onglet Calcul : dopé seulement pour objectif dopage ; alliage / pérovskite → non dopé. */
  function resolveSessionCalcSubTab(intent) {
    const i = intent || sessionStudyIntent();
    return i === "doping" ? "calc-doped" : "calc-nondope";
  }

  function paintCalcSubTabChrome() {
    if (!PHASES_ONLY) return;
    const btnN = $("tab-calc-nondope");
    if (btnN) {
      btnN.disabled = false;
      btnN.removeAttribute("aria-disabled");
      btnN.title = "";
    }
  }

  /** Onglet Calcul · non dopé : chaîne VC-RELAX → … → NSCF (+ tableau phases SQS si besoin). */
  function paintCalculNondopeLayout() {
    if (!PHASES_ONLY) return;
    paintPhaseStabilityHost();
    const intent = sessionStudyIntent();
    const inner = $("session-panel-calculs");
    const lead = $("session-calc-lead-nondope");
    if (inner) inner.hidden = false;
    if (lead) {
      lead.hidden = intent !== "sqs";
      if (intent === "sqs") lead.textContent = i18nT("session.calc.lead.sqs");
    }
    paintPhasesCalculsChainPanel();
    paintSessionMagSpinGallery();
  }

  function relocateSessionMatBlock(prepSub) {
    const block = $("session-block-mat");
    const slot =
      prepSub === "prep-doped" ? $("session-prep-mat-slot-doped") : $("session-prep-mat-slot-nondope");
    if (block && slot && block.parentElement !== slot) slot.appendChild(block);
  }

  function relocateSessionStructurePanel(_prepSub) {
    const panel = $("session-structure-panel");
    const slot = $("session-prep-cif-slot-nondope");
    if (panel && slot && panel.parentElement !== slot) slot.appendChild(panel);
  }

  function getSessionDopantElement() {
    return ($("doping-dopant-element")?.value || "").trim();
  }

  function paintPrepMatSubpanel(prepSub) {
    const isDoped = prepSub === "prep-doped";
    const intentSel = $("session-study-intent");
    /* Objectif (barre au-dessus) pilote le chemin. Clic « Matériau dopé » ⇒ doping.
       Clic « non dopé » ne change pas l’objectif (CIF des parents encore utile en dopage). */
    if (intentSel && isDoped && sessionStudyIntent() !== "doping") {
      intentSel.value = "doping";
      try {
        localStorage.setItem("optimqe.sessionIntent", "doping");
      } catch (_) {}
    }
    const flowDual = $("session-flow-dual");
    if (flowDual) flowDual.hidden = sessionStudyIntent() === "single";
    paintSessionIntentUI();
    relocateSessionMatBlock(prepSub);
    relocateSessionStructurePanel(prepSub);
    if (isDoped) {
      syncPhaseDopingMaterials();
      paintPhaseDopingFormCompact();
      refreshDopingHostElements().catch(() => {});
    } else {
      paintPhaseDopingFormCompact();
      updateDopingActionsEnabled();
    }
    paintPrepToneChrome();
  }

  /** Fond d’interface : vert = non dopé, bleu clair = dopé. */
  function currentPrepTone() {
    const home = $("session-panel-accueil");
    if (home && !home.hidden) return "accueil";
    const prep = $("session-panel-preparation");
    const calc = $("session-panel-calcul");
    const res = $("session-panel-resultats");
    if (prep && !prep.hidden) {
      return sessionPrepSubTab === "prep-doped" ? "doped" : "nondope";
    }
    if (calc && !calc.hidden) {
      return sessionCalcSubTab === "calc-doped" ? "doped" : "nondope";
    }
    if (res && !res.hidden) {
      if (resultsBrowseKind === "doped") return "doped";
      if (resultsBrowseKind === "nondope") return "nondope";
      return "";
    }
    return sessionPrepSubTab === "prep-doped" ? "doped" : "nondope";
  }

  function paintPrepToneChrome() {
    const tone = currentPrepTone();
    document.body.dataset.prepTone = tone || "";
    document.body.classList.toggle("prep-tone-accueil", tone === "accueil");
    document.body.classList.toggle("prep-tone-nondope", tone === "nondope");
    document.body.classList.toggle("prep-tone-doped", tone === "doped");
  }

  function switchSessionSubTab(group, sub) {
    const g = group === "calcul" ? "calcul" : "preparation";
    const prepSubs = ["prep-nondope", "prep-doped"];
    const calcSubs = ["calc-nondope", "calc-doped"];
    const subs = g === "calcul" ? calcSubs : prepSubs;
    let s = String(sub || "");
    if (!subs.includes(s)) s = subs[0];
    if (g === "calcul" && s === "calc-doped" && sessionStudyIntent() !== "doping") {
      s = "calc-nondope";
    }
    if (g === "preparation") sessionPrepSubTab = s;
    else sessionCalcSubTab = s;

    const panelPrep = $("session-panel-preparation");
    const panelCalc = $("session-panel-calcul");
    if (g === "preparation") {
      if (panelPrep && !panelPrep.hidden) {
        prepSubs.forEach((id) => {
          const el = $(`session-subpanel-${id}`);
          const btn = document.querySelector(`[data-session-subtab="${id}"][data-session-subtab-group="preparation"]`);
          const on = id === s;
          if (el) {
            el.classList.toggle("active", on);
            el.hidden = !on;
          }
          if (btn) {
            btn.classList.toggle("active", on);
            btn.setAttribute("aria-selected", on ? "true" : "false");
          }
        });
      }
      paintPrepMatSubpanel(s);
    }
    if (g === "calcul" && panelCalc && !panelCalc.hidden) {
      calcSubs.forEach((id) => {
        const el = $(`session-subpanel-${id}`);
        const btn = document.querySelector(`[data-session-subtab="${id}"][data-session-subtab-group="calcul"]`);
        const on = id === s;
        if (el) {
          el.classList.toggle("active", on);
          el.hidden = !on;
        }
        if (btn) {
          btn.classList.toggle("active", on);
          btn.setAttribute("aria-selected", on ? "true" : "false");
        }
      });
      paintPhaseStabilityHost();
      paintCalcSubTabChrome();
      if (s === "calc-nondope") {
        paintCalculNondopeLayout();
        if (sessionConfirmed && material) refreshPhaseStability().catch(() => {});
      } else if (sessionConfirmed && material) {
        refreshPhaseStability().catch(() => {});
      }
    }
    try {
      localStorage.setItem(`optimqe.sessionSubTab.${g}`, s);
    } catch (_) {}
    paintPrepToneChrome();
  }

  function currentTab() {
    if (PHASES_ONLY) {
      const res = $("session-panel-resultats");
      if (res && !res.hidden) return "resultats";
      const prep = $("session-panel-preparation");
      if (prep && !prep.hidden) return "phases";
      const calcMain = $("session-panel-calcul");
      if (calcMain && !calcMain.hidden) return "optimisation";
    }
    const active = document.querySelector(".optim-page.active");
    if (active && active.id && active.id.startsWith("page-")) {
      return active.id.slice("page-".length);
    }
    return localStorage.getItem("optimqe.tab") || "optimisation";
  }

  /** Contexte affiché en tête de l’onglet Magnétisme (FM/AFM actif, pas seulement NM). */
  function magHeaderContext(data) {
    const rows = (data && data.orders) || (lastMagOrders && lastMagOrders.orders) || [];
    for (const r of rows) {
      if (r.order === "nm") continue;
      const act = magOrderRunning(r);
      if (act) {
        return {
          order: (r.short || r.order).replace("afm-", "AFM-").toUpperCase(),
          nspin: r.nspin != null ? r.nspin : (r.order === "ncl" ? 4 : 2),
        };
      }
    }
    if (currentTab() === "magnetisme") {
      const fm = rows.find((r) => r.order === "fm");
      if (fm && (fm.input_exists || fm.scf_converged || (fm.steps && fm.steps["vc-relax"]))) {
        return { order: "FM", nspin: fm.nspin != null ? fm.nspin : 2 };
      }
    }
    return null;
  }

  function stopJobsBoardAutoRefresh() {
    if (jobsBoardTimer) {
      clearInterval(jobsBoardTimer);
      jobsBoardTimer = null;
    }
  }

  function startJobsBoardAutoRefresh() {
    stopJobsBoardAutoRefresh();
    if (!sessionConfirmed || !material) return;
    jobsBoardTimer = setInterval(() => refreshJobsBoard().catch(() => {}), 12000);
  }

  async function refreshJobsBoard(opts = {}) {
    const panel = $("jobs-board");
    if (!panel) return;
    if (!sessionConfirmed || !material) {
      panel.hidden = true;
      stopJobsBoardAutoRefresh();
      return;
    }
    const bust = opts.force ? `_jb=${Date.now()}` : "";
    const q = phaseQuery(bust ? `?${bust}` : "");
    const data = await api(`/api/materials/${encodeURIComponent(material)}/jobs-board${q}`);
    const tab = normalizeTab(localStorage.getItem("optimqe.tab") || "optimisation");
    let cases = data.cases || [];
    // Onglet ① : une seule ligne NM (phase active) — pas les vieux cas FM/AFM.
    if (tab === "optimisation") {
      cases = cases.filter((c) => String(c.mag_order || "nm").toLowerCase() === "nm");
    }
    const cnt = $("jobs-board-count");
    if (cnt) {
      cnt.textContent = cases.length
        ? i18nT("jobs.board.count", { n: String(cases.length) })
        : "";
    }
    if (!cases.length) {
      panel.hidden = true;
      return;
    }
    panel.hidden = false;
    const KINDS = ["vc-relax", "relax", "scf", "nscf"];
    const cell = (run) => {
      if (!run) return `<td class="job-cell job-cell-none">—</td>`;
      const st = runState(run);
      const out = run.out_url
        ? ` <a class="run-out" href="${escAttr(safeHref(run.out_url))}" target="_blank" rel="noopener">${esc(i18nT("runs.out"))}</a>`
        : "";
      const dur = run.duration_s != null && run.phase !== "running"
        ? ` · ${esc(fmtDuration(run.duration_s))}`
        : "";
      const info = run.error ? ` title="${escAttr(run.error)}"` : "";
      return `<td class="job-cell ${escAttr(st.cls)}"${info}>${esc(i18nT(st.key))}${dur}${out}</td>`;
    };
    let html =
      `<table class="jobs-board-table"><thead><tr><th>${esc(i18nT("jobs.board.case"))}</th>` +
      KINDS.map((k) => `<th>${esc(i18nT("runs.kind." + k))}</th>`).join("") +
      `<th>${esc(i18nT("jobs.board.job"))}</th></tr></thead><tbody>`;
    for (const c of cases) {
      const phase = c.phase_id ? esc(c.phase_id) : esc(i18nT("jobs.phase.main"));
      const label = `${phase} · ${esc(c.label || String(c.mag_order || "nm").toUpperCase())}`;
      const mo = String(c.mag_order || "nm").toLowerCase();
      html +=
        `<tr class="jobs-board-row${c.running ? " is-running" : ""}" data-mag-order="${escAttr(mo)}" data-job-id="${escAttr(c.job_id || "")}" tabindex="0" title="${escAttr(i18nT("jobs.board.resume"))}">` +
        `<th scope="row" class="job-case">${label}</th>` +
        KINDS.map((k) => cell((c.kinds || {})[k])).join("") +
        `<td class="job-case-id">${esc(c.job_id || "—")}</td></tr>`;
    }
    html += `</tbody></table>`;
    const body = $("jobs-board-body");
    if (body) body.innerHTML = html;
  }

  async function confirmSession() {
    clearSessionActionPulse();
    syncSessionMagOrderFromUi();
    const magOrderPick = getSessionMagOrder();
    if (sessionConfirmed && material && getDraftMaterial() === material) {
      if (PHASES_ONLY && PHASES_PREP_ONLY) {
        switchSessionWorkTab("resultats");
        await refreshMaterialIoProfile().catch(() => {});
        return;
      }
      if (PHASES_ONLY) switchSessionWorkTab("calcul");
      paintPhasesCalculsChainPanel();
      await startStudyChainFromSession().catch((e) => alert(e.message));
      return;
    }
    if (isDualStudyIntent()) {
      if (!dualMaterialsValidated) {
        const ok = await validateDualMaterials();
        if (!ok) {
          $("session-flow-dual")?.scrollIntoView({ behavior: "smooth", block: "nearest" });
          return;
        }
      }
      if (sessionStudyIntent() === "doping") {
        const dopEl = getSessionDopantElement();
        if (!dopEl) {
          alert(i18nT("session.doping.need"));
          $("doping-dopant-element")?.focus();
          return;
        }
        localStorage.setItem("optimqe.dopingElement", dopEl);
      }
    } else if (!singleMaterialValidated) {
      const ok = await validateSingleMaterial();
      if (!ok) {
        $("material-select")?.focus();
        return;
      }
    }
    const m = getDraftMaterial();
    if (!m) {
      alert(i18nT("alert.pick_mat"));
      if (isDualStudyIntent()) $("material-final")?.focus();
      else $("material-select")?.focus();
      return;
    }
    await refreshPhasesForDraft();
    phaseId = getDraftPhase();
    const ready = await ensureStructureReadyBeforeStart(m);
    if (!ready) {
      alert(i18nT("session.origin.need_confirm"));
      if (PHASES_ONLY && sessionStudyIntent() === "doping") {
        switchSessionWorkTab("preparation");
        switchSessionSubTab("preparation", "prep-nondope");
      }
      $("session-structure-panel")?.scrollIntoView({ behavior: "smooth", block: "nearest" });
      return;
    }
    await refreshStructureSource(m);
    const phSel = allPhaseSelects()[0];
    const hasNamedPhase = phSel && [...phSel.options].some((o) => o.value && o.value.length > 0);
    const hasRootPhase = phSel && [...phSel.options].some((o) => o.value === "");
    if (!phaseId && hasNamedPhase && !hasRootPhase) {
      alert(i18nT("phase.pick_required"));
      phSel?.focus();
      return;
    }
    material = m;
    if (isDualStudyIntent()) {
      localStorage.setItem("optimqe.materialA", getDualMaterialA());
      localStorage.setItem("optimqe.materialB", getDualMaterialB());
      if ($("material-select")) $("material-select").value = m;
    }
    jobId = getDraftJob();
    sessionConfirmed = true;
    localStorage.setItem("optimqe.material", material);
    localStorage.setItem("optimqe.sessionIntent", sessionStudyIntent());
    localStorage.setItem("optimqe.job", jobId);
    localStorage.setItem("optimqe.phase", phaseId);
    localStorage.setItem("optimqe.sessionConfirmed", "1");
    setWorkspaceActive(true);
    if (sessionStudyIntent() === "doping") {
      await prepareDualEndpointInputs();
    } else {
      await bootstrapNmInputs(material, { silent: true, sync_followups: true }).catch(() => {});
    }
    await refreshMaterialType(material).catch(() => {});
    await refreshPhaseTypePanel(material).catch(() => {});
    await refreshJobsForDraft();
    // Liste vide → créer un job tout de suite pour que N° job ne soit plus vide
    if (!getDraftJob()) {
      const created = await createNewJob({ apply: false }).catch(() => null);
      if (created) {
        jobId = created;
        setJob(created);
        const sel = $("job-select");
        if (sel) sel.value = created;
      }
    } else {
      jobId = getDraftJob();
      setJob(jobId);
    }
    if (magOrderPick === "nm") {
      await applySpinToInputs({ material, silent: true, nspin: getSessionChainNspin() }).catch(() => {});
    }
    await sanitizeMaterialInputs({ silent: true }).catch(() => {});
    await refreshMaterials().catch(() => {});
    resetRunTracking();
    resetAutoResumeScope();
    if ($("jobs-board")) startJobsBoardAutoRefresh();
    if ($("optim-cards") && !PHASES_PREP_ONLY) {
      await refreshOptimStatus();
      if (magOrderPick === "nm") {
        await tryAutoResumeInterrupted();
      } else {
        await refreshMagOrders({ light: true, skipExtras: true }).catch(() => {});
      }
    } else if (PHASES_PREP_ONLY && magOrderPick !== "nm") {
      await refreshMagOrders({ light: true, skipExtras: true, skipCaseRepaint: true }).catch(() => {});
    }
    paintPhasesCalculsChainPanel();
    await refreshPhaseStability().catch(() => {});
    paintSessionStatus();
    paintStructurePanelVisibility();
    paintJobPanel();
    log("log-opt", i18nT("session.confirmed.log", {
      material,
      phase: phaseId || i18nT("phase.principal"),
      job: jobId || i18nT("label.job.none"),
    }), true);
    await refreshStudyGuide().catch(() => {});
    await refreshOutputFooterPaths().catch(() => {});
    if (document.getElementById("page-resultats")?.classList.contains("active")) {
      await refreshResults().catch(() => {});
    }
    syncMainAppNavLinks();
    if (PHASES_ONLY) {
      const intent = sessionStudyIntent();
      if (PHASES_PREP_ONLY) {
        if (magOrderPick !== "nm") {
          const afmList = await fetchAvailableAfmOrders(material).catch(() => []);
          const orders = ordersForMagInputRefresh(magOrderPick, afmList);
          await prepareMagOrders(orders.length ? orders : [magOrderPick], {
            silent: true,
            material,
          }).catch(() => {});
          await refreshMagOrders({ light: true, skipExtras: true, skipCaseRepaint: true }).catch(() => {});
        }
        if (intent === "doping") {
          switchSessionWorkTab("preparation");
          switchSessionSubTab("preparation", "prep-doped");
          log("log-opt", i18nT("session.prep_only.after_confirm_doping"), true);
        } else {
          switchSessionWorkTab("resultats");
          log("log-opt", i18nT("session.prep_only.after_confirm"), true);
        }
        await refreshMaterialIoProfile().catch(() => {});
        return;
      }
      const runPostConfirmChain = async () => {
        if (intent === "sqs") {
          if (magOrderPick === "nm") {
            await startStudyChainFromSession().catch((e) => alert(e.message));
          } else {
            log(
              "log-opt",
              i18nT("session.calc.sqs_mag_hint", { order: sessionMagOrderShort(magOrderPick) }),
              true
            );
            await refreshPhaseStability().catch(() => {});
          }
        } else if (magOrderPick === "nm") {
          await startStudyChainFromSession().catch((e) => alert(e.message));
        } else {
          const afmList = await fetchAvailableAfmOrders(material).catch(() => []);
          const orders = ordersForMagInputRefresh(magOrderPick, afmList);
          await prepareMagOrders(orders.length ? orders : [magOrderPick], { silent: true, material }).catch(() => {});
          await refreshMagOrders({ light: true, skipExtras: true, skipCaseRepaint: true }).catch(() => {});
          paintPhasesCalculsChainPanel();
          const magRow = magOrderRowFromLast(magOrderPick);
          const audit = await fetchMagOrderChainAudit(magOrderPick);
          applyMagOrderAuditToUi(magOrderPick, audit);
          if (magOrderInputsPrepared(magRow) && audit.ok) {
            await startStudyChainFromSession().catch((e) => alert(e.message));
          } else if (magOrderInputsPrepared(magRow)) {
            log("log-opt", i18nT("mag.audit.block_run", { order: sessionMagOrderShort(magOrderPick) }), false);
          } else {
            clearMagInputsVerified(magOrderPick);
            log(
              "log-opt",
              i18nT("phases.mag.prepared_no_autorun", {
                order: sessionMagOrderShort(magOrderPick),
                nspin: String(nspinForMagOrder(magOrderPick)),
              }),
              true
            );
          }
        }
      };
      if (intent === "doping" && magOrderPick === "nm") {
        switchSessionWorkTab("preparation");
        switchSessionSubTab("preparation", "prep-doped");
      } else {
        switchSessionWorkTab("calcul");
        switchSessionSubTab("calcul", resolveSessionCalcSubTab(intent));
        paintCalculNondopeLayout();
      }
      await runPostConfirmChain();
    }
    const dest = (lastStudy && lastStudy.next_tab) || "optimisation";
    const allowed = new Set(["optimisation", "phases", "magnetisme", "resultats", "proprietes"]);
    const next = allowed.has(dest) ? dest : "optimisation";
    if (next === "phases") {
      goPhasesApp();
      return;
    }
    switchTab(next);
  }

  function requireSessionConfirmed() {
    if (sessionConfirmed && material && draftsMatchSession()) return true;
    if (sessionConfirmed && material && reconcileSessionDrafts()) return true;
    alert(draftsMatchSession() ? i18nT("alert.confirm_session") : i18nT("alert.session_draft_mismatch"));
    $("btn-confirm-session")?.focus();
    return false;
  }

  function setJob(id) {
    jobId = id || "";
    localStorage.setItem("optimqe.job", jobId);
    const sel = $("job-select");
    if (sel) sel.value = jobId;
    syncJobSelectMirrors();
  }

  function invalidateDualCompose() {
    if (!isDualStudyIntent()) return;
    dualMaterialsValidated = false;
    localStorage.setItem("optimqe.dualValidated", "0");
    const compose = $("session-dual-compose");
    if (compose) compose.hidden = true;
    if (isDualStudyIntent()) setSessionValidateStatus("", "");
    paintStructurePanelVisibility();
    paintSessionStepHint();
  }

  /** Bascule active (ex. rerun depuis l’historique) : met à jour brouillon + confirme. */
  async function activateMaterialJob(mat, jid) {
    const m = normalizeMaterialInput(mat);
    if (!m) return;
    const inp = $("material-select");
    if (inp) inp.value = m;
    await refreshJobsForDraft();
    const sel = $("job-select");
    if (sel && jid) sel.value = jid;
    await applySelectedJob({ goFm: true });
  }

  // ------------------------------------------------------------------
  // Enchaînement VC-RELAX → RELAX → SCF — au choix de l'utilisateur :
  //   server : le backend enchaîne (survit à la fermeture de l'onglet)
  //   client : l'interface enchaîne via son polling (ancien comportement)
  //   off    : chaque calcul se lance à la main
  // ------------------------------------------------------------------
  const PIPELINE_MODES = ["server", "client", "off"];

  function legacyPipelineMode() {
    const saved = localStorage.getItem("optimqe.pipeline");
    if (PIPELINE_MODES.includes(saved)) return saved;
    if (saved === "0") return "off"; // ancienne case à cocher décochée
    if (saved === "1") return "client"; // ancienne case à cocher cochée
    return "server"; // défaut recommandé
  }

  let pipelineChain = legacyPipelineMode();

  function pipelineMode() {
    const sel = $("pipeline-chain");
    if (sel && sel.tagName === "SELECT" && PIPELINE_MODES.includes(sel.value)) return sel.value;
    return pipelineChain;
  }

  function initPipeline() {
    const el = $("pipeline-chain");
    if (!el) return;
    pipelineChain = legacyPipelineMode();
    if (el.tagName === "SELECT") {
      el.value = pipelineChain;
      el.addEventListener("change", () => {
        pipelineChain = PIPELINE_MODES.includes(el.value) ? el.value : "server";
        localStorage.setItem("optimqe.pipeline", pipelineChain);
      });
    } else {
      // Ancienne case à cocher (compatibilité)
      el.checked = pipelineChain !== "off";
      el.addEventListener("change", () => {
        pipelineChain = el.checked ? "client" : "off";
        localStorage.setItem("optimqe.pipeline", pipelineChain);
      });
    }
  }

  async function maybeChainAfterKind(kind, converged) {
    const mode = pipelineMode();
    if (mode === "off" || !converged || !material) return;
    if (mode === "server") {
      setTimeout(() => refreshOptimStatus().catch(() => {}), 2500);
      return;
    }
    if (mode === "client" && jobId) await attachNmAutorun(jobId).catch(() => null);
    if (kind === "vc-relax") {
      log("log-opt", i18nT("label.pipeline") + " → RELAX…", true);
      await runOptimKind("relax", { fromChain: true });
    } else if (kind === "relax") {
      log("log-opt", i18nT("label.pipeline") + " → SCF…", true);
      await syncScfFromChain().catch(() => {});
      await runOptimKind("scf", { fromChain: true });
    } else if (kind === "scf") {
      log("log-opt", i18nT("label.pipeline") + " → NSCF…", true);
      await runNscfOrder("nm");
    }
  }

  async function continueNmChainPoll(mat, jobIdForPoll, finishedKind) {
    if (pipelineMode() === "off" || finishedKind !== "scf") return false;
    if (jobIdForPoll) await attachNmAutorun(jobIdForPoll).catch(() => null);
    for (let attempt = 0; attempt < 8; attempt += 1) {
      if (attempt) await new Promise((res) => setTimeout(res, 700));
      await refreshOptimStatusBody().catch(() => null);
      const steps = lastOptimSteps || {};
      if (steps.nscf?.running) {
        startOptimPoll(mat, "nscf", jobIdForPoll || steps.nscf.job_id || jobId);
        return true;
      }
      if (steps.nscf?.converged) return false;
    }
    return false;
  }

  // ------------------------------------------------------------------
  // Spin (chaîne) : toujours nspin = 1 — FM/AFM/NCL = onglet Magnétisme
  // ------------------------------------------------------------------
  const CHAIN_NSPIN = 1;
  let nspinChoice = "1";
  const SESSION_MAG_ORDERS = [
    { order: "nm", short: "NM", nspin: 1 },
    { order: "fm", short: "FM", nspin: 2 },
    { order: "afm-g", short: "AFM-G", nspin: 2 },
    { order: "afm-a", short: "AFM-A", nspin: 2 },
    { order: "afm-b", short: "AFM-B", nspin: 2 },
    { order: "afm-c", short: "AFM-C", nspin: 2 },
    { order: "ncl", short: "NCL", nspin: 4 },
  ];
  let sessionMagOrder = (() => {
    try {
      return (localStorage.getItem("optimqe.session_mag_order") || "nm").trim().toLowerCase();
    } catch {
      return "nm";
    }
  })();

  function sessionMagOrderShort(order) {
    const o = String(order || "").trim().toLowerCase();
    const hit = SESSION_MAG_ORDERS.find((r) => r.order === o);
    if (hit) return hit.short;
    return o.replace(/^afm-/i, "AFM-").toUpperCase() || "NM";
  }

  function nspinForMagOrder(order) {
    const o = String(order || "nm").trim().toLowerCase();
    if (o === "ncl") return 4;
    if (o === "nm") return 1;
    return 2;
  }

  function getSessionMagOrder() {
    const el = $("session-mag-order");
    const v = (el && el.value ? el.value : sessionMagOrder || "nm").trim().toLowerCase();
    if (SESSION_MAG_ORDERS.some((r) => r.order === v)) return v;
    return "nm";
  }

  function syncSessionMagOrderFromUi() {
    const order = getSessionMagOrder();
    sessionMagOrder = order;
    try {
      localStorage.setItem("optimqe.session_mag_order", order);
    } catch (_) {
      /* ignore */
    }
    nspinChoice = String(nspinForMagOrder(order));
    const nsEl = $("session-chain-nspin");
    if (nsEl && order === "nm") {
      /* ne pas forcer nspin=2 quand l’ordre est FM/AFM/NCL */
    } else if (nsEl && order !== "nm") {
      suppressChainNspinChangeEvent = true;
      nsEl.value = "1";
      suppressChainNspinChangeEvent = false;
    }
    paintSessionMagChainNspinVisibility();
    paintGenerateInputsButtonLabel();
  }

  function paintGenerateInputsButtonLabel() {
    const btn = $("btn-generate-all-inputs");
    if (!btn) return;
    const short = sessionMagOrderShort(getSessionMagOrder());
    btn.textContent = i18nT("session.cif.generate_for", { order: short });
  }

  function magOrdersWithInputs(data) {
    const rows = (data && data.orders) || (lastMagOrders && lastMagOrders.orders) || [];
    return rows.filter((r) => {
      if (!r || r.order === "nm") return false;
      if (r.input_exists) return true;
      const vc = (r.steps || {})["vc-relax"];
      return !!(vc && (vc.input_exists || vc.output_exists));
    });
  }

  function resolveMagPrepareBannerText(data) {
    const d = data || lastMagOrders;
    if (!d) return sessionMagPrepareBannerText || "";
    if (d.auto_prepare_message) return String(d.auto_prepare_message);
    if (d.message && (d.ok || (Array.isArray(d.prepared) && d.prepared.length))) {
      return String(d.message);
    }
    if (d.prepare_banner) return String(d.prepare_banner);
    if (sessionMagPrepareBannerText) return sessionMagPrepareBannerText;
    const geo = d.geometry || {};
    if (!magGeoUsable(geo)) return "";
    const magRows = magOrdersWithInputs(d);
    if (!magRows.length) return "";
    const src = d.source || geo.source_kind || "scf";
    return i18nT("session.mag_order.prepare_banner", {
      n: String(magRows.length),
      src: String(src),
    });
  }

  function paintSessionMagPrepareBanner(data) {
    const el = $("session-mag-prepare-banner");
    if (!el) return;
    const text = resolveMagPrepareBannerText(data);
    if (text) sessionMagPrepareBannerText = text;
    if (!text || !resolveSessionStructureMaterial()) {
      el.hidden = true;
      el.textContent = "";
      el.className = "session-mag-prepare-banner meta";
      return;
    }
    el.hidden = false;
    el.textContent = text;
    const err = data && data.auto_prepared === false && data.auto_prepare_message;
    el.className = `session-mag-prepare-banner meta${err ? " is-warn" : ""}`;
  }

  async function paintSessionMagInputMode(matName) {
    const el = $("session-mag-input-mode");
    const hint = $("session-cif-generate-hint");
    const wf = $("session-mag-workflow");
    if (wf && window.qeI18n && window.qeI18n.apply) window.qeI18n.apply(wf);
    if (!el) return;
    const mat = String(matName || resolveSessionStructureMaterial()).trim();
    if (!mat || !structurePanelUnlocked()) {
      el.hidden = true;
      el.textContent = "";
      el.className = "session-mag-input-mode meta";
      return;
    }
    const inputs = await fetchNmInputsForMaterial(mat);
    const hasVc = inputs.some((r) => r.kind === "vc-relax");
    if (hasVc) {
      el.hidden = false;
      el.textContent = i18nT("session.mag_order.mode.ready");
      el.className = "session-mag-input-mode meta is-ready";
      if (hint) hint.hidden = false;
    } else {
      el.hidden = false;
      el.textContent = i18nT("session.mag_order.mode.need_cif");
      el.className = "session-mag-input-mode meta is-need-cif";
      if (hint) hint.hidden = false;
    }
    paintSessionMagPrepareBanner(lastMagOrders);
  }

  function paintSessionMagOrderOptions(availableAfm) {
    const el = $("session-mag-order");
    if (!el || !SESSION_MAG_ORDERS || !SESSION_MAG_ORDERS.length) return;
    const prev = getSessionMagOrder();
    const afmSet = new Set(
      (availableAfm && availableAfm.length ? availableAfm : ["afm-g", "afm-a", "afm-b", "afm-c"]).map((x) =>
        String(x).trim().toLowerCase()
      )
    );
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    el.innerHTML = "";
    SESSION_MAG_ORDERS.forEach((row) => {
      if (row.order.startsWith("afm-") && !afmSet.has(row.order)) return;
      const opt = document.createElement("option");
      opt.value = row.order;
      const nsLab = lang === "en" ? `nspin = ${row.nspin}` : `nspin = ${row.nspin}`;
      opt.textContent = `${row.short} · ${nsLab}`;
      el.appendChild(opt);
    });
    if ([...el.options].some((o) => o.value === prev)) el.value = prev;
    else if (el.options.length) el.value = el.options[0].value;
    syncSessionMagOrderFromUi();
  }

  async function refreshSessionMagOrderPick(mat) {
    paintSessionMagOrderOptions(["afm-g", "afm-a", "afm-b", "afm-c"]);
    const m = String(mat || "").trim();
    if (!m || !structurePanelUnlocked()) return;
    try {
      const data = await api(
        `/api/materials/${encodeURIComponent(m)}/mag-orders${magOrdersQuery({ light: true })}`
      );
      if (data && data.available_afm && data.available_afm.length) {
        paintSessionMagOrderOptions(data.available_afm);
      }
    } catch (_) {
      /* garde la liste complète AFM */
    }
  }
  let nspinApplySeq = 0;

  try {
    localStorage.removeItem("optimqe.nspin");
  } catch (_) {}

  function parseNspinChoice(_raw) {
    return CHAIN_NSPIN;
  }

  function paintNspinStatus(data) {
    const el = $("nspin-status");
    if (!el) return;
    if (!data || !data.ok) {
      if (data && data.error && !data.skipped) el.textContent = data.error;
      return;
    }
    const ns = CHAIN_NSPIN;
    const dir = data.dir ? `inputs/${String(data.dir).replace(/\/?$/, "/")}` : "";
    const files = (data.files || []).map((f) => `inputs/${f}`).join(", ");
    el.textContent = files
      ? i18nT("nspin.inputs.updated", { nspin: ns, files })
      : i18nT("nspin.status", { nspin: ns, dir: dir || "—" });
  }

  async function applySpinToInputs(options = {}) {
    const mat = (options.material || studyJobMaterial() || getDraftMaterial() || "").trim();
    if (!mat) return { ok: false, skipped: true };
    const ns = options.nspin != null ? Number(options.nspin) : getSessionChainNspin();
    const pid = String(options.phase_id || withPhaseBody({}).phase_id || activePhaseId() || "").trim();
    if (isDopedPhaseId(pid) && ns !== 1) {
      const order =
        getSessionMagOrder() !== "nm"
          ? getSessionMagOrder()
          : ns === 4
            ? "ncl"
            : "fm";
      return prepareMagOrders([order], {
        material: mat,
        phase_id: pid,
        silent: !!options.silent,
        allowBeforeConfirm: true,
      });
    }
    nspinChoice = String(ns === 2 ? 2 : 1);
    const seq = ++nspinApplySeq;
    const body = withPhaseBody({ nspin: ns });
    if (options.phase_id) body.phase_id = String(options.phase_id).trim();
    const data = await api(`/api/materials/${encodeURIComponent(mat)}/apply-spin`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (seq !== nspinApplySeq) return data;
    paintNspinStatus(data);
    if (data.ok) {
      const files = (data.files || []).join(", ") || (data.updated || []).join(", ");
      if (!options.silent && files) {
        log("log-opt", i18nT("nspin.inputs.updated", { nspin: ns, files }), true);
      }
      if (!$("optim-modal")?.hidden && optimEditKind) {
        openOptimEditor(optimEditKind).catch(() => {});
      }
    } else if (!options.silent) {
      log("log-opt", data.error || i18nT("nspin.inputs.failed"), false);
    }
    return data;
  }

  function initNspin() {
    const el = $("nspin-select");
    if (!el) return;
    nspinChoice = "1";
    if (el.tagName === "SELECT") {
      el.value = "1";
      el.disabled = true;
      el.title = i18nT("nspin.hint");
    }
    paintSessionMagChainNspinVisibility();
  }

  function nspinBody() {
    return { nspin: sessionConfirmed ? getSessionChainNspin() : CHAIN_NSPIN };
  }

  // ------------------------------------------------------------------
  // Parallélisme : contrôle runtime via /api/runtime (QE_NPROC / OMP)
  // ------------------------------------------------------------------
  function parallelModeFromRuntime(rt) {
    const mode = rt?.qe_launch_mode || "serial";
    return mode === "mpi_openmp" ? "mpi" : mode === "openmp" ? "openmp" : "serial";
  }

  function fillParallelWorkersSelect(workersEl, ncpu, selected) {
    if (!workersEl || !ncpu) return;
    const n = Math.max(1, Number(ncpu) || 1);
    const want = Math.max(1, Math.min(n, Number(selected) || 1));
    workersEl.innerHTML = "";
    for (let i = 1; i <= n; i += 1) {
      const opt = document.createElement("option");
      opt.value = String(i);
      opt.textContent = String(i);
      if (i === want) opt.selected = true;
      workersEl.appendChild(opt);
    }
  }

  function syncParallelWorkersUi(modeSel, workersEl, hintEl) {
    const serial = !modeSel || modeSel.value === "serial";
    if (workersEl) workersEl.disabled = serial;
    if (hintEl) hintEl.hidden = serial;
  }

  async function postParallelRuntime(modeSel, workersEl) {
    const mode = modeSel?.value || "serial";
    const body = { mode };
    if (mode !== "serial" && workersEl) {
      body.workers = parseInt(workersEl.value, 10) || 1;
    }
    const data = await api("/api/runtime", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    paintRuntime({ runtime: data.runtime });
    const p = data.runtime?.parallel;
    if (p && workersEl) fillParallelWorkersSelect(workersEl, p.cpu_count, p.workers);
    log("log-opt", data.message || `Parallélisme : ${mode}`, true);
    return data;
  }

  function hubbardMaterial() {
    return (material || getDraftMaterial() || "").trim();
  }

  function hubbardPhaseQuery() {
    const pid = activePhaseId() || getDraftPhase() || "";
    return phaseQueryFor(pid);
  }

  function collectHubbardU() {
    const u = {};
    document.querySelectorAll("[data-hubbard-u]").forEach((inp) => {
      const sp = inp.getAttribute("data-hubbard-u");
      if (!sp) return;
      const v = parseFloat(String(inp.value).replace(",", "."));
      u[sp] = Number.isFinite(v) ? v : 0;
    });
    return u;
  }

  function paintHubbardSpecies(data) {
    const rows = $("hubbard-species-rows");
    const status = $("hubbard-status");
    if (!rows) return;
    const species = data?.species || [];
    if (!species.length) {
      rows.innerHTML = `<p class="meta">${esc(i18nT("hubbard.empty"))}</p>`;
      if (status) status.textContent = "";
      lastHubbardReference = {};
      return;
    }
    const uMap = data.u_by_species || {};
    const refMap = data.reference_by_species || {};
    lastHubbardReference = refMap;
    rows.innerHTML = species
      .map(({ symbol, index }) => {
        const val = uMap[symbol] != null ? uMap[symbol] : 0;
        const ref = refMap[symbol];
        const refHint =
          ref && ref.correlated && ref.u > 0
            ? `<span class="hubbard-ref-hint">${esc(
                i18nT("hubbard.ref_hint", {
                  shell: ref.shell || "?",
                  u: String(ref.u),
                  uev: ref.u_ev != null ? String(ref.u_ev) : "",
                })
              )}</span>`
            : "";
        return (
          `<label class="hubbard-species-row">` +
          `<span class="hubbard-species-label">${esc(symbol)} <span class="meta">(${index})</span>${refHint}</span>` +
          `<input type="number" step="any" min="0" data-hubbard-u="${escAttr(symbol)}" value="${escAttr(String(val))}" title="${escAttr(i18nT("hubbard.col.u"))}" />` +
          `</label>`
        );
      })
      .join("");
  }

  async function refreshHubbardCatalog() {
    const body = $("hubbard-catalog-body");
    const note = $("hubbard-catalog-note");
    if (!body) return;
    try {
      const data = await api("/api/hubbard/reference");
      const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
      if (note) {
        note.textContent = lang === "en" ? data.note_en || data.note_fr : data.note_fr || data.note_en;
      }
      const elems = data.elements || [];
      body.innerHTML = elems
        .map((row) => {
          const u = row.u != null ? row.u : (row.u_ev != null ? row.u_ev : 0);
          const cls = row.correlated && u > 0 ? "is-correlated" : "";
          return (
            `<tr class="${cls}">` +
            `<td>${esc(row.symbol || "")}</td>` +
            `<td>${esc(row.shell || "")}</td>` +
            `<td>${u > 0 ? esc(String(u)) : "—"}</td>` +
            `</tr>`
          );
        })
        .join("");
    } catch (_) {
      if (note) note.textContent = "";
      body.innerHTML = "";
    }
  }

  function fillHubbardFromReference() {
    let n = 0;
    document.querySelectorAll("[data-hubbard-u]").forEach((inp) => {
      const sp = inp.getAttribute("data-hubbard-u");
      const ref = sp ? lastHubbardReference[sp] : null;
      if (ref && ref.correlated && ref.u > 0) {
        inp.value = String(ref.u);
        n += 1;
      }
    });
    const en = $("hubbard-enabled");
    if (en && n > 0) en.checked = true;
    const st = $("hubbard-status");
    if (st && n > 0) st.textContent = i18nT("hubbard.filled_ref");
  }

  let hubbardCatalogLoaded = false;

  function scheduleHubbardPanelRefresh() {
    if (hubbardRefreshTimer) clearTimeout(hubbardRefreshTimer);
    hubbardRefreshTimer = setTimeout(() => {
      refreshHubbardPanel().catch(() => {});
    }, 350);
  }

  async function refreshHubbardPanel(opts = {}) {
    const panel = $("mat-hubbard-panel");
    const mat = hubbardMaterial();
    if (!panel) return;
    if (!mat) {
      panel.hidden = true;
      lastHubbardKey = "";
      return;
    }
    panel.hidden = false;
    const key = `${mat}|${hubbardPhaseQuery()}`;
    const rows = $("hubbard-species-rows");
    if (
      !opts.force
      && key === lastHubbardKey
      && rows
      && rows.querySelector("[data-hubbard-u]")
    ) {
      return;
    }
    if (rows && !rows.querySelector("[data-hubbard-u]")) {
      rows.innerHTML = `<p class="meta">${esc(i18nT("hubbard.loading"))}</p>`;
    }
    try {
      const data = await api(
        `/api/materials/${encodeURIComponent(mat)}/hubbard${hubbardPhaseQuery()}`
      );
      lastHubbardKey = key;
      const en = $("hubbard-enabled");
      if (en) en.checked = !!data.enabled;
      paintHubbardSpecies(data);
    } catch (e) {
      const st = $("hubbard-status");
      if (st) st.textContent = i18nT("hubbard.err", { msg: String(e.message || e) });
    }
  }

  async function applyHubbardSettings() {
    const mat = hubbardMaterial();
    if (!mat) return;
    const st = $("hubbard-status");
    try {
      const data = await api(
        `/api/materials/${encodeURIComponent(mat)}/hubbard${hubbardPhaseQuery()}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            enabled: !!$("hubbard-enabled")?.checked,
            u_by_species: collectHubbardU(),
            apply_all: true,
            ...withPhaseBody({}),
          }),
        }
      );
      const n = (data.updated_files || []).length;
      if (st) {
        st.textContent = i18nT("hubbard.saved", { n: String(n) });
      }
      log("log-opt", st?.textContent || "DFT+U appliqué", true);
      lastHubbardKey = `${mat}|${hubbardPhaseQuery()}`;
      paintHubbardSpecies(data);
    } catch (e) {
      if (st) st.textContent = i18nT("hubbard.err", { msg: String(e.message || e) });
      log("log-opt", String(e.message || e), false);
    }
  }

  function initHubbard() {
    bind("btn-hubbard-apply", "click", () => {
      applyHubbardSettings().catch(() => {});
    });
    bind("btn-hubbard-fill-ref", "click", () => {
      fillHubbardFromReference();
    });
    const cat = $("hubbard-ref-catalog");
    if (cat) {
      cat.addEventListener("toggle", () => {
        if (cat.open && !hubbardCatalogLoaded) {
          hubbardCatalogLoaded = true;
          refreshHubbardCatalog().catch(() => {});
        }
      });
    }
    refreshHubbardPanel({ force: true }).catch(() => {});
    const matInp = $("material-select");
    if (matInp) {
      matInp.addEventListener("change", () => refreshHubbardPanel({ force: true }).catch(() => {}));
      matInp.addEventListener("input", scheduleHubbardPanelRefresh);
    }
  }

  async function initParallel() {
    const sel = $("parallel-select");
    const workersEl = $("parallel-workers");
    const hintEl = $("parallel-workers-hint");
    if (!sel) return;
    try {
      const data = await api("/api/tools");
      paintRuntime(data);
      const p = data.runtime?.parallel || {};
      sel.value = parallelModeFromRuntime(p);
      fillParallelWorkersSelect(workersEl, p.cpu_count, p.workers);
      syncParallelWorkersUi(sel, workersEl, hintEl);
    } catch (_) {
      sel.value = "serial";
      fillParallelWorkersSelect(workersEl, 4, 2);
      syncParallelWorkersUi(sel, workersEl, hintEl);
    }
    const onParallelChange = async () => {
      syncParallelWorkersUi(sel, workersEl, hintEl);
      try {
        await postParallelRuntime(sel, workersEl);
      } catch (e) {
        log("log-opt", String(e.message || e), false);
      }
    };
    sel.addEventListener("change", onParallelChange);
    if (workersEl) workersEl.addEventListener("change", onParallelChange);
  }

  function paintRuntime(data) {
    const el = $("runtime-info");
    const p = data?.runtime?.parallel;
    const t = data?.tools;
    if (el && p && t) {
      const slots =
        p.max_concurrent != null
          ? ` · ${p.max_concurrent} run(s) max (${p.max_concurrent_source || "auto"})`
          : "";
      el.textContent = `pw.x : ${t.pw_x || "introuvable"} · ${p.summary}${slots} · timeout ${Math.round((data.runtime.pw_timeout_sec || 0) / 3600)} h`;
    }
  }

  // ------------------------------------------------------------------
  // Matériaux / jobs
  // ------------------------------------------------------------------
  async function refreshMaterials() {
    const data = await api("/api/materials");
    materialsCache = data.materials || [];
    const optionsHtml = materialsCache
      .map((m) => {
        const typeLab = m.type_fr || m.type || "";
        const label = typeLab
          ? `[${typeLab}] ${m.name} — ${m.n_inputs} input(s)`
          : `${m.name} — ${m.n_inputs} input(s)`;
        return `<option value="${escAttr(m.name)}" label="${escAttr(label)}">${esc(label)}</option>`;
      })
      .join("");
    const dl = $("material-datalist");
    if (dl) dl.innerHTML = optionsHtml;
    const resDl = $("results-mat-datalist");
    if (resDl) resDl.innerHTML = optionsHtml;
    await refreshMaterialType(getDraftMaterial()).catch(() => {});
  }

  async function refreshJobs() {
    return refreshJobsForDraft();
  }

  // ------------------------------------------------------------------
  // Cartes de statut
  // ------------------------------------------------------------------
  function runPollBlocked() {
    return Date.now() < runPollSuppressUntil;
  }

  function sanitizeStaleRunningStep(st) {
    if (!st) return;
    if (!(st.running || st.run_phase === "running")) return;
    st.running = false;
    st.stopped = true;
    if (st.run_phase === "running") st.run_phase = "stopped";
  }

  function sanitizeStaleRunningFlags(steps) {
    if (!steps) return;
    for (const k of ["vc-relax", "relax", "scf", "nscf"]) {
      sanitizeStaleRunningStep(steps[k]);
    }
  }

  function sanitizeStaleMagOrderRunning(row) {
    if (!row) return;
    if (row.running || row.nscf_running) {
      row.running = false;
      row.nscf_running = false;
    }
    const sub = row.steps || {};
    for (const k of ["vc-relax", "relax", "scf", "nscf"]) {
      sanitizeStaleRunningStep(sub[k]);
    }
  }

  function settleUiAfterUserStop(kind, magOrder) {
    stopOptimPoll();
    document.querySelectorAll(".btn-nm-chain-stop, .btn-optim-stop, .btn-mag-stop").forEach((b) => {
      b.hidden = true;
    });
    document.querySelectorAll(".btn-nm-chain-run, .btn-mag-run, .btn-optim-run").forEach((b) => {
      b.disabled = false;
    });
    const mo = String(magOrder || "").trim().toLowerCase();
    if (mo) {
      paintLiveOnTrack(`track-mag-${mo}`, null);
      const row = document.querySelector(`.mag-case-row[data-order="${CSS.escape(mo)}"]`);
      row?.classList.remove("is-running");
      row?.querySelectorAll(".mag-pipe-step.is-run").forEach((el) => el.classList.remove("is-run"));
      const stEl = $(`status-mag-${mo}`);
      if (stEl) {
        stEl.textContent = i18nT("state.stopped");
        stEl.className = "mag-chain-banner warn";
      }
      if (PHASES_ONLY) {
        paintPhasesCalculsChainPanel();
        paintPhasesCalcStopBar();
      }
      return;
    }
    paintLiveOnTrack("track-nm-chain", null);
    $("nm-chain-card")?.classList.remove("is-running");
    document.querySelectorAll("#nm-optim-pipeline .mag-pipe-step.is-run").forEach((el) => {
      el.classList.remove("is-run");
    });
    const banner = $("status-nm-chain");
    if (banner) {
      banner.textContent = i18nT("state.stopped");
      banner.className = "mag-chain-banner warn";
    }
    if (PHASES_ONLY) {
      paintPhasesCalculsChainPanel();
      paintPhasesCalcStopBar();
    }
    if (lastOptimSteps && kind && lastOptimSteps[kind]) {
      sanitizeStaleRunningStep(lastOptimSteps[kind]);
    }
  }

  function stepIsRunning(step) {
    if (!step) return false;
    if (step.stopped === true) return false;
    if (step.run_phase === "stopped" || step.run_phase === "failed") return false;
    return !!(step.running || step.run_phase === "running");
  }

  function nmActiveStep(steps) {
    if (!steps) return null;
    for (const k of ["vc-relax", "relax", "scf", "nscf"]) {
      if (stepIsRunning(steps[k])) return k;
    }
    return null;
  }

  function nmLivePayload(steps, kind) {
    const st = (steps && steps[kind]) || {};
    return {
      ...st,
      kind,
      running: true,
      progress: st.run_progress || st.progress,
    };
  }

  function nmNscfStepState(steps) {
    const nscf = (steps && steps.nscf) || {};
    const scf = (steps && steps.scf) || {};
    if (nscf.running || nscf.run_phase === "running") {
      return { cls: "run", icon: "…", lab: i18nT("state.running") };
    }
    if (nscf.converged) return { cls: "ok", icon: "✓", lab: i18nT("state.converged") };
    if (nscf.run_phase === "failed" || nscf.run_phase === "stopped") {
      return { cls: "fail", icon: "✗", lab: i18nT("state.stopped") };
    }
    if (nscf.output_exists) return { cls: "partial", icon: "◐", lab: i18nT("mag.pipe.partial") };
    if (scf.converged || nscf.input_exists) {
      return { cls: "ready", icon: "○", lab: i18nT("mag.case.ready") };
    }
    return { cls: "idle", icon: "—", lab: "—" };
  }

  const CHAIN_KINDS_NM = ["vc-relax", "relax", "scf", "nscf"];
  const CHAIN_KINDS_MAG = ["vc-relax", "relax", "scf"];
  const CHAIN_KINDS_GEOM = CHAIN_KINDS_MAG;

  function phaseChainPollKind(row) {
    if (!row) return "vc-relax";
    const steps = row.chain_steps || {};
    for (const k of CHAIN_KINDS_GEOM) {
      const st = steps[k];
      if (st && (st.running || st.run_phase === "running")) return k;
    }
    const cr = row.chain_resume || {};
    if (cr.next_kind && CHAIN_KINDS_GEOM.includes(cr.next_kind)) return cr.next_kind;
    return "vc-relax";
  }

  function stepConverged(st) {
    if (!st) return false;
    if (st.converged === true) return true;
    if (st.scf_converged === true) return true;
    return false;
  }

  function chainStartKind(cr, steps, kinds = CHAIN_KINDS_NM) {
    if (cr && cr.next_kind) return cr.next_kind;
    if (cr && cr.all_done) return null;
    for (const k of kinds) {
      const st = steps && steps[k];
      if (!st) continue;
      if (st.running || st.run_phase === "running") return k;
      if (stepConverged(st)) continue;
      if (st.run_phase === "failed" || st.run_phase === "stopped") return k;
      if (st.output_exists && st.converged === false) return k;
      const idx = kinds.indexOf(k);
      const priorOk = idx <= 0 || kinds.slice(0, idx).every((pk) => stepConverged(steps[pk]));
      if (priorOk && (st.input_exists || st.output_exists)) return k;
    }
    return kinds[0];
  }

  function chainAnyStepRunning(steps, kinds = CHAIN_KINDS_NM) {
    return kinds.some((k) => {
      const s = steps && steps[k];
      return s && (s.running || s.run_phase === "running");
    });
  }

  function chainButtonMeta(cr, steps, kinds = CHAIN_KINDS_NM) {
    const startKind = chainStartKind(cr, steps, kinds) || kinds[0];
    const st = (steps && steps[startKind]) || {};
    const anyRunning = chainAnyStepRunning(steps, kinds);
    const completed = (cr && cr.completed) || [];
    const priorFail = !anyRunning && (
      !!(cr && cr.prior_fail)
      || st.run_phase === "failed"
      || st.run_phase === "stopped"
    );
    const partial = !anyRunning && (
      !!(cr && cr.partial) || (st.output_exists && !stepConverged(st))
    );
    const retry = !anyRunning && (
      !!(cr && cr.retry) || (partial || priorFail || (st.output_exists && !stepConverged(st)))
    );
    const resume = !!(cr && cr.resume) || completed.length > 0;
    let verbKey = "mag.chain.run";
    if (retry) verbKey = "mag.chain.launch_step";
    else if (resume) verbKey = "mag.chain.resume";
    const stepLab = String(startKind).toUpperCase();
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    let title = (lang === "en" ? (cr && cr.message_en) : (cr && cr.message_fr))
      || i18nT("mag.chain.title");
    if (retry && startKind === "scf" && !title.includes("conv")) {
      title += ` ${i18nT("mag.chain.hint_edit_scf")}`;
    }
    return {
      startKind,
      stepLab,
      label: `${i18nT(verbKey)} → ${stepLab}`,
      title,
      retry,
      resume,
      interrupted: retry || priorFail || partial,
    };
  }

  function stepNeedsFix(step) {
    if (!step || stepConverged(step)) return false;
    if (step.running || step.run_phase === "running") return false;
    return step.run_phase === "failed" || step.run_phase === "stopped"
      || step.output_exists
      || (step.run_phase === "done" && step.converged === false);
  }

  function chainFixPanelHtml(step, ctx = {}) {
    if (!stepNeedsFix(step)) return "";
    const kind = (ctx.kind || step.kind || "scf").toLowerCase();
    const stepLab = String(kind).toUpperCase();
    const order = ctx.order || "";
    const phaseId = ctx.phaseId || "";
    const tips = [...(step.hints || []), ...(step.solutions || [])].filter(Boolean).slice(0, 5);
    const tipsHtml = tips.length
      ? `<ul class="optim-hints chain-fix-hints">${tips.map((t) => `<li>${esc(t)}</li>`).join("")}</ul>`
      : `<p class="meta">${esc(i18nT("chain.fix.no_tips"))}</p>`;
    const n = Number(step.conv_adjust_level) || 0;
    const mx = Number(step.conv_adjust_max) || 4;
    const rescueLab = n > 0
      ? i18nT("btn.adjust_conv.again", { n: Math.min(n + 1, mx), max: mx })
      : i18nT("btn.adjust_conv");
    const balanced = kind === "scf" && !order
      ? `<button type="button" class="btn ghost btn-chain-fix-balanced" data-kind="scf">${esc(i18nT("opt.balanced.apply"))}</button>`
      : "";
    return `<div class="chain-fix-panel" role="region" aria-label="${escAttr(i18nT("chain.fix.title", { step: stepLab }))}">
      <p class="chain-fix-lead"><strong>${esc(i18nT("chain.fix.title", { step: stepLab }))}</strong> — ${esc(i18nT("chain.fix.lead", { step: stepLab }))}</p>
      ${tipsHtml}
      <div class="chain-fix-actions">
        <button type="button" class="btn ghost btn-chain-fix-edit" data-kind="${escAttr(kind)}" data-order="${escAttr(order)}" data-phase="${escAttr(phaseId)}">${esc(i18nT("btn.edit"))} ${stepLab}</button>
        <button type="button" class="btn ghost btn-chain-fix-rescue" data-kind="${escAttr(kind)}" data-order="${escAttr(order)}" data-phase="${escAttr(phaseId)}">${esc(rescueLab)}</button>
        ${balanced}
      </div>
      <p class="meta chain-fix-foot">${esc(i18nT("chain.fix.then_launch", { step: stepLab }))}</p>
    </div>`;
  }

  function ensureChainFixSlot(afterEl, id) {
    if (!afterEl) return null;
    let el = $(id);
    if (!el) {
      el = document.createElement("div");
      el.id = id.replace(/^#/, "");
      el.className = "chain-fix-host";
      afterEl.insertAdjacentElement("afterend", el);
    }
    return el;
  }

  function nmStepState(st) {
    if (!st) return { cls: "idle", icon: "—", lab: "—" };
    if (st.running || st.run_phase === "running") {
      return { cls: "run", icon: "…", lab: i18nT("state.running") };
    }
    if (stepConverged(st)) return { cls: "ok", icon: "✓", lab: i18nT("state.converged") };
    if (st.run_phase === "failed" || st.run_phase === "stopped") {
      return { cls: "fail", icon: "✗", lab: i18nT("state.stopped") };
    }
    if (st.output_exists) return { cls: "partial", icon: "◐", lab: i18nT("state.not_converged") };
    if (st.input_exists) return { cls: "ready", icon: "○", lab: i18nT("mag.case.ready") };
    return { cls: "idle", icon: "—", lab: "—" };
  }

  function paintNmOptimChain(data) {
    const pipe = $("nm-optim-pipeline");
    const banner = $("status-nm-chain");
    const card = $("nm-chain-card");
    const chainBtn = $("btn-nm-chain-run");
    const stopBtn = $("btn-nm-chain-stop");
    if (!pipe || !banner) return;
    if (!material) {
      pipe.innerHTML = "";
      banner.textContent = i18nT("opt.status.pick_mat") || "—";
      banner.className = "mag-chain-banner";
      if (chainBtn) chainBtn.disabled = true;
      if (stopBtn) stopBtn.hidden = true;
      if (card) card.classList.remove("is-running", "is-converged", "is-interrupted");
      const fixEmpty = $("nm-chain-fix");
      if (fixEmpty) { fixEmpty.innerHTML = ""; fixEmpty.hidden = true; }
      return;
    }
    if (!data) data = { steps: {}, chain_resume: {} };
    const steps = data.steps || {};
    const cr = data.chain_resume || {};
    const kinds = [
      { id: "vc-relax", label: "VC-RELAX" },
      { id: "relax", label: "RELAX" },
      { id: "scf", label: "SCF NM" },
    ];
    const active = nmActiveStep(steps);
    const canRun = sessionConfirmed && material;
    const scf = steps.scf || {};
    const nscf = steps.nscf || {};
    const allDone = !!cr.all_done || (!!nscf.converged && !active);
    const chainMeta = chainButtonMeta(cr, steps, CHAIN_KINDS_NM);
    const startKind = chainMeta.startKind;
    const failKind = chainMeta.retry ? startKind : "";
    const editDis = canRun ? "" : "disabled";
    const kindCells = kinds.map((k, i) => {
      const st = nmStepState(steps[k.id]);
      const stepData = steps[k.id] || {};
      const metricsSub = nmStepMetricsLine(stepData, k.id);
      const arrow = `<li class="mag-pipe-arrow" aria-hidden="true">→</li>`;
      const failCls = failKind === k.id ? " is-fail is-focus" : "";
      const runCls = stepData.running || stepData.run_phase === "running" ? " is-run" : "";
      return `<li class="mag-pipe-step is-${st.cls}${failCls}${runCls}" data-kind="${k.id}">
        <div class="mag-pipe-head">
          <span class="mag-pipe-num">${i + 1}</span>
          <strong class="mag-pipe-label">${k.label}</strong>
          <span class="mag-pipe-icon" title="${escAttr(st.lab)}">${st.icon}</span>
        </div>
        <span class="mag-pipe-state">${esc(st.lab)}</span>
        ${metricsSub ? `<span class="mag-pipe-metrics run-metrics">${esc(metricsSub)}</span>` : ""}
        ${stepData.percent != null && (stepData.running || stepData.run_phase === "running")
          ? `<div class="run-meter run-meter-compact"><div class="run-meter-fill" style="width:${Math.min(100, stepData.percent)}%"></div></div>`
          : ""}
        <button type="button" class="btn ghost btn-optim-edit" data-kind="${k.id}" ${editDis} title="${escAttr(i18nT("mag.edit.step", { kind: k.label }))}">${i18nT("btn.edit")}</button>
      </li>${arrow}`;
    }).join("");
    const nscfSt = nmNscfStepState(steps);
    const nscfMetrics = nmStepMetricsLine(nscf, "nscf");
    const nscfRunCls = nscf.running || nscf.run_phase === "running" ? " is-run" : "";
    pipe.innerHTML = `${kindCells}
      <li class="mag-pipe-step is-${nscfSt.cls}${nscfRunCls}" data-kind="nscf">
        <div class="mag-pipe-head">
          <span class="mag-pipe-num">4</span>
          <strong class="mag-pipe-label">NSCF</strong>
          <span class="mag-pipe-icon" title="${escAttr(nscfSt.lab)}">${nscfSt.icon}</span>
        </div>
        <span class="mag-pipe-state">${esc(nscfSt.lab)}</span>
        ${nscfMetrics ? `<span class="mag-pipe-metrics run-metrics">${esc(nscfMetrics)}</span>` : ""}
        ${nscf.percent != null && (nscf.running || nscf.run_phase === "running")
          ? `<div class="run-meter run-meter-compact"><div class="run-meter-fill" style="width:${Math.min(100, nscf.percent)}%"></div></div>`
          : ""}
        <button type="button" class="btn ghost btn-optim-edit" data-kind="nscf" ${editDis} title="${escAttr(i18nT("mag.edit.step", { kind: "NSCF" }))}">${i18nT("btn.edit")}</button>
        <span class="mag-pipe-note">${esc(nscfMetrics ? i18nT("mag.pipe.nscf_auto") : (nscf.run_progress || i18nT("mag.pipe.nscf_auto")))}</span>
      </li>`;
    const chainTitle = chainMeta.title;
    const balBtn = $("btn-nm-balanced");
    if (balBtn) {
      balBtn.disabled = !canRun || !!active;
      balBtn.title = i18nT("opt.balanced.hint");
    }
    if (chainBtn) {
      chainBtn.disabled = !canRun || !!active || allDone;
      chainBtn.textContent = chainMeta.label;
      chainBtn.title = chainTitle;
      chainBtn.dataset.kind = startKind || "vc-relax";
      chainBtn.classList.toggle("btn-chain-retry", !!chainMeta.retry);
    }
    if (stopBtn) {
      stopBtn.hidden = !active;
      stopBtn.dataset.kind = active || "vc-relax";
    }
    let bannerTxt = chainTitle;
    let liveCls = "";
    if (active === "nscf") {
      bannerTxt = i18nT("phase.nscf.running");
      const metricsLine = liveMetricsLabel({ ...nscf, kind: "nscf" }, "nscf");
      if (metricsLine) bannerTxt += ` · ${metricsLine}`;
      else if (nscf.run_progress) bannerTxt += ` · ${nscf.run_progress}`;
      liveCls = "running";
    } else if (active) {
      bannerTxt = i18nT("mag.banner.running", { order: "NM", step: String(active).toUpperCase() });
      liveCls = "running";
      const actSt = steps[active] || {};
      const metricsLine = liveMetricsLabel({ ...actSt, kind: active }, active);
      if (metricsLine) bannerTxt += ` · ${metricsLine}`;
      else if (actSt.run_progress) bannerTxt += ` · ${actSt.run_progress}`;
    } else if (allDone) {
      bannerTxt = i18nT("mag.banner.done", { order: "NM" });
      liveCls = "ok";
    } else if (chainMeta.interrupted || cr.prior_fail || cr.partial || cr.resume) {
      bannerTxt = chainTitle;
      liveCls = "warn";
    } else if (steps["vc-relax"]?.input_exists) {
      bannerTxt = i18nT("mag.banner.ready", { order: "NM" });
    }
    banner.textContent = bannerTxt;
    banner.className = `mag-chain-banner ${liveCls}`;
    const fixHost = ensureChainFixSlot(banner, "nm-chain-fix");
    const failStep = steps[startKind] || {};
    if (fixHost) {
      fixHost.innerHTML = (!active && chainMeta.retry && stepNeedsFix(failStep))
        ? chainFixPanelHtml({ ...failStep, kind: startKind }, { kind: startKind })
        : "";
      fixHost.hidden = !fixHost.innerHTML;
    }
    if (card) {
      card.classList.toggle("is-running", !!active);
      card.classList.toggle("is-converged", allDone && !active);
      card.classList.toggle("is-interrupted", !active && chainMeta.interrupted);
    }
    if (active) {
      const stEl = pipe.querySelector(`.mag-pipe-step[data-kind="${active}"]`);
      if (stEl) {
        stEl.classList.add("is-run");
      }
    }
    if (PHASES_ONLY) paintPhasesCalcStopBar();
  }

  function nmStepMetricsLine(step, kind) {
    if (!step || !(step.running || step.run_phase === "running")) return "";
    return liveMetricsLabel({ ...step, kind: kind || step.kind }, kind || step.kind);
  }

  function mergeLiveIntoOptimSteps(steps, kind, live) {
    if (!steps || !kind || !live) return;
    const st = steps[kind];
    if (!st) return;
    Object.assign(st, {
      running: !!live.running,
      run_phase: live.running ? "running" : st.run_phase,
      run_progress: live.progress || st.run_progress,
      iteration: live.iteration != null ? live.iteration : st.iteration,
      max_iterations: live.max_iterations != null ? live.max_iterations : st.max_iterations,
      scf_iteration: live.scf_iteration != null ? live.scf_iteration : st.scf_iteration,
      scf_max_iterations: live.scf_max_iterations != null ? live.scf_max_iterations : st.scf_max_iterations,
      percent: live.percent != null ? live.percent : st.percent,
      elapsed_s: live.elapsed_s != null ? live.elapsed_s : st.elapsed_s,
      progress_mode: live.progress_mode || st.progress_mode,
      iter_rate_per_min: live.iter_rate_per_min != null ? live.iter_rate_per_min : st.iter_rate_per_min,
      progress_rate_per_min: live.progress_rate_per_min != null ? live.progress_rate_per_min : st.progress_rate_per_min,
    });
  }

  function formatLiveBannerHtml(line, live) {
    let html = `<span class="mag-live-line">${esc(line)}</span>`;
    if (live && live.percent != null) {
      html += `<div class="run-meter run-meter-compact"><div class="run-meter-fill" style="width:${Math.min(100, live.percent)}%"></div></div>`;
    }
    return html;
  }

  function applyPipeStepLiveMetrics(pipeRoot, kind, live) {
    if (!pipeRoot || !kind || !live || !live.running) return;
    pipeRoot.querySelectorAll(".mag-pipe-step.is-run").forEach((el) => {
      if (el.dataset.kind !== kind) el.classList.remove("is-run");
    });
    const stepEl = pipeRoot.querySelector(`.mag-pipe-step[data-kind="${kind}"]`);
    if (!stepEl) return;
    stepEl.classList.add("is-run");
    const state = stepEl.querySelector(".mag-pipe-state");
    if (state) state.textContent = i18nT("state.running");
    const icon = stepEl.querySelector(".mag-pipe-icon");
    if (icon) icon.textContent = "…";
    const metrics = liveMetricsLabel(live, kind);
    let mEl = stepEl.querySelector(".mag-pipe-metrics");
    if (metrics) {
      if (!mEl) {
        mEl = document.createElement("span");
        mEl.className = "mag-pipe-metrics run-metrics";
        (state || stepEl.querySelector(".mag-pipe-head"))?.insertAdjacentElement("afterend", mEl);
      }
      mEl.textContent = metrics;
    } else if (mEl) mEl.remove();
    let meter = stepEl.querySelector(".run-meter-compact");
    if (live.percent != null) {
      if (!meter) {
        meter = document.createElement("div");
        meter.className = "run-meter run-meter-compact";
        meter.innerHTML = '<div class="run-meter-fill"></div>';
        (mEl || state)?.insertAdjacentElement("afterend", meter);
      }
      const fill = meter.querySelector(".run-meter-fill");
      if (fill) fill.style.width = `${Math.min(100, live.percent)}%`;
    } else if (meter) meter.remove();
  }

  function updateMagPipeLiveMetrics(magOrder, kind, live) {
    if (!magOrder || !kind || !live || !live.running) return;
    document.querySelectorAll(`.mag-case-row[data-order="${magOrder}"]`).forEach((row) => {
      const pipe = row.querySelector(".mag-pipeline");
      if (pipe) applyPipeStepLiveMetrics(pipe, kind, live);
    });
  }

  function updatePhasePipeLiveMetrics(phaseId, kind, live) {
    if (!phaseId || !kind || !live || !live.running) return;
    const host = $("phase-chain-pipeline-host");
    if (!host || host.hidden) return;
    const pipe = host.querySelector(`.phase-struct-pipeline[data-phase-id="${CSS.escape(phaseId)}"]`)
      || host.querySelector(".mag-pipeline");
    if (pipe) applyPipeStepLiveMetrics(pipe, kind, live);
  }

  function syncMagPipeLiveFromRow(row) {
    if (!row || row.order === "nm") return;
    const act = magOrderRunning(row);
    if (act) {
      const live = magLivePayloadFromRow(row, act.kind);
      live.running = true;
      updateMagPipeLiveMetrics(row.order, act.kind, live);
    }
    if (row.nscf_running) {
      const nLive = magLivePayloadFromRow(row, "nscf");
      nLive.running = true;
      updateMagPipeLiveMetrics(row.order, "nscf", nLive);
    }
  }

  function magLivePayloadFromRow(r, kind) {
    const steps = (r && r.steps) || {};
    const st = steps[kind] || {};
    return {
      ...st,
      kind,
      running: !!(st.running || st.run_phase === "running" || r.nscf_running && kind === "nscf"),
      progress: st.run_progress || st.progress,
      label: st.run_label || i18nT("state.running"),
      job_id: st.job_id || r.job_id || jobId,
    };
  }

  /** Suivi live carte FM/AFM/NCL (équivalent paintNmLiveFromSteps pour le magnétisme). */
  function paintMagLiveFromRow(r) {
    if (!r || r.order === "nm") return;
    const order = r.order;
    const trackId = `track-mag-${order}`;
    if (runPollBlocked()) {
      paintLiveOnTrack(trackId, null, { magOrder: order });
      return;
    }
    const act = magOrderRunning(r);
    if (!act) {
      if (!optimPollTimer) paintLiveOnTrack(trackId, null, { magOrder: order });
      return;
    }
    const live = magLivePayloadFromRow(r, act.kind);
    live.running = true;
    paintLiveOnTrack(trackId, live, { kind: act.kind, magOrder: order });
    updateMagPipeLiveMetrics(order, act.kind, live);
    if (r.nscf_running) {
      const nLive = magLivePayloadFromRow(r, "nscf");
      nLive.running = true;
      updateMagPipeLiveMetrics(order, "nscf", nLive);
    }
    const stEl = $(`status-mag-${order}`);
    if (stEl && live.running) {
      const short = (r.short || order).replace("afm-", "AFM-").toUpperCase();
      const metricsLine = liveMetricsLabel(live, act.kind);
      const line = [
        i18nT("mag.banner.running", { order: short, step: String(act.kind).toUpperCase() }),
        metricsLine,
      ].filter(Boolean).join(" · ");
      stEl.innerHTML = formatLiveBannerHtml(line, live);
      stEl.className = "mag-chain-banner running";
    }
    if (!optimPollTimer && !runPollBlocked() && sessionConfirmed && material) {
      attachPollIfLiveRunning(
        material,
        act.kind,
        act.job || jobId,
        order,
        activePhaseId(),
        trackId
      ).catch(() => {});
    }
  }

  function syncPhasesCalculsLiveTracks(magData) {
    if (!PHASES_ONLY || !sessionCalculsPanelVisible()) return;
    const order = getSessionMagOrder();
    if (order === "nm") {
      if (lastOptimSteps) paintNmLiveFromSteps(lastOptimSteps);
      refreshRuns().catch(() => {});
      return;
    }
    const rows = (magData && magData.orders) || (lastMagOrders && lastMagOrders.orders) || [];
    const row = rows.find((x) => x.order === order);
    if (row) paintMagLiveFromRow(row);
    refreshRuns().catch(() => {});
    if (row && magRowAnyRunning(row) && sessionConfirmed && material && !runsAutoTimer) {
      startRunsAutoRefresh();
    }
  }

  /** Panneau NM : suivi live depuis optim-status (tous types : vc-relax … nscf). */
  function paintNmLiveFromSteps(steps) {
    if (!material) {
      if (!optimPollTimer) paintLiveOnTrack("track-nm-chain", null);
      return;
    }
    if (runPollBlocked()) {
      paintLiveOnTrack("track-nm-chain", null);
      return;
    }
    const active = nmActiveStep(steps);
    if (!active) {
      if (!optimPollTimer) paintLiveOnTrack("track-nm-chain", null);
      return;
    }
    const live = nmLivePayload(steps, active);
    paintLiveOnTrack("track-nm-chain", live, { kind: active });
    if (sessionConfirmed && !optimPollTimer && !runPollBlocked() && live.job_id) {
      attachPollIfLiveRunning(material, active, live.job_id || jobId).catch(() => {});
    }
  }

  function appendLiveMetricBits(bits, live, kind) {
    const k = String(kind || live.kind || "").toLowerCase();
    if (live.progress_mode === "nscf_kpoints" && live.iteration != null && live.max_iterations != null) {
      bits.push(`${i18nT("res.kpoints")} ${live.iteration}/${live.max_iterations}`);
    }
    const geom = live.progress_mode === "bfgs" || k === "vc-relax" || k === "relax";
    if (geom && live.iteration != null) {
      if (live.max_iterations != null) {
        bits.push(`${i18nT("res.bfgs")} ${live.iteration}/${live.max_iterations}`);
      } else {
        bits.push(`${i18nT("res.bfgs")} #${live.iteration}`);
      }
      if (live.scf_iteration != null && live.scf_max_iterations != null) {
        bits.push(`${i18nT("res.scf_cycle")} ${live.scf_iteration}/${live.scf_max_iterations}`);
      } else if (live.scf_iteration != null) {
        bits.push(`${i18nT("res.scf_cycle")} #${live.scf_iteration}`);
      }
    } else if (live.iteration != null && live.max_iterations != null) {
      bits.push(`${i18nT("res.scf_cycle")} ${live.iteration}/${live.max_iterations}`);
    } else if (live.iteration != null) {
      bits.push(`${i18nT("res.scf_cycle")} #${live.iteration}`);
    }
    if (live.percent != null) bits.push(`≈ ${live.percent} %`);
    if (live.iter_rate_per_min != null) {
      bits.push(`${i18nT("res.iter_rate")} ≈ ${live.iter_rate_per_min} it./min`);
    }
    if (live.progress_rate_per_min != null) {
      bits.push(`${i18nT("res.progress_rate")} ≈ ${live.progress_rate_per_min} %/min`);
    }
    if (live.scf_ethr) bits.push(`${i18nT("res.scf_ethr")} ${live.scf_ethr}`);
  }

  function liveMetricsLabel(live, kind) {
    const parts = [];
    if (live.elapsed_s != null) parts.push(`${i18nT("res.elapsed")} ${fmtDuration(live.elapsed_s)}`);
    appendLiveMetricBits(parts, live, kind);
    return parts.join(" · ");
  }

  function statusProgressHtml(step) {
    if (!step || !step.run_progress) return "";
    return `<br/><span class="run-progress">${esc(i18nT("opt.status.progress"))} : ${esc(step.run_progress)}</span>`;
  }

  function statusLastRunHtml(step) {
    const lr = step && step.last_run;
    if (!lr || step.running || step.run_phase === "running") return "";
    const st = runState(lr);
    const when = lr.finished || lr.started || "";
    const dur = lr.duration_s != null ? fmtDuration(lr.duration_s) : "";
    return `<p class="run-line meta">${esc(i18nT("opt.status.last_run"))} : ` +
      `<span class="run-state ${escAttr(st.cls)}">${esc(i18nT(st.key))}</span>` +
      (when ? ` · ${esc(when)}` : "") +
      (dur ? ` · ${esc(dur)}` : "") +
      (lr.summary ? ` · ${esc(lr.summary)}` : "") +
      `</p>`;
  }

  function statusBoxHtml(step) {
    if (!step) return "—";
    const running = step.running || step.run_phase === "running";
    const label = running
      ? (step.run_label || i18nT("state.running"))
      : (step.run_label || (step.output_exists ? i18nT("state.not_converged") : "—"));
    const flag = !running && step.converged
      ? `<span class="conv-flag">${esc(i18nT("state.converged"))}</span>`
      : `<strong>${esc(label)}</strong>`;
    let html = `${flag}${statusProgressHtml(step)}${statusLastRunHtml(step)}`;

    if (running) {
      return html;
    }

    if (step.run_phase === "done" || step.run_phase === "failed" || step.output_exists || step.input_exists) {
      html += `<br/><code>${esc(step.input_path || "")}</code>`;
      if (step.output_path) html += `<br/>out : <code>${esc(step.output_path)}</code>`;
    } else if (!step.input_exists) {
      return `Input absent : <code>${esc(step.input_path || "")}</code>`;
    } else {
      html += `<br/>Input prêt · <code>${esc(step.input_path || "")}</code>`;
    }
    if (step.hints && step.hints.length) {
      html += `<ul class="optim-hints">${step.hints.map((h) => `<li>${esc(h)}</li>`).join("")}</ul>`;
    }
    return step.converged ? html : html + solutionsHtml(step);
  }

  function paintOptimStatus(step, el) {
    if (!el) return;
    if (!step) {
      el.textContent = "—";
      el.className = "optim-status";
      return;
    }
    el.innerHTML = statusBoxHtml(step);
    let cls = step.converged ? "ok" : step.output_exists ? "warn" : step.input_exists ? "" : "bad";
    if (step.running || step.run_phase === "running") cls = "running";
    else if (step.run_phase === "done" && step.converged) cls = "ok";
    else if (step.run_phase === "failed" || (step.output_exists && !step.converged)) cls = "warn";
    el.className = "optim-status " + cls;
    const card = el.closest(".optim-card");
    if (card) {
      card.classList.toggle("is-converged", cls === "ok");
      const stopBtn = card.querySelector(".btn-optim-stop");
      if (stopBtn) stopBtn.hidden = !(step.running || step.run_phase === "running");
    }
  }

  function stopOptimStatusTimer() {
    if (optimStatusTimer) {
      clearInterval(optimStatusTimer);
      optimStatusTimer = null;
    }
  }

  function startOptimStatusTimer() {
    stopOptimStatusTimer();
    if (!sessionConfirmed || !material) return;
    optimStatusTimer = setInterval(() => {
      refreshOptimStatus().catch(() => {});
    }, 4000);
  }

  let optimStatusBusy = false;

  /** Une seule enquête de statut à la fois : empêche les timers de s'empiler
   *  (rafale de GET /optim-status quand l'API est lente). */
  async function refreshOptimStatus() {
    if (optimStatusBusy) return;
    optimStatusBusy = true;
    try {
      await refreshOptimStatusBody();
    } finally {
      optimStatusBusy = false;
    }
  }

  async function refreshOptimStatusBody() {
    const banner = $("optim-banner");
    if (!material) {
      paintNmOptimChain(null);
      if (banner) banner.hidden = true;
      paintRunsEmpty();
      stopOptimStatusTimer();
      return;
    }
    const data = await api(`/api/materials/${encodeURIComponent(material)}/optim-status${phaseQuery()}`);
    lastOptimStatus = data;
    rememberStructure(data);
    paintSessionStatus();
    const steps = data.steps || {};
    if (runPollBlocked()) sanitizeStaleRunningFlags(steps);
    lastOptimSteps = steps;
    lastNmChainResume = data.chain_resume || {};
    paintNmOptimChain(data);
    paintNmLiveFromSteps(steps);
    paintSessionChainPlan();
    await ensureNmAutorunForSteps(steps);
    if (banner) {
      const st = lastStudy;
      if (st && st.next_fr && data.scf_ready) {
        banner.hidden = false;
        const span = banner.querySelector("span");
        if (span) span.textContent = st.next_fr;
      } else {
        banner.hidden = !data.scf_ready;
      }
    }
    refreshHubbardPanel().catch(() => {});
    let anyRunning = false;
    let nmRunKind = null;
    for (const k of ["vc-relax", "relax", "scf", "nscf"]) {
      if (stepIsRunning(steps[k])) {
        anyRunning = true;
        nmRunKind = k;
        break;
      }
    }
    if (anyRunning && nmRunKind && sessionConfirmed && !optimPollTimer && !runPollBlocked()) {
      attachPollIfLiveRunning(material, nmRunKind, jobId || steps[nmRunKind].job_id).then((ok) => {
        if (!ok && steps[nmRunKind]) {
          sanitizeStaleRunningStep(steps[nmRunKind]);
          paintNmOptimChain(lastOptimStatus);
        }
      }).catch(() => {});
    }
    const tab = currentTab();
    const magPollMs = optimPollTimer ? 15000 : 5000;
    const magPollDue = Date.now() - lastMagOrdersRefresh > magPollMs;
    const needMagPoll =
      magPollDue
      && (
        tab === "magnetisme"
        || tab === "resultats"
        || sessionCalculsPanelVisible()
        || sessionPhasePanelVisible()
        || (!!optimPollTimer && tab !== "optimisation")
      );
    const magData = needMagPoll
      ? await refreshMagOrders({
          skipCaseRepaint: tab !== "magnetisme",
          autoPrepare: false,
          light: !!optimPollTimer || tab !== "magnetisme",
        }).catch(() => null)
      : lastMagOrders;
    if (needMagPoll) lastMagOrdersRefresh = Date.now();
    if (runPollBlocked() && magData && magData.orders) {
      magData.orders.forEach((r) => sanitizeStaleMagOrderRunning(r));
    }
    maybeAutoResumeFromStatus(data, magData);
    if (!anyRunning && magData) {
      for (const r of magData.orders || []) {
        const run = magOrderRunning(r);
        if (run) {
          anyRunning = true;
          if (!optimPollTimer && !runPollBlocked()) {
            attachPollIfLiveRunning(material, run.kind, jobId || run.job, run.order).catch(() => {});
          }
          break;
        }
      }
    }
    const fmAct = magData && !runPollBlocked() && !optimPollTimer && magOrderRunning(fmMagRow());
    if (banner && fmAct && !anyRunning) {
      banner.hidden = false;
      const span = banner.querySelector("span");
      const hint = i18nT("mag.step.running", { step: String(fmAct.kind).toUpperCase() })
        + " · FM · " + i18nT("session.goto.mag");
      if (span) span.textContent = hint;
      else banner.textContent = hint;
    }
    if (!anyRunning && !optimPollTimer) startOptimStatusTimer();
    else if (anyRunning) stopOptimStatusTimer();
    if (lastOptimSteps) paintNmLiveFromSteps(lastOptimSteps);
    syncPhasesCalculsLiveTracks(magData);
    let magRunningUi = false;
    for (const r of (magData && magData.orders) || []) {
      if (magRowAnyRunning(r)) {
        magRunningUi = true;
        break;
      }
    }
    if (anyRunning || magRunningUi || optimPollTimer) {
      await refreshRuns().catch(() => {});
      if (Date.now() - jobsBoardTs > 20000) {
        jobsBoardTs = Date.now();
        refreshJobsBoard().catch(() => {});
      }
    }
    if ((anyRunning || magRunningUi) && sessionConfirmed && material && !runsAutoTimer) {
      startRunsAutoRefresh();
    }
  }

  function stopRunsAutoRefresh() {
    if (runsAutoTimer) {
      clearInterval(runsAutoTimer);
      runsAutoTimer = null;
    }
  }

  function startRunsAutoRefresh() {
    stopRunsAutoRefresh();
    refreshRuns().catch(() => {});
    runsAutoTimer = setInterval(() => refreshRuns().catch(() => {}), 2500);
  }

  function stopOptimPoll() {
    if (optimPollTimer) {
      clearInterval(optimPollTimer);
      optimPollTimer = null;
    }
    stopRunsAutoRefresh();
    startOptimStatusTimer();
  }

  function liveMetricsHtml(live, kind) {
    const line = liveMetricsLabel(live, kind);
    if (!line) return "";
    return `<br/><span class="run-progress">${esc(line)}</span>`;
  }

  /** Panneau de suivi temps réel (NM / FM / AFM / phases) — même modèle que l’ancien onglet Synthèse. */
  function runTrackingPanelHtml(st, kind, opts = {}) {
    if (!st || !st.running) return "";
    const k = String(kind || st.kind || "").toLowerCase();
    const showStop = opts.showStop !== false;
    const magOrder = opts.magOrder || "";
    const fullElectronic = opts.fullElectronic === true;
    const progLine = st.progress || st.run_progress;
    let html = `<div class="result-pills"><span class="pill ok">${esc(i18nT("state.running"))}</span>`;
    const stepLab = st.label || st.run_label;
    if (stepLab && stepLab !== i18nT("state.running")) {
      html += ` <span class="track-live-step">${esc(stepLab)}</span>`;
    }
    html += `</div>`;
    if (progLine) html += `<p class="run-progress">${esc(progLine)}</p>`;
    const bits = [];
    if (st.elapsed_s != null) bits.push(`${i18nT("res.elapsed")} ${fmtDuration(st.elapsed_s)}`);
    appendLiveMetricBits(bits, st, k);
    if (bits.length) html += `<p class="run-metrics">${bits.map(esc).join(" · ")}</p>`;
    else if (progLine && progLine !== "pw.x en cours…") {
      html += `<p class="run-metrics">${esc(progLine)}</p>`;
    }
    if (st.percent != null) {
      html += `<div class="run-meter"><div class="run-meter-fill" style="width:${Math.min(100, st.percent)}%"></div></div>`;
    }
    html += `<p class="meta track-live-hint">${i18nT("res.running.hint")}</p>`;
    if (showStop) {
      html += `<button class="btn ghost btn-run-stop" type="button" data-kind="${escAttr(st.kind || k)}"` +
        (magOrder ? ` data-mag-order="${escAttr(magOrder)}"` : "") +
        `>${i18nT("btn.stop")}</button>`;
    }
    if (fullElectronic) html += scfMagneticBlock(st);
    return html;
  }

  function resultsRunningDeferHtml(kind) {
    const tab = kind === "scf" || kind === "vc-relax" || kind === "relax" ? "optimisation" : "optimisation";
    return (
      `<div class="result-pills"><span class="pill ok">${esc(i18nT("state.running"))}</span></div>` +
      `<p class="meta">${esc(i18nT("res.running.defer"))}</p>` +
      `<button type="button" class="btn ghost btn-goto-tracking" data-tab="${escAttr(tab)}">${esc(i18nT("res.goto.tracking"))}</button>`
    );
  }

  async function fetchRunLive(mat, kind, jobIdForPoll, magOrder, structurePhaseId) {
    const parts = [];
    if (jobIdForPoll) parts.push(`job_id=${encodeURIComponent(jobIdForPoll)}`);
    if (magOrder) parts.push(`mag_order=${encodeURIComponent(magOrder)}`);
    const q = phaseQueryFor(structurePhaseId, parts.length ? `?${parts.join("&")}` : "");
    if (structurePhaseId && !magOrder) {
      for (const k of ["vc-relax", "relax", "scf", "nscf"]) {
        const live = await api(`/api/materials/${encodeURIComponent(mat)}/run-live/${encodeURIComponent(k)}${q}`);
        if (live.running) return { live: { ...live, kind: k }, pollKind: k };
      }
    }
    let live = await api(`/api/materials/${encodeURIComponent(mat)}/run-live/${encodeURIComponent(kind)}${q}`);
    let pollKind = kind;
    if (magOrder && live.active_kind && live.active_kind !== kind && live.running) {
      pollKind = live.active_kind;
      live = await api(`/api/materials/${encodeURIComponent(mat)}/run-live/${encodeURIComponent(pollKind)}${q}`);
    }
    return { live: { ...live, kind: pollKind }, pollKind };
  }

  function startOptimPoll(mat, kind, jobIdForPoll, magOrder, structurePhaseId, trackIdOverride) {
    if (runPollBlocked()) return;
    stopOptimPoll();
    startRunsAutoRefresh();
    if (!magOrder && !structurePhaseId && jobIdForPoll) attachNmAutorun(jobIdForPoll).catch(() => {});
    const tick = async () => {
      if (!mat) return;
      if (runPollBlocked()) {
        stopOptimPoll();
        return;
      }
      try {
        const { live, pollKind } = await fetchRunLive(mat, kind, jobIdForPoll, magOrder, structurePhaseId);
        if (magOrder && live.active_kind && live.active_kind !== pollKind && live.running) {
          startOptimPoll(mat, live.active_kind, jobIdForPoll || live.job_id, magOrder, structurePhaseId, trackIdOverride);
          return;
        }
        await refreshRuns().catch(() => {});
        if (Date.now() - jobsBoardTs > 12000) {
          jobsBoardTs = Date.now();
          refreshJobsBoard().catch(() => {});
        }
        const statusId = magOrder ? `status-mag-${magOrder}` : (structurePhaseId ? "status-phase-chain" : "status-nm-chain");
        let trackId = trackIdOverride;
        if (!trackId) {
          trackId = magOrder ? `track-mag-${magOrder}` : "track-nm-chain";
        }
        paintLiveOnTrack(trackId, live, { kind: pollKind, magOrder: magOrder || "" });
        if (magOrder) {
          clearMagCaseChainFix(magOrder);
          updateMagPipeLiveMetrics(magOrder, pollKind, live);
        } else if (structurePhaseId && live.running) {
          if (lastPhaseStability && lastPhaseStability.phases) {
            const prow = lastPhaseStability.phases.find((p) => p.phase_id === structurePhaseId);
            if (prow && prow.chain_steps) mergeLiveIntoOptimSteps(prow.chain_steps, pollKind, live);
          }
          updatePhasePipeLiveMetrics(structurePhaseId, pollKind, live);
        } else if (lastOptimStatus && lastOptimStatus.steps && live.running && !runPollBlocked()) {
          mergeLiveIntoOptimSteps(lastOptimStatus.steps, pollKind, live);
          paintNmOptimChain(lastOptimStatus);
        }
        const el = $(statusId);
        if (el && live.label) {
          const stepLab = magOrder && live.running
            ? i18nT("mag.step.running", { step: String(pollKind).toUpperCase() })
            : (live.running && structurePhaseId
              ? i18nT("phase.chain.running", {
                phase: structurePhaseId,
                step: String(pollKind).toUpperCase(),
              })
              : (live.running && !magOrder
                ? i18nT("mag.banner.running", { order: "NM", step: String(pollKind).toUpperCase() })
                : live.label));
          const prog = live.progress ? ` · ${live.progress}` : "";
          const metrics = liveMetricsLabel(live, pollKind);
          const line = [stepLab, metrics].filter(Boolean).join(" · ") + prog;
          if (live.converged && !live.running) {
            el.textContent = i18nT("state.converged");
          } else if (live.running) {
            el.innerHTML = formatLiveBannerHtml(line, live);
          } else {
            el.textContent = line;
          }
          el.className = "mag-chain-banner " + (live.running ? "running" : live.converged ? "ok" : "warn");
          el.closest(".optim-card, .mag-case-row, .nm-chain-row")?.classList.toggle(
            "is-converged",
            !!live.converged && !live.running
          );
        }
        if (live.finished) {
          if (magOrder && await continueMagChainPoll(mat, magOrder, jobIdForPoll, pollKind, live)) {
            return;
          }
          if (!magOrder && !structurePhaseId && await continueNmChainPoll(mat, jobIdForPoll || live.job_id, pollKind)) {
            return;
          }
          stopOptimPoll();
          log("log-opt", { label: live.label, converged: live.converged, kind: magOrder || kind }, live.converged === true);
          await refreshJobs();
          await refreshMaterials();
          await refreshOptimStatus();
          if (kind === "nscf" || magOrder) {
            await refreshMagOrders().catch(() => {});
          }
          if (kind === "nscf" || !magOrder || structurePhaseId) {
            await refreshPhaseStability().catch(() => {});
          }
          await refreshRuns().catch(() => {});
          refreshJobsBoard().catch(() => {});
          document.querySelectorAll(".btn-optim-run, .btn-mag-run").forEach((b) => { b.disabled = false; });
          document.querySelectorAll(".btn-optim-stop, .btn-nm-chain-stop").forEach((b) => { b.hidden = true; });
          if (live.converged === true && !magOrder) {
            await maybeChainAfterKind(kind, true);
          }
        }
      } catch (_) {
        /* erreurs de polling transitoires ignorées */
      }
    };
    tick();
    optimPollTimer = setInterval(tick, 2000);
  }

  // ------------------------------------------------------------------
  // Éditeur d'input
  // ------------------------------------------------------------------
  async function openOptimEditor(kind) {
    if (!requireSessionConfirmed()) return;
    if (!material) { alert(i18nT("alert.pick_mat")); return; }
    magEditOrder = "";
    magEditKind = "scf";
    optimEditPhaseId = null;
    optimEditPhaseMat = null;
    optimEditKind = kind;
    const data = await api(`/api/materials/${encodeURIComponent(material)}/input/${encodeURIComponent(kind)}${phaseQuery()}`);
    $("optim-modal-title").textContent = `Éditer ${kind.toUpperCase()}`;
    $("optim-modal-path").textContent = data.path || "";
    $("optim-modal-text").value = data.content || "";
    $("optim-modal").hidden = false;
  }

  async function openMagEditorForPhase(order, kind, mat, phaseIdOverride) {
    const m = (mat || studyJobMaterial() || material || "").trim();
    if (!m) {
      alert(i18nT("alert.pick_mat"));
      return;
    }
    optimEditKind = "";
    magEditOrder = String(order || "fm").trim().toLowerCase();
    const k = (kind || "scf").toLowerCase();
    magEditKind = ["vc-relax", "relax", "scf", "nscf"].includes(k) ? k : "scf";
    const pid = phaseIdOverride != null ? String(phaseIdOverride) : activePhaseId();
    optimEditPhaseId = pid;
    optimEditPhaseMat = m;
    const q = phaseQueryFor(pid);
    const kindQ = `kind=${encodeURIComponent(magEditKind)}`;
    const magUrl =
      `/api/materials/${encodeURIComponent(m)}/mag-orders/input/${encodeURIComponent(magEditOrder)}` +
      (q ? `${q}&${kindQ}` : `?${kindQ}`);
    const data = await api(magUrl);
    if (data && data.ok === false) {
      alert(data.error || i18nT("mag.prepare.fail"));
      return;
    }
    const ns = data.nspin != null ? data.nspin : magEditOrder === "ncl" ? 4 : 2;
    const short = data.short || String(magEditOrder).toUpperCase();
    $("optim-modal-title").textContent = i18nT("mag.edit.title", {
      order: short,
      kind: String(magEditKind).toUpperCase(),
      nspin: String(ns),
    });
    $("optim-modal-path").textContent = data.path || "";
    $("optim-modal-text").value = data.content || "";
    paintOptimModalNspinAudit(data.content || "", magEditOrder);
    $("optim-modal").hidden = false;
  }

  async function openMagEditor(order, kind) {
    if (!requireSessionConfirmed()) return;
    await openMagEditorForPhase(order, kind, studyJobMaterial() || material, activePhaseId());
  }

  async function saveOptimEditor() {
    const content = $("optim-modal-text").value;
    if (magEditOrder) {
      const saveMat = (optimEditPhaseMat || studyJobMaterial() || material || "").trim();
      if (!saveMat) return;
      const body = withPhaseBody({ content, kind: magEditKind || "scf" });
      if (optimEditPhaseId) body.phase_id = optimEditPhaseId;
      const data = await api(
        `/api/materials/${encodeURIComponent(saveMat)}/mag-orders/input/${encodeURIComponent(magEditOrder)}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        }
      );
      log("log-opt", data, !!data.ok);
      const nmTxt = await nmInputTextForMagAudit(material);
      const audit = auditMagInputForOrder(content, magEditOrder, nmTxt);
      if (!audit.ok) log("log-opt", { note: audit.message, audit: true }, false);
      $("optim-modal").hidden = true;
      lastMagCasePaintKey = "";
      await refreshMagOrders().catch(() => {});
      await refreshMagOrderInputAudit(magEditOrder).catch(() => {});
      if (PHASES_ONLY) paintPhasesCalculsChainPanel();
      return;
    }
    if (!optimEditKind) return;
    const saveMat = optimEditPhaseMat || studyJobMaterial() || material;
    if (!saveMat) return;
    if (isDopedPhaseId(optimEditPhaseId)) {
      const nmAudit = auditMagInputNspin(content, "nm");
      if (nmAudit.found != null && nmAudit.found !== 1) {
        alert(i18nT("phase.edit.doping_nm_nspin_warn"));
        return;
      }
    }
    const savePayload = { content };
    if (optimEditPhaseId !== null) savePayload.phase_id = optimEditPhaseId;
    const data = await api(`/api/materials/${encodeURIComponent(saveMat)}/input/${encodeURIComponent(optimEditKind)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(withPhaseBody(savePayload)),
    });
    let msg = data;
    if (data.structure_ok === false) {
      msg = { ...data, note: data.structure_hint || "Structure non lue par l'interface." };
    }
    log("log-opt", msg, data.structure_ok !== false && !!data.ok);
    $("optim-modal").hidden = true;
    optimEditPhaseId = null;
    optimEditPhaseMat = null;
    const savedKind = optimEditKind || magEditKind || "scf";
    log("log-opt", i18nT("chain.fix.after_save", { step: String(savedKind).toUpperCase() }), true);
    await refreshOptimStatus();
    await refreshPhaseStability().catch(() => {});
    await refreshMagOrders().catch(() => {});
  }

  // ------------------------------------------------------------------
  // Lancement
  // ------------------------------------------------------------------
  function resetAutoResumeScope() {
    autoResumeScope = "";
  }

  function chainResumeWantsAutostart(cr) {
    if (!cr || cr.all_done || !cr.next_kind) return false;
    return !!(
      cr.resume
      || cr.retry
      || cr.partial
      || cr.prior_fail
      || (cr.completed && cr.completed.length)
    );
  }

  async function tryAutoResumeInterrupted() {
    if (PHASES_PREP_ONLY) return;
    if (!sessionConfirmed || !material) return;
    const scope = `${material}|${phaseId || ""}`;
    if (autoResumeScope === scope) return;
    try {
      const data = await api(
        `/api/materials/${encodeURIComponent(material)}/resume-interrupted`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(withPhaseBody({})),
        }
      );
      autoResumeScope = scope;
      const launched = data.launched || [];
      if (!launched.length) return;
      const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
      const msg =
        lang === "en"
          ? data.message_en || data.message_fr
          : data.message_fr || data.message_en;
      log("log-opt", msg || i18nT("autoresume.started"), true);
      for (const item of launched) {
        if (!item.ok) continue;
        const mo = item.mag_order || "";
        const kind = item.kind || "vc-relax";
        const jid = item.job_id || jobId;
        if (jid && jid !== jobId) setJob(jid);
        if (jid && !mo) await attachNmAutorun(jid);
        startOptimPoll(material, kind, jid, mo || null);
      }
      jobsBoardTs = 0;
      await refreshOptimStatus();
    } catch (_) {
      /* API indisponible au chargement : maybeAutoResumeFromStatus réessaiera */
    }
  }

  function maybeAutoResumeFromStatus(data, magData) {
    if (PHASES_PREP_ONLY) return;
    if (!sessionConfirmed || !material || !data || runPollBlocked()) return;
    const steps = data.steps || {};
    for (const k of ["vc-relax", "relax", "scf", "nscf"]) {
      if (stepIsRunning(steps[k])) return;
    }
    if (chainResumeWantsAutostart(data.chain_resume)) {
      tryAutoResumeInterrupted().catch(() => {});
      return;
    }
    const orders = (magData && magData.orders) || (lastMagOrders && lastMagOrders.orders) || [];
    for (const row of orders) {
      if (chainResumeWantsAutostart(row.chain_resume)) {
        tryAutoResumeInterrupted().catch(() => {});
        return;
      }
    }
  }

  async function attachNmAutorun(jid) {
    const id = String(jid || jobId || "").trim();
    if (!material || !id || nmAutorunJobs.has(id)) return;
    try {
      const data = await api(
        `/api/materials/${encodeURIComponent(material)}/nm-chain/attach-autorun`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(withPhaseBody({ job_id: id })),
        }
      );
      if (data.ok) nmAutorunJobs.add(id);
    } catch (_) {
      /* idempotent côté serveur ; ne pas bloquer le suivi */
    }
  }

  async function ensureNmAutorunForSteps(steps) {
    if (!steps || pipelineMode() === "off") return;
    for (const k of ["vc-relax", "relax", "scf", "nscf"]) {
      const st = steps[k];
      if (st && (st.running || st.run_phase === "running") && st.job_id) {
        await attachNmAutorun(st.job_id);
        return;
      }
    }
  }

  async function applyBalancedNmProfile() {
    if (!requireSessionConfirmed() || !material) return;
    const data = await api(
      `/api/materials/${encodeURIComponent(material)}/apply-balanced-profile`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(withPhaseBody({})),
      }
    );
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    const msg = lang === "en" ? (data.message_en || data.message_fr) : (data.message_fr || data.message_en);
    log("log-opt", msg || data, !!data.ok);
    if (!data.ok && data.error) alert(data.error);
    await refreshOptimStatus();
  }

  async function runNmChainKind(kind, opts = {}) {
    if (PHASES_PREP_ONLY) return;
    if (kind === "nscf") return runNscfOrder("nm");
    return runOptimKind(kind, { fromChain: true, forceServerChain: true, ...opts });
  }

  async function runOptimKind(kind, opts = {}) {
    if (PHASES_PREP_ONLY) return;
    if (!opts.fromChain && !requireSessionConfirmed()) return;
    if (!material) { alert(i18nT("alert.pick_mat")); return; }
    const runBtns = document.querySelectorAll(".btn-optim-run");
    if (!opts.fromChain) runBtns.forEach((b) => { b.disabled = true; });
    const banner = $("status-nm-chain");
    if (banner) {
      banner.textContent = kind === "nscf"
        ? i18nT("phase.nscf.running")
        : i18nT("mag.banner.running", { order: "NM", step: String(kind).toUpperCase() });
      banner.className = "mag-chain-banner running";
    }
    const stopBtn = $("btn-nm-chain-stop");
    if (stopBtn) {
      stopBtn.hidden = false;
      stopBtn.dataset.kind = kind;
    }
    paintLiveOnTrack("track-nm-chain", { running: true, label: "Calcul en cours…", progress: "pw.x", kind });
    log("log-opt", `${kind} — démarrage (${material})…`);
    try {
      await sanitizeMaterialInputs({ silent: true }).catch(() => {});
      const chain = opts.forceServerChain ? "server" : pipelineMode();
      const body = withPhaseBody({ ...nspinBody(), chain });
      if (opts.waitForSlot) body.wait_for_slot = true;
      if (jobId) body.job_id = jobId;
      const data = await api(`/api/materials/${encodeURIComponent(material)}/run/${encodeURIComponent(kind)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (data.job_id) setJob(data.job_id);
      if (opts.forceServerChain && data.job_id) await attachNmAutorun(data.job_id);
      if (data.resynced_input) {
        log("log-opt", i18nT("chain.input.resynced", { path: data.resynced_input }), true);
      }
      if (data.chained_to) {
        log("log-opt", i18nT("chain.server.next", { kind: String(data.chained_to).toUpperCase() }), true);
      }
      if (data.running) {
        log("log-opt", data.message || "Calcul en cours — témoin sur la carte.", true);
        await refreshRuns().catch(() => {});
        startOptimPoll(material, kind, data.job_id);
        return;
      }
      log("log-opt", data, !!data.ok && data.converged !== false);
      if (data.ok && data.converged && data.generated_inputs) {
        if (kind === "vc-relax" && data.generated_inputs.relax) {
          log("log-opt", i18nT("chain.vc_relax.done", { path: data.generated_inputs.relax }), true);
        }
        if (kind === "relax" && data.generated_inputs.scf) {
          log("log-opt", i18nT("chain.relax.done", { path: data.generated_inputs.scf }), true);
        }
      }
      if (data.ok && data.converged && kind === "scf") {
        log("log-opt", i18nT("phase.scf.done"), true);
        await refreshPhaseStability().catch(() => {});
        await refreshMagOrders().catch(() => {});
      }
      if (kind === "relax" && data.ok && data.converged) {
        await refreshMagOrders().catch(() => {});
      }
      await refreshJobs();
      await refreshMaterials();
      await refreshOptimStatus();
      await refreshRuns().catch(() => {});
      if (data.ok && data.converged) {
        await maybeChainAfterKind(kind, true);
      }
    } catch (e) {
      log("log-opt", String(e.message || e), false);
      if (banner) banner.className = "mag-chain-banner warn";
    } finally {
      if (!optimPollTimer) runBtns.forEach((b) => { b.disabled = false; });
    }
  }

  // ------------------------------------------------------------------
  // Suivi des calculs (historique d'un enregistrement par run)
  // ------------------------------------------------------------------
  function fmtDuration(sec) {
    const s = Math.max(0, Math.round(Number(sec) || 0));
    if (s < 60) return `${s} s`;
    const mn = Math.floor(s / 60);
    if (mn < 60) return `${mn} min ${String(s % 60).padStart(2, "0")} s`;
    return `${Math.floor(mn / 60)} h ${String(mn % 60).padStart(2, "0")} min`;
  }

  function runState(run) {
    if (!run) return { cls: "", key: "state.running" };
    if (run.phase === "running") return { cls: "running", key: "state.running" };
    if (run.phase === "interrupted") return { cls: "warn", key: "state.interrupted" };
    if (run.phase === "failed") return { cls: "bad", key: "state.failed" };
    return run.converged
      ? { cls: "ok", key: "state.converged" }
      : { cls: "warn", key: "state.not_converged" };
  }

  function runLabel(run) {
    if (!run || !run.started) return "";
    const once = run.phase === "running" ? "" : " · ";
    let txt = `${run.started}${once}${run.duration_s != null && run.phase !== "running" ? fmtDuration(run.duration_s) : ""}`;
    if (run.summary) txt += ` · ${run.summary}`;
    if (run.error) txt += ` · ${run.error}`;
    return txt;
  }

  function runActionsHtml(kind, mat, includeRescue, level, maxLevel, magOrder) {
    const launchLab = i18nT("chain.launch_step_short", { step: String(kind || "").toUpperCase() });
    let html = `<button class="btn ghost btn-run-again" type="button" data-kind="${escAttr(kind)}" data-mat="${escAttr(mat || "")}" data-mag-order="${escAttr(magOrder || "")}">${esc(launchLab)}</button>`;
    if (includeRescue) {
      const n = Number(level) || 0;
      const mx = Number(maxLevel) || 4;
      const lab = n > 0
        ? i18nT("btn.adjust_conv.again", { n: Math.min(n + 1, mx), max: mx })
        : i18nT("btn.adjust_conv");
      html += `<button class="btn ghost btn-run-rescue" type="button" data-kind="${escAttr(kind)}" data-mag-order="${escAttr(magOrder || "")}">${esc(lab)}</button>`;
    }
    return html;
  }

  function solutionsHtml(step) {
    const sols = (step && step.solutions) || [];
    const last = step && step.last_run;
    if (!sols.length && !last) return "";
    let html = `<div class="optim-solutions">`;
    if (last) {
      const st = runState(last);
      html += `<p class="run-line">${esc(i18nT("runs.last"))} ${esc(i18nT(st.key))} — ${esc(runLabel(last))}</p>`;
    }
    if (sols.length) {
      html += `<strong>${esc(i18nT("runs.solutions"))}</strong>` +
        `<ul class="optim-hints">${sols.map((s) => `<li>${esc(s)}</li>`).join("")}</ul>`;
    }
    return html + runActionsHtml(step.kind, material, !step.converged, step.conv_adjust_level, step.conv_adjust_max) + `</div>`;
  }

  const TRACK_GROUPS = [
    { id: "vc-relax", kinds: ["vc-relax"], labelKey: "runs.kind.vc-relax" },
    { id: "relax", kinds: ["relax"], labelKey: "runs.kind.relax" },
    { id: "scf", kinds: ["scf"], labelKey: "runs.kind.scf" },
    { id: "nscf", kinds: ["nscf"], labelKey: "runs.kind.nscf" },
    { id: "mag", kinds: ["mag"], labelKey: "runs.kind.mag" },
  ];

  function runTrackGroup(run) {
    const mo = String(run.mag_order || run.magnetic_order || "").toLowerCase();
    if (mo === "nm") return "scf";
    if (mo) return "mag";
    const k = String(run.kind || "").toLowerCase();
    if (k.startsWith("mag") || k === "fm" || k === "afm" || k === "ncl") return "mag";
    if (k === "nscf") return "nscf";
    if (k === "relax") return "relax";
    if (k === "vc-relax" || k === "vcrelax") return "vc-relax";
    if (k === "scf") return "scf";
    return k || "scf";
  }

  function runKindBadge(run) {
    const mo = String(run.mag_order || run.magnetic_order || "").toLowerCase();
    const k = String(run.kind || "").toLowerCase();
    const step =
      k === "vc-relax" || k === "vcrelax" ? "VC-RELAX"
      : k === "relax" ? "RELAX"
      : k === "nscf" ? "NSCF"
      : k === "scf" ? "SCF"
      : k ? k.toUpperCase() : "CALC";
    if (mo && mo !== "nm") return `${step} ${mo.toUpperCase()}`;
    return step;
  }

  function runMetricsInline(run) {
    if (!run || run.phase !== "running") return "";
    const bits = [];
    const k = String(run.kind || "").toLowerCase();
    if (run.elapsed_s != null) bits.push(`${i18nT("res.elapsed")} ${fmtDuration(run.elapsed_s)}`);
    appendLiveMetricBits(bits, run, k);
    if (run.progress) bits.unshift(run.progress);
    if (!bits.length) return "";
    let html = `<p class="run-metrics run-metrics-inline">${bits.map(esc).join(" · ")}</p>`;
    if (run.percent != null) {
      html += `<div class="run-meter run-meter-compact"><div class="run-meter-fill" style="width:${Math.min(100, run.percent)}%"></div></div>`;
    }
    return html;
  }

  function runRowHtml(run, opts = {}) {
    const st = runState(run);
    const kind = run.kind || "";
    const compact = !!opts.compact;
    const out = run.out_url
      ? `<a class="run-out" href="${escAttr(safeHref(run.out_url))}" target="_blank" rel="noopener">${esc(i18nT("runs.out"))}</a>`
      : "";
    const diag = [...(run.hints || []), ...(run.solutions || [])];
    const details = !compact && diag.length
      ? `<details class="run-diag"><summary>${esc(i18nT("runs.solutions"))}</summary>` +
        `<ul class="optim-hints">${diag.map((h) => `<li>${esc(h)}</li>`).join("")}</ul></details>`
      : "";
    const badge = runKindBadge(run);
    return `<article class="run-row ${escAttr(st.cls)}${compact ? " compact" : ""}">
      <div class="run-head">
        <span class="run-badge">${esc(badge)}</span>
        ${compact ? "" : `<span class="run-mat">${esc(run.material || "")}</span>`}
        <span class="run-date">${esc(runLabel(run))}</span>
        <span class="run-state ${escAttr(st.cls)}">${esc(i18nT(st.key))}</span>
        ${out}
        ${compact ? "" : `<span class="run-actions">${runActionsHtml(kind, run.material || "", st.cls === "warn" || st.cls === "bad", run.conv_adjust_level, run.conv_adjust_max, run.mag_order || "")}</span>`}
      </div>
      ${runMetricsInline(run)}
      ${details}
    </article>`;
  }

  function groupRunsByKind(runs) {
    const groups = {};
    for (const g of TRACK_GROUPS) groups[g.id] = [];
    for (const run of runs || []) {
      const id = runTrackGroup(run);
      if (!groups[id]) groups[id] = [];
      groups[id].push(run);
    }
    return groups;
  }

  function runTrackElId(run) {
    const mo = String(run.mag_order || run.magnetic_order || "").toLowerCase();
    if (mo && mo !== "nm") return `track-mag-${mo}`;
    const g = runTrackGroup(run);
    if (g === "vc-relax" || g === "relax" || g === "scf" || g === "nscf") return "track-nm-chain";
    return `track-${g}`;
  }

  function ensureTrackParts(el) {
    if (!el) return { live: null, hist: null };
    let live = el.querySelector(".track-live");
    if (!live) {
      live = document.createElement("div");
      live.className = "track-live";
      live.hidden = true;
      el.prepend(live);
    }
    let hist = el.querySelector(".track-history");
    if (!hist) {
      hist = document.createElement("div");
      hist.className = "track-history";
      el.appendChild(hist);
    }
    return { live, hist };
  }

  function paintLiveOnTrack(trackId, live, opts = {}) {
    const el = typeof trackId === "string" ? $(trackId) : trackId;
    if (!el) return;
    const parts = ensureTrackParts(el);
    if (!parts.live) return;
    if (!live) {
      parts.live.hidden = true;
      parts.live.innerHTML = "";
      return;
    }
    const kind = opts.kind || live.kind || "";
    const magOrder = opts.magOrder || "";
    if (live.running) {
      parts.live.hidden = false;
      parts.live.className = "track-live running track-live-panel";
      parts.live.innerHTML = runTrackingPanelHtml(live, kind, { magOrder, showStop: true });
      el.closest(".optim-card, .mag-case-row, .nm-chain-row")?.classList.toggle("is-running", true);
      return;
    }
    const metrics = liveMetricsHtml(live, kind).replace(/^<br\/>/, "");
    const prog = live.progress ? `<span class="run-progress">${esc(live.progress)}</span>` : "";
    const bits = [live.label ? esc(live.label) : "", metrics, prog].filter(Boolean).join(" · ");
    parts.live.hidden = !bits;
    parts.live.className = "track-live " + (live.converged ? "ok" : live.finished ? "warn" : "");
    parts.live.innerHTML = live.converged && !live.running
      ? `<span class="conv-flag">${esc(i18nT("state.converged"))}</span> ${bits}`
      : (bits || "");
    el.closest(".optim-card, .mag-case-row, .nm-chain-row")?.classList.toggle("is-converged", !!live.converged && !live.running);
    el.closest(".optim-card, .mag-case-row, .nm-chain-row")?.classList.toggle("is-running", false);
  }

  function paintCardTracksFromRuns(runs) {
    const byEl = {};
    for (const run of runs || []) {
      const id = runTrackElId(run);
      if (!byEl[id]) byEl[id] = [];
      byEl[id].push(run);
    }
    document.querySelectorAll(".card-track").forEach((el) => {
      const { hist } = ensureTrackParts(el);
      if (!hist) return;
      let items = byEl[el.id] || [];
      const magMo = el.id && el.id.startsWith("track-mag-") ? el.id.slice("track-mag-".length) : "";
      if (magMo) {
        items = items.filter(
          (r) => String(r.mag_order || r.magnetic_order || "").toLowerCase() === magMo
        );
      }
      let kindLabel = el.dataset.kind
        ? i18nT(`runs.kind.${el.dataset.kind}`) || String(el.dataset.kind).toUpperCase()
        : (el.id || "").replace(/^track-/, "").toUpperCase();
      const trackTitle = magMo
        ? i18nT("runs.track.mag_order", { order: magMo.toUpperCase() })
        : i18nT("runs.kind.follow", { kind: kindLabel });
      if (!items.length) {
        hist.innerHTML = `<p class="meta card-track-empty">${i18nT("runs.kind.empty", { kind: kindLabel })}</p>`;
        return;
      }
      hist.innerHTML =
        `<p class="card-track-title">${esc(trackTitle)}</p>` +
        items.slice(0, 6).map((r) => runRowHtml(r, { compact: true })).join("");
      const liveRun = items.find((r) => r && r.phase === "running");
      if (liveRun && !optimPollTimer && !runPollBlocked()) {
        const mo = String(liveRun.mag_order || liveRun.magnetic_order || "").toLowerCase();
        const moUse = mo && mo !== "nm" ? mo : "";
        attachPollIfLiveRunning(
          material,
          liveRun.kind,
          liveRun.job_id || liveRun.job || jobId,
          moUse || undefined,
          liveRun.structure_phase_id || liveRun.phase_id || activePhaseId(),
          el.id
        ).catch(() => {});
      }
    });
  }

  function paintCardTracks(groups) {
    const runs = [];
    Object.values(groups || {}).forEach((list) => {
      (list || []).forEach((r) => runs.push(r));
    });
    paintCardTracksFromRuns(runs);
  }

  function paintRunsEmpty() {
    paintCardTracksFromRuns([]);
  }

  /** Vide le suivi (rechargement page, Confirmer, bouton Rafraîchir du panneau). */
  function resetRunTracking(clearOnly) {
    runTrackingSince = Date.now() / 1000;
    if (clearOnly !== false) paintRunsEmpty();
    refreshRuns().catch(() => {});
  }

  function runInTrackingWindow(run) {
    if (!run) return false;
    const ts = Number(run.started_ts || 0);
    if (!ts || !Number.isFinite(runTrackingSince)) return false;
    return ts >= runTrackingSince - 0.5;
  }

  async function refreshRuns() {
    if (!sessionConfirmed || !material) {
      paintRunsEmpty();
      return;
    }
    // Tableau des jobs (moins souvent : lit tout l'historique du matériau)
    if (Date.now() - jobsBoardTs > 4000) {
      jobsBoardTs = Date.now();
      refreshJobsBoard().catch(() => {});
    }
    const path = `/api/materials/${encodeURIComponent(material)}/runs${phaseQuery("?limit=80")}`;
    const data = await api(path);
    let runs = (data.runs || []).filter(runInTrackingWindow);
    if (!runs.length && (data.runs || []).length) {
      const byKind = {};
      for (const r of data.runs) {
        const key = runTrackElId(r);
        if (r && !byKind[key]) byKind[key] = r;
      }
      runs = Object.values(byKind);
    }
    paintCardTracksFromRuns(runs);
    const liveRun = runs.find((r) => r && r.phase === "running");
    if (liveRun && !optimPollTimer && !runPollBlocked()) {
      try {
        const mo = String(liveRun.mag_order || liveRun.magnetic_order || "").toLowerCase();
        const pid = liveRun.structure_phase_id || getDraftPhase() || "";
        const { live, pollKind } = await fetchRunLive(
          material,
          liveRun.kind || "scf",
          liveRun.job_id || jobId,
          mo && mo !== "nm" ? mo : "",
          pid
        );
        if (!live.running) {
          paintLiveOnTrack(runTrackElId(liveRun), null);
          return;
        }
        paintLiveOnTrack(runTrackElId(liveRun), live, {
          kind: pollKind,
          magOrder: mo && mo !== "nm" ? mo : "",
        });
      } catch (_) {
        /* ignore */
      }
    }
  }

  async function sanitizeMaterialInputs(opts = {}) {
    if (!material) return null;
    const data = await api(
      `/api/materials/${encodeURIComponent(material)}/sanitize-inputs`,
      { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(withPhaseBody()) }
    );
    if (!opts.silent && data.updated && data.updated.length) {
      log("log-opt", { sanitize: data.updated }, true);
    }
    return data;
  }

  async function applyPlanB(kind, opts = {}) {
    if (!material) { alert(i18nT("alert.pick_mat")); return; }
    const body = withPhaseBody({ apply: true });
    if (opts.magOrder) body.mag_order = opts.magOrder;
    if (opts.phaseId) body.phase_id = opts.phaseId;
    const data = await api(
      `/api/materials/${encodeURIComponent(material)}/rescue/${encodeURIComponent(kind)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      }
    );
    log("log-opt", data.message || data, data.ok !== false && data.structure_ok !== false);
    await sanitizeMaterialInputs({ silent: true }).catch(() => {});
    await refreshOptimStatus();
    await refreshMagOrders().catch(() => {});
    await refreshPhaseStability().catch(() => {});
    await refreshRuns();
    if (data.ok !== false && data.applied && kind) {
      if (opts.magOrder) await runMagOrder(opts.magOrder, kind, { waitForSlot: true });
      else await runNmChainKind(kind, { waitForSlot: true });
    }
  }

  function onRunsClick(ev) {
    const target = ev.target && ev.target.closest ? ev.target : null;
    if (!target) return;
    const gotoTr = target.closest(".btn-goto-tracking");
    if (gotoTr && gotoTr.dataset.tab) {
      switchTab(gotoTr.dataset.tab);
      return;
    }
    const trackStop = target.closest(".card-track .btn-run-stop");
    if (trackStop) {
      stopRun(trackStop.dataset.kind, trackStop.dataset.magOrder || "").catch((e) => alert(e.message));
      return;
    }
    const rescue = target.closest(".btn-run-rescue");
    if (rescue) {
      applyPlanB(rescue.dataset.kind, { magOrder: rescue.dataset.magOrder || "" }).catch((e) => alert(e.message));
      return;
    }
    const again = target.closest(".btn-run-again");
    if (again) {
      const mat = again.dataset.mat;
      const kind = again.dataset.kind;
      const mo = again.dataset.magOrder || "";
      const launch = () => (mo ? runMagOrder(mo, kind) : runNmChainKind(kind));
      if (mat) {
        activateMaterialJob(mat, "")
          .then(() => launch())
          .catch((e) => alert(e.message));
      } else {
        launch().catch(() => {});
      }
    }
  }

  function onChainFixClick(ev) {
    const t = ev.target && ev.target.closest ? ev.target : null;
    if (!t) return;
    const edit = t.closest(".btn-chain-fix-edit");
    if (edit) {
      const order = edit.dataset.order || "";
      const kind = edit.dataset.kind || "scf";
      if (order) openMagEditor(order, kind).catch((e) => alert(e.message));
      else openOptimEditor(kind).catch((e) => alert(e.message));
      return;
    }
    const rescue = t.closest(".btn-chain-fix-rescue");
    if (rescue) {
      applyPlanB(rescue.dataset.kind || "scf", {
        magOrder: rescue.dataset.order || "",
        phaseId: rescue.dataset.phase || "",
      }).catch((e) => alert(e.message));
      return;
    }
    const bal = t.closest(".btn-chain-fix-balanced");
    if (bal) {
      applyBalancedNmProfile().catch((e) => alert(e.message));
    }
  }

  // ------------------------------------------------------------------
  // Onglets : Optimisation / Magnétisme / Phases / Résultats
  // ------------------------------------------------------------------
  function normalizeTab(tab) {
    if (tab === "calculs") return "optimisation";
    if (tab === "elastique") return "proprietes";
    const known = ["optimisation", "phases", "magnetisme", "proprietes", "resultats"];
    return known.includes(tab) ? tab : "optimisation";
  }

  function sessionResultsTabVisible() {
    if (!PHASES_ONLY) {
      const page = document.getElementById("page-resultats");
      return !!(page && page.classList.contains("active"));
    }
    const panel = $("session-panel-resultats");
    return !!(panel && !panel.hidden);
  }

  function switchSessionWorkTab(tab) {
    if (!PHASES_ONLY) return;
    const t = normalizeSessionWorkTab(tab);
    const panelsRoot = document.querySelector(".session-work-panels");
    if (panelsRoot) panelsRoot.hidden = false;
    const tabsBar = $("session-work-tabs");
    if (tabsBar) {
      tabsBar.hidden = false;
      tabsBar.style.display = "flex";
    }
    const home = $("session-panel-accueil");
    const prep = $("session-panel-preparation");
    const calcMain = $("session-panel-calcul");
    const res = $("session-panel-resultats");
    const btnHome = $("tab-session-accueil");
    const btnPrep = $("tab-session-preparation");
    const btnCalc = $("tab-session-calcul");
    const btnR = $("tab-session-resultats");
    if (!prep || !res) return;
    const onHome = t === "accueil";
    const onPrep = t === "preparation";
    const onCalc = t === "calcul" && !PHASES_PREP_ONLY;
    const onRes = t === "resultats";
    if (home) {
      home.classList.toggle("active", onHome);
      home.hidden = !onHome;
    }
    prep.classList.toggle("active", onPrep);
    prep.hidden = !onPrep;
    if (calcMain) {
      calcMain.classList.toggle("active", onCalc);
      calcMain.hidden = PHASES_PREP_ONLY ? true : !onCalc;
    }
    res.classList.toggle("active", onRes);
    res.hidden = !onRes;
    if (btnHome) {
      btnHome.classList.toggle("active", onHome);
      btnHome.setAttribute("aria-selected", onHome ? "true" : "false");
    }
    if (btnPrep) {
      btnPrep.classList.toggle("active", onPrep);
      btnPrep.setAttribute("aria-selected", onPrep ? "true" : "false");
    }
    if (btnCalc) {
      if (PHASES_PREP_ONLY) {
        btnCalc.hidden = true;
        btnCalc.classList.remove("active");
        btnCalc.setAttribute("aria-selected", "false");
      } else {
        btnCalc.classList.toggle("active", onCalc);
        btnCalc.setAttribute("aria-selected", onCalc ? "true" : "false");
      }
    }
    if (btnR) {
      btnR.classList.toggle("active", onRes);
      btnR.setAttribute("aria-selected", onRes ? "true" : "false");
    }
    const pageRes = document.getElementById("page-resultats");
    const pageHome = document.getElementById("page-accueil");
    document.querySelectorAll(".session-work-panels .optim-page").forEach((p) => {
      p.classList.remove("active");
    });
    if (onHome && pageHome) pageHome.classList.add("active");
    if (onRes && pageRes) pageRes.classList.add("active");
    else if (onPrep) {
      const onDopedPrep = sessionPrepSubTab === "prep-doped";
      document.getElementById("page-prep-nondope")?.classList.toggle("active", !onDopedPrep);
      document.getElementById("page-prep-doped")?.classList.toggle("active", onDopedPrep);
    }
    paintPrepToneChrome();
    if (onHome) {
      stopResultsAutoRefresh();
    } else if (onRes) {
      onTabShownReschedule();
      paintResultsBrowseChrome();
      refreshResults().catch(() => {});
    } else if (onPrep) {
      stopResultsAutoRefresh();
      syncPhaseDopingMaterials();
      refreshDopingHostElements().catch(() => {});
      paintPhaseStudyMode();
      refreshStudyGuide().catch(() => {});
      switchSessionSubTab("preparation", sessionPrepSubTab);
      if (sessionConfirmed && material) {
        refreshRuns().catch(() => {});
        if (!runsAutoTimer) startRunsAutoRefresh();
      }
    } else if (onCalc) {
      stopResultsAutoRefresh();
      const intent = sessionStudyIntent();
      sessionCalcSubTab = resolveSessionCalcSubTab(intent);
      switchSessionSubTab("calcul", sessionCalcSubTab);
      if (sessionConfirmed && material) {
        refreshOptimStatus().catch(() => {});
        refreshRuns().catch(() => {});
        if (!runsAutoTimer) startRunsAutoRefresh();
      }
    }
    try {
      localStorage.setItem("optimqe.sessionWorkTab", t);
    } catch (_) {}
  }

  function initSessionWorkTabs() {
    if (!PHASES_ONLY || !$("tab-session-preparation")) return;
    paintPhasesPrepOnlyChrome();
    let saved = "preparation";
    try {
      saved = normalizeSessionWorkTab(localStorage.getItem("optimqe.sessionWorkTab") || "preparation");
      sessionPrepSubTab = localStorage.getItem("optimqe.sessionSubTab.preparation") || "prep-nondope";
      sessionCalcSubTab = localStorage.getItem("optimqe.sessionSubTab.calcul") || "calc-nondope";
    } catch (_) {}
    if (!sessionConfirmed && saved !== "preparation" && saved !== "accueil") saved = "preparation";
    if (!["prep-nondope", "prep-doped"].includes(sessionPrepSubTab)) sessionPrepSubTab = "prep-nondope";
    if (!["calc-nondope", "calc-doped"].includes(sessionCalcSubTab)) {
      sessionCalcSubTab = "calc-nondope";
    }
    sessionCalcSubTab = resolveSessionCalcSubTab(sessionStudyIntent());
    document.querySelectorAll("[data-session-tab]").forEach((btn) => {
      btn.addEventListener("click", () => {
        switchSessionWorkTab(btn.dataset.sessionTab || "preparation");
      });
    });
    bind("btn-accueil-goto-prep", "click", () => switchSessionWorkTab("preparation"));
    document.querySelectorAll("[data-goto-accueil]").forEach((a) => {
      a.addEventListener("click", (ev) => {
        ev.preventDefault();
        switchSessionWorkTab("accueil");
      });
    });
    document.querySelectorAll("[data-session-subtab]").forEach((btn) => {
      btn.addEventListener("click", () => {
        switchSessionSubTab(btn.dataset.sessionSubtabGroup || "preparation", btn.dataset.sessionSubtab);
      });
    });
    try {
      resultsBrowseMat = localStorage.getItem("optimqe.resultsBrowseMat") || "";
      resultsBrowseKind = localStorage.getItem("optimqe.resultsBrowseKind") || "";
      resultsSubTab = localStorage.getItem("optimqe.resultsSubTab") || "res-nondope";
    } catch (_) {}
    if (!["nondope", "doped", ""].includes(resultsBrowseKind)) resultsBrowseKind = "";
    if (!["res-nondope", "res-doped"].includes(resultsSubTab)) resultsSubTab = "res-nondope";
    if (resultsBrowseKind === "doped") resultsSubTab = "res-doped";
    else if (resultsBrowseKind === "nondope") resultsSubTab = "res-nondope";
    const resInpInit = $("results-mat-select");
    if (resInpInit && resultsBrowseMat) resInpInit.value = resultsBrowseMat;
    document.querySelectorAll("[data-results-subtab]").forEach((btn) => {
      btn.addEventListener("click", () => switchResultsSubTab(btn.dataset.resultsSubtab));
    });
    paintResultsBrowseChrome();
    paintPhaseStabilityHost();
    paintCalcSubTabChrome();
    relocateSessionMatBlock(sessionPrepSubTab);
    relocateSessionStructurePanel(sessionPrepSubTab);
    paintPrepMatSubpanel(sessionPrepSubTab);
    switchSessionWorkTab(saved);
    paintStructurePanelVisibility();
    const tabsBar = $("session-work-tabs");
    if (tabsBar) {
      tabsBar.hidden = false;
      tabsBar.style.display = "flex";
    }
  }

  function switchTab(tab, opts = {}) {
    tab = normalizeTab(tab);
    if (!PHASES_ONLY && tab === "phases") {
      goPhasesApp();
      return;
    }
    if (PHASES_ONLY) {
      if (tab === "resultats") {
        switchSessionWorkTab("resultats");
        return;
      }
      if (tab !== "phases") {
        goMainApp(tab);
        return;
      }
      switchSessionWorkTab("preparation");
      if (!opts.silent) loadTabData("phases");
      localStorage.setItem("optimqe.tab", "phases");
      return;
    }
    document.querySelectorAll(".optim-tab").forEach((b) => {
      const on = b.dataset.tab === tab;
      b.classList.toggle("active", on);
      b.setAttribute("aria-selected", on ? "true" : "false");
    });
    document.querySelectorAll(".optim-page").forEach((p) => {
      p.classList.toggle("active", p.id === "page-" + tab);
    });
    localStorage.setItem("optimqe.tab", tab);
    if (opts.silent) return;
    loadTabData(tab);
  }

  function loadTabData(tab) {
    tab = normalizeTab(tab);
    if (tab === "resultats") {
      onTabShownReschedule();
      refreshStudyGuide().catch(() => {});
      refreshResults().catch(() => {});
    } else if (tab === "magnetisme") {
      stopResultsAutoRefresh();
      lastMagCasePaintKey = "";
      refreshMagOrders({ autoPrepare: false, skipExtras: true, forceCaseRepaint: true }).catch(() => {});
    } else if (tab === "phases") {
      stopResultsAutoRefresh();
      refreshPhaseStability().catch(() => {});
      refreshStudyGuide().catch(() => {});
    } else if (tab === "proprietes") {
      stopResultsAutoRefresh();
      refreshProprietesPage().catch(() => {});
    } else {
      stopResultsAutoRefresh();
      refreshOptimStatus().catch(() => {});
    }
  }

  function clearTabDomCache(tab) {
    const page = $(`page-${tab}`);
    if (!page) return;
    page.querySelectorAll(".card-track .track-live").forEach((el) => {
      el.hidden = true;
      el.textContent = "";
      el.className = "track-live";
    });
    page.querySelectorAll(".card-track .track-history").forEach((el) => {
      el.innerHTML = `<p class="meta">${i18nT("btn.purge_refresh.cleared")}</p>`;
    });
    page.querySelectorAll(".optim-status").forEach((el) => {
      el.textContent = "—";
      el.className = "optim-status";
    });
  }

  function clearBrowserCaches() {
    materialsCache = [];
    materialTypesCache = null;
    materialFamiliesCache = null;
    lastStudy = null;
    lastStructure = null;
    lastMaterialType = null;
    apiCacheBust = Date.now();
    try {
      const drop = [];
      for (let i = 0; i < sessionStorage.length; i++) {
        const k = sessionStorage.key(i);
        if (k && (k.startsWith("optimqe.cache.") || k.startsWith("optimqe.tmp."))) {
          drop.push(k);
        }
      }
      drop.forEach((k) => sessionStorage.removeItem(k));
    } catch (_) { /* ignore */ }
  }

  async function purgeAndRefreshTab(tab) {
    tab = normalizeTab(tab || localStorage.getItem("optimqe.tab") || "optimisation");
    clearBrowserCaches();
    clearTabDomCache(tab);
    resetRunTracking(true);
    log("log-opt", i18nT("btn.purge_refresh.done", { tab: i18nT(`tab.${tab}`) || tab }), true);
    if (!sessionConfirmed || !material) {
      await refreshPhasesForDraft().catch(() => {});
      await refreshPhaseTypePanel().catch(() => {});
      return;
    }
    await refreshPhasesForDraft().catch(() => {});
    await refreshStudyGuide().catch(() => {});
    if (tab === "optimisation") {
      await refreshOptimStatus().catch(() => {});
      await refreshRuns().catch(() => {});
    } else if (tab === "phases") {
      await refreshPhaseTypePanel().catch(() => {});
      await refreshPhaseStability().catch(() => {});
    } else if (tab === "magnetisme") {
      lastMagCasePaintKey = "";
      await refreshMagOrders().catch(() => {});
    } else if (tab === "proprietes") {
      await refreshProprietesPage().catch(() => {});
    } else if (tab === "resultats") {
      await refreshResults().catch(() => {});
      await refreshMagOrders().catch(() => {});
    }
  }

  function fmtNum(v, digits) {
    if (v == null || !isFinite(Number(v))) return "—";
    return Number(v).toFixed(digits == null ? 6 : digits);
  }

  function fmtCelldm(cd) {
    if (!cd) return "";
    const parts = [];
    for (const k of [1, 2, 3, 4, 5, 6]) {
      if (cd[k] != null) parts.push(`celldm(${k}) = ${Number(cd[k]).toFixed(5)}`);
    }
    return parts.join(" · ");
  }

  function kindLabel(kind) {
    return (kind || "").toUpperCase();
  }

  // ------------------------------------------------------------------
  // Résultats (vc-relax / relax / scf + input SCF suggéré)
  // ------------------------------------------------------------------
  let lastScfSuggestion = null;
  let scfMode = localStorage.getItem("optimqe.scfmode") || "auto";

  function currentScfContent() {
    if (!lastScfSuggestion) return "";
    if (scfMode === "zero") return lastScfSuggestion.content_zero || lastScfSuggestion.content || "";
    return lastScfSuggestion.content_auto || lastScfSuggestion.content || "";
  }

  function paramItem(label, value, unit, cls) {
    return `<div class="param-item ${cls || ""}">
      <span class="plabel">${label}</span>
      <span class="pvalue">${value}${unit ? ` <span class="unit">${unit}</span>` : ""}</span>
    </div>`;
  }

  function cellTable(cell) {
    if (!cell || cell.length !== 3) return "";
    const rows = cell.map((v) => `<td>${fmtNum(v[0])}</td><td>${fmtNum(v[1])}</td><td>${fmtNum(v[2])}</td>`).join("</tr><tr>");
    return `<div class="table-scroll"><table class="results-table cell-table">
      <thead><tr><th>a₁ (Å)</th><th>a₂ (Å)</th><th>a₃ (Å)</th></tr></thead>
      <tbody><tr>${rows}</tr></tbody>
    </table></div>`;
  }

  function positionsTable(positions) {
    if (!positions || !positions.length) return "";
    const rows = positions
      .map((p) => `<tr><td>${esc(p.symbol)}</td><td>${fmtNum(p.x)}</td><td>${fmtNum(p.y)}</td><td>${fmtNum(p.z)}</td></tr>`)
      .join("");
    return `<div class="table-scroll"><table class="results-table pos-table">
      <thead><tr><th>atome</th><th>x</th><th>y</th><th>z</th></tr></thead>
      <tbody>${rows}</tbody>
    </table></div>`;
  }

  function resolvedNspin(st) {
    if (st && st.nspin != null) return Number(st.nspin);
    return parseNspinChoice(nspinChoice);
  }

  function magneticStatusLabel(st) {
    const key = st && st.magnetic_property_en;
    if (key && i18nT("mag." + key) !== "mag." + key) return i18nT("mag." + key);
    if (st && st.magnetic_property) return st.magnetic_property;
    return resolvedNspin(st) === 2 ? i18nT("mag.pending_polarized") : i18nT("mag.unpolarized_run");
  }

  function scfElectronicBlock(st) {
    if (!st || !st.output_exists || st.running || st.stopped) return "";
    const rows = [];
    rows.push(paramItem("E<sub>Fermi</sub>", st.fermi_ev != null ? fmtNum(st.fermi_ev, 4) : "—", "eV"));
    rows.push(
      paramItem(
        "N(E<sub>F</sub>)",
        st.dos_at_ef != null ? fmtNum(st.dos_at_ef, 4) : "—",
        st.dos_at_ef != null ? "states/eV/cell" : ""
      )
    );
    let etypeKey = st.electronic_type_en;
    if (!etypeKey && st.dos_at_ef != null) {
      etypeKey = st.dos_at_ef > 0.02 ? "metal" : "insulator";
    }
    if (etypeKey) {
      rows.push(paramItem(i18nT("res.electronic"), i18nT("electronic." + etypeKey), "", "ok"));
    }
    if (st.gap_ev != null) {
      const g = fmtGapEv(st);
      rows.push(paramItem(i18nT("res.gap"), g === "—" ? fmtNum(st.gap_ev, 3) : g, "eV", Number(g) > 0 ? "ok" : ""));
    }
    return (
      `<h5 class="result-sub">${i18nT("res.electronic.block")}</h5>` +
      `<div class="param-grid scf-electronic-grid">${rows.join("")}</div>`
    );
  }

  /** Schéma SVG 2D de la maille (projection xy) avec images périodiques. */
  function cellSketchSvg(sk) {
    if (!sk || !sk.a1 || !sk.a2 || !sk.positions || !sk.positions.length) return "";
    const [a1x, a1y] = sk.a1;
    const [a2x, a2y] = sk.a2;
    const W = 240, H = 200, PAD = 44;
    const len = (v) => Math.hypot(v[0], v[1]);
    const L1 = Math.max(len(sk.a1), 1e-6);
    const L2 = Math.max(len(sk.a2), 1e-6);
    const scale = Math.min((W - 2 * PAD) / (Math.abs(a1x) + Math.abs(a2x) || 1),
                           (H - 2 * PAD) / (Math.abs(a1y) + Math.abs(a2y) || 1));
    const ox = PAD + (W - 2 * PAD - scale * (Math.abs(a1x) + Math.abs(a2x))) / 2 + scale * Math.abs(Math.min(a2x, 0));
    const oy = PAD + (H - 2 * PAD - scale * (Math.abs(a1y) + Math.abs(a2y))) / 2 + scale * Math.abs(Math.min(a2y, 0));
    const px = (fx, fy) => [ox + scale * (fx * a1x + fy * a2x), oy + scale * (fx * a1y + fy * a2y)];
    const O = px(0, 0), A = px(1, 0), B = px(0, 1), AB = px(1, 1);
    const fmt = (v) => (Math.abs(v) >= 10 ? v.toFixed(2) : v.toFixed(3));
    let svg = `<svg viewBox="0 0 ${W} ${H}" class="cell-sketch" role="img" aria-label="Schéma de la maille (projection xy)">`;
    // images périodiques des atomes (voisinage) puis maille puis atomes
    const imgs = [];
    for (const p of sk.positions) {
      for (let i = -1; i <= 1; i++) {
        for (let j = -1; j <= 1; j++) {
          const [x, y] = px(p.fx + i, p.fy + j);
          if (x > 2 && x < W - 2 && y > 2 && y < H - 2) {
            imgs.push(`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="7" class="sk-atom"/>`);
          }
        }
      }
    }
    svg += imgs.join("");
    svg += `<path d="M ${O} L ${A} L ${AB} L ${B} Z" class="sk-cell"/>`;
    svg += `<line x1="${O[0]}" y1="${O[1]}" x2="${A[0]}" y2="${A[1]}" class="sk-vec"/>`;
    svg += `<line x1="${O[0]}" y1="${O[1]}" x2="${B[0]}" y2="${B[1]}" class="sk-vec"/>`;
    svg += `<text x="${(O[0] + A[0]) / 2}" y="${(O[1] + A[1]) / 2 - 5}" class="sk-lab">a₁ ${fmt(L1)} Å</text>`;
    svg += `<text x="${(O[0] + B[0]) / 2 - 8}" y="${(O[1] + B[1]) / 2}" class="sk-lab" text-anchor="end">a₂ ${fmt(L2)} Å</text>`;
    svg += `<text x="${O[0] - 6}" y="${O[1] + 14}" class="sk-lab" text-anchor="start">O</text>`;
    svg += `<text x="${W - 6}" y="${H - 6}" class="sk-lab sk-xy" text-anchor="end">plan xy</text>`;
    svg += "</svg>";
    return svg;
  }

  /** Bloc magnétisme : toujours visible sur la carte SCF (nspin = 1 ou 2, tous matériaux). */
  function scfMagneticBlock(st) {
    const ns = resolvedNspin(st || {});
    const hasOut = st && st.output_exists && !st.running && !st.stopped;
    const rows = [];
    rows.push(paramItem("nspin", String(ns), ns === 4 ? "noncolin" : "", ns >= 2 ? "ok" : ""));
    rows.push(
      paramItem(
        i18nT("res.magnetic.status"),
        magneticStatusLabel(st || {}),
        "",
        hasOut && ns >= 2 && st.magnetic_property_en && st.magnetic_property_en !== "unpolarized_run" ? "ok" : ""
      )
    );
    if (hasOut) {
      const mTot = st.tot_magnetization != null ? fmtNum(st.tot_magnetization, 4) : "—";
      rows.push(paramItem("M<sub>tot</sub>", mTot, "µ<sub>B</sub>"));
      if (st.absolute_magnetization != null) {
        rows.push(paramItem("M<sub>abs</sub>", fmtNum(st.absolute_magnetization, 4), "µ<sub>B</sub>"));
      }
    } else {
      rows.push(paramItem("M<sub>tot</sub>", "—", "µ<sub>B</sub>"));
    }
    let note = "";
    if (ns === 1) {
      note = `<p class="meta mag-note">${esc(st && st.magnetic_note ? st.magnetic_note : i18nT("res.mag.note"))}</p>`;
    } else if (hasOut && st.magnetic_note) {
      note = `<p class="meta mag-note">${esc(st.magnetic_note)}</p>`;
    } else if (ns >= 2 && !hasOut) {
      note = `<p class="meta mag-note">${i18nT("res.mag.polarized.wait")}</p>`;
    }
    let siteTable = "";
    if (hasOut && ns >= 2 && st.site_moments && st.site_moments.length) {
      const rowsT = st.site_moments
        .map((m) => {
          const val = m.z != null ? m.z : m.x != null ? m.x : null;
          const comp = m.z != null ? "M<sub>z</sub>" : "M<sub>x</sub>";
          return `<tr><td>${esc(String(m.index))}</td><td>${val != null ? fmtNum(val, 4) : "—"}</td><td>${comp}</td></tr>`;
        })
        .join("");
      siteTable =
        `<h5 class="result-sub">${i18nT("res.site.moments")} <span class="unit-note">(µ<sub>B</sub>)</span></h5>` +
        `<div class="table-scroll"><table class="results-table mag-table">
          <thead><tr><th>#</th><th>${i18nT("res.site.moment")}</th><th>${i18nT("res.site.comp")}</th></tr></thead>
          <tbody>${rowsT}</tbody>
        </table></div>`;
    }
    // Base de données de référence magnétique (littérature expérimentale)
    let refHtml = "";
    const ref = st && st.magnetic_reference;
    if (hasOut && ref) {
      const fr = qeI18n.getLang() === "fr";
      const chiVal = ref.chi_molar_cgs_e6;
      const chiTxt = chiVal != null
        ? `${chiVal > 0 ? "+" : ""}${fmtNum(chiVal, 1)} × 10<sup>−6</sup> emu·mol<sup>−1</sup>`
        : "—";
      const cls = ref.classification_en
        ? (i18nT("mag." + ref.classification_en) !== "mag." + ref.classification_en
            ? i18nT("mag." + ref.classification_en)
            : ref.classification_en)
        : "—";
      const agree = ref.classification_en && st.magnetic_property_en
        ? ref.classification_en === st.magnetic_property_en
        : null;
      // Comparaison χ_Pauli estimée (N(EF) du calcul) ↔ χ expérimentale
      let chiCmp = "";
      const cmp = st.chi_pauli_vs_exp;
      if (cmp && cmp.estimated != null && cmp.experimental != null) {
        const ratio = cmp.ratio_est_over_exp;
        const ratioTxt = ratio != null
          ? (ratio >= 1 ? `≈ ${fmtNum(ratio, 2)} × χ<sub>exp</sub>` : `≈ ${fmtNum(ratio * 100, 0)} % de χ<sub>exp</sub>`)
          : "";
        chiCmp =
          paramItem("χ<sub>Pauli</sub> (calc., N(E<sub>F</sub>))",
            `+${fmtNum(cmp.estimated, 1)} × 10<sup>−6</sup> emu·mol<sup>−1</sup>`, "") +
          paramItem(i18nT("res.magref.chi_compare"), ratioTxt, "",
            ratio != null && ratio >= 0.5 && ratio <= 2 ? "ok" : "");
      }
      refHtml =
        `<h5 class="result-sub">${i18nT("res.magref.title")}</h5>` +
        `<div class="param-grid scf-magref-grid">` +
        paramItem(i18nT("res.magref.classification"), cls, "", agree ? "ok" : "") +
        paramItem("χ (molaire, exp.)", chiTxt, "") +
        chiCmp +
        `</div>` +
        (cmp && cmp.estimated != null
          ? `<p class="meta mag-note">${esc(i18nT("res.magref.chi_note"))}</p>`
          : "") +
        `<p class="meta mag-note">${esc(fr ? (ref.note_fr || "") : (ref.note_en || ""))}</p>`;
    }
    return (
      `<article class="result-magnetic-box" aria-label="${i18nT("res.magnetic.block")}">
        <h5 class="result-sub">${i18nT("res.magnetic.block")}</h5>
        <div class="param-grid scf-magnetic-grid">${rows.join("")}</div>
        ${note}${siteTable}${refHtml}
      </article>`
    );
  }

  function resultBodyHtml(st, kind) {
    const fullElectronic = kind === "scf";
    if (kind === "scf" && (!st || !st.output_exists)) {
      return (
        `<p class="meta">${i18nT("res.empty.scf")}</p>` +
        scfMagneticBlock(st || { nspin: resolvedNspin(null) })
      );
    }
    if (!st || !st.output_exists) {
      return `<p class="meta">${i18nT("res.empty")}</p>`;
    }
    if (st.running) {
      return resultsRunningDeferHtml(kind);
    }
    // Arrêté par l'utilisateur
    if (st.stopped) {
      return `<div class="result-pills"><span class="pill bad">${i18nT("state.stopped")}</span></div>` +
        `<p class="meta">${i18nT("res.stopped.hint")}</p>`;
    }
    const state = st.converged
      ? `<span class="pill ok">${i18nT("state.converged")}</span>`
      : `<span class="pill bad">${i18nT("state.not_converged")}</span>`;
    let html = `<div class="result-pills">${state}`;
    if (st.output_path) {
      const href = safeHref(String(st.output_path).startsWith("/") ? st.output_path : `/${st.output_path}`);
      html += ` <a class="run-out" href="${escAttr(href)}" target="_blank" rel="noopener">${esc(i18nT("runs.out"))}</a>`;
    }
    html += `</div>`;
    if (fullElectronic) {
      html += scfElectronicBlock(st);
      html += scfMagneticBlock(st);
    } else if (st.dos_at_ef != null || st.fermi_ev != null) {
      html += `<p class="meta">${i18nT("res.electronic.hint_scf")}</p>`;
    }
    const items = [];
    if (st.total_energy_ry != null) {
      items.push(paramItem("E total", fmtNum(st.total_energy_ry, 6), "Ry", "ok"));
      items.push(paramItem("E total", fmtNum(st.total_energy_ev, 3), "eV"));
    }
    if (st.final_enthalpy_ry != null) {
      items.push(paramItem("H finale", fmtNum(st.final_enthalpy_ry, 6), "Ry", "ok"));
    }
    if (fullElectronic && st.nelec != null) items.push(paramItem("N<sub>elec</sub>", fmtNum(st.nelec, 2), ""));
    if (fullElectronic && st.nbnd != null) items.push(paramItem("nbnd", String(st.nbnd), ""));
    if (fullElectronic && st.magnetization_vector && st.magnetization_vector.length === 3) {
      const v = st.magnetization_vector.map((x) => fmtNum(x, 4)).join(", ");
      items.push(paramItem("M (x,y,z)", v, "µ<sub>B</sub>"));
    }
    if (st.pressure_kbar != null) items.push(paramItem("P", fmtNum(st.pressure_kbar, 2), "kbar"));
    if (st.alat_angstrom != null) items.push(paramItem("alat", fmtNum(st.alat_angstrom, 5), "Å"));
    if (st.volume_ang3 != null) items.push(paramItem("Volume", fmtNum(st.volume_ang3, 5), "Å³"));
    if (st.density_g_cm3 != null) items.push(paramItem("Densité", fmtNum(st.density_g_cm3, 5), "g/cm³"));
    if (st.scf_iterations != null) items.push(paramItem("Itérations SCF", String(st.scf_iterations), ""));
    if (st.bravais && st.bravais.ibrav != null) {
      const sl = structureLabel() || st.bravais.label || "";
      items.push(paramItem("Structure", sl || `ibrav = ${st.bravais.ibrav}`, "", "ok"));
      items.push(paramItem("ibrav", String(st.bravais.ibrav), "", "ok"));
      const cd = fmtCelldm(st.bravais.celldm);
      if (cd) items.push(paramItem("Paramètres de maille", cd, "bohr"));
    } else if (structureLabel()) {
      items.push(paramItem("Structure", structureLabel(), "", "ok"));
    }
    if (items.length) html += `<div class="param-grid">${items.join("")}</div>`;
    return html;
  }

  function paintResultsFiles(bundle) {
    const el = $("res-files-body");
    if (!el) return;
    const data = bundle || {};
    const inputs = data.scf_inputs || [];
    const relax = data.relax_files || [];
    const structs = data.structures || [];
    if (!inputs.length && !relax.length && !structs.length) {
      el.innerHTML = `<p class="meta">${esc(i18nT("res.files.empty"))}</p>`;
      return;
    }
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    const note = lang === "en" ? (data.note_en || data.note_fr) : (data.note_fr || data.note_en);
    let html = note ? `<p class="meta">${esc(note)}</p>` : "";
    if (inputs.length) {
      const rows = inputs.map((f) =>
        `<tr><td>${esc(f.label || f.order || "")}</td>` +
        `<td><code>${esc(f.path || f.name || "")}</code></td>` +
        `<td><a class="run-out" href="${escAttr(f.url || "#")}" download>${esc(i18nT("res.files.download_in"))}</a></td></tr>`
      ).join("");
      html += `<h5 class="result-sub">${esc(i18nT("res.files.scf"))}</h5>` +
        `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table"><thead>` +
        `<tr><th>${esc(i18nT("res.lattice.col.order"))}</th><th>Fichier</th><th></th></tr>` +
        `</thead><tbody>${rows}</tbody></table></div>`;
    }
    if (relax.length) {
      const rows = relax.map((f) => {
        const inp = f.input_url
          ? `<a class="run-out" href="${escAttr(f.input_url)}" download>${esc(f.input_name || "relax.in")}</a>`
          : "—";
        const out = f.output_url
          ? `<a class="run-out" href="${escAttr(f.output_url)}" target="_blank" rel="noopener">${esc(i18nT("runs.out"))}</a>`
          : "—";
        return `<tr><td>${esc(f.label || f.order || "")}</td><td>${f.converged ? "✓" : "—"}</td><td>${inp}</td><td>${out}</td></tr>`;
      }).join("");
      html += `<h5 class="result-sub">${esc(i18nT("res.files.relax"))}</h5>` +
        `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table"><thead>` +
        `<tr><th>${esc(i18nT("res.lattice.col.order"))}</th><th>RELAX</th><th>Input</th><th>.out</th></tr>` +
        `</thead><tbody>${rows}</tbody></table></div>`;
    }
    if (structs.length) {
      const rows = structs.map((f) =>
        `<tr><td>${esc(f.label || f.order || "")}</td><td>${esc(String(f.kind || "").toUpperCase())}</td>` +
        `<td><a class="run-out" href="${escAttr(f.xsf_url || "#")}" download>${esc(f.xsf_name || "structure.xsf")}</a></td>` +
        `<td><a class="run-out" href="${escAttr(f.cif_url || "#")}" download>${esc(f.cif_name || "structure.cif")}</a></td></tr>`
      ).join("");
      html += `<h5 class="result-sub">${esc(i18nT("res.files.struct"))}</h5>` +
        `<p class="meta">${esc(i18nT("res.files.xcrysden"))}</p>` +
        `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table"><thead>` +
        `<tr><th>${esc(i18nT("res.lattice.col.order"))}</th><th>${esc(i18nT("res.files.step"))}</th>` +
        `<th>XCrySDen (.xsf)</th><th>VESTA (.cif)</th></tr>` +
        `</thead><tbody>${rows}</tbody></table></div>`;
    }
    el.innerHTML = html;
  }

  function nmStepFlag(st) {
    if (!st) return { icon: "—", cls: "idle", lab: "—" };
    if (st.running) return { icon: "…", cls: "run", lab: i18nT("state.running") };
    if (st.converged) return { icon: "✓", cls: "ok", lab: i18nT("state.converged") };
    if (st.stopped) return { icon: "✗", cls: "fail", lab: i18nT("state.stopped") };
    if (st.output_exists) return { icon: "◐", cls: "partial", lab: i18nT("state.not_converged") };
    if (st.input_exists) return { icon: "○", cls: "ready", lab: i18nT("mag.case.ready") };
    return { icon: "—", cls: "idle", lab: "—" };
  }

  function fmtLatticeNum(v, d) {
    if (v == null || Number.isNaN(Number(v))) return "—";
    return fmtNum(v, d == null ? 4 : d);
  }

  function paintLatticeMechanicsTable(block) {
    const el = $("res-lattice-body");
    const card = $("res-lattice-card");
    if (!el) return;
    const data = block || {};
    const rows = data.rows || [];
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    if (card) card.hidden = !material;
    if (!rows.length) {
      const msg =
        data.message_fr && lang === "en"
          ? data.message_en || data.message_fr
          : data.message_fr || data.message_en || i18nT("res.lattice.empty");
      el.innerHTML = `<p class="meta">${esc(msg || i18nT("res.lattice.empty"))}</p>`;
      return;
    }
    const bulkSrc = (src) => {
      if (src === "elastic") return i18nT("res.lattice.bulk.elastic");
      if (src === "estimate") return i18nT("res.lattice.bulk.estimate");
      return "—";
    };
    const latticeCell = (r) => {
      if (r.lattice_text) return r.lattice_text;
      const abc = [r.a_ang, r.b_ang, r.c_ang].map((x) => fmtLatticeNum(x, 4)).join(" · ");
      const ang = [r.alpha_deg, r.beta_deg, r.gamma_deg].map((x) => fmtLatticeNum(x, 1)).join(" · ");
      const stLab = r.structure_label || (r.ibrav != null ? `ibrav ${r.ibrav}` : "");
      return [stLab, abc ? `a,b,c = ${abc} Å` : "", ang ? `αβγ = ${ang}°` : ""].filter(Boolean).join(" · ") || "—";
    };
    const head = `<tr><th>${esc(i18nT("res.lattice.col.order"))}</th>` +
      `<th><span class="res-col-num">①</span> ${esc(i18nT("res.lattice.col.lattice"))}</th>` +
      `<th><span class="res-col-num">②</span> ${esc(i18nT("res.lattice.col.energy"))}</th>` +
      `<th><span class="res-col-num">③</span> ${esc(i18nT("res.lattice.col.bulk"))}</th>` +
      `<th><span class="res-col-num">④</span> ${esc(i18nT("res.lattice.col.bprime"))}</th>` +
      `<th><span class="res-col-num">⑤</span> ${esc(i18nT("res.lattice.col.volume"))}</th>` +
      `<th><span class="res-col-num">⑥</span> ${esc(i18nT("res.lattice.col.shear"))}</th>` +
      `<th>${esc(i18nT("res.lattice.col.source"))}</th></tr>`;
    const lines = rows.map((r) => {
      const epa = r.energy_per_atom_ev != null ? fmtLatticeNum(r.energy_per_atom_ev, 6) : "—";
      const b = r.bulk_modulus_gpa != null ? fmtLatticeNum(r.bulk_modulus_gpa, 2) : "—";
      const bp = r.bulk_derivative != null ? fmtLatticeNum(r.bulk_derivative, 2) : i18nT("res.lattice.bprime.na");
      const g = r.shear_modulus_gpa != null ? fmtLatticeNum(r.shear_modulus_gpa, 2) : "—";
      const src = r.from_kind ? String(r.from_kind).toUpperCase() : "—";
      const bNote = r.bulk_modulus_gpa != null ? bulkSrc(r.bulk_source) : "";
      const lat = latticeCell(r);
      return `<tr><th scope="row">${esc(r.label || r.mag_order || "—")}</th>` +
        `<td>${esc(lat)}${bNote ? `<br><span class="meta">${esc(bNote)}</span>` : ""}</td>` +
        `<td class="num-hi">${esc(epa)}<span class="meta"> eV/at</span></td>` +
        `<td class="num-hi">${esc(b)}</td>` +
        `<td class="num-hi">${esc(String(bp))}</td>` +
        `<td class="num-hi">${fmtLatticeNum(r.volume_ang3, 3)}<span class="meta"> Å³</span></td>` +
        `<td class="num-hi">${esc(g)}</td>` +
        `<td>${esc(src)}</td></tr>`;
    });
    const note = lang === "en" ? (data.note_en || data.note_fr) : (data.note_fr || data.note_en);
    el.innerHTML =
      `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table"><thead>${head}</thead>` +
      `<tbody>${lines.join("")}</tbody></table></div>` +
      (note ? `<p class="meta">${esc(note)}</p>` : "");
  }

  function paintNmPipeline(steps) {
    const el = $("res-nm-pipeline");
    if (!el) return;
    const kinds = [
      { id: "vc-relax", label: "VC-RELAX" },
      { id: "relax", label: "RELAX" },
      { id: "scf", label: "SCF NM" },
    ];
    const cells = kinds.map((k, i) => {
      const st = nmStepFlag(steps[k.id]);
      return `<li class="mag-pipe-step is-${st.cls}">
        <div class="mag-pipe-head">
          <span class="mag-pipe-num">${i + 1}</span>
          <strong class="mag-pipe-label">${k.label}</strong>
          <span class="mag-pipe-icon">${st.icon}</span>
        </div>
        <span class="mag-pipe-state">${esc(st.lab)}</span>
      </li>
      <li class="mag-pipe-arrow" aria-hidden="true">→</li>`;
    }).join("");
    const nscfSt = nmNscfStepState(steps);
    el.innerHTML = `<ol class="mag-pipeline nm-res-pipeline">${cells}
      <li class="mag-pipe-step is-${nscfSt.cls}">
        <div class="mag-pipe-head">
          <span class="mag-pipe-num">4</span>
          <strong class="mag-pipe-label">NSCF</strong>
          <span class="mag-pipe-icon">${nscfSt.icon}</span>
        </div>
        <span class="mag-pipe-state">${esc(nscfSt.lab)}</span>
      </li></ol>`;
  }

  function paintNmAlert(data) {
    const el = $("res-nm-alert");
    if (!el) return;
    const steps = (data && data.steps) || {};
    const scf = steps.scf || {};
    const fm = fmMagRow();
    const fmRun = magOrderRunning(fm);
    if (scf.converged || (scf.output_exists && !scf.running)) {
      el.hidden = true;
      return;
    }
    if (fmRun) {
      el.hidden = false;
      el.className = "mag-nm-fm-alert warn";
      el.textContent = i18nT("res.nm.alert.fm_running", {
        step: String(fmRun.kind).toUpperCase(),
      });
      return;
    }
    if (!scf.output_exists && !scf.running) {
      el.hidden = false;
      el.className = "mag-nm-fm-alert wait";
      el.textContent = i18nT("res.nm.alert.need_nm");
      return;
    }
    el.hidden = true;
  }

  function paintResults(data) {
    const steps = data.steps || {};
    // SCF NM + RELAX visibles ; VC-RELAX reste dans les détails
    for (const kind of ["vc-relax", "relax", "scf"]) {
      const st = steps[kind] || {};
      const bodies = [$("result-body-" + kind)];
      if (kind === "relax") bodies.push($("result-body-relax-main"));
      const stateId = kind === "scf" ? "result-state-nm-summary" : ("result-state-" + kind);
      const state = $(stateId) || $("result-state-" + kind);
      const stateMain = kind === "relax" ? $("result-state-relax-main") : null;
      const html = (kind === "scf" && !st.output_exists && !st.running)
        ? `<p class="meta">${i18nT("res.empty.scf")}</p><p class="meta">${i18nT("res.nm.where")}</p>`
        : (st.running ? resultsRunningDeferHtml(kind) : resultBodyHtml(st, kind));
      bodies.forEach((body) => {
        if (body) body.innerHTML = html;
      });
      let label = "—";
      let cls = "";
      if (st.running) { label = i18nT("state.running"); cls = "running"; }
      else if (st.stopped) { label = i18nT("state.stopped"); cls = "warn"; }
      else if (st.output_exists) { label = st.converged ? i18nT("state.converged") : i18nT("state.not_converged"); cls = st.converged ? "ok" : "warn"; }
      [state, stateMain].forEach((node) => {
        if (!node) return;
        node.textContent = label;
        node.className = "result-state " + cls;
      });
    }
    paintResultsFiles(data.result_files);
    paintNmPipeline(steps);
    if (data.phase_id && data.phase_id !== phaseId) {
      syncPhaseSelects(data.phase_id);
    }
    paintLatticeMechanicsTable(data.lattice_mechanics);
    paintNmAlert(data);
    const nmCard = $("res-nm-card");
    if (nmCard) {
      const scf = steps.scf || {};
      nmCard.classList.toggle("is-converged", !!scf.converged);
      nmCard.classList.toggle("is-running", !!scf.running);
      nmCard.classList.toggle("is-empty", !scf.output_exists && !scf.running);
    }
    // Ligne matériau + bouton fiche technique
    const line = $("results-mat-line");
    if (line) {
      rememberStructure(data);
      const shown = materialDisplay(data);
      const stab = (data.study && data.study.stable_phase_label) || "";
      const lay = data.output_layout || (data.study && data.study.output_layout);
      const outHint = lay && lay.canonical && lay.canonical.nm
        ? lay.canonical.nm.dir
        : (lay && lay.canonical && lay.canonical.root
          ? `${lay.canonical.root}/optimisation`
          : `outputs/materiaux/${data.material || material || ""}/${phaseId || "phase1"}/optimisation`);
      line.textContent = stab
        ? `${data.material || material || ""} · ★ ${stab} · ${outHint}`
        : (shown ? `${shown} · ${outHint}` : outHint);
    }
    paintOutputLayout(data.output_layout || (data.study && data.study.output_layout));
    const ficheBtn = $("btn-open-fiche");
    if (ficheBtn) {
      ficheBtn.hidden = false;
      ficheBtn.onclick = () => {
        const m = data.material || material || "";
        const pid = activePhaseId();
        let url = "fiche.html?fiche=" + encodeURIComponent(m);
        if (pid) url += "&phase_id=" + encodeURIComponent(pid);
        window.open(url, "_blank");
      };
    }
    const gotoNm = $("btn-goto-nm");
    if (gotoNm) {
      gotoNm.onclick = () => switchTab("optimisation");
    }
    const gotoMag = $("btn-goto-mag");
    if (gotoMag) {
      gotoMag.onclick = () => switchTab("magnetisme");
    }
    const gotoProp = $("btn-goto-prop");
    if (gotoProp) {
      gotoProp.onclick = () => switchTab("proprietes");
    }
    // Input SCF suggéré (variantes auto / ibrav=0)
    const sug = data.scf_suggestion;
    lastScfSuggestion = sug || null;
    const prev = $("scf-input-preview");
    const note = $("scf-input-note");
    const stateIn = $("result-state-scf-input");
    const applyBtn = $("btn-scf-apply");
    const has = !!(sug && (sug.content_auto || sug.content));
    if (prev) prev.textContent = has ? currentScfContent() : "";
    if (note) {
      if (sug && sug.pending_relax && !sug.canonical) {
        note.textContent = i18nT("chain.scf.pending_relax");
      } else if (has) {
        let txt = i18nT("res.scfinput.from", { kind: kindLabel(sug.from || "relax") });
        if (scfMode === "auto" && sug.ibrav != null) {
          txt += ` · ibrav = ${sug.ibrav}`;
          if (sug.ibrav_label) txt += ` — ${sug.ibrav_label}`;
          if (sug.celldm) {
            const cd = fmtCelldm(sug.celldm);
            if (cd) txt += ` · ${cd} bohr`;
          }
        } else if (scfMode === "zero") {
          txt += ` · ${i18nT("res.scfinput.mode.zero")}`;
        }
        note.textContent = txt;
      } else {
        note.textContent = i18nT("res.scfinput.none");
      }
    }
    if (stateIn) {
      stateIn.textContent = has ? (sug.current_scf_input_exists ? i18nT("res.scfinput.applied") : i18nT("res.scfinput.ready")) : "—";
      stateIn.className = "result-state " + (has ? "ok" : "");
    }
    if (applyBtn) applyBtn.disabled = !has;
    const dl = $("btn-scf-download");
    if (dl) dl.disabled = !has;
    const modeSel = $("scf-mode-select");
    if (modeSel) modeSel.value = scfMode;
  }

  function paintPhaseStability(data) {
    lastPhaseStability = data && data.phases ? data : lastPhaseStability;
    if (sessionConfirmed && material && (data && data.phases)) paintSessionBar();
    const body = $("phase-stability-body");
    const note = $("phase-stability-note");
    const btnStable = $("btn-postscf-nscf-stable");
    const btnCur = $("btn-postscf-nscf");
    const btnGen = $("btn-gen-structures");
    const sug = (data && data.suggest) || {};
    if (btnGen) {
      btnGen.disabled = !sessionConfirmed || !material || sug.can_generate === false;
      if (sug.button_label) btnGen.textContent = sug.button_label;
    }
    if (!body) return;
    const rows = (data && data.phases) || [];
    if (!material || !rows.length) {
      body.innerHTML = `<p class="meta">${i18nT("phase.stability.empty")}</p>`;
      const resPhEmpty = $("res-phases-body");
      if (resPhEmpty) resPhEmpty.innerHTML = `<p class="meta">${i18nT("phase.stability.empty")}</p>`;
      if (btnStable) btnStable.disabled = true;
      if (btnCur) btnCur.disabled = !material;
      return;
    }
    const ref = data.reference_phase_id;
    const matForRows = (data && data.material) || material;
    const launchOk = isDopingVerifiedForLaunch();
    const btnAll = $("btn-phase-chains-all");
    if (btnAll) {
      const anyRun = rows.some((r) => r.running);
      const need = rows.some((r) => !(r.vc_relax_converged && r.relax_converged && r.scf_converged));
      btnAll.disabled = !sessionConfirmed || !matForRows || anyRun || !need || !launchOk;
    }
    // Chaîne complète par structure + E/atome → ★ = plus stable NM
    const defaultChainStart = getPhaseChainStartKind();
    const dopUi = dopingVerifyGateActive();
    const head = dopUi
      ? `<tr><th>${esc(i18nT("phase.col.edit"))}</th><th>${esc(i18nT("phase.col.structure"))}</th><th>${esc(i18nT("phase.col.folder"))}</th>` +
        `<th>VC-RELAX</th><th>RELAX</th><th>SCF</th><th>E/atom (eV)</th><th>ΔE</th><th></th></tr>`
      : `<tr><th>${esc(i18nT("phase.col.structure"))}</th><th>${esc(i18nT("phase.col.folder"))}</th>` +
        `<th>${esc(i18nT("phase.col.edit"))}</th><th>VC-RELAX</th><th>RELAX</th><th>SCF</th>` +
        `<th>E/atom (eV)</th><th>ΔE</th><th></th></tr>`;
    const lines = rows.map((r) => {
      const stable = ref != null && r.phase_id === ref;
      const flag = (ok) => (ok ? "✓" : "—");
      const pid = r.phase_id || "";
      const stLab = r.structure_label || r.label || pid || i18nT("phase.principal");
      const cr = r.chain_resume || {};
      const chainMeta = chainButtonMeta(cr, r.chain_steps || {}, CHAIN_KINDS_GEOM);
      const completed = (cr.completed || []).length;
      const startKind = completed ? (chainMeta.startKind || "vc-relax") : defaultChainStart;
      const chainDone = !!cr.all_done;
      const runDis = (!sessionConfirmed || r.running || chainDone || !launchOk) ? "disabled" : "";
      const editDis = !phaseEditorMaterial() ? "disabled" : "";
      const epa = r.energy_per_atom_ev != null ? fmtEnergyEv(r.energy_per_atom_ev) : "—";
      const de = r.delta_ev_per_atom != null ? fmtDeltaEv(r.delta_ev_per_atom) : "—";
      const expMark = r.is_experimental ? ` <span class="meta">(${esc(i18nT("phase.exp.short"))})</span>` : "";
      const chainBtnLab = r.running ? "…" : chainMeta.label;
      const chainBtnCls = `btn ghost btn-phase-chain${chainMeta.retry ? " btn-chain-retry" : ""}`;
      const isDop = /^dop_/i.test(pid);
      const editBtns = phaseEditButtonsHtml(pid, matForRows, isDop ? { doping: true } : { compact: true });
      const actions =
        `<button type="button" class="${chainBtnCls}" data-phase="${escAttr(pid)}" data-kind="${escAttr(startKind)}" title="${escAttr(chainMeta.title)}" ${runDis}>${esc(chainBtnLab)}</button> ` +
        `<button type="button" class="btn ghost btn-phase-activate" data-phase="${escAttr(pid)}" ${launchOk ? "" : "disabled"}>${esc(i18nT("phase.activate"))}</button>`;
      const rowCls = `${stable ? "phase-row-stable" : ""}${r.running ? " is-running" : ""}`;
      const rowTit = esc(r.energy_note || "");
      const cStruct = `<td>${esc(stLab)}${stable ? " ★" : ""}${expMark}</td>`;
      const cFolder = `<td><code>${esc(pid || "—")}</code></td>`;
      const cFlags =
        `<td>${flag(r.vc_relax_converged)}</td><td>${flag(r.relax_converged)}</td><td>${flag(r.scf_converged)}</td>`;
      const cEn =
        `<td class="num-hi">${esc(epa)}</td><td class="num-hi">${esc(de)}</td><td class="phase-actions">${actions}</td>`;
      const cEdit = `<td class="phase-edit-cell">${editBtns}</td>`;
      return dopUi
        ? `<tr class="${rowCls}" title="${rowTit}">${cEdit}${cStruct}${cFolder}${cFlags}${cEn}</tr>`
        : `<tr class="${rowCls}" title="${rowTit}">${cStruct}${cFolder}${cEdit}${cFlags}${cEn}</tr>`;
    });
    const warn = (data && data.warning_nm)
      ? `<p class="meta phase-nm-warn" role="status">${esc(data.warning_nm)}</p>`
      : "";
    const transHtml = renderPhaseTransitionsBlock(data);
    const tableHtml = `${warn}<div class="mag-table-scroll"><table class="phase-table mag-cmp-table"><thead>${head}</thead><tbody>${lines.join("")}</tbody></table></div>${transHtml}`;
    body.innerHTML = tableHtml;
    const resPh = $("res-phases-body");
    if (resPh) {
      const ro = rows.map((r) => {
        const stable = ref != null && r.phase_id === ref;
        const flag = (ok) => (ok ? "✓" : "—");
        const de = r.delta_ev_per_atom != null ? fmtDeltaEv(r.delta_ev_per_atom) : "—";
        const epa = fmtEnergyEv(r.energy_per_atom_ev);
        const pid = r.phase_id || "";
        const stLab = r.structure_label || r.label || pid || i18nT("phase.principal");
        return `<tr class="${stable ? "phase-row-stable" : ""}" title="${esc(r.energy_note || "")}"><td>${esc(stLab)}${stable ? " ★" : ""}</td><td>${esc(pid || "—")}</td><td>${flag(r.vc_relax_converged)}</td><td>${flag(r.relax_converged)}</td><td>${flag(r.scf_converged)}</td><td class="num-hi">${esc(epa)}</td><td class="num-hi">${esc(de)}</td></tr>`;
      });
      const headRo = `<tr><th>${i18nT("phase.col.structure")}</th><th>${i18nT("phase.col.folder")}</th><th>VC-RELAX</th><th>RELAX</th><th>SCF</th><th>E/atom (eV)</th><th>ΔE (eV/at)</th></tr>`;
      resPh.innerHTML = `${warn}<div class="mag-table-scroll"><table class="phase-table mag-cmp-table"><thead>${headRo}</thead><tbody>${ro.join("")}</tbody></table></div>${renderPhaseTransitionsBlock(data)}`;
    }
    if (note) {
      // Conserver le guide de workflow ; n’ajouter que les alertes NM.
      const base = i18nT("phase.stability.hint");
      const warn = (data && data.warning_nm) || "";
      note.textContent = warn ? `${base} ⚠ ${warn}` : base;
    }
    const anyScf = rows.some((r) => r.scf_converged);
    const elasticBtn = $("btn-postscf-elastic");
    const canPost = sessionConfirmed && material;
    if (btnStable) btnStable.disabled = !canPost || !anyScf || ref == null;
    if (btnCur) btnCur.disabled = !canPost;
    if (elasticBtn) elasticBtn.disabled = !canPost || !anyScf;
    const runRow = rows.find((r) => r.running);
    const interruptRow = !runRow
      ? rows.find((r) => {
        const cr = r.chain_resume || {};
        return !!(cr.retry || cr.prior_fail || cr.partial) && !cr.all_done;
      })
      : null;
    const phaseBanner = $("status-phase-chain");
    const phasePipeHost = $("phase-chain-pipeline-host");
    if (phasePipeHost) {
      if (runRow) {
        const crRun = runRow.chain_resume || {};
        const failKind = crRun.retry ? (crRun.next_kind || phaseChainPollKind(runRow)) : "";
        phasePipeHost.hidden = false;
        phasePipeHost.innerHTML = buildPhaseChainPipelineOl(runRow, failKind);
        const pk0 = phaseChainPollKind(runRow);
        const st0 = (runRow.chain_steps && runRow.chain_steps[pk0]) || {};
        if (st0.running || st0.run_phase === "running") {
          updatePhasePipeLiveMetrics(runRow.phase_id, pk0, {
            ...st0,
            kind: pk0,
            running: true,
            progress: st0.run_progress || st0.progress,
          });
        }
      } else {
        phasePipeHost.hidden = true;
        phasePipeHost.innerHTML = "";
      }
    }
    if (phaseBanner) {
      if (runRow) {
        const pk = phaseChainPollKind(runRow);
        const stepSt = (runRow.chain_steps && runRow.chain_steps[pk]) || {};
        const metricsLine = liveMetricsLabel(
          { ...stepSt, kind: pk, running: !!(stepSt.running || stepSt.run_phase === "running") },
          pk
        );
        const line = [
          i18nT("phase.chain.running", {
            phase: runRow.phase_id || "—",
            step: String(pk).toUpperCase(),
          }),
          metricsLine,
        ].filter(Boolean).join(" · ");
        phaseBanner.innerHTML = formatLiveBannerHtml(line, {
          ...stepSt,
          kind: pk,
          running: true,
          percent: stepSt.percent,
        });
        phaseBanner.className = "mag-chain-banner running";
        phaseBanner.hidden = false;
      } else if (interruptRow) {
        const cr = interruptRow.chain_resume || {};
        const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
        phaseBanner.textContent = lang === "en" ? (cr.message_en || cr.message_fr) : (cr.message_fr || cr.message_en) || "—";
        phaseBanner.className = "mag-chain-banner warn";
        phaseBanner.hidden = false;
      } else {
        phaseBanner.textContent = "—";
        phaseBanner.className = "mag-chain-banner";
        phaseBanner.hidden = true;
      }
    }
    if (runRow && !optimPollTimer) {
      const pk = phaseChainPollKind(runRow);
      const stepSt = (runRow.chain_steps && runRow.chain_steps[pk]) || {};
      paintLiveOnTrack(
        "track-phase-chain",
        {
          ...stepSt,
          kind: pk,
          running: true,
          label: stepSt.run_label || i18nT("state.running"),
          progress: stepSt.run_progress || stepSt.progress,
        },
        { kind: pk }
      );
      startOptimPoll(
        material,
        pk,
        jobId,
        null,
        runRow.phase_id || "",
        "track-phase-chain"
      );
      refreshRuns().catch(() => {});
      if (sessionConfirmed && material && !runsAutoTimer) startRunsAutoRefresh();
    }
    const phaseFixRow = interruptRow || (runRow ? null : rows.find((r) => {
      const cr = r.chain_resume || {};
      return !!(cr.retry && cr.next_kind);
    }));
    const phaseFixHost = ensureChainFixSlot($("phase-stability-body"), "phase-chain-fix");
    if (phaseFixHost) {
      if (phaseFixRow && !phaseFixRow.running) {
        const pk = (phaseFixRow.chain_resume && phaseFixRow.chain_resume.next_kind) || phaseChainPollKind(phaseFixRow);
        const st = (phaseFixRow.chain_steps && phaseFixRow.chain_steps[pk]) || {};
        phaseFixHost.innerHTML = stepNeedsFix(st)
          ? chainFixPanelHtml({ ...st, kind: pk }, { kind: pk, phaseId: phaseFixRow.phase_id || "" })
          : "";
      } else {
        phaseFixHost.innerHTML = "";
      }
      phaseFixHost.hidden = !phaseFixHost.innerHTML;
    }
    if (rows.some((r) => r.running)) {
      setTimeout(() => refreshPhaseStability().catch(() => {}), 4000);
    }
  }

  function populateSqsPhaseSelects(phases, enabled) {
    const selA = $("sqs-phase-a");
    const selB = $("sqs-phase-b");
    if (!selA || !selB) return;
    const list = (phases || []).filter((p) => p.id && !p.legacy);
    const opts = list
      .map(
        (ph) =>
          `<option value="${escAttr(ph.id)}">${esc(ph.label || ph.id)} (${esc(ph.id)})</option>`
      )
      .join("");
    const empty = `<option value="">—</option>`;
    selA.innerHTML = empty + opts;
    selB.innerHTML = empty + opts;
    const on = !!enabled && list.length >= 2;
    selA.disabled = !on;
    selB.disabled = !on;
    const btnP = $("btn-sqs-preview");
    const btnG = $("btn-sqs-generate");
    if (btnP) btnP.disabled = !on;
    if (btnG) btnG.disabled = !on;
  }

  function selectedSqsFractions() {
    const fr = [];
    document.querySelectorAll(".sqs-frac:checked").forEach((el) => {
      const v = parseInt(el.value, 10);
      if (v > 0 && v < 100) fr.push(v / 100);
    });
    const custom = ($("sqs-frac-custom")?.value || "").trim();
    custom.split(/[,;\s]+/).forEach((tok) => {
      if (!tok) return;
      const v = parseFloat(tok.replace("%", ""));
      if (!Number.isFinite(v)) return;
      if (v > 0 && v < 1) fr.push(v);
      else if (v > 0 && v < 100) fr.push(v / 100);
    });
    return [...new Set(fr.map((f) => Math.round(f * 1000) / 1000))].sort((a, b) => a - b);
  }

  function paintSqsPreview(data) {
    const body = $("sqs-preview-body");
    const st = $("sqs-status");
    if (st) {
      st.textContent = data?.message_fr || data?.message_en || data?.error || "";
      st.className = "meta" + (data?.ok === false ? " status-err" : data?.ok ? " status-ok" : "");
    }
    if (!body) return;
    if (!data || !data.ok) {
      body.innerHTML = `<p class="meta">${esc(data?.error || "—")}</p>`;
      return;
    }
    const sc = data.supercell || {};
    const head = `<tr><th>${esc(i18nT("phase.sqs.col.phase"))}</th><th>${esc(i18nT("phase.sqs.col.frac"))}</th><th>${esc(i18nT("phase.sqs.col.quality"))}</th><th>${esc(i18nT("phase.sqs.col.atoms"))}</th><th>${esc(i18nT("phase.sqs.col.formula"))}</th></tr>`;
    const rows = (data.compositions || [])
      .map(
        (c) => {
          const q = c.sqs_quality || {};
          const grade = q.grade ? `<strong>${esc(q.grade)}</strong>` : "—";
          const wc = q.warren_cowley_max != null ? ` α≤${esc(String(q.warren_cowley_max))}` : "";
          return (
            `<tr><td><code>${esc(c.phase_id)}</code></td><td class="num-hi">${esc(String(c.fraction_b_pct))} % ${esc(data.species_b)}</td>` +
            `<td>${grade}<span class="meta">${wc}</span></td>` +
            `<td class="num-hi">${esc(String(c.n_species_a))} ${esc(data.species_a)} · ${esc(String(c.n_species_b))} ${esc(data.species_b)}</td>` +
            `<td>${esc(c.formula || "")}</td></tr>`
          );
        }
      )
      .join("");
    const backend = data.sqs_backend || {};
    const eng =
      backend.preferred_engine === "atat_mcsqs"
        ? i18nT("phase.sqs.engine.atat")
        : i18nT("phase.sqs.engine.internal");
    body.innerHTML =
      `<p class="meta">${esc(i18nT("phase.sqs.supercell", { nx: sc.nx, ny: sc.ny, nz: sc.nz, n: data.n_atoms_supercell }))}</p>` +
      `<p class="meta">${esc(eng)} · ${esc(data.species_a)} ↔ ${esc(data.species_b)} · ${esc(data.phase_a)} + ${esc(data.phase_b)}</p>` +
      `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table"><thead>${head}</thead><tbody>${rows}</tbody></table></div>`;
  }

  async function previewSqs() {
    if (!requireSessionConfirmed()) return;
    const phase_a = ($("sqs-phase-a")?.value || "").trim();
    const phase_b = ($("sqs-phase-b")?.value || "").trim();
    const fractions = selectedSqsFractions();
    if (!phase_a || !phase_b) {
      alert(i18nT("phase.sqs.pick_phases"));
      return;
    }
    if (phase_a === phase_b) {
      alert(i18nT("phase.sqs.distinct"));
      return;
    }
    if (!fractions.length) {
      alert(i18nT("phase.sqs.pick_frac"));
      return;
    }
    const data = await api(`/api/materials/${encodeURIComponent(material)}/phases/sqs/preview`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phase_a, phase_b, fractions, estimate_quality: true }),
    });
    paintSqsPreview(data);
    return data;
  }

  async function generateSqs() {
    if (!requireSessionConfirmed()) return;
    const phase_a = ($("sqs-phase-a")?.value || "").trim();
    const phase_b = ($("sqs-phase-b")?.value || "").trim();
    const fractions = selectedSqsFractions();
    if (!phase_a || !phase_b || phase_a === phase_b || !fractions.length) {
      await previewSqs();
      return;
    }
    const data = await api(`/api/materials/${encodeURIComponent(material)}/phases/sqs/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phase_a, phase_b, fractions }),
    });
    paintSqsPreview(data.preview || data);
    log("log-opt", data.message_fr || data.message_en || data.error || "", !!data.ok);
    if (data.ok) {
      await refreshPhasesForDraft();
      await refreshPhaseStability().catch(() => {});
      if (PHASES_PREP_ONLY) {
        log("log-opt", i18nT("session.prep_only.after_sqs"), true);
        const matSeed = material || getDraftMaterial() || "";
        if (matSeed) setResultsBrowseMat(matSeed, { keepKind: true });
        setResultsBrowseKind("nondope", { skipLoad: true });
        switchSessionWorkTab("resultats");
        await refreshMaterialIoProfile().catch(() => {});
      }
    }
    return data;
  }

  /** Libellé uniforme des listes hôte / dopant : symbole · détail */
  function formatDopingElementOption(symbol, detail) {
    const sym = String(symbol || "").trim();
    if (!sym) return "";
    const d = String(detail || "").trim();
    return d ? `${sym} · ${d}` : sym;
  }

  function hostElementOptionDetail(el, count) {
    const n = count != null && count !== "" ? Number(count) : NaN;
    if (Number.isFinite(n) && n > 0) return i18nT("phase.doping.host_sites", { n: String(n) });
    return "";
  }

  async function refreshDopingHostElements() {
    const mat = getPhaseDopingParentA();
    const selHost = $("doping-host-element");
    const manual = $("doping-host-element-manual");
    if (!selHost || !mat) {
      lastDopingSpecies = null;
      if (selHost) {
        selHost.innerHTML = `<option value="">—</option>`;
        selHost.disabled = true;
      }
      if (manual) manual.hidden = true;
      updateDopantSuggestions();
      updateDopingActionsEnabled();
      return;
    }
    const parentB = getPhaseDopingParentB();
    const params = new URLSearchParams();
    if (parentB) params.set("parent_b", parentB);
    const qs = params.toString() ? `?${params.toString()}` : "";
    try {
      const data = await api(
        `/api/materials/${encodeURIComponent(mat)}/phases/doping/species${qs}`
      );
      lastDopingSpecies = data && data.ok ? data : null;
      if (!data.ok) {
        selHost.innerHTML = `<option value="">—</option>`;
        selHost.disabled = true;
        selHost.hidden = true;
        if (manual) {
          manual.hidden = false;
          manual.disabled = false;
          if (!manual.value.trim()) {
            manual.value = localStorage.getItem("optimqe.dopingHostElement") || "";
          }
        }
        return;
      }
      const els = data.dopable_elements || data.elements || [];
      const cations = data.cations || [];
      const anions = data.anions || [];
      const emptyOpt = `<option value="">${esc(i18nT("phase.doping.host_pick"))}</option>`;
      
      // Construction du HTML avec séparation cations/anions
      let optionsHtml = emptyOpt;
      
      const cationLab = i18nT("phase.doping.group.cations");
      const anionLab = i18nT("phase.doping.group.anions");
      if (cations.length > 0) {
        optionsHtml += `<optgroup label="${escAttr(cationLab)}">`;
        cations.forEach((el) => {
          const n = (data.counts && data.counts[el]) || "";
          const lab = formatDopingElementOption(el, hostElementOptionDetail(el, n));
          optionsHtml += `<option value="${escAttr(el)}">${esc(lab)}</option>`;
        });
        optionsHtml += `</optgroup>`;
      }
      if (anions.length > 0) {
        optionsHtml += `<optgroup label="${escAttr(anionLab)}">`;
        anions.forEach((el) => {
          const n = (data.counts && data.counts[el]) || "";
          const lab = formatDopingElementOption(el, hostElementOptionDetail(el, n));
          optionsHtml += `<option value="${escAttr(el)}">${esc(lab)}</option>`;
        });
        optionsHtml += `</optgroup>`;
      }
      if (cations.length === 0 && anions.length === 0 && els.length > 0) {
        els.forEach((el) => {
          const n = (data.counts && data.counts[el]) || "";
          const lab = formatDopingElementOption(el, hostElementOptionDetail(el, n));
          optionsHtml += `<option value="${escAttr(el)}">${esc(lab)}</option>`;
        });
      }
      
      const previousHost = (selHost.value || "").trim();
      selHost.innerHTML = optionsHtml;
      selHost.hidden = false;
      selHost.disabled = false;
      if (manual) manual.hidden = true;

      // Conserver le choix utilisateur (ex. O pour dopage anionique) — ne pas le remplacer par Cr/Gd sauvegardé
      const allElements = [...cations, ...anions];
      const saved = localStorage.getItem("optimqe.dopingHostElement") || "";
      const suggested = data.suggested_host || "";
      let pick = "";
      if (previousHost && allElements.includes(previousHost)) pick = previousHost;
      else if (saved && allElements.includes(saved)) pick = saved;
      else if (suggested && allElements.includes(suggested)) pick = suggested;
      else if (allElements.length === 1) pick = allElements[0];
      if (pick) selHost.value = pick;

      paintDopingHostModeHint();
      
      const st = $("doping-status");
      if (st && suggested && pick === suggested) {
        st.textContent = i18nT("phase.doping.host_suggested", { el: suggested });
        st.className = "meta status-ok";
      }
    } catch {
      lastDopingSpecies = null;
      selHost.disabled = false;
      selHost.hidden = true;
      if (manual) {
        manual.hidden = false;
        manual.disabled = false;
      }
    } finally {
      updateDopantSuggestions();
      updateDopingActionsEnabled();
    }
  }

  function getDopingHostElement() {
    const sel = ($("doping-host-element")?.value || "").trim();
    if (sel) return sel;
    return ($("doping-host-element-manual")?.value || "").trim();
  }

  // Mettre à jour les suggestions de dopants selon l'élément hôte (cation ou anion)
  function paintDopingHostModeHint() {
    const st = $("doping-status");
    if (!st) return;
    const host = getDopingHostElement();
    const anionLike = ["O", "F", "Cl", "Br", "I", "N", "S", "P", "H", "C", "Se", "Te"];
    if (host && anionLike.includes(host)) {
      st.textContent = i18nT("phase.doping.hint_anion_host", { host });
      st.className = "meta status-ok";
    }
  }

  function dopingAnionLikeSet() {
    return new Set(["O", "F", "Cl", "Br", "I", "N", "S", "P", "H", "C", "Se", "Te"]);
  }

  function inferDopantFromParentB(hostElement, elementsB) {
    const anionLike = dopingAnionLikeSet();
    const host = (hostElement || "").trim();
    const els = elementsB || [];
    if (!host || !els.length) return "";
    const cationsB = els.filter((e) => e && !anionLike.has(e) && e !== host);
    if (cationsB.length === 1) return cationsB[0];
    return cationsB[0] || "";
  }

  function updateDopantSuggestions() {
    ensureDopingHostFromParents();
    const hostElement = getDopingHostElement();
    const select = $("doping-dopant-element");
    if (!select) return;

    const previousDopant = (select.value || "").trim();
    const savedDopant = localStorage.getItem("optimqe.dopingElement") || "";
    const pairFromParents = inferDopingPairFromParents(
      getPhaseDopingParentA(),
      getPhaseDopingParentB()
    );

    const anionLike = dopingAnionLikeSet();
    if (!hostElement) {
      select.innerHTML = `<option value="">${esc(i18nT("phase.doping.dopant_need_host"))}</option>`;
      select.disabled = true;
      return;
    }
    select.disabled = false;
    const isAnionHost = anionLike.has(hostElement);
    const langEn = window.qeI18n && window.qeI18n.getLang && window.qeI18n.getLang() === "en";

    const cationDopants = [
      { value: "Mn", name: langEn ? "Manganese" : "Manganèse" },
      { value: "Fe", name: langEn ? "Iron" : "Fer" },
      { value: "Co", name: langEn ? "Cobalt" : "Cobalt" },
      { value: "Ni", name: langEn ? "Nickel" : "Nickel" },
      { value: "Cu", name: langEn ? "Copper" : "Cuivre" },
      { value: "Ga", name: langEn ? "Gallium" : "Gallium" },
      { value: "Al", name: langEn ? "Aluminium" : "Aluminium" },
      { value: "Ti", name: langEn ? "Titanium" : "Titane" },
      { value: "V", name: langEn ? "Vanadium" : "Vanadium" },
      { value: "Zn", name: langEn ? "Zinc" : "Zinc" },
      { value: "Sc", name: langEn ? "Scandium" : "Scandium" },
      { value: "Y", name: langEn ? "Yttrium" : "Yttrium" },
      { value: "La", name: langEn ? "Lanthanum" : "Lanthane" },
      { value: "Ce", name: langEn ? "Cerium" : "Cérium" },
      { value: "Pr", name: langEn ? "Praseodymium" : "Praséodyme" },
      { value: "Nd", name: langEn ? "Neodymium" : "Néodyme" },
      { value: "Sm", name: langEn ? "Samarium" : "Samarium" },
      { value: "Eu", name: langEn ? "Europium" : "Europium" },
      { value: "Gd", name: langEn ? "Gadolinium" : "Gadolinium" },
      { value: "Tb", name: langEn ? "Terbium" : "Terbium" },
      { value: "Dy", name: langEn ? "Dysprosium" : "Dysprosium" },
      { value: "Ho", name: langEn ? "Holmium" : "Holmium" },
      { value: "Er", name: langEn ? "Erbium" : "Erbium" },
    ];

    const anionDopants = [
      { value: "N", name: langEn ? "Nitrogen" : "Azote" },
      { value: "C", name: langEn ? "Carbon" : "Carbone" },
      { value: "F", name: langEn ? "Fluorine" : "Fluor" },
      { value: "Cl", name: langEn ? "Chlorine" : "Chlore" },
      { value: "S", name: langEn ? "Sulfur" : "Soufre" },
      { value: "Br", name: langEn ? "Bromine" : "Brome" },
      { value: "I", name: langEn ? "Iodine" : "Iode" },
      { value: "P", name: langEn ? "Phosphorus" : "Phosphore" },
      { value: "Se", name: langEn ? "Selenium" : "Sélénium" },
      { value: "Te", name: langEn ? "Tellurium" : "Tellure" },
    ];

    const dopantLabel = (d) => formatDopingElementOption(d.value, d.name);

    let dopantOptions = (isAnionHost ? anionDopants : cationDopants).filter(
      (d) => d.value !== hostElement
    );
    const fromB = !isAnionHost && lastDopingSpecies?.parent_b_elements
      ? lastDopingSpecies.parent_b_elements.filter(
          (e) => e && !anionLike.has(e) && e !== hostElement
        )
      : [];
    let optionsHtml = `<option value="">${esc(i18nT("phase.doping.dopant_pick"))}</option>`;
    if (fromB.length) {
      const fromSet = new Set(fromB);
      const prim = dopantOptions.filter((d) => fromSet.has(d.value));
      const rest = dopantOptions.filter((d) => !fromSet.has(d.value));
      if (prim.length) {
        optionsHtml += `<optgroup label="${escAttr(i18nT("phase.doping.dopant_from_b"))}">`;
        optionsHtml += prim.map((d) => `<option value="${escAttr(d.value)}">${esc(dopantLabel(d))}</option>`).join("");
        optionsHtml += `</optgroup>`;
      }
      if (rest.length) {
        const restLab = isAnionHost
          ? i18nT("phase.doping.group.dopant_anion")
          : i18nT("phase.doping.dopant_other");
        optionsHtml += `<optgroup label="${escAttr(restLab)}">`;
        optionsHtml += rest.map((d) => `<option value="${escAttr(d.value)}">${esc(dopantLabel(d))}</option>`).join("");
        optionsHtml += `</optgroup>`;
      }
      if (!prim.length && !rest.length) {
        fromB.forEach((el) => {
          optionsHtml += `<option value="${escAttr(el)}">${esc(formatDopingElementOption(el, ""))}</option>`;
        });
      }
    } else {
      const groupLab = isAnionHost
        ? i18nT("phase.doping.group.dopant_anion")
        : i18nT("phase.doping.group.dopant_cation");
      optionsHtml += `<optgroup label="${escAttr(groupLab)}">`;
      optionsHtml += dopantOptions
        .map((d) => `<option value="${escAttr(d.value)}">${esc(dopantLabel(d))}</option>`)
        .join("");
      optionsHtml += `</optgroup>`;
    }

    select.innerHTML = optionsHtml;

    const valid = new Set(
      [...dopantOptions.map((d) => d.value), ...fromB].filter((v) => v && v !== hostElement)
    );
    let restore = "";
    if (previousDopant && valid.has(previousDopant)) restore = previousDopant;
    else if (savedDopant && valid.has(savedDopant)) restore = savedDopant;
    else if (!isAnionHost) {
      const inferred = inferDopantFromParentB(hostElement, lastDopingSpecies?.parent_b_elements);
      if (inferred && valid.has(inferred)) restore = inferred;
    }
    if (
      !restore &&
      !isAnionHost &&
      pairFromParents.dopant &&
      valid.has(pairFromParents.dopant)
    ) {
      restore = pairFromParents.dopant;
    }
    if (restore) select.value = restore;
    updateDopingActionsEnabled();
  }

  function selectedDopingFractions() {
    const fr = [];
    document.querySelectorAll(".doping-frac:checked").forEach((el) => {
      const v = parseInt(el.value, 10);
      if (v > 0 && v < 100) fr.push(v / 100);
    });
    const custom = ($("doping-frac-custom")?.value || "").trim();
    custom.split(/[,;\s]+/).forEach((tok) => {
      if (!tok) return;
      const v = parseFloat(tok.replace("%", "").replace(",", "."));
      if (!Number.isFinite(v)) return;
      if (v > 0 && v < 1) fr.push(v);
      else if (v > 0 && v <= 100) fr.push(v / 100);
    });
    return [...new Set(fr.map((f) => Math.round(f * 1000) / 1000))].sort((a, b) => a - b);
  }

  function paintDopingPreview(data, generateResult) {
    const body = $("doping-preview-body");
    const st = $("doping-status");
    const gen = generateResult && typeof generateResult === "object" ? generateResult : null;
    const preview = data && data.ok ? data : gen && gen.preview ? gen.preview : data;
    if (st) {
      const parts = [];
      if (gen?.message_fr || gen?.message_en) parts.push(gen.message_fr || gen.message_en);
      else if (preview?.message_fr || preview?.message_en) parts.push(preview.message_fr || preview.message_en);
      if (gen?.error) parts.push(gen.error);
      if (gen?.errors?.length) parts.push(gen.errors.join(" · "));
      st.textContent = parts.filter(Boolean).join(" — ") || preview?.error || "";
      const stOk = gen ? !!gen.ok : preview?.ok !== false;
      st.className = "meta" + (!stOk ? " status-err" : stOk ? " status-ok" : "");
    }
    if (!body) return;
    if (!preview || !preview.ok) {
      body.innerHTML = `<p class="meta">${esc(preview?.error || gen?.error || "—")}</p>`;
      return;
    }
    const createdByPid = {};
    (gen?.created || []).forEach((c) => {
      if (c && c.phase_id) createdByPid[c.phase_id] = c;
    });
    const filesGenerated = !!(
      (gen?.created || []).some((c) => c && (c.vc_relax_path || c.inputs_path)) ||
      (gen?.created || []).length
    );
    const sc = preview.supercell || {};
    const jobMat = getPhaseDopingJobMaterial() || preview.material || "";
    const head =
      `<tr><th>${esc(i18nT("phase.col.edit"))}</th>` +
      `<th>${esc(i18nT("phase.doping.col.kind"))}</th>` +
      `<th>${esc(i18nT("phase.doping.col.frac"))}</th>` +
      `<th>${esc(i18nT("phase.doping.col.material"))}</th>` +
      `<th>${esc(i18nT("phase.doping.col.files"))}</th>` +
      `<th>${esc(i18nT("phase.doping.col.detail"))}</th></tr>`;
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    const endpointRows = (preview.endpoints || [])
      .map((ep) => {
        const lab = lang === "en" ? ep.label_en || ep.label_fr : ep.label_fr || ep.label_en;
        const pmat = ep.material || "";
        return (
          `<tr class="doping-row-parent"><td class="phase-edit-cell">${phaseEditButtonsHtml("", pmat, { doping: true })}</td>` +
          `<td>${esc(i18nT("phase.doping.kind.parent"))}</td>` +
          `<td class="num-hi">${esc(String(ep.fraction_dopant_pct))} %</td>` +
          `<td><strong>${esc(pmat)}</strong></td>` +
          `<td class="meta">—</td>` +
          `<td>${esc(lab || "")}</td></tr>`
        );
      })
      .join("");
    const interRows = (preview.intermediates || preview.compositions || [])
      .map((c) => {
        const sub =
          `${esc(String(c.n_dopant_sublattice))} ${esc(preview.dopant)} · ` +
          `${esc(String(c.n_host_sublattice))} ${esc(preview.host_element)} / ${esc(String(c.n_sublattice))}`;
        const pid = c.phase_id || "";
        const cr = createdByPid[pid];
        const fprefix = c.file_prefix || cr?.file_prefix || "";
        const relDir = cr?.inputs_path || (jobMat && pid ? `inputs/materiaux/${jobMat}/${pid}/` : "");
        const vcRel =
          cr?.vc_relax_path ||
          (relDir && fprefix ? relDir + `${fprefix}-vc-relax.in` : relDir && jobMat ? relDir + `${jobMat}-vc-relax.in` : "");
        let filesCell = `<span class="meta">${esc(i18nT("phase.doping.files_pending"))}</span>`;
        if (filesGenerated && relDir) {
          const href = vcRel ? `/${vcRel.replace(/^\//, "")}` : "";
          filesCell = href
            ? `<code class="doping-path"><a href="${escAttr(href)}" target="_blank" rel="noopener">${esc(relDir)}</a></code>`
            : `<code>${esc(relDir)}</code>`;
          const magOrd = cr?.mag_orders || [];
          if (cr?.mag_ok || magOrd.length) {
            const magHref = `/${(cr?.mag_path || relDir + "mag/").replace(/^\//, "")}`;
            filesCell +=
              `<br><span class="meta status-ok">${esc(i18nT("phase.doping.mag_on_disk"))}</span> ` +
              `<code><a href="${escAttr(magHref)}" target="_blank" rel="noopener">mag/</a></code> ` +
              `<span class="meta">(${esc(magOrd.join(", ") || "FM, AFM, NCL")})</span>`;
          }
        } else if (cr?.inputs_path) {
          filesCell = `<code>${esc(cr.inputs_path)}</code>`;
        }
        const hasFile = filesGenerated && cr;
        const editCell = hasFile || pid
          ? phaseEditButtonsHtml(pid, jobMat, { doping: true })
          : `<span class="meta">—</span>`;
        return (
          `<tr class="doping-row-inter"><td class="phase-edit-cell">${editCell}</td>` +
          `<td>${esc(i18nT("phase.doping.kind.intermediate"))} <code>${esc(pid)}</code></td>` +
          `<td class="num-hi">${esc(String(c.fraction_dopant_pct))} %</td>` +
          `<td>${esc(jobMat)}</td>` +
          `<td class="doping-files-cell">${filesCell}</td>` +
          `<td>${esc(c.formula_general || "")}${c.formula_general && c.formula ? " · " : ""}${c.formula ? esc(c.formula) : ""}${sub ? ` · ${sub}` : ""}${fprefix ? ` · <code>${esc(fprefix)}-*.in</code>` : ""}</td></tr>`
        );
      })
      .join("");
    const previewOnly =
      !filesGenerated && !gen
        ? `<p class="meta doping-preview-only" role="status">${esc(i18nT("phase.doping.preview_only"))}</p>`
        : "";
    const onDisk =
      filesGenerated && jobMat
        ? `<p class="meta status-ok">${esc(i18nT("phase.doping.files_on_disk", { job: jobMat }))}</p>`
        : "";
    body.innerHTML =
      previewOnly +
      onDisk +
      `<p class="meta"><strong>${esc(preview.formula_general || `${preview.host_element}(1-x)${preview.dopant}x`)}</strong> · ${esc(i18nT("phase.doping.model"))} · ${esc(preview.host_element)} → ${esc(preview.dopant)} · ${esc(i18nT("phase.doping.job_label"))} ${esc(getPhaseDopingJobMaterial() || preview.material || "")}</p>` +
      `<p class="meta">${esc(i18nT("phase.sqs.supercell", { nx: sc.nx, ny: sc.ny, nz: sc.nz, n: preview.n_atoms_supercell }))} · ${esc(String(preview.n_sublattice_sites))} sites ${esc(preview.host_element)} (${esc(preview.structure_source_material || "")})</p>` +
      `<p class="meta">${esc(i18nT("phase.doping.verify_hint"))}</p>` +
      `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table doping-preview-table"><thead>${head}</thead><tbody>${endpointRows}${interRows}</tbody></table></div>`;
    updateDopingLaunchGate(filesGenerated);
  }

  async function repairDopedJobLayout(jobMat) {
    const resolved = resolveDopingJobMaterial();
    const m = (jobMat || resolved.job || "").trim();
    if (!m) return null;
    const parentA = getPhaseDopingParentA();
    try {
      return await api(`/api/materials/${encodeURIComponent(m)}/phases/doping/repair`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ parent_material_a: parentA || "" }),
      });
    } catch (_) {
      return null;
    }
  }

  async function dopingPhasesOnDisk(jobMat) {
    const m = (jobMat || "").trim();
    if (!m) return [];
    await repairDopedJobLayout(m);
    try {
      const local = await api(`/api/materials/${encodeURIComponent(m)}/phases/doping/files`);
      if (local.ok && (local.phases || []).length) return local.phases;
    } catch (_) {
      /* repli API calculs */
    }
    try {
      const listed = await api(`/api/materials/${encodeURIComponent(m)}/phases`);
      return (listed.phases || [])
        .filter((p) => p && p.id && /^dop_/i.test(String(p.id)))
        .map((p) => {
          const id = String(p.id);
          let dir = String(p.inputs_path || `inputs/materiaux/${m}/${id}/`).replace(/^\//, "");
          if (!dir.endsWith("/")) dir += "/";
          return {
            phase_id: id,
            inputs_path: dir,
            vc_relax_path: `${dir}${m}-vc-relax.in`,
          };
        });
    } catch (_) {
      return [];
    }
  }

  async function paintDopingPreviewAsync(data, generateResult) {
    const jobMat =
      getPhaseDopingJobMaterial() ||
      (data && data.material) ||
      (generateResult && generateResult.material) ||
      "";
    let gen = generateResult && typeof generateResult === "object" ? generateResult : null;
    const disk = await dopingPhasesOnDisk(jobMat);
    if (disk.length) {
      const byId = {};
      (gen?.created || []).forEach((c) => {
        if (c && c.phase_id) byId[c.phase_id] = c;
      });
      disk.forEach((c) => {
        const prev = byId[c.phase_id] || {};
        byId[c.phase_id] = Object.assign({}, prev, c, {
          mag_ok: !!(c.has_magnetic_inputs || (c.mag_orders || []).length || prev.mag_ok),
          mag_orders: c.mag_orders || prev.mag_orders || [],
          mag_path: c.mag_path || prev.mag_path,
        });
      });
      gen = Object.assign({}, gen || {}, {
        ok: !!(gen && gen.ok) || disk.length > 0,
        created: Object.values(byId),
      });
    }
    paintDopingPreview(data, gen);
  }

  async function refreshDopingDiskListing() {
    const jobMat = getPhaseDopingJobMaterial();
    if (!jobMat) return;
    const body = $("doping-preview-body");
    if (!body) return;
    if (body.querySelector(".doping-preview-table tbody tr.doping-row-inter")) return;
    const disk = await dopingPhasesOnDisk(jobMat);
    if (!disk.length) return;
    const intermediates = disk.map((p) => {
      const pct = parseDopingPhasePct(p.phase_id);
      return {
        phase_id: p.phase_id,
        fraction_dopant_pct: pct != null ? pct : "—",
        n_dopant_sublattice: "—",
        n_host_sublattice: "—",
        n_sublattice: "—",
        formula: "",
      };
    });
    const synthetic = {
      ok: true,
      material: jobMat,
      host_element: "—",
      dopant: "—",
      intermediates,
      compositions: intermediates,
      endpoints: [],
      supercell: { nx: "—", ny: "—", nz: "—" },
      n_atoms_supercell: "—",
      n_sublattice_sites: "—",
      structure_source_material: "",
      message_fr: i18nT("phase.doping.files_on_disk", { job: jobMat }),
    };
    await paintDopingPreviewAsync(synthetic, { ok: true, created: disk });
  }

  async function postDopingGenerate(apiMat, payload) {
    const url = `/api/materials/${encodeURIComponent(apiMat)}/phases/doping/generate`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      cache: "no-store",
      body: JSON.stringify(payload),
    });
    const ct = (res.headers.get("content-type") || "").toLowerCase();
    const data = ct.includes("application/json") ? await res.json().catch(() => ({})) : {};
    if (!ct.includes("application/json") && !res.ok) {
      data.error =
        data.error ||
        `Erreur serveur HTTP ${res.status} (génération dopée interrompue — souvent dépendance mag./numpy).`;
    }
    return { httpOk: res.ok, data, status: res.status };
  }

  function onPhaseEditClick(ev) {
    const edit = ev.target && ev.target.closest ? ev.target.closest(".btn-phase-edit") : null;
    if (!edit || edit.disabled) return false;
    openPhaseEditor(
      edit.dataset.phase || "",
      edit.dataset.kind || "vc-relax",
      edit.dataset.jobMat || ""
    ).catch((e) => alert(e.message));
    return true;
  }

  function dopingRequestPayload() {
    syncPhaseDopingMaterials();
    const phase_id = (phaseId || "").trim();
    const host_element = getDopingHostElement();
    const dopant = getSessionDopantElement();
    const fractions = selectedDopingFractions();
    const jobMat = getPhaseDopingJobMaterial();
    const parent_material_a = getPhaseDopingParentA();
    const parent_material_b = getPhaseDopingParentB();
    return {
      phase_id,
      host_element,
      dopant,
      fractions,
      parent_material_a,
      parent_material_b,
      job_material: jobMat,
    };
  }

  async function previewDoping() {
    if (!requireDopingRun()) return;
    const payload = dopingRequestPayload();
    const { phase_id, host_element, dopant, fractions, parent_material_a, parent_material_b, job_material } =
      payload;
    if (!parent_material_a) {
      alert(i18nT("phase.doping.pick_parent_a"));
      return;
    }
    if (!host_element) {
      alert(i18nT("phase.doping.pick_host"));
      return;
    }
    if (!dopant) {
      alert(i18nT("phase.doping.pick_dopant"));
      return;
    }
    if (!fractions.length) {
      alert(i18nT("phase.doping.pick_frac"));
      return;
    }
    localStorage.setItem("optimqe.dopingElement", dopant);
    localStorage.setItem("optimqe.dopingHostElement", host_element);
    const apiMat = dopingApiMaterial({ ...payload, job_material, parent_material_a });
    if (!apiMat) {
      alert(i18nT("alert.pick_mat"));
      return;
    }
    const data = await api(
      `/api/materials/${encodeURIComponent(apiMat)}/phases/doping/preview`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phase_id,
          host_element,
          dopant,
          fractions,
          parent_material_a,
          parent_material_b,
        }),
      }
    );
    await paintDopingPreviewAsync(data);
    return data;
  }

  async function generateDopingPhases() {
    if (!requireDopingRun()) return;
    const payload = dopingRequestPayload();
    if (!payload.parent_material_a || !payload.host_element || !payload.dopant || !payload.fractions.length) {
      await previewDoping();
      return;
    }
    const apiMat = dopingApiMaterial(payload);
    if (!apiMat) {
      alert(i18nT("alert.pick_mat"));
      return;
    }
    const { httpOk, data, status } = await postDopingGenerate(apiMat, payload);
    const errLine = [data.error, ...(data.errors || [])].filter(Boolean).join(" · ");
    const created = (data && data.created) || [];
    const genOk = !!(httpOk && data && data.ok && created.length);
    log(
      "log-opt",
      data.message_fr || data.message_en || errLine || (httpOk ? "" : `HTTP ${status || "erreur"}`),
      genOk
    );
    if (!genOk) {
      const msg =
        errLine ||
        (data && (data.message_fr || data.message_en)) ||
        (!httpOk
          ? i18nT("phase.doping.generate_http", { status: String(status || "?") })
          : i18nT("phase.doping.generate_no_files"));
      alert(msg);
      showToast(msg, false);
      await paintDopingPreviewAsync(data.preview || data, data);
      return data;
    }
    await paintDopingPreviewAsync(data.preview || data, data);
    if (data.inputs_root_used) {
      log("log-opt", `inputs: ${data.inputs_root_used}`, true);
    }
    const magLines = created
      .filter((c) => c && c.mag_ok && (c.mag_orders || []).length)
      .map((c) => `${c.phase_id}: ${(c.mag_orders || []).join(", ")} → ${c.mag_path || ""}`);
    if (magLines.length) {
      log("log-opt", `Magnétisme dopé (nspin 2/4):\n${magLines.join("\n")}`, true);
    }
    if (data.ok) {
      await repairDopedJobLayout(apiMat);
      const vchk = $("doping-verified-check");
      if (vchk) vchk.checked = false;
      updateDopingLaunchGate(true);
      await refreshPhasesForDraft();
      await refreshPhaseStability(apiMat).catch(() => {});
      if (apiMat && material && apiMat !== material) {
        log(
          "log-opt",
          i18nT("phase.doping.stability_job_mat", { job: apiMat, session: material }),
          true
        );
      }
      if (PHASES_PREP_ONLY) {
        log("log-opt", i18nT("session.prep_only.after_confirm_doping"), true);
        const matSeed = apiMat || getPhaseDopingJobMaterial() || material || "";
        if (matSeed) setResultsBrowseMat(matSeed, { keepKind: true });
        setResultsBrowseKind("doped", { skipLoad: true });
        switchSessionWorkTab("resultats");
        await refreshMaterialIoProfile().catch(() => {});
      } else {
        log("log-opt", i18nT("phase.chain.start.after_doping"), true);
        scrollToDopingVerify();
      }
    }
    return data;
  }

  async function generateCrystalPhases(keys) {
    if (!requireSessionConfirmed()) return;
    const body = {};
    if (keys && keys.length) body.keys = keys;
    const data = await api(`/api/materials/${encodeURIComponent(material)}/phases/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    log("log-opt", data.message || data.error || data, !!data.ok);
    if (data.ok) {
      await refreshPhasesForDraft();
      await refreshPhaseStability().catch(() => {});
      $("structure-ai-modal").hidden = true;
    }
    return data;
  }

  function paintStructureAdvice(data) {
    const adviceEl = $("structure-ai-advice");
    const knownEl = $("structure-ai-known");
    const genEl = $("structure-ai-generate");
    if (!data || !data.ok) {
      if (adviceEl) adviceEl.textContent = (data && data.error) || "—";
      return;
    }
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    if (adviceEl) {
      adviceEl.textContent = lang === "en" ? (data.advice_en || data.advice_fr) : (data.advice_fr || data.advice_en);
    }
    paintMaterialTypeBadge(data);
    const known = data.known_phases || [];
    if (knownEl) {
      if (!known.length) {
        knownEl.innerHTML = `<p class="meta">${esc(i18nT("phase.ai.no_catalog"))}</p>`;
      } else {
        const typeTitle = lang === "en" ? (data.type_en || "") : (data.type_fr || "");
        knownEl.innerHTML = (typeTitle
          ? `<p class="meta structure-type-line"><strong>${esc(i18nT("phase.ai.type"))}</strong> ${esc(typeTitle)}</p>`
          : "") + `<ul class="structure-ai-list">${known.map((p) => {
          const lab = lang === "en" ? (p.label_en || p.short) : (p.label_fr || p.short);
          const tags = [
            p.ambient ? i18nT("phase.ai.tag.ambient") : "",
            p.spacegroup || "",
            p.generatable ? i18nT("phase.ai.tag.auto") : i18nT("phase.ai.tag.manual"),
            p.in_ui ? i18nT("phase.ai.tag.in_ui") : "",
          ].filter(Boolean).join(" · ");
          const note = lang === "en" ? (p.note_en || p.note_fr) : (p.note_fr || p.note_en);
          return `<li><strong>${esc(lab)}</strong> <span class="meta">(${esc(tags)})</span>${note ? `<br/><span class="meta">${esc(note)}</span>` : ""}</li>`;
        }).join("")}</ul>`;
      }
    }
    const sug = (data.suggest && data.suggest.proposed) || [];
    const reco = new Set(data.recommended_generatable || []);
    const choices = sug.filter((p) => !p.skip_same && p.key);
    if (genEl) {
      if (!choices.length) {
        genEl.innerHTML = `<p class="meta">${esc(i18nT("phase.ai.none_gen"))}</p>`;
      } else {
        genEl.innerHTML = choices.map((p) => {
          const checked = reco.has(p.key) && !p.exists ? "checked" : "";
          const dis = p.exists ? "disabled" : "";
          const mark = p.exists ? ` · ${i18nT("phase.ai.exists")}` : (p.catalog_ambient ? ` · ${i18nT("phase.ai.tag.ambient")}` : "");
          return `<label class="structure-ai-check"><input type="checkbox" class="structure-ai-key" value="${escAttr(p.key)}" ${checked} ${dis}/> <span>${esc(p.short || p.key)}${esc(mark)}</span></label>`;
        }).join("");
      }
    }
  }

  async function openStructureAdvice(opts = {}) {
    if (!material && !getDraftMaterial()) {
      alert(i18nT("alert.pick_mat"));
      return;
    }
    const mat = material || getDraftMaterial();
    const data = await api(`/api/materials/${encodeURIComponent(mat)}/structure-advice${phaseQuery()}`);
    paintStructureAdvice(data);
    if (opts.showCatalog) {
      await loadStructureCatalog().catch(() => {});
      const det = $("structure-catalog-details");
      if (det) det.open = true;
    }
    $("structure-ai-modal").hidden = false;
  }

  async function loadStructureCatalog() {
    const data = await api("/api/structure-catalog");
    const body = $("structure-catalog-body");
    const note = $("structure-catalog-note");
    if (note) note.textContent = data.note_fr || data.title_fr || "";
    if (!body) return data;
    const rows = data.materials || [];
    if (!rows.length) {
      body.innerHTML = `<p class="meta">—</p>`;
      return data;
    }
    const cats = data.categories || {};
    const types = data.material_types || [];
    const typeBlock = types.length
      ? `<p class="meta"><strong>${esc(i18nT("phase.catalog.types"))}</strong> ${esc(types.map((t) => t.fr).join(" · "))}</p>`
      : "";
    const head = `<tr><th>${esc(i18nT("phase.catalog.col.mat"))}</th><th>${esc(i18nT("phase.catalog.col.type"))}</th><th>${esc(i18nT("phase.catalog.col.ambient"))}</th><th>N</th></tr>`;
    const lines = rows.map((r) => {
      const typ = r.type_fr || (cats[r.category] || {}).fr || r.category || "—";
      return `<tr class="${(r.material || "") === material ? "phase-row-stable" : ""}"><td><button type="button" class="linkish btn-catalog-mat" data-mat="${escAttr(r.material)}">${esc(r.material)}</button></td><td>${esc(typ)}</td><td>${esc(r.ambient_short || "—")}</td><td class="num-hi">${esc(String(r.n_phases || 0))}</td></tr>`;
    }).join("");
    body.innerHTML = `${typeBlock}<div class="mag-table-scroll"><table class="phase-table mag-cmp-table"><thead>${head}</thead><tbody>${lines}</tbody></table></div>`;
    return data;
  }

  function selectedStructureKeys() {
    return [...document.querySelectorAll("#structure-ai-generate input.structure-ai-key:checked:not(:disabled)")]
      .map((el) => el.value)
      .filter(Boolean);
  }

  async function runPhaseChain(pid, startKind) {
    if (PHASES_PREP_ONLY) return;
    if (!requireSessionConfirmed()) return;
    if (!isDopingVerifiedForLaunch()) {
      alert(i18nT("phase.doping.launch_locked"));
      scrollToDopingVerify();
      return;
    }
    const sk = startKind || getPhaseChainStartKind();
    const data = await api(`/api/materials/${encodeURIComponent(material)}/phases/run-chain`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        phase_id: pid || "",
        job_id: jobId || undefined,
        start_kind: sk,
      }),
    });
    log("log-opt", data.message || data.error || data, !!data.ok);
    if (data.ok && (data.started || data.running)) {
      const kind = data.started_kind || startKind || "vc-relax";
      startOptimPoll(material, kind, jobId, null, pid || "", "track-phase-chain");
    }
    await refreshPhaseStability().catch(() => {});
  }

  async function runAllPhaseChains() {
    if (PHASES_PREP_ONLY) return;
    if (!requireSessionConfirmed()) return;
    if (!isDopingVerifiedForLaunch()) {
      alert(i18nT("phase.doping.launch_locked"));
      scrollToDopingVerify();
      return;
    }
    const data = await api(`/api/materials/${encodeURIComponent(material)}/phases/run-all-chains`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        job_id: jobId || undefined,
        skip_complete: true,
        start_kind: getPhaseChainStartKind(),
      }),
    });
    log("log-opt", data.message || data.error || data, !!data.ok);
    await refreshPhaseStability().catch(() => {});
  }

  async function activatePhase(pid) {
    if (![...allPhaseSelects()[0]?.options || []].some((o) => o.value === (pid || ""))) {
      await refreshPhasesForDraft();
    }
    syncPhaseSelects(pid || "");
    if (!sessionConfirmed || getDraftMaterial() !== material) {
      await confirmSession();
    } else {
      await onPhaseChangedKeepSession();
    }
    if (PHASES_ONLY) goMainApp("magnetisme");
    else switchTab("magnetisme");
  }

  function fmtMagNum(v, digits) {
    if (v == null || Number.isNaN(Number(v))) return "—";
    return Number(v).toFixed(digits);
  }

  function fmtEnergyEv(v) {
    if (v == null || Number.isNaN(Number(v))) return "—";
    return Number(v).toFixed(8);
  }

  function fmtGapEv(r) {
    if (!r) return "—";
    const dos = r.dos_at_ef != null ? Number(r.dos_at_ef) : null;
    const metal = r.electronic_type_en === "metal" || r.electronic_type === "conducteur"
      || (dos != null && dos > 0.02);
    if (metal) return "0";
    if (r.band_gap_ev == null && r.gap_ev == null) return "—";
    const g = r.band_gap_ev != null ? r.band_gap_ev : r.gap_ev;
    return g;
  }

  function fmtDeltaEv(v) {
    if (v == null || Number.isNaN(Number(v))) return "—";
    const n = Number(v);
    if (n === 0) return "0";
    const a = Math.abs(n);
    if (a >= 1e-4) return `${n >= 0 ? "+" : ""}${n.toFixed(6)}`;
    return n.toExponential(3);
  }

  function fmtPhaseTransitionValue(tr) {
    if (!tr) return "—";
    if (tr.route === "pressure" && tr.transition_pressure_gpa != null && !Number.isNaN(Number(tr.transition_pressure_gpa))) {
      return `${Number(tr.transition_pressure_gpa).toFixed(2)} GPa`;
    }
    if (tr.route === "temperature") {
      if (tr.transition_temperature_c != null && !Number.isNaN(Number(tr.transition_temperature_c))) {
        return `${Number(tr.transition_temperature_c).toFixed(1)} °C`;
      }
      if (tr.transition_temperature_k != null && !Number.isNaN(Number(tr.transition_temperature_k))) {
        return `${Number(tr.transition_temperature_k).toFixed(1)} K`;
      }
    }
    return "—";
  }

  function fmtPhaseTransitionRoute(tr) {
    if (!tr || !tr.route) return "—";
    if (tr.route === "pressure") return i18nT("phase.transitions.route.pressure");
    if (tr.route === "temperature") return i18nT("phase.transitions.route.temperature");
    return tr.route;
  }

  function renderPhaseTransitionsBlock(data) {
    const ref = data && data.reference_phase_id;
    const list = (data && data.phase_transitions) || [];
    if (ref == null) return "";
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    const hint = lang === "en"
      ? ((data && data.phase_transitions_note_en) || i18nT("phase.transitions.hint"))
      : ((data && data.phase_transitions_note_fr) || i18nT("phase.transitions.hint"));
    if (!list.length) {
      return `<section class="phase-transitions-block"><h4 class="phase-transitions-title">${esc(i18nT("phase.transitions.title"))}</h4><p class="meta">${esc(i18nT("phase.transitions.empty"))}</p></section>`;
    }
    const head = `<tr><th>${esc(i18nT("phase.transitions.col.to"))}</th><th>${esc(i18nT("phase.transitions.col.route"))}</th><th>${esc(i18nT("phase.transitions.col.value"))}</th><th>ΔV/at</th><th>${esc(i18nT("phase.transitions.col.source"))}</th></tr>`;
    const lines = list.map((tr) => {
      const src = tr.source === "dft"
        ? i18nT("phase.transitions.source.dft")
        : tr.source === "catalog"
          ? i18nT("phase.transitions.source.catalog")
          : (tr.source || "—");
      const note = lang === "en" ? (tr.note_en || tr.note_fr || "") : (tr.note_fr || tr.note_en || "");
      const dv = tr.delta_v_per_atom_ang3 != null ? fmtDeltaEv(tr.delta_v_per_atom_ang3) : "—";
      const extra = tr.dft_pressure_gpa != null && tr.catalog_pressure_gpa != null && tr.source === "dft"
        ? ` (${i18nT("phase.transitions.source.catalog")}: ${Number(tr.catalog_pressure_gpa).toFixed(1)} GPa)`
        : "";
      return `<tr title="${escAttr(note)}"><td>${esc(tr.to_label || tr.to_phase_id || "—")}</td><td>${esc(fmtPhaseTransitionRoute(tr))}</td><td class="num-hi">${esc(fmtPhaseTransitionValue(tr))}${esc(extra)}</td><td class="num-hi">${esc(dv)}</td><td>${esc(src || "—")}</td></tr>`;
    });
    return `<section class="phase-transitions-block"><h4 class="phase-transitions-title">${esc(i18nT("phase.transitions.title"))}</h4><p class="meta">${esc(hint)}</p><div class="mag-table-scroll"><table class="phase-table mag-cmp-table phase-transitions-table"><thead>${head}</thead><tbody>${lines.join("")}</tbody></table></div></section>`;
  }

  function magRowScfEnergy(r) {
    if (!r || r.energy_per_atom_ev == null) return null;
    if (!(r.scf_converged || r.from_main_scf)) return null;
    return Number(r.energy_per_atom_ev);
  }

  function pickLowestMagOrder(rows, orders) {
    let best = null;
    let bestE = Infinity;
    (orders || []).forEach((ord) => {
      const r = rows.find((x) => x.order === ord);
      const e = magRowScfEnergy(r);
      if (e != null && e < bestE) {
        bestE = e;
        best = ord;
      }
    });
    return best == null ? null : { order: best, energy: bestE };
  }

  /** Verdict NM vs FM (+ suite AFM/NCL) si l’API ne renvoie pas nm_fm. */
  function computeLocalMagVerdict(data) {
    const rows = (data && data.orders) || [];
    const by = {};
    rows.forEach((r) => { by[r.order] = r; });
    const eNm = magRowScfEnergy(by.nm);
    const eFm = magRowScfEnergy(by.fm);
    if (eNm == null || eFm == null) return null;
    const dFmNm = eFm - eNm;
    if (dFmNm >= 0) {
      return {
        alert_level: "stop",
        alert: i18nT("mag.protocol.verdict.nm", {
          eNm: fmtEnergyEv(eNm),
          eFm: fmtEnergyEv(eFm),
          d: fmtDeltaEv(dFmNm),
        }),
        continue_afm: false,
        reference_order: "nm",
      };
    }
    const afmList = (data.available_afm && data.available_afm.length)
      ? data.available_afm
      : rows.filter((r) => String(r.order).startsWith("afm")).map((r) => r.order);
    const pool = ["fm", ...afmList, "ncl"];
    const low = pickLowestMagOrder(rows, pool);
    const ref = (data.reference_order && magRowScfEnergy(by[data.reference_order]) != null)
      ? data.reference_order
      : (low && low.order) || "fm";
    const eBest = low ? low.energy : eFm;
    const bestLab = ref === "nm" ? "NM" : sessionMagOrderShort(ref);
    const afmPending = afmList.some((ord) => !by[ord]?.scf_converged);
    const nclRow = by.ncl || {};
    const nclPending = !nclRow.scf_converged && !nclRow.from_main_scf;
    let alertKey = "mag.protocol.verdict.magnetic";
    if (afmPending) alertKey = "mag.protocol.verdict.need_afm";
    else if (nclPending && ref !== "ncl") alertKey = "mag.protocol.verdict.suggest_ncl";
    return {
      alert_level: "go",
      alert: i18nT(alertKey, {
        eNm: fmtEnergyEv(eNm),
        eFm: fmtEnergyEv(eFm),
        d: fmtDeltaEv(dFmNm),
        best: bestLab,
        eBest: fmtEnergyEv(eBest),
      }),
      continue_afm: true,
      reference_order: ref,
    };
  }

  function effectiveMagVerdict(data) {
    const apiV = (data && data.nm_fm) || {};
    if (apiV.alert && apiV.alert_level) return apiV;
    const local = computeLocalMagVerdict(data);
    if (local) return local;
    return apiV;
  }

  function paintMagProtocolPanel(data) {
    const card = $("res-mag-protocol-card");
    if (!card) return;
    const show = !!(sessionConfirmed && material);
    card.hidden = !show;
    if (!show) return;
    const stepsEl = $("mag-protocol-steps");
    if (stepsEl && window.qeI18n && window.qeI18n.apply) window.qeI18n.apply(stepsEl);
    const alertEl = $("mag-nm-fm-alert-results");
    const nextEl = $("mag-protocol-next");
    const bodyEl = $("mag-stability-body-results");
    if (!data || !(data.orders && data.orders.length)) {
      if (bodyEl) bodyEl.innerHTML = `<p class="meta">${i18nT("mag.stability.empty")}</p>`;
      if (alertEl) {
        alertEl.hidden = true;
        alertEl.textContent = "";
      }
      if (nextEl) nextEl.textContent = i18nT("mag.next.fm");
      return;
    }
    const verdict = effectiveMagVerdict(data);
    const wf = magWorkflowStep({ ...data, nm_fm: verdict });
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    if (alertEl) {
      const txt = lang === "en" ? (verdict.alert_en || verdict.alert) : (verdict.alert || "");
      alertEl.hidden = !txt;
      alertEl.innerHTML = txt || "";
      alertEl.className = `mag-nm-fm-alert ${verdict.alert_level || "wait"}`;
    }
    const nextKeys = {
      wait: "mag.next.wait",
      gen: "mag.next.gen",
      fm: "mag.next.fm",
      stop: "mag.next.stop",
      afm: "mag.next.afm",
      ncl: "mag.next.ncl",
      done_nm: "mag.next.done_nm",
      done_pick: "mag.next.done_pick",
    };
    if (nextEl) nextEl.textContent = i18nT(nextKeys[wf.key] || "mag.next.wait");
    if (bodyEl) {
      const enriched = { ...data, nm_fm: verdict, reference_order: data.reference_order || verdict.reference_order };
      bodyEl.innerHTML = magTableHtml(enriched);
    }
  }

  /** Lignes du tableau comparatif NM / FM / AFM / NCL (pas seulement les SCF déjà convergés). */
  function magOrderInCompareTable(r) {
    if (!r || !r.order) return false;
    if (r.order === "nm" || r.order === "fm" || r.order === "ncl") return true;
    if (String(r.order).startsWith("afm")) return true;
    return !!(r.scf_converged || r.from_main_scf || r.dos_at_ef != null || r.input_exists);
  }

  function magWorkflowStep(data) {
    const geo = (data && data.geometry) || {};
    const rows = (data && data.orders) || [];
    const by = {};
    rows.forEach((r) => { by[r.order] = r; });
    const fm = by.fm || {};
    const nm = by.nm || {};
    const ncl = by.ncl || {};
    const verdict = effectiveMagVerdict(data);
    const afmList = (data && data.available_afm && data.available_afm.length)
      ? data.available_afm
      : rows.filter((r) => String(r.order).startsWith("afm")).map((r) => r.order);
    const ready = magGeoUsable(geo);
    if (!ready) return { step: 0, key: "wait" };
    const nmScf = !!(nm.scf_converged || nm.from_main_scf);
    if (!nmScf) return { step: 0, key: "wait" };
    const fmPrepared = !!(fm.input_exists || (fm.steps && fm.steps["vc-relax"] && fm.steps["vc-relax"].input_exists));
    if (!fmPrepared) return { step: 1, key: "gen" };
    if (!fm.scf_converged && !fm.from_main_scf) return { step: 2, key: "fm" };
    if (verdict.alert_level === "stop") return { step: 4, key: "done_nm" };
    const afmPending = afmList.some((ord) => {
      const r = by[ord] || {};
      return !(r.scf_converged || r.from_main_scf);
    });
    if (afmPending) return { step: 3, key: "afm" };
    if (!(ncl.scf_converged || ncl.from_main_scf) && ncl.input_exists) return { step: 4, key: "ncl" };
    if (data.reference_order || verdict.reference_order) return { step: 5, key: "done_pick" };
    return { step: 3, key: "afm" };
  }

  function paintMagOrders(data, opts = {}) {
    const skipCaseRepaint = !!opts.skipCaseRepaint;
    const note = $("mag-orders-note");
    const resBody = $("mag-stability-body");
    const resNote = $("mag-stability-note");
    const toMag = $("btn-scf-to-mag");
    const phaseLine = $("mag-phase-line");
    const geo = (data && data.geometry) || {};
    const ready = magGeoUsable(geo);
    const canRun = !!sessionConfirmed && ready;
    const rows = (data && data.orders) || [];
    const afmList = data && data.available_afm && data.available_afm.length
      ? data.available_afm
      : ["afm-g"];
    const verdict = effectiveMagVerdict(data);
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    const wf = magWorkflowStep({ ...data, nm_fm: verdict });
    const ph = (data && data.phase_id) || phaseId || i18nT("phase.principal");
    if (phaseLine) {
      rememberStructure(data);
      const magCtx = magHeaderContext(data);
      if (magCtx) {
        phaseLine.textContent = i18nT("mag.phase.line.active", {
          material: material || "—",
          structure: phaseCrystalLabel(data) || "—",
          phase: ph,
          order: magCtx.order,
          nspin: String(magCtx.nspin),
        });
      } else {
        phaseLine.textContent = i18nT("mag.phase.line", {
          material: material || "—",
          structure: phaseCrystalLabel(data) || "—",
          phase: ph,
        });
      }
    }
    if (note) {
      const nextKeys = {
        wait: "mag.next.wait",
        gen: "mag.next.gen",
        fm: "mag.next.fm",
        stop: "mag.next.stop",
        afm: "mag.next.afm",
        ncl: "mag.next.ncl",
        done_nm: "mag.next.done_nm",
        done_pick: "mag.next.done_pick",
      };
      if (verdict.alert_level === "stop" || verdict.alert_level === "go") {
        note.textContent = (lang === "en" ? (verdict.alert_en || verdict.alert) : (verdict.alert || ""))
          + "  ·  " + i18nT(nextKeys[wf.key] || "mag.next.fm");
      } else {
        note.textContent = i18nT(nextKeys[wf.key] || "mag.next.wait");
      }
    }
    ["mag-nm-fm-alert", "mag-nm-fm-alert-results"].forEach((id) => {
      const el = $(id);
      if (!el) return;
      const txt = lang === "en" ? (verdict.alert_en || verdict.alert) : (verdict.alert || "");
      const level = verdict.alert_level || "wait";
      el.hidden = !txt;
      el.innerHTML = txt || "";
      el.className = `mag-nm-fm-alert ${level}`;
    });
    const cmpRows = rows.filter((r) => magOrderInCompareTable(r));
    const byOrd = {};
    rows.forEach((r) => { byOrd[r.order] = r; });
    const nmR = byOrd.nm || {};
    const fmR = byOrd.fm || {};
    let summary = "";
    const stHead = materialDisplay(data);
    if (stHead) summary += `<p class="mag-cmp-structure">${stHead}</p>`;
    if (nmR.energy_per_atom_ev != null && fmR.energy_per_atom_ev != null) {
      const dFmNm = Number(fmR.energy_per_atom_ev) - Number(nmR.energy_per_atom_ev);
      const winner = data.reference_order === "fm" ? "FM" : (data.reference_order === "nm" ? "NM" : (data.reference_order || "").toUpperCase());
      summary += `<p class="mag-cmp-summary">${winner ? winner + " ★  ·  " : ""}NM ${fmtEnergyEv(nmR.energy_per_atom_ev)} eV/at  ·  FM ${fmtEnergyEv(fmR.energy_per_atom_ev)} eV/at  ·  ΔE(FM−NM) = ${fmtDeltaEv(dFmNm)} eV/at</p>`;
    }
    const head = `<tr>
      <th>Ordre</th><th>Mailles</th><th>Spins</th><th>nspin</th>
      <th>E<sub>tot</sub> / u.c. (eV)</th><th>E<sub>tot</sub> / u.c. (Ry)</th>
      <th>E/atom (eV)</th><th>ΔE (eV/at)</th>
      <th>M<sub>tot</sub> / u.c.</th><th>M<sub>abs</sub> / u.c.</th>
      <th>E<sub>F</sub> (eV)</th><th>V / u.c. (Å<sup>3</sup>)</th>
      <th>N(E<sub>F</sub>) / u.c.</th><th>Gap (eV)</th><th>Type</th>
    </tr>`;
    const lines = cmpRows.map((r) => {
      const stable = data.reference_order && r.order === data.reference_order && (r.scf_converged || r.from_main_scf);
      let st = r.running ? "…" : r.scf_converged ? "✓" : r.output_exists ? "✗" : r.input_exists ? "in" : "—";
      if (r.order === "nm" && r.from_main_scf) st = "✓";
      const label = r.order === "nm" ? "NM" : (r.short || r.order);
      const err = r.error ? ` title="${String(r.spin_pattern || r.error || "").replace(/"/g, "&quot;")}"` : ` title="${String(r.spin_pattern || "").replace(/"/g, "&quot;")}"`;
      const dos = r.dos_at_ef != null ? Number(r.dos_at_ef).toFixed(3) : (r.nscf_running ? "…" : "—");
      const gap = (r.scf_converged || r.from_main_scf) ? fmtGapEv(r) : "—";
      const etypeRaw = lang === "en" ? (r.electronic_type_en || r.electronic_type) : (r.electronic_type || r.electronic_type_en);
      const etype = etypeRaw || (st === "✓" ? "—" : st);
      const etot = r.total_energy_ev != null ? Number(r.total_energy_ev).toFixed(4) : "—";
      const ery = r.total_energy_ry != null ? Number(r.total_energy_ry).toFixed(6) : "—";
      const ef = r.fermi_ev != null ? Number(r.fermi_ev).toFixed(4) : "—";
      const vol = r.volume_ang3 != null ? Number(r.volume_ang3).toFixed(3) : "—";
      const nCell = r.n_cells != null ? r.n_cells : 1;
      const cellLab = Number(nCell) > 1
        ? `${nCell} u.c. · ${r.supercell || "surmaille"}`
        : "1 u.c.";
      const spins = r.spin_arrows || (r.order === "nm" ? "·" : "—");
      return `<tr class="${stable ? "phase-row-stable" : ""}"${err}><td>${label}${stable ? " ★" : ""}</td><td>${cellLab}</td><td class="mag-spin-arrows">${spins}</td><td>${r.nspin}</td><td class="num-hi">${etot}</td><td class="num-hi">${ery}</td><td class="num-hi">${fmtEnergyEv(r.energy_per_atom_ev)}</td><td class="num-hi">${r.delta_ev_per_atom != null ? fmtDeltaEv(r.delta_ev_per_atom) : "—"}</td><td>${fmtMagNum(r.tot_mag, 4)}</td><td>${fmtMagNum(r.abs_mag, 4)}</td><td class="num-hi">${ef}</td><td class="num-hi">${vol}</td><td class="num-hi">${dos}</td><td class="num-hi">${gap}</td><td>${etype}</td></tr>`;
    });
    const table = cmpRows.length
      ? `${summary}<div class="mag-table-scroll"><table class="phase-table mag-cmp-table"><thead>${head}</thead><tbody>${lines.join("")}</tbody></table></div>`
      : `<p class="meta">${i18nT("mag.stability.empty")}</p>`;
    if (resBody) resBody.innerHTML = table;
    // L'onglet Résultats utilise magnetism_stable (phase ★), pas la phase UI active
    if (resNote && data && data.note) resNote.textContent = data.note;
    const magOpen = true;
    const prepBtn = $("btn-mag-prepare");
    if (prepBtn) prepBtn.disabled = !canRun;
    const magCard = $("mag-orders-card");
    if (magCard) magCard.classList.remove("is-locked");
    const nscfAllBtn = $("btn-mag-nscf-all");
    const nscfMagHint = $("mag-nscf-mag-hint");
    const pendingNscf = magOrdersPendingNscf(rows);
    if (nscfAllBtn) {
      const show = canRun && magOpen && pendingNscf.length > 0;
      nscfAllBtn.hidden = !show;
      nscfAllBtn.disabled = !show;
      const labels = pendingNscf.map(magOrderNscfLabel);
      nscfAllBtn.textContent = labels.length
        ? i18nT("mag.nscf.all.pending", { orders: labels.join(" / ") })
        : i18nT("mag.nscf.all.mag");
      nscfAllBtn.title = i18nT("mag.nscf.all.title.mag");
    }
    if (nscfMagHint) {
      nscfMagHint.hidden = !(canRun && magOpen);
      nscfMagHint.textContent = canRun && magOpen ? i18nT("mag.nscf.per_order.hint") : "";
    }
    const afmAllBtn = $("btn-mag-afm-all");
    if (afmAllBtn) {
      afmAllBtn.hidden = !(canRun && magOpen);
      afmAllBtn.disabled = !(canRun && magOpen);
    }
    paintMagAfmPicker(afmList, byOrd, rows, verdict, canRun && magOpen, wf);
    const cards = $("mag-case-cards");
    if (cards) {
      const by = {};
      rows.forEach((r) => { by[r.order] = r; });
      // NM prêt → pour chaque ordre : chaîne VC-RELAX → RELAX → SCF (géométrie propre)
      const open = canRun && magOpen;
      const cases = [
        { order: "fm", nspin: 2, runOk: open },
        ...afmList.map((ord) => ({ order: ord, nspin: 2, runOk: open })),
        { order: "ncl", nspin: 4, runOk: open },
      ];
      const caseKey = magCasePaintKey(data);
      const cardsEmpty = !cards.querySelector(".mag-case-row");
      const domOrderKey = [...cards.querySelectorAll(".mag-case-row[data-order]")]
        .map((el) => el.dataset.order)
        .join("\0");
      const wantOrderKey = cases.map((c) => c.order).join("\0");
      const cardsMismatch = domOrderKey !== wantOrderKey;
      const paintCases =
        cardsEmpty
        || cardsMismatch
        || (!skipCaseRepaint && caseKey !== lastMagCasePaintKey);
      if (paintCases) {
        ensureMagAfmPickerSibling(cards);
        cards.innerHTML = cases.map((c) => {
        const r = by[c.order] || { order: c.order };
        const short = (r.short || c.order).replace("afm-", "AFM-").toUpperCase();
        const steps = r.steps || {};
        const anyRun = !!(r.running || Object.values(steps).some((s) => s && s.running));
        const cr = r.chain_resume || {};
        const chainMeta = chainButtonMeta(cr, steps, CHAIN_KINDS_MAG);
        const startKind = chainMeta.startKind;
        const nextStep = (steps && steps[startKind]) || {};
        const stepInterrupted = !anyRun && chainMeta.interrupted;
        const eTxt = r.energy_per_atom_ev != null ? `E/at ${fmtEnergyEv(r.energy_per_atom_ev)} eV` : "";
        const mTxt = r.tot_mag != null ? `M ${fmtMagNum(r.tot_mag, 5)} µB` : "";
        const cellTxt = r.n_cells != null
          ? (Number(r.n_cells) > 1 ? `${r.n_cells} cellules (${r.supercell || "surmaille"})` : "1 u.c.")
          : "";
        const spinTxt = r.spin_arrows || "";
        const ordJob = orderJobId(r) || (cr.job_id ? String(cr.job_id) : "");
        const metaBits = [cellTxt, spinTxt ? `spins ${spinTxt}` : "", `nspin = ${c.nspin}`, eTxt, mTxt]
          .filter(Boolean).join(" · ");
        const chainTitle = chainMeta.title;
        const runDis = (c.runOk && !anyRun && !cr.all_done && !r.nscf_running) ? "" : "disabled";
        const editDis = canRun ? "" : "disabled";
        const conv = !anyRun && !!r.scf_converged;
        const nscfDis = (conv && !r.nscf_running) ? "" : "disabled";
        const liveCls = anyRun || r.nscf_running ? "running" : stepInterrupted ? "warn" : conv ? "ok" : "";
        const actRun = magOrderRunning(r);
        let banner = "";
        if (r.nscf_running) {
          banner = i18nT("phase.nscf.running");
        } else if (actRun) {
          banner = i18nT("mag.banner.running", {
            order: short,
            step: String(actRun.kind).toUpperCase(),
          });
        } else if (conv && cr.all_done && (r.needs_nscf || cr.needs_nscf) && !r.nscf_converged) {
          banner = i18nT("mag.banner.nscf_pending", { order: short });
        } else if (conv && cr.all_done && r.nscf_converged) {
          banner = i18nT("mag.banner.done", { order: short });
        } else if (conv && cr.all_done) {
          banner = i18nT("mag.banner.done", { order: short });
        } else if (stepInterrupted || cr.resume) {
          banner = chainTitle;
        } else if (r.input_exists || (steps["vc-relax"] && steps["vc-relax"].input_exists)) {
          banner = i18nT("mag.banner.ready", { order: short });
        } else {
          banner = i18nT("mag.banner.need_gen");
        }
        const failDetail = nextStep.error || r.error || "";
        const statusInner = failDetail
          ? `${esc(banner)} · <span class="mag-fail-detail">${esc(failDetail)}</span>`
          : esc(banner);
        const stopKind = r.nscf_running
          ? "nscf"
          : (Object.entries(steps).find(([, s]) => s && s.running)?.[0] || startKind || "vc-relax");
        const stopBtn = (anyRun || r.nscf_running)
          ? `<button class="btn ghost btn-mag-stop" type="button" data-order="${c.order}" data-kind="${stopKind}">${i18nT("btn.stop")}</button>`
          : "";
        const nscfBtn = (conv || r.nscf_running)
          ? `<button class="btn ghost btn-mag-nscf" type="button" data-order="${c.order}" ${nscfDis}>${i18nT("mag.nscf.run")}</button>`
          : "";
        const spinLine = r.spin_pattern
          ? `<p class="mag-spin-line">${esc(r.spin_pattern)}</p>`
          : "";
        const spinFig = magSpinOrientationBlock(c.order, r);
        let jobLine = "";
        if (ordJob) {
          const isActive = jobId && ordJob === jobId;
          const useBtn = (!isActive && canRun)
            ? ` <button type="button" class="btn ghost btn-mag-use-job" data-order="${escAttr(c.order)}" data-job-id="${escAttr(ordJob)}">${esc(i18nT("mag.case.job.use"))}</button>`
            : "";
          const activeNote = isActive ? ` · ${esc(i18nT("mag.case.job.active"))}` : "";
          jobLine = `<p class="mag-case-job">${esc(i18nT("mag.case.job", { job: ordJob }))}${activeNote}${useBtn}</p>`;
        } else {
          jobLine = `<p class="mag-case-job meta">${esc(i18nT("mag.case.job.none"))}</p>`;
        }
        return `<article class="mag-case-row${conv ? " is-converged" : ""}${anyRun || r.nscf_running ? " is-running" : ""}${stepInterrupted ? " is-interrupted" : ""}" data-order="${c.order}" data-job-id="${escAttr(ordJob)}">
          <div class="mag-calc-spin-top">${spinFig}</div>
          <div class="calc-row">
            <div class="calc-row-label">
              <strong class="mag-case-name">${short}</strong>
              <span class="meta">${metaBits}</span>
              ${spinLine}
              ${jobLine}
            </div>
            <div class="calc-row-actions">
              <button class="btn btn-mag-run${chainMeta.retry ? " btn-chain-retry" : ""}" type="button" data-order="${c.order}" data-kind="${escAttr(startKind || "vc-relax")}" data-job-id="${escAttr(ordJob)}" ${runDis} title="${escAttr(chainTitle)}">${esc(chainMeta.label)}</button>
              ${nscfBtn}
              ${stopBtn}
            </div>
          </div>
          ${buildMagPipelineOlHtml({ ...r, order: c.order }, editDis, !anyRun && chainMeta.retry ? startKind : "")}
          ${!anyRun && chainMeta.retry && stepNeedsFix(nextStep)
            ? chainFixPanelHtml({ ...nextStep, kind: startKind }, { kind: startKind, order: c.order })
            : ""}
          <p class="mag-chain-banner ${liveCls}" id="status-mag-${c.order}">${statusInner}</p>
          <p class="meta card-track-kicker">${esc(i18nT("runs.track.live"))}</p>
          <div class="card-track" id="track-mag-${c.order}" data-kind="mag" aria-live="polite">
            <div class="track-live" hidden></div>
            <div class="track-history"></div>
          </div>
        </article>`;
      }).join("");
        lastMagCasePaintKey = caseKey;
        placeMagAfmPickerAfterFm();
        // Suivi live immédiat (sans attendre le poll) pour tout ordre en cours.
        cases.forEach((c) => seedMagLiveTrack(by[c.order] || { order: c.order }));
      } else if (rows.some((r) => r.order !== "nm" && (magOrderRunning(r) || r.nscf_running))) {
        rows.forEach((r) => {
          if (r.order === "nm") return;
          if (!magOrderRunning(r) && !r.nscf_running) return;
          clearMagCaseChainFix(r.order);
          syncMagPipeLiveFromRow(r);
          const act = magOrderRunning(r);
          const short = (r.short || r.order).replace("afm-", "AFM-").toUpperCase();
          const stEl = $(`status-mag-${r.order}`);
          if (stEl && act) {
            const stepData = (r.steps && r.steps[act.kind]) || {};
            const metricsLine = liveMetricsLabel({ ...stepData, kind: act.kind, running: true }, act.kind);
            const banner = i18nT("mag.banner.running", {
              order: short,
              step: String(act.kind).toUpperCase(),
            });
            const line = [banner, metricsLine].filter(Boolean).join(" · ");
            stEl.innerHTML = formatLiveBannerHtml(line, { ...stepData, running: true, kind: act.kind });
            stEl.className = "mag-chain-banner running";
          } else if (stEl && r.nscf_running) {
            stEl.textContent = i18nT("phase.nscf.running");
            stEl.className = "mag-chain-banner running";
          }
          if (!optimPollTimer) seedMagLiveTrack(r);
        });
        paintMagJobBanner();
      }
    }
    if (toMag) {
      toMag.hidden = !sessionConfirmed || !(geo.after_nm_scf || geo.scf_converged);
    }
    paintMagProtocolPanel(data);
    if (PHASES_ONLY) {
      paintPhasesCalculsChainPanel();
      paintSessionMagSpinGallery();
    }
  }

  function magOrdersQuery(opts = {}) {
    const pid = activePhaseId();
    let q = phaseQueryFor(pid);
    const parts = [];
    if (opts.autoPrepare) parts.push("auto_prepare=1");
    if (opts.light) parts.push("light=1");
    if (parts.length) {
      q += (q ? "&" : "?") + parts.join("&");
    }
    return q;
  }

  async function refreshMagOrders(opts = {}) {
    const mat = (opts.material || studyJobMaterial() || "").trim();
    if (!mat) {
      lastMagCasePaintKey = "";
      paintMagOrders(null);
      return null;
    }
    if (magOrdersBusy) return lastMagOrders;
    magOrdersBusy = true;
    let data;
    try {
      data = await api(
        `/api/materials/${encodeURIComponent(mat)}/mag-orders${magOrdersQuery(opts)}`
      );
    } finally {
      magOrdersBusy = false;
    }
    if (data.auto_prepare_message) {
      sessionMagPrepareBannerText = String(data.auto_prepare_message);
      if (data.auto_prepared) log("log-opt", data.auto_prepare_message, true);
    }
    rememberStructure(data);
    paintSessionStatus();
    lastMagOrders = data;
    paintSessionMagPrepareBanner(data);
    paintMagOrders(data, {
      ...opts,
      skipCaseRepaint: opts.forceCaseRepaint
        ? false
        : ((!!opts.skipCaseRepaint || !!optimPollTimer) && currentTab() !== "magnetisme"),
    });
    paintSessionBar();
    paintMagJobBanner();
    startMagRunningPolls(data);
    if (!opts.skipExtras && !optimPollTimer) {
      const running = ((data && data.orders) || []).some((r) => r.running || r.nscf_running);
      if (running) {
        await refreshRuns().catch(() => {});
        if (Date.now() - jobsBoardTs > 20000) {
          jobsBoardTs = Date.now();
          refreshJobsBoard().catch(() => {});
        }
      }
    }
    return data;
  }

  async function prepareMagOrders(orders, opts = {}) {
    const mat = String(opts.material || studyJobMaterial() || material || "").trim();
    if (!mat) return null;
    if (!opts.silent && !opts.allowBeforeConfirm && !requireSessionConfirmed()) return null;
    const body = withPhaseBody({});
    if (opts.phase_id) body.phase_id = String(opts.phase_id).trim();
    const jobMat =
      sessionStudyIntent() === "doping" ? getPhaseDopingJobMaterial() || mat : mat;
    if (jobMat && /_doped$/i.test(jobMat)) body.material = jobMat;
    if (orders && orders.length) body.orders = orders.map((o) => String(o).trim().toLowerCase());
    const data = await api(`/api/materials/${encodeURIComponent(mat)}/mag-orders/prepare`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (opts.silent && !data.ok) return data;
    log("log-opt", data, !!data.ok);
    if (!data.ok) {
      if (!opts.silent) window.alert(data.error || i18nT("mag.prepare.fail"));
      return data;
    }
    if (data.message) {
      sessionMagPrepareBannerText = String(data.message);
      paintSessionMagPrepareBanner(data);
    }
    if (!opts.silent) {
      const names = (data.prepared || []).map((p) => {
        const short = (p.short || p.order || "").toUpperCase();
        const ns = p.nspin != null ? p.nspin : "";
        return `  ${short}  nspin=${ns}  ${p.rel || p.path || ""}`;
      });
      const ph = data.phase_id || phaseId || "—";
      log(
        "log-opt",
        i18nT("mag.prepare.done", { phase: ph, n: String((data.prepared || []).length) })
          + (names.length ? "\n" + names.join("\n") : "")
          + "\n"
          + i18nT("mag.next.fm"),
        true
      );
    }
    await refreshMagOrders({ forceCaseRepaint: true }).catch(() => {});
    if (data.ok) {
      try {
        const regMat =
          sessionStudyIntent() === "doping" && getPhaseDopingJobMaterial()
            ? getPhaseDopingJobMaterial()
            : mat;
        const regBody = {};
        if (opts.phase_id) regBody.phase_id = String(opts.phase_id).trim();
        else if (body.phase_id) regBody.phase_id = body.phase_id;
        const reg = await api(
          `/api/materials/${encodeURIComponent(regMat)}/mag-orders/regenerate-local`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(regBody),
          }
        );
        if (reg && reg.audit_ok === false) {
          log("log-opt", i18nT("mag.audit.some_fail"), false);
        } else if (reg && reg.ok) {
          log("log-opt", i18nT("mag.regenerate.local_ok", { mat }), true);
        }
        await refreshMagOrders({ forceCaseRepaint: true }).catch(() => {});
      } catch (_) {
        /* upstream prepare seul */
      }
    }
    if (PHASES_ONLY && data.ok && orders && orders.length) {
      const allAud = await fetchAllMagOrdersAudit(orders).catch(() => null);
      if (allAud && !allAud.ok) {
        log("log-opt", i18nT("mag.audit.some_fail"), false);
      }
      const active = getSessionMagOrder();
      if (active && active !== "nm") await refreshMagOrderInputAudit(active).catch(() => {});
    }
    return data;
  }

  function clearMagCaseChainFix(order) {
    const row = document.querySelector(`.mag-case-row[data-order="${order}"]`);
    if (!row) return;
    row.querySelectorAll(".chain-fix-panel").forEach((el) => el.remove());
    row.querySelectorAll(".mag-pipe-step.is-fail, .mag-pipe-step.is-focus").forEach((el) => {
      el.classList.remove("is-fail", "is-focus");
    });
    row.classList.remove("is-interrupted");
    const runBtn = row.querySelector(".btn-mag-run");
    if (runBtn) runBtn.classList.remove("btn-chain-retry");
  }

  /** Alimente immédiatement le panneau « Suivi en direct » d'un ordre mag
   *  depuis les métriques déjà présentes dans r.steps (itérations, %, temps),
   *  sans attendre le premier tick du poll. */
  function seedMagLiveTrack(r) {
    if (!r || r.order === "nm") return;
    const act = magOrderRunning(r);
    if (!act) return;
    const stepData = (r.steps && r.steps[act.kind]) || {};
    const live = {
      ...stepData,
      kind: act.kind,
      running: true,
      label: stepData.run_label || i18nT("state.running"),
      progress: stepData.run_progress || stepData.progress,
      job_id: act.job || stepData.job_id || r.job_id,
    };
    paintLiveOnTrack(`track-mag-${r.order}`, live, { kind: act.kind, magOrder: r.order });
  }

  function paintMagStepRunning(order, step) {
    const stepUp = String(step || "vc-relax").toUpperCase();
    const stEl = $(`status-mag-${order}`);
    const row = document.querySelector(`.mag-case-row[data-order="${order}"]`);
    clearMagCaseChainFix(order);
    if (stEl) {
      stEl.className = "mag-chain-banner running";
      stEl.innerHTML = `<strong>${esc(i18nT("mag.step.running", { step: stepUp }))}</strong>`;
    }
    if (row) {
      row.classList.add("is-running");
      row.classList.remove("is-converged", "is-interrupted");
    }
    paintLiveOnTrack(
      `track-mag-${order}`,
      {
        running: true,
        finished: false,
        label: i18nT("mag.step.running", { step: stepUp }),
        progress: i18nT("state.running"),
        kind: step,
      },
      { kind: step, magOrder: order }
    );
    const banner = $("mag-job-banner");
    if (banner && order === "fm") {
      banner.hidden = false;
      banner.className = "mag-job-banner meta is-running";
      banner.textContent = i18nT("mag.job.banner", {
        job: jobId || i18nT("label.job.none"),
        order: "FM",
        state: i18nT("mag.job.state.running", { step: stepUp }),
      });
    }
  }

  async function activateOrderJob(order, explicitJobId) {
    const rows = (lastMagOrders && lastMagOrders.orders) || [];
    const row = rows.find((r) => r.order === order) || null;
    const jid = explicitJobId || orderJobId(row);
    if (!jid) return "";
    if (jid !== jobId) {
      const sel = $("job-select");
      if (sel) {
        if (![...sel.options].some((o) => o.value === jid)) {
          const opt = document.createElement("option");
          opt.value = jid;
          opt.textContent = jid;
          sel.appendChild(opt);
        }
        sel.value = jid;
      }
      setJob(jid);
      paintJobPanel();
      log("log-opt", i18nT("job.applied", { job: jid }), true);
    }
    return jid;
  }

  async function runMagOrder(order, kind, opts = {}) {
    if (PHASES_PREP_ONLY) return;
    if (!requireSessionConfirmed()) return;
    const step = kind || "vc-relax";
    // Reprise FM/AFM : rattacher le job de cet ordre avant le lancement
    await activateOrderJob(order).catch(() => {});
    paintMagStepRunning(order, step);
    const body = withPhaseBody({
      kind: step,
      chain: step === "nscf" ? "off" : "server",
    });
    if (opts.waitForSlot) body.wait_for_slot = true;
    if (jobId) body.job_id = jobId;
    const data = await api(
      `/api/materials/${encodeURIComponent(material)}/mag-orders/run/${encodeURIComponent(order)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      }
    );
    log("log-opt", data.message || data.conv_adjust?.message || data, !!data.ok);
    if (!data.ok) {
      window.alert(data.error || i18nT("mag.run.fail"));
      const row = document.querySelector(`.mag-case-row[data-order="${order}"]`);
      if (row) {
        row.classList.remove("is-running");
        row.classList.add("is-interrupted");
      }
      const stEl = $(`status-mag-${order}`);
      if (stEl) {
        stEl.className = "mag-chain-banner warn";
        stEl.textContent = data.error || i18nT("mag.run.fail");
      }
      paintLiveOnTrack(`track-mag-${order}`, null, { kind: step, magOrder: order });
      document.querySelectorAll(".btn-mag-run").forEach((b) => { b.disabled = false; });
      await refreshMagOrders({ light: false }).catch(() => {});
      return;
    }
    if (data.conv_adjust && data.conv_adjust.exhausted && !data.conv_adjust.applied) {
      window.alert(data.conv_adjust.message || i18nT("chain.fix.exhausted"));
    }
    if (data.job_id) setJob(data.job_id);
    paintMagStepRunning(order, data.started_kind || step);
    const pollKind = data.started_kind || step;
    const pollJob = data.job_id || jobId;
    startOptimPoll(material, pollKind, pollJob, order);
    try {
      const { live, pollKind: pk } = await fetchRunLive(
        material,
        pollKind,
        pollJob,
        order,
        activePhaseId()
      );
      paintLiveOnTrack(`track-mag-${order}`, live, { kind: pk, magOrder: order });
      updateMagPipeLiveMetrics(order, pk, live);
    } catch (_) {
      /* poll reprendra au tick suivant */
    }
    jobsBoardTs = 0;
    refreshJobsBoard().catch(() => {});
    await refreshRuns().catch(() => {});
    window.setTimeout(() => refreshMagOrders({ skipCaseRepaint: true }).catch(() => {}), 800);
    const st = lastMagOrders;
    const v = (st && st.nm_fm) || data.nm_fm || {};
    if (order === "fm" && (v.alert_level === "stop" || v.alert_level === "go") && v.alert) {
      window.alert(v.alert);
    }
  }

  function readMagAfmPickSelection() {
    const sel = new Set();
    document.querySelectorAll("#mag-afm-picker input.mag-afm-pick:checked").forEach((el) => {
      if (el.value) sel.add(el.value);
    });
    return sel;
  }

  function updateMagAfmSelectedBtn() {
    const btn = $("btn-mag-afm-selected");
    if (!btn) return;
    const n = document.querySelectorAll("#mag-afm-picker input.mag-afm-pick:checked:not(:disabled)").length;
    btn.disabled = n === 0;
  }

  /** Remet le picker à côté de la liste — évite de le détruire lors d’un `cards.innerHTML`. */
  function ensureMagAfmPickerSibling(cards) {
    const parent = cards && cards.parentNode;
    if (!parent) return $("mag-afm-picker");
    let picker = $("mag-afm-picker");
    if (!picker) {
      picker = document.createElement("div");
      picker.id = "mag-afm-picker";
      picker.className = "mag-afm-picker";
      picker.hidden = true;
      parent.insertBefore(picker, cards.nextSibling);
      return picker;
    }
    if (cards.contains(picker)) {
      parent.insertBefore(picker, cards.nextSibling);
    }
    return picker;
  }

  function placeMagAfmPickerAfterFm() {
    const picker = $("mag-afm-picker");
    const cards = $("mag-case-cards");
    if (!picker || !cards || picker.hidden) return;
    const fm = cards.querySelector('.mag-case-row[data-order="fm"]');
    if (!fm || fm.nextElementSibling === picker) return;
    fm.insertAdjacentElement("afterend", picker);
  }

  function paintMagAfmPicker(afmList, byOrd, rows, verdict, show, wf) {
    const picker = $("mag-afm-picker");
    if (!picker) return;
    const wfStep = wf && typeof wf.step === "number" ? wf.step : 0;
    const showPicker = show && afmList && afmList.length && wfStep >= 2;
    if (!showPicker) {
      picker.hidden = true;
      picker.innerHTML = "";
      return;
    }
    const prevPick = readMagAfmPickSelection();
    const hadPick = prevPick.size > 0;
    const defaultsGo = verdict.continue_afm === true || verdict.alert_level === "go";
    const items = afmList.map((ord) => {
      const r = byOrd[ord] || {};
      const lab = String(r.short || ord).replace(/^afm-/i, "AFM-").toUpperCase();
      const running = !!r.running;
      const done = !!r.scf_converged;
      const dis = running ? " disabled" : "";
      const checked = (hadPick ? prevPick.has(ord) : (defaultsGo && !done && !running)) ? " checked" : "";
      const cls = `mag-afm-pick-item${done ? " is-done" : ""}${running ? " is-running" : ""}`;
      const suffix = done ? ` (${esc(i18nT("state.converged"))})` : (running ? ` (${esc(i18nT("state.running"))})` : "");
      return `<label class="${cls}"><input type="checkbox" class="mag-afm-pick" value="${escAttr(ord)}"${dis}${checked} /> ${esc(lab)}${suffix}</label>`;
    }).join("");
    picker.hidden = false;
    picker.innerHTML =
      `<div class="mag-afm-picker-head">` +
      `<strong id="mag-afm-picker-title">${esc(i18nT("mag.afm.pick.title"))}</strong>` +
      `<div class="mag-afm-picker-actions">` +
      `<button type="button" class="btn ghost btn-mag-afm-sel-all">${esc(i18nT("mag.afm.select_all"))}</button>` +
      `<button type="button" class="btn ghost btn-mag-afm-sel-none">${esc(i18nT("mag.afm.select_none"))}</button>` +
      `</div></div>` +
      `<div class="mag-afm-pick-grid">${items}</div>` +
      `<p class="meta mag-afm-picker-hint">${esc(i18nT("mag.afm.pick.hint"))}</p>` +
      `<button type="button" class="btn btn-mag-afm-selected" id="btn-mag-afm-selected">${esc(i18nT("mag.run.afm_selected"))}</button>`;
    updateMagAfmSelectedBtn();
    placeMagAfmPickerAfterFm();
  }

  async function runMagBatch(includeFm, orders) {
    if (!requireSessionConfirmed()) return;
    const body = withPhaseBody({ include_fm: !!includeFm });
    if (orders && orders.length) body.orders = orders;
    if (jobId) body.job_id = jobId;
    const data = await api(
      `/api/materials/${encodeURIComponent(material)}/mag-orders/run-batch`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      }
    );
    log("log-opt", data.message || i18nT("mag.batch.started", { orders: (data.queued || []).join(", ") }), !!data.ok);
    if (data.job_id) setJob(data.job_id);
    await refreshMagOrders().catch(() => {});
    await refreshRuns().catch(() => {});
    const v = data.nm_fm || {};
    if (!data.ok && v.alert) window.alert(v.alert);
    if (!data.ok && data.error) alert(data.error);
  }

  async function runSelectedAfmBatch() {
    const orders = [...document.querySelectorAll("#mag-afm-picker input.mag-afm-pick:checked:not(:disabled)")]
      .map((el) => el.value)
      .filter(Boolean);
    if (!orders.length) {
      alert(i18nT("mag.afm.pick_one"));
      return;
    }
    await runMagBatch(false, orders);
  }

  async function switchToMagneticScf() {
    if (!requireSessionConfirmed()) return;
    const st = lastStudy || await refreshStudyGuide().catch(() => null);
    // Phase inconnue / ★ pas activée → Phases d’abord ; phase connue → Magnétisme.
    if (st && st.next_tab === "phases" && st.mode === "search_phase") {
      if (PHASES_ONLY) loadTabData("phases");
      else goPhasesApp();
      return;
    }
    switchTab("magnetisme");
    await refreshMagOrders().catch(() => {});
    $("mag-orders-card")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  async function refreshPhaseStability(materialOverride) {
    const m = (materialOverride || material || "").trim();
    if (!m) {
      paintPhaseStability(null);
      return null;
    }
    if (sessionStudyIntent() === "doping" || /_doped$/i.test(m)) {
      await repairDopedJobLayout(m);
    }
    const data = await api(`/api/materials/${encodeURIComponent(m)}/phase-stability`);
    paintPhaseStability(data);
    if (m === material) await refreshNscfElectronicSummary().catch(() => {});
    return data;
  }

  async function refreshNscfElectronicSummary() {
    const el = $("nscf-electronic-summary");
    if (!el || !material) {
      if (el) el.textContent = "";
      return;
    }
    const st = await api(`/api/materials/${encodeURIComponent(material)}/nscf/status${phaseQuery()}`);
    if (st.running) {
      el.textContent = i18nT("phase.nscf.running");
      if (sessionConfirmed && !optimPollTimer) {
        startOptimPoll(material, "nscf", st.job_id || jobId);
      }
      if (lastOptimSteps && nmActiveStep(lastOptimSteps)) {
        paintNmLiveFromSteps(lastOptimSteps);
      } else {
        paintLiveOnTrack(
          "track-nm-chain",
          { ...st, kind: "nscf", running: true, progress: st.progress || st.run_progress },
          { kind: "nscf" }
        );
      }
      return;
    }
    if (lastOptimSteps && nmActiveStep(lastOptimSteps)) {
      paintNmLiveFromSteps(lastOptimSteps);
      return;
    }
    if (!optimPollTimer) paintLiveOnTrack("track-nm-chain", null);
    const e = st.electronic;
    if (e && e.dos_at_ef != null) {
      el.innerHTML = i18nT("phase.nscf.summary", {
        dos: e.dos_at_ef,
        gap: fmtGapEv(e),
        type: e.electronic_type || e.electronic_type_en || "—",
      });
    } else if (st.needs_scf) {
      el.textContent = i18nT("phase.nscf.need_scf");
    } else {
      el.textContent = "";
    }
  }

  function formatElasticValue(v) {
    if (v == null || Number.isNaN(Number(v))) return "—";
    return Number(v).toFixed(4);
  }

  function postscfStepLabel(st) {
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    return lang === "en" ? (st.label_en || st.label_fr) : (st.label_fr || st.label_en);
  }

  function paintPostscfPipeline(postscf) {
    const pipe = $("postscf-pipeline-steps");
    const summary = $("postscf-summary");
    if (!pipe) return;
    const steps = (postscf && postscf.steps) || [];
    if (!steps.length) {
      pipe.innerHTML = "";
      if (summary) summary.textContent = "";
      return;
    }
    pipe.innerHTML = steps.map((st, i) => {
      let cls = "idle";
      let lab = i18nT("proprietes.step.todo");
      if (st.done) { cls = "ok"; lab = i18nT("proprietes.step.done"); }
      else if (st.running) { cls = "run"; lab = i18nT("proprietes.step.run"); }
      const prog = st.running && st.progress ? ` · ${esc(st.progress)}` : "";
      const arrow = i < steps.length - 1 ? `<li class="mag-pipe-arrow" aria-hidden="true">→</li>` : "";
      return `<li class="mag-pipe-step is-${cls}" data-step="${escAttr(st.id || "")}">
        <div class="mag-pipe-head"><span class="mag-pipe-num">${i + 1}</span><strong class="mag-pipe-label">${esc(postscfStepLabel(st))}</strong></div>
        <span class="mag-pipe-state">${esc(lab)}${prog}</span>
      </li>${arrow}`;
    }).join("");
    if (summary && postscf && postscf.nscf && postscf.nscf.running) {
      summary.textContent = postscf.nscf.progress || i18nT("phase.nscf.running");
    } else if (summary) summary.textContent = "";
  }

  function _chartPad() {
    return { l: 52, r: 14, t: 18, b: 36 };
  }

  function _chartPadBands() {
    return { l: 56, r: 18, t: 22, b: 48 };
  }

  function formatKpathLabel(s) {
    return String(s ?? "")
      .replace(/Gamma/gi, "Γ")
      .replace(/(^|[,\-→])G(?=[,\-→]|$)/g, "$1Γ");
  }

  function _energyTicks(eMin, eMax, count = 5) {
    const out = [];
    if (!Number.isFinite(eMin) || !Number.isFinite(eMax) || eMin === eMax) return out;
    for (let i = 0; i <= count; i += 1) {
      out.push(eMin + (i / count) * (eMax - eMin));
    }
    return out;
  }

  function _mapRange(v, d0, d1, r0, r1) {
    if (d1 === d0) return (r0 + r1) / 2;
    return r0 + ((v - d0) / (d1 - d0)) * (r1 - r0);
  }

  function svgDosPlot(dosPlot) {
    if (!dosPlot || !dosPlot.energy_ev || !dosPlot.energy_ev.length) return "";
    const W = 520;
    const H = 260;
    const pad = _chartPad();
    const xs = dosPlot.energy_ev.map(Number);
    const ys = dosPlot.dos.map(Number);
    const x0 = Math.min(...xs);
    const x1 = Math.max(...xs);
    const y1 = Math.max(...ys, 1e-6);
    const pw = W - pad.l - pad.r;
    const ph = H - pad.t - pad.b;
    const px = (x) => _mapRange(x, x0, x1, pad.l, pad.l + pw);
    const py = (y) => _mapRange(y, 0, y1, pad.t + ph, pad.t);
    let path = `M ${px(xs[0])} ${py(ys[0])}`;
    for (let i = 1; i < xs.length; i += 1) path += ` L ${px(xs[i])} ${py(ys[i])}`;
    const efX = px(Number(dosPlot.ef_ev || 0));
    const xLab = i18nT("proprietes.chart.dos_x");
    const yLab = dosPlot.units || "DOS";
    return `<svg viewBox="0 0 ${W} ${H}" class="chart-svg" role="img" aria-label="${esc(i18nT("proprietes.chart.dos"))}">
      <line class="ch-axis" x1="${pad.l}" y1="${pad.t + ph}" x2="${pad.l + pw}" y2="${pad.t + ph}"/>
      <line class="ch-axis" x1="${pad.l}" y1="${pad.t}" x2="${pad.l}" y2="${pad.t + ph}"/>
      <line class="ch-ef" x1="${efX}" y1="${pad.t}" x2="${efX}" y2="${pad.t + ph}"/>
      <path class="ch-fill" d="${path} L ${px(xs[xs.length - 1])} ${py(0)} L ${px(xs[0])} ${py(0)} Z"/>
      <path class="ch-line" d="${path}"/>
      <text class="ch-lab ch-lab-axis" x="${pad.l + pw / 2}" y="${H - 8}" text-anchor="middle">${esc(xLab)}</text>
      <text class="ch-lab ch-lab-axis" x="12" y="${pad.t + ph / 2}" text-anchor="middle" transform="rotate(-90 12 ${pad.t + ph / 2})">${esc(yLab)}</text>
    </svg>`;
  }

  function svgBandsPlot(bPlot, lang) {
    if (!bPlot || !bPlot.bands_up_ev || !bPlot.bands_up_ev.length) return "";
    const lg = lang || (window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr");
    const symPath = bPlot.mode === "high_symmetry";
    const W = 640;
    const H = symPath ? 340 : 300;
    const pad = _chartPadBands();
    const rows = bPlot.bands_up_ev;
    const nks = rows.length;
    const nbnd = rows[0].length;
    let eMin = Number(bPlot.e_min_ev);
    let eMax = Number(bPlot.e_max_ev);
    rows.forEach((row) => row.forEach((e) => {
      eMin = Math.min(eMin, Number(e));
      eMax = Math.max(eMax, Number(e));
    }));
    (bPlot.bands_down_ev || []).forEach((row) => row.forEach((e) => {
      eMin = Math.min(eMin, Number(e));
      eMax = Math.max(eMax, Number(e));
    }));
    eMin -= 0.25;
    eMax += 0.25;
    const xs = bPlot.x && bPlot.x.length === nks ? bPlot.x.map(Number) : rows.map((_, i) => i);
    const x0 = Math.min(...xs);
    const x1 = Math.max(...xs);
    const pw = W - pad.l - pad.r;
    const ph = H - pad.t - pad.b;
    const px = (x) => _mapRange(x, x0, x1, pad.l, pad.l + pw);
    const py = (e) => _mapRange(e, eMin, eMax, pad.t + ph, pad.t);
    const eGrid = _energyTicks(eMin, eMax, symPath ? 6 : 4);
    const yGrid = eGrid.map((e) => {
      const y = py(e);
      return `<line class="ch-grid" x1="${pad.l}" y1="${y}" x2="${pad.l + pw}" y2="${y}"/>
        <text class="ch-lab ch-lab-ytick" x="${pad.l - 6}" y="${y + 3}" text-anchor="end">${esc(Number(e).toFixed(1))}</text>`;
    }).join("");
    const lines = [];
    for (let b = 0; b < nbnd; b += 1) {
      let d = `M ${px(xs[0])} ${py(rows[0][b])}`;
      for (let k = 1; k < nks; k += 1) d += ` L ${px(xs[k])} ${py(rows[k][b])}`;
      const lineCls = symPath ? "ch-line ch-line-bands" : "ch-line ch-line-mesh";
      lines.push(`<path class="${lineCls}" d="${d}"/>`);
    }
    (bPlot.bands_down_ev || []).forEach((row) => {
      if (row.length !== nks) return;
      let d = `M ${px(xs[0])} ${py(row[0])}`;
      for (let k = 1; k < nks; k += 1) d += ` L ${px(xs[k])} ${py(row[k])}`;
      const dnCls = symPath ? "ch-line ch-line-bands ch-line-down" : "ch-line ch-line-mesh ch-line-down";
      lines.push(`<path class="${dnCls}" d="${d}"/>`);
    });
    const seenTickX = new Set();
    const tickList = (bPlot.ticks || []).slice().sort((a, b) => Number(a.x) - Number(b.x));
    const ticks = tickList.map((t) => {
      const tx = px(Number(t.x));
      const key = tx.toFixed(1);
      if (seenTickX.has(key)) return "";
      seenTickX.add(key);
      const lab = formatKpathLabel(t.label || "");
      const tickCls = symPath ? "ch-tick ch-tick-sym" : "ch-tick";
      return `<line class="${tickCls}" x1="${tx}" y1="${pad.t}" x2="${tx}" y2="${pad.t + ph}"/>
        <text class="ch-lab ch-lab-kpoint" x="${tx}" y="${H - 14}" text-anchor="middle">${esc(lab)}</text>`;
    }).join("");
    const efY = py(0);
    const xLab = symPath
      ? i18nT("proprietes.chart.bands_x_sym")
      : i18nT("proprietes.chart.bands_x_mesh");
    const hint = lg === "en" ? (bPlot.hint_en || "") : (bPlot.hint_fr || "");
    const pathRaw = bPlot.path_label || "";
    const pathLab = pathRaw
      ? `<p class="bands-path-label">${esc(formatKpathLabel(pathRaw))}</p>`
      : "";
    return `${pathLab}<p class="meta bands-chart-hint">${esc(hint)}</p>
    <svg viewBox="0 0 ${W} ${H}" class="chart-svg chart-svg-bands${symPath ? " is-high-sym" : " is-k-mesh"}" role="img" aria-label="${esc(i18nT("proprietes.chart.bands"))}">
      <rect class="ch-plot-bg" x="${pad.l}" y="${pad.t}" width="${pw}" height="${ph}" rx="2"/>
      ${yGrid}
      <line class="ch-axis" x1="${pad.l}" y1="${pad.t + ph}" x2="${pad.l + pw}" y2="${pad.t + ph}"/>
      <line class="ch-axis" x1="${pad.l}" y1="${pad.t}" x2="${pad.l}" y2="${pad.t + ph}"/>
      <line class="ch-ef" x1="${pad.l}" y1="${efY}" x2="${pad.l + pw}" y2="${efY}"/>
      ${ticks}
      ${lines.join("")}
      <text class="ch-lab ch-lab-axis" x="${pad.l + pw / 2}" y="${H - 4}" text-anchor="middle">${esc(xLab)}</text>
      <text class="ch-lab ch-lab-axis" x="16" y="${pad.t + ph / 2}" text-anchor="middle" transform="rotate(-90 16 ${pad.t + ph / 2})">E − E_F (eV)</text>
    </svg>`;
  }

  function svgOpticalSeries(spec, key, title, color) {
    if (!spec || !spec.omega_ev || !spec[key] || spec.omega_ev.length !== spec[key].length) return "";
    const W = 480;
    const H = 200;
    const pad = _chartPad();
    const xs = spec.omega_ev.map(Number);
    const ys = spec[key].map(Number);
    const x0 = Math.min(...xs);
    const x1 = Math.max(...xs);
    let y0 = Math.min(...ys);
    let y1 = Math.max(...ys);
    if (y0 === y1) { y0 -= 1; y1 += 1; }
    const pw = W - pad.l - pad.r;
    const ph = H - pad.t - pad.b;
    const px = (x) => _mapRange(x, x0, x1, pad.l, pad.l + pw);
    const py = (y) => _mapRange(y, y0, y1, pad.t + ph, pad.t);
    let d = `M ${px(xs[0])} ${py(ys[0])}`;
    for (let i = 1; i < xs.length; i += 1) d += ` L ${px(xs[i])} ${py(ys[i])}`;
    return `<div class="chart-box"><h4 class="chart-title">${esc(title)}</h4>
      <svg viewBox="0 0 ${W} ${H}" class="chart-svg" role="img">
        <line class="ch-axis" x1="${pad.l}" y1="${pad.t + ph}" x2="${pad.l + pw}" y2="${pad.t + ph}"/>
        <line class="ch-axis" x1="${pad.l}" y1="${pad.t}" x2="${pad.l}" y2="${pad.t + ph}"/>
        <path class="ch-line" style="stroke:${color}" d="${d}"/>
        <text class="ch-lab ch-lab-axis" x="${pad.l + pw / 2}" y="${H - 6}" text-anchor="middle">ω (eV)</text>
      </svg></div>`;
  }

  function svgOpticalBlock(optical, lang) {
    const lg = lang || (window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr");
    const spec = optical && optical.spectrum;
    if (!spec || !spec.omega_ev) {
      const prev = (optical && optical.preview) || {};
      const note = lg === "en" ? (prev.note_en || prev.note_fr) : (prev.note_fr || prev.note_en);
      return note ? `<p class="meta">${esc(note)}</p>` : `<p class="meta">${esc(i18nT("proprietes.chart.optical_empty"))}</p>`;
    }
    const parts = [
      svgOpticalSeries(spec, "epsilon_real", i18nT("proprietes.chart.eps1"), "#1d4ed8"),
      svgOpticalSeries(spec, "epsilon_imag", i18nT("proprietes.chart.eps2"), "#c2410c"),
      svgOpticalSeries(spec, "n_real", i18nT("proprietes.chart.n_real"), "#047857"),
      svgOpticalSeries(spec, "n_imag", i18nT("proprietes.chart.n_imag"), "#7c3aed"),
      svgOpticalSeries(spec, "conductivity", i18nT("proprietes.chart.sigma"), "#b45309"),
    ].filter(Boolean);
    return `<div class="chart-grid">${parts.join("")}</div>
      <p class="meta">${esc(i18nT("proprietes.chart.optical_src"))}: <code>${esc(spec.source || "—")}</code></p>`;
  }

  function postscfElectronicHtml(postscf) {
    if (!postscf || !postscf.ok) {
      const empty = material ? i18nT("res.postscf.empty") : i18nT("proprietes.pick_mat");
      return `<p class="meta">${esc(empty)}</p>`;
    }
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    const elec = postscf.electronic || {};
    const opt = postscf.optical_preview || {};
    const plots = postscf.plots || {};
    const dosPts = postscf.nscf && postscf.nscf.has_results ? "✓" : "—";
    const gap = elec.band_gap_ev != null ? Number(elec.band_gap_ev).toFixed(3) : "—";
    const dosEf = elec.dos_at_ef != null ? Number(elec.dos_at_ef).toFixed(3) : "—";
    const etype = lang === "en"
      ? (elec.electronic_type_en || elec.electronic_type || "—")
      : (elec.electronic_type || elec.electronic_type_en || "—");
    const optNote = lang === "en" ? (opt.note_en || opt.note_fr) : (opt.note_fr || opt.note_en);
    const onset = opt.absorption_onset_nm != null ? `${opt.absorption_onset_nm} nm` : "—";
    const dosSvg = svgDosPlot(plots.dos);
    const bandsSvg = svgBandsPlot(plots.bands, lang);
    const bandsMode = plots.bands && plots.bands.mode;
    const bandsNotice =
      bandsMode === "k_mesh" && dosPts === "✓"
        ? `<p class="meta postscf-bands-notice">${esc(i18nT("proprietes.bands.mesh_notice"))}</p>`
        : "";
    const dosNotice =
      dosPts === "✓"
        ? `<p class="meta">${esc(i18nT("proprietes.dos.notice"))}</p>`
        : "";
    const opticalHtml = svgOpticalBlock(
      plots.optical || { preview: opt, spectrum: postscf.optical_spectrum },
      lang
    );
    const pd = postscf.plot_data || {};
    const pdFiles = pd.files || [];
    const fileRows = pdFiles.length
      ? `<ul class="plot-data-list">${pdFiles.map((f) =>
        `<li><a href="${esc(f.url || "#")}" target="_blank" rel="noopener"><code>${esc(f.name)}</code></a> — ${esc(lang === "en" ? (f.label_en || f.name) : (f.label_fr || f.name))}</li>`
      ).join("")}</ul>`
      : `<p class="meta">${esc(i18nT("proprietes.data.no_files"))}</p>`;
    const zipBase = `/api/materials/${encodeURIComponent(postscf.material || material || "")}/postscf/download-zip${phaseQuery()}`;
    return `
      <div class="meta"><strong>Gap :</strong> ${esc(gap)} eV · <strong>N(E<sub>F</sub>) :</strong> ${esc(dosEf)} · <strong>Type :</strong> ${esc(etype)}</div>
      <div class="meta"><strong>DOS/bandes extraits :</strong> ${dosPts}</div>
      ${dosNotice}
      ${bandsNotice}
      <div class="meta"><strong>Aperçu optique :</strong> bord ≈ ${esc(onset)}${optNote ? ` — ${esc(optNote)}` : ""}</div>
      <div class="chart-grid">
        ${dosSvg ? `<div class="chart-box"><h4 class="chart-title">${esc(i18nT("proprietes.chart.dos"))}</h4>${dosSvg}</div>` : ""}
        ${bandsSvg ? `<div class="chart-box chart-box-bands${bandsMode === "high_symmetry" ? " is-high-sym" : ""}"><h4 class="chart-title">${esc(i18nT("proprietes.chart.bands"))}${bandsMode === "high_symmetry" ? " · Γ, X, M…" : ""}</h4>${bandsSvg}</div>` : ""}
      </div>
      <div class="chart-box"><h4 class="chart-title">${esc(i18nT("proprietes.chart.optical"))}</h4>${opticalHtml}</div>
      <div class="chart-box"><h4 class="chart-title">${esc(i18nT("proprietes.data.files_title"))}</h4>
        ${fileRows}
        <p class="meta"><a href="${esc(zipBase)}" download>${esc(i18nT("proprietes.btn.download_zip"))}</a> · <code>optimisation/plot_data/</code></p>
      </div>`;
  }

  function paintPostscfElectronic(postscf) {
    const html = postscfElectronicHtml(postscf);
    const body = $("postscf-electronic-body");
    const resBody = $("res-postscf-body");
    if (body) body.innerHTML = html;
    if (resBody) resBody.innerHTML = html;
  }

  function paintElasticResults(elasticData) {
    const el = $("res-elastic-body");
    if (!el) return;
    if (!elasticData) {
      el.innerHTML = `<p class="meta">${esc(material ? i18nT("res.elastic.empty") : i18nT("proprietes.pick_mat"))}</p>`;
      return;
    }
    const tensor = elasticData.elastic_tensor || {};
    const has = Object.keys(tensor).some((k) => Number(tensor[k]));
    if (!has) {
      el.innerHTML = `<p class="meta">${esc(elasticData.message || elasticData.error || i18nT("res.elastic.empty"))}</p>`;
      return;
    }
    const bornList = elasticData.born_criteria || [];
    const born = bornList.length ? bornList.join(" ; ") : "—";
    const stable = elasticData.static_stable ? (window.qeI18n && window.qeI18n.getLang && window.qeI18n.getLang() === "en" ? "Yes" : "Oui") : (window.qeI18n && window.qeI18n.getLang && window.qeI18n.getLang() === "en" ? "No" : "Non");
    const rows = Object.entries(tensor).map(([k, v]) =>
      `<tr><th>${esc(k)}</th><td class="num-hi">${formatElasticValue(v)}</td></tr>`
    ).join("");
    const note = elasticData.note || "";
    el.innerHTML =
      `<p class="meta"><strong>${esc(i18nT("res.elastic.born"))} :</strong> ${esc(stable)} · ${esc(born)}</p>` +
      (note ? `<p class="meta">${esc(note)}</p>` : "") +
      `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table"><thead><tr><th>Cij</th><th>GPa</th></tr></thead><tbody>${rows}</tbody></table></div>`;
  }

  function paintHubbardResults(data) {
    const el = $("res-hubbard-body");
    if (!el) return;
    const species = (data && data.species) || [];
    if (!species.length) {
      el.innerHTML = `<p class="meta">${esc(i18nT("res.hubbard.empty"))}</p>`;
      return;
    }
    const uMap = data.u_by_species || {};
    const refMap = data.reference_by_species || {};
    const rows = species.map(({ symbol, index }) => {
      const val = uMap[symbol] != null ? uMap[symbol] : 0;
      const ref = refMap[symbol];
      const refTxt = ref && ref.correlated && ref.u > 0
        ? `ref. ${ref.shell || "?"} ≈ ${ref.u} eV`
        : "—";
      return `<tr><td>${esc(symbol)}</td><td>${esc(String(index ?? ""))}</td><td class="num-hi">${esc(String(val))}</td><td>${esc(refTxt)}</td></tr>`;
    }).join("");
    el.innerHTML =
      `<p class="meta">${esc(data.enabled ? i18nT("res.hubbard.on") : i18nT("res.hubbard.off"))}</p>` +
      `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table"><thead><tr><th>${esc(i18nT("hubbard.col.species"))}</th><th>#</th><th>${esc(i18nT("hubbard.col.u"))}</th><th>Réf.</th></tr></thead><tbody>${rows}</tbody></table></div>`;
  }

  async function refreshResultsExtras() {
    const emptyIds = ["res-postscf-body", "res-elastic-body", "res-hubbard-body"];
    if (!material) {
      paintPostscfElectronic(null);
      paintElasticResults(null);
      paintHubbardResults(null);
      return;
    }
    emptyIds.forEach((id) => {
      const node = $(id);
      if (node && (!node.textContent || node.textContent.trim() === "—")) {
        node.innerHTML = `<p class="meta">…</p>`;
      }
    });
    const [postscf, elastic, hubbard] = await Promise.all([
      api(`/api/materials/${encodeURIComponent(material)}/postscf/status${phaseQuery()}`).catch(() => null),
      api(`/api/materials/${encodeURIComponent(material)}/elastic${phaseQuery("?full=1")}`).catch(() => null),
      api(`/api/materials/${encodeURIComponent(material)}/hubbard${hubbardPhaseQuery()}`).catch(() => null),
    ]);
    paintPostscfElectronic(postscf);
    paintElasticResults(elastic);
    paintHubbardResults(hubbard);
  }

  function updatePostscfButtons(postscf, phaseStab) {
    const can = sessionConfirmed && material;
    const nscf = (postscf && postscf.nscf) || {};
    const scfOk = !!(lastOptimSteps && lastOptimSteps.scf && (lastOptimSteps.scf.converged || lastOptimSteps.scf.run_phase === "done"));
    const ref = phaseStab && (phaseStab.reference_phase_id || phaseStab.stable_phase_id);
    const btnNscf = $("btn-postscf-nscf");
    const btnStable = $("btn-postscf-nscf-stable");
    const btnExtract = $("btn-postscf-extract");
    const btnBands = $("btn-postscf-bands");
    const btnOpt = $("btn-postscf-optical");
    const btnEl = $("btn-postscf-elastic");
    const btnElRun = $("btn-postscf-elastic-run");
    const elStep = ((postscf && postscf.steps) || []).find((s) => s.id === "elastic") || {};
    if (btnNscf) btnNscf.disabled = !can || !scfOk || !!nscf.running;
    if (btnStable) btnStable.disabled = !can || !ref || !!nscf.running;
    const canExtract = can && (nscf.has_results || nscf.phase === "done" || _nscfSaveHint(postscf));
    if (btnExtract) btnExtract.disabled = !canExtract;
    if (btnBands) btnBands.disabled = !can || !scfOk;
    const btnExport = $("btn-postscf-export-data");
    const btnFiche = $("btn-postscf-fiche");
    const zipLink = $("btn-postscf-zip");
    if (btnExport) btnExport.disabled = !can;
    if (btnFiche) btnFiche.disabled = !can;
    if (zipLink) {
      zipLink.hidden = !can;
      if (can && material) {
        zipLink.href = `/api/materials/${encodeURIComponent(material)}/postscf/download-zip${phaseQuery()}`;
      }
    }
    if (btnOpt) btnOpt.disabled = !can;
    if (btnEl) btnEl.disabled = !can || !scfOk;
    const pendingElastic = Number(elStep.inputs_pending || 0) > 0 && !elStep.done;
    if (btnElRun) btnElRun.disabled = !can || !pendingElastic;
  }

  function _nscfSaveHint(postscf) {
    const steps = (postscf && postscf.steps) || [];
    const dos = steps.find((s) => s.id === "dos_bands");
    return dos && dos.done;
  }

  async function refreshProprietesPage() {
    const body = $("elastic-page-body");
    if (!body) return null;
    if (!material) {
      body.innerHTML = `<p class="meta">${esc(i18nT("proprietes.pick_mat"))}</p>`;
      paintPostscfPipeline(null);
      paintPostscfElectronic(null);
      return null;
    }
    const postscf = await api(
      `/api/materials/${encodeURIComponent(material)}/postscf/status${phaseQuery()}`
    );
    paintPostscfPipeline(postscf);
    paintPostscfElectronic(postscf);
    const phaseStab = await api(
      `/api/materials/${encodeURIComponent(material)}/static-stability${phaseQuery()}`
    ).catch(() => null);
    updatePostscfButtons(postscf, phaseStab);
    const [staticData, elasticData] = await Promise.all([
      api(`/api/materials/${encodeURIComponent(material)}/static-stability${phaseQuery()}`),
      api(`/api/materials/${encodeURIComponent(material)}/elastic${phaseQuery("?full=1")}`),
    ]);
    const stableId = (staticData && (staticData.stable_phase_id || staticData.reference_phase_id)) || phaseId || "";
    const row = ((staticData && staticData.results) || []).find((r) => r.phase_id === stableId) || ((staticData && staticData.results) || [])[0] || null;
    const thermo = (row && row.thermodynamics) || {};
    const hasScfTensor = !!(elasticData && elasticData.ok && elasticData.elastic_tensor && Object.keys(elasticData.elastic_tensor).length);
    const elastic = hasScfTensor
      ? elasticData.elastic_tensor
      : ((row && (row.synthetic_elastic_constants || row.elastic_constants)) || {});
    const elasticSource = hasScfTensor ? "SCF QE (mailles déformées)" : "aperçu provisoire (pas encore de SCF élastique)";
    const bornSrc = hasScfTensor ? elasticData : row;
    const stable = bornSrc && bornSrc.static_stable ? "Oui" : "Non";
    const bornList = (bornSrc && bornSrc.born_criteria) || [];
    const born = bornList.length ? bornList.join(" ; ") : "Aucun critère de rupture détecté";
    const bornLabel = hasScfTensor ? "Stabilité Born (SCF)" : "Stabilité Born (aperçu provisoire)";
    const coh = row && row.cohesive_energy_ev_per_atom != null ? formatElasticValue(row.cohesive_energy_ev_per_atom) : "—";
    const form = row && row.formation_energy_ev_per_atom != null ? formatElasticValue(row.formation_energy_ev_per_atom) : "—";
    const enthalpy = thermo.enthalpy_ev_per_atom != null ? formatElasticValue(thermo.enthalpy_ev_per_atom) : "—";
    const gibbs = thermo.gibbs_free_energy_ev_per_atom != null ? formatElasticValue(thermo.gibbs_free_energy_ev_per_atom) : "—";
    const entropy = thermo.entropy_ev_per_atom_k != null ? formatElasticValue(thermo.entropy_ev_per_atom_k) : "—";
    const pressure = thermo.pressure_gpa != null ? formatElasticValue(thermo.pressure_gpa) : "0.0000";
    const temp = thermo.temperature_k != null ? formatElasticValue(thermo.temperature_k) : "300.0000";
    const phaseLabel = row ? (row.phase_label || row.phase_id || stableId || "—") : (stableId || "—");
    const elasticHtml = Object.keys(elastic).length
      ? Object.entries(elastic).map(([k, v]) => `<tr><th>${esc(k)}</th><td>${formatElasticValue(v)}</td></tr>`).join("")
      : '<tr><th>Élastique</th><td>Pas de tenseur SCF : générez puis lancez les déformations (calculation = scf).</td></tr>';
    const banner = hasScfTensor
      ? `<p class="meta" style="border-left:3px solid var(--ok, #15803d);padding-left:0.6rem;">
           <strong>Cij = SCF :</strong> tenseur issu des énergies totales pw.x sur mailles déformées.
         </p>`
      : `<p class="meta" style="border-left:3px solid var(--warn, #b45309);padding-left:0.6rem;">
           <strong>Cij SCF pas encore disponibles :</strong> ${esc((staticData && staticData.disclaimer) || "lancez le calcul élastique (SCF déformé).")}
         </p>`;
    body.innerHTML = `
      ${banner}
      <div class="meta"><strong>Phase stable :</strong> ${esc(String(phaseLabel))}</div>
      <div class="meta"><strong>${esc(bornLabel)} :</strong> ${stable} · ${esc(born)}</div>
      <div class="meta"><strong>Cohésion (aperçu) :</strong> ${coh} eV/at · <strong>ΔE formation vs ref (SCF) :</strong> ${form} eV/at</div>
      <div class="meta"><strong>Thermo (aperçu) :</strong> T = ${temp} K · P = ${pressure} GPa · H = ${enthalpy} eV/at · G = ${gibbs} eV/at · S = ${entropy} eV/(at·K)</div>
      <div class="meta"><strong>Tenseur Cij :</strong> ${esc(elasticSource)}</div>
      <div class="mag-table-scroll">
        <table class="phase-table mag-cmp-table">
          <thead><tr><th>Constante</th><th>Valeur</th></tr></thead>
          <tbody>${elasticHtml}</tbody>
        </table>
      </div>
      ${elasticData && elasticData.needs_qe_run ? `<p class="meta">${esc(elasticData.message || "SCF élastiques en attente d’exécution.")}</p>` : ""}
    `;
    if (postscf && postscf.nscf && postscf.nscf.running && !optimPollTimer) {
      startOptimPoll(material, "nscf", postscf.nscf.job_id || jobId);
    }
    return { staticData, postscf };
  }

  async function runPostscfExtract() {
    if (!requireSessionConfirmed()) return;
    const data = await api(
      `/api/materials/${encodeURIComponent(material)}/postscf/extract`,
      { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(withPhaseBody({})) }
    );
    log("log-opt", data.message || data.error || data, !!data.ok);
    await refreshProprietesPage().catch(() => {});
    await refreshPhaseStability().catch(() => {});
  }

  async function runPostscfExportData() {
    if (!requireSessionConfirmed()) return;
    const data = await api(
      `/api/materials/${encodeURIComponent(material)}/postscf/export-data`,
      { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(withPhaseBody({})) }
    );
    log("log-opt", data.message || data.error || data, !!data.ok);
    await refreshProprietesPage().catch(() => {});
  }

  function openPostscfFiche() {
    if (!material) return;
    const pid = activePhaseId();
    let url = "fiche.html?fiche=" + encodeURIComponent(material);
    if (pid) url += "&phase_id=" + encodeURIComponent(pid);
    window.open(url, "_blank");
  }

  async function runPostscfBands() {
    if (!requireSessionConfirmed()) return;
    const data = await api(
      `/api/materials/${encodeURIComponent(material)}/postscf/bands/generate`,
      { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(withPhaseBody({})) }
    );
    log("log-opt", data.message || data.error || data, !!data.ok);
    await refreshProprietesPage().catch(() => {});
  }

  async function runPostscfOptical() {
    if (!requireSessionConfirmed()) return;
    const data = await api(
      `/api/materials/${encodeURIComponent(material)}/postscf/optical/prepare`,
      { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(withPhaseBody({})) }
    );
    log("log-opt", data.message || data.error || data, !!data.ok);
    await refreshProprietesPage().catch(() => {});
  }

  async function runElasticActivePhase() {
    if (!requireSessionConfirmed()) return;
    const pid = activePhaseId() || getDraftPhase() || "";
    const payload = withPhaseBody({ phase_id: pid, epsilon: 0.01 });
    const data = await api(`/api/materials/${encodeURIComponent(material)}/elastic/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    log("log-opt", data && data.message ? data.message : (data && data.error ? data.error : "Cij"), !!(data && data.ok));
    await refreshProprietesPage().catch(() => {});
    return data;
  }

  async function runElasticBatchActivePhase() {
    if (!requireSessionConfirmed()) return;
    const data = await api(
      `/api/materials/${encodeURIComponent(material)}/elastic/run-batch`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(withPhaseBody({ job_id: jobId || undefined })),
      }
    );
    log("log-opt", data.message || data.error || data, !!data.ok);
    if (data.job_id) setJob(data.job_id);
    await refreshProprietesPage().catch(() => {});
  }

  async function runNscfStable() {
    if (!requireSessionConfirmed()) return;
    const body = withPhaseBody({});
    if (jobId) body.job_id = jobId;
    const data = await api(`/api/materials/${encodeURIComponent(material)}/nscf/run-stable`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    log("log-opt", data, !!data.ok);
    if (data.job_id) setJob(data.job_id);
    await refreshPhaseStability().catch(() => {});
  }

  async function runElasticStable() {
    if (!requireSessionConfirmed()) return;
    const st = await api(`/api/materials/${encodeURIComponent(material)}/phase-stability`);
    const ref = (st && (st.reference_phase_id || st.stable_phase_id)) || activePhaseId() || phaseId || "";
    if (!ref) {
      const el = $("elastic-summary");
      if (el) el.textContent = "Aucune phase stable déterminée pour lancer le calcul élastique.";
      return;
    }
    const payload = withPhaseBody({ phase_id: ref, epsilon: 0.01 });
    const data = await api(`/api/materials/${encodeURIComponent(material)}/elastic/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const el = $("elastic-summary");
    if (el) {
      if (data && data.ok) {
        const count = (data.inputs || []).length || 0;
        el.textContent = `Déformations élastiques générées pour ${ref} : ${count} fichiers prêts à être lancés dans QE.`;
      } else {
        el.textContent = data && data.error ? data.error : "Le calcul élastique n’a pas pu être préparé.";
      }
    }
    log("log-opt", data && data.message ? data.message : (data && data.error ? data.error : "Calcul élastique"), !!(data && data.ok));
    return data;
  }

  async function runNscfOrder(order) {
    if (!requireSessionConfirmed()) return;
    const mo = !order || order === "nm" ? "" : order;
    const body = withPhaseBody({ mag_order: mo });
    if (jobId) body.job_id = jobId;
    const data = await api(`/api/materials/${encodeURIComponent(material)}/nscf/run`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    log("log-opt", data.message || data, !!data.ok);
    if (data.job_id) setJob(data.job_id);
    await refreshMagOrders().catch(() => {});
    await refreshPhaseStability().catch(() => {});
    await refreshOptimStatus().catch(() => {});
    if (data.ok) startOptimPoll(material, "nscf", data.job_id || jobId, mo || undefined);
  }

  async function runNscfMagneticSet() {
    if (!requireSessionConfirmed()) return;
    const body = withPhaseBody({});
    if (jobId) body.job_id = jobId;
    const data = await api(`/api/materials/${encodeURIComponent(material)}/nscf/run-magnetic`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    log("log-opt", data.message || data, !!data.ok);
    if (data.job_id) setJob(data.job_id);
    await refreshMagOrders().catch(() => {});
    await refreshPhaseStability().catch(() => {});
    if (data.ok) {
      const first = (data.queued || []).find((o) => o) || "nm";
      startOptimPoll(material, "nscf", data.job_id || jobId, first !== "nm" ? first : undefined);
    }
  }

  async function runNscfCurrentPhase() {
    if (!requireSessionConfirmed()) return;
    const body = withPhaseBody({});
    if (jobId) body.job_id = jobId;
    const data = await api(`/api/materials/${encodeURIComponent(material)}/nscf/run`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    log("log-opt", data, !!data.ok);
    if (data.job_id) setJob(data.job_id);
    await refreshPhaseStability().catch(() => {});
    await refreshProprietesPage().catch(() => {});
    if (data.ok) startOptimPoll(material, "nscf", data.job_id || jobId);
  }

  function magTableHtml(data) {
    if (!data) return `<p class="meta">${i18nT("mag.stability.empty")}</p>`;
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    const rows = (data.orders) || [];
    const cmpRows = rows.filter((r) => magOrderInCompareTable(r));
    const byOrd = {};
    rows.forEach((r) => { byOrd[r.order] = r; });
    const nmR = byOrd.nm || {};
    const fmR = byOrd.fm || {};
    let summary = "";
    if (nmR.energy_per_atom_ev != null && fmR.energy_per_atom_ev != null) {
      const dFmNm = Number(fmR.energy_per_atom_ev) - Number(nmR.energy_per_atom_ev);
      const winner = data.reference_order === "fm" ? "FM" : (data.reference_order === "nm" ? "NM" : (data.reference_order || "").toUpperCase());
      summary += `<p class="mag-cmp-summary">${winner ? winner + " ★  ·  " : ""}NM ${fmtEnergyEv(nmR.energy_per_atom_ev)} eV/at  ·  FM ${fmtEnergyEv(fmR.energy_per_atom_ev)} eV/at  ·  ΔE(FM−NM) = ${fmtDeltaEv(dFmNm)} eV/at</p>`;
    }
    const head = `<tr>
      <th>Ordre</th><th>Mailles</th><th>Spins</th><th>nspin</th>
      <th>E<sub>tot</sub> / u.c. (eV)</th><th>E/atom (eV)</th><th>ΔE (eV/at)</th>
      <th>M<sub>tot</sub> / u.c.</th><th>M<sub>abs</sub> / u.c.</th>
      <th>E<sub>F</sub> (eV)</th><th>V / u.c. (Å<sup>3</sup>)</th>
    </tr>`;
    const lines = cmpRows.map((r) => {
      const stable = data.reference_order && r.order === data.reference_order && (r.scf_converged || r.from_main_scf);
      const label = r.order === "nm" ? "NM" : (r.short || r.order);
      const etot = r.total_energy_ev != null ? Number(r.total_energy_ev).toFixed(4) : "—";
      const ef = r.fermi_ev != null ? Number(r.fermi_ev).toFixed(4) : "—";
      const vol = r.volume_ang3 != null ? Number(r.volume_ang3).toFixed(3) : "—";
      const nCell = r.n_cells != null ? r.n_cells : 1;
      const cellLab = Number(nCell) > 1
        ? `${nCell} u.c. · ${r.supercell || "surmaille"}`
        : "1 u.c.";
      const spins = r.spin_arrows || (r.order === "nm" ? "·" : "—");
      return `<tr class="${stable ? "phase-row-stable" : ""}"><td>${label}${stable ? " ★" : ""}</td><td>${cellLab}</td><td class="mag-spin-arrows">${spins}</td><td>${r.nspin ?? "—"}</td><td class="num-hi">${etot}</td><td class="num-hi">${fmtEnergyEv(r.energy_per_atom_ev)}</td><td class="num-hi">${r.delta_ev_per_atom != null ? fmtDeltaEv(r.delta_ev_per_atom) : "—"}</td><td>${fmtMagNum(r.tot_mag, 4)}</td><td>${fmtMagNum(r.abs_mag, 4)}</td><td class="num-hi">${ef}</td><td class="num-hi">${vol}</td></tr>`;
    });
    return cmpRows.length
      ? `${summary}<div class="mag-table-scroll"><table class="phase-table mag-cmp-table"><thead>${head}</thead><tbody>${lines.join("")}</tbody></table></div>`
      : `<p class="meta">${i18nT("mag.stability.empty")}</p>`;
  }

  function fmtThermo(v) {
    if (v == null || v === "") return "—";
    const n = Number(v);
    return Number.isFinite(n) ? n.toFixed(4) : "—";
  }

  function outputPathLink(rel) {
    if (!rel) return "";
    const href = safeHref(String(rel).startsWith("/") ? rel : `/${rel}`);
    return `<a class="run-out" href="${escAttr(href)}" target="_blank" rel="noopener">${esc(rel)}</a>`;
  }

  /** Affichage chemin sans téléchargement (inventaire Préparation / Résultats). */
  function outputPathPlain(rel) {
    if (!rel) return "—";
    return `<code class="io-path-plain">${esc(rel)}</code>`;
  }

  async function openIoInventoryInput(opts = {}) {
    const mat = String(opts.material || material || getDraftMaterial() || "").trim();
    const kind = String(opts.kind || "vc-relax").trim().toLowerCase();
    const phase = String(opts.phaseId || "").trim();
    const mag = String(opts.magOrder || "").trim().toLowerCase();
    if (!mat) {
      alert(i18nT("alert.pick_mat"));
      return;
    }
    if (!["vc-relax", "relax", "scf", "nscf"].includes(kind)) {
      alert(i18nT("res.io.open_unsupported"));
      return;
    }
    if (mag && mag !== "nm") {
      await openMagEditorForPhase(mag, kind, mat, phase || "");
      return;
    }
    await openPhaseEditor(phase || "", kind, mat);
  }

  function bindIoInventoryOpenClicks(root) {
    if (!root || root.dataset.ioOpenBound === "1") return;
    root.dataset.ioOpenBound = "1";
    root.addEventListener("click", (ev) => {
      const btn = ev.target && ev.target.closest ? ev.target.closest(".btn-io-open") : null;
      if (!btn) return;
      ev.preventDefault();
      openIoInventoryInput({
        material: btn.dataset.mat || "",
        kind: btn.dataset.kind || "",
        phaseId: btn.dataset.phase || "",
        magOrder: btn.dataset.mag || "",
      }).catch((e) => alert(e.message || String(e)));
    });
  }

  function getResultsBrowseMat() {
    const fromInput = normalizeMaterialInput(($("results-mat-select")?.value || "").trim());
    if (fromInput) return fromInput;
    return normalizeMaterialInput(resultsBrowseMat || "") || "";
  }

  function setResultsBrowseMat(matName, opts = {}) {
    const m = normalizeMaterialInput(String(matName || "").trim()) || "";
    resultsBrowseMat = m;
    const inp = $("results-mat-select");
    if (inp && inp.value !== m) inp.value = m;
    const clearBtn = $("btn-results-mat-clear");
    if (clearBtn) clearBtn.hidden = !m;
    const hint = $("results-browse-mat-hint");
    if (hint) hint.hidden = !!m;
    const stepKind = $("results-browse-step-kind");
    if (stepKind) stepKind.hidden = !m;
    if (!m) {
      resultsBrowseKind = "";
      resultsSubTab = "res-nondope";
    } else if (!opts.keepKind) {
      resultsBrowseKind = "";
    }
    paintResultsBrowseChrome();
    try {
      if (m) localStorage.setItem("optimqe.resultsBrowseMat", m);
      else localStorage.removeItem("optimqe.resultsBrowseMat");
      if (!resultsBrowseKind) localStorage.removeItem("optimqe.resultsBrowseKind");
    } catch (_) {}
  }

  function setResultsBrowseKind(kind, opts = {}) {
    const k = kind === "doped" ? "doped" : kind === "nondope" ? "nondope" : "";
    resultsBrowseKind = k;
    resultsSubTab = k === "doped" ? "res-doped" : "res-nondope";
    paintResultsBrowseChrome();
    paintPrepToneChrome();
    try {
      if (k) {
        localStorage.setItem("optimqe.resultsBrowseKind", k);
        localStorage.setItem("optimqe.resultsSubTab", resultsSubTab);
      } else {
        localStorage.removeItem("optimqe.resultsBrowseKind");
      }
    } catch (_) {}
    if (!opts.skipLoad && getResultsBrowseMat() && k) {
      refreshMaterialIoProfile().catch(() => {});
    }
  }

  function paintResultsBrowseChrome() {
    const mat = getResultsBrowseMat();
    const kind = resultsBrowseKind;
    const stepFiles = $("results-browse-step-files");
    const panelN = $("res-subpanel-nondope");
    const panelD = $("res-subpanel-doped");
    const cardN = $("res-io-nondope-card");
    const cardD = $("res-io-doped-card");
    const chipN = $("results-mat-chip-nondope");
    const chipD = $("results-mat-chip-doped");
    const showFiles = !!(mat && kind);
    if (stepFiles) stepFiles.hidden = !showFiles;
    if (panelN) {
      const on = showFiles && kind === "nondope";
      panelN.hidden = !on;
      panelN.classList.toggle("active", on);
    }
    if (panelD) {
      const on = showFiles && kind === "doped";
      panelD.hidden = !on;
      panelD.classList.toggle("active", on);
    }
    if (cardN) cardN.hidden = !(showFiles && kind === "nondope");
    if (cardD) cardD.hidden = !(showFiles && kind === "doped");
    if (chipN) {
      chipN.classList.toggle("is-active", kind === "nondope");
      chipN.setAttribute("aria-selected", kind === "nondope" ? "true" : "false");
      chipN.disabled = !mat;
    }
    if (chipD) {
      chipD.classList.toggle("is-active", kind === "doped");
      chipD.setAttribute("aria-selected", kind === "doped" ? "true" : "false");
      chipD.disabled = !mat;
    }
    // Onglets cachés : le parcours browse les remplace
    const subtabs = $("session-subtabs-resultats");
    if (subtabs) subtabs.hidden = true;
    const line = $("results-mat-line");
    if (line) {
      if (mat && kind) {
        line.hidden = false;
        line.textContent =
          kind === "doped"
            ? `${i18nT("res.org.doped")} · ${mat}`
            : `${i18nT("res.org.nondope")} · ${mat}`;
      } else {
        line.hidden = true;
        line.textContent = "";
      }
    }
  }

  function switchResultsSubTab(sub) {
    const s = String(sub || "");
    if (s === "res-doped" || s === "doped") setResultsBrowseKind("doped");
    else if (s === "res-nondope" || s === "nondope") setResultsBrowseKind("nondope");
    else setResultsBrowseKind("");
  }

  function ioInputsTableRows(inputs, ctx = {}) {
    if (!inputs || !inputs.length) return "";
    const mat = String(ctx.material || material || "").trim();
    const phaseId = String(ctx.phaseId || "").trim();
    const magOrder = String(ctx.magOrder || "").trim();
    return inputs
      .map((f) => {
        const kind = String(f.kind || "").trim().toLowerCase();
        const openable = ["vc-relax", "relax", "scf", "nscf"].includes(kind);
        const openCell = openable
          ? `<button type="button" class="btn ghost btn-io-open" data-mat="${escAttr(mat)}" data-phase="${escAttr(phaseId)}" data-mag="${escAttr(magOrder)}" data-kind="${escAttr(kind)}">${esc(i18nT("res.io.open"))}</button>`
          : `<span class="meta">—</span>`;
        return (
          `<tr><td>${esc(f.kind || "—")}</td><td><code>${esc(f.name || "")}</code></td>` +
          `<td class="io-open-cell">${openCell}</td>` +
          `<td>${outputPathPlain(f.path)}</td></tr>`
        );
      })
      .join("");
  }

  function ioInputsTableHead() {
    return `<thead><tr><th>${esc(i18nT("res.io.col.kind"))}</th><th>${esc(i18nT("res.io.col.file"))}</th><th>${esc(i18nT("res.io.col.open"))}</th><th>${esc(i18nT("res.io.col.path"))}</th></tr></thead>`;
  }

  function ioOutputBlock(branch, title) {
    if (!branch) return "";
    if (!branch.exists) {
      return `<h5 class="result-sub">${esc(title)}</h5><p class="meta">${esc(i18nT("res.io.outputs.pending"))}</p>`;
    }
    const files =
      (branch.files || []).slice(0, 12).map((f) => `<li><code>${esc(f)}</code></li>`).join("") || "";
    const subs =
      (branch.subdirs || []).slice(0, 8).map((d) => `<li><code>${esc(d)}/</code></li>`).join("") || "";
    return (
      `<h5 class="result-sub">${esc(title)}</h5>` +
      `<p class="meta">${outputPathLink(branch.dir)}/</p>` +
      (files ? `<ul class="output-layout-files">${files}</ul>` : "") +
      (subs ? `<p class="meta">${esc(i18nT("res.io.subdirs"))}</p><ul class="output-layout-files">${subs}</ul>` : "")
    );
  }

  function paintMaterialIoProfile(data) {
    const bodyN = $("res-io-nondope-body");
    const bodyD = $("res-io-doped-body");
    if (!bodyN || !bodyD) return;
    if (!data || !data.ok || !data.profile) {
      const empty = `<p class="meta">${esc(i18nT("res.io.empty"))}</p>`;
      bodyN.innerHTML = empty;
      bodyD.innerHTML = empty;
      paintResultsBrowseChrome();
      return;
    }
    paintResultsBrowseChrome();
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    const guide = lang === "en" ? data.guide_en || data.guide_fr : data.guide_fr || data.guide_en;
    const nd = data.profile.nondoped || {};
    const dp = data.profile.doped || {};
    const prepN = nd.preparation || {};
    const calcN = nd.calculation || {};

    const invMat = String(data.material || browseMat || material || "").trim();
    const matHeading = invMat;
    let htmlN = `<div class="results-mat-block" data-mat="${escAttr(matHeading || invMat)}">`;
    htmlN += `<h4 class="results-mat-heading">${esc(i18nT("res.org.block_nondope", { mat: matHeading || "—" }))}</h4>`;
    if (guide) htmlN += `<p class="meta">${esc(guide)}</p>`;
    htmlN += `<p class="meta">${esc(i18nT("res.io.open_hint"))}</p>`;
    htmlN += `<p class="meta"><strong>${esc(i18nT("res.io.inputs_root"))}</strong> ${outputPathPlain(data.inputs_dir)}</p>`;
    htmlN += `<h5 class="result-sub">${esc(i18nT("res.io.prep.nm"))}</h5>`;
    if (prepN.cif) htmlN += `<p class="meta">CIF : ${outputPathPlain(prepN.cif)}</p>`;
    const nmRows = ioInputsTableRows(prepN.nm_chain || [], { material: invMat });
    htmlN += nmRows
      ? `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table">${ioInputsTableHead()}<tbody>${nmRows}</tbody></table></div>`
      : `<p class="meta">—</p>`;
    const magOrders = prepN.magnetic_orders || [];
    if (magOrders.length) {
      htmlN += `<h5 class="result-sub">${esc(i18nT("res.io.prep.mag"))}</h5>`;
      magOrders.forEach((mo) => {
        htmlN += `<p class="meta"><strong>${esc(mo.order)}</strong></p>`;
        const rows = ioInputsTableRows(mo.inputs || [], {
          material: invMat,
          magOrder: mo.order || "",
        });
        if (rows) {
          htmlN += `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table">${ioInputsTableHead()}<tbody>${rows}</tbody></table></div>`;
        }
      });
    }
    const sqs = prepN.sqs_phases || [];
    if (sqs.length) {
      htmlN += `<h5 class="result-sub">${esc(i18nT("res.io.prep.sqs"))}</h5>`;
      sqs.forEach((ph) => {
        htmlN += `<p class="meta"><strong>${esc(ph.phase_id)}</strong></p>`;
        const rows = ioInputsTableRows(ph.inputs || [], {
          material: invMat,
          phaseId: ph.phase_id || "",
        });
        htmlN += `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table">${ioInputsTableHead()}<tbody>${rows}</tbody></table></div>`;
      });
    }
    if (!PHASES_PREP_ONLY) {
      htmlN += `<h5 class="result-sub">${esc(i18nT("res.io.calc.nm"))}</h5>`;
      htmlN += ioOutputBlock(calcN.nm, "NM") || `<p class="meta">—</p>`;
      const magCalc = calcN.magnetism || {};
      const magKeys = Object.keys(magCalc);
      if (magKeys.length) {
        htmlN += `<h5 class="result-sub">${esc(i18nT("res.io.calc.mag"))}</h5>`;
        magKeys.forEach((k) => {
          htmlN += ioOutputBlock(magCalc[k], k.toUpperCase());
        });
      }
    }
    htmlN += `</div>`;
    bodyN.innerHTML = htmlN;

    const prepD = dp.preparation || {};
    const calcD = dp.calculation || {};
    const jobLabel = data.doped_job_material || resultsDopedMaterialName() || material || "";
    let htmlD = `<div class="results-mat-block results-mat-block-doped" data-mat="${escAttr(jobLabel || "doped")}">`;
    htmlD += `<h4 class="results-mat-heading">${esc(i18nT("res.org.block_doped", { mat: jobLabel || "—" }))}</h4>`;
    htmlD +=
      `<p class="meta">${esc(i18nT("res.io.open_hint"))}</p>` +
      `<p class="meta"><strong>${esc(i18nT("res.io.doped.inputs"))}</strong> ` +
      (jobLabel
        ? outputPathPlain(`inputs/materiaux/${jobLabel}/`)
        : outputPathPlain(data.inputs_dir)) +
      `<span class="meta"> (dossiers dop_* · NM + mag/)</span></p>`;
    const phases = prepD.phases || [];
    if (!phases.length) {
      htmlD += `<p class="meta">${esc(i18nT("res.io.doped.empty"))}</p>`;
    } else {
      phases.forEach((ph) => {
        const phaseMat = jobLabel || invMat;
        const genHint = (ph.formula_general || ph.file_prefix || "").trim();
        htmlD += `<section class="results-dop-phase">`;
        htmlD += `<h5 class="result-sub">${esc(ph.phase_id)}${genHint ? ` · <code>${esc(genHint)}</code>` : ""}</h5>`;
        htmlD += `<p class="meta">${outputPathPlain(ph.inputs_path)}</p>`;
        htmlD += `<h6 class="result-sub">${esc(i18nT("res.io.doped.nm_chain"))}</h6>`;
        const nmRows = ioInputsTableRows(ph.inputs || [], {
          material: phaseMat,
          phaseId: ph.phase_id || "",
        });
        htmlD += nmRows
          ? `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table">${ioInputsTableHead()}<tbody>${nmRows}</tbody></table></div>`
          : `<p class="meta">—</p>`;
        const magOrdersD = ph.magnetic_orders || [];
        if (magOrdersD.length) {
          htmlD += `<h6 class="result-sub">${esc(i18nT("res.io.prep.mag"))} · nspin 2 / 4</h6>`;
          htmlD += `<p class="meta">${outputPathPlain(ph.mag_path || (ph.inputs_path || "") + "mag/")}</p>`;
          magOrdersD.forEach((mo) => {
            htmlD += `<p class="meta"><strong>${esc(mo.order)}</strong></p>`;
            const rows = ioInputsTableRows(mo.inputs || [], {
              material: phaseMat,
              phaseId: ph.phase_id || "",
              magOrder: mo.order || "",
            });
            if (rows) {
              htmlD += `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table">${ioInputsTableHead()}<tbody>${rows}</tbody></table></div>`;
            }
          });
        } else {
          htmlD += `<p class="meta warn">${esc(i18nT("res.io.doped.mag_missing"))}</p>`;
        }
        htmlD += `</section>`;
      });
    }
    if (!PHASES_PREP_ONLY) {
      htmlD += `<h5 class="result-sub">${esc(i18nT("res.io.calc.doped"))}</h5>`;
      const calcPhases = calcD.phases || [];
      if (!calcPhases.length) {
        htmlD += `<p class="meta">${esc(i18nT("res.io.outputs.doped_pending"))}</p>`;
      } else {
        calcPhases.forEach((row) => {
          htmlD += ioOutputBlock(row.outputs, row.phase_id);
        });
      }
    }
    htmlD += `</div>`;
    bodyD.innerHTML = htmlD;
    bindIoInventoryOpenClicks(bodyN);
    bindIoInventoryOpenClicks(bodyD);
    paintResultsMaterialOrg(data);
    paintResultsBrowseChrome();
  }

  function resultsNondopedMaterialNames() {
    const browse = getResultsBrowseMat();
    if (browse) {
      if (/_doped$/i.test(browse)) {
        const base = browse.replace(/_doped$/i, "");
        return base ? [base] : [browse];
      }
      return [browse];
    }
    const intent = sessionStudyIntent();
    if (intent === "doping" || isDualStudyIntent()) {
      const a = getPhaseDopingParentA() || getDualMaterialA() || "";
      const b = getPhaseDopingParentB() || getDualMaterialB() || "";
      const names = [];
      if (a) names.push(a);
      if (b && normalizeMaterialInput(b) !== normalizeMaterialInput(a)) names.push(b);
      if (names.length) return names;
    }
    const single =
      (intent === "single" && (getDraftMaterial() || material || ($("material-select")?.value || "").trim())) ||
      (!isDualStudyIntent() && (material || getDraftMaterial() || ""));
    return single ? [normalizeMaterialInput(single) || single] : [];
  }

  function resultsDopedMaterialName() {
    const browse = getResultsBrowseMat();
    if (browse) {
      if (/_doped$/i.test(browse)) return browse;
      const dopedGuess = `${browse}_doped`;
      const known = (materialsCache || []).some(
        (m) => normalizeMaterialInput(m.name) === normalizeMaterialInput(dopedGuess)
      );
      if (known) return dopedGuess;
      return dopedGuess;
    }
    if (sessionStudyIntent() !== "doping" && !getPhaseDopingJobMaterial()) {
      const job = studyJobMaterial();
      if (job && /_doped$/i.test(job)) return job;
      return "";
    }
    return (
      getPhaseDopingJobMaterial() ||
      studyJobMaterial() ||
      ($("material-final")?.value || "").trim() ||
      ""
    );
  }

  function paintResultsMaterialOrg(data) {
    const browse = getResultsBrowseMat();
    const nondopeNames = resultsNondopedMaterialNames();
    const dopedName =
      (data && data.doped_job_material) ||
      resultsDopedMaterialName() ||
      "";
    const nameN = $("results-mat-name-nondope");
    const nameD = $("results-mat-name-doped");
    const chipN = $("results-mat-chip-nondope");
    const chipD = $("results-mat-chip-doped");
    const titleN = $("res-io-nondope-title");
    const titleD = $("res-io-doped-title");
    const nondopeLabel = nondopeNames.length ? nondopeNames.join(" · ") : browse || "—";
    const dopedLabel = dopedName || (browse ? `${browse}_doped` : "—");
    if (nameN) nameN.textContent = nondopeLabel;
    if (nameD) nameD.textContent = dopedLabel;
    if (chipN) chipN.classList.toggle("is-empty", !browse);
    if (chipD) chipD.classList.toggle("is-empty", !browse);
    if (titleN) {
      titleN.textContent = browse
        ? i18nT("res.io.nondope.title_mat", { mat: nondopeLabel })
        : i18nT("res.io.nondope.title");
    }
    if (titleD) {
      titleD.textContent = browse
        ? i18nT("res.io.doped.title_mat", { mat: dopedLabel })
        : i18nT("res.io.doped.title");
    }
    paintResultsBrowseChrome();
  }

  function paintResultsInventoryChrome() {
    paintResultsMaterialOrg();
    paintResultsBrowseChrome();
  }

  async function fetchParentIoPrepSlice(matName, labelKey) {
    const m = String(matName || "").trim();
    if (!m) return "";
    try {
      const data = await api(`/api/materials/${encodeURIComponent(m)}/io-profile`);
      if (!data?.ok || !data.profile) return "";
      const prep = data.profile.nondoped?.preparation || {};
      let html = `<div class="results-mat-block" data-mat="${escAttr(m)}">`;
      html += `<h4 class="results-mat-heading">${esc(i18nT(labelKey, { mat: m }))}</h4>`;
      html += `<p class="meta"><strong>${esc(i18nT("res.io.inputs_root"))}</strong> ${outputPathPlain(data.inputs_dir || `inputs/materiaux/${m}/`)}</p>`;
      if (prep.cif) html += `<p class="meta">CIF : ${outputPathPlain(prep.cif)}</p>`;
      const nmRows = ioInputsTableRows(prep.nm_chain || [], { material: m });
      html += `<h6 class="result-sub">${esc(i18nT("res.io.prep.nm"))}</h6>`;
      html += nmRows
        ? `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table">${ioInputsTableHead()}<tbody>${nmRows}</tbody></table></div>`
        : `<p class="meta">—</p>`;
      const magOrders = prep.magnetic_orders || [];
      if (magOrders.length) {
        html += `<h6 class="result-sub">${esc(i18nT("res.io.prep.mag"))}</h6>`;
        magOrders.forEach((mo) => {
          html += `<p class="meta"><strong>${esc(mo.order)}</strong></p>`;
          const rows = ioInputsTableRows(mo.inputs || [], {
            material: m,
            magOrder: mo.order || "",
          });
          if (rows) {
            html += `<div class="mag-table-scroll"><table class="phase-table mag-cmp-table">${ioInputsTableHead()}<tbody>${rows}</tbody></table></div>`;
          }
        });
      }
      html += `</div>`;
      return html;
    } catch (_) {
      return `<div class="results-mat-block"><h4 class="results-mat-heading">${esc(i18nT(labelKey, { mat: m }))}</h4><p class="meta">—</p></div>`;
    }
  }

  async function refreshMaterialIoProfile() {
    paintResultsInventoryChrome();
    const browseMat = getResultsBrowseMat();
    if (!browseMat) {
      paintMaterialIoProfile(null);
      paintResultsMaterialOrg();
      return;
    }
    const nondopeMat = /_doped$/i.test(browseMat)
      ? browseMat.replace(/_doped$/i, "") || browseMat
      : browseMat;
    const dopedMat = /_doped$/i.test(browseMat) ? browseMat : `${browseMat}_doped`;
    if (!resultsBrowseKind) {
      paintResultsMaterialOrg({
        material: nondopeMat,
        doped_job_material: dopedMat,
      });
      return;
    }
    const wantDoped = resultsBrowseKind === "doped";
    try {
      let data;
      if (wantDoped) {
        data = await api(`/api/materials/${encodeURIComponent(dopedMat)}/io-profile`);
        if (!data?.ok) {
          data = await api(`/api/materials/${encodeURIComponent(browseMat)}/io-profile`);
        }
        data = Object.assign({}, data || {}, {
          ok: !!(data && data.ok),
          material: nondopeMat,
          doped_job_material: dopedMat,
        });
      } else {
        data = await api(`/api/materials/${encodeURIComponent(nondopeMat)}/io-profile`);
        data = Object.assign({}, data || {}, {
          ok: !!(data && data.ok),
          material: nondopeMat,
          doped_job_material: dopedMat,
        });
      }
      paintMaterialIoProfile(data);
    } catch (e) {
      paintMaterialIoProfile({ ok: false, error: String(e.message || e) });
    }
  }

  function outputBranchHtml(branch, title) {
    if (!branch || !branch.dir) return "";
    const parts = [];
    parts.push(`<h5 class="result-sub">${esc(title)}</h5>`);
    parts.push(`<p class="meta output-layout-dir">${outputPathLink(branch.dir)}/</p>`);
    const fileRows = [];
    const pw = branch.pw_out || {};
    Object.keys(pw).forEach((k) => {
      fileRows.push(`<li><span class="output-tag">${esc(k)}</span> ${outputPathLink(pw[k])}</li>`);
    });
    const wit = branch.witness || {};
    Object.keys(wit).forEach((k) => {
      fileRows.push(`<li><span class="output-tag">witness ${esc(k)}</span> ${outputPathLink(wit[k])}</li>`);
    });
    const an = branch.analysis || {};
    Object.keys(an).forEach((k) => {
      fileRows.push(`<li><span class="output-tag">${esc(k)}</span> ${outputPathLink(an[k])}</li>`);
    });
    if (fileRows.length) {
      parts.push(`<ul class="output-layout-files">${fileRows.join("")}</ul>`);
    } else if (!branch.exists) {
      parts.push(`<p class="meta">${i18nT("res.empty")}</p>`);
    } else {
      parts.push(`<p class="meta">—</p>`);
    }
    return parts.join("");
  }

  function paintOutputLayout(layout) {
    const body = $("res-output-layout-body");
    const card = $("res-output-layout-card");
    if (!body) return;
    if (!layout || !layout.canonical) {
      body.innerHTML = `<p class="meta">${i18nT("res.outputs.empty")}</p>`;
      if (card) card.hidden = !material;
      updateOutputFooter(null);
      return;
    }
    if (card) card.hidden = false;
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    const guide = lang === "en" ? (layout.guide_en || layout.guide_fr) : (layout.guide_fr || "");
    let html = guide ? `<p class="meta output-layout-guide"><strong>${i18nT("res.outputs.guide")} :</strong> ${esc(guide)}</p>` : "";
    html += `<p class="meta">${outputPathLink(layout.inputs_dir)}/</p>`;
    html += outputBranchHtml(layout.canonical.nm, i18nT("res.outputs.nm"));
    const mag = layout.magnetism || {};
    const magKeys = Object.keys(mag);
    if (magKeys.length) {
      html += `<h5 class="result-sub">${i18nT("res.outputs.mag")}</h5>`;
      magKeys.forEach((ord) => {
        const lab = ord === "fm" ? "FM" : ord.toUpperCase();
        html += outputBranchHtml(mag[ord], lab);
      });
    }
    const leg = layout.legacy_other || [];
    if (leg.length) {
      html += `<p class="meta mag-note"><strong>${i18nT("res.outputs.legacy")}</strong></p><ul class="output-layout-files">`;
      leg.forEach((row) => {
        const note = lang === "en" ? (row.note_en || row.note_fr) : (row.note_fr || "");
        html += `<li>${outputPathLink(row.dir)}/${note ? ` <span class="meta">— ${esc(note)}</span>` : ""}</li>`;
      });
      html += `</ul>`;
    }
    body.innerHTML = html;
    updateOutputFooter(layout);
  }

  function updateOutputFooter(layout) {
    const foot = $("app-footer-paths");
    if (!foot) return;
    if (!layout || !layout.canonical) {
      foot.textContent = i18nT("footer.optim");
      return;
    }
    const nm = (layout.canonical.nm && layout.canonical.nm.dir) || "";
    const inp = layout.inputs_dir || "";
    foot.textContent = nm ? `${inp}/ · ${nm}/` : `${inp}/`;
  }

  function paintThermoComparison(cmp) {
    const body = $("res-thermo-body");
    if (!body) return;
    const rows = (cmp && cmp.orders) || [];
    if (!rows.length) {
      body.innerHTML = `<p class="meta">${i18nT("res.thermo.empty")}</p>`;
      return;
    }
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    const disc = lang === "en" ? (cmp.disclaimer_en || cmp.disclaimer_fr) : (cmp.disclaimer_fr || "");
    const head = `<tr><th>${i18nT("res.thermo.col.order") || "Ordre"}</th><th>Gap (eV)</th><th>N(E<sub>F</sub>)</th><th>${i18nT("res.thermo.col.e_atom")}</th><th>${i18nT("res.thermo.col.e_form")}</th><th title="${escAttr(i18nT("res.thermo.col.e_coh.title"))}">${i18nT("res.thermo.col.e_coh")}</th><th>${i18nT("res.thermo.col.e_mag")}</th><th>H (eV/at)</th><th>G (eV/at)</th><th>NSCF</th></tr>`;
    const lines = rows.map((r) => {
      const label = r.order === "nm" ? "NM" : (r.short || r.order || "").toString().toUpperCase();
      const star = r.is_reference ? " ★" : "";
      const gap = r.band_gap_ev != null ? Number(r.band_gap_ev).toFixed(3) : "—";
      const dos = r.dos_at_ef != null ? Number(r.dos_at_ef).toFixed(3) : "—";
      const eAtom = r.energy_per_atom_ev != null ? fmtEnergyEv(r.energy_per_atom_ev) : "—";
      const eForm = r.formation_energy_ev_per_atom != null ? fmtDeltaEv(r.formation_energy_ev_per_atom) : "—";
      const eMag = r.mag_formation_vs_nm_ev_per_atom != null
        ? fmtDeltaEv(r.mag_formation_vs_nm_ev_per_atom)
        : (r.order === "nm" ? "0.0000" : "—");
      return `<tr class="${r.is_reference ? "phase-row-stable" : ""}"><td>${label}${star}</td><td class="num-hi">${gap}</td><td class="num-hi">${dos}</td><td class="num-hi">${eAtom}</td><td class="num-hi">${eForm}</td><td class="num-hi">${fmtThermo(r.cohesive_energy_ev_per_atom)}</td><td class="num-hi">${eMag}</td><td class="num-hi">${fmtThermo(r.enthalpy_ev_per_atom)}</td><td class="num-hi">${fmtThermo(r.gibbs_free_energy_ev_per_atom)}</td><td>${r.nscf_converged ? "✓" : "…"}</td></tr>`;
    });
    const sum = lang === "en" ? (cmp.summary_en || cmp.summary_fr) : (cmp.summary_fr || "");
    body.innerHTML = `${sum ? `<p class="meta">${esc(sum)}</p>` : ""}${disc ? `<p class="meta mag-note">${esc(disc)}</p>` : ""}<div class="mag-table-scroll"><table class="phase-table mag-cmp-table"><thead>${head}</thead><tbody>${lines.join("")}</tbody></table></div>`;
  }

  function paintElectronicResults(elec) {
    const body = $("res-elec-body");
    if (!body) return;
    const orders = (elec && elec.orders) || [];
    if (!orders.length) {
      body.innerHTML = `<p class="meta">${i18nT("res.elec.empty")}</p>`;
      return;
    }
    const lang = window.qeI18n && window.qeI18n.getLang ? window.qeI18n.getLang() : "fr";
    const head = `<tr><th>Ordre</th><th>Type</th><th>N(E<sub>F</sub>) / u.c.</th><th>Gap (eV)</th><th>E<sub>F</sub> (eV)</th><th>M<sub>tot</sub></th><th>NSCF</th></tr>`;
    const lines = orders.map((r) => {
      const label = r.order === "nm" ? "NM" : (r.short || r.order || "").toString().toUpperCase();
      const etype = lang === "en"
        ? (r.electronic_type_en || r.electronic_type || "—")
        : (r.electronic_type || r.electronic_type_en || "—");
      const dos = r.dos_at_ef != null ? Number(r.dos_at_ef).toFixed(3) : "—";
      const gap = r.band_gap_ev != null ? Number(r.band_gap_ev).toFixed(3) : "—";
      const ef = r.fermi_ev != null ? Number(r.fermi_ev).toFixed(4) : "—";
      const star = r.is_reference ? " ★" : "";
      return `<tr class="${r.is_reference ? "phase-row-stable" : ""}"><td>${label}${star}</td><td>${etype}</td><td class="num-hi">${dos}</td><td class="num-hi">${gap}</td><td class="num-hi">${ef}</td><td>${fmtMagNum(r.tot_mag, 4)}</td><td>${r.nscf_converged ? "✓" : "—"}</td></tr>`;
    });
    const stLab = (elec && elec.structure_label) ? `<p class="meta">${esc(elec.structure_label)}</p>` : "";
    body.innerHTML = `${stLab}<div class="mag-table-scroll"><table class="phase-table mag-cmp-table"><thead>${head}</thead><tbody>${lines.join("")}</tbody></table></div>`;
  }

  function paintResultsOverview(study) {
    if (!study) return;
    const conc = $("res-conclusion-body");
    if (conc && study.conclusion) conc.textContent = study.conclusion;
    const magLine = $("res-mag-structure-line");
    if (magLine) {
      magLine.textContent = i18nT("res.mag.structure", {
        structure: study.stable_phase_label || "—",
      });
    }
    const magSnap = study.magnetism_stable || study.magnetism;
    paintMagProtocolPanel(magSnap && magSnap.orders ? magSnap : null);
    let thermoCmp = study.thermodynamic_comparison;
    if (!(thermoCmp && thermoCmp.orders && thermoCmp.orders.length) && study.electronic) {
      const ref = study.electronic.reference_order || (study.magnetism_stable || study.magnetism || {}).reference_order;
      thermoCmp = {
        ...(thermoCmp || {}),
        reference_order: ref,
        orders: (study.electronic.orders || []).map((r) => ({
          order: r.order,
          short: r.short,
          is_reference: r.is_reference,
          energy_per_atom_ev: r.energy_per_atom_ev,
          formation_energy_ev_per_atom: r.formation_energy_ev_per_atom,
          mag_formation_vs_nm_ev_per_atom: r.mag_formation_vs_nm_ev_per_atom,
          cohesive_energy_ev_per_atom: r.cohesive_energy_ev_per_atom,
          enthalpy_ev_per_atom: r.enthalpy_ev_per_atom,
          gibbs_free_energy_ev_per_atom: r.gibbs_free_energy_ev_per_atom,
          band_gap_ev: r.band_gap_ev,
          dos_at_ef: r.dos_at_ef,
          electronic_type: r.electronic_type,
          electronic_type_en: r.electronic_type_en,
          nscf_converged: r.nscf_converged,
        })),
        disclaimer_fr: (thermoCmp && thermoCmp.disclaimer_fr) || (
          "Cohésion, enthalpie, Gibbs et entropie : estimations pédagogiques "
          + "à partir de l'énergie SCF (sans phonons). Gap et N(E_F) : NSCF."
        ),
        disclaimer_en: (thermoCmp && thermoCmp.disclaimer_en) || (
          "Cohesion, enthalpy, Gibbs and entropy: pedagogical estimates from "
          + "SCF energy (no phonons). Gap and N(E_F): NSCF."
        ),
      };
    }
    paintThermoComparison(thermoCmp);
    paintElectronicResults(study.electronic);
  }

  async function refreshResults() {
    if (PHASES_PREP_ONLY) {
      paintPhasesPrepOnlyChrome();
      // Préremplir le browse depuis la session si vide
      if (!getResultsBrowseMat()) {
        const seed =
          material ||
          getDraftMaterial() ||
          resultsDopedMaterialName() ||
          resultsNondopedMaterialNames()[0] ||
          "";
        if (seed) setResultsBrowseMat(seed, { keepKind: true });
      } else {
        paintResultsBrowseChrome();
        paintResultsMaterialOrg();
      }
      await refreshMaterialIoProfile().catch(() => {});
      stopResultsAutoRefresh();
      return;
    }
    if (!material) {
      for (const kind of ["vc-relax", "relax", "scf"]) {
        const body = $("result-body-" + kind);
        if (body) body.innerHTML = `<p class="meta">${i18nT("opt.status.pick_mat")}</p>`;
        const state = $("result-state-" + kind);
        if (state) { state.textContent = "—"; state.className = "result-state"; }
      }
      const line = $("results-mat-line");
      if (line) line.textContent = "";
      const prev = $("scf-input-preview");
      if (prev) prev.textContent = "";
      const note = $("scf-input-note");
      if (note) note.textContent = i18nT("res.scfinput.pick");
      ["res-io-nondope-body", "res-io-doped-body", "res-phases-body", "mag-stability-body-results", "res-thermo-body", "res-elec-body", "res-output-layout-body", "res-lattice-body", "res-postscf-body", "res-elastic-body", "res-hubbard-body", "res-files-body", "result-body-relax-main"].forEach((id) => {
        const el = $(id);
        if (el) el.innerHTML = `<p class="meta">—</p>`;
      });
      const magProto = $("res-mag-protocol-card");
      if (magProto) magProto.hidden = true;
      paintOutputLayout(null);
      paintPostscfElectronic(null);
      paintElasticResults(null);
      paintHubbardResults(null);
      lastScfSuggestion = null;
      return;
    }
    try {
      const data = await api(`/api/materials/${encodeURIComponent(material)}/results${phaseQuery()}`);
      await refreshMaterialIoProfile().catch(() => {});
      paintResults(data);
      if (data.study) {
        paintStudyGuide(data.study);
        paintResultsOverview(data.study);
      }
      await refreshPhaseStability().catch(() => {});
      await refreshResultsExtras().catch(() => {});
      if (material) {
        api(`/api/materials/${encodeURIComponent(material)}/mag-orders${magOrdersQuery({ light: true })}`)
          .then((mag) => paintMagProtocolPanel(mag))
          .catch(() => {});
      }
      scheduleResultsAutoRefresh(data);
    } catch (e) {
      const msg = String(e.message || e);
      const html = `<p class="meta warn">${esc(i18nT("res.results.load_failed", { msg }))}</p>`;
      const scfBody = $("result-body-scf");
      if (scfBody) scfBody.innerHTML = html;
      paintLatticeMechanicsTable({ rows: [], message_fr: msg, message_en: msg });
      log("log-opt", msg, false);
    }
  }

  // Auto-refresh de l'onglet Résultats tant qu'un calcul tourne (2.5 s)
  let resultsAutoTimer = null;

  function stopResultsAutoRefresh() {
    if (resultsAutoTimer) {
      clearTimeout(resultsAutoTimer);
      resultsAutoTimer = null;
    }
  }

  function scheduleResultsAutoRefresh(data) {
    stopResultsAutoRefresh();
    const steps = (data && data.steps) || {};
    const anyRunning = ["vc-relax", "relax", "scf", "nscf"].some((k) => steps[k] && steps[k].running);
    if (anyRunning && sessionResultsTabVisible()) {
      resultsAutoTimer = setTimeout(() => {
        refreshResults().catch(() => {});
      }, 2500);
    }
  }

  // (Re)planifie quand on revient sur l'onglet Résultats
  function onTabShownReschedule() {
    if (material) refreshResults().catch(() => {});
  }

  async function stopRun(kind, magOrder) {
    if (!material) return;
    const label = magOrder
      ? `SCF ${String(magOrder).toUpperCase()}`
      : String(kind || "").toUpperCase();
    if (!window.confirm(i18nT("confirm.stop", { kind: label }))) return;
    runPollSuppressUntil = Date.now() + 15000;
    settleUiAfterUserStop(kind, magOrder);
    try {
      const body = withPhaseBody({});
      if (jobId) body.job_id = jobId;
      if (magOrder) body.mag_order = magOrder;
      const data = await api(`/api/materials/${encodeURIComponent(material)}/stop/${encodeURIComponent(kind)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      log("log-opt", data.message || data, data.ok !== false);
      await refreshOptimStatus().catch(() => {});
      await refreshMagOrders().catch(() => {});
      await refreshResults().catch(() => {});
      await refreshRuns().catch(() => {});
      settleUiAfterUserStop(kind, magOrder);
      if (PHASES_ONLY) paintPhasesCalcStopBar();
    } catch (e) {
      log("log-opt", String(e.message || e), false);
    }
  }

  function onResultsClick(ev) {
    const target = ev.target && ev.target.closest ? ev.target : null;
    if (!target) return;
    const stopBtn = target.closest(".btn-run-stop");
    if (stopBtn) {
      stopRun(stopBtn.dataset.kind, stopBtn.dataset.magOrder || "").catch((e) => alert(e.message));
    }
  }

  /** Régénère inputs/<Mat>/<Mat>-scf.in depuis RELAX + tpl vc-relax/relax (source de vérité). */
  async function syncScfFromChain() {
    if (!material) return null;
    const data = await api(`/api/materials/${encodeURIComponent(material)}/rebuild-scf`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(withPhaseBody()),
    });
    if (data.ok) {
      log("log-opt", i18nT("chain.scf.synced", { path: data.path || "" }), true);
    } else {
      log("log-opt", data.error || i18nT("chain.scf.pending_relax"), false);
    }
    await refreshOptimStatus().catch(() => {});
    await refreshResults().catch(() => {});
    return data;
  }

  async function applyScfSuggestion() {
    if (!material) return;
    if (lastScfSuggestion && lastScfSuggestion.pending_relax) {
      alert(i18nT("chain.scf.pending_relax"));
      return;
    }
    await syncScfFromChain();
  }

  function downloadScfInput() {
    const content = currentScfContent();
    if (!content) return;
    const blob = new Blob([content], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${material || "material"}-scf.in`;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  function setScfMode(mode) {
    scfMode = mode === "zero" ? "zero" : "auto";
    localStorage.setItem("optimqe.scfmode", scfMode);
    const sel = $("scf-mode-select");
    if (sel) sel.value = scfMode;
    const prev = $("scf-input-preview");
    if (prev && lastScfSuggestion) prev.textContent = currentScfContent();
    // Note mise à jour sans recharger toute la page
    const note = $("scf-input-note");
    if (note && lastScfSuggestion) {
      const sug = lastScfSuggestion;
      let txt = i18nT("res.scfinput.from", { kind: kindLabel(sug.from) });
      if (scfMode === "auto" && sug.ibrav != null) {
        txt += ` · ibrav = ${sug.ibrav}`;
        if (sug.ibrav_label) txt += ` — ${sug.ibrav_label}`;
        if (sug.celldm) {
          const cd = fmtCelldm(sug.celldm);
          if (cd) txt += ` · ${cd} bohr`;
        }
      } else if (scfMode === "zero") {
        txt += ` · ${i18nT("res.scfinput.mode.zero")}`;
      }
      note.textContent = txt;
    }
  }

  // ------------------------------------------------------------------
  // Init
  // ------------------------------------------------------------------
  function bind(id, ev, fn) {
    const el = $(id);
    if (el) el.addEventListener(ev, fn);
  }

  /** Place le panneau auteur en fixed sous le summary (évite clipping overflow). */
  function placeAuthorPopover(detailsEl) {
    if (!detailsEl || !detailsEl.open) return;
    const summary = detailsEl.querySelector("summary");
    const panel = detailsEl.querySelector(".header-author-mail, .accueil-author-detail");
    if (!summary || !panel) return;
    const r = summary.getBoundingClientRect();
    const pad = 8;
    const width = Math.min(panel.offsetWidth || 248, window.innerWidth - pad * 2);
    let left = r.right - width;
    if (left < pad) left = pad;
    if (left + width > window.innerWidth - pad) left = Math.max(pad, window.innerWidth - pad - width);
    let top = r.bottom + 6;
    panel.style.left = `${Math.round(left)}px`;
    panel.style.top = `${Math.round(top)}px`;
    panel.style.right = "auto";
    // Si dépasse en bas, remonter au-dessus du bouton
    requestAnimationFrame(() => {
      const pr = panel.getBoundingClientRect();
      if (pr.bottom > window.innerHeight - pad) {
        const above = r.top - pr.height - 6;
        panel.style.top = `${Math.round(Math.max(pad, above))}px`;
      }
    });
  }

  function initAuthorPopovers() {
    const nodes = document.querySelectorAll("details.header-author, details.accueil-author");
    nodes.forEach((d) => {
      d.addEventListener("toggle", () => {
        if (d.open) placeAuthorPopover(d);
      });
    });
    window.addEventListener(
      "resize",
      () => {
        document.querySelectorAll("details.header-author[open], details.accueil-author[open]").forEach(placeAuthorPopover);
      },
      { passive: true }
    );
    window.addEventListener(
      "scroll",
      () => {
        document.querySelectorAll("details.header-author[open], details.accueil-author[open]").forEach(placeAuthorPopover);
      },
      { passive: true, capture: true }
    );
  }

  function initSessionFromStorage() {
    const storedMat = localStorage.getItem("optimqe.material") || "";
    const storedJob = localStorage.getItem("optimqe.job") || "";
    const intentSel = $("session-study-intent");
    const storedIntent = localStorage.getItem("optimqe.sessionIntent") || "single";
    if (intentSel) intentSel.value = storedIntent;
    setSessionDopingCase(localStorage.getItem("optimqe.dopingCase") || "endpoints", { skipPaint: true });
    const inpA = $("material-select-a");
    const inpB = $("material-select-b");
    const inpFinal = $("material-final");
    if (inpA) inpA.value = localStorage.getItem("optimqe.materialA") || "";
    if (inpB) inpB.value = localStorage.getItem("optimqe.materialB") || "";
    if ($("doping-dopant-element")) {
      $("doping-dopant-element").value = localStorage.getItem("optimqe.dopingElement") || "";
    }
    paintPhaseStudyMode();
    dualMaterialsValidated = localStorage.getItem("optimqe.dualValidated") === "1";
    singleMaterialValidated = localStorage.getItem("optimqe.singleValidated") === "1";
    sessionConfirmed = localStorage.getItem("optimqe.sessionConfirmed") === "1" && !!storedMat;
    if (!sessionConfirmed) {
      singleMaterialValidated = false;
      dualMaterialsValidated = false;
      localStorage.setItem("optimqe.singleValidated", "0");
      localStorage.setItem("optimqe.dualValidated", "0");
    }
    const inp = $("material-select");
    if (isDualStudyIntent()) {
      if (inpFinal && storedMat) inpFinal.value = storedMat;
    } else if (inp && storedMat) inp.value = storedMat;
    if (dualMaterialsValidated && $("session-dual-compose")) {
      $("session-dual-compose").hidden = false;
    }
    paintSessionIntentUI();
    if (sessionConfirmed) {
      singleMaterialValidated = true;
      dualMaterialsValidated = true;
    }
    paintStructurePanelVisibility();
    phaseId = localStorage.getItem("optimqe.phase") || "";
    if (sessionConfirmed) {
      material = normalizeMaterialInput(storedMat);
      jobId = storedJob;
      setWorkspaceActive(true);
    } else {
      setWorkspaceActive(false);
    }
    paintSessionStatus();
    paintJobPanel();
    paintSessionStepHint();
  }

  function resetPhasesHorizontalScroll() {
    if (!PHASES_ONLY) return;
    const root = document.documentElement;
    const body = document.body;
    root.scrollLeft = 0;
    body.scrollLeft = 0;
    const shell = document.querySelector(".phases-app-shell");
    if (shell) shell.scrollLeft = 0;

    const isChrome =
      typeof navigator !== "undefined" &&
      /Chrome\//.test(navigator.userAgent) &&
      !/Edg\//.test(navigator.userAgent) &&
      !/OPR\//.test(navigator.userAgent);
    if (!isChrome) return;

    root.classList.add("phases-app-root");
    body.style.display = "block";
    body.style.width = "100%";
    body.style.maxWidth = "100%";
    body.style.marginLeft = "0";
    body.style.overflowX = "hidden";
    root.style.overflowX = "hidden";
    root.style.width = "100%";
    root.style.maxWidth = "100%";

    if (shell) {
      shell.style.marginLeft = "auto";
      shell.style.marginRight = "auto";
      shell.style.width = "min(100%, 1120px)";
      shell.style.maxWidth = "1120px";
      shell.style.overflowX = "hidden";
    }

    const vw = root.clientWidth;
    if (root.scrollWidth > vw + 2) {
      root.scrollLeft = 0;
      body.scrollLeft = 0;
      document.querySelectorAll(".mag-table-scroll, .table-scroll, .guide-table-wrap").forEach((box) => {
        box.style.maxWidth = "100%";
        box.style.overflowX = "auto";
      });
      document.querySelectorAll("table.results-table, table.phase-table, table.mag-cmp-table").forEach((tbl) => {
        if (tbl.closest("[hidden]") || tbl.closest(".phases-work-stash")) return;
        tbl.style.maxWidth = "100%";
      });
      document.querySelectorAll("select").forEach((sel) => {
        if (sel.closest(".phases-work-stash")) return;
        sel.style.maxWidth = "100%";
        sel.style.minWidth = "0";
      });
    }
  }

  function watchPhasesHorizontalOverflow() {
    if (!PHASES_ONLY) return;
    let t = 0;
    let lastFix = 0;
    const run = () => {
      window.clearTimeout(t);
      t = window.setTimeout(() => {
        const now = Date.now();
        if (now - lastFix < 500) return;
        lastFix = now;
        resetPhasesHorizontalScroll();
      }, 250);
    };
    const shell = document.querySelector(".phases-app-shell") || document.querySelector(".wrap");
    if (!shell) return;
    const obs = new MutationObserver(run);
    obs.observe(shell, { childList: true, subtree: true, attributes: true, attributeFilter: ["hidden"] });
    window.addEventListener("resize", run, { passive: true });
  }

  window.addEventListener("pageshow", () => resetPhasesHorizontalScroll());

  document.addEventListener("DOMContentLoaded", () => {
    resetPhasesHorizontalScroll();
    initSessionFromStorage();
    applyUrlSessionParams();
    if (applyUrlSessionParams._appliedMat) {
      material = normalizeMaterialInput(applyUrlSessionParams._appliedMat);
      if (isDualStudyIntent() && $("material-final")) $("material-final").value = material;
      else if ($("material-select")) $("material-select").value = material;
    }
    if (sessionConfirmed || singleMaterialValidated || dualMaterialsValidated) {
      refreshStructureSource().catch(() => {});
    }
    runTrackingSince = 0;
    const intentSel = $("session-study-intent");
    if (intentSel) {
      intentSel.addEventListener("change", () => {
        localStorage.setItem("optimqe.sessionIntent", intentSel.value);
        invalidateDualCompose();
        invalidateSingleMaterial();
        markSessionPending();
        paintSessionIntentUI();
        if (intentSel.value === "doping") {
          switchSessionSubTab("preparation", "prep-doped");
        } else if (sessionPrepSubTab === "prep-doped") {
          switchSessionSubTab("preparation", "prep-nondope");
        } else {
          paintPrepMatSubpanel(sessionPrepSubTab);
        }
        if (sessionConfirmed || singleMaterialValidated || dualMaterialsValidated) {
          refreshStructureSource().catch(() => {});
        }
      });
    }
    document.querySelectorAll('input[name="session-doping-case"]').forEach((radio) => {
      radio.addEventListener("change", () => {
        if (!radio.checked) return;
        invalidateDualCompose();
        invalidateSingleMaterial();
        markSessionPending();
        setSessionDopingCase(radio.value);
      });
    });
    bind("btn-validate-dual-materials", "click", () => {
      validateDualMaterials().catch((e) => alert(e.message));
    });
    bind("btn-validate-single-material", "click", () => {
      validateSingleMaterial().catch((e) => alert(e.message));
    });
    bind("session-cif-pick", "change", () => onSessionCifPickChange());
    bind("session-input-pick", "change", () => onSessionInputPickChange());
    bind("session-mag-order", "change", () => {
      onSessionMagOrderChange().catch((e) => alert(e.message));
    });
    bind("session-chain-nspin", "change", () => {
      onSessionChainNspinChange().catch((e) => alert(e.message));
    });
    bind("btn-generate-all-inputs", "click", () => generateAllInputsFromCif().catch((e) => alert(e.message)));
    paintSessionMagOrderOptions(["afm-g", "afm-a", "afm-b", "afm-c"]);
    paintGenerateInputsButtonLabel();
    const onSpinGalleryClick = (ev) => {
      const btn = ev.target.closest(".mag-spin-fig-card[data-order]");
      if (!btn) return;
      onMagSpinGalleryPick(btn.dataset.order);
    };
    $("session-mag-spin-gallery")?.addEventListener("click", onSpinGalleryClick);
    $("session-calc-mag-spin-gallery")?.addEventListener("click", onSpinGalleryClick);
    paintSessionMagSpinGallery();
    bind("session-dual-cif-target", "change", () => {
      paintDualCifSwitch();
      refreshDualStructureStatuses().catch(() => {});
    });
    bind("btn-dual-cif-a", "click", () => setDualCifTarget("a"));
    bind("btn-dual-cif-b", "click", () => setDualCifTarget("b"));
    const matInp = $("material-select");
    if (matInp) {
      matInp.addEventListener("keydown", (ev) => {
        if (ev.key === "Enter" && !isDualStudyIntent()) {
          ev.preventDefault();
          validateSingleMaterial().catch((e) => alert(e.message));
        }
      });
    }
    const wireMatDraft = (el, onDualSide) => {
      if (!el) return;
      const refresh = () => {
        markSessionPending();
        if (onDualSide) {
          invalidateDualCompose();
          localStorage.setItem(onDualSide === "b" ? "optimqe.materialB" : "optimqe.materialA", el.value);
          refreshDualStructureStatuses().catch(() => {});
        } else {
          invalidateSingleMaterial();
          refreshMaterialType(el.value).catch(() => {});
          refreshPhaseTypePanel(el.value).catch(() => {});
          paintSessionStepHint();
        }
        paintJobPanel();
      };
      el.addEventListener("input", refresh);
      el.addEventListener("change", () => {
        refresh();
        if (!onDualSide) applySpinToInputs({ silent: true }).catch(() => {});
      });
    };
    wireMatDraft($("material-select"));
    wireMatDraft($("material-select-a"), "a");
    wireMatDraft($("material-select-b"), "b");
    const syncDopingFromSessionMats = () => {
      if (sessionStudyIntent() !== "doping") return;
      syncPhaseDopingMaterials();
      paintPhaseDopingFormCompact();
      updateDopantSuggestions();
      refreshDopingHostElements().catch(() => {});
    };
    $("material-select-a")?.addEventListener("change", syncDopingFromSessionMats);
    $("material-select-b")?.addEventListener("change", syncDopingFromSessionMats);
    $("material-select-a")?.addEventListener("input", syncDopingFromSessionMats);
    $("material-select-b")?.addEventListener("input", syncDopingFromSessionMats);
    wireMatDraft($("material-final"));
    document.addEventListener("change", (ev) => {
      const sel = ev.target && ev.target.closest ? ev.target.closest("select.phase-select") : null;
      if (!sel) return;
      syncPhaseSelects(sel.value || "");
      if (sessionConfirmed && getDraftMaterial() === material) {
        onPhaseChangedKeepSession().catch(() => {});
      } else {
        markSessionPending();
        refreshPhaseTypePanel(getDraftMaterial()).catch(() => {});
      }
    });
    document.addEventListener("click", (ev) => {
      const purge = ev.target && ev.target.closest ? ev.target.closest(".btn-tab-purge") : null;
      if (purge) {
        purgeAndRefreshTab(purge.dataset.tab || "").catch((e) => alert(e.message));
        return;
      }
      const btn = ev.target && ev.target.closest ? ev.target.closest(".btn-new-phase") : null;
      if (!btn || btn.disabled) return;
      createNewPhase().catch((e) => alert(e.message));
    });
    bind("btn-new-job", "click", () => createNewJob().catch((e) => alert(e.message)));
    bind("btn-confirm-session", "click", () => confirmSession().catch((e) => alert(e.message)));
    bind("btn-phases-stop-calc", "click", () => {
      const btn = $("btn-phases-stop-calc");
      if (!btn || btn.hidden || !btn.dataset.kind) return;
      stopRun(btn.dataset.kind, btn.dataset.magOrder || "").catch((e) => alert(e.message));
    });
    bind("btn-session-change", "click", () => editSession());
    bind("btn-session-goto-mag", "click", () => goToMagOrder("fm"));
    $("jobs-board-body")?.addEventListener("click", (ev) => {
      const row = ev.target && ev.target.closest ? ev.target.closest("tr.jobs-board-row") : null;
      if (!row || ev.target.closest("a.run-out")) return;
      const mo = row.dataset.magOrder || "fm";
      const jid = row.dataset.jobId || "";
      const sel = $("job-select");
      if (sel && jid) sel.value = jid;
      applySelectedJob({ goFm: mo !== "nm", goTab: mo === "nm" ? "optimisation" : "" }).catch((e) => alert(e.message));
    });
    bind("job-select", "change", () => {
      syncJobSelectMirrors();
      paintJobPanel();
    });
    bind("job-select-dual", "change", () => {
      const primary = $("job-select");
      if (primary && $("job-select-dual")) primary.value = $("job-select-dual").value;
      paintJobPanel();
    });
    bind("btn-apply-job", "click", () => {
      applySelectedJob({ goFm: true }).catch((e) => alert(e.message));
    });
    bind("btn-optim-refresh", "click", () => {
      if (!requireSessionConfirmed()) return;
      refreshMaterials().catch(() => {});
      refreshJobs().catch((e) => alert(e.message));
      refreshJobsBoard({ force: true }).catch(() => {});
      refreshOptimStatus().catch((e) => alert(e.message));
    });
    bind("btn-jobs-board-refresh", "click", (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      if (!requireSessionConfirmed()) return;
      jobsBoardTs = 0;
      refreshJobsBoard({ force: true }).catch((e) => alert(e.message));
    });
    $("optim-cards")?.addEventListener("click", (ev) => {
      onChainFixClick(ev);
      const edit = ev.target && ev.target.closest ? ev.target.closest(".btn-optim-edit") : null;
      if (edit && edit.dataset.kind) {
        openOptimEditor(edit.dataset.kind).catch((e) => alert(e.message));
        return;
      }
      const chainRun = ev.target && ev.target.closest ? ev.target.closest(".btn-nm-chain-run") : null;
      if (chainRun && !chainRun.disabled && chainRun.dataset.kind) {
        runNmChainKind(chainRun.dataset.kind).catch((e) => alert(e.message));
        return;
      }
      const magEdit = ev.target && ev.target.closest ? ev.target.closest(".btn-mag-edit") : null;
      if (magEdit && magEdit.dataset.order) {
        if (magEdit.disabled) return;
        openMagEditor(magEdit.dataset.order, magEdit.dataset.kind || "scf").catch((e) => alert(e.message));
        return;
      }
      const magRun = ev.target && ev.target.closest ? ev.target.closest(".btn-mag-run") : null;
      if (magRun && magRun.dataset.order) {
        if (magRun.disabled) {
          const reason = magRunBlockedReason(magRun.dataset.order);
          if (reason) alert(reason);
          return;
        }
        runMagOrder(magRun.dataset.order, magRun.dataset.kind || "vc-relax").catch((e) => alert(e.message));
        return;
      }
      const magStop = ev.target && ev.target.closest ? ev.target.closest(".btn-mag-stop") : null;
      if (magStop && !magStop.hidden && magStop.dataset.order) {
        stopRun(magStop.dataset.kind || "scf", magStop.dataset.order).catch((e) => alert(e.message));
        return;
      }
      const stop = ev.target && ev.target.closest
        ? ev.target.closest(".btn-nm-chain-stop, .btn-optim-stop")
        : null;
      if (!stop || stop.hidden || !stop.dataset.kind) return;
      stopRun(stop.dataset.kind).catch((e) => alert(e.message));
    });
    document.addEventListener("click", onRunsClick);
    bind("optim-modal-close", "click", () => { $("optim-modal").hidden = true; });
    bind("optim-modal-save", "click", () => saveOptimEditor().catch((e) => alert(e.message)));
    $("optim-modal-text")?.addEventListener("input", () => {
      if (magEditOrder) paintOptimModalNspinAudit($("optim-modal-text").value, magEditOrder);
    });
    bind("optim-modal", "click", (ev) => {
      if (ev.target === $("optim-modal")) $("optim-modal").hidden = true;
    });

    const studySel = $("study-mode-select");
    if (studySel) {
      studySel.value = localStorage.getItem("optimqe.studyMode") || "auto";
      studySel.addEventListener("change", () => {
        localStorage.setItem("optimqe.studyMode", studySel.value);
        refreshStudyGuide().catch(() => {});
        if (currentTab() === "magnetisme") {
          refreshMagOrders({ autoPrepare: false, skipExtras: true }).catch(() => {});
        }
      });
    }
    document.querySelectorAll(".optim-tab").forEach((btn) => {
      if (btn.tagName === "A") {
        btn.addEventListener("click", (e) => {
          e.preventDefault();
          goPhasesApp();
        });
        return;
      }
      btn.addEventListener("click", () => {
        if (btn.dataset.sessionTab) return;
        switchTab(btn.dataset.tab);
      });
    });
    $("study-workflow-steps")?.addEventListener("click", (ev) => {
      const li = ev.target && ev.target.closest ? ev.target.closest("[data-tab-link]") : null;
      if (!li || !li.dataset.tabLink) return;
      if (li.dataset.tabLink === "phases") {
        goPhasesApp();
        return;
      }
      switchTab(li.dataset.tabLink);
    });
    bind("btn-scf-apply", "click", () => applyScfSuggestion().catch((e) => alert(e.message)));
    bind("btn-scf-download", "click", downloadScfInput);
    bind("btn-validate-type", "click", () => validatePhaseType().catch((e) => alert(e.message)));
    bind("phase-type-select", "change", () => {
      const btn = $("btn-validate-type");
      if (btn) btn.disabled = !sessionConfirmed || !($("phase-type-select")?.value);
    });
    bind("btn-detect-phase", "click", () => detectStartingPhase().catch((e) => alert(e.message)));
    bind("btn-validate-phase", "click", () => validateStartingPhase().catch((e) => alert(e.message)));
    bind("phase-start-name", "input", () => {
      const btn = $("btn-validate-phase");
      if (btn) btn.disabled = !sessionConfirmed || !(($("phase-start-name")?.value || "").trim());
    });
    bind("btn-gen-structures", "click", () => generateCrystalPhases().catch((e) => alert(e.message)));
    bind("btn-sqs-preview", "click", () => previewSqs().catch((e) => alert(e.message)));
    bind("btn-sqs-generate", "click", () => generateSqs().catch((e) => alert(e.message)));
    bind("btn-doping-preview", "click", () => previewDoping().catch((e) => alert(e.message)));
    bind("btn-doping-generate", "click", () => generateDopingPhases().catch((e) => alert(e.message)));
    bind("btn-refresh-ui", "click", () => {
      if (!window.confirm(i18nT("btn.refresh_ui.confirm"))) return;
      refreshClearInterface();
    });
    bind("btn-results-refresh", "click", () => {
      const btn = $("btn-results-refresh");
      const st = $("results-refresh-status");
      if (!getResultsBrowseMat()) {
        if (st) st.textContent = i18nT("res.refresh.need_mat");
        $("results-mat-select")?.focus();
        return;
      }
      if (btn) btn.disabled = true;
      if (st) st.textContent = i18nT("res.refresh.busy");
      Promise.resolve(refreshMaterials())
        .then(() => refreshResults())
        .then(() => {
          if (st) st.textContent = i18nT("res.refresh.done");
        })
        .catch((e) => {
          if (st) st.textContent = String(e.message || e);
          alert(e.message || String(e));
        })
        .finally(() => {
          if (btn) btn.disabled = false;
          paintResultsMaterialOrg();
          setTimeout(() => {
            if (st && st.textContent === i18nT("res.refresh.done")) st.textContent = "";
          }, 2500);
        });
    });
    bind("results-mat-chip-nondope", "click", () => setResultsBrowseKind("nondope"));
    bind("results-mat-chip-doped", "click", () => setResultsBrowseKind("doped"));
    const resMatInp = $("results-mat-select");
    if (resMatInp) {
      const applyBrowseMat = () => {
        const v = (resMatInp.value || "").trim();
        setResultsBrowseMat(v);
        if (v && resultsBrowseKind) refreshMaterialIoProfile().catch(() => {});
      };
      resMatInp.addEventListener("change", applyBrowseMat);
      resMatInp.addEventListener("keydown", (ev) => {
        if (ev.key === "Enter") {
          ev.preventDefault();
          applyBrowseMat();
        }
      });
    }
    bind("btn-results-mat-clear", "click", () => {
      setResultsBrowseMat("");
      const bodyN = $("res-io-nondope-body");
      const bodyD = $("res-io-doped-body");
      const empty = `<p class="meta">${esc(i18nT("res.browse.mat_hint"))}</p>`;
      if (bodyN) bodyN.innerHTML = empty;
      if (bodyD) bodyD.innerHTML = empty;
      const st = $("results-refresh-status");
      if (st) st.textContent = "";
    });
    bind("btn-doping-reset", "click", () => {
      // Réinitialiser le formulaire de dopage
      const jobInput = $("phase-doping-material");
      const parentA = $("phase-doping-parent-a");
      const parentB = $("phase-doping-parent-b");
      const hostSelect = $("doping-host-element");
      const dopantInput = $("doping-dopant-element");
      const customFrac = $("doping-frac-custom");
      const previewBody = $("doping-preview-body");
      const statusEl = $("doping-status");
      
      // Vider les champs
      if (jobInput) jobInput.value = "";
      if (parentA) parentA.value = "";
      if (parentB) parentB.value = "";
      if (hostSelect) hostSelect.value = "";
      if (dopantInput) dopantInput.value = "";
      if (customFrac) customFrac.value = "";
      
      // Décocher toutes les fractions
      document.querySelectorAll(".doping-frac:checked").forEach((cb) => {
        cb.checked = false;
      });
      
      // Vider l'aperçu et le statut
      if (previewBody) previewBody.innerHTML = '<p class="meta">—</p>';
      if (statusEl) {
        statusEl.textContent = "Formulaire réinitialisé. Veuillez sélectionner le matériau et l'élément à doper.";
        statusEl.className = "meta";
      }
      
      // Cacher le bloc de vérification
      const verifyBlock = $("doping-verify-block");
      if (verifyBlock) verifyBlock.hidden = true;
      
      // Décocher la vérification
      const verifyCheck = $("doping-verified-check");
      if (verifyCheck) verifyCheck.checked = false;
      
      updateDopantSuggestions();
      updateDopingActionsEnabled();
      updateDopingLaunchGate();
    });
    bind("doping-verified-check", "change", () => updateDopingLaunchGate());
    ["phase-doping-material", "phase-doping-parent-a", "phase-doping-parent-b"].forEach((id) => {
      bind(id, "input", () => {
        if (id === "phase-doping-parent-a" || id === "phase-doping-parent-b") {
          const el = $(id);
          if (el) el.dataset.userEdited = "1";
        }
        if (id === "phase-doping-material") {
          const el = $(id);
          if (el) el.dataset.userEdited = "1";
        }
        syncPhaseDopingMaterials();
        refreshDopingHostElements().catch(() => {});
      });
      bind(id, "change", () => {
        if (id === "phase-doping-material" || id === "phase-doping-parent-a" || id === "phase-doping-parent-b") {
          normalizeDopedJobFromParents({ silent: false });
        }
      });
    });
    bind("material-final", "change", () => {
      if (sessionStudyIntent() === "doping") normalizeDopedJobFromParents({ silent: false });
    });
    bind("doping-dopant-element", "change", () => {
      const v = ($("doping-dopant-element")?.value || "").trim();
      if (v) localStorage.setItem("optimqe.dopingElement", v);
      updateDopingActionsEnabled();
      paintPhaseDopingFormCompact();
    });
    bind("doping-host-element", "change", () => {
      const v = ($("doping-host-element")?.value || "").trim();
      if (v) localStorage.setItem("optimqe.dopingHostElement", v);
      const dopSel = $("doping-dopant-element");
      if (dopSel && dopSel.value === v) dopSel.value = "";
      updateDopantSuggestions();
      paintDopingHostModeHint();
      paintPhaseDopingFormCompact();
    });
    bind("doping-host-element-manual", "input", () => {
      const v = ($("doping-host-element-manual")?.value || "").trim();
      if (v) localStorage.setItem("optimqe.dopingHostElement", v);
      updateDopantSuggestions();
      paintDopingHostModeHint();
      updateDopingActionsEnabled();
      paintPhaseDopingFormCompact();
    });
    document.querySelectorAll(".doping-frac").forEach((el) => {
      el.addEventListener("change", () => updateDopingActionsEnabled());
    });
    bind("doping-frac-custom", "input", () => updateDopingActionsEnabled());
    bind("btn-structure-ai", "click", () => openStructureAdvice().catch((e) => alert(e.message)));
    bind("btn-structure-catalog", "click", () => openStructureAdvice({ showCatalog: true }).catch((e) => alert(e.message)));
    bind("structure-ai-close", "click", () => { $("structure-ai-modal").hidden = true; });
    bind("structure-ai-modal", "click", (ev) => {
      if (ev.target === $("structure-ai-modal")) $("structure-ai-modal").hidden = true;
    });
    bind("structure-ai-gen-selected", "click", () => {
      const keys = selectedStructureKeys();
      if (!keys.length) {
        alert(i18nT("phase.ai.pick_one"));
        return;
      }
      generateCrystalPhases(keys).catch((e) => alert(e.message));
    });
    bind("structure-ai-gen-reco", "click", async () => {
      try {
        const mat = material || getDraftMaterial();
        const data = await api(`/api/materials/${encodeURIComponent(mat)}/structure-advice${phaseQuery()}`);
        const keys = data.recommended_generatable || [];
        if (!keys.length) {
          alert(i18nT("phase.ai.none_gen"));
          return;
        }
        await generateCrystalPhases(keys);
      } catch (e) {
        alert(e.message);
      }
    });
    $("structure-catalog-body")?.addEventListener("click", (ev) => {
      const btn = ev.target && ev.target.closest ? ev.target.closest(".btn-catalog-mat") : null;
      if (!btn) return;
      const mat = btn.dataset.mat || "";
      if (!mat) return;
      const inp = $("material-select");
      if (inp) inp.value = mat;
      markSessionPending();
      refreshPhasesForDraft()
        .then(() => openStructureAdvice())
        .catch((e) => alert(e.message));
    });
    bind("btn-phase-chains-all", "click", () => runAllPhaseChains().catch((e) => alert(e.message)));
    $("doping-preview-body")?.addEventListener("click", (ev) => {
      if (onPhaseEditClick(ev)) return;
    });
    $("phase-stability-body")?.addEventListener("click", (ev) => {
      onChainFixClick(ev);
      if (onPhaseEditClick(ev)) return;
      const chain = ev.target && ev.target.closest ? ev.target.closest(".btn-phase-chain") : null;
      if (chain && !chain.disabled) {
        runPhaseChain(chain.dataset.phase || "", chain.dataset.kind || getPhaseChainStartKind()).catch((e) => alert(e.message));
        return;
      }
      const act = ev.target && ev.target.closest ? ev.target.closest(".btn-phase-activate") : null;
      if (act) activatePhase(act.dataset.phase || "").catch((e) => alert(e.message));
    });
    document.querySelectorAll('input[name="phase-chain-start"]').forEach((el) => {
      el.addEventListener("change", () => {
        if (el.checked) localStorage.setItem("optimqe.phaseChainStart", el.value);
      });
    });
    paintPhaseChainStartChoice();
    bind("btn-postscf-nscf-stable", "click", () => runNscfStable().catch((e) => alert(e.message)));
    bind("btn-postscf-nscf", "click", () => runNscfCurrentPhase().catch((e) => alert(e.message)));
    bind("btn-postscf-extract", "click", () => runPostscfExtract().catch((e) => alert(e.message)));
    bind("btn-postscf-export-data", "click", () => runPostscfExportData().catch((e) => alert(e.message)));
    bind("btn-postscf-fiche", "click", () => openPostscfFiche());
    bind("btn-postscf-bands", "click", () => runPostscfBands().catch((e) => alert(e.message)));
    bind("btn-postscf-optical", "click", () => runPostscfOptical().catch((e) => alert(e.message)));
    bind("btn-postscf-elastic", "click", () => runElasticActivePhase().catch((e) => alert(e.message)));
    bind("btn-postscf-elastic-run", "click", () => runElasticBatchActivePhase().catch((e) => alert(e.message)));
    bind("btn-nm-balanced", "click", () => applyBalancedNmProfile().catch((e) => alert(e.message)));
    bind("btn-mag-nscf-all", "click", () => runNscfMagneticSet().catch((e) => alert(e.message)));
    bind("btn-mag-prepare", "click", () => prepareMagOrders().catch((e) => alert(e.message)));
    bind("btn-mag-afm-all", "click", () => runMagBatch(false).catch((e) => alert(e.message)));
    $("mag-orders-card")?.addEventListener("click", (ev) => {
      const t = ev.target && ev.target.closest ? ev.target : null;
      if (!t) return;
      if (t.closest(".btn-mag-afm-selected")) {
        runSelectedAfmBatch().catch((e) => alert(e.message));
        return;
      }
      if (t.closest(".btn-mag-afm-sel-all")) {
        document.querySelectorAll("#mag-afm-picker input.mag-afm-pick:not(:disabled)").forEach((el) => {
          el.checked = true;
        });
        updateMagAfmSelectedBtn();
        return;
      }
      if (t.closest(".btn-mag-afm-sel-none")) {
        document.querySelectorAll("#mag-afm-picker input.mag-afm-pick").forEach((el) => {
          el.checked = false;
        });
        updateMagAfmSelectedBtn();
      }
    });
    $("mag-orders-card")?.addEventListener("change", (ev) => {
      if (ev.target && ev.target.classList && ev.target.classList.contains("mag-afm-pick")) {
        updateMagAfmSelectedBtn();
      }
    });
    bind("btn-scf-to-mag", "click", () => switchToMagneticScf().catch((e) => alert(e.message)));
    $("mag-case-cards")?.addEventListener("click", (ev) => {
      onChainFixClick(ev);
      const btn = ev.target && ev.target.closest ? ev.target.closest("button[data-order]") : null;
      if (!btn) return;
      if (btn.disabled && btn.classList.contains("btn-mag-run")) {
        const reason = magRunBlockedReason(btn.dataset.order || "fm");
        if (reason) alert(reason);
        return;
      }
      if (btn.disabled) return;
      const order = btn.dataset.order;
      if (btn.classList.contains("btn-mag-use-job")) {
        activateOrderJob(order, btn.dataset.jobId || "")
          .then(() => refreshMagOrders().catch(() => {}))
          .catch((e) => alert(e.message));
        return;
      }
      if (btn.classList.contains("btn-mag-edit")) {
        openMagEditor(order, btn.dataset.kind || "scf").catch((e) => alert(e.message));
        return;
      }
      if (btn.classList.contains("btn-mag-nscf")) {
        runNscfOrder(order).catch((e) => alert(e.message));
        return;
      }
      if (btn.classList.contains("btn-mag-stop")) {
        stopRun(btn.dataset.kind || "scf", order).catch((e) => alert(e.message));
        return;
      }
      if (btn.classList.contains("btn-mag-run")) {
        runMagOrder(order, btn.dataset.kind || "vc-relax").catch((e) => alert(e.message));
      }
    });
    bind("btn-goto-nm", "click", () => switchTab("optimisation"));
    bind("btn-goto-mag", "click", () => switchTab("magnetisme"));
    bind("btn-goto-prop", "click", () => switchTab("proprietes"));
    bind("scf-mode-select", "change", () => setScfMode($("scf-mode-select").value));
    initPipeline();
    initSessionWorkTabs();
    initAuthorPopovers();
    initNspin();
    const resultsPage = document.getElementById("page-resultats");
    if (resultsPage) resultsPage.addEventListener("click", onResultsClick);
    window.addEventListener("beforeunload", () => {
      stopResultsAutoRefresh();
      stopRunsAutoRefresh();
    });

    if (PHASES_ONLY) {
      resetPhasesHorizontalScroll();
      requestAnimationFrame(() => {
        resetPhasesHorizontalScroll();
        requestAnimationFrame(resetPhasesHorizontalScroll);
      });
      window.addEventListener("resize", resetPhasesHorizontalScroll, { passive: true });
      watchPhasesHorizontalOverflow();
      loadTabData("phases");
      syncMainAppNavLinks();
    } else {
      const savedTab = normalizeTab(localStorage.getItem("optimqe.tab") || "optimisation");
      if (savedTab === "phases") goPhasesApp();
      else switchTab(savedTab, { silent: true });
    }

    if (!PHASES_ONLY) {
      initParallel().catch(() => {});
      initHubbard();
      refreshHubbardPanel().catch(() => {});
    }
    refreshMaterials().catch(() => {});
    if (structurePanelUnlocked() || sessionConfirmed) {
      refreshPhaseTypePanel().catch(() => {}).finally(resetPhasesHorizontalScroll);
    }
    refreshPhasesForDraft()
      .then(() => refreshJobsForDraft())
      .then(() => {
        if (sessionConfirmed && material) reconcileSessionDrafts();
        syncMainAppNavLinks();
        if (PHASES_ONLY) {
          loadTabData("phases");
        } else {
          const tab = currentTab();
          if (tab === "optimisation") {
            refreshOptimStatus().catch(() => {});
          } else if (tab !== "phases") {
            loadTabData(tab);
          }
        }
        if (sessionConfirmed && material && $("optim-cards") && !PHASES_PREP_ONLY) {
          try {
            if (localStorage.getItem("optimqe.autoresume") === "1") {
              window.setTimeout(() => tryAutoResumeInterrupted().catch(() => {}), 4000);
            }
          } catch (_) {
            /* ignore */
          }
        }
      })
      .catch(() => {});
  });
})();

# -*- coding: utf-8 -*-
"""
Pseudopotentiels Norm-Conserving (ONCVPSP / ld1.x) pour les lanthanides (Z 57–71).

Méthodologie :
  - ``open_core`` : électrons 4f gelés dans le cœur (inertes, pseudo plus doux).
  - ``valence_f`` : 4f actifs en valence (magnétisme, DFT+U souvent requis).
  - r_c(4f) recommandé : 1.8–2.3 bohr ; relativité forte recommandée.
"""

from __future__ import annotations

from typing import Any

LANTHANIDE_SYMBOLS: tuple[str, ...] = (
    "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy",
    "Ho", "Er", "Tm", "Yb", "Lu",
)

# Valence avec 4f actifs (référence ld1 / chimie)
_VALENCE_F: dict[str, str] = {
    "La": "5d1 6s2",
    "Ce": "4f1 5d1 6s2",
    "Pr": "4f3 6s2",
    "Nd": "4f4 6s2",
    "Pm": "4f5 6s2",
    "Sm": "4f6 6s2",
    "Eu": "4f7 6s2",
    "Gd": "4f7 5d1 6s2",
    "Tb": "4f9 6s2",
    "Dy": "4f10 6s2",
    "Ho": "4f11 6s2",
    "Er": "4f12 6s2",
    "Tm": "4f13 6s2",
    "Yb": "4f14 6s2",
    "Lu": "5d1 6s2",  # 4f14 dans le cœur
}

# Valence « open core » : 4f retirés de la valence (restent dans le cœur AE)
_OPEN_CORE: dict[str, str] = {
    "La": "5d1 6s2",
    "Ce": "5d1 6s2",
    "Pr": "6s2",
    "Nd": "6s2",
    "Pm": "6s2",
    "Sm": "6s2",
    "Eu": "6s2",
    "Gd": "5d1 6s2",
    "Tb": "6s2",
    "Dy": "6s2",
    "Ho": "6s2",
    "Er": "6s2",
    "Tm": "6s2",
    "Yb": "6s2",
    "Lu": "5d1 6s2",
}

# iexc ONCVPSP : fichiers officiels (57_La.dat, 32_Ge.dat) utilisent 3 pour PBE/LDA courant.
_ONCV_IEXC = {
    "lda_pw": 3,
    "lda_pz": 3,
    "gga_pbe": 3,
    "gga_pbesol": 3,
    "pbe": 3,
    "pbesol": 3,
}

_RC_F_DEFAULT = 2.05  # bohr, milieu de 1.8–2.3


def is_lanthanide(sym: str) -> bool:
    s = (sym or "").strip()
    if len(s) == 1:
        key = s.upper()
    else:
        key = s[0].upper() + s[1:].lower()
    return key in LANTHANIDE_SYMBOLS


def normalize_f_treatment(mode: str | None) -> str:
    m = (mode or "valence_f").strip().lower().replace("-", "_")
    if m in ("open", "open_core", "core", "frozen_f", "inert_f"):
        return "open_core"
    return "valence_f"


def valence_string(sym: str, f_treatment: str | None = None) -> str:
    sym = _norm(sym)
    ft = normalize_f_treatment(f_treatment)
    if ft == "open_core":
        return _OPEN_CORE.get(sym, _VALENCE_F.get(sym, "6s2"))
    return _VALENCE_F.get(sym, "6s2")


def adjust_valence_occ(
    valence: dict[tuple[int, int], int],
    sym: str,
    f_treatment: str | None,
) -> dict[tuple[int, int], int]:
    """Retire les orbitales 4f de la valence si open_core."""
    if normalize_f_treatment(f_treatment) != "open_core":
        return dict(valence)
    out = {k: v for k, v in valence.items() if k[1] != 3}
    return out


def rc_f_bohr(scale: float = 1.0) -> float:
    v = _RC_F_DEFAULT * float(scale)
    return round(max(1.80, min(2.30, v)), 3)


def get_guide(sym: str, f_treatment: str | None = None) -> dict[str, Any]:
    sym = _norm(sym)
    ft = normalize_f_treatment(f_treatment)
    return {
        "element": sym,
        "is_lanthanide": True,
        "f_treatment": ft,
        "f_treatment_label": (
            "Open core (4f gelé dans le cœur)"
            if ft == "open_core"
            else "Valence 4f active (magnétisme / DFT+U)"
        ),
        "valence_recommended": valence_string(sym, ft),
        "valence_f_alternate": valence_string(sym, "valence_f"),
        "valence_open_core_alternate": valence_string(sym, "open_core"),
        "semicore_valence": "5s2 5p6 (à inclure systématiquement en valence ld1/ONCV)",
        "rc_4f_bohr_range": [1.8, 2.3],
        "rc_4f_suggested": rc_f_bohr(1.0),
        "relativistic": "rel=2 (équation de Dirac) recommandé en ld1.x ; scalaire insuffisant pour 4f",
        "nlcc": "nlcc=.true. + rcore≈1.2 recommandé (chevauchement cœur–valence)",
        "rho0_bessel": "rho0≈0.02 si échec RRKJ / fonctions de Bessel",
        "oncv_recommended": True,
        "ld1_difficulty": "élevée — semi-cœur 5s/5p + rel=2 + NLCC ; sinon ONCVPSP / PseudoDojo",
        "pseudodojo_url": "https://www.pseudo-dojo.org/",
        "pw_x_tips": [
            "HUBBARD U sur 4f si sur-délocalisation GGA/LDA",
            "nspin=2 + starting_magnetization",
            "mixing_beta=0.15–0.30",
        ],
        "workflow": [
            "Inclure 5s/5p en valence (semi-cœur)",
            "ld1 : rel=2, nlcc=.true., rcore≈1.2 ; rho0 si échec Bessel",
            "Choisir open_core vs valence_f pour le 4f",
            "Générer ONCV (.dat) — r_c(4f) 1.8–2.3 bohr",
            "TEST 1 : dérivées logarithmiques (ghost state ?)",
            "TEST 2 : transférabilité (oxyde / solide)",
            "pw.x : DFT+U + magnétisation initiale si SCF difficile",
            "Sinon : PseudoDojo standard/stringent (ONCV déjà validés)",
        ],
        "tests": {
            "test1_log_derivative": "Discontinuité du déphasage → ghost ; ajuster r_c(4f)",
            "test2_transferability": "SCF sur maille test vs données tout-électron",
        },
    }


def _norm(sym: str) -> str:
    s = (sym or "").strip()
    if len(s) == 1:
        return s.upper()
    return s[0].upper() + s[1:].lower()


# Cœur [Xe] (Z=54) — ordre ONCV (n croissant, l croissant)
_XE_CORE: tuple[tuple[int, int, float], ...] = (
    (1, 0, 2.0), (2, 0, 2.0), (2, 1, 6.0),
    (3, 0, 2.0), (3, 1, 6.0), (3, 2, 10.0),
    (4, 0, 2.0), (4, 1, 6.0), (4, 2, 10.0),
    (5, 0, 2.0), (5, 1, 6.0),
)


def parse_valence_tokens(valence: str) -> list[tuple[int, int, float]]:
    """Parse une chaîne type « 4f7 5d1 6s2 » en (n, l, occupation)."""
    import re

    out: list[tuple[int, int, float]] = []
    for m in re.finditer(r"(\d)([spdf])(\d+)", valence, re.I):
        n = int(m.group(1))
        l = {"s": 0, "p": 1, "d": 2, "f": 3}[m.group(2).lower()]
        occ = float(m.group(3))
        out.append((n, l, occ))
    return sorted(out, key=lambda t: (t[0], t[1]))


def _parse_valence_tokens(valence: str) -> list[tuple[int, int, float]]:
    return parse_valence_tokens(valence)


def valence_occ_dict(sym: str, f_treatment: str | None = None) -> dict[tuple[int, int], int]:
    """Occupations de valence chimiques pour APE / ld1 (lanthanides)."""
    out: dict[tuple[int, int], int] = {}
    for n, l, occ in parse_valence_tokens(valence_string(sym, f_treatment)):
        out[(n, l)] = int(round(occ))
    return out


def _build_oncv_electron_lines(sym: str, f_treatment: str, Z: int) -> tuple[list[str], int, int]:
    """
    Lignes (n,l,f) ONCV : nc lignes cœur puis nv lignes valence.
    Convention ONCV (ex. 29_Cu.dat, 60_Nd_GHOST.dat) : nc et nv = nombres de lignes.
    Référence : cœur [Xe] (+ 5s5p si Z>54) + 4f gelé (open_core) + valence déclarée.
    """
    import pseudo_auto_inputs as pai

    sym = _norm(sym)
    pai.atomic_number(sym)
    ft = normalize_f_treatment(f_treatment)
    val_tokens = _parse_valence_tokens(valence_string(sym, ft))
    valence_set = {(n, l) for n, l, _ in val_tokens}
    val_lines = [(n, l, occ) for n, l, occ in val_tokens]

    merged: dict[tuple[int, int], float] = {(n, l): o for n, l, o in _XE_CORE}
    if Z > 54:
        merged[(5, 0)] = 2.0
        merged[(5, 1)] = 6.0
    if ft == "open_core":
        for n, l, occ in _parse_valence_tokens(_VALENCE_F.get(sym, "")):
            if l == 3:
                merged[(n, l)] = occ

    core_lines = sorted(
        ((n, l, merged[(n, l)]) for n, l in merged if (n, l) not in valence_set),
        key=lambda t: (t[0], t[1]),
    )
    nc = len(core_lines)
    nv = len(val_lines)
    all_lines = core_lines + val_lines
    str_lines = [f"    {n}    {l}    {occ:.1f}" for n, l, occ in all_lines]
    return str_lines, nc, nv


def generate_oncv_dat(
    sym: str,
    f_treatment: str | None = None,
    xc: str = "gga_pbe",
    rc_f_scale: float = 1.0,
    psfile: str = "both",
) -> str:
    """Génère une entrée ONCVPSP .dat pour un lanthanide (NC), format proche 57_La.dat."""
    import pseudo_auto_inputs as pai

    sym = _norm(sym)
    if not is_lanthanide(sym):
        raise ValueError(f"{sym} n'est pas un lanthanide (Z 57–71).")
    Z = pai.atomic_number(sym)
    ft = normalize_f_treatment(f_treatment)
    iexc = _ONCV_IEXC.get((xc or "gga_pbe").lower(), 3)
    rc_f = rc_f_bohr(rc_f_scale)
    rc_spd = round(max(2.10, min(2.55, 2.50 * rc_f_scale)), 2)

    elec_lines, nc, nv = _build_oncv_electron_lines(sym, ft, Z)
    val_tokens = _parse_valence_tokens(valence_string(sym, ft))
    has_f_val = any(l == 3 for _, l, _ in val_tokens)
    has_f_core = ft == "open_core" and any(
        l == 3 for n, l, _ in _parse_valence_tokens(_VALENCE_F.get(sym, ""))
    )
    has_f = has_f_val or has_f_core
    lmax = 3 if has_f else 2

    # rc(lloc) doit être <= rc(l) pour chaque canal (test_data ONCV).
    rc_channels = [
        (0, rc_spd, 0.00, 4, 8, 5.00),
        (1, rc_spd, 0.00, 4, 8, 5.00),
        (2, rc_spd, 0.00, 4, 9, 6.00),
    ]
    if lmax >= 3:
        ep_f = -0.10 if ft == "open_core" else 0.00
        rc_channels.append((3, rc_f, ep_f, 5, 9, 10.00))
    rc_local = min(r[1] for r in rc_channels)

    rc_lines = [
        f"    {l}    {rc:.2f}   {ep:5.2f}    {ncon}    {nbas}   {qcut:.2f}"
        for l, rc, ep, ncon, nbas, qcut in rc_channels
    ]

    # Valeurs proches 60_Nd_GHOST.dat (debl=0 refusé par ONCV pour certains l).
    proj = ["    0    2    1.00", "    1    2    4.00", "    2    2    4.00"]
    if lmax >= 3:
        proj.append("    3    2    2.00")

    atsym = sym.lower()[:2]
    ps = (psfile or "both").strip().lower()
    if ps not in ("upf", "both", "psp8"):
        ps = "both"

    header = (
        "# ONCVPSP — lanthanide NC (generation_pseudos/lanthanide_nc.py)\n"
        f"# Cible par défaut : Quantum ESPRESSO — psfile={ps} (UPF XML + psp8)\n"
        f"# 4f: {ft} — valence {valence_string(sym, ft)} — r_c(4f)={rc_f} bohr\n"
        "#\n"
        "# ATOM AND REFERENCE CONFIGURATION\n"
        "# atsym, z, nc, nv, iexc   psfile\n"
        f"  {atsym}  {float(Z):.1f}   {nc}   {nv}   {iexc}   {ps}\n"
        "#\n"
        "# n, l, f  (nc+nv lines)\n"
    )
    body = "\n".join(elec_lines)
    opt = (
        "#\n# PSEUDOPOTENTIAL AND OPTIMIZATION\n# lmax\n"
        f"    {lmax}\n#\n# l, rc, ep, ncon, nbas, qcut  (lmax+1 lines, l's must be in order)\n"
        + "\n".join(rc_lines)
        + "\n#\n# LOCAL POTENTIAL\n# lloc, lpopt, rc(5), dvloc0\n"
        f"    {lmax + 1}    5    {rc_local:.1f}    0.0\n#\n"
        "# VANDERBILT-KLEINMAN-BYLANDER PROJECTORs\n# l, nproj, debl  (lmax+1 lines, l's in order)\n"
        + "\n".join(proj)
        + "\n#\n# MODEL CORE CHARGE\n# icmod, fcfact\n    0    0.0\n#\n"
        "# LOG DERIVATIVE ANALYSIS\n# epsh1, epsh2, depsh\n   -2.0  3.0  0.02\n#\n"
        "# OUTPUT GRID\n# rlmax, drl\n    6.0  0.01\n#\n# TEST CONFIGURATIONS\n# ncnf\n    0\n"
    )
    return header + body + "\n" + opt

# -*- coding: utf-8 -*-
"""
Optimisation pragmatique des rayons de coupure r_c (Bohr).

But : réduire les échecs de génération (nœuds avant r_c, ghost, GSL / itérations)
sans prétendre remplacer une validation transfertabilité (Δε, logarithme dérivatif, etc.).

Stratégie :
  1. Plancher (floor) par famille / canal l — r_c trop petits → nœuds.
  2. Échelle de départ (rc_scale) plus élevée pour 3d / 4f / APE.
  3. Escalade automatique après erreur typique (×1.15, ×1.35, … plafonnée).
"""

from __future__ import annotations

import re
from typing import Any

try:
    from pseudo_auto_inputs import normalize_symbol, atomic_number, _TRANSITION_3D
except ImportError:
    _TRANSITION_3D = frozenset(
        {"Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn"}
    )

    def normalize_symbol(s: str) -> str:
        s = (s or "").strip()
        return s.upper() if len(s) == 1 else (s[0].upper() + s[1:].lower() if s else "")

    def atomic_number(sym: str) -> int:
        return 0


# Erreurs qui justifient d'augmenter r_c
_RC_ERROR_PATTERNS = (
    r"phi has nodes before r_c",
    r"nodes before r_c",
    r"wrong number of nodes",
    r"n[œoe]uds",
    r"ghost\s+state",
    r"spurious\s+state",
    r"exceeded max number of iterations",
    r"multiroot",
    r"gsl",
    r"test_data:\s*rc\s*<\s*rc\(lloc\)",
    r"optimize:\s*ERROR",
    r"negative\s+rho",
    r"Errors in PS-KS",
)

# Échelle d'escalade (tentative 0 = échelle de base)
_SCALE_LADDER = (1.00, 1.15, 1.30, 1.45, 1.60, 1.80)
_SCALE_MAX = 2.0


def _is_lanthanide(sym: str) -> bool:
    try:
        import lanthanide_nc as lnc

        return lnc.is_lanthanide(sym)
    except ImportError:
        z = atomic_number(sym)
        return 57 <= z <= 71


def family_tag(sym: str) -> str:
    sym_n = normalize_symbol(sym)
    z = atomic_number(sym_n)
    if sym_n in _TRANSITION_3D or 21 <= z <= 30:
        return "3d"
    if _is_lanthanide(sym_n):
        return "4f"
    if 39 <= z <= 48:
        return "4d"
    if 72 <= z <= 80:
        return "5d"
    if z >= 81:
        return "heavy"
    return "light"


def safe_rc_floor(sym: str, n: int, l: int) -> float | None:
    """
    Plancher Bohr pour (n,l) — au-dessous, ld1/APE voient souvent des nœuds.
    None = pas de plancher additionnel.
    """
    fam = family_tag(sym)
    # Métaux 3d : 4s très nodal → rc large ; 3d un peu plus doux mais pas trop serré
    if fam == "3d":
        if l == 0 and n >= 4:
            return 2.40
        if l == 1 and n >= 4:
            return 2.20
        if l == 1 and n == 3:
            return 2.00
        if l == 2 and n == 3:
            return 2.00
    if fam == "4d":
        if l == 0 and n >= 5:
            return 2.50
        if l == 2 and n == 4:
            return 2.10
    if fam == "4f":
        if l == 3:
            return 1.90  # fenêtre open-core / PseudoDojo ~1.8–2.3
        if l == 0 and n >= 6:
            return 2.50
        if l == 2 and n == 5:
            return 2.40
    if fam in ("5d", "heavy"):
        if l == 0 and n >= 6:
            return 2.40
        if l == 2:
            return 2.10
    return None


def apply_safe_floor(sym: str, n: int, l: int, rc: float) -> float:
    """Applique le plancher famille sur une valeur r_c déjà calculée."""
    floor = safe_rc_floor(sym, n, l)
    if floor is None:
        return float(rc)
    return max(float(rc), float(floor))


def default_rc_scale(sym: str, generator: str = "ape") -> float:
    """
    Échelle de départ recommandée (multiplicateur sur la base elements_physics_db).
    Plus élevée pour APE sur 3d/4f (convergence PP difficile).
    """
    fam = family_tag(sym)
    gen = (generator or "").strip().lower()
    if gen in ("ape",):
        if fam == "3d":
            return 1.45
        if fam == "4f":
            return 1.55
        if fam in ("4d", "5d"):
            return 1.25
        return 1.0
    if gen in ("atompaw", "aw"):
        if fam in ("3d", "4f"):
            return 1.15
        return 1.0
    if gen in ("ld1", "ld1.x", "ld1x"):
        if fam == "3d":
            return 1.10
        if fam == "4f":
            return 1.20
        return 1.0
    if gen in ("oncvpsp", "oncv"):
        if fam == "4f":
            return 1.05
        return 1.0
    return 1.0


def error_suggests_larger_rc(log_text: str | None) -> bool:
    if not log_text:
        return False
    blob = str(log_text)
    for pat in _RC_ERROR_PATTERNS:
        if re.search(pat, blob, re.IGNORECASE):
            return True
    return False


def next_rc_scale(current: float, attempt: int = 0) -> float | None:
    """
    Prochaine échelle après un échec. attempt = 0 → première escalade.
    Retourne None si le plafond est atteint.
    """
    cur = float(current) if current and current > 0 else 1.0
    # Chercher le prochain cran > cur dans la ladder × cur_base
    # Simplifié : multiplier par 1.15 à chaque tentative, plafonné
    nxt = round(cur * 1.15, 3)
    if nxt <= cur + 0.02:
        nxt = round(cur + 0.15, 3)
    if nxt > _SCALE_MAX:
        return None
    return nxt


def rc_scale_ladder(base: float = 1.0, max_attempts: int = 4) -> list[float]:
    """Liste d'échelles à essayer (base incluse)."""
    base = float(base) if base and base > 0 else 1.0
    out = [round(base, 3)]
    cur = base
    for _ in range(max_attempts):
        nxt = next_rc_scale(cur)
        if nxt is None:
            break
        out.append(nxt)
        cur = nxt
    return out


def diagnose_rc(sym: str, generator: str = "ape", current_scale: float = 1.0) -> dict[str, Any]:
    """Fiche pour l'UI / API : famille, échelle conseillée, planchers, conseils."""
    sym_n = normalize_symbol(sym)
    fam = family_tag(sym_n)
    suggested = default_rc_scale(sym_n, generator)
    floors: dict[str, float] = {}
    for n, l, label in (
        (4, 0, "4s"),
        (4, 1, "4p"),
        (3, 1, "3p"),
        (3, 2, "3d"),
        (5, 2, "5d"),
        (4, 3, "4f"),
        (6, 0, "6s"),
    ):
        f = safe_rc_floor(sym_n, n, l)
        if f is not None:
            floors[label] = f
    tips = []
    if fam == "3d":
        tips.append("3d : r_c(4s) ≥ 2.4 bohr souvent nécessaire (nœuds) ; préférer US/PAW en ld1.")
        tips.append("APE NC sur 3d reste fragile même avec r_c large — ATOMPAW / ONCVPSP / PseudoDojo.")
    elif fam == "4f":
        tips.append("4f : r_c(4f) dans 1.8–2.3 bohr ; open-core + ATOMPAW/ONCVPSP plus fiables.")
    elif fam in ("4d", "5d"):
        tips.append("Augmentez r_c si « nodes before r_c » ; semi-cœur p parfois utile.")
    else:
        tips.append("Gardez rc_scale≈1 sauf erreur de nœuds / ghost — alors +15–30 %.")
    tips.append("r_c trop grand → pseudo plus « mou », ecutwfc plus bas mais transfertabilité à vérifier.")
    return {
        "element": sym_n,
        "family": fam,
        "generator": generator,
        "current_rc_scale": float(current_scale),
        "suggested_rc_scale": suggested,
        "ladder": rc_scale_ladder(max(float(current_scale), suggested), 4),
        "floors_bohr": floors,
        "tips": tips,
        "note": (
            "Optimisation heuristique anti-erreur de génération — "
            "pas un substitut à une validation (ghost, log-derivative, solides)."
        ),
    }

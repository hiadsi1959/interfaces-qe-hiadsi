#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API Standalone — Génération des Pseudopotentiels (Quantum ESPRESSO)
===================================================================
API Flask minimale et autonome pour l'interface "Génération des Pseudos".
Ne dépend d'aucun autre fichier du projet Interface-QE.

Utilisation :
    python3 api_pseudos_standalone.py                    # auto-détection
    python3 api_pseudos_standalone.py --port 5008
    python3 api_pseudos_standalone.py --qe /chemin/bin --pseudos ~/pseudos
"""

import mimetypes
import os, re, sys, json, glob, shutil, subprocess, argparse, tempfile, time
from datetime import datetime
from pathlib import Path

try:
    from flask import Flask, request, jsonify, Response
    from flask_cors import CORS
except ImportError:
    print("❌ Flask non installé. Exécutez : pip3 install flask flask-cors")
    sys.exit(1)

# Marqueur de version : incrémenter dès qu'une route ou un chemin change.
# Le frontend l'affiche dans le badge « Diagnostic API » : si la valeur ne
# correspond pas à celle attendue, c'est qu'un ancien processus tourne.
API_BUILD_TAG = "2026-08-28-expertise-finale"

# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  Chemins — priorité : CLI → api_config.json → third_party/ → PATH / QE      ║
# ║  Mode autonome : les 4 générateurs (ld1, APE, ATOMPAW, ONCV) sans QE full.  ║
# ║  Sur un nouveau PC : ./configure.sh puis ./DEMARRER.sh (port 5008)          ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

_APP_ROOT = os.path.dirname(os.path.abspath(__file__))
PROJET_DIR = _APP_ROOT
# Références optionnelles (vides = ne forcent pas un utilisateur) — détection auto ensuite
QE_BIN_REF = ''
PSEUDOS_REF = os.path.join(_APP_ROOT, 'pseudos')
INPUTS_REF = os.path.join(_APP_ROOT, 'inputs')
OUTPUTS_REF = os.path.join(_APP_ROOT, 'outputs')
CIF_REF = os.path.join(_APP_ROOT, 'fichiers_cif')
STRUCTURES_REF = os.path.join(_APP_ROOT, 'structures')
LOGS_REF = os.path.join(_APP_ROOT, 'logs')
TMP_REF = os.path.join(_APP_ROOT, '_work')
INTERFACE_PSEUDOS = os.path.join(_APP_ROOT, 'index.html')
INTERFACE_PRINCIPALE = INTERFACE_PSEUDOS

# ─── Auto-détection (si les chemins de référence n'existent pas) ───────────────

def _dir_has_prog(d: str, *names: str) -> bool:
    return bool(d) and any(os.path.isfile(os.path.join(d, n)) for n in names)


def detecter_qe():
    """Détecte un dossier bin/ contenant ld1.x et/ou pw.x — priorité ./bin du projet."""
    local_bin = os.path.join(_APP_ROOT, 'bin')
    if _dir_has_prog(local_bin, 'pw.x', 'ld1.x'):
        return local_bin
    local_qe = os.path.join(_APP_ROOT, 'third_party', 'qe', 'bin')
    if _dir_has_prog(local_qe, 'pw.x', 'ld1.x'):
        return local_qe
    env = os.environ.get('QE_BIN', '')
    if env and _dir_has_prog(env, 'pw.x', 'ld1.x'):
        return env
    pw = shutil.which('pw.x')
    if pw:
        return str(Path(pw).parent)
    if QE_BIN_REF and _dir_has_prog(QE_BIN_REF, 'pw.x', 'ld1.x'):
        return QE_BIN_REF
    for motif in [
        os.path.expanduser('~/q-e-qe-*/bin'),
        os.path.expanduser('~/q-e-*/bin'),
        os.path.expanduser('~/qe-*/bin'),
        os.path.expanduser('~/QE/bin'),
        '/usr/local/qe/bin', '/opt/qe/bin',
    ]:
        for chemin in sorted(glob.glob(motif), reverse=True):
            if _dir_has_prog(chemin, 'pw.x', 'ld1.x'):
                return chemin
    return None


def detecter_pseudos():
    """Détecte ou crée le répertoire des pseudopotentiels (priorité dossier du projet)."""
    local_link = os.path.join(os.path.dirname(__file__), 'pseudos')
    if os.path.isdir(local_link):
        return os.path.abspath(local_link)
    if PSEUDOS_REF and os.path.isdir(PSEUDOS_REF):
        return os.path.abspath(PSEUDOS_REF)
    env = os.environ.get('QE_PSEUDOS', '')
    if env and os.path.isdir(env):
        return os.path.abspath(env)
    for c in [
        os.path.expanduser('~/pseudos'),
        os.path.expanduser('~/qe-pseudos'),
        '/opt/qe/pseudos', '/usr/share/espresso/pseudo',
    ]:
        if os.path.isdir(c):
            return os.path.abspath(c)
    fallback = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pseudos')
    os.makedirs(fallback, exist_ok=True)
    return fallback


def detecter_dossier(ref, *fallbacks):
    """Retourne le premier dossier existant parmi ref et les alternatives."""
    if os.path.isdir(ref):
        return os.path.abspath(ref)
    for fb in fallbacks:
        fb_exp = os.path.expanduser(fb)
        if os.path.isdir(fb_exp):
            return os.path.abspath(fb_exp)
    # Créer le premier fallback
    fb = os.path.expanduser(fallbacks[0]) if fallbacks else ref
    os.makedirs(fb, exist_ok=True)
    return os.path.abspath(fb)


# ─── Parsing des arguments CLI ─────────────────────────────────────────────────

parser = argparse.ArgumentParser(description='API standalone pseudopotentiels (4 générateurs, QE optionnel)')
parser.add_argument('--port',    type=int, default=5008)
parser.add_argument('--qe',     type=str, default=None, help='Dossier bin/ QE optionnel (pw.x / ld1.x)')
parser.add_argument('--ld1',    type=str, default=None, help='Chemin absolu vers ld1.x (autonomie sans QE)')
parser.add_argument('--pseudos',type=str, default=None)
parser.add_argument('--inputs', type=str, default=None)
parser.add_argument('--outputs',type=str, default=None)
args, _ = parser.parse_known_args()

# Chemins finaux résolus (projet local en priorité)
QE_BIN  = args.qe or detecter_qe()
PSEUDOS = args.pseudos or detecter_pseudos()
INPUTS  = args.inputs  or detecter_dossier(INPUTS_REF, os.path.join(_APP_ROOT, 'inputs'), '~/inputs')
OUTPUTS = args.outputs or detecter_dossier(OUTPUTS_REF, os.path.join(_APP_ROOT, 'outputs'), '~/outputs')
TMP     = detecter_dossier(TMP_REF, os.path.join(_APP_ROOT, '_work'), '/tmp/qe_pseudos')
LOGS    = detecter_dossier(LOGS_REF, os.path.join(_APP_ROOT, 'logs'))
API_PORT = args.port
LD1_BIN_OVERRIDE = (args.ld1 or '').strip() or None

# ─── Flask ─────────────────────────────────────────────────────────────────────

_STATIC_ROOT = Path(os.path.dirname(os.path.abspath(__file__)))
app = Flask(__name__, static_folder=None)
CORS(app)  # CORS complet — autorise requêtes cross-origin si nécessaire


# ─── Utilitaires ───────────────────────────────────────────────────────────────

def qe_bin(programme):
    if QE_BIN:
        p = os.path.join(QE_BIN, programme)
        if os.path.isfile(p):
            return p
    return shutil.which(programme) or programme


def _standalone_api_config():
    """Charge api_config.json du projet (source de vérité sur chaque PC)."""
    _here = os.path.dirname(os.path.abspath(__file__))
    merged: dict = {}
    p = os.path.join(_here, 'api_config.json')
    if os.path.isfile(p):
        try:
            with open(p, encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, dict):
                merged.update(data)
        except Exception:
            pass
    return merged


_ST_CFG = _standalone_api_config()

try:
    import transition_3d_nc as _t3d_boot

    _t3d_boot.ensure_cached_templates(_STATIC_ROOT)
except Exception:
    pass

try:
    import transition_4d_nc as _t4d_boot

    _t4d_boot.ensure_cached_templates(_STATIC_ROOT)
except Exception:
    pass

# api_config.json prime sur la détection (sauf si --qe / --pseudos CLI)
if not args.qe:
    _qb = (_ST_CFG.get('qe_bin') or '').strip()
    # Accepte un dossier avec ld1.x seul (pas besoin de pw.x pour générer)
    if _qb and _dir_has_prog(_qb, 'pw.x', 'ld1.x'):
        QE_BIN = _qb
if not args.pseudos:
    _pd = (_ST_CFG.get('pseudos_dir') or '').strip()
    if _pd and os.path.isdir(_pd):
        PSEUDOS = os.path.abspath(_pd)
    elif not PSEUDOS:
        PSEUDOS = detecter_pseudos()


def _env_str(name):
    v = os.environ.get(name, '')
    return v.strip() if isinstance(v, str) else ''


def _cfg_str(key):
    v = _ST_CFG.get(key)
    return v.strip() if isinstance(v, str) else ''


def _path_executable(p: Path) -> bool:
    return p.is_file() and os.access(p, os.X_OK)


def _oncvpsp_candidate_paths() -> list[Path]:
    """Priorité : env/cfg → ./bin/oncvpsp.x → third_party → home."""
    _here = Path(__file__).resolve().parent
    out: list[Path] = []
    env_or_cfg = _env_str('ONCVPSP_BIN') or _cfg_str('oncvpsp_bin')
    if env_or_cfg:
        out.append(Path(env_or_cfg).expanduser())
    out.extend([
        _here / 'bin' / 'oncvpsp.x',
        _here / 'third_party' / 'oncvpsp' / 'bin' / 'oncvpsp.x',
        _here / 'oncvpsp-master' / 'bin' / 'oncvpsp.x',
        _here / 'oncvpsp-master' / 'build' / 'bin' / 'oncvpsp.x',
    ])
    for rel in (
        '.local/bin/oncvpsp.x',
        'oncvpsp/build/bin/oncvpsp.x',
        'oncvpsp/build/src/oncvpsp.x',
    ):
        out.append(Path.home() / rel)
    seen: set[str] = set()
    uniq: list[Path] = []
    for p in out:
        key = str(p)
        if key not in seen:
            seen.add(key)
            uniq.append(p)
    return uniq


def _resolve_oncvpsp_bin():
    for c in _oncvpsp_candidate_paths():
        try:
            pp = c.resolve()
        except OSError:
            pp = c
        if _path_executable(pp):
            return pp
    return None


def _resolve_ld1_bin() -> Path | None:
    """ld1.x définitif : LD1_BIN → ./bin/ld1.x → QE_BIN → PATH."""
    candidates: list[Path] = []
    if LD1_BIN_OVERRIDE:
        candidates.append(Path(LD1_BIN_OVERRIDE).expanduser())
    env_or_cfg = _env_str('LD1_BIN') or _cfg_str('ld1_bin')
    if env_or_cfg:
        candidates.append(Path(env_or_cfg).expanduser())
    root = Path(__file__).resolve().parent
    candidates.extend([
        root / 'bin' / 'ld1.x',
        root / 'third_party' / 'qe' / 'bin' / 'ld1.x',
        root / 'third_party' / 'ld1' / 'bin' / 'ld1.x',
    ])
    if QE_BIN:
        candidates.append(Path(QE_BIN) / 'ld1.x')
    w = shutil.which('ld1.x')
    if w:
        candidates.append(Path(w))
    seen: set[str] = set()
    for c in candidates:
        try:
            pp = c.expanduser().resolve()
        except OSError:
            continue
        key = str(pp)
        if key in seen:
            continue
        seen.add(key)
        if _path_executable(pp) or (pp.is_file() and os.access(pp, os.R_OK)):
            return pp
    return None


def _resolve_pw_bin() -> Path | None:
    """pw.x définitif : PW_BIN → ./bin/pw.x → QE_BIN → PATH."""
    candidates: list[Path] = []
    env_or_cfg = _env_str('PW_BIN') or _cfg_str('pw_bin')
    if env_or_cfg:
        candidates.append(Path(env_or_cfg).expanduser())
    root = Path(__file__).resolve().parent
    candidates.append(root / 'bin' / 'pw.x')
    candidates.append(root / 'third_party' / 'qe' / 'bin' / 'pw.x')
    if QE_BIN:
        candidates.append(Path(QE_BIN) / 'pw.x')
    w = shutil.which('pw.x')
    if w:
        candidates.append(Path(w))
    seen: set[str] = set()
    for c in candidates:
        try:
            pp = c.expanduser().resolve()
        except OSError:
            continue
        key = str(pp)
        if key in seen:
            continue
        seen.add(key)
        if _path_executable(pp) or (pp.is_file() and os.access(pp, os.R_OK)):
            return pp
    return None


def _oncvpsp_tests_data_dir():
    r = _env_str('ONCVPSP_ROOT') or _cfg_str('oncvpsp_root')
    if r:
        p = Path(r).expanduser().resolve() / 'tests' / 'data'
        if p.is_dir():
            return p
    _here = Path(__file__).resolve().parent
    for p in (
        _here / 'data' / 'oncvpsp_tests_data',
        _here / 'third_party' / 'oncvpsp' / 'tests' / 'data',
        Path.home() / 'oncvpsp' / 'tests' / 'data',
        _here / 'oncvpsp-master' / 'tests' / 'data',
    ):
        if p.is_dir():
            return p.resolve()
    return None


def _oncv_local_lib():
    p = Path.home() / '.local' / 'lib'
    return p if p.is_dir() else None


_STANDALONE_ROOT = Path(__file__).resolve().parent

_pseudo_auto_sa = None


def _load_pseudo_auto_inputs_sa():
    global _pseudo_auto_sa
    if _pseudo_auto_sa is not None:
        return _pseudo_auto_sa
    p = _STANDALONE_ROOT / 'pseudo_auto_inputs.py'
    if not p.is_file():
        return None
    import importlib.util
    spec = importlib.util.spec_from_file_location('pseudo_auto_inputs_standalone', p)
    if spec is None or spec.loader is None:
        return None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    _pseudo_auto_sa = mod
    return mod


def _pseudo_templates_dir_sa() -> Path:
    return _STANDALONE_ROOT / 'templates'


def _pseudo_template_file_sa(fname: str) -> Path | None:
    ext = _STANDALONE_ROOT / 'templates' / fname
    if ext.is_file():
        return ext
    bundled = Path(__file__).resolve().parent / 'pseudo_generator_templates' / fname
    if bundled.is_file():
        return bundled
    return None


_MAX_LOCAL_INPUT_SAVE_BYTES_SA = 2_097_152


# ─── Repli résilient des dossiers d'écriture ────────────────────────────────────
#
# Le générateur est AUTONOME (dossier du projet). Si non inscriptible, bascule vers
# ~/.gen_pseudos/ puis /tmp/gen_pseudos/. Aucune dépendance à d'autres interfaces.

def _gen_user_state_root() -> Path:
    return (Path.home() / ".gen_pseudos").resolve()


def _gen_tmp_state_root() -> Path:
    return (Path(tempfile.gettempdir()) / "gen_pseudos").resolve()


def _gen_is_writable(p: Path) -> bool:
    try:
        p.mkdir(parents=True, exist_ok=True)
        probe = p / ".sa_write_probe"
        probe.write_text("1", encoding="ascii")
        probe.unlink(missing_ok=True)
        return True
    except OSError:
        return False


def _gen_first_writable(candidates: list[Path]) -> tuple[Path, str]:
    """Renvoie (chemin, warning). Le warning est vide si on est sur le 1er choix."""
    if not candidates:
        raise OSError("Aucun candidat de dossier fourni.")
    primary = candidates[0].resolve()
    if _gen_is_writable(primary):
        return primary, ""
    for alt in candidates[1:]:
        ap = alt.resolve()
        if _gen_is_writable(ap):
            return ap, (
                f"Dossier projet non inscriptible ({primary}) — bascule sur {ap}. "
                "Si vous voulez sauvegarder sous generation_pseudos, exécutez : "
                f"sudo chown -R $USER:$USER {_STANDALONE_ROOT}"
            )
    raise OSError(
        f"Aucun des emplacements n'est inscriptible : "
        f"{', '.join(str(c) for c in candidates)}"
    )


def _pseudo_local_inputs_dir_sa(generator: str) -> tuple[Path, str]:
    """pseudo_generator_templates/{ape,atompaw}/ — repli auto vers ~/.gen_pseudos puis /tmp/gen_pseudos."""
    g = (generator or "").strip().lower()
    sub = "ape" if g == "ape" else "atompaw"
    return _gen_first_writable([
        _STANDALONE_ROOT / "pseudo_generator_templates" / sub,
        _gen_user_state_root() / "pseudo_generator_templates" / sub,
        _gen_tmp_state_root() / "pseudo_generator_templates" / sub,
    ])


def _pseudo_gen_work_root_sa() -> tuple[Path, str]:
    """_work/ pour les exécutions APE/ATOMPAW — repli auto."""
    return _gen_first_writable([
        _STANDALONE_ROOT / "_work",
        _gen_user_state_root() / "_work",
        _gen_tmp_state_root() / "_work",
    ])


def _pseudo_gen_output_dir_sa() -> tuple[Path, str]:
    """Racine des sorties générées (pseudos_generes/ — rétrocompatibilité)."""
    return _gen_first_writable([
        _STANDALONE_ROOT / "pseudos_generes",
        _gen_user_state_root() / "pseudos_generes",
        _gen_tmp_state_root() / "pseudos_generes",
    ])


def _pseudo_gen_bucket_sa(generator: str) -> tuple[Path, str]:
    """Dossier par générateur : pseudos-ld1, pseudos-APE, pseudos-atompaw, pseudos-oncvpsp."""
    try:
        from generator_guide import output_dir_name
    except ImportError:
        def output_dir_name(g: str) -> str:
            return "pseudos_generes"
    sub = output_dir_name(generator)
    return _gen_first_writable([
        _STANDALONE_ROOT / sub,
        _gen_user_state_root() / sub,
        _gen_tmp_state_root() / sub,
    ])


def _ensure_generator_output_dirs_sa() -> list[str]:
    """Crée les 4 dossiers de sortie (un par générateur) à la racine du projet."""
    created: list[str] = []
    try:
        from generator_guide import GENERATOR_OUTPUT_DIRS
    except ImportError:
        GENERATOR_OUTPUT_DIRS = [
            "pseudos-ld1", "pseudos-APE", "pseudos-atompaw", "pseudos-oncvpsp",
        ]
    for sub in GENERATOR_OUTPUT_DIRS:
        for base in (_STANDALONE_ROOT, _gen_user_state_root(), _gen_tmp_state_root()):
            try:
                path = base / sub
                path.mkdir(parents=True, exist_ok=True)
                (path / "_runs").mkdir(parents=True, exist_ok=True)
                resolved = str(path.resolve())
                if resolved not in created:
                    created.append(resolved)
            except OSError:
                pass
    return created


def _archive_pseudo_run_sa(
    bucket: Path,
    element: str,
    generator: str,
    *,
    work_dir: Path | None = None,
    input_path: Path | None = None,
    log_text: str | None = None,
) -> str | None:
    """Archive entrée + logs dans <bucket>/_runs/<élément>_<horodatage>/."""
    try:
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        run_dir = bucket / "_runs" / f"{element}_{ts}"
        run_dir.mkdir(parents=True, exist_ok=True)
        meta = {
            "element": element,
            "generator": generator,
            "time": ts,
        }
        (run_dir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        if input_path and input_path.is_file():
            shutil.copy2(input_path, run_dir / input_path.name)
        if work_dir and work_dir.is_dir():
            for fn in sorted(work_dir.iterdir()):
                if fn.is_file() and fn.suffix.lower() in (".dat", ".in", ".out", ".upf", ".psp8", ".log"):
                    try:
                        shutil.copy2(fn, run_dir / fn.name)
                    except OSError:
                        pass
        if log_text:
            (run_dir / "run.log").write_text(log_text[-200000:], encoding="utf-8", errors="replace")
        return str(run_dir.resolve())
    except OSError:
        return None


def _find_oncv_dat_for_element(sym: str, z: int, ft: str | None = None) -> tuple[str | None, str]:
    """Cherche un .dat ONCV pour l'élément (sans repli silencieux sur Si)."""
    sym = sym.strip()
    if len(sym) == 1:
        sym = sym.upper()
    else:
        sym = sym[0].upper() + sym[1:].lower()
    # Z fiable depuis le symbole (évite z=14 par défaut API → rate 22_Ti.dat)
    try:
        from pseudo_auto_inputs import atomic_number as _az

        z_sym = int(_az(sym))
        if not z or z < 1 or (z_sym and z != z_sym):
            z = z_sym
    except Exception:
        if not z or z < 1:
            z = 0
    try:
        import lanthanide_nc as lnc

        if lnc.is_lanthanide(sym):
            dat = lnc.generate_oncv_dat(sym, f_treatment=ft, psfile="both")
            return dat, "generated_lanthanide"
    except Exception:
        pass
    cache_3d = _STANDALONE_ROOT / "oncv_templates_3d" / f"{sym}.dat"
    if cache_3d.is_file():
        return cache_3d.read_text(encoding="utf-8", errors="replace"), "cached_3d"
    cache_4d = _STANDALONE_ROOT / "oncv_templates_4d" / f"{sym}.dat"
    if cache_4d.is_file():
        return cache_4d.read_text(encoding="utf-8", errors="replace"), "cached_4d"
    try:
        import transition_3d_nc as t3d

        if t3d.needs_generated_dat(sym):
            dat = t3d.generate_oncv_dat(sym, psfile="both")
            try:
                cache_3d.parent.mkdir(parents=True, exist_ok=True)
                cache_3d.write_text(dat, encoding="utf-8")
            except OSError:
                pass
            return dat, "generated_3d"
    except Exception as ex:
        print(f"[oncv] transition_3d_nc {sym}: {ex}", flush=True)
    try:
        import transition_4d_nc as t4d

        if t4d.needs_generated_dat(sym):
            dat = t4d.generate_oncv_dat(sym, psfile="both")
            try:
                cache_4d.parent.mkdir(parents=True, exist_ok=True)
                cache_4d.write_text(dat, encoding="utf-8")
            except OSError:
                pass
            return dat, "generated_4d"
    except Exception as ex:
        print(f"[oncv] transition_4d_nc {sym}: {ex}", flush=True)
    # Fichiers officiels tests/data même si z était faux au départ
    tdir = _oncvpsp_tests_data_dir()
    if tdir and tdir.is_dir():
        tdir = Path(tdir)
        patterns = []
        if z:
            patterns.extend([
                tdir / f"{z:02d}_{sym}.dat",
                tdir / f"{z:02d}_{sym}_GHOST.dat",
                tdir / f"{z:02d}_{sym}_UPF.dat",
            ])
        patterns.extend(sorted(tdir.glob(f"*_{sym}.dat")))
        patterns.extend(sorted(tdir.glob(f"*_{sym}_*.dat")))
        seen: set[str] = set()
        for p in patterns:
            key = str(p)
            if key in seen or not p.is_file():
                continue
            seen.add(key)
            return p.read_text(encoding="utf-8", errors="replace"), f"tests_data:{p.name}"
    local = _STANDALONE_ROOT / f"oncv_default_{sym}.dat"
    if not local.is_file():
        local = _STANDALONE_ROOT / "data" / "oncv" / f"oncv_default_{sym}.dat"
    if local.is_file():
        return local.read_text(encoding="utf-8", errors="replace"), f"local:{local.name}"
    return None, "missing"


def _resolve_ape_bin_sa() -> Path | None:
    v = _env_str('APE_BIN') or _cfg_str('ape_bin')
    if v:
        p = Path(v).expanduser().resolve()
        if p.is_file():
            return p
    root = _STANDALONE_ROOT
    for cand in (
        root / 'bin' / 'ape',
        root / 'third_party' / 'ape' / 'bin' / 'ape',
    ):
        if cand.is_file() or cand.is_symlink():
            try:
                return cand.resolve()
            except OSError:
                if cand.is_file():
                    return cand
    w = shutil.which('ape')
    return Path(w).resolve() if w else None


def _resolve_atompaw_bin_sa() -> Path | None:
    v = _env_str('ATOMPAW_BIN') or _cfg_str('atompaw_bin')
    if v:
        p = Path(v).expanduser().resolve()
        if p.is_file():
            return p
    root = _STANDALONE_ROOT
    for cand in (
        root / 'bin' / 'atompaw',
        root / 'third_party' / 'atompaw' / 'bin' / 'atompaw',
        root / 'third_party' / 'atompaw' / 'bin' / 'AtomPAW',
        root / 'third_party' / 'atompaw' / 'bin' / 'atompaw.x',
    ):
        if cand.is_file() or cand.is_symlink():
            try:
                return cand.resolve()
            except OSError:
                if cand.is_file():
                    return cand
    for name in ('atompaw', 'AtomPAW', 'atompaw.x'):
        w = shutil.which(name)
        if w:
            return Path(w).resolve()
    return None


def _find_upf_files_in_dir(work_dir: Path) -> list[str]:
    """Liste tous les UPF dans un dossier de travail ATOMPAW (y compris El.XC-paw.UPF)."""
    found: list[str] = []
    try:
        for pat in ('*.UPF', '*.upf'):
            found.extend(str(p.resolve()) for p in work_dir.glob(pat))
        for pat in ('*.UPF', '*.upf'):
            found.extend(str(p.resolve()) for p in work_dir.rglob(pat))
    except OSError:
        pass
    # dédoublonnage en gardant le plus récent en tête
    uniq = []
    for p in sorted(set(found), key=lambda x: os.path.getmtime(x) if os.path.isfile(x) else 0, reverse=True):
        uniq.append(p)
    return uniq


def _safe_tmp_workdir_sa(continue_dir: str | None, tmp_root: Path, default_wd: Path) -> Path:
    tmp_root = tmp_root.resolve()
    if continue_dir and str(continue_dir).strip():
        try:
            cand = Path(str(continue_dir).strip()).expanduser().resolve()
            cand.relative_to(tmp_root)
            cand.mkdir(parents=True, exist_ok=True)
            return cand
        except Exception:
            pass
    default_wd.mkdir(parents=True, exist_ok=True)
    return default_wd.resolve()


def _copy_upf_outputs_sa(work_dir: Path, dest_dir: Path) -> list[str]:
    dest_dir.mkdir(parents=True, exist_ok=True)
    copied = []
    for pattern in ('*.UPF', '*.upf'):
        for f in work_dir.glob(pattern):
            try:
                t = dest_dir / f.name
                shutil.copy2(f, t)
                copied.append(str(t.resolve()))
            except OSError:
                continue
    return copied


def _collect_other_codes_from_run(
    *,
    log_text: str | None = None,
    qe_validation: dict | None = None,
    upf_path: str | Path | None = None,
    psp8_in_stdout: bool = False,
    work_dir: Path | None = None,
) -> list[dict[str, str]]:
    """Formats détectés hors conformité QE (ABINIT psp8, etc.)."""
    try:
        from generator_guide import detect_pseudo_formats_from_text
    except ImportError:
        return []
    chunks: list[str] = []
    if log_text:
        chunks.append(log_text)
    if upf_path and Path(upf_path).is_file():
        try:
            chunks.append(Path(upf_path).read_text(encoding='utf-8', errors='replace'))
        except OSError:
            pass
    if work_dir and work_dir.is_dir():
        for pat in ('*.psp8', '*.PSP8', '*.psp', '*.dat'):
            try:
                for f in work_dir.glob(pat):
                    if f.is_file() and f.stat().st_size > 100:
                        try:
                            chunks.append(f.read_text(encoding='utf-8', errors='replace')[:80000])
                        except OSError:
                            pass
            except OSError:
                pass
    merged = '\n'.join(chunks)
    det = detect_pseudo_formats_from_text(merged)
    codes = list(det.get('other_codes') or [])
    if psp8_in_stdout and not any(c.get('code') == 'abinit' for c in codes):
        codes.insert(0, {
            'code': 'abinit',
            'label': 'ABINIT',
            'format': 'psp8 dans la sortie (PSPCODE8)',
        })
    if qe_validation and qe_validation.get('conform_qe'):
        codes = [c for c in codes if c.get('code') != 'qe_partial']
    return codes


def _validate_upf_qe(path: str | Path | None, element: str | None = None) -> dict:
    """Vérifie qu'un fichier est un UPF lisible par Quantum ESPRESSO (pw.x)."""
    out = {
        'conform_qe': False,
        'format': None,
        'element_in_file': None,
        'size_bytes': 0,
        'errors': [],
        'advice': None,
        'other_codes': [],
    }
    if not path:
        out['errors'].append('Chemin UPF absent.')
        out['advice'] = 'Générez ou téléchargez un fichier .UPF.'
        return out
    p = Path(path).expanduser()
    if not p.is_file():
        out['errors'].append(f'Fichier introuvable : {p}')
        return out
    try:
        raw = p.read_text(encoding='utf-8', errors='replace')
    except OSError as e:
        out['errors'].append(str(e))
        return out
    out['size_bytes'] = p.stat().st_size
    if out['size_bytes'] < 200:
        out['errors'].append('Fichier trop petit pour un UPF valide.')
        return out
    has_v2 = bool(re.search(r'<UPF\s+version\s*=', raw, re.IGNORECASE))
    has_v1_begin = 'Begin PSP_UPF' in raw
    has_v1_end = 'End PSP_UPF' in raw
    has_ape_xml = (
        '<PP_HEADER>' in raw
        and '<PP_INFO>' in raw
        and ('<PP_MESH>' in raw or '<PP_RHOATOM>' in raw)
    )
    if has_v2:
        out['format'] = 'UPF v2 (XML)'
        if '</UPF>' not in raw and '<PP_HEADER' not in raw:
            out['errors'].append('XML UPF incomplet (balise </UPF> ou PP_HEADER manquante).')
        else:
            out['conform_qe'] = True
    elif has_ape_xml:
        out['format'] = 'UPF APE (PP_HEADER, compatible pw.x)'
        out['conform_qe'] = True
    elif has_v1_begin and has_v1_end:
        out['format'] = 'UPF v1 (PSP_UPF)'
        out['conform_qe'] = True
    elif has_v1_begin:
        out['format'] = 'UPF v1 (partiel)'
        out['errors'].append('Bloc Begin PSP_UPF sans End PSP_UPF.')
    else:
        out['errors'].append('Format non reconnu (attendu : Begin PSP_UPF ou <UPF version=…>).')
        out['advice'] = 'Pour ONCVPSP : psfile=upf ou both dans le .dat ; pour APE/ATOMPAW : conversion UPF explicite.'
        return out
    m_el = re.search(r'element\s*=\s*["\']([A-Za-z]{1,3})["\']', raw, re.IGNORECASE)
    if not m_el:
        m_el = re.search(
            r'^\s*([A-Za-z]{1,3})\s+Element\s*$',
            raw,
            re.MULTILINE | re.IGNORECASE,
        )
    if not m_el:
        m_el = re.search(r'<PP_HEADER[^>]*>\s*([A-Za-z]{1,3})\s', raw, re.IGNORECASE)
    if m_el:
        out['element_in_file'] = m_el.group(1).capitalize()
    if element and out['element_in_file']:
        el_req = re.sub(r'[^A-Za-z]', '', str(element))[:2].capitalize()
        if el_req and out['element_in_file'].capitalize() != el_req:
            out['errors'].append(
                f'Élément fichier ({out["element_in_file"]}) ≠ élément demandé ({el_req}).'
            )
            out['conform_qe'] = False
    try:
        from generator_guide import detect_pseudo_formats_from_text, format_other_codes_note

        det = detect_pseudo_formats_from_text(raw)
        out['other_codes'] = det.get('other_codes') or []
        if det.get('conform_qe') and not out['conform_qe']:
            out['conform_qe'] = True
            out['format'] = det.get('qe_format') or out['format']
    except ImportError:
        pass
    if out['conform_qe']:
        out['advice'] = 'Compatible Quantum ESPRESSO (pseudo_dir + ATOMIC_SPECIES).'
    elif out.get('other_codes'):
        try:
            from generator_guide import format_other_codes_note

            note = format_other_codes_note(out['other_codes'])
            out['advice'] = note or (
                'Non conforme Quantum ESPRESSO (pw.x) — voir formats alternatifs ci-dessous.'
            )
        except ImportError:
            out['advice'] = 'Non conforme Quantum ESPRESSO (pw.x).'
    return out


# Cible par défaut : Quantum ESPRESSO (UPF dans stdout via psfile=both).
ONCV_TARGET_DEFAULT = 'qe'
ONCV_PSFILE_FOR_TARGET = {
    'qe': 'both',           # UPF XML + psp8 (recommandé pour pw.x)
    'quantum_espresso': 'both',
    'pw': 'both',
    'espresso': 'both',
    'upf': 'upf',           # UPF seul (autre option QE)
    'both': 'both',
    'abinit': 'psp8',       # format ABINIT natif
    'abinit8': 'psp8',
    'multi': 'both',        # les deux formats
}


def _oncv_target_psfile(target_code: str | None) -> str:
    key = (target_code or ONCV_TARGET_DEFAULT).strip().lower()
    return ONCV_PSFILE_FOR_TARGET.get(key, 'both')


def _normalize_oncv_dat_for_target(
    content: str,
    target_code: str | None = None,
) -> tuple[str, list[str], str]:
    """
    Ajuste psfile selon la cible (QE par défaut).
    Retourne (contenu, avertissements, psfile_appliqué).
    """
    warnings: list[str] = []
    if not content:
        return content, warnings, _oncv_target_psfile(target_code)
    want = _oncv_target_psfile(target_code)
    out = content
    if not re.search(r'#\s*ATOM AND REFERENCE', out, re.IGNORECASE):
        warnings.append('Section « ATOM AND REFERENCE » absente — vérifiez le format .dat.')
    # Ligne atsym / z / nc / nv / iexc / psfile
    lines = out.splitlines()
    in_atom = False
    for i, line in enumerate(lines):
        if re.search(r'#\s*ATOM AND REFERENCE', line, re.IGNORECASE):
            in_atom = True
            continue
        if not in_atom:
            continue
        if line.strip().startswith('#'):
            continue
        m = re.match(
            r'^(\s*[A-Za-z]{1,2}\s+[\d.]+\s+\d+\s+\d+\s+-?\d+)\s*(\S*)\s*$',
            line,
        )
        if m:
            base = m.group(1).rstrip()
            had = (m.group(2) or '').strip().lower()
            if had and had != want:
                warnings.append(
                    f'psfile « {had} » → « {want} » (cible {target_code or ONCV_TARGET_DEFAULT}).'
                )
            elif not had:
                warnings.append(f'psfile « {want} » ajouté (cible Quantum ESPRESSO par défaut).')
            lines[i] = f'{base}   {want}'
            break
    out = '\n'.join(lines)
    if want in ('both', 'upf') and not re.search(r'\b(upf|both)\b', out, re.IGNORECASE):
        warnings.append(f'psfile={want} requis pour Quantum ESPRESSO.')
    if want == 'psp8' and re.search(r'\b(upf|both)\b', out, re.IGNORECASE):
        out = re.sub(r'\b(?:upf|both)\b', 'psp8', out, flags=re.IGNORECASE, count=1)
        warnings.append('psfile basculé vers « psp8 » (cible ABINIT).')
    if want in ('both', 'upf') and re.search(r'\bpsp8\b', out, re.IGNORECASE):
        out = re.sub(r'\bpsp8\b', want, out, flags=re.IGNORECASE)
        warnings.append(
            f'psfile « psp8 » → « {want} » : sortie UPF Quantum ESPRESSO (pw.x).'
        )
    if want in ('both', 'upf') and not out.lstrip().startswith('#'):
        out = (
            '# ONCVPSP — sortie Quantum ESPRESSO (psfile=both → UPF XML dans stdout)\n'
            + out
        )
    return out, warnings, want


def _normalize_oncv_dat_for_qe(content: str) -> tuple[str, list[str]]:
    """Rétrocompatibilité : normalisation cible QE."""
    out, warns, _ = _normalize_oncv_dat_for_target(content, ONCV_TARGET_DEFAULT)
    return out, warns


def _extract_upf_from_stdout_sa(text: str, dest: Path) -> Path | None:
    """Extrait UPF v2 (XML) ou v1 (Begin PSP_UPF) depuis la sortie ONCVPSP."""
    if not text:
        return None
    dest.parent.mkdir(parents=True, exist_ok=True)
    if re.search(r'<UPF\s+version', text, re.IGNORECASE):
        m = re.search(r'(<UPF\s+version.*?</UPF>)', text, re.DOTALL | re.IGNORECASE)
        if not m:
            m = re.search(r'(<UPF\s+version[\s\S]+)', text, re.IGNORECASE)
        if m:
            block = m.group(1).strip()
            if '</UPF>' not in block and '<PP_HEADER>' in block:
                block = block + '\n</UPF>\n'
            if not block.lstrip().startswith('<?xml'):
                block = '<?xml version="1.0" encoding="UTF-8"?>\n' + block
            dest.write_text(block + '\n', encoding='utf-8')
            return dest
    if 'Begin PSP_UPF' in text:
        m = re.search(r'(Begin PSP_UPF.*?End PSP_UPF)', text, re.DOTALL)
        if m:
            dest.write_text(m.group(1).strip() + '\n', encoding='utf-8')
            return dest
    return None


def _discover_oncv_upf_files_sa(work_dir: Path, element: str) -> list[str]:
    """Fichiers UPF possibles après ONCVPSP (cwd, sous-dossiers)."""
    found: list[str] = []
    el = re.sub(r'[^A-Za-z0-9._-]+', '', element or '')[:8]
    patterns = (
        f'{el}*.[Uu][Pp][Ff]',
        f'{el}*.oncvpsp.upf',
        '*.[Uu][Pp][Ff]',
        '*.oncvpsp.upf',
    )
    try:
        for pat in patterns:
            found.extend(str(p.resolve()) for p in work_dir.glob(pat))
        for pat in ('*.UPF', '*.upf', '*.oncvpsp.upf'):
            found.extend(str(p.resolve()) for p in work_dir.rglob(pat))
    except OSError:
        pass
    uniq: list[str] = []
    for p in sorted(set(found), key=lambda x: os.path.getmtime(x) if os.path.isfile(x) else 0, reverse=True):
        if os.path.isfile(p) and os.path.getsize(p) > 200:
            uniq.append(p)
    return uniq


def _finalize_upf_sa(
    upf_path: str | Path | None,
    element: str,
    generator: str,
    *,
    stdout_text: str | None = None,
    work_dir: Path | None = None,
    input_path: Path | None = None,
    log_text: str | None = None,
) -> dict:
    """
    Valide l'UPF, archive dans pseudos-<générateur>/ (et bibliothèque PSEUDOS/ si conforme QE).
    """
    element = re.sub(r'[^A-Za-z]+', '', str(element or 'X'))[:2] or 'X'
    gen = (generator or 'unknown').strip().lower()
    try:
        bucket, bucket_warn = _pseudo_gen_bucket_sa(gen)
    except OSError as e:
        return {
            'qe_validation': {'conform_qe': False, 'errors': [str(e)]},
            'copied_to_pseudos_generes': [],
            'saved_to_pseudos_dir': None,
            'warnings': [str(e)],
        }

    resolved: Path | None = None
    if upf_path:
        p = Path(upf_path).expanduser()
        if p.is_file():
            resolved = p.resolve()

    if resolved is None and work_dir:
        for cand_s in _discover_oncv_upf_files_sa(work_dir, element):
            resolved = Path(cand_s).resolve()
            break

    if resolved is None and stdout_text and work_dir:
        cand = work_dir / f'{element}_oncv.UPF'
        extracted = _extract_upf_from_stdout_sa(stdout_text, cand)
        if extracted and extracted.is_file():
            resolved = extracted.resolve()

    warnings: list[str] = []
    if bucket_warn:
        warnings.append(bucket_warn)

    run_archive = _archive_pseudo_run_sa(
        bucket, element, gen,
        work_dir=work_dir,
        input_path=input_path,
        log_text=log_text,
    )

    copied_gen: list[str] = []
    saved_pseudos: str | None = None
    qe_val = _validate_upf_qe(resolved, element)

    if resolved and qe_val.get('conform_qe'):
        os.makedirs(PSEUDOS, exist_ok=True)
        os.makedirs(bucket, exist_ok=True)
        dest_name = f'{element}_{resolved.name}' if not resolved.name.upper().startswith(element.upper()) else resolved.name
        try:
            dest_gen = bucket / dest_name
            shutil.copy2(resolved, dest_gen)
            copied_gen.append(str(dest_gen.resolve()))
        except OSError as e:
            warnings.append(f'Copie {bucket.name} : {e}')
        try:
            in_pseudos = False
            try:
                resolved.relative_to(Path(PSEUDOS).resolve())
                in_pseudos = True
                saved_pseudos = str(resolved)
            except ValueError:
                pass
            if not in_pseudos:
                dest_lib = Path(PSEUDOS) / dest_name
                shutil.copy2(resolved, dest_lib)
                saved_pseudos = str(dest_lib.resolve())
            else:
                saved_pseudos = str(resolved)
        except OSError as e:
            warnings.append(f'Copie bibliothèque pseudos : {e}')
    elif resolved:
        warnings.append('UPF présent mais non conforme QE — copie dans _non_conforme_QE/.')
        try:
            bad_dir = bucket / '_non_conforme_QE'
            bad_dir.mkdir(parents=True, exist_ok=True)
            bad_copy = bad_dir / resolved.name
            shutil.copy2(resolved, bad_copy)
            copied_gen.append(str(bad_copy.resolve()))
        except OSError as e:
            warnings.append(f'Archivage non conforme : {e}')

    return {
        'qe_validation': qe_val,
        'upf_path': str(resolved) if resolved else None,
        'upf_genere': resolved.name if resolved else None,
        'copied_to_pseudos_generes': copied_gen,
        'pseudos_generes_dir': str(bucket),
        'pseudos_bucket': str(bucket),
        'generator_output_dir': str(bucket),
        'run_archive_dir': run_archive,
        'saved_to_pseudos_dir': saved_pseudos,
        'pseudos_dir': PSEUDOS,
        'generator': gen,
        'warnings': warnings,
    }


ATOMPAW_INPUT_NAME_SA = 'atompaw.in'


def lister_upf(element=None):
    fichiers = []
    if not os.path.isdir(PSEUDOS):
        return fichiers
    pattern_UPF = glob.glob(os.path.join(PSEUDOS, '**', '*.UPF'), recursive=True)
    pattern_upf = glob.glob(os.path.join(PSEUDOS, '**', '*.upf'), recursive=True)
    for f in sorted(set(pattern_UPF + pattern_upf)):
        nom = os.path.basename(f)
        if element is None or \
           nom.lower().startswith(element.lower() + '.') or \
           nom.lower().startswith(element.lower() + '_'):
            rel = os.path.relpath(f, PSEUDOS)
            fichiers.append({
                'nom':     nom,
                'chemin':  rel,
                'taille':  os.path.getsize(f),
                'dossier': os.path.dirname(rel) or '.',
            })
    return fichiers

# ─── Routes ────────────────────────────────────────────────────────────────────

@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        'status':   'ok',
        'service':  'API Pseudopotentiels Standalone',
        'version':  '1.0',
        'qe_bin':   QE_BIN  or 'non détecté',
        'pseudos':  PSEUDOS,
        'inputs':   INPUTS,
        'outputs':  OUTPUTS,
        'tmp':      TMP,
        'logs':     LOGS,
        'port':     API_PORT,
    })


@app.route('/api/statut', methods=['GET'])
def statut():
    progs_qe = [
        'pw.x', 'ph.x', 'ld1.x', 'pp.x', 'dos.x', 'bands.x',
        'epsilon.x', 'matdyn.x', 'q2r.x', 'dynmat.x', 'projwfc.x',
        'pw2wannier90.x', 'wannier90.x', 'neb.x', 'cp.x', 'xspectra.x',
        'hp.x', 'kcw.x', 'turbo_lanczos.x', 'turbo_davidson.x',
    ]
    programmes = {}
    for prog in progs_qe:
        p = qe_bin(prog)
        programmes[prog] = os.path.isfile(p)

    return jsonify({
        'status':        'ok',
        'qe_bin':        QE_BIN,
        'pseudos_dir':   PSEUDOS,
        'inputs_dir':    INPUTS,
        'outputs_dir':   OUTPUTS,
        'tmp_dir':       TMP,
        'logs_dir':      LOGS,
        'programmes':    programmes,
        'nb_pseudos':    len(lister_upf()),
        'nb_inputs':     len(glob.glob(os.path.join(INPUTS, '**', '*.in'), recursive=True)),
    })


def _canon_bin(name: str) -> Path:
    """Chemin canonique autonomie : ./bin/<name> (symlink OK, non résolu)."""
    return _STANDALONE_ROOT / 'bin' / name


def _bin_entry(name: str, resolved: Path | None) -> dict:
    """Entrée détaillée pour l’UI Chemins PC (préfixe bin/ + cible réelle)."""
    canon = _canon_bin(name)
    display = str(canon) if (canon.is_file() or canon.is_symlink()) else (str(resolved) if resolved else '')
    real = ''
    if resolved:
        try:
            real = str(resolved.resolve())
        except OSError:
            real = str(resolved)
    elif canon.exists():
        try:
            real = str(canon.resolve())
        except OSError:
            real = str(canon)
    ok = bool(
        (canon.is_file() or canon.is_symlink())
        or (resolved is not None and resolved.is_file())
    )
    return {
        'name': name,
        'path': display,
        'realpath': real,
        'via_bin': bool(canon.is_file() or canon.is_symlink()),
        'ok': ok,
    }


@app.route('/api/chemins', methods=['GET'])
def chemins():
    """Tous les chemins du PC — autonomie 4 générateurs sous ./bin/."""
    gen_dirs: dict[str, str] = {}
    try:
        from generator_guide import GENERATOR_OUTPUT_DIRS, GENERATOR_OUTPUT_LABELS, output_dir_name
        for folder in GENERATOR_OUTPUT_DIRS:
            label = GENERATOR_OUTPUT_LABELS.get(folder, folder)
            for key, sub in (
                ('ld1.x', 'ld1'),
                ('ape', 'ape'),
                ('atompaw', 'atompaw'),
                ('oncvpsp', 'oncvpsp'),
            ):
                if output_dir_name(key) == folder:
                    try:
                        path, _ = _pseudo_gen_bucket_sa(key)
                        gen_dirs[label] = str(path)
                    except OSError:
                        gen_dirs[label] = str(_STANDALONE_ROOT / folder)
                    break
    except ImportError:
        pass

    ld1 = _resolve_ld1_bin()
    pw = _resolve_pw_bin()
    ape = _resolve_ape_bin_sa()
    atompaw = _resolve_atompaw_bin_sa()
    oncv = _resolve_oncvpsp_bin()
    bin_dir = str(_STANDALONE_ROOT / 'bin')
    generators = {
        'ld1.x': _bin_entry('ld1.x', ld1),
        'pw.x': _bin_entry('pw.x', pw),
        'ape': _bin_entry('ape', ape),
        'atompaw': _bin_entry('atompaw', atompaw),
        'oncvpsp.x': _bin_entry('oncvpsp.x', oncv),
    }
    n_ok = sum(1 for k in ('ld1.x', 'ape', 'atompaw', 'oncvpsp.x') if generators[k]['ok'])
    ld1_disp = generators['ld1.x']['path']
    pw_disp = generators['pw.x']['path']
    ape_disp = generators['ape']['path']
    aw_disp = generators['atompaw']['path']
    oncv_disp = generators['oncvpsp.x']['path']

    return jsonify({
        'projet': str(_STANDALONE_ROOT),
        'project_root': str(_STANDALONE_ROOT),
        'work_dir': str(_STANDALONE_ROOT),
        'bin_dir': bin_dir,
        'qe_bin': QE_BIN or bin_dir,
        'ld1_bin': ld1_disp,
        'pw_bin': pw_disp,
        'oncvpsp_bin': oncv_disp,
        'ape_bin': ape_disp,
        'atompaw_bin': aw_disp,
        'generators': generators,
        'autonomie': {
            'ready': n_ok == 4,
            'score_pct': int(round(100 * n_ok / 4)),
            'generators_ok': n_ok,
            'generators_total': 4,
            'qe_required': False,
            'prefix': './bin/',
            'message': (
                f'Autonomie {n_ok}/4 — préfixe {bin_dir}'
                if n_ok == 4
                else f'Incomplet {n_ok}/4 — lancez ./scripts/vendor_generators.sh'
            ),
        },
        'qe_optional': True,
        'autonomie_4gen': True,
        'vendor_qe_dir': bin_dir,
        'vendor_oncv_dir': bin_dir,
        'pseudos': PSEUDOS,
        'pseudos_generes': str(_STANDALONE_ROOT / 'pseudos_generes'),
        'inputs': INPUTS,
        'outputs': OUTPUTS,
        'tmp': TMP,
        'logs': LOGS,
        'generator_output_dirs': gen_dirs,
        'dossiers': {
            'bin': bin_dir,
            'pseudos': PSEUDOS,
            'pseudos_generes': str(_STANDALONE_ROOT / 'pseudos_generes'),
            'pseudos-ld1': gen_dirs.get('ld1.x (Quantum ESPRESSO)') or str(_STANDALONE_ROOT / 'pseudos-ld1'),
            'pseudos-APE': gen_dirs.get('APE') or str(_STANDALONE_ROOT / 'pseudos-APE'),
            'pseudos-atompaw': gen_dirs.get('ATOMPAW') or str(_STANDALONE_ROOT / 'pseudos-atompaw'),
            'pseudos-oncvpsp': gen_dirs.get('ONCVPSP') or str(_STANDALONE_ROOT / 'pseudos-oncvpsp'),
            'inputs': INPUTS,
            'outputs': OUTPUTS,
            '_work': TMP,
            'logs': LOGS,
            'templates': str(_STANDALONE_ROOT / 'pseudo_generator_templates'),
        },
        'interface_principale': INTERFACE_PRINCIPALE,
        'interface_pseudos': INTERFACE_PSEUDOS,
        'api_port': API_PORT,
        'api_url': f'http://127.0.0.1:{API_PORT}',
        'reference': {
            'qe_bin_ref': QE_BIN_REF,
            'pseudos_ref': PSEUDOS_REF,
            'inputs_ref': INPUTS_REF,
            'outputs_ref': OUTPUTS_REF,
            'cif_ref': CIF_REF,
            'structures_ref': STRUCTURES_REF,
        },
    })


@app.route('/api/pseudos/lister', methods=['GET'])
def pseudos_lister():
    element = request.args.get('element')
    fichiers = lister_upf(element)
    return jsonify({'success': True, 'pseudos': fichiers,
                    'total': len(fichiers), 'dossier': PSEUDOS})


@app.route('/api/pseudos/libraries/catalog', methods=['GET'])
def pseudos_libraries_catalog():
    """Métadonnées PSLibrary / PseudoDojo / SSSP + état des dossiers."""
    try:
        import pseudo_libraries as pl
    except ImportError:
        return jsonify({'success': False, 'error': 'pseudo_libraries.py absent.'}), 503
    meta = pl.get_catalog_metadata()
    inv = pl.scan_all_libraries(PSEUDOS)
    for lib in inv['libraries']:
        lib.pop('files', None)
    meta['inventory'] = inv
    meta['pseudos_root'] = PSEUDOS
    return jsonify({'success': True, **meta})


@app.route('/api/pseudos/libraries/search', methods=['GET'])
def pseudos_libraries_search():
    """Recherche d'UPF par élément dans toutes les bibliothèques."""
    element = (request.args.get('element') or request.args.get('sym') or '').strip()
    family = (request.args.get('family') or '').strip().lower()
    lib_id = (request.args.get('library') or request.args.get('lib') or '').strip()
    try:
        import pseudo_libraries as pl
    except ImportError:
        return jsonify({'success': False, 'error': 'pseudo_libraries.py absent.'}), 503
    if not element and not lib_id:
        return jsonify({'success': False, 'error': 'Paramètre element requis.'}), 400
    if lib_id:
        row = pl.scan_library(PSEUDOS, lib_id, element or None)
        libs = [row]
        total = row.get('file_count', 0)
    else:
        data = pl.scan_all_libraries(PSEUDOS, element)
        libs = data['libraries']
        if family:
            libs = [x for x in libs if x.get('family', '').lower() == family]
        total = sum(x.get('file_count', 0) for x in libs)
    return jsonify({
        'success': True,
        'pseudos_root': PSEUDOS,
        'element': element or None,
        'family': family or None,
        'libraries': libs,
        'total_matching_files': total,
    })


@app.route('/api/pseudos/libraries/ensure_dirs', methods=['POST', 'GET'])
def pseudos_libraries_ensure_dirs():
    """Crée l'arborescence standard des bibliothèques sous pseudos/."""
    try:
        import pseudo_libraries as pl
    except ImportError:
        return jsonify({'success': False, 'error': 'pseudo_libraries.py absent.'}), 503
    created = pl.ensure_library_tree(PSEUDOS)
    return jsonify({
        'success': True,
        'pseudos_root': PSEUDOS,
        'created': created,
        'standard_subdirs': pl.STANDARD_SUBDIRS,
    })


@app.route('/api/pseudos/libraries/organize', methods=['POST', 'GET'])
def pseudos_libraries_organize():
    """Synchronise PBE/USPP/PAW legacy et UPF à la racine vers PSLibrary_* / PseudoDojo_*."""
    try:
        import pseudo_libraries as pl
    except ImportError:
        return jsonify({'success': False, 'error': 'pseudo_libraries.py absent.'}), 503
    pl.ensure_library_tree(PSEUDOS)
    result = pl.organize_libraries(PSEUDOS, copy_files=True)
    return jsonify({'success': True, **result})


@app.route('/api/pseudos/verifier/<nom>', methods=['GET'])
def pseudos_verifier(nom):
    for ext in ['', '.UPF', '.upf']:
        cible = os.path.join(PSEUDOS, nom + ext)
        if os.path.isfile(cible):
            return jsonify({'success': True, 'exists': True,
                            'chemin': cible, 'size': os.path.getsize(cible)})
    for f in lister_upf():
        if f['nom'].lower() in [nom.lower(), (nom + '.upf').lower()]:
            cible = os.path.join(PSEUDOS, f['chemin'])
            return jsonify({'success': True, 'exists': True,
                            'chemin': cible, 'size': os.path.getsize(cible)})
    return jsonify({'success': True, 'exists': False, 'nom': nom})


@app.route('/api/pseudos/generer_ld1', methods=['POST'])
def pseudos_generer_ld1():
    data      = request.get_json() or {}
    element   = data.get('element', 'H')
    # Compatibilité : l'interface envoie parfois `ld1_content` au lieu de `input`
    input_ld1 = data.get('input') or data.get('ld1_content', '')

    if not input_ld1:
        return jsonify({'success': False, 'error': 'Input ld1.x vide'})

    ld1_path = _resolve_ld1_bin()
    ld1 = str(ld1_path) if ld1_path else ''
    if not ld1 or not os.path.isfile(ld1):
        return jsonify({
            'success': False,
            'error': (
                'ld1.x non trouvé.\n'
                'Mode autonome : placez ld1.x dans bin/ld1.x\n'
                'ou définissez ld1_bin dans api_config.json / LD1_BIN / --ld1.\n'
                'pw.x (tests) : bin/pw.x — même dossier que qe_bin=./bin.'
            ),
        }), 503

    os.makedirs(TMP, exist_ok=True)
    input_file  = os.path.join(TMP, f'ld1_{element}.in')
    output_file = os.path.join(TMP, f'ld1_{element}.out')

    with open(input_file, 'w') as f:
        f.write(input_ld1)

    # Nom UPF déclaré dans l'entrée (évite de recycler un vieux {element}*.UPF)
    m_upf = re.search(
        r"file_pseudopw\s*=\s*['\"]?([^'\"\s,/]+)",
        input_ld1,
        re.I,
    )
    expected_upf = (m_upf.group(1).strip() if m_upf else '') or ''
    t_run = time.time()

    try:
        result = subprocess.run(
            [ld1, '-input', input_file],
            capture_output=True, text=True, timeout=300, cwd=PSEUDOS
        )
        with open(output_file, 'w') as f:
            f.write(result.stdout + result.stderr)

        candidates = []
        if expected_upf:
            p_exp = os.path.join(PSEUDOS, expected_upf)
            if os.path.isfile(p_exp) and os.path.getmtime(p_exp) >= (t_run - 2.0):
                candidates = [p_exp]
        if not candidates:
            for pat in (f'{element}*.UPF', f'{element}*.upf'):
                for p in glob.glob(os.path.join(PSEUDOS, pat)):
                    try:
                        if os.path.getmtime(p) >= (t_run - 2.0):
                            candidates.append(p)
                    except OSError:
                        pass
        upf_pick = max(candidates, key=os.path.getmtime) if candidates else None
        upf_genere = os.path.basename(upf_pick) if upf_pick else None

        out_s = result.stdout or ''
        err_s = result.stderr or ''
        log_combined = out_s + '\n' + err_s
        fatal = _sa_log_fatal_errors(log_combined)
        diagnostics = _ld1_diagnostics(log_combined, input_ld1, element)
        rc_ok = result.returncode == 0 and not fatal
        fin = _finalize_upf_sa(upf_pick, element, 'ld1.x') if upf_pick else {
            'qe_validation': {'conform_qe': False, 'errors': ['Aucun UPF produit.']},
            'copied_to_pseudos_generes': [],
            'saved_to_pseudos_dir': None,
            'pseudos_generes_dir': None,
            'warnings': [],
        }
        qe_ok = fin['qe_validation'].get('conform_qe', False)
        run_ok = rc_ok and bool(upf_pick) and qe_ok
        payload = {
            'success':     run_ok,
            'upf_qe_ready': qe_ok,
            'returncode':  result.returncode,
            'output':      out_s[-8000:],
            'stderr':      err_s[-4000:],
            'log':         log_combined[-12000:],
            'upf_genere':  upf_genere or fin.get('upf_genere'),
            'upf_path':    fin.get('upf_path') or upf_pick,
            'output_file': output_file,
            'pseudos_dir': PSEUDOS,
            'qe_validation': fin['qe_validation'],
            'copied_to_pseudos_generes': fin.get('copied_to_pseudos_generes', []),
            'pseudos_generes_dir': fin.get('pseudos_generes_dir'),
            'saved_to_pseudos_dir': fin.get('saved_to_pseudos_dir'),
            'generator': 'ld1.x',
            'fatal_errors': fatal,
            'diagnostics': diagnostics,
        }
        if fin.get('warnings'):
            payload['warnings'] = fin['warnings']
        if not run_ok:
            if fatal:
                payload['error'] = fatal[0]
            elif not upf_pick:
                payload['error'] = (
                    f'ld1.x terminé (code {result.returncode}) mais aucun UPF {element}*.UPF dans {PSEUDOS}.'
                )
            elif not rc_ok:
                payload['error'] = (
                    f'ld1.x a quitté avec le code {result.returncode}. '
                    'Voir la sortie ci-dessous.'
                )
            else:
                payload['error'] = 'UPF produit mais non conforme Quantum ESPRESSO.'
        elif upf_genere is None:
            payload['warning'] = (
                f'ld1.x a retourné 0 mais aucun fichier {element}*.UPF détecté dans {PSEUDOS}'
            )
        elif not fin['qe_validation'].get('conform_qe'):
            payload['warning'] = (
                'UPF détecté mais non conforme au format Quantum ESPRESSO : '
                + '; '.join(fin['qe_validation'].get('errors') or [])
            )
        return jsonify(payload)
    except subprocess.TimeoutExpired:
        return jsonify({'success': False, 'error': 'Timeout 120s — calcul ld1.x trop long'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route('/api/pseudos/voir_output', methods=['GET'])
def pseudos_voir_output():
    element     = request.args.get('element', '')
    output_file = os.path.join(TMP, f'ld1_{element}.out')
    if os.path.isfile(output_file):
        with open(output_file) as f:
            contenu = f.read()
        return jsonify({'success': True, 'contenu': contenu, 'fichier': output_file})
    return jsonify({'success': False, 'error': f'Pas de sortie ld1.x pour {element}'})


@app.route('/api/pseudos/telecharger', methods=['POST'])
def pseudos_telecharger():
    data    = request.get_json() or {}
    element = data.get('element', '')
    source  = data.get('source', 'pseudodojo')

    if not element:
        return jsonify({'success': False, 'error': 'Élément manquant'})

    sym = re.sub(r'[^A-Za-z]+', '', str(element))[:2].capitalize() or element
    os.makedirs(PSEUDOS, exist_ok=True)

    try:
        import pseudo_libraries as pl
        import lanthanide_nc as lnc
        libs_order = ['Lanthanides_NC_PBE', 'PseudoDojo_standard', 'PseudoDojo_stringent']
        if not lnc.is_lanthanide(sym):
            libs_order = None
        if libs_order:
            for lib_id in libs_order:
                row = pl.scan_library(PSEUDOS, lib_id, sym)
                for f in row.get('files') or []:
                    src = f.get('path')
                    if not src or not os.path.isfile(src):
                        continue
                    fin = _finalize_upf_sa(src, sym, 'bibliotheque')
                    if fin['qe_validation'].get('conform_qe'):
                        return jsonify({
                            'success': True,
                            'source': 'local',
                            'library': lib_id,
                            'fichier': fin.get('saved_to_pseudos_dir') or src,
                            'path': fin.get('upf_path'),
                            'qe_validation': fin['qe_validation'],
                        })
        inv = pl.scan_all_libraries(PSEUDOS, sym)
        prefer = ('ONCV', 'oncv', 'pbe', 'NC', 'nc', '_sp', 'f-in-core')
        for lib in inv.get('libraries', []):
            for f in lib.get('files') or []:
                name = f.get('name', '')
                if not any(p in name for p in prefer):
                    continue
                src = f.get('path')
                if not src or not os.path.isfile(src):
                    continue
                fin = _finalize_upf_sa(src, sym, 'bibliotheque')
                if fin['qe_validation'].get('conform_qe'):
                    return jsonify({
                        'success': True,
                        'source': 'local',
                        'library': lib.get('id'),
                        'fichier': fin.get('saved_to_pseudos_dir') or src,
                        'path': fin.get('upf_path'),
                        'qe_validation': fin['qe_validation'],
                    })
    except ImportError:
        pass
    except Exception:
        pass

    urls = []
    if source == 'pseudodojo':
        base = 'https://pseudo-dojo.org/pseudos'
        urls = [
            f'{base}/pbe_s_sr/{element}.upf',
            f'{base}/pbe_nc_sr/{element}.upf',
        ]
    elif source == 'sssp':
        urls = [f'https://archive.materialscloud.org/record/file?filename={element}.upf&record_id=1043']

    dest = os.path.join(PSEUDOS, f'{sym}_ONCV_PBE.upf')
    for url in urls:
        try:
            r = subprocess.run(['curl', '-L', '-s', '-o', dest, url], timeout=30)
            if r.returncode == 0 and os.path.getsize(dest) > 100:
                fin = _finalize_upf_sa(dest, sym, 'telechargement')
                if fin['qe_validation'].get('conform_qe'):
                    return jsonify({
                        'success': True,
                        'url': url,
                        'fichier': fin.get('saved_to_pseudos_dir') or dest,
                        'qe_validation': fin['qe_validation'],
                    })
        except Exception:
            continue

    return jsonify({
        'success': False,
        'error': (
            f'Aucun UPF {sym} trouvé localement (PseudoDojo/ONCV) ni en téléchargement. '
            'Onglet PseudoDojo ou ONCVPSP (psfile=both, puis relancer).'
        ),
    })


@app.route('/api/pseudos/oncv_status', methods=['GET'])
def pseudos_oncv_status():
    exe = _resolve_oncvpsp_bin()
    tdir = _oncvpsp_tests_data_dir()
    loc = _oncv_local_lib()
    checked = []
    for c in _oncvpsp_candidate_paths()[:10]:
        try:
            rp = c.resolve()
        except OSError:
            rp = c
        checked.append({
            'path': str(rp),
            'exists': rp.is_file(),
            'executable': _path_executable(rp),
        })
    return jsonify({
        'available': bool(exe),
        'path': str(exe) if exe else None,
        'tests_data': str(tdir) if tdir else None,
        'ld_local_lib': str(loc) if loc else None,
        'default_target_code': ONCV_TARGET_DEFAULT,
        'default_psfile': _oncv_target_psfile(ONCV_TARGET_DEFAULT),
        'oncvpsp_bin_config': _cfg_str('oncvpsp_bin') or None,
        'oncvpsp_bin_env': _env_str('ONCVPSP_BIN') or None,
        'home': str(Path.home()),
        'candidates_checked': checked,
        'hint': (
            'Binaire OK — lancez oncvpsp via l’interface.'
            if exe
            else 'Définissez oncvpsp_bin dans generation_pseudos/api_config.json '
                 'ou ONCVPSP_BIN, puis ./DEMARRER.sh'
        ),
    })


@app.route('/api/pseudos/lanthanide_nc_guide', methods=['GET'])
def pseudos_lanthanide_nc_guide():
    """Guide méthodologique NC pour lanthanides (4f open core vs valence)."""
    sym = (request.args.get('element') or request.args.get('sym') or 'Nd').strip()
    ft = (request.args.get('f_treatment') or request.args.get('f_4f') or 'valence_f').strip()
    try:
        import lanthanide_nc as lnc
    except ImportError:
        return jsonify({'success': False, 'error': 'lanthanide_nc.py absent.'}), 503
    try:
        sym_n = lnc._norm(sym) if hasattr(lnc, '_norm') else sym
        if not lnc.is_lanthanide(sym_n):
            return jsonify({
                'success': False,
                'error': f'{sym_n} n’est pas un lanthanide (Z 57–71).',
            }), 400
        guide = lnc.get_guide(sym_n, ft)
        guide['oncv_dat_preview'] = lnc.generate_oncv_dat(
            sym_n, f_treatment=ft, xc=request.args.get('xc') or 'gga_pbe', psfile='both',
        )[:2000]
        return jsonify({'success': True, **guide})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400


@app.route('/api/pseudos/generator_tab_guide', methods=['GET'])
def pseudos_generator_tab_guide():
    """Conseils affichés lors du choix d'un onglet générateur (fiabilité QE par famille)."""
    tab = (request.args.get('tab') or request.args.get('tab_id') or '').strip()
    sym = (request.args.get('element') or request.args.get('sym') or '').strip() or None
    try:
        from generator_guide import tab_guide

        return jsonify(tab_guide(tab, sym))
    except ImportError:
        return jsonify({'tab': tab, 'element': sym, 'message': 'Guide générateur indisponible.'})


@app.route('/api/pseudos/oncv_input_template', methods=['GET'])
def pseudos_oncv_input_template():
    el = request.args.get('element', 'Si')
    zraw = request.args.get('z', '14')
    ft = (request.args.get('f_treatment') or request.args.get('f_4f') or '').strip() or None
    xc = (request.args.get('xc') or 'gga_pbe').strip()
    target_code = (request.args.get('target_code') or request.args.get('target') or ONCV_TARGET_DEFAULT).strip()
    try:
        z = int(zraw)
    except ValueError:
        z = 14
    sym = el.strip()
    if len(sym) == 1:
        sym = sym.upper()
    else:
        sym = sym[0].upper() + sym[1:].lower()
    try:
        from pseudo_auto_inputs import atomic_number as _az
        z = int(_az(sym))
    except Exception:
        pass
    raw, source = _find_oncv_dat_for_element(sym, z, ft)
    if not raw:
        return jsonify({
            'error': f'Aucun modèle ONCV pour {sym} (Z={z}).',
            'hint': (
                'Ne pas utiliser le fichier Si par défaut pour un autre élément. '
                'Importez PseudoDojo / Lanthanides_NC_PBE ou placez oncv_default_<sym>.dat.'
            ),
            'available_examples': ['14_Si', '22_Ti', '29_Cu', '57_La', 'Mn (généré 3d)', '60_Nd_GHOST'],
        }), 404
    norm, warns, ps = _normalize_oncv_dat_for_target(raw, target_code)
    header = (
        f"# Source modèle : {source} — élément {sym} (Z={z}) — psfile cible : {ps}\n"
        f"# NE PAS lancer ce fichier pour un autre symbole sans le régénérer.\n"
    )
    if warns:
        header += '# ' + ' | '.join(warns) + '\n'
    return Response(header + norm, mimetype='text/plain; charset=utf-8')


@app.route('/api/pseudos/run_oncvpsp', methods=['POST'])
def pseudos_run_oncvpsp():
    data = request.get_json() or {}
    content = (data.get('input') or '').strip()
    element = re.sub(r'[^A-Za-z0-9._-]+', '', str(data.get('element') or 'X'))[:8] or 'X'
    if not content or len(content) > 500000:
        return jsonify({'success': False, 'error': "Contenu d'entrée vide ou trop volumineux."}), 400

    target_code = (data.get('target_code') or data.get('target') or ONCV_TARGET_DEFAULT).strip()
    content, norm_warns, psfile_used = _normalize_oncv_dat_for_target(content, target_code)
    input_normalized = bool(norm_warns) or psfile_used in ('both', 'upf')

    exe = _resolve_oncvpsp_bin()
    if not exe:
        return jsonify({
            'success': False,
            'error': 'oncvpsp.x introuvable. Installez ONCVPSP ou définissez ONCVPSP_BIN.',
        }), 503

    try:
        bucket, _ = _pseudo_gen_bucket_sa('oncvpsp')
    except OSError:
        bucket = Path(TMP)
    tmp_dir = bucket / '_work' / f'oncv_{element}'
    tmp_dir.mkdir(parents=True, exist_ok=True)
    infile = tmp_dir / f'oncv_{element}.dat'
    outfile = tmp_dir / f'oncv_{element}.out'
    infile.write_text(content, encoding='utf-8')
    # Vérifier cohérence symbole / entrée (évite Si.dat pour Fe/Co…)
    sym_expect = re.sub(r'[^A-Za-z]+', '', element)[:2]
    m_at = re.search(
        r'#\s*ATOM AND REFERENCE.*?\n\s*([A-Za-z]{1,2})\s+([\d.]+)',
        content,
        re.IGNORECASE | re.DOTALL,
    )
    auto_swapped = False
    if m_at and sym_expect:
        atsym = m_at.group(1).strip()
        if atsym.lower() != sym_expect.lower():
            z_el = 0
            try:
                mod = _load_pseudo_auto_inputs_sa()
                if mod:
                    z_el = int(mod.atomic_number(sym_expect))
            except Exception:
                pass
            if not z_el:
                try:
                    z_el = int(float(m_at.group(2)))
                except ValueError:
                    z_el = 0
            raw_fix, src_fix = _find_oncv_dat_for_element(sym_expect, z_el, None)
            if raw_fix:
                content, norm_warns, psfile_used = _normalize_oncv_dat_for_target(raw_fix, target_code)
                infile.write_text(content, encoding='utf-8')
                auto_swapped = True
                input_normalized = True
                norm_warns = list(norm_warns or []) + [
                    f'Entrée « {atsym} » remplacée par le modèle {sym_expect} ({src_fix}).'
                ]
            else:
                return jsonify({
                    'success': False,
                    'error': (
                        f'Entrée .dat pour « {atsym} » mais élément demandé « {sym_expect} ». '
                        f'Aucun modèle ONCV pour {sym_expect} — placez '
                        f'oncv_templates_3d/{sym_expect}.dat ou cliquez « Recharger modèle » '
                        '(pas de repli Si).'
                    ),
                }), 400

    env = os.environ.copy()
    loclib = _oncv_local_lib()
    if loclib is not None:
        o = env.get('LD_LIBRARY_PATH', '')
        s = str(loclib)
        if s not in o.split(':'):
            env['LD_LIBRARY_PATH'] = s + (':' + o if o else '')

    # stdin = fichier ouvert (comme « oncvpsp < f.dat »), pas un tuyau — backspace autorisé.
    t_run = time.time()
    try:
        with open(infile, 'r', encoding='utf-8', errors='replace') as inf:
            proc = subprocess.run(
                [str(exe)],
                stdin=inf,
                capture_output=True,
                text=True,
                timeout=300,
                cwd=str(tmp_dir),
                env=env,
            )
    except subprocess.TimeoutExpired:
        return jsonify({'success': False, 'error': 'Timeout 300 s (ONCVPSP).'}), 500
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

    out_s = proc.stdout or ''
    out_e = proc.stderr or ''
    with open(outfile, 'w', encoding='utf-8', errors='replace') as f:
        f.write(out_s)
        f.write('\n--- stderr ---\n')
        f.write(out_e)

    # Ne retenir que les UPF écrits pendant ce run (évite un vieux oncv_Fe/*.UPF)
    upf_files = [
        p for p in _discover_oncv_upf_files_sa(tmp_dir, element)
        if os.path.isfile(p) and os.path.getmtime(p) >= (t_run - 2.0)
    ]
    upf_name = upf_files[0] if upf_files else None

    upf_in_stdout = (
        'Begin PSP_UPF' in out_s
        or bool(re.search(r'<UPF\s+version', out_s, re.IGNORECASE))
    )
    psp8_in_stdout = 'Begin PSPCODE8' in out_s
    log_combined = out_s + '\n' + out_e
    fatal = _sa_log_fatal_errors(log_combined)
    run_ok = proc.returncode == 0 and not fatal
    note = None
    if fatal:
        note = '; '.join(fatal)
    fin = _finalize_upf_sa(
        upf_name,
        element,
        'oncvpsp',
        stdout_text=out_s if (upf_in_stdout or psp8_in_stdout) else None,
        work_dir=tmp_dir,
        input_path=infile,
        log_text=log_combined,
    )
    if norm_warns:
        fin.setdefault('warnings', []).extend(norm_warns)
    qe_ok = fin['qe_validation'].get('conform_qe', False)
    if run_ok and not fin.get('upf_path') and not upf_name:
        if upf_in_stdout:
            note = 'UPF dans stdout mais extraction échouée — voir oncv_*.out (XML </UPF> ou Begin PSP_UPF).'
        elif psp8_in_stdout:
            note = 'Sortie psp8 seulement — utilisez psfile=both puis relancez (normalisation auto possible).'
        else:
            note = 'Pas de .UPF détecté — voir oncv_*.out et la liste des fichiers.'
    elif fin['qe_validation'].get('conform_qe') and fin.get('copied_to_pseudos_generes'):
        note = (
            f'UPF conforme QE — sauvegardé dans {fin.get("pseudos_bucket") or "pseudos-oncvpsp"}/ '
            'et bibliothèque pseudos.'
        )
    elif run_ok and not qe_ok:
        note = (note or '') + (
            ' Calcul ONCV terminé sans UPF conforme QE — voir _non_conforme_QE/ ou PseudoDojo.'
        )

    files_in_tmp = []
    try:
        for fn in sorted(os.listdir(tmp_dir)):
            fp = tmp_dir / fn
            if fp.is_file():
                files_in_tmp.append({
                    'name': fn,
                    'path': str(fp.resolve()),
                    'size': os.path.getsize(fp),
                })
    except OSError:
        pass

    tgt = target_code.lower()
    qe_target = tgt in ('qe', 'quantum_espresso', 'pw', 'espresso', 'upf', 'both', 'multi', '')
    if qe_target or tgt == '':
        success = run_ok and qe_ok
    else:
        success = run_ok and (qe_ok or psp8_in_stdout)
    other_codes: list[dict[str, str]] = []
    qe_status: dict = {}
    try:
        from generator_guide import classify_qe_status

        other_codes = _collect_other_codes_from_run(
            log_text=log_combined,
            qe_validation=fin['qe_validation'],
            upf_path=fin.get('upf_path') or upf_name,
            psp8_in_stdout=psp8_in_stdout,
            work_dir=tmp_dir,
        )
        qe_status = classify_qe_status(
            "oncvpsp",
            upf_qe_ready=qe_ok,
            upf_found=bool(fin.get("upf_path") or upf_name),
            run_completed=run_ok,
            returncode=proc.returncode,
            fatal_errors=fatal,
            element=element,
            other_codes=other_codes,
        )
    except Exception:
        qe_status = {"level": "conform_qe" if qe_ok else "non_conforme", "alternatives": []}
    return jsonify({
        'success': success,
        'upf_qe_ready': qe_ok,
        'qe_status_level': qe_status.get("level"),
        'qe_status': qe_status,
        'fatal_errors': fatal,
        'other_codes': other_codes,
        'alternatives': qe_status.get("alternatives") or [],
        'run_completed': run_ok,
        'target_code': target_code or ONCV_TARGET_DEFAULT,
        'psfile_used': psfile_used,
        'input_normalized': input_normalized,
        'upf_file_detected': fin.get('upf_path') is not None,
        'upf_in_stdout': upf_in_stdout,
        'psp8_in_stdout': psp8_in_stdout,
        'returncode': proc.returncode,
        'output': out_s[-12000:],
        'stderr': out_e[-4000:],
        'upf_path': fin.get('upf_path') or upf_name,
        'upf_genere': fin.get('upf_genere') or (os.path.basename(upf_name) if upf_name else None),
        'input_file': str(infile),
        'output_file': str(outfile),
        'work_dir': str(tmp_dir),
        'files_in_tmp': files_in_tmp,
        'note': note,
        'warnings': list(dict.fromkeys((fin.get('warnings') or []) + list(norm_warns or []))),
        'input_auto_swapped': auto_swapped,
        'qe_validation': fin['qe_validation'],
        'copied_to_pseudos_generes': fin.get('copied_to_pseudos_generes', []),
        'pseudos_generes_dir': fin.get('pseudos_generes_dir'),
        'pseudos_bucket': fin.get('pseudos_bucket'),
        'run_archive_dir': fin.get('run_archive_dir'),
        'saved_to_pseudos_dir': fin.get('saved_to_pseudos_dir'),
        'pseudos_dir': PSEUDOS,
        'generator': 'oncvpsp',
        'validation': {
            'upf_created': fin.get('upf_path') is not None,
            'qe_conform': qe_ok,
        },
    })


@app.route('/api/pseudos/version', methods=['GET'])
def pseudos_version_sa():
    """Identification rapide de la version de code chargée en mémoire."""
    return jsonify({
        'build_tag': API_BUILD_TAG,
        'pid': os.getpid(),
        'source_file': os.path.abspath(__file__),
        'source_mtime': datetime.fromtimestamp(os.path.getmtime(__file__)).isoformat(timespec='seconds'),
    })


@app.route('/api/pseudos/diagnose', methods=['GET'])
def pseudos_diagnose_sa():
    """État complet du générateur autonome : binaires, dossiers, gabarits, env."""

    def _dir_test(label, getter):
        try:
            p, warn = getter()
            return {
                'label': label,
                'path': str(p),
                'writable': True,
                'warning': warn or None,
            }
        except Exception as e:
            return {
                'label': label,
                'path': None,
                'writable': False,
                'error': str(e),
            }

    ape = _resolve_ape_bin_sa()
    atompaw = _resolve_atompaw_bin_sa()
    ld1 = _resolve_ld1_bin()
    oncv = _resolve_oncvpsp_bin()
    pw = _resolve_pw_bin()
    auto_mod = _load_pseudo_auto_inputs_sa()

    ape_tpl = _pseudo_template_file_sa('ape.inp.template')
    atompaw_tpl = _pseudo_template_file_sa('atompaw.in.template')

    gens = {
        'ld1.x': _bin_entry('ld1.x', ld1),
        'pw.x': _bin_entry('pw.x', pw),
        'ape': _bin_entry('ape', ape),
        'atompaw': _bin_entry('atompaw', atompaw),
        'oncvpsp': _bin_entry('oncvpsp.x', oncv),
    }
    bins = {
        k: {'found': v['ok'], 'path': v['path'] or None, 'realpath': v.get('realpath') or None, 'via_bin': v.get('via_bin')}
        for k, v in gens.items()
    }
    n_ok = sum(1 for k in ('ld1.x', 'ape', 'atompaw', 'oncvpsp') if bins[k]['found'])
    info = {
        'ok': True,
        'build_tag': API_BUILD_TAG,
        'pid': os.getpid(),
        'source_file': os.path.abspath(__file__),
        'source_mtime': datetime.fromtimestamp(os.path.getmtime(__file__)).isoformat(timespec='seconds'),
        'standalone_root': str(_STANDALONE_ROOT),
        'autonomie': {
            'qe_required': False,
            'qe_bin': QE_BIN or str(_STANDALONE_ROOT / 'bin'),
            'pw_x': bool(bins['pw.x']['found']),
            'ld1_x': bool(bins['ld1.x']['found']),
            'vendor_qe': str(_STANDALONE_ROOT / 'bin'),
            'vendor_oncv': str(_STANDALONE_ROOT / 'bin'),
            'bin_dir': str(_STANDALONE_ROOT / 'bin'),
            'generators_ok': n_ok,
            'generators_total': 4,
            'score_pct': int(round(100 * n_ok / 4)),
            'ready': n_ok == 4,
            'message': f'Autonomie {n_ok}/4 — préfixe {_STANDALONE_ROOT / "bin"}',
        },
        'binaries': bins,
        'auto_inputs_module': auto_mod is not None,
        'templates': {
            'ape.inp.template': str(ape_tpl) if ape_tpl else None,
            'atompaw.in.template': str(atompaw_tpl) if atompaw_tpl else None,
        },
        'directories': [
            _dir_test('pseudo_generator_templates/ape', lambda: _pseudo_local_inputs_dir_sa('ape')),
            _dir_test('pseudo_generator_templates/atompaw', lambda: _pseudo_local_inputs_dir_sa('atompaw')),
            _dir_test('_work', _pseudo_gen_work_root_sa),
            _dir_test('pseudos-ld1', lambda: _pseudo_gen_bucket_sa('ld1')),
            _dir_test('pseudos-APE', lambda: _pseudo_gen_bucket_sa('ape')),
            _dir_test('pseudos-atompaw', lambda: _pseudo_gen_bucket_sa('atompaw')),
            _dir_test('pseudos-oncvpsp', lambda: _pseudo_gen_bucket_sa('oncvpsp')),
        ],
        'environment': {
            k: os.environ.get(k, '') for k in (
                'APE_BIN', 'ATOMPAW_BIN', 'HOME', 'PATH', 'USER',
            )
        },
        'port': API_PORT,
        'hint': (
            "Si un dossier bascule sur ~/.gen_pseudos ou /tmp, le dossier du projet "
            "n'est pas inscriptible — exécutez : sudo chown -R $USER:$USER \"$(pwd)\""
        ),
    }
    return jsonify(info)


@app.route('/api/pseudos/ape_status', methods=['GET'])
def pseudos_ape_status():
    exe = _resolve_ape_bin_sa()
    return jsonify({'available': bool(exe), 'path': str(exe) if exe else None})


@app.route('/api/pseudos/atompaw_status', methods=['GET'])
def pseudos_atompaw_status():
    exe = _resolve_atompaw_bin_sa()
    return jsonify({'available': bool(exe), 'path': str(exe) if exe else None})


@app.route('/api/pseudos/auto_inputs', methods=['GET', 'POST', 'OPTIONS'])
@app.route('/api/pseudos/auto_inputs/', methods=['GET', 'POST', 'OPTIONS'])
def pseudos_auto_inputs():
    if request.method == 'OPTIONS':
        return '', 204
    if request.method == 'POST':
        body     = request.get_json() or {}
        sym_raw  = str(body.get('element') or body.get('sym') or 'Si').strip()
        xc       = str(body.get('xc') or 'lda_pw')
        pp_ape   = str(body.get('pp_type_ape') or body.get('pp_type') or 'troullier')
        pp_aw    = str(body.get('pp_type_atompaw') or body.get('pp_type') or 'vanderbilt')
        relat    = bool(body.get('relativistic') or body.get('scalar_rel'))
        semicore = bool(body.get('semicore') or body.get('semi_core'))
        rc_scale = float(body.get('rc_scale') or 1.0)
        l_local  = body.get('l_local')
        l_local  = int(l_local) if l_local is not None else None
        f_treatment = str(body.get('f_treatment') or body.get('f_4f') or '').strip() or None
    else:
        sym_raw  = (request.args.get('element') or request.args.get('sym') or 'Si').strip()
        xc       = (request.args.get('xc') or 'lda_pw').strip()
        pp_ape   = (request.args.get('pp_type_ape') or request.args.get('pp_type') or 'troullier').strip()
        pp_aw    = (request.args.get('pp_type_atompaw') or request.args.get('pp_type') or 'vanderbilt').strip()
        relat    = request.args.get('relativistic', '').lower() in ('1', 'true', 'yes')
        semicore = request.args.get('semicore', '').lower() in ('1', 'true', 'yes')
        rc_scale = float(request.args.get('rc_scale') or 1.0)
        l_local_r = request.args.get('l_local')
        l_local  = int(l_local_r) if l_local_r is not None else None
        f_treatment = (request.args.get('f_treatment') or request.args.get('f_4f') or '').strip() or None

    mod = _load_pseudo_auto_inputs_sa()
    if mod is None:
        return jsonify({'error': 'pseudo_auto_inputs.py introuvable à côté du serveur.'}), 503
    try:
        sym = mod.normalize_symbol(sym_raw)
        Z   = mod.atomic_number(sym)
        oncv_dat = ''
        ld1_in = ''
        lanth_guide = {}
        lnc = None
        try:
            import lanthanide_nc as lnc
            if lnc.is_lanthanide(sym) and not relat:
                relat = True
        except ImportError:
            pass
        ape = mod.generate_ape_input(sym, xc=xc, pp_type=pp_ape,
                                     relativistic=relat, semicore=semicore,
                                     rc_scale=rc_scale, l_local=l_local,
                                     f_treatment=f_treatment)
        aw  = mod.generate_atompaw_input(sym, xc=xc, pp_type=pp_aw,
                                         relativistic=relat, semicore=semicore,
                                         rc_scale=rc_scale, f_treatment=f_treatment)
        aw_qe = ''
        if hasattr(mod, 'generate_atompaw_input_qe_file'):
            aw_qe = mod.generate_atompaw_input_qe_file(
                sym, xc=xc, pp_type=pp_aw, relativistic=relat,
                semicore=semicore, rc_scale=rc_scale, f_treatment=f_treatment,
            )
        if hasattr(mod, 'generate_ld1_input'):
            dft_map = {
                'lda_pw': 'SLA PZ', 'lda_pz': 'PZ',
                'gga_pbe': 'PBE', 'gga_pbesol': 'PBESOL', 'pbe': 'PBE',
            }
            dft_ld1 = dft_map.get(xc.lower(), 'PBE')
            ld1_in = mod.generate_ld1_input(
                sym, dft=dft_ld1, semicore=semicore, f_treatment=f_treatment,
            )
        if lnc and lnc.is_lanthanide(sym):
            try:
                oncv_dat = lnc.generate_oncv_dat(sym, f_treatment=f_treatment, xc=xc, psfile='both')
                lanth_guide = lnc.get_guide(sym, f_treatment)
            except Exception:
                pass
    except Exception as e:
        return jsonify({'error': str(e)}), 400

    metadata = {}
    try:
        import importlib.util as _iu, os as _os
        _db_path = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'elements_physics_db.py')
        if _os.path.isfile(_db_path):
            _spec = _iu.spec_from_file_location('elements_physics_db', _db_path)
            _db   = _iu.module_from_spec(_spec)
            _spec.loader.exec_module(_db)
            metadata = _db.element_metadata(sym)
    except Exception:
        pass

    breakdown = {}
    try:
        if hasattr(mod, 'inputs_breakdown'):
            breakdown = mod.inputs_breakdown(
                sym, xc, pp_ape, pp_aw, relat, semicore, rc_scale, l_local, f_treatment,
            )
    except Exception:
        pass

    return jsonify({
        'element': sym, 'Z': Z,
        'ape_input': ape, 'atompaw_input': aw, 'atompaw_input_qe': aw_qe,
        'ld1_input': ld1_in,
        'oncv_input_dat': oncv_dat,
        'lanthanide_nc_guide': lanth_guide,
        'params': {'xc': xc, 'pp_type_ape': pp_ape, 'pp_type_atompaw': pp_aw,
                   'relativistic': relat, 'semicore': semicore,
                   'rc_scale': rc_scale, 'l_local': l_local, 'f_treatment': f_treatment},
        'metadata': metadata,
        'input_breakdown': breakdown,
        'qe_route': breakdown.get('qe_route') if breakdown else {},
        'note': (
            breakdown.get('qe_route', {}).get('message')
            if breakdown.get('qe_route')
            else (
                'Lanthanide : préférer ONCVPSP ou PseudoDojo (NC). Boucle r_c(4f) 1.8–2.3 bohr si ghost.'
                if lanth_guide
                else 'Aufbau anormal (Cu, Cr, …) : vérifiez la configuration de valence.'
            )
        ),
    })


@app.route('/api/pseudos/ape_input_template', methods=['GET'])
@app.route('/api/pseudos/ape_input_template/', methods=['GET'])
def pseudos_ape_input_template():
    preset = (request.args.get('preset') or 'li_ae').strip().lower()
    mapping = {'li_ae': 'inp.ape.Li_ae', 'li_pp': 'inp.ape.Li_pp'}
    fname = mapping.get(preset, mapping['li_ae'])
    fp = _pseudo_template_file_sa(fname)
    if fp is not None:
        return Response(fp.read_text(encoding='utf-8', errors='replace'), mimetype='text/plain; charset=utf-8')
    return jsonify({
        'error': (
            f'Modèle absent : {fname}. '
            f'Attendu sous {_pseudo_templates_dir_sa()} ou pseudo_generator_templates/ à côté du serveur.'
        ),
    }), 404


@app.route('/api/pseudos/atompaw_input_template', methods=['GET'])
@app.route('/api/pseudos/atompaw_input_template/', methods=['GET'])
def pseudos_atompaw_input_template():
    fp = _pseudo_template_file_sa('atompaw.in.example')
    if fp is not None:
        return Response(fp.read_text(encoding='utf-8', errors='replace'), mimetype='text/plain; charset=utf-8')
    return jsonify({
        'error': (
            'Modèle absent : atompaw.in.example. '
            f'Attendu sous {_pseudo_templates_dir_sa()} ou pseudo_generator_templates/ à côté du serveur.'
        ),
    }), 404


_JSON_SAVE_METHODS_SA = ('POST', 'PUT', 'PATCH', 'OPTIONS')


def _pseudo_save_local_input_dispatch_sa():
    """Écrit l’entrée dans pseudo_generator_templates/{ape,atompaw}/ — partagé POST …/save_local_input et …/save_pseudo_generator."""
    if request.method == 'OPTIONS':
        return '', 204
    data = request.get_json() or {}
    gen = str(data.get('generator') or data.get('kind') or '').strip().lower()
    if gen not in ('ape', 'atompaw'):
        return jsonify({'success': False, 'error': 'generator doit être ape ou atompaw.'}), 400
    content = data.get('content')
    if not isinstance(content, str):
        return jsonify({'success': False, 'error': 'content (chaîne) requis.'}), 400
    blob = content.encode('utf-8')
    if len(blob) > _MAX_LOCAL_INPUT_SAVE_BYTES_SA:
        return jsonify({'success': False, 'error': 'Contenu trop volumineux (max 2 Mo).'}), 400
    element = re.sub(r'[^A-Za-z0-9._-]+', '', str(data.get('element') or 'X')).strip()[:16] or 'X'
    xc = re.sub(r'[^a-zA-Z0-9._-]+', '_', str(data.get('xc') or 'xc').strip())[:32] or 'xc'
    pp = re.sub(
        r'[^a-zA-Z0-9._-]+',
        '_',
        str(data.get('pp_type') or data.get('pp_type_ape') or data.get('pp_type_atompaw') or 'pp').strip(),
    )[:32] or 'pp'

    try:
        dest_dir, dir_warn = _pseudo_local_inputs_dir_sa(gen)
    except OSError as e:
        return jsonify({"success": False, "error": str(e)}), 503
    fname_override = data.get('filename')
    if isinstance(fname_override, str) and fname_override.strip():
        base = Path(fname_override.strip()).name
        if not re.fullmatch(r'[A-Za-z0-9._-]+', base):
            return jsonify({'success': False, 'error': 'filename invalide.'}), 400
        out = dest_dir / base
    else:
        ts = datetime.now().strftime('%Y%m%d-%H%M%S')
        base = f'{element}_{xc}_{pp}_ape_{ts}.inp.ape' if gen == 'ape' else f'{element}_{xc}_{pp}_atompaw_{ts}.atompaw.in'
        out = dest_dir / base

    try:
        out.resolve().relative_to(dest_dir.resolve())
    except ValueError:
        return jsonify({'success': False, 'error': 'Chemin invalide.'}), 400
    try:
        out.write_text(content, encoding='utf-8')
    except OSError as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    out_payload = {
        'success': True,
        'filename': out.name,
        'path': str(out.resolve()),
        'directory': str(dest_dir.resolve()),
        'generator': gen,
    }
    if dir_warn:
        out_payload['warning'] = dir_warn
    return jsonify(out_payload)


@app.route('/api/pseudos/save_local_input', methods=['POST', 'OPTIONS'])
@app.route('/api/pseudos/save_local_input/', methods=['POST', 'OPTIONS'])
def pseudos_save_local_input():
    """Écrit l’entrée éditée dans pseudo_generator_templates/{ape,atompaw}/ (logique type ld1_inputs/)."""
    return _pseudo_save_local_input_dispatch_sa()


@app.route('/api/inputs/save_pseudo_generator', methods=list(_JSON_SAVE_METHODS_SA))
@app.route('/api/inputs/save_pseudo_generator/', methods=list(_JSON_SAVE_METHODS_SA))
def inputs_save_pseudo_generator_sa():
    """Même corps JSON que …/api/pseudos/save_local_input (chemins /api/inputs/* souvent mieux acceptés)."""
    return _pseudo_save_local_input_dispatch_sa()


def _upf_conversion_advice_sa(
    generator: str,
    qe_val: dict | None,
    *,
    upf_found: bool = False,
    fatal: list[str] | None = None,
) -> str | None:
    """Conseils si l'UPF n'est pas prêt pour pw.x."""
    qe_val = qe_val or {}
    if qe_val.get('conform_qe'):
        return None
    gen = (generator or '').strip().lower()
    parts: list[str] = []
    if upf_found and not qe_val.get('conform_qe'):
        parts.append(
            'Fichier .UPF présent mais rejeté par la validation QE — vérifiez element/ format XML '
            '(Begin PSP_UPF, <UPF version=…> ou PP_HEADER APE).'
        )
    if fatal:
        if any('malloc' in f or 'SIGABRT' in f or 'multiroot' in f for f in fatal):
            parts.append(
                'Métaux 3d / lanthanides : APE instable — préférez ATOMPAW (PAW), ONCVPSP (psfile=both) '
                'ou un UPF PseudoDojo / PSLibrary déjà validé.'
            )
    if gen == 'ape':
        parts.append(
            'APE → QE : PPOutputFileFormat = upf (déjà dans l\'entrée auto). '
            'CalculationMode = ae + pp en une passe ; si seul ae a tourné, cochez « Réutiliser ce dossier » et relancez.'
        )
    elif gen == 'oncvpsp':
        parts.append(
            'ONCV → QE : psfile=both ou upf dans le .dat ; l\'UPF XML est dans stdout ou *.UPF — '
            'relancez avec cible Quantum ESPRESSO.'
        )
    elif gen == 'atompaw':
        parts.append(
            'ATOMPAW → QE : sortie Create_PSP / format UPF ; vérifiez rc(Vloc) et la queue PWSCFOUT + END.'
        )
    elif gen == 'ld1.x':
        parts.append(
            'ld1.x produit directement un UPF QE si le calcul converge ; pour 3d en NC, passez en US/PAW ou importez PseudoDojo.'
        )
    if not upf_found:
        parts.append(
            'Aucun .UPF dans le dossier de travail — lisez le log (erreurs fatal ci-dessus).'
        )
    if qe_val.get('advice') and qe_val['advice'] not in parts:
        parts.append(qe_val['advice'])
    return ' '.join(parts) if parts else None


def _ape_force_pp_mode(content: str) -> str:
    """Remplace CalculationMode par « pp » (2ᵉ étape APE après AE)."""
    text = content or ''
    if re.search(r'(?im)^\s*CalculationMode\s*=', text):
        return re.sub(
            r'(?im)^\s*CalculationMode\s*=\s*.*$',
            'CalculationMode = pp',
            text,
            count=1,
        )
    # Insérer après Title si présent
    if re.search(r'(?im)^\s*Title\s*=', text):
        return re.sub(
            r'(?im)^(\s*Title\s*=\s*.*)$',
            r'\1\nCalculationMode = pp',
            text,
            count=1,
        )
    return 'CalculationMode = pp\n' + text


def _ape_workdir_has_ae(work_dir: Path) -> bool:
    ae = work_dir / 'ae'
    if not ae.is_dir():
        return False
    try:
        return any(ae.iterdir())
    except OSError:
        return False


def _ape_hint_for_result(ape_stage: dict | str | None, fatal: list, element: str) -> str:
    stage = ape_stage if isinstance(ape_stage, str) else (ape_stage or {}).get('stage') if isinstance(ape_stage, dict) else None
    fat = ' '.join(fatal or []).lower()
    if 'multiroot' in fat or 'exceeded max' in fat or 'gsl' in fat or 'malloc' in fat:
        return (
            f'APE PP non convergent pour {element}. '
            'Préférez ATOMPAW (PAW), ONCVPSP (psfile=both) ou PseudoDojo / PSLibrary.'
        )
    if stage == 'ae_only':
        return 'APE : AE terminé — renvoyez continue_dir = work_dir (CalculationMode = pp auto).'
    return ''


def _ape_status_from_log(log: str, upf_files: list) -> dict:
    """Découpe ae / pp et signale si un UPF a été écrit."""
    import re as _re
    log = log or ''
    ae_done = bool(_re.search(r'all[\s-]*electron|CalculationMode.*ae|ae\s+calculation', log, _re.I))
    pp_done = bool(_re.search(r'pseudopotential|pp\s+calculation|Writing.*UPF|PPOutput', log, _re.I))
    upf_written = bool(upf_files) or bool(_re.search(r'\.UPF|UPF file', log, _re.I))
    stage = 'unknown'
    if upf_written and upf_files:
        stage = 'pp_upf'
    elif pp_done and not upf_files:
        stage = 'pp_no_file'
    elif ae_done and not pp_done:
        stage = 'ae_only'
    elif ae_done and pp_done:
        stage = 'ae_pp'
    return {
        'ae_likely_done': ae_done,
        'pp_likely_done': pp_done,
        'upf_written': upf_written,
        'stage': stage,
    }


def _sa_log_fatal_errors(combined: str) -> list[str]:
    """Erreurs ATOMPAW/APE/ONCV dans le log même si le code retour est 0."""
    import re as _re
    found: list[str] = []
    patterns = (
        (r'input_dataset:\s*error', 'Erreur entrée ATOMPAW (input_dataset).'),
        (r'rc\(Vloc\)\s+is\s+missing', 'Rayons de coupure ATOMPAW incomplets (rc Vloc).'),
        (r'rc\(core\)\s+is\s+missing', 'Rayons de coupure ATOMPAW incomplets (rc core).'),
        (r'malloc\(\):\s+invalid\s+size', 'Crash mémoire APE (souvent métaux 3d — essayez ld1 ou PSLibrary).'),
        (r'SIGABRT|signal\s+6|Aborted', 'Processus interrompu (SIGABRT).'),
        (r'STOP\s+', 'Arrêt Fortran (STOP dans le générateur).'),
        (r'Bad integer for item.*list input', 'Entrée ATOMPAW invalide (grille ou format obsolète — régénérez l\'entrée).'),
        (r'UPF file not created', 'ATOMPAW n\'a pas écrit de UPF (cœur+nhat négatif : réduisez rc_core ou changez la valence).'),
        (r'not compatible with Dirac relativistic', 'UPF impossible en mode Dirac — désactivez la relativité scalaire.'),
        (r'Option not recognized', 'Entrée post-calcul incorrecte — mettez à jour pseudo_auto_inputs.py et relancez.'),
        (r'Read ERROR,\s*input data file line', 'Entrée ONCV invalide (format .dat — régénérez depuis lanthanide NC).'),
        (r'test_data:\s*rc\s*<\s*rc\(lloc\)', 'ONCV : rc canal < rc(local) — régénérez l\'entrée ou augmentez r_c.'),
        (r'test_data found\s+\d+\s+ERROR', 'ONCV : paramètres incohérents (rayons de coupure / valence).'),
        (r'Program will stop', 'ONCV arrêté (entrée ou optimisation).'),
        (r'optimize:\s*ERROR', 'ONCV : échec optimisation (ajustez r_c, valence ou PseudoDojo).'),
        (r'oncvpsp:\s*ERROR\s+debl', 'ONCV : paramètre debl invalide — régénérez l\'entrée lanthanide.'),
        (r'ERROR:\s*test_data found', 'ONCV : erreurs test_data — voir le log complet.'),
        (r'Errors in PS-KS equation', (
            'Échec test PS-KS (ld1.x) : fréquent pour les métaux 3d en norme-conservant. '
            'Relancez en US ou PAW, ou importez un NC PseudoDojo / PSLibrary.'
        )),
        (r'Error in routine run_pseudo', 'Échec génération pseudo (routine run_pseudo).'),
        (r'Fatal Error', 'APE arrêté (erreur fatale dans le log).'),
        (r'State:\s*\S+\s+is\s+unbound', (
            'APE : orbitale de valence non liée (état « unbound ») — '
            'augmentez r_c, vérifiez la valence (ex. Pd : 4d10+5s0) ou utilisez ATOMPAW / PseudoDojo.'
        )),
        (r'multiroot_solve_system', (
            'APE : convergence échouée (métaux 3d / lanthanides NC) — '
            'essayez ATOMPAW (PAW) ou ONCVPSP / PseudoDojo, puis validez l’UPF QE.'
        )),
        (r'exceeded max number of iterations', 'APE : itérations GSL épuisées — augmentez r_c ou changez de générateur.'),
        (r"symbol\s+'scalar_relativistic'\s+used before being defined", (
            'Entrée APE obsolète (WaveEquation) — régénérez l’entrée (scalar_rel).'
        )),
        (r'expected\s+\d+\s+nodes.*found\s+\d+', (
            'Nombre de nœuds radial incorrect — augmentez r_c (surtout 4s/3d pour Sc–Zn).'
        )),
        (r'MPI_Abort|application called MPI_Abort', 'Calcul ld1.x interrompu (MPI_Abort).'),
        (r'phi has nodes before r_c', 'Orbitale avec nœuds avant r_c — augmentez le rayon de coupure.'),
    )
    for pat, msg in patterns:
        if _re.search(pat, combined, _re.IGNORECASE) and msg not in found:
            found.append(msg)
    return found


def _ld1_diagnostics(combined: str, input_ld1: str, element: str) -> dict:
    """Diagnostic structuré pour l'UI après échec ld1.x."""
    import re as _re
    issues: list[dict] = []
    sym = re.sub(r'[^A-Za-z]+', '', str(element or ''))[:2].capitalize() or 'X'
    pt_m = _re.search(r'pseudotype\s*=\s*(\d+)', input_ld1 or '', _re.I)
    pseudotype = int(pt_m.group(1)) if pt_m else None
    z_m = _re.search(r'zed\s*=\s*([\d.]+)', input_ld1 or '', _re.I)
    z_val = float(z_m.group(1)) if z_m else None
    is_3d = z_val is not None and 21 <= z_val <= 30

    if _re.search(r'Errors in PS-KS equation', combined, _re.I):
        details = (
            f'{sym} : l’étape de construction du pseudo (test de l’équation pseudo-KS) a échoué. '
            'C’est typique des métaux de transition 3d (Sc–Zn) en NC avec ld1.x.'
        )
        suggestion = (
            'Choisir US ou PAW dans la modale ld1, relancer la génération ; '
            'pour un NC validé : onglet PseudoDojo ou ./telecharger_lanthanides_nc.sh '
            '(jeu ONCV) / PSLibrary NC.'
        )
        if is_3d and pseudotype == 1:
            suggestion = (
                f'Pour {sym} (3d) : ld1.x + NC échoue presque toujours. '
                'Passez à US ou PAW (testé OK), ou téléchargez Mn-sp.upf depuis PseudoDojo (ONCV NC).'
            )
        issues.append({
            'title': 'Échec test PS-KS',
            'details': details,
            'suggestion': suggestion,
            'lines': [],
        })

    if _re.search(r'expected\s+\d+\s+nodes', combined, _re.I):
        issues.append({
            'title': 'Nœuds radiaux inattendus',
            'details': 'Une orbitale de valence a plus de nœuds que prévu avant r_c.',
            'suggestion': 'Augmentez r_c (4s ≥ 4.2 bohr, 3d ≥ 2.85, 4p vide en 3.1) ou passez en US/PAW.',
            'lines': [],
        })

    summary = issues[0]['details'] if issues else 'Voir la sortie ld1.x ci-dessous.'
    return {'summary': summary, 'issues': issues, 'is_3d_metal': is_3d, 'pseudotype': pseudotype}


def _sa_analyse_log(stdout, stderr, upf_files, element=None):
    import re as _re
    combined = (stdout or '') + '\n' + (stderr or '')
    fatal = _sa_log_fatal_errors(combined)
    ghost = any(_re.search(p, combined, _re.IGNORECASE) for p in [
        r'ghost\s+state', r'spurious\s+state', r'ghost\s+node',
        r'repulsive\s+local', r'WARNING.*ghost', r'WARNING.*local.*component'])
    conv_ok = not any(_re.search(p, combined, _re.IGNORECASE) for p in [
        r'not\s+converged', r'convergence\s+fail', r'maximum\s+iteration'])
    upf_ok  = len(upf_files) > 0
    qe_ok = False
    qe_fmt = None
    if upf_ok:
        try:
            pick = max(upf_files, key=os.path.getmtime)
        except Exception:
            pick = upf_files[0]
        qv = _validate_upf_qe(pick, element)
        qe_ok = qv.get('conform_qe', False)
        qe_fmt = qv.get('format')
    advice  = []
    advice.extend(fatal)
    if ghost:  advice.append('Ghost state — changez l_local ou augmentez rc.')
    if not upf_ok:
        advice.append('Aucun .UPF — vérifiez le log.')
    elif not qe_ok:
        advice.append('UPF non conforme QE — conversion ou psfile=upf requis.')
    if not conv_ok: advice.append('Convergence — réduisez rc ou vérifiez la valence.')
    return {
        'upf_created': upf_ok,
        'qe_conform': qe_ok,
        'qe_format': qe_fmt,
        'ghost_state_detected': ghost,
        'convergence_ok': conv_ok and not fatal,
        'fatal_errors': fatal,
        'advice': '; '.join(advice) if advice else None,
    }


@app.route('/api/pseudos/verifier_upf_qe', methods=['GET', 'POST'])
def pseudos_verifier_upf_qe():
    """Vérifie la conformité d'un UPF au format Quantum ESPRESSO."""
    if request.method == 'POST':
        data = request.get_json() or {}
    else:
        data = request.args
    chemin = (data.get('path') or data.get('chemin') or '').strip()
    nom = (data.get('nom') or data.get('filename') or '').strip()
    element = (data.get('element') or '').strip()
    if nom and not chemin:
        for ext in ('', '.UPF', '.upf'):
            c = os.path.join(PSEUDOS, nom + ext) if ext else os.path.join(PSEUDOS, nom)
            if os.path.isfile(c):
                chemin = c
                break
        if not chemin:
            for f in lister_upf(element or None):
                if f['nom'].lower() == nom.lower() or f['nom'].lower() == (nom + '.upf').lower():
                    chemin = os.path.join(PSEUDOS, f['chemin'])
                    break
    if not chemin:
        return jsonify({'success': False, 'error': 'Chemin ou nom de fichier UPF requis.'}), 400
    qv = _validate_upf_qe(chemin, element or None)
    return jsonify({
        'success': True,
        'conform_qe': qv.get('conform_qe', False),
        'validation': qv,
        'path': os.path.abspath(chemin) if os.path.isfile(chemin) else chemin,
    })


@app.route('/api/pseudos/sauvegarder_upf', methods=['POST'])
def pseudos_sauvegarder_upf():
    """Copie un UPF existant vers le dossier du générateur et la bibliothèque PSEUDOS (si conforme QE)."""
    data = request.get_json() or {}
    chemin = (data.get('path') or data.get('upf_path') or '').strip()
    element = (data.get('element') or 'X').strip()
    generator = (data.get('generator') or data.get('source') or 'manuel').strip()
    if not chemin or not os.path.isfile(chemin):
        return jsonify({'success': False, 'error': 'Fichier UPF introuvable.'}), 400
    fin = _finalize_upf_sa(chemin, element, generator)
    ok = fin['qe_validation'].get('conform_qe', False)
    return jsonify({
        'success': ok,
        'conform_qe': ok,
        'qe_validation': fin['qe_validation'],
        'copied_to_pseudos_generes': fin.get('copied_to_pseudos_generes', []),
        'pseudos_generes_dir': fin.get('pseudos_generes_dir'),
        'saved_to_pseudos_dir': fin.get('saved_to_pseudos_dir'),
        'pseudos_dir': PSEUDOS,
        'error': None if ok else 'UPF non conforme Quantum ESPRESSO — sauvegarde refusée.',
    }), (200 if ok else 422)


@app.route('/api/pseudos/element_info', methods=['GET'])
def pseudos_element_info():
    sym_raw = (request.args.get('element') or request.args.get('sym') or 'Si').strip()
    try:
        import importlib.util as _iu, os as _os
        _db_path = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'elements_physics_db.py')
        if not _os.path.isfile(_db_path):
            return jsonify({'error': 'elements_physics_db.py absent'}), 503
        _spec = _iu.spec_from_file_location('elements_physics_db', _db_path)
        _db   = _iu.module_from_spec(_spec)
        _spec.loader.exec_module(_db)
        mod = _load_pseudo_auto_inputs_sa()
        sym = mod.normalize_symbol(sym_raw) if mod else sym_raw
        return jsonify(_db.element_metadata(sym))
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@app.route('/api/pseudos/wizard_catalog', methods=['GET'])
def pseudos_wizard_catalog():
    """Catalogue assistant guidé : type pseudo / type générateur / utilisation."""
    sym_raw = (request.args.get('element') or request.args.get('sym') or 'Si').strip()
    try:
        from wizard_pseudo_catalog import build_element_catalog
        cat = build_element_catalog(sym_raw)
        cat['success'] = True
        return jsonify(cat)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400


@app.route('/api/pseudos/rc_optimize', methods=['GET'])
def pseudos_rc_optimize():
    """Conseils d'optimisation r_c (plancher, échelle, escalade anti-erreur)."""
    sym = (request.args.get('element') or request.args.get('sym') or 'Si').strip()
    gen = (request.args.get('generator') or request.args.get('gen') or 'ape').strip()
    try:
        scale = float(request.args.get('rc_scale') or 1.0)
    except (TypeError, ValueError):
        scale = 1.0
    try:
        from rc_optimize import diagnose_rc
        out = diagnose_rc(sym, gen, scale)
        out['success'] = True
        return jsonify(out)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400


@app.route('/api/pseudos/run_ape', methods=['POST', 'OPTIONS'])
def pseudos_run_ape():
    if request.method == 'OPTIONS':
        return '', 204
    data     = request.get_json() or {}
    element  = re.sub(r'[^A-Za-z0-9._-]+', '', str(data.get('element') or 'X'))[:8] or 'X'
    auto_g   = bool(data.get('auto_generate') or data.get('auto'))
    content  = (data.get('input') or '').strip()
    xc       = str(data.get('xc') or 'lda_pw')
    pp_type  = str(data.get('pp_type_ape') or data.get('pp_type') or 'troullier')
    relat    = bool(data.get('relativistic') or data.get('scalar_rel'))
    semicore = bool(data.get('semicore'))
    rc_scale = float(data.get('rc_scale') or 1.0)
    l_local  = data.get('l_local')
    l_local  = int(l_local) if l_local is not None else None
    optimize_rc = bool(data.get('optimize_rc', True))
    rc_scale_user = rc_scale
    # 3d / 4f : rc plus large + hamann (Troullier diverge souvent sur d/f)
    ape_blocked = False
    try:
        from generator_guide import ape_feasibility
        ape_blocked = ape_feasibility(element) == 'blocked'
    except Exception:
        ape_blocked = False
    if optimize_rc and (auto_g or not content) and rc_scale_user <= 1.01:
        try:
            from rc_optimize import default_rc_scale
            rc_scale = max(rc_scale, float(default_rc_scale(element, 'ape')))
        except Exception:
            if ape_blocked:
                rc_scale = max(rc_scale, 1.5)
    if (auto_g or not content) and ape_blocked:
        if rc_scale <= 1.01:
            rc_scale = 1.5
        if (pp_type or 'troullier').lower() in ('troullier', 'tm', ''):
            pp_type = 'hamann'
        if not relat:
            relat = True
        if not semicore:
            semicore = True
    if auto_g or not content:
        mod = _load_pseudo_auto_inputs_sa()
        if mod is None:
            return jsonify({'success': False, 'error': 'pseudo_auto_inputs.py absent.'}), 503
        try:
            sym_pass = re.sub(r'[^A-Za-z]+', '', str(data.get('element') or element))
            f_treatment = str(data.get('f_treatment') or data.get('f_4f') or '').strip() or None
            content = mod.generate_ape_input(
                sym_pass or element,
                xc=xc,
                pp_type=pp_type,
                relativistic=relat,
                semicore=semicore,
                rc_scale=rc_scale,
                l_local=l_local,
                f_treatment=f_treatment,
            )
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 400
    elif len(content) > 500000:
        return jsonify({'success': False, 'error': 'Entrée APE trop volumineuse.'}), 400

    exe = _resolve_ape_bin_sa()
    if not exe:
        return jsonify({'success': False, 'error': 'ape introuvable (APE_BIN ou PATH).'}), 503

    try:
        work_root, work_warn = _pseudo_gen_work_root_sa()
        gen_bucket, gen_bucket_warn = _pseudo_gen_bucket_sa('ape')
    except OSError as e:
        return jsonify({'success': False, 'error': str(e)}), 503

    default_wd = work_root / f'ape_{element}'
    continue_dir = data.get('continue_dir') or data.get('work_dir')
    work_dir = _safe_tmp_workdir_sa(str(continue_dir) if continue_dir else None, work_root, default_wd)
    try:
        work_dir.relative_to(work_root)
    except ValueError:
        return jsonify({'success': False, 'error': 'Répertoire hors _work.'}), 400

    # Reprise : forcer CalculationMode = pp si AE déjà présent
    if continue_dir and _ape_workdir_has_ae(work_dir):
        content = _ape_force_pp_mode(content)

    inp = work_dir / 'inp.ape'
    inp.write_text(content, encoding='utf-8')
    out_log = work_dir / 'ape_run.log'
    try:
        proc = subprocess.run(
            [str(exe)],
            cwd=str(work_dir),
            capture_output=True,
            text=True,
            timeout=300,
        )
    except subprocess.TimeoutExpired:
        return jsonify({'success': False, 'error': 'Timeout 300 s (APE).'}), 500
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

    log_combined = (proc.stdout or '') + '\n' + (proc.stderr or '')
    upf_files = glob.glob(str(work_dir / '*.UPF')) + glob.glob(str(work_dir / '*.upf'))
    # Auto-chaîne ae → pp dans la même requête si AE OK mais pas d’UPF
    ape_stage_pre = _ape_status_from_log(log_combined, upf_files)
    if (
        not upf_files
        and _ape_workdir_has_ae(work_dir)
        and ape_stage_pre.get('stage') in ('ae_only', 'ae_pp', 'pp_no_file', 'unknown')
        and 'CalculationMode = pp' not in content
        and not re.search(r'(?im)^\s*CalculationMode\s*=\s*pp\b', content)
    ):
        content_pp = _ape_force_pp_mode(content)
        inp.write_text(content_pp, encoding='utf-8')
        try:
            proc2 = subprocess.run(
                [str(exe)],
                cwd=str(work_dir),
                capture_output=True,
                text=True,
                timeout=300,
            )
            log_combined = (
                log_combined
                + '\n--- auto CalculationMode=pp ---\n'
                + (proc2.stdout or '')
                + '\n'
                + (proc2.stderr or '')
            )
            proc = proc2
            upf_files = glob.glob(str(work_dir / '*.UPF')) + glob.glob(str(work_dir / '*.upf'))
        except Exception as e:
            log_combined += f'\n--- auto pp failed: {e} ---\n'

    out_log.write_text(log_combined, encoding='utf-8')
    upf_pick = None
    if upf_files:
        try:
            upf_pick = max(upf_files, key=os.path.getmtime)
        except Exception:
            upf_pick = upf_files[0]

    fatal = _sa_log_fatal_errors(log_combined)
    run_completed = proc.returncode == 0
    proc_ok = run_completed and not fatal
    if upf_pick:
        fin = _finalize_upf_sa(
            upf_pick, element, 'ape',
            work_dir=work_dir,
            input_path=inp,
            log_text=log_combined,
        )
    else:
        fin = {
            'qe_validation': {'conform_qe': False, 'errors': fatal or ['Aucun fichier .UPF produit.']},
            'copied_to_pseudos_generes': [],
            'saved_to_pseudos_dir': None,
            'warnings': [],
            'upf_path': None,
            'upf_genere': None,
        }
    validation = _sa_analyse_log(proc.stdout, proc.stderr, upf_files, element)
    validation['qe_conform'] = fin['qe_validation'].get('conform_qe', False)
    validation['qe_format'] = fin['qe_validation'].get('format')
    ape_stage = _ape_status_from_log(log_combined, upf_files)

    files_list = []
    try:
        for fn in sorted(os.listdir(work_dir)):
            fp = work_dir / fn
            if fp.is_file():
                files_list.append({'name': fn, 'path': str(fp.resolve()), 'size': fp.stat().st_size})
    except OSError:
        pass

    warnings = [w for w in (work_warn, gen_bucket_warn) if w]
    warnings.extend(fin.get('warnings') or [])
    if fatal:
        warnings.extend(fatal)
    run_ok = proc_ok
    upf_qe_ok = bool(fin['qe_validation'].get('conform_qe'))
    upf_found = bool(upf_pick)
    if upf_qe_ok:
        status = 'qe_ready'
    elif run_completed and upf_found:
        status = 'upf_non_conforme'
    elif run_completed:
        status = 'run_ok_no_upf'
    else:
        status = 'failed'
    conversion_advice = _upf_conversion_advice_sa(
        'ape', fin['qe_validation'], upf_found=upf_found, fatal=fatal,
    )
    other_codes: list[dict[str, str]] = []
    qe_status: dict = {}
    try:
        from generator_guide import classify_qe_status

        other_codes = _collect_other_codes_from_run(
            log_text=log_combined,
            qe_validation=fin['qe_validation'],
            upf_path=fin.get('upf_path') or upf_pick,
            work_dir=work_dir,
        )
        qe_status = classify_qe_status(
            "ape",
            upf_qe_ready=upf_qe_ok,
            upf_found=upf_found,
            run_completed=run_completed,
            returncode=proc.returncode,
            fatal_errors=fatal or validation.get('fatal_errors'),
            element=element,
            other_codes=other_codes,
        )
    except Exception:
        qe_status = {
            'level': 'conform_qe' if upf_qe_ok else ('cannot_generate' if fatal else 'non_conforme'),
            'label': 'Conforme QE' if upf_qe_ok else 'Non conforme QE',
            'color': 'green' if upf_qe_ok else 'yellow',
            'short': conversion_advice or '',
            'alternatives': [],
        }
    return jsonify({
        'success': upf_qe_ok,
        'upf_qe_ready': upf_qe_ok,
        'qe_status_level': qe_status.get('level', status),
        'qe_status': qe_status,
        'run_completed': run_completed,
        'run_ok': run_ok,
        'status': qe_status.get('level', status),
        'upf_found': upf_found,
        'ape_stage': ape_stage,
        'ape_feasibility': qe_status.get('feasibility'),
        'alternatives': qe_status.get('alternatives') or [],
        'conversion_advice': conversion_advice,
        'returncode': proc.returncode,
        'output': (proc.stdout or '')[-12000:],
        'stderr': (proc.stderr or '')[-4000:],
        'work_dir': str(work_dir),
        'input_file': str(inp),
        'log_file': str(out_log),
        'validation': validation,
        'qe_validation': fin['qe_validation'],
        'upf_path': fin.get('upf_path') or upf_pick,
        'upf_genere': fin.get('upf_genere') or (os.path.basename(upf_pick) if upf_pick else None),
        'copied_to_pseudos_generes': fin.get('copied_to_pseudos_generes', []),
        'pseudos_generes_dir': fin.get('pseudos_generes_dir') or str(gen_bucket),
        'saved_to_pseudos_dir': fin.get('saved_to_pseudos_dir'),
        'pseudos_dir': PSEUDOS,
        'generator': 'ape',
        'files_in_workdir': files_list,
        'warnings': warnings,
        'fatal_errors': fatal or validation.get('fatal_errors') or [],
        'other_codes': other_codes,
        'diagnostic_summary': (
            (fatal[0] if fatal else None)
            or validation.get('advice')
            or ('UPF conforme QE.' if upf_qe_ok else 'Aucun UPF conforme Quantum ESPRESSO.')
        ),
        'hint': _ape_hint_for_result(ape_stage, fatal, element),
        'rc_scale_used': rc_scale,
        'error': (
            None if upf_qe_ok else (
                (fatal[0] if fatal else None)
                or _ape_hint_for_result(ape_stage, fatal, element)
                or 'Aucun UPF conforme Quantum ESPRESSO.'
            )
        ),
    })
    # Conseil d'escalade r_c si échec typique
    try:
        from rc_optimize import diagnose_rc, error_suggests_larger_rc, next_rc_scale
        payload = _.get_json() if False else None  # noqa — placeholder unused
    except Exception:
        pass
    try:
        from rc_optimize import diagnose_rc, error_suggests_larger_rc, next_rc_scale
        diag = diagnose_rc(element, 'ape', rc_scale)
        resp = {
            'success': upf_qe_ok,
            'upf_qe_ready': upf_qe_ok,
            'qe_status_level': qe_status.get('level', status),
            'qe_status': qe_status,
            'run_completed': run_completed,
            'run_ok': run_ok,
            'status': qe_status.get('level', status),
            'upf_found': upf_found,
            'ape_stage': ape_stage,
            'ape_feasibility': qe_status.get('feasibility'),
            'alternatives': qe_status.get('alternatives') or [],
            'conversion_advice': conversion_advice,
            'returncode': proc.returncode,
            'output': (proc.stdout or '')[-12000:],
            'stderr': (proc.stderr or '')[-4000:],
            'work_dir': str(work_dir),
            'input_file': str(inp),
            'log_file': str(out_log),
            'validation': validation,
            'qe_validation': fin['qe_validation'],
            'upf_path': fin.get('upf_path') or upf_pick,
            'upf_genere': fin.get('upf_genere') or (os.path.basename(upf_pick) if upf_pick else None),
            'copied_to_pseudos_generes': fin.get('copied_to_pseudos_generes', []),
            'pseudos_generes_dir': fin.get('pseudos_generes_dir') or str(gen_bucket),
            'saved_to_pseudos_dir': fin.get('saved_to_pseudos_dir'),
            'pseudos_dir': PSEUDOS,
            'generator': 'ape',
            'files_in_workdir': files_list,
            'warnings': warnings,
            'fatal_errors': fatal or validation.get('fatal_errors') or [],
            'other_codes': other_codes,
            'diagnostic_summary': (
                (fatal[0] if fatal else None)
                or validation.get('advice')
                or ('UPF conforme QE.' if upf_qe_ok else 'Aucun UPF conforme Quantum ESPRESSO.')
            ),
            'hint': _ape_hint_for_result(ape_stage, fatal, element),
            'rc_scale_used': rc_scale,
            'rc_optimize': diag,
            'error': (
                None if upf_qe_ok else (
                    (fatal[0] if fatal else None)
                    or _ape_hint_for_result(ape_stage, fatal, element)
                    or 'Aucun UPF conforme Quantum ESPRESSO.'
                )
            ),
        }
        if not upf_qe_ok and error_suggests_larger_rc(log_combined):
            nxt = next_rc_scale(rc_scale)
            resp['rc_retry_suggested'] = nxt
            if nxt:
                tip = f'Relancez avec rc_scale={nxt} (nœuds/ghost/GSL détectés).'
                resp['hint'] = ((resp.get('hint') or '') + ' · ' + tip).strip(' ·')
                warnings.append(tip)
                resp['warnings'] = warnings
        return jsonify(resp)
    except Exception:
        return jsonify({
        'success': upf_qe_ok,
        'upf_qe_ready': upf_qe_ok,
        'qe_status_level': qe_status.get('level', status),
        'qe_status': qe_status,
        'run_completed': run_completed,
        'run_ok': run_ok,
        'status': qe_status.get('level', status),
        'upf_found': upf_found,
        'ape_stage': ape_stage,
        'ape_feasibility': qe_status.get('feasibility'),
        'alternatives': qe_status.get('alternatives') or [],
        'conversion_advice': conversion_advice,
        'returncode': proc.returncode,
        'output': (proc.stdout or '')[-12000:],
        'stderr': (proc.stderr or '')[-4000:],
        'work_dir': str(work_dir),
        'input_file': str(inp),
        'log_file': str(out_log),
        'validation': validation,
        'qe_validation': fin['qe_validation'],
        'upf_path': fin.get('upf_path') or upf_pick,
        'upf_genere': fin.get('upf_genere') or (os.path.basename(upf_pick) if upf_pick else None),
        'copied_to_pseudos_generes': fin.get('copied_to_pseudos_generes', []),
        'pseudos_generes_dir': fin.get('pseudos_generes_dir') or str(gen_bucket),
        'saved_to_pseudos_dir': fin.get('saved_to_pseudos_dir'),
        'pseudos_dir': PSEUDOS,
        'generator': 'ape',
        'files_in_workdir': files_list,
        'warnings': warnings,
        'fatal_errors': fatal or validation.get('fatal_errors') or [],
        'other_codes': other_codes,
        'diagnostic_summary': (
            (fatal[0] if fatal else None)
            or validation.get('advice')
            or ('UPF conforme QE.' if upf_qe_ok else 'Aucun UPF conforme Quantum ESPRESSO.')
        ),
        'hint': _ape_hint_for_result(ape_stage, fatal, element),
        'rc_scale_used': rc_scale,
        'error': (
            None if upf_qe_ok else (
                (fatal[0] if fatal else None)
                or _ape_hint_for_result(ape_stage, fatal, element)
                or 'Aucun UPF conforme Quantum ESPRESSO.'
            )
        ),
    })


@app.route('/api/pseudos/run_atompaw', methods=['POST', 'OPTIONS'])
def pseudos_run_atompaw():
    if request.method == 'OPTIONS':
        return '', 204
    data     = request.get_json() or {}
    element  = re.sub(r'[^A-Za-z0-9._-]+', '', str(data.get('element') or 'X'))[:8] or 'X'
    auto_g   = bool(data.get('auto_generate') or data.get('auto'))
    content  = (data.get('input') or '').strip()
    xc       = str(data.get('xc') or 'lda_pw')
    pp_type  = str(data.get('pp_type_atompaw') or data.get('pp_type') or 'vanderbilt')
    relat    = bool(data.get('relativistic') or data.get('scalar_rel'))
    semicore = bool(data.get('semicore'))
    rc_scale = float(data.get('rc_scale') or 1.0)
    fmt = str(data.get('atompaw_format') or 'interactive').strip().lower()
    use_qe = fmt in ('qe', 'qe_file', 'file', 'redirection', 'compact')
    continue_dir = data.get('continue_dir') or data.get('work_dir')
    optimize_rc = bool(data.get('optimize_rc', True))
    if optimize_rc and (auto_g or not content) and rc_scale <= 1.01:
        try:
            from rc_optimize import default_rc_scale
            rc_scale = max(rc_scale, float(default_rc_scale(element, 'atompaw')))
        except Exception:
            pass
    mod = _load_pseudo_auto_inputs_sa()
    obsolete = False
    if mod and content and hasattr(mod, 'atompaw_input_is_obsolete'):
        try:
            obsolete = bool(mod.atompaw_input_is_obsolete(content))
        except Exception:
            obsolete = False
    regen = bool(
        auto_g
        or not content
        or data.get('regenerate_input')
        or continue_dir
        or obsolete
    )
    if regen:
        if mod is None:
            return jsonify({'success': False, 'error': 'pseudo_auto_inputs.py absent.'}), 503
        try:
            sym_pass = re.sub(r'[^A-Za-z]+', '', str(data.get('element') or element))
            sym_use = sym_pass or element
            if use_qe and hasattr(mod, 'generate_atompaw_input_qe_file'):
                content = mod.generate_atompaw_input_qe_file(
                    sym_use, xc=xc, pp_type=pp_type, relativistic=relat,
                    semicore=semicore, rc_scale=rc_scale,
                )
            else:
                content = mod.generate_atompaw_input(sym_use, xc=xc, pp_type=pp_type,
                                                     relativistic=relat, semicore=semicore,
                                                     rc_scale=rc_scale)
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 400
    elif len(content) > 500000:
        return jsonify({'success': False, 'error': 'Entrée ATOMPAW trop volumineuse.'}), 400

    exe = _resolve_atompaw_bin_sa()
    if not exe:
        return jsonify({'success': False, 'error': 'ATOMPAW introuvable (ATOMPAW_BIN ou PATH).'}), 503

    try:
        work_root, work_warn = _pseudo_gen_work_root_sa()
        gen_bucket, gen_bucket_warn = _pseudo_gen_bucket_sa('atompaw')
    except OSError as e:
        return jsonify({'success': False, 'error': str(e)}), 503

    default_wd = work_root / f'atompaw_{element}'
    work_dir = _safe_tmp_workdir_sa(str(continue_dir) if continue_dir else None, work_root, default_wd)
    try:
        work_dir.relative_to(work_root)
    except ValueError:
        return jsonify({'success': False, 'error': 'Répertoire hors _work.'}), 400

    inp = work_dir / ATOMPAW_INPUT_NAME_SA
    inp.write_text(content, encoding='utf-8')
    out_log = work_dir / 'atompaw_run.log'

    try:
        with inp.open('r', encoding='utf-8') as stdin_f:
            proc = subprocess.run(
                [str(exe)],
                cwd=str(work_dir),
                stdin=stdin_f,
                capture_output=True,
                text=True,
                timeout=300,
            )
    except subprocess.TimeoutExpired:
        return jsonify({'success': False, 'error': 'Timeout 300 s (ATOMPAW).'}), 500
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

    stdout_part = proc.stdout or ''
    stderr_part = proc.stderr or ''
    log_combined = (stdout_part + ('\n' if stdout_part and stderr_part else '') + stderr_part).strip()
    out_log.write_text(
        (log_combined or '(sortie ATOMPAW vide sur stdout/stderr)\n')
        + '\n--- stderr ---\n' + (stderr_part or '(vide)'),
        encoding='utf-8',
    )
    if not log_combined and out_log.is_file():
        try:
            log_combined = out_log.read_text(encoding='utf-8', errors='replace').strip()
        except OSError:
            pass
    upf_files = _find_upf_files_in_dir(work_dir)
    upf_pick = upf_files[0] if upf_files else None
    if not upf_pick and 'UPF atomic dataset created' in log_combined:
        # UPF annoncé dans le log mais fichier non trouvé — recherche élargie
        upf_files = _find_upf_files_in_dir(work_root)
        upf_pick = upf_files[0] if upf_files else None

    fatal = _sa_log_fatal_errors(log_combined)
    proc_ok = proc.returncode == 0 and not fatal
    if upf_pick:
        fin = _finalize_upf_sa(
            upf_pick, element, 'atompaw',
            work_dir=work_dir,
            input_path=inp,
            log_text=log_combined,
        )
    else:
        fin = {
            'qe_validation': {'conform_qe': False, 'errors': fatal or ['Aucun fichier .UPF produit.']},
            'copied_to_pseudos_generes': [],
            'saved_to_pseudos_dir': None,
            'warnings': [],
            'upf_path': None,
            'upf_genere': None,
        }
    validation = _sa_analyse_log(proc.stdout, proc.stderr, upf_files, element)
    validation['qe_conform'] = fin['qe_validation'].get('conform_qe', False)
    validation['qe_format'] = fin['qe_validation'].get('format')

    files_list = []
    try:
        for fn in sorted(os.listdir(work_dir)):
            fp = work_dir / fn
            if fp.is_file():
                files_list.append({'name': fn, 'path': str(fp.resolve()), 'size': fp.stat().st_size})
    except OSError:
        pass

    warnings = [w for w in (work_warn, gen_bucket_warn) if w]
    warnings.extend(fin.get('warnings') or [])
    if fatal:
        warnings.extend(fatal)
    if regen and continue_dir:
        warnings.append(
            'Entrée régénérée automatiquement dans le dossier réutilisé (continue_dir).'
        )
    elif obsolete and not regen:
        warnings.append(
            'Entrée ATOMPAW obsolète détectée — cochez régénérer ou videz la zone pour forcer une nouvelle entrée.'
        )
    upf_qe_ok = bool(fin['qe_validation'].get('conform_qe'))
    run_ok = proc_ok
    # Succès utilisateur = calcul OK et UPF présent + conforme QE
    success = proc_ok and bool(upf_pick) and upf_qe_ok
    if proc_ok and not upf_pick:
        warnings.append(
            'Calcul ATOMPAW terminé (code 0) mais aucun fichier .UPF — '
            'vérifiez « UPF file not created » ou « Option not recognized » dans le log.'
        )
    elif proc_ok and upf_pick and not upf_qe_ok:
        warnings.append('UPF produit mais non conforme Quantum ESPRESSO — voir qe_validation.')
    if upf_qe_ok:
        hint = (
            'UPF PWSCF produit par ATOMPAW (option PWSCFOUT) — prêt pour '
            '<code>pseudo_dir</code>, aucune conversion paw_generate nécessaire.'
        )
    elif proc_ok and not upf_pick:
        hint = (
            'Pas de .UPF : vérifiez PWSCFOUT + END dans l’entrée, les rayons rc(Vloc), '
            'et le message « UPF file not created » dans le log.'
        )
    else:
        hint = 'Consultez le log ATOMPAW ci-dessous (stdout + stderr enregistrés dans atompaw_run.log).'
    other_codes: list[dict[str, str]] = []
    qe_status: dict = {}
    try:
        from generator_guide import classify_qe_status

        other_codes = _collect_other_codes_from_run(
            log_text=log_combined,
            qe_validation=fin['qe_validation'],
            upf_path=fin.get('upf_path') or upf_pick,
            work_dir=work_dir,
        )
        qe_status = classify_qe_status(
            "atompaw",
            upf_qe_ready=upf_qe_ok,
            upf_found=bool(upf_pick),
            run_completed=run_ok,
            returncode=proc.returncode,
            fatal_errors=fatal or validation.get("fatal_errors"),
            element=element,
            other_codes=other_codes,
        )
    except Exception:
        qe_status = {"level": "conform_qe" if upf_qe_ok else "non_conforme", "alternatives": []}
    return jsonify({
        'success': success,
        'qe_status_level': qe_status.get("level"),
        'qe_status': qe_status,
        'fatal_errors': fatal or validation.get("fatal_errors") or [],
        'other_codes': other_codes,
        'alternatives': qe_status.get("alternatives") or [],
        'run_completed': run_ok,
        'upf_qe_ready': upf_qe_ok,
        'upf_found': bool(upf_pick),
        'returncode': proc.returncode,
        'input_regenerated': bool(regen),
        'output': log_combined[-12000:],
        'stderr': stderr_part[-4000:],
        'work_dir': str(work_dir),
        'input_file': str(inp),
        'log_file': str(out_log),
        'validation': validation,
        'qe_validation': fin['qe_validation'],
        'upf_path': fin.get('upf_path') or upf_pick,
        'upf_genere': fin.get('upf_genere') or (os.path.basename(upf_pick) if upf_pick else None),
        'copied_to_pseudos_generes': fin.get('copied_to_pseudos_generes', []),
        'pseudos_generes_dir': fin.get('pseudos_generes_dir') or str(gen_bucket),
        'saved_to_pseudos_dir': fin.get('saved_to_pseudos_dir'),
        'pseudos_dir': PSEUDOS,
        'generator': 'atompaw',
        'files_in_workdir': files_list,
        'warnings': warnings,
        'hint': hint,
    })


def _path_under_allowed_roots(raw: str) -> Path | None:
    """Résout un chemin uniquement s'il est sous le projet ou la biblio PSEUDOS."""
    if not raw or not isinstance(raw, str):
        return None
    try:
        p = Path(raw).expanduser().resolve()
    except OSError:
        return None
    roots = [
        _STANDALONE_ROOT.resolve(),
        Path(PSEUDOS).resolve(),
        _gen_user_state_root(),
        _gen_tmp_state_root(),
    ]
    for root in roots:
        try:
            p.relative_to(root)
            return p
        except ValueError:
            continue
    return None


def _list_element_upf_in_subdir(subdir: str, element: str, limit: int = 40) -> list[str]:
    """Liste les UPF d'un sous-dossier de PSEUDOS dont le nom commence par l'élément."""
    sub = (subdir or '').strip().lstrip('/')
    if not sub or '..' in sub.split('/'):
        return []
    base = Path(PSEUDOS).resolve() / sub
    if not base.is_dir():
        return []
    el = (element or '').strip()
    if not el or not re.match(r'^[A-Za-z]{1,3}$', el):
        return []
    pat = re.compile(rf'^{re.escape(el)}[_.]', re.IGNORECASE)
    names: list[str] = []
    try:
        for fp in sorted(base.iterdir()):
            if not fp.is_file():
                continue
            if not fp.name.lower().endswith('.upf'):
                continue
            if pat.match(fp.name):
                names.append(fp.name)
            if len(names) >= limit:
                break
    except OSError:
        return []
    return names


@app.route('/api/pseudos/list_in_dir', methods=['GET'])
def pseudos_list_in_dir():
    """Remplace l’ancien `ls | grep` — liste UPF par élément dans un sous-dossier de PSEUDOS."""
    subdir = (request.args.get('subdir') or request.args.get('dir') or '').strip()
    element = (request.args.get('element') or request.args.get('sym') or '').strip()
    try:
        limit = int(request.args.get('limit') or 40)
    except (TypeError, ValueError):
        limit = 40
    files = _list_element_upf_in_subdir(subdir, element, limit=max(1, min(limit, 200)))
    # `stdout` conservé pour compatibilité éventuelle avec d’anciens clients
    return jsonify({
        'success': True,
        'subdir': subdir,
        'element': element,
        'files': files,
        'stdout': '\n'.join(files),
        'pseudos_root': PSEUDOS,
        'path': str(Path(PSEUDOS) / subdir) if subdir else PSEUDOS,
    })


@app.route('/api/pseudos/preview_file', methods=['GET'])
def pseudos_preview_file():
    """Aperçu texte sécurisé (remplace `head -N`)."""
    raw = (request.args.get('path') or request.args.get('chemin') or '').strip()
    try:
        nlines = int(request.args.get('lines') or 60)
    except (TypeError, ValueError):
        nlines = 60
    nlines = max(1, min(nlines, 400))
    p = _path_under_allowed_roots(raw)
    if not p or not p.is_file():
        # Essai relatif à PSEUDOS
        if raw and not os.path.isabs(raw):
            cand = Path(PSEUDOS).resolve() / raw
            if cand.is_file():
                p = cand
    if not p or not p.is_file():
        return jsonify({'success': False, 'error': 'Fichier introuvable ou hors zone autorisée.', 'stdout': ''}), 404
    if p.suffix.lower() not in ('.upf', '.in', '.out', '.log', '.dat', '.txt', '.ape', '') and \
            not p.name.endswith(('.UPF', '.ld1.in', '.ld1.out')):
        # Autoriser encore les UPF sans suffixe rare
        if '.upf' not in p.name.lower() and '.in' not in p.name.lower():
            return jsonify({'success': False, 'error': 'Type de fichier non autorisé en aperçu.', 'stdout': ''}), 400
    try:
        text = p.read_text(encoding='utf-8', errors='replace')
    except OSError as e:
        return jsonify({'success': False, 'error': str(e), 'stdout': ''}), 500
    lines = text.splitlines()
    head = '\n'.join(lines[:nlines])
    return jsonify({
        'success': True,
        'path': str(p),
        'name': p.name,
        'lines': min(nlines, len(lines)),
        'total_lines': len(lines),
        'stdout': head,
        'output': head,
    })


@app.route('/api/pseudos/archive_generated_upf', methods=['POST'])
def pseudos_archive_generated_upf():
    """Archive un UPF généré (ld1 ou autre) vers le bucket générateur — sans shell mv."""
    data = request.get_json() or {}
    element = re.sub(r'[^A-Za-z]', '', str(data.get('element') or ''))[:3]
    if not element:
        return jsonify({'success': False, 'error': 'Paramètre element requis.'}), 400
    generator = (data.get('generator') or 'ld1').strip().lower() or 'ld1'
    explicit = (data.get('path') or data.get('upf_path') or '').strip()

    candidates: list[Path] = []
    if explicit:
        ep = _path_under_allowed_roots(explicit)
        if ep and ep.is_file():
            candidates.append(ep)

    # Ne pas rglober tout PSEUDOS/ (peut être très volumineux) — zones de génération seulement
    search_roots: list[tuple[Path, bool]] = [
        (_STANDALONE_ROOT / 'pseudos-ld1', True),
        (_STANDALONE_ROOT / '_work', True),
        (_STANDALONE_ROOT / 'pseudos_generes', False),
        (_STANDALONE_ROOT, False),  # racine projet uniquement (pas récursif)
    ]
    for key in ('search_dir', 'ld1_inputs_dir', 'pseudo_generes_dir'):
        raw = (data.get(key) or '').strip()
        if not raw:
            continue
        sp = _path_under_allowed_roots(raw)
        if sp and sp.is_dir():
            search_roots.insert(0, (sp, True))

    pat = re.compile(rf'^{re.escape(element)}', re.I)

    def _collect(root: Path, recursive: bool) -> None:
        if not root.is_dir():
            return
        try:
            it = root.rglob('*') if recursive else root.iterdir()
            for fp in it:
                if not fp.is_file():
                    continue
                if not fp.name.lower().endswith('.upf'):
                    continue
                if pat.match(fp.name) or pat.match(fp.stem):
                    candidates.append(fp.resolve())
        except OSError:
            return

    for root, recursive in search_roots:
        _collect(root, recursive)

    # Dédupliquer, plus récent d’abord
    seen: set[str] = set()
    uniq: list[Path] = []
    for c in candidates:
        k = str(c)
        if k in seen:
            continue
        seen.add(k)
        if c.is_file():
            uniq.append(c)
    uniq.sort(key=lambda p: p.stat().st_mtime, reverse=True)

    if not uniq:
        return jsonify({
            'success': False,
            'error': f'Aucun fichier .UPF trouvé pour {element}.',
            'hint': 'Générez d’abord le pseudo (ld1.x / APE / …) puis réessayez.',
        }), 404

    chosen = uniq[0]
    fin = _finalize_upf_sa(chosen, element, generator)
    ok = bool(fin.get('qe_validation', {}).get('conform_qe')) or bool(fin.get('copied_to_pseudos_generes'))
    return jsonify({
        'success': ok or bool(fin.get('copied_to_pseudos_generes')),
        'source_path': str(chosen),
        'stdout': 'OK\n' + str(chosen),
        'qe_validation': fin.get('qe_validation'),
        'copied_to_pseudos_generes': fin.get('copied_to_pseudos_generes', []),
        'pseudos_generes_dir': fin.get('pseudos_generes_dir'),
        'saved_to_pseudos_dir': fin.get('saved_to_pseudos_dir'),
        'pseudos_bucket': fin.get('pseudos_bucket'),
    })


@app.route('/api/executer_commande', methods=['POST'])
def executer_commande():
    """Ancien endpoint shell — désactivé (jamais de subprocess shell)."""
    return jsonify({
        'success': False,
        'disabled': True,
        'error': (
            'Endpoint shell désactivé. '
            'Utilisez /api/pseudos/list_in_dir, /api/pseudos/preview_file '
            'ou /api/pseudos/archive_generated_upf.'
        ),
        'stdout': '',
    }), 410


# ─── NOUVEAUX ENDPOINTS : Historique, Batch ──────────────────────────────────────────


@app.route('/api/pseudos/history', methods=['GET'])
def pseudos_history():
    """Historique des générations depuis tous les dossiers _runs/."""
    limit = request.args.get('limit', '50')
    element_filter = (request.args.get('element') or '').strip()
    generator_filter = (request.args.get('generator') or '').strip().lower()
    try:
        limit = int(limit)
    except (ValueError, TypeError):
        limit = 50
    entries = []
    seen_dirs = set()
    scan_dirs: list[str] = []
    try:
        from generator_guide import GENERATOR_OUTPUT_DIRS
        scan_dirs = list(GENERATOR_OUTPUT_DIRS) + ['pseudos-telecharges']
    except ImportError:
        scan_dirs = [
            'pseudos-ld1', 'pseudos-APE', 'pseudos-atompaw',
            'pseudos-oncvpsp', 'pseudos-telecharges',
        ]
    for pattern in scan_dirs:
        bucket = _STANDALONE_ROOT / pattern / '_runs'
        if not bucket.is_dir():
            continue
        try:
            for run_dir in sorted(bucket.iterdir(), reverse=True):
                if not run_dir.is_dir():
                    continue
                run_path = str(run_dir.resolve())
                if run_path in seen_dirs:
                    continue
                seen_dirs.add(run_path)
                meta_file = run_dir / 'meta.json'
                meta = {}
                if meta_file.is_file():
                    try:
                        meta = json.loads(meta_file.read_text(encoding='utf-8', errors='replace'))
                    except (json.JSONDecodeError, OSError):
                        pass
                el = meta.get('element', '')
                gen = meta.get('generator', pattern).lower()
                ts = meta.get('time', run_dir.name.split('_')[-1] if '_' in run_dir.name else '')
                if element_filter and element_filter.lower() not in el.lower():
                    continue
                if generator_filter and generator_filter not in gen:
                    continue
                upf_files = list(run_dir.glob('*.UPF')) + list(run_dir.glob('*.upf'))
                log_files = list(run_dir.glob('*.log')) + list(run_dir.glob('*.out'))
                status = 'upf' if upf_files else ('log_only' if log_files else 'empty')
                entries.append({
                    'element': el or run_dir.name.split('_')[0],
                    'generator': gen,
                    'timestamp': ts,
                    'time': ts,
                    'run_dir': run_path,
                    'run_name': run_dir.name,
                    'status': status,
                    'meta': meta,
                    'upf_files': [f.name for f in upf_files],
                    'log_files': [f.name for f in log_files],
                })
        except OSError:
            pass
    entries.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
    total = len(entries)
    entries = entries[:limit]
    return jsonify({
        'success': True,
        'history': entries,
        'total': total,
        'returned': len(entries),
        'limit': limit,
    })


def _safe_run_dir(run_dir: str) -> Path | None:
    """Valide qu'un run_dir est sous un dossier *_runs* du projet."""
    try:
        p = Path(run_dir).expanduser().resolve()
    except OSError:
        return None
    if not p.is_dir():
        return None
    root = _STANDALONE_ROOT.resolve()
    try:
        p.relative_to(root)
    except ValueError:
        # autoriser aussi ~/.gen_pseudos
        try:
            p.relative_to(_gen_user_state_root())
        except ValueError:
            return None
    if '_runs' not in p.parts:
        return None
    return p


def _upf_summary_fields(path: Path) -> dict:
    qv = _validate_upf_qe(path)
    raw = ''
    try:
        raw = path.read_text(encoding='utf-8', errors='replace')[:80000]
    except OSError:
        pass
    zval = None
    m = re.search(r'z_valence\s*=\s*["\']?([0-9.eE+-]+)', raw, re.I)
    if m:
        try:
            zval = float(m.group(1))
        except ValueError:
            zval = m.group(1)
    if zval is None:
        m2 = re.search(r'Z\s*valence\s*[:=]\s*([0-9.]+)', raw, re.I)
        if m2:
            try:
                zval = float(m2.group(1))
            except ValueError:
                zval = m2.group(1)
    ptype = None
    for pat, lab in (
        (r'is_paw\s*=\s*["\']?T', 'PAW'),
        (r'is_ultrasoft\s*=\s*["\']?T', 'US'),
        (r'pseudo_type\s*=\s*["\']([^"\']+)', None),
    ):
        mm = re.search(pat, raw, re.I)
        if mm:
            ptype = lab or mm.group(1)
            break
    dft = None
    md = re.search(r'functional\s*=\s*["\']([^"\']+)', raw, re.I)
    if md:
        dft = md.group(1)
    return {
        'path': str(path),
        'name': path.name,
        'size_bytes': path.stat().st_size if path.is_file() else 0,
        'conform_qe': qv.get('conform_qe', False),
        'format': qv.get('format'),
        'element': qv.get('element_in_file'),
        'z_valence': zval,
        'pseudo_type': ptype,
        'functional': dft,
        'errors': qv.get('errors') or [],
    }


@app.route('/api/pseudos/export_run', methods=['GET'])
def pseudos_export_run():
    """Archive un dossier de run (input + log + UPF + meta) en .zip."""
    run_dir = (request.args.get('run_dir') or request.args.get('path') or '').strip()
    p = _safe_run_dir(run_dir)
    if not p:
        return jsonify({'success': False, 'error': 'run_dir invalide ou hors projet.'}), 400
    import io
    import zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(p.rglob('*')):
            if f.is_file():
                zf.write(f, arcname=str(Path(p.name) / f.relative_to(p)))
    buf.seek(0)
    from flask import send_file
    return send_file(
        buf,
        mimetype='application/zip',
        as_attachment=True,
        download_name=f'{p.name}.zip',
    )


@app.route('/api/pseudos/compare_upf', methods=['POST'])
def pseudos_compare_upf():
    """Compare deux UPF (chemins absolus sous le projet ou bibliothèque)."""
    data = request.get_json() or {}
    p1 = (data.get('path_a') or data.get('path1') or '').strip()
    p2 = (data.get('path_b') or data.get('path2') or '').strip()
    if not p1 or not p2:
        return jsonify({'success': False, 'error': 'path_a et path_b requis.'}), 400

    def _resolve_upf(raw: str) -> Path | None:
        cand = Path(raw).expanduser()
        if cand.is_file():
            return cand.resolve()
        for base in (Path(PSEUDOS), _STANDALONE_ROOT):
            t = (base / raw).resolve()
            if t.is_file():
                return t
        return None

    a = _resolve_upf(p1)
    b = _resolve_upf(p2)
    if not a or not b:
        return jsonify({'success': False, 'error': 'Un ou les deux UPF introuvables.'}), 404
    sa, sb = _upf_summary_fields(a), _upf_summary_fields(b)
    diffs = []
    for key in ('element', 'format', 'z_valence', 'pseudo_type', 'functional', 'conform_qe', 'size_bytes'):
        if sa.get(key) != sb.get(key):
            diffs.append({'field': key, 'a': sa.get(key), 'b': sb.get(key)})
    return jsonify({
        'success': True,
        'a': sa,
        'b': sb,
        'identical_meta': len(diffs) == 0,
        'diffs': diffs,
    })


@app.route('/api/pseudos/batch_generate', methods=['POST', 'OPTIONS'])
def pseudos_batch_generate():
    """Génération batch : lance plusieurs éléments en séquence."""
    if request.method == 'OPTIONS':
        return '', 204
    data = request.get_json() or {}
    elements = data.get('elements', [])
    if isinstance(elements, str):
        elements = [e.strip() for e in elements.replace(',', ' ').split() if e.strip()]
    if not elements or not isinstance(elements, list):
        return jsonify({'success': False, 'error': "Liste d'elements requise (elements: [...])"}), 400
    generator = (data.get('generator') or 'oncvpsp').strip().lower()
    config = data.get('config', {})
    results = []
    errors = []
    for sym in elements[:20]:
        sym = sym.strip().capitalize()
        if not sym or len(sym) > 2:
            continue
        try:
            if generator == 'oncvpsp':
                mod = _load_pseudo_auto_inputs_sa()
                z = mod.atomic_number(sym) if mod else 14
                raw, source = _find_oncv_dat_for_element(sym, z, config.get('f_treatment'))
                if not raw:
                    errors.append({'element': sym, 'error': 'Pas de modele ONCV'})
                    continue
                content, warns, _ = _normalize_oncv_dat_for_target(raw, config.get('target_code', 'qe'))
                exe = _resolve_oncvpsp_bin()
                if not exe:
                    errors.append({'element': sym, 'error': 'ONCVPSP binaire introuvable'})
                    continue
                bucket, _ = _pseudo_gen_bucket_sa('oncvpsp')
                tmp_dir = bucket / '_work' / f'oncv_{sym}'
                tmp_dir.mkdir(parents=True, exist_ok=True)
                infile = tmp_dir / f'oncv_{sym}.dat'
                outfile = tmp_dir / f'oncv_{sym}.out'
                infile.write_text(content, encoding='utf-8')
                with open(infile, 'r', encoding='utf-8', errors='replace') as inf:
                    proc = subprocess.run([str(exe)], stdin=inf, capture_output=True, text=True, timeout=300, cwd=str(tmp_dir))
                out_s = (proc.stdout or '') + '\\n' + (proc.stderr or '') + (proc.stderr or '')
                outfile.write_text(out_s, encoding='utf-8')
                upf_list = _discover_oncv_upf_files_sa(tmp_dir, sym)
                upf_pick = upf_list[0] if upf_list else None
                fin = _finalize_upf_sa(upf_pick, sym, 'oncvpsp', stdout_text=proc.stdout, work_dir=tmp_dir, input_path=infile, log_text=out_s)
                results.append({
                    'element': sym,
                    'success': bool(fin['qe_validation'].get('conform_qe')),
                    'upf': fin.get('upf_genere'),
                    'upf_path': fin.get('upf_path'),
                    'qe_validation': fin['qe_validation'],
                    'returncode': proc.returncode,
                })
            else:
                errors.append({'element': sym, 'error': f'Generateur {generator} pas supporte en batch'})
        except subprocess.TimeoutExpired:
            errors.append({'element': sym, 'error': 'Timeout 300s'})
        except Exception as e:
            errors.append({'element': sym, 'error': str(e)[:200]})
    return jsonify({
        'success': len(errors) == 0,
        'batch_results': results,
        'errors': errors,
        'total_requested': len(elements),
        'total_success': sum(1 for r in results if r.get('success')),
        'total_errors': len(errors),
        'generator': generator,
    })


# ─── Fichiers statiques (apres toutes les routes /api/* pour eviter collisions POST/GET) ──

@app.route('/api/pseudos/logs', methods=['GET'])
def pseudos_logs():
    """Server-Sent Events (SSE) pour les logs en direct."""
    import time as _time

    def _get_recent_logs(max_lines=40):
        logs = []
        runs_root = Path(_STANDALONE_ROOT)
        try:
            from generator_guide import GENERATOR_OUTPUT_DIRS
            gen_scan = list(GENERATOR_OUTPUT_DIRS)
        except ImportError:
            gen_scan = ['pseudos-ld1', 'pseudos-APE', 'pseudos-atompaw', 'pseudos-oncvpsp']
        for gen_dir in gen_scan:
            base = runs_root / gen_dir / '_runs'
            if not base.is_dir():
                continue
            for run_dir in sorted(base.iterdir(), reverse=True)[:10]:
                for out_f in sorted(run_dir.glob('*.out')):
                    try:
                        with open(out_f, 'r', errors='replace') as f:
                            for line in f.readlines()[-max_lines:]:
                                logs.append({
                                    'time': _time.strftime('%H:%M:%S'),
                                    'source': run_dir.name,
                                    'line': line.rstrip()[:400],
                                })
                                if len(logs) >= max_lines:
                                    break
                    except Exception:
                        pass
                    if len(logs) >= max_lines:
                        break
                if len(logs) >= max_lines:
                    break
            if len(logs) >= max_lines:
                break
        return logs

    def generate():
        try:
            max_lines = min(max(int(request.args.get('lines', 40)), 10), 200)
        except (ValueError, TypeError):
            max_lines = 40
        initial = _get_recent_logs(max_lines)
        yield 'data: ' + json.dumps({'type': 'initial', 'logs': initial}) + '\n\n'
        sent = len(initial)
        try:
            while True:
                _time.sleep(3)
                cur = _get_recent_logs(max_lines)
                if len(cur) > sent:
                    diff = cur[sent:]
                    sent = len(cur)
                    yield 'data: ' + json.dumps({'type': 'update', 'logs': diff}) + '\n\n'
                else:
                    yield 'data: ' + json.dumps({'type': 'heartbeat', 'time': _time.time()}) + '\n\n'
        except GeneratorExit:
            pass

    return Response(
        generate(),
        mimetype='text/event-stream',
        headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'},
    )


@app.route('/api/pseudos/runs', methods=['GET'])
def pseudos_runs():
    """Liste les dernieres sessions de generation avec fichiers UPF trouves."""
    runs = []
    runs_root = Path(_STANDALONE_ROOT)
    try:
        from generator_guide import GENERATOR_OUTPUT_DIRS
        gen_dirs = list(GENERATOR_OUTPUT_DIRS)
    except ImportError:
        gen_dirs = ['pseudos-ld1', 'pseudos-APE', 'pseudos-atompaw', 'pseudos-oncvpsp']
    for gen_dir in gen_dirs:
        base = runs_root / gen_dir / '_runs'
        if not base.is_dir():
            continue
        for run_dir in sorted(base.iterdir(), reverse=True)[:30]:
            meta = run_dir / 'meta.json'
            meta_data = {}
            if meta.is_file():
                try:
                    meta_data = json.loads(meta.read_text())
                except Exception:
                    pass
            upf_files = sorted(run_dir.glob('*.UPF')) + sorted(run_dir.glob('*.upf'))
            runs.append({
                'dir': run_dir.name,
                'path': str(run_dir.relative_to(runs_root)),
                'generator': gen_dir,
                'meta': meta_data,
                'upf_files': [f.name for f in upf_files],
                'mtime': run_dir.stat().st_mtime,
            })
    return jsonify({'runs': runs, 'total': len(runs)})


# ─── Fichiers statiques (après toutes les routes /api/* pour éviter collisions POST/GET) ──

_SAFE_EXT = {
    '.html', '.htm', '.js', '.css', '.json', '.png', '.jpg', '.jpeg',
    '.svg', '.ico', '.woff', '.woff2', '.ttf', '.eot', '.map', '.txt', '.dat',
}


@app.route('/', methods=['GET'])
def _serve_index():
    idx = _STATIC_ROOT / 'index.html'
    if idx.is_file():
        return _STATIC_ROOT.joinpath('index.html').read_bytes(), 200, {
            'Content-Type': 'text/html; charset=utf-8',
            'Cache-Control': 'no-cache',
        }
    return 'index.html introuvable', 404


@app.route('/<path:relpath>', methods=['GET'])
def _serve_static(relpath):
    # Ne pas intercepter les routes /api/* ni /health
    if relpath.startswith('api/') or relpath == 'health':
        from flask import abort
        abort(404)
    target = (_STATIC_ROOT / relpath).resolve()
    try:
        target.relative_to(_STATIC_ROOT)  # empêche les path traversals
    except ValueError:
        from flask import abort
        abort(403)
    if not target.is_file():
        from flask import abort
        abort(404)
    ext = target.suffix.lower()
    if ext not in _SAFE_EXT:
        from flask import abort
        abort(403)
    mime = mimetypes.guess_type(str(target))[0] or 'application/octet-stream'
    return target.read_bytes(), 200, {
        'Content-Type': mime,
        'Cache-Control': 'no-cache',
    }


# ─── Route de configuration (lecture/écriture api_config.json) ───────────────

@app.route('/api/config', methods=['GET'])
def api_config_get():
    """Retourne la configuration actuelle depuis api_config.json."""
    cfg = _standalone_api_config()
    return jsonify({'success': True, 'config': cfg})


@app.route('/api/config/save', methods=['POST', 'OPTIONS'])
def api_config_save():
    """Sauvegarde la configuration dans api_config.json (a cote du serveur)."""
    if request.method == 'OPTIONS':
        return '', 204
    data = request.get_json() or {}
    if not isinstance(data, dict):
        return jsonify({'success': False, 'error': 'Corps JSON invalide.'}), 400
    here = os.path.dirname(os.path.abspath(__file__))
    cfg_path = os.path.join(here, 'api_config.json')
    existing = {}
    if os.path.isfile(cfg_path):
        try:
            with open(cfg_path, 'r', encoding='utf-8') as f:
                existing = json.load(f)
        except Exception:
            existing = {}
    existing.update(data)
    try:
        with open(cfg_path, 'w', encoding='utf-8') as f:
            json.dump(existing, f, indent=2, ensure_ascii=False)
            f.write('\n')
        return jsonify({'success': True, 'config': existing, 'path': cfg_path})
    except OSError as e:
        return jsonify({'success': False, 'error': f'Ecriture impossible : {e}'}), 500


# ─── Démarrage ─────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    print()
    print('═' * 62)
    print('  API Pseudopotentiels — Standalone (4 générateurs)')
    print('═' * 62)
    _ld1 = _resolve_ld1_bin()
    _ocv = _resolve_oncvpsp_bin()
    _ape = _resolve_ape_bin_sa()
    _aw = _resolve_atompaw_bin_sa()
    print(f'  ld1.x    : {_ld1 or "absent — bin/ld1.x"}')
    print(f'  pw.x     : {_resolve_pw_bin() or "absent — bin/pw.x"}')
    print(f'  APE      : {_ape or "absent — bin/ape"}')
    print(f'  ATOMPAW  : {_aw or "absent — bin/atompaw"}')
    print(f'  ONCVPSP  : {_ocv or "absent — bin/oncvpsp.x"}')
    print(f'  QE bin   : {QE_BIN or "(optionnel)"}')
    print(f'  Pseudos  : {PSEUDOS}')
    print(f'  Port     : {API_PORT}')
    n_ok = sum(1 for x in (_ld1, _ape, _aw, _ocv) if x)
    print(f'  Autonomie: {n_ok}/4 générateurs')
    print()
    print(f'  Interface  → http://127.0.0.1:{API_PORT}/')
    print(f'  Diagnostic → http://127.0.0.1:{API_PORT}/api/pseudos/diagnose')
    print('═' * 62)
    print()

    if n_ok < 4:
        print('ℹ️  Générateurs manquants : ./configure.sh puis scripts/vendor_generators.sh')
        print()
    if not QE_BIN:
        print('ℹ️  QE absent — normal en mode autonome (pw.x non requis pour générer).')
        print()

    _ensure_generator_output_dirs_sa()
    print('  Dossiers de sortie (un par générateur) :')
    for gen_key, label in (
        ('ld1', 'ld1.x'),
        ('ape', 'APE'),
        ('atompaw', 'ATOMPAW'),
        ('oncvpsp', 'ONCVPSP'),
    ):
        try:
            p, w = _pseudo_gen_bucket_sa(gen_key)
            extra = f'  ⚠ {w}' if w else ''
            print(f'    {label:10} → {p}{extra}')
        except OSError as e:
            print(f'    {label:10} → ❌ {e}')
    print()

    nb_pseudos = len(lister_upf())
    print(f'  📦 {nb_pseudos} pseudopotentiel(s) trouvé(s) dans {PSEUDOS}')
    print()

    app.run(host='0.0.0.0', port=API_PORT, debug=False, threaded=True)

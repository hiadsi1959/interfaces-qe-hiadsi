# -*- coding: utf-8 -*-
"""
Gabarits ONCVPSP (.dat) pour métaux de transition 4d (Y–Cd).

Référence format : data/oncvpsp_tests_data/40_Zr.dat
  — cœur 1s–3d (nc=6) + valence 4s/4p/4d/5s (nv=4).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

TRANSITION_4D_SYMBOLS: tuple[str, ...] = (
    "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd",
)

_OFFICIAL_ONCV_4D = frozenset({"Zr"})  # tests/data/40_Zr.dat

# Occupations valence 4d (Aufbau simplifié) : (4d, 5s)
# Pd : ONCV refuse f=0 en config de référence → 4d9 5s1 (transfert classique)
_VALENCE_4D: dict[str, tuple[float, float]] = {
    "Y": (1.0, 2.0),
    "Zr": (2.0, 2.0),
    "Nb": (4.0, 1.0),
    "Mo": (5.0, 1.0),
    "Tc": (5.0, 2.0),
    "Ru": (7.0, 1.0),
    "Rh": (8.0, 1.0),
    "Pd": (9.0, 1.0),
    "Ag": (10.0, 1.0),
    "Cd": (10.0, 2.0),
}

_ONCV_IEXC = {
    "lda_pw": 3,
    "lda_pz": 3,
    "gga_pbe": 3,
    "gga_pbesol": 3,
    "pbe": 3,
    "pbesol": 3,
}

# Cœur [Ar] + 3d10 = 1s–3d (comme 40_Zr.dat)
_CORE_AR3D: tuple[tuple[int, int, float], ...] = (
    (1, 0, 2.0),
    (2, 0, 2.0),
    (2, 1, 6.0),
    (3, 0, 2.0),
    (3, 1, 6.0),
    (3, 2, 10.0),
)


def _norm(sym: str) -> str:
    s = (sym or "").strip()
    if not s:
        return ""
    return s.upper() if len(s) == 1 else s[0].upper() + s[1:].lower()


def is_transition_4d(sym: str) -> bool:
    return _norm(sym) in TRANSITION_4D_SYMBOLS


def needs_generated_dat(sym: str) -> bool:
    s = _norm(sym)
    return s in TRANSITION_4D_SYMBOLS and s not in _OFFICIAL_ONCV_4D


def atomic_number(sym: str) -> int:
    try:
        from pseudo_auto_inputs import atomic_number as az

        return int(az(sym))
    except Exception:
        zmap = {
            "Y": 39, "Zr": 40, "Nb": 41, "Mo": 42, "Tc": 43,
            "Ru": 44, "Rh": 45, "Pd": 46, "Ag": 47, "Cd": 48,
        }
        return zmap.get(_norm(sym), 0)


def get_guide(sym: str) -> dict[str, Any]:
    sym = _norm(sym)
    return {
        "element": sym,
        "is_transition_4d": True,
        "has_official_dat": sym in _OFFICIAL_ONCV_4D,
        "valence_note": "Valence type Zr : 4s, 4p, 4d, 5s après cœur 1s–3d",
        "message": (
            f"{sym} : gabarit ONCV 4d généré (format 40_Zr.dat). "
            "Valider ghosts / transfert ; sinon PseudoDojo ou ATOMPAW."
        ),
        "pseudodojo_url": "https://www.pseudo-dojo.org/",
    }


def generate_oncv_dat(
    sym: str,
    xc: str = "gga_pbe",
    rc_scale: float = 1.0,
    psfile: str = "both",
) -> str:
    """Entrée ONCV NC pour un métal 4d (sauf Zr officiel)."""
    sym = _norm(sym)
    if not is_transition_4d(sym):
        raise ValueError(f"{sym} n'est pas un métal 4d (Y–Cd).")
    if sym in _OFFICIAL_ONCV_4D:
        raise ValueError(f"{sym} : utiliser tests/data/40_Zr.dat.")

    Z = atomic_number(sym)
    iexc = _ONCV_IEXC.get((xc or "gga_pbe").lower(), 3)
    d_occ, s_occ = _VALENCE_4D.get(sym, (10.0, 2.0))

    # Semi-cœur 4s2 4p6 + 4d + 5s (comme Zr)
    # ONCV : occupation f>0 obligatoire sur chaque ligne de référence
    val_lines: list[tuple[int, int, float]] = [
        (4, 0, 2.0),
        (4, 1, 6.0),
        (4, 2, float(d_occ)),
        (5, 0, float(s_occ) if s_occ > 0 else 1.0),
    ]
    if s_occ <= 0 and d_occ >= 10:
        # filet (ne devrait plus arriver) : déplacer 1 e- de d vers s
        val_lines[2] = (4, 2, d_occ - 1.0)
        val_lines[3] = (5, 0, 1.0)

    core_lines = list(_CORE_AR3D)
    nc = len(core_lines)
    nv = len(val_lines)
    lmax = 2

    # Rayons : un peu plus durs que Zr pour Cd (d plein), proches de Zr sinon
    base = 2.05 if sym == "Cd" else 2.15
    if sym in ("Ag", "Pd"):
        base = 2.00
    scale = float(rc_scale)
    rc_s = round(base * scale, 2)
    rc_p = round((base + 0.05) * scale, 2)
    rc_d = round((base - 0.15) * scale, 2)
    rc_local = round(min(rc_s, rc_p, rc_d), 1)
    rc_s = max(rc_s, rc_local)
    rc_p = max(rc_p, rc_local)
    rc_d = max(rc_d, rc_local)

    rc_lines = [
        f"    0    {rc_s:.2f}    0.00    5    8    6.00",
        f"    1    {rc_p:.2f}    0.00    5    8    6.00",
        f"    2    {rc_d:.2f}    0.00    5    8    6.50",
    ]
    proj = [
        "    0    2    1.50",
        "    1    2    1.50",
        "    2    2    1.25",
    ]

    ps = (psfile or "both").strip().lower()
    if ps not in ("upf", "both", "psp8"):
        ps = "both"

    atsym = sym.lower()[:2]
    val_str = " ".join(f"{n}{'spdf'[l]}{int(o)}" for n, l, o in val_lines if o > 0)

    header = (
        "# ONCVPSP — métal 4d NC (generation_pseudos/transition_4d_nc.py)\n"
        f"# Élément {sym} Z={Z} — valence {val_str}\n"
        f"# Cible QE : psfile={ps} — modèle type 40_Zr.dat\n"
        "#\n"
        "# ATOM AND REFERENCE CONFIGURATION\n"
        "# atsym, z, nc, nv, iexc   psfile\n"
        f"  {atsym}  {float(Z):.1f}   {nc}   {nv}   {iexc}   {ps}\n"
        "#\n"
        "# n, l, f  (nc+nv lines)\n"
    )
    elec = [f"    {n}    {l}    {occ:.1f}" for n, l, occ in core_lines + val_lines]
    opt = (
        "#\n# PSEUDOPOTENTIAL AND OPTIMIZATION\n# lmax\n"
        f"    {lmax}\n#\n# l, rc, ep, ncon, nbas, qcut  (lmax+1 lines, l's must be in order)\n"
        + "\n".join(rc_lines)
        + "\n#\n# LOCAL POTENTIAL\n# lloc, lpopt, rc(5), dvloc0\n"
        f"    4    5    {rc_local:.1f}    0.0\n#\n"
        "# VANDERBILT-KLEINMAN-BYLANDER PROJECTORs\n# l, nproj, debl  (lmax+1 lines, l's in order)\n"
        + "\n".join(proj)
        + "\n#\n# MODEL CORE CHARGE\n# icmod, fcfact\n    0    0.0\n#\n"
        "# LOG DERIVATIVE ANALYSIS\n# epsh1, epsh2, depsh\n   -3.0  3.0  0.02\n#\n"
        "# OUTPUT GRID\n# rlmax, drl\n    5.0  0.01\n#\n# TEST CONFIGURATIONS\n# ncnf\n    0\n"
    )
    return header + "\n".join(elec) + "\n" + opt


def ensure_cached_templates(project_root: str | Path) -> list[str]:
    """Écrit oncv_templates_4d/<Sym>.dat pour Y–Cd (sauf Zr)."""
    root = Path(project_root).expanduser().resolve()
    cache = root / "oncv_templates_4d"
    cache.mkdir(parents=True, exist_ok=True)
    written: list[str] = []
    for sym in TRANSITION_4D_SYMBOLS:
        if not needs_generated_dat(sym):
            continue
        path = cache / f"{sym}.dat"
        try:
            path.write_text(generate_oncv_dat(sym), encoding="utf-8")
            written.append(sym)
        except Exception:
            pass
    return written

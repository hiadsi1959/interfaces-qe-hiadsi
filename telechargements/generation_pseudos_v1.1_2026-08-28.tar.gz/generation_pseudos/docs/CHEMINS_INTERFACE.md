# Chemins requis par l’interface (autonomie 100 %)

L’interface est servie par `api_pseudos_standalone.py` à la **racine du projet**.  
**Préfixe canonique des binaires : `./bin/`** (pas besoin d’une install QE externe).

Sur chaque PC : `./scripts/vendor_generators.sh` → `./configure.sh -y` → `./DEMARRER.sh`  
→ écrit `api_config.json` + UI via `GET /api/chemins`.

## Binaires (autonomie 4/4)

| Fichier | Rôle |
|---------|------|
| `bin/ld1.x` | Générateur QE ld1 |
| `bin/ape` | Lien → `third_party/ape/…` |
| `bin/atompaw` | Lien → `third_party/atompaw/…` |
| `bin/oncvpsp.x` | ONCVPSP NC |
| `bin/pw.x` | Optionnel (tests SCF) |

L’UI « Chemins PC » affiche le chemin `bin/…` et, si symlink, la cible réelle.

## Fichiers statiques (racine)

Servis en GET `http://127.0.0.1:5008/<fichier>` :

| Fichier / dossier | Usage |
|-------------------|--------|
| `index.html` | Page principale |
| `pseudo_wizard.html` | Assistant guidé |
| `qe_paths_setup.js`, `config_chemins.js` | Chemins PC / API |
| `script_tableau_periodique.js` | Tableau périodique |
| `script_generateur_ld1.js`, `script_generateur_ape_atompaw.js`, … | Générateurs |

## Gabarits ONCV (fetch navigateur)

- `oncv_default_<Symbole>.dat` — racine ou `data/oncv/`
- `oncv_templates_3d/<Symbole>.dat`

## Dossiers de sortie / entrées (API)

| Dossier | Rôle |
|---------|------|
| `pseudos/` | Bibliothèque catalogue |
| `pseudos_generes/` | Archive UPF conformes QE |
| `pseudos-ld1/`, `pseudos-APE/`, `pseudos-atompaw/`, `pseudos-oncvpsp/` | Sorties par générateur |
| `pseudo_generator_templates/ape/`, `…/atompaw/` | Entrées éditées |
| `_work/` | Runs temporaires |
| `bin/` | Préfixe autonomie |
| `third_party/ape`, `third_party/atompaw` | Cibles des symlinks `bin/` |

## Vérification

```bash
./scripts/verifier_chemins_ui.sh
curl -s http://127.0.0.1:5008/api/chemins | python3 -m json.tool | head -60
# autonomie.score_pct doit être 100
```

Puis navigateur : `http://127.0.0.1:5008/` → bouton **Chemins PC**.

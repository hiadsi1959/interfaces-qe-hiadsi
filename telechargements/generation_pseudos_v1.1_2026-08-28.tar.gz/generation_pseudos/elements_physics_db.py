# -*- coding: utf-8 -*-
"""
Base de données physique des éléments pour la génération de pseudopotentiels.
rc en Bohr (référence PseudoDojo / ONCVPSP / SSSP ± 5 %, adaptés APE/ATOMPAW).
"""
from __future__ import annotations

# ── Fonctionnelles XC ─────────────────────────────────────────────────────────
XC_DEFS: dict[str, dict] = {
    "lda_pw":     {"label": "LDA (PW92)",   "ape_block": " lda_x\n lda_c_pw",          "atompaw_kw": "LDA-PW"},
    "lda_pz":     {"label": "LDA (PZ81)",   "ape_block": " lda_x\n lda_c_pz",          "atompaw_kw": "LDA-PZ"},
    "gga_pbe":    {"label": "GGA (PBE)",    "ape_block": " gga_x_pbe\n gga_c_pbe",     "atompaw_kw": "GGA-PBE"},
    "gga_pbesol": {"label": "GGA (PBEsol)", "ape_block": " gga_x_pbe_sol\n gga_c_pbe_sol", "atompaw_kw": "GGA-PBEsol"},
}
XC_DEFAULT = "lda_pw"

# ── Types de pseudo ────────────────────────────────────────────────────────────
PP_TYPE_APE: dict[str, str] = {
    "troullier": "tm",
    "hamann":    "ham",
}
PP_TYPE_ATOMPAW: dict[str, str] = {
    "vanderbilt":    "VANDERBILT",
    "bloechl":       "BLOECHL",
    "vanderbilt_tm": "VANDERBILT MTROULLIER",
}
PP_TYPE_APE_DEFAULT     = "troullier"
PP_TYPE_ATOMPAW_DEFAULT = "vanderbilt"

# ── Données physiques par élément ──────────────────────────────────────────────
# Colonnes : (Z, sym, nom, rc_default, {l: rc}, l_local, scalar_rel, [(n,l)], note)
_RAW: list = [
    (1,  "H",  "Hydrogène",    0.80, {0: 0.80},                         -1, False, [],                   "1 orbital s uniquement."),
    (2,  "He", "Hélium",       0.90, {0: 0.90},                         -1, False, [],                   "Gaz noble, rare en PP."),
    (3,  "Li", "Lithium",      1.50, {0: 1.50, 1: 1.60},                 1, False, [],                   "Valence 2s."),
    (4,  "Be", "Béryllium",    1.40, {0: 1.40, 1: 1.55},                 1, False, [],                   ""),
    (5,  "B",  "Bore",         1.50, {0: 1.50, 1: 1.50},                 1, False, [],                   ""),
    (6,  "C",  "Carbone",      1.50, {0: 1.50, 1: 1.50},                 1, False, [],                   "Ecut élevé requis."),
    (7,  "N",  "Azote",        1.45, {0: 1.45, 1: 1.45},                 1, False, [],                   ""),
    (8,  "O",  "Oxygène",      1.40, {0: 1.40, 1: 1.40},                 1, False, [],                   "Ecut ≥ 80 Ry."),
    (9,  "F",  "Fluor",        1.35, {0: 1.35, 1: 1.35},                 1, False, [],                   "Très électronégatif."),
    (10, "Ne", "Néon",         1.40, {0: 1.40, 1: 1.40},                 1, False, [],                   "Gaz noble."),
    (11, "Na", "Sodium",       1.80, {0: 1.80, 1: 1.90, 2: 1.90},        2, False, [],                   ""),
    (12, "Mg", "Magnésium",    1.80, {0: 1.80, 1: 1.90, 2: 1.90},        2, False, [],                   ""),
    (13, "Al", "Aluminium",    1.85, {0: 1.85, 1: 1.85, 2: 1.95},        2, False, [],                   ""),
    (14, "Si", "Silicium",     1.80, {0: 1.80, 1: 1.80, 2: 1.90},        2, False, [],                   "Référence de test standard."),
    (15, "P",  "Phosphore",    1.75, {0: 1.75, 1: 1.75, 2: 1.85},        2, False, [],                   ""),
    (16, "S",  "Soufre",       1.70, {0: 1.70, 1: 1.70, 2: 1.80},        2, False, [],                   ""),
    (17, "Cl", "Chlore",       1.65, {0: 1.65, 1: 1.65, 2: 1.75},        2, False, [],                   ""),
    (18, "Ar", "Argon",        1.70, {0: 1.70, 1: 1.70, 2: 1.80},        2, False, [],                   "Gaz noble."),
    (19, "K",  "Potassium",    2.00, {0: 2.00, 1: 2.00, 2: 2.20},        2, False, [],                   ""),
    (20, "Ca", "Calcium",      1.90, {0: 1.90, 1: 1.90, 2: 2.10},        2, False, [],                   ""),
    (21, "Sc", "Scandium",     1.80, {0: 1.80, 1: 2.00, 2: 1.80},        2, False, [(3, 0), (3, 1)],     "3s3p semi-cœur pour oxydes."),
    (22, "Ti", "Titane",       1.80, {0: 1.80, 1: 2.00, 2: 1.70},        2, False, [(3, 0), (3, 1)],     "3s3p → précision+."),
    (23, "V",  "Vanadium",     1.75, {0: 1.75, 1: 1.90, 2: 1.65},        2, False, [(3, 0), (3, 1)],     ""),
    (24, "Cr", "Chrome",       1.70, {0: 1.70, 1: 1.90, 2: 1.60},        2, False, [(3, 0), (3, 1)],     "Aufbau anormal [Ar]3d5 4s1."),
    (25, "Mn", "Manganèse",    1.70, {0: 1.70, 1: 1.90, 2: 1.60},        2, False, [(3, 0), (3, 1)],     ""),
    (26, "Fe", "Fer",          1.65, {0: 1.65, 1: 1.85, 2: 1.55},        2, False, [(3, 0), (3, 1)],     "3s3p crucial pour magnétisme."),
    (27, "Co", "Cobalt",       1.60, {0: 1.60, 1: 1.80, 2: 1.55},        2, False, [(3, 0), (3, 1)],     ""),
    (28, "Ni", "Nickel",       1.60, {0: 1.60, 1: 1.80, 2: 1.55},        2, False, [(3, 0), (3, 1)],     ""),
    (29, "Cu", "Cuivre",       1.58, {0: 1.58, 1: 1.70, 2: 1.58},        2, False, [(3, 0), (3, 1)],     "Aufbau anormal [Ar]3d10 4s1."),
    (30, "Zn", "Zinc",         1.65, {0: 1.65, 1: 1.75, 2: 1.60},        2, False, [(3, 0), (3, 1)],     "3d plein."),
    (31, "Ga", "Gallium",      1.75, {0: 1.75, 1: 1.75, 2: 1.80},        2, False, [(3, 0), (3, 1)],     ""),
    (32, "Ge", "Germanium",    1.80, {0: 1.80, 1: 1.80, 2: 1.90},        2, False, [(3, 0), (3, 1)],     ""),
    (33, "As", "Arsenic",      1.75, {0: 1.75, 1: 1.75, 2: 1.85},        2, False, [],                   ""),
    (34, "Se", "Sélénium",     1.75, {0: 1.75, 1: 1.75, 2: 1.85},        2, False, [],                   ""),
    (35, "Br", "Brome",        1.70, {0: 1.70, 1: 1.70, 2: 1.80},        2, False, [],                   ""),
    (36, "Kr", "Krypton",      1.80, {0: 1.80, 1: 1.80, 2: 1.90},        2, False, [],                   "Gaz noble."),
    (37, "Rb", "Rubidium",     2.20, {0: 2.20, 1: 2.20, 2: 2.30},        2, True,  [],                   "Scalar-rel. activé."),
    (38, "Sr", "Strontium",    2.10, {0: 2.10, 1: 2.10, 2: 2.20},        2, True,  [],                   ""),
    (39, "Y",  "Yttrium",      2.00, {0: 2.00, 1: 2.10, 2: 1.90},        2, True,  [(4, 0), (4, 1)],     "4s4p semi-cœur parfois utile."),
    (40, "Zr", "Zirconium",    1.95, {0: 1.95, 1: 2.10, 2: 1.85},        2, True,  [(4, 0), (4, 1)],     ""),
    (41, "Nb", "Niobium",      1.90, {0: 1.90, 1: 2.05, 2: 1.80},        2, True,  [(4, 0), (4, 1)],     "Aufbau anormal."),
    (42, "Mo", "Molybdène",    1.90, {0: 1.90, 1: 2.05, 2: 1.80},        2, True,  [(4, 0), (4, 1)],     "Aufbau anormal."),
    (43, "Tc", "Technétium",   1.85, {0: 1.85, 1: 2.00, 2: 1.80},        2, True,  [],                   "Radioactif."),
    (44, "Ru", "Ruthénium",    1.85, {0: 1.85, 1: 2.00, 2: 1.80},        2, True,  [],                   "Aufbau anormal."),
    (45, "Rh", "Rhodium",      1.85, {0: 1.85, 1: 2.00, 2: 1.80},        2, True,  [],                   "Aufbau anormal."),
    (46, "Pd", "Palladium",    1.80, {0: 1.80, 1: 1.95, 2: 1.75},        2, True,  [],                   "Aufbau anormal [Kr]4d10."),
    (47, "Ag", "Argent",       1.80, {0: 1.80, 1: 1.95, 2: 1.75},        2, True,  [(4, 0), (4, 1)],     "Aufbau anormal."),
    (48, "Cd", "Cadmium",      1.85, {0: 1.85, 1: 2.00, 2: 1.80},        2, True,  [(4, 0), (4, 1)],     ""),
    (49, "In", "Indium",       1.90, {0: 1.90, 1: 1.90, 2: 2.00},        2, True,  [],                   ""),
    (50, "Sn", "Étain",        1.95, {0: 1.95, 1: 1.95, 2: 2.00},        2, True,  [],                   ""),
    (51, "Sb", "Antimoine",    1.95, {0: 1.95, 1: 1.95, 2: 2.05},        2, True,  [],                   ""),
    (52, "Te", "Tellure",      1.90, {0: 1.90, 1: 1.90, 2: 2.00},        2, True,  [],                   ""),
    (53, "I",  "Iode",         1.85, {0: 1.85, 1: 1.85, 2: 1.95},        2, True,  [],                   ""),
    (54, "Xe", "Xénon",        1.90, {0: 1.90, 1: 1.90, 2: 2.00},        2, True,  [],                   "Gaz noble."),
    (55, "Cs", "Césium",       2.40, {0: 2.40, 1: 2.40, 2: 2.50},        2, True,  [],                   "Gros atome."),
    (56, "Ba", "Baryum",       2.20, {0: 2.20, 1: 2.20, 2: 2.30},        2, True,  [],                   ""),
    (57, "La", "Lanthane",     2.10, {0: 2.10, 1: 2.10, 2: 2.00, 3: 2.00}, 2, True, [(5, 0), (5, 1)],   "Lanthanide NC : open_core ou 5d/6s ; ONCV recommandé."),
    (58, "Ce", "Cérium",       2.10, {0: 2.10, 1: 2.10, 2: 2.00, 3: 2.00}, 2, True, [(5, 0), (5, 1)],   "4f : valence_f (magnétisme) ou open_core ; r_c(4f) 1.8–2.3 bohr."),
    (59, "Pr", "Praseodyme",   2.05, {0: 2.05, 1: 2.05, 2: 2.00, 3: 2.00}, 2, True, [(5, 0), (5, 1)],   "NC ONCV — ghost : ajuster r_c(4f)."),
    (60, "Nd", "Néodyme",      2.00, {0: 2.00, 1: 2.00, 2: 1.95, 3: 2.00}, 2, True, [(5, 0), (5, 1)],   "Réf. ONCV 60_Nd_GHOST.dat — r_c(4f) critique."),
    (61, "Pm", "Prométhium",   2.00, {0: 2.00, 1: 2.00, 2: 1.95, 3: 2.00}, 2, True, [(5, 0), (5, 1)],   "Radioactif — même logique Nd."),
    (62, "Sm", "Samarium",     2.00, {0: 2.00, 1: 2.00, 2: 1.95, 3: 2.00}, 2, True, [(5, 0), (5, 1)],   "open_core si 4f inertes en pratique."),
    (63, "Eu", "Europium",     2.00, {0: 2.00, 1: 2.00, 2: 1.95, 3: 2.00}, 2, True, [(5, 0), (5, 1)],   "valence_f + DFT+U fréquent (f⁷)."),
    (64, "Gd", "Gadolinium",   2.00, {0: 2.00, 1: 2.00, 2: 1.95, 3: 2.00}, 2, True, [(5, 0), (5, 1)],   "4f⁷5d¹6s² — open_core ou valence_f."),
    (65, "Tb", "Terbium",      2.00, {0: 2.00, 1: 2.00, 2: 1.95, 3: 2.00}, 2, True, [(5, 0), (5, 1)],   "NC dur (ecut élevé) si 4f en valence."),
    (66, "Dy", "Dysprosium",   2.00, {0: 2.00, 1: 2.00, 2: 1.95, 3: 2.00}, 2, True, [(5, 0), (5, 1)],   "PseudoDojo souvent plus rapide que ld1.x."),
    (67, "Ho", "Holmium",      2.00, {0: 2.00, 1: 2.00, 2: 1.95, 3: 2.00}, 2, True, [(5, 0), (5, 1)],   ""),
    (68, "Er", "Erbium",       2.00, {0: 2.00, 1: 2.00, 2: 1.95, 3: 2.00}, 2, True, [(5, 0), (5, 1)],   ""),
    (69, "Tm", "Thulium",      2.00, {0: 2.00, 1: 2.00, 2: 1.95, 3: 2.00}, 2, True, [(5, 0), (5, 1)],   ""),
    (70, "Yb", "Ytterbium",    2.00, {0: 2.00, 1: 2.00, 2: 1.95, 3: 2.00}, 2, True, [(5, 0), (5, 1)],   "4f¹⁴ — open_core naturel."),
    (71, "Lu", "Lutécium",     2.00, {0: 2.00, 1: 2.00, 2: 1.95, 3: 2.10}, 2, True, [(5, 0), (5, 1)],   "4f¹⁴ cœur ; valence 5d¹6s²."),
    (72, "Hf", "Hafnium",      1.95, {0: 1.95, 1: 2.00, 2: 1.85, 3: 2.10}, 2, True, [(5, 0), (5, 1), (5, 2)], "5p semi-cœur recommandé."),
    (73, "Ta", "Tantale",      1.90, {0: 1.90, 1: 2.00, 2: 1.80, 3: 2.10}, 2, True, [(5, 0), (5, 1), (5, 2)], ""),
    (74, "W",  "Tungstène",    1.85, {0: 1.85, 1: 2.00, 2: 1.75, 3: 2.10}, 2, True, [(5, 0), (5, 1), (5, 2)], "Aufbau anormal."),
    (75, "Re", "Rhénium",      1.85, {0: 1.85, 1: 1.95, 2: 1.75, 3: 2.10}, 2, True, [],                  ""),
    (76, "Os", "Osmium",       1.80, {0: 1.80, 1: 1.90, 2: 1.75, 3: 2.10}, 2, True, [],                  ""),
    (77, "Ir", "Iridium",      1.80, {0: 1.80, 1: 1.90, 2: 1.75, 3: 2.10}, 2, True, [],                  ""),
    (78, "Pt", "Platine",      1.80, {0: 1.80, 1: 1.90, 2: 1.70, 3: 2.10}, 2, True, [],                  "Aufbau anormal."),
    (79, "Au", "Or",           1.80, {0: 1.80, 1: 1.90, 2: 1.70, 3: 2.10}, 2, True, [(5, 0), (5, 1)],   "5s5p semi-cœur souvent nécessaire."),
    (80, "Hg", "Mercure",      1.85, {0: 1.85, 1: 1.95, 2: 1.80, 3: 2.10}, 2, True, [(5, 0), (5, 1)],   ""),
    (81, "Tl", "Thallium",     1.90, {0: 1.90, 1: 1.90, 2: 2.00},          2, True, [],                  ""),
    (82, "Pb", "Plomb",        1.95, {0: 1.95, 1: 1.95, 2: 2.05},          2, True, [],                  ""),
    (83, "Bi", "Bismuth",      1.95, {0: 1.95, 1: 1.95, 2: 2.05},          2, True, [],                  "SOC important."),
    (90, "Th", "Thorium",      2.10, {0: 2.10, 1: 2.10, 2: 2.00, 3: 1.90}, 2, True, [(6, 0), (6, 1)],   "PAW fortement recommandé."),
    (92, "U",  "Uranium",      2.05, {0: 2.05, 1: 2.05, 2: 1.95, 3: 1.85}, 2, True, [(6, 0), (6, 1)],   "DFT+U + PAW indispensable."),
]

ELEMENTS_DB: dict[str, dict] = {
    sym: {
        "z": z, "name": name, "rc_default": rcd,
        "rc_by_l": rcl, "l_local": ll,
        "scalar_rel": sr, "semicore": sc, "note": note,
    }
    for z, sym, name, rcd, rcl, ll, sr, sc, note in _RAW
}


def get_element_info(sym: str) -> dict:
    s = sym.strip()
    s = (s[0].upper() + s[1:].lower()) if len(s) > 1 else s.upper()
    return ELEMENTS_DB.get(s, {})


def get_rc_for_orbital(sym: str, n: int, l: int, scale: float = 1.0) -> float:
    info = get_element_info(sym)
    base = (info["rc_by_l"].get(l) or info["rc_default"]) if info else (1.12 + 0.18 * l + 0.035 * n)
    val = float(base) * float(scale)
    try:
        from rc_optimize import apply_safe_floor

        val = apply_safe_floor(sym, n, l, val)
    except ImportError:
        pass
    return round(val, 3)


def element_metadata(sym: str) -> dict:
    """Dict complet sérialisable JSON pour l'interface."""
    info = get_element_info(sym)
    try:
        import pseudo_auto_inputs as _m
        sym_n = _m.normalize_symbol(sym)
        Z = _m.SYMBOL_TO_Z[sym_n]
        noble_z, noble_sym = _m._prev_noble(Z)
        total = _m.neutral_configuration(Z)
        core = _m.neutral_configuration(noble_z) if noble_z > 0 else {}
        val = {k: v - core.get(k, 0) for k, v in total.items() if v - core.get(k, 0) > 0}
        _L = "spdfg"
        core_lbl = f"[{noble_sym}]" if noble_sym else ""
        val_str = (core_lbl + " " + " ".join(f"{n}{_L[l]}{e}" for (n, l), e in sorted(val.items()))).strip()
    except Exception:
        sym_n = sym; Z = info.get("z", 0); val_str = "?"

    meta = {
        "symbol":                 sym_n,
        "Z":                      Z,
        "name":                   info.get("name", sym_n),
        "valence_config":         val_str,
        "rc_default":             info.get("rc_default", 1.80),
        "rc_by_l":                {str(k): v for k, v in info.get("rc_by_l", {}).items()},
        "l_local":                info.get("l_local", 2),
        "scalar_rel_recommended": info.get("scalar_rel", False),
        "semicore_shells":        [[n, l] for n, l in info.get("semicore", [])],
        "note":                   info.get("note", ""),
        "xc_options":             list(XC_DEFS.keys()),
        "xc_labels":              {k: v["label"] for k, v in XC_DEFS.items()},
        "pp_type_ape_options":    list(PP_TYPE_APE.keys()),
        "pp_type_atompaw_options": list(PP_TYPE_ATOMPAW.keys()),
    }
    try:
        from rc_optimize import diagnose_rc

        meta["rc_optimize"] = {
            "ape": diagnose_rc(sym_n, "ape"),
            "atompaw": diagnose_rc(sym_n, "atompaw"),
            "ld1": diagnose_rc(sym_n, "ld1"),
        }
    except Exception:
        pass
    return meta

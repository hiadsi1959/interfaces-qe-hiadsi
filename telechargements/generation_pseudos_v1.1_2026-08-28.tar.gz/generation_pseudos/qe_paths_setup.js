/**
 * Configuration des chemins — interface autonome generation_pseudos (port 5008).
 * Source de vérité : API /api/chemins (+ api_config.json / ./bin/).
 * Autonomie 4/4 : ld1.x · ape · atompaw · oncvpsp.x sous ./bin/
 */
(function () {
    'use strict';

    var STORAGE_KEY = 'qe_unified_paths_v1';
    /** Incrémenter pour invalider anciens profils hiadsi / QE-only */
    var SCHEMA_VERSION = 5;

    function resolvePseudosApiOrigin() {
        try {
            var loc = window.location;
            if (loc.protocol === 'http:' || loc.protocol === 'https:') {
                var port = String(loc.port || '');
                if (port === '5008' || port === '5009') {
                    return loc.origin.replace(/\/$/, '');
                }
            }
        } catch (e) { /* ignore */ }
        return 'http://127.0.0.1:5008';
    }

    var PRESET_STANDALONE = {
        profile: 'standalone',
        PROJECT_MAIN: '',
        PROJECT_INPUTS_APP: '',
        PROJECT_PSEUDOS_UI: '',
        QE_BIN_DIR: '',
        QE_API_PORT: 5008,
        API_PSEUDOS_ORIGIN: 'http://127.0.0.1:5008',
        schemaVersion: SCHEMA_VERSION
    };

    function trimSlash(p) {
        return String(p || '').replace(/\/+$/, '');
    }

    function deriveFull(cfg) {
        var main = trimSlash(cfg.PROJECT_MAIN);
        var inApp = trimSlash(cfg.PROJECT_INPUTS_APP);
        var qeBin = trimSlash(cfg.QE_BIN_DIR);
        return {
            WORK_DIR: main,
            PROJECT_MAIN: main,
            INPUTS_DIR: main ? main + '/inputs' : '',
            OUTPUTS_DIR: main ? main + '/outputs' : '',
            PSEUDO_DIR: main ? main + '/pseudos' : '',
            CIF_DIR: main ? main + '/fichiers_cif' : '',
            TMP_DIR: main ? main + '/_work' : '',
            INPUTS_GENERES_DIR: inApp ? inApp + '/inputs_générés' : '',
            PSEUDO_GENERES_DIR: main ? main + '/pseudos-ld1' : '',
            LD1_INPUTS_DIR: main ? main + '/pseudos-ld1' : '',
            QE_BIN_DIR: qeBin,
            LD1_BIN: cfg.LD1_BIN || (qeBin ? qeBin + '/ld1.x' : ''),
            APE_BIN: cfg.APE_BIN || '',
            ATOMPAW_BIN: cfg.ATOMPAW_BIN || '',
            ONCVPSP_BIN: cfg.ONCVPSP_BIN || '',
            PW_BIN: cfg.PW_BIN || (qeBin ? qeBin + '/pw.x' : ''),
            BIN_DIR: cfg.BIN_DIR || qeBin,
            PROJECT_INPUTS_APP: inApp,
            PROJECT_PSEUDOS_UI: trimSlash(cfg.PROJECT_PSEUDOS_UI),
            AUTO_REFRESH_INTERVAL: 3000,
            AUTO_START_API: true
        };
    }

    function syncInputsLocalStorage(full) {
        try {
            localStorage.setItem('qe_inputs_config', JSON.stringify({
                INPUTS_GENERES_DIR: full.INPUTS_GENERES_DIR,
                INPUTS_DIR: full.INPUTS_DIR,
                OUTPUTS_DIR: full.OUTPUTS_DIR,
                PSEUDO_DIR: full.PSEUDO_DIR,
                CIF_DIR: full.CIF_DIR,
                QE_BIN_DIR: full.QE_BIN_DIR,
                BIN_DIR: full.BIN_DIR,
                WORK_DIR: full.WORK_DIR
            }));
        } catch (e) {
            console.warn('qe_paths_setup: synchro qe_inputs_config impossible', e);
        }
    }

    function applyCheminsPayload(data) {
        if (!data) return null;
        var root = trimSlash(data.project_root || data.projet || data.work_dir || '');
        var binDir = trimSlash(data.bin_dir || data.qe_bin || '');
        window.QE_CONFIG = window.QE_CONFIG || {};
        window.QE_CONFIG.WORK_DIR = root;
        window.QE_CONFIG.PROJECT_MAIN = root;
        window.QE_CONFIG.QE_BIN_DIR = binDir;
        window.QE_CONFIG.BIN_DIR = binDir;
        window.QE_CONFIG.LD1_BIN = trimSlash(data.ld1_bin || '');
        window.QE_CONFIG.PW_BIN = trimSlash(data.pw_bin || '');
        window.QE_CONFIG.APE_BIN = trimSlash(data.ape_bin || '');
        window.QE_CONFIG.ATOMPAW_BIN = trimSlash(data.atompaw_bin || '');
        window.QE_CONFIG.ONCVPSP_BIN = trimSlash(data.oncvpsp_bin || '');
        if (data.pseudos) window.QE_CONFIG.PSEUDO_DIR = trimSlash(data.pseudos);
        if (data.inputs) window.QE_CONFIG.INPUTS_DIR = trimSlash(data.inputs);
        if (data.outputs) window.QE_CONFIG.OUTPUTS_DIR = trimSlash(data.outputs);
        if (data.tmp) window.QE_CONFIG.TMP_DIR = trimSlash(data.tmp);
        if (data.logs) window.QE_CONFIG.LOGS_DIR = trimSlash(data.logs);
        var d = data.dossiers || {};
        if (d['pseudos-ld1']) window.QE_CONFIG.LD1_INPUTS_DIR = trimSlash(d['pseudos-ld1']);
        if (d['pseudos-ld1']) window.QE_CONFIG.PSEUDO_GENERES_DIR = trimSlash(d['pseudos-ld1']);
        window.__CHEMINS_API__ = data;
        window.__AUTONOMIE__ = data.autonomie || null;

        var el = document.getElementById('pseudos_path_display');
        if (el && data.pseudos) {
            el.textContent = data.pseudos;
            el.style.color = '#a5b4fc';
        }
        var autoEl = document.getElementById('autonomie_score_display');
        if (autoEl && data.autonomie) {
            var a = data.autonomie;
            autoEl.textContent = (a.ready ? '✓ ' : '') + 'Autonomie ' + (a.generators_ok || 0) + '/' + (a.generators_total || 4)
                + ' (' + (a.score_pct || 0) + '%)';
            autoEl.style.color = a.ready ? '#86efac' : '#fbbf24';
            autoEl.title = a.message || '';
        }
        syncInputsLocalStorage(window.QE_CONFIG);
        console.log('✅ Chemins autonomie:', binDir || '(bin/)', '| score',
            (data.autonomie && data.autonomie.score_pct) || '?', '%');
        return data;
    }

    window.applyUnifiedQEPaths = function (raw, opt) {
        opt = opt || {};
        var merged = Object.assign({}, PRESET_STANDALONE, raw || {});
        if (merged.profile === 'hiadsi') {
            merged = Object.assign({}, PRESET_STANDALONE);
        }
        merged.schemaVersion = SCHEMA_VERSION;
        merged.QE_API_PORT = 5008;
        if (!merged.API_PSEUDOS_ORIGIN) {
            merged.API_PSEUDOS_ORIGIN = resolvePseudosApiOrigin();
        }
        var full = deriveFull(merged);
        window.QE_CONFIG = Object.assign(window.QE_CONFIG || {}, full);
        window.QE_API_PORT = 5008;
        window.QE_API_URL = 'http://127.0.0.1:5008';
        window.API_PSEUDOS_ORIGIN = trimSlash(merged.API_PSEUDOS_ORIGIN) || resolvePseudosApiOrigin();
        window.GENERATION_PSEUDOS_API_ORIGIN = window.API_PSEUDOS_ORIGIN;
        if (!opt.skipStorage) {
            try {
                localStorage.setItem(STORAGE_KEY, JSON.stringify({
                    profile: 'standalone',
                    QE_BIN_DIR: merged.QE_BIN_DIR || '',
                    QE_API_PORT: 5008,
                    API_PSEUDOS_ORIGIN: window.API_PSEUDOS_ORIGIN,
                    schemaVersion: SCHEMA_VERSION
                }));
            } catch (e) {
                console.warn('qe_paths_setup: sauvegarde impossible', e);
            }
            syncInputsLocalStorage(full);
        }
        window.__QE_PATHS_READY__ = true;
        window.dispatchEvent(new CustomEvent('qe-paths-ready', { detail: full }));
        console.log('✅ Chemins QE (standalone 5008):', full.QE_BIN_DIR || '(via API)');
    };

    window.loadUnifiedQEPathsFromStorage = function () {
        try {
            var s = localStorage.getItem(STORAGE_KEY);
            if (!s) return null;
            return JSON.parse(s);
        } catch (e) {
            return null;
        }
    };

    function qeEscapeHtml(s) {
        return String(s || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    function hideMismatchBanner() {
        var b = document.getElementById('qe_paths_mismatch_banner');
        if (b) b.remove();
    }

    function loadCheminsFromStandaloneApi() {
        var base = trimSlash(window.API_PSEUDOS_ORIGIN) || 'http://127.0.0.1:5008';
        return fetch(base + '/api/chemins', { cache: 'no-store' })
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (data) {
                return applyCheminsPayload(data);
            })
            .catch(function () { return null; });
    }

    function verifyStandaloneApi() {
        var base = trimSlash(window.API_PSEUDOS_ORIGIN) || 'http://127.0.0.1:5008';
        fetch(base + '/health', { method: 'GET', cache: 'no-store' })
            .then(function (r) {
                if (!r.ok) throw new Error('health');
                return loadCheminsFromStandaloneApi();
            })
            .then(function () { hideMismatchBanner(); })
            .catch(function () {
                if (window.location.protocol === 'file:') return;
                console.warn('API (5008) non joignable — ./DEMARRER.sh');
            });
    }

    window.verifierCheminsAvecAPI = verifyStandaloneApi;

    function injectModalStyles() {
        if (document.getElementById('qe-paths-setup-css')) return;
        var st = document.createElement('style');
        st.id = 'qe-paths-setup-css';
        st.textContent =
            '#qe_paths_modal_overlay{position:fixed;inset:0;background:rgba(15,23,42,.92);z-index:100000;display:flex;align-items:center;justify-content:center;padding:16px;font-family:system-ui,Segoe UI,sans-serif;overflow:auto;}' +
            '#qe_paths_modal_box{background:#1e293b;color:#e2e8f0;max-width:640px;width:100%;border-radius:14px;padding:22px 24px;border:1px solid #334155;margin:auto;}' +
            '#qe_paths_modal_box h2{margin:0 0 6px 0;font-size:1.15rem;color:#93c5fd;}' +
            '#qe_paths_modal_box .qe-sub{font-size:0.84rem;line-height:1.45;color:#94a3b8;margin:0 0 14px 0;}' +
            '#qe_paths_modal_box label{display:block;font-size:0.78rem;color:#94a3b8;margin:10px 0 3px;}' +
            '#qe_paths_modal_box input[type=text]{width:100%;box-sizing:border-box;padding:7px 10px;border-radius:8px;border:1px solid #475569;background:#0f172a;color:#f8fafc;font-size:0.82rem;font-family:ui-monospace,monospace;}' +
            '#qe_paths_detail{background:#0f172a;border:1px solid #334155;border-radius:10px;padding:12px 14px;margin:12px 0;font-size:0.8rem;line-height:1.55;max-height:280px;overflow:auto;}' +
            '#qe_paths_detail code{color:#a5b4fc;font-size:0.78rem;word-break:break-all;}' +
            '#qe_paths_detail .ok{color:#86efac;} #qe_paths_detail .ko{color:#fca5a5;}' +
            '#qe_paths_detail .row{display:grid;grid-template-columns:110px 1fr;gap:4px 10px;margin:4px 0;}' +
            '#qe_paths_modal_actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px;}' +
            '#qe_paths_modal_actions button{padding:9px 16px;border-radius:8px;border:none;cursor:pointer;font-weight:600;font-size:0.9rem;}' +
            '.qe_btn_primary{background:#0e7490;color:#fff;}' +
            '.qe_btn_ghost{background:#334155;color:#e2e8f0;}';
        document.head.appendChild(st);
    }

    function renderCheminsDetail(data) {
        if (!data) {
            return '<p class="ko">API non joignable — lancez <code>./DEMARRER.sh</code></p>';
        }
        var a = data.autonomie || {};
        var gens = data.generators || {};
        var d = data.dossiers || {};
        var html = '';
        html += '<div style="margin-bottom:8px;"><strong class="' + (a.ready ? 'ok' : 'ko') + '">' +
            qeEscapeHtml(a.message || ('Autonomie ' + (a.generators_ok || 0) + '/4')) +
            '</strong></div>';
        html += '<div class="row"><span>Projet</span><code>' + qeEscapeHtml(data.project_root || data.projet || '') + '</code></div>';
        html += '<div class="row"><span>Préfixe bin/</span><code>' + qeEscapeHtml(data.bin_dir || '') + '</code></div>';
        html += '<hr style="border:none;border-top:1px solid #334155;margin:10px 0;">';
        html += '<div style="color:#94a3b8;margin-bottom:4px;">Binaires (autonomie)</div>';
        ['ld1.x', 'ape', 'atompaw', 'oncvpsp.x', 'pw.x'].forEach(function (k) {
            var g = gens[k] || {};
            var mark = g.ok ? '<span class="ok">OK</span>' : '<span class="ko">—</span>';
            html += '<div class="row"><span>' + mark + ' ' + k + '</span><code>' +
                qeEscapeHtml(g.path || '(absent)') + '</code></div>';
            if (g.realpath && g.path && g.realpath !== g.path) {
                html += '<div class="row"><span style="opacity:.6;">↳ réel</span><code style="opacity:.75;">' +
                    qeEscapeHtml(g.realpath) + '</code></div>';
            }
        });
        html += '<hr style="border:none;border-top:1px solid #334155;margin:10px 0;">';
        html += '<div style="color:#94a3b8;margin-bottom:4px;">Dossiers sortie / travail</div>';
        var keys = [
            ['pseudos', 'Bibliothèque'],
            ['pseudos-ld1', 'Sortie ld1'],
            ['pseudos-APE', 'Sortie APE'],
            ['pseudos-atompaw', 'Sortie ATOMPAW'],
            ['pseudos-oncvpsp', 'Sortie ONCV'],
            ['pseudos_generes', 'Archive UPF'],
            ['_work', 'Travail (_work)'],
            ['logs', 'Logs'],
            ['templates', 'Templates']
        ];
        keys.forEach(function (pair) {
            var val = d[pair[0]] || data[pair[0]] || '';
            if (!val) return;
            html += '<div class="row"><span>' + pair[1] + '</span><code>' + qeEscapeHtml(val) + '</code></div>';
        });
        html += '<hr style="border:none;border-top:1px solid #334155;margin:10px 0;">';
        html += '<div class="row"><span>API</span><code>' + qeEscapeHtml(data.api_url || ('http://127.0.0.1:' + (data.api_port || 5008))) + '</code></div>';
        return html;
    }

    function openQEPathsWizard(force) {
        injectModalStyles();
        var existing = document.getElementById('qe_paths_modal_overlay');
        if (existing) existing.remove();

        var stored = window.loadUnifiedQEPathsFromStorage() || {};
        var o = document.createElement('div');
        o.id = 'qe_paths_modal_overlay';
        o.innerHTML =
            '<div id="qe_paths_modal_box">' +
            '<h2>Chemins sur ce PC</h2>' +
            '<p class="qe-sub">Interface <strong>100&nbsp;% autonome</strong> — les 4 générateurs vivent sous <code>./bin/</code> ' +
            '(ld1.x, ape, atompaw, oncvpsp.x). Source de vérité : <code>api_config.json</code> + <code>./configure.sh</code>. ' +
            'QE full n’est <em>pas</em> requis.</p>' +
            '<div id="qe_paths_detail"><em style="color:#64748b;">Chargement…</em></div>' +
            '<label>URL API (port 5008)</label>' +
            '<input type="text" id="qe_in_pseudosapi" value="http://127.0.0.1:5008" />' +
            '<label>Override dossier bin/ (optionnel — laisser vide = détection API)</label>' +
            '<input type="text" id="qe_in_qebin" placeholder="./bin du projet (recommandé)" />' +
            '<p class="qe-sub">Nouveau PC : <code>./scripts/vendor_generators.sh</code> → <code>./configure.sh -y</code> → <code>./DEMARRER.sh</code></p>' +
            '<div id="qe_paths_modal_actions">' +
            '<button type="button" class="qe_btn_primary" id="qe_paths_ok">Enregistrer</button>' +
            '<button type="button" class="qe_btn_ghost" id="qe_paths_reload">Recharger depuis l’API</button>' +
            (force ? '<button type="button" class="qe_btn_ghost" id="qe_paths_cancel">Fermer</button>' : '') +
            '</div></div>';
        document.body.appendChild(o);

        var detail = o.querySelector('#qe_paths_detail');
        var qb = o.querySelector('#qe_in_qebin');
        if (qb) qb.value = (window.QE_CONFIG && window.QE_CONFIG.QE_BIN_DIR) || stored.QE_BIN_DIR || '';
        var ps = o.querySelector('#qe_in_pseudosapi');
        if (ps) ps.value = stored.API_PSEUDOS_ORIGIN || window.API_PSEUDOS_ORIGIN || 'http://127.0.0.1:5008';

        function fillDetail(data) {
            if (detail) detail.innerHTML = renderCheminsDetail(data);
            if (data && data.bin_dir && qb && !qb.value) qb.value = data.bin_dir;
        }

        if (window.__CHEMINS_API__) {
            fillDetail(window.__CHEMINS_API__);
        }
        loadCheminsFromStandaloneApi().then(fillDetail);

        o.querySelector('#qe_paths_ok').onclick = function () {
            var qeb = (o.querySelector('#qe_in_qebin') || {}).value || '';
            var papi = (o.querySelector('#qe_in_pseudosapi') || {}).value || 'http://127.0.0.1:5008';
            window.applyUnifiedQEPaths({
                profile: 'standalone',
                QE_BIN_DIR: trimSlash(qeb),
                BIN_DIR: trimSlash(qeb),
                QE_API_PORT: 5008,
                API_PSEUDOS_ORIGIN: trimSlash(papi),
                schemaVersion: SCHEMA_VERSION
            });
            hideMismatchBanner();
            setTimeout(verifyStandaloneApi, 300);
            o.remove();
        };
        o.querySelector('#qe_paths_reload').onclick = function () {
            loadCheminsFromStandaloneApi().then(function (data) {
                fillDetail(data);
                if (data) {
                    var a = data.autonomie || {};
                    alert(
                        'Chemins rechargés.\n\n' +
                        (a.message || '') + '\n' +
                        'bin/ : ' + (data.bin_dir || '') + '\n' +
                        'pseudos : ' + (data.pseudos || '')
                    );
                } else {
                    alert('API non joignable — lancez ./DEMARRER.sh');
                }
            });
        };
        var cxl = o.querySelector('#qe_paths_cancel');
        if (cxl) cxl.onclick = function () { o.remove(); };
    }

    window.openQEPathsWizard = function (force) {
        openQEPathsWizard(!!force);
    };
    window.openStandaloneConfigWizard = window.openQEPathsWizard;

    // Bootstrap
    var saved = window.loadUnifiedQEPathsFromStorage();
    if (saved && (saved.profile === 'hiadsi' || Number(saved.schemaVersion || 0) < SCHEMA_VERSION)) {
        try { localStorage.removeItem(STORAGE_KEY); } catch (e) { /* ignore */ }
        saved = null;
    }
    if (saved && saved.profile === 'standalone') {
        window.applyUnifiedQEPaths(Object.assign({}, PRESET_STANDALONE, saved), { skipStorage: true });
    } else {
        window.applyUnifiedQEPaths(PRESET_STANDALONE, { skipStorage: true });
    }
    window.API_PSEUDOS_ORIGIN = resolvePseudosApiOrigin();
    window.GENERATION_PSEUDOS_API_ORIGIN = window.API_PSEUDOS_ORIGIN;
    setTimeout(verifyStandaloneApi, 400);
})();

#!/bin/bash
# Nettoie les artefacts locaux sans toucher à l’interface ni aux bibliothèques pseudos/.
# Usage : ./scripts/nettoyer_projet.sh [--work-only]

set -e
HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$HERE"

WORK_ONLY=0
[ "${1:-}" = "--work-only" ] && WORK_ONLY=1

echo "🧹 Nettoyage dans $HERE"
echo "   (interface inchangée — voir docs/CHEMINS_INTERFACE.md)"

# Ne jamais toucher aux chemins servis par Flask / fetch UI
PROTECT=(
  index.html pseudo_wizard.html
  oncv_default_14_Si.dat oncv_default_Cu.dat
  script_tableau_periodique.js script_generateur_ld1.js
  api_pseudos_standalone.py api_config.json
)

# PID / crash
rm -f api.pid server.pid CRASH parser.log input_tmp.in 2>/dev/null || true

# Cache Python
find "$HERE" -maxdepth 2 -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null || true

# Anciens runs APE/ATOMPAW/ONCV dans _work (garder .gitkeep)
if [ -d _work ]; then
  find _work -mindepth 1 -maxdepth 1 ! -name .gitkeep -exec rm -rf {} + 2>/dev/null || true
  touch _work/.gitkeep
  echo "  ✓ _work/ vidé (sauf .gitkeep)"
fi

# Sessions de travail sous les dossiers générateurs (régénérables)
for d in pseudos-oncvpsp/_work pseudos-ld1/_work pseudos-APE/_work pseudos-atompaw/_work; do
  if [ -d "$d" ]; then
    find "$d" -mindepth 1 -maxdepth 1 -exec rm -rf {} + 2>/dev/null || true
    echo "  ✓ $d vidé"
  fi
done

# Cache Python (tous niveaux utiles)
find "$HERE" -type d -name __pycache__ -not -path '*/third_party/*' -exec rm -rf {} + 2>/dev/null || true
find "$HERE" -type f -name '*.pyc' -not -path '*/third_party/*' -delete 2>/dev/null || true

if [ "$WORK_ONLY" = 1 ]; then
  echo "Terminé (--work-only)."
  exit 0
fi

# Archive historique (non lue par l’API — voir docs/ARCHIVE.md)
[ -d archive ] && rm -rf archive && echo "  ✓ archive/ supprimé"

# Cache téléchargements bibliothèques (contenu déjà dans pseudos/)
[ -d data/download_cache ] && rm -rf data/download_cache && echo "  ✓ data/download_cache/ supprimé"

# Anciens exports dist (garder le tarball le plus récent + binaire)
if [ -d dist ]; then
  ls -t dist/generation_pseudos_*.tar.gz 2>/dev/null | tail -n +2 | xargs -r rm -f
  ls -t dist/generation_pseudos_*_minimal.tar.gz 2>/dev/null | tail -n +2 | xargs -r rm -f
  echo "  ✓ dist/ — anciens tarballs retirés (dernier conservé)"
fi

# Logs secondaires (garder les JSON de validation / expertise)
rm -f logs/api_now.log logs/api_pseudos_*.log logs/download_*.log logs/server.log logs/telecharger_all.log 2>/dev/null || true
rm -f logs/*.log 2>/dev/null || true
# Ne pas supprimer les .json de validation
rm -f logs/api_pseudos_standalone.pid 2>/dev/null || true

# Dossiers vides / IDE
rm -rf .qodo web 2>/dev/null || true
rm -f logo_usto.png 2>/dev/null || true

# Ancien dossier commun (obsolète — les 4 dossiers pseudos-* par générateur)
if [ -d pseudos_generes ]; then
  find pseudos_generes -maxdepth 1 -type f \( -name '*.UPF' -o -name '*.upf' \) -delete 2>/dev/null || true
  touch pseudos_generes/.gitkeep
  echo "  ✓ pseudos_generes/ — UPF legacy retirés (voir pseudos-ld1, pseudos-APE, …)"
fi

# Anciennes sessions _runs (historique, pas requis par l’UI)
for d in pseudos-oncvpsp/_runs pseudos-ld1/_runs pseudos-APE/_runs pseudos-atompaw/_runs; do
  [ -d "$d" ] && find "$d" -mindepth 1 -maxdepth 1 -exec rm -rf {} + 2>/dev/null && echo "  ✓ $d vidé"
done

# Fichiers ld1 / test à la racine (liste blanche — pas les oncv_default_*.dat ni scripts)
for f in ld1.wfc ld1ps.wfc ld1.test vx.pot tmp_test_ge.UPF; do
  skip=0
  for p in "${PROTECT[@]}"; do [ "$f" = "$p" ] && skip=1; done
  [ "$skip" = 1 ] && continue
  [ -f "$f" ] && mkdir -p archive/root_misc && mv -f "$f" archive/root_misc/
done

echo "  ✓ artefacts racine / caches / _work"
echo "Non touché : index.html, scripts UI, bin/, third_party/, pseudos/ (bibliothèques), api_config.json"
echo "Terminé."

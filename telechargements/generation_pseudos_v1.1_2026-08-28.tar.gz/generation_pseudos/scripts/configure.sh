#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
#  configure.sh — Configuration sur un nouveau PC Linux
#  Génération des pseudopotentiels (interface autonome, port 5008)
# ═══════════════════════════════════════════════════════════════════════════════
#
#  Sur un autre PC, après copie du dossier :
#    ./scripts/vendor_generators.sh   # optionnel : copie ld1/oncv dans third_party/
#    ./configure.sh                   # une fois : chemins (QE optionnel)
#    ./DEMARRER.sh                    # à chaque utilisation
#
#  Usage :
#    ./configure.sh                         # interactif
#    ./configure.sh --qe ~/q-e-qe-7.5/bin   # QE optionnel
#    ./configure.sh --ld1 ./third_party/ld1/bin/ld1.x
#    ./configure.sh --check-only            # vérifie sans modifier api_config.json
#    ./configure.sh --start                 # configure puis lance ./DEMARRER.sh
#    ./configure.sh -y                      # valeurs par défaut sans questions
#
#  Options :
#    --qe PATH           Dossier bin/ QE optionnel (pw.x et/ou ld1.x)
#    --ld1 PATH          Binaire ld1.x (autonomie sans QE full)
#    --pseudos PATH      Bibliothèque UPF (défaut : ./pseudos)
#    --oncv PATH         Binaire oncvpsp.x
#    --ape PATH          Binaire ape
#    --atompaw PATH      Binaire atompaw
#    --port PORT         Port API (défaut : 5008)
#    --check-only        Diagnostic uniquement
#    --start             Démarre l’API après configuration
#    -y, --yes           Mode non interactif (détection auto)
#    -h, --help          Aide
#
# ═══════════════════════════════════════════════════════════════════════════════
set -euo pipefail

# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
cd "$SCRIPT_DIR"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

QE_BIN=""
LD1_BIN=""
PSEUDOS_DIR=""
ONCV_BIN=""
APE_BIN=""
ATOMPAW_BIN=""
API_PORT=5008
CHECK_ONLY=0
DO_START=0
ASSUME_YES=0

usage() {
    sed -n '6,30p' "$0" | sed 's/^# //'
    exit 0
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --qe) QE_BIN="${2:-}"; shift 2 ;;
        --ld1) LD1_BIN="${2:-}"; shift 2 ;;
        --pseudos) PSEUDOS_DIR="${2:-}"; shift 2 ;;
        --oncv) ONCV_BIN="${2:-}"; shift 2 ;;
        --ape) APE_BIN="${2:-}"; shift 2 ;;
        --atompaw) ATOMPAW_BIN="${2:-}"; shift 2 ;;
        --port) API_PORT="${2:-}"; shift 2 ;;
        --check-only) CHECK_ONLY=1; shift ;;
        --start) DO_START=1; shift ;;
        -y|--yes) ASSUME_YES=1; shift ;;
        -h|--help) usage ;;
        *) echo -e "${RED}Option inconnue : $1${NC}"; usage ;;
    esac
done

hr() { echo -e "${CYAN}────────────────────────────────────────────────────────${NC}"; }
ok() { echo -e "   ${GREEN}✅ $*${NC}"; }
warn() { echo -e "   ${YELLOW}⚠️  $*${NC}"; }
err() { echo -e "   ${RED}❌ $*${NC}"; exit 1; }

echo -e "${CYAN}${BOLD}"
echo "╔═══════════════════════════════════════════════════════╗"
echo "║  configure.sh — Autonomie 4 générateurs (QE optionnel)║"
echo "╚═══════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo "   Projet : $SCRIPT_DIR"
echo ""

# Vendor local si demandé / disponible
if [[ "$CHECK_ONLY" -eq 0 && -x "$SCRIPT_DIR/scripts/vendor_generators.sh" ]]; then
    bash "$SCRIPT_DIR/scripts/vendor_generators.sh" || true
fi

# ── Python / Flask ───────────────────────────────────────────────────────────
hr
echo -e "${BOLD}Python${NC}"
command -v python3 >/dev/null || err "python3 introuvable (sudo apt install python3 python3-pip)"
ok "python3 $(python3 --version 2>&1 | awk '{print $2}')"
if ! python3 -c "import flask" 2>/dev/null; then
    if [[ "$CHECK_ONLY" -eq 1 ]]; then
        warn "flask absent — pip install flask flask-cors"
    else
        echo "   Installation flask / flask-cors…"
        python3 -m pip install --user flask flask-cors 2>/dev/null \
            || python3 -m pip install --break-system-packages flask flask-cors 2>/dev/null \
            || pip3 install --user flask flask-cors \
            || pip3 install flask flask-cors
        ok "Flask installé"
    fi
else
    ok "Flask OK"
fi

# ── Dossiers projet ──────────────────────────────────────────────────────────
hr
echo -e "${BOLD}Dossiers de sortie (4 générateurs)${NC}"
GEN_DIRS=(pseudos-ld1 pseudos-APE pseudos-atompaw pseudos-oncvpsp)
OTHER_DIRS=(pseudos pseudos-telecharges logs _work)
if [[ "$CHECK_ONLY" -eq 0 ]]; then
    for d in "${GEN_DIRS[@]}"; do
        mkdir -p "$SCRIPT_DIR/$d/_runs"
        touch "$SCRIPT_DIR/$d/.gitkeep" 2>/dev/null || true
    done
    for d in pseudos pseudos-telecharges logs _work data/oncv; do
        mkdir -p "$SCRIPT_DIR/$d"
    done
    mkdir -p "$SCRIPT_DIR/pseudo_generator_templates/ape" "$SCRIPT_DIR/pseudo_generator_templates/atompaw"
    touch _work/.gitkeep 2>/dev/null || true
fi
for d in "${GEN_DIRS[@]}"; do
    [[ -d "$SCRIPT_DIR/$d" ]] && ok "$d/" || warn "$d/ manquant"
done

# ── ld1.x + pw.x (canonique : ./bin) ─────────────────────────────────────────
hr
echo -e "${BOLD}Exécutables locaux (./bin)${NC}"
if [[ -z "$LD1_BIN" ]]; then
    for candidate in \
        "$SCRIPT_DIR/bin/ld1.x" \
        "$SCRIPT_DIR/third_party/qe/bin/ld1.x" \
        "$(command -v ld1.x 2>/dev/null)" \
        "$HOME/q-e-qe-7.5/bin/ld1.x" \
        "$HOME/q-e-qe-7.5/atomic/src/ld1.x"; do
        [[ -n "$candidate" && -f "$candidate" ]] && LD1_BIN="$candidate" && break
    done
fi
if [[ -n "$LD1_BIN" && -f "$LD1_BIN" ]]; then
    LD1_BIN="$(readlink -f "$LD1_BIN" 2>/dev/null || echo "$LD1_BIN")"
    ok "ld1.x → $LD1_BIN"
else
    warn "ld1.x absent — scripts/vendor_generators.sh"
    LD1_BIN=""
fi

hr
echo -e "${BOLD}Dossier QE (= ./bin si ld1/pw présents)${NC}"
if [[ -z "$QE_BIN" ]]; then
    for candidate in \
        "$SCRIPT_DIR/bin" \
        "$SCRIPT_DIR/third_party/qe/bin" \
        "$(dirname "$(command -v pw.x 2>/dev/null)" 2>/dev/null)" \
        "$HOME/q-e-qe-7.5/bin"; do
        [[ -n "$candidate" && ( -f "$candidate/pw.x" || -f "$candidate/ld1.x" ) ]] && QE_BIN="$candidate" && break
    done
fi
if [[ -z "$QE_BIN" && "$ASSUME_YES" -eq 0 && "$CHECK_ONLY" -eq 0 ]]; then
    read -rp "   Chemin bin/ QE optionnel (Entrée = ignorer) : " QE_BIN
fi
if [[ -n "$QE_BIN" && ( -f "$QE_BIN/pw.x" || -f "$QE_BIN/ld1.x" ) ]]; then
    QE_BIN="$(cd "$QE_BIN" && pwd)"
    ok "QE_BIN=$QE_BIN"
    for prog in pw.x ld1.x; do
        [[ -f "$QE_BIN/$prog" ]] && echo -e "      ✔ $prog" || warn "$prog absent"
    done
    if [[ -z "$LD1_BIN" && -f "$QE_BIN/ld1.x" ]]; then
        LD1_BIN="$(readlink -f "$QE_BIN/ld1.x")"
        ok "ld1.x via QE_BIN → $LD1_BIN"
    fi
else
    warn "QE_BIN vide — OK si bin/ld1.x existe"
    QE_BIN=""
fi

# ── Bibliothèque pseudos ─────────────────────────────────────────────────────
if [[ -z "$PSEUDOS_DIR" ]]; then
    PSEUDOS_DIR="${GEN_PSEUDOS_INSTALL:-$SCRIPT_DIR}/pseudos"
    if [[ -d "$SCRIPT_DIR/pseudos" && "$SCRIPT_DIR/pseudos" != "$PSEUDOS_DIR" ]]; then
        PSEUDOS_DIR="$SCRIPT_DIR/pseudos"
    fi
    [[ -L "$SCRIPT_DIR/pseudos" ]] && PSEUDOS_DIR="$(readlink -f "$SCRIPT_DIR/pseudos" 2>/dev/null || echo "$PSEUDOS_DIR")"
fi
[[ "$CHECK_ONLY" -eq 0 ]] && mkdir -p "$PSEUDOS_DIR"
ok "Bibliothèque UPF : $PSEUDOS_DIR"

# ── Binaires générateurs (third_party en priorité) ───────────────────────────
hr
echo -e "${BOLD}Générateurs (APE · ATOMPAW · ONCVPSP)${NC}"

_detect_bin() {
    local name="$1" var="$2" default="$3"
    local val="${!var}"
    if [[ -z "$val" ]]; then
        if [[ -x "$default" ]]; then
            val="$default"
        elif command -v "$name" >/dev/null 2>&1; then
            val="$(command -v "$name")"
        fi
    fi
    if [[ -n "$val" && -x "$val" ]]; then
        printf -v "$var" '%s' "$(readlink -f "$val" 2>/dev/null || echo "$val")"
        ok "$name → ${!var}"
        return 0
    fi
    warn "$name non trouvé (onglet correspondant limité)"
    printf -v "$var" '%s' ""
    return 1
}

_detect_bin oncvpsp.x ONCV_BIN "$SCRIPT_DIR/bin/oncvpsp.x"
[[ -z "$ONCV_BIN" && -x "$SCRIPT_DIR/third_party/oncvpsp/bin/oncvpsp.x" ]] && ONCV_BIN="$SCRIPT_DIR/third_party/oncvpsp/bin/oncvpsp.x" && ok "oncvpsp.x → $ONCV_BIN"
[[ -z "$ONCV_BIN" && -x "$HOME/oncvpsp/build/bin/oncvpsp.x" ]] && ONCV_BIN="$HOME/oncvpsp/build/bin/oncvpsp.x" && ok "oncvpsp.x → $ONCV_BIN"
ONCV_ROOT="${ONCV_ROOT:-}"
if [[ -z "$ONCV_ROOT" ]]; then
    if [[ -d "$SCRIPT_DIR/data/oncvpsp_tests_data" ]]; then
        ONCV_ROOT="$SCRIPT_DIR"   # templates via data/ ; binaire dans bin/
    elif [[ -d "$SCRIPT_DIR/third_party/oncvpsp" ]]; then
        ONCV_ROOT="$SCRIPT_DIR/third_party/oncvpsp"
    elif [[ -d "$HOME/oncvpsp" ]]; then
        ONCV_ROOT="$HOME/oncvpsp"
    fi
fi
_detect_bin ape APE_BIN "$SCRIPT_DIR/bin/ape"
[[ -z "$APE_BIN" ]] && _detect_bin ape APE_BIN "$SCRIPT_DIR/third_party/ape/bin/ape"
_detect_bin atompaw ATOMPAW_BIN "$SCRIPT_DIR/bin/atompaw"
[[ -z "$ATOMPAW_BIN" ]] && _detect_bin atompaw ATOMPAW_BIN "$SCRIPT_DIR/third_party/atompaw/bin/atompaw"

# ── api_config.json ──────────────────────────────────────────────────────────
CFG="$SCRIPT_DIR/api_config.json"
EXAMPLE="$SCRIPT_DIR/api_config.local.json.example"

if [[ "$CHECK_ONLY" -eq 1 ]]; then
    hr
    echo -e "${BOLD}Vérification interface${NC}"
    bash "$SCRIPT_DIR/scripts/verifier_chemins_ui.sh" || true
    echo ""
    echo -e "${GREEN}Diagnostic terminé (--check-only).${NC}"
    exit 0
fi

hr
echo -e "${BOLD}api_config.json${NC}"
if [[ ! -f "$CFG" && -f "$EXAMPLE" ]]; then
    cp "$EXAMPLE" "$CFG"
    echo "   Créé depuis api_config.local.json.example"
fi
[[ ! -f "$CFG" ]] && echo '{}' > "$CFG"

export CFG QE_BIN LD1_BIN PSEUDOS_DIR ONCV_BIN APE_BIN ATOMPAW_BIN ONCV_ROOT
python3 <<'PY'
import json, os
cfg_path = os.environ["CFG"]
with open(cfg_path, encoding="utf-8") as f:
    cfg = json.load(f)
mapping = {
    "qe_bin": os.environ.get("QE_BIN") or "",
    "ld1_bin": os.environ.get("LD1_BIN") or "",
    "pseudos_dir": os.environ.get("PSEUDOS_DIR") or "",
    "oncvpsp_bin": os.environ.get("ONCV_BIN") or "",
    "oncvpsp_root": os.environ.get("ONCV_ROOT") or "",
    "ape_bin": os.environ.get("APE_BIN") or "",
    "atompaw_bin": os.environ.get("ATOMPAW_BIN") or "",
}
for key, val in mapping.items():
    if val:
        cfg[key] = val
# Prefer ./bin as canonical install prefix
root = os.path.dirname(cfg_path)
local_bin = os.path.join(root, "bin")
if os.path.isfile(os.path.join(local_bin, "ld1.x")):
    cfg["qe_bin"] = local_bin
    cfg["ld1_bin"] = os.path.join(local_bin, "ld1.x")
if os.path.isfile(os.path.join(local_bin, "oncvpsp.x")):
    cfg["oncvpsp_bin"] = os.path.join(local_bin, "oncvpsp.x")
if os.path.isfile(os.path.join(local_bin, "ape")) or os.path.islink(os.path.join(local_bin, "ape")):
    cfg["ape_bin"] = os.path.join(local_bin, "ape")
if os.path.isfile(os.path.join(local_bin, "atompaw")) or os.path.islink(os.path.join(local_bin, "atompaw")):
    cfg["atompaw_bin"] = os.path.join(local_bin, "atompaw")
# oncvpsp_root : templates projet
if os.path.isdir(os.path.join(root, "data", "oncvpsp_tests_data")):
    cfg["oncvpsp_root"] = root
elif os.path.isdir(os.path.join(root, "third_party", "oncvpsp")):
    cfg["oncvpsp_root"] = os.path.join(root, "third_party", "oncvpsp")
cfg.setdefault("oncv_default_target", "qe")
cfg["qe_optional"] = True
cfg["autonomie_4gen"] = True
with open(cfg_path, "w", encoding="utf-8") as f:
    json.dump(cfg, f, indent=2, ensure_ascii=False)
    f.write("\n")
print("   api_config.json mis à jour (préfixe bin/)")
for k, v in sorted(cfg.items()):
    if v and (str(k).endswith("_bin") or k in ("qe_bin", "pseudos_dir", "ld1_bin", "oncvpsp_root")):
        print(f"      {k}: {v}")
n = sum(1 for k in ("ld1_bin", "ape_bin", "atompaw_bin", "oncvpsp_bin") if cfg.get(k))
pw = os.path.isfile(os.path.join(cfg.get("qe_bin") or "", "pw.x"))
print(f"   Autonomie générateurs : {n}/4  |  pw.x dans bin/ : {'oui' if pw else 'non'}")
PY

# ── Vérification chemins UI ──────────────────────────────────────────────────
hr
echo -e "${BOLD}Fichiers interface${NC}"
bash "$SCRIPT_DIR/scripts/verifier_chemins_ui.sh"

# ── Résumé ───────────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}${BOLD}✅ Configuration terminée${NC}"
echo ""
echo "   Dossiers de génération :"
echo "     pseudos-ld1/      → ld1.x"
echo "     pseudos-APE/      → APE"
echo "     pseudos-atompaw/  → ATOMPAW"
echo "     pseudos-oncvpsp/  → ONCVPSP"
echo ""
echo "   Lancement : ./DEMARRER.sh"
echo "   Interface : http://127.0.0.1:${API_PORT}/"
echo "   Config    : $CFG"
echo ""

if [[ "$DO_START" -eq 1 ]]; then
    export GEN_PORT="$API_PORT"
    export QE_BIN
    export SKIP_LEGACY_API=1
    echo -e "${BOLD}── Démarrage API ──${NC}"
    exec bash "$SCRIPT_DIR/scripts/DEMARRER.sh"
fi

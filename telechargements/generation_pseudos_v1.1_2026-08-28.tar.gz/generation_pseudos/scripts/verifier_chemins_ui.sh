#!/bin/bash
# Vérifie que les fichiers requis par l'interface existent (sans lancer le navigateur).
set -e
HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$HERE"
fail=0
check() {
  if [ -e "$1" ]; then echo "OK  $1"; else echo "MANQUE  $1"; fail=1; fi
}
check bin/ld1.x
check bin/oncvpsp.x
check bin/ape
check bin/atompaw
check api_config.json
check qe_paths_setup.js
check config_chemins.js
check index.html
check script_tableau_periodique.js
check script_generateur_ld1.js
check script_generateur_ape_atompaw.js
check oncv_default_Cu.dat
check oncv_default_14_Si.dat
check oncv_templates_3d/Ni.dat
check pseudo_generator_templates
for d in pseudos-ld1 pseudos-APE pseudos-atompaw pseudos-oncvpsp; do
  check "$d/.gitkeep"
done
check _work/.gitkeep
[ "$fail" = 0 ] && echo "→ Chemins UI + bin/ autonomie OK." || { echo "→ Corrigez avant ./DEMARRER.sh"; exit 1; }

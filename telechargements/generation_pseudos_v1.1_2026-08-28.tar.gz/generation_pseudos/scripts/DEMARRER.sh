#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
#  Générateur de pseudopotentiels — interface AUTONOME
#  ==================================================
#  Lance l’API standalone (interface + ld1 + générateurs) sur le port 5008.
#  Ouvrir : http://127.0.0.1:5008/  (ne pas utiliser file:// sur index.html)
#
#  Variables :
#    GEN_PORT                 port API (défaut 5008)
#    QE_BIN                   dossier bin/ QE optionnel (pw.x / ld1.x)
#    LD1_BIN                  binaire ld1.x (autonomie sans QE full)
#    SKIP_LEGACY_API=0        lancer aussi Interface-QE sur 5007 (optionnel)
#    INTERFACE_QE_DIR         racine Interface-QE_v1 si legacy activé
#    ONCVPSP_BIN, ONCVPSP_ROOT, APE_BIN, ATOMPAW_BIN
# ─────────────────────────────────────────────────────────────────────────────
set -e

# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
cd "$HERE"

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'; RED='\033[0;31m'; NC='\033[0m'

GEN_PORT="${GEN_PORT:-5008}"
# Par défaut : standalone seul (pas de dépendance Interface-QE / port 5007)
SKIP_LEGACY_API="${SKIP_LEGACY_API:-1}"
LEGACY_PORT="${QE_API_PORT:-5007}"
GEN_URL="http://127.0.0.1:${GEN_PORT}/"
LEGACY_URL="http://127.0.0.1:${LEGACY_PORT}/pseudos-interface/"
IQE_DIR="${INTERFACE_QE_DIR:-$HOME/Interface-QE_v1}"

hr() { printf '%s\n' "────────────────────────────────────────────────────────────"; }

# ─── Binaires (api_config.json + chemins usuels) ───────────────────────────
_load_bin_from_config() {
    local key="$1" varname="$2"
    [ -f "$HERE/api_config.json" ] || return 0
    local v
    v=$(python3 -c "import json;print(json.load(open('$HERE/api_config.json')).get('$key','') or '')" 2>/dev/null || true)
    if [ -n "$v" ] && [ -z "${!varname:-}" ]; then
        export "$varname=$v"
    fi
}
_load_bin_from_config oncvpsp_bin ONCVPSP_BIN
_load_bin_from_config oncvpsp_root ONCVPSP_ROOT
_load_bin_from_config ape_bin APE_BIN
_load_bin_from_config atompaw_bin ATOMPAW_BIN
_load_bin_from_config ld1_bin LD1_BIN
_load_bin_from_config qe_bin QE_BIN

if [ -z "${LD1_BIN:-}" ]; then
    for _ld in "$HERE/bin/ld1.x" "$HERE/third_party/qe/bin/ld1.x"; do
        [ -x "$_ld" ] && export LD1_BIN="$_ld" && break
    done
fi

if [ -z "${QE_BIN:-}" ]; then
    for _qe in "$HERE/bin" "$HERE/third_party/qe/bin" "$HOME/q-e-qe-7.5/bin"; do
        if [ -f "$_qe/pw.x" ] || [ -f "$_qe/ld1.x" ]; then
            export QE_BIN="$_qe"
            break
        fi
    done
fi

if [ -z "${ONCVPSP_BIN:-}" ]; then
    for _oc in "$HERE/bin/oncvpsp.x" "$HERE/third_party/oncvpsp/bin/oncvpsp.x" "$HOME/oncvpsp/build/bin/oncvpsp.x"; do
        if [ -x "$_oc" ]; then export ONCVPSP_BIN="$_oc"; break; fi
    done
fi
[ -z "${ONCVPSP_ROOT:-}" ] && [ -d "$HERE/data/oncvpsp_tests_data" ] && export ONCVPSP_ROOT="$HERE"
[ -z "${ONCVPSP_ROOT:-}" ] && [ -d "$HERE/third_party/oncvpsp" ] && export ONCVPSP_ROOT="$HERE/third_party/oncvpsp"
[ -z "${APE_BIN:-}" ] && [ -x "$HERE/bin/ape" ] && export APE_BIN="$HERE/bin/ape"
[ -z "${APE_BIN:-}" ] && [ -x "$HERE/third_party/ape/bin/ape" ] && export APE_BIN="$HERE/third_party/ape/bin/ape"
[ -z "${ATOMPAW_BIN:-}" ] && [ -x "$HERE/bin/atompaw" ] && export ATOMPAW_BIN="$HERE/bin/atompaw"
[ -z "${ATOMPAW_BIN:-}" ] && [ -x "$HERE/third_party/atompaw/bin/atompaw" ] && export ATOMPAW_BIN="$HERE/third_party/atompaw/bin/atompaw"

echo -e "${CYAN}Générateur de pseudopotentiels — interface autonome (4 gén.)${NC}"
echo -e "${CYAN}    Port ${GEN_PORT} — ld1 · APE · ATOMPAW · ONCV · bibliothèques${NC}"
echo -e "${CYAN}    QE full optionnel (pw.x non requis pour générer)${NC}"
[ "${SKIP_LEGACY_API}" != "1" ] && echo -e "${CYAN}    + legacy Interface-QE port ${LEGACY_PORT} (optionnel)${NC}"
[ -n "${LD1_BIN:-}" ] && echo -e "${CYAN}    LD1_BIN : ${LD1_BIN}${NC}"
[ -n "${ONCVPSP_BIN:-}" ] && echo -e "${CYAN}    ONCVPSP_BIN : ${ONCVPSP_BIN}${NC}"
echo

PY="$(command -v python3 || command -v python)"
if [ -z "$PY" ]; then
    echo -e "${RED}❌ Python 3 introuvable.${NC}" >&2
    exit 1
fi

# ═══════════════════════════════════════════════════════════════════════════
#  [1/2] API legacy Interface-QE (port 5007)
# ═══════════════════════════════════════════════════════════════════════════
LEGACY_OK=0
if [ "${SKIP_LEGACY_API:-}" = "1" ]; then
    echo -e "${YELLOW}[1/2] API 5007 ignorée (SKIP_LEGACY_API=1)${NC}"
else
    echo -e "${CYAN}[1/2] API Interface-QE (port ${LEGACY_PORT})…${NC}"
    ASSURE="$IQE_DIR/scripts/assure_api_qe.sh"
    if [ ! -f "$ASSURE" ]; then
        echo -e "${YELLOW}   ⚠️  Interface-QE_v1 introuvable : ${IQE_DIR}${NC}"
        echo -e "${YELLOW}   → Seul le port ${GEN_PORT} sera utilisé (générateur autonome).${NC}"
    else
        set +e
        QE_API_PORT="$LEGACY_PORT" ONCVPSP_BIN="${ONCVPSP_BIN:-}" ONCVPSP_ROOT="${ONCVPSP_ROOT:-}" \
            bash "$ASSURE"
        _aq=$?
        set -e
        if [ "$_aq" -eq 0 ]; then
            LEGACY_OK=1
            echo -e "${GREEN}   ✅ API ${LEGACY_PORT} en ligne${NC}"
        else
            echo -e "${YELLOW}   ⚠️  API ${LEGACY_PORT} non démarrée (voir logs dans ${IQE_DIR}/logs/)${NC}"
        fi
    fi
fi
echo

# ═══════════════════════════════════════════════════════════════════════════
#  [2/2] API générateur autonome (port 5008)
# ═══════════════════════════════════════════════════════════════════════════
echo -e "${CYAN}[2/2] API générateur autonome (port ${GEN_PORT})…${NC}"

EXPECTED_BUILD_TAG=$(grep -m1 '^API_BUILD_TAG' "$HERE/api_pseudos_standalone.py" | sed -E 's/.*"([^"]+)".*/\1/')
echo -e "${CYAN}    Build attendu : ${EXPECTED_BUILD_TAG}${NC}"

rm -rf "$HERE/__pycache__" 2>/dev/null || true

if ! "$PY" -c "import flask, flask_cors" 2>/dev/null; then
    if [ -f "$HERE/requirements.txt" ]; then
        echo -e "${YELLOW}⚠️  Dépendances Python manquantes — installation via requirements.txt…${NC}"
        "$PY" -m pip install --user --quiet -r "$HERE/requirements.txt" 2>/dev/null \
        || "$PY" -m pip install --break-system-packages --quiet -r "$HERE/requirements.txt" 2>/dev/null \
        || "$PY" -m pip install --user --quiet -r "$HERE/requirements.txt" || {
            echo -e "${RED}❌ pip install -r requirements.txt a échoué.${NC}" >&2
            exit 1
        }
    else
        echo -e "${YELLOW}⚠️  Dépendances Python manquantes — installation…${NC}"
        "$PY" -m pip install --user --quiet flask flask-cors 2>/dev/null \
            || "$PY" -m pip install --break-system-packages --quiet flask flask-cors 2>/dev/null \
            || "$PY" -m pip install --user --quiet flask flask-cors || {
            echo -e "${RED}❌ pip install a échoué.${NC}" >&2
            exit 1
        }
    fi
fi

_free_port_if_stale() {
    local port="$1"
    local pid=""
    if command -v lsof >/dev/null 2>&1; then
        pid=$(lsof -ti:"$port" 2>/dev/null | head -1 || true)
    fi
    [ -z "$pid" ] && return 0
    local tag=""
    if command -v curl >/dev/null 2>&1; then
        tag=$(curl -fsS --max-time 2 "http://127.0.0.1:${port}/api/pseudos/version" 2>/dev/null \
            | sed -n 's/.*"build_tag"[ ]*:[ ]*"\([^"]*\)".*/\1/p' || true)
    fi
    if [ -n "$tag" ] && [ "$tag" = "$EXPECTED_BUILD_TAG" ]; then
        echo -e "${GREEN}   ✅ Port ${port} déjà à jour (build_tag OK)${NC}"
        return 2
    fi
    echo -e "${YELLOW}   Port ${port} occupé (PID ${pid}) — redémarrage…${NC}"
    kill "$pid" 2>/dev/null || true
    sleep 0.5
    kill -9 "$pid" 2>/dev/null || true
    sleep 0.2
    return 0
}

_stale=$(_free_port_if_stale "$GEN_PORT") || true
if [ "${_stale:-0}" -eq 2 ]; then
    GEN_PID=$(lsof -ti:"$GEN_PORT" 2>/dev/null | head -1 || echo "?")
else
    mkdir -p "$HERE/logs" \
        "$HERE/pseudos-oncvpsp" "$HERE/pseudos-ld1" "$HERE/pseudos-APE" \
        "$HERE/pseudos-atompaw" "$HERE/pseudos-telecharges" "$HERE/pseudos_generes"
    LOG="$HERE/logs/api_pseudos_standalone.log"
    echo -e "${CYAN}   ▶️  ${PY} api_pseudos_standalone.py --port ${GEN_PORT}${NC}"
    QE_ARGS=()
    [ -n "${QE_BIN:-}" ] && { [ -f "${QE_BIN}/pw.x" ] || [ -f "${QE_BIN}/ld1.x" ]; } && QE_ARGS=(--qe "$QE_BIN")
    LD1_ARGS=()
    [ -n "${LD1_BIN:-}" ] && [ -f "${LD1_BIN}" ] && LD1_ARGS=(--ld1 "$LD1_BIN")
    nohup env ONCVPSP_BIN="${ONCVPSP_BIN:-}" ONCVPSP_ROOT="${ONCVPSP_ROOT:-}" \
        APE_BIN="${APE_BIN:-}" ATOMPAW_BIN="${ATOMPAW_BIN:-}" \
        LD1_BIN="${LD1_BIN:-}" QE_BIN="${QE_BIN:-}" \
        "$PY" "$HERE/api_pseudos_standalone.py" --port "$GEN_PORT" "${QE_ARGS[@]}" "${LD1_ARGS[@]}" \
        > "$LOG" 2>&1 &
    GEN_PID=$!
    echo "$GEN_PID" > "$HERE/logs/api_pseudos_standalone.pid"

    for i in $(seq 1 40); do
        sleep 0.25
        if command -v curl >/dev/null 2>&1; then
            curl -fsS "http://127.0.0.1:${GEN_PORT}/api/pseudos/version" -o /dev/null 2>/dev/null && break
        fi
        kill -0 "$GEN_PID" 2>/dev/null || {
            echo -e "${RED}❌ API ${GEN_PORT} arrêtée — voir ${LOG}${NC}" >&2
            tail -n 30 "$LOG" 2>/dev/null >&2 || true
            exit 1
        }
    done
fi

GEN_OK=0
if command -v curl >/dev/null 2>&1; then
    curl -fsS --max-time 3 "http://127.0.0.1:${GEN_PORT}/health" -o /dev/null 2>/dev/null && GEN_OK=1
fi
[ "$GEN_OK" -eq 1 ] && echo -e "${GREEN}   ✅ API ${GEN_PORT} en ligne (PID ${GEN_PID:-?})${NC}" \
    || echo -e "${RED}   ❌ API ${GEN_PORT} ne répond pas${NC}"

echo
hr
echo -e "${CYAN}Résumé des APIs${NC}"

_ping() {
    local url="$1"
    curl -fsS --connect-timeout 2 --max-time 4 "$url" -o /dev/null 2>/dev/null
}

if [ "$LEGACY_OK" -eq 1 ] || _ping "http://127.0.0.1:${LEGACY_PORT}/health"; then
    echo -e "  ${GREEN}✅${NC} Port ${LEGACY_PORT} — Interface-QE (chemins, ld1, téléchargements)"
    echo -e "       ${LEGACY_URL}"
else
    echo -e "  ${YELLOW}⚠️${NC}  Port ${LEGACY_PORT} — hors ligne (optionnel si vous utilisez seulement ${GEN_PORT})"
fi

if [ "$GEN_OK" -eq 1 ]; then
    echo -e "  ${GREEN}✅${NC} Port ${GEN_PORT} — Générateur APE · ATOMPAW · ONCVPSP · UPF QE"
    echo -e "       ${GEN_URL}"
    if command -v curl >/dev/null 2>&1; then
        ONCV_AV=$(curl -fsS --max-time 3 "http://127.0.0.1:${GEN_PORT}/api/pseudos/oncv_status" 2>/dev/null \
            | sed -n 's/.*"available"[ ]*:[ ]*\(true\|false\).*/\1/p' || true)
        if [ "$ONCV_AV" = "true" ]; then
            echo -e "       ${GREEN}oncvpsp.x détecté par l’API${NC}"
        elif [ -n "$ONCV_AV" ]; then
            echo -e "       ${YELLOW}oncvpsp.x non signalé — vérifiez api_config.json / ONCVPSP_BIN${NC}"
        fi
    fi
else
    echo -e "  ${RED}❌${NC} Port ${GEN_PORT} — échec (voir logs/api_pseudos_standalone.log)"
fi

hr
echo -e "Vérification API : ${CYAN}python3 ${HERE}/verifier_api_generale.py${NC}"
echo -e "Arrêt complet    : ${CYAN}./ARRETER.sh${NC}  (5008 + 5007)"
echo -e "Logs 5008        : ${HERE}/logs/api_pseudos_standalone.log"
echo

OPEN_URL="${GEN_URL}"
if [ "${OPEN_LEGACY_UI:-}" = "1" ] && [ "$LEGACY_OK" -eq 1 ]; then
    OPEN_URL="${LEGACY_URL}"
fi

for b in firefox xdg-open google-chrome chromium-browser; do
    if command -v "$b" >/dev/null 2>&1; then
        DISPLAY="${DISPLAY:-:0}" nohup "$b" "$OPEN_URL" > /dev/null 2>&1 &
        echo -e "${GREEN}✅ Navigateur : ${OPEN_URL}${NC}"
        exit 0
    fi
done

echo -e "${YELLOW}Ouvrez : ${OPEN_URL}${NC}"
exit 0

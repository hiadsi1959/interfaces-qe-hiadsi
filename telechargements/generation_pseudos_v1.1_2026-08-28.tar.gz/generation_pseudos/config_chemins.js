// Configuration des chemins — interface autonome generation_pseudos (port 5008)
// Source de vérité : /api/chemins → préfixe ./bin/ (ld1, ape, atompaw, oncvpsp)
(function() {
    'use strict';

    window.QE_API_PORT = 5008;
    window.QE_API_URL = 'http://127.0.0.1:5008';
    if (typeof window.API_PSEUDOS_ORIGIN === 'undefined') {
        window.API_PSEUDOS_ORIGIN = 'http://127.0.0.1:5008';
    }
    if (typeof window.GENERATION_PSEUDOS_API_ORIGIN === 'undefined') {
        window.GENERATION_PSEUDOS_API_ORIGIN = window.API_PSEUDOS_ORIGIN;
    }

    if (!window.QE_CONFIG || !window.QE_CONFIG.QE_BIN_DIR) {
        window.QE_CONFIG = Object.assign(window.QE_CONFIG || {}, {
            WORK_DIR: '',
            INPUTS_DIR: '',
            OUTPUTS_DIR: '',
            PSEUDO_DIR: '',
            CIF_DIR: '',
            QE_BIN_DIR: '',
            BIN_DIR: '',
            LD1_BIN: '',
            APE_BIN: '',
            ATOMPAW_BIN: '',
            ONCVPSP_BIN: '',
            AUTO_REFRESH_INTERVAL: 3000,
            AUTO_START_API: false
        });
    }

    function applyPayload(data) {
        if (!data) return false;
        var root = (data.project_root || data.projet || data.work_dir || '').replace(/\/+$/, '');
        var binDir = (data.bin_dir || data.qe_bin || '').replace(/\/+$/, '');
        if (root) {
            window.QE_CONFIG.WORK_DIR = root;
            window.QE_CONFIG.PROJECT_MAIN = root;
        }
        if (binDir) {
            window.QE_CONFIG.QE_BIN_DIR = binDir;
            window.QE_CONFIG.BIN_DIR = binDir;
        }
        if (data.ld1_bin) window.QE_CONFIG.LD1_BIN = data.ld1_bin;
        if (data.pw_bin) window.QE_CONFIG.PW_BIN = data.pw_bin;
        if (data.ape_bin) window.QE_CONFIG.APE_BIN = data.ape_bin;
        if (data.atompaw_bin) window.QE_CONFIG.ATOMPAW_BIN = data.atompaw_bin;
        if (data.oncvpsp_bin) window.QE_CONFIG.ONCVPSP_BIN = data.oncvpsp_bin;
        if (data.pseudos) window.QE_CONFIG.PSEUDO_DIR = data.pseudos;
        if (data.inputs) window.QE_CONFIG.INPUTS_DIR = data.inputs;
        if (data.outputs) window.QE_CONFIG.OUTPUTS_DIR = data.outputs;
        if (data.tmp) window.QE_CONFIG.TMP_DIR = data.tmp;
        var d = data.dossiers || {};
        if (d['pseudos-ld1']) {
            window.QE_CONFIG.LD1_INPUTS_DIR = d['pseudos-ld1'];
            window.QE_CONFIG.PSEUDO_GENERES_DIR = d['pseudos-ld1'];
        }
        window.__CHEMINS_API__ = data;
        window.__AUTONOMIE__ = data.autonomie || null;
        console.log('✅ Chemins chargés depuis l’API:', binDir || '(bin/)',
            data.autonomie ? ('autonomie ' + data.autonomie.score_pct + '%') : '');
        return true;
    }

    window.detecterCheminsAuto = async function() {
        var base = (typeof getApiPseudosGenerationBase === 'function')
            ? getApiPseudosGenerationBase()
            : (window.API_PSEUDOS_ORIGIN || 'http://127.0.0.1:5008');
        try {
            var response = await fetch(base.replace(/\/+$/, '') + '/api/chemins', { cache: 'no-store' });
            if (response.ok) {
                var data = await response.json();
                return applyPayload(data);
            }
        } catch (error) {
            console.warn('⚠️ API non joignable — lancez ./DEMARRER.sh ou ./GenerationPseudos');
        }
        return false;
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            window.detecterCheminsAuto();
        });
    } else {
        window.detecterCheminsAuto();
    }
})();

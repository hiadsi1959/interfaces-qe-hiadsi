# -*- coding: utf-8 -*-
"""Catalogue assistant guidé : types de pseudo × calculs × générateurs (par élément)."""

from __future__ import annotations

from typing import Any

try:
    from pseudo_auto_inputs import normalize_symbol, atomic_number, qe_route_hint
    from pseudo_auto_inputs import _TRANSITION_3D
except ImportError:
    _TRANSITION_3D = frozenset()

    def normalize_symbol(s: str) -> str:
        s = (s or "").strip()
        return s.upper() if len(s) == 1 else (s[0].upper() + s[1:].lower() if s else "")

    def atomic_number(sym: str) -> int:
        return 0

    def qe_route_hint(sym: str) -> dict[str, Any]:
        return {"message": "", "recommended_generators": []}


# Types de calcul affichés dans le catalogue
CALCUL_TYPES: list[dict[str, str]] = [
    {"id": "electronique", "label": "Électronique", "sous": "SCF / bandes / DOS (pw.x)"},
    {"id": "optique", "label": "Optique", "sous": "ε(ω) / absorption (epsilon.x)"},
    {"id": "phonons", "label": "Phonons", "sous": "DFPT (ph.x / matdyn.x)"},
    {"id": "dynamique", "label": "Dynamique", "sous": "Car–Parrinello (cp.x)"},
    {"id": "wannier", "label": "Wannier", "sous": "pw2wannier90 / Wannier90"},
    {"id": "magnetisme", "label": "Magnétisme", "sous": "nspin=2 / DFT+U"},
    {"id": "xanes", "label": "XANES", "sous": "xspectra.x"},
    {"id": "gw", "label": "GW / TDDFT", "sous": "GW, BSE, TDDFT"},
    {"id": "neb", "label": "NEB", "sous": "Barrières (neb.x)"},
]

# Générateurs locaux + bibliothèques (« Autres bases »)
# category: local | library
GENERATORS_BY_PSEUDO: dict[str, list[dict[str, str]]] = {
    "NC": [
        {"id": "ape", "name": "APE", "mode": "génération locale", "category": "local"},
        {"id": "oncvpsp", "name": "ONCVPSP", "mode": "génération locale (.dat)", "category": "local"},
        {"id": "ld1", "name": "ld1.x", "mode": "pseudotype=1", "category": "local"},
        {"id": "pseudodojo", "name": "PseudoDojo", "mode": "bibliothèque NC (import)", "category": "library"},
        {"id": "sg15", "name": "SG15", "mode": "bibliothèque ONCV NC (Schlipf–Gygi)", "category": "library"},
        {"id": "sssp", "name": "SSSP", "mode": "bibliothèque Materials Cloud (import)", "category": "library"},
        {"id": "pslibrary", "name": "PSLibrary", "mode": "bibliothèque QE — jeux NC", "category": "library"},
    ],
    "USPP": [
        {"id": "ld1", "name": "ld1.x", "mode": "pseudotype=2", "category": "local"},
        {"id": "pslibrary", "name": "PSLibrary", "mode": "bibliothèque QE USPP (Dal Corso)", "category": "library"},
        {"id": "gbrv", "name": "GBRV", "mode": "bibliothèque USPP (Rutgers)", "category": "library"},
        {"id": "sssp", "name": "SSSP", "mode": "bibliothèque Materials Cloud (import)", "category": "library"},
    ],
    "PAW": [
        {"id": "atompaw", "name": "ATOMPAW", "mode": "génération locale PAW", "category": "local"},
        {"id": "ld1", "name": "ld1.x", "mode": "pseudotype=3", "category": "local"},
        {"id": "pslibrary", "name": "PSLibrary", "mode": "bibliothèque QE PAW (Dal Corso)", "category": "library"},
        {"id": "sssp", "name": "SSSP", "mode": "bibliothèque Materials Cloud (import)", "category": "library"},
    ],
}

# Fiche pédagogique des « Autres bases » (onglet du même nom)
AUTRES_BASES: list[dict[str, Any]] = [
    {
        "id": "pslibrary",
        "name": "PSLibrary",
        "pseudo_types": ["NC", "USPP", "PAW"],
        "utilisation": "Référence QE (Dal Corso) — SCF, phonons, magnétisme, XANES (PAW)",
        "site": "https://pseudopotentials.quantum-espresso.org",
        "wizard_gen": "pslibrary",
        "tab": "pslibrary",
    },
    {
        "id": "pseudodojo",
        "name": "PseudoDojo",
        "pseudo_types": ["NC"],
        "utilisation": "NC haute précision (ONCVPSP) — GW, optique, Wannier, cp.x ; standard & stringent",
        "site": "https://www.pseudo-dojo.org/",
        "wizard_gen": "pseudodojo",
        "tab": "pseudodojo",
    },
    {
        "id": "sssp",
        "name": "SSSP",
        "pseudo_types": ["NC", "USPP", "PAW"],
        "utilisation": "Sélection curatée Materials Cloud (Efficiency / Precision) — SCF / bandes prêts à l’emploi",
        "site": "https://www.materialscloud.org/discover/sssp/table",
        "wizard_gen": "sssp",
        "tab": "sssp",
    },
    {
        "id": "gbrv",
        "name": "GBRV",
        "pseudo_types": ["USPP"],
        "utilisation": "USPP Vanderbilt (Rutgers) — oxydes, métaux de transition, basse ecutwfc",
        "site": "https://www.physics.rutgers.edu/gbrv/",
        "wizard_gen": "gbrv",
        "tab": "autresbases",
    },
    {
        "id": "sg15",
        "name": "SG15",
        "pseudo_types": ["NC"],
        "utilisation": "ONCVPSP NC (Schlipf–Gygi) — calculs multi-codes, GW / optique",
        "site": "http://www.quantum-simulation.org/potentials/sg15_oncv/",
        "wizard_gen": "sg15",
        "tab": "autresbases",
    },
]

PSEUDO_META: dict[str, dict[str, str]] = {
    "NC": {
        "label": "Norm-Conserving (NC)",
        "short": "NC",
        "desc": "Léger, transfertabilité élevée ; souvent requis pour GW / optique / cp.x.",
    },
    "USPP": {
        "label": "Ultrasoft (USPP)",
        "short": "USPP",
        "desc": "Basse coupure ecutwfc ; robuste pour métaux et phonons.",
    },
    "PAW": {
        "label": "Projector Augmented Wave (PAW)",
        "short": "PAW",
        "desc": "Haute précision (cœur reconstruit) ; XANES, 3d/4f, SOC.",
    },
}

# Recommandations spécifiques élément (écrasent la famille)
_ELEMENT_OVERRIDES: dict[str, dict[str, dict[str, str]]] = {
    "H": {"default": {"type": "NC", "fonct": "PBE", "source": "PseudoDojo", "cutoff": "80 Ry", "note": "Léger — NC suffisant"}},
    "Li": {"default": {"type": "NC", "fonct": "PBE", "source": "PseudoDojo", "cutoff": "80 Ry", "note": "USPP si calcul magnétique"}},
    "Fe": {
        "default": {"type": "USPP", "fonct": "PBE", "source": "PSLibrary / ld1", "cutoff": "70 Ry", "note": "3d — USPP efficace"},
        "optique": {"type": "PAW", "fonct": "PBE", "source": "ATOMPAW / PSLibrary", "cutoff": "80 Ry", "note": "PAW pour ε(ω) précis"},
        "magnetisme": {"type": "USPP", "fonct": "PBE", "source": "PSLibrary / ld1", "cutoff": "80 Ry", "note": "USPP + nspin=2"},
    },
    "Co": {"default": {"type": "USPP", "fonct": "PBE", "source": "PSLibrary / ld1", "cutoff": "70 Ry", "note": "3d magnétique"}},
    "Ni": {"default": {"type": "USPP", "fonct": "PBE", "source": "PSLibrary / ld1", "cutoff": "70 Ry", "note": "3d — USPP stable"}},
    "Cu": {"default": {"type": "USPP", "fonct": "PBE", "source": "PSLibrary / ld1", "cutoff": "70 Ry", "note": "Attention 3d¹⁰"}},
    "Ga": {"default": {"type": "USPP", "fonct": "PBE", "source": "PSLibrary", "cutoff": "60 Ry", "note": "Semi-cœur 3d"}},
    "Ge": {"default": {"type": "USPP", "fonct": "PBE", "source": "PSLibrary", "cutoff": "70 Ry", "note": "Semi-cœur 3d recommandé"}},
    "Pb": {
        "default": {"type": "PAW", "fonct": "PBE", "source": "PSLibrary / ATOMPAW", "cutoff": "100 Ry", "note": "SOC fort"},
        "phonons": {"type": "PAW", "fonct": "PBE", "source": "PSLibrary", "cutoff": "100 Ry", "note": "ph.x + SOC"},
    },
    "Bi": {"default": {"type": "PAW", "fonct": "PBEsol", "source": "PSLibrary", "cutoff": "100 Ry", "note": "SOC fort requis"}},
    "Tl": {"default": {"type": "PAW", "fonct": "PBE", "source": "PSLibrary", "cutoff": "100 Ry", "note": "SOC fort"}},
    "Hg": {"default": {"type": "PAW", "fonct": "PBE", "source": "PSLibrary", "cutoff": "100 Ry", "note": "Semi-cœur 5d"}},
    "U": {"default": {"type": "PAW", "fonct": "PBE+U", "source": "PSLibrary / ATOMPAW", "cutoff": "120 Ry", "note": "DFT+U pour 5f"}},
    "Pu": {"default": {"type": "PAW", "fonct": "PBE+U", "source": "PSLibrary / ATOMPAW", "cutoff": "120 Ry", "note": "f corrélés"}},
}

# Règles famille × calcul
_FAMILY_CALCUL: dict[str, dict[str, dict[str, str]]] = {
    "electronique": {
        "non-metal": {"type": "NC", "fonct": "PBE", "source": "PseudoDojo / SSSP", "cutoff": "80 Ry", "note": "NC optimal SCF/bandes"},
        "metal-alcalin": {"type": "USPP", "fonct": "PBE", "source": "PSLibrary / SSSP", "cutoff": "50 Ry", "note": "USPP efficace"},
        "metal-alcalino-terreux": {"type": "USPP", "fonct": "PBE", "source": "PSLibrary / SSSP", "cutoff": "60 Ry", "note": "USPP recommandé"},
        "metal-transition": {"type": "USPP", "fonct": "PBE", "source": "ld1 / ATOMPAW / PSLibrary", "cutoff": "70 Ry", "note": "USPP ou PAW pour électrons d"},
        "metal": {"type": "USPP", "fonct": "PBE", "source": "PSLibrary", "cutoff": "50 Ry", "note": "Efficace et rapide"},
        "metalloid": {"type": "NC", "fonct": "PBE", "source": "PseudoDojo", "cutoff": "80 Ry", "note": "NC précis"},
        "halogene": {"type": "NC", "fonct": "PBE", "source": "PseudoDojo", "cutoff": "100 Ry", "note": "Cutoff élevé"},
        "gaz-noble": {"type": "NC", "fonct": "PBE", "source": "PseudoDojo", "cutoff": "60 Ry", "note": "NC suffisant"},
        "lanthanide": {"type": "PAW", "fonct": "PBE+U", "source": "ATOMPAW / PSLibrary", "cutoff": "100 Ry", "note": "4f — DFT+U conseillé"},
        "actinide": {"type": "PAW", "fonct": "PBE+U", "source": "ATOMPAW / PSLibrary", "cutoff": "120 Ry", "note": "5f — DFT+U requis"},
        "_default": {"type": "USPP", "fonct": "PBE", "source": "SSSP", "cutoff": "70 Ry", "note": "SSSP Efficiency"},
    },
    "optique": {
        "_default": {"type": "NC", "fonct": "PBE", "source": "PseudoDojo / ONCVPSP", "cutoff": "100 Ry", "note": "epsilon.x exige NC"},
        "metal-transition": {"type": "NC", "fonct": "PBE", "source": "PseudoDojo / ONCVPSP", "cutoff": "120 Ry", "note": "NC + grille k dense"},
        "lanthanide": {"type": "NC", "fonct": "PBE", "source": "PseudoDojo / ONCVPSP", "cutoff": "130 Ry", "note": "NC open-core ou semi-cœur f"},
        "actinide": {"type": "NC", "fonct": "PBE", "source": "PseudoDojo", "cutoff": "140 Ry", "note": "NC relativiste"},
    },
    "phonons": {
        "_default": {"type": "USPP", "fonct": "PBE", "source": "PSLibrary / ld1", "cutoff": "70 Ry", "note": "ph.x : USPP/PAW OK"},
        "non-metal": {"type": "NC", "fonct": "PBE", "source": "PseudoDojo", "cutoff": "80 Ry", "note": "NC précis pour phonons"},
        "metal-transition": {"type": "USPP", "fonct": "PBE", "source": "PSLibrary / ld1", "cutoff": "80 Ry", "note": "USPP stable ph.x"},
        "lanthanide": {"type": "PAW", "fonct": "PBE", "source": "ATOMPAW", "cutoff": "120 Ry", "note": "PAW pour phonons f"},
        "actinide": {"type": "PAW", "fonct": "PBE", "source": "ATOMPAW", "cutoff": "130 Ry", "note": "PAW requis"},
    },
    "dynamique": {
        "_default": {"type": "NC", "fonct": "PBE", "source": "PseudoDojo / APE", "cutoff": "80 Ry", "note": "cp.x : NC uniquement"},
        "metal-transition": {"type": "NC", "fonct": "PBE", "source": "ONCVPSP / PseudoDojo", "cutoff": "100 Ry", "note": "cp.x NC"},
        "lanthanide": {"type": "NC", "fonct": "PBE", "source": "ONCVPSP / PseudoDojo", "cutoff": "120 Ry", "note": "cp.x NC open-core"},
    },
    "wannier": {
        "_default": {"type": "NC", "fonct": "PBE", "source": "PseudoDojo / ONCVPSP", "cutoff": "80 Ry", "note": "NC recommandé"},
        "metal-transition": {"type": "USPP", "fonct": "PBE", "source": "PSLibrary", "cutoff": "80 Ry", "note": "USPP si Wannierisation standard"},
    },
    "xanes": {
        "_default": {"type": "PAW", "fonct": "PBE", "source": "ATOMPAW / PSLibrary", "cutoff": "100 Ry", "note": "xspectra.x : PAW obligatoire"},
    },
    "gw": {
        "_default": {"type": "NC", "fonct": "PBE", "source": "PseudoDojo / ONCVPSP", "cutoff": "120 Ry", "note": "GW : NC de qualité"},
        "metal-transition": {"type": "NC", "fonct": "PBE", "source": "PseudoDojo / ONCVPSP", "cutoff": "150 Ry", "note": "NC + semi-cœur d"},
    },
    "neb": {
        "_default": {"type": "USPP", "fonct": "PBE", "source": "PSLibrary / SSSP", "cutoff": "70 Ry", "note": "Comme électronique"},
    },
    "magnetisme": {
        "metal-transition": {"type": "USPP", "fonct": "PBE", "source": "ld1 / PSLibrary", "cutoff": "80 Ry", "note": "USPP + nspin=2"},
        "lanthanide": {"type": "PAW", "fonct": "PBE+U", "source": "ATOMPAW", "cutoff": "120 Ry", "note": "PAW + DFT+U + SOC"},
        "_default": {"type": "USPP", "fonct": "PBE", "source": "PSLibrary / ld1", "cutoff": "70 Ry", "note": "USPP recommandé"},
    },
}

# Générateur local préféré pour un type de pseudo (sélection wizard)
_PREFERRED_LOCAL_GEN: dict[str, str] = {
    "NC": "ape",
    "USPP": "ld1",
    "PAW": "atompaw",
}


def element_family(sym: str) -> dict[str, Any]:
    """Famille chimique pour les règles de recommandation."""
    sym_n = normalize_symbol(sym)
    z = atomic_number(sym_n)
    try:
        import lanthanide_nc as lnc

        if lnc.is_lanthanide(sym_n):
            return {"id": "lanthanide", "label": "Lanthanide (4f)", "Z": z}
    except ImportError:
        if 57 <= z <= 71:
            return {"id": "lanthanide", "label": "Lanthanide (4f)", "Z": z}

    if 89 <= z <= 103:
        return {"id": "actinide", "label": "Actinide (5f)", "Z": z}
    if sym_n in _TRANSITION_3D or (21 <= z <= 30) or (39 <= z <= 48) or (72 <= z <= 80):
        return {"id": "metal-transition", "label": "Métal de transition", "Z": z}
    if z in (3, 11, 19, 37, 55, 87):
        return {"id": "metal-alcalin", "label": "Métal alcalin", "Z": z}
    if z in (4, 12, 20, 38, 56, 88):
        return {"id": "metal-alcalino-terreux", "label": "Alcalino-terreux", "Z": z}
    if z in (5, 14, 32, 33, 51, 52):
        return {"id": "metalloid", "label": "Métalloïde", "Z": z}
    if z in (9, 17, 35, 53, 85):
        return {"id": "halogene", "label": "Halogène", "Z": z}
    if z in (2, 10, 18, 36, 54, 86):
        return {"id": "gaz-noble", "label": "Gaz noble", "Z": z}
    # Métaux simples (Al, etc.) vs non-métaux
    if z in (13, 31, 49, 50, 81, 82, 83, 84):
        return {"id": "metal", "label": "Métal (bloc p)", "Z": z}
    if z <= 20 or z in (6, 7, 8, 15, 16, 34):
        return {"id": "non-metal", "label": "Non-métal", "Z": z}
    return {"id": "_default", "label": "Général", "Z": z}


def _recommendation(sym: str, family_id: str, calcul_id: str) -> dict[str, str]:
    ov = _ELEMENT_OVERRIDES.get(sym) or {}
    if calcul_id in ov:
        return dict(ov[calcul_id])
    if "default" in ov and calcul_id == "electronique":
        return dict(ov["default"])
    # pour les autres calculs : override élément default seulement si pas de règle calcul
    fam_map = _FAMILY_CALCUL.get(calcul_id) or {}
    if family_id in fam_map:
        return dict(fam_map[family_id])
    if "_default" in fam_map:
        base = dict(fam_map["_default"])
        if "default" in ov and calcul_id not in ("optique", "dynamique", "gw", "xanes"):
            # conserver type élément pour NEB / magnetisme si pertinent
            if calcul_id in ("neb",) and ov["default"].get("type"):
                base = dict(ov["default"])
        return base
    if "default" in ov:
        return dict(ov["default"])
    return {
        "type": "USPP",
        "fonct": "PBE",
        "source": "PSLibrary / SSSP",
        "cutoff": "70 Ry",
        "note": "Recommandation générale",
    }


def _preferred_generator(pseudo_type: str, family_id: str, route: dict[str, Any]) -> dict[str, str]:
    """Choix de générateur local / bibliothèque pour ce type de pseudo."""
    gens = GENERATORS_BY_PSEUDO.get(pseudo_type) or []
    reco = [g.lower() for g in (route.get("recommended_generators") or [])]

    # Priorité : générateurs recommandés pour l'élément ∩ type de pseudo
    for g in reco:
        for row in gens:
            if row["id"] == g or (g in ("ld1.x", "ld1x") and row["id"] == "ld1"):
                return dict(row)

    # Familles denses : éviter APE pour NC
    if pseudo_type == "NC" and family_id in ("metal-transition", "lanthanide", "actinide"):
        for pref in ("oncvpsp", "pseudodojo", "ld1"):
            for row in gens:
                if row["id"] == pref:
                    return dict(row)

    if pseudo_type == "PAW":
        for row in gens:
            if row["id"] == "atompaw":
                return dict(row)

    pref_id = _PREFERRED_LOCAL_GEN.get(pseudo_type, "ld1")
    for row in gens:
        if row["id"] == pref_id:
            return dict(row)
    return dict(gens[0]) if gens else {"id": "ld1", "name": "ld1.x", "mode": ""}


def _ape_note(sym: str) -> tuple[str, str]:
    try:
        from generator_guide import ape_feasibility

        feas = ape_feasibility(sym)
    except Exception:
        feas = "caution"
    note = {
        "recommended": "Adapté à cet élément",
        "caution": "À tester pour cet élément",
        "blocked": "Souvent instable ici — préférer ONCVPSP / PseudoDojo",
    }.get(feas, "")
    return feas, note


def _wizard_gen_id(gen_id: str, ptype: str) -> str:
    """Identifiant pour ouvrir le bon onglet UI."""
    g = (gen_id or "").strip().lower()
    if g in ("ape", "atompaw", "ld1", "oncvpsp", "pseudodojo", "pslibrary", "sssp"):
        return g
    if g in ("gbrv", "sg15"):
        return g
    if ptype == "NC":
        return "pseudodojo"
    if ptype == "PAW":
        return "atompaw"
    return "ld1"


def _tab_for_generator(gen_id: str) -> str:
    g = (gen_id or "").strip().lower()
    if g == "ld1":
        return "ld1x"
    if g in ("gbrv", "sg15"):
        return "autresbases"
    if g in ("ape", "atompaw", "oncvpsp", "pslibrary", "pseudodojo", "sssp"):
        return g
    return "autresbases"


def _autres_bases_rows(fam: dict[str, Any], default_type: str) -> list[dict[str, Any]]:
    """Lignes dédiées aux bibliothèques de l'onglet Autres bases."""
    fam_id = (fam or {}).get("id") or "_default"
    rows: list[dict[str, Any]] = []
    for b in AUTRES_BASES:
        types = b.get("pseudo_types") or []
        rec = default_type in types
        note = ""
        if fam_id == "metal-transition" and b["id"] in ("gbrv", "pslibrary", "sssp"):
            note = "Souvent pertinent pour les métaux de transition"
            rec = True
        if fam_id == "lanthanide" and b["id"] in ("pseudodojo", "sssp", "pslibrary"):
            note = "Préférable à une génération NC locale fragile"
            rec = True
        rows.append(
            {
                "pseudo_type": " / ".join(types),
                "pseudo_types": list(types),
                "pseudo_label": "Bibliothèque — " + ", ".join(types),
                "generator_id": b["id"],
                "generator_name": b["name"],
                "generator_mode": "Autres bases (import UPF)",
                "generator_note": note,
                "utilisation": b.get("utilisation") or "",
                "utilisation_detail": b.get("utilisation") or "",
                "site": b.get("site") or "",
                "recommended": rec,
                "wizard_gen": b.get("wizard_gen") or b["id"],
                "tab": b.get("tab") or "autresbases",
                "category": "library",
            }
        )
    return rows


def build_element_catalog(sym: str) -> dict[str, Any]:
    """
    Catalogue : type_pseudo | type_generateur | utilisation
    Inclut générateurs locaux + Autres bases (PSLibrary, PseudoDojo, SSSP, GBRV, SG15).
    """
    sym_n = normalize_symbol(sym)
    z = atomic_number(sym_n)
    fam = element_family(sym_n)
    route = qe_route_hint(sym_n)

    by_calcul: list[dict[str, Any]] = []
    calculs_by_pseudo: dict[str, list[dict[str, str]]] = {"NC": [], "USPP": [], "PAW": []}

    for ct in CALCUL_TYPES:
        rec = _recommendation(sym_n, fam["id"], ct["id"])
        ptype = (rec.get("type") or "USPP").upper()
        if ptype == "US":
            ptype = "USPP"
        pref = _preferred_generator(ptype, fam["id"], route)
        row = {
            "calcul_id": ct["id"],
            "calcul_label": ct["label"],
            "calcul_sous": ct["sous"],
            "pseudo_type": ptype,
            "pseudo_label": PSEUDO_META.get(ptype, {}).get("label", ptype),
            "fonct": rec.get("fonct", "PBE"),
            "cutoff": rec.get("cutoff", ""),
            "source": rec.get("source", ""),
            "note": rec.get("note", ""),
            "generator": pref,
            "generators": list(GENERATORS_BY_PSEUDO.get(ptype) or []),
            "wizard_gen": _wizard_gen_id(pref["id"], ptype),
        }
        by_calcul.append(row)
        if ptype in calculs_by_pseudo:
            calculs_by_pseudo[ptype].append(
                {"id": ct["id"], "label": ct["label"], "sous": ct["sous"]}
            )

    default_rec = _recommendation(sym_n, fam["id"], "electronique")
    default_type = (default_rec.get("type") or "USPP").upper()
    if default_type == "US":
        default_type = "USPP"

    ape_feas, ape_note = _ape_note(sym_n)

    rows: list[dict[str, Any]] = []
    rows_local: list[dict[str, Any]] = []
    rows_library: list[dict[str, Any]] = []
    by_pseudo: list[dict[str, Any]] = []

    for ptype in ("NC", "USPP", "PAW"):
        meta = PSEUDO_META[ptype]
        calcs = calculs_by_pseudo.get(ptype) or []
        utilisation = (
            ", ".join(c["label"] for c in calcs)
            if calcs
            else "Peu recommandé pour les calculs listés sur cet élément"
        )
        utilisation_detail = (
            "; ".join(f"{c['label']} ({c['sous']})" for c in calcs) if calcs else meta["desc"]
        )
        gens_out: list[dict[str, Any]] = []
        for g in GENERATORS_BY_PSEUDO[ptype]:
            g2 = dict(g)
            if g2["id"] == "ape":
                g2["feasibility"] = ape_feas
                g2["note"] = ape_note
            gens_out.append(g2)
            row = {
                "pseudo_type": ptype,
                "pseudo_label": meta["label"],
                "generator_id": g2["id"],
                "generator_name": g2["name"],
                "generator_mode": g2.get("mode") or "",
                "generator_note": g2.get("note") or "",
                "utilisation": utilisation,
                "utilisation_detail": utilisation_detail,
                "recommended": ptype == default_type,
                "wizard_gen": _wizard_gen_id(g2["id"], ptype),
                "category": g2.get("category") or "local",
                "tab": _tab_for_generator(g2["id"]),
            }
            rows.append(row)
            if row["category"] == "library":
                rows_library.append(row)
            else:
                rows_local.append(row)
        pref = _preferred_generator(ptype, fam["id"], route)
        by_pseudo.append(
            {
                "pseudo_type": ptype,
                "label": meta["label"],
                "short": meta["short"],
                "desc": meta["desc"],
                "recommended": ptype == default_type,
                "calculs": calcs,
                "utilisation": utilisation,
                "generators": gens_out,
                "preferred_generator": pref,
                "wizard_gen": _wizard_gen_id(pref["id"], ptype),
            }
        )

    autres = _autres_bases_rows(fam, default_type)

    return {
        "element": sym_n,
        "Z": z,
        "family": fam,
        "default_pseudo_type": default_type,
        "default_recommendation": default_rec,
        "route_message": route.get("message") or "",
        "recommended_generators": route.get("recommended_generators") or [],
        "columns": ["type_pseudo", "type_generateur", "utilisation"],
        "rows": rows,
        "rows_local": rows_local,
        "rows_library": rows_library,
        "autres_bases": autres,
        "by_pseudo": by_pseudo,
        "by_calcul": by_calcul,
        "legend": {
            "NC": PSEUDO_META["NC"]["desc"],
            "USPP": PSEUDO_META["USPP"]["desc"],
            "PAW": PSEUDO_META["PAW"]["desc"],
        },
    }

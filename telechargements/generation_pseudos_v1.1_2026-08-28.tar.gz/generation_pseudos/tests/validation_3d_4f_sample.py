#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Échantillon 3d / 4f — test des 4 générateurs (ld1, APE, ATOMPAW, ONCVPSP).

  python3 tests/validation_3d_4f_sample.py
  python3 tests/validation_3d_4f_sample.py Ti Fe La
"""
from __future__ import annotations

import json
import os
import re
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

_CLI = [a for a in sys.argv[1:] if not a.startswith("-") and re.match(r"^[A-Za-z]{1,3}$", a)]
_saved = sys.argv[:]
sys.argv = ["api_pseudos_standalone", "--port", "5008"]
import api_pseudos_standalone as api  # noqa: E402
sys.argv = _saved

import pseudo_auto_inputs as pai  # noqa: E402

# Échantillon représentatif
SAMPLE_3D = ["Ti", "Fe", "Ni"]
SAMPLE_4F = ["La", "Ce", "Gd"]
DEFAULT = SAMPLE_3D + SAMPLE_4F

FAMILLE = {
    "Ti": "3d (début)",
    "Fe": "3d (milieu)",
    "Ni": "3d (fin)",
    "Cu": "3d (anomalie)",
    "La": "4f (La, open-core)",
    "Ce": "4f (Ce, f¹)",
    "Gd": "4f (Gd, f⁷)",
    "Nd": "4f (Nd)",
}

Z = {
    "Ti": 22, "Fe": 26, "Ni": 28, "Cu": 29,
    "La": 57, "Ce": 58, "Nd": 60, "Gd": 64,
}


def _zval(path: str | None) -> float | None:
    if not path or not os.path.isfile(path):
        return None
    try:
        txt = Path(path).read_text(encoding="utf-8", errors="replace")[:8000]
        m = re.search(r"z_valence\s*=\s*([0-9.]+)", txt, re.I)
        if m:
            return float(m.group(1))
    except OSError:
        pass
    return None


def _fresh(path: str | None, t0: float) -> bool:
    if not path or not os.path.isfile(path):
        return False
    return os.path.getmtime(path) >= (t0 - 1.0)


def _score(j: dict, upf: str | None, t0: float) -> dict:
    upf = upf or j.get("upf_path") or ""
    qv = {}
    if upf and hasattr(api, "_validate_upf_qe"):
        qv = api._validate_upf_qe(upf)
    rc = j.get("returncode")
    ok_api = bool(j.get("success"))
    fresh = _fresh(upf, t0)
    conform = bool(qv.get("conform_qe") or j.get("upf_qe_ready"))
    ok_sci = ok_api and fresh and conform and (rc is None or rc == 0)
    size = os.path.getsize(upf) if upf and os.path.isfile(upf) else 0
    err = (j.get("error") or j.get("hint") or j.get("diagnostic_summary") or "")[:180]
    return {
        "success": ok_api,
        "ok_scientifique": ok_sci,
        "fresh_upf": fresh,
        "conform_qe": conform,
        "upf_path": upf,
        "z_valence": _zval(upf),
        "size_kb": round(size / 1024, 1) if size else 0,
        "error": err,
        "returncode": rc,
    }


def _oncv_input(client, element: str, z: int) -> str:
    # Lanthanides : gabarit dédié
    try:
        import lanthanide_nc as lnc
        if lnc.is_lanthanide(element):
            return lnc.generate_oncv_dat(element, f_treatment="open_core", xc="gga_pbe", psfile="both")
    except Exception:
        pass
    # Fichiers locaux
    for cand in [
        ROOT / "data" / "oncvpsp_tests_data" / f"{z}_{element}.dat",
        ROOT / "oncv_templates_3d" / f"{element}.dat",
        ROOT / f"oncv_default_{element}.dat",
    ]:
        if cand.is_file():
            return cand.read_text(encoding="utf-8")
    for p in ROOT.glob("data/**/*.dat"):
        if element.lower() in p.name.lower() and (str(z) in p.name or element.lower() in p.stem.lower()):
            return p.read_text(encoding="utf-8")
    r = client.get(f"/api/pseudos/oncv_input_template?element={element}&z={z}")
    if r.status_code == 200:
        txt = r.data.decode("utf-8", errors="replace")
        head = "\n".join(txt.splitlines()[:12]).lower()
        if re.search(rf"\b{element.lower()}\b", head):
            return txt
    # Fallback auto via lanthanide_nc / auto_inputs
    r2 = client.get(f"/api/pseudos/auto_inputs?element={element}&xc=gga_pbe")
    j = r2.get_json() or {}
    return (j.get("oncv_input_dat") or "").strip()


def run_one(client, element: str) -> dict:
    fam = FAMILLE.get(element, "?")
    print(f"\n{'=' * 72}\n  {element}  ({fam})\n{'=' * 72}", flush=True)
    out: dict = {}
    z = Z.get(element, pai.atomic_number(element))
    is_4f = element in SAMPLE_4F or (57 <= z <= 71)
    is_3d = element in SAMPLE_3D or element in pai._TRANSITION_3D

    # --- ld1 ---
    t0 = time.time()
    print("  → ld1.x …", flush=True)
    try:
        ld1_in = pai.generate_ld1_input(
            element, dft="PBE", semicore=True,
            f_treatment="open_core" if is_4f else None,
        )
        resp = client.post("/api/pseudos/generer_ld1", json={"element": element, "input": ld1_in})
        j = resp.get_json() or {}
        upf = j.get("upf_path") or ""
        if not upf and j.get("upf_genere") and j.get("pseudos_dir"):
            upf = str(Path(j["pseudos_dir"]) / j["upf_genere"])
        row = _score(j, upf, t0)
    except Exception as e:
        row = {"success": False, "ok_scientifique": False, "error": str(e)[:180],
               "fresh_upf": False, "conform_qe": False, "z_valence": None, "size_kb": 0, "upf_path": ""}
    row["dt_s"] = round(time.time() - t0, 1)
    out["ld1.x"] = row
    _print_row(row)

    # --- APE ---
    t0 = time.time()
    print("  → APE …", flush=True)
    body = {
        "element": element, "auto_generate": True, "xc": "lda_pw",
        "relativistic": True, "semicore": True,
        "rc_scale": 1.25 if (is_3d or is_4f) else 1.0,
    }
    if is_4f:
        body["f_treatment"] = "open_core"
    resp = client.post("/api/pseudos/run_ape", json=body)
    j = resp.get_json() or {}
    wd = j.get("work_dir") or j.get("continue_dir") or j.get("run_dir")
    hint = ((j.get("hint") or "") + (j.get("error") or "")).lower()
    if (not j.get("success")) and wd and ("continue" in hint or "étape ae" in hint or "ae" in hint):
        print(f"     (ae→pp continue {wd})", flush=True)
        resp = client.post("/api/pseudos/run_ape", json={
            "element": element, "continue_dir": wd, "auto_generate": False, "xc": "lda_pw",
        })
        j = resp.get_json() or {}
    row = _score(j, j.get("upf_path"), t0)
    row["dt_s"] = round(time.time() - t0, 1)
    out["APE"] = row
    _print_row(row)

    # --- ATOMPAW ---
    t0 = time.time()
    print("  → ATOMPAW …", flush=True)
    body = {
        "element": element, "auto_generate": True, "format": "interactive",
        "relativistic": True, "semicore": True,
    }
    if is_4f:
        body["f_treatment"] = "open_core"
    resp = client.post("/api/pseudos/run_atompaw", json=body)
    j = resp.get_json() or {}
    row = _score(j, j.get("upf_path"), t0)
    row["dt_s"] = round(time.time() - t0, 1)
    out["ATOMPAW"] = row
    _print_row(row)

    # --- ONCVPSP ---
    t0 = time.time()
    print("  → ONCVPSP …", flush=True)
    oncv = _oncv_input(client, element, z)
    if not oncv:
        row = {"success": False, "ok_scientifique": False, "error": "pas de template ONCV",
               "fresh_upf": False, "conform_qe": False, "z_valence": None, "size_kb": 0,
               "upf_path": "", "dt_s": 0}
        print("     err: pas de template ONCV")
    else:
        resp = client.post("/api/pseudos/run_oncvpsp", json={"element": element, "input": oncv})
        j = resp.get_json() or {}
        row = _score(j, j.get("upf_path"), t0)
        row["dt_s"] = round(time.time() - t0, 1)
        _print_row(row)
    out["ONCVPSP"] = row
    return out


def _print_row(row: dict) -> None:
    print(
        f"     api={row.get('success')} sci={row.get('ok_scientifique')} "
        f"fresh={row.get('fresh_upf')} qe={row.get('conform_qe')} "
        f"z={row.get('z_valence')} {row.get('size_kb')} KB  ({row.get('dt_s')}s)",
        flush=True,
    )
    if not row.get("ok_scientifique") and row.get("error"):
        print(f"     err: {row['error']}", flush=True)


def main() -> int:
    elements = _CLI or DEFAULT
    print("VALIDATION ÉCHANTILLON 3d / 4f — 4 générateurs")
    print(f"Projet : {ROOT}")
    print(f"Build  : {getattr(api, 'API_BUILD_TAG', '?')}")
    print("Éléments :", ", ".join(f"{e} ({FAMILLE.get(e, '?')})" for e in elements))
    bins = {
        "ld1.x": bool(api.QE_BIN and os.path.isfile(os.path.join(api.QE_BIN, "ld1.x"))),
        "APE": bool(api._resolve_ape_bin_sa()),
        "ATOMPAW": bool(api._resolve_atompaw_bin_sa()),
        "ONCVPSP": bool(api._resolve_oncvpsp_bin()),
    }
    print("Binaires :", ", ".join(f"{k}={'OK' if v else 'ABSENT'}" for k, v in bins.items()))

    client = api.app.test_client()
    all_res: dict = {}
    for el in elements:
        all_res[el] = run_one(client, el)

    print(f"\n{'=' * 72}")
    print("SYNTHÈSE")
    print(f"{'=' * 72}")
    print(f"{'Élément':<6} {'Famille':<22} {'Outil':<10} {'Sci':<5} {'QE':<5} {'z':<6} {'t(s)':<6}")
    print("-" * 70)
    n_ok = n_tot = 0
    by_tool: dict[str, list] = {k: [] for k in ("ld1.x", "APE", "ATOMPAW", "ONCVPSP")}
    for el, tools in all_res.items():
        for name, row in tools.items():
            n_tot += 1
            sci = bool(row.get("ok_scientifique"))
            if sci:
                n_ok += 1
            by_tool.setdefault(name, []).append(sci)
            print(
                f"{el:<6} {FAMILLE.get(el, '?'):<22} {name:<10} "
                f"{'OK' if sci else '—':<5} "
                f"{'OK' if row.get('conform_qe') else '—':<5} "
                f"{str(row.get('z_valence') or '—'):<6} "
                f"{row.get('dt_s', '—')}"
            )
            if not sci and row.get("error"):
                print(f"       └ {row['error'][:100]}")

    print("-" * 70)
    print(f"Score global : {n_ok}/{n_tot}")
    for tool, flags in by_tool.items():
        if flags:
            print(f"  {tool:<10} {sum(flags)}/{len(flags)}")

    out_path = ROOT / "logs" / "validation_3d_4f_sample.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps({"elements": elements, "score": f"{n_ok}/{n_tot}", "results": all_res}, indent=2),
        encoding="utf-8",
    )
    print(f"\nJSON → {out_path}")
    return 0 if n_ok == n_tot else 1


if __name__ == "__main__":
    raise SystemExit(main())

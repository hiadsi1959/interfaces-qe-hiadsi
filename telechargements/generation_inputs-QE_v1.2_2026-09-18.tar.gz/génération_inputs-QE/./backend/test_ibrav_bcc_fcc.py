"""Vérifie la cohérence QE : ibrav=2 → FCC, ibrav=3 → BCC."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

FILES_QE_CORRECT = [
    ROOT / "scripts" / "script_tab1_restructuration_v2.js",
    ROOT / "scripts" / "base_donnees_structures.js",
    ROOT / "scripts" / "script_positions_atomiques.js",
    ROOT / "scripts" / "script_positions_precises.js",
    ROOT / "scripts" / "script_positions_complete.js",
    ROOT / "scripts" / "script_structures_completes_v2.js",
    ROOT / "index.html",
]


def test_ibrav2_label_fcc_in_tab1_select():
    text = (ROOT / "scripts" / "tab1_build_html.js").read_text(encoding="utf-8")
    assert "2 - Cubique Faces Centrées (FCC)" in text
    assert "3 - Cubique Centré (BCC)" in text


def test_type_materiau_applies_ibrav_with_ascii_handler():
    text = (ROOT / "scripts" / "script_type_materiau.js").read_text(encoding="utf-8")
    assert "window.changerTypeMateriau = changerTypeMateriau" in text
    assert "appliquerIbravDepuisStructure" in text
    assert "resolveIbravForTab1Select" in text
    assert 'onchange="changerTypeMateriau()"' in text


def test_tab1_positions_exported_on_window():
    text = (ROOT / "scripts" / "script_positions_atomiques.js").read_text(encoding="utf-8")
    assert "window.reconstruirePositionsAtomiques = reconstruirePositionsAtomiques" in text
    assert "window.genererFormatPositions = mettreAJourFormat" in text
    assert "#section_4_positions #section_positions_atomiques" in text
    assert "#section_3_especes #nat" in text


def test_input_dft_tab1_scoped_init():
    dft = (ROOT / "scripts" / "qe_input_dft_options.js").read_text(encoding="utf-8")
    html = (ROOT / "scripts" / "tab1_build_html.js").read_text(encoding="utf-8")
    assert "resolveInputDftSelect" in dft
    assert "__qeInitTab1InputDft" in dft
    assert "#section_2_structure select#pw_input_dft" in dft
    assert "qeBuildInputDftBootstrapHtml" in html
    assert 'value="pbe"' in html


def test_tab1_build_html_includes_ibrav_options():
    """Le select ibrav ne doit pas dépendre uniquement d'un init JS tardif."""
    text = (ROOT / "scripts" / "tab1_build_html.js").read_text(encoding="utf-8")
    assert "qeBuildIbravSelectOptionsHtml" in text
    assert "value: '2'" in text and "FCC" in text
    assert "value: '3'" in text and "BCC" in text
    assert "qeBuildIbravSelectOptionsHtml()" in text


def test_ibrav2_fcc_ibrav3_bcc_base_structures():
    text = (ROOT / "scripts" / "base_donnees_structures.js").read_text(encoding="utf-8")
    assert "'fcc':" in text and "ibrav: [2]" in text
    assert "'bcc':" in text and "ibrav: [3]" in text


def test_no_swapped_bcc_fcc_labels_in_core_scripts():
    for path in FILES_QE_CORRECT:
        text = path.read_text(encoding="utf-8")
        assert "value: '2', label: '2 - Cubique Centré (BCC)'" not in text, f"swap BCC@2 dans {path.name}"
        assert "value: '3', label: '3 - Cubique Faces Centrées (FCC)'" not in text, f"swap FCC@3 dans {path.name}"


def test_ibrav_label_lut_in_index():
    text = (ROOT / "index.html").read_text(encoding="utf-8")
    assert "2: 'Cubique faces centrées (F)'" in text
    assert "3: 'Cubique centré (I)'" in text


def test_bands_kpath_fcc_is_ibrav2():
    from qe_input_builders import bands_kpath_crystal_b

    k2 = bands_kpath_crystal_b(2)
    k3 = bands_kpath_crystal_b(3)
    assert "Γ-X-W" in k2 or "0.5000 0.0000 0.5000" in k2
    assert "Γ-H-N" in k3 or "0.5000 -0.5000 0.5000" in k3

# Génération Inputs QE

Interface web pour générer des fichiers input Quantum ESPRESSO (génération directe ou conversion CIF → input).

**URL locale :** http://127.0.0.1:5012/

---

## Workflow — PC source → autre PC

### Méthode recommandée : un seul fichier `generation_inputs`

Sur le **PC source** (développement), construisez l’installateur :

```bash
cd génération_inputs-QE
chmod +x build_generation_inputs.sh
./build_generation_inputs.sh
```

Cela produit **`generation_inputs`** à la racine du projet : un exécutable autonome (~taille du projet compressé) qui embarque toute l’interface.

Copiez **ce seul fichier** sur l’autre PC (USB, `scp`, etc.) :

```bash
scp generation_inputs user@autre-pc:~/
```

Sur le **PC destination** :

```bash
chmod +x generation_inputs
./generation_inputs
# ou en une commande : ./generation_inputs --yes --start
```

L’installateur :

1. Extrait les fichiers dans `~/generation_inputs-QE` (ou `--install-dir CHEMIN`)
2. Lance automatiquement **`CONFIGURER.sh`** (apt, pip, détection QE, chemins locaux)
3. Affiche comment démarrer : `./DEMARRER.sh` → http://127.0.0.1:5012/

Options utiles :

| Option | Effet |
|--------|--------|
| `--install-dir DIR` | Dossier d’installation (défaut : `~/generation_inputs-QE`) |
| `--yes`, `-y` | Configuration sans questions |
| `--no-verify` | Ne pas lancer `VERIFIER.sh` après install |
| `--start` | Démarre l’interface à la fin |
| `--help` | Aide |

### Méthode alternative : archive `.tar.gz`

```bash
./compacter.sh
scp generation_inputs-QE_transfert_*.tar.gz user@autre-pc:~/
# Sur l’autre PC :
tar -xzf generation_inputs-QE_transfert_*.tar.gz
cd génération_inputs-QE
./CONFIGURER.sh
```

### Configuration (`CONFIGURER.sh`)

Sur un **nouveau PC**, seul le chemin de **Quantum ESPRESSO** (`pw.x`) diffère vraiment d’une machine à l’autre. Les pseudopotentiels utilisent par défaut les dossiers **locaux du projet** :

- `pseudos/PBE/` — pseudos scalaires
- `pseudos/PBE_FR/` — pseudos full-relativistic (non colinéaire)

Copiez vos fichiers `.UPF` dans ces dossiers, puis choisissez les bons pseudos dans l’interface (tableau périodique / paramètres).

```bash
./CONFIGURER.sh              # interactif (recommandé la première fois)
./CONFIGURER.sh --yes        # sans questions
./CONFIGURER.sh --yes --verify
./CONFIGURER.sh --yes --minimal   # dossiers + fichiers config uniquement
./CONFIGURER.sh --yes --no-apt    # sans sudo apt
```

Le script :

1. Installe les prérequis (`sudo apt`, `pip`) sauf en mode `--minimal`
2. Crée les dossiers (`inputs_générés_direct`, `inputs_convertis_cif`, `outputs`, `pseudos`, `data`)
3. Détecte **Quantum ESPRESSO** (`pw.x`) — seul paramètre machine-spécifique demandé si absent
4. Écrit `config_pc.env` et `scripts/config_pc_local.js`

Copiez vos pseudopotentiels si besoin :

```bash
cp /chemin/vers/*.UPF pseudos/PBE/
cp /chemin/vers/*.rel-pbe-*.UPF pseudos/PBE_FR/
```

Puis relancez `./CONFIGURER.sh` si vous changez le chemin de `pw.x`.

### Démarrer

```bash
./DEMARRER.sh
```

- Si `config_pc.env` est absent, **configuration minimale automatique** (`CONFIGURER.sh --yes --minimal`)
- Démarre l’API autonome (port **5012**)
- Démarre Interface-QE_v1 (port **5007**) si installée à côté
- Ouvre le navigateur sur http://127.0.0.1:5012/

Arrêt :

```bash
./ARRETER.sh
```

Vérification :

```bash
./VERIFIER.sh
```

---

## Scripts principaux

| Script | Rôle |
|--------|------|
| `DEMARRER.sh` | Lance l’API et ouvre l’interface |
| `ARRETER.sh` | Arrête les services |
| `CONFIGURER.sh` | Installation + configuration sur un nouveau PC |
| `VERIFIER.sh` | Contrôle fichiers et dépendances |
| `build_generation_inputs.sh` | Construit l’installateur `generation_inputs` |
| `compacter.sh` | Archive `.tar.gz` alternative pour transfert |

---

## Fichiers de configuration générés

| Fichier | Usage |
|---------|--------|
| `config_pc.env` | Variables shell (QE bin, pseudos, ports) — lu par `DEMARRER.sh` |
| `scripts/config_pc_local.js` | Chemins injectés dans l’interface avant `config_chemins.js` |

Ne pas versionner une config propre à une machine : elle est recréée par `./CONFIGURER.sh` sur chaque PC.

---

## Prérequis

- **Ubuntu** (ou dérivé Debian) avec `sudo`
- **Python 3** + pip (installés par `CONFIGURER.sh`)
- **Pseudopotentiels** dans `pseudos/PBE` et `pseudos/PBE_FR` (full-relativistic pour `noncolin`)
- **Quantum ESPRESSO** (`pw.x`) — optionnel pour générer des inputs ; requis pour lancer des calculs
- **Interface-QE_v1** — optionnel ; le mode autonome 5012 suffit pour générer et sauvegarder les inputs

---

## Dépannage

| Problème | Action |
|----------|--------|
| Flask / ase manquants | `./CONFIGURER.sh` |
| `pw.x` non trouvé | Relancer `./CONFIGURER.sh` — indiquer le dossier `bin` de QE |
| Pseudos absents | Copier `.UPF` dans `pseudos/PBE` et `.rel-pbe-*` dans `pseudos/PBE_FR` |
| Anciens chemins dans l’UI | Ctrl+F5 ; console F12 : `localStorage.removeItem('qe_inputs_config'); location.reload();` |
| Interface ancienne (cache) | Ctrl+F5 |
| Port 5012 occupé | `./ARRETER.sh` puis `./DEMARRER.sh` |
| Logs API | `.gen_inputs.log` (5012), `.gen_inputs_v1.log` (5007) |

---

## Structure utile

```
generation_inputs-QE/
├── index.html              # Interface
├── backend/                # API Python (5012)
├── scripts/                # Logique JS
├── inputs_générés_direct/  # Inputs génération directe
├── inputs_convertis_cif/   # Inputs depuis CIF
├── outputs/                # Sorties calculs
├── pseudos/PBE, PBE_FR/    # Pseudopotentiels (locaux)
├── cif/                    # Fichiers CIF d'exemple
├── data/                   # Catalogues JSON (DFT, Hubbard, defaults)
├── CONFIGURER.sh           # Config nouveau PC
├── DEMARRER.sh
├── ARRETER.sh
├── VERIFIER.sh
├── build_generation_inputs.sh
└── compacter.sh
```

Voir aussi `GUIDE_TRANSFERT.md` pour des détails complémentaires.

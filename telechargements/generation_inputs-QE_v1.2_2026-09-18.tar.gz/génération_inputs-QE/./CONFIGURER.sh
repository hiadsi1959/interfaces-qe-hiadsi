#!/bin/bash
# CONFIGURER.sh — Configuration sur un nouveau PC (PC destination).
#
# Rôle :
#   Installe les prérequis (apt + pip), crée les dossiers, détecte QE,
#   génère config_pc.env et scripts/config_pc_local.js, puis lance VERIFIER.sh.
#
# Usage :
#   cd génération_inputs-QE/
#   chmod +x CONFIGURER.sh
#   ./CONFIGURER.sh              # interactif
#   ./CONFIGURER.sh --yes        # sans questions (apt + pip auto)
#   ./CONFIGURER.sh --yes --verify
#   ./CONFIGURER.sh --yes --minimal   # dossiers + fichiers config uniquement
#   ./CONFIGURER.sh --yes --no-apt      # sans sudo apt
#
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

AUTO_YES=0
RUN_VERIFY=0
SKIP_APT=0
MINIMAL=0
for arg in "$@"; do
    case "$arg" in
        -y|--yes) AUTO_YES=1 ;;
        --verify) RUN_VERIFY=1 ;;
        --no-apt) SKIP_APT=1 ;;
        --minimal) MINIMAL=1; SKIP_APT=1 ;;
        -h|--help)
            echo "Usage: $0 [--yes] [--verify] [--no-apt] [--minimal]"
            echo "  --yes      Installe apt/pip sans confirmation (sauf --minimal)"
            echo "  --verify   Lance ./VERIFIER.sh à la fin"
            echo "  --no-apt   Ignore sudo apt (pip + config toujours)"
            echo "  --minimal  Dossiers + config uniquement (pas apt/pip)"
            exit 0
            ;;
    esac
done

sep() { echo -e "${CYAN}──────────────────────────────────────────────────────────${NC}"; }

ask() {
    local prompt="$1"
    local default="${2:-}"
    local reply
    if [ -n "$default" ]; then
        read -r -p "$prompt [$default] : " reply
        echo "${reply:-$default}"
    else
        read -r -p "$prompt : " reply
        echo "$reply"
    fi
}

ask_yes() {
    local prompt="$1"
    local default="${2:-o}"
    if [ "$AUTO_YES" -eq 1 ]; then
        return 0
    fi
    local reply
    read -r -p "$prompt (o/n) [$default] : " reply
    reply="${reply:-$default}"
    [[ "$reply" =~ ^[oOyY] ]]
}

echo -e "${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║  CONFIGURER.sh — Configuration PC destination             ║${NC}"
echo -e "${CYAN}║  Génération Inputs QE (port 5012)                       ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════╝${NC}"
echo "Dossier : $HERE"
echo

# ═══════════════════════════════════════════════════════════════════════════
# PARTIE 0 — Scripts exécutables
# ═══════════════════════════════════════════════════════════════════════════
sep
echo -e "${CYAN}PARTIE 0 — Permissions des scripts${NC}"
sep

EXEC_SCRIPTS=(
    DEMARRER.sh ARRETER.sh CONFIGURER.sh
    emballer.sh compacter.sh VERIFIER.sh build_generation_inputs.sh
)
for s in "${EXEC_SCRIPTS[@]}"; do
    [ -f "$HERE/$s" ] && chmod +x "$HERE/$s" 2>/dev/null || true
done
echo -e "${GREEN}✅ Scripts rendus exécutables${NC}"

# ═══════════════════════════════════════════════════════════════════════════
# PARTIE 1 — Prérequis système (apt)
# ═══════════════════════════════════════════════════════════════════════════
if [ "$MINIMAL" -eq 0 ]; then
    sep
    echo -e "${CYAN}PARTIE 1 — Prérequis système (sudo apt)${NC}"
    sep

    APT_PKGS=(
        python3 python3-pip python3-venv python3-dev
        curl wget rsync tar gzip ca-certificates
        build-essential libopenblas-dev libfftw3-dev
    )

    if [ "$SKIP_APT" -eq 1 ]; then
        echo -e "${YELLOW}⚠️  Étape apt ignorée (--no-apt)${NC}"
    elif ask_yes "Installer / mettre à jour les paquets système avec sudo apt ?" "o"; then
        echo -e "${YELLOW}→ sudo apt update && sudo apt install -y …${NC}"
        sudo apt-get update -qq
        sudo apt-get install -y "${APT_PKGS[@]}"
        echo -e "${GREEN}✅ Paquets système installés${NC}"
    else
        echo -e "${YELLOW}⚠️  Étape apt ignorée — vérifiez python3, pip, curl manuellement${NC}"
    fi

    if command -v node >/dev/null 2>&1; then
        echo -e "${GREEN}✅ node présent${NC} ($(node --version 2>/dev/null || echo '?')) — VERIFIER.sh pourra tester la syntaxe JS"
    else
        echo -e "${YELLOW}⚠️  node absent — optionnel (VERIFIER.sh ignorera la syntaxe JS)${NC}"
        if ask_yes "Installer nodejs via apt ?" "n"; then
            sudo apt-get install -y nodejs npm 2>/dev/null || echo -e "${YELLOW}⚠️  nodejs non installé${NC}"
        fi
    fi
fi

# ═══════════════════════════════════════════════════════════════════════════
# PARTIE 2 — Dépendances Python (pip)
# ═══════════════════════════════════════════════════════════════════════════
if [ "$MINIMAL" -eq 0 ]; then
    sep
    echo -e "${CYAN}PARTIE 2 — Dépendances Python (pip)${NC}"
    sep

    pip_install() {
        local pkg="$1"
        if python3 -m pip install --user "$pkg" 2>/tmp/pip_cfg_err; then
            echo -e "  ${GREEN}✅${NC} $pkg"
        elif python3 -m pip install --user --break-system-packages "$pkg" 2>/tmp/pip_cfg_err; then
            echo -e "  ${GREEN}✅${NC} $pkg (break-system-packages)"
        else
            echo -e "  ${RED}❌${NC} $pkg — voir /tmp/pip_cfg_err"
            return 1
        fi
    }

    for spec in "flask:flask" "flask_cors:flask-cors" "pytest:pytest"; do
        mod="${spec%%:*}"; pkg="${spec##*:}"
        python3 -c "import $mod" 2>/dev/null && echo -e "  ${GREEN}✅${NC} $mod déjà présent" || pip_install "$pkg"
    done

    if python3 -c "import ase, spglib" 2>/dev/null; then
        echo -e "  ${GREEN}✅${NC} ase + spglib déjà présents"
    elif python3 -c "import pymatgen" 2>/dev/null; then
        echo -e "  ${GREEN}✅${NC} pymatgen déjà présent"
    else
        pip_install "ase"
        pip_install "spglib"
    fi
fi

# ═══════════════════════════════════════════════════════════════════════════
# PARTIE 3 — Dossiers locaux + fragments
# ═══════════════════════════════════════════════════════════════════════════
sep
echo -e "${CYAN}PARTIE 3 — Dossiers du projet${NC}"
sep

mkdir -p \
    "$HERE/inputs_générés_direct" \
    "$HERE/inputs_convertis_cif" \
    "$HERE/outputs" \
    "$HERE/pseudos/PBE" \
    "$HERE/pseudos/PBE_FR" \
    "$HERE/cif" \
    "$HERE/data" \
    "$HERE/fragments"

# Anciennes installs : liens CIF erronés dans data/ (canonique = cif/)
find "$HERE/data" -maxdepth 1 -type l -name '*.cif' -delete 2>/dev/null || true

if [ ! -f "$HERE/fragments/subsection_gestion.html" ]; then
    echo -e "${RED}❌ fragments/subsection_gestion.html manquant — archive incomplète ?${NC}"
    echo "   Relancez ./compacter.sh sur le PC source et re-transférez."
else
    echo -e "${GREEN}✅ Fragment CIF présent (fragments/subsection_gestion.html)${NC}"
fi

echo -e "${GREEN}✅ Dossiers créés (inputs, outputs, pseudos, data, fragments)${NC}"

# ═══════════════════════════════════════════════════════════════════════════
# PARTIE 4 — Détection automatique
# ═══════════════════════════════════════════════════════════════════════════
sep
echo -e "${CYAN}PARTIE 4 — Détection automatique${NC}"
sep

detect_qe_bin() {
    local c
    for c in \
        "$HOME/q-e-qe-7.5/bin" \
        "$HOME/q-e-qe-7.5/PW/src" \
        "$HOME/q-e/bin" \
        "$HOME/qe-7.5/bin" \
        "$HOME/qe/bin" \
        "/opt/qe/bin" \
        "/usr/local/qe/bin" \
        "/usr/bin"
    do
        [ -x "$c/pw.x" ] && { echo "$c"; return 0; }
    done
    command -v pw.x >/dev/null 2>&1 && dirname "$(command -v pw.x)" && return 0
    return 1
}

count_upf() {
    local d="$1"
    [ -d "$d" ] && find "$d" -maxdepth 1 \( -name '*.UPF' -o -name '*.upf' \) 2>/dev/null | wc -l || echo 0
}

QE_BIN="$(detect_qe_bin 2>/dev/null || true)"
# Pseudos : toujours les dossiers locaux du projet (l'utilisateur y copie ses .UPF)
PSEUDO_DIR="$HERE/pseudos/PBE"
PSEUDO_FR_DIR="$HERE/pseudos/PBE_FR"
INPUTS_DIR="$HERE/inputs_générés_direct"
INPUTS_CIF_DIR="$HERE/inputs_convertis_cif"
OUTPUTS_DIR="$HERE/outputs"
CIF_DIR="$HERE/cif"
INTERFACE_QE_V1=""

for candidate in "$HERE/../Interface-QE_v1" "$HOME/Interface-QE_v1"; do
    if [ -f "$candidate/api_qe_ubuntu.py" ]; then
        INTERFACE_QE_V1="$(cd "$candidate" && pwd)"
        break
    fi
done

echo "Détection :"
if [ -n "$QE_BIN" ]; then
    echo -e "  ${GREEN}✅${NC} Quantum ESPRESSO : $QE_BIN/pw.x"
else
    echo -e "  ${YELLOW}⚠️${NC}  pw.x non trouvé (génération d'inputs OK, lancement calculs non)"
fi
echo -e "  Pseudos PBE    : $PSEUDO_DIR ($(count_upf "$PSEUDO_DIR") fichiers)"
echo -e "  Pseudos PBE_FR : $PSEUDO_FR_DIR ($(count_upf "$PSEUDO_FR_DIR") fichiers)"
echo -e "  Inputs direct  : $INPUTS_DIR"
echo -e "  Inputs CIF     : $INPUTS_CIF_DIR"
echo -e "  Outputs        : $OUTPUTS_DIR"
echo -e "  CIF (exemples) : $CIF_DIR"
[ -n "$INTERFACE_QE_V1" ] && echo -e "  ${GREEN}✅${NC} Interface-QE_v1 : $INTERFACE_QE_V1" \
    || echo -e "  ${YELLOW}—${NC} Interface-QE_v1 non trouvé (mode autonome 5012 suffit)"

# ═══════════════════════════════════════════════════════════════════════════
# PARTIE 5 — Ajustements interactifs
# ═══════════════════════════════════════════════════════════════════════════
if [ "$MINIMAL" -eq 0 ]; then
    sep
    echo -e "${CYAN}PARTIE 5 — Ajustements (si besoin)${NC}"
    sep

    if [ -z "$QE_BIN" ] && [ "$AUTO_YES" -eq 0 ]; then
        echo -e "${YELLOW}Quantum ESPRESSO (pw.x) non détecté — seul paramètre vraiment spécifique à ce PC.${NC}"
        QE_IN="$(ask "Chemin dossier bin QE (Enter = ignorer)" "")"
        if [ -n "$QE_IN" ] && [ -x "$QE_IN/pw.x" ]; then
            QE_BIN="$QE_IN"
            echo -e "${GREEN}✅ pw.x : $QE_BIN/pw.x${NC}"
        elif [ -n "$QE_IN" ]; then
            echo -e "${RED}❌ pw.x introuvable dans $QE_IN${NC}"
            QE_BIN=""
        fi
    fi

    if [ "$(count_upf "$PSEUDO_DIR")" -eq 0 ] && [ "$AUTO_YES" -eq 0 ]; then
        echo
        echo -e "${YELLOW}Pseudos PBE absents — copiez des .UPF dans : $HERE/pseudos/PBE${NC}"
        echo "   (ou indiquez un autre dossier si vous préférez)"
        P_IN="$(ask "Chemin pseudos PBE (Enter = dossier local vide)" "$PSEUDO_DIR")"
        [ -d "$P_IN" ] && PSEUDO_DIR="$P_IN"
    fi

    if [ "$(count_upf "$PSEUDO_FR_DIR")" -eq 0 ] && [ "$AUTO_YES" -eq 0 ]; then
        echo
        echo -e "${YELLOW}Pseudos PBE_FR absents — requis pour noncolin / .rel-pbe-*${NC}"
        FR_IN="$(ask "Chemin pseudos PBE_FR (Enter = dossier local vide)" "$PSEUDO_FR_DIR")"
        [ -d "$FR_IN" ] && PSEUDO_FR_DIR="$FR_IN"
    fi

    if [ "$AUTO_YES" -eq 0 ]; then
        if ask_yes "Modifier le dossier outputs ?" "n"; then
            OUTPUTS_DIR="$(ask "Répertoire outputs" "$OUTPUTS_DIR")"
        fi
        if ask_yes "Modifier les dossiers inputs ?" "n"; then
            INPUTS_DIR="$(ask "inputs_générés_direct" "$INPUTS_DIR")"
            INPUTS_CIF_DIR="$(ask "inputs_convertis_cif" "$INPUTS_CIF_DIR")"
        fi
        if [ -z "$INTERFACE_QE_V1" ] && ask_yes "Interface-QE_v1 installé ailleurs ?" "n"; then
            IQ="$(ask "Chemin Interface-QE_v1" "$HOME/Interface-QE_v1")"
            [ -f "$IQ/api_qe_ubuntu.py" ] && INTERFACE_QE_V1="$(cd "$IQ" && pwd)" \
                || echo -e "${YELLOW}⚠️  api_qe_ubuntu.py absent dans $IQ${NC}"
        fi
    fi
fi

# ═══════════════════════════════════════════════════════════════════════════
# PARTIE 6 — Fichiers de configuration
# ═══════════════════════════════════════════════════════════════════════════
sep
echo -e "${CYAN}PARTIE 6 — Enregistrement de la configuration${NC}"
sep

GEN_PORT="${GEN_INPUTS_PORT:-5012}"
QE_API_PORT="${QE_API_PORT:-5007}"

cat > "$HERE/config_pc.env" <<EOF
# Généré par CONFIGURER.sh — $(date -Iseconds)
export GEN_INPUTS_ROOT="$HERE"
export GEN_INPUTS_PORT="$GEN_PORT"
export GEN_INPUTS_HOST="127.0.0.1"
export QE_BIN_DIR="${QE_BIN:-}"
export PSEUDO_DIR="$PSEUDO_DIR"
export PSEUDO_FR_DIR="$PSEUDO_FR_DIR"
export INPUTS_GENERES_DIR="$INPUTS_DIR"
export INPUTS_CIF_DIR="$INPUTS_CIF_DIR"
export OUTPUTS_DIR="$OUTPUTS_DIR"
export CIF_DIR="$CIF_DIR"
export INTERFACE_QE_V1="${INTERFACE_QE_V1:-}"
export QE_API_PORT="$QE_API_PORT"
export START_INTERFACE_QE_V1="$([ -n "$INTERFACE_QE_V1" ] && echo 1 || echo 0)"
EOF

cat > "$HERE/scripts/config_pc_local.js" <<EOF
/** Généré par CONFIGURER.sh — $(date -Iseconds) — ne pas éditer à la main */
(function () {
    'use strict';
    window.QE_CONFIG_PRELOAD = {
        INPUTS_DIRECT_DIR: $(python3 -c "import json; print(json.dumps('$INPUTS_DIR'))"),
        INPUTS_GENERES_DIR: $(python3 -c "import json; print(json.dumps('$INPUTS_DIR'))"),
        INPUTS_DIR: $(python3 -c "import json; print(json.dumps('$INPUTS_DIR'))"),
        INPUTS_CIF_DIR: $(python3 -c "import json; print(json.dumps('$INPUTS_CIF_DIR'))"),
        OUTPUTS_DIR: $(python3 -c "import json; print(json.dumps('$OUTPUTS_DIR'))"),
        PSEUDO_DIR: $(python3 -c "import json; print(json.dumps('$PSEUDO_DIR'))"),
        PSEUDO_FR_DIR: $(python3 -c "import json; print(json.dumps('$PSEUDO_FR_DIR'))"),
        CIF_DIR: $(python3 -c "import json; print(json.dumps('$CIF_DIR'))"),
        QE_BIN_DIR: $(python3 -c "import json; print(json.dumps('${QE_BIN:-}'))"),
        WORK_DIR: $(python3 -c "import json; print(json.dumps('$HERE'))")
    };
})();
EOF

echo -e "${GREEN}✅ config_pc.env${NC}"
echo -e "${GREEN}✅ scripts/config_pc_local.js${NC}"

# ═══════════════════════════════════════════════════════════════════════════
# PARTIE 7 — Vérification (optionnelle)
# ═══════════════════════════════════════════════════════════════════════════
if [ "$MINIMAL" -eq 0 ]; then
    sep
    echo -e "${CYAN}PARTIE 7 — Vérification${NC}"
    sep

    if [ "$RUN_VERIFY" -eq 1 ] || ask_yes "Lancer ./VERIFIER.sh maintenant ?" "o"; then
        if [ -x "$HERE/VERIFIER.sh" ]; then
            "$HERE/VERIFIER.sh" || true
        else
            echo -e "${YELLOW}⚠️  VERIFIER.sh introuvable${NC}"
        fi
    else
        echo -e "${YELLOW}⚠️  VERIFIER.sh non lancé — exécutez-le avant la première utilisation${NC}"
    fi
fi

# ═══════════════════════════════════════════════════════════════════════════
# Résumé
# ═══════════════════════════════════════════════════════════════════════════
sep
echo -e "${GREEN}Configuration terminée.${NC}"
echo
echo "Prochaines étapes sur ce PC :"
echo "  1. ./DEMARRER.sh"
echo "  2. Ouvrir http://127.0.0.1:${GEN_PORT}/  puis Ctrl+F5"
echo "  3. Onglet 1 → Génération direct ou Gestion CIF"
if [ "$MINIMAL" -eq 0 ]; then
    echo "  4. ./VERIFIER.sh  (si pas déjà fait)"
fi
echo
if [ "$(count_upf "$PSEUDO_DIR")" -eq 0 ]; then
    echo -e "${YELLOW}⚠️  Copiez vos pseudos .UPF dans $PSEUDO_DIR${NC}"
    echo "   Puis choisissez-les dans l'interface (tableau périodique / paramètres)."
fi
if [ "$(count_upf "$PSEUDO_FR_DIR")" -eq 0 ]; then
    echo -e "${YELLOW}⚠️  Copiez les pseudos .rel-pbe-* dans $PSEUDO_FR_DIR pour le non colinéaire.${NC}"
fi
if [ -z "$QE_BIN" ]; then
    echo -e "${YELLOW}⚠️  pw.x non configuré — génération d'inputs OK, exécution pw.x non.${NC}"
    echo "   Relancez ./CONFIGURER.sh pour indiquer le dossier bin de Quantum ESPRESSO."
fi
echo
echo -e "${CYAN}Navigateur :${NC} si l'interface affiche d'anciens chemins, ouvrez la console (F12) et tapez :"
echo "  localStorage.removeItem('qe_inputs_config'); location.reload();"
echo
echo "Reconfigurer : ./CONFIGURER.sh"
echo "Transfert retour : ./build_generation_inputs.sh sur ce PC (ou ./compacter.sh)"

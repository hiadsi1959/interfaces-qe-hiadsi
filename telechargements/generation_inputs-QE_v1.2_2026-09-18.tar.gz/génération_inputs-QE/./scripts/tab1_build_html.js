/**
 * HTML Tab 1 — toutes les chaînes via window.t()
 */
(function () {
    'use strict';

    function _t(k) {
        return (typeof window.t === 'function') ? window.t(k) : k;
    }

    /** Liste canonique ibrav 1–14 (QE pw.x) — partagée HTML + init JS */
    window.QE_IBRAV_OPTIONS = [
        { value: '1', label: '1 - Cubique Simple (SC)' },
        { value: '2', label: '2 - Cubique Faces Centrées (FCC)' },
        { value: '3', label: '3 - Cubique Centré (BCC)' },
        { value: '4', label: '4 - Hexagonal' },
        { value: '5', label: '5 - Rhomboédrique' },
        { value: '6', label: '6 - Tétragonal Simple' },
        { value: '7', label: '7 - Tétragonal Centré' },
        { value: '8', label: '8 - Orthorhombique Simple' },
        { value: '9', label: '9 - Orthorhombique Centré' },
        { value: '10', label: '10 - Orthorhombique F' },
        { value: '11', label: '11 - Orthorhombique I' },
        { value: '12', label: '12 - Monoclinique Simple' },
        { value: '13', label: '13 - Monoclinique Centré' },
        { value: '14', label: '14 - Triclinique' }
    ];

    /** Options minimales si le catalogue complet n’est pas encore exécuté */
    window.qeBuildInputDftBootstrapHtml = function qeBuildInputDftBootstrapHtml() {
        return ''
            + '<option value="">(défaut — ne pas forcer input_dft)</option>'
            + '<option value="pbe" selected>★ PBE (GGA — défaut courant)</option>'
            + '<option value="pbesol">★ PBESOL</option>'
            + '<option value="lda">LDA (alias → pz)</option>'
            + '<option value="scan">SCAN (méta‑GGA)</option>';
    };

    window.qeBuildIbravSelectOptionsHtml = function qeBuildIbravSelectOptionsHtml() {
        var placeholder = _t('sec2.select');
        var html = '<option value="">' + placeholder + '</option>';
        (window.QE_IBRAV_OPTIONS || []).forEach(function (struct) {
            html += '<option value="' + struct.value + '">' + struct.label + '</option>';
        });
        return html;
    };

    window.buildTab1HTML = function buildTab1HTML() {
        return ''
            + '<div id="tab1_header" class="qe-tab-header">'
            + '<h1 style="margin:0;font-size:1.65em;">' + _t('tab1.title') + '</h1>'
            + '<p style="margin:10px 0 0;opacity:0.92;">' + _t('tab1.subtitle') + '</p></div>'
            + '<nav id="tab1_main_nav" class="tab1-main-nav" aria-label="' + _t('tab1.nav_aria') + '">'
            + '<button type="button" class="tab1-main-nav-btn active" data-tab1-panel="guide" data-i18n="nav.guide" onclick="tab1SwitchMainTab(\'guide\')">' + _t('nav.guide') + '</button>'
            + '<button type="button" class="tab1-main-nav-btn" data-tab1-panel="generation" data-i18n="nav.generation" onclick="tab1SwitchMainTab(\'generation\')">' + _t('nav.generation') + '</button>'
            + '<button type="button" class="tab1-main-nav-btn" data-tab1-panel="cif" data-i18n="nav.cif" onclick="tab1SwitchMainTab(\'cif\')">' + _t('nav.cif') + '</button>'
            + '<button type="button" class="tab1-main-nav-btn" data-tab1-panel="exemples" data-i18n="nav.examples" onclick="tab1SwitchMainTab(\'exemples\')">' + _t('nav.examples') + '</button>'
            + '</nav>'
            + '<div id="tab1_status_banner" class="tab1-status-banner" style="display:none;" role="status"></div>'
            + '<div id="tab1_panel_guide" class="tab1-main-panel active"><div id="tab1_aide_panel" class="tab1-aide-panel">'
            + '<h3 data-i18n="guide.title">' + _t('guide.title') + '</h3>'
            + '<div class="qe-guide-flow" aria-label="' + _t('stepper.aria') + '">'
            + '<div class="qe-guide-step"><strong>1</strong>' + _t('guide.step1') + '<br><code>prefix</code></div>'
            + '<div class="qe-guide-step"><strong>2</strong>' + _t('guide.step2') + '<br><code>ibrav</code></div>'
            + '<div class="qe-guide-step"><strong>2b</strong>' + _t('guide.step2b') + '<br><code>input_dft</code></div>'
            + '<div class="qe-guide-step"><strong>3</strong>' + _t('guide.step3') + '<br><code>ntyp</code></div>'
            + '<div class="qe-guide-step"><strong>4</strong>' + _t('guide.step4') + '<br><code>ATOMIC_POSITIONS</code></div>'
            + '<div class="qe-guide-step"><strong>5</strong>' + _t('guide.step5') + '<br>type · mag · U</div>'
            + '<div class="qe-guide-step"><strong>6</strong>' + _t('guide.step6') + '<br><code>.in</code> ' + _t('guide.step6_sub') + '</div></div>'
            + '<ol class="tab1-aide-list">'
            + '<li data-i18n="guide.li1" data-i18n-html="1">' + _t('guide.li1') + '</li>'
            + '<li data-i18n="guide.li2" data-i18n-html="1">' + _t('guide.li2') + '</li>'
            + '<li data-i18n="guide.li3" data-i18n-html="1">' + _t('guide.li3') + '</li>'
            + '<li data-i18n="guide.li4" data-i18n-html="1">' + _t('guide.li4') + '</li>'
            + '<li data-i18n="guide.li5" data-i18n-html="1">' + _t('guide.li5') + '</li>'
            + '<li data-i18n="guide.li6" data-i18n-html="1">' + _t('guide.li6') + '</li>'
            + '<li data-i18n="guide.li7" data-i18n-html="1">' + _t('guide.li7') + '</li>'
            + '<li data-i18n="guide.li8" data-i18n-html="1">' + _t('guide.li8') + '</li></ol>'
            + '<div class="qe-guide-cols"><div class="qe-guide-col"><h4 data-i18n="guide.col1_title">' + _t('guide.col1_title') + '</h4>'
            + '<p data-i18n="guide.col1_text" data-i18n-html="1" style="margin:0;font-size:0.88em;line-height:1.55;color:#475569;">' + _t('guide.col1_text') + '</p></div>'
            + '<div class="qe-guide-col"><h4 data-i18n="guide.col2_title">' + _t('guide.col2_title') + '</h4>'
            + '<p data-i18n="guide.col2_text" data-i18n-html="1" style="margin:0;font-size:0.88em;line-height:1.55;color:#475569;">' + _t('guide.col2_text') + '</p></div></div>'
            + '<p class="qe-guide-note" data-i18n="guide.note" data-i18n-html="1">' + _t('guide.note') + '</p>'
            + '<p class="tab1-aide-foot" data-i18n="guide.foot" data-i18n-html="1">' + _t('guide.foot') + '</p>'
            + '<p style="margin:14px 0 0;text-align:center;">'
            + '<button type="button" class="tab1-tb-btn tab1-tb-primary" data-i18n="guide.btn_gen" onclick="tab1SwitchMainTab(\'generation\')">' + _t('guide.btn_gen') + '</button>'
            + '<button type="button" class="tab1-tb-btn" style="margin-left:8px;" data-i18n="guide.btn_ex" onclick="tab1SwitchMainTab(\'exemples\')">' + _t('guide.btn_ex') + '</button>'
            + '</p></div></div>'
            + '<div id="tab1_panel_generation" class="tab1-main-panel">'
            + '<nav id="tab1_stepper" class="tab1-stepper" aria-label="' + _t('stepper.aria') + '">'
            + '<button type="button" class="tab1-step-item" onclick="tab1ScrollToStep(0)"><span id="tab1_step_dot_0" class="tab1-step-dot pending">1</span><span class="tab1-step-label" data-i18n="stepper.material">' + _t('stepper.material') + '</span></button><span class="tab1-step-sep"></span>'
            + '<button type="button" class="tab1-step-item" onclick="tab1ScrollToStep(1)"><span id="tab1_step_dot_1" class="tab1-step-dot pending">2</span><span class="tab1-step-label" data-i18n="stepper.structure">' + _t('stepper.structure') + '</span></button><span class="tab1-step-sep"></span>'
            + '<button type="button" class="tab1-step-item" onclick="tab1ScrollToStep(2)"><span id="tab1_step_dot_2" class="tab1-step-dot pending">3</span><span class="tab1-step-label" data-i18n="stepper.species">' + _t('stepper.species') + '</span></button><span class="tab1-step-sep"></span>'
            + '<button type="button" class="tab1-step-item" onclick="tab1ScrollToStep(3)"><span id="tab1_step_dot_3" class="tab1-step-dot pending">4</span><span class="tab1-step-label" data-i18n="stepper.positions">' + _t('stepper.positions') + '</span></button><span class="tab1-step-sep"></span>'
            + '<button type="button" class="tab1-step-item" onclick="tab1ScrollToStep(4)"><span id="tab1_step_dot_4" class="tab1-step-dot pending">5</span><span class="tab1-step-label" data-i18n="stepper.calc">' + _t('stepper.calc') + '</span></button>'
            + '</nav>'
            + '<p class="tab1-flow-hint" data-i18n="gen.flow_hint" data-i18n-html="1">' + _t('gen.flow_hint') + '</p>'
            + '<div id="section_1_materiau" class="qe-section qe-section--materiau">'
            + '<h2 class="qe-section-title"><span class="qe-step-num">01</span> <span data-i18n="sec1.title">' + _t('sec1.title') + '</span></h2>'
            + '<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;"><div class="form-group">'
            + '<label data-i18n="sec1.name">' + _t('sec1.name') + '</label>'
            + '<input type="text" id="materiau_name" placeholder="Ex: BaFeO3, GaN, Si, ZnO" style="width:100%;padding:12px;">'
            + '<small data-i18n="sec1.name_hint" style="color:#64748b;margin-top:5px;display:block;">' + _t('sec1.name_hint') + '</small></div>'
            + '<div class="form-group"><label data-i18n="sec1.prefix">' + _t('sec1.prefix') + '</label>'
            + '<input type="text" id="prefix_name" placeholder="Ex: BaFeO3_scf" style="width:100%;padding:12px;">'
            + '<small data-i18n="sec1.prefix_hint" style="color:#64748b;margin-top:5px;display:block;">' + _t('sec1.prefix_hint') + '</small></div></div>'
            + '<div id="sec1_type_materiau_panel" class="sec1-type-materiau-panel" role="region" aria-labelledby="sec1_type_materiau_heading">'
            + '<div class="sec1-type-materiau-panel__head">'
            + '<span class="sec1-type-materiau-panel__badge" data-i18n="sec1.type_badge">' + _t('sec1.type_badge') + '</span>'
            + '<h3 id="sec1_type_materiau_heading" data-i18n="sec1.type_summary">' + _t('sec1.type_summary') + '</h3>'
            + '<p class="sec1-type-materiau-panel__hint" data-i18n="sec1.type_hint" data-i18n-html="1">' + _t('sec1.type_hint') + '</p>'
            + '</div>'
            + '<div id="sec1_type_materiau_block">'
            + ((typeof window.buildTypeMateriauFieldsHTML === 'function') ? window.buildTypeMateriauFieldsHTML() : '')
            + '</div></div></div>'
            + '<div id="section_2_structure" class="qe-section qe-section--structure">'
            + '<h2 class="qe-section-title"><span class="qe-step-num">02</span> <span data-i18n="sec2.title">' + _t('sec2.title') + '</span></h2>'
            + '<div class="form-group" style="max-width:560px;margin-bottom:12px;">'
            + '<label data-i18n="sec2.ibrav" data-i18n-html="1">' + _t('sec2.ibrav') + '</label>'
            + '<select id="ibrav" onchange="if(typeof afficherParametresCristallins===\'function\')afficherParametresCristallins(); if(typeof afficherGroupesEspaceTab1===\'function\')afficherGroupesEspaceTab1();" style="width:100%;padding:10px;">'
            + window.qeBuildIbravSelectOptionsHtml()
            + '</select></div>'
            + '<details id="sec2_sg_optional_wrap" class="sec2-sg-optional" style="margin:0 0 14px;padding:10px 12px;border:1px dashed var(--qe-border,#cbd5e1);border-radius:8px;background:rgba(248,250,252,.85);">'
            + '<summary style="cursor:pointer;font-weight:600;color:#475569;" data-i18n="sec2.sg_optional_summary">' + _t('sec2.sg_optional_summary') + '</summary>'
            + '<p data-i18n="sec2.sg_hint" data-i18n-html="1" style="margin:10px 0 8px;font-size:0.88em;line-height:1.45;color:#64748b;">' + _t('sec2.sg_hint') + '</p>'
            + '<div class="form-group" style="margin-bottom:0;">'
            + '<label data-i18n="sec2.sg" data-i18n-html="1">' + _t('sec2.sg') + '</label>'
            + '<select id="groupe_espace_select" style="width:100%;padding:10px;">'
            + '<option value="">' + _t('sec2.sg_skip') + '</option></select></div></details>'
            + '<div id="parametres_cristallins" style="margin-top:20px;padding-top:20px;border-top:1px solid var(--qe-border,#cbd5e1);"></div>'
            + '<div id="gen_direct_input_dft_block"><p data-i18n="sec2.order_hint" data-i18n-html="1" style="color:#475569;font-size:0.88em;margin:0 0 12px;line-height:1.45;">' + _t('sec2.order_hint') + '</p>'
            + '<div class="form-group" style="max-width:560px;"><label data-i18n="sec2.dft_label" data-i18n-html="1">' + _t('sec2.dft_label') + '</label>'
            + '<select id="pw_input_dft" style="width:100%;padding:12px;font-size:1em;">'
            + window.qeBuildInputDftBootstrapHtml()
            + '</select>'
            + '<small data-i18n="sec2.dft_hint" data-i18n-html="1" style="color:#64748b;display:block;margin-top:6px;line-height:1.35;">' + _t('sec2.dft_hint') + '</small></div></div></div>'
            + '<div id="section_3_especes" class="qe-section qe-section--especes">'
            + '<h2 class="qe-section-title"><span class="qe-step-num">03</span> <span data-i18n="sec3.title">' + _t('sec3.title') + '</span></h2>'
            + '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:10px;"><div class="form-group" style="margin-bottom:0;">'
            + '<label data-i18n="sec3.ntyp" data-i18n-html="1">' + _t('sec3.ntyp') + '</label>'
            + '<input type="number" id="ntyp" min="1" max="10" value="1" '
            + 'oninput="if(typeof reconstruireChampElements===\'function\')reconstruireChampElements(); if(typeof reconstruirePositionsAtomiques===\'function\')reconstruirePositionsAtomiques(); if(typeof genererFormatPositions===\'function\')genererFormatPositions();" '
            + 'onchange="if(typeof reconstruireChampElements===\'function\')reconstruireChampElements(); if(typeof reconstruirePositionsAtomiques===\'function\')reconstruirePositionsAtomiques(); if(typeof genererFormatPositions===\'function\')genererFormatPositions();" '
            + 'style="width:100%;padding:8px;"></div>'
            + '<div class="form-group" style="margin-bottom:0;"><label data-i18n="sec3.nat" data-i18n-html="1">' + _t('sec3.nat') + '</label>'
            + '<input type="number" id="nat" min="1" max="100" onchange="if(typeof window.reconstruirePositionsAtomiques===\'function\')window.reconstruirePositionsAtomiques(); if(typeof window.genererFormatPositions===\'function\')window.genererFormatPositions();" style="width:100%;padding:8px;"></div></div>'
            + '<div id="section_elements"></div></div>'
            + '<div id="section_4_positions" class="qe-section qe-section--positions">'
            + '<h2 class="qe-section-title"><span class="qe-step-num">04</span> <span data-i18n="sec4.title">' + _t('sec4.title') + '</span></h2>'
            + '<div id="section_positions_atomiques"><p style="margin:0;color:#64748b;font-size:0.9em;line-height:1.45;" data-i18n="sec4.hint">' + _t('sec4.hint') + '</p></div></div>'
            + '<details id="tab1_autres_entrees" class="tab1-autres-entrees"><summary data-i18n="other.summary">' + _t('other.summary') + '</summary>'
            + '<div id="barre_actions_rapides" class="tab1-autres-entrees-body"><div style="display:flex;gap:15px;justify-content:center;flex-wrap:wrap;padding:16px 0 8px;">'
            + '<button type="button" onclick="ouvrirInputsExistantsRapide()" class="tab1-tb-btn" data-i18n="other.open_inputs">' + _t('other.open_inputs') + '</button>'
            + '<button type="button" onclick="ouvrirFichiersCIFRapide()" class="tab1-tb-btn" data-i18n="other.open_cif">' + _t('other.open_cif') + '</button>'
            + '<button type="button" onclick="tab1SwitchMainTab(\'cif\')" class="tab1-tb-btn" data-i18n="other.cif_full">' + _t('other.cif_full') + '</button>'
            + '<button type="button" onclick="fermerZoneFichiers()" id="btn_fermer_fichiers" style="display:none;" class="tab1-tb-btn tab1-tb-muted" data-i18n="other.close">' + _t('other.close') + '</button>'
            + '</div><div id="zone_resultats_fichiers" style="display:none;margin-top:12px;background:white;border-radius:10px;padding:20px;">'
            + '<div id="liste_inputs_rapide"></div><div id="liste_cif_rapide"></div></div></div></details>'
            + '</div>'
            + '<div id="tab1_panel_exemples" class="tab1-main-panel"><div class="tab1-aide-panel">'
            + '<h3 data-i18n="ex.title">' + _t('ex.title') + '</h3>'
            + '<p data-i18n="ex.intro" data-i18n-html="1" style="margin:0 0 14px;line-height:1.55;">' + _t('ex.intro') + '</p>'
            + '<div class="tab1-exemples-grid">'
            + '<div class="tab1-exemple-card" onclick="tab1ChargerExempleEtAller(\'BaTiO3\')"><strong>BaTiO3</strong><p data-i18n="ex.batio3">' + _t('ex.batio3') + '</p></div>'
            + '<div class="tab1-exemple-card" onclick="tab1ChargerExempleEtAller(\'Si\')"><strong>Si</strong><p data-i18n="ex.si">' + _t('ex.si') + '</p></div>'
            + '<div class="tab1-exemple-card" onclick="tab1ChargerExempleEtAller(\'GdVO3\')"><strong>GdVO3</strong><p data-i18n="ex.gdvo3">' + _t('ex.gdvo3') + '</p></div></div>'
            + '<select id="tab1_exemple_select" class="tab1-tb-btn tab1-exemple-select" style="margin-top:16px;width:100%;max-width:420px;" onchange="tab1ChargerExempleDepuisSelect(this)">'
            + '<option value="">' + _t('ex.select_placeholder') + '</option>'
            + '<option value="BaTiO3">' + _t('ex.opt_batio3') + '</option>'
            + '<option value="Si">' + _t('ex.opt_si') + '</option>'
            + '<option value="GdVO3">' + _t('ex.opt_gdvo3') + '</option></select></div></div>';
    };
})();

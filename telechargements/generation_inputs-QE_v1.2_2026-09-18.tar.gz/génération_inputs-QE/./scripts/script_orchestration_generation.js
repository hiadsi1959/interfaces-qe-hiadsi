// ═══════════════════════════════════════════════════════════════════════════
// ORCHESTRATION COMPLÈTE - Assure que TOUT est rempli avant génération
// ═══════════════════════════════════════════════════════════════════════════

function __genLireIbravWorkflow() {
    var el = document.getElementById('ibrav') || document.getElementById('pw_input_ibrav');
    return el ? String(el.value || '').trim() : '';
}

function __genSyncPositionsDepuisTextarea() {
    if (typeof mettreAJourFormat !== 'function') return false;
    var ta = document.getElementById('atomic_positions');
    if (ta && String(ta.value || '').trim()) {
        try { mettreAJourFormat(); return true; } catch (_e) {}
    }
    if (window.atomicPositionsContent && String(window.atomicPositionsContent).trim()) return true;
    return false;
}

function __genCompterPositionsRemplies(nat) {
    var ok = 0;
    for (var i = 1; i <= nat; i++) {
        var x = document.getElementById('pos_x_' + i);
        var y = document.getElementById('pos_y_' + i);
        var z = document.getElementById('pos_z_' + i);
        if (x && y && z &&
                String(x.value).trim() !== '' &&
                String(y.value).trim() !== '' &&
                String(z.value).trim() !== '') {
            ok++;
        }
    }
    return ok;
}

function __genLireCalcType() {
    var el = document.querySelector('#section_5_type_calcul_chemins #calc_type')
        || document.getElementById('calc_type');
    return el ? String(el.value || '').trim() : '';
}

function __genToastErreur(msgPlain) {
    if (!msgPlain) return;
    var t = document.createElement('div');
    t.setAttribute('role', 'alert');
    t.style.cssText = 'position:fixed;bottom:28px;left:50%;transform:translateX(-50%);max-width:min(92vw,520px);'
        + 'background:#b91c1c;color:#fff;padding:14px 20px;border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,0.35);'
        + 'z-index:10050;font-size:0.95em;line-height:1.45;font-weight:600;text-align:center;';
    t.textContent = msgPlain;
    document.body.appendChild(t);
    setTimeout(function () { try { t.remove(); } catch (_eRm) {} }, 7000);
}

function __genSignalerErreurPrep(msgHtml, opts) {
    opts = opts || {};
    if (typeof window.tab1ShowStatus === 'function') {
        window.tab1ShowStatus('error', msgHtml, { scroll: true });
    }
    __genToastErreur(String(msgHtml || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());
    if (opts.scrollTo) {
        if (typeof window.tab1HighlightWorkflowFromScroll === 'function') {
            window.tab1HighlightWorkflowFromScroll(opts.scrollTo);
        }
        setTimeout(function () {
            var target = document.querySelector(opts.scrollTo);
            if (target) {
                try { target.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (_eSc) {}
            }
        }, 120);
    } else if (typeof window.tab1ScrollToStep === 'function') {
        setTimeout(function () { try { window.tab1ScrollToStep(4); } catch (_eSt) {} }, 120);
    }
    if (typeof window.tab1ShowStatus !== 'function') {
        alert(msgHtml.replace(/<[^>]+>/g, ''));
    }
}

/**
 * Fonction PRINCIPALE: Préparer tout avant génération d'input
 * Appelée avant genererInputComplet()
 */
function preparerAvantGeneration() {
    console.log('\n\n🎯🎯🎯 PRÉPARATION COMPLÈTE AVANT GÉNÉRATION 🎯🎯🎯\n');

    if (!document.getElementById('section_5_type_calcul_chemins') &&
            typeof creerSection5TypeCalculChemins === 'function') {
        try { creerSection5TypeCalculChemins(); } catch (_eSec5) { console.warn(_eSec5); }
    }

    var calcType = __genLireCalcType();
    if (!calcType) {
        var calcEl = document.querySelector('#section_5_type_calcul_chemins #calc_type');
        if (calcEl) {
            calcEl.value = 'scf';
            if (typeof window.changerTypeCalculSimple === 'function') {
                try { window.changerTypeCalculSimple(); } catch (_eCt) {}
            }
            calcType = __genLireCalcType();
        }
    }
    if (!calcType) {
        __genSignalerErreurPrep(
            '❌ Choisissez un <strong>type de calcul</strong> (section 5) avant de générer.',
            { scrollTo: '#section_5_type_calcul_chemins' }
        );
        return false;
    }

    const materiau = document.getElementById('materiau_name')?.value.trim();

    if (typeof window.qeIsAuxInputType === 'function' && window.qeIsAuxInputType(calcType)) {
        if (!materiau) {
            __genSignalerErreurPrep(
                '❌ Indiquez le <strong>nom du matériau</strong> / <code>prefix</code> pour l\'input '
                + calcType + '.',
                { scrollTo: '#section_1_materiau' }
            );
            return false;
        }
        console.log('✅ Préparation OK (input auxiliaire ' + calcType + ')');
        return true;
    }
    
    // ÉTAPE 1: Vérifier que les champs de base sont remplis (pw.x)
    console.log('✓ ÉTAPE 1: Vérification des champs de base...');
    const ibrav = __genLireIbravWorkflow();
    const ntyp = parseInt(document.getElementById('ntyp')?.value, 10) || 0;
    const nat = parseInt(document.getElementById('nat')?.value, 10) || 0;
    
    console.log(`  Matériau: ${materiau || '❌ VIDE'}`);
    console.log(`  ibrav: ${ibrav || '❌ VIDE'}`);
    console.log(`  ntyp: ${ntyp || '❌ 0'}`);
    console.log(`  nat: ${nat || '❌ 0'}`);
    
    if (!materiau || !ibrav || ntyp <= 0 || nat <= 0) {
        var scrollTo = !materiau ? '#section_1_materiau'
            : (!ibrav ? '#section_2_structure' : '#section_3_especes');
        __genSignalerErreurPrep(
            '❌ Complétez les étapes 1 à 3 : <strong>matériau</strong>, <strong>ibrav</strong>, <strong>ntyp</strong> et <strong>nat</strong>.',
            { scrollTo: scrollTo }
        );
        return false;
    }
    
    // ÉTAPE 2: Vérifier et remplir les éléments
    console.log('\n✓ ÉTAPE 2: Vérification des éléments...');
    if (!document.getElementById('element_1') && typeof window.reconstruireChampElements === 'function') {
        window.reconstruireChampElements();
    }
    const elements = [];
    for (let i = 1; i <= ntyp; i++) {
        const elemField = document.getElementById(`element_${i}`);
        const value = elemField?.value.trim() || '';
        console.log(`  element_${i}: ${value || '❌ VIDE'}`);
        if (!value) {
            __genSignalerErreurPrep(
                `❌ L'élément <strong>element_${i}</strong> est vide — renseignez toutes les espèces (section 3).`,
                { scrollTo: '#section_3_especes' }
            );
            return false;
        }
        elements.push(value);
    }
    console.log(`  ✅ ${ntyp} éléments remplis`);
    
    // ÉTAPE 3: Générer ATOMIC_SPECIES
    console.log('\n✓ ÉTAPE 3: Génération de ATOMIC_SPECIES...');
    if (typeof genererAtomicSpecies !== 'function') {
        __genSignalerErreurPrep('❌ Module espèces atomiques indisponible (<code>genererAtomicSpecies</code>).');
        return false;
    }
    genererAtomicSpecies();
    
    // Vérifier que atomicSpeciesGlobal est rempli
    if (!window.atomicSpeciesGlobal || window.atomicSpeciesGlobal.trim().length === 0) {
        console.error('❌ atomicSpeciesGlobal vide après genererAtomicSpecies()');
        __genSignalerErreurPrep(
            '❌ <strong>ATOMIC_SPECIES</strong> vide — vérifiez les éléments et pseudopotentiels (section 3).'
        );
        return false;
    }
    console.log(`  ✅ ATOMIC_SPECIES généré (${window.atomicSpeciesGlobal.length} caractères)`);
    console.log(window.atomicSpeciesGlobal);

        if (typeof window.pwGenSyncHiddenFieldsFromWorkflow === 'function') {
            window.pwGenSyncHiddenFieldsFromWorkflow();
        }
        if (typeof window.pwGenNoncolinActive === 'function' && window.pwGenNoncolinActive() &&
                typeof window.nspin4Flow !== 'undefined' && window.nspin4Flow.applyWorkflowDefaults) {
            try { window.nspin4Flow.applyWorkflowDefaults('gen'); } catch (_eNcPrep) { console.warn(_eNcPrep); }
        }
        if (typeof window.pwGenRefreshHubbardPanel === 'function') {
        try { window.pwGenRefreshHubbardPanel(); } catch (_eHbPrep) { console.warn(_eHbPrep); }
    }
    
    // ÉTAPE 4: Vérifier les positions
    console.log('\n✓ ÉTAPE 4: Vérification des positions...');
    if (__genCompterPositionsRemplies(nat) < nat &&
            typeof reconstruirePositionsAtomiques === 'function') {
        try { reconstruirePositionsAtomiques(); } catch (_ePos) { console.warn(_ePos); }
    }

    let positionsRemplies = __genCompterPositionsRemplies(nat);

    if (positionsRemplies < nat && typeof genererPositionsAuto === 'function') {
        try {
            genererPositionsAuto({ silent: true });
            positionsRemplies = __genCompterPositionsRemplies(nat);
        } catch (_eAutoPos) { console.warn(_eAutoPos); }
    }
    
    if (positionsRemplies < nat) {
        __genSyncPositionsDepuisTextarea();
        positionsRemplies = __genCompterPositionsRemplies(nat);
    }

    if (positionsRemplies < nat &&
            (window.atomicPositionsContent && String(window.atomicPositionsContent).trim())) {
        positionsRemplies = nat;
    }
    
    if (positionsRemplies < nat) {
        __genSignalerErreurPrep(
            `❌ Positions manquantes (<strong>${positionsRemplies}/${nat}</strong>). `
            + 'Remplissez les coordonnées (section 4) ou cliquez <strong>Générer Auto</strong>.',
            { scrollTo: '#section_4_positions' }
        );
        return false;
    }
    console.log(`  ✅ ${positionsRemplies}/${nat} positions remplies`);
    
    // ÉTAPE 5: Générer ATOMIC_POSITIONS
    console.log('\n✓ ÉTAPE 5: Génération de ATOMIC_POSITIONS...');
    if (typeof mettreAJourFormat !== 'function') {
        __genSignalerErreurPrep('❌ Module positions indisponible (<code>mettreAJourFormat</code>).');
        return false;
    }
    mettreAJourFormat();
    
    // Vérifier que atomicPositionsContent est rempli
    if (!window.atomicPositionsContent || window.atomicPositionsContent.trim().length === 0) {
        if (!__genSyncPositionsDepuisTextarea()) {
            console.error('❌ atomicPositionsContent vide après mettreAJourFormat()');
            __genSignalerErreurPrep('❌ <strong>ATOMIC_POSITIONS</strong> n\'a pas pu être généré — vérifiez la section 4.');
            return false;
        }
    }
    console.log(`  ✅ ATOMIC_POSITIONS généré (${window.atomicPositionsContent.length} caractères)`);
    console.log(window.atomicPositionsContent);
    
    console.log('\n✅ TOUS LES VÉRIFICATIONS PASSÉES! Prêt pour génération.\n');
    return true;
}

/**
 * Wrapper pour genererInputComplet() avec préparation
 */
async function genererInputAvecPreparation() {
    console.log('🎯 Génération d\'input avec préparation complète...');

    if (typeof window.tab1SwitchMainTab === 'function') {
        var genPanel = document.getElementById('tab1_panel_generation');
        if (genPanel && !genPanel.classList.contains('active')) {
            window.tab1SwitchMainTab('generation');
        }
    }

    if (typeof window.tab1SetWorkflowPath === 'function') window.tab1SetWorkflowPath('direct');
    if (typeof window.tab1SetWorkflowStep === 'function') window.tab1SetWorkflowStep(5, 'generating');

    var btn = document.querySelector('#section_5_type_calcul_chemins .qe-action-btn--generate')
        || document.querySelector('button.qe-action-btn--generate[onclick*="genererInputAvecPreparation"]');
    if (!btn && document.activeElement && document.activeElement.tagName === 'BUTTON') {
        btn = document.activeElement;
    }
    if (btn && btn.tagName === 'BUTTON') {
        btn.disabled = true;
        btn.dataset.genPrevLabel = btn.innerHTML;
        btn.innerHTML = '⏳ Génération…';
    }

    try {
        if (!preparerAvantGeneration()) {
            console.error('❌ Préparation échouée');
            if (typeof window.tab1ClearWorkflowForced === 'function') window.tab1ClearWorkflowForced();
            return;
        }

        if (typeof window.pwGenSyncHiddenFieldsFromWorkflow === 'function') {
            window.pwGenSyncHiddenFieldsFromWorkflow();
        }
        if (typeof window.pwGenPrepareHubbardBeforeGenerate === 'function') {
            try {
                await Promise.race([
                    window.pwGenPrepareHubbardBeforeGenerate(),
                    new Promise(function (resolve) { setTimeout(resolve, 8000); })
                ]);
            } catch (_eHb) { console.warn(_eHb); }
        }
        if (typeof window.pwGenPrepareAfmStructure === 'function') {
            try { window.pwGenPrepareAfmStructure(); } catch (_eAfm) { console.warn(_eAfm); }
        }

        var genFn = window.genererInputComplet || genererInputComplet;
        console.log('\n🚀 Appel genererInputComplet()...');
        if (typeof genFn !== 'function') {
            __genSignalerErreurPrep('❌ Fonction <code>genererInputComplet</code> introuvable — rechargez la page.');
            return;
        }

        await genFn();
        console.log('✅ Input généré avec succès!');
        if (typeof window.tab1SetWorkflowStep === 'function') window.tab1SetWorkflowStep(5, 'done');
    } catch (err) {
        console.error('❌ Erreur génération input:', err);
        if (typeof window.tab1ClearWorkflowForced === 'function') window.tab1ClearWorkflowForced();
        __genSignalerErreurPrep(
            '❌ Erreur lors de la génération : <code>' + (err && err.message ? err.message : String(err)) + '</code>'
        );
    } finally {
        if (typeof window.tab1RefreshWorkflowTracker === 'function') window.tab1RefreshWorkflowTracker();
        if (btn && btn.tagName === 'BUTTON') {
            btn.disabled = false;
            btn.innerHTML = btn.dataset.genPrevLabel || '⚡ GÉNÉRER INPUT COMPLET';
        }
    }
}

window.preparerAvantGeneration = preparerAvantGeneration;
window.genererInputAvecPreparation = genererInputAvecPreparation;

console.log('✅ Script orchestration chargé');

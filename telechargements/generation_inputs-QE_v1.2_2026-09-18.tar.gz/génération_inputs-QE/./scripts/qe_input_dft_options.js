/**
 * Catalogue input_dft QE — généré par backend/extract_qe_dft_catalog.py
 * Source : QE 7.5 (XClib/qe_dft_list.f90, Modules/funct.f90)
 * Ne pas éditer à la main ; relancer le script extracteur après mise à jour QE.
 * Libxc : input_dft = 'XC-001i-004Li-012i-045Li-…'
 */
(function () {
    'use strict';

    /** @type {{label:string, opts:[string,string][]}}[] */
    var QE_INPUT_DFT_OPTGROUPS = [
        {
            label: 'Défaut',
            opts: [['', '(défaut — pseudopotentiel / ne pas forcer input_dft)']],
        },
        {
            label: "LDA",
            opts: [
                ["hf", "HF"],
                ["kli", "KLI"],
                ["lda", "LDA (alias → pz)"],
                ["lda_pw", "lda_pw — alias PW-LDA (→ pw)"],
                ["oep", "OEP"],
                ["pw", "PW"],
                ["pz", "PZ"],
                ["vwn-rpa", "VWN-RPA"],
            ],
        },
        {
            label: "GGA",
            opts: [
                ["b86bpbe", "B86BPBE"],
                ["b88", "B88"],
                ["blyp", "BLYP"],
                ["bp", "BP"],
                ["ev93", "EV93"],
                ["hcth", "HCTH"],
                ["olyp", "OLYP"],
                ["optb86b", "OPTB86B"],
                ["optbk88", "OPTBK88"],
                ["pbc", "PBC"],
                ["pbe", "★ PBE (GGA généraliste, usage courant)"],
                ["pbeq2d", "PBEQ2D"],
                ["pbesol", "★ PBESOL (souvent mieux pour géométries de solides)"],
                ["pw86pbe", "PW86PBE"],
                ["pw91", "PW91"],
                ["q2d", "Q2D (alias → pbeq2d)"],
                ["revpbe", "REVPBE"],
                ["rpbe", "RPBE"],
                ["sogga", "SOGGA"],
                ["wc", "WC"],
            ],
        },
        {
            label: "Hybrides",
            opts: [
                ["b3lyp", "B3LYP"],
                ["b3lyp-v1r", "B3LYP-V1R"],
                ["b86bpbex", "B86BPBEX"],
                ["b86bx", "b86bx — alias B86BPBEX"],
                ["bhahlyp", "BHAHLYP"],
                ["bhandhlyp", "BHANDHLYP (alias → bhahlyp)"],
                ["gaup", "GAUP"],
                ["gaupbe", "GAUPBE (alias → gaup)"],
                ["hse", "HSE"],
                ["pbe0", "PBE0"],
                ["x3lyp", "X3LYP"],
            ],
        },
        {
            label: "Méta-GGA",
            opts: [
                ["m06l", "M06L"],
                ["pbe-ah", "PBE-AH"],
                ["pbesol-ah", "PBESOL-AH"],
                ["r2scan", "R2SCAN"],
                ["rscan", "RSCAN"],
                ["sca0", "sca0 — alias SCAN0"],
                ["scan", "★ SCAN (méta‑GGA, coûteux, pseudos alignés requis)"],
                ["scan0", "SCAN0"],
                ["tb09", "TB09"],
                ["tpss", "TPSS"],
            ],
        },
        {
            label: "vdW non-local / rVV10",
            opts: [
                ["rvv10", "rVV10"],
                ["rvv10-scan", "rvv10-scan — rVV10 + SCAN"],
                ["vdw-df", "vdW-DF1"],
                ["vdw-df-ahcx", "vdW-DF-AHCX"],
                ["vdw-df-c09", "vdW-DF-C09"],
                ["vdw-df-c090", "vdw-df-c090 — vdW-DF-C09-0"],
                ["vdw-df-c6", "vdW-DF-C6"],
                ["vdw-df-cx", "vdW-DF-cx"],
                ["vdw-df-cx0", "vdW-DF-cx0"],
                ["vdw-df-cx0p", "vdW-DF-cx0p"],
                ["vdw-df-ob86", "vdw-df-ob86 — vdW-DF-optB86b"],
                ["vdw-df-obk8", "vdw-df-obk8 — vdW-DF-optB88"],
                ["vdw-df2", "vdW-DF2"],
                ["vdw-df2-0", "vdW-DF2-0 (hybride)"],
                ["vdw-df2-ah", "vdW-DF2-AH"],
                ["vdw-df2-ahbr", "vdW-DF2-AHBR"],
                ["vdw-df2-b86r", "vdW-DF2-B86R (rev-vdW-DF2)"],
                ["vdw-df2-br0", "vdW-DF2-br0"],
                ["vdw-df2-c09", "vdW-DF2-C09"],
                ["vdw-df3-opt1", "vdW-DF3-opt1"],
                ["vdw-df3-opt2", "vdW-DF3-opt2"],
            ],
        },
        {
            label: "BEEF",
            opts: [
                ["beef", "BEEF-vdW-DF2 (défaut)"],
                ["beef-vdw", "BEEF-vdW-DF2"],
                ["beef_lxc", "beef_lxc — BEEF-vdW (Libxc XC_GGA_XC_BEEFVDW)"],
            ],
        },
    ];

    /** Alias → valeur canonique (qe_dft_list / funct.f90) */
    var QE_INPUT_DFT_ALIASES = {
    "lda": "pz",
    "lda_pw": "pw",
    "q2d": "pbeq2d",
    "b86bx": "b86bpbex",
    "bhandhlyp": "bhahlyp",
    "gaupbe": "gaup",
    "sca0": "scan0"
};

    function optionExists(selectEl, wanted) {
        if (!wanted) return true;
        for (var i = 0; i < selectEl.options.length; i++) {
            if (selectEl.options[i].value === wanted)
                return true;
        }
        return false;
    }

    /** Évite les doublons d’id legacy / Tab1 restructuré */
    function resolveInputDftSelect(id) {
        if (id === 'pw_input_dft') {
            var tab1Sel = document.querySelector('#section_2_structure select#pw_input_dft');
            if (tab1Sel) return tab1Sel;
            var blockSel = document.querySelector('#gen_direct_input_dft_block select#pw_input_dft');
            if (blockSel) return blockSel;
        }
        return document.getElementById(id);
    }

    window.resolveInputDftSelect = resolveInputDftSelect;

    window.__qeInitTab1InputDft = function __qeInitTab1InputDft(preferred) {
        var sel = resolveInputDftSelect('pw_input_dft');
        if (!sel) return false;
        var val = (preferred != null && String(preferred).trim() !== '')
            ? String(preferred).trim()
            : (sel.value || 'pbe');
        if (!val) val = 'pbe';
        fillInputDftSelect(sel, val);
        return true;
    };

    /** @param {HTMLSelectElement | null | undefined} selectEl */
    function fillInputDftSelect(selectEl, selectedValue) {
        if (!selectEl) return;

        try {
            if (arguments.length < 2 && selectEl.value)
                selectedValue = selectEl.value;
        } catch (_) {}

        if (typeof selectedValue === 'undefined' || selectedValue === null)
            selectedValue = '';

        selectEl.innerHTML = '';

        QE_INPUT_DFT_OPTGROUPS.forEach(function (g) {
            var og = document.createElement('optgroup');
            og.label = g.label;
            g.opts.forEach(function (pair) {
                var opt = document.createElement('option');
                var val = pair[0];
                var lab = pair[1];
                opt.value = val;
                opt.textContent = lab || val;
                og.appendChild(opt);
            });
            selectEl.appendChild(og);
        });

        if (selectedValue && !optionExists(selectEl, selectedValue)) {
            var custom = document.createElement('option');
            custom.value = selectedValue;
            custom.textContent = selectedValue + ' (personnalisé)';
            var firstOg = selectEl.querySelector('optgroup');
            if (firstOg) firstOg.insertBefore(custom, firstOg.firstChild);
            else selectEl.appendChild(custom);
        }

        try {
            selectEl.value = selectedValue;
            if (!optionExists(selectEl, selectedValue))
                selectEl.value = '';
        } catch (_) {
            selectEl.value = '';
        }
    }

    function initInputDftSelects(ids) {
        var list = ids || [
            { id: 'pw_input_dft', def: 'pbe' },
            { id: 'cif_input_dft', def: '' },
            { id: 'gestion_pw_input_dft', def: 'pbe' },
            { id: 'modal_pw_input_dft', def: 'pbe' },
        ];
        list.forEach(function (entry) {
            var id;
            var def;
            if (typeof entry === 'string') {
                id = entry;
                def = (id === 'cif_input_dft') ? '' : 'pbe';
            } else {
                id = entry.id;
                def = (entry.def != null) ? entry.def : ((id === 'cif_input_dft') ? '' : 'pbe');
            }
            var sel = resolveInputDftSelect(id);
            if (sel) fillInputDftSelect(sel, def);
        });
    }

    window.QE_INPUT_DFT_OPTGROUPS = QE_INPUT_DFT_OPTGROUPS;
    window.QE_INPUT_DFT_ALIASES = QE_INPUT_DFT_ALIASES;
    window.fillInputDftSelect = fillInputDftSelect;
    window.initInputDftSelects = initInputDftSelects;

    document.addEventListener('DOMContentLoaded', function () {
        window.initInputDftSelects();
    });

    document.addEventListener('tab1Restructured', function () {
        setTimeout(function () {
            if (typeof window.__qeInitTab1InputDft === 'function') {
                window.__qeInitTab1InputDft('pbe');
            } else {
                window.initInputDftSelects([{ id: 'pw_input_dft', def: 'pbe' }]);
            }
        }, 0);
    });

    document.addEventListener('htmlFragmentsLoaded', function () {
        setTimeout(function () {
            window.initInputDftSelects([
                { id: 'cif_input_dft', def: '' },
                { id: 'pw_input_dft', def: 'pbe' },
            ]);
        }, 60);
    });
})();

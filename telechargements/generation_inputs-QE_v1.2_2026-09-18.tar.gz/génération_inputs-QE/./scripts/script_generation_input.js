// ═══════════════════════════════════════════════════════════════════════════
// GÉNÉRATION COMPLÈTE DU FICHIER INPUT QUANTUM ESPRESSO
// Intègre ATOMIC_SPECIES et ATOMIC_POSITIONS
// ═══════════════════════════════════════════════════════════════════════════

function __genInputApiBase() {
    if (typeof window.getGenInputsApiBase === 'function') return window.getGenInputsApiBase();
    try {
        var p = String(window.location.port || '');
        if (p === '5012') return window.location.origin || 'http://127.0.0.1:5012';
    } catch (_eP) {}
    return window.__GEN_INPUTS_STANDALONE__ ? 'http://127.0.0.1:5012' : 'http://localhost:5007';
}

function __genInputSaveErrorHint() {
    var base = __genInputApiBase();
    if (base.indexOf('5012') >= 0 || window.__GEN_INPUTS_STANDALONE__) {
        return 'Vérifiez que le serveur autonome est démarré :\n  cd ~/génération_inputs-QE && ./DEMARRER.sh\n  puis ouvrez http://127.0.0.1:5012';
    }
    return "Vérifiez que l'API QE est démarrée (port 5007) :\n  python3 /home/hiadsi/Interface-QE_v1/api_qe_ubuntu.py";
}

async function __genInputFetchJson(url, options) {
    var response = await fetch(url, options);
    var text = await response.text();
    var ct = (response.headers.get('content-type') || '').toLowerCase();
    var data = null;
    if (text && (ct.indexOf('json') >= 0 || /^\s*[\[{]/.test(text))) {
        try {
            data = JSON.parse(text);
        } catch (_eJ) {
            throw new Error('Réponse non-JSON de ' + url + ' : ' + text.slice(0, 120));
        }
    }
    if (!response.ok) {
        var errMsg = (data && (data.error || data.message)) || text.slice(0, 200) || ('HTTP ' + response.status);
        throw new Error(errMsg);
    }
    if (data === null) {
        throw new Error('Réponse vide ou non-JSON (' + response.status + ') depuis ' + url);
    }
    return data;
}

function __genInputDefaultPath(kind) {
    var cfg = window.QE_CONFIG || {};
    var root = (typeof window.qeProjectRoot === 'function') ? window.qeProjectRoot() : '';
    if (kind === 'inputs') {
        return cfg.INPUTS_DIRECT_DIR || cfg.INPUTS_GENERES_DIR || cfg.INPUTS_DIR
            || (typeof window.qeInputsDirectRoot === 'function' ? window.qeInputsDirectRoot() : '')
            || (root ? root + '/inputs_générés_direct' : '');
    }
    if (kind === 'outputs') {
        return cfg.OUTPUTS_DIR || (root ? root + '/outputs' : '');
    }
    if (kind === 'pseudos') {
        return cfg.PSEUDO_DIR || (root ? root + '/pseudos/PBE' : '');
    }
    return '';
}

async function __genInputResolveOutputsRoot() {
    if (typeof window.__gestResolveOutputsRoot === 'function') {
        try {
            var r = await window.__gestResolveOutputsRoot();
            if (r) return r;
        } catch (_eGr) {}
    }
    var base = __genInputApiBase();
    try {
        var ver = await __genInputFetchJson(base + '/api/version', { method: 'GET' });
        if (ver.outputs_root) return ver.outputs_root;
    } catch (_eVer) {}
    return __genInputDefaultPath('inputs');
}

async function __genInputSaveToServer(fichierComplet, contenu) {
    var base = __genInputApiBase();
    var payloadLegacy = JSON.stringify({ fichier: fichierComplet, contenu: contenu });
    var payloadModern = JSON.stringify({ path: fichierComplet, content: contenu });
    var lastErr = null;
    try {
        var data = await __genInputFetchJson(base + '/api/sauvegarder_fichier', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: payloadLegacy
        });
        if (data.success || data.ok) return data;
        lastErr = new Error(data.error || 'Erreur de sauvegarde');
    } catch (e1) {
        lastErr = e1;
    }
    try {
        var data2 = await __genInputFetchJson(base + '/api/files/write', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: payloadModern
        });
        if (data2.success || data2.ok) {
            return {
                success: true,
                ok: true,
                filepath: data2.path || data2.filepath || fichierComplet,
                fichier: data2.path || fichierComplet,
                path: data2.path || fichierComplet
            };
        }
        lastErr = new Error(data2.error || 'Erreur de sauvegarde');
    } catch (e2) {
        lastErr = e2;
    }
    throw lastErr || new Error('Erreur de sauvegarde');
}

/** Sauvegarde unifiée (génération directe) → inputs_générés_direct/<mat>/<mat>_<calc>.in */
async function __genInputSaveUnified(materialName, calcType, inputContent) {
    var mat = String(materialName || 'material').trim().replace(/[^A-Za-z0-9._-]+/g, '_') || 'material';
    var calc = String(calcType || 'scf').trim().replace(/[^A-Za-z0-9._-]+/g, '_') || 'scf';
    var outName = mat + '_' + calc + '.in';
    var relative = mat + '/' + outName;

    if (typeof window.__gestSaveInputToGenerated === 'function') {
        var sr = await window.__gestSaveInputToGenerated(mat, calc, inputContent, 'direct');
        if (sr.ok) {
            return {
                success: true,
                ok: true,
                path: sr.path,
                filepath: sr.path,
                fichier: sr.path,
                relative: sr.relative || relative,
                filename: sr.filename || outName
            };
        }
        return { success: false, ok: false, error: sr.error || 'sauvegarde échouée' };
    }

    try {
        var root = await __genInputResolveOutputsRoot();
        var fichierComplet = String(root).replace(/\/+$/, '') + '/' + relative;
        var data = await __genInputSaveToServer(fichierComplet, inputContent);
        return Object.assign({
            success: true,
            ok: true,
            relative: relative,
            filename: outName
        }, data);
    } catch (e) {
        return { success: false, ok: false, error: e.message || String(e) };
    }
}

function __genEscHtml(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/** Bandeau permanent sous l’aperçu — le chemin reste visible après le toast. */
function __genEnsureSaveBanner() {
    var host = document.getElementById('preview_input_container')
        || document.getElementById('input_preview_card')
        || document.getElementById('gen_input_preview_panel');
    if (!host) return null;
    var el = document.getElementById('direct_save_banner');
    if (!el) {
        el = document.createElement('div');
        el.id = 'direct_save_banner';
        el.className = 'qe-save-banner';
        el.setAttribute('role', 'status');
        var h4 = host.querySelector('h4');
        if (h4 && h4.parentNode === host) {
            host.insertBefore(el, h4.nextSibling);
        } else {
            host.insertBefore(el, host.firstChild);
        }
    }
    return el;
}

function __genShowSaveBanner(opts) {
    opts = opts || {};
    var el = __genEnsureSaveBanner();
    if (!el) return;
    var folder = opts.folder || 'inputs_générés_direct';
    var rel = opts.relative || opts.path || '';
    var ok = opts.ok !== false;
    el.style.display = 'block';
    el.className = 'qe-save-banner ' + (ok ? 'qe-save-banner--ok' : 'qe-save-banner--warn');
    if (ok) {
        el.innerHTML = '💾 <strong>Fichier enregistré</strong> — <code>'
            + __genEscHtml(folder + '/' + rel) + '</code>'
            + ' <button type="button" class="qe-save-banner-link" onclick="if(typeof ouvrirInputsExistantsRapide===\'function\')ouvrirInputsExistantsRapide();">'
            + 'Voir la liste</button>';
    } else {
        el.innerHTML = '⚠️ <strong>Sauvegarde non confirmée</strong> — cliquez <strong>SAUVEGARDER</strong>.'
            + (opts.error ? ' <code>' + __genEscHtml(opts.error) + '</code>' : '');
    }
}

/**
 * Rafraîchit la liste des .in sans ouvrir le panneau CIF / « Autres entrées »
 * (évite d’afficher l’UI CIF sous la visualisation 3D).
 */
window.__genRevealSavedInputsList = function __genRevealSavedInputsList(opts) {
    opts = opts || {};
    var openPanel = opts.openPanel === true;
    var det = document.getElementById('tab1_autres_entrees');
    var zone = document.getElementById('zone_resultats_fichiers');
    var gest = document.getElementById('subsection_gestion');

    // Toujours masquer le panneau CIF complet hors onglet CIF
    if (gest && gest.style.display !== 'none') {
        var onCifTab = false;
        try {
            var cifBtn = document.querySelector('#tab1_main_nav .tab1-main-nav-btn[data-tab1-panel="cif"]');
            onCifTab = !!(cifBtn && cifBtn.classList.contains('active'));
        } catch (_eTab) {}
        if (!onCifTab) gest.style.display = 'none';
    }

    if (openPanel) {
        if (typeof window.tab1PrepareAutresEntrees === 'function') {
            try { window.tab1PrepareAutresEntrees(); } catch (_ePrep) {}
        } else {
            if (det) det.open = true;
            if (zone) zone.style.display = 'block';
        }
    }

    // Rafraîchir la liste seulement si le panneau est déjà ouvert (sinon rien à montrer)
    var panelOpen = openPanel || (det && det.open && zone && zone.style.display !== 'none');
    if (panelOpen && typeof window.listerInputsExistants === 'function') {
        try { window.listerInputsExistants(); } catch (_eLi) {}
    }
};

/** Masque les morceaux d’UI CIF qui peuvent fuiter sous l’aperçu génération. */
window.__genHideCifUiLeak = function __genHideCifUiLeak() {
    var gest = document.getElementById('subsection_gestion');
    if (gest) gest.style.display = 'none';
    var bar = document.getElementById('cif_floating_action_bar');
    if (bar) bar.style.display = 'none';
    var det = document.getElementById('tab1_autres_entrees');
    if (det) det.open = false;
    var zone = document.getElementById('zone_resultats_fichiers');
    if (zone) zone.style.display = 'none';
    // Status CIF éventuellement injecté dans la zone rapide
    var st = document.getElementById('gestion_fichiers_status');
    if (st && zone && zone.contains(st)) {
        st.innerHTML = '';
        st.style.display = 'none';
    }
};

function __genInputFlashSaveOk(savedPath, relative, folder) {
    var folderLabel = folder || 'inputs_générés_direct';
    var rel = relative || savedPath || '';
    __genShowSaveBanner({ ok: true, folder: folderLabel, relative: rel, path: savedPath });
    var notif = document.createElement('div');
    notif.className = 'qe-save-toast';
    notif.innerHTML = '✅ Input sauvegardé<br><small>📁 '
        + __genEscHtml(folderLabel + '/' + rel) + '</small>';
    document.body.appendChild(notif);
    setTimeout(function () { try { notif.remove(); } catch (_e) {} }, 4500);
    // Ne pas ouvrir le panneau CIF — le bandeau + « Voir la liste » suffisent
    if (typeof window.__genHideCifUiLeak === 'function') {
        try { window.__genHideCifUiLeak(); } catch (_eHide) {}
    }
}

/** Détecte positions manquantes ou superposées (ex. tout à 0,0,0). */
function detecterPositionsAtomiquesInvalides(posText, natAttendu) {
    if (!posText || !String(posText).trim()) return 'section vide';
    var lines = String(posText).split(/\r?\n/).filter(function (l) {
        var t = l.trim();
        return t && !/^ATOMIC_POSITIONS/i.test(t);
    });
    if (lines.length < 1) return 'aucune ligne d\'atome';
    var coords = [];
    lines.forEach(function (line) {
        var p = line.trim().split(/\s+/);
        if (p.length < 4) return;
        var x = parseFloat(p[1]), y = parseFloat(p[2]), z = parseFloat(p[3]);
        if (isNaN(x) || isNaN(y) || isNaN(z)) return;
        coords.push(x.toFixed(6) + ',' + y.toFixed(6) + ',' + z.toFixed(6));
    });
    if (coords.length < 1) return 'coordonnées illisibles';
    if (natAttendu && coords.length < natAttendu) {
        return 'seulement ' + coords.length + ' atome(s) sur ' + natAttendu + ' attendu(s)';
    }
    var uniq = {};
    coords.forEach(function (k) { uniq[k] = (uniq[k] || 0) + 1; });
    var keys = Object.keys(uniq);
    if (keys.length === 1 && coords.length > 1) {
        return 'tous les atomes sont à la même position (' + keys[0].replace(/,/g, ' ') + ')';
    }
    for (var i = 0; i < keys.length; i++) {
        if (uniq[keys[i]] > 1) {
            return 'position dupliquée : ' + keys[i].replace(/,/g, ' ');
        }
    }
    return '';
}
window.detecterPositionsAtomiquesInvalides = detecterPositionsAtomiquesInvalides;

/**
 * Créer la section de génération d'input
 */
function creerSectionGenerationInput(opts) {
    opts = opts || {};
    console.log('📝 Création de la section génération d\'input...');
    
    var existingGen = document.getElementById('section_generation_input');
    if (existingGen && !opts.force) {
        console.log('⚠️ Section génération input déjà créée, annulation');
        return;
    }
    if (existingGen) existingGen.remove();

    function _tg(k) { return (typeof window.t === 'function') ? window.t(k) : k; }
    
    // ⭐ VÉRIFIER D'ABORD si la section existe déjà — géré ci-dessus
    if (false && document.getElementById('section_generation_input')) {
        console.log('⚠️ Section génération input déjà créée, annulation');
        return;
    }
    
    // Chercher un bon endroit pour insérer (après type de calcul QE)
    // Accepte l'ID original OU l'alias créé par script_interface_parametres_qe_simple.js
    const typeCalculSection = document.getElementById('section_type_calcul') ||
                              document.getElementById('section_5_type_calcul_chemins');
    
    if (!typeCalculSection) {
        console.warn('⚠️ Section type calcul non trouvée! Sera créée via événement...');
        return; // Ne pas créer de boucle, laisser l'événement gérer
    }
    
    const section = document.createElement('div');
    section.id = 'section_generation_input';
    section.style.cssText = `
        margin-top: 30px;
        padding: 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: 2px solid #667eea;
        border-radius: 10px;
    `;
    
    section.innerHTML = `
        <div style="margin-bottom:20px;">
            <h3 style="color: white; margin: 0 0 4px 0;" data-i18n="gen.title">${_tg('gen.title')}</h3>
            <small style="color:rgba(255,255,255,0.7);" data-i18n="gen.hint">${_tg('gen.hint')}</small>
        </div>
        <style>
        @keyframes pulse-visu {
            0%,100% { box-shadow: 0 3px 10px rgba(0,188,212,0.4); }
            50%      { box-shadow: 0 3px 20px rgba(0,188,212,0.8); }
        }
        </style>
        
        <div style="display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 15px; align-items:center;">
            <button onclick="genererInputAvecPreparation()" style="
                padding: 12px 28px;
                background: #4caf50;
                color: white; border: none; border-radius: 5px;
                cursor: pointer; font-weight: bold; font-size: 1.05em;
                box-shadow: 0 2px 8px rgba(76,175,80,0.4);
            ">${_tg('gen.btn_generate')}</button>
            
            <button onclick="previewInput()" style="
                padding: 12px 20px; background: #2196f3;
                color: white; border: none; border-radius: 5px;
                cursor: pointer; font-weight: bold; font-size: 1em;
            " data-i18n="gen.btn_preview">${_tg('gen.btn_preview')}</button>
            
            <button onclick="copierInputComplet()" style="
                padding: 12px 20px; background: #ff9800;
                color: white; border: none; border-radius: 5px;
                cursor: pointer; font-weight: bold; font-size: 1em;
            " data-i18n="gen.btn_copy">${_tg('gen.btn_copy')}</button>
            
            <button onclick="telechargerInput()" style="
                padding: 12px 20px; background: #9c27b0;
                color: white; border: none; border-radius: 5px;
                cursor: pointer; font-weight: bold; font-size: 1em;
            " data-i18n="gen.btn_download">${_tg('gen.btn_download')}</button>

            <button onclick="ouvrirStructureExterne('xcrysden')" id="btn_visu3d_main" style="
                padding: 12px 20px;
                background: linear-gradient(135deg, #1565c0 0%, #0d47a1 100%);
                color: white; border: none; border-radius: 5px;
                cursor: pointer; font-weight: bold; font-size: 1em;
                box-shadow: 0 3px 8px rgba(21,101,192,0.4);
            " title="Ouvrir la structure dans XCrysDen (maille cristalline)">📐 XCrysDen</button>

            <button onclick="ouvrirStructureExterne('vesta')" style="
                padding: 12px 20px;
                background: linear-gradient(135deg, #e65100 0%, #ff9800 100%);
                color: white; border: none; border-radius: 5px;
                cursor: pointer; font-weight: bold; font-size: 1em;
            " title="Ouvrir dans VESTA (si installé)">🔬 VESTA</button>
        </div>
        
        <div id="gen_input_preview_panel" style="
            margin-top: 20px;
            padding: 15px;
            background: white;
            color: #000;
            border-radius: 8px;
            border: 2px solid #667eea;
            display: none;
        ">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                <h4 style="color: #667eea; margin: 0;" data-i18n="gen.preview_title">${_tg('gen.preview_title')}</h4>
                <button onclick="sauvegarderInputModifie()" style="
                    padding: 10px 20px;
                    background: linear-gradient(135deg, #4caf50 0%, #45a049 100%);
                    color: white;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    font-weight: bold;
                    font-size: 1em;
                    box-shadow: 0 2px 8px rgba(76, 175, 80, 0.3);
                " data-i18n="gen.btn_save_mod">${_tg('gen.btn_save_mod')}</button>
                
                <button onclick="telechargerInputSurPC()" style="
                    padding: 10px 20px;
                    background: linear-gradient(135deg, #2196f3 0%, #1976d2 100%);
                    color: white; border: none; border-radius: 5px;
                    cursor: pointer; font-weight: bold; font-size: 1em;
                    box-shadow: 0 2px 8px rgba(33, 150, 243, 0.3);
                " data-i18n="gen.btn_save_pc">${_tg('gen.btn_save_pc')}</button>
            </div>
            <textarea id="input_content" style="
                width: 100%;
                height: 500px;
                font-family: 'Courier New', monospace;
                font-size: 0.9em;
                line-height: 1.5;
                background: #f5f5f5;
                padding: 15px;
                border: 2px solid #ddd;
                border-radius: 5px;
                resize: vertical;
                box-sizing: border-box;
            "></textarea>
            <div style="margin-top: 10px; padding: 10px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 5px;" data-i18n="gen.preview_tip" data-i18n-html="1">
                ${_tg('gen.preview_tip')}
            </div>
        </div>
    `;
    
    // Insérer APRÈS section_type_calcul
    typeCalculSection.parentElement.insertBefore(section, typeCalculSection.nextElementSibling);
    
    console.log('✅ Section génération input créée APRÈS section_type_calcul');
    
    // Initialiser les valeurs des chemins depuis localStorage (comme aide)
    setTimeout(() => {
        initialiserCheminsInputs();
    }, 500);
}
window.creerSectionGenerationInput = creerSectionGenerationInput;

/**
 * Initialiser les champs de chemins avec les valeurs de localStorage
 * (comme valeurs par défaut pratiques)
 */
function initialiserCheminsInputs() {
    console.log('🔧 Initialisation des chemins depuis localStorage...');

    const outDirInput  = document.getElementById('input_outdir');
    const pseudoDirInput = document.getElementById('input_pseudo_dir');

    if (!outDirInput || !pseudoDirInput) {
        console.warn('⚠️ Inputs de chemins non trouvés');
        return;
    }

    // Lire depuis window.QE_CONFIG (config_chemins.js), puis fallbacks localStorage legacy
    const savedOutputs = (window.QE_CONFIG && window.QE_CONFIG.OUTPUTS_DIR)
        || localStorage.getItem('qe_path_outputs')
        || localStorage.getItem('path_outputs')
        || __genInputDefaultPath('outputs');

    const savedPseudos = (window.QE_CONFIG && window.QE_CONFIG.PSEUDO_DIR)
        || localStorage.getItem('qe_path_pseudos')
        || localStorage.getItem('path_pseudos')
        || __genInputDefaultPath('pseudos');

    if (!outDirInput.value) {
        outDirInput.value = savedOutputs;
        console.log(`  ✓ outdir initialisé: ${savedOutputs}`);
    }

    if (!pseudoDirInput.value) {
        pseudoDirInput.value = savedPseudos;
        console.log(`  ✓ pseudo_dir initialisé: ${savedPseudos}`);
    }

    console.log('✅ Chemins initialisés');
}

/**
 * Afficher les chemins configurés
 * [DEPRECATED] - Les chemins sont maintenant dans des inputs éditables
 */
/*
function afficherCheminsConfigures() {
    // Cette fonction n'est plus nécessaire
    // Les chemins sont maintenant configurés directement via les inputs éditables
}
*/

/**
 * Récupérer les données d'ATOMIC_SPECIES
 */
function obtenirAtomicSpecies() {
    console.log('\n📥 obtenirAtomicSpecies() appelée:');
    console.log('  window.atomicSpeciesGlobal:', window.atomicSpeciesGlobal);
    console.log('  Type:', typeof window.atomicSpeciesGlobal);
    console.log('  Longueur:', window.atomicSpeciesGlobal?.length || 0);
    
    const content = window.atomicSpeciesGlobal || '';
    
    if (!content || content.trim().length === 0) {
        console.error('  ❌ ATOMIC_SPECIES VIDE!');
        console.log('  Contenu exact:', JSON.stringify(content));
        return '';
    }
    
    console.log('  ✅ ATOMIC_SPECIES OK:');
    console.log(content);
    
    return content;
}

/**
 * Récupérer les données d'ATOMIC_POSITIONS
 */
function obtenirAtomicPositions() {
    console.log('\n📥 obtenirAtomicPositions() appelée:');
    console.log('  window.atomicPositionsContent:', window.atomicPositionsContent);
    console.log('  Type:', typeof window.atomicPositionsContent);
    console.log('  Longueur:', window.atomicPositionsContent?.length || 0);
    
    const content = window.atomicPositionsContent || '';
    
    if (!content || content.trim().length === 0) {
        console.error('  ❌ ATOMIC_POSITIONS VIDE!');
        console.log('  Contenu exact:', JSON.stringify(content));
        return '';
    }
    
    console.log('  ✅ ATOMIC_POSITIONS OK:');
    console.log(content);
    
    return content;
}

/**
 * Récupérer les chemins configurés
 */
function obtenirCheminsConfigures() {
    // Lire depuis window.QE_CONFIG (source principale), puis fallbacks legacy
    const cfg = window.QE_CONFIG || {};

    const pathInputs  = cfg.INPUTS_GENERES_DIR
        || localStorage.getItem('qe_path_inputs')
        || localStorage.getItem('path_inputs')
        || __genInputDefaultPath('inputs');

    const pathOutputs = cfg.OUTPUTS_DIR
        || localStorage.getItem('qe_path_outputs')
        || localStorage.getItem('path_outputs')
        || __genInputDefaultPath('outputs');

    const pathPseuodos = cfg.PSEUDO_DIR
        || localStorage.getItem('qe_path_pseudos')
        || localStorage.getItem('path_pseudos')
        || __genInputDefaultPath('pseudos');

    console.log('📁 Chemins configurés:', { inputs: pathInputs, outputs: pathOutputs, pseudos: pathPseuodos });

    return { inputs: pathInputs, outputs: pathOutputs, pseudos: pathPseuodos };
}

/**
 * Récupérer les paramètres du calcul
 */
function obtenirParametresCalcul() {
    const calcEl = document.querySelector('#section_5_type_calcul_chemins #calc_type')
        || document.getElementById('calc_type');
    const calcType = (calcEl && String(calcEl.value || '').trim()) || 'scf';
    
    // ⭐ Récupérer les chemins depuis la NOUVELLE section 5
    let outdir = document.getElementById('path_outputs_field')?.value;
    let pseudoDir = document.getElementById('path_pseudos_field')?.value;
    
    // Fallback: anciens champs puis QE_CONFIG puis constantes correctes
    if (!outdir) outdir = document.getElementById('input_outdir')?.value;
    if (!outdir) outdir = __genInputDefaultPath('outputs');
    if (!pseudoDir) pseudoDir = document.getElementById('input_pseudo_dir')?.value;
    if (!pseudoDir) pseudoDir = __genInputDefaultPath('pseudos');
    if (typeof window.pwGenNoncolinActive === 'function' && window.pwGenNoncolinActive() &&
            typeof window.pwGenFrPseudoDir === 'function') {
        pseudoDir = window.pwGenFrPseudoDir();
    }
    
    console.log('📁 Chemins récupérés pour l\'input:');
    console.log(`  outdir: ${outdir}`);
    console.log(`  pseudo_dir: ${pseudoDir}`);
    
    var prefixVal = (document.getElementById('prefix_name')?.value || '').trim();
    var materiauVal = (document.getElementById('materiau_name')?.value || '').trim();
    var ibravEl = document.getElementById('ibrav') || document.getElementById('pw_input_ibrav');
    return {
        materiau: prefixVal || materiauVal || 'material',
        materiau_label: materiauVal || prefixVal || 'material',
        ibrav: (ibravEl && String(ibravEl.value || '').trim()) || '1',
        groupe: (document.getElementById('groupe_espace_select')?.value || '').trim(),
        ntyp: parseInt(document.getElementById('ntyp')?.value) || 1,
        nat: parseInt(document.getElementById('nat')?.value) || 1,
        calculation: calcType,  // ⭐ Type de calcul sélectionné
        ecutwfc: document.getElementById('ecutwfc')?.value || '50',
        ecutrho: document.getElementById('ecutrho')?.value || '200',
        functional: document.getElementById('functional')?.value || 'PBE',
        kpoints: document.getElementById('kpoints')?.value || '2 2 2',
        // ⭐ PARAMÈTRES DE MAILLE (IDs corrects: param_a, param_b, param_c)
        a: document.getElementById('param_a')?.value || '5.0',
        b: document.getElementById('param_b')?.value || '5.0',
        c: document.getElementById('param_c')?.value || '5.0',
        cosab: document.getElementById('param_cosab')?.value || '0.0',
        cosac: document.getElementById('param_cosac')?.value || '0.0',
        cosbc: document.getElementById('param_cosbc')?.value || '0.0',
        // ⭐ Chemins depuis les inputs de la page (pour l'input .in)
        pathOutputs: outdir,
        pathPseuodos: pseudoDir
    };
}

/** Valeur Fortran (.true./.false.) pour &SYSTEM — prend en charge <select> ou ancienne checkbox. */
function lireLspinorbFortran() {
    const el = document.getElementById('lspinorb');
    if (!el) return '.false.';
    const tag = String(el.tagName || '').toUpperCase();
    const typ = String(el.type || '').toLowerCase();
    if (tag === 'INPUT' && typ === 'checkbox') {
        return el.checked ? '.true.' : '.false.';
    }
    const v = String(el.value || '').trim();
    if (v === '.true.' || v === '.false.') return v;
    return '.false.';
}

/**
 * Mode magnétisme pour &SYSTEM : panneau avancé (radios) prioritaire si déjà « non_colin »,
 * sinon prise en compte du sélecteur #nspin (1 / 2 / 4) du formulaire principal.
 */
function magnetismeEffectifPourSystem() {
    let typeMag = window.typeMagnetisme || 'non_mag';
    const nspinSel = document.getElementById('nspin')?.value;
    if (typeMag !== 'non_colin') {
        if (nspinSel === '4') typeMag = 'non_colin';
        else if (nspinSel === '2') typeMag = 'mag';
        else if (nspinSel === '1') typeMag = 'non_mag';
    }
    return typeMag;
}

/** Chemin k crystal_b selon ibrav (pw.x bands). */
function __genBandsKpathCrystalB(ibrav) {
    var ib = parseInt(ibrav, 10) || 0;
    if (ib === 2) {
        return 'K_POINTS crystal_b\n5\n0.0000 0.0000 0.0000 50  ! Gamma\n0.5000 0.0000 0.5000 50  ! X\n0.5000 0.2500 0.7500 50  ! W\n0.0000 0.0000 0.0000 50  ! Gamma\n0.5000 0.5000 0.5000 1   ! L';
    }
    if (ib === 3) {
        return 'K_POINTS crystal_b\n4\n0.0000 0.0000 0.0000 50  ! Gamma\n0.5000 -0.5000 0.5000 50  ! H\n0.0000 0.0000 0.5000 50  ! N\n0.0000 0.0000 0.0000 1   ! Gamma';
    }
    if (ib === 4) {
        return 'K_POINTS crystal_b\n4\n0.0000 0.0000 0.0000 50  ! Gamma\n0.5000 0.0000 0.0000 50  ! M\n0.3333 0.3333 0.0000 50  ! K\n0.0000 0.0000 0.0000 1   ! Gamma';
    }
    return 'K_POINTS crystal_b\n4\n0.0000 0.0000 0.0000 50  ! Gamma\n0.5000 0.0000 0.0000 50  ! X\n0.5000 0.5000 0.0000 50  ! M\n0.0000 0.0000 0.0000 1   ! Gamma';
}

function __genOccupationsBlock(calcType) {
    var c = String(calcType || 'scf').toLowerCase();
    if (c === 'nscf') {
        return "    occupations = 'tetrahedra'\n";
    }
    return "    occupations = 'smearing'\n    smearing = 'cold'\n    degauss = 0.02\n";
}

function __genNbndLine(nat, calcType) {
    var c = String(calcType || '').toLowerCase();
    if (c !== 'nscf' && c !== 'bands') return '';
    var n = parseInt(nat, 10) || 1;
    return '    nbnd = ' + Math.max(8, n * 8) + '\n';
}

/**
 * Ajustements finaux de compatibilité QE 7.5 appliqués à TOUS les inputs générés.
 * (tous matériaux + tous types de calcul)
 */
function appliquerCompatibiliteQe75(inputContent, params) {
    var text = String(inputContent || '');
    if (!text.trim()) return text;

    // 1) Forcer pseudo_dir depuis la config active (évite "./pseudos" incohérent).
    var pseudoDir = String((params && params.pathPseuodos) || '').trim();
    if (pseudoDir) {
        var safePseudoDir = pseudoDir.replace(/\\/g, '/').replace(/'/g, "\\'");
        if (/^\s*pseudo_dir\s*=/im.test(text)) {
            text = text.replace(/^\s*pseudo_dir\s*=\s*'[^']*'/im, "    pseudo_dir = '" + safePseudoDir + "'");
        }
    }

    // 2) Harmoniser le pseudo oxygène attendu dans votre jeu QE 7.5.
    text = text.replace(/\bO\.pbe_v1\.2\.uspp\.F\.UPF\b/g, 'O_pbe_v1.2.uspp.F.UPF');

    // 3) QE n'accepte pas nspin=4 : on conserve noncolin + lspinorb uniquement.
    text = text.replace(/^[ \t]*nspin\s*=\s*4\s*$/gim, '');

    // 4) Détection pseudos .rel- (full relativistic) → forcer noncolin=.true.
    //    QE 7.5 refuse nspin=2 avec des pseudos full-relativistic (.rel-).
    //    Si un pseudo .rel- est détecté et nspin=2 présent, on bascule en noncolin.
    var hasRelPseudo = text.match(/\b[A-Z][a-z]?\.rel-/i);
    if (hasRelPseudo && /^[ \t]*nspin\s*=\s*2\s*$/im.test(text)) {
        text = text.replace(/^[ \t]*nspin\s*=\s*2\s*$/gim, '');
        // Supprimer starting_magnetization (incompatible avec noncolin : QE les ignore,
        // mais leur présence prête à confusion dans un contexte non-colinéaire)
        text = text.replace(/^[ \t]*starting_magnetization\s*\(\s*\d+\s*\)\s*=[^\n]*\n?/gim, '');
        // Supprimer tot_magnetization également (inutilisé en non-colinéaire)
        text = text.replace(/^[ \t]*tot_magnetization\s*=[^\n]*\n?/gim, '');
        // Ajouter noncolin=.true. et lspinorb=.true. dans &SYSTEM si pas déjà présents
        if (!/noncolin\s*=\s*\.true\./i.test(text)) {
            text = text.replace(
                /^(\s*)(&SYSTEM\b)/im,
                '$1$2\n    ! ⚠️ Auto-détection : pseudo .rel- (full-rel) → noncolin .true. (nspin=2 retiré)\n    noncolin = .true.\n    lspinorb = .true.'
            );
        }
        // Notification utilisateur (une seule fois par session)
        if (typeof window._relPseudoNotified === 'undefined') {
            window._relPseudoNotified = true;
            console.info(
                '%c⚠️ Override auto : pseudo .rel- détecté → bascule en noncolin=.true.',
                'background:#ff9800;color:#fff;padding:4px 8px;border-radius:4px;font-weight:bold;'
            );
            // Notification visuelle si disponible
            if (typeof window.tab1ShowStatus === 'function') {
                window.tab1ShowStatus('warn',
                    '⚠️ Pseudo .rel- (full-relativistic) détecté → bascule automatique en <code>noncolin=.true.</code>'
                );
            }
        }
    }

    return text;
}

function qe75ExtrairePseudoDir(inputContent) {
    var m = String(inputContent || '').match(/^\s*pseudo_dir\s*=\s*'([^']+)'/im);
    return m ? String(m[1] || '').trim() : '';
}

function qe75ExtraireAtomicSpeciesRows(inputContent) {
    var text = String(inputContent || '');
    var m = text.match(/^\s*ATOMIC_SPECIES\s*\n([\s\S]*?)(?=^\s*ATOMIC_POSITIONS\b|^\s*K_POINTS\b|^\s*HUBBARD\b|\s*$)/im);
    if (!m) return [];
    return String(m[1] || '')
        .split(/\r?\n/)
        .map(function (l) { return l.trim(); })
        .filter(function (l) { return !!l; });
}

function qe75AnalyserHubbard(inputContent) {
    var text = String(inputContent || '');
    var hasLegacy = /\bHubbard_U\s*\(/i.test(text) || /\bHubbard_J0\s*\(/i.test(text);
    var hasCard = /^\s*HUBBARD(?:\s*\(|\s+\S)/im.test(text);
    var rows = [];
    var m = text.match(/^\s*HUBBARD[^\n]*\n([\s\S]*?)(?=^\s*K_POINTS\b|\s*$)/im);
    if (m) {
        rows = String(m[1] || '').split(/\r?\n/).map(function (l) { return l.trim(); }).filter(function (l) { return !!l; });
    }
    return {
        hasLegacy: hasLegacy,
        hasCard: hasCard,
        rows: rows
    };
}

async function verifierCompatibiliteQe75Strict(inputContent, opts) {
    opts = opts || {};
    var forSave = !!opts.forSave;
    var text = String(inputContent || '');
    var erreurs = [];
    var avertissements = [];

    if (!text.trim()) {
        erreurs.push('Contenu input vide.');
        if (!opts.silent) alert('❌ ' + erreurs.join('\n'));
        return { ok: false, errors: erreurs, warnings: avertissements };
    }

    if (forSave) {
        var hubSave = qe75AnalyserHubbard(text);
        if (hubSave.hasLegacy) {
            avertissements.push('Hubbard legacy (Hubbard_U) détecté — carte HUBBARD QE 7.5 recommandée.');
        }
        if (!qe75ExtrairePseudoDir(text)) {
            avertissements.push('pseudo_dir absent ou vide dans l\'input.');
        }
        if (!qe75ExtraireAtomicSpeciesRows(text).length) {
            avertissements.push('ATOMIC_SPECIES absent ou vide.');
        }
        if (avertissements.length && !opts.silent && typeof window.tab1ShowStatus === 'function') {
            window.tab1ShowStatus('warn', '⚠️ ' + avertissements.join(' · '));
        }
        return { ok: true, errors: [], warnings: avertissements };
    }

    var hub = qe75AnalyserHubbard(text);
    if (hub.hasLegacy) {
        erreurs.push("Bloc Hubbard legacy détecté (Hubbard_U / Hubbard_J0). Utilisez la syntaxe HUBBARD de QE 7.5.");
    }
    if (hub.hasCard) {
        var hasBadRows = hub.rows.some(function (r) {
            if (!/^\s*U\s+/i.test(r)) return false;
            // Exiger un label orbital explicite du style Gd-4f, V-3d...
            return !/^\s*U\s+[A-Za-z][A-Za-z0-9]*-[spdfgh][0-9]?\s+[-+0-9.eEdD]+/i.test(r);
        });
        if (hasBadRows) {
            erreurs.push("Certaines lignes HUBBARD sont ambiguës pour QE 7.5 (attendu: U Gd-4f 6.5, U V-3d 4.0, ...).");
        }
    }

    var pseudoDir = qe75ExtrairePseudoDir(text);
    var speciesRows = qe75ExtraireAtomicSpeciesRows(text);
    var pseudoFiles = speciesRows.map(function (row) {
        var p = row.split(/\s+/);
        return p.length >= 3 ? p[p.length - 1] : '';
    }).filter(function (x) { return !!x; });

    if (!pseudoDir) {
        erreurs.push("pseudo_dir introuvable dans l'input.");
    } else if (!pseudoFiles.length) {
        erreurs.push("ATOMIC_SPECIES introuvable ou vide.");
    } else {
        try {
            var listData = await __genInputFetchJson(__genInputApiBase() + '/api/files/list_dir', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ directory: pseudoDir })
            });
            var names = (listData && listData.files ? listData.files : [])
                .map(function (f) {
                    if (typeof f === 'string') return f.trim().toLowerCase();
                    if (f && f.name) return String(f.name).trim().toLowerCase();
                    return '';
                })
                .filter(function (n) { return !!n; });
            if (!names.length) {
                avertissements.push(
                    "pseudo_dir vide ou inaccessible — sauvegarde autorisée ; copiez vos .UPF avant de lancer pw.x."
                );
            } else {
                var missing = pseudoFiles.filter(function (pf) {
                    return names.indexOf(String(pf).toLowerCase()) < 0;
                });
                if (missing.length) {
                    var msg = "Pseudopotentiels introuvables dans pseudo_dir: " + missing.join(', ');
                    if (forSave) {
                        avertissements.push(msg);
                    } else {
                        erreurs.push(msg);
                    }
                }
            }
        } catch (e) {
            avertissements.push("Vérification des fichiers .UPF non disponible (API): " + (e.message || e));
        }
    }

    if (erreurs.length) {
        var msg = "❌ Profil QE 7.5 strict: corrections requises avant sauvegarde\n\n- "
            + erreurs.join('\n- ');
        if (avertissements.length) msg += "\n\n⚠️ " + avertissements.join('\n⚠️ ');
        if (!opts.silent) alert(msg);
        return { ok: false, errors: erreurs, warnings: avertissements };
    }

    if (avertissements.length && !opts.silent) {
        alert("⚠️ Profil QE 7.5 strict: avertissement\n\n- " + avertissements.join('\n- '));
    }
    return { ok: true, errors: [], warnings: avertissements };
}

/**
 * Générer un input auxiliaire (dos.x, ph.x, …) via API 7.5+
 */
async function genererInputAuxComplet(params) {
    params = params || obtenirParametresCalcul();
    var pkg = params.calculation;
    var apiBase = (typeof window.getGenInputsApiBase === 'function')
        ? window.getGenInputsApiBase() : 'http://127.0.0.1:5012';
    var prefix = params.materiau || 'material';
    var outdir = (params.pathOutputs || './out') + '/' + prefix + '/';

    if (typeof window.tab1ShowStatus === 'function') {
        window.tab1ShowStatus('info', '⏳ Génération template <strong>' + pkg + '</strong>…');
    }

    try {
        var r = await fetch(apiBase + '/api/qe/build_aux', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(Object.assign({
                package: pkg,
                prefix: prefix,
                outdir: outdir,
                material: prefix,
                ibrav: (function () {
                    try {
                        var el = document.getElementById('ibrav') || document.getElementById('cif_ibrav');
                        if (el && el.value !== '') return parseInt(el.value, 10) || 0;
                    } catch (_eIb) {}
                    return parseInt(params.ibrav, 10) || 0;
                })(),
                amass: (function () {
                    try {
                        if (params.amass) return params.amass;
                        var sp = document.getElementById('atomic_species') || document.getElementById('cif_atomic_species');
                        if (!sp || !sp.value) return undefined;
                        var masses = [];
                        String(sp.value).split(/\r?\n/).forEach(function (line) {
                            var m = line.trim().match(/^([A-Za-z][A-Za-z0-9]*)\s+([\d.]+)/);
                            if (m) masses.push(m[2]);
                        });
                        return masses.length ? masses.join(',') : undefined;
                    } catch (_eAm) { return undefined; }
                })()
            }, (typeof window.qeCollectPolarizationOptionsForApi === 'function')
                ? window.qeCollectPolarizationOptionsForApi(pkg) : {}))
        });
        var data = await r.json();
        if (!r.ok || !data.ok) {
            throw new Error((data && data.error) || ('HTTP ' + r.status));
        }
        var inputContent = data.text || '';
        var meta = (typeof window.qeGetCalcTypeMeta === 'function') ? window.qeGetCalcTypeMeta(pkg) : null;
        var exe = (meta && meta.exe) ? meta.exe : pkg;

        inputContent += '\n! ═══════════════════════════════════════════════════════════════\n'
            + '! INPUT ' + exe.toUpperCase() + ' — QE 7.5+\n'
            + '! prefix: ' + prefix + '\n'
            + '! outdir: ' + outdir + '\n'
            + '! Généré par Interface Génération Inputs QE\n'
            + '! ═══════════════════════════════════════════════════════════════\n';

        window.currentInputContent = inputContent;
        afficherPreviewInput(inputContent);

        var vwarn = (data.verify && data.verify.warnings && data.verify.warnings.length)
            ? ' — ' + data.verify.warnings.join(' · ') : '';
        try {
            var autoSave = await __genInputSaveUnified(prefix, pkg, inputContent);
            if (autoSave && (autoSave.success || autoSave.ok)) {
                __genInputFlashSaveOk(autoSave.path || autoSave.filepath, autoSave.relative);
                if (typeof window.tab1ShowStatus === 'function') {
                    window.tab1ShowStatus('ok',
                        '✅ Input <strong>' + __genEscHtml(exe) + '</strong> généré et sauvegardé → <code>inputs_générés_direct/'
                        + __genEscHtml(autoSave.relative || '') + '</code>' + vwarn);
                }
            } else if (typeof window.tab1ShowStatus === 'function') {
                window.tab1ShowStatus('warn',
                    '⚠️ Input <strong>' + __genEscHtml(exe) + '</strong> généré — sauvegarde échouée' + vwarn);
            }
        } catch (_eAs) {
            console.warn(_eAs);
            if (typeof window.tab1ShowStatus === 'function') {
                window.tab1ShowStatus('ok',
                    '✅ Input <strong>' + __genEscHtml(exe) + '</strong> généré pour <code>'
                    + __genEscHtml(prefix) + '</code>' + vwarn);
            }
        }

        if (typeof window.tab1ScrollToInputPreview === 'function') {
            window.tab1ScrollToInputPreview({ delay: 180, block: 'center' });
        }
        return inputContent;
    } catch (err) {
        console.error('genererInputAuxComplet:', err);
        if (typeof window.tab1ShowStatus === 'function') {
            window.tab1ShowStatus('error', '❌ Génération ' + pkg + ' : <code>' + (err.message || err) + '</code>', { scroll: true });
        } else {
            alert('Erreur génération ' + pkg + ': ' + (err.message || err));
        }
        throw err;
    }
}

/**
 * Parse ATOMIC_SPECIES (texte) → { species: [], pseudos: {} }
 */
function directParseAtomicSpeciesForWorkflow(speciesText) {
    var species = [];
    var pseudos = {};
    String(speciesText || '').split(/\r?\n/).forEach(function (line) {
        var m = line.trim().match(/^([A-Za-z][A-Za-z0-9]*)\s+[\d.]+\s+(\S+)/);
        if (!m) return;
        var sym = m[1];
        if (species.indexOf(sym) < 0) species.push(sym);
        pseudos[sym] = m[2];
    });
    return { species: species, pseudos: pseudos };
}

/**
 * Parse positions (crystal) depuis textarea ou champs pos_x_i.
 */
function directParseAtomicPositionsForWorkflow(nat) {
    var positions = [];
    var content = String(window.atomicPositionsContent || '').trim();
    if (content) {
        content.split(/\r?\n/).forEach(function (line) {
            var p = line.trim().split(/\s+/);
            if (p.length >= 4) {
                positions.push({
                    symbol: p[0],
                    x: parseFloat(p[1]),
                    y: parseFloat(p[2]),
                    z: parseFloat(p[3])
                });
            }
        });
    }
    if (!positions.length && nat > 0) {
        for (var i = 1; i <= nat; i++) {
            var el = document.getElementById('elem_' + i) || document.getElementById('element_' + i);
            var sym = el ? String(el.value || '').trim() : ('Atom_' + i);
            var x = parseFloat((document.getElementById('pos_x_' + i) || {}).value || '0');
            var y = parseFloat((document.getElementById('pos_y_' + i) || {}).value || '0');
            var z = parseFloat((document.getElementById('pos_z_' + i) || {}).value || '0');
            positions.push({ symbol: sym || ('Atom_' + i), x: x, y: y, z: z });
        }
    }
    return positions;
}

/**
 * Objet workflow pour /api/inputs/build (voie directe Tab 1).
 */
window.directCollectWorkflowForApi = function directCollectWorkflowForApi(params) {
    params = params || obtenirParametresCalcul();
    var speciesText = (typeof obtenirAtomicSpecies === 'function') ? obtenirAtomicSpecies() : (window.atomicSpeciesGlobal || '');
    var parsed = directParseAtomicSpeciesForWorkflow(speciesText);
    var species = parsed.species;
    if (!species.length) {
        for (var i = 1; i <= (params.ntyp || 1); i++) {
            var e = document.getElementById('element_' + i);
            if (e && e.value.trim()) species.push(e.value.trim());
        }
    }
    var positions = directParseAtomicPositionsForWorkflow(params.nat);
    return {
        formula: params.materiau_label || params.materiau || 'material',
        prefix: params.materiau || 'material',
        ibrav: parseInt(params.ibrav, 10) || 1,
        a: parseFloat(params.a) || 5.0,
        b: parseFloat(params.b) || parseFloat(params.a) || 5.0,
        c: parseFloat(params.c) || parseFloat(params.a) || 5.0,
        cosab: parseFloat(params.cosab),
        cosac: parseFloat(params.cosac),
        cosbc: parseFloat(params.cosbc),
        nat: params.nat,
        ntyp: params.ntyp || species.length || 1,
        atomic_species: species,
        atomic_positions_crystal: positions,
        pseudos: parsed.pseudos
    };
};

/**
 * Corps JSON complet pour POST /api/inputs/build (voie directe).
 */
window.directCollectBuildOptionsForApi = function directCollectBuildOptionsForApi(params) {
    params = params || obtenirParametresCalcul();
    var workflow = directCollectWorkflowForApi(params);
    // Grille k depuis #kx/#ky/#kz (section 5). Ne pas densifier ici :
    // build_pw_input (Python) applique déjà ×1.5 pour NSCF.
    var kx = parseInt((document.getElementById('kx') || {}).value || '4', 10) || 4;
    var ky = parseInt((document.getElementById('ky') || {}).value || '4', 10) || 4;
    var kz = parseInt((document.getElementById('kz') || {}).value || '4', 10) || 4;
    if ((!document.getElementById('kx') || !document.getElementById('ky') || !document.getElementById('kz'))
            && document.getElementById('kpoints')) {
        var parts = String(document.getElementById('kpoints').value || '').trim().split(/\s+/);
        if (parts.length >= 3) {
            kx = parseInt(parts[0], 10) || kx;
            ky = parseInt(parts[1], 10) || ky;
            kz = parseInt(parts[2], 10) || kz;
        }
    }
    var mix = parseFloat(document.getElementById('mixing_beta')?.value || '0.7');
    var body = {
        workflow: workflow,
        calculation: params.calculation || 'scf',
        prefix: params.materiau || 'material',
        pseudo_dir: params.pathPseuodos || './pseudos',
        outdir: params.pathOutputs || './out',
        k_points: [kx, ky, kz],
        ecutwfc: parseFloat(document.getElementById('ecutwfc')?.value || params.ecutwfc || '50'),
        ecutrho: parseFloat(document.getElementById('ecutrho')?.value || params.ecutrho || '400'),
        occupations: 'smearing',
        smearing: 'marzari-vanderbilt',
        degauss: 0.01,
        mixing_beta: isNaN(mix) ? 0.7 : mix,
        forc_conv_thr: parseFloat(String(document.getElementById('forc_conv_thr')?.value || '1.0d-4').replace(/d/i, 'e')) || 1.0e-4,
        ion_dynamics: document.getElementById('ion_dynamics')?.value || 'bfgs',
        cell_dynamics: document.getElementById('cell_dynamics')?.value || 'bfgs',
        press_conv_thr: parseFloat(document.getElementById('press_conv_thr')?.value || '0.5') || 0.5,
    };
    if (workflow.pseudos && Object.keys(workflow.pseudos).length) {
        body.pseudos = workflow.pseudos;
    }
    var nspinEl = document.getElementById('nspin');
    if (nspinEl) {
        var ns = parseInt(nspinEl.value, 10);
        if (ns === 1 || ns === 2 || ns === 4) body.nspin = ns;
    }
    if (typeof window.pwGenNoncolinActive === 'function' && window.pwGenNoncolinActive()) {
        body.noncolin = true;
        body.lspinorb = true;
    }
    var ordreMag = window.ordreMagnetisme || '';
    if (ordreMag && String(ordreMag).toLowerCase().indexOf('afm') === 0) {
        body.afm_type = ordreMag;
    }
    if (typeof window.genHubbardCollectForApi === 'function') {
        var hb = window.genHubbardCollectForApi();
        if (hb) {
            Object.keys(hb).forEach(function (k) { body[k] = hb[k]; });
        }
    }
    if (typeof window.qeCollectPolarizationOptionsForApi === 'function') {
        var pol = window.qeCollectPolarizationOptionsForApi(params.calculation);
        Object.keys(pol).forEach(function (k) { body[k] = pol[k]; });
    }
    if (body.calculation === 'scf_berry') {
        body.lberry = true;
        body.gdir = body.gdir != null ? body.gdir : 3;
        body.nppstr = body.nppstr != null ? body.nppstr : 8;
    }
    if (body.calculation === 'scf_born' && !body.conv_thr) {
        body.conv_thr = '1.0d-12';
    }
    var pwdEl = document.getElementById('pw_input_dft') || document.getElementById('gen_pw_input_dft');
    if (pwdEl && typeof window.normalizePwInputDft === 'function') {
        var idft = window.normalizePwInputDft(pwdEl.value || '');
        if (idft) body.input_dft = idft;
    }
    return body;
};

function __genPostProcessPwInput(inputContent, params) {
    var text = String(inputContent || '');
    try {
        if (typeof window.injectInputDftHubbardIntoPwText === 'function') {
            var syms = (window.directCollectWorkflowForApi(params) || {}).atomic_species || [];
            text = window.injectInputDftHubbardIntoPwText(text, {
                hubbard_prefix: 'gen',
                input_dft: (document.getElementById('pw_input_dft') || {}).value || '',
                species: syms
            });
        }
    } catch (_eInj) { console.warn(_eInj); }
    try {
        if (typeof window.applyPwGenMagnetismPostProcess === 'function') {
            text = window.applyPwGenMagnetismPostProcess(text);
        }
    } catch (_eMag) { console.warn(_eMag); }
    if (typeof appliquerCompatibiliteQe75 === 'function') {
        text = appliquerCompatibiliteQe75(text, params);
    }
    return text;
}

async function __genFinalizeInputOutput(inputContent, params) {
    window.currentInputContent = inputContent;
    afficherPreviewInput(inputContent);
    var mat = (params && params.materiau) || 'material';
    var calc = ((params && params.calculation) || 'scf').toUpperCase();
    var saveOk = false;
    var saveRel = '';
    var saveErr = '';
    try {
        var autoSave = await __genInputSaveUnified(params.materiau, params.calculation, inputContent);
        if (autoSave && (autoSave.success || autoSave.ok)) {
            saveOk = true;
            saveRel = autoSave.relative || '';
            __genInputFlashSaveOk(autoSave.path || autoSave.filepath, autoSave.relative);
        } else {
            saveErr = (autoSave && autoSave.error) ? String(autoSave.error) : 'sauvegarde échouée';
            __genShowSaveBanner({ ok: false, error: saveErr });
        }
    } catch (_eAs) {
        console.warn(_eAs);
        saveErr = _eAs && _eAs.message ? String(_eAs.message) : String(_eAs);
        __genShowSaveBanner({ ok: false, error: saveErr });
    }
    if (typeof window.tab1ShowStatus === 'function') {
        if (saveOk) {
            window.tab1ShowStatus('ok',
                '✅ Input généré et sauvegardé pour <strong>' + __genEscHtml(mat) + '</strong> ('
                + __genEscHtml(calc) + ') → <code>inputs_générés_direct/'
                + __genEscHtml(saveRel) + '</code>');
        } else {
            window.tab1ShowStatus('warn',
                '⚠️ Input généré pour <strong>' + __genEscHtml(mat) + '</strong> — sauvegarde auto échouée'
                + (saveErr ? ' : <code>' + __genEscHtml(saveErr) + '</code>' : '')
                + '. Cliquez <strong>💾 SAUVEGARDER</strong>.');
        }
    }
    if (typeof window.tab1UpdateStepper === 'function') window.tab1UpdateStepper();
    if (typeof window.tab1SetWorkflowStep === 'function') window.tab1SetWorkflowStep(5, 'done');
    if (typeof window.tab1RefreshWorkflowTracker === 'function') window.tab1RefreshWorkflowTracker();
    if (typeof window.__genHideCifUiLeak === 'function') {
        try { window.__genHideCifUiLeak(); } catch (_eHide2) {}
    }
    if (typeof window.tab1ScrollToInputPreview === 'function') {
        window.tab1ScrollToInputPreview({ delay: 180, block: 'center' });
    }
    return inputContent;
}

/**
 * Génération pw.x via API Python (source unique avec voie CIF).
 */
async function genererInputPwViaApi(params) {
    params = params || obtenirParametresCalcul();
    var apiBase = (typeof window.getGenInputsApiBase === 'function')
        ? window.getGenInputsApiBase() : 'http://127.0.0.1:5012';
    var body = (typeof window.directCollectBuildOptionsForApi === 'function')
        ? window.directCollectBuildOptionsForApi(params)
        : null;
    if (!body || !body.workflow) {
        throw new Error('workflow direct invalide');
    }
    if (typeof window.tab1ShowStatus === 'function') {
        window.tab1ShowStatus('info', '⏳ Génération <strong>pw.x</strong> via API Python…');
    }
    var r = await fetch(apiBase + '/api/inputs/build', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    });
    var data = await r.json();
    if (!r.ok || !data.text) {
        throw new Error((data && data.error) || ('HTTP ' + r.status));
    }
    var text = __genPostProcessPwInput(data.text, params);
    var vwarn = (data.verify && data.verify.warnings && data.verify.warnings.length)
        ? ' — ' + data.verify.warnings.join(' · ') : '';
    if (data.verify && !data.verify.ok && typeof window.tab1ShowStatus === 'function') {
        window.tab1ShowStatus('warn', '⚠️ Vérification QE 7.5 : ' + (data.verify.errors || []).join(' · ') + vwarn);
    }
    return __genFinalizeInputOutput(text, params);
}

/**
 * Générer le fichier input complet
 */
async function genererInputComplet() {
    if (typeof mettreAJourFormat === 'function') {
        try { mettreAJourFormat(); } catch (_eFmt) {}
    }
    if (typeof window.pwGenPrepareAfmStructure === 'function') {
        try {
            var _nsGc = (document.getElementById('nspin') || {}).value || '1';
            if (String(_nsGc).trim() !== '4') window.pwGenPrepareAfmStructure();
        } catch (_eAfmPrep) { console.warn(_eAfmPrep); }
    }
    console.log('\n\n🚀🚀🚀 GÉNÉRATION INPUT COMPLET 🚀🚀🚀\n');
    
    // ⭐ IMPORTANT: Vérifier et remplir ATOMIC_SPECIES avant le reste
    console.log('🔍 DEBUG - Vérification window.atomicSpeciesGlobal:');
    console.log('  Valeur:', window.atomicSpeciesGlobal);
    console.log('  Type:', typeof window.atomicSpeciesGlobal);
    console.log('  Longueur:', window.atomicSpeciesGlobal?.length || 0);
    console.log('  Contenu:');
    if (window.atomicSpeciesGlobal) {
        console.log(window.atomicSpeciesGlobal);
    } else {
        console.error('  ❌ VIDE!');
    }
    
    // Si vide, essayer de le générer maintenant
    if (!window.atomicSpeciesGlobal || window.atomicSpeciesGlobal.trim().length === 0) {
        console.warn('⚠️ atomicSpeciesGlobal vide, tentative de génération...');
        if (typeof genererAtomicSpecies === 'function') {
            genererAtomicSpecies();
            console.log('  ✓ genererAtomicSpecies() appelée');
            console.log('  window.atomicSpeciesGlobal maintenant:', window.atomicSpeciesGlobal);
        }
    }
    
    const params = obtenirParametresCalcul();

    if (typeof window.qeIsAuxInputType === 'function' && window.qeIsAuxInputType(params.calculation)) {
        return genererInputAuxComplet(params);
    }

    // ── Voie unifiée pw.x : API Python uniquement (même moteur que CIF) ──
    // Repli JS local désactivé par défaut (exactitude QE 7.5 / Hubbard / AFM).
    // Escape hatch debug uniquement : window.QE_ALLOW_JS_FALLBACK = true
    try {
        return await genererInputPwViaApi(params);
    } catch (_eApiPw) {
        console.error('❌ API pw.x indisponible — génération annulée:', _eApiPw);
        var _msgApi = 'API Python injoignable (' + ((_eApiPw && _eApiPw.message) || _eApiPw) + '). '
            + 'Lancez <code>./DEMARRER.sh</code> puis réessayez.';
        if (typeof window.tab1ShowStatus === 'function') {
            window.tab1ShowStatus('error', '❌ ' + _msgApi);
        } else {
            alert('API Python injoignable. Lancez ./DEMARRER.sh puis réessayez.\n' + ((_eApiPw && _eApiPw.message) || ''));
        }
        if (window.QE_ALLOW_JS_FALLBACK !== true) {
            return;
        }
        console.warn('⚠️ QE_ALLOW_JS_FALLBACK=true — repli JS local (non recommandé)');
        if (typeof window.tab1ShowStatus === 'function') {
            window.tab1ShowStatus('warn', '⚠️ Repli JS local activé (debug). Préférez l\'API Python.');
        }
    }

    console.log('\n🔍 DEBUG - Appel obtenirAtomicSpecies():');
    const atomicSpecies = obtenirAtomicSpecies();
    console.log('  Retourné:', atomicSpecies);
    console.log('  Longueur:', atomicSpecies?.length || 0);

    console.log('\n🔍 DEBUG - Appel obtenirAtomicPositions():');
    const atomicPositions = obtenirAtomicPositions();
    console.log('  Retourné:', atomicPositions);
    console.log('  Longueur:', atomicPositions?.length || 0);

    console.log('\n📋 Récupération finale:');
    console.log('  atomicSpecies (longueur):', atomicSpecies?.length || 0);
    console.log('  atomicPositions (longueur):', atomicPositions?.length || 0);

    // Vérifications
    if (!atomicSpecies) {
        alert('❌ ATOMIC_SPECIES vide!\nVeuillez entrer les éléments et leurs pseudo-potentiels.');
        console.error('❌ ATOMIC_SPECIES vide après vérification');
        return;
    }

    if (!atomicPositions) {
        alert('❌ ATOMIC_POSITIONS vide!\nVeuillez générer les positions atomiques.');
        return;
    }

    if (typeof detecterPositionsAtomiquesInvalides === 'function') {
        var posErr = detecterPositionsAtomiquesInvalides(atomicPositions, params.nat);
        if (posErr) {
            alert('❌ Positions atomiques invalides : ' + posErr + '\n\nPour BaTiO3 (pérovskite cubique Pm-3m) :\n  Ba 0 0 0\n  Ti 0.5 0.5 0.5\n  O  0.5 0.5 0 ; 0.5 0 0.5 ; 0 0.5 0.5\n\nCliquez « Générer Auto » en section 4 ou chargez l\'exemple BaTiO3.');
            return;
        }
    }
    
    // Vérifier les chemins (outdir et pseudo_dir depuis les inputs éditables)
    if (!params.pathOutputs || !params.pathPseuodos) {
        alert('❌ Chemins non configurés!\nVeuillez remplir les champs "outdir" et "pseudo_dir" dans la section ci-dessus.');
        return;
    }
    
    // Vérifier que les chemins ne sont pas vides
    if (params.pathOutputs.trim().length === 0 || params.pathPseuodos.trim().length === 0) {
        alert('❌ Chemins vides!\nVeuillez remplir les champs "outdir" et "pseudo_dir" dans la section ci-dessus.');
        return;
    }
    
    // DEBUG: Afficher les chemins utilisés
    console.log('\n📁 CHEMINS UTILISÉS POUR LA GÉNÉRATION:');
    console.log('  outdir (pathOutputs):', params.pathOutputs);
    console.log('  pseudo_dir (pathPseuodos):', params.pathPseuodos);
    console.log('  calculation:', params.calculation);

    const typeMag = magnetismeEffectifPourSystem();
    const ordreMag = window.ordreMagnetisme || 'fm';
    
    // Construire le fichier input avec les chemins configurés
    // ⭐ RÉCUPÉRER TOUS LES PARAMÈTRES depuis Section 5
    const ecutwfc = document.getElementById('ecutwfc')?.value || params.ecutwfc || '50';
    const ecutrho = document.getElementById('ecutrho')?.value || params.ecutrho || '400';
    const conv_thr = document.getElementById('conv_thr')?.value || '1.0d-8';
    const mixing_beta_raw = document.getElementById('mixing_beta')?.value || '0.7';
    var _genHbForMix = document.getElementById('gen_hubbard_enable');
    var _magForMix = typeMag !== 'non_mag';
    var mixing_beta_num = parseFloat(mixing_beta_raw);
    if (isNaN(mixing_beta_num)) mixing_beta_num = 0.7;
    if (typeMag === 'non_colin') {
        mixing_beta_num = Math.min(0.25, Math.max(0.15, mixing_beta_num > 0.25 ? 0.15 : mixing_beta_num));
    } else if ((_genHbForMix && _genHbForMix.checked && _magForMix) || (_magForMix && /^afm/.test(ordreMag))) {
        mixing_beta_num = Math.min(0.35, Math.max(0.3, mixing_beta_num > 0.35 ? 0.3 : mixing_beta_num));
    }
    const mixing_beta = String(mixing_beta_num.toFixed(2));
    
    // Paramètres relax/vc-relax
    const forc_conv_thr = document.getElementById('forc_conv_thr')?.value || '1.0d-4';
    const ion_dynamics = document.getElementById('ion_dynamics')?.value || 'bfgs';
    const press_conv_thr = document.getElementById('press_conv_thr')?.value || '0.5';
    const cell_dynamics = document.getElementById('cell_dynamics')?.value || 'bfgs';
    
    // K-POINTS depuis l'UI
    const kx = document.getElementById('kx')?.value || '4';
    const ky = document.getElementById('ky')?.value || '4';
    const kz = document.getElementById('kz')?.value || '4';
    
    console.log(`📊 Paramètres lus depuis Section 5:
  ecutwfc=${ecutwfc}, ecutrho=${ecutrho}
  conv_thr=${conv_thr}, mixing_beta=${mixing_beta}
  K-POINTS: ${kx} ${ky} ${kz}`);
    
    // ⭐ CONSTRUIRE &SYSTEM avec paramètres de maille selon ibrav
    let systemBlock = `&SYSTEM
    ibrav = ${params.ibrav}
`;

    // ⭐ Ajouter paramètres de maille selon ibrav
    const ibrav = parseInt(params.ibrav);
    
    if (ibrav === 0) {
        // Libre: tous les paramètres
        systemBlock += `    A = ${params.a}
    B = ${params.b}
    C = ${params.c}
    cosAB = ${params.cosab}
    cosAC = ${params.cosac}
    cosBC = ${params.cosbc}
`;
    } else if (ibrav === 1 || ibrav === 2 || ibrav === 3) {
        // Cubique: seulement A
        systemBlock += `    A = ${params.a}
`;
    } else if (ibrav === 4 || ibrav === 6 || ibrav === 7) {
        // Hexagonal ou Tétragonal: A et C
        systemBlock += `    A = ${params.a}
    C = ${params.c}
`;
    } else if (ibrav === 5) {
        // Rhomboédrique: A et cosAB
        systemBlock += `    A = ${params.a}
    cosAB = ${params.cosab}
`;
    } else if (ibrav === 8 || ibrav === 9 || ibrav === 10 || ibrav === 11 || ibrav === 91) {
        // Orthorhombique: A, B, C
        systemBlock += `    A = ${params.a}
    B = ${params.b}
    C = ${params.c}
`;
    } else if (ibrav === 12 || ibrav === 13 || ibrav === -12 || ibrav === -13) {
        // Monoclinique: A, B, C et cosAB
        systemBlock += `    A = ${params.a}
    B = ${params.b}
    C = ${params.c}
    cosAB = ${params.cosab}
`;
    } else if (ibrav === 14) {
        // Triclinique: tous les paramètres
        systemBlock += `    A = ${params.a}
    B = ${params.b}
    C = ${params.c}
    cosAB = ${params.cosab}
    cosAC = ${params.cosac}
    cosBC = ${params.cosbc}
`;
    } else {
        // Par défaut: A, B, C
        systemBlock += `    A = ${params.a}
    B = ${params.b}
    C = ${params.c}
`;
    }
    
    // ⭐ Paramètres magnétiques dynamiques (voir INPUT_PW : non-colinéaire → noncolin, sans nspin=4 redondant)
    const ntyp       = parseInt(params.ntyp) || 1;
    const totMag     = document.getElementById('tot_magnetization')?.value?.trim() || '';
    var lspinorbF  = lireLspinorbFortran();
    if (typeMag === 'non_colin' && typeof window.nspin4ResolveLspinorb === 'function') {
        lspinorbF = window.nspin4ResolveLspinorb('gen');
    } else if (typeMag === 'non_colin' && lspinorbF !== '.true.') {
        lspinorbF = '.true.';
    }

    let magLines = '';
    if (typeMag === 'non_colin') {
        magLines += `    noncolin = .true.\n`;
        magLines += `    lspinorb = ${lspinorbF}\n`;
    } else {
        const nspinValue = typeMag === 'non_mag' ? 1 : 2;
        magLines += `    nspin = ${nspinValue}\n`;
    }

    if (typeMag !== 'non_mag') {
        var ncRows = (typeMag === 'non_colin' && typeof window.nspin4CollectFields === 'function')
            ? window.nspin4CollectFields('gen') : null;
        for (let i = 1; i <= ntyp; i++) {
            var el = document.getElementById('start_mag_' + i);
            var val;
            if (ncRows && ncRows[i - 1] && ncRows[i - 1].sm !== '') {
                val = parseFloat(String(ncRows[i - 1].sm).replace(/,/g, '.'));
            } else if (el) {
                val = parseFloat(el.value);
            } else if (typeof window.nspin4Flow !== 'undefined' && window.nspin4Flow.defaultStartMag) {
                var symsNc = _speciesResolved.length ? _speciesResolved : [];
                var symI = symsNc[i - 1] || '';
                val = parseFloat(window.nspin4Flow.defaultStartMag(symI));
            } else {
                val = (i === 1 ? 0.5 : (ordreMag === 'afm' ? (i % 2 === 0 ? -0.5 : 0.5) : 0.0));
            }
            if (!isNaN(val) && val !== 0) {
                magLines += `    starting_magnetization(${i}) = ${val.toFixed(3)}\n`;
            }
        }
        if (totMag !== '') {
            magLines += `    tot_magnetization = ${totMag}\n`;
        }
    }

    // Angles pour non-colinéaire
    if (typeMag === 'non_colin') {
        for (let i = 1; i <= ntyp; i++) {
            const a1 = document.getElementById('angle1_' + i)?.value || '0';
            const a2 = document.getElementById('angle2_' + i)?.value || '0';
            magLines += `    angle1(${i}) = ${a1}\n`;
            magLines += `    angle2(${i}) = ${a2}\n`;
        }
    }

    let pwInputDftLine = '';
    const pwdElCompl = document.getElementById('pw_input_dft');
    const pwdTrimCompl = pwdElCompl ? pwdElCompl.value.trim() : '';
    if (pwdTrimCompl && typeof window.normalizePwInputDft === 'function') {
        const __nfdCompl = window.normalizePwInputDft(pwdTrimCompl);
        if (__nfdCompl) pwInputDftLine = `    input_dft = '${__nfdCompl}'\n`;
    }

    let hubbardLegacyInSystem = '';
    var _speciesResolved = [];
    try {
        if (typeof window.pwGenResolveSpeciesList === 'function') {
            _speciesResolved = window.pwGenResolveSpeciesList(atomicSpecies || '');
        } else if (typeof window.parseSymbolsFromAtomicSpecies === 'function') {
            _speciesResolved = window.parseSymbolsFromAtomicSpecies(atomicSpecies || '');
        }
        if (typeof window.genHubbardBuildLinesForSystem === 'function' && _speciesResolved.length) {
            const hbBlk = window.genHubbardBuildLinesForSystem(_speciesResolved, 'gen');
            if (hbBlk && String(hbBlk).trim()) {
                hubbardLegacyInSystem = '\n    ! --- DFT+U (Hubbard) ---\n' + hbBlk;
            }
        }
    } catch (_eHbCompl) { /* ignore */ }

    // Continuer &SYSTEM
    systemBlock += `    nat = ${params.nat}
    ntyp = ${params.ntyp}
${pwInputDftLine}    ecutwfc = ${ecutwfc}
    ecutrho = ${ecutrho}
${__genOccupationsBlock(params.calculation)}${__genNbndLine(params.nat, params.calculation)}${magLines}${hubbardLegacyInSystem}/
`;

    var restartMode = (params.calculation === 'nscf' || params.calculation === 'bands')
        ? 'restart' : 'from_scratch';
    var nstepLine = (params.calculation === 'md' || params.calculation === 'vc-md')
        ? '    nstep = 1000\n' : '';
    let inputContent = `&CONTROL
    calculation = '${params.calculation}'
    prefix = '${params.materiau}'
    outdir = '${params.pathOutputs}/${params.materiau}/'
    pseudo_dir = '${params.pathPseuodos}'
    tprnfor = .true.
    tstress = .true.
    restart_mode = '${restartMode}'
    verbosity = 'high'
${nstepLine}/

${systemBlock}

&ELECTRONS
    diagonalization = 'david'
    mixing_mode = 'plain'
    mixing_beta = ${mixing_beta}
    conv_thr = ${conv_thr}
/
`;

    // ⭐ AJOUTER &IONS pour relax, vc-relax ou MD
    if (params.calculation === 'relax' || params.calculation === 'vc-relax') {
        inputContent += `
&IONS
    ion_dynamics = '${ion_dynamics}'
/
`;
    } else if (params.calculation === 'md' || params.calculation === 'vc-md') {
        inputContent += `
&IONS
    ion_dynamics = 'verlet'
    tempw = 300.0
    dt = 20.0
    nstep = 1000
/
`;
    }

    // ⭐ AJOUTER &CELL pour vc-relax et vc-md
    if (params.calculation === 'vc-relax' || params.calculation === 'vc-md') {
        inputContent += `
&CELL
    cell_dynamics = '${cell_dynamics}'
    press_conv_thr = ${press_conv_thr}
    press = 0.0d0
/
`;
    }

    // ATOMIC_SPECIES + ATOMIC_POSITIONS + K_POINTS
    inputContent += `
ATOMIC_SPECIES
${atomicSpecies}

${atomicPositions}
`;
    try {
        if (typeof window.genHubbardBuildCard === 'function') {
            const symsCard = _speciesResolved.length ? _speciesResolved
                : (typeof window.parseSymbolsFromAtomicSpecies === 'function'
                    ? window.parseSymbolsFromAtomicSpecies(atomicSpecies || '') : []);
            const cardTxt = window.genHubbardBuildCard(symsCard, 'gen');
            if (cardTxt) inputContent += '\n' + cardTxt + '\n';
        }
    } catch (_eCardCompl) { /* ignore */ }

    try {
        if (typeof window.injectInputDftHubbardIntoPwText === 'function') {
            var _pwdNorm = '';
            var _pwdEl = document.getElementById('pw_input_dft');
            if (_pwdEl && typeof window.normalizePwInputDft === 'function') {
                _pwdNorm = window.normalizePwInputDft(_pwdEl.value || '') || '';
            }
            var _symsInj = _speciesResolved.length ? _speciesResolved
                : (typeof window.parseSymbolsFromAtomicSpecies === 'function'
                    ? window.parseSymbolsFromAtomicSpecies(atomicSpecies || '') : []);
            inputContent = window.injectInputDftHubbardIntoPwText(inputContent, {
                hubbard_prefix: 'gen',
                input_dft: _pwdNorm,
                species: _symsInj
            });
            var _genEnF = document.getElementById('gen_hubbard_enable');
            var _hasUF = /^\s*HUBBARD\s*\(/m.test(inputContent) || /\bHubbard_U\s*\(/i.test(inputContent);
            if (_genEnF && _genEnF.checked && !_hasUF && _symsInj.length &&
                    typeof window.genHubbardBuildCard === 'function') {
                var _cardF = window.genHubbardBuildCard(_symsInj, 'gen');
                if (_cardF) {
                    inputContent = inputContent.replace(/\s+$/, '') + '\n\n' + _cardF;
                    inputContent = window.injectInputDftHubbardIntoPwText(inputContent, {
                        hubbard_prefix: 'gen', input_dft: _pwdNorm, species: _symsInj
                    });
                }
            }
        }
    } catch (_eInjCompl) { console.warn('injectInputDftHubbardIntoPwText:', _eInjCompl); }

    inputContent += `
`;
    var kxUse = parseInt(kx, 10) || 4;
    var kyUse = parseInt(ky, 10) || 4;
    var kzUse = parseInt(kz, 10) || 4;
    if (params.calculation === 'nscf') {
        kxUse = Math.max(kxUse, Math.ceil(kxUse * 1.5));
        kyUse = Math.max(kyUse, Math.ceil(kyUse * 1.5));
        kzUse = Math.max(kzUse, Math.ceil(kzUse * 1.5));
        inputContent += 'K_POINTS automatic\n' + kxUse + ' ' + kyUse + ' ' + kzUse + ' 0 0 0\n';
    } else if (params.calculation === 'bands') {
        inputContent += __genBandsKpathCrystalB(ibrav) + '\n';
    } else {
        inputContent += 'K_POINTS automatic\n' + kxUse + ' ' + kyUse + ' ' + kzUse + ' 0 0 0\n';
    }

    try {
        if (typeof window.applyPwGenMagnetismPostProcess === 'function') {
            inputContent = window.applyPwGenMagnetismPostProcess(inputContent);
        }
    } catch (_eMagPpCompl) { console.warn('applyPwGenMagnetismPostProcess:', _eMagPpCompl); }

    // Ajustements globaux QE 7.5 (tous matériaux / tous types de calcul).
    inputContent = appliquerCompatibiliteQe75(inputContent, params);
    
    // Ajouter les informations de chemins en commentaire
    const cheminInfo = `
! ═══════════════════════════════════════════════════════════════
! CHEMINS CONFIGURÉS
! ═══════════════════════════════════════════════════════════════
! Répertoire des outputs: ${params.pathOutputs}
! Répertoire des pseudos: ${params.pathPseuodos}
! 
! Pour exécuter:
!   pw.x < ${params.materiau}.in > ${params.materiau}.out
! ═══════════════════════════════════════════════════════════════
`;
    
    // Stocker globalement
    window.currentInputContent = inputContent;
    window.cheminInfo = cheminInfo;
    
    console.log('✅ Input généré avec chemins (repli JS local)');
    console.log(cheminInfo);
    
    return __genFinalizeInputOutput(inputContent, params);
}

/**
 * Afficher l'aperçu
 */
function afficherPreviewInput(content) {
    // Formulaire direct (input_preview_card) — bouton vert « GÉNÉRER L'INPUT QE »
    const inputPreviewCard = document.getElementById('input_preview_card');
    const inputPreview = document.getElementById('input_preview');
    if (inputPreview) {
        inputPreview.value = content;
        if (inputPreviewCard) inputPreviewCard.style.display = 'block';
    }
    const genStatus = document.getElementById('generation_status');
    if (genStatus) {
        genStatus.innerHTML = '<div class="alert alert-success">'
            + '<strong>✅ Input généré</strong> — aperçu ci-dessous '
            + '(sauvegarde auto vers <code>inputs_générés_direct/</code>).'
            + '</div>';
    }

    // Section 5 (assistant Tab 1)
    const previewContainer = document.getElementById('preview_input_container');
    const previewTextarea = document.getElementById('preview_input');
    
    if (previewContainer && previewTextarea) {
        previewTextarea.value = content;
        previewContainer.style.display = 'block';
        
        const btnSauvegarder = document.getElementById('btn_sauvegarder_modif');
        if (btnSauvegarder) btnSauvegarder.style.display = 'block';
        
        console.log('✅ Preview affiché dans section 5');
    } else {
        const previewDiv = document.getElementById('gen_input_preview_panel');
        const contentTextarea = document.getElementById('input_content');
        
        if (previewDiv && contentTextarea) {
            contentTextarea.value = content;
            previewDiv.style.display = 'block';
        } else if (inputPreviewCard) {
            inputPreviewCard.style.display = 'block';
        }
    }
    if (typeof window.tab1ScrollToInputPreview === 'function') {
        window.tab1ScrollToInputPreview({ delay: 60, block: 'center' });
    }
}

/**
 * Preview input
 */
function previewInput() {
    const content = window.currentInputContent;
    if (!content) {
        alert('❌ Veuillez d\'abord générer l\'input');
        genererInputComplet();
        return;
    }
    
    afficherPreviewInput(content);
}

/**
 * Copier l'input complet
 */
function copierInputComplet() {
    const content = window.currentInputContent;
    
    if (!content) {
        alert('❌ Veuillez d\'abord générer l\'input');
        genererInputComplet();
        return;
    }
    
    try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(content).then(() => {
                alert('✅ Input complet copié!\n\nVous pouvez maintenant coller dans votre fichier .in');
            }).catch(() => {
                fallbackCopyInput(content);
            });
        } else {
            fallbackCopyInput(content);
        }
    } catch (err) {
        fallbackCopyInput(content);
    }
}

/**
 * Fallback copie input
 */
function fallbackCopyInput(content) {
    try {
        const textarea = document.createElement('textarea');
        textarea.value = content;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        
        alert('✅ Input complet copié!');
    } catch (err) {
        alert('❌ Erreur: ' + err.message);
    }
}

/**
 * Télécharger le fichier input
 */
function telechargerInput() {
    const content = window.currentInputContent;
    
    if (!content) {
        alert('❌ Veuillez d\'abord générer l\'input');
        genererInputComplet();
        return;
    }
    
    const params = obtenirParametresCalcul();
    const filename = `${params.materiau}.in`;
    
    // Créer blob
    const blob = new Blob([content], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    
    // Créer et déclencher le téléchargement
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
    
    console.log(`✅ ${filename} téléchargé`);
}

/**
 * Sauvegarder automatiquement le fichier .in dans le dossier configuré
 */
async function sauvegarderInputAutomatiquement(inputContent, params) {
    console.log('\n💾 Sauvegarde automatique du fichier .in sur le serveur...');
    
    if (!inputContent || !params) {
        console.error('❌ Contenu ou paramètres manquants');
        return;
    }
    
    const prefix = params.materiau || 'input';
    const calcType = params.calculation || 'scf';
    
    try {
        const result = await __genInputSaveUnified(prefix, calcType, inputContent);
        
        if (result.success || result.ok) {
            console.log(`✅ Input sauvegardé: ${result.filepath || result.path || result.relative}`);
            
            // Afficher notification de succès
            const notif = document.createElement('div');
            notif.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: linear-gradient(135deg, #4caf50 0%, #45a049 100%);
                color: white;
                padding: 15px 25px;
                border-radius: 10px;
                box-shadow: 0 4px 15px rgba(0,0,0,0.3);
                z-index: 10000;
                font-weight: bold;
                animation: slideIn 0.3s ease-out;
            `;
            notif.innerHTML = `
                ✅ <strong>${result.filename || (prefix + '_' + calcType + '.in')}</strong> sauvegardé!<br>
                <small style="opacity: 0.9;">📁 inputs_générés_direct/${result.relative || result.filepath}</small>
            `;
            
            document.body.appendChild(notif);
            
            // Animation CSS
            if (!document.getElementById('notification-animation-style')) {
                const style = document.createElement('style');
                style.id = 'notification-animation-style';
                style.textContent = `
                    @keyframes slideIn {
                        from {
                            transform: translateX(400px);
                            opacity: 0;
                        }
                        to {
                            transform: translateX(0);
                            opacity: 1;
                        }
                    }
                    @keyframes slideOut {
                        from {
                            transform: translateX(0);
                            opacity: 1;
                        }
                        to {
                            transform: translateX(400px);
                            opacity: 0;
                        }
                    }
                `;
                document.head.appendChild(style);
            }
            
            // Retirer après 4 secondes
            setTimeout(() => {
                notif.style.animation = 'slideOut 0.3s ease-in';
                setTimeout(() => {
                    notif.remove();
                }, 300);
            }, 4000);
            
        } else {
            console.error('❌ Échec sauvegarde:', result.error);
            alert(`❌ Erreur de sauvegarde: ${result.error}`);
        }
        
    } catch (error) {
        console.error('❌ Erreur sauvegarde serveur:', error);
        alert('❌ Impossible de sauvegarder sur le serveur.\n\n' + __genInputSaveErrorHint() + '\n\nErreur: ' + error.message);
    }
}

/**
 * Sauvegarder l'input MODIFIÉ par l'utilisateur sur le serveur
 */
async function sauvegarderInputModifie() {
    console.log('\n💾 Sauvegarde de l\'input modifié...');
    
    // Récupérer le contenu MODIFIÉ du textarea (nouvelle section 5)
    let contentTextarea = document.getElementById('preview_input');
    
    // Fallback vers ancienne version
    if (!contentTextarea) {
        contentTextarea = document.getElementById('input_content');
    }
    if (!contentTextarea) {
        contentTextarea = document.getElementById('input_preview');
    }
    
    if (!contentTextarea) {
        alert('❌ Erreur: Zone de texte non trouvée!');
        return;
    }
    
    const inputContent = contentTextarea.value;
    
    if (!inputContent || inputContent.trim().length === 0) {
        alert('❌ Le contenu est vide!');
        return;
    }
    
    // Récupérer les paramètres et chemins depuis section 5
    const params = obtenirParametresCalcul();
    const prefix = params.materiau || 'input';
    const calcType = params.calculation || 'scf';

    // Garde-fou QE 7.5 avant écriture disque.
    const strictCheck = await verifierCompatibiliteQe75Strict(inputContent, { forSave: true });
    if (!strictCheck.ok) return;
    
    try {
        const data = await __genInputSaveUnified(prefix, calcType, inputContent);
        
        if (data.success || data.ok) {
            console.log(`✅ ${data.filename || prefix} sauvegardé: ${data.path || data.filepath}`);
            var savedPath = data.filepath || data.fichier || data.path || '';
            __genInputFlashSaveOk(savedPath, data.relative);
            if (typeof window.tab1ShowStatus === 'function') {
                window.tab1ShowStatus('ok',
                    '💾 Input sauvegardé : <code>inputs_générés_direct/'
                    + __genEscHtml(data.relative || savedPath) + '</code>');
            }
            
            // ✨ RETOUR AUTOMATIQUE AUX CALCULS si demandé
            const retourActif = sessionStorage.getItem('retour_calcul_actif');
            if (retourActif === 'true') {
                console.log('🔄 Retour automatique vers Calculs détecté');
                
                const workflow = sessionStorage.getItem('retour_calcul_workflow');
                const materiau = sessionStorage.getItem('retour_calcul_materiau');
                const typeCalcul = sessionStorage.getItem('retour_calcul_type');
                
                // Nettoyer les flags
                sessionStorage.removeItem('retour_calcul_actif');
                sessionStorage.removeItem('preremplir_materiau');
                sessionStorage.removeItem('preremplir_type_calcul');
                
                // Basculer vers Calculs après 2.5s
                setTimeout(() => {
                    if (typeof window.switchTab === 'function') {
                        window.switchTab(1);
                        
                        // Notification finale après retour
                        setTimeout(() => {
                            const notifFinal = document.createElement('div');
                            notifFinal.style.cssText = `
                                position: fixed;
                                top: 80px;
                                right: 20px;
                                background: linear-gradient(135deg, #10b981 0%, #059669 100%);
                                color: white;
                                padding: 20px 30px;
                                border-radius: 10px;
                                box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                                z-index: 10001;
                                animation: slideInRight 0.5s;
                            `;
                            notifFinal.innerHTML = `
                                <div style="display: flex; align-items: center; gap: 15px;">
                                    <span style="font-size: 2em;">✅</span>
                                    <div>
                                        <strong>Input créé avec succès !</strong><br>
                                        <span style="opacity: 0.9; font-size: 0.9em;">${materiau} - ${typeCalcul}</span><br>
                                        <span style="opacity: 0.8; font-size: 0.85em;">Vous pouvez maintenant lancer le calcul</span>
                                    </div>
                                </div>
                            `;
                            document.body.appendChild(notifFinal);
                            setTimeout(() => notifFinal.remove(), 5000);
                        }, 500);
                    }
                }, 2500);
            }
        } else {
            throw new Error(data.error || 'Erreur de sauvegarde');
        }
    } catch (error) {
        console.error('❌ Erreur lors de la sauvegarde:', error);
        alert('❌ Impossible de sauvegarder.\n\n' + __genInputSaveErrorHint() + '\n\nErreur: ' + error.message);
    }
}

/**
 * Initialiser la section génération input
 */
function initialiserGenerationInput() {
    console.log('🔧 Initialisation génération input...');
    
    // Écouter l'événement "sectionTypeCalculReady"
    document.addEventListener('sectionTypeCalculReady', () => {
        console.log('📢 Événement sectionTypeCalculReady reçu!');
        setTimeout(() => {
            creerSectionGenerationInput();
            console.log('✅ Génération input initialisée APRÈS section_type_calcul');
        }, 100);
    });
    
    // Fallback 1 (2s) : cas où la section type calcul est déjà présente
    setTimeout(() => {
        if (!document.getElementById('section_generation_input')) {
            console.warn('⚠️ Fallback 1: tentative création section génération...');
            creerSectionGenerationInput();
        }
    }, 2000);

    // Fallback 2 (6s) : attend que script_interface_parametres_qe_simple.js ait créé section_5
    // (celui-ci se crée après window.load+2500ms, soit généralement 4-8s après DOMContentLoaded)
    setTimeout(() => {
        if (!document.getElementById('section_generation_input')) {
            console.warn('⚠️ Fallback 2: tentative création section génération (après section 5)...');
            creerSectionGenerationInput();
        }
    }, 6000);
}

// Exécuter au chargement
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialiserGenerationInput);
} else {
    initialiserGenerationInput();
}

/**
 * Sauvegarder l'input sur le serveur dans /home/hiadsi/génération_inputs-QE/inputs_générés/prefix/
 */
async function telechargerInputSurPC() {
    console.log('\n💻 Sauvegarde de l\'input sur le serveur...');
    
    // Récupérer le contenu du textarea
    const contentTextarea = document.getElementById('input_content');
    if (!contentTextarea) {
        alert('❌ Erreur: Input non trouvé! Générez d\'abord l\'input.');
        return;
    }
    
    const inputContent = contentTextarea.value;
    if (!inputContent || inputContent.trim().length === 0) {
        alert('❌ L\'input est vide! Générez d\'abord l\'input.');
        return;
    }
    
    // Récupérer le nom du matériau (prefix)
    const materiauxInput = document.getElementById('materiau_name');
    const prefix = materiauxInput?.value || 'input';
    const filename = `${prefix}.in`;
    
    // Récupérer les chemins configurés
    const inputDirField = document.getElementById('path_inputs_editable');
    const outputDirField = document.getElementById('path_outputs_editable');
    
    const baseInputDir = inputDirField?.value || __genInputDefaultPath('inputs');
    const baseOutputDir = outputDirField?.value || __genInputDefaultPath('outputs');
    
    const inputDir = `${baseInputDir}/${prefix}`;
    const outputDir = `${baseOutputDir}/${prefix}`;

    // Garde-fou QE 7.5 avant écriture disque.
    const strictCheck = await verifierCompatibiliteQe75Strict(inputContent, { forSave: true });
    if (!strictCheck.ok) return;
    
    console.log(`  Prefix: ${prefix}`);
    console.log(`  Dossier input: ${inputDir}`);
    console.log(`  Dossier output: ${outputDir}`);
    console.log(`  Fichier: ${filename}`);
    
    try {
        // Appel API pour sauvegarder sur le serveur (mode natif)
        const fichierComplet = `${inputDir}/${filename}`;
        console.log(`📝 Appel API: /api/sauvegarder_fichier avec fichier=${fichierComplet}`);
        
        const result = await __genInputSaveToServer(fichierComplet, inputContent);
        console.log('✅ Sauvegarde réussie:', result);
        
        // Notification de succès
        const notif = document.createElement('div');
        notif.style.cssText = `
            position: fixed;
            top: 20px;
            left: 20px;
            background: linear-gradient(135deg, #2196f3 0%, #1976d2 100%);
            color: white;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            z-index: 10000;
            font-weight: bold;
            animation: slideInLeft 0.3s ease-out;
        `;
        notif.innerHTML = `
            💻 <strong>${filename}</strong> sauvegardé!<br>
            <small style="opacity: 0.9;">📁 ${result.file_path || result.filepath || inputDir}</small>
        `;
        
        document.body.appendChild(notif);
        
        // Animation CSS
        if (!document.getElementById('notification-left-animation-style')) {
            const style = document.createElement('style');
            style.id = 'notification-left-animation-style';
            style.textContent = `
                @keyframes slideInLeft {
                    from {
                        transform: translateX(-400px);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
                @keyframes slideOutLeft {
                    from {
                        transform: translateX(0);
                        opacity: 1;
                    }
                    to {
                        transform: translateX(-400px);
                        opacity: 0;
                    }
                }
            `;
            document.head.appendChild(style);
        }
        
        // Retirer après 4 secondes
        setTimeout(() => {
            notif.style.animation = 'slideOutLeft 0.3s ease-in';
            setTimeout(() => {
                notif.remove();
            }, 300);
        }, 4000);
        
    } catch (error) {
        console.error('❌ Erreur lors de la sauvegarde:', error);
        alert('❌ Impossible de sauvegarder sur le serveur.\n\n' + __genInputSaveErrorHint() + '\n\nErreur: ' + error.message);
    }
}

// ════════════════════════════════════════════════════════════════════════════
// VISUALISATION — XCrysDen (externe)
// ════════════════════════════════════════════════════════════════════════════

function visualiserInputActuel() {
    if (typeof window.ouvrirStructureExterne === 'function') {
        return window.ouvrirStructureExterne('xcrysden');
    }
    alert('❌ Module de visualisation non chargé — rechargez la page (Ctrl+F5).');
}

function visualiserContenuInput(content) {
    if (!content || !content.trim()) {
        alert('⚠️ Contenu vide.');
        return;
    }
    if (typeof window.ouvrirStructureExterne === 'function') {
        window.ouvrirStructureExterne('xcrysden', content);
    }
}

window.__genInputSaveUnified = __genInputSaveUnified;
window.__genInputSaveToServer = __genInputSaveToServer;
window.sauvegarderInputModifie = sauvegarderInputModifie;
window.genererInputComplet = genererInputComplet;
window.genererInputPwViaApi = genererInputPwViaApi;
window.sauvegarderInputAutomatiquement = sauvegarderInputAutomatiquement;
window.appliquerCompatibiliteQe75 = appliquerCompatibiliteQe75;
window.verifierCompatibiliteQe75Strict = verifierCompatibiliteQe75Strict;

console.log('✅ Script génération input Quantum ESPRESSO chargé');


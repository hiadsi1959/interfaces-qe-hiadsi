// ═══════════════════════════════════════════════════════════════════════════
// VISUALISATION STRUCTURE — QE Input → XSF → XCrysDen / VESTA
// Parseur QE .in (pas de viewer 3D intégré dans le navigateur)
// ═══════════════════════════════════════════════════════════════════════════

// ── Couleurs CPK des éléments ─────────────────────────────────────────────
const ELEMENT_COLORS = {
    H:'#FFFFFF', He:'#D9FFFF', Li:'#CC80FF', Be:'#C2FF00', B:'#FFB5B5',
    C:'#909090', N:'#3050F8', O:'#FF0D0D', F:'#90E050', Ne:'#B3E3F5',
    Na:'#AB5CF2', Mg:'#8AFF00', Al:'#BFA6A6', Si:'#F0C8A0', P:'#FF8000',
    S:'#FFFF30', Cl:'#1FF01F', Ar:'#80D1E3', K:'#8F40D4', Ca:'#3DFF00',
    Sc:'#E6E6E6', Ti:'#BFC2C7', V:'#A6A6AB', Cr:'#8A99C7', Mn:'#9C7AC7',
    Fe:'#E06633', Co:'#F090A0', Ni:'#50D050', Cu:'#C88033', Zn:'#7D80B0',
    Ga:'#C28F8F', Ge:'#668F8F', As:'#BD80E3', Se:'#FFA100', Br:'#A62929',
    Kr:'#5CB8D1', Rb:'#702EB0', Sr:'#00FF00', Y:'#94FFFF', Zr:'#94E0E0',
    Nb:'#73C2C9', Mo:'#54B5B5', Tc:'#3B9E9E', Ru:'#248F8F', Rh:'#0A7D8C',
    Pd:'#006985', Ag:'#C0C0C0', Cd:'#FFD98F', In:'#A67573', Sn:'#668080',
    Sb:'#9E63B5', Te:'#D47A00', I:'#940094', Xe:'#429EB0', Cs:'#57178F',
    Ba:'#00C900', La:'#70D4FF', Ce:'#FFFFC7', Pr:'#D9FFC7', Nd:'#C7FFC7',
    Pm:'#A3FFC7', Sm:'#8FFFC7', Eu:'#61FFC7', Gd:'#45FFC7', Tb:'#30FFC7',
    Dy:'#1FFFC7', Ho:'#00FF9C', Er:'#00E675', Tm:'#00D452', Yb:'#00BF38',
    Lu:'#00AB24', Hf:'#4DC2FF', Ta:'#4DA6FF', W:'#2194D6', Re:'#267DAB',
    Os:'#266696', Ir:'#175487', Pt:'#D0D0E0', Au:'#FFD123', Hg:'#B8B8D0',
    Tl:'#A6544D', Pb:'#575961', Bi:'#9E4FB5', Po:'#AB5C00', At:'#754F45',
    Rn:'#428296', Fr:'#420066', Ra:'#007D00', Ac:'#70ABFA', Th:'#00BAFF',
    Pa:'#00A1FF', U:'#008FFF', Np:'#0080FF', Pu:'#006BFF',
};

// ── Rayons covalents (Å) ──────────────────────────────────────────────────
const ELEMENT_RADII = {
    H:0.31, He:0.28, Li:1.28, Be:0.96, B:0.84, C:0.77, N:0.75, O:0.73,
    F:0.71, Ne:0.69, Na:1.66, Mg:1.41, Al:1.21, Si:1.11, P:1.07, S:1.05,
    Cl:1.02, Ar:1.06, K:2.03, Ca:1.76, Sc:1.70, Ti:1.60, V:1.53, Cr:1.39,
    Mn:1.61, Fe:1.52, Co:1.50, Ni:1.24, Cu:1.32, Zn:1.22, Ga:1.22, Ge:1.20,
    As:1.19, Se:1.20, Br:1.20, Kr:1.16, Rb:2.20, Sr:1.95, Y:1.90, Zr:1.75,
    Nb:1.64, Mo:1.54, Tc:1.47, Ru:1.46, Rh:1.42, Pd:1.39, Ag:1.45, Cd:1.44,
    In:1.42, Sn:1.39, Sb:1.39, Te:1.38, I:1.39, Xe:1.40, Cs:2.44, Ba:2.15,
    La:2.07, Ce:2.04, Pr:2.03, Nd:2.01, Pm:1.99, Sm:1.98, Eu:1.98, Gd:1.96,
    Tb:1.94, Dy:1.92, Ho:1.92, Er:1.89, Tm:1.90, Yb:1.87, Lu:1.87, Hf:1.75,
    Ta:1.70, W:1.62, Re:1.51, Os:1.44, Ir:1.41, Pt:1.36, Au:1.36, Hg:1.32,
    Tl:1.45, Pb:1.46, Bi:1.48, Po:1.40, At:1.50, Rn:1.50, Fr:2.60, Ra:2.21,
    Ac:2.15, Th:2.06, Pa:2.00, U:1.96, Np:1.90, Pu:1.87,
};

// ── Constante de conversion Bohr → Angstrom ───────────────────────────────
const BOHR_TO_ANG = 0.529177210903;

// ════════════════════════════════════════════════════════════════════════════
// PARSEUR QE INPUT
// ════════════════════════════════════════════════════════════════════════════

/**
 * Parse un fichier input QE complet — parseur ligne-par-ligne robuste
 * Correction: la regex lookaheed (?=\n[A-Z_]+) déclenchait faussement sur les noms d'atomes (Ba, Fe, O...)
 */
function parseQEInput(inputText) {
    const result = {
        ibrav: 0,
        a: 1, b: 1, c: 1,
        cosAB: 0, cosAC: 0, cosBC: 0,
        nat: 0, ntyp: 0,
        cellParams: null,    // 3×3 si CELL_PARAMETERS
        cellUnits: 'angstrom',
        species: {},         // { symbol: { mass, pseudo } }
        atoms: [],           // { symbol, x, y, z }
        atomsUnit: 'crystal',
    };

    // ── Machine d'état ligne par ligne ────────────────────────────────────
    // Évite le bug des regex où Ba, Fe, O déclenchaient le lookahead [A-Z_]+
    let state = 'none'; // none | system | namelist | atomic_species | atomic_positions | cell_parameters

    const lines = inputText.split('\n');
    for (let i = 0; i < lines.length; i++) {
        // Supprimer commentaires QE (!) et Python (#), puis trimmer
        const line = lines[i].replace(/!.*$/, '').replace(/#.*$/, '').trim();
        if (!line) continue;

        const upper = line.toUpperCase();

        // ── Détection des en-têtes de sections ──────────────────────────
        if (upper.startsWith('&SYSTEM')) {
            state = 'system'; continue;
        }
        if (/^&\w+/.test(upper)) {
            state = 'namelist'; continue;
        }
        // Fin de namelist
        if (line === '/' && (state === 'system' || state === 'namelist')) {
            state = 'none'; continue;
        }
        if (upper.startsWith('ATOMIC_SPECIES')) {
            state = 'atomic_species'; continue;
        }
        if (upper.startsWith('ATOMIC_POSITIONS')) {
            state = 'atomic_positions';
            const m = line.match(/[\({]\s*(\w+)\s*[\)}]/);
            result.atomsUnit = m ? m[1].toLowerCase() : 'crystal';
            continue;
        }
        if (upper.startsWith('K_POINTS') || upper.startsWith('CONSTRAINTS') ||
            upper.startsWith('OCCUPATIONS') || upper.startsWith('ATOMIC_FORCES')) {
            state = 'k_points'; continue;
        }
        if (upper.startsWith('CELL_PARAMETERS')) {
            state = 'cell_parameters';
            const m = line.match(/[\({]\s*(\w+)\s*[\)}]/);
            result.cellUnits = m ? m[1].toLowerCase() : 'bohr';
            result.cellParams = [];
            continue;
        }

        // ── Traitement selon l'état ──────────────────────────────────────
        if (state === 'system' || state === 'namelist') {
            // celldm(n) = … (a en Bohr, rapports b/a, c/a, cosinus)
            const celldmRe = /\bcelldm\s*\(\s*(\d+)\s*\)\s*=\s*([\d.eEdD+\-]+)/gi;
            let cm;
            while ((cm = celldmRe.exec(line)) !== null) {
                const idx = parseInt(cm[1], 10);
                const val = parseFloat(cm[2].replace(/[dD]/g, 'e'));
                if (isNaN(val)) continue;
                if (!result.celldm) result.celldm = {};
                result.celldm[idx] = val;
            }
            // Plusieurs paires clé=valeur possibles sur la même ligne (séparées par virgule)
            const pairRe = /\b([a-zA-Z_]\w*)\s*=\s*([\d.eEdD+\-]+)/g;
            let m;
            while ((m = pairRe.exec(line)) !== null) {
                const key = m[1].toLowerCase();
                const val = parseFloat(m[2].replace(/[dD]/g, 'e'));
                if (isNaN(val)) continue;
                if (key === 'ibrav') result.ibrav = val;
                else if (key === 'a')     result.a = val;
                else if (key === 'b')     result.b = val;
                else if (key === 'c')     result.c = val;
                else if (key === 'cosab') result.cosAB = val;
                else if (key === 'cosac') result.cosAC = val;
                else if (key === 'cosbc') result.cosBC = val;
                else if (key === 'nat')   result.nat = val;
                else if (key === 'ntyp')  result.ntyp = val;
            }
        }

        else if (state === 'atomic_species') {
            const p = line.split(/\s+/);
            // Ligne valide: symbole masse pseudo
            if (p.length >= 2 && isNaN(parseFloat(p[0])) && p[0].length <= 6) {
                result.species[p[0]] = { mass: parseFloat(p[1]), pseudo: p[2] || '' };
            }
        }

        else if (state === 'atomic_positions') {
            const p = line.split(/\s+/);
            // Ligne valide: symbole x y z [fx fy fz]
            if (p.length >= 4 && isNaN(parseFloat(p[0])) && p[0].length <= 6) {
                result.atoms.push({
                    symbol: p[0].replace(/[0-9_]/g, ''),
                    x: parseFloat(p[1]),
                    y: parseFloat(p[2]),
                    z: parseFloat(p[3]),
                });
            }
        }

        else if (state === 'cell_parameters') {
            const p = line.split(/\s+/).slice(0, 3).map(Number);
            if (p.length === 3 && !isNaN(p[0]) && !isNaN(p[1]) && !isNaN(p[2])) {
                result.cellParams.push(p);
            }
        }
    }

    // ── celldm → a,b,c (Å) et cosinus ────────────────────────────────────
    if (result.celldm && result.celldm[1] != null) {
        const aBohr = result.celldm[1];
        const aAng = aBohr * BOHR_TO_ANG;
        // Si A/B/C absents (défaut 1), privilégier celldm
        if (!result.a || result.a === 1) result.a = aAng;
        if (result.celldm[2] != null) result.b = result.a * result.celldm[2];
        if (result.celldm[3] != null) result.c = result.a * result.celldm[3];
        if (result.celldm[4] != null && !result.cosAB && !result.cosBC) {
            // ibrav 5/12/13: cos(alpha) ; ibrav 14: cos(bc) — approximation utile
            const ibr = parseInt(result.ibrav, 10) || 0;
            if (ibr === 14) result.cosBC = result.celldm[4];
            else result.cosAB = result.celldm[4];
        }
        if (result.celldm[5] != null) result.cosAC = result.celldm[5];
        if (result.celldm[6] != null) result.cosAB = result.celldm[6];
    }

    // ── Valeurs par défaut et cohérence ───────────────────────────────────
    if (!result.b || result.b === 1) result.b = result.a;
    if (!result.c || result.c === 1) result.c = result.a;

    // Appliquer l'échelle sur CELL_PARAMETERS selon les unités
    if (result.cellParams && result.cellParams.length >= 3) {
        const scale = result.cellUnits.includes('bohr') ? BOHR_TO_ANG :
                      result.cellUnits.includes('alat')  ? result.a     : 1.0;
        if (scale !== 1.0) {
            result.cellParams = result.cellParams.map(r => r.map(v => v * scale));
        }
        // Garder uniquement les 3 premières lignes
        result.cellParams = result.cellParams.slice(0, 3);
    } else {
        result.cellParams = null;
    }

    return result;
}

// ════════════════════════════════════════════════════════════════════════════
// CALCUL DES VECTEURS DE MAILLE depuis ibrav
// ════════════════════════════════════════════════════════════════════════════

function getLatticeVectors(s) {
    if (s.cellParams) return s.cellParams;
    const a = s.a, b = s.b, c = s.c;
    const cosAB = s.cosAB, cosAC = s.cosAC, cosBC = s.cosBC;
    const ibrav = parseInt(s.ibrav);

    switch (ibrav) {
        case 1: // SC
            return [[a,0,0],[0,a,0],[0,0,a]];
        case 2: // FCC
            return [[-a/2,0,a/2],[0,a/2,a/2],[-a/2,a/2,0]];
        case 3: // BCC
            return [[a/2,a/2,a/2],[-a/2,a/2,a/2],[-a/2,-a/2,a/2]];
        case 4: { // Hexagonal
            return [[a,0,0],[-a/2,a*Math.sqrt(3)/2,0],[0,0,c]];
        }
        case 5: { // Trigonal (rhomboedral)
            const tx = Math.sqrt((1 - cosAB) / 2);
            const ty = Math.sqrt((1 - cosAB) / 6);
            const tz = Math.sqrt((1 + 2*cosAB) / 3);
            return [[a*tx, -a*ty, a*tz],[0, 2*a*ty, a*tz],[-a*tx, -a*ty, a*tz]];
        }
        case 6: // ST (simple tetragonal)
            return [[a,0,0],[0,a,0],[0,0,c]];
        case 7: { // BCT
            return [[a/2,-a/2,c/2],[a/2,a/2,c/2],[-a/2,-a/2,c/2]];
        }
        case 8: // Orthorhombic
            return [[a,0,0],[0,b,0],[0,0,c]];
        case 9: // Base-centered orthorhombic
            return [[a/2,b/2,0],[-a/2,b/2,0],[0,0,c]];
        case 10: { // Face-centered orthorhombic
            return [[a/2,0,c/2],[a/2,b/2,0],[0,b/2,c/2]];
        }
        case 11: // Body-centered orthorhombic
            return [[a/2,b/2,c/2],[-a/2,b/2,c/2],[-a/2,-b/2,c/2]];
        case 12: { // Simple monoclinic (c unique)
            const sinAB = Math.sqrt(1 - cosAB*cosAB);
            return [[a,0,0],[b*cosAB,b*sinAB,0],[0,0,c]];
        }
        case 13: { // Base-centered monoclinic
            const sinAB = Math.sqrt(1 - cosAB*cosAB);
            return [[a/2,0,-c/2],[b*cosAB,b*sinAB,0],[a/2,0,c/2]];
        }
        case 14: { // Triclinic
            const sinAB = Math.sqrt(1 - cosAB*cosAB);
            const cx = cosAC;
            const cy = (cosBC - cosAC*cosAB) / sinAB;
            const cz = Math.sqrt(Math.max(0, 1 - cx*cx - cy*cy));
            return [[a,0,0],[b*cosAB,b*sinAB,0],[c*cx,c*cy,c*cz]];
        }
        default:
            return [[a,0,0],[0,b||a,0],[0,0,c||a]];
    }
}

// ── Multiplication matrice-vecteur ────────────────────────────────────────
function matVec(M, v) {
    return [
        M[0][0]*v[0] + M[1][0]*v[1] + M[2][0]*v[2],
        M[0][1]*v[0] + M[1][1]*v[1] + M[2][1]*v[2],
        M[0][2]*v[0] + M[1][2]*v[1] + M[2][2]*v[2],
    ];
}

// ── Convertir positions fractionnaires → cartésiennes ────────────────────
function toCartesian(s) {
    const lattice = getLatticeVectors(s);
    const unit = s.atomsUnit;

    return s.atoms.map(at => {
        let x = at.x, y = at.y, z = at.z;
        if (unit.includes('crys') || unit.includes('frac')) {
            [x, y, z] = matVec(lattice, [x, y, z]);
        } else if (unit.includes('bohr')) {
            x *= BOHR_TO_ANG; y *= BOHR_TO_ANG; z *= BOHR_TO_ANG;
        } else if (unit.includes('alat')) {
            x *= s.a; y *= s.a; z *= s.a;
        }
        return { symbol: at.symbol, x, y, z };
    });
}

// Table numéros atomiques (export XSF)
const ATOMIC_NUMBERS = {
    H:1,He:2,Li:3,Be:4,B:5,C:6,N:7,O:8,F:9,Ne:10,
    Na:11,Mg:12,Al:13,Si:14,P:15,S:16,Cl:17,Ar:18,K:19,Ca:20,
    Sc:21,Ti:22,V:23,Cr:24,Mn:25,Fe:26,Co:27,Ni:28,Cu:29,Zn:30,
    Ga:31,Ge:32,As:33,Se:34,Br:35,Kr:36,Rb:37,Sr:38,Y:39,Zr:40,
    Nb:41,Mo:42,Tc:43,Ru:44,Rh:45,Pd:46,Ag:47,Cd:48,In:49,Sn:50,
    Sb:51,Te:52,I:53,Xe:54,Cs:55,Ba:56,La:57,Ce:58,Pr:59,Nd:60,
    Pm:61,Sm:62,Eu:63,Gd:64,Tb:65,Dy:66,Ho:67,Er:68,Tm:69,Yb:70,
    Lu:71,Hf:72,Ta:73,W:74,Re:75,Os:76,Ir:77,Pt:78,Au:79,Hg:80,
    Tl:81,Pb:82,Bi:83,Po:84,At:85,Rn:86,Fr:87,Ra:88,Ac:89,Th:90,
    Pa:91,U:92,Np:93,Pu:94,
};

function genererXSF(s, cartAtoms, lattice) {
    const fmt = (v, d) => v.toFixed(d == null ? 8 : d).padStart((d == null ? 8 : d) + 4);
    let xsf = 'CRYSTAL\n';
    xsf += 'PRIMVEC\n';
    lattice.forEach(function (v) {
        xsf += '  ' + fmt(v[0]) + '  ' + fmt(v[1]) + '  ' + fmt(v[2]) + '\n';
    });
    xsf += 'CONVVEC\n';
    lattice.forEach(function (v) {
        xsf += '  ' + fmt(v[0]) + '  ' + fmt(v[1]) + '  ' + fmt(v[2]) + '\n';
    });
    xsf += 'PRIMCOORD\n  ' + cartAtoms.length + '  1\n';
    cartAtoms.forEach(function (at) {
        const Z = ATOMIC_NUMBERS[at.symbol] || 1;
        xsf += '  ' + String(Z).padStart(3) + '  ' + fmt(at.x) + '  ' + fmt(at.y) + '  ' + fmt(at.z) + '\n';
    });
    return xsf;
}

// ════════════════════════════════════════════════════════════════════════════
// VISUALISATION EXTERNE — XCrysDen / VESTA (maille cristalline correcte)
// ════════════════════════════════════════════════════════════════════════════

function __visu3dLireInputCourant() {
    return (window.currentInputContent && window.currentInputContent.trim())
        ? window.currentInputContent
        : (document.getElementById('preview_input')?.value?.trim()
            ? document.getElementById('preview_input').value
            : document.getElementById('input_content')?.value?.trim()
                ? document.getElementById('input_content').value
                : document.getElementById('input_preview')?.value?.trim()
                    ? document.getElementById('input_preview').value
                    : document.getElementById('textarea_input_existant')?.value?.trim()
                        ? document.getElementById('textarea_input_existant').value
                        : document.getElementById('input_editeur')?.value?.trim()
                            ? document.getElementById('input_editeur').value
                            : null);
}

function __visu3dApiBase() {
    if (typeof window.getGenInputsApiBase === 'function') return window.getGenInputsApiBase();
    var loc = window.location;
    if (loc && loc.port === '5012') return loc.protocol + '//' + loc.host;
    return 'http://127.0.0.1:5012';
}

function __visu3dFormuleDepuisAtoms(cartAtoms) {
    const counts = {};
    cartAtoms.forEach(function (a) { counts[a.symbol] = (counts[a.symbol] || 0) + 1; });
    return Object.entries(counts).map(function (e) {
        return e[0] + (e[1] > 1 ? e[1] : '');
    }).join('');
}

/**
 * Ouvre la structure dans XCrysDen ou VESTA (fichier .xsf avec maille).
 * @param {string} viewer - 'xcrysden' | 'vesta'
 * @param {string} [inputContent] - contenu .in QE (optionnel)
 */
async function ouvrirStructureExterne(viewer, inputContent) {
    viewer = String(viewer || 'xcrysden').trim().toLowerCase();
    const content = inputContent || __visu3dLireInputCourant();
    if (!content || !String(content).trim()) {
        alert('⚠️ Aucun input à visualiser.\n\nGénérez d\'abord l\'input ou ouvrez un fichier .in.');
        return;
    }

    let s, cartAtoms, lattice;
    try {
        s = parseQEInput(content);
        if (!s.atoms.length) {
            alert('⚠️ Aucun atome dans ATOMIC_POSITIONS.');
            return;
        }
        cartAtoms = toCartesian(s);
        lattice = getLatticeVectors(s);
    } catch (e) {
        alert('❌ Erreur de lecture du fichier input:\n' + (e && e.message ? e.message : String(e)));
        return;
    }

    const formule = __visu3dFormuleDepuisAtoms(cartAtoms);
    const xsf = genererXSF(s, cartAtoms, lattice);
    const nom = formule + '.xsf';
    const label = viewer === 'vesta' ? 'VESTA' : 'XCrysDen';

    window._visu3d_s = s;
    window._visu3d_cartAtoms = cartAtoms;
    window._visu3d_lattice = lattice;
    window._visu3d_formule = formule;
    window._visu3d_lastContent = content;

    if (typeof window.tab1ShowStatus === 'function') {
        window.tab1ShowStatus('info', '⏳ Sauvegarde XSF + ouverture <strong>' + label + '</strong>…');
    }

    try {
        const r = await fetch(__visu3dApiBase() + '/api/structure/open', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ viewer: viewer, nom: nom, contenu: xsf }),
        });
        const data = await r.json();
        var cheminAff = data.relative || data.chemin || ('structures_xsf/' + nom);

        if (data.ok || data.succes) {
            if (typeof window.tab1ShowStatus === 'function') {
                window.tab1ShowStatus('ok',
                    '💾 XSF sauvé → <code>' + cheminAff + '</code>'
                    + ' · 🔬 <strong>' + label + '</strong> lancé');
            }
            return;
        }

        // XSF souvent déjà sauvé même si XCrySDen plante (OpenGL)
        if (data.xsf_saved || data.chemin || data.partial) {
            var failMsg = (data.error ? (' — ' + label + ' : ' + data.error) : '');
            if (typeof window.tab1ShowStatus === 'function') {
                window.tab1ShowStatus('warn',
                    '💾 XSF enregistré dans <code>' + cheminAff + '</code>' + failMsg
                    + '<br>Ouvrez-le avec <strong>VESTA</strong> ou en terminal : '
                    + '<code>xcrysden --xsf ' + cheminAff + '</code>');
            } else {
                alert('XSF sauvé : ' + cheminAff + failMsg
                    + '\nOuvrez avec VESTA ou : xcrysden --xsf «' + cheminAff + '»');
            }
            return;
        }

        visu3d_downloadXSF(formule);
        var msg = (data && data.error) ? data.error : ('HTTP ' + r.status);
        if (typeof window.tab1ShowStatus === 'function') {
            window.tab1ShowStatus('warn', '⚠️ ' + msg + ' — .xsf téléchargé (<code>' + nom + '</code>).');
        } else {
            alert('⚠️ ' + msg + '\nLe fichier .xsf a été téléchargé.');
        }
    } catch (e) {
        visu3d_downloadXSF(formule);
        if (typeof window.tab1ShowStatus === 'function') {
            window.tab1ShowStatus('warn',
                '⚠️ API indisponible — fichier <code>' + nom + '</code> téléchargé. Placez-le dans <code>structures_xsf/</code>.');
        } else {
            alert('⚠️ API indisponible.\nLe fichier .xsf a été téléchargé.');
        }
    }
}

function visu3d_downloadXSF(formule) {
    const s = window._visu3d_s;
    const cartAtoms = window._visu3d_cartAtoms;
    const lattice = window._visu3d_lattice;
    if (!s || !cartAtoms || !lattice) return;
    const xsf = genererXSF(s, cartAtoms, lattice);
    const blob = new Blob([xsf], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = (formule || 'structure') + '.xsf';
    a.click();
    URL.revokeObjectURL(a.href);
}

async function visu3d_ouvrirVESTA(formule) {
    const content = __visu3dLireInputCourant();
    if (content) {
        return ouvrirStructureExterne('vesta', content);
    }
    visu3d_downloadXSF(formule || window._visu3d_formule || 'structure');
}

window.ouvrirStructureExterne = ouvrirStructureExterne;
window.parseQEInput = parseQEInput;
window.visualiserInputActuel = function visualiserInputActuel() {
    return ouvrirStructureExterne('xcrysden');
};
/** @deprecated — redirige vers XCrysDen */
window.afficherVisualisation3D = function afficherVisualisation3D(inputContent) {
    return ouvrirStructureExterne('xcrysden', inputContent);
};

console.log('✅ Script visualisation structure (XCrysDen / VESTA) chargé');

/**
 * Ordres magnétiques AFM — organigramme Interface-QE :
 * 1) Système cristallin → colinéaire (nspin=2) ou non-colinéaire (nspin=4)
 * 2) Configurations FM / AFM-A,C,G… selon la branche
 * 3) Maille primitive compatible AFM ? sinon supercellule + split X1/X2
 */
(function () {
    'use strict';

    var MAGNETIC = /^(Gd|Tb|Dy|Ho|Er|Tm|Yb|Ce|Pr|Nd|Sm|Eu|Fe|Co|Ni|Mn|Cr|V|La)$/i;
    var RARE_EARTH = /^(La|Ce|Pr|Nd|Pm|Sm|Eu|Gd|Tb|Dy|Ho|Er|Tm|Yb|Lu|Y)$/i;
    var BSITE_TM = /^(V|Cr|Mn|Fe|Co|Ni)$/i;
    var A_SITE_WEAK = /^(La|Ce|Pr|Nd|Pm|Sm|Eu|Gd|Tb|Dy|Ho|Er|Tm|Yb|Lu|Y|Ba|Sr|Ca|K|Rb|Cs)$/i;

    window.AFM_TYPE_POLICIES = {
        fm: { label: 'FM', supercellDiag: null, branches: ['cubic_ortho', 'tetragonal', 'hex_trig'] },
        ferri: { label: 'Ferrimagnétique', supercellDiag: null, branches: ['cubic_ortho', 'tetragonal', 'hex_trig'] },
        dms: { label: 'DMS', supercellDiag: null, branches: ['cubic_ortho', 'tetragonal', 'hex_trig'] },
        afm: { label: 'AFM générique', supercellDiag: [2, 1, 1], branches: ['cubic_ortho', 'tetragonal'] },
        afm_g: { label: 'AFM-G (damier)', supercellDiag: [2, 2, 1], branches: ['cubic_ortho', 'tetragonal'] },
        afm_a: { label: 'AFM-A (feuillets)', supercellDiag: [1, 1, 2], branches: ['cubic_ortho', 'tetragonal'] },
        afm_c: { label: 'AFM-C (chaînes)', supercellDiag: [2, 1, 1], branches: ['cubic_ortho'] },
        afm_e: { label: 'AFM-E (maille étendue)', supercellDiag: [2, 2, 2], branches: ['cubic_ortho'] },
        afm_120: { label: 'AFM 120° (coplanaire)', supercellDiag: null, branches: ['hex_trig'] },
        afm_helical: { label: 'AFM hélicoïdal', supercellDiag: [1, 1, 2], branches: ['hex_trig'] },
    };

    var FM_DEF = {
        Gd: 0.7, Tb: 0.7, Dy: 0.7, Ho: 0.7, Er: 0.7, Tm: 0.7,
        Fe: 0.5, Co: 0.5, Ni: 0.31, Mn: 0.5, Cr: 0.5, V: 0.3,
        Eu: 0.5, Nd: 0.5, Sm: 0.5,
    };

    function normOrd(ordVal) {
        var ord = String(ordVal || 'fm').trim();
        if (AFM_TYPE_POLICIES[ord]) return ord;
        if (/^afm/.test(ord)) return 'afm';
        return ord;
    }

    function isMag(sym) {
        return MAGNETIC.test(baseSym(sym));
    }

    function baseSym(sym) {
        var m = /^([A-Z][a-z]?)/i.exec(String(sym || '').trim());
        return m ? m[1] : String(sym || '').trim();
    }

    function splitSuffix(sym) {
        var m = /^([A-Z][a-z]?)([12])$/i.exec(String(sym || '').trim());
        return m ? m[2] : '';
    }

    function hasMagSplit(species) {
        return (species || []).some(function (s) { return /^[A-Z][a-z]?[12]$/i.test(String(s)); });
    }

    function countMagSpecies(species) {
        var seen = {};
        (species || []).forEach(function (s) {
            var b = baseSym(s);
            if (isMag(b) && !seen[b]) { seen[b] = 1; }
        });
        return Object.keys(seen).length;
    }

    window.afmCountMagSpecies = countMagSpecies;
    window.afmIsMagSpecies = function (sym) { return isMag(baseSym(sym)); };

    /** Ordre FM/AFM/… suggéré à partir de l’analyse CIF (comme détection génération directe). */
    window.afmSuggestOrdreForAnalysis = function (analysis) {
        if (!analysis) return 'fm';
        var species = analysis.atomic_species || [];
        var formula = String(analysis.formula || '').replace(/\s/g, '');
        if (typeof window.MAG_CONFIGS_CONNUS === 'object' && formula) {
            var keys = Object.keys(window.MAG_CONFIGS_CONNUS);
            keys.sort(function (a, b) { return b.length - a.length; });
            for (var ki = 0; ki < keys.length; ki++) {
                var key = keys[ki];
                if (formula.toLowerCase().indexOf(key.toLowerCase()) >= 0) {
                    return window.MAG_CONFIGS_CONNUS[key].ordre || 'fm';
                }
            }
        }
        if (isPerovskiteLike(species) && detectPerovskiteBsite(species)) return 'afm_g';
        if (countMagSpecies(species) > 0) return 'fm';
        return 'fm';
    };

    function isRareEarth(sym) {
        return RARE_EARTH.test(baseSym(sym));
    }

    function isBsiteTm(sym) {
        return BSITE_TM.test(baseSym(sym));
    }

    function isAsiteWeak(sym) {
        return A_SITE_WEAK.test(baseSym(sym));
    }

    function isPerovskiteLike(species) {
        var bases = {};
        (species || []).forEach(function (s) { bases[baseSym(s)] = true; });
        return bases.O && detectPerovskiteBsite(species) != null;
    }

    /** @deprecated alias */
    function isRvo3Like(species) {
        return isPerovskiteLike(species) && detectPerovskiteBsite(species) === 'V';
    }

    function detectPerovskiteBsite(species) {
        var bases = {};
        (species || []).forEach(function (s) { bases[baseSym(s)] = true; });
        if (!bases.O) return null;
        var tms = [];
        (species || []).forEach(function (s) {
            var b = baseSym(s);
            if (BSITE_TM.test(b) && !splitSuffix(s) && tms.indexOf(b) < 0) tms.push(b);
        });
        if (tms.length === 1) return tms[0];
        if (tms.length > 1) {
            var prefs = ['V', 'Fe', 'Mn', 'Co', 'Ni', 'Cr'];
            for (var pi = 0; pi < prefs.length; pi++) {
                if (tms.indexOf(prefs[pi]) >= 0) return prefs[pi];
            }
        }
        return null;
    }

    function countElementInPositions(positions, element, unsplitOnly) {
        var el = baseSym(element);
        var n = 0;
        (positions || []).forEach(function (row) {
            var sym = row[0];
            if (baseSym(sym) !== el) return;
            if (unsplitOnly && splitSuffix(sym)) return;
            n++;
        });
        return n;
    }

    function hasUnsplitBsite(species, bsite) {
        bsite = bsite || detectPerovskiteBsite(species);
        if (!bsite) return false;
        return (species || []).some(function (s) {
            return baseSym(s) === bsite && !splitSuffix(s);
        });
    }

    function hasUnsplitVanadium(species) {
        return hasUnsplitBsite(species, 'V');
    }

    window.afmIsRvo3Like = isRvo3Like;
    window.afmIsPerovskiteLike = isPerovskiteLike;
    window.afmDetectPerovskiteBsite = detectPerovskiteBsite;

    function wrapFrac(v) {
        var x = parseFloat(v) % 1.0;
        if (x < 0) x += 1.0;
        if (Math.abs(x - 1.0) < 1e-8) x = 0.0;
        return x;
    }

    function afmSublatticeIndex(x, y, z, ordVal) {
        var ord = normOrd(ordVal);
        var fx = wrapFrac(x);
        var fy = wrapFrac(y);
        var fz = wrapFrac(z);
        var eps = 1e-5;
        if (ord === 'afm_a') return Math.floor((fz + eps) * 2) % 2;
        if (ord === 'afm_c') return Math.floor((fx + eps) * 2) % 2;
        if (ord === 'afm_e') {
            return (Math.floor((fx + eps) * 2) + Math.floor((fy + eps) * 2) + Math.floor((fz + eps) * 2)) % 2;
        }
        return (Math.floor((fx + eps) * 2) + Math.floor((fy + eps) * 2)) % 2;
    }

    function diagMatrix(diag) {
        if (!diag || diag.length !== 3) return null;
        return [[diag[0], 0, 0], [0, diag[1], 0], [0, 0, diag[2]]];
    }

    /** Branche organigramme selon crystal_system de l'analyse CIF. */
    window.afmCrystalBranch = function afmCrystalBranch(analysis) {
        var cs = String((analysis && analysis.crystal_system) || '').toLowerCase();
        if (/cubic|orthorhombic|monoclinic|triclinic/.test(cs)) return 'cubic_ortho';
        if (/tetragonal/.test(cs)) return 'tetragonal';
        if (/hexagonal|trigonal/.test(cs)) return 'hex_trig';
        return 'cubic_ortho';
    };

    /** Paramètres QE recommandés par branche (organigramme). */
    window.afmQeMagModeForBranch = function afmQeMagModeForBranch(branch) {
        if (branch === 'hex_trig') {
            return {
                typeMag: 'non_colin',
                nspin: '4',
                lspinorb: '.true.',
                note: 'Hexagonal / trigonal : non-colinéaire conseillé (spins inclinés). Activez <code>lspinorb=.true.</code> si couplage spin-orbite.',
            };
        }
        return {
            typeMag: 'mag',
            nspin: '2',
            lspinorb: '.false.',
            note: 'Cubique / orthorhombique / tétragonal : colinéaire <code>nspin=2</code>.',
        };
    };

    function ordersForBranch(branch) {
        if (branch === 'hex_trig') return ['fm', 'afm_120', 'afm_helical'];
        if (branch === 'tetragonal') return ['fm', 'ferri', 'dms', 'afm', 'afm_g', 'afm_a'];
        return ['fm', 'ferri', 'dms', 'afm', 'afm_g', 'afm_a', 'afm_c', 'afm_e'];
    }

    /** Étape maille : la maille actuelle permet-elle l'AFM sans supercellule ? */
    function afmMailleDecision(analysis, ordVal, cellType) {
        var species = (analysis && analysis.atomic_species) || [];
        var ord = normOrd(ordVal);
        if (ord === 'fm' || ord === 'dms' || ord === 'ferri') {
            return { keepCell: true, needSupercell: false, mailleNote: 'FM / DMS / ferrimagnétisme : maille unitaire OK.' };
        }
        if (isPerovskiteLike(species) && /^afm/.test(normOrd(ordVal))) {
            var bsite = detectPerovskiteBsite(species);
            return {
                keepCell: true,
                needSupercell: false,
                mailleNote: 'Pérovskite / oxyde : AFM sur site B (' + (bsite || 'TM')
                    + ') — split ' + (bsite || 'X') + '→' + (bsite || 'X') + '1/' + (bsite || 'X') + '2 si ≥2 ions B dans la maille.',
            };
        }
        if (hasMagSplit(species)) {
            return { keepCell: true, needSupercell: false, mailleNote: 'Espèces X1/X2 déjà présentes — conserver la maille.' };
        }
        var nMag = countMagSpecies(species);
        if (nMag >= 2) {
            return {
                keepCell: true,
                needSupercell: false,
                mailleNote: 'Plusieurs espèces magnétiques (' + species.filter(isMag).join(', ')
                    + ') — maille suffisante (ex. GdVO₃ AFM-G sans supercellule).',
            };
        }
        if (nMag === 0) {
            return { keepCell: true, needSupercell: false, mailleNote: 'Aucune espèce magnétique détectée.' };
        }
        var prim = cellType === 'primitive';
        var cs = String((analysis && analysis.crystal_system) || '').toLowerCase();
        if (!prim && /orthorhombic/.test(cs)) {
            return {
                keepCell: false,
                needSupercell: true,
                mailleNote: 'Une espèce magnétique — maille conventionnelle orthorhombique : supercellule + split X1/X2 recommandés pour AFM colinéaire.',
            };
        }
        return {
            keepCell: false,
            needSupercell: true,
            mailleNote: (prim ? 'Maille primitive' : 'Maille unitaire')
                + ' avec un seul ion magnétique — générer une supercellule puis Fe1/Fe2.',
        };
    }

    window.afmEvaluateStructure = function afmEvaluateStructure(analysis, ordVal, cellType) {
        var ord = normOrd(ordVal);
        var pol = AFM_TYPE_POLICIES[ord] || AFM_TYPE_POLICIES.afm;
        var branch = window.afmCrystalBranch(analysis);
        var species = (analysis && analysis.atomic_species) || [];
        var nMag = countMagSpecies(species);
        var nat = (analysis && analysis.nat) || 0;
        var applied = !!(window.__cifSupercellApplied && window.__cifSupercellApplied.matrix);
        var splitDone = hasMagSplit(species);
        var maille = afmMailleDecision(analysis, ord, cellType || 'conventional');

        var needsSupercell = maille.needSupercell && !applied && !splitDone;
        if (applied || splitDone) needsSupercell = false;

        var perov = isPerovskiteLike(species);
        var bsiteEl = detectPerovskiteBsite(species);
        var needsSplit = !splitDone && /^afm/.test(ord) && (
            (nMag === 1 && (applied || /^afm/.test(ord)))
            || (perov && bsiteEl && hasUnsplitBsite(species, bsiteEl))
        );

        var reason = maille.mailleNote;
        if (splitDone) {
            reason = '✅ Split magnétique X1/X2 actif — prêt pour starting_magnetization(1)>0, (2)<0.';
        } else if (perov && bsiteEl && hasUnsplitBsite(species, bsiteEl) && /^afm/.test(ord)) {
            reason = 'Pérovskite : split ' + bsiteEl + '→' + bsiteEl + '1/' + bsiteEl + '2 '
                + '(maille avec ≥2 ions ' + bsiteEl + ', ou supercellule si primitive).';
        } else if (applied) {
            reason = 'Supercellule ' + (window.__cifSupercellApplied.diag || []).join('×')
                + ' appliquée (' + nat + ' at.). '
                + (nMag === 1 ? 'Cliquez « Supercellule + split X1/V2 » si Fe1/Fe2 absents.' : '');
        }

        return {
            ord: ord,
            branch: branch,
            label: pol.label,
            needsSupercell: needsSupercell,
            needsSplit: needsSplit,
            needsPerovskiteSplit: perov && bsiteEl && hasUnsplitBsite(species, bsiteEl) && !splitDone,
            needsRvo3Split: perov && bsiteEl === 'V' && hasUnsplitBsite(species, 'V') && !splitDone,
            bsiteElement: bsiteEl,
            reason: reason,
            strategy: splitDone ? 'split_done' : (perov ? 'perovskite_bsite' : (nMag >= 2 ? 'multi_species' : 'single_species_split')),
            nMagSpecies: nMag,
            magneticSpecies: species.filter(isMag),
            supercellDiag: pol.supercellDiag,
            supercellMatrix: pol.supercellDiag ? diagMatrix(pol.supercellDiag) : null,
            nat: nat,
        };
    };

    window.afmResolveStartingMags = function afmResolveStartingMags(species, ordVal, smManual) {
        var ord = normOrd(ordVal);
        var result = new Array(species.length);
        var manual = smManual || [];
        var i, sv, mn, b, suf, def;

        for (i = 0; i < species.length; i++) result[i] = null;

        /* Manual preset values apply only to magnetic species (in order). */
        var magManualIdx = 0;
        for (i = 0; i < species.length; i++) {
            b = baseSym(species[i]);
            if (!isMag(b) || splitSuffix(species[i])) continue;
            if (magManualIdx < manual.length && manual[magManualIdx] !== '' && manual[magManualIdx] != null) {
                mn = parseFloat(String(manual[magManualIdx]).replace(/,/g, '.'));
                if (!isNaN(mn)) result[i] = manual[magManualIdx];
            }
            magManualIdx++;
        }

        /* Fe1 / Fe2 après split automatique */
        for (i = 0; i < species.length; i++) {
            if (result[i] != null) continue;
            suf = splitSuffix(species[i]);
            b = baseSym(species[i]);
            if (!isMag(b) || !suf) continue;
            def = (b === 'V') ? 0.5 : (FM_DEF[b] != null ? FM_DEF[b] : 0.5);
            result[i] = suf === '1' ? String(def) : String(-Math.abs(def));
        }

        if (/^afm/.test(ord) && isPerovskiteLike(species)) {
            for (i = 0; i < species.length; i++) {
                if (result[i] != null) continue;
                b = baseSym(species[i]);
                if ((isAsiteWeak(b) || b === 'O') && !splitSuffix(species[i])) result[i] = '0.0';
            }
        }
        if (/^afm/.test(ord) && hasMagSplit(species)) {
            for (i = 0; i < species.length; i++) {
                if (result[i] != null) continue;
                suf = splitSuffix(species[i]);
                b = baseSym(species[i]);
                if (isBsiteTm(b) && suf) {
                    def = FM_DEF[b] != null ? FM_DEF[b] : 0.5;
                    result[i] = suf === '1' ? String(def) : String(-Math.abs(def));
                }
            }
        }

        var magIdx = [];
        for (i = 0; i < species.length; i++) {
            b = baseSym(species[i]);
            if (!isMag(b) || splitSuffix(species[i])) continue;
            if (isPerovskiteLike(species) && isAsiteWeak(b)) continue;
            magIdx.push(i);
        }

        if (ord === 'fm' || ord === 'dms') {
            for (i = 0; i < magIdx.length; i++) {
                if (result[magIdx[i]] != null) continue;
                b = baseSym(species[magIdx[i]]);
                result[magIdx[i]] = String(ord === 'dms' ? 0.2 : (FM_DEF[b] != null ? FM_DEF[b] : 0.5));
            }
        } else if (/^afm/.test(ord) || ord === 'ferri') {
            for (i = 0; i < magIdx.length; i++) {
                if (result[magIdx[i]] != null) continue;
                b = baseSym(species[magIdx[i]]);
                def = FM_DEF[b] != null ? FM_DEF[b] : 0.5;
                if (i === 0) result[magIdx[i]] = String(def);
                else if (i === 1) result[magIdx[i]] = String(-Math.abs(def));
                else result[magIdx[i]] = '0.0';
            }
        }

        for (i = 0; i < species.length; i++) {
            b = baseSym(species[i]);
            if (!isMag(b) && !splitSuffix(species[i])) result[i] = '0.0';
        }
        return result;
    };

    window.__cifResolveStartingMags = window.afmResolveStartingMags;

    function setCifMagRadio(typeMag) {
        var ids = { non_mag: 'cif_tm_non_mag', mag: 'cif_tm_mag', non_colin: 'cif_tm_non_colin' };
        var el = document.getElementById(ids[typeMag] || ids.non_mag);
        if (el) el.checked = true;
        window.__cifTypeMagnetisme = typeMag;
        if (typeof window.cifSyncTypeMagnetisme === 'function') window.cifSyncTypeMagnetisme();
    }

    function toggleOrdreVisibility(branch) {
        var allowed = ordersForBranch(branch);
        var hexOnly = ['afm_120', 'afm_helical'];
        document.querySelectorAll('[data-cif-ordre]').forEach(function (lab) {
            var v = lab.getAttribute('data-cif-ordre');
            var show = allowed.indexOf(v) >= 0;
            lab.style.display = show ? '' : 'none';
        });
        var hexBlock = document.getElementById('cif_afm_hex_block');
        if (hexBlock) hexBlock.style.display = branch === 'hex_trig' ? 'block' : 'none';
        var colinBlock = document.getElementById('cif_afm_colin_block');
        if (colinBlock) colinBlock.style.display = branch === 'hex_trig' ? 'none' : 'block';
    }

    /** Applique l'organigramme après analyse CIF (système cristallin + QE + options visibles). */
    window.afmApplyStructureGuidance = async function afmApplyStructureGuidance(analysis, opts) {
        opts = opts || {};
        if (!analysis) return;
        window.__cifLastAnalysis = analysis;

        var branch = window.afmCrystalBranch(analysis);
        var qeMode = window.afmQeMagModeForBranch(branch);
        var flow = document.getElementById('cif_afm_flow_banner');

        if (flow) {
            var cs = analysis.crystal_system || '?';
            var sg = (analysis.spacegroup_symbol || '') + ' (' + (analysis.spacegroup_number || '') + ')';
            flow.style.display = 'block';
            flow.innerHTML =
                '<strong>📐 Structure détectée</strong> : ' + cs + ' · SG ' + sg + '<br>'
                + '<span style="font-size:0.9em;">' + qeMode.note + '</span>'
                + (branch === 'hex_trig'
                    ? '<br><span style="font-size:0.85em;color:#0f766e;">Configurations : FM, AFM 120°, AFM hélicoïdal.</span>'
                    : branch === 'tetragonal'
                        ? '<br><span style="font-size:0.85em;color:#4338ca;">Configurations : FM, AFM-A, AFM-G.</span>'
                        : '<br><span style="font-size:0.85em;color:#4338ca;">Configurations : FM, AFM-A, AFM-C, AFM-G.</span>');
        }

        toggleOrdreVisibility(branch);

        if (opts.autoMagMode !== false && countMagSpecies(analysis.atomic_species) > 0) {
            setCifMagRadio(qeMode.typeMag);
            var ls = document.getElementById('cif_lspinorb');
            if (ls && branch === 'hex_trig') ls.value = '.true.';
        }

        if (typeof window.afmRefreshSupercellBanner === 'function') {
            await window.afmRefreshSupercellBanner();
        }
    };

    window.afmFetchAnalysis = async function afmFetchAnalysis(cifText, extra) {
        var base = (typeof getGenInputsApiBase === 'function') ? getGenInputsApiBase() : 'http://127.0.0.1:5012';
        var cellEl = document.getElementById('cif_cell_type');
        var body = Object.assign({
            cif_text: cifText,
            cell_type: cellEl ? cellEl.value : 'conventional',
        }, extra || {});
        if (typeof window.afmCifAnalyzePayload === 'function') {
            body = window.afmCifAnalyzePayload(body);
        }
        var r = await fetch(base + '/api/cif/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        });
        var d = await r.json();
        if (!r.ok || !d.analysis) throw new Error((d && d.error) || ('HTTP ' + r.status));
        return d;
    };

    window.afmRefreshSupercellBanner = async function afmRefreshSupercellBanner() {
        var banner = document.getElementById('cif_afm_supercell_banner');
        if (!banner) return;

        var ordVal = window.__cifOrdreMagnetisme || 'fm';
        if (!/^afm/.test(ordVal) && ordVal !== 'afm') {
            banner.style.display = 'none';
            banner.innerHTML = '';
            return;
        }

        var analysis = window.__cifLastAnalysis;
        var cellEl = document.getElementById('cif_cell_type');
        var cellType = cellEl ? cellEl.value : 'conventional';

        if (!analysis) {
            var cifData = (typeof window.getCifDataCurrent === 'function') ? window.getCifDataCurrent() : null;
            if (cifData && cifData.content) {
                try {
                    var d = await window.afmFetchAnalysis(cifData.content);
                    analysis = d.analysis;
                    window.__cifLastAnalysis = analysis;
                } catch (_e) {}
            }
        }
        if (!analysis) {
            banner.style.display = 'block';
            banner.innerHTML = '<strong>ℹ️ Maille AFM</strong> — chargez un CIF pour l\'étape supercellule.';
            return;
        }

        var ev = window.afmEvaluateStructure(analysis, ordVal, cellType);
        var html = '<strong>🧲 ' + ev.label + '</strong> · <em>Étape maille</em><br>'
            + '<span style="font-size:0.92em;">' + ev.reason + '</span>';

        if (ev.needsSupercell && ev.supercellDiag) {
            html += '<br><button type="button" id="cif_afm_apply_supercell_btn" class="btn" style="margin-top:8px;padding:8px 14px;background:#7c3aed;color:#fff;border:none;border-radius:6px;font-weight:600;cursor:pointer;">'
                + '🔲 Supercellule ' + ev.supercellDiag.join('×') + '</button>';
        }
        if (ev.needsSplit || (window.__cifSupercellApplied && !hasMagSplit(analysis.atomic_species))) {
            var splitLabel = ev.needsPerovskiteSplit && ev.bsiteElement
                ? ('⚛️ Split ' + ev.bsiteElement + '→' + ev.bsiteElement + '1/' + ev.bsiteElement + '2 (site B)')
                : '⚛️ Supercellule + split X1/X2';
            html += '<br><button type="button" id="cif_afm_apply_split_btn" class="btn" style="margin-top:8px;margin-left:6px;padding:8px 14px;background:#059669;color:#fff;border:none;border-radius:6px;font-weight:600;cursor:pointer;">'
                + splitLabel + '</button>';
        }
        if (hasMagSplit(analysis.atomic_species)) {
            html += '<br><span style="color:#065f46;font-size:0.88em;">✅ Types '
                + analysis.atomic_species.filter(function (s) { return /[12]$/.test(s); }).join(', ')
                + ' prêts pour QE.</span>';
        }

        banner.style.display = 'block';
        banner.innerHTML = html;

        var b1 = document.getElementById('cif_afm_apply_supercell_btn');
        if (b1) b1.onclick = function () { window.afmApplySuggestedSupercell(ordVal, false); };
        var b2 = document.getElementById('cif_afm_apply_split_btn');
        if (b2) b2.onclick = function () { window.afmApplySuggestedSupercell(ordVal, true); };
    };

    window.afmApplySuggestedSupercell = async function afmApplySuggestedSupercell(ordVal, withSplit) {
        var cifData = (typeof window.getCifDataCurrent === 'function') ? window.getCifDataCurrent() : null;
        if (!cifData || !cifData.content) {
            alert('❌ Chargez d\'abord un fichier CIF.');
            return;
        }
        ordVal = ordVal || window.__cifOrdreMagnetisme || 'afm_g';
        var analysis = window.__cifLastAnalysis || {};
        var cellEl = document.getElementById('cif_cell_type');
        var ev = window.afmEvaluateStructure(analysis, ordVal, cellEl ? cellEl.value : 'conventional');
        var statusDiv = document.getElementById('gestion_fichiers_status');

        var payload = {
            cif_text: cifData.content,
            cell_type: cellEl ? cellEl.value : 'conventional',
            afm_type: ordVal,
        };
        if (ev.supercellMatrix && !ev.needsRvo3Split) payload.supercell_matrix = ev.supercellMatrix;
        if (withSplit || ev.needsSplit) payload.afm_split_sublattices = true;
        if (ev.needsRvo3Split) delete payload.supercell_matrix;

        if (statusDiv) {
            statusDiv.innerHTML = '<div class="alert alert-info">⏳ '
                + (payload.supercell_matrix ? 'Supercellule ' + ev.supercellDiag.join('×') : 'Analyse')
                + (payload.afm_split_sublattices ? ' + split X1/X2…' : '…') + '</div>';
        }

        try {
            var data = await window.afmFetchAnalysis(cifData.content, payload);
            window.__cifLastAnalysis = data.analysis;
            if (payload.supercell_matrix) {
                window.__cifSupercellApplied = {
                    diag: ev.supercellDiag ? ev.supercellDiag.slice() : [],
                    matrix: payload.supercell_matrix,
                    afmType: ordVal,
                    nat: data.analysis.nat,
                };
            }
            if (typeof window.ensureCifPseudoRowsFromAnalysis === 'function') {
                window.ensureCifPseudoRowsFromAnalysis(data.analysis);
            }
            if (typeof window.ensureCifHubbardSpeciesRowsFromAnalysis === 'function') {
                await window.ensureCifHubbardSpeciesRowsFromAnalysis(data.analysis);
            }
            if (statusDiv) {
                var sp = (data.analysis.atomic_species || []).join(', ');
                statusDiv.innerHTML = '<div class="alert alert-success">✅ '
                    + data.analysis.nat + ' atomes · espèces : <code>' + sp + '</code>'
                    + (data.afm_split_applied ? ' · split X1/X2 appliqué.' : '') + '</div>';
            }
            if (typeof window.cifApplyOrdreMagValues === 'function') {
                window.cifApplyOrdreMagValues(null, ordVal);
            }
            await window.afmRefreshSupercellBanner();
        } catch (e) {
            var msg = e.message || String(e);
            if (statusDiv) statusDiv.innerHTML = '<div class="alert alert-error">❌ ' + msg + '</div>';
            alert('❌ ' + msg);
        }
    };

    window.afmCifAnalyzePayload = function afmCifAnalyzePayload(base) {
        var p = Object.assign({}, base || {});
        if (window.__cifSupercellApplied && window.__cifSupercellApplied.matrix) {
            p.supercell_matrix = window.__cifSupercellApplied.matrix;
        }
        var ord = window.__cifOrdreMagnetisme || p.afm_type;
        if (ord && /^afm/.test(ord)) {
            p.afm_type = ord;
            p.afm_split_sublattices = true;
            if (window.__cifSupercellApplied && window.__cifSupercellApplied.matrix) {
                p.supercell_matrix = window.__cifSupercellApplied.matrix;
            }
        }
        return p;
    };

    function parseSpeciesLines(text) {
        var map = {};
        String(text || '').split(/\r?\n/).forEach(function (line) {
            var t = line.trim();
            if (!t || t.charAt(0) === '!') return;
            var p = t.split(/\s+/);
            if (p[0]) map[p[0]] = t;
        });
        return map;
    }

    function parsePositionLines(text) {
        var rows = [];
        String(text || '').split(/\r?\n/).forEach(function (line) {
            var t = line.trim();
            if (!t || t.charAt(0) === '!' || /^ATOMIC_POSITIONS/i.test(t)) return;
            var p = t.split(/\s+/);
            if (p.length >= 4) {
                rows.push([p[0], parseFloat(p[1]), parseFloat(p[2]), parseFloat(p[3])]);
            }
        });
        return rows;
    }

    function formatPositionLines(rows) {
        return rows.map(function (r) {
            return r[0] + '  ' + r[1].toFixed(8) + '  ' + r[2].toFixed(8) + '  ' + r[3].toFixed(8);
        }).join('\n');
    }

    function rebuildSpeciesText(order, speciesMap) {
        var out = [];
        order.forEach(function (sp) {
            if (speciesMap[sp]) {
                out.push(speciesMap[sp]);
            } else {
                var base = baseSym(sp);
                if (speciesMap[base]) {
                    out.push(speciesMap[base].replace(/^\S+/, sp));
                }
            }
        });
        return out.join('\n');
    }

    window.afmSplitPerovskiteBsiteLocal = function afmSplitPerovskiteBsiteLocal(speciesText, positionsText, ordVal) {
        return window.afmApplyMagneticSplitLocal(speciesText, positionsText, ordVal);
    };

    /** Split AFM généralisé : pérovskite site B (V/Fe/Mn…) ou espèce magnétique unique (Fe1/Fe2). */
    window.afmApplyMagneticSplitLocal = function afmApplyMagneticSplitLocal(speciesText, positionsText, ordVal) {
        ordVal = ordVal || 'afm_g';
        var spMap = parseSpeciesLines(speciesText);
        var speciesOrder = Object.keys(spMap);
        var pos = parsePositionLines(positionsText);
        var unchanged = {
            changed: false,
            speciesText: speciesText,
            positionsText: positionsText,
            species: speciesOrder,
            nat: pos.length,
            ntyp: speciesOrder.length,
            strategy: 'none',
        };

        var bsite = detectPerovskiteBsite(speciesOrder);
        if (bsite && isPerovskiteLike(speciesOrder) && hasUnsplitBsite(speciesOrder, bsite)) {
            if (countElementInPositions(pos, bsite, true) < 2) {
                return unchanged;
            }
            var newPosB = [];
            var countB = [0, 0];
            pos.forEach(function (row) {
                var sym = row[0];
                if (baseSym(sym) === bsite && !splitSuffix(sym)) {
                    var sub = afmSublatticeIndex(row[1], row[2], row[3], ordVal);
                    countB[sub]++;
                    newPosB.push([bsite + (sub + 1), row[1], row[2], row[3]]);
                } else {
                    newPosB.push(row.slice());
                }
            });
            if (countB[0] === 0 || countB[1] === 0) return unchanged;
            var newOrderB = [];
            speciesOrder.forEach(function (s) {
                var b = baseSym(s);
                if (!BSITE_TM.test(b) && b !== 'O') newOrderB.push(s);
            });
            if (newOrderB.indexOf(bsite + '1') < 0) newOrderB.push(bsite + '1', bsite + '2');
            speciesOrder.forEach(function (s) {
                if (baseSym(s) === 'O' && newOrderB.indexOf(s) < 0) newOrderB.push(s);
            });
            return {
                changed: true,
                speciesText: rebuildSpeciesText(newOrderB, spMap),
                positionsText: formatPositionLines(newPosB),
                species: newOrderB,
                nat: newPosB.length,
                ntyp: newOrderB.length,
                strategy: 'perovskite_bsite',
                bsiteElement: bsite,
            };
        }

        var magBases = [];
        speciesOrder.forEach(function (s) {
            var b = baseSym(s);
            if (isMag(b) && !splitSuffix(s) && magBases.indexOf(b) < 0) magBases.push(b);
        });
        if (magBases.length !== 1 || hasMagSplit(speciesOrder)) return unchanged;
        var base = magBases[0];
        if (countElementInPositions(pos, base, true) < 2) return unchanged;
        var newPosS = [];
        var countS = [0, 0];
        pos.forEach(function (row) {
            if (baseSym(row[0]) === base) {
                var sub2 = afmSublatticeIndex(row[1], row[2], row[3], ordVal);
                countS[sub2]++;
                newPosS.push([base + (sub2 + 1), row[1], row[2], row[3]]);
            } else {
                newPosS.push(row.slice());
            }
        });
        if (countS[0] === 0 || countS[1] === 0) return unchanged;
        var newOrderS = [base + '1', base + '2'];
        speciesOrder.forEach(function (s) {
            if (baseSym(s) !== base && newOrderS.indexOf(s) < 0) newOrderS.push(s);
        });
        return {
            changed: true,
            speciesText: rebuildSpeciesText(newOrderS, spMap),
            positionsText: formatPositionLines(newPosS),
            species: newOrderS,
            nat: newPosS.length,
            ntyp: newOrderS.length,
            strategy: 'single_species',
            bsiteElement: base,
        };
    };

    function replacePwBlock(text, headerRe, newBody, stopRe) {
        var lines = String(text || '').split(/\r?\n/);
        var start = -1;
        for (var i = 0; i < lines.length; i++) {
            if (headerRe.test(lines[i])) { start = i; break; }
        }
        if (start < 0) return text;
        var end = lines.length;
        for (var j = start + 1; j < lines.length; j++) {
            if (stopRe.test(lines[j])) { end = j; break; }
        }
        return lines.slice(0, start + 1).concat(String(newBody || '').split(/\r?\n/)).concat(lines.slice(end)).join('\n');
    }

    function hubbardUFromMap(sym, uMap) {
        uMap = uMap || {};
        if (Object.prototype.hasOwnProperty.call(uMap, sym)) {
            var v0 = parseFloat(String(uMap[sym]).replace(/,/g, '.'));
            if (!isNaN(v0) && v0 !== 0) return v0;
        }
        var m = /^([A-Z][a-z]?)([12])$/i.exec(String(sym || '').trim());
        if (m && Object.prototype.hasOwnProperty.call(uMap, m[1])) {
            var vb = parseFloat(String(uMap[m[1]]).replace(/,/g, '.'));
            if (!isNaN(vb) && vb !== 0) return vb;
        }
        return null;
    }

    window.applyAfmStructureToPwText = function applyAfmStructureToPwText(text, ordVal, opts) {
        opts = opts || {};
        ordVal = ordVal || 'afm_g';
        if (!/^afm/.test(ordVal) || !text) return text;

        var mSp = text.match(/^\s*ATOMIC_SPECIES\s*\n([\s\S]*?)(?=^\s*ATOMIC_POSITIONS)/im);
        var mPos = text.match(/^\s*ATOMIC_POSITIONS[^\n]*\n([\s\S]*?)(?=^\s*K_POINTS)/im);
        var spBlock = mSp ? mSp[1] : '';
        var posBlock = mPos ? mPos[1] : '';

        var split = window.afmApplyMagneticSplitLocal(spBlock, posBlock, ordVal);
        if (!split.changed) return text;

        var out = replacePwBlock(text, /^\s*ATOMIC_SPECIES\s*$/i, split.speciesText, /^\s*ATOMIC_POSITIONS/i);
        out = replacePwBlock(out, /^\s*ATOMIC_POSITIONS/i, split.positionsText, /^\s*K_POINTS/i);
        out = out.replace(/^\s*ntyp\s*=\s*\d+/im, '  ntyp  = ' + split.ntyp);
        out = out.replace(/^\s*nat\s*=\s*\d+/im, '  nat   = ' + split.nat);

        var prefix = opts.hubbard_prefix || 'cif';
        var hubPayload = null;
        try {
            if (prefix === 'cif' && typeof window.cifHubbardCollectForApi === 'function') {
                hubPayload = window.cifHubbardCollectForApi();
            } else if (prefix === 'gen' && typeof window.genHubbardCollectForApi === 'function') {
                hubPayload = window.genHubbardCollectForApi();
            }
        } catch (_eHub) {}
        if (hubPayload && hubPayload.hubbard_u) {
            var uMap = hubPayload.hubbard_u;
            var proj = String(hubPayload.hubbard_projection || 'ortho-atomic').replace(/[^\w\-]/g, '') || 'ortho-atomic';
            var rows = [];
            split.species.forEach(function (sym) {
                var uval = hubbardUFromMap(sym, uMap);
                if (uval == null) return;
                var mf = '3d';
                if (hubPayload.hubbard_manifolds) {
                    var mm = hubPayload.hubbard_manifolds;
                    if (mm[sym]) mf = String(mm[sym]).trim();
                    else {
                        var mb = /^([A-Z][a-z]?)([12])?$/i.exec(String(sym || '').trim());
                        if (mb && mm[mb[1]]) mf = String(mm[mb[1]]).trim();
                    }
                } else if (typeof window.hubbardManifoldForSpecies === 'function') {
                    mf = window.hubbardManifoldForSpecies(prefix, sym);
                } else if (typeof window.defaultManifoldForSpecies === 'function') {
                    mf = window.defaultManifoldForSpecies(sym);
                }
                var orbLabel = (typeof window.hubbardCardOrbitalLabel === 'function')
                    ? window.hubbardCardOrbitalLabel(sym, mf)
                    : (sym + '-' + mf);
                rows.push('U  ' + orbLabel + '  ' + Number(uval).toFixed(6));
            });
            if (rows.length) {
                out = out.replace(/\n\s*HUBBARD\s*\([^)]*\)[\s\S]*?(?=\n\s*K_POINTS|\s*$)/i, '\n');
                out = out.replace(/(\n\s*K_POINTS)/i, '\n\nHUBBARD (' + proj + ')\n' + rows.join('\n') + '\n$1');
            }
        } else if (/^\s*HUBBARD\s*\(/im.test(out)) {
            out = out.replace(/U\s+([A-Z][a-z]?)-(\w+)\s+([\d.]+)/gi, function (_m, el, orb, val) {
                if (/[12]$/.test(el)) return _m;
                return 'U  ' + el + '1-' + orb + '  ' + val + '\n  U  ' + el + '2-' + orb + '  ' + val;
            });
        }
        return out;
    };

    window.pwGenOrdreMagValue = function pwGenOrdreMagValue() {
        var sel = document.getElementById('pw_gen_ordre_mag_select');
        return sel ? (sel.value || window.ordreMagnetisme || 'fm') : (window.ordreMagnetisme || 'fm');
    };

    window.pwGenApplyOrdreMagValues = function pwGenApplyOrdreMagValues(ordre) {
        var ord = String(ordre || 'fm').trim();
        var vals = { fm: ['0.7', '0.3', '0.0'], ferri: ['0.7', '-0.3', '0.0'], dms: ['0.2', '0.0', '0.0'] };
        if (/^afm_g/.test(ord)) vals.afm_g = ['0.0', '0.5', '-0.5'];
        if (/^afm/.test(ord) && !vals[ord]) vals[ord] = ['0.5', '-0.5', '0.0'];
        var v = vals[ord] || vals[/^afm/.test(ord) ? (ord.indexOf('afm_g') === 0 ? 'afm_g' : ord) : 'fm'] || vals.fm;
        var sm = document.getElementById('starting_magnetization');
        if (sm && v[0] != null) sm.value = v[0];
    };

    window.pwGenPrepareAfmStructure = function pwGenPrepareAfmStructure() {
        var nsEl = document.getElementById('nspin');
        if (nsEl && String(nsEl.value || '').trim() === '4') return false;
        var ord = window.pwGenOrdreMagValue();
        if (!/^afm/.test(ord)) return false;
        var spEl = document.getElementById('atomic_species');
        var posEl = document.getElementById('atomic_positions');
        if (!spEl || !posEl) return false;
        var split = window.afmApplyMagneticSplitLocal(spEl.value, posEl.value, ord);
        if (!split.changed) return false;
        spEl.value = split.speciesText;
        posEl.value = split.positionsText;
        if (window.atomicSpeciesGlobal != null) window.atomicSpeciesGlobal = split.speciesText;
        var ntypEl = document.getElementById('ntyp');
        var natEl = document.getElementById('nat');
        if (ntypEl) ntypEl.value = String(split.ntyp);
        if (natEl) natEl.value = String(split.nat);
        window.pwGenApplyOrdreMagValues(ord);
        try {
            if (typeof window.pwGenOnAtomicSpeciesChanged === 'function') window.pwGenOnAtomicSpeciesChanged();
            if (typeof window.pwGenRefreshHubbardPanel === 'function') window.pwGenRefreshHubbardPanel();
        } catch (_eHb) {}
        return true;
    };

    window.applyPwGenMagnetismPostProcess = function applyPwGenMagnetismPostProcess(text) {
        if (!text || typeof text !== 'string') return text;

        var nsEl = document.getElementById('nspin');
        var ns = nsEl ? String(nsEl.value).trim() : '1';
        if (ns !== '1' && ns !== '2' && ns !== '4') ns = '1';

        var ordVal = (typeof window.pwGenOrdreMagValue === 'function')
            ? window.pwGenOrdreMagValue()
            : (window.ordreMagnetisme || 'fm');

        if (/^afm/.test(ordVal) && ns === '2' && typeof window.applyAfmStructureToPwText === 'function') {
            try {
                text = window.applyAfmStructureToPwText(text, ordVal, { hubbard_prefix: 'gen' });
            } catch (_eStr) { console.warn(_eStr); }
        }

        function pwGenField(id) {
            var el = document.getElementById(id);
            return el ? String(el.value || '').trim() : '';
        }

        function pwGenAngle(which, idx) {
            var v = pwGenField('pw_gen_' + which + '_' + idx);
            if (v !== '') return v;
            return pwGenField(which + '_' + idx);
        }

        var sm = pwGenField('starting_magnetization');
        var ncSm = pwGenField('pw_gen_nc_sm1');
        var lspin = pwGenField('lspinorb');
        if (ns === '4' && typeof window.nspin4ResolveLspinorb === 'function') {
            lspin = window.nspin4ResolveLspinorb('gen');
        } else if (lspin !== '.true.' && lspin !== '.false.') lspin = '.false.';
        var totM = pwGenField('tot_magnetization');

        var species = [];
        try {
            if (typeof window.parseSpeciesFromPwText === 'function')
                species = window.parseSpeciesFromPwText(text) || [];
        } catch (_eSp) {}

        var lines = text.split(/\r?\n/);
        var iSys = -1;
        for (var i = 0; i < lines.length; i++) {
            if (/^\s*&SYSTEM/i.test(lines[i])) { iSys = i; break; }
        }
        var iEnd = -1;
        if (iSys >= 0) {
            for (var j = iSys + 1; j < lines.length; j++) {
                if (/^\s*\/\s*$/.test(lines[j])) { iEnd = j; break; }
            }
        }
        if (iSys < 0 || iEnd < 0) return text;

        var inner = lines.slice(iSys + 1, iEnd).filter(function (l) {
            if (/^\s*!/.test(l)) return true;
            if (/^\s*nspin\s*=/i.test(l)) return false;
            if (/^\s*noncolin\s*=/i.test(l)) return false;
            if (/^\s*lspinorb\s*=/i.test(l)) return false;
            if (/^\s*starting_magnetization\s*\(/i.test(l)) return false;
            if (/^\s*tot_magnetization\s*=/i.test(l)) return false;
            if (/^\s*angle1\s*\(/i.test(l)) return false;
            if (/^\s*angle2\s*\(/i.test(l)) return false;
            return true;
        });

        if (ns === '1') {
            inner.push('  nspin = 1');
        } else if (ns === '2') {
            inner.push('  nspin = 2');
            var smManual = [sm, pwGenField('starting_magnetization_2'), pwGenField('starting_magnetization_3')];
            var smResolved = (species.length && typeof window.afmResolveStartingMags === 'function')
                ? window.afmResolveStartingMags(species, ordVal, smManual)
                : smManual;
            var rvo3Split = species.length >= 3 && hasMagSplit(species);
            if (species.length && smResolved && smResolved.length) {
                for (var si = 0; si < species.length; si++) {
                    var sv = smResolved[si];
                    if (sv == null || sv === '') continue;
                    var svNum = parseFloat(String(sv).replace(/,/g, '.'));
                    if (rvo3Split || (!isNaN(svNum) && svNum !== 0)) {
                        inner.push('  starting_magnetization(' + (si + 1) + ') = ' + sv);
                    }
                }
            } else {
                if (sm !== '') inner.push('  starting_magnetization(1) = ' + sm);
            }
            if (totM !== '') inner.push('  tot_magnetization = ' + totM);
        } else {
            if (typeof window.nspin4Flow !== 'undefined') {
                window.nspin4Flow.injectNoncolinSystem(inner, 'gen', lspin, totM);
            } else {
                inner.push('  noncolin = .true.');
                inner.push('  lspinorb = ' + lspin);
                var nc1 = ncSm !== '' ? ncSm : sm;
                if (nc1 !== '') inner.push('  starting_magnetization(1) = ' + nc1);
                var ntypNc = species.length || parseInt(pwGenField('ntyp'), 10) || 2;
                for (var ai = 1; ai <= ntypNc; ai++) {
                    var th = pwGenAngle('angle1', ai);
                    var ph = pwGenAngle('angle2', ai);
                    if (th !== '') inner.push('  angle1(' + ai + ') = ' + th);
                    if (ph !== '') inner.push('  angle2(' + ai + ') = ' + ph);
                }
            }
        }

        var out = lines.slice(0, iSys + 1).concat(inner).concat(lines.slice(iEnd)).join('\n');

        var hubOn = document.getElementById('gen_hubbard_enable');
        if (hubOn && hubOn.checked && ns === '2') {
            out = out.replace(/^\s*mixing_beta\s*=\s*[^\n]+/im, '    mixing_beta = 0.30');
        } else if (ns === '4' && typeof window.nspin4Flow !== 'undefined') {
            out = window.nspin4Flow.adjustMixingInOutput(out, 'gen');
        } else if (hubOn && hubOn.checked && ns === '4' && typeof window.nspin4Flow !== 'undefined') {
            out = window.nspin4Flow.adjustMixingInOutput(out, 'gen');
        }
        if (ns === '4' && typeof window.nspin4Flow !== 'undefined') {
            out = window.nspin4Flow.finalizeNoncolinOutput(out, lspin);
        }
        return out;
    };

})();

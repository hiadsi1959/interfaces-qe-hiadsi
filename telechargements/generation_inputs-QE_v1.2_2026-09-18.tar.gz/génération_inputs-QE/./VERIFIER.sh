#!/bin/bash
# VERIFIER.sh — Contrôle d'intégrité avant transfert ou après installation.
#
# Rôle :
#   Vérifie que tous les fichiers essentiels sont présents, que la syntaxe
#   des scripts JS et Python est correcte, et que les dépendances sont
#   satisfaites. Produit un résumé OK/KO/WARN.
#
# Usage :
#   ./VERIFIER.sh
#
# Codes de sortie :
#   0 = tout OK
#   1 = des échecs détectés
#
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
OK=0; KO=0; WARN=0

pass() { echo -e "  ${GREEN}✅${NC} $*"; OK=$((OK + 1)); }
fail() { echo -e "  ${RED}❌${NC} $*"; KO=$((KO + 1)); }
warn() { echo -e "  ${YELLOW}⚠️${NC}  $*"; WARN=$((WARN + 1)); }

echo -e "${CYAN}══════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}  Vérification — Génération Inputs QE${NC}"
echo -e "${CYAN}  Dossier : $HERE${NC}"
echo -e "${CYAN}══════════════════════════════════════════════════════════${NC}"

echo
echo "── Fichiers essentiels ──"
for f in index.html DEMARRER.sh CONFIGURER.sh backend/api_inputs_standalone.py backend/cif_to_qe.py; do
    [ -f "$f" ] && pass "$f" || fail "manquant : $f"
done

echo
echo "── Scripts JS (syntaxe) ──"
JS_FILES=(
    scripts/qe_input_dft_options.js
    scripts/hubbard_qe75.js
    scripts/nspin4_noncolin_flow.js
    scripts/script_elements_pseudos.js
    scripts/script_generation_input.js
    scripts/script_orchestration_generation.js
    scripts/script_gestion_fichiers_complet.js
    scripts/afm_magnetic_order.js
)
if command -v node >/dev/null 2>&1; then
    for f in "${JS_FILES[@]}"; do
        if [ -f "$f" ] && node --check "$f" 2>/dev/null; then
            pass "syntaxe OK : $f"
        else
            fail "syntaxe KO : $f"
        fi
    done
else
    warn "node absent — vérification syntaxe JS ignorée"
fi

echo
echo "── Python backend ──"
if python3 -m py_compile backend/cif_to_qe.py backend/api_inputs_standalone.py 2>/dev/null; then
    pass "py_compile backend OK"
else
    fail "py_compile backend KO"
fi

echo
echo "── Fonctionnelles DFT (input_dft QE 7.5) ──"
[ -f "$HERE/data/qe_input_dft_catalog.json" ] && pass 'data/qe_input_dft_catalog.json' || fail 'catalogue DFT manquant'
[ -f "$HERE/scripts/qe_input_dft_options.js" ] && pass 'scripts/qe_input_dft_options.js' || fail 'qe_input_dft_options.js manquant'
python3 -m pytest backend/test_input_dft_catalog.py -q 2>/dev/null && pass 'pytest catalogue DFT' || fail 'pytest catalogue DFT'
grep -q '"pw"' scripts/qe_input_dft_options.js && pass 'input_dft : pw (LDA)' || fail 'input_dft : pw manquant'
grep -q '"rscan"' scripts/qe_input_dft_options.js && pass 'input_dft : rscan' || fail 'input_dft : rscan manquant'
grep -q 'perovskite_abx3' scripts/script_type_materiau.js && pass 'classe matériau : mapping pérovskite' || fail 'mapping pérovskite manquant'
grep -q 'sec1_type_materiau_block' scripts/tab1_build_html.js && pass 'Tab1 : bloc type matériau intégré' || fail 'bloc type matériau Tab1 manquant'
grep -q 'id="kx"' scripts/script_interface_parametres_qe_simple.js && pass 'Tab1 : champs K_POINTS kx/ky/kz' || fail 'champs kx/ky/kz manquants'
grep -q '_normalize_afm_type' backend/cif_to_qe.py && pass 'normalisation afm-g → afm_g' || fail 'normalisation AFM manquante'
grep -q 'A-Za-z\]\[a-z\]?\\d\*' backend/qe75_verifier.py && pass 'vérif HUBBARD accepte V1/V2' || fail 'regex HUBBARD AFM trop stricte'
grep -q 'buildTypeMateriauFieldsHTML' scripts/script_type_materiau.js && pass 'buildTypeMateriauFieldsHTML' || fail 'buildTypeMateriauFieldsHTML manquant'
grep -q 'ensureTypeMateriauFields' scripts/script_type_materiau.js && pass 'ensureTypeMateriauFields (après restruct)' || fail 'ensureTypeMateriauFields manquant'
grep -q 'olivine_abxo4' scripts/base_donnees_structures.js && pass 'structure olivine' || fail 'structure olivine manquante'
grep -q 'dichalcogenide_2d_mx2' scripts/base_donnees_structures.js && pass 'structure 2D MX2' || fail 'structure 2D MX2 manquante'
python3 -m pytest backend/test_type_materiau_enrichissement.py -q 2>/dev/null && pass 'pytest enrichissement types matériau' || fail 'pytest enrichissement types matériau'
grep -q 'convergence_recommendations_panel' scripts/script_interface_parametres_qe_simple.js && pass 'panneau convergence dans parametres_container' || fail 'panneau convergence mal placé'
grep -q 'obtenirConteneurPanneauConvergence' scripts/script_type_materiau.js && pass 'ancrage panneau → paramètres calcul' || fail 'ancrage panneau manquant'
grep -q 'tab1_workflow_tracker' scripts/script_tab1_workflow_tracker.js && pass 'indicateur workflow unifié' || fail 'workflow tracker manquant'
grep -q 'script_tab1_workflow_tracker.js' index.html && pass 'index.html charge workflow tracker' || fail 'workflow tracker non lié'
[ -x CONFIGURER.sh ] && pass 'CONFIGURER.sh exécutable' || fail 'CONFIGURER.sh manquant ou non exécutable'
[ ! -f config_autres_pc.sh ] && pass 'config_autres_pc.sh supprimé (consolidé)' || fail 'config_autres_pc.sh encore présent'
[ ! -f RELANCER.sh ] && pass 'RELANCER.sh supprimé (ARRETER + DEMARRER)' || warn 'RELANCER.sh encore présent'
grep -q 'load_html_fragments.js' index.html && pass 'chargeur fragments HTML' || fail 'load_html_fragments.js non lié'
[ -f fragments/subsection_gestion.html ] && pass 'fragment subsection_gestion.html' || fail 'fragment gestion manquant'
grep -q "Cubique Faces Centrées (FCC)" scripts/tab1_build_html.js && pass 'ibrav 2 = FCC corrigé' || fail 'ibrav 2/FCC non corrigé'
python3 -m pytest backend/test_html_fragments.py backend/test_ibrav_bcc_fcc.py backend/test_workflow_user_scenarios.py backend/test_aux_templates_enriched.py -q 2>/dev/null && pass 'pytest P1-P4 améliorations' || fail 'pytest P1-P4'
python3 -m pytest backend/test_config_autres_pc.py -q 2>/dev/null && pass 'pytest CONFIGURER.sh' || fail 'pytest CONFIGURER'
[ -f build_generation_inputs.sh ] && pass 'build_generation_inputs.sh' || fail 'build_generation_inputs.sh manquant'
grep -q '__GEN_INPUTS_ARCHIVE_BELOW__' build_generation_inputs.sh 2>/dev/null && pass 'installateur self-extracting (marqueur)' || fail 'marqueur installateur absent'
if [ "${GEN_INPUTS_BUILDING:-0}" = 1 ]; then
    warn 'pytest installateur ignoré pendant le build (évite récursion)'
elif [ -f generation_inputs ]; then
    python3 -m pytest backend/test_generation_inputs_installer.py -q -k "not built_or_buildable" 2>/dev/null && pass 'pytest installateur generation_inputs' || fail 'pytest installateur generation_inputs'
else
    python3 -m pytest backend/test_generation_inputs_installer.py::test_build_script_exists -q 2>/dev/null && pass 'pytest script build installateur' || fail 'pytest script build installateur'
fi
grep -q 'cif_gestion_init.js' index.html && pass 'init CIF après fragment' || fail 'cif_gestion_init.js non lié'
grep -q 'initCifGestionAfterFragment' scripts/cif_gestion_init.js && pass 'initCifGestionAfterFragment' || fail 'init CIF manquant'
grep -q 'htmlFragmentsLoaded' scripts/cif_gestion_init.js && pass 'hook fragment → CIF' || fail 'hook CIF fragment manquant'
grep -q 'ph_zeu' scripts/qe_calc_type_options.js && pass 'menu ph_zeu (Born)' || fail 'ph_zeu menu manquant'
grep -q 'qe_polarization_born_berry' index.html && pass 'module polarisation Berry/Born' || fail 'qe_polarization_born_berry.js non lié'
python3 -m pytest backend/test_polarization_born_berry.py -q 2>/dev/null && pass 'pytest Berry / Born' || fail 'pytest Berry / Born'
grep -q 'Guide — génération\|guide.title' scripts/tab1_build_html.js scripts/script_tab1_restructuration_v2.js 2>/dev/null && pass 'guide mis à jour' || fail 'guide non mis à jour'
grep -q 'qe-section--structure' scripts/tab1_build_html.js scripts/script_tab1_restructuration_v2.js 2>/dev/null && pass 'sections design scientifique' || fail 'classes qe-section manquantes'

echo
echo "── Types inputs QE 7.5+ (catalogue + conformité) ──"
[ -f "$HERE/data/qe_input_types_catalog.json" ] && pass 'data/qe_input_types_catalog.json' || fail 'catalogue types QE manquant'
[ -f "$HERE/backend/qe_input_types_catalog.py" ] && pass 'backend/qe_input_types_catalog.py' || fail 'module catalogue types manquant'
[ -f "$HERE/backend/qe75_verifier.py" ] && pass 'backend/qe75_verifier.py' || fail 'vérificateur QE 7.5 manquant'
[ -f "$HERE/scripts/qe_input_types_catalog.js" ] && pass 'scripts/qe_input_types_catalog.js' || fail 'UI catalogue types manquante'
[ -f "$HERE/scripts/qe_calc_type_options.js" ] && pass 'scripts/qe_calc_type_options.js' || fail 'options types calcul manquantes'
grep -q 'qe_calc_type_options.js' index.html && pass 'index.html charge qe_calc_type_options.js' || fail 'qe_calc_type_options.js non lié dans index.html'
grep -q 'directCollectBuildOptionsForApi' scripts/script_generation_input.js && pass 'voie directe → directCollectBuildOptionsForApi' || fail 'collect API direct manquant'
grep -q 'genererInputPwViaApi' scripts/script_generation_input.js && pass 'voie directe pw.x → API Python' || fail 'genererInputPwViaApi manquant'
grep -q 'analysis_from_workflow_dict' backend/cif_to_qe.py && pass 'analysis_from_workflow_dict (Python)' || fail 'workflow analysis Python manquant'
grep -q '"workflow"' backend/api_inputs_standalone.py && pass 'API /api/inputs/build accepte workflow' || fail 'workflow API build manquant'
grep -q 'turbo_lanczos' scripts/qe_calc_type_options.js && pass 'menu optique (turbo_lanczos)' || fail 'types optiques manquants'
grep -q 'epw' scripts/qe_calc_type_options.js && pass 'menu supraconductivité (epw)' || fail 'type epw manquant'
grep -q 'pp_charge' scripts/qe_calc_type_options.js && pass 'menu pp.x variantes' || fail 'variantes pp manquantes'
python3 -m pytest backend/test_qe_input_types.py backend/test_qe75_conformity.py backend/test_qe_all_types_api.py -q 2>/dev/null && pass 'pytest tous types QE 7.5 + API workflow' || fail 'pytest types/API QE 7.5'
python3 -m pytest backend/test_qe75_conformity.py -q 2>/dev/null && pass 'pytest conformité QE 7.5' || fail 'pytest conformité QE 7.5'
grep -q 'api/qe/catalog' backend/api_inputs_standalone.py && pass 'API /api/qe/catalog' || fail 'API catalogue manquante'
grep -q 'api/qe/verify' backend/api_inputs_standalone.py && pass 'API /api/qe/verify' || fail 'API vérification manquante'

echo
echo "── Unification voies de génération ──"
grep -q 'onclick="genererInputAvecPreparation()"' index.html && pass 'bouton direct → genererInputAvecPreparation' || fail 'bouton direct pas unifié'
grep -q 'window.convertirCIFversInput = async function' index.html && fail 'convertirCIFversInput inline encore dans index.html' || pass 'CIF : pas de doublon inline index.html'
grep -q 'convertirCIFversInput' scripts/script_gestion_fichiers_complet.js && pass 'CIF : convertirCIFversInput dans script_gestion' || fail 'CIF : convertirCIFversInput manquant'
grep -q 'api/convertir_cif' scripts/script_gestion_fichiers_complet.js && fail 'fallback 5007 encore dans script_gestion' || pass 'CIF : fallback 5007 supprimé (script_gestion)'

echo
echo "── Dossiers inputs générés ──"
[ -d "$HERE/inputs_générés_direct" ] && pass 'inputs_générés_direct/' || fail 'inputs_générés_direct/ manquant'
[ -d "$HERE/inputs_convertis_cif" ] && pass 'inputs_convertis_cif/' || fail 'inputs_convertis_cif/ manquant'
[ -d "$HERE/inputs_générés" ] && warn 'ancien dossier inputs_générés/ encore présent' || pass 'ancien inputs_générés/ supprimé'
grep -q "'cif'" scripts/script_gestion_fichiers_complet.js && pass 'CIF save → source cif' || fail 'CIF save source manquant'
grep -q "'direct'" scripts/script_generation_input.js && pass 'direct save → source direct' || fail 'direct save source manquant'
grep -q '_path_under_write_roots' backend/api_inputs_standalone.py && pass 'API write limitée aux 2 dossiers' || fail 'API write roots manquant'

echo
grep -q 'cifPrepareNoncolinBeforeBuild' scripts/nspin4_noncolin_flow.js && pass 'cifPrepareNoncolinBeforeBuild' || fail 'cifPrepareNoncolinBeforeBuild'
grep -q 'pwGenFrPseudoDir' scripts/script_elements_pseudos.js && pass 'pwGenFrPseudoDir' || fail 'pwGenFrPseudoDir'
grep -q 'nspin4ResolveLspinorb' scripts/nspin4_noncolin_flow.js && pass 'nspin4ResolveLspinorb' || fail 'nspin4ResolveLspinorb'
grep -q 'pwGenScalarToFullRel' scripts/script_elements_pseudos.js && pass 'pwGenScalarToFullRel' || fail 'pwGenScalarToFullRel'
grep -q 'cifPrepareNoncolinBeforeBuild' scripts/script_gestion_fichiers_complet.js && pass 'CIF : prep avant build' || fail 'CIF : prep avant build'
grep -q 'const typeMag = magnetismeEffectifPourSystem' scripts/script_generation_input.js && pass 'fix typeMag (ReferenceError)' || fail 'fix typeMag'

grep -q 'QE_ALLOW_JS_FALLBACK' scripts/script_generation_input.js && pass 'API-only pw (pas de repli JS silencieux)' || fail 'QE_ALLOW_JS_FALLBACK manquant'
grep -q 'repli générateur JS local' scripts/script_generation_input.js && fail 'repli JS silencieux encore actif' || pass 'repli JS silencieux retiré'
[ -f "$HERE/data/qe_calc_type_defaults.json" ] && pass 'data/qe_calc_type_defaults.json' || fail 'defaults calcul JSON manquant'
[ -f "$HERE/styles/qe_legacy_inline.css" ] && pass 'CSS legacy extrait' || fail 'qe_legacy_inline.css manquant'
grep -q 'qe_legacy_inline.css' index.html && pass 'index.html lie CSS extrait' || fail 'lien CSS legacy manquant'
grep -q '/api/calc/recommended' backend/api_inputs_standalone.py && pass 'API /api/calc/recommended' || fail 'API calc recommended manquante'
grep -q '_SENSITIVE_READ_NAMES' backend/api_inputs_standalone.py && pass 'lecture fichiers durcie' || fail 'durcissement lecture manquant'
python3 -m pytest backend/test_optimize_toward_10.py -q 2>/dev/null && pass 'pytest optimisation 10/10' || fail 'pytest optimisation'

echo
echo "── Dépendances Python ──"
python3 -c "import flask" 2>/dev/null && pass 'flask' || warn 'flask absent — ./CONFIGURER.sh'
python3 -c "import flask_cors" 2>/dev/null && pass 'flask-cors' || warn 'flask-cors absent'
if python3 -c "import ase, spglib" 2>/dev/null; then
    pass 'ase + spglib'
elif python3 -c "import pymatgen" 2>/dev/null; then
    pass 'pymatgen'
else
    warn 'ase/spglib ou pymatgen absent — conversion CIF limitée'
fi

echo
echo "── Pseudopotentiels (optionnel pour générer, requis pour pw.x) ──"
FR="$HERE/pseudos/PBE_FR"
PB="$HERE/pseudos/PBE"
if [ -d "$FR" ] && ls "$FR"/*.UPF >/dev/null 2>&1; then
    pass "pseudos FR : $(ls "$FR"/*.UPF 2>/dev/null | wc -l) fichiers .UPF"
else
    warn "dossier pseudos/PBE_FR absent ou vide — à copier sur le PC de calcul"
fi
if [ -d "$PB" ] && ls "$PB"/*.UPF >/dev/null 2>&1; then
    pass "pseudos PBE : $(ls "$PB"/*.UPF 2>/dev/null | wc -l) fichiers .UPF"
else
    warn "dossier pseudos/PBE absent — calculs scalar-relativistic non disponibles localement"
fi

echo
echo "── Serveur (si déjà lancé) ──"
PORT="${GEN_INPUTS_PORT:-5012}"
if curl -sf --max-time 2 "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then
    pass "API http://127.0.0.1:${PORT}/api/health"
    TAG="$(curl -sf --max-time 2 "http://127.0.0.1:${PORT}/api/version" | grep -oE '"build_tag":"[^"]+"' | head -1 | cut -d'"' -f4 || true)"
    [ -n "$TAG" ] && pass "build_tag runtime : $TAG" || warn "build_tag non lu"
else
    warn "serveur non démarré (normal avant transfert) — lancez ./DEMARRER.sh après install"
fi

echo
echo -e "${CYAN}──────────────────────────────────────────────────────────${NC}"
echo -e "Résultat : ${GREEN}${OK} OK${NC}  ${RED}${KO} échec(s)${NC}  ${YELLOW}${WARN} avertissement(s)${NC}"
if [ "$KO" -gt 0 ]; then
    echo -e "${RED}Corrigez les échecs avant le transfert.${NC}"
    exit 1
fi
echo -e "${GREEN}Prêt pour ./build_generation_inputs.sh (ou ./compacter.sh)${NC}"
exit 0

#!/usr/bin/env sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
HOST=${HOST:-127.0.0.1}
PORT=${PORT:-8000}

if [ -f "$ROOT/env.sh" ]; then
    # shellcheck disable=SC1091
    . "$ROOT/env.sh"
elif [ -f "$ROOT/.venv/bin/activate" ]; then
    # shellcheck disable=SC1091
    . "$ROOT/.venv/bin/activate"
fi

if ! command -v python3 >/dev/null 2>&1; then
    printf '%s\n' "Erreur : Python 3 est requis. Lancez d'abord ./configure.sh" >&2
    exit 1
fi

while ! python3 -c 'import socket, sys; sock = socket.socket(); result = sock.connect_ex((sys.argv[1], int(sys.argv[2]))); sock.close(); sys.exit(0 if result else 1)' "$HOST" "$PORT"; do
    PORT=$((PORT + 1))
done

URL="http://$HOST:$PORT/interface/"
printf 'Interface disponible sur %s\n' "$URL"
printf 'Arrêt : Ctrl+C | Port de départ personnalisé : PORT=8080 ./start.sh\n'

HOST="$HOST" PORT="$PORT" python3 "$ROOT/api/server.py" &
SERVER_PID=$!
trap 'kill "$SERVER_PID" 2>/dev/null || true' EXIT INT TERM

python3 - "$HOST" "$PORT" <<'PY'
import socket
import sys
import time

host, port = sys.argv[1], int(sys.argv[2])
deadline = time.monotonic() + 5
while time.monotonic() < deadline:
    try:
        from urllib.request import urlopen
        with urlopen("http://%s:%d/api/health" % (host, port), timeout=0.3) as response:
            if response.status == 200:
                break
    except OSError:
        time.sleep(0.05)
else:
    raise SystemExit("Erreur : le serveur HTTP n'a pas démarré.")
PY

if [ "${OPEN_BROWSER:-1}" = "1" ]; then
    if command -v firefox >/dev/null 2>&1; then
        firefox --new-tab "$URL" >/dev/null 2>&1 &
    elif command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$URL" >/dev/null 2>&1 &
    else
        printf '%s\n' "Navigateur introuvable; ouvrez cette adresse manuellement : $URL"
    fi
fi

wait "$SERVER_PID"
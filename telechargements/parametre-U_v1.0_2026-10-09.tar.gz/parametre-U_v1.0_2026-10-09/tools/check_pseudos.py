#!/usr/bin/env python3
"""Vérifie (et optionnellement télécharge) les pseudos de data/elements.json.

    python3 tools/check_pseudos.py            # état local uniquement
    python3 tools/check_pseudos.py --fetch    # télécharge ce qui manque
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pipeline import elements as el   # noqa: E402
from pipeline import pseudos as ps    # noqa: E402


def local_status(sym):
    """(fichier, source) si présent localement, sinon (None, None)."""
    for c in el.pseudo_candidates(sym):
        p = os.path.join(ps.DEST_DIR, c)
        if os.path.exists(p):
            return c, "projet"
        for d in ps.EXTRA_DIRS:
            if os.path.exists(os.path.join(d, c)):
                return c, "local"
    # flou local
    for d in [ps.DEST_DIR] + ps.EXTRA_DIRS:
        if not os.path.isdir(d):
            continue
        for f in os.listdir(d):
            if f.upper().endswith(".UPF") and f.lower().startswith(sym.lower() + "."):
                return f, "local?"
    return None, None


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--fetch", action="store_true",
                    help="télécharger les pseudos manquants (réseau requis)")
    ap.add_argument("--only", nargs="*", help="restreindre à ces symboles (ex. Ni O)")
    args = ap.parse_args()

    syms = args.only or sorted(el.load_elements(), key=lambda s: el.load_elements()[s]["Z"])
    ok, miss = [], []
    for sym in syms:
        f, src = local_status(sym)
        if f:
            ok.append((sym, f, src))
        else:
            miss.append(sym)

    print("présents localement : %d/%d" % (len(ok), len(syms)))
    for sym, f, src in ok:
        print("  %-3s %-42s (%s)" % (sym, f, src))
    if miss:
        print("\nmanquants : %d — %s" % (len(miss), " ".join(miss)))
        if not args.fetch:
            print("relancez avec --fetch pour les télécharger")
            return 1
        ko = []
        for sym in miss:
            try:
                f, src = ps.ensure_pseudo(sym)
                print("  %-3s %-42s (%s)" % (sym, f, src))
            except ps.PseudoError as exc:
                ko.append(sym)
                print("  %-3s ÉCHEC : %s" % (sym, exc))
        if ko:
            print("\nintrouvables : %s" % " ".join(ko))
            return 1
    print("\nOK — tous les pseudos requis sont disponibles")
    return 0


if __name__ == "__main__":
    sys.exit(main())

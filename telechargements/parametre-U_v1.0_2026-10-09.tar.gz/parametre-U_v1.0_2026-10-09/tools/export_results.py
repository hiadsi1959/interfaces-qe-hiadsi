#!/usr/bin/env python3
"""Export des résultats de TOUS les jobs : table à l'écran et CSV.

    python3 tools/export_results.py            # table monospace
    python3 tools/export_results.py --csv out.csv
"""
import argparse
import csv
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pipeline import elements as el  # noqa: E402


def collect():
    base = os.path.join(el.ROOT, "outputs")
    rows = []
    if not os.path.isdir(base):
        return rows
    for name in sorted(os.listdir(base)):
        p = os.path.join(base, name, "résumé.json")
        if not os.path.exists(p):
            continue
        with open(p, encoding="utf-8") as f:
            s = json.load(f)
        e = s.get("energies_Ry", {})
        u = s.get("U", [])
        rows.append({
            "job": s.get("job", name),
            "formule": s.get("structure", {}).get("formula"),
            "natomes": s.get("structure", {}).get("nat"),
            "ecutwfc": s.get("parametres", {}).get("ecutwfc"),
            "ecutrho": s.get("parametres", {}).get("ecutrho"),
            "k": "x".join(map(str, s.get("parametres", {}).get("kmesh", []))),
            "q": "x".join(map(str, s.get("parametres", {}).get("nq", []))),
            "U_hp": "; ".join("%s=%.3f" % (x["label"], x["U_hp_x"])
                              for x in u if x.get("U_hp_x") is not None),
            "U_utilise": "; ".join("%s=%.3f" % (x["label"], x["U_utilise"])
                                   for x in u if x.get("U_utilise") is not None),
            "E_DFT_Ry": e.get("scf2") if e.get("scf2") is not None else e.get("scf1"),
            "E_DFTU_Ry": e.get("scf_u"),
            "dE_Ry": e.get("delta_DFTU_minus_DFT"),
            "dE_eV_fu": e.get("delta_par_unite_formelle_eV"),
            "M_scf_u": s.get("magnetisation_bohr", {}).get("scf_u"),
            "gap_scf_u_eV": s.get("gap_eV", {}).get("scf_u"),
            "avertissements": " | ".join(s.get("avertissements", [])),
        })
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--csv", metavar="FICHIER", help="écrire aussi un CSV")
    args = ap.parse_args()
    rows = collect()
    if not rows:
        print("aucun résultat dans outputs/")
        return 1
    cols = ["job", "formule", "natomes", "ecutwfc", "ecutrho", "k", "q",
            "U_hp", "U_utilise", "E_DFT_Ry", "E_DFTU_Ry", "dE_eV_fu",
            "M_scf_u", "gap_scf_u_eV"]
    widths = {c: max(len(str(c)), *(len(str(r.get(c, ""))) for r in rows))
              for c in cols}
    print("  ".join(str(c).ljust(widths[c]) for c in cols))
    print("  ".join("-" * widths[c] for c in cols))
    for r in rows:
        print("  ".join(("—" if r.get(c) in (None, "") else str(r.get(c)))
                        .ljust(widths[c]) for c in cols))
    if args.csv:
        with open(args.csv, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        print("\nCSV écrit :", args.csv)
    return 0


if __name__ == "__main__":
    sys.exit(main())

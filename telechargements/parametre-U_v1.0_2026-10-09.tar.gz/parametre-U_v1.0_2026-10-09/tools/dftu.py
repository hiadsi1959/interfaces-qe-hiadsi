#!/usr/bin/env python3
"""Pipeline DFT+U de Quantum ESPRESSO : hp.x (U par réponse linéaire) ->
scf DFT+U -> analyse.

Exemples :
  # U de Ni dans NiO (structure prototype + antiferromagnétique)
  python3 tools/dftu.py run --name nio --formula NiO --prototype rocksalt \\
      --a 4.17 --supercell 2 1 1 --afm

  # depuis un fichier de structure (cif, xsf, POSCAR, ...)
  python3 tools/dftu.py run --name mon_materiau --structure entree.cif

  # sans hp.x, U de littérature + surcharge explicite
  python3 tools/dftu.py run --name nio2 --structure nio.cif --skip-hp \\
      --u-source literature --u Ni=6.2

  python3 tools/dftu.py list
  python3 tools/dftu.py show nio
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pipeline import elements as el          # noqa: E402
from pipeline.job import Job, JobError, STEPS  # noqa: E402


def _symvals(pairs, what):
    out = {}
    for p in pairs or []:
        if "=" not in p:
            raise SystemExit("%s : format attendu SYM=valeur (%r)" % (what, p))
        k, v = p.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def _sitegroups(groups):
    out = {}
    for group in groups or []:
        if "=" not in group:
            raise SystemExit("--site-group : format attendu SYM=I,J (%r)" % group)
        symbol, raw_indices = group.split("=", 1)
        symbol = symbol.strip()
        try:
            indices = [int(value) for value in raw_indices.split(",")]
        except ValueError:
            raise SystemExit("--site-group : indices entiers attendus (%r)" % group)
        if not symbol or not indices or any(index < 1 for index in indices):
            raise SystemExit("--site-group : symbole et indices positifs requis (%r)" % group)
        out.setdefault(symbol, []).append(indices)
    return out or None


def cmd_run(args):
    if not args.resume and not args.structure and not args.formula:
        raise SystemExit("il faut --structure <fichier> ou --formula <formule>")
    opts = {
        "structure": args.structure,
        "formula": args.formula,
        "prototype": args.prototype,
        "a": args.a, "c": args.c, "ca": args.ca, "u_ase": args.ase_u,
        "supercell": args.supercell,
        "site_groups": _sitegroups(args.site_group),
        "hubbard_elements": args.hubbard_element,
        "magnetic": args.magnetic,
        "noncolin": args.magnetic == "noncolin",
        "lspinorb": bool(getattr(args, "lspinorb", False)),
        "afm_axis": (args.afm[0] if isinstance(args.afm, list) and args.afm
                     else args.afm),
        "mag_map": _symvals(args.mag, "--mag"),
        "start_mag": args.start_mag,
        "kind": args.kind,
        "ecutwfc": args.ecutwfc, "ecutrho": args.ecutrho,
        "kmesh": args.kmesh, "nq": args.nq,
        "smearing": args.smearing, "degauss": args.degauss,
        "conv_thr": args.conv_thr, "conv_thr_tight": args.conv_thr_tight,
        "u_source": args.u_source, "u_map": _symvals(args.u, "--u"),
        "skip_hp": args.skip_hp,
        "np": args.np or 4,
    }
    name = args.name or (args.formula or os.path.splitext(
        os.path.basename(args.structure or ""))[0])
    name = "".join(c for c in str(name or "") if c.isalnum() or c in "_-")
    if not name or name in {".", ".."}:
        raise SystemExit("identifiant de job invalide après sanitisation")
    if args.resume and not os.path.isfile(os.path.join(el.ROOT, "jobs", name, "state.json")):
        raise SystemExit("état introuvable pour la reprise : %s" % name)
    job = Job(name, opts, fresh=args.fresh)
    try:
        steps = args.steps.split(",") if args.steps else None
        job.run(dry_run=args.dry_run, steps=steps, np_=args.np, resume=args.resume)
    except JobError as exc:
        print("ERREUR : %s" % exc, file=sys.stderr)
        print("  journal : %s" % os.path.join(job.log_dir, "<étape>.out"), file=sys.stderr)
        return 1
    if not args.dry_run:
        rep = os.path.join(job.out_dir, "rapport.txt")
        if os.path.exists(rep):
            print("\n" + open(rep, encoding="utf-8").read())
    return 0


def cmd_list(_args):
    base = os.path.join(el.ROOT, "jobs")
    if not os.path.isdir(base) or not sorted(os.listdir(base)):
        print("aucun job")
        return 0
    fmt = "%-20s %-10s %-20s %s"
    print(fmt % ("JOB", "STATUT", "MAJ", "ÉTAPES"))
    for name in sorted(os.listdir(base)):
        sf = os.path.join(base, name, "state.json")
        if not os.path.exists(sf):
            continue
        with open(sf, encoding="utf-8") as f:
            stt = json.load(f)
        steps = stt.get("steps", {})
        ok = sum(1 for v in steps.values() if v.get("status") in {"done", "skipped"})
        hard_fail = [k for k, v in steps.items()
                     if v.get("status") == "failed"]
        soft_fail = [k for k, v in steps.items()
                     if v.get("status") == "soft_failed"]
        interrupted = [k for k, v in steps.items()
                       if v.get("status") == "interrupted"]
        analyse_done = steps.get("analyse", {}).get("status") == "done"
        if hard_fail:
            status = "ÉCHEC:%s" % ",".join(hard_fail)
        elif interrupted and not analyse_done:
            status = "interrompu:%s" % ",".join(interrupted)
        elif analyse_done:
            status = "terminé" + (
                " (soft:%s)" % ",".join(soft_fail) if soft_fail else "")
        elif soft_fail:
            status = "dégradé:%s" % ",".join(soft_fail)
        else:
            status = "%d/%d" % (ok, len(STEPS))
        print(fmt % (name, status, stt.get("updated", "?"),
                     " ".join(steps)))
    return 0


def cmd_show(args):
    p = os.path.join(el.ROOT, "outputs", args.name, "rapport.txt")
    if os.path.exists(p):
        print(open(p, encoding="utf-8").read())
        return 0
    sf = os.path.join(el.ROOT, "jobs", args.name, "state.json")
    if os.path.exists(sf):
        stt = json.load(open(sf, encoding="utf-8"))
        print(json.dumps(stt.get("steps", {}), indent=2, ensure_ascii=False))
        return 0
    print("job introuvable : %s" % args.name, file=sys.stderr)
    return 1


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Pipeline DFT+U (pw.x + hp.x) — QE 7.5",
        formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    sub = ap.add_subparsers(dest="cmd")

    r = sub.add_parser("run", help="lancer un job complet")
    r.add_argument("--name", help="identifiant du job (défaut : formule)")
    r.add_argument("--resume", action="store_true",
                   help="reprendre un job existant depuis la première étape incomplète")
    g = r.add_mutually_exclusive_group()
    g.add_argument("--structure",
                   help="fichier de structure (cif, xsf, POSCAR, ou <matériau>-scf.in)")
    g.add_argument("--formula", help="formule pour un prototype, ex. NiO")
    r.add_argument("--prototype", default="rocksalt",
                   help="prototype ASE pour --formula (défaut rocksalt)")
    r.add_argument("--a", type=float, help="paramètre de maille (Å)")
    r.add_argument("--c", type=float, help="paramètre c (Å)")
    r.add_argument("--ca", type=float, help="rapport c/a")
    r.add_argument("--ase-u", type=float, dest="ase_u", help="paramètre u (wurtzite)")
    r.add_argument("--supercell", nargs=3, type=int, metavar=("NX", "NY", "NZ"),
                   help="réplication de la maille")
    r.add_argument("--magnetic", choices=["auto", "on", "off", "noncolin"], default="auto",
                   help="aimantation : auto/on/off (colinéaire nspin=1|2) "
                        "ou noncolin (noncolin=.true., cas nspin=4)")
    r.add_argument("--lspinorb", action="store_true",
                   help="avec --magnetic noncolin : activer le couplage spin-orbite")
    r.add_argument("--afm", action="append", choices=["x", "y", "z"],
                   metavar="AXE",
                   help="alternance des spins par plans (répétable ; 1er axe utilisé)")
    r.add_argument("--mag", action="append", metavar="SYM=VAL",
                   help="aimantation imposée, ex. --mag Ni1=0.5 --mag Ni2=-0.5")
    r.add_argument("--site-group", action="append", metavar="SYM=I,J",
                   help="sites équivalents partageant un U, indices 1-based par élément")
    r.add_argument("--hubbard-element", action="append", metavar="SYM",
                   help="activer le canal Hubbard uniquement pour cet élément (répétable)")
    r.add_argument("--start-mag", type=float, default=0.5, dest="start_mag")
    r.add_argument("--kind", choices=["auto", "metal", "insulator", "semiconductor"],
                   default="auto",
                   help="auto/isolant/semi-conducteur = gap (scf2 si magnétique) ; "
                        "métal = smearing seul")
    r.add_argument("--ecutwfc", type=float, help="défaut : suggestion de l'UPF")
    r.add_argument("--ecutrho", type=float, help="défaut : suggestion de l'UPF")
    r.add_argument("--kmesh", nargs=3, type=int, default=None, metavar=("K1", "K2", "K3"),
                   help="maille k (défaut : 6×6×6 isolant / 8×8×8 métal)")
    r.add_argument("--nq", nargs=3, type=int, default=None, metavar=("Q1", "Q2", "Q3"),
                   help="maille q de hp.x (défaut 2 2 2)")
    r.add_argument("--smearing", default=None,
                   help="défaut : valeur du *-scf.in ou gauss selon le type")
    r.add_argument("--degauss", type=float, default=None,
                   help="défaut : valeur du *-scf.in ou selon le type")
    r.add_argument("--conv-thr", type=float, default=1.0e-10, dest="conv_thr")
    r.add_argument("--conv-thr-tight", type=float, default=1.0e-15,
                   dest="conv_thr_tight")
    r.add_argument("--u-source", choices=["hp", "literature"], default="hp",
                   dest="u_source", help="U utilisé pour le scf DFT+U (défaut hp)")
    r.add_argument("--u", action="append", metavar="SYM=EV",
                   help="U imposé, ex. --u Ni=6.2 (prioritaire sur tout)")
    r.add_argument("--skip-hp", action="store_true", dest="skip_hp",
                   help="ne pas lancer hp.x (U littérature ou --u)")
    r.add_argument("--np", type=int, default=None, help="processeurs MPI (défaut 4)")
    r.add_argument("--steps", help="sous-ensemble d'étapes : scf1,scf2,hp,scf_u,analyse")
    r.add_argument("--fresh", action="store_true",
                   help="effacer l'état existant du job")
    r.add_argument("--dry-run", action="store_true", dest="dry_run",
                   help="générer les entrées sans exécuter QE")
    r.set_defaults(func=cmd_run)

    l = sub.add_parser("list", help="lister les jobs")
    l.set_defaults(func=cmd_list)

    s = sub.add_parser("show", help="afficher le rapport d'un job")
    s.add_argument("name")
    s.set_defaults(func=cmd_show)

    args = ap.parse_args(argv)
    if not getattr(args, "func", None):
        ap.print_help()
        return 2
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Comparaison des paramètres de Hubbard U : hp.x vs littérature.

    python3 tools/u_compare.py            # tous les jobs ayant un calcul hp.x
    python3 tools/u_compare.py --elements # U de littérature de data/elements.json
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pipeline import elements as el  # noqa: E402


def jobs():
    base = os.path.join(el.ROOT, "outputs")
    out = []
    if not os.path.isdir(base):
        return out
    for name in sorted(os.listdir(base)):
        p = os.path.join(base, name, "résumé.json")
        if os.path.exists(p):
            out.append(json.load(open(p, encoding="utf-8")))
    return out


def print_elements():
    print("%-4s %-14s %-8s %-10s %-10s %s"
          % ("sym", "nom", "canal", "U_typ", "U_min..max", "pseudo"))
    for sym, e in sorted(el.load_elements().items(), key=lambda kv: kv[1]["Z"]):
        if not e.get("correlated"):
            continue
        print("%-4s %-14s %-8s %-10s %-10s %s"
              % (sym, e["name"], e.get("manifold") or "-",
                 e.get("U_typ") or "-",
                 "%s..%s" % (e.get("U_min"), e.get("U_max")) if e.get("U_min") else "-",
                 e.get("pseudo") or "—"))


def print_jobs():
    any_row = False
    print("%-14s %-6s %-8s %10s %12s %8s  %s"
          % ("job", "site", "élément", "U_hp.x", "U_littérature", "écart", "source"))
    for s in jobs():
        for u in s.get("U", []):
            hp, lit = u.get("U_hp_x"), u.get("U_litterature")
            if hp is None and lit is None:
                continue
            any_row = True
            ecart = ("%+.3f" % (hp - lit)) if (hp is not None and lit is not None) else "—"
            print("%-14s %-6s %-8s %10s %12s %8s  %s"
                  % (s.get("job"), u.get("label"), u.get("element"),
                     "%.4f" % hp if hp is not None else "—",
                     "%.2f" % lit if lit is not None else "—",
                     ecart, u.get("source") or "—"))
    if not any_row:
        print("aucun résultat U — lancez d'abord : python3 tools/dftu.py run ...")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--elements", action="store_true",
                    help="lister les U de littérature de data/elements.json")
    args = ap.parse_args()
    if args.elements:
        print_elements()
    else:
        print_jobs()
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Génère data/elements.json : éléments fortement corrélés (3d, 4f, 5f) +
éléments partenaires courants, avec manifold Hubbard, U de littérature indicatif,
et noms de pseudos pslibrary VÉRIFIÉS (HEAD 200 sur le serveur QE).
"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

# Index des pseudos vérifiés (généré par le sondage du serveur QE)
IDX_PATHS = ["/tmp/pseudo_all.json"]

# --- Données Hubbard (littérature indicative, eV) ---------------------------
# manifold = canal Hubbard par défaut (HUBBARD card « U El-manifold »)
# U_typ / U_min / U_max : ordres de grandeur courants en DFT+U (eV)
# dossier == None → élément "partenaire" (pas d'électrons corrélés typiques)
CORRELATED = [
    # sym, nom, Z, série, manifold, U_typ, U_min, U_max, magnétique?, commentaires
    ("Sc", "Scandium", 21, "3d", "3d", 3.0, 2.0, 4.0, True, "Rarement traité; 3d¹"),
    ("Ti", "Titane", 22, "3d", "3d", 3.0, 2.0, 4.0, True, "TiO₂, d¹ (Ti³⁺)"),
    ("V", "Vanadium", 23, "3d", "3d", 3.0, 2.0, 4.0, True, "VO₂, V₂O₃ (transition MOTT)"),
    ("Cr", "Chrome", 24, "3d", "3d", 3.5, 2.5, 4.5, True, "Cr₂O₃, CrI₃ (2D)"),
    ("Mn", "Manganèse", 25, "3d", "3d", 3.9, 3.0, 5.0, True, "MnO, MnO₂, manganites"),
    ("Fe", "Fer", 26, "3d", "3d", 4.3, 3.5, 5.5, True, "Fe₂O₃, Fe₃O₄, ferrites"),
    ("Co", "Cobalt", 27, "3d", "3d", 3.9, 3.0, 5.0, True, "LiCoO₂, CoO, cobaltites"),
    ("Ni", "Nickel", 28, "3d", "3d", 6.2, 5.0, 7.0, True, "NiO (MOTT isolant), nickelates"),
    ("Cu", "Cuivre", 29, "3d", "3d", 5.0, 4.0, 6.5, True, "CuO, cuprates (high-Tc)"),
    ("Zn", "Zinc", 30, "3d", "3d", 8.0, 6.0, 9.0, False, "d¹⁰ rempli; U grand, rarement utile"),
    ("Y", "Yttrium", 39, "4d", "4d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("Zr", "Zirconium", 40, "4d", "4d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("Nb", "Niobium", 41, "4d", "4d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("Mo", "Molybdène", 42, "4d", "4d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("Tc", "Technétium", 43, "4d", "4d", None, None, None, False, "Radioactif; calcul hp.x selon le composé"),
    ("Ru", "Ruthénium", 44, "4d", "4d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("Rh", "Rhodium", 45, "4d", "4d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("Pd", "Palladium", 46, "4d", "4d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("Ag", "Argent", 47, "4d", "4d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("Cd", "Cadmium", 48, "4d", "4d", None, None, None, False, "d¹⁰ rempli; canal à justifier selon le matériau"),
    ("La", "Lanthane", 57, "4f", "5d", 0.0, 0.0, 0.0, False, "4f vide (La³⁺); pas d'électrons corrélés"),
    ("Ce", "Cérium", 58, "4f", "4f", 5.0, 4.0, 7.0, True, "CeO₂, Ce₂O₃ (KONDO/valence mixte)"),
    ("Pr", "Praséodyme", 59, "4f", "4f", 5.0, 4.0, 7.0, True, "PrO₂, PrBa₂Cu₃O₇"),
    ("Nd", "Néodyme", 60, "4f", "4f", 5.0, 4.0, 7.0, True, "Nd₂Fe₁₄B, néodymates"),
    ("Pm", "Prométhium", 61, "4f", "4f", 5.0, 4.0, 7.0, False, "Radioactif; peu de données"),
    ("Sm", "Samarium", 62, "4f", "4f", 5.0, 4.0, 7.0, True, "SmB₆ (topologique), SmCo₅"),
    ("Eu", "Europium", 63, "4f", "4f", 6.0, 5.0, 8.0, True, "EuO (ferromagnétique), EuB₆"),
    ("Gd", "Gadolinium", 64, "4f", "4f", 6.0, 5.0, 8.0, True, "GdN, Gd₂O₃, GdBCO"),
    ("Tb", "Terbium", 65, "4f", "4f", 6.0, 5.0, 8.0, True, "TbMnO₃ (multiferroïque)"),
    ("Dy", "Dysprosium", 66, "4f", "4f", 6.0, 5.0, 8.0, True, "Dy₂Ti₂O₇ (spin glace)"),
    ("Ho", "Holmium", 67, "4f", "4f", 6.0, 5.0, 8.0, True, "Ho₂O₃, grenats"),
    ("Er", "Erbium", 68, "4f", "4f", 6.0, 5.0, 8.0, True, "ErBa₂Cu₃O₇"),
    ("Tm", "Thulium", 69, "4f", "4f", 6.0, 5.0, 8.0, True, "TmBCO, Tm₂O₃"),
    ("Yb", "Ytterbium", 70, "4f", "4f", 6.0, 5.0, 8.0, True, "YbB₁₂, YbInCu₄"),
    ("Lu", "Lutécium", 71, "4f", "4f", 0.0, 0.0, 0.0, False, "4f¹⁴ rempli; pas d'électrons corrélés"),
    ("Hf", "Hafnium", 72, "5d", "5d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("Ta", "Tantale", 73, "5d", "5d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("W", "Tungstène", 74, "5d", "5d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("Re", "Rhénium", 75, "5d", "5d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("Os", "Osmium", 76, "5d", "5d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("Ir", "Iridium", 77, "5d", "5d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("Pt", "Platine", 78, "5d", "5d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("Au", "Or", 79, "5d", "5d", None, None, None, False, "U dépend du composé; calcul hp.x recommandé"),
    ("Hg", "Mercure", 80, "5d", "5d", None, None, None, False, "d¹⁰ rempli; canal à justifier selon le matériau"),
    ("Ac", "Actinium", 89, "5f", "5d", 0.0, 0.0, 0.0, False, "5f vide; pas d'électrons corrélés"),
    ("Th", "Thorium", 90, "5f", "5f", 4.0, 3.0, 6.0, False, "ThO₂, Th est faiblement corrélé"),
    ("Pa", "Protactinium", 91, "5f", "5f", 4.0, 3.0, 6.0, True, "5f² (Pa⁴⁺)"),
    ("U", "Uranium", 92, "5f", "5f", 4.5, 3.5, 6.0, True, "UO₂ (combustible nucléaire), UTe₂"),
    ("Np", "Neptunium", 93, "5f", "5f", 4.5, 3.5, 6.0, True, "NpO₂"),
    ("Pu", "Plutonium", 94, "5f", "5f", 4.5, 3.5, 6.5, True, "δ-Pu, PuO₂ (anomalies 5f)"),
    ("Am", "Américium", 95, "5f", "5f", 5.0, 4.0, 7.0, True, "5f⁶ (Am³⁺)"),
    ("Cm", "Curium", 96, "5f", "5f", 5.5, 4.5, 7.5, True, "CmO₂, CmB₄"),
    ("Bk", "Berkélium", 97, "5f", "5f", None, None, None, False, "Radioactif; pas de U générique retenu"),
    ("Cf", "Californium", 98, "5f", "5f", None, None, None, False, "Radioactif; pas de U générique retenu"),
    ("Es", "Einsteinium", 99, "5f", "5f", None, None, None, False, "Radioactif; pas de U générique retenu"),
    ("Fm", "Fermium", 100, "5f", "5f", None, None, None, False, "Radioactif; pas de U générique retenu"),
    ("Md", "Mendélévium", 101, "5f", "5f", None, None, None, False, "Radioactif; pas de U générique retenu"),
    ("No", "Nobélium", 102, "5f", "5f", None, None, None, False, "Radioactif; pas de U générique retenu"),
    ("Lr", "Lawrencium", 103, "5f", "5f", None, None, None, False, "Radioactif; pas de U générique retenu"),
]

# Éléments partenaires (anions/cations non corrélés) — masses atomiques (u)
PARTNERS = [
    ("H", "Hydrogène", 1, 1.008), ("Li", "Lithium", 3, 6.94),
    ("Be", "Béryllium", 4, 9.012), ("B", "Bore", 5, 10.81),
    ("C", "Carbone", 6, 12.011), ("N", "Azote", 7, 14.007),
    ("O", "Oxygène", 8, 15.999), ("F", "Fluor", 9, 18.998),
    ("Na", "Sodium", 11, 22.990), ("Mg", "Magnésium", 12, 24.305),
    ("Al", "Aluminium", 13, 26.982), ("Si", "Silicium", 14, 28.085),
    ("P", "Phosphore", 15, 30.974), ("S", "Soufre", 16, 32.06),
    ("Cl", "Chlore", 17, 35.45), ("K", "Potassium", 19, 39.098),
    ("Ca", "Calcium", 20, 40.078), ("Ga", "Gallium", 31, 69.723),
    ("Ge", "Germanium", 32, 72.630), ("As", "Arsenic", 33, 74.922),
    ("Se", "Sélénium", 34, 78.971), ("Br", "Brome", 35, 79.904),
    ("Sr", "Strontium", 38, 87.62), ("In", "Indium", 49, 114.818),
    ("Sn", "Étain", 50, 118.710), ("Sb", "Antimoine", 51, 121.760),
    ("Te", "Tellure", 52, 127.60), ("I", "Iode", 53, 126.904),
    ("Cs", "Césium", 55, 132.905), ("Ba", "Baryum", 56, 137.327),
]

MASS = {
    "Sc": 44.956, "Ti": 47.867, "V": 50.942, "Cr": 51.996, "Mn": 54.938,
    "Fe": 55.845, "Co": 58.933, "Ni": 58.693, "Cu": 63.546, "Zn": 65.38,
    "La": 138.905, "Ce": 140.116, "Pr": 140.908, "Nd": 144.242, "Pm": 145.0,
    "Sm": 150.36, "Eu": 151.964, "Gd": 157.25, "Tb": 158.925, "Dy": 162.500,
    "Ho": 164.930, "Er": 167.259, "Tm": 168.934, "Yb": 173.045, "Lu": 174.967,
    "Ac": 227.0, "Th": 232.038, "Pa": 231.036, "U": 238.029, "Np": 237.0,
    "Pu": 244.0, "Am": 243.0, "Cm": 247.0, "Bk": 247.0, "Cf": 251.0,
    "Es": 252.0, "Fm": 257.0, "Md": 258.0, "No": 259.0, "Lr": 266.0,
    "Y": 88.906, "Zr": 91.224, "Nb": 92.906, "Mo": 95.95, "Tc": 98.0,
    "Ru": 101.07, "Rh": 102.906, "Pd": 106.42, "Ag": 107.868, "Cd": 112.414,
    "Hf": 178.49, "Ta": 180.948, "W": 183.84, "Re": 186.207, "Os": 190.23,
    "Ir": 192.217, "Pt": 195.084, "Au": 196.967, "Hg": 200.592,
}

# Priorité : PAW (kjpaw) d'abord, puis USPP (rrkjus) — les deux conviennent à hp.x
def pick_pseudo(cands):
    if not cands:
        return None, None
    paw = [c for c in cands if "kjpaw" in c]
    uspp = [c for c in cands if "rrkjus" in c]
    if paw:
        return paw[0], "PAW"
    if uspp:
        return uspp[0], "USPP"
    return cands[0], "USPP"


def main():
    idx = {}
    existing = {}
    existing_path = os.path.join(ROOT, "data", "elements.json")
    if os.path.exists(existing_path):
        with open(existing_path, encoding="utf-8") as f:
            existing = {e["symbol"]: e for e in json.load(f).get("elements", [])}
    for p in IDX_PATHS:
        if os.path.exists(p):
            with open(p) as f:
                for k, v in json.load(f).items():
                    idx.setdefault(k, v)

    elements = []
    for (sym, name, z, serie, manifold, ut, umin, umax, magnetic, note) in CORRELATED:
        cands = idx.get(sym) or existing.get(sym, {}).get("pseudo_candidates") or []
        previous_pseudo = existing.get(sym, {}).get("pseudo")
        if previous_pseudo and previous_pseudo not in cands:
            cands.insert(0, previous_pseudo)
        pseudo, ptype = pick_pseudo(cands)
        elements.append({
            "symbol": sym, "name": name, "Z": z, "series": serie,
            "correlated": True,
            "manifold": manifold,
            "U_typ": ut, "U_min": umin, "U_max": umax,
            "U_data_status": "indicative" if ut is not None and ut > 0 else (
                "inactive" if ut == 0 else "material_specific"),
            "magnetic_default": magnetic,
            "mass": MASS.get(sym),
            "pseudo": pseudo, "pseudo_type": ptype,
            "pseudo_candidates": cands,
            "note": note,
        })
    for (sym, name, z, mass) in PARTNERS:
        cands = idx.get(sym) or existing.get(sym, {}).get("pseudo_candidates") or []
        previous_pseudo = existing.get(sym, {}).get("pseudo")
        if previous_pseudo and previous_pseudo not in cands:
            cands.insert(0, previous_pseudo)
        pseudo, ptype = pick_pseudo(cands)
        elements.append({
            "symbol": sym, "name": name, "Z": z, "series": None,
            "correlated": False,
            "manifold": None,
            "U_typ": None, "U_min": None, "U_max": None,
            "U_data_status": "not_correlated",
            "magnetic_default": False,
            "mass": mass,
            "pseudo": pseudo, "pseudo_type": ptype,
            "pseudo_candidates": cands,
            "note": "élément partenaire",
        })

    out = os.path.join(ROOT, "data", "elements.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    database = {
        "units": "eV",
        "scope": ["3d", "4d", "5d", "4f", "5f"],
        "limits": (
            "U_typ, U_min et U_max sont des repères indicatifs compilés, et non des constantes "
            "universelles ni des valeurs rattachées à un composé unique. U dépend notamment "
            "du matériau, de la valence, des projecteurs et de la méthode. Les entrées sans "
            "base générique suffisante restent non renseignées; recalculer U par hp.x pour "
            "une étude quantitative. Les canaux 4d et 5d sont recensés comme candidats; "
            "aucune valeur élémentaire générique n'est fournie pour eux."
        ),
        "references": [
            {
                "citation": "Cococcioni et de Gironcoli, Phys. Rev. B 71, 035105 (2005)",
                "doi": "10.1103/PhysRevB.71.035105",
                "role": "Calcul de U par réponse linéaire",
            },
            {
                "citation": "Dudarev et al., Phys. Rev. B 57, 1505 (1998)",
                "doi": "10.1103/PhysRevB.57.1505",
                "role": "Convention U_eff en DFT+U",
            },
        ],
    }
    with open(out, "w", encoding="utf-8") as f:
        json.dump({"generated_from": "pslibrary HEAD probe + compilation indicative DFT+U",
                   "hubbard_u_database": database,
                   "elements": elements}, f, indent=2, ensure_ascii=False)
    n_ok = sum(1 for e in elements if e["pseudo"])
    print(f"{len(elements)} éléments écrits ({n_ok} avec pseudo vérifié) -> {out}")
    miss = [e["symbol"] for e in elements if not e["pseudo"]]
    if miss:
        print("sans pseudo:", miss)


if __name__ == "__main__":
    main()

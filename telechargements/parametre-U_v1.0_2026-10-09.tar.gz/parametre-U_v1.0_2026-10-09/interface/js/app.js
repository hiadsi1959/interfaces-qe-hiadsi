const state = {
  elements: [],
  sourceInfo: null,
  sourceDirty: true,
  selectedElements: [],
  groups: {},
  launchInFlight: false,
  validateInFlight: false,
  resultsSeq: 0,
  previewTimer: null,
  latestJobs: [],
  parallel: null,
};

const PIPELINE_ORDER = ['prepare', 'scf1', 'scf2', 'hp', 'scf_u', 'analyse'];
const STEP_LABELS = {
  prepare: 'Preparation',
  scf1: 'Initial SCF',
  scf2: 'Insulator SCF',
  hp: 'Linear response hp.x',
  scf_u: 'SCF + U (DFT+U)',
  analyse: 'U extraction / report',
};
const STEP_LABELS_SHORT = {
  prepare: 'Preparation', scf1: 'Initial SCF', scf2: 'Insulator SCF',
  hp: 'hp.x', scf_u: 'SCF+U', analyse: 'Analysis',
};
const STATUS_LABELS = {
  running: 'Running', queued: 'Queued', done: 'Done', failed: 'Failed',
  soft_failed: 'Degraded', degraded: 'Degraded',
  interrupted: 'Interrupted', prepared: 'Prepared', not_started: 'Not started',
};

const statusLabel = document.querySelector('#load-status');
const tabs = document.querySelectorAll('.tab');
const panels = {
  calculations: document.querySelector('#panel-calculations'),
  results: document.querySelector('#panel-results'),
  help: document.querySelector('#panel-help'),
};
const scfMode = document.querySelector('#scf-mode');
const formulaMode = document.querySelector('#formula-mode');
const fileMode = document.querySelector('#file-mode');
const elementSelection = document.querySelector('#element-selection');
const siteGroups = document.querySelector('#site-groups');
const catalogMiniBody = document.querySelector('#catalog-mini-body');
const catalogFullBody = document.querySelector('#catalog-full-body');
const catalogFull = document.querySelector('#catalog-full');
const catalogDescription = document.querySelector('#catalog-description');
const catalogReferences = document.querySelector('#catalog-references');
const catalogToggle = document.querySelector('#toggle-full-catalog');
const resultsList = document.querySelector('#results-list');
const jobMessage = document.querySelector('#job-message');
const scfPreview = document.querySelector('#scf-preview');
const scfPreviewContent = document.querySelector('#scf-preview-content');
const hpPreviewContent = document.querySelector('#hp-preview-content');
const scfPreviewMeta = document.querySelector('#scf-preview-meta');
const crystalFromScf = document.querySelector('#crystal-from-scf');
const materialNameInput = document.querySelector('#material-name-input');
const materialDatalist = document.querySelector('#material-datalist');
const scfFileDisplay = document.querySelector('#scf-file-display');
const choiceTip = document.querySelector('#choice-tip');
const choiceTipTitle = document.querySelector('#choice-tip-title');
const choiceTipBody = document.querySelector('#choice-tip-body');
let choiceTipTimer = null;
let choiceTipLeaveTimer = null;
const CHOICE_TIP_MS = 10000;

const SOURCE_GUIDE = {
  file: {
    tone: 'success',
    titleKey: 'tip.sourceFileTitle',
    bodyKey: 'tip.sourceFileBody',
  },
  scf: {
    tone: 'info',
    titleKey: 'tip.sourceScfTitle',
    bodyKey: 'tip.sourceScfBody',
  },
  formula: {
    tone: 'warning',
    titleKey: 'tip.sourceFormulaTitle',
    bodyKey: 'tip.sourceFormulaBody',
  },
};

function currentSourceMode() {
  return document.querySelector('input[name="source-mode"]:checked')?.value || 'file';
}

function hideChoiceTip() {
  if (choiceTipTimer) {
    clearTimeout(choiceTipTimer);
    choiceTipTimer = null;
  }
  if (choiceTipLeaveTimer) {
    clearTimeout(choiceTipLeaveTimer);
    choiceTipLeaveTimer = null;
  }
  if (!choiceTip) return;
  choiceTip.classList.add('is-leaving');
  choiceTipLeaveTimer = setTimeout(() => {
    choiceTip.classList.add('hidden');
    choiceTip.classList.remove('is-leaving', 'is-visible');
    choiceTipLeaveTimer = null;
  }, 320);
}

function showChoiceTip(title, body, tone = 'info') {
  if (!choiceTip || !choiceTipTitle || !choiceTipBody) return;
  if (choiceTipTimer) clearTimeout(choiceTipTimer);
  if (choiceTipLeaveTimer) clearTimeout(choiceTipLeaveTimer);
  choiceTipTitle.textContent = title || '';
  choiceTipBody.textContent = body || '';
  choiceTip.dataset.tone = tone || 'info';
  choiceTip.classList.remove('hidden', 'is-leaving');
  choiceTip.classList.add('is-visible');
  const bar = choiceTip.querySelector('.choice-tip-timer span');
  if (bar) {
    bar.style.animation = 'none';
    void bar.offsetWidth;
    bar.style.animation = '';
  }
  choiceTipTimer = setTimeout(hideChoiceTip, CHOICE_TIP_MS);
}

function tipText(key, fallback) {
  const translated = typeof t === 'function' ? t(key) : '';
  if (translated && translated !== key) return translated;
  return fallback;
}

function flashSourceTip(mode = currentSourceMode()) {
  const guide = SOURCE_GUIDE[mode] || SOURCE_GUIDE.file;
  const defaults = {
    file: {
      title: 'CIF / structure file',
      body: 'Recommended for a real material: lattice and positions come from the file. Set magnetism and UPFs next.',
    },
    scf: {
      title: 'From a validated scf.in',
      body: 'Uses inputs/<name>/<name>-scf.in. Prefer a file already relaxed in QE; otherwise a CIF is safer.',
    },
    formula: {
      title: 'Formula / prototype (tests)',
      body: 'Ideal ASE structure for benchmarks only — set a realistic lattice constant a. Prefer CIF for real alloys.',
    },
  };
  const d = defaults[mode] || defaults.file;
  showChoiceTip(
    tipText(guide.titleKey, d.title),
    tipText(guide.bodyKey, d.body),
    guide.tone,
  );
}

function flashCaseTip(caseKey) {
  const tips = {
    'afm-semiconductor': ['tip.caseAfmSemiTitle', 'tip.caseAfmSemiBody', 'AFM · semiconductor', 'Gapped magnetic oxide path (nspin=2 + scf2). Needs a supercell that fits opposite-spin sublattices.'],
    'afm-insulator': ['tip.caseAfmInsTitle', 'tip.caseAfmInsBody', 'AFM · insulator', 'Classic NiO-like path: same gapped hp.x route as semiconductor. Enlarge the cell for AFM.'],
    'afm-metal': ['tip.caseAfmMetTitle', 'tip.caseAfmMetBody', 'AFM · metal', 'Possible but less common. Smearing only — no insulator-style scf2.'],
    'fm-semiconductor': ['tip.caseFmSemiTitle', 'tip.caseFmSemiBody', 'FM · semiconductor', 'Magnetic semiconductor: nspin=2, gapped path with scf2 when needed.'],
    'fm-insulator': ['tip.caseFmInsTitle', 'tip.caseFmInsBody', 'FM · insulator', 'Ferromagnetic insulator: collinear nspin=2 and the gapped SCF path.'],
    'fm-metal': ['tip.caseFmMetTitle', 'tip.caseFmMetBody', 'FM · metal', 'Common for Fe, Co, Ni… Smearing; no insulator scf2.'],
    'nm-semiconductor': ['tip.caseNmSemiTitle', 'tip.caseNmSemiBody', 'NM · semiconductor', 'nspin=1. On a correlated magnet, U is often too low — use only if truly non-magnetic.'],
    'nm-insulator': ['tip.caseNmInsTitle', 'tip.caseNmInsBody', 'NM · insulator', 'Closed-shell insulator path (nspin=1). Rarely relevant for magnetic d/f U.'],
    'nm-metal': ['tip.caseNmMetTitle', 'tip.caseNmMetBody', 'NM · metal', 'Simple non-magnetic metal. Beware a false NM metal on a magnetic oxide.'],
    'ncl-semiconductor': ['tip.caseNclSemiTitle', 'tip.caseNclSemiBody', 'NCL · semiconductor', 'Noncollinear + gap: noncolin=.true. (no collinear scf2). Optional SOC. Higher cost.'],
    'ncl-insulator': ['tip.caseNclInsTitle', 'tip.caseNclInsBody', 'NCL · insulator', 'Noncollinear insulator: same NCL path as semiconductor (no scf2). Often used with SOC.'],
    'ncl-metal': ['tip.caseNclMetTitle', 'tip.caseNclMetBody', 'NCL · metal', 'Noncollinear metal: smearing + noncolin=.true. Typical for spin spirals / noncollinear metals.'],
  };
  const row = tips[caseKey];
  if (!row) return;
  showChoiceTip(tipText(row[0], row[2]), tipText(row[1], row[3]), caseKey.startsWith('ncl') ? 'warning' : 'info');
}

function updateSourceAdvice() {
  /* Tips are ephemeral via showChoiceTip — nothing permanent in the form. */
}

function materialName() {
  return (materialNameInput?.value || '').trim();
}

function syncScfFileName() {
  const name = materialName();
  if (scfFileDisplay) {
    scfFileDisplay.textContent = name
      ? `inputs/${name}/${name}-scf.in`
      : 'ex. inputs/fe/fe-scf.in · inputs/NiO/NiO-scf.in';
  }
  const jobName = document.querySelector('#job-name');
  if (jobName && name && (!jobName.value || jobName.dataset.fromMaterial === '1')) {
    jobName.value = name;
    jobName.dataset.fromMaterial = '1';
  }
}

function clearCalculationTraces() {
  state.sourceInfo = null;
  state.sourceDirty = true;
  state.selectedElements = [];
  state.groups = {};
  renderElementSelection();
  renderSiteGroups();
  updateRuntimeEstimate();
  updateMagnetismGuard();

  const jobName = document.querySelector('#job-name');
  jobName.value = '';
  delete jobName.dataset.fromMaterial;
  document.querySelector('#magnetic-select').value = 'auto';
  document.querySelector('#kind-select').value = 'auto';
  document.querySelector('#afm-select').value = '';
  document.querySelector('#ecutwfc').value = '';
  document.querySelector('#ecutrho').value = '';
  document.querySelector('#kmesh').value = '';
  document.querySelector('#nq').value = '2 2 2';
  document.querySelector('#start-mag').value = '0.5';
  document.querySelector('#smearing').value = '';
  document.querySelector('#degauss').value = '';
  document.querySelector('#np').value = '4';

  document.querySelector('#formula-input').value = '';
  document.querySelector('#prototype-input').value = '';
  document.querySelector('#a-input').value = '';
  document.querySelector('#c-input').value = '';
  document.querySelector('#ca-input').value = '';
  document.querySelector('#ase-u-input').value = '';
  document.querySelector('#supercell-input').value = '';

  if (crystalFromScf) {
    crystalFromScf.classList.add('hidden');
    crystalFromScf.innerHTML = '';
  }
  if (scfPreview) scfPreview.classList.add('hidden');
  if (scfPreviewContent) scfPreviewContent.textContent = '';
  if (hpPreviewContent) hpPreviewContent.textContent = '';
  if (scfPreviewMeta) scfPreviewMeta.textContent = 'SCF and hp.in adapted to the material type.';
  const structureFile = document.querySelector('#structure-file');
  if (structureFile) structureFile.value = '';
  setMessage('');
}

async function loadMaterials() {
  try {
    const response = await fetch('/api/materials');
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Material list unavailable.');
    const materials = data.materials || [];
    materialDatalist.innerHTML = materials.map((item) =>
      `<option value="${escapeHtml(item.name)}" label="${escapeHtml(item.relpath || `inputs/${item.name}/${item.name}-scf.in`)}"></option>`
    ).join('');
    materialNameInput.value = '';
    syncScfFileName();
  } catch (error) {
    materialDatalist.innerHTML = '';
    setMessage(error.message, 'error');
  }
}

function applyParamsFromScf(data) {
  const crystal = data.crystal || {};
  const from = data.from_scf || {};
  const aConv = crystal.a_conventional ?? crystal.alat_A ?? crystal.a;
  if (aConv != null) document.querySelector('#a-input').value = String(aConv);
  if (crystal.c != null && Math.abs(crystal.c - (crystal.a || aConv || 0)) > 1e-4) {
    document.querySelector('#c-input').value = String(crystal.c);
  }
  if (from.ecutwfc != null) document.querySelector('#ecutwfc').value = String(from.ecutwfc);
  if (from.ecutrho != null) document.querySelector('#ecutrho').value = String(from.ecutrho);
  if (from.kmesh) document.querySelector('#kmesh').value = from.kmesh.join(' ');
  if (from.smearing) document.querySelector('#smearing').value = from.smearing;
  if (from.degauss != null) document.querySelector('#degauss').value = String(from.degauss);
  if (from.kind_hint) document.querySelector('#kind-select').value = from.kind_hint;
  if (from.magnetic_hint) document.querySelector('#magnetic-select').value = from.magnetic_hint;
  const name = (data.material_name || materialName() || '').trim();
  const jobName = document.querySelector('#job-name');
  if (name) {
    jobName.value = name;
    jobName.dataset.fromMaterial = '1';
    materialNameInput.value = name;
    syncScfFileName();
  }

  if (crystalFromScf) {
    const scfPath = data.scf_path || (name
      ? `inputs/${name}/${name}-scf.in`
      : (data.scf_file || 'scf.in'));
    const bits = [
      `<strong>${escapeHtml(scfPath)}</strong>`,
      `ibrav=${data.ibrav ?? '?'}`,
      `a=${crystal.a_conventional ?? crystal.a ?? '?'} Å`,
    ];
    if (crystal.b != null) bits.push(`b=${crystal.b} Å`);
    if (crystal.c != null) bits.push(`c=${crystal.c} Å`);
    if (from.kmesh) bits.push(`k=${from.kmesh.join('×')}`);
    if (from.ecutwfc != null) bits.push(`ecutwfc=${from.ecutwfc}`);
    crystalFromScf.innerHTML = `Crystal parameters read from ${bits.join(' · ')}`;
    crystalFromScf.classList.remove('hidden');
  }
}

function recommendedKindParams(kind) {
  if (kind === 'metal') {
    return {
      kind: 'metal',
      smearing: 'mv',
      degauss: 0.02,
      kmesh: [8, 8, 8],
      nq: [2, 2, 2],
    };
  }
  // insulator + semiconductor : même chemin « à gap » pour hp.x
  return {
    kind: kind === 'semiconductor' ? 'semiconductor' : 'insulator',
    smearing: 'gauss',
    degauss: 0.001,
    kmesh: [6, 6, 6],
    nq: [2, 2, 2],
  };
}

function applyKindRecommendations() {
  const kind = document.querySelector('#kind-select').value;
  if (kind === 'auto') return;
  const rec = recommendedKindParams(kind);
  document.querySelector('#smearing').value = rec.smearing;
  document.querySelector('#degauss').value = String(rec.degauss);
  document.querySelector('#kmesh').value = rec.kmesh.join(' ');
  document.querySelector('#nq').value = rec.nq.join(' ');
}

function schedulePreviewRefresh() {
  if (!state.sourceInfo || state.sourceDirty) return;
  if (state.previewTimer) window.clearTimeout(state.previewTimer);
  state.previewTimer = window.setTimeout(() => {
    state.previewTimer = null;
    previewScfInput().catch(() => {});
  }, 400);
}

function groupsForSymbol(symbol) {
  const sites = state.sourceInfo?.correlated?.[symbol] || [];
  const current = state.groups[symbol];
  if (!current || !current.length) {
    state.groups[symbol] = buildDefaultGroups(sites);
    return state.groups[symbol];
  }
  return current;
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (character) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  })[character]);
}

function setStatus(text) {
  statusLabel.textContent = text;
}

function t(key, vars) {
  return (typeof window.paramuT === 'function') ? window.paramuT(key, vars) : key;
}

function setTab(tabName) {
  const atHome = !tabName;
  document.body.classList.toggle('is-home', atHome);
  document.body.classList.toggle('has-workspace', !atHome);
  const pageAccueil = document.querySelector('#page-accueil');
  if (pageAccueil) {
    pageAccueil.setAttribute('aria-label', atHome ? t('brand.home') : (window.paramuLang === 'fr' ? 'Espace de travail' : 'Workspace'));
  }
  document.title = atHome
    ? t('doc.home')
    : ({
      calculations: t('doc.prep'),
      results: t('doc.monitor'),
      help: t('doc.help'),
    }[tabName] || 'parametre-U');
  tabs.forEach((tab) => tab.classList.toggle('is-active', tab.dataset.tab === tabName));
  Object.entries(panels).forEach(([key, panel]) => {
    panel.classList.toggle('is-active', key === tabName);
  });
}

function openDetailedMonitor() {
  setTab('results');
  // Ensure the results panel is visible (leave home / other tabs)
  requestAnimationFrame(() => {
    const panel = document.querySelector('#panel-results');
    const list = document.querySelector('#results-list');
    panel?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    list?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    list?.classList.add('is-flash');
    window.setTimeout(() => list?.classList.remove('is-flash'), 1200);
  });
}

function openCaseHelp(anchor = 'help-practical') {
  setTab('help');
  requestAnimationFrame(() => {
    const target = document.getElementById(anchor) || document.getElementById('help-practical');
    target?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    const section = document.getElementById('help-practical');
    section?.classList.add('is-flash');
    window.setTimeout(() => section?.classList.remove('is-flash'), 1400);
  });
}

async function loadCatalog() {
  try {
    const response = await fetch('/api/catalog');
    if (!response.ok) throw new Error('Catalogue unavailable');
    const data = await response.json();
    state.elements = data.elements || [];
    renderCatalogMini();
    renderFullCatalog(data);
    updateMagnetismGuard();
  } catch (error) {
    setStatus('Catalogue unavailable');
    console.error(error);
  }
}

function renderFullCatalog(data) {
  const rows = state.elements
    .filter((element) => element.correlated)
    .map((element) => {
      const indicative = Number.isFinite(element.U_typ) && element.U_typ > 0
        ? `${element.U_typ.toFixed(1)} eV`
        : 'Not set';
      const range = Number.isFinite(element.U_min) && Number.isFinite(element.U_max)
        ? `${element.U_min.toFixed(1)}–${element.U_max.toFixed(1)} eV`
        : 'Not sete';
      return `
        <tr>
          <td><strong>${escapeHtml(element.symbol)}</strong> · ${escapeHtml(element.name || '')}</td>
          <td>${escapeHtml(element.manifold || '—')}</td>
          <td>${escapeHtml(indicative)}</td>
          <td>${escapeHtml(range)}</td>
          <td>${escapeHtml(element.note || '—')}</td>
        </tr>
      `;
    })
    .join('');
  catalogFullBody.innerHTML = rows || '<tr><td colspan="5">Aucune entrée de U dans la base.</td></tr>';
  catalogDescription.textContent = data.hubbard_u_database?.limits
    || 'Indicative comparison values, not universal; determine U for the material with hp.x.';
  catalogReferences.innerHTML = (data.hubbard_u_database?.references || []).map((reference) => `
    <p><strong>${escapeHtml(reference.citation)}</strong> · ${escapeHtml(reference.role)} · DOI ${escapeHtml(reference.doi)}</p>
  `).join('');
}

function normaliseGroupInput(raw) {
  if (!raw) return [];
  return raw
    .split(',')
    .map((item) => Number(String(item).trim()))
    .filter((value) => Number.isInteger(value) && value > 0);
}

function readNumericList(value) {
  if (!value || typeof value !== 'string') return [];
  return value.split(/\s+/).map((item) => Number(item)).filter((num) => Number.isFinite(num));
}

function readSupercell(value) {
  const nums = readNumericList(value);
  if (!nums.length) return null;
  if (nums.length !== 3 || nums.some((n) => !Number.isInteger(n) || n < 1)) {
    throw new Error('La supercellule doit contenir exactement trois entiers positifs (ex. 2 1 1).');
  }
  return nums;
}

function renderCatalogMini() {
  const rows = state.elements
    .filter((element) => element.correlated)
    .slice(0, 12)
    .map((element) => {
      const u = Number.isFinite(element.U_typ) && element.U_typ > 0 ? element.U_typ : null;
      const range = Number.isFinite(element.U_min) && Number.isFinite(element.U_max)
        ? `${element.U_min.toFixed(1)}–${element.U_max.toFixed(1)} eV`
        : '—';
      return `
        <tr>
          <td>${escapeHtml(element.symbol)}</td>
          <td>${escapeHtml(element.manifold || '—')}</td>
          <td>${u === null ? '—' : `${u.toFixed(1)} eV`}</td>
          <td>${escapeHtml(range)}</td>
        </tr>
      `;
    })
    .join('');
  catalogMiniBody.innerHTML = rows || '<tr><td colspan="4">No correlated element.</td></tr>';
}

function setMessage(text, type = '') {
  jobMessage.textContent = text;
  jobMessage.className = `job-message ${type}`.trim();
}

function buildDefaultGroups(sites) {
  return [sites.map((site) => site.index)];
}

function renderElementSelection() {
  const elements = state.sourceInfo?.elements || [];
  if (!elements.length) {
    elementSelection.innerHTML = '<div class="empty-state">No validated structure yet.</div>';
    return;
  }

  state.selectedElements = [...elements];
  elementSelection.innerHTML = elements.map((symbol) => `
    <label class="element-chip">
      <input type="checkbox" data-symbol="${symbol}" checked>
      <span>${escapeHtml(symbol)}</span>
    </label>
  `).join('');

  elementSelection.querySelectorAll('input[type="checkbox"]').forEach((checkbox) => {
    checkbox.addEventListener('change', () => {
      const symbol = checkbox.dataset.symbol;
      if (checkbox.checked) {
        if (!state.selectedElements.includes(symbol)) state.selectedElements.push(symbol);
        const sites = state.sourceInfo?.correlated?.[symbol] || [];
        state.groups[symbol] = buildDefaultGroups(sites);
      } else {
        state.selectedElements = state.selectedElements.filter((entry) => entry !== symbol);
        delete state.groups[symbol];
      }
      renderSiteGroups();
      schedulePreviewRefresh();
      updateMagnetismGuard();
    });
  });

  renderSiteGroups();
  updateMagnetismGuard();
}

function renderSiteGroups() {
  const source = state.sourceInfo;
  if (!source) {
    siteGroups.innerHTML = '<div class="empty-state">Validate a structure to define site groups.</div>';
    return;
  }

  const selected = state.selectedElements;
  const markup = selected
    .map((symbol) => {
      const sites = source.correlated[symbol] || [];
      const groups = groupsForSymbol(symbol);

      const content = groups.map((group, groupIndex) => {
        const values = Array.isArray(group) ? group.join(', ') : '';
        return `
          <div class="group-inputs">
            <div class="site-group-header">
              <strong>Group ${groupIndex + 1}</strong>
              <div class="site-group-actions">
                <button class="small-button" type="button" data-action="add-group" data-symbol="${symbol}">Ajouter</button>
                <button class="small-button" type="button" data-action="remove-group" data-symbol="${symbol}" data-index="${groupIndex}">Remove</button>
              </div>
            </div>
            <input class="group-input" type="text" value="${escapeHtml(values)}" data-symbol="${symbol}" data-group-index="${groupIndex}" placeholder="1, 2, 3">
          </div>
        `;
      }).join('');

      return `
        <div class="site-group-card">
          <div class="site-group-header">
            <strong>${escapeHtml(symbol)}</strong>
            <span>${sites.length} sites</span>
          </div>
          ${content}
        </div>
      `;
    })
    .join('');

  siteGroups.innerHTML = markup || '<div class="empty-state">No element selected.</div>';

  siteGroups.querySelectorAll('.group-input').forEach((input) => {
    input.addEventListener('input', () => {
      const symbol = input.dataset.symbol;
      const groupIndex = Number(input.dataset.groupIndex);
      const current = state.groups[symbol] || [];
      current[groupIndex] = normaliseGroupInput(input.value);
      state.groups[symbol] = current;
      schedulePreviewRefresh();
    });
  });

  siteGroups.querySelectorAll('[data-action="add-group"]').forEach((button) => {
    button.addEventListener('click', () => {
      const symbol = button.dataset.symbol;
      const current = groupsForSymbol(symbol);
      current.push([]);
      state.groups[symbol] = current;
      renderSiteGroups();
    });
  });

  siteGroups.querySelectorAll('[data-action="remove-group"]').forEach((button) => {
    button.addEventListener('click', () => {
      const symbol = button.dataset.symbol;
      const idx = Number(button.dataset.index);
      const current = state.groups[symbol] || [];
      if (current.length <= 1) return;
      current.splice(idx, 1);
      state.groups[symbol] = current;
      renderSiteGroups();
    });
  });
}

function getSourcePayload() {
  const mode = document.querySelector('input[name="source-mode"]:checked').value;
  if (mode === 'scf') {
    return {
      mode: 'scf',
      name: materialName(),
      supercell: readSupercell(document.querySelector('#scf-supercell-input').value),
    };
  }
  if (mode === 'formula') {
    return {
      mode: 'formula',
      formula: document.querySelector('#formula-input').value.trim(),
      prototype: document.querySelector('#prototype-input').value.trim() || 'rocksalt',
      a: document.querySelector('#a-input').value !== '' ? Number(document.querySelector('#a-input').value) : null,
      c: document.querySelector('#c-input').value !== '' ? Number(document.querySelector('#c-input').value) : null,
      ca: document.querySelector('#ca-input').value !== '' ? Number(document.querySelector('#ca-input').value) : null,
      ase_u: document.querySelector('#ase-u-input').value !== '' ? Number(document.querySelector('#ase-u-input').value) : null,
      supercell: readSupercell(document.querySelector('#supercell-input').value),
    };
  }

  const file = document.querySelector('#structure-file')?.files?.[0];
  return {
    mode: 'file',
    filename: file?.name || 'structure.cif',
    content: null,
    supercell: readSupercell(document.querySelector('#file-supercell-input')?.value || ''),
  };
}

function optionalNumber(selector) {
  const raw = document.querySelector(selector).value;
  if (raw === '' || raw == null) return null;
  const value = Number(raw);
  return Number.isFinite(value) ? value : null;
}

function optionalText(selector) {
  const raw = document.querySelector(selector).value.trim();
  return raw || null;
}

function getSelectedGroups() {
  const selected = {};
  for (const symbol of state.selectedElements) {
    const groups = state.groups[symbol] || [];
    if (!groups.length) {
      const sites = state.sourceInfo?.correlated?.[symbol] || [];
      selected[symbol] = [sites.map((site) => site.index)];
    } else {
      selected[symbol] = groups.filter((group) => Array.isArray(group) && group.length).map((group) => [...group]);
    }
  }
  return selected;
}

function getCalculationParams() {
  const kmeshRaw = document.querySelector('#kmesh').value.trim();
  const nqRaw = document.querySelector('#nq').value.trim();
  const kmesh = readNumericList(kmeshRaw);
  const nq = readNumericList(nqRaw);
  if (kmeshRaw && kmesh.length !== 3) {
    throw new Error('kmesh must contain exactly three integers (e.g. 6 6 6).');
  }
  if (nqRaw && nq.length !== 3) {
    throw new Error('nq must contain exactly three integers (e.g. 2 2 2).');
  }
  const magnetic = document.querySelector('#magnetic-select').value;
  return {
    magnetic,
    noncolin: magnetic === 'noncolin',
    lspinorb: !!document.querySelector('#lspinorb')?.checked,
    kind: document.querySelector('#kind-select').value,
    ecutwfc: optionalNumber('#ecutwfc'),
    ecutrho: optionalNumber('#ecutrho'),
    kmesh: kmesh.length === 3 ? kmesh : null,
    nq: nq.length === 3 ? nq : [2, 2, 2],
    np: optionalNumber('#np') ?? 4,
    start_mag: optionalNumber('#start-mag') ?? 0.5,
    smearing: optionalText('#smearing'),
    degauss: optionalNumber('#degauss'),
    afm: document.querySelector('#afm-select').value ? [document.querySelector('#afm-select').value] : [],
  };
}

function currentSupercellTuple() {
  const mode = currentSourceMode();
  const selector = mode === 'file'
    ? '#file-supercell-input'
    : (mode === 'scf' ? '#scf-supercell-input' : '#supercell-input');
  const raw = document.querySelector(selector)?.value?.trim() || '';
  if (!raw) return [1, 1, 1];
  try {
    const vals = readSupercell(raw);
    return vals && vals.length === 3 ? vals : [1, 1, 1];
  } catch (_) {
    return [1, 1, 1];
  }
}

function likelyMagneticSymbols() {
  const selected = state.selectedElements?.length
    ? state.selectedElements
    : Object.keys(state.sourceInfo?.correlated || {});
  return selected.filter((symbol) => {
    const el = state.elements.find((item) => item.symbol === symbol);
    return el ? !!el.magnetic_default : true;
  });
}

function currentPhysicalCase() {
  const magMode = document.querySelector('#magnetic-select')?.value || 'auto';
  const afm = document.querySelector('#afm-select')?.value || '';
  const kindRaw = document.querySelector('#kind-select')?.value || 'auto';
  let order = 'auto';
  if (magMode === 'noncolin') order = 'ncl';
  else if (magMode === 'off') order = 'nm';
  else if (afm) order = 'afm';
  else if (magMode === 'on') order = 'fm';
  else order = 'auto';
  const elec = kindRaw;
  const key = (order !== 'auto' && elec !== 'auto') ? `${order}-${elec}` : null;
  const nspin = magMode === 'noncolin' ? 4
    : (magMode === 'off' ? 1 : 2);
  return {
    order, elec, key,
    magnetic: magMode !== 'off',
    noncolin: magMode === 'noncolin',
    gapped: elec === 'semiconductor' || elec === 'insulator',
    metal: elec === 'metal',
    nspin,
    scf2: magMode !== 'off' && magMode !== 'noncolin' && elec !== 'metal',
  };
}

function magnetismIssues() {
  const magMode = document.querySelector('#magnetic-select')?.value || 'auto';
  const afm = document.querySelector('#afm-select')?.value || '';
  const kind = document.querySelector('#kind-select')?.value || 'auto';
  const sc = currentSupercellTuple();
  const unitCell = sc.every((v) => Number(v) === 1);
  const magElems = likelyMagneticSymbols();
  const issues = [];
  if (magMode === 'off' && magElems.length) {
    issues.push({
      level: 'danger',
      code: 'nm',
      text: t('mag.warnNm', { elems: magElems.join(', ') }),
    });
  }
  if (afm && unitCell) {
    issues.push({
      level: 'danger',
      code: 'afm-cell',
      text: t('mag.warnAfmCell', { sc: sc.join('×') }),
    });
  } else if (magMode !== 'off' && magMode !== 'noncolin' && !afm
      && magElems.length && unitCell && kind !== 'metal') {
    issues.push({
      level: 'warn',
      code: 'afm-suggest',
      text: t('mag.warnAfmSuggest', { elems: magElems.join(', ') }),
    });
  }
  return issues;
}

function syncLspinorbVisibility() {
  const wrap = document.querySelector('#lspinorb-wrap');
  const magMode = document.querySelector('#magnetic-select')?.value || 'auto';
  if (wrap) wrap.classList.toggle('is-disabled', magMode !== 'noncolin');
  if (magMode !== 'noncolin') {
    const box = document.querySelector('#lspinorb');
    if (box) box.checked = false;
  }
}

function updateCaseSummary() {
  const el = document.querySelector('#case-summary');
  if (!el) return;
  const c = currentPhysicalCase();
  syncLspinorbVisibility();
  const orderLabel = c.order === 'afm' ? 'AFM'
    : (c.order === 'fm' ? 'FM'
      : (c.order === 'nm' ? 'NM'
        : (c.order === 'ncl' ? 'NCL' : 'auto')));
  const elecLabel = c.elec === 'auto' ? 'auto' : c.elec;
  const path = c.order === 'ncl'
    ? t('case.pathNcl')
    : (c.elec === 'metal'
      ? t('case.pathMetal')
      : (c.order === 'nm'
        ? t('case.pathNmGap')
        : t('case.pathMagGap')));
  el.innerHTML = `
    <strong data-i18n-keep>${escapeHtml(t('case.current'))}</strong>
    <span class="case-pill">${escapeHtml(orderLabel)} · ${escapeHtml(elecLabel)}</span>
    <span class="case-pill">nspin=${c.nspin}</span>
    <span class="case-meta">${escapeHtml(path)}</span>`;
  document.querySelectorAll('[data-case]').forEach((btn) => {
    btn.classList.toggle('is-active', !!c.key && btn.dataset.case === c.key);
  });
}

function updateMagnetismGuard() {
  const box = document.querySelector('#magnetism-guard');
  updateCaseSummary();
  if (!box) return;
  const issues = magnetismIssues();
  const magMode = document.querySelector('#magnetic-select')?.value || 'auto';

  if (!state.sourceInfo || state.sourceDirty) {
    if (!issues.length) {
      box.classList.add('hidden');
      box.innerHTML = '';
      return;
    }
  }
  if (!issues.length) {
    if (magMode === 'off') {
      box.classList.add('hidden');
      box.innerHTML = '';
      return;
    }
    box.className = 'magnetism-guard is-ok';
    box.innerHTML = `<p>${escapeHtml(t('mag.guardOk'))}</p>`;
    return;
  }
  const worst = issues.some((i) => i.level === 'danger') ? 'danger' : 'warn';
  box.className = `magnetism-guard is-${worst}`;
  box.innerHTML = `<ul>${issues.map((i) => `<li>${escapeHtml(i.text)}</li>`).join('')}</ul>`;
}

function ensureAfmSupercellHint() {
  const sc = currentSupercellTuple();
  if (!sc.every((v) => Number(v) === 1)) return;
  const mode = currentSourceMode();
  const selector = mode === 'file'
    ? '#file-supercell-input'
    : (mode === 'scf' ? '#scf-supercell-input' : '#supercell-input');
  const input = document.querySelector(selector);
  if (input && !input.value.trim()) input.value = '2 1 1';
}

function applyCasePreset(caseKey) {
  const mag = document.querySelector('#magnetic-select');
  const afm = document.querySelector('#afm-select');
  const kind = document.querySelector('#kind-select');
  const startMag = document.querySelector('#start-mag');
  if (!mag || !afm || !kind || !caseKey) return;
  const [order, elec] = caseKey.split('-');
  if (!order || !elec) return;

  if (order === 'nm') {
    mag.value = 'off';
    afm.value = '';
  } else if (order === 'fm') {
    mag.value = 'on';
    afm.value = '';
    if (startMag) startMag.value = startMag.value || '0.5';
  } else if (order === 'afm') {
    mag.value = 'on';
    afm.value = 'z';
    if (startMag) startMag.value = startMag.value || '0.5';
    ensureAfmSupercellHint();
  } else if (order === 'ncl') {
    mag.value = 'noncolin';
    afm.value = '';
    if (startMag) startMag.value = startMag.value || '0.5';
  }

  kind.value = elec;
  applyKindRecommendations();
  state.sourceDirty = true;
  updateMagnetismGuard();
  updateRuntimeEstimate();
  schedulePreviewRefresh();
  flashCaseTip(caseKey);
}

function confirmMagnetismBeforeLaunch() {
  const issues = magnetismIssues();
  const nm = issues.find((i) => i.code === 'nm');
  if (nm && !window.confirm(t('mag.confirmNm'))) return false;
  const afmCell = issues.find((i) => i.code === 'afm-cell');
  if (afmCell && !window.confirm(t('mag.confirmAfmCell'))) return false;
  return true;
}

function formatEstimateDuration(minutes) {
  const n = Math.max(1, Math.round(minutes));
  if (n < 60) return t('estimate.minutes', { n });
  return t('estimate.hours', { h: (n / 60).toFixed(1) });
}

function updateRuntimeEstimate() {
  const el = document.querySelector('#runtime-estimate');
  const title = document.querySelector('#launch-bar-title');
  if (!el) return;
  if (!state.sourceInfo || state.sourceDirty) {
    el.textContent = t('estimate.needValidate');
    if (title) title.textContent = t('launch.title');
    return;
  }
  const nat = Math.max(1, Number(state.sourceInfo.nat) || 1);
  const np = Math.max(1, optionalNumber('#np') || 4);
  const kind = document.querySelector('#kind-select')?.value || 'auto';
  const magMode = document.querySelector('#magnetic-select')?.value || 'auto';
  const formula = state.sourceInfo.formula || '—';
  const elems = (state.selectedElements || []).join(', ') || '—';
  // Heuristique locale indicative (pas un benchmark) : coût ~ nat^2.1 / np × étapes pipeline
  const scfUnits = (nat ** 2.1) / np;
  const stages = kind === 'metal' ? 3.5 : 5;
  const nclFactor = magMode === 'noncolin' ? 3.5 : 1;
  const minutes = Math.max(8, scfUnits * stages * 0.28 * nclFactor);
  el.textContent = t('estimate.ready', {
    formula,
    nat,
    elems,
    np,
    time: formatEstimateDuration(minutes),
  });
  if (title) title.textContent = t('launch.readyTitle', { formula });
}

async function previewScfInput({ silent = false } = {}) {
  if (!state.sourceInfo || state.sourceDirty) {
    if (!silent) setMessage('Validate the structure and material type first.', 'error');
    throw new Error('Validate the structure and material type first.');
  }
  const button = document.querySelector('#preview-scf');
  button.disabled = true;
  button.textContent = 'Generating…';
  try {
    const response = await fetch('/api/preview-scf', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        token: state.sourceInfo.token,
        elements: state.selectedElements,
        site_groups: getSelectedGroups(),
        params: getCalculationParams(),
      }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Could not generate inputs.');
    scfPreviewContent.textContent = data.input;
    hpPreviewContent.textContent = data.hp_input || '';
    const nqNote = data.nq_adjusted
      ? ` · nq adjusted → ${Array.isArray(data.nq) ? data.nq.join('×') : data.nq}`
      : '';
    scfPreviewMeta.textContent =
      `${data.formula} · ${data.nat} atomes · ${data.kind}`
      + ` · scf1.in / hp.in preview${nqNote} (written at launch)`;
    scfPreview.classList.remove('hidden');
    if (!silent) {
      setMessage('scf1.in / hp.in preview ready — real files will be written at launch.', 'success');
    }
  } catch (error) {
    if (!silent) setMessage(error.message, 'error');
    throw error;
  } finally {
    button.disabled = false;
    button.textContent = t('btn.preview');
  }
}

async function validateSource() {
  if (state.validateInFlight) return false;
  const button = document.querySelector('#validate-structure');
  const payload = getSourcePayload();

  if (payload.mode === 'scf' && !payload.name) {
    setMessage('Enter the material name (<name>-scf.in file).', 'error');
    return false;
  }

  if (payload.mode === 'file') {
    const file = document.querySelector('#structure-file')?.files?.[0];
    if (!file) {
      setMessage('Choose a structure file before validation.', 'error');
      return false;
    }
    const bytes = new Uint8Array(await file.arrayBuffer());
    let binary = '';
    for (let offset = 0; offset < bytes.length; offset += 0x8000) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
    }
    payload.content = btoa(binary);
    payload.filename = file.name;
  }

  state.validateInFlight = true;
  if (button) {
    button.disabled = true;
    button.textContent = 'Validating…';
  }
  const requestToken = Symbol('validate');
  state._validateToken = requestToken;
  let ok = false;
  try {
    const response = await fetch('/api/inspect', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await response.json();
    if (state._validateToken !== requestToken) return false;
    if (!response.ok) {
      throw new Error(data.error || 'Validation impossible.');
    }

    state.sourceInfo = data;
    state.sourceDirty = false;
    state.groups = {};
    Object.keys(data.correlated || {}).forEach((symbol) => {
      const indexes = (data.correlated[symbol] || []).map((site) => site.index);
      state.groups[symbol] = [indexes];
    });
    state.selectedElements = Object.keys(data.correlated || {});
    renderElementSelection();
    let okMsg = '';
    if (data.from_scf) {
      applyParamsFromScf(data);
      okMsg = `Material validated from ${data.scf_file}: ${data.formula} (${data.nat} atoms) — crystal parameters imported.`;
    } else {
      if (crystalFromScf) crystalFromScf.classList.add('hidden');
      if (data.formula) document.querySelector('#job-name').value = data.formula;
      if (!document.querySelector('#kmesh').value.trim()) applyKindRecommendations();
      okMsg = `Structure validated : ${data.formula} (${data.nat} atomes)`;
    }
    updateRuntimeEstimate();
    updateMagnetismGuard();
    try {
      await previewScfInput({ silent: true });
      setMessage(`${okMsg} scf1.in / hp.in preview ready.`, 'success');
    } catch (previewError) {
      setMessage(`${okMsg} Preview: ${previewError.message}`, 'error');
    }
    ok = true;
  } catch (error) {
    if (state._validateToken === requestToken) setMessage(error.message, 'error');
    updateRuntimeEstimate();
    updateMagnetismGuard();
  } finally {
    state.validateInFlight = false;
    if (button) {
      button.disabled = false;
      button.textContent = t('btn.validate');
    }
  }
  return ok;
}

function parallelMode() {
  return document.querySelector('input[name="parallel-mode"]:checked')?.value || 'solo';
}

function syncParallelPrepControls({ adjustNp = false } = {}) {
  const mode = parallelMode();
  const slotsWrap = document.querySelector('#parallel-slots-wrap');
  const slotsInput = document.querySelector('#parallel-slots');
  const isParallel = mode === 'parallel';
  if (slotsWrap) slotsWrap.classList.toggle('is-disabled', !isParallel);
  if (slotsInput) slotsInput.disabled = !isParallel;
  if (adjustNp && state.parallel) {
    applyParallelNpSuggestion(state.parallel);
  }
}

function applyParallelNpSuggestion(cap) {
  const npInput = document.querySelector('#np');
  const slotsInput = document.querySelector('#parallel-slots');
  const machineInfo = document.querySelector('#machine-parallel-info');
  if (!cap) return;
  if (machineInfo) {
    const override = cap.env_overridden || {};
    const note = (override.jobs || override.mpi) ? ' (env override)' : ' (auto from host)';
    machineInfo.textContent = `Host ${cap.hostname || 'local'} · ${cap.cpu_count} CPU cores · MPI cap ${cap.max_mpi} · max jobs ${cap.max_jobs}${note}`;
  }
  if (!npInput) return;
  const mode = parallelMode();
  if (mode === 'solo') {
    const solo = Math.max(1, Number(cap.suggested_np_solo ?? cap.max_mpi) || 4);
    npInput.value = String(solo);
    return;
  }
  if (slotsInput && !slotsInput.dataset.userSet) {
    const suggestedSlots = Math.max(2, Number(cap.suggested_slots) || 2);
    slotsInput.value = String(Math.min(8, suggestedSlots));
  }
  const slots = Math.max(2, Math.min(8, Number(slotsInput?.value) || 2));
  const suggested = Math.max(
    1,
    Number(cap.suggested_np_parallel)
      || Math.floor(Math.max(1, Number(cap.mpi_free > 0 ? cap.mpi_free : cap.max_mpi) || 4) / slots),
  );
  npInput.value = String(suggested);
}

async function refreshParallelCapacity({ adjustNp = false } = {}) {
  const hint = document.querySelector('#parallel-hint');
  syncParallelPrepControls();
  try {
    const response = await fetch('/api/parallel');
    if (!response.ok) throw new Error('parallel unavailable');
    const data = await response.json();
    state.parallel = data;
    if (adjustNp) applyParallelNpSuggestion(data);
    syncParallelPrepControls();
    if (!hint) return data;
    const mode = parallelMode();
    const freeJobs = data.jobs_free ?? 0;
    const freeMpi = data.mpi_free ?? 0;
    const npWanted = optionalNumber('#np') ?? 4;
    const slots = Math.max(2, Number(document.querySelector('#parallel-slots')?.value) || 2);
    hint.classList.remove('is-tight', 'is-full');
    if (mode === 'solo') {
      hint.textContent = `Preparation · single job: np=${npWanted}. Host ${data.hostname || ''} · ${data.cpu_count || data.max_mpi} CPU · ${data.max_mpi} MPI ranks · ${data.n_active} active.`;
      if (data.n_active > 0 && npWanted > freeMpi) {
        hint.classList.add('is-tight');
        hint.textContent = `Preparation · single job, but ${data.n_active} job(s) already use ${data.used_mpi} ranks on ${data.hostname || 'this host'}. Lower np ≤ ${Math.max(1, freeMpi)} or wait.`;
      }
      return data;
    }
    if (freeJobs <= 0 || freeMpi <= 0) {
      hint.classList.add('is-full');
      hint.textContent = `Preparation · parallel saturated on ${data.hostname || 'host'}: ${data.n_active}/${data.max_jobs} jobs · ${data.used_mpi}/${data.max_mpi} MPI. Wait before another supercell.`;
    } else if (npWanted > freeMpi) {
      hint.classList.add('is-tight');
      hint.textContent = `Preparation · parallel (${slots} planned): np=${npWanted} > ${freeMpi} free ranks on ${data.hostname || 'host'}. Lower np or concurrent jobs.`;
    } else {
      hint.textContent = `Preparation · parallel (${slots} supercells) on ${data.hostname || 'host'}: np=${npWanted} · ${data.n_active}/${data.max_jobs} active · ${freeMpi} free ranks · you can launch another job.`;
    }
    return data;
  } catch (error) {
    if (hint) {
      hint.classList.remove('is-tight', 'is-full');
      hint.textContent = 'Choose the parallel mode in Preparation (single calculation or several supercells). Settings follow this machine.';
    }
    return null;
  }
}

async function launchCalculation() {
  if (state.launchInFlight) return;
  const button = document.querySelector('#run-calculation');
  state.launchInFlight = true;
  if (button) {
    button.disabled = true;
    button.textContent = '…';
  }
  try {
    if (!state.sourceInfo?.token || state.sourceDirty) {
      setMessage('Validating material before launch…');
      const validated = await validateSource();
      if (!validated || !state.sourceInfo?.token || state.sourceDirty) return;
    }

    const selected = state.selectedElements.filter((symbol) => !!state.sourceInfo.correlated[symbol]);
    if (!selected.length) {
      setMessage('Select at least one correlated element.', 'error');
      const adv = document.querySelector('#advanced-structure');
      if (adv) adv.open = true;
      return;
    }

    updateMagnetismGuard();
    if (!confirmMagnetismBeforeLaunch()) {
      setMessage(t('mag.launchCancelled'), 'error');
      return;
    }

    const params = getCalculationParams();
    const material = state.sourceInfo.material_name || materialName() || state.sourceInfo.formula || 'calcul_u';

    const body = {
      token: state.sourceInfo.token,
      elements: selected,
      site_groups: getSelectedGroups(),
      params,
      name: document.querySelector('#job-name').value.trim() || material,
    };

    const response = await fetch('/api/jobs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'The job could not be started.');
    }
    const parallel = data.parallel || state.parallel;
    const parallelNote = parallel
      ? ` · parallel ${parallel.n_active}/${parallel.max_jobs} jobs, ${parallel.used_mpi}/${parallel.max_mpi} MPI`
      : '';
    setMessage(`${t('msg.jobStarted')} ${data.id}${parallelNote}`, 'success');
    setTab('results');
    refreshParallelCapacity({ adjustNp: false });
    fetchResults();
  } catch (error) {
    setMessage(error.message, 'error');
    refreshParallelCapacity({ adjustNp: false });
  } finally {
    state.launchInFlight = false;
    if (button) {
      button.disabled = false;
      button.textContent = t('btn.run');
    }
  }
}

function displayNumber(value, digits = 3, unit = '') {
  if (value === null || value === undefined || value === '') return '—';
  const number = Number(value);
  return Number.isFinite(number) ? `${number.toFixed(digits)}${unit}` : escapeHtml(value);
}

function formatSci(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return '—';
  return number.toExponential(2);
}

function scfAdvancement(info) {
  if (!info) return { pct: null, iteration: null, maxIterations: null };
  const iteration = info.iteration != null ? Number(info.iteration) : null;
  const maxIterations = info.max_iterations != null ? Number(info.max_iterations) : 100;
  // progress_pct est calculé côté API ; repli minimal si absent
  let pct = info.progress_pct != null ? Number(info.progress_pct) : null;
  if (pct == null && (info.converged === true || info.job_done)) pct = 100;
  if (pct == null && iteration != null && maxIterations) {
    pct = Math.max(0, Math.min(99, Math.round((100 * iteration) / maxIterations)));
  }
  return { pct, iteration, maxIterations };
}

function renderStepProgress(stepKey, progress) {
  const info = progress?.[stepKey];
  if (!info || (!info.available && info.step_status !== 'running')) return '';

  if (info.kind === 'hp') {
    const pct = info.progress_pct != null
      ? info.progress_pct
      : ((info.q_total && info.q_done)
        ? Math.min(100, Math.round((100 * info.q_done) / info.q_total))
        : (info.job_done ? 100 : null));
    return `
      <div class="conv-track ${info.job_done ? 'is-done' : 'is-running'}">
        <div class="conv-track-head">
          <strong>Suivi hp.x</strong>
          <span>${escapeHtml(info.message || 'running')}</span>
        </div>
        ${pct !== null ? `
          <div class="conv-bar" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100">
            <span style="width:${pct}%"></span>
          </div>
          <small>${info.q_done || 0}${info.q_total ? ` / ${info.q_total} points q` : ' réponses'} · ${pct}%</small>
        ` : `<small>${escapeHtml(info.message || '')}</small>`}
      </div>`;
  }

  const adv = scfAdvancement(info);
  const converged = info.converged === true;
  const running = info.step_status === 'running' || info.converged === false;
  const thr = info.conv_thr;
  const acc = info.accuracy_ry;
  const ratio = adv.pct;
  const iterLabel = adv.iteration != null
    ? `${adv.iteration}${adv.maxIterations ? ` / ${adv.maxIterations}` : ''}`
    : '—';

  const tone = converged ? 'is-done' : (info.converged === false && info.step_status === 'failed' ? 'is-failed' : 'is-running');
  return `
    <div class="conv-track ${tone}">
      <div class="conv-track-head">
        <strong>Convergence SCF</strong>
        <span>${converged ? 'Reached' : escapeHtml(info.message || 'running')}</span>
      </div>
      <div class="conv-metrics">
        <div><span class="label">Iterations</span><strong>${escapeHtml(iterLabel)}</strong></div>
        <div><span class="label">Progress</span><strong>${ratio != null ? `${ratio}%` : '—'}</strong></div>
        <div><span class="label">Energy</span><strong>${info.energy_ry != null ? `${Number(info.energy_ry).toFixed(6)} Ry` : '—'}</strong></div>
        <div><span class="label">Δ residual</span><strong>${acc != null ? `${formatSci(acc)} Ry` : '—'}</strong></div>
        <div><span class="label">Threshold</span><strong>${thr != null ? `${formatSci(thr)} Ry` : '—'}</strong></div>
      </div>
      ${ratio !== null ? `
        <div class="conv-bar" role="progressbar" aria-valuenow="${ratio}" aria-valuemin="0" aria-valuemax="100"
             aria-label="Progress rate">
          <span style="width:${ratio}%"></span>
        </div>
        <small>${converged
          ? 'Convergence threshold reached'
          : `Progress ${ratio}% · ${adv.iteration != null ? `${adv.iteration} iteration${adv.iteration > 1 ? 's' : ''}` : 'starting'}`}
          ${running && !converged ? ' · live tracking' : ''}</small>
      ` : `<small>${escapeHtml(info.message || 'Waiting for the first SCF iterations')}</small>`}
    </div>`;
}

function activeStepKey(job) {
  const steps = job.steps || {};
  return PIPELINE_ORDER.find((key) => steps[key]?.status === 'running')
    || PIPELINE_ORDER.find((key) => ['interrupted', 'failed'].includes(steps[key]?.status))
    || PIPELINE_ORDER.filter((key) => steps[key]?.status === 'done').slice(-1)[0]
    || null;
}

function updateLiveMonitor(jobs) {
  const monitor = document.querySelector('#live-monitor');
  const body = document.querySelector('#live-monitor-body');
  const title = document.querySelector('#live-monitor-title');
  const statsEl = document.querySelector('#live-monitor-stats');
  const progressWrap = document.querySelector('#live-monitor-progress');
  const progressBar = progressWrap?.querySelector('.live-monitor-bar');
  const badge = document.querySelector('#suivi-live-badge');
  if (!monitor || !body) return;

  const running = (jobs || []).filter((job) => job.status === 'running');
  const interrupted = (jobs || []).filter((job) => job.status === 'interrupted');
  const watched = running.length ? running : interrupted.slice(0, 1);

  if (badge) {
    badge.classList.toggle('hidden', running.length === 0);
    badge.textContent = running.length ? `${running.length} live` : 'live';
  }

  if (!watched.length) {
    monitor.classList.add('hidden');
    if (statsEl) statsEl.textContent = '';
    if (progressWrap) {
      progressWrap.classList.add('hidden');
      progressWrap.setAttribute('aria-hidden', 'true');
    }
    if (statusLabel && statusLabel.dataset.live !== '0') {
      statusLabel.textContent = 'Ready';
      statusLabel.dataset.live = '0';
    }
    return;
  }

  monitor.classList.remove('hidden');

  body.innerHTML = watched.map((job) => {
    const stepKey = activeStepKey(job);
    const step = (job.steps || {})[stepKey] || {};
    const progress = (job.progress || {})[stepKey] || {};
    const adv = scfAdvancement(progress);
    const formula = job.structure?.formula || job.summary?.structure?.formula || '—';
    const bits = [];
    bits.push(`<span class="live-chip"><em>Step</em> ${escapeHtml(STEP_LABELS_SHORT[stepKey] || stepKey || '?')}</span>`);
    if (adv.iteration != null) {
      const maxPart = adv.maxIterations ? ` / ${adv.maxIterations}` : '';
      bits.push(`<span class="live-chip live-chip-accent"><em>Iterations</em> ${adv.iteration}${maxPart}</span>`);
    } else if (progress.q_done != null) {
      bits.push(`<span class="live-chip live-chip-accent"><em>q</em> ${progress.q_done}${progress.q_total ? `/${progress.q_total}` : ''}</span>`);
    }
    if (progress.energy_ry != null) {
      bits.push(`<span class="live-chip"><em>E</em> ${Number(progress.energy_ry).toFixed(6)} Ry</span>`);
    }
    if (progress.accuracy_ry != null) {
      bits.push(`<span class="live-chip"><em>Δ</em> ${formatSci(progress.accuracy_ry)} Ry</span>`);
    }
    if (progress.conv_thr != null) {
      bits.push(`<span class="live-chip"><em>threshold</em> ${formatSci(progress.conv_thr)} Ry</span>`);
    }
    const detail = progress.message || step.detail || job.detail || '';
    const tone = job.status === 'running' ? 'is-running' : 'is-interrupted';
    return `
      <article class="live-job ${tone}">
        <div class="live-job-title">
          <strong>${escapeHtml(job.id)}</strong>
          <span>${escapeHtml(formula)}</span>
          <span class="live-job-status">${job.status === 'running' ? 'Running' : 'Interrupted'}</span>
        </div>
        <div class="live-job-metrics">${bits.join('')}</div>
        ${detail ? `<p class="live-job-detail">${escapeHtml(detail)}</p>` : ''}
      </article>`;
  }).join('');

  const primary = watched[0];
  const pStep = activeStepKey(primary);
  const pInfo = (primary.progress || {})[pStep] || {};
  const pAdv = scfAdvancement(pInfo);
  const headerPct = pAdv.pct;
  const headerIter = pAdv.iteration;

  if (title) {
    title.textContent = running.length
      ? (running.length === 1 ? t('live.title') : t('live.titleMany', { n: running.length }))
      : t('live.interrupted');
  }
  if (statsEl) {
    const parts = [];
    if (headerPct != null) parts.push(`${headerPct}%`);
    if (headerIter != null) {
      parts.push(`${headerIter} iteration${headerIter > 1 ? 's' : ''}`);
    } else if (pInfo.q_done != null) {
      parts.push(`q ${pInfo.q_done}${pInfo.q_total ? `/${pInfo.q_total}` : ''}`);
    }
    statsEl.textContent = parts.length ? `· ${parts.join(' · ')}` : '';
  }
  if (progressWrap && progressBar) {
    if (headerPct != null) {
      progressWrap.classList.remove('hidden');
      progressWrap.setAttribute('aria-hidden', 'false');
      progressBar.setAttribute('aria-valuenow', String(headerPct));
      const fill = progressBar.querySelector('span');
      if (fill) fill.style.width = `${headerPct}%`;
    } else {
      progressWrap.classList.add('hidden');
      progressWrap.setAttribute('aria-hidden', 'true');
    }
  }

  if (statusLabel) {
    if (running.length > 1) {
      statusLabel.textContent = `${running.length} parallel calculations · ${primary.id.slice(0, 18)}…`;
    } else {
      const bits = [pStep || primary.status];
      if (headerPct != null) bits.push(`${headerPct}%`);
      if (headerIter != null) bits.push(`it. ${headerIter}`);
      statusLabel.textContent = `${primary.id.slice(0, 22)}… ${bits.join(' · ')}`;
    }
    statusLabel.dataset.live = '1';
  }

}

function renderResults(jobs) {
  state.latestJobs = jobs || [];
  updateLiveMonitor(jobs);
  // Capacité affichée dans Préparation ; pas de recalcul agressif ici
  if (document.body.classList.contains('has-workspace')
      && document.querySelector('.tab[data-tab="calculations"]')?.classList.contains('is-active')) {
    refreshParallelCapacity({ adjustNp: false });
  }

  if (!jobs.length) {
    resultsList.innerHTML = `<div class="empty-state">${escapeHtml(t('empty.results'))}</div>`;
    return;
  }

  resultsList.innerHTML = jobs.map((job) => {
    const summary = job.summary;
    const structure = job.structure || summary?.structure || {};
    const energies = summary?.energies_Ry || {};
    // Normalisation des étapes déjà faite côté API (normalize_pipeline_steps)
    const rawSteps = job.steps || {};
    const progress = job.progress || {};
    const pendingLabel = ['running', 'interrupted', 'done', 'degraded', 'failed'].includes(job.status)
      ? 'Waiting'
      : 'Not started';
    const stepMarkup = PIPELINE_ORDER.map((key) => {
      const step = rawSteps[key] || { status: 'not_started', detail: 'waiting' };
      if (key === 'scf2' && step.status === 'skipped') {
        return `
          <div class="step-row skipped">
            <span>${escapeHtml(STEP_LABELS[key])}</span>
            <strong>Skipped</strong>
            <small>not required (metal / non-magnetic)</small>
          </div>`;
      }
      const showProgress = ['scf1', 'scf2', 'scf_u', 'hp'].includes(key)
        && ['running', 'done', 'failed', 'interrupted', 'soft_failed'].includes(step.status);
      const stepStatusLabel = step.status === 'not_started'
        ? pendingLabel
        : (STATUS_LABELS[step.status] || step.status || 'Waiting');
      return `
      <div class="step-block">
        <div class="step-row ${escapeHtml(step.status || 'not_started')}">
          <span>${escapeHtml(STEP_LABELS[key] || key)}</span>
          <strong>${escapeHtml(stepStatusLabel)}</strong>
          <small>${escapeHtml(step.detail || (step.status === 'not_started' ? 'waiting' : ''))}</small>
        </div>
        ${showProgress ? renderStepProgress(key, progress) : ''}
      </div>`;
    }).join('');
    const uValues = summary?.U || [];
    const uHero = uValues.length ? `
      <div class="u-hero" aria-label="${escapeHtml(t('results.uHero'))}">
        <p class="u-hero-label">${escapeHtml(t('results.uHero'))}</p>
        <div class="u-hero-grid">
          ${uValues.map((value) => `
            <div class="u-hero-item">
              <span>${escapeHtml(value.label || value.element)}</span>
              <strong>${displayNumber(value.U_hp_x ?? value.U_utilise, 2, ' eV')}</strong>
            </div>`).join('')}
        </div>
      </div>` : '';
    const uRows = uValues.map((value) => {
      const reference = state.elements.find((element) => element.symbol === value.element);
      const range = reference && Number.isFinite(reference.U_min) && Number.isFinite(reference.U_max)
        ? `${reference.U_min.toFixed(1)}–${reference.U_max.toFixed(1)} eV`
        : 'not provided';
      const indicative = reference && Number.isFinite(reference.U_typ)
        ? `${reference.U_typ.toFixed(1)} eV (indicative)`
        : '—';
      return `
        <tr>
          <td>${escapeHtml(value.label || value.element)}</td>
          <td>${displayNumber(value.U_hp_x, 4, ' eV')}</td>
          <td>${displayNumber(value.U_utilise, 4, ' eV')}</td>
          <td>${escapeHtml(value.source || '—')}</td>
          <td>${escapeHtml(indicative)}<br><small>Range: ${escapeHtml(range)}</small></td>
        </tr>
      `;
    }).join('');
    const analysis = summary ? `
      ${uHero}
      <div class="result-summary">
        <div class="summary-box"><span class="label">DFT energy</span><strong>${displayNumber(energies.scf2 ?? energies.scf1, 6, ' Ry')}</strong></div>
        <div class="summary-box"><span class="label">DFT+U energy</span><strong>${displayNumber(energies.scf_u, 6, ' Ry')}</strong></div>
        <div class="summary-box"><span class="label">Difference per unit</span><strong>${displayNumber(energies.delta_par_unite_formelle_eV, 4, ' eV')}</strong></div>
        <div class="summary-box"><span class="label">DFT+U gap</span><strong>${displayNumber(summary.gap_eV?.scf_u, 3, ' eV')}</strong></div>
        <div class="summary-box"><span class="label">DFT+U magnetization</span><strong>${displayNumber(summary.magnetisation_bohr?.scf_u, 3, ' μB')}</strong></div>
      </div>
      <div class="mini-table-wrap result-table-wrap">
        <table class="result-table"><thead><tr><th>Site / channel</th><th>U hp.x</th><th>U applied</th><th>Source</th><th>Indicative reference</th></tr></thead>
          <tbody>${uRows || '<tr><td colspan="5">No U value available in the report.</td></tr>'}</tbody>
        </table>
      </div>
      ${summary.avertissements?.length ? `<p class="result-warning">${summary.avertissements.map(escapeHtml).join(' · ')}</p>` : ''}
    ` : `<p class="job-message">${escapeHtml(job.status === 'prepared'
      ? 'Input files are ready, but no QE calculation has been launched yet.'
      : job.status === 'not_started'
        ? 'No calculation has been launched for this folder.'
        : job.status === 'interrupted'
          ? 'The calculation was interrupted before final analysis. Check the indicated step log.'
          : job.status === 'failed'
            ? 'The calculation failed before the final report was produced.'
            : 'Scientific results will appear after analysis completes.')}</p>`;
    const artifactMarkup = (job.artifacts || []).length ? `
      <div class="job-artifacts" aria-label="Files du calcul">
        <strong>Files</strong>
        ${(job.artifacts || []).map((artifact) => `
          <a href="${escapeHtml(artifact.url)}" download>${escapeHtml(artifact.label)}</a>
        `).join('')}
      </div>
    ` : '';
    const resumeLabel = job.status === 'prepared' ? 'Run calculation' : 'Resume';
    const resumeMarkup = ['interrupted', 'failed', 'degraded', 'prepared'].includes(job.status)
      ? `<button class="primary-button" type="button" data-resume-job="${escapeHtml(job.id)}" data-resume-label="${escapeHtml(resumeLabel)}">${resumeLabel}</button>`
      : '';

    const calc = job.calc || {};
    const calcChips = (calc.nspin != null || calc.magnetic != null || calc.kind) ? `
      <div class="calc-setup" aria-label="${escapeHtml(t('results.calcSetup'))}">
        ${calc.nspin != null ? `<span class="calc-chip"><em>${escapeHtml(t('results.nspin'))}</em><strong>${escapeHtml(String(calc.nspin))}</strong></span>` : ''}
        ${calc.noncolin ? `<span class="calc-chip is-mag"><em>NCL</em><strong>noncolin</strong></span>` : ''}
        ${calc.lspinorb ? `<span class="calc-chip is-mag"><em>SOC</em><strong>lspinorb</strong></span>` : ''}
        ${calc.magnetic === true && !calc.noncolin ? `<span class="calc-chip is-mag"><em>${escapeHtml(t('results.magnetic'))}</em><strong>yes</strong></span>` : ''}
        ${calc.magnetic === false ? `<span class="calc-chip is-nm"><em>${escapeHtml(t('results.nonMagnetic'))}</em><strong>NM</strong></span>` : ''}
        ${calc.afm_axis ? `<span class="calc-chip is-mag"><em>${escapeHtml(t('results.afm'))}</em><strong>${escapeHtml(String(calc.afm_axis))}</strong></span>` : ''}
        ${calc.kind ? `<span class="calc-chip"><em>${escapeHtml(t('results.kind'))}</em><strong>${escapeHtml(String(calc.kind))}</strong></span>` : ''}
      </div>` : '';

    return `
      <article class="result-card">
        <div class="result-head">
          <div><h3>${escapeHtml(job.id)}</h3><span class="result-formula">${escapeHtml(structure.formula || 'Structure in preparation')}</span></div>
          <span class="status-pill ${escapeHtml(job.status || 'not_started')}">${escapeHtml(STATUS_LABELS[job.status] || 'Unknown status')}</span>
        </div>
        <div class="result-meta"><span>Updated: ${escapeHtml(job.updated || '—')}</span></div>
        ${calcChips}
        <div class="step-list">${stepMarkup}</div>
        ${analysis}
        ${artifactMarkup}
        <div class="card-actions">
          ${resumeMarkup}
          <button class="secondary-button" type="button" data-delete-job="${escapeHtml(job.id)}">Delete</button>
        </div>
      </article>
    `;
  }).join('');
}

let resultsPollTimer = null;

function scheduleResultsPolling(jobs) {
  const active = Array.isArray(jobs) && jobs.some((job) => job.status === 'running');
  const delay = active ? 2000 : 5000;
  if (resultsPollTimer) window.clearTimeout(resultsPollTimer);
  resultsPollTimer = window.setTimeout(() => {
    fetchResults();
  }, delay);
}

async function fetchResults() {
  const seq = ++state.resultsSeq;
  try {
    const response = await fetch('/api/results');
    if (!response.ok) throw new Error('Invalid server response');
    const jobs = await response.json();
    if (seq !== state.resultsSeq) return;
    const list = Array.isArray(jobs) ? jobs : [];
    renderResults(list);
    scheduleResultsPolling(list);
  } catch (error) {
    if (seq !== state.resultsSeq) return;
    console.error(error);
    updateLiveMonitor([]);
    resultsList.innerHTML = '<div class="empty-state">Could not load jobs and results.</div>';
    scheduleResultsPolling([]);
  }
}

async function resumeJob(jobId, button) {
  button.disabled = true;
  button.textContent = 'Reprise…';
  try {
    const response = await fetch(`/api/jobs/${encodeURIComponent(jobId)}/resume`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Resume failed.');
    await fetchResults();
  } catch (error) {
    button.disabled = false;
    button.textContent = button.dataset.resumeLabel || 'Resume';
    window.alert(error.message);
  }
}

async function deleteJob(jobId, button) {
  if (!window.confirm(`Delete job “${jobId}” and its files?`)) return;
  if (button) {
    button.disabled = true;
    button.textContent = 'Suppression…';
  }
  try {
    const response = await fetch(`/api/jobs/${encodeURIComponent(jobId)}`, { method: 'DELETE' });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Suppression impossible.');
    await fetchResults();
  } catch (error) {
    if (button) {
      button.disabled = false;
      button.textContent = 'Delete';
    }
    window.alert(error.message);
  }
}

async function clearOldResults() {
  try {
    const list = await fetch('/api/results').then((r) => r.json());
    if (!Array.isArray(list) || !list.length) return;
    const keep = [...list].sort((a, b) => {
      const rank = (j) => (j.status === 'running' ? 2 : j.status === 'done' ? 1 : 0);
      const byStatus = rank(b) - rank(a);
      if (byStatus) return byStatus;
      return String(b.updated || '').localeCompare(String(a.updated || ''));
    })[0]?.id;
    if (!window.confirm(
      keep
        ? `Clear all jobs except “${keep}” (newest / running)?`
        : 'Clear all jobs?',
    )) return;
    const response = await fetch('/api/jobs/clear-others', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ keep: keep || '' }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Nettoyage impossible.');
    await fetchResults();
  } catch (error) {
    window.alert(error.message);
  }
}

resultsList.addEventListener('click', (event) => {
  const resume = event.target.closest('[data-resume-job]');
  if (resume) {
    resumeJob(resume.dataset.resumeJob, resume);
    return;
  }
  const del = event.target.closest('[data-delete-job]');
  if (del) deleteJob(del.dataset.deleteJob, del);
});

document.querySelectorAll('input[name="source-mode"]').forEach((radio) => {
  radio.addEventListener('change', (event) => {
    const mode = event.target.value;
    clearCalculationTraces();
    scfMode.classList.toggle('hidden', mode !== 'scf');
    formulaMode.classList.toggle('hidden', mode !== 'formula');
    fileMode.classList.toggle('hidden', mode !== 'file');
    if (mode === 'scf') syncScfFileName();
    flashSourceTip(mode);
  });
  radio.addEventListener('click', () => {
    // Même si déjà sélectionné : un toucher montre le tip 10 s
    flashSourceTip(radio.value);
  });
});

document.querySelectorAll('#scf-supercell-input, #file-supercell-input, #formula-mode input, #structure-file').forEach((input) => {
  input.addEventListener('input', () => {
    state.sourceDirty = true;
    updateRuntimeEstimate();
  });
  input.addEventListener('change', () => {
    state.sourceDirty = true;
    updateRuntimeEstimate();
  });
});

document.querySelector('#structure-file')?.addEventListener('change', () => {
  flashSourceTip('file');
});

materialNameInput.addEventListener('input', () => {
  const name = materialName();
  syncScfFileName();
  if (!state.sourceInfo) {
    state.sourceDirty = true;
    return;
  }
  // Seul un vrai changement de matériau invalide la validation
  if (state.sourceInfo.material_name
      && name.toLowerCase() !== String(state.sourceInfo.material_name).toLowerCase()) {
    clearCalculationTraces();
    materialNameInput.value = name;
    syncScfFileName();
  }
});

tabs.forEach((tab) => tab.addEventListener('click', () => {
  setTab(tab.dataset.tab);
  if (tab.dataset.tab === 'calculations') {
    refreshParallelCapacity({ adjustNp: false });
  }
}));
const brandHome = document.querySelector('.brand-wrap');
if (brandHome) {
  brandHome.style.cursor = 'pointer';
  brandHome.title = 'Home';
  const goHome = () => setTab(null);
  brandHome.addEventListener('click', goHome);
  brandHome.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      goHome();
    }
  });
}
// Event delegation: survives re-renders and avoids a dead button
document.querySelector('#live-monitor')?.addEventListener('click', (event) => {
  const openBtn = event.target.closest('#live-monitor-open');
  if (!openBtn) return;
  event.preventDefault();
  openDetailedMonitor();
});
document.querySelector('#lang-fr')?.addEventListener('click', () => {
  window.applyParamuI18n?.('fr');
  setTab(document.body.classList.contains('is-home') ? null
    : (document.querySelector('.tab.is-active')?.dataset.tab || 'calculations'));
});
document.querySelector('#lang-en')?.addEventListener('click', () => {
  window.applyParamuI18n?.('en');
  setTab(document.body.classList.contains('is-home') ? null
    : (document.querySelector('.tab.is-active')?.dataset.tab || 'calculations'));
});
document.addEventListener('paramu:lang', () => {
  // Refresh dynamic parallel hint after language switch
  if (typeof refreshParallelCapacity === 'function') {
    refreshParallelCapacity({ adjustNp: false });
  }
});
catalogToggle.addEventListener('click', () => {
  const expanded = catalogToggle.getAttribute('aria-expanded') === 'true';
  catalogToggle.setAttribute('aria-expanded', String(!expanded));
  catalogToggle.textContent = expanded ? t('btn.allU') : t('btn.hideU');
  catalogFull.classList.toggle('hidden', expanded);
});
document.querySelector('#validate-structure').addEventListener('click', validateSource);
document.querySelector('#preview-scf').addEventListener('click', () => {
  previewScfInput().catch(() => {});
});
document.querySelector('#kind-select').addEventListener('change', () => {
  applyKindRecommendations();
  schedulePreviewRefresh();
  const kind = document.querySelector('#kind-select')?.value || 'auto';
  const kindTips = {
    auto: ['tip.kindAutoTitle', 'tip.kindAutoBody', 'Electronic type · auto', 'The pipeline picks insulator defaults unless the source suggests otherwise.'],
    semiconductor: ['tip.kindSemiTitle', 'tip.kindSemiBody', 'Semiconductor', 'Gapped path for hp.x (same numerics as insulator). With magnetism: scf2 unless NCL.'],
    insulator: ['tip.kindInsTitle', 'tip.kindInsBody', 'Insulator', 'Gapped path for hp.x. Collinear magnetic gaps use scf2 (tot_magnetization).'],
    metal: ['tip.kindMetTitle', 'tip.kindMetBody', 'Metal', 'Smearing only — no insulator-style scf2.'],
  };
  const row = kindTips[kind];
  if (row) showChoiceTip(tipText(row[0], row[2]), tipText(row[1], row[3]), 'info');
});
document.querySelector('#magnetic-select')?.addEventListener('change', () => {
  const mag = document.querySelector('#magnetic-select')?.value || 'auto';
  const magTips = {
    auto: ['tip.magAutoTitle', 'tip.magAutoBody', 'Magnetism · auto', 'Uses magnetic defaults / scf.in hints when available.'],
    on: ['tip.magOnTitle', 'tip.magOnBody', 'Magnetism · on (nspin=2)', 'Collinear spin-polarized density. Add an AFM axis for antiferromagnetism.'],
    off: ['tip.magOffTitle', 'tip.magOffBody', 'Magnetism · off (nspin=1)', 'Non-magnetic. On correlated magnets, U is often underestimated.'],
    noncolin: ['tip.magNclTitle', 'tip.magNclBody', 'Magnetism · noncolin (nspin=4)', 'Noncollinear density (noncolin=.true.). Optional SOC via lspinorb. No collinear scf2.'],
  };
  const row = magTips[mag];
  if (row) showChoiceTip(tipText(row[0], row[2]), tipText(row[1], row[3]), mag === 'noncolin' ? 'warning' : 'info');
});
document.querySelector('#afm-select')?.addEventListener('change', () => {
  const afm = document.querySelector('#afm-select')?.value || '';
  if (!afm) {
    showChoiceTip(
      tipText('tip.afmNoneTitle', 'AFM axis · none'),
      tipText('tip.afmNoneBody', 'No AFM axis → ferromagnetic (or NM) collinear order.'),
      'info',
    );
    return;
  }
  showChoiceTip(
    tipText('tip.afmAxisTitle', `AFM axis · ${afm}`),
    tipText('tip.afmAxisBody', 'Alternating spin planes along this axis. Use a supercell that fits both sublattices (e.g. 2 1 1).'),
    'info',
  );
});
document.querySelector('#lspinorb')?.addEventListener('change', () => {
  const on = !!document.querySelector('#lspinorb')?.checked;
  showChoiceTip(
    tipText('tip.socTitle', 'Spin–orbit (lspinorb)'),
    on
      ? tipText('tip.socOnBody', 'SOC enabled with noncolin. Requires suitable (often fully relativistic) pseudopotentials. Cost increases further.')
      : tipText('tip.socOffBody', 'SOC off — noncollinear magnetism without spin–orbit.'),
    'warning',
  );
});
['#magnetic-select', '#afm-select', '#ecutwfc', '#ecutrho', '#kmesh', '#nq',
 '#start-mag', '#smearing', '#degauss', '#np'].forEach((selector) => {
  const el = document.querySelector(selector);
  if (!el) return;
  el.addEventListener('change', schedulePreviewRefresh);
  el.addEventListener('input', schedulePreviewRefresh);
});
['#magnetic-select', '#afm-select', '#kind-select',
 '#file-supercell-input', '#scf-supercell-input', '#supercell-input']
  .forEach((selector) => {
    const el = document.querySelector(selector);
    if (!el) return;
    el.addEventListener('change', updateMagnetismGuard);
    el.addEventListener('input', updateMagnetismGuard);
  });
document.querySelectorAll('[data-case]').forEach((btn) => {
  btn.addEventListener('click', () => applyCasePreset(btn.dataset.case));
});
document.querySelector('#choice-tip-close')?.addEventListener('click', hideChoiceTip);
document.addEventListener('paramu:lang', () => {
  updateMagnetismGuard();
  updateCaseSummary();
});
document.querySelector('#np')?.addEventListener('input', () => {
  refreshParallelCapacity({ adjustNp: false });
  updateRuntimeEstimate();
});
document.querySelector('#np')?.addEventListener('change', () => {
  refreshParallelCapacity({ adjustNp: false });
  updateRuntimeEstimate();
});
document.querySelector('#kind-select')?.addEventListener('change', updateRuntimeEstimate);
document.addEventListener('paramu:lang', updateRuntimeEstimate);
document.querySelectorAll('input[name="parallel-mode"]').forEach((radio) => {
  radio.addEventListener('change', () => {
    refreshParallelCapacity({ adjustNp: true });
  });
});
document.querySelector('#parallel-slots')?.addEventListener('input', () => {
  refreshParallelCapacity({ adjustNp: true });
});
document.querySelector('#parallel-slots')?.addEventListener('change', () => {
  refreshParallelCapacity({ adjustNp: true });
});
document.querySelector('#job-name').addEventListener('input', (event) => {
  delete event.target.dataset.fromMaterial;
});
document.querySelector('#run-calculation').addEventListener('click', launchCalculation);
document.querySelector('#refresh-results').addEventListener('click', fetchResults);
document.querySelector('#clear-old-results').addEventListener('click', clearOldResults);
document.querySelector('#open-case-help')?.addEventListener('click', () => openCaseHelp('help-practical'));
document.querySelectorAll('.help-toc a[href^="#"]').forEach((link) => {
  link.addEventListener('click', (event) => {
    const id = link.getAttribute('href')?.slice(1);
    if (!id) return;
    event.preventDefault();
    openCaseHelp(id);
  });
});

(() => {
  let lang = 'en';
  try { lang = localStorage.getItem('paramu-lang') || 'en'; } catch (_) { /* ignore */ }
  window.applyParamuI18n?.(lang === 'fr' ? 'fr' : 'en');
})();
setTab(null);
updateRuntimeEstimate();
updateMagnetismGuard();
loadCatalog();
loadMaterials();
refreshParallelCapacity({ adjustNp: true });
fetchResults();
# Généré par configure.sh — relancez ./configure.sh pour régénérer
# Sourcé automatiquement par start.sh et DEMARRER.sh
ROOT="/home/hiadsi/terme_U"
export PARAMETRE_U_ROOT="$ROOT"
export QE_BIN="${QE_BIN:-$ROOT/bin}"
export PATH="$ROOT/bin:$PATH"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"

# OpenMPI Fedora/RHEL
if [ -d /usr/lib64/openmpi/bin ]; then
  export PATH="/usr/lib64/openmpi/bin:$PATH"
fi

# Intel oneAPI (MKL + Intel MPI) — libs des exécutables dans bin/
if [ -f "/opt/intel/oneapi/setvars.sh" ] && [ -z "${ONEAPI_ROOT:-}" ]; then
  # shellcheck disable=SC1091
  . "/opt/intel/oneapi/setvars.sh" --force >/dev/null 2>&1 || . "/opt/intel/oneapi/setvars.sh" >/dev/null 2>&1 || true
fi

if [ -f "$ROOT/.venv/bin/activate" ]; then
  # shellcheck disable=SC1091
  . "$ROOT/.venv/bin/activate"
fi

#!/usr/bin/env python3
"""Serveur local de l'interface parametre-U et API des calculs hp.x."""
import base64
import json
import math
import mimetypes
import os
import re
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time
import uuid
from datetime import datetime, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote, unquote, urlparse

ROOT = Path(__file__).resolve().parents[1]
INTERFACE_DIR = ROOT / "interface"
sys.path.insert(0, str(ROOT))
UPLOADS = ROOT / "inputs" / ".uploads"
DOI = "10.1103/PhysRevB.71.035105"
TOKENS = {}  # token -> {"record": ..., "created": epoch}
PROCESSES = {}
TOKEN_TTL_SEC = int(os.environ.get("TOKEN_TTL_SEC", str(2 * 3600)))
UPLOAD_TTL_SEC = int(os.environ.get("UPLOAD_TTL_SEC", str(24 * 3600)))
# Journal d'accès silencieux par défaut (l'interface interroge /api/results
# toutes les 5 s et le flux noie le terminal) ; ACCESS_LOG=1 pour tout afficher.
ACCESS_LOG = os.environ.get("ACCESS_LOG", "").strip().lower() in {"1", "true", "yes"}
LOCK = threading.Lock()
# Parallel jobs (supercells): caps derived from this machine unless overridden
# MAX_PARALLEL_JOBS = concurrent dftu pipelines
# MAX_PARALLEL_MPI  = sum of --np (MPI ranks) allowed on the host
_CPU = os.cpu_count() or 4
_HOSTNAME = socket.gethostname()


def _default_max_jobs(cpu):
    """Suggest how many concurrent jobs this host can sensibly run."""
    if cpu <= 2:
        return 1
    if cpu <= 4:
        return 2
    if cpu <= 8:
        return 3
    return min(6, max(4, cpu // 4))


MAX_PARALLEL_JOBS = max(1, int(os.environ.get(
    "MAX_PARALLEL_JOBS", str(_default_max_jobs(_CPU)))))
MAX_PARALLEL_MPI = max(1, int(os.environ.get("MAX_PARALLEL_MPI", str(_CPU))))


def purge_expired_tokens():
    now = time.time()
    with LOCK:
        expired = [key for key, meta in TOKENS.items()
                   if now - meta.get("created", 0) > TOKEN_TTL_SEC]
        for key in expired:
            del TOKENS[key]


def get_token_record(token):
    purge_expired_tokens()
    with LOCK:
        meta = TOKENS.get(token)
    if not meta:
        return None
    return meta["record"]


def store_token(record):
    purge_expired_tokens()
    token = uuid.uuid4().hex
    with LOCK:
        TOKENS[token] = {"record": record, "created": time.time()}
    return token


def purge_old_uploads():
    if not UPLOADS.is_dir():
        return
    now = time.time()
    for path in UPLOADS.iterdir():
        if not path.is_file():
            continue
        try:
            age = now - path.stat().st_mtime
        except OSError:
            continue
        if age > UPLOAD_TTL_SEC:
            path.unlink(missing_ok=True)


def list_active_job_ids():
    """Identifiants des calculs dftu encore actifs (suivis ou orphelins)."""
    found = []
    with LOCK:
        tracked = list(PROCESSES)
    for job_id in tracked:
        if job_process_active(job_id):
            found.append(job_id)
    proc_dir = Path("/proc")
    if not proc_dir.is_dir():
        return found
    known = set(found)
    for entry in proc_dir.iterdir():
        if not entry.name.isdigit():
            continue
        try:
            args = [part.decode(errors="replace") for part in
                    (entry / "cmdline").read_bytes().split(b"\0") if part]
        except OSError:
            continue
        if "dftu.py" not in " ".join(args) or "run" not in args:
            continue
        try:
            name_index = args.index("--name")
        except ValueError:
            continue
        if name_index + 1 >= len(args):
            continue
        job_id = args[name_index + 1]
        if job_id not in known:
            known.add(job_id)
            found.append(job_id)
    return found


def any_job_process_active():
    active = list_active_job_ids()
    return active[0] if active else None


def job_mpi_ranks(job_id):
    """Rangs MPI (--np) d'un job, depuis state.json (défaut 4)."""
    state_path = ROOT / "jobs" / job_id / "state.json"
    if state_path.is_file():
        try:
            state = json.loads(state_path.read_text(encoding="utf-8"))
            value = (state.get("params") or {}).get("np")
            if type(value) is int and value >= 1:
                return value
            value = (state.get("opts") or {}).get("np")
            if type(value) is int and value >= 1:
                return value
        except (OSError, json.JSONDecodeError, TypeError, ValueError):
            pass
    return 4


def parallel_capacity(requested_np=0, exclude_job_id=None):
    """Parallel resource state and machine-derived suggestions."""
    active = [job_id for job_id in list_active_job_ids()
              if job_id != exclude_job_id]
    used_mpi = sum(job_mpi_ranks(job_id) for job_id in active)
    mpi_free = max(0, MAX_PARALLEL_MPI - used_mpi)
    # Suggested concurrent supercell jobs for *this* host
    if MAX_PARALLEL_MPI <= 2 or MAX_PARALLEL_JOBS <= 1:
        suggested_slots = 1
    else:
        suggested_slots = min(
            MAX_PARALLEL_JOBS,
            max(2, MAX_PARALLEL_MPI // 2),
        )
    budget = mpi_free if mpi_free > 0 else MAX_PARALLEL_MPI
    suggested_np_parallel = max(1, budget // max(1, suggested_slots))
    suggested_np_solo = max(1, mpi_free if mpi_free > 0 else MAX_PARALLEL_MPI)
    return {
        "active_jobs": active,
        "n_active": len(active),
        "max_jobs": MAX_PARALLEL_JOBS,
        "jobs_free": max(0, MAX_PARALLEL_JOBS - len(active)),
        "used_mpi": used_mpi,
        "max_mpi": MAX_PARALLEL_MPI,
        "mpi_free": mpi_free,
        "cpu_count": _CPU,
        "hostname": _HOSTNAME,
        "requested_np": int(requested_np or 0),
        "suggested_slots": suggested_slots,
        "suggested_np_solo": suggested_np_solo,
        "suggested_np_parallel": suggested_np_parallel,
        "env_overridden": {
            "jobs": "MAX_PARALLEL_JOBS" in os.environ,
            "mpi": "MAX_PARALLEL_MPI" in os.environ,
        },
        "can_start": (
            len(active) < MAX_PARALLEL_JOBS
            and used_mpi + int(requested_np or 0) <= MAX_PARALLEL_MPI
        ),
    }


def assert_can_start_job(requested_np, exclude_job_id=None):
    """Reject a launch that exceeds this machine's job or MPI caps."""
    if type(requested_np) is not int or requested_np < 1:
        raise ValueError("np must be an integer ≥ 1.")
    if requested_np > MAX_PARALLEL_MPI:
        raise ValueError(
            "np=%s exceeds this host's MPI cap (%s cores available as "
            "MAX_PARALLEL_MPI on %s). Lower np or set MAX_PARALLEL_MPI."
            % (requested_np, MAX_PARALLEL_MPI, _HOSTNAME))
    cap = parallel_capacity(requested_np, exclude_job_id=exclude_job_id)
    if cap["n_active"] >= MAX_PARALLEL_JOBS:
        raise ValueError(
            "Parallel job limit reached (%s/%s) on %s. Active: %s. "
            "Wait for a job to finish or raise MAX_PARALLEL_JOBS."
            % (cap["n_active"], MAX_PARALLEL_JOBS, _HOSTNAME,
               ", ".join(cap["active_jobs"])))
    if cap["used_mpi"] + requested_np > MAX_PARALLEL_MPI:
        raise ValueError(
            "Not enough MPI capacity on %s for another supercell job: "
            "%s ranks in use + np=%s > cap %s. Lower np (≤ %s) or wait."
            % (_HOSTNAME, cap["used_mpi"], requested_np, MAX_PARALLEL_MPI,
               max(1, cap["mpi_free"])))
    return cap


def allowed_artifact_path(url_path):
    """Autorise uniquement outputs/<job>/… et jobs/<job>/logs/…"""
    rel = unquote(url_path).lstrip("/")
    if not rel or ".." in rel.split("/") or rel.startswith("/"):
        return None
    parts = Path(rel).parts
    if not parts:
        return None
    if parts[0] == "outputs" and len(parts) >= 2:
        target = (ROOT / rel).resolve()
        root_out = (ROOT / "outputs").resolve()
        if str(target).startswith(str(root_out) + os.sep) or target == root_out:
            return target if target.is_file() else None
    if parts[0] == "jobs" and len(parts) >= 4 and parts[2] == "logs":
        target = (ROOT / rel).resolve()
        root_jobs = (ROOT / "jobs").resolve()
        if str(target).startswith(str(root_jobs) + os.sep) and target.is_file():
            return target
    return None


def job_process_active(job_id):
    with LOCK:
        process = PROCESSES.get(job_id)
    if process is not None and process.poll() is None:
        return True

    proc_dir = Path("/proc")
    if not proc_dir.is_dir():
        return False
    for entry in proc_dir.iterdir():
        if not entry.name.isdigit():
            continue
        try:
            args = [part.decode(errors="replace") for part in
                    (entry / "cmdline").read_bytes().split(b"\0") if part]
        except OSError:
            continue
        if "dftu.py" not in " ".join(args) or "run" not in args:
            continue
        try:
            name_index = args.index("--name")
        except ValueError:
            continue
        if name_index + 1 < len(args) and args[name_index + 1] == job_id:
            return True
    return False


def json_bytes(value):
    return json.dumps(value, ensure_ascii=False).encode("utf-8")


def validate_positive_triple(value, label):
    if not isinstance(value, list) or len(value) != 3 or any(
            type(item) is not int or item < 1 for item in value):
        raise ValueError("%s doit contenir exactement trois entiers positifs." % label)


PIPELINE_STEPS = ("prepare", "scf1", "scf2", "hp", "scf_u", "analyse")
_ACTIVE_STEP = {"running", "done", "failed", "interrupted", "soft_failed", "skipped", "prepared"}


def scf_progress_pct(info):
    """Avancement SCF : max(itérations/plafond, proximité log du seuil).

    Les supercellules progressent souvent longtemps avec un Δ encore élevé :
    le plafond electron_maxstep donne un taux visible dès les premières itérations.
    """
    if not info:
        return None
    if info.get("converged") is True or info.get("job_done"):
        return 100
    scores = []
    thr = info.get("conv_thr")
    acc = info.get("accuracy_ry")
    history = info.get("history") or []
    if thr is not None and thr > 0 and acc is not None and acc > 0:
        import math
        log_acc = math.log10(max(float(acc), 1e-30))
        log_thr = math.log10(float(thr))
        # Ancre sur le pire Δ vu (ou 100 Ry) pour une barre stable en début de SCF
        peak = max(
            (row.get("accuracy_ry") for row in history
             if row.get("accuracy_ry") is not None),
            default=None,
        )
        start = math.log10(max(float(peak or 100.0), float(acc), 1e-30))
        start = max(start, log_thr + 8.0)
        ratio = 100.0 * (start - log_acc) / max(start - log_thr, 1e-9)
        scores.append(max(0.0, min(99.0, ratio)))
    iteration = info.get("iteration") or info.get("n_iterations")
    max_iter = info.get("max_iterations") or 100
    if iteration is not None and max_iter:
        # Laisser de la marge avant 100 % : la convergence réelle doit conclure
        scores.append(min(95.0, 100.0 * float(iteration) / float(max_iter)))
    if not scores:
        return None
    return int(max(0, min(99, round(max(scores)))))


def normalize_pipeline_steps(steps, state=None, job_id=None):
    """Complète les étapes antérieures manquantes (ex. prepare perdu après reprise)."""
    steps = {key: dict(value) for key, value in (steps or {}).items()
             if isinstance(value, dict)}
    params = (state or {}).get("params") or {}
    progressed = [
        index for index, key in enumerate(PIPELINE_STEPS)
        if (steps.get(key) or {}).get("status") in _ACTIVE_STEP
    ]
    inputs_ready = bool(params) or (
        job_id is not None and (ROOT / "inputs" / job_id / "job.json").is_file()
    )
    if inputs_ready:
        prepare = steps.get("prepare")
        if not prepare or prepare.get("status") in {
                None, "not_started", "interrupted"}:
            steps["prepare"] = {
                "status": "done",
                "detail": (prepare or {}).get("detail") or "entrées prêtes",
            }
            if not progressed:
                progressed = [0]
    if not progressed:
        return steps
    far = max(progressed)
    scf2_needed = params.get("scf2_needed", True)
    skip_hp = params.get("skip_hp", False)
    for index in range(far):
        key = PIPELINE_STEPS[index]
        current = steps.get(key) or {}
        status = current.get("status")
        if status in _ACTIVE_STEP and status != "not_started":
            continue
        if key == "scf2" and not scf2_needed:
            steps[key] = {"status": "skipped",
                          "detail": current.get("detail") or "non magnétique ou métal"}
        elif key == "hp" and skip_hp:
            steps[key] = {"status": "skipped",
                          "detail": current.get("detail") or "--skip-hp"}
        else:
            steps[key] = {
                "status": "done",
                "detail": current.get("detail") or "étape antérieure terminée",
            }
    return steps


def collect_job_progress(job_id, state):
    """Lit les journaux live pour suivre la convergence SCF / hp jusqu'à la fin."""
    from pipeline import qeio

    logs = ROOT / "jobs" / job_id / "logs"
    archived = ROOT / "outputs" / job_id / "journaux"
    steps = (state or {}).get("steps") or {}
    results = (state or {}).get("results") or {}
    progress = {}

    def resolve_log(name):
        live = logs / name
        if live.is_file():
            return live
        arch = archived / name
        if arch.is_file():
            return arch
        return None

    params = (state or {}).get("params") or {}

    for step in ("scf1", "scf2", "scf_u"):
        status = (steps.get(step) or {}).get("status")
        if status in {None, "skipped", "not_started"} and step not in results:
            continue
        path = resolve_log("%s.out" % step)
        if path is None and status not in {"running", "interrupted", "failed", "done"}:
            continue
        info = qeio.parse_scf_progress(str(path) if path else "")
        inp = ROOT / "inputs" / job_id / ("%s.in" % step)
        inp_text = ""
        if inp.is_file():
            try:
                inp_text = inp.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                inp_text = ""
        # Seuil depuis l'entrée si le journal ne le répète pas
        if info.get("conv_thr") is None:
            if inp_text:
                try:
                    import re as _re
                    m = _re.search(
                        r"conv_thr\s*=\s*([-+0-9.eEdD]+)", inp_text)
                    if m:
                        info["conv_thr"] = float(
                            m.group(1).replace("d", "e").replace("D", "E"))
                except ValueError:
                    pass
            if info.get("conv_thr") is None:
                key = "conv_thr_tight" if step in {"scf2", "scf_u"} else "conv_thr"
                if params.get(key) is not None:
                    info["conv_thr"] = float(params[key])
        # Plafond d'itérations (utile pour supercellules longues)
        max_iter = 100
        if inp_text:
            try:
                import re as _re
                m = _re.search(r"electron_maxstep\s*=\s*(\d+)", inp_text)
                if m:
                    max_iter = max(1, int(m.group(1)))
            except ValueError:
                pass
        info["max_iterations"] = max_iter
        stored = results.get(step) or {}
        if stored.get("energy_ry") is not None and info.get("energy_ry") is None:
            info["energy_ry"] = stored["energy_ry"]
        if stored.get("n_scf_iterations") and not info.get("iteration"):
            info["iteration"] = stored["n_scf_iterations"]
            info["n_iterations"] = stored["n_scf_iterations"]
        if stored.get("converged") is not None and info.get("converged") is None:
            info["converged"] = stored["converged"]
        if status == "done" and info.get("converged") is None:
            info["converged"] = True
            info["message"] = info.get("message") or "étape terminée"
        if status == "running" and not info.get("available"):
            info["message"] = "QE démarré — en attente des premières itérations"
        info["step_status"] = status
        # Taux d'avancement : convergence (log) prioritaire, sinon itérations / max
        info["progress_pct"] = scf_progress_pct(info)
        progress[step] = info

    hp_status = (steps.get("hp") or {}).get("status")
    if hp_status not in {None, "skipped", "not_started"} or "hp" in results:
        path = resolve_log("hp.out")
        info = qeio.parse_hp_progress(str(path) if path else "")
        info["step_status"] = hp_status
        if hp_status == "done":
            info["available"] = True
            info["job_done"] = True
            info["message"] = info.get("message") or "hp.x terminé"
        if info.get("q_total") and info.get("q_done") is not None:
            info["progress_pct"] = int(min(
                100, round(100.0 * float(info["q_done"]) / float(info["q_total"]))))
        elif info.get("job_done"):
            info["progress_pct"] = 100
        progress["hp"] = info

    return progress


def inspect_source(source):
    from pipeline import elements
    from pipeline import qe_scf
    from pipeline import structure as structures

    purge_old_uploads()
    if source.get("supercell") not in (None, "", []):
        validate_positive_triple(source["supercell"], "La supercellule")

    mode = source.get("mode")
    scf_meta = None
    if mode == "scf":
        # Convention : inputs/<nom>/<nom>-scf.in (ex. fe/fe-scf.in, NiO/NiO-scf.in)
        name = source.get("name") or source.get("formula")
        if not isinstance(name, str) or not name.strip():
            raise ValueError(
                "Indiquez le nom du matériau : inputs/<nom>/<nom>-scf.in "
                "(ex. inputs/fe/fe-scf.in ou inputs/NiO/NiO-scf.in).")
        name = name.strip()
        try:
            scf_meta = qe_scf.load_material_scf(name, source.get("supercell"))
        except Exception as exc:
            raise ValueError(str(exc)) from exc
        name = scf_meta.get("name") or name
        struct = scf_meta["struct"]
        record = {
            "mode": "scf",
            "name": name,
            "path": scf_meta["source"],
            "supercell": source.get("supercell"),
            "filename": Path(scf_meta["source"]).name,
        }
    elif mode == "formula":
        formula = source.get("formula")
        if not isinstance(formula, str) or not formula.strip():
            raise ValueError("Entrez une formule chimique.")
        # Si <formule>-scf.in existe, les paramètres cristallins viennent de ce fichier.
        scf_path = qe_scf.material_scf_path(formula.strip())
        if scf_path.is_file():
            try:
                scf_meta = qe_scf.load_material_scf(formula.strip(), source.get("supercell"))
            except Exception as exc:
                raise ValueError(str(exc)) from exc
            struct = scf_meta["struct"]
            record = {
                "mode": "scf",
                "name": scf_meta.get("name") or formula.strip(),
                "path": scf_meta["source"],
                "supercell": source.get("supercell"),
                "filename": Path(scf_meta["source"]).name,
            }
        else:
            struct = structures.build_bulk(
                formula.strip(), source.get("prototype", "rocksalt"),
                a=source.get("a"), c=source.get("c"), ca=source.get("ca"),
                u=source.get("ase_u"), supercell=source.get("supercell"),
            )
            record = {"mode": "formula", "formula": formula.strip(),
                      "prototype": source.get("prototype", "rocksalt"),
                      "a": source.get("a"), "c": source.get("c"),
                      "ca": source.get("ca"), "ase_u": source.get("ase_u"),
                      "supercell": source.get("supercell")}
    elif mode == "file":
        filename = source.get("filename", "structure.cif")
        suffix = Path(filename).suffix.lower()
        name_lower = Path(filename).name.lower()
        allowed = {".cif", ".xsf", ".vasp", ".poscar", ".xyz", ".pdb", ".in", ".txt"}
        if suffix not in allowed:
            raise ValueError(
                "Format pris en charge : CIF, XSF, POSCAR/vasp, XYZ, PDB ou <matériau>-scf.in.")
        try:
            raw = base64.b64decode(source.get("content", ""), validate=True)
        except (ValueError, TypeError) as exc:
            raise ValueError("Le fichier transmis est illisible.") from exc
        if not raw or len(raw) > 20 * 1024 * 1024:
            raise ValueError("Le fichier est vide ou dépasse la limite de 20 Mo.")
        token = uuid.uuid4().hex
        save_suffix = suffix if suffix != ".txt" else ".in"
        path = UPLOADS / (token + save_suffix)
        UPLOADS.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        try:
            if name_lower.endswith("-scf.in") or name_lower.endswith(".in"):
                scf_meta = qe_scf.parse_scf_in(path)
                struct = scf_meta["struct"]
                if source.get("supercell"):
                    struct = structures.load_file(str(path), source.get("supercell"))
            else:
                struct = structures.load_file(str(path), source.get("supercell"))
        except Exception:
            path.unlink(missing_ok=True)
            raise
        record = {"mode": "file", "path": str(path),
                  "supercell": source.get("supercell"), "filename": Path(filename).name}
    else:
        raise ValueError("Choisissez une formule, un matériau *-scf.in ou un fichier.")

    correlated = {}
    for site in struct.sites:
        if elements.is_correlated(site.symbol):
            correlated.setdefault(site.symbol, []).append({
                "index": site.site_index,
                "manifold": elements.manifold(site.symbol),
                "frac": [round(float(v), 8) for v in site.frac],
            })
    if not correlated:
        raise ValueError("Aucun élément avec un canal Hubbard pris en charge n'a été trouvé dans cette structure.")

    record["correlated"] = correlated
    record["elements"] = list(correlated)
    token = store_token(record)
    payload = {
        "token": token,
        "formula": struct.formula,
        "nat": struct.nat,
        "volume": round(struct.volume, 4),
        "cell": [[round(float(x), 6) for x in row] for row in struct.cell],
        "correlated": correlated,
        "elements": list(correlated),
        "source_mode": record["mode"],
    }
    if scf_meta:
        mat_name = record.get("name") or Path(scf_meta["source"]).parent.name
        payload["material_name"] = mat_name
        payload["scf_file"] = Path(scf_meta["source"]).name
        payload["scf_path"] = "inputs/%s/%s-scf.in" % (mat_name, mat_name)
        payload["crystal"] = scf_meta["crystal"]
        payload["from_scf"] = scf_meta["params"]
        payload["ibrav"] = scf_meta["ibrav"]
    return payload


def build_scf_preview(payload):
    from pipeline import inputs as qein
    from pipeline import pseudos as ps
    from pipeline import structure as structures

    source = get_token_record(payload.get("token"))
    if not source:
        raise ValueError("Structure expirée; validez-la de nouveau avant l’aperçu SCF.")

    selected = payload.get("elements")
    groups = payload.get("site_groups")
    params = payload.get("params") or {}
    if not isinstance(selected, list) or not selected:
        raise ValueError("Sélectionnez au moins un élément corrélé.")
    if set(selected) - set(source.get("elements", [])):
        raise ValueError("La sélection contient un élément absent de la structure validée.")
    if not isinstance(groups, dict) or set(groups) != set(selected):
        raise ValueError("Définissez les groupes de sites avant de prévisualiser l’entrée.")
    for symbol, element_groups in groups.items():
        expected = {site["index"] for site in source["correlated"][symbol]}
        if not isinstance(element_groups, list) or any(
                not isinstance(group, list) or not group or any(
                    type(index) is not int or index < 1 for index in group)
                for group in element_groups):
            raise ValueError("Les groupes %s doivent contenir des indices positifs." % symbol)
        assigned = [index for group in element_groups for index in group]
        if set(assigned) != expected or len(assigned) != len(expected):
            raise ValueError("Les groupes %s doivent affecter chaque site exactement une fois." % symbol)

    if source["mode"] == "formula":
        struct = structures.build_bulk(
            source["formula"], source["prototype"], a=source.get("a"),
            c=source.get("c"), ca=source.get("ca"), u=source.get("ase_u"),
            supercell=source.get("supercell"))
    elif source["mode"] in {"scf", "file"}:
        struct = structures.load_file(source["path"], source.get("supercell"))
    else:
        raise ValueError("Source de structure inconnue.")

    magnetic_mode = params.get("magnetic", "auto")
    kind = params.get("kind", "auto")
    if magnetic_mode not in {"auto", "on", "off", "noncolin"}:
        raise ValueError("Magnétisme doit être auto, on, off ou noncolin.")
    if kind not in {"auto", "metal", "insulator", "semiconductor"}:
        raise ValueError(
            "Type de matériau doit être auto, metal, insulator ou semiconductor.")
    # Aligner preview sur prepare() : hints dès qu'un *.in est la source
    scf_hints = {}
    src_path = source.get("path") or ""
    if src_path and str(src_path).lower().endswith(".in"):
        try:
            from pipeline import qe_scf
            scf_hints = (qe_scf.parse_scf_in(src_path).get("params") or {})
        except Exception:
            scf_hints = {}
    if kind == "auto":
        kind = scf_hints.get("kind_hint") or "insulator"
    kind = qein.resolve_electronic_kind(kind)
    if magnetic_mode == "auto" and scf_hints.get("magnetic_hint") in {"on", "off"}:
        magnetic_mode = scf_hints["magnetic_hint"]
    noncolin = magnetic_mode == "noncolin" or bool(params.get("noncolin"))
    if noncolin:
        magnetic_mode = "noncolin"
    start_mag = params.get("start_mag", 0.5)
    afm_axes = params.get("afm", [])
    structures.assign_magnetism(
        struct, mode=magnetic_mode, afm_axis=afm_axes[0] if afm_axes else None,
        start_mag=start_mag)
    types = structures.finalize(struct, groups, selected)

    preferred_dirs = []
    if scf_hints.get("pseudo_dir"):
        preferred_dirs.append(os.path.expanduser(scf_hints["pseudo_dir"]))
    if source.get("path"):
        preferred_dirs.append(str(Path(source["path"]).parent))
    scf_pseudos = scf_hints.get("pseudos") or {}
    pseudo_info = {}
    for atomic_type in types:
        filename, origin = ps.ensure_pseudo(
            atomic_type["symbol"],
            preferred=scf_pseudos.get(atomic_type["symbol"]),
            preferred_dirs=preferred_dirs,
            allow_download=True)
        atomic_type["pseudo"] = filename
        header = ps.read_upf_header(os.path.join(ps.DEST_DIR, filename))
        pseudo_info[atomic_type["symbol"]] = {
            "file": filename,
            "source": origin,
            "type": header.get("pseudo_type", "?"),
            "z_valence": header.get("z_valence"),
        }

    kind_defaults = qein.recommended_kind_params(kind)
    ecutwfc = params.get("ecutwfc")
    if ecutwfc is None:
        ecutwfc = scf_hints.get("ecutwfc")
    ecutrho = params.get("ecutrho")
    if ecutrho is None:
        ecutrho = scf_hints.get("ecutrho")
    suggestions = [ps.suggest_cutoffs(os.path.join(ps.DEST_DIR, atomic_type["pseudo"]))
                   for atomic_type in types]
    suggestions = [item for item in suggestions if item]
    if ecutwfc is None:
        ecutwfc = math.ceil(max(item[0] for item in suggestions)) if suggestions else 40.0
    if ecutrho is None:
        ecutrho = math.ceil(max([item[1] for item in suggestions] + [4.0 * ecutwfc])) \
            if suggestions else 4.0 * ecutwfc
    ecutrho = max(float(ecutrho), 4.0 * float(ecutwfc))

    kmesh = params.get("kmesh") or scf_hints.get("kmesh") or kind_defaults["kmesh"]
    validate_positive_triple(kmesh, "kmesh")
    nq = params.get("nq") or kind_defaults["nq"]
    validate_positive_triple(nq, "nq")
    nq_adj, nq_adjusted = qein.adjust_nq(tuple(kmesh), tuple(nq))
    magnetic = any(atomic_type.get("mag") is not None for atomic_type in types) or noncolin
    material_kind = kind if kind in {"metal", "insulator", "semiconductor"} else "insulator"
    scf2_needed = magnetic and material_kind != "metal" and not noncolin
    occupations = "smearing" if (
        material_kind == "metal" or scf2_needed or noncolin) else "fixed"
    outdir = str(ROOT / "jobs" / ".preview" / "tmp") + os.sep
    smearing = params.get("smearing") or scf_hints.get("smearing") or kind_defaults["smearing"]
    degauss = params.get("degauss")
    if degauss is None:
        degauss = scf_hints.get("degauss")
    if degauss is None:
        degauss = kind_defaults["degauss"]
    preview_params = {
        "stage": "scf1",
        "prefix": "parametre_u_preview",
        "pseudo_dir": ps.DEST_DIR + os.sep,
        "outdir": outdir,
        "ecutwfc": float(ecutwfc),
        "ecutrho": float(ecutrho),
        "kmesh": kmesh,
        "magnetic": magnetic,
        "noncolin": noncolin,
        "lspinorb": bool(params.get("lspinorb")),
        "occupations": occupations,
        "smearing": smearing,
        "degauss": float(degauss),
        "conv_thr": 1.0e-10,
        "use_file": False,
        "nbnd": None,
        "tot_magnetization": None,
    }
    hp_params = {
        "prefix": "parametre_u_preview",
        "outdir": outdir,
        "nq": list(nq_adj),
        "conv_thr_chi": float(params.get("conv_thr_chi", 1.0e-8)),
        "kind": material_kind,
    }
    return {
        "formula": struct.formula,
        "nat": struct.nat,
        "kind": material_kind,
        "magnetic": magnetic,
        "noncolin": noncolin,
        "scf2_needed": scf2_needed,
        "nq": list(nq_adj),
        "nq_adjusted": nq_adjusted,
        "recommended": qein.recommended_kind_params(kind),
        "input": qein.render_pw_input(struct, types, preview_params),
        "hp_input": qein.render_hp_input(hp_params),
    }


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        # Ne sert QUE interface/ via SimpleHTTP ; le reste est filtré dans do_GET.
        super().__init__(*args, directory=str(INTERFACE_DIR), **kwargs)

    def log_message(self, fmt, *args):
        if not ACCESS_LOG:
            return
        sys.stderr.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))

    def log_request(self, code="-", size="-"):
        """Accès silencieux, sauf erreurs HTTP (et tout si ACCESS_LOG=1)."""
        try:
            status = int(code)
        except (TypeError, ValueError):
            status = 0
        if ACCESS_LOG or status >= 400:
            sys.stderr.write('[%s] "%s" %s %s\n' % (
                self.log_date_time_string(), self.requestline, code, size))

    def send_json(self, status, payload):
        body = json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_file_bytes(self, path):
        data = path.read_bytes()
        ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length < 1 or length > 25 * 1024 * 1024:
            raise ValueError("Requête vide ou trop volumineuse.")
        try:
            return json.loads(self.rfile.read(length))
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise ValueError("Corps JSON invalide.") from exc

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/health":
            self.send_json(200, {"status": "ok", "parallel": parallel_capacity()})
            return
        if path == "/api/parallel":
            self.send_json(200, parallel_capacity())
            return
        if path == "/api/catalog":
            try:
                data = json.loads((ROOT / "data" / "elements.json").read_text(encoding="utf-8"))
                self.send_json(200, data)
            except (OSError, json.JSONDecodeError) as exc:
                self.send_json(500, {"error": str(exc)})
            return
        if path == "/api/materials":
            from pipeline import qe_scf
            self.send_json(200, {"materials": qe_scf.list_materials()})
            return
        if path == "/api/results":
            self.send_json(200, self.get_results())
            return
        match = re.fullmatch(r"/api/jobs/([A-Za-z0-9_-]+)", path)
        if match:
            self.send_json(200, self.get_job(match.group(1)))
            return
        # Artefacts contrôlés (rapports, journaux) — pas le dépôt entier
        artifact = allowed_artifact_path(path)
        if artifact is not None:
            try:
                self.send_file_bytes(artifact)
            except OSError as exc:
                self.send_json(500, {"error": str(exc)})
            return
        # Interface statique uniquement
        if path in {"/", "/interface", "/interface/"}:
            self.path = "/index.html"
            return SimpleHTTPRequestHandler.do_GET(self)
        if path.startswith("/interface/"):
            self.path = path[len("/interface"):] or "/"
            return SimpleHTTPRequestHandler.do_GET(self)
        self.send_error(404, "Not Found")

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            payload = self.read_json()
            if path == "/api/inspect":
                self.send_json(200, inspect_source(payload))
            elif path == "/api/preview-scf":
                self.send_json(200, build_scf_preview(payload))
            elif path == "/api/jobs":
                self.send_json(202, self.start_job(payload))
            elif re.fullmatch(r"/api/jobs/[A-Za-z0-9_-]+/resume", path):
                job_id = path.split("/")[-2]
                self.send_json(202, self.resume_job(job_id))
            elif path == "/api/jobs/clear-others":
                keep = str(payload.get("keep") or "").strip()
                self.send_json(200, self.clear_other_jobs(keep))
            else:
                self.send_json(404, {"error": "Route inconnue."})
        except (ValueError, KeyError) as exc:
            self.send_json(400, {"error": str(exc)})
        except Exception as exc:
            self.send_json(500, {"error": str(exc)})

    def do_DELETE(self):
        path = urlparse(self.path).path
        match = re.fullmatch(r"/api/jobs/([A-Za-z0-9_-]+)", path)
        if not match:
            self.send_json(404, {"error": "Route inconnue."})
            return
        try:
            self.send_json(200, self.delete_job(match.group(1)))
        except ValueError as exc:
            self.send_json(400, {"error": str(exc)})
        except Exception as exc:
            self.send_json(500, {"error": str(exc)})

    def start_job(self, payload):
        token = payload.get("token")
        selected = payload.get("elements")
        groups = payload.get("site_groups")
        params = payload.get("params", {})
        if not isinstance(params, dict):
            raise ValueError("Les paramètres du calcul doivent être un objet JSON.")
        source = get_token_record(token)
        if not source:
            raise ValueError("Structure expirée; validez de nouveau le matériau.")
        if not isinstance(selected, list) or not selected or any(
            not isinstance(symbol, str) for symbol in selected) or len(set(selected)) != len(selected):
            raise ValueError("Sélectionnez au moins un élément corrélé, sans doublon.")
        if set(selected) - set(source.get("elements", [])):
            raise ValueError("La sélection contient un élément absent du matériau validé.")
        if not isinstance(groups, dict) or set(groups) != set(selected):
            raise ValueError("Définissez les groupes locaux de chaque élément sélectionné.")
        if params.get("magnetic", "auto") not in {"auto", "on", "off", "noncolin"}:
            raise ValueError("Magnétisme doit être auto, on, off ou noncolin.")
        if params.get("kind", "auto") not in {"auto", "metal", "insulator", "semiconductor"}:
            raise ValueError(
                "Type de matériau doit être auto, metal, insulator ou semiconductor.")
        for key in ("ecutwfc", "ecutrho"):
            value = params.get(key)
            if value is not None and (isinstance(value, bool) or not isinstance(value, (int, float))
                                      or not 0 < value < float("inf")):
                raise ValueError("%s doit être un nombre positif fini." % key)
        for key in ("kmesh", "nq"):
            if params.get(key) is not None:
                validate_positive_triple(params[key], key)
        np_value = params.get("np", 4)
        if type(np_value) is not int or np_value < 1:
            raise ValueError("np doit être un entier supérieur ou égal à 1.")
        assert_can_start_job(np_value)
        for key in ("degauss", "start_mag"):
            value = params.get(key)
            if value is not None and (isinstance(value, bool) or not isinstance(value, (int, float))
                                      or not float("-inf") < value < float("inf")):
                raise ValueError("%s doit être un nombre fini." % key)
        if params.get("degauss") is not None and params.get("degauss") < 0:
            raise ValueError("degauss ne peut pas être négatif.")
        afm_axes = params.get("afm", [])
        if not isinstance(afm_axes, list) or any(axis not in {"x", "y", "z"} for axis in afm_axes):
            raise ValueError("Les axes AFM possibles sont x, y et z.")
        for symbol, element_groups in groups.items():
            expected = {site["index"] for site in source["correlated"][symbol]}
            if not isinstance(element_groups, list) or any(
                    not isinstance(group, list) or not group or any(
                        type(index) is not int or index < 1 for index in group)
                    for group in element_groups):
                raise ValueError("Les groupes %s doivent contenir des indices de sites positifs." % symbol)
            assigned = [index for group in element_groups for index in group]
            if set(assigned) != expected or len(assigned) != len(expected):
                raise ValueError("Les groupes %s doivent affecter chaque site exactement une fois." % symbol)
        safe_name = re.sub(r"[^A-Za-z0-9_-]+", "_", str(payload.get("name", "alliage"))).strip("_")[:48]
        job_id = "%s_%s" % (safe_name or "alliage", uuid.uuid4().hex[:8])
        command = [sys.executable, str(ROOT / "tools" / "dftu.py"), "run",
                   "--name", job_id, "--u-source", "hp"]
        if source["mode"] == "formula":
            command.extend(["--formula", source["formula"], "--prototype", source["prototype"]])
            for key, option in (("a", "--a"), ("c", "--c"), ("ca", "--ca"), ("ase_u", "--ase-u")):
                if source.get(key) is not None:
                    command.extend([option, str(source[key])])
        elif source["mode"] in {"scf", "file"}:
            command.extend(["--structure", source["path"]])
        else:
            raise ValueError("Source de structure inconnue.")
        for key, option in (("magnetic", "--magnetic"), ("kind", "--kind"),
                            ("ecutwfc", "--ecutwfc"), ("ecutrho", "--ecutrho"),
                            ("degauss", "--degauss"), ("smearing", "--smearing"),
                            ("np", "--np"), ("start_mag", "--start-mag")):
            if params.get(key) is not None:
                command.extend([option, str(params[key])])
        if params.get("lspinorb"):
            command.append("--lspinorb")
        for key, option in (("kmesh", "--kmesh"), ("nq", "--nq")):
            values = params.get(key)
            if values:
                command.extend([option, *map(str, values)])
        supercell = source.get("supercell")
        if supercell:
            validate_positive_triple(supercell, "La supercellule")
            command.extend(["--supercell", *map(str, supercell)])
        for symbol in selected:
            command.extend(["--hubbard-element", symbol])
            for group in groups[symbol]:
                if not isinstance(group, list) or not group:
                    raise ValueError("Chaque groupe de sites doit contenir au moins un site.")
                command.extend(["--site-group", "%s=%s" % (symbol, ",".join(map(str, group)))])
        for axis in params.get("afm", []):
            command.extend(["--afm", axis])

        env = os.environ.copy()
        env["PYTHONPATH"] = str(ROOT) + os.pathsep + env.get("PYTHONPATH", "")
        log_path = ROOT / "jobs" / job_id / "logs" / "interface.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_file = log_path.open("w", encoding="utf-8")
        try:
            process = subprocess.Popen(command, cwd=str(ROOT), env=env,
                                       stdout=log_file, stderr=subprocess.STDOUT,
                                       start_new_session=True)
        except OSError:
            log_file.close()
            raise
        else:
            log_file.close()
        with LOCK:
            PROCESSES[job_id] = process
        return {
            "id": job_id,
            "status": "running",
            "parallel": parallel_capacity(),
        }

    def _stop_job_process(self, job_id):
        with LOCK:
            process = PROCESSES.pop(job_id, None)
        if process is not None and process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except (ProcessLookupError, PermissionError, OSError):
                try:
                    process.terminate()
                except OSError:
                    pass
        # Orphelins : tuer uniquement les processus dont --name == job_id (match exact)
        proc_dir = Path("/proc")
        if proc_dir.is_dir():
            for entry in proc_dir.iterdir():
                if not entry.name.isdigit():
                    continue
                try:
                    args = [part.decode(errors="replace") for part in
                            (entry / "cmdline").read_bytes().split(b"\0") if part]
                except OSError:
                    continue
                if "dftu.py" not in " ".join(args) or "run" not in args:
                    continue
                try:
                    name_index = args.index("--name")
                except ValueError:
                    continue
                if name_index + 1 < len(args) and args[name_index + 1] == job_id:
                    try:
                        os.kill(int(entry.name), signal.SIGTERM)
                    except (ProcessLookupError, PermissionError, OSError):
                        pass

    def delete_job(self, job_id):
        if not re.fullmatch(r"[A-Za-z0-9_-]+", job_id or ""):
            raise ValueError("Identifiant de job invalide.")
        # Ne jamais supprimer le dépôt matériau inputs/<nom>/<nom>-scf.in
        material_marker = ROOT / "inputs" / job_id / ("%s-scf.in" % job_id)
        self._stop_job_process(job_id)
        removed = []
        for folder in (ROOT / "jobs" / job_id, ROOT / "outputs" / job_id):
            if folder.is_dir():
                shutil.rmtree(folder, ignore_errors=True)
                removed.append(str(folder.relative_to(ROOT)))
        job_inputs = ROOT / "inputs" / job_id
        if job_inputs.is_dir() and not material_marker.is_file():
            shutil.rmtree(job_inputs, ignore_errors=True)
            removed.append(str(job_inputs.relative_to(ROOT)))
        return {"id": job_id, "deleted": True, "removed": removed}

    def clear_other_jobs(self, keep):
        """Supprime jobs/outputs/inputs des calculs sauf le job conservé et les *-scf.in."""
        keep = str(keep or "").strip()
        names = set()
        for base in (ROOT / "jobs", ROOT / "outputs"):
            if base.is_dir():
                names.update(p.name for p in base.iterdir() if p.is_dir())
        with LOCK:
            names.update(list(PROCESSES))
        deleted = []
        for name in sorted(names):
            if keep and name == keep:
                continue
            # Conserver un dossier matériau (présence de <name>-scf.in)
            if (ROOT / "inputs" / name / ("%s-scf.in" % name)).is_file():
                # Ne retirer que jobs/ et outputs/ éventuels du même nom
                for folder in (ROOT / "jobs" / name, ROOT / "outputs" / name):
                    if folder.is_dir():
                        self._stop_job_process(name)
                        shutil.rmtree(folder, ignore_errors=True)
                        deleted.append(str(folder.relative_to(ROOT)))
                continue
            result = self.delete_job(name)
            deleted.extend(result.get("removed") or [name])
        return {"keep": keep or None, "deleted": deleted}

    def resume_job(self, job_id):
        state_path = ROOT / "jobs" / job_id / "state.json"
        if not state_path.is_file():
            raise ValueError(
                "État introuvable : ce job s'est arrêté pendant la préparation, "
                "avant d'enregistrer son état, et ne peut pas être repris. "
                "Supprimez-le puis relancez le calcul depuis une nouvelle "
                "validation de la structure.")
        if job_process_active(job_id):
            raise ValueError("Ce calcul est toujours actif; attendez sa fin avant toute reprise.")
        try:
            state = json.loads(state_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError("État du job illisible; reprise impossible.") from exc
        if not state.get("params") and not state.get("opts"):
            raise ValueError("Paramètres sauvegardés absents; reprise impossible.")
        if state.get("params") and not (ROOT / "inputs" / job_id / "job.json").is_file():
            raise ValueError("Métadonnées du job absentes; reprise impossible.")

        np_value = (state.get("params") or {}).get("np") or (state.get("opts") or {}).get("np") or 4
        try:
            np_value = int(np_value)
        except (TypeError, ValueError):
            np_value = 4
        assert_can_start_job(np_value)

        command = [sys.executable, str(ROOT / "tools" / "dftu.py"), "run",
                   "--name", job_id, "--resume"]
        if np_value:
            command.extend(["--np", str(np_value)])
        env = os.environ.copy()
        env["PYTHONPATH"] = str(ROOT) + os.pathsep + env.get("PYTHONPATH", "")
        log_path = ROOT / "jobs" / job_id / "logs" / "interface.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_file = log_path.open("a", encoding="utf-8")
        try:
            process = subprocess.Popen(command, cwd=str(ROOT), env=env,
                                       stdout=log_file, stderr=subprocess.STDOUT,
                                       start_new_session=True)
        except OSError:
            log_file.close()
            raise
        else:
            log_file.close()
        with LOCK:
            PROCESSES[job_id] = process
        return {
            "id": job_id,
            "status": "running",
            "parallel": parallel_capacity(),
        }

    def get_job(self, job_id):
        state_path = ROOT / "jobs" / job_id / "state.json"
        with LOCK:
            process = PROCESSES.get(job_id)
        process_active = job_process_active(job_id)
        if not state_path.is_file():
            launch_log = ROOT / "jobs" / job_id / "logs" / "interface.log"
            launch_artifacts = []
            if launch_log.is_file():
                relative = launch_log.relative_to(ROOT).as_posix()
                launch_artifacts.append({"label": "Journal de lancement",
                                         "url": "/" + quote(relative, safe="/")})
            if process_active:
                return {"id": job_id, "status": "running", "steps": {
                    "prepare": {"status": "running", "detail": "Initialisation du job"}},
                    "artifacts": launch_artifacts}
            if process is not None:
                return {"id": job_id, "status": "failed", "steps": {},
                        "detail": "Le processus s’est arrêté avant d’enregistrer l’état (code %s)."
                        % process.returncode, "artifacts": launch_artifacts}
            return {"id": job_id, "status": "not_started", "steps": {},
                    "detail": "Aucun état de calcul enregistré.", "artifacts": launch_artifacts}
        try:
            state = json.loads(state_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {"id": job_id, "status": "interrupted", "steps": {},
                    "detail": "Le fichier d’état est illisible."}
        steps = normalize_pipeline_steps(
            state.get("steps", {}), state=state, job_id=job_id)
        structure = (state.get("params") or {}).get("structure")
        statuses = [item.get("status") for item in steps.values()]
        summary_path = ROOT / "outputs" / job_id / "résumé.json"
        output_dir = ROOT / "outputs" / job_id
        summary = None
        if summary_path.is_file():
            try:
                summary = json.loads(summary_path.read_text(encoding="utf-8"))
                if summary.get("run_id") != state.get("run_id"):
                    summary = None
                if summary is not None:
                    summary["references_methode"] = [{
                        "citation": "Cococcioni et de Gironcoli, Phys. Rev. B 71, 035105 (2005)",
                        "doi": DOI,
                        "role": "Méthode de réponse linéaire utilisée pour calculer U avec hp.x",
                    }]
            except (OSError, json.JSONDecodeError):
                summary = None
        artifacts = []
        if summary is not None:
            preferred = [
                ("Rapport final", output_dir / "rapport.txt"),
                ("Résumé structuré", output_dir / "résumé.json"),
                ("Index des fichiers", output_dir / "index.json"),
                ("Guide des sorties", output_dir / "LISEZ-MOI.txt"),
            ]
            for label, path in preferred:
                if path.is_file():
                    relative = path.relative_to(ROOT).as_posix()
                    artifacts.append({"label": label, "url": "/" + quote(relative, safe="/")})
            for subdir, label in (("entrees", "Entrée"), ("journaux", "Journal archivé"),
                                  ("hubbard", "Paramètres Hubbard")):
                folder = output_dir / subdir
                if folder.is_dir():
                    for path in sorted(folder.iterdir()):
                        if path.is_file():
                            relative = path.relative_to(ROOT).as_posix()
                            artifacts.append({"label": "%s : %s" % (label, path.name),
                                              "url": "/" + quote(relative, safe="/")})
        runtime_logs = ROOT / "jobs" / job_id / "logs"
        if runtime_logs.is_dir() and not (output_dir / "journaux").is_dir():
            for path in sorted((*runtime_logs.glob("*.out"), *runtime_logs.glob("interface.log"))):
                relative = path.relative_to(ROOT).as_posix()
                artifacts.append({"label": "Journal live : %s" % path.name,
                                  "url": "/" + quote(relative, safe="/")})
        # soft_failed (ex. hp non bloquant avec --u-source literature) ≠ échec global
        hard_failed = any(
            (steps.get(key) or {}).get("status") == "failed" for key in steps)
        soft_failed = any(
            (steps.get(key) or {}).get("status") == "soft_failed" for key in steps)
        analyse_done = steps.get("analyse", {}).get("status") == "done" and summary is not None
        if hard_failed:
            status = "failed"
        elif analyse_done:
            status = "degraded" if soft_failed else "done"
        elif any(item == "running" for item in statuses):
            if process_active:
                status = "running"
            else:
                status = "interrupted"
                for step in steps.values():
                    if step.get("status") == "running":
                        step["status"] = "interrupted"
                        step["detail"] = "Processus du job non actif; étape interrompue. Consultez son journal."
        elif soft_failed and not process_active:
            status = "degraded"
        elif not steps:
            if process_active:
                status = "running"
            elif state.get("params"):
                status = "prepared"
            elif state.get("opts"):
                # Lancé mais arrêté pendant la préparation : reprenable
                status = "failed"
            else:
                status = "not_started"
            if process_active:
                steps["prepare"] = {"status": "running", "detail": "Initialisation du job"}
        else:
            status = "running" if process_active else "interrupted"
        progress = collect_job_progress(job_id, state)
        # Enrichir le détail des étapes running avec le suivi de convergence
        for key, info in progress.items():
            step = steps.get(key)
            if not step or step.get("status") not in {"running", "interrupted"}:
                continue
            if info.get("kind") == "scf" and info.get("iteration"):
                bits = ["it. %s" % info["iteration"]]
                if info.get("accuracy_ry") is not None:
                    bits.append("Δ = %.3e Ry" % info["accuracy_ry"])
                if info.get("conv_thr") is not None:
                    bits.append("seuil %.1e" % info["conv_thr"])
                if info.get("energy_ry") is not None:
                    bits.append("E = %.6f Ry" % info["energy_ry"])
                step["detail"] = " · ".join(bits)
            elif info.get("kind") == "hp" and info.get("message"):
                step["detail"] = info["message"]

        params = state.get("params") or {}
        opts = state.get("opts") or {}
        magnetic_flag = params.get("magnetic")
        afm_axis = opts.get("afm_axis")
        if afm_axis is None:
            afm_raw = opts.get("afm")
            if isinstance(afm_raw, (list, tuple)) and afm_raw:
                afm_axis = afm_raw[0]
            elif afm_raw not in (None, "", False):
                afm_axis = afm_raw
        noncolin = bool(params.get("noncolin")) or opts.get("magnetic") == "noncolin"
        if noncolin:
            nspin_disp = 4
        elif magnetic_flag:
            nspin_disp = 2
        elif magnetic_flag is not None:
            nspin_disp = 1
        else:
            nspin_disp = None
        calc = {
            "magnetic": bool(magnetic_flag) if magnetic_flag is not None else None,
            "magnetic_mode": opts.get("magnetic"),
            "kind": params.get("kind"),
            "nspin": nspin_disp,
            "noncolin": noncolin,
            "lspinorb": bool(params.get("lspinorb") or opts.get("lspinorb")),
            "scf2_needed": params.get("scf2_needed"),
            "afm_axis": afm_axis,
            "start_mag": opts.get("start_mag"),
            "np": params.get("np") or opts.get("np"),
        }
        return {"id": job_id, "status": status, "steps": steps,
                "updated": state.get("updated"), "structure": structure,
            "summary": summary, "artifacts": artifacts,
            "progress": progress,
            "calc": calc,
            "detail": "Entrées préparées; aucune étape de calcul lancée."
                if status == "prepared" else
                ("La préparation s'est arrêtée avant d'enregistrer les paramètres; "
                 "consultez le journal puis reprenez le calcul."
                 if status == "failed" and not steps else None)}

    def get_results(self):
        names = set()
        jobs_dir = ROOT / "jobs"
        if jobs_dir.is_dir():
            names.update(path.name for path in jobs_dir.iterdir()
                         if path.is_dir() and (path / "state.json").is_file())
        with LOCK:
            names.update(PROCESSES)
        outputs_dir = ROOT / "outputs"
        if outputs_dir.is_dir():
            names.update(path.parent.name for path in outputs_dir.glob("*/résumé.json"))
        return [self.get_job(name) for name in sorted(names)]


def main():
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8000"))
    server = ThreadingHTTPServer((host, port), Handler)
    print("Serveur parametre-U sur http://%s:%d/interface/" % (host, port), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
# parametre-U — pipeline DFT+U (Quantum ESPRESSO 7.5)

Chaîne complète **hp.x (U par réponse linéaire) → scf DFT+U → analyse**,
Python + interface locale ; exécutables QE prioritaires dans `bin/`
(puis `$QE_BIN`, puis `~/q-e-qe-7.5/bin`).

## Démarrage rapide

Sur une machine neuve (une fois) :

```bash
./configure.sh          # Python, venv, numpy/ase, env.sh, vérif. bin/pw.x
```

Ensuite :

```bash
./start.sh              # interface web (Firefox / navigateur)
./demarrer.sh           # idem sans argument
./demarrer.sh inputs/mon_alliage.json   # calcul depuis un JSON
./star.sh               # alias de start.sh
```

Changer le port : `PORT=8080 ./start.sh`. Sans navigateur :
`OPEN_BROWSER=0 ./start.sh`. Vérifier l’environnement : `./configure.sh --check`.

Les binaires QE attendus sont dans `bin/` (`pw.x`, `hp.x`). S’ils sont liés à
Intel MKL/MPI, installez Intel oneAPI (Base + HPC) avant les calculs ;
`configure.sh` détecte `/opt/intel/oneapi/setvars.sh` et l’écrit dans `env.sh`.

Le catalogue affiche des valeurs indicatives en eV, pas des constantes
universelles; pour un matériau étudié, privilégier le calcul hp.x.

## Calculer U pour un nouvel alliage

Copiez et adaptez [`inputs/alloy.template.json`](inputs/alloy.template.json).
Pour un prototype disponible dans ASE, donnez `formula`, `prototype` et le
paramètre de maille. Pour un alliage ordonné réel, utilisez plutôt `structure`
avec un fichier CIF, POSCAR ou XSF. Ces deux modes sont alternatifs.
`site_groups` décrit, pour chaque élément corrélé, les indices 1-based des
sites équivalents dans l'ordre où ASE lit les atomes, en comptant séparément
chaque élément. Les sites d'un même groupe partagent un type QE
et un U; des environnements différents doivent être placés dans des groupes
distincts. Tous les sites de chaque élément corrélé doivent être couverts.

```bash
./DEMARRER.sh inputs/mon_alliage.json --dry-run  # vérifier/générer les entrées
./DEMARRER.sh inputs/mon_alliage.json             # lancer scf -> hp.x -> scf+U
./DEMARRER.sh inputs/mon_alliage.json --fresh     # recommencer le job
```

Le lanceur `DEMARRER.sh` impose `--u-source hp` et refuse `skip_hp` (pour un
calcul sans hp.x, utilisez `tools/dftu.py run --skip-hp`). Le rapport et le
résumé U sont écrits dans `outputs/<name>/`; les U du catalogue ne sont pas
repris pour le calcul de l'alliage.

```bash
# NiO antiferromagnétique (prototype + maille doublée + spins alternés)
python3 tools/dftu.py run --name nio --formula NiO --prototype rocksalt \
    --a 4.17 --supercell 2 1 1 --afm --ecutwfc 50 --ecutrho 400

# depuis un fichier de structure (cif, xsf, POSCAR, ...)
python3 tools/dftu.py run --name mon_mat --structure entree.cif

# sans hp.x : U de littérature (data/elements.json) ou imposé
python3 tools/dftu.py run --name nio_lit --structure nio.cif --skip-hp \
    --u-source literature --u Ni=6.2

python3 tools/dftu.py list          # état des jobs
python3 tools/dftu.py show nio      # rapport
```

## Étapes du pipeline

| Étape    | Code    | Rôle |
|----------|---------|------|
| prepare  | —       | structure (ASE/prototype), magnétisme, pseudos, inputs |
| scf1     | pw.x    | DFT : magnétique « faux métal » (smearing) ou isolant |
| scf2     | pw.x    | isolant magnétique : `occupations=fixed`, `nbnd`, `tot_magnetization` (workflow HP example02) |
| hp.x     | hp.x    | U par réponse linéaire (DFPT) → `<prefix>.Hubbard_parameters.dat` |
| scf_u    | pw.x    | scf DFT+U avec l'U calculé (carte `HUBBARD {ortho-atomic}`) |
| analyse  | —       | Résumé et rapport dans `outputs/<job>/`, avec les entrées, journaux et données U rangés par dossier |

Chaque étape est reprise là où elle s'est arrêtée (`state.json`) ; `--fresh`
efface jobs/tmp/logs, entrées générées et archives outputs ; `--dry-run`
génère les entrées sans lancer QE ni verrouiller `params_hash` (pseudos
locaux uniquement, pas de téléchargement).

## Organisation

```
data/elements.json    89 éléments; canaux 3d/4d/5d/4f/5f, U indicatifs non transférables
tools/build_elements.py  regénère data/elements.json
interface/            interface locale de consultation du catalogue
start.sh              lance le serveur HTTP local de l'interface
DEMARRER.sh            calcule les U d'un alliage depuis une entrée JSON dédiée
tools/dftu.py         CLI du pipeline
pipeline/             modules : structure, pseudos, inputs, qeio, runner, job
pseudo/               UPF utilisés (copiés localement ou téléchargés)
inputs/<job>/         entrées QE générées + job.json
jobs/<job>/           espace technique : state.json, logs live/, run/, tmp/ QE et fichiers de réponse
outputs/<job>/        livrables : résumé.json, rapport.txt, index.json, LISEZ-MOI.txt
outputs/<job>/entrees/  entrées QE et structure utilisées
outputs/<job>/journaux/ sorties archivées de pw.x et hp.x
outputs/<job>/hubbard/  Hubbard_parameters.dat produit par hp.x
```

Le dossier `jobs/<job>/` est l'espace de travail technique; ses fichiers `tmp/`
peuvent être volumineux et ne sont pas les résultats à transmettre. Le dossier
`outputs/<job>/` est l'archive lisible du calcul. `résumé.json` contient les
valeurs structurées, `rapport.txt` leur synthèse, et `index.json` inventorie les
fichiers archivés. Les journaux live restent consultables dans `jobs/<job>/logs/`
pendant l'exécution; ils sont copiés dans `outputs/<job>/journaux/` à la fin.

## Conventions reprises des exemples QE (HP/examples)

* Sites corrélés **en premier** dans `ATOMIC_POSITIONS` (exigence hp.x).
* scf1 : `smearing` + `starting_magnetization` → scf2 : `fixed` +
  `tot_magnetization` (arrondi à l'entier) + `nbnd` extraits de scf1.
* Carte `HUBBARD {ortho-atomic}` avec `U X-3d 0.0001` pendant les scf de
  préparation, vraies valeurs pendant le scf DFT+U.
* Pseudos : PAW (`kjpaw`) de préférence, sinon USPP (`rrkjus`) ;
  résolution locale (`thermo_pw`, `base des pseudos`, ...) puis téléchargement
  sur `pseudopotentials.quantum-espresso.org`.

## Réglages notables

* Coupures : suggestion de l'UPF par défaut (`--ecutwfc/--ecutrho` pour
  forcer ; l'exemple NiO officiel utilise 50/400 Ry).
* Maille k : 6×6×6 (isolant) / 8×8×8 (métal) par défaut ; maille q hp.x :
  2 2 2 (ajustée si non commensurable avec k).
* `--kind metal` : un seul scf en smearing (métaux) ; `auto` = isolant
  (ou `kind_hint` du `*-scf.in`).
* `--afm [x|y|z]` : spins alternés par plans (répétable ; 1er axe utilisé) ;
  `--mag Ni1=0.5 --mag Ni2=-0.5` pour un contrôle total ; `--magnetic off`
  pour le non-magnétique.
* `--np` : rangs MPI (défaut 4) ; `OMP_NUM_THREADS=1` forcé.
* Calculs parallèles (interface) : plusieurs jobs supercellule peuvent
  tourner ensemble. Plafonds : `MAX_PARALLEL_JOBS` (défaut 4) et
  `MAX_PARALLEL_MPI` (défaut = nombre de cœurs). La somme des `np` des
  jobs actifs ne doit pas dépasser `MAX_PARALLEL_MPI`.
* `QE_TIMEOUT` : délai max par exécutable QE en secondes (défaut 86400 ;
  `0` = illimité). `PSEUDO_PATHS` : dossiers UPF locaux supplémentaires
  (séparateur `:`).

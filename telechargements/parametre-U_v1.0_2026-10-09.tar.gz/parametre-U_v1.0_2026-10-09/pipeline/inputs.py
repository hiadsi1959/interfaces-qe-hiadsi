"""Génération des fichiers d'entrée QE (pw.x et hp.x) du pipeline.

Référence : HP/examples/example02 (NiO) et example04 (Ni) de QE 7.5.
"""
from . import elements as el


def _f(x, prec=8):
    return ("%%.%df" % prec) % float(x)


def _fort(x):
    """Flottant au format Fortran d'entrée QE (1.0d-10)."""
    s = "%.6e" % float(x)
    mant, exp = s.split("e")
    if "." not in mant:
        mant += ".0"
    return "%sd%s" % (mant, exp)


def render_pw_input(struct, types, p):
    """Fichier d'entrée pw.x.

    p : dict avec
      stage        : 'scf1' | 'scf2' | 'scf_u'
      prefix, pseudo_dir, outdir
      ecutwfc, ecutrho, kmesh(3), magnetic(bool)
      occupations  : 'smearing' | 'fixed'
      smearing, degauss
      nbnd, tot_magnetization   (scf2 / scf_u)
      use_file     : startingpot/startingwfc = 'file'
      conv_thr
      u_map        : {label: U} pour la carte HUBBARD (scf_u) ; sinon 1.0d-4
    """
    stage = p["stage"]
    L = []
    L.append(" &control")
    L.append("    calculation = 'scf'")
    L.append("    restart_mode = 'from_scratch'")
    L.append("    prefix = '%s'" % p["prefix"])
    L.append("    pseudo_dir = '%s'" % p["pseudo_dir"])
    L.append("    outdir = '%s'" % p["outdir"])
    L.append("    verbosity = 'high'")
    L.append(" /")
    L.append(" &system")
    L.append("    ibrav = 0")
    L.append("    nat = %d" % struct.nat)
    L.append("    ntyp = %d" % len(types))
    L.append("    ecutwfc = %s" % _f(p["ecutwfc"], 3))
    L.append("    ecutrho = %s" % _f(p["ecutrho"], 3))
    noncolin = bool(p.get("noncolin"))
    if noncolin:
        # QE : ne pas écrire nspin=4 à la main — noncolin=.true. active le cas NCL
        L.append("    noncolin = .true.")
        if p.get("lspinorb"):
            L.append("    lspinorb = .true.")
    elif p.get("magnetic"):
        L.append("    nspin = 2")
    if stage in ("scf1", "scf_u") and p.get("magnetic"):
        for i, t in enumerate(types, start=1):
            if t["mag"] is not None:
                L.append("    starting_magnetization(%d) = %s" % (i, _f(t["mag"], 4)))
    if p.get("nbnd"):
        L.append("    nbnd = %d" % int(p["nbnd"]))
    # tot_magnetization : chemin colinéaire (nspin=2) uniquement
    if (p.get("tot_magnetization") is not None and p.get("magnetic")
            and not noncolin):
        L.append("    tot_magnetization = %s" % _f(p["tot_magnetization"], 4))
    L.append("    occupations = '%s'" % p["occupations"])
    if p["occupations"] == "smearing":
        # Tolérer une valeur absente (None) : jamais de « 'None' » dans l'entrée.
        smear = p.get("smearing")
        smear = "gauss" if smear in (None, "") else smear
        deg = p.get("degauss")
        deg = 0.001 if deg is None else deg
        L.append("    smearing = '%s'" % smear)
        L.append("    degauss = %s" % _f(deg, 5))
    L.append(" /")
    L.append(" &electrons")
    L.append("    conv_thr = %s" % _fort(p.get("conv_thr", 1.0e-10)))
    L.append("    mixing_beta = 0.7")
    if p.get("use_file"):
        L.append("    startingpot = 'file'")
        L.append("    startingwfc = 'file'")
    L.append(" /")
    L.append("ATOMIC_SPECIES")
    for t in types:
        mass = t.get("mass")
        if mass is None or float(mass) <= 0:
            raise ValueError(
                "masse atomique inconnue pour %s (%s) — symbole absent de "
                "data/elements.json" % (t.get("label"), t.get("symbol")))
        L.append("%-4s %10.4f  %s" % (t["label"], float(mass), t["pseudo"]))
    L.append("ATOMIC_POSITIONS {crystal}")
    for s in struct.sites:
        L.append("%-4s %18.12f %18.12f %18.12f" % (s.label, s.frac[0], s.frac[1], s.frac[2]))
    L.append("CELL_PARAMETERS {angstrom}")
    for row in struct.cell:
        L.append(" %18.12f %18.12f %18.12f" % (row[0], row[1], row[2]))
    L.append("K_POINTS {automatic}")
    kx, ky, kz = p["kmesh"]
    L.append(" %d %d %d 0 0 0" % (kx, ky, kz))
    hub_types = [t for t in types if t["hubbard"]]
    if hub_types:
        L.append("HUBBARD {ortho-atomic}")
        for t in hub_types:
            if stage == "scf_u":
                u = p["u_map"][t["label"]]
            else:
                u = 1.0e-4  # valeur de travail, comme les exemples QE pour hp.x
            L.append("U %s-%s %s" % (t["label"], t["manifold"], _f(u, 4)))
    return "\n".join(L) + "\n"


def adjust_nq(kmesh, nq):
    """Ajuste nq pour que chaque composante divise celle de kmesh."""
    out = []
    warn = False
    for k, q in zip(kmesh, nq):
        q = max(1, int(q))
        while q > 1 and int(k) % q != 0:
            q -= 1
            warn = True
        out.append(q)
    return tuple(out), warn


def resolve_electronic_kind(kind):
    """Normalise le type électronique pour le pipeline SCF/hp.x.

    Dans ce workflow HP, « semiconductor » et « insulator » partagent le même
    chemin (occupations fixed hors scf1 magnétique) : ce qui compte est
    métal (smearing) vs système à gap. L'ordre magnétique (NM/FM/AFM) est
    indépendant et se règle via magnetic / afm.
    """
    if kind in (None, "", "auto"):
        return "insulator"
    if kind == "semiconductor":
        return "semiconductor"
    if kind == "metal":
        return "metal"
    return "insulator"


def recommended_kind_params(kind):
    """Paramètres de calcul recommandés selon le type de matériau.

    Aligné sur HP/examples (Ni métal, NiO / LiCoO2 isolants) : le contenu
    de hp.in reste le même format ; nq, smearing et degauss changent.
    """
    resolved = resolve_electronic_kind(kind)
    if resolved == "metal":
        return {
            "kind": "metal",
            "smearing": "mv",
            "degauss": 0.02,
            "kmesh": [8, 8, 8],
            "nq": [2, 2, 2],
        }
    # Isolant et semi-conducteur : même réglages numériques (système à gap)
    return {
        "kind": resolved if resolved in {"insulator", "semiconductor"} else "insulator",
        "smearing": "gauss",
        "degauss": 0.001,
        "kmesh": [6, 6, 6],
        "nq": [2, 2, 2],
    }


def render_hp_input(p):
    """Fichier d'entrée hp.x (identique en forme pour métal et isolant)."""
    return (
        "&inputhp\n"
        "   prefix = '%s',\n"
        "   outdir = '%s',\n"
        "   nq1 = %d, nq2 = %d, nq3 = %d,\n"
        "   conv_thr_chi = %s,\n"
        "   iverbosity = 2\n"
        "/\n"
    ) % (
        p["prefix"], p["outdir"],
        int(p["nq"][0]), int(p["nq"][1]), int(p["nq"][2]),
        _fort(p.get("conv_thr_chi", 1.0e-8)),
    )


def dump_structure(struct, path):
    """Copie JSON de la structure pour la traçabilité."""
    import json
    data = {
        "formula": struct.formula,
        "comment": struct.comment,
        "cell_A": [[round(x, 10) for x in row] for row in struct.cell.tolist()],
        "volume_A3": round(struct.volume, 6),
        "sites": [
            {"label": s.label, "symbol": s.symbol,
             "frac": [round(x, 12) for x in s.frac.tolist()],
             "mag": s.mag, "manifold": s.manifold}
            for s in struct.sites
        ],
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

"""Lancement des exécutables QE (pw.x, hp.x) avec journalisation."""
import os
import shutil
import subprocess

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# binaires embarqués du projet d'abord (interface autonome), sinon QE externe
QE_SEARCH = [
    os.environ.get("QE_BIN", ""),
    os.path.join(ROOT, "bin"),
    os.path.expanduser("~/q-e-qe-7.5/bin"),
]
QE_BIN = next((d for d in QE_SEARCH if d and os.path.isdir(d)), QE_SEARCH[-1])


def find_exe(exe):
    """Chemin de l'exécutable : $QE_BIN > projet bin/ > QE 7.5 système."""
    for d in QE_SEARCH:
        if d and os.access(os.path.join(d, exe), os.X_OK):
            return os.path.join(d, exe)
    return None


class RunError(RuntimeError):
    pass


def available():
    return {e: find_exe(e) is not None for e in ("pw.x", "hp.x")}


def _mpirun_prefix(np):
    if np and np > 1:
        mpirun = shutil.which("mpirun") or shutil.which("mpiexec")
        if not mpirun:
            raise RunError("mpirun introuvable alors que --np > 1")
        return [mpirun, "-np", str(int(np))]
    return []


def default_timeout():
    """Timeout QE en secondes (QE_TIMEOUT) ; défaut 24 h. 0 = illimité."""
    raw = os.environ.get("QE_TIMEOUT", "").strip()
    if raw == "":
        return 24 * 3600
    try:
        value = float(raw)
    except ValueError:
        return 24 * 3600
    return None if value <= 0 else value


def run_code(exe, infile, outfile, np=4, cwd=None, timeout=None, log=None):
    """Exécute <exe> < infile > outfile. Retourne le code retour."""
    path = find_exe(exe)
    if not path:
        raise RunError("exécutable introuvable: %s (cherché dans %s)"
                       % (exe, ", ".join(d for d in QE_SEARCH if d)))
    if timeout is None:
        timeout = default_timeout()
    cmd = _mpirun_prefix(np) + [path]
    env = os.environ.copy()
    env["OMP_NUM_THREADS"] = "1"
    os.makedirs(os.path.dirname(outfile) or ".", exist_ok=True)
    try:
        with open(infile, "rb") as fin, open(outfile, "wb") as fout:
            proc = subprocess.run(
                cmd, stdin=fin, stdout=fout, stderr=subprocess.STDOUT,
                cwd=cwd or os.path.dirname(outfile) or ROOT,
                env=env, timeout=timeout,
            )
    except subprocess.TimeoutExpired as exc:
        raise RunError(
            "%s a dépassé le délai (%s s) — augmentez QE_TIMEOUT ou passez 0 pour illimité"
            % (exe, timeout)
        ) from exc
    if log:
        with open(log, "a", encoding="utf-8") as f:
            f.write("$ %s < %s > %s  (rc=%d)\n"
                    % (" ".join(cmd), infile, outfile, proc.returncode))
    return proc.returncode

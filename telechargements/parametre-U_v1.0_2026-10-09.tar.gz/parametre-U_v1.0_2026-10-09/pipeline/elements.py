"""Accès au jeu de données data/elements.json (généré par tools/build_elements.py)."""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_FILE = os.path.join(ROOT, "data", "elements.json")

_cache = None


def load_elements():
    """Retourne {symbole: fiche élément}."""
    global _cache
    if _cache is None:
        with open(DATA_FILE, encoding="utf-8") as f:
            data = json.load(f)
        _cache = {e["symbol"]: e for e in data["elements"]}
    return _cache


def get(symbol):
    """Fiche d'un élément ou None si inconnu."""
    return load_elements().get(symbol)


def is_correlated(symbol):
    """True si l'élément a un canal corrélé (manifold), même sans U de littérature."""
    e = get(symbol)
    return bool(e and e.get("correlated") and e.get("manifold"))


def manifold(symbol):
    """Canal Hubbard (3d, 4f, 5f...) ou None."""
    e = get(symbol)
    return e.get("manifold") if e else None


def u_literature(symbol):
    """U de littérature indicatif (eV) ou None."""
    e = get(symbol)
    if not e or not e.get("correlated"):
        return None
    u = e.get("U_typ")
    return u if u else None


def mass(symbol):
    e = get(symbol)
    return e.get("mass") if e else None


def pseudo_candidates(symbol):
    """Noms de pseudos pslibrary vérifiés, pseudo préféré en premier."""
    e = get(symbol)
    if not e:
        return []
    out = []
    if e.get("pseudo"):
        out.append(e["pseudo"])
    for c in e.get("pseudo_candidates") or []:
        if c not in out:
            out.append(c)
    return out


def magnetic_default(symbol):
    """Aimantation par défaut (éléments corrélés magnétiques)."""
    e = get(symbol)
    return bool(e and e.get("magnetic_default"))

"""Lecture des fichiers QE « {matériau}-scf.in ».

Convention générale :
  inputs/<nom>/<nom>-scf.in

Exemples :
  inputs/fe/fe-scf.in
  inputs/Fe/Fe-scf.in
  inputs/NiO/NiO-scf.in

La casse du dossier et du fichier doit coïncider ; la recherche du nom
saisi tolère une différence de casse (fe → Fe/Fe-scf.in).
Les paramètres cristallins sont lus à la validation, avant tout calcul.
"""
import math
import os
import re
from pathlib import Path

import numpy as np

from . import elements as el
from .structure import Site, Struct, StructError

BOHR_A = 0.529177210903
INPUTS_DIR = Path(el.ROOT) / "inputs"


def _safe_material_name(name):
    safe = str(name or "").strip()
    if not safe or "/" in safe or "\\" in safe or ".." in safe:
        raise StructError("Nom de matériau invalide.")
    return safe


def material_scf_path(name, resolve=True):
    """Chemin inputs/<name>/<name>-scf.in (résolution insensible à la casse)."""
    safe = _safe_material_name(name)
    exact = INPUTS_DIR / safe / ("%s-scf.in" % safe)
    if exact.is_file() or not resolve:
        return exact
    if not INPUTS_DIR.is_dir():
        return exact
    for directory in INPUTS_DIR.iterdir():
        if not directory.is_dir() or directory.name.lower() != safe.lower():
            continue
        candidate = directory / ("%s-scf.in" % directory.name)
        if candidate.is_file():
            return candidate
    return exact


def list_materials():
    """Matériaux disposant d'un fichier inputs/<nom>/<nom>-scf.in."""
    out = []
    if not INPUTS_DIR.is_dir():
        return out
    for path in sorted(INPUTS_DIR.glob("*/*-scf.in")):
        name = path.parent.name
        if path.name != "%s-scf.in" % name:
            continue
        out.append({
            "name": name,
            "path": str(path),
            "relpath": "inputs/%s/%s-scf.in" % (name, name),
            "filename": path.name,
        })
    return out


def _strip_comment(line):
    return re.split(r"[!#]", line, maxsplit=1)[0].strip()


def _parse_namelists(text):
    """Retourne {nom_namelist_lower: {clé: valeur_str}}."""
    namelists = {}
    current = None
    for raw in text.splitlines():
        line = _strip_comment(raw)
        if not line:
            continue
        start = re.match(r"&(\w+)\s*$", line, re.I)
        if start:
            current = start.group(1).lower()
            namelists.setdefault(current, {})
            continue
        if line == "/" or line.upper() == "/END":
            current = None
            continue
        if current is None:
            continue
        for part in re.split(r"[,]\s*(?=[A-Za-z_])", line):
            part = part.strip().rstrip(",")
            if not part or "=" not in part:
                continue
            key, val = part.split("=", 1)
            key = key.strip().lower()
            val = val.strip().strip("'\"")
            # celldm(1) -> conserver tel quel
            namelists[current][key] = val
    return namelists


def _parse_card(text, card_name):
    """Retourne (option, lignes) pour une carte ATOMIC_*/CELL_*/K_POINTS."""
    lines = text.splitlines()
    pattern = re.compile(r"^%s\s*(?:\{([^}]*)\}|\(([^)]*)\)|\s+(\S+))?\s*$" % card_name,
                         re.I)
    for i, raw in enumerate(lines):
        line = _strip_comment(raw)
        m = pattern.match(line)
        if not m:
            continue
        option = (m.group(1) or m.group(2) or m.group(3) or "").strip().lower()
        body = []
        for nxt in lines[i + 1:]:
            s = _strip_comment(nxt)
            if not s:
                if body:
                    break
                continue
            if re.match(r"^[A-Z_]+\b", s) and not re.match(r"^[A-Za-z]{1,3}\s+[-\d.]", s):
                # nouvelle carte (sauf ligne position/espèce)
                upper = s.split()[0].upper()
                if upper in {"ATOMIC_SPECIES", "ATOMIC_POSITIONS", "CELL_PARAMETERS",
                             "K_POINTS", "HUBBARD", "OCCUPATIONS", "CONSTRAINTS"}:
                    break
            body.append(s)
        return option, body
    return None, []


def _f(val):
    return float(str(val).lower().replace("d", "e"))


def _celldm_map(system):
    out = {}
    for key, val in system.items():
        m = re.match(r"celldm\((\d+)\)", key)
        if m:
            out[int(m.group(1))] = _f(val)
    return out


def _cell_from_ibrav(ibrav, celldm):
    """Vecteurs de maille (Å) selon les conventions INPUT_PW de QE."""
    if 1 not in celldm and ibrav != 0:
        raise StructError("celldm(1) manquant pour ibrav=%s." % ibrav)
    a = celldm.get(1, 0.0) * BOHR_A

    def angstrom_cell(rows):
        return np.asarray(rows, dtype=float)

    if ibrav == 1:  # sc
        return angstrom_cell([[a, 0, 0], [0, a, 0], [0, 0, a]])
    if ibrav == 2:  # fcc
        return angstrom_cell([[-a / 2, 0, a / 2], [0, a / 2, a / 2], [-a / 2, a / 2, 0]])
    if ibrav == 3:  # bcc
        return angstrom_cell([[a / 2, a / 2, a / 2],
                             [-a / 2, a / 2, a / 2],
                             [-a / 2, -a / 2, a / 2]])
    if ibrav == -3:  # bcc, axes cartésiens
        return angstrom_cell([[a, 0, 0], [0, a, 0], [0, 0, a]])  # positions en crystal unique
    if ibrav == 4:  # hex
        if celldm.get(3, 0.0) <= 0:
            raise StructError("ibrav=4 exige celldm(3)=c/a > 0.")
        c = celldm[3] * a
        return angstrom_cell([[a, 0, 0],
                             [-a / 2, a * math.sqrt(3) / 2, 0],
                             [0, 0, c]])
    if ibrav == 6:  # tetragonal P
        if celldm.get(3, 0.0) <= 0:
            raise StructError("ibrav=6 exige celldm(3)=c/a > 0.")
        c = celldm[3] * a
        return angstrom_cell([[a, 0, 0], [0, a, 0], [0, 0, c]])
    if ibrav == 8:  # orthorhombic P
        if celldm.get(2, 0.0) <= 0 or celldm.get(3, 0.0) <= 0:
            raise StructError("ibrav=8 exige celldm(2)=b/a et celldm(3)=c/a > 0.")
        b = celldm[2] * a
        c = celldm[3] * a
        return angstrom_cell([[a, 0, 0], [0, b, 0], [0, 0, c]])
    if ibrav == 0:
        raise StructError("ibrav=0 exige la carte CELL_PARAMETERS.")
    raise StructError("ibrav=%s non pris en charge pour l'instant; utilisez ibrav=0 "
                      "avec CELL_PARAMETERS, ou ibrav 1/2/3/4/6/8." % ibrav)


def _cell_from_parameters(option, body, celldm):
    if len(body) < 3:
        raise StructError("CELL_PARAMETERS incomplet.")
    rows = []
    for line in body[:3]:
        parts = line.split()
        if len(parts) < 3:
            raise StructError("Ligne CELL_PARAMETERS invalide: %s" % line)
        rows.append([_f(parts[0]), _f(parts[1]), _f(parts[2])])
    cell = np.asarray(rows, dtype=float)
    opt = (option or "alat").lower()
    if opt in ("angstrom", "ang"):
        return cell
    if opt == "bohr":
        return cell * BOHR_A
    if opt == "alat":
        if 1 not in celldm:
            raise StructError("CELL_PARAMETERS {alat} exige celldm(1).")
        return cell * celldm[1] * BOHR_A
    raise StructError("Unité CELL_PARAMETERS inconnue: %s" % option)


def _lattice_params(cell):
    a = float(np.linalg.norm(cell[0]))
    b = float(np.linalg.norm(cell[1]))
    c = float(np.linalg.norm(cell[2]))

    def angle(u, v):
        cu = np.clip(np.dot(u, v) / (np.linalg.norm(u) * np.linalg.norm(v)), -1.0, 1.0)
        return float(math.degrees(math.acos(cu)))

    return {
        "a": round(a, 8),
        "b": round(b, 8),
        "c": round(c, 8),
        "alpha": round(angle(cell[1], cell[2]), 6),
        "beta": round(angle(cell[0], cell[2]), 6),
        "gamma": round(angle(cell[0], cell[1]), 6),
    }


def parse_scf_in(path):
    """Parse un fichier {matériau}-scf.in.

    Retourne dict :
      struct, params (ecut, kmesh, ...), crystal, ibrav, celldm, source
    """
    path = Path(path)
    if not path.is_file():
        raise StructError("Fichier scf.in introuvable: %s" % path)
    text = path.read_text(encoding="utf-8", errors="replace")
    namelists = _parse_namelists(text)
    system = namelists.get("system") or {}
    control = namelists.get("control") or {}
    if not system:
        raise StructError("Namelist &system absente dans %s" % path.name)

    ibrav = int(float(system.get("ibrav", "0")))
    celldm = _celldm_map(system)
    cell_opt, cell_body = _parse_card(text, "CELL_PARAMETERS")
    if ibrav == 0 or cell_body:
        if not cell_body:
            raise StructError("CELL_PARAMETERS requis (ibrav=0) dans %s" % path.name)
        cell = _cell_from_parameters(cell_opt, cell_body, celldm)
    else:
        cell = _cell_from_ibrav(ibrav, celldm)

    # Espèces atomiques + aimantations initiales (AFM via Ni1/Ni2, etc.)
    _spec_opt, spec_body = _parse_card(text, "ATOMIC_SPECIES")
    species_labels = []
    species_pseudos = {}  # symbole chimique -> nom UPF (premier rencontré)
    for line in spec_body:
        parts = line.split()
        if not parts:
            continue
        species_labels.append(parts[0])
        if len(parts) >= 3:
            label = parts[0]
            sym_m = re.match(r"^([A-Za-z][a-z]?)", label)
            if sym_m:
                symbol = sym_m.group(1)
                symbol = symbol[0].upper() + symbol[1:].lower()
                species_pseudos.setdefault(symbol, parts[2])
    start_mags = {}
    for key, val in system.items():
        m = re.match(r"starting_magnetization\((\d+)\)", key)
        if not m:
            continue
        idx = int(m.group(1))
        if 1 <= idx <= len(species_labels):
            start_mags[species_labels[idx - 1]] = _f(val)

    pos_opt, pos_body = _parse_card(text, "ATOMIC_POSITIONS")
    if not pos_body:
        raise StructError("ATOMIC_POSITIONS manquant dans %s" % path.name)
    nat = int(float(system["nat"])) if "nat" in system else len(pos_body)
    sites = []
    for line in pos_body[:nat]:
        parts = line.split()
        if len(parts) < 4:
            raise StructError("Position atomique invalide: %s" % line)
        qe_label = parts[0]
        sym_match = re.match(r"^([A-Za-z][a-z]?)", qe_label)
        if not sym_match:
            raise StructError("Symbole atomique illisible: %s" % qe_label)
        symbol = sym_match.group(1)
        symbol = symbol[0].upper() + symbol[1:].lower()
        xyz = np.array([_f(parts[1]), _f(parts[2]), _f(parts[3])], dtype=float)
        opt = (pos_opt or "alat").lower()
        if opt == "crystal_sg":
            raise StructError(
                "ATOMIC_POSITIONS {crystal_sg} non pris en charge; "
                "utilisez crystal, alat, bohr ou angstrom.")
        if opt == "crystal":
            frac = xyz
        elif opt == "angstrom":
            frac = xyz @ np.linalg.inv(cell)
        elif opt == "bohr":
            frac = (xyz * BOHR_A) @ np.linalg.inv(cell)
        elif opt == "alat":
            if 1 not in celldm:
                raise StructError("ATOMIC_POSITIONS {alat} exige celldm(1).")
            frac = (xyz * celldm[1] * BOHR_A) @ np.linalg.inv(cell)
        else:
            raise StructError("Unité ATOMIC_POSITIONS inconnue: %s" % pos_opt)
        sites.append(Site(symbol, frac, mag=start_mags.get(qe_label), label=qe_label))

    if len(sites) != nat:
        raise StructError("nat=%d mais %d positions lues." % (nat, len(sites)))

    struct = Struct(cell, sites, comment=path.name)
    crystal = _lattice_params(cell)
    if 1 in celldm:
        crystal["alat_A"] = round(celldm[1] * BOHR_A, 8)
        crystal["a_conventional"] = crystal["alat_A"]

    kmesh = None
    lines = [_strip_comment(r) for r in text.splitlines()]
    for i, line in enumerate(lines):
        if re.match(r"^K_POINTS\b", line, re.I):
            if "automatic" in line.lower():
                for nxt in lines[i + 1:]:
                    if nxt:
                        parts = nxt.split()
                        if len(parts) >= 3:
                            kmesh = [int(float(parts[0])), int(float(parts[1])),
                                     int(float(parts[2]))]
                        break
            break

    params = {
        "prefix": (control.get("prefix") or path.stem.replace("-scf", "")).strip(),
        "ecutwfc": _f(system["ecutwfc"]) if "ecutwfc" in system else None,
        "ecutrho": _f(system["ecutrho"]) if "ecutrho" in system else None,
        "occupations": system.get("occupations"),
        "smearing": system.get("smearing"),
        "degauss": _f(system["degauss"]) if "degauss" in system else None,
        "nspin": int(float(system["nspin"])) if "nspin" in system else 1,
        "nbnd": int(float(system["nbnd"])) if "nbnd" in system else None,
        "kmesh": kmesh,
        "ibrav": ibrav,
        "starting_magnetization": start_mags or None,
        "pseudos": species_pseudos or None,
        "pseudo_dir": (control.get("pseudo_dir") or "").strip() or None,
    }
    if params["smearing"]:
        sm = params["smearing"].lower()
        if sm in ("marzari-vanderbilt", "m-v", "mv"):
            params["smearing"] = "mv"
        elif sm in ("gaussian", "gauss"):
            params["smearing"] = "gauss"
    if params["occupations"] == "smearing" or (params["degauss"] or 0) > 0:
        params["kind_hint"] = "metal"
    else:
        params["kind_hint"] = "insulator"
    if params["nspin"] and params["nspin"] >= 2:
        params["magnetic_hint"] = "on"
    else:
        params["magnetic_hint"] = "off"

    return {
        "struct": struct,
        "params": params,
        "crystal": crystal,
        "ibrav": ibrav,
        "celldm": celldm,
        "source": str(path),
        "name": path.parent.name if path.parent.name != "inputs" else params["prefix"],
    }


def load_material_scf(name, supercell=None):
    """Charge inputs/<name>/<name>-scf.in → Struct (+ meta via parse)."""
    path = material_scf_path(name, resolve=True)
    if not path.is_file():
        safe = _safe_material_name(name)
        raise StructError(
            "Fichier introuvable : inputs/%s/%s-scf.in "
            "(ex. inputs/fe/fe-scf.in ou inputs/NiO/NiO-scf.in)."
            % (safe, safe))
    data = parse_scf_in(path)
    # Nom canonique = dossier réel (conserve la casse du dépôt)
    data["name"] = path.parent.name
    data["source"] = str(path)
    struct = data["struct"]
    if supercell:
        from .structure import repeat_struct
        struct = repeat_struct(struct, supercell)
        data["struct"] = struct
    return data

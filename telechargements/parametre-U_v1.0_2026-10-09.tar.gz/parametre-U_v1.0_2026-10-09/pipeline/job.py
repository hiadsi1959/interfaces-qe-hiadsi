"""Orchestrateur du pipeline DFT+U :
préparation -> scf1 [-> scf2] -> hp.x -> scf DFT+U -> analyse.

Arborescence d'un job :
  inputs/<name>/   entrées QE générées
  jobs/<name>/     outdir QE (tmp/), logs/, run/, state.json
  outputs/<name>/  résumé.json, rapport.txt, sorties QE
"""
import hashlib
import json
import os
import shutil
import time
import uuid
from math import ceil

from . import elements as el
from . import inputs as qein
from . import pseudos as ps
from . import qeio
from . import runner
from . import structure as st

ROOT = el.ROOT
EV = 13.605693122994  # Ry -> eV

STEPS = ["prepare", "scf1", "scf2", "hp", "scf_u", "analyse"]


class JobError(RuntimeError):
    pass


def _now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _hash_params(p):
    txt = json.dumps(p, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(txt.encode("utf-8")).hexdigest()[:16]


def _divisors_ok(nk, nq):
    """Ajuste nq pour que nk % nq == 0 (grille q commensurable avec k)."""
    return qein.adjust_nq(nk, nq)


class Job(object):
    def __init__(self, name, opts, fresh=False):
        name = str(name or "").strip()
        if not name or name in {".", ".."} or "/" in name or "\\" in name:
            raise JobError("identifiant de job invalide")
        self.name = name
        self.opts = dict(opts)
        self.inp_dir = os.path.join(ROOT, "inputs", name)
        self.job_dir = os.path.join(ROOT, "jobs", name)
        self.tmp_dir = os.path.join(self.job_dir, "tmp")
        self.log_dir = os.path.join(self.job_dir, "logs")
        self.run_dir = os.path.join(self.job_dir, "run")
        self.out_dir = os.path.join(ROOT, "outputs", name)
        self.state_file = os.path.join(self.job_dir, "state.json")
        for d in (self.inp_dir, self.tmp_dir, self.log_dir, self.run_dir, self.out_dir):
            os.makedirs(d, exist_ok=True)
        self.state = None
        self._load_state(fresh)
        # Conserver les options de lancement dès la création : si la préparation
        # échoue avant d'écrire params, la reprise pourra la rejouer à l'identique.
        # Ne jamais écraser une source (structure/formula) déjà enregistrée par null.
        if self.state.get("opts") is None:
            self.state["opts"] = dict(self.opts)
            self._save()
        else:
            self._merge_launch_opts(self.opts)

    def _merge_launch_opts(self, incoming):
        """Fusionne les opts CLI non nuls dans l'état (préserve structure/formula)."""
        saved = dict(self.state.get("opts") or {})
        for key, value in (incoming or {}).items():
            if value is None or value == {} or value == []:
                continue
            if key in {"structure", "formula"} and saved.get(key):
                continue
            saved[key] = value
        self.state["opts"] = saved
        self._save()

    def _persist_opts(self):
        """Écrit self.opts complets (après prepare) pour un resume fiable."""
        self.state["opts"] = dict(self.opts)
        self._save()

    # ------------------------------------------------------------- état
    def _wipe_generated_inputs(self):
        """Efface les entrées générées du job, sans toucher un dépôt *-scf.in matériau."""
        material_marker = os.path.join(self.inp_dir, "%s-scf.in" % self.name)
        if os.path.isfile(material_marker):
            return
        if not os.path.isdir(self.inp_dir):
            return
        for fname in os.listdir(self.inp_dir):
            path = os.path.join(self.inp_dir, fname)
            if os.path.isfile(path) or os.path.islink(path):
                try:
                    os.remove(path)
                except OSError:
                    pass

    def _load_state(self, fresh):
        if fresh:
            for path in (self.tmp_dir, self.run_dir, self.log_dir):
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                os.makedirs(path, exist_ok=True)
            self._wipe_generated_inputs()
            for sub in ("hubbard", "entrees", "journaux"):
                folder = os.path.join(self.out_dir, sub)
                if os.path.isdir(folder):
                    shutil.rmtree(folder, ignore_errors=True)
            for stale in (
                os.path.join(self.out_dir, "résumé.json"),
                os.path.join(self.out_dir, "rapport.txt"),
                os.path.join(self.out_dir, "index.json"),
                os.path.join(self.out_dir, "LISEZ-MOI.txt"),
                self.state_file,
            ):
                if os.path.isfile(stale):
                    try:
                        os.remove(stale)
                    except OSError:
                        pass
        if fresh or not os.path.exists(self.state_file):
            self.state = {
                "job": self.name, "created": _now(), "updated": _now(),
                "run_id": uuid.uuid4().hex,
                "params": None, "params_hash": None,
                "steps": {}, "results": {}, "warnings": [],
            }
            return
        with open(self.state_file, encoding="utf-8") as f:
            self.state = json.load(f)
        self._recover_orphan_running()

    def _recover_orphan_running(self):
        """Toute étape « running » au chargement est orpheline (processus tué)."""
        changed = False
        for step, info in list((self.state.get("steps") or {}).items()):
            if isinstance(info, dict) and info.get("status") == "running":
                info["status"] = "interrupted"
                info["end"] = _now()
                info["detail"] = (info.get("detail") or "") + (
                    " — reprise : étape interrompue (processus non actif)"
                ).strip(" —")
                changed = True
        if changed:
            self._save()

    def _restore_for_resume(self):
        if not self.state.get("params"):
            raise JobError("reprise impossible : paramètres du job absents")
        meta_path = os.path.join(self.inp_dir, "job.json")
        structure_path = os.path.join(self.inp_dir, "structure.json")
        try:
            with open(meta_path, encoding="utf-8") as f:
                meta = json.load(f)
            with open(structure_path, encoding="utf-8") as f:
                structure_data = json.load(f)
        except (OSError, json.JSONDecodeError) as exc:
            raise JobError("reprise impossible : métadonnées ou structure sauvegardées illisibles") from exc

        struct = st.Struct(structure_data["cell_A"], [
            st.Site(site["symbol"], site["frac"], mag=site.get("mag"), label=site["label"])
            for site in structure_data["sites"]
        ], structure_data.get("comment", ""))
        types = [dict(item, mass=item.get("mass") or el.mass(item["symbol"]))
             for item in meta.get("types", [])]
        if not types:
            raise JobError("reprise impossible : types atomiques sauvegardés absents")
        self.struct = struct
        self.types = types
        self.magnetic = bool(self.state["params"].get("magnetic"))
        self.params = dict(self.state["params"])
        self.params["pseudo_dir"] = ps.DEST_DIR + os.sep
        self.params["outdir"] = self.tmp_dir + os.sep
        self.state["params"] = self.params
        self.pseudo_info = self.params.get("pseudos", {})

        base = dict(self.params)
        if not self._done("scf1"):
            p1 = dict(base, stage="scf1", occupations=self.params["occupations1"],
                      nbnd=None, tot_magnetization=None, use_file=False,
                      conv_thr=self.params["conv_thr"])
            self._write("scf1.in", qein.render_pw_input(struct, types, p1))
        if self.params["scf2_needed"] and not self._done("scf2"):
            r1 = self.state.get("results", {}).get("scf1") or {}
            p2 = dict(base, stage="scf2", occupations="fixed", nbnd=r1.get("nbnd"),
                      tot_magnetization=r1.get("tot_magnetization_rounded"),
                      use_file=True, conv_thr=self.params["conv_thr_tight"])
            self._write("scf2.in", qein.render_pw_input(struct, types, p2))
        if not self.params["skip_hp"] and not self._done("hp"):
            self._write("hp.in", qein.render_hp_input(base))
        return True

    def _save(self):
        self.state["updated"] = _now()
        tmp = self.state_file + ".part"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.state, f, indent=2, ensure_ascii=False)
        os.replace(tmp, self.state_file)

    def _warn(self, msg):
        if msg not in self.state["warnings"]:
            self.state["warnings"].append(msg)

    def _done(self, step):
        s = self.state["steps"].get(step)
        return bool(s and s.get("status") == "done")

    def _begin(self, step):
        self.state["steps"][step] = {"status": "running", "start": _now(), "t0": time.time()}
        self._save()
        print("[%s] %s ..." % (self.name, step), flush=True)

    def _end(self, step, ok, detail=""):
        s = self.state["steps"].setdefault(step, {})
        s.update({"status": "done" if ok else "failed", "end": _now(),
                  "seconds": round(time.time() - s.get("t0", time.time()), 1),
                  "detail": detail})
        self._save()
        print("[%s] %s %s %s" % (self.name, step, "OK" if ok else "ÉCHEC", detail), flush=True)
        if not ok:
            raise JobError("étape %s échouée : %s" % (step, detail))

    # -------------------------------------------------------- préparation
    def prepare(self, dry_run=False):
        o = self.opts
        self._begin("prepare")
        # --- structure
        scf_defaults = {}
        if o.get("structure"):
            # Normaliser le chemin pour resume fiable
            o["structure"] = os.path.abspath(o["structure"])
            struct = st.load_file(o["structure"], o.get("supercell"))
            base = os.path.basename(o["structure"]).lower()
            if base.endswith("-scf.in") or base.endswith(".in"):
                try:
                    from .qe_scf import parse_scf_in
                    scf_defaults = parse_scf_in(o["structure"]).get("params") or {}
                except Exception:
                    scf_defaults = {}
        else:
            if not o.get("formula"):
                self._end("prepare", False,
                          "structure ou formula absente des options (resume cassé ?)")
            struct = st.build_bulk(o["formula"], o.get("prototype", "rocksalt"),
                                   a=o.get("a"), c=o.get("c"), ca=o.get("ca"),
                                   u=o.get("u_ase"), supercell=o.get("supercell"))
        mag_mode = o.get("magnetic", "auto")
        # Honorer nspin / magnetic_hint du *-scf.in lorsque magnetic=auto
        if mag_mode == "auto" and scf_defaults.get("magnetic_hint") in {"on", "off"}:
            mag_mode = scf_defaults["magnetic_hint"]
        noncolin = mag_mode == "noncolin" or bool(o.get("noncolin"))
        if noncolin:
            mag_mode = "noncolin"
        # afm_axis peut être une liste (CLI --afm répétable) : garder le premier
        afm_axis = o.get("afm_axis")
        if isinstance(afm_axis, (list, tuple)):
            afm_axis = afm_axis[0] if afm_axis else None
        st.assign_magnetism(struct, mode=mag_mode,
                            afm_axis=afm_axis, mag_spec=o.get("mag_map") or None,
                            start_mag=o.get("start_mag", 0.5))
        types = st.finalize(struct, o.get("site_groups"), o.get("hubbard_elements"))

        magnetic = any(t["mag"] is not None for t in types) or noncolin
        kind = o.get("kind", "auto")
        if kind == "auto":
            kind = scf_defaults.get("kind_hint") or "insulator"
        kind = qein.resolve_electronic_kind(kind)
        kind_defaults = qein.recommended_kind_params(kind)
        # Priorité : options CLI > valeurs du *-scf.in > recommandations type
        for key in ("ecutwfc", "ecutrho", "kmesh", "smearing", "degauss", "nbnd"):
            if o.get(key) is None and scf_defaults.get(key) is not None:
                o[key] = scf_defaults[key]

        # --- pseudos (tous les types) ; honorer UPF du *-scf.in si présent
        scf_pseudos = scf_defaults.get("pseudos") or {}
        preferred_dirs = []
        if scf_defaults.get("pseudo_dir"):
            preferred_dirs.append(os.path.expanduser(scf_defaults["pseudo_dir"]))
        if o.get("structure"):
            preferred_dirs.append(os.path.dirname(o["structure"]))
        allow_dl = not dry_run
        pseudo_info = {}
        for t in types:
            preferred = scf_pseudos.get(t["symbol"])
            try:
                fn, src = ps.ensure_pseudo(
                    t["symbol"], preferred=preferred,
                    preferred_dirs=preferred_dirs, allow_download=allow_dl)
            except ps.PseudoError as exc:
                self._end("prepare", False, str(exc))
                return False
            if preferred and os.path.basename(fn) != os.path.basename(preferred):
                self._warn(
                    "pseudo scf.in %s introuvable pour %s — utilisation de %s (%s)"
                    % (preferred, t["symbol"], fn, src))
            t["pseudo"] = fn
            hdr = ps.read_upf_header(os.path.join(ps.DEST_DIR, fn))
            pseudo_info[t["symbol"]] = {
                "file": fn, "source": src,
                "type": hdr.get("pseudo_type", "?"),
                "z_valence": hdr.get("z_valence"),
            }
        familles = set(v["type"] for v in pseudo_info.values())
        if len(familles) > 1:
            self._warn("pseudos de familles mélangées (%s) — vérifiez la cohérence "
                       "PAW/USPP du calcul" % ", ".join(sorted(familles)))

        # --- coupures (suggestions UPF si non imposées)
        ecutwfc = o.get("ecutwfc")
        ecutrho = o.get("ecutrho")
        sug = [ps.suggest_cutoffs(os.path.join(ps.DEST_DIR, t["pseudo"]))
               for t in types]
        sug = [s for s in sug if s]
        if ecutwfc is None:
            ecutwfc = ceil(max(s[0] for s in sug)) if sug else 40.0
        if ecutrho is None:
            ecutrho = ceil(max([s[1] for s in sug] + [4.0 * ecutwfc])) if sug else 4.0 * ecutwfc
        if ecutrho < 4.0 * ecutwfc:
            ecutrho = 4.0 * ecutwfc

        # --- mailles k et q (défauts selon le type de matériau)
        kmesh = tuple(int(x) for x in (o.get("kmesh") or kind_defaults["kmesh"]))
        nq, warn = _divisors_ok(
            kmesh, tuple(int(x) for x in (o.get("nq") or kind_defaults["nq"])))
        if warn:
            self._warn("maille q ajustée pour rester commensurable avec k : %s" % (nq,))

        # --- état magnétique / occupations
        # Colinéaire : métal → smearing ; isolant/semi (+ mag) → scf2 fixed
        # Noncolin (nspin=4) : pas de scf2 tot_magnetization (spécifique nspin=2)
        scf2_needed = magnetic and kind != "metal" and not noncolin
        if noncolin:
            occ1 = "smearing" if kind == "metal" else (
                "smearing" if magnetic else "fixed")
            if kind != "metal" and magnetic:
                # petit smearing pour stabiliser NCL à gap (évite scf2 colinéaire)
                if o.get("degauss") is None and kind_defaults.get("degauss") is not None:
                    pass  # kind_defaults déjà utilisés plus bas
        else:
            occ1 = "smearing" if (magnetic and scf2_needed) else (
                "smearing" if kind == "metal" else "fixed")

        self.struct, self.types, self.magnetic = struct, types, magnetic
        self.pseudo_info = pseudo_info
        self.params = {
            "prefix": self.name,
            "pseudo_dir": ps.DEST_DIR + os.sep,
            "outdir": self.tmp_dir + os.sep,
            "ecutwfc": float(ecutwfc), "ecutrho": float(ecutrho),
            "kmesh": list(kmesh), "nq": list(nq),
            "magnetic": magnetic, "kind": kind, "scf2_needed": scf2_needed,
            "noncolin": bool(noncolin),
            "lspinorb": bool(o.get("lspinorb")),
            "occupations1": occ1,
            # Les clés existent toujours dans o (valeur None si non fournies) :
            # .get(k, defaut) renverrait None, il faut tester explicitement.
            "smearing": (o.get("smearing") if o.get("smearing") is not None
                         else kind_defaults["smearing"]),
            "degauss": float(o.get("degauss") if o.get("degauss") is not None
                             else kind_defaults["degauss"]),
            "conv_thr": float(o.get("conv_thr", 1.0e-10)),
            "conv_thr_tight": float(o.get("conv_thr_tight", 1.0e-15)),
            "u_source": o.get("u_source", "hp"),
            "u_explicit": o.get("u_map", {}),
            "skip_hp": bool(o.get("skip_hp")),
            "np": int(o.get("np", 4)),
            "structure": {"formula": struct.formula, "comment": struct.comment,
                          "nat": struct.nat, "volume": round(struct.volume, 4),
                          "source": o.get("structure"),
                          "formula_opt": o.get("formula")},
            "pseudos": pseudo_info,
        }
        h = _hash_params(self.params)
        if not dry_run:
            if self.state.get("params_hash") and self.state["params_hash"] != h:
                self._end("prepare", False,
                          "les paramètres du job %r ont changé — relancez avec --fresh "
                          "ou changez de nom" % self.name)
            self.state["params_hash"] = h
        self.state["params"] = self.params
        self._persist_opts()

        # --- fichiers d'entrée
        qein.dump_structure(struct, os.path.join(self.inp_dir, "structure.json"))
        base = dict(self.params)
        p1 = dict(base, stage="scf1", occupations=occ1,
                  nbnd=o.get("nbnd"),
                  tot_magnetization=None, use_file=False,
                  conv_thr=self.params["conv_thr"])
        self._write("scf1.in", qein.render_pw_input(struct, types, p1))
        if scf2_needed:
            r1 = (self.state.get("results") or {}).get("scf1") or {}
            p2 = dict(base, stage="scf2", occupations="fixed",
                      nbnd=r1.get("nbnd"),
                      tot_magnetization=r1.get("tot_magnetization_rounded"),
                      use_file=True, conv_thr=self.params["conv_thr_tight"])
            self._write("scf2.in", qein.render_pw_input(struct, types, p2))
        if not self.params["skip_hp"]:
            self._write("hp.in", qein.render_hp_input(base))
        self._write_run_meta()
        self._end("prepare", True, "entrées dans inputs/%s/" % self.name)
        return True

    def _write(self, fname, content):
        path = os.path.join(self.inp_dir, fname)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return path

    def _write_run_meta(self):
        meta = {"job": self.name, "created": _now(), "params": self.params,
                "types": [{k: v for k, v in t.items() if k != "mass"} for t in self.types],
                "sites": [{"label": s.label, "symbol": s.symbol,
                           "frac": [round(float(x), 10) for x in s.frac],
                           "mag": s.mag} for s in self.struct.sites]}
        with open(os.path.join(self.inp_dir, "job.json"), "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2, ensure_ascii=False)

    # ================================================== suite des étapes ==

    def _end_soft(self, step, detail):
        """Marque une étape dégradée sans interrompre le pipeline."""
        s = self.state["steps"].setdefault(step, {})
        s.update({"status": "soft_failed", "end": _now(),
                  "seconds": round(time.time() - s.get("t0", time.time()), 1),
                  "detail": detail})
        self._warn("%s : %s" % (step, detail))
        self._save()
        print("[%s] %s ÉCHEC (non bloquant) : %s" % (self.name, step, detail), flush=True)

    def step_scf1(self):
        if self._done("scf1"):
            return
        self._begin("scf1")
        rc = self._pw("scf1.in", "scf1.out")
        p = qeio.parse_pw(os.path.join(self.log_dir, "scf1.out"))
        if rc != 0 or p["energy_ry"] is None or not p["job_done"]:
            self._end("scf1", False, p.get("error") or "rc=%d" % rc)
        if p["converged"] is False:
            self._end("scf1", False, "SCF non convergé (conv_thr=%g)"
                      % self.params["conv_thr"])
        res = dict(p)
        res["rc"] = rc
        # tot_magnetization / scf2 : uniquement régime colinéaire (nspin=2)
        if self.magnetic and not self.params.get("noncolin"):
            if p["tot_magnetization"] is None:
                self._end("scf1", False, "total magnetization absente de la sortie")
            tm = float(p["tot_magnetization"])
            tm_r = float(round(tm))
            if abs(tm - tm_r) > 0.05:
                self._warn("tot_magnetization %.3f arrondie à %g (exigence occupations=fixed)"
                           % (tm, tm_r))
            res["tot_magnetization_rounded"] = tm_r
            if not p["nbnd"]:
                self._end("scf1", False, "nombre de Kohn-Sham states introuvable")
        self.state["results"]["scf1"] = res
        self._end("scf1", True, "E = %.6f Ry  M = %s" %
                  (p["energy_ry"], p["tot_magnetization"]))

    def step_scf2(self):
        pr = self.params
        if not pr["scf2_needed"]:
            if not self._done("scf2"):
                self.state["steps"]["scf2"] = {
                    "status": "skipped",
                    "detail": ("noncolin (nspin=4) — pas de scf2 colinéaire"
                               if pr.get("noncolin") else "non magnétique ou métal")}
                self._save()
            return
        if self._done("scf2"):
            return
        self._begin("scf2")
        r1 = self.state["results"].get("scf1") or {}
        nbnd, tm = r1.get("nbnd"), r1.get("tot_magnetization_rounded")
        if not nbnd or tm is None:
            self._end("scf2", False, "nbnd/tm absents (scf1 non exécuté ?)")
        p2 = dict(pr, stage="scf2", occupations="fixed", nbnd=int(nbnd),
                  tot_magnetization=tm, use_file=True,
                  conv_thr=pr["conv_thr_tight"])
        self._write("scf2.in", qein.render_pw_input(self.struct, self.types, p2))
        rc = self._pw("scf2.in", "scf2.out")
        p = qeio.parse_pw(os.path.join(self.log_dir, "scf2.out"))
        if rc != 0 or p["energy_ry"] is None or not p["job_done"]:
            self._end("scf2", False, p.get("error") or "rc=%d" % rc)
        if p["converged"] is False:
            self._end("scf2", False, "SCF non convergé (conv_thr=%g)"
                      % pr["conv_thr_tight"])
        res = dict(p)
        res["rc"] = rc
        self.state["results"]["scf2"] = res
        self._end("scf2", True, "E = %.6f Ry  M = %s" %
                  (p["energy_ry"], p["tot_magnetization"]))

    def step_hp(self):
        pr = self.params
        if pr["skip_hp"]:
            if not self._done("hp"):
                self.state["steps"]["hp"] = {"status": "skipped", "detail": "--skip-hp"}
                self._save()
            return
        if self._done("hp"):
            return
        self._begin("hp")
        hp_t0 = time.time()
        # Nettoyer d'éventuels fichiers Hubbard périmés (run + archives locales)
        hubbard_name = pr["prefix"] + ".Hubbard_parameters.dat"
        for stale in (
            os.path.join(self.run_dir, hubbard_name),
            os.path.join(self.tmp_dir, hubbard_name),
            os.path.join(self.log_dir, hubbard_name),
        ):
            if os.path.exists(stale):
                os.remove(stale)
        hubbard_archive = os.path.join(self.out_dir, "hubbard")
        if os.path.isdir(hubbard_archive):
            for fname in os.listdir(hubbard_archive):
                if fname.endswith("Hubbard_parameters.dat"):
                    try:
                        os.remove(os.path.join(hubbard_archive, fname))
                    except OSError:
                        pass
        hp_out = os.path.join(self.log_dir, "hp.out")
        rc = runner.run_code(
            "hp.x", os.path.join(self.inp_dir, "hp.in"),
            hp_out, np=pr["np"], cwd=self.run_dir,
            log=os.path.join(self.log_dir, "commands.log"))
        # Ne jamais lire un .dat archivé dans outputs/ (risque de U périmés)
        dat = qeio.find_hubbard_dat(
            pr["prefix"], self.run_dir, self.tmp_dir, self.log_dir,
            newer_than=hp_t0 - 1.0)
        hub = qeio.parse_hubbard_dat(dat) if dat else {"onsite": [], "pairs": []}
        u_map = qeio.u_by_label(hub)
        # Repli : tableau U imprimé dans hp.out (si .dat absent ou parse vide)
        if not u_map:
            hub = qeio.parse_hubbard_from_hp_out(hp_out)
            u_map = qeio.u_by_label(hub)
        res = {"rc": rc, "dat": dat if dat and os.path.exists(dat) else None,
               "onsite": hub["onsite"], "pairs": hub["pairs"], "u_hp": u_map}
        self.state["results"]["hp"] = res
        if rc != 0 or not u_map:
            detail = "hp.x rc=%d, %d paramètre(s) U lus" % (rc, len(u_map))
            if not dat:
                detail += " (fichier Hubbard_parameters.dat introuvable)"
            if pr["u_source"] == "hp":
                self._end("hp", False, detail + " — réessayez ou --skip-hp "
                          "--u-source literature --u SYM=valeur")
            self._end_soft("hp", detail)
            return
        bad = [k for k, v in u_map.items() if v <= 0]
        if bad:
            self._warn("U non positif pour : %s" % ", ".join(bad))
        self.state["results"]["hp"] = res
        self._end("hp", True, ", ".join("%s=%.4f eV" % kv for kv in sorted(u_map.items())))

    def _pw(self, infile, outfile):
        return runner.run_code(
            "pw.x", os.path.join(self.inp_dir, infile),
            os.path.join(self.log_dir, outfile),
            np=self.params["np"], cwd=self.run_dir,
            log=os.path.join(self.log_dir, "commands.log"))

    def _parse_pw(self, outfile):
        return qeio.parse_pw(os.path.join(self.log_dir, outfile))

    # ------------------------------------------------- résolution des U
    def resolve_u(self):
        """U par type (libellé) : --u explicite > hp.x > littérature."""
        pr = self.params
        hp_u = (self.state["results"].get("hp") or {}).get("u_hp") or {}
        explicit = pr.get("u_explicit") or {}
        src = pr.get("u_source", "hp")
        u_map, sources = {}, {}
        for t in self.types:
            if not t["hubbard"]:
                continue
            sym, lbl = t["symbol"], t["label"]
            lit = el.u_literature(sym)
            if sym in explicit:
                u_map[lbl], sources[lbl] = float(explicit[sym]), "--u"
            elif src == "hp" and lbl in hp_u:
                u_map[lbl], sources[lbl] = float(hp_u[lbl]), "hp.x"
            elif src == "hp":
                raise JobError(
                    "hp.x n'a pas produit de U pour %s (%s); aucune valeur de littérature ne sera substituée."
                    % (lbl, sym))
            elif src == "literature" and lit is not None:
                u_map[lbl], sources[lbl] = float(lit), "littérature"
            elif lbl in hp_u:
                u_map[lbl], sources[lbl] = float(hp_u[lbl]), "hp.x (repli)"
            elif lit is not None:
                u_map[lbl], sources[lbl] = float(lit), "littérature (repli)"
            else:
                raise JobError("aucune valeur de U pour %s (%s) — donnez-la : "
                               "--u %s=<eV>" % (lbl, sym, sym))
        return u_map, sources

    def step_scf_u(self):
        if self._done("scf_u"):
            return
        self._begin("scf_u")
        pr = self.params
        try:
            u_map, sources = self.resolve_u()
        except JobError as exc:
            self._end("scf_u", False, str(exc))
            return
        metal = pr["kind"] == "metal"
        occ = "smearing" if metal else "fixed"
        conv = pr["conv_thr_tight"] if occ == "fixed" else min(pr["conv_thr_tight"], 1.0e-12)
        nbnd = tm = None
        if self.magnetic and not metal:
            r2 = self.state["results"].get("scf2") or {}
            r1 = self.state["results"].get("scf1") or {}
            nbnd = r2.get("nbnd") or r1.get("nbnd")
            tm = r2.get("tot_magnetization_rounded")
            if tm is None:
                tm = r1.get("tot_magnetization_rounded")
            if tm is None and r2.get("tot_magnetization") is not None:
                tm = round(float(r2["tot_magnetization"]))
            if tm is None:
                self._end("scf_u", False, "scf2 absent (étape scf2 requise)")
                return
        pu = dict(pr, stage="scf_u", occupations=occ, nbnd=nbnd,
                  tot_magnetization=tm, use_file=True, conv_thr=conv, u_map=u_map)
        self._write("scf_u.in", qein.render_pw_input(self.struct, self.types, pu))
        rc = self._pw("scf_u.in", "scf_u.out")
        p = qeio.parse_pw(os.path.join(self.log_dir, "scf_u.out"))
        if rc != 0 or p["energy_ry"] is None or not p["job_done"]:
            self._end("scf_u", False, p.get("error") or "rc=%d" % rc)
        if p["converged"] is False:
            self._end("scf_u", False, "SCF DFT+U non convergé")
        res = dict(p)
        res["rc"] = rc
        res["u_map"] = u_map
        res["u_sources"] = sources
        self.state["results"]["scf_u"] = res
        self._end("scf_u", True, "E(DFT+U) = %.6f Ry" % p["energy_ry"])

    # ------------------------------------------------------- analyse
    def _summary(self):
        pr = self.params
        res = self.state["results"]
        r_dft = res.get("scf2") or res.get("scf1") or {}
        r_du = res.get("scf_u") or {}
        n_fu = self.struct.n_formula_units
        e_dft, e_du = r_dft.get("energy_ry"), r_du.get("energy_ry")
        delta = delta_fu = None
        if e_dft is not None and e_du is not None:
            delta = e_du - e_dft
            delta_fu = delta / n_fu * EV
        try:
            u_map, sources = self.resolve_u()
        except JobError:
            u_map, sources = {}, {}
        hp_u = (res.get("hp") or {}).get("u_hp") or {}
        u_rows = []
        for t in self.types:
            if not t["hubbard"]:
                continue
            u_rows.append({
                "label": t["label"], "element": t["symbol"],
                "manifold": t["manifold"],
                "U_hp_x": hp_u.get(t["label"]),
                "U_litterature": el.u_literature(t["symbol"]),
                "U_utilise": u_map.get(t["label"]),
                "source": sources.get(t["label"]),
            })
        return {
            "job": self.name, "cree": self.state["created"],
            "run_id": self.state.get("run_id"),
            "termine": _now(),
            "structure": pr["structure"],
            "parametres": {k: pr[k] for k in (
                "kind", "magnetic", "scf2_needed", "ecutwfc", "ecutrho",
                "kmesh", "nq", "degauss", "conv_thr", "conv_thr_tight",
                "u_source", "np")},
            "pseudos": pr["pseudos"],
            "etapes": self.state["steps"],
            "U": u_rows,
            "energies_Ry": {"scf1": res.get("scf1", {}).get("energy_ry"),
                            "scf2": res.get("scf2", {}).get("energy_ry"),
                            "scf_u": r_du.get("energy_ry"),
                            "delta_DFTU_minus_DFT": delta,
                            "delta_par_unite_formelle_eV": delta_fu},
            "magnetisation_bohr": {
                "scf1": res.get("scf1", {}).get("tot_magnetization"),
                "scf2": res.get("scf2", {}).get("tot_magnetization"),
                "scf_u": r_du.get("tot_magnetization")},
            "gap_eV": {"scf2": res.get("scf2", {}).get("gap_ev"),
                       "scf_u": r_du.get("gap_ev")},
            "fermi_eV": {"scf1": res.get("scf1", {}).get("fermi_ev"),
                         "scf2": res.get("scf2", {}).get("fermi_ev"),
                         "scf_u": r_du.get("fermi_ev")},
            "nb_iterations": {"scf1": res.get("scf1", {}).get("n_scf_iterations"),
                              "scf2": res.get("scf2", {}).get("n_scf_iterations"),
                              "scf_u": r_du.get("n_scf_iterations")},
            "avertissements": self.state["warnings"],
        }

    def _report(self, s):
        L = []
        L.append("Pipeline DFT+U — job %s" % s["job"])
        L.append("=" * 62)
        L.append("Structure : %s  (%s, %d atomes, %.3f Å³)"
                 % (s["structure"]["formula"],
                    (s["structure"].get("comment") or ""),
                    s["structure"]["nat"], s["structure"]["volume"]))
        p = s["parametres"]
        L.append("Réglages : ecutwfc=%g ecutrho=%g Ry, k=%s, q=%s, %s%s"
                 % (p["ecutwfc"], p["ecutrho"], "x".join(map(str, p["kmesh"])),
                    "x".join(map(str, p["nq"])), p["kind"],
                    ", magnétique" if p["magnetic"] else ""))
        L.append("")
        L.append("Étapes :")
        for k, v in s["etapes"].items():
            L.append("  %-8s %-8s %8s s  %s"
                     % (k, v.get("status", "?"), v.get("seconds", "-"),
                        v.get("detail", "")))
        L.append("")
        L.append("Pseudopotentiels :")
        for sym, info in s["pseudos"].items():
            L.append("  %-3s %-40s %-5s (%s)" %
                     (sym, info["file"], info.get("type", "?"), info.get("source", "")))
        L.append("")
        L.append("Paramètres de Hubbard U (eV) :")
        L.append("  %-6s %-6s %-8s %10s %12s %10s  %s"
                 % ("site", "élément", "canal", "hp.x", "littérature", "utilisé", "source"))
        for u in s["U"]:
            L.append("  %-6s %-6s %-8s %10s %12s %10s  %s" % (
                u["label"], u["element"], u["manifold"],
                ("%.4f" % u["U_hp_x"]) if u["U_hp_x"] is not None else "—",
                ("%.2f" % u["U_litterature"]) if u["U_litterature"] is not None else "—",
                ("%.4f" % u["U_utilise"]) if u["U_utilise"] is not None else "—",
                u["source"] or "—"))
        L.append("")
        e = s["energies_Ry"]
        L.append("Énergies (Ry) :")
        L.append("  DFT  (scf%s) = %s" % ("2" if e["scf2"] is not None else "1",
                                          "%.6f" % e["scf2"] if e["scf2"] is not None
                                          else ("%.6f" % e["scf1"] if e["scf1"] is not None else "—")))
        L.append("  DFT+U       = %s" % ("%.6f" % e["scf_u"] if e["scf_u"] is not None else "—"))
        if e["delta_par_unite_formelle_eV"] is not None:
            L.append("  ΔE(DFT+U − DFT) = %.6f Ry  (%.4f eV/unité formelle)"
                     % (e["delta_DFTU_minus_DFT"], e["delta_par_unite_formelle_eV"]))
        L.append("")
        L.append("Magnétisation totale (μB/cellule) : scf1=%s  scf2=%s  scf_u=%s"
                 % (s["magnetisation_bohr"]["scf1"], s["magnetisation_bohr"]["scf2"],
                    s["magnetisation_bohr"]["scf_u"]))
        L.append("Gap (eV) : scf2=%s   scf_u=%s"
                 % (s["gap_eV"]["scf2"], s["gap_eV"]["scf_u"]))
        if s["avertissements"]:
            L.append("")
            L.append("Avertissements :")
            for w in s["avertissements"]:
                L.append("  - %s" % w)
        return "\n".join(L) + "\n"

    def step_analyse(self):
        if self._done("analyse"):
            return
        if not self._done("scf_u"):
            raise JobError(
                "analyse impossible : le SCF DFT+U doit être terminé avant de produire un résultat final")
        self._begin("analyse")
        try:
            summary = self._summary()
        except Exception as exc:
            self._end("analyse", False, repr(exc))
            return
        with open(os.path.join(self.out_dir, "résumé.json"), "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2, ensure_ascii=False)
        with open(os.path.join(self.out_dir, "rapport.txt"), "w", encoding="utf-8") as f:
            f.write(self._report(summary))

        archive_dirs = {
            "inputs": os.path.join(self.out_dir, "entrees"),
            "logs": os.path.join(self.out_dir, "journaux"),
            "hubbard": os.path.join(self.out_dir, "hubbard"),
        }
        for directory in archive_dirs.values():
            os.makedirs(directory, exist_ok=True)

        artifacts = ["résumé.json", "rapport.txt"]
        for step in ("scf1", "scf2", "hp", "scf_u"):
            src = os.path.join(self.log_dir, step + ".out")
            if os.path.exists(src):
                relative = os.path.join("journaux", step + ".out")
                shutil.copy2(src, os.path.join(self.out_dir, relative))
                artifacts.append(relative.replace(os.sep, "/"))
        for f_ in ("scf1.in", "scf2.in", "hp.in", "scf_u.in", "structure.json"):
            src = os.path.join(self.inp_dir, f_)
            if os.path.exists(src):
                relative = os.path.join("entrees", f_)
                shutil.copy2(src, os.path.join(self.out_dir, relative))
                artifacts.append(relative.replace(os.sep, "/"))
        dat = (self.state["results"].get("hp") or {}).get("dat")
        if dat and os.path.exists(dat):
            relative = os.path.join("hubbard", os.path.basename(dat))
            shutil.copy2(dat, os.path.join(self.out_dir, relative))
            artifacts.append(relative.replace(os.sep, "/"))

        manifest = {
            "job": self.name,
            "run_id": self.state.get("run_id"),
            "structure": summary["structure"],
            "resume": "résumé.json",
            "rapport": "rapport.txt",
            "dossiers": {
                "entrees/": "Entrées QE et structure utilisées pour le calcul.",
                "journaux/": "Sorties brutes de pw.x et hp.x.",
                "hubbard/": "Paramètres U produits par hp.x.",
                "runtime": "jobs/%s/ contient l’état, les journaux live et les fichiers temporaires QE." % self.name,
            },
            "fichiers": artifacts,
        }
        with open(os.path.join(self.out_dir, "index.json"), "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2, ensure_ascii=False)
        with open(os.path.join(self.out_dir, "LISEZ-MOI.txt"), "w", encoding="utf-8") as f:
            f.write("Résultats du job %s\n" % self.name)
            f.write("==============================\n\n")
            f.write("résumé.json : résultats structurés pour traitement automatique.\n")
            f.write("rapport.txt : synthèse lisible du calcul et de ses résultats.\n")
            f.write("entrees/ : entrées QE et structure effectivement utilisées.\n")
            f.write("journaux/ : sorties détaillées de pw.x et hp.x.\n")
            f.write("hubbard/ : fichier Hubbard_parameters.dat calculé par hp.x.\n")
            f.write("jobs/%s/ : fichiers temporaires et état technique du job.\n" % self.name)
        self._end("analyse", True, "outputs/%s/" % self.name)

    # ------------------------------------------------------------ lancement
    def run(self, dry_run=False, steps=None, np_=None, resume=False):
        if resume:
            # Les options enregistrées priment sur la ligne de commande (elles
            # définissent le job) ; seul --np peut être surchargé à la reprise.
            if self.state.get("opts"):
                merged = dict(self.state["opts"])
                # Reprise CLI sans --structure : ne pas écraser par null
                for key, value in self.opts.items():
                    if value is None or value == {} or value == []:
                        continue
                    if key in {"structure", "formula"} and merged.get(key):
                        continue
                    merged[key] = value
                self.opts = merged
            if np_:
                self.opts["np"] = int(np_)
            # Reconstituer structure depuis params si opts incomplets
            params_struct = (self.state.get("params") or {}).get("structure") or {}
            if not self.opts.get("structure") and params_struct.get("source"):
                self.opts["structure"] = params_struct["source"]
            if not self.opts.get("formula") and params_struct.get("formula_opt"):
                self.opts["formula"] = params_struct["formula_opt"]
            self._persist_opts()
            if self.state.get("params") and self._done("prepare"):
                self._restore_for_resume()
                if np_:
                    self.params["np"] = int(np_)
            elif self.state.get("params") and not self._done("prepare"):
                # Anciens jobs / état prepare perdu : restaurer si métadonnées OK
                try:
                    self._restore_for_resume()
                    if np_:
                        self.params["np"] = int(np_)
                    prev = (self.state.get("steps") or {}).get("prepare") or {}
                    self.state.setdefault("steps", {})["prepare"] = {
                        "status": "done",
                        "detail": prev.get("detail") or "entrées déjà présentes",
                    }
                    self._save()
                except JobError:
                    self.prepare(dry_run=False)
            else:
                # Préparation interrompue avant l'enregistrement des paramètres :
                # on la rejoue intégralement (valable pour toute source/tout type).
                self.prepare(dry_run=False)
        else:
            if np_:
                self.opts["np"] = int(np_)
            self.prepare(dry_run=dry_run)
        # Si prepare a disparu du state alors que les entrées existent, le rétablir
        if (self.state.get("params") and not self._done("prepare")
                and os.path.isfile(os.path.join(self.inp_dir, "job.json"))):
            self.state.setdefault("steps", {})["prepare"] = {
                "status": "done", "detail": "entrées déjà présentes"}
            self._save()
        if dry_run:
            print("[dry-run] entrées générées dans %s :" % self.inp_dir)
            for f in sorted(os.listdir(self.inp_dir)):
                print("   ", f)
            print("[dry-run] aucun téléchargement UPF ni params_hash verrouillant ;")
            if self.params.get("noncolin"):
                print("[dry-run] noncolin (nspin=4) : pas de scf2 colinéaire ;")
            elif self.params.get("scf2_needed"):
                print("[dry-run] scf2.in sera complété (nbnd, tot_magnetization) après scf1 ;")
            else:
                print("[dry-run] scf2.in non requis (NM ou métal) ;")
            print("[dry-run] scf_u.in sera généré avec les U de hp.x.")
            return
        wanted = steps or ["scf1", "scf2", "hp", "scf_u", "analyse"]
        unknown = set(wanted) - set(STEPS[1:])
        if unknown:
            raise JobError("étapes inconnues : %s" % ", ".join(sorted(unknown)))
        prerequisites = {
            "scf1": ("prepare",),
            "scf2": ("prepare", "scf1"),
            "hp": ("prepare", "scf1", "scf2"),
            "scf_u": ("prepare", "scf1", "scf2", "hp"),
            "analyse": ("prepare", "scf1", "scf2", "hp", "scf_u"),
        }
        for s in ("scf1", "scf2", "hp", "scf_u", "analyse"):
            if s in wanted:
                required = list(prerequisites[s])
                if not self.params["scf2_needed"]:
                    required = [step for step in required if step != "scf2"]
                if self.params["skip_hp"]:
                    required = [step for step in required if step != "hp"]
                # prepare est toujours exigé mais hors « wanted » explicite
                missing = [step for step in required
                           if not self._done(step)
                           and step not in wanted and step != "prepare"]
                if "prepare" in required and not self._done("prepare"):
                    missing = ["prepare"] + missing
                if missing:
                    raise JobError("étape %s impossible avant : %s" % (s, ", ".join(missing)))
                getattr(self, "step_" + s)()

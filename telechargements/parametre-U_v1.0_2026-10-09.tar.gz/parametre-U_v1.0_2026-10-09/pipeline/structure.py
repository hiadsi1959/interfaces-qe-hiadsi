"""Construction de la structure : fichier ASE ou prototype (bulk), magnétisme,
ordre des sites (corrélés d'abord — exigence de hp.x) et libellés de types.

Convention de libellés (identique aux exemples QE HP) :
  * un seul groupe par symbole            -> « Ni », « O »
  * plusieurs groupes (aims différentes)  -> « Ni1 », « Ni2 »
hp.x exige que les sites avec Hubbard_U != 0 soient listés EN PREMIER dans
ATOMIC_POSITIONS (voir HP/examples/README).
"""
import os
from collections import OrderedDict

import numpy as np

from . import elements as el

AFM_TOL = 0.10  # Å : tolérance de regroupement des plans pour --afm


class StructError(ValueError):
    pass


class Site(object):
    def __init__(self, symbol, frac, mag=None, label=None):
        self.symbol = symbol
        self.frac = np.asarray(frac, dtype=float)
        self.mag = mag          # starting_magnetization (ou None si non magnétique)
        self.label = label      # libellé de type QE (Ni1, O, ...)

    @property
    def hubbard(self):
        return el.is_correlated(self.symbol)

    @property
    def manifold(self):
        return el.manifold(self.symbol)

    @property
    def mass(self):
        return el.mass(self.symbol)


class Struct(object):
    def __init__(self, cell, sites, comment=""):
        self.cell = np.asarray(cell, dtype=float)   # Å (3×3, lignes = vecteurs)
        self.sites = list(sites)
        self.comment = comment
        site_counts = {}
        for site in self.sites:
            site_counts[site.symbol] = site_counts.get(site.symbol, 0) + 1
            site.site_index = site_counts[site.symbol]

    @property
    def formula(self):
        counts = OrderedDict()
        for s in self.sites:
            counts[s.symbol] = counts.get(s.symbol, 0) + 1
        return "".join("%s%s" % (k, v if v > 1 else "") for k, v in counts.items())

    @property
    def nat(self):
        return len(self.sites)

    @property
    def n_formula_units(self):
        """Nombre d'unités formelles pour AxBx... (plus petit entier des stœchiométries)."""
        counts = OrderedDict()
        for s in self.sites:
            counts[s.symbol] = counts.get(s.symbol, 0) + 1
        from math import gcd
        g = 0
        for v in counts.values():
            g = gcd(g, v)
        return max(g, 1)

    def cart(self, site):
        return site.frac @ self.cell

    @property
    def volume(self):
        return abs(float(np.linalg.det(self.cell)))


def _from_atoms(atoms, comment="", mags=None):
    symbols = atoms.get_chemical_symbols()
    fracs = atoms.get_scaled_positions()
    sites = []
    for i, (symbol, frac) in enumerate(zip(symbols, fracs)):
        mag = mags[i] if mags is not None and i < len(mags) else None
        sites.append(Site(symbol, frac, mag=mag))
    return Struct(np.array(atoms.get_cell()), sites, comment)


def repeat_struct(struct, supercell):
    """Réplique la maille en conservant les aimantations des sites d'origine."""
    if not supercell:
        return struct
    try:
        nx, ny, nz = (int(v) for v in supercell)
    except (TypeError, ValueError) as exc:
        raise StructError("supercellule invalide : %s" % (supercell,)) from exc
    if min(nx, ny, nz) < 1:
        raise StructError("supercellule : chaque dimension doit être >= 1")
    from ase import Atoms
    atoms = Atoms(
        symbols=[s.symbol for s in struct.sites],
        scaled_positions=[s.frac for s in struct.sites],
        cell=struct.cell, pbc=True,
    )
    atoms = atoms.repeat((nx, ny, nz))
    n0 = len(struct.sites)
    # Ordre ASE repeat : pour chaque cellule (ix,iy,iz), tous les atomes d'origine.
    mags = [struct.sites[i % n0].mag for i in range(len(atoms))]
    return _from_atoms(atoms, struct.comment, mags=mags)


def load_file(path, supercell=None):
    if not os.path.exists(path):
        raise StructError("fichier de structure introuvable: %s" % path)
    # Fichiers QE « {matériau}-scf.in » (ibrav/celldm non lus par ASE)
    base = os.path.basename(path).lower()
    if base.endswith("-scf.in") or base.endswith(".scf.in") or (
            base.endswith(".in") and ("scf" in base or "pw" in base)):
        from .qe_scf import parse_scf_in
        data = parse_scf_in(path)
        struct = data["struct"]
        if supercell:
            return repeat_struct(struct, supercell)
        return struct
    from ase.io import read as ase_read
    atoms = ase_read(path, index=0)
    struct = _from_atoms(atoms, os.path.basename(path))
    if supercell:
        return repeat_struct(struct, supercell)
    return struct


def build_bulk(formula, prototype, a=None, c=None, ca=None, u=None, supercell=None):
    from ase.build import bulk as ase_bulk
    kw = {}
    # ASE attend covera (rapport c/a) : --ca / ca reste le nom d'entrée.
    for k, v in (("a", a), ("c", c), ("covera", ca), ("u", u)):
        if v is not None:
            kw[k] = v
    try:
        atoms = ase_bulk(formula, prototype, **kw)
    except Exception as exc:
        raise StructError(
            "prototype %r invalide pour %s (%s). Utilisez --structure <fichier>."
            % (prototype, formula, exc)
        )
    struct = _from_atoms(atoms, "%s/%s" % (formula, prototype))
    if supercell:
        return repeat_struct(struct, supercell)
    return struct


# ---------------------------------------------------------------- magnétisme

def _magnetic_symbols(mode):
    """Symboles à traiter comme magnétiques selon le mode."""
    els = el.load_elements()
    if mode == "off":
        return set()
    out = set()
    # noncolin = aimantation initiale comme « on », puis noncolin=.true. dans pw.x
    force_on = mode in {"on", "noncolin"}
    for sym, e in els.items():
        if not e.get("correlated") or not e.get("manifold"):
            continue
        if force_on or e.get("magnetic_default"):
            out.add(sym)
    return out


def assign_magnetism(struct, mode="auto", afm_axis=None, mag_spec=None, start_mag=0.5):
    """Fixe site.mag pour chaque site.

    mode       : 'auto' | 'on' | 'off' | 'noncolin'
                 (noncolin = moments initiaux comme on ; le flag QE noncolin
                 est géré côté génération d'entrées)
    afm_axis   : None (ferromagnétique) ou 0/1/2 ('x'/'y'/'z') -> plans alternés +/-
    mag_spec   : dict {'Ni': 0.5, 'Ni2': -0.5, 'O1': 0.0} — prioritaire
                 (suffixe numérique = index 1-based du site dans le symbole)
    Retourne le nombre de sites magnétiques.
    """
    magsyms = _magnetic_symbols(mode)
    magnetic = [s for s in struct.sites if s.symbol in magsyms]
    if not magnetic or mode == "off":
        for s in struct.sites:
            s.mag = None
        return 0

    # Conserver les aimantations déjà lues depuis un *-scf.in (AFM/FM)
    # lorsque magnetic=auto et qu'aucune surcharge CLI n'est fournie.
    if (mode == "auto" and mag_spec is None and afm_axis is None
            and any(s.mag is not None for s in magnetic)):
        for s in struct.sites:
            if s.symbol not in magsyms:
                s.mag = None
        return sum(1 for s in struct.sites if s.mag is not None)

    if mag_spec:
        by_sym = OrderedDict()
        for s in struct.sites:
            by_sym.setdefault(s.symbol, []).append(s)
        for key, val in mag_spec.items():
            m = _split_key(key)
            if m[0] not in by_sym:
                raise StructError("--mag: symbole inconnu %r" % m[0])
            sites = by_sym[m[0]]
            if m[1] is None:
                for s in sites:
                    s.mag = float(val)
            else:
                if m[1] < 1 or m[1] > len(sites):
                    raise StructError("--mag: %s n'a que %d site(s)" % (key, len(sites)))
                sites[m[1] - 1].mag = float(val)
        for s in struct.sites:
            if s.symbol in magsyms and s.mag is None:
                s.mag = 0.0
        return sum(1 for s in struct.sites if s.mag is not None)

    if afm_axis is None:
        for s in struct.sites:
            s.mag = start_mag if s.symbol in magsyms else None
        return len(magnetic)

    # plans AFM : regroupement 1D de la coordonnée cartésienne de l'axe choisi
    axis = {"x": 0, "y": 1, "z": 2}.get(str(afm_axis))
    if axis is None:
        axis = int(afm_axis)
    vals = sorted(struct.cart(s)[axis] for s in magnetic)
    centers = []
    for v in vals:
        if not centers or abs(v - centers[-1][0]) > AFM_TOL:
            centers.append([v, 1])
        else:
            centers[-1][0] = (centers[-1][0] * centers[-1][1] + v) / (centers[-1][1] + 1)
            centers[-1][1] += 1
    if len(centers) < 2:
        raise StructError(
            "--afm : un seul plan magnétique le long de l'axe %s — agrandissez la "
            "maille (--supercell) ou précisez --mag" % "xyz"[axis]
        )
    plane_z = [c[0] for c in centers]
    for s in struct.sites:
        if s.symbol not in magsyms:
            s.mag = None
            continue
        z = struct.cart(s)[axis]
        i = int(np.argmin([abs(z - pz) for pz in plane_z]))
        s.mag = start_mag if i % 2 == 0 else -start_mag
    return len(magnetic)


def _split_key(key):
    """'Ni2' -> ('Ni', 2) ; 'O' -> ('O', None)."""
    m = _re_match(key)
    return m


import re as _re
_key_re = _re.compile(r"^([A-Z][a-z]?)(\d+)$")


def _re_match(key):
    m = _key_re.match(key)
    if m:
        return m.group(1), int(m.group(2))
    if _re.match(r"^[A-Z][a-z]?$", key):
        return key, None
    raise StructError("--mag: clé invalide %r (attendu 'Ni' ou 'Ni2')" % key)


# ------------------------------------------------------- libellés et ordre

def finalize(struct, site_groups=None, hubbard_elements=None):
    """Réordonne les sites (corrélés d'abord) et attribue les libellés de types.

    Retourne la liste ordonnée des types : [{'label','symbol','mag','mass',
    'hubbard','manifold'}].
    """
    # 1. sites corrélés (avec U) d'abord — exigence de hp.x
    selected = set(hubbard_elements) if hubbard_elements is not None else None
    is_hubbard = lambda site: site.hubbard and (selected is None or site.symbol in selected)
    struct.sites.sort(key=lambda s: 0 if is_hubbard(s) else 1)

    # 2. Valider les groupes locaux facultatifs (indices 1-based par élément).
    group_by_site = {}
    if site_groups is not None:
        correlated_symbols = {s.symbol for s in struct.sites if is_hubbard(s)}
        if set(site_groups) != correlated_symbols:
            raise StructError(
                "site_groups doit décrire chaque élément corrélé : %s"
                % ", ".join(sorted(correlated_symbols))
            )
        for symbol, groups in site_groups.items():
            expected = {s.site_index for s in struct.sites
                        if s.symbol == symbol and is_hubbard(s)}
            assigned = set()
            for group_index, indices in enumerate(groups, start=1):
                if not indices:
                    raise StructError("site_groups.%s contient un groupe vide" % symbol)
                for index in indices:
                    if index in assigned:
                        raise StructError("site %s%d apparaît plusieurs fois" % (symbol, index))
                    assigned.add(index)
                    group_by_site[(symbol, index)] = group_index
            if assigned != expected:
                raise StructError(
                    "site_groups.%s doit couvrir exactement les sites %s"
                    % (symbol, ", ".join(map(str, sorted(expected))))
                )

    # 3. libellés : regroupement par élément, aimantation et environnement local
    labels = {}
    types = OrderedDict()
    for s in struct.sites:
        local_group = group_by_site.get((s.symbol, s.site_index))
        key = (s.symbol, None if s.mag is None else round(s.mag, 6), local_group)
        if key not in labels:
            labels[key] = None  # attribué ci-dessous
        s._grp = key
    per_sym = OrderedDict()
    for s in struct.sites:
        per_sym.setdefault(s.symbol, [])
        if s._grp not in per_sym[s.symbol]:
            per_sym[s.symbol].append(s._grp)
    for sym, groups in per_sym.items():
        multi = len(groups) > 1
        for i, g in enumerate(groups):
            labels[g] = "%s%d" % (sym, i + 1) if multi else sym
    for s in struct.sites:
        s.label = labels[s._grp]
        if s.label not in types:
            types[s.label] = {
                "label": s.label,
                "symbol": s.symbol,
                "mag": s.mag,
                "mass": s.mass,
                "hubbard": is_hubbard(s) and s.manifold is not None,
                "manifold": s.manifold,
            }
    # un type « corrélé » doit porter un U > 0 sinon on le traite comme partenaire
    for t in types.values():
        if t["hubbard"] and not el.is_correlated(t["symbol"]):
            t["hubbard"] = False
    return list(types.values())

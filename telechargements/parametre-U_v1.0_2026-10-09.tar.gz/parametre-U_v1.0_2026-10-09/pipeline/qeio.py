"""Analyse des sorties QE : pw.x (scf) et *.Hubbard_parameters.dat (hp.x)."""
import os
import re

_PW_NUM = r"[-+]?\d*\.?\d+(?:[eEdD][-+]?\d+)?"


def _fnum(value):
    return float(str(value).replace("d", "e").replace("D", "E"))


def _read_log_text(path, head=16000, tail=1200000):
    """Lit un journal QE : entier si petit, sinon tête + queue (suivi live)."""
    size = os.path.getsize(path)
    with open(path, "rb") as handle:
        if size <= head + tail:
            return handle.read().decode("utf-8", errors="ignore")
        head_txt = handle.read(head).decode("utf-8", errors="ignore")
        handle.seek(max(0, size - tail))
        handle.readline()  # éviter une ligne tronquée
        tail_txt = handle.read().decode("utf-8", errors="ignore")
        return head_txt + "\n" + tail_txt


def parse_pw(path):
    """Extrait l'essentiel d'une sortie pw.x."""
    out = {
        "job_done": False, "converged": None, "energy_ry": None,
        "nbnd": None, "tot_magnetization": None, "fermi_ev": None,
        "homo_lumo_ev": None, "gap_ev": None, "error": None,
        "n_scf_iterations": None,
    }
    if not os.path.exists(path):
        out["error"] = "sortie absente"
        return out
    with open(path, encoding="utf-8", errors="ignore") as f:
        txt = f.read()

    out["job_done"] = "JOB DONE." in txt
    m = re.search(r"number of Kohn-Sham states\s*=\s*(\d+)", txt)
    if m:
        out["nbnd"] = int(m.group(1))
    energies = re.findall(
        r"^!\s+total energy\s+=\s+(%s)\s+Ry" % _PW_NUM, txt, re.M)
    if energies:
        out["energy_ry"] = _fnum(energies[-1])
    mags = re.findall(
        r"total magnetization\s+=\s+(%s)\s+Bohr mag/cell" % _PW_NUM, txt)
    if mags:
        out["tot_magnetization"] = _fnum(mags[-1])
    m = re.search(r"the Fermi energy is\s+(%s)\s*ev" % _PW_NUM, txt)
    if m:
        out["fermi_ev"] = _fnum(m.group(1))
    m = re.search(
        r"highest occupied, lowest unoccupied level \(ev\):\s+(%s)\s+(%s)"
        % (_PW_NUM, _PW_NUM), txt
    )
    if m:
        homo = _fnum(m.group(1))
        lumo = _fnum(m.group(2))
        out["homo_lumo_ev"] = [homo, lumo]
        out["gap_ev"] = lumo - homo
    if "convergence NOT achieved" in txt:
        out["converged"] = False
        out["error"] = "convergence NOT achieved"
    elif out["energy_ry"] is not None and out["job_done"]:
        out["converged"] = True
    if not out["job_done"] and out["error"] is None:
        m = re.search(r"^Error in routine.*$", txt, re.M)
        out["error"] = m.group(0).strip() if m else "pas de JOB DONE"
    iters = re.findall(r"iteration #\s*(\d+)", txt)
    if iters:
        out["n_scf_iterations"] = int(iters[-1])
    return out


def parse_scf_progress(path, history_limit=80):
    """Suivi de convergence SCF depuis une sortie pw.x (live ou terminée)."""
    out = {
        "kind": "scf",
        "available": False,
        "conv_thr": None,
        "iteration": None,
        "n_iterations": 0,
        "energy_ry": None,
        "accuracy_ry": None,
        "converged": None,
        "job_done": False,
        "history": [],
        "message": None,
    }
    if not path or not os.path.isfile(path):
        out["message"] = "journal absent"
        return out
    try:
        txt = _read_log_text(path)
    except OSError as exc:
        out["message"] = str(exc)
        return out

    out["job_done"] = "JOB DONE." in txt
    m = re.search(r"conv_thr\s*=\s*(%s)" % _PW_NUM, txt)
    if m:
        out["conv_thr"] = _fnum(m.group(1))

    history = []
    for block in re.split(r"(?=^\s*iteration #\s*\d+)", txt, flags=re.M):
        m = re.match(r"\s*iteration #\s*(\d+)", block)
        if not m:
            continue
        n = int(m.group(1))
        energy = None
        acc = None
        em = re.search(
            r"^\s*!?\s*total energy\s+=\s+(%s)\s+Ry" % _PW_NUM, block, re.M)
        if em:
            energy = _fnum(em.group(1))
        am = re.search(
            r"estimated scf accuracy\s+<\s+(%s)" % _PW_NUM, block)
        if am:
            acc = _fnum(am.group(1))
        if energy is None and acc is None:
            # itération démarrée mais pas encore de résumé
            history.append({"n": n, "energy_ry": None, "accuracy_ry": None})
            continue
        history.append({"n": n, "energy_ry": energy, "accuracy_ry": acc})

    if history:
        out["available"] = True
        out["n_iterations"] = len(history)
        out["iteration"] = history[-1]["n"]
        out["history"] = history[-history_limit:]
        last = next(
            (row for row in reversed(history)
             if row.get("energy_ry") is not None or row.get("accuracy_ry") is not None),
            history[-1])
        out["energy_ry"] = last.get("energy_ry")
        out["accuracy_ry"] = last.get("accuracy_ry")

    if "convergence NOT achieved" in txt:
        out["converged"] = False
        out["message"] = "convergence NOT achieved"
    elif "convergence has been achieved" in txt or (
            out["job_done"] and out["energy_ry"] is not None):
        out["converged"] = True
        out["message"] = "convergence atteinte"
    elif out["available"]:
        thr = out["conv_thr"]
        acc = out["accuracy_ry"]
        if thr and acc is not None and acc <= thr:
            out["converged"] = True
            out["message"] = "seuil conv_thr atteint"
        else:
            out["converged"] = False
            out["message"] = "SCF en cours"
    elif out["job_done"]:
        out["available"] = True
        out["message"] = "JOB DONE"
    else:
        out["message"] = "démarrage / initialisation QE"
    return out


def parse_hp_progress(path):
    """Suivi approximatif de hp.x (points q / perturbations)."""
    out = {
        "kind": "hp",
        "available": False,
        "q_done": None,
        "q_total": None,
        "job_done": False,
        "message": None,
    }
    if not path or not os.path.isfile(path):
        out["message"] = "journal absent"
        return out
    try:
        txt = _read_log_text(path)
    except OSError as exc:
        out["message"] = str(exc)
        return out

    out["job_done"] = "JOB DONE." in txt
    # Formats usuels hp.x / DFPT
    matches = re.findall(
        r"(?:q[- ]?point|q point)\s*#?\s*(\d+)\s*(?:of|/)\s*(\d+)",
        txt, re.I)
    if matches:
        out["available"] = True
        out["q_done"] = int(matches[-1][0])
        out["q_total"] = int(matches[-1][1])
        out["message"] = "point q %d / %d" % (out["q_done"], out["q_total"])
    else:
        pert = len(re.findall(r"Perturbing\b|RESPONSE\b", txt, re.I))
        if pert:
            out["available"] = True
            out["q_done"] = pert
            out["message"] = "%d réponse(s) DFPT détectée(s)" % pert
    if out["job_done"]:
        out["available"] = True
        out["message"] = "hp.x terminé" if not out["message"] else out["message"] + " · terminé"
    elif not out["available"]:
        out["message"] = "hp.x en initialisation"
    return out


_NUM = r"[-+]?\d*\.?\d+(?:[eEdD][-+]?\d+)?"
# QE ≤7.x : site type label spin new_type new_label U
# QE 7.5+ : site type label spin new_type new_label manifold U
_ONSITE_RE = re.compile(
    r"^\s*(\d+)\s+(\d+)\s+(\S+)\s+([-+]?\d+)\s+(\d+)\s+(\S+)"
    r"(?:\s+(\S+))?\s+(%s)\s*$" % _NUM
)


def _parse_hubbard_lines(lines):
    res = {"onsite": [], "pairs": []}
    for ln in lines:
        m = _ONSITE_RE.match(ln)
        if not m:
            continue
        site, typ, label, spin, _ntyp2, nlabel, manifold_or_u, maybe_u = m.groups()
        # Sans colonne manifold : group7 = U (ou None si seul group8), group8 = U
        # Avec manifold : group7 = "3d", group8 = U
        if maybe_u is None:
            if manifold_or_u is None:
                continue
            manifold, u = None, manifold_or_u
        elif manifold_or_u is None:
            manifold, u = None, maybe_u
        else:
            try:
                float(str(manifold_or_u).replace("d", "e").replace("D", "E"))
                manifold, u = None, manifold_or_u
            except ValueError:
                manifold, u = manifold_or_u, maybe_u
        row = {
            "site": int(site), "type": int(typ), "label": label,
            "spin": int(spin), "new_label": nlabel,
            "manifold": manifold,
            "U": float(u.replace("d", "e").replace("D", "E")),
        }
        if label == nlabel:
            res["onsite"].append(row)
        else:
            res["pairs"].append(row)
    return res


def parse_hubbard_dat(path):
    """Parse <prefix>.Hubbard_parameters.dat (écrit par hp.x dans le CWD).

    Retourne {'onsite': [{site,type,label,spin,new_label,U}], 'pairs': [...]}.
    """
    if not path or not os.path.exists(path):
        return {"onsite": [], "pairs": []}
    with open(path, encoding="utf-8", errors="ignore") as f:
        return _parse_hubbard_lines(f.readlines())


def parse_hubbard_from_hp_out(path):
    """Repli : extrait le tableau Hubbard U depuis la sortie hp.x."""
    if not path or not os.path.exists(path):
        return {"onsite": [], "pairs": []}
    with open(path, encoding="utf-8", errors="ignore") as f:
        txt = f.read()
    # Prendre le dernier bloc « Hubbard U parameters »
    parts = re.split(r"Hubbard U parameters\s*:", txt)
    if len(parts) < 2:
        return {"onsite": [], "pairs": []}
    block = parts[-1]
    end = re.search(r"=-+|\n\s*Hubbard V parameters|\n\s*chi0 matrix", block)
    if end:
        block = block[:end.start()]
    return _parse_hubbard_lines(block.splitlines())


def find_hubbard_dat(prefix, *roots, newer_than=None):
    """Cherche <prefix>.Hubbard_parameters.dat sous les racines données.

    newer_than : horodatage Unix minimal (évite de réutiliser un .dat d’un run précédent).
    """
    name = prefix + ".Hubbard_parameters.dat"
    candidates = []
    for root in roots:
        if not root:
            continue
        direct = os.path.join(root, name)
        if os.path.isfile(direct):
            candidates.append(direct)
        if os.path.isdir(root):
            for dirpath, _dirs, files in os.walk(root):
                if name in files:
                    candidates.append(os.path.join(dirpath, name))
    if newer_than is not None:
        candidates = [p for p in candidates if os.path.getmtime(p) >= newer_than]
    # Préférer le plus récemment modifié
    candidates = sorted(set(candidates), key=lambda p: os.path.getmtime(p), reverse=True)
    return candidates[0] if candidates else None


def u_by_label(hubbard):
    """U moyen par libellé de type (hp.x peut donner plusieurs sites/types).

    Priorité aux lignes onsite ; les pairs ne complètent que les libellés
    absents (évite de biaiser Ni1/Ni2 AFM en moyennant onsite+pairs).
    """
    acc = {}
    for row in hubbard.get("onsite", []):
        acc.setdefault(row["label"], []).append(row["U"])
    for row in hubbard.get("pairs", []):
        for key in (row.get("label"), row.get("new_label")):
            if key and key not in acc:
                acc.setdefault(key, []).append(row["U"])
    return {k: sum(v) / len(v) for k, v in acc.items()}

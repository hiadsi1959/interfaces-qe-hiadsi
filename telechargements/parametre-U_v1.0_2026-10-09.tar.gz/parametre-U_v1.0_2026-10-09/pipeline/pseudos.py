"""Résolution des pseudopotentiels pslibrary : local -> autre dépôt local -> téléchargement.

Priorité identique à tools/build_elements.py : PAW (kjpaw) d'abord, sinon USPP
(rrkjus). Vérification systématique de l'élément déclaré dans l'enête UPF.
"""
import os
import re
import shutil
import urllib.request

from . import elements as el

ROOT = el.ROOT
DEST_DIR = os.path.join(ROOT, "pseudo")

# Serveurs officiels (sondage HEAD du 07/10 : pseudopotentials.quantum-espresso.org)
BASE_URLS = [
    "https://pseudopotentials.quantum-espresso.org/upf_files/",
    "https://www.quantum-espresso.org/wp-content/uploads/upf/",
]

# Dépôts locaux par défaut (s'ils existent) ; surcharge via PSEUDO_PATHS (séparateur :).
_DEFAULT_EXTRA = [
    "/home/hiadsi/thermo_pw/pseudos/PBE",
    "/home/hiadsi/thermo_pw/pseudos/PBE_FR",
    "/home/hiadsi/base des pseudos/PBE",
    "/home/hiadsi/base des pseudos/PBE_FR",
    "/home/hiadsi/génération_inputs-QE/pseudos/PBE",
    "/home/hiadsi/génération_inputs-QE/pseudos/PBE_FR",
]


def extra_dirs():
    """Chemins de recherche locaux : PSEUDO_PATHS puis dépôts connus existants."""
    env = os.environ.get("PSEUDO_PATHS", "")
    from_env = [os.path.expanduser(p.strip()) for p in env.split(os.pathsep) if p.strip()]
    defaults = [d for d in _DEFAULT_EXTRA if os.path.isdir(d)]
    seen, out = set(), []
    for d in from_env + defaults:
        key = os.path.abspath(d)
        if key not in seen:
            seen.add(key)
            out.append(d)
    return out


# Rétrocompatibilité pour imports existants
EXTRA_DIRS = _DEFAULT_EXTRA


class PseudoError(RuntimeError):
    pass


def read_upf_header(path):
    """Extrait element, pseudo_type, z_valence, wfc_cutoff, rho_cutoff, has_so."""
    with open(path, encoding="utf-8", errors="ignore") as f:
        head = f.read(12000)
    out = {}
    m = re.search(r"<PP_HEADER\b([^>]*?)>", head, re.S)
    if m and "=" in m.group(1):
        attrs = dict(re.findall(r'(\w+)\s*=\s*"([^"]*)"', m.group(1)))
        for k in ("element", "pseudo_type", "z_valence", "wfc_cutoff", "rho_cutoff", "has_so"):
            if attrs.get(k) is not None:
                out[k] = attrs[k].strip()
    # UPF v1 (format "clé   valeur" en clair)
    pats = {
        "element": r"Element\s*[:=]?\s+([A-Z][a-z]?)\b",
        "pseudo_type": r"Pseudopotential type\s*[:=]\s*(\S+)",
        "z_valence": r"z_valence\s*[:=]?\s+([-+0-9.eEdD]+)",
        "wfc_cutoff": r"wfc_cutoff\s*[:=]?\s+([-+0-9.eEdD]+)",
        "rho_cutoff": r"rho_cutoff\s*[:=]?\s+([-+0-9.eEdD]+)",
        "has_so": r"has_so\s*[:=]?\s*(\S+)",
    }
    for k, p in pats.items():
        if k not in out:
            mm = re.search(p, head)
            if mm:
                out[k] = mm.group(1).strip()
    if "element" not in out:
        mm = re.search(r"^Element\s+(\S+)\s*$", head, re.M)
        if mm:
            out["element"] = mm.group(1)
    return out


def _f(x, default=None):
    try:
        return float(str(x).replace("d", "e").replace("D", "E"))
    except (TypeError, ValueError):
        return default


def suggest_cutoffs(path):
    """(ecutwfc, ecutrho) suggérés par l'UPF, ou None si indisponible."""
    h = read_upf_header(path)
    wfc = _f(h.get("wfc_cutoff"))
    rho = _f(h.get("rho_cutoff"))
    if wfc is None and rho is None:
        return None
    if wfc is None:
        wfc = rho / 4.0
    if rho is None:
        rho = 4.0 * wfc
    return wfc, rho


def _validate(path, symbol):
    """UPF lisible, bien formé et appartenant bien à `symbol`."""
    if os.path.getsize(path) < 1000:
        return False, "fichier trop petit"
    with open(path, encoding="utf-8", errors="ignore") as f:
        txt = f.read(2000)
    if "<UPF" not in txt and "<PP_HEADER" not in txt:
        return False, "pas un fichier UPF"
    h = read_upf_header(path)
    elt = h.get("element")
    if elt and elt.lower() != symbol.lower():
        return False, "élément déclaré %s ≠ %s" % (elt, symbol)
    return True, None


def _rank(name):
    """Classement : PAW (kjpaw) avant USPP (rrkjus), PBE avant autre."""
    s = 2
    if "kjpaw" in name:
        s = 0
    elif "rrkjus" in name:
        s = 1
    return (s, 0 if ".pbe-" in name else 1, name)


def _copy_into_dest(src, symbol, origin):
    ok, why = _validate(src, symbol)
    if not ok:
        return None
    os.makedirs(DEST_DIR, exist_ok=True)
    dst = os.path.join(DEST_DIR, os.path.basename(src))
    if os.path.abspath(src) != os.path.abspath(dst):
        shutil.copy2(src, dst)
    return os.path.basename(dst), origin


def _download(name, symbol):
    os.makedirs(DEST_DIR, exist_ok=True)
    dst = os.path.join(DEST_DIR, name)
    for base in BASE_URLS:
        try:
            with urllib.request.urlopen(base + name, timeout=90) as r:
                data = r.read()
        except Exception:
            continue
        if len(data) < 1000:
            continue
        tmp = dst + ".part"
        with open(tmp, "wb") as f:
            f.write(data)
        ok, _ = _validate(tmp, symbol)
        if not ok:
            os.remove(tmp)
            continue
        os.replace(tmp, dst)
        return name, "download:" + base.split("/")[2]
    if os.path.exists(dst):
        os.remove(dst)
    return None, None


def _resolve_named(symbol, filename, search_dirs):
    """Cherche un UPF nommé (basename) dans les dépôts locaux."""
    name = os.path.basename(filename)
    if not name:
        return None
    for d in search_dirs:
        if not d:
            continue
        # Chemin absolu fourni tel quel
        if os.path.isabs(filename) and os.path.isfile(filename):
            res = _copy_into_dest(filename, symbol, "scf:" + os.path.dirname(filename))
            if res:
                return res
        p = os.path.join(d, name)
        if os.path.isfile(p):
            origin = "projet:pseudo/" if os.path.abspath(d) == os.path.abspath(DEST_DIR) \
                else "scf-local:" + d
            res = _copy_into_dest(p, symbol, origin)
            if res:
                return res
    return None


def ensure_pseudo(symbol, preferred=None, preferred_dirs=None, allow_download=True):
    """Garantit la présence du pseudo de `symbol` dans pseudo/.

    preferred : nom UPF (ex. depuis ATOMIC_SPECIES d'un *-scf.in).
    preferred_dirs : dossiers supplémentaires (ex. pseudo_dir du scf.in).
    allow_download : False en dry-run (local uniquement).

    Retourne (nom_de_fichier, origine). Lève PseudoError si introuvable.
    """
    cands = el.pseudo_candidates(symbol)
    locals_ = [DEST_DIR] + list(preferred_dirs or []) + extra_dirs()

    # 0. Honorer le UPF nommé dans le *-scf.in s'il est disponible localement
    if preferred:
        hit = _resolve_named(symbol, preferred, locals_)
        if hit:
            return hit

    # 1. candidats dans l'ordre de préférence (PAW puis USPP) : dépôt du projet,
    #    puis les autres dépôts locaux — un pseudo moins bien classé ne l'emporte
    #    jamais sur un candidat supérieur disponible.
    for c in cands:
        if os.path.exists(os.path.join(DEST_DIR, c)):
            return c, "projet:pseudo/"
        for d in extra_dirs():
            p = os.path.join(d, c)
            if os.path.exists(p):
                res = _copy_into_dest(p, symbol, "local:" + d)
                if res:
                    return res
    # 3. recherche floue locale (préférence kjpaw > rrkjus > autre)
    pool = []
    for d in locals_:
        if not os.path.isdir(d):
            continue
        for f in os.listdir(d):
            if f.upper().endswith(".UPF") and f.lower().startswith(symbol.lower() + "."):
                pool.append(os.path.join(d, f))
    for p in sorted(set(pool), key=lambda x: _rank(os.path.basename(x))):
        res = _copy_into_dest(p, symbol, "local-flou:" + os.path.dirname(p))
        if res:
            return res
    # 4. téléchargement des candidats vérifiés
    if allow_download:
        for c in sorted(cands, key=_rank):
            res = _download(c, symbol)
            if res[0]:
                return res
    hint = preferred or (", ".join(cands) or "aucun")
    raise PseudoError(
        "aucun pseudo trouvé pour %s (demandé: %s)" % (symbol, hint)
    )

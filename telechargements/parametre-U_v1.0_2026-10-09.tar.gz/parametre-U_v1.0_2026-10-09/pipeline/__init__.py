"""Pipeline DFT+U pour Quantum ESPRESSO 7.5.

Chaîne complète :
    préparation (structure + pseudos) -> scf1 [-> scf2] -> hp.x (U
    par réponse linéaire) -> scf DFT+U avec U calculé -> analyse.

Entrées  : inputs/<job>/   (fichiers d'entrée QE générés)
État     : jobs/<job>/     (state.json, journaux live, temporaires QE)
Résultats: outputs/<job>/  (résumé, rapport, entrees/, journaux/, hubbard/)
"""

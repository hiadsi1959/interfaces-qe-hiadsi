#!/usr/bin/env sh
# configure.sh — installe les prérequis et prépare l'environnement parametre-U
# Usage :
#   ./configure.sh              # installation complète
#   ./configure.sh --check      # vérification seule
#   ./configure.sh --skip-system  # sans paquets système (venv + env.sh seulement)
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
CHECK_ONLY=0
SKIP_SYSTEM=0
FORCE_VENV=0

for arg in "$@"; do
    case "$arg" in
        --check) CHECK_ONLY=1 ;;
        --skip-system) SKIP_SYSTEM=1 ;;
        --force-venv) FORCE_VENV=1 ;;
        -h|--help)
            printf '%s\n' \
                "Usage: ./configure.sh [--check] [--skip-system] [--force-venv]" \
                "" \
                "  Installe Python/venv, numpy+ase, vérifie bin/pw.x et bin/hp.x," \
                "  génère env.sh, et prépare start.sh / demarrer.sh."
            exit 0
            ;;
        *)
            printf 'Option inconnue : %s\n' "$arg" >&2
            exit 2
            ;;
    esac
done

log()  { printf '→ %s\n' "$*"; }
ok()   { printf '  ✓ %s\n' "$*"; }
warn() { printf '  ! %s\n' "$*" >&2; }
err()  { printf '  ✗ %s\n' "$*" >&2; }

need_cmd() {
    command -v "$1" >/dev/null 2>&1
}

# —— Paquets système ——
install_system() {
    if [ "$SKIP_SYSTEM" = "1" ]; then
        log "Paquets système ignorés (--skip-system)"
        return 0
    fi
    if [ "$(id -u)" -eq 0 ]; then
        SUDO=""
    elif need_cmd sudo; then
        SUDO="sudo"
    else
        warn "Pas de sudo : installez manuellement python3, python3-venv, python3-pip, openmpi"
        return 0
    fi

    log "Installation des paquets système…"
    if need_cmd apt-get; then
        $SUDO apt-get update -y
        $SUDO DEBIAN_FRONTEND=noninteractive apt-get install -y \
            python3 python3-venv python3-pip python3-dev \
            build-essential curl ca-certificates \
            openmpi-bin libopenmpi-dev \
            || warn "apt-get : certains paquets ont échoué"
    elif need_cmd dnf; then
        $SUDO dnf install -y \
            python3 python3-pip python3-devel gcc gcc-c++ make curl \
            openmpi openmpi-devel \
            || warn "dnf : certains paquets ont échoué"
        # module openmpi souvent sous /usr/lib64/openmpi/bin
        if [ -d /usr/lib64/openmpi/bin ]; then
            export PATH="/usr/lib64/openmpi/bin:$PATH"
        fi
    elif need_cmd yum; then
        $SUDO yum install -y \
            python3 python3-pip python3-devel gcc gcc-c++ make curl \
            openmpi openmpi-devel \
            || warn "yum : certains paquets ont échoué"
    elif need_cmd pacman; then
        $SUDO pacman -Sy --noconfirm \
            python python-pip base-devel curl openmpi \
            || warn "pacman : certains paquets ont échoué"
    elif need_cmd zypper; then
        $SUDO zypper --non-interactive install \
            python3 python3-pip python3-devel gcc gcc-c++ make curl \
            openmpi openmpi-devel \
            || warn "zypper : certains paquets ont échoué"
    else
        warn "Gestionnaire de paquets non reconnu — installez Python ≥ 3.10 et OpenMPI à la main"
    fi
}

# —— Intel oneAPI (libs des binaires embarqués) ——
find_oneapi_setvars() {
    for cand in \
        "${ONEAPI_ROOT:+$ONEAPI_ROOT/setvars.sh}" \
        /opt/intel/oneapi/setvars.sh \
        "$HOME/intel/oneapi/setvars.sh" \
        /usr/local/intel/oneapi/setvars.sh
    do
        if [ -n "${cand:-}" ] && [ -f "$cand" ]; then
            printf '%s\n' "$cand"
            return 0
        fi
    done
    return 1
}

# —— Venv Python ——
setup_venv() {
    if ! need_cmd python3; then
        err "python3 introuvable"
        return 1
    fi
    pyver=$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')
    ok "Python $pyver"

    VPY="$ROOT/.venv/bin/python"
    if [ ! -x "$VPY" ] || [ "$FORCE_VENV" = "1" ]; then
        log "Création du venv ($ROOT/.venv)…"
        rm -rf "$ROOT/.venv"
        python3 -m venv "$ROOT/.venv"
        VPY="$ROOT/.venv/bin/python"
    else
        ok "venv déjà présent"
    fi

    if [ ! -x "$VPY" ]; then
        err "venv invalide ($VPY) — relancez avec ./configure.sh --force-venv"
        return 1
    fi

    log "Installation des paquets Python (requirements.txt)…"
    "$VPY" -m pip install --upgrade pip wheel >/dev/null
    "$VPY" -m pip install -r "$ROOT/requirements.txt"
    "$VPY" -c 'import numpy, ase; print("numpy", numpy.__version__, "| ase", ase.__version__)' \
        | while IFS= read -r line; do ok "$line"; done
}

# —— Dossiers & scripts ——
prepare_tree() {
    log "Préparation des dossiers…"
    mkdir -p "$ROOT/pseudo" "$ROOT/jobs" "$ROOT/outputs" "$ROOT/inputs" "$ROOT/bin"
    chmod +x \
        "$ROOT/configure.sh" \
        "$ROOT/start.sh" \
        "$ROOT/DEMARRER.sh" \
        "$ROOT/demarrer.sh" \
        "$ROOT/tools/dftu.py" \
        2>/dev/null || true
    # Alias pratique (typo fréquente)
    if [ ! -e "$ROOT/star.sh" ]; then
        ln -sf start.sh "$ROOT/star.sh"
    fi
    ok "arborescence et permissions"
}

# —— Génération env.sh ——
write_env_sh() {
    ONEAPI=""
    if ONEAPI=$(find_oneapi_setvars); then
        ok "Intel oneAPI trouvé : $ONEAPI"
    else
        ONEAPI=""
        warn "Intel oneAPI (setvars.sh) introuvable — requis si bin/ est lié à MKL/Intel MPI"
    fi

    # ROOT figé en chemin absolu (fiable sous sh/bash quand on source le fichier)
    {
        printf '%s\n' \
            "# Généré par configure.sh — relancez ./configure.sh pour régénérer" \
            "# Sourcé automatiquement par start.sh et DEMARRER.sh" \
            "ROOT=\"$ROOT\"" \
            "export PARAMETRE_U_ROOT=\"\$ROOT\"" \
            "export QE_BIN=\"\${QE_BIN:-\$ROOT/bin}\"" \
            "export PATH=\"\$ROOT/bin:\$PATH\"" \
            "export PYTHONPATH=\"\$ROOT\${PYTHONPATH:+:\$PYTHONPATH}\"" \
            "" \
            "# OpenMPI Fedora/RHEL" \
            "if [ -d /usr/lib64/openmpi/bin ]; then" \
            "  export PATH=\"/usr/lib64/openmpi/bin:\$PATH\"" \
            "fi" \
            "" \
            "# Intel oneAPI (MKL + Intel MPI) — libs des exécutables dans bin/"
        if [ -n "$ONEAPI" ]; then
            printf '%s\n' \
                "if [ -f \"$ONEAPI\" ] && [ -z \"\${ONEAPI_ROOT:-}\" ]; then" \
                "  # shellcheck disable=SC1091" \
                "  . \"$ONEAPI\" --force >/dev/null 2>&1 || . \"$ONEAPI\" >/dev/null 2>&1 || true" \
                "fi"
        else
            printf '%s\n' \
                "# Installez Intel oneAPI puis relancez ./configure.sh" \
                "# Exemple : . /opt/intel/oneapi/setvars.sh"
        fi
        printf '%s\n' \
            "" \
            "if [ -f \"\$ROOT/.venv/bin/activate\" ]; then" \
            "  # shellcheck disable=SC1091" \
            "  . \"\$ROOT/.venv/bin/activate\"" \
            "fi"
    } > "$ROOT/env.sh"
    ok "écrit $ROOT/env.sh"
}

# —— Vérifications QE ——
check_qe() {
    log "Vérification des exécutables QE (bin/)…"
    missing=0
    for exe in pw.x hp.x; do
        path="$ROOT/bin/$exe"
        if [ -x "$path" ]; then
            ok "$exe → $path"
        else
            err "$exe manquant ou non exécutable dans bin/"
            missing=1
        fi
    done

    if [ "$missing" = "1" ]; then
        warn "Copiez pw.x et hp.x (QE 7.5) dans $ROOT/bin/"
        return 1
    fi

    if need_cmd ldd; then
        unresolved=$(ldd "$ROOT/bin/pw.x" 2>/dev/null | grep -c 'not found' || true)
        if [ "${unresolved:-0}" -gt 0 ]; then
            err "pw.x : bibliothèques manquantes (souvent Intel oneAPI MKL/MPI)"
            ldd "$ROOT/bin/pw.x" 2>/dev/null | grep 'not found' | while IFS= read -r line; do
                warn "$line"
            done
            warn "Installez Intel oneAPI Base Toolkit + HPC Toolkit, puis relancez ./configure.sh"
            return 1
        fi
        ok "dépendances dynamiques de pw.x résolues"
    fi

    if need_cmd mpirun || need_cmd mpiexec; then
        ok "MPI launcher : $(command -v mpirun 2>/dev/null || command -v mpiexec)"
    else
        warn "mpirun/mpiexec introuvable — calculs --np 1 seulement, ou installez OpenMPI / Intel MPI"
    fi
    return 0
}

check_python_imports() {
    log "Vérification des imports Python…"
    VPY="$ROOT/.venv/bin/python"
    if [ ! -x "$VPY" ]; then
        VPY=$(command -v python3 || true)
    fi
    if [ -z "$VPY" ]; then
        err "python3 introuvable"
        return 1
    fi
    if "$VPY" -c 'import numpy, ase' 2>/dev/null; then
        ok "numpy + ase ($VPY)"
    else
        err "numpy/ase absents — lancez ./configure.sh sans --check"
        return 1
    fi
    if PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}" "$VPY" -c 'from pipeline import runner; print(runner.available())' 2>/dev/null; then
        ok "pipeline importable"
    else
        warn "import pipeline échoué (vérifiez PYTHONPATH / venv)"
    fi
}

# —— Main ——
main() {
    printf '\n=== parametre-U — configuration ===\n'
    printf 'Racine : %s\n\n' "$ROOT"

    if [ "$CHECK_ONLY" = "1" ]; then
        prepare_tree
        if [ -f "$ROOT/env.sh" ]; then
            # shellcheck disable=SC1091
            . "$ROOT/env.sh"
            ok "env.sh chargé"
        else
            warn "env.sh absent — lancez ./configure.sh"
        fi
        check_python_imports || true
        check_qe || true
        printf '\nVérification terminée.\n'
        return 0
    fi

    install_system
    prepare_tree
    setup_venv
    write_env_sh
    # recharge env pour les checks
    # shellcheck disable=SC1091
    . "$ROOT/env.sh"
    check_python_imports
    qe_ok=0
    check_qe && qe_ok=1 || true

    printf '\n=== Prêt ===\n'
    printf '  Interface web :  ./start.sh\n'
    printf '                   ./demarrer.sh          (sans argument = interface)\n'
    printf '                   ./star.sh              (alias de start.sh)\n'
    printf '  Calcul JSON :    ./demarrer.sh inputs/mon_alliage.json\n'
    printf '                   ./DEMARRER.sh inputs/mon_alliage.json --dry-run\n'
    printf '  CLI :            python3 tools/dftu.py list\n'
    printf '\n'
    printf '  Port custom :    PORT=8080 ./start.sh\n'
    printf '  Sans navigateur : OPEN_BROWSER=0 ./start.sh\n'
    if [ "$qe_ok" != "1" ]; then
        printf '\nAttention : QE/MPI incomplets — l’interface démarre, les calculs pw.x/hp.x peuvent échouer.\n' >&2
        return 1
    fi
    printf '\nConfiguration OK.\n'
    return 0
}

main "$@"

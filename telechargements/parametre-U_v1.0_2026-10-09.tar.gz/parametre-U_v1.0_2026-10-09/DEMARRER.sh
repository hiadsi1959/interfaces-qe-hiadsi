#!/usr/bin/env sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

if [ -f "$ROOT/env.sh" ]; then
    # shellcheck disable=SC1091
    . "$ROOT/env.sh"
elif [ -f "$ROOT/.venv/bin/activate" ]; then
    # shellcheck disable=SC1091
    . "$ROOT/.venv/bin/activate"
    export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
    export QE_BIN="${QE_BIN:-$ROOT/bin}"
    export PATH="$ROOT/bin:$PATH"
fi

if [ "$#" -eq 0 ]; then
    exec "$ROOT/start.sh"
fi
if [ "$#" -lt 1 ]; then
    printf 'Usage: %s <config.json> [--dry-run] [--fresh] [--steps scf1,scf2,hp,scf_u,analyse]\n' "$(basename "$0")" >&2
    exit 2
fi

if ! command -v python3 >/dev/null 2>&1; then
    printf '%s\n' "Erreur : Python 3 est requis. Lancez d'abord ./configure.sh" >&2
    exit 1
fi

CFG=$1
shift

PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}" exec python3 - "$ROOT" "$CFG" "$@" <<'PY'
import json
import os
import sys

root = sys.argv[1]
cfg_path = sys.argv[2]
extra = sys.argv[3:]

with open(cfg_path, 'r', encoding='utf-8') as fh:
    data = json.load(fh)

name = str(data.get('name') or os.path.splitext(os.path.basename(cfg_path))[0]).strip()
if not name:
    raise SystemExit("Le fichier JSON doit contenir un champ 'name'.")

cmd = [sys.executable, os.path.join(root, 'tools', 'dftu.py'), 'run', '--name', name]

if data.get('structure'):
    cmd.extend(['--structure', str(data['structure'])])
elif data.get('formula'):
    cmd.extend(['--formula', str(data['formula'])])
    if data.get('prototype') is not None:
        cmd.extend(['--prototype', str(data['prototype'])])
    for key, flag in (('a', '--a'), ('c', '--c'), ('ca', '--ca'), ('ase_u', '--ase-u')):
        if data.get(key) is not None:
            cmd.extend([flag, str(data[key])])

# Contrat DEMARRER : toujours hp.x (pas de skip, pas de u_source literature)
if data.get('skip_hp'):
    raise SystemExit(
        "DEMARRER.sh impose hp.x : retirez skip_hp du JSON "
        "(utilisez tools/dftu.py run --skip-hp pour un calcul sans hp).")
if data.get('u_source') not in (None, '', 'hp'):
    raise SystemExit(
        "DEMARRER.sh impose --u-source hp (reçu %r)." % data.get('u_source'))
cmd.extend(['--u-source', 'hp'])

for key, flag in (('magnetic', '--magnetic'), ('kind', '--kind'),
                  ('smearing', '--smearing'), ('np', '--np'), ('start_mag', '--start-mag'),
                  ('ecutwfc', '--ecutwfc'), ('ecutrho', '--ecutrho'), ('degauss', '--degauss'),
                  ('conv_thr', '--conv-thr'), ('conv_thr_tight', '--conv-thr-tight')):
    if data.get(key) is not None:
        if key in {'magnetic', 'kind', 'smearing'}:
            cmd.extend([flag, str(data[key])])
        else:
            cmd.extend([flag, str(data[key])])

if data.get('supercell') not in (None, ''):
    cmd.extend(['--supercell', *[str(v) for v in data['supercell']]])
if data.get('kmesh') not in (None, ''):
    cmd.extend(['--kmesh', *[str(v) for v in data['kmesh']]])
if data.get('nq') not in (None, ''):
    cmd.extend(['--nq', *[str(v) for v in data['nq']]])

for item in data.get('mag') or []:
    cmd.extend(['--mag', str(item)])
for item in data.get('u') or []:
    cmd.extend(['--u', str(item)])
for item in data.get('hubbard_element') or []:
    cmd.extend(['--hubbard-element', str(item)])

site_groups = data.get('site_groups') or {}
for symbol, groups in site_groups.items():
    for group in groups or []:
        if group:
            cmd.extend(['--site-group', f"{symbol}={','.join(str(v) for v in group)}"])

afm = data.get('afm')
if afm is not None and afm != '' and afm is not False:
    if afm is True:
        cmd.extend(['--afm', 'z'])
    elif isinstance(afm, (list, tuple)):
        for axis in afm:
            cmd.extend(['--afm', str(axis)])
    else:
        cmd.extend(['--afm', str(afm)])

cmd.extend(extra)
os.execvp(sys.executable, cmd)
PY

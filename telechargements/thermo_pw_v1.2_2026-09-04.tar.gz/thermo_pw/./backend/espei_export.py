"""
Export des données thermo_pw (profil P2 QHA) vers des jeux ESPEI (JSON).

Produit un dossier ``calphad_espei/`` dans le work_dir :
  * ``datasets/*.json`` — CPM_FORM, SM_FORM, HM_FORM (non-équilibre ESPEI)
  * ``phase_models_stub.json`` — modèle mono-phase à compléter
  * ``espei_in_stub.yaml`` — gabarit de lancement ESPEI
  * ``README.txt`` — instructions (pyCalphad / diagramme de phases)
  * ``manifest.json`` — résumé machine-lisible

Un seul run P2 = une phase, une composition. Un diagramme CALPHAD complet
exige plusieurs runs (phases / compositions) agrégés manuellement ou via ESPEI.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from parsers.thermo_therm_dat import parse_therm_dat, parse_therm_dat_file, pick_central_geometry, find_therm_dat_files
from parsers.thermo_derived import enrich_thermo_and_dielectric

_RY_TO_J = 2.179872361e-18
_N_A = 6.02214076e23
_STD_P_PA = 101325.0


@dataclass
class EspeiExportResult:
    ok: bool
    output_dir: str = "calphad_espei"
    datasets: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    manifest: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "output_dir": self.output_dir,
            "datasets": list(self.datasets),
            "warnings": list(self.warnings),
            "errors": list(self.errors),
            "manifest": dict(self.manifest),
        }


def _read_scf_text(work_dir: Path) -> str:
    for name in ("pw_scf_V0_for_phonon.in", "scf.in", "scf_eq.in"):
        p = work_dir / name
        if p.is_file():
            try:
                return p.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
    return ""


def parse_species_and_nat(work_dir: Path) -> tuple[list[str], int]:
    """Éléments (symboles MAJ) et ``nat`` depuis le scf.in du run."""
    text = _read_scf_text(work_dir)
    species: list[str] = []
    for ln in text.splitlines():
        m = re.match(r"^\s*([A-Za-z][A-Za-z]?)\s+[\d.]+\s+\S+\.UPF", ln.strip(), re.I)
        if m:
            sym = m.group(1).strip().upper()
            if sym not in species:
                species.append(sym)
    nat = 0
    m = re.search(r"(?im)^\s*nat\s*=\s*(\d+)", text)
    if m:
        try:
            nat = int(m.group(1))
        except ValueError:
            nat = 0
    if not species and nat == 0:
        return (["X"], 1)
    if nat <= 0:
        nat = max(1, len(species))
    return (species if species else ["X"], nat)


def _ry_per_cell_to_j_per_mol(value_ry: float, *, nat: int) -> float:
    """Ry/cell → J/mol-atoms (``nat`` atomes par cellule de simulation)."""
    nat = max(1, int(nat))
    return float(value_ry) * _RY_TO_J * _N_A / nat


def _default_phase_name(material_id: str, species: list[str]) -> str:
    base = (material_id or "MAT").upper().replace("-", "_").replace(" ", "_")
    if len(species) == 1:
        return f"{base}_{species[0]}"
    return base


def _solver_block(species: list[str]) -> dict[str, Any]:
    syms = [s.upper() for s in species] or ["X"]
    return {
        "mode": "manual",
        "sublattice_site_ratios": [1],
        "sublattice_configurations": [syms],
        "sublattice_occupancies": [[1.0 / len(syms)] * len(syms)],
    }


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def export_espei_bundle(
    work_dir: Path,
    results: Optional[dict[str, Any]] = None,
    *,
    material_id: str = "",
    phase_name: Optional[str] = None,
) -> EspeiExportResult:
    """Construit ``calphad_espei/`` depuis un run P2 (ou P3 avec thermo QHA)."""
    work_dir = Path(work_dir).resolve()
    res = EspeiExportResult(ok=False)
    out_root = work_dir / "calphad_espei"
    ds_dir = out_root / "datasets"

    species, nat = parse_species_and_nat(work_dir)
    components = list(species) + ["VA"]
    phase = phase_name or _default_phase_name(material_id, species)

    results = dict(results or {})
    thermo = dict(results.get("thermo") or {})
    eos = dict(results.get("eos") or {})

    # Enrichir Cp / courbes si le marker est minimal.
    try:
        enrich_thermo_and_dielectric(work_dir, results, force=False)
        thermo = dict(results.get("thermo") or thermo)
    except Exception as ex:  # noqa: BLE001
        res.warnings.append(f"enrich_thermo skipped: {ex}")

    paths = find_therm_dat_files(work_dir)
    target = pick_central_geometry(paths)
    parsed = parse_therm_dat_file(target) if target else parse_therm_dat(work_dir)

    temps: list[float] = list(parsed.get("curve_T_K") or [])
    cv_ry: list[Optional[float]] = list(parsed.get("curve_Cv_Ry_per_K") or [])
    cp_ry: list[Optional[float]] = list(thermo.get("curve_Cp_Ry_per_K") or [])
    s_ry: list[Optional[float]] = []

    if target and target.is_file():
        full = parse_therm_dat_file(target, max_curve_points=500)
        s_ry = list(full.get("curve_entropy") or [])
        if not s_ry and full.get("curve_T_K"):
            # Re-parse entropy from file if missing in short parse
            try:
                text = target.read_text(encoding="utf-8", errors="replace")
                s_rows: list[float] = []
                t_rows: list[float] = []
                for ln in text.splitlines():
                    if ln.strip().startswith("#") or not ln.strip():
                        continue
                    toks = re.split(r"\s+", ln.strip())
                    if len(toks) >= 4:
                        try:
                            t_rows.append(float(toks[0].replace("D", "E")))
                            s_rows.append(float(toks[3].replace("D", "E")))
                        except ValueError:
                            pass
                if len(t_rows) == len(s_rows) and t_rows:
                    temps = t_rows if not temps else temps
                    s_ry = s_rows
            except OSError:
                pass

    if not temps:
        res.errors.append("Aucune courbe T dans output_therm.dat — lancer P2 jusqu'à thermo_pw QHA.")
        _write_readme(out_root, res, phase, components)
        return res

    # Cp prioritaire, sinon Cv.
    heat_ry = cp_ry if cp_ry and len(cp_ry) == len(temps) else cv_ry
    if not heat_ry or len(heat_ry) != len(temps):
        res.warnings.append("Courbe Cp absente — export CPM depuis Cv QHA uniquement.")
        heat_ry = cv_ry

    cpm_pairs: list[tuple[float, float]] = []
    sm_pairs: list[tuple[float, float]] = []
    hm_pairs: list[tuple[float, float]] = []
    curve_f = parsed.get("curve_F_Ry") or []
    for i, t in enumerate(temps):
        t_f = float(t)
        cv = heat_ry[i] if i < len(heat_ry) and heat_ry[i] is not None else None
        if cv is not None:
            cpm_pairs.append((t_f, _ry_per_cell_to_j_per_mol(float(cv), nat=nat)))
        s = s_ry[i] if i < len(s_ry) and s_ry[i] is not None else None
        if s is not None:
            sm_pairs.append((t_f, _ry_per_cell_to_j_per_mol(float(s), nat=nat)))
        fe = float(curve_f[i]) if i < len(curve_f) and curve_f[i] is not None else None
        if fe is not None and s is not None:
            # H ≈ F + TS (Helmholtz → enthalpie approchée, P≈0)
            hm_pairs.append(
                (t_f, _ry_per_cell_to_j_per_mol(fe + t_f * float(s), nat=nat))
            )

    def _write_qha_dataset(
        filename: str,
        output: str,
        pairs: list[tuple[float, float]],
    ) -> bool:
        if len(pairs) < 2:
            return False
        ts, vs = zip(*pairs)
        payload = {
            **common_meta,
            "output": output,
            "conditions": {"P": [_STD_P_PA], "T": [float(x) for x in ts]},
            "values": _values_pt_config(list(vs)),
        }
        _write_json(ds_dir / filename, payload)
        written.append(f"datasets/{filename}")
        return True

    common_meta = {
        "components": components,
        "phases": [phase],
        "reference": (
            f"thermo_pw QHA export ({material_id or '?'}) — "
            "vérifier l'état de référence ESPEI (SGTE91) avant ajustement CALPHAD."
        ),
        "conditions": {"P": [_STD_P_PA], "T": [float(t) for t in temps]},
        "solver": _solver_block(species),
        "excluded_model_contributions": ["idmix", "mag"],
    }

    # ESPEI attend values de forme (nP, nT, nconfigs) — ici (1, nT, 1).
    def _values_pt_config(scalars: list[float]) -> list[list[list[float]]]:
        return [[ [float(v)] for v in scalars ]]

    written: list[str] = []
    qha_n = 0
    if _write_qha_dataset("cpm_form_qha.json", "CPM_FORM", cpm_pairs):
        qha_n += 1
    if _write_qha_dataset("sm_form_qha.json", "SM_FORM", sm_pairs):
        qha_n += 1
    if _write_qha_dataset("hm_form_qha.json", "HM_FORM", hm_pairs):
        qha_n += 1

    e0 = eos.get("E0_Ry")
    if e0 is not None:
        name = "hm_form_e0_298.json"
        payload = {
            **common_meta,
            "output": "HM_FORM",
            "conditions": {"P": [_STD_P_PA], "T": [298.15]},
            "values": [[[_ry_per_cell_to_j_per_mol(float(e0), nat=nat)]]],
            "reference": (
                "E₀ DFT (EOS Birch–Murnaghan) à 298 K — PAS une enthalpie de formation "
                "sans énergies élémentaires de référence ; compléter avant ESPEI."
            ),
            "solver": _solver_block(species),
            "excluded_model_contributions": ["idmix", "mag"],
        }
        _write_json(ds_dir / name, payload)
        written.append(f"datasets/{name}")
        res.warnings.append(
            "HM_FORM depuis E₀ statique : ajouter les références élémentaires DFT pour ESPEI."
        )

    if not written:
        res.errors.append("Aucun jeu JSON ESPEI produit (données thermo insuffisantes).")
        _write_readme(out_root, res, phase, components)
        return res

    # phase_models stub
    phase_models = {
        "components": components,
        "phases": {
            phase: {
                "sublattice_model": [species],
                "sublattice_site_ratios": [1],
            }
        },
    }
    _write_json(out_root / "phase_models_stub.json", phase_models)

    yaml_stub = f"""# Gabarit ESPEI — compléter puis : espei --check-datasets {out_root.name}/datasets
system:
  phase_models: phase_models_stub.json
  datasets: datasets
  tags:
    dft_qha:
      excluded_model_contributions: ['idmix', 'mag']

generate_parameters:
  ref_state: SGTE91
  excess_model: linear

# Étape suivante (hors thermo_pw) : pyCalphad binplot / equilibrium avec le .tdb exporté.
"""
    out_root.mkdir(parents=True, exist_ok=True)
    (out_root / "espei_in_stub.yaml").write_text(yaml_stub, encoding="utf-8")

    res.datasets = written
    res.ok = qha_n > 0
    if not res.ok:
        res.warnings.append(
            "Aucun jeu QHA (Cp/S/H vs T) exporté — E₀ seul ne suffit pas pour ESPEI."
        )
    qha_n_t = max(len(cpm_pairs), len(sm_pairs), len(hm_pairs), len(temps) if temps else 0)
    res.manifest = {
        "material_id": material_id,
        "phase_name": phase,
        "components": components,
        "nat": nat,
        "n_temperature_points": qha_n_t,
        "T_min_K": min(temps) if temps else None,
        "T_max_K": max(temps) if temps else None,
        "datasets": written,
        "next_steps": [
            "Fusionner plusieurs runs (autres phases/compositions) dans datasets/",
            "espei --check-datasets calphad_espei/datasets",
            "Lancer ESPEI (generate_parameters / mcmc) → fichier .tdb",
            "Tracer le diagramme avec pyCalphad binplot ou equilibrium",
        ],
    }
    _write_json(out_root / "manifest.json", res.manifest)
    _write_readme(out_root, res, phase, components)
    return res


def _write_readme(
    out_root: Path,
    res: EspeiExportResult,
    phase: str,
    components: list[str],
) -> None:
    lines = [
        "Export ESPEI / CALPHAD (option P2 thermo_pw)",
        "==========================================",
        "",
        f"Phase exportée : {phase}",
        f"Composants   : {', '.join(components)}",
        "",
        "Ce dossier contient des données NON-ÉQUILIBRE pour ESPEI (CPM/SM/HM_FORM).",
        "Un diagramme de phases complet nécessite plusieurs phases et compositions.",
        "",
        "Étapes :",
        "  1. espei --check-datasets datasets/",
        "  2. espei -i espei_in_stub.yaml  (après complétion du YAML)",
        "  3. pyCalphad : Database('sortie.tdb') + binplot / equilibrium",
        "",
    ]
    if res.warnings:
        lines.append("Avertissements :")
        lines.extend(f"  - {w}" for w in res.warnings)
        lines.append("")
    if res.errors:
        lines.append("Erreurs :")
        lines.extend(f"  - {e}" for e in res.errors)
    out_root.mkdir(parents=True, exist_ok=True)
    (out_root / "README.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


__all__ = ["EspeiExportResult", "export_espei_bundle", "parse_species_and_nat"]

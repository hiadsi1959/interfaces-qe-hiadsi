"""Enchaînement P(i) → P(i+1) en réutilisant le work_dir et les étapes communes."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from thermo_pw_resume import phonon_prereqs_ok

PROFILE_ORDER: tuple[str, ...] = ("P1", "P2", "P3", "P4", "P5")

_PROFILE_NEEDS: dict[str, dict[str, bool]] = {
    "P1": {"needs_eos": False, "needs_phonons": True},
    "P2": {"needs_eos": True, "needs_phonons": True},
    "P3": {"needs_eos": True, "needs_phonons": True},
    "P4": {"needs_eos": True, "needs_phonons": True},
    "P5": {"needs_eos": False, "needs_phonons": True},
}


def profile_index(profile_id: str) -> int:
    pid = (profile_id or "").strip().upper()
    try:
        return PROFILE_ORDER.index(pid)
    except ValueError:
        return -1


def next_profile_id(profile_id: str) -> Optional[str]:
    i = profile_index(profile_id)
    if i < 0 or i >= len(PROFILE_ORDER) - 1:
        return None
    return PROFILE_ORDER[i + 1]


def iter_upgrade_targets(source_profile_id: str) -> list[str]:
    """Profils cibles possibles (strictement après la source dans P1..P5)."""
    i = profile_index(source_profile_id)
    if i < 0:
        return []
    return list(PROFILE_ORDER[i + 1 :])


def eos_prereqs_ok(work_dir: Path) -> tuple[bool, str]:
    wd = Path(work_dir)
    eos_dir = wd / "1_eos_volumes"
    if not eos_dir.is_dir():
        return False, "1_eos_volumes/ absent"
    summary = eos_dir / "eos_summary.json"
    scf_eq = eos_dir / "scf_eq.in"
    if summary.is_file():
        return True, ""
    # Au moins un volume SCF dans la grille EOS
    vols = list(eos_dir.glob("scf_v*.in")) + list(eos_dir.glob("pw_scf_v*.in"))
    if scf_eq.is_file() and len(vols) >= 3:
        return True, ""
    if len(vols) >= 5:
        return True, ""
    return False, "grille EOS incomplète (eos_summary.json ou volumes manquants)"


def scf_equilibrium_ok(work_dir: Path) -> tuple[bool, str]:
    wd = Path(work_dir)
    if (wd / "1_eos_volumes" / "scf_eq.in").is_file():
        return True, ""
    if (wd / "pw_scf_V0_for_phonon.in").is_file():
        return True, ""
    if (wd / "scf.in").is_file() and (wd / "out" / "scf.out").is_file():
        return True, ""
    return False, "SCF équilibre non trouvé (scf_eq.in / pw_scf_V0_for_phonon.in)"


def electronic_props_reusable(work_dir: Path, results: Optional[dict] = None) -> bool:
    props = (results or {}).get("properties") or {}
    if props.get("bands_ok") or props.get("band_gap_eV") is not None:
        return True
    wd = Path(work_dir)
    return (wd / "nscf.in").is_file() and (
        (wd / "ebands.png").is_file() or (wd / "edos.png").is_file()
    )


@dataclass
class UpgradePlan:
    source_profile_id: str
    target_profile_id: str
    source_job_id: str
    source_work_dir: Path
    skip_eos: bool = False
    skip_scf_eq: bool = False
    skip_phonons: bool = False
    skip_electronic: bool = False
    reuse_notes: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_profile_id": self.source_profile_id,
            "target_profile_id": self.target_profile_id,
            "source_job_id": self.source_job_id,
            "source_work_dir": str(self.source_work_dir),
            "skip_eos": self.skip_eos,
            "skip_scf_eq": self.skip_scf_eq,
            "skip_phonons": self.skip_phonons,
            "skip_electronic": self.skip_electronic,
            "reuse_notes": list(self.reuse_notes),
            "warnings": list(self.warnings),
        }


@dataclass
class UpgradeOption:
    profile_id: str
    label: str
    detail: str
    recommended: bool
    plan: UpgradePlan

    def to_dict(self) -> dict[str, Any]:
        return {
            "profile_id": self.profile_id,
            "label": self.label,
            "detail": self.detail,
            "recommended": self.recommended,
            "skip_steps": [
                k
                for k, v in (
                    ("eos", self.plan.skip_eos),
                    ("scf_eq", self.plan.skip_scf_eq),
                    ("phonons", self.plan.skip_phonons),
                    ("electronic", self.plan.skip_electronic),
                )
                if v
            ],
            "reuse_notes": list(self.plan.reuse_notes),
            "warnings": list(self.plan.warnings),
        }


_PROFILE_LABELS = {
    "P1": "Mécanique 0 K",
    "P2": "Thermo QHA",
    "P3": "Étude complète",
    "P4": "Durées de vie phonons",
    "P5": "Diélectrique / optique",
}


def build_upgrade_plan(
    *,
    source_profile_id: str,
    target_profile_id: str,
    source_job_id: str,
    work_dir: Path,
    results: Optional[dict] = None,
    material_id: Optional[str] = None,
) -> UpgradePlan:
    src = (source_profile_id or "").strip().upper()
    tgt = (target_profile_id or "").strip().upper()
    wd = Path(work_dir).resolve()
    plan = UpgradePlan(
        source_profile_id=src,
        target_profile_id=tgt,
        source_job_id=source_job_id,
        source_work_dir=wd,
    )
    if profile_index(src) < 0 or profile_index(tgt) < 0:
        plan.warnings.append(f"Profil inconnu : {src!r} → {tgt!r}.")
        return plan
    if profile_index(tgt) <= profile_index(src):
        plan.warnings.append(
            f"La cible {tgt} doit être strictement après {src} dans P1→P5."
        )
        return plan
    if not wd.is_dir():
        plan.warnings.append(f"work_dir introuvable : {wd}")
        return plan

    tgt_needs = _PROFILE_NEEDS.get(tgt, {})

    if tgt_needs.get("needs_eos"):
        ok, msg = eos_prereqs_ok(wd)
        if ok:
            plan.skip_eos = True
            plan.reuse_notes.append("Grille EOS + fit Birch–Murnaghan conservés.")
        else:
            plan.warnings.append(f"EOS non réutilisable : {msg}")

    if tgt_needs.get("needs_phonons"):
        ok_ph, msg_ph = phonon_prereqs_ok(wd)
        ok_eq, _msg_eq = scf_equilibrium_ok(wd)
        if ok_ph:
            plan.skip_phonons = True
            plan.reuse_notes.append(
                "Chaîne phonon (ph.x → q2r.x → matdyn.x) conservée."
            )
        else:
            plan.warnings.append(f"Phonons non réutilisables : {msg_ph}")
        if ok_eq:
            plan.skip_scf_eq = True
            plan.reuse_notes.append("SCF @ V₀ (équilibre) conservé.")
    elif not tgt_needs.get("needs_eos"):
        # P5 : pas de grille EOS, mais SCF + phonons
        ok_eq, msg_eq = scf_equilibrium_ok(wd)
        ok_ph, msg_ph = phonon_prereqs_ok(wd)
        if ok_eq:
            plan.skip_scf_eq = True
            plan.reuse_notes.append("SCF @ V₀ conservé (pas de nouvelle grille EOS).")
        else:
            plan.warnings.append(f"SCF équilibre : {msg_eq}")
        if ok_ph:
            plan.skip_phonons = True
            plan.reuse_notes.append("Phonons DFPT conservés pour ε∞ / Z*.")
        else:
            plan.warnings.append(f"Phonons requis pour P5 : {msg_ph}")

    if electronic_props_reusable(wd, results):
        plan.skip_electronic = True
        plan.reuse_notes.append("Propriétés électroniques (NSCF/DOS/bandes) conservées.")

    if material_id:
        plan.reuse_notes.append(f"Matériau : {material_id}.")

    return plan


def plan_is_runnable(plan: UpgradePlan) -> bool:
    """True si l'upgrade apporte un gain (au moins une étape prefix réutilisable)."""
    if profile_index(plan.target_profile_id) <= profile_index(plan.source_profile_id):
        return False
    if not plan.reuse_notes and not (
        plan.skip_eos or plan.skip_phonons or plan.skip_scf_eq or plan.skip_electronic
    ):
        return False
    tgt = plan.target_profile_id
    tgt_needs = _PROFILE_NEEDS.get(tgt, {})
    # Phonons obligatoires pour la cible : doivent être réutilisables.
    if tgt_needs.get("needs_phonons") and not plan.skip_phonons:
        return False
    # EOS : si manquant, upgrade partiel OK (ex. P1→P2 ne réutilise que phonons).
    if tgt_needs.get("needs_eos") and not plan.skip_eos:
        return plan.skip_phonons or plan.skip_scf_eq
    return True


def list_upgrade_options(
    *,
    source_profile_id: str,
    source_job_id: str,
    work_dir: Path,
    results: Optional[dict] = None,
    material_id: Optional[str] = None,
    only_next: bool = False,
) -> list[UpgradeOption]:
    """Options d'upgrade depuis un run source terminé."""
    src = (source_profile_id or "").strip().upper()
    targets = (
        [next_profile_id(src)]
        if only_next
        else iter_upgrade_targets(src)
    )
    out: list[UpgradeOption] = []
    nxt = next_profile_id(src)
    for tgt in targets:
        if not tgt:
            continue
        plan = build_upgrade_plan(
            source_profile_id=src,
            target_profile_id=tgt,
            source_job_id=source_job_id,
            work_dir=work_dir,
            results=results,
            material_id=material_id,
        )
        if not plan_is_runnable(plan):
            continue
        lbl = _PROFILE_LABELS.get(tgt, tgt)
        skipped = ", ".join(
            s
            for s, flag in (
                ("EOS", plan.skip_eos),
                ("SCF@V₀", plan.skip_scf_eq),
                ("phonons", plan.skip_phonons),
                ("électronique", plan.skip_electronic),
            )
            if flag
        )
        detail = (
            f"Depuis {src} : réutilise {skipped or 'artefacts partiels'} ; "
            f"lance uniquement les étapes propres à {tgt}."
        )
        if plan.warnings:
            detail += " ⚠ " + " ; ".join(plan.warnings[:2])
        out.append(
            UpgradeOption(
                profile_id=tgt,
                label=f"Continuer en {tgt} — {lbl}",
                detail=detail,
                recommended=(tgt == nxt),
                plan=plan,
            )
        )
    return out


# ---------------------------------------------------------------------------
# Estimations Δ (upgrade) pour affichage tuiles P1..P5
# ---------------------------------------------------------------------------

_RUNTIME_STEPS_BY_SKIP: dict[str, frozenset[str]] = {
    "skip_eos": frozenset({"eos_grid"}),
    "skip_scf_eq": frozenset({"scf_eq", "scf_phonon"}),
    "skip_phonons": frozenset({"ph", "q2r", "matdyn", "scf_phonon"}),
    "skip_electronic": frozenset({"electronic_props"}),
}

_STORAGE_NAME_MARKERS_BY_SKIP: dict[str, tuple[str, ...]] = {
    "skip_eos": ("1_eos_volumes",),
    "skip_scf_eq": ("out_scf_eq", "SCF @ V₀"),
    "skip_phonons": ("_ph0", "chaîne phonon", "potentiels dvscf", "orbitales perturbées"),
    "skip_electronic": ("NSCF + DOS", "NSCF"),
}


def ideal_upgrade_skips(
    source_profile_id: str, target_profile_id: str
) -> dict[str, bool]:
    """Sauts prévus si le run source est ``done`` avec artefacts complets."""
    src = (source_profile_id or "").strip().upper()
    tgt = (target_profile_id or "").strip().upper()
    si = profile_index(src)
    ti = profile_index(tgt)
    out = {
        "skip_eos": False,
        "skip_scf_eq": False,
        "skip_phonons": False,
        "skip_electronic": False,
    }
    if si < 0 or ti < 0 or ti <= si:
        return out
    tgt_needs = _PROFILE_NEEDS.get(tgt, {})
    if tgt_needs.get("needs_phonons") and si >= profile_index("P1"):
        out["skip_phonons"] = True
        out["skip_scf_eq"] = True
    if tgt_needs.get("needs_eos") and si >= profile_index("P2"):
        out["skip_eos"] = True
    if si >= profile_index("P1"):
        out["skip_electronic"] = True
    return out


def _excluded_runtime_steps(skips: dict[str, bool]) -> set[str]:
    excluded: set[str] = set()
    for flag, steps in _RUNTIME_STEPS_BY_SKIP.items():
        if skips.get(flag):
            excluded |= set(steps)
    return excluded


def _storage_component_skipped(name: str, skips: dict[str, bool]) -> bool:
    ln = (name or "").lower()
    for flag, markers in _STORAGE_NAME_MARKERS_BY_SKIP.items():
        if not skips.get(flag):
            continue
        for m in markers:
            if m.lower() in ln:
                return True
    return False


def estimate_upgrade_delta(
    *,
    source_profile_id: str,
    target_profile_id: str,
    runtime_full: Optional[dict[str, Any]],
    storage_full: Optional[dict[str, Any]],
) -> Optional[dict[str, Any]]:
    """Durée / disque additionnels si upgrade depuis ``source_profile_id``."""
    from runtime_estimate import humanize_seconds
    from storage_estimate import humanize_bytes

    skips = ideal_upgrade_skips(source_profile_id, target_profile_id)
    if not any(skips.values()):
        return None
    src = (source_profile_id or "").strip().upper()
    tgt = (target_profile_id or "").strip().upper()
    out: dict[str, Any] = {
        "source_profile_id": src,
        "target_profile_id": tgt,
        "skip_flags": dict(skips),
    }
    excluded = _excluded_runtime_steps(skips)
    if runtime_full and isinstance(runtime_full.get("steps"), list):
        kept = [
            s for s in runtime_full["steps"]
            if str(s.get("step") or "") not in excluded
        ]
        total = sum(float(s.get("seconds") or 0) for s in kept)
        if total <= 0:
            return None
        full_total = float(runtime_full.get("total_seconds") or 0) or total
        ratio = total / full_total if full_total > 0 else 0.5
        low = float(runtime_full.get("low_seconds") or total) * ratio
        high = float(runtime_full.get("high_seconds") or total) * ratio
        out["runtime"] = {
            "total_seconds": round(total, 1),
            "total_human": humanize_seconds(total),
            "range_human": (
                f"{humanize_seconds(low)} – {humanize_seconds(high)}"
            ),
            "confidence": runtime_full.get("confidence") or "moyenne",
            "dominant_step": (
                max(kept, key=lambda s: float(s.get("seconds") or 0)).get("step")
                if kept
                else ""
            ),
            "steps_kept": len(kept),
            "steps_skipped": len(excluded),
        }
    if storage_full and isinstance(storage_full.get("components"), list):
        kept_c = [
            c for c in storage_full["components"]
            if not _storage_component_skipped(str(c.get("name") or ""), skips)
        ]
        peak = sum(int(c.get("bytes") or 0) for c in kept_c)
        retained = sum(
            int(c.get("bytes") or 0)
            for c in kept_c
            if str(c.get("kind") or "") == "résultats"
        )
        if peak <= 0:
            peak = int(storage_full.get("peak_bytes") or 0) // 4
        out["storage"] = {
            "peak_bytes": peak,
            "peak_human": humanize_bytes(peak),
            "retained_bytes": retained,
            "retained_human": humanize_bytes(retained),
            "scratch_human": humanize_bytes(max(0, peak - retained)),
        }
    if "runtime" not in out and "storage" not in out:
        return None
    saved_seconds = 0.0
    if runtime_full and "runtime" in out:
        saved_seconds = max(
            0.0,
            float(runtime_full.get("total_seconds") or 0)
            - float(out["runtime"]["total_seconds"]),
        )
        out["runtime"]["saved_human"] = humanize_seconds(saved_seconds)
    if storage_full and "storage" in out:
        full_peak = int(storage_full.get("peak_bytes") or 0)
        out["storage"]["saved_peak_human"] = humanize_bytes(
            max(0, full_peak - int(out["storage"]["peak_bytes"]))
        )
    return out


def resolve_job_work_dir(job_dict: dict[str, Any], work_root: Path) -> Optional[Path]:
    wd_raw = str(job_dict.get("work_dir") or "").strip()
    if not wd_raw:
        return None
    try:
        p = Path(wd_raw).expanduser().resolve()
    except OSError:
        p = None
    if p is not None and p.is_dir():
        return p
    try:
        p2 = (work_root / wd_raw).resolve()
        if p2.is_dir():
            return p2
    except OSError:
        pass
    return None

"""Reprise partielle ``thermo_pw.x`` (P1–P5) sans refaire EOS / phonons.

Utilisé quand un job plante pendant ``thermo_pw`` (ou un extra P5 / optique)
alors que la chaîne phonon — voire la grille EOS — est déjà sur disque.
"""
from __future__ import annotations

import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from runtime_estimate import parse_thermo_qha_progress

QHA_PROFILES = frozenset({"P2", "P3", "P4"})

_RE_DYN_GEOM = re.compile(r"^ph_dyn\.g(\d+)\.")


@dataclass
class ResumeTarget:
    """Une cible de reprise exposée à l'UI."""

    target_id: str
    label: str
    detail: str
    recommended: bool = False
    qha_done: Optional[int] = None
    qha_total: Optional[int] = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "target_id": self.target_id,
            "label": self.label,
            "detail": self.detail,
            "recommended": self.recommended,
        }
        if self.qha_done is not None:
            out["qha_done"] = self.qha_done
        if self.qha_total is not None:
            out["qha_total"] = self.qha_total
        return out


@dataclass
class PrepareResult:
    actions: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {"actions": self.actions, "warnings": self.warnings}


def _count_dyn_per_geometry(wd: Path) -> dict[int, int]:
    counts: dict[int, int] = {}
    dyn = wd / "dynamical_matrices"
    if not dyn.is_dir():
        return counts
    for p in dyn.glob("ph_dyn.g*"):
        m = _RE_DYN_GEOM.match(p.name)
        if m:
            gi = int(m.group(1))
            counts[gi] = counts.get(gi, 0) + 1
    return counts


def _finished_qha_geometries(wd: Path) -> set[int]:
    finished: set[int] = set()
    therm = wd / "therm_files"
    if not therm.is_dir():
        return finished
    for p in therm.glob("output_therm.dat.g*"):
        m = re.search(r"\.g(\d+)$", p.name)
        if m:
            finished.add(int(m.group(1)))
    return finished


def prepare_work_dir_for_resume(
    work_dir: Path,
    *,
    profile_id: str,
    target: str,
) -> PrepareResult:
    """Nettoie l'état partiel/corrompu avant une reprise ``thermo_pw``.

    * ``restart/`` — toujours purgé (crash FFT / EOF fréquent).
    * Profils QHA (P2–P4) + cible ``thermo_main`` : supprime la géométrie
      courante incomplète (pas de ``output_therm.dat.gN`` mais des
      ``ph_dyn.gN.*`` partiels).
    """
    wd = Path(work_dir)
    res = PrepareResult()

    restart = wd / "restart"
    if restart.is_dir():
        try:
            shutil.rmtree(restart)
            res.actions.append("restart/ supprimé (état de reprise corrompu)")
        except OSError as ex:
            res.warnings.append(f"impossible de supprimer restart/ : {ex}")

    if profile_id in QHA_PROFILES and target == "thermo_main":
        finished = _finished_qha_geometries(wd)
        counts = _count_dyn_per_geometry(wd)
        per_complete = max(counts.get(g, 0) for g in finished) if finished else 0
        prog = parse_thermo_qha_progress(wd)
        total = prog.get("geometries_total")

        pending = [
            g for g, n in counts.items()
            if g not in finished and n > 0
        ]
        if pending:
            g_bad = max(pending)
        elif counts and finished:
            # Géométrie suivante pas encore commencée — rien à purger.
            g_bad = None
        else:
            g_bad = None

        if g_bad is not None:
            n_bad = counts.get(g_bad, 0)
            incomplete = per_complete == 0 or n_bad < per_complete
            if incomplete:
                dyn = wd / "dynamical_matrices"
                removed = 0
                for p in dyn.glob(f"ph_dyn.g{g_bad}.*"):
                    try:
                        p.unlink()
                        removed += 1
                    except OSError:
                        pass
                ph0 = wd / "out_scf_eq" / f"g{g_bad}" / "_ph0"
                if ph0.is_dir():
                    try:
                        shutil.rmtree(ph0)
                        res.actions.append(
                            f"out_scf_eq/g{g_bad}/_ph0 supprimé (géom. incomplète)"
                        )
                    except OSError as ex:
                        res.warnings.append(f"purge g{g_bad}/_ph0 : {ex}")
                if removed:
                    ref = per_complete or "?"
                    res.actions.append(
                        f"géométrie QHA {g_bad}/{total or '?'} : "
                        f"{removed} matrice(s) partielle(s) effacée(s) "
                        f"(attendu ≈{ref} pour une géom. complète)"
                    )

    return res


def list_resume_targets(
    *,
    profile_id: str,
    work_dir: Path,
    extra_whats: Optional[list[str]] = None,
    needs_optical: bool = False,
    lo_to_opt_in: bool = False,
    results: Optional[dict[str, Any]] = None,
) -> list[ResumeTarget]:
    """Cibles de reprise disponibles pour ce profil / dossier."""
    wd = Path(work_dir)
    targets: list[ResumeTarget] = []
    results = results or {}

    qha_done: Optional[int] = None
    qha_total: Optional[int] = None
    qha_detail = ""
    if profile_id in QHA_PROFILES:
        prog = parse_thermo_qha_progress(wd)
        qha_done = int(prog.get("geometries_done") or 0)
        qha_total = prog.get("geometries_total")
        if qha_total:
            qha_detail = (
                f" — {qha_done}/{qha_total} géométrie(s) QHA déjà terminée(s) "
                "seront conservée(s)"
            )

    main_label = {
        "P1": "thermo_pw (C_ij, scf_elastic_constants)",
        "P2": "thermo_pw QHA (mur_lc_t)",
        "P3": "thermo_pw QHA + élasticité (elastic_constants_geo)",
        "P4": "thermo_pw (ph_life)",
        "P5": "ε∞ + Born (depuis ph.out, pas thermo_pw 7.5)",
    }.get(profile_id, "thermo_pw")

    targets.append(
        ResumeTarget(
            target_id="thermo_main",
            label=f"Reprendre {main_label}",
            detail=(
                "Ignore EOS et phonons déjà terminés ; relance uniquement "
                f"``thermo_pw.x`` puis les étapes aval (DOS/bandes, optique…)."
                + qha_detail
            ),
            recommended=True,
            qha_done=qha_done,
            qha_total=qha_total,
        )
    )

    if profile_id == "P5":
        extras = list(extra_whats or [])
        te = results.get("thermo_extras") or {}
        for what in extras:
            ok = (te.get(what) or {}).get("ok")
            if ok is True:
                continue
            from thermo_what_catalog import get_catalog_entry

            entry = get_catalog_entry(what)
            label = entry.label if entry else what
            targets.append(
                ResumeTarget(
                    target_id=f"thermo_extra:{what}",
                    label=f"Extra thermo_pw : {label}",
                    detail=(
                        f"Relance seulement ``what={what}`` "
                        f"(journal thermo_pw_{what}.out)."
                    ),
                    recommended=False,
                )
            )
        if needs_optical:
            op = results.get("optical_props") or {}
            if not op.get("epsilon_ok"):
                targets.append(
                    ResumeTarget(
                        target_id="optical",
                        label="Chaîne optique ε(ω)",
                        detail=(
                            "Relance epsilon.x + turbo_lanczos + turbo_davidson "
                            "(phonons et dielectric supposés OK)."
                        ),
                        recommended=False,
                    )
                )

    if profile_id == "P1" and lo_to_opt_in:
        die = results.get("dielectric") or {}
        if not die.get("lo_to_splitting_cm-1"):
            targets.append(
                ResumeTarget(
                    target_id="lo_to",
                    label="Correction LO/TO (opt-in)",
                    detail="Chaîne dielectric → BORN → matdyn non_analytique.",
                    recommended=False,
                )
            )

    return targets


def validate_target_for_profile(
    profile_id: str,
    target: str,
    *,
    extra_whats: Optional[list[str]] = None,
    needs_optical: bool = False,
    lo_to_opt_in: bool = False,
) -> None:
    """Lève ``ValueError`` si la cible est incohérente avec le profil."""
    allowed = {
        t.target_id
        for t in list_resume_targets(
            profile_id=profile_id,
            work_dir=Path("."),
            extra_whats=extra_whats,
            needs_optical=needs_optical,
            lo_to_opt_in=lo_to_opt_in,
        )
    }
    # list_resume_targets with dummy wd still returns thermo_main; extras need real wd
    base = {"thermo_main", "optical", "lo_to"}
    if target in base:
        if target == "optical" and profile_id != "P5":
            raise ValueError("La reprise optique n'est disponible que pour P5.")
        if target == "lo_to" and profile_id != "P1":
            raise ValueError("La reprise LO/TO n'est disponible que pour P1.")
        return
    if target.startswith("thermo_extra:"):
        if profile_id != "P5":
            raise ValueError("Les extras thermo_pw ne s'appliquent qu'au profil P5.")
        what = target.split(":", 1)[1]
        if extra_whats and what not in extra_whats:
            raise ValueError(f"Extra {what!r} absent de la sélection du job.")
        return
    raise ValueError(f"Cible de reprise inconnue : {target!r}")


def phonon_prereqs_ok(work_dir: Path) -> tuple[bool, str]:
    """Vérifie minimalement que la chaîne phonon est utilisable."""
    wd = Path(work_dir)
    if not (wd / "ph.out").is_file():
        return False, "ph.out absent — relancez la chaîne phonon complète."
    if not (wd / "fc.out").is_file():
        return False, "fc.out absent — relancez q2r/matdyn."
    pw = wd / "pw_scf_V0_for_phonon.in"
    if not pw.is_file() and not (wd / "scf.in").is_file():
        return False, "pw_scf_V0_for_phonon.in / scf.in absent."
    return True, ""


def logs_indicate_qha_least_squares_failure(text: str) -> bool:
    """True si le texte journal signale un échec moindres carrés QHA."""
    tl = (text or "").lower()
    return (
        "dgels" in tl
        or "dgelss" in tl
        or "linsolvms" in tl
        or "linsolvsvd" in tl
        or "parameter 7 was incorrect" in tl
        or "parameter 6 was incorrect" in tl
    )


def detect_qha_least_squares_failure(work_dir: Path) -> bool:
    """True si le journal thermo_pw signale un échec moindres carrés QHA."""
    wd = Path(work_dir)
    log = wd / "thermo_pw_run.out"
    if not log.is_file():
        return False
    try:
        tail = log.read_text(encoding="utf-8", errors="replace")[-120_000:]
    except OSError:
        return False
    return logs_indicate_qha_least_squares_failure(tail)


# Mode thermodynamique par défaut (aligné sur ``PROFILES[*]['thermo_opts']``).
_PROFILE_DEFAULT_THERM_MODE: dict[str, str] = {
    "P2": "dos",
    "P3": "dos",
    "P4": "freq",  # ltherm_dos=False — ph_life / fréquences phonons
}


def default_therm_mode_for_profile(profile_id: str) -> Optional[str]:
    """``dos`` | ``freq`` | None si profil hors QHA."""
    if profile_id not in QHA_PROFILES:
        return None
    return _PROFILE_DEFAULT_THERM_MODE.get(profile_id, "dos")


def read_thermo_control_qha_hints(work_dir: Path) -> dict[str, Any]:
    """Lit deltat / ltherm_* depuis ``thermo_control`` si présent."""
    wd = Path(work_dir)
    tc = wd / "thermo_control"
    out: dict[str, Any] = {}
    if not tc.is_file():
        return out
    try:
        text = tc.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return out
    m = re.search(r"(?im)^\s*deltat\s*=\s*([0-9.+-DEd]+)", text)
    if m:
        try:
            out["deltat"] = float(m.group(1).replace("D", "E").replace("d", "e"))
        except ValueError:
            pass
    for key in ("ltherm_dos", "ltherm_freq"):
        m2 = re.search(rf"(?im)^\s*{key}\s*=\s*(\.true\.|\.false\.|true|false)", text)
        if m2:
            out[key] = ".true." in m2.group(1).lower() or m2.group(1).lower() == "true"
    m3 = re.search(r"(?im)^\s*lsolve\s*=\s*([0-9]+)", text)
    if m3:
        try:
            out["lsolve"] = int(m3.group(1))
        except ValueError:
            pass
    return out


def validate_lsolve(value: Any) -> Optional[int]:
    """Normalise ``lsolve`` (1, 2 ou 3) ou lève ``ValueError``."""
    if value is None or value == "":
        return None
    n = int(value)
    if n not in (1, 2, 3):
        raise ValueError(f"lsolve doit être 1, 2 ou 3 (reçu {n}).")
    return n


def validate_deltat(value: Any) -> Optional[float]:
    """Normalise ``deltat`` (K) pour la grille QHA."""
    if value is None or value == "":
        return None
    dt = float(value)
    if dt <= 0 or dt > 500:
        raise ValueError(f"deltat doit être entre 0 et 500 K (reçu {dt}).")
    return dt


def validate_therm_source(
    *,
    ltherm_dos: Any = None,
    ltherm_freq: Any = None,
) -> tuple[Optional[bool], Optional[bool]]:
    """Valide le couple DOS/fréquences (mutuellement exclusif)."""
    dos = ltherm_dos
    freq = ltherm_freq
    if dos is None and freq is None:
        return None, None
    if dos is None and freq is not None:
        dos = not bool(freq)
    if freq is None and dos is not None:
        freq = not bool(dos)
    dos_b = bool(dos)
    freq_b = bool(freq)
    if dos_b and freq_b:
        raise ValueError("ltherm_dos et ltherm_freq ne peuvent pas être true simultanément.")
    if not dos_b and not freq_b:
        raise ValueError("Activez ltherm_dos ou ltherm_freq pour la thermodynamique QHA.")
    return dos_b, freq_b


def parse_resume_thermo_overrides(
    data: dict[str, Any],
    *,
    profile_id: str,
) -> dict[str, Any]:
    """Filtre les overrides thermo_pw acceptés pour une reprise."""
    if profile_id not in QHA_PROFILES:
        lsolve = validate_lsolve(data.get("lsolve"))
        if lsolve is not None:
            raise ValueError(
                f"lsolve ne s'applique qu'aux profils QHA "
                f"({', '.join(sorted(QHA_PROFILES))})."
            )
        if any(k in data for k in ("deltat", "ltherm_dos", "ltherm_freq")):
            raise ValueError(
                "deltat / ltherm_dos / ltherm_freq ne s'appliquent qu'aux profils QHA."
            )
        return {}

    out: dict[str, Any] = {}
    lsolve = validate_lsolve(data.get("lsolve"))
    if lsolve is not None:
        out["lsolve"] = lsolve
    deltat = validate_deltat(data.get("deltat"))
    if deltat is not None:
        out["deltat"] = deltat
    dos_raw = data.get("ltherm_dos")
    freq_raw = data.get("ltherm_freq")
    therm_mode = str(data.get("therm_mode") or "").strip().lower()
    if therm_mode == "dos":
        dos_raw, freq_raw = True, False
    elif therm_mode == "freq":
        dos_raw, freq_raw = False, True
    dos, freq = validate_therm_source(ltherm_dos=dos_raw, ltherm_freq=freq_raw)
    if dos is not None:
        out["ltherm_dos"] = dos
    if freq is not None:
        out["ltherm_freq"] = freq
    return out

"""
Propriétés optiques — chaîne Quantum ESPRESSO opt-in pour le profil P5.

Complément de ``electronic_props.py`` orienté absorption / indice complexe /
réponse linéaire et TDDFPT. Orchestration opt-in du profil P5
(``needs_optical_overridable=True`` : epsilon.x + turbo_lanczos + turbo_davidson).

Trois chaînes optiques complémentaires, **toutes** exécutées après la même
étape ``NSCF_optic`` (un seul restart sur les fonctions d'onde Kohn-Sham) :

  1. **``epsilon.x``** — réponse linéaire IPA/RPA (Independent-Particle /
     Random-Phase Approximation). Produit ε₁(ω), ε₂(ω), JDOS, α(ω), EELS.
     *C'est la voie rapide, sans effets excitoniques.*
  2. **``turbo_lanczos.x``** — TDDFPT Lanczos. Polarizability χ(ω) complète
     avec correction TDDFPT (noyaux XC dynamique via adiabatic LDA/GGA).
     Capture les **effets excitoniques** (résonances ω→ε⁻¹) et l'absorption
     au-dessus du gap (avec décalage vers le rouge vs IPA/RPA).
  3. **``turbo_davidson.x``** — TDDFPT Davidson sur une fenêtre spectrale.
     Spectre d'absorption sélectif [start, finish] (par défaut [0, 2] eV
     pour la fenêtre visible), état par état — utile pour identifier les
     transitions dominantes.

Toutes les trois lisent le même ``<prefix>.save/`` produit par la NSCF_optic
(``restart_mode='restart'``) : un seul calcul lourd partagé, ROI maximal.

**Note de nomenclature (juin 2026) :** ``epsilon.x`` ≠ TDDFPT stricto sensu.
Pour la TDDFPT complète (avec kernel XC dynamique), il faut explicitement
les exécutables ``turbo_lanczos.x`` / ``turbo_davidson.x`` de la suite QE
turbo/tddfpt, désormais inclus dans P5.

Pré-requis matériel :
  * Le SCF d'équilibre (``scf.in`` pour P5) **doit** contenir
    ``wf_collect = .true.`` ; ``inject_wf_collect`` (re-exporté depuis
    ``electronic_props``) gère l'injection à la volée.
  * Grille K_POINTS automatic densifiée (ré-utilise ``densify_kpoints_for_nscf``).
  * nbnd doublé pour récupérer suffisamment d'états vides : contrainte
    QE pour décrire transitions inter-bandes jusqu'à la coupure ``wmax``
    renseignée à ``epsilon.x`` (~15 eV). QE recommande souvent ×2 ou « nat × 16 »
    pour la chimie inorganique typique (cf. optique_tddft_tutorial).
  * **Pseudos Norm-Conserving uniquement** — epsilon.x et la chaîne turbo
    n'acceptent pas les pseudos ultra-doux / PAW sans commutateur
    spécifique. Le profil P5 documente cette contrainte dans
    ``params_summary`` ; l'absence de NC n'est pas une erreur fatale mais
    produira un [WARN] si une sous-étape échoue côté QE.

Mesures défensives côté Python :
  * ``wf_collect = .true.`` injecté à la volée si absent.
  * ``nosym = .true.`` et ``noinv = .true.`` imposés sur la NSCF optique
    (réduit la symétrie k-points — utile pour epsilon.x sur petites BZ).
  * **Tolérance aux binaires manquants** : si ``epsilon.x``,
    ``turbo_lanczos.x`` ou ``turbo_davidson.x`` n'est pas compilé/installé,
    la sous-étape concernée est ignorée avec un ``[WARN]`` propre (pas
    d'erreur fatale — l'utilisateur peut travailler sans la chaîne
    complète, ou la recompiler).
  * Si le SCF force ``wf_collect = .false.`` explicitement, on saute
    toute la chaîne (cf. comportement symétrique dans electronic_props).
"""
from __future__ import annotations

import os
import re
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import config as cfg
from qe_subprocess import run_pw_x_in, run_qe_stdin
from electronic_props import (
    _force_set_kv,
    _read_pw_in,
    densify_kpoints_for_nscf,
    force_kpoints_gamma,
    inject_wf_collect,
    check_wf_collect_explicit_false,
)


# ============================================================================
# Constantes & seuils
# ============================================================================

# nbnd par défaut pour la NSCF optique :
# - ×2 le nbnd SCF (cas standard QE) ;
# - ou ``nat × 16`` plancher (~8 bandes de conduction par atome, typique
#   pour absorb jusqu'à wmax ~ 15 eV sur inorganique usuel) ;
# - minimum absolu 20 (casPETit système : sécurité).
OPTIC_NBND_MULTIPLIER = 2
OPTIC_NBND_PER_ATOM = 16
OPTIC_NBND_MIN = 20

# Grille énergétique epsilon.x par défaut (eV) — couvre le visible + UV proche.
EPSILON_WMIN_EV = 0.0
EPSILON_WMAX_EV = 15.0
EPSILON_NW = 300
# Smearing inter-bandes (eV) — 0.136 eV = 1000 cm⁻¹ ≈ instrument IR standard.
EPSILON_INTERMEAR_EV = 0.136

# --- turbo_lanczos.x (TDDFPT / réponse complète χ(ω)) -------------------
# Paramètres raisonnables pour inorganique standard (cf. QE INPUT_Lanczos).
# * ``itermax`` = 500 itérations Lanczos (suffit convergence typique).
# * ``ipol = 4`` = « trace » de χ (somme xx + yy + zz) = absorption moyenne
#   polycristalline (« average over cartesian directions »).
TURBO_LANCZOS_ITERMAX = 500
TURBO_LANCZOS_IPOL = 4

# --- turbo_davidson.x (TDDFPT / spectre fenêtre [start, finish]) --------
# Paramètres raisonnables pour spectre visible proche UV (2 eV max).
# * ``residue_conv_thr = 1.0d-5`` = critère convergence serré.
# * ``max_iter = 120`` = limite itérations Davidson par état.
# * Fenêtre [0, 2] eV, pas 0.002 eV (1000 points sur le visible).
TURBO_DAVIDSON_RESIDUE_CONV_THR = "1.0d-5"
TURBO_DAVIDSON_MAX_ITER = 120
TURBO_DAVIDSON_START_EV = 0.0
TURBO_DAVIDSON_FINISH_EV = 2.0
TURBO_DAVIDSON_STEP_EV = 0.002


# ============================================================================
# Génération des fichiers d'entrée
# ============================================================================


def write_nscf_optic_in(work_dir: Path, scf_basename: str) -> Path:
    """Génère ``nscf_optic.in`` à partir du SCF équilibre.

    Différences avec ``electronic_props.write_nscf_in`` :
      * ``nosym = .true.`` et ``noinv = .true.`` (cf. tutoriel
        optics_QE : la symétrie k-points peut fausser ε pour petites BZ).
      * ``nbnd`` doublé (ressemble à la pratique standard Turbo/epsilon).
      * ``occupations='smearing'`` conservé (utile pour les métaux où
        la population thermique des bandes vaut epsilon.x en pratique).

    Ré-utilise ``inject_wf_collect`` et ``densify_kpoints_for_nscf``
    d'electronic_props pour rester cohérent avec la chaîne ichamp=3.
    """
    scf_src = work_dir / scf_basename
    if not scf_src.is_file():
        raise FileNotFoundError(f"{scf_basename} absent dans {work_dir}")
    text = _read_pw_in(scf_src)
    # 1. calculation + restart_mode
    text = _force_set_kv(text, "calculation", "'nscf'", block_name="CONTROL")
    text = _force_set_kv(text, "restart_mode", "'restart'", block_name="CONTROL")
    # 2. Pseudos NC + epsilon.x : nosym et noinv quasi obligatoires.
    text = _force_set_kv(text, "nosym", ".true.", block_name="SYSTEM")
    text = _force_set_kv(text, "noinv", ".true.", block_name="SYSTEM")
    # 3. nbnd doublé
    m_nbnd = re.search(r"(?im)^\s*nbnd\s*=\s*(\d+)", text)
    m_nat = re.search(r"(?im)^\s*nat\s*=\s*(\d+)", text)
    nbnd_now = int(m_nbnd.group(1)) if m_nbnd else None
    nat = int(m_nat.group(1)) if m_nat else None
    target_nbnd = max(
        (nbnd_now or 0) * OPTIC_NBND_MULTIPLIER,
        (nat or 0) * OPTIC_NBND_PER_ATOM,
        OPTIC_NBND_MIN,
    )
    if nbnd_now is None or nbnd_now < target_nbnd:
        text = _force_set_kv(text, "nbnd", str(target_nbnd), block_name="SYSTEM")
    # 4. wf_collect + grille K densifiée (ré-exportés d'electronic_props)
    text, _ch, _sk = inject_wf_collect(text)
    text = densify_kpoints_for_nscf(text)
    target = work_dir / "nscf_optic.in"
    target.write_text(text, encoding="utf-8")
    return target


def write_nscf_turbo_gamma_in(work_dir: Path, scf_basename: str) -> Path:
    """Génère ``nscf_turbo_gamma.in`` — NSCF à Γ seule pour turboTDDFT.

    Même préparation que ``write_nscf_optic_in`` (nbnd, nosym, noinv,
    wf_collect) mais ``K_POINTS gamma`` au lieu d'une grille Monkhorst-Pack.
    À lancer **après** ``epsilon.x`` (qui consomme la NSCF dense) et **avant**
    ``turbo_lanczos.x`` / ``turbo_davidson.x``.
    """
    scf_src = work_dir / scf_basename
    if not scf_src.is_file():
        raise FileNotFoundError(f"{scf_basename} absent dans {work_dir}")
    text = _read_pw_in(scf_src)
    text = _force_set_kv(text, "calculation", "'nscf'", block_name="CONTROL")
    text = _force_set_kv(text, "restart_mode", "'restart'", block_name="CONTROL")
    text = _force_set_kv(text, "nosym", ".true.", block_name="SYSTEM")
    text = _force_set_kv(text, "noinv", ".true.", block_name="SYSTEM")
    m_nbnd = re.search(r"(?im)^\s*nbnd\s*=\s*(\d+)", text)
    m_nat = re.search(r"(?im)^\s*nat\s*=\s*(\d+)", text)
    nbnd_now = int(m_nbnd.group(1)) if m_nbnd else None
    nat = int(m_nat.group(1)) if m_nat else None
    target_nbnd = max(
        (nbnd_now or 0) * OPTIC_NBND_MULTIPLIER,
        (nat or 0) * OPTIC_NBND_PER_ATOM,
        OPTIC_NBND_MIN,
    )
    if nbnd_now is None or nbnd_now < target_nbnd:
        text = _force_set_kv(text, "nbnd", str(target_nbnd), block_name="SYSTEM")
    text, _ch, _sk = inject_wf_collect(text)
    text = force_kpoints_gamma(text)
    target = work_dir / "nscf_turbo_gamma.in"
    target.write_text(text, encoding="utf-8")
    return target


def write_epsilon_in(
    work_dir: Path,
    *,
    prefix: str,
    wmin: float = EPSILON_WMIN_EV,
    wmax: float = EPSILON_WMAX_EV,
    nw: int = EPSILON_NW,
    intersmear: float = EPSILON_INTERMEAR_EV,
) -> Path:
    """Écrit ``epsilon.in`` qui demande à ``epsilon.x`` de calculer la
    fonction diélectrique ε(ω) + JDOS + EELS sur la grille [wmin, wmax].

    Les valeurs par défaut couvrent l'UV-visible (0–15 eV) avec un
    smearing instrumental de 0.136 eV (≈ 1000 cm⁻¹).
    """
    body = (
        " &inputpp\n"
        f"  outdir = './out/'\n"
        f"  prefix = '{prefix}'\n"
        "  calculation = 'eps'\n"
        " /\n"
        " &energy_grid\n"
        "  smeartype = 'gauss'\n"
        f"  intersmear = {intersmear:.4f}\n"
        f"  wmin = {wmin:.6f}\n"
        f"  wmax = {wmax:.6f}\n"
        f"  nw = {nw}\n"
        " /\n"
    )
    p = work_dir / "epsilon.in"
    p.write_text(body, encoding="utf-8")
    return p


def write_turbo_lanczos_in(
    work_dir: Path,
    *,
    prefix: str,
    itermax: int = TURBO_LANCZOS_ITERMAX,
    ipol: int = TURBO_LANCZOS_IPOL,
) -> Path:
    """Écrit ``turbo_lanczos.in`` pour ``turbo_lanczos.x`` (TDDFPT Lanczos).

    Paramètres choisis pour inorganique standard :
      * ``itermax = 500`` itérations Lanczos (convergence typique).
      * ``ipol = 4`` = trace χ (somme cartésienne) → absorption moyenne
        polycristalline (utile quand on n'a pas d'orientation cristalline).

    Pré-requis : la NSCF_optic a écrit ``<prefix>.save/`` sur disque ;
    ``restart_mode='restart'`` est implicite (le fichier de wf est relu).
    """
    body = (
        " &lr_input\n"
        f"  prefix = '{prefix}'\n"
        "  outdir = './out/'\n"
        " /\n"
        " &lr_control\n"
        f"  itermax = {itermax}\n"
        f"  ipol = {ipol}\n"
        " /\n"
    )
    p = work_dir / "turbo_lanczos.in"
    p.write_text(body, encoding="utf-8")
    return p


def write_turbo_davidson_in(
    work_dir: Path,
    *,
    prefix: str,
    residue_conv_thr: str = TURBO_DAVIDSON_RESIDUE_CONV_THR,
    max_iter: int = TURBO_DAVIDSON_MAX_ITER,
    start_eV: float = TURBO_DAVIDSON_START_EV,
    finish_eV: float = TURBO_DAVIDSON_FINISH_EV,
    step_eV: float = TURBO_DAVIDSON_STEP_EV,
) -> Path:
    """Écrit ``turbo_davidson.in`` pour ``turbo_davidson.x`` (TDDFPT Davidson).

    Spectre d'absorption sur fenêtre restreinte [start, finish] eV
    (défaut : [0, 2] eV = visible). Calcule les transitions dominantes
    état par état, utile pour analyser les pics d'absorption.

    ``residue_conv_thr`` est passé en chaîne Fortran-like (« 1.0d-5 ») car
    QE lit directement cette notation dans ``&lr_dav``.
    """
    body = (
        " &lr_input\n"
        f"  prefix = '{prefix}'\n"
        "  outdir = './out/'\n"
        " /\n"
        " &lr_dav\n"
        f"  residue_conv_thr = {residue_conv_thr}\n"
        f"  max_iter = {max_iter}\n"
        f"  start = {start_eV:.4f}d0\n"
        f"  finish = {finish_eV:.4f}d0\n"
        f"  step = {step_eV:.4f}d0\n"
        " /\n"
    )
    p = work_dir / "turbo_davidson.in"
    p.write_text(body, encoding="utf-8")
    return p


# ============================================================================
# Dataclass résultat
# ============================================================================


@dataclass
class OpticalPropsResult:
    """Résultat détaillé de la chaîne optique complète (utilisé pour marker JSON + UI).

    Champs couvrent les **3 exécutables optiques QE** orchestrés depuis P5 :
      * ``nscf_optic_*`` : NSCF optique (préparatoire commun).
      * ``epsilon_*``    : epsilon.x (DFPT linéaire IPA/RPA).
      * ``turbo_lanczos_*`` : turbo_lanczos.x (TDDFPT Lanczos + χ(ω) complète).
      * ``turbo_davidson_*`` : turbo_davidson.x (TDDFPT Davidson fenêtre spectrale).
    """

    nscf_optic_ok: bool = False
    epsilon_ok: bool = False
    nscf_optic_in: Optional[str] = None
    epsilon_in: Optional[str] = None
    nscf_optic_nbnd: Optional[int] = None
    nscf_turbo_gamma_ok: bool = False
    nscf_turbo_gamma_in: Optional[str] = None
    eps_dat_files: list = None  # type: ignore[assignment]
    turbo_lanczos_ok: bool = False
    turbo_davidson_ok: bool = False
    turbo_lanczos_in: Optional[str] = None
    turbo_davidson_in: Optional[str] = None
    turbo_dat_files: list = None  # type: ignore[assignment]
    notes: list = None  # type: ignore[assignment]

    def to_dict(self) -> dict[str, Any]:
        return {
            "nscf_optic_ok": self.nscf_optic_ok,
            "epsilon_ok": self.epsilon_ok,
            "nscf_optic_in": self.nscf_optic_in,
            "epsilon_in": self.epsilon_in,
            "nscf_optic_nbnd": self.nscf_optic_nbnd,
            "nscf_turbo_gamma_ok": self.nscf_turbo_gamma_ok,
            "nscf_turbo_gamma_in": self.nscf_turbo_gamma_in,
            "eps_dat_files": list(self.eps_dat_files or []),
            "turbo_lanczos_ok": self.turbo_lanczos_ok,
            "turbo_davidson_ok": self.turbo_davidson_ok,
            "turbo_lanczos_in": self.turbo_lanczos_in,
            "turbo_davidson_in": self.turbo_davidson_in,
            "turbo_dat_files": list(self.turbo_dat_files or []),
            "notes": list(self.notes or []),
        }


# ============================================================================
# Helpers bas niveau
# ============================================================================


def _looks_like_executable(p: Path) -> bool:
    """Un binaire QE « présent » = fichier régulier non vide + exécutable."""
    if not p.is_file():
        return False
    if p.stat().st_size < 100:
        return False
    return True


def _extract_prefix_from_text(text: str) -> str:
    """Récupère ``prefix = '...'`` dans une namelist QE (défaut 'pw_scf')."""
    m = re.search(r"(?im)^\s*prefix\s*=\s*['\"]?([^,'\"\s]+)", text)
    return m.group(1) if m else "pw_scf"


def _list_eps_dat_files(work_dir: Path) -> list[str]:
    """Liste tous les fichiers epsNN_/eelsNN_/jdos_ .dat écrits par epsilon.x.

    QE produit typiquement ``epsNN_l_M.dat``, ``eelsNN_l_M.dat``,
    ``jdos_l_M.dat`` (N = composante tensorielle cartésienne 1/2/3,
    l = canal, M = nb maximal d'instructions G).
    """
    found: list[str] = []
    try:
        candidates = sorted(set(
            list(work_dir.glob("eps*.dat"))
            + list(work_dir.glob("eels*.dat"))
            + list(work_dir.glob("jdos*.dat"))
        ))
    except OSError:
        return found
    for p in candidates:
        if p.is_file():
            try:
                rel = str(p.relative_to(work_dir))
            except ValueError:
                rel = p.name
            found.append(rel)
    return found


def _list_turbo_dat_files(work_dir: Path) -> list[str]:
    """Liste les fichiers .dat écrits par ``turbo_lanczos.x`` / ``turbo_davidson.x``.

    turbo_lanczos.x / turbo_davidson.x produisent typiquement :
      * ``chi.dat`` — polarizability χ(ω) complète (somme ou composantes).
      * ``eigenvalues*.dat`` — énergies propres TDDFPT (Davidson surtout).
      * ``polarizability*.dat`` — variante χ(ω).
      * ``spectrum*.dat`` — spectre d'absorption reconstruit.
      * ``turbo*.dat`` — fichiers de post-traitement turbo génériques.

    Les fichiers ``eps*/eels*/jdos*.dat`` (epsilon.x) sont **exclus** —
    déjà comptabilisés par ``_list_eps_dat_files``. Évite les doublons UI.
    """
    found: list[str] = []
    eps_names: set[str] = set()
    try:
        eps_names = {p.name for p in [
            *(work_dir.glob("eps*.dat")),
            *(work_dir.glob("eels*.dat")),
            *(work_dir.glob("jdos*.dat")),
        ]}
    except OSError:
        eps_names = set()
    try:
        candidates = sorted(set(
            list(work_dir.glob("chi*.dat"))
            + list(work_dir.glob("eigenvalues*.dat"))
            + list(work_dir.glob("polarizability*.dat"))
            + list(work_dir.glob("spectrum*.dat"))
            + list(work_dir.glob("turbo*.dat"))
        ))
    except OSError:
        return found
    for p in candidates:
        if not p.is_file():
            continue
        if p.name in eps_names:
            continue
        try:
            rel = str(p.relative_to(work_dir))
        except ValueError:
            rel = p.name
        found.append(rel)
    return found


# ============================================================================
# Orchestrateur principal
# ============================================================================


def run_optical_properties(
    work_dir: Path,
    *,
    nproc: int,
    scf_basename: str,
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
    log_emit: Optional[callable] = None,
    wmin: float = EPSILON_WMIN_EV,
    wmax: float = EPSILON_WMAX_EV,
    nw: int = EPSILON_NW,
    intersmear: float = EPSILON_INTERMEAR_EV,
) -> OpticalPropsResult:
    """Orchestre la chaîne optique ``NSCF_optic → epsilon.x`` pour P5.

    * ``scf_basename`` : nom du SCF d'équilibre (``scf.in`` pour P5, qui ne
      lance pas d'EOS, donc ``pw_scf_V0_for_phonon.in`` n'existe pas).
    * ``log_emit`` : callback callable (typiquement ``PipelineJob._append_log``).

    Renvoie un ``OpticalPropsResult`` TOUJOURS, même si une sous-étape
    échoue — les erreurs sont consignées dans ``notes`` et le résultat
    partiel reste consommable par le marker JSON du job.
    """
    res = OpticalPropsResult(
        eps_dat_files=[], turbo_dat_files=[], notes=[]
    )
    log = log_emit or (lambda _msg: None)

    def note(msg: str) -> None:
        res.notes.append(msg)
        try:
            log(msg)
        except Exception:  # noqa: BLE001
            pass

    work_dir = Path(work_dir).expanduser().resolve()

    # --- Préconditions ----------------------------------------------------
    scf_path = work_dir / scf_basename
    if not scf_path.is_file():
        note(f"[OPTIC] {scf_basename} absent — propriétés optiques sautées.")
        return res

    pw_x = cfg.pw_path()
    if not _looks_like_executable(pw_x):
        note(f"[OPTIC] pw.x manquant ou vide ({pw_x}) — propriétés optiques sautées.")
        return res

    epsilon_x = cfg.epsilon_path()
    if not _looks_like_executable(epsilon_x):
        note(
            f"[OPTIC] epsilon.x manquant ou vide ({epsilon_x}) — "
            "chaîne optique NON exécutée. Vérifiez THERMO_EPSILON ou "
            "l'installation QE (paquet turbo/tddfpt)."
        )
        return res

    try:
        scf_text = scf_path.read_text(encoding="utf-8", errors="replace")
    except OSError as ex:
        note(f"[OPTIC] lecture {scf_basename} : {ex} — propriétés optiques sautées.")
        return res
    if check_wf_collect_explicit_false(scf_text):
        note(
            "[OPTIC] ATTENTION : SCF équilibre contient « wf_collect = .false. » "
            "explicite. NSCF_optic et epsilon.x reposent sur les fonctions "
            "d'onde sérialisées (restart_mode='restart'). La chaîne optique "
            "est donc COURT-CIRCUITÉE. Passez « wf_collect = .true. » "
            "dans le SCF pour activer ε(ω)."
        )
        return res

    # --- 1. NSCF_optic ----------------------------------------------------
    try:
        nscf_path = write_nscf_optic_in(work_dir, scf_basename)
        res.nscf_optic_in = nscf_path.name
        # Récupération du nbnd résultant pour info dans le marker JSON.
        try:
            m_nbnd = re.search(
                r"(?im)^\s*nbnd\s*=\s*(\d+)",
                nscf_path.read_text(encoding="utf-8", errors="replace"),
            )
            if m_nbnd:
                res.nscf_optic_nbnd = int(m_nbnd.group(1))
        except (OSError, ValueError):
            pass
        note(f"[OPTIC] nscf_optic.in écrit (nbnd={res.nscf_optic_nbnd}).")
    except Exception as ex:  # noqa: BLE001
        note(f"[OPTIC] write_nscf_optic_in : {ex} — propriétés optiques sautées.")
        return res

    try:
        log(f"[OPTIC] Lancement pw.x NSCF_optic (nproc={nproc}).")
        run_pw_x_in(
            work_dir, "nscf_optic.in", nproc=nproc,
            cancel_event=cancel_event, proc_holder=proc_holder,
        )
        res.nscf_optic_ok = True
        note("[OPTIC] NSCF_optic terminé (états vides disponibles).")
    except Exception as ex:  # noqa: BLE001
        if cancel_event is not None and cancel_event.is_set():
            raise
        note(f"[OPTIC] NSCF_optic échoué : {ex} — chaîne optique sautée.")
        return res

    # Extraction du préfixe pour TOUTES les chaînes optiques suivantes
    # (epsilon.x + turbo_lanczos.x + turbo_davidson.x). On le calcule
    # **immédiatement** après NSCF_optic (depuis nscf_optic.in) pour que
    # turbo_lanczos/davidson en disposent même si epsilon.x échoue ou est
    # absent. C'est juste un regex — aucune dépendance QE externe.
    try:
        prefix = _extract_prefix_from_text(
            nscf_path.read_text(encoding="utf-8", errors="replace")
        )
    except (OSError, ValueError) as ex:  # noqa: BLE001
        prefix = "pw_scf"  # fallback manifestement raisonnable.
        note(f"[OPTIC] extraction prefix NSCF_optic échouée ({ex}) — défaut '{prefix}'.")

    # --- 2. epsilon.x -----------------------------------------------------
    try:
        write_epsilon_in(
            work_dir,
            prefix=prefix,
            wmin=wmin,
            wmax=wmax,
            nw=nw,
            intersmear=intersmear,
        )
        res.epsilon_in = "epsilon.in"
        note(
            f"[OPTIC] epsilon.in écrit (prefix={prefix}, "
            f"ω∈[{wmin:.1f}, {wmax:.1f}] eV, {nw} points)."
        )
    except Exception as ex:  # noqa: BLE001
        note(f"[OPTIC] write_epsilon_in : {ex} — epsilon.x NON lancé.")
        return res

    try:
        log("[OPTIC] Lancement epsilon.x (DFPT linéaire).")
        run_qe_stdin(
            epsilon_x, work_dir / "epsilon.in", work_dir, work_dir / "epsilon.out",
            cancel_event=cancel_event, proc_holder=proc_holder,
        )
        res.epsilon_ok = True
        note("[OPTIC] epsilon.x terminé — ε₁, ε₂, JDOS, EELS calculés.")
    except Exception as ex:  # noqa: BLE001
        if cancel_event is not None and cancel_event.is_set():
            raise
        note(f"[OPTIC] epsilon.x échoué : {ex} — pas de ε(ω).")

    # --- 2b. NSCF Γ seule (requis par turboTDDFT — lr_readin gamma_only) ----
    tl_exe = cfg.turbo_lanczos_path()
    td_exe = cfg.turbo_davidson_path()
    turbo_requested = _looks_like_executable(tl_exe) or _looks_like_executable(td_exe)
    if turbo_requested:
        try:
            tg_path = write_nscf_turbo_gamma_in(work_dir, scf_basename)
            res.nscf_turbo_gamma_in = tg_path.name
            note(
                "[OPTIC] nscf_turbo_gamma.in écrit (K_POINTS gamma — requis "
                "turbo_lanczos / turbo_davidson, cf. QE lr_readin)."
            )
            log(f"[OPTIC] Lancement pw.x NSCF Γ (turbo TDDFPT, nproc={nproc}).")
            run_pw_x_in(
                work_dir, tg_path.name, nproc=nproc,
                cancel_event=cancel_event, proc_holder=proc_holder,
            )
            res.nscf_turbo_gamma_ok = True
            note("[OPTIC] NSCF Γ terminée — fonctions d'onde prêtes pour turboTDDFT.")
        except Exception as ex:  # noqa: BLE001
            if cancel_event is not None and cancel_event.is_set():
                raise
            note(
                f"[OPTIC] NSCF Γ (turbo) échouée : {ex} — turbo_lanczos/davidson "
                "non lancés (gamma_only obligatoire en QE 7.x)."
            )

    # --- 3. turbo_lanczos.x (TDDFPT Lanczos : χ(ω) complet, effets excitoniques) -----
    # Réutilise le même prefix/outdir que NSCF Γ (wf gamma_only sur disque).
    # Binaire manquant → [WARN] propre, on continue (chaîne optionnelle).
    if not _looks_like_executable(tl_exe):
        note(
            f"[OPTIC] turbo_lanczos.x manquant ou vide ({tl_exe}) — chaîne "
            "TDDFPT-Lanczos NON exécutée. Vérifiez THERMO_TURBO_LANCZOS ou "
            "compilez le paquet QE turbo/tddfpt."
        )
    else:
        if not res.nscf_turbo_gamma_ok:
            note(
                "[OPTIC] turbo_lanczos.x NON lancé — NSCF Γ manquante "
                "(grille k Monkhorst-Pack incompatible avec turboTDDFT)."
            )
        else:
            try:
                write_turbo_lanczos_in(work_dir, prefix=prefix)
                res.turbo_lanczos_in = "turbo_lanczos.in"
                note(
                    f"[OPTIC] turbo_lanczos.in écrit (prefix={prefix}, "
                    f"itermax={TURBO_LANCZOS_ITERMAX}, ipol={TURBO_LANCZOS_IPOL})."
                )
                log("[OPTIC] Lancement turbo_lanczos.x (TDDFPT Lanczos).")
                run_qe_stdin(
                    tl_exe,
                    work_dir / "turbo_lanczos.in",
                    work_dir,
                    work_dir / "turbo_lanczos.out",
                    cancel_event=cancel_event,
                    proc_holder=proc_holder,
                )
                res.turbo_lanczos_ok = True
                note("[OPTIC] turbo_lanczos.x terminé — χ(ω) TDDFPT calculé.")
            except Exception as ex:  # noqa: BLE001
                if cancel_event is not None and cancel_event.is_set():
                    raise
                note(f"[OPTIC] turbo_lanczos.x échoué : {ex} — pas de χ(ω) TDDFPT.")

    # --- 4. turbo_davidson.x (TDDFPT Davidson : spectre fenêtre visible [0, 2] eV) ---
    # Même logique : binaire optionnel, [WARN] propre si absent.
    if not _looks_like_executable(td_exe):
        note(
            f"[OPTIC] turbo_davidson.x manquant ou vide ({td_exe}) — chaîne "
            "TDDFPT-Davidson NON exécutée. Vérifiez THERMO_TURBO_DAVIDSON ou "
            "compilez le paquet QE turbo/tddfpt."
        )
    else:
        if not res.nscf_turbo_gamma_ok:
            note(
                "[OPTIC] turbo_davidson.x NON lancé — NSCF Γ manquante "
                "(grille k Monkhorst-Pack incompatible avec turboTDDFT)."
            )
        else:
            try:
                write_turbo_davidson_in(work_dir, prefix=prefix)
                res.turbo_davidson_in = "turbo_davidson.in"
                note(
                    f"[OPTIC] turbo_davidson.in écrit (prefix={prefix}, "
                    f"fenêtre [{TURBO_DAVIDSON_START_EV:.2f}, "
                    f"{TURBO_DAVIDSON_FINISH_EV:.2f}] eV, "
                    f"residue_conv_thr={TURBO_DAVIDSON_RESIDUE_CONV_THR})."
                )
                log("[OPTIC] Lancement turbo_davidson.x (TDDFPT Davidson).")
                run_qe_stdin(
                    td_exe,
                    work_dir / "turbo_davidson.in",
                    work_dir,
                    work_dir / "turbo_davidson.out",
                    cancel_event=cancel_event,
                    proc_holder=proc_holder,
                )
                res.turbo_davidson_ok = True
                note("[OPTIC] turbo_davidson.x terminé — spectre TDDFPT Davidson calculé.")
            except Exception as ex:  # noqa: BLE001
                if cancel_event is not None and cancel_event.is_set():
                    raise
                note(f"[OPTIC] turbo_davidson.x échoué : {ex} — pas de spectre Davidson.")

    # --- 5. Collecte des fichiers .dat (epsilon + turbo combinés) ---------
    res.eps_dat_files = _list_eps_dat_files(work_dir)
    res.turbo_dat_files = _list_turbo_dat_files(work_dir)
    if res.eps_dat_files:
        note(f"[OPTIC] Fichiers diélectriques (epsilon.x) : {len(res.eps_dat_files)} .dat.")
    if res.turbo_dat_files:
        note(f"[OPTIC] Fichiers turbo (TDDFPT) : {len(res.turbo_dat_files)} .dat.")

    note(
        f"[OPTIC] ===> résumé : NSCF_optic={res.nscf_optic_ok} | "
        f"epsilon.x={res.epsilon_ok} | "
        f"turbo_lanczos={res.turbo_lanczos_ok} | "
        f"turbo_davidson={res.turbo_davidson_ok} | "
        f"{len(res.eps_dat_files)} eps*.dat + "
        f"{len(res.turbo_dat_files)} turbo*.dat."
    )
    return res

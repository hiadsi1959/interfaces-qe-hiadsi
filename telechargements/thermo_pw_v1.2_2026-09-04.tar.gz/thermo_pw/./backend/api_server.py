"""
API HTTP pour l’interface THERMO_PW (matériaux, Workflow 1 EOS).
Lancement : cd backend && python3 api_server.py
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

# Marqueur de version : incrémenter à chaque changement de route ou de
# chemin. Le frontend (et RELANCER.sh) interroge /api/version et compare
# au tag attendu — si différent, c'est qu'un vieux processus tourne.
API_BUILD_TAG = "v1.2-2026-09-04"

# Imports relatifs au dossier backend/
_BACKEND = Path(__file__).resolve().parent
if str(_BACKEND) not in sys.path:
    sys.path.insert(0, str(_BACKEND))

from flask import Flask, Response, abort, current_app, jsonify, redirect, request, send_file, send_from_directory
from werkzeug.exceptions import HTTPException, MethodNotAllowed

import config as cfg
import input_editor as ie
import material_inputs as mi

try:
    from cif_to_pw import build_pw_input_from_cif
except ImportError:  # ase absent
    build_pw_input_from_cif = None  # type: ignore[assignment,misc]

import optics_inputs_check
from eos_paths import EOS_VOLUMES_SUBDIR, WORKFLOW_STATE_FILENAME, wf1_eos_run_root
from material_workspace import (
    RUN_EOS_DIR,
    ensure_material_workspace,
    iter_wf1_eos_run_dirs,
    write_wf1_run_readme,
)
from eos_gnuplot import (
    GP_ELASTIC,
    PNG_ELASTIC,
    resolve_gnuplot_executable,
    run_gnuplot_eos,
    run_gnuplot_elastic_temperature_dat,
)
from phonon_gnuplot import run_gnuplot_phonon_bands, run_gnuplot_phonon_dos
from phonon_chain_qe import (
    run_dynmat,
    run_matdyn_bands,
    run_matdyn_dos,
    run_q2r,
    run_q2r_dynamical_matrices,
    resolve_fildyn_for_qha_prereq,
    run_thermo_pw_mpi,
    purge_thermo_pw_scratch_dirs,
)
from pp_charge_plot import resolve_pw_in_basename_for_pp, run_pp_charge_density
from ph_input_from_pw import nq_from_request_body, try_autogenerate_ph_in
from qe_subprocess import API_CANCEL_RUNTIME_MSG, run_mpi_exe_in, run_ph_x_in, run_pw_x_in
import api_job_persist
from api_job_progress import estimate_job_progress_pct
from phonon_job_diagnosis import PHONON_QE_JOB_KINDS, diagnosis_hint_for_phonon_qe_job
from state_db import WorkflowDB
from qha_prereq_check import check_qha_prereqs, enrich_mur_lc_driver_prereqs, format_prereq_failure
from parsers.elastic_t_dat_scan import (
    SERIES_HINT_NAMES,
    dat_semantic_hint_for_filename,
    find_elastic_t_dat,
    list_dat_relpaths,
    list_elastic_like_dat_candidates,
    parse_numeric_series_dat,
    path_allowed_for_elastic_t_series_request,
)
from parsers.thermo_pw_out_parse import THERMO_PW_OUT_PARSE_REVISION, parse_work_dir_thermo_log
from work_optimize_eos import (
    EosConfig,
    list_scf_vol_outs_ordered,
    task_optimize,
    task_optimize_fit_only,
    task_optimize_scf_and_fit,
    task_optimize_scf_only,
    task_optimize_volumes_only,
)

app = Flask(__name__)

from pseudos_generation_routes import (
    pseudo_save_local_input_dispatch,
    register_pseudos_generation_routes,
)

register_pseudos_generation_routes(app)

# Nouveau système thermo_pw : 5 profils unifiés (P1..P5) → série de calculs automatisée.
# Endpoints : /api/pipeline/profiles, /api/pipeline/run, /api/pipeline/jobs, ...
try:
    from pipeline import PROFILES, register_pipeline_blueprint  # noqa: E402
    register_pipeline_blueprint(app)
    PIPELINE_AVAILABLE = True
except Exception as _pipeline_exc:  # noqa: BLE001
    PROFILES = {}
    PIPELINE_AVAILABLE = False
    import logging as _logging
    _logging.getLogger("thermo_pw.api").warning(
        "Pipeline blueprint indisponible : %s", _pipeline_exc
    )

# Juillet 2026 — fiche technique téléchargeable (Murnaghan + Cij + gap + magnétisme + DFPT + section expert rule-based)
# GET /api/pipeline/runs/<job_id>/factsheet?format=md|html|pdf
# Le PDF est servi via WeasyPrint en lazy-import : si la lib est absente ou
# ses natives Cairo/Pango manquent, l'endpoint retourne 503 avec un message
# d'installation, et le bouton PDF du front est désactivé via
# ``factsheet_pdf_available`` exposé par ``/api/health``.
try:
    from factsheet import (
        register_factsheet_blueprint,
        _resolve_pdf_backend as _factsheet_resolve_pdf_backend,
        FACTSHEET_VERSION as _FACTSHEET_VERSION,
        _module_compile_iso as _factsheet_compile_iso,
    )  # noqa: E402
    from factsheet_ai import FACTSHEET_AI_VERSION as _FACTSHEET_AI_VERSION
    fact_mod = sys.modules.get("factsheet")
    fact_ai_mod = sys.modules.get("factsheet_ai")
    register_factsheet_blueprint(app)
    FACTSHEET_AVAILABLE = True
except Exception as _factsheet_exc:  # noqa: BLE001
    FACTSHEET_AVAILABLE = False
    FACTSHEET_PDF_AVAILABLE = False
    _FACTSHEET_VERSION = None
    _FACTSHEET_AI_VERSION = None
    fact_mod = None
    fact_ai_mod = None
    import logging as _logging
    _logging.getLogger("thermo_pw.api").warning(
        "Factsheet blueprint indisponible : %s", _factsheet_exc
    )
else:
    # Le lazy-resolve est caché : on réutilise le même cache que l'endpoint.
    FACTSHEET_PDF_AVAILABLE = bool(_factsheet_resolve_pdf_backend())
    # Snippet « md compiler date » côté serveur — traçable jusqu'au commit git
    # (``git log --format=%ci backend/factsheet.py``). Helpers privés
    # ``_module_compile_iso`` = UTC ``YYYY-MM-DD`` depuis ``Path.stat().st_mtime``.
    _FACTSHEET_COMPILED_AT = (
        _factsheet_compile_iso(fact_mod.__file__) if fact_mod and fact_mod.__file__ else "—"
    )
    _FACTSHEET_AI_COMPILED_AT = (
        _factsheet_compile_iso(fact_ai_mod.__file__) if fact_ai_mod and fact_ai_mod.__file__ else "—"
    )

# POST JSON pour les jobs / entrées ; PUT/PATCH tolérés (sinon Werkzeug peut répondre 405
# si la requête n’est pas strictement POST — proxies ou clients REST « incorrects »).
EOS_JSON_POST_METHODS = ("POST", "PUT", "PATCH", "OPTIONS")
# GET accepté pour répondre un JSON d’aide (évite 405 si l’URL POST est ouverte dans la barre du navigateur).
EOS_JSON_POST_METHODS_PLUS_GET: tuple[str, ...] = (*EOS_JSON_POST_METHODS, "GET")

# Interface web (fichiers statiques) : même hôte / même port que l’API
INTERFACE_DIR: Path = (cfg.THERMO_REPO_ROOT / "interface").resolve()

_jobs: dict[str, dict[str, Any]] = {}
_jobs_lock = threading.RLock()
# Si True : refuse d'enfiler de nouveaux jobs (EOS, phonons, thermo_pw, optique…). Les jobs déjà lancés continuent.
_new_jobs_blocked = False


def _eos_api_browser_get_help(extra_body_keys: Optional[dict[str, Any]] = None) -> tuple[Any, int]:
    """Réponse JSON si l’endpoint « POST only » est appelé en GET (URL dans la barre d’adresse, etc.)."""
    ex: dict[str, Any] = {"work_dir": "/absolu/vers/thermo_pw/work/…/wf1_eos_…"}
    if extra_body_keys:
        ex.update(extra_body_keys)
    return (
        jsonify(
            {
                "error": (
                    "Appelez cette URL en POST (JSON), pas en GET. "
                    "Coller l’adresse dans le navigateur envoie un GET — avant correction serveur cela produisait « Method Not Allowed »."
                ),
                "required_method": "POST",
                "content_type": "application/json",
                "body_example": ex,
                "hint": "Workflow 2 — boutons §3bis / gnuplot, ou curl -X POST -H 'Content-Type: application/json' -d '{…}' …",
            }
        ),
        400,
    )


def _reject_if_new_jobs_blocked() -> Optional[tuple[Any, int]]:
    with _jobs_lock:
        blocked = _new_jobs_blocked
    if not blocked:
        return None
    return (
        jsonify(
            {
                "error": "new_jobs_blocked",
                "blocked": True,
                "hint": (
                    "Les nouveaux calculs API sont bloqués. Rétablissez avec "
                    "POST /api/workflow1/eos/jobs/block et {\"blocked\": false}, "
                    "ou via la case à cocher du bandeau « Calcul en cours »."
                ),
            }
        ),
        423,
    )


def _eos_jobs_active_list() -> list[dict[str, Any]]:
    """Jobs encore ``queued`` ou ``running`` pour ce processus API (mémoire ; pas de persistance fichier)."""
    with _jobs_lock:
        items = list(_jobs.items())
    active: list[dict[str, Any]] = []
    for jid, d in items:
        st = str(d.get("status") or "")
        if st not in ("queued", "running"):
            continue
        row: dict[str, Any] = {
                "job_id": jid,
                "status": st,
                "kind": d.get("kind"),
                "message": d.get("message", ""),
                "work_dir": d.get("work_dir"),
                "thermo_what": d.get("thermo_what"),
                "nproc": d.get("nproc"),
                "pw_in": d.get("pw_in"),
                "material_id": d.get("material_id"),
                "mode": d.get("mode"),
                "fit_only": d.get("fit_only"),
            }
        wd_raw = d.get("work_dir")
        if wd_raw:
            try:
                pp = estimate_job_progress_pct(Path(str(wd_raw)).expanduser().resolve(), d)
                if pp is not None:
                    row["progress_pct"] = pp
            except OSError:
                pass
        active.append(row)
    return active


def _signal_cancel_run_thermo_pw_job(job_id: str) -> dict[str, Any]:
    """Demande d’arrêt MPI pour un job ``run_thermo_pw`` encore actif (sans lever d’exception)."""
    with _jobs_lock:
        j = _jobs.get(job_id)
    if not j:
        return {"job_id": job_id, "result": "not_found"}
    kind = str(j.get("kind") or "")
    if kind != "run_thermo_pw":
        return {"job_id": job_id, "result": "wrong_kind", "kind": kind}
    st = str(j.get("status") or "").lower()
    if st in ("done", "error", "cancelled"):
        return {"job_id": job_id, "result": "already_finished", "status": st}
    ce = j.get("cancel_event")
    if not isinstance(ce, threading.Event):
        return {"job_id": job_id, "result": "no_cancel_event"}
    ce.set()
    return {"job_id": job_id, "result": "cancel_requested"}


def _corsify(resp):
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET, HEAD, POST, PUT, PATCH, OPTIONS"
    return resp


def _json_api_405_payload() -> dict[str, Any]:
    p = getattr(request, "path", "") or ""
    hi = (
        "Utilisez POST avec Content-Type: application/json et "
        '{"work_dir":"/chemin/absolu/run/wf1_eos_…"} '
        "(endpoints : run_dynmat, gnuplot_phonon_bands, gnuplot_phonon_dos, …). "
        "PUT/PATCH acceptés."
    )
    if (
        "run_pp_charge" in p
        or p.rstrip("/").endswith("/pp_charge")
        or p.rstrip("/") == "/api/pp_charge"
        or p.rstrip("/") == "/api/run_pp_charge"
    ):
        hi += (
            " **405 sur pp.x API** : redémarrer l’API après mise à jour ; les routes valides sont "
            "**POST** …/api/workflow1/eos/pp_charge, …/run_pp_charge, et alias **…/api/pp_charge**, "
            "**…/api/run_pp_charge** (JSON avec work_dir). Un GET seul (barre d’adresse) renvoie l’aide JSON, pas le calcul."
        )
    elif "auto_inputs" in p:
        hi = (
            "Pour /api/pseudos/auto_inputs : la route accepte GET, POST et OPTIONS (prévol CORS). "
            "Si vous voyez ce message après mise à jour : redémarrer api_server.py "
            "ou utiliser GET avec ?element=Si&xc=lda_pw (voir pseudos_generation_routes)."
        )
    else:
        hi += " Redémarrer api_server.py après mise à jour ; vérifier proxy."
    return {
        "error": "Method Not Allowed",
        "method": request.method,
        "path": p,
        "hint": hi,
    }


def _json_api_405_response() -> tuple[Any, int]:
    """405 pour chemins /api/… — toujours du JSON (évite HTML Werkzeug et JSON.parse côté client)."""
    return jsonify(_json_api_405_payload()), 405


@app.errorhandler(MethodNotAllowed)
def _handle_method_not_allowed(exc: MethodNotAllowed) -> Any:
    """Prioritaire sur HTTPException — MethodNotAllowed → JSON sous /api/."""
    if request.path.startswith("/api/"):
        return _json_api_405_response()
    return exc.get_response()


@app.errorhandler(HTTPException)
def _handle_http_exception(exc: HTTPException) -> Any:
    """Repli pour tout code HTTP 405 non capturé comme MethodNotAllowed (selon versions Werkzeug)."""
    code = getattr(exc, "code", None)
    if code == 405 and request.path.startswith("/api/"):
        return _json_api_405_response()
    return exc.get_response()


@app.after_request
def _after(resp):
    """CORS + dernier filet : toute réponse 405 encore en HTML sous /api/ → JSON."""
    try:
        if (
            resp.status_code == 405
            and request.path.startswith("/api/")
            and not getattr(resp, "direct_passthrough", False)
        ):
            txt = resp.get_data(as_text=True)
            low = txt.strip().lower()
            if low.startswith("<!doctype") or "<title>405" in txt.lower():
                body, _status = _json_api_405_response()
                return _corsify(body)
    except Exception:
        pass
    resp = _corsify(resp)
    # Lecture du journal évolutif : évite une réponse JSON obsolète (navigateur / proxy)
    try:
        p = getattr(request, "path", "") or ""
        if p in (
            "/api/workflow1/eos/thermo_output_parse",
            "/api/parse_thermo_pw_out",
            "/api/workflow1/work/default_run_dir",
            "/api/workflow1/eos/jobs",
            "/api/workflow1/eos/jobs/purge_active_keep_first",
            "/api/workflow1/eos/purge_active",
            "/api/workflow1/eos/jobs/purge_active",
            "/api/workflow1/eos/persisted_job_state",
            "/api/workflow1/eos/elastic_t_dat_candidates",
        ):
            resp.headers["Cache-Control"] = "no-store, max-age=0"
            resp.headers["Pragma"] = "no-cache"
    except Exception:
        pass
    return resp


def _safe_material_id(s: str) -> str:
    t = re.sub(r"[^0-9A-Za-z._-]+", "_", (s or "material").strip())[:64]
    return t or "material"


def _is_allowed_eos_work_dir(p: Path) -> bool:
    """Réutiliser un run EOS déjà dans thermo_pw/work/ (sécurité)."""
    try:
        p.resolve().relative_to(cfg.WORK_ROOT.resolve())
    except ValueError:
        return False
    return True


def _persist_job_disk(job_id: str) -> None:
    """Écrit ``thermo_api_job_state.json`` dans le work_dir du job (reprise post-coupure)."""
    try:
        with _jobs_lock:
            rec = dict(_jobs.get(job_id) or {})
        api_job_persist.write_job_marker(job_id, rec)
    except OSError:
        pass


def _infer_material_id_from_wf1_work_dir(work_dir: Path) -> str:
    """…/work/<M>/<wf1_eos_…>/ ou …/work/<M>/run_eos/<wf1_eos_…>/ → M."""
    try:
        wd = work_dir.resolve()
        root = cfg.WORK_ROOT.resolve()
        rel = wd.relative_to(root)
    except ValueError:
        return ""
    if not rel.parts or not wd.name.startswith("wf1_eos_"):
        return ""
    return _safe_material_id(rel.parts[0])


def _eos_run_child_path(raw_wd: str, relpath: str) -> Optional[Path]:
    """Chemin résolu sous work_dir (peut ne pas exister encore). Sécurité : uniquement sous work/."""
    if not relpath or not raw_wd:
        return None
    rel = relpath.replace("\\", "/").strip().lstrip("/")
    if not rel or ".." in rel.split("/"):
        return None
    wd = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not _is_allowed_eos_work_dir(wd) or not wd.is_dir():
        return None
    p = (wd / rel).resolve()
    try:
        p.relative_to(wd)
    except ValueError:
        return None
    return p


def _safe_work_artifact_path(raw_wd: str, relpath: str) -> Optional[Path]:
    """Fichier existant sous work_dir/… (PNG, scripts gnuplot, .dat…)."""
    p = _eos_run_child_path(raw_wd, relpath)
    if p is None or not p.is_file():
        return None
    return p


def _resolve_pipeline_job_workdir(job_id: str) -> Optional[Path]:
    """Résout le work_dir d'un job : mémoire d'abord, puis disque (markers).

    Partagé par ``/api/pipeline/runs/<job_id>/files`` et ``/result_file``.
    Renvoie ``None`` si introuvable — l'appelant renvoie 404 / 503.
    """
    wd: Optional[Path] = None
    # (a) PipelineJob vivant en mémoire.
    try:
        from pipeline import PipelineJob
        with PipelineJob._REGISTRY_LOCK:
            job = PipelineJob._REGISTRY.get(job_id)
        if job is not None and getattr(job, "work_dir", None):
            wd = Path(str(job.work_dir)).expanduser().resolve()
            return wd
    except Exception:
        pass
    # (b) Marker disque (config.py + scan borné ``work/<mat>/pipeline_*/``).
    try:
        marker_files = list(cfg.WORK_ROOT.glob("**/pipeline_api_job_state.json"))
    except OSError:
        return None
    for marker_path in marker_files:
        try:
            d = json.loads(marker_path.read_text(encoding="utf-8", errors="replace"))
        except (OSError, json.JSONDecodeError):
            continue
        if str(d.get("job_id") or "") == job_id:
            try:
                wd = marker_path.parent.resolve()
            except OSError:
                continue
            if wd.is_dir() and _is_allowed_eos_work_dir(wd):
                return wd
    return None


def _tail_utf8_file(path: Path, max_lines: int, read_chunk: int) -> tuple[str, int, bool]:
    """Dernières lignes d’un fichier texte ; (texte, taille_fichier, tronqué_en_tête)."""
    try:
        sz = path.stat().st_size
    except OSError:
        return "", 0, False
    if sz <= 0:
        return "", sz, False
    chunk = min(sz, read_chunk)
    with path.open("rb") as f:
        f.seek(sz - chunk)
        raw = f.read()
    truncated = chunk < sz
    text = raw.decode("utf-8", errors="replace")
    if truncated and sz > chunk:
        nl = text.find("\n")
        if nl != -1:
            text = text[nl + 1 :]
    lines = text.splitlines()
    if len(lines) > max_lines:
        lines = lines[-max_lines:]
    return "\n".join(lines), sz, truncated


def _run_scf_v0_job(
    job_id: str,
    work_dir: Path,
    nproc: int,
    inp_basename: str,
) -> None:
    try:
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"
            _jobs[job_id]["message"] = f"pw.x -in {inp_basename}…"
        _persist_job_disk(job_id)
        try:
            out = run_pw_x_in(work_dir, inp_basename, nproc=nproc)
            with _jobs_lock:
                _jobs[job_id]["status"] = "done"
                _jobs[job_id]["message"] = "Terminé (pw.x @ V0)"
                _jobs[job_id]["log_file"] = str(out.resolve())
        except Exception as ex:  # noqa: BLE001
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = str(ex)
    finally:
        _persist_job_disk(job_id)


def _run_ph_x_job(
    job_id: str,
    work_dir: Path,
    nproc: int,
    inp_basename: str,
) -> None:
    try:
        inp = work_dir / inp_basename
        if not inp.is_file():
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = (
                    f"Fichier introuvable : {inp_basename} (créez-le avant ph.x)"
                )
            return
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"
            _jobs[job_id]["message"] = f"ph.x -in {inp_basename}…"
        _persist_job_disk(job_id)
        try:
            out = run_ph_x_in(work_dir, inp_basename, nproc=nproc)
            with _jobs_lock:
                _jobs[job_id]["status"] = "done"
                _jobs[job_id]["message"] = "Terminé (ph.x)"
                _jobs[job_id]["log_file"] = str(out.resolve())
        except Exception as ex:  # noqa: BLE001
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = str(ex)
    finally:
        _persist_job_disk(job_id)


def _run_q2r_job(
    job_id: str,
    work_dir: Path,
    flfrc: str = "fc.out",
    dynamical_matrices_igeo: Optional[int] = None,
) -> None:
    try:
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"
            _jobs[job_id]["message"] = "q2r.x…"
        _persist_job_disk(job_id)
        try:
            if dynamical_matrices_igeo is not None:
                log = run_q2r_dynamical_matrices(
                    work_dir, igeo=dynamical_matrices_igeo, flfrc=flfrc
                )
            else:
                log = run_q2r(work_dir, flfrc=flfrc)
            with _jobs_lock:
                _jobs[job_id]["status"] = "done"
                _jobs[job_id]["message"] = "Terminé (q2r.x)"
                _jobs[job_id]["log_file"] = str(log.resolve())
                _jobs[job_id]["kind"] = "run_q2r"
        except Exception as ex:  # noqa: BLE001
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = str(ex)
    finally:
        _persist_job_disk(job_id)


def _run_phonon_bands_from_dynamical_matrices_job(
    job_id: str,
    work_dir: Path,
    igeo: int,
    flfrc: str = "fc.out",
) -> None:
    try:
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"
            _jobs[job_id]["message"] = "q2r.x (dynamical_matrices)…"
        _persist_job_disk(job_id)
        run_q2r_dynamical_matrices(work_dir, igeo=igeo, flfrc=flfrc)
        with _jobs_lock:
            _jobs[job_id]["message"] = "matdyn.x (bandes phonons)…"
        _persist_job_disk(job_id)
        run_matdyn_bands(work_dir, flfrc=flfrc)
        with _jobs_lock:
            _jobs[job_id]["message"] = "gnuplot bandes…"
        _persist_job_disk(job_id)
        gres = run_gnuplot_phonon_bands(work_dir, flfrq="phonon.freq")
        rel = str(gres.get("relpath") or "phonon_bands.png")
        with _jobs_lock:
            _jobs[job_id]["status"] = "done"
            _jobs[job_id]["message"] = "Terminé — " + rel
            _jobs[job_id]["kind"] = "phonon_bands_from_dynamical_matrices"
            _jobs[job_id]["gnuplot_relpath"] = rel
            _jobs[job_id]["log_file"] = str((work_dir / "q2r_from_dm.out").resolve())
    except Exception as ex:  # noqa: BLE001
        with _jobs_lock:
            _jobs[job_id]["status"] = "error"
            _jobs[job_id]["message"] = str(ex)
    finally:
        _persist_job_disk(job_id)


def _run_matdyn_dos_job(
    job_id: str,
    work_dir: Path,
    nk1: int,
    nk2: int,
    nk3: int,
    flfrc: str = "fc.out",
) -> None:
    try:
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"
            _jobs[job_id]["message"] = "matdyn.x (DOS phonons)…"
        _persist_job_disk(job_id)
        try:
            log = run_matdyn_dos(
                work_dir, nk1=nk1, nk2=nk2, nk3=nk3, flfrc=flfrc
            )
            with _jobs_lock:
                _jobs[job_id]["status"] = "done"
                _jobs[job_id]["message"] = "Terminé (matdyn DOS)"
                _jobs[job_id]["log_file"] = str(log.resolve())
                _jobs[job_id]["kind"] = "run_matdyn_dos"
        except Exception as ex:  # noqa: BLE001
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = str(ex)
    finally:
        _persist_job_disk(job_id)


def _run_matdyn_bands_job(job_id: str, work_dir: Path, flfrc: str = "fc.out") -> None:
    try:
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"
            _jobs[job_id]["message"] = "matdyn.x (dispersions)…"
        _persist_job_disk(job_id)
        try:
            log = run_matdyn_bands(work_dir, flfrc=flfrc)
            with _jobs_lock:
                _jobs[job_id]["status"] = "done"
                _jobs[job_id]["message"] = "Terminé (matdyn bandes)"
                _jobs[job_id]["log_file"] = str(log.resolve())
                _jobs[job_id]["kind"] = "run_matdyn_bands"
        except Exception as ex:  # noqa: BLE001
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = str(ex)
    finally:
        _persist_job_disk(job_id)


def _run_dynmat_job(job_id: str, work_dir: Path, fildyn_file: Optional[str]) -> None:
    try:
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"
            _jobs[job_id]["message"] = "dynmat.x…"
        _persist_job_disk(job_id)
        try:
            log = run_dynmat(work_dir, fildyn_file=fildyn_file)
            with _jobs_lock:
                _jobs[job_id]["status"] = "done"
                _jobs[job_id]["message"] = "Terminé (dynmat)"
                _jobs[job_id]["log_file"] = str(log.resolve())
                _jobs[job_id]["kind"] = "run_dynmat"
        except Exception as ex:  # noqa: BLE001
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = str(ex)
    finally:
        _persist_job_disk(job_id)


def _run_pp_charge_job(
    job_id: str,
    work_dir: Path,
    pw_in_basename: str,
    plot_num: int,
    fileout: Optional[str],
    output_format: Optional[int],
    filplot: Optional[str],
    reuse_charge_dat: bool,
    charge_dat_relpath: Optional[str],
) -> None:
    wd_r = wf1_eos_run_root(work_dir.resolve())
    try:
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"
            _jobs[job_id]["message"] = "pp.x (densité charge)…"
            _jobs[job_id]["kind"] = "run_pp_charge"
        _persist_job_disk(job_id)
        try:
            log, out_path, inp_name = run_pp_charge_density(
                wd_r,
                pw_in_basename=pw_in_basename,
                plot_num=plot_num,
                fileout=fileout,
                cube_name=None,
                output_format=output_format,
                filplot=filplot,
                reuse_charge_dat=reuse_charge_dat,
                charge_dat_relpath=charge_dat_relpath,
            )
            cube_rel = str(out_path.resolve().relative_to(wd_r)).replace("\\", "/")
            with _jobs_lock:
                _jobs[job_id]["status"] = "done"
                _jobs[job_id]["message"] = "Terminé (pp.x — densité)"
                _jobs[job_id]["log_file"] = str(log.resolve())
                _jobs[job_id]["kind"] = "run_pp_charge"
                _jobs[job_id]["cube_relpath"] = cube_rel
                _jobs[job_id]["pp_charge_in_relpath"] = inp_name
        except Exception as ex:  # noqa: BLE001
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = str(ex)
                _jobs[job_id]["kind"] = "run_pp_charge"
    finally:
        _persist_job_disk(job_id)


def _run_thermo_pw_job(
    job_id: str,
    work_dir: Path,
    nproc: int,
    pw_in_basename: str,
    thermo_opts: Optional[dict[str, Any]],
    clear_thermo_restart: bool = True,
) -> None:
    what_l = ""
    if thermo_opts:
        what_l = str(thermo_opts.get("what") or "").strip()
    if not what_l:
        what_l = "mur_lc_t"
    try:
        with _jobs_lock:
            cancel_ev = _jobs[job_id].get("cancel_event")
        if isinstance(cancel_ev, threading.Event) and cancel_ev.is_set():
            with _jobs_lock:
                _jobs[job_id]["status"] = "cancelled"
                _jobs[job_id]["message"] = "Annulé avant le démarrage MPI."
            return
        detail = (
            f"thermo_pw.x MPI — what={what_l!r} — np={nproc} — entrée {pw_in_basename!r} — "
            f"progression détaillée dans thermo_pw_run.out (SCF, phonons, matdyn, …)."
        )
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"
            _jobs[job_id]["message"] = detail
        _persist_job_disk(job_id)
        try:
            log = run_thermo_pw_mpi(
                work_dir,
                nproc=nproc,
                pw_in_basename=pw_in_basename,
                thermo_opts=thermo_opts,
                clear_thermo_restart=clear_thermo_restart,
                cancel_event=cancel_ev if isinstance(cancel_ev, threading.Event) else None,
            )
            with _jobs_lock:
                _jobs[job_id]["status"] = "done"
                _jobs[job_id]["message"] = f"Terminé (thermo_pw.x, what={what_l!r})"
                _jobs[job_id]["log_file"] = str(log.resolve())
                _jobs[job_id]["kind"] = "run_thermo_pw"
        except Exception as ex:  # noqa: BLE001
            cancelled = isinstance(ex, RuntimeError) and API_CANCEL_RUNTIME_MSG in str(ex)
            with _jobs_lock:
                if cancelled:
                    _jobs[job_id]["status"] = "cancelled"
                    _jobs[job_id]["message"] = API_CANCEL_RUNTIME_MSG
                else:
                    _jobs[job_id]["status"] = "error"
                    _jobs[job_id]["message"] = str(ex)
    finally:
        _persist_job_disk(job_id)


def _read_workflow_state(work_dir: Path) -> Optional[dict[str, Any]]:
    p = work_dir / WORKFLOW_STATE_FILENAME
    if not p.is_file():
        return None
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except OSError:
        return None


def _run_eos_job(
    job_id: str,
    work_dir: Path,
    material_id: str,
    template_pw: Path,
    n_points: int,
    strain_min_pct: int,
    strain_max_pct: int,
    nproc: int,
    sequential: bool,
) -> None:
    st_path = work_dir / WORKFLOW_STATE_FILENAME
    try:
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"
            _jobs[job_id]["message"] = "EOS en cours (pw.x + fit)…"
        _persist_job_disk(job_id)
        db = WorkflowDB.load(st_path)
        if not db.material_id:
            db = WorkflowDB(material_id=material_id, work_dir=str(work_dir))
        db.save(st_path)
        smin = strain_min_pct / 100.0
        smax = strain_max_pct / 100.0
        conf = EosConfig(
            template_pw=template_pw,
            n_points=n_points,
            strain_min=smin,
            strain_max=smax,
            nproc=nproc,
            sequential=sequential,
        )
        try:
            summary = task_optimize(
                work_dir, material_id, template_pw, db, conf
            )
            with _jobs_lock:
                _jobs[job_id]["status"] = "done"
                _jobs[job_id]["message"] = "Terminé"
                _jobs[job_id]["summary"] = summary
                _jobs[job_id]["work_dir"] = str(work_dir.resolve())
                _jobs[job_id]["mode"] = "full"
        except Exception as ex:  # noqa: BLE001
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = str(ex)
            try:
                ie.clean_outputs_for_material(material_id)
            except (OSError, ValueError):
                pass
            try:
                st = WorkflowDB.load(st_path)
                st.save(st_path)
            except OSError:
                pass
    finally:
        _persist_job_disk(job_id)


def _run_eos_fit_only_job(
    job_id: str,
    work_dir: Path,
    material_id: str,
    template_pw: Path,
    n_points: int,
    strain_min_pct: int,
    strain_max_pct: int,
) -> None:
    st_path = work_dir / WORKFLOW_STATE_FILENAME
    try:
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"
            _jobs[job_id]["message"] = "E(V) + Birch–Murnaghan (sans relancer pw.x)…"
        _persist_job_disk(job_id)
        db = WorkflowDB.load(st_path)
        if not db.material_id:
            db = WorkflowDB(material_id=material_id, work_dir=str(work_dir))
        db.save(st_path)
        smin = strain_min_pct / 100.0
        smax = strain_max_pct / 100.0
        conf = EosConfig(
            template_pw=template_pw,
            n_points=n_points,
            strain_min=smin,
            strain_max=smax,
        )
        try:
            summary = task_optimize_fit_only(
                work_dir, material_id, template_pw, db, conf
            )
            with _jobs_lock:
                _jobs[job_id]["status"] = "done"
                _jobs[job_id]["message"] = "Terminé (ajustement seul)"
                _jobs[job_id]["summary"] = summary
                _jobs[job_id]["work_dir"] = str(work_dir.resolve())
        except Exception as ex:  # noqa: BLE001
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = str(ex)
            try:
                st = WorkflowDB.load(st_path)
                st.save(st_path)
            except OSError:
                pass
    finally:
        _persist_job_disk(job_id)


def _run_eos_volumes_only_job(
    job_id: str,
    work_dir: Path,
    material_id: str,
    template_pw: Path,
    n_points: int,
    strain_min_pct: int,
    strain_max_pct: int,
) -> None:
    st_path = work_dir / WORKFLOW_STATE_FILENAME
    try:
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"
            _jobs[job_id]["message"] = "Génération de la grille (.in)…"
        _persist_job_disk(job_id)
        db = WorkflowDB.load(st_path)
        if not db.material_id:
            db = WorkflowDB(material_id=material_id, work_dir=str(work_dir))
        db.save(st_path)
        smin = strain_min_pct / 100.0
        smax = strain_max_pct / 100.0
        conf = EosConfig(
            template_pw=template_pw,
            n_points=n_points,
            strain_min=smin,
            strain_max=smax,
        )
        try:
            summary = task_optimize_volumes_only(
                work_dir, material_id, template_pw, db, conf
            )
            with _jobs_lock:
                _jobs[job_id]["status"] = "done"
                _jobs[job_id]["message"] = "Grille générée (aucun SCF)"
                _jobs[job_id]["summary"] = summary
                _jobs[job_id]["work_dir"] = str(work_dir.resolve())
                _jobs[job_id]["mode"] = "volumes_only"
        except Exception as ex:  # noqa: BLE001
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = str(ex)
            try:
                st = WorkflowDB.load(st_path)
                st.save(st_path)
            except OSError:
                pass
    finally:
        _persist_job_disk(job_id)


def _run_eos_scf_from_work_dir_job(
    job_id: str,
    work_dir: Path,
    material_id: str,
    template_pw: Path,
    n_points: int,
    strain_min_pct: int,
    strain_max_pct: int,
    nproc: int,
    sequential: bool,
) -> None:
    st_path = work_dir / WORKFLOW_STATE_FILENAME
    try:
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"
            _jobs[job_id]["message"] = "EOS (pw.x + fit)…"
        _persist_job_disk(job_id)
        db = WorkflowDB.load(st_path)
        if not db.material_id:
            db = WorkflowDB(material_id=material_id, work_dir=str(work_dir))
        db.save(st_path)
        smin = strain_min_pct / 100.0
        smax = strain_max_pct / 100.0
        conf = EosConfig(
            template_pw=template_pw,
            n_points=n_points,
            strain_min=smin,
            strain_max=smax,
            nproc=nproc,
            sequential=sequential,
        )
        try:
            summary = task_optimize_scf_and_fit(
                work_dir, material_id, template_pw, db, conf
            )
            with _jobs_lock:
                _jobs[job_id]["status"] = "done"
                _jobs[job_id]["message"] = "Terminé"
                _jobs[job_id]["summary"] = summary
                _jobs[job_id]["work_dir"] = str(work_dir.resolve())
                _jobs[job_id]["mode"] = "scf_and_fit"
        except Exception as ex:  # noqa: BLE001
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = str(ex)
            try:
                ie.clean_outputs_for_material(material_id)
            except (OSError, ValueError):
                pass
            try:
                st = WorkflowDB.load(st_path)
                st.save(st_path)
            except OSError:
                pass
    finally:
        _persist_job_disk(job_id)


def _run_eos_scf_only_from_work_dir_job(
    job_id: str,
    work_dir: Path,
    material_id: str,
    template_pw: Path,
    n_points: int,
    strain_min_pct: int,
    strain_max_pct: int,
    nproc: int,
    sequential: bool,
) -> None:
    st_path = work_dir / WORKFLOW_STATE_FILENAME
    try:
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"
            _jobs[job_id]["message"] = "SCF par volume (sans fit)…"
        _persist_job_disk(job_id)
        db = WorkflowDB.load(st_path)
        if not db.material_id:
            db = WorkflowDB(material_id=material_id, work_dir=str(work_dir))
        db.save(st_path)
        smin = strain_min_pct / 100.0
        smax = strain_max_pct / 100.0
        conf = EosConfig(
            template_pw=template_pw,
            n_points=n_points,
            strain_min=smin,
            strain_max=smax,
            nproc=nproc,
            sequential=sequential,
        )
        try:
            summary = task_optimize_scf_only(
                work_dir, material_id, template_pw, db, conf
            )
            with _jobs_lock:
                _jobs[job_id]["status"] = "done"
                _jobs[job_id]["message"] = "SCF terminés — lancez le fit (3.3)"
                _jobs[job_id]["summary"] = summary
                _jobs[job_id]["work_dir"] = str(work_dir.resolve())
                _jobs[job_id]["mode"] = "scf_only"
        except Exception as ex:  # noqa: BLE001
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = str(ex)
            try:
                ie.clean_outputs_for_material(material_id)
            except (OSError, ValueError):
                pass
            try:
                st = WorkflowDB.load(st_path)
                st.save(st_path)
            except OSError:
                pass
    finally:
        _persist_job_disk(job_id)


@app.route("/api/version", methods=["GET", "OPTIONS"])
def api_version():
    """Identification rapide de la version chargée en mémoire (anti vieux processus)."""
    if request.method == "OPTIONS":
        return "", 204
    ui_version = "v1"
    ui_date = "2026-08-20"
    version_path = INTERFACE_DIR / "VERSION"
    try:
        if version_path.is_file():
            lines = [
                ln.strip()
                for ln in version_path.read_text(encoding="utf-8", errors="replace").splitlines()
                if ln.strip()
            ]
            if lines:
                ui_version = lines[0]
            if len(lines) > 1:
                ui_date = lines[1]
    except OSError:
        pass
    return jsonify({
        "build_tag": API_BUILD_TAG,
        "ui_version": ui_version,
        "ui_date": ui_date,
        "pid": os.getpid(),
        "source_file": os.path.abspath(__file__),
        "source_mtime": datetime.fromtimestamp(
            os.path.getmtime(__file__)
        ).isoformat(timespec="seconds"),
        "thermo_repo_root": str(cfg.THERMO_REPO_ROOT),
    })




@app.route("/api/cheatsheet_outputs", methods=["GET", "OPTIONS"])
def api_cheatsheet_outputs():
    """Juillet 2026 — sert la cheatsheet Markdown des sorties par profil.

    GET  -> text/markdown; charset=utf-8
    OPTIONS -> 204 No Content (CORS preflight)
    """
    if request.method == "OPTIONS":
        return "", 204
    md_path = _BACKEND.parent / "templates" / "cheatsheet" / "cheatsheet_outputs_par_profil.md"
    try:
        with open(md_path, "r", encoding="utf-8") as f:
            content = f.read()
    except OSError as exc:
        return jsonify({"error": "cheatsheet unavailable", "detail": str(exc), "path": md_path}), 500
    return Response(content, mimetype="text/markdown")


@app.route("/health", methods=["GET", "OPTIONS"])
def health_root_alias():
    """Compatibilité avec generation_pseudos/index.html (sonde GET /health)."""
    return health()





def _rehydrate_jobs_from_disk_marker():
    """Juillet 2026 (P1) - resilience post-crash API.

    Scanne ``cfg.WORK_ROOT/**/pipeline_api_job_state.json`` au boot et logge un
    resume des statuts terminaux / orphelins ``running``. Ne peut PAS ressusciter
    le subprocess MPI perdu (mort avec le process parent) - la reprise effective
    reste manuelle via la section UI « Charger un calcul precedent » (les markers
    disque sont deja listes par ``/api/pipeline/runs``).

    But : informer l'operateur combien de jobs ont ete « absorbes » silencieusement
    par un crash, plutot qu'il ne decouvre la perte au prochain « Job perdu » 5 min
    plus tard en se demandant ce qui s'est passe.
    """
    try:
        work_root = cfg.WORK_ROOT.resolve()
    except (OSError, AttributeError):
        return
    if not work_root.is_dir():
        return
    recovered = {
        "done": 0, "error": 0, "cancelled": 0, "interrupted": 0,
        "running_orphan": 0, "queued_orphan": 0, "unreadable": 0,
    }
    try:
        marker_files = list(work_root.glob("**/pipeline_api_job_state.json"))
    except OSError:
        return
    for marker_path in marker_files:
        try:
            d = json.loads(marker_path.read_text(encoding="utf-8", errors="replace"))
        except (OSError, json.JSONDecodeError):
            recovered["unreadable"] += 1
            continue
        st = str(d.get("status") or "").lower()
        if st in ("done", "error", "cancelled", "interrupted"):
            recovered[st] = recovered.get(st, 0) + 1
        elif st in ("running", "queued"):
            recovered["running_orphan" if st == "running" else "queued_orphan"] += 1
    if any(v > 0 for v in recovered.values()):
        import logging
        logging.getLogger("thermo_pw.api").warning(
            "[Rebind] scan disque %s : %s - utilisez 'Charger un calcul precedent' pour les orphelins.",
            work_root,
            ", ".join(f"{k}={v}" for k, v in recovered.items() if v > 0),
        )


# P1 - appel au boot du module, AVANT les routes. Survit aux crashs silencieux :
# le warning marque la perte d'etat cote log serveur.
_rehydrate_jobs_from_disk_marker()


def _process_memory_stats():
    """Juillet 2026 (P3++) - metriques memoire + ballast FD pour precurseur OOM.

    Lit ``/proc/self/status`` (Linux / WSL2) et ``/proc/self/fd`` (meme OS).
    No-op silencieux si ``/proc`` absent (Windows natif, conteneur verrouille) :
    renvoie ``None`` plutot que zero pour distinguer « non observable » de
    « 0 Mo ».

    Champs exposes cote ``/api/health`` :
      * ``api_memory_vmrss_mb``        - RSS courant (taille residente, en Mo)
      * ``api_memory_vmpeak_mb``       - Pic RSS depuis demarrage (en Mo)
      * ``api_memory_threads``         - Nombre de threads Python + OS
      * ``api_memory_num_fds``         - len(os.listdir('/proc/self/fd')) - FD leaks
      * ``api_memory_rssfile_mb``      - RssFile /proc/self/status - mmap'd wfc/wavecar
      * ``api_memory_vmdata_mb``       - VmData /proc/self/status - segment data

    Une remontee de ``api_memory_vmpeak_mb > 4 GiB`` OU
    ``api_memory_num_fds > 512`` (heuristique grossiere ; var selon le workload)
    doit alerter (signal precurseur d'un futur OOM-kill / fd-exhaustion) - a
    brancher sur une Prometheus alert / Grafana plus tard.
    """
    out = {
        "api_memory_vmrss_mb": None,
        "api_memory_vmpeak_mb": None,
        "api_memory_threads": None,
        "api_memory_num_fds": None,
        "api_memory_rssfile_mb": None,
        "api_memory_vmdata_mb": None,
    }
    try:
        # (1) /proc/self/status : RSS, peak, threads, RssFile, VmData
        try:
            with open("/proc/self/status", "r", encoding="utf-8", errors="replace") as f:
                stats = {}
                for line in f:
                    if ":" in line and (
                        line.startswith("VmRSS:")
                        or line.startswith("VmPeak:")
                        or line.startswith("VmData:")
                        or line.startswith("RssFile:")
                        or line.startswith("Threads:")
                    ):
                        k, v = line.split(":", 1)
                        stats[k.strip()] = v.strip()
            rss_kb = int(stats.get("VmRSS", "0").split()[0])
            peak_kb = int(stats.get("VmPeak", "0").split()[0])
            threads = int(stats.get("Threads", "0").split()[0])
            rssfile_kb = int(stats.get("RssFile", "0").split()[0])
            vmdata_kb = int(stats.get("VmData", "0").split()[0])
            out["api_memory_vmrss_mb"] = round(rss_kb / 1024, 1)
            out["api_memory_vmpeak_mb"] = round(peak_kb / 1024, 1)
            out["api_memory_threads"] = threads
            out["api_memory_rssfile_mb"] = round(rssfile_kb / 1024, 1)
            out["api_memory_vmdata_mb"] = round(vmdata_kb / 1024, 1)
        except (OSError, ValueError, IndexError, AttributeError):
            pass
        # (2) /proc/self/fd : len pour FD leak detection (Quantum ESPRESSO peut
        # ouvrir des dizaines de wfc/wavecar ; si cleanup oublie, count grimpe).
        try:
            import os as _os
            out["api_memory_num_fds"] = len(_os.listdir("/proc/self/fd"))
        except (OSError, ValueError, AttributeError):
            pass
        return out
    except Exception:  # pragma: no cover - filet de securite final
        return out




def _rehydrate_jobs_from_disk_marker():
    """Juillet 2026 (P1) - resilience post-crash API.

    Scanne ``cfg.WORK_ROOT/**/pipeline_api_job_state.json`` au boot et logge un
    resume des statuts terminaux / orphelins ``running``. Ne peut PAS ressusciter
    le subprocess MPI perdu (mort avec le process parent) - la reprise effective
    reste manuelle via la section UI « Charger un calcul precedent » (les markers
    disque sont deja listes par ``/api/pipeline/runs``).

    But : informer l'operateur combien de jobs ont ete « absorbes » silencieusement
    par un crash, plutot qu'il ne decouvre la perte au prochain « Job perdu » 5 min
    plus tard en se demandant ce qui s'est passe.
    """
    try:
        work_root = cfg.WORK_ROOT.resolve()
    except (OSError, AttributeError):
        return
    if not work_root.is_dir():
        return
    recovered = {
        "done": 0, "error": 0, "cancelled": 0, "interrupted": 0,
        "running_orphan": 0, "queued_orphan": 0, "unreadable": 0,
    }
    try:
        marker_files = list(work_root.glob("**/pipeline_api_job_state.json"))
    except OSError:
        return
    for marker_path in marker_files:
        try:
            d = json.loads(marker_path.read_text(encoding="utf-8", errors="replace"))
        except (OSError, json.JSONDecodeError):
            recovered["unreadable"] += 1
            continue
        st = str(d.get("status") or "").lower()
        if st in ("done", "error", "cancelled", "interrupted"):
            recovered[st] = recovered.get(st, 0) + 1
        elif st in ("running", "queued"):
            recovered["running_orphan" if st == "running" else "queued_orphan"] += 1
    if any(v > 0 for v in recovered.values()):
        import logging
        logging.getLogger("thermo_pw.api").warning(
            "[Rebind] scan disque %s : %s - utilisez 'Charger un calcul precedent' pour les orphelins.",
            work_root,
            ", ".join(f"{k}={v}" for k, v in recovered.items() if v > 0),
        )


# P1 - appel au boot du module, AVANT les routes. Survit aux crashs silencieux :
# le warning marque la perte d'etat cote log serveur.
_rehydrate_jobs_from_disk_marker()


@app.route("/api/health", methods=["GET", "OPTIONS"])
def health():
    if request.method == "OPTIONS":
        return "", 204
    _gp = resolve_gnuplot_executable()

    def _bin(path_fn) -> dict[str, object]:
        p = path_fn()
        return {"path": str(p), "present": bool(p.is_file())}

    qe_x = {
        "pw.x": _bin(cfg.pw_path),
        "ph.x": _bin(cfg.ph_path),
        "pp.x": _bin(cfg.pp_path),
        "q2r.x": _bin(cfg.q2r_path),
        "matdyn.x": _bin(cfg.matdyn_path),
        "dynmat.x": _bin(cfg.dynmat_path),
        "thermo_pw.x": _bin(cfg.thermo_pw_path),
        "turbo_lanczos.x": _bin(cfg.turbo_lanczos_path),
        "turbo_davidson.x": _bin(cfg.turbo_davidson_path),
        "epsilon.x": _bin(cfg.epsilon_path),
    }
    return jsonify(
        {
            "ok": True,
            "thermo_repo_root": str(cfg.THERMO_REPO_ROOT),
            "work_root": str(cfg.WORK_ROOT),
            "inputs_dir": str(cfg.INPUTS_DIR),
            "outputs_dir": str(cfg.OUTPUTS_DIR),
            "pseudos_dir": str(cfg.PSEUDOS_DIR),
            "qe_bin": str(cfg.QE_BIN),
            "qe_executables": qe_x,
            "gnuplot": _gp is not None,
            "gnuplot_path": _gp or "",
            "eos_ev_plot_engine": "gnuplot uniquement",
            "thermo_pw_out_parse_revision": THERMO_PW_OUT_PARSE_REVISION,
            "eos_active_job_count": len(_eos_jobs_active_list()),
            "api_restart_remote_enabled": False,
            "api_restart_auth_disabled": False,
            "api_restart_localhost_only": True,
            "api_restart_uses_external_script": bool(cfg.THERMO_API_RESTART_SCRIPT),
            # Juillet 2026 — fiche technique téléchargeable (md/html). L'UI grise
            # le bouton « 📋 Fiche technique » quand l'endpoint n'est pas
            # chargé (rare ; pipeline.py absent → register_factsheet_blueprint
            # aurait planté).
            "factsheet_available": bool(globals().get("FACTSHEET_AVAILABLE", False)),
            # Juillet 2026 — option PDF du factsheet (WeasyPrint côté serveur).
            # L'UI grise l'option PDF dans le sélecteur quand FAUX.
            "factsheet_pdf_available": bool(globals().get("FACTSHEET_PDF_AVAILABLE", False)),
            # Juillet 2026 — versioning exposé pour le bandeau UI. ``factsheet_version``
            # suit un schéma ``MAJOR.MINOR`` (rupture de contrat vs ajout de section
            # profil-aware). ``factsheet_compiled_at`` est UTC ``YYYY-MM-DD`` —
            # traçable jusqu'au commit git (même valeur que ``git log --format=%ci``).
            # Présents seulement si le factsheet est chargé (rétro-compat UI).
            "factsheet_version": globals().get("_FACTSHEET_VERSION", None),
            "factsheet_compiled_at": globals().get("_FACTSHEET_COMPILED_AT", None),
            "factsheet_ai_version": globals().get("_FACTSHEET_AI_VERSION", None),
            "factsheet_ai_compiled_at": globals().get("_FACTSHEET_AI_COMPILED_AT", None),
            # Juillet 2026 (P3) - metriques memoire process API pour detecter
            # les derives pre-OOM-kill (api_memory_vmpeak_mb > 4 GiB = alerte).
            **_process_memory_stats(),
        }
    )


@app.route("/api/admin/restart", methods=("POST", "OPTIONS"))
def post_admin_restart() -> Any:
    """
    Redémarrage du serveur (dev / poste utilisateur uniquement).

    Sécurité : désactivé si ``THERMO_API_RESTART_TOKEN`` est vide ; le jeton doit être
    passé dans le corps JSON ``{"token": "…"}``.
    Sans ``THERMO_API_RESTART_SCRIPT`` : ``os.execv`` du même interpréteur + api_server.py
    après un court délai (recharge le code Python).
    Avec ``THERMO_API_RESTART_SCRIPT`` : le script est lancé en arrière-plan ; il doit
    tuer ``$THERMO_API_PID_TO_STOP``.
    """
    if request.method == "OPTIONS":
        return "", 204
    addr = (request.remote_addr or "").strip()
    if addr not in ("127.0.0.1", "::1"):
        return jsonify({
            "ok": False,
            "error": "restart_localhost_only",
            "hint": "POST /api/admin/restart n'est accepté que depuis 127.0.0.1.",
        }), 403

    script = cfg.THERMO_API_RESTART_SCRIPT
    if script:
        sp = Path(script).expanduser().resolve()
        if not sp.is_file():
            return jsonify({"ok": False, "error": "bad_script", "path": str(sp)}), 500
        env_run = os.environ.copy()
        env_run["THERMO_API_PID_TO_STOP"] = str(os.getpid())
        subprocess.Popen(
            ["/bin/sh", str(sp)],
            cwd=str(cfg.THERMO_REPO_ROOT.resolve()),
            env=env_run,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        return jsonify(
            {
                "ok": True,
                "mode": "script",
                "pid": env_run["THERMO_API_PID_TO_STOP"],
                "hint": "Le script doit terminer le processus THERMO_API_PID_TO_STOP (ex. kill).",
            }
        )

    main_py = Path(__file__).resolve()

    def _reexec_delayed() -> None:
        time.sleep(0.45)
        try:
            os.execv(sys.executable, [sys.executable, str(main_py)] + sys.argv[1:])
        except OSError:
            os._exit(1)

    threading.Thread(target=_reexec_delayed, daemon=False, name="thermo_pw_reexec").start()
    return jsonify(
        {
            "ok": True,
            "mode": "reexec",
            "hint": "Rechargement du processus dans < 1 s. Rafraîchir la page après ~3–5 s.",
        }
    )


@app.route("/api/materials", methods=["GET", "OPTIONS"])
def list_materials():
    if request.method == "OPTIONS":
        return "", 204
    mats = [m.to_dict() for m in mi.collect_materials()]
    return jsonify({"materials": mats, "inputs_dir": str(cfg.INPUTS_DIR)})


@app.route("/api/materials/<path:material_id>", methods=["GET", "OPTIONS"])
def get_material(material_id: str):
    if request.method == "OPTIONS":
        return "", 204
    m = mi.find_material(material_id)
    if not m:
        return jsonify({"error": f"Matériau inconnu : {material_id}"}), 404
    return jsonify(m.to_dict())


@app.route("/api/workflow1/work/browse", methods=["GET", "OPTIONS"])
def browse_work_tree():
    """
    Liste les sous-dossiers d’un chemin sous thermo_pw/work/ (navigation type /work).
    Query: path= (optionnel) — chemin absolu ; sans paramètre = racine work.
    """
    if request.method == "OPTIONS":
        return "", 204
    root = cfg.WORK_ROOT.resolve()
    try:
        root.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    raw = (request.args.get("path") or "").strip()
    if not raw:
        current = root
    else:
        p = Path(raw).expanduser().resolve()
        if not p.is_dir():
            return jsonify({"error": f"Dossier introuvable : {p}"}), 400
        if not _is_allowed_eos_work_dir(p):
            return jsonify({"error": "Le chemin doit être sous thermo_pw/work/."}), 403
        current = p
    can_up = current != root
    parent = current.parent if can_up else root
    if can_up and not _is_allowed_eos_work_dir(parent):
        can_up = False
        parent = root
    try:
        if current != root and current.resolve().parent == root:
            ensure_material_workspace(current)
    except OSError:
        pass
    entries: list[dict[str, Any]] = []
    try:
        for c in sorted(current.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
            if c.is_dir() and not c.name.startswith("."):
                entries.append(
                    {
                        "name": c.name,
                        "path": str(c.resolve()),
                        "is_dir": True,
                    }
                )
    except OSError as ex:
        return jsonify({"error": str(ex)}), 500
    return jsonify(
        {
            "work_root": str(root),
            "current": str(current.resolve()),
            "parent": str(parent.resolve()) if can_up else str(root),
            "can_go_up": can_up,
            "entries": entries,
        }
    )


@app.route("/api/workflow1/work/default_run_dir", methods=["GET", "OPTIONS"])
def get_default_run_dir_for_material():
    """
    Dernier dossier ``wf1_eos_*`` : sous ``work/<material_id>/run_eos/`` (nouveau)
    ou à la racine du matériau (anciens runs).
    """
    if request.method == "OPTIONS":
        return "", 204
    raw = (request.args.get("material_id") or "").strip()
    if not raw:
        return jsonify({"error": "material_id requis (query)."}), 400
    safe = _safe_material_id(raw)
    root = cfg.WORK_ROOT.resolve()
    try:
        root.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    mat_dir = (root / safe).resolve()
    try:
        mat_dir.relative_to(root)
    except ValueError:
        return jsonify({"error": "Matériau invalide."}), 400
    if not mat_dir.is_dir():
        return jsonify(
            {
                "work_dir": None,
                "material_id": safe,
                "hint": (
                    "Aucun dossier work/" + safe + "/ — créez un run (workflow EOS) pour générer "
                    "run_eos/wf1_eos_…"
                ),
            }
        ), 200
    ensure_material_workspace(mat_dir)
    runs_mt: list[tuple[float, Path]] = []
    try:
        for c in iter_wf1_eos_run_dirs(mat_dir):
            try:
                runs_mt.append((c.stat().st_mtime, c.resolve()))
            except OSError:
                continue
    except OSError as ex:
        return jsonify({"error": str(ex)}), 500
    if not runs_mt:
        return jsonify(
            {
                "work_dir": None,
                "material_id": safe,
                "hint": "Aucun dossier wf1_eos_* dans work/" + safe + "/ (voir run_eos/ ou racine matériau).",
            }
        ), 200
    runs_mt.sort(key=lambda t: -t[0])
    best = runs_mt[0][1]
    return jsonify(
        {
            "work_dir": str(best),
            "material_id": safe,
            "run_folder": best.name,
            "runs_found": len(runs_mt),
        }
    ), 200


@app.route("/api/inputs/thermo", methods=["GET", "OPTIONS"])
def list_thermo_inputs_tree():
    """Liste des matériaux sous `thermo_pw/inputs` ayant au moins un fichier .in."""
    if request.method == "OPTIONS":
        return "", 204
    mats = [m.to_dict() for m in mi.list_thermo_input_materials()]
    return jsonify({"inputs_dir": str(cfg.INPUTS_DIR), "materials": mats})


@app.route("/api/inputs/thermo/<path:material_id>", methods=["GET", "OPTIONS"])
def get_thermo_input_material(material_id: str):
    """Détail d'un matériau dans `thermo_pw/inputs/<material_id>/` uniquement."""
    if request.method == "OPTIONS":
        return "", 204
    m = mi.find_thermo_inputs_only(material_id)
    if not m:
        return (
            jsonify(
                {
                    "error": "Dossier introuvable ou sans fichier .in",
                    "path_expected": str(cfg.INPUTS_DIR / material_id),
                    "inputs_dir": str(cfg.INPUTS_DIR),
                }
            ),
            404,
        )
    return jsonify(m.to_dict())


@app.route(
    "/api/workflow/optics/inputs_check",
    methods=["GET", "OPTIONS"],
    strict_slashes=False,
)
def get_optics_inputs_check():
    """Classe les .in d'un matériau (SCF / NSCF / turbo / epsilon / thermo_pw) sous inputs/."""
    if request.method == "OPTIONS":
        return "", 204
    mid = (request.args.get("material_id") or "").strip()
    if not mid:
        return jsonify({"error": "material_id requis"}), 400
    rep = optics_inputs_check.report_for_material_param(mid)
    if not rep:
        return (
            jsonify(
                {
                    "error": "Dossier matériau introuvable sous inputs/",
                    "path_expected": str(cfg.INPUTS_DIR / mid),
                    "inputs_dir": str(cfg.INPUTS_DIR),
                }
            ),
            404,
        )
    return jsonify(rep), 200


@app.route(
    "/api/workflow/optics/templates",
    methods=["GET", "OPTIONS"],
    strict_slashes=False,
)
def list_optics_templates():
    """Liste les fichiers .in sous templates/optics/ (gabarits chaîne optique)."""
    if request.method == "OPTIONS":
        return "", 204
    d = (cfg.THERMO_REPO_ROOT / "templates" / "optics").resolve()
    if not d.is_dir():
        return jsonify({"templates": [], "templates_dir": str(d)}), 200
    names = sorted(
        p.name for p in d.iterdir() if p.is_file() and p.suffix.lower() == ".in"
    )
    return jsonify(
        {
            "templates": [{"basename": n, "path": str(d / n)} for n in names],
            "templates_dir": str(d),
        }
    ), 200


_MAX_IN_PREVIEW = 512 * 1024


@app.route("/api/inputs/preview", methods=["GET", "OPTIONS"])
def preview_input_file():
    """Lecture du contenu d’un .in (aperçu dans l’interface) — chemin autorisé comme pour EOS."""
    if request.method == "OPTIONS":
        return "", 204
    raw = (request.args.get("path") or "").strip()
    if not raw:
        return jsonify({"error": "Paramètre path requis"}), 400
    p = Path(raw).expanduser().resolve()
    if not p.is_file() or p.suffix.lower() != ".in":
        return jsonify({"error": "Fichier .in introuvable"}), 400
    if not cfg.is_path_under_allowed_template(p):
        return jsonify({"error": "Chemin non autorisé", "path": str(p)}), 403
    try:
        st = p.stat()
        if st.st_size > _MAX_IN_PREVIEW:
            return (
                jsonify(
                    {
                        "error": f"Fichier trop volumineux (max {_MAX_IN_PREVIEW} octets)",
                    }
                ),
                400,
            )
        content = p.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        return jsonify({"error": str(e)}), 500
    return jsonify({"path": str(p), "content": content})


@app.route("/api/inputs/save", methods=list(EOS_JSON_POST_METHODS), strict_slashes=False)
def post_inputs_save():
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    path_raw = (data.get("path") or "").strip()
    content = data.get("content")
    if not path_raw or content is None:
        return jsonify({"error": "Champs path et content requis."}), 400
    p = Path(path_raw).expanduser().resolve()
    try:
        ie.save_input(p, content if isinstance(content, str) else str(content))
    except ValueError as e:
        return jsonify({"error": str(e)}), 403
    except OSError as e:
        return jsonify({"error": str(e)}), 500
    return jsonify({"ok": True, "path": str(p)})


@app.route("/api/inputs/save_pseudo_generator", methods=list(EOS_JSON_POST_METHODS), strict_slashes=False)
def post_inputs_save_pseudo_generator():
    """Alias familier `/api/inputs/*` — même corps JSON que POST /api/pseudos/save_local_input (évite 405 selon proxy / pile)."""
    return pseudo_save_local_input_dispatch()


@app.route("/api/inputs/transform", methods=list(EOS_JSON_POST_METHODS), strict_slashes=False)
def post_inputs_transform():
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    content = data.get("content")
    if not isinstance(content, str):
        return jsonify({"error": "Champ content (string) requis."}), 400
    material_id = _safe_material_id((data.get("material_id") or "").strip() or "material")
    op = (data.get("op") or "").strip().lower()
    if op in ("thermo_paths", "paths"):
        out = ie.apply_thermo_paths(content, material_id)
    elif op in ("reinforce_light", "light"):
        out = ie.reinforce_params(content, "light")
    elif op in ("reinforce_medium", "medium"):
        out = ie.reinforce_params(content, "medium")
    else:
        return (
            jsonify(
                {
                    "error": "op inconnu (thermo_paths, reinforce_light, reinforce_medium).",
                }
            ),
            400,
        )
    return jsonify(
        {
            "content": out,
            "material_id": material_id,
            "op": op,
        }
    )


@app.route("/api/inputs/cif_to_pw", methods=list(EOS_JSON_POST_METHODS), strict_slashes=False)
def post_inputs_cif_to_pw():
    """
    Corps JSON : ``cif`` (texte), ``ibrav`` (int, défaut 0), ``celldm`` (optionnel dict/list),
    ``pseudopotentials`` (optionnel), ``ecutwfc``, ``ecutrho``, ``kpts`` [nx,ny,nz].

    - ``ibrav=0`` : ``CELL_PARAMETERS`` = maille du CIF (ASE) ; pas équivalent strict à « conventionnel » :
      c’est la géométrie telle que dans le fichier (souvent grande maille pour F/I si le CIF l’indique).

    - ``ibrav≠0`` : convention Bravais QE + ``celldm`` ; vérifier cohérence positions / ``nat`` avec cette
      convention (pas de réduction automatique primitive ↔ conventionnel).

    Sans ``infer_ibrav`` : pour ``ibrav≠0`` fournir ``celldm`` (INPUT_PW), sauf ``ibrav=1`` + cube simple où
    un ``celldm(1)`` peut être déduit seul.

    - ``use_crystal_sg`` (bool, défaut ``false``) : ``ATOMIC_POSITIONS crystal_sg`` + ``space_group`` ITA dans
      ``&SYSTEM``, avec atomes réduits aux sites inéquivalents (CIF avec groupe d’espace reconnu par ASE).

    - ``infer_ibrav`` (bool, défaut ``false``) : déduit ``ibrav`` et ``celldm`` depuis le symbole de Pearson
      (groupe d’espace IT > 1 dans le CIF, sinon géométrie de la maille). Les CIF sans symétrie (ASE → P1)
      utilisent la détection géométrique. Échec possible pour certaines classes : alors ``ibrav=0`` ou celldm manuels.
    """
    if request.method == "OPTIONS":
        return "", 204
    if build_pw_input_from_cif is None:
        return (
            jsonify(
                {
                    "error": (
                        "Le paquet Python « ase » est requis pour CIF→pw. "
                        "Installez les dépendances : pip install -r backend/requirements.txt"
                    ),
                }
            ),
            503,
        )
    data = request.get_json(silent=True) or {}
    cif = data.get("cif")
    if not isinstance(cif, str) or not cif.strip():
        return jsonify({"error": "Champ « cif » (chaîne non vide) requis."}), 400
    try:
        ibrav = int(data.get("ibrav", 0))
    except (TypeError, ValueError):
        return jsonify({"error": "ibrav doit être un entier (ex. 0, 1, 2, −3)." }), 400
    pseudo_raw = data.get("pseudopotentials")
    pseudo: Optional[dict[str, str]] = None
    if isinstance(pseudo_raw, dict):
        pseudo = {str(k): str(v) for k, v in pseudo_raw.items()}

    def _float_opt(key: str, default: float) -> float:
        try:
            v = data.get(key, default)
            return float(v) if v is not None else float(default)
        except (TypeError, ValueError):
            raise ValueError(f"{key} numérique invalide.") from None

    try:
        ecutwfc = _float_opt("ecutwfc", 40.0)
        ecutrho = _float_opt("ecutrho", 320.0)
        conv_thr = _float_opt("conv_thr", 1e-6)
    except ValueError as ex:
        return jsonify({"error": str(ex)}), 400

    kr = data.get("kpts", [4, 4, 4])
    if isinstance(kr, list) and len(kr) == 3:
        try:
            kpts = (max(1, int(kr[0])), max(1, int(kr[1])), max(1, int(kr[2])))
        except (TypeError, ValueError):
            return jsonify({"error": "kpts doit être trois entiers ≥ 1."}), 400
    else:
        return jsonify({"error": "kpts doit être une liste [nx, ny, nz]."}), 400

    crystal_coordinates = bool(data.get("crystal_coordinates", True))
    celldm_arg = data.get("celldm")
    use_crystal_sg = bool(data.get("use_crystal_sg", False))
    infer_ibrav = bool(data.get("infer_ibrav", False))

    try:
        content, meta = build_pw_input_from_cif(
            cif,
            ibrav=ibrav,
            celldm=celldm_arg,
            pseudopotentials=pseudo,
            ecutwfc=ecutwfc,
            ecutrho=ecutrho,
            kpts=kpts,
            crystal_coordinates=crystal_coordinates,
            conv_thr=conv_thr,
            use_crystal_sg=use_crystal_sg,
            infer_ibrav=infer_ibrav,
        )
    except ValueError as ex:
        return jsonify({"error": str(ex)}), 400
    except Exception as ex:
        return jsonify({"error": str(ex)}), 500

    return jsonify({"content": content, "meta": meta}), 200


@app.route("/api/outputs/clean", methods=list(EOS_JSON_POST_METHODS), strict_slashes=False)
def post_outputs_clean():
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    mid = (data.get("material_id") or "").strip()
    if not mid:
        return jsonify({"error": "material_id requis."}), 400
    try:
        result = ie.clean_outputs_for_material(mid)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify(result)


# Enregistré *avant* /api/workflow1/eos : évite toute ambiguïté de routage.
@app.route(
    "/api/workflow1/eos/fit-only",
    methods=["POST", "GET", "HEAD", "OPTIONS"],
    strict_slashes=False,
)
@app.route(
    "/api/workflow1/eos_fit_only",
    methods=["POST", "GET", "HEAD", "OPTIONS"],
    strict_slashes=False,
)
def post_workflow1_eos_fit_only():
    """
    Relit les scf_vol_XX.out existants, fit Birch–Murnaghan, écrit scf_eq.in / eos_summary.json.
    Ne lance pas pw.x (utile si les SCF sont déjà faits).
    """
    if request.method in ("GET", "HEAD"):
        if request.method == "HEAD":
            return "", 200
        return (
            jsonify(
                {
                    "ok": True,
                    "message": "Utilisez POST (JSON) pour l’ajustement seul. Redémarrez l’API si ce GET renvoyait 405 auparavant.",
                    "post_fields": [
                        "work_dir",
                        "template_pw",
                        "material_id",
                        "n_points",
                        "strain_percent",
                    ],
                }
            ),
            200,
        )
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    if not raw_wd:
        return (
            jsonify(
                {
                    "error": "Champ work_dir requis (dossier du run, ex. .../work/Si/wf1_eos_...).",
                }
            ),
            400,
        )
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir():
        return jsonify({"error": f"Dossier introuvable : {work_dir}"}), 400
    if not _is_allowed_eos_work_dir(work_dir):
        return (
            jsonify(
                {
                    "error": "work_dir doit être sous thermo_pw/work/ (déplacements non autorisés).",
                }
            ),
            403,
        )
    raw_mid = (data.get("material_id") or "").strip()
    inferred_mid = _infer_material_id_from_wf1_work_dir(work_dir)
    effective_for_tpl = (raw_mid or inferred_mid or "").strip()
    material_id = _safe_material_id(effective_for_tpl or "material")
    template_pw: Optional[Path] = None
    template_raw = (data.get("template_pw") or "").strip()
    template_basename = (data.get("template_basename") or "").strip() or None
    if template_raw:
        template_pw = Path(template_raw).expanduser()
    else:
        cand0 = work_dir / EOS_VOLUMES_SUBDIR / "scf_vol_00.in"
        if cand0.is_file():
            template_pw = cand0
        elif effective_for_tpl:
            template_pw = mi.resolve_template(effective_for_tpl, template_basename)
    if template_pw is None or not template_pw.is_file():
        return (
            jsonify(
                {
                    "error": "Fichier modèle .in introuvable : indiquez template_pw, "
                    "ou un matériau sous inputs/, ou le dossier doit contenir "
                    "1_eos_volumes/scf_vol_00.in (run EOS existant).",
                }
            ),
            400,
        )
    if not cfg.is_path_under_allowed_template(template_pw):
        return (
            jsonify(
                {
                    "error": "template_pw non autorisé.",
                }
            ),
            403,
        )
    n_points = int(data.get("n_points", 7))
    tdir = work_dir / EOS_VOLUMES_SUBDIR
    n_outs = len(list_scf_vol_outs_ordered(tdir)) if tdir.is_dir() else 0
    if n_outs >= 2:
        n_points = n_outs
    m_pct = int(data.get("strain_percent", data.get("m", 3)))
    if n_points < 2:
        return jsonify({"error": "n_points doit être ≥ 2"}), 400
    if m_pct < 1 or m_pct > 30:
        return jsonify({"error": "m (déformation max en %) entre 1 et 30"}), 400
    job_id = uuid.uuid4().hex[:12]
    with _jobs_lock:
        _jobs[job_id] = {
            "status": "queued",
            "message": "Ajustement EOS seul (lecture .out)",
            "work_dir": str(work_dir),
            "material_id": material_id,
            "template_used": str(template_pw.resolve()),
            "fit_only": True,
            "mode": "fit_only",
        }
    _persist_job_disk(job_id)
    t = threading.Thread(
        target=_run_eos_fit_only_job,
        kwargs={
            "job_id": job_id,
            "work_dir": work_dir,
            "material_id": material_id,
            "template_pw": template_pw,
            "n_points": n_points,
            "strain_min_pct": -m_pct,
            "strain_max_pct": m_pct,
        },
        daemon=True,
    )
    t.start()
    return (
        jsonify(
            {
                "job_id": job_id,
                "work_dir": str(work_dir),
                "status": "queued",
                "template_used": str(template_pw.resolve()),
                "mode": "fit_only",
            }
        ),
        202,
    )


@app.route("/api/workflow1/eos", methods=list(EOS_JSON_POST_METHODS), strict_slashes=False)
def post_workflow1_eos():
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    raw_mid = (data.get("material_id") or "").strip()
    material_id = _safe_material_id(raw_mid or "material")

    template_pw: Optional[Path] = None
    template_raw = (data.get("template_pw") or "").strip()
    template_basename = (data.get("template_basename") or "").strip() or None

    if template_raw:
        template_pw = Path(template_raw).expanduser()
    elif raw_mid:
        template_pw = mi.resolve_template(raw_mid, template_basename)
        if template_pw is None:
            return (
                jsonify(
                    {
                        "error": "Impossible de résoudre le fichier .in : indiquez template_pw "
                        "ou placez le matériau sous thermo_pw/inputs/<Mat>/",
                    }
                ),
                400,
            )
    else:
        return jsonify(
            {
                "error": "Indiquez material_id (dossier sous inputs/) ou le chemin absolu template_pw.",
            }
        ), 400

    if not template_pw.is_file():
        return jsonify({"error": f"Fichier introuvable : {template_pw}"}), 400
    if not cfg.is_path_under_allowed_template(template_pw):
        return (
            jsonify(
                {
                    "error": "Chemin modèle non autorisé (hors work, inputs thermo_pw ou THERMO_EOS_ALLOW_PREFIXES).",
                    "allow_roots": [str(p) for p in cfg.eos_template_allowed_roots()],
                }
            ),
            403,
        )

    n_points = int(data.get("n_points", 7))
    m_pct = int(data.get("strain_percent", data.get("m", 3)))
    nproc = int(data.get("nproc", cfg.MPI_NPROC))
    sequential = bool(data.get("sequential", False))

    if n_points < 2:
        return jsonify({"error": "n_points doit être ≥ 2"}), 400
    if m_pct < 1 or m_pct > 30:
        return jsonify({"error": "m (déformation max en %) doit être entre 1 et 30"}), 400
    if nproc < 1:
        return jsonify({"error": "nproc invalide"}), 400

    mode_raw = (data.get("mode") or "full").strip().lower()
    _eos_mode_aliases = {
        "volumes": "volumes_only",
        "volumes_only": "volumes_only",
        "grid": "volumes_only",
        "gen": "volumes_only",
        "scf": "scf_and_fit",
        "scf_and_fit": "scf_and_fit",
        "run_scf": "scf_and_fit",
        "scf_only": "scf_only",
        "pw_only": "scf_only",
        "full": "full",
        "all": "full",
    }
    mode = _eos_mode_aliases.get(mode_raw, mode_raw)
    if mode not in ("full", "volumes_only", "scf_and_fit", "scf_only"):
        mode = "full"

    if mode in ("scf_and_fit", "scf_only"):
        raw_wd = (data.get("work_dir") or "").strip()
        if not raw_wd:
            return (
                jsonify(
                    {
                        "error": "work_dir requis (dossier work/.../wf1_eos_... rempli après la génération de la grille).",
                    }
                ),
                400,
            )
        wdir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
        if not wdir.is_dir():
            return jsonify({"error": f"Dossier introuvable : {wdir}"}), 400
        if not _is_allowed_eos_work_dir(wdir):
            return jsonify({"error": "Dossier de travail non autorisé (hors thermo_pw/work/)."}), 403
        job_id = uuid.uuid4().hex[:12]
        target = (
            _run_eos_scf_from_work_dir_job
            if mode == "scf_and_fit"
            else _run_eos_scf_only_from_work_dir_job
        )
        with _jobs_lock:
            _jobs[job_id] = {
                "status": "queued",
                "message": "En file d’attente",
                "work_dir": str(wdir.resolve()),
                "material_id": material_id,
                "template_used": str(template_pw.resolve()),
                "mode": mode,
            }
        _persist_job_disk(job_id)
        t = threading.Thread(
            target=target,
            kwargs={
                "job_id": job_id,
                "work_dir": wdir,
                "material_id": material_id,
                "template_pw": template_pw,
                "n_points": n_points,
                "strain_min_pct": -m_pct,
                "strain_max_pct": m_pct,
                "nproc": nproc,
                "sequential": sequential,
            },
            daemon=True,
        )
        t.start()
        return (
            jsonify(
                {
                    "job_id": job_id,
                    "work_dir": str(wdir.resolve()),
                    "status": "queued",
                    "template_used": str(template_pw.resolve()),
                    "mode": mode,
                }
            ),
            202,
        )

    mat_root = (cfg.WORK_ROOT / material_id).resolve()
    ensure_material_workspace(mat_root)
    work_dir = mat_root / RUN_EOS_DIR / f"wf1_eos_{int(time.time())}_{uuid.uuid4().hex[:6]}"
    work_dir.mkdir(parents=True, exist_ok=True)
    write_wf1_run_readme(work_dir)
    job_id = uuid.uuid4().hex[:12]
    with _jobs_lock:
        _jobs[job_id] = {
            "status": "queued",
            "message": "En file d’attente",
            "work_dir": str(work_dir.resolve()),
            "material_id": material_id,
            "template_used": str(template_pw.resolve()),
            "mode": mode,
        }
    _persist_job_disk(job_id)
    if mode == "volumes_only":
        t = threading.Thread(
            target=_run_eos_volumes_only_job,
            kwargs={
                "job_id": job_id,
                "work_dir": work_dir,
                "material_id": material_id,
                "template_pw": template_pw,
                "n_points": n_points,
                "strain_min_pct": -m_pct,
                "strain_max_pct": m_pct,
            },
            daemon=True,
        )
    else:
        t = threading.Thread(
            target=_run_eos_job,
            kwargs={
                "job_id": job_id,
                "work_dir": work_dir,
                "material_id": material_id,
                "template_pw": template_pw,
                "n_points": n_points,
                "strain_min_pct": -m_pct,
                "strain_max_pct": m_pct,
                "nproc": nproc,
                "sequential": sequential,
            },
            daemon=True,
        )
    t.start()
    return (
        jsonify(
            {
                "job_id": job_id,
                "work_dir": str(work_dir.resolve()),
                "status": "queued",
                "template_used": str(template_pw.resolve()),
                "mode": mode,
            }
        ),
        202,
    )


@app.route("/api/workflow1/eos/persisted_job_state", methods=["GET", "OPTIONS"])
def get_persisted_job_state():
    """Dernier job API enregistré dans le run (reprise après coupure / redémarrage)."""
    if request.method == "OPTIONS":
        return "", 204
    raw = (request.args.get("work_dir") or "").strip()
    if not raw:
        return jsonify({"error": "Paramètre work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        return jsonify({"error": "work_dir invalide ou hors zone work/"}), 400
    persisted = api_job_persist.read_job_marker(work_dir)
    wf = _read_workflow_state(work_dir)
    persisted_out = dict(persisted) if isinstance(persisted, dict) else persisted
    if isinstance(persisted_out, dict):
        stp = str(persisted_out.get("status") or "").lower()
        if stp in ("running", "queued"):
            try:
                pp = estimate_job_progress_pct(work_dir, persisted_out)
                if pp is not None:
                    persisted_out["progress_pct"] = pp
            except OSError:
                pass
    return jsonify(
        {
            "work_dir": str(work_dir.resolve()),
            "persisted": persisted_out,
            "workflow_state": wf,
        }
    )


@app.route("/api/pipeline/runs/<job_id>/files", methods=["GET", "OPTIONS"])
def api_pipeline_runs_files(job_id: str):
    """Liste exhaustive des artefacts du work_dir d'un run (juillet 2026).

    Renvoie ``{kind: [relpath, …]}`` pour chaque catégorie :
    ``png``, ``pdf``, ``gs`` (scripts gnuplot), ``dat`` (données brutes),
    ``in`` (entrées QE), ``out`` (logs), ``json`` (markers),
    ``other`` (rares). Capée à 80 fichiers.

    Consommée par le front (« Panneau Artefacts » de la section Résultats)
    qui propose une prévisualisation en ligne (PNG/PDF/text) via
    ``/api/pipeline/runs/<job_id>/result_file``.

    Codes : 200 / 404 / 503 (work_dir absent).
    """
    if request.method == "OPTIONS":
        return "", 204
    wd = _resolve_pipeline_job_workdir(job_id)
    if wd is None or not wd.is_dir() or not _is_allowed_eos_work_dir(wd):
        return jsonify({
            "error": "work_dir introuvable pour job_id",
            "job_id": job_id,
        }), 404
    # Lecture marker (results.plots + output_files) + scan direct.
    try:
        marker_dict = {}
        marker_path = wd / "pipeline_api_job_state.json"
        if marker_path.is_file():
            try:
                marker_dict = json.loads(
                    marker_path.read_text(encoding="utf-8", errors="replace")
                )
            except (OSError, json.JSONDecodeError):
                marker_dict = {}
        results = marker_dict.get("results") or {}
    except Exception:
        results = {}
    try:
        # PostScript -> PDF: lazy convert residual *.ps to *.pdf so /files picks them up.
        # Idempotent (skips when .pdf already fresh); best-effort, never aborts /files.
        try:
            from ps_to_pdf import convert_postscript_to_pdf
            convert_postscript_to_pdf(wd)
        except Exception:
            pass
        from factsheet import _section_artifacts
        rows = _section_artifacts(results, wd)
    except Exception as ex:
        return jsonify({"error": "scan artefacts impossible", "detail": str(ex)}), 500
    grouped: dict[str, list[str]] = {
        "png": [], "pdf": [], "gs": [], "dat": [],
        "in": [], "out": [], "json": [], "ps": [], "other": [],
    }
    for _basename, relpath, kind in rows:
        grouped.setdefault(kind, grouped["other"]).append(relpath)
    # counts pour le front (UI badges).
    counts = {k: len(v) for k, v in grouped.items()}
    return jsonify({
        "job_id": job_id,
        "work_dir": str(wd),
        "kinds": grouped,
        "counts": counts,
        "total": sum(counts.values()),
        "hint": (
            "Utilisez '/api/pipeline/runs/<job_id>/result_file?path=<relpath>&inline=1' "
            "pour ouvrir un fichier (PNG/PDF/text) inline dans un nouvel onglet "
            "ou dans une modale de prévisualisation."
        ),
    }), 200


@app.route("/api/pipeline/runs/<job_id>/result_file", methods=["GET", "OPTIONS"])
def api_pipeline_runs_result_file(job_id: str):
    """Sert un fichier du work_dir d'un run (inline par défaut ; tail supporté).

    Args (query) :
      * ``path`` (obligatoire) : chemin relatif sous le work_dir (forward slashes).
      * ``inline`` (``1`` par défaut) :
          ``1`` → ``Content-Disposition: inline`` (le navigateur TENTE
          d'afficher : image, PDF, texte).
          ``0`` → ``Content-Disposition: attachment; filename=…``
          (téléchargement forcé).
      * ``tail`` (entier ≥ 1, fichiers texte UNIQUEMENT) : retourne les
        ``N`` dernières lignes via ``_tail_utf8_file``. Très utile pour les
        gros ``.out`` (5–50 Mo) sans geler le navigateur.
      * ``max_size`` (5 Mo par défaut) : cap lecture. Au-delà, 400 sauf si
        ``tail`` est fourni (tail reste capé par ``_tail_utf8_file`` à
        64 ko de chunk et la sortie est en bytes légers).

    MIME strict par extension :
      * ``.png`` → ``image/png`` ; ``.pdf`` → ``application/pdf`` ;
        ``.json`` → ``application/json`` ; tout le reste (``.gs``/``.dat``/
        ``.in``/``.out``/``.log``) → ``text/plain; charset=utf-8``
        pour permettre l'aperçu en clair (et éviter que le navigateur
        propose un téléchargement agressif).

    Codes : 200 (mime + contenu) ; 400 (bad query / trop gros) ; 403 (path
    hors work_dir) ; 404 (fichier absent / job inconnu) ; 503 (work_dir indispo).
    """
    if request.method == "OPTIONS":
        return "", 204
    wd = _resolve_pipeline_job_workdir(job_id)
    if wd is None or not wd.is_dir() or not _is_allowed_eos_work_dir(wd):
        return jsonify({
            "error": "work_dir introuvable pour job_id",
            "job_id": job_id,
        }), 503
    relpath = (request.args.get("path") or "").strip()
    if not relpath:
        return jsonify({
            "error": "Paramètre 'path' (relpath sous work_dir) requis.",
        }), 400
    abs_path = _eos_run_child_path(str(wd), relpath)
    if abs_path is None:
        return jsonify({
            "error": f"Chemin invalide ou hors work_dir : {relpath}",
        }), 403
    if not abs_path.is_file():
        return jsonify({
            "error": f"Fichier introuvable : {relpath}",
            "work_dir": str(wd),
        }), 404
    # Tail support (text only).
    tail_raw = (request.args.get("tail") or "").strip()
    use_tail = False
    tail_n: Optional[int] = None
    if tail_raw:
        try:
            tail_n = max(1, min(200_000, int(tail_raw)))
            use_tail = True
        except ValueError:
            return jsonify({"error": "tail doit être un entier."}), 400
    # MIME strict.
    suf = abs_path.suffix.lower()
    MIME_FOR_SUFFIX = {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".svg": "image/svg+xml",
        ".pdf": "application/pdf",
        ".json": "application/json",
        ".js": "application/javascript",
        ".css": "text/css",
    }
    if suf in MIME_FOR_SUFFIX:
        mime = MIME_FOR_SUFFIX[suf]
    else:
        # Tout le reste en text/plain pour affichage inline dans le navigateur.
        mime = "text/plain; charset=utf-8"
    is_text_only = mime.startswith("text/")
    try:
        size = abs_path.stat().st_size
    except OSError:
        size = 0
    # Cap max_size.
    max_size_raw = (request.args.get("max_size") or "").strip()
    try:
        max_size = int(max_size_raw) if max_size_raw else 5 * 1024 * 1024
    except ValueError:
        return jsonify({"error": "max_size doit être un entier (octets)."}), 400
    if not use_tail and size > max_size:
        return jsonify({
            "error": (
                f"Fichier trop volumineux : {size} octets > max_size={max_size}. "
                "Ajoutez ?tail=N pour ne lire que les N dernières lignes "
                "(fichiers texte uniquement)."
            ),
            "size_bytes": size,
            "max_size_bytes": max_size,
        }), 400
    # Inline / attachment.
    inline_raw = (request.args.get("inline") or "1").strip()
    is_inline = inline_raw not in ("0", "false", "no")
    # Construire la réponse.
    try:
        if use_tail and is_text_only and tail_n is not None:
            text, _sz, _trunc = _tail_utf8_file(abs_path, tail_n, 64 * 1024)
            resp = Response(text.encode("utf-8", errors="replace"), mimetype=mime)
        else:
            resp = send_file(
                abs_path,
                mimetype=mime,
                as_attachment=not is_inline,
                conditional=True,
            )
        # Filename propre pour le frontend (toujours fourni pour
        # faciliter l'enregistrement depuis le bouton « Télécharger »).
        safe_basename = re.sub(r"[^A-Za-z0-9._-]+", "_", abs_path.name)[:120] or "file"
        # Content-Disposition : inline vs attachment.
        disposition = (
            f'inline; filename="{safe_basename}"'
            if is_inline
            else f'attachment; filename="{safe_basename}"'
        )
        resp.headers["Content-Disposition"] = disposition
        resp.headers["Cache-Control"] = "no-store, max-age=0"
        resp.headers["X-Thermo-Served-File"] = safe_basename
        return resp
    except FileNotFoundError:
        return jsonify({"error": f"Fichier disparu pendant la lecture : {relpath}"}), 404
    except Exception as ex:
        return jsonify({
            "error": "Lecture / envoi du fichier impossible.",
            "detail": str(ex),
            "type": type(ex).__name__,
        }), 500


@app.route("/api/workflow1/eos/jobs", methods=["GET", "OPTIONS"])
def list_eos_jobs():
    """Liste les calculs encore en file ou en cours (ce serveur uniquement)."""
    if request.method == "OPTIONS":
        return "", 204
    active = _eos_jobs_active_list()
    return jsonify(
        {
            "active_jobs": active,
            "active_count": len(active),
            "hint": (
                "Un lancement (POST) renvoie un job_id ; GET …/jobs/<job_id> pour le détail ; "
                "GET …/persisted_job_state?work_dir=… pour le dernier état enregistré sur disque "
                f"(fichier {api_job_persist.MARKER_NAME}) après coupure ou redémarrage ; "
                "POST …/eos/purge_active {\"scope\":\"last\"|\"all\"} (recommandé) ou …/jobs/purge_active — thermo_pw.x. "
                "Les jobs uniquement en mémoire disparaissent si l’API redémarre ; le fichier par run conserve done / error / interrupted."
            ),
        }
    )


@app.route("/api/workflow1/eos/purge_active", methods=list(EOS_JSON_POST_METHODS))
@app.route("/api/workflow1/eos/jobs/purge_active", methods=list(EOS_JSON_POST_METHODS))
def post_purge_active_thermo_pw_jobs():
    """Annule un ou tous les jobs ``run_thermo_pw`` encore ``queued`` / ``running``.

    Préférez ``POST …/eos/purge_active`` pour éviter tout conflit avec ``GET …/jobs/<job_id>`` (405 si mal routé).
    """
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    scope_raw = (data.get("scope") or data.get("mode") or "").strip().lower()
    if scope_raw not in ("last", "all", "single"):
        return (
            jsonify(
                {
                    "error": 'Corps JSON : {"scope":"last"} ou {"scope":"all"} ou {"scope":"single","job_id":"…"} — purge des jobs thermo_pw.x actifs uniquement.',
                }
            ),
            400,
        )
    job_id_single_raw = (data.get("job_id") or "").strip()
    if scope_raw == "single" and not job_id_single_raw:
        return jsonify({"error": "scope:\"single\" requiert un job_id."}), 400
    with _jobs_lock:
        items = list(_jobs.items())
    cancel_requested: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    if scope_raw == "last":
        for job_id, _j in reversed(items):
            if str(_j.get("kind") or "") != "run_thermo_pw":
                continue
            st = str(_j.get("status") or "").lower()
            if st not in ("queued", "running"):
                continue
            sig = _signal_cancel_run_thermo_pw_job(job_id)
            if sig.get("result") == "cancel_requested":
                cancel_requested.append(sig)
                break
            skipped.append(sig)
    elif scope_raw == "single":
        found = False
        for job_id, _j in items:
            if job_id != job_id_single_raw:
                continue
            found = True
            if str(_j.get("kind") or "") != "run_thermo_pw":
                skipped.append(_signal_cancel_run_thermo_pw_job(job_id))
                break
            st = str(_j.get("status") or "").lower()
            if st not in ("queued", "running"):
                skipped.append(_signal_cancel_run_thermo_pw_job(job_id))
                break
            sig = _signal_cancel_run_thermo_pw_job(job_id)
            if sig.get("result") == "cancel_requested":
                cancel_requested.append(sig)
            else:
                skipped.append(sig)
            break
        if not found:
            return jsonify({"error": "job_id inconnu pour la purge simple."}), 404
    else: # scope_raw == "all"
        for job_id, _j in items:
            if str(_j.get("kind") or "") != "run_thermo_pw":
                continue
            st = str(_j.get("status") or "").lower()
            if st not in ("queued", "running"):
                continue
            sig = _signal_cancel_run_thermo_pw_job(job_id)
            if sig.get("result") == "cancel_requested":
                cancel_requested.append(sig)
            else:
                skipped.append(sig)
    active_other: list[dict[str, Any]] = []
    for job_id, _j in items:
        st = str(_j.get("status") or "").lower()
        if st not in ("queued", "running"):
            continue
        if str(_j.get("kind") or "") == "run_thermo_pw":
            continue
        active_other.append(
            {
                "job_id": job_id,
                "kind": _j.get("kind"),
                "status": st,
                "note": "Non annulé par purge_active — seuls run_thermo_pw sont gérés.",
            }
        )
    msg = (
        f"Purge « {scope_raw} » : {len(cancel_requested)} job(s) thermo_pw.x — annulation signalée."
        if cancel_requested
        else (
            "Aucun job thermo_pw.x actif annulable (ou déjà terminés / sans cancel_event)."
        )
    )
    if scope_raw == "single" and len(cancel_requested) == 0 and len(skipped) == 0:
        msg = f"Le job {job_id_single_raw} n'a pas pu être purgé (déjà terminé, kind incorrect ou sans mécanisme d'annulation)."
    elif scope_raw == "single" and len(cancel_requested) == 1:
        msg = f"Le job {job_id_single_raw} a été purgé."

    return (
        jsonify(
            {
                "scope": scope_raw,
                "job_id_single": job_id_single_raw if scope_raw == "single" else None,
                "cancel_requested": cancel_requested,
                "skipped": skipped,
                "active_other_kinds": active_other,
                "message": msg,
                "hint": "Les jobs lancés hors API (shell pur) n’apparaissent pas ici ; utilisez kill/pkill côté système.",
            }
        ),
        202,
    )


@app.route("/api/workflow1/eos/jobs/<job_id>/cancel", methods=list(EOS_JSON_POST_METHODS))
def post_cancel_eos_job(job_id: str):
    """Annule un job thermo_pw.x en cours (SIGTERM au groupe MPI) ou encore en file."""
    if request.method == "OPTIONS":
        return "", 204
    sig = _signal_cancel_run_thermo_pw_job(job_id)
    res = sig.get("result")
    if res == "not_found":
        return jsonify({"error": "job_id inconnu"}), 404
    if res == "wrong_kind":
        return (
            jsonify(
                {
                    "error": "Annulation API réservée pour l’instant aux jobs thermo_pw.x (run_thermo_pw).",
                    "kind": sig.get("kind"),
                }
            ),
            400,
        )
    if res == "already_finished":
        return jsonify({"error": "Job déjà terminé.", "status": sig.get("status")}), 400
    if res == "no_cancel_event":
        return (
            jsonify(
                {
                    "error": "Job sans mécanisme d’annulation (version ancienne du serveur). Redémarrer api_server.py.",
                    "job_id": job_id,
                }
            ),
            500,
        )
    return (
        jsonify(
            {
                "job_id": job_id,
                "status": "cancel_requested",
                "message": "Annulation signalée — arrêt du groupe MPI thermo_pw.x (SIGTERM puis SIGKILL si besoin).",
            }
        ),
        202,
    )


@app.route("/api/workflow1/eos/jobs/<job_id>", methods=["GET", "OPTIONS"])
def get_job(job_id: str):
    if request.method == "OPTIONS":
        return "", 204
    with _jobs_lock:
        j = _jobs.get(job_id)
    if not j:
        return jsonify({"error": "job_id inconnu"}), 404
    out: dict[str, Any] = {
        "status": j.get("status"),
        "message": j.get("message", ""),
        "work_dir": j.get("work_dir"),
        "material_id": j.get("material_id"),
        "template_used": j.get("template_used"),
    }
    wd = j.get("work_dir")
    if wd:
        state = _read_workflow_state(Path(wd))
        if state is not None:
            out["workflow_state"] = state
    if j.get("status") == "done" and j.get("summary"):
        s = j["summary"]
        eos = s.get("eos", {})
        out["V0_bohr3"] = eos.get("V0_bohr3")
        out["B0_GPa_approx"] = s.get("B0_GPa_approx")
        out["eq_input"] = s.get("eq_input_generated")
        out["pw_for_phonon"] = s.get("pw_for_phonon")
        out["summary"] = s
    if j.get("kind"):
        out["kind"] = j["kind"]
    if j.get("thermo_what"):
        out["thermo_what"] = j["thermo_what"]
    if j.get("nproc") is not None:
        out["nproc"] = j["nproc"]
    if j.get("pw_in"):
        out["pw_in"] = j["pw_in"]
    if j.get("log_file"):
        out["log_file"] = j["log_file"]
    if j.get("gnuplot_relpath"):
        out["gnuplot_relpath"] = j["gnuplot_relpath"]
    if j.get("cube_relpath"):
        out["cube_relpath"] = j["cube_relpath"]
    if j.get("pp_charge_in_relpath"):
        out["pp_charge_in_relpath"] = j["pp_charge_in_relpath"]
    if j.get("mode"):
        out["mode"] = j["mode"]
    wd_s = j.get("work_dir")
    if wd_s and j.get("status") in ("running", "queued"):
        try:
            pp = estimate_job_progress_pct(Path(str(wd_s)).expanduser().resolve(), j)
            if pp is not None:
                out["progress_pct"] = pp
        except OSError:
            pass
    if j.get("status") == "error" and j.get("kind") in PHONON_QE_JOB_KINDS and wd_s:
        try:
            wdp = Path(str(wd_s)).expanduser().resolve()
            if wdp.is_dir():
                ph_hint = diagnosis_hint_for_phonon_qe_job(
                    wdp,
                    str(j.get("kind") or ""),
                    str(j.get("message") or ""),
                )
                if ph_hint:
                    out["diagnosis_hint"] = ph_hint
        except OSError:
            pass
    return jsonify(out)


@app.route("/api/workflow1/eos/run_scf_v0", methods=list(EOS_JSON_POST_METHODS), strict_slashes=False)
def post_run_scf_v0():
    """Lance pw.x sur pw_scf_V0_for_phonon.in à la racine du run (étape 4)."""
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    nproc = int(data.get("nproc", cfg.MPI_NPROC))
    inp = (data.get("input_basename") or "pw_scf_V0_for_phonon.in").strip() or "pw_scf_V0_for_phonon.in"
    if nproc < 1:
        return jsonify({"error": "nproc invalide"}), 400
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    if not (work_dir / inp).is_file():
        return jsonify({"error": f"Fichier introuvable dans le run : {inp}"}), 400
    job_id = uuid.uuid4().hex[:12]
    with _jobs_lock:
        _jobs[job_id] = {
            "status": "queued",
            "message": "File d'attente (pw @ V0)",
            "work_dir": str(work_dir),
            "kind": "run_scf_v0",
        }
    _persist_job_disk(job_id)
    t = threading.Thread(
        target=_run_scf_v0_job,
        kwargs={
            "job_id": job_id,
            "work_dir": work_dir,
            "nproc": nproc,
            "inp_basename": inp,
        },
        daemon=True,
    )
    t.start()
    return (
        jsonify(
            {
                "job_id": job_id,
                "status": "queued",
                "work_dir": str(work_dir),
                "kind": "run_scf_v0",
            }
        ),
        202,
    )


@app.route("/api/workflow1/eos/run_ph", methods=list(EOS_JSON_POST_METHODS), strict_slashes=False)
def post_run_ph():
    """Lance ph.x (étape 5). Crée ph.in à partir de pw_scf_V0_for_phonon.in si absent."""
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    nproc = int(data.get("nproc", cfg.MPI_NPROC))
    inp = (data.get("input_basename") or "ph.in").strip() or "ph.in"
    if nproc < 1:
        return jsonify({"error": "nproc invalide"}), 400
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    autonote = ""
    if not (work_dir / inp).is_file():
        if data.get("auto_ph", True) is False:
            return (
                jsonify(
                    {
                        "error": f"Fichier {inp!r} introuvable. Créez-le (Howto 1.8) "
                        "ou relancez sans auto_ph:false pour génération automatique.",
                    }
                ),
                400,
            )
        n1, n2, n3 = nq_from_request_body(data)
        ok, msg = try_autogenerate_ph_in(
            work_dir,
            inp,
            nq1=n1,
            nq2=n2,
            nq3=n3,
        )
        if not ok:
            return jsonify({"error": msg}), 400
        autonote = msg
    job_id = uuid.uuid4().hex[:12]
    with _jobs_lock:
        _jobs[job_id] = {
            "status": "queued",
            "message": "File d'attente (ph.x)",
            "work_dir": str(work_dir),
            "kind": "run_ph",
        }
    _persist_job_disk(job_id)
    t = threading.Thread(
        target=_run_ph_x_job,
        kwargs={
            "job_id": job_id,
            "work_dir": work_dir,
            "nproc": nproc,
            "inp_basename": inp,
        },
        daemon=True,
    )
    t.start()
    out_ph: dict[str, Any] = {
        "job_id": job_id,
        "status": "queued",
        "work_dir": str(work_dir),
        "kind": "run_ph",
    }
    if autonote:
        out_ph["note"] = autonote
    return jsonify(out_ph), 202


@app.route("/api/workflow1/eos/write_ph_in", methods=list(EOS_JSON_POST_METHODS), strict_slashes=False)
def post_write_ph_in():
    """Écrit seulement ph.in (sans lancer ph.x) — même logique que run_ph."""
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    inp = (data.get("input_basename") or "ph.in").strip() or "ph.in"
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    overwrite = bool(data.get("overwrite"))
    if (work_dir / inp).is_file() and not overwrite:
        return (
            jsonify(
                {
                    "error": f"{inp!r} existe déjà. Passez overwrite:true pour l’écraser, "
                    "ou éditez le fichier à la main.",
                }
            ),
            400,
        )
    n1, n2, n3 = nq_from_request_body(data)
    ok, msg = try_autogenerate_ph_in(
        work_dir, inp, nq1=n1, nq2=n2, nq3=n3, force=overwrite
    )
    if not ok:
        return jsonify({"error": msg}), 400
    return jsonify(
        {
            "ok": True,
            "path": str((work_dir / inp).resolve()),
            "note": msg,
        }
    )


@app.route("/api/workflow1/eos/write_control_file", methods=list(EOS_JSON_POST_METHODS), strict_slashes=False)
def post_write_control_file():
    """Écrit ``thermo_control`` ou ``ph_control`` sous un dossier de run EOS (racine ou sous-dossier relatif sécurisé)."""
    if request.method == "OPTIONS":
        return "", 204
    _SAFE_CONTROL_BASE = frozenset({"thermo_control", "ph_control"})
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    basename = (data.get("basename") or "thermo_control").strip() or "thermo_control"
    subdir_raw = str(data.get("subdir") or "").strip().replace("\\", "/").strip("/")
    content_raw = data.get("content")
    if isinstance(content_raw, bytes):
        return jsonify({"error": "content doit être une chaîne UTF-8"}), 400
    content = (
        ""
        if content_raw is None
        else (content_raw if isinstance(content_raw, str) else str(content_raw))
    )
    max_bytes = int(data.get("max_bytes_validate") or 600_000)
    if len(content.encode("utf-8", errors="replace")) > max(1024, min(2_000_000, max_bytes)):
        return jsonify({"error": "content trop volumineux pour cet endpoint"}), 400
    if basename not in _SAFE_CONTROL_BASE:
        return jsonify({"error": f"basename doit être parmi : {sorted(_SAFE_CONTROL_BASE)}"}), 400
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d'environnement THERMO_WORK_ROOT si vous l'avez changée)."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    target_dir = work_dir
    if subdir_raw:
        parts = [p for p in subdir_raw.split("/") if p]
        if any(p in (".", "..") or (".." in p) for p in parts):
            return jsonify({"error": "subdir invalide"}), 400
        if not parts or len(parts) > 8:
            return jsonify({"error": "subdir trop profond ou vide"}), 400
        for p in parts:
            if not re.match(r"^[A-Za-z0-9_\-.]+$", p):
                return jsonify({"error": f"nom de segment refusé : {p!r}"}), 400
        target_dir = work_dir.joinpath(*parts)
        try:
            target_dir.relative_to(work_dir.resolve())
        except ValueError:
            return jsonify({"error": "subdir hors du dossier run"}), 400
        try:
            target_dir.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            return jsonify({"error": f"mkdir subdir impossible : {e}"}), 500
    out_path = (target_dir / basename).resolve()
    try:
        out_path.relative_to(work_dir.resolve())
    except ValueError:
        return jsonify({"error": "chemin cible hors du dossier run"}), 400
    try:
        out_path.write_text(content, encoding="utf-8", newline="\n")
    except OSError as e:
        return jsonify({"error": f"écriture impossible : {e}"}), 500
    return jsonify({"ok": True, "path": str(out_path)}), 200


@app.route("/api/workflow1/eos/qha_prereq", methods=["GET", "HEAD", "OPTIONS"])
def get_qha_prereq_check():
    """
    Vérifie prérequis QHA/thermo (3_phonon ou ph/ ou dyn/, fildyn, journaux) pour un work_dir.
    Query: work_dir (requis), fildyn (défaut dyn), no_eos_volumes=1 optionnel,
    mur_lc_driver=1 pour les mêmes contrôles + ph_control/ph.in/fc.out qu'avant POST run_thermo_pw (mur_lc_t, mur_lc_disp, mur_lc_t_elastic_constants).
    """
    if request.method in ("HEAD", "OPTIONS"):
        return "", 204
    raw_wd = (request.args.get("work_dir") or "").strip()
    if not raw_wd:
        return jsonify({"error": "work_dir requis (query)."}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    fildyn = (request.args.get("fildyn") or "dyn").strip() or "dyn"
    from_eos = (request.args.get("no_eos_volumes") or "").strip() not in ("1", "true", "yes")
    try:
        st = WorkflowDB.load(work_dir / WORKFLOW_STATE_FILENAME)
    except (OSError, json.JSONDecodeError, ValueError):
        st = WorkflowDB(material_id="", work_dir="")
    res = check_qha_prereqs(
        work_dir,
        fildyn=fildyn,
        db=st,
        under_eos_volumes=from_eos,
    )
    mur_lc_drv = (request.args.get("mur_lc_driver") or "").strip().lower() in ("1", "true", "yes")
    if mur_lc_drv:
        enrich_mur_lc_driver_prereqs(res, work_dir)
    return jsonify(res.as_dict()), 200


@app.route("/api/workflow1/eos/run_q2r", methods=list(EOS_JSON_POST_METHODS_PLUS_GET), strict_slashes=False)
def post_run_q2r():
    """§suite ph.x : q2r.x → fc.out (prérequis matrices dynamiques ph_dyn*).

    Option JSON ``dynamical_matrices_igeo`` (entier >= 1) : lire
    ``dynamical_matrices/ph_dyn.g{igeo}.*`` (sortie thermo_pw / ph.x récent)
    au lieu de ``ph_dyn0``, ``ph_dyn1``, … à la racine du run.
    """
    if request.method == "OPTIONS":
        return "", 204
    if request.method in ("GET", "HEAD"):
        return _eos_api_browser_get_help(
            {"dynamical_matrices_igeo": 1}
        )
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    if not cfg.q2r_path().is_file():
        return jsonify({"error": f"q2r.x introuvable : {cfg.q2r_path()}"}), 400
    flfrc = (data.get("flfrc") or "fc.out").strip() or "fc.out"
    dynamical_matrices_igeo: Optional[int] = None
    if data.get("dynamical_matrices_igeo") not in (None, ""):
        try:
            dynamical_matrices_igeo = int(data["dynamical_matrices_igeo"])
        except (TypeError, ValueError):
            return jsonify(
                {"error": "dynamical_matrices_igeo doit être un entier (ex. 1 pour la 1re géométrie)."}
            ), 400
        if dynamical_matrices_igeo < 1:
            return jsonify({"error": "dynamical_matrices_igeo doit être >= 1"}), 400
    job_id = uuid.uuid4().hex[:12]
    with _jobs_lock:
        _jobs[job_id] = {
            "status": "queued",
            "message": "File q2r.x",
            "work_dir": str(work_dir.resolve()),
            "kind": "run_q2r",
        }
    _persist_job_disk(job_id)
    threading.Thread(
        target=_run_q2r_job,
        kwargs={
            "job_id": job_id,
            "work_dir": work_dir,
            "flfrc": flfrc,
            "dynamical_matrices_igeo": dynamical_matrices_igeo,
        },
        daemon=True,
    ).start()
    return jsonify({"job_id": job_id, "status": "queued", "kind": "run_q2r"}), 202


@app.route(
    "/api/workflow1/eos/phonon_bands_from_dynamical_matrices",
    methods=list(EOS_JSON_POST_METHODS_PLUS_GET),
    strict_slashes=False,
)
def post_phonon_bands_from_dynamical_matrices():
    """q2r (dynamical_matrices/ph_dyn.g*.* pour une géométrie) → matdyn bandes → gnuplot phonon_bands.png."""
    if request.method == "OPTIONS":
        return "", 204
    if request.method in ("GET", "HEAD"):
        return _eos_api_browser_get_help({"dynamical_matrices_igeo": 1})
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    if not cfg.q2r_path().is_file():
        return jsonify({"error": f"q2r.x introuvable : {cfg.q2r_path()}"}), 400
    if not cfg.matdyn_path().is_file():
        return jsonify({"error": f"matdyn.x introuvable : {cfg.matdyn_path()}"}), 400
    try:
        igeo = int(data.get("dynamical_matrices_igeo", data.get("igeo", 1)))
    except (TypeError, ValueError):
        return jsonify({"error": "dynamical_matrices_igeo (ou igeo) doit être un entier ≥ 1"}), 400
    if igeo < 1:
        return jsonify({"error": "dynamical_matrices_igeo doit être ≥ 1"}), 400
    flfrc = (data.get("flfrc") or "fc.out").strip() or "fc.out"
    job_id = uuid.uuid4().hex[:12]
    with _jobs_lock:
        _jobs[job_id] = {
            "status": "queued",
            "message": "Bandes depuis dynamical_matrices…",
            "work_dir": str(work_dir.resolve()),
            "kind": "phonon_bands_from_dynamical_matrices",
        }
    _persist_job_disk(job_id)
    threading.Thread(
        target=_run_phonon_bands_from_dynamical_matrices_job,
        kwargs={
            "job_id": job_id,
            "work_dir": work_dir,
            "igeo": igeo,
            "flfrc": flfrc,
        },
        daemon=True,
    ).start()
    return (
        jsonify(
            {
                "job_id": job_id,
                "status": "queued",
                "kind": "phonon_bands_from_dynamical_matrices",
                "dynamical_matrices_igeo": igeo,
            }
        ),
        202,
    )


@app.route("/api/workflow1/eos/run_matdyn_bands", methods=list(EOS_JSON_POST_METHODS_PLUS_GET), strict_slashes=False)
def post_run_matdyn_bands():
    """§1.8 : matdyn.x — dispersions ; chemin q par défaut selon ``ibrav`` du pw (voir README §2, fc.out requis)."""
    if request.method == "OPTIONS":
        return "", 204
    if request.method in ("GET", "HEAD"):
        return _eos_api_browser_get_help({"flfrc": "fc.out"})
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    if not cfg.matdyn_path().is_file():
        return jsonify({"error": f"matdyn.x introuvable : {cfg.matdyn_path()}"}), 400
    flfrc = (data.get("flfrc") or "fc.out").strip() or "fc.out"
    job_id = uuid.uuid4().hex[:12]
    with _jobs_lock:
        _jobs[job_id] = {
            "status": "queued",
            "message": "File matdyn (bandes)",
            "work_dir": str(work_dir.resolve()),
            "kind": "run_matdyn_bands",
        }
    _persist_job_disk(job_id)
    threading.Thread(
        target=_run_matdyn_bands_job,
        kwargs={"job_id": job_id, "work_dir": work_dir, "flfrc": flfrc},
        daemon=True,
    ).start()
    return jsonify({"job_id": job_id, "status": "queued", "kind": "run_matdyn_bands"}), 202


@app.route("/api/workflow1/eos/run_dynmat", methods=list(EOS_JSON_POST_METHODS_PLUS_GET), strict_slashes=False)
def post_run_dynmat():
    """§1.10 (modes à q fixé / analyse) : dynmat.x sur un fichier ph_dyn*."""
    if request.method == "OPTIONS":
        return "", 204
    if request.method in ("GET", "HEAD"):
        return _eos_api_browser_get_help({"fildyn_file": "ph_dyn1"})
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    if not cfg.dynmat_path().is_file():
        return jsonify({"error": f"dynmat.x introuvable : {cfg.dynmat_path()}"}), 400
    fdf = (data.get("fildyn_file") or "").strip() or None
    job_id = uuid.uuid4().hex[:12]
    with _jobs_lock:
        _jobs[job_id] = {
            "status": "queued",
            "message": "File dynmat.x",
            "work_dir": str(work_dir.resolve()),
            "kind": "run_dynmat",
        }
    _persist_job_disk(job_id)
    threading.Thread(
        target=_run_dynmat_job,
        kwargs={"job_id": job_id, "work_dir": work_dir, "fildyn_file": fdf},
        daemon=True,
    ).start()
    return jsonify({"job_id": job_id, "status": "queued", "kind": "run_dynmat"}), 202


def _tok_pw_in_relative(raw: str) -> Optional[str]:
    """Chemin relatif au run, ex. ``pw_scf_V0_for_phonon.in`` ou ``1_eos_volumes/scf_vol_12.in``."""
    t = (raw or "").strip()
    if not t or len(t) > 220:
        return None
    if ".." in t or t.startswith(("/", "\\")):
        return None
    t = t.replace("\\", "/")
    for seg in t.split("/"):
        if not seg:
            return None
        for c in seg:
            if not (c.isalnum() or c in "._-"):
                return None
    if not t.lower().endswith(".in"):
        return None
    return t


def _tok_filplot_rel(raw: str) -> Optional[str]:
    """Nom ou chemin relatif du préfixe filplot (ex. ``charge_density_map`` ou ``tmp/charge_density``)."""
    t = (raw or "").strip()
    if not t or len(t) > 200:
        return None
    if ".." in t or t.startswith(("/", "\\")):
        return None
    t = t.replace("\\", "/")
    for seg in t.split("/"):
        if not seg:
            return None
        for c in seg:
            if not (c.isalnum() or c in "._-"):
                return None
    return t


def _tok_charge_dat_relpath(raw: str) -> Optional[str]:
    """Chemin relatif à un ``.dat`` de densité déjà présent (ex. ``tmp/charge-density.dat``)."""
    t = (raw or "").strip()
    if not t or len(t) > 240:
        return None
    if ".." in t or t.startswith(("/", "\\")):
        return None
    t = t.replace("\\", "/")
    if not t.lower().endswith(".dat"):
        return None
    for seg in t.split("/"):
        if not seg:
            return None
        for c in seg:
            if not (c.isalnum() or c in "._-"):
                return None
    return t


@app.route("/api/workflow1/eos/run_pp_charge", methods=list(EOS_JSON_POST_METHODS_PLUS_GET), strict_slashes=False)
@app.route("/api/workflow1/eos/pp_charge", methods=list(EOS_JSON_POST_METHODS_PLUS_GET), strict_slashes=False)
@app.route("/api/run_pp_charge", methods=list(EOS_JSON_POST_METHODS_PLUS_GET), strict_slashes=False)
@app.route("/api/pp_charge", methods=list(EOS_JSON_POST_METHODS_PLUS_GET), strict_slashes=False)
def post_run_pp_charge():
    """Post-traitement : pp.x pour exporter la densité (XSF format 5, Cube 6, …)."""
    if request.method == "OPTIONS":
        return "", 204
    if request.method in ("GET", "HEAD"):
        return _eos_api_browser_get_help(
            {
                "pw_in_basename": "(optionnel) ex. pw_scf_V0_for_phonon.in — défaut : auto, fichier dont prefix/outdir coïncident avec les données .save",
                "reuse_charge_dat": True,
                "charge_dat_relpath": "(optionnel) ex. tmp/charge-density.dat — force la réutilisation de ce .dat (section &PLOT seule)",
                "plot_num": 0,
                "output_format": 5,
                "fileout": "charge_density.xsf",
                "filplot": "(optionnel) défaut auto si .dat détecté ; sinon charge_density_map ou chemin relatif",
                "cube_name": "(alias de fileout, ex. charge_density.cube si output_format=6)",
            }
        )

    def _tok_pp_token(raw: str, *, default: Optional[str], allow_empty: bool) -> Optional[str]:
        """Nom court sans chemin (fileout, filplot) ; allow_empty + default=None → None si vide."""
        t = (raw or "").strip()
        if not t:
            return default if not allow_empty else None
        if len(t) > 180 or "/" in t or "\\" in t or t.startswith("."):
            return None
        if ".." in t:
            return None
        for c in t:
            if not (c.isalnum() or c in "._-"):
                return None
        return t

    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    raw_pw = str(data.get("pw_in_basename") or "").strip()
    explicit: Optional[str] = None
    if raw_pw:
        explicit = _tok_pw_in_relative(raw_pw)
        if explicit is None:
            return (
                jsonify(
                    {
                        "error": (
                            "pw_in_basename invalide — utilisez un chemin relatif au dossier du run "
                            "(ex. pw_scf_V0_for_phonon.in ou 1_eos_volumes/scf_vol_12.in), sans .."
                        ),
                        "hint": "Laissez pw_in_basename absent ou vide pour un choix automatique cohérent avec les fichiers prefix.save.",
                    }
                ),
                400,
            )
    try:
        pw_in = resolve_pw_in_basename_for_pp(work_dir, explicit, require_existing_save=True)
    except FileNotFoundError as ex:
        return (
            jsonify(
                {
                    "error": str(ex),
                    "hint": "Placez l’entrée pw du SCF terminé dans le dossier du run ; work_dir doit être la racine wf1_eos (thermo_pw_run.out).",
                }
            ),
            400,
        )
    except ValueError as ex:
        return (
            jsonify(
                {
                    "error": str(ex),
                    "hint": "pp.x exige le même prefix et le même outdir que le pw.x dont les fichiers .save sont sur disque.",
                }
            ),
            400,
        )
    raw_fo = str(data.get("fileout") or data.get("cube_name") or "").strip()
    fileout_opt = _tok_pp_token(raw_fo, default=None, allow_empty=True)
    if raw_fo and fileout_opt is None:
        return jsonify({"error": "fileout / cube_name invalide (nom seul, sans chemin)"}), 400
    raw_fl = str(data.get("filplot") or "").strip()
    filplot_opt = _tok_filplot_rel(raw_fl) if raw_fl else None
    if raw_fl and filplot_opt is None:
        return jsonify(
            {"error": "filplot invalide (nom ou chemin relatif au run, ex. tmp/charge_density_map, sans ..)"}
        ), 400
    raw_cd = str(data.get("charge_dat_relpath") or "").strip()
    charge_dat_opt = _tok_charge_dat_relpath(raw_cd) if raw_cd else None
    if raw_cd and charge_dat_opt is None:
        return jsonify(
            {
                "error": "charge_dat_relpath invalide (ex. tmp/charge-density.dat sous le dossier du run)",
                "hint": "Laissez vide pour détection automatique des charge-density.dat (souvent dans outdir/tmp).",
            }
        ), 400
    rcv = data.get("reuse_charge_dat")
    reuse_charge_dat = True if rcv is None else bool(rcv)
    try:
        plot_num = int(data.get("plot_num", 0))
    except (TypeError, ValueError):
        return jsonify({"error": "plot_num invalide"}), 400
    plot_num = max(0, min(plot_num, 64))
    output_format_opt: Optional[int] = None
    if data.get("output_format") not in (None, ""):
        try:
            output_format_opt = int(data["output_format"])
        except (TypeError, ValueError):
            return jsonify({"error": "output_format invalide (entier, ex. 5=XSF, 6=Cube)"}), 400
        output_format_opt = max(0, min(output_format_opt, 99))
    exe_pp = cfg.pp_path()
    if not exe_pp.is_file():
        return jsonify({"error": f"pp.x introuvable : {exe_pp} (QE_BIN ou THERMO_PP)"}), 400
    job_id = uuid.uuid4().hex[:12]
    with _jobs_lock:
        _jobs[job_id] = {
            "status": "queued",
            "message": "File pp.x (densité)",
            "work_dir": str(work_dir.resolve()),
            "kind": "run_pp_charge",
        }
    _persist_job_disk(job_id)
    threading.Thread(
        target=_run_pp_charge_job,
        kwargs={
            "job_id": job_id,
            "work_dir": work_dir,
            "pw_in_basename": pw_in,
            "plot_num": plot_num,
            "fileout": fileout_opt,
            "output_format": output_format_opt,
            "filplot": filplot_opt,
            "reuse_charge_dat": reuse_charge_dat,
            "charge_dat_relpath": charge_dat_opt,
        },
        daemon=True,
    ).start()
    return jsonify({"job_id": job_id, "status": "queued", "kind": "run_pp_charge"}), 202


@app.route("/api/workflow1/eos/run_matdyn_dos", methods=list(EOS_JSON_POST_METHODS_PLUS_GET), strict_slashes=False)
def post_run_matdyn_dos():
    """§1.9 (DOS phonons harmonique) : matdyn.x avec dos=.true."""
    if request.method == "OPTIONS":
        return "", 204
    if request.method in ("GET", "HEAD"):
        return _eos_api_browser_get_help({"flfrc": "fc.out", "nk1": 24, "nk2": 24, "nk3": 24})
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    if not cfg.matdyn_path().is_file():
        return jsonify({"error": f"matdyn.x introuvable : {cfg.matdyn_path()}"}), 400
    flfrc = (data.get("flfrc") or "fc.out").strip() or "fc.out"
    nk1 = int(data.get("nk1", 24))
    nk2 = int(data.get("nk2", 24))
    nk3 = int(data.get("nk3", 24))
    if nk1 < 1 or nk2 < 1 or nk3 < 1:
        return jsonify({"error": "nk1,nk2,nk3 doivent être ≥ 1"}), 400
    job_id = uuid.uuid4().hex[:12]
    with _jobs_lock:
        _jobs[job_id] = {
            "status": "queued",
            "message": "File matdyn (DOS)",
            "work_dir": str(work_dir.resolve()),
            "kind": "run_matdyn_dos",
        }
    _persist_job_disk(job_id)
    threading.Thread(
        target=_run_matdyn_dos_job,
        kwargs={
            "job_id": job_id,
            "work_dir": work_dir,
            "nk1": nk1,
            "nk2": nk2,
            "nk3": nk3,
            "flfrc": flfrc,
        },
        daemon=True,
    ).start()
    return jsonify({"job_id": job_id, "status": "queued", "kind": "run_matdyn_dos"}), 202


def _normalize_job_work_dir_str(work_dir: Path) -> str:
    try:
        return str(work_dir.resolve())
    except OSError:
        return str(work_dir)


def _active_thermo_pw_job_for_dir(work_dir: Path) -> Optional[tuple[str, str]]:
    """Si un job ``run_thermo_pw`` est encore ``queued`` ou ``running`` sur ce dossier, retourne (job_id, status)."""
    wd_key = _normalize_job_work_dir_str(work_dir)
    with _jobs_lock:
        for jid, d in _jobs.items():
            if str(d.get("kind") or "") != "run_thermo_pw":
                continue
            st = str(d.get("status") or "").lower()
            if st not in ("queued", "running"):
                continue
            jwd = str(d.get("work_dir") or "").strip()
            if not jwd:
                continue
            try:
                jnorm = str(Path(jwd).expanduser().resolve())
            except OSError:
                jnorm = jwd
            if jnorm == wd_key:
                return jid, st
    return None


def _tpw_what_requires_qha_phonon_prereq(what_val: str) -> bool:
    """mur_lc_t, elastic_constants_geo (P3), ph_life (P4), alias legacy."""
    x = (what_val or "").strip().strip("'\"").lower()
    return x in {
        "thermo",
        "mur_lc_t",
        "mur_lc_disp",
        "mur_lc_t_elastic_constants",
        "elastic_constants_geo",
        "ph_life",
        "qha_lif",
    }


@app.route("/api/workflow1/eos/run_thermo_pw", methods=list(EOS_JSON_POST_METHODS), strict_slashes=False)
def post_run_thermo_pw():
    """§1.15+ : thermo_pw.x + thermo_control minimal (MPI). Peut être très long.

    Corps JSON facultatif :
    ``clear_thermo_restart`` (défaut ``true``) — supprime ``restart/e_work_part*``
    avant le calcul pour éviter des reprises MPI tronquées (forrtl 24 EOF).
    Mettre ``false`` pour tenter une reprise après une coupure maîtrisée (risque EOF si incohérent).
    """
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    if not cfg.thermo_pw_path().is_file():
        return jsonify({"error": f"thermo_pw.x introuvable : {cfg.thermo_pw_path()}"}), 400
    nproc = int(data.get("nproc", cfg.MPI_NPROC))
    if nproc < 1:
        return jsonify({"error": "nproc invalide"}), 400
    pw_in = (data.get("pw_in") or "pw_scf_V0_for_phonon.in").strip() or "pw_scf_V0_for_phonon.in"
    thermo_opts: dict[str, Any] = {}
    if isinstance(data.get("thermo"), dict):
        thermo_opts.update(data["thermo"])
    for key in (
        "what",
        "tmin",
        "tmax",
        "deltat",
        "fildyn",
        "zasr",
        "ltherm_dos",
        "ltherm_freq",
        # Solveur de l'ajustement QHA (1=équations normales, 2=QR, 3=SVD).
        # Indispensable pour relancer la seule étape anharmonique après un
        # abandon de DGELS, sans refaire les phonons.
        "lsolve",
    ):
        if key in data:
            thermo_opts[key] = data[key]
    job_id = uuid.uuid4().hex[:12]
    what_val = str(thermo_opts.get("what") or data.get("what") or "").strip()
    skip_mur_lc_prereq = bool(
        data.get("skip_mur_lc_prereq_check") or data.get("skip_prereq_check")
    )
    if _tpw_what_requires_qha_phonon_prereq(what_val) and not skip_mur_lc_prereq:
        try:
            st_pr = WorkflowDB.load(work_dir / "workflow_state.json")
        except (OSError, json.JSONDecodeError, ValueError):  # noqa: PERF203
            st_pr = WorkflowDB(material_id="", work_dir="")
        fildyn_chk = resolve_fildyn_for_qha_prereq(work_dir, thermo_opts, data)
        pr_res = check_qha_prereqs(work_dir, fildyn=fildyn_chk, db=st_pr)
        enrich_mur_lc_driver_prereqs(pr_res, work_dir)
        if not pr_res.ok:
            return (
                jsonify(
                    {
                        "error": "Prérequis phonons / fichiers avant "
                        + what_val
                        + " — "
                        + format_prereq_failure(pr_res),
                        "mur_lc_prereq_failed": True,
                        "prereq": pr_res.as_dict(),
                    }
                ),
                400,
            )
    clr_raw = data.get("clear_thermo_restart")
    clear_tr = True if clr_raw is None else bool(clr_raw)
    qw = what_val or "mur_lc_t"
    conflict = _active_thermo_pw_job_for_dir(work_dir)
    if conflict is not None:
        oc_id, oc_st = conflict
        return (
            jsonify(
                {
                    "error": (
                        "Un calcul thermo_pw.x est déjà actif sur ce dossier (job "
                        + repr(oc_id)
                        + ", état "
                        + repr(oc_st)
                        + "). Attendre la fin ou éviter de lancer deux « what » "
                        "différents en parallèle sur le même répertoire — même préfixe / restart / journal, risque "
                        "de fichiers corrompus ou temps CPU doublé sans convergence utile."
                    ),
                    "conflicting_job_id": oc_id,
                    "conflicting_status": oc_st,
                }
            ),
            409,
        )
    q_msg = (
        f"File d'attente thermo_pw.x — what={qw!r} — np={nproc} — entrée {pw_in!r}"
    )
    cancel_ev = threading.Event()
    with _jobs_lock:
        _jobs[job_id] = {
            "status": "queued",
            "message": q_msg,
            "work_dir": str(work_dir.resolve()),
            "kind": "run_thermo_pw",
            "thermo_what": what_val,
            "nproc": nproc,
            "pw_in": pw_in,
            "cancel_event": cancel_ev,
        }
    _persist_job_disk(job_id)
    threading.Thread(
        target=_run_thermo_pw_job,
        kwargs={
            "job_id": job_id,
            "work_dir": work_dir,
            "nproc": nproc,
            "pw_in_basename": pw_in,
            "thermo_opts": thermo_opts or None,
            "clear_thermo_restart": clear_tr,
        },
        daemon=True,
    ).start()
    return jsonify(
        {
            "job_id": job_id,
            "status": "queued",
            "kind": "run_thermo_pw",
            "thermo_what": what_val,
            "nproc": nproc,
            "pw_in": pw_in,
            "work_dir": str(work_dir.resolve()),
        }
    ), 202


@app.route("/api/workflow1/eos/clear_thermo_pw_scratch", methods=list(EOS_JSON_POST_METHODS), strict_slashes=False)
def post_clear_thermo_pw_scratch():
    """Supprime ``restart/`` et ``_temporary*`` (ex. forrtl 24 EOF sur e_work_part*)."""
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    try:
        out = purge_thermo_pw_scratch_dirs(work_dir)
    except OSError as ex:
        return jsonify({"error": str(ex)}), 500
    return jsonify(out), 200


def _optics_exe_path(exe_key: str) -> Optional[Path]:
    key = (exe_key or "").strip().lower().replace("-", "_")
    mapping = {
        "pw": cfg.pw_path,
        "turbo_lanczos": cfg.turbo_lanczos_path,
        "turbo_davidson": cfg.turbo_davidson_path,
        "epsilon": cfg.epsilon_path,
    }
    fn = mapping.get(key)
    return fn() if fn else None


def _list_in_basenames(work_dir: Path, limit: int = 40) -> list[str]:
    try:
        names = sorted(
            p.name
            for p in work_dir.iterdir()
            if p.is_file() and p.suffix.lower() == ".in"
        )
    except OSError:
        return []
    return names[:limit]


def _safe_optics_input_basename(basename: str) -> Optional[str]:
    """Nom de fichier seul (sans répertoire ni « .. »), pour entrées MPI / copie depuis inputs/."""
    raw = (basename or "").strip()
    if not raw:
        return None
    p = Path(raw.replace("\\", "/"))
    if p.is_absolute():
        return None
    parts = tuple(x for x in p.parts if x != ".")
    if len(parts) != 1:
        return None
    name = parts[0]
    if name in ("..", "") or "/" in name or "\\" in name:
        return None
    return name


def _inputs_material_dir_for_slug(slug: str) -> Optional[Path]:
    """Répertoire ``inputs/<matériau>/`` ; tolère une casse différente du dossier sous Linux."""
    if not slug or slug in (".", ".."):
        return None
    root = cfg.INPUTS_DIR.resolve()
    direct = (root / slug).resolve()
    try:
        direct.relative_to(root)
    except ValueError:
        return None
    if direct.is_dir():
        return direct
    low = slug.lower()
    try:
        for child in root.iterdir():
            if not child.is_dir() or child.name.lower() != low:
                continue
            cr = child.resolve()
            try:
                cr.relative_to(root)
            except ValueError:
                continue
            return cr
    except OSError:
        pass
    return None


def _eos_work_material_slug(work_dir: Path) -> Optional[str]:
    """
    Pour .../work/<M>/... retourne M (premier segment sous WORK_ROOT).

    Fallback : tout chemin contenant ``.../work/<M>/...`` dont ``inputs/<M>/`` existe —
    évite les échecs si THERMO_WORK_ROOT ne correspond pas au ``work_dir`` réel du run.
    """
    wd = work_dir.resolve()
    try:
        rel = wd.relative_to(cfg.WORK_ROOT.resolve())
    except ValueError:
        rel = None
    if rel is not None and rel.parts:
        slug = rel.parts[0]
        if (
            slug
            and slug not in (".", "..")
            and slug == Path(slug).name
            and "/" not in slug
            and "\\" not in slug
        ):
            mat = _inputs_material_dir_for_slug(slug)
            return mat.name if mat is not None else slug
    # Dernier segment « …/work/<M>/… » vérifiable sous inputs/
    parts = wd.parts
    found: Optional[str] = None
    for i in range(len(parts) - 1):
        if parts[i].lower() != "work":
            continue
        cand = parts[i + 1]
        if not cand or cand in (".", "..") or cand != Path(cand).name:
            continue
        mat_d = _inputs_material_dir_for_slug(cand)
        if mat_d is not None:
            found = mat_d.name
    return found


def _find_under_material_inputs(mat: Path, basename: str) -> Optional[Path]:
    """Fichier sous mat/ : correspondance exacte puis insensible à la casse (Linux)."""
    direct = mat / basename
    if direct.is_file():
        return direct
    want = basename.lower()
    try:
        for p in mat.iterdir():
            if (
                p.is_file()
                and p.suffix.lower() == ".in"
                and p.name.lower() == want
            ):
                return p
    except OSError:
        pass
    return None


def _try_copy_exact_inputs_to_work(work_dir: Path, basename: str) -> Optional[str]:
    """Si absent du run, copie inputs/<slug>/<basename> → work_dir (nom du fichier demandé)."""
    safe_name = _safe_optics_input_basename(basename)
    if not safe_name:
        return None
    wd_r = Path(work_dir).resolve()
    dst_plain = wd_r / safe_name
    if dst_plain.is_file():
        return None
    slug = _eos_work_material_slug(wd_r)

    mats_ordered: list[tuple[Path, str]] = []
    if slug:
        mat0 = _inputs_material_dir_for_slug(slug)
        if mat0 is not None and mat0.is_dir():
            mats_ordered.append((mat0, mat0.name))
    root_in = cfg.INPUTS_DIR.resolve()
    try:
        for child in sorted(root_in.iterdir(), key=lambda p: p.name.lower()):
            if not child.is_dir():
                continue
            cr = child.resolve()
            if mats_ordered and cr == mats_ordered[0][0].resolve():
                continue
            try:
                cr.relative_to(root_in)
            except ValueError:
                continue
            mats_ordered.append((cr, child.name))
    except OSError:
        pass

    src: Optional[Path] = None
    used_mat_name = ""
    for mat, mat_name in mats_ordered:
        cand = _find_under_material_inputs(mat, safe_name)
        if cand is not None and cand.is_file():
            src = cand
            used_mat_name = mat_name
            break
    if src is None:
        return None

    dst = (wd_r / safe_name).resolve()
    try:
        dst.relative_to(wd_r)
    except ValueError:
        return None
    try:
        shutil.copy2(src, dst)
    except OSError:
        return None
    if src.name != safe_name:
        return (
            f"copié depuis inputs/{used_mat_name}/{src.name} sous le nom « {safe_name} » dans le run"
        )
    return f"copié depuis inputs/{used_mat_name}/{safe_name}"


def _pick_pw_scf_like_from_material_inputs(mat_inputs: Path) -> Optional[Path]:
    """Fichier type SCF (ex. si_scf.in), exclut NSCF et vc-relax."""
    paths = sorted(
        [p for p in mat_inputs.glob("*.in") if p.is_file()],
        key=lambda p: (len(p.stem), p.name.lower()),
    )
    picked: list[Path] = []
    for p in paths:
        n = p.stem.lower().replace("-", "").replace("_", "")
        if "nscf" in n:
            continue
        if "vcrelax" in n or (n.startswith("vc") and "relax" in p.stem.lower()):
            continue
        if "scf" in n:
            picked.append(p)
    return picked[0] if picked else None


def _resolve_optics_input_basename(
    work_dir: Path,
    exe_key: str,
    requested_raw: Optional[str],
    defaults: dict[str, str],
) -> tuple[str, Optional[str]]:
    """
    Choisit le fichier d'entrée pour /api/workflow/optics/run.

    Pour ``pw`` : si ``pw.in`` (défaut ou demandé explicitement) est absent,
    essaie les noms typiques d'un run EOS (V0 phonon, équilibre, maille du milieu de la grille),
    puis un fichier type SCF dans ``inputs/<matériau>/`` (copie en ``pw.in`` dans le run).

    Returns:
        (basename, hint) où hint est un court message si auto-sélection.

    Raises:
        ValueError: aucun fichier utilisable ; message liste les .in présents.
    """
    k = (exe_key or "").strip().lower().replace("-", "_")
    default_bn = defaults.get(k, "pw.in")
    req = (requested_raw or "").strip()
    raw_requested = req or default_bn
    requested = _safe_optics_input_basename(raw_requested)
    if not requested:
        raise ValueError(
            f"Nom de fichier d'entrée invalide : {raw_requested!r}. "
            "Utilisez uniquement le nom du fichier (ex. pw.in, Si_nscf.in), sans chemin."
        )

    wd_res = Path(work_dir).resolve()
    inp_hint = _try_copy_exact_inputs_to_work(wd_res, requested)
    if (wd_res / requested).is_file():
        return requested, inp_hint

    use_pw_fallback = k == "pw" and (not req or requested == default_bn)
    if use_pw_fallback:
        candidates = [
            "pw_scf_V0_for_phonon.in",
            "scf_eq.in",
            "pw_scf_eq.in",
        ]
        for c in candidates:
            if (wd_res / c).is_file():
                return c, f"auto : {default_bn} absent → {c}"
        vol_files = sorted(wd_res.glob("pw_scf_vol_*.in"))
        if vol_files:

            def _vol_key(p: Path) -> tuple[int, str]:
                m = re.search(r"pw_scf_vol_(\d+)", p.name, re.I)
                return (int(m.group(1)), p.name) if m else (10**9, p.name)

            vol_sorted = sorted(vol_files, key=_vol_key)
            pick = vol_sorted[len(vol_sorted) // 2]
            return pick.name, f"auto : {default_bn} absent → {pick.name} (grille EOS)"
        slug = _eos_work_material_slug(wd_res)
        if slug:
            mat = _inputs_material_dir_for_slug(slug)
            if mat is not None and mat.is_dir():
                cand = _pick_pw_scf_like_from_material_inputs(mat)
                if cand is not None and cand.is_file():
                    dst_pw = wd_res / "pw.in"
                    shutil.copy2(cand, dst_pw)
                    return (
                        "pw.in",
                        (inp_hint + " · " if inp_hint else "")
                        + f"auto : {default_bn} absent → {cand.name} "
                        f"depuis inputs/{slug}/ copié en pw.in dans le run",
                    )

    present = _list_in_basenames(wd_res)
    extra = (
        " Fichiers .in dans le dossier : " + ", ".join(present) + "."
        if present
        else " Aucun fichier .in dans ce dossier."
    )
    in_slug = _eos_work_material_slug(wd_res)
    mat_list = _inputs_material_dir_for_slug(in_slug) if in_slug else None
    if mat_list is not None and mat_list.is_dir():
        ins = sorted(p.name for p in mat_list.glob("*.in") if p.is_file())
        if ins:
            extra += (
                f" Gabarits inputs/{mat_list.name}/ : " + ", ".join(ins[:20])
                + ("…" if len(ins) > 20 else "")
                + "."
            )
    raise ValueError(
        f"Entrée introuvable : {requested}.{extra} "
        "Indiquez le nom exact dans l'interface (WF4), enregistrez sous inputs/<matériau>/, "
        "ou copiez un .in adapté dans le dossier du run."
    )


def _run_optics_mpi_job(
    job_id: str,
    work_dir: Path,
    nproc: int,
    inp_basename: str,
    exe_key: str,
) -> None:
    try:
        exe = _optics_exe_path(exe_key)
        if not exe or not exe.is_file():
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = (
                    f"Binaire introuvable pour {exe_key!r} : {exe}"
                )
            return
        work_dir_r = Path(work_dir).resolve()
        safe_in = _safe_optics_input_basename(inp_basename)
        if not safe_in:
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = (
                    f"Nom d'entrée invalide : {inp_basename!r} "
                    "(indiquez uniquement le fichier .in, ex. Si_nscf.in)."
                )
            return
        inp = work_dir_r / safe_in
        if not inp.is_file():
            _try_copy_exact_inputs_to_work(work_dir_r, safe_in)
        if not inp.is_file():
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = (
                    f"Fichier introuvable : {safe_in}. "
                    "Vérifiez inputs/<matériau>/ dans le dépôt ou copiez le .in dans le dossier du run."
                )
            return
        with _jobs_lock:
            _jobs[job_id]["status"] = "running"
            _jobs[job_id]["message"] = f"{exe.name} -in {safe_in}…"
        _persist_job_disk(job_id)
        try:
            out = run_mpi_exe_in(work_dir_r, exe, safe_in, nproc)
            with _jobs_lock:
                _jobs[job_id]["status"] = "done"
                _jobs[job_id]["message"] = f"Terminé ({exe.name})"
                _jobs[job_id]["log_file"] = str(out.resolve())
                _jobs[job_id]["kind"] = f"optics_{exe_key}"
        except Exception as ex:  # noqa: BLE001
            with _jobs_lock:
                _jobs[job_id]["status"] = "error"
                _jobs[job_id]["message"] = str(ex)
    finally:
        _persist_job_disk(job_id)


@app.route("/api/workflow/optics/run", methods=list(EOS_JSON_POST_METHODS), strict_slashes=False)
def post_optics_run():
    """
    Lance MPI : pw.x, turbo_lanczos.x, turbo_davidson.x ou epsilon.x dans un dossier sous work/.
    Corps JSON : work_dir, executable (pw|turbo_lanczos|turbo_davidson|epsilon),
    input_basename (optionnel ; défaut pw.in …), nproc (optionnel).

    Si ``executable=pw`` et ``pw.in`` est absent alors que vous n’avez pas imposé
    un autre nom, choix automatique parmi les entrées typiques d’un run EOS
    (``pw_scf_V0_for_phonon.in``, ``scf_eq.in``, fichier du milieu ``pw_scf_vol_*.in``),
    puis copie depuis ``inputs/<M>/`` (ex. ``si_scf.in`` dans le dossier du matériau
    lorsque ``work_dir`` est ``.../work/<M>/...``) sous le nom ``pw.in`` dans le run.
    """
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    exe_key = (data.get("executable") or "").strip()
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    exe = _optics_exe_path(exe_key)
    if exe is None:
        return (
            jsonify(
                {
                    "error": "executable invalide — utiliser : "
                    "pw, turbo_lanczos, turbo_davidson, epsilon"
                }
            ),
            400,
        )
    if not exe.is_file():
        return (
            jsonify(
                {
                    "error": f"Binaire introuvable : {exe} "
                    "(THERMO_QE_BIN / THERMO_TURBO_* / THERMO_EPSILON)",
                }
            ),
            400,
        )
    defaults = {
        "pw": "pw.in",
        "turbo_lanczos": "turbo_lanczos.in",
        "turbo_davidson": "turbo_davidson.in",
        "epsilon": "epsilon.in",
    }
    k = exe_key.strip().lower().replace("-", "_")
    requested_inp = (data.get("input_basename") or "").strip() or None
    try:
        inp, inp_hint = _resolve_optics_input_basename(
            work_dir, k, requested_inp, defaults
        )
    except ValueError as ex:
        return jsonify({"error": str(ex)}), 400
    nproc = int(data.get("nproc", cfg.MPI_NPROC))
    if nproc < 1:
        return jsonify({"error": "nproc invalide"}), 400
    job_id = uuid.uuid4().hex[:12]
    msg = f"File ({exe_key})"
    if inp_hint:
        msg = f"{msg} — {inp_hint}"
    with _jobs_lock:
        _jobs[job_id] = {
            "status": "queued",
            "message": msg,
            "work_dir": str(work_dir.resolve()),
            "kind": f"optics_{exe_key}",
            "nproc": nproc,
            "pw_in": inp,
        }
    _persist_job_disk(job_id)
    threading.Thread(
        target=_run_optics_mpi_job,
        kwargs={
            "job_id": job_id,
            "work_dir": work_dir,
            "nproc": nproc,
            "inp_basename": inp,
            "exe_key": k,
        },
        daemon=True,
    ).start()
    payload: dict[str, Any] = {
        "job_id": job_id,
        "status": "queued",
        "kind": f"optics_{exe_key}",
        "work_dir": str(work_dir.resolve()),
        "input_basename": inp,
        "nproc": nproc,
    }
    if inp_hint:
        payload["input_resolution"] = inp_hint
    return jsonify(payload), 202


@app.route("/api/workflow1/eos/gnuplot_eos", methods=list(EOS_JSON_POST_METHODS), strict_slashes=False)
def post_gnuplot_eos():
    """E(V) : écrit .dat, lance gnuplot, produit 1_eos_volumes/eos_ev.png"""
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    try:
        res = run_gnuplot_eos(work_dir)
    except (OSError, ValueError, RuntimeError, FileNotFoundError) as ex:
        return jsonify({"error": str(ex)}), 500
    rel = res["relpath"]
    return jsonify(
        {
            "ok": True,
            "relpath": rel,
            "png_path": res["png_path"],
            "gnuplot_script": res.get("gnuplot_script"),
            "renderer": res.get("renderer"),
        }
    )


@app.route("/api/workflow1/eos/gnuplot_phonon_bands", methods=list(EOS_JSON_POST_METHODS_PLUS_GET), strict_slashes=False)
def post_gnuplot_phonon_bands():
    """phonon.freq → PNG bandes (gnuplot)."""
    if request.method == "OPTIONS":
        return "", 204
    if request.method in ("GET", "HEAD"):
        return _eos_api_browser_get_help({"flfrq": "phonon.freq"})
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    flfrq_raw = (data.get("flfrq_file") or data.get("flfrq") or "phonon.freq").strip() or "phonon.freq"
    fb = Path(str(flfrq_raw).replace("\\", "/").strip()).name
    flfrq = fb if fb and fb not in (".", "..") else "phonon.freq"
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    try:
        res = run_gnuplot_phonon_bands(work_dir, flfrq=flfrq)
    except (OSError, ValueError, RuntimeError, FileNotFoundError) as ex:
        return jsonify({"error": str(ex)}), 500
    rel = res["relpath"]
    return jsonify(
        {
            "ok": True,
            "relpath": rel,
            "png_path": res["png_path"],
            "gnuplot_script": res.get("gnuplot_script"),
            "renderer": res.get("renderer"),
            "nmodes": res.get("nmodes"),
            "bands_source": res.get("bands_source"),
        }
    )


@app.route("/api/workflow1/eos/gnuplot_phonon_dos", methods=list(EOS_JSON_POST_METHODS_PLUS_GET), strict_slashes=False)
def post_gnuplot_phonon_dos():
    """phonon.dos → PNG DOS (gnuplot)."""
    if request.method == "OPTIONS":
        return "", 204
    if request.method in ("GET", "HEAD"):
        return _eos_api_browser_get_help({"fldos": "phonon.dos"})
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    fldos = (data.get("fldos_file") or data.get("fldos") or "phonon.dos").strip() or "phonon.dos"
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    try:
        res = run_gnuplot_phonon_dos(work_dir, fldos=fldos)
    except (OSError, ValueError, RuntimeError, FileNotFoundError) as ex:
        return jsonify({"error": str(ex)}), 500
    rel = res["relpath"]
    return jsonify(
        {
            "ok": True,
            "relpath": rel,
            "png_path": res["png_path"],
            "gnuplot_script": res.get("gnuplot_script"),
            "renderer": res.get("renderer"),
        }
    )


@app.route("/api/workflow1/eos/thermo_output_parse", methods=["GET", "OPTIONS"])
def get_thermo_output_parse():
    """Lit thermo_pw_run.out dans work_dir et extrait repères (C_ij, modules, T_D, …)."""
    if request.method == "OPTIONS":
        return "", 204
    raw_wd = (request.args.get("work_dir") or "").strip()
    if not raw_wd:
        return jsonify({"error": "work_dir requis (query)."}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    log_rel = (request.args.get("log_relpath") or "").strip().replace("\\", "/")
    res = parse_work_dir_thermo_log(work_dir, primary_log_relpath=log_rel or None)
    if isinstance(res, dict):
        res.setdefault("parse_revision", THERMO_PW_OUT_PARSE_REVISION)
    return jsonify(res), 200


@app.route("/api/workflow1/eos/elastic_t_series", methods=["GET", "OPTIONS"])
def get_elastic_t_series():
    """Tableau colonnes depuis un .dat (élasticités / modules vs première colonne, souvent T)."""
    if request.method == "OPTIONS":
        return "", 204
    raw_wd = (request.args.get("work_dir") or "").strip()
    rel_hint = (request.args.get("relpath") or "").strip().replace("\\", "/")
    if not raw_wd:
        return jsonify({"error": "work_dir requis (query)."}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    dat_path: Optional[Path] = None
    if rel_hint:
        p = _safe_work_artifact_path(raw_wd, rel_hint)
        if not p:
            return jsonify({"error": "relpath invalide ou hors du dossier run."}), 400
        if not path_allowed_for_elastic_t_series_request(p):
            return jsonify(
                {
                    "error": (
                        "Indiquez un fichier tableau : .dat ou sortie thermo_pw sous anhar_files/ "
                        "(ex. *.el_cons_qha, *.el_comp_qha ; pas une courbe pression *.el_cons_p)."
                    ),
                }
            ), 400
        dat_path = p
    else:
        dat_path = find_elastic_t_dat(work_dir)
        if dat_path is None:
            return (
                jsonify(
                    {
                        "error": (
                            "Aucun fichier tableau « élasticités / modules vs première colonne (souvent T) » "
                            "trouvé automatiquement (.dat ou anhar_files/*.el_cons_* / *.el_comp_*)."
                        ),
                        "searched_in": str(work_dir.resolve()),
                        "filename_hints": list(SERIES_HINT_NAMES),
                        "dat_files_sample": list_dat_relpaths(work_dir, limit=64),
                        "dat_elastic_candidates": list_elastic_like_dat_candidates(work_dir, limit=80),
                        "diagnosis_hint": (
                            "Ce dossier ne contient pas encore de tableau colonnes du type élasticités/modules vs "
                            "température (§1.21). Thermo_pw écrit souvent des colonnes sous "
                            "<code>anhar_files/&lt;préfixe&gt;.el_cons_qha</code> ou "
                            "<code>.el_cons_qsa</code> (sans extension .dat). Les .dat listés peuvent être EOS ou phonons ; "
                            "ils ne servent pas à C_ij(T). Vérifier que thermo_pw a bien terminé (journal thermo_pw_run.out) "
                            "après what=elastic_constants_geo (ou alias mur_lc_t_elastic_constants → geo)."
                        ),
                        "note": (
                            "energy_files/output_ev.dat et variantes : courbes EOS E(V), pas C_ij(T). "
                            "Après §1.21 (guide thermo_pw), un fichier colonnes est attendu si le calcul va au bout "
                            "(souvent elastic_vs_T.dat ou anhar_files/*.el_cons_qha sans extension .dat). "
                            "Sinon indiquez relpath dans le champ ou l’API. "
                            "Vérifier la fin de thermo_pw_run.out (convergence, erreurs MPI)."
                        ),
                    }
                ),
                404,
            )
    try:
        max_rows_q = (request.args.get("max_rows") or "").strip()
        mr = int(max_rows_q) if max_rows_q else 2500
    except ValueError:
        mr = 2500
    tbl = parse_numeric_series_dat(dat_path, max_rows=max(50, min(50_000, mr)))
    err = tbl.get("error") if isinstance(tbl, dict) else None
    if isinstance(err, str):
        return jsonify(tbl), 500
    try:
        rel_actual = Path(tbl["path"]).resolve().relative_to(work_dir.resolve()).as_posix()
    except ValueError:
        rel_actual = dat_path.name
    tbl["dat_relpath"] = rel_actual
    tbl["work_dir"] = str(work_dir.resolve())
    tbl["dat_semantic_hint"] = dat_semantic_hint_for_filename(dat_path.name)
    tbl["offline_plot"] = {
        "gnuplot_script_relpath": GP_ELASTIC,
        "png_relpath_after_gnuplot": PNG_ELASTIC,
        "note": "Après POST …/gnuplot_elastic_vs_t, le script et le PNG sont dans work_dir ; rejouer : cd work_dir && gnuplot " + GP_ELASTIC,
    }
    return jsonify(tbl), 200


@app.route("/api/workflow1/eos/elastic_t_dat_candidates", methods=["GET", "OPTIONS"])
def get_elastic_t_dat_candidates():
    """Liste les .dat / anhar_files exploitables pour §1.21 sans charger tout le tableau (sélection UI)."""
    if request.method == "OPTIONS":
        return "", 204
    raw_wd = (request.args.get("work_dir") or "").strip()
    if not raw_wd:
        return jsonify({"error": "work_dir requis (query)."}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    auto_rel: Optional[str] = None
    auto_path = find_elastic_t_dat(work_dir)
    if auto_path is not None:
        try:
            auto_rel = auto_path.resolve().relative_to(work_dir.resolve()).as_posix()
        except ValueError:
            auto_rel = auto_path.name
    return jsonify(
        {
            "work_dir": str(work_dir.resolve()),
            "dat_elastic_candidates": list_elastic_like_dat_candidates(work_dir, limit=80),
            "dat_files_sample": list_dat_relpaths(work_dir, limit=64),
            "auto_relpath": auto_rel,
            "note": (
                "dat_elastic_candidates — noms orientés C_ij(T) / modules vs T. "
                "dat_files_sample — autres .dat (dont energy_files/output_ev* = courbes EOS E(V), pas §1.21)."
            ),
        }
    ), 200


@app.route("/api/workflow1/eos/gnuplot_elastic_vs_t", methods=list(EOS_JSON_POST_METHODS), strict_slashes=False)
def post_gnuplot_elastic_vs_t():
    """gnuplot PNG : colonnes 2… vs col 1 d’un fichier .dat (thermo élasticités vs T, §1.21)."""
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    raw_wd = (data.get("work_dir") or "").strip()
    rel_hint = (data.get("relpath") or "").strip().replace("\\", "/")
    if not raw_wd:
        return jsonify({"error": "work_dir requis"}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )
    dat_path: Optional[Path] = None
    if rel_hint:
        p = _safe_work_artifact_path(raw_wd, rel_hint)
        if not p or not path_allowed_for_elastic_t_series_request(p):
            return jsonify(
                {
                    "error": (
                        "relpath doit pointer vers un fichier tableau dans work_dir (.dat ou "
                        "anhar_files/*.el_cons_* / *.el_comp_*)."
                    ),
                }
            ), 400
        dat_path = p
    else:
        dat_path = find_elastic_t_dat(work_dir)
    if dat_path is None:
        return (
            jsonify(
                {"error": "Aucun fichier tableau exploitable — passez relpath=… (ex. elastic_vs_T.dat ou anhar_files/*.el_cons_qha)."}
            ),
            404,
        )
    tbl = parse_numeric_series_dat(dat_path)
    if tbl.get("error"):
        return jsonify({"error": str(tbl["error"])}), 500
    ncol = int(tbl.get("ncol") or 0)
    cols = list(tbl.get("columns") or [])
    raw_tt = data.get("title")
    if isinstance(raw_tt, str) and raw_tt.strip():
        title = raw_tt.strip()
    else:
        title = "Élasticités / modules (.dat) vs première colonne"
    if ncol < 2:
        return jsonify({"error": "Le fichier doit avoir au moins 2 colonnes numériques."}), 400
    try:
        rel_actual = dat_path.resolve().relative_to(work_dir.resolve()).as_posix()
        res_plot = run_gnuplot_elastic_temperature_dat(
            work_dir,
            dat_relpath=rel_actual,
            ncol=ncol,
            column_labels=cols if cols else [f"y{i}" for i in range(ncol)],
            title=title,
        )
    except (OSError, ValueError, RuntimeError, FileNotFoundError) as ex:
        return jsonify({"error": str(ex)}), 500
    return jsonify({"ok": True, "png_relpath": res_plot["png_relpath"], "png_path": res_plot["png_path"]}), 200


def _normalize_request_path_for_api_dispatch(path: str) -> str:
    """Normalise PATH_INFO pour le secours routage : casse, slashes, /api/api/, préfixe type reverse-proxy."""
    p = (path or "").split("?", 1)[0].strip().replace("\\", "/")
    p = re.sub(r"/+", "/", p).lower()
    while "/api/api/" in p:
        p = p.replace("/api/api/", "/api/", 1)
    idx = p.find("/api/")
    if idx > 0:
        p = p[idx:]
        while "/api/api/" in p:
            p = p.replace("/api/api/", "/api/", 1)
    if len(p) > 1:
        p = p.rstrip("/")
    return p if p.startswith("/") else "/" + p


def _normalize_api_path_casefold(path: str) -> str:
    """Alias : même logique que _normalize_request_path_for_api_dispatch (pseudos + secours)."""
    return _normalize_request_path_for_api_dispatch(path)


# Même contrat que pseudos_generation_routes ; exécuté en before_request avant le dispatch Flask
# (certaines piles matchent `/<path:relpath>` avant /api/pseudos/… → JSON générique « not found »).
_API_PSEUDOS_CATCH_DISPATCH: tuple[tuple[frozenset[str], frozenset[str], str], ...] = (
    (frozenset({"/api/pseudos/generator_paths"}), frozenset({"GET", "HEAD"}), "tpw_pseudos_generator_paths"),
    (frozenset({"/api/pseudos/ape_status"}), frozenset({"GET", "HEAD"}), "tpw_pseudos_ape_status"),
    (frozenset({"/api/pseudos/atompaw_status"}), frozenset({"GET", "HEAD"}), "tpw_pseudos_atompaw_status"),
    (frozenset({"/api/pseudos/auto_inputs"}), frozenset({"GET", "POST", "OPTIONS"}), "tpw_pseudos_auto_inputs"),
    (frozenset({"/api/pseudos/element_info"}), frozenset({"GET", "HEAD"}), "tpw_pseudos_element_info"),
    (frozenset({"/api/pseudos/ape_input_template"}), frozenset({"GET", "HEAD"}), "tpw_pseudos_ape_input_template"),
    (frozenset({"/api/pseudos/atompaw_input_template"}), frozenset({"GET", "HEAD"}), "tpw_pseudos_atompaw_input_template"),
    (frozenset({"/api/pseudos/run_ape"}), frozenset({"POST", "OPTIONS"}), "tpw_pseudos_run_ape"),
    (frozenset({"/api/pseudos/run_atompaw"}), frozenset({"POST", "OPTIONS"}), "tpw_pseudos_run_atompaw"),
    (frozenset({"/api/pseudos/save_local_input"}), frozenset({"POST", "OPTIONS"}), "tpw_pseudos_save_local_input"),
)


@app.before_request
def _dispatch_api_pseudos_before_catch_all() -> Any:
    norm = _normalize_api_path_casefold(request.path)
    if not norm.startswith("/api/pseudos"):
        return None
    method = request.method
    for paths, methods, endpoint in _API_PSEUDOS_CATCH_DISPATCH:
        if norm not in paths:
            continue
        if method not in methods:
            return None
        vfn = current_app.view_functions.get(endpoint)
        if vfn is None:
            return None
        return vfn()
    return None


@app.before_request
def _dispatch_api_inputs_save_pseudo_before_catch_all() -> Any:
    """POST …/api/inputs/save_pseudo_generator même avec préfixe / montage (sinon 405 / catch‑all)."""
    norm = _normalize_request_path_for_api_dispatch(request.path).rstrip("/")
    if norm != "/api/inputs/save_pseudo_generator":
        return None
    if request.method not in EOS_JSON_POST_METHODS:
        return None
    vfn = current_app.view_functions.get("post_inputs_save_pseudo_generator")
    if vfn is None:
        return None
    return vfn()


@app.before_request
def _route_thermo_parse_before_catch_all():
    """Certaines piles résolvent `/<path:relpath>` avant la route dédiée → JSON « not found ».
    Intercepte explicitement ces URLs avant tout dispatch."""
    path = (request.path or "").rstrip("/").lower()
    if path == "/api/workflow/optics/inputs_check":
        if request.method not in ("GET", "OPTIONS"):
            return None
        return get_optics_inputs_check()
    if path == "/api/workflow/optics/templates":
        if request.method not in ("GET", "OPTIONS"):
            return None
        return list_optics_templates()
    if path not in (
        "/api/workflow1/eos/thermo_output_parse",
        "/api/parse_thermo_pw_out",
    ):
        return None
    if request.method not in ("GET", "OPTIONS"):
        return None
    return get_thermo_output_parse()


@app.route("/api/parse_thermo_pw_out", methods=["GET", "OPTIONS"])
def get_thermo_output_parse_short_alias():
    """Alias court — même comportement que …/thermo_output_parse (évite conflits de routage)."""
    return get_thermo_output_parse()


@app.route("/api/workflow1/eos/run_log_tail", methods=["GET", "OPTIONS"])
def get_run_log_tail():
    """Fin d'un journal .out dans work_dir (SCF V₀, etc.) pour aperçu navigateur."""
    if request.method == "OPTIONS":
        return "", 204
    raw_wd = (request.args.get("work_dir") or "").strip()
    rel_arg = (request.args.get("relpath") or "").strip()
    try:
        max_lines = int(request.args.get("max_lines", "120"))
    except ValueError:
        max_lines = 120
    max_lines = min(500, max(1, max_lines))
    if not raw_wd:
        return jsonify({"error": "work_dir requis (query)."}), 400
    work_dir = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not work_dir.is_dir() or not _is_allowed_eos_work_dir(work_dir):
        root_s = str(cfg.WORK_ROOT.resolve())
        return (
            jsonify(
                {
                    "error": (
                        "Dossier de travail interdit ou introuvable. Le serveur n’accepte que des chemins "
                        "existants sous son répertoire work : "
                        + root_s
                        + " (variable d’environnement THERMO_WORK_ROOT si vous l’avez changée). "
                        "Copiez votre run sous ce dossier ou indiquez un chemin absolu qui y descend."
                    ),
                    "work_root_api": root_s,
                }
            ),
            400,
        )

    candidates: list[str] = []
    if rel_arg:
        candidates.append(rel_arg.replace("\\", "/").lstrip("/"))
    else:
        candidates.extend(["pw_scf_V0_for_phonon.out", "pw_V0_for_phonon.out"])

    chosen: Optional[Path] = None
    chosen_rel: Optional[str] = None
    for r in candidates:
        p = _eos_run_child_path(raw_wd, r)
        if p is not None and p.is_file():
            chosen = p
            chosen_rel = r
            break

    if chosen is None or chosen_rel is None:
        tried = []
        for r in candidates:
            p = _eos_run_child_path(raw_wd, r)
            tried.append({"relpath": r, "exists": bool(p and p.is_file())})
        return jsonify(
            {
                "exists": False,
                "work_dir": str(work_dir.resolve()),
                "tried": tried,
                "tail": "",
                "message": "Aucun journal V₀ encore présent (essayé : "
                + ", ".join(candidates)
                + "). Lancez pw.x puis actualisez.",
            }
        )

    tail, sz, trunc = _tail_utf8_file(chosen, max_lines, 262_144)
    return jsonify(
        {
            "exists": True,
            "work_dir": str(work_dir.resolve()),
            "relpath": chosen_rel,
            "size_bytes": sz,
            "tail_truncated": trunc,
            "tail": tail,
        }
    )


@app.route("/api/workflow1/eos/run_postscript_list", methods=["GET", "HEAD", "OPTIONS"])
def get_run_postscript_list():
    """Liste les fichiers *.ps à la racine d’un run wf1 (sorties gnuplot natives thermo_pw)."""
    if request.method == "OPTIONS":
        return "", 204
    raw_wd = (request.args.get("work_dir") or "").strip()
    if not raw_wd:
        return jsonify({"error": "Paramètre work_dir requis."}), 400
    wd = wf1_eos_run_root(Path(raw_wd).expanduser().resolve())
    if not _is_allowed_eos_work_dir(wd) or not wd.is_dir():
        return jsonify({"error": "Dossier de run invalide ou introuvable."}), 400
    files = sorted(p.name for p in wd.glob("*.ps") if p.is_file())
    return jsonify({"work_dir": str(wd.resolve()), "files": files})


@app.route("/api/workflow1/eos/artifact", methods=["GET", "HEAD", "OPTIONS"])
def get_work_artifact():
    """Sert un fichier d’un run (ex. PNG gnuplot) — work_dir + relpath en query."""
    if request.method == "OPTIONS":
        return "", 204
    raw_wd = (request.args.get("work_dir") or "").strip()
    rel = (request.args.get("relpath") or request.args.get("path") or "").strip()
    p = _safe_work_artifact_path(raw_wd, rel)
    if p is None:
        return jsonify({"error": "Fichier introuvable ou chemin interdit."}), 404
    suf = p.suffix.lower()
    if suf == ".png":
        mimetype = "image/png"
    elif suf == ".ps":
        mimetype = "application/postscript"
    elif suf == ".dat":
        mimetype = "text/plain; charset=utf-8"
    else:
        mimetype = "text/plain; charset=utf-8"
    return send_file(
        p,
        mimetype=mimetype,
        as_attachment=False,
        max_age=0,
    )


def _safe_interface_path(relpath: str) -> Optional[Path]:
    if not relpath or ".." in relpath or relpath.startswith(("/", "\\")):
        return None
    p = (INTERFACE_DIR / relpath).resolve()
    try:
        p.relative_to(INTERFACE_DIR)
    except ValueError:
        return None
    if not p.is_file():
        return None
    return p


_THERMO_PW_PARSE_REL_KEYS = frozenset(
    {
        "api/workflow1/eos/thermo_output_parse",
        "api/parse_thermo_pw_out",
    }
)


def _normalize_path_segment_for_delegate(relpath: str) -> str:
    """Ce que Flask passe à /<path:relpath> (sans slash initial), normalisé pour comparaison."""
    s = (relpath or "").strip().replace("\\", "/").split("?", 1)[0].strip("/")
    s = re.sub(r"/+", "/", s).strip("/").lower()
    while "api/api/" in s:
        s = s.replace("api/api/", "api/", 1)
    for marker in ("api/pseudos/", "api/inputs/"):
        k = s.find(marker)
        if k != -1:
            s = s[k:]
            break
    return s


def _delegates_from_catch_all_to_thermo_parse(relpath: str) -> bool:
    return _normalize_path_segment_for_delegate(relpath) in _THERMO_PW_PARSE_REL_KEYS


# Enregistré en dernier : le routeur préfère les routes explicites /api/… à ce motif large.
@app.get("/index.html")
@app.get("/index.html/")
def serve_index_html_legacy() -> Any:
    """Compat : bookmarks / liens anciens pointaient sur /index.html (avant refactor 5 profils).
    Redirige de façon permanente vers la nouvelle page d’accueil."""
    return redirect("/index_v2.html", code=301)


@app.get("/")
def serve_index() -> Any:
    """Sert l’interface sur le même port que l’API (ouvrir un seul URL dans le navigateur)."""
    if not (INTERFACE_DIR / "index_v2.html").is_file():
        return jsonify({"error": f"index_v2.html introuvable : {INTERFACE_DIR}"}), 500
    return send_from_directory(str(INTERFACE_DIR), "index_v2.html", mimetype="text/html; charset=utf-8")


def _no_cache_html(resp: Any) -> Any:
    """Évite que le navigateur garde une vieille interface après git pull ou mise à jour du bundle."""
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    return resp


@app.get("/generation-inputs")
@app.get("/generation-inputs/")
def serve_generation_inputs() -> Any:
    """Redirige vers l’ancre CIF de l’interface principale (hash géré côté client)."""
    return redirect("/#generation_inputs", code=302)


@app.route("/<path:relpath>", methods=["GET", "HEAD", "POST", "OPTIONS"])
def serve_interface_static(relpath: str) -> Any:
    """Ressources de interface/ (*.js, etc.). Déporte aussi certains /api/* si le routeur tombe ici."""
    low = (relpath or "").lower()
    if low.startswith("api/") or low.startswith("api\\"):
        # Si le routeur tombe ici au lieu des routes dédiées (ordre Werkzeug / catch‑all premier).
        # Inclut les deux URLs parse + alias ; normalisation casse / slashes / doubles slash.
        seg = _normalize_path_segment_for_delegate(relpath)
        seg_trim = seg.rstrip("/")
        if seg_trim == "api/pseudos/save_local_input" and request.method in ("POST", "OPTIONS"):
            vfn = current_app.view_functions.get("tpw_pseudos_save_local_input")
            if vfn is not None:
                return vfn()
        if seg_trim == "api/inputs/save_pseudo_generator" and request.method in (
            "POST",
            "PUT",
            "PATCH",
            "OPTIONS",
        ):
            vfn = current_app.view_functions.get("post_inputs_save_pseudo_generator")
            if vfn is not None:
                return vfn()
        if seg == "api/workflow/optics/inputs_check":
            return get_optics_inputs_check()
        if seg == "api/workflow/optics/templates":
            return list_optics_templates()
        if _delegates_from_catch_all_to_thermo_parse(relpath):
            return get_thermo_output_parse()
        if seg_trim == "api/pseudos/atompaw_input_template":
            vfn = current_app.view_functions.get("tpw_pseudos_atompaw_input_template")
            if vfn is not None:
                return vfn()
        if seg_trim == "api/pseudos/ape_input_template":
            vfn = current_app.view_functions.get("tpw_pseudos_ape_input_template")
            if vfn is not None:
                return vfn()
        return jsonify({"error": "not found"}), 404
    p = _safe_interface_path(relpath)
    if p is None:
        abort(404)
    resp = send_from_directory(str(p.parent), p.name, max_age=0)
    if p.suffix.lower() == ".html":
        return _no_cache_html(resp)
    return resp


def _recover_stale_persisted_jobs_startup() -> None:
    try:
        n = api_job_persist.recover_stale_api_job_markers(cfg.WORK_ROOT)
    except Exception:  # noqa: BLE001
        return
    if n:
        print(
            f"THERMO_PW — reprise : {n} job(s) API marqué(s) « interrupted » "
            f"({api_job_persist.MARKER_NAME}, pid API absent).",
            file=sys.stderr,
        )


_recover_stale_persisted_jobs_startup()


def main() -> None:
    import os

    host = "127.0.0.1"
    try:
        p = int(os.environ.get("THERMO_API_PORT", "5010"))
    except ValueError:
        p = 5010
    print(
        f"THERMO_PW — http://{host}:{p}/  (interface + API sur le même port)\n"
        f"  générateur pseudos APE/ATOMPAW — racine THERMO_GENERATION_PSEUDOS_DIR : {cfg.GENERATION_PSEUDOS_DIR}\n"
        f"    sortie .UPF THERMO_PSEUDO_GEN_OUTPUT_DIR (déf. …/generated_upf) : {cfg.PSEUDO_GEN_OUTPUT_DIR}\n"
        f"    travail runs THERMO_PSEUDO_GEN_WORK_ROOT (déf. …/_work) : {cfg.PSEUDO_GEN_WORK_ROOT}\n"
        f"  biblio QE (pw.x) THERMO_PSEUDOS_DIR : {cfg.PSEUDOS_DIR}\n"
        f"  interface répertoire : {INTERFACE_DIR}\n"
        f"  index_v2.html présent : {(INTERFACE_DIR / 'index_v2.html').is_file()} "
        f"(interface V2 — 5 profils / workflow 4 étapes)\n"
        f"  parse thermo_pw_run.out — révision JSON : {THERMO_PW_OUT_PARSE_REVISION} (redémarrer l’API après git pull)\n"
        f"  POST /api/admin/restart  — redémarrage à distance si THERMO_API_RESTART_TOKEN est défini (interface affiche le panneau si parse obsolète).\n"
        f"  GET  /  index_v2.html  ·  /app_v2.{{js,css}}  ·  /api/health  …/api/inputs/thermo  …/api/inputs/preview?path=…\n"
        f"  POST /api/inputs/save  ·  POST /api/inputs/save_pseudo_generator (APE/ATOMPAW)  ·  /api/inputs/transform  ·  /api/inputs/cif_to_pw  ·  /api/outputs/clean  ·  /api/workflow1/eos  ·  /api/workflow1/eos_fit_only\n"
        f"       GET /api/workflow1/work/browse?path=…  ·  GET /api/workflow1/work/default_run_dir?material_id=…  ·  run_scf_v0 / run_ph / run_q2r / phonon_bands_from_dynamical_matrices / run_matdyn_* / run_dynmat / run_thermo_pw\n"
        f"       GET …/thermo_output_parse  gnuplot_eos gnuplot_phonon_* gnuplot_elastic_vs_t  GET elastic_t_dat_candidates elastic_t_series · write_ph_in · write_control_file · GET …/artifact GET …/run_postscript_list · GET …/run_log_tail?work_dir=… · GET …/qha_prereq?work_dir=…\n"
        f"       POST …/run_pp_charge ou …/pp_charge (densité Cube, pp.x) — 405 après POST : routes absentes ⇒ redémarrer l’API."
    )
    app.run(host=host, port=p, debug=False, threaded=True)


if __name__ == "__main__":
    main()

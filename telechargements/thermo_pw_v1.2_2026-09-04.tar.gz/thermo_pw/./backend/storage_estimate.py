"""Estimation de l'espace disque d'un calcul, par profil P1..P5.

Pourquoi ce module
------------------
Un P2 sur Si — 2 atomes, le plus petit cas réaliste — occupe **~10 Gio** une fois
terminé (9 géométries QHA × ~880 Mio de scratch ``_ph0`` chacune, plus EOS et la
première chaîne phonon). Rien dans l'interface ne le disait au lancement : le
modèle initial (~1,5 Gio) ne comptait que la **première** chaîne phonon, pas la
boucle thermo_pw QHA (P2–P4).

Ce que l'estimation distingue
-----------------------------
La mesure d'un run réel montre une répartition très déséquilibrée :

===========================  ===========  ==================================
composant                    taille       nature
===========================  ===========  ==================================
``out_scf_eq/_ph0/``         ~1,2 Gio     scratch DFPT (1ère chaîne phonon)
``out_scf_eq/g1..g9/``       ~8,0 Gio     scratch QHA (9 × ~880 Mio/géom.)
``1_eos_volumes/``           90 Mio       densités + fonctions d'onde
résultats (.dat .freq .dos)  ~80 Mio      livrables + tracés (pic conservé)
===========================  ===========  ==================================

Annoncer « 1,5 Gio » sans dire que 99,8 % est du scratch temporaire serait aussi
trompeur qu'annoncer « 2,5 Mio » en ignorant le pic. Les deux sont donc
rapportés séparément.

Base physique
-------------
Les tailles ne sont pas devinées : elles se calculent depuis la géométrie et les
cutoffs, puis se vérifient sur le run mesuré.

* ondes planes des fonctions d'onde : ``N_pw = V · ecutwfc^{3/2} / 6π²``
* vecteurs G de la densité : ``N_G = V · ecutrho^{3/2} / 6π²``
  — prédit 49 236 pour Si là où QE rapporte 49 229 (0,01 % d'écart)
* ``dvscf`` par point q = ``3·nat × N_FFT × 16`` octets
  — prédit 19,78 Mio, mesuré 19,8 Mio
* sortie pw.x = densité + fonctions d'onde collectées ≈ 12 Mio par volume
  — mesuré 12,9 Mio sur les 7 volumes de la grille EOS

Comme pour la durée, les comptes deviennent **exacts** dès que QE a écrit ses
sorties : le nombre de vecteurs G et les dimensions FFT y sont imprimés.
"""
from __future__ import annotations

import math
import re
import shutil
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional

from runtime_estimate import (
    MaterialDescriptors,
    estimate_irreducible_points,
    is_qha_profile,
    qha_n_geometries,
)

BOHR_PER_ANGSTROM = 1.8897261254535
# Un nombre complexe double précision, unité de stockage de QE.
BYTES_PER_COMPLEX = 16
MIB = 1024 * 1024
GIB = 1024 * MIB

# 6π², dénominateur du décompte d'ondes planes dans une sphère de rayon G_max.
_SIX_PI2 = 6.0 * math.pi ** 2

# Rapport points de grille FFT / vecteurs G de la densité. Mesuré sur Si
# (49 229 vecteurs G → FFT 60×60×60 = 216 000 points). Il varie un peu avec la
# forme de la maille et l'arrondi de QE vers des tailles FFT efficaces ; c'est
# la partie la moins solide du modèle, remplacée par la valeur exacte dès que
# la sortie pw.x est lisible.
_FFT_PER_G_VECTOR = 4.4

# Référence Si pour calibrer le scratch QHA (8 q, FFT 216³, grille k 12³).
_REF_N_Q = 8
_REF_N_MODES = 6
_REF_N_FFT = 216_000
_REF_WFC_FULL = 4 * 2176 * 16 * (12 * 12 * 12)

# out_scf_eq/_ph0 ≈ 1,2 Gio et chaque out_scf_eq/gK/_ph0 ≈ 880 Mio (Si, août 2026).
_PH0_PER_GEOMETRY_MIB = 880.0

# Coefficients du scratch ph.x (wfc1/wfc2/dwf…), ajustés sur le run P2/Si mesuré.
# Ils comptent des tableaux de type « fonction d'onde » que ph.x écrit en plusieurs copies
# (wfc1/wfc2 conservés par point q ; dwf/bar/mixd seulement pour le q courant).
_PH_WFC_PER_Q = 0.414   # wfc1 + wfc2, fraction de la grille k complète
_PH_PEAK_SCRATCH = 1.20  # dwf + bar + mixd du point q en cours

# Fichiers de résultats : une base quasi fixe (journaux, tracés, EOS) plus un
# terme qui suit le nombre de modes et de points q (matdyn.modes surtout).
_RESULTS_BASE_MIB = 1.8
_RESULTS_PER_MODE_Q_KIB = 1.3

# Part fixe d'un dossier ``prefix.save`` (XML, occupations, PAW/becsum).
_PW_FIXED_OVERHEAD_MIB = 2.0


@dataclass
class CellFacts:
    """Grandeurs de maille et d'électrons nécessaires au calcul des tailles."""

    volume_bohr3: float = 270.0
    nelec: float = 8.0
    nbnd: int = 4
    n_pw_wfc: int = 2176
    n_g_dense: int = 49236
    n_fft_dense: int = 216_000
    insulator: bool = True
    source: str = "estimé"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Géométrie : volume de la maille
# ---------------------------------------------------------------------------
def _celldm(text: str, i: int) -> Optional[float]:
    m = re.search(
        rf"(?im)^\s*celldm\(\s*{i}\s*\)\s*=\s*([+-]?[\d.]+(?:[dDeE][+-]?\d+)?)", text
    )
    if not m:
        return None
    try:
        return float(m.group(1).replace("d", "e").replace("D", "e"))
    except ValueError:
        return None


def _alat_bohr(text: str) -> Optional[float]:
    """Paramètre de maille en bohr, depuis ``celldm(1)`` ou ``A`` (en Å)."""
    a = _celldm(text, 1)
    if a and a > 0:
        return a
    m = re.search(r"(?im)^\s*A\s*=\s*([+-]?[\d.]+(?:[dDeE][+-]?\d+)?)", text)
    if m:
        try:
            ang = float(m.group(1).replace("d", "e").replace("D", "e"))
            if ang > 0:
                return ang * BOHR_PER_ANGSTROM
        except ValueError:
            pass
    return None


def _cell_parameters_volume(text: str, alat: Optional[float]) -> Optional[float]:
    """Volume par déterminant de la carte ``CELL_PARAMETERS`` (ibrav=0)."""
    m = re.search(r"(?im)^\s*CELL_PARAMETERS\s*\(?\s*(\w+)?", text)
    if not m:
        return None
    unit = (m.group(1) or "alat").lower()
    lines = text[m.end():].splitlines()
    vecs: list[list[float]] = []
    for ln in lines:
        nums = re.findall(r"[-+]?\d*\.?\d+(?:[dDeE][-+]?\d+)?", ln)
        if len(nums) >= 3:
            vecs.append([float(x.replace("d", "e").replace("D", "e")) for x in nums[:3]])
            if len(vecs) == 3:
                break
        elif vecs:
            break
    if len(vecs) != 3:
        return None
    (a1, a2, a3) = vecs
    det = (
        a1[0] * (a2[1] * a3[2] - a2[2] * a3[1])
        - a1[1] * (a2[0] * a3[2] - a2[2] * a3[0])
        + a1[2] * (a2[0] * a3[1] - a2[1] * a3[0])
    )
    vol = abs(det)
    if unit.startswith("alat"):
        if not alat:
            return None
        vol *= alat ** 3
    elif unit.startswith("angstrom"):
        vol *= BOHR_PER_ANGSTROM ** 3
    return vol if vol > 0 else None


def cell_volume_bohr3(text: str, ibrav: Optional[int]) -> Optional[float]:
    """Volume de la maille primitive, en bohr³, depuis un fichier pw.x.

    Les formules par ``ibrav`` suivent les conventions de INPUT_PW : le volume
    de la maille **primitive** vaut une fraction du cube pour les réseaux
    centrés (moitié pour un cubique I, quart pour un cubique F).
    """
    a = _alat_bohr(text)
    if ibrav == 0 or ibrav is None:
        return _cell_parameters_volume(text, a)
    if not a:
        return None
    b_over_a = _celldm(text, 2) or 1.0
    c_over_a = _celldm(text, 3) or 1.0
    cos_g = _celldm(text, 4) or 0.0

    ib = int(ibrav)
    a3 = a ** 3
    if ib == 1:
        return a3
    if ib in (2,):
        return a3 / 4.0
    if ib in (3, -3):
        return a3 / 2.0
    if ib == 4:
        return a3 * c_over_a * math.sqrt(3.0) / 2.0
    if ib in (5, -5):
        c = max(-0.999, min(0.999, cos_g))
        return a3 * math.sqrt(1.0 - 3.0 * c * c + 2.0 * c ** 3)
    if ib == 6:
        return a3 * c_over_a
    if ib == 7:
        return a3 * c_over_a / 2.0
    if ib == 8:
        return a3 * b_over_a * c_over_a
    if ib in (9, -9, 91, 11):
        return a3 * b_over_a * c_over_a / 2.0
    if ib == 10:
        return a3 * b_over_a * c_over_a / 4.0
    if ib in (12, -12, 13, -13, 14):
        sin_g = math.sqrt(max(0.0, 1.0 - cos_g * cos_g)) or 1.0
        vol = a3 * b_over_a * c_over_a * sin_g
        return vol / 2.0 if ib in (13, -13) else vol
    return a3


# ---------------------------------------------------------------------------
# Électrons : valence lue dans les pseudopotentiels
# ---------------------------------------------------------------------------
def _upf_z_valence(upf: Path) -> Optional[float]:
    """Charge de valence d'un UPF (formats v2 attribut et v1 tabulé)."""
    try:
        head = upf.read_text(encoding="utf-8", errors="replace")[:20000]
    except OSError:
        return None
    m = re.search(r'z_valence\s*=\s*"\s*([\d.eEdD+-]+)\s*"', head)
    if not m:
        m = re.search(r"([\d.eEdD+-]+)\s*Z\s*valence", head)
    if not m:
        return None
    try:
        return float(m.group(1).replace("d", "e").replace("D", "e"))
    except ValueError:
        return None


def _atomic_species(text: str) -> list[tuple[str, str]]:
    """Couples (symbole, fichier UPF) de la carte ATOMIC_SPECIES."""
    m = re.search(r"(?im)^\s*ATOMIC_SPECIES\s*$", text)
    if not m:
        return []
    out: list[tuple[str, str]] = []
    for ln in text[m.end():].splitlines():
        s = ln.strip()
        if not s:
            continue
        if re.match(r"(?i)^(ATOMIC_POSITIONS|K_POINTS|CELL_PARAMETERS|OCCUPATIONS|&)", s):
            break
        parts = s.split()
        if len(parts) >= 3 and re.match(r"(?i).*\.(upf|UPF)$", parts[2]):
            out.append((parts[0], parts[2]))
    return out


def _atom_type_counts(text: str) -> dict[str, int]:
    """Nombre d'atomes par espèce, depuis ATOMIC_POSITIONS."""
    m = re.search(r"(?im)^\s*ATOMIC_POSITIONS", text)
    if not m:
        return {}
    counts: dict[str, int] = {}
    for ln in text[m.end():].splitlines():
        s = ln.strip()
        if not s:
            continue
        if re.match(r"(?i)^(K_POINTS|CELL_PARAMETERS|ATOMIC_SPECIES|OCCUPATIONS|&)", s):
            break
        parts = s.split()
        if len(parts) >= 4 and re.match(r"^[A-Za-z]{1,3}[0-9]?$", parts[0]):
            counts[parts[0]] = counts.get(parts[0], 0) + 1
    return counts


def count_electrons(text: str, pseudo_dirs: list[Path]) -> Optional[float]:
    """Électrons de valence = Σ (atomes de l'espèce × z_valence de son UPF).

    Passer par les UPF donne la valeur **exacte** que pw.x utilisera, là où
    déduire la valence du numéro atomique serait faux pour tout pseudo à cœur
    gelé (Si_ONCV : 4 électrons, pas 14).
    """
    species = _atomic_species(text)
    if not species:
        return None
    counts = _atom_type_counts(text)
    if not counts:
        return None
    total = 0.0
    for symbol, upf_name in species:
        z: Optional[float] = None
        for d in pseudo_dirs:
            cand = d / upf_name
            if cand.is_file():
                z = _upf_z_valence(cand)
                if z is not None:
                    break
        if z is None:
            return None
        total += z * counts.get(symbol, 0)
    return total if total > 0 else None


def estimate_nbnd(nelec: float, *, insulator: bool) -> int:
    """Bandes de Kohn-Sham que pw.x allouera par défaut.

    Isolant (``occupations='fixed'``) : nelec/2 exactement — vérifié sur Si
    (8 électrons → 4 bandes, comme rapporté par QE). Métal : QE ajoute une
    marge pour les états partiellement occupés.
    """
    half = nelec / 2.0
    if insulator:
        return max(1, int(math.ceil(half)))
    return max(1, int(math.ceil(max(1.2 * half, half + 4.0))))


# ---------------------------------------------------------------------------
# Décomptes d'ondes planes
# ---------------------------------------------------------------------------
def plane_wave_count(volume_bohr3: float, ecut_ry: float) -> int:
    """Ondes planes dans la sphère ``|G|² ≤ ecut`` (unités Ry, ħ²/2m = 1)."""
    if volume_bohr3 <= 0 or ecut_ry <= 0:
        return 1
    return max(1, int(volume_bohr3 * ecut_ry ** 1.5 / _SIX_PI2))


def derive_cell_facts(
    text: str,
    desc: MaterialDescriptors,
    *,
    pseudo_dirs: Optional[list[Path]] = None,
) -> CellFacts:
    """Assemble volume, électrons, bandes et décomptes d'ondes planes."""
    facts = CellFacts()
    vol = cell_volume_bohr3(text, desc.ibrav) if text else None
    if vol:
        facts.volume_bohr3 = vol
        facts.source = "calculé depuis scf.in"

    insulator = bool(re.search(r"(?i)occupations\s*=\s*['\"]?fixed", text or ""))
    facts.insulator = insulator
    nelec = count_electrons(text, pseudo_dirs or []) if text else None
    if nelec:
        facts.nelec = nelec
        facts.nbnd = estimate_nbnd(nelec, insulator=insulator)
    # ``nbnd`` explicite dans l'entrée : il prime sur toute déduction.
    m = re.search(r"(?im)^\s*nbnd\s*=\s*(\d+)", text or "")
    if m:
        facts.nbnd = max(1, int(m.group(1)))

    ecutrho = desc.ecutrho or 4.0 * desc.ecutwfc
    facts.n_pw_wfc = plane_wave_count(facts.volume_bohr3, desc.ecutwfc)
    facts.n_g_dense = plane_wave_count(facts.volume_bohr3, ecutrho)
    facts.n_fft_dense = int(facts.n_g_dense * _FFT_PER_G_VECTOR)
    return facts


def read_exact_cell_facts(out_path: Path, facts: CellFacts) -> CellFacts:
    """Remplace les estimations par ce que pw.x a réellement imprimé.

    pw.x publie volume, bandes, vecteurs G et dimensions FFT dans son en-tête :
    dès qu'une sortie existe, l'estimation de taille devient quasi exacte.
    """
    try:
        head = out_path.read_text(encoding="utf-8", errors="replace")[:60000]
    except OSError:
        return facts
    got = False
    m = re.search(r"unit-cell volume\s*=\s*([\d.]+)", head)
    if m:
        facts.volume_bohr3, got = float(m.group(1)), True
    m = re.search(r"number of Kohn-Sham states\s*=\s*(\d+)", head)
    if m:
        facts.nbnd, got = int(m.group(1)), True
    m = re.search(r"number of electrons\s*=\s*([\d.]+)", head)
    if m:
        facts.nelec, got = float(m.group(1)), True
    m = re.search(
        r"Dense\s+grid:\s*(\d+)\s*G-vectors\s*FFT dimensions:\s*\(\s*(\d+),\s*(\d+),\s*(\d+)\)",
        head,
    )
    if m:
        facts.n_g_dense = int(m.group(1))
        facts.n_fft_dense = int(m.group(2)) * int(m.group(3)) * int(m.group(4))
        got = True
    m = re.search(r"Smooth\s+grid:\s*(\d+)\s*G-vectors", head)
    if m and facts.n_g_dense:
        # Le nombre d'ondes planes des fonctions d'onde se déduit du volume et
        # d'ecutwfc ; la grille « Smooth » sert la densité, pas les orbitales.
        pass
    if got:
        facts.source = f"lu ({out_path.name})"
    return facts


# ---------------------------------------------------------------------------
# Estimation
# ---------------------------------------------------------------------------
@dataclass
class StorageComponent:
    name: str
    bytes: int
    kind: str  # "scratch" | "résultats"
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "bytes": self.bytes,
            "human": humanize_bytes(self.bytes),
            "kind": self.kind,
            "detail": self.detail,
        }


@dataclass
class StorageEstimate:
    profile_id: str
    peak_bytes: int
    retained_bytes: int
    components: list[StorageComponent] = field(default_factory=list)
    cell_facts: dict[str, Any] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    disk_free_bytes: Optional[int] = None
    confidence: str = "moyenne"

    def to_dict(self) -> dict[str, Any]:
        return {
            "profile_id": self.profile_id,
            "peak_bytes": self.peak_bytes,
            "peak_human": humanize_bytes(self.peak_bytes),
            "retained_bytes": self.retained_bytes,
            "retained_human": humanize_bytes(self.retained_bytes),
            "scratch_bytes": max(0, self.peak_bytes - self.retained_bytes),
            "scratch_human": humanize_bytes(max(0, self.peak_bytes - self.retained_bytes)),
            "components": [c.to_dict() for c in self.components],
            "cell_facts": self.cell_facts,
            "warnings": self.warnings,
            "disk_free_bytes": self.disk_free_bytes,
            "disk_free_human": (
                humanize_bytes(self.disk_free_bytes)
                if self.disk_free_bytes is not None
                else None
            ),
            "confidence": self.confidence,
        }


def humanize_bytes(n: float) -> str:
    """Taille lisible : « 812 Kio », « 1,5 Gio »."""
    v = float(max(0, n))
    for unit, limit in (("o", 1024), ("Kio", 1024 ** 2), ("Mio", 1024 ** 3)):
        if v < limit:
            scaled = v / (limit / 1024)
            if unit == "o":
                return f"{v:.0f} o"
            return f"{scaled:.0f} {unit}" if scaled >= 10 else f"{scaled:.1f} {unit}"
    gio = v / GIB
    return f"{gio:.0f} Gio" if gio >= 10 else f"{gio:.1f} Gio"


def _ph0_physics_bytes(
    n_q: int,
    n_modes: int,
    n_fft: int,
    wfc_full_grid: int,
) -> int:
    """Partie dvscf + orbitales perturbées, sans plancher empirique."""
    dvscf = n_q * n_modes * n_fft * BYTES_PER_COMPLEX
    wfc = int(n_q * _PH_WFC_PER_Q * wfc_full_grid + _PH_PEAK_SCRATCH * wfc_full_grid)
    return int(dvscf + wfc)


def _ph0_first_chain_bytes(
    n_q: int,
    n_modes: int,
    n_fft: int,
    wfc_full_grid: int,
) -> int:
    """Première chaîne phonon (avant QHA) — ~1,2 Gio mesurés sur Si (8 q)."""
    geo = _ph0_qha_geometry_bytes(n_q, n_modes, n_fft, wfc_full_grid)
    return max(geo, int(1.18 * GIB * max(1, n_q) / 8))


def _ph0_qha_geometry_bytes(
    n_q: int,
    n_modes: int,
    n_fft: int,
    wfc_full_grid: int,
) -> int:
    """Scratch ``out_scf_eq/gK/_ph0`` — calibré à 880 Mio pour Si (8 q irr.)."""
    physics = _ph0_physics_bytes(n_q, n_modes, n_fft, wfc_full_grid)
    ref = _ph0_physics_bytes(_REF_N_Q, _REF_N_MODES, _REF_N_FFT, _REF_WFC_FULL)
    if ref <= 0:
        return int(_PH0_PER_GEOMETRY_MIB * MIB)
    return int(physics * (_PH0_PER_GEOMETRY_MIB * MIB / ref))


def _pw_run_bytes(facts: CellFacts, n_k: int) -> int:
    """Taille d'un dossier ``prefix.save`` après un pw.x : densité + orbitales.

    Le terme fixe couvre le XML, les occupations et les blocs PAW/becsum. Il est
    calé sur les 12,86 Mio mesurés par volume de la grille EOS de référence,
    dont la densité et les orbitales n'expliquent que 10,8 Mio.
    """
    density = facts.n_g_dense * BYTES_PER_COMPLEX
    wavefunctions = facts.nbnd * facts.n_pw_wfc * BYTES_PER_COMPLEX * max(1, n_k)
    return int(density + wavefunctions + _PW_FIXED_OVERHEAD_MIB * MIB)


def estimate_storage(
    *,
    profile_id: str,
    profile: dict[str, Any],
    descriptors: MaterialDescriptors,
    cell_facts: CellFacts,
    n_eos_volumes: int = 7,
    disk_path: Optional[Path] = None,
    nscf_k_multiplier: float = 4.0,
) -> StorageEstimate:
    """Espace disque attendu pour un profil, composant par composant."""
    comps: list[StorageComponent] = []
    n_k_irr = descriptors.nk_irreducible or estimate_irreducible_points(
        descriptors.nk, descriptors.ibrav
    )
    n_k_full = max(1, descriptors.nk[0] * descriptors.nk[1] * descriptors.nk[2])
    n_q = descriptors.nq_irreducible or estimate_irreducible_points(
        descriptors.nq, descriptors.ibrav
    )
    n_modes = descriptors.n_modes
    pw_run = _pw_run_bytes(cell_facts, n_k_irr)
    wfc_full_grid = cell_facts.nbnd * cell_facts.n_pw_wfc * BYTES_PER_COMPLEX * n_k_full

    if profile.get("needs_eos"):
        comps.append(
            StorageComponent(
                "1_eos_volumes", int(n_eos_volumes * pw_run), "scratch",
                f"{n_eos_volumes} volumes × (densité + {cell_facts.nbnd} bandes "
                f"× {n_k_irr} points k)",
            )
        )
    comps.append(
        StorageComponent(
            "out_scf_eq (SCF @ V₀)", pw_run, "scratch",
            f"densité {cell_facts.n_g_dense} vecteurs G + orbitales",
        )
    )

    if profile.get("needs_phonons"):
        if is_qha_profile(profile):
            ph0 = _ph0_first_chain_bytes(
                n_q, n_modes, cell_facts.n_fft_dense, wfc_full_grid
            )
            comps.append(
                StorageComponent(
                    "_ph0 — chaîne phonon (1ère)",
                    ph0,
                    "scratch",
                    f"{n_q} points q × {n_modes} modes — avant boucle QHA",
                )
            )
        else:
            dvscf = n_q * n_modes * cell_facts.n_fft_dense * BYTES_PER_COMPLEX
            ph0 = _ph0_physics_bytes(
                n_q, n_modes, cell_facts.n_fft_dense, wfc_full_grid
            )
            comps.append(
                StorageComponent(
                    "_ph0 — potentiels dvscf", int(dvscf), "scratch",
                    f"{n_q} points q × {n_modes} modes × {cell_facts.n_fft_dense} "
                    f"points FFT × 16 o",
                )
            )
            comps.append(
                StorageComponent(
                    "_ph0 — orbitales perturbées",
                    max(0, ph0 - int(dvscf)),
                    "scratch",
                    "wfc1/wfc2 conservés par point q, plus dwf/bar/mixd du q courant",
                )
            )

    if is_qha_profile(profile):
        n_geo = qha_n_geometries(n_eos_volumes=n_eos_volumes)
        ph0_geo = _ph0_qha_geometry_bytes(
            n_q, n_modes, cell_facts.n_fft_dense, wfc_full_grid
        )
        comps.append(
            StorageComponent(
                f"thermo_pw QHA (g1..g{n_geo})",
                int(n_geo * ph0_geo),
                "scratch",
                f"{n_geo} géométries × ~{humanize_bytes(ph0_geo)}/géom. (Si)",
            )
        )
        comps.append(
            StorageComponent(
                "thermo_pw — sorties intermédiaires",
                int(80 * MIB + 12 * MIB * n_geo),
                "scratch",
                "phdisp_files, restart/, therm_files partiels",
            )
        )

    what_l = str(profile.get("what_qe") or "").strip().lower()
    if what_l == "scf_elastic_constants":
        comps.append(
            StorageComponent(
                "thermo_pw — déformations C_ij",
                int(12 * pw_run * 0.35),
                "scratch",
                "what='scf_elastic_constants' — cellules déformées",
            )
        )

    if profile.get("properties_enabled"):
        comps.append(
            StorageComponent(
                "NSCF + DOS + bandes",
                int(_pw_run_bytes(cell_facts, int(n_k_irr * nscf_k_multiplier))),
                "scratch",
                f"grille k densifiée (×{nscf_k_multiplier:g})",
            )
        )

    if profile.get("needs_optical"):
        # La chaîne optique ajoute beaucoup de bandes vides : le stockage des
        # orbitales croît proportionnellement.
        optic_nbnd = max(cell_facts.nbnd * 4, cell_facts.nbnd + 8)
        optic = optic_nbnd * cell_facts.n_pw_wfc * BYTES_PER_COMPLEX * int(
            n_k_irr * nscf_k_multiplier
        )
        comps.append(
            StorageComponent(
                "chaîne optique (bandes vides)", int(optic), "scratch",
                f"{optic_nbnd} bandes pour ε(ω)",
            )
        )

    results = int(
        _RESULTS_BASE_MIB * MIB + _RESULTS_PER_MODE_Q_KIB * 1024 * n_modes * n_q
    )
    if what_l in ("elastic_constants_geo", "mur_lc_t_elastic_constants"):
        results += int(15 * MIB)
    elif what_l == "ph_life":
        results += int(25 * MIB)
    elif is_qha_profile(profile):
        # Tracés QHA, phdisp_files, therm_files — souvent conservés pour analyse.
        results += int(150 * MIB)

    comps.append(
        StorageComponent(
            "résultats conservés", results, "résultats",
            "journaux, .dat/.freq/.dos, matrices dynamiques, tracés",
        )
    )

    peak = sum(c.bytes for c in comps)
    retained = sum(c.bytes for c in comps if c.kind == "résultats")

    warnings: list[str] = []
    free: Optional[int] = None
    if disk_path is not None:
        try:
            free = shutil.disk_usage(str(disk_path)).free
        except OSError:
            free = None
    if free is not None:
        if peak > free:
            warnings.append(
                f"Espace insuffisant : {humanize_bytes(peak)} nécessaires pour "
                f"{humanize_bytes(free)} disponibles. Le calcul échouera en "
                f"cours de route — libérez de la place avant de lancer."
            )
        elif peak > 0.7 * free:
            warnings.append(
                f"Marge disque faible : {humanize_bytes(peak)} nécessaires sur "
                f"{humanize_bytes(free)} disponibles."
            )
    scratch = peak - retained
    if scratch > 20 * retained and scratch > 200 * MIB:
        pct = 100.0 * scratch / peak if peak else 0.0
        warnings.append(
            f"{pct:.1f} % du pic ({humanize_bytes(scratch)}) est du scratch QE "
            f"temporaire (out_*/_ph0). Les résultats à conserver ne pèsent que "
            f"{humanize_bytes(retained)} : un nettoyage après calcul libère "
            f"presque tout."
        )

    if is_qha_profile(profile):
        n_geo = qha_n_geometries(n_eos_volumes=n_eos_volumes)
        warnings.append(
            f"thermo_pw QHA : ~{n_geo} géométries conservent chacune un dossier "
            f"``out_scf_eq/g*`` (~{humanize_bytes(_PH0_PER_GEOMETRY_MIB * MIB)} "
            f"de scratch/géom. sur Si). Le pic annoncé inclut cette accumulation ; "
            f"un nettoyage des dossiers g* libère l'essentiel."
        )

    confidence = "bonne" if cell_facts.source.startswith("lu") else "moyenne"
    return StorageEstimate(
        profile_id=profile_id,
        peak_bytes=int(peak),
        retained_bytes=int(retained),
        components=comps,
        cell_facts=cell_facts.to_dict(),
        warnings=warnings,
        disk_free_bytes=free,
        confidence=confidence,
    )


# ---------------------------------------------------------------------------
# Mesure réelle (suivi live et calibration)
# ---------------------------------------------------------------------------
def measure_dir_size(path: Path, *, max_entries: int = 200_000) -> dict[str, Any]:
    """Taille réelle d'un dossier de calcul, scratch et résultats séparés.

    ``max_entries`` borne le parcours : un ``_ph0`` peut contenir des milliers
    de fichiers et cette fonction est appelée pendant que le calcul tourne.
    """
    root = Path(path)
    total = 0
    scratch = 0
    seen = 0
    if not root.is_dir():
        return {"total_bytes": 0, "scratch_bytes": 0, "results_bytes": 0, "truncated": False}
    truncated = False
    for p in root.rglob("*"):
        if seen >= max_entries:
            truncated = True
            break
        try:
            if not p.is_file():
                continue
            size = p.stat().st_size
        except OSError:
            continue
        seen += 1
        total += size
        rel = str(p.relative_to(root))
        # Scratch QE : outdir (out*/), _ph0, grille EOS, géométries QHA g*.
        if (
            rel.startswith(("out", "1_eos_volumes"))
            or "_ph0" in rel
            or "/g" in rel and rel.startswith("out_scf_eq/g")
            or rel.startswith(("phdisp_files", "restart"))
        ):
            scratch += size
    return {
        "total_bytes": total,
        "total_human": humanize_bytes(total),
        "scratch_bytes": scratch,
        "scratch_human": humanize_bytes(scratch),
        "results_bytes": total - scratch,
        "results_human": humanize_bytes(total - scratch),
        "truncated": truncated,
    }

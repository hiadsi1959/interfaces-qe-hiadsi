"""
Catalogue des ``what=`` thermo_pw étendus pour le profil P5 « Propriétés diélectriques ».

Le profil P5 extrait ε∞ depuis **ph.out** (pas de ``what=`` thermo_pw 7.5).
Le guide utilisateur documente en complément quelques ``what=`` thermo_pw.x
activables comme extras P5 :

* ``piezoelectric_tensor``   : alias → ``scf_piezoelectric_tensor`` (T = 0 K, V = V₀).
* ``magnetic_susceptibility``: χ magnétique — exige un SCF spin-polarisé (nspin=2)
                               en amont. Sans cela, thermo_pw sort proprement
                               avec un message d'erreur lisible.
* ``magnetoelectric_tensor`` : tenseur magnétoélectrique α_ij (multi-physique).
* ``plot_bz``                : utilitaire de visualisation de la zone de Brillouin
                               et du groupe spatial — inoffensif, utile pour
                               la publication et l'archivage du run.

Ces ``what=`` font partie de l'extension P5 et sont *additifs* à la chaîne
QE principale (qui reste active). L'utilisateur les active via le panneau
d'options P5 (étape ② de l'UI). Chaque ``what=`` produit son propre journal
``thermo_pw_<what>.out`` (cf. ``phonon_chain_qe.run_thermo_pw_mpi(log_filename=...)``).

Fonctions exposées :
* ``WHAT_CATALOG`` : dict[what_lower → WhatCatalogEntry].
* ``get_catalog_entry(what)`` : valide la saisie + enrichit pour un run précis.
* ``default_extra_whats_for_p5()`` : suggère une présélection safe (``plot_bz``).
* ``validation_warnings(extra_whats, profile)`` : retourne les messages à
  afficher à l'utilisateur quand un ``what=`` sélectionné requiert des
  options SCF spéciales (nspin=2, etc.).

Voir ``phonon_chain_qe.valid_thermo_pw_key`` pour la whitelist stricte (sécurité).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class WhatCatalogEntry:
    """Métadonnées pour un ``what=`` thermo_pw.x admissible côté P5 extras.

    Attributs figés (`frozen=True`) — ce catalogue est une référence
    statique reconstruite au chargement du module.
    """

    # --- Identité ----------------------------------------------------------
    #: Clé canonique minuscule utilisée côté backend / API / pipeline.
    what: str
    #: Libellé humain court pour l'UI.
    label: str
    #: Description longue affichée dans un ``title`` HTML.
    tooltip: str
    #: Emoji optionnel pour la chip UI (vide pour sobriété max).
    emoji: str = ""
    #: Catégorie thématique — utilisée pour grouper dans l'UI.
    group: str = "Divers"

    # --- Exécution --------------------------------------------------------
    #: Préfixe pour le journal thermo_pw.x (``thermo_pw_<suffix>.out``).
    log_suffix: str = ""
    #: `what=` envoyé à ``write_thermo_control_minimal`` (par défaut = ``what``).
    directive: str = ""
    #: Binaire thermo_pw.x — vide ⇒ le binaire ``cfg.thermo_pw_path()`` standard.
    executable: str = ""

    # --- Physique / dépendances ------------------------------------------
    #: ``True`` si thermo_pw a besoin de chaines phonons (fc.out) — toujours
    #: ``False`` pour les extras P5 (sinon on les aurait déjà classés en QHA).
    needs_phonons: bool = False
    #: ``True`` si un SCF spin-polarisé (``nspin=2``) doit être disponible.
    needs_spin_polarized: bool = False
    #: ``True`` pour les matériaux isolants uniquement (gap > 0).
    needs_insulating: bool = False
    #: ``True`` si le matériau doit être non-centrosymétrique (spacegroup ≠ centrosym.).
    needs_non_centrosymmetric: bool = False

    # --- Sortie -----------------------------------------------------------
    #: Fichiers de sortie typiques (relatifs à work_dir) — ajoutés à
    #: ``expected_results.files`` de P5 si l'extra est sélectionné.
    expected_outputs: tuple[str, ...] = field(default_factory=tuple)
    #: Clés que les parsers peuvent extraire (cosmétique — utilisé pour
    #: ``expected_results.metrics`` additionnelles).
    metric_keys: tuple[str, ...] = field(default_factory=tuple)


# ----------------------------------------------------------------------------
# Catalogue complet (extension P5)
# ----------------------------------------------------------------------------


WHAT_CATALOG: dict[str, WhatCatalogEntry] = {
    "piezoelectric_tensor": WhatCatalogEntry(
        what="piezoelectric_tensor",
        label="Tenseur piézoélectrique e_ijk",
        tooltip=(
            "Tenseur piézoélectrique (e_ijk) à T = 0 K, V = V₀ — DFPT "
            "thermo_pw (what='scf_piezoelectric_tensor'). Réservé aux isolants "
            "non-centrosymétriques ; pour un matériau centrosymétrique le "
            "tenseur est nul par symétrie."
        ),
        group="Piézolélectrique",
        log_suffix="piezoelectric_tensor",
        directive="scf_piezoelectric_tensor",
        needs_insulating=True,
        needs_non_centrosymmetric=True,
        expected_outputs=("output_piezo.dat",),
        metric_keys=(
            "thermo_extras.piezoelectric_e33_pCm2",
            "thermo_extras.piezoelectric_tensor_pCm2",
        ),
    ),
    "magnetic_susceptibility": WhatCatalogEntry(
        what="magnetic_susceptibility",
        label="Susceptibilité magnétique χ",
        tooltip=(
            "Susceptibilité magnétique χ en unités SI. REQUIERT un SCF "
            "spin-polarisé (``nspin=2``) en amont — sinon thermo_pw.x "
            "terminera en erreur explicite. À activer pour les matériaux "
            "magnétiques déclarés (Fe / Co / Ni / Mn / …)."
        ),
        emoji= "🧲",
        group="Magnétisme",
        log_suffix="magnetic_susceptibility",
        needs_spin_polarized=True,
        metric_keys=("thermo_extras.magnetic_susceptibility_SI",),
        expected_outputs=("magnetic_susceptibility.dat",),
    ),
    "magnetoelectric_tensor": WhatCatalogEntry(
        what="magnetoelectric_tensor",
        label="Tenseur magnétoélectrique α_ij",
        tooltip=(
            "Tenseur magnétoélectrique α_ij (couplage champ magnétique ↔ "
            "polarisation électrique). Calcul multi-physique exigeant un "
            "SCF spin-polarisé et un matériau isolant. À activer pour "
            "études dédiées (rare en pratique)."
        ),
        group="Magnétoélectrique",
        log_suffix="magnetoelectric_tensor",
        needs_spin_polarized=True,
        needs_insulating=True,
        metric_keys=("thermo_extras.magnetoelectric_alpha_ij",),
    ),
    "plot_bz": WhatCatalogEntry(
        what="plot_bz",
        label="Visualisation zone de Brillouin",
        tooltip=(
            "Sortie graphique de la zone de Brillouin (PostScript) + "
            "fichier texte avec les points high-sym. Inoffensif et "
            "rapide : fortement recommandé pour documentation / "
            "archivage des chemins q et k."
        ),
        emoji="🛰️",
        group="Visualisation",
        log_suffix="plot_bz",
        expected_outputs=("BZ_plot.ps.gz", "BZ.txt"),
    ),
}


def get_catalog_entry(what: str) -> Optional[WhatCatalogEntry]:
    """Lookup avec normalisation (lower + strip apostrophes)."""
    if not what:
        return None
    w = str(what).strip().strip("'\"").lower()
    return WHAT_CATALOG.get(w)


def list_all_p5_extras() -> list[WhatCatalogEntry]:
    """Liste triée par groupe puis alphabétique pour affichage UI."""
    return sorted(
        WHAT_CATALOG.values(),
        key=lambda e: (e.group.lower(), e.label.lower()),
    )


def default_extra_whats_for_p5() -> list[str]:
    """Présélection safe pour P5 (sans côté piézo/magnétique hasardeux).

    Active uniquement ``plot_bz`` (inoffensif, rapide, utile). L'utilisateur
    peut cocher manuellement les autres depuis le panneau P5.
    """
    return ["plot_bz"]


def validation_warnings(
    extra_whats: list[str],
    *,
    scf_has_spin_polarized: bool,
    band_gap_eV: Optional[float] = None,
    spacegroup_is_centrosymmetric: Optional[bool] = None,
) -> list[str]:
    """Calcule les avertissements à afficher à l'utilisateur.

    Reçoit des indices sur le matériau (lus côté api_server depuis le SCF
    ou depuis des inputs externes). On NE lève PAS d'erreur : c'est un
    warning UI qui n'empêche pas de lancer le run.
    """
    warnings: list[str] = []
    if not extra_whats:
        return warnings
    for raw in extra_whats:
        e = get_catalog_entry(raw)
        if e is None:
            continue
        if e.needs_spin_polarized and not scf_has_spin_polarized:
            warnings.append(
                f"[{e.what}] requiert un SCF spin-polarisé (nspin=2 ou nspin=4). "
                "Le run actuel utilise un SCF non-polarisé — thermo_pw.x "
                "risque fort d'échouer."
            )
        if e.needs_insulating and band_gap_eV is not None and band_gap_eV <= 0.05:
            warnings.append(
                f"[{e.what}] ciblé isolants — le gap estimé est nul/métallique "
                f"(≤ 0.05 eV). Le calcul n'a probablement pas de sens pour "
                f"ce matériau."
            )
        if (
            e.needs_non_centrosymmetric
            and spacegroup_is_centrosymmetric is True
        ):
            warnings.append(
                f"[{e.what}] requiert un cristal non-centrosymétrique — le "
                "matériau actuel est centrosymétrique (tenseur piézo nul)."
            )
    return warnings


def expand_extra_whats(
    raw: list[str] | tuple[str, ...] | str | None,
) -> list[str]:
    """Normalise une entrée utilisateur (string, list, csv) → liste dédupliquée.

    * ``None`` ou ``""`` → ``[]``
    * ``"plot_bz"`` ou ``"plot_bz,piezo"`` → ``["plot_bz", "piezo"]``
    * Déduplique en préservant l'ordre.
    * Filtre ce qui n'est PAS dans ``WHAT_CATALOG`` pour éviter les
      frappes clavier parasites côté API.
    """
    if raw is None or raw == "":
        return []
    if isinstance(raw, str):
        parts = [p for p in (s.strip().strip("'\"") for s in raw.split(",")) if p]
    else:
        parts = [str(p).strip().strip("'\"") for p in raw if str(p).strip()]
    seen: set[str] = set()
    out: list[str] = []
    for p in parts:
        if not p or p in seen:
            continue
        if p not in WHAT_CATALOG:
            continue
        seen.add(p)
        out.append(p)
    return out

"""
Diagrammes thermo mono-phase (post-P2, opt-in CALPHAD).

Post-traitement léger (~secondes, ~200 Ko PNG) : courbes Cp, S, H vs T
depuis ``calphad_espei/datasets/*.json``. Pas de pyCalphad requis.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


@dataclass
class PhasePlotResult:
    ok: bool
    plots: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "plots": list(self.plots),
            "warnings": list(self.warnings),
            "errors": list(self.errors),
        }


def _load_espei_curve(path: Path) -> tuple[list[float], list[float]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    temps = [float(t) for t in data["conditions"]["T"]]
    vals = [float(row[0]) for row in data["values"][0]]
    return temps, vals


def _stability_caption(results: Optional[dict[str, Any]], material_id: str) -> str:
    props = (results or {}).get("properties") or {}
    dyn = props.get("dynamically_stable")
    eos = ((results or {}).get("eos") or {}).get("eos") or {}
    b0 = eos.get("B0_GPa") or (results or {}).get("eos", {}).get("B0_GPa_approx")
    parts = [material_id or "Phase"]
    if dyn is True:
        parts.append("stable dynamiquement (ω > 0)")
    elif dyn is False:
        parts.append("instabilité dynamique détectée")
    if b0 is not None:
        parts.append(f"B₀ ≈ {float(b0):.1f} GPa")
    parts.append("mono-phase QHA — pas un diagramme multi-phases")
    return " · ".join(parts)


def generate_phase_plots(
    work_dir: Path,
    *,
    espei_dir_name: str = "calphad_espei",
    results: Optional[dict[str, Any]] = None,
    material_id: str = "",
) -> PhasePlotResult:
    """Écrit ``calphad_espei/plots/phase_thermo_overview.png`` (+ courbes séparées)."""
    work_dir = Path(work_dir).resolve()
    espei_dir = work_dir / espei_dir_name
    out_dir = espei_dir / "plots"
    res = PhasePlotResult(ok=False)
    ds = espei_dir / "datasets"

    specs = [
        ("cpm_form_qha.json", "Cp (J/mol-atom·K)", "phase_cp.png", "#2563eb"),
        ("sm_form_qha.json", "S (J/mol-atom·K)", "phase_entropy.png", "#059669"),
        ("hm_form_qha.json", "H (J/mol-atom)", "phase_enthalpy.png", "#dc2626"),
    ]
    curves: list[tuple[str, list[float], list[float], str, str]] = []
    for fname, ylab, png, color in specs:
        p = ds / fname
        if not p.is_file():
            res.warnings.append(f"dataset absent : {fname}")
            continue
        try:
            t, y = _load_espei_curve(p)
            curves.append((ylab, t, y, color, png))
        except (OSError, json.JSONDecodeError, KeyError, IndexError, TypeError) as ex:
            res.warnings.append(f"{fname} illisible : {ex}")

    if not curves:
        res.errors.append(
            "Aucune courbe ESPEI — lancer d'abord l'export (opt-in P2 ou API espei_export)."
        )
        return res

    out_dir.mkdir(parents=True, exist_ok=True)
    caption = _stability_caption(results, material_id)
    rel_plots: list[str] = []

    # Vue combinée (une tuile UI).
    n = len(curves)
    fig, axes = plt.subplots(n, 1, figsize=(7.5, 2.8 * n), sharex=True)
    if n == 1:
        axes = [axes]
    for ax, (ylab, t, y, color, _png) in zip(axes, curves):
        ax.plot(t, y, color=color, lw=2)
        ax.set_ylabel(ylab)
        ax.grid(True, alpha=0.3)
    axes[-1].set_xlabel("T (K)")
    fig.suptitle(f"Diagramme thermo mono-phase — {caption}", fontsize=10)
    fig.tight_layout()
    overview = out_dir / "phase_thermo_overview.png"
    fig.savefig(overview, dpi=150)
    plt.close(fig)
    rel_plots.append(f"{espei_dir_name}/plots/phase_thermo_overview.png")

    for ylab, t, y, color, png in curves:
        fig, ax = plt.subplots(figsize=(7, 4.2))
        ax.plot(t, y, color=color, lw=2)
        ax.set_xlabel("T (K)")
        ax.set_ylabel(ylab)
        ax.set_title(caption)
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        out_path = out_dir / png
        fig.savefig(out_path, dpi=150)
        plt.close(fig)
        rel_plots.append(f"{espei_dir_name}/plots/{png}")

    res.plots = rel_plots
    res.ok = True
    return res


__all__ = ["PhasePlotResult", "generate_phase_plots"]

"""
Lecteur ε∞ + charges de Born pour le profil P5.

thermo_pw 7.5 n'expose **aucun** ``what=`` diélectrique (ni ``dielectric`` ni
``scf_dielectric`` — ``thermo_summary`` → « what not programmed »). P5 extrait
donc les grandeurs depuis **ph.x** (champ électrique à Γ, déjà calculé dans la
chaîne phonon) :

1. ``ph.out`` (source principale) : « Dielectric constant in cartesian axis »
   + « Effective charges (d P / du) » ou « (d Force / dE) … without … asr ».

2. ``thermo_pw_run.out`` (legacy / runs anciens) : section « Dielectric constant: ».

3. ``epsilon_infinity.dat`` / ``dielectric_tensor.dat`` : fichiers colonne optionnels.

Format de retour (clés garanties) :

    * ``epsilon_xx``               : float | None
    * ``epsilon_yy``               : float | None
    * ``epsilon_zz``               : float | None
    * ``epsilon_xy``               : float | None  (syn. ``epsilon_yx``)
    * ``epsilon_xz``               : float | None  (syn. ``epsilon_zx``)
    * ``epsilon_yz``               : float | None  (syn. ``epsilon_zy``)
    * ``epsilon_average``          : float | None  (mean of diagonal)
    * ``epsilon_anisotropy``       : float | None  (max(diag) / min(diag))
    * ``average_dielectric_constant`` : float | None  (depuis header)
    * ``born_Z_star_max_abs``      : float | None  (max |Z*_alpha,beta|)
    * ``born_Z_star_per_atom``     : list[{atom_index, atom_type, Z_star_3x3}]
    * ``refractive_index_avg``     : float | None  (sqrt(epsilon_average))
    * ``source_line``              : str | None
    * ``matched_keywords``         : list[str]

Reprend partiellement `parse_scf_dielectric` de thermo_pw_out_parse (qui
couvre ``dielectric constant (high frequency)``) et étend avec le bloc
« Born effective charges » + post-traitements moyenne / anisotropie / n.
"""
from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Any, Optional

# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------


def _qe_float(token: str) -> Optional[float]:
    s = str(token).strip().replace(",", ".")
    if not s:
        return None
    try:
        return float(s.replace("D", "E").replace("d", "e"))
    except ValueError:
        return None


# Header « Dielectric constant: » (thermo_pw 7.x ug.1.5.0+).
# NB : flags passés via `re.compile(..., flags=)` au lieu de inline `(?is)` afin
# d'éviter `re.PatternError: global flags not at the start` sur Python ≥3.13
# quand le flag inline est précédé d'un whitespace (multi-ligne).
_RE_DIELECTRIC_HEADER = re.compile(
    r"(?:static\s+|electronic\s+)?(?:dielectric\s+constant|epsilon\s*∞|eps\s*∞)\s*"
    r"(?:\([^)]*\))?\s*:?\s*\n",
    re.IGNORECASE | re.DOTALL,
)
# Header « Effective charges: » / « Born effective charges ».
_RE_BORN_HEADER = re.compile(
    r"(?:born\s+effective\s+charges|effective\s+charges|born\s+charges)\s*:?\s*\n",
    re.IGNORECASE | re.DOTALL,
)
# Moyenne publiée explicitement.
_RE_AVERAGE = re.compile(
    r"average\s+(?:dielectric\s+constant|dielectric\s+tensor\s+trace|epsilon)\s*[:=]\s*"
    r"([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)",
    re.IGNORECASE | re.DOTALL,
)
# Refractive index publié (rare mais utile).
_RE_REFRACTIVE = re.compile(
    r"(?:refractive\s+index|index\s+of\s+refraction)\s*[:=]\s*"
    r"([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)",
    re.IGNORECASE | re.DOTALL,
)
# Ligne atome de la section Born charges : « atom <idx>  type <sym> »
_RE_BORN_ATOM = re.compile(
    r"(?i)atom\s+(\d+)(?:\s+type\s+([A-Za-z][A-Za-z0-9_]*))?\s*(?:\(.+?\))?\s*:?\s*$",
)
# Ligne Z* en notation compacte : « Z* =  Zxx Zxy Zxz   Zyx Zyy Zyz   Zzx Zzy Zzz »
# (les 9 nombres sont typiquement espacés librement sur 1-3 lignes).
_RE_ZSTAR_COMPACT = re.compile(
    r"(?i)(?:Z\*|Z\^\*)\s*[=:]?\s*([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?"
    r"(?:\s+[+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?){8,30})",
)
# ph.x (QE 7.x) — tenseur ε en notation FORTRAN « ( a b c ) » sur 3 lignes.
_RE_PH_DIELECTRIC_BLOCK = re.compile(
    r"Dielectric constant in cartesian axis\s*\n+"
    r"\s*\(\s*([+-]?\d+\.?\d*(?:[EeDd][+-]?\d+)?)\s+"
    r"([+-]?\d+\.?\d*(?:[EeDd][+-]?\d+)?)\s+"
    r"([+-]?\d+\.?\d*(?:[EeDd][+-]?\d+)?)\s*\)\s*\n"
    r"\s*\(\s*([+-]?\d+\.?\d*(?:[EeDd][+-]?\d+)?)\s+"
    r"([+-]?\d+\.?\d*(?:[EeDd][+-]?\d+)?)\s+"
    r"([+-]?\d+\.?\d*(?:[EeDd][+-]?\d+)?)\s*\)\s*\n"
    r"\s*\(\s*([+-]?\d+\.?\d*(?:[EeDd][+-]?\d+)?)\s+"
    r"([+-]?\d+\.?\d*(?:[EeDd][+-]?\d+)?)\s+"
    r"([+-]?\d+\.?\d*(?:[EeDd][+-]?\d+)?)\s*\)",
    re.IGNORECASE,
)
# ph.x — atom line « atom    1  Si    Mean Z*: … » puis Ex/Ey/Ez ou Px/Py/Pz.
_RE_PH_BORN_ATOM = re.compile(
    r"^\s*atom\s+(\d+)\s*([A-Za-z][A-Za-z0-9_]*)\b",
    re.IGNORECASE | re.MULTILINE,
)
_RE_PH_BORN_ROW = re.compile(
    r"^\s*(?:E[xyz]|P[xyz])\s*\(\s*"
    r"([+-]?\d+\.?\d*(?:[EeDd][+-]?\d+)?)\s+"
    r"([+-]?\d+\.?\d*(?:[EeDd][+-]?\d+)?)\s+"
    r"([+-]?\d+\.?\d*(?:[EeDd][+-]?\d+)?)\s*\)",
    re.IGNORECASE | re.MULTILINE,
)


def _read_numeric_matrix_after_block(
    block: str,
    *,
    n_rows: int = 3,
    n_cols: int = 3,
    max_scan_lines: int = 50,
) -> tuple[list[list[Optional[float]]], Optional[str]]:
    """Lit une matrice ``n_rows×n_cols`` à partir d'un bloc de texte.

    Skip les lignes vides / commentaires / titres. Renvoie
    ``(matrix, first_line_used)``. ``matrix`` peut contenir des ``None``
    là où un token n'est pas numérique.
    """
    if not block or not block.strip():
        return [], None
    rows: list[list[Optional[float]]] = []
    first_line: Optional[str] = None
    for ln_raw in block.splitlines()[:max_scan_lines]:
        ln = ln_raw.strip()
        if not ln or ln.lower().startswith("#") or ln.lower().startswith("!"):
            continue
        # Skip titres (« atom … type … »).
        if _RE_BORN_ATOM.match(ln):
            continue
        # Skip ligne « Z* = … » : déléguée au parseur Z*.
        if _RE_ZSTAR_COMPACT.match(ln):
            continue
        # FORTRAN-style : un « . » isolé (non précédé/suivi d'un chiffre) représente
        # le zéro implicite que thermo_pw 7.x omet dans l'impression des matrices
        # symétriques. ``0.20`` reste ``0.20`` ; `` .  `` devient ``0.0``.
        if "." in ln:
            ln_norm = re.sub(r"(?<!\d)\.(?!\d)", "0.0", ln)
        else:
            ln_norm = ln
        toks = re.split(r"[\s,;]+", ln_norm)
        if len(toks) < n_cols:
            continue
        vals: list[Optional[float]] = [_qe_float(t) for t in toks[:n_cols]]
        if any(v is None for v in vals):
            # Repli : on accepte une ligne avec moins de ``n_cols`` valides mais
            # ≥ 2 (cas d'une ligne d'en-tête).
            cont = sum(1 for v in vals if v is not None)
            if cont < 2:
                continue
        if first_line is None:
            first_line = ln[:200]
        rows.append(vals)
        if len(rows) >= n_rows:
            break
    return rows, first_line


def _apply_epsilon_matrix(
    out: dict[str, Any],
    matrix: list[list[Optional[float]]],
    *,
    source_line: Optional[str],
    keyword: str,
) -> None:
    if len(matrix) < 3:
        return
    out["epsilon_xx"] = matrix[0][0]
    out["epsilon_yy"] = matrix[1][1]
    out["epsilon_zz"] = matrix[2][2]
    out["epsilon_xy"] = matrix[0][1]
    out["epsilon_xz"] = matrix[0][2]
    out["epsilon_yz"] = matrix[1][2]
    if source_line:
        out["source_line"] = source_line
    diag = [matrix[i][i] for i in range(3) if matrix[i][i] is not None]
    if diag:
        out["epsilon_average"] = sum(diag) / len(diag)
        out["average_dielectric_constant"] = out["epsilon_average"]
        dmin, dmax = min(diag), max(diag)
        if dmin > 0:
            out["epsilon_anisotropy"] = dmax / dmin
        if out["epsilon_average"] and out["epsilon_average"] > 0:
            try:
                out["refractive_index_avg"] = float(
                    math.sqrt(out["epsilon_average"])
                )
            except ValueError:
                pass
    if keyword not in out["matched_keywords"]:
        out["matched_keywords"].append(keyword)


def parse_ph_out_dielectric_from_text(text: str) -> dict[str, Any]:
    """Extrait ε∞ et Z* depuis le journal ``ph.out`` (champ électrique Γ de ph.x)."""
    out: dict[str, Any] = {
        "epsilon_xx": None,
        "epsilon_yy": None,
        "epsilon_zz": None,
        "epsilon_xy": None,
        "epsilon_xz": None,
        "epsilon_yz": None,
        "epsilon_average": None,
        "epsilon_anisotropy": None,
        "average_dielectric_constant": None,
        "born_Z_star_max_abs": None,
        "born_Z_star_per_atom": [],
        "refractive_index_avg": None,
        "source_line": None,
        "matched_keywords": [],
    }
    if not text or not text.strip():
        return out

    m_eps = _RE_PH_DIELECTRIC_BLOCK.search(text)
    if m_eps:
        nums = [_qe_float(g) for g in m_eps.groups()]
        if all(n is not None for n in nums):
            matrix = [
                [nums[0], nums[1], nums[2]],
                [nums[3], nums[4], nums[5]],
                [nums[6], nums[7], nums[8]],
            ]
            _apply_epsilon_matrix(
                out,
                matrix,
                source_line=m_eps.group(0).splitlines()[0][:200],
                keyword="ph_out_dielectric_tensor_3x3",
            )

    # Préfère « d P / du » (Born macroscopiques) ; sinon « d Force / dE … without asr ».
    born_sections: list[tuple[str, str]] = []
    for marker in (
        "Effective charges (d P / du) in cartesian axis",
        "Effective charges (d Force / dE) in cartesian axis without acoustic sum rule applied (asr)",
    ):
        idx = text.find(marker)
        if idx >= 0:
            born_sections.append((marker, text[idx: idx + 12_000]))
    if not born_sections:
        idx = text.lower().find("effective charges")
        if idx >= 0:
            born_sections.append(("effective charges", text[idx: idx + 12_000]))

    per_atom: list[dict[str, Any]] = []
    max_abs_vals: list[float] = []
    for _label, block in born_sections:
        per_atom = []
        max_abs_vals = []
        atom_matches = list(_RE_PH_BORN_ATOM.finditer(block))
        for i, am in enumerate(atom_matches):
            atom_index = int(am.group(1))
            atom_type = (am.group(2) or "").strip()
            start = am.end()
            end = (
                atom_matches[i + 1].start()
                if i + 1 < len(atom_matches)
                else len(block)
            )
            sub = block[start:end]
            rows_raw = _RE_PH_BORN_ROW.findall(sub)
            if len(rows_raw) < 3:
                continue
            z_star: list[list[float]] = []
            for row in rows_raw[:3]:
                z_star.append([float(_qe_float(v) or 0.0) for v in row])
            per_atom.append(
                {
                    "atom_index": atom_index,
                    "atom_type": atom_type,
                    "Z_star": z_star,
                }
            )
            for r in z_star:
                for v in r:
                    max_abs_vals.append(abs(v))
        if per_atom:
            break

    if per_atom:
        out["born_Z_star_per_atom"] = per_atom
        out["born_Z_star_max_abs"] = max(max_abs_vals) if max_abs_vals else None
        out["matched_keywords"].append("ph_out_born_effective_charges_3x3")

    return out


# ----------------------------------------------------------------------------
# Parseur principal
# ----------------------------------------------------------------------------

def parse_dielectric_from_text(text: str) -> dict[str, Any]:
    """Lit ε∞ (3×3) et Z* depuis le journal ``thermo_pw_run.out`` (what='dielectric').

    Renvoie le dict structuré (voir module docstring).
    """
    out: dict[str, Any] = {
        "epsilon_xx": None,
        "epsilon_yy": None,
        "epsilon_zz": None,
        "epsilon_xy": None,
        "epsilon_xz": None,
        "epsilon_yz": None,
        "epsilon_average": None,
        "epsilon_anisotropy": None,
        "average_dielectric_constant": None,
        "born_Z_star_max_abs": None,
        "born_Z_star_per_atom": [],
        "refractive_index_avg": None,
        "source_line": None,
        "matched_keywords": [],
    }
    if not text or not text.strip():
        return out

    # 1. Tenseur diélectrique statique
    m_head = _RE_DIELECTRIC_HEADER.search(text)
    if m_head:
        block = text[m_head.end(): m_head.end() + 4096]
        # On cherche une matrice 3×3 dans les 30 prochaines lignes.
        rows, first_line = _read_numeric_matrix_after_block(block, n_rows=3, n_cols=3)
        if len(rows) == 3 and all(len(r) >= 3 for r in rows):
            # Symétrise : moyenne deux-côtés si asymétrie résiduelle légère.
            sym = [[(rows[i][j] if rows[i][j] is not None else
                     (rows[j][i] if rows[j][i] is not None else 0.0))
                    for j in range(3)] for i in range(3)]
            # Cast float-safe (peut contenir None → défaut 0).
            float_sym: list[list[float]] = []
            for r in sym:
                row_f: list[float] = []
                for v in r:
                    if v is None:
                        row_f.append(0.0)
                    elif isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
                        row_f.append(0.0)
                    else:
                        row_f.append(float(v))
                float_sym.append(row_f)
            out["epsilon_xx"] = float_sym[0][0]
            out["epsilon_yy"] = float_sym[1][1]
            out["epsilon_zz"] = float_sym[2][2]
            out["epsilon_xy"] = float_sym[0][1]
            out["epsilon_xz"] = float_sym[0][2]
            out["epsilon_yz"] = float_sym[1][2]
            finite_diag = [float_sym[i][i] for i in range(3) if float_sym[i][i] > 0]
            if finite_diag:
                # Moyenne sur les diagonales strictement positives. Un tenseur
                # pathologique (ex. ε = (12, 0, 0)) donne 12, pas 4.
                out["epsilon_average"] = float(sum(finite_diag) / len(finite_diag))
                if len(finite_diag) == 3:
                    mx, mn = max(finite_diag), min(finite_diag)
                    if mn > 0:
                        out["epsilon_anisotropy"] = float(mx / mn)
                out["refractive_index_avg"] = (
                    float(math.sqrt(out["epsilon_average"]))
                    if out["epsilon_average"] is not None
                    and out["epsilon_average"] > 0
                    else None
                )
            out["source_line"] = first_line
            out["matched_keywords"].append("epsilon_infinity_tensor_3x3")

    # 2. Header « Average dielectric constant »
    m_avg = _RE_AVERAGE.search(text)
    if m_avg:
        try:
            out["average_dielectric_constant"] = float(
                m_avg.group(1).replace("D", "E").replace("d", "e")
            )
            out.setdefault("matched_keywords", []).append(
                "average_dielectric_constant_header"
            )
        except ValueError:
            pass

    # 3. Section Born effective charges : matrice 3×3 par atome.
    m_born = _RE_BORN_HEADER.search(text)
    if m_born:
        block = text[m_born.end(): m_born.end() + 16_000]
        # Découpage par lignes « atom … » : chaque bloc suivant est lisible
        # comme une sous-bloc 1 (header) + ~3 lignes numériques (matrice 3x3).
        lines = block.splitlines()
        current_atom: Optional[dict[str, Any]] = None
        atoms: list[dict[str, Any]] = []
        max_abs_vals: list[float] = []
        i = 0
        while i < len(lines):
            ls = lines[i].strip()
            if not ls:
                i += 1
                continue
            m_atom = _RE_BORN_ATOM.match(ls)
            if m_atom:
                # Sauver l'atome précédent (si on avait accumulé des valeurs).
                if current_atom is not None and current_atom["_Z_rows"]:
                    atoms.append(_finalize_atom_block(current_atom))
                    max_abs_vals.extend(_collect_abs(current_atom))
                current_atom = {
                    "atom_index": int(m_atom.group(1)),
                    "atom_type": m_atom.group(2) or "",
                    "_Z_rows": [],
                }
                i += 1
                continue
            if current_atom is not None:
                # Born effective charges : matrice Z* 3×3 (compact 1 ligne OU
                # multiligne 3 lignes). Total cumulé ≤ 9 valeurs. Au-delà, on
                # STOPPE pour ne pas absorber le bloc suivant (ex. « Dielectric
                # constant : … » juste après, comme dans test_dielectric_born_
                # charges_basic où la matrice ε pollue _Z_rows sinon).
                _already_total = sum(
                    len(r) for r in current_atom["_Z_rows"]
                )
                if _already_total >= 9:
                    # Z* complet : on n'accumule plus pour cet atome.
                    i += 1
                    continue
                m_compact = _RE_ZSTAR_COMPACT.match(ls)
                if m_compact:
                    nums_raw = re.split(r"[\s,;]+", m_compact.group(1))
                    # FORTRAN « . » → 0.0 placeholder (cf. _read_numeric_matrix_
                    # after_block).
                    nums_raw = [
                        "0.0" if re.fullmatch(r"\.", t) else t
                        for t in nums_raw
                    ]
                    vals = [_qe_float(t) for t in nums_raw]
                    if len([v for v in vals if v is not None]) >= 6:
                        current_atom["_Z_rows"].append(vals)
                else:
                    toks = re.split(r"[\s,;]+", ls)
                    if len(toks) < 3:
                        i += 1
                        continue
                    vals = [_qe_float(t) for t in toks]
                    if any(v is not None for v in vals[:3]):
                        current_atom["_Z_rows"].append(vals)
            i += 1
        # Finalise le dernier atome.
        if current_atom is not None and current_atom["_Z_rows"]:
            atoms.append(_finalize_atom_block(current_atom))
            max_abs_vals.extend(_collect_abs(current_atom))

        # Filtre : on garde les atomes qui ont effectivement une matrice 3x3.
        valid_atoms = [a for a in atoms if isinstance(a.get("Z_star"), list)]
        if valid_atoms:
            out["born_Z_star_per_atom"] = valid_atoms
            out["born_Z_star_max_abs"] = max(max_abs_vals) if max_abs_vals else None
            out["matched_keywords"].append("born_effective_charges_3x3_per_atom")

    # 4. Refractive index explicite (rare).
    m_n = _RE_REFRACTIVE.search(text)
    if m_n:
        try:
            v = float(m_n.group(1).replace("D", "E").replace("d", "e"))
            if out["refractive_index_avg"] is None:
                out["refractive_index_avg"] = v
            out["matched_keywords"].append("refractive_index_from_log")
        except ValueError:
            pass

    # Repli : si on a une tensor + « Average … » mais pas de moyenne dérivée,
    # on utilise l'« Average » publiée.
    if out["epsilon_average"] is None and out["average_dielectric_constant"] is not None:
        out["epsilon_average"] = out["average_dielectric_constant"]
        out["matched_keywords"].append("epsilon_average_from_log_header")

    if not out["matched_keywords"]:
        out["matched_keywords"].append("no_dielectric_output_found")
    return out


def _finalize_atom_block(at: dict[str, Any]) -> dict[str, Any]:
    """Convertit ``_Z_rows`` (liste de listes ``Optional[float]``) en matrice 3×3 ``float``."""
    rows_raw = at["_Z_rows"]
    # On récupère les 9 premières valeurs numériques flottantes.
    flat: list[Optional[float]] = []
    for row in rows_raw:
        for v in row:
            if v is not None and not (isinstance(v, float) and (math.isnan(v) or math.isinf(v))):
                flat.append(float(v))
                if len([x for x in flat if x is not None]) >= 9:
                    break
        if len([x for x in flat if x is not None]) >= 9:
            break
    flat_filled: list[float] = [x if x is not None else 0.0 for x in flat][:9]
    if len(flat_filled) < 9:
        # Matrice incomplète : on relâche (KeyError plus tard attrapé caller)
        Z = None
    else:
        Z = [flat_filled[0:3], flat_filled[3:6], flat_filled[6:9]]
    return {
        "atom_index": at["atom_index"],
        "atom_type": at["atom_type"],
        "Z_star": Z,
    }


def _collect_abs(at: dict[str, Any]) -> list[float]:
    """Liste des |Z*_ij| pour un atome ayant une matrice."""
    flat = at["_Z_rows"]
    vals: list[float] = []
    for row in flat:
        for v in row:
            if v is not None and not (isinstance(v, float) and (math.isnan(v) or math.isinf(v))):
                vals.append(abs(v))
    return vals


# ----------------------------------------------------------------------------
# Parseur fichier autonome (rare ; parfois écrit comme ``dielectric_xx.dat``)
# ----------------------------------------------------------------------------

def parse_dielectric_tensor_file(path: Path) -> dict[str, Any]:
    """Lit un fichier ``.dat`` contenant une matrice 3×3 unique.

    Format : 3 lignes × 3 colonnes ; ``#`` lignes commentaires.
    """
    path = Path(path).resolve()
    out: dict[str, Any] = {
        "path": str(path),
        "matrix": None,
        "matched_keywords": [],
        "error": None,
    }
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as ex:
        out["error"] = str(ex)
        return out
    rows, first_line = _read_numeric_matrix_after_block(text, n_rows=3, n_cols=3)
    if len(rows) == 3:
        # Cast float + sym.
        out["matrix"] = [[float(r[j] or 0.0) for j in range(3)] for r in rows]
        out["source_line"] = first_line
        out["matched_keywords"].append("dielectric_tensor_dat_file")
    return out


# ----------------------------------------------------------------------------
# Orchestration
# ----------------------------------------------------------------------------

_DIELECTRIC_FILE_CANDIDATES = (
    "thermo_pw_dielectric.out",
    "epsilon_infinity.dat",
    "dielectric_tensor.dat",
)


def parse_dielectric(work_dir: Path) -> dict[str, Any]:
    """Combine ph.out + journal thermo_pw + fichiers colonne pour P5."""
    work_dir = Path(work_dir).resolve()
    out: dict[str, Any] = {
        "epsilon_xx": None,
        "epsilon_yy": None,
        "epsilon_zz": None,
        "epsilon_xy": None,
        "epsilon_xz": None,
        "epsilon_yz": None,
        "epsilon_average": None,
        "epsilon_anisotropy": None,
        "average_dielectric_constant": None,
        "born_Z_star_max_abs": None,
        "born_Z_star_per_atom": [],
        "refractive_index_avg": None,
        "source_files": [],
        "matched_keywords": [],
    }

    def _merge_parsed(parsed: dict[str, Any], rel_path: str) -> None:
        for k, v in parsed.items():
            if k in ("matched_keywords",):
                for kw in v or []:
                    if kw not in out["matched_keywords"]:
                        out["matched_keywords"].append(kw)
                continue
            if v is None or v == []:
                continue
            if k in ("born_Z_star_per_atom",):
                if not out[k]:
                    out[k] = v
            elif out.get(k) is None:
                out[k] = v
        if rel_path and rel_path not in out["source_files"]:
            out["source_files"].append(rel_path)

    # 1. ph.out — source canonique thermo_pw 7.5 (DFPT phonon, Γ).
    ph_log = work_dir / "ph.out"
    if ph_log.is_file():
        try:
            text = ph_log.read_text(encoding="utf-8", errors="replace")
        except OSError:
            text = ""
        if text:
            head = text[:500_000] if len(text) > 500_000 else text
            _merge_parsed(
                parse_ph_out_dielectric_from_text(head),
                ph_log.resolve().relative_to(work_dir).as_posix(),
            )

    # 2. Journal thermo_pw (runs legacy ou extras).
    tpw_log = work_dir / "thermo_pw_run.out"
    if tpw_log.is_file():
        try:
            text = tpw_log.read_text(encoding="utf-8", errors="replace")
        except OSError:
            text = ""
        if text:
            tail = text[-200_000:] if len(text) > 200_000 else text
            parsed = parse_dielectric_from_text(tail)
            rel = tpw_log.resolve().relative_to(work_dir).as_posix()
            _merge_parsed(parsed, rel)

    # 3. Fichier colonne autonome (epsilon_infinity.dat).
    for nm in _DIELECTRIC_FILE_CANDIDATES:
        p = work_dir / nm
        if p.is_file():
            fdata = parse_dielectric_tensor_file(p)
            if fdata.get("matrix"):
                m = fdata["matrix"]
                out["epsilon_xx"] = m[0][0]
                out["epsilon_yy"] = m[1][1]
                out["epsilon_zz"] = m[2][2]
                out["matched_keywords"].append("dielectric_tensor_dat_file")
                out["source_files"].append(
                    str(p.resolve().relative_to(work_dir).as_posix())
                )
                break

    if out["epsilon_average"] is not None and out["epsilon_average"] > 0 \
            and out["refractive_index_avg"] is None:
        try:
            out["refractive_index_avg"] = float(math.sqrt(out["epsilon_average"]))
        except ValueError:
            out["refractive_index_avg"] = None

    if out.get("epsilon_xx") is not None:
        out["matched_keywords"] = [
            k for k in out["matched_keywords"]
            if k != "no_dielectric_output_found"
        ]
    if not out["matched_keywords"] and out.get("epsilon_xx") is None:
        out["matched_keywords"].append("no_dielectric_output_found")
    return out


__all__ = [
    "parse_dielectric",
    "parse_dielectric_from_text",
    "parse_ph_out_dielectric_from_text",
    "parse_dielectric_tensor_file",
]

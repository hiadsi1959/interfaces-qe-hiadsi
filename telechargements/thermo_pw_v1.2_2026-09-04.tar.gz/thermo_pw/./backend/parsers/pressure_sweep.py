"""Parser balayage pression P (P3 opt-in) — séries ``*.el_cons_p`` / ``*.el_comp_p``."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

from parsers.elastic_t_dat_scan import (
    is_pressure_axis_dat_basename,
    parse_numeric_series_dat,
)


_PRESSURE_SERIES_GLOBS = (
    "**/anhar_files/*.el_cons_p*",
    "**/anhar_files/*.el_comp_p*",
    "**/anhar_files/*_qha_p*",
    "**/anhar_files/*_qsa_p*",
    "energy_files/*.el_cons_p*",
    "energy_files/*.el_comp_p*",
)


def find_elastic_pressure_dat(work_dir: Path) -> Optional[Path]:
    """Retourne le fichier colonne P, C_ij… le plus pertinent sous ``work_dir``."""
    wd = work_dir.resolve()
    hits: list[Path] = []
    for pattern in _PRESSURE_SERIES_GLOBS:
        for p in wd.glob(pattern):
            if not p.is_file():
                continue
            if not is_pressure_axis_dat_basename(p.name):
                continue
            hits.append(p)
    if not hits:
        return None
    hits.sort(key=lambda p: (len(p.name), str(p)))
    return hits[0]


def parse_pressure_sweep(work_dir: Path) -> dict[str, Any]:
    """Extrait une série élasticité vs P depuis les sorties thermo_pw ``*_p``."""
    out: dict[str, Any] = {
        "ok": False,
        "source_files": [],
        "dat_relpath": None,
        "p_min_kbar": None,
        "p_max_kbar": None,
        "n_points": 0,
        "columns": [],
        "C11_GPa_at_points": [],
        "bulk_modulus_GPa_at_points": [],
        "matched_keywords": [],
    }
    wd = work_dir.resolve()
    dat = find_elastic_pressure_dat(wd)
    log = wd / "thermo_pw_pressure_sweep.out"
    if log.is_file():
        out["source_files"].append(log.name)
        out["matched_keywords"].append("thermo_pw_pressure_sweep_out")
    if dat is None:
        if log.is_file() and log.stat().st_size > 200:
            out["matched_keywords"].append("pressure_log_only_no_dat")
        return out
    try:
        rel = dat.resolve().relative_to(wd).as_posix()
    except ValueError:
        rel = dat.name
    out["dat_relpath"] = rel
    out["source_files"].append(rel)
    tbl = parse_numeric_series_dat(dat)
    if tbl.get("error"):
        out["parse_error"] = tbl["error"]
        return out
    cols = list(tbl.get("columns") or [])
    rows = list(tbl.get("rows") or [])
    out["columns"] = cols
    out["n_points"] = len(rows)
    if not rows:
        return out
    pressures = [r[0] for r in rows if r]
    if pressures:
        out["p_min_kbar"] = min(pressures)
        out["p_max_kbar"] = max(pressures)
    # Colonne 2 = C11 ou B selon le fichier ; on stocke la 2e colonne numérique.
    c11_idx = 1
    for i, c in enumerate(cols):
        cl = str(c).lower()
        if "c11" in cl or cl.startswith("c_11"):
            c11_idx = i
            break
    b_idx = 1
    for i, c in enumerate(cols):
        cl = str(c).lower()
        if cl in ("b", "bulk", "b_gpa", "bulk_modulus"):
            b_idx = i
            break
    out["C11_GPa_at_points"] = [
        r[c11_idx] for r in rows if len(r) > c11_idx
    ]
    if b_idx != c11_idx:
        out["bulk_modulus_GPa_at_points"] = [
            r[b_idx] for r in rows if len(r) > b_idx
        ]
    out["ok"] = True
    out["matched_keywords"].append("pressure_elastic_series_dat")
    return out

"""Colonne « Interprétation » dans les tableaux de la fiche technique."""
from __future__ import annotations

import config as cfg
from factsheet import assemble_factsheet, render_factsheet_html, render_factsheet_md
from factsheet_ai import build_inline_interpretations, lookup_row_interpretation


def test_build_inline_interpretations_maps_eos_label(tmp_path, monkeypatch):
    from tests.test_factsheet import _make_work_dir_P2

    fr = _make_work_dir_P2(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)
    fs = assemble_factsheet(
        work_dir=fr["work_dir"],
        profile_id="P2",
        profile={"id": "P2", "name": "Thermique QHA", "what_qe": "thermo"},
        results=fr["results"],
    )
    interp = build_inline_interpretations(fs, fs.ai_insights or [])
    assert lookup_row_interpretation("V₀ (volume d'équilibre)", interp)
    assert lookup_row_interpretation("B₀ (module de compressibilité)", interp)


def test_render_factsheet_tables_have_interpretation_column(tmp_path, monkeypatch):
    from tests.test_factsheet import _make_work_dir_P2

    fr = _make_work_dir_P2(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)
    fs = assemble_factsheet(
        work_dir=fr["work_dir"],
        profile_id="P2",
        profile={"id": "P2", "name": "Thermique QHA", "what_qe": "thermo"},
        results=fr["results"],
    )
    md = render_factsheet_md(fs)
    html = render_factsheet_html(fs)
    assert "| Grandeur | Valeur | Unité | Interprétation |" in md
    assert "Volume d'équilibre" in md or "Birch" in md
    assert "<th>Interprétation</th>" in html
    assert 'class="ft-interp"' in html

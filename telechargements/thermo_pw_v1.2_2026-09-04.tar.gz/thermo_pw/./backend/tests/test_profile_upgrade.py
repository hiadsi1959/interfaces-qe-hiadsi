"""Tests enchaînement P(i) → P(i+1)."""
from __future__ import annotations

from pathlib import Path

from profile_upgrade import (
    build_upgrade_plan,
    estimate_upgrade_delta,
    ideal_upgrade_skips,
    list_upgrade_options,
    next_profile_id,
    plan_is_runnable,
)


def _fake_p2_workdir(tmp_path: Path) -> Path:
    eos = tmp_path / "1_eos_volumes"
    eos.mkdir()
    (eos / "eos_summary.json").write_text('{"volumes_bohr3":[1,2,3]}', encoding="utf-8")
    (eos / "scf_eq.in").write_text("&control/", encoding="utf-8")
    (tmp_path / "ph.out").write_text("ok", encoding="utf-8")
    (tmp_path / "fc.out").write_text("ok", encoding="utf-8")
    (tmp_path / "pw_scf_V0_for_phonon.in").write_text("&control/", encoding="utf-8")
    return tmp_path


def _fake_p1_workdir(tmp_path: Path) -> Path:
    (tmp_path / "ph.out").write_text("ok", encoding="utf-8")
    (tmp_path / "fc.out").write_text("ok", encoding="utf-8")
    (tmp_path / "pw_scf_V0_for_phonon.in").write_text("&control/", encoding="utf-8")
    (tmp_path / "scf.in").write_text("&control/", encoding="utf-8")
    return tmp_path


def test_next_profile_id():
    assert next_profile_id("P2") == "P3"
    assert next_profile_id("P5") is None


def test_p2_to_p3_full_prefix_reuse(tmp_path: Path):
    wd = _fake_p2_workdir(tmp_path)
    plan = build_upgrade_plan(
        source_profile_id="P2",
        target_profile_id="P3",
        source_job_id="abc123",
        work_dir=wd,
    )
    assert plan.skip_eos is True
    assert plan.skip_phonons is True
    assert plan_is_runnable(plan)


def test_p1_to_p2_partial_reuse(tmp_path: Path):
    wd = _fake_p1_workdir(tmp_path)
    plan = build_upgrade_plan(
        source_profile_id="P1",
        target_profile_id="P2",
        source_job_id="p1job",
        work_dir=wd,
    )
    assert plan.skip_eos is False
    assert plan.skip_phonons is True
    assert plan_is_runnable(plan)


def test_list_upgrade_options_multiple_targets(tmp_path: Path):
    wd = _fake_p2_workdir(tmp_path)
    opts = list_upgrade_options(
        source_profile_id="P2",
        source_job_id="j1",
        work_dir=wd,
        only_next=False,
    )
    pids = [o.profile_id for o in opts]
    assert "P3" in pids
    assert "P4" in pids or "P5" in pids


def test_ideal_upgrade_skips_p2_to_p3():
    skips = ideal_upgrade_skips("P2", "P3")
    assert skips["skip_eos"] is True
    assert skips["skip_phonons"] is True


def test_estimate_upgrade_delta_p2_to_p3():
    runtime_full = {
        "total_seconds": 100.0,
        "low_seconds": 80.0,
        "high_seconds": 120.0,
        "confidence": "moyenne",
        "steps": [
            {"step": "eos_grid", "seconds": 30.0},
            {"step": "ph", "seconds": 40.0},
            {"step": "thermo_pw", "seconds": 30.0},
        ],
    }
    storage_full = {
        "peak_bytes": 10_000_000_000,
        "components": [
            {"name": "1_eos_volumes", "bytes": 4_000_000_000, "kind": "scratch"},
            {"name": "chaîne phonon", "bytes": 3_000_000_000, "kind": "scratch"},
            {"name": "thermo_pw résultats", "bytes": 1_000_000_000, "kind": "résultats"},
        ],
    }
    delta = estimate_upgrade_delta(
        source_profile_id="P2",
        target_profile_id="P3",
        runtime_full=runtime_full,
        storage_full=storage_full,
    )
    assert delta is not None
    assert delta["runtime"]["total_seconds"] == 30.0
    assert delta["storage"]["peak_bytes"] == 1_000_000_000

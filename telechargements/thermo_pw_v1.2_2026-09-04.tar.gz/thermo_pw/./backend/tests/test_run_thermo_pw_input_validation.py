"""Tests for ``run_thermo_pw_mpi`` input validation — juillet 2026.

Background
----------
``run_thermo_pw_mpi`` (``backend/phonon_chain_qe.py``) is the unique entry
point for ``POST /run_thermo_pw``. La fonction héritait de
``normalize_thermo_opts`` qui FILTRAIT silencieusement les clés hors
whitelist — un utilisateur qui injectait ``lband`` (legacy / non QE) ne
voyait rien jusqu'au runtime MPI avec un ``MPI_Abort(1)`` cryptique
(« Error in routine thermo_summary (1): what not programmed » ou pire, un
crash hours-deep dans la chaîne EOS/phono sans aucun lien avec la typo).

Le nouveau helper ``validate_known_thermo_flags`` lève une ``ValueError``
claire AVANT ``_purge_before_thermo_pw_mpi`` (qui efface sinon restart/).
Ce module verrouille ce nouveau comportement + couvre les renommages
canoniques ``lband`` → ``ltherm_freq``.

Exécution
---------
* pytest : ``cd backend && python3 -m pytest tests/test_run_thermo_pw_input_validation.py -v``
* standalone : ``python3 backend/tests/test_run_thermo_pw_input_validation.py``
"""
from __future__ import annotations

import os
import re
import sys

# Rend ``backend/`` importable (le test vit dans ``backend/tests/``).
_HERE = os.path.dirname(os.path.abspath(__file__))
_BACKEND = os.path.dirname(_HERE)
if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)

import pytest  # noqa: E402

from phonon_chain_qe import (  # noqa: E402
    KNOWN_THERMO_FLAGS,
    RENAMED_THERMO_FLAGS_HINTS,
    normalize_thermo_opts,
    run_thermo_pw_mpi,
    validate_known_thermo_flags,
)


# ============================================================================
# Phase 1 — surface publique (constantes whitelist + hint map)
# ============================================================================


def test_KNOWN_THERMO_FLAGS_is_frozenset_immutable():
    """L'API publique expose une collection immuable (frozenset)."""
    from collections.abc import Set
    assert isinstance(KNOWN_THERMO_FLAGS, frozenset)
    assert isinstance(KNOWN_THERMO_FLAGS, Set)


def test_KNOWN_THERMO_FLAGS_covers_canonical_thermo_pw_7x_flags():
    """Les 8 drapeaux canoniques de ``templates/thermo_control.template``
    doivent tous être présents (lock-step avec le template).
    """
    expected = {
        "what",
        "tmin", "tmax", "deltat",
        "fildyn", "zasr",
        "ltherm_dos", "ltherm_freq",
    }
    missing = expected - set(KNOWN_THERMO_FLAGS)
    assert not missing, (
        f"KNOWN_THERMO_FLAGS manque ces drapeaux canoniques 7.x : {missing}. "
        f"Mettre à jour le test ET la constante en lock-step avec "
        f"``templates/thermo_control.template``."
    )


def test_lband_is_NOT_in_known_flags():
    """``lband`` n'existe PAS en thermo_pw 7.x (legacy / convention non QE) —
    doit rester hors whitelist pour produire la levée.
    """
    assert "lband" not in KNOWN_THERMO_FLAGS, (
        "Si 'lband' est dans KNOWN_THERMO_FLAGS, le guard ne lèvera plus — "
        "or 'lband' n'est pas un drapeau thermo_pw 7.x valide et causerait "
        "un ``MPI_Abort(1)`` runtime (cf. bug report originel). "
        "Doit rester HORS whitelist."
    )


def test_ltherm_freq_IS_in_known_flags():
    """``ltherm_freq`` est le drapeau canonique 7.x pour la sortie freq-par-mode."""
    assert "ltherm_freq" in KNOWN_THERMO_FLAGS


def test_RENAMED_HINTS_documents_lband_to_ltherm_freq():
    """Le hint ``lband`` → ``ltherm_freq`` doit toujours être documenté
    (cf. message ciblé « sortie freq-par-mode » côté UI).

    Le format est un tuple ``(canonical, phrase_extra)``: la 2e composante
    ajoute une précision sur l'intention de l'utilisateur (typiquement
    « si vous voulez la sortie freq-par-mode » pour ``lband``).
    """
    entry = RENAMED_THERMO_FLAGS_HINTS.get("lband")
    assert entry is not None, (
        "Le mapping canonique lband → ltherm_freq doit être documenté dans "
        "RENAMED_THERMO_FLAGS_HINTS pour produire le message ciblé."
    )
    # Tuple ``(canonical, phrase_extra)`` — on tolère aussi la forme legacy
    # string (forward-compat si on veut déprécier).
    if isinstance(entry, tuple):
        canonical, extra = entry
        assert canonical == "ltherm_freq", (
            f"``lband`` doit pointer vers ``ltherm_freq``, got {canonical!r}"
        )
        assert "freq-par-mode" in extra, (
            f"La phrase extra doit préciser l'intention freq-par-mode, "
            f"got {extra!r}"
        )
    else:
        assert entry == "ltherm_freq"


# ============================================================================
# Phase 2 — pure unit tests on validate_known_thermo_flags
# ============================================================================


class TestValidatePassThrough:
    """Les entrées vides / canoniques ne lèvent PAS."""

    def test_None_passes(self):
        validate_known_thermo_flags(None)  # doit passer / ne rien faire

    def test_empty_dict_passes(self):
        validate_known_thermo_flags({})  # idem

    def test_single_canonical_flag_passes(self):
        validate_known_thermo_flags({"ltherm_freq": True})

    def test_lsolve_passes(self):
        validate_known_thermo_flags({"lsolve": 3})

    def test_full_canonical_combo_passes(self):
        """Même forme que ``PROFILES['P2']['thermo_opts']`` — doit passer."""
        validate_known_thermo_flags({
            "what": "mur_lc_t",
            "tmin": 0.0,
            "tmax": 1000.0,
            "deltat": 20.0,
            "fildyn": "ph_dyn",
            "zasr": "simple",
            "ltherm_dos": True,
            "ltherm_freq": False,
        })

    def test_guard_only_validates_keys_not_values(self):
        """Le guard ne valide PAS les types (c'est le job de
        ``normalize_thermo_opts``). Les valeurs garbage pour des clés
        canoniques passent.
        """
        validate_known_thermo_flags({"what": 12345})  # int au lieu de str


class TestValidateRejectsLband:
    """Le cas central de la demande utilisateur : ``lband``."""

    def test_lband_alone_raises_with_targeted_hint(self):
        """``lband`` lève avec message ciblé mentionnant ltherm_freq."""
        with pytest.raises(ValueError) as exc_info:
            validate_known_thermo_flags({"lband": True})
        s = str(exc_info.value)
        assert "lband" in s, f"Message doit citer 'lband', got: {s!r}"
        assert "ltherm_freq" in s, (
            f"Message doit suggérer ltherm_freq comme remplaçant canonique "
            f"7.x, got: {s!r}"
        )
        assert "7.x" in s, (
            f"Message doit préciser le contexte '7.x', got: {s!r}"
        )
        assert "freq-par-mode" in s, (
            f"Message doit expliquer l'intention freq-par-mode, got: {s!r}"
        )

    def test_lband_with_other_canonical_flags_still_blocks(self):
        """Mix ``lband`` + ``ltherm_freq`` (canonique) lève quand même —
        la présence de ``lband`` seule est ambiguë, on tranche par blocage.
        """
        with pytest.raises(ValueError) as exc_info:
            validate_known_thermo_flags({
                "lband": True,
                "ltherm_freq": False,
            })
        s = str(exc_info.value)
        assert "lband" in s
        # Le hint renvoie vers ltherm_freq — peut ou peut ne pas citer ce
        # nom dans le message générique ; on vérifie au moins le nom du hint.
        assert "ltherm_freq" in s


class TestValidateRejectsAnyUnknown:
    """Le guard bloque TOUT drapeau hors whitelist (pas seulement ``lband``)."""

    def test_multiple_unknown_flags_all_listed_no_fast_fail(self):
        """Si plusieurs drapeaux sont inconnus, TOUS remontés en une passe."""
        with pytest.raises(ValueError) as exc_info:
            validate_known_thermo_flags({
                "lband": True,
                "wat": "foo",       # typo / non QE
                "tnin": 0.0,        # typo classique pour tmin
            })
        s = str(exc_info.value)
        for k in ("lband", "wat", "tnin"):
            assert k in s, f"Message doit citer {k!r}, got: {s!r}"

    def test_unknown_flag_without_hint_still_lists_it(self):
        """Pour un drapeau inconnu SANS hint (hors RENAMED_THERMO_FLAGS_HINTS),
        le message reste générique — pas de fabrication de hint.
        """
        with pytest.raises(ValueError) as exc_info:
            validate_known_thermo_flags({"wat_not_documented": True})
        s = str(exc_info.value)
        assert "wat_not_documented" in s
        assert "7.x" in s
        # Pas de magic dans le message générique :
        assert "drapeaux inconnus" in s or "drapeau inconnu" in s

    def test_typo_tnin_listed_not_silent(self):
        """Typo fréquente ``tnin`` au lieu de ``tmin`` — guard la liste
        (pas de fabrication de correctif automatique).
        """
        with pytest.raises(ValueError) as exc_info:
            validate_known_thermo_flags({"tnin": 0.0})
        s = str(exc_info.value)
        assert "tnin" in s

    def test_message_lists_known_flags_for_discovery(self):
        """Le message doit lister les drapeaux acceptés (aide l'utilisateur
        à corriger sans avoir à ouvrir le code).
        """
        with pytest.raises(ValueError) as exc_info:
            validate_known_thermo_flags({"lband": True})
        s = str(exc_info.value)
        for canon in ("what", "tmin", "tmax", "ltherm_dos", "ltherm_freq"):
            assert canon in s, (
                f"Message doit lister {canon!r} dans les drapeaux acceptés, "
                f"got: {s!r}"
            )


# ============================================================================
# Phase 3 — normalize_thermo_opts remains a silent filter (compat legacy)
# ============================================================================


def test_normalize_filters_out_lband_silently():
    """``normalize_thermo_opts`` reste un filtre typé silencieux pour les
    chemins legacy — l'avertissement strict est ailleurs.
    """
    out = normalize_thermo_opts({"lband": True, "ltherm_freq": True})
    assert "lband" not in out
    assert out["ltherm_freq"] is True


def test_normalize_types_canonical_flags_correctly():
    out = normalize_thermo_opts({
        "what": "  mur_lc_t  ",          # strip + default si vide
        "fildyn": "  ph_dyn  ",          # strip
        "zasr": "  simple  ",            # strip
        "tmin": 0.0, "tmax": 1000,        # float
        "ltherm_freq": 1,                # truthy → True
        "ltherm_dos": 0,                 # falsy  → False
    })
    assert out["what"] == "mur_lc_t"
    assert out["fildyn"] == "ph_dyn"
    assert out["zasr"] == "simple"
    assert isinstance(out["tmax"], float)
    assert out["tmax"] == 1000.0
    assert out["tmin"] == 0.0
    assert out["ltherm_freq"] is True
    assert out["ltherm_dos"] is False


def test_normalize_lsolve_as_int():
    out = normalize_thermo_opts({"lsolve": "3"})
    assert out["lsolve"] == 3


def test_normalize_returns_empty_dict_on_None_or_empty():
    assert normalize_thermo_opts(None) == {}
    assert normalize_thermo_opts({}) == {}


# ============================================================================
# Phase 4 — run_thermo_pw_mpi fail-fast on unknown flag (end-to-end)
# ============================================================================
#
# ``run_thermo_pw_mpi`` est l'unique point d'entrée de ``POST /run_thermo_pw``.
# Si le guard n'est pas appelé AVANT ``_purge_before_thermo_pw_mpi``, l'utilisateur
# verrait ``restart/`` effacé avant l'erreur. Cette phase vérifie la propriété
# end-to-end via monkeypatch — on ne lance PAS thermo_pw.x (pas de MPI réel,
# pas de QE compilé requis en CI).


class TestRunThermoPwFailFastOnUnknownFlag:
    """``run_thermo_pw_mpi`` doit lever AVANT toute purge scratch."""

    def _setup_workdir(self, tmp_path):
        """Prépare un work_dir minimaliste : pw.in présent, restart/ avec
        un sentinel utilisateur qui NE DOIT PAS être purgé."""
        (tmp_path / "pw_scf_V0_for_phonon.in").write_text(
            "! pw.in stub\n &CONTROL\n / \n", encoding="utf-8"
        )
        rd = tmp_path / "restart"
        rd.mkdir()
        sentinel = rd / "e_work_part.0"
        sentinel.write_text("user_owned_checkpoint", encoding="utf-8")
        # _temporary* testés aussi (l'autre moitié du scratch).
        tmp_dir = tmp_path / "_temporary_42"
        tmp_dir.mkdir()
        tmp_sentinel = tmp_dir / "inputpw_0.tmp"
        tmp_sentinel.write_text("user_owned_tmp", encoding="utf-8")
        return sentinel, tmp_sentinel

    def _assert_no_side_effect(self, tmp_path, sentinel, tmp_sentinel):
        """``run_thermo_pw_mpi`` ne doit avoir écrit/effacé RIEN en cas
        d'erreur de validation."""
        # 1. restart/ + sentinel toujours là.
        assert sentinel.is_file(), (
            "Faille de sécurité : _purge_before_thermo_pw_mpi a effacé "
            "le dossier restart/ avant la levée du guard. restart/ doit "
            "rester intact sur entrée invalide (fail-fast strict)."
        )
        assert sentinel.read_text(encoding="utf-8") == "user_owned_checkpoint"
        # 2. _temporary* non touchés.
        assert tmp_sentinel.is_file(), (
            "Faille : _purge_before_thermo_pw_mpi a effacé _temporary* avant "
            "la levée du guard."
        )
        assert tmp_sentinel.read_text(encoding="utf-8") == "user_owned_tmp"
        # 3. thermo_control n'a PAS été écrit.
        assert not (tmp_path / "thermo_control").exists(), (
            "Faille : write_thermo_control_minimal a tourné avant le guard "
            "— thermo_control ne doit pas exister sur entrée invalide."
        )

    def test_lband_in_thermo_opts_raises_before_purge_and_writes(
        self, tmp_path, monkeypatch,
    ):
        """Le cas central : ``lband`` dans thermo_opts lève AVANT tout."""
        sentinel, tmp_sentinel = self._setup_workdir(tmp_path)

        # Mock _purge_before_thermo_pw_mpi : si jamais appelé, le test casse
        # explicitement. Garantit fail-fast.
        monkeypatch.setattr(
            "phonon_chain_qe._purge_before_thermo_pw_mpi",
            lambda *_a, **_kw: pytest.fail(
                "_purge_before_thermo_pw_mpi ne doit PAS être appelé quand "
                "thermo_opts contient un drapeau inconnu !"
            ),
        )
        # Mock write_thermo_control_minimal : idem.
        monkeypatch.setattr(
            "phonon_chain_qe.write_thermo_control_minimal",
            lambda *_a, **_kw: pytest.fail(
                "write_thermo_control_minimal ne doit PAS être appelé quand "
                "thermo_opts contient un drapeau inconnu !"
            ),
        )

        with pytest.raises(ValueError) as exc_info:
            run_thermo_pw_mpi(
                tmp_path,
                nproc=1,
                thermo_opts={"lband": True},
            )

        # Message orienté : ``lband`` + ``ltherm_freq`` + ``7.x``.
        s = str(exc_info.value)
        assert "lband" in s
        assert "ltherm_freq" in s
        assert "7.x" in s

        # Aucune modification du work_dir.
        self._assert_no_side_effect(tmp_path, sentinel, tmp_sentinel)

    def test_unknown_flag_among_others_raises_before_purge(
        self, tmp_path, monkeypatch,
    ):
        """Variant : un drapeau inconnu caché parmi des canoniques lève
        aussi avant purge (le guard ne fast-fail pas sur le premier key).
        """
        sentinel, tmp_sentinel = self._setup_workdir(tmp_path)
        monkeypatch.setattr(
            "phonon_chain_qe._purge_before_thermo_pw_mpi",
            lambda *_a, **_kw: pytest.fail(
                "_purge_before_thermo_pw_mpi ne doit PAS être appelé !"
            ),
        )
        monkeypatch.setattr(
            "phonon_chain_qe.write_thermo_control_minimal",
            lambda *_a, **_kw: pytest.fail(
                "write_thermo_control_minimal ne doit PAS être appelé !"
            ),
        )

        with pytest.raises(ValueError) as exc_info:
            run_thermo_pw_mpi(
                tmp_path,
                nproc=1,
                thermo_opts={
                    "what": "mur_lc_t",  # canonique
                    "ltherm_dos": True,  # canonique
                    "wat_typo": "oops",  # UNKNOWN
                },
            )
        assert "wat_typo" in str(exc_info.value)
        self._assert_no_side_effect(tmp_path, sentinel, tmp_sentinel)

    def test_lband_and_ltherm_freq_mix_raises(
        self, tmp_path, monkeypatch,
    ):
        """Le mix classique : ``lband`` + ``ltherm_freq`` (l'utilisateur
        pense souvent que l'un OU l'autre marche). Doit lever — on explicite
        la priorité."""
        sentinel, tmp_sentinel = self._setup_workdir(tmp_path)
        monkeypatch.setattr(
            "phonon_chain_qe._purge_before_thermo_pw_mpi",
            lambda *_a, **_kw: pytest.fail(
                "_purge_before_thermo_pw_mpi appelé avant le guard !"
            ),
        )
        monkeypatch.setattr(
            "phonon_chain_qe.write_thermo_control_minimal",
            lambda *_a, **_kw: pytest.fail(
                "write_thermo_control_minimal appelé avant le guard !"
            ),
        )
        with pytest.raises(ValueError) as exc_info:
            run_thermo_pw_mpi(
                tmp_path,
                nproc=1,
                thermo_opts={"lband": True, "ltherm_freq": False},
            )
        assert "lband" in str(exc_info.value)
        assert "ltherm_freq" in str(exc_info.value)


class TestRunThermoPwPreservesHappyPath:
    """Anti-régression : le chemin HEUREUX appelle toujours purge + writes."""

    def test_canonical_thermo_opts_reaches_purge_and_writes(
        self, tmp_path, monkeypatch,
    ):
        """Avec thermo_opts 100% canoniques, le guard passe ET
        ``_purge_before_thermo_pw_mpi`` est appelée.
        """
        (tmp_path / "pw_scf_V0_for_phonon.in").write_text(
            "! pw.in\n", encoding="utf-8"
        )

        # Capture l'appel de purge — DOIT être called 1 fois.
        call_count = {"n": 0}

        def fake_purge(work_dir):
            call_count["n"] += 1
            return ([], True)

        monkeypatch.setattr(
            "phonon_chain_qe._purge_before_thermo_pw_mpi",
            fake_purge,
        )

        # Stub l'appel MPI pour ne PAS vraiment lancer thermo_pw.x.
        # Doit être appelé APRÈS purge et APRÈS write_thermo_control.
        event_log = []

        def fake_write_tc(work_dir, **kwargs):
            event_log.append("write_tc")
            p = work_dir / "thermo_control"
            p.write_text("! stub\n", encoding="utf-8")
            return p

        monkeypatch.setattr(
            "phonon_chain_qe.write_thermo_control_minimal",
            fake_write_tc,
        )

        # ``mur_lc_t`` est dans ``_THERMO_PW_QHA_KEYS`` — ``run_thermo_pw_mpi``
        # appelle ``ensure_ph_control_for_thermo_pw`` qui lève
        # ``FileNotFoundError`` si ni ph_control ni ph.in n'est présent.
        # Ce test NE couvre PAS cette branches — stub no-op.
        monkeypatch.setattr(
            "phonon_chain_qe.ensure_ph_control_for_thermo_pw",
            lambda *_a, **_kw: None,
        )

        def fake_run_mpi(*args, **kwargs):
            event_log.append("run_mpi")
            raise RuntimeError("STUB: MPI stopped for test")

        monkeypatch.setattr(
            "phonon_chain_qe.run_mpi_stdio_on_open_log",
            fake_run_mpi,
        )
        monkeypatch.setattr(
            "phonon_chain_qe.which_mpirun",
            lambda: "/bin/true",
        )

        with pytest.raises(RuntimeError, match="STUB"):
            run_thermo_pw_mpi(
                tmp_path,
                nproc=1,
                thermo_opts={
                    "what": "mur_lc_t",
                    "tmin": 0.0, "tmax": 1000.0, "deltat": 20.0,
                    "fildyn": "ph_dyn", "zasr": "simple",
                    "ltherm_dos": True, "ltherm_freq": False,
                },
            )

        # 1. Purge a tourné EXACTEMENT 1 fois (pas 0 = fail-fast cassé, pas 2 = double).
        assert call_count["n"] == 1, (
            f"Purge doit être appelée 1 fois sur entrée canonique, "
            f"got {call_count['n']}"
        )
        # 2. Ordre canonique respecté : write_tc AVANT run_mpi.
        assert event_log == ["write_tc", "run_mpi"], (
            f"Ordre canonique cassé (got {event_log}, attendu ['write_tc','run_mpi'])"
        )


# ============================================================================
# Phase 5 — sanity imports
# ============================================================================


def test_pipeline_module_imports_clean():
    """``phonon_chain_qe`` doit s'importer sans effet de bord inattendu
    (sanity global — pas de cycle d'import)."""
    import pipeline  # noqa: F401, WPS433
    assert hasattr(pipeline, "PipelineJob")
    assert hasattr(pipeline, "PROFILES")


# ============================================================================
# Phase 6 — Legacy alias rewrite: ``thermo`` → ``mur_lc_t`` (run_thermo_pw_mpi)
# ============================================================================
#
# watch-out bug (été 2026) : thermo_pw 7.x n'a PAS de what='thermo' dans
# ``thermo_summary`` (réponse Fortran: « what not programmed » → MPI_Abort).
# Réécriture silencieuse à l'intérieur de ``run_thermo_pw_mpi`` pour préserver
# l'UX historique des profils P2 (``PROFILES['P2']['what_qe']='thermo'``) +
# les anciens jobs sérialisés dans ``work/<mat>/pipeline_P2_*``.
# Le log_header ajoute une ligne ``# legacy_alias_rewrite: 'thermo' ->
# 'mur_lc_t' (QHA 7.x)`` que les tests ci-dessous vérifient.



class TestThermoLegacyAliasRewrite:
    """``run_thermo_pw_mpi`` doit réécrire ``what='thermo'``→``mur_lc_t``
    AVANT d'écrire le ``thermo_control`` envoyé au binaire ``thermo_pw.x`` 7.x.
    """

    def _setup_workdir(self, tmp_path):
        (tmp_path / "pw_scf_V0_for_phonon.in").write_text(
            "! pw.in\n", encoding="utf-8"
        )

    def _stub_post_rewrite(self, monkeypatch):
        """Stub les appels post-réécriture pour ne PAS vraiment lancer
        ``thermo_pw.x`` (pas de MPI réel requis)."""
        monkeypatch.setattr(
            "phonon_chain_qe.ensure_ph_control_for_thermo_pw",
            lambda *_a, **_kw: None,
        )
        monkeypatch.setattr(
            "phonon_chain_qe.run_mpi_stdio_on_open_log",
            lambda *a, **kw: (_ for _ in ()).throw(
                RuntimeError("STUB: MPI stopped for rewrite test")
            ),
        )
        monkeypatch.setattr(
            "phonon_chain_qe.which_mpirun",
            lambda: "/bin/true",
        )

    def test_thermo_what_is_rewritten_to_mur_lc_t_in_thermo_control(
        self, tmp_path, monkeypatch,
    ):
        """``what='thermo'`` doit produire un ``thermo_control what='mur_lc_t'``
        sur disque (le binaire 7.x rejette 'thermo')."""
        self._setup_workdir(tmp_path)
        self._stub_post_rewrite(monkeypatch)

        with pytest.raises(RuntimeError, match="STUB"):
            run_thermo_pw_mpi(
                tmp_path,
                nproc=1,
                thermo_opts={
                    "what": "thermo",
                    "tmin": 0.0, "tmax": 1000.0, "deltat": 50.0,
                    "fildyn": "ph_dyn", "zasr": "simple",
                    "ltherm_dos": True, "ltherm_freq": False,
                },
            )
        tc = tmp_path / "thermo_control"
        assert tc.is_file(), "thermo_control doit être écrit (réécriture OK)"
        content = tc.read_text(encoding="utf-8")
        assert "what = 'mur_lc_t'" in content, (
            f"thermo_control doit contenir what='mur_lc_t' (canonique 7.x) ; "
            f"got:\n{content}"
        )
        assert "what = 'thermo'" not in content, (
            f"thermo_control NE doit PAS contenir what='thermo' "
            f"(rejeté binaire 7.x) ; got:\n{content}"
        )
        # Regex anchor (future-proof) — la présence d'un motif ``what='thermo'``
        # en début de ligne suivi d'une virgule/fin garantit qu'on ne trippe
        # pas sur un futur champ type ``prefix='thermo_run'``.
        assert not re.search(
            r"""^\s*what\s*=\s*'thermo'\s*[,/]""", content, re.M
        ), (
            f"thermo_control NE doit PAS contenir what='thermo' en tête de "
            f"ligne namelist (canonique 7.x = 'mur_lc_t') ; got:\n{content}"
        )

    def test_thermo_rewrite_trace_lands_in_log_header(
        self, tmp_path, monkeypatch,
    ):
        """Le log_header ``# legacy_alias_rewrite: 'thermo' -> 'mur_lc_t'``
        doit être écrit en tête de ``thermo_pw_run.out`` — traçabilité
        utilisateur (ancienne valeur + cible canonique)."""
        self._setup_workdir(tmp_path)
        self._stub_post_rewrite(monkeypatch)

        with pytest.raises(RuntimeError, match="STUB"):
            run_thermo_pw_mpi(
                tmp_path, nproc=1,
                thermo_opts={
                    "what": "thermo",
                    "tmin": 0.0, "tmax": 1000.0, "deltat": 50.0,
                    "fildyn": "ph_dyn", "zasr": "simple",
                    "ltherm_dos": True,
                },
            )
        log = tmp_path / "thermo_pw_run.out"
        assert log.is_file(), (
            f"Le log ``thermo_pw_run.out`` doit être créé même sur erreur MPI."
        )
        head = log.read_text(encoding="utf-8", errors="replace")[:1000]
        assert "legacy_alias_rewrite: 'thermo' -> 'mur_lc_t'" in head, (
            f"En-tête log doit contenir la trace de réécriture ; got:\n{head}"
        )
        assert "QHA 7.x" in head, (
            f"La trace doit préciser le contexte QHA 7.x ; got:\n{head}"
        )

    def test_mur_lc_t_canonical_no_rewrite_no_trace(
        self, tmp_path, monkeypatch,
    ):
        """Anti-régression : si l'utilisateur envoie déjà ``mur_lc_t`` (canonique),
        PAS de réécriture et PAS de trace ``legacy_alias_rewrite`` dans le log
        (sinon pollution inutile des logs utilisateurs qui sont déjà sur la
        bonne valeur)."""
        self._setup_workdir(tmp_path)
        self._stub_post_rewrite(monkeypatch)

        with pytest.raises(RuntimeError, match="STUB"):
            run_thermo_pw_mpi(
                tmp_path, nproc=1,
                thermo_opts={
                    "what": "mur_lc_t",
                    "tmin": 0.0, "tmax": 1000.0, "deltat": 50.0,
                    "fildyn": "ph_dyn", "zasr": "simple",
                    "ltherm_dos": True,
                },
            )
        tc = tmp_path / "thermo_control"
        content = tc.read_text(encoding="utf-8")
        assert "what = 'mur_lc_t'" in content
        log = tmp_path / "thermo_pw_run.out"
        head = log.read_text(encoding="utf-8", errors="replace")[:1000]
        assert "legacy_alias_rewrite" not in head, (
            f"Aucune trace ``legacy_alias_rewrite`` pour valeur déjà "
            f"canonique ; got:\n{head}"
        )

    def test_legacy_alias_hint_can_be_called_directly(
        self,
    ):
        """Le rewrite expose une logique testable : on peut invoquer
        ``validate_known_thermo_flags`` séparément pour vérifier que
        ``thermo`` reste dans la whitelist (legitimate interface level key)
        tout en étant réécrit au runtime par ``run_thermo_pw_mpi``."""
        # Au niveau interface/validation : 'thermo' est une valeur légitime
        # (l'utilisateur peut la passer, c'est accepté côté API).
        validate_known_thermo_flags({"what": "thermo"})
        # Et 'mur_lc_t' aussi (canonique).
        validate_known_thermo_flags({"what": "mur_lc_t"})






# ============================================================================
# Phase 7 — Legacy alias rewriter (``elastic`` et ``mur_lc_t_elastic_constants`` → 7.x)
# ============================================================================
# Symétrie avec Phase 6 (``thermo`` → ``mur_lc_t``) et Phase 8 (``qha_lif`` → ``ph_life``).
# Ces profils ont une **branche** dans le safety-net prelude de ``run_thermo_pw_mpi`` :
#   * ``elastic`` (legacy P1) → ``scf_elastic_constants`` (T=0K)
#                              | ``elastic_constants_geo`` (si grille T)
#   * ``mur_lc_t_elastic_constants`` (legacy UI P3) → ``elastic_constants_geo`` + use_free_energy + elastic_algorithm


class TestElasticLegacyAliasRewrite:
    """``run_thermo_pw_mpi`` doit réécrire ``what='elastic'`` → 7.x canon."""

    def _setup_workdir(self, tmp_path):
        (tmp_path / "pw_scf_V0_for_phonon.in").write_text("! pw.in\n", encoding="utf-8")

    def _stub_post_rewrite(self, monkeypatch):
        monkeypatch.setattr("phonon_chain_qe.ensure_ph_control_for_thermo_pw", lambda *_a, **_kw: None)
        monkeypatch.setattr(
            "phonon_chain_qe.run_mpi_stdio_on_open_log",
            lambda *a, **kw: (_ for _ in ()).throw(RuntimeError("STUB: MPI stopped for elastic rewrite")),
        )
        monkeypatch.setattr("phonon_chain_qe.which_mpirun", lambda: "/bin/true")

    def test_elastic_no_grid_rewrites_to_scf_elastic_constants(self, tmp_path, monkeypatch):
        """Sans tmin/tmax/deltat → P1 T=0K canon ``scf_elastic_constants``."""
        self._setup_workdir(tmp_path)
        self._stub_post_rewrite(monkeypatch)
        with pytest.raises(RuntimeError, match="STUB"):
            run_thermo_pw_mpi(
                tmp_path, nproc=1,
                thermo_opts={"what": "elastic", "fildyn": "ph_dyn", "zasr": "simple", "ltherm_dos": True},
            )
        tc = tmp_path / "thermo_control"
        content = tc.read_text(encoding="utf-8")
        assert "what = 'scf_elastic_constants'" in content, (
            f"elastic sans grille → 'scf_elastic_constants' ; got:\n{content}"
        )

    def test_elastic_with_grid_rewrites_to_elastic_constants_geo(self, tmp_path, monkeypatch):
        """Avec tmin/tmax/deltat → P3 QHA grid canon ``elastic_constants_geo``."""
        self._setup_workdir(tmp_path)
        self._stub_post_rewrite(monkeypatch)
        with pytest.raises(RuntimeError, match="STUB"):
            run_thermo_pw_mpi(
                tmp_path, nproc=1,
                thermo_opts={
                    "what": "elastic",
                    "tmin": 0.0, "tmax": 1000.0, "deltat": 50.0,
                    "fildyn": "ph_dyn", "zasr": "simple", "ltherm_dos": True,
                },
            )
        tc = tmp_path / "thermo_control"
        content = tc.read_text(encoding="utf-8")
        assert "what = 'elastic_constants_geo'" in content, (
            f"elastic+grille → 'elastic_constants_geo' ; got:\n{content}"
        )

    def test_mur_lc_t_elastic_constants_rewrites_with_use_free_energy(self, tmp_path, monkeypatch):
        """Legacy UI ``mur_lc_t_elastic_constants`` → ``elastic_constants_geo`` + use_free_energy."""
        self._setup_workdir(tmp_path)
        self._stub_post_rewrite(monkeypatch)
        with pytest.raises(RuntimeError, match="STUB"):
            run_thermo_pw_mpi(
                tmp_path, nproc=1,
                thermo_opts={
                    "what": "mur_lc_t_elastic_constants",
                    "tmin": 0.0, "tmax": 1000.0, "deltat": 50.0,
                    "fildyn": "ph_dyn", "zasr": "simple", "ltherm_dos": True,
                },
            )
        tc = tmp_path / "thermo_control"
        content = tc.read_text(encoding="utf-8")
        assert "what = 'elastic_constants_geo'" in content, (
            f"mur_lc_t_elastic_constants → elastic_constants_geo ; got:\n{content}"
        )
        assert "use_free_energy = .true." in content, ("elastic_constants_geo doit activer use_free_energy=.true.")
        assert "elastic_algorithm" in content, ("elastic_constants_geo doit fixer elastic_algorithm='energy'")

    def test_elastic_no_grid_rewrite_trace_in_log_header(self, tmp_path, monkeypatch):
        """``elastic`` sans grille T doit produire la trace
        ``legacy_alias_rewrite: 'elastic' -> 'scf_elastic_constants'``
        (= canonique T=0K, profil P1) en tête du log.

        Verrouille le FORMAT de la trace (utilisateur grep pour “legacy_alias_rewrite:
        'elastic' -> 'scf_elastic_constants'” doit la trouver).
        """
        self._setup_workdir(tmp_path)
        self._stub_post_rewrite(monkeypatch)
        with pytest.raises(RuntimeError, match="STUB"):
            run_thermo_pw_mpi(
                tmp_path, nproc=1,
                thermo_opts={
                    "what": "elastic",
                    "fildyn": "ph_dyn", "zasr": "simple",
                    "ltherm_dos": True,
                },
            )
        log = tmp_path / "thermo_pw_run.out"
        head = log.read_text(encoding="utf-8", errors="replace")[:1000]
        assert "legacy_alias_rewrite: 'elastic' -> 'scf_elastic_constants'" in head, (
            f"En-tête doit contenir la trace de réécriture elastic→scf_elastic_constants ; got:\n{head}"
        )

    def test_elastic_with_grid_rewrite_trace_in_log_header(self, tmp_path, monkeypatch):
        """``elastic`` + grille T doit produire la trace
        ``legacy_alias_rewrite: 'elastic' -> 'elastic_constants_geo'``
        (= canonique QHA, profil P3) en tête du log.

        Anti-régression : si une future modif du safety-net prelude inverse
        les deux branches (T=0K et QHA), ce test casse.
        """
        self._setup_workdir(tmp_path)
        self._stub_post_rewrite(monkeypatch)
        with pytest.raises(RuntimeError, match="STUB"):
            run_thermo_pw_mpi(
                tmp_path, nproc=1,
                thermo_opts={
                    "what": "elastic",
                    "tmin": 0.0, "tmax": 1000.0, "deltat": 50.0,
                    "fildyn": "ph_dyn", "zasr": "simple",
                    "ltherm_dos": True,
                },
            )
        log = tmp_path / "thermo_pw_run.out"
        head = log.read_text(encoding="utf-8", errors="replace")[:1000]
        assert "legacy_alias_rewrite: 'elastic' -> 'elastic_constants_geo'" in head, (
            f"En-tête doit contenir la trace de réécriture elastic→elastic_constants_geo ; got:\n{head}"
        )


# ============================================================================
# Phase 8 — Legacy alias rewriter (``qha_lif`` → ``ph_life``)
# ============================================================================
# Symétrie P2 : ``qha_lif`` (legacy UI/API avant juin 2026) → ``ph_life`` canonique 7.x.
# BUGFIX été 2026 : avant cette branche, _THERMO_PW_QHA_KEYS whitelistait ``qha_lif``
# mais ``run_thermo_pw_mpi`` ne le réécrivait pas — les anciens jobs P4 crasheraient
# avec ``what not programmed`` exactement comme P2 ``thermo``.


class TestQhaLifLegacyAliasRewrite:
    """``run_thermo_pw_mpi`` doit réécrire ``what='qha_lif'`` → ``ph_life``."""

    def _setup_workdir(self, tmp_path):
        (tmp_path / "pw_scf_V0_for_phonon.in").write_text("! pw.in\n", encoding="utf-8")

    def _stub_post_rewrite(self, monkeypatch):
        monkeypatch.setattr("phonon_chain_qe.ensure_ph_control_for_thermo_pw", lambda *_a, **_kw: None)
        monkeypatch.setattr(
            "phonon_chain_qe.run_mpi_stdio_on_open_log",
            lambda *a, **kw: (_ for _ in ()).throw(RuntimeError("STUB: MPI stopped for qha_lif rewrite")),
        )
        monkeypatch.setattr("phonon_chain_qe.which_mpirun", lambda: "/bin/true")

    def test_qha_lif_what_rewrites_to_ph_life_in_thermo_control(self, tmp_path, monkeypatch):
        self._setup_workdir(tmp_path)
        self._stub_post_rewrite(monkeypatch)
        with pytest.raises(RuntimeError, match="STUB"):
            run_thermo_pw_mpi(
                tmp_path, nproc=1,
                thermo_opts={
                    "what": "qha_lif", "tmin": 0.0, "tmax": 1000.0, "deltat": 50.0,
                    "fildyn": "ph_dyn", "zasr": "simple", "ltherm_dos": False,
                },
            )
        tc = tmp_path / "thermo_control"
        content = tc.read_text(encoding="utf-8")
        assert "what = 'ph_life'" in content, (
            f"qha_lif doit être réécrit en 'ph_life' ; got:\n{content}"
        )
        assert not re.search(
            r"""^\s*what\s*=\s*'qha_lif'\s*[,/]""", content, re.M
        ), (
            f"thermo_control NE doit PAS contenir qha_lif en tête namelist (canonique 7.x = 'ph_life') ; got:\n{content}"
        )

    def test_qha_lif_rewrite_trace_lands_in_log_header(self, tmp_path, monkeypatch):
        self._setup_workdir(tmp_path)
        self._stub_post_rewrite(monkeypatch)
        with pytest.raises(RuntimeError, match="STUB"):
            run_thermo_pw_mpi(
                tmp_path, nproc=1,
                thermo_opts={
                    "what": "qha_lif", "tmin": 0.0, "tmax": 1000.0, "deltat": 50.0,
                    "fildyn": "ph_dyn", "zasr": "simple", "ltherm_dos": False,
                },
            )
        log = tmp_path / "thermo_pw_run.out"
        head = log.read_text(encoding="utf-8", errors="replace")[:1000]
        assert "legacy_alias_rewrite: 'qha_lif' -> 'ph_life'" in head, (
            f"En-tête doit contenir la trace de réécriture ; got:\n{head}"
        )

    def test_ph_life_canonical_no_rewrite_no_trace(self, tmp_path, monkeypatch):
        """Anti-régression : si l'utilisateur envoie déjà ``ph_life``, PAS de trace."""
        self._setup_workdir(tmp_path)
        self._stub_post_rewrite(monkeypatch)
        with pytest.raises(RuntimeError, match="STUB"):
            run_thermo_pw_mpi(
                tmp_path, nproc=1,
                thermo_opts={
                    "what": "ph_life", "tmin": 0.0, "tmax": 1000.0, "deltat": 50.0,
                    "fildyn": "ph_dyn", "zasr": "simple", "ltherm_dos": False,
                },
            )
        log = tmp_path / "thermo_pw_run.out"
        head = log.read_text(encoding="utf-8", errors="replace")[:1000]
        assert "legacy_alias_rewrite" not in head, (
            f"Aucune trace alias_rewrite pour valeur déjà canonique ; got:\n{head}"
        )


# ============================================================================
# Phase 9 — Legacy alias rewriter (``piezoelectric_tensor`` → ``scf_piezoelectric_tensor``)
# ============================================================================


class TestPiezoLegacyAliasRewrite:
    """``run_thermo_pw_mpi`` réécrit ``piezoelectric_tensor`` pour thermo_pw 7.5."""

    def _setup_workdir(self, tmp_path):
        (tmp_path / "pw_scf_V0_for_phonon.in").write_text("! pw.in\n", encoding="utf-8")

    def _stub_post_rewrite(self, monkeypatch):
        monkeypatch.setattr(
            "phonon_chain_qe.ensure_ph_control_for_thermo_pw",
            lambda *_a, **_kw: None,
        )
        monkeypatch.setattr(
            "phonon_chain_qe.run_mpi_stdio_on_open_log",
            lambda *a, **kw: (_ for _ in ()).throw(
                RuntimeError("STUB: MPI stopped for piezo rewrite")
            ),
        )
        monkeypatch.setattr("phonon_chain_qe.which_mpirun", lambda: "/bin/true")

    def test_piezo_rewrites_to_scf_piezoelectric_tensor_in_thermo_control(
        self, tmp_path, monkeypatch,
    ):
        self._setup_workdir(tmp_path)
        self._stub_post_rewrite(monkeypatch)
        with pytest.raises(RuntimeError, match="STUB"):
            run_thermo_pw_mpi(
                tmp_path,
                nproc=1,
                thermo_opts={
                    "what": "piezoelectric_tensor",
                    "fildyn": "ph_dyn",
                    "zasr": "simple",
                    "ltherm_dos": False,
                    "ltherm_freq": False,
                },
            )
        content = (tmp_path / "thermo_control").read_text(encoding="utf-8")
        assert "what = 'scf_piezoelectric_tensor'" in content, (
            f"piezoelectric_tensor → scf_piezoelectric_tensor attendu ; got:\n{content}"
        )


# ============================================================================
# Phase 9 — OOM mitigation regression (helper contract + reference check)
# ============================================================================
# Symptôme été 2026 : P1 Si nproc=4 tué par SIGTERM dans ``cegterg``
# (c_bands iterative diag) à cause du heap OpenMP per-rank (chaque rang MPI
# spawnait autant de threads OMP que de CPU → multiplication du heap, déclenchant
# SIGTERM du cgroup memory.max). Mitigation : helper ``_safe_qe_env`` dans
# ``backend/qe_subprocess.py`` qui pose ``OMP_NUM_THREADS='1'`` par défaut
# sauf override caller.
#
# Ces tests verrouillent LE CONTRAT du helper (vu, reusable, refactor-survivable)
# + une cheap-reference check qui garantit que le helper est branché aux deux
# launchers (run_qe + run_mpi_stdio_on_open_log). Sinon un futur refactor
# pourrait débrancher le helper d'un des deux sites et les tests functionnels
# du helper continueraient à passer (faux sentiment de sécurité).


@pytest.mark.parametrize(
    "launcher_name",
    ["run_qe", "run_mpi_stdio_on_open_log"],
)
def test_safe_qe_env_is_referenced_from_subprocess_launchers(launcher_name):
    """Verrouille : ``_safe_qe_env`` est appelé par les DEUX launchers
    (run_qe ET run_mpi_stdio_on_open_log). Empêche un futur refactor de
    décoller le helper d'un des deux sites (sinon mitigation OOM disparaît
    silencieusement et la couverture contract tests du helper passent en
    vert alors qu'elles ne couvrent plus le path réel).
    """
    import inspect
    import qe_subprocess

    fn = getattr(qe_subprocess, launcher_name)
    src = inspect.getsource(fn)
    assert "_safe_qe_env" in src, (
        f"{launcher_name} doit référencer _safe_qe_env (helper d'injection OMP=1) ; "
        f"{launcher_name} doit referencer _safe_qe_env (helper OOM mitigation). "

        f"helper absent du body de {launcher_name} -> mitigation OOM debranchee."

    )


def test_safe_qe_env_applies_omp_default_when_caller_passes_none(monkeypatch):
    """``_safe_qe_env(None)`` doit poser ``OMP_NUM_THREADS='1'``."""
    import qe_subprocess

    monkeypatch.delenv("OMP_NUM_THREADS", raising=False)
    env = qe_subprocess._safe_qe_env(None)
    assert env.get("OMP_NUM_THREADS") == "1", (
        f"_safe_qe_env(None) doit retourner OMP_NUM_THREADS='1' comme "
        f"mitigation OOM. got: env.get('OMP_NUM_THREADS')={env.get('OMP_NUM_THREADS')!r}"
    )


def test_safe_qe_env_caller_override_wins_over_default(monkeypatch):
    """Caller passe ``OMP_NUM_THREADS='8'`` → '8' doit gagner sur '1'."""
    import qe_subprocess

    monkeypatch.delenv("OMP_NUM_THREADS", raising=False)
    env = qe_subprocess._safe_qe_env({"OMP_NUM_THREADS": "8"})
    assert env.get("OMP_NUM_THREADS") == "8", (
        f"Sémantique d'override cassée : caller env= doit gagner sur OMP=1. "
        f"got: env.get('OMP_NUM_THREADS')={env.get('OMP_NUM_THREADS')!r}"
    )


def test_safe_qe_env_caller_passes_empty_dict_still_default_1(monkeypatch):
    """``_safe_qe_env({})`` (dict vide) doit retourner OMP=1 — couvre le
    path ``**(env or {})`` quand env={} (pas None).
    """
    import qe_subprocess

    monkeypatch.delenv("OMP_NUM_THREADS", raising=False)
    env = qe_subprocess._safe_qe_env({})
    assert env.get("OMP_NUM_THREADS") == "1"


def test_safe_qe_env_does_not_drop_other_os_environ_keys(monkeypatch):
    """Le helper doit préserver le reste du ``os.environ`` (PATH, HOME, etc.) — pas casser la propagation de variables système cruciales."""
    import qe_subprocess

    monkeypatch.delenv("OMP_NUM_THREADS", raising=False)
    monkeypatch.setenv("THERMO_PW_TEST_PROBE_KEY", "set-by-test")
    env = qe_subprocess._safe_qe_env(None)
    assert env.get("THERMO_PW_TEST_PROBE_KEY") == "set-by-test", (
        f"_safe_qe_env doit préserver les autres clés de os.environ. "
        f"got: env.get('THERMO_PW_TEST_PROBE_KEY')={env.get('THERMO_PW_TEST_PROBE_KEY')!r}"
    )
    assert env.get("OMP_NUM_THREADS") == "1"


def test_safe_qe_env_filters_none_values_in_user_env(monkeypatch):
    """Si user_env passe ``None`` comme valeur (e.g. ``env={"OMP_NUM_THREADS": None}``
    pour demander la levée d'override), le helper NE DOIT PAS écrire ``None``
    littéralement — sinon le sous-process reçoit ``OMP_NUM_THREADS=None`` (invalide).
    Sémantique : valeur ``None`` dans user_env = « touche pas à cette clé ».

    Cas concret testé : shell OMP=4 + user_env={"OMP_NUM_THREADS": None}
    → doit préserver 4 (pas None, pas 1).
    """
    import qe_subprocess

    monkeypatch.setenv("OMP_NUM_THREADS", "4")
    env = qe_subprocess._safe_qe_env({"OMP_NUM_THREADS": None})
    assert env.get("OMP_NUM_THREADS") == "4", (
        f"None dans user_env doit signifier « touche pas à cette clé » — "
        f"préserver os.environ. got: env.get('OMP_NUM_THREADS')={env.get('OMP_NUM_THREADS')!r}"
    )
    # Et un autre None sur une clé arbitraire : doit être entièrement écarté
    monkeypatch.delenv("OMP_NUM_THREADS", raising=False)
    env2 = qe_subprocess._safe_qe_env({"MY_CUSTOM_VAR": None, "MY_OTHER": "set"})
    assert "MY_CUSTOM_VAR" not in env2, (
        f"Une clé user_env=None ne doit pas polluer env (defensive filter). "
        f"got: env2={env2!r}"
    )
    assert env2.get("MY_OTHER") == "set", (
        f"Une clé user_env non-None doit toujours être posée. got: env2={env2!r}"
    )


if __name__ == "__main__":
    """Émule pytest.main() minimaliste — utile pour debug local rapide.

    Usage : ``python3 backend/tests/test_run_thermo_pw_input_validation.py``
    Sortie : liste les tests par nom + OK/FAIL, exit 0 si tous OK, 1 sinon.

    NB : seuls les tests SANS fixtures arrivent ici ; pour la couverture
    complète, exécuter pytest.
    """
    import sys
    import inspect
    fns = []
    for name, obj in sorted(globals().items()):
        if not callable(obj) or not name.startswith("test_"):
            continue
        sig = inspect.signature(obj)
        params = [p for p in sig.parameters.keys() if p != "self"]
        if params:
            # A besoin de fixtures (pytest-only).
            print(f"SKIP  {name}  (needs pytest fixtures)")
            continue
        fns.append((name, obj))
    fails = []
    for name, fn in fns:
        try:
            fn()
        except Exception as ex:  # noqa: BLE001
            fails.append(f"FAIL  {name}  → {type(ex).__name__}: {ex}")
        else:
            print(f"PASS  {name}")
    if fails:
        print()
        for line in fails:
            print(line)
        sys.exit(1)
    print(f"\n[OK] {len(fns)} standalone tests passed (others need pytest).")
    sys.exit(0)

"""Tests unitaires pour ``backend/thermo_what_catalog`` (P5 extras).

Couvre :
  * Catalogue complet et invariants (5 entrées, nom/label/tooltip non-vides).
  * ``expand_extra_whats`` : string simple, CSV, list, doublons, entrées
    hors-catalogue filtrées.
  * ``validation_warnings`` : spin-polarisé / isolant / non-centrosymétrique.
  * ``default_extra_whats_for_p5`` : renvoie uniquement ``plot_bz``.
  * ``list_all_p5_extras`` : tri stable.

Exécution : ``cd backend && python -m pytest tests/test_thermo_what_catalog.py -v``.
"""
from __future__ import annotations

import os
import sys

# Permet d'importer ``thermo_what_catalog`` sans package __init__ lourd.
_HERE = os.path.dirname(os.path.abspath(__file__))
_BACKEND = os.path.dirname(_HERE)
if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)

import pytest

import thermo_what_catalog as cat


# ----------------------------------------------------------------------------
# Catalogue
# ----------------------------------------------------------------------------


def test_catalog_has_four_entries():
    """Quatre ``what=`` extras P5 (ε∞ = extraction ph.out, hors catalogue)."""
    assert set(cat.WHAT_CATALOG.keys()) == {
        "piezoelectric_tensor",
        "magnetic_susceptibility",
        "magnetoelectric_tensor",
        "plot_bz",
    }


@pytest.mark.parametrize("what", sorted(cat.WHAT_CATALOG.keys()))
def test_catalog_entry_invariants(what):
    e = cat.WHAT_CATALOG[what]
    assert e.what == what.lower()
    assert e.label and e.label.strip(), f"label vide pour {what}"
    assert e.tooltip and e.tooltip.strip(), f"tooltip vide pour {what}"
    assert e.log_suffix and e.log_suffix.strip(), f"log_suffix vide pour {what}"
    # Pas de what= QHA dans les extras P5.
    assert e.needs_phonons is False


def test_magnetic_extras_require_spin():
    """magnetic_susceptibility ET magnetoelectric_tensor exigent nspin=2."""
    assert cat.WHAT_CATALOG["magnetic_susceptibility"].needs_spin_polarized is True
    assert cat.WHAT_CATALOG["magnetoelectric_tensor"].needs_spin_polarized is True
    assert cat.WHAT_CATALOG["plot_bz"].needs_spin_polarized is False


def test_piezoelectric_requires_insulating_and_non_centrosymmetric():
    e = cat.WHAT_CATALOG["piezoelectric_tensor"]
    assert e.needs_insulating is True
    assert e.needs_non_centrosymmetric is True


def test_plot_bz_artifacts():
    """plot_bz écrit BZ_plot.ps.gz + BZ.txt — pitfall connus de thermo_pw."""
    assert "BZ_plot.ps.gz" in cat.WHAT_CATALOG["plot_bz"].expected_outputs
    assert "BZ.txt" in cat.WHAT_CATALOG["plot_bz"].expected_outputs


# ----------------------------------------------------------------------------
# expand_extra_whats
# ----------------------------------------------------------------------------


def test_expand_none_or_empty_returns_empty():
    assert cat.expand_extra_whats(None) == []
    assert cat.expand_extra_whats("") == []
    assert cat.expand_extra_whats([]) == []
    assert cat.expand_extra_whats("") == []


def test_expand_single_string():
    assert cat.expand_extra_whats("plot_bz") == ["plot_bz"]


def test_expand_csv_string_is_deduped():
    out = cat.expand_extra_whats("plot_bz,plot_bz,piezoelectric_tensor")
    assert out == ["plot_bz", "piezoelectric_tensor"]


def test_expand_list_dedupes_and_preserves_order():
    raw = ["piezoelectric_tensor", "plot_bz", "plot_bz"]
    assert cat.expand_extra_whats(raw) == ["piezoelectric_tensor", "plot_bz"]


def test_expand_filters_unknown_entries():
    """Les whats hors-catalogue sont silencieusement filtrés (sécurité API)."""
    out = cat.expand_extra_whats(["plot_bz", "bogus_what", "another_bogus"])
    assert out == ["plot_bz"]


def test_expand_strips_quotes_and_whitespace():
    """Tolère les apostrophes et espaces — typique d'une sérialisation JSON sale."""
    out = cat.expand_extra_whats("'plot_bz' , \"piezoelectric_tensor\"")
    assert out == ["plot_bz", "piezoelectric_tensor"]


# ----------------------------------------------------------------------------
# default_extra_whats_for_p5
# ----------------------------------------------------------------------------


def test_default_only_plot_bz():
    assert cat.default_extra_whats_for_p5() == ["plot_bz"]


# ----------------------------------------------------------------------------
# get_catalog_entry
# ----------------------------------------------------------------------------


def test_get_catalog_entry_normalises():
    assert cat.get_catalog_entry("PLOT_BZ") is not None
    assert cat.get_catalog_entry("'plot_bz'") is not None
    assert cat.get_catalog_entry("  plot_bz  ") is not None
    assert cat.get_catalog_entry("nonexistent") is None
    assert cat.get_catalog_entry(None) is None
    assert cat.get_catalog_entry("") is None


# ----------------------------------------------------------------------------
# validation_warnings
# ----------------------------------------------------------------------------


def test_warnings_empty_when_no_extras():
    assert cat.validation_warnings([], scf_has_spin_polarized=False) == []


def test_warning_on_spin_when_scf_unpolarised():
    out = cat.validation_warnings(["magnetic_susceptibility"], scf_has_spin_polarized=False)
    assert len(out) == 1
    assert "spin-polarisé" in out[0]
    assert "magnetic_susceptibility" in out[0]


def test_no_spin_warning_when_scf_already_polarised():
    out = cat.validation_warnings(
        ["magnetic_susceptibility"], scf_has_spin_polarized=True
    )
    assert out == []


def test_warning_on_metallic_gap_for_piezo():
    out = cat.validation_warnings(
        ["piezoelectric_tensor"],
        scf_has_spin_polarized=False,
        band_gap_eV=0.0,
    )
    assert len(out) == 1
    assert "piezoelectric_tensor" in out[0]
    assert "isolant" in out[0]


def test_no_warning_for_large_gap():
    out = cat.validation_warnings(
        ["piezoelectric_tensor"],
        scf_has_spin_polarized=False,
        band_gap_eV=2.5,
    )
    assert out == []


def test_warning_for_centrosymmetric_piezo():
    out = cat.validation_warnings(
        ["piezoelectric_tensor"],
        scf_has_spin_polarized=False,
        spacegroup_is_centrosymmetric=True,
    )
    assert len(out) == 1
    assert "centrosymétrique" in out[0]


def test_multiple_warnings_at_once():
    """piezo + magnetic : spin + isolant + non-centrosymétrique.

    Note : une même ``what=`` peut produirePLUSIEURS messages si elle cumule
    plusieurs prérequis non-remplis (ex. ``piezoelectric_tensor`` isolé ET
    non-centrosymétrique). On expose chaque problème séparément plutôt que
    de tout fusionner dans une ligne unique — plus diagnostiquable pour
    l'utilisateur.
    """
    out = cat.validation_warnings(
        ["piezoelectric_tensor", "magnetic_susceptibility"],
        scf_has_spin_polarized=False,
        band_gap_eV=0.0,
        spacegroup_is_centrosymmetric=True,
    )
    # 3 lignes attendues : 1 isolant (piezo), 1 centrosymétrique (piezo),
    # 1 spin-polarisé (magnetic).
    assert len(out) == 3
    piezo_insul = next(m for m in out if "piezoelectric_tensor" in m and "isolant" in m)
    piezo_centro = next(m for m in out if "piezoelectric_tensor" in m and "centrosymétrique" in m)
    mag_spin = next(m for m in out if "magnetic_susceptibility" in m)
    assert "isolant" in piezo_insul
    assert "centrosymétrique" in piezo_centro
    assert "spin-polarisé" in mag_spin


def test_unknown_what_silently_skipped_in_warnings():
    """Les whats hors-catalogue ne génèrent pas de warning (juste ignorés)."""
    out = cat.validation_warnings(
        ["plot_bz", "unknown_what"],
        scf_has_spin_polarized=False,
    )
    # plot_bz: pas de warning. unknown_what: ignoré (n'existe pas).
    assert out == []

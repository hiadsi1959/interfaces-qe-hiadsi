"""resolve_template ne doit pas sortir du dossier matériau."""
from __future__ import annotations

from pathlib import Path

import material_inputs as mi


def test_resolve_template_rejects_parent_path(tmp_path, monkeypatch):
    mat = tmp_path / "inputs" / "Si"
    mat.mkdir(parents=True)
    (mat / "scf.in").write_text("&control\n/\n", encoding="utf-8")
    outside = tmp_path / "secret.in"
    outside.write_text("&control\n/\n", encoding="utf-8")
    monkeypatch.setattr(mi.cfg, "INPUTS_DIR", tmp_path / "inputs")
    monkeypatch.setattr(mi, "extra_inputs_roots", lambda: [])
    assert mi.resolve_template("Si", "scf.in") is not None
    assert mi.resolve_template("Si", "../secret.in") is None
    assert mi.resolve_template("Si", "..\\secret.in") is None
    assert mi.resolve_template("Si", "/etc/passwd") is None

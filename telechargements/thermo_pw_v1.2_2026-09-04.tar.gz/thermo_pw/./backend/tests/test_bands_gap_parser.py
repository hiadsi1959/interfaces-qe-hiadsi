"""Régression — parse_bands_gap sur format QE bands.dat / bands.dat.gnu (P1..P5)."""
from __future__ import annotations

from pathlib import Path

import pytest

from electronic_props import (
    parse_bands_gap,
    parse_nscf_fermi,
    refresh_band_gap_properties,
)
from pipeline import PROFILES

ALL_PROFILE_IDS = tuple(sorted(PROFILES.keys()))


@pytest.mark.parametrize("profile_id", ALL_PROFILE_IDS)
def test_all_profiles_use_shared_band_gap_parser(profile_id: str) -> None:
    """P1..P5 : même chaîne ichamp=3 → même ``parse_bands_gap`` centralisé."""
    p = PROFILES[profile_id]
    assert p.get("properties_enabled") is True
    assert int(p.get("properties_ichamp", 0)) >= 3
    keys = {
        m.get("key")
        for m in (p.get("expected_results") or {}).get("metrics") or []
        if m.get("key")
    }
    assert "properties.band_gap_eV" in keys
    assert "properties.vbm_eV" in keys
    assert "properties.cbm_eV" in keys


def test_refresh_band_gap_fixes_stale_inflated_marker(tmp_path: Path) -> None:
    """Marqueur JSON avec gap gonflé (bug parseur) → refresh corrige."""
    gnu = (
        "    0.0000    6.1944\n    0.0250    6.1944\n    0.0500    6.1944\n"
        "    0.0750    6.1944\n    0.1000    6.1944\n"
    )
    for b in range(16):
        block = gnu if b < 3 else gnu.replace("6.1944", "6.7818", 1)
        (tmp_path / f"_b{b}.tmp").write_text(block, encoding="utf-8")
    # bands.dat.gnu : une bande par bloc (format QE)
    lines: list[str] = []
    for b in range(3):
        for ln in gnu.strip().splitlines():
            parts = ln.split()
            lines.append(f"    {parts[0]}   {parts[1]}")
        lines.append("")
    for b in range(3, 16):
        for ln in gnu.strip().splitlines():
            parts = ln.split()
            e = "6.7818" if float(parts[0]) > 0.02 else parts[1]
            lines.append(f"    {parts[0]}   {e}")
        lines.append("")
    (tmp_path / "bands.dat.gnu").write_text("\n".join(lines), encoding="utf-8")
    stale = refresh_band_gap_properties(
        tmp_path, fermi_eV=6.2473, stored_gap=10.636, force=False
    )
    assert stale["band_gap_eV"] == pytest.approx(0.5874, abs=0.02)
    assert stale["cbm_eV"] == pytest.approx(6.7818, abs=0.01)
    # Déjà à jour → pas de re-écriture
    assert refresh_band_gap_properties(
        tmp_path, fermi_eV=6.2473, stored_gap=stale["band_gap_eV"], force=False
    ) == {}


def test_si_p5_gap_from_real_work_dir():
    wd = Path("/home/hiadsi/thermo_pw/work/Si/pipeline_P5_1787311705_c49511")
    if not (wd / "bands.dat.gnu").is_file():
        return
    fermi = parse_nscf_fermi(wd)
    gp = parse_bands_gap(wd, fermi_eV=fermi)
    assert fermi is not None
    assert gp["gap_eV"] is not None
    # Si PBE : gap indirect ~0,5–0,7 eV — pas ~10 eV (bug parseur naïf).
    assert gp["gap_eV"] < 1.5, gp
    assert gp["gap_eV"] > 0.2, gp
    assert gp["type"] == "semiconductor"
    assert gp["direct"] is False


def test_bands_dat_raw_format_not_confused_with_k(tmp_path: Path):
    """Format QE : ligne k (3 floats) puis lignes d'énergies seules."""
    (tmp_path / "bands.dat").write_text(
        "&plot nbnd=  4, nks=   2 /\n"
        "            0.000000  0.000000  0.000000\n"
        "   -5.735    6.226    6.226    8.787\n"
        "            0.500000  0.500000  0.500000\n"
        "    6.150    6.782    9.100   12.000\n",
        encoding="utf-8",
    )
    gp = parse_bands_gap(tmp_path, fermi_eV=6.25)
    assert gp["gap_eV"] is not None
    assert 0.4 < gp["gap_eV"] < 0.7
    assert gp["cbm_eV"] == 6.782

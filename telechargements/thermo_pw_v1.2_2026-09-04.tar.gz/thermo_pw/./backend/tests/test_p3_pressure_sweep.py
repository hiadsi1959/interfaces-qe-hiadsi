"""Tests balayage pression P3 (opt-in)."""
from __future__ import annotations

from pathlib import Path

from phonon_chain_qe import KNOWN_THERMO_FLAGS, write_thermo_control_minimal
from parsers.elastic_t_dat_scan import is_pressure_axis_dat_basename
from parsers.pressure_sweep import find_elastic_pressure_dat, parse_pressure_sweep


def test_pressure_flags_in_known_thermo_flags():
    for k in ("pmin", "pmax", "deltap", "pressure", "lmurn", "npress_plot"):
        assert k in KNOWN_THERMO_FLAGS


def test_write_thermo_control_emits_pressure_block(tmp_path: Path):
    write_thermo_control_minimal(
        tmp_path,
        what="mur_lc",
        pmin=0.0,
        pmax=50.0,
        deltap=5.0,
        pressure=0.0,
        lmurn=True,
        ltherm_dos=False,
        ltherm_freq=False,
        tmin=None,
        tmax=None,
        deltat=None,
    )
    text = (tmp_path / "thermo_control").read_text(encoding="utf-8")
    assert "what = 'mur_lc'" in text
    assert "pmin = 0.0d0" in text
    assert "pmax = 50.0d0" in text
    assert "deltap = 5.0d0" in text
    assert "lmurn = .true." in text
    assert "tmin" not in text


def test_is_pressure_axis_dat_basename():
    assert is_pressure_axis_dat_basename("Si.el_cons_p")
    assert is_pressure_axis_dat_basename("foo.el_comp_p.dat")
    assert not is_pressure_axis_dat_basename("Si.el_cons_qha")


def test_parse_pressure_sweep_from_anhar_file(tmp_path: Path):
    anhar = tmp_path / "anhar_files"
    anhar.mkdir()
    dat = anhar / "Si.el_cons_p"
    dat.write_text(
        "# P kbar  C11 GPa  B GPa\n"
        "0.0  150.0  98.0\n"
        "5.0  152.0  99.0\n"
        "10.0 154.0  100.0\n",
        encoding="utf-8",
    )
    found = find_elastic_pressure_dat(tmp_path)
    assert found == dat
    out = parse_pressure_sweep(tmp_path)
    assert out["ok"] is True
    assert out["n_points"] == 3
    assert out["p_min_kbar"] == 0.0
    assert out["p_max_kbar"] == 10.0


def test_pipeline_job_p3_pressure_default_off():
    from pipeline import PipelineJob

    job = PipelineJob(
        material_id="Si",
        profile_id="P3",
        scf_in_basename="scf.in",
        nproc=1,
    )
    assert job.p3_pressure_sweep_opt_in is False

    job_on = PipelineJob(
        material_id="Si",
        profile_id="P3",
        scf_in_basename="scf.in",
        nproc=1,
        p3_pressure_sweep_opt_in=True,
    )
    assert job_on.p3_pressure_sweep_opt_in is True

    job_p2 = PipelineJob(
        material_id="Si",
        profile_id="P2",
        scf_in_basename="scf.in",
        nproc=1,
        p3_pressure_sweep_opt_in=True,
    )
    assert job_p2.p3_pressure_sweep_opt_in is False

"""Tests export ESPEI / CALPHAD (opt-in P2)."""
from __future__ import annotations

import json
from pathlib import Path

from espei_export import export_espei_bundle, parse_species_and_nat


def _write_minimal_p2_work(tmp_path: Path) -> None:
    (tmp_path / "scf.in").write_text(
        "&control\n"
        "  calculation='scf'\n"
        "  nat=2\n"
        "/\n"
        "ATOMIC_SPECIES\n"
        "  Si  28.086  Si.pbe-n-rrkjus_psl.1.0.0.UPF\n"
        "ATOMIC_POSITIONS crystal\n"
        "  Si  0 0 0\n"
        "  Si  0.25 0.25 0.25\n"
        "K_POINTS automatic\n"
        "  8 8 8 0 0 0\n",
        encoding="utf-8",
    )
    therm_dir = tmp_path / "therm_files"
    therm_dir.mkdir()
    (therm_dir / "output_therm.dat.g0").write_text(
        "# ZPE = 0.010 Ry\n"
        "0.0   -10.0  -10.0  0.001  0.0001\n"
        "50.0  -10.1  -10.05 0.002  0.0002\n"
        "100.0 -10.2  -10.10 0.003  0.0003\n"
        "300.0 -10.5  -10.40 0.005  0.0005\n",
        encoding="utf-8",
    )


def test_parse_species_and_nat(tmp_path: Path):
    _write_minimal_p2_work(tmp_path)
    species, nat = parse_species_and_nat(tmp_path)
    assert species == ["SI"]
    assert nat == 2


def test_export_espei_bundle_minimal(tmp_path: Path):
    _write_minimal_p2_work(tmp_path)
    results = {"eos": {"E0_Ry": -10.0}}
    res = export_espei_bundle(tmp_path, results, material_id="Si")
    assert res.ok is True
    assert (tmp_path / "calphad_espei" / "manifest.json").is_file()
    assert (tmp_path / "calphad_espei" / "datasets" / "cpm_form_qha.json").is_file()
    cpm = json.loads(
        (tmp_path / "calphad_espei" / "datasets" / "cpm_form_qha.json").read_text(
            encoding="utf-8"
        )
    )
    assert cpm["output"] == "CPM_FORM"
    assert cpm["components"] == ["SI", "VA"]
    assert len(cpm["values"][0]) == 4  # nT
    assert len(cpm["values"][0][0]) == 1  # nconfigs


def test_pipeline_job_p2_espei_default_off():
    from pipeline import PipelineJob

    job = PipelineJob(
        material_id="Si",
        profile_id="P2",
        scf_in_basename="scf.in",
        nproc=1,
    )
    assert job.p2_espei_export_opt_in is False

    job_on = PipelineJob(
        material_id="Si",
        profile_id="P2",
        scf_in_basename="scf.in",
        nproc=1,
        p2_espei_export_opt_in=True,
    )
    assert job_on.p2_espei_export_opt_in is True

    job_p3 = PipelineJob(
        material_id="Si",
        profile_id="P3",
        scf_in_basename="scf.in",
        nproc=1,
        p2_espei_export_opt_in=True,
    )
    assert job_p3.p2_espei_export_opt_in is False

"""Tests pour ``backend/parsers/dielectric.py`` (refonte juin 2026).

Couvre :
  * ``parse_dielectric_from_text(text)`` : journal thermo_pw (ε∞ 3×3 + Z*).
  * ``parse_dielectric_tensor_file(path)`` : fichier colonne 3×3 (``epsilon_infinity.dat``).
  * ``parse_dielectric(work_dir)`` : orchestrateur.

Format thermo_pw 7.x (ug.1.5.0+) : juin 2021.
"""
from __future__ import annotations

import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_BACKEND = os.path.dirname(_HERE)
if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)

import pytest

from parsers.dielectric import (
    parse_dielectric,
    parse_dielectric_from_text,
    parse_dielectric_tensor_file,
)


# ============================================================================
# parse_dielectric_from_text
# ============================================================================


def test_dielectric_tensor_3x3_basic():
    text = """
  Dielectric constant:
   12.456    0.052    0.000
    0.052   12.389    0.000
    0.000    0.000   12.211

  Average dielectric constant: 12.352
"""
    out = parse_dielectric_from_text(text)
    assert out["epsilon_xx"] == pytest.approx(12.456, rel=1e-6)
    assert out["epsilon_yy"] == pytest.approx(12.389, rel=1e-6)
    assert out["epsilon_zz"] == pytest.approx(12.211, rel=1e-6)
    assert out["epsilon_xy"] == pytest.approx(0.052, rel=1e-6)
    assert out["epsilon_average"] == pytest.approx(12.352, rel=1e-6)
    assert out["epsilon_anisotropy"] is not None
    assert out["epsilon_anisotropy"] == pytest.approx(12.456 / 12.211, rel=1e-6)
    assert out["refractive_index_avg"] == pytest.approx((12.352) ** 0.5, rel=1e-6)
    assert out["average_dielectric_constant"] == pytest.approx(12.352, rel=1e-6)
    assert "epsilon_infinity_tensor_3x3" in out["matched_keywords"]


def test_dielectric_tensor_alternative_header():
    text = """
Dielectric constant (high frequency):
 11.20   0.00   0.00
  0.00  11.20   0.00
  0.00   0.00  11.20
"""
    out = parse_dielectric_from_text(text)
    assert out["epsilon_xx"] == pytest.approx(11.20, rel=1e-6)
    assert out["epsilon_anisotropy"] == pytest.approx(1.0, rel=1e-6)
    assert out["refractive_index_avg"] == pytest.approx(11.20 ** 0.5, rel=1e-6)


def test_dielectric_born_charges_basic():
    text = """
  Born effective charges:
   atom   1  type Si
       Z* =  3.210  0.000  0.000  0.000  3.205  0.000  0.000  0.000  3.198
   atom   2  type Si
       Z* = -3.210  0.000  0.000  0.000 -3.205  0.000  0.000  0.000 -3.198

  Dielectric constant:
   12.0   0.0   0.0
    0.0  12.0   0.0
    0.0   0.0  12.0
"""
    out = parse_dielectric_from_text(text)
    assert len(out["born_Z_star_per_atom"]) == 2
    assert out["born_Z_star_per_atom"][0]["atom_index"] == 1
    assert out["born_Z_star_per_atom"][0]["atom_type"] == "Si"
    assert out["born_Z_star_per_atom"][0]["Z_star"][0][0] == pytest.approx(3.210, rel=1e-6)
    assert out["born_Z_star_per_atom"][1]["Z_star"][0][0] == pytest.approx(-3.210, rel=1e-6)
    assert out["born_Z_star_max_abs"] == pytest.approx(3.210, rel=1e-6)
    assert "born_effective_charges_3x3_per_atom" in out["matched_keywords"]


def test_dielectric_born_multiline_format():
    """Matrice Z* sur 3 lignes plutôt que compact."""
    text = """
  Born effective charges:
   atom   1  type O
     2.50  0.00  0.00
     0.00  2.48  0.00
     0.00  0.00  2.45
   atom   2  type O
    -2.50  0.00  0.00
     0.00 -2.48  0.00
     0.00  0.00 -2.45
"""
    out = parse_dielectric_from_text(text)
    # 2 atomes attendus
    assert len(out["born_Z_star_per_atom"]) == 2
    z0 = out["born_Z_star_per_atom"][0]["Z_star"]
    assert z0[0][0] == pytest.approx(2.50, rel=1e-6)
    assert z0[2][2] == pytest.approx(2.45, rel=1e-6)
    assert out["born_Z_star_max_abs"] == pytest.approx(2.50, rel=1e-6)


# ============================================================================
# parse_ph_out_dielectric_from_text (ph.x QE 7.5)
# ============================================================================

PH_OUT_SNIPPET = """
     End of electric fields calculation

          Dielectric constant in cartesian axis 

          (      13.177241750       0.000000000       0.000000000 )
          (       0.000000000      13.177241750       0.000000000 )
          (       0.000000000       0.000000000      13.177241750 )

          Effective charges (d P / du) in cartesian axis 

           atom      1Si    
      Px  (       -0.00777        0.00000        0.00000 )
      Py  (        0.00000       -0.00777       -0.00000 )
      Pz  (        0.00000       -0.00000       -0.00777 )
           atom      2Si    
      Px  (       -0.00777       -0.00000        0.00000 )
      Py  (       -0.00000       -0.00777       -0.00000 )
      Pz  (        0.00000       -0.00000       -0.00777 )

     Diagonalizing the dynamical matrix
"""


def test_ph_out_dielectric_tensor():
    from parsers.dielectric import parse_ph_out_dielectric_from_text

    out = parse_ph_out_dielectric_from_text(PH_OUT_SNIPPET)
    assert out["epsilon_xx"] == pytest.approx(13.177241750, rel=1e-6)
    assert out["epsilon_yy"] == pytest.approx(13.177241750, rel=1e-6)
    assert out["epsilon_zz"] == pytest.approx(13.177241750, rel=1e-6)
    assert out["epsilon_average"] == pytest.approx(13.177241750, rel=1e-6)
    assert "ph_out_dielectric_tensor_3x3" in out["matched_keywords"]
    assert len(out["born_Z_star_per_atom"]) == 2
    assert "ph_out_born_effective_charges_3x3" in out["matched_keywords"]


def test_parse_dielectric_reads_ph_out(tmp_path):
    wd = tmp_path / "run"
    wd.mkdir()
    (wd / "ph.out").write_text(PH_OUT_SNIPPET, encoding="utf-8")
    out = parse_dielectric(wd)
    assert out["epsilon_xx"] == pytest.approx(13.177241750, rel=1e-6)
    assert "ph.out" in out["source_files"][0]


def test_dielectric_no_match_returns_empty():
    out = parse_dielectric_from_text("some totally unrelated log\n")
    assert out["epsilon_xx"] is None
    assert out["born_Z_star_per_atom"] == []
    assert "no_dielectric_output_found" in out["matched_keywords"]


def test_dielectric_tensor_symmetric_avg_when_off_diagonal_only_one_side():
    """Si le journal omet ε_yx, on prend la moyenne ε_xy (symmétrie)."""
    text = """
  Dielectric constant:
    10.0    0.20    0.00
     .      10.0    0.00
     .       .     10.0
"""
    out = parse_dielectric_from_text(text)
    # ε_xy = 0.20 (lu), ε_yz = 0.0 (lu), ε_xz = 0.0 (lu).
    assert out["epsilon_xy"] == pytest.approx(0.20, rel=1e-6)


# ============================================================================
# parse_dielectric_tensor_file
# ============================================================================


def test_dielectric_tensor_file_basic(tmp_path):
    p = tmp_path / "epsilon_infinity.dat"
    p.write_text(
        "# epsilon_infinity (3x3)\n"
        " 12.5  0.0  0.0\n"
        "  0.0 12.3  0.0\n"
        "  0.0  0.0 12.1\n",
        encoding="utf-8",
    )
    out = parse_dielectric_tensor_file(p)
    assert out["matrix"] is not None
    assert out["matrix"][0][0] == pytest.approx(12.5, rel=1e-6)
    assert out["matrix"][2][2] == pytest.approx(12.1, rel=1e-6)


# ============================================================================
# parse_dielectric — orchestrateur
# ============================================================================


def test_orchestrator_from_log(tmp_path):
    (tmp_path / "thermo_pw_run.out").write_text(
        "Dielectric constant:\n"
        " 12.0  0.0  0.0\n"
        "  0.0 12.0  0.0\n"
        "  0.0  0.0 12.0\n"
        "\n"
        "Average dielectric constant: 12.0\n"
        "Born effective charges:\n"
        " atom   1  type Si\n"
        "  Z* =  3.2  0.0  0.0  0.0  3.2  0.0  0.0  0.0  3.2\n",
        encoding="utf-8",
    )
    out = parse_dielectric(tmp_path)
    assert out["epsilon_xx"] == pytest.approx(12.0, rel=1e-6)
    assert out["epsilon_average"] == pytest.approx(12.0, rel=1e-6)
    assert out["refractive_index_avg"] == pytest.approx(12.0 ** 0.5, rel=1e-6)
    assert out["born_Z_star_max_abs"] == pytest.approx(3.2, rel=1e-6)
    assert "epsilon_infinity_tensor_3x3" in out["matched_keywords"]
    assert "born_effective_charges_3x3_per_atom" in out["matched_keywords"]


def test_orchestrator_combines_log_and_dat_file(tmp_path):
    """Le fichier colonne ``epsilon_infinity.dat`` complète/maj le journal."""
    (tmp_path / "thermo_pw_run.out").write_text("# unrelated\n", encoding="utf-8")
    (tmp_path / "epsilon_infinity.dat").write_text(
        "10.0  0.0  0.0\n"
        " 0.0 10.5  0.0\n"
        " 0.0  0.0 11.0\n",
        encoding="utf-8",
    )
    out = parse_dielectric(tmp_path)
    assert out["epsilon_xx"] == pytest.approx(10.0, rel=1e-6)
    assert out["epsilon_zz"] == pytest.approx(11.0, rel=1e-6)
    assert "dielectric_tensor_dat_file" in out["matched_keywords"]


def test_orchestrator_no_outputs_marks_no_match(tmp_path):
    out = parse_dielectric(tmp_path)
    assert "no_dielectric_output_found" in out["matched_keywords"]
    assert out["epsilon_xx"] is None


def test_orchestrator_n_refractive_only_when_average_positive(tmp_path):
    """Si ε_average == 0 ou négatif (artefact pathologique), n = None."""
    (tmp_path / "thermo_pw_run.out").write_text(
        "Dielectric constant:\n"
        " 0.0  0.0  0.0\n"
        " 0.0  0.0  0.0\n"
        " 0.0  0.0  0.0\n",
        encoding="utf-8",
    )
    out = parse_dielectric(tmp_path)
    assert out["refractive_index_avg"] is None

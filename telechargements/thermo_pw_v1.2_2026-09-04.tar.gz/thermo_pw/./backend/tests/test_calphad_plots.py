"""Tests diagrammes thermo mono-phase (opt-in P2)."""
from __future__ import annotations

import json
from pathlib import Path

from calphad_plots import generate_phase_plots


def _write_espei_minimal(tmp_path: Path) -> None:
    ds = tmp_path / "calphad_espei" / "datasets"
    ds.mkdir(parents=True)
    base = {
        "components": ["SI", "VA"],
        "phases": ["SI"],
        "conditions": {"P": [101325.0], "T": [0.0, 300.0, 600.0]},
        "values": [[[1.0], [2.0], [3.0]]],
    }
    for name, out in (
        ("cpm_form_qha.json", "CPM_FORM"),
        ("sm_form_qha.json", "SM_FORM"),
        ("hm_form_qha.json", "HM_FORM"),
    ):
        payload = {**base, "output": out}
        (ds / name).write_text(json.dumps(payload), encoding="utf-8")


def test_generate_phase_plots(tmp_path: Path):
    _write_espei_minimal(tmp_path)
    results = {"properties": {"dynamically_stable": True}, "eos": {"B0_GPa_approx": 87.0}}
    res = generate_phase_plots(tmp_path, results=results, material_id="Si")
    assert res.ok is True
    overview = tmp_path / "calphad_espei/plots/phase_thermo_overview.png"
    assert overview.is_file()
    assert overview.stat().st_size > 1000
    assert any(p.endswith("phase_thermo_overview.png") for p in res.plots)


def test_generate_phase_plots_skips_corrupt_dataset(tmp_path: Path):
    """Un JSON ESPEI corrompu ne doit pas faire planter les autres courbes."""
    _write_espei_minimal(tmp_path)
    sm = tmp_path / "calphad_espei" / "datasets" / "sm_form_qha.json"
    sm.write_text("{not-json", encoding="utf-8")
    res = generate_phase_plots(tmp_path, material_id="Si")
    assert res.ok is True
    assert any("sm_form_qha.json illisible" in w for w in res.warnings)
    overview = tmp_path / "calphad_espei/plots/phase_thermo_overview.png"
    assert overview.is_file()
    assert (tmp_path / "calphad_espei/plots/phase_cp.png").is_file()
    assert not (tmp_path / "calphad_espei/plots/phase_entropy.png").is_file()

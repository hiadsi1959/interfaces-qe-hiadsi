"""
Post-ph.x : q2r.x (fc.out), matdyn.x (dispersions §1.8, DOS §1.9), dynmat.x (§1.10 suite).
Entrées générées à partir de ph.in et pw_scf_V0_for_phonon.in dans work_dir.
"""
from __future__ import annotations

import math
import os
import re
import shutil
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import config as cfg
from eos_paths import wf1_eos_run_root
from ph_input_from_pw import (
    normalize_ph_control_for_thermo_pw,
    try_autogenerate_ph_in,
)
from phonon_imaginary_recommendations import (
    build_phonon_imaginary_recommendations,
)
from qe_subprocess import (
    API_CANCEL_RUNTIME_MSG,
    run_mpi_stdio_on_open_log,
    run_qe_stdin,
    which_mpirun,
)


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def parse_ph_fildyn(work_dir: Path) -> tuple[str, str]:
    """Lit ph.in pour zasr et préfixe fildyn."""
    ph_in = work_dir / "ph.in"
    if not ph_in.is_file():
        raise FileNotFoundError(f"ph.in absent dans {work_dir}")
    txt = _read_text(ph_in)
    fd = "ph_dyn"
    z = "simple"
    m = re.search(r"fildyn\s*=\s*['\"]?([^'\"/\s]+)", txt, re.I)
    if m:
        fd = m.group(1).strip()
    m2 = re.search(r"zasr\s*=\s*['\"]?([^'\"/\s]+)", txt, re.I)
    if m2:
        z = m2.group(1).strip()
    return z, fd


def parse_fildyn_from_ph_any(work_dir: Path) -> Optional[str]:
    """fildyn dans ph_control ou ph.in, si présents (cohérence thermo_control ↔ entrée phonon)."""
    work_dir = wf1_eos_run_root(work_dir.resolve())
    for name in ("ph_control", "ph.in"):
        p = work_dir / name
        if not p.is_file():
            continue
        m = re.search(r"fildyn\s*=\s*['\"]?([^'\"/\s]+)", _read_text(p), re.I)
        if m:
            return m.group(1).strip()
    return None


def resolve_zasr_for_thermo_pw(work_dir: Path) -> Optional[str]:
    """ASR lue depuis q2r.in / ph_control / ph.in (cohérence avec fc.out / q2r).

    thermo_pw 7.x : ``zasr='crystal'`` + MPI peut provoquer un SIGSEGV dans ``dynmat_sub`` /
    ``set_asr_tpw`` (sp2) après écriture des dispersions ; le défaut API suit **simple** ou la
    valeur déjà utilisée à l’étape q2r si présente.
    """
    work_dir = wf1_eos_run_root(work_dir.resolve())
    for name in ("q2r.in", "ph_control", "ph.in"):
        p = work_dir / name
        if not p.is_file():
            continue
        m = re.search(r"zasr\s*=\s*['\"]?([^'\"/\s,]+)", _read_text(p), re.I)
        if m:
            return m.group(1).strip().lower()
    return None


def resolve_fildyn_for_qha_prereq(
    work_dir: Path,
    thermo_opts: dict,
    flat_data: dict,
) -> str:
    """Prérequis QHA : préférer le fildyn réellement lu dans ph_control / ph.in."""
    fd = parse_fildyn_from_ph_any(work_dir)
    if fd:
        return fd
    return (
        str(thermo_opts.get("fildyn") or flat_data.get("fildyn") or "ph_dyn")
        .strip()
        or "ph_dyn"
    )


def parse_atomic_masses_from_pw(work_dir: Path) -> list[float]:
    """Lit ATOMIC_SPECIES dans pw_scf_V0_for_phonon.in (ordre des types)."""
    # Important : dans les workflows EOS, `scf_eq.in` peut correspondre à une étape
    # intermédiaire (voire une géométrie / `nat` différent) alors que la chaison
    # phonon (ph.x / matdyn) est alignée sur `pw_scf_V0_for_phonon.in`.
    for name in ("pw_scf_V0_for_phonon.in", "scf_eq.in"):
        p = work_dir / name
        if not p.is_file():
            continue
        txt = _read_text(p)
        masses: list[float] = []
        block = False
        for line in txt.splitlines():
            ls = line.strip()
            if not ls or ls.startswith("!"):
                continue
            if ls.upper().startswith("ATOMIC_SPECIES"):
                block = True
                continue
            if block:
                ul = ls.upper()
                if ul.startswith("&") or ul.startswith("/") or ul.startswith("ATOMIC_POSITIONS"):
                    break
                parts = ls.split()
                if len(parts) >= 2:
                    try:
                        masses.append(float(parts[1]))
                    except ValueError:
                        pass
        if masses:
            return masses
    raise ValueError(
        "Impossible de lire les masses dans pw_scf_V0_for_phonon.in ou scf_eq.in"
    )


def parse_nat_from_pw(work_dir: Path) -> int:
    """Lit nat dans le même fichier PW que pour les masses (phonons)."""
    for name in ("pw_scf_V0_for_phonon.in", "scf_eq.in"):
        p = work_dir / name
        if not p.is_file():
            continue
        txt = _read_text(p)
        m = re.search(r"\bnat\s*=\s*(\d+)", txt, flags=re.I)
        if m:
            return int(m.group(1))
    raise ValueError(
        "Impossible de lire nat dans pw_scf_V0_for_phonon.in ou scf_eq.in"
    )


def parse_ibrav_from_pw(work_dir: Path) -> Optional[int]:
    """Lit ``ibrav`` dans ``&SYSTEM`` (même ordre de fichiers que les masses atomiques).

    Ordre de priorité des fichiers d'entrée (juillet 2026) :
      1. ``pw_scf_V0_for_phonon.in`` (P1-P5 — SCF @ V₀ copié avant ph.x)
      2. ``scf_eq.in``             (legacy 1_eos_volumes)
      3. ``scf.in``                (fallback — SCF brut)

    Le fallback sur ``scf.in`` assure la détection ``ibrav`` même si
    ``pw_scf_V0_for_phonon.in`` n'est pas encore copié (nécessaire pour
    ``write_pw_bands_in`` dans la chaîne bandes électroniques).
    """
    for name in ("pw_scf_V0_for_phonon.in", "scf_eq.in", "scf.in"):
        p = work_dir / name
        if not p.is_file():
            continue
        m = re.search(r"\bibrav\s*=\s*(-?\d+)", _read_text(p), re.I)
        if m:
            return int(m.group(1))
    return None


def matdyn_band_qpath_for_ibrav(ibrav: Optional[int]) -> tuple[list[tuple[float, float, float]], list[int]]:
    """Sommets q (fractionnaires réseau réciproque cristallin) et pas par segment pour ``matdyn_bands.in``.

    Conventions alignées sur ``templates/qe_bands/README_chemins_k_et_bandes.txt`` (§2).
    Dernier entier de chaque ligne : pas vers le sommet suivant ; 1 sur la dernière ligne.

    * ``ibrav`` 1 ou inconnu / 0 : cubique simple Γ–X–M–Γ–R–X–M–R.
    * ``ibrav`` 2 : FCC (ex. Si) chemin type §2.2 avec U = (5/8, 1/4, 5/8).
    * ``ibrav`` 3 : BCC §2.3 (coordonnées H avec composante négative, comme dans le README).
    * ``ibrav`` 4 : hexagonal §2.4 (Γ–M–K–Γ–A–L–H–A).
    * ``ibrav`` 6 : tétragonal simple §2.5 (Γ–X–M–Γ–Z–R–A–Z).
    """
    nk_mid, nk_end = 40, 1

    def pack(verts: list[tuple[float, float, float]]) -> tuple[list[tuple[float, float, float]], list[int]]:
        nks = [nk_mid] * (len(verts) - 1) + [nk_end]
        return verts, nks

    if ibrav == 2:
        u = (5.0 / 8.0, 1.0 / 4.0, 5.0 / 8.0)
        verts = [
            (0.0, 0.0, 0.0),
            (0.0, 0.5, 0.5),
            (0.25, 0.5, 0.75),
            (0.375, 0.375, 0.75),
            (0.0, 0.0, 0.0),
            (0.5, 0.5, 0.5),
            u,
            (0.25, 0.5, 0.75),
            (0.5, 0.5, 0.5),
            (0.375, 0.375, 0.75),
        ]
        return pack(verts)
    if ibrav == 3:
        verts = [
            (0.0, 0.0, 0.0),
            (0.5, -0.5, 0.5),
            (0.0, 0.0, 0.5),
            (0.0, 0.0, 0.0),
            (0.25, 0.25, 0.25),
            (0.5, -0.5, 0.5),
        ]
        return pack(verts)
    if ibrav == 4:
        o3 = 1.0 / 3.0
        verts = [
            (0.0, 0.0, 0.0),
            (0.5, 0.0, 0.0),
            (o3, o3, 0.0),
            (0.0, 0.0, 0.0),
            (0.0, 0.0, 0.5),
            (0.5, 0.0, 0.5),
            (o3, o3, 0.5),
            (0.0, 0.0, 0.5),
        ]
        return pack(verts)
    if ibrav == 6:
        verts = [
            (0.0, 0.0, 0.0),
            (0.5, 0.0, 0.0),
            (0.5, 0.5, 0.0),
            (0.0, 0.0, 0.0),
            (0.0, 0.0, 0.5),
            (0.5, 0.0, 0.5),
            (0.5, 0.5, 0.5),
            (0.0, 0.0, 0.5),
        ]
        return pack(verts)
    verts = [
        (0.0, 0.0, 0.0),
        (0.5, 0.0, 0.0),
        (0.5, 0.5, 0.0),
        (0.0, 0.0, 0.0),
        (0.5, 0.5, 0.5),
        (0.5, 0.0, 0.0),
        (0.5, 0.5, 0.0),
        (0.5, 0.5, 0.5),
    ]
    return pack(verts)


def write_q2r_in(work_dir: Path, *, zasr: str, fildyn: str, flfrc: str = "fc.out") -> Path:
    body = (
        f" &input\n"
        f"  zasr='{zasr}', fildyn='{fildyn}', flfrc='{flfrc}'\n"
        f" /\n"
    )
    p = work_dir / "q2r.in"
    p.write_text(body, encoding="utf-8")
    return p


def run_q2r(
    work_dir: Path,
    *,
    flfrc: str = "fc.out",
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
) -> Path:
    work_dir = wf1_eos_run_root(work_dir.resolve())
    zasr, fildyn = parse_ph_fildyn(work_dir)
    write_q2r_in(work_dir, zasr=zasr, fildyn=fildyn, flfrc=flfrc)
    inp = work_dir / "q2r.in"
    log = work_dir / "q2r.out"
    run_qe_stdin(
        cfg.q2r_path(), inp, work_dir, log,
        cancel_event=cancel_event, proc_holder=proc_holder,
    )
    fc = work_dir / flfrc
    if not fc.is_file():
        raise RuntimeError(f"{flfrc} non créé après q2r.x — voir {log}")
    return log


def run_q2r_dynamical_matrices(
    work_dir: Path,
    *,
    igeo: int = 1,
    flfrc: str = "fc.out",
    zasr: Optional[str] = None,
) -> Path:
    """q2r.x quand ph.x / thermo_pw a écrit ``dynamical_matrices/ph_dyn.g*.*``.

    Fichier ``.0`` : grille (nq1, nq2, nq3, nombre de q irréductibles).
    Fichiers ``.1`` … ``.N`` : matrices (chemin QE / matdyn ; Γ en ``.1`` pour thermo_pw).

    Entrée q2r sans ``ph_dyn0`` à la racine : liste explicite des chemins (QE ``do_q2r``).
    """
    work_dir = wf1_eos_run_root(work_dir.resolve())
    if igeo < 1:
        raise ValueError("igeo doit être >= 1 (indice géométrie thermo_pw)")
    dm = work_dir / "dynamical_matrices"
    grid = dm / f"ph_dyn.g{igeo}.0"
    if not grid.is_file():
        raise FileNotFoundError(
            f"Grille introuvable : {grid} — vérifier igeo (1 = première géométrie EOS/QHA)."
        )
    glines = [ln.strip() for ln in _read_text(grid).splitlines() if ln.strip()]
    if len(glines) < 2:
        raise ValueError(f"Fichier grille invalide : {grid}")
    nr_parts = glines[0].split()
    if len(nr_parts) < 3:
        raise ValueError(f"{grid} : nq1 nq2 nq3 attendus sur la 1re ligne")
    nr1, nr2, nr3 = int(nr_parts[0]), int(nr_parts[1]), int(nr_parts[2])
    nfile = int(glines[1].split()[0])
    if nfile < 1:
        raise ValueError(f"{grid} : nombre de fichiers q irr. invalide ({nfile})")
    rel_names: list[str] = []
    for j in range(1, nfile + 1):
        rel = f"dynamical_matrices/ph_dyn.g{igeo}.{j}"
        if not (work_dir / rel).is_file():
            raise FileNotFoundError(f"Matrice dynamique attendue : {work_dir / rel}")
        rel_names.append(rel)
    z = (zasr or "").strip().lower()
    if not z:
        z = resolve_zasr_for_thermo_pw(work_dir) or parse_ph_fildyn(work_dir)[0]
    fake = "__tpw_q2r_no_dyn0__"
    body = (
        " &input\n"
        f"  zasr='{z}', fildyn='{fake}', flfrc='{flfrc}'\n"
        " /\n"
        f"{nr1} {nr2} {nr3}\n"
        f"{nfile}\n"
        + "\n".join(rel_names)
        + "\n"
    )
    inp = work_dir / "q2r_from_dm.in"
    inp.write_text(body, encoding="utf-8")
    log = work_dir / "q2r_from_dm.out"
    run_qe_stdin(cfg.q2r_path(), inp, work_dir, log)
    fc = work_dir / flfrc
    if not fc.is_file():
        raise RuntimeError(f"{flfrc} non créé après q2r.x — voir {log}")
    return log


def _fmt_amass_list(masses: list[float]) -> str:
    lines = []
    for i, m in enumerate(masses, start=1):
        lines.append(f"  amass({i})={m},")
    return "\n".join(lines)


def write_matdyn_dos_in(
    work_dir: Path,
    masses: list[float],
    *,
    flfrc: str = "fc.out",
    fldos: str = "phonon.dos",
    nk1: int = 24,
    nk2: int = 24,
    nk3: int = 24,
    delta_e: float = 1.0,
    ndos: int = 501,
    asr: str = "simple",
) -> Path:
    am = _fmt_amass_list(masses)
    body = (
        " &input\n"
        f"  asr='{asr}',\n"
        f"  dos=.true.,\n"
        f"  flfrc='{flfrc}',\n"
        f"  fldos='{fldos}',\n"
        f"  nk1={nk1}, nk2={nk2}, nk3={nk3},\n"
        f"  DeltaE={delta_e}d0,\n"
        f"  ndos={ndos},\n"
        f"{am}\n"
        " /\n"
    )
    p = work_dir / "matdyn_dos.in"
    p.write_text(body, encoding="utf-8")
    return p


def run_matdyn_dos(
    work_dir: Path,
    *,
    nk1: int = 24,
    nk2: int = 24,
    nk3: int = 24,
    flfrc: str = "fc.out",
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
) -> Path:
    work_dir = wf1_eos_run_root(work_dir.resolve())
    masses = parse_atomic_masses_from_pw(work_dir)
    fc = work_dir / flfrc
    if not fc.is_file():
        raise FileNotFoundError(f"{flfrc} absent — lancez d'abord q2r.x")
    write_matdyn_dos_in(
        work_dir,
        masses,
        flfrc=flfrc,
        nk1=nk1,
        nk2=nk2,
        nk3=nk3,
    )
    inp = work_dir / "matdyn_dos.in"
    log = work_dir / "matdyn_dos.out"
    run_qe_stdin(
        cfg.matdyn_path(), inp, work_dir, log,
        cancel_event=cancel_event, proc_holder=proc_holder,
    )
    return log


def write_matdyn_bands_in(
    work_dir: Path,
    masses: list[float],
    *,
    flfrc: str = "fc.out",
    flfrq: str = "phonon.freq",
    asr: str = "simple",
) -> Path:
    """Écrit ``matdyn_bands.in`` : chemin q selon ``ibrav`` (README §2), défaut cubique simple."""
    ibrav = parse_ibrav_from_pw(work_dir)
    verts, nks = matdyn_band_qpath_for_ibrav(ibrav)
    am = _fmt_amass_list(masses)
    lines = [
        " &input\n",
        f"  asr='{asr}',\n",
        f"  flfrc='{flfrc}',\n",
        f"  flfrq='{flfrq}',\n",
        "  q_in_band_form=.true.,\n",
        "  q_in_cryst_coord=.true.,\n",
        f"{am}\n",
        " /\n",
        f" {len(verts)}\n",
    ]
    for (qx, qy, qz), nk in zip(verts, nks, strict=True):
        lines.append(f"  {qx:.12g} {qy:.12g} {qz:.12g}   {nk}\n")
    p = work_dir / "matdyn_bands.in"
    p.write_text("".join(lines), encoding="utf-8")
    return p


def pick_dynmat_dyn_file(work_dir: Path, fildyn_file: Optional[str] = None) -> str:
    """Nom d’un fichier dynamique local (ph_dyn0, …) pour dynmat.x."""
    work_dir = Path(work_dir)

    def _looks_like_dynmat_matrix_file(p: Path) -> bool:
        try:
            first = p.open("r", encoding="utf-8", errors="replace").readline()
        except OSError:
            return False
        return "Dynamical matrix file" in first

    if fildyn_file:
        p = work_dir / fildyn_file
        if not p.is_file():
            raise FileNotFoundError(f"fichier dynamique absent : {fildyn_file}")
        # Erreur fréquente : `ph_dyn0` est souvent seulement une entête de grille q,
        # pas une matrice complète lisible par dynmat.x → code Fortran 24 (EOF).
        if _looks_like_dynmat_matrix_file(p):
            return fildyn_file
        # Si l'utilisateur force explicitement un mauvais fichier, on retombe sur la sélection auto.
        # (sinon dynmat.x échoue systématiquement avec EOF.)
    # ph.x (nq1,nq2,nq3) écrit typiquement:
    # - `ph_dyn0`: entête/grille q-points (très petit fichier)
    # - `ph_dyn1`, `ph_dyn2`, ... : fichiers "Dynamical matrix file" lisibles par dynmat.x
    candidates = [p for p in work_dir.glob("ph_dyn*") if p.is_file() and p.suffix != ".in"]
    candidates = sorted(candidates, key=lambda x: x.name)
    for p in candidates:
        try:
            first = p.open("r", encoding="utf-8", errors="replace").readline().strip()
        except OSError:
            continue
        if "Dynamical matrix file" in first:
            return p.name
    # fallback: mieux vaut éviter `ph_dyn0` si possible
    for p in candidates:
        if p.name != "ph_dyn0":
            return p.name
    raise FileNotFoundError(
        "Aucun fichier ph_dyn* dans le dossier — exécutez ph.x avant dynmat.x."
    )


def run_dynmat(
    work_dir: Path,
    *,
    fildyn_file: Optional[str] = None,
    asr: str = "simple",
) -> Path:
    """Diagonalisation / analyse dynmat.x — utile §1.10 (modes Γ), IR… selon entrées."""
    work_dir = wf1_eos_run_root(work_dir.resolve())
    dyn = pick_dynmat_dyn_file(work_dir, fildyn_file)
    body = (
        "&INPUT\n"
        f"  fildyn = '{dyn}',\n"
        f"  asr = '{asr}',\n"
        "  filout = 'dynmat_iface.out',\n"
        "/\n"
    )
    inp = work_dir / "dynmat.in"
    inp.write_text(body, encoding="utf-8")
    log = work_dir / "dynmat_run.out"
    exe = cfg.dynmat_path()
    if not exe.is_file():
        raise FileNotFoundError(f"dynmat.x introuvable : {exe}")
    run_qe_stdin(exe, inp, work_dir, log)
    return log


def run_matdyn_bands(
    work_dir: Path,
    *,
    flfrc: str = "fc.out",
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
) -> Path:
    work_dir = wf1_eos_run_root(work_dir.resolve())
    masses = parse_atomic_masses_from_pw(work_dir)
    fc = work_dir / flfrc
    if not fc.is_file():
        raise FileNotFoundError(f"{flfrc} absent — lancez d'abord q2r.x")
    write_matdyn_bands_in(work_dir, masses, flfrc=flfrc)
    inp = work_dir / "matdyn_bands.in"
    log = work_dir / "matdyn_bands.out"
    run_qe_stdin(
        cfg.matdyn_path(), inp, work_dir, log,
        cancel_event=cancel_event, proc_holder=proc_holder,
    )
    fq = work_dir / "phonon.freq"
    if not fq.is_file():
        raise RuntimeError(f"phonon.freq non créé — voir {log}")
    return log


# (juillet 2026) Whitelist canonique des options ``thermo_opts`` acceptées
# par ``run_thermo_pw_mpi`` — alignée thermo_pw 7.x et
# ``templates/thermo_control.template``. Si l'utilisateur injecte un drapeau
# hors whitelist (ex. ``lband`` qui n'existe PAS en 7.x — seul ``ltherm_freq``
# pilote la sortie freq-par-mode), ``run_thermo_pw_mpi`` lève une
# ``ValueError`` claire AVANT ``_purge_before_thermo_pw_mpi`` : ``restart/``
# et les ``_temporary*`` NE sont PAS effacés si l'entrée est invalide.
KNOWN_THERMO_FLAGS = frozenset({
    "what",
    "tmin",
    "tmax",
    "deltat",
    "fildyn",
    "zasr",
    "ltherm_dos",
    "ltherm_freq",
    # Solveur moindres carrés QHA (1=normales, 2=QR/DGELS, 3=SVD).
    "lsolve",
    # Balayage explicite en pression (thermo_pw § Temperature and pressure).
    "pmin",
    "pmax",
    "deltap",
    "pressure",
    "lmurn",
    "npress_plot",
})

# Mapping des fautes de frappe / renommages 7.x. Format :
#   ``flag_invalide -> (flag_canonique_7x, phrase_extra)``
# La phrase_extra est concaténée après « utilisez « {canon} » » (typiquement
# une précision sur l'intention de l'utilisateur). Étendre ce dict au gré
# des remontées UI / bug reports (cf. validate_known_thermo_flags).
RENAMED_THERMO_FLAGS_HINTS = {
    # ``lband`` n'existe pas en thermo_pw 7.x (legacy / convention non QE) ;
    # la sortie freq-par-mode se pilote via ``ltherm_freq``.
    "lband": ("ltherm_freq", "si vous voulez la sortie freq-par-mode"),
}


def validate_known_thermo_flags(raw: Optional[dict]) -> None:
    """Lève une ``ValueError`` claire si ``raw`` contient un drapeau hors whitelist 7.x.

    Comportement :
      * ``raw`` falsy (``None`` / ``{}``) → no-op silencieux.
      * Tous les drapeaux dans ``KNOWN_THERMO_FLAGS`` → no-op silencieux.
      * Au moins un drapeau inconnu → ``ValueError`` listant TOUS les
        drapeaux inconnus (pas de fast-fail). Si le **premier** drapeau
        inconnu est dans ``RENAMED_THERMO_FLAGS_HINTS``, le message de
        tête porte la substitution canonique (ex. « lband → ltherm_freq »).

    NB — le guard vérifie les **clés**, pas les **types** (un ``tmin='abc'``
    passera le guard ; c'est ensuite ``normalize_thermo_opts`` qui lèvera sur
    ``float('abc')`` via son filtre typé). Cela évite une explosion de
    branches dans le validateur et garde la séparation des concerns —
    keys = ici, types = ``normalize_thermo_opts``, persistence = le run
    thermo_pw.x lui-même.

    Appelée en début de ``run_thermo_pw_mpi`` AVANT
    ``_purge_before_thermo_pw_mpi`` — un utilisateur qui injecte un drapeau
    inconnu n'a ainsi pas son dossier ``restart/`` effacé avant de lire
    l'erreur. Idempotente : sûre à rappeler plusieurs fois par les tests.
    """
    if not raw:
        return
    unknown = [k for k in raw.keys() if k not in KNOWN_THERMO_FLAGS]
    if not unknown:
        return
    # Premier inconnu mappé : message ciblé en tête.
    head_hint = ""
    for k in unknown:
        if k in RENAMED_THERMO_FLAGS_HINTS:
            canonical, extra = RENAMED_THERMO_FLAGS_HINTS[k]
            head_hint = (
                f"drapeau inconnu en 7.x : « {k} » — utilisez « {canonical} » "
                f"{extra}. "
            )
            break
    listed = ", ".join(repr(k) for k in unknown)
    known_list = ", ".join(sorted(KNOWN_THERMO_FLAGS))
    msg_parts: list[str] = [head_hint]
    # Si le hint ciblé couvre déjà l'unique inconnu, on évite la
    # duplication « drapeaux inconnus : ['lband'] » (l'utilisateur a déjà
    # lu le nom dans head_hint). Si >1 inconnu OU pas de hint, on liste
    # tous les drapeaux inconnus en clair.
    if not (head_hint and len(unknown) == 1):
        msg_parts.append(f"drapeaux inconnus : [{listed}]. ")
    msg_parts.append(
        f"Drapeaux thermo_pw 7.x acceptés : [{known_list}]. "
        f"Voir ``templates/thermo_control.template`` pour le format canonique."
    )
    raise ValueError("".join(msg_parts))


def normalize_thermo_opts(raw: Optional[dict]) -> dict:
    """Filtre les clés acceptées pour write_thermo_control_minimal.

    NB — la validation **dure** (``ValueError`` sur drapeau inconnu) est faite
    en amont par ``validate_known_thermo_flags`` à l'intérieur de
    ``run_thermo_pw_mpi``. Cette fonction reste un filtre typé silencieux
    pour les chemins legacy / CLI / tests unitaires ; un appelant qui veut
    le mode strict doit appeler ``validate_known_thermo_flags`` en amont
    (cf. ``backend/tests/test_run_thermo_pw_input_validation.py``).
    """
    if not raw:
        return {}
    ok = KNOWN_THERMO_FLAGS
    out: dict = {}
    for k, v in raw.items():
        if k not in ok:
            continue
        if k in ("ltherm_dos", "ltherm_freq", "lmurn"):
            out[k] = bool(v)
        elif k in ("lsolve", "npress_plot"):
            out[k] = int(v)
        elif k == "what":
            out[k] = str(v).strip() or "mur_lc_t"
        elif k == "fildyn":
            out[k] = str(v).strip() or "ph_dyn"
        elif k == "zasr":
            out[k] = str(v).strip() or "simple"
        else:
            out[k] = float(v)
    return out


BOHR_RADIUS_A = 0.529177210903  # Å — définition CODATA utilisée par QE pour celldm vs Å


def _elastic_what_normalizes_pw_cell(what: str) -> bool:
    """Ce qui utilise latgen avec géométrie pw — éviter ibrav=0 pour §1.11 elastic."""
    w = (what or "").strip().lower()
    return "elastic" in w


def _parse_cp_three_vectors(lines: list[str], cp_idx: int) -> tuple[list[tuple[float, float, float]], int]:
    """Retourne les 3 lignes du bloc CELL_PARAMETERS après la ligne d'en-tête."""
    rows: list[tuple[float, float, float]] = []
    j = cp_idx + 1
    while len(rows) < 3 and j < len(lines):
        ls = lines[j].strip()
        if not ls or ls.startswith("!"):
            j += 1
            continue
        parts = ls.replace(",", " ").split()
        vals = []
        for p in parts:
            try:
                vals.append(float(p))
            except ValueError:
                continue
            if len(vals) == 3:
                break
        if len(vals) != 3:
            raise ValueError(f"ligne CELL_PARAMETERS invalide : {lines[j]!r}")
        rows.append((vals[0], vals[1], vals[2]))
        j += 1
    if len(rows) != 3:
        raise ValueError("CELL_PARAMETERS incomplet (< 3 lignes)")
    return rows, j


def _cell_parameters_unit(header_line: str) -> str:
    """angstrom | bohr | alat | unknown."""
    sup = header_line.upper().replace("{", " ").replace("}", " ")
    if "ALAT" in sup:
        return "alat"
    if "BOHR" in sup:
        return "bohr"
    if "ANGSTROM" in sup:
        return "angstrom"
    return "unknown"


def _is_cubic_diagonal_cell(
    r1: tuple[float, float, float],
    r2: tuple[float, float, float],
    r3: tuple[float, float, float],
    *,
    rtol: float = 4e-6,
    atol: float = 1e-8,
) -> bool:
    """True si les vecteurs sont alignés sur x,y,z avec même constante de maille."""
    def nz(*xs: float) -> bool:
        return max(abs(x) for x in xs) > atol

    if nz(r1[1], r1[2], r2[0], r2[2], r3[0], r3[1]):
        return False
    a, b, c = r1[0], r2[1], r3[2]
    if a <= 0 or b <= 0 or c <= 0:
        return False
    ref = max(abs(a), abs(b), abs(c))
    return (
        math.isclose(a, b, rel_tol=rtol, abs_tol=atol * max(1.0, ref))
        and math.isclose(a, c, rel_tol=rtol, abs_tol=atol * max(1.0, ref))
    )


def _celldm_from_cubic_diagonal(
    rows: list[tuple[float, float, float]],
    unit: str,
    *,
    celldm1_alat_hint: Optional[float] = None,
) -> Optional[float]:
    """Constante en Bohr pour ibrav=1 ; None si conversion impossible."""
    if len(rows) != 3:
        return None
    r1, r2, r3 = rows
    if not _is_cubic_diagonal_cell(r1, r2, r3):
        return None
    a_cell = float(r1[0])
    if unit == "angstrom":
        return a_cell / BOHR_RADIUS_A
    if unit == "bohr":
        return a_cell
    if unit == "alat":
        if celldm1_alat_hint is None or celldm1_alat_hint <= 0:
            return None
        return celldm1_alat_hint * a_cell
    # unknown — traité comme Å pour grandeurs typiques EOS (> ~2 Å)
    if unit == "unknown":
        if a_cell >= 2.0:
            return a_cell / BOHR_RADIUS_A
        return None
    return None


def _extract_celldm1_alat_hint(system_lines: list[str]) -> Optional[float]:
    """Si CELL_PARAMETERS en alat : lit celldm(1) dans le bloc SYSTEM fusionné."""
    blob = "\n".join(system_lines)
    m = re.search(r"celldm\s*\(\s*1\s*\)\s*=\s*([+-]?\d+\.?\d*(?:[deDE][+-]?\d+)?)", blob, re.I)
    if not m:
        return None
    try:
        v = float(m.group(1).replace("d", "e").replace("D", "e"))
    except ValueError:
        return None
    return v if v > 0 else None


def _find_system_block(lines: list[str]) -> tuple[Optional[int], Optional[int]]:
    """Premier bloc &SYSTEM … ligne avec / seule."""
    system_start = None
    for i, line in enumerate(lines):
        if re.match(r"\s*&SYSTEM\b", line, re.I):
            system_start = i
            break
    if system_start is None:
        return None, None
    for i in range(system_start + 1, len(lines)):
        if re.match(r"\s*/\s*$", lines[i]):
            return system_start, i
    return None, None


def rewrite_pw_cubic_ibrav0_for_elastic(pw_path: Path) -> tuple[bool, str]:
    """
    thermo_pw + latgen peut échouer avec ibrav=0 et CELL_PARAMETERS seuls (wrong celldm(1)).
    Pour une maille cubique décrite par trois vecteurs diagonaux, réécrit en ibrav=1 + celldm(1).
    Sauvegarde : même nom + '.bak_before_elastic' une fois.
    Retourne (modifié?, message court pour logs).
    """
    orig = pw_path.read_text(encoding="utf-8", errors="replace")
    lines = orig.splitlines()

    cp_line = None
    for i, line in enumerate(lines):
        if re.match(r"\s*CELL_PARAMETERS\b", line, re.I):
            cp_line = i
            break
    if cp_line is None:
        return False, ""

    header = lines[cp_line]
    unit = _cell_parameters_unit(header)

    system_start, system_end = _find_system_block(lines)
    if system_start is None or system_end is None:
        return False, ""

    celldm_hint = None
    if unit == "alat":
        sys_blob = lines[system_start : system_end + 1]
        celldm_hint = _extract_celldm1_alat_hint(sys_blob)
        if celldm_hint is None:
            return False, "(CELL_PARAMETERS alat sans celldm(1) lisible — pas de réécriture auto)"

    try:
        rows, idx_after_cp = _parse_cp_three_vectors(lines, cp_line)
    except ValueError:
        return False, ""

    celldm_bohr = _celldm_from_cubic_diagonal(
        rows, unit, celldm1_alat_hint=celldm_hint
    )
    if celldm_bohr is None or celldm_bohr <= 0:
        return False, ""

    ibrav_line = None
    for i in range(system_start + 1, system_end):
        if re.match(r"\s*ibrav\s*=\s*0\b", lines[i], re.I):
            ibrav_line = i
            break
    if ibrav_line is None:
        return False, ""

    celldm_lines_to_drop: set[int] = set()
    for i in range(system_start + 1, system_end):
        if re.match(r"\s*celldm\s*\(\s*1\s*\)\s*=", lines[i], re.I):
            celldm_lines_to_drop.add(i)

    drop_indices = set(range(cp_line, idx_after_cp))
    drop_indices |= celldm_lines_to_drop

    new_lines: list[str] = []
    inserted_celldm = False
    for i, line in enumerate(lines):
        if i in drop_indices:
            continue
        new_lines.append(line)
        if i == ibrav_line:
            indent = re.match(r"^(\s*)", line)
            pad = indent.group(1) if indent else "    "
            new_lines[-1] = f"{pad}ibrav = 1"
            new_lines.append(f"{pad}celldm(1) = {celldm_bohr:.12f}")
            inserted_celldm = True

    if not inserted_celldm:
        return False, ""

    bak = pw_path.with_name(pw_path.name + ".bak_before_elastic")
    if not bak.is_file():
        bak.write_text(orig, encoding="utf-8")

    out = "\n".join(new_lines) + ("\n" if orig.endswith("\n") else "")
    pw_path.write_text(out, encoding="utf-8")
    return True, (
        f"geom→ibrav=1, celldm(1)={celldm_bohr:.8f} Bohr "
        f"(était ibrav=0 cubique diagonal ; sauvegarde {bak.name})"
    )


def canonicalize_thermo_what(
    what: str,
    opts: Optional[dict[str, Any]] = None,
) -> tuple[str, str, str]:
    """Réécrit les alias legacy vers les noms thermo_pw 7.x.

    Retourne ``(canonique, original, note_legacy)``. Met à jour ``opts['what']``
    si ``opts`` est fourni. Appelée depuis ``run_thermo_pw_mpi`` et
    ``write_thermo_control_minimal`` pour que tout chemin d'écriture du
    ``thermo_control`` soit couvert (reprise thermo_pw incluse).
    """
    original = (what or "").strip().strip("'\"") or "mur_lc_t"
    w = original.lower()
    note = ""
    canonical = original

    if w == "qha_lif":
        canonical = "ph_life"
        note = f"legacy_alias_rewrite: 'qha_lif' -> '{canonical}' (P4 7.x LIF)"
    elif w == "thermo":
        canonical = "mur_lc_t"
        note = f"legacy_alias_rewrite: 'thermo' -> '{canonical}' (QHA 7.x)"
    elif w == "elastic":
        has_grid = bool(opts and any(k in opts for k in ("tmin", "tmax", "deltat")))
        canonical = "elastic_constants_geo" if has_grid else "scf_elastic_constants"
        note = (
            f"legacy_alias_rewrite: 'elastic' -> '{canonical}' "
            f"({'QHA grid' if has_grid else 'no QHA keys (T=0K)'})"
        )
    elif w == "piezoelectric_tensor":
        canonical = "scf_piezoelectric_tensor"
        note = (
            "legacy_alias_rewrite: 'piezoelectric_tensor' -> "
            "'scf_piezoelectric_tensor' (thermo_pw 7.5)"
        )
    elif w == "mur_lc_t_elastic_constants":
        canonical = "elastic_constants_geo"

    if opts is not None and canonical != original:
        opts["what"] = canonical
    return canonical, original, note


def write_thermo_control_minimal(
    work_dir: Path,
    *,
    what: str = "mur_lc_t",
    tmin: Optional[float] = 0.0,
    tmax: Optional[float] = 1000.0,
    deltat: Optional[float] = 10.0,
    fildyn: str = "ph_dyn",
    zasr: str = "simple",
    ltherm_dos: bool = True,
    ltherm_freq: bool = False,
    geo_elastic_qha_phonon: bool = False,
    lsolve: Optional[int] = None,
    pmin: Optional[float] = None,
    pmax: Optional[float] = None,
    deltap: Optional[float] = None,
    pressure: Optional[float] = None,
    lmurn: Optional[bool] = None,
    npress_plot: Optional[int] = None,
    **_ignored: Any,
) -> Path:
    """
    Si ``geo_elastic_qha_phonon`` (alias UI/API ``mur_lc_t_elastic_constants`` → ``elastic_constants_geo``),
    impose ``use_free_energy`` et ``elastic_algorithm='energy'`` comme l’attend QE thermo_pw 7.x avec phonons QHA.

    ``lsolve`` sélectionne le solveur moindres carrés de l'ajustement QHA
    (1 = équations normales, 2 = QR — défaut thermo_pw, 3 = SVD). Exposé car un
    échec de ``DGELS`` dans ``linsolvms`` interrompt le calcul *après* toute la
    partie DFPT : sur le cas de référence, 17 h de phonons perdues sur
    l'ajustement final.
    """
    opts_stub: dict[str, Any] = {"what": what}
    if tmin is not None:
        opts_stub["tmin"] = tmin
    if tmax is not None:
        opts_stub["tmax"] = tmax
    if deltat is not None:
        opts_stub["deltat"] = deltat
    what, _orig, _note = canonicalize_thermo_what(what, opts_stub)
    lines = [
        "! thermo_control — généré par api_server (bouton thermo_pw)",
        "&INPUT_THERMO",
        f"  what = '{what}',",
    ]
    if tmin is not None:
        lines.append(f"  tmin = {float(tmin)}d0,")
    if tmax is not None:
        lines.append(f"  tmax = {float(tmax)}d0,")
    if deltat is not None:
        lines.append(f"  deltat = {float(deltat)}d0,")
    lines.extend([
        f"  fildyn = '{fildyn}',",
        f"  zasr = '{zasr}',",
        f"  ltherm_dos = {'.true.' if ltherm_dos else '.false.'},",
        f"  ltherm_freq = {'.true.' if ltherm_freq else '.false.'},",
    ])
    if lsolve is not None:
        lines.append(f"  lsolve = {int(lsolve)},")
    if pmin is not None:
        lines.append(f"  pmin = {float(pmin)}d0,")
    if pmax is not None:
        lines.append(f"  pmax = {float(pmax)}d0,")
    if deltap is not None:
        lines.append(f"  deltap = {float(deltap)}d0,")
    if pressure is not None:
        lines.append(f"  pressure = {float(pressure)}d0,")
    if lmurn is not None:
        lines.append(f"  lmurn = {'.true.' if lmurn else '.false.'},")
    if npress_plot is not None:
        lines.append(f"  npress_plot = {int(npress_plot)},")
    if geo_elastic_qha_phonon:
        lines.extend(
            [
                "  use_free_energy = .true.,",
                "  elastic_algorithm = 'energy',",
            ]
        )
    lines.extend(["/", ""])
    p = work_dir / "thermo_control"
    p.write_text("\n".join(lines), encoding="utf-8")
    return p


_FAIL_LOG_LINE_RE = re.compile(
    r"(error\s+in\s+routine|\bfrom\s+error\b|fatal\s+error|stopping\.{3}|"
    r"\bmp_i?abort\b|mpi_abort|forrtl:|\bsevere\b\s*\(|wrong\s+nr\.|"
    r"\bdgels\b|linsolvms|mkl\s+error|parameter\s+\d+\s+was\s+incorrect|"
    r"cannot\s+open|not\s+found|allocation\s+failed|segmentation\s+fault)",
    re.I,
)


def _thermo_pw_fail_one_liner(excerpt: str) -> str:
    """Ligne courte lisible pour bandeaux (erreur souvent en fin d'extrait)."""
    best = ""
    for line in excerpt.splitlines():
        s = line.strip()
        if len(s) < 10:
            continue
        if _FAIL_LOG_LINE_RE.search(s) and len(s) > len(best):
            best = s
    if len(best) > 480:
        return best[:477].rstrip() + "…"
    return best


def _thermo_pw_fail_log_excerpt(raw: str, *, max_chars: int) -> str:
    """Préserve les lignes de méta (« # thermo_pw run ») puis la fin du fichier (erreurs QE)."""
    if not raw:
        return ""
    meta_lines: list[str] = []
    for line in raw.splitlines():
        if line.startswith("#"):
            meta_lines.append(line)
        else:
            break
    head = ("\n".join(meta_lines) + "\n\n") if meta_lines else ""
    lines = raw.splitlines()
    last_hit: Optional[int] = None
    for i in range(len(lines) - 1, -1, -1):
        if _FAIL_LOG_LINE_RE.search(lines[i]):
            last_hit = i
            break
    if last_hit is not None:
        err_start = max(0, last_hit - 28)
        err_block = "\n".join(lines[err_start:])
        candidate = head + err_block
    else:
        avail = max(200, max_chars - len(head))
        tail = raw[-avail:] if len(raw) > avail else raw
        candidate = head + tail
    if len(candidate) <= max_chars:
        return candidate
    return candidate[-max_chars:]


_MAX_THERMO_PW_FAIL_EXCERPT_CHARS = 3400


def _chmod_tree_writable(top: Path) -> None:
    """Assouplit les permissions pour faciliter rmtree (fichiers en lecture seule)."""
    if not top.exists():
        return
    try:
        for root, dirnames, filenames in os.walk(top, topdown=False):
            for name in filenames:
                p = Path(root) / name
                try:
                    p.chmod(p.stat().st_mode | 0o200)
                except OSError:
                    pass
            for name in dirnames:
                p = Path(root) / name
                try:
                    p.chmod(p.stat().st_mode | 0o200)
                except OSError:
                    pass
        try:
            top.chmod(top.stat().st_mode | 0o200)
        except OSError:
            pass
    except OSError:
        pass


def _purge_before_thermo_pw_mpi(work_dir: Path) -> tuple[list[str], bool]:
    """
    Supprime restart/ et les _temporary* (entrées PW temporaires).
    Retourne (fragments pour le journal, True si restart/ était présent et supprimé).
    """
    frags: list[str] = []
    did_restart = False
    rd = work_dir / "restart"
    if rd.is_dir():
        _chmod_tree_writable(rd)
        try:
            shutil.rmtree(rd)
        except OSError:
            shutil.rmtree(rd, ignore_errors=True)
        if rd.exists():
            raise RuntimeError(
                f"restart/ sous {work_dir} n’a pas pu être effacé. "
                "Fermez tous les thermo_pw / mpirun, puis en terminal : rm -rf restart"
            )
        did_restart = True
        frags.append("restart/")

    tmp_rm = 0
    for entry in sorted(work_dir.glob("_temporary*"), key=lambda p: str(p)):
        try:
            if entry.is_dir():
                _chmod_tree_writable(entry)
                shutil.rmtree(entry, ignore_errors=True)
                if not entry.exists():
                    tmp_rm += 1
            elif entry.is_file():
                try:
                    entry.chmod(entry.stat().st_mode | 0o200)
                except OSError:
                    pass
                entry.unlink(missing_ok=True)
                if not entry.exists():
                    tmp_rm += 1
        except OSError:
            pass
    if tmp_rm:
        frags.append("_temporary*" + f" ×{tmp_rm}")

    return frags, did_restart


def purge_thermo_pw_scratch_dirs(work_dir: Path) -> dict[str, object]:
    """
    Efface restart/ et _temporary* pour un dossier de run wf1_eos (API bouton ou curl).
    """
    wd = wf1_eos_run_root(Path(work_dir).expanduser().resolve())
    fragments, had_restart = _purge_before_thermo_pw_mpi(wd)
    return {
        "work_dir": str(wd),
        "removed": fragments,
        "restart_was_present": had_restart,
    }


# Backends 5-profils thermo_pw (UI « 5 profils » : mécanique, thermique, complète, LIF).
# `qha_lif` (Local Isothermal Free energy) — méthode exacte phonon par déformation anisotrope.
# Mêmes exigences que les autres what_*_elastic : ph_control + pw.in via stdin + geom cohérente.
# Juin 2026 refonte : whitelist étendue avec les noms canoniques ug.1.5.0+.
# Les aliases legacy (mur_lc_t, elastic_constants_geo, qha_lif, scf_elastic_constants)
# sont conservés pour rétro-compat des runs persistés dans work/.
_THERMO_PW_QHA_KEYS = frozenset({
    "elastic",          # P1 élasticité @ T=0 / P3 élasticité vs T (alias legacy: scf_elastic_constants)
    "thermo",           # P2 thermodynamique QHA (alias legacy: mur_lc_t)
    "ph_life",          # P4 durée de vie phonons / anharmonicité (alias legacy: qha_lif)
    # legacy / rétro-compat runs persistés :
    "mur_lc_t",
    "mur_lc_disp",
    "mur_lc_t_elastic_constants",
    "elastic_constants_geo",
    "qha_lif",
    "scf_elastic_constants",
})


# (juin 2026) Whitelist étendue pour P5 « exhaustive » : couvre les `what=`
# thermo_pw qui NE dépendent PAS d'une chaîne phonons préalable, et qui
# complètent la couverture du pipeline (piézoélectricité, magnétisme,
# visualisation BZ, constante diélectrique statique).
# * `piezoelectric_tensor`   : alias → ``scf_piezoelectric_tensor`` (thermo_pw 7.5).
# * `magnetic_susceptibility`: χ magnétique ; nécessite SCF spin-polarisé
#                              (nspin=2) en amont — sinon thermo_pw échouera
#                              proprement.
# * `magnetoelectric_tensor` : tenseur magnétoélectrique α_ij ; multi-physique.
# * `plot_bz`                : utilitaire de visualisation zone de Brillouin +
#                              info groupe spatial. Sortie `BZ_plot.ps.gz` +
#                              fichier texte avec noms q-points high-sym.
#
# Ces `what=` sont *additifs* à P5 : le profile_id="P5" appelle déjà la chaîne
# QE pure (epsilon.x + turbo_lanczos.x + turbo_davidson.x). Le client peut
# *en plus* sélectionner un sous-ensemble de ces `what_extra` via
# ``PipelineJob(extra_whats=[...])`` pour élargir le périmètre thermo_pw.
_THERMO_PW_LEGACY_WHAT_ALIASES = frozenset({
    "thermo",      # P2 → mur_lc_t
    "elastic",     # P1/P3 → scf_elastic_constants | elastic_constants_geo
    "qha_lif",     # P4 → ph_life
    "piezoelectric_tensor",  # P5 extra → scf_piezoelectric_tensor
})

_THERMO_PW_P5_EXTRAS = frozenset({
    "piezoelectric_tensor",
    "magnetic_susceptibility",
    "magnetoelectric_tensor",
    "plot_bz",
})


def _thermo_pw_what_needs_auto_ph_control(what_kw: str) -> bool:
    w = (what_kw or "").strip().strip("'\"").lower()
    return w in _THERMO_PW_QHA_KEYS


def _thermo_pw_uses_stdin_pw_instead_of_inp(qe_what: str) -> bool:
    """Voir thermo_pw 7.x : phq_readin_tpw fait open_input_file() → même fichier que -inp ; phonons utilisent aussi stdin/unit 5 relié à ph_control.

    `qha_lif` partage la même chaîne phonons → stdin.
    """
    w = (qe_what or "").strip().strip("'\"").lower()
    return w in _TERMO_PW_QHA_KEYS if False else w in _THERMO_PW_QHA_KEYS


def valid_thermo_pw_key(what_kw: str) -> bool:
    """Whitelist utilisateur pour le champ ``what=`` côté API.

    Couvre :
      * Les 5 profils de base + alias historique (QHA + scf_elastic).
      * L'extension P5 extras (piézo/magnéto/plot_bz/scf_dielectric).
      * Toute combinaison de transcription (« mur_lc_t_elastic_constants »,
        « elastic_constants », etc.) — limiter aux alias documentés ; on NE
        devine PAS de nouvelles combinaisons.
    """
    w = (what_kw or "").strip().strip("'\"").lower()
    return (
        w in _THERMO_PW_QHA_KEYS
        or w in _THERMO_PW_P5_EXTRAS
        or w in _THERMO_PW_LEGACY_WHAT_ALIASES
        or w in {
            "scf_elastic_constants",
            "mur_lc_elastic_constants",
        }
    )


def is_p5_extra_what(what_kw: str) -> bool:
    """True si le `what=` est un extra-thermo admissible pour P5 (pas de chaîne phonons)."""
    w = (what_kw or "").strip().strip("'\"").lower()
    return w in _THERMO_PW_P5_EXTRAS


def ensure_ph_control_for_thermo_pw(
    work_dir: Path, *, pw_in_basename: str
) -> None:
    """Pour mur_lc_t, mur_lc_disp, et l’alias API « mur_lc_t_elastic_constants » (réécrit en ``elastic_constants_geo``),
    thermo_pw ouvre ``ph_control`` (routine thermo_ph_readin).

    Souvent même contenu que ``ph.in`` ; si ``ph_control`` manque et ``ph.in`` existe, on copie sans
    écraser un fichier utilisateur déjà présent.
    """
    pctrl = work_dir / "ph_control"
    if pctrl.is_file():
        return
    ph_path = work_dir / "ph.in"
    if not ph_path.is_file():
        ok, msg = try_autogenerate_ph_in(
            work_dir, "ph.in", pw_basename=pw_in_basename, force=False
        )
        if not ok:
            raise FileNotFoundError(
                "Les tâches QHA (mur_lc_t, mur_lc_disp, alias mur_lc_t_elastic_constants) requièrent ph_control "
                "dans le dossier du run (phonons thermo_pw). "
                "Ajoutez-le à la main ou placez/abaissez une entrée phonon : absence de ph.in "
                f"({msg})"
            )
    if not ph_path.is_file():
        raise FileNotFoundError(
            "ph_control absent et ph.in introuvable — impossible de générer l’entrée phonon."
        )
    txt = normalize_ph_control_for_thermo_pw(
        ph_path.read_text(encoding="utf-8", errors="replace")
    )
    pctrl.write_text(txt, encoding="utf-8")


_RE_PSEUDO_DIR_PW_IN = re.compile(r"(?im)^\s*pseudo_dir\s*=\s*['\"]([^'\"]*)['\"]")


def _parse_pw_pseudo_dir_relative(work_dir: Path, pw_in: Path) -> Optional[Path]:
    """Répertoire pseudos sous work_dir si ``pseudo_dir`` est relatif dans l’entrée PW ; sinon None."""
    try:
        txt = pw_in.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    m = _RE_PSEUDO_DIR_PW_IN.search(txt)
    if not m:
        return None
    raw = (m.group(1) or "").strip()
    if not raw or Path(raw).is_absolute():
        return None
    target = (work_dir / raw).resolve()
    try:
        target.relative_to(work_dir.resolve())
    except ValueError:
        return None
    return target


def _parse_atomic_species_upf_names(txt: str) -> list[str]:
    names: list[str] = []
    lines = txt.splitlines()
    i = 0
    while i < len(lines):
        if re.match(r"(?i)^\s*ATOMIC_SPECIES\s*$", lines[i]):
            i += 1
            while i < len(lines):
                ls = lines[i].strip()
                if not ls or ls.startswith("&"):
                    break
                parts = ls.split()
                if len(parts) >= 3:
                    fn = parts[-1].strip()
                    if fn.lower().endswith(".upf"):
                        names.append(fn)
                i += 1
            break
        i += 1
    return names


def stage_missing_pseudos_for_pw_in(work_dir: Path, pw_in: Path) -> list[str]:
    """
    Copie les fichiers .UPF manquants depuis ``cfg.PSEUDOS_DIR`` lorsque ``pseudo_dir`` est relatif au run
    (ex. ``./pseudos/PBE/``). Sinon thermo_pw peut échouer tout de suite dans readpp.
    """
    notes: list[str] = []
    dest_dir = _parse_pw_pseudo_dir_relative(work_dir, pw_in)
    if dest_dir is None:
        return notes
    try:
        txt = pw_in.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return notes
    lib = cfg.PSEUDOS_DIR.resolve()
    if not lib.is_dir():
        notes.append(f"bibliothèque pseudos absente ou non répertoire : {lib} (THERMO_PSEUDOS_DIR)")
        return notes
    for fn in _parse_atomic_species_upf_names(txt):
        dest = dest_dir / fn
        if dest.is_file():
            continue
        src = lib / fn
        if not src.is_file():
            notes.append(f"non résolu : {fn} (absent de {lib})")
            continue
        try:
            dest_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
            notes.append(f"copié {fn}")
        except OSError as ex:
            notes.append(f"échec copie {fn}: {ex}")
    return notes


def run_thermo_pw_mpi(
    work_dir: Path,
    *,
    nproc: int,
    pw_in_basename: str = "pw_scf_V0_for_phonon.in",
    thermo_opts: Optional[dict] = None,
    clear_thermo_restart: bool = True,
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
    log_filename: str = "thermo_pw_run.out",
) -> Path:
    """Lance thermo_pw.x depuis work_dir avec thermo_control ; entrée PW en stdin ou ``-inp`` selon QE.

    ``log_filename`` permet de produire des journaux distincts par sous-étape
    (P5 extras : ``thermo_pw_<what>.out``). Défaut : le fichier canonique
    ``thermo_pw_run.out`` consumido par les parseurs live.
    """

    work_dir = wf1_eos_run_root(work_dir.resolve())
    pw_in = work_dir / pw_in_basename
    if not pw_in.is_file():
        raise FileNotFoundError(f"{pw_in_basename} absent dans {work_dir}")
    # (juillet 2026) refuse les drapeaux hors whitelist 7.x — AVANT
    # ``_purge_before_thermo_pw_mpi`` — pour ne pas effacer ``restart/`` ni
    # ``_temporary*`` si l'entrée est invalide (fail-fast sur thermo_opts).
    # ``run_thermo_pw_mpi`` est l'unique point d'entrée pour
    # ``POST /run_thermo_pw`` côté API/UI ; le helper lève ``ValueError`` avec
    # un message ciblé pour les fautes de frappe connues (ex. ``lband`` →
    # ``ltherm_freq``).
    validate_known_thermo_flags(thermo_opts)
    restart_cleared = False
    scratch_frags: list[str] = []
    if clear_thermo_restart:
        try:
            scratch_frags, restart_cleared = _purge_before_thermo_pw_mpi(work_dir)
        except Exception as ex:
            raise RuntimeError(
                "Impossible d’effacer les fichiers de reprise avant thermo_pw.x. "
                f"Supprimez à la main « restart » sous {work_dir} : {ex}"
            ) from ex
    prepseudo_notes = stage_missing_pseudos_for_pw_in(work_dir, pw_in)
    opts = normalize_thermo_opts(thermo_opts)
    # même défaut que write_thermo_control_minimal(..., what="mur_lc_t")
    what_api = (str(opts.get("what") or "").strip() or "mur_lc_t")
    opts["what"] = what_api
    what_api, original_what_kw, legacy_rewrite_note = canonicalize_thermo_what(
        what_api, opts
    )
    w_api_l = what_api.lower().strip("'\"").strip()
    # QE 7.x : C_ij(T) sur grille QHA = elastic_constants_geo + use_free_energy + elastic_algorithm ('energy').
    # L'UI peut envoyer soit mur_lc_t_elastic_constants soit elastic_constants_geo directement.
    alias_elastic_geo = w_api_l in ("mur_lc_t_elastic_constants", "elastic_constants_geo")
    if alias_elastic_geo and w_api_l == "mur_lc_t_elastic_constants":
        # thermo_pw 7.x n'a pas de what='mur_lc_t_elastic_constants' (thermo_summary → « what not programmed »).
        # C_ij(T) sur grille QHA : what='elastic_constants_geo' + use_free_energy (cf. guide / initialize_thermo_work).
        opts["what"] = "elastic_constants_geo"
    what_kw = opts["what"]
    if _elastic_what_normalizes_pw_cell(what_kw):
        _changed, _msg = rewrite_pw_cubic_ibrav0_for_elastic(pw_in)
        # journal minimal pour déboguer sans changer le comportement fonctionnel
        if _changed and _msg:
            dbg = work_dir / "thermo_pw_geom_normalize.txt"
            try:
                dbg.write_text(_msg + "\n", encoding="utf-8")
            except OSError:
                pass
    if _thermo_pw_what_needs_auto_ph_control(what_api):
        ensure_ph_control_for_thermo_pw(work_dir, pw_in_basename=pw_in_basename)
        if _thermo_pw_uses_stdin_pw_instead_of_inp(what_kw):
            _pc = work_dir / "ph_control"
            if _pc.is_file():
                raw_pc = _pc.read_text(encoding="utf-8", errors="replace")
                norm_pc = normalize_ph_control_for_thermo_pw(raw_pc)
                if norm_pc != raw_pc:
                    _pc.write_text(norm_pc, encoding="utf-8")
    fd_align = parse_fildyn_from_ph_any(work_dir)
    if fd_align:
        opts["fildyn"] = fd_align
    if "zasr" not in opts:
        z_align = resolve_zasr_for_thermo_pw(work_dir)
        if z_align:
            opts["zasr"] = z_align
    write_thermo_control_minimal(work_dir, geo_elastic_qha_phonon=alias_elastic_geo, **opts)
    tc = work_dir / "thermo_control"
    if not tc.is_file():
        raise RuntimeError("thermo_control non écrit")

    log = work_dir / log_filename
    m = which_mpirun()
    stdin_pw = _thermo_pw_uses_stdin_pw_instead_of_inp(what_kw)
    if stdin_pw:
        # mur_lc_* + elastic_constants_geo : phq_readin_tpw rouvre ce que -inp désigne ; il faut
        # passer l’entrée pw sur stdin comme thermo/examples (thermo_pw.x < pw.in sans -inp).
        args = [m, "-np", str(nproc), str(cfg.thermo_pw_path())]
    else:
        args = [m, "-np", str(nproc), str(cfg.thermo_pw_path()), "-inp", pw_in.name]
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    if clear_thermo_restart:
        if scratch_frags:
            scratch_desc = "; ".join(scratch_frags)
        else:
            scratch_desc = "aucun restart/ ni _temporary* à supprimer"
    else:
        scratch_desc = "omis (clear_thermo_restart=false)"
    rr_note = (
        "skipped (option false)"
        if not clear_thermo_restart
        else ("yes (e_work_part* supprimés)" if restart_cleared else "n/a (pas de dossier restart/)")
    )
    log_header = (
        "# thermo_pw run (via API/serveur)",
        f"# utc={ts}",
        f"# cwd={work_dir}",
        f"# pw_in={pw_in_basename} via {'stdin (sans -inp)' if stdin_pw else '-inp ' + pw_in.name}",
        f"# thermo_control what={opts.get('what')!r}",
        "# scratch_before_run: " + scratch_desc,
        "# restart_dir_cleared=" + rr_note,
    )
    if alias_elastic_geo:
        suf = (
            "requête API : mur_lc_t_elastic_constants → what=elastic_constants_geo (QE 7.x)"
            if w_api_l == "mur_lc_t_elastic_constants"
            else "what=elastic_constants_geo + use_free_energy / elastic_algorithm (bloc QHA)"
        )
        log_header = (*log_header, f"# {suf}")
    if legacy_rewrite_note:
        # Trace explicite de la réécriture legacy → canonique 7.x.
        log_header = (*log_header, f"# {legacy_rewrite_note}")
    if prepseudo_notes:
        try:
            (work_dir / "thermo_pw_staged_pseudos.txt").write_text(
                "\n".join(prepseudo_notes) + "\n", encoding="utf-8"
            )
        except OSError:
            pass
        log_header = (*log_header, "# pseudos_auto: " + " · ".join(prepseudo_notes)[:480])
    meta = "\n".join(log_header) + "\n\n"
    with open(log, "w", encoding="utf-8") as lf:
        lf.write(meta)
        lf.flush()
        if stdin_pw:
            with open(pw_in, "rb") as stdin_f:
                p = run_mpi_stdio_on_open_log(
                    args,
                    cwd=work_dir,
                    stdout_f=lf,
                    stdin_f=stdin_f,
                    cancel_event=cancel_event,
                    proc_holder=proc_holder,
                )
        else:
            p = run_mpi_stdio_on_open_log(
                args,
                cwd=work_dir,
                stdout_f=lf,
                stdin_f=None,
                cancel_event=cancel_event,
                proc_holder=proc_holder,
            )
    if cancel_event is not None and cancel_event.is_set():
        raise RuntimeError(API_CANCEL_RUNTIME_MSG)
    if p.returncode != 0:
        raw = log.read_text(encoding="utf-8", errors="replace") if log.is_file() else ""
        tail = _thermo_pw_fail_log_excerpt(raw, max_chars=_MAX_THERMO_PW_FAIL_EXCERPT_CHARS)
        tl = tail.lower()
        hint_parts: list[str] = []
        if "wrong celldm" in tl:
            hint_parts.append(
                "[thermo_pw / elastic] « wrong celldm(1) » : si maille cubique diagonale + ibrav=0, "
                "le serveur réécrit normalement en ibrav=1 avant le run (voir thermo_pw_geom_normalize.txt dans le dossier). "
                "Sinon, décrivez la maille avec ibrav/celldm ou adaptez la compatibilité QE."
            )
        if "readpp" in tl and ".upf" in tl and (
            "not found" in tl or "cannot open" in tl or "fatal error reading file" in tl
        ):
            hint_parts.append(
                "[pseudopotentiel] pw.x / thermo_pw ne trouve pas un fichier .UPF sous pseudo_dir (voir « ATOMIC_SPECIES » dans l’entrée PW). "
                "Pour une entrée avec pseudo_dir relatif (ex. ./pseudos/PBE/), le serveur tente désormais de copier les UPF "
                f"manquants depuis THERMO_PSEUDOS_DIR (« {cfg.PSEUDOS_DIR} » par défaut). "
                "Sinon copiez les fichiers à la main ou pointez pseudo_dir vers un répertoire absolu qui les contient."
            )
        if ("thermo_ph_readin" in tl or "error opening file ph_control" in tl) and "ph_control" in tl:
            hint_parts.append(
                "[QHA] thermo_pw doit ouvrir « ph_control » (entrée phonons). "
                "Placez ce fichier dans le dossier du run — en général après la chaîne ph.x "
                "(user guide §1.8–1.9). Sans lui, mur_lc_t / mur_lc_disp ou l’alias mur_lc_t_elastic_constants peuvent "
                "s’arrêter après l’EOS ou ne pas enchaîner phonons."
            )
        if "could not find namelist &inputph" in tl:
            hint_parts.append(
                "[phonons thermo_pw] « &inputph » introuvable après l’EOS : avec QE thermo_pw 7.x, l’entrée pw doit "
                "être lue depuis stdin et ph_control doit contenir une ligne titre avant « &inputph » "
                "(l’API le fait automatiquement pour mur_lc_t / mur_lc_disp / elastic_constants_geo)."
            )
        # Hint « what not programmed » piloté par les données : on émet la
        # valeur **actuellement dispatchée** (post-réécriture) plutôt qu'un
        # nom en dur. Si l'API a déjà tenté une réécriture (lignes
        # ``# legacy_alias_rewrite:`` en tête de log), on le mentionne pour
        # aider l'utilisateur à diagnostiquer un éventuel état stale.
        # Hint « what not programmed » piloté par les données : on émet
        # la valeur **actuellement dispatchée** + la valeur ORIGINALE
        # (pré-réécriture) si elles diffèrent. L'utilisateur voit ainsi
        # « j'avais envoyée X (réécrit en Y par l'API) ». Si l'API a
        # déjà tenté une réécriture (lignes ``# legacy_alias_rewrite:``
        # en tête de log), on le mentionne ici aussi.
        if "what not programmed" in tl and "thermo_summary" in tl:
            rewrite_trace = (
                f" (réécriture API : {legacy_rewrite_note})"
                if legacy_rewrite_note
                else " (pas de réécriture par l'API — vérifiez votre thermo_control sur disque)"
            )
            effective = (
                f"what='{original_what_kw}' (réécrit par l'API en what='{what_kw}')"
                if original_what_kw != what_kw
                else f"what='{what_kw}'"
            )
            hint_parts.append(
                f"[what] Vous aviez envoyé {effective}"
                f"{rewrite_trace}. Si cette valeur est rejetée par "
                "thermo_pw 7.x (thermo_summary → « what not programmed »), "
                "consultez les noms canoniques 7.x dans "
                "templates/thermo_control.template — l'API réécrit "
                "automatiquement les alias legacy ('thermo' → 'mur_lc_t', "
                "'piezoelectric_tensor' → 'scf_piezoelectric_tensor', "
                "'mur_lc_t_elastic_constants' → 'elastic_constants_geo'). "
                "Profil P5 : ε∞ extrait de ph.out (pas de what thermo_pw 7.5). "
                "Si le journal commence par des lignes « # thermo_pw run » "
                "récentes mais que vous voyez encore cette erreur, "
                "signalez-la ; sinon l'extrait peut provenir d'un ancien "
                ".out avant mise à jour de thermo_control — ouvrez le "
                "fichier complet sur disque après le dernier job."
            )
        if ("severe (24)" in tl or "end-of-file during read" in tl) and (
            "restart" in tl or "e_work_part" in tl
        ):
            hint_parts.append(
                "[restart] Fin de fichier en lisant restart/e_work_part.* : checkpoints incompatibles "
                "(run interrompu, ou nombre MPI différent du run précédent). Effacez le dossier « restart » sous le run "
                "et relancez. — Les lancements via POST /run_thermo_pw effacent « restart » par défaut sauf corps JSON "
                "« clear_thermo_restart » : false."
            )
        if "severe (28)" in tl or "close_buffer" in tl or ("forrtl" in tl and "operation not permitted" in tl):
            hint_parts.append(
                "[stdin / OPEN] Crash forrtl 28 : autres tâches thermo_pw (hors mur_lc_* phonons avec ph_control) utilisent « -inp ». "
                "Pour mur_lc_t / mur_lc_disp / elastic_constants_geo, l’API envoie l’entrée pw sur stdin comme les exemples Dal Corso."
            )
        if ("severe (71)" in tl or "integer divide by zero" in tl) and "frc_blk" in tl:
            hint_parts.append(
                "[matdyn / write_ph_freq] forrtl 71 dans frc_blk — souvent **grille IFC trop courte** "
                "(ex. ``nq1=nq2=nq3=2`` avec thermo_pw 7.x + ``mur_lc_disp``). "
                "L’API remonte désormais toute grille « 2 × 2 × 2 » vers **≥ 4 × 4 × 4** dans ``ph_control`` au prochain POST ; "
                "relancez le job après **redémarrage du serveur**. "
                "En secours : régénérez phonons après suppression de ``dynamical_matrices/ph_dyn*``, ou ``mpirun -np 1`` ; "
                "correctif compilateur QE évoqué ci‑dessous.\n\n"
                "Détail (sources QE) : après ``nr1=nq1…`` dans ``matdyn_sub.f90``, certaines compilations peuvent passer "
                "à ``nq*=0`` en mémoire ; patch possible avec ``SIZE(frc,1…3)`` puis recompilation de ``thermo_pw.x``."
            )
        if "dgels" in tl or "linsolvms" in tl or "linsolvsvd" in tl or "parameter 7 was incorrect" in tl or "parameter 6 was incorrect" in tl:
            hint_parts.append(
                "[QHA / anharmonic] Échec dans la résolution aux moindres carrés (DGELS / linsolvms) pendant "
                "« anharmonic properties » avec **DOS phonons** (``ltherm_dos``). Souvent : EOS / volumes, "
                "fichiers ``phdisp_files/output_dos.dat.g*`` ou grille température mal calibrée. "
                "**Essais** : plus de volumes sur la courbe EOS, élargir ``deltat`` (moins de points T), "
                "``mpirun -np 1``, ou passer en **fréquences** si la chaîne le permet : ``ltherm_freq=.true.`` "
                "et ``ltherm_dos=.false.`` dans ``thermo_control`` (puis relancer). "
                "Vérifier aussi l’absence de DOS / fréquences aberrantes (zéros, NaN). "
                "Une autre pile BLAS/LAPACK (OpenBLAS au lieu de MKL) peut parfois éviter ce coin numérique."
            )
        hints = "".join("\n\n" + h for h in hint_parts)
        core = f"thermo_pw.x code {p.returncode} — voir {log}"
        one_l = _thermo_pw_fail_one_liner(tail)
        lead = f"Cause (journal) : {one_l}\n\n" if one_l else ""
        raise RuntimeError(
            lead + (hints + "\n\n" if hints else "") + core + "\n--- fin du journal (tronquée) ---\n" + tail
        )
    return log


# =============================================================================
# Juin 2026 — indicateur de stabilité dynamique à partir de matdyn.x.
# =============================================================================
# Le pipeline « 5 profils » (P1..P5) expose désormais un indicateur de
# stabilité dynamique au niveau de **chaque** profil, dans le même
# `expected_results.metrics` que le gap électronique. C'est un *contrat UI*
# uniforme (mêmes 3 clés pour P1=P5) ; pour P1/P3 ces 3 valeurs restent
# `None` car ces profils ne font PAS tourner la chaîne phonon
# (`needs_phonons=False`) — l'UI montre alors « N/A : chaîne phonon non
# requise pour ce profil ». Pour P2/P3/P4/P5 (matdyn.x a tourné), le parser
# lit `matdyn_bands.out` (prioritaire, cm-1 natif, marqueur
# `(***ima***)` explicite) puis bascule sur ``phonon.freq`` :
#   * format bandes matdyn (``&plot`` + paires q/fréquences en cm⁻¹) ;
#   * format blocs ``q =`` (cm⁻¹) ;
#   * repli legacy une-fréquence-par-ligne (THz → cm⁻¹).
#
# Tolérance : on considère comme « imaginaire » tout mode `freq < -0.5 cm-1`
# après conversion. C'est le seuil standard pour discriminer le bruit
# numérique des modes acoustiques en Γ dans les chaînes phonon DFPT
# (4×4×4 + q2r 'simple') ; les branches acoustiques d'un cristal bien
# relaxé valent typiquement 0 ± 0.5 cm-1 — voir aussi
# phonopy / phononDFT pour la même convention « stable » vs « imaginary ».
# =============================================================================

# Cm⁻¹ / THz (facteur de conversion, NIST CODATA).
_CM1_PER_THZ = 33.35641

# Regex matdyn.x bandes : "freq ( N) = ±<value>[ (***ima***)] cm-1".
# Robuste aux espaces variables, à la notation scientifique optionnelle,
# et au marqueur `(***ima***)` qui peut suivre le signe ou la valeur.
_MATDYN_BANDS_FREQ_RE = re.compile(
    r"freq\s*\(\s*\d+\s*\)\s*=\s*"
    r"([+-]?\d+\.?\d*(?:[eE][-+]?\d+)?)\s*"
    r"(?:\(\*\*\*ima\*\*\*\))?\s*"
    r"cm-1",
    re.IGNORECASE,
)


def _dyn_stability_summary(
    freqs_cm_minus_1: list[float],
    tol_cm_minus_1: float,
    *,
    source: str,
) -> dict[str, Any]:
    """Calcule les 3 métriques UI + diagnostics à partir d'une liste de fréquences.

    Args:
        freqs_cm_minus_1 : fréquences extraites (cm-1), signes préservés.
        tol_cm_minus_1   : seuil sous lequel un mode est dit « imaginaire »
                          (défaut -0.5 cm-1).
        source           : chemin du fichier source (diag/log uniquement).

    Returns:
        Dict avec `dynamically_stable`, `n_imaginary_modes`, `min_freq_cm-1`,
        `n_modes_total`, `source`. Toujours non-vide si la liste contient ≥ 1
        fréquence (les valeurs 0/None sont autorisées « en place » mais
        shape fixe).
    """
    n_total = len(freqs_cm_minus_1)
    if n_total == 0:
        return {
            "dynamically_stable": True,
            "n_imaginary_modes": 0,
            "min_freq_cm-1": 0.0,
            "n_modes_total": 0,
            "source": source,
        }
    min_f = min(freqs_cm_minus_1)
    n_imag = sum(1 for f in freqs_cm_minus_1 if f < tol_cm_minus_1)
    return {
        "dynamically_stable": bool(n_imag == 0),
        "n_imaginary_modes": int(n_imag),
        "min_freq_cm-1": float(min_f),
        "n_modes_total": int(n_total),
        "source": source,
    }


def _parse_matdyn_bands_out_for_stability(
    path: Path,
    tol_cm_minus_1: float,
) -> Optional[dict[str, Any]]:
    """Lit `matdyn_bands.out` (cm-1, marqueur `(***ima***)` explicite).

    Le parser identifie chaque ligne `freq ( N) = ±v [ (***ima***)] cm-1`,
    extrait la valeur flottante avec signe, et la stocke telle quelle
    (matdyn émet déjà la valeur négative pour les modes imaginaires :
    `freq (  2) =    -7.8941 (***ima***) cm-1`).

    Renvoie None si le fichier est vide ou sans aucune fréquence lisible —
    l'appelant retombe alors sur `phonon.freq` (via `parse_matdyn_dynamic_stability`).
    """
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    freqs: list[float] = []
    for m in _MATDYN_BANDS_FREQ_RE.finditer(raw):
        try:
            freqs.append(float(m.group(1)))
        except (ValueError, TypeError):
            continue
    if not freqs:
        return None
    return _dyn_stability_summary(freqs, tol_cm_minus_1, source=str(path.name))


_CM1_PER_THZ = 33.35641

_PHONON_FLOAT_RE = re.compile(
    r"[-+]?(?:\d*\.\d+|\d+(?:\.\d*)?)(?:[eE][-+]?\d+)?"
)


def _phonon_floats_in_line(line: str) -> list[float]:
    return [float(x) for x in _PHONON_FLOAT_RE.findall(line)]


def _parse_nbnd_from_phonon_freq_header(lines: list[str]) -> Optional[int]:
    """Lit ``nbnd`` dans le namelist ``&plot`` en tête de ``phonon.freq``."""
    buf: list[str] = []
    in_plot = False
    for ln in lines[:220]:
        if not in_plot:
            if "&plot" in ln.lower():
                in_plot = True
                buf.append(ln)
            continue
        buf.append(ln)
        if "/" in ln:
            break
        if len(buf) > 25:
            break
    if not buf:
        return None
    m = re.search(r"nbnd\s*=\s*(\d+)", "\n".join(buf), flags=re.I)
    return int(m.group(1)) if m else None


def _infer_nmodes_from_matdyn_plot(lines: list[str]) -> Optional[int]:
    """Déduit le nombre de modes depuis la 1re ligne de fréquences après un q."""
    expecting_q = False
    seen_plot = False
    for ln in lines:
        s = ln.strip()
        if not s or s.startswith("!"):
            continue
        if "&plot" in ln.lower():
            seen_plot = True
            expecting_q = True
            continue
        if not seen_plot or s.startswith("&"):
            continue
        nums = _phonon_floats_in_line(s)
        if expecting_q:
            if len(nums) >= 4:
                expecting_q = False
            continue
        if nums:
            return len(nums)
    return None


def _extract_freqs_matdyn_plot_cm1(lines: list[str], nmodes: int) -> list[float]:
    """Format bandes matdyn : alternance ligne q (4 floats) + fréquences (cm⁻¹)."""
    start: Optional[int] = None
    for i, ln in enumerate(lines):
        if "&plot" in ln.lower():
            start = i + 1
            break
    if start is None:
        return []

    all_freqs: list[float] = []
    expecting_q = True
    buf: list[float] = []
    i = start
    while i < len(lines):
        ln_a = lines[i].strip()
        if not ln_a or ln_a.startswith("!"):
            i += 1
            continue
        if ln_a.startswith("&"):
            break
        nums = _phonon_floats_in_line(ln_a)
        if expecting_q:
            if len(nums) < 4:
                break
            buf = []
            expecting_q = False
            i += 1
            continue
        if not nums:
            break
        buf.extend(nums)
        if len(buf) >= nmodes:
            all_freqs.extend(buf[:nmodes])
            buf = []
            expecting_q = True
        i += 1
    return all_freqs


def _split_phonon_freq_q_blocks(lines: list[str]) -> list[list[str]]:
    """Découpe ``phonon.freq`` aux lignes ``q =`` (format bloc legacy matdyn)."""
    blocks: list[list[str]] = []
    cur: list[str] = []
    for line in lines:
        if re.match(r"^\s*q\s*=\s*$", line.strip()):
            if cur:
                blocks.append(cur)
            cur = []
            continue
        cur.append(line)
    if cur:
        blocks.append(cur)
    return blocks


def _freqs_cm1_one_q_block(block_lines: list[str], nmodes: int) -> list[float]:
    """Extrait les fréquences (cm⁻¹) d'un bloc ``q =``."""
    cleaned = [ln for ln in block_lines if ln.strip()]
    start_i = 0
    for i, ln in enumerate(cleaned):
        nums = _phonon_floats_in_line(ln)
        if len(nums) >= 3:
            start_i = i + 1
            break
    else:
        return []

    out: list[float] = []
    for ln in cleaned[start_i:]:
        nums = _phonon_floats_in_line(ln)
        if not nums:
            continue
        if "q =" in ln.lower():
            break
        if len(nums) >= 2:
            out.append(nums[-1])
        elif len(nums) == 1:
            out.append(nums[0])
        if len(out) >= nmodes:
            break
    return out[:nmodes]


def _extract_freqs_q_block_cm1(lines: list[str], nmodes: int) -> list[float]:
    blocks = _split_phonon_freq_q_blocks(lines)
    if not blocks:
        return []
    freqs: list[float] = []
    for blk in blocks:
        part = _freqs_cm1_one_q_block(blk, nmodes)
        if part:
            freqs.extend(part)
    return freqs


def _extract_freqs_legacy_thz_lines(lines: list[str]) -> list[float]:
    """Ancien format : une fréquence THz par ligne (sans bloc q/fréq)."""
    freqs: list[float] = []
    for line in lines:
        s = line.strip()
        if not s or s.startswith("#") or s.startswith("!") or s.startswith("&"):
            continue
        tok = s.split()[0]
        try:
            freqs.append(float(tok))
        except ValueError:
            continue
    return freqs


def _collect_frequencies_cm1_from_phonon_freq(lines: list[str]) -> tuple[list[float], str]:
    """Retourne (fréquences cm⁻¹, sous-format détecté)."""
    nbnd = _parse_nbnd_from_phonon_freq_header(lines)
    nmodes = nbnd if nbnd and nbnd > 0 else _infer_nmodes_from_matdyn_plot(lines)

    has_plot = any("&plot" in ln.lower() for ln in lines[:220])
    if has_plot:
        nm = int(nmodes) if nmodes else 6
        freqs = _extract_freqs_matdyn_plot_cm1(lines, nm)
        if freqs:
            return freqs, "phonon.freq:matdyn_plot_cm-1"

    has_q_blocks = any(re.match(r"^\s*q\s*=\s*$", ln.strip()) for ln in lines)
    if has_q_blocks:
        nm = int(nmodes) if nmodes else 6
        freqs = _extract_freqs_q_block_cm1(lines, nm)
        if freqs:
            return freqs, "phonon.freq:q_blocks_cm-1"

    freqs_thz = _extract_freqs_legacy_thz_lines(lines)
    if freqs_thz:
        return [f * _CM1_PER_THZ for f in freqs_thz], "phonon.freq:legacy_thz"

    return [], "phonon.freq:empty"


def _parse_phonon_freq_for_stability(
    path: Path,
    tol_cm_minus_1: float,
) -> Optional[dict[str, Any]]:
    """Lit ``phonon.freq`` et extrait les fréquences en cm⁻¹.

    Formats supportés (ordre de détection) :

    1. **Bandes matdyn** (``&plot nbnd=…``) : paires (coordonnées q, 4 floats)
       + ligne(s) de fréquences déjà en **cm⁻¹** — format standard des
       dispersions après ``matdyn.x`` avec ``flfrq='phonon.freq'``.
       Les coordonnées q négatives le long du chemin Γ→X→… ne sont **pas**
       des fréquences.

    2. **Blocs ``q =``** : fréquences en cm⁻¹ par point q (legacy matdyn).

    3. **Legacy** : une fréquence **THz** par ligne → conversion × ``_CM1_PER_THZ``.
    """
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    lines = raw.splitlines()
    freqs_cm1, _fmt = _collect_frequencies_cm1_from_phonon_freq(lines)
    if not freqs_cm1:
        return None
    summary = _dyn_stability_summary(
        freqs_cm1, tol_cm_minus_1, source=str(path.name)
    )
    return summary


def parse_matdyn_dynamic_stability(
    work_dir: Path,
    *,
    tolerance_cm_minus_1: float = -0.5,
) -> Optional[dict[str, Any]]:
    """Indicateur de stabilité dynamique à partir des sorties matdyn.x.

    Source prioritaire : ``matdyn_bands.out`` (cm-1, marqueur ``(***ima***)``
    explicite). Fallback : ``phonon.freq`` — bandes matdyn (cm⁻¹), blocs
    ``q =``, ou legacy THz (× ``_CM1_PER_THZ``).

    Args:
        work_dir : répertoire de run (typiquement
                   ``wf1_eos_run_root(work_dir.resolve())``).
        tolerance_cm_minus_1 : seuil sous lequel un mode est « imaginaire »
            (défaut ``-0.5`` cm-1 : convention standard pour discriminer le
            bruit numérique des branches acoustiques au point Γ).

    Returns:
        Dict :
            * ``dynamically_stable`` : ``True`` si ``n_imaginary_modes == 0``.
            * ``n_imaginary_modes`` : nombre de modes strictement sous
              ``tolerance_cm_minus_1``.
            * ``min_freq_cm-1`` : fréquence la plus basse (cm-1) — peut
              être négative pour les matériaux mécaniquement instables.
            * ``n_modes_total`` : nombre total de modes parsés (toute la
              dispersion + tous les modes par q-point).
            * ``source`` : nom du fichier source pour traçabilité diag.
        Renvoie ``None`` si aucun des deux fichiers n'est présent ou si
        les deux sont vides / illisibles — c'est le cas typique pour
        ``PipelineJob`` P1/P3 (``needs_phonons=False``, matdyn.x jamais
        lancé). L'appelant ``PipelineJob._intermediate_parse`` NE TOUCHE
        alors PAS aux 3 clés ``properties.dynamically_stable`` /
        ``properties.n_imaginary_modes`` / ``properties.min_freq_cm-1`` :
        elles restent ``None`` (matérialisées par
        ``_init_results_for_profile`` en prévision « au niveau tous les pi »).

    Notes:
        * Le parser ne lance AUCUN calcul — purement lecture disque, sûr
          dans ``_intermediate_parse`` (appelé après chaque sous-étape
          depuis ph.x jusqu'à matdyn.dos).
        * Tolérance configurable : un matériau avec branches acoustiques
          très bruitées (nq1=nq2=nq3=2 sans extrapolation) peut mériter
          ``tolerance_cm_minus_1=-1.0`` ; pour les chaînes standards
          4×4×4 + ``asr='simple'``, ``-0.5`` suffit.
        * Format ``phonon.freq`` peut varier légèrement entre versions QE
          (commentaires en tête possibles) — le préfixe ``#`` / ``!`` est
          strippé à titre défensif.
    """
    work_dir = Path(work_dir).expanduser().resolve()
    bands_out = work_dir / "matdyn_bands.out"
    if bands_out.is_file():
        r = _parse_matdyn_bands_out_for_stability(bands_out, tolerance_cm_minus_1)
        if r is not None:
            return _attach_verification_recommendations(r, work_dir)
    freq_file = work_dir / "phonon.freq"
    if freq_file.is_file():
        r = _parse_phonon_freq_for_stability(freq_file, tolerance_cm_minus_1)
        if r is not None:
            return _attach_verification_recommendations(r, work_dir)
    return None


def _attach_verification_recommendations(
    dyn_summary: dict[str, Any],
    work_dir: Path,
) -> dict[str, Any]:
    """Enrichit le verdict ``dyn_summary`` avec des recommandations de vérification.

    Juillet 2026 — quand ``n_imaginary_modes > 0``, on appelle le module
    ``phonon_imaginary_recommendations`` qui inspecte les artefacts du
    work_dir (lecture-seule) pour générer une liste de suggestions
    actionables — pseudopotentiels alternatifs, durcissement de tr2_ph,
    augmentation du q-grid, ASR 'crystal', cross-validation phonopy, etc.

    Le résultat fusionné garantit que la fiche technique et le marker
    ``pipeline_api_job_state.json`` exposent **simultanément** :
      1. le verdict quantitatif (``n_imaginary_modes``, ``omega_min`` …),
      2. la liste structurée de causes probables et de remèdes.

    Le bloc ``verification_recommendations`` est *toujours* présent (même
    s'il est vide) pour garantir un schéma stable côté UI / snapshot
    tests ; ``has_imaginary`` y indique si on était dans le cas pathologue.
    """
    out = dict(dyn_summary)  # shallow copy : pas de muter l'entrée appelant.
    recs = build_phonon_imaginary_recommendations(
        work_dir=work_dir,
        results={"properties": out},
    )
    out["verification_recommendations"] = recs
    return out

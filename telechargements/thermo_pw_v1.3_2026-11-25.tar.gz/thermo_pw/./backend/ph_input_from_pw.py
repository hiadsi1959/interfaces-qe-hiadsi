"""
Génère un ph.in minimal à partir de pw_scf_V0_for_phonon.in (même prefix / outdir).
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Optional, Tuple

_RE_PREFIX = re.compile(
    r"^\s*prefix\s*=\s*['\"]([^'\"]+)['\"]", re.IGNORECASE | re.MULTILINE
)
_RE_OUTDIR = re.compile(
    r"^\s*outdir\s*=\s*['\"]([^'\"]+)['\"]", re.IGNORECASE | re.MULTILINE
)
_RE_INPUTPH_START = re.compile(r"(?mi)^\s*&inputph\b")
_RE_NQ_LINE = re.compile(r"(?mi)^(?P<lead>\s*nq(?P<id>[123])\s*=\s*)(?P<num>\d+)" )
_RE_OUTDIR_LINE = re.compile(
    r"(?mi)^[ \t]*outdir[ \t]*=[ \t]*['\"][^'\"]*['\"][ \t]*,?[ \t]*\r?\n"
)

# thermo_pw 7.x mur_lc_disp / mur_lc_t : grille 2×2×2 provoque souvent forrtl 71 (frc_blk) dans matdyn_sub.
_PH_Q_MESH_MIN_FOR_MATDYN = 4

# Carte QE 7+ : HUBBARD {atomic|ortho-atomic|...}  (aussi parentheses).
_RE_HUBBARD_CARD = re.compile(
    r"(?im)^\s*HUBBARD\s*[({]\s*([a-z0-9_-]+)\s*[)}]"
)
# Projecteurs incompatibles avec DFPT (ph.x) — voir PHonon/PH/phq_readin.f90.
_HUBBARD_DFPT_UNSUPPORTED = frozenset({
    "ortho-atomic",
    "ortho_atomic",
    "norm-atomic",
    "norm_atomic",
    "wf",
    "pseudo",
})


def coerce_ph_q_grid_minimum(
    text: str,
    *,
    min_when_coarse: int = _PH_Q_MESH_MIN_FOR_MATDYN,
    coarse_threshold: int = 2,
) -> tuple[str, bool]:
    """
    Si chaque ``nq1,nq2,nq3 ≤ coarse_threshold``, remonte à au moins ``min_when_coarse``
    pour éviter matdyn_interp / frc_blk (divide by zero) avec thermo_pw 7.x.
    """
    if not text.strip():
        return text, False
    found: dict[int, int] = {}
    for m in _RE_NQ_LINE.finditer(text):
        qi = int(m.group("id"))
        found[qi] = int(m.group("num"))
    if len(found) != 3 or max(found.values()) > coarse_threshold:
        return text, False

    def _repl(m: re.Match[str]) -> str:
        n = max(int(m.group("num")), min_when_coarse)
        return m.group("lead") + str(n)

    out = _RE_NQ_LINE.sub(_repl, text)
    return out, True


def strip_outdir_for_thermo_pw(text: str) -> Tuple[str, Optional[str]]:
    """Retire ``outdir`` du ``&inputph`` destiné à thermo_pw. Renvoie (texte, valeur ôtée).

    thermo_pw appelle ``set_outdir_name(igeom)`` (``tools/src/set_files_names.f90``),
    qui redirige ``outdir`` vers ``<outdir_pw>/g<N>/`` avant chaque géométrie, **puis**
    lit ``ph_control`` via ``phq_readin_tpw``. Un ``outdir`` explicite dans le namelist
    écrase donc cette redirection, et les neuf géométries relisent les fonctions d'onde
    du seul volume d'équilibre : fréquences identiques, paramètres de Grüneisen nuls,
    dilatation thermique nulle, et ajustement QHA final singulier (abandon dans DGELS).
    Les ``ph_control`` des exemples thermo_pw ne déclarent jamais ``outdir``.

    Ne s'applique qu'à ``ph_control``. Un ``ph.in`` autonome, lui, en a besoin.
    """
    if not text or not text.strip():
        return text, None
    m = _RE_INPUTPH_START.search(text)
    if not m:
        return text, None
    head, body = text[: m.start()], text[m.start() :]
    found = _RE_OUTDIR.search(body)
    if not found:
        return text, None
    return head + _RE_OUTDIR_LINE.sub("", body), found.group(1)


def normalize_ph_control_for_thermo_pw(text: str) -> str:
    """
    thermo_pw / phq_readin_tpw attend une première ligne titre (voir exemples QE,
    cf. dalcorso/example24/ph_control « ph_title ») avant ``&inputph``. Les commentaires !
    ne suffisent pas : la lecture ligne titre consomme quand même une ligne littérale.
    Insère « thermo_pw_ph » avant ``&inputph`` s’il n’existe aucune ligne « titre » avant le namelist.
    """
    if not text or not text.strip():
        return text
    text, _ = strip_outdir_for_thermo_pw(text)
    m = _RE_INPUTPH_START.search(text)
    if not m:
        return text
    before = text[: m.start()].splitlines()
    has_title = False
    for ln in before:
        s = ln.strip()
        if not s or s.startswith("!"):
            continue
        if s.startswith("&"):
            break
        has_title = True
        break
    if has_title:
        t2, _ = coerce_ph_q_grid_minimum(text)
        return t2
    insert = "thermo_pw_ph\n\n"
    text_out = text[: m.start()] + insert + text[m.start() :]
    text_out, _ = coerce_ph_q_grid_minimum(text_out)
    return text_out


def parse_prefix_outdir_from_pw_text(text: str) -> Tuple[Optional[str], Optional[str]]:
    pm = _RE_PREFIX.search(text)
    om = _RE_OUTDIR.search(text)
    return (pm.group(1) if pm else None, om.group(1) if om else None)


# Défaut pipeline : 1e-12 (rapide / tests). Publication : resserrer à 1e-14 ou 1e-15.
_DEFAULT_TR2_PH = "1.0d-12"

# Presets UI « exact vs rapide » (nov. 2026).
# Clé → (nq isotrope, tr2_ph, libellé court).
PHONON_PRESETS: dict[str, dict[str, Any]] = {
    "gamma": {
        "nq": 1,
        "tr2_ph": "1.0d-12",
        "label_fr": "Γ seul — stabilité (le plus rapide)",
        "label_en": "Γ only — stability (fastest)",
    },
    "fast": {
        "nq": 2,
        "tr2_ph": "1.0d-12",
        "label_fr": "2×2×2 — test rapide",
        "label_en": "2×2×2 — fast test",
    },
    "standard": {
        "nq": 4,
        "tr2_ph": "1.0d-12",
        "label_fr": "4×4×4 — standard (défaut)",
        "label_en": "4×4×4 — standard (default)",
    },
    "publish": {
        "nq": 6,
        "tr2_ph": "1.0d-14",
        "label_fr": "6×6×6 — publication (précis)",
        "label_en": "6×6×6 — publication (accurate)",
    },
}


def normalize_tr2_ph(raw: Any, default: str = _DEFAULT_TR2_PH) -> str:
    """Accepte ``1e-12``, ``1.0d-12``, ``1.0E-14`` → forme Fortran ``1.0d-XX``."""
    if raw is None or raw is False:
        return default
    s = str(raw).strip().lower().replace(" ", "")
    if not s:
        return default
    s = s.replace("e-", "d-").replace("e+", "d+")
    if re.fullmatch(r"1(\.0)?d-\d+", s):
        # Normalise en 1.0d-N
        n = s.split("d-")[-1]
        return f"1.0d-{n}"
    m = re.fullmatch(r"1(\.0)?[de]-\d+", str(raw).strip().lower())
    if m:
        n = re.split(r"[de]-", str(raw).strip().lower())[-1]
        return f"1.0d-{n}"
    # Valeur déjà style Fortran libre
    if re.search(r"\d", s):
        return str(raw).strip()
    return default


def resolve_phonon_settings(data: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """Déduit ``(nq1,nq2,nq3)``, ``tr2_ph`` et ``preset`` depuis un body / query.

    Priorité : ``phonon_preset`` → sinon ``phonon_nq`` / ``nq*`` → défaut standard.
    ``tr2_ph`` explicite écrase celui du preset.
    """
    data = data or {}
    preset = str(data.get("phonon_preset") or data.get("preset") or "").strip().lower()
    if preset in PHONON_PRESETS:
        n = int(PHONON_PRESETS[preset]["nq"])
        nq = (n, n, n)
        tr2 = str(PHONON_PRESETS[preset]["tr2_ph"])
    else:
        preset = "custom" if (
            data.get("phonon_nq") or data.get("nq") or data.get("nq1") or data.get("tr2_ph")
        ) else "standard"
        try:
            n_iso = int(data.get("phonon_nq") or data.get("nq_iso") or 0)
        except (TypeError, ValueError):
            n_iso = 0
        if n_iso >= 1:
            nq = (n_iso, n_iso, n_iso)
        else:
            nq = nq_from_request_body(data)
        tr2 = _DEFAULT_TR2_PH
        # Heuristique : grille dense → tr2 plus serré si non fourni
        if min(nq) >= 6 and data.get("tr2_ph") is None:
            tr2 = "1.0d-14"
    if data.get("tr2_ph") is not None and str(data.get("tr2_ph")).strip() != "":
        tr2 = normalize_tr2_ph(data.get("tr2_ph"), default=tr2)
    else:
        tr2 = normalize_tr2_ph(tr2)
    return {
        "preset": preset if preset in PHONON_PRESETS or preset == "custom" else "standard",
        "nq": nq,
        "tr2_ph": tr2,
    }


def detect_hubbard_projectors(scf_text: Optional[str]) -> Optional[str]:
    """Type de projecteurs de la carte ``HUBBARD {…}``, ou None si absente."""
    if not scf_text:
        return None
    m = _RE_HUBBARD_CARD.search(scf_text)
    if not m:
        return None
    return m.group(1).strip().lower().replace("_", "-")


def hubbard_dfpt_blocker_message(scf_text: Optional[str]) -> Optional[str]:
    """Message d'erreur si DFT+U est incompatible avec DFPT (ph.x / thermo_pw).

    ``HUBBARD {ortho-atomic}`` (et variants) fait planter ph.x avec :
    « The phonon code for this Hubbard projectors type is not implemented ».
    Seul ``{atomic}`` est supporté (cf. PHonon/example/example18).
    """
    proj = detect_hubbard_projectors(scf_text)
    if not proj or proj == "atomic":
        return None
    if proj not in _HUBBARD_DFPT_UNSUPPORTED:
        return None
    return (
        f"DFT+U : HUBBARD {{{proj}}} est incompatible avec les phonons DFPT "
        f"(ph.x / thermo_pw). Remplacez par « HUBBARD {{atomic}} » dans scf.in, "
        f"puis relancez SCF + phonons. "
        f"(Erreur QE typique : « Hubbard projectors type is not implemented ».)"
    )


def read_scf_text_for_hubbard_check(
    work_dir: Optional[Path] = None,
    pw_path: Optional[Path] = None,
) -> str:
    """Lit le premier scf.in utile pour le contrôle Hubbard / DFPT."""
    candidates: list[Path] = []
    if pw_path is not None:
        candidates.append(Path(pw_path))
    if work_dir is not None:
        wd = Path(work_dir)
        candidates.extend(
            [
                wd / "pw_scf_V0_for_phonon.in",
                wd / "scf_eq.in",
                wd / "scf.in",
            ]
        )
    for p in candidates:
        try:
            if p.is_file():
                return p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
    return ""


def scf_phonon_advice(
    *,
    ibrav: Optional[int],
    nat: int,
    nq: tuple[int, int, int] = (4, 4, 4),
    profile_needs_eos: bool = False,
    scf_text: Optional[str] = None,
) -> list[str]:
    """Conseils actionnables pour un scf.in + choix de grille q."""
    tips: list[str] = []
    block = hubbard_dfpt_blocker_message(scf_text)
    if block:
        tips.append("⛔ " + block)
    else:
        proj = detect_hubbard_projectors(scf_text)
        if proj == "atomic":
            tips.append(
                "DFT+U : HUBBARD {atomic} — compatible DFPT (ph.x). "
                "Les valeurs U peuvent différer légèrement d’ortho-atomic."
            )
    if ibrav is not None and int(ibrav) == 0:
        tips.append(
            "ibrav=0 : préférez ibrav>0 (ex. cubique ibrav=1 + celldm) — "
            "meilleure symétrie, ETA et DFPT plus fiables."
        )
    n_q = max(1, int(nq[0])) * max(1, int(nq[1])) * max(1, int(nq[2]))
    if nat >= 16 and min(nq) >= 4:
        tips.append(
            f"Maille large (nat={nat}) + q={nq[0]}×{nq[1]}×{nq[2]} : "
            "DFPT peut prendre des semaines/mois en local. "
            "Essayez le preset « Γ seul » ou « 2×2×2 » pour un test, "
            "ou cochez « sans DFPT » sur P1/P5."
        )
    elif nat >= 16 and min(nq) >= 2:
        tips.append(
            f"Maille large (nat={nat}) : même en 2×2×2 le DFPT reste lourd. "
            "Preset « Γ seul » recommandé pour la stabilité dynamique."
        )
    if profile_needs_eos and min(nq) < 4:
        tips.append(
            "Profil QHA (P2–P4) : une grille q < 4×4×4 sera remontée à ≥ 4 "
            "pour thermo_pw (matdyn 7.x). Le premier ph.x garde votre grille."
        )
    if n_q == 1:
        tips.append(
            "Preset Γ : idéal pour vérifier l’absence de modes imaginaires ; "
            "pas suffisant pour une DOS / QHA de publication."
        )
    return tips


def try_autogenerate_ph_in(
    work_dir: Path,
    ph_basename: str = "ph.in",
    *,
    pw_basename: str = "pw_scf_V0_for_phonon.in",
    nq1: int = 4,
    nq2: int = 4,
    nq3: int = 4,
    tr2_ph: str = _DEFAULT_TR2_PH,
    force: bool = False,
) -> tuple[bool, str]:
    """
    Si ``ph_basename`` est absent (ou ``force``), le crée d’après le .pw du run.
    Renvoie (True, message) en cas de succès, (False, raison) sinon.

    ``tr2_ph`` défaut ``1.0d-12`` (compromis durée / précision). Pour une
    publication ou des modes acoustiques délicats, passer ``1.0d-14``.
    """
    work_dir = Path(work_dir)
    ph_path = work_dir / ph_basename
    if ph_path.is_file() and not force:
        return True, ""
    pw_path = work_dir / pw_basename
    if not pw_path.is_file():
        return (
            False,
            f"Ni {ph_basename!r} ni {pw_basename!r} — lancez d’abord l’EOS (fit) pour produire {pw_basename!r}, "
            f"ou créez {ph_basename!r} à la main (Howto 1.8).",
        )
    text = pw_path.read_text(encoding="utf-8", errors="replace")
    prefix, outdir = parse_prefix_outdir_from_pw_text(text)
    if not prefix or not outdir:
        return (
            False,
            f"Impossible de lire prefix/outdir dans {pw_basename!r} — éditez {ph_basename!r} manuellement.",
        )
    nq1 = max(1, int(nq1))
    nq2 = max(1, int(nq2))
    nq3 = max(1, int(nq3))
    tr2 = (tr2_ph or _DEFAULT_TR2_PH).strip() or _DEFAULT_TR2_PH
    # ``ph_control`` est lu par thermo_pw pour chaque géométrie : y déclarer ``outdir``
    # écraserait la redirection ``…/g<N>/`` et ferait recalculer neuf fois le même
    # volume (cf. strip_outdir_for_thermo_pw). Un ``ph.in`` autonome en a besoin.
    is_thermo_pw_control = ph_basename.strip() == "ph_control"
    outdir_line = "" if is_thermo_pw_control else f"  outdir = '{outdir}'\n"
    origin = "prefix" if is_thermo_pw_control else "prefix/outdir"
    content = f"""! Généré automatiquement par thermo_pw (ph.x — même {origin} que {pw_basename})
! Ajustez tr2_ph, nq1..nq3, fildyn (Howto 1.8, thermo_pw) selon le système.
! Défaut tr2_ph={tr2} (rapide) ; publication : 1.0d-14.
!
thermo_pw_ph

&inputph
  tr2_ph = {tr2}
  prefix = '{prefix}'
{outdir_line}  ldisp = .true.
  nq1 = {nq1}
  nq2 = {nq2}
  nq3 = {nq3}
  fildyn = 'ph_dyn'
  fildvscf = 'dvscf'
/
"""
    ph_path.write_text(content, encoding="utf-8")
    return (
        True,
        f"{ph_basename!r} écrit à partir de {pw_basename!r} (prefix={prefix!r}, q-grille {nq1}×{nq2}×{nq3}, tr2_ph={tr2}).",
    )


def nq_from_request_body(data: dict[str, Any]) -> tuple[int, int, int]:
    """Lecture optionnelle nq [n1,n2,n3] ou nq1,nq2,nq3 distincts."""
    nq = data.get("nq")
    if isinstance(nq, (list, tuple)) and len(nq) >= 3:
        try:
            return (max(1, int(nq[0])), max(1, int(nq[1])), max(1, int(nq[2])))
        except (TypeError, ValueError):
            pass
    try:
        return (
            max(1, int(data.get("nq1", 4))),
            max(1, int(data.get("nq2", 4))),
            max(1, int(data.get("nq3", 4))),
        )
    except (TypeError, ValueError):
        return (4, 4, 4)

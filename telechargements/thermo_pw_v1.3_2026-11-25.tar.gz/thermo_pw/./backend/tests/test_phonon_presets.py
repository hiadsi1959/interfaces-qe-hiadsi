"""Presets phonons : gamma / fast / standard / publish + conseils scf."""
from __future__ import annotations

from ph_input_from_pw import (
    resolve_phonon_settings,
    scf_phonon_advice,
    normalize_tr2_ph,
    try_autogenerate_ph_in,
)

PW_IN = """&CONTROL
    calculation = 'scf'
    prefix = 'x'
    outdir = './out/'
/
&SYSTEM
    ibrav = 1
    nat = 5
    ntyp = 1
    ecutwfc = 50.0
/
"""


def test_normalize_tr2_ph():
    assert normalize_tr2_ph("1e-14") == "1.0d-14"
    assert normalize_tr2_ph("1.0d-12") == "1.0d-12"
    assert normalize_tr2_ph(None) == "1.0d-12"


def test_preset_gamma():
    s = resolve_phonon_settings({"phonon_preset": "gamma"})
    assert s["nq"] == (1, 1, 1)
    assert s["tr2_ph"] == "1.0d-12"
    assert s["preset"] == "gamma"


def test_preset_publish():
    s = resolve_phonon_settings({"phonon_preset": "publish"})
    assert s["nq"] == (6, 6, 6)
    assert s["tr2_ph"] == "1.0d-14"


def test_tr2_override():
    s = resolve_phonon_settings({"phonon_preset": "fast", "tr2_ph": "1e-14"})
    assert s["nq"] == (2, 2, 2)
    assert s["tr2_ph"] == "1.0d-14"


def test_advice_ibrav0_and_large_cell():
    tips = scf_phonon_advice(ibrav=0, nat=20, nq=(4, 4, 4))
    assert any("ibrav=0" in t for t in tips)
    assert any("nat=20" in t for t in tips)


def test_advice_hubbard_ortho_atomic_blocks_dfpt():
    from ph_input_from_pw import (
        detect_hubbard_projectors,
        hubbard_dfpt_blocker_message,
    )

    scf = PW_IN + "\nHUBBARD (ortho-atomic)\nU  Fe-3d  4.0\n"
    assert detect_hubbard_projectors(scf) == "ortho-atomic"
    msg = hubbard_dfpt_blocker_message(scf)
    assert msg and "atomic" in msg and "ortho-atomic" in msg
    tips = scf_phonon_advice(ibrav=1, nat=5, nq=(2, 2, 2), scf_text=scf)
    assert any("⛔" in t and "HUBBARD" in t for t in tips)


def test_advice_hubbard_atomic_ok():
    from ph_input_from_pw import hubbard_dfpt_blocker_message

    scf = PW_IN + "\nHUBBARD {atomic}\nU  Fe-3d  4.0\n"
    assert hubbard_dfpt_blocker_message(scf) is None
    tips = scf_phonon_advice(ibrav=1, nat=5, nq=(2, 2, 2), scf_text=scf)
    assert any("compatible DFPT" in t for t in tips)
    assert not any("⛔" in t for t in tips)


def test_autogen_uses_tr2(tmp_path):
    (tmp_path / "pw_scf_V0_for_phonon.in").write_text(PW_IN, encoding="utf-8")
    ok, _ = try_autogenerate_ph_in(
        tmp_path, "ph.in", nq1=1, nq2=1, nq3=1, tr2_ph="1.0d-12"
    )
    assert ok
    txt = (tmp_path / "ph.in").read_text(encoding="utf-8")
    assert "nq1 = 1" in txt
    assert "tr2_ph = 1.0d-12" in txt

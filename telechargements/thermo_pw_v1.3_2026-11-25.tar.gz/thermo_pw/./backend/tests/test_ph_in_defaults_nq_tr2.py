"""Défauts ph.in : tr2_ph rapide + grille q configurable."""
from __future__ import annotations

from ph_input_from_pw import try_autogenerate_ph_in

PW_IN = """&CONTROL
    calculation = 'scf'
    prefix = 'scf_eq'
    outdir = './out_scf_eq/'
/
&SYSTEM
    ibrav = 1
    celldm(1) = 7.56
    nat = 5
    ntyp = 3
    ecutwfc = 50.0
/
"""


def test_default_tr2_ph_is_fast_1e12(tmp_path):
    (tmp_path / "pw_scf_V0_for_phonon.in").write_text(PW_IN, encoding="utf-8")
    ok, msg = try_autogenerate_ph_in(tmp_path, "ph.in")
    assert ok, msg
    texte = (tmp_path / "ph.in").read_text(encoding="utf-8")
    assert "tr2_ph = 1.0d-12" in texte
    assert "nq1 = 4" in texte


def test_custom_nq_and_strict_tr2(tmp_path):
    (tmp_path / "pw_scf_V0_for_phonon.in").write_text(PW_IN, encoding="utf-8")
    ok, msg = try_autogenerate_ph_in(
        tmp_path, "ph.in", nq1=2, nq2=2, nq3=2, tr2_ph="1.0d-14"
    )
    assert ok, msg
    texte = (tmp_path / "ph.in").read_text(encoding="utf-8")
    assert "nq1 = 2" in texte
    assert "nq2 = 2" in texte
    assert "nq3 = 2" in texte
    assert "tr2_ph = 1.0d-14" in texte

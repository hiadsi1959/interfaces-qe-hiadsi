(() => {
  const $ = (id) => document.getElementById(id);
  const page = document.body?.dataset?.page || "home";
  let jobId = localStorage.getItem("qealamode.job") || "";
  let material = localStorage.getItem("qealamode.material") || "";
  let materialsCache = [];
  let kappaChart = null;
  let bandsChart = null;
  const BAND_COLORS = ["#0a5c5c", "#c4772a", "#1a4a6e", "#047857", "#7c3aed", "#0a2540"];

  function log(id, msg, ok) {
    const el = $(id);
    if (!el) return;
    el.textContent = typeof msg === "string" ? msg : JSON.stringify(msg, null, 2);
    el.className = "log " + (ok === true ? "status-ok" : ok === false ? "status-err" : "");
  }

  async function api(path, opts = {}) {
    const res = await fetch(path, opts);
    const data = await res.json().catch(() => ({}));
    if (!res.ok && data.ok !== true) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  }

  function syncPublishHints() {
    if (typeof window.qeAideUpdatePublish === "function") window.qeAideUpdatePublish();
    const box = $("publish-box");
    if (box) box.hidden = !(material && jobId);
  }

  function setJob(id) {
    jobId = id || "";
    localStorage.setItem("qealamode.job", jobId);
    const label = $("job-label");
    if (label) label.textContent = jobId ? `Job : ${jobId}` : "";
    const sel = $("job-select");
    if (sel) sel.value = jobId;
    syncPublishHints();
  }

  function updateMatChosen() {
    const el = $("mat-chosen");
    if (!el) return;
    if (!material) {
      el.textContent = "Aucun matériau sélectionné.";
      el.classList.add("empty");
      return;
    }
    const mat = materialsCache.find((m) => m.name === material);
    const n = mat ? mat.n_inputs : 0;
    const inp = $("input-select")?.value;
    el.classList.remove("empty");
    el.textContent = inp
      ? `Matériau : ${material} · input : ${inp}`
      : `Matériau : ${material}` + (n ? ` · ${n} input(s)` : "");
  }

  function setMaterial(name) {
    material = name || "";
    localStorage.setItem("qealamode.material", material);
    const sel = $("material-select");
    if (sel) sel.value = material;
    fillInputSelect();
    filterJobsByMaterial();
    updateMatChosen();
    syncPublishHints();
    if (page === "optimisation") refreshOptimStatus().catch(() => {});
    if (page === "calcul") refreshCalcStatus().catch(() => {});
    if (page === "resultats") refreshResults().catch(() => {});
  }

  function statusBoxHtml(step) {
    if (!step) return "—";
    if (!step.input_exists) {
      return `Input absent : <code>${step.input_path || ""}</code>`;
    }
    if (step.converged) {
      return `Convergé · <code>${step.input_path}</code>` +
        (step.output_path ? `<br/>out : <code>${step.output_path}</code>` : "");
    }
    if (step.output_exists) {
      return `Sortie présente (à vérifier) · <code>${step.input_path}</code>`;
    }
    return `Input prêt · <code>${step.input_path}</code>`;
  }

  function paintOptimStatus(step, el) {
    if (!el || !step) return;
    el.innerHTML = statusBoxHtml(step);
    el.className = "optim-status " + (
      step.converged ? "ok" : step.output_exists ? "warn" : step.input_exists ? "" : "bad"
    );
  }

  async function refreshOptimStatus() {
    const banner = $("optim-banner");
    if (!material) {
      ["vc-relax", "relax", "scf"].forEach((k) => {
        const el = $("status-" + k);
        if (el) { el.textContent = "Choisissez un matériau."; el.className = "optim-status"; }
      });
      if (banner) banner.hidden = true;
      return;
    }
    const data = await api(`/api/materials/${encodeURIComponent(material)}/optim-status`);
    const steps = data.steps || {};
    paintOptimStatus(steps["vc-relax"], $("status-vc-relax"));
    paintOptimStatus(steps.relax, $("status-relax"));
    paintOptimStatus(steps.scf, $("status-scf"));
    if (banner) banner.hidden = !data.scf_ready;
  }

  let optimEditKind = "";

  async function openOptimEditor(kind) {
    if (!material) { alert("Choisissez un matériau."); return; }
    optimEditKind = kind;
    const data = await api(`/api/materials/${encodeURIComponent(material)}/input/${encodeURIComponent(kind)}`);
    $("optim-modal-title").textContent = `Éditer ${kind.toUpperCase()}`;
    $("optim-modal-path").textContent = data.path || "";
    $("optim-modal-text").value = data.content || "";
    $("optim-modal").hidden = false;
  }

  async function saveOptimEditor() {
    if (!material || !optimEditKind) return;
    const content = $("optim-modal-text").value;
    const data = await api(`/api/materials/${encodeURIComponent(material)}/input/${encodeURIComponent(optimEditKind)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content }),
    });
    log("log-opt", data, !!data.ok);
    $("optim-modal").hidden = true;
    await refreshOptimStatus();
  }

  async function runOptimKind(kind) {
    if (!material) { alert("Choisissez un matériau."); return; }
    log("log-opt", `${kind} en cours pour ${material}…`);
    const body = {};
    if (jobId) body.job_id = jobId;
    const data = await api(`/api/materials/${encodeURIComponent(material)}/run/${encodeURIComponent(kind)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (data.job_id) setJob(data.job_id);
    log("log-opt", data, !!data.ok);
    await refreshJobs();
    await refreshMaterials();
    await refreshOptimStatus();
  }


  function bind(id, ev, fn) {
    const el = $(id);
    if (el) el.addEventListener(ev, fn);
  }

  function requireJob() {
    if (!jobId) { alert("Créez ou sélectionnez un job (matériau)."); return false; }
    return true;
  }

  function showStep(n) {
    document.querySelectorAll(".step-tab").forEach((b) => b.classList.toggle("active", b.dataset.step === String(n)));
    document.querySelectorAll(".panel").forEach((p) => {
      p.classList.toggle("active", p.id === `panel-${n}` || p.id === "panel-" + n);
    });
  }

  async function refreshTools() {
    const box = $("tools-status");
    if (!box) return;
    const data = await api("/api/tools");
    const t = data.tools || {};
    box.innerHTML = "";
    [["pw.x", t.pw_x], ["alm", t.alm], ["anphon", t.anphon]].forEach(([name, path]) => {
      const span = document.createElement("span");
      span.className = "pill " + (path ? "ok" : "bad");
      span.textContent = path ? `${name} OK` : `${name} absent`;
      span.title = path || "";
      box.appendChild(span);
    });
  }

  async function refreshMaterials() {
    const sel = $("material-select");
    if (!sel) return;
    const data = await api("/api/materials");
    materialsCache = data.materials || [];
    sel.innerHTML = "";
    const o0 = document.createElement("option");
    o0.value = ""; o0.textContent = "— matériau —";
    sel.appendChild(o0);
    materialsCache.forEach((m) => {
      const o = document.createElement("option");
      o.value = m.name;
      o.textContent = m.name;
      sel.appendChild(o);
    });
    if (material) sel.value = material;
    else if (materialsCache.length === 1) setMaterial(materialsCache[0].name);
    fillInputSelect();
  }

  function fillInputSelect() {
    const sel = $("input-select");
    if (!sel) return;
    sel.innerHTML = "";
    const o0 = document.createElement("option");
    o0.value = ""; o0.textContent = "— input —";
    sel.appendChild(o0);
    const mat = materialsCache.find((m) => m.name === material);
    (mat?.inputs || []).forEach((inp) => {
      const o = document.createElement("option");
      o.value = inp.rel || inp.name;
      o.textContent = inp.name;
      sel.appendChild(o);
    });
    if (mat?.inputs?.length && !sel.value) {
      const names = mat.inputs.map((inp) => inp.rel || inp.name);
      const preferred = names.find((n) => /optim|relax|scf/i.test(n)) || names[0];
      sel.value = preferred;
    }
    // library cards on calcul
    const box = $("inputs-library");
    if (box) {
      box.innerHTML = "";
      (mat?.inputs || []).forEach((inp) => {
        const card = document.createElement("div");
        card.className = "input-card ready";
        card.innerHTML = `<div><h4>${inp.name}</h4><p>${inp.path}</p></div><button class="btn" type="button">Utiliser</button>`;
        card.querySelector("button").onclick = () => useInput(inp.rel || inp.name);
        box.appendChild(card);
      });
      if (!(mat?.inputs || []).length) box.innerHTML = "<p class='desc'>Aucun .in pour ce matériau dans inputs/.</p>";
    }
    updateMatChosen();
  }


  async function refreshJobs() {
    const sel = $("job-select");
    if (!sel) return;
    const data = await api("/api/jobs");
    window.__allJobs = data.jobs || [];
    filterJobsByMaterial();
  }

  function filterJobsByMaterial() {
    const sel = $("job-select");
    if (!sel) return;
    const jobs = window.__allJobs || [];
    sel.innerHTML = "";
    const o0 = document.createElement("option");
    o0.value = ""; o0.textContent = "—";
    sel.appendChild(o0);
    const filtered = jobs.filter((j) => !material || j.material === material || (j.name || "").includes(material));
    filtered.forEach((j) => {
      const o = document.createElement("option");
      o.value = j.id;
      o.textContent = `${j.id} (${j.material || j.name || ""})`;
      sel.appendChild(o);
    });
    const stillValid = filtered.some((j) => j.id === jobId);
    if (stillValid) sel.value = jobId;
    else if (filtered.length && material && (page === "resultats" || page === "calcul")) {
      setJob(filtered[0].id);
      sel.value = filtered[0].id;
    } else if (jobId) sel.value = jobId;
  }

  async function useInput(rel) {
    if (!rel) { alert("Choisissez un input."); return; }
    if (!jobId) {
      const created = await api("/api/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: material || "material", material: material || undefined }),
      });
      setJob(created.job_id);
      if (created.material) setMaterial(created.material);
      await refreshJobs();
    }
    const data = await api(`/api/jobs/${jobId}/use-input`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: rel }),
    });
    const logId = page === "optimisation" ? "log-opt" : page === "calcul" ? "log-calc" : "log-1";
    log(logId, data, !!data.ok);
    await refreshMaterials();
    if (page === "calcul") await refreshCalcStatus();
    return data;
  }

  function fmtVal(v) {
    if (v === null || v === undefined || v === "") return "—";
    if (typeof v === "number") {
      if (!Number.isFinite(v)) return "—";
      if (Math.abs(v) >= 1e4 || (Math.abs(v) > 0 && Math.abs(v) < 1e-3)) return v.toExponential(3);
      return Number(v.toPrecision(6)).toString();
    }
    return String(v);
  }

  function setFicheLinks() {
    const hint = $("fiche-hint");
    ["html", "pdf"].forEach((kind) => {
      const a = $(`fiche-${kind}`);
      if (!a) return;
      if (!jobId) { a.hidden = true; return; }
      a.hidden = false;
      a.href = `/api/jobs/${jobId}/fiche/${kind}`;
      a.target = "_blank";
    });
    if (hint) hint.hidden = !!jobId;
  }

  function plotKappa(rows) {
    const wrap = $("kappa-chart-wrap"), hint = $("kappa-hint"), ctx = $("kappa-chart");
    if (kappaChart) { kappaChart.destroy(); kappaChart = null; }
    if (!ctx || typeof Chart === "undefined" || !rows?.length) {
      if (wrap) wrap.hidden = true;
      if (hint) hint.hidden = false;
      return;
    }
    wrap.hidden = false; if (hint) hint.hidden = true;
    kappaChart = new Chart(ctx, {
      type: "line",
      data: {
        labels: rows.map((r) => r.T),
        datasets: [
          { label: "κ_xx", data: rows.map((r) => r.kappa_xx), borderColor: "#0d6e6e", tension: 0.2, pointRadius: 2 },
          { label: "κ_yy", data: rows.map((r) => r.kappa_yy), borderColor: "#b86b2e", tension: 0.2, pointRadius: 2 },
          { label: "κ_zz", data: rows.map((r) => r.kappa_zz), borderColor: "#245f78", borderDash: [4, 3], tension: 0.2, pointRadius: 2 },
        ],
      },
      options: {
        responsive: true,
        scales: {
          x: { title: { display: true, text: "T (K)" } },
          y: { title: { display: true, text: "κ_L (W/m/K)" } },
        },
      },
    });
  }

  function plotBands(series) {
    const wrap = $("bands-chart-wrap"), hint = $("bands-hint"), ctx = $("bands-chart");
    if (bandsChart) { bandsChart.destroy(); bandsChart = null; }
    if (!ctx || typeof Chart === "undefined" || !series?.length) {
      if (wrap) wrap.hidden = true;
      if (hint) hint.hidden = false;
      return;
    }
    wrap.hidden = false; if (hint) hint.hidden = true;
    bandsChart = new Chart(ctx, {
      type: "line",
      data: {
        datasets: series.map((s, i) => ({
          label: `mode ${s.mode}`,
          data: s.k.map((k, j) => ({ x: k, y: s.omega[j] })),
          borderColor: BAND_COLORS[i % BAND_COLORS.length],
          pointRadius: 0, borderWidth: 1.5, tension: 0,
        })),
      },
      options: {
        responsive: true,
        parsing: false,
        plugins: { legend: { display: series.length <= 12 } },
        scales: {
          x: { type: "linear", title: { display: true, text: "q" } },
          y: { title: { display: true, text: "ω (cm⁻¹)" } },
        },
      },
    });
  }

  async function refreshResults() {
    const grid = $("param-grid");
    if (!grid) return;
    grid.innerHTML = "";
    setFicheLinks();
    syncPublishHints();
    const label = $("results-job-label");
    const empty = $("results-empty");
    const jobFiles = $("job-files-list");
    if (jobFiles) jobFiles.innerHTML = "";

    if (!material) {
      if (label) label.textContent = "Choisissez un matériau";
      if (empty) { empty.hidden = false; empty.textContent = "1 · Choisissez un matériau, puis un job."; }
      plotBands([]);
      plotKappa([]);
      return;
    }
    if (!jobId) {
      if (label) label.textContent = `${material} — sélectionnez un job`;
      if (empty) { empty.hidden = false; empty.textContent = "Choisissez un job pour afficher les grandeurs."; }
      plotBands([]);
      plotKappa([]);
      return;
    }

    let data;
    try {
      data = await api(`/api/jobs/${jobId}/results`);
    } catch (err) {
      if (label) label.textContent = `${jobId} — erreur`;
      if (empty) {
        empty.hidden = false;
        empty.textContent = err.message || "Impossible de charger les résultats.";
      }
      plotBands([]);
      plotKappa([]);
      return;
    }
    if (label) label.textContent = `${data.name || jobId} · ${material}`;
    const params = data.params || [];
    const nOk = params.filter((p) => p.status === "ok").length;
    if (empty) {
      empty.hidden = nOk > 0;
      if (nOk === 0) empty.textContent = "Job chargé — grandeurs encore incomplètes.";
    }
    params.forEach((p) => {
      const div = document.createElement("div");
      div.className = "param-item " + (p.status === "ok" ? "ok" : "pending");
      const note = p.note ? `<span class="pnote">${p.note}</span>` : "";
      const val = p.status === "ok" ? `${fmtVal(p.value)}${p.unit ? `<span class="unit">${p.unit}</span>` : ""}` : "—";
      div.innerHTML = `<div class="plabel">${p.label}</div><div class="pvalue">${val}${note}</div>`;
      grid.appendChild(div);
    });

    const tbG = $("gamma-table")?.querySelector("tbody");
    if (tbG) {
      const modes = data.gamma_modes || [];
      tbG.innerHTML = modes.map((g, i) => {
        const w = Number(g.omega_cm1) || 0;
        const kind = (i < 3 || Math.abs(w) < 1e-2) ? "acoustique" : "optique";
        return `<tr><td>${g.mode}</td><td>${fmtVal(g.omega_cm1)}</td><td>${kind}</td></tr>`;
      }).join("") || "<tr><td colspan=3>—</td></tr>";
    }

    const tbI = $("ifc-table")?.querySelector("tbody");
    if (tbI) {
      const ifc = data.ifc || {};
      const keys = Object.keys(ifc);
      tbI.innerHTML = keys.map((k) =>
        `<tr><td>${k}</td><td>${ifc[k].n_terms ?? "—"}</td><td>${fmtVal(ifc[k].max_abs)}</td>`
        + `<td>${fmtVal(ifc[k].min)}</td><td>${fmtVal(ifc[k].max)}</td></tr>`
      ).join("") || "<tr><td colspan=5>—</td></tr>";
    }

    const bands = data.bands_series || [];
    const bh = $("bands-hint");
    if (bh) bh.hidden = bands.length > 0;
    plotBands(bands);

    const kappa = data.kappa || [];
    const kh = $("kappa-hint");
    if (kh) kh.hidden = kappa.length > 0;
    const tbK = $("kappa-table")?.querySelector("tbody");
    if (tbK) {
      tbK.innerHTML = kappa.map((r) =>
        `<tr><td>${fmtVal(r.T)}</td><td>${fmtVal(r.kappa_xx)}</td><td>${fmtVal(r.kappa_yy)}</td><td>${fmtVal(r.kappa_zz)}</td></tr>`
      ).join("") || "<tr><td colspan=4>—</td></tr>";
    }
    plotKappa(kappa);

    if (jobFiles) {
      const files = data.files || {};
      Object.entries(files).forEach(([k, v]) => {
        if (!v) return;
        const li = document.createElement("li");
        li.textContent = `${k}: ${v}`;
        jobFiles.appendChild(li);
      });
      const steps = data.steps_ok || {};
      Object.entries(steps).forEach(([k, v]) => {
        const li = document.createElement("li");
        li.textContent = `étape ${k}: ${v ? "OK" : "—"}`;
        jobFiles.appendChild(li);
      });
      if (!jobFiles.children.length) {
        const li = document.createElement("li");
        li.textContent = "Aucun fichier résumé.";
        jobFiles.appendChild(li);
      }
    }
  }


  async function ensureJobForMaterial() {
    if (!material) { alert("Choisissez un matériau."); return false; }
    if (!jobId) {
      const data = await api("/api/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: material, material }),
      });
      setJob(data.job_id);
      await refreshJobs();
      if (page === "calcul") openMiniGuide();
    }
    return true;
  }

  let guideMiniLoaded = false;

  function slugifyHeading(text) {
    return String(text || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 64) || "section";
  }

  function enhanceGuideHtml(bodyEl, tocNav, html) {
    if (!bodyEl) return;
    bodyEl.innerHTML = html;
    // Wrap tables for horizontal scroll
    bodyEl.querySelectorAll("table").forEach((table) => {
      if (table.parentElement && table.parentElement.classList.contains("guide-table-wrap")) return;
      const wrap = document.createElement("div");
      wrap.className = "guide-table-wrap";
      table.parentNode.insertBefore(wrap, table);
      wrap.appendChild(table);
    });
    // Callout styles from blockquotes
    bodyEl.querySelectorAll("blockquote").forEach((bq) => {
      const text = (bq.textContent || "").toLowerCase();
      bq.classList.add("guide-callout");
      if (/attention|danger|interdit|ne pas|refusé|non publiable|critique/.test(text)) {
        bq.classList.add("guide-callout-danger");
      } else if (/κ|kappa|norder\s*[=≥]\s*2|publiable|recommand/.test(text)) {
        bq.classList.add("guide-callout-ok");
      } else if (/warning|attention|timeout|oneapi|piège/.test(text)) {
        bq.classList.add("guide-callout-warn");
      }
    });
    // TOC from h2
    if (tocNav) {
      tocNav.innerHTML = "";
      const used = new Set();
      bodyEl.querySelectorAll("h2").forEach((h2) => {
        let id = slugifyHeading(h2.textContent);
        let n = 2;
        while (used.has(id)) {
          id = `${slugifyHeading(h2.textContent)}-${n++}`;
        }
        used.add(id);
        h2.id = id;
        const a = document.createElement("a");
        a.href = `#${id}`;
        a.textContent = h2.textContent || id;
        a.addEventListener("click", (ev) => {
          ev.preventDefault();
          h2.scrollIntoView({ behavior: "smooth", block: "start" });
        });
        tocNav.appendChild(a);
      });
    }
  }

  window.qeEnhanceGuide = enhanceGuideHtml;

  async function loadMiniGuideContent() {
    const body = $("guide-mini-body");
    if (!body) return;
    if (guideMiniLoaded && body.innerHTML.trim() && !body.dataset.loadingText) return;
    const loading = body.dataset.loadingText || body.getAttribute("data-i18n") || "Chargement…";
    if (!body.innerHTML.trim() || body.textContent === loading || /Loading|Chargement/.test(body.textContent || "")) {
      body.textContent = (window.qeI18n && window.qeI18n.t("calc.guide.loading")) || "Chargement…";
    }
    try {
      const res = await fetch("/api/guide/mini");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const md = await res.text();
      const html = typeof marked !== "undefined" ? marked.parse(md) : `<pre>${md}</pre>`;
      enhanceGuideHtml(body, $("guide-mini-toc-nav"), html);
      guideMiniLoaded = true;
    } catch (e) {
      body.textContent = String(e.message || e);
    }
  }

  function openMiniGuide(force) {
    const modal = $("guide-mini-modal");
    if (!modal) {
      window.open("guide-mini.html", "_blank", "noopener");
      return;
    }
    if (!force && localStorage.getItem("qealamode.guide_mini_auto") === "0") return;
    modal.hidden = false;
    loadMiniGuideContent().catch(() => {});
  }

  function closeMiniGuide() {
    const modal = $("guide-mini-modal");
    if (modal) modal.hidden = true;
    const skip = $("guide-mini-skip");
    if (skip && skip.checked) {
      localStorage.setItem("qealamode.guide_mini_auto", "0");
    }
  }

  function paintCalcBox(id, html, cls) {
    const el = $(id);
    if (!el) return;
    el.innerHTML = html;
    el.className = "optim-status" + (cls ? " " + cls : "");
  }

  function updateSciWarnings() {
    const banner = $("sci-banner");
    if (!banner || page !== "calcul") return;
    const nx = +($("nx")?.value || 1);
    const ny = +($("ny")?.value || 1);
    const nz = +($("nz")?.value || 1);
    const norder = +($("norder")?.value || 2);
    const mode = $("anphon-mode")?.value || "phonons";
    const small = nx * ny * nz < 8;
    const kappaRisk = mode === "rta" && (norder < 2 || small);
    banner.classList.toggle("warn", kappaRisk);
    if (kappaRisk) {
      banner.innerHTML =
        "<strong>Attention κ<sub>L</sub></strong> — " +
        (norder < 2 ? "NORDER doit être ≥ 2. " : "") +
        (small ? "Supercellule trop petite (idéalement 3×3×3). " : "") +
        "Résultats non recommandés pour publication.";
    } else {
      banner.innerHTML =
        "<strong>κ<sub>L</sub> publiable</strong> — " +
        "supercellule ≥ 2×2×2 (idéalement <strong>3×3×3</strong> sur machine puissante, ex. 14900K · 64&nbsp;Go) · NORDER = 2 · " +
        "tous les motifs <code>pw.x</code> en <code>JOB DONE</code> avant DFSET · " +
        "puis anphon <code>phonons</code> → <code>rta</code>. " +
        "PC limité : tester d’abord <code>1×1×1</code> " +
        "(<code>python3 scripts/verify_dft_nxn.py --n 1 --run</code>).";
    }
  }

  function paintCardEtas(data) {
    const cards = data.cards || {};
    const byId = {};
    (data.steps || []).forEach((s) => {
      byId[s.id] = s;
    });
    const setEta = (cardKey, human, title) => {
      const el = $("eta-card-" + cardKey);
      if (!el) return;
      el.textContent = human ? `~ ${human}` : "~ —";
      if (title) el.title = title;
    };
    // SCF
    const scf = cards.scf || byId.scf;
    setEta("scf", scf?.human, scf?.detail || (scf?.parts || []).join(" · "));
    // Supercell
    const sc = cards.supercell || byId.supercell;
    setEta("supercell", sc?.human, sc?.detail || (sc?.parts || []).join(" · "));
    // Forces = QE (+ DFSET si présent)
    const forces = cards.forces;
    if (forces) {
      const tip = [
        ...(forces.parts || []),
        forces.detail || "",
        forces.per_config_human ? `≈ ${forces.per_config_human} / config` : "",
      ]
        .filter(Boolean)
        .join(" · ");
      setEta("forces", forces.human, tip);
    } else if (byId.qe) {
      setEta(
        "forces",
        byId.qe.human,
        [byId.qe.detail, byId.qe.per_config_human ? `≈ ${byId.qe.per_config_human} / config` : ""]
          .filter(Boolean)
          .join(" · "),
      );
    } else {
      setEta("forces", null);
    }
    // alm
    const alm = cards.alm || byId.alm;
    setEta("alm", alm?.human, alm?.detail || (alm?.parts || []).join(" · "));
    // anphon (+ export)
    const an = cards.anphon;
    if (an) {
      setEta("anphon", an.human, (an.parts || []).join(" · ") || an.detail || "");
    } else if (byId.anphon) {
      setEta("anphon", byId.anphon.human, byId.anphon.detail || "");
    } else {
      setEta("anphon", null);
    }
  }

  async function refreshTimeEstimate() {
    const box = $("time-estimate");
    if (!box || page !== "calcul") return;
    const payload = {
      material: material || undefined,
      job_id: jobId || undefined,
      nx: +($("nx")?.value || 1),
      ny: +($("ny")?.value || 1),
      nz: +($("nz")?.value || 1),
      n_patterns: +($("n_patterns")?.value || 12),
      // ETA sur l'étape complète (tous les motifs) — max_jobs = taille de lot seulement
      norder: +($("norder")?.value || 2),
      anphon_mode: $("anphon-mode")?.value || "phonons",
      kmesh: [+($("kx")?.value || 10), +($("ky")?.value || 10), +($("kz")?.value || 10)],
      tmin: +($("tmin")?.value || 0),
      tmax: +($("tmax")?.value || 1000),
      dt: +($("dt")?.value || 50),
    };
    try {
      const data = await api("/api/estimate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const total = $("eta-total");
      const range = $("eta-range");
      const steps = $("eta-steps");
      const note = $("eta-note");
      if (total) total.textContent = data.total_human || "—";
      if (range) {
        const t = (window.qeI18n && window.qeI18n.t("calc.eta.range")) || "Fourchette probable";
        range.textContent = data.range_human ? `${t} : ${data.range_human}` : "";
      }
      if (steps) {
        steps.innerHTML = (data.steps || [])
          .map(
            (s) =>
              `<li><span class="eta-label">${s.label}</span><span class="eta-time">${s.human}</span>` +
              (s.detail ? `<span class="eta-detail">${s.detail}</span>` : "") +
              `</li>`
          )
          .join("");
      }
      if (note) {
        const base = (window.qeI18n && window.qeI18n.t("calc.eta.hint")) || data.disclaimer || "";
        note.textContent = data.note ? `${base} ${data.note}` : base;
      }
      paintCardEtas(data);
    } catch (e) {
      const total = $("eta-total");
      if (total) total.textContent = "—";
      ["scf", "supercell", "forces", "alm", "anphon"].forEach((k) => {
        const el = $("eta-card-" + k);
        if (el) el.textContent = "~ —";
      });
    }
  }

  const NEXT_CARD = {
    supercell: "supercell",
    qe_forces: "forces",
    qe_config: "forces",
    dfset: "forces",
    alm_prepare: "alm",
    alm_run: "alm",
    alm_optimize: "alm",
    anphon_prepare: "anphon",
    anphon_run: "anphon",
    anphon: "anphon",
    anphon_phonons: "anphon",
    anphon_rta: "anphon",
    publish: "anphon",
  };

  function clearNextReady() {
    document.querySelectorAll(".optim-card.next-ready").forEach((el) => el.classList.remove("next-ready"));
  }

  const PIPELINE_CARD = {
    import: "scf",
    supercell: "supercell",
    qe_forces: "forces",
    qe_config: "forces",
    dfset: "forces",
    alm_prepare: "alm",
    alm_optimize: "alm",
    alm_run: "alm",
    anphon_prepare: "anphon",
    anphon: "anphon",
    anphon_phonons: "anphon",
    anphon_rta: "anphon",
    publish: "anphon",
    terminé: "anphon",
  };

  function paintPipelineProgress(pipe) {
    const box = $("calc-progress");
    if (!box) return;
    if (!pipe) {
      box.className = "calc-progress";
      if ($("calc-progress-state")) $("calc-progress-state").textContent = "—";
      if ($("calc-progress-current")) $("calc-progress-current").textContent = "Sélectionnez un job";
      if ($("calc-progress-hint")) {
        $("calc-progress-hint").textContent = "L’état du calcul s’affiche ici en permanence.";
      }
      if ($("calc-progress-track")) $("calc-progress-track").innerHTML = "";
      document.querySelectorAll(".optim-card.step-current").forEach((el) => el.classList.remove("step-current"));
      return;
    }
    const state = pipe.state || "idle";
    box.className = "calc-progress is-" + state;
    if ($("calc-progress-state")) $("calc-progress-state").textContent = pipe.state_label || state;
    if ($("calc-progress-current")) {
      $("calc-progress-current").textContent =
        (pipe.current_label || pipe.current_step || "?") +
        (pipe.next_label && pipe.next_step !== pipe.current_step
          ? `  →  suivant : ${pipe.next_label}`
          : "");
    }
    if ($("calc-progress-hint")) {
      let h = pipe.hint || "";
      if (pipe.qe_total) h += ` · QE ${pipe.qe_done || 0}/${pipe.qe_total}`;
      if ((pipe.running || []).length) h += ` · process actif`;
      $("calc-progress-hint").textContent = h;
    }
    const track = $("calc-progress-track");
    if (track) {
      track.innerHTML = (pipe.checklist || [])
        .map((c) => {
          const cls = c.ok ? "ok" : c.active ? "active" : "";
          return `<li class="${cls}">${c.label}</li>`;
        })
        .join("");
    }
    document.querySelectorAll(".optim-card.step-current").forEach((el) => el.classList.remove("step-current"));
    const cardKey = PIPELINE_CARD[pipe.current_step] || PIPELINE_CARD[pipe.next_step];
    if (cardKey) {
      const card = document.querySelector(`#calc-cards .optim-card[data-step="${cardKey}"]`);
      if (card) card.classList.add("step-current");
    }
  }

  function showStepSignal(sig) {
    const box = $("step-signal-banner");
    if (!box) return;
    const visible = !!(sig && sig.awaiting_user && !sig.acked);
    if (!visible) {
      box.hidden = true;
      box.classList.remove("is-interrupted", "is-failed", "is-ok");
      clearNextReady();
      return;
    }
    const title = $("step-signal-title");
    const hint = $("step-signal-hint");
    const meta = $("step-signal-meta");
    const st = sig.state || (sig.ok === false ? "interrupted" : "ok");
    box.classList.remove("is-interrupted", "is-failed", "is-ok");
    box.classList.add(st === "interrupted" || st === "failed" ? "is-interrupted" : "is-ok");
    if (title) {
      if (st === "interrupted" || sig.ok === false) {
        title.textContent = `Calcul arrêté — ${sig.step_label || sig.step || "étape"} → reprendre : ${sig.next_label || sig.next_step || "?"}`;
      } else {
        const tFn = window.qeI18n && window.qeI18n.t;
        const tpl = (tFn && tFn("calc.signal.title")) || "Étape terminée : {step} → suivant : {next}";
        title.textContent = tpl
          .replace("{step}", sig.step_label || sig.step || "?")
          .replace("{next}", sig.next_label || sig.next_step || "?");
      }
    }
    if (hint) hint.textContent = sig.hint || sig.message || "";
    if (meta) {
      meta.textContent = [
        sig.finished_at || "",
        sig.job_id || jobId,
        `work/${sig.job_id || jobId}/READY_NEXT_STEP`,
      ]
        .filter(Boolean)
        .join(" · ");
    }
    box.hidden = false;
    clearNextReady();
    const cardKey = NEXT_CARD[sig.next_step] || NEXT_CARD[sig.step] || PIPELINE_CARD[sig.next_step];
    if (cardKey) {
      const card = document.querySelector(`#calc-cards .optim-card[data-step="${cardKey}"]`);
      if (card) card.classList.add("next-ready");
    }
  }

  async function pollStepSignal() {
    if (page !== "calcul" || !jobId) {
      paintPipelineProgress(null);
      return;
    }
    try {
      const data = await api(`/api/jobs/${jobId}/signal`);
      paintPipelineProgress(data.pipeline || null);
      showStepSignal(data.signal);
    } catch (_) {
      /* ignore */
    }
  }

  function noteStepSignalFromResult(data) {
    if (data && data.step_signal) showStepSignal(data.step_signal);
  }

  async function refreshCalcStatus() {
    const banner = $("calc-banner");
    refreshTimeEstimate().catch(() => {});
    pollStepSignal().catch(() => {});
    if (!material) {
      paintCalcBox("status-calc-scf", "Choisissez un matériau.", "bad");
      ["supercell", "forces", "alm", "anphon"].forEach((k) => paintCalcBox("status-calc-" + k, "En attente."));
      if (banner) banner.hidden = true;
      return;
    }
    const scfPath = `inputs/${material}/${material}-scf.in`;
    let scfOk = false;
    try {
      const st = await api(`/api/materials/${encodeURIComponent(material)}/optim-status`);
      scfOk = !!(st.steps && st.steps.scf && st.steps.scf.input_exists);
      paintCalcBox(
        "status-calc-scf",
        scfOk ? `Input prêt · <code>${scfPath}</code>` : `Absent · <code>${scfPath}</code>`,
        scfOk ? "ok" : "bad",
      );
    } catch (e) {
      paintCalcBox("status-calc-scf", String(e.message || e), "bad");
    }

    if (!jobId) {
      ["supercell", "forces", "alm", "anphon"].forEach((k) => paintCalcBox("status-calc-" + k, "Créez ou sélectionnez un job."));
      if (banner) banner.hidden = true;
      return;
    }
    try {
      const job = await api(`/api/jobs/${jobId}`);
      const steps = (job.meta && job.meta.steps) || job.steps || {};
      const mark = (key, id) => {
        const s = steps[key] || steps[key.replace("-", "_")];
        if (s && (s.ok === true || s === true)) paintCalcBox(id, "OK", "ok");
        else if (s && s.ok === false) paintCalcBox(id, s.error || "Échec", "bad");
        else paintCalcBox(id, "En attente.");
      };
      mark("supercell", "status-calc-supercell");
      const qe = steps.qe_forces || {};
      const df = steps.dfset || {};
      const qeOk = qe.ok === true;
      const dfOk = df.ok === true;
      if (qeOk && dfOk) {
        paintCalcBox("status-calc-forces", `pw.x ${qe.n_done || "OK"}/${qe.n_expected || "OK"} · DFSET OK`, "ok");
      } else if (df.ok === false && df.error) {
        paintCalcBox("status-calc-forces", df.error, "warn");
      } else if (qe.n_done != null && qe.n_expected != null) {
        const cls = qeOk ? "ok" : qe.n_done > 0 ? "warn" : "";
        paintCalcBox(
          "status-calc-forces",
          `pw.x ${qe.n_done}/${qe.n_expected}` +
            (qe.remaining ? ` · reste ${qe.remaining} (relancer Run pw.x)` : "") +
            (dfOk ? " · DFSET OK" : ""),
          cls,
        );
      } else if (qeOk) paintCalcBox("status-calc-forces", "pw.x OK", "ok");
      else if (dfOk) paintCalcBox("status-calc-forces", "DFSET OK", "ok");
      else paintCalcBox("status-calc-forces", "En attente.");
      const almOk = (steps.alm_optimize && steps.alm_optimize.ok) || (steps.alm_suggest && steps.alm_suggest.ok);
      if (almOk) paintCalcBox("status-calc-alm", "OK", "ok");
      else paintCalcBox("status-calc-alm", "En attente.");
      if (steps.anphon && steps.anphon.ok) {
        const kp = steps.anphon.kappa_points || 0;
        paintCalcBox("status-calc-anphon", kp ? `OK · κ : ${kp} points` : "OK (phonons)", "ok");
      } else if (steps.anphon && steps.anphon.ok === false) {
        const err = steps.anphon.error || "Échec anphon";
        paintCalcBox("status-calc-anphon", err, "bad");
      } else paintCalcBox("status-calc-anphon", "En attente.");
      const importOk = steps.import && steps.import.ok;
      if (importOk && scfOk) paintCalcBox("status-calc-scf", `SCF chargé · <code>${scfPath}</code>`, "ok");
      const ready = !!(steps.anphon && steps.anphon.ok);
      if (banner) banner.hidden = !ready;
    } catch (e) {
      ["supercell", "forces", "alm", "anphon"].forEach((k) => paintCalcBox("status-calc-" + k, "—"));
    }
  }

  async function useMaterialScf() {
    if (!(await ensureJobForMaterial())) return;
    const name = `${material}/${material}-scf.in`;
    const data = await useInput(name);
    log("log-calc", data, !!data?.ok);
    await refreshCalcStatus();
  }

  // —— binds communs matériau ——
  bind("material-select", "change", () => setMaterial($("material-select").value));
  bind("input-select", "change", () => updateMatChosen());
  bind("btn-use-material", "click", () => useInput($("input-select")?.value));
  bind("btn-new-job", "click", async () => {
    const mat = material || $("material-select")?.value || "material";
    const data = await api("/api/jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: mat, material: mat }),
    });
    setJob(data.job_id);
    if (data.material) setMaterial(data.material);
    await refreshJobs();
    const inp = $("input-select")?.value;
    if (inp) await useInput(inp);
    else if (page === "calcul" && material) {
      try { await useMaterialScf(); } catch (e) { /* ignore */ }
    }
    if (page === "calcul") {
      openMiniGuide(true);
      await refreshCalcStatus();
    }
  });
  bind("job-select", "change", () => {
    setJob($("job-select").value);
    if (page === "resultats") refreshResults().catch(() => {});
    if (page === "calcul") refreshCalcStatus().catch(() => {});
  });

  // Optimisation (type Interface-QE_v1)
  document.querySelectorAll(".btn-optim-edit").forEach((btn) => {
    btn.addEventListener("click", () => openOptimEditor(btn.dataset.kind).catch((e) => alert(e.message)));
  });
  document.querySelectorAll(".btn-optim-run").forEach((btn) => {
    btn.addEventListener("click", () => runOptimKind(btn.dataset.kind).catch((e) => {
      log("log-opt", String(e.message || e), false);
    }));
  });
  bind("btn-optim-refresh", "click", () => refreshOptimStatus().catch((e) => alert(e.message)));
  bind("btn-results-refresh", "click", () => refreshResults().catch((e) => alert(e.message)));
  bind("optim-modal-close", "click", () => { if ($("optim-modal")) $("optim-modal").hidden = true; });
  bind("optim-modal-save", "click", () => saveOptimEditor().catch((e) => alert(e.message)));
  if ($("optim-modal")) {
    $("optim-modal").addEventListener("click", (ev) => {
      if (ev.target === $("optim-modal")) $("optim-modal").hidden = true;
    });
  }

  // Calculs (cartes comme Optimisation)
  document.querySelectorAll(".step-tab").forEach((btn) => {
    btn.addEventListener("click", () => showStep(btn.dataset.step));
  });
  bind("btn-calc-use-scf", "click", () => useMaterialScf().catch((e) => log("log-calc", String(e.message || e), false)));
  bind("btn-calc-refresh", "click", () => refreshCalcStatus().catch((e) => alert(e.message)));

  // Recalculer l'ETA quand les paramètres changent
  if (page === "calcul") {
    const etaIds = ["nx", "ny", "nz", "n_patterns", "max_jobs", "norder", "anphon-mode", "kx", "ky", "kz", "tmin", "tmax", "dt"];
    ["nx", "ny", "nz", "norder", "anphon-mode"].forEach((id) => {
      const el = $(id);
      if (el) el.addEventListener("change", updateSciWarnings);
      if (el) el.addEventListener("input", updateSciWarnings);
    });
    updateSciWarnings();
    let etaTimer = null;
    const scheduleEta = () => {
      clearTimeout(etaTimer);
      etaTimer = setTimeout(() => refreshTimeEstimate().catch(() => {}), 200);
    };
    etaIds.forEach((id) => {
      const el = $(id);
      if (!el) return;
      el.addEventListener("input", scheduleEta);
      el.addEventListener("change", scheduleEta);
    });
  }
  bind("btn-open-guide", "click", () => openMiniGuide(true));
  bind("guide-mini-close", "click", closeMiniGuide);
  if ($("guide-mini-modal")) {
    $("guide-mini-modal").addEventListener("click", (ev) => {
      if (ev.target === $("guide-mini-modal")) closeMiniGuide();
    });
  }
  bind("btn-step-signal-ack", "click", async () => {
    if (!jobId) return;
    try {
      await api(`/api/jobs/${jobId}/signal/ack`, { method: "POST" });
    } catch (_) {
      /* ignore */
    }
    showStepSignal(null);
  });
  bind("btn-supercell", "click", async () => {
    if (!(await ensureJobForMaterial())) return;
    log("log-calc", (window.qeI18n && window.qeI18n.t("log.supercell")) || "Supercellules…");
    const data = await api(`/api/jobs/${jobId}/supercell`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        nx: +$("nx").value, ny: +$("ny").value, nz: +$("nz").value,
        magnitude: +$("magnitude").value, n_patterns: +$("n_patterns").value,
        norder: +($("norder")?.value || 2),
      }),
    });
    noteStepSignalFromResult(data);
    log("log-calc", data, !!data.ok);
    await refreshCalcStatus();
  });
  bind("btn-qe", "click", async () => {
    if (!(await ensureJobForMaterial())) return;
    log("log-calc", "pw.x (lot suivant, configs incomplètes)…");
    const data = await api(`/api/jobs/${jobId}/qe/run`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ max_jobs: +$("max_jobs").value }),
    });
    noteStepSignalFromResult(data);
    if (data.remaining != null) {
      log(
        "log-calc",
        data.ok
          ? `Lot terminé · ${data.n_done}/${data.n_expected} · reste ${data.remaining}`
          : data,
        !!data.ok,
      );
    } else {
      log("log-calc", data, !!data.ok);
    }
    await refreshCalcStatus();
    updateSciWarnings();
  });
  bind("btn-dfset", "click", async () => {
    if (!(await ensureJobForMaterial())) return;
    const data = await api(`/api/jobs/${jobId}/dfset`, { method: "POST" });
    noteStepSignalFromResult(data);
    log("log-calc", data, !!data.ok);
    await refreshCalcStatus();
  });
  bind("btn-alm-prep", "click", async () => {
    if (!(await ensureJobForMaterial())) return;
    const data = await api(`/api/jobs/${jobId}/alm/prepare`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ norder: +$("norder").value, cutoff: +$("cutoff").value }),
    });
    noteStepSignalFromResult(data);
    log("log-calc", data, !!data.ok);
    await refreshCalcStatus();
  });
  bind("btn-alm-run", "click", async () => {
    if (!(await ensureJobForMaterial())) return;
    log("log-calc", "alm…");
    const data = await api(`/api/jobs/${jobId}/alm/run`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ which: "optimize" }),
    });
    noteStepSignalFromResult(data);
    log("log-calc", data, !!data.ok);
    await refreshCalcStatus();
  });
  bind("btn-anphon-prep", "click", async () => {
    if (!(await ensureJobForMaterial())) return;
    const data = await api(`/api/jobs/${jobId}/anphon/prepare`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        mode: $("anphon-mode").value,
        kmesh: [+$("kx").value, +$("ky").value, +$("kz").value],
        tmin: +$("tmin").value, tmax: +$("tmax").value, dt: +$("dt").value,
      }),
    });
    noteStepSignalFromResult(data);
    log("log-calc", data, !!data.ok);
    await refreshCalcStatus();
  });
  bind("btn-anphon-run", "click", async () => {
    if (!(await ensureJobForMaterial())) return;
    log("log-calc", "anphon…");
    const data = await api(`/api/jobs/${jobId}/anphon/run`, { method: "POST" });
    noteStepSignalFromResult(data);
    log("log-calc", data, !!data.ok);
    await refreshCalcStatus();
  });
  bind("btn-publish", "click", async () => {
    if (!(await ensureJobForMaterial())) return;
    const data = await api(`/api/jobs/${jobId}/publish`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ material }),
    });
    noteStepSignalFromResult(data);
    const msg = data.ok
      ? `Sorti → ${data.dir || "outputs/"} (${(data.files || []).length} fichier(s))`
      : data;
    if (page === "resultats") {
      log("results-job-label", msg, !!data.ok);
    } else {
      log("log-calc", msg, !!data.ok);
    }
    await refreshMaterials();
    if (page === "resultats") await refreshResults();
    else await refreshCalcStatus();
  });

  // init
  refreshTools().catch(() => {});
  if (page === "calcul") {
    setInterval(() => {
      pollStepSignal().catch(() => {});
    }, 5000);
  }
  if ($("material-select")) {
    refreshMaterials()
      .then(() => refreshJobs())
      .then(() => {
        if (page === "optimisation") return refreshOptimStatus();
        if (page === "calcul") return refreshCalcStatus();
        if (page === "resultats") return refreshResults();
        return null;
      })
      .catch(() => {});
    if (jobId) {
      const label = $("job-label");
      if (label) label.textContent = `Job : ${jobId}`;
    }
  }
  if (page === "resultats") refreshResults().catch(() => {});
})();

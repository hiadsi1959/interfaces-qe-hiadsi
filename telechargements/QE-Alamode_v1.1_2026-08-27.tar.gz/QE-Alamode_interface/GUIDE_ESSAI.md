# Essai rapide — QE–ALAMODE

Guide complet : [GUIDE.md](GUIDE.md) · guide UI : [guide-mini.html](interface/guide-mini.html)

```bash
cd /chemin/vers/QE-Alamode_interface
source /opt/intel/oneapi/setvars.sh   # Prop1
./DEMARRER.sh
# → http://127.0.0.1:5020/
```

## Selon la machine

| Machine | Que faire |
|---------|-----------|
| PC limité (≤12 Go, dual-core) | Tester en **1×1×1** : `python3 scripts/verify_dft_nxn.py --n 1 --run` |
| Station puissante (ex. **i9-14900K + 64 Go**) | Enchaîner jusqu’au **3×3×3** pour κ_L publiable |

Le **3×3×3 n’est pas impossible** : il est **prévu** pour les machines bien équipées. Sur un portable peu pourvu en RAM, validez d’abord la chaîne (N=1), puis lancez le 3×3×3 sur la machine puissante.

```bash
python3 scripts/verify_dft_nxn.py   # conseille N selon la RAM disponible
```

## Parcours UI (test chaîne sur PC limité)

1. **Optimisation** — VC-RELAX puis SCF (**Si**)  
2. **Calculs** — Utiliser SCF → supercellules **1×1×1** (2–6 motifs)  
3. Forces QE jusqu’à **n_done = n_expected** → DFSET  
4. alm **NORDER=1** (phonons) ou **2** (préparation κ_L)  
5. anphon `phonons` (puis `rta` si NORDER=2 et N≥2)  
6. **Résultats** — fiche HTML  

> 1×1×1 = validation de la chaîne · **non publiable** pour κ_L.  
> Pour κ_L publiable : **3×3×3 + NORDER=2** sur machine type 14900K / 64 Go.

 # Déploiement QE–ALAMODE sur un autre PC

**Auteur :** S. Hiadsi · LMESM / Faculté de Physique / USTO-MB · Oran, Algérie  
**Email :** said.hiadsi@univ-usto.dz

Ce document détaille ce qui est **dans l’interface**, ce qu’il faut **sur la machine cible**, et **trois propositions** pour emporter ALAMODE avec le projet.

---

## 1. Ce que contient (et ne contient pas) l’interface

| Élément | Dans `interface/` ? | Rôle |
|---------|---------------------|------|
| Pages HTML / CSS / JS | Oui | UI (Optimisation, Calculs, Résultats) |
| `work/`, `outputs/` | Dossiers vides possibles | Jobs en cours / résultats publiés |
| Backend Flask (`backend/`) | Non (projet complet) | API qui lance `pw.x`, `alm`, `anphon` |
| Quantum ESPRESSO (`pw.x`) | **Non** | Forces, SCF, relax — **toujours requis sur l’autre PC** |
| ALAMODE (`alm`, `anphon`) | **Non** (sauf si on les emballe) | IFC, phonons, κ_L |

**Important :** l’interface web seule ne calcule rien. Il faut le **backend** + les **exécutables**.

Les binaires actuels dans `bin/alm` et `bin/anphon` (compilés ici) dépendent d’**Intel oneAPI** :

- MKL : `libmkl_intel_lp64`, `libmkl_intel_thread`, `libmkl_core`
- OpenMP Intel : `libiomp5`
- MPI Intel : `libmpi` (pour `anphon`)
- Système : `libsymspg`, `libstdc++`, `libc`, …

Donc **copier uniquement** `alm` / `anphon` ne suffit en général **pas** sur un autre PC.

---

## 2. Prérequis toujours nécessaires sur l’autre PC

1. **Linux x86_64** (recommandé : Ubuntu 22.04+)
2. **Python 3.10+** + dépendances (`requirements.txt` : Flask, ASE, NumPy, …)
3. **Quantum ESPRESSO** compilé (`pw.x`) — chemin dans `QE_BIN_DIR`
4. Pseudos (dossier `pseudos/` du projet ou équivalent)

Installation guidée du projet :

```bash
./INSTALLER_AUTRE_PC.sh
# ou
./INSTALLER_AUTRE_PC.sh --install-deps --install-alamode
```

---

## 3. Trois propositions pour ALAMODE

### Proposition 1 — Interface + binaires + oneAPI sur la cible  
**Archive type :** `dist/QE-Alamode_prop1_interface_bin_*.tar.gz`  
**Guide détaillé dans le pack :** `README.md` (issu de `README_PROP1.md`)

| | |
|--|--|
| **Contenu** | `interface/`, `backend/`, `bin/alm`+`anphon`, `work/`+`outputs/` vides, `inputs/`, `pseudos/`, scripts d’install |
| **Sur l’autre PC** | QE **+** runtime Intel oneAPI (MKL + MPI) |
| **Taille** | ~quelques Mo |
| **Avantages** | Très simple à préparer ; binaires déjà validés ici |
| **Inconvénients** | L’autre PC **n’a pas** « QE seul » ; oneAPI à installer |
| **Quand l’utiliser** | Labo où oneAPI est déjà installé |

```bash
./scripts/pack_deploiement.sh prop1
```

#### Configuration sur l’autre PC (résumé Prop. 1)

```bash
tar -xzf QE-Alamode_prop1_interface_bin_*.tar.gz
cd QE-Alamode_prop1_interface_bin_*

# 1) Intel oneAPI (obligatoire pour ces binaires)
source /opt/intel/oneapi/setvars.sh
ldd bin/alm | grep -i 'not found' || echo "alm OK"

# 2) Python + config des chemins
chmod +x INSTALLER_AUTRE_PC.sh DEMARRER.sh ARRETER.sh CONFIGURER.sh
./INSTALLER_AUTRE_PC.sh --install-deps
# Interactif : indiquer le dossier de pw.x et laisser ALAMODE = ./bin
./INSTALLER_AUTRE_PC.sh
# ou non interactif :
#   export QE_BIN_DIR=/chemin/qe/bin
#   export ALAMODE_BIN_DIR=$PWD/bin
#   ./INSTALLER_AUTRE_PC.sh --non-interactif

# 3) Lancer
source /opt/intel/oneapi/setvars.sh
./DEMARRER.sh
# → http://127.0.0.1:5020/
```

Procédure complète, dépannage et vérifications : fichier **`README.md`** à la racine du pack Prop. 1.

---

### Proposition 2 — Recompilation portable d’ALAMODE (OpenBLAS / libs système)  
**Archive type :** `QE-Alamode_prop2_portable_*.tar.gz`  
**Script build :** `./scripts/INSTALL_ALAMODE_PORTABLE.sh`

| | |
|--|--|
| **Contenu** | Projet (ou pack) avec `bin/` issu d’une compile **sans** MKL Intel |
| **Sur l’autre PC** | **QE seulement** (+ paquets système courants : BLAS/LAPACK, spglib, OpenMPI si besoin) |
| **Taille** | Binaires petits ; pas de MKL embarqué |
| **Avantages** | Objectif « QE seul » le plus propre ; portable Linux ; pas de licence MKL à redistribuer |
| **Inconvénients** | Il faut **recompiler** une fois (ou livrer le résultat de cette compile) ; validation à refaire (petits tests Si) |
| **Quand l’utiliser** | Distribution à d’autres PC / étudiants / labos sans oneAPI |

```bash
# Sur cette machine (ou une machine de build) :
./scripts/INSTALL_ALAMODE_PORTABLE.sh
./scripts/pack_deploiement.sh prop2
```

Paquets typiques Ubuntu pour compiler / exécuter :

```bash
sudo apt-get install -y g++ gfortran cmake libeigen3-dev \
  libopenblas-dev liblapack-dev libsymspg-dev libopenmpi-dev
```

---

### Proposition 3 — Binaires actuels + libs oneAPI emballées (`lib/`)  
**Archive type :** `QE-Alamode_prop3_bundle_libs_*.tar.gz`

| | |
|--|--|
| **Contenu** | `interface/`, `bin/` (wrappers), `lib/` (~150 Mo de `.so` MKL/MPI/iomp5 + spglib), `work/`, `outputs/` |
| **Sur l’autre PC** | **QE seulement** (en pratique), Linux x86_64 compatible |
| **Taille** | ~160 Mo+ |
| **Avantages** | Pas besoin d’installer oneAPI sur la cible ; démarre vite si glibc compatible |
| **Inconvénients** | Gros ; fragile (glibc / OS) ; **redistribution MKL** soumise aux conditions Intel ; pas idéal long terme |
| **Quand l’utiliser** | Démo / machine isolée sans droits admin pour oneAPI |

```bash
./scripts/pack_deploiement.sh prop3
```

Les wrappers `bin/alm` et `bin/anphon` positionnent `LD_LIBRARY_PATH` vers `lib/`.

---

## 4. Comparatif rapide

| Critère | Prop. 1 | Prop. 2 | Prop. 3 |
|---------|---------|---------|---------|
| Simplicité de **préparation** | ★★★★★ | ★★☆☆☆ | ★★★★☆ |
| Simplicité pour **l’utilisateur final** | ★★☆☆☆ | ★★★★★ | ★★★★☆ |
| Objectif « **QE seul** » | Non | **Oui** | Oui (pratique) |
| Taille archive | Très petite | Petite | Moyenne (~160 Mo) |
| Robustesse long terme | Moyenne | **Bonne** | Moyenne |
| Licence / redistribution | OK (bin locaux) | **OK** (OpenBLAS) | Attention MKL |
| Recommandé pour labo USTO / partage | — | **Oui** | Démo uniquement |

---

## 5. Recommandation : la plus simple et la plus efficace

### La plus **simple à préparer maintenant** → **Proposition 1**
- On emballe `interface/` + `bin/` existants en une commande.
- Idéal si l’autre PC a déjà (ou peut avoir) Intel oneAPI.

### La plus **efficace** pour votre but (« emporter ALAMODE, ne dépendre que de QE ») → **Proposition 2**
- Une recompilation portable une fois, puis distribution légère et propre.
- Pas de dépendance oneAPI, pas de zone grise licence MKL.
- C’est le choix recommandé pour installer le projet sur d’autres PC de façon durable.

### Compromis rapide sans recompiler → **Proposition 3**
- Utile pour un transfert immédiat « ça marche tout de suite » sur un Linux x86_64 proche.
- À éviter comme solution officielle de diffusion (poids + licence MKL).

**Verdict :**  
- **Court terme / urgence** → Prop. 3 (ou Prop. 1 si oneAPI déjà là).  
- **Solution recommandée** → **Prop. 2 (portable)** : la plus efficace pour « QE seul ».

---

## 6. Contenu minimal d’un pack « prêt à installer »

Même avec ALAMODE emballé, un déploiement réel inclut en pratique :

```
QE-Alamode/
  interface/          # UI
  backend/            # API
  scripts/            # resume_job, pack, install
  bin/                # alm, anphon (+ wrappers prop3)
  lib/                # seulement prop3
  work/               # vide
  outputs/            # vide
  inputs/             # exemples (Si, …)
  pseudos/            # UPF
  INSTALLER_AUTRE_PC.sh
  DEMARRER.sh
  config_local.sh     # généré à l’install
  README_DEPLOIEMENT.md
```

Les scripts `./scripts/pack_deploiement.sh prop1|prop2|prop3` produisent les archives sous la racine du projet.

---

## 7. Vérification rapide sur la machine cible

```bash
source config_local.sh
"$QE_BIN_DIR/pw.x" -h | head -3
"$ALAMODE_BIN_DIR/alm" --help 2>&1 | head -5 || "$ALAMODE_BIN_DIR/alm" -h 2>&1 | head -5
ldd "$ALAMODE_BIN_DIR/alm" | grep -i 'not found' || echo "alm: libs OK"
ldd "$ALAMODE_BIN_DIR/anphon" | grep -i 'not found' || echo "anphon: libs OK"
./DEMARRER.sh
# navigateur → http://127.0.0.1:5020/
```

---

## 8. Contact

S. Hiadsi — LMESM / Faculté de Physique / USTO-MB, Oran, Algérie  
said.hiadsi@univ-usto.dz

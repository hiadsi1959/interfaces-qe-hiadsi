QE–ALAMODE Version 1.1 — 2026-08-27T13:51:36+01:00
Auteur : S. Hiadsi — LMESM / USTO-MB — said.hiadsi@univ-usto.dz
ALAMODE : bin/alm + bin/anphon (portable, sans oneAPI)
Lire : README.md

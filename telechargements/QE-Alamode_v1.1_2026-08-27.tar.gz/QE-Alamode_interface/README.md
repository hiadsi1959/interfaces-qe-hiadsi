# QE–ALAMODE Version 1.1

**Auteur :** Prof. S. Hiadsi — LMESM / Faculté de Physique / USTO-MB, Oran  
**Date :** 2026-08-27  
**Port :** http://127.0.0.1:5020/

## Contenu

- Interface web locale (Calculs, Optimisation, Résultats, Guide)
- Backend API Flask
- **ALAMODE embarqué** : `bin/alm` et `bin/anphon` (compile portable, **sans Intel oneAPI / MKL**)
- Guides et exemples (Si)

## Prérequis sur votre PC (Ubuntu)

1. **Quantum ESPRESSO** (`pw.x`) installé
2. Python 3.9+
3. Paquets système usuels (souvent déjà présents) :
   ```bash
   sudo apt-get install -y libblas3 liblapack3 libsymspg2 libgomp1 libopenmpi3
   ```
   *(noms exacts selon la version Ubuntu — `ldd bin/alm` indique les libs manquantes)*

**Vous n’avez pas à compiler ni installer ALAMODE** : les binaires sont dans `bin/`.

## Installation rapide

```bash
tar -xzf QE-Alamode_v1.1_2026-08-27.tar.gz
cd QE-Alamode_interface
export QE_BIN_DIR=/chemin/vers/qe/bin          # dossier contenant pw.x
export ALAMODE_BIN_DIR=$PWD/bin               # alm + anphon fournis
./INSTALLER_AUTRE_PC.sh --non-interactif
./DEMARRER.sh
# → http://127.0.0.1:5020/
```

## Version 1.1 — testée et corrigée

- Smoke DFT 1×1×1 validé (QE → DFSET → alm → phonons)
- Page Résultats corrigée (configs DFSET, fiche technique, export, graphiques)
- Guide 3×3×3 clarifié (standard sur machine forte, ex. i9-14900K + 64 Go)
- Garde-fous scientifiques (DFSET complet, NORDER=2 pour κ_L, RTA)
- Pack **Prop2** : ALAMODE portable inclus

## Licence d’usage

Libre pour la recherche et l’enseignement. Toute modification du code nécessite une collaboration avec l’auteur.

Contact : said.hiadsi@univ-usto.dz

# Guide QE–ALAMODE — outil scientifique (HIADSI)

**Auteur :** S. Hiadsi · LMESM / USTO-MB · said.hiadsi@univ-usto.dz  
**Interface locale :** http://127.0.0.1:5020/  
**Démarrage :** `./DEMARRER.sh` (depuis le dossier de l’interface)

Plateforme **autonome** pour phonons anharmoniques et conductivité thermique de réseau κ_L  
(Quantum ESPRESSO `pw.x` + ALAMODE `alm` / `anphon`).

---

## Objectif scientifique

| Grandeur | Prérequis | Critère de qualité |
|----------|-----------|-------------------|
| Phonons (bandes, Γ) | DFSET complet · NORDER ≥ 1 | 0 mode imaginaire · ω_Γ cohérent |
| κ_L (RTA) | DFSET complet · **NORDER ≥ 2** · supercellule ≥ 2×2×2 | courbe κ(T) · fichier `.kl` |

> **Publication κ_L :** supercellule idéalement **3×3×3**, **NORDER = 2**, tous les motifs `pw.x` en `JOB DONE` avant DFSET, puis `anphon` mode `phonons` puis `rta`.

---

## Matériel — choisir N×N×N selon le PC

| Supercellule | Atomés (Si) | RAM QE typ. | PC adapté | Durée indicative | Usage |
|--------------|-------------|-------------|-----------|------------------|--------|
| **1×1×1** | 2 | ~0,5 Go | tout PC (≥8 Go) | ~30–60 min | **Vérifier la chaîne** (phonons) |
| **2×2×2** | 16 | ~2–4 Go | ≥ 8–16 Go | ~3–8 h (PC moyen) | κ_L indicative |
| **3×3×3** | 54 | **~10 Go / process** | **machine puissante** | voir ci-dessous | **κ_L publiable** |

### 3×3×3 — ce n’est pas « impossible »

Le DFT 3×3×3 **fonctionne très bien** sur une station ou un serveur bien équipé, par exemple :
- **Intel Core i9-14900K** (ou équivalent AMD) + **32–64 Go RAM**
- workstation / cluster avec MPI

| Machine | 3×3×3 Si (12 motifs) |
|---------|----------------------|
| i9-14900K · **64 Go** RAM | **recommandé** — typiquement **quelques heures à ~1–2 jours** selon MPI/OpenMP |
| ≥16–32 Go · CPU récent multi-cœurs | **OK** — ~1–3 jours en séquentiel / moins avec MPI |
| ~8–12 Go · dual-core (ex. i7-7500U) | **à éviter** — QE demande ~10 Go/process → OOM / `SIGTERM` / swap |

Sur un **PC portable limité** : validez d’abord avec **N=1** (ou N=2), puis lancez le 3×3×3 sur la machine puissante.

```bash
# Diagnostic machine + N recommandé (sans calcul)
python3 scripts/verify_dft_nxn.py

# Vérification DFT réelle avec N petit (API démarrée) — PC limité
./DEMARRER.sh
python3 scripts/verify_dft_nxn.py --n 1 --run
```

Contrôler un job déjà lancé :
```bash
python3 scripts/verify_dft_nxn.py --n 3 --job 20260803_230151_Si
```

---

## Chemins (relatifs au dossier d’installation)

| Rôle | Dossier |
|------|---------|
| Inputs | `inputs/<Matériau>/` |
| Outputs | `outputs/<matériau>/` |
| Pseudos | `pseudos/` |
| Binaires ALAMODE | `bin/` (`alm`, `anphon`) |
| Jobs | `work/<job_id>/` |

Prop1 : charger Intel oneAPI avant démarrage (`source /opt/intel/oneapi/setvars.sh`).

---

## Parcours recommandé

1. **Optimisation** — VC-RELAX → (RELAX) → SCF  
2. **Calculs** — SCF → supercellules → forces QE (tous les lots) → DFSET → alm → anphon  
3. **Résultats** — grandeurs, bandes, κ_L, fiche technique  

Le **guide détaillé** est dans l’interface : **Calculs → Guide scientifique** ou `guide-mini.html`.

---

## Onglet Calculs — règles critiques

1. **SCF** — charger `inputs/<Mat>/<Mat>-scf.in`  
2. **Supercellules** — choisir N selon le PC (tableau ci-dessus)  
3. **Forces QE** — « Configs / lot » ; **relancer** jusqu’à `n_done = n_expected`  
4. **DFSET** — refusé si motifs incomplets  
5. **alm** — **NORDER = 2** pour κ_L (1 = phonons seulement)  
6. **anphon** — `phonons` puis `rta` · `&cell` = maille **primitive**

---

## Lancer / arrêter

```bash
cd /chemin/vers/QE-Alamode_interface
source /opt/intel/oneapi/setvars.sh   # Prop1
./DEMARRER.sh
./ARRETER.sh
```

Exemple prêt : `inputs/Si/` + `pseudos/Si.UPF`.

---

## Licence

Usage libre pour la recherche et l’enseignement.  
Modification du code : collaboration avec l’auteur.  
Voir `LICENCE_ET_CONDITIONS.txt`.

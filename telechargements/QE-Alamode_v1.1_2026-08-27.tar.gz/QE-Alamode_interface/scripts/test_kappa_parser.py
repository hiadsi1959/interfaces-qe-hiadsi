#!/usr/bin/env python3
"""Tests unitaires — parseur κ_L (.kl) et garde-fous RTA (sans QE)."""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

from alamode_io import parse_kappa_file, write_anphon_phonons  # noqa: E402

REF_KL = Path.home() / "alamode/src/example/Si/reference/si222.kl"


def test_parse_reference_kl() -> None:
    assert REF_KL.is_file(), f"Référence absente : {REF_KL}"
    rows = parse_kappa_file(REF_KL)
    assert rows, "parse_kappa_file a renvoyé []"
    assert all("T" in r and "kappa_xx" in r for r in rows)
    # Point proche de 300 K
    near = min(rows, key=lambda r: abs(r["T"] - 300.0))
    k = float(near["kappa_xx"])
    assert 50.0 < k < 250.0, f"κ(≈300 K) hors plage attendue : {k}"
    print(f"OK parse référence · {len(rows)} points · κ(≈{near['T']} K)={k:.3g} W/m/K")


def test_parse_synthetic_tensor() -> None:
    text = "# T  xx xy xz yx yy yz zx zy zz\n300 100 0 0 0 100 0 0 0 100\n400 80 0 0 0 80 0 0 0 80\n"
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "demo.kl"
        p.write_text(text, encoding="utf-8")
        rows = parse_kappa_file(p)
    assert len(rows) == 2
    assert rows[0]["kappa_xx"] == 100.0
    assert rows[0]["kappa_yy"] == 100.0
    assert rows[1]["kappa_zz"] == 80.0
    print("OK parse tenseur synthétique 10 colonnes")


def test_anphon_cell_is_bohr_scaled() -> None:
    """Les vecteurs écrits sont en Bohr (× ANG_TO_BOHR)."""
    with tempfile.TemporaryDirectory() as td:
        dest = Path(td) / "anphon.in"
        # Maille cubique a=5.43 Å (Si)
        a = 5.43
        write_anphon_phonons(
            dest,
            prefix="Si",
            kd_names=["Si"],
            masses=[28.0855],
            lattice_vectors=[[a, 0, 0], [0, a, 0], [0, 0, a]],
            mode="rta",
            kmesh=(4, 4, 4),
            tmin=300,
            tmax=500,
            dt=100,
        )
        text = dest.read_text(encoding="utf-8")
        assert "MODE = rta" in text
        assert "TMIN = 300" in text
        # ~5.43 / 0.529 ≈ 10.26 Bohr
        assert "10.2" in text or "10.26" in text
    print("OK write_anphon MODE=rta + cellule Bohr")


def test_xml_anharm3_helper() -> None:
    import workflow as wf

    with tempfile.TemporaryDirectory() as td:
        job = Path(td)
        alamode = job / "alamode"
        alamode.mkdir()
        xml = alamode / "demo.xml"
        xml.write_text("<ForceConstants><HARMONIC/></ForceConstants>\n", encoding="utf-8")
        assert wf._xml_has_anharm3(xml) is False
        xml.write_text("<ForceConstants><ANHARM3/><FC3/></ForceConstants>\n", encoding="utf-8")
        assert wf._xml_has_anharm3(xml) is True
    print("OK détection ANHARM3/FC3")


def main() -> int:
    test_parse_synthetic_tensor()
    test_anphon_cell_is_bohr_scaled()
    test_xml_anharm3_helper()
    if REF_KL.is_file():
        test_parse_reference_kl()
    else:
        print(f"SKIP référence {REF_KL}")
    print("\nTous les tests κ_L (parseur / garde-fous) : OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

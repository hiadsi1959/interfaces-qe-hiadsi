#!/usr/bin/env bash
# Emballage des 3 propositions de déploiement.
# Usage :
#   ./scripts/pack_deploiement.sh prop1|prop2|prop3|all
set -euo pipefail

HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$HERE"
STAMP="$(date +%Y%m%d_%H%M%S)"
MODE="${1:-}"
OUTDIR="$HERE/dist"
mkdir -p "$OUTDIR"

die() { echo "ERREUR: $*" >&2; exit 1; }

stage_common() {
  local root="$1"
  mkdir -p "$root/interface" "$root/work" "$root/outputs" "$root/bin"
  cp -a "$HERE/interface/." "$root/interface/"
  : >"$root/work/.gitkeep"
  : >"$root/outputs/.gitkeep"
  cp -f "$HERE/README_DEPLOIEMENT.md" "$root/"
  cat >"$root/README_PACK.txt" <<EOF
QE–ALAMODE — pack de déploiement
Auteur : S. Hiadsi — LMESM / USTO-MB — said.hiadsi@univ-usto.dz
Date   : $(date -Iseconds)
Voir   : README_DEPLOIEMENT.md
EOF
}

pack_prop1() {
  local name="QE-Alamode_prop1_interface_bin_${STAMP}"
  local stage
  stage="$(mktemp -d)"
  local root="$stage/$name"
  stage_common "$root"
  [[ -x "$HERE/bin/alm" && -x "$HERE/bin/anphon" ]] || die "bin/alm ou bin/anphon manquant"
  cp -f "$HERE/bin/alm" "$HERE/bin/anphon" "$root/bin/"

  # Pack utilisable : backend + scripts + inputs + pseudos
  mkdir -p "$root/backend" "$root/scripts" "$root/inputs" "$root/pseudos" "$root/logs"
  cp -a "$HERE/backend/." "$root/backend/"
  rm -rf "$root/backend/__pycache__"
  find "$root/backend" -type d -name '__pycache__' -prune -exec rm -rf {} + 2>/dev/null || true
  cp -a "$HERE/inputs/." "$root/inputs/" 2>/dev/null || true
  cp -a "$HERE/pseudos/." "$root/pseudos/" 2>/dev/null || true
  cp -f "$HERE/requirements.txt" "$root/"
  cp -f "$HERE/INSTALLER_AUTRE_PC.sh" "$HERE/DEMARRER.sh" "$HERE/ARRETER.sh" \
        "$HERE/CONFIGURER.sh" "$root/"
  # scripts utiles (sans recopier tout le dépôt)
  for s in resume_job.sh complete_pipeline.sh watch_job.sh signal_etape.py \
           INSTALL_ALAMODE.sh pack_deploiement.sh; do
    [[ -f "$HERE/scripts/$s" ]] && cp -f "$HERE/scripts/$s" "$root/scripts/"
  done
  chmod +x "$root/"*.sh "$root/scripts/"*.sh "$root/bin/"* 2>/dev/null || true

  # README principal = guide Prop. 1 (config autre PC)
  if [[ -f "$HERE/README_PROP1.md" ]]; then
    cp -f "$HERE/README_PROP1.md" "$root/README.md"
    cp -f "$HERE/README_PROP1.md" "$root/README_PROP1.md"
  else
    die "README_PROP1.md manquant"
  fi
  cp -f "$HERE/README_DEPLOIEMENT.md" "$root/"

  cat >"$root/README_PACK.txt" <<EOF
QE–ALAMODE — Proposition 1 (interface + bin ALAMODE)
Auteur : S. Hiadsi — LMESM / USTO-MB — said.hiadsi@univ-usto.dz
Date   : $(date -Iseconds)

Lire en premier : README.md  (configuration sur un autre PC)
Complément      : README_DEPLOIEMENT.md
EOF

  local archive="$OUTDIR/${name}.tar.gz"
  tar -czf "$archive" -C "$stage" "$name"
  rm -rf "$stage"
  # Copie pratique à la racine du projet
  cp -f "$archive" "$HERE/"
  echo "OK prop1 → $archive ($(du -h "$archive" | awk '{print $1}'))"
  echo "     aussi → $HERE/$(basename "$archive")"
}

pack_prop2() {
  local src_bin="$HERE/bin-portable"
  [[ -x "$src_bin/alm" && -x "$src_bin/anphon" ]] || die \
    "bin-portable/ absent. Lancez d'abord : ./scripts/INSTALL_ALAMODE_PORTABLE.sh"
  local name="QE-Alamode_prop2_portable_${STAMP}"
  local stage
  stage="$(mktemp -d)"
  local root="$stage/$name"
  stage_common "$root"
  cp -f "$src_bin/alm" "$src_bin/anphon" "$root/bin/"
  # Inclure un extrait backend minimal utile + scripts install
  mkdir -p "$root/backend" "$root/scripts"
  cp -a "$HERE/backend/." "$root/backend/"
  cp -f "$HERE/scripts/INSTALL_ALAMODE_PORTABLE.sh" "$HERE/scripts/INSTALL_ALAMODE.sh" \
        "$HERE/INSTALLER_AUTRE_PC.sh" "$HERE/DEMARRER.sh" "$HERE/ARRETER.sh" \
        "$HERE/CONFIGURER.sh" "$root/" 2>/dev/null || true
  cp -f "$HERE/requirements.txt" "$root/" 2>/dev/null || true
  cat >"$root/README_PROP2.txt" <<'EOF'
PROPOSITION 2 — ALAMODE recompilé portable (OpenBLAS / libs système)

Sur l'autre PC il faut surtout :
  1. Quantum ESPRESSO (pw.x)
  2. Paquets système éventuels : libopenblas, liblapack, libsymspg, libopenmpi
  3. Python + pip install -r requirements.txt

Puis :
  export QE_BIN_DIR=/chemin/qe/bin
  export ALAMODE_BIN_DIR=$PWD/bin
  ./INSTALLER_AUTRE_PC.sh --non-interactif
  ./DEMARRER.sh

C'est la proposition recommandée pour « QE seul ».
EOF
  local archive="$OUTDIR/${name}.tar.gz"
  tar -czf "$archive" -C "$stage" "$name"
  rm -rf "$stage"
  echo "OK prop2 → $archive ($(du -h "$archive" | awk '{print $1}'))"
}

pack_prop3() {
  local name="QE-Alamode_prop3_bundle_libs_${STAMP}"
  local stage
  stage="$(mktemp -d)"
  local root="$stage/$name"
  stage_common "$root"
  mkdir -p "$root/lib" "$root/bin/.real"
  [[ -x "$HERE/bin/alm" && -x "$HERE/bin/anphon" ]] || die "bin/alm ou bin/anphon manquant"

  cp -f "$HERE/bin/alm" "$root/bin/.real/alm"
  cp -f "$HERE/bin/anphon" "$root/bin/.real/anphon"

  # Copier les .so non-système nécessaires (oneAPI + spglib)
  copy_dep() {
    local so="$1"
    [[ -n "$so" && -e "$so" ]] || return 0
    local base
    base="$(basename "$so")"
    # ignorer libc / libm / libpthread / ld-linux / libstdc++
    case "$base" in
      libc.so*|libm.so*|libdl.so*|librt.so*|libpthread.so*|libgcc_s.so*|libstdc++.so*|ld-linux*) return 0 ;;
    esac
    # ne garder que oneAPI / intel / spglib (évite de pomper /usr/lib entier)
    case "$so" in
      *oneapi*|*intel*|*mkl*|*iomp*|*symspg*|*spglib*) ;;
      *) return 0 ;;
    esac
    cp -fL "$so" "$root/lib/$base" 2>/dev/null || cp -f "$so" "$root/lib/$base" || true
  }

  for exe in alm anphon; do
    while read -r so; do
      copy_dep "$so"
    done < <(ldd "$HERE/bin/$exe" 2>/dev/null | awk '/=> \// {print $3}')
  done
  local nlib
  nlib="$(find "$root/lib" -type f | wc -l)"
  [[ "$nlib" -ge 3 ]] || die "prop3: trop peu de libs copiées ($nlib) — oneAPI accessible ?"

  # Wrappers LD_LIBRARY_PATH
  for exe in alm anphon; do
    cat >"$root/bin/$exe" <<EOF
#!/usr/bin/env bash
HERE="\$(cd "\$(dirname "\$0")/.." && pwd)"
export LD_LIBRARY_PATH="\$HERE/lib:\${LD_LIBRARY_PATH:-}"
exec "\$HERE/bin/.real/$exe" "\$@"
EOF
    chmod +x "$root/bin/$exe"
  done

  cat >"$root/README_PROP3.txt" <<'EOF'
PROPOSITION 3 — binaires + libs Intel emballées (lib/)

Sur l'autre PC : Quantum ESPRESSO (pw.x) + ce pack.
Les wrappers bin/alm et bin/anphon chargent lib/ via LD_LIBRARY_PATH.

Attention :
  - Linux x86_64, glibc compatible recommandé
  - Redistribution des libs MKL : vérifier la licence Intel
  - Pack destiné surtout aux démos / transferts rapides

Test :
  ./bin/alm  (doit démarrer sans "not found")
  ldd bin/.real/alm | head
EOF
  # backend léger pour pouvoir démarrer si besoin
  mkdir -p "$root/backend"
  cp -a "$HERE/backend/." "$root/backend/"
  cp -f "$HERE/DEMARRER.sh" "$HERE/ARRETER.sh" "$HERE/INSTALLER_AUTRE_PC.sh" \
        "$HERE/requirements.txt" "$root/" 2>/dev/null || true

  local archive="$OUTDIR/${name}.tar.gz"
  tar -czf "$archive" -C "$stage" "$name"
  rm -rf "$stage"
  echo "OK prop3 → $archive ($(du -h "$archive" | awk '{print $1}'))"
}

usage() {
  echo "Usage: $0 prop1|prop2|prop3|all"
  echo "  prop1 — interface + bin (oneAPI requis sur cible)"
  echo "  prop2 — nécessite bin-portable/ (INSTALL_ALAMODE_PORTABLE.sh)"
  echo "  prop3 — interface + bin + lib/ emballées"
  echo "Archives → $OUTDIR/"
}

case "$MODE" in
  prop1) pack_prop1 ;;
  prop2) pack_prop2 ;;
  prop3) pack_prop3 ;;
  all)
    pack_prop1
    pack_prop3
    if [[ -x "$HERE/bin-portable/alm" ]]; then
      pack_prop2
    else
      echo "NOTE: prop2 ignoré (lancez ./scripts/INSTALL_ALAMODE_PORTABLE.sh puis re-pack prop2)"
    fi
    ;;
  *) usage; exit 1 ;;
esac

echo "Fichiers dans $OUTDIR :"
ls -lh "$OUTDIR"/*"${STAMP}"* 2>/dev/null || ls -lht "$OUTDIR" | head -10

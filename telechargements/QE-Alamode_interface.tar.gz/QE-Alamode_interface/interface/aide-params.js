(() => {
  const CONTENT = {
    fr: {
      checklist: [
        "Structure convergée · forces < 1 mRy/Bohr",
        "SCF · conv_thr = 1×10⁻⁸ · k-points convergés",
        "Supercellule 2×2×2 · amplitude 0,01 Å · motifs ≥ 3×N_at",
        "alm · erreur < 2 % · 0 mode imaginaire",
        "κ_L · NORDER ≥ 2 · anphon rta · k ≥ 10×10×10",
      ],
      reliabilityGeneral: [
        "Comparer deux jobs : ω(Γ) stable à ± 1 %",
        "Valider la fiche (Résultats) avant Export",
      ],
      optimisation: [
        {
          id: "recap",
          title: "Récap · Optimisation",
          badge: "Synthèse",
          intro: "Valeurs recommandées dans les fichiers QE (Éditer → input).",
          recommended: [
            { field: "ecutwfc", value: "60 Ry", note: "≥ 1,3× cutoff pseudo" },
            { field: "ecutrho", value: "480 Ry", note: "8 × ecutwfc" },
            { field: "K_POINTS", value: "8 8 8", note: "10 10 10 pour publication" },
            { field: "conv_thr", value: "1.0d-8", note: "" },
            { field: "forc_conv_thr", value: "1.0d-4", note: "VC-RELAX / RELAX" },
            { field: "press_conv_thr", value: "0.5", note: "kbar · VC-RELAX" },
            { field: "tprnfor", value: ".true.", note: "SCF · forces phonons" },
          ],
        },
        {
          id: "vc-relax",
          title: "VC-RELAX",
          badge: "Prérequis",
          recommended: [
            { field: "calculation", value: "vc-relax", note: "" },
            { field: "ecutwfc / ecutrho", value: "60 / 480 Ry", note: "" },
            { field: "K_POINTS", value: "8 8 8", note: "semiconducteur type Si" },
            { field: "forc_conv_thr", value: "1.0d-4", note: "Ry/Bohr" },
            { field: "press_conv_thr", value: "0.5", note: "kbar" },
            { field: "cell_dofree", value: "all", note: "section &CELL" },
          ],
          reliability: [
            "Forces finales < 1 mRy/Bohr",
            "Test ecut +10 Ry : ΔE < 1 meV/at",
          ],
        },
        {
          id: "relax",
          title: "RELAX",
          badge: "Optionnel",
          recommended: [
            { field: "calculation", value: "relax", note: "maille fixe" },
            { field: "ecut / K_POINTS", value: "identiques VC-RELAX", note: "" },
            { field: "forc_conv_thr", value: "1.0d-4", note: "" },
          ],
        },
        {
          id: "scf-opt",
          title: "SCF",
          badge: "Prérequis",
          recommended: [
            { field: "calculation", value: "scf", note: "" },
            { field: "conv_thr", value: "1.0d-8", note: "" },
            { field: "mixing_beta", value: "0.7", note: "0.3–0.5 si instable" },
            { field: "K_POINTS", value: "8 8 8", note: "10 10 10 publication" },
            { field: "tprnfor", value: ".true.", note: "obligatoire" },
          ],
        },
      ],
      calcul: [
        {
          id: "recap",
          title: "Récap · Calculs (interface)",
          badge: "Synthèse",
          intro: "Meilleures valeurs à saisir dans les cartes de l’onglet Calculs.",
          recommended: [
            { field: "nx · ny · nz", value: "3 · 3 · 3", note: "grande supercellule recommandée" },
            { field: "Amplitude (Å)", value: "0.01", note: "déplacement fini" },
            { field: "Nb motifs", value: "12", note: "Si (2 at.) · min = 3×N_at = 6" },
            { field: "Max jobs", value: "8", note: "parallélisation pw.x" },
            { field: "NORDER", value: "1", note: "phonons · 2 pour κ_L" },
            { field: "Cutoff Å", value: "0", note: "None · ou 6–8 si besoin" },
            { field: "Mode anphon", value: "phonons", note: "rta si NORDER ≥ 2" },
            { field: "kx · ky · kz", value: "10 · 10 · 10", note: "20 pour κ_L publication" },
            { field: "Tmin · Tmax · ΔT", value: "300 · 1000 · 50", note: "K · courbe κ_L" },
          ],
        },
        {
          id: "scf",
          title: "SCF",
          badge: "1",
          recommended: [
            { field: "Action", value: "Utiliser SCF", note: "inputs/&lt;Mat&gt;/&lt;Mat&gt;-scf.in" },
            { field: "conv_thr", value: "1.0d-8", note: "comme optimisation" },
            { field: "ecutwfc / ecutrho", value: "60 / 480 Ry", note: "ne pas réduire" },
          ],
        },
        {
          id: "supercell",
          title: "Supercellules",
          badge: "2",
          recommended: [
            { field: "nx", value: "3", note: "grande supercellule · 2 min publiable" },
            { field: "ny", value: "3", note: "" },
            { field: "nz", value: "3", note: "" },
            { field: "Amplitude (Å)", value: "0.01", note: "standard ALAMODE" },
            { field: "Nb motifs", value: "12", note: "Si · formule ≥ 3×N_at" },
          ],
          reliability: [
            "1×1×1 : test rapide seulement",
            "12–16 motifs : meilleur ajustement alm",
            "Amplitude : 0.008–0.012 Å si doute",
          ],
        },
        {
          id: "forces",
          title: "Forces QE",
          badge: "3",
          recommended: [
            { field: "Max jobs", value: "8", note: "selon cœurs disponibles" },
            { field: "conv_thr (pw.x)", value: "1.0d-10", note: "forces précises" },
            { field: "ecutwfc", value: "60 Ry", note: "identique SCF" },
          ],
          reliability: [
            "Lancer pw.x puis DFSET",
            "Chaque motif doit converger",
          ],
        },
        {
          id: "alm",
          title: "alm",
          badge: "4",
          recommended: [
            { field: "NORDER", value: "1", note: "phonons harmoniques" },
            { field: "NORDER", value: "2", note: "κ_L (relancer forces)" },
            { field: "Cutoff Å", value: "0", note: "publication · 6–8 si fit instable" },
            { field: "Erreur fit cible", value: "< 2 %", note: "lire dans Résultats" },
          ],
        },
        {
          id: "anphon",
          title: "anphon",
          badge: "5",
          recommended: [
            { field: "Mode", value: "phonons", note: "bandes · NORDER = 1" },
            { field: "Mode", value: "rta", note: "κ_L · NORDER ≥ 2" },
            { field: "kx · ky · kz", value: "10 · 10 · 10", note: "15–20 publication κ_L" },
            { field: "Tmin", value: "300", note: "K" },
            { field: "Tmax", value: "1000", note: "K" },
            { field: "ΔT", value: "50", note: "K" },
          ],
          reliability: [
            "0 mode imaginaire à Γ",
            "Comparer ω_max avec littérature",
          ],
        },
        {
          id: "publish",
          title: "Export",
          badge: "Sortie",
          intro: "Après validation des grandeurs (onglet Résultats).",
          recommended: [
            { field: "Destination", value: "outputs/&lt;Mat&gt;/&lt;job&gt;/", note: "" },
          ],
          files: [".xml", ".fcs", ".bands", ".kl", "DFSET", "fiche_technique.html"],
        },
      ],
    },
    en: {
      checklist: [
        "Converged structure · forces < 1 mRy/Bohr",
        "SCF · conv_thr = 1×10⁻⁸ · converged k-mesh",
        "Supercell 2×2×2 · amplitude 0.01 Å · patterns ≥ 3×N_at",
        "alm · error < 2 % · 0 imaginary modes",
        "κ_L · NORDER ≥ 2 · anphon rta · k ≥ 10×10×10",
      ],
      reliabilityGeneral: [
        "Compare two jobs: ω(Γ) stable within ± 1 %",
        "Validate sheet (Results) before Export",
      ],
      optimisation: [
        {
          id: "recap",
          title: "Summary · Optimization",
          badge: "Overview",
          intro: "Recommended values in QE input files (Edit → input).",
          recommended: [
            { field: "ecutwfc", value: "60 Ry", note: "≥ 1.3× pseudo cutoff" },
            { field: "ecutrho", value: "480 Ry", note: "8 × ecutwfc" },
            { field: "K_POINTS", value: "8 8 8", note: "10 10 10 for publication" },
            { field: "conv_thr", value: "1.0d-8", note: "" },
            { field: "forc_conv_thr", value: "1.0d-4", note: "VC-RELAX / RELAX" },
            { field: "press_conv_thr", value: "0.5", note: "kbar · VC-RELAX" },
            { field: "tprnfor", value: ".true.", note: "SCF · phonon forces" },
          ],
        },
        {
          id: "vc-relax",
          title: "VC-RELAX",
          badge: "Required",
          recommended: [
            { field: "calculation", value: "vc-relax", note: "" },
            { field: "ecutwfc / ecutrho", value: "60 / 480 Ry", note: "" },
            { field: "K_POINTS", value: "8 8 8", note: "semiconductor e.g. Si" },
            { field: "forc_conv_thr", value: "1.0d-4", note: "Ry/Bohr" },
            { field: "press_conv_thr", value: "0.5", note: "kbar" },
            { field: "cell_dofree", value: "all", note: "&CELL section" },
          ],
          reliability: [
            "Final forces < 1 mRy/Bohr",
            "Test ecut +10 Ry: ΔE < 1 meV/atom",
          ],
        },
        {
          id: "relax",
          title: "RELAX",
          badge: "Optional",
          recommended: [
            { field: "calculation", value: "relax", note: "fixed cell" },
            { field: "ecut / K_POINTS", value: "same as VC-RELAX", note: "" },
            { field: "forc_conv_thr", value: "1.0d-4", note: "" },
          ],
        },
        {
          id: "scf-opt",
          title: "SCF",
          badge: "Required",
          recommended: [
            { field: "calculation", value: "scf", note: "" },
            { field: "conv_thr", value: "1.0d-8", note: "" },
            { field: "mixing_beta", value: "0.7", note: "0.3–0.5 if unstable" },
            { field: "K_POINTS", value: "8 8 8", note: "10 10 10 publication" },
            { field: "tprnfor", value: ".true.", note: "required" },
          ],
        },
      ],
      calcul: [
        {
          id: "recap",
          title: "Summary · Calculations (UI)",
          badge: "Overview",
          intro: "Best values to enter in the Calculations tab cards.",
          recommended: [
            { field: "nx · ny · nz", value: "3 · 3 · 3", note: "large supercell recommended" },
            { field: "Amplitude (Å)", value: "0.01", note: "finite displacement" },
            { field: "Patterns", value: "12", note: "Si (2 at.) · min = 3×N_at = 6" },
            { field: "Max jobs", value: "8", note: "pw.x parallel runs" },
            { field: "NORDER", value: "1", note: "phonons · 2 for κ_L" },
            { field: "Cutoff Å", value: "0", note: "None · or 6–8 if needed" },
            { field: "anphon Mode", value: "phonons", note: "rta if NORDER ≥ 2" },
            { field: "kx · ky · kz", value: "10 · 10 · 10", note: "20 for κ_L publication" },
            { field: "Tmin · Tmax · ΔT", value: "300 · 1000 · 50", note: "K · κ_L curve" },
          ],
        },
        {
          id: "scf",
          title: "SCF",
          badge: "1",
          recommended: [
            { field: "Action", value: "Use SCF", note: "inputs/&lt;Mat&gt;/&lt;Mat&gt;-scf.in" },
            { field: "conv_thr", value: "1.0d-8", note: "same as optimization" },
            { field: "ecutwfc / ecutrho", value: "60 / 480 Ry", note: "do not reduce" },
          ],
        },
        {
          id: "supercell",
          title: "Supercells",
          badge: "2",
          recommended: [
            { field: "nx", value: "3", note: "large supercell · 2 min publication" },
            { field: "ny", value: "3", note: "" },
            { field: "nz", value: "3", note: "" },
            { field: "Amplitude (Å)", value: "0.01", note: "ALAMODE standard" },
            { field: "Patterns", value: "12", note: "Si · use ≥ 3×N_at" },
          ],
          reliability: [
            "1×1×1: quick test only",
            "12–16 patterns: better alm fit",
            "Amplitude: 0.008–0.012 Å if unsure",
          ],
        },
        {
          id: "forces",
          title: "QE Forces",
          badge: "3",
          recommended: [
            { field: "Max jobs", value: "8", note: "match available cores" },
            { field: "conv_thr (pw.x)", value: "1.0d-10", note: "accurate forces" },
            { field: "ecutwfc", value: "60 Ry", note: "same as SCF" },
          ],
          reliability: [
            "Run pw.x then DFSET",
            "Every pattern must converge",
          ],
        },
        {
          id: "alm",
          title: "alm",
          badge: "4",
          recommended: [
            { field: "NORDER", value: "1", note: "harmonic phonons" },
            { field: "NORDER", value: "2", note: "κ_L (rerun forces)" },
            { field: "Cutoff Å", value: "0", note: "publication · 6–8 if unstable fit" },
            { field: "Target fit error", value: "< 2 %", note: "check in Results" },
          ],
        },
        {
          id: "anphon",
          title: "anphon",
          badge: "5",
          recommended: [
            { field: "Mode", value: "phonons", note: "bands · NORDER = 1" },
            { field: "Mode", value: "rta", note: "κ_L · NORDER ≥ 2" },
            { field: "kx · ky · kz", value: "10 · 10 · 10", note: "15–20 for κ_L publication" },
            { field: "Tmin", value: "300", note: "K" },
            { field: "Tmax", value: "1000", note: "K" },
            { field: "ΔT", value: "50", note: "K" },
          ],
          reliability: [
            "0 imaginary modes at Γ",
            "Compare ω_max with literature",
          ],
        },
        {
          id: "publish",
          title: "Export",
          badge: "Output",
          intro: "After validating quantities (Results tab).",
          recommended: [
            { field: "Destination", value: "outputs/&lt;Mat&gt;/&lt;job&gt;/", note: "" },
          ],
          files: [".xml", ".fcs", ".bands", ".kl", "DFSET", "fiche_technique.html"],
        },
      ],
    },
  };

  function lang() {
    return window.qeI18n?.getLang?.() === "fr" ? "fr" : "en";
  }

  function getSections(page) {
    const L = CONTENT[lang()] || CONTENT.en;
    const base = L[page] || [];
    if (page === "calcul" && base.length) {
      const pub = base.find((s) => s.id === "pub");
      if (!pub) {
        return [
          {
            id: "pub",
            title: lang() === "fr" ? "Objectif" : "Goal",
            badge: lang() === "fr" ? "Qualité" : "Quality",
            intro: lang() === "fr"
              ? "Checklist pour des résultats fiables et publiables."
              : "Checklist for reliable, publishable results.",
            checklist: L.checklist,
            reliability: L.reliabilityGeneral,
          },
          ...base,
        ];
      }
    }
    if (page === "optimisation") {
      return [
        {
          id: "pub",
          title: lang() === "fr" ? "Objectif" : "Goal",
          badge: lang() === "fr" ? "Qualité" : "Quality",
          intro: lang() === "fr"
            ? "Checklist avant calculs phonons / κ_L."
            : "Checklist before phonon / κ_L calculations.",
          checklist: L.checklist,
          reliability: L.reliabilityGeneral,
        },
        ...base.filter((s) => s.id !== "pub"),
      ];
    }
    return base;
  }

  function esc(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function tr(key, fb) {
    return window.qeI18n?.t(key) ?? fb;
  }

  function renderRecommended(items) {
    if (!items?.length) return "";
    let html = `<div class="aide-subhead aide-subhead-rec">${esc(tr("aide.recommended", "Recommended parameters"))}</div>`;
    html += `<dl class="aide-params aide-rec-params">${items
      .map((p) => `<dt>${esc(p.field)}</dt><dd><strong class="aide-rec-val">${esc(p.value)}</strong>${p.note ? `<span>${esc(p.note)}</span>` : ""}</dd>`)
      .join("")}</dl>`;
    return html;
  }

  function renderSection(sec, openDefault) {
    let html = `<details class="aide-block" data-aide="${esc(sec.id)}"${openDefault ? " open" : ""}>`;
    html += `<summary class="aide-block-head">`;
    if (sec.badge) html += `<span class="aide-badge">${esc(sec.badge)}</span>`;
    html += `<h3>${esc(sec.title)}</h3></summary>`;
    html += `<div class="aide-block-body">`;
    if (sec.intro) html += `<p class="aide-intro">${sec.intro}</p>`;
    if (sec.recommended?.length) html += renderRecommended(sec.recommended);
    if (sec.checklist?.length) {
      html += `<div class="aide-subhead">${esc(tr("aide.checklist", "Checklist"))}</div>`;
      html += `<ul class="aide-checklist">${sec.checklist.map((c) => `<li>${esc(c)}</li>`).join("")}</ul>`;
    }
    if (sec.reliability?.length) {
      html += `<div class="aide-subhead aide-subhead-rel">${esc(tr("aide.reliability", "Reliability"))}</div>`;
      html += `<ul class="aide-reliability">${sec.reliability.map((r) => `<li>${esc(r)}</li>`).join("")}</ul>`;
    }
    if (sec.files?.length) {
      html += `<div class="aide-subhead">${esc(tr("aide.files", "Files"))}</div>`;
      html += `<p class="aide-files"><code>${sec.files.map(esc).join("</code> · <code>")}</code></p>`;
    }
    html += `</div></details>`;
    return html;
  }

  function updatePublishHints() {
    const mat = localStorage.getItem("qealamode.material") || "";
    const job = localStorage.getItem("qealamode.job") || "";
    const dest = mat && job ? `outputs/${mat}/${job}/` : "outputs/&lt;Mat&gt;/&lt;job&gt;/";
    document.querySelectorAll("[data-publish-dest]").forEach((el) => {
      el.textContent = dest;
    });
    document.querySelectorAll("[data-publish-ready]").forEach((el) => {
      el.hidden = !(mat && job);
    });
  }

  const AIDE_COLLAPSED_KEY = "qealamode.aide.collapsed";

  function setAideCollapsed(collapsed) {
    const layout = document.querySelector(".page-layout");
    const panel = document.getElementById("aide-panel");
    if (!layout || !panel) return;
    layout.classList.toggle("aide-collapsed", collapsed);
    panel.classList.toggle("is-collapsed", collapsed);
    localStorage.setItem(AIDE_COLLAPSED_KEY, collapsed ? "1" : "0");
    const btn = panel.querySelector(".aide-collapse-btn");
    if (btn) {
      btn.setAttribute("aria-expanded", String(!collapsed));
      btn.title = tr(collapsed ? "aide.expand" : "aide.collapse", collapsed ? "Show help" : "Collapse help");
    }
    const tab = panel.querySelector(".aide-expand-tab");
    if (tab) tab.title = tr("aide.expand", "Show help");
  }

  function bindAideCollapse(panel) {
    const collapsed = localStorage.getItem(AIDE_COLLAPSED_KEY) === "1";
    setAideCollapsed(collapsed);
    panel.querySelector(".aide-collapse-btn")?.addEventListener("click", (ev) => {
      ev.stopPropagation();
      setAideCollapsed(!panel.classList.contains("is-collapsed"));
    });
    panel.querySelector(".aide-expand-tab")?.addEventListener("click", () => setAideCollapsed(false));
  }

  function init() {
    const page = document.body?.dataset?.page;
    if (!page || !CONTENT.en[page]) return;
    const panel = document.getElementById("aide-panel");
    if (!panel) return;

    const sections = getSections(page);
    panel.innerHTML = `
      <button type="button" class="aide-expand-tab" aria-label="${esc(tr("aide.expand", "Show help"))}">${esc(tr("aide.expand", "Help"))}</button>
      <div class="aide-panel-inner">
        <header class="aide-panel-head">
          <div class="aide-panel-head-row">
            <h2>${tr("aide.title", "Help · parameters")}</h2>
            <button type="button" class="aide-collapse-btn" aria-expanded="true" title="${esc(tr("aide.collapse", "Collapse help"))}">‹</button>
          </div>
          <p class="aide-subtitle"></p>
        </header>
        ${sections.map((sec, i) => renderSection(sec, i <= 1)).join("")}
        <footer class="aide-foot">QE–ALAMODE · LMESM / USTO-MB · <a href="mailto:said.hiadsi@univ-usto.dz">said.hiadsi@univ-usto.dz</a></footer>
      </div>`;

    const sub = panel.querySelector(".aide-subtitle");
    if (sub) sub.innerHTML = tr("aide.subtitle", "Recommended parameters for reliable calculations.");

    bindAideCollapse(panel);
    updatePublishHints();

    const cards = document.querySelectorAll(".optim-card[data-kind], .optim-card[data-step]");
    if (!cards.length) return;

    function highlight(id) {
      panel.querySelectorAll(".aide-block").forEach((b) => {
        const on = b.dataset.aide === id;
        b.classList.toggle("active", on);
        if (on && b.tagName === "DETAILS") b.open = true;
      });
    }

    cards.forEach((card) => {
      const id = card.dataset.kind || card.dataset.step;
      const map = { "vc-relax": "vc-relax", relax: "relax", scf: page === "optimisation" ? "scf-opt" : "scf" };
      const aideId = map[id] || id;
      card.addEventListener("mouseenter", () => highlight(aideId));
      card.addEventListener("focusin", () => highlight(aideId));
    });
    panel.addEventListener("mouseleave", () => highlight(""));
  }

  window.qeAideUpdatePublish = updatePublishHints;
  window.qeAideInit = init;

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();

  window.qeI18n?.onLangChange?.(() => init());
})();

(() => {
  const STORAGE_KEY = "qealamode.lang";
  const DEFAULT_LANG = "fr";

  const STRINGS = {
    en: {
      "header.author": "Author",
      "nav.home": "Home",
      "nav.optim": "Optimization",
      "nav.calc": "Calculations",
      "nav.results": "Results",
      "nav.aria": "Main navigation",
      "lang.aria": "Language",
      "title.home": "Home — QE–ALAMODE",
      "title.optim": "Optimization — QE–ALAMODE",
      "title.calc": "Calculations — QE–ALAMODE",
      "title.results": "Results — QE–ALAMODE",
      "tagline.home": "Standalone interface — phonons & κ<sub>L</sub>",
      "tagline.optim": "Optimization & SCF",
      "tagline.calc": "Calculations (SCF → phonons / κ<sub>L</sub>)",
      "tagline.results": "Results",
      "home.kicker": "Quantum ESPRESSO · ALAMODE",
      "home.hero": "Calculation platform",
      "home.hero.line": "Anharmonic phonons and lattice thermal conductivity κ<sub>L</sub>",
      "home.hero.sub": "From the relaxed structure to force constants, through to κ<sub>L</sub>(T).",
      "home.flow.title": "Three steps",
      "home.flow.lead": "One continuous chain — from DFT to transport properties.",
      "home.step1.short": "VC-RELAX · SCF",
      "home.step2.short": "Forces · alm · anphon",
      "home.step3.short": "κ<sub>L</sub> · technical sheet",
      "home.meta": "S. Hiadsi · LMESM · Faculté de Physique · USTO-MB · Oran · Algeria · <a href=\"mailto:said.hiadsi@univ-usto.dz\">said.hiadsi@univ-usto.dz</a>",
      "home.author.aff": "LMESM · Faculty of Physics · USTO-MB · Oran · Algeria",
      "home.paths": "Inputs: <code>/home/hiadsi/QE-Alamode/inputs/&lt;Material&gt;/</code><br/>Outputs: <code>/home/hiadsi/QE-Alamode/outputs</code><br/>Pseudos: <code>pseudos/</code> · ALAMODE binaries: <code>bin/</code>",
      "home.tools.detect": "Detecting…",
      "home.step1.title": "Optimization",
      "home.step1.desc": "Choose material, then VC-RELAX / RELAX / SCF.",
      "home.step2.title": "Calculations",
      "home.step2.desc": "SCF → supercells → forces → <code>alm</code> → <code>anphon</code>.",
      "home.step3.title": "Results",
      "home.step3.desc": "Quantities, plots, technical sheet HTML/PDF · <code>outputs/&lt;material&gt;/</code>.",
      "home.cta.optim": "Start",
      "home.cta.calc": "Calculations",
      "home.cta.results": "Results",
      "home.cta.guide": "Guide",
      "footer.standalone": "QE–ALAMODE standalone · port 5020",
      "footer.optim": "inputs/&lt;Mat&gt;/ · outputs/&lt;Mat&gt;/optimisation/",
      "footer.calc": "inputs/&lt;Mat&gt;/ · outputs/&lt;Mat&gt;/",
      "footer.results": "1 · Material · 2 · Results & technical sheet",
      "label.material": "Material",
      "label.job": "Job",
      "label.material.none": "— material —",
      "label.input.none": "— input —",
      "btn.new_job": "New job",
      "btn.check": "Check",
      "btn.edit": "Edit",
      "btn.run": "Run",
      "btn.close": "Close",
      "btn.save": "Save",
      "btn.use_scf": "Use SCF",
      "btn.run_pwx": "Run pw.x",
      "btn.prepare": "Prepare",
      "btn.export": "Export",
      "btn.export_outputs": "Export → outputs/",
      "badge.required": "Required",
      "badge.optional": "Optional",
      "opt.vc.desc": "Full optimization (cell + positions).",
      "opt.relax.desc": "Atomic positions (fixed cell).",
      "opt.scf.desc": "Self-consistent field on optimized structure.",
      "opt.banner": "<strong>SCF ready</strong> — continue to phonon / κ<sub>L</sub> calculations.",
      "opt.banner.link": "Next → Calculations",
      "opt.modal.title": "Edit input",
      "opt.modal.edit_kind": "Edit {kind}",
      "opt.status.pick_mat": "Choose a material.",
      "calc.scf.desc": "Load material SCF (<code>inputs/&lt;Mat&gt;/&lt;Mat&gt;-scf.in</code>).",
      "calc.supercell.title": "Supercells",
      "calc.supercell.desc": "N×N×N supercell and displacement patterns.",
      "calc.forces.desc": "<code>pw.x</code> on patterns, then build DFSET.",
      "calc.alm.desc": "Force constants (NORDER=2 required for κ_L).",
      "calc.anphon.desc": "Phonons or κ<sub>L</sub> (RTA).",
      "calc.label.amplitude": "Amplitude (Å)",
      "calc.label.n_patterns": "Patterns",
      "calc.label.max_jobs": "Max jobs",
      "calc.label.cutoff": "Cutoff Å (0=None)",
      "calc.label.mode": "Mode",
      "calc.eta.title": "Runtime estimate",
      "calc.eta.range": "Likely range",
      "calc.eta.hint": "Indicative estimate (± factor ~2), calibrated on local Si runs.",
      "calc.banner": "<strong>Calculations ready</strong> — review quantities and technical sheet.",
      "calc.signal.ack": "Got it",
      "calc.signal.title": "Step done: {step} → next: {next}",
      "calc.signal.waiting": "Waiting for the next step signal…",
      "calc.banner.link": "Next → Results",
      "calc.guide.open": "Mini-guide",
      "calc.guide.title": "Mini-guide — Calculations",
      "calc.guide.new_tab": "New tab",
      "calc.guide.skip": "Do not open automatically again",
      "calc.guide.loading": "Loading…",
      "calc.guide.back_calc": "Back to Calculations",
      "calc.export.hint": "<strong>Export</strong> — archives final files (.xml, .fcs, .bands, sheet…) to <code>{dest}</code> · does not delete <code>work/</code>",
      "calc.export.title": "Copy results to outputs/",
      "res.section.material": "Material",
      "res.section.science": "Scientific results",
      "res.export.box": "<strong>Export</strong> copies validated results from the work job to the permanent folder:",
      "res.export.files": "Files: .xml · .fcs · .bands · .kl · DFSET · fiche_technique.html · logs · INFO.txt",
      "res.pick_mat_job": "Select a material and a job",
      "res.no_job": "No job selected yet.",
      "res.quantities": "Quantities",
      "res.gamma": "Γ modes",
      "res.ifc": "Force constants (IFC)",
      "res.bands": "Phonon dispersion",
      "res.kappa": "κ<sub>L</sub>(T)",
      "res.job_files": "Job files",
      "res.bands.hint": "No bands available (run anphon MODE=phonons).",
      "res.kappa.hint": "Requires anphon MODE=rta.",
      "res.fiche.title": "Technical sheet",
      "res.fiche.desc": "Full report: quantities, tables, dispersion and κ<sub>L</sub> plots.",
      "res.fiche.hint": "Select a job to generate the technical sheet.",
      "res.fiche.html": "Open HTML",
      "res.fiche.pdf": "PDF (print)",
      "log.waiting": "Waiting…",
      "log.waiting_calc": "Waiting…",
      "status.pending": "Pending.",
      "status.input_missing": "Input missing: <code>{path}</code>",
      "status.converged": "Converged · <code>{path}</code>",
      "status.output_check": "Output present (verify) · <code>{path}</code>",
      "status.input_ready": "Input ready · <code>{path}</code>",
      "status.absent": "Missing · <code>{path}</code>",
      "status.scf_loaded": "SCF loaded · <code>{path}</code>",
      "status.fail": "Failed",
      "status.create_job": "Create or select a job.",
      "status.pwx_dfset_ok": "pw.x OK · DFSET OK",
      "status.pwx_ok": "pw.x OK",
      "status.dfset_ok": "DFSET OK",
      "status.anphon_kappa": "OK · κ: {n} points",
      "status.anphon_phonons": "OK (phonons)",
      "status.anphon_warn": "κ_L: anharmonic IFC required (NORDER≥2) · phonons OK if MODE=phonons",
      "alert.pick_material": "Choose a material.",
      "alert.pick_job": "Create or select a job (material).",
      "alert.pick_input": "Choose an input.",
      "msg.exported": "Exported → {dir} ({n} file(s))",
      "msg.no_material": "No material selected.",
      "msg.material": "Material: {mat}",
      "msg.material_input": "Material: {mat} · input: {inp}",
      "msg.material_inputs": "Material: {mat} · {n} input(s)",
      "msg.job": "Job: {id}",
      "msg.pick_mat_results": "Choose a material",
      "msg.pick_mat_step": "1 · Choose a material, then a job.",
      "msg.pick_job_results": "{mat} — select a job",
      "msg.pick_job_grand": "Choose a job to display quantities.",
      "msg.job_incomplete": "Job loaded — quantities still incomplete.",
      "msg.no_summary_files": "No summary files.",
      "msg.step_ok": "step {k}: {v}",
      "msg.no_inputs": "No .in file for this material in inputs/.",
      "tool.ok": "{name} OK",
      "tool.missing": "{name} missing",
      "mode.acoustic": "acoustic",
      "mode.optical": "optical",
      "log.supercell": "Supercells…",
      "log.pwx": "pw.x…",
      "log.alm": "alm…",
      "log.anphon": "anphon…",
      "log.optim_running": "{kind} running for {mat}…",
      "aide.aria": "Optimal parameters help",
      "aide.title": "Help · parameters",
      "aide.subtitle": "Recommended values for <strong>reliable calculations</strong> (enter in the UI or QE inputs).",
      "aide.collapse": "Collapse help",
      "aide.expand": "Show help",
      "aide.checklist": "Quality checklist",
      "aide.recommended": "Recommended parameters",
      "aide.reliability": "Checks & tips",
      "aide.files": "Copied files",
    },
    fr: {
      "header.author": "Auteur",
      "nav.home": "Accueil",
      "nav.optim": "Optimisation",
      "nav.calc": "Calculs",
      "nav.results": "Résultats",
      "nav.aria": "Navigation principale",
      "lang.aria": "Langue",
      "title.home": "Accueil — QE–ALAMODE",
      "title.optim": "Optimisation — QE–ALAMODE",
      "title.calc": "Calculs — QE–ALAMODE",
      "title.results": "Résultats — QE–ALAMODE",
      "tagline.home": "Interface autonome — phonons & κ<sub>L</sub>",
      "tagline.optim": "Optimisation & SCF",
      "tagline.calc": "Calculs (SCF → phonons / κ<sub>L</sub>)",
      "tagline.results": "Résultats",
      "home.kicker": "Quantum ESPRESSO · ALAMODE",
      "home.hero": "Plateforme de Calculs",
      "home.hero.line": "Phonons anharmoniques et conductivité thermique κ<sub>L</sub>",
      "home.hero.sub": "De la structure relaxée aux constantes de force, jusqu’à κ<sub>L</sub>(T).",
      "home.flow.title": "Trois étapes",
      "home.flow.lead": "Un enchaînement unique — du DFT aux propriétés de transport.",
      "home.step1.short": "VC-RELAX · SCF",
      "home.step2.short": "Forces · alm · anphon",
      "home.step3.short": "κ<sub>L</sub> · fiche",
      "home.meta": "S. Hiadsi · LMESM · Faculté de Physique · USTO-MB · Oran · Algérie · <a href=\"mailto:said.hiadsi@univ-usto.dz\">said.hiadsi@univ-usto.dz</a>",
      "home.author.aff": "LMESM · Faculté de Physique · USTO-MB · Oran · Algérie",
      "home.paths": "Inputs : <code>/home/hiadsi/QE-Alamode/inputs/&lt;Matériau&gt;/</code><br/>Outputs : <code>/home/hiadsi/QE-Alamode/outputs</code><br/>Pseudos : <code>pseudos/</code> · Binaires ALAMODE : <code>bin/</code>",
      "home.tools.detect": "Détection…",
      "home.step1.title": "Optimisation",
      "home.step1.desc": "Choisir le matériau, puis VC-RELAX / RELAX / SCF.",
      "home.step2.title": "Calculs",
      "home.step2.desc": "SCF → supercellules → forces → <code>alm</code> → <code>anphon</code>.",
      "home.step3.title": "Résultats",
      "home.step3.desc": "Grandeurs, courbes, fiche HTML/PDF · <code>outputs/&lt;matériau&gt;/</code>.",
      "home.cta.optim": "Commencer",
      "home.cta.calc": "Calculs",
      "home.cta.results": "Résultats",
      "home.cta.guide": "Guide",
      "footer.standalone": "QE–ALAMODE autonome · port 5020",
      "footer.optim": "inputs/&lt;Mat&gt;/ · outputs/&lt;Mat&gt;/optimisation/",
      "footer.calc": "inputs/&lt;Mat&gt;/ · outputs/&lt;Mat&gt;/",
      "footer.results": "1 · Matériau · 2 · Résultats & fiche technique",
      "label.material": "Matériau",
      "label.job": "Job",
      "label.material.none": "— matériau —",
      "label.input.none": "— input —",
      "btn.new_job": "Nouveau job",
      "btn.check": "Vérifier",
      "btn.edit": "Éditer",
      "btn.run": "Lancer",
      "btn.close": "Fermer",
      "btn.save": "Enregistrer",
      "btn.use_scf": "Utiliser SCF",
      "btn.run_pwx": "Lancer pw.x",
      "btn.prepare": "Préparer",
      "btn.export": "Sortir",
      "btn.export_outputs": "Sortir → outputs/",
      "badge.required": "Prérequis",
      "badge.optional": "Optionnel",
      "opt.vc.desc": "Optimisation complète (cellule + positions).",
      "opt.relax.desc": "Positions atomiques (maille fixe).",
      "opt.scf.desc": "Champ auto-cohérent sur la structure optimisée.",
      "opt.banner": "<strong>SCF prêt</strong> — poursuivez vers les calculs phonons / κ<sub>L</sub>.",
      "opt.banner.link": "Suite → Calculs",
      "opt.modal.title": "Éditer l’input",
      "opt.modal.edit_kind": "Éditer {kind}",
      "opt.status.pick_mat": "Choisissez un matériau.",
      "calc.scf.desc": "Charger le SCF du matériau (<code>inputs/&lt;Mat&gt;/&lt;Mat&gt;-scf.in</code>).",
      "calc.supercell.title": "Supercellules",
      "calc.supercell.desc": "Supercellule N×N×N et motifs de déplacements.",
      "calc.forces.desc": "<code>pw.x</code> sur les motifs, puis construction du DFSET.",
      "calc.alm.desc": "Constantes de force (NORDER=2 requis pour κ_L).",
      "calc.anphon.desc": "Phonons ou κ<sub>L</sub> (RTA).",
      "calc.label.amplitude": "Amplitude (Å)",
      "calc.label.n_patterns": "Nb motifs",
      "calc.label.max_jobs": "Max jobs",
      "calc.label.cutoff": "Cutoff Å (0=None)",
      "calc.label.mode": "Mode",
      "calc.eta.title": "Estimation du temps",
      "calc.eta.range": "Fourchette probable",
      "calc.eta.hint": "Estimation indicative (± facteur ~2), calibrée sur des runs Si locaux.",
      "calc.banner": "<strong>Calculs prêts</strong> — consultez les grandeurs et la fiche.",
      "calc.signal.ack": "Compris",
      "calc.signal.title": "Étape terminée : {step} → suivant : {next}",
      "calc.signal.waiting": "En attente du signal de fin d’étape…",
      "calc.banner.link": "Suite → Résultats",
      "calc.guide.open": "Mini-guide",
      "calc.guide.title": "Mini-guide — Calculs",
      "calc.guide.new_tab": "Nouvel onglet",
      "calc.guide.skip": "Ne plus ouvrir automatiquement",
      "calc.guide.loading": "Chargement…",
      "calc.guide.back_calc": "Retour aux Calculs",
      "calc.export.hint": "<strong>Sortir</strong> — archive les fichiers finaux (.xml, .fcs, .bands, fiche…) vers <code>{dest}</code> · ne supprime pas <code>work/</code>",
      "calc.export.title": "Copier les résultats vers outputs/",
      "res.section.material": "Matériau",
      "res.section.science": "Résultats scientifiques",
      "res.export.box": "<strong>Sortir</strong> copie les résultats validés du job de travail vers le dossier permanent :",
      "res.export.files": "Fichiers : .xml · .fcs · .bands · .kl · DFSET · fiche_technique.html · logs utiles · INFO.txt",
      "res.pick_mat_job": "Sélectionnez un matériau et un job",
      "res.no_job": "Pas encore de job sélectionné.",
      "res.quantities": "Grandeurs",
      "res.gamma": "Modes Γ",
      "res.ifc": "Constantes de force (IFC)",
      "res.bands": "Dispersion phonons",
      "res.kappa": "κ<sub>L</sub>(T)",
      "res.job_files": "Fichiers du job",
      "res.bands.hint": "Aucune bande disponible (lancer anphon MODE=phonons).",
      "res.kappa.hint": "Nécessite anphon MODE=rta.",
      "res.fiche.title": "Fiche technique",
      "res.fiche.desc": "Rapport complet : grandeurs, tableaux, courbes de dispersion et κ<sub>L</sub>.",
      "res.fiche.hint": "Sélectionnez un job pour générer la fiche technique.",
      "res.fiche.html": "Ouvrir HTML",
      "res.fiche.pdf": "PDF (imprimer)",
      "log.waiting": "En attente…",
      "log.waiting_calc": "En attente…",
      "status.pending": "En attente.",
      "status.input_missing": "Input absent : <code>{path}</code>",
      "status.converged": "Convergé · <code>{path}</code>",
      "status.output_check": "Sortie présente (à vérifier) · <code>{path}</code>",
      "status.input_ready": "Input prêt · <code>{path}</code>",
      "status.absent": "Absent · <code>{path}</code>",
      "status.scf_loaded": "SCF chargé · <code>{path}</code>",
      "status.fail": "Échec",
      "status.create_job": "Créez ou sélectionnez un job.",
      "status.pwx_dfset_ok": "pw.x OK · DFSET OK",
      "status.pwx_ok": "pw.x OK",
      "status.dfset_ok": "DFSET OK",
      "status.anphon_kappa": "OK · κ : {n} points",
      "status.anphon_phonons": "OK (phonons)",
      "status.anphon_warn": "κ_L : IFC anharmoniques requises (NORDER≥2) · phonons OK si MODE=phonons",
      "alert.pick_material": "Choisissez un matériau.",
      "alert.pick_job": "Créez ou sélectionnez un job (matériau).",
      "alert.pick_input": "Choisissez un input.",
      "msg.exported": "Sorti → {dir} ({n} fichier(s))",
      "msg.no_material": "Aucun matériau sélectionné.",
      "msg.material": "Matériau : {mat}",
      "msg.material_input": "Matériau : {mat} · input : {inp}",
      "msg.material_inputs": "Matériau : {mat} · {n} input(s)",
      "msg.job": "Job : {id}",
      "msg.pick_mat_results": "Choisissez un matériau",
      "msg.pick_mat_step": "1 · Choisissez un matériau, puis un job.",
      "msg.pick_job_results": "{mat} — sélectionnez un job",
      "msg.pick_job_grand": "Choisissez un job pour afficher les grandeurs.",
      "msg.job_incomplete": "Job chargé — grandeurs encore incomplètes.",
      "msg.no_summary_files": "Aucun fichier résumé.",
      "msg.step_ok": "étape {k}: {v}",
      "msg.no_inputs": "Aucun .in pour ce matériau dans inputs/.",
      "tool.ok": "{name} OK",
      "tool.missing": "{name} absent",
      "mode.acoustic": "acoustique",
      "mode.optical": "optique",
      "log.supercell": "Supercellules…",
      "log.pwx": "pw.x…",
      "log.alm": "alm…",
      "log.anphon": "anphon…",
      "log.optim_running": "{kind} en cours pour {mat}…",
      "aide.aria": "Aide paramètres optimaux",
      "aide.title": "Aide · paramètres",
      "aide.subtitle": "Valeurs recommandées pour des <strong>calculs fiables</strong> (saisir dans l’interface ou inputs QE).",
      "aide.collapse": "Replier l’aide",
      "aide.expand": "Afficher l’aide",
      "aide.checklist": "Checklist qualité",
      "aide.recommended": "Paramètres recommandés",
      "aide.reliability": "Contrôles & astuces",
      "aide.files": "Fichiers copiés",
    },
  };

  const PARAM_LABELS = {
    en: {
      formula: "Formula", nat: "Atoms (cell)", supercell: "Supercell", n_patterns: "DFSET configs",
      norder: "NORDER (IFC)", n_ifc_params: "Free IFC params", fit_err: "alm fit error",
      fc2_max: "|FC2| max", fc3_n: "FC3 terms", omega_max: "ω_max (band)", omega_lo: "Optical Γ (max)",
      n_imag: "Imaginary modes", kappa_xx: "κ_xx(T)", kappa_yy: "κ_yy", kappa_zz: "κ_zz",
      mfp: "MFP / cumulative κ", tau: "τ_q,j (lifetime)", gamma_line: "Γ_q,j (linewidth)",
      cv: "C_v(T)", cp: "C_p(T)", entropy: "S(T)", alpha: "α(T) expansion",
    },
    fr: {},
  };

  let lang = localStorage.getItem(STORAGE_KEY) || DEFAULT_LANG;
  if (!STRINGS[lang]) lang = DEFAULT_LANG;
  const listeners = [];

  function interpolate(s, vars) {
    if (!vars) return s;
    return s.replace(/\{(\w+)\}/g, (_, k) => (vars[k] !== undefined ? vars[k] : `{${k}}`));
  }

  function t(key, vars) {
    const pack = STRINGS[lang] || STRINGS.en;
    const s = pack[key] ?? STRINGS.en[key] ?? key;
    return interpolate(s, vars);
  }

  function paramLabel(id, fallback) {
    const pack = PARAM_LABELS[lang];
    if (pack && pack[id]) return pack[id];
    return fallback;
  }

  function getLang() { return lang; }

  function setLang(code) {
    if (!STRINGS[code]) return;
    lang = code;
    localStorage.setItem(STORAGE_KEY, lang);
    applyI18n();
    updateLangButtons();
    listeners.forEach((fn) => { try { fn(lang); } catch (_) { /* ignore */ } });
  }

  function applyI18n() {
    document.documentElement.lang = lang === "fr" ? "fr" : "en";
    const page = document.body?.dataset?.page || "home";
    document.title = t(`title.${page === "home" ? "home" : page}`);
    document.querySelectorAll("[data-i18n]").forEach((el) => {
      el.textContent = t(el.dataset.i18n);
    });
    document.querySelectorAll("[data-i18n-html]").forEach((el) => {
      el.innerHTML = t(el.dataset.i18nHtml);
    });
    document.querySelectorAll("[data-i18n-title]").forEach((el) => {
      el.title = t(el.dataset.i18nTitle);
    });
    document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
      el.placeholder = t(el.dataset.i18nPlaceholder);
    });
    document.querySelectorAll("[data-i18n-aria]").forEach((el) => {
      el.setAttribute("aria-label", t(el.dataset.i18nAria));
    });
    const aide = document.getElementById("aide-panel");
    if (aide) aide.setAttribute("aria-label", t("aide.aria"));
    const nav = document.querySelector(".main-nav");
    if (nav && !nav.getAttribute("aria-label")) nav.setAttribute("aria-label", t("nav.aria"));
    syncExportHint();
  }

  function syncExportHint() {
    const mat = localStorage.getItem("qealamode.material") || "";
    const job = localStorage.getItem("qealamode.job") || "";
    const dest = mat && job ? `outputs/${mat}/${job}/` : "outputs/<Mat>/<job>/";
    const hint = document.getElementById("publish-inline-calc");
    if (hint) hint.innerHTML = t("calc.export.hint", { dest });
  }

  function updateLangButtons() {
    document.querySelectorAll(".lang-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.lang === lang);
    });
  }

  function initLangSwitch() {
    document.querySelectorAll(".lang-btn").forEach((btn) => {
      btn.addEventListener("click", () => setLang(btn.dataset.lang));
    });
    updateLangButtons();
  }

  function onLangChange(fn) { listeners.push(fn); }

  window.qeI18n = { t, getLang, setLang, applyI18n, onLangChange, paramLabel, syncExportHint };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => { applyI18n(); initLangSwitch(); });
  } else {
    applyI18n();
    initLangSwitch();
  }
})();

QE–ALAMODE — Proposition 1 (interface + bin ALAMODE)
Auteur : S. Hiadsi — LMESM / USTO-MB — said.hiadsi@univ-usto.dz
Date   : 2026-08-08T09:51:34+01:00

Lire en premier : README.md  (configuration sur un autre PC)
Complément      : README_DEPLOIEMENT.md

#!/usr/bin/env bash
# Surveille un job QE–ALAMODE et relance resume_job.sh si le calcul s'arrête.
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
JOB="${1:?Usage: $0 <job_id> [material]}"
MAT="${2:-Si}"
INTERVAL="${WATCH_INTERVAL:-120}"
LOG="$HERE/logs/${JOB}_watch.log"

exec >> "$LOG" 2>&1
echo "=== Watch $JOB — $(date) — intervalle ${INTERVAL}s ==="

while true; do
  if pgrep -f "resume_job.sh ${JOB}" >/dev/null 2>&1; then
    :
  elif pgrep -f "pw.x -in disp_" >/dev/null 2>&1 && pgrep -f "${JOB}/qe" >/dev/null 2>&1; then
    :
  else
    prog="$HERE/work/$JOB/progress.json"
    done=0 total=12
    if [[ -f "$prog" ]]; then
      done=$(python3 -c "import json; d=json.load(open('$prog')); print(d.get('qe_done',0))" 2>/dev/null || echo 0)
      total=$(python3 -c "import json; d=json.load(open('$prog')); print(d.get('qe_total',12))" 2>/dev/null || echo 12)
    fi
    if [[ "$done" -ge "$total" ]] && grep -qE '"phase": "(terminé|awaiting:)' "$prog" 2>/dev/null; then
      echo "[$(date +%H:%M:%S)] QE terminé ou en attente utilisateur ($done/$total) — arrêt du watch."
      echo "    Voir work/$JOB/READY_NEXT_STEP pour l'étape suivante."
      # Signal de courtoisie si fichier absent
      if [[ ! -f "$HERE/work/$JOB/READY_NEXT_STEP" ]]; then
        python3 "$HERE/scripts/signal_etape.py" "$JOB" qe_forces \
          --message "Forces QE terminées ($done/$total)" || true
      fi
      exit 0
    fi
    echo "[$(date +%H:%M:%S)] Calcul arrêté ($done/$total) — relance resume_job…"
    nohup "$HERE/scripts/resume_job.sh" "$JOB" "$MAT" &
    sleep 10
  fi
  sleep "$INTERVAL"
done

#!/usr/bin/env bash
# Enchaînement ALAMODE : IFC → phonons → κ_L (RTA), avec SIGNAL après chaque étape.
# Usage: complete_pipeline.sh <job_id> [material] [norder] [kappa]
#   norder : 1 = harmonique seul · 2+ = FC3 (défaut 2, requis pour κ_L)
#   kappa  : auto|yes|no  (auto = RTA si norder≥2)
# STEP_PAUSE=1 (défaut) : s'arrête après chaque étape et émet un signal
# STEP_PAUSE=0          : enchaîne tout, signaux informatifs seulement
set -euo pipefail
API="${QEALAMODE_API:-http://127.0.0.1:5020}"
JOB="${1:?Usage: $0 <job_id> [material] [norder] [kappa]}"
MAT="${2:-Si}"
NORDER="${3:-2}"
KAPPA="${4:-auto}"
STEP_PAUSE="${STEP_PAUSE:-1}"
HERE="$(cd "$(dirname "$0")/.." && pwd)"
SIGNAL_PY="$HERE/scripts/signal_etape.py"

if [[ "$KAPPA" == "auto" ]]; then
  if [[ "$NORDER" -ge 2 ]]; then
    KAPPA="yes"
  else
    KAPPA="no"
  fi
fi

signal_step() {
  python3 "$SIGNAL_PY" "$JOB" "$@" || true
}

pause_or_continue() {
  local step="$1"
  if [[ "$STEP_PAUSE" == "1" ]]; then
    echo ""
    echo ">>> PAUSE après [$step] — signal dans work/$JOB/READY_NEXT_STEP"
    echo ">>> Relancez ce script (STEP_PAUSE=0 pour tout enchaîner) ou l'étape suivante via l'interface / API."
    exit 0
  fi
}

echo "Job: $JOB · NORDER=$NORDER · kappa=$KAPPA · STEP_PAUSE=$STEP_PAUSE"

echo "--- DFSET ---"
curl -sf -X POST "$API/api/jobs/$JOB/dfset" | python3 -m json.tool | head -20
signal_step dfset --message "DFSET prêt"
pause_or_continue dfset

echo "--- alm prepare/run (NORDER=$NORDER) ---"
curl -sf -X POST "$API/api/jobs/$JOB/alm/prepare" \
  -H "Content-Type: application/json" \
  -d "{\"norder\":$NORDER,\"cutoff\":0}" | python3 -m json.tool | head -12
signal_step alm_prepare
pause_or_continue alm_prepare

curl -sf -X POST "$API/api/jobs/$JOB/alm/run" \
  -H "Content-Type: application/json" \
  -d '{"which":"optimize"}' | python3 -m json.tool | head -12
signal_step alm_optimize
pause_or_continue alm_optimize

echo "--- anphon phonons (dispersion / contrôle Γ) ---"
curl -sf -X POST "$API/api/jobs/$JOB/anphon/prepare" \
  -H "Content-Type: application/json" \
  -d '{"mode":"phonons","kmesh":[10,10,10],"tmin":300,"tmax":1000,"dt":50}' \
  | python3 -m json.tool | head -12
signal_step anphon_prepare --hint "Étape suivante : anphon run (phonons)."
pause_or_continue anphon_prepare_phonons

curl -sf -X POST "$API/api/jobs/$JOB/anphon/run" | python3 -m json.tool | head -12
signal_step anphon_phonons
pause_or_continue anphon_phonons

if [[ "$KAPPA" == "yes" ]]; then
  echo "--- anphon rta (κ_L) ---"
  curl -sf -X POST "$API/api/jobs/$JOB/anphon/prepare" \
    -H "Content-Type: application/json" \
    -d '{"mode":"rta","kmesh":[10,10,10],"tmin":100,"tmax":500,"dt":50}' \
    | python3 -m json.tool | head -12
  signal_step anphon_prepare --hint "Étape suivante : anphon run (RTA / κ_L)."
  pause_or_continue anphon_prepare_rta

  curl -sf -X POST "$API/api/jobs/$JOB/anphon/run" | python3 -m json.tool | head -14
  signal_step anphon_rta
  pause_or_continue anphon_rta
else
  echo "--- κ_L ignoré (NORDER=$NORDER < 2 ou kappa=no) ---"
fi

echo "--- résultats / export ---"
curl -sf "$API/api/jobs/$JOB/results" | python3 -c "
import json, sys
d = json.load(sys.stdin)
ps = d.get('params') or []
print('OK', sum(1 for p in ps if p.get('status') == 'ok'), '/', len(ps))
print('Fiche', (d.get('fiche') or {}).get('html'))
kap = d.get('kappa') or []
print('kappa_points', len(kap))
"
curl -sf -X POST "$API/api/jobs/$JOB/publish" \
  -H "Content-Type: application/json" \
  -d "{\"material\":\"$MAT\"}" | python3 -m json.tool
signal_step publish --message "Export terminé → outputs/$MAT/"
echo "=== PIPELINE TERMINÉ ==="

#!/usr/bin/env bash
# Installe ALAMODE (alm + anphon) dans ~/alamode
# À lancer manuellement si tu veux valider les étapes 7 et 9 :
#   ./scripts/INSTALL_ALAMODE.sh
set -euo pipefail

PREFIX="${ALAMODE_PREFIX:-$HOME/alamode}"
SRC="${ALAMODE_SRC:-/tmp/alamode-src}"

echo "=== Installation ALAMODE → $PREFIX ==="

sudo apt-get update
sudo apt-get install -y git cmake g++ gfortran libeigen3-dev liblapack-dev libblas-dev

rm -rf "$SRC"
git clone --depth 1 https://github.com/ttadano/alamode.git "$SRC"
mkdir -p "$SRC/_build" "$PREFIX/bin"
cd "$SRC/_build"
cmake .. -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$PREFIX"
cmake --build . -j"$(nproc)"

mapfile -t BINS < <(find "$SRC" -type f \( -name alm -o -name anphon \) -perm -111)
if [[ ${#BINS[@]} -eq 0 ]]; then
  echo "Binaires introuvables après compilation."
  exit 1
fi
for b in "${BINS[@]}"; do
  cp -f "$b" "$PREFIX/bin/"
  echo "  → $PREFIX/bin/$(basename "$b")"
done

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cat >"$ROOT/config_local.sh" <<EOF
export QE_BIN_DIR="\${QE_BIN_DIR:-$HOME/q-e-qe-7.5/bin}"
export ALAMODE_BIN_DIR="$PREFIX/bin"
export PSEUDO_DIR="$ROOT/pseudos"
export QEALAMODE_PORT="\${QEALAMODE_PORT:-5020}"
EOF

echo ""
echo "ALAMODE installé."
echo "Relancez : cd $ROOT && ./ARRETER.sh && ./DEMARRER.sh"
echo "Puis     : python3 scripts/verifier_etapes.py"
echo ""

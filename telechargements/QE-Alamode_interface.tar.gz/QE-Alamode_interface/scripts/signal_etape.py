#!/usr/bin/env python3
"""CLI : émettre / lire / acquitter un signal de fin d'étape."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))

from step_signal import emit_step_signal, read_step_signal, ack_step_signal  # noqa: E402


def main() -> int:
    p = argparse.ArgumentParser(description="Signal de fin d'étape QE–ALAMODE")
    p.add_argument("job_id")
    p.add_argument("step", nargs="?", help="Nom d'étape (ex: qe_forces, dfset, alm_optimize)")
    p.add_argument("--fail", action="store_true", help="Signaler un échec")
    p.add_argument("--message", default="")
    p.add_argument("--hint", default=None)
    p.add_argument("--next", dest="next_step", default=None)
    p.add_argument("--read", action="store_true", help="Afficher le signal courant")
    p.add_argument("--ack", action="store_true", help="Acquitter le signal")
    p.add_argument("--no-notify", action="store_true")
    args = p.parse_args()

    if args.read:
        sig = read_step_signal(args.job_id)
        print(json.dumps(sig or {"ok": False, "error": "aucun signal"}, indent=2, ensure_ascii=False))
        return 0 if sig else 1
    if args.ack:
        print(json.dumps(ack_step_signal(args.job_id), indent=2, ensure_ascii=False))
        return 0
    if not args.step:
        p.error("step requis (sauf --read / --ack)")
    sig = emit_step_signal(
        args.job_id,
        args.step,
        ok=not args.fail,
        message=args.message,
        hint=args.hint,
        next_step=args.next_step,
        notify=not args.no_notify,
    )
    print(json.dumps(sig, indent=2, ensure_ascii=False))
    return 0 if sig.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env bash
# Reprend un job interrompu : pw.x sur tous les disp_*.in.
# Par défaut s'arrête après les forces QE et émet un SIGNAL pour lancer DFSET / ALAMODE manuellement.
# AUTO_PIPELINE=1 → enchaîne complete_pipeline.sh (ancien comportement).
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
# shellcheck disable=SC1091
source "$HERE/config_local.sh"

JOB="${1:?Usage: $0 <job_id> [material] [norder]}"
MAT="${2:-Si}"
NORDER="${3:-2}"
AUTO_PIPELINE="${AUTO_PIPELINE:-0}"
QE_DIR="$HERE/work/$JOB/qe"
LOG="$HERE/logs/${JOB}_resume.log"
PROGRESS="$HERE/work/$JOB/progress.json"
PW="${QE_BIN_DIR}/pw.x"
NPROC="${QE_NPROC:-2}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}"
SIGNAL_PY="$HERE/scripts/signal_etape.py"

signal_step() {
  python3 "$SIGNAL_PY" "$JOB" "$@" || true
}

exec >> "$LOG" 2>&1
echo "=== Reprise job $JOB — $(date) === (MPI np=$NPROC, OMP=$OMP_NUM_THREADS, NORDER=$NORDER)"

if [[ ! -x "$PW" ]]; then
  echo "ERREUR: pw.x introuvable ($PW)"
  exit 1
fi

run_pw() {
  local inp_name="$1"
  local out_name="$2"
  cd "$QE_DIR"
  if command -v mpirun >/dev/null 2>&1 && [[ "$NPROC" -gt 1 ]]; then
    stdbuf -oL mpirun -np "$NPROC" "$PW" -in "$inp_name" > "$out_name" 2>"$HERE/logs/${JOB}_${inp_name%.in}.err"
  else
    stdbuf -oL "$PW" -in "$inp_name" > "$out_name" 2>"$HERE/logs/${JOB}_${inp_name%.in}.err"
  fi
}

write_progress() {
  local done="$1" total="$2" current="$3" phase="${4:-qe_forces}"
  python3 - "$PROGRESS" "$JOB" "$done" "$total" "$current" "$phase" <<'PY'
from pathlib import Path
import json, sys
from datetime import datetime
path = Path(sys.argv[1])
job, done, total, current, phase = sys.argv[2:7]
data = {
    "job_id": job,
    "updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    "qe_done": int(done),
    "qe_total": int(total),
    "current": current,
    "phase": phase,
}
path.parent.mkdir(parents=True, exist_ok=True)
path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
PY
}

inputs=("$QE_DIR"/disp_*.in)
if [[ ! -e "${inputs[0]}" ]]; then
  echo "ERREUR: aucun disp_*.in dans $QE_DIR"
  exit 1
fi

n_ok=0
n_total=${#inputs[@]}
write_progress 0 "$n_total" "démarrage" "qe_forces"

for inp in "${inputs[@]}"; do
  out="${inp%.in}.out"
  stem="$(basename "$inp" .in)"
  if [[ -f "$out" ]] && grep -q "JOB DONE" "$out" 2>/dev/null; then
    echo "[$stem] déjà terminé — skip"
    n_ok=$((n_ok + 1))
    write_progress "$n_ok" "$n_total" "$stem (ok)" "qe_forces"
    continue
  fi
  echo "[$stem] pw.x démarré $(date +%H:%M:%S) …"
  write_progress "$n_ok" "$n_total" "$stem (en cours)" "qe_forces"
  run_pw "$(basename "$inp")" "$(basename "$out")"
  if grep -q "JOB DONE" "$out"; then
    echo "[$stem] OK — $(date +%H:%M:%S)"
    n_ok=$((n_ok + 1))
    write_progress "$n_ok" "$n_total" "$stem (ok)" "qe_forces"
    signal_step qe_config --message "$stem OK ($n_ok/$n_total)" \
      --hint "Config $stem terminée. Suite automatique des motifs restants, ou attendez le signal final QE."
  else
    echo "[$stem] ÉCHEC — voir $out"
    tail -20 "$out" || true
    write_progress "$n_ok" "$n_total" "$stem (échec)" "qe_forces"
    signal_step qe_config --fail --message "$stem échec"
    exit 1
  fi
done

echo "=== QE terminé: $n_ok/$n_total === $(date)"
write_progress "$n_ok" "$n_total" "QE forces OK — en attente DFSET" "awaiting:dfset"
signal_step qe_forces --message "Forces QE terminées ($n_ok/$n_total)" \
  --hint "Étape suivante : DFSET (interface bouton DFSET, ou: curl -X POST …/dfset). Puis alm → anphon."

if [[ "$AUTO_PIPELINE" == "1" ]]; then
  echo "=== AUTO_PIPELINE=1 → ALAMODE (NORDER=$NORDER) ==="
  write_progress "$n_ok" "$n_total" "pipeline alamode" "alamode"
  STEP_PAUSE=0 "$HERE/scripts/complete_pipeline.sh" "$JOB" "$MAT" "$NORDER" "auto"
  write_progress "$n_total" "$n_total" "terminé" "terminé"
  signal_step terminé --message "Pipeline complet terminé"
else
  echo "=== PAUSE — signal émis. Relancez l'étape suivante (DFSET) manuellement. ==="
  echo "    Fichier : $HERE/work/$JOB/READY_NEXT_STEP"
  echo "    Pour enchaîner auto : AUTO_PIPELINE=1 $0 $JOB $MAT $NORDER"
fi
echo "=== FIN QE === $(date)"

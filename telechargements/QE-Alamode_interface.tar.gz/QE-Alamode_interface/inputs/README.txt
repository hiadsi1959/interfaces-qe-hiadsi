inputs/<Matériau>/*.in
Exemple : inputs/Si/Si-scf.in , Si-vc-relax.in , Si-relax.in

#!/usr/bin/env bash
# Raccourci vers configure.sh (installation complète sur un nouveau PC).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
exec "$HERE/configure.sh" "$@"

#!/usr/bin/env bash
# Raccourci : mise à jour des chemins seulement (voir configure.sh pour l’installation complète).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
exec "$HERE/configure.sh" --paths-only "$@"

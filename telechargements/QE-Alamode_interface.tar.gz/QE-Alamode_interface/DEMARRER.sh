#!/usr/bin/env bash
# QE–ALAMODE — démarre l'API + ouvre le navigateur
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"
if [[ -f "$HERE/config_local.sh" ]]; then
  # shellcheck disable=SC1091
  source "$HERE/config_local.sh"
fi

HOST="${QEALAMODE_HOST:-127.0.0.1}"
PORT="${QEALAMODE_PORT:-5020}"
URL="http://${HOST}:${PORT}/"
PIDFILE="$HERE/logs/api.pid"
LOGFILE="$HERE/logs/api.log"

mkdir -p "$HERE/logs" "$HERE/work" "$HERE/inputs" "$HERE/outputs"

if [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
  echo "  API déjà active → $URL"
else
  echo ""
  echo "  QE–ALAMODE — HIADSI"
  echo "  URL : $URL"
  echo ""
  nohup python3 "$HERE/backend/api_server.py" >>"$LOGFILE" 2>&1 &
  echo $! >"$PIDFILE"
  sleep 1
fi

# attendre health
for i in $(seq 1 30); do
  if curl -sf "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then
    break
  fi
  sleep 0.3
done

# Firefox par défaut (Chrome pose problème sur cette machine)
if command -v firefox >/dev/null 2>&1; then
  nohup firefox --new-window "$URL" >/dev/null 2>&1 &
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$URL" >/dev/null 2>&1 || true
fi

echo "  Santé : curl -s http://127.0.0.1:${PORT}/api/health"
echo "  Arrêt  : ./ARRETER.sh"
echo ""

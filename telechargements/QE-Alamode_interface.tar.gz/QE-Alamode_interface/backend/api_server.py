#!/usr/bin/env python3
"""API Flask — Interface QE–ALAMODE (HIADSI)."""
from __future__ import annotations

import os
import sys
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import INTERFACE, WORK, INPUTS, detect_tools  # noqa: E402
import workflow as wf  # noqa: E402
from time_estimate import estimate_runtime  # noqa: E402
from qe_parser import parse_qe_scf_template  # noqa: E402
from step_signal import (  # noqa: E402
    attach_signal,
    read_step_signal,
    ack_step_signal,
    compute_pipeline_status,
    ensure_status_signal,
)

app = Flask(__name__, static_folder=str(INTERFACE), static_url_path="")


def _ok_signal(job_id: str, step: str, result: dict, **kwargs):
    """Attache un signal de fin d'étape aux réponses API réussies."""
    return attach_signal(result if isinstance(result, dict) else {"ok": False, "raw": result}, job_id, step, **kwargs)


@app.get("/api/health")
def health():
    tools = detect_tools()
    return jsonify(
        {
            "ok": True,
            "service": "QE-Alamode",
            "author": "S. Hiadsi — LMESM / USTO-MB · said.hiadsi@univ-usto.dz",
            "tools": tools,
        }
    )


@app.get("/api/tools")
def tools():
    return jsonify({"ok": True, "tools": detect_tools()})


@app.get("/api/jobs")
def jobs():
    return jsonify({"ok": True, "jobs": wf.list_jobs()})


@app.post("/api/jobs")
def create_job():
    data = request.get_json(silent=True) or {}
    return jsonify(wf.create_job(data.get("name") or data.get("material") or "material", material=data.get("material")))


@app.get("/api/jobs/<job_id>")
def job_status(job_id: str):
    return jsonify(wf.job_status(job_id))


@app.get("/api/jobs/<job_id>/results")
def job_results(job_id: str):
    data = wf.get_results(job_id, refresh=True)
    if not data.get("ok"):
        return jsonify(data), 404
    # ne pas envoyer des séries trop lourdes si absentes
    return jsonify(data)


@app.get("/api/jobs/<job_id>/fiche/<kind>")
def job_fiche(job_id: str, kind: str):
    """Ouvre la fiche technique dans le navigateur (html|txt|pdf|md|json)."""
    from flask import Response
    job = WORK / job_id
    if not job.exists():
        return jsonify({"ok": False, "error": "Job inconnu"}), 404
    data = wf.get_results(job_id, refresh=True)
    if not data.get("ok"):
        return jsonify(data), 404
    folder = job / "results"
    kind = (kind or "").lower()

    if kind == "html":
        from fiche_html import render_fiche_html
        html = render_fiche_html(data)
        (folder / "fiche_technique.html").write_text(html, encoding="utf-8")
        return Response(html, mimetype="text/html; charset=utf-8")

    if kind == "pdf":
        # Page HTML imprimable (navigateur → Enregistrer en PDF)
        from fiche_html import render_fiche_html
        html = render_fiche_html(data, auto_print=True)
        return Response(html, mimetype="text/html; charset=utf-8")

    if kind == "txt":
        path = folder / "fiche_technique.txt"
        if not path.is_file():
            return jsonify({"ok": False, "error": "Fiche absente"}), 404
        return Response(
            path.read_text(encoding="utf-8"),
            mimetype="text/plain; charset=utf-8",
        )

    if kind == "md":
        path = folder / "fiche_technique.md"
        if not path.is_file():
            return jsonify({"ok": False, "error": "Fiche absente"}), 404
        return Response(path.read_text(encoding="utf-8"), mimetype="text/markdown; charset=utf-8")

    if kind == "json":
        path = folder / "results.json"
        if not path.is_file():
            return jsonify({"ok": False, "error": "JSON absent"}), 404
        return send_from_directory(folder, path.name, mimetype="application/json")

    return jsonify({"ok": False, "error": "kind = html|txt|pdf|md|json"}), 400




@app.get("/api/materials")
def api_materials():
    from materials import list_materials
    return jsonify({
        "ok": True,
        "inputs_dir": str(ROOT / "inputs"),
        "outputs_dir": str(ROOT / "outputs"),
        "materials": list_materials(),
    })



@app.get("/api/materials/<mat>/optim-status")
def api_optim_status(mat: str):
    from optim import optim_status
    return jsonify(optim_status(mat))


@app.get("/api/materials/<mat>/input/<kind>")
def api_get_mat_input(mat: str, kind: str):
    from optim import get_material_input
    data = get_material_input(mat, kind)
    return jsonify(data), (200 if data.get("ok") else 404)


@app.put("/api/materials/<mat>/input/<kind>")
def api_put_mat_input(mat: str, kind: str):
    from optim import put_material_input
    body = request.get_json(silent=True) or {}
    content = body.get("content")
    if content is None:
        return jsonify({"ok": False, "error": "content requis"}), 400
    try:
        return jsonify(put_material_input(mat, kind, str(content)))
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.post("/api/materials/<mat>/run/<kind>")
def api_run_mat_optim(mat: str, kind: str):
    from optim import run_material_optim
    body = request.get_json(silent=True) or {}
    try:
        return jsonify(run_material_optim(mat, kind, job_id=body.get("job_id")))
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.get("/api/jobs/<job_id>/signal")
def job_signal(job_id: str):
    """Statut pipeline + signal visible (auto-émission si job interrompu / en attente)."""
    refresh = (request.args.get("refresh") or "1") != "0"
    status = ensure_status_signal(job_id) if refresh else compute_pipeline_status(job_id)
    if not status.get("ok"):
        return jsonify(status), 404
    sig = status.get("signal")
    awaiting = bool(sig and sig.get("awaiting_user") and not sig.get("acked"))
    return jsonify(
        {
            "ok": True,
            "signal": sig,
            "awaiting_user": awaiting,
            "pipeline": {
                "state": status.get("state"),
                "state_label": status.get("state_label"),
                "current_step": status.get("current_step"),
                "current_label": status.get("current_label"),
                "next_step": status.get("next_step"),
                "next_label": status.get("next_label"),
                "hint": status.get("hint"),
                "qe_done": status.get("qe_done"),
                "qe_total": status.get("qe_total"),
                "running": status.get("running") or [],
                "checklist": status.get("checklist") or [],
            },
        }
    )


@app.post("/api/jobs/<job_id>/signal/ack")
def job_signal_ack(job_id: str):
    return jsonify(ack_step_signal(job_id))


@app.post("/api/jobs/<job_id>/publish")
def publish_job(job_id: str):
    from materials import publish_job_to_outputs
    data = request.get_json(silent=True) or {}
    return jsonify(_ok_signal(job_id, "publish", publish_job_to_outputs(job_id, data.get("material"))))


@app.post("/api/jobs/<job_id>/relax/prepare")
def relax_prepare(job_id: str):
    data = request.get_json(silent=True) or {}
    return jsonify(wf.prepare_relax(job_id, kind=str(data.get("kind", "relax"))))


@app.post("/api/jobs/<job_id>/relax/run")
def relax_run(job_id: str):
    data = request.get_json(silent=True) or {}
    return jsonify(
        wf.run_relax(
            job_id,
            kind=str(data.get("kind", "relax")),
            save_to_inputs=bool(data.get("save_to_inputs", True)),
        )
    )


@app.get("/api/inputs")
def api_inputs():
    return jsonify({"ok": True, "inputs": wf.list_library_inputs()})


@app.post("/api/jobs/<job_id>/use-input")
def use_input(job_id: str):
    data = request.get_json(silent=True) or {}
    name = data.get("name") or data.get("filename")
    if not name:
        return jsonify({"ok": False, "error": "name requis (fichier dans inputs/)"}), 400
    return jsonify(_ok_signal(job_id, "import", wf.use_library_input(job_id, str(name))))


@app.post("/api/jobs/<job_id>/structure")
def upload_structure(job_id: str):
    if "file" not in request.files:
        return jsonify({"ok": False, "error": "Fichier manquant (champ file)."}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"ok": False, "error": "Nom de fichier vide."}), 400
    return jsonify(wf.import_structure(job_id, f.filename, f.read()))



@app.post("/api/jobs/<job_id>/vc-relax/prepare")
def vcrelax_prepare(job_id: str):
    return jsonify(wf.prepare_vc_relax(job_id))


@app.post("/api/jobs/<job_id>/vc-relax/run")
def vcrelax_run(job_id: str):
    data = request.get_json(silent=True) or {}
    return jsonify(wf.run_vc_relax(job_id, save_to_inputs=bool(data.get("save_to_inputs", True))))


@app.post("/api/inputs/upload")
def inputs_upload():
    if "file" not in request.files:
        return jsonify({"ok": False, "error": "Fichier manquant"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"ok": False, "error": "Nom vide"}), 400
    return jsonify(wf.deposit_input_to_library(f.filename, f.read()))


@app.post("/api/estimate")
def estimate():
    """Estimation indicative du temps de calcul (QE + alm + anphon)."""
    data = request.get_json(silent=True) or {}
    nat_prim = int(data.get("nat_prim") or data.get("nat") or 2)
    nx = int(data.get("nx", 1))
    ny = int(data.get("ny", 1))
    nz = int(data.get("nz", 1))
    n_patterns = int(data.get("n_patterns", 12))
    max_jobs = data.get("max_jobs")
    max_jobs = int(max_jobs) if max_jobs is not None else None
    norder = int(data.get("norder", 1))
    mode = str(data.get("anphon_mode") or data.get("mode") or "phonons")
    k = data.get("kmesh") or [10, 10, 10]
    ecutwfc = float(data.get("ecutwfc") or 60.0)
    kf = data.get("kpoints_force") or [4, 4, 4]

    # Enrichir depuis le job / template SCF si fournis
    job_id = data.get("job_id")
    material = data.get("material")
    if job_id:
        st = wf.job_status(job_id)
        if st.get("ok"):
            meta = st.get("meta") or {}
            struct = meta.get("structure") or {}
            if struct.get("nat"):
                nat_prim = int(struct["nat"])
            sc = meta.get("supercell") or {}
            if sc.get("nx"):
                nx, ny, nz = int(sc["nx"]), int(sc.get("ny", 1)), int(sc.get("nz", 1))
            qt = meta.get("qe_template") or {}
            if qt.get("ecutwfc"):
                ecutwfc = float(qt["ecutwfc"])
            if qt.get("kpoints_force"):
                kf = qt["kpoints_force"]
    if material:
        tpl = INPUTS / material / f"{material}-scf.in"
        if not tpl.is_file():
            tpl = INPUTS / f"{material}_scf.in"
        if not tpl.is_file():
            tpl = INPUTS / "Si_scf.in"
        if tpl.is_file():
            parsed = parse_qe_scf_template(tpl)
            ecutwfc = float(parsed.get("ecutwfc") or ecutwfc)
            # k force adapté comme dans workflow
            kx0, ky0, kz0 = parsed.get("kpoints", (4, 4, 4))
            kf = (
                max(1, (int(kx0) + nx - 1) // nx),
                max(1, (int(ky0) + ny - 1) // ny),
                max(1, (int(kz0) + nz - 1) // nz),
            )
            if n_patterns > 1:
                kf = tuple(min(4, int(x)) for x in kf)

    return jsonify(
        estimate_runtime(
            nat_prim=nat_prim,
            nx=nx,
            ny=ny,
            nz=nz,
            n_patterns=n_patterns,
            max_jobs=max_jobs,
            ecutwfc=ecutwfc,
            kpoints_force=tuple(int(x) for x in kf),
            norder=norder,
            anphon_mode=mode,
            kmesh=(int(k[0]), int(k[1]), int(k[2])),
            tmin=float(data.get("tmin", 0)),
            tmax=float(data.get("tmax", 1000)),
            dt=float(data.get("dt", 50)),
        )
    )


@app.post("/api/jobs/<job_id>/supercell")
def supercell(job_id: str):
    data = request.get_json(silent=True) or {}
    return jsonify(
        _ok_signal(
            job_id,
            "supercell",
            wf.generate_supercell_displacements(
                job_id,
                nx=int(data.get("nx", 2)),
                ny=int(data.get("ny", 2)),
                nz=int(data.get("nz", 2)),
                magnitude=float(data.get("magnitude", 0.01)),
                n_patterns=int(data.get("n_patterns", 12)),
                norder=int(data.get("norder", 2)),
                method=str(data.get("method") or data.get("displace_method") or "auto"),
            ),
        )
    )


@app.post("/api/jobs/<job_id>/qe/run")
def qe_run(job_id: str):
    data = request.get_json(silent=True) or {}
    result = wf.launch_qe_displacements(job_id, max_jobs=int(data.get("max_jobs", 4)))
    # Signal fort seulement si toutes les forces + DFSET sont prêts ; sinon info partielle
    df = result.get("dfset") or {}
    if result.get("ok") and df.get("ok"):
        return jsonify(_ok_signal(job_id, "qe_forces", result))
    if result.get("ok"):
        n_ok = sum(1 for r in (result.get("results") or []) if r.get("ok"))
        n_tot = len(result.get("results") or [])
        return jsonify(
            _ok_signal(
                job_id,
                "qe_config",
                result,
                force=True,
                message=f"pw.x : {n_ok}/{n_tot} configs dans ce lot.",
                hint=(
                    df.get("error")
                    or "Continuez pw.x jusqu'à toutes les configs, puis DFSET."
                ),
            )
        )
    return jsonify(result)


@app.post("/api/jobs/<job_id>/dfset")
def dfset_build(job_id: str):
    return jsonify(_ok_signal(job_id, "dfset", wf.build_dfset_from_qe(job_id)))


@app.post("/api/jobs/<job_id>/alm/prepare")
def alm_prepare(job_id: str):
    data = request.get_json(silent=True) or {}
    cut_raw = data.get("cutoff", 8.0)
    try:
        cut_val = float(cut_raw)
    except (TypeError, ValueError):
        cut_val = 8.0
    # 0 ou négatif → pas de cutoff (None), convention ALAMODE
    cutoff = None if cut_val <= 0 else cut_val
    return jsonify(
        _ok_signal(
            job_id,
            "alm_prepare",
            wf.prepare_alm_optimize(
                job_id,
                norder=int(data.get("norder", 1)),
                cutoff=cutoff,
            ),
        )
    )


@app.post("/api/jobs/<job_id>/alm/run")
def alm_run(job_id: str):
    data = request.get_json(silent=True) or {}
    which = str(data.get("which", "optimize"))
    step = "alm_optimize" if which == "optimize" else "alm_run"
    return jsonify(_ok_signal(job_id, step, wf.run_alm(job_id, which=which)))


@app.post("/api/jobs/<job_id>/anphon/prepare")
def anphon_prepare(job_id: str):
    data = request.get_json(silent=True) or {}
    k = data.get("kmesh") or [10, 10, 10]
    return jsonify(
        _ok_signal(
            job_id,
            "anphon_prepare",
            wf.prepare_anphon(
                job_id,
                mode=str(data.get("mode", "phonons")),
                kmesh=(int(k[0]), int(k[1]), int(k[2])),
                tmin=float(data.get("tmin", 0)),
                tmax=float(data.get("tmax", 1000)),
                dt=float(data.get("dt", 50)),
            ),
        )
    )


@app.post("/api/jobs/<job_id>/anphon/run")
def anphon_run(job_id: str):
    return jsonify(_ok_signal(job_id, "anphon", wf.run_anphon(job_id)))



@app.get("/api/guide")
def guide():
    path = ROOT / "GUIDE.md"
    if not path.is_file():
        path = ROOT / "GUIDE_ESSAI.md"
    return send_from_directory(path.parent, path.name, mimetype="text/markdown; charset=utf-8")


@app.get("/api/guide/mini")
def guide_mini():
    """Mini-guide débutant affiché à chaque nouveau calcul."""
    path = ROOT / "GUIDE_MINI_CALCULS.md"
    if not path.is_file():
        return jsonify({"ok": False, "error": "GUIDE_MINI_CALCULS.md introuvable"}), 404
    return send_from_directory(path.parent, path.name, mimetype="text/markdown; charset=utf-8")




@app.get("/api/materials/<mat>/outputs")
def api_material_outputs(mat: str):
    from config import OUTPUTS
    from materials import _safe_name
    mat = _safe_name(mat)
    base = OUTPUTS / mat
    files = []
    if base.is_dir():
        for p in sorted(base.rglob("*")):
            if not p.is_file():
                continue
            if p.name.startswith("."):
                continue
            # ignorer wfc volumineux
            if p.suffix.lower() in {".dat", ".wfc", ".hdf5"} and "save" in str(p).lower():
                continue
            rel = p.relative_to(OUTPUTS)
            files.append({
                "name": p.name,
                "path": f"outputs/{rel.as_posix()}",
                "rel": rel.as_posix(),
                "size": p.stat().st_size,
            })
    return jsonify({"ok": True, "material": mat, "dir": f"outputs/{mat}", "files": files})


@app.get("/outputs/<path:fname>")
def serve_output_file(fname: str):
    from config import OUTPUTS
    return send_from_directory(OUTPUTS, fname, as_attachment=False)


@app.get("/inputs/<path:fname>")
def serve_input_file(fname: str):
    from config import INPUTS
    return send_from_directory(INPUTS, fname, as_attachment=False)


@app.get("/")
def index():
    return send_from_directory(INTERFACE, "index.html")


def main():
    host = os.environ.get("QEALAMODE_HOST", "127.0.0.1")
    port = int(os.environ.get("QEALAMODE_PORT", "5020"))
    print(f"QE-Alamode → http://{host}:{port}/")
    app.run(host=host, port=port, debug=False, threaded=True)


if __name__ == "__main__":
    main()

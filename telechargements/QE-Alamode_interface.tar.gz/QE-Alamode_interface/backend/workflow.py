"""Orchestration du workflow QE → ALAMODE."""
from __future__ import annotations

import json
import re
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

from ase.build import make_supercell
from ase.data import atomic_masses, atomic_numbers
from ase.io import read, write
import numpy as np

from alamode_io import write_alm_suggest, write_anphon_phonons, parse_kappa_file
from config import ROOT, WORK, LOGS, INPUTS, detect_tools
from qe_parser import (
    build_pw_scf_input,
    extract_forces_ry_au,
    parse_qe_input_full,
    parse_qe_scf_template,
    write_alamode_dfset,
)
from results_report import build_and_save


def _mass(symbol: str) -> float:
    try:
        return float(atomic_masses[atomic_numbers[symbol]])
    except Exception:
        return 1.0


def _pseudo_dir_for_job(job: Path) -> str:
    # Prefer project-level pseudos/
    project_pseudos = ROOT / "pseudos"
    env_pseudo = os.environ.get("PSEUDO_DIR")
    if env_pseudo and Path(env_pseudo).is_dir():
        return str(Path(env_pseudo).resolve())
    return str(project_pseudos.resolve())


def _job_dir(job_id: str) -> Path:
    d = WORK / job_id
    d.mkdir(parents=True, exist_ok=True)
    (d / "qe").mkdir(exist_ok=True)
    (d / "alamode").mkdir(exist_ok=True)
    (d / "results").mkdir(exist_ok=True)
    return d


def _save_meta(job: Path, meta: dict) -> None:
    (job / "meta.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _load_meta(job: Path) -> dict:
    p = job / "meta.json"
    if not p.exists():
        return {}
    return json.loads(p.read_text(encoding="utf-8"))


def create_job(name: str = "material", material: str | None = None) -> dict:
    from materials import _safe_name, material_from_filename
    mat = _safe_name(material or name)
    job_id = time.strftime("%Y%m%d_%H%M%S") + "_" + "".join(c for c in mat if c.isalnum())[:20]
    job = _job_dir(job_id)
    meta = {
        "id": job_id,
        "name": name or mat,
        "material": mat,
        "created": time.strftime("%Y-%m-%d %H:%M:%S"),
        "steps": {},
    }
    _save_meta(job, meta)
    # dossier outputs/<matériau>/
    from config import OUTPUTS
    (OUTPUTS / mat).mkdir(parents=True, exist_ok=True)
    return {"ok": True, "job_id": job_id, "material": mat, "path": str(job)}


def list_jobs() -> list[dict]:
    jobs = []
    if not WORK.exists():
        return jobs
    for p in sorted(WORK.iterdir(), reverse=True):
        if p.is_dir() and (p / "meta.json").exists():
            jobs.append(_load_meta(p))
    return jobs



def list_library_inputs() -> list[dict]:
    """Liste les inputs SCF/relax disponibles dans inputs/."""
    from config import INPUTS
    items = []
    paths = list(INPUTS.glob("*.in"))
    for d in INPUTS.iterdir():
        if d.is_dir():
            paths.extend(d.glob("*.in"))
    for path in sorted(paths):
        text = path.read_text(encoding="utf-8", errors="replace")[:4000]
        calc = None
        m = re.search(r"calculation\s*=\s*'([^']+)'", text, re.IGNORECASE)
        if m:
            calc = m.group(1)
        ecut = None
        m = re.search(r"ecutwfc\s*=\s*([0-9.eEdD+-]+)", text, re.IGNORECASE)
        if m:
            ecut = float(m.group(1).replace("d", "e").replace("D", "E"))
        has_cell = bool(re.search(r"CELL_PARAMETERS", text, re.IGNORECASE))
        has_pos = bool(re.search(r"ATOMIC_POSITIONS", text, re.IGNORECASE))
        # au moins une ligne de coordonnées numériques sous ATOMIC_POSITIONS
        has_coords = bool(re.search(
            r"ATOMIC_POSITIONS[^\n]*\n(?:\s*![^\n]*\n)*\s*[A-Za-z]{1,3}\s+[-+0-9.]",
            text, re.IGNORECASE,
        ))
        has_vecs = bool(re.search(
            r"CELL_PARAMETERS[^\n]*\n(?:\s*![^\n]*\n)*\s*[-+0-9.]+\s+[-+0-9.]+\s+[-+0-9.]+",
            text, re.IGNORECASE,
        ))
        compact = text.replace(" ", "").lower()
        ready = has_cell and has_pos and has_coords and has_vecs and "nat=0" not in compact
        items.append(
            {
                "name": path.name,
                "path": f"inputs/{path.relative_to(INPUTS)}",
                "size": path.stat().st_size,
                "calculation": calc,
                "ecutwfc": ecut,
                "ready": ready,
                "hint": "Prêt (structure + paramètres)" if ready else "Paramètres seuls — incomplet pour démarrer",
            }
        )
    return items


def use_library_input(job_id: str, filename: str) -> dict:
    """Démarre à partir d'un fichier de inputs/ (autonome)."""
    from materials import resolve_input_path, material_from_filename
    src = resolve_input_path(filename)
    if src is None:
        return {"ok": False, "error": f"Input introuvable dans inputs/ : {filename}"}
    job = _job_dir(job_id)
    meta = _load_meta(job)
    meta["material"] = meta.get("material") or material_from_filename(src.name)
    meta["input_file"] = str(src.relative_to(ROOT)) if str(src).startswith(str(ROOT)) else src.name
    _save_meta(job, meta)
    return import_structure(job_id, src.name, src.read_bytes())


def import_structure(job_id: str, filename: str, content: bytes) -> dict:
    """
    Import principal : input SCF/relax QE (.in) avec structure optimisée + paramètres.
    Option secondaire : CIF / POSCAR / XYZ (sans paramètres QE dédiés).
    """
    name_l = (filename or "").lower()
    is_qe = name_l.endswith(".in") or b"&control" in content[:2000].lower() or b"&CONTROL" in content[:2000]
    if is_qe:
        return import_scf_input(job_id, filename, content)
    return import_geometry_file(job_id, filename, content)


def import_scf_input(job_id: str, filename: str, content: bytes) -> dict:
    from qe_parser import parse_qe_input_full

    job = _job_dir(job_id)
    raw_dir = job / "structure_raw"
    raw_dir.mkdir(parents=True, exist_ok=True)
    src = raw_dir / (filename if filename.endswith(".in") else f"{filename}.in")
    src.write_bytes(content)

    parsed = parse_qe_input_full(src)
    atoms = parsed["atoms"]
    tpl = parsed["template"]

    write(str(job / "structure.cif"), atoms)
    # Garder l'input SCF de référence pour les paramètres des disp_*.in
    (job / "qe" / "reference_scf.in").parent.mkdir(parents=True, exist_ok=True)
    (job / "qe" / "reference_scf.in").write_bytes(content)
    (job / "qe_params.json").write_text(
        json.dumps(
            {
                k: (list(v) if isinstance(v, tuple) else v)
                for k, v in tpl.items()
                if k not in {"atoms"}
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (job / "structure_summary.json").write_text(
        json.dumps(
            {
                "nat": len(atoms),
                "symbols": atoms.get_chemical_symbols(),
                "cell": atoms.cell.array.tolist(),
                "positions": atoms.get_positions().tolist(),
                "formula": atoms.get_chemical_formula(),
                "source": "scf_input",
                "file": src.name,
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    meta = _load_meta(job)
    meta["structure"] = {
        "file": src.name,
        "source": "scf_input",
        "nat": len(atoms),
        "symbols": atoms.get_chemical_symbols(),
        "cell": atoms.cell.array.tolist(),
        "formula": atoms.get_chemical_formula(),
        "calculation": tpl.get("calculation"),
        "ecutwfc": tpl.get("ecutwfc"),
        "ecutrho": tpl.get("ecutrho"),
        "kpoints": list(tpl.get("kpoints") or (2, 2, 2)),
    }
    meta["qe_params"] = {
        k: (list(v) if isinstance(v, tuple) else v)
        for k, v in tpl.items()
        if isinstance(v, (int, float, str, list, dict, tuple, type(None), bool))
    }
    meta["steps"]["import"] = {
        "ok": True,
        "mode": "scf",
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "hint": "Structure + paramètres QE issus de l'input SCF/relax.",
    }
    _save_meta(job, meta)
    return {
        "ok": True,
        "mode": "scf",
        "structure": meta["structure"],
        "qe_params": meta["qe_params"],
        "message": "Input SCF/relax importé : géométrie optimisée + paramètres QE conservés.",
    }


def import_geometry_file(job_id: str, filename: str, content: bytes) -> dict:
    job = _job_dir(job_id)
    src = job / "structure_raw" / filename
    src.parent.mkdir(parents=True, exist_ok=True)
    src.write_bytes(content)
    atoms = read(str(src))
    write(str(job / "structure.cif"), atoms)
    (job / "structure_summary.json").write_text(
        json.dumps(
            {
                "nat": len(atoms),
                "symbols": atoms.get_chemical_symbols(),
                "cell": atoms.cell.array.tolist(),
                "positions": atoms.get_positions().tolist(),
                "formula": atoms.get_chemical_formula(),
                "source": "geometry",
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    meta = _load_meta(job)
    meta["structure"] = {
        "file": filename,
        "source": "geometry",
        "nat": len(atoms),
        "symbols": atoms.get_chemical_symbols(),
        "cell": atoms.cell.array.tolist(),
        "formula": atoms.get_chemical_formula(),
    }
    meta["steps"]["import"] = {
        "ok": True,
        "mode": "geometry",
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "hint": "Géométrie seule — préférer un input SCF relaxé pour les paramètres QE.",
    }
    _save_meta(job, meta)
    return {
        "ok": True,
        "mode": "geometry",
        "structure": meta["structure"],
        "message": "Géométrie importée (CIF/XYZ…). Pour un calcul sérieux, importez plutôt un input SCF relaxé.",
    }



def _qe_tpl_for_job(job: Path, sc) -> dict:
    qe_tpl: dict = {}
    params_path = job / "qe_params.json"
    if params_path.is_file():
        try:
            qe_tpl = json.loads(params_path.read_text(encoding="utf-8"))
            if isinstance(qe_tpl.get("kpoints"), list):
                qe_tpl["kpoints"] = tuple(qe_tpl["kpoints"])
        except Exception:
            qe_tpl = {}
    if not qe_tpl:
        formula = "".join(dict.fromkeys(sc.get_chemical_symbols()))
        for cand in (
            job / "qe" / "reference_scf.in",
            INPUTS / f"{formula}_scf.in",
            INPUTS / "Si_scf.in",
            *sorted(INPUTS.glob("*_scf.in")),
        ):
            if cand.is_file():
                qe_tpl = parse_qe_scf_template(cand)
                break
    return qe_tpl


def _force_kmesh(qe_tpl: dict, nx: int, ny: int, nz: int, n_patterns: int) -> tuple[int, int, int]:
    kx0, ky0, kz0 = qe_tpl.get("kpoints", (2, 2, 2))
    k_force = (
        max(1, (kx0 + nx - 1) // nx),
        max(1, (ky0 + ny - 1) // ny),
        max(1, (kz0 + nz - 1) // nz),
    )
    if n_patterns > 1:
        k_force = tuple(min(4, k) for k in k_force)  # type: ignore[assignment]
    return k_force  # type: ignore[return-value]


def _write_one_disp_qe(
    *,
    job: Path,
    sc,
    index: int,
    pos: np.ndarray,
    ref_pos: np.ndarray,
    qe_tpl: dict,
    k_force: tuple[int, int, int],
    pseudo_dir: str,
    meta_extra: dict | None = None,
) -> dict:
    qe_dir = job / "qe"
    displaced = sc.copy()
    displaced.set_positions(pos)
    write(str(qe_dir / f"disp_{index:04d}.xyz"), displaced)
    np.save(qe_dir / f"disp_{index:04d}_dr.npy", pos - ref_pos)
    symbols = displaced.get_chemical_symbols()
    unique: list[str] = []
    for s in symbols:
        if s not in unique:
            unique.append(s)
    species = [{"symbol": s, "mass": _mass(s), "pseudo": f"{s}.UPF"} for s in unique]
    positions = [
        {"symbol": s, "x": float(p[0]), "y": float(p[1]), "z": float(p[2]), "unit": "angstrom"}
        for s, p in zip(symbols, displaced.get_positions())
    ]
    text = build_pw_scf_input(
        prefix=f"disp{index:04d}",
        species=species,
        positions=positions,
        cell=displaced.cell.array.tolist(),
        ecutwfc=float(qe_tpl.get("ecutwfc", 40.0)),
        ecutrho=float(qe_tpl.get("ecutrho", 320.0)),
        kpoints=k_force,
        pseudo_dir=pseudo_dir,
        occupations=qe_tpl.get("occupations"),
        smearing=qe_tpl.get("smearing"),
        degauss=qe_tpl.get("degauss"),
        conv_thr=str(qe_tpl.get("conv_thr", "1.0d-8")),
        mixing_beta=qe_tpl.get("mixing_beta"),
    )
    inp = qe_dir / f"disp_{index:04d}.in"
    inp.write_text(text, encoding="utf-8")
    info = {"index": index, "input": inp.name}
    if meta_extra:
        info.update(meta_extra)
    return info


def _patterns_from_ase(sc, *, n_patterns: int, magnitude: float) -> list[tuple[np.ndarray, dict]]:
    """Fallback : un atome déplacé aléatoirement par motif."""
    ref = sc.get_positions()
    rng = np.random.default_rng(42)
    out = []
    for i in range(max(1, n_patterns)):
        pos = ref.copy()
        atom_idx = int(i % len(sc))
        direction = rng.normal(size=3)
        direction /= np.linalg.norm(direction) + 1e-15
        pos[atom_idx] = pos[atom_idx] + magnitude * direction
        out.append((pos, {"atom": atom_idx, "method": "ase_random"}))
    return out


def _patterns_from_alm_suggest(
    job: Path,
    sc,
    *,
    job_id: str,
    norder: int,
    magnitude: float,
    qe_tpl: dict,
    k_force: tuple[int, int, int],
    pseudo_dir: str,
    max_patterns: int | None,
) -> tuple[list[tuple[np.ndarray, dict]], dict]:
    """
    alm MODE=suggest → pattern_* → displace.py → positions déplacées.
    Retourne (liste (pos, meta), info_debug) ou lève RuntimeError.
    """
    tools = detect_tools()
    if not tools.get("alm"):
        raise RuntimeError("alm introuvable")
    displace_py = ROOT / "tools" / "alamode" / "displace.py"
    if not displace_py.is_file():
        raise RuntimeError(f"displace.py absent ({displace_py})")

    alamode = job / "alamode"
    alamode.mkdir(parents=True, exist_ok=True)
    prefix = (job_id[:20] or "mat").replace(" ", "_")
    kd: list[str] = []
    for s in sc.get_chemical_symbols():
        if s not in kd:
            kd.append(s)
    frac = sc.get_scaled_positions()
    write_alm_suggest(
        alamode / "alm_suggest.in",
        prefix=prefix,
        nat=len(sc),
        nkd=len(kd),
        kd_names=kd,
        lattice_vectors=sc.cell.array.tolist(),
        positions_frac=[(s, float(f[0]), float(f[1]), float(f[2])) for s, f in zip(sc.get_chemical_symbols(), frac)],
        mode="suggest",
        norder=max(1, int(norder)),
    )
    proc = subprocess.run(
        [tools["alm"], str(alamode / "alm_suggest.in")],
        cwd=str(alamode),
        capture_output=True,
        text=True,
        timeout=600,
    )
    (alamode / "alm_suggest.log").write_text((proc.stdout or "") + "\n" + (proc.stderr or ""), encoding="utf-8")
    if proc.returncode != 0:
        raise RuntimeError(f"alm suggest rc={proc.returncode} — voir alamode/alm_suggest.log")

    pattern_files = sorted(alamode.glob(f"{prefix}.pattern_*"))
    if not pattern_files:
        pattern_files = sorted(alamode.glob("*.pattern_*"))
    if not pattern_files:
        raise RuntimeError("Aucun fichier *.pattern_* produit par alm suggest")

    # Input QE d'équilibre pour displace.py
    qe_dir = job / "qe"
    symbols = sc.get_chemical_symbols()
    unique: list[str] = []
    for s in symbols:
        if s not in unique:
            unique.append(s)
    species = [{"symbol": s, "mass": _mass(s), "pseudo": f"{s}.UPF"} for s in unique]
    eq_pos = [
        {"symbol": s, "x": float(p[0]), "y": float(p[1]), "z": float(p[2]), "unit": "angstrom"}
        for s, p in zip(symbols, sc.get_positions())
    ]
    eq_text = build_pw_scf_input(
        prefix="supercell_eq",
        species=species,
        positions=eq_pos,
        cell=sc.cell.array.tolist(),
        ecutwfc=float(qe_tpl.get("ecutwfc", 40.0)),
        ecutrho=float(qe_tpl.get("ecutrho", 320.0)),
        kpoints=k_force,
        pseudo_dir=pseudo_dir,
        occupations=qe_tpl.get("occupations"),
        smearing=qe_tpl.get("smearing"),
        degauss=qe_tpl.get("degauss"),
        conv_thr=str(qe_tpl.get("conv_thr", "1.0d-8")),
        mixing_beta=qe_tpl.get("mixing_beta"),
    )
    eq_in = qe_dir / "supercell_eq.in"
    eq_in.write_text(eq_text, encoding="utf-8")

    # Nettoyer anciennes sorties displace
    for old in list(alamode.glob("disp_sug*.pw.in")) + list(alamode.glob("disp_sug*.in")):
        old.unlink(missing_ok=True)

    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT / "tools" / "alamode") + (
        os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else ""
    )
    cmd = [
        sys.executable,
        str(displace_py),
        "--QE",
        str(eq_in.resolve()),
        "-pf",
        *[str(p.name) for p in pattern_files],
        "--mag",
        str(magnitude),
        "--prefix",
        "disp_sug",
    ]
    dproc = subprocess.run(cmd, cwd=str(alamode), capture_output=True, text=True, timeout=600, env=env)
    (alamode / "displace.log").write_text((dproc.stdout or "") + "\n" + (dproc.stderr or ""), encoding="utf-8")
    if dproc.returncode != 0:
        raise RuntimeError(f"displace.py rc={dproc.returncode} — voir alamode/displace.log")

    sug_files = sorted(alamode.glob("disp_sug*.pw.in"))
    if not sug_files:
        sug_files = sorted(alamode.glob("disp_sug*.in"))
    if not sug_files:
        raise RuntimeError("displace.py n'a produit aucun disp_sug*.pw.in")

    if max_patterns and max_patterns > 0:
        sug_files = sug_files[:max_patterns]

    from ase import Atoms

    out: list[tuple[np.ndarray, dict]] = []
    for i, fpath in enumerate(sug_files):
        parsed = parse_qe_input_full(fpath)
        atoms_d: Atoms = parsed["atoms"]
        # Aligner la cellule sur la supercellule ASE (même orientation)
        atoms_d.set_cell(sc.cell, scale_atoms=False)
        out.append(
            (
                atoms_d.get_positions(),
                {"method": "alm_suggest", "source": fpath.name, "patterns": [p.name for p in pattern_files]},
            )
        )
    info = {
        "norder_suggest": norder,
        "pattern_files": [p.name for p in pattern_files],
        "n_displaced": len(out),
        "eq_input": "qe/supercell_eq.in",
    }
    return out, info


def generate_supercell_displacements(
    job_id: str,
    *,
    nx: int = 2,
    ny: int = 2,
    nz: int = 2,
    magnitude: float = 0.01,
    n_patterns: int = 12,
    norder: int = 2,
    method: str = "auto",
) -> dict:
    """
    Supercellule + motifs de déplacements.
    method=auto|suggest|ase :
      - auto/suggest : alm MODE=suggest + displace.py si alm disponible
      - ase : fallback aléatoire (1 atome / motif)
    n_patterns sert de plafond (suggest) ou de nombre exact (ase).
    """
    job = _job_dir(job_id)
    struct = job / "structure.cif"
    if not struct.exists():
        return {"ok": False, "error": "Importez d'abord une structure."}
    atoms = read(str(struct))
    P = np.diag([nx, ny, nz])
    sc = make_supercell(atoms, P)
    write(str(job / "supercell.cif"), sc)

    qe_dir = job / "qe"
    for old in list(qe_dir.glob("disp_*.in")) + list(qe_dir.glob("disp_*.xyz")) + list(qe_dir.glob("disp_*.npy")):
        old.unlink(missing_ok=True)

    tools = detect_tools()
    pseudo_dir = _pseudo_dir_for_job(job)
    ref_pos = sc.get_positions()
    np.save(qe_dir / "ref_positions.npy", ref_pos)

    qe_tpl = _qe_tpl_for_job(job, sc)
    method_l = (method or "auto").lower()
    use_suggest = method_l in {"auto", "suggest"} and bool(tools.get("alm"))
    if method_l == "suggest" and not tools.get("alm"):
        return {"ok": False, "error": "method=suggest mais binaire alm introuvable."}

    # k-mesh provisoire (affiné après connaître n_patterns réel)
    k_force = _force_kmesh(qe_tpl, nx, ny, nz, max(1, n_patterns))

    displace_info: dict = {}
    pattern_rows: list[tuple[np.ndarray, dict]] = []
    method_used = "ase_random"
    warn = None

    if use_suggest:
        try:
            pattern_rows, displace_info = _patterns_from_alm_suggest(
                job,
                sc,
                job_id=job_id,
                norder=norder,
                magnitude=magnitude,
                qe_tpl=qe_tpl,
                k_force=k_force,
                pseudo_dir=pseudo_dir,
                max_patterns=n_patterns if n_patterns > 0 else None,
            )
            method_used = "alm_suggest"
        except Exception as exc:
            if method_l == "suggest":
                return {"ok": False, "error": f"alm suggest / displace a échoué : {exc}"}
            warn = f"alm suggest échoué ({exc}) — fallback ASE"
            pattern_rows = []

    if not pattern_rows:
        pattern_rows = _patterns_from_ase(sc, n_patterns=n_patterns, magnitude=magnitude)
        method_used = "ase_random"
        # garder le template suggest pour usage manuel
        kd = []
        for s in sc.get_chemical_symbols():
            if s not in kd:
                kd.append(s)
        frac = sc.get_scaled_positions()
        write_alm_suggest(
            job / "alamode" / "alm_suggest.in",
            prefix=job_id[:20] or "mat",
            nat=len(sc),
            nkd=len(kd),
            kd_names=kd,
            lattice_vectors=sc.cell.array.tolist(),
            positions_frac=[(s, float(f[0]), float(f[1]), float(f[2])) for s, f in zip(sc.get_chemical_symbols(), frac)],
            mode="suggest",
            norder=max(1, int(norder)),
        )

    k_force = _force_kmesh(qe_tpl, nx, ny, nz, len(pattern_rows))
    patterns = []
    for i, (pos, extra) in enumerate(pattern_rows):
        patterns.append(
            _write_one_disp_qe(
                job=job,
                sc=sc,
                index=i,
                pos=pos,
                ref_pos=ref_pos,
                qe_tpl=qe_tpl,
                k_force=k_force,
                pseudo_dir=pseudo_dir,
                meta_extra=extra,
            )
        )

    meta = _load_meta(job)
    meta["supercell"] = {
        "nx": nx,
        "ny": ny,
        "nz": nz,
        "nat": len(sc),
        "n_patterns": len(patterns),
        "displace_method": method_used,
        "norder_suggest": norder,
    }
    meta["qe_template"] = {
        "source": qe_tpl.get("source"),
        "ecutwfc": qe_tpl.get("ecutwfc"),
        "ecutrho": qe_tpl.get("ecutrho"),
        "kpoints_template": list(qe_tpl.get("kpoints", (2, 2, 2))),
        "kpoints_force": list(k_force),
    }
    note = (
        "Motifs ALAMODE (alm suggest + displace.py) — optimal pour IFC/κ_L."
        if method_used == "alm_suggest"
        else "Motifs ASE aléatoires (fallback)."
    )
    if warn:
        note = warn + " · " + note
    meta["steps"]["supercell"] = {
        "ok": True,
        "patterns": patterns,
        "alm_suggest": "alamode/alm_suggest.in",
        "note": note,
        "displace_method": method_used,
        "displace_info": displace_info,
        "alm_available": bool(tools.get("alm")),
        "qe_template": meta["qe_template"],
    }
    _save_meta(job, meta)
    return {
        "ok": True,
        "supercell": meta["supercell"],
        "patterns": patterns,
        "displace_method": method_used,
        "warning": warn,
        "tools": tools,
    }


def _qe_out_complete(outfile: Path) -> bool:
    """True si pw.x a fini correctement (forces finales fiables)."""
    if not outfile.is_file():
        return False
    try:
        text = outfile.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    return "JOB DONE" in text


def _read_alm_norder(job: Path) -> int | None:
    for name in ("alm_optimize.in", "alm_suggest.in"):
        path = job / "alamode" / name
        if not path.is_file():
            continue
        m = re.search(r"NORDER\s*=\s*(\d+)", path.read_text(encoding="utf-8", errors="replace"))
        if m:
            return int(m.group(1))
    return None


def launch_qe_displacements(job_id: str, *, max_jobs: int = 4) -> dict:
    """Lance pw.x sur les inputs disp_*.in (séquentiel pour stabilité)."""
    tools = detect_tools()
    if not tools.get("pw_x"):
        return {"ok": False, "error": "pw.x introuvable. Définissez QE_BIN_DIR."}
    job = _job_dir(job_id)
    qe_dir = job / "qe"
    all_inputs = sorted(qe_dir.glob("disp_*.in"))
    inputs = all_inputs[:max_jobs]
    if not inputs:
        return {"ok": False, "error": "Aucun input disp_*.in — générez d'abord les supercellules."}

    results = []
    for inp in inputs:
        out = inp.with_suffix(".out")
        log = LOGS / f"{job_id}_{inp.stem}.log"
        cmd = [tools["pw_x"], "-in", str(inp)]
        try:
            with out.open("w", encoding="utf-8") as fout, log.open("w", encoding="utf-8") as flog:
                proc = subprocess.run(
                    cmd,
                    cwd=str(qe_dir),
                    stdout=fout,
                    stderr=flog,
                    # 3×3×3 Si ~plusieurs heures / config ; 3600s coupait les SCF à ~it.5
                    timeout=int(os.environ.get("QE_TIMEOUT", "21600")),
                    check=False,
                )
            ok = proc.returncode == 0 and _qe_out_complete(out)
            forces_n = None
            if ok:
                try:
                    forces_n = len(extract_forces_ry_au(out))
                except Exception:
                    ok = False
            results.append({"input": inp.name, "ok": ok, "rc": proc.returncode, "forces": forces_n})
        except subprocess.TimeoutExpired:
            results.append({"input": inp.name, "ok": False, "error": "timeout"})

    meta = _load_meta(job)
    meta["steps"]["qe_forces"] = {"ok": all(r.get("ok") for r in results), "results": results}
    _save_meta(job, meta)

    # DFSET seulement quand toutes les configs prévues sont terminées (pas un DFSET partiel).
    done_outs = [p for p in qe_dir.glob("disp_*.out") if _qe_out_complete(p)]
    n_expected = len(all_inputs)
    dfset_info: dict | None
    if n_expected > 0 and len(done_outs) >= n_expected:
        dfset_info = build_dfset_from_qe(job_id)
    else:
        dfset_info = {
            "ok": False,
            "skipped": True,
            "n_done": len(done_outs),
            "n_expected": n_expected,
            "error": (
                f"DFSET non construit : {len(done_outs)}/{n_expected} configs QE terminées "
                "(JOB DONE). Relancez les motifs restants ou scripts/resume_job.sh."
            ),
        }

    return {"ok": True, "results": results, "dfset": dfset_info}


def build_dfset_from_qe(job_id: str) -> dict:
    """Assemble DFSET = déplacements sauvegardés + forces des .out QE complets uniquement."""
    job = _job_dir(job_id)
    qe_dir = job / "qe"
    inputs = sorted(qe_dir.glob("disp_*.in"))
    outs = sorted(qe_dir.glob("disp_*.out"))
    if not outs:
        return {"ok": False, "error": "Aucun fichier disp_*.out"}

    pairs = []
    used = []
    skipped = []
    for out in outs:
        if not _qe_out_complete(out):
            skipped.append(out.name)
            continue
        stem = out.stem  # disp_0000
        dr_path = qe_dir / f"{stem}_dr.npy"
        if not dr_path.exists():
            skipped.append(f"{out.name} (pas de {stem}_dr.npy)")
            continue
        try:
            forces = extract_forces_ry_au(out)
            displ = np.load(dr_path)
            if displ.shape[0] != len(forces):
                return {
                    "ok": False,
                    "error": f"Incohérence atomes dans {out.name}: displ={displ.shape[0]} forces={len(forces)}",
                }
            displs = [tuple(map(float, row)) for row in displ]
            pairs.append((displs, forces))
            used.append(out.name)
        except Exception as exc:
            return {"ok": False, "error": f"{out.name}: {exc}"}

    if not pairs:
        return {
            "ok": False,
            "error": "Aucun couple déplacement/forces exploitable (vérifier JOB DONE dans les .out)",
            "skipped": skipped,
        }

    n_expected = len(inputs) if inputs else len(outs)
    incomplete = n_expected > 0 and len(pairs) < n_expected
    dest = job / "alamode" / "DFSET"
    n = write_alamode_dfset(pairs, dest)
    meta = _load_meta(job)
    meta["steps"]["dfset"] = {
        "ok": not incomplete,
        "file": "alamode/DFSET",
        "n_configs": n,
        "n_expected": n_expected,
        "sources": used,
        "skipped": skipped,
        "warning": (
            f"DFSET partiel : {n}/{n_expected} configs — IFC/κ_L non fiables tant que tous les motifs ne sont pas finis."
            if incomplete
            else None
        ),
    }
    _save_meta(job, meta)
    result = {
        "ok": True,
        "file": "alamode/DFSET",
        "n_configs": n,
        "n_expected": n_expected,
        "sources": used,
        "skipped": skipped,
    }
    if incomplete:
        result["warning"] = meta["steps"]["dfset"]["warning"]
        result["partial"] = True
    return result


def prepare_alm_optimize(job_id: str, *, norder: int = 1, cutoff: float | None = 8.0) -> dict:
    job = _job_dir(job_id)
    struct = job / "supercell.cif"
    if not struct.exists():
        struct = job / "structure.cif"
    if not struct.exists():
        return {"ok": False, "error": "Structure absente."}
    atoms = read(str(struct))
    kd = []
    for s in atoms.get_chemical_symbols():
        if s not in kd:
            kd.append(s)
    frac = atoms.get_scaled_positions()
    write_alm_suggest(
        job / "alamode" / "alm_optimize.in",
        prefix=(job_id[:20] or "mat"),
        nat=len(atoms),
        nkd=len(kd),
        kd_names=kd,
        lattice_vectors=atoms.cell.array.tolist(),
        positions_frac=[(s, float(f[0]), float(f[1]), float(f[2])) for s, f in zip(atoms.get_chemical_symbols(), frac)],
        mode="optimize",
        norder=norder,
        cutoff=None if cutoff is None or float(cutoff) <= 0 else float(cutoff),
    )
    # Copier DFSET si l'utilisateur en a fourni un
    meta = _load_meta(job)
    meta["steps"]["alm_prepare"] = {
        "ok": True,
        "file": "alamode/alm_optimize.in",
        "norder": norder,
        "cutoff": cutoff,
        "hint": "Placez votre DFSET (déplacements+forces) dans work/<job>/alamode/DFSET puis lancez alm.",
    }
    _save_meta(job, meta)
    return {"ok": True, "file": "alamode/alm_optimize.in", "tools": detect_tools()}


def run_alm(job_id: str, which: str = "optimize") -> dict:
    tools = detect_tools()
    if not tools.get("alm"):
        return {
            "ok": False,
            "error": "Binaire `alm` introuvable. Installez ALAMODE et définissez ALAMODE_BIN_DIR.",
            "tools": tools,
        }
    job = _job_dir(job_id)
    inp = job / "alamode" / (f"alm_{which}.in" if which != "suggest" else "alm_suggest.in")
    if which == "suggest":
        inp = job / "alamode" / "alm_suggest.in"
    if not inp.exists():
        return {"ok": False, "error": f"Fichier absent : {inp.name}"}
    out = job / "alamode" / f"alm_{which}.log"
    proc = subprocess.run(
        [tools["alm"], str(inp)],
        cwd=str(job / "alamode"),
        capture_output=True,
        text=True,
        timeout=3600,
    )
    out.write_text((proc.stdout or "") + "\n" + (proc.stderr or ""), encoding="utf-8")
    meta = _load_meta(job)
    meta["steps"][f"alm_{which}"] = {"ok": proc.returncode == 0, "rc": proc.returncode, "log": str(out.name)}
    report = None
    if proc.returncode == 0:
        report = build_and_save(job, meta)
        meta["results_summary"] = {
            "generated_at": report.get("generated_at"),
            "fiche": report.get("fiche"),
            "n_params_ok": sum(1 for p in report.get("params") or [] if p.get("status") == "ok"),
        }
    _save_meta(job, meta)
    return {
        "ok": proc.returncode == 0,
        "rc": proc.returncode,
        "log": out.read_text(encoding="utf-8")[-4000:],
        "results": report,
    }


def prepare_anphon(job_id: str, *, mode: str = "phonons", kmesh=(10, 10, 10), tmin=0, tmax=1000, dt=50) -> dict:
    job = _job_dir(job_id)
    struct = job / "supercell.cif"
    if not struct.exists():
        struct = job / "structure.cif"
    if not struct.exists():
        return {"ok": False, "error": "Structure absente."}
    mode_l = (mode or "phonons").lower()
    norder = _read_alm_norder(job)
    if mode_l in {"rta", "bte"} and norder is not None and norder < 2:
        return {
            "ok": False,
            "error": (
                f"MODE={mode_l} exige des IFC cubiques (NORDER≥2), "
                f"mais alm est préparé avec NORDER={norder}. "
                "Relancez alm/prepare avec norder=2 puis alm/run avant RTA."
            ),
            "norder": norder,
        }
    atoms = read(str(struct))
    kd = []
    for s in atoms.get_chemical_symbols():
        if s not in kd:
            kd.append(s)
    write_anphon_phonons(
        job / "alamode" / "anphon.in",
        prefix=(job_id[:20] or "mat"),
        kd_names=kd,
        masses=[_mass(s) for s in kd],
        lattice_vectors=atoms.cell.array.tolist(),
        mode=mode_l,
        kmesh=tuple(kmesh),
        tmin=tmin,
        tmax=tmax,
        dt=dt,
    )
    meta = _load_meta(job)
    meta["steps"]["anphon_prepare"] = {"ok": True, "mode": mode_l, "kmesh": list(kmesh), "norder": norder}
    _save_meta(job, meta)
    return {"ok": True, "file": "alamode/anphon.in", "mode": mode_l, "norder": norder}


def run_anphon(job_id: str) -> dict:
    tools = detect_tools()
    if not tools.get("anphon"):
        return {"ok": False, "error": "Binaire `anphon` introuvable.", "tools": tools}
    job = _job_dir(job_id)
    inp = job / "alamode" / "anphon.in"
    if not inp.exists():
        return {"ok": False, "error": "anphon.in absent — préparez d'abord l'étape anphon."}
    inp_text = inp.read_text(encoding="utf-8", errors="replace")
    mode_m = re.search(r"MODE\s*=\s*(\w+)", inp_text, re.IGNORECASE)
    mode_l = (mode_m.group(1) if mode_m else "phonons").lower()
    norder = _read_alm_norder(job)
    if mode_l in {"rta", "bte"} and norder is not None and norder < 2:
        return {
            "ok": False,
            "error": (
                f"anphon.in est en MODE={mode_l} mais NORDER={norder} < 2. "
                "Chaîne invalide pour κ_L : alm NORDER=2 → anphon phonons → anphon rta."
            ),
            "norder": norder,
            "mode": mode_l,
        }
    out = job / "alamode" / "anphon.log"
    proc = subprocess.run(
        [tools["anphon"], str(inp)],
        cwd=str(job / "alamode"),
        capture_output=True,
        text=True,
        timeout=7200,
    )
    out.write_text((proc.stdout or "") + "\n" + (proc.stderr or ""), encoding="utf-8")
    # chercher kappa (fichiers *kappa* ou *.kl ALAMODE)
    kappa_rows = []
    kappa_cands = sorted((job / "alamode").glob("*kappa*")) + sorted((job / "alamode").glob("*.kl"))
    for cand in kappa_cands:
        kappa_rows = parse_kappa_file(cand)
        if kappa_rows:
            shutil.copy2(cand, job / "results" / cand.name)
            break
    meta = _load_meta(job)
    meta["steps"]["anphon"] = {"ok": proc.returncode == 0, "rc": proc.returncode, "kappa_points": len(kappa_rows)}
    if kappa_rows:
        meta["kappa"] = kappa_rows
        (job / "results" / "kappa.json").write_text(json.dumps(kappa_rows, indent=2), encoding="utf-8")
    report = None
    if proc.returncode == 0:
        report = build_and_save(job, meta)
        meta["results_summary"] = {
            "generated_at": report.get("generated_at"),
            "fiche": report.get("fiche"),
            "n_params_ok": sum(1 for p in report.get("params") or [] if p.get("status") == "ok"),
        }
    _save_meta(job, meta)
    return {
        "ok": proc.returncode == 0,
        "rc": proc.returncode,
        "mode": mode_l,
        "kappa": kappa_rows,
        "log_tail": out.read_text(encoding="utf-8")[-3000:],
        "results": report,
    }


def get_results(job_id: str, *, refresh: bool = True) -> dict:
    job = WORK / job_id
    if not job.exists():
        return {"ok": False, "error": "Job inconnu"}
    meta = _load_meta(job)
    if refresh:
        data = build_and_save(job, meta)
        meta["results_summary"] = {
            "generated_at": data.get("generated_at"),
            "fiche": data.get("fiche"),
            "n_params_ok": sum(1 for p in data.get("params") or [] if p.get("status") == "ok"),
        }
        _save_meta(job, meta)
    else:
        data = build_and_save(job, meta)
    return data


def job_status(job_id: str) -> dict:
    job = WORK / job_id
    if not job.exists():
        return {"ok": False, "error": "Job inconnu"}
    meta = _load_meta(job)
    files = {
        "qe_inputs": [p.name for p in sorted((job / "qe").glob("*.in"))],
        "qe_outputs": [p.name for p in sorted((job / "qe").glob("*.out"))],
        "alamode": [p.name for p in sorted((job / "alamode").iterdir())] if (job / "alamode").exists() else [],
        "results": [p.name for p in sorted((job / "results").iterdir())] if (job / "results").exists() else [],
    }
    return {"ok": True, "meta": meta, "files": files, "tools": detect_tools()}


def render_fiche_html(data: dict, *, auto_print: bool = False) -> str:
    from fiche_html import render_fiche_html as _render
    return _render(data, auto_print=auto_print)


def prepare_relax(job_id: str, *, kind: str = "vc-relax") -> dict:
    """
    Onglet Optimisation : kind = 'relax' (ions) ou 'vc-relax' (ions+cellule).
    Pseudos et sorties locaux à cette interface.
    """
    from qe_parser import build_pw_scf_input

    kind = "vc-relax" if kind.lower() in {"vc-relax", "vcrelax", "vc_relax"} else "relax"
    job = _job_dir(job_id)
    struct = job / "structure.cif"
    if not struct.exists():
        return {"ok": False, "error": "Choisissez d'abord le matériau et son input (SCF ou géométrie)."}
    atoms = read(str(struct))
    qe_tpl: dict = {}
    if (job / "qe_params.json").is_file():
        try:
            qe_tpl = json.loads((job / "qe_params.json").read_text(encoding="utf-8"))
            if isinstance(qe_tpl.get("kpoints"), list):
                qe_tpl["kpoints"] = tuple(qe_tpl["kpoints"])
        except Exception:
            qe_tpl = {}

    kd = []
    for s in atoms.get_chemical_symbols():
        if s not in kd:
            kd.append(s)
    pseudo_map = qe_tpl.get("pseudo_map") or {}
    mass_map = qe_tpl.get("mass_map") or {}
    species = [
        {"symbol": s, "mass": float(mass_map.get(s, _mass(s))), "pseudo": pseudo_map.get(s, f"{s}.UPF")}
        for s in kd
    ]
    positions = [
        {"symbol": s, "x": float(f[0]), "y": float(f[1]), "z": float(f[2]), "unit": "crystal"}
        for s, f in zip(atoms.get_chemical_symbols(), atoms.get_scaled_positions())
    ]
    from config import OUTPUTS
    meta = _load_meta(job)
    mat = meta.get("material") or "material"
    outdir = OUTPUTS / mat / "optimisation" / kind.replace("-", "")
    outdir.mkdir(parents=True, exist_ok=True)
    pseudo_dir = _pseudo_dir_for_job(job)

    text = build_pw_scf_input(
        prefix=kind.replace("-", ""),
        species=species,
        positions=positions,
        cell=atoms.cell.array.tolist(),
        ecutwfc=float(qe_tpl.get("ecutwfc", 60.0)),
        ecutrho=float(qe_tpl.get("ecutrho", 480.0)),
        kpoints=tuple(qe_tpl.get("kpoints") or (4, 4, 4)),
        pseudo_dir=pseudo_dir,
        occupations=qe_tpl.get("occupations") or "smearing",
        smearing=qe_tpl.get("smearing") or "cold",
        degauss=qe_tpl.get("degauss", 0.02),
        conv_thr=str(qe_tpl.get("conv_thr", "1.0d-8")),
        mixing_beta=qe_tpl.get("mixing_beta", 0.7),
    )
    text = text.replace("calculation = 'scf'", f"calculation = '{kind}'")
    ions = "&IONS\n  ion_dynamics = 'bfgs'\n/\n"
    cell = "&CELL\n  cell_dynamics = 'bfgs'\n  press = 0.0\n/\n" if kind == "vc-relax" else ""
    if "CELL_PARAMETERS" in text and "&IONS" not in text:
        text = text.replace("CELL_PARAMETERS", ions + cell + "CELL_PARAMETERS", 1)
    text = re.sub(r"outdir\s*=\s*'[^']*'", f"outdir = '{outdir}'", text, count=1, flags=re.IGNORECASE)

    fname = "vc_relax.in" if kind == "vc-relax" else "relax.in"
    dest = job / "qe" / fname
    dest.write_text(text, encoding="utf-8")
    meta["steps"][f"{kind}_prepare"] = {
        "ok": True,
        "file": f"qe/{fname}",
        "outdir": str(outdir),
        "note": f"Optimisation {kind} — sorties dans outputs/{mat}/optimisation/",
    }
    _save_meta(job, meta)
    return {"ok": True, "file": f"qe/{fname}", "kind": kind, "outdir": str(outdir)}


def run_relax(job_id: str, *, kind: str = "vc-relax", save_to_inputs: bool = True) -> dict:
    """Lance relax ou vc-relax ; publie SCF optimisé dans inputs/ et outputs/."""
    from qe_parser import build_pw_scf_input, parse_qe_scf_template
    from config import INPUTS, OUTPUTS
    from materials import _safe_name, publish_job_to_outputs

    kind = "vc-relax" if kind.lower() in {"vc-relax", "vcrelax", "vc_relax"} else "relax"
    tools = detect_tools()
    if not tools.get("pw_x"):
        return {"ok": False, "error": "pw.x introuvable.", "tools": tools}
    job = _job_dir(job_id)
    fname = "vc_relax.in" if kind == "vc-relax" else "relax.in"
    inp = job / "qe" / fname
    if not inp.exists():
        prep = prepare_relax(job_id, kind=kind)
        if not prep.get("ok"):
            return prep
    out = job / "qe" / fname.replace(".in", ".out")
    log = LOGS / f"{job_id}_{kind.replace('-', '')}.log"
    try:
        with out.open("w", encoding="utf-8") as fout, log.open("w", encoding="utf-8") as flog:
            proc = subprocess.run(
                [tools["pw_x"], "-in", str(inp)],
                cwd=str(job / "qe"),
                stdout=fout,
                stderr=flog,
                timeout=int(os.environ.get("QE_TIMEOUT", "7200")),
                check=False,
            )
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"{kind} : timeout"}

    if proc.returncode != 0:
        return {"ok": False, "error": f"{kind} échoué (rc={proc.returncode})", "log": str(log.name)}

    try:
        atoms = read(str(out), format="espresso-out")
    except Exception as exc:
        return {"ok": False, "error": f"Lecture sortie impossible : {exc}"}

    write(str(job / "structure.cif"), atoms)
    meta = _load_meta(job)
    mat = _safe_name(meta.get("material") or atoms.get_chemical_formula() or "material")
    meta["material"] = mat

    qe_tpl = {}
    if (job / "qe_params.json").is_file():
        qe_tpl = json.loads((job / "qe_params.json").read_text(encoding="utf-8"))
    kd, pseudo_map, mass_map = [], qe_tpl.get("pseudo_map") or {}, qe_tpl.get("mass_map") or {}
    for s in atoms.get_chemical_symbols():
        if s not in kd:
            kd.append(s)
    species = [
        {"symbol": s, "mass": float(mass_map.get(s, _mass(s))), "pseudo": pseudo_map.get(s, f"{s}.UPF")}
        for s in kd
    ]
    positions = [
        {"symbol": s, "x": float(f[0]), "y": float(f[1]), "z": float(f[2]), "unit": "crystal"}
        for s, f in zip(atoms.get_chemical_symbols(), atoms.get_scaled_positions())
    ]
    scf_text = build_pw_scf_input(
        prefix=mat,
        species=species,
        positions=positions,
        cell=atoms.cell.array.tolist(),
        ecutwfc=float(qe_tpl.get("ecutwfc", 60.0)),
        ecutrho=float(qe_tpl.get("ecutrho", 480.0)),
        kpoints=tuple(qe_tpl.get("kpoints") or (8, 8, 8)),
        pseudo_dir="../pseudos",
        occupations=qe_tpl.get("occupations") or "smearing",
        smearing=qe_tpl.get("smearing") or "cold",
        degauss=qe_tpl.get("degauss", 0.02),
        conv_thr=str(qe_tpl.get("conv_thr", "1.0d-8")),
        mixing_beta=qe_tpl.get("mixing_beta", 0.7),
    )
    (job / "qe" / "reference_scf.in").write_text(scf_text, encoding="utf-8")
    saved_name = f"{mat}-scf.in"
    saved_rel = f"{mat}/{saved_name}"
    if save_to_inputs:
        mat_in = INPUTS / mat
        mat_in.mkdir(parents=True, exist_ok=True)
        (mat_in / saved_name).write_text(scf_text, encoding="utf-8")
    # copie aussi dans outputs/<mat>/optimisation/
    opt_dir = OUTPUTS / mat / "optimisation"
    opt_dir.mkdir(parents=True, exist_ok=True)
    (opt_dir / saved_name).write_text(scf_text, encoding="utf-8")
    shutil.copy2(out, opt_dir / out.name)

    import_scf_input(job_id, "reference_scf.in", scf_text.encode("utf-8"))
    meta = _load_meta(job)
    meta["material"] = mat
    meta["steps"][kind] = {"ok": True, "rc": proc.returncode, "saved_input": saved_rel}
    _save_meta(job, meta)
    publish_job_to_outputs(job_id, mat)
    return {
        "ok": True,
        "kind": kind,
        "material": mat,
        "saved_input": saved_rel,
        "outputs_dir": f"outputs/{mat}/optimisation",
        "message": f"{kind} terminé. SCF → inputs/{saved_rel} et outputs/{mat}/optimisation/",
    }


def prepare_vc_relax(job_id: str) -> dict:
    return prepare_relax(job_id, kind="vc-relax")


def run_vc_relax(job_id: str, *, save_to_inputs: bool = True) -> dict:
    return run_relax(job_id, kind="vc-relax", save_to_inputs=save_to_inputs)


def deposit_input_to_library(filename: str, content: bytes) -> dict:
    """Dépose un SCF dans inputs/ (bibliothèque autonome)."""
    from config import INPUTS
    safe = Path(filename).name
    if not safe.endswith(".in"):
        safe = f"{safe}.in"
    INPUTS.mkdir(parents=True, exist_ok=True)
    dest = INPUTS / safe
    dest.write_bytes(content)
    return {"ok": True, "name": safe, "path": f"inputs/{safe}"}



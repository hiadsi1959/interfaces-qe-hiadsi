"""Estimation indicative du temps de calcul QE → alm → anphon.

Calibrée sur des runs locaux Si (ecut≈60, k≈4³, ~2 atomes/mail) :
  ~50 s / config pw.x ; alm < 1 min ; phonons ~quelques s ; RTA ~1–few min (petit mesh).
Ce n'est PAS une prédiction exacte — ordres de grandeur pour planifier.
"""
from __future__ import annotations

from typing import Any


def _fmt_seconds(sec: float) -> str:
    sec = max(0, int(round(sec)))
    if sec < 60:
        return f"{sec} s"
    m, s = divmod(sec, 60)
    if m < 60:
        return f"{m} min {s:02d} s" if s else f"{m} min"
    h, m = divmod(m, 60)
    return f"{h} h {m:02d} min"


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def estimate_runtime(
    *,
    nat_prim: int = 2,
    nx: int = 1,
    ny: int = 1,
    nz: int = 1,
    n_patterns: int = 12,
    max_jobs: int | None = None,
    ecutwfc: float = 60.0,
    kpoints_force: tuple[int, int, int] = (4, 4, 4),
    norder: int = 1,
    anphon_mode: str = "phonons",
    kmesh: tuple[int, int, int] = (10, 10, 10),
    tmin: float = 0.0,
    tmax: float = 1000.0,
    dt: float = 50.0,
) -> dict[str, Any]:
    nat_prim = max(1, int(nat_prim))
    nx, ny, nz = max(1, int(nx)), max(1, int(ny)), max(1, int(nz))
    nat = nat_prim * nx * ny * nz
    n_patterns = max(1, int(n_patterns))
    n_qe = n_patterns if max_jobs is None else max(1, min(n_patterns, int(max_jobs)))
    ecutwfc = max(10.0, float(ecutwfc))
    kx, ky, kz = (max(1, int(k)) for k in kpoints_force)
    n_k = kx * ky * kz
    norder = max(1, min(4, int(norder)))
    mode = (anphon_mode or "phonons").lower()
    mkx, mky, mkz = (max(1, int(k)) for k in kmesh)
    n_q = mkx * mky * mkz
    n_T = max(1, int(round((float(tmax) - float(tmin)) / max(1e-9, float(dt)))) + 1)

    # Référence : Si2, ecut=60, k=4³ → ~50 s / SCF
    t_ref = 50.0
    scale_nat = (nat / 2.0) ** 2.2
    scale_k = n_k / 64.0
    scale_ecut = (ecutwfc / 60.0) ** 1.5
    t_one_scf = t_ref * scale_nat * scale_k * scale_ecut
    t_one_scf = _clamp(t_one_scf, 5.0, 6 * 3600.0)
    t_qe = t_one_scf * n_qe

    # alm : rapide ; croît avec nat et NORDER
    t_alm = 2.0 + 0.05 * nat * (norder ** 2) + 0.02 * n_qe * nat
    t_alm = _clamp(t_alm, 1.0, 30 * 60.0)

    # anphon
    if mode in {"rta", "bte"}:
        # RTA ~ O(N_q²) grossier + modes ~ 3*nat
        t_anphon = 8.0 + 0.002 * (n_q ** 2) * max(1, 3 * nat) * (0.3 + 0.05 * n_T)
        if norder < 2:
            note_rta = "RTA nécessite en pratique des IFC cubiques (NORDER≥2)."
        else:
            note_rta = ""
    else:
        # dispersion / chemin k : quelques secondes à ~1 min
        t_anphon = 3.0 + 0.02 * nat * 120
        note_rta = ""
    t_anphon = _clamp(t_anphon, 2.0, 24 * 3600.0)

    t_scf = 5.0  # chargement / use-input
    t_supercell = _clamp(3.0 + 0.02 * nat * n_patterns, 2.0, 5 * 60.0)
    t_dfset = _clamp(2.0 + 0.05 * n_qe, 1.0, 60.0)
    t_publish = 5.0
    t_overhead = t_scf + t_supercell + t_dfset + t_publish
    total = t_qe + t_alm + t_anphon + t_overhead
    # Intervalle d'incertitude (~ facteur 0.5 – 2)
    total_lo = total * 0.5
    total_hi = total * 2.0

    steps = [
        {
            "id": "scf",
            "card": "scf",
            "label": "SCF / import",
            "seconds": t_scf,
            "human": _fmt_seconds(t_scf),
            "detail": "Chargement de l'input matériau",
        },
        {
            "id": "supercell",
            "card": "supercell",
            "label": f"Supercellules ({nx}×{ny}×{nz})",
            "seconds": t_supercell,
            "human": _fmt_seconds(t_supercell),
            "detail": f"{n_patterns} motifs · nat={nat}",
        },
        {
            "id": "qe",
            "card": "forces",
            "label": f"Forces QE (pw.x × {n_qe})",
            "seconds": t_qe,
            "human": _fmt_seconds(t_qe),
            "detail": f"~{_fmt_seconds(t_one_scf)} / config · nat={nat} · k={kx}×{ky}×{kz} · ecut={ecutwfc:g}",
            "per_config_human": _fmt_seconds(t_one_scf),
        },
        {
            "id": "dfset",
            "card": "forces",
            "label": "DFSET",
            "seconds": t_dfset,
            "human": _fmt_seconds(t_dfset),
            "detail": "Assemblage déplacements / forces",
        },
        {
            "id": "alm",
            "card": "alm",
            "label": f"alm (NORDER={norder})",
            "seconds": t_alm,
            "human": _fmt_seconds(t_alm),
            "detail": "Ajustement IFC",
        },
        {
            "id": "anphon",
            "card": "anphon",
            "label": f"anphon ({mode})",
            "seconds": t_anphon,
            "human": _fmt_seconds(t_anphon),
            "detail": (
                f"mesh q={mkx}×{mky}×{mkz}" + (f" · {n_T} T" if mode in {"rta", "bte"} else " · bande")
            ),
        },
        {
            "id": "publish",
            "card": "anphon",
            "label": "Export / fiche",
            "seconds": t_publish,
            "human": _fmt_seconds(t_publish),
            "detail": "Publication vers outputs/",
        },
    ]

    # Badges par carte UI (somme si plusieurs sous-étapes sur la même carte)
    cards: dict[str, dict[str, Any]] = {}
    for s in steps:
        key = s["card"]
        slot = cards.setdefault(
            key,
            {"card": key, "seconds": 0.0, "parts": [], "detail": ""},
        )
        slot["seconds"] += float(s["seconds"])
        slot["parts"].append(f"{s['label']}: {s['human']}")
        if s["id"] == "qe":
            slot["detail"] = s["detail"]
            slot["per_config_human"] = s.get("per_config_human")
    for slot in cards.values():
        slot["human"] = _fmt_seconds(slot["seconds"])

    return {
        "ok": True,
        "calibrated_on": "Si local (ecut≈60, k≈4³, ~50 s/SCF)",
        "disclaimer": "Estimation indicative (± facteur ~2). Dépend du CPU, OpenMP, disque.",
        "inputs": {
            "nat_prim": nat_prim,
            "supercell": [nx, ny, nz],
            "nat": nat,
            "n_patterns": n_patterns,
            "n_qe": n_qe,
            "ecutwfc": ecutwfc,
            "kpoints_force": [kx, ky, kz],
            "norder": norder,
            "anphon_mode": mode,
            "kmesh": [mkx, mky, mkz],
            "n_T": n_T,
        },
        "steps": steps,
        "cards": cards,
        "total_seconds": total,
        "total_human": _fmt_seconds(total),
        "range_human": f"{_fmt_seconds(total_lo)} – {_fmt_seconds(total_hi)}",
        "note": note_rta,
    }

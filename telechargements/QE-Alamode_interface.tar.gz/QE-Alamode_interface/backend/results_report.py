"""Collecte des grandeurs physiques et génération de la fiche technique."""
from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path

from alamode_io import parse_kappa_file


def _read(path: Path) -> str:
    if not path.is_file():
        return ""
    return path.read_text(encoding="utf-8", errors="replace")


def _first(alamode: Path, pattern: str) -> Path | None:
    hits = sorted(alamode.glob(pattern))
    return hits[0] if hits else None


def parse_alm_log(text: str) -> dict:
    out: dict = {}
    m = re.search(r"NORDER\s*=\s*(\d+)", text)
    if m:
        out["norder"] = int(m.group(1))
    m = re.search(r"Total Number of Parameters\s*:\s*(\d+)", text)
    if m:
        out["n_parameters"] = int(m.group(1))
    m = re.search(r"Total Number of Free Parameters\s*:\s*(\d+)", text)
    if m:
        out["n_free_parameters"] = int(m.group(1))
    m = re.search(r"Residual sum of squares[^:]*:\s*([0-9.eE+-]+)", text)
    if m:
        out["rss"] = float(m.group(1))
    m = re.search(r"Fitting error\s*\(%\)\s*:\s*([0-9.eE+-]+)", text)
    if m:
        out["fitting_error_pct"] = float(m.group(1))
    m = re.search(r"PREFIX\s*=\s*(\S+)", text)
    if m:
        out["prefix"] = m.group(1)
    return out


def parse_fcs_summary(text: str) -> dict:
    """Résumé des IFC du bloc Index (FC2, FC3, …)."""
    orders: dict[str, list[dict]] = {}
    current = None
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("*FC"):
            current = s.lstrip("*").split()[0]
            orders.setdefault(current, [])
            continue
        if current and re.match(r"^\d+\s+\d+\s+", s):
            parts = s.split()
            if len(parts) >= 3:
                try:
                    val = float(parts[2])
                except ValueError:
                    continue
                dist = None
                if len(parts) >= 6:
                    try:
                        dist = float(parts[-1])
                    except ValueError:
                        dist = None
                orders[current].append({"value": val, "distance_bohr": dist})
    summary = {}
    for order, rows in orders.items():
        if not rows:
            continue
        vals = [r["value"] for r in rows]
        summary[order] = {
            "n_terms": len(rows),
            "max_abs": max(abs(v) for v in vals),
            "min": min(vals),
            "max": max(vals),
            "terms": rows[:12],
        }
    return summary


def parse_bands(path: Path) -> dict:
    if not path.is_file():
        return {}
    labels: list[str] = []
    ticks: list[float] = []
    rows: list[list[float]] = []
    for i, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines()):
        if not line.strip():
            continue
        if line.startswith("#"):
            body = line.lstrip("#").strip()
            if i == 0 and any(c.isalpha() for c in body):
                labels = body.split()
            elif i == 1:
                try:
                    ticks = [float(x) for x in body.split()]
                except ValueError:
                    pass
            continue
        parts = line.split()
        try:
            rows.append([float(x) for x in parts])
        except ValueError:
            continue
    if not rows:
        return {}
    nmodes = len(rows[0]) - 1
    gamma = rows[0][1:]
    all_w = [w for r in rows for w in r[1:]]
    # échantillon pour le graphe (≤ 200 points)
    step = max(1, len(rows) // 200)
    series = []
    for m in range(nmodes):
        series.append(
            {
                "mode": m + 1,
                "k": [rows[i][0] for i in range(0, len(rows), step)],
                "omega": [rows[i][m + 1] for i in range(0, len(rows), step)],
            }
        )
    return {
        "n_k": len(rows),
        "n_modes": nmodes,
        "path_labels": labels,
        "path_ticks": ticks,
        "omega_gamma_cm1": gamma,
        "omega_min_cm1": min(all_w),
        "omega_max_cm1": max(all_w),
        "omega_lo_gamma_cm1": max(gamma) if gamma else None,
        "n_imaginary": sum(1 for w in all_w if w < -1e-3),
        "series": series,
    }


def _param(id_: str, label: str, value, unit: str = "", status: str = "ok", note: str = "") -> dict:
    return {
        "id": id_,
        "label": label,
        "value": value,
        "unit": unit,
        "status": status,  # ok | pending | na
        "note": note,
    }


def collect_results(job: Path, meta: dict | None = None) -> dict:
    meta = meta or {}
    alamode = job / "alamode"
    results_dir = job / "results"
    results_dir.mkdir(parents=True, exist_ok=True)

    alm_log = _read(alamode / "alm_optimize.log")
    alm_info = parse_alm_log(alm_log)

    fcs_path = _first(alamode, "*.fcs")
    fcs_info = parse_fcs_summary(_read(fcs_path)) if fcs_path else {}

    bands_path = _first(alamode, "*.bands")
    bands_info = parse_bands(bands_path) if bands_path else {}

    kappa_rows = meta.get("kappa") or []
    kappa_file = None
    if not kappa_rows:
        cands = (
            sorted(alamode.glob("*kappa*"))
            + sorted(alamode.glob("*.kl"))
            + sorted(results_dir.glob("*kappa*"))
            + sorted(results_dir.glob("*.kl"))
        )
        for cand in cands:
            kappa_rows = parse_kappa_file(cand)
            if kappa_rows:
                kappa_file = cand.name
                break
    else:
        kappa_file = "meta.kappa"

    xml_path = _first(alamode, "*.xml")
    dfset = alamode / "DFSET"
    n_dfset = 0
    if dfset.is_file():
        n_dfset = sum(1 for line in dfset.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip())

    struct = meta.get("structure") or {}
    sc = meta.get("supercell") or {}
    steps = meta.get("steps") or {}

    # κ résumé
    kappa_summary = {}
    if kappa_rows:
        mid = kappa_rows[len(kappa_rows) // 2]
        kappa_summary = {
            "n_points": len(kappa_rows),
            "T_min": kappa_rows[0]["T"],
            "T_max": kappa_rows[-1]["T"],
            "kappa_xx_mid": mid.get("kappa_xx"),
            "kappa_yy_mid": mid.get("kappa_yy"),
            "kappa_zz_mid": mid.get("kappa_zz"),
            "T_mid": mid.get("T"),
        }

    pending_rta = "Nécessite anphon MODE=rta"
    pending_thermo = "Nécessite calcul thermo / DOS anphon"
    pending_anh = "Nécessite IFC 3ᵉ ordre (NORDER≥2) + rta"

    params = [
        _param("formula", "Formule", struct.get("formula"), status="ok" if struct.get("formula") else "pending",
               note="" if struct.get("formula") else "Importer une structure"),
        _param("nat", "Nb atomes (maille)", struct.get("nat") or sc.get("nat"), status="ok" if (struct.get("nat") or sc.get("nat")) else "pending"),
        _param("supercell", "Supercellule", f"{sc.get('nx')}×{sc.get('ny')}×{sc.get('nz')}" if sc.get("nx") else None,
               status="ok" if sc.get("nx") else "pending"),
        _param("n_patterns", "Configs DFSET (lignes)", n_dfset or None, status="ok" if n_dfset else "pending"),
        _param("norder", "NORDER (IFC)", alm_info.get("norder"), status="ok" if "norder" in alm_info else "pending",
               note="1=harmonique, 2=cubique"),
        _param("n_ifc_params", "Paramètres IFC libres", alm_info.get("n_free_parameters"),
               status="ok" if "n_free_parameters" in alm_info else "pending"),
        _param("fit_err", "Erreur d’ajustement alm", alm_info.get("fitting_error_pct"), "%",
               status="ok" if "fitting_error_pct" in alm_info else "pending"),
        _param("fc2_max", "|FC2| max", (fcs_info.get("FC2") or {}).get("max_abs"), "Ry/a0²",
               status="ok" if fcs_info.get("FC2") else "pending"),
        _param("fc3_n", "Nb termes FC3", (fcs_info.get("FC3") or {}).get("n_terms"),
               status="ok" if fcs_info.get("FC3") else "pending", note="NORDER≥2"),
        _param("omega_max", "ω_max (bande)", bands_info.get("omega_max_cm1"), "cm⁻¹",
               status="ok" if bands_info else "pending"),
        _param("omega_lo", "ω_optique Γ (max)", bands_info.get("omega_lo_gamma_cm1"), "cm⁻¹",
               status="ok" if bands_info else "pending"),
        _param("n_imag", "Modes imaginaires", bands_info.get("n_imaginary"),
               status="ok" if bands_info else "pending"),
        _param("kappa_xx", f"κ_xx (T≈{kappa_summary.get('T_mid')} K)" if kappa_summary else "κ_xx(T)",
               kappa_summary.get("kappa_xx_mid"), "W/m/K",
               status="ok" if kappa_summary else "pending", note="" if kappa_summary else pending_rta),
        _param("kappa_yy", "κ_yy", kappa_summary.get("kappa_yy_mid"), "W/m/K",
               status="ok" if kappa_summary else "pending", note="" if kappa_summary else pending_rta),
        _param("kappa_zz", "κ_zz", kappa_summary.get("kappa_zz_mid"), "W/m/K",
               status="ok" if kappa_summary else "pending", note="" if kappa_summary else pending_rta),
        _param("mfp", "MFP / κ cumulé", None, "", "pending", pending_rta),
        _param("tau", "τ_q,j (temps de vie)", None, "ps", "pending", pending_anh),
        _param("gamma_line", "Γ_q,j (largeur de raie)", None, "cm⁻¹", "pending", pending_anh),
        _param("cv", "C_v(T)", None, "J/mol/K", "pending", pending_thermo),
        _param("cp", "C_p(T)", None, "J/mol/K", "pending", pending_thermo),
        _param("entropy", "S(T)", None, "J/mol/K", "pending", pending_thermo),
        _param("alpha", "α(T) dilatation", None, "K⁻¹", "pending", pending_thermo),
    ]

    files = {
        "fcs": fcs_path.name if fcs_path else None,
        "xml": xml_path.name if xml_path else None,
        "bands": bands_path.name if bands_path else None,
        "kappa": kappa_file,
        "dfset": "DFSET" if dfset.is_file() else None,
    }

    data = {
        "ok": True,
        "job_id": job.name,
        "name": meta.get("name") or job.name,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "steps_ok": {k: bool(v.get("ok")) for k, v in steps.items() if isinstance(v, dict)},
        "params": params,
        "alm": alm_info,
        "ifc": fcs_info,
        "bands": {k: v for k, v in bands_info.items() if k != "series"},
        "bands_series": bands_info.get("series") or [],
        "kappa": kappa_rows,
        "kappa_summary": kappa_summary,
        "files": files,
        "gamma_modes": [
            {"mode": i + 1, "omega_cm1": w}
            for i, w in enumerate(bands_info.get("omega_gamma_cm1") or [])
        ],
    }
    return data


def write_fiche_technique(job: Path, data: dict) -> dict:
    """Écrit fiche_technique.md/.txt et results.json."""
    results = job / "results"
    results.mkdir(parents=True, exist_ok=True)

    json_path = results / "results.json"
    json_path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    lines_md = [
        f"# Fiche technique — {data.get('name')} ({data.get('job_id')})",
        "",
        f"*Générée le {data.get('generated_at')} — QE–ALAMODE / HIADSI*",
        "",
        "## 1. Paramètres physiques",
        "",
        "| Paramètre | Valeur | Unité | Statut |",
        "|-----------|--------|-------|--------|",
    ]
    for p in data.get("params") or []:
        val = p.get("value")
        if val is None:
            val_s = "—"
        elif isinstance(val, float):
            val_s = f"{val:.6g}"
        else:
            val_s = str(val)
        st = {"ok": "calculé", "pending": "en attente", "na": "n/a"}.get(p.get("status"), p.get("status"))
        note = f" ({p['note']})" if p.get("note") and p.get("status") != "ok" else ""
        lines_md.append(f"| {p['label']} | {val_s} | {p.get('unit') or ''} | {st}{note} |")

    lines_md += ["", "## 2. Modes au point Γ", ""]
    gamma = data.get("gamma_modes") or []
    if gamma:
        lines_md += ["| Mode | ω (cm⁻¹) |", "|------|----------|"]
        for g in gamma:
            lines_md.append(f"| {g['mode']} | {g['omega_cm1']:.6g} |")
    else:
        lines_md.append("*Non disponible — lancer anphon (MODE=phonons).*")

    lines_md += ["", "## 3. Constantes de force (aperçu)", ""]
    ifc = data.get("ifc") or {}
    if ifc:
        for order, info in ifc.items():
            lines_md.append(
                f"- **{order}** : {info['n_terms']} termes · |max| = {info['max_abs']:.6g} Ry/a0ⁿ"
            )
    else:
        lines_md.append("*Non disponible — lancer alm optimize.*")

    lines_md += ["", "## 4. Conductivité thermique κ_L(T)", ""]
    kappa = data.get("kappa") or []
    if kappa:
        lines_md += ["| T (K) | κ_xx | κ_yy | κ_zz |", "|-------|------|------|------|"]
        for row in kappa:
            lines_md.append(
                f"| {row['T']:.4g} | {row.get('kappa_xx')} | {row.get('kappa_yy')} | {row.get('kappa_zz')} |"
            )
    else:
        lines_md.append("*Non disponible — lancer anphon MODE=rta.*")

    lines_md += [
        "",
        "## 5. Fichiers associés",
        "",
    ]
    for key, name in (data.get("files") or {}).items():
        if name:
            lines_md.append(f"- `{key}` : `{name}`")

    lines_md += [
        "",
        "---",
        "QE (forces DFT) → alm (IFC) → anphon (phonons / BTE). Auteur : S. Hiadsi — LMESM / USTO-MB · said.hiadsi@univ-usto.dz",
        "",
    ]

    md_path = results / "fiche_technique.md"
    md_path.write_text("\n".join(lines_md), encoding="utf-8")

    # Version texte simple
    txt_lines = [
        f"FICHE TECHNIQUE QE-ALAMODE — {data.get('name')} ({data.get('job_id')})",
        f"Date : {data.get('generated_at')}",
        "=" * 60,
        "",
        "PARAMETRES",
    ]
    for p in data.get("params") or []:
        val = p.get("value")
        val_s = "—" if val is None else (f"{val:.6g}" if isinstance(val, float) else str(val))
        unit = p.get("unit") or ""
        st = p.get("status")
        extra = f"  [{p['note']}]" if p.get("note") and st != "ok" else ""
        txt_lines.append(f"  {p['label']:<32} {val_s:>14} {unit:<10} ({st}){extra}")
    txt_lines += ["", "MODES GAMMA (cm-1)"]
    for g in gamma:
        txt_lines.append(f"  mode {g['mode']}: {g['omega_cm1']:.6g}")
    if not gamma:
        txt_lines.append("  (absent)")
    txt_lines += ["", "KAPPA"]
    if kappa:
        for row in kappa:
            txt_lines.append(
                f"  T={row['T']}: xx={row.get('kappa_xx')} yy={row.get('kappa_yy')} zz={row.get('kappa_zz')}"
            )
    else:
        txt_lines.append("  (absent — MODE=rta requis)")
    txt_lines += ["", "FICHIERS"]
    for key, name in (data.get("files") or {}).items():
        if name:
            txt_lines.append(f"  {key}: {name}")
    txt_lines.append("")

    from fiche_html import render_fiche_html

    html_path = results / "fiche_technique.html"
    html_path.write_text(render_fiche_html(data), encoding="utf-8")

    txt_path = results / "fiche_technique.txt"
    txt_path.write_text("\n".join(txt_lines), encoding="utf-8")

    return {
        "json": str(json_path.relative_to(job.parent.parent) if False else f"results/{json_path.name}"),
        "md": f"results/{md_path.name}",
        "txt": f"results/{txt_path.name}",
        "paths": {"json": json_path, "md": md_path, "txt": txt_path, "html": html_path},
        "html": f"results/{html_path.name}",
    }


def build_and_save(job: Path, meta: dict | None = None) -> dict:
    data = collect_results(job, meta)
    fiche = write_fiche_technique(job, data)
    data["fiche"] = {"md": fiche["md"], "txt": fiche["txt"], "json": fiche["json"], "html": fiche.get("html")}
    # persister résumé léger dans meta côté appelant
    return data

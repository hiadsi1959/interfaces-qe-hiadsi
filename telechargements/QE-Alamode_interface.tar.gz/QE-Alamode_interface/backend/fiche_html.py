"""Fiche technique HTML complète (tableaux + courbes SVG) pour impression PDF."""
from __future__ import annotations

import html
import json
from typing import Any


def _esc(s: Any) -> str:
    return html.escape("" if s is None else str(s))


def _fmt_val(v: Any) -> str:
    if v is None or v == "":
        return "—"
    if isinstance(v, float):
        if abs(v) >= 1e4 or (0 < abs(v) < 1e-3):
            return f"{v:.6e}"
        return f"{v:.6g}"
    return str(v)


def _svg_line_chart(
    datasets: list[dict],
    *,
    width: int = 760,
    height: int = 300,
    title: str = "",
    xlab: str = "",
    ylab: str = "",
) -> str:
    """datasets: [{label, x[], y[], color}]"""
    if not datasets:
        return f'<p class="empty">—</p>'
    pad_l, pad_r, pad_t, pad_b = 52, 18, 28, 42
    plot_w = width - pad_l - pad_r
    plot_h = height - pad_t - pad_b

    xs, ys = [], []
    for ds in datasets:
        xs.extend(ds.get("x") or [])
        ys.extend(ds.get("y") or [])
    if not xs or not ys:
        return f'<p class="empty">—</p>'

    xmin, xmax = min(xs), max(xs)
    ymin, ymax = min(ys), max(ys)
    if xmax == xmin:
        xmax = xmin + 1.0
    if ymax == ymin:
        ymax = ymin + 1.0
    yr = ymax - ymin
    ymin -= 0.05 * yr
    ymax += 0.05 * yr

    def px(x: float) -> float:
        return pad_l + (x - xmin) / (xmax - xmin) * plot_w

    def py(y: float) -> float:
        return pad_t + (ymax - y) / (ymax - ymin) * plot_h

    colors = ["#0d6e6e", "#b86b2e", "#245f78", "#5a7d2a", "#8a3d5b", "#3d5a80", "#7c3aed", "#c2410c"]
    paths = []
    legend = []
    for i, ds in enumerate(datasets):
        xarr, yarr = ds.get("x") or [], ds.get("y") or []
        if len(xarr) < 2:
            continue
        col = ds.get("color") or colors[i % len(colors)]
        pts = " ".join(f"{px(x):.2f},{py(y):.2f}" for x, y in zip(xarr, yarr))
        paths.append(f'<polyline fill="none" stroke="{col}" stroke-width="1.5" points="{pts}"/>')
        legend.append(
            f'<span class="lg"><i style="background:{col}"></i>{_esc(ds.get("label") or f"s{i+1}")}</span>'
        )

    if not paths:
        return f'<p class="empty">—</p>'

    return f"""
<figure class="chart">
  <figcaption>{_esc(title)}</figcaption>
  <svg viewBox="0 0 {width} {height}" width="100%" height="{height}" role="img">
    <rect x="{pad_l}" y="{pad_t}" width="{plot_w}" height="{plot_h}" fill="#fafcfd" stroke="#dde5ea"/>
    <line x1="{pad_l}" y1="{pad_t + plot_h}" x2="{pad_l + plot_w}" y2="{pad_t + plot_h}" stroke="#889"/>
    <line x1="{pad_l}" y1="{pad_t}" x2="{pad_l}" y2="{pad_t + plot_h}" stroke="#889"/>
    <text x="{pad_l + plot_w/2:.0f}" y="{height - 8}" text-anchor="middle" font-size="11" fill="#456">{_esc(xlab)}</text>
    <text transform="translate(14,{pad_t + plot_h/2:.0f}) rotate(-90)" text-anchor="middle" font-size="11" fill="#456">{_esc(ylab)}</text>
    {''.join(paths)}
  </svg>
  <div class="legend">{''.join(legend)}</div>
</figure>"""


def render_fiche_html(data: dict, *, auto_print: bool = False) -> str:
    """Fiche technique complète : grandeurs, tableaux, courbes (SVG)."""
    job_id = data.get("job_id") or ""
    name = data.get("name") or job_id
    title = f"Fiche technique — {name} ({job_id})"

    # —— Paramètres (tous) ——
    param_rows = []
    for p in data.get("params") or []:
        st = p.get("status") or ""
        cls = "ok" if st == "ok" else "pending"
        note = f"<br/><small>{_esc(p.get('note'))}</small>" if p.get("note") and st != "ok" else ""
        val = _fmt_val(p.get("value")) if st == "ok" else "—"
        param_rows.append(
            f'<tr class="{cls}"><td>{_esc(p.get("label"))}</td><td>{val}{note}</td>'
            f'<td>{_esc(p.get("unit") or "")}</td><td>{_esc(st)}</td></tr>'
        )

    # —— Modes Γ ——
    gamma_rows = []
    for g in data.get("gamma_modes") or []:
        w = g.get("omega_cm1", 0)
        kind = "acoustique" if abs(w) < 1e-2 else "optique"
        gamma_rows.append(
            f"<tr><td>{g.get('mode')}</td><td>{_fmt_val(w)}</td><td>{kind}</td></tr>"
        )

    # —— IFC ——
    ifc_rows = []
    for order, info in (data.get("ifc") or {}).items():
        ifc_rows.append(
            f"<tr><td>{_esc(order)}</td><td>{info.get('n_terms', '—')}</td>"
            f"<td>{_fmt_val(info.get('max_abs'))}</td>"
            f"<td>{_fmt_val(info.get('min'))}</td><td>{_fmt_val(info.get('max'))}</td></tr>"
        )

    # —— κ table ——
    kappa = data.get("kappa") or []
    kappa_rows = [
        f"<tr><td>{_fmt_val(r.get('T'))}</td><td>{_fmt_val(r.get('kappa_xx'))}</td>"
        f"<td>{_fmt_val(r.get('kappa_yy'))}</td><td>{_fmt_val(r.get('kappa_zz'))}</td></tr>"
        for r in kappa
    ]

    # —— Courbes ——
    band_datasets = []
    for s in data.get("bands_series") or []:
        band_datasets.append({
            "label": f"mode {s.get('mode')}",
            "x": s.get("k") or [],
            "y": s.get("omega") or [],
        })
    bands_svg = _svg_line_chart(
        band_datasets, title="Dispersion phonons", xlab="q (chemin réduit)", ylab="ω (cm⁻¹)"
    )

    kappa_datasets = []
    if kappa:
        T = [r.get("T") for r in kappa]
        kappa_datasets = [
            {"label": "κ_xx", "x": T, "y": [r.get("kappa_xx") for r in kappa], "color": "#0d6e6e"},
            {"label": "κ_yy", "x": T, "y": [r.get("kappa_yy") for r in kappa], "color": "#b86b2e"},
            {"label": "κ_zz", "x": T, "y": [r.get("kappa_zz") for r in kappa], "color": "#245f78"},
        ]
    kappa_svg = _svg_line_chart(
        kappa_datasets, title="Conductivité thermique κ_L(T)", xlab="T (K)", ylab="κ (W/m/K)"
    )

    # —— Étapes ——
    steps = data.get("steps_ok") or {}
    step_rows = "".join(
        f"<tr><td>{_esc(k)}</td><td>{'OK' if v else '—'}</td></tr>" for k, v in sorted(steps.items())
    )

    # —— Fichiers ——
    files = data.get("files") or {}
    file_rows = "".join(
        f"<tr><td>{_esc(k)}</td><td><code>{_esc(v)}</code></td></tr>" for k, v in files.items() if v
    )

    print_js = "window.addEventListener('load',()=>setTimeout(()=>window.print(),400));" if auto_print else ""

    return f"""<!DOCTYPE html>
<html lang="fr"><head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>{_esc(title)}</title>
<style>
:root {{ --ink:#0f1c24; --teal:#0d6e6e; --line:#dde5ea; }}
* {{ box-sizing:border-box; }}
body {{ font-family:"Source Sans 3",Segoe UI,sans-serif; max-width:900px; margin:0 auto; padding:1.5rem 1.25rem 2rem;
  color:var(--ink); line-height:1.45; background:#f4f7f9; }}
h1 {{ font-family:Georgia,serif; font-size:1.55rem; margin:0 0 .35rem; color:var(--teal); }}
.meta {{ color:#456; font-size:.92rem; margin-bottom:1.2rem; }}
h2 {{ font-size:1.12rem; margin:1.6rem 0 .55rem; padding-bottom:.3rem; border-bottom:2px solid var(--teal); }}
table {{ width:100%; border-collapse:collapse; margin:.5rem 0 1rem; font-size:.92rem; background:#fff; }}
th,td {{ text-align:left; padding:.45rem .5rem; border-bottom:1px solid var(--line); }}
th {{ font-size:.78rem; text-transform:uppercase; color:#567; background:#eef4f6; }}
tr.pending td {{ color:#8a4b16; }}
.chart {{ margin:1rem 0; background:#fff; border:1px solid var(--line); border-radius:4px; padding:.75rem; }}
.chart figcaption {{ font-weight:700; margin-bottom:.5rem; color:var(--teal); }}
.legend {{ display:flex; flex-wrap:wrap; gap:.65rem; margin-top:.45rem; font-size:.82rem; }}
.legend .lg i {{ display:inline-block; width:14px; height:3px; margin-right:4px; vertical-align:middle; }}
.empty {{ color:#789; font-style:italic; }}
.noprint {{ margin-bottom:1rem; }}
.noprint a, .noprint button {{ display:inline-block; margin-right:.5rem; padding:.45rem .85rem;
  background:var(--teal); color:#fff; text-decoration:none; border:none; border-radius:4px; cursor:pointer; font-size:.9rem; }}
@media print {{
  body {{ background:#fff; padding:0; max-width:none; }}
  .noprint {{ display:none !important; }}
  .chart {{ break-inside:avoid; page-break-inside:avoid; }}
  h2 {{ break-after:avoid; }}
}}
</style>
</head><body>
<div class="noprint">
  <a href="javascript:window.print()">Imprimer / Enregistrer en PDF</a>
  <button type="button" onclick="history.back()">Retour</button>
</div>
<h1>{_esc(title)}</h1>
<p class="meta">Générée le {_esc(data.get('generated_at'))} · QE–ALAMODE · S. Hiadsi — LMESM / USTO-MB · <a href="mailto:said.hiadsi@univ-usto.dz">said.hiadsi@univ-usto.dz</a></p>

<h2>1 · Grandeurs calculées</h2>
<table>
<thead><tr><th>Paramètre</th><th>Valeur</th><th>Unité</th><th>Statut</th></tr></thead>
<tbody>{''.join(param_rows) or '<tr><td colspan="4">Aucune donnée</td></tr>'}</tbody>
</table>

<h2>2 · Modes au point Γ</h2>
<table>
<thead><tr><th>Mode</th><th>ω (cm⁻¹)</th><th>Type</th></tr></thead>
<tbody>{''.join(gamma_rows) or '<tr><td colspan="3">— (lancer anphon MODE=phonons)</td></tr>'}</tbody>
</table>

<h2>3 · Constantes de force (IFC)</h2>
<table>
<thead><tr><th>Ordre</th><th>Nb termes</th><th>|max|</th><th>min</th><th>max</th></tr></thead>
<tbody>{''.join(ifc_rows) or '<tr><td colspan="5">— (lancer alm)</td></tr>'}</tbody>
</table>

<h2>4 · Dispersion phonons</h2>
{bands_svg if band_datasets else '<p class="empty">Courbe non disponible — lancer anphon MODE=phonons.</p>'}

<h2>5 · Conductivité thermique κ<sub>L</sub>(T)</h2>
{kappa_svg if kappa else '<p class="empty">Courbe non disponible — lancer anphon MODE=rta (NORDER≥2 pour production).</p>'}
<table>
<thead><tr><th>T (K)</th><th>κ_xx</th><th>κ_yy</th><th>κ_zz</th></tr></thead>
<tbody>{''.join(kappa_rows) or '<tr><td colspan="4">—</td></tr>'}</tbody>
</table>

<h2>6 · Étapes du workflow</h2>
<table><thead><tr><th>Étape</th><th>Statut</th></tr></thead><tbody>{step_rows or '<tr><td colspan="2">—</td></tr>'}</tbody></table>

<h2>7 · Fichiers associés</h2>
<table><thead><tr><th>Type</th><th>Fichier</th></tr></thead><tbody>{file_rows or '<tr><td colspan="2">—</td></tr>'}</tbody></table>

<p class="meta">QE (forces) → alm (IFC) → anphon (phonons / BTE) · Interface autonome QE–ALAMODE</p>
<script>{print_js}</script>
</body></html>"""

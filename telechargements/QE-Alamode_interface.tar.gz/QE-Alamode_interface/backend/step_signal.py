"""Signal de fin d'étape — permet de relancer manuellement l'étape suivante."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any

from config import WORK, ROOT

# Chaîne recommandée : étape terminée → prochaine action UI / CLI
STEP_CHAIN: dict[str, dict[str, str]] = {
    "import": {
        "label": "SCF / import",
        "next": "supercell",
        "next_label": "Supercellules",
        "hint": "Étape suivante : générer les supercellules (bouton Run · carte 2).",
    },
    "supercell": {
        "label": "Supercellules",
        "next": "qe_forces",
        "next_label": "Forces QE (pw.x)",
        "hint": "Étape suivante : lancer pw.x sur les motifs (bouton Run pw.x · carte 3).",
    },
    "qe_forces": {
        "label": "Forces QE",
        "next": "dfset",
        "next_label": "DFSET",
        "hint": "Étape suivante : construire le DFSET (bouton DFSET · carte 3).",
    },
    "qe_config": {
        "label": "Config QE",
        "next": "qe_forces",
        "next_label": "Forces QE (suite)",
        "hint": "Une config pw.x est terminée. Les autres peuvent encore tourner.",
    },
    "dfset": {
        "label": "DFSET",
        "next": "alm_prepare",
        "next_label": "alm prepare",
        "hint": "Étape suivante : préparer alm (bouton Prepare · carte 4, NORDER=2 pour κ_L).",
    },
    "alm_prepare": {
        "label": "alm prepare",
        "next": "alm_run",
        "next_label": "alm run",
        "hint": "Étape suivante : exécuter alm (bouton Run · carte 4).",
    },
    "alm_optimize": {
        "label": "alm optimize",
        "next": "anphon_prepare",
        "next_label": "anphon phonons",
        "hint": "Étape suivante : préparer anphon en mode phonons (carte 5).",
    },
    "alm_run": {
        "label": "alm",
        "next": "anphon_prepare",
        "next_label": "anphon phonons",
        "hint": "Étape suivante : préparer anphon en mode phonons (carte 5).",
    },
    "anphon_prepare": {
        "label": "anphon prepare",
        "next": "anphon_run",
        "next_label": "anphon run",
        "hint": "Étape suivante : lancer anphon (bouton Run · carte 5).",
    },
    "anphon": {
        "label": "anphon",
        "next": "publish",
        "next_label": "Export / résultats",
        "hint": "Étape suivante : exporter les résultats (bouton Export) ou lancer RTA (mode rta) si κ_L.",
    },
    "anphon_phonons": {
        "label": "anphon phonons",
        "next": "anphon_rta",
        "next_label": "anphon RTA (κ_L)",
        "hint": "Phonons OK. Pour κ_L : mode rta puis Prepare + Run · ou Export si fini.",
    },
    "anphon_rta": {
        "label": "anphon RTA",
        "next": "publish",
        "next_label": "Export / résultats",
        "hint": "κ_L calculé. Étape suivante : Export → outputs/<matériau>/ puis page Résultats.",
    },
    "publish": {
        "label": "Export",
        "next": "terminé",
        "next_label": "Terminé",
        "hint": "Pipeline publié. Consultez la page Résultats et outputs/<matériau>/.",
    },
    "terminé": {
        "label": "Terminé",
        "next": "terminé",
        "next_label": "—",
        "hint": "Toutes les étapes sont terminées.",
    },
}


def _job_dir(job_id: str) -> Path:
    return WORK / job_id


def signal_paths(job_id: str) -> dict[str, Path]:
    job = _job_dir(job_id)
    return {
        "json": job / "etape_signal.json",
        "ready": job / "READY_NEXT_STEP",
        "progress": job / "progress.json",
        "log": ROOT / "logs" / f"{job_id}_etapes.log",
    }


def emit_step_signal(
    job_id: str,
    step: str,
    *,
    ok: bool = True,
    message: str = "",
    detail: dict[str, Any] | None = None,
    next_step: str | None = None,
    next_label: str | None = None,
    hint: str | None = None,
    notify: bool = True,
    awaiting_user: bool | None = None,
    state: str | None = None,
) -> dict[str, Any]:
    """Écrit le signal de fin d'étape (fichier + progress + notify-send)."""
    chain = STEP_CHAIN.get(step, {})
    nxt = next_step or chain.get("next", "")
    nxt_label = next_label or chain.get("next_label", nxt)
    text_hint = hint or chain.get("hint", "Étape terminée — vous pouvez lancer la suivante.")
    label = chain.get("label", step)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    wait = bool(ok) if awaiting_user is None else bool(awaiting_user)

    payload: dict[str, Any] = {
        "job_id": job_id,
        "ok": bool(ok),
        "step": step,
        "step_label": label,
        "finished_at": now,
        "awaiting_user": wait,
        "next_step": nxt,
        "next_label": nxt_label,
        "hint": text_hint,
        "message": message or (f"{label} terminé." if ok else f"{label} en échec / interrompu."),
        "acked": False,
        "detail": detail or {},
        "state": state or ("ok" if ok else "failed"),
    }

    paths = signal_paths(job_id)
    paths["json"].parent.mkdir(parents=True, exist_ok=True)
    paths["json"].write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    if wait:
        tag = "READY" if ok else "INTERRUPTED"
        paths["ready"].write_text(
            f"{tag}\njob={job_id}\nstep={step}\nnext={nxt}\nnext_label={nxt_label}\n"
            f"at={now}\n\n{text_hint}\n",
            encoding="utf-8",
        )
    elif paths["ready"].exists():
        paths["ready"].unlink()

    # progress.json (phase = awaiting:<next>)
    prog: dict[str, Any] = {}
    if paths["progress"].is_file():
        try:
            prog = json.loads(paths["progress"].read_text(encoding="utf-8"))
        except Exception:
            prog = {}
    prog.update(
        {
            "job_id": job_id,
            "updated": now,
            "phase": f"awaiting:{nxt}" if ok else f"failed:{step}",
            "current": payload["message"],
            "step_done": step,
            "next_step": nxt,
            "awaiting_user": bool(ok),
            "hint": text_hint,
        }
    )
    paths["progress"].write_text(json.dumps(prog, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    # journal append
    paths["log"].parent.mkdir(parents=True, exist_ok=True)
    with paths["log"].open("a", encoding="utf-8") as fh:
        fh.write(f"[{now}] {'OK' if ok else 'FAIL'} {step} → next={nxt} | {text_hint}\n")

    banner = (
        f"\n{'=' * 60}\n"
        f"  SIGNAL ÉTAPE — job {job_id}\n"
        f"  {'OK' if ok else 'ÉCHEC'} : {label} ({step})\n"
        f"  Suivant : {nxt_label} ({nxt})\n"
        f"  {text_hint}\n"
        f"  Fichier : work/{job_id}/READY_NEXT_STEP\n"
        f"{'=' * 60}\n"
    )
    print(banner, flush=True)

    if notify and ok and os.environ.get("QEALAMODE_NOTIFY", "1") != "0":
        _desktop_notify(
            title=f"QE–ALAMODE · {label} terminé",
            body=f"{job_id}\n→ {nxt_label}\n{text_hint}",
        )

    return payload


def read_step_signal(job_id: str) -> dict[str, Any] | None:
    path = signal_paths(job_id)["json"]
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _qe_job_done(out: Path) -> bool:
    try:
        return "JOB DONE" in out.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return False


def _is_compute_cmd(cmd: str) -> bool:
    """True seulement pour un vrai process de calcul (pas un shell/sandbox qui cite le chemin)."""
    if not cmd:
        return False
    low = cmd.lower()
    if any(x in low for x in ("cursorsandbox", "sandbox-policy", "cursor/resources", "/bin/bash -o extglob")):
        return False
    # binaires / scripts de calcul
    markers = ("/pw.x", " pw.x ", "pw.x -in", "/alm ", " alm ", "/anphon", " anphon ", "resume_job.sh", "complete_pipeline.sh")
    return any(m in low or m.strip() in low for m in markers) or low.rstrip().endswith("pw.x")


def _proc_running_for_job(job_id: str) -> list[str]:
    """Retourne les process liés au job (pw.x / alm / anphon) s'ils tournent."""
    job_token = f"work/{job_id}"
    found: list[str] = []
    try:
        out = subprocess.check_output(["ps", "-eo", "args"], text=True, timeout=5)
        for line in out.splitlines():
            if job_token not in line:
                continue
            if not _is_compute_cmd(line):
                continue
            found.append(line.strip()[:160])
    except Exception:
        pass
    return found


def compute_pipeline_status(job_id: str) -> dict[str, Any]:
    """Où en est le job : étape courante, suivante, running / interrompu / en attente."""
    job = _job_dir(job_id)
    if not job.is_dir():
        return {"ok": False, "error": "Job inconnu"}

    meta: dict[str, Any] = {}
    meta_path = job / "meta.json"
    if meta_path.is_file():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except Exception:
            meta = {}
    steps = meta.get("steps") or {}
    qe_dir = job / "qe"
    inputs = sorted(qe_dir.glob("disp_*.in")) if qe_dir.is_dir() else []
    outs = sorted(qe_dir.glob("disp_*.out")) if qe_dir.is_dir() else []
    n_in = len(inputs)
    n_done = sum(1 for p in outs if _qe_job_done(p))
    running = _proc_running_for_job(job_id)

    import_ok = bool((steps.get("import") or {}).get("ok"))
    supercell_ok = bool((steps.get("supercell") or {}).get("ok")) or n_in > 0
    dfset_ok = bool((steps.get("dfset") or {}).get("ok")) or (job / "alamode" / "DFSET").is_file()
    alm_ok = bool((steps.get("alm_optimize") or {}).get("ok")) or bool(
        (steps.get("alm_run") or {}).get("ok")
    )
    anphon_ok = bool((steps.get("anphon") or {}).get("ok"))
    publish_ok = bool((steps.get("publish") or {}).get("ok"))

    # Chaîne ordonnée
    chain = [
        ("import", "SCF / import", import_ok),
        ("supercell", "Supercellules", supercell_ok),
        ("qe_forces", f"Forces QE ({n_done}/{n_in or '?'} JOB DONE)", n_done > 0 and n_done >= max(1, n_in)),
        ("dfset", "DFSET", dfset_ok),
        ("alm_optimize", "alm", alm_ok),
        ("anphon", "anphon", anphon_ok),
        ("publish", "Export", publish_ok),
    ]

    current_id = "import"
    current_label = "SCF / import"
    next_id = "import"
    next_label = "SCF / import"
    for i, (sid, label, ok) in enumerate(chain):
        if not ok:
            current_id, current_label = sid, label
            next_id, next_label = sid, label
            break
        if i + 1 < len(chain):
            next_id, next_label = chain[i + 1][0], chain[i + 1][1]
        else:
            current_id, current_label = "terminé", "Terminé"
            next_id, next_label = "terminé", "—"
    else:
        current_id, current_label = "terminé", "Terminé"
        next_id, next_label = "terminé", "—"

    # Affinage QE partiel
    qe_complete = n_in > 0 and n_done >= n_in
    if supercell_ok and not qe_complete:
        current_id = "qe_forces"
        current_label = f"Forces QE ({n_done}/{n_in} JOB DONE)"
        next_id = "qe_forces" if n_done < n_in else "dfset"
        next_label = "Forces QE (suite)" if n_done < n_in else "DFSET"

    if running:
        state = "running"
        state_label = "En cours"
        hint = f"Calcul actif : {running[0][:100]}"
    elif current_id == "terminé":
        state = "done"
        state_label = "Terminé"
        hint = "Pipeline terminé — consultez Résultats / outputs/."
    elif supercell_ok and not qe_complete and (n_done > 0 or outs):
        state = "interrupted"
        state_label = "Interrompu"
        hint = (
            f"Forces QE arrêtées : {n_done}/{n_in} terminées. "
            "Aucune étape n'est finie pour DFSET. Relancez pw.x / resume_job.sh."
        )
        next_id, next_label = "qe_forces", "Forces QE (reprise)"
    elif not import_ok:
        state = "idle"
        state_label = "À démarrer"
        hint = "Chargez d'abord le SCF du matériau."
    else:
        state = "awaiting"
        state_label = "En attente"
        hint = f"Prêt pour l'étape : {current_label}. Lancez-la dans l'interface."

    checklist = [
        {
            "id": sid,
            "label": label,
            "ok": ok,
            "active": sid == current_id,
        }
        for sid, label, ok in chain
    ]

    return {
        "ok": True,
        "job_id": job_id,
        "state": state,
        "state_label": state_label,
        "current_step": current_id,
        "current_label": current_label,
        "next_step": next_id,
        "next_label": next_label,
        "hint": hint,
        "qe_done": n_done,
        "qe_total": n_in,
        "running": running,
        "checklist": checklist,
        "signal": read_step_signal(job_id),
    }


def ensure_status_signal(job_id: str) -> dict[str, Any]:
    """Si le job est interrompu sans signal actif, en émettre un visible (une fois)."""
    status = compute_pipeline_status(job_id)
    if not status.get("ok"):
        return status
    sig = status.get("signal") or {}
    active = bool(sig.get("awaiting_user") and not sig.get("acked"))
    if active:
        status["signal"] = sig
        return status

    state = status.get("state")
    # Ne pas réémettre si un signal du même état existe déjà (même acquitté) :
    # le bandeau progression reste la référence permanente.
    if sig and sig.get("state") == state:
        status["signal"] = sig
        return status

    if state == "interrupted":
        sig = emit_step_signal(
            job_id,
            "qe_forces",
            ok=False,
            awaiting_user=True,
            state="interrupted",
            message=status["current_label"],
            hint=status["hint"],
            next_step=status["next_step"],
            next_label=status["next_label"],
            notify=True,
        )
        status["signal"] = sig
    elif state == "done" and (not sig or sig.get("state") != "done"):
        sig = emit_step_signal(
            job_id,
            "terminé",
            ok=True,
            awaiting_user=True,
            state="done",
            message="Pipeline terminé",
            hint=status["hint"],
            notify=False,
        )
        status["signal"] = sig
    return status


def ack_step_signal(job_id: str) -> dict[str, Any]:
    """Acquitte le signal (bandeau UI) sans effacer l'historique."""
    path = signal_paths(job_id)["json"]
    data = read_step_signal(job_id) or {"job_id": job_id}
    data["acked"] = True
    data["acked_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    data["awaiting_user"] = False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    ready = signal_paths(job_id)["ready"]
    if ready.exists():
        ready.unlink()
    return {"ok": True, "signal": data}


def attach_signal(result: dict[str, Any], job_id: str, step: str, **kwargs: Any) -> dict[str, Any]:
    """Ajoute step_signal au dict API si l'étape a réussi (ou si force=True)."""
    force = bool(kwargs.pop("force", False))
    ok = bool(result.get("ok")) if "ok" in result else force
    if not ok and not force:
        return result
    # anphon : préciser phonons vs rta si possible
    emit_step = step
    if step == "anphon":
        mode = (result.get("mode") or kwargs.get("mode") or "").lower()
        if mode == "rta":
            emit_step = "anphon_rta"
        elif mode in ("phonons", "dos"):
            emit_step = "anphon_phonons"
    sig = emit_step_signal(job_id, emit_step, ok=ok, detail={"api_ok": result.get("ok")}, **kwargs)
    out = dict(result)
    out["step_signal"] = sig
    return out


def _desktop_notify(title: str, body: str) -> None:
    if not shutil.which("notify-send"):
        return
    try:
        subprocess.run(
            ["notify-send", "-a", "QE-Alamode", "-u", "normal", title, body],
            check=False,
            timeout=5,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        pass

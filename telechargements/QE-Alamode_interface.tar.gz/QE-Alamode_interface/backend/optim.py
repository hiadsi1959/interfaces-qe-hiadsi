"""Optimisation type Interface-QE_v1 : VC-RELAX / RELAX / SCF par matériau."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import threading
import time
from pathlib import Path

from config import INPUTS, OUTPUTS, LOGS, WORK, ROOT, detect_tools
from materials import _safe_name


KINDS = ("vc-relax", "relax", "scf")

_WITNESS_LABEL = {
    "running": "Calcul en cours…",
    "done_ok": "Calcul terminé — Convergé",
    "done_bad": "Calcul terminé — Non convergé",
    "failed": "Calcul terminé — Échec (non convergé)",
}


def _witness_path(mat: str, kind: str) -> Path:
    mat = _safe_name(mat)
    kind = normalize_kind(kind)
    return OUTPUTS / mat / "optimisation" / f"witness_{kind.replace('-', '_')}.json"


def _write_witness(
    mat: str,
    kind: str,
    *,
    phase: str,
    job_id: str | None = None,
    converged: bool | None = None,
    progress: str | None = None,
    error: str | None = None,
    rc: int | None = None,
) -> None:
    kind = normalize_kind(kind)
    path = _witness_path(mat, kind)
    path.parent.mkdir(parents=True, exist_ok=True)
    label = _WITNESS_LABEL.get("running")
    if phase == "done":
        label = _WITNESS_LABEL["done_ok"] if converged else _WITNESS_LABEL["done_bad"]
    elif phase == "failed":
        label = _WITNESS_LABEL["failed"]
    payload = {
        "material": _safe_name(mat),
        "kind": kind,
        "phase": phase,
        "label": label,
        "job_id": job_id,
        "converged": converged,
        "progress": progress,
        "error": error,
        "rc": rc,
        "updated": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _read_witness(mat: str, kind: str) -> dict | None:
    path = _witness_path(mat, kind)
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except (OSError, json.JSONDecodeError):
        return None


def _progress_from_out(out_path: Path) -> str | None:
    if not out_path.is_file() or out_path.stat().st_size < 20:
        return None
    try:
        text = out_path.read_text(encoding="utf-8", errors="replace")[-12000:]
    except OSError:
        return None
    for pat in (
        r"convergence has been achieved in\s+\d+\s+iterations",
        r"iteration #\s*\d+.*?ecut=",
        r"number of bfgs steps\s*=\s*\d+",
        r"BFGS Geometry Optimization",
        r"Self-consistent Calculation",
    ):
        matches = list(re.finditer(pat, text, re.IGNORECASE | re.DOTALL))
        if matches:
            line = matches[-1].group(0).split("\n")[0].strip()
            if len(line) > 90:
                line = line[:87] + "…"
            return line
    return None


def material_run_live(mat: str, kind: str, *, job_id: str | None = None) -> dict:
    """Témoin temps réel (phase, évolution, convergé ou non)."""
    from job_paths import find_job_dir, job_dir

    mat = _safe_name(mat)
    kind = normalize_kind(kind)
    wit = _read_witness(mat, kind) or {}
    phase = wit.get("phase") or "idle"
    jid = job_id or wit.get("job_id")
    out_path = None
    if jid:
        job = find_job_dir(jid) or job_dir(jid, material=mat, create=False)
        qe_name = {"vc-relax": "vc_relax.out", "relax": "relax.out", "scf": "scf.out"}[kind]
        cand = job / "qe" / qe_name
        if cand.is_file():
            out_path = cand
    if out_path is None:
        opt = _find_out(mat, kind)
        if opt:
            out_path = opt

    progress = wit.get("progress")
    if phase == "running" and out_path:
        progress = _progress_from_out(out_path) or progress or "pw.x en cours…"

    converged = wit.get("converged")
    if phase in {"done", "failed"} and converged is None and out_path:
        converged = _out_converged(out_path)

    label = wit.get("label") or "En attente"
    if phase == "running":
        label = _WITNESS_LABEL["running"]
    elif phase == "done":
        label = _WITNESS_LABEL["done_ok"] if converged else _WITNESS_LABEL["done_bad"]
    elif phase == "failed":
        label = _WITNESS_LABEL["failed"]

    return {
        "ok": True,
        "material": mat,
        "kind": kind,
        "phase": phase,
        "label": label,
        "progress": progress,
        "converged": converged,
        "running": phase == "running",
        "finished": phase in {"done", "failed"},
        "job_id": jid,
        "error": wit.get("error"),
    }


def normalize_kind(kind: str) -> str:
    k = (kind or "").strip().lower().replace("_", "-")
    if k in {"vc-relax", "vcrelax", "vc"}:
        return "vc-relax"
    if k == "relax":
        return "relax"
    if k == "scf":
        return "scf"
    raise ValueError(f"kind inconnu: {kind} (vc-relax|relax|scf)")


def input_filename(mat: str, kind: str) -> str:
    mat = _safe_name(mat)
    kind = normalize_kind(kind)
    return f"{mat}-{kind}.in"


def material_input_path(mat: str, kind: str) -> Path:
    mat = _safe_name(mat)
    return INPUTS / mat / input_filename(mat, kind)


def _find_out(mat: str, kind: str) -> Path | None:
    mat = _safe_name(mat)
    kind = normalize_kind(kind)
    opt = OUTPUTS / mat / "optimisation"
    candidates: list[Path] = []
    if opt.is_dir():
        for name in (
            f"{mat}_{kind}.out",
            f"{mat}-{kind}.out",
            f"{kind}.out",
            f"{kind.replace('-', '_')}.out",
            "vc_relax.out" if kind == "vc-relax" else None,
            "relax.out" if kind == "relax" else None,
            "scf.out" if kind == "scf" else None,
        ):
            if name:
                candidates.append(opt / name)
        for p in sorted(opt.glob("*.out")):
            n = p.name.lower()
            if kind == "vc-relax" and ("vc" in n and "relax" in n):
                candidates.append(p)
            elif kind == "relax" and "relax" in n and "vc" not in n:
                candidates.append(p)
            elif kind == "scf" and "scf" in n:
                candidates.append(p)
    if WORK.exists():
        for job in WORK.iterdir():
            qe = job / "qe"
            if not qe.is_dir():
                continue
            meta = job / "meta.json"
            if meta.is_file():
                try:
                    m = json.loads(meta.read_text(encoding="utf-8"))
                    if _safe_name(m.get("material") or "") not in {mat, ""}:
                        if _safe_name(m.get("material") or "") != mat:
                            continue
                except Exception:
                    pass
            for name in (
                "vc_relax.out" if kind == "vc-relax" else None,
                "relax.out" if kind == "relax" else None,
                "scf.out" if kind == "scf" else None,
                f"{kind}.out",
            ):
                if name and (qe / name).is_file():
                    candidates.append(qe / name)
    for c in candidates:
        if c and c.is_file() and c.stat().st_size > 50:
            return c
    return None


def _out_converged(path: Path | None) -> bool:
    if not path or not path.is_file():
        return False
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return False
    if "JOB DONE" not in text:
        return False
    if re.search(r"convergence NOT achieved|Error in", text, re.I):
        return False
    return True


def _out_diagnostics(path: Path | None) -> list[str]:
    """Conseils courts dérivés de la fin d'un .out pw.x (vc-relax / relax)."""
    if not path or not path.is_file():
        return []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")[-20000:]
    except OSError:
        return []
    hints: list[str] = []
    if "JOB DONE" in text and not re.search(r"Error in routine", text, re.I):
        return hints

    err = re.search(r"Error in routine\s+(\S+)\s*\(\d+\):\s*(.+?)(?:\n|%|$)", text, re.I)
    if err:
        hints.append(f"Erreur QE : {err.group(1)} — {err.group(2).strip()[:120]}")

    if re.search(r"\bNaN\b", text):
        hints.append(
            "Instabilité BFGS (NaN) : repartir de celldm/positions initiales, "
            "augmenter press_conv_thr (ex. 0.5–1.0 kbar), mixing_beta ~ 0.5–0.7, "
            "conv_thr SCF 1d-8 (pas 1d-9), ou relax (cellule fixe) puis vc-relax."
        )

    m = re.search(r"Cell gradient error\s*=\s*([\d.E+-]+)\s*kbar", text, re.I)
    if m:
        try:
            pg = float(m.group(1).replace("D", "E").replace("d", "e"))
            if pg > 1.0:
                hints.append(
                    f"Contrainte cellule élevée ({pg:.2g} kbar) : ecutwfc ≥ 80 Ry, "
                    "k-mesh 12×12×12 ou plus, press_conv_thr plus souple au 1er run."
                )
        except ValueError:
            pass

    if "c_bands:" in text and "not converged" in text:
        hints.append(
            "SCF électronique difficile : electron_maxstep = 200, conv_thr = 1d-8, "
            "mixing_beta = 0.5–0.7 ; degauss ~ 0.02 Ry pour Nb métallique."
        )

    if "JOB DONE" not in text and not err:
        hints.append(
            "Sortie incomplète (pas de JOB DONE) : calcul interrompu ou timeout — relancer ou augmenter QE_TIMEOUT."
        )

    if not hints:
        hints.append(
            "Ajuster forc_conv_thr, press_conv_thr, ecutwfc, mixing_beta, nstep ; Enregistrer puis Relancer."
        )
    return hints[:4]


def optim_status(mat: str) -> dict:
    mat = _safe_name(mat)
    mat_dir = INPUTS / mat
    steps = {}
    for kind in KINDS:
        inp = material_input_path(mat, kind)
        out = _find_out(mat, kind)
        out_rel = None
        if out:
            try:
                out_rel = str(out.relative_to(ROOT))
            except ValueError:
                out_rel = str(out)
        wit = _read_witness(mat, kind)
        phase = (wit or {}).get("phase") or "idle"
        steps[kind] = {
            "kind": kind,
            "input_exists": inp.is_file(),
            "input_path": f"inputs/{mat}/{inp.name}",
            "output_exists": bool(out),
            "output_path": out_rel,
            "converged": _out_converged(out),
            "hints": _out_diagnostics(out) if out else [],
            "run_phase": phase,
            "run_label": (wit or {}).get("label"),
            "run_progress": (wit or {}).get("progress"),
            "running": phase == "running",
        }
        if phase == "done" and wit and wit.get("converged") is not None:
            steps[kind]["run_label"] = (
                _WITNESS_LABEL["done_ok"] if wit["converged"] else _WITNESS_LABEL["done_bad"]
            )
    # Prêt pour Calculs : un input SCF existe ET une étape QE a convergé
    # (SCF lui-même, ou relax/vc-relax ayant produit la structure).
    scf_ready = steps["scf"]["input_exists"] and (
        steps["scf"]["converged"]
        or steps["vc-relax"]["converged"]
        or steps["relax"]["converged"]
    )
    return {
        "ok": True,
        "material": mat,
        "dir": f"inputs/{mat}" if mat_dir.is_dir() else None,
        "steps": steps,
        "scf_ready": bool(scf_ready),
    }


def get_material_input(mat: str, kind: str) -> dict:
    mat = _safe_name(mat)
    kind = normalize_kind(kind)
    path = material_input_path(mat, kind)
    if not path.is_file():
        return {"ok": False, "error": f"Absent : inputs/{mat}/{path.name}"}
    return {
        "ok": True,
        "material": mat,
        "kind": kind,
        "path": f"inputs/{mat}/{path.name}",
        "content": path.read_text(encoding="utf-8"),
    }


def put_material_input(mat: str, kind: str, content: str) -> dict:
    mat = _safe_name(mat)
    kind = normalize_kind(kind)
    path = material_input_path(mat, kind)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = content if content.endswith("\n") else content + "\n"
    path.write_text(text, encoding="utf-8")
    out = {"ok": True, "material": mat, "kind": kind, "path": f"inputs/{mat}/{path.name}"}
    out.update(_validate_input_structure(path))
    return out


def _patch_pw_paths(text: str, *, outdir: Path, pseudo_dir: str) -> str:
    text = re.sub(r"outdir\s*=\s*'[^']*'", f"outdir = '{outdir}'", text, count=1, flags=re.I)
    text = re.sub(r"pseudo_dir\s*=\s*'[^']*'", f"pseudo_dir = '{pseudo_dir}'", text, count=1, flags=re.I)
    return text


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _run_lock_path(job: Path) -> Path:
    return job / "qe" / ".pw_run.lock"


def _acquire_run_lock(job: Path, *, kind: str) -> tuple[bool, str]:
    lock = _run_lock_path(job)
    if lock.is_file():
        try:
            data = json.loads(lock.read_text(encoding="utf-8"))
            pid = int(data.get("pid") or 0)
            started = float(data.get("started") or 0)
            if pid and _pid_alive(pid):
                return False, (
                    f"Un calcul {data.get('kind', 'QE')} est déjà en cours pour ce job "
                    f"({job.name}). Attendez la fin ou créez un nouveau job."
                )
            if not pid and started and (time.time() - started) < 7200:
                return False, (
                    f"Un calcul {data.get('kind', kind)} démarre déjà pour ce job "
                    f"({job.name}). Réessayez dans un instant."
                )
        except (OSError, json.JSONDecodeError, TypeError, ValueError):
            pass
        lock.unlink(missing_ok=True)
    lock.write_text(
        json.dumps({"pid": None, "kind": kind, "started": time.time()}, indent=2) + "\n",
        encoding="utf-8",
    )
    return True, ""


def _release_run_lock(job: Path) -> None:
    _run_lock_path(job).unlink(missing_ok=True)


def _update_run_lock_pid(job: Path, pid: int, *, input_name: str) -> None:
    lock = _run_lock_path(job)
    try:
        data = json.loads(lock.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        data = {"kind": "qe", "started": time.time()}
    data["pid"] = pid
    data["input"] = input_name
    lock.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def _validate_input_structure(path: Path) -> dict:
    from qe_parser import parse_qe_input_full

    try:
        parse_qe_input_full(path)
        return {"structure_ok": True}
    except ValueError as exc:
        return {"structure_ok": False, "structure_hint": str(exc)}


def run_material_optim(
    mat: str,
    kind: str,
    *,
    job_id: str | None = None,
    background: bool = True,
) -> dict:
    """Lance vc-relax / relax / scf pour un matériau (inputs/<Mat>/)."""
    mat = _safe_name(mat)
    kind = normalize_kind(kind)
    tools = detect_tools()
    if not tools.get("pw_x"):
        return {"ok": False, "error": "pw.x introuvable", "tools": tools}

    src = material_input_path(mat, kind)
    if not src.is_file():
        return {"ok": False, "error": f"Input manquant : inputs/{mat}/{src.name}"}

    from workflow import create_job, _job_dir

    if not job_id:
        created = create_job(mat, material=mat)
        job_id = created["job_id"]
    job = _job_dir(job_id)
    ok_lock, lock_err = _acquire_run_lock(job, kind=kind)
    if not ok_lock:
        return {"ok": False, "error": lock_err, "job_id": job_id}
    _release_run_lock(job)

    wit = _read_witness(mat, kind)
    if wit and wit.get("phase") == "running":
        return {"ok": False, "error": f"{kind} déjà en cours pour {mat}.", "running": True}

    _write_witness(mat, kind, phase="running", job_id=job_id, progress="Préparation…")

    if background:
        threading.Thread(
            target=_execute_material_optim,
            args=(mat, kind),
            kwargs={"job_id": job_id},
            daemon=True,
        ).start()
        return {
            "ok": True,
            "running": True,
            "material": mat,
            "kind": kind,
            "job_id": job_id,
            "label": _WITNESS_LABEL["running"],
            "message": "Calcul démarré — suivi en direct sur la carte.",
        }
    return _execute_material_optim(mat, kind, job_id=job_id)


def _execute_material_optim(mat: str, kind: str, *, job_id: str) -> dict:
    """Exécution pw.x (thread ou mode synchrone)."""
    from ase.io import read, write
    from qe_parser import write_followup_relax_scf_inputs
    from workflow import (
        import_scf_input,
        _job_dir,
        _load_meta,
        _save_meta,
        _mass,
    )

    mat = _safe_name(mat)
    kind = normalize_kind(kind)
    tools = detect_tools()
    src = material_input_path(mat, kind)
    job = _job_dir(job_id)
    meta = _load_meta(job)
    meta["material"] = mat
    meta["steps"][kind] = {"ok": False, "status": "running", "started": time.strftime("%Y-%m-%d %H:%M:%S")}
    _save_meta(job, meta)

    ok_lock, lock_err = _acquire_run_lock(job, kind=kind)
    if not ok_lock:
        meta["steps"][kind] = {"ok": False, "status": "busy", "error": lock_err}
        _save_meta(job, meta)
        _write_witness(mat, kind, phase="failed", job_id=job_id, converged=False, error=lock_err)
        return {"ok": False, "error": lock_err, "job_id": job_id, "label": _WITNESS_LABEL["failed"]}

    try:
        import_scf_input(job_id, src.name, src.read_bytes())
    except ValueError as exc:
        _release_run_lock(job)
        meta["steps"][kind] = {"ok": False, "status": "input_invalid", "error": str(exc)}
        _save_meta(job, meta)
        _write_witness(mat, kind, phase="failed", job_id=job_id, converged=False, error=str(exc))
        return {
            "ok": False,
            "error": str(exc),
            "job_id": job_id,
            "label": _WITNESS_LABEL["failed"],
            "hint": "Corrigez l'input (Éditer → Enregistrer), puis relancez Run.",
        }

    opt_dir = OUTPUTS / mat / "optimisation"
    opt_dir.mkdir(parents=True, exist_ok=True)
    outdir = opt_dir / kind.replace("-", "")
    outdir.mkdir(parents=True, exist_ok=True)

    from workflow import _pseudo_dir_for_job
    pseudo_dir = _pseudo_dir_for_job(job)
    text = _patch_pw_paths(src.read_text(encoding="utf-8"), outdir=outdir, pseudo_dir=pseudo_dir)

    qe_name = {"vc-relax": "vc_relax.in", "relax": "relax.in", "scf": "scf.in"}[kind]
    inp = job / "qe" / qe_name
    inp.parent.mkdir(parents=True, exist_ok=True)
    inp.write_text(text, encoding="utf-8")
    out = job / "qe" / qe_name.replace(".in", ".out")
    log = LOGS / f"{job_id}_{kind.replace('-', '')}.log"
    _write_witness(mat, kind, phase="running", job_id=job_id, progress="Lancement pw.x…")

    rc = -1
    pw_proc: subprocess.Popen | None = None
    try:
        with out.open("w", encoding="utf-8") as fout, log.open("w", encoding="utf-8") as flog:
            pw_proc = subprocess.Popen(
                [tools["pw_x"], "-in", str(inp)],
                cwd=str(job / "qe"),
                stdout=fout,
                stderr=flog,
            )
            _update_run_lock_pid(job, pw_proc.pid, input_name=inp.name)
            _write_witness(mat, kind, phase="running", job_id=job_id, progress="pw.x en cours…")
            rc = pw_proc.wait(timeout=int(os.environ.get("QE_TIMEOUT", "21600")))
            prog = _progress_from_out(out)
            if prog:
                _write_witness(mat, kind, phase="running", job_id=job_id, progress=prog)
    except subprocess.TimeoutExpired:
        if pw_proc:
            try:
                pw_proc.kill()
                pw_proc.wait(timeout=30)
            except (OSError, subprocess.TimeoutExpired):
                pass
        meta["steps"][kind] = {"ok": False, "status": "timeout"}
        _save_meta(job, meta)
        _write_witness(mat, kind, phase="failed", job_id=job_id, converged=False, error="timeout")
        return {"ok": False, "error": f"{kind} : timeout", "job_id": job_id}
    finally:
        _release_run_lock(job)

    shutil.copy2(out, opt_dir / f"{mat}_{kind}.out")
    shutil.copy2(inp, opt_dir / f"{mat}_{kind}.in")

    if rc != 0:
        meta["steps"][kind] = {
            "ok": False,
            "status": "failed",
            "rc": rc,
            "log": log.name,
        }
        _save_meta(job, meta)
        _write_witness(mat, kind, phase="failed", job_id=job_id, converged=False, rc=rc, error=f"rc={rc}")
        return {
            "ok": False,
            "error": f"{kind} échoué (rc={rc})",
            "log": log.name,
            "job_id": job_id,
            "output": f"outputs/{mat}/optimisation/{mat}_{kind}.out",
            "label": _WITNESS_LABEL["failed"],
            "hint": "Corrigez l'input si besoin, Enregistrez, puis relancez Run (réutilise le même job).",
        }

    converged = _out_converged(out)
    result = {
        "ok": True,
        "kind": kind,
        "material": mat,
        "job_id": job_id,
        "output": f"outputs/{mat}/optimisation/{mat}_{kind}.out",
        "converged": converged,
        "label": _WITNESS_LABEL["done_ok"] if converged else _WITNESS_LABEL["done_bad"],
    }

    if kind in {"vc-relax", "relax"}:
        try:
            atoms = read(str(out), format="espresso-out")
        except Exception as exc:
            result["warning"] = f"Sortie OK mais structure non lue : {exc}"
            return result
        write(str(job / "structure.cif"), atoms)
        qe_tpl = {}
        if (job / "qe_params.json").is_file():
            qe_tpl = json.loads((job / "qe_params.json").read_text(encoding="utf-8"))
        kd = []
        pseudo_map = qe_tpl.get("pseudo_map") or {}
        mass_map = qe_tpl.get("mass_map") or {}
        for s in atoms.get_chemical_symbols():
            if s not in kd:
                kd.append(s)
        species = [
            {
                "symbol": s,
                "mass": float(mass_map.get(s, _mass(s))),
                "pseudo": pseudo_map.get(s, f"{s}.UPF"),
            }
            for s in kd
        ]
        positions = [
            {
                "symbol": s,
                "x": float(f[0]),
                "y": float(f[1]),
                "z": float(f[2]),
                "unit": "crystal",
            }
            for s, f in zip(atoms.get_chemical_symbols(), atoms.get_scaled_positions())
        ]
        prefix = str(qe_tpl.get("prefix") or mat)
        if result.get("converged"):
            paths = write_followup_relax_scf_inputs(
                mat=mat,
                prefix=prefix,
                pseudo_dir=pseudo_dir,
                opt_dir=opt_dir,
                inputs_dir=INPUTS / mat,
                species=species,
                positions=positions,
                cell=atoms.cell.array.tolist(),
                qe_tpl=qe_tpl,
            )
            scf_text = (INPUTS / mat / f"{mat}-scf.in").read_text(encoding="utf-8")
            (job / "qe" / "reference_scf.in").write_text(scf_text, encoding="utf-8")
            import_scf_input(job_id, "reference_scf.in", scf_text.encode("utf-8"))
            result["generated_inputs"] = paths
            result["saved_input"] = paths["scf"]
            result["message"] = (
                f"{kind} convergé → {paths['relax']} et {paths['scf']} "
                f"(prefix={prefix}, pseudo_dir partagé, outdir …/relax et …/scf)."
            )
        else:
            result["message"] = (
                f"{kind} terminé (rc=0) mais convergence non confirmée — "
                "inputs relax/scf non régénérés."
            )
    else:
        result["message"] = f"SCF terminé → outputs/{mat}/optimisation/"
        result["saved_input"] = f"inputs/{mat}/{mat}-scf.in"

    meta = _load_meta(job)
    meta["material"] = mat
    meta["steps"][kind] = {"ok": True, "rc": rc, "status": "done", "converged": converged}
    _save_meta(job, meta)
    _write_witness(
        mat,
        kind,
        phase="done",
        job_id=job_id,
        converged=converged,
        rc=rc,
        progress=_progress_from_out(out),
    )
    return result

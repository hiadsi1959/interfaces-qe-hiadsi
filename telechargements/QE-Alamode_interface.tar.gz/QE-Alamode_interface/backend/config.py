"""Chemins et détection QE / ALAMODE."""
from __future__ import annotations

import os
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
INPUTS = ROOT / "inputs"
WORK = ROOT / "work"
OUTPUTS = ROOT / "outputs"
LOGS = ROOT / "logs"
TEMPLATES = ROOT / "templates"
INTERFACE = ROOT / "interface"

for d in (INPUTS, WORK, OUTPUTS, LOGS):
    d.mkdir(parents=True, exist_ok=True)

DEFAULT_QE_BIN = Path(os.environ.get("QE_BIN_DIR", str(Path.home() / "q-e-qe-7.5" / "bin")))
DEFAULT_ALAMODE_BIN = Path(os.environ.get("ALAMODE_BIN_DIR", str(ROOT / "bin")))
if not (DEFAULT_ALAMODE_BIN / "alm").is_file():
    DEFAULT_ALAMODE_BIN = Path(os.environ.get("ALAMODE_BIN_DIR", str(Path.home() / "alamode" / "bin")))


def _which_in(name: str, directory: Path) -> str | None:
    cand = directory / name
    if cand.is_file() and os.access(cand, os.X_OK):
        return str(cand)
    found = shutil.which(name)
    return found


def detect_tools() -> dict:
    qe_bin = Path(os.environ.get("QE_BIN_DIR", DEFAULT_QE_BIN))
    al_bin = Path(os.environ.get("ALAMODE_BIN_DIR", DEFAULT_ALAMODE_BIN))
    return {
        "qe_bin_dir": str(qe_bin),
        "alamode_bin_dir": str(al_bin),
        "pw_x": _which_in("pw.x", qe_bin),
        "alm": _which_in("alm", al_bin) or _which_in("alm", Path("/usr/local/bin")),
        "anphon": _which_in("anphon", al_bin) or _which_in("anphon", Path("/usr/local/bin")),
        "root": str(ROOT),
    }

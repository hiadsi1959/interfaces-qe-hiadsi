"""Matériaux : découverte depuis inputs/ et publication vers outputs/."""
from __future__ import annotations

import json
import re
import shutil
import time
from pathlib import Path

from config import INPUTS, OUTPUTS, WORK

_SYNC_SKIP_NAMES = {".pw_run.lock", "README.txt", "INFO.txt"}
_SYNC_FILE_SUFFIXES = {
    ".in",
    ".out",
    ".xml",
    ".fcs",
    ".bands",
    ".kl",
    ".md",
    ".txt",
    ".html",
    ".json",
    ".cif",
    ".npy",
    ".log",
}
_SYNC_ROOT_FILES = (
    "structure.cif",
    "supercell.cif",
    "qe_params.json",
    "structure_summary.json",
    "meta.json",
)


def _safe_name(name: str) -> str:
    s = "".join(c for c in (name or "").strip() if c.isalnum() or c in "-_")
    return s or "material"


def _should_mirror_file(path: Path) -> bool:
    if not path.is_file() or path.name in _SYNC_SKIP_NAMES or path.name.startswith("."):
        return False
    if path.name == "DFSET":
        return True
    return path.suffix.lower() in _SYNC_FILE_SUFFIXES


def material_from_filename(filename: str) -> str:
    """Si_relaxed_scf.in → Si ; GaAs_opt.in → GaAs."""
    stem = Path(filename).stem
    # enlever suffixes courants
    for suf in ("-optimized-scf", "_optimized_scf", "-relaxed-scf", "_relaxed_scf",
                "-vc-relax", "_vc-relax", "-vcrelax", "_vcrelax",
                "-relax", "_relax", "-scf", "_scf", "-opt", "_opt"):
        if stem.lower().endswith(suf.lower()):
            stem = stem[: -len(suf)]
            break
    # premier jeton alphanum
    m = re.match(r"([A-Za-z][A-Za-z0-9]*)", stem)
    return m.group(1) if m else _safe_name(stem)


def list_materials() -> list[dict]:
    INPUTS.mkdir(parents=True, exist_ok=True)
    OUTPUTS.mkdir(parents=True, exist_ok=True)
    mats: dict[str, dict] = {}

    # sous-dossiers inputs/<Mat>/
    for d in sorted(INPUTS.iterdir()):
        if d.is_dir() and not d.name.startswith("."):
            mats.setdefault(d.name, {"name": d.name, "inputs": [], "outputs": []})

    for path in sorted(INPUTS.glob("*.in")):
        mat = material_from_filename(path.name)
        mats.setdefault(mat, {"name": mat, "inputs": [], "outputs": []})
        mats[mat]["inputs"].append(
            {
                "name": path.name,
                "path": f"inputs/{path.name}",
                "rel": path.name,
            }
        )

    for d in INPUTS.iterdir():
        if not d.is_dir():
            continue
        mat = d.name
        mats.setdefault(mat, {"name": mat, "inputs": [], "outputs": []})
        for path in sorted(d.glob("*.in")):
            mats[mat]["inputs"].append(
                {
                    "name": path.name,
                    "path": f"inputs/{mat}/{path.name}",
                    "rel": f"{mat}/{path.name}",
                }
            )

    for d in OUTPUTS.iterdir():
        if d.is_dir() and not d.name.startswith("."):
            mats.setdefault(d.name, {"name": d.name, "inputs": [], "outputs": []})
            for path in sorted(d.rglob("*")):
                if path.is_file() and path.name not in {"README.txt", "SYNC.json"}:
                    mats[d.name]["outputs"].append(
                        {
                            "name": path.name,
                            "path": str(path.relative_to(OUTPUTS.parent)),
                        }
                    )

    # jobs liés
    for job_meta in []:
        pass
    if WORK.exists():
        for p in WORK.iterdir():
            if not (p / "meta.json").is_file():
                continue
            try:
                meta = json.loads((p / "meta.json").read_text(encoding="utf-8"))
            except Exception:
                continue
            mat = meta.get("material") or material_from_filename(meta.get("name") or p.name)
            mats.setdefault(mat, {"name": mat, "inputs": [], "outputs": []})
            mats[mat].setdefault("jobs", []).append({"id": meta.get("id"), "name": meta.get("name")})

    out = []
    for name in sorted(mats.keys(), key=str.lower):
        item = mats[name]
        item.setdefault("jobs", [])
        item["n_inputs"] = len(item["inputs"])
        item["n_outputs"] = len(item["outputs"])
        out.append(item)
    return out


def resolve_input_path(rel_or_name: str) -> Path | None:
    """Résout un input depuis inputs/ (fichier ou Mat/fichier)."""
    rel = rel_or_name.replace(chr(92), "/").lstrip("/")
    if rel.startswith("inputs/"):
        rel = rel[len("inputs/") :]
    cand = INPUTS / rel
    if cand.is_file():
        return cand
    name = Path(rel).name
    for d in INPUTS.iterdir():
        if d.is_dir():
            c = d / name
            if c.is_file():
                return c
    cand = INPUTS / name
    if cand.is_file():
        return cand
    return None


def _copy_if_newer(src: Path, dest: Path) -> bool:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.is_file():
        try:
            if dest.stat().st_mtime >= src.stat().st_mtime and dest.stat().st_size == src.stat().st_size:
                return False
        except OSError:
            pass
    shutil.copy2(src, dest)
    return True


def sync_job_outputs(job_id: str, material: str | None = None, *, step: str | None = None) -> dict:
    """Miroir incrémental work/ ou job → outputs/<mat>/<job_id>/ (qe/, alamode/, results/)."""
    from job_paths import find_job_dir, ensure_job_subdirs

    job = find_job_dir(job_id)
    if job is None or not job.is_dir():
        return {"ok": False, "error": "Job inconnu"}
    meta: dict = {}
    meta_path = job / "meta.json"
    if meta_path.is_file():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            meta = {}
    mat = _safe_name(material or meta.get("material") or meta.get("name") or "material")
    dest = OUTPUTS / mat / job_id
    ensure_job_subdirs(dest)
    for sub in ("qe", "alamode", "results"):
        (dest / sub).mkdir(parents=True, exist_ok=True)

    copied: list[str] = []
    job_res = job.resolve()
    dest_res = dest.resolve()

    def mirror_file(src: Path, rel: str) -> None:
        if job_res == dest_res and src.parent.resolve() == dest_res:
            return
        target = dest / rel
        if _copy_if_newer(src, target):
            copied.append(str(target.relative_to(OUTPUTS.parent)))

    for name in _SYNC_ROOT_FILES:
        src = job / name
        if src.is_file() and _should_mirror_file(src):
            mirror_file(src, name)

    for sub in ("qe", "alamode", "results"):
        src_dir = job / sub
        if not src_dir.is_dir():
            continue
        for f in src_dir.iterdir():
            if not _should_mirror_file(f):
                continue
            mirror_file(f, f"{sub}/{f.name}")

    qe = meta.get("steps", {}).get("qe_forces") or {}
    sync_info = {
        "job_id": job_id,
        "material": mat,
        "step": step,
        "at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "source": (
            str(job.relative_to(OUTPUTS.parent))
            if OUTPUTS.parent in job.parents or job == OUTPUTS.parent
            else str(job)
        ),
        "dest": f"outputs/{mat}/{job_id}",
        "n_copied_this_sync": len(copied),
        "qe_n_done": qe.get("n_done"),
        "qe_n_expected": qe.get("n_expected"),
    }
    try:
        (dest / "SYNC.json").write_text(json.dumps(sync_info, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    except OSError:
        pass

    readme = dest / "INFO.txt"
    try:
        src_rel = job.relative_to(OUTPUTS.parent)
    except ValueError:
        src_rel = job
    readme.write_text(
        f"Matériau : {mat}\nJob : {job_id}\nDernière sync : {sync_info['at']}\n"
        f"Source : {src_rel}\nÉtape : {step or '—'}\n",
        encoding="utf-8",
    )

    meta.setdefault("steps", {})
    meta["steps"]["sync"] = {
        "ok": True,
        "dir": f"outputs/{mat}/{job_id}",
        "at": sync_info["at"],
        "step": step,
        "n_copied": len(copied),
    }
    try:
        meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        if job_res != dest_res and (dest / "meta.json").exists() is False:
            shutil.copy2(meta_path, dest / "meta.json")
        elif job_res != dest_res:
            _copy_if_newer(meta_path, dest / "meta.json")
    except OSError:
        pass

    return {
        "ok": True,
        "material": mat,
        "dir": f"outputs/{mat}/{job_id}",
        "files": copied,
        "sync": sync_info,
    }


def publish_job_to_outputs(job_id: str, material: str | None = None) -> dict:
    """Publication complète (= sync structurée + marqueur publish)."""
    out = sync_job_outputs(job_id, material, step="publish")
    if not out.get("ok"):
        return out
    from job_paths import find_job_dir

    job = find_job_dir(job_id)
    if job is None:
        return out
    meta = {}
    try:
        meta = json.loads((job / "meta.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        pass
    mat = out.get("material") or _safe_name(material or "material")
    try:
        meta.setdefault("steps", {})
        meta["steps"]["publish"] = {
            "ok": True,
            "dir": out.get("dir"),
            "n_files": len(out.get("files") or []),
            "at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        (job / "meta.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    except OSError:
        pass
    return {
        "ok": True,
        "material": mat,
        "dir": out.get("dir"),
        "files": out.get("files") or [],
    }

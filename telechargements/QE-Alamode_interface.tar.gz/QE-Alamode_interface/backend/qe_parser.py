"""Parsing / génération d'inputs Quantum ESPRESSO pour ALAMODE."""
from __future__ import annotations

import re
from pathlib import Path

ANG_TO_BOHR = 1.0 / 0.529177210903

FORCE_RE = re.compile(
    r"^\s*atom\s+(\d+)\s+type\s+\d+\s+force\s*=\s*([-\d.Ee+]+)\s+([-\d.Ee+]+)\s+([-\d.Ee+]+)",
    re.IGNORECASE,
)


def extract_forces_ry_au(outfile: Path) -> list[tuple[float, float, float]]:
    """Extrait les dernières forces cartésiennes (Ry/au) d'un fichier pw.x .out."""
    text = outfile.read_text(encoding="utf-8", errors="replace")
    blocks: list[list[tuple[float, float, float]]] = []
    current: list[tuple[float, float, float]] | None = None
    for line in text.splitlines():
        if "Forces acting on atoms" in line:
            current = []
            continue
        if current is not None:
            m = FORCE_RE.match(line)
            if m:
                current.append((float(m.group(2)), float(m.group(3)), float(m.group(4))))
            elif current and line.strip() == "":
                blocks.append(current)
                current = None
            elif "The non-local" in line or "Total force" in line:
                if current:
                    blocks.append(current)
                current = None
    if current:
        blocks.append(current)
    if not blocks:
        raise ValueError(f"Aucune force trouvée dans {outfile}")
    return blocks[-1]


def write_alamode_dfset(
    pairs: list[tuple[list[tuple[float, float, float]], list[tuple[float, float, float]]]],
    dest: Path,
    *,
    displ_unit: str = "angstrom",
) -> int:
    """
    Construit un DFSET ALAMODE 1.x.
    pairs: (displacements, forces_Ry/Bohr) par configuration.
    Sortie: dx dy dz (Bohr) + fx fy fz (Ryd/Bohr).
    """
    scale = ANG_TO_BOHR if displ_unit.lower().startswith("ang") else 1.0
    lines: list[str] = []
    for displs, forces in pairs:
        if len(displs) != len(forces):
            raise ValueError("Déplacements et forces : nombres d'atomes différents")
        for (dx, dy, dz), (fx, fy, fz) in zip(displs, forces):
            lines.append(
                f"{dx * scale:16.10f}{dy * scale:16.10f}{dz * scale:16.10f}"
                f"{fx:16.10f}{fy:16.10f}{fz:16.10f}"
            )
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return len(pairs)


def parse_qe_scf_template(path: Path) -> dict:
    """Lit un input SCF de référence (ex. inputs/Si_scf.in) pour ecut, k-points, smearing…"""
    defaults = {
        "ecutwfc": 40.0,
        "ecutrho": 320.0,
        "kpoints": (2, 2, 2),
        "occupations": None,
        "smearing": None,
        "degauss": None,
        "conv_thr": "1.0d-8",
        "mixing_beta": None,
    }
    if not path.is_file():
        return defaults
    text = path.read_text(encoding="utf-8", errors="replace")
    for key in ("ecutwfc", "ecutrho", "degauss", "mixing_beta"):
        m = re.search(rf"{key}\s*=\s*([0-9.eEdD+-]+)", text, re.IGNORECASE)
        if m:
            defaults[key] = float(m.group(1).replace("d", "e").replace("D", "E"))
    for key in ("occupations", "smearing"):
        m = re.search(rf"{key}\s*=\s*'([^']+)'", text, re.IGNORECASE)
        if m:
            defaults[key] = m.group(1)
    m = re.search(r"conv_thr\s*=\s*([^\s,/]+)", text, re.IGNORECASE)
    if m:
        defaults["conv_thr"] = m.group(1).strip()
    # K_POINTS automatic → ligne suivante
    m = re.search(
        r"K_POINTS\s+automatic\s*\n\s*(\d+)\s+(\d+)\s+(\d+)",
        text,
        re.IGNORECASE,
    )
    if m:
        defaults["kpoints"] = (int(m.group(1)), int(m.group(2)), int(m.group(3)))
    defaults["source"] = str(path)
    return defaults


def parse_qe_input_full(path: Path) -> dict:
    """
    Parse un input pw.x (scf / relax / vc-relax) :
      - paramètres électroniques (comme parse_qe_scf_template)
      - ATOMIC_SPECIES, CELL_PARAMETERS, ATOMIC_POSITIONS
    Retourne aussi une structure ASE-ready : symbols, cell(Å), positions(Å).
    """
    from ase import Atoms
    import numpy as np

    tpl = parse_qe_scf_template(path)
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()

    # ATOMIC_SPECIES
    species: list[dict] = []
    i = 0
    while i < len(lines):
        if re.match(r"^\s*ATOMIC_SPECIES\b", lines[i], re.IGNORECASE):
            i += 1
            while i < len(lines):
                s = lines[i].strip()
                if not s or s.startswith("!") or s.startswith("#"):
                    i += 1
                    continue
                if re.match(r"^[A-Za-z_]", s) and "=" not in s.split()[0] and not s.upper().startswith("ATOMIC") and not s.upper().startswith("CELL") and not s.upper().startswith("K_POINTS"):
                    parts = s.split()
                    if len(parts) >= 3 and not parts[0].startswith("&"):
                        species.append({"symbol": parts[0], "mass": float(parts[1]), "pseudo": parts[2]})
                        i += 1
                        continue
                break
            break
        i += 1

    # CELL_PARAMETERS
    cell = None
    cell_unit = "angstrom"
    i = 0
    while i < len(lines):
        m = re.match(r"^\s*CELL_PARAMETERS(?:\s+(\S+))?", lines[i], re.IGNORECASE)
        if m:
            unit = (m.group(1) or "angstrom").lower().strip()
            cell_unit = "bohr" if ("bohr" in unit or unit in {"a.u.", "au"}) else "angstrom"
            vecs = []
            j = i + 1
            while j < len(lines) and len(vecs) < 3:
                s = lines[j].strip()
                if s and not s.startswith("!") and not s.startswith("#"):
                    parts = s.split()
                    if len(parts) >= 3:
                        try:
                            vecs.append([float(parts[0]), float(parts[1]), float(parts[2])])
                        except ValueError:
                            break
                j += 1
            if len(vecs) == 3:
                cell = np.array(vecs, dtype=float)
                if cell_unit == "bohr":
                    cell = cell / ANG_TO_BOHR  # Bohr → Å  (ANG_TO_BOHR = 1/a0)
            break
        i += 1

    # ATOMIC_POSITIONS
    pos_unit = "alat"
    coords: list[tuple[str, float, float, float]] = []
    i = 0
    while i < len(lines):
        m = re.match(r"^\s*ATOMIC_POSITIONS(?:\s+(\S+))?", lines[i], re.IGNORECASE)
        if m:
            pos_unit = (m.group(1) or "alat").lower()
            j = i + 1
            while j < len(lines):
                s = lines[j].strip()
                if not s or s.startswith("!") or s.startswith("#"):
                    j += 1
                    continue
                if re.match(r"^(ATOMIC_|CELL_|K_POINTS|&)", s, re.IGNORECASE):
                    break
                parts = s.split()
                if len(parts) >= 4:
                    try:
                        coords.append((parts[0], float(parts[1]), float(parts[2]), float(parts[3])))
                    except ValueError:
                        break
                else:
                    break
                j += 1
            break
        i += 1

    if cell is None or not coords:
        raise ValueError(
            "Input QE incomplet : il faut CELL_PARAMETERS (3 vecteurs) et ATOMIC_POSITIONS "
            "avec une structure déjà relaxée/optimisée."
        )

    symbols = [c[0] for c in coords]
    frac_or_cart = np.array([[c[1], c[2], c[3]] for c in coords], dtype=float)
    if "crystal" in pos_unit:
        atoms = Atoms(symbols=symbols, scaled_positions=frac_or_cart, cell=cell, pbc=True)
    elif "bohr" in pos_unit:
        atoms = Atoms(symbols=symbols, positions=frac_or_cart / ANG_TO_BOHR, cell=cell, pbc=True)
    else:
        # angstrom / alat (si alat sans facteur : traité comme angstrom si cellule en Å)
        atoms = Atoms(symbols=symbols, positions=frac_or_cart, cell=cell, pbc=True)

    # Pseudos par symbole
    pseudo_map = {sp["symbol"]: sp["pseudo"] for sp in species}
    mass_map = {sp["symbol"]: sp["mass"] for sp in species}

    tpl["species"] = species
    tpl["pseudo_map"] = pseudo_map
    tpl["mass_map"] = mass_map
    tpl["nat"] = len(atoms)
    tpl["ntyp"] = len({s for s in symbols})
    tpl["calculation"] = None
    mcalc = re.search(r"calculation\s*=\s*'([^']+)'", text, re.IGNORECASE)
    if mcalc:
        tpl["calculation"] = mcalc.group(1)
    return {"template": tpl, "atoms": atoms}


def build_pw_scf_input(
    *,
    prefix: str,
    species: list[dict],
    positions: list[dict],
    cell: list[list[float]],
    ecutwfc: float = 40.0,
    ecutrho: float = 320.0,
    kpoints: tuple[int, int, int] = (2, 2, 2),
    pseudo_dir: str = "../pseudos",
    occupations: str | None = None,
    smearing: str | None = None,
    degauss: float | None = None,
    conv_thr: str = "1.0d-8",
    mixing_beta: float | None = None,
) -> str:
    """Génère un input pw.x SCF (cellule en angstroms) pour forces ALAMODE."""
    nat = len(positions)
    ntyp = len(species)
    lines = [
        "&CONTROL",
        "  calculation = 'scf'",
        f"  prefix = '{prefix}'",
        "  outdir = './tmp'",
        f"  pseudo_dir = '{pseudo_dir}'",
        "  tprnfor = .true.",
        "/",
        "&SYSTEM",
        "  ibrav = 0",
        f"  nat = {nat}",
        f"  ntyp = {ntyp}",
        f"  ecutwfc = {ecutwfc}",
        f"  ecutrho = {ecutrho}",
    ]
    if occupations:
        lines.append(f"  occupations = '{occupations}'")
    if smearing:
        lines.append(f"  smearing = '{smearing}'")
    if degauss is not None:
        lines.append(f"  degauss = {degauss}")
    lines += [
        "/",
        "&ELECTRONS",
        f"  conv_thr = {conv_thr}",
    ]
    if mixing_beta is not None:
        lines.append(f"  mixing_beta = {mixing_beta}")
    lines.append("/")
    lines.append("CELL_PARAMETERS angstrom")
    for row in cell:
        lines.append(f"  {row[0]:.10f}  {row[1]:.10f}  {row[2]:.10f}")
    lines.append("ATOMIC_SPECIES")
    for sp in species:
        lines.append(f"  {sp['symbol']}  {sp.get('mass', 1.0)}  {sp['pseudo']}")
    pos_unit = positions[0].get("unit", "angstrom") if positions else "angstrom"
    lines.append(f"ATOMIC_POSITIONS {pos_unit}")
    for p in positions:
        lines.append(f"  {p['symbol']}  {p['x']:.10f}  {p['y']:.10f}  {p['z']:.10f}")
    kx, ky, kz = kpoints
    lines.append("K_POINTS automatic")
    lines.append(f"  {kx} {ky} {kz} 0 0 0")
    lines.append("")
    return "\n".join(lines)

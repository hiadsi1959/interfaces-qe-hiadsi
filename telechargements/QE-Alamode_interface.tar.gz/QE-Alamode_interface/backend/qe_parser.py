"""Parsing / génération d'inputs Quantum ESPRESSO pour ALAMODE."""
from __future__ import annotations

import re
from pathlib import Path

ANG_TO_BOHR = 1.0 / 0.529177210903

FORCE_RE = re.compile(
    r"^\s*atom\s+(\d+)\s+type\s+\d+\s+force\s*=\s*([-\d.Ee+]+)\s+([-\d.Ee+]+)\s+([-\d.Ee+]+)",
    re.IGNORECASE,
)


def extract_forces_ry_au(outfile: Path) -> list[tuple[float, float, float]]:
    """Extrait les dernières forces cartésiennes (Ry/au) d'un fichier pw.x .out."""
    text = outfile.read_text(encoding="utf-8", errors="replace")
    blocks: list[list[tuple[float, float, float]]] = []
    current: list[tuple[float, float, float]] | None = None
    for line in text.splitlines():
        if "Forces acting on atoms" in line:
            current = []
            continue
        if current is not None:
            m = FORCE_RE.match(line)
            if m:
                current.append((float(m.group(2)), float(m.group(3)), float(m.group(4))))
            elif current and line.strip() == "":
                blocks.append(current)
                current = None
            elif "The non-local" in line or "Total force" in line:
                if current:
                    blocks.append(current)
                current = None
    if current:
        blocks.append(current)
    if not blocks:
        raise ValueError(f"Aucune force trouvée dans {outfile}")
    return blocks[-1]


def write_alamode_dfset(
    pairs: list[tuple[list[tuple[float, float, float]], list[tuple[float, float, float]]]],
    dest: Path,
    *,
    displ_unit: str = "angstrom",
) -> int:
    """
    Construit un DFSET ALAMODE 1.x.
    pairs: (displacements, forces_Ry/Bohr) par configuration.
    Sortie: dx dy dz (Bohr) + fx fy fz (Ryd/Bohr).
    """
    scale = ANG_TO_BOHR if displ_unit.lower().startswith("ang") else 1.0
    lines: list[str] = []
    for displs, forces in pairs:
        if len(displs) != len(forces):
            raise ValueError("Déplacements et forces : nombres d'atomes différents")
        for (dx, dy, dz), (fx, fy, fz) in zip(displs, forces):
            lines.append(
                f"{dx * scale:16.10f}{dy * scale:16.10f}{dz * scale:16.10f}"
                f"{fx:16.10f}{fy:16.10f}{fz:16.10f}"
            )
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return len(pairs)


def parse_qe_scf_template(path: Path) -> dict:
    """Lit un input SCF de référence (ex. inputs/Si_scf.in) pour ecut, k-points, smearing…"""
    defaults = {
        "ecutwfc": 40.0,
        "ecutrho": 320.0,
        "kpoints": (2, 2, 2),
        "occupations": None,
        "smearing": None,
        "degauss": None,
        "conv_thr": "1.0d-8",
        "mixing_beta": None,
    }
    if not path.is_file():
        return defaults
    text = path.read_text(encoding="utf-8", errors="replace")
    for key in ("ecutwfc", "ecutrho", "degauss", "mixing_beta"):
        m = re.search(rf"{key}\s*=\s*([0-9.eEdD+-]+)", text, re.IGNORECASE)
        if m:
            defaults[key] = float(m.group(1).replace("d", "e").replace("D", "E"))
    for key in ("occupations", "smearing"):
        m = re.search(rf"{key}\s*=\s*'([^']+)'", text, re.IGNORECASE)
        if m:
            defaults[key] = m.group(1)
    m = re.search(r"(?<!forc_)conv_thr\s*=\s*([^\s,/]+)", text, re.IGNORECASE)
    if m:
        defaults["conv_thr"] = m.group(1).strip()
    m = re.search(r"prefix\s*=\s*'([^']+)'", text, re.IGNORECASE)
    if m:
        defaults["prefix"] = m.group(1)
    m = re.search(r"forc_conv_thr\s*=\s*([0-9.eEdD+-]+)", text, re.IGNORECASE)
    if m:
        defaults["forc_conv_thr"] = float(m.group(1).replace("d", "e").replace("D", "E"))
    m = re.search(r"ibrav\s*=\s*(-?\d+)", text, re.IGNORECASE)
    if m:
        defaults["ibrav"] = int(m.group(1))
    m = re.search(r"nspin\s*=\s*(\d+)", text, re.IGNORECASE)
    if m:
        defaults["nspin"] = int(m.group(1))
    # K_POINTS automatic → ligne suivante
    m = re.search(
        r"K_POINTS\s+automatic\s*\n\s*(\d+)\s+(\d+)\s+(\d+)",
        text,
        re.IGNORECASE,
    )
    if m:
        defaults["kpoints"] = (int(m.group(1)), int(m.group(2)), int(m.group(3)))
    defaults["source"] = str(path)
    return defaults


def _celldm_from_qe_text(text: str) -> dict[int, float]:
    celldm: dict[int, float] = {}
    for m in re.finditer(
        r"celldm\s*\(\s*(\d+)\s*\)\s*=\s*([0-9.eEdD+-]+)",
        text,
        re.IGNORECASE,
    ):
        celldm[int(m.group(1))] = float(m.group(2).replace("d", "e").replace("D", "E"))
    return celldm


def _cell_matrix_from_ibrav(ibrav: int, celldm: dict[int, float]) -> list[list[float]] | None:
    """
    Vecteurs de maille en angströms (convention pw.x / ibrav > 0).
    celldm(1…) sont en Bohr.
    """
    import numpy as np

    if ibrav == 0 or not celldm.get(1):
        return None
    a = celldm[1] * (1.0 / ANG_TO_BOHR)  # Bohr → Å
    b = celldm.get(2, 1.0) * a
    c = celldm.get(3, 1.0) * a
    cosab = celldm.get(4)
    cosac = celldm.get(5)
    cosbc = celldm.get(6)

    def v(*xyz: float) -> list[float]:
        return [float(x) for x in xyz]

    h = 0.5
    if ibrav == 1:
        return [v(a, 0, 0), v(0, a, 0), v(0, 0, a)]
    if ibrav == 2:
        return [v(0, h * b, h * c), v(h * a, 0, h * c), v(h * a, h * b, 0)]
    if ibrav == 3:
        return [v(-h * a, 0, h * a), v(0, h * a, h * a), v(-h * a, h * a, 0)]
    if ibrav == 4:
        return [v(a, 0, 0), v(-h * a, h * np.sqrt(3) * a, 0), v(0, 0, c)]
    if ibrav == 5 and cosab is not None:
        tx = np.sqrt(1.0 - cosab**2)
        return [v(a, 0, 0), v(b * cosab, b * tx, 0), v(0, 0, c)]
    if ibrav == 6:
        return [v(a, 0, 0), v(0, b, 0), v(0, 0, c)]
    if ibrav == 7:
        return [v(h * a, -h * b, 0), v(h * a, h * b, 0), v(0, 0, c)]
    if ibrav == 8:
        return [v(a, 0, 0), v(0, b, 0), v(0, 0, c)]
    if ibrav == 9:
        return [v(h * a, h * b, 0), v(-h * a, h * b, 0), v(0, 0, c)]
    if ibrav == 10:
        return [v(h * a, h * b, 0), v(h * a, -h * b, 0), v(0, 0, c)]
    if ibrav == 11:
        return [v(h * a, h * b, h * c), v(-h * a, h * b, h * c), v(-h * a, -h * b, h * c)]
    if ibrav == 12 and cosbc is not None:
        return [v(a, 0, 0), v(b * cosbc, b * np.sqrt(1 - cosbc**2), 0), v(0, 0, c)]
    if ibrav == 13 and cosab is not None and cosbc is not None:
        return [
            v(h * a, 0, h * c),
            v(h * b * cosab, h * b * np.sqrt(1 - cosab**2), 0),
            v(-h * a, 0, h * c),
        ]
    if ibrav == 14 and cosab is not None and cosac is not None and cosbc is not None:
        v1 = v(a, 0, 0)
        v2 = v(b * cosbc, b * np.sqrt(1 - cosbc**2), 0)
        cx = c * cosac
        cy = c * (cosab - cosac * cosbc) / np.sqrt(1 - cosbc**2)
        cz = c * np.sqrt(1 - cosac**2 - ((cosab - cosac * cosbc) / np.sqrt(1 - cosbc**2)) ** 2)
        return [v1, v2, v(cx, cy, cz)]
    return None


def _celldm_from_optimized_cell(ibrav: int, cell_ang: list[list[float]]) -> dict[int, float] | None:
    """Déduit celldm (Bohr) depuis la maille optimisée (Å) pour les ibrav QE courants."""
    import numpy as np

    v = np.array(cell_ang, dtype=float)
    if v.shape != (3, 3):
        return None
    la, lb, lc = float(np.linalg.norm(v[0])), float(np.linalg.norm(v[1])), float(np.linalg.norm(v[2]))
    if la < 1e-6:
        return None
    to_bohr = ANG_TO_BOHR
    if ibrav == 1:
        return {1: la * to_bohr}
    if ibrav == 2:
        return {1: la * np.sqrt(2) * to_bohr}
    if ibrav == 3:
        return {1: la * np.sqrt(2) * to_bohr}
    if ibrav == 4:
        if lc < 1e-6:
            return None
        a = la * to_bohr
        return {1: a, 3: (lc * to_bohr) / a}
    if ibrav == 6:
        if lb < 1e-6 or lc < 1e-6:
            return None
        a = la * to_bohr
        return {1: a, 2: lb / la, 3: lc / la}
    return None


def _structure_format_from_template(qe_tpl: dict, cell_ang: list[list[float]]) -> tuple[int, dict[int, float] | None]:
    """
    Conserve ibrav du vc-relax si défini (ex. 3 pour bcc) ; sinon maille libre ibrav=0.
    """
    ibrav = int(qe_tpl.get("ibrav") or 0)
    if ibrav <= 0:
        return 0, None
    celldm = _celldm_from_optimized_cell(ibrav, cell_ang)
    if celldm:
        return ibrav, celldm
    return 0, None


def parse_qe_input_full(path: Path) -> dict:
    """
    Parse un input pw.x (scf / relax / vc-relax) :
      - paramètres électroniques (comme parse_qe_scf_template)
      - ATOMIC_SPECIES, CELL_PARAMETERS, ATOMIC_POSITIONS
    Retourne aussi une structure ASE-ready : symbols, cell(Å), positions(Å).
    """
    from ase import Atoms
    import numpy as np

    tpl = parse_qe_scf_template(path)
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()

    # ATOMIC_SPECIES
    species: list[dict] = []
    i = 0
    while i < len(lines):
        if re.match(r"^\s*ATOMIC_SPECIES\b", lines[i], re.IGNORECASE):
            i += 1
            while i < len(lines):
                s = lines[i].strip()
                if not s or s.startswith("!") or s.startswith("#"):
                    i += 1
                    continue
                if re.match(r"^[A-Za-z_]", s) and "=" not in s.split()[0] and not s.upper().startswith("ATOMIC") and not s.upper().startswith("CELL") and not s.upper().startswith("K_POINTS"):
                    parts = s.split()
                    if len(parts) >= 3 and not parts[0].startswith("&"):
                        species.append({"symbol": parts[0], "mass": float(parts[1]), "pseudo": parts[2]})
                        i += 1
                        continue
                break
            break
        i += 1

    # CELL_PARAMETERS
    cell = None
    cell_unit = "angstrom"
    i = 0
    while i < len(lines):
        m = re.match(r"^\s*CELL_PARAMETERS(?:\s+(\S+))?", lines[i], re.IGNORECASE)
        if m:
            unit = (m.group(1) or "angstrom").lower().strip()
            cell_unit = "bohr" if ("bohr" in unit or unit in {"a.u.", "au"}) else "angstrom"
            vecs = []
            j = i + 1
            while j < len(lines) and len(vecs) < 3:
                s = lines[j].strip()
                if s and not s.startswith("!") and not s.startswith("#"):
                    parts = s.split()
                    if len(parts) >= 3:
                        try:
                            vecs.append([float(parts[0]), float(parts[1]), float(parts[2])])
                        except ValueError:
                            break
                j += 1
            if len(vecs) == 3:
                cell = np.array(vecs, dtype=float)
                if cell_unit == "bohr":
                    cell = cell / ANG_TO_BOHR  # Bohr → Å  (ANG_TO_BOHR = 1/a0)
            break
        i += 1

    # ATOMIC_POSITIONS
    pos_unit = "alat"
    coords: list[tuple[str, float, float, float]] = []
    i = 0
    while i < len(lines):
        m = re.match(r"^\s*ATOMIC_POSITIONS(?:\s+(\S+))?", lines[i], re.IGNORECASE)
        if m:
            pos_unit = (m.group(1) or "alat").lower()
            j = i + 1
            while j < len(lines):
                s = lines[j].strip()
                if not s or s.startswith("!") or s.startswith("#"):
                    j += 1
                    continue
                if re.match(r"^(ATOMIC_|CELL_|K_POINTS|&)", s, re.IGNORECASE):
                    break
                parts = s.split()
                if len(parts) >= 4:
                    try:
                        coords.append((parts[0], float(parts[1]), float(parts[2]), float(parts[3])))
                    except ValueError:
                        break
                else:
                    break
                j += 1
            break
        i += 1

    if cell is None and coords:
        mibrav = re.search(r"ibrav\s*=\s*(-?\d+)", text, re.IGNORECASE)
        if mibrav:
            ibrav = int(mibrav.group(1))
            celldm = _celldm_from_qe_text(text)
            vecs = _cell_matrix_from_ibrav(ibrav, celldm)
            if vecs is not None:
                cell = np.array(vecs, dtype=float)

    if cell is None or not coords:
        raise ValueError(
            "Input QE incomplet : il faut CELL_PARAMETERS (3 vecteurs) ou ibrav+celldm, "
            "et ATOMIC_POSITIONS (structure de départ ou déjà relaxée)."
        )

    symbols = [c[0] for c in coords]
    frac_or_cart = np.array([[c[1], c[2], c[3]] for c in coords], dtype=float)
    if "crystal" in pos_unit:
        atoms = Atoms(symbols=symbols, scaled_positions=frac_or_cart, cell=cell, pbc=True)
    elif "bohr" in pos_unit:
        atoms = Atoms(symbols=symbols, positions=frac_or_cart / ANG_TO_BOHR, cell=cell, pbc=True)
    elif "alat" in pos_unit:
        # alat positions = coordonnées fractionnaires (identique à crystal)
        # r = x*(a1/alat)*alat + y*(a2/alat)*alat + z*(a3/alat)*alat = x*a1 + y*a2 + z*a3
        atoms = Atoms(symbols=symbols, scaled_positions=frac_or_cart, cell=cell, pbc=True)
    else:
        # angstrom (défaut)
        atoms = Atoms(symbols=symbols, positions=frac_or_cart, cell=cell, pbc=True)

    # Pseudos par symbole
    pseudo_map = {sp["symbol"]: sp["pseudo"] for sp in species}
    mass_map = {sp["symbol"]: sp["mass"] for sp in species}

    tpl["species"] = species
    tpl["pseudo_map"] = pseudo_map
    tpl["mass_map"] = mass_map
    tpl["nat"] = len(atoms)
    tpl["ntyp"] = len({s for s in symbols})
    tpl["calculation"] = None
    mcalc = re.search(r"calculation\s*=\s*'([^']+)'", text, re.IGNORECASE)
    if mcalc:
        tpl["calculation"] = mcalc.group(1)
    return {"template": tpl, "atoms": atoms}


def build_pw_input(
    *,
    calculation: str,
    prefix: str,
    outdir: str,
    pseudo_dir: str,
    species: list[dict],
    positions: list[dict],
    cell: list[list[float]],
    ecutwfc: float = 40.0,
    ecutrho: float = 320.0,
    kpoints: tuple[int, int, int] = (2, 2, 2),
    occupations: str | None = None,
    smearing: str | None = None,
    degauss: float | None = None,
    conv_thr: str = "1.0d-8",
    mixing_beta: float | None = None,
    forc_conv_thr: float | None = None,
    ibrav: int = 0,
    celldm: dict[int, float] | None = None,
    nspin: int | None = None,
) -> str:
    """Génère un input pw.x (scf / relax) — structure optimisée (ibrav+celldm ou ibrav=0)."""
    calc = calculation.strip().lower()
    nat = len(positions)
    ntyp = len(species)
    use_bravais = ibrav > 0 and celldm and celldm.get(1)
    lines = [
        "&CONTROL",
        f"  calculation   = '{calc}'",
        f"  prefix        = '{prefix}'",
        "  restart_mode  = 'from_scratch'",
        f"  outdir        = '{outdir}'",
        f"  pseudo_dir    = '{pseudo_dir}'",
        "  verbosity     = 'high'",
        "  tprnfor       = .true.",
    ]
    if calc in {"relax", "vc-relax"} and forc_conv_thr is not None:
        lines.append(f"  forc_conv_thr = {forc_conv_thr}")
    lines.append("/")
    lines += [
        "&SYSTEM",
        f"  ibrav       = {ibrav if use_bravais else 0}",
        f"  nat         = {nat}",
        f"  ntyp        = {ntyp}",
        f"  ecutwfc     = {ecutwfc}",
        f"  ecutrho     = {ecutrho}",
    ]
    if use_bravais and celldm:
        for idx in sorted(celldm):
            lines.append(f"  celldm({idx})   = {celldm[idx]:.8f}")
    if nspin is not None:
        lines.append(f"  nspin       = {nspin}")
    if occupations:
        lines.append(f"  occupations = '{occupations}'")
    if smearing:
        lines.append(f"  smearing    = '{smearing}'")
    if degauss is not None:
        lines.append(f"  degauss     = {degauss}")
    lines += [
        "/",
        "&ELECTRONS",
        f"  conv_thr    = {conv_thr}",
    ]
    if mixing_beta is not None:
        lines.append(f"  mixing_beta = {mixing_beta}")
    lines.append("/")
    if calc == "relax":
        lines += ["&IONS", "  ion_dynamics = 'bfgs'", "/"]
    lines.append("")
    lines.append("ATOMIC_SPECIES")
    for sp in species:
        lines.append(f"  {sp['symbol']}  {sp.get('mass', 1.0)}  {sp['pseudo']}")
    lines.append("")
    if not use_bravais:
        lines.append("CELL_PARAMETERS angstrom")
        for row in cell:
            lines.append(f"  {row[0]:.10f}  {row[1]:.10f}  {row[2]:.10f}")
        lines.append("")
    pos_unit = positions[0].get("unit", "crystal") if positions else "crystal"
    lines.append(f"ATOMIC_POSITIONS {pos_unit}")
    for p in positions:
        lines.append(f"  {p['symbol']}  {p['x']:.10f}  {p['y']:.10f}  {p['z']:.10f}")
    kx, ky, kz = kpoints
    lines.append("K_POINTS automatic")
    lines.append(f"  {kx} {ky} {kz} 0 0 0")
    lines.append("")
    return "\n".join(lines)


def build_pw_scf_input(
    *,
    prefix: str,
    species: list[dict],
    positions: list[dict],
    cell: list[list[float]],
    ecutwfc: float = 40.0,
    ecutrho: float = 320.0,
    kpoints: tuple[int, int, int] = (2, 2, 2),
    pseudo_dir: str = "../pseudos",
    occupations: str | None = None,
    smearing: str | None = None,
    degauss: float | None = None,
    conv_thr: str = "1.0d-8",
    mixing_beta: float | None = None,
    outdir: str = "./tmp",
) -> str:
    """Génère un input pw.x SCF (cellule en angstroms) pour forces ALAMODE."""
    return build_pw_input(
        calculation="scf",
        prefix=prefix,
        outdir=outdir,
        pseudo_dir=pseudo_dir,
        species=species,
        positions=positions,
        cell=cell,
        ecutwfc=ecutwfc,
        ecutrho=ecutrho,
        kpoints=kpoints,
        occupations=occupations,
        smearing=smearing,
        degauss=degauss,
        conv_thr=conv_thr,
        mixing_beta=mixing_beta,
    )


def write_followup_relax_scf_inputs(
    *,
    mat: str,
    prefix: str,
    pseudo_dir: str,
    opt_dir: Path,
    inputs_dir: Path,
    species: list[dict],
    positions: list[dict],
    cell: list[list[float]],
    qe_tpl: dict,
) -> dict[str, str]:
    """
    Après vc-relax/relax convergé : inputs/{Mat}/{Mat}-relax.in et -scf.in
    avec outdir outputs/.../optimisation/relax et .../scf.
    """
    mat = mat.strip()
    relax_od = opt_dir / "relax"
    scf_od = opt_dir / "scf"
    relax_od.mkdir(parents=True, exist_ok=True)
    scf_od.mkdir(parents=True, exist_ok=True)

    tpl = dict(qe_tpl)
    if not tpl.get("ibrav"):
        from config import INPUTS

        vcref = INPUTS / mat / f"{mat}-vc-relax.in"
        if vcref.is_file():
            tpl.update({k: v for k, v in parse_qe_scf_template(vcref).items() if v is not None})

    ibrav, celldm = _structure_format_from_template(tpl, cell)
    kw = dict(
        prefix=prefix,
        pseudo_dir=pseudo_dir,
        species=species,
        positions=positions,
        cell=cell,
        ecutwfc=float(tpl.get("ecutwfc", 60.0)),
        ecutrho=float(tpl.get("ecutrho", 480.0)),
        kpoints=tuple(tpl.get("kpoints") or (8, 8, 8)),
        occupations=tpl.get("occupations") or "smearing",
        smearing=tpl.get("smearing") or "cold",
        degauss=tpl.get("degauss", 0.02),
        conv_thr=str(tpl.get("conv_thr", "1.0d-8")),
        mixing_beta=tpl.get("mixing_beta", 0.7),
        forc_conv_thr=tpl.get("forc_conv_thr"),
        ibrav=ibrav,
        celldm=celldm,
        nspin=tpl.get("nspin"),
    )
    relax_text = build_pw_input(
        calculation="relax",
        outdir=str(relax_od.resolve()),
        **kw,
    )
    scf_text = build_pw_input(
        calculation="scf",
        outdir=str(scf_od.resolve()),
        **kw,
    )
    inputs_dir.mkdir(parents=True, exist_ok=True)
    relax_name = f"{mat}-relax.in"
    scf_name = f"{mat}-scf.in"
    (inputs_dir / relax_name).write_text(relax_text, encoding="utf-8")
    (inputs_dir / scf_name).write_text(scf_text, encoding="utf-8")
    (opt_dir / relax_name).write_text(relax_text, encoding="utf-8")
    (opt_dir / scf_name).write_text(scf_text, encoding="utf-8")
    return {
        "relax": f"inputs/{mat}/{relax_name}",
        "scf": f"inputs/{mat}/{scf_name}",
    }

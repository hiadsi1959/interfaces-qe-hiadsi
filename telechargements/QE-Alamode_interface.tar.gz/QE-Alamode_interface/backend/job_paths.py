"""Emplacement des jobs : outputs/<matériau>/<job_id> (work/ = legacy)."""
from __future__ import annotations

from pathlib import Path

from config import OUTPUTS, WORK
from materials import _safe_name


def infer_material_from_job_id(job_id: str) -> str | None:
    if "_" not in job_id:
        return None
    tail = job_id.rsplit("_", 1)[-1]
    if tail and not tail.isdigit() and tail.lower() != "material":
        return _safe_name(tail)
    return None


def ensure_job_subdirs(job: Path) -> None:
    job.mkdir(parents=True, exist_ok=True)
    (job / "qe").mkdir(exist_ok=True)
    (job / "alamode").mkdir(exist_ok=True)
    (job / "results").mkdir(exist_ok=True)


def _qe_activity_mtime(job: Path) -> float:
    qe = job / "qe"
    if not job.is_dir() or not qe.is_dir():
        return 0.0
    best = 0.0
    for f in qe.glob("disp_*.out"):
        try:
            best = max(best, f.stat().st_mtime)
        except OSError:
            pass
    for name in (".pw_run.lock",):
        p = qe / name
        if p.is_file():
            try:
                best = max(best, p.stat().st_mtime)
            except OSError:
                pass
    return best


def find_job_dir(job_id: str) -> Path | None:
    legacy = WORK / job_id if WORK.is_dir() and (WORK / job_id).is_dir() else None
    out_dir: Path | None = None
    if OUTPUTS.is_dir():
        for mat_dir in sorted(OUTPUTS.iterdir(), key=lambda p: p.name.lower()):
            if not mat_dir.is_dir() or mat_dir.name == "optimisation":
                continue
            cand = mat_dir / job_id
            if cand.is_dir():
                out_dir = cand
                break
    if legacy is not None and out_dir is not None:
        return legacy if _qe_activity_mtime(legacy) >= _qe_activity_mtime(out_dir) else out_dir
    return out_dir or legacy


def job_dir(job_id: str, *, material: str | None = None, create: bool = False) -> Path:
    found = find_job_dir(job_id)
    if found is not None:
        if create:
            ensure_job_subdirs(found)
        return found
    mat = _safe_name(material) if material else infer_material_from_job_id(job_id)
    if mat:
        d = OUTPUTS / mat / job_id
    else:
        d = WORK / job_id
    if create:
        ensure_job_subdirs(d)
    return d


def iter_job_dirs():
    seen: set[str] = set()
    if WORK.is_dir():
        for p in WORK.iterdir():
            if p.is_dir() and (p / "meta.json").is_file() and p.name not in seen:
                seen.add(p.name)
                yield p
    if OUTPUTS.is_dir():
        for mat_dir in OUTPUTS.iterdir():
            if not mat_dir.is_dir() or mat_dir.name == "optimisation":
                continue
            for p in mat_dir.iterdir():
                if p.is_dir() and (p / "meta.json").is_file() and p.name not in seen:
                    seen.add(p.name)
                    yield p

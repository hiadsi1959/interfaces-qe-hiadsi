# QE–ALAMODE — Proposition 1  
## Interface + binaires ALAMODE (`alm` / `anphon`)

**Auteur :** S. Hiadsi · LMESM / Faculté de Physique / USTO-MB · Oran, Algérie  
**Email :** said.hiadsi@univ-usto.dz

Ce pack correspond à la **proposition 1** de déploiement : l’interface web, les exécutables ALAMODE déjà compilés, le backend, et des dossiers `work/` / `outputs/` vides.

Voir aussi : [README_DEPLOIEMENT.md](README_DEPLOIEMENT.md) (comparaison des 3 propositions).

---

## Contenu de l’archive

```
QE-Alamode_prop1_…/
  README.md                 ← ce guide (configuration autre PC)
  README_DEPLOIEMENT.md
  interface/                ← pages web
  backend/                  ← API Flask
  bin/alm , bin/anphon      ← ALAMODE (liés à Intel oneAPI)
  work/                     ← vide (jobs)
  outputs/                  ← vide (export)
  inputs/                   ← exemples (ex. Si)
  pseudos/                  ← UPF
  requirements.txt
  INSTALLER_AUTRE_PC.sh
  CONFIGURER.sh
  DEMARRER.sh
  ARRETER.sh
  scripts/                  ← utilitaires (resume_job, etc.)
```

---

## Ce qu’il faut déjà sur l’autre PC

| Prérequis | Obligatoire ? | Notes |
|-----------|---------------|--------|
| Linux **x86_64** | Oui | Ubuntu 22.04+ recommandé |
| **Quantum ESPRESSO** (`pw.x`) | **Oui** | Non inclus dans ce pack |
| **Intel oneAPI** (MKL + MPI runtime) | **Oui** | Les `alm`/`anphon` de ce pack en dépendent |
| Python **3.10+** | Oui | Flask, ASE, NumPy |
| `curl`, navigateur | Oui | Démarrage / UI |

Sans oneAPI, `ldd bin/alm` affichera des libs `not found` (MKL / MPI).

---

## Configuration pas à pas (autre PC)

### 1. Extraire l’archive

```bash
tar -xzf QE-Alamode_prop1_interface_bin_YYYYMMDD_HHMMSS.tar.gz
cd QE-Alamode_prop1_interface_bin_YYYYMMDD_HHMMSS
# ou le nom de dossier indiqué à l’extraction
```

### 2. Charger Intel oneAPI

```bash
# chemin typique :
source /opt/intel/oneapi/setvars.sh

# Vérifier que les libs ALAMODE sont résolues :
ldd bin/alm | grep -i 'not found' || echo "alm : libs OK"
ldd bin/anphon | grep -i 'not found' || echo "anphon : libs OK"
```

Si `not found` : installer le [Intel oneAPI Base Toolkit](https://www.intel.com/content/www/us/en/developer/tools/oneapi/base-toolkit.html) (au minimum MKL + MPI), puis `source …/setvars.sh` à chaque session (ou dans `~/.bashrc`).

### 3. Repérer Quantum ESPRESSO

```bash
# Exemple si QE est dans $HOME/q-e-qe-7.5 :
ls $HOME/q-e-qe-7.5/bin/pw.x
# ou
which pw.x
```

Notez le dossier qui contient `pw.x` (ex. `/home/user/q-e-qe-7.5/bin`).

### 4. Installer les dépendances Python

```bash
chmod +x INSTALLER_AUTRE_PC.sh DEMARRER.sh ARRETER.sh CONFIGURER.sh
./INSTALLER_AUTRE_PC.sh --install-deps
```

Ou manuellement :

```bash
python3 -m pip install --user -r requirements.txt
```

### 5. Configurer les chemins (`config_local.sh`)

**Mode interactif (recommandé) :**

```bash
source /opt/intel/oneapi/setvars.sh
./INSTALLER_AUTRE_PC.sh
```

Le script demande :

1. **Dossier bin QE** → chemin vers `pw.x`  
2. **Dossier bin ALAMODE** → laissez le défaut `./bin` (ou le chemin absolu du pack)  
3. **Pseudos** → défaut `./pseudos`  
4. **Port** → défaut `5020`

**Mode non interactif :**

```bash
source /opt/intel/oneapi/setvars.sh
export QE_BIN_DIR=/chemin/vers/qe/bin          # obligatoire : contient pw.x
export ALAMODE_BIN_DIR=$PWD/bin                # alm + anphon de ce pack
export PSEUDO_DIR=$PWD/pseudos
export QEALAMODE_PORT=5020
./INSTALLER_AUTRE_PC.sh --non-interactif
```

Cela écrit `config_local.sh` :

```bash
export QE_BIN_DIR="..."
export ALAMODE_BIN_DIR="..."
export PSEUDO_DIR="..."
export QEALAMODE_PORT="5020"
export OMP_NUM_THREADS=2
export QE_NPROC=2
```

Reconfiguration ultérieure sans tout réinstaller :

```bash
./CONFIGURER.sh
```

### 6. Démarrer l’interface

```bash
source /opt/intel/oneapi/setvars.sh   # si pas déjà dans le shell
source ./config_local.sh             # optionnel (DEMARRER le source déjà)
./DEMARRER.sh
```

Ouvrir : **http://127.0.0.1:5020/**

Arrêt :

```bash
./ARRETER.sh
```

### 7. Vérification rapide

```bash
source config_local.sh
source /opt/intel/oneapi/setvars.sh
"$QE_BIN_DIR/pw.x" -h | head -2
"$ALAMODE_BIN_DIR/alm" 2>&1 | head -3
curl -sf http://127.0.0.1:5020/api/health | python3 -m json.tool
```

Dans l’UI : Accueil → Optimisation / Calculs → matériau **Si** (input fourni dans `inputs/`).

---

## Rappel important (Prop. 1)

- Ce pack **inclut** ALAMODE (`bin/`) mais **pas** Quantum ESPRESSO.  
- Les binaires `alm` / `anphon` **exigent Intel oneAPI** sur la machine cible.  
- Les calculs s’écrivent dans `work/<job_id>/` ; l’export va dans `outputs/<matériau>/`.  
- Pour une machine **sans** oneAPI, préférer la **proposition 2** (portable) ou **3** (libs emballées) — voir `README_DEPLOIEMENT.md`.

---

## Dépannage

| Problème | Piste |
|----------|--------|
| `ldd bin/alm` → `libmkl_… not found` | `source /opt/intel/oneapi/setvars.sh` ou installer oneAPI |
| `pw.x introuvable` | Refaire `./CONFIGURER.sh` avec le bon `QE_BIN_DIR` |
| Port 5020 occupé | `export QEALAMODE_PORT=5021` puis `./CONFIGURER.sh` / `./DEMARRER.sh` |
| `ModuleNotFoundError: flask` | `pip install -r requirements.txt` |
| API ne démarre pas | Voir `logs/api.log` |

---

## Contact

S. Hiadsi — LMESM / Faculté de Physique / USTO-MB, Oran, Algérie  
said.hiadsi@univ-usto.dz

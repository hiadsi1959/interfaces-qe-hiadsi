#!/usr/bin/env bash
set -euo pipefail
cd /home/hiadsi/thermo_pw
echo "=== capture index with verbose ==="
curl -s -o /tmp/idx.html http://127.0.0.1:5010/ || true
SIZE=$(wc -c < /tmp/idx.html || echo 0)
echo "size: $SIZE"
PCK=$(grep -c p1SkipPhononsCheckbox /tmp/idx.html || echo 0)
echo "p1 checkbox present: $PCK"
SRC=$(grep -oE 'src="/app_v2\.min\.js"' /tmp/idx.html || true)
echo "body script src: ${SRC:-none}"
echo -n "health: "
curl -s http://127.0.0.1:8000/api/health || echo "no health"
echo ""
echo "ping google: $(curl -s -o /dev/null -w '%{http_code}' http://google.com || echo no)"
echo "whoami: $(whoami)"
echo "DISPLAY=${DISPLAY:-none} WAYLAND=${WAYLAND_DISPLAY:-none}"

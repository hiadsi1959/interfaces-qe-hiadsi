#!/usr/bin/env bash
# =============================================================================
# env/local.sh — configuration THERMO_PW pour ce PC
#
# Genere automatiquement par config_autre_pc.sh le 2026-10-24 a 07:45
# Systeme : Ubuntu 25.10
# CPU     : 4 coeurs — Intel(R) Core(TM) i7-7500U CPU @ 2.70GHz
# RAM     : 11Gi
#
# DEMARRER.sh charge ce fichier automatiquement s'il existe.
# Editez les chemins ci-dessous si votre configuration change.
# =============================================================================

export USER_HOME="${USER_HOME:-$HOME}"

# --- Quantum ESPRESSO (binaires pw.x, ph.x, thermo_pw.x, etc.) ---
export THERMO_QE_BIN="/home/hiadsi/q-e-qe-7.5/bin"

# --- Racine du depot (auto-detectee si non definie) ---
# export THERMO_REPO_ROOT="/home/hiadsi/thermo_pw"

# --- Repertoires de travail ---
export THERMO_WORK_ROOT="${THERMO_WORK_ROOT:-/home/hiadsi/thermo_pw/work}"
export THERMO_INPUTS_DIR="${THERMO_INPUTS_DIR:-/home/hiadsi/thermo_pw/inputs}"
export THERMO_OUTPUTS_DIR="${THERMO_OUTPUTS_DIR:-/home/hiadsi/thermo_pw/outputs}"

# --- Pseudopotentiels ---
export THERMO_PSEUDOS_DIR="${THERMO_PSEUDOS_DIR:-/home/hiadsi/thermo_pw/pseudos/PBE}"

# --- MPI ---
export THERMO_MPI_NPROC="4"
export OMP_NUM_THREADS="1"

# Plafond memoire par sous-process MPI (evite OOM-kill de l'API)
export THERMO_MPI_RLIMIT_AS_BYTES="4294967296"

# --- Serveur Flask ---
export THERMO_HOST="0.0.0.0"
export THERMO_PORT="8000"
# export THERMO_NO_BROWSER="1"  # decommenter pour serveur headless (SSH)

# --- libfabric / OFI (contournement crash MPI_Init) ---
export THERMO_FI_PROVIDER="tcp"
export THERMO_I_MPI_FABRICS="shm"

# --- Autres outils (optionnel) ---
# export INTERFACE_QE_V1="$USER_HOME/Interface-QE_v1"
# export GEN_INPUTS_QE="$USER_HOME/generation_inputs-QE"
# export GEN_PSEUDOS="$USER_HOME/generation_pseudos"

# --- PATH (ajoute QE au PATH si absent) ---
case ":$PATH:" in
  *:"$THERMO_QE_BIN":*) ;;
  *) export PATH="$PATH:$THERMO_QE_BIN" ;;
esac

/* ==========================================================================
   test_api_payload.js — ce que l'UI envoie RÉELLEMENT à /api/pipeline/run.

   Contexte (bug d'octobre 2026) : la case « Sans DFPT » de P1/P5 remplissait
   bien `body.skip_phonons` dans app_v2.js, mais `ThermoPipeline.runPipeline`
   déstructurait une liste fixe de champs et jetait `skip_phonons` en
   reconstruisant le JSON. Le job partait donc en DFPT complet (log « Étape
   dominante : ph », 394 j) alors que les tuiles annonçaient 2 j 8 h.

   Le test charge api_v2.js tel quel dans un contexte Node avec un `fetch`
   espion : aucun serveur, aucun calcul QE.

   Usage : node test_api_payload.js
   ========================================================================== */
"use strict";

const fs = require("fs");
const path = require("path");
const assert = require("assert");

const captured = [];

globalThis.window = {
  location: { protocol: "http:", host: "127.0.0.1:8000" },
  AbortController,
  setTimeout,
  clearTimeout,
};
globalThis.fetch = async (url, init) => {
  captured.push({ url: String(url), body: (init && init.body) || "" });
  return {
    ok: true,
    status: 202,
    headers: { get: () => "application/json" },
    json: async () => ({ job_id: "stub-job", status: "queued" }),
    text: async () => "",
  };
};

const SRC = fs.readFileSync(path.join(__dirname, "interface", "api_v2.js"), "utf8");
// eslint-disable-next-line no-eval
eval(SRC);

const Pipeline = globalThis.window.ThermoPipeline;
const BASE = {
  material_id: "GdFeO3",
  profile_id: "P1",
  scf_in_basename: "GdFeO3_scf.in",
  nproc: 4,
};

function lastBody() {
  return JSON.parse(captured[captured.length - 1].body);
}

(async () => {
  assert(Pipeline && typeof Pipeline.runPipeline === "function", "ThermoPipeline absent");

  // 1) Case cochée sur P1 → le flag doit survivre à la sérialisation.
  captured.length = 0;
  await Pipeline.runPipeline({ ...BASE, skip_phonons: true });
  let body = lastBody();
  assert.strictEqual(body.skip_phonons, true, "skip_phonons perdu pour P1");
  assert.strictEqual(body.profile_id, "P1");
  assert.strictEqual(body.nproc, 4);
  console.log("[OK] P1 cochée  → POST contient skip_phonons:true");

  // 2) Case décochée → aucune clé (le profil garde son défaut : DFPT inclus).
  captured.length = 0;
  await Pipeline.runPipeline({ ...BASE });
  body = lastBody();
  assert(!("skip_phonons" in body), "skip_phonons envoyé sans la case");
  console.log("[OK] P1 décochée → POST sans skip_phonons");

  // 3) P5 : même contrat (le flag vient de la case du panneau extras).
  captured.length = 0;
  await Pipeline.runPipeline({ ...BASE, profile_id: "P5", extra_whats: ["plot_bz"], skip_phonons: true });
  body = lastBody();
  assert.strictEqual(body.skip_phonons, true, "skip_phonons perdu pour P5");
  assert.deepStrictEqual(body.extra_whats, ["plot_bz"]);
  console.log("[OK] P5 cochée  → POST contient skip_phonons:true + extra_whats");

  // 4) Estimation des tuiles : même information dans la query string.
  captured.length = 0;
  await Pipeline.listProfiles("GdFeO3", "GdFeO3_scf.in", 4, null, true);
  assert(
    /[?&]skip_phonons=1(&|$)/.test(captured[captured.length - 1].url),
    "listProfiles ne transmet pas skip_phonons"
  );
  captured.length = 0;
  await Pipeline.listProfiles("GdFeO3", "GdFeO3_scf.in", 4, null, false);
  assert(
    !/skip_phonons/.test(captured[captured.length - 1].url),
    "listProfiles envoie skip_phonons sans la case"
  );
  console.log("[OK] tuiles → /profiles reçoit skip_phonons=1 seulement si cochée");

  console.log("[PASS] contrat API runPipeline / listProfiles conforme");
})().catch((e) => {
  console.error("[FAIL]", e.message);
  process.exit(1);
});

"""Couverture backend du flag ``skip_phonons`` (option « sans phonons »).

Cible l'option P1 « Sans phonons » : qu'un job P1 avec
``skip_phonons=True`` ne lance ni ph.x, ni q2r, ni matdyn.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from pipeline import PipelineJob


@pytest.fixture
def p1_job(tmp_path: Path) -> PipelineJob:
    from pipeline import PipelineJob

    scf_in = tmp_path / "scf.in"
    scf_in.write_text("&control/\n", encoding="utf-8")
    job = PipelineJob(
        material_id="testmat",
        profile_id="P1",
        scf_in_basename=scf_in.name,
        nproc=1,
        user_work_dir=str(tmp_path),
    )
    job.job_id = "test-p1-skip-phonons"
    job.skip_phonons = True  # option « sans phonons »
    return job


def test_p1_skip_phonons_skips_phonon_chain_and_does_not_parse(p1_job: PipelineJob, tmp_path: Path):
    from unittest.mock import patch

    with patch.object(p1_job, "_run_phonon_chain") as mock_chain, \
            patch.object(p1_job, "_intermediate_parse") as mock_parse, \
            patch.object(p1_job, "_append_log") as mock_log:

        p1_job._execute()

    mock_chain.assert_not_called()
    mock_parse.assert_not_called()
    # Le profil P1 est lancé : _execute entre dans la série, puis saute la
    # chaîne phonon (flag skip_phonons) et s'arrête sans relancer ph.x/q2r/matdyn.
    # Le statut de l'erreur est attendu car le job s'arrête après le SCF @ V₀
    # (la chaîne phonon est sautée) ; c'est le comportement déclaratif du flag.
    assert p1_job.status in ("running", "error")


def test_p1_skip_phonons_is_overridable(p1_job: PipelineJob) -> None:
    assert p1_job.skip_phonons is True
    p1_job.skip_phonons = False
    assert p1_job.skip_phonons is False

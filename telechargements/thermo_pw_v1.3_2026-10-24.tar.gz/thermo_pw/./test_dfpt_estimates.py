"""Régression : estimations durée/espace « sans DFPT » de P1 et P5.

Ce test ne lance AUCUN calcul QE et n'écrit aucun fichier de travail. Il
compare, pour P1 et P5, l'estimation du profil complet et celle du même profil
avec ``skip_phonons=True`` — exactement ce que le backend transmet à
``estimate_runtime`` / ``estimate_storage`` quand la case « Sans DFPT » est
cochée (voir ``pipeline.py`` : ``api_pipeline_run`` et
``get_runtime_estimate_route``).

Ce qu'il verrouille (bug d'octobre 2026) : un run P1 sans DFPT annonçait encore
392 j et 82 Gio de scratch, parce que ni ``estimate_runtime`` ni
``estimate_storage`` ne lisaient le drapeau.

Usage :
    venv/bin/python test_dfpt_estimates.py
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "backend"))

import pipeline  # noqa: E402  (profils réels + accès aux pseudos)
from machine_profile import MachineProfile  # noqa: E402
from runtime_estimate import (  # noqa: E402
    estimate_runtime,
    parse_material_descriptors,
)
from storage_estimate import derive_cell_facts, estimate_storage  # noqa: E402

SCF = ROOT / "BaTiO3" / "BaTiO3" / "BaTiO3_scf.in"

# Machine figée (i7-like, 2 cœurs physiques / 4 threads) : les assertions
# portent sur des rapports, pas sur des valeurs absolues, mais un profil machine
# constant garde le test reproductible d'une machine à l'autre.
MACHINE = MachineProfile(
    cpu_model="fixture test",
    cores_physical=2,
    cores_logical=4,
    cores_available=2,
    smt_ratio=2.0,
    ram_total_mb=8000,
    ram_available_mb=6000,
    speed_index=1.0,
)

# Étapes DFPT que l'option doit faire disparaître de l'estimation.
PHONON_STEPS = {"scf_phonon", "ph", "q2r", "matdyn"}
SKIP_PROFILES = ("P1", "P5")


def _estimate(profile_id: str, skip: bool):
    prof = dict(pipeline.get_profile(profile_id))
    prof["skip_phonons"] = skip
    runtime = estimate_runtime(
        profile_id=profile_id,
        profile=prof,
        descriptors=DESC,
        machine=MACHINE,
        nproc=2,
    )
    storage = estimate_storage(
        profile_id=profile_id,
        profile=prof,
        descriptors=DESC,
        cell_facts=FACTS,
    )
    return runtime, storage


def _steps(runtime) -> set[str]:
    return {s.step for s in runtime.steps}


def check_profile(profile_id: str) -> None:
    full_rt, full_st = _estimate(profile_id, skip=False)
    skip_rt, skip_st = _estimate(profile_id, skip=True)

    # 1) Le profil complet lance bien la chaîne DFPT estimée.
    missing_full = PHONON_STEPS - _steps(full_rt)
    assert not missing_full, (
        f"{profile_id}: étapes DFPT absentes du profil complet : {sorted(missing_full)}"
    )

    # 2) Sans DFPT, plus aucune étape ph.x/q2r.x/matdyn.x n'est estimée.
    leftover = PHONON_STEPS & _steps(skip_rt)
    assert not leftover, (
        f"{profile_id}: skip_phonons laisse des étapes DFPT dans l'ETA : {sorted(leftover)}"
    )

    # 3) Le reste du run est toujours estimé (on ne renvoie pas une durée nulle).
    assert skip_rt.total_seconds > 0, f"{profile_id}: durée nulle après skip_phonons"
    assert skip_rt.steps, f"{profile_id}: aucune étape restante après skip_phonons"

    # 4) Durée strictement réduite.
    assert skip_rt.total_seconds < full_rt.total_seconds, (
        f"{profile_id}: durée sans DFPT ({skip_rt.total_seconds:.0f} s) "
        f">= durée complète ({full_rt.total_seconds:.0f} s)"
    )

    # 5) Disque : le scratch _ph0 disparaît et le pic baisse.
    full_ph0 = [c.name for c in full_st.components if c.name.startswith("_ph0")]
    skip_ph0 = [c.name for c in skip_st.components if c.name.startswith("_ph0")]
    assert full_ph0, f"{profile_id}: aucune composante _ph0 dans le profil complet"
    assert not skip_ph0, f"{profile_id}: _ph0 encore estimé sans DFPT : {skip_ph0}"
    assert skip_st.peak_bytes < full_st.peak_bytes, (
        f"{profile_id}: pic disque sans DFPT ({skip_st.peak_bytes}) "
        f">= pic complet ({full_st.peak_bytes})"
    )

    full_h = full_rt.total_seconds / 3600.0
    skip_h = skip_rt.total_seconds / 3600.0
    print(
        f"[OK] {profile_id}: durée {full_h:9.1f} h -> {skip_h:9.1f} h "
        f"(x{full_rt.total_seconds / max(1.0, skip_rt.total_seconds):.1f}) · "
        f"pic disque {full_st.peak_bytes / 1024**3:7.2f} Gio -> "
        f"{skip_st.peak_bytes / 1024**3:7.2f} Gio · "
        f"étapes restantes : {', '.join(sorted(_steps(skip_rt)))}"
    )


def check_job_estimate_uses_flag() -> None:
    """L'ETA journalisée AU LANCEMENT doit aussi voir le drapeau.

    C'est le chemin qui a produit le log « Durée estimée (P1, nproc=4) :
    394 j … Étape dominante : ph » alors que la tuile annonçait 2 j 8 h.
    Le job est construit sans ``start()`` : aucun calcul n'est lancé.
    """
    job = pipeline.PipelineJob(
        material_id="GdFeO3",
        profile_id="P1",
        scf_in_basename="GdFeO3_scf.in",
        nproc=2,
        skip_phonons=True,
    )
    assert job.skip_phonons is True
    assert job.profile.get("skip_phonons") is True, (
        "le drapeau n'atteint pas le profil lu par _compute_runtime_estimate"
    )
    est = estimate_runtime(
        profile_id="P1",
        profile=job.profile,
        descriptors=DESC,
        machine=MACHINE,
        nproc=2,
    )
    assert "ph" not in _steps(est), "l'ETA de lancement inclut encore ph.x"
    assert est.dominant_step != "ph", (
        f"étape dominante du job = {est.dominant_step}, ph attendu absent"
    )
    print(
        f"[OK] job P1 skip_phonons=True : ETA {est.total_seconds / 3600.0:.1f} h, "
        f"dominante = {est.dominant_step}"
    )


def check_overridable_scope() -> None:
    """Seuls P1 et P5 déclarent l'option ; le reste l'ignore côté route."""
    for pid in SKIP_PROFILES:
        assert pipeline.get_profile(pid).get("skip_phonons_overridable") is True, (
            f"{pid}: skip_phonons_overridable doit rester activé"
        )
    for pid in ("P2", "P3", "P4"):
        assert not pipeline.get_profile(pid).get("skip_phonons_overridable"), (
            f"{pid}: skip_phonons ne doit pas être surchargeable"
        )
    print("[OK] périmètre skip_phonons = P1, P5 uniquement")


def check_nproc_guidance() -> None:
    """Le guidage nproc doit distinguer SMT et surnombre de threads."""
    smt = " ".join(MACHINE.warnings_for(4))
    over = " ".join(MACHINE.warnings_for(6))
    assert "SMT" in smt and "cœurs physiques" in smt, smt
    assert "threads matériels" in over, over
    assert not MACHINE.warnings_for(2), "nproc=2 ne doit produire aucun avertissement nproc"
    print("[OK] guidage nproc : SMT (4) vs surnombre (6), silence à nproc=2")


def main() -> int:
    if not SCF.is_file():
        print(f"[FAIL] scf.in de référence absent : {SCF}", file=sys.stderr)
        return 2
    print(f"[INFO] scf.in de référence : {SCF.relative_to(ROOT)}")
    for pid in SKIP_PROFILES:
        check_profile(pid)
    check_job_estimate_uses_flag()
    check_overridable_scope()
    check_nproc_guidance()
    print("[PASS] estimations sans DFPT conformes pour P1 et P5")
    return 0


DESC = parse_material_descriptors(
    pw_path=SCF if SCF.is_file() else None,
    material_id="BaTiO3",
)
FACTS = derive_cell_facts(
    SCF.read_text() if SCF.is_file() else "",
    DESC,
    pseudo_dirs=[Path(pipeline.cfg.PSEUDOS_DIR)],
)


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PIDFILE="$HERE/logs/api.pid"
if [[ -f "$PIDFILE" ]]; then
  pid=$(cat "$PIDFILE")
  if kill -0 "$pid" 2>/dev/null; then
    kill "$pid" || true
    echo "  API arrêtée (pid $pid)."
  fi
  rm -f "$PIDFILE"
fi
pkill -f "$HERE/backend/api_server.py" 2>/dev/null || true
sleep 0.3
echo "  Aucun api_server QE–ALAMODE actif (nettoyage)."

# Guide scientifique — chaque calcul QE–ALAMODE

**Interface :** http://127.0.0.1:5020/ · **Démarrage :** `./DEMARRER.sh`

> Ce guide s’ouvre **automatiquement** à chaque **Nouveau job** sur l’onglet Calculs (désactivable via « Ne plus ouvrir automatiquement »).

> **κ_L publiable :** supercellule ≥ **2×2×2** (idéalement **3×3×3**) · **NORDER = 2** · tous les `disp_*.out` en **JOB DONE** avant DFSET · puis anphon **phonons** → **rta**. Un DFSET partiel est **refusé** par l’API.

> **PC peu puissant (≤12 Go RAM, dual-core) :** préférez **N=1** pour tester la chaîne ; le **3×3×3** reste le standard **publiable** sur machine puissante (ex. **i9-14900K + 64 Go**).
> Diagnostic : `python3 scripts/verify_dft_nxn.py` · test léger : `python3 scripts/verify_dft_nxn.py --n 1 --run` (API démarrée).

Chaque section = **1 calcul**. Respecter l’ordre numéroté.

---

## Matériel & choix de N×N×N

| N | Atomés (Si) | RAM QE | PC limité (8–12 Go) | Machine puissante (ex. 14900K · 64 Go) | Objectif |
|---|-------------|--------|---------------------|----------------------------------------|---------|
| **1×1×1** | 2 | ~0,5 Go | **idéal pour tester** | utile aussi (smoke test) | Valider DFT + phonons |
| **2×2×2** | 16 | ~2–4 Go | possible si assez de RAM libre | rapide | κ_L indicative |
| **3×3×3** | 54 | **~10 Go** | **déconseillé** (OOM/swap) | **recommandé** — quelques h à ~1–2 j | **κ_L publiable** |

> Le 3×3×3 n’est **pas impossible** : il est **standard** sur une machine du type **Intel Core i9-14900K / Ryzen équivalent + 32–64 Go RAM** (idéalement avec MPI). Il est seulement **inadapté** aux portables peu pourvus en RAM.

```bash
# Sans calcul : que choisir sur CE PC ?
python3 scripts/verify_dft_nxn.py

# Avec calcul léger (N=1) — PC limité
./DEMARRER.sh
python3 scripts/verify_dft_nxn.py --n 1 --run
```

---

## Vue d’ensemble

```
Optimisation          Calculs                    Résultats
─────────────         ───────                    ─────────
0. VC-RELAX    →      1. SCF (Utiliser)    →     Fiche technique
   RELAX (opt.)        2. Supercellules             Grandeurs
   SCF                 3. Forces QE (tous les lots)
                       4. alm  (NORDER=2 pour κ_L)
                       5. anphon (phonons → rta)
                       6. Export
```

---

## 0a · VC-RELAX — Optimiser la maille et les positions

| | |
|---|---|
| **Où** | Onglet **Optimisation** → carte **VC-RELAX** |
| **But** | Trouver la bonne forme de la boîte (cellule) et la position de chaque atome |
| **Logiciel** | Quantum ESPRESSO `pw.x` |
| **Durée (Si)** | ~10–30 min |

### Étapes interface
1. Choisir le matériau **Si**
2. **Éditer** → vérifier les paramètres (voir ci-dessous)
3. **Lancer**
4. Attendre le message de succès (statut vert)

### Paramètres recommandés (dans l’input)
| Paramètre | Valeur | Note |
|-----------|--------|------|
| `calculation` | `vc-relax` | |
| `ecutwfc` / `ecutrho` | 60 / 480 Ry | |
| `K_POINTS` | 8 8 8 | 10 10 10 pour publication |
| `forc_conv_thr` | 1.0d-4 | Ry/Bohr |
| `press_conv_thr` | 0.5 | kbar |
| `cell_dofree` | `all` | section `&CELL` |

### Fichiers produits
- `inputs/Si/Si-vc-relax.in` (input)
- `outputs/Si/optimisation/` (sorties QE)
- Met à jour `inputs/Si/Si-scf.in` avec la structure optimisée

### Comment savoir que c’est OK ?
- Forces finales < 1 mRy/Bohr
- Pas de message `convergence NOT achieved`

### Commande terminal (optionnel)
```bash
curl -X POST http://127.0.0.1:5020/api/materials/Si/run/vc-relax
```

---

## 0b · RELAX — Optimiser les positions seulement (optionnel)

| | |
|---|---|
| **Où** | Onglet **Optimisation** → carte **RELAX** |
| **But** | Ajuster les positions atomiques, **maille fixe** |
| **Quand l’utiliser** | Si la maille est déjà connue (expérience, littérature) |
| **Durée (Si)** | ~5–15 min |

### Étapes interface
1. Choisir **Si**
2. **Éditer** → `calculation = 'relax'`
3. **Lancer**

### Paramètres clés
| Paramètre | Valeur |
|-----------|--------|
| `calculation` | `relax` |
| `forc_conv_thr` | 1.0d-4 |
| ecut / K_POINTS | identiques au VC-RELAX |

### Fichiers produits
- `inputs/Si/Si-relax.in`
- `outputs/Si/optimisation/`

> **Astuce débutant :** pour Si, VC-RELAX suffit en général. RELAX est optionnel.

---

## 0c · SCF (Optimisation) — Champ auto-cohérent final

| | |
|---|---|
| **Où** | Onglet **Optimisation** → carte **SCF** |
| **But** | Calculer l’énergie et la densité électronique sur la structure optimisée |
| **Prérequis** | VC-RELAX (ou RELAX) terminé |
| **Durée (Si)** | ~2–5 min |

### Étapes interface
1. Choisir **Si**
2. **Éditer** → vérifier `tprnfor = .true.` (obligatoire pour les phonons)
3. **Lancer**
4. Bandeau vert **« SCF prêt → Calculs »** → cliquer **Calculs**

### Paramètres clés
| Paramètre | Valeur | Note |
|-----------|--------|------|
| `calculation` | `scf` | |
| `conv_thr` | 1.0d-8 | |
| `tprnfor` | `.true.` | **obligatoire** |
| `mixing_beta` | 0.7 | 0.3–0.5 si instable |

### Fichiers produits
- `inputs/Si/Si-scf.in` ← **fichier de référence pour tout le reste**
- `outputs/Si/optimisation/scf.out`

---

## 1 · SCF (Calculs) — Charger la structure dans un job

| | |
|---|---|
| **Où** | Onglet **Calculs** → carte **1 · SCF** |
| **But** | Créer un **job** et importer la structure + paramètres QE |
| **Prérequis** | `inputs/Si/Si-scf.in` existe (étape 0c) |
| **Durée** | instantané |

### Étapes interface
1. Choisir matériau **Si**
2. **Nouveau job** (ou sélectionner un job existant)
3. Cliquer **Utiliser SCF**
4. Statut vert : structure importée

### Ce qui se passe
- Copie de la structure dans `work/<job_id>/`
- Création de `structure.cif`, `qe_params.json`, `reference_scf.in`

### Fichiers produits
```
work/20260803_230151_Si/
  structure.cif
  qe_params.json
  qe/reference_scf.in
  meta.json
```

### Commande terminal
```bash
curl -X POST http://127.0.0.1:5020/api/jobs \
  -H "Content-Type: application/json" -d '{"name":"Si","material":"Si"}'
curl -X POST http://127.0.0.1:5020/api/jobs/MON_JOB_ID/use-input \
  -H "Content-Type: application/json" -d '{"path":"inputs/Si/Si-scf.in"}'
```

---

## 2 · Supercellules — Agrandir la maille et créer les déplacements

| | |
|---|---|
| **Où** | Onglet **Calculs** → carte **2 · Supercellules** |
| **But** | Construire une supercellule N×N×N et générer les fichiers `disp_*.in` |
| **Prérequis** | SCF importé (étape 1) |
| **Durée** | ~1 min |

### Étapes interface
1. Remplir les champs :
   | Champ | Valeur débutant | Valeur publication |
   |-------|-----------------|-------------------|
   | nx, ny, nz | 1 1 1 (test rapide) | 3 3 3 |
   | Amplitude (Å) | 0.01 | 0.01 |
   | Nb motifs | 6 (Si 1×1×1) | 12 (Si 3×3×3) |
2. Cliquer **Lancer**
3. Statut vert : motifs créés

### Règle pour le nombre de motifs
```
Nb motifs ≥ 3 × N_atomés_dans_la_supercellule
```
Exemple Si 3×3×3 : 2×27 = 54 atomes → minimum 6 motifs, **12 recommandé**.

### Fichiers produits
```
work/<job_id>/
  supercell.cif
  qe/disp_0000.in … disp_0011.in
  qe/disp_0000.xyz … disp_0011.xyz
  alamode/alm_suggest.in
```

### Pièges débutant
| Erreur | Solution |
|--------|----------|
| 1×1×1 pour κ_L | Trop petit → utiliser 3×3×3 |
| Trop peu de motifs | alm échouera → augmenter à 12+ |

---

## 3 · Forces QE — Calculer les forces atomiques

| | |
|---|---|
| **Où** | Onglet **Calculs** → carte **3 · Forces QE** |
| **But** | Lancer `pw.x` sur chaque `disp_*.in` pour mesurer les forces |
| **Prérequis** | Supercellules créées (étape 2) |
| **Durée** | **la plus longue** — voir tableau ci-dessous |

### Étapes interface
1. **Max jobs** : 8 (selon nombre de cœurs CPU)
2. Cliquer **Lancer pw.x**
3. Attendre que **tous** les motifs convergent
4. Puis cliquer **DFSET** (étape 3b)

### Durées indicatives (Si)
| Supercellule | Atomés | Motifs | Durée / motif | Total | RAM typ. |
|------------|--------|--------|---------------|-------|----------|
| 1×1×1 | 2 | 2–6 | ~2–5 min | ~15–60 min | ~0,5 Go |
| 2×2×2 | 16 | 6–12 | ~15–40 min | ~3–8 h | ~2–4 Go |
| 3×3×3 | 54 | 12 | ~2–4 h* | **1,5–3 jours*** | **~10 Go** |

\*Sur **machine puissante** (ex. i9-14900K + 64 Go, idéalement MPI) : souvent **quelques heures à ~1–2 jours**.  
Sur PC **~11 Go / dual-core** : le 3×3×3 est **déconseillé** (OOM/`SIGTERM`) — validez d’abord en 1×1×1, puis calculez le 3×3×3 ailleurs.

### Vérifier DFT même avec N petit
```bash
python3 scripts/verify_dft_nxn.py              # conseil N selon RAM
python3 scripts/verify_dft_nxn.py --n 1 --run  # test réel 1×1×1
python3 scripts/verify_dft_nxn.py --n 2 --run  # si assez de RAM
python3 scripts/verify_dft_nxn.py --n 3 --job MON_JOB   # contrôle sans recalcul
```

### Comment suivre
```bash
# Progression
cat work/<job_id>/progress.json

# Un calcul terminé ?
grep "JOB DONE" work/<job_id>/qe/disp_0000.out

# Log
tail -f logs/<job_id>_resume.log
```

### Reprendre si interrompu
```bash
nohup ./scripts/resume_job.sh <job_id> Si >> logs/<job_id>_resume.log 2>&1 &
nohup ./scripts/watch_job.sh <job_id> Si >> logs/<job_id>_watch.log 2>&1 &
```

### Fichiers produits
```
work/<job_id>/qe/disp_0000.out … disp_*.out
```

### Comment savoir que c’est OK ?
Chaque `.out` contient la ligne :
```
JOB DONE.
```

---

## 3b · DFSET — Regrouper les forces

| | |
|---|---|
| **Où** | Onglet **Calculs** → carte **3 · Forces QE** → bouton **DFSET** |
| **But** | Assembler toutes les forces dans un fichier ALAMODE |
| **Prérequis** | Tous les `disp_*.out` avec `JOB DONE` |
| **Durée** | ~10 secondes |

### Étapes interface
1. Cliquer **DFSET** (après pw.x)
2. Statut vert

### Fichier produit
```
work/<job_id>/alamode/DFSET
```

### Commande terminal
```bash
curl -X POST http://127.0.0.1:5020/api/jobs/<job_id>/dfset
```

---

## 4 · alm — Constantes de force (IFC)

| | |
|---|---|
| **Où** | Onglet **Calculs** → carte **4 · alm** |
| **But** | Ajuster les constantes de force interatomiques à partir des forces QE |
| **Prérequis** | DFSET créé (étape 3b) |
| **Durée** | ~1–5 min |

### Étapes interface
1. Régler **NORDER** et **Cutoff** :
   | Objectif | NORDER | Cutoff Å |
   |----------|--------|----------|
   | Phonons harmoniques | 1 | 0 |
   | Conductivité κ_L | 2 | 0 ou 6–8 |
2. Cliquer **Préparer**
3. Cliquer **Lancer**
4. Vérifier l’erreur de fit < 2 % (onglet Résultats)

### Fichiers produits
```
work/<job_id>/alamode/
  alm_optimize.in
  alm_optimize.log
  <job_id>.fcs      ← constantes de force
  <job_id>.xml      ← structure + IFC
```

### Comment savoir que c’est OK ?
- Erreur de fit < 2 %
- 0 mode imaginaire à Γ (vérifier dans Résultats)

### Commande terminal
```bash
curl -X POST http://127.0.0.1:5020/api/jobs/<job_id>/alm/prepare \
  -H "Content-Type: application/json" -d '{"norder":2,"cutoff":0}'
curl -X POST http://127.0.0.1:5020/api/jobs/<job_id>/alm/run \
  -H "Content-Type: application/json" -d '{"which":"optimize"}'
```

> Pour phonons harmoniques seuls, `norder:1` suffit. Pour **κ_L**, gardez **`norder:2`**.

---

## 5a · anphon (mode phonons) — Bandes et modes à Γ

| | |
|---|---|
| **Où** | Onglet **Calculs** → carte **5 · anphon** |
| **But** | Calculer les fréquences des phonons (vibrations du cristal) |
| **Prérequis** | alm terminé (NORDER = 1 ou 2 ; les bandes harmoniques sont valides dans les deux cas) |
| **Durée** | ~1–3 min |

### Étapes interface
1. Mode : **phonons**
2. kx, ky, kz : **10 10 10**
3. Cliquer **Préparer** puis **Lancer**

### Fichiers produits
```
work/<job_id>/alamode/
  anphon.in
  anphon.log
  <job_id>.bands     ← dispersion phonons
```

### Validation
- ω(Γ) cohérent avec la littérature (Si : ~520 cm⁻¹ LO)
- Aucun mode imaginaire (frééquence négative)

---

## 5b · anphon (mode rta) — Conductivité thermique κ_L

| | |
|---|---|
| **Où** | Onglet **Calculs** → carte **5 · anphon** |
| **But** | Calculer κ_L(T) — conductivité thermique des phonons |
| **Prérequis** | alm avec **NORDER ≥ 2** (supercellule 3×3×3 recommandée) |
| **Durée** | ~5–30 min |

### Étapes interface
1. Mode : **rta (κ)**
2. kx, ky, kz : **10 10 10** (20 pour publication)
3. Tmin : **300** · Tmax : **1000** · ΔT : **50** (Kelvin)
4. **Préparer** → **Lancer**

### Fichiers produits
```
work/<job_id>/alamode/
  <job_id>.kl        ← κ_L en fonction de T
```

### Piège débutant
| Erreur | Cause |
|--------|-------|
| rta échoue | NORDER = 1 seulement → relancer alm avec NORDER = 2 |
| κ_L aberrante | Supercellule 1×1×1 trop petite |

---

## 6 · Export — Copier les résultats finaux

| | |
|---|---|
| **Où** | Onglet **Calculs** ou **Résultats** → bouton **Export** |
| **But** | Copier tous les fichiers validés dans le dossier permanent |
| **Prérequis** | anphon terminé, fiche vérifiée |
| **Durée** | instantané |

### Destination
```
outputs/Si/<job_id>/
  fiche_technique.html
  fiche_technique.md
  results.json
  <job_id>.xml
  <job_id>.fcs
  <job_id>.bands
  DFSET
  INFO.txt
```

### Commande terminal
```bash
curl -X POST http://127.0.0.1:5020/api/jobs/<job_id>/publish \
  -H "Content-Type: application/json" -d '{"material":"Si"}'
```

---

## 7 · Résultats — Lire la fiche technique

| | |
|---|---|
| **Où** | Onglet **Résultats** |
| **But** | Visualiser toutes les grandeurs et ouvrir la fiche HTML |

### Étapes interface
1. Choisir matériau **Si** et le **job**
2. Cliquer **Vérifier**
3. Consulter : grandeurs · modes Γ · bandes · κ_L · **Fiche technique HTML**

### Grandeurs affichées (exemple Si)
| Grandeur | Description |
|----------|-------------|
| ω(Γ) | Fréquences à Γ (cm⁻¹) |
| Erreur alm | Précision de l’ajustement IFC |
| Bandes phonons | Courbe de dispersion |
| κ_L(T) | Conductivité thermique (W/m/K) |

---

## Pipeline complet en une commande (terminal)

Une fois les supercellules créées, tout enchaîner automatiquement :

```bash
cd /chemin/vers/QE-Alamode_interface

# 1. Lancer / reprendre les 12 calculs QE + pipeline ALAMODE
nohup ./scripts/resume_job.sh MON_JOB_ID Si >> logs/MON_JOB_ID_resume.log 2>&1 &

# 2. Surveiller (relance auto si coupure)
nohup ./scripts/watch_job.sh MON_JOB_ID Si >> logs/MON_JOB_ID_watch.log 2>&1 &

# 3. Suivre
cat work/MON_JOB_ID/progress.json
tail -f logs/MON_JOB_ID_resume.log
```

Si les 12 `.out` existent déjà, lancer seulement ALAMODE :

```bash
./scripts/complete_pipeline.sh MON_JOB_ID Si
```

---

## Checklist qualité (avant publication)

- [ ] Structure convergée · forces < 1 mRy/Bohr
- [ ] SCF · `conv_thr = 1×10⁻⁸` · k-points convergés
- [ ] Supercellule ≥ 2×2×2 · amplitude 0,01 Å · motifs ≥ 3×N_at
- [ ] alm · erreur < 2 % · 0 mode imaginaire
- [ ] κ_L · NORDER ≥ 2 · anphon rta · k ≥ 10×10×10
- [ ] Fiche technique validée → Export

---

## Deux parcours types

### Parcours A — Vérifier DFT sur PC limité (~30–60 min)
```
VC-RELAX → SCF → job → Supercellule 1×1×1 (2–6 motifs)
→ Forces → DFSET → alm (NORDER=1) → anphon (phonons) → Résultats
```
Ou en une commande (API démarrée) :
```bash
python3 scripts/verify_dft_nxn.py --n 1 --run
```
> Valide la **chaîne** (JOB DONE, DFSET, phonons). **Non publiable** pour κ_L.

### Parcours B — κ_L indicative (PC ≥8–16 Go, ~3–8 h)
```
… → Supercellule 2×2×2 → Forces → alm (NORDER=2) → anphon phonons → rta → Export
```

### Parcours C — Publication Si (machine puissante, ex. 14900K · 64 Go)
```
… → Supercellule 3×3×3 (12 motifs)
→ Forces (12× pw.x) → DFSET → alm (NORDER=2) → anphon (rta) → Export
```
> **C’est le parcours cible pour κ_L publiable.** Sur PC portable ~8–12 Go : faites d’abord le parcours A, puis lancez C sur la machine puissante (le code et les guides sont les mêmes).

---

*Guide HIADSI · LMESM / USTO-MB · QE–ALAMODE · said.hiadsi@univ-usto.dz*

QE–ALAMODE — Version 1.2 (2026-09-03)
Auteur : Prof. S. Hiadsi — LMESM / USTO-MB — said.hiadsi@univ-usto.dz
Lire en premier : README.md

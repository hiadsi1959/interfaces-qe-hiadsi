#!/usr/bin/env bash
# Installation et configuration de QE–ALAMODE sur un nouveau PC (Linux).
#
# Usage :
#   ./INSTALLER_AUTRE_PC.sh                    # interactif
#   ./INSTALLER_AUTRE_PC.sh --non-interactif   # valeurs par défaut / env
#   ./INSTALLER_AUTRE_PC.sh --install-alamode  # compile ALAMODE si absent
#   ./INSTALLER_AUTRE_PC.sh --help
#
# Variables d'environnement (mode non interactif) :
#   QE_BIN_DIR          chemin vers pw.x
#   ALAMODE_BIN_DIR     chemin vers alm / anphon
#   PSEUDO_DIR          dossier pseudos (défaut : <projet>/pseudos)
#   QEALAMODE_PORT      port API (défaut : 5020)
#
# Prérequis externes (non compilés ici) :
#   - Quantum ESPRESSO (pw.x) — https://www.quantum-espresso.org/
#   - Python 3.10+
#
# Auteur : S. Hiadsi · LMESM / USTO-MB
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

ENVF="$HERE/config_local.sh"
REQ="$HERE/requirements.txt"
LOG="$HERE/logs/install.log"

INTERACTIF=1
INSTALL_DEPS=0
INSTALL_ALAMODE=0
SKIP_PIP=0

QE_BIN="${QE_BIN_DIR:-}"
AL_BIN="${ALAMODE_BIN_DIR:-}"
PSEUDO="${PSEUDO_DIR:-$HERE/pseudos}"
PORT="${QEALAMODE_PORT:-5020}"
PYTHON_BIN="${QEALAMODE_PYTHON:-python3}"

usage() {
  sed -n '2,20p' "$0" | sed 's/^# \?//'
  exit 0
}

log() { echo "$*" | tee -a "$LOG"; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help) usage ;;
    -y|--non-interactif|--yes) INTERACTIF=0; shift ;;
    --install-deps) INSTALL_DEPS=1; shift ;;
    --install-alamode) INSTALL_ALAMODE=1; shift ;;
    --skip-pip) SKIP_PIP=1; shift ;;
    --qe-bin) QE_BIN="$2"; shift 2 ;;
    --alamode-bin) AL_BIN="$2"; shift 2 ;;
    --pseudos) PSEUDO="$2"; shift 2 ;;
    --port) PORT="$2"; shift 2 ;;
    *) echo "Option inconnue : $1 (--help)" >&2; exit 1 ;;
  esac
done

mkdir -p "$HERE/logs" "$HERE/work" "$HERE/inputs" "$HERE/outputs" "$PSEUDO"
: >"$LOG"
log "=== INSTALLER_AUTRE_PC — $(date) ==="
log "Projet : $HERE"

# ── 1. Paquets système (optionnel) ──
if [[ "$INSTALL_DEPS" -eq 1 ]]; then
  log ">>> Paquets système (apt)…"
  if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update
    sudo apt-get install -y \
      python3 python3-pip python3-venv \
      curl git \
      cmake g++ gfortran libeigen3-dev liblapack-dev libblas-dev \
      build-essential
  else
    log "AVERTISSEMENT : apt-get absent — installez Python3, pip, cmake, g++ manuellement."
  fi
fi

# ── 2. Dépendances Python ──
if [[ "$SKIP_PIP" -eq 0 ]]; then
  log ">>> Dépendances Python…"
  if [[ ! -f "$REQ" ]]; then
    echo "flask>=3.0
ase>=3.22
numpy>=1.24" >"$REQ"
  fi
  # Déjà satisfait (paquets système / venv actif) ?
  if python3 -c "import flask, ase, numpy" 2>/dev/null; then
    log "Dépendances Python déjà présentes (flask, ase, numpy)."
  elif python3 -m pip install --user -r "$REQ" >>"$LOG" 2>&1; then
    log "pip --user OK"
  else
    # Ubuntu 23.04+ : PEP 668 (« externally-managed-environment ») → environnement virtuel local
    log "pip --user refusé (PEP 668 probable) → création de .venv/ …"
    if python3 -m venv --system-site-packages "$HERE/.venv" >>"$LOG" 2>&1 \
       && "$HERE/.venv/bin/python" -m pip install --upgrade pip >>"$LOG" 2>&1 \
       && "$HERE/.venv/bin/python" -m pip install -r "$REQ" >>"$LOG" 2>&1; then
      PYTHON_BIN="$HERE/.venv/bin/python"
      log "venv OK → $PYTHON_BIN"
    else
      log "AVERTISSEMENT : installation Python échouée. Essayez : sudo apt install python3-flask python3-ase python3-numpy"
      log "               ou : python3 -m venv .venv && .venv/bin/pip install -r requirements.txt"
    fi
  fi
fi
[[ -x "$HERE/.venv/bin/python" ]] && PYTHON_BIN="$HERE/.venv/bin/python"

# ── 3. ALAMODE (optionnel) ──
if [[ "$INSTALL_ALAMODE" -eq 1 ]]; then
  log ">>> Compilation ALAMODE…"
  bash "$HERE/scripts/INSTALL_ALAMODE.sh" >>"$LOG" 2>&1
  if [[ -f "$HERE/config_local.sh" ]]; then
    # shellcheck disable=SC1091
    source "$HERE/config_local.sh"
    AL_BIN="${ALAMODE_BIN_DIR:-}"
  fi
fi

# ── 4. Détection automatique des binaires ──
find_qe() {
  local cands=(
    "${QE_BIN_DIR:-}"
    "$HOME/q-e-qe-7.5/bin"
    "$HOME/qe/bin"
    "$HOME/quantum-espresso/bin"
    "/usr/local/bin"
  )
  local d
  for d in "${cands[@]}"; do
    [[ -n "$d" && -x "$d/pw.x" ]] && { echo "$d"; return 0; }
  done
  command -v pw.x >/dev/null 2>&1 && dirname "$(command -v pw.x)" || true
}

find_alm() {
  local cands=(
    "${ALAMODE_BIN_DIR:-}"
    "$HERE/bin"
    "$HOME/alamode/bin"
    "/usr/local/bin"
  )
  local d
  for d in "${cands[@]}"; do
    [[ -n "$d" && -x "$d/alm" && -x "$d/anphon" ]] && { echo "$d"; return 0; }
  done
  return 1
}

[[ -z "$QE_BIN" ]] && QE_BIN="$(find_qe || true)"
[[ -z "$AL_BIN" ]] && AL_BIN="$(find_alm || true)"

QE_DEFAULT="${QE_BIN:-$HOME/q-e-qe-7.5/bin}"
AL_DEFAULT="${AL_BIN:-$HERE/bin}"

# ── 5. Saisie interactive ──
if [[ "$INTERACTIF" -eq 1 ]]; then
  echo ""
  echo "  ╔══════════════════════════════════════════════════════╗"
  echo "  ║   QE–ALAMODE — Configuration sur un nouveau PC       ║"
  echo "  ╚══════════════════════════════════════════════════════╝"
  echo ""
  echo "  Projet : $HERE"
  echo ""
  if [[ -x "$QE_DEFAULT/pw.x" ]]; then
    echo "  ✓ pw.x détecté : $QE_DEFAULT/pw.x"
  else
    echo "  ✗ pw.x non trouvé — indiquez le chemin QE compilé"
  fi
  if [[ -n "$AL_DEFAULT" && -x "$AL_DEFAULT/alm" ]]; then
    echo "  ✓ alm/anphon détectés : $AL_DEFAULT"
  else
    echo "  ✗ alm/anphon non trouvés — copiez bin/ ou lancez --install-alamode"
  fi
  echo ""
  read -r -p "  Dossier bin QE (pw.x) [$QE_DEFAULT] : " _qe
  QE_BIN="${_qe:-$QE_DEFAULT}"
  read -r -p "  Dossier bin ALAMODE (alm, anphon) [$AL_DEFAULT] : " _al
  AL_BIN="${_al:-$AL_DEFAULT}"
  read -r -p "  Dossier pseudos [$PSEUDO] : " _ps
  PSEUDO="${_ps:-$PSEUDO}"
  read -r -p "  Port interface web [$PORT] : " _pt
  PORT="${_pt:-$PORT}"
  echo ""
else
  # Mode non interactif : appliquer les valeurs détectées / par défaut (jamais de chemin vide)
  QE_BIN="${QE_BIN:-$QE_DEFAULT}"
  AL_BIN="${AL_BIN:-$AL_DEFAULT}"
fi

# ── 6. Écriture config (fichier temporaire ; promu après vérif réussie) ──
ENVF_NEW="${ENVF}.new"
cat >"$ENVF_NEW" <<EOF
# Généré par INSTALLER_AUTRE_PC.sh — $(date '+%Y-%m-%d %H:%M:%S')
# Sourcer : source "$ENVF"
export QE_BIN_DIR="$QE_BIN"
export ALAMODE_BIN_DIR="$AL_BIN"
export PSEUDO_DIR="$PSEUDO"
export QEALAMODE_PORT="$PORT"
export QEALAMODE_PYTHON="$PYTHON_BIN"
export OMP_NUM_THREADS="\${OMP_NUM_THREADS:-2}"
export QE_NPROC="\${QE_NPROC:-2}"
EOF
log "Brouillon : $ENVF_NEW"

# ── 7. Scripts exécutables ──
chmod +x "$HERE/DEMARRER.sh" "$HERE/ARRETER.sh" 2>/dev/null || true
chmod +x "$HERE/CONFIGURER.sh" "$HERE/INSTALLER_AUTRE_PC.sh" 2>/dev/null || true
chmod +x "$HERE/scripts/"*.sh 2>/dev/null || true

# ── 8. Vérification ──
# shellcheck disable=SC1091
source "$ENVF_NEW"

ok=0
warn=0
err=0

check() {
  local label="$1" path="$2"
  if [[ -x "$path" ]]; then
    log "  OK  $label → $path"
    ok=$((ok + 1))
  elif [[ -f "$path" ]]; then
    log "  WARN $label existe mais non exécutable : $path"
    warn=$((warn + 1))
  else
    log "  ERR $label introuvable : $path"
    err=$((err + 1))
  fi
}

echo ""
echo "  ── Vérification ──"
check "pw.x"    "$QE_BIN_DIR/pw.x"
check "alm"     "$ALAMODE_BIN_DIR/alm"
check "anphon"  "$ALAMODE_BIN_DIR/anphon"

# Les binaires ALAMODE embarqués démarrent-ils sur cette machine (libs système, glibc) ?
check_alamode_runs() {
  local exe="$1" name
  name="$(basename "$exe")"
  [[ -x "$exe" ]] || return 0
  local missing
  missing="$(ldd "$exe" 2>/dev/null | awk '/not found/ {print $1}' | sort -u | tr '\n' ' ')"
  if [[ -n "$missing" ]]; then
    log "  ERR $name : bibliothèques manquantes → $missing"
    log "      Ubuntu/Debian : sudo apt-get install -y libblas3 liblapack3 libfftw3-double3 libsymspg2 libgomp1 libgfortran5 libopenmpi3 libnuma1"
    log "      (le nom exact du paquet OpenMPI varie : libopenmpi3 / libopenmpi40 ; vérifiez avec : ldd $exe)"
    err=$((err + 1))
    return 0
  fi
  # Sans input, alm/anphon renvoient 1 avec un message « input » ; un rc 126/127/≥128 = ne démarre pas (glibc trop ancienne…)
  local rc=0
  timeout 10 "$exe" </dev/null >/dev/null 2>&1 || rc=$?
  if [[ "$rc" -ge 126 || "$rc" -eq 124 ]]; then
    log "  ERR $name ne démarre pas (rc=$rc) — glibc/libstdc++ trop anciens ? Binaires compilés sur Ubuntu 24.04+ (glibc ≥ 2.38)."
    log "      Solution : recompiler localement → ALAMODE_INSTALL_TO_BIN=1 ./scripts/INSTALL_ALAMODE_PORTABLE.sh"
    err=$((err + 1))
  else
    log "  OK  $name démarre (libs système OK)"
    ok=$((ok + 1))
  fi
}
check_alamode_runs "$ALAMODE_BIN_DIR/alm"
check_alamode_runs "$ALAMODE_BIN_DIR/anphon"

for mod in flask ase numpy; do
  if "$PYTHON_BIN" -c "import $mod" 2>/dev/null; then
    log "  OK  python:$mod"
    ok=$((ok + 1))
  else
    log "  ERR python:$mod manquant"
    err=$((err + 1))
  fi
done

[[ -d "$PSEUDO_DIR" ]] && log "  OK  pseudos/ → $PSEUDO_DIR" || log "  WARN pseudos/ absent"

# Test API detect_tools
if DETECT=$("$PYTHON_BIN" -c "
import sys
sys.path.insert(0, '$HERE/backend')
from config import detect_tools
import json
print(json.dumps(detect_tools()))
" 2>>"$LOG"); then
  log "  detect_tools : $DETECT"
fi

echo ""
echo "  ── Résumé : $ok OK · $warn avertissement(s) · $err erreur(s) ──"
echo ""

if [[ "$err" -gt 0 ]]; then
  echo "  ⚠ Configuration incomplète — config_local.sh non mis à jour (brouillon : $ENVF_NEW)."
  echo ""
  echo "  Actions possibles :"
  echo "    · Installer QE (pw.x) puis relancer ce script"
    echo "    · Copier alm/anphon dans $HERE/bin/  (depuis un PC déjà configuré)"
    echo "    · Ou recompiler ALAMODE portable : ALAMODE_INSTALL_TO_BIN=1 ./scripts/INSTALL_ALAMODE_PORTABLE.sh"
    echo "    · Ou : ./INSTALLER_AUTRE_PC.sh --install-alamode --install-deps"
    echo "    · pip : python3 -m venv .venv && .venv/bin/pip install -r requirements.txt"
  echo ""
  exit 1
fi

mv -f "$ENVF_NEW" "$ENVF"
log "Écrit : $ENVF"

echo "  ✓ Configuration terminée."
echo ""
echo "  Démarrer l'interface :"
echo "    cd $HERE"
echo "    ./DEMARRER.sh"
echo ""
echo "  URL : http://127.0.0.1:${PORT}/"
echo ""
echo "  Vérifier le workflow :"
echo "    python3 scripts/verifier_etapes.py"
echo ""
echo "  Log installation : $LOG"
echo ""

exit 0

"""Matériaux : découverte depuis inputs/ et publication vers outputs/."""
from __future__ import annotations

import json
import re
import shutil
import time
from pathlib import Path

from config import INPUTS, OUTPUTS, WORK


def _safe_name(name: str) -> str:
    s = "".join(c for c in (name or "").strip() if c.isalnum() or c in "-_")
    return s or "material"


def material_from_filename(filename: str) -> str:
    """Si_relaxed_scf.in → Si ; GaAs_opt.in → GaAs."""
    stem = Path(filename).stem
    # enlever suffixes courants
    for suf in ("-optimized-scf", "_optimized_scf", "-relaxed-scf", "_relaxed_scf",
                "-vc-relax", "_vc-relax", "-vcrelax", "_vcrelax",
                "-relax", "_relax", "-scf", "_scf", "-opt", "_opt"):
        if stem.lower().endswith(suf.lower()):
            stem = stem[: -len(suf)]
            break
    # premier jeton alphanum
    m = re.match(r"([A-Za-z][A-Za-z0-9]*)", stem)
    return m.group(1) if m else _safe_name(stem)


def list_materials() -> list[dict]:
    INPUTS.mkdir(parents=True, exist_ok=True)
    OUTPUTS.mkdir(parents=True, exist_ok=True)
    mats: dict[str, dict] = {}

    # sous-dossiers inputs/<Mat>/
    for d in sorted(INPUTS.iterdir()):
        if d.is_dir() and not d.name.startswith("."):
            mats.setdefault(d.name, {"name": d.name, "inputs": [], "outputs": []})

    for path in sorted(INPUTS.glob("*.in")):
        mat = material_from_filename(path.name)
        mats.setdefault(mat, {"name": mat, "inputs": [], "outputs": []})
        mats[mat]["inputs"].append(
            {
                "name": path.name,
                "path": f"inputs/{path.name}",
                "rel": path.name,
            }
        )

    for d in INPUTS.iterdir():
        if not d.is_dir():
            continue
        mat = d.name
        mats.setdefault(mat, {"name": mat, "inputs": [], "outputs": []})
        for path in sorted(d.glob("*.in")):
            mats[mat]["inputs"].append(
                {
                    "name": path.name,
                    "path": f"inputs/{mat}/{path.name}",
                    "rel": f"{mat}/{path.name}",
                }
            )

    for d in OUTPUTS.iterdir():
        if d.is_dir() and not d.name.startswith("."):
            mats.setdefault(d.name, {"name": d.name, "inputs": [], "outputs": []})
            for path in sorted(d.rglob("*")):
                if path.is_file() and path.name != "README.txt":
                    mats[d.name]["outputs"].append(
                        {
                            "name": path.name,
                            "path": str(path.relative_to(OUTPUTS.parent)),
                        }
                    )

    # jobs liés
    for job_meta in []:
        pass
    if WORK.exists():
        for p in WORK.iterdir():
            if not (p / "meta.json").is_file():
                continue
            try:
                meta = json.loads((p / "meta.json").read_text(encoding="utf-8"))
            except Exception:
                continue
            mat = meta.get("material") or material_from_filename(meta.get("name") or p.name)
            mats.setdefault(mat, {"name": mat, "inputs": [], "outputs": []})
            mats[mat].setdefault("jobs", []).append({"id": meta.get("id"), "name": meta.get("name")})

    out = []
    for name in sorted(mats.keys(), key=str.lower):
        item = mats[name]
        item.setdefault("jobs", [])
        item["n_inputs"] = len(item["inputs"])
        item["n_outputs"] = len(item["outputs"])
        out.append(item)
    return out


def resolve_input_path(rel_or_name: str) -> Path | None:
    """Résout un input depuis inputs/ (fichier ou Mat/fichier)."""
    rel = rel_or_name.replace(chr(92), "/").lstrip("/")
    if rel.startswith("inputs/"):
        rel = rel[len("inputs/") :]
    cand = INPUTS / rel
    if cand.is_file():
        return cand
    name = Path(rel).name
    for d in INPUTS.iterdir():
        if d.is_dir():
            c = d / name
            if c.is_file():
                return c
    cand = INPUTS / name
    if cand.is_file():
        return cand
    return None


def publish_job_to_outputs(job_id: str, material: str | None = None) -> dict:
    """Copie les résultats utiles du job vers outputs/<matériau>/."""
    job = WORK / job_id
    if not job.is_dir():
        return {"ok": False, "error": "Job inconnu"}
    meta = {}
    if (job / "meta.json").is_file():
        meta = json.loads((job / "meta.json").read_text(encoding="utf-8"))
    mat = _safe_name(material or meta.get("material") or meta.get("name") or "material")
    dest = OUTPUTS / mat / job_id
    dest.mkdir(parents=True, exist_ok=True)

    copied = []
    for sub in ("results", "alamode", "qe"):
        src = job / sub
        if not src.is_dir():
            continue
        for f in src.iterdir():
            if not f.is_file():
                continue
            if f.suffix.lower() in {".in", ".out", ".xml", ".fcs", ".bands", ".kl", ".md", ".txt", ".html", ".json"} or f.name == "DFSET":
                target = dest / f.name
                shutil.copy2(f, target)
                copied.append(str(target.relative_to(OUTPUTS.parent)))

    readme = dest / "INFO.txt"
    readme.write_text(
        f"Matériau : {mat}\nJob : {job_id}\nPublié : {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"Source : work/{job_id}\n",
        encoding="utf-8",
    )
    # Marquer l’étape export dans meta (checklist Résultats)
    try:
        meta.setdefault("steps", {})
        meta["steps"]["publish"] = {
            "ok": True,
            "dir": f"outputs/{mat}/{job_id}",
            "n_files": len(copied),
            "at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        (job / "meta.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    except OSError:
        pass
    return {"ok": True, "material": mat, "dir": f"outputs/{mat}/{job_id}", "files": copied}

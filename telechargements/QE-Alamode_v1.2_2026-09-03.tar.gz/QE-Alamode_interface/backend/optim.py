"""Optimisation type Interface-QE_v1 : VC-RELAX / RELAX / SCF par matériau."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path

from config import INPUTS, OUTPUTS, LOGS, WORK, ROOT, detect_tools
from materials import _safe_name


KINDS = ("vc-relax", "relax", "scf")


def normalize_kind(kind: str) -> str:
    k = (kind or "").strip().lower().replace("_", "-")
    if k in {"vc-relax", "vcrelax", "vc"}:
        return "vc-relax"
    if k == "relax":
        return "relax"
    if k == "scf":
        return "scf"
    raise ValueError(f"kind inconnu: {kind} (vc-relax|relax|scf)")


def input_filename(mat: str, kind: str) -> str:
    mat = _safe_name(mat)
    kind = normalize_kind(kind)
    return f"{mat}-{kind}.in"


def material_input_path(mat: str, kind: str) -> Path:
    mat = _safe_name(mat)
    return INPUTS / mat / input_filename(mat, kind)


def _find_out(mat: str, kind: str) -> Path | None:
    mat = _safe_name(mat)
    kind = normalize_kind(kind)
    opt = OUTPUTS / mat / "optimisation"
    candidates: list[Path] = []
    if opt.is_dir():
        for name in (
            f"{mat}_{kind}.out",
            f"{mat}-{kind}.out",
            f"{kind}.out",
            f"{kind.replace('-', '_')}.out",
            "vc_relax.out" if kind == "vc-relax" else None,
            "relax.out" if kind == "relax" else None,
            "scf.out" if kind == "scf" else None,
        ):
            if name:
                candidates.append(opt / name)
        for p in sorted(opt.glob("*.out")):
            n = p.name.lower()
            if kind == "vc-relax" and ("vc" in n and "relax" in n):
                candidates.append(p)
            elif kind == "relax" and "relax" in n and "vc" not in n:
                candidates.append(p)
            elif kind == "scf" and "scf" in n:
                candidates.append(p)
    if WORK.exists():
        for job in WORK.iterdir():
            qe = job / "qe"
            if not qe.is_dir():
                continue
            meta = job / "meta.json"
            if meta.is_file():
                try:
                    m = json.loads(meta.read_text(encoding="utf-8"))
                    if _safe_name(m.get("material") or "") not in {mat, ""}:
                        if _safe_name(m.get("material") or "") != mat:
                            continue
                except Exception:
                    pass
            for name in (
                "vc_relax.out" if kind == "vc-relax" else None,
                "relax.out" if kind == "relax" else None,
                "scf.out" if kind == "scf" else None,
                f"{kind}.out",
            ):
                if name and (qe / name).is_file():
                    candidates.append(qe / name)
    for c in candidates:
        if c and c.is_file() and c.stat().st_size > 50:
            return c
    return None


def _out_converged(path: Path | None) -> bool:
    if not path or not path.is_file():
        return False
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return False
    if "JOB DONE" not in text:
        return False
    if re.search(r"convergence NOT achieved|Error in", text, re.I):
        return False
    return True


def optim_status(mat: str) -> dict:
    mat = _safe_name(mat)
    mat_dir = INPUTS / mat
    steps = {}
    for kind in KINDS:
        inp = material_input_path(mat, kind)
        out = _find_out(mat, kind)
        out_rel = None
        if out:
            try:
                out_rel = str(out.relative_to(ROOT))
            except ValueError:
                out_rel = str(out)
        steps[kind] = {
            "kind": kind,
            "input_exists": inp.is_file(),
            "input_path": f"inputs/{mat}/{inp.name}",
            "output_exists": bool(out),
            "output_path": out_rel,
            "converged": _out_converged(out),
        }
    # Prêt pour Calculs : un input SCF existe ET une étape QE a convergé
    # (SCF lui-même, ou relax/vc-relax ayant produit la structure).
    scf_ready = steps["scf"]["input_exists"] and (
        steps["scf"]["converged"]
        or steps["vc-relax"]["converged"]
        or steps["relax"]["converged"]
    )
    return {
        "ok": True,
        "material": mat,
        "dir": f"inputs/{mat}" if mat_dir.is_dir() else None,
        "steps": steps,
        "scf_ready": bool(scf_ready),
    }


def get_material_input(mat: str, kind: str) -> dict:
    mat = _safe_name(mat)
    kind = normalize_kind(kind)
    path = material_input_path(mat, kind)
    if not path.is_file():
        return {"ok": False, "error": f"Absent : inputs/{mat}/{path.name}"}
    return {
        "ok": True,
        "material": mat,
        "kind": kind,
        "path": f"inputs/{mat}/{path.name}",
        "content": path.read_text(encoding="utf-8"),
    }


def put_material_input(mat: str, kind: str, content: str) -> dict:
    mat = _safe_name(mat)
    kind = normalize_kind(kind)
    path = material_input_path(mat, kind)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = content if content.endswith("\n") else content + "\n"
    path.write_text(text, encoding="utf-8")
    return {"ok": True, "material": mat, "kind": kind, "path": f"inputs/{mat}/{path.name}"}


def _patch_pw_paths(text: str, *, outdir: Path, pseudo_dir: str) -> str:
    text = re.sub(r"outdir\s*=\s*'[^']*'", f"outdir = '{outdir}'", text, count=1, flags=re.I)
    text = re.sub(r"pseudo_dir\s*=\s*'[^']*'", f"pseudo_dir = '{pseudo_dir}'", text, count=1, flags=re.I)
    return text


def run_material_optim(mat: str, kind: str, *, job_id: str | None = None) -> dict:
    """Lance vc-relax / relax / scf pour un matériau (inputs/<Mat>/)."""
    from ase.io import read, write
    from qe_parser import build_pw_scf_input
    from workflow import (
        create_job,
        import_scf_input,
        _job_dir,
        _load_meta,
        _save_meta,
        _mass,
    )

    mat = _safe_name(mat)
    kind = normalize_kind(kind)
    tools = detect_tools()
    if not tools.get("pw_x"):
        return {"ok": False, "error": "pw.x introuvable", "tools": tools}

    src = material_input_path(mat, kind)
    if not src.is_file():
        return {"ok": False, "error": f"Input manquant : inputs/{mat}/{src.name}"}

    if not job_id:
        created = create_job(mat, material=mat)
        job_id = created["job_id"]
    job = _job_dir(job_id)
    meta = _load_meta(job)
    meta["material"] = mat
    _save_meta(job, meta)

    import_scf_input(job_id, src.name, src.read_bytes())

    opt_dir = OUTPUTS / mat / "optimisation"
    opt_dir.mkdir(parents=True, exist_ok=True)
    outdir = opt_dir / kind.replace("-", "")
    outdir.mkdir(parents=True, exist_ok=True)

    from workflow import _pseudo_dir_for_job
    pseudo_dir = _pseudo_dir_for_job(job)
    text = _patch_pw_paths(src.read_text(encoding="utf-8"), outdir=outdir, pseudo_dir=pseudo_dir)

    qe_name = {"vc-relax": "vc_relax.in", "relax": "relax.in", "scf": "scf.in"}[kind]
    inp = job / "qe" / qe_name
    inp.parent.mkdir(parents=True, exist_ok=True)
    inp.write_text(text, encoding="utf-8")
    out = job / "qe" / qe_name.replace(".in", ".out")
    log = LOGS / f"{job_id}_{kind.replace('-', '')}.log"

    try:
        with out.open("w", encoding="utf-8") as fout, log.open("w", encoding="utf-8") as flog:
            proc = subprocess.run(
                [tools["pw_x"], "-in", str(inp)],
                cwd=str(job / "qe"),
                stdout=fout,
                stderr=flog,
                timeout=int(os.environ.get("QE_TIMEOUT", "21600")),
                check=False,
            )
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"{kind} : timeout", "job_id": job_id}

    shutil.copy2(out, opt_dir / f"{mat}_{kind}.out")
    shutil.copy2(inp, opt_dir / f"{mat}_{kind}.in")

    if proc.returncode != 0:
        return {
            "ok": False,
            "error": f"{kind} échoué (rc={proc.returncode})",
            "log": log.name,
            "job_id": job_id,
            "output": f"outputs/{mat}/optimisation/{mat}_{kind}.out",
        }

    result = {
        "ok": True,
        "kind": kind,
        "material": mat,
        "job_id": job_id,
        "output": f"outputs/{mat}/optimisation/{mat}_{kind}.out",
        "converged": _out_converged(out),
    }

    if kind in {"vc-relax", "relax"}:
        try:
            atoms = read(str(out), format="espresso-out")
        except Exception as exc:
            result["warning"] = f"Sortie OK mais structure non lue : {exc}"
            return result
        write(str(job / "structure.cif"), atoms)
        qe_tpl = {}
        if (job / "qe_params.json").is_file():
            qe_tpl = json.loads((job / "qe_params.json").read_text(encoding="utf-8"))
        kd = []
        pseudo_map = qe_tpl.get("pseudo_map") or {}
        mass_map = qe_tpl.get("mass_map") or {}
        for s in atoms.get_chemical_symbols():
            if s not in kd:
                kd.append(s)
        species = [
            {
                "symbol": s,
                "mass": float(mass_map.get(s, _mass(s))),
                "pseudo": pseudo_map.get(s, f"{s}.UPF"),
            }
            for s in kd
        ]
        positions = [
            {
                "symbol": s,
                "x": float(f[0]),
                "y": float(f[1]),
                "z": float(f[2]),
                "unit": "crystal",
            }
            for s, f in zip(atoms.get_chemical_symbols(), atoms.get_scaled_positions())
        ]
        scf_text = build_pw_scf_input(
            prefix=mat,
            species=species,
            positions=positions,
            cell=atoms.cell.array.tolist(),
            ecutwfc=float(qe_tpl.get("ecutwfc", 60.0)),
            ecutrho=float(qe_tpl.get("ecutrho", 480.0)),
            kpoints=tuple(qe_tpl.get("kpoints") or (8, 8, 8)),
            pseudo_dir=pseudo_dir,
            occupations=qe_tpl.get("occupations") or "smearing",
            smearing=qe_tpl.get("smearing") or "cold",
            degauss=qe_tpl.get("degauss", 0.02),
            conv_thr=str(qe_tpl.get("conv_thr", "1.0d-8")),
            mixing_beta=qe_tpl.get("mixing_beta", 0.7),
        )
        scf_path = material_input_path(mat, "scf")
        scf_path.parent.mkdir(parents=True, exist_ok=True)
        scf_path.write_text(scf_text, encoding="utf-8")
        (opt_dir / f"{mat}-scf.in").write_text(scf_text, encoding="utf-8")
        (job / "qe" / "reference_scf.in").write_text(scf_text, encoding="utf-8")
        import_scf_input(job_id, "reference_scf.in", scf_text.encode("utf-8"))
        result["saved_input"] = f"inputs/{mat}/{mat}-scf.in"
        result["message"] = f"{kind} terminé. SCF → inputs/{mat}/{mat}-scf.in"
    else:
        result["message"] = f"SCF terminé → outputs/{mat}/optimisation/"
        result["saved_input"] = f"inputs/{mat}/{mat}-scf.in"

    meta = _load_meta(job)
    meta["material"] = mat
    meta["steps"][kind] = {"ok": True, "rc": proc.returncode}
    _save_meta(job, meta)
    return result

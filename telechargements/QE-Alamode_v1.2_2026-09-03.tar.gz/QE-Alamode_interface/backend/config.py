"""Chemins et détection QE / ALAMODE."""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
INPUTS = ROOT / "inputs"
WORK = ROOT / "work"
OUTPUTS = ROOT / "outputs"
LOGS = ROOT / "logs"
TEMPLATES = ROOT / "templates"
INTERFACE = ROOT / "interface"

for d in (INPUTS, WORK, OUTPUTS, LOGS):
    d.mkdir(parents=True, exist_ok=True)


def _env_dir(name: str) -> Path | None:
    """Variable d'environnement non vide → Path, sinon None."""
    val = (os.environ.get(name) or "").strip()
    return Path(val).expanduser() if val else None


def _has(directory: Path | None, *names: str) -> bool:
    if directory is None:
        return False
    return all((directory / n).is_file() and os.access(directory / n, os.X_OK) for n in names)


def _default_qe_bin() -> Path:
    env = _env_dir("QE_BIN_DIR")
    if env is not None:
        return env
    # 1) bin/ du projet (pack livré avec pw.x éventuel) · 2) pw.x dans le PATH · 3) chemins usuels
    if _has(ROOT / "bin", "pw.x"):
        return ROOT / "bin"
    found = shutil.which("pw.x")
    if found:
        return Path(found).resolve().parent
    for cand in (
        Path.home() / "q-e-qe-7.5" / "bin",
        Path.home() / "qe" / "bin",
        Path.home() / "quantum-espresso" / "bin",
        Path("/usr/local/bin"),
    ):
        if _has(cand, "pw.x"):
            return cand
    return ROOT / "bin"


def _looks_mkl(directory: Path) -> bool:
    """True si alm de ce dossier est lié à Intel MKL (non portable)."""
    alm = directory / "alm"
    if not alm.is_file():
        return False
    try:
        out = subprocess.run(
            ["ldd", str(alm)], capture_output=True, text=True, timeout=5
        )
        return "mkl" in (out.stdout or "").lower()
    except (OSError, subprocess.SubprocessError):
        return False


def _default_alamode_bin() -> Path:
    env = _env_dir("ALAMODE_BIN_DIR")
    if env is not None:
        return env
    portable = ROOT / "bin-portable"
    bundled = ROOT / "bin"
    # Pack public : bin/ portable. Dépôt de dev : préférer bin-portable si bin/ est MKL.
    if _has(portable, "alm", "anphon") and (not _has(bundled, "alm", "anphon") or _looks_mkl(bundled)):
        return portable
    if _has(bundled, "alm", "anphon"):
        return bundled
    found = shutil.which("alm")
    if found:
        return Path(found).resolve().parent
    for cand in (Path.home() / "alamode" / "bin", Path("/usr/local/bin")):
        if _has(cand, "alm", "anphon"):
            return cand
    return ROOT / "bin"


DEFAULT_QE_BIN = _default_qe_bin()
DEFAULT_ALAMODE_BIN = _default_alamode_bin()


def _which_in(name: str, directory: Path) -> str | None:
    cand = directory / name
    if cand.is_file() and os.access(cand, os.X_OK):
        return str(cand)
    return shutil.which(name)


def detect_tools() -> dict:
    qe_bin = _env_dir("QE_BIN_DIR") or _default_qe_bin()
    al_bin = _env_dir("ALAMODE_BIN_DIR") or _default_alamode_bin()
    return {
        "qe_bin_dir": str(qe_bin),
        "alamode_bin_dir": str(al_bin),
        "pw_x": _which_in("pw.x", qe_bin),
        "alm": _which_in("alm", al_bin) or _which_in("alm", Path("/usr/local/bin")),
        "anphon": _which_in("anphon", al_bin) or _which_in("anphon", Path("/usr/local/bin")),
        "root": str(ROOT),
    }

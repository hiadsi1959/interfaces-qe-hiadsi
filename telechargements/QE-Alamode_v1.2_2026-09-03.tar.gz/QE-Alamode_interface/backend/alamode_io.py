"""Génération des fichiers d'entrée ALAMODE 1.5 (alm / anphon)."""
from __future__ import annotations

from pathlib import Path

ANG_TO_BOHR = 1.0 / 0.529177210903


def write_alm_suggest(
    dest: Path,
    *,
    prefix: str,
    nat: int,
    nkd: int,
    kd_names: list[str],
    lattice_vectors: list[list[float]],
    positions_frac: list[tuple[str, float, float, float]],
    mode: str = "suggest",
    norder: int = 2,
    cutoff: float | None = None,
) -> None:
    """
    Écrit un fichier alm.in (mode suggest ou optimize).
    Convention ALAMODE 1.x :
      - NORDER = 1 (harmonique), 2 (cubique), …
      - &cell : facteur + vecteurs en Bohr
      - &cutoff : paires Elem-Elem (ex. Si-Si None) ; cutoff UI en Å
    """
    mode_l = mode.lower()
    mode_out = "optimize" if mode_l in {"optimize", "opt"} else mode_l

    lines = [
        "&general",
        f"  PREFIX = {prefix}",
        f"  MODE = {mode_out}",
        f"  NAT = {nat}; NKD = {nkd}",
        "  KD = " + " ".join(kd_names),
        "/",
        "&interaction",
        f"  NORDER = {norder}  # 1: harmonic, 2: cubic, ...",
        "/",
        "&cell",
        "  1.0  # facteur (vecteurs ci-dessous en Bohr)",
    ]
    for v in lattice_vectors:
        bx, by, bz = v[0] * ANG_TO_BOHR, v[1] * ANG_TO_BOHR, v[2] * ANG_TO_BOHR
        lines.append(f"  {bx:.10f} {by:.10f} {bz:.10f}")
    lines.append("/")
    lines.append("&cutoff")
    # Une valeur de cutoff par ordre d’IFC (NORDER colonnes) — ex. NORDER=2 → « Si-Si None None »
    if cutoff is None or float(cutoff) <= 0:
        cols = " ".join(["None"] * max(1, int(norder)))
    else:
        one = f"{float(cutoff) * ANG_TO_BOHR:.6f}"
        cols = " ".join([one] * max(1, int(norder)))
    for i, a in enumerate(kd_names):
        for b in kd_names[i:]:
            lines.append(f"  {a}-{b} {cols}")
    lines.append("/")
    lines.append("&position")
    kd_index = {name: i + 1 for i, name in enumerate(kd_names)}
    for sym, x, y, z in positions_frac:
        lines.append(f"  {kd_index[sym]}  {x:.10f}  {y:.10f}  {z:.10f}")
    lines.append("/")
    if mode_out == "optimize":
        lines += [
            "&optimize",
            "  DFSET = DFSET",
            "/",
        ]
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_anphon_phonons(
    dest: Path,
    *,
    prefix: str,
    kd_names: list[str],
    masses: list[float],
    lattice_vectors: list[list[float]],
    mode: str = "phonons",
    kmesh: tuple[int, int, int] = (10, 10, 10),
    tmin: float = 0.0,
    tmax: float = 1000.0,
    dt: float = 50.0,
) -> None:
    kx, ky, kz = kmesh
    nkd = len(kd_names)
    mass_str = " ".join(f"{m:.6f}" for m in masses)
    cell_lines = ["&cell", "  1.0  # Bohr"]
    for v in lattice_vectors:
        bx, by, bz = v[0] * ANG_TO_BOHR, v[1] * ANG_TO_BOHR, v[2] * ANG_TO_BOHR
        cell_lines.append(f"  {bx:.10f} {by:.10f} {bz:.10f}")
    cell_lines.append("/")

    mode_l = mode.lower()
    # "dos" = MODE=phonons + maille uniforme (DOS + thermo)
    anphon_mode = "phonons" if mode_l == "dos" else mode_l
    general = [
        "&general",
        f"  PREFIX = {prefix}",
        f"  MODE = {anphon_mode}",
        f"  FCSXML = {prefix}.xml",
        f"  NKD = {nkd}",
        "  KD = " + " ".join(kd_names),
        f"  MASS = {mass_str}",
    ]
    if mode_l in {"rta", "bte", "dos"}:
        general += [
            f"  TMIN = {tmin}",
            f"  TMAX = {tmax}",
            f"  DT = {dt}",
        ]
    general.append("/")

    if mode_l in {"rta", "bte", "dos"}:
        kpoint = ["&kpoint", "  2", f"  {kx} {ky} {kz}", "/"]
    else:
        kpoint = [
            "&kpoint",
            "  1",
            "  G 0.0 0.0 0.0  X 0.5 0.5 0.0 40",
            "  X 0.5 0.5 0.0  G 0.0 0.0 0.0 40",
            "  G 0.0 0.0 0.0  L 0.5 0.5 0.5 40",
            "/",
        ]

    lines = general + cell_lines + kpoint
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_kappa_file(path: Path) -> list[dict]:
    """
    Parse sortie conductivité ALAMODE.
    - format court : T κxx κyy κzz
    - format .kl   : T κxx κxy κxz κyx κyy κyz κzx κzy κzz
    """
    if not path.is_file():
        return []
    rows = []
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        s = line.strip()
        if not s or s.startswith("#") or s.startswith("!"):
            continue
        parts = s.split()
        if len(parts) < 2:
            continue
        try:
            t = float(parts[0])
            nums = [float(x) for x in parts[1:]]
        except ValueError:
            continue
        if len(nums) >= 9:
            kxx, kyy, kzz = nums[0], nums[4], nums[8]
        elif len(nums) >= 3:
            kxx, kyy, kzz = nums[0], nums[1], nums[2]
        elif len(nums) == 2:
            kxx, kyy, kzz = nums[0], nums[1], nums[1]
        elif len(nums) == 1:
            kxx = kyy = kzz = nums[0]
        else:
            continue
        rows.append({"T": t, "kappa_xx": kxx, "kappa_yy": kyy, "kappa_zz": kzz})
    return rows

# Outils ALAMODE

Copie de `alamode/src/tools` (dépôt ALAMODE, ttadano).

> **Requis par l’interface :** `alamode/displace.py` (+ `GenDisplacement.py`, `interface/`) — utilisé par la
> carte *Supercellules* pour générer les motifs de déplacement **alm suggest** (méthode recommandée pour
> IFC / κ_L). S’il manque, l’interface se replie sur des déplacements **aléatoires ASE** (moins bon).

Les autres scripts sont optionnels. L’interface exploite déjà les résultats via :
- `backend/results_report.py` — parse `.bands`, `.kl`, `.fcs`
- `backend/fiche_html.py` + `interface/app.js` — graphiques bandes / κ_L
- `bin/alm` et `bin/anphon` — calculs principaux

## Utiles en ligne de commande (optionnel)

| Script | Usage |
|--------|--------|
| `plotband.py` | Figure publication des bandes phonons (matplotlib) |
| `plotdos.py` | Densité d’états phonons |
| `extract.py` | Extraire forces / énergies des sorties QE |
| `analyze_phonons.py` | Temps de vie, MFP (nécessite compilation du `.cpp`) |

## Exemples

```bash
# Bandes phonons (après anphon)
python3 tools/alamode/plotband.py work/JOB_ID/alamode/JOB_ID.bands

# DOS phonons
python3 tools/alamode/plotdos.py work/JOB_ID/alamode/JOB_ID.dos

# Aide
python3 tools/alamode/plotband.py --help
```

Dépendances Python optionnelles : `numpy`, `matplotlib`.

#!/usr/bin/env python3
"""État de validation κ_L — checklist sans recalcul QE lourd."""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JOB = sys.argv[1] if len(sys.argv) > 1 else "20260803_230151_Si"
work = ROOT / "work" / JOB


def flag(ok: bool) -> str:
    return "OK" if ok else "NO"


def main() -> int:
    print(f"=== Validation κ_L · job {JOB} ===\n")
    if not work.is_dir():
        print(f"NO  job absent : {work}")
        return 1

    qe = work / "qe"
    outs = sorted(qe.glob("disp_*.out")) if qe.is_dir() else []
    done = [p for p in outs if "JOB DONE" in p.read_text(encoding="utf-8", errors="replace")]
    print(f"{flag(len(done) == len(outs) > 0)}  QE JOB DONE : {len(done)}/{len(outs)}")

    dfset = work / "alamode" / "DFSET"
    print(f"{flag(dfset.is_file() and dfset.stat().st_size > 0)}  DFSET présent")

    alm_in = work / "alamode" / "alm_optimize.in"
    norder = None
    if alm_in.is_file():
        import re

        m = re.search(r"NORDER\s*=\s*(\d+)", alm_in.read_text(encoding="utf-8", errors="replace"))
        norder = int(m.group(1)) if m else None
    print(f"{flag(norder is not None and norder >= 2)}  alm NORDER≥2 (lu={norder})")

    xmls = sorted((work / "alamode").glob("*.xml")) if (work / "alamode").is_dir() else []
    has_fc3 = False
    if xmls:
        text = xmls[0].read_text(encoding="utf-8", errors="replace")
        has_fc3 = "ANHARM3" in text.upper() or "<FC3" in text
    print(f"{flag(has_fc3)}  FCSXML avec ANHARM3/FC3")

    anphon = work / "alamode" / "anphon.in"
    prim = False
    if anphon.is_file() and (work / "structure.cif").is_file():
        # Heuristique : 1ʳᵉ ligne de vecteur anphon (Bohr) vs structure Å
        import re

        from ase.io import read

        atoms = read(str(work / "structure.cif"))
        a_prim_bohr = float(atoms.cell.lengths()[0]) / 0.529177210903
        m = re.search(r"&cell.*?1\.0.*?\n\s*([0-9.eE+-]+)", anphon.read_text(encoding="utf-8", errors="replace"), re.S)
        if m:
            a_anphon = float(m.group(1))
            prim = abs(a_anphon - a_prim_bohr) / max(a_prim_bohr, 1e-6) < 0.05
            print(
                f"{flag(prim)}  anphon &cell ≈ primitive "
                f"(anphon={a_anphon:.3f} Bohr · prim={a_prim_bohr:.3f} Bohr)"
            )
        else:
            print("NO  anphon.in : vecteur &cell illisible")
    else:
        print(f"{flag(False)}  anphon.in / structure.cif")

    kls = list((work / "alamode").glob("*.kl")) + list((work / "results").glob("*.kl"))
    print(f"{flag(bool(kls))}  fichier .kl ({len(kls)})")

    res = work / "results" / "results.json"
    if res.is_file():
        data = json.loads(res.read_text(encoding="utf-8"))
        n = len(data.get("kappa") or [])
        print(f"{flag(n > 0)}  results.json kappa points = {n}")
    else:
        print("NO  results.json")

    print("\n--- Correctifs code (attendus) ---")
    wf = (ROOT / "backend" / "workflow.py").read_text(encoding="utf-8")
    print(f"{flag('structure.cif' in wf and 'mailPRIMITIVE' not in wf and 'maille PRIMITIVE' in wf)}  prepare_anphon → structure.cif")
    print(f"{flag('_xml_has_anharm3' in wf)}  garde ANHARM3")
    print(f"{flag('_collect_kappa_rows' in wf)}  collecte .kl renforcée")

    print(
        "\nVerdict : κ_L publiable pour ce job = "
        + ("OUI" if (len(done) == len(outs) > 0 and has_fc3 and kls) else "NON — terminer QE 3×3×3 puis alm NORDER=2 → rta")
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

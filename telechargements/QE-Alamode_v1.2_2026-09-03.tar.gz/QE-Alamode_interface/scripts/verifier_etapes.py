#!/usr/bin/env python3
"""Vérifie chaque étape du workflow QE–ALAMODE (local)."""
from __future__ import annotations

import json
import subprocess
import sys
import urllib.request
from pathlib import Path

import os

BASE = os.environ.get("QEALAMODE_API") or f"http://127.0.0.1:{os.environ.get('QEALAMODE_PORT', '5020')}"
ROOT = Path(__file__).resolve().parents[1]
CIF = ROOT / "inputs" / "Si" / "Si_diamond.cif"


class StepResult:
    def __init__(self, name: str):
        self.name = name
        self.ok = False
        self.detail = ""


def http_json(method: str, path: str, data=None, timeout: int = 3600):
    body = None
    headers = {}
    if data is not None:
        body = json.dumps(data).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(BASE + path, data=body, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def curl_upload(job_id: str, filepath: Path):
    r = subprocess.run(
        [
            "curl",
            "-s",
            "-X",
            "POST",
            f"{BASE}/api/jobs/{job_id}/structure",
            "-F",
            f"file=@{filepath}",
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    return json.loads(r.stdout)


def main() -> int:
    results: list[StepResult] = []

    # 0. Santé
    s = StepResult("0. API / health")
    try:
        h = http_json("GET", "/api/health")
        s.ok = bool(h.get("ok") and h.get("tools", {}).get("pw_x"))
        tools = h.get("tools", {})
        s.detail = (
            f"pw.x={'OK' if tools.get('pw_x') else 'ABSENT'} · "
            f"alm={'OK' if tools.get('alm') else 'ABSENT'} · "
            f"anphon={'OK' if tools.get('anphon') else 'ABSENT'}"
        )
    except Exception as e:
        s.detail = str(e)
    results.append(s)
    if not s.ok:
        _print(results)
        return 1

    # 1. Créer job
    s = StepResult("1. Créer job")
    try:
        job = http_json("POST", "/api/jobs", {"name": "VerifySi"})
        jid = job["job_id"]
        s.ok = bool(job.get("ok") and jid)
        s.detail = jid
    except Exception as e:
        s.detail = str(e)
        results.append(s)
        _print(results)
        return 1
    results.append(s)

    # 2. Import structure
    s = StepResult("2. Import structure (CIF)")
    try:
        if not CIF.exists():
            raise FileNotFoundError(CIF)
        data = curl_upload(jid, CIF)
        s.ok = bool(data.get("ok"))
        st = data.get("structure", {})
        s.detail = f"{st.get('formula')} · nat={st.get('nat')}"
    except Exception as e:
        s.detail = str(e)
    results.append(s)

    # 3. Supercellule
    s = StepResult("3. Supercellules & déplacements")
    try:
        data = http_json(
            "POST",
            f"/api/jobs/{jid}/supercell",
            {"nx": 1, "ny": 1, "nz": 1, "n_patterns": 12, "magnitude": 0.02},
        )
        s.ok = bool(data.get("ok"))
        sc = data.get("supercell", {})
        s.detail = f"nat={sc.get('nat')} · patterns={sc.get('n_patterns')} · inputs QE générés"
        qe_in = ROOT / "work" / jid / "qe" / "disp_0000.in"
        if not qe_in.exists():
            s.ok = False
            s.detail += " · MANQUE disp_0000.in"
    except Exception as e:
        s.detail = str(e)
    results.append(s)

    # 4. QE forces
    s = StepResult("4. Forces QE (pw.x)")
    try:
        data = http_json("POST", f"/api/jobs/{jid}/qe/run", {"max_jobs": 12})
        res = (data.get("results") or [{}])[0]
        s.ok = bool(data.get("ok") and res.get("ok"))
        s.detail = f"rc={res.get('rc')} · forces={res.get('forces')} · dfset_auto={bool((data.get('dfset') or {}).get('ok'))}"
    except Exception as e:
        s.detail = str(e)
    results.append(s)

    # 5. DFSET
    s = StepResult("5. Construction DFSET")
    try:
        data = http_json("POST", f"/api/jobs/{jid}/dfset")
        s.ok = bool(data.get("ok"))
        s.detail = f"configs={data.get('n_configs')} · file={data.get('file')}"
        df = ROOT / "work" / jid / "alamode" / "DFSET"
        if not df.exists() or df.stat().st_size < 10:
            s.ok = False
            s.detail += " · fichier DFSET invalide"
        else:
            lines = df.read_text(encoding="utf-8").strip().splitlines()
            s.detail += f" · lignes={len(lines)}"
    except Exception as e:
        s.detail = str(e)
    results.append(s)

    # 6. Préparer alm
    s = StepResult("6. Préparer alm_optimize.in")
    try:
        data = http_json(
            "POST",
            f"/api/jobs/{jid}/alm/prepare",
            {"norder": 2, "cutoff": 0},
        )
        s.ok = bool(data.get("ok"))
        path = ROOT / "work" / jid / "alamode" / "alm_optimize.in"
        s.detail = f"file={data.get('file')} · exists={path.exists()} · NORDER=2"
        if not path.exists():
            s.ok = False
    except Exception as e:
        s.detail = str(e)
    results.append(s)

    # 7. Exécuter alm (IFC 2ᵉ + 3ᵉ ordre)
    s = StepResult("7. Exécuter alm")
    try:
        data = http_json("POST", f"/api/jobs/{jid}/alm/run", {"which": "optimize"})
        if data.get("ok"):
            s.ok = True
            s.detail = f"rc={data.get('rc')}"
        else:
            s.ok = False
            s.detail = data.get("error") or f"rc={data.get('rc')}"
            if "introuvable" in (s.detail or "").lower() or "alm" in (s.detail or "").lower():
                s.detail = "ATTENDU sans ALAMODE : " + s.detail
    except Exception as e:
        s.detail = str(e)
    results.append(s)

    # 8. Préparer anphon phonons
    s = StepResult("8. Préparer anphon.in (phonons)")
    try:
        data = http_json(
            "POST",
            f"/api/jobs/{jid}/anphon/prepare",
            {"mode": "phonons", "kmesh": [4, 4, 4], "tmin": 0, "tmax": 300, "dt": 50},
        )
        path = ROOT / "work" / jid / "alamode" / "anphon.in"
        s.ok = bool(data.get("ok") and path.exists())
        s.detail = f"file={data.get('file')} · exists={path.exists()}"
    except Exception as e:
        s.detail = str(e)
    results.append(s)

    # 9. Exécuter anphon phonons
    s = StepResult("9. Exécuter anphon (phonons)")
    try:
        data = http_json("POST", f"/api/jobs/{jid}/anphon/run")
        if data.get("ok"):
            nb = len(list((ROOT / "work" / jid / "alamode").glob("*.bands")))
            s.ok = True
            s.detail = f"rc={data.get('rc')} · bands={nb}"
        else:
            s.ok = False
            s.detail = data.get("error") or f"rc={data.get('rc')}"
            if "introuvable" in (s.detail or "").lower():
                s.detail = "ATTENDU sans ALAMODE : " + s.detail
    except Exception as e:
        s.detail = str(e)
    results.append(s)

    # 10. Préparer anphon RTA
    s = StepResult("10. Préparer anphon.in (rta)")
    try:
        data = http_json(
            "POST",
            f"/api/jobs/{jid}/anphon/prepare",
            {"mode": "rta", "kmesh": [5, 5, 5], "tmin": 100, "tmax": 500, "dt": 50},
        )
        path = ROOT / "work" / jid / "alamode" / "anphon.in"
        s.ok = bool(data.get("ok") and path.exists())
        s.detail = f"mode=rta · exists={path.exists()}"
    except Exception as e:
        s.detail = str(e)
    results.append(s)

    # 11. Exécuter anphon RTA → κ_L
    s = StepResult("11. Exécuter anphon (rta → κ)")
    try:
        data = http_json("POST", f"/api/jobs/{jid}/anphon/run")
        nkap = len(data.get("kappa") or [])
        kl = list((ROOT / "work" / jid / "alamode").glob("*.kl"))
        if data.get("ok") and (nkap > 0 or kl):
            s.ok = True
            s.detail = f"rc={data.get('rc')} · kappa_points={nkap} · kl={[p.name for p in kl]}"
        else:
            s.ok = False
            s.detail = data.get("error") or f"rc={data.get('rc')} · kappa_points={nkap}"
            if "introuvable" in (s.detail or "").lower():
                s.detail = "ATTENDU sans ALAMODE : " + s.detail
    except Exception as e:
        s.detail = str(e)
    results.append(s)

    # 12. Fiche technique
    s = StepResult("12. Fiche technique & résultats")
    try:
        data = http_json("GET", f"/api/jobs/{jid}/results")
        n_ok = sum(1 for p in data.get("params") or [] if p.get("status") == "ok")
        fiche = data.get("fiche") or {}
        fiche_txt = ROOT / "work" / jid / "results" / "fiche_technique.txt"
        s.ok = bool(data.get("ok") and fiche_txt.exists() and n_ok >= 10)
        s.detail = (
            f"params_ok={n_ok} · fiche={fiche.get('txt')} · "
            f"kappa_rows={len(data.get('kappa') or [])}"
        )
    except Exception as e:
        s.detail = str(e)
    results.append(s)

    # 13. Status job
    s = StepResult("13. Statut job complet")
    try:
        data = http_json("GET", f"/api/jobs/{jid}")
        s.ok = bool(data.get("ok"))
        files = data.get("files", {})
        s.detail = (
            f"qe_in={len(files.get('qe_inputs') or [])} · "
            f"qe_out={len(files.get('qe_outputs') or [])} · "
            f"alamode={len(files.get('alamode') or [])} · "
            f"results={len(files.get('results') or [])}"
        )
    except Exception as e:
        s.detail = str(e)
    results.append(s)

    _print(results)
    return 0 if all(r.ok for r in results) else 2


def _print(results: list[StepResult]) -> None:
    print("")
    print("=" * 64)
    print("  VÉRIFICATION ÉTAPE PAR ÉTAPE — QE–ALAMODE")
    print("=" * 64)
    for r in results:
        mark = "✅" if r.ok else "❌"
        # étapes ALAMODE absentes : avertissement plutôt que échec bloquant affiché
        if (not r.ok) and r.detail.startswith("ATTENDU"):
            mark = "⚠️ "
        print(f"{mark} {r.name}")
        print(f"   {r.detail}")
    print("=" * 64)
    ok_n = sum(1 for r in results if r.ok)
    warn_n = sum(1 for r in results if (not r.ok) and r.detail.startswith("ATTENDU"))
    fail_n = len(results) - ok_n - warn_n
    print(f"  Résumé : {ok_n} OK · {warn_n} en attente ALAMODE · {fail_n} échec(s)")
    print("=" * 64)
    print("")


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env bash
# Compile ALAMODE avec libs système (OpenBLAS / LAPACK / spglib / OpenMPI)
# pour une distribution portable — Proposition 2.
# Usage : ./scripts/INSTALL_ALAMODE_PORTABLE.sh
#   ALAMODE_INSTALL_TO_BIN=1 …   → copie aussi alm/anphon dans bin/ (remplace les binaires livrés)
#   ALAMODE_SKIP_APT=1 …         → ne pas lancer apt-get (paquets déjà installés / pas de sudo)
set -euo pipefail

HERE="$(cd "$(dirname "$0")/.." && pwd)"
PREFIX="${ALAMODE_PORTABLE_PREFIX:-$HERE/alamode-portable}"
SRC="${ALAMODE_SRC:-/tmp/alamode-portable-src}"
DEST_BIN="$HERE/bin-portable"
INSTALL_TO_BIN="${ALAMODE_INSTALL_TO_BIN:-0}"

echo "=== ALAMODE portable → $PREFIX (copie binaires dans $DEST_BIN) ==="

if [[ "${ALAMODE_SKIP_APT:-0}" != "1" ]] && command -v apt-get >/dev/null 2>&1; then
  sudo apt-get update
  sudo apt-get install -y \
    git cmake g++ gfortran \
    libeigen3-dev libopenblas-dev liblapack-dev \
    libsymspg-dev libopenmpi-dev openmpi-bin \
    build-essential
fi

rm -rf "$SRC"
git clone --depth 1 https://github.com/ttadano/alamode.git "$SRC"
mkdir -p "$SRC/_build" "$PREFIX/bin" "$DEST_BIN"
cd "$SRC/_build"

# Forcer BLAS/LAPACK système (éviter MKL si oneAPI est dans l'environnement)
unset MKLROOT INTEL_MKL_DIR 2>/dev/null || true
export BLA_VENDOR=OpenBLAS

cmake .. \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX="$PREFIX" \
  -DBLA_VENDOR=OpenBLAS \
  -DCMAKE_PREFIX_PATH="/usr"

cmake --build . -j"$(nproc)"

mapfile -t BINS < <(find "$SRC" -type f \( -name alm -o -name anphon \) -perm -111)
if [[ ${#BINS[@]} -eq 0 ]]; then
  echo "ERREUR: binaires introuvables après compilation."
  exit 1
fi

for b in "${BINS[@]}"; do
  cp -f "$b" "$PREFIX/bin/"
  cp -f "$b" "$DEST_BIN/"
  echo "  → $DEST_BIN/$(basename "$b")"
  echo "  deps:"
  ldd "$DEST_BIN/$(basename "$b")" | sed 's/^/    /' | head -20
done

# Vérifier absence de MKL Intel
if ldd "$DEST_BIN/alm" | grep -qi mkl; then
  echo "AVERTISSEMENT: alm semble encore lié à MKL — vérifiez la config CMake."
else
  echo "OK: alm sans MKL Intel détecté dans ldd."
fi

if [[ "$INSTALL_TO_BIN" == "1" ]]; then
  mkdir -p "$HERE/bin"
  cp -f "$DEST_BIN/alm" "$DEST_BIN/anphon" "$HERE/bin/"
  chmod +x "$HERE/bin/alm" "$HERE/bin/anphon"
  echo "Binaires installés dans : $HERE/bin (utilisés par l'interface)"
fi

echo ""
echo "Binaires portables dans : $DEST_BIN"
echo "Ensuite : ./scripts/pack_deploiement.sh prop2   (ou ./DEMARRER.sh si ALAMODE_INSTALL_TO_BIN=1)"
echo ""

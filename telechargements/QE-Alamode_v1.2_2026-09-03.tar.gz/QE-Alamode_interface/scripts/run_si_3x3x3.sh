#!/usr/bin/env bash
# Chaîne complète Si · surcellule 3×3×3 · 12 motifs
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
API="${QEALAMODE_API:-http://127.0.0.1:5020}"
MAT="Si"

cd "$HERE"
curl -sf "$API/api/health" >/dev/null || { echo "API inactive — lancer ./DEMARRER.sh"; exit 1; }

JOB=$(curl -sf -X POST "$API/api/jobs" -H "Content-Type: application/json" \
  -d "{\"name\":\"$MAT\",\"material\":\"$MAT\"}" | python3 -c "import sys,json; print(json.load(sys.stdin)['job_id'])")
echo "Job: $JOB"

curl -sf -X POST "$API/api/jobs/$JOB/use-input" -H "Content-Type: application/json" \
  -d '{"name":"Si/Si-scf.in"}' >/dev/null

echo "Surcellule 3×3×3 · 12 motifs…"
curl -sf -X POST "$API/api/jobs/$JOB/supercell" -H "Content-Type: application/json" \
  -d '{"nx":3,"ny":3,"nz":3,"magnitude":0.01,"n_patterns":12}' >/dev/null

echo "pw.x (long avec 54 atomes)…"
curl -sf -X POST "$API/api/jobs/$JOB/qe/run" -H "Content-Type: application/json" \
  -d '{"max_jobs":8}'

"$HERE/scripts/complete_pipeline.sh" "$JOB" "$MAT"

#!/usr/bin/env python3
"""Vérifier DFT pour une supercellule N×N×N — y compris N petit (PC peu puissant).

Sans --run : diagnostic machine + recommandation de N + contrôle d'un job existant.
Avec --run  : lance une vérif légère via l'API (défaut N=1, adapté aux PC ≤16 Go).

Exemples :
  python3 scripts/verify_dft_nxn.py
  python3 scripts/verify_dft_nxn.py --n 1 --run
  python3 scripts/verify_dft_nxn.py --n 2 --job 20260803_xxxx_Si
  python3 scripts/verify_dft_nxn.py --n 3   # estime seulement (souvent trop lourd)
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = os.environ.get("QEALAMODE_API", "http://127.0.0.1:5020")
CIF = ROOT / "inputs" / "Si" / "Si_diamond.cif"

# RAM QE estimée (Go) pour Si ecut≈60 — ordre de grandeur (pw.x « Estimated max dynamical RAM »)
RAM_GB_EST = {1: 0.5, 2: 2.5, 3: 10.0}
ATOMS = {1: 2, 2: 16, 3: 54}
# Durée indicative / config sur i7 dual-core si RAM OK (heures)
HOURS_PER_CFG = {1: 0.05, 2: 0.4, 3: 3.0}


def mem_available_gb() -> float | None:
    try:
        txt = Path("/proc/meminfo").read_text(encoding="utf-8")
        total = avail = None
        for line in txt.splitlines():
            if line.startswith("MemTotal:"):
                total = int(line.split()[1]) / 1024 / 1024
            elif line.startswith("MemAvailable:"):
                avail = int(line.split()[1]) / 1024 / 1024
        return avail if avail is not None else total
    except OSError:
        return None


def http_json(method: str, path: str, data=None, timeout: int = 7200):
    body = None
    headers = {}
    if data is not None:
        body = json.dumps(data).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(BASE + path, data=body, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def recommend_n(avail: float | None) -> int:
    if avail is None:
        return 1
    if avail >= 20:
        return 3
    if avail >= 8:
        return 2
    return 1


def print_machine_advice(n_want: int) -> int:
    avail = mem_available_gb()
    rec = recommend_n(avail)
    print("=== Machine ===")
    print(f"RAM disponible ≈ {avail:.1f} Go" if avail else "RAM : inconnue")
    print(f"N recommandé sur ce PC : {rec}×{rec}×{rec}")
    print()
    print("=== Estimation N×N×N (Si, ecut≈60) ===")
    print(f"{'N':>3}  {'atomes':>6}  {'RAM QE':>8}  {'/config':>8}  {'12 configs':>10}  avis")
    for n in (1, 2, 3):
        ram = RAM_GB_EST[n]
        h1 = HOURS_PER_CFG[n]
        h12 = h1 * 12
        if avail is None:
            avis = "?"
        elif ram > (avail * 0.85):
            avis = "déconseillé ici (RAM insuffisante)"
        elif ram > (avail * 0.55):
            avis = "limite / risqué"
        else:
            avis = "OK sur ce PC"
        mark = "← demandé" if n == n_want else ""
        print(f"{n:>3}  {ATOMS[n]:>6}  {ram:>6.1f} Go  {h1:>6.2f} h  {h12:>8.1f} h  {avis} {mark}")
    print()
    print("Note : 3×3×3 est le standard publiable sur machine puissante")
    print("       (ex. i9-14900K + 64 Go RAM) — pas « impossible », juste inadapté aux PC peu pourvus.")
    if avail is not None and RAM_GB_EST[n_want] > avail * 0.85:
        print(
            f"ATTENTION : {n_want}×{n_want}×{n_want} demande ~{RAM_GB_EST[n_want]:.0f} Go ; "
            f"ce PC n’en a que ~{avail:.0f} Go disponibles."
        )
        print(f"→ Sur ce PC : --n {rec} --run · Sur 14900K/64 Go : --n 3 (parcours publication)")
        return 1
    return 0


def check_job_dft(job_id: str, n: int) -> int:
    job = ROOT / "work" / job_id
    print(f"=== Contrôle job {job_id} (attendu {n}×{n}×{n}) ===")
    if not job.is_dir():
        print(f"NO  dossier absent : {job}")
        return 1
    qe = job / "qe"
    inputs = sorted(qe.glob("disp_*.in")) if qe.is_dir() else []
    outs = sorted(qe.glob("disp_*.out")) if qe.is_dir() else []
    done = [
        p
        for p in outs
        if "JOB DONE" in p.read_text(encoding="utf-8", errors="replace")
    ]
    print(f"{'OK' if inputs else 'NO'}  inputs disp_*.in : {len(inputs)}")
    print(f"{'OK' if done and len(done) == len(inputs) else 'NO'}  JOB DONE : {len(done)}/{len(inputs)}")

    # Heuristique taille cellule depuis un .out ou supercell.cif
    sc = job / "supercell.cif"
    if sc.is_file():
        try:
            from ase.io import read

            atoms = read(str(sc))
            nat = len(atoms)
            expect = ATOMS.get(n)
            ok_nat = expect is None or nat == expect
            print(f"{'OK' if ok_nat else 'NO'}  supercell.cif nat={nat} (attendu {expect} pour N={n})")
        except Exception as exc:
            print(f"NO  lecture supercell.cif : {exc}")
    else:
        print("NO  supercell.cif absent")

    if outs:
        text = outs[0].read_text(encoding="utf-8", errors="replace")
        m = re.search(r"Estimated max dynamical RAM per process >\s+([\d.]+)\s+GB", text)
        if m:
            print(f"INFO  RAM estimée QE (1er out) : {m.group(1)} Go / process")
        if "JOB DONE" not in text and "SIGTERM" in "".join(
            p.read_text(encoding="utf-8", errors="replace")[-200:]
            for p in sorted((ROOT / "logs").glob(f"{job_id}_disp_*.log"))[:3]
        ):
            print("INFO  logs : SIGTERM observé (souvent manque de RAM)")

    ok = bool(inputs) and len(done) == len(inputs) > 0
    print()
    print("Verdict DFT :", "OK — forces complètes" if ok else "INCOMPLET — relancer pw.x / choisir N plus petit")
    return 0 if ok else 2


def run_light_verify(n: int, n_patterns: int, norder: int) -> int:
    print(f"=== Vérification active API · {n}×{n}×{n} · motifs={n_patterns} · NORDER={norder} ===")
    print(f"API : {BASE}")
    try:
        h = http_json("GET", "/api/health", timeout=10)
    except Exception as exc:
        print(f"NO  API inaccessible ({exc}). Lancez ./DEMARRER.sh puis réessayez.")
        return 1
    if not h.get("tools", {}).get("pw_x"):
        print("NO  pw.x introuvable")
        return 1
    print("OK  API + pw.x")

    job = http_json("POST", "/api/jobs", {"name": f"VerifyDFT_{n}x{n}x{n}"})
    jid = job["job_id"]
    print(f"OK  job {jid}")

    if not CIF.is_file():
        # fallback SCF template
        print("INFO  pas de CIF — utilisation SCF matériau Si via use-input")
        data = http_json("POST", f"/api/jobs/{jid}/use-input", {"name": "Si/Si-scf.in"})
        if not data.get("ok"):
            print("NO  use-input :", data)
            return 1
    else:
        r = subprocess.run(
            [
                "curl",
                "-s",
                "-X",
                "POST",
                f"{BASE}/api/jobs/{jid}/structure",
                "-F",
                f"file=@{CIF}",
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        data = json.loads(r.stdout or "{}")
        if not data.get("ok"):
            print("NO  import CIF :", data)
            return 1
        print("OK  structure CIF")

    data = http_json(
        "POST",
        f"/api/jobs/{jid}/supercell",
        {"nx": n, "ny": n, "nz": n, "n_patterns": n_patterns, "magnitude": 0.01, "norder": norder},
    )
    if not data.get("ok"):
        print("NO  supercell :", data)
        return 1
    print(f"OK  supercellule {n}×{n}×{n}")

    data = http_json("POST", f"/api/jobs/{jid}/qe/run", {"max_jobs": n_patterns}, timeout=max(3600, n_patterns * 3600))
    n_done = data.get("n_done")
    n_exp = data.get("n_expected")
    print(f"INFO  qe/run → n_done={n_done}/{n_exp} remaining={data.get('remaining')}")
    # Relancer tant qu'il reste des configs (lots)
    guard = 0
    while data.get("remaining") and data.get("remaining") > 0 and guard < 20:
        guard += 1
        data = http_json(
            "POST",
            f"/api/jobs/{jid}/qe/run",
            {"max_jobs": n_patterns},
            timeout=max(3600, n_patterns * 3600),
        )
        print(f"INFO  lot {guard} → n_done={data.get('n_done')}/{data.get('n_expected')}")

    df = http_json("POST", f"/api/jobs/{jid}/dfset", {})
    print(f"{'OK' if df.get('ok') else 'NO'}  DFSET : {df.get('n_configs')}/{df.get('n_expected')} {df.get('error') or ''}")

    alm = http_json("POST", f"/api/jobs/{jid}/alm/prepare", {"norder": norder, "cutoff": 0})
    print(f"{'OK' if alm.get('ok') else 'NO'}  alm prepare NORDER={norder}")
    if alm.get("ok"):
        run = http_json("POST", f"/api/jobs/{jid}/alm/run", {"which": "optimize"}, timeout=1800)
        print(f"{'OK' if run.get('ok') else 'NO'}  alm run rc={run.get('rc')} {run.get('error') or ''}")

    ph = http_json(
        "POST",
        f"/api/jobs/{jid}/anphon/prepare",
        {"mode": "phonons", "kmesh": [8, 8, 8]},
    )
    print(f"{'OK' if ph.get('ok') else 'NO'}  anphon prepare (phonons) cell={ph.get('structure')}")
    if ph.get("ok"):
        pr = http_json("POST", f"/api/jobs/{jid}/anphon/run", timeout=1800)
        print(f"{'OK' if pr.get('ok') else 'NO'}  anphon phonons")

    if norder >= 2:
        rt = http_json(
            "POST",
            f"/api/jobs/{jid}/anphon/prepare",
            {"mode": "rta", "kmesh": [6, 6, 6], "tmin": 300, "tmax": 600, "dt": 100},
        )
        print(f"{'OK' if rt.get('ok') else 'NO'}  anphon prepare (rta) {rt.get('error') or ''}")
        if rt.get("ok"):
            rr = http_json("POST", f"/api/jobs/{jid}/anphon/run", timeout=3600)
            nk = len(rr.get("kappa") or [])
            print(f"{'OK' if rr.get('ok') and nk else 'NO'}  anphon rta · κ points={nk} {rr.get('error') or ''}")

    print()
    return check_job_dft(jid, n)


def main() -> int:
    ap = argparse.ArgumentParser(description="Vérifier DFT N×N×N (petit N pour PC limités)")
    ap.add_argument("--n", type=int, default=1, choices=[1, 2, 3], help="taille supercellule (défaut 1)")
    ap.add_argument("--patterns", type=int, default=None, help="nombre de motifs (défaut : 2 si N=1, 6 si N=2, 12 si N=3)")
    ap.add_argument("--norder", type=int, default=None, help="NORDER alm (défaut 1 si N=1, sinon 2)")
    ap.add_argument("--job", type=str, default="", help="contrôler un job existant (sans --run)")
    ap.add_argument("--run", action="store_true", help="lancer la vérif via l'API (pw.x réel)")
    args = ap.parse_args()

    n = args.n
    n_patterns = args.patterns or {1: 2, 2: 6, 3: 12}[n]
    norder = args.norder if args.norder is not None else (1 if n == 1 else 2)

    rc_adv = print_machine_advice(n)
    if args.job and not args.run:
        return check_job_dft(args.job, n)
    if not args.run:
        print("Mode diagnostic seulement. Pour vérifier DFT en réel (N petit) :")
        print(f"  1) ./DEMARRER.sh")
        print(f"  2) python3 scripts/verify_dft_nxn.py --n {recommend_n(mem_available_gb())} --run")
        print()
        print("Rappels guide :")
        print("  · N=1 : test chaîne (phonons) — PC limité")
        print("  · N=2 : κ_L indicative — PC moyen (≥8–16 Go)")
        print("  · N=3 : κ_L publiable — machine puissante (ex. 14900K + 64 Go)")
        return rc_adv

    if rc_adv != 0 and n >= 3:
        print("Sur cette machine, N=3 est déconseillé (RAM). Utilisez --n 1 --run ici,")
        print("ou lancez N=3 sur une station type 14900K / 64 Go.")
        return rc_adv
    return run_light_verify(n, n_patterns, norder)


if __name__ == "__main__":
    raise SystemExit(main())

# QE–ALAMODE Version 1.2

**Auteur :** Prof. S. Hiadsi — LMESM / Faculté de Physique / USTO-MB, Oran  
**Date :** 2026-09-03  
**Port :** http://127.0.0.1:5020/

## Contenu

- Interface web locale (Optimisation, Calculs, Résultats, Guide)
- Backend API Flask
- **ALAMODE embarqué** : `bin/alm` et `bin/anphon` (compilation portable, **sans Intel oneAPI / MKL**)
- Outils Python ALAMODE (`tools/alamode/displace.py`) pour les motifs de déplacement « alm suggest »
- Guides et exemple prêt (Si : `inputs/Si/` + `pseudos/Si.UPF`)

## Prérequis sur votre PC

1. **Ubuntu 24.04 ou plus récent** (les binaires ALAMODE fournis exigent glibc ≥ 2.38 ; sur Ubuntu 22.04
   recompilez-les : `ALAMODE_INSTALL_TO_BIN=1 ./scripts/INSTALL_ALAMODE_PORTABLE.sh`)
2. **Quantum ESPRESSO** (`pw.x`) installé
3. Python 3.10+ (l'installateur crée un `.venv` si `pip --user` est refusé — PEP 668)
4. Bibliothèques système pour ALAMODE (souvent déjà présentes) :
   ```bash
   sudo apt-get install -y libblas3 liblapack3 libfftw3-double3 libsymspg2 libgomp1 libgfortran5 libopenmpi3 libnuma1
   ```
   *(`ldd bin/alm` et `ldd bin/anphon` indiquent les bibliothèques manquantes ; l'installateur le vérifie.)*

**Vous n'avez pas à compiler ni installer ALAMODE** : les binaires sont dans `bin/` et détectés automatiquement.

## Installation rapide

```bash
tar -xzf QE-Alamode_v1.2_2026-09-03.tar.gz
cd QE-Alamode_interface
export QE_BIN_DIR=/chemin/vers/qe/bin        # dossier contenant pw.x (facultatif si pw.x est dans le PATH)
./INSTALLER_AUTRE_PC.sh --non-interactif     # détecte pw.x, ALAMODE = ./bin, dépendances Python
./DEMARRER.sh
# → http://127.0.0.1:5020/
```

Arrêt : `./ARRETER.sh` · Reconfigurer les chemins : `./CONFIGURER.sh`

## Version 1.2 — audit et correctifs

- **anphon** : refuse la supercellule si `structure.cif` (maille primitive) manque — plus de κ_L silencieuse fausse
- **QE / DFSET** : si toutes les configs sont dites « terminées » mais DFSET échoue, l'API renvoie `ok=false`
- **Installateur** : `config_local.sh` n'est écrit qu'après vérifications réussies
- **CONFIGURER.sh** : conserve `QEALAMODE_PYTHON` (`.venv`)
- **k-mesh API** : liste courte / invalide complétée (plus d'IndexError)
- **Détection ALAMODE** : préfère `bin-portable/` si `bin/` est encore lié à MKL
- **`tools/alamode/displace.py` inclus** : motifs alm suggest (pas le repli aléatoire ASE)
- Erreurs API en JSON ; timeouts `alm` / `anphon` ; installateur PEP 668 (`.venv`)
- ALAMODE embarqué **sans oneAPI** ; guides 3×3×3 clarifiés

Historique v1.1 : smoke DFT 1×1×1, page Résultats, pack portable.

## Licence d'usage

Libre pour la recherche et l'enseignement. Toute modification du code nécessite une collaboration avec l'auteur.

Contact : said.hiadsi@univ-usto.dz

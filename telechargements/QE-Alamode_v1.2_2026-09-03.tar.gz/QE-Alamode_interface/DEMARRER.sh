#!/usr/bin/env bash
# QE–ALAMODE — démarre l'API + ouvre le navigateur
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"
if [[ -f "$HERE/config_local.sh" ]]; then
  # shellcheck disable=SC1091
  source "$HERE/config_local.sh"
fi

HOST="${QEALAMODE_HOST:-127.0.0.1}"
PORT="${QEALAMODE_PORT:-5020}"
URL="http://${HOST}:${PORT}/"
PIDFILE="$HERE/logs/api.pid"
LOGFILE="$HERE/logs/api.log"

# Python : venv local (.venv créé par INSTALLER_AUTRE_PC.sh) > QEALAMODE_PYTHON > python3
PYTHON_BIN="${QEALAMODE_PYTHON:-python3}"
[[ -x "$HERE/.venv/bin/python" ]] && PYTHON_BIN="$HERE/.venv/bin/python"
if ! "$PYTHON_BIN" -c "import flask, ase, numpy" 2>/dev/null; then
  echo "  ✗ Dépendances Python manquantes (flask, ase, numpy) pour : $PYTHON_BIN"
  echo "    Lancez d'abord : ./INSTALLER_AUTRE_PC.sh --non-interactif"
  exit 1
fi

# ALAMODE embarqué : bin/alm + bin/anphon du pack si ALAMODE_BIN_DIR n'est pas défini
if [[ -z "${ALAMODE_BIN_DIR:-}" && -x "$HERE/bin/alm" && -x "$HERE/bin/anphon" ]]; then
  export ALAMODE_BIN_DIR="$HERE/bin"
fi

mkdir -p "$HERE/logs" "$HERE/work" "$HERE/inputs" "$HERE/outputs"

if [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
  echo "  API déjà active → $URL"
else
  echo ""
  echo "  QE–ALAMODE — HIADSI"
  echo "  URL : $URL"
  echo ""
  nohup "$PYTHON_BIN" "$HERE/backend/api_server.py" >>"$LOGFILE" 2>&1 &
  echo $! >"$PIDFILE"
  sleep 1
fi

# attendre health (curl si présent, sinon Python)
health_ok() {
  if command -v curl >/dev/null 2>&1; then
    curl -sf "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1
  else
    "$PYTHON_BIN" -c "import urllib.request,sys; urllib.request.urlopen('http://127.0.0.1:${PORT}/api/health', timeout=2); sys.exit(0)" >/dev/null 2>&1
  fi
}
started=0
for i in $(seq 1 40); do
  if health_ok; then started=1; break; fi
  sleep 0.3
done
if [[ "$started" -eq 0 ]]; then
  echo "  ✗ L'API ne répond pas sur $URL — voir $LOGFILE :"
  tail -n 15 "$LOGFILE" 2>/dev/null | sed 's/^/    /'
  exit 1
fi

# Firefox par défaut (Chrome pose problème sur cette machine)
if command -v firefox >/dev/null 2>&1; then
  nohup firefox --new-window "$URL" >/dev/null 2>&1 &
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$URL" >/dev/null 2>&1 || true
fi

echo "  Santé : curl -s http://127.0.0.1:${PORT}/api/health"
echo "  Arrêt  : ./ARRETER.sh"
echo ""

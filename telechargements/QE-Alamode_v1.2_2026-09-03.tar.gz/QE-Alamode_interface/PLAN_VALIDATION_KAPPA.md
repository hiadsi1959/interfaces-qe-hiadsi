# Plan de validation κ_L — Silicium (QE–ALAMODE)

**Document :** PLAN_VALIDATION_KAPPA.md  
**Version :** 1.2 — 3 septembre 2026  
**Auteur :** S. Hiadsi · LMESM / USTO-MB · said.hiadsi@univ-usto.dz  
**Job cible :** `20260803_230151_Si` (Si · supercellule 3×3×3 · 12 motifs)  

> **Correctifs code (27/08/2026) :** `anphon` utilise désormais la **maille primitive** (`structure.cif`) ; RTA exige **ANHARM3** dans le XML ; DFSET partiel refusé ; parseur `.kl` validé sur la référence ALAMODE `si222.kl` (κ≈112 W/m/K à 300 K).

> **État actuel :** les forces QE 3×3×3 ne sont **pas** terminées sur ce PC → **pas de `.kl` de production** tant que `JOB DONE` ≠ 12/12. Tests automatiques : `python3 scripts/test_kappa_parser.py` · statut : `python3 scripts/validate_kappa_status.py`.

---

## Objectif

Valider scientifiquement la **conductivité thermique lattice** κ<sub>L</sub>(T) calculée par ALAMODE (`anphon` MODE=rta) après achèvement du job Si 3×3×3, et produire une fiche technique **publiable**.

---

## Prérequis (checklist avant validation)

Cocher chaque item avant de commencer la validation κ<sub>L</sub> :

- [ ] **12/12** fichiers `disp_*.out` contiennent `JOB DONE`
- [ ] Fichier `alamode/DFSET` présent et non vide
- [ ] `alm` exécuté avec **NORDER = 2** (IFC cubiques) — XML contient **ANHARM3**
- [ ] Erreur fit `alm` **< 2 %**
- [ ] **0 mode imaginaire** à Γ (anphon phonons)
- [ ] `anphon.in` : `&cell` = **maille primitive** (pas la supercellule)
- [ ] `anphon` exécuté en **MODE = rta**
- [ ] Fichier `*.kl` généré dans `work/<job_id>/alamode/`
- [ ] Fiche technique régénérée (onglet Résultats → Vérifier)

---

## Phase A — Achèvement du calcul (automatique ou manuel)

### A1. Surveiller la fin des calculs QE

```bash
cd /chemin/vers/QE-Alamode_interface

# Progression
cat work/20260803_230151_Si/progress.json

# Log en direct
tail -f logs/20260803_230151_Si_resume.log

# Compter les configs terminées
grep -l "JOB DONE" work/20260803_230151_Si/qe/disp_*.out | wc -l
# Attendu : 12
```

### A2. Pipeline ALAMODE (si pas déjà lancé par resume_job.sh)

```bash
# Défaut : NORDER=2 → phonons → rta (κ_L) → publish
./scripts/complete_pipeline.sh 20260803_230151_Si Si
# Harmonique seul (smoke test) : ./scripts/complete_pipeline.sh <job> Si 1 no
```

Ou via l'interface : **Calculs** → DFSET → alm (NORDER=2) → anphon phonons → anphon rta.

### A3. Vérification automatisée

```bash
python3 scripts/verifier_etapes.py
# Attendu : 14 OK · 0 échec
```

---

## Phase B — Contrôles phonons (avant κ_L)

### B1. Fréquence optique à Γ

| Critère | Valeur attendue | Où lire |
|---------|-----------------|---------|
| ω(Γ) LO | **515–525 cm⁻¹** | Résultats → Modes Γ |
| Modes imaginaires | **0** | Résultats → Modes imaginaires |
| ω_max bande | ~520 cm⁻¹ | Fiche technique |

**Référence expérimentale Si :** ~520 cm⁻¹ (Raman, LO à Γ).

```bash
# Extraire depuis JSON
python3 -c "
import json
d=json.load(open('work/20260803_230151_Si/results/results.json'))
for p in d.get('params',[]):
    if p['id'] in ('omega_lo','n_imag','fit_err'):
        print(p['label'], p['value'], p.get('unit',''), p['status'])
"
```

**Verdict B1 :** ☐ OK · ☐ À revoir (si ω hors ±2 % ou modes imaginaires > 0)

### B2. Bandes phonons

- Ouvrir **Résultats** → courbe dispersion
- Vérifier : pas de branche imaginaire, forme cohérente (Si : 3 branches acoustiques + 3 optiques)

**Verdict B2 :** ☐ OK · ☐ À revoir

### B3. Qualité de l'ajustement alm

| Critère | Seuil | Action si échec |
|---------|-------|-----------------|
| Erreur fit | < 2 % | Relancer alm |
| Erreur fit | 2–5 % | Augmenter motifs ou cutoff |
| Erreur fit | > 5 % | Revoir supercellule / forces QE |

**Verdict B3 :** ☐ OK · ☐ À revoir

---

## Phase C — Validation κ_L(T)

### C1. Extraire κ_L à 300 K

```bash
# Fichier ALAMODE
ls -la work/20260803_230151_Si/alamode/*.kl

# Aperçu (T en K, κ en W/m/K)
head -5 work/20260803_230151_Si/alamode/*.kl

# Via API / JSON
python3 -c "
import json
d=json.load(open('work/20260803_230151_Si/results/results.json'))
k=d.get('kappa') or []
for row in k:
    if abs(row.get('T',0)-300)<1:
        print('T=300 K:', row)
        break
else:
    print('kappa rows:', len(k))
    print('summary:', d.get('kappa_summary'))
"
```

### C2. Comparaison avec la littérature (Si bulk)

| Référence | κ_L à 300 K (W/m/K) | Notes |
|-----------|---------------------|-------|
| Expérience (pur, polycristal) | ~140–150 | Ordre de grandeur |
| Expérience (monocristal [100]) | ~150 | Directionnel |
| Calcul ALAMODE (tutoriel 2×2×2) | ~100–160 | Selon paramètres |
| **Votre calcul (3×3×3)** | **_______** | À remplir |

**Critère de succès :** κ<sub>L</sub>(300 K) dans l'intervalle **80–180 W/m/K** (ordre de grandeur bulk Si).  
Un écart > 30 % nécessite une analyse (k-mesh, NORDER, convergence supercellule).

**Verdict C2 :** ☐ OK · ☐ Acceptable · ☐ À recalculer

### C3. Courbe κ_L(T)

Vérifier dans l'interface ou la fiche HTML :

| Propriété attendue | Physique |
|--------------------|----------|
| κ<sub>L</sub> croît avec T (bas T) | Régime phonon-phonon |
| Maximum ou plateau ~100–400 K | Typique Si |
| Comportement à haute T | Dépend des scatterings |

**Verdict C3 :** ☐ Forme physique cohérente · ☐ Anomalie détectée

### C4. Isotropie (Si cubique)

Pour Si bulk (diamant), κ<sub>xx</sub> ≈ κ<sub>yy</sub> ≈ κ<sub>zz</sub> :

```bash
python3 -c "
import json
d=json.load(open('work/20260803_230151_Si/results/results.json'))
for row in (d.get('kappa') or []):
    if abs(row.get('T',0)-300)<1:
        xx,yy,zz=row.get('kappa_xx'),row.get('kappa_yy'),row.get('kappa_zz')
        print(f'κ_xx={xx} κ_yy={yy} κ_zz={zz}')
        if xx and yy and zz:
            spread=max(xx,yy,zz)/min(xx,yy,zz)-1
            print(f'écart relatif max: {100*spread:.1f} %')
"
```

**Critère :** écart relatif < **10 %** entre composantes diagonales.

**Verdict C4 :** ☐ OK · ☐ Anisotropie significative (à documenter)

---

## Phase D — Tests de robustesse (recommandés)

### D1. Convergence k-mesh (anphon)

Relancer `anphon` rta avec k = **15×15×15** ou **20×20×20** :

| k-mesh | κ_L(300 K) | Δ vs 10×10×10 |
|--------|------------|---------------|
| 10×10×10 | _______ | — |
| 15×15×15 | _______ | _______ % |

**Critère :** variation < **10 %** entre k=10 et k=15 → convergé.

### D2. Comparaison NORDER=1 vs NORDER=2 (phonons)

| NORDER | ω(Γ) cm⁻¹ | Commentaire |
|--------|-----------|-------------|
| 1 | ~519 (job 190045) | Harmonique |
| 2 | _______ | Avec anharmonique |

### D3. Stabilité numérique QE

Vérifier qu'aucun `disp_*.out` ne contient :

```bash
grep -L "JOB DONE" work/20260803_230151_Si/qe/disp_*.out
grep -i "convergence NOT\|error\|abort" work/20260803_230151_Si/qe/disp_*.out | head
```

---

## Phase E — Publication des résultats

### E1. Export final

```bash
# Interface : Résultats → Export → outputs/Si/20260803_230151_Si/
# Ou :
curl -X POST http://127.0.0.1:5020/api/jobs/20260803_230151_Si/publish \
  -H "Content-Type: application/json" -d '{"material":"Si"}'
```

### E2. Fichiers à archiver

| Fichier | Contenu |
|---------|---------|
| `fiche_technique.html` | Rapport complet |
| `results.json` | Toutes les grandeurs |
| `*.bands` | Dispersion phonons |
| `*.kl` | κ<sub>L</sub>(T) |
| `*.xml`, `*.fcs` | IFC ALAMODE |
| `DFSET` | Forces regroupées |
| `reference_scf.in` | Input QE de réfénce |

### E3. Tableau récapitulatif pour publication

Remplir après validation :

| Grandeur | Valeur | Unité | Méthode |
|----------|--------|-------|---------|
| Matériau | Si (diamant) | — | — |
| Supercellule | 3×3×3 | — | ALAMODE |
| ecutwfc | 60 | Ry | QE |
| K_POINTS | 8×8×8 | — | QE |
| NORDER | 2 | — | alm |
| ω(Γ) LO | _______ | cm⁻¹ | anphon |
| κ_L(300 K) | _______ | W/m/K | anphon RTA |
| Erreur fit alm | _______ | % | alm |

---

## Phase F — Dépannage

| Problème | Cause probable | Solution |
|----------|----------------|----------|
| anphon rta échoue | NORDER=1 seulement | Relancer alm NORDER=2 |
| κ_L trop élevée (>300) | Supercellule trop petite / k-mesh grossier | 3×3×3 + k≥15 |
| κ_L trop faible (<50) | Forces mal convergées | conv_thr=1d-10, revoir QE |
| Modes imaginaires | Structure non relaxée / mauvais fit | VC-RELAX + revoir alm |
| Calcul QE interrompu | RAM / timeout | `resume_job.sh` + `watch_job.sh` |
| Fermi / smearing warnings | Si semi-conducteur | degauss=0.01 ou fixed occupations |

---

## Calendrier indicatif

| Étape | Durée estimée | Statut |
|-------|---------------|--------|
| Fin calculs QE (12×) | 12–36 h | ⏳ En cours |
| DFSET + alm NORDER=2 | ~10 min | ☐ |
| anphon phonons | ~3 min | ☐ |
| anphon rta | ~10–30 min | ☐ |
| Validation Phase B–C | ~1 h | ☐ |
| Tests robustesse Phase D | ~2–4 h | ☐ |
| Export + archivage | ~15 min | ☐ |

---

## Signatures / validation

| Rôle | Nom | Date | Signature |
|------|-----|------|-----------|
| Développeur | S. Hiadsi | _______ | _______ |
| Validateur | _______ | _______ | _______ |

---

## Références utiles

1. T. Tadano et al., ALAMODE documentation : https://alamode.readthedocs.io/
2. Tutoriel Si ALAMODE (2×2×2) : https://alamode.readthedocs.io/en/latest/tutorial_pages/silicon.html
3. Slack & Anderson, Phys. Rev. B **65**, 035403 (2001) — κ<sub>L</sub> Si exp./calc.
4. Rapport interne : `RAPPORT_EXPERTISE.md`
5. Rapport vérification : `RAPPORT_VERIFICATION.md`

---

*Plan établi le 4 août 2026 — QE–ALAMODE · LMESM / USTO-MB · S. Hiadsi · said.hiadsi@univ-usto.dz*

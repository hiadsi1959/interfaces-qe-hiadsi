#!/usr/bin/env bash
# Configure les chemins QE / ALAMODE pour ce PC
# (Pour une installation complète sur un nouveau PC, préférer ./INSTALLER_AUTRE_PC.sh)
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ENVF="$HERE/config_local.sh"

QE_DEFAULT="${HOME}/q-e-qe-7.5/bin"
AL_DEFAULT="${HERE}/bin"
PYTHON_BIN="python3"
if [[ -x "$HERE/.venv/bin/python" ]]; then
  PYTHON_BIN="$HERE/.venv/bin/python"
elif [[ -f "$ENVF" ]]; then
  # shellcheck disable=SC1091
  source "$ENVF"
  PYTHON_BIN="${QEALAMODE_PYTHON:-$PYTHON_BIN}"
fi

echo ""
echo "  Configuration QE–ALAMODE"
echo "  (installation complète : ./INSTALLER_AUTRE_PC.sh)"
echo ""
read -r -p "  Dossier bin QE [${QE_DEFAULT}] : " QE_BIN
QE_BIN="${QE_BIN:-$QE_DEFAULT}"
read -r -p "  Dossier bin ALAMODE [${AL_DEFAULT}] : " AL_BIN
AL_BIN="${AL_BIN:-$AL_DEFAULT}"
read -r -p "  Dossier pseudos [${HERE}/pseudos] : " PSEUDO
PSEUDO="${PSEUDO:-$HERE/pseudos}"
read -r -p "  Port interface [5020] : " PORT_IN
PORT_IN="${PORT_IN:-5020}"

mkdir -p "$PSEUDO"

cat >"$ENVF" <<EOF
# Généré par CONFIGURER.sh — $(date '+%Y-%m-%d %H:%M:%S')
export QE_BIN_DIR="$QE_BIN"
export ALAMODE_BIN_DIR="$AL_BIN"
export PSEUDO_DIR="$PSEUDO"
export QEALAMODE_PORT="$PORT_IN"
export QEALAMODE_PYTHON="$PYTHON_BIN"
export OMP_NUM_THREADS="\${OMP_NUM_THREADS:-2}"
export QE_NPROC="\${QE_NPROC:-2}"
EOF

echo ""
echo "  Écrit : $ENVF"
echo "  Test  :"
echo "    source $ENVF"
echo "    ls \$QE_BIN_DIR/pw.x"
echo "    ls \$ALAMODE_BIN_DIR/alm \$ALAMODE_BIN_DIR/anphon"
echo ""

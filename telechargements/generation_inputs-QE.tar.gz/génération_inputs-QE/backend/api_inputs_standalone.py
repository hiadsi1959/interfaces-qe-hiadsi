"""
api_inputs_standalone.py — serveur Flask autonome pour génération_inputs-QE.

Aucune dépendance à Interface-QE_v1 ni à thermo_pw.

Endpoints principaux :
  GET  /                         → sert index.html
  GET  /<asset>                  → sert tout asset (logo, JS, CSS) du dossier projet
  GET  /api/health               → ping
  GET  /api/version              → build_tag + pid + source_mtime
  POST /api/cif/analyze          → JSON { cif_text, cell_type? primitive? } …
  POST /api/inputs/build         → JSON { analysis, calculation, ecutwfc, … } → { text }
  POST /api/inputs/save          → JSON { material, calculation_label, text }
                                   sauve dans inputs_générés/<material>/<calc_label>/pw.in
  GET  /api/inputs/list          → liste des fichiers sauvegardés
  POST /api/files/read           → { path } → { content }
  POST /api/files/write          → { path, content } → sauvegarde dans zone autorisée
  POST /api/files/list_dir       → { directory } → liste fichiers (projet + outputs_root)
"""
from __future__ import annotations

import datetime as _dt
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory, abort

from cif_to_qe import (
    analyze_cif,
    analysis_from_workflow_dict,
    apply_afm_perovskite_bsite_split,
    apply_afm_species_split,
    build_pw_input,
    should_use_perovskite_bsite_split,
    _chem_base_symbol,
    ATOMIC_MASSES,
    CifAnalysis,
    get_convergence_profile,
    detect_material_class,
    get_profile_for_formula,
    profile_to_dict,
    get_all_material_classes,
    CONVERGENCE_PROFILES,
    MaterialClass,
    ConvergenceProfile,
)
from qe_input_types_catalog import (
    load_catalog,
    catalog_summary,
    is_valid_pw_calculation,
    is_aux_input_type,
    normalize_pw_calculation,
    normalize_input_type,
    list_packages,
    ALL_INPUT_TYPES,
    PW_CALC_TYPES,
)
from qe75_verifier import verify_qe75
from qe_input_builders import build_aux_input, BUILDERS


# Configuration ---------------------------------------------------------------
_STANDALONE_ROOT = Path(__file__).resolve().parent.parent  # = .../génération_inputs-QE/
_BACKEND_DIR = Path(__file__).resolve().parent


def _read_config_pc_env() -> dict[str, str]:
    """Lit config_pc.env (généré par CONFIGURER.sh) sans exécuter de shell."""
    out: dict[str, str] = {}
    env_path = _STANDALONE_ROOT / "config_pc.env"
    if not env_path.is_file():
        return out
    for raw in env_path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].strip()
        if "=" not in line:
            continue
        key, _, val = line.partition("=")
        key = key.strip()
        val = val.strip().strip('"').strip("'")
        if key:
            out[key] = val
    return out


_PC_ENV = _read_config_pc_env()


def _analyze_primitive_flags(extra: dict | None) -> bool:
    """True = maille primitive à l'analyse, False = maille conventionnelle standard.

    Clés reconnues dans le JSON (et champs de formulaire multipart) :
      - primitive : bool
      - cell_type : « primitive » | « conventional » / « conventionnelle »
    Par défaut (aligné sur l'UI CIF « conventionnelle ») : conventionnelle si rien n'est précisé.
    """
    opts = extra or {}
    pv = opts.get("primitive")
    if isinstance(pv, bool):
        return pv
    if isinstance(pv, str) and pv.strip():
        s = pv.strip().lower()
        if s in ("true", "1", "yes", "y"):
            return True
        if s in ("false", "0", "no", "n"):
            return False
    ct = str(opts.get("cell_type") or "").strip().lower()
    if ct in ("primitive", "primitif", "prim"):
        return True
    if ct in ("conventional", "conventionnelle", "conventionnel", "std"):
        return False
    # Pas de indication explicite : même défaut que le menu déroulant CIF du frontend
    return False


def _parse_supercell_matrix(extra: dict | None):
    """Matrice 3×3 entière ou diagonale [na, nb, nc] pour supercell magnétique."""
    opts = extra or {}
    raw = opts.get("supercell_matrix")
    if raw is None:
        raw = opts.get("supercell_diag")
    if raw is None:
        return None
    if isinstance(raw, (list, tuple)) and len(raw) == 3:
        if all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in raw):
            a, b, c = (int(raw[0]), int(raw[1]), int(raw[2]))
            return [[a, 0, 0], [0, b, 0], [0, 0, c]]
        if len(raw) == 3 and all(isinstance(row, (list, tuple)) and len(row) == 3 for row in raw):
            return [[int(row[0]), int(row[1]), int(row[2])] for row in raw]
    return None


_INPUTS_DIRECT = _STANDALONE_ROOT / "inputs_générés_direct"
_INPUTS_CIF = _STANDALONE_ROOT / "inputs_convertis_cif"
# Rétrocompat (anciens chemins / messages)
_INPUTS_OUT = _INPUTS_DIRECT
_FALLBACK_HOME = Path.home() / ".gen_inputs_qe"

API_BUILD_TAG = "2026-05-19+sauvegarder-fichier-compat"
PORT = int(os.environ.get("GEN_INPUTS_PORT", "5012"))
HOST = os.environ.get("GEN_INPUTS_HOST", "127.0.0.1")


def _writable(p: Path) -> bool:
    """Vérifie si un répertoire est accessible en écriture (test de création de fichier)."""
    try:
        p.mkdir(parents=True, exist_ok=True)
        test = p / ".write_test"
        test.write_text("ok", encoding="utf-8")
        test.unlink(missing_ok=True)
        return True
    except Exception:
        return False


def _outputs_root_for(source: str = "direct") -> Path:
    """Répertoire writable pour la voie directe ou CIF."""
    src = (source or "direct").strip().lower()
    if src in ("cif", "convertis", "convertis_cif", "inputs_convertis_cif"):
        candidates = (
            _INPUTS_CIF,
            _FALLBACK_HOME / "inputs_convertis_cif",
            Path(tempfile.gettempdir()) / "gen_inputs_qe_cif",
        )
    else:
        candidates = (
            _INPUTS_DIRECT,
            _FALLBACK_HOME / "inputs_générés_direct",
            _FALLBACK_HOME / "inputs_générés",
            Path(tempfile.gettempdir()) / "gen_inputs_qe_direct",
        )
    for candidate in candidates:
        if _writable(candidate):
            return candidate
    return Path(tempfile.gettempdir()) / "gen_inputs_qe"


def _outputs_root() -> Path:
    """Voie directe (rétrocompat API)."""
    return _outputs_root_for("direct")


def _structure_xsf_dir() -> Path:
    d = _STANDALONE_ROOT / "tmp_structures"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _save_structure_xsf(nom: str, contenu: str) -> tuple[Path | None, str | None]:
    nom_safe = re.sub(r"[^\w.\-]+", "_", str(nom or "structure.xsf").strip()) or "structure.xsf"
    if not nom_safe.lower().endswith(".xsf"):
        nom_safe += ".xsf"
    dest = _structure_xsf_dir() / nom_safe
    try:
        dest.write_text(contenu, encoding="utf-8")
        return dest, None
    except OSError as e:
        return None, str(e)


def _find_structure_viewer(viewer: str) -> str | None:
    v = (viewer or "xcrysden").strip().lower()
    if v in ("xcrysden", "xcd"):
        return shutil.which("xcrysden") or ("/usr/bin/xcrysden" if Path("/usr/bin/xcrysden").is_file() else None)
    if v in ("vesta",):
        for cmd in ("vesta", "VESTA"):
            found = shutil.which(cmd)
            if found:
                return found
        for candidate in (
            Path.home() / "VESTA-gtk3" / "VESTA",
            Path.home() / "VESTA" / "VESTA",
            Path("/opt/VESTA/VESTA"),
            Path("/usr/local/bin/VESTA"),
        ):
            if candidate.is_file():
                return str(candidate)
    return None


def _launch_structure_viewer(exe: str, viewer: str, chemin: str) -> None:
    v = (viewer or "xcrysden").strip().lower()
    env = os.environ.copy()
    if v in ("xcrysden", "xcd"):
        subprocess.Popen(
            [exe, "--xsf", chemin],
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=env,
        )
        return
    subprocess.Popen(
        [exe, chemin],
        start_new_session=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        env=env,
    )


def _all_outputs_roots() -> list[Path]:
    """Les deux zones de sauvegarde d'inputs générés."""
    roots: list[Path] = []
    for src in ("direct", "cif"):
        p = _outputs_root_for(src)
        if p not in roots:
            roots.append(p)
    return roots


def _cif_dir() -> Path:
    """Répertoire CIF du paquet portable (sous la racine projet)."""
    d = _STANDALONE_ROOT / "data"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return d


def _project_root() -> Path:
    return _STANDALONE_ROOT.resolve()


def _safe_name(name: str, default: str = "x") -> str:
    """
    Nettoie une chaîne pour l'utiliser comme nom de fichier/dossier.
    Remplace les caractères non autorisés par des underscores.
    """
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", (name or "").strip())
    return s or default


# Flask app -------------------------------------------------------------------
app = Flask(__name__, static_folder=None)

# CORS explicite (évite doublons flask-cors + garantit preflight OPTIONS partout).
# Requis si l’UI est sur un autre port/origine (ex. localhost:5007 → API :5012).
@app.after_request
def _cors_all_responses(resp):
    origin = request.headers.get("Origin")
    if origin:
        resp.headers["Access-Control-Allow-Origin"] = origin
        resp.headers["Vary"] = "Origin"
    else:
        resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Headers"] = (
        "Content-Type, Authorization, X-Requested-With, Accept, Origin, Prefer"
    )
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS, HEAD"
    resp.headers["Access-Control-Max-Age"] = "86400"
    # Chromium / requêtes vers réseau « privé » (localhost)
    resp.headers["Access-Control-Allow-Private-Network"] = "true"
    return resp


@app.route("/api/health", methods=["GET"])
def api_health():
    return jsonify({"ok": True, "service": "gen_inputs_qe_standalone", "port": PORT})


@app.route("/api/version", methods=["GET"])
def api_version():
    src = Path(__file__)
    try:
        mtime = _dt.datetime.fromtimestamp(src.stat().st_mtime).isoformat()
    except Exception:
        mtime = None
    return jsonify({
        "build_tag": API_BUILD_TAG,
        "pid": os.getpid(),
        "python": sys.version.split()[0],
        "source_file": str(src),
        "source_mtime": mtime,
        "outputs_root": str(_outputs_root()),
        "outputs_root_direct": str(_outputs_root_for("direct")),
        "outputs_root_cif": str(_outputs_root_for("cif")),
        "port": PORT,
    })


@app.route("/api/dft/catalog", methods=["GET"])
def api_dft_catalog():
    """Catalogue input_dft QE (qe_dft_list + funct.f90 vdW/BEEF)."""
    from qe_input_dft_catalog import load_catalog

    try:
        return jsonify({"ok": True, "catalog": load_catalog()})
    except FileNotFoundError as e:
        return jsonify({"ok": False, "error": str(e)}), 503


# ── Endpoint de recommandation de convergence ──
@app.route("/api/convergence/recommend", methods=["POST", "OPTIONS"])
def api_convergence_recommend():
    """
    Recommande les paramètres de convergence optimaux pour un matériau.

    Requête JSON :
      - formula (str) : Formule chimique (ex. "GdVO3", "Fe2O3")
      - atomic_species (list[str]) : Liste des espèces atomiques (ex. ["Gd", "V", "O"])
      - calculation (str) : Type de calcul ("scf", "relax", "vc-relax", "nscf", "bands", "md")

    Retourne le profil de convergence optimal avec la classe de matériau détectée.
    """
    if request.method == "OPTIONS":
        return ("", 204)
    data = request.get_json(silent=True) or {}
    formula = str(data.get("formula") or "").strip()
    atomic_species = data.get("atomic_species") or []
    calculation = str(data.get("calculation", "scf")).strip().lower()

    if not formula and not atomic_species:
        return jsonify({
            "ok": False,
            "error": "Fournissez 'formula' ou 'atomic_species' pour la détection."
        }), 400

    try:
        mc = detect_material_class(formula, list(atomic_species))
        profile = get_convergence_profile(mc.value, calculation)
        profile_json = profile_to_dict(profile)
        profile_json["material_class_name"] = _MATERIAL_CLASS_NAMES.get(mc.value, "Inconnu")
        profile_json["material_class_description"] = _MATERIAL_CLASS_DESCRIPTIONS.get(mc.value, "")
        return jsonify({
            "ok": True,
            "detected_class": mc.value,
            "class_name": profile_json["material_class_name"],
            "class_description": profile_json["material_class_description"],
            "profile": profile_json,
        })
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 422


@app.route("/api/convergence/classes", methods=["GET"])
def api_convergence_classes():
    """Retourne la liste de toutes les classes de matériaux et leurs profils."""
    classes = get_all_material_classes()
    calc_types = ["scf", "relax", "vc-relax", "nscf", "bands", "md", "vc-md"]
    result = []
    for cls in classes:
        cls_id = cls["id"]
        profiles = {}
        for ct in calc_types:
            try:
                prof = get_convergence_profile(cls_id, ct)
                d = profile_to_dict(prof)
                d.pop("material_class", None)
                d.pop("calculation_type", None)
                profiles[ct] = d
            except Exception:
                profiles[ct] = None
        result.append({
            "id": cls_id,
            "name": cls["name"],
            "description": cls["description"],
            "profiles": profiles,
        })
    return jsonify({"ok": True, "classes": result})


_MATERIAL_CLASS_NAMES = {
    "metal": "Métal",
    "insulator": "Isolant",
    "semiconductor": "Semi-conducteur",
    "mag_metal": "Métal magnétique",
    "mag_insulator": "Isolant magnétique",
    "rare_earth": "Terre rare",
    "organic": "Organique",
    "unknown": "Non déterminé",
}

_MATERIAL_CLASS_DESCRIPTIONS = {
    "metal": "Bon conducteur (Cu, Al, Na…) — smearing nécessaire, mixing_beta modéré",
    "insulator": "Gap > 3 eV (MgO, NaCl, BaTiO₃…) — occupations fixed, convergence facile",
    "semiconductor": "Gap 0.5-3 eV (Si, GaAs…) — cold smearing, paramètres standards",
    "mag_metal": "Métal ferromagnétique (Fe, Co, Ni…) — mixing_beta bas, conv_thr strict",
    "mag_insulator": "Oxyde magnétique (NiO, Fe₂O₃, LaVO₃…) — mixing_beta ~0.3, Hubbard U",
    "rare_earth": "Terre rare / f-electron (Gd, Dy, Ce…) — mixing_beta très bas ~0.15-0.25, Hubbard U",
    "organic": "Cristal moléculaire / polymère — grille k clairsemée, occupations fixed",
    "unknown": "Matériau non reconnu — paramètres prudents par défaut",
}


# CIF → analyse --------------------------------------------------------------
@app.route("/api/cif/analyze", methods=["POST", "OPTIONS"])
def api_cif_analyze():
    if request.method == "OPTIONS":
        return ("", 204)

    data = request.get_json(silent=True) or {}

    cif_text = None

    if request.files:
        f = request.files.get("file") or next(iter(request.files.values()), None)
        if f is not None:
            try:
                cif_text = f.read().decode("utf-8", errors="replace")
            except Exception as e:
                return jsonify({"error": f"lecture du fichier impossible : {e}"}), 400

    if cif_text is None:
        cif_text = data.get("cif_text") or data.get("cif") or data.get("text")

    if not cif_text or not cif_text.strip():
        return jsonify({"error": "aucun contenu CIF fourni (champ 'cif_text' JSON ou fichier 'file')."}), 400

    analyze_opts = dict(data)
    try:
        if request.form:
            for _k in ("cell_type", "primitive"):
                if _k in request.form and request.form.get(_k) not in (None, ""):
                    analyze_opts[_k] = request.form.get(_k)
    except Exception:
        pass

    primitive = _analyze_primitive_flags(analyze_opts)
    supercell_matrix = _parse_supercell_matrix(analyze_opts)
    afm_type = str(analyze_opts.get("afm_type") or analyze_opts.get("ordre_mag") or "").strip() or None
    afm_split_raw = analyze_opts.get("afm_split_sublattices")
    if afm_split_raw is None:
        afm_split = bool(
            afm_type and str(afm_type).lower().startswith("afm")
        )
    else:
        afm_split = bool(afm_split_raw)

    with tempfile.NamedTemporaryFile("w", suffix=".cif", delete=False, encoding="utf-8") as tf:
        tf.write(cif_text)
        tmp_path = tf.name
    try:
        analysis = analyze_cif(
            tmp_path,
            primitive=primitive,
            supercell_matrix=supercell_matrix,
            afm_type=afm_type,
            afm_split_sublattices=afm_split,
        )
    except Exception as e:
        return jsonify({"error": f"analyse CIF échouée : {e}"}), 422
    finally:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass

    return jsonify({
        "ok": True,
        "primitive_requested": primitive,
        "supercell_applied": supercell_matrix is not None,
        "afm_split_applied": bool(
            afm_type
            and any(
                "AFM split" in n or "RVO₃ AFM split" in n
                for n in (analysis.notes or [])
            )
        ),
        "afm_type": afm_type,
        "analysis": analysis.to_dict(),
    })


# Construction d'input -------------------------------------------------------
def _analysis_from_dict(d: dict) -> CifAnalysis:
    """
    Reconstruit un objet CifAnalysis à partir du dictionnaire JSON
    renvoyé par l'endpoint /api/cif/analyze.

    Cette fonction inverse la sérialisation to_dict() de CifAnalysis,
    permettant de passer l'analyse CIF au constructeur d'input sans
    avoir à ré-analyser le fichier.
    """
    celldm_raw = d.get("celldm") or {}
    celldm = {}
    for k, v in celldm_raw.items():
        try:
            celldm[int(k)] = float(v)
        except Exception:
            continue
    positions = []
    for site in (d.get("atomic_positions_crystal") or []):
        positions.append((str(site.get("symbol", "X")),
                          float(site.get("x", 0.0)),
                          float(site.get("y", 0.0)),
                          float(site.get("z", 0.0))))
    cell_a = []
    for row in (d.get("cell_parameters_angstrom") or []):
        if isinstance(row, (list, tuple)) and len(row) == 3:
            cell_a.append(tuple(float(x) for x in row))
    species = []
    for s in (d.get("atomic_species") or []):
        if isinstance(s, dict):
            sym = str(s.get("symbol") or s.get("label") or s.get("name") or "").strip()
            if sym and sym not in species:
                species.append(sym)
        else:
            sym = str(s).strip()
            if sym and not sym.startswith("{") and sym not in species:
                species.append(sym)
    return CifAnalysis(
        formula=str(d.get("formula", "material")),
        formula_cell=str(d.get("formula_cell") or d.get("formula") or ""),
        spacegroup_number=int(d.get("spacegroup_number", 0)),
        spacegroup_symbol=str(d.get("spacegroup_symbol", "")),
        crystal_system=str(d.get("crystal_system", "unknown")),
        centering=str(d.get("centering", "P")),
        ibrav=int(d.get("ibrav", 0)),
        a=float(d.get("a", 0.0)),
        b=float(d.get("b", 0.0)),
        c=float(d.get("c", 0.0)),
        alpha_deg=float(d.get("alpha_deg", 90.0)),
        beta_deg=float(d.get("beta_deg", 90.0)),
        gamma_deg=float(d.get("gamma_deg", 90.0)),
        celldm=celldm,
        nat=int(d.get("nat", len(positions))),
        ntyp=int(d.get("ntyp", len(species))),
        atomic_species=species,
        atomic_positions_crystal=positions,
        cell_parameters_angstrom=cell_a,
        backend=str(d.get("backend", "")),
        notes=list(d.get("notes") or []),
        formula_units_z=int(d.get("formula_units_z") or 1),
    )


@app.route("/api/inputs/build", methods=["POST", "OPTIONS"])
def api_inputs_build():
    if request.method == "OPTIONS":
        return ("", 204)
    data = request.get_json(silent=True) or {}
    analysis_dict = data.get("analysis")
    workflow_dict = data.get("workflow")
    if workflow_dict and not analysis_dict:
        try:
            cif = analysis_from_workflow_dict(workflow_dict)
        except Exception as e:
            return jsonify({"error": f"workflow invalide : {e}"}), 400
    elif analysis_dict:
        try:
            cif = _analysis_from_dict(analysis_dict)
        except Exception as e:
            return jsonify({"error": f"analyse invalide : {e}"}), 400
    else:
        return jsonify({
            "error": "champ 'analysis' ou 'workflow' manquant.",
            "hint": "analysis = sortie /api/cif/analyze ; workflow = champs Tab 1 direct.",
        }), 400

    kp = data.get("k_points") or [8, 8, 8]
    try:
        k_points = (int(kp[0]), int(kp[1]), int(kp[2]))
    except Exception:
        k_points = (8, 8, 8)

    # Pseudos : niveau racine, sinon workflow.pseudos, sinon extraits de atomic_species[{pseudo}]
    pseudos = data.get("pseudos") or None
    if not isinstance(pseudos, dict) or not pseudos:
        wf_src = workflow_dict if isinstance(workflow_dict, dict) else {}
        pseudos = wf_src.get("pseudos") if isinstance(wf_src.get("pseudos"), dict) else None
    if not isinstance(pseudos, dict) or not pseudos:
        extracted: dict[str, str] = {}
        src_species = []
        if isinstance(workflow_dict, dict):
            src_species = workflow_dict.get("atomic_species") or []
        elif isinstance(analysis_dict, dict):
            src_species = analysis_dict.get("atomic_species") or []
        for item in src_species:
            if isinstance(item, dict):
                sym = str(item.get("symbol") or item.get("label") or "").strip()
                upf = str(item.get("pseudo") or item.get("upf") or "").strip()
                if sym and upf:
                    extracted[sym] = upf
        pseudos = extracted or None

    # DFT+U (optionnel) : nettoyage cote serveur, on accepte {sym: U_eV}
    def _coerce_uj(d):
        """
        Nettoie un dictionnaire {espèce: valeur_U/JeV} : supprime les zéros
        et les valeurs non numériques. Retourne None si vide.
        """
        if not isinstance(d, dict):
            return None
        out = {}
        for k, v in d.items():
            try:
                vf = float(v)
            except (TypeError, ValueError):
                continue
            if vf == 0.0:
                continue
            out[str(k)] = vf
        return out or None

    hubbard_u_in = _coerce_uj(data.get("hubbard_u"))
    hubbard_j0_in = _coerce_uj(data.get("hubbard_j0"))
    hubbard_syntax = str(data.get("hubbard_syntax", "card")).strip().lower() or "card"
    if hubbard_syntax not in ("legacy", "card"):
        hubbard_syntax = "card"
    hubbard_legacy_verbose = bool(data.get("hubbard_legacy_verbose", False))
    try:
        hubbard_kind = int(data.get("hubbard_kind", 0))
    except (TypeError, ValueError):
        hubbard_kind = 0
    hubbard_projection = str(data.get("hubbard_projection", "ortho-atomic")).strip() or "ortho-atomic"
    hubbard_manifold = str(data.get("hubbard_manifold", "3d")).strip() or "3d"
    hubbard_manifolds_in = data.get("hubbard_manifolds")
    hubbard_manifolds: dict[str, str] | None = None
    if isinstance(hubbard_manifolds_in, dict):
        hubbard_manifolds = {
            str(k): str(v).strip()
            for k, v in hubbard_manifolds_in.items()
            if str(k).strip() and str(v).strip()
        } or None
    hubbard_auto_spin = bool(data.get("hubbard_auto_spin", False))
    try:
        hubbard_starting_mag = float(data.get("hubbard_starting_magnetization", 0.45))
    except (TypeError, ValueError):
        hubbard_starting_mag = 0.45
    ibrav_override_arg: int | None = None
    _ibrav_ov_raw = data.get("ibrav_override")
    if _ibrav_ov_raw is not None and str(_ibrav_ov_raw).strip() != "":
        try:
            _iv = int(_ibrav_ov_raw)
            if _iv == 0:
                pass  # utilisez force_ibrav_zero pour CELL_PARAMETERS explicites
            elif 1 <= _iv <= 14 or _iv == 91:
                ibrav_override_arg = _iv
        except (TypeError, ValueError):
            pass
    input_dft_raw = data.get("input_dft")
    if input_dft_raw is None or input_dft_raw == "":
        input_dft_arg = None
    else:
        input_dft_arg = str(input_dft_raw).strip()

    afm_type = str(data.get("afm_type") or data.get("ordre_mag") or "").strip() or None
    if afm_type and afm_type.lower().startswith("afm"):
        if should_use_perovskite_bsite_split(cif, afm_type):
            cif = apply_afm_perovskite_bsite_split(cif, afm_type)
        else:
            cif = apply_afm_species_split(cif, afm_type)

    if hubbard_u_in:
        expanded_u = dict(hubbard_u_in)
        for sym in cif.atomic_species:
            if sym not in expanded_u:
                base = _chem_base_symbol(sym)
                if base in expanded_u:
                    expanded_u[sym] = expanded_u[base]
        hubbard_u_in = expanded_u

    # ── Paramètres magnétisme (QE 7.5+) ──
    nspin_arg = data.get("nspin")
    if nspin_arg is not None:
        try:
            nspin_arg = int(nspin_arg)
            if nspin_arg not in (1, 2, 4):
                nspin_arg = None
        except (TypeError, ValueError):
            nspin_arg = None
    noncolin_arg = data.get("noncolin")
    if noncolin_arg is not None:
        noncolin_arg = bool(noncolin_arg)
    lspinorb_arg = data.get("lspinorb")
    if lspinorb_arg is not None:
        lspinorb_arg = bool(lspinorb_arg)
    starting_mag_arg = data.get("starting_magnetization")
    if isinstance(starting_mag_arg, dict):
        starting_mag_arg = {
            str(k): float(v) for k, v in starting_mag_arg.items()
            if str(k).strip()
        }
    else:
        starting_mag_arg = None
    # ── Angles non colinéaires nc+soc (angle1/angle2) ──
    angle1_arg = data.get("angle1")
    if isinstance(angle1_arg, dict):
        angle1_arg = {str(k): float(v) for k, v in angle1_arg.items() if str(k).strip()}
    else:
        angle1_arg = None
    angle2_arg = data.get("angle2")
    if isinstance(angle2_arg, dict):
        angle2_arg = {str(k): float(v) for k, v in angle2_arg.items() if str(k).strip()}
    else:
        angle2_arg = None
    afm_type_arg = str(data.get("afm_type") or "").strip() or None

    try:
        calc_norm = normalize_input_type(str(data.get("calculation", "scf")))
        lberry_arg = bool(data.get("lberry"))
        lelfield_arg = bool(data.get("lelfield"))
        if calc_norm == "scf_berry":
            lberry_arg = True
            lelfield_arg = False
        nppstr_arg = int(data.get("nppstr") or data.get("nberrycyc") or 8)
        conv_thr_arg = (
            str(data["conv_thr"]).strip() if data.get("conv_thr") not in (None, "") else None
        )
        if calc_norm == "scf_born" and conv_thr_arg is None:
            conv_thr_arg = "1.0d-12"
        if is_aux_input_type(calc_norm):
            prefix = str(data.get("prefix") or cif.formula or "material")
            outdir = str(data.get("outdir", "./out"))
            aux_skip = {
                "calculation", "workflow", "analysis", "prefix", "outdir",
                "pseudo_dir", "k_points", "pseudos", "force_ibrav_zero",
                "ibrav_override", "material",
            }
            aux_kw = {
                k: v for k, v in data.items()
                if k not in aux_skip and v is not None
            }
            text = build_aux_input(calc_norm, prefix=prefix, outdir=outdir, **aux_kw)
            vres = verify_qe75(text, package=calc_norm, strict=False)
            return jsonify({
                "ok": True,
                "text": text,
                "calculation": calc_norm,
                "package": calc_norm,
                "verify": vres.to_dict(),
            })
        text = build_pw_input(
            cif,
            calculation=calc_norm,
            prefix=data.get("prefix"),
            pseudo_dir=str(data.get("pseudo_dir", "./pseudos")),
            outdir=str(data.get("outdir", "./out")),
            ecutwfc=float(data.get("ecutwfc", 60.0)),
            ecutrho=float(data.get("ecutrho", 480.0)),
            k_points=k_points,
            pseudos=pseudos,
            occupations=str(data.get("occupations", "smearing")),
            smearing=str(data.get("smearing", "marzari-vanderbilt")),
            degauss=float(data.get("degauss", 0.01)),
            force_ibrav_zero=bool(data.get("force_ibrav_zero", False)),
            ibrav_override=ibrav_override_arg,
            hubbard_u=hubbard_u_in,
            hubbard_j0=hubbard_j0_in,
            hubbard_syntax=hubbard_syntax,
            hubbard_legacy_verbose=hubbard_legacy_verbose,
            hubbard_kind=hubbard_kind,
            hubbard_projection=hubbard_projection,
            hubbard_manifold=hubbard_manifold,
            hubbard_manifolds=hubbard_manifolds,
            input_dft=input_dft_arg,
            # Magnétisme : nouveaux paramètres QE 7.5+
            nspin=nspin_arg,
            noncolin=noncolin_arg,
            lspinorb=lspinorb_arg,
            starting_magnetization=starting_mag_arg,
            # Angles non colinéaires nc+soc
            angle1=angle1_arg,
            angle2=angle2_arg,
            afm_type=afm_type_arg,
            # Rétrocompatibilité
            hubbard_auto_spin=hubbard_auto_spin,
            hubbard_starting_magnetization=hubbard_starting_mag,
            ion_dynamics=str(data.get("ion_dynamics", "bfgs")),
            cell_dynamics=str(data.get("cell_dynamics", "bfgs")),
            press=float(data.get("press", 0.0)),
            forc_conv_thr=float(data.get("forc_conv_thr", 1.0e-4)),
            mixing_beta=(float(data["mixing_beta"]) if data.get("mixing_beta") not in (None, "") else None),
            press_conv_thr=(float(data["press_conv_thr"]) if data.get("press_conv_thr") not in (None, "") else None),
            conv_thr=conv_thr_arg,
            lberry=lberry_arg,
            lelfield=lelfield_arg,
            nppstr=nppstr_arg,
            nberrycyc=nppstr_arg,
            gdir=int(data.get("gdir") or 3),
        )
    except Exception as e:
        return jsonify({"error": f"construction input échouée : {e}"}), 422

    vres = verify_qe75(text, package="pw", strict=False, for_save=True)
    return jsonify({"ok": True, "text": text, "calculation": calc_norm, "verify": vres.to_dict()})


@app.route("/api/qe/catalog", methods=["GET"])
def api_qe_catalog():
    cat = load_catalog()
    return jsonify({
        "ok": True,
        "summary": catalog_summary(),
        "packages": list_packages(),
        "pw_calculation_types": sorted(PW_CALC_TYPES),
        "all_input_types": sorted(ALL_INPUT_TYPES),
    })


@app.route("/api/qe/verify", methods=["POST", "OPTIONS"])
def api_qe_verify():
    if request.method == "OPTIONS":
        return ("", 204)
    data = request.get_json(silent=True) or {}
    text = data.get("text") or data.get("content") or ""
    if not str(text).strip():
        return jsonify({"error": "champ 'text' manquant"}), 400
    pkg = str(data.get("package") or "pw").strip().lower()
    strict = bool(data.get("strict"))
    res = verify_qe75(text, package=pkg, strict=strict, for_save=not strict)
    return jsonify({"ok": res.ok, **res.to_dict()})


@app.route("/api/qe/build_aux", methods=["POST", "OPTIONS"])
def api_qe_build_aux():
    if request.method == "OPTIONS":
        return ("", 204)
    data = request.get_json(silent=True) or {}
    pkg = str(data.get("package") or data.get("id") or "").strip().lower()
    if not pkg:
        return jsonify({"error": "champ 'package' manquant"}), 400
    if pkg not in BUILDERS:
        return jsonify({
            "error": f"package '{pkg}' sans générateur template",
            "available": sorted(BUILDERS.keys()),
        }), 400
    opts = {k: v for k, v in data.items() if k not in ("package", "id")}
    try:
        text = build_aux_input(pkg, **opts)
    except TypeError as e:
        return jsonify({"error": f"paramètres invalides : {e}"}), 400
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    vres = verify_qe75(text, package=pkg, strict=False)
    return jsonify({"ok": True, "package": pkg, "text": text, "verify": vres.to_dict()})


# Sauvegarde / listing -------------------------------------------------------
@app.route("/api/inputs/save", methods=["POST", "OPTIONS"])
def api_inputs_save():
    if request.method == "OPTIONS":
        return ("", 204)
    data = request.get_json(silent=True) or {}
    text = data.get("text") or data.get("content")
    if not text:
        return jsonify({"error": "champ 'text' manquant."}), 400

    pkg = str(data.get("package") or "pw").strip().lower()
    strict_verify = bool(data.get("strict_verify") or data.get("strict"))
    verify_res = verify_qe75(text, package=pkg, strict=strict_verify, for_save=not strict_verify)
    if strict_verify and not verify_res.ok:
        return jsonify({
            "error": "input non conforme QE 7.5+",
            "verify": verify_res.to_dict(),
        }), 422

    material = _safe_name(data.get("material") or "material")
    calc_label = _safe_name(data.get("calculation_label") or data.get("label") or "scf")
    filename = _safe_name(data.get("filename") or "pw.in")

    source = str(data.get("source") or data.get("voie") or "direct").strip().lower()
    layout = str(data.get("layout") or "flat").strip().lower()
    root = _outputs_root_for("cif" if source == "cif" else "direct")
    if not filename.endswith(".in"):
        filename = filename + ".in" if "." not in filename else filename
    if layout == "nested":
        target = root / material / calc_label / filename
    else:
        # flat (défaut UI) : inputs_générés_direct/Mat/Mat_scf.in
        flat_name = filename if filename != "pw.in" else f"{material}_{calc_label}.in"
        target = root / material / flat_name
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
    except OSError as e:
        return jsonify({"error": f"écriture impossible : {e}", "outputs_root": str(_outputs_root())}), 503

    try:
        rel = str(target.relative_to(root))
    except Exception:
        rel = target.name
    return jsonify({
        "ok": True,
        "path": str(target),
        "relative": rel,
        "outputs_root": str(root),
        "material": material,
        "calculation": calc_label,
        "filename": target.name,
        "verify": verify_res.to_dict(),
    })


@app.route("/api/inputs/list", methods=["GET"])
def api_inputs_list():
    items = []
    roots_meta = []
    for src, root in (("direct", _outputs_root_for("direct")), ("cif", _outputs_root_for("cif"))):
        roots_meta.append({"source": src, "path": str(root)})
        if not root.exists():
            continue
        for p in root.rglob("*"):
            if not p.is_file():
                continue
            try:
                rel = p.relative_to(root)
            except Exception:
                rel = p.name
            try:
                size = p.stat().st_size
                mtime = _dt.datetime.fromtimestamp(p.stat().st_mtime).isoformat()
            except Exception:
                size, mtime = 0, None
            items.append({
                "path": str(p),
                "relative": str(rel),
                "source": src,
                "root": str(root),
                "size": size,
                "mtime": mtime,
            })
    items.sort(key=lambda x: (x.get("source", ""), x.get("relative", "")))
    return jsonify({
        "ok": True,
        "outputs_root": str(_outputs_root()),
        "outputs_root_direct": str(_outputs_root_for("direct")),
        "outputs_root_cif": str(_outputs_root_for("cif")),
        "roots": roots_meta,
        "items": items,
    })


@app.route("/api/hubbard/defaults", methods=["GET"])
def api_hubbard_defaults():
    """Valeurs U indicatives depuis data/hubbard_u_defaults.json (éditable localement)."""
    p = _STANDALONE_ROOT / "data" / "hubbard_u_defaults.json"
    if not p.is_file():
        return jsonify({"_missing_file": True, "_path_hint": str(p)})
    try:
        data_js = json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        return jsonify({"error": str(e)}), 422
    return jsonify(data_js)


def _path_under_allowed_roots(p: Path) -> bool:
    """True si p résolu est sous une zone lisible (outputs, projet, data/)."""
    try:
        rp = p.resolve()
    except OSError:
        return False
    allowed = [b.resolve() for b in _all_outputs_roots()]
    allowed.extend([_STANDALONE_ROOT.resolve(), _cif_dir().resolve()])
    for base in allowed:
        try:
            rp.relative_to(base)
            return True
        except ValueError:
            continue
    return False


def _path_under_write_roots(p: Path) -> bool:
    """Écriture autorisée uniquement dans inputs_générés_direct/ ou inputs_convertis_cif/."""
    try:
        rp = p.resolve()
    except OSError:
        return False
    for base in _all_outputs_roots():
        try:
            rp.relative_to(base.resolve())
            return True
        except ValueError:
            continue
    return False


def _list_directory_entries(d: Path) -> list[dict]:
    files_out: list[dict] = []
    for child in sorted(d.iterdir(), key=lambda x: (x.is_dir(), x.name.lower())):
        try:
            st = child.stat()
            files_out.append({
                "name": child.name,
                "path": str(child),
                "type": "directory" if child.is_dir() else "file",
                "size": 0 if child.is_dir() else int(st.st_size),
                "modified": _dt.datetime.fromtimestamp(st.st_mtime).isoformat(),
            })
        except OSError:
            continue
    return files_out


@app.route("/api/files/read", methods=["POST", "OPTIONS"])
def api_files_read():
    if request.method == "OPTIONS":
        return ("", 204)
    data = request.get_json(silent=True) or {}
    path_str = data.get("path") or ""
    if not path_str:
        return jsonify({"error": "champ 'path' manquant."}), 400
    p = Path(path_str).resolve()
    if not _path_under_allowed_roots(p):
        return jsonify({"error": f"chemin hors zone autorisée : {p}"}), 403
    if not p.is_file():
        return jsonify({"error": f"fichier introuvable : {p}"}), 404
    try:
        content = p.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        return jsonify({"error": f"lecture impossible : {e}"}), 500
    return jsonify({"ok": True, "path": str(p), "content": content})


def _write_file_under_roots(path_str: str, raw) -> tuple[Path | None, str | None]:
    """Écrit un fichier sous zone autorisée. Retourne (path, None) ou (None, message_erreur)."""
    if not path_str:
        return None, "chemin de fichier manquant."
    p = Path(path_str).resolve()
    if not _path_under_write_roots(p):
        return None, f"chemin hors zone autorisée : {p}"
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("" if raw is None else str(raw), encoding="utf-8")
    except OSError as e:
        return None, str(e)
    return p, None


@app.route("/api/files/write", methods=["POST", "OPTIONS"])
def api_files_write():
    if request.method == "OPTIONS":
        return ("", 204)
    data = request.get_json(silent=True) or {}
    path_str = data.get("path") or ""
    raw = data.get("content")
    if raw is None:
        raw = data.get("text")
    p, err = _write_file_under_roots(path_str, raw)
    if err:
        code = 400 if "manquant" in err else (403 if "autorisée" in err else 500)
        return jsonify({"error": err}), code
    return jsonify({"ok": True, "success": True, "path": str(p)})


@app.route("/api/sauvegarder_fichier", methods=["POST", "OPTIONS"])
def api_sauvegarder_fichier_compat():
    """Compatibilité UI génération directe (legacy Interface-QE port 5007)."""
    if request.method == "OPTIONS":
        return ("", 204)
    data = request.get_json(silent=True) or {}
    path_str = data.get("fichier") or data.get("path") or ""
    raw = data.get("contenu")
    if raw is None:
        raw = data.get("content") or data.get("text")
    p, err = _write_file_under_roots(path_str, raw)
    if err:
        code = 400 if "manquant" in err else (403 if "autorisée" in err else 500)
        return jsonify({"success": False, "error": err}), code
    sp = str(p)
    return jsonify({
        "ok": True,
        "success": True,
        "path": sp,
        "filepath": sp,
        "fichier": sp,
        "file_path": sp,
    })


@app.route("/api/files/list_dir", methods=["POST", "OPTIONS"])
def api_files_list_dir():
    if request.method == "OPTIONS":
        return ("", 204)
    data = request.get_json(silent=True) or {}
    dir_str = data.get("directory") or data.get("path") or ""
    if not dir_str.strip():
        return jsonify({"error": "champ 'directory' manquant."}), 400
    d = Path(dir_str).resolve()
    if not _path_under_allowed_roots(d):
        return jsonify({"error": "répertoire hors zone autorisée", "hint": str(_cif_dir())}), 403
    if not d.is_dir():
        try:
            if _path_under_allowed_roots(d):
                d.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
    if not d.is_dir():
        return jsonify({"error": f"pas un répertoire : {d}"}), 400
    files_out = []
    try:
        files_out = _list_directory_entries(d)
    except OSError as e:
        return jsonify({"error": str(e)}), 500
    return jsonify({
        "ok": True,
        "status": "success",
        "directory": str(d),
        "files": files_out,
    })


@app.route("/api/structure/save_xsf", methods=["POST", "OPTIONS"])
def api_structure_save_xsf():
    if request.method == "OPTIONS":
        return ("", 204)
    data = request.get_json(silent=True) or {}
    contenu = data.get("contenu") or data.get("content") or data.get("text") or ""
    nom = str(data.get("nom") or data.get("filename") or "structure.xsf").strip()
    if not contenu.strip():
        return jsonify({"ok": False, "error": "contenu XSF vide"}), 400
    dest, err = _save_structure_xsf(nom, contenu)
    if err:
        return jsonify({"ok": False, "error": err}), 500
    return jsonify({"ok": True, "succes": True, "chemin": str(dest), "path": str(dest)})


@app.route("/api/structure/open", methods=["POST", "OPTIONS"])
def api_structure_open():
    if request.method == "OPTIONS":
        return ("", 204)
    data = request.get_json(silent=True) or {}
    viewer = str(data.get("viewer") or "xcrysden").strip().lower()
    contenu = data.get("contenu") or data.get("content") or data.get("text") or ""
    chemin = data.get("chemin") or data.get("path") or ""
    nom = str(data.get("nom") or data.get("filename") or "structure.xsf").strip()

    if not chemin and contenu.strip():
        dest, err = _save_structure_xsf(nom, contenu)
        if err:
            return jsonify({"ok": False, "error": err}), 500
        chemin = str(dest)
    elif chemin:
        p = Path(chemin).resolve()
        if not p.is_file():
            return jsonify({"ok": False, "error": f"fichier introuvable : {p}"}), 404
        chemin = str(p)
    else:
        return jsonify({"ok": False, "error": "contenu XSF ou chemin manquant"}), 400

    exe = _find_structure_viewer(viewer)
    if not exe:
        return jsonify({
            "ok": False,
            "succes": False,
            "error": f"{viewer} introuvable sur ce système",
            "chemin": chemin,
            "xsf_saved": True,
            "hint": "Installez XCrysDen (apt install xcrysden) ou VESTA, ou téléchargez le .xsf manuellement.",
        }), 404

    try:
        _launch_structure_viewer(exe, viewer, chemin)
    except OSError as e:
        return jsonify({"ok": False, "error": str(e), "chemin": chemin}), 500

    return jsonify({
        "ok": True,
        "succes": True,
        "chemin": chemin,
        "viewer": viewer,
        "executable": exe,
    })


@app.route("/api/sauvegarder_xsf", methods=["POST", "OPTIONS"])
def api_sauvegarder_xsf_compat():
    """Compatibilité legacy Interface-QE (port 5007)."""
    return api_structure_save_xsf()


@app.route("/api/ouvrir_vesta", methods=["POST", "OPTIONS"])
def api_ouvrir_vesta_compat():
    """Compatibilité legacy — lance VESTA sur un fichier XSF déjà sauvegardé."""
    if request.method == "OPTIONS":
        return ("", 204)
    data = request.get_json(silent=True) or {}
    chemin = data.get("chemin") or data.get("path") or ""
    if not chemin:
        return jsonify({"succes": False, "error": "chemin manquant"}), 400
    exe = _find_structure_viewer("vesta")
    if not exe:
        return jsonify({"succes": False, "error": "VESTA introuvable", "chemin": chemin}), 404
    try:
        _launch_structure_viewer(exe, "vesta", chemin)
    except OSError as e:
        return jsonify({"succes": False, "error": str(e)}), 500
    return jsonify({"succes": True, "ok": True, "chemin": chemin})


@app.route("/api/paths", methods=["GET"])
def api_paths():
    root = _project_root()
    cif = _cif_dir()
    out_direct = _outputs_root_for("direct")
    out_cif = _outputs_root_for("cif")
    pseudo_dir = _PC_ENV.get("PSEUDO_DIR") or str(root / "pseudos" / "PBE")
    pseudo_fr_dir = _PC_ENV.get("PSEUDO_FR_DIR") or str(root / "pseudos" / "PBE_FR")
    qe_bin_dir = _PC_ENV.get("QE_BIN_DIR") or ""
    return jsonify({
        "ok": True,
        "project_root": str(root),
        "cif_dir": str(cif),
        "inputs_dir": str(out_direct),
        "inputs_dir_direct": str(out_direct),
        "inputs_dir_cif": str(out_cif),
        "outputs_root": str(out_direct),
        "outputs_root_direct": str(out_direct),
        "outputs_root_cif": str(out_cif),
        "pseudo_dir": pseudo_dir,
        "pseudo_fr_dir": pseudo_fr_dir,
        "qe_bin_dir": qe_bin_dir,
    })


@app.route("/api/cif/list", methods=["GET"])
def api_cif_list():
    """Liste les .cif du dossier data/ du projet (mode portable, sans chemin client)."""
    d = _cif_dir()
    try:
        d.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        return jsonify({"error": f"impossible de créer {d} : {e}"}), 503
    try:
        all_entries = _list_directory_entries(d)
    except OSError as e:
        return jsonify({"error": str(e)}), 500
    cif_files = [e for e in all_entries if e.get("type") == "file" and str(e.get("name", "")).lower().endswith(".cif")]
    return jsonify({
        "ok": True,
        "status": "success",
        "directory": str(d),
        "files": cif_files,
        "all_files": all_entries,
    })


# ----------------------------------------------------------------------------
# Sert l'index.html et les assets statiques du dossier projet
# ----------------------------------------------------------------------------
@app.route("/", methods=["GET"])
def root_index():
    return send_from_directory(str(_STANDALONE_ROOT), "index.html")


@app.route("/<path:asset>", methods=["GET"])
def static_asset(asset):
    safe = asset.replace("..", "")
    full = (_STANDALONE_ROOT / safe).resolve()
    try:
        full.relative_to(_STANDALONE_ROOT.resolve())
    except Exception:
        abort(403)
    if full.is_file():
        return send_from_directory(str(full.parent), full.name)
    abort(404)


# ----------------------------------------------------------------------------
def main() -> None:
    """Point d'entrée du serveur Flask autonome (port 5012 par défaut)."""
    print(f"[gen_inputs_qe] standalone server  build_tag={API_BUILD_TAG}", flush=True)
    print(f"[gen_inputs_qe] http://{HOST}:{PORT}/  outputs_root={_outputs_root()}", flush=True)
    app.run(host=HOST, port=PORT, debug=False, threaded=True)


if __name__ == "__main__":
    main()

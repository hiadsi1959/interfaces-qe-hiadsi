"""Générateurs de templates d'inputs QE auxiliaires (QE 7.5+)."""
from __future__ import annotations

import inspect
from typing import Optional

# plot_num pp.x — guide INPUT_PP QE 7.5
PP_PLOT_NUM = {
    "pp": 0,
    "pp_charge": 0,
    "pp_rho": 0,
    "pp_potential": 1,
    "pp_vtot": 1,
    "pp_ldos": 5,
    "pp_elf": 6,
    "pp_spin": 8,
    "pp_vh": 11,
    "pp_vxc": 10,
}


def bands_kpath_crystal_b(ibrav: int) -> str:
    """Chemin k haute-symétrie minimal selon ibrav (pw.x crystal_b)."""
    ib = int(ibrav or 0)
    if ib == 2:
        return """K_POINTS crystal_b
5
0.0000 0.0000 0.0000 50  ! Gamma
0.5000 0.0000 0.5000 50  ! X
0.5000 0.2500 0.7500 50  ! W
0.0000 0.0000 0.0000 50  ! Gamma
0.5000 0.5000 0.5000 1   ! L"""
    if ib == 3:
        return """K_POINTS crystal_b
4
0.0000 0.0000 0.0000 50  ! Gamma
0.5000 -0.5000 0.5000 50  ! H
0.0000 0.0000 0.5000 50  ! N
0.0000 0.0000 0.0000 1   ! Gamma"""
    if ib == 4:
        return """K_POINTS crystal_b
4
0.0000 0.0000 0.0000 50  ! Gamma
0.5000 0.0000 0.0000 50  ! M
0.3333 0.3333 0.0000 50  ! K
0.0000 0.0000 0.0000 1   ! Gamma"""
    return """K_POINTS crystal_b
4
0.0000 0.0000 0.0000 50  ! Gamma
0.5000 0.0000 0.0000 50  ! X
0.5000 0.5000 0.0000 50  ! M
0.0000 0.0000 0.0000 1   ! Gamma"""


def estimate_nbnd(nat: int, ntyp: int = 1) -> int:
    try:
        n = max(1, int(nat))
    except (TypeError, ValueError):
        n = 1
    return max(8, n * 8)


def _outdir_slash(outdir: str) -> str:
    o = str(outdir or "./out").rstrip("/") + "/"
    return o


def build_dos_input(
    prefix: str = "material",
    outdir: str = "./out",
    fildos: Optional[str] = None,
    emin: float = -10.0,
    emax: float = 10.0,
    deltae: float = 0.01,
) -> str:
    fildos = fildos or f"{prefix}.dos"
    return f"""&DOS
  prefix = '{prefix}'
  outdir = '{_outdir_slash(outdir)}'
  fildos = '{fildos}'
  emin   = {emin}
  emax   = {emax}
  deltae = {deltae}
/
"""


def build_bands_pp_input(
    prefix: str = "material",
    outdir: str = "./out",
    filband: Optional[str] = None,
    lsym: bool = True,
) -> str:
    filband = filband or f"{prefix}.bands"
    lsym_s = ".true." if lsym else ".false."
    return f"""&BANDS
  prefix  = '{prefix}'
  outdir  = '{_outdir_slash(outdir)}'
  filband = '{filband}'
  lsym    = {lsym_s}
/
"""


def build_projwfc_input(
    prefix: str = "material",
    outdir: str = "./out",
    filpdos: Optional[str] = None,
    ngauss: int = 0,
    degauss: float = 0.01,
) -> str:
    filpdos = filpdos or f"{prefix}"
    return f"""&PROJWFC
  prefix  = '{prefix}'
  outdir  = '{_outdir_slash(outdir)}'
  filpdos = '{filpdos}'
  ngauss  = {ngauss}
  degauss = {degauss}
/
"""


def build_ph_input(
    prefix: str = "material",
    outdir: str = "./out",
    tr2_ph: float = 1.0e-12,
    ldisp: bool = False,
    nq1: int = 2,
    nq2: int = 2,
    nq3: int = 2,
    trans: str = "all",
    fildvscf: Optional[str] = None,
    amass: Optional[str] = None,
    zeu: bool = False,
    epsil: bool = False,
) -> str:
    ld = ".true." if ldisp else ".false."
    fildvscf = fildvscf or f"{prefix}.dvscf"
    amass_line = f"  amass(1) = {amass}\n" if amass else ""
    zeu_line = f"  zeu      = .true.\n" if zeu else ""
    epsil_line = f"  epsil    = .true.\n" if epsil else ""
    body = f"""&INPUTPH
  tr2_ph   = {tr2_ph}
  prefix   = '{prefix}'
  outdir   = '{_outdir_slash(outdir)}'
  fildyn   = '{prefix}.dyn'
  fildvscf = '{fildvscf}'
  ldisp    = {ld}
  nq1      = {nq1}
  nq2      = {nq2}
  nq3      = {nq3}
  trans    = '{trans}'
{zeu_line}{epsil_line}{amass_line}/
"""
    if ldisp:
        return body + "! Grille q automatique (ldisp=.true.) — exécuter après SCF convergé\n"
    hint = ""
    if zeu:
        hint = "! Charges effectives de Born (zeu=.true.) — après SCF très convergé (conv_thr ~ 1.d-12)\n"
    return body + hint + f"""! Mode q explicite (ldisp=.false.) — compléter les q-points ci-dessous
{prefix}.dyn0
0.0 0.0 0.0  1.0
! Exemple Γ : 0 0 0 | X : 0.5 0 0.5 (ajuster selon la maille)
"""


def build_ph_zeu_input(
    prefix: str = "material",
    outdir: str = "./out",
    tr2_ph: float = 1.0e-12,
    epsil: bool = False,
    **kwargs,
) -> str:
    """ph.x — charges effectives de Born (zeu) à Γ, après SCF strict."""
    return build_ph_input(
        prefix=prefix,
        outdir=outdir,
        tr2_ph=tr2_ph,
        ldisp=False,
        zeu=True,
        trans=str(kwargs.get("trans") or "all"),
        fildvscf=kwargs.get("fildvscf"),
        amass=kwargs.get("amass"),
        epsil=bool(epsil),
    )


def build_q2r_input(
    prefix: str = "material",
    fildyn: Optional[str] = None,
    flfrc: Optional[str] = None,
) -> str:
    fildyn = fildyn or f"{prefix}.dyn"
    flfrc = flfrc or f"{prefix}.fc"
    return f"""&INPUT
  fildyn = '{fildyn}'
  flfrc  = '{flfrc}'
  zasr   = 'simple'
/
"""


def build_matdyn_input(
    prefix: str = "material",
    flfrc: Optional[str] = None,
    flfrq: Optional[str] = None,
    flvec: Optional[str] = None,
    asr: str = "simple",
) -> str:
    flfrc = flfrc or f"{prefix}.fc"
    flfrq = flfrq or f"{prefix}.freq"
    flvec = flvec or f"{prefix}.modes"
    return f"""&INPUT
  flfrc = '{flfrc}'
  flfrq = '{flfrq}'
  flvec = '{flvec}'
  asr   = '{asr}'
  dos   = .false.
/
"""


def build_matdyn_disp_input(
    prefix: str = "material",
    flfrc: Optional[str] = None,
    flfrq: Optional[str] = None,
    flvec: Optional[str] = None,
    npath: int = 51,
) -> str:
    flfrc = flfrc or f"{prefix}.fc"
    flfrq = flfrq or f"{prefix}.freq"
    flvec = flvec or f"{prefix}.modes"
    return f"""&INPUT
  flfrc = '{flfrc}'
  flfrq = '{flfrq}'
  flvec = '{flvec}'
  asr   = 'simple'
  dos   = .false.
/
{npath}
! Chemin q haute symétrie (ex. FCC) — ajuster selon ibrav
  0.0000 0.0000 0.0000  {max(10, npath // 5)}  ! Gamma
  0.5000 0.0000 0.5000  {max(10, npath // 5)}  ! X
  0.5000 0.2500 0.7500  {max(10, npath // 5)}  ! W
  0.0000 0.0000 0.0000  {max(10, npath // 5)}  ! Gamma
  0.5000 0.5000 0.5000  1                    ! L
"""


def build_matdyn_dos_input(
    prefix: str = "material",
    flfrc: Optional[str] = None,
    fldos: Optional[str] = None,
    nk1: int = 10,
    nk2: int = 10,
    nk3: int = 10,
) -> str:
    flfrc = flfrc or f"{prefix}.fc"
    fldos = fldos or f"{prefix}.phdos"
    return f"""&INPUT
  flfrc = '{flfrc}'
  fldos = '{fldos}'
  asr   = 'simple'
  dos   = .true.
  nk1   = {nk1}
  nk2   = {nk2}
  nk3   = {nk3}
/
"""


def build_matdyn_thermo_input(
    prefix: str = "material",
    flfrc: Optional[str] = None,
    fldos: Optional[str] = None,
) -> str:
    flfrc = flfrc or f"{prefix}.fc"
    fldos = fldos or f"{prefix}.thermo"
    return f"""&INPUT
  flfrc = '{flfrc}'
  fldos = '{fldos}'
  asr   = 'simple'
  dos   = .true.
  nk1   = 16
  nk2   = 16
  nk3   = 16
/
! Propriétés thermodynamiques (phonon DOS) — post-traiter fldos
"""


def build_dynmat_input(
    prefix: str = "material",
    fildyn: Optional[str] = None,
) -> str:
    fildyn = fildyn or f"{prefix}.dyn"
    return f"""&INPUT
  fildyn = '{fildyn}'
/
! amass : lu depuis le fichier dynamique si non spécifié (QE 7.5)
"""


def build_pp_input(
    prefix: str = "material",
    outdir: str = "./out",
    plot_num: int = 0,
    filplot: Optional[str] = None,
) -> str:
    suffix = {
        0: "rho",
        1: "pot",
        5: "ldos",
        6: "elf",
        8: "spin",
        10: "vxc",
        11: "vh",
    }.get(int(plot_num), "plot")
    filplot = filplot or f"{prefix}.{suffix}"
    return f"""&INPUTPP
  prefix   = '{prefix}'
  outdir   = '{_outdir_slash(outdir)}'
  plot_num = {int(plot_num)}
  filplot  = '{filplot}'
/
"""


def _build_pp_variant(
    prefix: str = "material",
    outdir: str = "./out",
    variant: str = "pp_charge",
    filplot: Optional[str] = None,
) -> str:
    plot_num = PP_PLOT_NUM.get(variant, 0)
    return build_pp_input(prefix=prefix, outdir=outdir, plot_num=plot_num, filplot=filplot)


def build_pp_charge_input(prefix: str = "material", outdir: str = "./out", **kw) -> str:
    return _build_pp_variant(prefix, outdir, "pp_charge", kw.get("filplot"))


def build_pp_potential_input(prefix: str = "material", outdir: str = "./out", **kw) -> str:
    return _build_pp_variant(prefix, outdir, "pp_potential", kw.get("filplot"))


def build_pp_ldos_input(prefix: str = "material", outdir: str = "./out", **kw) -> str:
    return _build_pp_variant(prefix, outdir, "pp_ldos", kw.get("filplot"))


def build_pp_elf_input(prefix: str = "material", outdir: str = "./out", **kw) -> str:
    return _build_pp_variant(prefix, outdir, "pp_elf", kw.get("filplot"))


def build_pp_vh_input(prefix: str = "material", outdir: str = "./out", **kw) -> str:
    return _build_pp_variant(prefix, outdir, "pp_vh", kw.get("filplot"))


def build_pp_spin_input(prefix: str = "material", outdir: str = "./out", **kw) -> str:
    return _build_pp_variant(prefix, outdir, "pp_spin", kw.get("filplot"))


def build_average_input(
    prefix: str = "material",
    outdir: str = "./out",
    filavg: Optional[str] = None,
) -> str:
    filavg = filavg or f"{prefix}.avg"
    return f"""&AVERAGE
  prefix = '{prefix}'
  outdir = '{_outdir_slash(outdir)}'
  filavg = '{filavg}'
/
"""


def build_plotrho_input(
    prefix: str = "material",
    filplot: Optional[str] = None,
    nx: int = 50,
    ny: int = 50,
) -> str:
    filplot = filplot or f"{prefix}.rho"
    return f"""&INPUTPLOT
  filplot = '{filplot}'
  nx      = {nx}
  ny      = {ny}
/
! Visualisation charge — exécuter après pp.x (plot_num=0)
"""


def build_plotband_input(
    prefix: str = "material",
    outdir: str = "./out",
    filband: Optional[str] = None,
) -> str:
    filband = filband or f"{prefix}.bands"
    return f"""&BANDS
  prefix  = '{prefix}'
  outdir  = '{_outdir_slash(outdir)}'
  filband = '{filband}'
  lp      = .true.
  lsym    = .true.
/
! Tracé bandes — après bands.x
"""


def build_epsilon_input(
    prefix: str = "material",
    outdir: str = "./out",
    smearing: float = 0.02,
    inter_bands: bool = True,
) -> str:
    inter = ".true." if inter_bands else ".false."
    return f"""&INPUT
  prefix      = '{prefix}'
  outdir      = '{_outdir_slash(outdir)}'
  smearing    = {smearing}
  intra_bands = .true.
  inter_bands = {inter}
  use_qgrid   = .true.
/
! Fonction diélectrique ε(ω) — après NSCF (DFPT/optique)
! Post-traiter avec epsilon.x ou scripts QE associés
"""


def build_turbo_lanczos_input(
    prefix: str = "material",
    outdir: str = "./out",
    egr_id: int = 1,
    itermax: int = 500,
    conv_thr: float = 1.0e-4,
    egr_nbnd: Optional[int] = None,
) -> str:
    nbnd_line = f"  egr_nbnd    = {egr_nbnd}\n" if egr_nbnd else ""
    return f"""&LR_INPUT
  prefix       = '{prefix}'
  outdir       = '{_outdir_slash(outdir)}'
  egr_id       = {egr_id}
  lr_verbosity = 1
  itermax      = {itermax}
  conv_thr     = {conv_thr}
{nbnd_line}/
! Absorption optique LR-TDDFT (turbo_lanczos.x)
! Post-traitement : turbo_spectrum.x sur le fichier Lanczos généré
"""


def build_turbo_davidson_input(
    prefix: str = "material",
    outdir: str = "./out",
    egr_id: int = 1,
    davidson_max_iter: int = 100,
    conv_thr: float = 1.0e-4,
) -> str:
    return f"""&LR_INPUT
  prefix            = '{prefix}'
  outdir            = '{_outdir_slash(outdir)}'
  egr_id            = {egr_id}
  lr_verbosity      = 1
  davidson          = .true.
  davidson_max_iter = {davidson_max_iter}
  conv_thr          = {conv_thr}
/
! Spectroscopie optique (turbo_davidson.x) — transitions discrètes
"""


def build_turbo_eels_input(
    prefix: str = "material",
    outdir: str = "./out",
    egr_id: int = 1,
    q0: float = 0.01,
    itermax: int = 500,
) -> str:
    return f"""&LR_INPUT
  prefix       = '{prefix}'
  outdir       = '{_outdir_slash(outdir)}'
  egr_id       = {egr_id}
  lr_verbosity = 1
  q0           = {q0}
  itermax      = {itermax}
/
! EELS (turbo_eels.x) — perte d'énergie électronique
! Prérequis : NSCF convergé + grille k dense
"""


def build_xspectra_input(
    prefix: str = "material",
    outdir: str = "./out",
) -> str:
    return f"""&XSPEC
  prefix     = '{prefix}'
  outdir     = '{_outdir_slash(outdir)}'
  xonly_plot = .false.
  iprint     = 0
  ia1        = 1
  ia2        = 0
/
! Spectres X (absorption K/L) — xspectra.x
"""


def build_alpha2f_input(
    prefix: str = "material",
    fila2f: Optional[str] = None,
) -> str:
    fila2f = fila2f or f"{prefix}.a2f"
    return f"""&INPUT
  fila2f  = '{fila2f}'
  fltrans = '{prefix}.dos'
  lter    = .false.
/
! Fonction spectrale Eliashberg α²F(ω) — après ph.x + matdyn
"""


def build_lambda_input(
    prefix: str = "material",
) -> str:
    return f"""&INPUT
  drho = '{prefix}.drho'
  dg   = '{prefix}.dg'
/
! Constante de couplage électron-phonon λ — après ph.x
"""


def build_hp_input(
    prefix: str = "material",
    outdir: str = "./out",
    maxiter: int = 100,
    nmix: int = 1,
) -> str:
    return f"""&INPUTHP
  prefix  = '{prefix}'
  outdir  = '{_outdir_slash(outdir)}'
  maxiter = {maxiter}
  nmix    = {nmix}
/
! Paramètres Hubbard U/J ab initio (hp.x) — après SCF+Hubbard
"""


def build_epw_input(
    prefix: str = "material",
    outdir: str = "./out",
    epwwin: float = 0.0,
    nkf1: int = 4,
    nkf2: int = 4,
    nkf3: int = 4,
    nqg1: int = 2,
    nqg2: int = 2,
    nqg3: int = 2,
    fsthick: float = 10.0,
    degaussq: float = 0.02,
    wscut: float = 0.0,
) -> str:
    return f"""&INPUTEPW
  prefix   = '{prefix}'
  outdir   = '{_outdir_slash(outdir)}'
  epwwin   = {epwwin}
  nkf1     = {nkf1}
  nkf2     = {nkf2}
  nkf3     = {nkf3}
  nqg1     = {nqg1}
  nqg2     = {nqg2}
  nqg3     = {nqg3}
  fsthick  = {fsthick}
  degaussq = {degaussq}
  wscut    = {wscut}
  elph     = .true.
  prtgkk   = .false.
  lpolar   = .true.
/
! Couplage électron-phonon (epw.x) — chaîne : SCF → NSCF → ph.x (ldisp) → epw.x
! Vérifier cohérence des grilles k/q et des fichiers .save/
"""


def build_cp_input_stub(
    prefix: str = "material",
    outdir: str = "./out",
) -> str:
    return f"""&CONTROL
  calculation = 'cp'
  prefix      = '{prefix}'
  outdir      = '{_outdir_slash(outdir)}'
  pseudo_dir  = './pseudos/'
  restart_mode = 'from_scratch'
/
&SYSTEM
  ibrav = 0
  nat   = 1
  ntyp  = 1
  ecutwfc = 40.0
/
&CP
  emass = 1.0
  dt    = 4.0
  nstep = 1000
/
! Dynamique Car-Parrinello (cp.x) — compléter ATOMIC_SPECIES / POSITIONS / K_POINTS
"""


def build_neb_input_stub(prefix: str = "material") -> str:
    return f"""&PATH
  restart_mode = 'from_scratch'
  string_method = 'bfgs'
  nstep_path = 1
  num_of_images = 3
  path_threshold = 0.05
/
! NEB : compléter avec images intermédiaires (ATOMIC_POSITIONS par image)
! prefix suggéré : {prefix}
"""


def build_pw2wan_input(
    prefix: str = "material",
    outdir: str = "./out",
    seedname: Optional[str] = None,
) -> str:
    seedname = seedname or prefix
    return f"""&inputpw2wan
  outdir   = '{_outdir_slash(outdir)}'
  prefix   = '{prefix}'
  seedname = '{seedname}'
/
! Interface pw.x → Wannier90 (pw2wannier90.x) — après NSCF
"""


BUILDERS = {
    "dos": build_dos_input,
    "bands_pp": build_bands_pp_input,
    "projwfc": build_projwfc_input,
    "ph": build_ph_input,
    "ph_zeu": build_ph_zeu_input,
    "q2r": build_q2r_input,
    "matdyn": build_matdyn_input,
    "matdyn_disp": build_matdyn_disp_input,
    "matdyn_dos": build_matdyn_dos_input,
    "matdyn_thermo": build_matdyn_thermo_input,
    "dynmat": build_dynmat_input,
    "pp": build_pp_input,
    "pp_charge": build_pp_charge_input,
    "pp_potential": build_pp_potential_input,
    "pp_ldos": build_pp_ldos_input,
    "pp_elf": build_pp_elf_input,
    "pp_vh": build_pp_vh_input,
    "pp_spin": build_pp_spin_input,
    "average": build_average_input,
    "plotrho": build_plotrho_input,
    "plotband": build_plotband_input,
    "epsilon": build_epsilon_input,
    "turbo_lanczos": build_turbo_lanczos_input,
    "turbo_davidson": build_turbo_davidson_input,
    "turbo_eels": build_turbo_eels_input,
    "xspectra": build_xspectra_input,
    "alpha2f": build_alpha2f_input,
    "lambda": build_lambda_input,
    "hp": build_hp_input,
    "epw": build_epw_input,
    "cp": build_cp_input_stub,
    "neb": build_neb_input_stub,
    "pw2wan": build_pw2wan_input,
}


def build_aux_input(package: str, **kwargs) -> str:
    pid = str(package or "").strip().lower()
    fn = BUILDERS.get(pid)
    if not fn:
        raise ValueError(f"package non supporté pour génération template : {pid}")
    sig = inspect.signature(fn)
    filtered = {k: v for k, v in kwargs.items() if k in sig.parameters}
    return fn(**filtered)

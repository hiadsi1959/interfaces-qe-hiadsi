"""Templates auxiliaires enrichis (ph, epw, turbo_*)."""
from __future__ import annotations

import pytest

from qe75_verifier import verify_qe75
from qe_input_builders import build_aux_input


@pytest.mark.parametrize("pkg,needles", [
    ("ph", ["fildvscf", "trans", "ldisp"]),
    ("ph_zeu", ["zeu", "0.0 0.0 0.0"]),
    ("epw", ["nqg1", "degaussq", "lpolar", "elph"]),
    ("turbo_lanczos", ["itermax", "conv_thr", "turbo_spectrum"]),
    ("turbo_davidson", ["davidson_max_iter", "conv_thr"]),
    ("turbo_eels", ["q0", "itermax"]),
    ("matdyn_disp", ["Gamma", "0.5000 0.0000 0.5000"]),
    ("epsilon", ["smearing", "inter_bands", "intra_bands"]),
])
def test_aux_templates_contain_enriched_fields(pkg: str, needles: list[str]):
    text = build_aux_input(pkg, prefix="Si")
    for n in needles:
        assert n in text, f"{pkg}: champ/commentaire manquant: {n}"
    res = verify_qe75(text, package=pkg, strict=True)
    assert res.ok, f"{pkg}: {res.errors}"

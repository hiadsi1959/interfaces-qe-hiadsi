/** Généré par CONFIGURER.sh — 2026-07-28T18:45:47+01:00 — ne pas éditer à la main */
(function () {
    'use strict';
    window.QE_CONFIG_PRELOAD = {
        INPUTS_DIRECT_DIR: "/home/hiadsi/g\u00e9n\u00e9ration_inputs-QE/inputs_g\u00e9n\u00e9r\u00e9s_direct",
        INPUTS_GENERES_DIR: "/home/hiadsi/g\u00e9n\u00e9ration_inputs-QE/inputs_g\u00e9n\u00e9r\u00e9s_direct",
        INPUTS_DIR: "/home/hiadsi/g\u00e9n\u00e9ration_inputs-QE/inputs_g\u00e9n\u00e9r\u00e9s_direct",
        INPUTS_CIF_DIR: "/home/hiadsi/g\u00e9n\u00e9ration_inputs-QE/inputs_convertis_cif",
        OUTPUTS_DIR: "/home/hiadsi/g\u00e9n\u00e9ration_inputs-QE/outputs",
        PSEUDO_DIR: "/home/hiadsi/g\u00e9n\u00e9ration_inputs-QE/pseudos/PBE",
        PSEUDO_FR_DIR: "/home/hiadsi/g\u00e9n\u00e9ration_inputs-QE/pseudos/PBE_FR",
        CIF_DIR: "/home/hiadsi/g\u00e9n\u00e9ration_inputs-QE/data",
        QE_BIN_DIR: "/home/hiadsi/q-e-qe-7.5/bin",
        WORK_DIR: "/home/hiadsi/g\u00e9n\u00e9ration_inputs-QE"
    };
})();

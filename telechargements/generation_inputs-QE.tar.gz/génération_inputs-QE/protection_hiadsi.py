#!/usr/bin/env python3
"""
Protection HIADSI — les interfaces restent utilisables,
mais le code source ne peut être modifié qu'avec le mot de passe auteur.
"""

from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import os
import stat
import sys
from pathlib import Path

# Mot de passe auteur (hashé à l'installation — jamais en clair dans .protection/)
DEFAULT_PASSWORD = "rio_salado_1959sh"

SKIP_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "venv",
    "env",
    "__pycache__",
    ".pytest_cache",
    ".protection",
    "outputs",
    "inputs",
    "logs",
    "tmp",
    "work",
    "dist",
    "build",
    "_work",
    "node_modules",
    "BaTiO3",
    "inputs_convertis_cif",
    "inputs_générés_direct",
    "out",
    "third_party",
    "pseudos",
    "pseudos-ld1",
    "fichiers_cif",
    "structures",
    "api.pid",
}

SKIP_NAME_EXACT = {
    "api_config.json",
    "api_config.local.json",
    "config.env",
    "config_pc.env",
    "api.pid",
    "parser.log",
    "api.log",
    "api_restart.log",
    "protection_hiadsi.py",
    "VERROUILLER.sh",
    "DEVERROUILLER-MODIFICATION.sh",
    "VERIFIER-INTEGRITE.sh",
}

SKIP_SUFFIXES = {
    ".log",
    ".pid",
    ".pyc",
    ".pyo",
    ".tar.gz",
    ".tgz",
    ".zip",
    ".UPF",
    ".upf",
    ".in",
    ".out",
    ".dat",
    ".xsf",
    ".cif",
}

PROTECT_SUFFIXES = {
    ".html",
    ".htm",
    ".js",
    ".css",
    ".py",
    ".sh",
    ".md",
    ".txt",
    ".json",
    ".svg",
    ".desktop",
    ".desktop.in",
    ".example",
    ".in",  # only templates named *.in in source? skip .in above wins for data - remove .in from protect
}

# recalibrate: don't protect .in as data inputs
PROTECT_SUFFIXES.discard(".in")


def root_from_script() -> Path:
    return Path(__file__).resolve().parent


def protection_dir(root: Path) -> Path:
    return root / ".protection"


def hash_password(password: str, salt: str) -> str:
    return hashlib.sha256(f"{salt}:{password}".encode("utf-8")).hexdigest()


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def iter_protected_files(root: Path):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [
            d
            for d in dirnames
            if d not in SKIP_DIRS and not d.startswith(".")
        ]
        # keep .protection out; already in SKIP_DIRS
        rel_dir = Path(dirpath).relative_to(root)
        if any(part in SKIP_DIRS for part in rel_dir.parts):
            continue
        for name in filenames:
            if name in SKIP_NAME_EXACT:
                continue
            if name.startswith("."):
                continue
            path = Path(dirpath) / name
            suf = path.suffix.lower()
            if suf in SKIP_SUFFIXES:
                continue
            # protect known source types + extensionless launchers that are scripts
            if suf in PROTECT_SUFFIXES or name in {
                "DEMARRER.sh",
                "ARRETER.sh",
                "CONFIGURER.sh",
                "CONFIGURER-PC.sh",
                "Makefile",
            }:
                if path.is_symlink():
                    continue
                if not path.is_file():
                    continue
                yield path


def load_secret(root: Path) -> dict:
    path = protection_dir(root) / "secret.json"
    if not path.exists():
        raise SystemExit("Protection non initialisée. Lancez : python3 protection_hiadsi.py init")
    return json.loads(path.read_text(encoding="utf-8"))


def verify_password(root: Path, password: str) -> bool:
    secret = load_secret(root)
    return hash_password(password, secret["salt"]) == secret["password_hash"]


def ask_password(prompt: str = "Mot de passe auteur : ") -> str:
    return getpass.getpass(prompt)


def cmd_init(root: Path, password: str | None) -> None:
    pwd = password or DEFAULT_PASSWORD
    salt = hashlib.sha256(os.urandom(32)).hexdigest()[:32]
    pdir = protection_dir(root)
    pdir.mkdir(exist_ok=True)
    secret = {
        "salt": salt,
        "password_hash": hash_password(pwd, salt),
        "auteur": "S. Hiadsi — LMESM / USTO-MB",
        "note": "Modification du code source uniquement avec le mot de passe auteur.",
    }
    (pdir / "secret.json").write_text(json.dumps(secret, indent=2) + "\n", encoding="utf-8")
    os.chmod(pdir / "secret.json", 0o600)
    write_manifest(root)
    lock_files(root)
    unlocked = pdir / "unlocked"
    if unlocked.exists():
        unlocked.unlink()
    print(f"✅ Protection initialisée dans {root.name}")
    print("   Interfaces utilisables · code verrouillé contre modification")


def write_manifest(root: Path) -> int:
    pdir = protection_dir(root)
    pdir.mkdir(exist_ok=True)
    lines = []
    for path in sorted(iter_protected_files(root), key=lambda p: str(p.relative_to(root))):
        rel = path.relative_to(root).as_posix()
        lines.append(f"{file_sha256(path)}  {rel}")
    (pdir / "MANIFEST.sha256").write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    return len(lines)


def lock_files(root: Path) -> int:
    n = 0
    for path in iter_protected_files(root):
        mode = path.stat().st_mode
        path.chmod(mode & ~stat.S_IWUSR & ~stat.S_IWGRP & ~stat.S_IWOTH)
        n += 1
    return n


def unlock_files(root: Path) -> int:
    n = 0
    for path in iter_protected_files(root):
        mode = path.stat().st_mode
        path.chmod(mode | stat.S_IWUSR)
        n += 1
    return n


def cmd_lock(root: Path, password: str | None) -> None:
    pwd = password or ask_password()
    if not verify_password(root, pwd):
        raise SystemExit("❌ Mot de passe incorrect.")
    n = write_manifest(root)
    lock_files(root)
    unlocked = protection_dir(root) / "unlocked"
    if unlocked.exists():
        unlocked.unlink()
    print(f"🔒 Verrouillé — {n} fichiers protégés (lecture seule).")
    print("   L'interface peut toujours démarrer et calculer.")


def cmd_unlock(root: Path, password: str | None) -> None:
    pwd = password or ask_password()
    if not verify_password(root, pwd):
        raise SystemExit("❌ Mot de passe incorrect.")
    n = unlock_files(root)
    (protection_dir(root) / "unlocked").write_text(
        "Mode collaboration actif — pensez à ./VERROUILLER.sh après modifications.\n",
        encoding="utf-8",
    )
    print(f"🔓 Déverrouillé — {n} fichiers modifiables.")
    print("   Après vos changements : ./VERROUILLER.sh")


def cmd_check(root: Path) -> None:
    pdir = protection_dir(root)
    manifest_path = pdir / "MANIFEST.sha256"
    if not manifest_path.exists():
        print("⚠️  Pas de manifeste de protection — démarrage autorisé.")
        return
    if (pdir / "unlocked").exists():
        print("ℹ️  Mode collaboration (déverrouillé) — contrôle d'intégrité assoupli.")
        return

    expected = {}
    for line in manifest_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or "  " not in line:
            continue
        digest, rel = line.split("  ", 1)
        expected[rel] = digest

    errors = []
    for rel, digest in expected.items():
        path = root / rel
        if not path.is_file():
            errors.append(f"manquant : {rel}")
            continue
        if file_sha256(path) != digest:
            errors.append(f"modifié : {rel}")

    # nouveaux fichiers source non listés
    for path in iter_protected_files(root):
        rel = path.relative_to(root).as_posix()
        if rel not in expected and rel != "protection_hiadsi.py":
            # allow new only when unlocked; here locked → report
            errors.append(f"ajouté sans autorisation : {rel}")

    if errors:
        print("❌ INTERFACE PROTÉGÉE — modification détectée sans autorisation.")
        print("   L'auteur : S. Hiadsi (LMESM / USTO-MB)")
        print("   Pour collaborer / modifier : ./DEVERROUILLER-MODIFICATION.sh")
        for e in errors[:12]:
            print(f"   • {e}")
        if len(errors) > 12:
            print(f"   … et {len(errors) - 12} autre(s)")
        raise SystemExit(2)

    print("✅ Intégrité OK — interface prête (code non modifié).")


def main() -> None:
    parser = argparse.ArgumentParser(description="Protection anti-modification HIADSI")
    parser.add_argument(
        "command",
        choices=["init", "lock", "unlock", "check"],
        help="init | lock | unlock | check",
    )
    parser.add_argument("--root", default=None, help="Racine de l'interface")
    parser.add_argument("--password", default=None, help="Mot de passe (sinon demandé)")
    args = parser.parse_args()
    root = Path(args.root).resolve() if args.root else root_from_script()

    if args.command == "init":
        cmd_init(root, args.password)
    elif args.command == "lock":
        cmd_lock(root, args.password)
    elif args.command == "unlock":
        cmd_unlock(root, args.password)
    elif args.command == "check":
        cmd_check(root)


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
# Déverrouille le code pour collaboration (mot de passe auteur requis)
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
exec python3 "$HERE/protection_hiadsi.py" unlock --root "$HERE"

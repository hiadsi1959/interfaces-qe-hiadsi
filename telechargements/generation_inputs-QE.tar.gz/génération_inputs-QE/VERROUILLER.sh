#!/usr/bin/env bash
# Re-verrouille le code après modification (mot de passe auteur requis)
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
exec python3 "$HERE/protection_hiadsi.py" lock --root "$HERE"

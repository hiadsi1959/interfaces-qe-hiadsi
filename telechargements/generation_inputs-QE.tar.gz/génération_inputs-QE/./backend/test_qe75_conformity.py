#!/usr/bin/env python3
"""
Tests unitaires de conformité QE 7.5 pour la génération d'inputs.

Vérifie :
1. nspin=4 n'est JAMAIS écrit (→ noncolin=.true.)
2. Syntaxe HUBBARD (ortho-atomic) correcte
3. Namelists complètes (&CONTROL, &SYSTEM, &ELECTRONS, &IONS, &CELL)
4. paramètres de maille valides
5. Cohérence nspin=2 avec starting_magnetization
"""

import sys, os, re
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend'))

try:
    from cif_to_qe import analyze_cif, build_pw_input
except ImportError:
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend'))
    from cif_to_qe import analyze_cif, build_pw_input


CIF = os.path.join(os.path.dirname(__file__), "..", "cif")
if not os.path.isdir(CIF):
    CIF = os.path.join(os.path.dirname(__file__), "cif")


def _cif(name):
    return os.path.join(CIF, name)

# ─────────────────────────────────────────────
# TEST 1 : nspin=1 → aucun nspin écrit
# ─────────────────────────────────────────────
def test_no_nspin_for_non_polarized():
    cif = analyze_cif(_cif('Si.cif'))
    text = build_pw_input(cif, calculation='scf', ecutwfc=50, ecutrho=400)
    assert 'nspin' not in text, (
        "nspin=1 ne doit rien écrire dans &SYSTEM"
    )
    assert 'noncolin' not in text, (
        "noncolin ne doit pas apparaître pour nspin=1"
    )

# ─────────────────────────────────────────────
# TEST 2 : nspin=2 → nspin=2 + starting_mag
# ─────────────────────────────────────────────
def test_nspin2_with_startmag():
    cif = analyze_cif(_cif('Si.cif'))
    text = build_pw_input(cif, calculation='scf', nspin=2, ecutwfc=55, ecutrho=440,
                          starting_magnetization={'Si': 0.5})
    assert 'nspin = 2' in text, (
        "nspin=2 doit écrire nspin = 2"
    )
    assert 'starting_magnetization' in text, (
        "starting_magnetization doit être présent pour nspin=2"
    )

# ─────────────────────────────────────────────
# TEST 3 : nspin=4 → NON (noncolin=.true. OUI)
# ─────────────────────────────────────────────
def test_no_nspin4_noncolin():
    cif = analyze_cif(_cif('DyVO3_mp-22789_primitive.cif'), primitive=True)
    text = build_pw_input(cif, calculation='scf', ecutwfc=60, ecutrho=480,
                          nspin=4)
    # nspin=4 NE DOIT PAS apparaître
    nspin_matches = re.findall(r'^\s*nspin\s*=\s*4\s*$', text, re.MULTILINE)
    assert not nspin_matches, (
        f"nspin=4 ne doit PAS apparaître dans l'input (QE 7.5): {nspin_matches}"
    )
    # noncolin DOIT apparaître
    assert 'noncolin' in text, (
        "noncolin doit être présent pour nspin=4"
    )
    assert 'noncolin = .true.' in text

# ─────────────────────────────────────────────
# TEST 4 : Hubbard card syntax
# ─────────────────────────────────────────────
def test_hubbard_card_syntax():
    cif = analyze_cif(_cif('DyVO3_mp-22789_primitive.cif'), primitive=True)
    text = build_pw_input(cif, calculation='vc-relax', ecutwfc=65, ecutrho=520,
                          nspin=4,
                          hubbard_u={'Dy': 6.5, 'V': 4.0},
                          hubbard_manifolds={'Dy': '4f', 'V': '3d'},
                          hubbard_syntax='card')
    assert 'HUBBARD (ortho-atomic)' in text, (
        "La carte HUBBARD doit commencer par HUBBARD (ortho-atomic)"
    )
    assert 'U  Dy-4f  6.500000' in text, (
        "La ligne U Dy-4f doit être présente"
    )
    assert 'U  V-3d  4.000000' in text, (
        "La ligne U V-3d doit être présente"
    )
    # Pour carte HUBBARD (QE 7.5+), lda_plus_u est facultatif dans &SYSTEM
    # (la carte active automatiquement DFT+U). On vérifie que la carte est présente.
    assert 'HUBBARD' in text, "La carte HUBBARD doit être présente"
    assert 'U  Dy-4f' in text
    assert 'U  V-3d' in text

# ─────────────────────────────────────────────
# TEST 5 : Namelists complètes
# ─────────────────────────────────────────────
def test_namelists_complete():
    cif = analyze_cif(_cif('DyVO3_mp-22789_primitive.cif'), primitive=True)
    text = build_pw_input(cif, calculation='vc-relax', ecutwfc=65, ecutrho=520)
    required = ['&CONTROL', '&SYSTEM', '&ELECTRONS', '&IONS', '&CELL',
                'ATOMIC_SPECIES', 'ATOMIC_POSITIONS', 'K_POINTS']
    for section in required:
        assert section in text, f"Section {section} manquante dans l'input"

    # relax only
    text2 = build_pw_input(cif, calculation='relax', ecutwfc=65, ecutrho=520)
    assert '&IONS' in text2, "&IONS manquant pour relax"
    assert '&CELL' not in text2, "&CELL ne doit pas être dans relax"

    # scf only
    text3 = build_pw_input(cif, calculation='scf', ecutwfc=65, ecutrho=520)
    assert '&IONS' not in text3, "&IONS ne doit pas être dans scf"
    assert '&CELL' not in text3, "&CELL ne doit pas être dans scf"

# ─────────────────────────────────────────────
# TEST 6 : AFM split avec magnetizations
# ─────────────────────────────────────────────
def test_afm_split_start_mag():
    """AFM-G + Hubbard : nspin=2, starting_magnetization, carte U après K_POINTS."""
    cif = analyze_cif(_cif('DyVO3_mp-22789_primitive.cif'), primitive=True, afm_type='afm_g')
    text = build_pw_input(cif, calculation='relax', ecutwfc=55, ecutrho=440,
                          nspin=2, afm_type='afm_g',
                          hubbard_u={'Dy': 6.5, 'V': 3.5},
                          hubbard_manifolds={'Dy': '4f', 'V': '3d'},
                          hubbard_syntax='card')
    assert 'nspin = 2' in text
    assert 'starting_magnetization' in text
    assert 'HUBBARD (ortho-atomic)' in text
    assert 'U  V' in text or 'U  V1' in text or 'U  V2' in text
    # Si split AFM V1/V2 : signes opposés ; sinon au moins un start_mag non nul
    if 'V1' in text and 'V2' in text:
        assert re.search(r'starting_magnetization\(\d+\)\s*=\s*-', text), (
            "AFM split : au moins un starting_magnetization négatif attendu"
        )
    else:
        assert re.search(r'starting_magnetization\(\d+\)\s*=\s*[0-9.\-]+', text)
    from qe75_verifier import verify_pw_qe75
    res = verify_pw_qe75(text, strict=True)
    assert res.ok, res.errors


def test_hubbard_card_after_kpoints():
    """QE 7.5 : carte HUBBARD après K_POINTS (SCF prêt phonons/optique)."""
    cif = analyze_cif(_cif('DyVO3_mp-22789_primitive.cif'), primitive=True)
    text = build_pw_input(
        cif, calculation='scf', ecutwfc=60, ecutrho=480, nspin=2,
        starting_magnetization={'Dy': 0.0, 'V': 0.3, 'O': 0.0},
        hubbard_u={'Dy': 6.5, 'V': 4.0},
        hubbard_manifolds={'Dy': '4f', 'V': '3d'},
        hubbard_syntax='card',
    )
    kp = text.upper().find('K_POINTS')
    hub = text.upper().find('HUBBARD')
    assert kp >= 0 and hub >= 0 and hub > kp, (
        "HUBBARD doit être après K_POINTS"
    )
    from qe75_verifier import verify_pw_qe75
    res = verify_pw_qe75(text, strict=True)
    assert res.ok, res.errors


def test_nspin2_without_startmag_fails_verifier():
    from qe75_verifier import verify_pw_qe75
    text = (
        "&CONTROL\n  calculation = 'scf'\n/\n"
        "&SYSTEM\n  ibrav = 1\n  nat = 1\n  ntyp = 1\n  ecutwfc = 50\n  nspin = 2\n/\n"
        "&ELECTRONS\n/\n"
        "ATOMIC_SPECIES\n  Fe 55.845 Fe.upf\n"
        "ATOMIC_POSITIONS crystal\n  Fe 0 0 0\n"
        "K_POINTS automatic\n  2 2 2 0 0 0\n"
    )
    res = verify_pw_qe75(text, strict=True)
    assert not res.ok
    assert any('starting_magnetization' in e for e in res.errors)


def test_hubbard_between_kpoints_detected_and_sanitized():
    """HUBBARD entre K_POINTS automatic et la grille → erreur verifier + sanitize répare."""
    from qe75_verifier import verify_pw_qe75, sanitize_pw_cards_qe75
    broken = (
        "&CONTROL\n  calculation = 'scf'\n/\n"
        "&SYSTEM\n  ibrav = 1\n  nat = 1\n  ntyp = 1\n  ecutwfc = 50\n"
        "  nspin = 2\n  starting_magnetization(1) = 0.5\n/\n"
        "&ELECTRONS\n  conv_thr = 1.0d-10\n/\n"
        "ATOMIC_SPECIES\n  Fe 55.845 Fe.upf\n"
        "ATOMIC_POSITIONS crystal\n  Fe 0 0 0\n"
        "K_POINTS automatic\n"
        "HUBBARD (ortho-atomic)\n"
        "U  Fe-3d  4.000000\n"
        "\n"
        "  6 6 6  0 0 0\n"
    )
    bad = verify_pw_qe75(broken, strict=True)
    assert not bad.ok
    assert any("HUBBARD" in e and "K_POINTS" in e for e in bad.errors)

    fixed = sanitize_pw_cards_qe75(broken)
    assert re.search(r"K_POINTS\s+automatic\s*\n\s*6\s+6\s+6\s+0\s+0\s+0", fixed)
    assert fixed.upper().find("HUBBARD") > fixed.upper().find("K_POINTS")
    assert not re.search(r"K_POINTS\s+automatic\s*\n\s*HUBBARD", fixed, re.I)
    ok = verify_pw_qe75(fixed, strict=True)
    assert ok.ok, ok.errors


def test_relax_vc_relax_scf_hubbard_kpoints_order():
    """relax / vc-relax / scf + U : K_POINTS grille puis HUBBARD."""
    cif = analyze_cif(_cif('DyVO3_mp-22789_primitive.cif'), primitive=True)
    for calc in ('scf', 'relax', 'vc-relax'):
        text = build_pw_input(
            cif, calculation=calc, ecutwfc=60, ecutrho=480, nspin=2,
            starting_magnetization={'Dy': 0.0, 'V': 0.4, 'O': 0.0},
            hubbard_u={'Dy': 6.5, 'V': 4.0},
            hubbard_manifolds={'Dy': '4f', 'V': '3d'},
            hubbard_syntax='card',
        )
        assert 'HUBBARD (ortho-atomic)' in text
        kp = text.upper().find('K_POINTS')
        hub = text.upper().find('HUBBARD')
        assert hub > kp, f"{calc}: HUBBARD doit suivre K_POINTS"
        assert re.search(
            r"K_POINTS\s+automatic\s*\n\s*\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+",
            text,
            re.I,
        ), f"{calc}: grille k manquante ou corrompue"
        from qe75_verifier import verify_pw_qe75
        res = verify_pw_qe75(text, strict=True)
        assert res.ok, (calc, res.errors)

# ─────────────────────────────────────────────
# TEST 7 : Material class detection (auto)
# ─────────────────────────────────────────────
def test_detect_material_class_si():
    from cif_to_qe import detect_material_class
    cls = detect_material_class('Si', ['Si'])
    assert cls.value == 'semiconductor', (
        f"Si devrait être semi-conducteur, détecté: {cls}"
    )

def test_detect_material_class_fe():
    from cif_to_qe import detect_material_class
    cls = detect_material_class('Fe', ['Fe'])
    # Fe est un métal magnétique (transition metal, pas d'oxygène)
    assert cls.value == 'mag_metal', (
        f"Fe devrait être mag_metal, détecté: {cls}"
    )

def test_detect_material_class_dy():
    from cif_to_qe import detect_material_class
    cls = detect_material_class('Dy', ['Dy'])
    assert cls.value == 'rare_earth', (
        f"Dy devrait être terre rare, détecté: {cls}"
    )

def test_detect_material_class_mgo():
    """MgO → insulator (oxyde + alcalino-terreux sans TM)"""
    from cif_to_qe import detect_material_class
    cls = detect_material_class('MgO', ['Mg', 'O'])
    assert cls.value == 'insulator', (
        f"MgO devrait être insulator, détecté: {cls}"
    )

# ─────────────────────────────────────────────
# TEST 8 : occupations = 'fixed' for insulators
# ─────────────────────────────────────────────
def test_occupations_fixed_for_insulator():
    cif = analyze_cif(_cif('Si.cif'))
    # Si sans smearing explicite → occupations='fixed'
    text = build_pw_input(cif, calculation='scf', ecutwfc=50, ecutrho=400,
                          occupations='fixed')
    assert "occupations = 'fixed'" in text
    assert 'smearing' not in text, (
        "smearing ne doit pas apparaître si occupations='fixed'"
    )

# ─────────────────────────────────────────────
# TEST 9 : Verify no double slashes in paths
# ─────────────────────────────────────────────
def test_no_nspin_in_system():
    """Vérifie que nspin n'apparaît JAMAIS pour nspin=1"""
    cif = analyze_cif(_cif('Si.cif'))
    text = build_pw_input(cif, calculation='scf', ecutwfc=50, ecutrho=400)
    lines = text.split('\n')
    nspin_lines = [l for l in lines if re.match(r'^\s*nspin\s*=', l)]
    assert not nspin_lines, (
        f"nspin ne doit pas être écrit pour nspin=1 ({nspin_lines})"
    )

# ─────────────────────────────────────────────
# TEST 10 : Clean generated input files (existing)
# ─────────────────────────────────────────────
def test_generated_inputs_have_no_nspin4():
    """Vérifie qu'aucun input généré existant ne contient nspin=4"""
    base = os.path.join(os.path.dirname(__file__), '..')
    inputs_dirs = [
        os.path.join(base, 'inputs_générés_direct'),
        os.path.join(base, 'inputs_convertis_cif'),
    ]
    issues = []
    for inputs_dir in inputs_dirs:
        if not os.path.isdir(inputs_dir):
            continue
        for root, dirs, files in os.walk(inputs_dir):
            for f in files:
                if f.endswith('.in'):
                    path = os.path.join(root, f)
                    with open(path) as fh:
                        content = fh.read()
                    if re.search(r'^\s*nspin\s*=\s*4\s*$', content, re.MULTILINE):
                        issues.append(path)
    assert not issues, (
        f"Fichiers avec nspin=4 encore présents: {issues}"
    )


# ─────────────────────────────────────────────
# TEST 11 : Pseudo .rel- (full relativistic) → force noncolin
# ─────────────────────────────────────────────
def test_rel_pseudo_forces_noncolin():
    """
    Vérifie que si un pseudo contient .rel-, nspin=2 est remplacé
    par noncolin=.true. + lspinorb=.true. (QE 7.5 compatibility).
    """
    cif = analyze_cif(_cif('DyVO3_mp-22789_primitive.cif'), primitive=True)
    # Simule des pseudos .rel- (full relativistic)
    pseudos = {
        'Dy': 'Dy.rel-pbe-spn-rrkjus_psl.1.0.0.UPF',
        'V':  'V.rel-pbe-spn-rrkjus_psl.1.0.0.UPF',
        'O':  'O.rel-pbe-n-rrkjus_psl.1.0.0.UPF',
    }
    text = build_pw_input(cif, calculation='scf', nspin=2,
                          ecutwfc=60, ecutrho=480,
                          pseudos=pseudos)
    # nspin=2 NE DOIT PAS apparaître (remplacé par noncolin)
    nspin2 = re.findall(r'^\s*nspin\s*=\s*2\s*$', text, re.MULTILINE)
    assert not nspin2, (
        f"nspin=2 ne doit PAS apparaître avec pseudos .rel-: {nspin2}"
    )
    # noncolin DOIT être présent
    assert 'noncolin = .true.' in text, (
        "noncolin=.true. doit être présent avec pseudos .rel-"
    )
    assert 'lspinorb = .true.' in text, (
        "lspinorb=.true. doit être présent avec pseudos .rel-"
    )

# ─────────────────────────────────────────────
# TEST 12 : Pseudo normal (.pbe-) → nspin=2 conservé
# ─────────────────────────────────────────────
def test_normal_pseudo_keeps_nspin2():
    """
    Vérifie que les pseudos normaux (.pbe-) ne sont PAS affectés
    par la détection .rel- et que nspin=2 reste présent.
    """
    cif = analyze_cif(_cif('DyVO3_mp-22789_primitive.cif'), primitive=True)
    pseudos = {
        'Dy': 'Dy.pbe-spn-rrkjus_psl.1.0.0.UPF',
        'V':  'V.pbe-spn-rrkjus_psl.1.0.0.UPF',
        'O':  'O.pbe-n-rrkjus_psl.1.0.0.UPF',
    }
    text = build_pw_input(cif, calculation='scf', nspin=2,
                          ecutwfc=60, ecutrho=480,
                          pseudos=pseudos)
    assert 'nspin = 2' in text, (
        "nspin=2 doit être conservé avec pseudos .pbe- normaux"
    )
    assert 'noncolin' not in text, (
        "noncolin ne doit PAS apparaître avec pseudos .pbe- normaux"
    )


if __name__ == '__main__':
    pytest_args = ['-v', '--tb=short', __file__]
    import pytest
    sys.exit(pytest.main(pytest_args))

// ═══════════════════════════════════════════════════════════════════════════
// GESTION DES ÉLÉMENTS ET PSEUDO-POTENTIELS DYNAMIQUES (V3)
// Après ntyp: Ajouter les noms des éléments et afficher leurs pseudos
// ═══════════════════════════════════════════════════════════════════════════

/** Masses atomiques (alignées sur backend/cif_to_qe.py ATOMIC_MASSES). */
const ELEMENT_MASSES = {
    'H': 1.008, 'He': 4.003, 'Li': 6.941, 'Be': 9.012, 'B': 10.811, 'C': 12.011, 'N': 14.007, 'O': 15.999,
    'F': 18.998, 'Ne': 20.180, 'Na': 22.990, 'Mg': 24.305, 'Al': 26.982, 'Si': 28.086, 'P': 30.974, 'S': 32.065,
    'Cl': 35.453, 'Ar': 39.948, 'K': 39.098, 'Ca': 40.078, 'Sc': 44.956, 'Ti': 47.867, 'V': 50.942, 'Cr': 51.996,
    'Mn': 54.938, 'Fe': 55.845, 'Co': 58.933, 'Ni': 58.693, 'Cu': 63.546, 'Zn': 65.380, 'Ga': 69.723, 'Ge': 72.640,
    'As': 74.922, 'Se': 78.960, 'Br': 79.904, 'Kr': 83.798, 'Rb': 85.468, 'Sr': 87.620, 'Y': 88.906, 'Zr': 91.224,
    'Nb': 92.906, 'Mo': 95.960, 'Tc': 98.000, 'Ru': 101.070, 'Rh': 102.906, 'Pd': 106.420, 'Ag': 107.868, 'Cd': 112.411,
    'In': 114.818, 'Sn': 118.710, 'Sb': 121.760, 'Te': 127.600, 'I': 126.905, 'Xe': 131.293, 'Cs': 132.906,
    'Ba': 137.327, 'La': 138.905, 'Ce': 140.116, 'Pr': 140.908, 'Nd': 144.242, 'Pm': 145.000, 'Sm': 150.360,
    'Eu': 151.964, 'Gd': 157.250, 'Tb': 158.925, 'Dy': 162.500, 'Ho': 164.930, 'Er': 167.259, 'Tm': 168.934,
    'Yb': 173.040, 'Lu': 174.967, 'Hf': 178.492, 'Ta': 180.948, 'W': 183.840, 'Re': 186.207, 'Os': 190.230,
    'Ir': 192.217, 'Pt': 195.084, 'Au': 196.967, 'Hg': 200.592, 'Tl': 204.383, 'Pb': 207.200, 'Bi': 208.980
};

const _TM_PSEUDO = ['Sc','Ti','V','Cr','Mn','Fe','Co','Ni','Cu','Zn','Y','Zr','Nb','Mo','Tc','Ru','Rh','Pd','Ag','Cd','Hf','Ta','W','Re','Os','Ir','Pt','Au'];
const _LN_PSEUDO = ['La','Ce','Pr','Nd','Pm','Sm','Eu','Gd','Tb','Dy','Ho','Er','Tm','Yb','Lu'];
const _ALK_PSEUDO = ['Li','Na','K','Rb','Cs','Fr'];
const _AE_PSEUDO = ['Be','Mg','Ca','Sr','Ba','Ra'];

function __normalizeElementSymbol(raw) {
    var s = String(raw || '').trim();
    if (!s) return '';
    if (s.length === 1) return s.toUpperCase();
    return s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
}

function __scalarPseudoToFullRel(name) {
    var n = String(name || '').trim();
    if (!n || /\.rel-/i.test(n)) return n;
    n = n.replace(/\.pbe-/i, '.rel-pbe-');
    n = n.replace(/\.rel-pbe-spn-/i, '.rel-pbe-spfn-');
    return n;
}

function __guessPseudoFilenameScalar(element) {
    var el = __normalizeElementSymbol(element);
    if (_LN_PSEUDO.indexOf(el) >= 0 || _ALK_PSEUDO.indexOf(el) >= 0 || _AE_PSEUDO.indexOf(el) >= 0) {
        return el + '.pbe-spn-rrkjus_psl.1.0.0.UPF';
    }
    if (_TM_PSEUDO.indexOf(el) >= 0) {
        if (['Cu','Zn','Ag','Cd','Ga','Ge','In','Sn','Hg','Tl','Pb','Bi'].indexOf(el) >= 0) {
            return el + '.pbe-dn-kjpaw_psl.1.0.0.UPF';
        }
        if (['Pd','Pt','Au'].indexOf(el) >= 0) {
            return el + '.pbe-d-rrkjus_psl.1.0.0.UPF';
        }
        return el + '.pbe-spn-rrkjus_psl.1.0.0.UPF';
    }
    if (['Cl','Br','I'].indexOf(el) >= 0) {
        return el + '.pbe-n-rrkjus_psl.1.0.0.UPF';
    }
    if (el === 'O') {
        return 'O_pbe_v1.2.uspp.F.UPF';
    }
    if (['N','P','As','Sb','Bi','F','Ne','Ar','Kr','Xe','He','S','Se','Te'].indexOf(el) >= 0) {
        return el + '.pbe-n-kjpaw_psl.1.0.0.UPF';
    }
    return el + '.pbe-dn-kjpaw_psl.1.0.0.UPF';
}

function __guessPseudoFilename(element, opts) {
    var scalar = __guessPseudoFilenameScalar(element);
    if (opts && opts.fullRel) return __scalarPseudoToFullRel(scalar);
    return scalar;
}

window.pwGenNoncolinActive = function pwGenNoncolinActive() {
    if (window.typeMagnetisme === 'non_colin') return true;
    if (window.__cifTypeMagnetisme === 'non_colin') return true;
    var ns = (document.getElementById('nspin') || {}).value;
    if (String(ns || '').trim() === '4') return true;
    var cifNs = document.getElementById('cif_nspin') || document.getElementById('conversion_cif_nspin');
    if (cifNs && String(cifNs.value || '').trim() === '4') return true;
    var r = document.querySelector('input[name="pw_gen_type_mag"]:checked');
    if (r && r.value === 'non_colin') return true;
    var r2 = document.querySelector('input[name="type_magnetisme"]:checked');
    if (r2 && r2.value === 'non_colin') return true;
    var r3 = document.querySelector('input[name="cif_type_mag"]:checked');
    if (r3 && r3.value === 'non_colin') return true;
    return false;
};

window.cifNoncolinActive = window.pwGenNoncolinActive;

window.pwGenScalarToFullRel = __scalarPseudoToFullRel;

window.pwGenFrPseudoDir = function pwGenFrPseudoDir() {
    var cfg = window.QE_CONFIG || {};
    if (cfg.PSEUDO_FR_DIR) return cfg.PSEUDO_FR_DIR;
    var base = cfg.PSEUDO_DIR || ((typeof window.qeProjectRoot === 'function' && window.qeProjectRoot()) ? window.qeProjectRoot() + '/pseudos/PBE' : '');
    if (/\/PBE\/?$/i.test(base)) return base.replace(/\/PBE\/?$/i, '/PBE_FR');
    if (/\/pseudos\/?$/i.test(base)) return base.replace(/\/?$/, '') + '/PBE_FR';
    return String(base).replace(/\/?$/, '') + '_FR';
};

window.pwGenUpgradeAtomicSpeciesText = function pwGenUpgradeAtomicSpeciesText(text) {
    if (!text || typeof text !== 'string') return text;
    var lines = text.split(/\r?\n/);
    var inBlock = false;
    for (var i = 0; i < lines.length; i++) {
        if (/^\s*ATOMIC_SPECIES/i.test(lines[i])) { inBlock = true; continue; }
        if (inBlock && /^\s*ATOMIC_POSITIONS/i.test(lines[i])) break;
        if (!inBlock) continue;
        var parts = lines[i].trim().split(/\s+/);
        if (parts.length >= 3 && /\.upf$/i.test(parts[parts.length - 1])) {
            parts[parts.length - 1] = __scalarPseudoToFullRel(parts[parts.length - 1]);
            lines[i] = '  ' + parts.join('  ');
        }
    }
    return lines.join('\n');
};

/**
 * BASE DE DONNÉES DES PSEUDO-POTENTIELS
 */
const PSEUDOS_DATABASE = {
    'H': { mass: 1.008, pseudo: 'H.pbe-rrkjus_psl.1.0.0.UPF' },
    'He': { mass: 4.003, pseudo: 'He.pbe-rrkjus_psl.1.0.0.UPF' },
    'Li': { mass: 6.941, pseudo: 'Li.pbe-s-rrkjus_psl.1.0.0.UPF' },
    'Be': { mass: 9.012, pseudo: 'Be.pbe-s-rrkjus_psl.1.0.0.UPF' },
    'B': { mass: 10.811, pseudo: 'B.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'C': { mass: 12.011, pseudo: 'C.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'N': { mass: 14.007, pseudo: 'N.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'O': { mass: 15.999, pseudo: 'O_pbe_v1.2.uspp.F.UPF' },
    'F': { mass: 18.998, pseudo: 'F.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'Ne': { mass: 20.180, pseudo: 'Ne.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'Na': { mass: 22.990, pseudo: 'Na.pbe-s-rrkjus_psl.1.0.0.UPF' },
    'Mg': { mass: 24.305, pseudo: 'Mg.pbe-s-rrkjus_psl.1.0.0.UPF' },
    'Al': { mass: 26.982, pseudo: 'Al.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'Si': { mass: 28.085, pseudo: 'Si.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'P': { mass: 30.974, pseudo: 'P.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'S': { mass: 32.065, pseudo: 'S.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'Cl': { mass: 35.453, pseudo: 'Cl.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'Ar': { mass: 39.948, pseudo: 'Ar.pbe-n-rrkjus_psl.1.0.0.UPF' },
    'K': { mass: 39.098, pseudo: 'K.pbe-s-rrkjus_psl.1.0.0.UPF' },
    'Ca': { mass: 40.078, pseudo: 'Ca.pbe-s-rrkjus_psl.1.0.0.UPF' },
    'Sc': { mass: 44.956, pseudo: 'Sc.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Ti': { mass: 47.867, pseudo: 'Ti.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'V': { mass: 50.942, pseudo: 'V.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Cr': { mass: 51.996, pseudo: 'Cr.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Mn': { mass: 54.938, pseudo: 'Mn.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Fe': { mass: 55.845, pseudo: 'Fe.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Co': { mass: 58.933, pseudo: 'Co.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Ni': { mass: 58.693, pseudo: 'Ni.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Cu': { mass: 63.546, pseudo: 'Cu.pbe-dn-rrkjus_psl.1.0.0.UPF' },
    'Zn': { mass: 65.380, pseudo: 'Zn.pbe-dn-rrkjus_psl.1.0.0.UPF' },
    'Ga': { mass: 69.723, pseudo: 'Ga.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'Ge': { mass: 72.640, pseudo: 'Ge.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'As': { mass: 74.922, pseudo: 'As.pbe-n-kjpaw_psl.1.0.0.UPF' },
    'Se': { mass: 78.960, pseudo: 'Se.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'Br': { mass: 79.904, pseudo: 'Br.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'Kr': { mass: 83.798, pseudo: 'Kr.pbe-n-kjpaw_psl.1.0.0.UPF' },
    'Rb': { mass: 85.468, pseudo: 'Rb.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Sr': { mass: 87.620, pseudo: 'Sr.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Y': { mass: 88.906, pseudo: 'Y.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Zr': { mass: 91.224, pseudo: 'Zr.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Nb': { mass: 92.906, pseudo: 'Nb.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Mo': { mass: 95.960, pseudo: 'Mo.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Tc': { mass: 98.000, pseudo: 'Tc.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Ru': { mass: 101.070, pseudo: 'Ru.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Rh': { mass: 102.906, pseudo: 'Rh.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Pd': { mass: 106.420, pseudo: 'Pd.pbe-d-rrkjus_psl.1.0.0.UPF' },
    'Ag': { mass: 107.868, pseudo: 'Ag.pbe-d-rrkjus_psl.1.0.0.UPF' },
    'Cd': { mass: 112.411, pseudo: 'Cd.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'In': { mass: 114.818, pseudo: 'In.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'Sn': { mass: 118.710, pseudo: 'Sn.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'Sb': { mass: 121.760, pseudo: 'Sb.pbe-n-kjpaw_psl.1.0.0.UPF' },
    'Te': { mass: 127.600, pseudo: 'Te.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'I': { mass: 126.905, pseudo: 'I.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'Xe': { mass: 131.293, pseudo: 'Xe.pbe-n-kjpaw_psl.1.0.0.UPF' },
    'Cs': { mass: 132.906, pseudo: 'Cs.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Ba': { mass: 137.327, pseudo: 'Ba.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'La': { mass: 138.905, pseudo: 'La.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Ce': { mass: 140.116, pseudo: 'Ce.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Pr': { mass: 140.908, pseudo: 'Pr.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Nd': { mass: 144.242, pseudo: 'Nd.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Sm': { mass: 150.360, pseudo: 'Sm.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Eu': { mass: 151.964, pseudo: 'Eu.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Gd': { mass: 157.250, pseudo: 'Gd.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Tb': { mass: 158.925, pseudo: 'Tb.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Dy': { mass: 162.500, pseudo: 'Dy.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Ho': { mass: 164.930, pseudo: 'Ho.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Er': { mass: 167.259, pseudo: 'Er.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Tm': { mass: 168.934, pseudo: 'Tm.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Yb': { mass: 173.040, pseudo: 'Yb.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Lu': { mass: 174.967, pseudo: 'Lu.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Hf': { mass: 178.492, pseudo: 'Hf.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Ta': { mass: 180.948, pseudo: 'Ta.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'W': { mass: 183.840, pseudo: 'W.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Re': { mass: 186.207, pseudo: 'Re.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Os': { mass: 190.230, pseudo: 'Os.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Ir': { mass: 192.217, pseudo: 'Ir.pbe-spn-rrkjus_psl.1.0.0.UPF' },
    'Pt': { mass: 195.084, pseudo: 'Pt.pbe-d-rrkjus_psl.1.0.0.UPF' },
    'Au': { mass: 196.967, pseudo: 'Au.pbe-d-rrkjus_psl.1.0.0.UPF' },
    'Hg': { mass: 200.592, pseudo: 'Hg.pbe-dn-rrkjus_psl.1.0.0.UPF' },
    'Tl': { mass: 204.383, pseudo: 'Tl.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'Pb': { mass: 207.200, pseudo: 'Pb.pbe-dn-kjpaw_psl.1.0.0.UPF' },
    'Bi': { mass: 208.980, pseudo: 'Bi.pbe-dn-kjpaw_psl.1.0.0.UPF' }
};

function __lookupPseudoData(element, opts) {
    var el = __normalizeElementSymbol(element);
    if (!el) return null;
    var useFr = opts && opts.fullRel;
    if (PSEUDOS_DATABASE[el]) {
        var row = PSEUDOS_DATABASE[el];
        return {
            mass: row.mass,
            pseudo: useFr ? __scalarPseudoToFullRel(row.pseudo) : row.pseudo,
            estimated: false
        };
    }
    var mass = ELEMENT_MASSES[el];
    if (mass == null) return null;
    return { mass: mass, pseudo: __guessPseudoFilename(el, opts), estimated: true };
}

// Stockage global
let atomicSpeciesGlobal = '';

/**
 * Créer la section pour les noms des éléments APRÈS ntyp
 * DYNAMIQUE en fonction de ntyp
 */
function creerSectionNomElements() {
    console.log('⚛️ Création de la section noms d\'éléments...');
    
    // Chercher le champ ntyp
    const ntypInput = document.getElementById('ntyp');
    if (!ntypInput) {
        console.warn('⚠️ Champ ntyp non trouvé');
        return;
    }
    
    // Ajouter un écouteur au changement de ntyp
    ntypInput.addEventListener('change', reconstruireChampElements);
    ntypInput.addEventListener('input', reconstruireChampElements);
    
    // Créer la section initiale
    reconstruireChampElements();
    
    console.log('✅ Section noms d\'éléments créée (dynamique)');
}

/**
 * Reconstruire les champs d'éléments en fonction de ntyp
 */
function reconstruireChampElements() {
    const ntypInput = document.getElementById('ntyp');
    const ntyp = parseInt(ntypInput?.value) || 0;
    
    console.log(`🔨 reconstruireChampElements() - ntyp=${ntyp}`);
    
    if (ntyp <= 0) {
        const section = document.getElementById('section_elements');
        if (section) section.innerHTML = '';
        window.atomicSpeciesGlobal = '';
        return;
    }

    const previousElements = [];
    for (let i = 1; i <= ntyp; i++) {
        const existing = document.getElementById(`element_${i}`);
        previousElements.push(existing ? String(existing.value || '').trim() : '');
    }
    
    // Chercher le conteneur correct: section_elements (dans section_3_especes)
    let section = document.getElementById('section_elements');
    
    if (!section) {
        console.warn('⚠️ section_elements NOT FOUND - On essaie de le créer');
        section = document.createElement('div');
        section.id = 'section_elements';
        
        // L'insérer dans section_3_especes s'il existe
        const container3 = document.getElementById('section_3_especes');
        if (container3) {
            container3.appendChild(section);
        } else {
            console.error('❌ section_3_especes NOT FOUND');
            return;
        }
    }
    
    // Construire les champs d'entrée dynamiquement (compact → ATOMIC_SPECIES plus tôt)
    let champsHTML = `<h4 style="color: #6a1b9a; margin: 0 0 8px 0; font-size: 0.98em;">Noms des éléments (${ntyp})</h4>`;
    champsHTML += `<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(100px, 1fr)); gap: 8px; margin-bottom: 10px;">`;
    
    for (let i = 1; i <= ntyp; i++) {
        champsHTML += `
            <div>
                <label style="font-weight: 600; color: #6a1b9a; display: block; margin-bottom: 3px; font-size: 0.88em;">Élément ${i}</label>
                <input type="text" id="element_${i}" placeholder="Ex: Ba" 
                       value="${previousElements[i - 1] || ''}"
                       onchange="genererAtomicSpecies()" oninput="genererAtomicSpecies()"
                       style="width: 100%; padding: 6px 8px; border: 1px solid #9c27b0; border-radius: 5px;">
            </div>
        `;
    }
    
    champsHTML += `</div>`;
    
    // ATOMIC_SPECIES — bloc compact (peu d'espace réservé vide)
    champsHTML += `
        <div style="margin-top: 8px; padding: 10px 12px; background: #f8f9fa; border-radius: 8px; border: 1px solid #9c27b0;">
            <h3 style="color: #6a1b9a; margin: 0 0 6px 0; font-size: 0.98em;">
                ATOMIC_SPECIES (Format QE)
            </h3>
            
            <div id="atomic_species_format" style="
                font-family: 'Courier New', Consolas, monospace;
                font-size: 0.9em;
                line-height: 1.45;
                background: white;
                padding: 8px 10px;
                border-radius: 6px;
                border: 1px solid #ddd;
                color: #000;
                overflow-x: auto;
                white-space: pre;
                min-height: 2.2em;
                max-height: 140px;
                overflow-y: auto;
            "><span style="color: #999;">En attente des éléments…</span></div>
            
            <div style="margin-top: 8px; display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
                <button id="copy_button" onclick="copierAtomicSpecies()" style="
                    padding: 6px 14px;
                    background: #9c27b0;
                    color: white;
                    border: none;
                    border-radius: 6px;
                    cursor: pointer;
                    font-weight: 600;
                    font-size: 0.88em;
                " onmouseover="this.style.background='#7b1fa2'" onmouseout="this.style.background='#9c27b0'">
                    Copier ATOMIC_SPECIES
                </button>
                <span id="copy_status" style="color: #4caf50; font-weight: 600; font-size: 0.88em;"></span>
            </div>
            
            <div id="pseudos_list" style="
                margin-top: 8px;
                padding: 6px 8px;
                background: #fff3e0;
                border-radius: 5px;
                border-left: 3px solid #ff9800;
                font-family: monospace;
                font-size: 0.85em;
                line-height: 1.4;
                color: #333;
                display: none;
            "></div>
        </div>
    `;
    
    section.innerHTML = champsHTML;

    if (previousElements.some(function (value) { return value; })) {
        genererAtomicSpecies();
    }
    
    console.log(`✅ ${ntyp} champs d'éléments créés dans section_elements`);

    try {
        if (typeof window.pwGenRefreshHubbardPanel === 'function') {
            window.pwGenRefreshHubbardPanel();
        } else if (typeof window.pwGenRefreshHubbardIfMagnetic === 'function') {
            window.pwGenRefreshHubbardIfMagnetic();
        }
    } catch (_eHbNtyp) {}
}

/**
 * Générer ATOMIC_SPECIES à partir des éléments
 * Cherche dans element_${i} OU elem_${i}
 */
function genererAtomicSpecies() {
    const ntypInput = document.getElementById('ntyp');
    const ntyp = parseInt(ntypInput?.value) || 0;
    
    console.log(`\n🔧 genererAtomicSpecies() - ntyp=${ntyp}`);
    
    // Récupérer tous les éléments
    // IMPORTANT: Chercher dans element_${i} (entrée manuelle) OU elem_${i} (selects table positions)
    const elements = [];
    for (let i = 1; i <= ntyp; i++) {
        // Chercher d'abord dans element_${i} (champs de la section des éléments)
        let value = document.getElementById(`element_${i}`)?.value.trim() || '';
        
        // Si vide, chercher dans elem_${i} (selects de la table positions)
        if (!value) {
            value = document.getElementById(`elem_${i}`)?.value.trim() || '';
            if (value) {
                console.log(`  element_${i}: VIDE → récupéré depuis elem_${i}: ${value}`);
            }
        } else {
            console.log(`  element_${i}: ${value}`);
        }
        
        if (value) {
            elements.push(__normalizeElementSymbol(value));
        }
    }
    
    console.log(`Éléments trouvés: [${elements.join(', ')}]`);

    if (elements.length > 0) {
        const pseudoWarning = document.getElementById('pseudo_warning_atomic_species');
        if (pseudoWarning) {
            pseudoWarning.remove();
        }
    }
    
    const pseudosList_div = document.getElementById('pseudos_list');
    const atomicSpeciesDiv = document.getElementById('atomic_species_format');
    
    if (elements.length === 0) {
        console.warn('⚠️ Aucun élément trouvé!');
        if (atomicSpeciesDiv) {
            atomicSpeciesDiv.innerHTML = '<span style="color: #999;">En attente des éléments...</span>';
        }
        window.atomicSpeciesGlobal = '';
        return;
    }
    
    // Générer la liste des pseudo-potentiels
    let pseudosList = '';
    let atomicSpecies = '';
    let allFound = true;
    
    const useFrPseudos = typeof window.pwGenNoncolinActive === 'function' && window.pwGenNoncolinActive();

    elements.forEach((element) => {
        const data = __lookupPseudoData(element, { fullRel: useFrPseudos });
        if (data) {
            const est = data.estimated ? ' <em style="color:#e65100;">(pseudo estimé)</em>' : '';
            pseudosList += `<div><strong>${element}</strong> ${data.mass.toFixed(3)} ${data.pseudo}${est}</div>`;
            const mass = data.mass.toFixed(3);
            atomicSpecies += `${element.padEnd(2)}   ${mass.padStart(8)}  ${data.pseudo}\n`;
            if (data.estimated) allFound = false;
        } else {
            pseudosList += `<div style="color: #d32f2f;"><strong>${element}</strong> <em>(symbole ou masse inconnue)</em></div>`;
            allFound = false;
        }
    });
    
    // Mise à jour DOM
    if (pseudosList_div) {
        pseudosList_div.innerHTML = pseudosList;
        
        // Ajouter le résumé
        const summary = document.createElement('div');
        summary.style.cssText = 'margin-top: 10px; padding-top: 10px; border-top: 1px solid #ff9800; color: #e65100; font-weight: bold;';
        summary.innerHTML = `✅ ${elements.length} élément(s) détecté(s)${allFound ? ' ✓' : ' ⚠️'}`;
        pseudosList_div.appendChild(summary);
        
        // ⭐ TOUJOURS AFFICHER pour que l'utilisateur vérifie avant génération
        pseudosList_div.style.display = 'block';
    }
    
    // Stocker le contenu globalement
    window.atomicSpeciesGlobal = atomicSpecies.trim();

    // Synchroniser le textarea principal utilisé par genererInput()
    const taMain = document.getElementById('atomic_species');
    if (taMain && window.atomicSpeciesGlobal) {
        taMain.value = window.atomicSpeciesGlobal;
    }

    // Rafraîchir le panneau DFT+U dès que les espèces sont connues
    try {
        if (typeof window.pwGenRefreshHubbardPanel === 'function') {
            window.pwGenRefreshHubbardPanel();
        } else if (typeof window.pwGenRefreshHubbardIfMagnetic === 'function') {
            window.pwGenRefreshHubbardIfMagnetic();
        }
    } catch (_eHb) {}

    if (typeof window.onSpeciesDetectedForRecommendations === 'function') {
        try {
            window.onSpeciesDetectedForRecommendations(elements, elements.join(''));
        } catch (_eRec) {}
    }
    
    console.log('🔍 DEBUG - Vérification atomicSpeciesGlobal:');
    console.log('  Type:', typeof window.atomicSpeciesGlobal);
    console.log('  Longueur:', window.atomicSpeciesGlobal.length);
    console.log('  Contenu:');
    console.log(window.atomicSpeciesGlobal);
    console.log('  window.atomicSpeciesGlobal:', window.atomicSpeciesGlobal);
    
    // ⭐ AFFICHER ATOMIC_SPECIES dans une section visible
    if (atomicSpeciesDiv) {
        // Créer un affichage formaté et visible
        atomicSpeciesDiv.innerHTML = `
            <div style="background: #fff3e0; padding: 15px; border-radius: 8px; border-left: 4px solid #ff9800; margin-top: 15px;">
                <h4 style="color: #e65100; margin: 0 0 10px 0; font-size: 1.1em;">
                    📋 ATOMIC_SPECIES Généré (sera copié dans l'input):
                </h4>
                <pre style="background: #263238; color: #aed581; padding: 15px; border-radius: 5px; overflow-x: auto; font-family: 'Courier New', monospace; font-size: 0.95em; margin: 0;">${window.atomicSpeciesGlobal}</pre>
                <div id="pseudo_warning_atomic_species" style="background: #fff8e1; border: 1px solid #f9a825; color: #7a4d00; border-radius: 6px; padding: 10px 12px; margin-top: 12px; font-size: 0.9em; line-height: 1.5;">
                    ⚠️ Vérifiez et remplacez le pseudopotentiel par un fichier valide pour votre calcul réel (ex. <code>Si.pbe-n-kjpaw_psl.1.0.0.UPF</code> ou un pseudopotentiel adapté à votre méthode et à votre ensemble de données).
                </div>
                <small style="color: #666; display: block; margin-top: 10px;">
                    💡 Le pseudo affiché ci-dessus est un défaut auto-généré. Mettez à jour la ligne avec un pseudopotentiel valable pour votre calcul.
                </small>
            </div>
        `;
        console.log('  ✓ Affichage VISIBLE dans atomic_species_format');
    } else {
        console.warn('  ❌ atomic_species_format NOT FOUND');
    }
    
    // AJOUTER: Vérifier les pseudos manquants
    if (typeof creerSectionPseudosMissing === 'function') {
        console.log('🔍 Vérification des pseudos manquants...');
        creerSectionPseudosMissing();
    }
}

/**
 * Copier ATOMIC_SPECIES dans le presse-papiers
 */
function copierAtomicSpecies() {
    console.log('📋 Tentative de copie. Contenu:', window.atomicSpeciesGlobal);
    
    if (!window.atomicSpeciesGlobal || window.atomicSpeciesGlobal.trim() === '') {
        alert('❌ Aucun contenu à copier.\n\nVeuillez:\n1. Entrer ntyp\n2. Entrer les noms des éléments (Ba, Ti, O...)\n3. Les pseudo-potentiels vont s\'afficher automatiquement');
        return;
    }
    
    // Récupérer le bouton
    const btn = document.getElementById('copy_button');
    
    try {
        // Essayer Clipboard API
        if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
            navigator.clipboard.writeText(window.atomicSpeciesGlobal).then(() => {
                console.log('✅ Copie réussie via Clipboard API');
                afficherSuccess(btn);
            }).catch((err) => {
                console.warn('⚠️ Clipboard API échouée:', err);
                fallbackCopy(window.atomicSpeciesGlobal, btn);
            });
        } else {
            console.warn('⚠️ Clipboard API non disponible');
            fallbackCopy(window.atomicSpeciesGlobal, btn);
        }
    } catch (err) {
        console.error('❌ Erreur:', err);
        fallbackCopy(window.atomicSpeciesGlobal, btn);
    }
}

/**
 * Afficher message de succès
 */
function afficherSuccess(btn) {
    if (!btn) return;
    
    const originalText = btn.textContent;
    btn.textContent = '✅ Copié!';
    btn.style.background = '#4caf50';
    
    // Afficher aussi dans le span de statut
    const statusSpan = document.getElementById('copy_status');
    if (statusSpan) {
        statusSpan.textContent = '✅ Copié dans le presse-papiers!';
        setTimeout(() => {
            statusSpan.textContent = '';
        }, 3000);
    }
    
    setTimeout(() => {
        btn.textContent = originalText;
        btn.style.background = '#9c27b0';
    }, 2000);
}

/**
 * Fallback: Copie manuelle
 */
function fallbackCopy(content, btn) {
    try {
        const textarea = document.createElement('textarea');
        textarea.value = content;
        textarea.style.position = 'fixed';
        textarea.style.top = '0';
        textarea.style.left = '0';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        
        textarea.focus();
        textarea.select();
        
        const success = document.execCommand('copy');
        document.body.removeChild(textarea);
        
        if (success) {
            console.log('✅ Copie réussie via fallback');
            afficherSuccess(btn);
            alert('✅ ATOMIC_SPECIES copié avec succès!');
        } else {
            alert('❌ Erreur: Impossible de copier');
        }
    } catch (err) {
        console.error('❌ Erreur fallback:', err);
        alert('❌ Erreur lors de la copie: ' + err.message);
    }
}

/**
 * Initialiser la section des noms d'éléments
 */
function initialiserNomElements() {
    console.log('🔧 Initialisation noms d\'éléments...');
    
    setTimeout(() => {
        creerSectionNomElements();
        console.log('✅ Noms d\'éléments initialisés');
    }, 300);
}

// Exécuter au chargement
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialiserNomElements);
} else {
    initialiserNomElements();
}

console.log('✅ Script noms éléments et pseudo-potentiels (V3) chargé');

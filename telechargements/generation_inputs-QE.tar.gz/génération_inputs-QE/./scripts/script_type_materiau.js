// ═══════════════════════════════════════════════════════════════════════════
// AJOUT DU CHAMP "TYPE DE MATÉRIAU"
// Pour sélection explicite de la structure cristalline
// ═══════════════════════════════════════════════════════════════════════════

function _tTm(key) {
    return (typeof window.t === 'function') ? window.t(key) : key;
}

function formaterIbravPourAffichage(ibrav) {
    if (!Array.isArray(ibrav) || !ibrav.length) return '—';
    return ibrav.map(function (v) { return String(v); }).join(', ');
}

function parserSymbolesDepuisFormule(formule) {
    if (!formule || typeof formule !== 'string') return [];
    const matches = String(formule).match(/[A-Z][a-z]?\d*/g) || [];
    const symbols = [];
    matches.forEach(function (token) {
        const clean = token.replace(/\d+$/g, '');
        if (clean && symbols.indexOf(clean) === -1) symbols.push(clean);
    });
    return symbols;
}

function remplirElementsDepuisMateriauSelectionne(typeId) {
    const ntypInput = document.getElementById('ntyp');
    const ntyp = parseInt(ntypInput && ntypInput.value, 10) || 0;
    if (!ntyp || !typeId) return;

    const structure = BASE_STRUCTURES[typeId];
    if (!structure) return;

    let candidates = [];
    const materiauNameEl = document.getElementById('materiau_name') || document.getElementById('system_name');
    if (materiauNameEl && String(materiauNameEl.value || '').trim()) {
        candidates = parserSymbolesDepuisFormule(materiauNameEl.value);
    }
    if (!candidates.length && Array.isArray(structure.exemples) && structure.exemples.length) {
        candidates = parserSymbolesDepuisFormule(structure.exemples[0]);
    }
    if (!candidates.length && structure.formule) {
        candidates = parserSymbolesDepuisFormule(structure.formule);
    }
    if (!candidates.length) return;

    const limit = Math.min(ntyp, candidates.length);
    for (let i = 1; i <= ntyp; i++) {
        const el = document.getElementById('element_' + i);
        if (el && !String(el.value || '').trim() && i <= limit) {
            el.value = candidates[i - 1];
        }
    }
    if (typeof genererAtomicSpecies === 'function') {
        genererAtomicSpecies();
    }
}

/**
 * Injecter les styles CSS
 */
function injecterStylesTypeMatériau() {
    if (document.getElementById('styles-type-materiau')) {
        return; // Déjà injecté
    }
    
    const style = document.createElement('style');
    style.id = 'styles-type-materiau';
    style.textContent = `
        /* Animations */
        @keyframes slideIn {
            from { transform: translateX(400px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(400px); opacity: 0; }
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        
        @keyframes glow {
            0%, 100% { box-shadow: 0 0 5px rgba(33, 150, 243, 0.5); }
            50% { box-shadow: 0 0 20px rgba(33, 150, 243, 0.8); }
        }
        
        /* Select Type de Matériau */
        #type_materiau {
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        #type_materiau:hover {
            border-color: #2196f3;
            box-shadow: 0 0 10px rgba(33, 150, 243, 0.3);
        }
        
        #type_materiau:focus {
            outline: none;
            border-color: #1976d2;
            box-shadow: 0 0 15px rgba(25, 118, 210, 0.5);
        }
        
        #type_materiau optgroup {
            font-weight: bold;
            font-size: 1.05em;
            color: #1976d2;
            background: #f5f5f5;
            padding: 8px 0;
        }
        
        #type_materiau option {
            padding: 8px 15px;
            color: #333;
            background: white;
        }
        
        #info_type_materiau {
            animation: slideIn 0.3s ease-out;
        }

        #classe_electronique {
            transition: all 0.3s ease;
            cursor: pointer;
        }

        #classe_electronique:hover {
            border-color: #7c3aed;
            box-shadow: 0 0 10px rgba(124, 58, 237, 0.3);
        }

        #classe_electronique:focus {
            outline: none;
            border-color: #6d28d9;
            box-shadow: 0 0 15px rgba(109, 40, 217, 0.5);
        }
        
        .badge-nouveau {
            display: inline-block;
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a6f 100%);
            color: white;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.75em;
            font-weight: bold;
            margin-left: 8px;
            animation: pulse 2s infinite;
        }
    `;
    
    document.head.appendChild(style);
    console.log('✅ Styles Type de Matériau injectés');
}

/**
 * Options HTML pour le sélecteur de classe électronique.
 */
function obtenirOptionsClasseElectroniqueHTML() {
    var html = '<option value="" data-i18n="sec1.elec_auto">' + _tTm('sec1.elec_auto') + '</option>';
    var classes = (typeof MATERIAL_CLASSES !== 'undefined' && MATERIAL_CLASSES.length)
        ? MATERIAL_CLASSES
        : [
            { id: 'metal', name: 'Métal' },
            { id: 'insulator', name: 'Isolant' },
            { id: 'semiconductor', name: 'Semi-conducteur' },
            { id: 'mag_metal', name: 'Métal magnétique' },
            { id: 'mag_insulator', name: 'Isolant magnétique' },
            { id: 'rare_earth', name: 'Terre rare / f-electron' },
            { id: 'organic', name: 'Organique / moléculaire' },
            { id: 'unknown', name: 'Non déterminé (défaut prudent)' }
        ];
    classes.forEach(function (c) {
        if (!c || !c.id || c.id === 'unknown') return;
        var label = c.name || c.id;
        if (c.description) label += ' — ' + c.description;
        html += '<option value="' + c.id + '">' + label + '</option>';
    });
    html += '<option value="unknown" data-i18n="sec1.elec_unknown">' + _tTm('sec1.elec_unknown') + '</option>';
    return html;
}

/**
 * Classe électronique forcée manuellement (null = mode auto).
 */
function obtenirClasseElectroniqueManuelle() {
    var sel = document.getElementById('classe_electronique');
    if (!sel) return null;
    var v = String(sel.value || '').trim();
    return v || null;
}

/**
 * Gestion du changement de classe électronique (forçage manuel).
 */
function changerClasseElectronique() {
    var typeSel = document.getElementById('type_materiau');
    var typeId = typeSel ? typeSel.value : '';
    console.log('\n⚡ Changement classe électronique:', obtenirClasseElectroniqueManuelle() || 'auto');
    if (typeId) {
        appliquerProfilConvergencePourType(typeId);
    } else if (obtenirClasseElectroniqueManuelle()) {
        var calcTypeEl = document.getElementById('calc_type');
        var calcType = (calcTypeEl && calcTypeEl.value) || 'scf';
        var profile = (typeof getConvergenceProfile === 'function')
            ? getConvergenceProfile(obtenirClasseElectroniqueManuelle(), calcType) : null;
        if (profile) {
            afficherPanneauConvergencePourType(obtenirClasseElectroniqueManuelle(), calcType, profile);
        }
    }
}

/**
 * HTML statique pour type de matériau + classe électronique (intégré au Tab 1 restructuré).
 */
window.buildTypeMateriauFieldsHTML = function buildTypeMateriauFieldsHTML() {
    if (typeof obtenirListeTypesMateriaux !== 'function' || typeof BASE_STRUCTURES === 'undefined') {
        return '<p style="color:#64748b;font-size:0.9em;margin:12px 0 0;">Chargement des types de matériau…</p>';
    }

    var categories = obtenirListeTypesMateriaux();
    var optionsHTML = '<option value="" data-i18n="sec1.type_select">' + _tTm('sec1.type_select') + '</option>';
    for (var categorie in categories) {
        if (!Object.prototype.hasOwnProperty.call(categories, categorie)) continue;
        optionsHTML += '<optgroup label="' + categorie + '">';
        categories[categorie].forEach(function (typeId) {
            var structure = BASE_STRUCTURES[typeId];
            if (structure) {
                var ibravText = formaterIbravPourAffichage(structure.ibrav);
                optionsHTML += '<option value="' + typeId + '">' + structure.nom + ' (ibrav: ' + ibravText + ')</option>';
            }
        });
        optionsHTML += '</optgroup>';
    }

    return ''
        + '<div class="sec1-type-materiau-fields">'
        + '<div class="form-group" style="margin-bottom:0;">'
        + '<label data-i18n="sec1.type_label" for="type_materiau">' + _tTm('sec1.type_label') + '</label>'
        + '<select id="type_materiau" class="sec1-type-materiau-select" onchange="changerTypeMatériau()">'
        + optionsHTML
        + '</select>'
        + '<div id="info_type_materiau" class="sec1-type-materiau-info" style="display:none;">'
        + '<div id="info_type_description"></div>'
        + '<div id="info_type_formule" style="margin-top:5px;font-weight:bold;"></div>'
        + '<div id="info_type_exemples" style="margin-top:5px;font-size:0.9em;color:#475569;"></div>'
        + '</div></div>'
        + '<div class="form-group" style="margin-bottom:0;">'
        + '<label data-i18n="sec1.elec_label" for="classe_electronique">' + _tTm('sec1.elec_label') + '</label>'
        + '<select id="classe_electronique" class="sec1-elec-select" onchange="changerClasseElectronique()">'
        + obtenirOptionsClasseElectroniqueHTML()
        + '</select>'
        + '<div id="info_classe_electronique" class="sec1-elec-info">'
        + _tTm('sec1.elec_auto')
        + '</div></div></div>';
};

function _bindTypeMateriauEvents() {
    var nameEl = document.getElementById('materiau_name');
    if (nameEl && !nameEl.dataset.convergenceBound) {
        nameEl.dataset.convergenceBound = '1';
        nameEl.addEventListener('input', function () {
            var typeSel = document.getElementById('type_materiau');
            if (typeSel && typeSel.value && typeof appliquerProfilConvergencePourType === 'function') {
                appliquerProfilConvergencePourType(typeSel.value);
            }
        });
    }
    ecouterChangementsIbrav();
}

/**
 * Garantit les champs type matériau dans #sec1_type_materiau_block (après restructuration Tab 1).
 */
window.ensureTypeMateriauFields = function ensureTypeMateriauFields() {
    injecterStylesTypeMatériau();
    var block = document.getElementById('sec1_type_materiau_block');
    if (!block) return;

    if (!document.getElementById('type_materiau')) {
        if (typeof window.buildTypeMateriauFieldsHTML === 'function') {
            block.innerHTML = window.buildTypeMateriauFieldsHTML();
            if (typeof window.applyI18n === 'function') {
                window.applyI18n(block);
            }
        }
    }
    _bindTypeMateriauEvents();
};

/**
 * Ajouter le champ "Type de Matériau" (repli si Tab 1 non restructuré).
 */
function ajouterChampTypeMatériau() {
    injecterStylesTypeMatériau();
    var block = document.getElementById('sec1_type_materiau_block');
    if (block) {
        window.ensureTypeMateriauFields();
        return;
    }

    var materiauxInput = document.getElementById('materiau_name');
    if (!materiauxInput) {
        return;
    }

    if (document.getElementById('type_materiau')) {
        if (!document.getElementById('classe_electronique')) {
            var existingType = document.getElementById('type_materiau');
            var existingGroup = existingType.closest('.form-group') || existingType.parentElement;
            if (existingGroup && existingGroup.parentElement) {
                ajouterChampClasseElectronique(existingGroup.parentElement, existingGroup.nextSibling);
            }
        }
        _bindTypeMateriauEvents();
        return;
    }

    var typeDiv = document.createElement('div');
    typeDiv.className = 'form-group';
    typeDiv.style.cssText = 'margin-bottom: 20px;';
    if (typeof window.buildTypeMateriauFieldsHTML === 'function') {
        typeDiv.innerHTML = window.buildTypeMateriauFieldsHTML();
        var materiauxParent = materiauxInput.closest('.form-group') || materiauxInput.parentElement;
        if (materiauxParent && materiauxParent.parentElement) {
            materiauxParent.parentElement.appendChild(typeDiv);
        }
    }
    _bindTypeMateriauEvents();
};

/**
 * Injecte le sélecteur « Classe électronique » juste après le type de structure.
 */
function ajouterChampClasseElectronique(parentEl, insertBeforeNode) {
    if (!parentEl || document.getElementById('classe_electronique')) return;

    var classeDiv = document.createElement('div');
    classeDiv.className = 'form-group';
    classeDiv.style.cssText = 'margin-bottom: 20px;';
    classeDiv.innerHTML = ''
        + '<label style="display: block; font-weight: bold; margin-bottom: 8px; color: #6d28d9;">'
        + '⚡ Classe électronique (convergence QE):'
        + '</label>'
        + '<select id="classe_electronique" onchange="changerClasseElectronique()" style="'
        + 'width: 100%; padding: 12px; border: 2px solid #7c3aed; border-radius: 5px; font-size: 1em; background: white;">'
        + obtenirOptionsClasseElectroniqueHTML()
        + '</select>'
        + '<div id="info_classe_electronique" style="margin-top: 8px; font-size: 0.88em; color: #5b21b6;">'
        + 'Laissez <strong>Auto</strong> pour déduire la classe depuis le type de structure et la formule, '
        + 'ou forcez une classe (ex. terre rare, organique).'
        + '</div>';

    if (insertBeforeNode) {
        parentEl.insertBefore(classeDiv, insertBeforeNode);
    } else {
        parentEl.appendChild(classeDiv);
    }
    console.log('✅ Champ Classe électronique créé');
}

/**
 * Gestion du changement de type de matériau
 */
function changerTypeMatériau() {
    const typeSelect = document.getElementById('type_materiau');
    const typeId = typeSelect.value;
    
    console.log(`\n🔄 Changement de type: ${typeId}`);
    
    if (!typeId) {
        // Cacher l'info
        document.getElementById('info_type_materiau').style.display = 'none';
        return;
    }
    
    const structure = BASE_STRUCTURES[typeId];
    if (!structure) {
        console.error(`❌ Structure non trouvée: ${typeId}`);
        return;
    }
    
    // Afficher les informations
    const infoDiv = document.getElementById('info_type_materiau');
    const descDiv = document.getElementById('info_type_description');
    const formDiv = document.getElementById('info_type_formule');
    const exDiv = document.getElementById('info_type_exemples');
    
    descDiv.textContent = structure.description;
    formDiv.textContent = `Formule: ${structure.formule}`;
    exDiv.textContent = `Exemples: ${structure.exemples.join(', ')}`;
    
    infoDiv.style.display = 'block';
    
    // Mettre à jour ntyp si nécessaire
    const ntypInput = document.getElementById('ntyp');
    if (ntypInput && structure.ntyp.length === 1) {
        ntypInput.value = structure.ntyp[0];
        console.log(`  ✓ ntyp défini automatiquement: ${structure.ntyp[0]}`);
        
        // Déclencher l'événement
        ntypInput.dispatchEvent(new Event('input', { bubbles: true }));
    }
    
    // Calculer et remplir nat automatiquement
    const ntypValue = parseInt(ntypInput?.value) || structure.ntyp[0];
    const natCalcule = calculerNatParType(typeId, ntypValue);
    
    if (natCalcule) {
        const natInput = document.getElementById('nat');
        if (natInput) {
            natInput.value = natCalcule;
            console.log(`  ✅ nat défini automatiquement: ${natCalcule}`);
            
            // Afficher une notification
            afficherNotificationNat(structure, natCalcule);
            
            // Déclencher l'événement
            natInput.dispatchEvent(new Event('input', { bubbles: true }));
        }
    }

    const ibravInput = document.getElementById('ibrav') || document.getElementById('pw_input_ibrav');
    if (ibravInput && Array.isArray(structure.ibrav) && structure.ibrav.length) {
        const candidate = String(structure.ibrav[0]);
        if (!String(ibravInput.value || '').trim()) {
            ibravInput.value = candidate;
            console.log(`  ✓ ibrav défini automatiquement: ${candidate} (${structure.nom})`);
        }
        if (ibravInput.value !== String(candidate)) {
            ibravInput.value = candidate;
        }
        ibravInput.dispatchEvent(new Event('change', { bubbles: true }));
    }

    remplirElementsDepuisMateriauSelectionne(typeId);

    if (typeof window.reconstruirePositionsAtomiques === 'function') {
        window.reconstruirePositionsAtomiques();
    } else if (typeof reconstruirePositionsAtomiques === 'function') {
        reconstruirePositionsAtomiques();
    }
    
    // Sauvegarder le type sélectionné globalement
    window.typeMateriauSelectionne = typeId;
    
    // Vérifier la compatibilité ibrav
    verifierCompatibiliteIbrav();

    // ══ APPLIQUER LE PROFIL DE CONVERGENCE OPTIMAL ══
    appliquerProfilConvergencePourType(typeId);
}

/**
 * Espèces atomiques saisies (éléments ou ATOMIC_SPECIES).
 */
function extraireEspecesDepuisFormulaireDirect() {
    var syms = [];
    var ntyp = parseInt((document.getElementById('ntyp') || {}).value, 10) || 0;
    var i;
    for (i = 1; i <= ntyp; i++) {
        var el = document.getElementById('element_' + i);
        if (el && String(el.value || '').trim()) syms.push(String(el.value).trim());
    }
    if (syms.length) return syms;
    var ta = document.getElementById('atomic_species');
    var src = (window.atomicSpeciesGlobal && String(window.atomicSpeciesGlobal).trim())
        || (ta && String(ta.value || '').trim()) || '';
    if (src && typeof window.parseSymbolsFromAtomicSpecies === 'function') {
        return window.parseSymbolsFromAtomicSpecies(src);
    }
    return syms;
}

/**
 * Heuristique à partir des métadonnées BASE_STRUCTURES (exemples, nom, id).
 */
function detecterClasseDepuisStructureMeta(structure) {
    if (!structure) return null;
    var blob = String(structure.id || '') + ' ' + String(structure.nom || '') + ' ' + String(structure.description || '');
    if (/heusler|ferrite|spinelle|pyrochlore|garnet|ferrimagn|antiferro|magn[eé]t|ilmenite/i.test(blob)) return 'mag_insulator';
    if (/diamond|zincblende|wurtzite|iii.?v|ii.?vi|chalcopyrite|kesterite|semi|tetradymite|dichalcogenide|skutterudite/i.test(blob)) return 'semiconductor';
    if (/^fcc$|^bcc$|^hcp$|alliage|cscl|m[eé]tal|max.?phase/i.test(blob)) return 'metal';
    if (/perovskite|rutile|corundum|fluorite|rocksalt|oxyde|isolant|olivine|ruddlesden/i.test(blob)) return 'insulator';
    var ex = structure.exemples || [];
    if (ex.length && typeof detectMaterialClass === 'function') {
        return detectMaterialClass(String(ex[0]), []);
    }
    return null;
}

/**
 * Résout la classe CONVERGENCE_PROFILES : type structure → formule → métadonnées.
 * Retourne null si aucune inférence fiable (ne pas afficher « Non déterminé »).
 */
function resoudreClasseMateriauConvergence(typeId) {
    var manuelle = obtenirClasseElectroniqueManuelle();
    if (manuelle) return manuelle;

    var cls = detecterClasseDepuisTypeStructure(typeId);
    if (cls) return cls;

    var nameEl = document.getElementById('materiau_name') || document.getElementById('system_name');
    var formula = nameEl ? String(nameEl.value || '').trim() : '';
    var species = extraireEspecesDepuisFormulaireDirect();
    if (typeof detectMaterialClass === 'function' && (formula || species.length)) {
        cls = detectMaterialClass(formula, species);
        if (cls && cls !== 'unknown') return cls;
    }

    if (typeId && typeof BASE_STRUCTURES !== 'undefined' && BASE_STRUCTURES[typeId]) {
        cls = detecterClasseDepuisStructureMeta(BASE_STRUCTURES[typeId]);
        if (cls) return cls;
    }

    return null;
}

/**
 * Applique le profil de convergence optimal pour le type de matériau sélectionné.
 * Utilise CONVERGENCE_PROFILES pour déterminer les paramètres optimaux.
 */
function appliquerProfilConvergencePourType(typeId) {
    if (typeof getConvergenceProfile !== 'function') {
        console.warn('⚠️ convergence_profiles.js non chargé, impossible d\'appliquer le profil.');
        return;
    }

    var materialClass = resoudreClasseMateriauConvergence(typeId);
    if (!materialClass) {
        var hidePanel = document.getElementById('convergence_recommendations_panel');
        if (hidePanel) hidePanel.style.display = 'none';
        console.warn('⚠️ Classe matériau non résolue pour le type:', typeId);
        return;
    }

    // Déterminer le type de calcul en cours
    var calcTypeEl = document.getElementById('calc_type');
    var calcType = (calcTypeEl && calcTypeEl.value) || 'scf';

    // Appliquer type de calcul + profil matériau (source unique)
    if (typeof window.qeApplyRecommendedCalcParams === 'function') {
        window.qeApplyRecommendedCalcParams(calcType, {
            scope: 'direct',
            materialClass: materialClass
        });
        if (typeof afficherPanneauConvergencePourType === 'function') {
            var mapCt = calcType;
            if (mapCt === 'vc-md') mapCt = 'vc-relax';
            else if (mapCt === 'scf_berry' || mapCt === 'scf_born') mapCt = 'scf';
            var profile = getConvergenceProfile(materialClass, mapCt);
            if (profile) afficherPanneauConvergencePourType(materialClass, calcType, profile);
        }
        return;
    }

    // Fallback legacy
    var profile = getConvergenceProfile(materialClass, calcType);
    if (!profile) return;
    console.log('📊 Profil de convergence appliqué:', materialClass, calcType, profile);
    var champs = [
        { id: 'ecutwfc', val: profile.ecutwfc },
        { id: 'ecutrho', val: profile.ecutrho },
        { id: 'conv_thr', val: profile.conv_thr },
        { id: 'mixing_beta', val: profile.mixing_beta }
    ];
    champs.forEach(function(c) {
        var el = document.getElementById(c.id);
        if (el) {
            el.value = c.val;
            el.style.transition = 'border-color 0.5s ease, background-color 0.5s ease';
            el.style.borderColor = '#10b981';
            el.style.backgroundColor = '#f0fdf4';
            setTimeout(function() {
                el.style.borderColor = '';
                el.style.backgroundColor = '';
            }, 2000);
        }
    });
    afficherPanneauConvergencePourType(materialClass, calcType, profile);
}

/**
 * Détecte la classe de matériau (CONVERGENCE_PROFILES) à partir du type BASE_STRUCTURES.
 */
function detecterClasseDepuisTypeStructure(typeId) {
    if (!typeId) return null;
    var t = String(typeId).toLowerCase();

    var exact = {
        fcc: 'metal',
        bcc: 'metal',
        hcp: 'metal',
        diamond: 'semiconductor',
        binaire_zincblende: 'semiconductor',
        binaire_wurtzite: 'semiconductor',
        binaire_iii_v_cubic: 'semiconductor',
        binaire_iii_v_hex: 'semiconductor',
        binaire_ii_vi: 'semiconductor',
        chalcopyrite_abx2: 'semiconductor',
        delafossite_abx2: 'semiconductor',
        quaternaire_kesterite: 'semiconductor',
        binaire_rocksalt: 'insulator',
        binaire_cscl: 'metal',
        rutile: 'insulator',
        corundum: 'insulator',
        fluorite: 'insulator',
        perovskite_abx3: 'insulator',
        antiperovskite_abx3: 'insulator',
        double_perovskite: 'mag_insulator',
        heusler_full: 'mag_metal',
        heusler_half: 'mag_metal',
        spinelle_ab2x4: 'mag_insulator',
        ferrite: 'mag_insulator',
        pyrochlore: 'mag_insulator',
        garnet: 'mag_insulator',
        ybco: 'mag_insulator',
        alliage_binaire_axb1x: 'metal',
        alliage_binaire_a1xbx: 'metal',
        ternaire_dope_ab1xcx: 'mag_insulator',
        ternaire_dope_a1xbxc: 'mag_insulator',
        perovskite_dope_abo3c: 'mag_insulator',
        perovskite_dope_axbo3: 'mag_insulator',
        perovskite_dope_abxco3: 'mag_insulator',
        olivine_abxo4: 'insulator',
        ruddlesden_popper_a2bo4: 'insulator',
        tetradymite_a2b3: 'semiconductor',
        dichalcogenide_2d_mx2: 'semiconductor',
        skutterudite_mx3: 'semiconductor',
        ilmenite_abx3: 'mag_insulator',
        max_phase_m2ax: 'metal'
    };
    if (exact[t]) return exact[t];

    if (/^perovskite/.test(t)) return 'insulator';
    if (/^alliage/.test(t)) return 'metal';
    if (/^binaire_(iii|ii)/.test(t) || /zincblende|wurtzite/.test(t)) return 'semiconductor';
    if (/^binaire_/.test(t)) return 'insulator';
    if (/heusler|ferrite|spinelle|pyrochlore|garnet|ybco/.test(t)) return 'mag_insulator';
    if (/olivine/.test(t)) return 'insulator';
    if (/ruddlesden/.test(t)) return 'insulator';
    if (/tetradymite|dichalcogenide|skutterudite/.test(t)) return 'semiconductor';
    if (/ilmenite/.test(t)) return 'mag_insulator';
    if (/max_phase/.test(t)) return 'metal';
    if (/dope/.test(t)) return 'mag_insulator';

    return null;
}

/**
 * Ancre le panneau de recommandations dans la section « Paramètres du calcul ».
 */
function obtenirConteneurPanneauConvergence() {
    var panel = document.getElementById('convergence_recommendations_panel');
    var paramContainer = document.getElementById('parametres_container');

    if (paramContainer) {
        if (!panel) {
            panel = document.createElement('div');
            panel.id = 'convergence_recommendations_panel';
            panel.style.cssText = 'display:none;margin-bottom:16px;';
        }
        if (!paramContainer.contains(panel)) {
            var h4 = paramContainer.querySelector('h4');
            if (h4) paramContainer.insertBefore(panel, h4.nextSibling);
            else paramContainer.insertBefore(panel, paramContainer.firstChild);
        }
        return panel;
    }

    // Formulaire legacy (subsection_generation) — après le titre Paramètres de Calcul
    var legacyTitle = document.getElementById('legacy_parametres_calcul_titre');
    if (legacyTitle) {
        if (!panel) {
            panel = document.createElement('div');
            panel.id = 'convergence_recommendations_panel';
            panel.style.cssText = 'display:none;margin-bottom:14px;';
        }
        if (panel.parentElement !== legacyTitle.parentElement || panel.previousElementSibling !== legacyTitle) {
            legacyTitle.parentElement.insertBefore(panel, legacyTitle.nextSibling);
        }
        return panel;
    }

    return panel;
}

/**
 * Affiche un panneau de recommandations convergence dans l'interface.
 */
function afficherPanneauConvergencePourType(materialClass, calcType, profile) {
    var panel = obtenirConteneurPanneauConvergence();
    if (!panel) return;

    // Déterminer la classe CSS du panneau
    var bgColors = {
        'metal': 'linear-gradient(135deg, #f59e0b, #d97706)',
        'insulator': 'linear-gradient(135deg, #10b981, #059669)',
        'semiconductor': 'linear-gradient(135deg, #3b82f6, #2563eb)',
        'mag_metal': 'linear-gradient(135deg, #ef4444, #dc2626)',
        'mag_insulator': 'linear-gradient(135deg, #8b5cf6, #7c3aed)',
        'rare_earth': 'linear-gradient(135deg, #ec4899, #db2777)',
        'organic': 'linear-gradient(135deg, #14b8a6, #0d9488)'
    };
    var bg = bgColors[materialClass] || 'linear-gradient(135deg, #64748b, #475569)';

    // Noms lisibles
    var classNames = {
        'metal': 'Métal',
        'insulator': 'Isolant',
        'semiconductor': 'Semi-conducteur',
        'mag_metal': 'Métal magnétique',
        'mag_insulator': 'Isolant magnétique',
        'rare_earth': 'Terre rare',
        'organic': 'Organique',
        'unknown': 'Non déterminé'
    };
    var className = classNames[materialClass] || 'Non déterminé';
    if (obtenirClasseElectroniqueManuelle()) {
        className += ' (forcé)';
    }

    var calcNames = {
        'scf': 'SCF', 'relax': 'Relax', 'vc-relax': 'VC-Relax',
        'nscf': 'NSCF', 'bands': 'Bandes', 'md': 'MD'
    };
    var calcName = calcNames[calcType] || calcType.toUpperCase();

    panel.innerHTML = '' +
        '<div style="background: ' + bg + '; color: white; border-radius: 10px; padding: 16px 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.15);">' +
            '<div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px; margin-bottom: 12px;">' +
                '<h4 style="margin: 0; font-size: 1em; font-weight: 700;">' +
                    '🎯 Paramètres de calcul recommandés — ' + className +
                '</h4>' +
                '<span style="background: rgba(255,255,255,0.2); padding: 4px 10px; border-radius: 20px; font-size: 0.78em; font-weight: 600;">' +
                    'Calcul: ' + calcName +
                '</span>' +
            '</div>' +
            '<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(100px, 1fr)); gap: 8px; margin-bottom: 10px;">' +
                '<div style="background: rgba(255,255,255,0.15); padding: 8px 10px; border-radius: 6px; text-align: center;">' +
                    '<div style="font-size: 0.7em; opacity: 0.85;">ecutwfc</div>' +
                    '<div style="font-size: 1.2em; font-weight: 700;">' + profile.ecutwfc + ' Ry</div>' +
                '</div>' +
                '<div style="background: rgba(255,255,255,0.15); padding: 8px 10px; border-radius: 6px; text-align: center;">' +
                    '<div style="font-size: 0.7em; opacity: 0.85;">ecutrho</div>' +
                    '<div style="font-size: 1.2em; font-weight: 700;">' + profile.ecutrho + ' Ry</div>' +
                '</div>' +
                '<div style="background: rgba(255,255,255,0.15); padding: 8px 10px; border-radius: 6px; text-align: center;">' +
                    '<div style="font-size: 0.7em; opacity: 0.85;">conv_thr</div>' +
                    '<div style="font-size: 1.1em; font-weight: 700;">' + profile.conv_thr + '</div>' +
                '</div>' +
                '<div style="background: rgba(255,255,255,0.15); padding: 8px 10px; border-radius: 6px; text-align: center;">' +
                    '<div style="font-size: 0.7em; opacity: 0.85;">mixing_beta</div>' +
                    '<div style="font-size: 1.2em; font-weight: 700;">' + profile.mixing_beta + '</div>' +
                '</div>' +
                '<div style="background: rgba(255,255,255,0.15); padding: 8px 10px; border-radius: 6px; text-align: center;">' +
                    '<div style="font-size: 0.7em; opacity: 0.85;">occupations</div>' +
                    '<div style="font-size: 0.85em; font-weight: 600;">' + profile.occupations + '</div>' +
                '</div>' +
                '<div style="background: rgba(255,255,255,0.15); padding: 8px 10px; border-radius: 6px; text-align: center;">' +
                    '<div style="font-size: 0.7em; opacity: 0.85;">smearing</div>' +
                    '<div style="font-size: 0.8em; font-weight: 600;">' + profile.smearing + '</div>' +
                '</div>' +
            '</div>' +
            (profile.note ? '<div style="background: rgba(255,255,255,0.12); padding: 8px 12px; border-radius: 6px; font-size: 0.82em;">💡 ' + profile.note + '</div>' : '') +
        '</div>';

    panel.style.display = 'block';
}


// Exposer globalement pour utilisation depuis d'autres scripts
window.appliquerProfilConvergencePourType = appliquerProfilConvergencePourType;
window.detecterClasseDepuisTypeStructure = detecterClasseDepuisTypeStructure;
window.resoudreClasseMateriauConvergence = resoudreClasseMateriauConvergence;
window.extraireEspecesDepuisFormulaireDirect = extraireEspecesDepuisFormulaireDirect;
window.obtenirConteneurPanneauConvergence = obtenirConteneurPanneauConvergence;
window.obtenirClasseElectroniqueManuelle = obtenirClasseElectroniqueManuelle;
window.changerClasseElectronique = changerClasseElectronique;

/**
 * Vérifier la compatibilité du ibrav avec le type sélectionné
 */
function verifierCompatibiliteIbrav() {
    const typeSelect = document.getElementById('type_materiau');
    const ibravInput = document.getElementById('ibrav');
    
    if (!typeSelect || !ibravInput) return;
    
    const typeId = typeSelect.value;
    if (!typeId) return;
    
    const structure = BASE_STRUCTURES[typeId];
    if (!structure) return;
    
    const ibravValue = ibravInput.value;
    if (!ibravValue) return;
    
    // Supprimer l'ancienne alerte si elle existe
    const oldAlert = document.getElementById('alert_ibrav_incompatible');
    if (oldAlert) oldAlert.remove();
    
    // Vérifier la compatibilité
    if (!structure.ibrav.map(String).includes(ibravValue)) {
        const alert = document.createElement('div');
        alert.id = 'alert_ibrav_incompatible';
        alert.style.cssText = `
            margin-top: 10px;
            padding: 12px;
            background: #fff3cd;
            border-left: 4px solid #ff9800;
            border-radius: 5px;
            color: #856404;
        `;
        alert.innerHTML = `
            ⚠️ <strong>Attention:</strong> ibrav=${ibravValue} pourrait ne pas être compatible avec ${structure.nom}.<br>
            <small>ibrav compatibles: ${structure.ibrav.join(', ')}</small>
        `;
        
        const infoDiv = document.getElementById('info_type_materiau');
        if (infoDiv && infoDiv.parentElement) {
            infoDiv.parentElement.insertBefore(alert, infoDiv.nextSibling);
        }
    }
}

/**
 * Écouter les changements de ibrav pour validation
 */
function ecouterChangementsIbrav() {
    const ibravInput = document.getElementById('ibrav');
    if (ibravInput) {
        ibravInput.addEventListener('change', verifierCompatibiliteIbrav);
    }
}

/**
 * Afficher une notification pour nat calculé
 */
function afficherNotificationNat(structure, nat) {
    // Supprimer l'ancienne notification si elle existe
    const oldNotif = document.getElementById('notif_nat_auto');
    if (oldNotif) oldNotif.remove();
    
    const notif = document.createElement('div');
    notif.id = 'notif_nat_auto';
    notif.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        background: linear-gradient(135deg, #4caf50 0%, #45a049 100%);
        color: white;
        padding: 15px 25px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        z-index: 10000;
        font-weight: bold;
        animation: slideIn 0.3s ease-out;
    `;
    notif.innerHTML = `
        ✅ <strong>nat = ${nat}</strong> (calculé automatiquement)<br>
        <small style="opacity: 0.9;">${structure.nom}</small>
    `;
    
    document.body.appendChild(notif);
    
    // Retirer après 3 secondes
    setTimeout(() => {
        notif.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => notif.remove(), 300);
    }, 3000);
}

// Initialiser au chargement + après chaque restructuration Tab 1
function _initTypeMateriauHooks() {
    window.ensureTypeMateriauFields();
    ajouterChampTypeMatériau();
}

document.addEventListener('tab1Restructured', function () {
    setTimeout(_initTypeMateriauHooks, 0);
});

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
        setTimeout(_initTypeMateriauHooks, 100);
    });
} else {
    setTimeout(_initTypeMateriauHooks, 100);
}

console.log('✅ Script Type de Matériau chargé');



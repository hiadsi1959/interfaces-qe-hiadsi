/**
 * Configuration des chemins (PC de référence vs autre machine Ubuntu).
 * À charger AVANT config_chemins.js sur chaque interface.
 * Stockage : localStorage "qe_unified_paths_v1" + synchro "qe_inputs_config".
 */
(function () {
    'use strict';

    var STORAGE_KEY = 'qe_unified_paths_v1';
    /** Incrémenter après changement important (transfert PC, clés localStorage) */
    var SCHEMA_VERSION = 2;

    var PRESET_HIADSI = {
        profile: 'hiadsi',
        PROJECT_MAIN: '/home/hiadsi/Interface-QE_v1',
        PROJECT_INPUTS_APP: '/home/hiadsi/génération_inputs-QE',
        PROJECT_PSEUDOS_UI: '/home/hiadsi/generation_pseudos',
        QE_BIN_DIR: '/home/hiadsi/q-e-qe-7.5/bin',
        QE_API_PORT: 5007,
        API_PSEUDOS_ORIGIN: 'http://localhost:5007',
        schemaVersion: SCHEMA_VERSION
    };

    function trimSlash(p) {
        return String(p || '').replace(/\/+$/, '');
    }

    function deriveFull(cfg) {
        var main = trimSlash(cfg.PROJECT_MAIN);
        var inApp = trimSlash(cfg.PROJECT_INPUTS_APP);
        var qeBin = trimSlash(cfg.QE_BIN_DIR);
        var out = {
            WORK_DIR: main,
            PROJECT_MAIN: main,
            INPUTS_DIR: main + '/inputs',
            OUTPUTS_DIR: main + '/outputs',
            PSEUDO_DIR: main + '/pseudos/PBE',
            CIF_DIR: main + '/cif',
            TMP_DIR: main + '/tmp',
            INPUTS_DIRECT_DIR: inApp + '/inputs_générés_direct',
            INPUTS_CIF_DIR: inApp + '/inputs_convertis_cif',
            INPUTS_GENERES_DIR: inApp + '/inputs_générés_direct',
            PSEUDO_GENERES_DIR: main + '/pseudos/Pseudo_generes',
            LD1_INPUTS_DIR: main + '/pseudos/Pseudo_generes/ld1_inputs',
            QE_BIN_DIR: qeBin,
            PROJECT_INPUTS_APP: inApp,
            PROJECT_PSEUDOS_UI: trimSlash(cfg.PROJECT_PSEUDOS_UI),
            AUTO_REFRESH_INTERVAL: 3000,
            AUTO_START_API: true
        };
        return out;
    }

    function syncInputsLocalStorage(full) {
        try {
            var pack = {
                INPUTS_GENERES_DIR: full.INPUTS_GENERES_DIR,
                INPUTS_DIR: full.INPUTS_GENERES_DIR,
                OUTPUTS_DIR: full.OUTPUTS_DIR,
                PSEUDO_DIR: full.PSEUDO_DIR,
                CIF_DIR: full.CIF_DIR,
                QE_BIN_DIR: full.QE_BIN_DIR,
                WORK_DIR: full.WORK_DIR
            };
            localStorage.setItem('qe_inputs_config', JSON.stringify(pack));
        } catch (e) {
            console.warn('qe_paths_setup: synchro qe_inputs_config impossible', e);
        }
    }

    /**
     * Applique la config (profil ou formulaire) et remplit window.QE_CONFIG.
     */
    window.applyUnifiedQEPaths = function (raw, opt) {
        opt = opt || {};
        var merged = Object.assign({}, PRESET_HIADSI, raw || {});
        if (merged.schemaVersion == null || Number(merged.schemaVersion) < SCHEMA_VERSION) {
            merged.schemaVersion = SCHEMA_VERSION;
        }
        var full = deriveFull(merged);
        window.QE_CONFIG = full;
        window.QE_API_PORT = Number(merged.QE_API_PORT) || 5007;
        window.QE_API_URL = 'http://localhost:' + window.QE_API_PORT;
        window.API_PSEUDOS_ORIGIN = merged.API_PSEUDOS_ORIGIN || 'http://localhost:5007';
        if (!opt.skipStorage) {
            try {
                localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
            } catch (e) {
                console.warn('qe_paths_setup: sauvegarde impossible', e);
            }
            syncInputsLocalStorage(full);
        }
        window.__QE_PATHS_READY__ = true;
        window.dispatchEvent(new CustomEvent('qe-paths-ready', { detail: full }));
        console.log('✅ QE chemins unifiés:', full.WORK_DIR, '| QE_BIN:', full.QE_BIN_DIR);
    };

    window.loadUnifiedQEPathsFromStorage = function () {
        try {
            var s = localStorage.getItem(STORAGE_KEY);
            if (!s) return null;
            return JSON.parse(s);
        } catch (e) {
            return null;
        }
    };

    function qeEscapeHtml(s) {
        return String(s || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    function hideMismatchBanner() {
        var b = document.getElementById('qe_paths_mismatch_banner');
        if (b) b.remove();
    }

    function showMismatchBanner(srv, loc) {
        injectModalStyles();
        hideMismatchBanner();
        var b = document.createElement('div');
        b.id = 'qe_paths_mismatch_banner';
        b.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:99999;background:linear-gradient(90deg,#f59e0b,#d97706);color:#1f2937;padding:10px 16px;font-size:0.88rem;display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;box-shadow:0 4px 12px rgba(0,0,0,.2);font-family:system-ui,sans-serif;';
        b.innerHTML =
            '<span><strong>Configuration (nouveau PC / transfert)</strong> — dossier dans le navigateur : <code style="background:rgba(255,255,255,.45);padding:2px 6px;border-radius:4px;">' +
            qeEscapeHtml(loc) +
            '</code> · dossier utilisé par l’API : <code style="background:rgba(255,255,255,.45);padding:2px 6px;border-radius:4px;">' +
            qeEscapeHtml(srv) +
            '</code></span>' +
            '<button type="button" id="qe_paths_banner_cfg" style="padding:6px 14px;border-radius:8px;border:none;background:#1e293b;color:#fff;font-weight:600;cursor:pointer;">Configurer les chemins</button>' +
            '<button type="button" id="qe_paths_banner_x" style="padding:6px 10px;border-radius:8px;border:1px solid #1e293b;background:transparent;color:#1f2937;cursor:pointer;">Fermer</button>';
        if (document.body) {
            document.body.insertBefore(b, document.body.firstChild);
            var cfg = document.getElementById('qe_paths_banner_cfg');
            if (cfg) {
                cfg.onclick = function () {
                    openQEPathsWizard(true);
                };
            }
            var x = document.getElementById('qe_paths_banner_x');
            if (x) {
                x.onclick = function () {
                    b.remove();
                };
            }
        }
    }

    /**
     * Compare le WORK_DIR du navigateur avec l’API /api/statut (work_dir).
     * Après transfert sur un autre PC, l’ancien localStorage pointe souvent vers /home/hiadsi/...
     */
    function verifyServerPaths() {
        var port = Number(window.QE_API_PORT) || 5007;
        fetch('http://localhost:' + port + '/api/statut', { method: 'GET', cache: 'no-store' })
            .then(function (r) {
                return r.ok ? r.json() : Promise.reject(new Error('statut'));
            })
            .then(function (st) {
                if (!st || !st.work_dir) return;
                var srv = trimSlash(st.work_dir);
                var loc = trimSlash(window.QE_CONFIG && window.QE_CONFIG.WORK_DIR);
                if (!loc || srv === loc) {
                    hideMismatchBanner();
                    return;
                }
                showMismatchBanner(srv, loc);
                try {
                    var key = 'qe_paths_autowiz_' + srv;
                    if (!sessionStorage.getItem(key)) {
                        sessionStorage.setItem(key, '1');
                        openQEPathsWizard(true);
                    }
                } catch (e2) {}
            })
            .catch(function () { /* API hors ligne : pas de bannière */ });
    }

    window.verifierCheminsAvecAPI = verifyServerPaths;

    function injectModalStyles() {
        if (document.getElementById('qe-paths-setup-css')) return;
        var st = document.createElement('style');
        st.id = 'qe-paths-setup-css';
        st.textContent =
            '#qe_paths_modal_overlay{position:fixed;inset:0;background:rgba(15,23,42,.92);z-index:100000;display:flex;align-items:center;justify-content:center;padding:16px;font-family:system-ui,Segoe UI,sans-serif;}' +
            '#qe_paths_modal_box{background:#1e293b;color:#e2e8f0;max-width:520px;width:100%;border-radius:14px;padding:22px 24px;border:1px solid #334155;box-shadow:0 20px 50px rgba(0,0,0,.5);}' +
            '#qe_paths_modal_box h2{margin:0 0 10px 0;font-size:1.15rem;color:#93c5fd;}' +
            '#qe_paths_modal_box p{font-size:0.9rem;line-height:1.5;color:#94a3b8;margin:8px 0 14px 0;}' +
            '#qe_paths_modal_box label{display:block;font-size:0.82rem;color:#cbd5e1;margin-bottom:4px;}' +
            '#qe_paths_modal_box input[type=text]{width:100%;box-sizing:border-box;padding:8px 10px;border-radius:8px;border:1px solid #475569;background:#0f172a;color:#f8fafc;margin-bottom:12px;font-size:0.88rem;}' +
            '#qe_paths_modal_actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px;}' +
            '#qe_paths_modal_actions button{padding:9px 16px;border-radius:8px;border:none;cursor:pointer;font-weight:600;font-size:0.9rem;}' +
            '.qe_btn_primary{background:#4f46e5;color:#fff;}' +
            '.qe_btn_ghost{background:#334155;color:#e2e8f0;}' +
            '.qe_profile_row{display:flex;gap:10px;margin:12px 0;flex-wrap:wrap;}' +
            '.qe_profile_row label{display:flex;align-items:center;gap:6px;cursor:pointer;font-size:0.88rem;}';
        document.head.appendChild(st);
    }

    function openQEPathsWizard(force) {
        injectModalStyles();
        var existing = document.getElementById('qe_paths_modal_overlay');
        if (existing) existing.remove();

        var stored = window.loadUnifiedQEPathsFromStorage();
        var o = document.createElement('div');
        o.id = 'qe_paths_modal_overlay';
        o.innerHTML =
            '<div id="qe_paths_modal_box">' +
            '<h2>Configuration des chemins (cette machine)</h2>' +
            '<p>Sur un <strong>nouveau PC</strong> ou après copie du dossier, choisissez <em>Autre utilisateur</em> et indiquez les vrais chemins. Le navigateur garde la config dans <code>localStorage</code> : si vous ne voyez pas cette fenêtre après transfert, utilisez le bouton <strong>Configurer les chemins</strong> en haut à droite.</p>' +
            '<div class="qe_profile_row">' +
            '<label><input type="radio" name="qe_prof" value="hiadsi" checked> PC référence (chemins type <code>/home/hiadsi/...</code>)</label>' +
            '<label><input type="radio" name="qe_prof" value="custom"> Autre utilisateur / chemins personnalisés</label>' +
            '</div>' +
            '<div id="qe_custom_fields" style="display:none;">' +
            '<label>Racine projet principal (<code>Interface-QE_v1</code>)</label>' +
            '<input type="text" id="qe_in_main" placeholder="/home/VOTRE_USER/Interface-QE_v1" />' +
            '<label>Dossier interface « génération des inputs »</label>' +
            '<input type="text" id="qe_in_inputsapp" placeholder="/home/VOTRE_USER/génération_inputs-QE" />' +
            '<label>Dossier interface « pseudos » (optionnel, pour affichage)</label>' +
            '<input type="text" id="qe_in_pseudoapp" placeholder="/home/VOTRE_USER/generation_pseudos" />' +
            '<label>Répertoire <code>bin</code> de Quantum ESPRESSO</label>' +
            '<input type="text" id="qe_in_qebin" placeholder="/home/VOTRE_USER/q-e-qe-7.5/bin" />' +
            '<label>Port API principale (Flask)</label>' +
            '<input type="text" id="qe_in_apiport" value="5007" />' +
            '<label>URL API pseudos (souvent la même que l’API principale, port 5007)</label>' +
            '<input type="text" id="qe_in_pseudosapi" value="http://localhost:5007" />' +
            '</div>' +
            '<div id="qe_paths_modal_actions">' +
            '<button type="button" class="qe_btn_primary" id="qe_paths_ok">Enregistrer et continuer</button>' +
            (force ? '<button type="button" class="qe_btn_ghost" id="qe_paths_cancel">Annuler</button>' : '') +
            '</div></div>';
        document.body.appendChild(o);

        var radios = o.querySelectorAll('input[name=qe_prof]');
        var customBox = o.querySelector('#qe_custom_fields');
        function toggleCustom() {
            var v = o.querySelector('input[name=qe_prof]:checked');
            customBox.style.display = v && v.value === 'custom' ? 'block' : 'none';
        }
        radios.forEach(function (r) {
            r.addEventListener('change', toggleCustom);
        });
        toggleCustom();

        if (stored && stored.profile === 'custom') {
            var rc = o.querySelector('input[value=custom]');
            if (rc) rc.checked = true;
            toggleCustom();
            var m = o.querySelector('#qe_in_main');
            if (m) m.value = stored.PROJECT_MAIN || '';
            var ia = o.querySelector('#qe_in_inputsapp');
            if (ia) ia.value = stored.PROJECT_INPUTS_APP || '';
            var pu = o.querySelector('#qe_in_pseudoapp');
            if (pu) pu.value = stored.PROJECT_PSEUDOS_UI || '';
            var qb = o.querySelector('#qe_in_qebin');
            if (qb) qb.value = stored.QE_BIN_DIR || '';
            var ap = o.querySelector('#qe_in_apiport');
            if (ap) ap.value = String(stored.QE_API_PORT != null ? stored.QE_API_PORT : 5007);
            var ps = o.querySelector('#qe_in_pseudosapi');
            if (ps) ps.value = stored.API_PSEUDOS_ORIGIN || 'http://localhost:5007';
        }

        o.querySelector('#qe_paths_ok').onclick = function () {
            var prof = o.querySelector('input[name=qe_prof]:checked');
            if (prof && prof.value === 'hiadsi') {
                window.applyUnifiedQEPaths(PRESET_HIADSI);
            } else {
                var main = (o.querySelector('#qe_in_main') || {}).value || '';
                var inp = (o.querySelector('#qe_in_inputsapp') || {}).value || '';
                var pui = (o.querySelector('#qe_in_pseudoapp') || {}).value || '';
                var qeb = (o.querySelector('#qe_in_qebin') || {}).value || '';
                var port = (o.querySelector('#qe_in_apiport') || {}).value || '5007';
                var papi = (o.querySelector('#qe_in_pseudosapi') || {}).value || 'http://localhost:5007';
                if (!trimSlash(main) || !trimSlash(qeb)) {
                    alert('Indiquez au minimum la racine Interface-QE_v1 et le dossier bin de Quantum ESPRESSO.');
                    return;
                }
                window.applyUnifiedQEPaths({
                    profile: 'custom',
                    PROJECT_MAIN: trimSlash(main),
                    PROJECT_INPUTS_APP: trimSlash(inp) || trimSlash(main).replace(/Interface-QE_v1$/, 'génération_inputs-QE'),
                    PROJECT_PSEUDOS_UI: trimSlash(pui),
                    QE_BIN_DIR: trimSlash(qeb),
                    QE_API_PORT: parseInt(port, 10) || 5007,
                    API_PSEUDOS_ORIGIN: trimSlash(papi),
                    schemaVersion: SCHEMA_VERSION
                });
            }
            if (typeof window.remplirChampsConfig === 'function') {
                try {
                    window.remplirChampsConfig();
                } catch (e2) {}
            }
            hideMismatchBanner();
            setTimeout(verifyServerPaths, 400);
            o.remove();
        };
        var cxl = o.querySelector('#qe_paths_cancel');
        if (cxl) {
            cxl.onclick = function () {
                o.remove();
            };
        }
    }

    window.openQEPathsWizard = function (force) {
        openQEPathsWizard(!!force);
    };

    // --- Bootstrap : localStorage OU première visite = assistant ---
    // En mode autonome (5012), ne pas appliquer le profil Interface-QE ni l’assistant : config_chemins.js définit les défauts.
    if (typeof window !== 'undefined' && window.__GEN_INPUTS_STANDALONE__) {
        console.log('📦 qe_paths_setup — ignoré en mode autonome (génération_inputs-QE seul).');
    } else {
        var saved = window.loadUnifiedQEPathsFromStorage();
        if (saved) {
            window.applyUnifiedQEPaths(saved);
        } else {
            window.applyUnifiedQEPaths(PRESET_HIADSI, { skipStorage: true });
            if (typeof document !== 'undefined') {
                var run = function () {
                    setTimeout(function () {
                        openQEPathsWizard(false);
                    }, 200);
                };
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', run);
                } else {
                    run();
                }
            }
        }
        setTimeout(verifyServerPaths, 800);
    }
})();


// ═══════════════════════════════════════════════════════════════════════════
// POSITIONS ATOMIQUES - VERSION SIMPLIFIÉE ET TESTÉE
// Sans dépendance externe, avec débug complet
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Positions prédéfinies pour chaque structure cristalline
 * (Coordonnées en unités cristallines)
 */
const POSITIONS_PAR_IBRAV = {
    '1': {  // Cubique Simple
        name: 'Cubique Simple (SC)',
        positions: [[0, 0, 0]]
    },
    '2': {  // FCC
        name: 'Cubique Faces Centrées (FCC)',
        positions: [[0, 0, 0], [0.5, 0.5, 0.5]]
    },
    '3': {  // BCC
        name: 'Cubique Centré (BCC)',
        positions: [[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]]
    },
    '4': {  // Hexagonal
        name: 'Hexagonal',
        positions: [[0, 0, 0], [1/3, 2/3, 0.5]]
    },
    '5': {  // Rhomboédrique
        name: 'Rhomboédrique',
        positions: [[0, 0, 0]]
    },
    '6': {  // Tétragonal simple
        name: 'Tétragonal Simple',
        positions: [[0, 0, 0]]
    },
    '7': {  // Tétragonal centré
        name: 'Tétragonal Centré',
        positions: [[0, 0, 0], [0.5, 0.5, 0.5]]
    },
    '8': {  // Orthorhombique simple
        name: 'Orthorhombique Simple',
        positions: [[0, 0, 0]]
    },
    '9': {  // Orthorhombique centré
        name: 'Orthorhombique Centré',
        positions: [[0, 0, 0], [0.5, 0.5, 0]]
    },
    '10': {  // Orthorhombique F
        name: 'Orthorhombique F',
        positions: [[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]]
    },
    '11': {  // Orthorhombique I
        name: 'Orthorhombique I',
        positions: [[0, 0, 0], [0.5, 0.5, 0.5]]
    },
    '12': {  // Monoclinique simple
        name: 'Monoclinique Simple',
        positions: [[0, 0, 0]]
    },
    '13': {  // Monoclinique centré
        name: 'Monoclinique Centré',
        positions: [[0, 0, 0], [0.5, 0.5, 0]]
    },
    '14': {  // Triclinique
        name: 'Triclinique',
        positions: [[0, 0, 0]]
    }
};

/**
 * Créer la section pour générer les positions atomiques
 */
function creerSectionPositionsAtomiques() {
    console.log('📍 Création de la section positions atomiques...');
    
    const natInput = document.getElementById('nat');
    if (!natInput) {
        console.warn('⚠️ Champ nat non trouvé');
        return;
    }
    
    // Ajouter des écouteurs
    natInput.addEventListener('change', reconstruirePositionsAtomiques);
    natInput.addEventListener('input', reconstruirePositionsAtomiques);
    
    console.log('✅ Section positions atomiques créée');
}

/**
 * Reconstruire les positions atomiques
 */
function reconstruirePositionsAtomiques() {
    const natInput = document.getElementById('nat');
    const nat = parseInt(natInput?.value) || 0;
    
    console.log(`\n🔨 Reconstruction positions: nat=${nat}`);
    
    if (nat <= 0) {
        const section = document.getElementById('section_positions_atomiques');
        if (section) section.style.display = 'none';
        return;
    }
    
    let section = document.getElementById('section_positions_atomiques');
    
    if (!section) {
        console.log('Création nouvelle section positions dans section_3_especes');
        section = document.createElement('div');
        section.id = 'section_positions_atomiques';
        section.style.cssText = `
            margin-top: 20px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.7);
            border: 2px solid #4caf50;
            border-radius: 10px;
        `;
        
        // Insérer DANS la section ESPÈCES ATOMIQUES (section_3_especes)
        const especesSection = document.getElementById('section_3_especes');
        if (especesSection) {
            especesSection.appendChild(section);
            console.log('✅ Section positions ajoutée dans section_3_especes');
        } else {
            // Fallback: après nat si section_3_especes non trouvée
            const natParent = natInput.closest('.form-group') || natInput.parentElement;
            natParent.parentElement.insertBefore(section, natParent.nextElementSibling);
            console.log('⚠️ Fallback: section positions après nat');
        }
    }
    
    // Construire le HTML du tableau
    let html = `<h4 style="color: #2e7d32; margin: 0 0 15px 0;">📍 Positions Atomiques (${nat})</h4>`;
    
    html += `<div style="margin-bottom: 15px; display: flex; gap: 10px;">
        <button onclick="genererPositionsAuto()" style="
            padding: 10px 20px;
            background: #4caf50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        ">🚀 Générer Auto</button>
        
        <button onclick="effacerPositions()" style="
            padding: 10px 20px;
            background: #f44336;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        ">🗑️ Effacer</button>
    </div>`;
    
    // Tableau
    html += `<table style="width: 100%; border-collapse: collapse; background: white; font-size: 0.9em;">
        <thead>
            <tr style="background: #4caf50; color: white;">
                <th style="padding: 8px; width: 40px;">N°</th>
                <th style="padding: 8px;">X</th>
                <th style="padding: 8px;">Y</th>
                <th style="padding: 8px;">Z</th>
                <th style="padding: 8px;">Élément</th>
            </tr>
        </thead>
        <tbody>`;
    
    for (let i = 1; i <= nat; i++) {
        html += `<tr style="border-bottom: 1px solid #eee;">
            <td style="padding: 8px; text-align: center;"><strong>${i}</strong></td>
            <td style="padding: 8px;"><input type="number" id="pos_x_${i}" step="0.001" min="0" max="1" placeholder="0" onchange="mettreAJourFormat()" style="width: 100%; padding: 5px; border: 1px solid #ddd; border-radius: 3px;"></td>
            <td style="padding: 8px;"><input type="number" id="pos_y_${i}" step="0.001" min="0" max="1" placeholder="0" onchange="mettreAJourFormat()" style="width: 100%; padding: 5px; border: 1px solid #ddd; border-radius: 3px;"></td>
            <td style="padding: 8px;"><input type="number" id="pos_z_${i}" step="0.001" min="0" max="1" placeholder="0" onchange="mettreAJourFormat()" style="width: 100%; padding: 5px; border: 1px solid #ddd; border-radius: 3px;"></td>
            <td style="padding: 8px;"><select id="elem_${i}" onchange="mettreAJourFormat()" style="width: 100%; padding: 5px; border: 1px solid #ddd; border-radius: 3px;">
                <option value="">--</option>
            </select></td>
        </tr>`;
    }
    
    html += `</tbody></table>`;
    
    // Zone d'affichage
    html += `<div id="atomic_pos_format" style="
        margin-top: 20px;
        padding: 15px;
        background: #f0f7f4;
        border-radius: 8px;
        border-left: 4px solid #4caf50;
        display: none;
    ">
        <h4 style="color: #2e7d32; margin: 0 0 10px 0;">✅ ATOMIC_POSITIONS:</h4>
        <div id="atomic_pos_text" style="
            font-family: monospace;
            font-size: 0.85em;
            line-height: 1.5;
            background: white;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #4caf50;
            color: #000;
            white-space: pre-wrap;
        "></div>
    </div>`;
    
    section.innerHTML = html;
    
    // Remplir les selects APRÈS la création du HTML
    remplirSelectsAvecElements(nat);
    
    console.log(`✅ Section reconstruite avec ${nat} positions`);
    
    // 🚀 GÉNÉRATION AUTOMATIQUE DES POSITIONS
    // Déclencher automatiquement après un court délai (laisser le DOM se mettre à jour)
    setTimeout(() => {
        console.log('🚀 Déclenchement automatique de la génération des positions...');
        genererPositionsAuto();
    }, 300);
}

/**
 * Remplir les selects avec les éléments détectés
 * AVEC SUPPORT SPÉCIAL pour structures (pérovskite, etc.)
 * PLUS: Remplir aussi les element_${i} pour que genererAtomicSpecies() trouve les valeurs
 */
function remplirSelectsAvecElements(nat) {
    console.log(`\n🔨 Remplir selects avec ${nat} éléments`);
    
    // Récupérer les éléments de la section des éléments
    const ntypInput = document.getElementById('ntyp');
    const ntyp = parseInt(ntypInput?.value) || 0;
    const materiauxInput = document.getElementById('materiau_name');
    const materiau = materiauxInput?.value || '';
    
    console.log(`ntyp = ${ntyp}`);
    
    const elements = [];
    for (let i = 1; i <= ntyp; i++) {
        const elemInput = document.getElementById(`element_${i}`);
        const value = elemInput?.value.trim() || '';
        console.log(`element_${i}: ${value}`);
        if (value) {
            elements.push(value);
        }
    }
    
    console.log(`Éléments trouvés: [${elements.join(', ')}]`);
    
    if (elements.length === 0) {
        console.warn('⚠️ Aucun élément détecté!');
        return;
    }
    
    // ⭐ SPÉCIAL: Détecteur Pérovskite (ntyp=3, nat=5, éléments: [A, B, X...])
    let mappingAtomes = null;
    const isPerovskite = (ntyp === 3 && nat === 5 && elements.length === 3);
    
    if (isPerovskite) {
        console.log('✓ Structure Pérovskite détectée (ntyp=3, nat=5)');
        // Mapping: [A, B, X, X, X]
        mappingAtomes = [
            elements[0],  // Position 1: A (Ba)
            elements[1],  // Position 2: B (Ti/Fe)
            elements[2],  // Position 3: X (O)
            elements[2],  // Position 4: X (O) ← FORCE!
            elements[2]   // Position 5: X (O) ← FORCE!
        ];
        console.log(`Mapping pérovskite: [${mappingAtomes.join(', ')}]`);
    }
    
    // ⭐ SPÉCIAL: Détecteur Chalcopyrite (ntyp=3, nat=8, éléments: [A, B, X...])
    const isChalcopyrite = (ntyp === 3 && nat === 8 && elements.length === 3);
    
    if (isChalcopyrite) {
        console.log('✓ Structure Chalcopyrite ABX2 détectée (ntyp=3, nat=8)');
        // Mapping: [A, A, B, B, X, X, X, X]
        mappingAtomes = [
            elements[0],  // Position 1: A (Cu)
            elements[0],  // Position 2: A (Cu)
            elements[1],  // Position 3: B (In/Ga)
            elements[1],  // Position 4: B (In/Ga)
            elements[2],  // Position 5: X (Se/S)
            elements[2],  // Position 6: X (Se/S)
            elements[2],  // Position 7: X (Se/S)
            elements[2]   // Position 8: X (Se/S)
        ];
        console.log(`Mapping chalcopyrite: [${mappingAtomes.join(', ')}]`);
    }
    
    // Remplir chaque select ET remplir aussi les element_${i} si vides
    for (let i = 1; i <= nat; i++) {
        const select = document.getElementById(`elem_${i}`);
        if (!select) {
            console.warn(`⚠️ elem_${i} NOT FOUND`);
            continue;
        }
        
        // Vider d'abord
        select.innerHTML = '<option value="">--</option>';
        
        // Ajouter les options
        elements.forEach(elem => {
            const option = document.createElement('option');
            option.value = elem;
            option.textContent = elem;
            select.appendChild(option);
        });
        
        // Déterminer le symbole à assigner
        let elementToAssign;
        
        if (mappingAtomes) {
            // Utiliser le mapping spécial (pérovskite ou chalcopyrite)
            elementToAssign = mappingAtomes[i - 1];
            console.log(`  ✓ elem_${i} = ${elementToAssign} (mapping spécial)`);
        } else {
            // Cyclage normal pour autres structures
            const elementIndexToCycle = (i - 1) % elements.length;
            elementToAssign = elements[elementIndexToCycle];
            console.log(`  ✓ elem_${i} = ${elementToAssign} (cycle: ${elementIndexToCycle})`);
        }
        
        select.value = elementToAssign;
    }
    
    // ⭐ AJOUT IMPORTANT: Remplir aussi element_${i} pour que genererAtomicSpecies() trouve les valeurs
    console.log(`\n⭐ Remplissage des element_${i} (pour genererAtomicSpecies)...`);
    for (let i = 1; i <= ntyp; i++) {
        const elemField = document.getElementById(`element_${i}`);
        if (elemField) {
            // Chercher la valeur depuis elem_${i} ou les éléments détectés
            let value = elements[i - 1] || '';
            elemField.value = value;
            console.log(`  ✓ element_${i} = ${value}`);
        }
    }
    
    console.log(`✅ ${nat} selects + ${ntyp} champs remplis`);
}

/**
 * Générer les positions automatiquement
 * UTILISE genererPositionsPrecises() pour positions réelles
 */
function genererPositionsAuto(options) {
    options = options || {};
    const ibravInput = document.getElementById('ibrav') || document.getElementById('pw_input_ibrav');
    const natInput = document.getElementById('nat');
    const materiauxInput = document.getElementById('materiau_name');
    const typeMateriauSelect = document.getElementById('type_materiau');
    
    const ibrav = ibravInput?.value || '1';
    const nat = parseInt(natInput?.value) || 0;
    const materiau = materiauxInput?.value || '';
    const typeMateriauId = typeMateriauSelect?.value || '';
    
    console.log(`\n\n🚀🚀🚀 GÉNÉRATION AUTO - ibrav=${ibrav}, nat=${nat}, materiau='${materiau}', type='${typeMateriauId}' 🚀🚀🚀\n`);
    
    if (nat <= 0) {
        alert('❌ Entrez nat d\'abord');
        return;
    }
    
    // ⭐ PRIORITÉ: Utiliser le type de matériau sélectionné si disponible
    let positions = [];
    
    if (typeMateriauId && typeof obtenirPositionsParType === 'function') {
        console.log(`✓ Utilisation du type de matériau sélectionné: ${typeMateriauId}`);
        const ntypInput = document.getElementById('ntyp');
        const ntyp = parseInt(ntypInput?.value) || 0;
        
        positions = obtenirPositionsParType(typeMateriauId, ntyp, nat);
        console.log(`  Positions obtenues par type: ${positions.length} positions`);
    }
    
    // Si pas de positions via type, utiliser genererPositionsPrecises()
    if (positions.length === 0) {
        console.log('⚠️ Type non sélectionné ou positions non trouvées, utilisation de genererPositionsPrecises()');
        
        if (typeof genererPositionsPrecises !== 'function') {
            alert('❌ Erreur: script_positions_precises.js non chargé');
            console.error('genererPositionsPrecises NOT FOUND');
            return;
        }
        
        positions = genererPositionsPrecises(ibrav, nat, materiau);
    }
    
    console.log(`\n🔍 Positions finales:`);
    console.log(`  Type: ${typeof positions}`);
    console.log(`  Longueur: ${positions.length}`);
    console.log(`  Contenu:`, positions);
    
    if (positions.length === 0) {
        alert(`❌ Positions non trouvées pour ibrav=${ibrav}, nat=${nat}`);
        return;
    }
    
    // ÉTAPE 1: REMPLIR LES INPUTS
    console.log(`\n→ ÉTAPE 1: Remplissage des ${nat} champs...`);
    
    for (let i = 1; i <= nat; i++) {
        const posArray = positions[i - 1];
        console.log(`  Position ${i}:`, posArray);
        
        if (!posArray || posArray.length < 3) {
            console.error(`    ❌ Position invalide!`);
            continue;
        }
        
        const [x, y, z] = posArray;
        console.log(`    Valeurs: x=${x}, y=${y}, z=${z}`);
        
        const xInput = document.getElementById(`pos_x_${i}`);
        const yInput = document.getElementById(`pos_y_${i}`);
        const zInput = document.getElementById(`pos_z_${i}`);
        
        if (xInput) {
            xInput.value = x;
            console.log(`    ✓ pos_x_${i} = ${x} (DOM: ${xInput.value})`);
        } else {
            console.error(`    ❌ pos_x_${i} NOT FOUND`);
        }
        if (yInput) {
            yInput.value = y;
            console.log(`    ✓ pos_y_${i} = ${y} (DOM: ${yInput.value})`);
        } else {
            console.error(`    ❌ pos_y_${i} NOT FOUND`);
        }
        if (zInput) {
            zInput.value = z;
            console.log(`    ✓ pos_z_${i} = ${z} (DOM: ${zInput.value})`);
        } else {
            console.error(`    ❌ pos_z_${i} NOT FOUND`);
        }
    }
    
    // ÉTAPE 2: REMPLIR LES SELECTS AVEC LES ÉLÉMENTS
    console.log(`\n→ ÉTAPE 2: Remplissage des selects avec les éléments...`);
    remplirSelectsAvecElements(nat);
    
    // DEBUG: Vérifier que les selects sont bien remplis
    console.log(`\n🔍 Vérification des selects après remplissage:`);
    for (let i = 1; i <= nat; i++) {
        const select = document.getElementById(`elem_${i}`);
        if (select) {
            console.log(`  elem_${i}.value = "${select.value}"`);
        } else {
            console.error(`  ❌ elem_${i} NOT FOUND`);
        }
    }
    
    // ⭐ ÉTAPE 3: GÉNÉRER ATOMIC_SPECIES
    console.log(`\n→ ÉTAPE 3: Génération de ATOMIC_SPECIES...`);
    
    // Appeler genererAtomicSpecies APRÈS que les éléments soient remplis
    setTimeout(() => {
        if (typeof genererAtomicSpecies === 'function') {
            console.log('  Appel genererAtomicSpecies()...');
            genererAtomicSpecies();
            
            // Vérifier que atomicSpeciesGlobal est rempli
            if (window.atomicSpeciesGlobal && window.atomicSpeciesGlobal.length > 0) {
                console.log('  ✅ window.atomicSpeciesGlobal rempli!');
                console.log('  Contenu:', window.atomicSpeciesGlobal);
            } else {
                console.warn('  ❌ window.atomicSpeciesGlobal VIDE!');
            }
        } else {
            console.warn('⚠️ genererAtomicSpecies NOT FOUND');
        }
    }, 100);
    
    // ÉTAPE 4: METTRE À JOUR LE FORMAT
    console.log(`\n→ ÉTAPE 4: Appel mettreAJourFormat() après 400ms...`);
    setTimeout(() => {
        mettreAJourFormat();
        console.log('✅ Format mis à jour\n');
    }, 400);
    
    if (!options.silent) {
        alert(`✅ ${nat} positions générées!`);
    }
}

/**
 * Mettre à jour le format ATOMIC_POSITIONS
 */
function mettreAJourFormat() {
    const natInput = document.getElementById('nat');
    const nat = parseInt(natInput?.value) || 0;
    
    console.log(`\n📝 mettreAJourFormat() - nat=${nat}`);
    
    if (nat <= 0) {
        window.atomicPositionsContent = '';
        return;
    }
    
    let text = 'ATOMIC_POSITIONS crystal\n';
    
    console.log('→ Génération des lignes:');
    console.log(`🔍 DEBUG: Vérification des selects AVANT lecture:`);
    for (let i = 1; i <= nat; i++) {
        const select = document.getElementById(`elem_${i}`);
        console.log(`  elem_${i} existe: ${!!select}, value: "${select?.value || 'N/A'}"`);
    }
    console.log();
    
    for (let i = 1; i <= nat; i++) {
        // IMPORTANT: Lire depuis le SELECT
        const elemSelect = document.getElementById(`elem_${i}`);
        const xInput = document.getElementById(`pos_x_${i}`);
        const yInput = document.getElementById(`pos_y_${i}`);
        const zInput = document.getElementById(`pos_z_${i}`);
        
        // Obtenir la valeur du select (pas du placeholder!)
        let elem = '';
        if (elemSelect) {
            elem = elemSelect.value; // ← CLÉE: .value du select
            if (!elem) {
                elem = `Atom_${i}`;
            }
        } else {
            elem = `Atom_${i}`;
        }
        
        const xVal = xInput?.value || '0';
        const yVal = yInput?.value || '0';
        const zVal = zInput?.value || '0';
        
        const x = parseFloat(xVal).toFixed(6);
        const y = parseFloat(yVal).toFixed(6);
        const z = parseFloat(zVal).toFixed(6);
        
        console.log(`  ${i}. elem_${i}.value="${elem}" [${x}, ${y}, ${z}]`);
        
        text += `${elem.padEnd(3)} ${x.padStart(8)} ${y.padStart(8)} ${z.padStart(8)}\n`;
    }
    
    window.atomicPositionsContent = text.trim();
    
    console.log(`\n✅ Contenu généré:\n${window.atomicPositionsContent}\n`);
    
    const formatDiv = document.getElementById('atomic_pos_format');
    const textDiv = document.getElementById('atomic_pos_text');
    
    if (formatDiv && textDiv) {
        textDiv.textContent = window.atomicPositionsContent;
        formatDiv.style.display = 'block';
        console.log('✓ Affiché dans le DOM');
    }
}

/**
 * Effacer les positions
 */
function effacerPositions() {
    const natInput = document.getElementById('nat');
    const nat = parseInt(natInput?.value) || 0;
    
    for (let i = 1; i <= nat; i++) {
        const x = document.getElementById(`pos_x_${i}`);
        const y = document.getElementById(`pos_y_${i}`);
        const z = document.getElementById(`pos_z_${i}`);
        if (x) x.value = '';
        if (y) y.value = '';
        if (z) z.value = '';
    }
    
    const formatDiv = document.getElementById('atomic_pos_format');
    if (formatDiv) formatDiv.style.display = 'none';
    
    window.atomicPositionsContent = '';
    
    console.log('🗑️ Positions effacées');
}

/**
 * Initialiser
 */
function initialiserPositionsAtomiques() {
    console.log('🔧 Init positions atomiques...');
    setTimeout(() => {
        creerSectionPositionsAtomiques();
    }, 300);
}

// Exécuter
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialiserPositionsAtomiques);
} else {
    initialiserPositionsAtomiques();
}

console.log('✅ Script positions atomiques (SIMPLIFIÉ) chargé');

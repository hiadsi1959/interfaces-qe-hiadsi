/**
 * Finalisation UX — Tab 1 génération directe (jeunes chercheurs)
 * Stepper, aide, exemples, accès CIF, bandeau de statut.
 */
(function () {
    'use strict';

    var QE_DOC = 'https://www.quantum-espresso.org/Doc/INPUT_PW.html';

    window.getGenInputsApiBase = window.getGenInputsApiBase || function getGenInputsApiBase() {
        if (window.__GEN_INPUTS_STANDALONE__) return 'http://127.0.0.1:5012';
        var loc = window.location;
        if (loc && loc.port === '5012') return 'http://127.0.0.1:5012';
        return 'http://localhost:5007';
    };

    window.tab1ShowStatus = function tab1ShowStatus(type, html, opts) {
        opts = opts || {};
        var el = document.getElementById('tab1_status_banner');
        if (!el) return;
        var clsMap = { error: 'tab1-status-error', warn: 'tab1-status-warn', ok: 'tab1-status-ok', info: 'tab1-status-info' };
        el.className = 'tab1-status-banner ' + (clsMap[type] || 'tab1-status-info');
        el.innerHTML = html;
        el.style.display = 'block';
        if (opts.scroll === true) {
            el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    };

    window.tab1HideStatus = function tab1HideStatus() {
        var el = document.getElementById('tab1_status_banner');
        if (el) el.style.display = 'none';
    };

    /** Revenir au formulaire de génération (haut du workflow Tab 1). */
    window.tab1RevenirInterface = function tab1RevenirInterface() {
        if (typeof window.tab1SwitchMainTab === 'function') {
            window.tab1SwitchMainTab('generation');
        }
        setTimeout(function () {
            var target = document.getElementById('tab1_header')
                || document.getElementById('section_1_materiau')
                || document.getElementById('tab1_stepper');
            if (target) {
                try { target.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (_eSc) {}
            }
            if (typeof window.tab1UpdateStepper === 'function') {
                try { window.tab1UpdateStepper(); } catch (_eSt) {}
            }
        }, 80);
    };

    /** Scroll vers l'aperçu / boutons de sauvegarde (génération directe ou CIF). */
    window.tab1ScrollToInputPreview = function tab1ScrollToInputPreview(opts) {
        opts = opts || {};
        var delay = opts.delay != null ? opts.delay : 120;
        var block = opts.block || 'center';
        setTimeout(function () {
            var selectors = [
                '#cif_save_result_mount',
                '#cif_editor_actions_top',
                '#cif_top_save_btn',
                '#cif_zone_preview',
                '#cif_zone_save',
                '#preview_input_container',
                '#btn_sauvegarder_modif',
                '#preview_input',
                '#gen_input_preview_panel',
                '#input_preview_card',
                '#gestion_fichiers_status .alert-success',
                '#gestion_fichiers_status'
            ];
            var el = null;
            for (var i = 0; i < selectors.length; i++) {
                var cand = document.querySelector(selectors[i]);
                if (!cand) continue;
                try {
                    var st = window.getComputedStyle(cand);
                    if (st.display === 'none' || st.visibility === 'hidden') continue;
                    if (cand.offsetParent === null && st.position !== 'fixed') continue;
                } catch (_eVis) {}
                el = cand;
                break;
            }
            if (!el) return;
            try {
                el.scrollIntoView({ behavior: 'smooth', block: block });
            } catch (_eSc) {
                try { el.scrollIntoView(true); } catch (_eSc2) {}
            }
        }, delay);
    };

    /** Onglets principaux : guide | generation | cif | exemples
     *  opts.scroll === false → pas de scroll (init / rebuild ; évite bug Chrome qui
     *  pousse le header hors écran via scrollIntoView(block:'start')).
     */
    window.tab1SwitchMainTab = function tab1SwitchMainTab(panelId, opts) {
        opts = opts || {};
        var pid = String(panelId || 'guide').trim();
        var panels = ['guide', 'generation', 'cif', 'exemples'];
        if (panels.indexOf(pid) < 0) pid = 'guide';
        var doScroll = opts.scroll !== false;

        if (typeof window.ensureSubsectionGestionInTab1 === 'function') {
            window.ensureSubsectionGestionInTab1();
        }
        if (pid === 'cif' && typeof window.initCifGestionAfterFragment === 'function') {
            window.initCifGestionAfterFragment();
        }

        document.querySelectorAll('#tab1_main_nav .tab1-main-nav-btn').forEach(function (btn) {
            var on = btn.getAttribute('data-tab1-panel') === pid;
            btn.classList.toggle('active', on);
        });
        document.querySelectorAll('.tab1-main-panel').forEach(function (p) {
            p.classList.remove('active');
        });

        var card = document.querySelector('.tab-content.active .card');
        var gest = document.getElementById('subsection_gestion');

        if (pid === 'cif') {
            if (card) card.style.display = 'none';
            if (typeof window.afficherSousSection === 'function') window.afficherSousSection('gestion');
            if (gest) gest.style.display = 'block';
            if (typeof window.listerFichiersCIF === 'function') {
                try { window.listerFichiersCIF(); } catch (_eLc) { console.warn(_eLc); }
            }
            tab1ShowStatus('info', '<strong>Gestion des fichiers CIF</strong> — listez, convertissez et sauvegardez vos inputs QE.', { scroll: doScroll });
            return;
        }

        if (card) card.style.display = 'block';
        if (gest) gest.style.display = 'none';
        try {
            var cifBar = document.getElementById('cif_floating_action_bar');
            if (cifBar) cifBar.style.display = 'none';
        } catch (_eBar) {}
        if (typeof window.afficherSousSection === 'function') {
            try { window.afficherSousSection('generation'); } catch (_eSg) {}
        }

        var panel = document.getElementById('tab1_panel_' + pid);
        if (panel) panel.classList.add('active');
        if (pid === 'guide') tab1HideStatus();

        // Chrome : scrollIntoView(panel, start) cache header + nav. Ancrer sur la nav.
        if (doScroll && pid !== 'guide') {
            var anchor = document.getElementById('tab1_main_nav')
                || document.getElementById('tab1_header')
                || panel;
            if (anchor) {
                try {
                    anchor.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                } catch (_eSc) {
                    try { anchor.scrollIntoView(true); } catch (_eSc2) {}
                }
            }
        }
    };

    window.tab1ChargerExempleEtAller = function tab1ChargerExempleEtAller(name) {
        if (name === 'GdVO3') {
            tab1SwitchMainTab('cif');
            var cifPath = 'cif/GdVO3_mp-541177_primitive.cif';
            if (typeof window.ouvrirCIFpourConversion === 'function') {
                window.ouvrirCIFpourConversion(cifPath, 'GdVO3_mp-541177_primitive.cif', { silent: true })
                    .then(function () {
                        setTimeout(async function () {
                            if (typeof window.cifApplyMateriauPreset === 'function') {
                                try { await window.cifApplyMateriauPreset('GdVO3'); } catch (_ePr) { console.warn(_ePr); }
                            }
                            tab1ShowStatus('ok', '✅ Exemple <strong>GdVO3</strong> — AFM-G + DFT+U pré-configurés. Cliquez <strong>CONVERTIR CIF → INPUT QE</strong> (sauvegarde auto).');
                        }, 350);
                    })
                    .catch(function () {
                        tab1ShowStatus('warn', 'Ouvrez manuellement <code>GdVO3_mp-541177_primitive.cif</code> dans la liste CIF.');
                    });
            }
            return;
        }
        tab1SwitchMainTab('generation');
        if (typeof window.chargerExempleWorkflow === 'function') {
            window.chargerExempleWorkflow(name);
        }
    };

    window.tab1ToggleAide = function tab1ToggleAide() {
        tab1SwitchMainTab('guide');
    };

    window.tab1OpenGestionCIF = function tab1OpenGestionCIF() {
        tab1SwitchMainTab('cif');
    };

    /** @deprecated alias — ancien « mode avancé » */
    window.tab1ToggleModeAvance = window.tab1OpenGestionCIF;

    window.tab1OpenGestion = function tab1OpenGestion() {
        tab1OpenGestionCIF();
        if (typeof window.afficherSousSection === 'function') window.afficherSousSection('gestion');
    };

    function setVal(id, val) {
        var el = document.getElementById(id);
        if (!el) return false;
        el.value = val;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
    }

    function setPos(i, x, y, z, elem) {
        setVal('pos_x_' + i, x);
        setVal('pos_y_' + i, y);
        setVal('pos_z_' + i, z);
        var es = document.getElementById('elem_' + i);
        if (es && elem) {
            es.value = elem;
            es.dispatchEvent(new Event('change', { bubbles: true }));
        }
    }

    function selectGroupeEspace(num) {
        var sel = document.getElementById('groupe_espace_select');
        if (!sel) return;
        for (var i = 0; i < sel.options.length; i++) {
            if (String(sel.options[i].value) === String(num)) {
                sel.selectedIndex = i;
                sel.dispatchEvent(new Event('change', { bubbles: true }));
                return;
            }
        }
    }

    function fillCalcParams(opts) {
        if (opts.calc_type) setVal('calc_type', opts.calc_type);
        if (opts.ecutwfc) setVal('ecutwfc', opts.ecutwfc);
        if (opts.ecutrho) setVal('ecutrho', opts.ecutrho);
        if (opts.kpoints) setVal('kpoints', opts.kpoints);
        if (opts.conv_thr) setVal('conv_thr', opts.conv_thr);
        if (opts.mixing_beta) setVal('mixing_beta', opts.mixing_beta);
        if (typeof window.changerTypeCalculSimple === 'function' && opts.calc_type) {
            try { window.changerTypeCalculSimple(); } catch (_e) {}
        }
    }

    var EXEMPLES = {
        BaTiO3: {
            materiau: 'BaTiO3', prefix: 'BaTiO3_scf', ibrav: '1', groupe: '221',
            ntyp: 3, nat: 5, elements: ['Ba', 'Ti', 'O'], param_a: '4.004',
            calc: { calc_type: 'scf', ecutwfc: '50', ecutrho: '400', conv_thr: '1.0d-8', mixing_beta: '0.3' },
            positions: [
                ['Ba', 0, 0, 0], ['Ti', 0.5, 0.5, 0.5],
                ['O', 0.5, 0.5, 0], ['O', 0.5, 0, 0.5], ['O', 0, 0.5, 0.5]
            ]
        },
        Si: {
            materiau: 'Silicon', prefix: 'si_scf', ibrav: '2', groupe: '227',
            ntyp: 1, nat: 2, elements: ['Si'], param_a: '5.43',
            calc: { calc_type: 'scf', ecutwfc: '40', ecutrho: '320', conv_thr: '1.0d-8', mixing_beta: '0.3' },
            positions: [['Si', 0, 0, 0], ['Si', 0.25, 0.25, 0.25]]
        }
    };

    window.tab1ChargerExempleDepuisSelect = function tab1ChargerExempleDepuisSelect(sel) {
        if (!sel) return;
        var name = String(sel.value || '').trim();
        if (!name) return;
        chargerExempleWorkflow(name);
        sel.value = '';
    };

    window.chargerExempleWorkflow = function chargerExempleWorkflow(name) {
        var ex = EXEMPLES[name];
        if (!ex) {
            tab1ShowStatus('error', 'Exemple inconnu : <code>' + name + '</code>');
            return;
        }
        tab1ShowStatus('info', '⏳ Chargement de l\'exemple <strong>' + name + '</strong>…');

        setVal('materiau_name', ex.materiau);
        setVal('prefix_name', ex.prefix);
        setVal('ibrav', ex.ibrav);
        if (typeof window.afficherParametresCristallins === 'function') window.afficherParametresCristallins();
        if (typeof window.afficherGroupesEspaceTab1_v2 === 'function') window.afficherGroupesEspaceTab1_v2();
        else if (typeof window.afficherGroupesEspaceTab1 === 'function') window.afficherGroupesEspaceTab1();

        setTimeout(function () {
            if (ex.param_a) setVal('param_a', ex.param_a);
            selectGroupeEspace(ex.groupe);
            setVal('ntyp', ex.ntyp);
            if (typeof window.reconstruireChampElements === 'function') window.reconstruireChampElements();

            setTimeout(function () {
                ex.elements.forEach(function (sym, idx) {
                    setVal('element_' + (idx + 1), sym);
                });
                setVal('nat', ex.nat);
                if (typeof window.reconstruirePositionsAtomiques === 'function') window.reconstruirePositionsAtomiques();

                setTimeout(function () {
                    ex.positions.forEach(function (row, idx) {
                        setPos(idx + 1, row[1], row[2], row[3], row[0]);
                    });
                    if (typeof window.mettreAJourFormat === 'function') window.mettreAJourFormat();
                    if (typeof window.genererAtomicSpecies === 'function') window.genererAtomicSpecies();
                    fillCalcParams(ex.calc);
                    if (typeof window.pwGenSyncHiddenFieldsFromWorkflow === 'function') {
                        window.pwGenSyncHiddenFieldsFromWorkflow();
                    }
                    if (typeof window.pwGenRefreshHubbardPanel === 'function') {
                        window.pwGenRefreshHubbardPanel();
                    }
                    if (name === 'BaTiO3') {
                        setVal('nspin', '1');
                        if (typeof window.changerTypeMagnetisme === 'function') {
                            try { window.changerTypeMagnetisme('non_mag'); } catch (_eNm) {}
                        }
                        var _hbSpin = document.getElementById('gen_hubbard_auto_spin');
                        if (_hbSpin) _hbSpin.checked = false;
                    }
                    tab1UpdateStepper();
                    tab1ShowStatus('ok',
                        '✅ Exemple <strong>' + name + '</strong> chargé. Vérifiez les pseudos (section 3), '
                        + 'puis cliquez <strong>⚡ GÉNÉRER INPUT COMPLET</strong> en bas.');
                    var s1 = document.getElementById('section_1_materiau');
                    if (s1) s1.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 400);
            }, 400);
        }, 350);
    };

    window.qeDocTip = function qeDocTip(label, anchor) {
        var url = QE_DOC + (anchor ? '#' + anchor : '');
        return '<a href="' + url + '" target="_blank" rel="noopener" class="qe-doc-tip" title="Documentation QE — ' + label + '">?</a>';
    };

    function injectQeTooltips() {
        var map = [
            { id: 'ecutwfc', label: 'ecutwfc' },
            { id: 'ecutrho', label: 'ecutrho' },
            { id: 'conv_thr', label: 'conv_thr' },
            { id: 'mixing_beta', label: 'mixing_beta' },
            { id: 'ibrav', label: 'ibrav' },
            { id: 'ntyp', label: 'ntyp' },
            { id: 'nat', label: 'nat' }
        ];
        map.forEach(function (m) {
            var inp = document.getElementById(m.id);
            if (!inp || inp.dataset.qeTip) return;
            inp.dataset.qeTip = '1';
            var lab = inp.closest('.form-group');
            if (!lab) lab = inp.parentElement;
            if (!lab) return;
            var lbl = lab.querySelector('label');
            if (lbl && !lbl.querySelector('.qe-doc-tip')) {
                lbl.insertAdjacentHTML('beforeend', ' ' + window.qeDocTip(m.label));
            }
        });
    }

    var STEPS = [
        { id: 'section_1_materiau', test: function () {
            return !!(document.getElementById('materiau_name') || {}).value.trim();
        }},
        { id: 'section_2_structure', test: function () {
            return !!(document.getElementById('ibrav') || {}).value;
        }},
        { id: 'section_3_especes', test: function () {
            var n = parseInt((document.getElementById('ntyp') || {}).value, 10) || 0;
            if (n < 1) return false;
            for (var i = 1; i <= n; i++) {
                if (!(document.getElementById('element_' + i) || {}).value.trim()) return false;
            }
            return true;
        }},
        { id: 'section_4_positions', test: function () {
            var nat = parseInt((document.getElementById('nat') || {}).value, 10) || 0;
            if (nat < 1) return false;
            var ok = 0;
            for (var j = 1; j <= nat; j++) {
                var x = document.getElementById('pos_x_' + j);
                if (x && String(x.value).trim() !== '') ok++;
            }
            return ok >= nat;
        }},
        { id: 'section_5_type_calcul_chemins', test: function () {
            var el = document.querySelector('#section_5_type_calcul_chemins #calc_type')
                || document.getElementById('calc_type');
            return !!(el && el.value);
        }}
    ];

    window.tab1UpdateStepper = function tab1UpdateStepper() {
        var wrap = document.getElementById('tab1_stepper');
        if (!wrap) return;
        var firstOpen = -1;
        STEPS.forEach(function (step, idx) {
            var dot = document.getElementById('tab1_step_dot_' + idx);
            var done = step.test();
            if (dot) {
                dot.classList.remove('done', 'active', 'pending');
                dot.classList.add(done ? 'done' : (firstOpen < 0 ? (firstOpen = idx, 'active') : 'pending'));
            }
        });
        if (firstOpen < 0) STEPS.forEach(function (_, idx) {
            var dot = document.getElementById('tab1_step_dot_' + idx);
            if (dot) { dot.classList.remove('pending', 'active'); dot.classList.add('done'); }
        });
    };

    function bindStepperWatchers() {
        document.addEventListener('input', tab1UpdateStepper, true);
        document.addEventListener('change', tab1UpdateStepper, true);
        tab1UpdateStepper();
    }

    function scrollToStep(idx) {
        var step = STEPS[idx];
        if (!step) return;
        var el = document.getElementById(step.id);
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    window.tab1ScrollToStep = scrollToStep;

    function migrateExempleToolbar() {
        if (document.getElementById('tab1_exemple_select')) return;
        var tb = document.getElementById('tab1_toolbar_debutant');
        if (!tb) return;
        var oldBtns = [];
        tb.querySelectorAll('button.tab1-tb-btn').forEach(function (btn) {
            var oc = btn.getAttribute('onclick') || '';
            if (/chargerExempleWorkflow\s*\(\s*['"]BaTiO3['"]\s*\)/.test(oc) ||
                    /chargerExempleWorkflow\s*\(\s*['"]Si['"]\s*\)/.test(oc)) {
                oldBtns.push(btn);
            }
        });
        if (!oldBtns.length) return;
        var sel = document.createElement('select');
        sel.id = 'tab1_exemple_select';
        sel.className = 'tab1-tb-btn tab1-exemple-select';
        sel.title = 'Charger un matériau d\'exemple pré-rempli';
        sel.onchange = function () { tab1ChargerExempleDepuisSelect(sel); };
        sel.innerHTML = '<option value="">📥 Exemple…</option>'
            + '<option value="BaTiO3">BaTiO3 — pérovskite (DFT+U optionnel)</option>'
            + '<option value="Si">Si — diamant (SCF simple)</option>';
        tb.insertBefore(sel, oldBtns[0]);
        oldBtns.forEach(function (b) { b.remove(); });
    }

    function refreshPseudosStatusBanner() {
        var apiBase = (typeof window.getGenInputsApiBase === 'function')
            ? window.getGenInputsApiBase() : 'http://127.0.0.1:5012';
        fetch(apiBase + '/api/pseudos/status')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (!data || data.ok === false) return;
                var host = document.getElementById('qe_pseudos_status_banner');
                if (!host) {
                    host = document.createElement('div');
                    host.id = 'qe_pseudos_status_banner';
                    host.setAttribute('role', 'status');
                    var mount = document.getElementById('tab1_status_banner')
                        || document.getElementById('gen-inputs-standalone-banner')
                        || document.querySelector('.container header');
                    if (mount && mount.parentNode) {
                        mount.parentNode.insertBefore(host, mount.nextSibling);
                    } else if (document.body) {
                        document.body.insertBefore(host, document.body.firstChild);
                    }
                }
                var total = data.total_upf != null ? data.total_upf : 0;
                var ready = !!data.ready_for_pw;
                if (ready && total > 0) {
                    host.className = 'qe-pseudos-banner qe-pseudos-banner--ok';
                    host.innerHTML = 'Pseudos locaux OK — <strong>' + total
                        + '</strong> fichier(s) UPF · génération pw.x prête.';
                    host.style.display = 'block';
                    return;
                }
                host.className = 'qe-pseudos-banner qe-pseudos-banner--warn';
                host.innerHTML = 'Aucun pseudo UPF dans <code>pseudos/PBE</code> / <code>PBE_FR</code> '
                    + '(total=' + total + '). Les inputs se génèrent, mais <strong>pw.x</strong> local échouera. '
                    + 'Voir <code>pseudos/README.md</code>'
                    + (data.hint ? (' — ' + String(data.hint)) : '') + '.';
                host.style.display = 'block';
            })
            .catch(function () { /* API absente : silencieux */ });
    }

    function injectPseudosBannerStyles() {
        if (document.getElementById('qe-pseudos-banner-style')) return;
        var st = document.createElement('style');
        st.id = 'qe-pseudos-banner-style';
        st.textContent = ''
            + '.qe-pseudos-banner{margin:0;padding:10px 16px;font-size:0.92em;border-bottom:1px solid rgba(0,0,0,.08);}'
            + '.qe-pseudos-banner--warn{background:#fff7ed;color:#9a3412;}'
            + '.qe-pseudos-banner--ok{background:#ecfdf5;color:#065f46;}'
            + '[data-theme="dark"] .qe-pseudos-banner--warn{background:#431407;color:#fed7aa;}'
            + '[data-theme="dark"] .qe-pseudos-banner--ok{background:#064e3b;color:#a7f3d0;}';
        document.head.appendChild(st);
    }

    function initTab1Ux() {
        if (!document.getElementById('tab1_restructured')) return;
        migrateExempleToolbar();
        try {
            // Pas de scroll au boot — Chrome décalait toute la page (header invisible).
            if (typeof window.tab1SwitchMainTab === 'function') {
                window.tab1SwitchMainTab('guide', { scroll: false });
            }
        } catch (_eInitTab) {}
        try { window.scrollTo(0, 0); } catch (_eTop) {}
        bindStepperWatchers();
        injectQeTooltips();
        injectPseudosBannerStyles();
        refreshPseudosStatusBanner();
        setTimeout(injectQeTooltips, 3000);
        console.log('✅ UX Tab 1 finalisation active (4 onglets)');
    }

    function waitReady() {
        var tries = 0;
        var iv = setInterval(function () {
            tries++;
            if (document.getElementById('tab1_restructured')) {
                clearInterval(iv);
                initTab1Ux();
            } else if (tries > 80) clearInterval(iv);
        }, 250);
    }

    document.addEventListener('sectionTypeCalculReady', function () {
        setTimeout(function () {
            injectQeTooltips();
            tab1UpdateStepper();
        }, 100);
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', waitReady);
    } else {
        waitReady();
    }
})();

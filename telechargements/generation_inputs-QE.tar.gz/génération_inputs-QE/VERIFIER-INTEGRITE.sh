#!/usr/bin/env bash
# Vérifie que le code source n'a pas été modifié sans autorisation
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
exec python3 "$HERE/protection_hiadsi.py" check --root "$HERE"

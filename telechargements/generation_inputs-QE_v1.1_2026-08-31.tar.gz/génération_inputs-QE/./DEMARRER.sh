#!/bin/bash
# DEMARRER.sh — Démarre les services API du projet Génération Inputs QE.
#
# Rôle :
#   Lancer le serveur Flask autonome (port 5012) qui sert l'interface web
#   et les endpoints de conversion CIF → input QE.
#   Optionnellement, démarrer aussi l'API Interface-QE_v1 (port 5007).
#
# Usage :
#   ./DEMARRER.sh
#   # Aucune interaction requise — tout est automatique.
#
# Arrêt :
#   ./ARRETER.sh
#
# Dépendances :
#   - python3 avec flask, ase/spglib ou pymatgen
#   - config_pc.env (généré par CONFIGURER.sh) pour les chemins personnalisés
#
set -e

HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

# Charger config PC destination si présente
if [ -f "$HERE/config_pc.env" ]; then
    # shellcheck source=/dev/null
    source "$HERE/config_pc.env"
fi

PORT="${GEN_INPUTS_PORT:-5012}"
HOST="${GEN_INPUTS_HOST:-127.0.0.1}"
URL="http://${HOST}:${PORT}/"
LOG="$HERE/.gen_inputs.log"
PIDFILE="$HERE/.gen_inputs.pid"
PIDFILE_V1="$HERE/.gen_inputs_v1.pid"
BUILD_TAG_EXPECTED="$(grep -E '^API_BUILD_TAG\s*=' "$HERE/backend/api_inputs_standalone.py" 2>/dev/null | head -n 1 | sed -E 's/.*=\s*"([^"]+)".*/\1/')"

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

echo -e "${CYAN}📝 Génération Inputs QE — démarrage des services${NC}"
echo "    Dossier : $HERE"
echo "    Port autonome : $PORT"

# ── Config minimale si première utilisation sur ce PC ──
if [ ! -f "$HERE/config_pc.env" ] || [ ! -f "$HERE/scripts/config_pc_local.js" ]; then
    echo -e "${YELLOW}⚠️  Configuration locale absente — lancement de ./CONFIGURER.sh --yes --minimal${NC}"
    if [ -x "$HERE/CONFIGURER.sh" ]; then
        bash "$HERE/CONFIGURER.sh" --yes --minimal || {
            echo -e "${RED}❌ Échec configuration. Lancez : ./CONFIGURER.sh${NC}" >&2
            exit 1
        }
        # shellcheck source=/dev/null
        source "$HERE/config_pc.env"
    else
        echo -e "${RED}❌ CONFIGURER.sh introuvable. Copiez une archive complète du projet.${NC}" >&2
        exit 1
    fi
fi

# ── Arrêt des instances précédentes (silencieux) ──
# Tue les processus résiduels et libère le port avant de redémarrer.
pkill -f "api_inputs_standalone.py" 2>/dev/null || true
fuser -k "${PORT}/tcp" 2>/dev/null || true
if [ -f "$PIDFILE" ]; then
    kill "$(cat "$PIDFILE" 2>/dev/null)" 2>/dev/null || true
    rm -f "$PIDFILE"
fi
find "$HERE/backend" -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null || true
sleep 1

# ── Vérifier Python (pas de question — message clair si KO) ──
PY=python3
if ! "$PY" -c "import flask" 2>/dev/null; then
    echo -e "${RED}❌ Flask manquant. Lancez : ./CONFIGURER.sh${NC}" >&2
    exit 1
fi
if ! "$PY" -c "import ase, spglib" 2>/dev/null && ! "$PY" -c "import pymatgen" 2>/dev/null; then
    echo -e "${RED}❌ ase/spglib manquants. Lancez : ./CONFIGURER.sh${NC}" >&2
    exit 1
fi

# ── API 5012 — autonome (interface + CIF + sauvegarde inputs) ──
cd "$HERE/backend"
GEN_INPUTS_PORT="$PORT" GEN_INPUTS_HOST="$HOST" nohup "$PY" -u api_inputs_standalone.py >> "$LOG" 2>&1 &
echo $! > "$PIDFILE"
echo -e "${GREEN}🚀 API autonome (5012) PID $(cat "$PIDFILE")${NC}"

# ── API 5007 — Interface-QE_v1 si disponible ──
start_interface_qe_v1() {
    local v1="${INTERFACE_QE_V1:-}"
    if [ -z "$v1" ]; then
        for candidate in "$HERE/../Interface-QE_v1" "$HOME/Interface-QE_v1"; do
            [ -f "$candidate/api_qe_ubuntu.py" ] && v1="$(cd "$candidate" && pwd)" && break
        done
    fi
    [ -z "$v1" ] && return 0
    [ "${START_INTERFACE_QE_V1:-1}" = "0" ] && return 0

    local ap="${QE_API_PORT:-5007}"
    if [ -f "$PIDFILE_V1" ] && kill -0 "$(cat "$PIDFILE_V1" 2>/dev/null)" 2>/dev/null; then
        echo -e "${GREEN}✅ Interface-QE_v1 déjà active (PID $(cat "$PIDFILE_V1"))${NC}"
        return 0
    fi
    fuser -k "${ap}/tcp" 2>/dev/null || true
    sleep 0.5
    cd "$v1"
    nohup "$PY" -u api_qe_ubuntu.py >> "$HERE/.gen_inputs_v1.log" 2>&1 &
    echo $! > "$PIDFILE_V1"
    echo -e "${GREEN}🚀 Interface-QE_v1 (port $ap) PID $(cat "$PIDFILE_V1")${NC}"
    echo "    Log : $HERE/.gen_inputs_v1.log"
}

start_interface_qe_v1

# ── Attendre que l'API 5012 réponde ──
for i in 1 2 3 4 5 6 7 8 9 10; do
    sleep 0.5
    if curl -sf --max-time 1 "http://${HOST}:${PORT}/api/health" >/dev/null 2>&1; then
        RESP="$(curl -sf --max-time 1 "http://${HOST}:${PORT}/api/version" 2>/dev/null || true)"
        TAG_RUN="$(echo "$RESP" | grep -oE '"build_tag":"[^"]+"' | head -n1 | cut -d'"' -f4)"
        if [ -n "$TAG_RUN" ] && [ -n "$BUILD_TAG_EXPECTED" ] && [ "$TAG_RUN" = "$BUILD_TAG_EXPECTED" ]; then
            echo -e "${GREEN}✅ API autonome OK — build_tag $TAG_RUN${NC}"
        else
            echo -e "${GREEN}✅ API autonome répond${NC}"
        fi
        break
    fi
    [ "$i" -eq 10 ] && echo -e "${YELLOW}⚠️  API lente — consultez $LOG${NC}"
done

echo -e "${GREEN}🌐${NC} $URL"
echo "    Log autonome : $LOG"

# ── Navigateur (sans question) ──
for b in xdg-open firefox google-chrome chromium-browser chromium; do
    if command -v "$b" >/dev/null 2>&1; then
        DISPLAY="${DISPLAY:-:0}" nohup "$b" "$URL" >/dev/null 2>&1 &
        echo -e "${GREEN}✅ Navigateur : $b${NC}"
        exit 0
    fi
done
echo "Ouvrez manuellement : $URL"
exit 0

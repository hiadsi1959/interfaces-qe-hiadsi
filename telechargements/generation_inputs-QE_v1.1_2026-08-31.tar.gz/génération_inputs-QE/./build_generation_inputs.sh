#!/bin/bash
# build_generation_inputs.sh — Produit l'installateur unique « generation_inputs ».
#
# Usage (PC source / développement) :
#   ./build_generation_inputs.sh
#
# Produit :
#   ./generation_inputs   (un seul fichier exécutable, ~taille du projet compressé)
#
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

OUT="$HERE/generation_inputs"
PAYLOAD="$(mktemp /tmp/gen_inputs_payload.XXXXXX.tar.gz)"
INSTALL_FOLDER="generation_inputs-QE"
STAMP="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
BUILD_TAG="$(grep -E '^API_BUILD_TAG\s*=' "$HERE/backend/api_inputs_standalone.py" 2>/dev/null | head -1 | sed "s/.*= *[\"']\\([^\"']*\\)[\"'].*/\\1/" || echo unknown)"

echo -e "${CYAN}🔧 Construction de l'installateur generation_inputs${NC}"

if [ -x "$HERE/VERIFIER.sh" ]; then
echo -e "${YELLOW}→ Vérification pré-build…${NC}"
GEN_INPUTS_BUILDING=1 bash "$HERE/VERIFIER.sh" || {
        echo -e "${RED}❌ VERIFIER.sh a signalé des erreurs — corrigez avant de builder.${NC}" >&2
        exit 1
    }
fi

TAR_EX=(
    --exclude='./.backup_*'
    --exclude='./__pycache__'
    --exclude='./**/__pycache__'
    --exclude='*.pyc'
    --exclude='./.gen_inputs.log'
    --exclude='./.gen_inputs_v1.log'
    --exclude='./.gen_inputs.pid'
    --exclude='./.gen_inputs_v1.pid'
    --exclude='./CRASH'
    --exclude='./.git'
    --exclude='./.cursor'
    --exclude='./.vscode'
    --exclude='./.pytest_cache'
    --exclude='./backend/.pytest_cache'
    --exclude='./generation_inputs'
    --exclude='./generation_inputs-QE_transfert_*.tar.gz'
    --exclude='./_export'
    --exclude='./config_pc.env'
    --exclude='./scripts/config_pc_local.js'
    --exclude='./MANIFEST_COMPACT.txt'
    --exclude='./input_tmp.in'
    --exclude='./inputs_générés_direct/*'
    --exclude='./inputs_convertis_cif/*'
    --exclude='./outputs/*'
)

echo -e "${CYAN}→ Archive embarquée…${NC}"
tar -czf "$PAYLOAD" \
    "${TAR_EX[@]}" \
    --transform="s,^,${INSTALL_FOLDER}/," \
    -C "$HERE" .

# En-tête installateur (self-extracting)
cat > "$OUT" <<'INSTALLER_HEADER'
#!/usr/bin/env bash
# generation_inputs — Installateur autonome « Génération Inputs QE »
# Un seul fichier : copiez-le sur un autre PC Linux, exécutez-le, l'interface
# est extraite, configurée automatiquement et prête à démarrer.
#
# Usage :
#   chmod +x generation_inputs
#   ./generation_inputs
#   ./generation_inputs --install-dir ~/opt/generation_inputs-QE
#   ./generation_inputs --yes --start
#
set -euo pipefail

INSTALLER_VERSION="__INSTALLER_VERSION__"
INSTALLER_BUILD_TAG="__INSTALLER_BUILD_TAG__"
INSTALLER_BUILT_AT="__INSTALLER_BUILT_AT__"
INSTALL_FOLDER="__INSTALL_FOLDER__"
MARKER="__GEN_INPUTS_ARCHIVE_BELOW__"

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

INSTALL_DIR="${GEN_INPUTS_INSTALL_DIR:-$HOME/generation_inputs-QE}"
AUTO_YES=0
RUN_VERIFY=1
AUTO_START=0

usage() {
    cat <<EOF
generation_inputs — Installateur Génération Inputs QE
  Version installateur : $INSTALLER_VERSION
  Build application  : $INSTALLER_BUILD_TAG
  Construit le       : $INSTALLER_BUILT_AT

Usage:
  ./generation_inputs [options]

Options:
  --install-dir DIR   Dossier d'installation (défaut: ~/generation_inputs-QE)
  --yes, -y           Configuration auto sans questions (apt + pip)
  --no-verify         Ne pas lancer VERIFIER.sh après installation
  --start             Lance ./DEMARRER.sh à la fin
  -h, --help          Cette aide

Après installation :
  cd INSTALL_DIR && ./DEMARRER.sh
  Navigateur : http://127.0.0.1:5012/  (Ctrl+F5)
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --install-dir) INSTALL_DIR="$2"; shift 2 ;;
        --yes|-y) AUTO_YES=1 ;;
        --no-verify) RUN_VERIFY=0 ;;
        --start) AUTO_START=1 ;;
        -h|--help) usage; exit 0 ;;
        *) echo -e "${RED}Option inconnue : $1${NC}" >&2; usage; exit 1 ;;
    esac
done

if [[ "$(uname -s)" != "Linux" ]]; then
    echo -e "${YELLOW}⚠️  OS non Linux — l'installation est prévue pour Ubuntu/Debian.${NC}" >&2
fi

ARCHIVE_LINE=$(awk -v m="$MARKER" '$0 == m {line=NR} END {if (line) print line + 1}' "$0")
if [[ -z "$ARCHIVE_LINE" ]]; then
    echo -e "${RED}❌ Archive embarquée corrompue (marqueur absent).${NC}" >&2
    exit 1
fi

PARENT="$(dirname "$INSTALL_DIR")"
BASE="$(basename "$INSTALL_DIR")"
mkdir -p "$PARENT"

echo -e "${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║  Installation Génération Inputs QE                       ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════╝${NC}"
echo "  Destination : $INSTALL_DIR"
echo "  Build       : $INSTALLER_BUILD_TAG"
echo

if [[ -d "$INSTALL_DIR" ]] && [[ -n "$(ls -A "$INSTALL_DIR" 2>/dev/null || true)" ]]; then
    echo -e "${YELLOW}⚠️  Le dossier existe déjà et n'est pas vide.${NC}"
    if [[ "$AUTO_YES" -eq 0 ]]; then
        read -r -p "Continuer et écraser/mettre à jour les fichiers extraits ? (o/n) [n] : " reply
        reply="${reply:-n}"
        [[ "$reply" =~ ^[oOyY] ]] || { echo "Annulé."; exit 0; }
    fi
fi

echo -e "${CYAN}→ Extraction…${NC}"
tail -n "+${ARCHIVE_LINE}" "$0" | tar -xzf - -C "$PARENT"

# Normaliser le chemin final (archive contient generation_inputs-QE/)
if [[ "$BASE" != "$INSTALL_FOLDER" ]]; then
    if [[ -d "$PARENT/$INSTALL_FOLDER" ]]; then
        mkdir -p "$INSTALL_DIR"
        shopt -s dotglob nullglob
        mv "$PARENT/$INSTALL_FOLDER"/* "$INSTALL_DIR"/ 2>/dev/null || true
        shopt -u dotglob nullglob
        rmdir "$PARENT/$INSTALL_FOLDER" 2>/dev/null || true
    fi
else
    INSTALL_DIR="$PARENT/$INSTALL_FOLDER"
fi

if [[ ! -f "$INSTALL_DIR/CONFIGURER.sh" ]]; then
    echo -e "${RED}❌ Extraction échouée — CONFIGURER.sh introuvable dans $INSTALL_DIR${NC}" >&2
    exit 1
fi

chmod +x "$INSTALL_DIR"/*.sh 2>/dev/null || true
chmod +x "$INSTALL_DIR/CONFIGURER.sh" "$INSTALL_DIR/DEMARRER.sh" 2>/dev/null || true

echo -e "${GREEN}✅ Fichiers extraits dans $INSTALL_DIR${NC}"
echo -e "${CYAN}→ Auto-configuration pour ce PC…${NC}"

CFG_ARGS=(--yes)
[[ "$RUN_VERIFY" -eq 1 ]] && CFG_ARGS+=(--verify)
bash "$INSTALL_DIR/CONFIGURER.sh" "${CFG_ARGS[@]}"

echo
echo -e "${GREEN}✅ Installation terminée.${NC}"
echo "  Dossier : $INSTALL_DIR"
echo "  Lancer  : cd \"$INSTALL_DIR\" && ./DEMARRER.sh"
echo "  URL     : http://127.0.0.1:5012/"
echo

if [[ "$AUTO_START" -eq 1 ]]; then
    echo -e "${CYAN}→ Démarrage de l'interface…${NC}"
    (cd "$INSTALL_DIR" && ./DEMARRER.sh) || true
fi

exit 0

__GEN_INPUTS_ARCHIVE_BELOW__
INSTALLER_HEADER

# Injecter métadonnées build dans l'en-tête
sed -i \
    -e "s|__INSTALLER_VERSION__|1.0.0|g" \
    -e "s|__INSTALLER_BUILD_TAG__|${BUILD_TAG}|g" \
    -e "s|__INSTALLER_BUILT_AT__|${STAMP}|g" \
    -e "s|__INSTALL_FOLDER__|${INSTALL_FOLDER}|g" \
    "$OUT"

# Joindre le payload compressé
cat "$PAYLOAD" >> "$OUT"
chmod +x "$OUT"
rm -f "$PAYLOAD"

SIZE="$(du -h "$OUT" | cut -f1)"
SHA="$(sha256sum "$OUT" | awk '{print $1}')"

echo
echo -e "${GREEN}✅ Installateur prêt${NC}"
echo "   Fichier : $OUT"
echo "   Taille  : $SIZE"
echo "   SHA256  : $SHA"
echo
echo -e "${CYAN}Sur un autre PC :${NC}"
echo "   scp generation_inputs user@pc-destination:~/"
echo "   ssh user@pc-destination"
echo "   chmod +x generation_inputs && ./generation_inputs"
echo "   # ou : ./generation_inputs --yes --start"

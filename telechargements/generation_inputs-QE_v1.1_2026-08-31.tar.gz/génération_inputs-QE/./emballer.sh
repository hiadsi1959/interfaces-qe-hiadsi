#!/bin/bash
# emballer.sh — Emballe le projet en archive .tar.gz pour transfert.
#
# Alias français de compacter.sh (même comportement, mêmes exclusions).
#
# Usage :
#   ./emballer.sh                   # → generation_inputs-QE_transfert_YYYYMMDD_HHMMSS.tar.gz
#   ./emballer.sh 192.168.1.42      # → archive + scp vers autre PC
#   ./emballer.sh user@192.168.1.42 # → archive + scp avec utilisateur
#
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
exec bash "$HERE/compacter.sh" "$@"

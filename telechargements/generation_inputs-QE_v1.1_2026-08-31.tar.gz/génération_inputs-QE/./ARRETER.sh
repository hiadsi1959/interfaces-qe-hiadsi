#!/bin/bash
# ARRETER.sh — Arrête le serveur Flask autonome (port 5012).
#
# Rôle :
#   Tue proprement le processus api_inputs_standalone.py et libère le port TCP.
#   Vérifie que le port est bien libéré avant de terminer.
#
# Usage :
#   ./ARRETER.sh
#
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
PORT="${GEN_INPUTS_PORT:-5012}"
PIDFILE="$HERE/.gen_inputs.pid"

YELLOW='\033[1;33m'; GREEN='\033[0;32m'; NC='\033[0m'

echo -e "${YELLOW}⏹  Arrêt du serveur génération_inputs-QE (port $PORT)…${NC}"

if [ -f "$PIDFILE" ]; then
    PID="$(cat "$PIDFILE" 2>/dev/null || true)"
    if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
        kill "$PID" 2>/dev/null || true
        sleep 1
        kill -9 "$PID" 2>/dev/null || true
    fi
    rm -f "$PIDFILE"
fi

pkill -f "api_inputs_standalone.py" 2>/dev/null || true
fuser -k "${PORT}/tcp" 2>/dev/null || true

sleep 1
if ss -lntp 2>/dev/null | grep -q ":${PORT} "; then
    echo "⚠  Port $PORT encore occupé."
    ss -lntp 2>/dev/null | grep ":${PORT} " || true
    exit 1
fi
echo -e "${GREEN}✅ Serveur arrêté.${NC}"

#!/bin/bash
# compacter.sh — Archive portable pour transfert vers un autre PC.
# Préférez ./build_generation_inputs.sh → un seul fichier « generation_inputs ».
#
# Rôle :
#   Crée une archive .tar.gz du projet prête à être copiée sur une autre
#   machine Ubuntu. Exclut les caches, logs, backups, config machine source
#   et anciennes archives.
#   Option : transfert direct par scp si l'IP du PC destination est fournie.
#
# Usage :
#   ./compacter.sh                   # → archive + instructions
#   ./compacter.sh 192.168.1.42      # → archive + scp vers autre PC
#   ./compacter.sh user@192.168.1.42 # → archive + scp avec user
#
# Alias : ./emballer.sh (même commande, nom français)
#
# Produit :
#   generation_inputs-QE_transfert_YYYYMMDD_HHMMSS.tar.gz
#
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

TOP="$(basename "$HERE")"
STAMP="$(date +%Y%m%d_%H%M%S)"
ARCHIVE="$HERE/generation_inputs-QE_transfert_${STAMP}.tar.gz"
ARCHIVE_BASENAME="$(basename "$ARCHIVE")"
DEST="${1:-}"  # IP ou user@IP optionnelle

echo -e "${CYAN}📦 Compaction — Génération Inputs QE${NC}"
echo "   Source : $HERE"

# ── Vérification ──
if [ -x "$HERE/VERIFIER.sh" ]; then
    echo -e "${YELLOW}→ Vérification…${NC}"
    bash "$HERE/VERIFIER.sh" || true
else
    echo -e "${YELLOW}→ VERIFIER.sh absent, compaction directe${NC}"
fi

# ── Nettoyage des anciennes archives et exports ──
rm -f "$HERE"/generation_inputs-QE_transfert_*.tar.gz 2>/dev/null || true
rm -rf "$HERE/_export" 2>/dev/null || true

# ── Exclusions ──
# config_pc.env + config_pc_local.js sont propres à la machine source
# (regénérés par CONFIGURER.sh sur le PC destination)
TAR_EX=(
    --exclude='./.backup_*'
    --exclude='./__pycache__'
    --exclude='./**/__pycache__'
    --exclude='*.pyc'
    --exclude='./.gen_inputs.log'
    --exclude='./.gen_inputs_v1.log'
    --exclude='./.gen_inputs.pid'
    --exclude='./.gen_inputs_v1.pid'
    --exclude='./CRASH'
    --exclude='./.git'
    --exclude='./.cursor'
    --exclude='./.vscode'
    --exclude='./generation_inputs-QE_transfert_*.tar.gz'
    --exclude='./_export'
    --exclude='./config_pc.env'
    --exclude='./scripts/config_pc_local.js'
    --exclude='./MANIFEST_COMPACT.txt'
    --exclude='./input_tmp.in'
)

# ── Manifeste (dans l'archive, sans config machine) ──
cat > "$HERE/MANIFEST_COMPACT.txt" <<EOF
generation_inputs-QE — archive compacte
created_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)
source_host=$(hostname 2>/dev/null || echo unknown)
source_path=$HERE
top_folder=$TOP
EOF
# Ajouter le build tag s'il existe
if grep -Eq '^API_BUILD_TAG\s*=' "$HERE/backend/api_inputs_standalone.py" 2>/dev/null; then
    grep -E '^API_BUILD_TAG\s*=' "$HERE/backend/api_inputs_standalone.py" | head -1 >> "$HERE/MANIFEST_COMPACT.txt"
fi

# ── Création de l'archive ──
echo -e "${CYAN}→ Création : $ARCHIVE${NC}"
echo "   Exclus : config_pc.env, configs machine, caches, logs, backups"

tar -czf "$ARCHIVE" \
    "${TAR_EX[@]}" \
    --transform="s,^,${TOP}/," \
    -C "$HERE" .

# Nettoyer le manifeste temporaire
rm -f "$HERE/MANIFEST_COMPACT.txt"

SIZE="$(du -h "$ARCHIVE" | cut -f1)"
SHA="$(sha256sum "$ARCHIVE" | awk '{print $1}')"

echo
echo -e "${GREEN}✅ Archive prête${NC}"
echo "   $ARCHIVE"
echo "   Taille : $SIZE"
echo "   SHA256 : $SHA"
echo

# ── Transfert scp optionnel ──
if [ -n "$DEST" ]; then
    echo -e "${CYAN}→ Transfert vers $DEST …${NC}"
    if scp "$ARCHIVE" "${DEST}:~/"; then
        echo -e "${GREEN}✅ Transfert terminé${NC}"
        echo "   Archive copiée sur ${DEST}:~/${ARCHIVE_BASENAME}"
        echo
        echo -e "${CYAN}Sur le PC destination, exécutez :${NC}"
        echo "   ssh ${DEST}"
        echo "   tar -xzf ${ARCHIVE_BASENAME}"
        echo "   cd ${TOP}"
        echo "   ./CONFIGURER.sh"
        echo "   ./DEMARRER.sh"
    else
        echo -e "${RED}❌ Échec du transfert scp vers $DEST${NC}"
        echo "   Vérifiez : ssh $DEST, le chemin, et les permissions."
        echo "   L'archive locale est disponible : $ARCHIVE"
    fi
    echo
else
    echo -e "${CYAN}Instructions pour le PC destination :${NC}"
    echo
    echo "   1. Copier l'archive :"
    echo "      scp ${ARCHIVE_BASENAME} user@pc-destination:~/"
    echo "      # ou : clé USB, rsync, wget ..."
    echo
    echo "   2. Sur le PC destination :"
    echo "      ssh user@pc-destination"
    echo "      tar -xzf ${ARCHIVE_BASENAME}"
    echo "      cd ${TOP}"
    echo "      ./CONFIGURER.sh"
    echo "      ./DEMARRER.sh"
    echo
    echo -e "   ${YELLOW}Astuce :${NC} ./build_generation_inputs.sh → installateur unique generation_inputs"
    echo -e "   ${YELLOW}Astuce :${NC} ./compacter.sh IP_DU_PC  → archive + scp automatique"
fi

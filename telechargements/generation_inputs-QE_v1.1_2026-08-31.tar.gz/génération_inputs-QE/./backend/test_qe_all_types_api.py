#!/usr/bin/env python3
"""Test E2E : tous les types d'inputs via builders + workflow API (QE 7.5+)."""
from __future__ import annotations

import json
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(__file__))

from cif_to_qe import analyze_cif, analysis_from_workflow_dict, build_pw_input
from qe_input_types_catalog import AUX_INPUT_TYPES, PW_CALC_TYPES, ALL_INPUT_TYPES
from qe_input_builders import build_aux_input, BUILDERS
from qe75_verifier import verify_qe75, verify_pw_qe75

DATA = os.path.join(os.path.dirname(__file__), "..", "data")


def _si_workflow():
    return {
        "formula": "Si",
        "ibrav": 2,
        "a": 5.43,
        "b": 5.43,
        "c": 5.43,
        "nat": 2,
        "ntyp": 1,
        "atomic_species": ["Si"],
        "atomic_positions_crystal": [
            {"symbol": "Si", "x": 0.0, "y": 0.0, "z": 0.0},
            {"symbol": "Si", "x": 0.25, "y": 0.25, "z": 0.25},
        ],
        "pseudos": {"Si": "Si.pbe-us.UPF"},
    }


@pytest.fixture(scope="module")
def si_cif():
    return analyze_cif(os.path.join(DATA, "Si.cif"))


def test_workflow_analysis_builds(si_cif):
    wf = _si_workflow()
    cif = analysis_from_workflow_dict(wf)
    assert cif.nat == 2
    assert cif.ibrav == 2
    assert len(cif.celldm) >= 1
    text = build_pw_input(cif, calculation="scf", ecutwfc=50, ecutrho=400)
    res = verify_pw_qe75(text, strict=True)
    assert res.ok, res.errors


def test_workflow_dict_atomic_species_and_pseudos():
    """UI peut envoyer atomic_species=[{symbol, mass, pseudo}, …]."""
    wf = {
        "formula": "Si",
        "ibrav": 2,
        "a": 5.43,
        "nat": 2,
        "ntyp": 1,
        "atomic_species": [
            {"symbol": "Si", "mass": 28.086, "pseudo": "Si.pbe-n-rrkjus_psl.1.0.0.UPF"}
        ],
        "atomic_positions_crystal": [
            {"symbol": "Si", "x": 0.0, "y": 0.0, "z": 0.0},
            {"symbol": "Si", "x": 0.25, "y": 0.25, "z": 0.25},
        ],
    }
    cif = analysis_from_workflow_dict(wf)
    assert cif.atomic_species == ["Si"]
    text = build_pw_input(
        cif,
        calculation="scf",
        ecutwfc=40,
        ecutrho=320,
        pseudos={"Si": "Si.pbe-n-rrkjus_psl.1.0.0.UPF"},
    )
    assert "Si.pbe-n-rrkjus_psl.1.0.0.UPF" in text
    assert "{'symbol'" not in text
    res = verify_pw_qe75(text, strict=True)
    assert res.ok, res.errors


def test_vc_relax_has_press_conv_thr_default(si_cif):
    text = build_pw_input(si_cif, calculation="vc-relax", ecutwfc=50, ecutrho=400)
    assert "press_conv_thr" in text
    res = verify_pw_qe75(text, strict=True)
    assert res.ok, res.errors
    assert not any("press_conv_thr recommandé" in w for w in res.warnings)


@pytest.mark.parametrize("calc", sorted(PW_CALC_TYPES))
def test_all_pw_types_strict(si_cif, calc: str):
    text = build_pw_input(si_cif, calculation=calc, ecutwfc=50, ecutrho=400, ibrav_override=2)
    res = verify_pw_qe75(text, strict=True)
    assert res.ok, f"{calc}: {res.errors}"


@pytest.mark.parametrize("pkg", sorted(AUX_INPUT_TYPES))
def test_all_aux_types_strict(pkg: str):
    text = build_aux_input(pkg, prefix="Si", outdir="./out")
    res = verify_qe75(text, package=pkg, strict=True)
    assert res.ok, f"{pkg}: {res.errors}"


def test_builders_cover_aux_types():
    missing = sorted(AUX_INPUT_TYPES - set(BUILDERS.keys()))
    assert not missing, f"builders manquants: {missing}"


def test_menu_types_count():
    """Types UI : 9 pw (dont scf_berry, scf_born) + aux incl. ph_zeu."""
    assert len(PW_CALC_TYPES) == 9
    assert len(AUX_INPUT_TYPES) == 33
    assert len(ALL_INPUT_TYPES) == 42


def test_workflow_all_pw_calc_types():
    cif = analysis_from_workflow_dict(_si_workflow())
    for calc in sorted(PW_CALC_TYPES):
        text = build_pw_input(cif, calculation=calc, ecutwfc=50, ecutrho=400, press_conv_thr=0.5)
        res = verify_pw_qe75(text, strict=True)
        assert res.ok, f"workflow {calc}: {res.errors}"

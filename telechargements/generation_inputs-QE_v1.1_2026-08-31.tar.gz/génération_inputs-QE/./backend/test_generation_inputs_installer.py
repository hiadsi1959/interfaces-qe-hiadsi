"""Tests installateur unique generation_inputs."""
from __future__ import annotations

import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def test_build_script_exists():
    p = ROOT / "build_generation_inputs.sh"
    assert p.is_file()
    text = p.read_text(encoding="utf-8")
    assert "generation_inputs" in text
    assert "__GEN_INPUTS_ARCHIVE_BELOW__" in text
    assert "CONFIGURER.sh" in text


def test_generation_inputs_built_or_buildable():
    installer = ROOT / "generation_inputs"
    build = ROOT / "build_generation_inputs.sh"
    if not installer.is_file():
        if __import__("os").environ.get("GEN_INPUTS_BUILDING") == "1":
            return  # évite récursion build → VERIFIER → pytest → build
        r = subprocess.run(
            ["bash", str(build)],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=300,
            env={**__import__("os").environ, "GEN_INPUTS_BUILDING": "1"},
        )
        assert r.returncode == 0, r.stderr[-2000:] if r.stderr else r.stdout[-2000:]
    assert installer.is_file()
    assert installer.stat().st_mode & 0o111


def test_installer_header_and_payload():
    installer = ROOT / "generation_inputs"
    if not installer.is_file():
        return
    text = installer.read_text(encoding="utf-8", errors="replace")
    assert "__GEN_INPUTS_ARCHIVE_BELOW__" in text
    assert "CONFIGURER.sh" in text
    assert "Auto-configuration" in text or "auto-configuration" in text.lower()
    raw_all = installer.read_bytes()
    marker_b = b"__GEN_INPUTS_ARCHIVE_BELOW__\n"
    idx = raw_all.rfind(marker_b)
    assert idx >= 0
    payload_start = idx + len(marker_b)
    raw = raw_all[payload_start : payload_start + 2]
    assert raw == b"\x1f\x8b", "payload gzip absent après le marqueur"


def test_installer_help():
    installer = ROOT / "generation_inputs"
    if not installer.is_file():
        return
    r = subprocess.run(
        [str(installer), "--help"],
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert r.returncode == 0
    assert "generation_inputs" in r.stdout
    assert "--install-dir" in r.stdout

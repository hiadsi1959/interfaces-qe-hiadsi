"""Tests enrichissement types matériau + sélecteur classe électronique."""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BASE_STRUCTURES = ROOT / "scripts" / "base_donnees_structures.js"
TYPE_MATERIAU = ROOT / "scripts" / "script_type_materiau.js"

NOUVELLES_STRUCTURES = [
    "olivine_abxo4",
    "ruddlesden_popper_a2bo4",
    "tetradymite_a2b3",
    "dichalcogenide_2d_mx2",
    "skutterudite_mx3",
    "ilmenite_abx3",
    "max_phase_m2ax",
]

MAPPINGS_ATTENDUS = {
    "olivine_abxo4": "insulator",
    "ruddlesden_popper_a2bo4": "insulator",
    "tetradymite_a2b3": "semiconductor",
    "dichalcogenide_2d_mx2": "semiconductor",
    "skutterudite_mx3": "semiconductor",
    "ilmenite_abx3": "mag_insulator",
    "max_phase_m2ax": "metal",
}


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_nouvelles_structures_dans_base():
    text = _read(BASE_STRUCTURES)
    for sid in NOUVELLES_STRUCTURES:
        assert f"'{sid}':" in text, f"structure manquante: {sid}"
    ids = re.findall(r"'([a-z0-9_]+)':\s*\{", text)
    assert len(ids) >= 41, f"attendu >= 41 structures, trouvé {len(ids)}"


def test_categories_menu_contiennent_nouveaux_types():
    text = _read(BASE_STRUCTURES)
    for sid in NOUVELLES_STRUCTURES:
        assert sid in text, f"type absent du menu/categories: {sid}"


def test_selecteur_classe_electronique_present():
    text = _read(TYPE_MATERIAU)
    for needle in (
        "classe_electronique",
        "obtenirClasseElectroniqueManuelle",
        "changerClasseElectronique",
        "obtenirOptionsClasseElectroniqueHTML",
    ):
        assert needle in text, f"manquant dans script_type_materiau.js: {needle}"


def test_resoudre_classe_priorise_forcage_manuel():
    text = _read(TYPE_MATERIAU)
    assert "var manuelle = obtenirClasseElectroniqueManuelle()" in text
    assert "if (manuelle) return manuelle;" in text


def test_mapping_convergence_nouvelles_structures():
    text = _read(TYPE_MATERIAU)
    for sid, cls in MAPPINGS_ATTENDUS.items():
        assert f"{sid}: '{cls}'" in text, f"mapping convergence manquant: {sid} -> {cls}"


def test_enchainement_convergence_inchange():
    """Le panneau et l'ancrage existants doivent rester intacts."""
    text = _read(TYPE_MATERIAU)
    for needle in (
        "appliquerProfilConvergencePourType",
        "obtenirConteneurPanneauConvergence",
        "convergence_recommendations_panel",
        "perovskite_abx3: 'insulator'",
    ):
        assert needle in text, f"régression enchaînement convergence: {needle}"

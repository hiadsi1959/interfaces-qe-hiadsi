"""
Tests unitaires — split AFM des sites magnétiques pour les pérovskites.

Matériaux testés :
  - GdVO₃  (groupe 62) : split V → V1/V2 sur ordre AFM-G
  - DyVO₃  (groupe 62) : split V → V1/V2 sur ordre AFM-A (parité en z)
  - LaVO₃  (groupe 62) : maille primitive insuffisante → pas de split
  - BaFeO₃ (groupe 221) : maille primitive insuffisante, nécessite supercellule

Ordres AFM supportés :
  - afm_g / afm : motif G-type (alternance x+y)
  - afm_a        : motif A-type (alternance z)
  - afm_c        : motif C-type (alternance x)
  - afm_e        : motif E-type (alternance x+y+z)
"""
from __future__ import annotations

from pathlib import Path

from cif_to_qe import (
    analyze_cif,
    apply_afm_species_split,
    detect_perovskite_bsite_element,
    should_use_perovskite_bsite_split,
)

ROOT = Path(__file__).resolve().parent.parent / "data"


def _analyze(path: str, afm: str, **kw):
    """
    Analyse un fichier CIF avec split AFM activé.
    Raccourci utilitaire pour les tests : appelle analyze_cif avec afm_type
    et afm_split_sublattices=True par défaut.
    """
    return analyze_cif(ROOT / path, afm_type=afm, afm_split_sublattices=True, **kw)



def test_gdvo3_afm_g_split():
    """Vérifie le split AFM-G sur GdVO₃ : V → V1 (up) et V2 (down)."""
    a = _analyze("GdVO3_mp-541177_primitive.cif", "afm_g")
    assert a.atomic_species == ["Gd", "V1", "V2", "O"]
    assert a.ntyp == 4
    v1 = sum(1 for s, *_ in a.atomic_positions_crystal if s == "V1")
    v2 = sum(1 for s, *_ in a.atomic_positions_crystal if s == "V2")
    assert v1 >= 1 and v2 >= 1


def test_gdvo3_afm_g_hyphen_alias():
    """Alias UI afm-g (tiret) doit se comporter comme afm_g."""
    a = _analyze("GdVO3_mp-541177_primitive.cif", "afm-g")
    assert a.atomic_species == ["Gd", "V1", "V2", "O"]
    assert a.ntyp == 4



def test_dyvo3_afm_a_uses_z_parity():
    """Vérifie le split AFM-A sur DyVO₃ : alternance selon la coordonnée z."""
    a = _analyze("DyVO3_mp-22789_primitive.cif", "afm_a")
    assert "V1" in a.atomic_species and "V2" in a.atomic_species



def test_laVO3_primitive_no_invalid_split():
    """Vérifie que LaVO₃ en maille primitive ne produit PAS de split invalide.
    La maille primitive ne contient qu'un seul V → le split est impossible."""
    raw = analyze_cif(ROOT / "LaVO3_mp-19053_primitive.cif")
    assert detect_perovskite_bsite_element(raw) == "V"
    assert not should_use_perovskite_bsite_split(raw, "afm_g")
    a = _analyze("LaVO3_mp-19053_primitive.cif", "afm_g")
    assert "V1" not in a.atomic_species or "V2" not in a.atomic_species or a.ntyp <= 3



def test_bafeo3_primitive_requires_supercell():
    """Vérifie que BaFeO₃ en maille primitive ne peut pas être splitée
    (un seul atome Fe dans la maille primitive cubique)."""
    raw = analyze_cif(ROOT / "BaFeO3.cif")
    assert detect_perovskite_bsite_element(raw) == "Fe"
    assert not should_use_perovskite_bsite_split(raw, "afm_g")
    a = _analyze("BaFeO3.cif", "afm_g")
    assert a.atomic_species == ["Ba", "Fe", "O"] or "Fe1" not in a.atomic_species



def test_bafeo3_supercell_then_split():
    """
    Vérifie le split AFM après application d'une supercellule 2×2×1 sur BaFeO₃.
    La supercellule crée suffisamment de sites Fe pour le motif AFM-G.
    """
    import numpy as np

    raw = analyze_cif(ROOT / "BaFeO3.cif")
    sc = np.diag([2, 2, 1]).tolist()
    big = analyze_cif(
        ROOT / "BaFeO3.cif",
        supercell_matrix=sc,
        afm_type="afm_g",
        afm_split_sublattices=True,
    )
    assert should_use_perovskite_bsite_split(big, "afm_g") or "Fe1" in big.atomic_species



def test_single_fe_split_after_manual_supercell():
    """Vérifie que apply_afm_species_split refuse le split si un seul atome Fe
    est présent (message d'erreur indiquant qu'une supercellule est requise)."""
    raw = analyze_cif(ROOT / "BaFeO3.cif")
    split = apply_afm_species_split(raw, "afm_g")
    assert split.atomic_species == raw.atomic_species
    assert any("supercellule" in n.lower() for n in split.notes)


if __name__ == "__main__":
    tests = [
        test_gdvo3_afm_g_split,
        test_dyvo3_afm_a_uses_z_parity,
        test_laVO3_primitive_no_invalid_split,
        test_bafeo3_primitive_requires_supercell,
        test_bafeo3_supercell_then_split,
        test_single_fe_split_after_manual_supercell,
    ]
    for t in tests:
        t()
        print("OK", t.__name__)

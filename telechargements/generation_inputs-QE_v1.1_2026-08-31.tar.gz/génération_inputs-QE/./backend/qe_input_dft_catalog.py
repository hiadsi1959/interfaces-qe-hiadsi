"""Catalogue input_dft QE 7.5 (data/qe_input_dft_catalog.json)."""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path
from typing import Optional

ROOT = Path(__file__).resolve().parent.parent
CATALOG_PATH = ROOT / "data" / "qe_input_dft_catalog.json"

# Alias courants → valeur canonique QE (qe_dft_list / funct.f90)
INPUT_DFT_ALIASES = {
    "lda": "pz",
    "lda_pw": "pw",
    "q2d": "pbeq2d",
    "sca0": "scan0",
    "b86bx": "b86bpbex",
    "bhandhlyp": "bhahlyp",
    "gaupbe": "gaup",
}


@lru_cache(maxsize=1)
def load_catalog() -> dict:
    if not CATALOG_PATH.is_file():
        raise FileNotFoundError(f"Catalogue DFT manquant : {CATALOG_PATH}")
    return json.loads(CATALOG_PATH.read_text(encoding="utf-8"))


def catalog_values() -> frozenset[str]:
    cat = load_catalog()
    return frozenset(str(v).lower() for v in cat.get("values", ()))


def normalize_input_dft(raw: Optional[str], *, canonicalize_aliases: bool = True) -> Optional[str]:
    """Nettoie input_dft pour pw.x ; Libxc XC-… conservé en majuscules."""
    if raw is None:
        return None
    s = str(raw).strip()
    if not s:
        return None
    if s.upper().startswith("XC-"):
        u = re.sub(r"[^a-zA-Z0-9\-_]", "", s.upper())
        return u[:140] if u else None
    t = re.sub(r"[^a-z0-9\-_]", "", s.lower())
    if not t:
        return None
    if canonicalize_aliases:
        aliases = dict(INPUT_DFT_ALIASES)
        try:
            cat_aliases = load_catalog().get("aliases") or {}
            aliases.update({str(k).lower(): str(v).lower() for k, v in cat_aliases.items()})
        except FileNotFoundError:
            pass
        t = aliases.get(t, t)
    return t[:80]

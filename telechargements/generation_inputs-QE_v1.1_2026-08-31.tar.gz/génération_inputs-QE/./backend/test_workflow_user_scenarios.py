"""Scénarios utilisateur — indicateur workflow unifié (direct + CIF)."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TRACKER = ROOT / "scripts" / "script_tab1_workflow_tracker.js"

DIRECT_STEPS = ["Matériau", "Structure", "Espèces", "Positions", "Calcul", "Générer"]
CIF_STEPS = ["Choisir CIF", "Aperçu", "Maille", "Calcul", "Magnétisme", "Convertir"]

HOOKS_DIRECT = [
    ("script_orchestration_generation.js", "tab1SetWorkflowStep(5, 'generating')"),
    ("script_orchestration_generation.js", "tab1HighlightWorkflowFromScroll"),
    ("script_generation_input.js", "tab1SetWorkflowStep(5, 'done')"),
]

HOOKS_CIF = [
    ("script_gestion_fichiers_complet.js", "tab1SetWorkflowPath('cif')"),
    ("script_gestion_fichiers_complet.js", "tab1SetWorkflowStep(5, 'generating')"),
    ("script_gestion_fichiers_complet.js", "tab1SetWorkflowStep(5, 'done')"),
    ("script_gestion_fichiers_complet.js", "tab1HighlightWorkflowStep(1)"),
]


def _read(rel: str) -> str:
    return (ROOT / "scripts" / rel).read_text(encoding="utf-8")


def test_direct_path_six_steps_defined():
    text = TRACKER.read_text(encoding="utf-8")
    for label in DIRECT_STEPS:
        assert f"label: '{label}'" in text, f"étape direct manquante: {label}"


def test_cif_path_six_steps_defined():
    text = TRACKER.read_text(encoding="utf-8")
    for label in CIF_STEPS:
        assert f"label: '{label}'" in text, f"étape CIF manquante: {label}"


def test_tracker_visible_outside_card():
    text = TRACKER.read_text(encoding="utf-8")
    assert "tab1MountWorkflowShell" in text
    assert "tab1.classList.add('tab1-workflow-mounted')" in text
    assert "tab1.insertBefore" in text


def test_direct_user_journey_hooks():
    for fname, needle in HOOKS_DIRECT:
        assert needle in _read(fname), f"hook direct manquant dans {fname}: {needle}"


def test_cif_user_journey_hooks():
    for fname, needle in HOOKS_CIF:
        assert needle in _read(fname), f"hook CIF manquant dans {fname}: {needle}"


def test_scroll_targets_for_user_navigation():
    text = TRACKER.read_text(encoding="utf-8")
    for sel in (
        "#section_1_materiau",
        "#section_5_type_calcul_chemins",
        "#liste_fichiers_cif",
        "#cif_editor_step1_preview",
        "#cif_editor_step2_options",
    ):
        assert sel in text, f"cible scroll manquante: {sel}"


def test_same_color_classes_as_stepper():
    css = (ROOT / "styles" / "qe_scientific_theme.css").read_text(encoding="utf-8")
    tracker = TRACKER.read_text(encoding="utf-8")
    assert ".tab1-workflow-tracker" in css
    assert "tab1-step-dot" in tracker
    assert ".tab1-step-dot.active" in css
    assert ".tab1-step-dot.done" in css

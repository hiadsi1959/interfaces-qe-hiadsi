"""Vérification de conformité QE 7.5+ pour les inputs texte."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from qe_input_types_catalog import PW_CALC_TYPES, normalize_pw_calculation

_RE_NSPIN4 = re.compile(r"^\s*nspin\s*=\s*4\s*$", re.MULTILINE | re.IGNORECASE)
_RE_NSPIN = re.compile(r"^\s*nspin\s*=\s*(\d+)\s*$", re.MULTILINE | re.IGNORECASE)
_RE_HUBBARD_LEGACY = re.compile(r"^\s*Hubbard_[UJ]0?\s*\(", re.MULTILINE | re.IGNORECASE)
_RE_HUBBARD_CARD = re.compile(r"^\s*HUBBARD\s*\(\s*ortho-atomic\s*\)", re.MULTILINE | re.IGNORECASE)
# Espèce = symbole chimique (+ suffixe AFM optionnel V1/Fe2) + manifold (3d, 4f…)
_RE_HUBBARD_LINE = re.compile(
    r"^\s*U\s+([A-Za-z][a-z]?\d*-\d+[spdf])\s+([\d.eE+\-]+)",
    re.MULTILINE,
)
_RE_CALC = re.compile(r"^\s*calculation\s*=\s*['\"]([^'\"]+)['\"]", re.MULTILINE | re.IGNORECASE)
_RE_REL_PSEUDO = re.compile(r"\.rel-", re.IGNORECASE)


@dataclass
class Qe75VerifyResult:
    ok: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    calculation: str | None = None
    package: str = "pw"

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "errors": self.errors,
            "warnings": self.warnings,
            "calculation": self.calculation,
            "package": self.package,
        }


def _has_section(text: str, name: str) -> bool:
    return bool(re.search(rf"^\s*&{re.escape(name)}\b", text, re.MULTILINE | re.IGNORECASE))


def _namelist_body(text: str, name: str) -> str:
    m = re.search(
        rf"^\s*&{re.escape(name)}\b([\s\S]*?)^\s*/\s*$",
        text,
        re.MULTILINE | re.IGNORECASE,
    )
    return m.group(1) if m else ""


def _has_var(text: str, name: str) -> bool:
    return bool(re.search(rf"^\s*{re.escape(name)}\s*=", text, re.MULTILINE | re.IGNORECASE))


# Règles QE 7.5+ : namelists + variables obligatoires par exécutable
_QE75_AUX_SPECS: dict[str, dict[str, Any]] = {
    "dos": {"namelists": ["DOS"], "vars": ["prefix", "outdir", "fildos"]},
    "bands_pp": {"namelists": ["BANDS"], "vars": ["prefix", "outdir", "filband"]},
    "plotband": {"namelists": ["BANDS"], "vars": ["prefix", "outdir", "filband", "lp"]},
    "projwfc": {"namelists": ["PROJWFC"], "vars": ["prefix", "outdir", "filpdos"]},
    "ph": {"namelists": ["INPUTPH"], "vars": ["prefix", "outdir", "fildyn", "tr2_ph"]},
    "q2r": {"namelists": ["INPUT"], "vars": ["fildyn", "flfrc"]},
    "matdyn": {"namelists": ["INPUT"], "vars": ["flfrc", "dos"]},
    "matdyn_disp": {"namelists": ["INPUT"], "vars": ["flfrc", "flfrq", "dos"]},
    "matdyn_dos": {"namelists": ["INPUT"], "vars": ["flfrc", "fldos", "dos"]},
    "matdyn_thermo": {"namelists": ["INPUT"], "vars": ["flfrc", "fldos", "dos"]},
    "dynmat": {"namelists": ["INPUT"], "vars": ["fildyn"]},
    "pp": {"namelists": ["INPUTPP"], "vars": ["prefix", "outdir", "plot_num", "filplot"]},
    "pp_charge": {"namelists": ["INPUTPP"], "vars": ["prefix", "outdir", "plot_num", "filplot"], "plot_num": 0},
    "pp_potential": {"namelists": ["INPUTPP"], "vars": ["prefix", "outdir", "plot_num", "filplot"], "plot_num": 1},
    "pp_ldos": {"namelists": ["INPUTPP"], "vars": ["prefix", "outdir", "plot_num", "filplot"], "plot_num": 5},
    "pp_elf": {"namelists": ["INPUTPP"], "vars": ["prefix", "outdir", "plot_num", "filplot"], "plot_num": 6},
    "pp_vh": {"namelists": ["INPUTPP"], "vars": ["prefix", "outdir", "plot_num", "filplot"], "plot_num": 11},
    "pp_spin": {"namelists": ["INPUTPP"], "vars": ["prefix", "outdir", "plot_num", "filplot"], "plot_num": 8},
    "average": {"namelists": ["AVERAGE"], "vars": ["prefix", "outdir", "filavg"]},
    "plotrho": {"namelists": ["INPUTPLOT"], "vars": ["filplot"]},
    "epsilon": {"namelists": ["INPUT"], "vars": ["prefix", "outdir"]},
    "turbo_lanczos": {"namelists": ["LR_INPUT"], "vars": ["prefix", "outdir", "egr_id"]},
    "turbo_davidson": {"namelists": ["LR_INPUT"], "vars": ["prefix", "outdir", "egr_id"]},
    "turbo_eels": {"namelists": ["LR_INPUT"], "vars": ["prefix", "outdir", "egr_id"]},
    "xspectra": {"namelists": ["XSPEC"], "vars": ["prefix", "outdir"]},
    "alpha2f": {"namelists": ["INPUT"], "vars": ["fila2f"]},
    "lambda": {"namelists": ["INPUT"], "vars": ["drho", "dg"]},
    "hp": {"namelists": ["INPUTHP"], "vars": ["prefix", "outdir", "maxiter"]},
    "epw": {"namelists": ["INPUTEPW"], "vars": ["prefix", "outdir", "elph"]},
    "cp": {"namelists": ["CONTROL", "SYSTEM", "CP"], "vars": ["calculation", "prefix", "outdir", "emass"]},
    "neb": {"namelists": ["PATH"], "vars": ["string_method", "num_of_images"]},
    "pw2wan": {"namelists": ["inputpw2wan"], "vars": ["prefix", "outdir", "seedname"]},
    "ld1": {"namelists": ["INPUT"], "vars": []},
}


def _plot_num_value(text: str) -> int | None:
    m = re.search(r"^\s*plot_num\s*=\s*(-?\d+)", text, re.MULTILINE | re.IGNORECASE)
    return int(m.group(1)) if m else None


def _required_pw_sections(calculation: str) -> list[str]:
    calc = normalize_pw_calculation(calculation)
    base = ["CONTROL", "SYSTEM", "ELECTRONS"]
    if calc in ("relax", "vc-relax", "md", "vc-md"):
        base.append("IONS")
    if calc in ("vc-relax", "vc-md"):
        base.append("CELL")
    return base


def _required_pw_cards(calculation: str) -> list[str]:
    return ["ATOMIC_SPECIES", "ATOMIC_POSITIONS", "K_POINTS"]


def verify_pw_qe75(text: str, *, strict: bool = True, for_save: bool = False) -> Qe75VerifyResult:
    """Vérifie un input pw.x contre les règles QE 7.5+."""
    res = Qe75VerifyResult(ok=True, package="pw")
    if not text or not str(text).strip():
        res.ok = False
        res.errors.append("contenu vide")
        return res

    m_calc = _RE_CALC.search(text)
    calc = normalize_pw_calculation(m_calc.group(1) if m_calc else "scf")
    res.calculation = calc

    if m_calc and m_calc.group(1).strip().lower() not in PW_CALC_TYPES:
        res.errors.append(f"type de calcul pw inconnu : {m_calc.group(1)}")

    if _RE_NSPIN4.search(text):
        res.errors.append("nspin=4 interdit en QE 7.5 — utiliser noncolin=.true.")

    if _RE_HUBBARD_LEGACY.search(text):
        msg = "syntaxe Hubbard legacy (Hubbard_U/Hubbard_J0) — utiliser carte HUBBARD (ortho-atomic)"
        if strict and not for_save:
            res.errors.append(msg)
        else:
            res.warnings.append(msg)

    if "HUBBARD" in text.upper():
        if not _RE_HUBBARD_CARD.search(text):
            res.warnings.append("bloc HUBBARD sans en-tête (ortho-atomic) explicite")
        bad_lines = []
        for line in text.splitlines():
            if re.match(r"^\s*U\s+", line) and not _RE_HUBBARD_LINE.match(line):
                bad_lines.append(line.strip()[:60])
        if bad_lines:
            res.errors.append("lignes HUBBARD ambiguës (attendu: U Gd-4f 6.5)")

    if _RE_REL_PSEUDO.search(text):
        if _RE_NSPIN.search(text):
            res.errors.append("pseudos .rel- incompatibles avec nspin=2 — utiliser noncolin=.true.")
        if "noncolin" not in text.lower():
            res.warnings.append("pseudos .rel- détectés — noncolin=.true. recommandé")

    for sec in _required_pw_sections(calc):
        if not _has_section(text, sec):
            res.errors.append(f"namelist &{sec} manquante pour calculation={calc}")

    for card in _required_pw_cards(calc):
        if card not in text.upper():
            res.errors.append(f"section {card} manquante")

    ctrl = _namelist_body(text, "CONTROL").lower()
    if "lberry" in ctrl or "gdir" in ctrl or "nppstr" in ctrl:
        res.errors.append(
            "lberry/gdir/nppstr ne doivent pas etre dans &CONTROL — utiliser &BP"
        )
    if "lelfield" in ctrl:
        res.errors.append(
            "lelfield ne doit pas etre dans &CONTROL — utiliser &ELECTRIC"
        )
    if _has_section(text, "BP") and "lelfield" in text.lower():
        res.errors.append("lberry (&BP) et lelfield (&ELECTRIC) sont mutuellement exclusifs")

    if calc == "nscf":
        if "restart_mode" in text.lower() and "restart" not in text.lower():
            res.warnings.append("NSCF : restart_mode='restart' recommandé")
        if "nbnd" not in text.lower():
            res.warnings.append("NSCF : nbnd recommandé pour DOS/bandes")
        if "tetrahedra" not in text.lower() and "smearing" not in text.lower():
            res.warnings.append("NSCF : occupations='tetrahedra' ou smearing recommandé")

    if calc == "bands":
        if "crystal_b" not in text.lower():
            res.warnings.append("BANDS : K_POINTS crystal_b recommandé")
        if "nbnd" not in text.lower():
            res.warnings.append("BANDS : nbnd recommandé")

    if calc in ("md", "vc-md"):
        if not _has_section(text, "IONS"):
            res.errors.append(f"{calc.upper()} : &IONS requis (ion_dynamics='verlet')")
        elif "verlet" not in text.lower() and "langevin" not in text.lower():
            res.warnings.append(f"{calc.upper()} : ion_dynamics verlet/langevin recommandé")
        if calc == "vc-md" and not _has_section(text, "CELL"):
            res.errors.append("VC-MD : &CELL requis (maille variable)")

    if calc in ("relax", "vc-relax"):
        if "ion_dynamics" not in text.lower():
            res.warnings.append(f"{calc.upper()} : ion_dynamics recommandé dans &IONS")
        if calc == "vc-relax" and "cell_dynamics" not in text.lower():
            res.warnings.append("VC-RELAX : cell_dynamics recommandé dans &CELL")
        if calc == "vc-relax" and "press_conv_thr" not in text.lower():
            res.warnings.append("VC-RELAX : press_conv_thr recommandé dans &CELL")

    if res.errors:
        res.ok = False
    return res


def verify_aux_qe75(text: str, package: str, *, strict: bool = True) -> Qe75VerifyResult:
    """Vérification QE 7.5+ pour inputs post-pw (dos, ph, pp, turbo, …)."""
    pid = str(package or "").strip().lower()
    res = Qe75VerifyResult(ok=True, package=pid)
    if not text or not str(text).strip():
        res.ok = False
        res.errors.append("contenu vide")
        return res

    spec = _QE75_AUX_SPECS.get(pid)
    if not spec:
        res.warnings.append(f"package '{pid}' sans règles QE 7.5 détaillées — vérification minimale")
        if not re.search(r"^\s*&\w+", text, re.MULTILINE):
            res.errors.append("aucun namelist détecté")
        if res.errors:
            res.ok = False
        return res

    for nl in spec.get("namelists") or []:
        if not _has_section(text, nl):
            res.errors.append(f"namelist &{nl} manquante pour {pid}")

    for var in spec.get("vars") or []:
        if not _has_var(text, var):
            res.errors.append(f"variable {var} manquante pour {pid} (QE 7.5)")

    expected_plot = spec.get("plot_num")
    if expected_plot is not None:
        got = _plot_num_value(text)
        if got is None:
            res.errors.append(f"plot_num manquant pour {pid}")
        elif got != int(expected_plot):
            res.errors.append(f"plot_num={got} invalide pour {pid} (attendu {expected_plot})")

    if pid.startswith("pp_") or pid == "pp":
        if "prefix" in (spec.get("vars") or []) and "outdir" in (spec.get("vars") or []):
            if not re.search(r"outdir\s*=\s*['\"].*/['\"]", text, re.IGNORECASE):
                res.warnings.append(f"{pid} : outdir devrait se terminer par / (convention QE)")

    if pid == "dynmat" and re.search(r"^\s*amass\s*=\s*auto\s*$", text, re.MULTILINE | re.IGNORECASE):
        res.errors.append("dynmat : amass=auto invalide — omettre amass ou fournir les masses")

    if pid == "nscf":
        pass  # pw only

    if res.errors:
        res.ok = False
    return res


def verify_qe75(text: str, package: str = "pw", *, strict: bool = True, for_save: bool = False) -> Qe75VerifyResult:
    pid = str(package or "pw").strip().lower()
    if pid in ("pw", "pw.x", ""):
        return verify_pw_qe75(text, strict=strict, for_save=for_save)
    return verify_aux_qe75(text, pid, strict=strict)

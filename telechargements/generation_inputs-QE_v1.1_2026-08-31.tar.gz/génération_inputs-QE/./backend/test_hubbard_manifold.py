"""
Tests unitaires — assignation des manifolds Hubbard par espèce chimique.

Cas test : GdVO₃
  - Gd (gadolinium, terre rare) → manifold 4f → lettre 'f' dans la carte HUBBARD
  - V  (vanadium, métal 3d)    → manifold 3d → lettre 'd' dans la carte HUBBARD
  - O  (oxygène)                → pas de U, ignoré

Vérifie aussi que les labels scindés (V1, V2) héritent du manifold de l'élément parent.
"""
from cif_to_qe import _hubbard_card, _manifold_for_species



def test_manifold_gdvo3_per_species():
    """Vérifie _manifold_for_species pour Gd, V, O et V1 (label scindé AFM)."""
    manifolds = {"Gd": "4f", "V": "3d", "O": "2p"}
    assert _manifold_for_species("Gd", "3d", manifolds) == "4f"
    assert _manifold_for_species("V", "3d", manifolds) == "3d"
    assert _manifold_for_species("V1", "3d", {"V": "3d"}) == "3d"
    assert _manifold_for_species("Gd", "3d", None) == "4f"
    assert _manifold_for_species("V", "3d", None) == "3d"



def test_hubbard_card_gdvo3():
    """
    Vérifie la génération de la carte HUBBARD pour GdVO₃ (format QE 7.5+).
    - Gd → U Gd-4f 6.5  (manifold complet)
    - V  → U V-3d  4.0  (manifold complet)
    - Pas de U pour O (O n'a pas de U)
    - Les libellés sont au format 'X-manifold' (ex. Gd-4f, V-3d) — recommandé QE 7.5+
    """
    species = ["Gd", "V", "O"]
    u = {"Gd": 6.5, "V": 4.0}
    card = _hubbard_card(species, u, {}, "3d", "ortho-atomic", {"Gd": "4f", "V": "3d"})
    text = "\n".join(card)
    # QE 7.5+ : utilise le manifold complet (4f, 3d) plutot que la seule lettre (f, d)
    assert "U  Gd-4f  6.500000" in text, f"Attendu 'U  Gd-4f  6.500000', obtenu : {text}"
    assert "U  V-3d  4.000000" in text, f"Attendu 'U  V-3d  4.000000', obtenu : {text}"


def test_hubbard_card_afm_split_passes_verifier():
    """Cartes U V1-3d / V2-3d (AFM) doivent passer verify_pw_qe75."""
    from qe75_verifier import verify_pw_qe75

    species = ["Gd", "V1", "V2", "O"]
    u = {"Gd": 6.0, "V1": 3.5, "V2": 3.5}
    card = _hubbard_card(species, u, {}, "3d", "ortho-atomic", {"Gd": "4f", "V": "3d"})
    text = (
        "&CONTROL\n  calculation = 'scf'\n/\n"
        "&SYSTEM\n  ibrav = 1\n  nat = 4\n  ntyp = 4\n  ecutwfc = 50\n  nspin = 2\n/\n"
        "&ELECTRONS\n/\n"
        "ATOMIC_SPECIES\n  Gd 157.25 Gd.upf\n  V1 50.94 V.upf\n  V2 50.94 V.upf\n  O 16.0 O.upf\n"
        "ATOMIC_POSITIONS crystal\n  Gd 0 0 0\n  V1 0.5 0.5 0.5\n  V2 0 0.5 0.5\n  O 0.5 0 0.5\n"
        "K_POINTS automatic\n  2 2 2 0 0 0\n\n"
        + "\n".join(card) + "\n"
    )
    res = verify_pw_qe75(text, strict=True)
    assert res.ok, res.errors

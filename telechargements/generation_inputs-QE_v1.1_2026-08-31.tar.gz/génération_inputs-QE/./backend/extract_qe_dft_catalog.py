#!/usr/bin/env python3
"""Génère data/qe_input_dft_catalog.json depuis QE (qe_dft_list.f90 + funct.f90)."""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "data" / "qe_input_dft_catalog.json"
OUT_JS = ROOT / "scripts" / "qe_input_dft_options.js"

HIGHLIGHT = {"pbe", "pbesol", "scan"}

QE_ROOT = Path(os.environ.get("QE_SOURCE", "/home/hiadsi/q-e-qe-7.5"))
QE_DFT_LIST = QE_ROOT / "XClib" / "qe_dft_list.f90"
FUNCT = QE_ROOT / "Modules" / "funct.f90"

# vdW / rVV10 / BEEF — Modules/funct.f90 (SELECT CASE, insensible à la casse)
VDW_BEEF = [
    ("vdw-df", "vdW-DF1", "vdw"),
    ("vdw-df2", "vdW-DF2", "vdw"),
    ("vdw-df-c09", "vdW-DF-C09", "vdw"),
    ("vdw-df2-c09", "vdW-DF2-C09", "vdw"),
    ("vdw-df-obk8", "vdW-DF-optB88", "vdw"),
    ("vdw-df-ob86", "vdW-DF-optB86b", "vdw"),
    ("vdw-df2-b86r", "vdW-DF2-B86R (rev-vdW-DF2)", "vdw"),
    ("vdw-df-cx", "vdW-DF-cx", "vdw"),
    ("vdw-df-cx0", "vdW-DF-cx0", "vdw"),
    ("vdw-df-cx0p", "vdW-DF-cx0p", "vdw"),
    ("vdw-df-ahcx", "vdW-DF-AHCX", "vdw"),
    ("vdw-df2-0", "vdW-DF2-0 (hybride)", "vdw"),
    ("vdw-df2-ah", "vdW-DF2-AH", "vdw"),
    ("vdw-df2-br0", "vdW-DF2-br0", "vdw"),
    ("vdw-df2-ahbr", "vdW-DF2-AHBR", "vdw"),
    ("vdw-df-c090", "vdW-DF-C09-0", "vdw"),
    ("vdw-df3-opt1", "vdW-DF3-opt1", "vdw"),
    ("vdw-df3-opt2", "vdW-DF3-opt2", "vdw"),
    ("vdw-df-c6", "vdW-DF-C6", "vdw"),
    ("rvv10", "rVV10", "vdw"),
    ("rvv10-scan", "rVV10 + SCAN", "vdw"),
    ("beef", "BEEF-vdW-DF2 (défaut)", "beef"),
    ("beef-vdw", "BEEF-vdW-DF2", "beef"),
    ("beef_lxc", "BEEF-vdW (Libxc XC_GGA_XC_BEEFVDW)", "beef"),
]

GROUP_LABELS = {
    "lda": "LDA",
    "gga": "GGA",
    "hybrid": "Hybrides",
    "meta": "Méta-GGA",
    "vdw": "vdW non-local / rVV10",
    "beef": "BEEF",
    "other": "Autres (QE interne)",
}

GROUP_ORDER = ["lda", "gga", "hybrid", "meta", "vdw", "beef", "other"]

# Classement heuristique des noms qe_dft_list
HYBRID = {"pbe0", "b86bpbex", "b86bx", "bhahlyp", "bhandhlyp", "hse", "gaup", "gaupbe", "b3lyp", "b3lyp-v1r", "x3lyp"}
META = {"tpss", "m06l", "tb09", "scan", "scan0", "sca0", "r2scan", "rscan", "pbe-ah", "pbesol-ah"}
LDA = {"pz", "lda", "pw", "vwn-rpa", "oep", "kli", "hf", "lda_pw"}


def _classify(name: str) -> str:
    n = name.lower()
    if n in LDA or n in {"vwn-rpa"}:
        return "lda"
    if n in HYBRID:
        return "hybrid"
    if n in META:
        return "meta"
    return "gga"


def _parse_qe_dft_list(text: str) -> list[dict]:
    items: list[dict] = []
    seen: set[str] = set()
    for m in re.finditer(
        r"DATA\s+dft_full\(\d+\)%name\s*/\s*'([^']+)'\s*/",
        text,
        re.I,
    ):
        raw = m.group(1).strip()
        val = raw.lower()
        if val in seen:
            continue
        seen.add(val)
        items.append({"value": val, "label": raw, "group": _classify(val), "source": "qe_dft_list"})
    # alias name2
    for m in re.finditer(
        r"DATA\s+dft_full\(\d+\)%name\s*/\s*'([^']+)'\s*/\s*\n\s*DATA\s+dft_full\(\d+\)%name2\s*/\s*'([^']+)'\s*/",
        text,
        re.I,
    ):
        primary = m.group(1).strip().lower()
        alias = m.group(2).strip().lower()
        if alias in ("none", "xxxx", ""):
            continue
        if alias not in seen:
            seen.add(alias)
            items.append({
                "value": alias,
                "label": f"{m.group(2).strip()} (alias → {primary})",
                "group": _classify(primary),
                "source": "qe_dft_list",
                "alias_of": primary,
            })
    return items


def _aliases_extra() -> list[dict]:
    return [
        {"value": "lda", "label": "alias Perdew–Zunger (pz)", "group": "lda", "alias_of": "pz"},
        {"value": "lda_pw", "label": "alias PW-LDA (→ pw)", "group": "lda", "alias_of": "pw"},
        {"value": "q2d", "label": "alias PBEQ2D", "group": "gga", "alias_of": "pbeq2d"},
        {"value": "sca0", "label": "alias SCAN0", "group": "meta", "alias_of": "scan0"},
        {"value": "b86bx", "label": "alias B86BPBEX", "group": "hybrid", "alias_of": "b86bpbex"},
        {"value": "bhandhlyp", "label": "alias BHAHLYP", "group": "hybrid", "alias_of": "bhahlyp"},
    ]


def build_catalog() -> dict:
    if not QE_DFT_LIST.is_file():
        raise FileNotFoundError(f"qe_dft_list introuvable : {QE_DFT_LIST}")
    text = QE_DFT_LIST.read_text(encoding="utf-8", errors="replace")
    items = _parse_qe_dft_list(text)
    seen = {it["value"] for it in items}
    for extra in _aliases_extra():
        if extra["value"] not in seen:
            items.append(extra)
            seen.add(extra["value"])
    for val, lab, grp in VDW_BEEF:
        if val not in seen:
            items.append({"value": val, "label": lab, "group": grp, "source": "funct.f90"})
            seen.add(val)
    def _opt_label(it: dict) -> str:
        val = it["value"]
        lab = it["label"]
        if lab.lower().startswith(val):
            text = lab
        else:
            text = f"{val} — {lab}"
        if val in HIGHLIGHT:
            hints = {
                "pbe": "GGA généraliste, usage courant",
                "pbesol": "souvent mieux pour géométries de solides",
                "scan": "méta‑GGA, coûteux, pseudos alignés requis",
            }
            text = f"★ {text} ({hints[val]})"
        return text

    groups: dict[str, list] = {g: [] for g in GROUP_ORDER}
    aliases: dict[str, str] = {}
    for it in sorted(items, key=lambda x: (GROUP_ORDER.index(x["group"]) if x["group"] in GROUP_ORDER else 99, x["value"])):
        g = it["group"] if it["group"] in groups else "other"
        groups[g].append([it["value"], _opt_label(it)])
        if it.get("alias_of"):
            aliases[it["value"]] = it["alias_of"]
    optgroups = [{"label": GROUP_LABELS.get(g, g), "opts": groups[g]} for g in GROUP_ORDER if groups[g]]
    return {
        "qe_version": "7.5",
        "qe_source": str(QE_ROOT),
        "generated_from": ["XClib/qe_dft_list.f90", "Modules/funct.f90"],
        "count": len(items),
        "values": sorted(seen),
        "items": items,
        "aliases": aliases,
        "optgroups": optgroups,
        "libxc_note": "Libxc : input_dft = 'XC-001i-004i-…' (voir manuel QE / Doc/user_guide)",
    }


def _js_string(s: str) -> str:
    return json.dumps(s, ensure_ascii=False)


def write_js(cat: dict) -> None:
    lines = [
        "/**",
        " * Catalogue input_dft QE — généré par backend/extract_qe_dft_catalog.py",
        f" * Source : QE {cat.get('qe_version', '?')} ({', '.join(cat.get('generated_from', []))})",
        " * Ne pas éditer à la main ; relancer le script extracteur après mise à jour QE.",
        " * Libxc : input_dft = 'XC-001i-004Li-012i-045Li-…'",
        " */",
        "(function () {",
        "    'use strict';",
        "",
        "    /** @type {{label:string, opts:[string,string][]}}[] */",
        "    var QE_INPUT_DFT_OPTGROUPS = [",
        "        {",
        "            label: 'Défaut',",
        "            opts: [['', '(défaut — pseudopotentiel / ne pas forcer input_dft)']],",
        "        },",
    ]
    for og in cat["optgroups"]:
        lines.append("        {")
        lines.append(f"            label: {_js_string(og['label'])},")
        lines.append("            opts: [")
        for val, lab in og["opts"]:
            lines.append(f"                [{_js_string(val)}, {_js_string(lab)}],")
        lines.append("            ],")
        lines.append("        },")
    lines.extend([
        "    ];",
        "",
        "    /** Alias → valeur canonique (qe_dft_list / funct.f90) */",
        f"    var QE_INPUT_DFT_ALIASES = {json.dumps(cat.get('aliases', {}), ensure_ascii=False, indent=4)};",
        "",
        "    function optionExists(selectEl, wanted) {",
        "        if (!wanted) return true;",
        "        for (var i = 0; i < selectEl.options.length; i++) {",
        "            if (selectEl.options[i].value === wanted)",
        "                return true;",
        "        }",
        "        return false;",
        "    }",
        "",
        "    /** @param {HTMLSelectElement | null | undefined} selectEl */",
        "    function fillInputDftSelect(selectEl, selectedValue) {",
        "        if (!selectEl) return;",
        "",
        "        try {",
        "            if (arguments.length < 2 && selectEl.value)",
        "                selectedValue = selectEl.value;",
        "        } catch (_) {}",
        "",
        "        if (typeof selectedValue === 'undefined' || selectedValue === null)",
        "            selectedValue = '';",
        "",
        "        selectEl.innerHTML = '';",
        "",
        "        QE_INPUT_DFT_OPTGROUPS.forEach(function (g) {",
        "            var og = document.createElement('optgroup');",
        "            og.label = g.label;",
        "            g.opts.forEach(function (pair) {",
        "                var opt = document.createElement('option');",
        "                var val = pair[0];",
        "                var lab = pair[1];",
        "                opt.value = val;",
        "                opt.textContent = lab || val;",
        "                og.appendChild(opt);",
        "            });",
        "            selectEl.appendChild(og);",
        "        });",
        "",
        "        if (selectedValue && !optionExists(selectEl, selectedValue)) {",
        "            var custom = document.createElement('option');",
        "            custom.value = selectedValue;",
        "            custom.textContent = selectedValue + ' (personnalisé)';",
        "            var firstOg = selectEl.querySelector('optgroup');",
        "            if (firstOg) firstOg.insertBefore(custom, firstOg.firstChild);",
        "            else selectEl.appendChild(custom);",
        "        }",
        "",
        "        try {",
        "            selectEl.value = selectedValue;",
        "            if (!optionExists(selectEl, selectedValue))",
        "                selectEl.value = '';",
        "        } catch (_) {",
        "            selectEl.value = '';",
        "        }",
        "    }",
        "",
        "    function initInputDftSelects(ids) {",
        "        var list = ids || [",
        "            { id: 'pw_input_dft', def: 'pbe' },",
        "            { id: 'cif_input_dft', def: '' },",
        "            { id: 'gestion_pw_input_dft', def: 'pbe' },",
        "            { id: 'modal_pw_input_dft', def: 'pbe' },",
        "        ];",
        "        list.forEach(function (entry) {",
        "            var id;",
        "            var def;",
        "            if (typeof entry === 'string') {",
        "                id = entry;",
        "                def = (id === 'cif_input_dft') ? '' : 'pbe';",
        "            } else {",
        "                id = entry.id;",
        "                def = (entry.def != null) ? entry.def : ((id === 'cif_input_dft') ? '' : 'pbe');",
        "            }",
        "            var sel = document.getElementById(id);",
        "            if (sel) fillInputDftSelect(sel, def);",
        "        });",
        "    }",
        "",
        "    window.QE_INPUT_DFT_OPTGROUPS = QE_INPUT_DFT_OPTGROUPS;",
        "    window.QE_INPUT_DFT_ALIASES = QE_INPUT_DFT_ALIASES;",
        "    window.fillInputDftSelect = fillInputDftSelect;",
        "    window.initInputDftSelects = initInputDftSelects;",
        "",
        "    document.addEventListener('DOMContentLoaded', function () {",
        "        window.initInputDftSelects();",
        "    });",
        "})();",
        "",
    ])
    OUT_JS.write_text("\n".join(lines), encoding="utf-8")


def main():
    cat = build_catalog()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(cat, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    write_js(cat)
    print(f"Wrote {OUT} ({cat['count']} functionals)")
    print(f"Wrote {OUT_JS}")


if __name__ == "__main__":
    main()

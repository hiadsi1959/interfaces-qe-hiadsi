"""Tests optimisation 10/10 : API-only, defaults JSON, lecture fichiers, workflows aux."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


def test_calc_type_defaults_json_complete():
    p = ROOT / "data" / "qe_calc_type_defaults.json"
    assert p.is_file()
    data = json.loads(p.read_text(encoding="utf-8"))
    defaults = data["defaults"]
    for key in ("scf", "relax", "vc-relax", "nscf", "bands", "md", "vc-md", "scf_berry", "scf_born"):
        assert key in defaults
        assert "ecutwfc" in defaults[key]
        assert "conv_thr" in defaults[key]
    assert "phonons" in data.get("workflows", {})
    assert "born" in data["workflows"]


def test_api_calc_recommended_endpoint_present():
    text = (ROOT / "backend" / "api_inputs_standalone.py").read_text(encoding="utf-8")
    assert "/api/calc/recommended" in text
    assert "/api/pseudos/status" in text
    assert "_SENSITIVE_READ_NAMES" in text


def test_generation_api_only_default():
    js = (ROOT / "scripts" / "script_generation_input.js").read_text(encoding="utf-8")
    assert "QE_ALLOW_JS_FALLBACK" in js
    assert "génération annulée" in js or "generation annul" in js.lower() or "API Python injoignable" in js
    # Ne doit plus basculer silencieusement sur le repli
    assert "repli générateur JS local" not in js


def test_css_extracted_from_index():
    html = (ROOT / "index.html").read_text(encoding="utf-8")
    assert "styles/qe_legacy_inline.css" in html
    assert "styles/qe_duplicate_panels.css" in html
    # Autorisé : un seul bloc critique Chrome inline (évite cache CSS)
    style_tags = re.findall(r"<style\b[^>]*>", html, flags=re.I)
    assert len(style_tags) <= 1
    if style_tags:
        assert "qe-chrome-layout-critical" in html
    assert (ROOT / "styles" / "qe_legacy_inline.css").is_file()
    assert (ROOT / "styles" / "qe_duplicate_panels.css").is_file()
    # allégé après déduplication / extraction scripts
    assert html.count("\n") < 18000


def test_no_duplicate_large_inline_scripts():
    html = (ROOT / "index.html").read_text(encoding="utf-8")
    pattern = re.compile(r"<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)</script>", re.I)
    seen: dict[str, int] = {}
    for m in pattern.finditer(html):
        content = m.group(1)
        if len(content) < 500:
            continue
        h = hashlib.md5(content.encode()).hexdigest()
        seen[h] = seen.get(h, 0) + 1
    dups = [h for h, c in seen.items() if c > 1]
    assert not dups, f"scripts inline dupliqués: {len(dups)}"


def test_ui_wires_pseudos_status():
    js = (ROOT / "scripts" / "script_tab1_ux_finalisation.js").read_text(encoding="utf-8")
    assert "/api/pseudos/status" in js
    assert "qe_pseudos_status_banner" in js


def test_xcrysden_fallback_opens_embedded_3d():
    js = (ROOT / "scripts" / "script_visualisation_3d.js").read_text(encoding="utf-8")
    assert "afficherVisualisation3D" in js
    assert "vue 3D intégrée" in js or "vue 3D integree" in js.lower()


def test_aux_workflows_comments():
    from qe_input_builders import build_aux_input

    dos = build_aux_input("dos", prefix="Si")
    assert "Workflow DOS" in dos
    ph = build_aux_input("ph", prefix="Si")
    assert "Workflow phonons" in ph
    q2r = build_aux_input("q2r", prefix="Si")
    assert "matdyn" in q2r.lower()
    from qe75_verifier import verify_qe75

    for pkg, text in (("dos", dos), ("ph", ph), ("q2r", q2r)):
        res = verify_qe75(text, package=pkg, strict=True)
        assert res.ok, f"{pkg}: {res.errors}"


def test_matdyn_disp_ibrav_aware():
    from qe_input_builders import build_aux_input

    sc = build_aux_input("matdyn_disp", prefix="Si", ibrav=1)
    fcc = build_aux_input("matdyn_disp", prefix="Si", ibrav=2)
    assert "ibrav=1" in sc
    assert "ibrav=2" in fcc
    assert "0.5000 0.0000 0.5000" in fcc  # X FCC
    assert "0.5000 0.0000 0.5000" not in sc
    ph = build_aux_input("ph", prefix="Si", amass="28.085,15.999")
    assert "amass(1) = 28.085" in ph
    assert "amass(2) = 15.999" in ph


def test_file_read_rejects_secrets():
    import sys

    sys.path.insert(0, str(ROOT / "backend"))
    import api_inputs_standalone as api

    secret = (ROOT / "config_pc.env").resolve()
    assert api._path_under_allowed_roots(secret) is False
    data_json = (ROOT / "data" / "qe_calc_type_defaults.json").resolve()
    assert api._path_under_allowed_roots(data_json) is True


def test_pseudos_readme():
    assert (ROOT / "pseudos" / "README.md").is_file()


def test_phonon_editor_bridge_present():
    assert (ROOT / "scripts" / "qe_phonon_editor_bridge.js").is_file()
    assert (ROOT / "scripts" / "workflow_phonons_ameliore_inline.js").is_file()
    html = (ROOT / "index.html").read_text(encoding="utf-8")
    assert "qe_phonon_editor_bridge.js" in html
    assert "workflow_phonons_ameliore_inline.js" in html

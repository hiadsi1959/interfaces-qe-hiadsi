"""Sauvegarde XSF dans structures_xsf/ + ouverture viewer."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def test_structure_xsf_dir_is_structures_xsf():
    import sys
    sys.path.insert(0, str(ROOT / "backend"))
    import api_inputs_standalone as api

    d = api._structure_xsf_dir()
    assert d.name == "structures_xsf"
    assert d.is_dir()


def test_save_structure_xsf_creates_material_subdir(tmp_path, monkeypatch):
    import sys
    sys.path.insert(0, str(ROOT / "backend"))
    import api_inputs_standalone as api

    monkeypatch.setattr(api, "_STANDALONE_ROOT", tmp_path)
    contenu = "CRYSTAL\nPRIMVEC\n1 0 0\n0 1 0\n0 0 1\nPRIMCOORD\n1 1\n14 0 0 0\n"
    dest, err = api._save_structure_xsf("Si.xsf", contenu)
    assert err is None
    assert dest is not None
    assert dest.name == "Si.xsf"
    assert dest.parent.name == "Si"
    assert "structures_xsf" in dest.parts
    assert dest.is_file()
    hist = list(dest.parent.glob("Si_*.xsf"))
    assert len(hist) >= 1

"""Tests extraction fragments HTML (P1)."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def test_fragment_gestion_exists():
    frag = ROOT / "fragments" / "subsection_gestion.html"
    assert frag.is_file()
    text = frag.read_text(encoding="utf-8")
    assert 'id="subsection_gestion"' in text
    assert 'id="liste_fichiers_cif"' in text
    assert 'id="editeur_cif_zone"' in text


def test_index_uses_fragment_mount():
    html = (ROOT / "index.html").read_text(encoding="utf-8")
    assert 'data-fragment="fragments/subsection_gestion.html"' in html
    assert 'id="subsection_gestion_mount"' in html
    assert 'id="liste_fichiers_cif"' not in html


def test_fragment_loader_script():
    js = (ROOT / "scripts" / "load_html_fragments.js").read_text(encoding="utf-8")
    assert "htmlFragmentsLoaded" in js
    assert "loadHtmlFragments" in js


def test_cif_gestion_init_script():
    js = (ROOT / "scripts" / "cif_gestion_init.js").read_text(encoding="utf-8")
    assert "initCifGestionAfterFragment" in js
    assert "ensureSubsectionGestionInTab1" in js
    html = (ROOT / "index.html").read_text(encoding="utf-8")
    assert "cif_gestion_init.js" in html
    idx_mount = html.find('subsection_gestion_mount')
    idx_card_close = html.rfind('fin .card tab1 principal', 0, idx_mount)
    assert idx_card_close >= 0, "mount CIF doit être après la fermeture du .card tab1"


def test_calc_type_selects_refresh_after_fragments():
    js = (ROOT / "scripts" / "qe_calc_type_options.js").read_text(encoding="utf-8")
    assert "htmlFragmentsLoaded" in js
    assert "populateAllCalcTypeSelects" in js
    dft = (ROOT / "scripts" / "qe_input_dft_options.js").read_text(encoding="utf-8")
    assert "htmlFragmentsLoaded" in dft
    assert "cif_input_dft" in dft


def test_index_smaller_after_extraction():
    lines = len((ROOT / "index.html").read_text(encoding="utf-8").splitlines())
    assert lines < 20000, f"index.html encore trop volumineux: {lines} lignes"

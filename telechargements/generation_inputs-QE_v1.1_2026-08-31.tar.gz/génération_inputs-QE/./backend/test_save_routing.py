"""Vérifie le routage des sauvegardes vers inputs_générés_direct vs inputs_convertis_cif."""
from pathlib import Path

import api_inputs_standalone as api


def test_outputs_roots_separate():
    direct = api._outputs_root_for("direct")
    cif = api._outputs_root_for("cif")
    assert direct != cif
    assert direct.name == "inputs_générés_direct"
    assert cif.name == "inputs_convertis_cif"


def test_path_under_write_roots_rejects_old_folder():
    old = api._STANDALONE_ROOT / "inputs_générés" / "old.in"
    assert not api._path_under_write_roots(old)


def test_path_under_write_roots_accepts_both():
    direct = api._outputs_root_for("direct") / "Mat" / "Mat_scf.in"
    cif = api._outputs_root_for("cif") / "Mat" / "Mat_scf.in"
    assert api._path_under_write_roots(direct)
    assert api._path_under_write_roots(cif)


def test_api_inputs_save_flat_layout():
    """POST /api/inputs/save layout=flat → material/material_calc.in"""
    import json
    from api_inputs_standalone import app

    client = app.test_client()
    payload = {
        "text": "&CONTROL\n calculation = 'scf'\n/",
        "material": "FlatTest",
        "calculation_label": "scf",
        "source": "direct",
        "layout": "flat",
    }
    r = client.post("/api/inputs/save", data=json.dumps(payload), content_type="application/json")
    assert r.status_code == 200
    data = r.get_json()
    assert data["ok"] is True
    assert data["filename"] == "FlatTest_scf.in"
    assert data["relative"] == "FlatTest/FlatTest_scf.in"
    p = api._outputs_root_for("direct") / "FlatTest" / "FlatTest_scf.in"
    assert p.is_file()

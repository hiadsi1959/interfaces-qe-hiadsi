"""Tests script configuration PC destination."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def test_configurer_exists_and_executable():
    p = ROOT / "CONFIGURER.sh"
    assert p.is_file()
    text = p.read_text(encoding="utf-8")
    assert "config_pc.env" in text
    assert "config_pc_local.js" in text
    assert "VERIFIER.sh" in text
    assert "fragments/subsection_gestion.html" in text
    assert "pseudos/PBE" in text


def test_obsolete_config_scripts_removed():
    for name in ("config_autres_pc.sh", "configurer_autrepc.sh", "INSTALLER.sh", "RELANCER.sh"):
        assert not (ROOT / name).is_file(), f"{name} should be removed"

#!/usr/bin/env python3
"""Tests catalogue types inputs + conformité QE 7.5+ (tous types pw + auxiliaires)."""
from __future__ import annotations

import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(__file__))

from cif_to_qe import analyze_cif, build_pw_input
from qe_input_types_catalog import (
    AUX_INPUT_TYPES,
    PW_CALC_TYPES,
    is_valid_pw_calculation,
    load_catalog,
    normalize_pw_calculation,
)
from qe75_verifier import verify_pw_qe75, verify_qe75
from qe_input_builders import build_aux_input, bands_kpath_crystal_b

DATA = os.path.join(os.path.dirname(__file__), "..", "data")


def _cif(name: str) -> str:
    return os.path.join(DATA, name)


@pytest.fixture(scope="module")
def si_cif():
    return analyze_cif(_cif("Si.cif"))


@pytest.mark.parametrize("calc", sorted(PW_CALC_TYPES - {"scf_berry", "scf_born"}))
def test_build_pw_all_calc_types(si_cif, calc: str):
    text = build_pw_input(si_cif, calculation=calc, ecutwfc=50, ecutrho=400)
    assert f"calculation = '{calc}'" in text
    res = verify_pw_qe75(text, strict=True)
    assert res.ok, f"{calc}: {res.errors}"


@pytest.mark.parametrize("calc,needle", [
    ("scf_berry", "&BP"),
    ("scf_born", "1.0d-12"),
])
def test_build_pw_polarization_types(si_cif, calc: str, needle: str):
    text = build_pw_input(si_cif, calculation=calc, ecutwfc=50, ecutrho=400)
    assert "calculation = 'scf'" in text
    assert needle in text
    res = verify_pw_qe75(text, strict=False)
    assert res.ok, f"{calc}: {res.errors}"


def test_nscf_has_nbnd_and_restart(si_cif):
    text = build_pw_input(si_cif, calculation="nscf", ecutwfc=50, ecutrho=400)
    assert "restart_mode= 'restart'" in text
    assert "nbnd =" in text
    assert "tetrahedra" in text


def test_bands_has_crystal_b(si_cif):
    text = build_pw_input(si_cif, calculation="bands", ecutwfc=50, ecutrho=400, ibrav_override=2)
    assert "K_POINTS crystal_b" in text
    assert "restart_mode= 'restart'" in text


def test_md_has_verlet_ions(si_cif):
    text = build_pw_input(si_cif, calculation="md", ecutwfc=50, ecutrho=400)
    assert "ion_dynamics = 'verlet'" in text
    assert "tempw" in text
    res = verify_pw_qe75(text, strict=True)
    assert res.ok, res.errors


def test_vc_md_has_ions_and_cell(si_cif):
    text = build_pw_input(si_cif, calculation="vc-md", ecutwfc=50, ecutrho=400)
    assert "calculation = 'vc-md'" in text
    assert "ion_dynamics = 'verlet'" in text
    assert "&CELL" in text
    res = verify_pw_qe75(text, strict=True)
    assert res.ok, res.errors


@pytest.mark.parametrize("pkg", sorted(AUX_INPUT_TYPES))
def test_aux_templates_verify(pkg: str):
    text = build_aux_input(pkg, prefix="Si")
    res = verify_qe75(text, package=pkg, strict=True)
    assert res.ok, f"{pkg}: {res.errors}"


def test_catalog_loads():
    cat = load_catalog()
    assert cat.get("qe_version_min") == "7.5"
    pkgs = cat.get("packages") or []
    assert len(pkgs) >= 10
    ids = {p["id"] for p in pkgs}
    assert "pw" in ids
    assert "dos" in ids
    assert "ph" in ids


def test_normalize_pw_calculation():
    assert normalize_pw_calculation("BANDS") == "bands"
    assert normalize_pw_calculation("invalid") == "scf"
    assert is_valid_pw_calculation("relax") is True
    assert is_valid_pw_calculation("dos") is False


def test_bands_kpath_fcc():
    path = bands_kpath_crystal_b(2)
    assert "K_POINTS crystal_b" in path
    assert "Gamma" in path or "0.0000" in path


def test_reject_nspin4_in_verifier(si_cif):
    text = build_pw_input(si_cif, calculation="scf", nspin=4, ecutwfc=50, ecutrho=400)
    assert "nspin = 4" not in text
    bad = text + "\n  nspin = 4\n"
    res = verify_pw_qe75(bad, strict=True)
    assert not res.ok
    assert any("nspin=4" in e for e in res.errors)

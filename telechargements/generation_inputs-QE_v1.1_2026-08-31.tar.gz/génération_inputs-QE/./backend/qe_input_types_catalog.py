"""Catalogue des types d'inputs Quantum ESPRESSO (QE 7.5+)."""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

_ROOT = Path(__file__).resolve().parent.parent
_CATALOG_PATH = _ROOT / "data" / "qe_input_types_catalog.json"

PW_CALC_TYPES = frozenset({"scf", "relax", "vc-relax", "nscf", "bands", "md", "vc-md", "scf_berry", "scf_born"})
AUX_INPUT_TYPES = frozenset({
    "dos", "bands_pp", "projwfc",
    "pp", "pp_charge", "pp_potential", "pp_ldos", "pp_elf", "pp_vh", "pp_spin",
    "average", "plotrho", "plotband",
    "epsilon", "turbo_lanczos", "turbo_davidson", "turbo_eels", "xspectra",
    "ph", "ph_zeu", "q2r", "matdyn", "matdyn_disp", "matdyn_dos", "matdyn_thermo", "dynmat",
    "alpha2f", "lambda",
    "hp", "epw", "cp", "neb", "pw2wan",
})
ALL_INPUT_TYPES = PW_CALC_TYPES | AUX_INPUT_TYPES


@lru_cache(maxsize=1)
def load_catalog() -> dict[str, Any]:
    with _CATALOG_PATH.open(encoding="utf-8") as fh:
        return json.load(fh)


def catalog_path() -> Path:
    return _CATALOG_PATH


def list_packages() -> list[dict[str, Any]]:
    return list(load_catalog().get("packages") or [])


def get_package(package_id: str) -> dict[str, Any] | None:
    pid = str(package_id or "").strip().lower()
    for pkg in list_packages():
        if str(pkg.get("id", "")).lower() == pid:
            return pkg
    return None


def pw_calculation_types() -> dict[str, Any]:
    return dict(load_catalog().get("pw_calculation_types") or {})


def is_valid_pw_calculation(calculation: str) -> bool:
    return str(calculation or "scf").strip().lower() in PW_CALC_TYPES


def is_valid_input_type(calculation: str) -> bool:
    return str(calculation or "scf").strip().lower() in ALL_INPUT_TYPES


def is_aux_input_type(calculation: str) -> bool:
    return str(calculation or "").strip().lower() in AUX_INPUT_TYPES


def normalize_pw_calculation(calculation: str) -> str:
    calc = str(calculation or "scf").strip().lower()
    if calc in AUX_INPUT_TYPES:
        return calc
    return calc if calc in PW_CALC_TYPES else "scf"


def normalize_input_type(calculation: str) -> str:
    calc = str(calculation or "scf").strip().lower()
    return calc if calc in ALL_INPUT_TYPES else "scf"


def catalog_summary() -> dict[str, Any]:
    cat = load_catalog()
    pkgs = list_packages()
    by_status: dict[str, int] = {}
    for p in pkgs:
        st = str(p.get("status") or "unknown")
        by_status[st] = by_status.get(st, 0) + 1
    return {
        "qe_version_min": cat.get("qe_version_min", "7.5"),
        "package_count": len(pkgs),
        "pw_calculation_types": sorted(PW_CALC_TYPES),
        "by_status": by_status,
        "catalog_path": str(_CATALOG_PATH),
    }

"""Tests résolution classe matériau (convergence_profiles.js — logique miroir Python)."""
from __future__ import annotations

import pytest


def test_detect_material_class_gdvo3():
    from cif_to_qe import detect_material_class, MaterialClass

    mc = detect_material_class("GdVO3", ["Gd", "V", "O"])
    assert mc == MaterialClass.RARE_EARTH


def test_detect_material_class_batio3():
    from cif_to_qe import detect_material_class, MaterialClass

    mc = detect_material_class("BaTiO3", ["Ba", "Ti", "O"])
    assert mc == MaterialClass.INSULATOR


def test_detect_material_class_si():
    from cif_to_qe import detect_material_class, MaterialClass

    mc = detect_material_class("Si", ["Si"])
    assert mc == MaterialClass.SEMICONDUCTOR

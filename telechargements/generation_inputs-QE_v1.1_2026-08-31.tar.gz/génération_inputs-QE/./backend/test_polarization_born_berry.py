"""Tests phase de Berry et charges effectives de Born."""
from __future__ import annotations

import os
import re
import sys

import pytest

sys.path.insert(0, os.path.dirname(__file__))

from cif_to_qe import analyze_cif, build_pw_input
from qe_input_builders import build_aux_input
from qe75_verifier import verify_qe75
from qe_input_types_catalog import is_aux_input_type, is_valid_pw_calculation

DATA = os.path.join(os.path.dirname(__file__), "..", "data")


@pytest.fixture(scope="module")
def si_cif():
    return analyze_cif(os.path.join(DATA, "Si.cif"))


def test_catalog_polarization_types():
    assert is_valid_pw_calculation("scf_berry")
    assert is_valid_pw_calculation("scf_born")
    assert is_aux_input_type("ph_zeu")


def test_scf_berry_bp_namelist(si_cif):
    text = build_pw_input(si_cif, calculation="scf_berry", gdir=2, nppstr=6, ecutwfc=50, ecutrho=400)
    assert "calculation = 'scf'" in text
    assert "&BP" in text
    assert "lberry" in text
    assert "gdir   = 2" in text
    assert "nppstr = 6" in text
    assert "lelfield" not in text
    ctrl = re.search(r"&CONTROL([\s\S]*?)^\s*/\s*$", text, re.MULTILINE | re.IGNORECASE)
    assert ctrl is None or "lberry" not in ctrl.group(1).lower()


def test_api_build_scf_berry_includes_bp(si_cif):
    """POST /api/inputs/build avec calculation=scf_berry → &BP avec lberry."""
    import json

    from api_inputs_standalone import app

    client = app.test_client()
    positions = [
        {"symbol": sym, "x": x, "y": y, "z": z}
        for sym, x, y, z in si_cif.atomic_positions_crystal
    ]
    analysis = {
        "formula": si_cif.formula,
        "ibrav": si_cif.ibrav,
        "celldm": si_cif.celldm,
        "nat": si_cif.nat,
        "ntyp": si_cif.ntyp,
        "atomic_species": list(si_cif.atomic_species),
        "atomic_positions_crystal": positions,
        "a": si_cif.a,
        "b": si_cif.b,
        "c": si_cif.c,
    }
    payload = {
        "analysis": analysis,
        "calculation": "scf_berry",
        "prefix": "Si",
        "pseudo_dir": "./pseudos",
        "outdir": "./out",
        "k_points": [4, 4, 4],
        "gdir": 2,
        "nppstr": 5,
    }
    r = client.post("/api/inputs/build", data=json.dumps(payload), content_type="application/json")
    assert r.status_code == 200, r.get_data(as_text=True)
    data = r.get_json()
    text = data.get("text") or ""
    assert "&BP" in text
    assert "lberry" in text
    assert "gdir   = 2" in text
    assert "nppstr = 5" in text
    assert "lelfield" not in text


def test_scf_born_tight_conv_thr(si_cif):
    text = build_pw_input(si_cif, calculation="scf_born", ecutwfc=50, ecutrho=400)
    assert "conv_thr    = 1.0d-12" in text


def test_ph_zeu_template():
    text = build_aux_input("ph_zeu", prefix="BaTiO3", outdir="./out/")
    assert "zeu" in text
    assert ".true." in text
    assert "0.0 0.0 0.0" in text
    assert "ldisp    = .false." in text
    res = verify_qe75(text, package="ph", strict=False)
    assert res.ok, res.errors


def test_ph_zeu_epsil_option():
    text = build_aux_input("ph_zeu", prefix="Si", epsil=True)
    assert "epsil" in text

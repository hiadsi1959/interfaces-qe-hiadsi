"""Tests indicateur workflow unifié Tab 1 (direct + CIF)."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TRACKER = ROOT / "scripts" / "script_tab1_workflow_tracker.js"
ORCH = ROOT / "scripts" / "script_orchestration_generation.js"
GEST = ROOT / "scripts" / "script_gestion_fichiers_complet.js"
CSS = ROOT / "styles" / "qe_scientific_theme.css"
INDEX = ROOT / "index.html"


def test_workflow_tracker_fichier_present():
    assert TRACKER.is_file()


def test_workflow_tracker_api_unifiee():
    text = TRACKER.read_text(encoding="utf-8")
    for needle in (
        "tab1_workflow_tracker",
        "tab1SetWorkflowPath",
        "tab1RefreshWorkflowTracker",
        "tab1MountWorkflowShell",
        "PATHS",
        "direct",
        "cif",
    ):
        assert needle in text, f"manquant: {needle}"


def test_workflow_tracker_lie_index():
    html = INDEX.read_text(encoding="utf-8")
    assert "script_tab1_workflow_tracker.js" in html


def test_hooks_generation_direct():
    text = ORCH.read_text(encoding="utf-8")
    assert "tab1SetWorkflowStep(5, 'generating')" in text
    assert "tab1HighlightWorkflowFromScroll" in text


def test_hooks_generation_cif():
    text = GEST.read_text(encoding="utf-8")
    assert "tab1SetWorkflowPath('cif')" in text
    assert "tab1SetWorkflowStep(5, 'generating')" in text


def test_css_workflow_tracker():
    css = CSS.read_text(encoding="utf-8")
    assert ".tab1-workflow-tracker" in css
    assert ".tab1-workflow-mounted #tab1_stepper" in css


def test_enchainement_stepper_preserve():
    """Le stepper existant et son update ne doivent pas être supprimés."""
    ux = (ROOT / "scripts" / "script_tab1_ux_finalisation.js").read_text(encoding="utf-8")
    assert "tab1UpdateStepper" in ux
    tracker = TRACKER.read_text(encoding="utf-8")
    assert "patchTab1UpdateStepper" in tracker

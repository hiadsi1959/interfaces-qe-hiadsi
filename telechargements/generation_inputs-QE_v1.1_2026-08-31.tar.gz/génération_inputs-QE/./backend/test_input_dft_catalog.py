"""Tests catalogue input_dft QE 7.5."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
CATALOG = ROOT / "data" / "qe_input_dft_catalog.json"

# Fonctionnelles qe_dft_list.f90 absentes avant complément
REQUIRED_QE75 = frozenset({
    "pw", "oep", "kli", "hf", "b88", "pbc",
    "pbe-ah", "pbesol-ah", "rscan", "pbeq2d",
})

REQUIRED_VDW = frozenset({
    "vdw-df", "vdw-df2", "vdw-df-ahcx", "vdw-df-c6", "rvv10", "rvv10-scan",
})

REQUIRED_BEEF = frozenset({"beef", "beef-vdw", "beef_lxc"})


def test_catalog_file_exists():
    assert CATALOG.is_file(), f"manquant : {CATALOG}"


def test_catalog_covers_qe75_core():
    data = json.loads(CATALOG.read_text(encoding="utf-8"))
    values = frozenset(data["values"])
    missing = REQUIRED_QE75 - values
    assert not missing, f"fonctionnelles QE manquantes : {sorted(missing)}"


def test_catalog_covers_vdw_beef():
    data = json.loads(CATALOG.read_text(encoding="utf-8"))
    values = frozenset(data["values"])
    assert REQUIRED_VDW <= values
    assert REQUIRED_BEEF <= values


def test_catalog_minimum_count():
    data = json.loads(CATALOG.read_text(encoding="utf-8"))
    assert data["count"] >= 70


def test_normalize_aliases():
    from qe_input_dft_catalog import normalize_input_dft

    assert normalize_input_dft("lda") == "pz"
    assert normalize_input_dft("  PBE  ") == "pbe"
    assert normalize_input_dft("sca0") == "scan0"
    assert normalize_input_dft("XC-001i-004i") == "XC-001I-004I"
    assert normalize_input_dft("") is None


def test_js_optgroups_synced():
    js = (ROOT / "scripts" / "qe_input_dft_options.js").read_text(encoding="utf-8")
    data = json.loads(CATALOG.read_text(encoding="utf-8"))
    for val in ("pbe", "rscan", "vdw-df-ahcx"):
        assert f"['{val}'" in js or f'["{val}"' in js, f"{val} absent du JS généré"

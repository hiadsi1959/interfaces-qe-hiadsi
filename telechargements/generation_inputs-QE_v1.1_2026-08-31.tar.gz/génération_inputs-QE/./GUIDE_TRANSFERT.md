# Guide de transfert — Génération Inputs QE

Ce guide décrit comment déplacer l’interface **génération_inputs-QE** vers un autre PC (Ubuntu / Linux), la réinstaller et vérifier que la **génération directe** et le flux **CIF → input** fonctionnent (y compris le mode **non colinéaire** avec pseudos FR).

---

## 1. Sur le PC actuel (source)

### 1.1 Vérification

```bash
cd "/chemin/vers/génération_inputs-QE"
chmod +x VERIFIER.sh build_generation_inputs.sh DEMARRER.sh CONFIGURER.sh
./VERIFIER.sh
```

Tous les tests doivent être **✅** (les ⚠️ pseudos sont normaux si vous n’avez pas encore copié les `.UPF`).

### 1.2 Construire l’installateur unique (recommandé)

```bash
./build_generation_inputs.sh
```

Produit **`generation_inputs`** à la racine du projet : un seul fichier exécutable, prêt à copier.

### 1.3 Copier vers l’autre PC

**SCP (réseau)** :

```bash
scp ~/génération_inputs-QE/generation_inputs utilisateur@IP_DU_PC:~/
```

**Clé USB** : copiez uniquement le fichier `generation_inputs`.

Les pseudopotentiels (`pseudos/PBE`, `pseudos/PBE_FR`) sont inclus dans l’installateur s’ils sont présents sur le PC source au moment du build.

### 1.4 Alternative : archive `.tar.gz`

```bash
./compacter.sh
scp generation_inputs-QE_transfert_*.tar.gz utilisateur@IP_DU_PC:~/
```

Voir la section 2 ci-dessous pour l’extraction manuelle.

---

## 2. Sur le PC destination

### 2.1 Prérequis

- **Ubuntu / Debian** (ou Linux avec `python3`, `bash`, `tar`)
- Connexion Internet pour `pip` (première installation)
- Navigateur (Firefox, Chromium…)
- **Quantum ESPRESSO** (`pw.x`) — optionnel pour *générer* des inputs, requis pour *lancer* les calculs

### 2.2 Installation avec `generation_inputs` (recommandé)

```bash
chmod +x generation_inputs
./generation_inputs
```

Installation silencieuse + démarrage immédiat :

```bash
./generation_inputs --yes --start
```

Autre dossier d’installation :

```bash
./generation_inputs --install-dir ~/opt/generation_inputs-QE
```

Par défaut, les fichiers sont extraits dans **`~/generation_inputs-QE`**, puis **`CONFIGURER.sh`** s’exécute automatiquement (apt, pip, détection QE, `config_pc.env`, `config_pc_local.js`).

### 2.3 Alternative : archive `.tar.gz`

```bash
cd ~
tar -xzf generation_inputs-QE_transfert_*.tar.gz
cd génération_inputs-QE   # ou generation_inputs-QE selon l’archive
chmod +x CONFIGURER.sh DEMARRER.sh
./CONFIGURER.sh
```

### 2.4 Pseudopotentiels

Par défaut, l’interface pointe vers les dossiers **locaux** du projet :

```bash
mkdir -p pseudos/PBE pseudos/PBE_FR
# Copiez vos .UPF dans ces dossiers
ls pseudos/PBE_FR/*.UPF | head
```

Seul le chemin de **Quantum ESPRESSO** (`QE_BIN_DIR`) est vraiment spécifique à chaque PC. Les pseudos : copiez les vôtres, puis sélectionnez-les dans l’interface.

Pour **EuGaCl3 non colinéaire**, vérifiez la présence de fichiers du type :

- `Eu.rel-pbe-spfn-rrkjus_psl.1.0.0.UPF`
- `Ga.rel-pbe-dn-kjpaw_psl.1.0.0.UPF`
- `Cl.rel-pbe-n-rrkjus_psl.1.0.0.UPF`

### 2.5 Démarrer l’interface

```bash
cd ~/generation_inputs-QE   # ou votre --install-dir
./DEMARRER.sh
```

Si la configuration n’existe pas encore, `DEMARRER.sh` lance automatiquement `CONFIGURER.sh --yes --minimal`.

Ouvrez : **http://127.0.0.1:5012/**  
Au premier chargement : **Ctrl+F5** (cache navigateur).

Arrêt : `./ARRETER.sh` — Redémarrage : `./ARRETER.sh` puis `./DEMARRER.sh`

### 2.6 Vérification post-installation

```bash
./VERIFIER.sh
curl -s http://127.0.0.1:5012/api/health
```

---

## 3. Tests fonctionnels recommandés

### A. Génération directe (BaTiO3)

1. Onglet **⚡ Génération direct**  
2. Exemple **BaTiO3**  
3. Type calcul **SCF**  
4. **⚡ GÉNÉRER INPUT COMPLET** → aperçu → **💾 SAUVEGARDER**

### B. CIF → input (GdVO3 ou autre)

1. Onglet **🔬 Gestion des fichiers CIF**  
2. Ouvrir un `.cif` (ex. `data/fichiers_cif/GdVO3_mp-541177_primitive.cif`)  
3. **CONVERTIR CIF → INPUT QE**

### C. Non colinéaire (EuGaCl3)

1. Charger structure (CIF ou saisie manuelle)  
2. Magnétisme : **Non-colinéaire**  
3. Vérifier dans l’input généré :

```fortran
noncolin = .true.
lspinorb = .true.
mixing_beta = 0.15    ! (entre 0.15 et 0.25)
pseudo_dir = '.../pseudos/PBE_FR'
```

Et dans `ATOMIC_SPECIES` : pseudos **`.rel-pbe-*`**, pas `.pbe-spn` / `.pbe-dn`.

---

## 4. Configuration des chemins

Sur chaque PC, `./CONFIGURER.sh` génère :

| Fichier | Rôle |
|---------|------|
| `config_pc.env` | Chemins pour les scripts shell |
| `scripts/config_pc_local.js` | Chemins pour l’interface web |

| Clé | Rôle |
|-----|------|
| `INPUTS_GENERES_DIR` | Inputs sauvegardés (direct) |
| `PSEUDO_DIR` | Pseudos scalar (`pseudos/PBE`) |
| `PSEUDO_FR_DIR` | Pseudos full-relativistic (`pseudos/PBE_FR`) |
| `QE_BIN_DIR` | Dossier `bin` de Quantum ESPRESSO |

Après transfert depuis un autre PC, si l’interface affiche d’anciens chemins :

```javascript
localStorage.removeItem('qe_inputs_config');
location.reload();
```

---

## 5. Dépannage

| Problème | Action |
|----------|--------|
| Page blanche / bouton inactif | Ctrl+F5 ; vérifier la console (F12) |
| Port 5012 occupé | `./ARRETER.sh` puis `./DEMARRER.sh` |
| Conversion CIF échoue | `./CONFIGURER.sh` ; relire `.gen_inputs.log` |
| pw.x crash non colinéaire | Pseudos **FR** manquants ou `lspinorb=.false.` |
| Chemins refusés à la sauvegarde | Utiliser `inputs_générés_direct/<matériau>/` (zone autorisée API 5012) |
| Installateur corrompu | Reconstruire avec `./build_generation_inputs.sh` sur le PC source |

Logs serveur : `.gen_inputs.log` à la racine du projet.

---

## 6. Contenu embarqué

Inclus dans `generation_inputs` / l’archive :

- `index.html`, `scripts/`, `backend/`, `data/` (CIF d’exemple)
- `DEMARRER.sh`, `CONFIGURER.sh`, `GUIDE_TRANSFERT.md`, `VERIFIER.sh`

Exclus (régénérables ou propres au PC) :

- `.backup_*`, `__pycache__`, `.gen_inputs.log`, `.gen_inputs.pid`
- `config_pc.env`, `config_pc_local.js` (recréés à l’installation)
- `inputs_générés_direct/*`, `inputs_convertis_cif/*`, `outputs/*` (dossiers recréés vides)

---

## 7. Checklist rapide

- [ ] `./VERIFIER.sh` OK sur le PC source  
- [ ] `./build_generation_inputs.sh` → fichier `generation_inputs`  
- [ ] `generation_inputs` copié sur le PC destination  
- [ ] `./generation_inputs` (ou `--yes --start`)  
- [ ] `pseudos/PBE_FR/` rempli si besoin  
- [ ] `./DEMARRER.sh` → http://127.0.0.1:5012  
- [ ] Test BaTiO3 + test CIF + test non colinéaire  

---

*Interface autonome — port 5012 — aucune dépendance à Interface-QE_v1 pour la génération d’inputs.*

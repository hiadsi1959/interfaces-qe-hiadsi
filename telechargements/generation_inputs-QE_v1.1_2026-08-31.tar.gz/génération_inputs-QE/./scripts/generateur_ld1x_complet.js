// ═══════════════════════════════════════════════════════════════════════════════
// GÉNÉRATEUR LD1.X COMPLET POUR TOUS LES ÉLÉMENTS
// ═══════════════════════════════════════════════════════════════════════════════

function ouvrirGenerateurLD1XComplet(symbole, nom) {
    console.log(`🔬 Ouverture du générateur ld1.x complet pour ${symbole}`);
    
    // Vérifier que les configurations sont chargées
    if (typeof CONFIGURATIONS_ELECTRONIQUES === 'undefined' || typeof OPTIONS_LD1X_COMPLETES === 'undefined') {
        alert('❌ Erreur: Les fichiers de configuration ne sont pas chargés.\n\nAssurez-vous que configurations_ld1x_completes.js est présent.');
        return;
    }
    
    // Récupérer la configuration de l'élément
    const config = CONFIGURATIONS_ELECTRONIQUES[symbole];
    if (!config) {
        alert(`❌ Configuration non disponible pour ${symbole}\n\nCet élément n'est pas encore supporté.`);
        return;
    }
    
    // Récupérer les informations de l'élément
    const element = ELEMENTS[symbole];
    const Z = element.numero;
    
    // Déterminer les paramètres recommandés
    const relRecommended = Z < 20 ? '0' : (Z > 50 ? '2' : '1');
    const nlccRecommended = Z > 20 ? 'true' : 'false';
    
    // Créer la modal
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.85);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        overflow-y: auto;
    `;
    
    modal.innerHTML = `
        <div style="background: white; border-radius: 15px; max-width: 1600px; width: 100%; max-height: 95vh; display: flex; flex-direction: column; box-shadow: 0 10px 40px rgba(0,0,0,0.5); overflow: hidden;">
            <!-- En-tête -->
            <div style="padding: 25px; border-bottom: 3px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                <div>
                    <h2 style="margin: 0 0 5px 0;">🔬 Générateur ld1.x Complet</h2>
                    <p style="margin: 0; opacity: 0.9; font-size: 1.1em;">
                        <strong>${nom} (${symbole})</strong> - Z = ${Z} - ${config.config}
                    </p>
                </div>
                <button onclick="this.closest('div[style*=\\'position: fixed\\']').remove()" 
                        style="background: rgba(255,255,255,0.2); color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1.1em;">
                    ❌ Fermer
                </button>
            </div>
            
            <!-- Contenu -->
            <div style="padding: 25px; overflow-y: auto; flex: 1;">
                <div id="generateur_ld1x_content_${symbole}">
                    <!-- Le contenu sera chargé ici -->
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Charger le contenu
    setTimeout(() => {
        chargerGenerateurLD1XComplet(symbole, nom, Z, config, relRecommended, nlccRecommended);
    }, 100);
}

function chargerGenerateurLD1XComplet(symbole, nom, Z, config, relRecommended, nlccRecommended) {
    const container = document.getElementById(`generateur_ld1x_content_${symbole}`);
    
    if (!container) {
        console.error('Container non trouvé');
        return;
    }
    
    const opts = OPTIONS_LD1X_COMPLETES;
    
    container.innerHTML = `
        <div style="display: grid; gap: 25px;">
            
            <!-- Informations de l'élément -->
            <div class="card" style="background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%); border: 2px solid #3b82f6;">
                <h3 style="margin-top: 0; color: #1e40af;">📊 Informations de l'élément</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                    <div>
                        <strong>Symbole:</strong> ${symbole}<br>
                        <strong>Nom:</strong> ${nom}<br>
                        <strong>Numéro atomique:</strong> ${Z}
                    </div>
                    <div>
                        <strong>Configuration:</strong> ${config.config}<br>
                        <strong>Électrons de valence:</strong> ${config.valence}<br>
                        <strong>Cœur:</strong> ${config.core || 'Aucun'}
                    </div>
                </div>
            </div>
            
            <!-- Type de pseudopotentiel -->
            <div class="card">
                <h3 style="margin-top: 0;">⚙️ ${opts.pseudotype.label}</h3>
                <select id="ld1x_pseudotype_${symbole}" class="form-control" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 1em;" onchange="updateEcutRecommendations('${symbole}')">
                    ${opts.pseudotype.options.map(opt => `
                        <option value="${opt.value}" ${opt.value === opts.pseudotype.default ? 'selected' : ''}>
                            ${opt.label} - ${opt.description}
                        </option>
                    `).join('')}
                </select>
                <div id="pseudotype_info_${symbole}" style="margin-top: 10px; padding: 10px; background: #f0f9ff; border-radius: 6px; font-size: 0.9em;"></div>
            </div>
            
            <!-- Effets relativistes -->
            <div class="card">
                <h3 style="margin-top: 0;">⚡ ${opts.relativistic.label}</h3>
                <select id="ld1x_relativistic_${symbole}" class="form-control" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 1em;">
                    ${opts.relativistic.options.map(opt => `
                        <option value="${opt.value}" ${opt.value === relRecommended ? 'selected' : ''}>
                            ${opt.label} - ${opt.description}
                        </option>
                    `).join('')}
                </select>
                <div style="margin-top: 10px; padding: 10px; background: #fef3c7; border-radius: 6px; font-size: 0.9em;">
                    💡 <strong>Recommandé pour Z=${Z}:</strong> ${opts.relativistic.options.find(o => o.value === relRecommended).label}
                </div>
            </div>
            
            <!-- Fonctionnelle XC -->
            <div class="card">
                <h3 style="margin-top: 0;">🧮 ${opts.functional.label}</h3>
                <select id="ld1x_functional_${symbole}" class="form-control" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 1em;">
                    ${opts.functional.options.map(opt => `
                        <option value="${opt.value}" ${opt.value === opts.functional.default ? 'selected' : ''}>
                            ${opt.label} (${opt.type}) - ${opt.description}
                        </option>
                    `).join('')}
                </select>
            </div>
            
            <!-- NLCC -->
            <div class="card">
                <h3 style="margin-top: 0;">🎯 ${opts.nlcc.label}</h3>
                <select id="ld1x_nlcc_${symbole}" class="form-control" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 1em;">
                    ${opts.nlcc.options.map(opt => `
                        <option value="${opt.value}" ${opt.value === nlccRecommended ? 'selected' : ''}>
                            ${opt.label} - ${opt.description}
                        </option>
                    `).join('')}
                </select>
                <div style="margin-top: 10px; padding: 10px; background: #fef3c7; border-radius: 6px; font-size: 0.9em;">
                    💡 <strong>Recommandé pour Z=${Z}:</strong> ${nlccRecommended === 'true' ? 'Activé' : 'Désactivé'}
                </div>
            </div>
            
            <!-- Cutoffs -->
            <div class="card" style="background: #f0fdf4; border: 2px solid #10b981;">
                <h3 style="margin-top: 0; color: #065f46;">⚡ Cutoffs d'énergie</h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div>
                        <label style="font-weight: 600; display: block; margin-bottom: 8px;">${opts.ecutwfc.label}:</label>
                        <input type="number" id="ld1x_ecutwfc_${symbole}" 
                               value="${opts.ecutwfc.default}" 
                               min="${opts.ecutwfc.min}" 
                               max="${opts.ecutwfc.max}" 
                               step="${opts.ecutwfc.step}"
                               onchange="updateEcutrho('${symbole}')"
                               style="width: 100%; padding: 10px; border: 2px solid #e5e7eb; border-radius: 6px; font-size: 1em;">
                        <small style="color: #666;">${opts.ecutwfc.description}</small>
                    </div>
                    <div>
                        <label style="font-weight: 600; display: block; margin-bottom: 8px;">${opts.ecutrho.label}:</label>
                        <input type="number" id="ld1x_ecutrho_${symbole}" 
                               value="${opts.ecutrho.default}" 
                               min="${opts.ecutrho.min}" 
                               max="${opts.ecutrho.max}" 
                               step="${opts.ecutrho.step}"
                               style="width: 100%; padding: 10px; border: 2px solid #e5e7eb; border-radius: 6px; font-size: 1em;">
                        <small style="color: #666;">${opts.ecutrho.description}</small>
                    </div>
                </div>
            </div>
            
            <!-- Rayons de coupure -->
            <div class="card">
                <h3 style="margin-top: 0;">📏 ${opts.rcut.label}</h3>
                <p style="color: #666; margin-bottom: 15px;">${opts.rcut.description}</p>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px;">
                    ${opts.rcut.canaux.map(canal => `
                        <div>
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Canal ${canal}:</label>
                            <input type="number" id="ld1x_rcut_${canal}_${symbole}" 
                                   value="${opts.rcut.default[canal]}" 
                                   min="${opts.rcut.min}" 
                                   max="${opts.rcut.max}" 
                                   step="${opts.rcut.step}"
                                   style="width: 100%; padding: 8px; border: 2px solid #e5e7eb; border-radius: 6px;">
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <!-- Rayon local et canal local -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="card">
                    <h3 style="margin-top: 0;">📍 ${opts.rcloc.label}</h3>
                    <p style="color: #666; margin-bottom: 10px;">${opts.rcloc.description}</p>
                    <input type="number" id="ld1x_rcloc_${symbole}" 
                           value="${opts.rcloc.default}" 
                           min="${opts.rcloc.min}" 
                           max="${opts.rcloc.max}" 
                           step="${opts.rcloc.step}"
                           style="width: 100%; padding: 10px; border: 2px solid #e5e7eb; border-radius: 8px;">
                </div>
                
                <div class="card">
                    <h3 style="margin-top: 0;">🎯 ${opts.local_channel.label}</h3>
                    <select id="ld1x_local_channel_${symbole}" class="form-control" style="width: 100%; padding: 10px; border: 2px solid #e5e7eb; border-radius: 8px;">
                        ${opts.local_channel.options.map(opt => `
                            <option value="${opt.value}" ${opt.value === opts.local_channel.default ? 'selected' : ''}>
                                ${opt.label} - ${opt.description}
                            </option>
                        `).join('')}
                    </select>
                </div>
            </div>
            
            <!-- Tests de validation -->
            <div class="card" style="background: #fef3c7; border: 2px solid #f59e0b;">
                <h3 style="margin-top: 0; color: #92400e;">🧪 Tests de Validation</h3>
                <div style="display: grid; gap: 12px;">
                    <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 10px; background: white; border-radius: 6px;">
                        <input type="checkbox" id="ld1x_test_ghost_${symbole}" checked style="width: 22px; height: 22px;">
                        <div>
                            <strong>${opts.test_ghost.label}</strong><br>
                            <small style="color: #666;">${opts.test_ghost.description}</small>
                        </div>
                    </label>
                    <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 10px; background: white; border-radius: 6px;">
                        <input type="checkbox" id="ld1x_test_transferability_${symbole}" checked style="width: 22px; height: 22px;">
                        <div>
                            <strong>${opts.test_transferability.label}</strong><br>
                            <small style="color: #666;">${opts.test_transferability.description}</small>
                        </div>
                    </label>
                </div>
            </div>
            
            <!-- Boutons d'action -->
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-top: 20px;">
                <button class="btn btn-secondary" onclick="resetParametresLD1X('${symbole}')" style="padding: 15px; font-size: 1.05em;">
                    🔄 Réinitialiser
                </button>
                <button class="btn btn-primary" onclick="genererInputLD1XComplet('${symbole}')" style="padding: 15px; font-size: 1.05em;">
                    📝 Générer Input
                </button>
                <button class="btn btn-success" onclick="lancerGenerationLD1XComplet('${symbole}')" style="padding: 15px; font-size: 1.05em;">
                    🚀 Générer Pseudo
                </button>
            </div>
            
            <!-- Zone de prévisualisation -->
            <div class="card" style="background: #1e293b; color: #e2e8f0; display: none;" id="preview_input_ld1x_${symbole}">
                <h3 style="color: #e2e8f0; margin-top: 0;">📄 Prévisualisation de l'input ld1.x</h3>
                <pre id="preview_input_ld1x_content_${symbole}" style="background: #0f172a; padding: 20px; border-radius: 8px; overflow-x: auto; font-size: 0.85em; line-height: 1.6; max-height: 500px;"></pre>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 15px;">
                    <button class="btn btn-secondary" onclick="copierTexte(document.getElementById('preview_input_ld1x_content_${symbole}').textContent)" style="width: 100%;">
                        📋 Copier
                    </button>
                    <button class="btn btn-primary" onclick="telechargerInputLD1X('${symbole}')" style="width: 100%;">
                        💾 Télécharger
                    </button>
                </div>
            </div>
            
        </div>
    `;
    
    // Initialiser les recommandations
    updateEcutRecommendations(symbole);
}

// Fonctions utilitaires
function updateEcutRecommendations(symbole) {
    const pseudotype = document.getElementById(`ld1x_pseudotype_${symbole}`).value;
    const opts = OPTIONS_LD1X_COMPLETES.pseudotype.options.find(o => o.value === pseudotype);
    
    const infoDiv = document.getElementById(`pseudotype_info_${symbole}`);
    if (infoDiv && opts) {
        infoDiv.innerHTML = `
            💡 <strong>Recommandations:</strong><br>
            • ecutwfc minimum: ${opts.ecutwfc_min} Ry<br>
            • ecutrho = ${opts.ecutrho_factor} × ecutwfc
        `;
        
        // Mettre à jour les valeurs
        const ecutwfcInput = document.getElementById(`ld1x_ecutwfc_${symbole}`);
        if (ecutwfcInput && parseInt(ecutwfcInput.value) < opts.ecutwfc_min) {
            ecutwfcInput.value = opts.ecutwfc_min;
            updateEcutrho(symbole);
        }
    }
}

function updateEcutrho(symbole) {
    const ecutwfc = parseFloat(document.getElementById(`ld1x_ecutwfc_${symbole}`).value);
    const ecutrhoInput = document.getElementById(`ld1x_ecutrho_${symbole}`);
    if (ecutrhoInput) {
        ecutrhoInput.value = ecutwfc * 8;
    }
}

function resetParametresLD1X(symbole) {
    if (confirm('Réinitialiser tous les paramètres aux valeurs par défaut?')) {
        chargerGenerateurLD1XComplet(symbole, ELEMENTS[symbole].nom, ELEMENTS[symbole].numero, 
                                     CONFIGURATIONS_ELECTRONIQUES[symbole], 
                                     ELEMENTS[symbole].numero < 20 ? '0' : '1',
                                     ELEMENTS[symbole].numero > 20 ? 'true' : 'false');
    }
}

console.log('✅ Générateur ld1.x complet chargé');

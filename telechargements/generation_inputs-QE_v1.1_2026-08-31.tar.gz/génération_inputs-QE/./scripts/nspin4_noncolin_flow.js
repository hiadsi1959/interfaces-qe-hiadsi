/**
 * Flux non-colinéaire (UI nspin=4) — génération directe (gen) + conversion CIF (cif).
 * QE 6.x/7.x : noncolin=.true. suffit ; ne pas écrire nspin=4 dans &SYSTEM.
 */
(function () {
    'use strict';

    var INFO_HTML =
        '<div class="nspin4-infobulle" style="margin:0 0 12px;padding:10px 12px;background:#fff7ed;border-left:4px solid #f97316;border-radius:6px;font-size:0.82em;line-height:1.45;color:#9a3412;">'
        + '<strong>⚠️ Pseudopotentiels obligatoires :</strong> avec <code>noncolin=.true.</code>, pw.x exige des fichiers '
        + '<strong>full-relativistic</strong> (<code>.rel-pbe-*</code>). Les pseudos scalar (<code>.pbe-spn</code>, '
        + '<code>.pbe-dn</code>…) provoquent un crash immédiat — même si <code>lspinorb=.false.</code>.'
        + '</div>'
        + '<div class="nspin4-infobulle" style="margin:0 0 12px;padding:10px 12px;background:#fef3c7;border-left:4px solid #f59e0b;border-radius:6px;font-size:0.82em;line-height:1.45;color:#92400e;">'
        + '<strong>SOC recommandé :</strong> pour les terres rares (Eu, Gd…) et la physique non colinéaire réaliste, '
        + 'activez <code>lspinorb=.true.</code> (préréglage par défaut).'
        + '</div>'
        + '<div class="nspin4-infobulle" style="margin:0 0 12px;padding:10px 12px;background:#eff6ff;border-left:4px solid #3b82f6;border-radius:6px;font-size:0.82em;line-height:1.45;color:#1e3a8a;">'
        + '<strong>💡 Mémoire / CPU :</strong> mode non-colinéaire ≈ 4× plus coûteux qu\'un calcul colinéaire (matrices spineurs).'
        + '</div>'
        + '<div class="nspin4-infobulle" style="margin:0 0 14px;padding:10px 12px;background:#ecfdf5;border-left:4px solid #10b981;border-radius:6px;font-size:0.82em;line-height:1.45;color:#065f46;">'
        + '<strong>🌐 Angles :</strong> <code>angle1</code> (θ) = inclinaison vs axe Z (0–180°) · '
        + '<code>angle2</code> (φ) = rotation dans le plan XY (0–360°).'
        + '</div>';

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function elementBase(sym) {
        var m = /^([A-Z][a-z]?)/.exec(String(sym || '').trim());
        return m ? m[1] : String(sym || '').trim();
    }

    function defaultStartMag(sym) {
        var b = elementBase(sym);
        if (/^(O|N|S|F|Cl|Br|I|H|He|Ne|Ar|Kr|Xe|C|P|Ga|Ge|In|Sn|Al|Si|B|Se|Te|As|Sb)$/i.test(b)) return '0.0';
        if (/^(Gd|La|Ce|Pr|Nd|Sm|Eu|Tb|Dy|Ho|Er|Tm|Yb|Lu)$/i.test(b)) return '0.5';
        if (/^(V|Fe|Co|Ni|Mn|Cr|Cu|Ti|Mo|W|Ru|Rh|Sc|Y)$/i.test(b)) return '0.3';
        return '0.5';
    }

    function isLikelyScalarRelPseudo(name) {
        var n = String(name || '');
        if (!/\.upf$/i.test(n)) return false;
        if (/\.rel-/i.test(n)) return false;
        return /\.pbe-(spn|dn|d-|n-|s-|rrkjus|kjpaw)/i.test(n) || /\.pbe_v|\.pbesol/i.test(n);
    }

    function resolveLspinorbForNoncolin(prefix) {
        var nosoc = document.querySelector('input[name="' + prefix + '_nspin4_soc"][value="nosoc"]:checked');
        if (nosoc) return '.false.';
        var ls = lspinorbEl(prefix);
        if (ls && String(ls.value || '').trim() === '.true.') return '.true.';
        return '.true.';
    }

    function lspinorbFromUi(prefix) {
        var ls = lspinorbEl(prefix);
        return ls && String(ls.value || '').trim() === '.true.';
    }

    function lspinorbEl(prefix) {
        if (prefix === 'gen') return document.getElementById('lspinorb');
        return document.getElementById('cif_lspinorb') || document.getElementById('conversion_cif_lspinorb');
    }

    function cifNspinEl() {
        return document.getElementById('cif_nspin') || document.getElementById('conversion_cif_nspin');
    }

    function panelEl(prefix) {
        return document.getElementById(prefix === 'gen' ? 'pw_gen_section_mag_noncolin' : 'cif_section_mag_noncolin');
    }

    function zoneEl(prefix) {
        return document.getElementById(prefix + '_nspin4_species_zone');
    }

    function isActive(prefix) {
        if (prefix === 'gen') {
            var nGen = document.getElementById('nspin');
            return !!(nGen && String(nGen.value || '').trim() === '4');
        }
        var cifNs = cifNspinEl();
        return !!(cifNs && String(cifNs.value || '').trim() === '4');
    }

    function speciesForPrefix(prefix) {
        var syms = [];
        if (prefix === 'gen') {
            var raw = (document.getElementById('atomic_species') || {}).value || '';
            if ((!raw || !String(raw).trim()) && window.atomicSpeciesGlobal) raw = window.atomicSpeciesGlobal;
            if (typeof window.pwGenResolveSpeciesList === 'function') {
                try { syms = window.pwGenResolveSpeciesList(raw) || []; } catch (_e) {}
            }
            if (!syms.length && typeof window.parseSymbolsFromAtomicSpecies === 'function') {
                syms = window.parseSymbolsFromAtomicSpecies(raw) || [];
            }
            if (!syms.length) {
                var n = parseInt((document.getElementById('ntyp') || {}).value || '2', 10) || 2;
                for (var i = 1; i <= n; i++) syms.push('Esp' + i);
            }
            return syms;
        }
        var hubZ = document.getElementById('cif_hubbard_species_zone');
        if (hubZ) {
            hubZ.querySelectorAll('input[data-cif-u]').forEach(function (inp) {
                var s = inp.getAttribute('data-cif-u');
                if (s && syms.indexOf(s) < 0) syms.push(s);
            });
        }
        if (!syms.length) {
            var pz = document.getElementById('cif_pseudo_species_zone');
            if (pz) {
                pz.querySelectorAll('input[data-cif-pseudo]').forEach(function (inp) {
                    var s = inp.getAttribute('data-cif-pseudo');
                    if (s && syms.indexOf(s) < 0) syms.push(s);
                });
            }
        }
        if (!syms.length) {
            var cd = (typeof window.getCifDataCurrent === 'function') ? window.getCifDataCurrent() : window.cifDataCurrent;
            if (cd && cd.content && typeof window.parseSpeciesFromPwText === 'function') {
                /* best-effort après analyse */
            }
        }
        return syms.length ? syms : ['Esp1', 'Esp2'];
    }

    function readRow(prefix, idx) {
        function f(suf) {
            var el = document.getElementById(prefix + '_nc_' + suf + '_' + idx);
            return el ? String(el.value || '').trim() : '';
        }
        return { sm: f('sm'), th: f('th'), ph: f('ph') };
    }

    function writeRow(prefix, idx, row) {
        ['sm', 'th', 'ph'].forEach(function (k) {
            var el = document.getElementById(prefix + '_nc_' + k + '_' + idx);
            if (el && row[k] != null) el.value = String(row[k]);
        });
    }

    function renderSpeciesTable(prefix, species) {
        var zone = zoneEl(prefix);
        if (!zone) return;
        if (!species || !species.length) {
            zone.innerHTML = '<div style="padding:10px;background:#fff;border:1px dashed #67e8f9;border-radius:6px;color:#0e7490;font-size:0.85em;">'
                + (prefix === 'gen'
                    ? 'Renseignez <code>ATOMIC_SPECIES</code> ci-dessus pour afficher les champs par espèce.'
                    : 'Cliquez <strong>Détecter les éléments du CIF</strong> (panneau DFT+U) pour lister les espèces.')
                + '</div>';
            return;
        }
        var saved = {};
        species.forEach(function (_s, i) { saved[i + 1] = readRow(prefix, i + 1); });

        var html = '<table style="width:100%;border-collapse:collapse;background:#fff;border-radius:6px;overflow:hidden;font-size:0.88em;">';
        html += '<thead><tr style="background:#cffafe;">';
        html += '<th style="padding:6px;border:1px solid #a5f3fc;text-align:left;">Espèce</th>';
        html += '<th style="padding:6px;border:1px solid #a5f3fc;"><code>|m|</code> (0–1)</th>';
        html += '<th style="padding:6px;border:1px solid #a5f3fc;"><code>angle1</code> θ (°)</th>';
        html += '<th style="padding:6px;border:1px solid #a5f3fc;"><code>angle2</code> φ (°)</th>';
        html += '</tr></thead><tbody>';
        for (var i = 0; i < species.length; i++) {
            var idx = i + 1;
            var sym = species[i];
            var prev = saved[idx] || {};
            var smShow = prev.sm !== '' ? prev.sm : defaultStartMag(sym);
            html += '<tr>';
            html += '<td style="padding:6px;border:1px solid #a5f3fc;font-weight:700;color:#0e7490;">' + esc(sym) + '</td>';
            html += '<td style="padding:2px;border:1px solid #a5f3fc;"><input type="text" id="' + prefix + '_nc_sm_' + idx + '" value="' + esc(smShow) + '" placeholder="' + esc(defaultStartMag(sym)) + '" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:4px;"></td>';
            html += '<td style="padding:2px;border:1px solid #a5f3fc;"><input type="text" id="' + prefix + '_nc_th_' + idx + '" value="' + esc(prev.th) + '" placeholder="0" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:4px;"></td>';
            html += '<td style="padding:2px;border:1px solid #a5f3fc;"><input type="text" id="' + prefix + '_nc_ph_' + idx + '" value="' + esc(prev.ph) + '" placeholder="0" style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:4px;"></td>';
            html += '</tr>';
        }
        html += '</tbody></table>';
        zone.innerHTML = html;
    }

    function ensurePanelChrome(prefix) {
        var panel = panelEl(prefix);
        if (!panel || panel.getAttribute('data-nspin4-bound') === '1') return;
        panel.setAttribute('data-nspin4-bound', '1');

        var infoId = prefix + '_nspin4_infobulles';
        if (!document.getElementById(infoId)) {
            var info = document.createElement('div');
            info.id = infoId;
            info.innerHTML = INFO_HTML;
            if (panel.children.length > 1) {
                panel.insertBefore(info, panel.children[1]);
            } else {
                panel.appendChild(info);
            }
        }

        var socId = prefix + '_nspin4_soc_row';
        if (!document.getElementById(socId)) {
            var soc = document.createElement('div');
            soc.id = socId;
            soc.style.cssText = 'margin:0 0 12px;padding:10px 12px;background:#f0f9ff;border:1px solid #7dd3fc;border-radius:8px;font-size:0.88em;';
            soc.innerHTML =
                '<strong style="color:#0369a1;">Objectif du calcul :</strong>'
                + '<div style="display:flex;flex-wrap:wrap;gap:14px;margin-top:8px;">'
                + '<label style="cursor:pointer;display:flex;align-items:center;gap:6px;"><input type="radio" name="' + prefix + '_nspin4_soc" value="soc" checked /> Couplage spin-orbite (<code>lspinorb=.true.</code> · pseudos FR · recommandé)</label>'
                + '<label style="cursor:pointer;display:flex;align-items:center;gap:6px;"><input type="radio" name="' + prefix + '_nspin4_soc" value="nosoc" /> Sans SOC (<code>lspinorb=.false.</code> · test artificiel uniquement)</label>'
                + '</div>';
            panel.appendChild(soc);
            soc.querySelectorAll('input[name="' + prefix + '_nspin4_soc"]').forEach(function (r) {
                r.addEventListener('change', function () {
                    window.nspin4Flow.onSocChange(prefix, r.value === 'soc');
                });
            });
        }

        var preId = prefix + '_nspin4_presets_row';
        if (!document.getElementById(preId)) {
            var pre = document.createElement('div');
            pre.id = preId;
            pre.style.cssText = 'margin:0 0 12px;display:flex;flex-wrap:wrap;gap:8px;align-items:center;';
            pre.innerHTML =
                '<span style="font-weight:600;color:#0e7490;font-size:0.88em;">Préréglages :</span>'
                + '<button type="button" class="btn" data-nspin4-preset="z" style="padding:6px 10px;font-size:0.82em;border:1px solid #22d3ee;background:#ecfeff;border-radius:6px;cursor:pointer;">↑↓ axe Z</button>'
                + '<button type="button" class="btn" data-nspin4-preset="hex120" style="padding:6px 10px;font-size:0.82em;border:1px solid #22d3ee;background:#ecfeff;border-radius:6px;cursor:pointer;">120° (hexa)</button>'
                + '<button type="button" class="btn" data-nspin4-preset="canted" style="padding:6px 10px;font-size:0.82em;border:1px solid #22d3ee;background:#ecfeff;border-radius:6px;cursor:pointer;">Incliné / canté</button>';
            panel.appendChild(pre);
            pre.querySelectorAll('[data-nspin4-preset]').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    window.nspin4Flow.applyPreset(prefix, btn.getAttribute('data-nspin4-preset'));
                });
            });
        }

        if (!document.getElementById(prefix + '_nspin4_species_zone')) {
            var z = document.createElement('div');
            z.id = prefix + '_nspin4_species_zone';
            panel.appendChild(z);
        }

        var convId = prefix + '_nspin4_conv_hint';
        if (!document.getElementById(convId)) {
            var cv = document.createElement('div');
            cv.id = convId;
            cv.style.cssText = 'margin-top:10px;font-size:0.78em;color:#57534e;line-height:1.4;';
            cv.innerHTML = 'Convergence SCF&nbsp;: <code>mixing_beta</code> réduit automatiquement · +15&nbsp;% sur <code>ecutwfc</code>/<code>ecutrho</code> si SOC.';
            panel.appendChild(cv);
        }
    }

    function toggleHubbardAutoSpin(prefix, active) {
        var id = prefix === 'gen' ? 'gen_hubbard_auto_spin' : 'cif_hubbard_auto_spin';
        var ck = document.getElementById(id);
        if (!ck) return;
        var wrap = ck.closest('label') || ck.parentElement;
        if (active) {
            ck.checked = false;
            ck.disabled = true;
            if (wrap) wrap.style.opacity = '0.55';
        } else {
            ck.disabled = false;
            if (wrap) wrap.style.opacity = '';
        }
    }

    window.nspin4Flow = {
        isActive: isActive,
        defaultStartMag: defaultStartMag,

        applyWorkflowDefaults: function (prefix) {
            var ls = lspinorbEl(prefix);
            if (ls) ls.value = '.true.';
            this.syncSocRadiosFromLspinorb(prefix);
            this.applyConvergenceHints(prefix, true);
            var pseudoField = document.getElementById(prefix === 'gen' ? 'path_pseudos_field' : 'cif_pseudo_dir');
            if (pseudoField && typeof window.pwGenFrPseudoDir === 'function') {
                pseudoField.value = window.pwGenFrPseudoDir();
            }
            if (prefix === 'gen' && typeof genererAtomicSpecies === 'function') {
                try { genererAtomicSpecies(); } catch (_eAs) { console.warn(_eAs); }
            } else if (prefix === 'cif' && typeof window.nspin4Flow.refreshPseudoSuggestionsForSoc === 'function') {
                this.refreshPseudoSuggestionsForSoc(false);
            }
        },

        refresh: function (prefix) {
            if (!isActive(prefix)) {
                var p = panelEl(prefix);
                if (p) {
                    p.style.display = 'none';
                    p.removeAttribute('data-nspin4-hints');
                }
                toggleHubbardAutoSpin(prefix, false);
                return;
            }
            ensurePanelChrome(prefix);
            var panel = panelEl(prefix);
            if (panel) panel.style.display = 'block';
            toggleHubbardAutoSpin(prefix, true);
            if (panel && panel.getAttribute('data-nspin4-hints') !== '1') {
                panel.setAttribute('data-nspin4-hints', '1');
                this.applyWorkflowDefaults(prefix);
            }
            renderSpeciesTable(prefix, speciesForPrefix(prefix));
            this.syncSocRadiosFromLspinorb(prefix);
        },

        collectFields: function (prefix) {
            var species = speciesForPrefix(prefix);
            var rows = [];
            for (var i = 0; i < species.length; i++) {
                var r = readRow(prefix, i + 1);
                rows.push({ sym: species[i], sm: r.sm, th: r.th, ph: r.ph });
            }
            return rows;
        },

        onSocChange: function (prefix, withSoc) {
            var ls = lspinorbEl(prefix);
            if (ls) ls.value = withSoc ? '.true.' : '.false.';
            this.applyConvergenceHints(prefix, withSoc);
            if (prefix === 'cif') this.refreshPseudoSuggestionsForSoc(true);
        },

        syncSocRadiosFromLspinorb: function (prefix) {
            var ls = lspinorbEl(prefix);
            var soc = ls && String(ls.value).trim() === '.true.';
            var name = prefix + '_nspin4_soc';
            document.querySelectorAll('input[name="' + name + '"]').forEach(function (r) {
                r.checked = (r.value === 'soc') ? soc : !soc;
            });
        },

        applyConvergenceHints: function (prefix, withSoc) {
            var mixIds = prefix === 'gen' ? ['mixing_beta'] : ['cif_mixing_beta'];
            mixIds.forEach(function (id) {
                var el = document.getElementById(id);
                if (!el) return;
                var v = parseFloat(el.value);
                if (isNaN(v) || v > 0.25) v = withSoc ? 0.15 : 0.20;
                el.value = String(Math.max(0.15, Math.min(0.25, v)).toFixed(2));
            });
            if (withSoc) {
                (prefix === 'gen' ? ['ecutwfc', 'ecutrho'] : []).forEach(function (id) {
                    var el = document.getElementById(id);
                    if (!el) return;
                    var e = parseFloat(el.value);
                    if (!isNaN(e)) el.value = String(Math.round(e * 1.15));
                });
            }
        },

        applyPreset: function (prefix, presetId) {
            var n = speciesForPrefix(prefix).length;
            if (!n) return;
            if (presetId === 'z') {
                writeRow(prefix, 1, { sm: '0.5', th: '0', ph: '0' });
                if (n >= 2) writeRow(prefix, 2, { sm: '0.5', th: '180', ph: '0' });
            } else if (presetId === 'hex120') {
                var hex = [
                    { sm: '0.5', th: '90', ph: '0' },
                    { sm: '0.5', th: '90', ph: '120' },
                    { sm: '0.5', th: '90', ph: '240' },
                ];
                for (var i = 0; i < Math.min(n, hex.length); i++) writeRow(prefix, i + 1, hex[i]);
            } else if (presetId === 'canted') {
                writeRow(prefix, 1, { sm: '0.5', th: '89', ph: '45' });
                if (n >= 2) writeRow(prefix, 2, { sm: '0.5', th: '91', ph: '225' });
            }
        },

        pushStartingMagLines: function (inner, rows) {
            rows.forEach(function (r, idx) {
                var i = idx + 1;
                var smVal = r.sm !== '' ? r.sm : defaultStartMag(r.sym);
                var smNum = parseFloat(String(smVal).replace(/,/g, '.'));
                if (!isNaN(smNum) && smNum !== 0) {
                    inner.push('  starting_magnetization(' + i + ') = ' + smVal);
                }
                if (r.th !== '') inner.push('  angle1(' + i + ') = ' + r.th);
                if (r.ph !== '') inner.push('  angle2(' + i + ') = ' + r.ph);
            });
        },

        injectNoncolinSystem: function (inner, prefix, lspin, totM) {
            inner.push('  noncolin = .true.');
            inner.push('  lspinorb = ' + (lspin === '.true.' ? '.true.' : '.false.'));
            var rows = this.collectFields(prefix);
            if (rows.length) {
                this.pushStartingMagLines(inner, rows);
            } else {
                var species = speciesForPrefix(prefix);
                var fallback = species.map(function (sym) {
                    return { sym: sym, sm: '', th: '', ph: '' };
                });
                this.pushStartingMagLines(inner, fallback);
            }
            if (totM !== '') inner.push('  tot_magnetization = ' + totM);
        },

        upgradeAtomicSpeciesInOutput: function (text) {
            if (typeof window.pwGenUpgradeAtomicSpeciesText === 'function') {
                return window.pwGenUpgradeAtomicSpeciesText(text);
            }
            return text;
        },

        upgradePseudoDirInOutput: function (text) {
            if (!text || typeof window.pwGenFrPseudoDir !== 'function') return text;
            var frDir = window.pwGenFrPseudoDir();
            return text.replace(/^\s*pseudo_dir\s*=\s*'[^']*'/im, "    pseudo_dir = '" + frDir + "'");
        },

        stripRedundantNspin4: function (text) {
            if (!text || !/noncolin\s*=\s*\.true\./i.test(text)) return text;
            return text.replace(/^[ \t]*nspin\s*=\s*4\s*$/gim, '');
        },

        annotateFrPseudoHint: function (text) {
            if (!text || !/noncolin\s*=\s*\.true\./i.test(text)) return text;
            var lines = text.split(/\r?\n/);
            var iAs = -1;
            for (var i = 0; i < lines.length; i++) {
                if (/^\s*ATOMIC_SPECIES/i.test(lines[i])) {
                    iAs = i;
                    break;
                }
            }
            if (iAs < 0) return text;
            var bad = false;
            for (var j = iAs + 1; j < lines.length; j++) {
                if (/^\s*ATOMIC_POSITIONS/i.test(lines[j])) break;
                var parts = lines[j].trim().split(/\s+/);
                if (parts.length >= 3 && isLikelyScalarRelPseudo(parts[parts.length - 1])) bad = true;
            }
            if (!bad) return text;
            var hint = '  ! Interface-QE: noncolin=.true. — pseudos full-relativistic requis (.rel-pbe-*)';
            if (lines[iAs + 1] && /full-relativistic|\.rel-pbe/i.test(lines[iAs + 1])) return text;
            lines.splice(iAs + 1, 0, hint);
            return lines.join('\n');
        },

        finalizeNoncolinOutput: function (text, lspin) {
            var out = this.stripRedundantNspin4(text);
            out = this.upgradeAtomicSpeciesInOutput(out);
            out = this.upgradePseudoDirInOutput(out);
            return this.annotateFrPseudoHint(out);
        },

        refreshPseudoSuggestionsForSoc: function (onlyIfDefaultLike) {
            if (typeof window.cifDefaultPseudoFilename !== 'function') return;
            var withFr = isActive('cif') || lspinorbFromUi('cif');
            document.querySelectorAll('input[data-cif-pseudo]').forEach(function (inp) {
                var sym = inp.getAttribute('data-cif-pseudo');
                if (!sym) return;
                var cur = String(inp.value || '').trim();
                var sr = window.cifDefaultPseudoFilename(sym, { soc: false });
                var fr = window.cifDefaultPseudoFilename(sym, { soc: true });
                if (onlyIfDefaultLike && cur && cur !== sr && cur !== fr &&
                        !/\.pbe-(spn|dn|d-|n-)/i.test(cur)) return;
                inp.value = withFr ? fr : sr;
            });
        },

        adjustMixingInOutput: function (text, prefix) {
            var id = prefix === 'gen' ? 'mixing_beta' : 'cif_mixing_beta';
            var el = document.getElementById(id);
            var mv = el ? parseFloat(el.value) : NaN;
            if (isNaN(mv)) mv = 0.15;
            mv = Math.max(0.15, Math.min(0.25, mv));
            return text.replace(/^\s*mixing_beta\s*=\s*[^\n]+/im, '    mixing_beta = ' + mv.toFixed(2));
        },
    };

    window.nspin4ResolveLspinorb = resolveLspinorbForNoncolin;

    window.nspin4CollectFields = function (prefix) {
        return window.nspin4Flow.collectFields(prefix);
    };

    window.cifPrepareNoncolinBeforeBuild = function cifPrepareNoncolinBeforeBuild() {
        try {
            if (typeof window.cifSyncTypeMagnetisme === 'function') window.cifSyncTypeMagnetisme();
        } catch (_eSync) { console.warn(_eSync); }
        if (!isActive('cif') && window.__cifTypeMagnetisme !== 'non_colin') return;
        window.nspin4Flow.applyWorkflowDefaults('cif');
    };

    /* Sync lspinorb select → radios SOC */
    document.addEventListener('change', function (ev) {
        var t = ev.target;
        if (!t || t.id !== 'lspinorb' && t.id !== 'cif_lspinorb') return;
        var prefix = t.id === 'lspinorb' ? 'gen' : 'cif';
        if (isActive(prefix)) window.nspin4Flow.syncSocRadiosFromLspinorb(prefix);
        if (t.id === 'cif_lspinorb' && typeof window.nspin4Flow.refreshPseudoSuggestionsForSoc === 'function') {
            window.nspin4Flow.refreshPseudoSuggestionsForSoc(true);
        }
    });

})();

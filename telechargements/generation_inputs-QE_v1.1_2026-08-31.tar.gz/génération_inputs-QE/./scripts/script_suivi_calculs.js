// ═══════════════════════════════════════════════════════════════════════════
// SCRIPT SUIVI DES CALCULS - MODAL INTERACTIF POUR LOGS EN TEMPS RÉEL
// ═══════════════════════════════════════════════════════════════════════════

let intervalSuiviCalcul = null;
let typeCalculEnCours = null;

// Mapping des types de calculs vers leurs fichiers de log
const CALCUL_LOG_MAPPING = {
    'vcrelax': { fichier: 'vc-relax.out', titre: 'VC-RELAX - Optimisation Géométrie', couleur: '#10b981' },
    'scf': { fichier: 'scf.out', titre: 'SCF - Calcul Auto-cohérent', couleur: '#0ea5e9' },
    'nscf': { fichier: 'nscf.out', titre: 'NSCF - Calcul Non-SCF', couleur: '#8b5cf6' },
    'bands': { fichier: 'bands.out', titre: 'BANDS - Structure de Bandes', couleur: '#f59e0b' },
    'dos': { fichier: 'dos.out', titre: 'DOS - Densité d\'États', couleur: '#ef4444' },
    'ph': { fichier: 'ph.out', titre: 'PH - Calcul Phonons', couleur: '#14b8a6' },
    'q2r': { fichier: 'q2r.out', titre: 'Q2R - Constantes de Force', couleur: '#3b82f6' },
    'matdyn': { fichier: 'matdyn.out', titre: 'MATDYN - Dispersion Phonons', couleur: '#8b5cf6' },
    'thermo': { fichier: 'thermo.out', titre: 'THERMO - Thermodynamique', couleur: '#f59e0b' },
    'eph': { fichier: 'eph.out', titre: 'e-ph - Couplage Électron-Phonon', couleur: '#ef4444' }
};

/**
 * Ouvre un modal de suivi pour un type de calcul spécifique
 * @param {string} typeCalcul - Type de calcul ('vcrelax', 'scf', 'nscf', 'bands', 'dos', 'ph', 'q2r', 'matdyn', 'thermo', 'eph')
 */
function ouvrirSuiviCalcul(typeCalcul) {
    typeCalculEnCours = typeCalcul;
    
    const config = CALCUL_LOG_MAPPING[typeCalcul];
    if (!config) {
        console.error('Type de calcul inconnu:', typeCalcul);
        return;
    }
    
    // Créer le modal s'il n'existe pas
    let modal = document.getElementById('modal_suivi_calcul');
    if (!modal) {
        modal = creerModalSuivi();
    }
    
    // Mettre à jour le titre et la couleur
    const titre = document.getElementById('modal_suivi_titre');
    const header = document.getElementById('modal_suivi_header');
    if (titre) {
        titre.textContent = config.titre;
    }
    if (header) {
        header.style.background = `linear-gradient(135deg, ${config.couleur}, ${ajusterCouleur(config.couleur, -20)})`;
    }
    
    // Réinitialiser le contenu
    const logsContent = document.getElementById('modal_suivi_logs_content');
    if (logsContent) {
        logsContent.innerHTML = '<div style="color: #94a3b8;">[INFO] Chargement des logs...</div>';
    }
    
    // Afficher le modal
    modal.style.display = 'flex';
    
    // Démarrer le rafraîchissement automatique des logs
    chargerLogsCalcul(typeCalcul);
    
    // Mettre à jour toutes les 3 secondes
    if (intervalSuiviCalcul) {
        clearInterval(intervalSuiviCalcul);
    }
    intervalSuiviCalcul = setInterval(() => {
        chargerLogsCalcul(typeCalcul);
    }, 3000);
}

/**
 * Crée le modal de suivi des calculs
 */
function creerModalSuivi() {
    const modal = document.createElement('div');
    modal.id = 'modal_suivi_calcul';
    modal.style.cssText = `
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        z-index: 10000;
        justify-content: center;
        align-items: center;
        backdrop-filter: blur(5px);
    `;
    
    modal.innerHTML = `
        <div style="
            background: white;
            border-radius: 16px;
            width: 90%;
            max-width: 1200px;
            max-height: 90vh;
            display: flex;
            flex-direction: column;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        ">
            <!-- En-tête -->
            <div id="modal_suivi_header" style="
                padding: 25px 30px;
                background: linear-gradient(135deg, #10b981, #059669);
                border-radius: 16px 16px 0 0;
                color: white;
                display: flex;
                justify-content: space-between;
                align-items: center;
            ">
                <div>
                    <h3 id="modal_suivi_titre" style="margin: 0; font-size: 1.5em; font-weight: 700;">
                        Suivi du Calcul
                    </h3>
                    <p style="margin: 5px 0 0 0; opacity: 0.9; font-size: 0.9em;">
                        Logs en temps réel - Mise à jour toutes les 3 secondes
                    </p>
                </div>
                <button onclick="fermerSuiviCalcul()" style="
                    background: rgba(255, 255, 255, 0.2);
                    border: none;
                    color: white;
                    font-size: 24px;
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    cursor: pointer;
                    transition: all 0.2s;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                " onmouseover="this.style.background='rgba(255,255,255,0.3)'" 
                   onmouseout="this.style.background='rgba(255,255,255,0.2)'">
                    ✕
                </button>
            </div>
            
            <!-- Barre d'actions -->
            <div style="
                padding: 15px 30px;
                background: #f8fafc;
                border-bottom: 1px solid #e2e8f0;
                display: flex;
                gap: 10px;
                align-items: center;
            ">
                <button onclick="chargerLogsCalcul(typeCalculEnCours)" style="
                    padding: 8px 16px;
                    background: linear-gradient(135deg, #3b82f6, #2563eb);
                    color: white;
                    border: none;
                    border-radius: 6px;
                    cursor: pointer;
                    font-weight: 600;
                    transition: transform 0.2s;
                " onmouseover="this.style.transform='scale(1.05)'" 
                   onmouseout="this.style.transform='scale(1)'">
                    🔄 Rafraîchir
                </button>
                <button onclick="telechargerLogs()" style="
                    padding: 8px 16px;
                    background: linear-gradient(135deg, #10b981, #059669);
                    color: white;
                    border: none;
                    border-radius: 6px;
                    cursor: pointer;
                    font-weight: 600;
                    transition: transform 0.2s;
                " onmouseover="this.style.transform='scale(1.05)'" 
                   onmouseout="this.style.transform='scale(1)'">
                    💾 Télécharger
                </button>
                <div style="flex: 1;"></div>
                <div id="modal_suivi_statut" style="
                    padding: 8px 16px;
                    background: #e0f2fe;
                    color: #0369a1;
                    border-radius: 6px;
                    font-size: 0.85em;
                    font-weight: 600;
                ">
                    🔄 En cours...
                </div>
            </div>
            
            <!-- Contenu des logs -->
            <div id="modal_suivi_logs_wrapper" style="
                flex: 1;
                overflow-y: auto;
                padding: 20px 30px;
                background: #1e293b;
            ">
                <div id="modal_suivi_logs_content" style="
                    font-family: 'JetBrains Mono', 'Courier New', monospace;
                    font-size: 0.85em;
                    line-height: 1.6;
                    color: #e2e8f0;
                    white-space: pre-wrap;
                    word-break: break-word;
                ">
                    [INFO] Initialisation...
                </div>
                </div>
                
            <!-- Pied de page -->
            <div style="
                padding: 20px 30px;
                background: #f8fafc;
                border-radius: 0 0 16px 16px;
                border-top: 1px solid #e2e8f0;
                display: flex;
                justify-content: space-between;
                align-items: center;
            ">
                <div style="font-size: 0.85em; color: #64748b;">
                    💡 <strong>Astuce:</strong> Les logs se mettent à jour automatiquement
                </div>
                <button onclick="fermerSuiviCalcul()" class="btn" style="
                    padding: 10px 25px;
                    background: #64748b;
                ">
                    Fermer
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Fermer en cliquant sur le fond
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            fermerSuiviCalcul();
        }
    });
    
    // Fermer avec la touche Échap
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.style.display === 'flex') {
            fermerSuiviCalcul();
        }
    });
    
    return modal;
}

/**
 * Charge les logs du calcul depuis le serveur
 * Essaie d'abord par type, puis cherche le dernier calcul si non trouvé
 */
async function chargerLogsCalcul(typeCalcul) {
    const config = CALCUL_LOG_MAPPING[typeCalcul];
    if (!config) return;
    
    const logsContent = document.getElementById('modal_suivi_logs_content');
    if (!logsContent) return;
    
    // Déterminer l'URL de l'API (localhost ou relative)
    const API_BASE = window.API_BASE || 'http://localhost:5007';
    
    try {
        // 1. Essayer d'abord par type de calcul
        let response = await fetch(`${API_BASE}/api/logs_calcul/${typeCalcul}`);
        let data = await response.json();
        
        // 2. Si pas trouvé, essayer de récupérer le dernier calcul
        if (!data.success) {
            console.log('Logs par type non trouvés, recherche du dernier calcul...');
            response = await fetch(`${API_BASE}/api/dernier_calcul`);
            data = await response.json();
        }
        
        if (data.success && data.contenu) {
            // Afficher le fichier trouvé
            const headerInfo = data.fichier ? 
                `<div style="color: #94a3b8; margin-bottom: 10px; padding: 8px; background: rgba(255,255,255,0.1); border-radius: 4px;">
                    📄 Fichier: <strong>${data.nom_fichier || data.fichier.split('/').pop()}</strong>
                    ${data.materiau ? ` | 📁 ${data.materiau}` : ''}
                    ${data.type_calcul ? ` | 🏷️ ${data.type_calcul}` : ''}
                </div>` : '';
            
            // Formater les logs avec coloration syntaxique
            logsContent.innerHTML = headerInfo + formaterLogs(data.contenu);
        
        // Mettre à jour le statut
            const statut = document.getElementById('modal_suivi_statut');
            if (statut) {
                if (data.en_cours) {
                    statut.innerHTML = '🔄 En cours...';
                    statut.style.background = '#dbeafe';
                    statut.style.color = '#1e40af';
                } else if (data.termine) {
                    statut.innerHTML = '✅ Terminé';
                    statut.style.background = '#dcfce7';
                    statut.style.color = '#166534';
                } else if (data.erreur) {
                    statut.innerHTML = '❌ Erreur détectée';
                    statut.style.background = '#fee2e2';
                    statut.style.color = '#991b1b';
                    
                    // Si message d'erreur, l'afficher en haut
                    if (data.message_erreur) {
                        const erreurDiv = document.createElement('div');
                        erreurDiv.style.cssText = 'background: #fee2e2; color: #991b1b; padding: 15px; margin-bottom: 15px; border-radius: 8px; border: 1px solid #fecaca;';
                        erreurDiv.innerHTML = `<strong>⚠️ Erreur détectée:</strong><br><code>${data.message_erreur}</code>`;
                        logsContent.insertBefore(erreurDiv, logsContent.firstChild);
            }
            
                    // NOUVEAU: Ajouter le bouton "Éditer et Corriger"
                    ajouterBoutonEditerDansModal(data.fichier, data.materiau, typeCalcul);
                } else {
                    statut.innerHTML = '📋 Logs disponibles';
                    statut.style.background = '#e0e7ff';
                    statut.style.color = '#3730a3';
                }
            }
            
            // Auto-scroll vers le bas (pour voir les derniers logs / erreurs)
            const wrapper = document.getElementById('modal_suivi_logs_wrapper');
            if (wrapper) {
                wrapper.scrollTop = wrapper.scrollHeight;
            }
        } else if (data.message) {
            logsContent.innerHTML = `<div style="color: #fbbf24;">[INFO] ${data.message}</div>
            <div style="color: #94a3b8; margin-top: 15px;">
                💡 <strong>Conseil:</strong> Vérifiez que:
                <ul style="margin: 10px 0;">
                    <li>Le calcul a bien été lancé</li>
                    <li>Le dossier outputs contient des fichiers .out</li>
                    <li>L'API fonctionne sur le port 5007</li>
                </ul>
            </div>`;
        }
    } catch (error) {
        logsContent.innerHTML = `<div style="color: #ef4444;">[ERREUR] Impossible de charger les logs: ${error.message}</div>
        <div style="color: #94a3b8; margin-top: 15px;">
            💡 Vérifiez que l'API est démarrée: <code>python3 api_sauvegarde_inputs.py</code>
        </div>`;
        console.error('Erreur chargement logs:', error);
    }
}

/**
 * Formate les logs avec coloration syntaxique
 */
function formaterLogs(contenu) {
    if (!contenu || contenu.trim() === '') {
        return '<div style="color: #94a3b8;">[INFO] Aucun log disponible</div>';
    }
    
    let formatted = contenu;
    
    // Colorer les différents types de messages
    formatted = formatted.replace(/(\[INFO\].*)/g, '<span style="color: #3b82f6;">$1</span>');
    formatted = formatted.replace(/(\[WARN.*?\].*)/g, '<span style="color: #f59e0b;">$1</span>');
    formatted = formatted.replace(/(\[ERROR.*?\].*)/g, '<span style="color: #ef4444; font-weight: 600;">$1</span>');
    formatted = formatted.replace(/(\[SUCCESS.*?\].*)/g, '<span style="color: #10b981; font-weight: 600;">$1</span>');
    
    // Colorer les mots-clés Quantum ESPRESSO
    formatted = formatted.replace(/(convergence|converged|total energy|force|stress)/gi, '<strong style="color: #10b981;">$1</strong>');
    formatted = formatted.replace(/(error|failed|warning)/gi, '<strong style="color: #ef4444;">$1</strong>');
    formatted = formatted.replace(/(scf|nscf|bands|dos|phonon|vc-relax)/gi, '<strong style="color: #8b5cf6;">$1</strong>');
    
    // Colorer les nombres
    formatted = formatted.replace(/(\d+\.\d+E[+-]\d+|\d+\.\d+)/g, '<span style="color: #06b6d4;">$1</span>');
    
    return formatted;
}

/**
 * Télécharge les logs actuels
 */
function telechargerLogs() {
    const logsContent = document.getElementById('modal_suivi_logs_content');
    if (!logsContent) return;
    
    const config = CALCUL_LOG_MAPPING[typeCalculEnCours];
    if (!config) return;
    
    // Extraire le texte brut (sans HTML)
    const texteBrut = logsContent.innerText || logsContent.textContent;
    
    // Créer un blob et le télécharger
    const blob = new Blob([texteBrut], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${typeCalculEnCours}_logs_${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

/**
 * Ferme le modal de suivi
 */
function fermerSuiviCalcul() {
    const modal = document.getElementById('modal_suivi_calcul');
    if (modal) {
        modal.style.display = 'none';
    }
    
    // Arrêter le rafraîchissement automatique
    if (intervalSuiviCalcul) {
        clearInterval(intervalSuiviCalcul);
        intervalSuiviCalcul = null;
    }
    
    typeCalculEnCours = null;
}

/**
 * Ajuste une couleur en luminosité
 */
function ajusterCouleur(hex, percent) {
    const num = parseInt(hex.replace('#', ''), 16);
    const amt = Math.round(2.55 * percent);
    const R = (num >> 16) + amt;
    const G = (num >> 8 & 0x00FF) + amt;
    const B = (num & 0x0000FF) + amt;
    return '#' + (
        0x1000000 +
        (R < 255 ? (R < 1 ? 0 : R) : 255) * 0x10000 +
        (G < 255 ? (G < 1 ? 0 : G) : 255) * 0x100 +
        (B < 255 ? (B < 1 ? 0 : B) : 255)
    ).toString(16).slice(1);
}

// ═══════════════════════════════════════════════════════════════════════════
// INTÉGRATION WORKFLOW ERREUR - BOUTON ÉDITER ET CORRIGER
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Ajoute le bouton "Éditer et Corriger" dans le modal quand une erreur est détectée
 */
function ajouterBoutonEditerDansModal(fichierOutput, materiau, typeCalcul) {
    // Vérifier si le bouton existe déjà
    if (document.getElementById('btn_editer_corriger_modal')) return;
    
    // Trouver la barre d'actions
    const modal = document.getElementById('modal_suivi_calcul');
    if (!modal) return;
    
    // Chercher la barre d'actions (contient les boutons Rafraîchir et Télécharger)
    const barreActions = modal.querySelector('div[style*="gap: 10px"]');
    if (!barreActions) return;
    
    // Chercher le fichier input correspondant
    let fichierInput = fichierOutput || '';
    if (fichierOutput) {
        // Transformer le .out en .in
        fichierInput = fichierOutput.replace('.out', '.in');
        fichierInput = fichierInput.replace('_vcrelax', '_vc-relax');
    }
    
    // Créer le bouton
    const bouton = document.createElement('button');
    bouton.id = 'btn_editer_corriger_modal';
    bouton.innerHTML = '🔧 Éditer et Corriger';
    bouton.style.cssText = `
        padding: 8px 16px;
        background: linear-gradient(135deg, #f59e0b, #d97706);
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 600;
        transition: transform 0.2s;
    `;
    bouton.onmouseover = () => bouton.style.transform = 'scale(1.05)';
    bouton.onmouseout = () => bouton.style.transform = 'scale(1)';
    bouton.onclick = async () => {
        // Fermer le modal de suivi
        fermerSuiviCalcul();
        
        // Ouvrir l'éditeur avec corrections (si la fonction existe)
        if (typeof window.ouvrirEditeurAvecCorrections === 'function') {
            await window.ouvrirEditeurAvecCorrections(materiau, fichierInput, fichierOutput, typeCalcul);
        } else {
            console.warn('Fonction ouvrirEditeurAvecCorrections non disponible');
            // Fallback: juste ouvrir l'onglet génération
            if (typeof switchTab === 'function') {
                switchTab(0);
                alert('Veuillez charger le fichier input manuellement et corriger les erreurs.');
            }
        }
    };
    
    // Insérer le bouton après le bouton "Télécharger"
    const btnTelecharger = barreActions.querySelector('button[onclick*="telechargerLogs"]');
    if (btnTelecharger && btnTelecharger.nextSibling) {
        btnTelecharger.parentNode.insertBefore(bouton, btnTelecharger.nextSibling);
    } else {
        // Insérer avant le div flex-1
        const spacer = barreActions.querySelector('div[style*="flex: 1"]');
        if (spacer) {
            barreActions.insertBefore(bouton, spacer);
        } else {
            barreActions.appendChild(bouton);
        }
    }
}

/**
 * Retire le bouton éditer du modal (quand le calcul n'est plus en erreur)
 */
function retirerBoutonEditer() {
    const bouton = document.getElementById('btn_editer_corriger_modal');
    if (bouton) {
        bouton.remove();
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// NETTOYAGE À LA FERMETURE DE LA PAGE
// ═══════════════════════════════════════════════════════════════════════════

window.addEventListener('beforeunload', () => {
    if (intervalSuiviCalcul) {
        clearInterval(intervalSuiviCalcul);
    }
});

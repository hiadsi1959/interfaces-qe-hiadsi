/**
 * CALCULATEUR AUTOMATIQUE DE nat
 * 
 * Calcule automatiquement le nombre d'atomes (nat) en fonction de:
 * - Type de structure (ibrav)
 * - Type de matériau (ntyp)
 * - Formule chimique détectée
 */

// ═══════════════════════════════════════════════════════════════════════════
// BASE DE DONNÉES DES STRUCTURES COMMUNES
// ═══════════════════════════════════════════════════════════════════════════

const STRUCTURES_NAT = {
    // ─────────────────────────────────────────────────────────────────────
    // BINAIRES (ntyp=2)
    // ─────────────────────────────────────────────────────────────────────
    'BINAIRE_FCC': {
        description: 'Rocksalt (NaCl) - FCC',
        ibrav: [2, 1],  // FCC ou Simple cubic
        ntyp: 2,
        nat: 8,
        exemples: ['NaCl', 'MgO', 'TiN']
    },
    'BINAIRE_WURTZITE': {
        description: 'Wurtzite (ZnO) - Hexagonal',
        ibrav: [4],  // Hexagonal
        ntyp: 2,
        nat: 4,
        exemples: ['ZnO', 'GaN', 'AlN', 'ZnS']
    },
    'BINAIRE_ZINCBLENDE': {
        description: 'Zinc Blende (GaAs) - FCC',
        ibrav: [2],  // FCC
        ntyp: 2,
        nat: 2,
        exemples: ['GaAs', 'ZnS', 'CdTe', 'SiC']
    },
    'BINAIRE_SIMPLE': {
        description: 'Structure simple AB',
        ibrav: [1, 2, 3],  // Cubic, FCC, BCC
        ntyp: 2,
        nat: 2,
        exemples: ['CsCl', 'FeAl']
    },
    
    // ─────────────────────────────────────────────────────────────────────
    // TERNAIRES (ntyp=3)
    // ─────────────────────────────────────────────────────────────────────
    'PEROVSKITE_ABX3': {
        description: 'Pérovskite ABX3 - Cubique/Orthorhombique',
        ibrav: [1, 2, 3, 221, 8, 9, 10, 11],  // Cubic + Orthorhombic
        ntyp: 3,
        nat: 5,  // 1A + 1B + 3X
        exemples: ['BaTiO3', 'SrTiO3', 'CaTiO3', 'BaFeO3', 'LaAlO3', 'GdAlO3', 'PrAlO3', 'NdAlO3', 'SmAlO3', 'YAlO3']
    },
    'CHALCOPYRITE_ABX2': {
        description: 'Chalcopyrite ABX2 - Tétragonal',
        ibrav: [6, 7],  // Tetragonal
        ntyp: 3,
        nat: 8,  // 2A + 2B + 4X
        exemples: ['CuInSe2', 'CuGaSe2', 'AgGaSe2', 'ZnSiP2']
    },
    'HEUSLER_ABC': {
        description: 'Heusler complet ABC - Cubique',
        ibrav: [1, 2],  // Cubic/FCC
        ntyp: 3,
        nat: 4,
        exemples: ['Co2MnSi', 'Co2FeSi', 'Cu2MnAl']
    },
    'DELAFOSSITE_ABX2': {
        description: 'Delafossite ABX2 - Hexagonal/Rhombohedral',
        ibrav: [4, 5],  // Hexagonal/Rhombohedral
        ntyp: 3,
        nat: 4,  // 1A + 1B + 2X
        exemples: ['CuAlO2', 'CuGaO2', 'PdCoO2']
    },
    
    // ─────────────────────────────────────────────────────────────────────
    // QUATERNAIRES (ntyp=4)
    // ─────────────────────────────────────────────────────────────────────
    'DOUBLE_PEROVSKITE_A2BBX6': {
        description: 'Double Pérovskite A2BB\'X6 - Cubique',
        ibrav: [1, 2],  // Cubic
        ntyp: 4,
        nat: 10,  // 2A + 1B + 1B\' + 6X
        exemples: ['Sr2FeMoO6', 'Ba2FeMoO6', 'La2NiMnO6']
    },
    'QUATERNAIRE_ABCX2': {
        description: 'Quaternaire ABCX2 - Tétragonal',
        ibrav: [6, 7],  // Tetragonal
        ntyp: 4,
        nat: 10,
        exemples: ['Cu2ZnSnSe4', 'Cu2ZnSnS4']
    },
    
    // ─────────────────────────────────────────────────────────────────────
    // SPINELLES ET COMPOSÉS COMPLEXES
    // ─────────────────────────────────────────────────────────────────────
    'SPINELLE_AB2X4': {
        description: 'Spinelle AB2X4 - Cubique',
        ibrav: [1, 2],  // Cubic/FCC
        ntyp: 3,
        nat: 14,  // 2A + 4B + 8X
        exemples: ['MgAl2O4', 'ZnFe2O4', 'CoFe2O4']
    },
    
    // ─────────────────────────────────────────────────────────────────────
    // CUPRATES SUPRACONDUCTEURS
    // ─────────────────────────────────────────────────────────────────────
    'YBCO_YBa2Cu3O7': {
        description: 'YBCO YBa2Cu3O7 - Orthorhombique',
        ibrav: [8, 9, 10, 11],  // Orthorhombic
        ntyp: 4,
        nat: 13,  // 1Y + 2Ba + 3Cu + 7O
        exemples: ['YBa2Cu3O7', 'YBa2Cu3O6']
    }
};

// ═══════════════════════════════════════════════════════════════════════════
// DÉTECTEUR DE TYPE DE STRUCTURE
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Détecter le type de structure à partir du matériau et de ntyp
 */
function detecterTypeStructure(materiau, ntyp, ibrav) {
    const mat = materiau.toLowerCase().trim();
    
    // ⭐ DÉTECTION GÉNÉRIQUE PRIORITAIRE POUR PÉROVSKITES
    // Si ntyp=3 + ibrav cubique/ortho + formule type ABX3 → Pérovskite!
    const isStructureCubique = ['1', '2', '3', '221'].includes(ibrav);
    const isStructureOrtho = ['8', '9', '10', '11'].includes(ibrav);
    const hasPerovskiteFormula = /^[a-z]{1,2}[a-z]{1,2}o3$/i.test(mat.replace(/\s/g, ''));
    
    if (ntyp === 3 && (isStructureCubique || isStructureOrtho) && hasPerovskiteFormula) {
        console.log(`✓ Structure PÉROVSKITE ABX3 détectée (générique): ${materiau}`);
        return 'PEROVSKITE_ABX3';
    }
    
    // Détection par nom exact (patterns spécifiques)
    const detecteurs = [
        // Pérovskites (avec pattern très large)
        { pattern: /([a-z]{1,2})([a-z]{1,2})(o|f)3$/i, type: 'PEROVSKITE_ABX3', condition: () => ntyp === 3 },
        
        // Chalcopyrites
        { pattern: /(cu|ag)(in|ga|al)(se|s|te)2/i, type: 'CHALCOPYRITE_ABX2' },
        { pattern: /zn(si|ge)(p|as)2/i, type: 'CHALCOPYRITE_ABX2' },
        
        // Wurtzite
        { pattern: /(zn|ga|al|in)(o|n|s)$/i, type: 'BINAIRE_WURTZITE', condition: () => ntyp === 2 },
        
        // Delafossite
        { pattern: /(cu|pd|pt)(al|ga|in|co|rh|cr)o2/i, type: 'DELAFOSSITE_ABX2' },
        
        // YBCO
        { pattern: /yba2cu3o[67]/i, type: 'YBCO_YBa2Cu3O7' },
        
        // Double Pérovskite
        { pattern: /(sr|ba|la)2(fe|co|ni|mn)(mo|w|re)o6/i, type: 'DOUBLE_PEROVSKITE_A2BBX6' },
        
        // Spinelle
        { pattern: /(mg|zn|co|ni|mn)(al|fe|cr)2o4/i, type: 'SPINELLE_AB2X4' }
    ];
    
    for (const det of detecteurs) {
        if (det.pattern.test(mat)) {
            // Vérifier condition supplémentaire si présente
            if (det.condition && !det.condition()) {
                continue;
            }
            console.log(`✓ Structure détectée: ${det.type}`);
            return det.type;
        }
    }
    
    // Détection générique par ntyp
    console.log('⚠️ Structure non reconnue, utilisation détection générique');
    return null;
}

/**
 * Calculer nat automatiquement
 */
function calculerNatAutomatique() {
    console.log('\n🧮 Calcul automatique de nat...');
    
    const materiauxInput = document.getElementById('materiau_name');
    const ntypInput = document.getElementById('ntyp');
    const ibravSelect = document.getElementById('ibrav');
    const natInput = document.getElementById('nat');
    
    if (!materiauxInput || !ntypInput || !ibravSelect || !natInput) {
        console.warn('⚠️ Champs manquants');
        return;
    }
    
    const materiau = materiauxInput.value.trim();
    const ntyp = parseInt(ntypInput.value) || 0;
    const ibrav = ibravSelect.value;
    
    console.log(`  Matériau: ${materiau}`);
    console.log(`  ntyp: ${ntyp}`);
    console.log(`  ibrav: ${ibrav}`);
    
    if (!materiau || ntyp === 0) {
        console.log('⚠️ Matériau ou ntyp non renseignés');
        return;
    }
    
    // Détecter le type de structure (avec ibrav)
    const typeStructure = detecterTypeStructure(materiau, ntyp, ibrav);
    
    if (typeStructure && STRUCTURES_NAT[typeStructure]) {
        const structure = STRUCTURES_NAT[typeStructure];
        
        // Vérifier que ntyp correspond
        if (structure.ntyp === ntyp) {
            const natCalcule = structure.nat;
            
            console.log(`✅ Structure: ${structure.description}`);
            console.log(`✅ nat calculé: ${natCalcule}`);
            
            // Remplir automatiquement
            natInput.value = natCalcule;
            
            // Afficher une info visuelle
            afficherInfoNat(structure, natCalcule);
            
            // Déclencher l'événement pour mettre à jour le reste
            natInput.dispatchEvent(new Event('input', { bubbles: true }));
            
            return natCalcule;
        }
    }
    
    // Si pas trouvé, proposer une estimation
    const natEstime = estimerNatGenerique(ntyp, ibrav);
    if (natEstime) {
        console.log(`⚠️ Estimation générique: nat ≈ ${natEstime}`);
        afficherInfoNatEstime(natEstime);
    }
    
    return null;
}

/**
 * Estimation générique de nat basée sur ntyp et ibrav
 */
function estimerNatGenerique(ntyp, ibrav) {
    // Règles génériques simples
    const ibravNum = parseInt(ibrav);
    
    if (ntyp === 2) {
        // Binaire: généralement 2-8 atomes
        if ([2, 3].includes(ibravNum)) return 2; // FCC, BCC
        if ([4].includes(ibravNum)) return 4; // Hexagonal (wurtzite)
        return 2;
    } else if (ntyp === 3) {
        // Ternaire: 4-8 atomes typiquement
        if ([1, 2].includes(ibravNum)) return 5; // Pérovskite probable
        if ([6, 7].includes(ibravNum)) return 8; // Chalcopyrite probable
        return 5;
    } else if (ntyp === 4) {
        // Quaternaire: 10-14 atomes
        return 10;
    }
    
    return null;
}

/**
 * Afficher info visuelle pour nat calculé
 */
function afficherInfoNat(structure, nat) {
    const natInput = document.getElementById('nat');
    if (!natInput) return;
    
    // Créer/mettre à jour le message
    let infoDiv = document.getElementById('nat_info');
    if (!infoDiv) {
        infoDiv = document.createElement('div');
        infoDiv.id = 'nat_info';
        infoDiv.style.cssText = `
            margin-top: 8px;
            padding: 10px 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 8px;
            font-size: 13px;
            line-height: 1.6;
            box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
        `;
        natInput.parentElement.appendChild(infoDiv);
    }
    
    infoDiv.innerHTML = `
        <div style="font-weight: bold; margin-bottom: 5px;">
            ✅ nat = ${nat} (calculé automatiquement)
        </div>
        <div style="opacity: 0.95;">
            ${structure.description}
        </div>
        <div style="opacity: 0.85; font-size: 11px; margin-top: 5px;">
            Exemples: ${structure.exemples.join(', ')}
        </div>
    `;
}

/**
 * Afficher estimation générique
 */
function afficherInfoNatEstime(nat) {
    const natInput = document.getElementById('nat');
    if (!natInput) return;
    
    let infoDiv = document.getElementById('nat_info');
    if (!infoDiv) {
        infoDiv = document.createElement('div');
        infoDiv.id = 'nat_info';
        infoDiv.style.cssText = `
            margin-top: 8px;
            padding: 10px 15px;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            border-radius: 8px;
            font-size: 13px;
            line-height: 1.6;
            box-shadow: 0 2px 8px rgba(240, 147, 251, 0.3);
        `;
        natInput.parentElement.appendChild(infoDiv);
    }
    
    infoDiv.innerHTML = `
        <div style="font-weight: bold; margin-bottom: 5px;">
            ⚠️ nat ≈ ${nat} (estimation)
        </div>
        <div style="opacity: 0.95; font-size: 12px;">
            Structure non reconnue automatiquement.<br>
            Vérifiez manuellement le nombre d'atomes.
        </div>
    `;
}

// ═══════════════════════════════════════════════════════════════════════════
// INITIALISATION ET ÉCOUTEURS
// ═══════════════════════════════════════════════════════════════════════════

function initialiserCalculateurNat() {
    console.log('🧮 Initialisation calculateur nat...');
    
    // Attendre que les champs soient créés
    setTimeout(() => {
        const materiauxInput = document.getElementById('materiau_name');
        const ntypInput = document.getElementById('ntyp');
        const ibravSelect = document.getElementById('ibrav');
        
        if (materiauxInput && ntypInput && ibravSelect) {
            // Déclencher le calcul quand matériau, ntyp ou ibrav change
            materiauxInput.addEventListener('input', calculerNatAutomatique);
            ntypInput.addEventListener('input', calculerNatAutomatique);
            ibravSelect.addEventListener('change', calculerNatAutomatique);
            
            console.log('✅ Calculateur nat initialisé');
        } else {
            console.warn('⚠️ Champs non trouvés, réessai...');
            setTimeout(initialiserCalculateurNat, 500);
        }
    }, 1000);
}

// Exécuter au chargement
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialiserCalculateurNat);
} else {
    initialiserCalculateurNat();
}


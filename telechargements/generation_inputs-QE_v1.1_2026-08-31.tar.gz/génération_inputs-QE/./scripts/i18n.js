/**
 * Internationalisation FR / EN — Génération Inputs QE
 */
(function () {
    'use strict';

    var STORAGE_KEY = 'GEN_INPUTS_LANG';

    var STR = { fr: {}, en: {} };

    function mergeStrings() {
        if (window.I18N_STRINGS) {
            Object.keys(window.I18N_STRINGS.fr || {}).forEach(function (k) {
                STR.fr[k] = window.I18N_STRINGS.fr[k];
            });
            Object.keys(window.I18N_STRINGS.en || {}).forEach(function (k) {
                STR.en[k] = window.I18N_STRINGS.en[k];
            });
        }
    }
    mergeStrings();

    function normalizeLang(lang) {
        return String(lang || '').toLowerCase().indexOf('en') === 0 ? 'en' : 'fr';
    }

    window.getQeLang = function getQeLang() {
        var attr = document.documentElement.getAttribute('data-lang');
        if (attr === 'en' || attr === 'fr') return attr;
        return 'fr';
    };

    window.t = function t(key, vars) {
        mergeStrings();
        var lang = window.getQeLang();
        var table = STR[lang] || STR.fr;
        var text = table[key];
        if (text == null) text = (STR.fr[key] != null ? STR.fr[key] : key);
        if (vars && typeof vars === 'object') {
            Object.keys(vars).forEach(function (k) {
                text = String(text).split('{' + k + '}').join(String(vars[k]));
            });
        }
        return text;
    };

    function applyElementI18n(el, lang) {
        var key = el.getAttribute('data-i18n');
        if (key) {
            var val = window.t(key);
            if (el.getAttribute('data-i18n-html') === '1') el.innerHTML = val;
            else el.textContent = val;
            return;
        }
        var fr = el.getAttribute('data-i18n-fr');
        if (fr != null) {
            var en = el.getAttribute('data-i18n-en') || fr;
            var txt = lang === 'en' ? en : fr;
            if (el.getAttribute('data-i18n-html') === '1') el.innerHTML = txt;
            else el.textContent = txt;
        }
    }

    window.applyI18n = function applyI18n(root) {
        mergeStrings();
        var lang = window.getQeLang();
        document.documentElement.setAttribute('lang', lang);
        var scope = root && root.querySelectorAll ? root : document;

        scope.querySelectorAll('[data-i18n], [data-i18n-fr]').forEach(function (el) {
            applyElementI18n(el, lang);
        });

        scope.querySelectorAll('[data-i18n-title]').forEach(function (el) {
            var k = el.getAttribute('data-i18n-title');
            if (k) el.title = window.t(k);
        });

        scope.querySelectorAll('[data-i18n-placeholder]').forEach(function (el) {
            var k = el.getAttribute('data-i18n-placeholder');
            if (k) el.placeholder = window.t(k);
        });

        var langBtn = document.getElementById('qe_lang_toggle');
        if (langBtn) {
            langBtn.textContent = lang === 'en' ? window.t('lang.switch_fr') : window.t('lang.switch_en');
            langBtn.title = window.t('lang.title');
            langBtn.setAttribute('aria-label', window.t('lang.title'));
        }

        if (typeof window.refreshThemeToggleLabels === 'function') {
            window.refreshThemeToggleLabels();
        }

        try {
            document.dispatchEvent(new CustomEvent('qe:langchange', { detail: { lang: lang } }));
        } catch (_eEv) {}
    };

    window.snapshotFormFields = function snapshotFormFields(root) {
        var snap = {};
        var scope = root || document;
        scope.querySelectorAll('input, select, textarea').forEach(function (el) {
            if (!el.id) return;
            if (el.type === 'checkbox' || el.type === 'radio') {
                if (el.type === 'radio' && !el.checked) return;
                snap[el.id] = el.type === 'checkbox' ? el.checked : (el.checked ? el.value : snap[el.id]);
            } else {
                snap[el.id] = el.value;
            }
        });
        return snap;
    };

    window.restoreFormFields = function restoreFormFields(snap) {
        if (!snap) return;
        Object.keys(snap).forEach(function (id) {
            var el = document.getElementById(id);
            if (!el) return;
            var v = snap[id];
            if (el.type === 'checkbox') el.checked = !!v;
            else if (el.type === 'radio') el.checked = (el.value === v || v === true);
            else el.value = v;
        });
    };

    window.refreshAllUiLang = function refreshAllUiLang() {
        mergeStrings();
        var lang = window.getQeLang();
        document.documentElement.setAttribute('lang', lang);

        if (typeof window.rebuildTab1ForLanguage === 'function') {
            window.rebuildTab1ForLanguage();
        }

        var gest = document.getElementById('subsection_gestion');
        document.querySelectorAll('[data-i18n], [data-i18n-fr]').forEach(function (el) {
            applyElementI18n(el, lang);
        });
        document.querySelectorAll('[data-i18n-title]').forEach(function (el) {
            var k = el.getAttribute('data-i18n-title');
            if (k) el.title = window.t(k);
        });
        document.querySelectorAll('[data-i18n-placeholder]').forEach(function (el) {
            var k = el.getAttribute('data-i18n-placeholder');
            if (k) el.placeholder = window.t(k);
        });

        var langBtn = document.getElementById('qe_lang_toggle');
        if (langBtn) {
            langBtn.textContent = lang === 'en' ? window.t('lang.switch_fr') : window.t('lang.switch_en');
            langBtn.title = window.t('lang.title');
            langBtn.setAttribute('aria-label', window.t('lang.title'));
        }
        if (typeof window.refreshThemeToggleLabels === 'function') {
            window.refreshThemeToggleLabels();
        }
        if (typeof window.__gestRefreshCifFloatingBarI18n === 'function') {
            window.__gestRefreshCifFloatingBarI18n();
        }
        var listeCif = document.getElementById('liste_fichiers_cif');
        if (listeCif && listeCif.querySelector('.gest-cif-file-card') && typeof window.listerFichiersCIF === 'function') {
            try { window.listerFichiersCIF(); } catch (_eCif) {}
        }
        var listeIn = document.getElementById('liste_inputs_existants');
        if (listeIn && listeIn.children.length && typeof window.listerInputsExistants === 'function') {
            try { window.listerInputsExistants(); } catch (_eIn) {}
        }
        try {
            document.dispatchEvent(new CustomEvent('qe:langchange', { detail: { lang: lang } }));
        } catch (_eEv) {}
    };

    window.setQeLang = function setQeLang(lang) {
        var l = normalizeLang(lang);
        document.documentElement.setAttribute('data-lang', l);
        try { localStorage.setItem(STORAGE_KEY, l); } catch (_eLs) {}
        window.refreshAllUiLang();
    };

    window.toggleQeLang = function toggleQeLang() {
        window.setQeLang(window.getQeLang() === 'en' ? 'fr' : 'en');
    };

    function initLang() {
        var saved = null;
        try { saved = localStorage.getItem(STORAGE_KEY); } catch (_eGet) {}
        if (saved === 'en' || saved === 'fr') {
            document.documentElement.setAttribute('data-lang', saved);
            return;
        }
        var nav = (navigator.language || navigator.userLanguage || 'fr').toLowerCase();
        document.documentElement.setAttribute('data-lang', nav.indexOf('en') === 0 ? 'en' : 'fr');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initLang);
    } else {
        initLang();
    }
})();

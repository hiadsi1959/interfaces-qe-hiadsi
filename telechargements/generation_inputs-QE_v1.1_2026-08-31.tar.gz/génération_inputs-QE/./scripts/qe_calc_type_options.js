/**
 * Options « Sélectionnez le type de calcul » — programmes QE 7.5+ (pw + post-pw).
 * Voies directe et CIF : même liste (#calc_type, #cif_calc_type, #gestion_cif_calc_type).
 */
(function () {
    'use strict';

    /** @type {Array<{group:string, options:Array<{value:string,label:string,exe?:string,hint?:string,pw?:boolean}>}>} */
    var QE_CALC_TYPE_GROUPS = [
        {
            group: 'pw.x — Calculs DFT (INPUT_PW)',
            options: [
                { value: 'scf', label: 'SCF — Self-Consistent Field', exe: 'pw.x', pw: true,
                  hint: 'Énergie / densité électronique. Point de départ de tout workflow.' },
                { value: 'relax', label: 'RELAX — Relaxation ionique (maille fixe)', exe: 'pw.x', pw: true,
                  hint: 'Minimise les forces. &IONS requis.' },
                { value: 'vc-relax', label: 'VC-RELAX — Relaxation complète', exe: 'pw.x', pw: true,
                  hint: 'Positions + maille. &IONS + &CELL.' },
                { value: 'nscf', label: 'NSCF — Non Self-Consistent', exe: 'pw.x', pw: true,
                  hint: 'Grille k dense, restart. Pour DOS / optique / PDOS.' },
                { value: 'bands', label: 'BANDS — Structure de bandes', exe: 'pw.x', pw: true,
                  hint: 'K_POINTS crystal_b, restart après SCF/NSCF.' },
                { value: 'md', label: 'MD — Dynamique moléculaire', exe: 'pw.x', pw: true,
                  hint: 'ion_dynamics=verlet, tempw, dt, nstep.' },
                { value: 'vc-md', label: 'VC-MD — MD maille variable', exe: 'pw.x', pw: true,
                  hint: 'MD + relaxation maille. &IONS + &CELL (QE 7.5).' }
            ]
        },
        {
            group: 'Électronique — DOS, charge, potentiels',
            options: [
                { value: 'dos', label: 'DOS — Densité d\'états', exe: 'dos.x', pw: false,
                  hint: 'Après NSCF. &DOS.' },
                { value: 'projwfc', label: 'PROJWFC — DOS projetée (PDOS)', exe: 'projwfc.x', pw: false,
                  hint: 'Projection orbitale après NSCF.' },
                { value: 'bands_pp', label: 'BANDS_PP — Post-traitement bandes', exe: 'bands.x', pw: false,
                  hint: 'Après calcul BANDS pw.x.' },
                { value: 'plotband', label: 'PLOTBAND — Tracé bandes', exe: 'plotband.x', pw: false,
                  hint: 'Visualisation bandes après bands.x.' },
                { value: 'pp_charge', label: 'PP_CHARGE — Densité de charge', exe: 'pp.x', pw: false,
                  hint: 'plot_num=0, charge ρ(r).' },
                { value: 'pp_potential', label: 'PP_POTENTIAL — Potentiel total', exe: 'pp.x', pw: false,
                  hint: 'plot_num=1, V_tot(r).' },
                { value: 'pp_ldos', label: 'PP_LDOS — Densité d\'états locale', exe: 'pp.x', pw: false,
                  hint: 'plot_num=5, LDOS(r,E).' },
                { value: 'pp_elf', label: 'PP_ELF — Fonction de localisation', exe: 'pp.x', pw: false,
                  hint: 'plot_num=6, ELF(r).' },
                { value: 'pp_vh', label: 'PP_VH — Potentiel Hartree', exe: 'pp.x', pw: false,
                  hint: 'plot_num=11, V_H(r).' },
                { value: 'pp_spin', label: 'PP_SPIN — Polarisation de spin', exe: 'pp.x', pw: false,
                  hint: 'plot_num=8, ρ↑−ρ↓ (nspin=2).' },
                { value: 'average', label: 'AVERAGE — Moyennes planaires / sphériques', exe: 'average.x', pw: false,
                  hint: 'Moyennage charge ou potentiel.' },
                { value: 'plotrho', label: 'PLOTRHO — Visualisation charge 2D', exe: 'plotrho.x', pw: false,
                  hint: 'Après pp.x (fichier .rho).' }
            ]
        },
        {
            group: 'Optique & spectroscopie',
            options: [
                { value: 'epsilon', label: 'EPSILON — Fonction diélectrique ε(ω)', exe: 'epsilon.x', pw: false,
                  hint: 'Réponse optique linéaire (DFPT).' },
                { value: 'turbo_lanczos', label: 'TURBO_LANCZOS — Absorption LR-TDDFT', exe: 'turbo_lanczos.x', pw: false,
                  hint: 'Spectres optiques (Lanczos) + turbo_spectrum.x.' },
                { value: 'turbo_davidson', label: 'TURBO_DAVIDSON — Spectroscopie optique', exe: 'turbo_davidson.x', pw: false,
                  hint: 'Alternative Davidson pour excitations.' },
                { value: 'turbo_eels', label: 'TURBO_EELS — Spectroscopie EELS', exe: 'turbo_eels.x', pw: false,
                  hint: 'Perte d\'énergie électronique en transmission.' },
                { value: 'xspectra', label: 'XSPECTRA — Spectres de rayons X', exe: 'xspectra.x', pw: false,
                  hint: 'Absorption XANES / spectroscopie X.' }
            ]
        },
        {
            group: 'Polarisation & charges effectives (après VC-RELAX)',
            options: [
                { value: 'scf_berry', label: 'SCF + Phase de Berry (polarisation)', exe: 'pw.x', pw: true,
                  hint: 'Étape 3A : pw.x SCF + namelist &BP (lberry, gdir, nppstr) — après vc-relax et coordonnées finales.' },
                { value: 'scf_born', label: 'SCF strict — préparation Born (conv_thr 1.d-12)', exe: 'pw.x', pw: true,
                  hint: 'Étape 3B-1 : SCF très convergé avant ph.x zeu — après vc-relax.' },
                { value: 'ph_zeu', label: 'PH_ZEU — Charges effectives de Born', exe: 'ph.x', pw: false,
                  hint: 'Étape 3B-2 : ph.x avec zeu=.true. à Γ — après SCF strict (scf_born).' }
            ]
        },
        {
            group: 'Phonons & vibrations',
            options: [
                { value: 'ph', label: 'PH — Phonons DFPT', exe: 'ph.x', pw: false,
                  hint: 'Calcul phonons après SCF convergé.' },
                { value: 'q2r', label: 'Q2R — Transformée Fourier q→r', exe: 'q2r.x', pw: false,
                  hint: 'Matrice de force en espace réel.' },
                { value: 'matdyn_disp', label: 'MATDYN_DISP — Dispersion phonons', exe: 'matdyn.x', pw: false,
                  hint: 'Courbes de dispersion ω(q).' },
                { value: 'matdyn_dos', label: 'MATDYN_DOS — DOS phonons', exe: 'matdyn.x', pw: false,
                  hint: 'Densité d\'états vibrationnelle g(ω).' },
                { value: 'matdyn_thermo', label: 'MATDYN_THERMO — Thermodynamique', exe: 'matdyn.x', pw: false,
                  hint: 'Entropie / chaleur spécifique via phonons.' },
                { value: 'dynmat', label: 'DYNMAT — Modes à Γ', exe: 'dynmat.x', pw: false,
                  hint: 'Fréquences et vecteurs propres à q=0.' }
            ]
        },
        {
            group: 'Supraconductivité & électron-phonon',
            options: [
                { value: 'alpha2f', label: 'ALPHA2F — Fonction Eliashberg α²F(ω)', exe: 'alpha2f.x', pw: false,
                  hint: 'Couplement e-ph spectral (BCS/McMillan).' },
                { value: 'lambda', label: 'LAMBDA — Constante λ e-ph', exe: 'lambda.x', pw: false,
                  hint: 'Intégrale du couplement électron-phonon.' },
                { value: 'epw', label: 'EPW — Transport & supraconductivité', exe: 'epw.x', pw: false,
                  hint: 'Couplage e-ph complet, Tc, mobilité (si EPW installé).' }
            ]
        },
        {
            group: 'Hubbard, dynamique & réactions',
            options: [
                { value: 'hp', label: 'HP — Paramètres Hubbard U/J', exe: 'hp.x', pw: false,
                  hint: 'U et J ab initio (DFT+U).' },
                { value: 'cp', label: 'CP — Dynamique Car-Parrinello', exe: 'cp.x', pw: false,
                  hint: 'MD électronique ab-initio (template à compléter).' },
                { value: 'neb', label: 'NEB — Nudged Elastic Band', exe: 'neb.x', pw: false,
                  hint: 'Barrières de réaction, chemins minimaux.' },
                { value: 'pw2wan', label: 'PW2WAN — Interface Wannier90', exe: 'pw2wannier90.x', pw: false,
                  hint: 'Export pour Wannier90 après NSCF.' }
            ]
        }
    ];

    var PW_SET = {};
    var AUX_SET = {};
    var ALL_SET = {};
    var META = {};

    QE_CALC_TYPE_GROUPS.forEach(function (g) {
        (g.options || []).forEach(function (o) {
            ALL_SET[o.value] = true;
            META[o.value] = o;
            if (o.pw) PW_SET[o.value] = true;
            else AUX_SET[o.value] = true;
        });
    });

    window.QE_CALC_TYPE_GROUPS = QE_CALC_TYPE_GROUPS;
    window.QE_PW_CALC_TYPES = Object.keys(PW_SET);
    window.QE_AUX_INPUT_TYPES = Object.keys(AUX_SET);

    window.qeIsPwCalcType = function (t) {
        return !!PW_SET[String(t || '').trim().toLowerCase()];
    };

    window.qeIsAuxInputType = function (t) {
        return !!AUX_SET[String(t || '').trim().toLowerCase()];
    };

    window.qeGetCalcTypeMeta = function (t) {
        return META[String(t || '').trim().toLowerCase()] || null;
    };

    window.populateCalcTypeSelect = function populateCalcTypeSelect(selectEl, opts) {
        if (!selectEl) return;
        opts = opts || {};
        var prev = selectEl.value;
        var includePlaceholder = opts.placeholder !== false;
        var defaultVal = opts.defaultValue || 'scf';

        var html = '';
        if (includePlaceholder) {
            html += '<option value="">-- Sélectionner un type de calcul --</option>';
        }
        QE_CALC_TYPE_GROUPS.forEach(function (g) {
            html += '<optgroup label="' + String(g.group).replace(/"/g, '&quot;') + '">';
            (g.options || []).forEach(function (o) {
                var sel = (prev && prev === o.value) || (!prev && o.value === defaultVal) ? ' selected' : '';
                html += '<option value="' + o.value + '"' + sel
                    + ' data-exe="' + (o.exe || '') + '"'
                    + ' data-pw="' + (o.pw ? '1' : '0') + '"'
                    + ' title="' + String(o.hint || '').replace(/"/g, '&quot;') + '">'
                    + o.label + '</option>';
            });
            html += '</optgroup>';
        });
        selectEl.innerHTML = html;
        if (prev && ALL_SET[prev]) selectEl.value = prev;
        else if (!selectEl.value) selectEl.value = defaultVal;
    };

    window.populateAllCalcTypeSelects = function populateAllCalcTypeSelects() {
        document.querySelectorAll('#calc_type, #cif_calc_type, #gestion_cif_calc_type').forEach(function (el) {
            populateCalcTypeSelect(el, { defaultValue: 'scf' });
        });
    };

    document.addEventListener('tab1Restructured', function () {
        setTimeout(populateAllCalcTypeSelects, 80);
    });
    document.addEventListener('htmlFragmentsLoaded', function () {
        setTimeout(populateAllCalcTypeSelects, 50);
        setTimeout(populateAllCalcTypeSelects, 400);
    });
    window.addEventListener('load', function () {
        setTimeout(populateAllCalcTypeSelects, 500);
        setTimeout(populateAllCalcTypeSelects, 1500);
    });

    console.log('✅ Options types de calcul QE 7.5 chargées (' + Object.keys(ALL_SET).length + ' types)');
})();

/**
 * convergence_profiles.js — Profils de convergence optimaux Quantum ESPRESSO
 *
 * Ce fichier définit des profils de paramètres de convergence pour chaque
 * type de matériau et type de calcul. Il sert de source unique de vérité
 * côté frontend, en miroir du fichier Python cif_to_qe.py.
 *
 * Utilisation :
 *   const profile = getConvergenceProfile('mag_insulator', 'vc-relax');
 *   console.log(profile.ecutwfc, profile.mixing_beta);
 */

// ── Classification des matériaux ──
const MATERIAL_CLASSES = [
    { id: "metal",         name: "Métal",             description: "Bon conducteur (Cu, Al, Na…)" },
    { id: "insulator",     name: "Isolant",           description: "Gap > 3 eV (MgO, NaCl, BaTiO₃…)" },
    { id: "semiconductor", name: "Semi-conducteur",   description: "Gap 0.5-3 eV (Si, GaAs…)" },
    { id: "mag_metal",     name: "Métal magnétique",  description: "Fe, Co, Ni, alliages ferromagnétiques" },
    { id: "mag_insulator", name: "Isolant magnétique", description: "Oxydes magnétiques (NiO, Fe₂O₃, LaVO₃…)" },
    { id: "rare_earth",    name: "Terre rare / f",    description: "Gd, Dy, Ce… forts corrélations, Hubbard U" },
    { id: "organic",       name: "Organique",         description: "Polymères, cristaux moléculaires, point Γ" },
    { id: "unknown",       name: "Non déterminé",     description: "Paramètres par défaut prudents" },
];

const MATERIAL_CLASS_MAP = {};
MATERIAL_CLASSES.forEach(function(c) { MATERIAL_CLASS_MAP[c.id] = c; });

// ── Profils de convergence ──
// Structure : CONVERGENCE_PROFILES[classe_materiau][type_calcul] = { paramètres }
const CONVERGENCE_PROFILES = {};

// ─── Métal ───
CONVERGENCE_PROFILES["metal"] = {
    scf: {
        ecutwfc: 55, ecutrho: 440, conv_thr: "1.0d-8",
        mixing_beta: 0.5, occupations: "smearing", smearing: "methfessel-paxton",
        degauss: 0.02, kpoints: [8,8,8],
        forc_conv_thr: "1.0d-4", electron_maxstep: 150,
        note: "Métal : smearing MP pour DOS fin, mixing_beta modéré"
    },
    relax: {
        ecutwfc: 65, ecutrho: 520, conv_thr: "1.0d-9",
        mixing_beta: 0.4, occupations: "smearing", smearing: "methfessel-paxton",
        degauss: 0.02, kpoints: [6,6,6],
        forc_conv_thr: "1.0d-4", electron_maxstep: 150,
        note: "Métal relax : ecutwfc +10 Ry pour forces précises"
    },
    "vc-relax": {
        ecutwfc: 75, ecutrho: 600, conv_thr: "1.0d-9",
        mixing_beta: 0.3, occupations: "smearing", smearing: "methfessel-paxton",
        degauss: 0.02, kpoints: [8,8,8],
        forc_conv_thr: "1.0d-4", press_conv_thr: "0.5", electron_maxstep: 200,
        note: "Métal vc-relax : ecutwfc bien convergé, mixing_beta bas"
    },
    nscf: {
        ecutwfc: 55, ecutrho: 440, conv_thr: "1.0d-10",
        mixing_beta: 0.5, occupations: "tetrahedra", smearing: "gaussian",
        degauss: 0.02, kpoints: [12,12,12],
        note: "NSCF métal : grille k très dense, occupations tetrahedra"
    },
    bands: {
        ecutwfc: 55, ecutrho: 440, conv_thr: "1.0d-10",
        mixing_beta: 0.5, occupations: "smearing", smearing: "methfessel-paxton",
        degauss: 0.02, kpoints: [8,8,8],
        note: "BANDS métal : mêmes paramètres que SCF"
    },
    md: {
        ecutwfc: 40, ecutrho: 320, conv_thr: "1.0d-7",
        mixing_beta: 0.5, occupations: "smearing", smearing: "methfessel-paxton",
        degauss: 0.02, kpoints: [2,2,2],
        note: "MD métal : ecutwfc réduit, conv_thr relâché"
    }
};

// ─── Isolant ───
CONVERGENCE_PROFILES["insulator"] = {
    scf: {
        ecutwfc: 45, ecutrho: 360, conv_thr: "1.0d-8",
        mixing_beta: 0.7, occupations: "fixed", smearing: "cold",
        degauss: 0.005, kpoints: [4,4,4],
        note: "Isolant : occupations fixed, convergence facile"
    },
    relax: {
        ecutwfc: 55, ecutrho: 440, conv_thr: "1.0d-9",
        mixing_beta: 0.5, occupations: "fixed", smearing: "cold",
        degauss: 0.005, kpoints: [4,4,4],
        forc_conv_thr: "1.0d-4",
        note: "Isolant relax : ecutwfc modéré"
    },
    "vc-relax": {
        ecutwfc: 65, ecutrho: 520, conv_thr: "1.0d-9",
        mixing_beta: 0.4, occupations: "fixed", smearing: "cold",
        degauss: 0.005, kpoints: [6,6,6],
        forc_conv_thr: "1.0d-4", press_conv_thr: "0.5",
        note: "Isolant vc-relax : paramètres standards"
    },
    nscf: {
        ecutwfc: 45, ecutrho: 360, conv_thr: "1.0d-10",
        mixing_beta: 0.7, occupations: "tetrahedra", smearing: "cold",
        degauss: 0.005, kpoints: [8,8,8],
        note: "NSCF isolant : grille 8×8×8"
    },
    bands: {
        ecutwfc: 45, ecutrho: 360, conv_thr: "1.0d-10",
        mixing_beta: 0.7, occupations: "fixed", smearing: "cold",
        degauss: 0.005, kpoints: [4,4,4],
        note: "BANDS isolant"
    },
    md: {
        ecutwfc: 35, ecutrho: 280, conv_thr: "1.0d-7",
        mixing_beta: 0.7, occupations: "fixed", smearing: "cold",
        degauss: 0.005, kpoints: [2,2,2],
        note: "MD isolant"
    }
};

// ─── Semi-conducteur ───
CONVERGENCE_PROFILES["semiconductor"] = {
    scf: {
        ecutwfc: 50, ecutrho: 400, conv_thr: "1.0d-8",
        mixing_beta: 0.7, occupations: "cold", smearing: "cold",
        degauss: 0.01, kpoints: [6,6,6],
        note: "Semiconductor SCF : cold smearing"
    },
    relax: {
        ecutwfc: 60, ecutrho: 480, conv_thr: "1.0d-9",
        mixing_beta: 0.5, occupations: "cold", smearing: "cold",
        degauss: 0.01, kpoints: [4,4,4],
        forc_conv_thr: "1.0d-4",
        note: "Semiconductor relax : ecutwfc 60 Ry"
    },
    "vc-relax": {
        ecutwfc: 70, ecutrho: 560, conv_thr: "1.0d-9",
        mixing_beta: 0.35, occupations: "cold", smearing: "cold",
        degauss: 0.01, kpoints: [6,6,6],
        forc_conv_thr: "1.0d-4", press_conv_thr: "0.5",
        note: "Semiconductor vc-relax"
    },
    nscf: {
        ecutwfc: 50, ecutrho: 400, conv_thr: "1.0d-10",
        mixing_beta: 0.7, occupations: "tetrahedra", smearing: "cold",
        degauss: 0.01, kpoints: [10,10,10],
        note: "NSCF semiconductor"
    },
    bands: {
        ecutwfc: 50, ecutrho: 400, conv_thr: "1.0d-10",
        mixing_beta: 0.7, occupations: "cold", smearing: "cold",
        degauss: 0.01, kpoints: [6,6,6],
        note: "BANDS semiconductor"
    },
    md: {
        ecutwfc: 40, ecutrho: 320, conv_thr: "1.0d-7",
        mixing_beta: 0.7, occupations: "cold", smearing: "cold",
        degauss: 0.01, kpoints: [2,2,2],
        note: "MD semiconductor"
    }
};

// ─── Métal magnétique ───
CONVERGENCE_PROFILES["mag_metal"] = {
    scf: {
        ecutwfc: 60, ecutrho: 480, conv_thr: "1.0d-9",
        mixing_beta: 0.3, occupations: "smearing", smearing: "methfessel-paxton",
        degauss: 0.02, kpoints: [8,8,8],
        electron_maxstep: 150,
        note: "Métal mag SCF : mixing_beta bas (0.3) pour stabilité spin"
    },
    relax: {
        ecutwfc: 70, ecutrho: 560, conv_thr: "1.0d-9",
        mixing_beta: 0.25, occupations: "smearing", smearing: "methfessel-paxton",
        degauss: 0.02, kpoints: [6,6,6],
        forc_conv_thr: "1.0d-4", electron_maxstep: 150,
        note: "Métal mag relax : mixing_beta 0.25"
    },
    "vc-relax": {
        ecutwfc: 80, ecutrho: 640, conv_thr: "1.0d-10",
        mixing_beta: 0.2, occupations: "smearing", smearing: "methfessel-paxton",
        degauss: 0.02, kpoints: [8,8,8],
        forc_conv_thr: "1.0d-5", press_conv_thr: "0.5", electron_maxstep: 200,
        note: "MÉTAL MAG vc-relax : ecutwfc 80 Ry, mixing_beta 0.2 !"
    },
    nscf: {
        ecutwfc: 60, ecutrho: 480, conv_thr: "1.0d-10",
        mixing_beta: 0.3, occupations: "tetrahedra", smearing: "methfessel-paxton",
        degauss: 0.02, kpoints: [12,12,12],
        note: "NSCF métal magnétique"
    },
    bands: {
        ecutwfc: 60, ecutrho: 480, conv_thr: "1.0d-10",
        mixing_beta: 0.3, occupations: "smearing", smearing: "methfessel-paxton",
        degauss: 0.02, kpoints: [8,8,8],
        note: "BANDS métal magnétique"
    },
    md: {
        ecutwfc: 45, ecutrho: 360, conv_thr: "1.0d-7",
        mixing_beta: 0.3, occupations: "smearing", smearing: "methfessel-paxton",
        degauss: 0.02, kpoints: [2,2,2],
        note: "MD métal magnétique"
    }
};

// ─── Isolant magnétique ───
CONVERGENCE_PROFILES["mag_insulator"] = {
    scf: {
        ecutwfc: 55, ecutrho: 440, conv_thr: "1.0d-9",
        mixing_beta: 0.3, occupations: "cold", smearing: "cold",
        degauss: 0.01, kpoints: [6,6,6],
        electron_maxstep: 150,
        note: "Isolant mag SCF : mixing_beta 0.3, cold smearing"
    },
    relax: {
        ecutwfc: 65, ecutrho: 520, conv_thr: "1.0d-9",
        mixing_beta: 0.25, occupations: "cold", smearing: "cold",
        degauss: 0.01, kpoints: [4,4,4],
        forc_conv_thr: "1.0d-5", electron_maxstep: 200,
        note: "Isolant mag relax : forc_conv_thr strict (1d-5)"
    },
    "vc-relax": {
        ecutwfc: 75, ecutrho: 600, conv_thr: "1.0d-10",
        mixing_beta: 0.2, occupations: "cold", smearing: "cold",
        degauss: 0.01, kpoints: [6,6,6],
        forc_conv_thr: "1.0d-5", press_conv_thr: "0.5", electron_maxstep: 250,
        note: "Isolant mag vc-relax : très strict"
    },
    nscf: {
        ecutwfc: 55, ecutrho: 440, conv_thr: "1.0d-10",
        mixing_beta: 0.3, occupations: "tetrahedra", smearing: "cold",
        degauss: 0.01, kpoints: [8,8,8],
        note: "NSCF isolant magnétique"
    },
    bands: {
        ecutwfc: 55, ecutrho: 440, conv_thr: "1.0d-10",
        mixing_beta: 0.3, occupations: "cold", smearing: "cold",
        degauss: 0.01, kpoints: [6,6,6],
        note: "BANDS isolant magnétique"
    },
    md: {
        ecutwfc: 40, ecutrho: 320, conv_thr: "1.0d-7",
        mixing_beta: 0.4, occupations: "cold", smearing: "cold",
        degauss: 0.01, kpoints: [2,2,2],
        note: "MD isolant magnétique"
    }
};

// ─── Terre rare / f-electron ───
CONVERGENCE_PROFILES["rare_earth"] = {
    scf: {
        ecutwfc: 65, ecutrho: 520, conv_thr: "1.0d-9",
        mixing_beta: 0.25, occupations: "cold", smearing: "cold",
        degauss: 0.01, kpoints: [6,6,6],
        electron_maxstep: 200,
        note: "Terre rare SCF : mixing_beta TRÈS bas (0.25), + Hubbard U"
    },
    relax: {
        ecutwfc: 75, ecutrho: 600, conv_thr: "1.0d-10",
        mixing_beta: 0.2, occupations: "cold", smearing: "cold",
        degauss: 0.01, kpoints: [4,4,4],
        forc_conv_thr: "1.0d-5", electron_maxstep: 250,
        note: "Terre rare relax : mixing_beta très bas (0.2)"
    },
    "vc-relax": {
        ecutwfc: 85, ecutrho: 680, conv_thr: "1.0d-10",
        mixing_beta: 0.15, occupations: "cold", smearing: "cold",
        degauss: 0.01, kpoints: [6,6,6],
        forc_conv_thr: "1.0d-5", press_conv_thr: "0.5", electron_maxstep: 300,
        note: "TERRE RARE vc-relax : ecutwfc 85 Ry, mixing_beta 0.15, 300 itérations max"
    },
    nscf: {
        ecutwfc: 65, ecutrho: 520, conv_thr: "1.0d-10",
        mixing_beta: 0.25, occupations: "tetrahedra", smearing: "cold",
        degauss: 0.01, kpoints: [8,8,8],
        note: "NSCF terre rare"
    },
    bands: {
        ecutwfc: 65, ecutrho: 520, conv_thr: "1.0d-10",
        mixing_beta: 0.25, occupations: "cold", smearing: "cold",
        degauss: 0.01, kpoints: [6,6,6],
        note: "BANDS terre rare"
    },
    md: {
        ecutwfc: 45, ecutrho: 360, conv_thr: "1.0d-7",
        mixing_beta: 0.35, occupations: "cold", smearing: "cold",
        degauss: 0.01, kpoints: [2,2,2],
        note: "MD terre rare"
    }
};

// ─── Organique ───
CONVERGENCE_PROFILES["organic"] = {
    scf: {
        ecutwfc: 40, ecutrho: 320, conv_thr: "1.0d-8",
        mixing_beta: 0.5, occupations: "fixed", smearing: "gaussian",
        degauss: 0.005, kpoints: [2,2,2],
        note: "Organique SCF : grille k clairsemée"
    },
    relax: {
        ecutwfc: 50, ecutrho: 400, conv_thr: "1.0d-9",
        mixing_beta: 0.4, occupations: "fixed", smearing: "gaussian",
        degauss: 0.005, kpoints: [1,1,1],
        forc_conv_thr: "1.0d-4",
        note: "Organique relax : point Γ seulement"
    },
    "vc-relax": {
        ecutwfc: 55, ecutrho: 440, conv_thr: "1.0d-9",
        mixing_beta: 0.35, occupations: "fixed", smearing: "gaussian",
        degauss: 0.005, kpoints: [1,1,1],
        forc_conv_thr: "1.0d-4", press_conv_thr: "0.5",
        note: "Organique vc-relax"
    },
    nscf: {
        ecutwfc: 40, ecutrho: 320, conv_thr: "1.0d-10",
        mixing_beta: 0.5, occupations: "tetrahedra", smearing: "gaussian",
        degauss: 0.005, kpoints: [4,4,4],
        note: "NSCF organique"
    },
    bands: {
        ecutwfc: 40, ecutrho: 320, conv_thr: "1.0d-10",
        mixing_beta: 0.5, occupations: "fixed", smearing: "gaussian",
        degauss: 0.005, kpoints: [2,2,2],
        note: "BANDS organique"
    },
    md: {
        ecutwfc: 30, ecutrho: 240, conv_thr: "1.0d-7",
        mixing_beta: 0.5, occupations: "fixed", smearing: "gaussian",
        degauss: 0.005, kpoints: [1,1,1],
        note: "MD organique : point Γ"
    }
};

// ─── Inconnu / défaut ───
CONVERGENCE_PROFILES["unknown"] = {
    scf: {
        ecutwfc: 50, ecutrho: 400, conv_thr: "1.0d-8",
        mixing_beta: 0.7, occupations: "smearing", smearing: "cold",
        degauss: 0.02, kpoints: [6,6,6],
        note: "Défaut : paramètres génériques"
    },
    relax: {
        ecutwfc: 60, ecutrho: 480, conv_thr: "1.0d-9",
        mixing_beta: 0.5, occupations: "smearing", smearing: "cold",
        degauss: 0.02, kpoints: [4,4,4],
        forc_conv_thr: "1.0d-4",
        note: "Défaut relax"
    },
    "vc-relax": {
        ecutwfc: 70, ecutrho: 560, conv_thr: "1.0d-9",
        mixing_beta: 0.35, occupations: "smearing", smearing: "cold",
        degauss: 0.02, kpoints: [6,6,6],
        forc_conv_thr: "1.0d-4", press_conv_thr: "0.5",
        note: "Défaut vc-relax"
    },
    nscf: {
        ecutwfc: 50, ecutrho: 400, conv_thr: "1.0d-10",
        mixing_beta: 0.7, occupations: "tetrahedra", smearing: "cold",
        degauss: 0.02, kpoints: [10,10,10],
        note: "Défaut NSCF"
    },
    bands: {
        ecutwfc: 50, ecutrho: 400, conv_thr: "1.0d-10",
        mixing_beta: 0.7, occupations: "smearing", smearing: "cold",
        degauss: 0.02, kpoints: [6,6,6],
        note: "Défaut BANDS"
    },
    md: {
        ecutwfc: 40, ecutrho: 320, conv_thr: "1.0d-7",
        mixing_beta: 0.7, occupations: "smearing", smearing: "cold",
        degauss: 0.02, kpoints: [2,2,2],
        note: "Défaut MD"
    }
};


// ═══════════════════════════════════════════════════════════════════════════════
// FONCTIONS D'ACCÈS AUX PROFILS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Récupère le profil de convergence optimal pour une classe de matériau
 * et un type de calcul donnés.
 *
 * @param {string} materialClass - Classe du matériau (ex. "mag_insulator", "rare_earth")
 * @param {string} calculationType - Type de calcul ("scf", "relax", "vc-relax", "nscf", "bands", "md")
 * @returns {object} Profil de convergence
 */
function getConvergenceProfile(materialClass, calculationType) {
    var mc = (materialClass || "unknown").trim().toLowerCase();
    var ct = (calculationType || "scf").trim().toLowerCase();
    var validTypes = ["scf", "relax", "vc-relax", "nscf", "bands", "md"];
    if (validTypes.indexOf(ct) === -1) ct = "scf";
    var classProfiles = CONVERGENCE_PROFILES[mc] || CONVERGENCE_PROFILES["unknown"];
    return classProfiles[ct] || CONVERGENCE_PROFILES["unknown"]["scf"];
}

/**
 * Détecte la classe d'un matériau à partir de sa formule chimique
 * et de la liste des espèces atomiques. Version JS de la fonction Python.
 *
 * @param {string} formula - Formule chimique (ex. "GdVO3", "Fe2O3")
 * @param {string[]} atomicSpecies - Liste des espèces (ex. ["Gd", "V", "O"])
 * @returns {string} ID de la classe de matériau
 */
function detectMaterialClass(formula, atomicSpecies) {
    var formulaUp = (formula || "").toUpperCase();
    var bases = [];
    var seen = {};
    (atomicSpecies || []).forEach(function(s) {
        var m = s.match(/^([A-Z][a-z]?)/);
        var base = m ? m[1] : s;
        if (!seen[base]) {
            seen[base] = true;
            bases.push(base);
        }
    });
    var hasO = bases.indexOf("O") !== -1;
    var hasC = bases.indexOf("C") !== -1;
    var hasH = bases.indexOf("H") !== -1;

    var rareEarth = ["Gd","Tb","Dy","Ho","Er","Tm","Yb","Ce","Pr","Nd","Sm","Eu","La"];
    var transMetals = ["Fe","Co","Ni","Mn","Cr","V","Cu","Zn"];
    var alkali = ["Li","Na","K","Rb","Cs","Be","Mg","Ca","Sr","Ba"];
    var semiClassic = ["Si","Ge","Ga","As","In","P","Sb"];
    var halogens = ["F","Cl","Br","I"];

    var foundRE = bases.some(function(b) { return rareEarth.indexOf(b) !== -1; });
    var foundTM = bases.some(function(b) { return transMetals.indexOf(b) !== -1; });
    var foundAlk = bases.some(function(b) { return alkali.indexOf(b) !== -1; });
    var foundSemi = bases.some(function(b) { return semiClassic.indexOf(b) !== -1; });
    var foundHal = bases.some(function(b) { return halogens.indexOf(b) !== -1; });

    // Organique
    if (hasC && hasH && (foundHal || hasO)) return "organic";

    // Terre rare → priorité haute (convergence difficile)
    if (foundRE) return "rare_earth";

    // Oxyde magnétique
    if (foundTM && hasO) return "mag_insulator";

    // Métal magnétique
    if (foundTM) return "mag_metal";

    // Oxyde isolant
    if (hasO && foundAlk) return "insulator";

    // Oxyde sans métal de transition
    if (hasO && !foundTM) return "insulator";

    // Métaux alcalins
    if (foundAlk) return "metal";

    // Semi-conducteurs classiques
    if (foundSemi) return "semiconductor";

    return "semiconductor";
}

/**
 * Applique un profil de convergence aux champs d'un formulaire.
 * Cherche les éléments par ID et y applique les valeurs du profil.
 *
 * @param {object} profile - Profil de convergence (retourné par getConvergenceProfile)
 * @param {string} calculationType - Type de calcul (optionnel)
 */
function applyConvergenceProfile(profile, calculationType) {
    if (!profile) return;

    var fields = {
        "ecutwfc": profile.ecutwfc,
        "ecutrho": profile.ecutrho,
        "conv_thr": profile.conv_thr,
        "mixing_beta": profile.mixing_beta,
        "occupations": profile.occupations,
        "smearing": profile.smearing,
        "degauss": profile.degauss
    };

    Object.keys(fields).forEach(function(key) {
        var el = document.getElementById(key) || document.querySelector("[name='" + key + "']");
        if (el) {
            el.value = fields[key];
            // Déclencher un événement change pour les frameworks réactifs
            var evt = document.createEvent("HTMLEvents");
            evt.initEvent("change", true, true);
            el.dispatchEvent(evt);
        }
    });

    // K-points
    if (profile.kpoints && profile.kpoints.length === 3) {
        var kpEl = document.getElementById("k_points") || document.querySelector("[name='k_points']");
        if (kpEl) {
            kpEl.value = profile.kpoints.join(" ");
        }
    }

    // forc_conv_thr
    if (profile.forc_conv_thr) {
        var fctEl = document.getElementById("forc_conv_thr") || document.querySelector("[name='forc_conv_thr']");
        if (fctEl) fctEl.value = profile.forc_conv_thr;
    }

    // Afficher la note
    var noteEl = document.getElementById("convergence_note") || document.querySelector(".convergence-note");
    if (noteEl && profile.note) {
        noteEl.textContent = "💡 " + profile.note;
        noteEl.style.display = "block";
    }

    // Mettre en évidence les paramètres modifiés
    Object.keys(fields).forEach(function(key) {
        var el = document.getElementById(key);
        if (el) {
            el.style.transition = "border-color 0.5s ease, background-color 0.5s ease";
            el.style.borderColor = "#10b981";
            el.style.backgroundColor = "#f0fdf4";
            setTimeout(function() {
                el.style.borderColor = "";
                el.style.backgroundColor = "";
            }, 2000);
        }
    });
}

/**
 * Crée un tableau HTML comparatif des profils pour un type de matériau.
 *
 * @param {string} materialClass - Classe du matériau
 * @returns {string} HTML du tableau
 */
function renderConvergenceTable(materialClass) {
    var calcTypes = ["scf", "relax", "vc-relax", "nscf", "bands", "md"];
    var calcNames = {
        "scf": "SCF", "relax": "Relax", "vc-relax": "VC-Relax",
        "nscf": "NSCF", "bands": "Bandes", "md": "MD"
    };

    var html = '<div style="overflow-x: auto; margin: 15px 0;">';
    html += '<table style="width: 100%; border-collapse: collapse; font-size: 0.85em;">';
    html += '<thead><tr style="background: linear-gradient(135deg, #4f46e5, #3730a3); color: white;">';
    html += '<th style="padding: 10px; text-align: left;">Paramètre</th>';
    calcTypes.forEach(function(ct) {
        html += '<th style="padding: 10px; text-align: center;">' + calcNames[ct] + '</th>';
    });
    html += '</tr></thead><tbody>';

    var params = [
        { key: "ecutwfc", label: "ecutwfc (Ry)" },
        { key: "ecutrho", label: "ecutrho (Ry)" },
        { key: "conv_thr", label: "conv_thr" },
        { key: "mixing_beta", label: "mixing_beta" },
        { key: "occupations", label: "occupations" },
        { key: "smearing", label: "smearing" },
        { key: "degauss", label: "degauss (Ry)" }
    ];

    params.forEach(function(p, idx) {
        var bg = idx % 2 === 0 ? "#f8fafc" : "#ffffff";
        html += '<tr style="background: ' + bg + ';">';
        html += '<td style="padding: 8px 10px; font-weight: 600; color: #1e293b; border-bottom: 1px solid #e2e8f0;">' + p.label + '</td>';
        calcTypes.forEach(function(ct) {
            var prof = getConvergenceProfile(materialClass, ct);
            var val = prof[p.key];
            if (Array.isArray(val)) val = val.join("×");
            html += '<td style="padding: 8px 10px; text-align: center; font-family: monospace; border-bottom: 1px solid #e2e8f0;">' + val + '</td>';
        });
        html += '</tr>';
    });

    html += '</tbody></table></div>';
    return html;
}

// Exporter pour Node.js (optionnel)
if (typeof module !== "undefined" && module.exports) {
    module.exports = {
        MATERIAL_CLASSES: MATERIAL_CLASSES,
        CONVERGENCE_PROFILES: CONVERGENCE_PROFILES,
        getConvergenceProfile: getConvergenceProfile,
        detectMaterialClass: detectMaterialClass,
        applyConvergenceProfile: applyConvergenceProfile,
        renderConvergenceTable: renderConvergenceTable
    };
}

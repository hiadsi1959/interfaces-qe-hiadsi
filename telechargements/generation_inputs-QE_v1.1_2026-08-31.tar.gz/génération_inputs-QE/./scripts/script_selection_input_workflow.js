// ═══════════════════════════════════════════════════════════════════════════
// SÉLECTION D'INPUT POUR WORKFLOW - Amélioration UX (v2 - Persistance)
// ═══════════════════════════════════════════════════════════════════════════

// Variable globale pour stocker l'input sélectionné
let inputWorkflowSelectionne = null;

// Clé localStorage pour la persistance
const STORAGE_KEY_INPUT = 'qe_workflow_input_selectionne';

/**
 * Sauvegarder la sélection dans localStorage
 */
function sauvegarderSelection(filepath, nom) {
    const selection = { filepath, nom, timestamp: Date.now() };
    localStorage.setItem(STORAGE_KEY_INPUT, JSON.stringify(selection));
    console.log(`💾 Sélection sauvegardée: ${nom}`);
}

/**
 * Récupérer la sélection depuis localStorage
 */
function recupererSelection() {
    try {
        const stored = localStorage.getItem(STORAGE_KEY_INPUT);
        if (stored) {
            const selection = JSON.parse(stored);
            // Vérifier que la sélection a moins de 24h
            if (Date.now() - selection.timestamp < 24 * 60 * 60 * 1000) {
                return selection;
            }
        }
    } catch (e) {
        console.warn('⚠️ Erreur lecture localStorage:', e);
    }
    return null;
}

/**
 * Effacer la sélection
 */
function effacerSelection() {
    localStorage.removeItem(STORAGE_KEY_INPUT);
    inputWorkflowSelectionne = null;
}

/**
 * Charger et afficher la liste des inputs disponibles
 */
async function chargerListeInputsWorkflow() {
    console.log('📂 Chargement des inputs pour workflow...');
    
    try {
        const response = await fetch('http://localhost:5007/api/lister_inputs');
        const data = await response.json();
        
        if (!data.success || !data.inputs || data.inputs.length === 0) {
            console.warn('⚠️ Aucun input trouvé');
            return;
        }
        
        // Créer une liste sélectionnable
        afficherListeInputsSelectable(data.inputs);
        
    } catch (error) {
        console.error('❌ Erreur chargement inputs:', error);
    }
}

/**
 * Afficher la liste des inputs avec boutons de sélection
 */
function afficherListeInputsSelectable(inputs) {
    // Trouver ou créer la zone d'affichage
    let zoneInputs = document.getElementById('zone_selection_inputs_workflow');
    
    if (!zoneInputs) {
        // Créer la zone si elle n'existe pas
        const etape1 = document.querySelector('[data-etape="selection-input"]');
        if (etape1) {
            zoneInputs = document.createElement('div');
            zoneInputs.id = 'zone_selection_inputs_workflow';
            zoneInputs.style.cssText = 'margin-top: 20px;';
            etape1.appendChild(zoneInputs);
        }
    }
    
    if (!zoneInputs) return;
    
    // Construire le HTML
    let html = `
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; border: 2px solid #e2e8f0;">
            <h5 style="margin: 0 0 15px 0; color: #1e293b; display: flex; align-items: center; gap: 10px;">
                <span style="font-size: 1.5em;">📁</span>
                <span>Inputs Disponibles</span>
            </h5>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px; max-height: 300px; overflow-y: auto;">
    `;
    
    inputs.forEach(input => {
        // ✅ L'API retourne 'nom', 'fichier', 'chemin' (pas 'prefix', 'filename', 'filepath')
        const nom = input.nom || input.prefix || (input.fichier ? input.fichier.replace('.in', '') : 'Sans nom');
        const type = input.type || 'scf';
        const filepath = input.chemin || `/home/hiadsi/génération_inputs-QE/inputs_générés_direct/${input.fichier || nom + '.in'}`;
        
        // Couleur selon le type
        const couleurs = {
            'vc-relax': '#10b981',
            'scf': '#3b82f6',
            'nscf': '#8b5cf6',
            'bands': '#f59e0b',
            'dos': '#ef4444'
        };
        const couleur = couleurs[type] || '#6b7280';
        
        html += `
            <button onclick="selectionnerInputPourWorkflow('${filepath}', '${nom}')" 
                    id="btn_input_${nom}"
                    style="
                        padding: 15px;
                        background: white;
                        border: 2px solid #e2e8f0;
                        border-radius: 8px;
                        cursor: pointer;
                        transition: all 0.3s;
                        text-align: left;
                    "
                    onmouseover="this.style.borderColor='${couleur}'; this.style.transform='scale(1.02)';"
                    onmouseout="this.style.borderColor='#e2e8f0'; this.style.transform='scale(1)';">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                    <span style="
                        background: ${couleur};
                        color: white;
                        padding: 4px 8px;
                        border-radius: 4px;
                        font-size: 0.75em;
                        font-weight: bold;
                    ">${type.toUpperCase()}</span>
                    <span style="font-weight: 600; color: #1e293b; flex: 1;">${nom}</span>
                </div>
                <div style="font-size: 0.75em; color: #64748b;">
                    ${filepath.split('/').slice(-2).join('/')}
                </div>
            </button>
        `;
    });
    
    html += `
            </div>
            
            <div id="input_workflow_selectionne_info" style="margin-top: 20px; padding: 15px; background: white; border-radius: 8px; border: 2px dashed #e2e8f0; display: none;">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span style="font-size: 1.5em;">✅</span>
                    <div style="flex: 1;">
                        <div style="font-weight: 600; color: #1e293b;">Input sélectionné:</div>
                        <div id="input_workflow_selectionne_nom" style="color: #3b82f6; font-family: monospace;"></div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    zoneInputs.innerHTML = html;
}

/**
 * Sélectionner un input pour le workflow
 */
function selectionnerInputPourWorkflow(filepath, nom) {
    console.log(`✅ Input sélectionné: ${nom}`);
    
    // Stocker la sélection en mémoire ET localStorage
    inputWorkflowSelectionne = { filepath, nom };
    sauvegarderSelection(filepath, nom);
    
    // Mettre à jour l'affichage
    const infoDiv = document.getElementById('input_workflow_selectionne_info');
    const nomDiv = document.getElementById('input_workflow_selectionne_nom');
    const nomField = document.getElementById('input_file_selected');
    
    if (infoDiv) {
        infoDiv.style.display = 'block';
        infoDiv.style.borderColor = '#10b981';
        infoDiv.style.background = '#f0fdf4';
    }
    
    if (nomDiv) {
        nomDiv.textContent = nom;
    }
    
    if (nomField) {
        nomField.textContent = nom;
    }
    
    // Activer le bouton de lancement
    const btn = document.getElementById('btn_lancer_workflow_elec');
    const status = document.getElementById('workflow_elec_status');
    
    if (btn) {
        btn.disabled = false;
        btn.style.opacity = '1';
        btn.style.cursor = 'pointer';
    }
    
    if (status) {
        status.textContent = `✅ Prêt à lancer - Input: ${nom}`;
        status.style.color = '#10b981';
        status.style.fontWeight = '600';
    }
    
    // Mettre en évidence le bouton sélectionné
    document.querySelectorAll('[id^="btn_input_"]').forEach(btn => {
        btn.style.borderColor = '#e2e8f0';
        btn.style.background = 'white';
    });
    
    const btnSelectionne = document.getElementById(`btn_input_${nom}`);
    if (btnSelectionne) {
        btnSelectionne.style.borderColor = '#10b981';
        btnSelectionne.style.background = '#f0fdf4';
        btnSelectionne.style.borderWidth = '3px';
    }
    
    // Scroll vers la zone de configuration
    const etape2 = document.querySelector('[data-etape="config-workflow"]');
    if (etape2) {
        setTimeout(() => {
            etape2.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 300);
    }
}

/**
 * Créer un bouton pour charger les inputs
 */
function creerBoutonChargerInputs() {
    // Créer un bouton élégant pour charger les inputs
    const btn = document.createElement('button');
    btn.textContent = '📁 Charger la Liste des Inputs';
    btn.onclick = chargerListeInputsWorkflow;
    btn.style.cssText = `
        padding: 12px 24px;
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
        color: white;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: 600;
        font-size: 1em;
        transition: transform 0.2s, box-shadow 0.2s;
        width: 100%;
    `;
    
    btn.onmouseover = () => {
        btn.style.transform = 'translateY(-2px)';
        btn.style.boxShadow = '0 4px 12px rgba(59, 130, 246, 0.4)';
    };
    
    btn.onmouseout = () => {
        btn.style.transform = 'translateY(0)';
        btn.style.boxShadow = 'none';
    };
    
    return btn;
}

// Charger automatiquement les inputs au chargement de la page
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        chargerListeInputsWorkflow();
        
        // Restaurer la sélection précédente après le chargement
        setTimeout(() => {
            restaurerSelectionPrecedente();
        }, 500);
    }, 1000);
});

/**
 * Restaurer la sélection précédente depuis localStorage
 */
function restaurerSelectionPrecedente() {
    const selection = recupererSelection();
    if (selection && selection.nom) {
        console.log(`🔄 Restauration de la sélection précédente: ${selection.nom}`);
        
        // Vérifier si l'input existe toujours
        const btnExiste = document.getElementById(`btn_input_${selection.nom}`);
        if (btnExiste) {
            // Simuler un clic pour sélectionner
            selectionnerInputPourWorkflow(selection.filepath, selection.nom);
            
            // Afficher un message discret
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: linear-gradient(135deg, #10b981 0%, #059669 100%);
                color: white;
                padding: 15px 25px;
                border-radius: 10px;
                box-shadow: 0 4px 20px rgba(16, 185, 129, 0.4);
                z-index: 9999;
                font-weight: 500;
                display: flex;
                align-items: center;
                gap: 10px;
                animation: slideIn 0.3s ease;
            `;
            notification.innerHTML = `
                <span style="font-size: 1.5em;">📌</span>
                <div>
                    <div style="font-weight: 600;">Matériau mémorisé</div>
                    <div style="font-size: 0.9em; opacity: 0.9;">${selection.nom}</div>
                </div>
            `;
            document.body.appendChild(notification);
            
            // Animation de disparition
            setTimeout(() => {
                notification.style.opacity = '0';
                notification.style.transform = 'translateX(100px)';
                notification.style.transition = 'all 0.3s';
                setTimeout(() => notification.remove(), 300);
            }, 3000);
        } else {
            console.warn(`⚠️ L'input ${selection.nom} n'est plus disponible`);
            effacerSelection();
        }
    }
}

console.log('✅ Script sélection input workflow chargé (v2 - Persistance)');


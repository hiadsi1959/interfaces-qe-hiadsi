// ═══════════════════════════════════════════════════════════════════════════
// UTILITAIRES DOM SÉCURISÉS - Éviter les erreurs getElementById null
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Récupérer un élément par ID de manière sécurisée
 * @param {string} id - L'ID de l'élément
 * @param {boolean} warnIfMissing - Afficher un warning si l'élément n'existe pas
 * @returns {HTMLElement|null}
 */
window.getElementByIdSafe = function(id, warnIfMissing = false) {
    const element = document.getElementById(id);
    if (!element && warnIfMissing) {
        console.warn(`⚠️ Élément introuvable: #${id}`);
    }
    return element;
};

/**
 * Récupérer la valeur d'un input/textarea/select de manière sécurisée
 * @param {string} id - L'ID de l'élément
 * @param {any} defaultValue - Valeur par défaut si l'élément n'existe pas
 * @returns {string|any}
 */
window.getValueSafe = function(id, defaultValue = '') {
    const element = document.getElementById(id);
    return element ? element.value : defaultValue;
};

/**
 * Définir la valeur d'un input/textarea/select de manière sécurisée
 * @param {string} id - L'ID de l'élément
 * @param {any} value - La valeur à définir
 * @returns {boolean} - true si réussi, false sinon
 */
window.setValueSafe = function(id, value) {
    const element = document.getElementById(id);
    if (element) {
        element.value = value;
        return true;
    }
    console.warn(`⚠️ Impossible de définir la valeur de #${id} (élément introuvable)`);
    return false;
};

/**
 * Définir le contenu HTML d'un élément de manière sécurisée
 * @param {string} id - L'ID de l'élément
 * @param {string} html - Le contenu HTML
 * @returns {boolean} - true si réussi, false sinon
 */
window.setHTMLSafe = function(id, html) {
    const element = document.getElementById(id);
    if (element) {
        element.innerHTML = html;
        return true;
    }
    console.warn(`⚠️ Impossible de définir le HTML de #${id} (élément introuvable)`);
    return false;
};

/**
 * Définir le contenu texte d'un élément de manière sécurisée
 * @param {string} id - L'ID de l'élément
 * @param {string} text - Le contenu texte
 * @returns {boolean} - true si réussi, false sinon
 */
window.setTextSafe = function(id, text) {
    const element = document.getElementById(id);
    if (element) {
        element.textContent = text;
        return true;
    }
    console.warn(`⚠️ Impossible de définir le texte de #${id} (élément introuvable)`);
    return false;
};

/**
 * Afficher/masquer un élément de manière sécurisée
 * @param {string} id - L'ID de l'élément
 * @param {boolean} visible - true pour afficher, false pour masquer
 * @returns {boolean} - true si réussi, false sinon
 */
window.setVisibleSafe = function(id, visible) {
    const element = document.getElementById(id);
    if (element) {
        element.style.display = visible ? '' : 'none';
        return true;
    }
    console.warn(`⚠️ Impossible de modifier la visibilité de #${id} (élément introuvable)`);
    return false;
};

/**
 * Activer/désactiver un élément de manière sécurisée
 * @param {string} id - L'ID de l'élément
 * @param {boolean} enabled - true pour activer, false pour désactiver
 * @returns {boolean} - true si réussi, false sinon
 */
window.setEnabledSafe = function(id, enabled) {
    const element = document.getElementById(id);
    if (element) {
        element.disabled = !enabled;
        return true;
    }
    console.warn(`⚠️ Impossible de modifier l'état de #${id} (élément introuvable)`);
    return false;
};

/**
 * Attendre qu'un élément existe dans le DOM
 * @param {string} id - L'ID de l'élément
 * @param {number} timeout - Timeout en ms (défaut: 5000)
 * @returns {Promise<HTMLElement>}
 */
window.waitForElement = function(id, timeout = 5000) {
    return new Promise((resolve, reject) => {
        const element = document.getElementById(id);
        if (element) {
            resolve(element);
            return;
        }
        
        const startTime = Date.now();
        const interval = setInterval(() => {
            const element = document.getElementById(id);
            if (element) {
                clearInterval(interval);
                resolve(element);
            } else if (Date.now() - startTime > timeout) {
                clearInterval(interval);
                reject(new Error(`Timeout: élément #${id} introuvable après ${timeout}ms`));
            }
        }, 100);
    });
};

/**
 * Exécuter une fonction uniquement si l'élément existe
 * @param {string} id - L'ID de l'élément
 * @param {Function} callback - Fonction à exécuter avec l'élément en paramètre
 * @returns {any} - Résultat de la callback ou undefined
 */
window.ifElementExists = function(id, callback) {
    const element = document.getElementById(id);
    if (element && typeof callback === 'function') {
        return callback(element);
    }
    return undefined;
};

/**
 * Exécuter une fonction de manière sécurisée avec gestion d'erreur
 * @param {Function} fn - Fonction à exécuter
 * @param {string} context - Contexte pour le message d'erreur
 */
window.safeTryCatch = function(fn, context = 'fonction') {
    try {
        return fn();
    } catch (error) {
        console.error(`❌ Erreur dans ${context}:`, error);
        return null;
    }
};

console.log('✅ Utilitaires DOM sécurisés chargés');









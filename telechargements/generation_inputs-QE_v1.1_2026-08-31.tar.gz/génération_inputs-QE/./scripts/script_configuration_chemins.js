// ═══════════════════════════════════════════════════════════════════════════
// CONFIGURATION DES CHEMINS - PORTABLE ENTRE PCs
// Ajouter au début du Tab 1 pour configurer inputs, outputs, pseudos
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Créer la section de configuration des chemins au début du Tab 1
 */
function creerSectionChemins() {
    console.log('📁 Création de la section chemins...');
    
    // Trouver le premier .card du Tab 1
    const firstCard = document.querySelector('.tab-content:first-of-type .card');
    if (!firstCard) {
        console.warn('⚠️ Pas de card trouvée');
        return;
    }
    
    // Créer la section chemins
    const cheminSection = document.createElement('div');
    cheminSection.id = 'section_chemins';
    cheminSection.style.cssText = `
        padding: 25px;
        background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%);
        border: 3px solid #9c27b0;
        border-radius: 10px;
        margin-bottom: 30px;
    `;
    
    cheminSection.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 20px;">
            <h2 style="color: #6a1b9a; margin: 0;">⚙️ Configuration des Chemins</h2>
            <button onclick="reinitialiserChemins()" style="
                padding: 8px 15px;
                background: #6a1b9a;
                color: white;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                font-weight: bold;
                font-size: 0.9em;
            ">🔄 Réinitialiser</button>
            <button onclick="exporterChemins()" style="
                padding: 8px 15px;
                background: #5e35b1;
                color: white;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                font-weight: bold;
                font-size: 0.9em;
            ">💾 Exporter Config</button>
        </div>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
            <!-- Répertoire des Inputs -->
            <div style="
                padding: 15px;
                background: white;
                border-left: 4px solid #ff6b6b;
                border-radius: 8px;
            ">
                <label style="
                    font-weight: bold;
                    color: #d32f2f;
                    display: block;
                    margin-bottom: 8px;
                ">📥 Répertoire des Inputs:</label>
                <input type="text" id="path_inputs" placeholder="/home/user/QE_inputs"
                       style="
                           width: 100%;
                           padding: 10px;
                           border: 2px solid #ff6b6b;
                           border-radius: 6px;
                           font-family: monospace;
                           font-size: 0.9em;
                       "
                       onchange="sauvegarderChemins()"
                       onblur="sauvegarderChemins()">
                <small style="color: #666; margin-top: 5px; display: block;">
                    Où les inputs QE seront sauvegardés
                </small>
            </div>
            
            <!-- Répertoire des Outputs -->
            <div style="
                padding: 15px;
                background: white;
                border-left: 4px solid #4caf50;
                border-radius: 8px;
            ">
                <label style="
                    font-weight: bold;
                    color: #2e7d32;
                    display: block;
                    margin-bottom: 8px;
                ">📤 Répertoire des Outputs:</label>
                <input type="text" id="path_outputs" placeholder="/home/user/QE_outputs"
                       style="
                           width: 100%;
                           padding: 10px;
                           border: 2px solid #4caf50;
                           border-radius: 6px;
                           font-family: monospace;
                           font-size: 0.9em;
                       "
                       onchange="sauvegarderChemins()"
                       onblur="sauvegarderChemins()">
                <small style="color: #666; margin-top: 5px; display: block;">
                    Où les résultats QE seront sauvegardés
                </small>
            </div>
            
            <!-- Répertoire des Pseudos -->
            <div style="
                padding: 15px;
                background: white;
                border-left: 4px solid #2196f3;
                border-radius: 8px;
            ">
                <label style="
                    font-weight: bold;
                    color: #0d47a1;
                    display: block;
                    margin-bottom: 8px;
                ">🧪 Répertoire des Pseudo-potentiels:</label>
                <input type="text" id="path_pseudos" placeholder="/home/user/pseudo"
                       style="
                           width: 100%;
                           padding: 10px;
                           border: 2px solid #2196f3;
                           border-radius: 6px;
                           font-family: monospace;
                           font-size: 0.9em;
                       "
                       onchange="sauvegarderChemins()"
                       onblur="sauvegarderChemins()">
                <small style="color: #666; margin-top: 5px; display: block;">
                    Où les fichiers .UPF sont stockés
                </small>
            </div>
        </div>
        
        <div style="
            margin-top: 20px;
            padding: 15px;
            background: #e8f5e9;
            border-radius: 8px;
            border-left: 4px solid #2e7d32;
            display: none;
            color: #2e7d32;
        " id="message_chemins">
            ✅ Chemins sauvegardés avec succès!
        </div>
    `;
    
    // Insérer au début du premier card
    firstCard.parentElement.insertBefore(cheminSection, firstCard);
    
    // Charger les chemins sauvegardés
    chargerChemins();
    
    console.log('✅ Section chemins créée');
}

/**
 * Charger les chemins depuis localStorage
 */
function chargerChemins() {
    const pathInputs = localStorage.getItem('qe_path_inputs');
    const pathOutputs = localStorage.getItem('qe_path_outputs');
    const pathPseudos = localStorage.getItem('qe_path_pseudos');
    
    // Valeurs par défaut depuis QE_CONFIG (config_chemins.js) sinon constantes correctes
    const cfg = window.QE_CONFIG || {};
    const defaultInputs  = cfg.INPUTS_DIRECT_DIR || cfg.INPUTS_GENERES_DIR || (typeof window.qeInputsDirectRoot === 'function' ? window.qeInputsDirectRoot() : '');
    const defaultOutputs = cfg.OUTPUTS_DIR        || ((typeof window.qeProjectRoot === 'function' && window.qeProjectRoot()) ? window.qeProjectRoot() + '/outputs' : '');
    const defaultPseudos = cfg.PSEUDO_DIR          || ((typeof window.qeProjectRoot === 'function' && window.qeProjectRoot()) ? window.qeProjectRoot() + '/pseudos/PBE' : '');
    
    // Remplir les champs
    const inputField = document.getElementById('path_inputs');
    const outputField = document.getElementById('path_outputs');
    const pseudoField = document.getElementById('path_pseudos');
    
    if (inputField) inputField.value = pathInputs || defaultInputs;
    if (outputField) outputField.value = pathOutputs || defaultOutputs;
    if (pseudoField) pseudoField.value = pathPseudos || defaultPseudos;
    
    console.log('✅ Chemins chargés');
    console.log('  Inputs:', pathInputs || defaultInputs);
    console.log('  Outputs:', pathOutputs || defaultOutputs);
    console.log('  Pseudos:', pathPseudos || defaultPseudos);
}

/**
 * Sauvegarder les chemins dans localStorage
 */
function sauvegarderChemins() {
    const pathInputs = document.getElementById('path_inputs').value;
    const pathOutputs = document.getElementById('path_outputs').value;
    const pathPseudos = document.getElementById('path_pseudos').value;
    
    localStorage.setItem('qe_path_inputs', pathInputs);
    localStorage.setItem('qe_path_outputs', pathOutputs);
    localStorage.setItem('qe_path_pseudos', pathPseudos);
    
    // Afficher le message de succès
    const message = document.getElementById('message_chemins');
    if (message) {
        message.style.display = 'block';
        setTimeout(() => {
            message.style.display = 'none';
        }, 3000);
    }
    
    console.log('✅ Chemins sauvegardés');
    console.log('  Inputs:', pathInputs);
    console.log('  Outputs:', pathOutputs);
    console.log('  Pseudos:', pathPseudos);
}

/**
 * Réinitialiser les chemins aux valeurs par défaut
 */
function reinitialiserChemins() {
    if (confirm('Voulez-vous réinitialiser les chemins aux valeurs par défaut?')) {
        localStorage.removeItem('qe_path_inputs');
        localStorage.removeItem('qe_path_outputs');
        localStorage.removeItem('qe_path_pseudos');
        
        chargerChemins();
        console.log('✅ Chemins réinitialisés');
    }
}

/**
 * Exporter la configuration des chemins
 */
function exporterChemins() {
    const pathInputs = document.getElementById('path_inputs').value;
    const pathOutputs = document.getElementById('path_outputs').value;
    const pathPseudos = document.getElementById('path_pseudos').value;
    
    const config = {
        version: '3.1',
        date: new Date().toISOString(),
        chemins: {
            inputs: pathInputs,
            outputs: pathOutputs,
            pseudos: pathPseudos
        }
    };
    
    const json = JSON.stringify(config, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `qe_chemins_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    
    console.log('✅ Configuration exportée');
}

/**
 * Importer une configuration de chemins
 */
function importerChemins(file) {
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const config = JSON.parse(e.target.result);
            if (config.chemins) {
                document.getElementById('path_inputs').value = config.chemins.inputs;
                document.getElementById('path_outputs').value = config.chemins.outputs;
                document.getElementById('path_pseudos').value = config.chemins.pseudos;
                sauvegarderChemins();
                alert('✅ Configuration importée avec succès!');
            }
        } catch (error) {
            alert('❌ Erreur lors de l\'import: ' + error.message);
        }
    };
    reader.readAsText(file);
}

/**
 * Obtenir le chemin des inputs
 */
function obtenirCheminInputs() {
    return document.getElementById('path_inputs').value || '~/QE_inputs';
}

/**
 * Obtenir le chemin des outputs
 */
function obtenirCheminOutputs() {
    return document.getElementById('path_outputs').value || '~/QE_outputs';
}

/**
 * Obtenir le chemin des pseudos
 */
function obtenirCheminPseudos() {
    return document.getElementById('path_pseudos').value || '~/pseudo';
}

/**
 * Initialiser au chargement
 */
function initialiserCheminAvantTab1() {
    console.log('🔧 Initialisation des chemins...');
    
    setTimeout(() => {
        creerSectionChemins();
        console.log('✅ Chemins initialisés');
    }, 200);
}

// Exécuter au chargement
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialiserCheminAvantTab1);
} else {
    initialiserCheminAvantTab1();
}

console.log('✅ Script configuration chemins chargé');








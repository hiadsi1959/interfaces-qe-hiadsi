// ═══════════════════════════════════════════════════════════════════════════
// SCRIPT AMÉLIORÉ POUR L'ONGLET RÉSULTATS - INTERFACE COMPLÈTE
// ═══════════════════════════════════════════════════════════════════════════

// Variables globales
window.materiauSelectionne = window.materiauSelectionne || 'BaFeO3';
window.materiaux = ['BaFeO3', 'BaTiO3', 'Si', 'GaN', 'PrAlO3'];

// ═══════════════════════════════════════════════════════════════════════════
// INITIALISATION DE L'ONGLET RÉSULTATS
// ═══════════════════════════════════════════════════════════════════════════

function initialiserOngletResultats() {
    console.log('🔧 Initialisation de l\'onglet résultats...');
    
    // Créer la structure HTML si elle n'existe pas
    const ongletResultats = document.querySelector('[id*="resultats"], [id*="Resultats"]');
    if (!ongletResultats) {
        console.warn('⚠️ Onglet résultats non trouvé');
        return;
    }
    
    // Créer le header amélioré
    creerHeaderResultats();
}

// ═══════════════════════════════════════════════════════════════════════════
// CRÉER LE HEADER AMÉLIORÉ
// ═══════════════════════════════════════════════════════════════════════════

function creerHeaderResultats() {
    // Chercher le conteneur principal
    let container = document.querySelector('[id*="resultats"], [id*="Resultats"]');
    
    if (!container) {
        console.warn('⚠️ Conteneur résultats non trouvé');
        return;
    }
    
    // Créer le header HTML
    const headerHTML = `
        <div id="header-resultats" style="
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
        ">
            <!-- TITRE PRINCIPAL -->
            <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 25px; border-bottom: 2px solid rgba(255,255,255,0.3); padding-bottom: 20px;">
                <span style="font-size: 2.5em;">📊</span>
                <div>
                    <h1 style="margin: 0; font-size: 2em; font-weight: bold;">Résultats et Analyse</h1>
                    <p style="margin: 5px 0 0 0; opacity: 0.9; font-size: 1em;">Interface complète pour l'analyse des calculs Quantum ESPRESSO</p>
                </div>
            </div>
            
            <!-- SECTION 1: SÉLECTION DU MATÉRIAU -->
            <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 12px; margin-bottom: 20px; border: 1px solid rgba(255,255,255,0.2);">
                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                    <span style="font-size: 1.5em;">🔬</span>
                    <h3 style="margin: 0; font-size: 1.2em; font-weight: bold;">Sélectionner le Matériau</h3>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px;">
                    ${window.materiaux.map(mat => `
                        <button onclick="changerMateriau('${mat}')" 
                                style="
                                    padding: 12px 20px;
                                    background: ${window.materiauSelectionne === mat ? '#10b981' : 'rgba(255,255,255,0.1)'};
                                    color: white;
                                    border: 2px solid ${window.materiauSelectionne === mat ? '#059669' : 'rgba(255,255,255,0.3)'};
                                    border-radius: 8px;
                                    cursor: pointer;
                                    font-weight: ${window.materiauSelectionne === mat ? 'bold' : 'normal'};
                                    font-size: 1em;
                                    transition: all 0.3s;
                                "
                                onmouseover="this.style.background='${window.materiauSelectionne === mat ? '#059669' : 'rgba(255,255,255,0.2)'}'"
                                onmouseout="this.style.background='${window.materiauSelectionne === mat ? '#10b981' : 'rgba(255,255,255,0.1)'}'"
                        >
                            ${mat}
                        </button>
                    `).join('')}
                </div>
                
                <div style="margin-top: 15px; padding: 12px; background: rgba(255,255,255,0.1); border-radius: 8px; border-left: 3px solid #fbbf24;">
                    <strong>Matériau actuel:</strong> <span id="materiau-actuel" style="font-weight: bold; font-size: 1.1em;">${window.materiauSelectionne}</span>
                </div>
            </div>
            
            <!-- SECTION 2: CHEMIN DES OUTPUTS -->
            <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 12px; margin-bottom: 20px; border: 1px solid rgba(255,255,255,0.2);">
                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                    <span style="font-size: 1.5em;">📂</span>
                    <h3 style="margin: 0; font-size: 1.2em; font-weight: bold;">Chemin des Outputs</h3>
                </div>
                
                <div style="background: rgba(0,0,0,0.2); padding: 15px; border-radius: 8px; font-family: monospace; font-size: 0.95em; word-break: break-all; border-left: 3px solid #60a5fa;">
                    <span id="chemin-materiau">/home/hiadsi/Interface-QE_v1/outputs/${window.materiauSelectionne}/</span>
                </div>
                
                <div style="margin-top: 15px; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px;">
                    <button onclick="verifierFichiers()" 
                            style="
                                padding: 12px 20px;
                                background: rgba(255,255,255,0.2);
                                color: white;
                                border: 1px solid rgba(255,255,255,0.3);
                                border-radius: 8px;
                                cursor: pointer;
                                font-weight: bold;
                                font-size: 1em;
                                transition: all 0.3s;
                            "
                            onmouseover="this.style.background='rgba(255,255,255,0.3)'"
                            onmouseout="this.style.background='rgba(255,255,255,0.2)'"
                    >
                        🔍 Vérifier Fichiers
                    </button>
                    
                    <button onclick="afficherPlotCombine()" 
                            style="
                                padding: 12px 20px;
                                background: rgba(255,255,255,0.2);
                                color: white;
                                border: 1px solid rgba(255,255,255,0.3);
                                border-radius: 8px;
                                cursor: pointer;
                                font-weight: bold;
                                font-size: 1em;
                                transition: all 0.3s;
                            "
                            onmouseover="this.style.background='rgba(255,255,255,0.3)'"
                            onmouseout="this.style.background='rgba(255,255,255,0.2)'"
                    >
                        📈 Afficher BANDS + DOS
                    </button>
                    
                    <button onclick="afficherAutresResultats()" 
                            style="
                                padding: 12px 20px;
                                background: rgba(255,255,255,0.2);
                                color: white;
                                border: 1px solid rgba(255,255,255,0.3);
                                border-radius: 8px;
                                cursor: pointer;
                                font-weight: bold;
                                font-size: 1em;
                                transition: all 0.3s;
                            "
                            onmouseover="this.style.background='rgba(255,255,255,0.3)'"
                            onmouseout="this.style.background='rgba(255,255,255,0.2)'"
                    >
                        📊 Autres Résultats
                    </button>
                </div>
            </div>
            
            <!-- SECTION 3: CHEMIN INTERACTIF -->
            <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.2);">
                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                    <span style="font-size: 1.5em;">🔗</span>
                    <h3 style="margin: 0; font-size: 1.2em; font-weight: bold;">Chemin Interactif des Outputs</h3>
                </div>
                
                <div style="background: rgba(0,0,0,0.2); padding: 15px; border-radius: 8px; font-family: monospace; font-size: 0.95em; word-break: break-all; border-left: 3px solid #60a5fa; margin-bottom: 15px;">
                    <span id="chemin-interactif">/home/hiadsi/Interface-QE_v1/outputs/${window.materiauSelectionne}/</span>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px;">
                    <button onclick="afficherFichierOutput('scf.out')" 
                            style="
                                padding: 12px 20px;
                                background: rgba(255,255,255,0.2);
                                color: white;
                                border: 1px solid rgba(255,255,255,0.3);
                                border-radius: 8px;
                                cursor: pointer;
                                font-weight: bold;
                                font-size: 0.95em;
                                transition: all 0.3s;
                            "
                            onmouseover="this.style.background='rgba(255,255,255,0.3)'"
                            onmouseout="this.style.background='rgba(255,255,255,0.2)'"
                    >
                        👁️ Voir scf.out
                    </button>
                    
                    <button onclick="afficherFichierOutput('nscf.out')" 
                            style="
                                padding: 12px 20px;
                                background: rgba(255,255,255,0.2);
                                color: white;
                                border: 1px solid rgba(255,255,255,0.3);
                                border-radius: 8px;
                                cursor: pointer;
                                font-weight: bold;
                                font-size: 0.95em;
                                transition: all 0.3s;
                            "
                            onmouseover="this.style.background='rgba(255,255,255,0.3)'"
                            onmouseout="this.style.background='rgba(255,255,255,0.2)'"
                    >
                        👁️ Voir nscf.out
                    </button>
                    
                    <button onclick="afficherFichierOutput('bands.out')" 
                            style="
                                padding: 12px 20px;
                                background: rgba(255,255,255,0.2);
                                color: white;
                                border: 1px solid rgba(255,255,255,0.3);
                                border-radius: 8px;
                                cursor: pointer;
                                font-weight: bold;
                                font-size: 0.95em;
                                transition: all 0.3s;
                            "
                            onmouseover="this.style.background='rgba(255,255,255,0.3)'"
                            onmouseout="this.style.background='rgba(255,255,255,0.2)'"
                    >
                        👁️ Voir bands.out
                    </button>
                    
                    <button onclick="afficherFichierOutput('dos.out')" 
                            style="
                                padding: 12px 20px;
                                background: rgba(255,255,255,0.2);
                                color: white;
                                border: 1px solid rgba(255,255,255,0.3);
                                border-radius: 8px;
                                cursor: pointer;
                                font-weight: bold;
                                font-size: 0.95em;
                                transition: all 0.3s;
                            "
                            onmouseover="this.style.background='rgba(255,255,255,0.3)'"
                            onmouseout="this.style.background='rgba(255,255,255,0.2)'"
                    >
                        👁️ Voir dos.out
                    </button>
                </div>
            </div>
        </div>
    `;
    
    // Insérer le header au début du conteneur
    const firstChild = container.firstChild;
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = headerHTML;
    container.insertBefore(tempDiv.firstChild, firstChild);
    
    console.log('✅ Header résultats créé');
}

// ═══════════════════════════════════════════════════════════════════════════
// FONCTIONS DE GESTION
// ═══════════════════════════════════════════════════════════════════════════

function changerMateriau(materiau) {
    window.materiauSelectionne = materiau;
    
    // Mettre à jour l'affichage
    const cheminElem = document.getElementById('chemin-materiau');
    if (cheminElem) {
        cheminElem.textContent = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}/`;
    }
    
    const materiauActuelElem = document.getElementById('materiau-actuel');
    if (materiauActuelElem) {
        materiauActuelElem.textContent = materiau;
    }
    
    // Mettre à jour les boutons
    const buttons = document.querySelectorAll('#header-resultats button');
    buttons.forEach(btn => {
        if (btn.textContent.includes(materiau)) {
            btn.style.background = 'rgba(255,255,255,0.3)';
            btn.style.borderColor = 'white';
            btn.style.fontWeight = 'bold';
        } else if (btn.textContent.includes('BaFeO3') || btn.textContent.includes('BaTiO3') || 
                   btn.textContent.includes('Si') || btn.textContent.includes('GaN') || 
                   btn.textContent.includes('PrAlO3')) {
            btn.style.background = 'rgba(255,255,255,0.1)';
            btn.style.borderColor = 'rgba(255,255,255,0.3)';
            btn.style.fontWeight = 'normal';
        }
    });
    
    console.log('✅ Matériau changé:', materiau);
    afficherNotification(`✅ Matériau sélectionné: ${materiau}`, 'success');
}

// ═══════════════════════════════════════════════════════════════════════════
// INITIALISER AU CHARGEMENT
// ═══════════════════════════════════════════════════════════════════════════

// Attendre que le DOM soit prêt
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialiserOngletResultats);
} else {
    initialiserOngletResultats();
}

console.log('✅ Script onglet résultats amélioré chargé');

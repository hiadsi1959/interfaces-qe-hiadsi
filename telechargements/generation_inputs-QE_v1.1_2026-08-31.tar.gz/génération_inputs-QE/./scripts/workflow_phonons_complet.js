// ═══════════════════════════════════════════════════════════════════════════
// WORKFLOW PHONONS COMPLET - Toutes les fonctionnalités
// Version corrigée et fonctionnelle
// ═══════════════════════════════════════════════════════════════════════════

// Variables globales
var materiauWorkflowComplet = null;
var calculEnCours = null;

// ═══════════════════════════════════════════════════════════════════════════
// 1. OUVRIR/FERMER LE WORKFLOW
// ════════════════════════════════════════════════════════════════════��══════

function ouvrirWorkflowCompletPhonons() {
    var zone = document.getElementById('zone_workflow_complet_phonons');
    if (zone) {
        zone.style.display = 'block';
        zone.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    console.log('✅ Workflow complet ouvert');
}

function fermerWorkflowComplet() {
    var zone = document.getElementById('zone_workflow_complet_phonons');
    if (zone) {
        zone.style.display = 'none';
    }
    console.log('❌ Workflow complet fermé');
}

// ═══════════════════════════════════════════════════════════════════════════
// 2. VALIDATION DU MATÉRIAU
// ═══════════════════════════════════════════════════════════════════════════

function validerMateriauComplet() {
    var input = document.getElementById('input_materiau_workflow');
    var materiau = input ? input.value.trim() : '';
    
    if (!materiau) {
        alert('⚠️ Veuillez entrer un nom de matériau');
        return;
    }
    
    // Stocker le matériau
    materiauWorkflowComplet = materiau;
    
    // Afficher la confirmation
    var infoDiv = document.getElementById('materiau_valide_info');
    var nomSpan = document.getElementById('materiau_valide_nom');
    if (infoDiv && nomSpan) {
        nomSpan.textContent = materiau;
        infoDiv.style.display = 'block';
    }
    
    console.log('✅ Matériau validé:', materiau);
    
    // Activer tous les boutons
    activerBoutonsWorkflow();
}

function activerBoutonsWorkflow() {
    var boutons = ['btn_vcrelax', 'btn_relax', 'btn_scf', 'btn_sauter_relax'];
    
    boutons.forEach(function(id) {
        var btn = document.getElementById(id);
        if (btn) {
            btn.disabled = false;
            btn.style.opacity = '1';
            btn.style.cursor = 'pointer';
        }
    });
    
    // Mettre à jour les statuts
    var types = ['vcrelax', 'relax', 'scf'];
    types.forEach(function(type) {
        var status = document.getElementById('status_' + type);
        if (status) {
            status.innerHTML = '✅ Prêt à lancer';
            status.style.background = '#d1fae5';
        }
    });
    
    console.log('✅ Tous les boutons activés');
}

// ═══════════════════════════════════════════════════════════════════════════
// 3. ÉDITION DES INPUTS
// ═══════════════════════════════════════════════════════════════════════════

function editerInputComplet(type) {
    if (!materiauWorkflowComplet) {
        alert('⚠️ Veuillez d\'abord valider un matériau');
        return;
    }
    
    console.log('📝 Édition input ' + type + ' pour ' + materiauWorkflowComplet);
    
    // Générer le template
    var template = genererTemplateInput(type, materiauWorkflowComplet);
    var recommandations = obtenirRecommandationsInput(type);
    
    // Créer et afficher le modal
    afficherModalEdition(type, template, recommandations);
}

function afficherModalEdition(type, template, recommandations) {
    // Supprimer un modal existant
    var existant = document.getElementById('modal_edition_workflow');
    if (existant) existant.remove();
    
    var modal = document.createElement('div');
    modal.id = 'modal_edition_workflow';
    modal.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.7);z-index:10000;display:flex;justify-content:center;align-items:center;padding:20px;';
    
    modal.innerHTML = '\
        <div style="background:white;border-radius:15px;max-width:900px;width:100%;max-height:90vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,0.3);">\
            <div style="padding:25px;border-bottom:2px solid #e5e7eb;display:flex;justify-content:space-between;align-items:center;background:linear-gradient(135deg,#10b981 0%,#059669 100%);color:white;border-radius:15px 15px 0 0;">\
                <h3 style="margin:0;font-size:1.3em;">✏️ Édition Input ' + type.toUpperCase() + ' - ' + materiauWorkflowComplet + '</h3>\
                <button onclick="fermerModalEdition()" style="background:white;color:#10b981;border:none;padding:8px 16px;border-radius:6px;cursor:pointer;font-weight:600;">\
                    ❌ Fermer\
                </button>\
            </div>\
            \
            <div style="padding:25px;">\
                <div style="background:#fef3c7;padding:15px;border-radius:8px;margin-bottom:20px;border-left:4px solid #f59e0b;">\
                    <h4 style="margin:0 0 10px 0;color:#92400e;">💡 Recommandations</h4>\
                    ' + recommandations + '\
                </div>\
                \
                <label style="display:block;margin-bottom:10px;font-weight:600;color:#374151;">\
                    Contenu de l\'input:\
                </label>\
                <textarea id="textarea_input_workflow" style="width:100%;min-height:400px;padding:15px;border:2px solid #e5e7eb;border-radius:8px;font-family:monospace;font-size:0.9em;background:#1e293b;color:#10b981;line-height:1.5;">' + template + '</textarea>\
                \
                <div style="display:flex;gap:15px;margin-top:20px;justify-content:center;flex-wrap:wrap;">\
                    <button onclick="sauvegarderInputWorkflow(\'' + type + '\')" style="padding:12px 24px;background:linear-gradient(135deg,#3b82f6,#2563eb);color:white;border:none;border-radius:8px;cursor:pointer;font-weight:600;font-size:1em;">\
                        💾 Sauvegarder\
                    </button>\
                    <button onclick="lancerCalculWorkflow(\'' + type + '\')" style="padding:12px 24px;background:linear-gradient(135deg,#10b981,#059669);color:white;border:none;border-radius:8px;cursor:pointer;font-weight:600;font-size:1em;">\
                        🚀 Lancer le Calcul\
                    </button>\
                    <button onclick="fermerModalEdition()" style="padding:12px 24px;background:#6b7280;color:white;border:none;border-radius:8px;cursor:pointer;font-weight:600;font-size:1em;">\
                        ❌ Annuler\
                    </button>\
                </div>\
            </div>\
        </div>\
    ';
    
    document.body.appendChild(modal);
}

function fermerModalEdition() {
    var modal = document.getElementById('modal_edition_workflow');
    if (modal) modal.remove();
}

// ═══════════════════════════════════════════════════════════════════════════
// 4. SAUVEGARDE ET LANCEMENT
// ═══════════════════════════════════════════════════════════════════════════

function sauvegarderInputWorkflow(type) {
    var textarea = document.getElementById('textarea_input_workflow');
    if (!textarea) return;
    
    var content = textarea.value;
    var filename = materiauWorkflowComplet + '_' + type + '.in';
    
    // Télécharger le fichier
    var blob = new Blob([content], { type: 'text/plain' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    alert('✅ Input sauvegardé: ' + filename);
    console.log('💾 Input ' + type + ' sauvegardé');
}

function lancerCalculWorkflow(type) {
    var textarea = document.getElementById('textarea_input_workflow');
    if (!textarea) return;
    
    var content = textarea.value;
    var filename = materiauWorkflowComplet + '_' + type + '.in';
    var outputFile = materiauWorkflowComplet + '_' + type + '.out';
    
    // Télécharger l'input
    var blob = new Blob([content], { type: 'text/plain' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    // Fermer le modal
    fermerModalEdition();
    
    // Mettre à jour le statut
    var status = document.getElementById('status_' + type);
    if (status) {
        status.innerHTML = '🔄 Calcul lancé - Fichier: ' + filename;
        status.style.background = '#dbeafe';
    }
    
    // Afficher la fenêtre de suivi
    afficherFenetreSuivi(type, filename, outputFile);
    
    calculEnCours = { type: type, filename: filename, outputFile: outputFile };
    console.log('🚀 Calcul ' + type + ' lancé');
}

function afficherFenetreSuivi(type, inputFile, outputFile) {
    // Supprimer une fenêtre existante
    var existante = document.getElementById('fenetre_suivi_workflow');
    if (existante) existante.remove();
    
    var commande = 'cd /home/hiadsi/Interface-QE_v1/outputs && mpirun -np 4 pw.x < ' + inputFile + ' > ' + outputFile + ' 2>&1';
    
    var fenetre = document.createElement('div');
    fenetre.id = 'fenetre_suivi_workflow';
    fenetre.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);width:90%;max-width:1000px;max-height:80vh;background:white;border-radius:15px;box-shadow:0 20px 60px rgba(0,0,0,0.3);z-index:10001;display:flex;flex-direction:column;';
    
    fenetre.innerHTML = '\
        <div style="padding:20px;border-bottom:2px solid #e5e7eb;background:linear-gradient(135deg,#3b82f6 0%,#2563eb 100%);color:white;border-radius:15px 15px 0 0;">\
            <div style="display:flex;justify-content:space-between;align-items:center;">\
                <h3 style="margin:0;">🔄 Suivi du calcul ' + type.toUpperCase() + ' - ' + materiauWorkflowComplet + '</h3>\
                <button onclick="fermerFenetreSuivi()" style="background:white;color:#3b82f6;border:none;padding:8px 16px;border-radius:6px;cursor:pointer;font-weight:600;">\
                    ❌ Fermer\
                </button>\
            </div>\
        </div>\
        \
        <div style="padding:20px;flex:1;overflow-y:auto;">\
            <div style="background:#f0fdf4;padding:15px;border-radius:8px;margin-bottom:15px;border-left:4px solid #10b981;">\
                <h4 style="margin:0 0 10px 0;color:#065f46;">📋 Informations</h4>\
                <div style="font-family:monospace;font-size:0.9em;color:#374151;">\
                    <div><strong>Fichier input:</strong> ' + inputFile + '</div>\
                    <div><strong>Fichier output:</strong> ' + outputFile + '</div>\
                    <div style="margin-top:10px;"><strong>Commande:</strong></div>\
                    <div style="background:#1e293b;color:#10b981;padding:10px;border-radius:4px;margin-top:5px;word-break:break-all;">\
                        ' + commande + '\
                    </div>\
                </div>\
            </div>\
            \
            <div style="background:#fef3c7;padding:15px;border-radius:8px;margin-bottom:15px;border-left:4px solid #f59e0b;">\
                <h4 style="margin:0 0 10px 0;color:#92400e;">💡 Instructions</h4>\
                <ol style="margin:0;padding-left:20px;color:#78350f;">\
                    <li>Copiez la commande ci-dessus</li>\
                    <li>Ouvrez un terminal</li>\
                    <li>Collez et exécutez la commande</li>\
                    <li>Attendez la fin du calcul (cherchez "JOB DONE")</li>\
                    <li>Revenez ici et cliquez sur "✅ Calcul terminé"</li>\
                </ol>\
            </div>\
            \
            <div style="text-align:center;margin-top:20px;">\
                <button onclick="marquerCalculTermine(\'' + type + '\')" style="padding:15px 30px;background:linear-gradient(135deg,#10b981,#059669);color:white;border:none;border-radius:8px;cursor:pointer;font-weight:600;font-size:1.1em;">\
                    ✅ Calcul Terminé\
                </button>\
            </div>\
        </div>\
    ';
    
    document.body.appendChild(fenetre);
}

function fermerFenetreSuivi() {
    var fenetre = document.getElementById('fenetre_suivi_workflow');
    if (fenetre) fenetre.remove();
}

function marquerCalculTermine(type) {
    console.log('✅ Calcul ' + type + ' marqué comme terminé');
    
    // Fermer la fenêtre de suivi
    fermerFenetreSuivi();
    
    // Mettre à jour le statut
    var status = document.getElementById('status_' + type);
    if (status) {
        status.innerHTML = '✅ Calcul terminé!<br><small style="color:#6b7280;">Fichier: ' + materiauWorkflowComplet + '_' + type + '.out</small>';
        status.style.background = '#d1fae5';
        status.style.borderLeft = '4px solid #10b981';
    }
    
    // Afficher le bouton "Continuer"
    afficherBoutonContinuer(type);
    
    calculEnCours = null;
}

function afficherBoutonContinuer(type) {
    var etapeSuivante = {
        'vcrelax': 'RELAX',
        'relax': 'SCF',
        'scf': 'PH.X'
    };
    
    var prochaine = etapeSuivante[type];
    if (!prochaine) return;
    
    var status = document.getElementById('status_' + type);
    if (status) {
        var btnContinuer = document.createElement('button');
        btnContinuer.innerHTML = '▶️ Continuer vers ' + prochaine;
        btnContinuer.style.cssText = 'margin-top:10px;padding:10px 20px;background:linear-gradient(135deg,#f59e0b,#d97706);color:white;border:none;border-radius:6px;cursor:pointer;font-weight:600;width:100%;';
        btnContinuer.onclick = function() { continuerVersEtapeSuivante(type); };
        status.appendChild(btnContinuer);
    }
}

function continuerVersEtapeSuivante(typeActuel) {
    console.log('▶️ Continuation depuis ' + typeActuel);
    
    if (typeActuel === 'scf') {
        alert('✅ Calculs préliminaires terminés!\n\nVous pouvez maintenant configurer et lancer les calculs de phonons (PH.X, Q2R, MATDYN, etc.)');
        fermerWorkflowComplet();
    } else {
        var prochaine = typeActuel === 'vcrelax' ? 'relax' : 'scf';
        alert('✅ ' + typeActuel.toUpperCase() + ' terminé!\n\nVous pouvez maintenant lancer ' + prochaine.toUpperCase());
        
        var nextDiv = document.getElementById('status_' + prochaine);
        if (nextDiv) {
            nextDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// 5. SAUTER UNE ÉTAPE
// ═══════════════════════════════════════════════════════════════════════════

function sauterEtapeComplet(type) {
    console.log('⏭️ Étape ' + type + ' sautée');
    
    var status = document.getElementById('status_' + type);
    if (status) {
        status.innerHTML = '⏭️ Étape sautée';
        status.style.background = '#fef3c7';
        status.style.borderLeft = '4px solid #f59e0b';
    }
    
    // Afficher le bouton continuer
    afficherBoutonContinuer(type);
}

// ═══════════���═══════════════════════════════════════════════════════════════
// 6. TEMPLATES D'INPUT
// ═══════════════════════════════════════════════════════════════════════════

function genererTemplateInput(type, materiau) {
    var templates = {
        vcrelax: '&CONTROL\n\
    calculation = \'vc-relax\'\n\
    prefix = \'' + materiau + '\'\n\
    outdir = \'./tmp/\'\n\
    pseudo_dir = \'/home/hiadsi/Interface-QE_v1/pseudos/PBE/\'\n\
    etot_conv_thr = 1.0D-5\n\
    forc_conv_thr = 1.0D-4\n\
/\n\
\n\
&SYSTEM\n\
    ibrav = 4\n\
    celldm(1) = 6.028\n\
    celldm(3) = 1.626\n\
    nat = 2\n\
    ntyp = 2\n\
    ecutwfc = 50.0\n\
    ecutrho = 400.0\n\
/\n\
\n\
&ELECTRONS\n\
    conv_thr = 1.0D-8\n\
    mixing_beta = 0.3\n\
/\n\
\n\
&IONS\n\
    ion_dynamics = \'bfgs\'\n\
/\n\
\n\
&CELL\n\
    cell_dynamics = \'bfgs\'\n\
    press = 0.0\n\
/\n\
\n\
ATOMIC_SPECIES\n\
 Ga  69.723  Ga.pbe-dn-kjpaw_psl.1.0.0.UPF\n\
 N   14.007  N.pbe-n-kjpaw_psl.1.0.0.UPF\n\
\n\
ATOMIC_POSITIONS crystal\n\
 Ga  0.333  0.667  0.000\n\
 N   0.333  0.667  0.377\n\
\n\
K_POINTS automatic\n\
 8 8 8  0 0 0',
        relax: '&CONTROL\n\
    calculation = \'relax\'\n\
    prefix = \'' + materiau + '\'\n\
    outdir = \'./tmp/\'\n\
    pseudo_dir = \'/home/hiadsi/Interface-QE_v1/pseudos/PBE/\'\n\
/\n\
\n\
&SYSTEM\n\
    ibrav = 4\n\
    celldm(1) = 6.028\n\
    celldm(3) = 1.626\n\
    nat = 2\n\
    ntyp = 2\n\
    ecutwfc = 50.0\n\
    ecutrho = 400.0\n\
/\n\
\n\
&ELECTRONS\n\
    conv_thr = 1.0D-8\n\
    mixing_beta = 0.3\n\
/\n\
\n\
&IONS\n\
    ion_dynamics = \'bfgs\'\n\
/\n\
\n\
ATOMIC_SPECIES\n\
 Ga  69.723  Ga.pbe-dn-kjpaw_psl.1.0.0.UPF\n\
 N   14.007  N.pbe-n-kjpaw_psl.1.0.0.UPF\n\
\n\
ATOMIC_POSITIONS crystal\n\
 Ga  0.333  0.667  0.000\n\
 N   0.333  0.667  0.377\n\
\n\
K_POINTS automatic\n\
 8 8 8  0 0 0',
        scf: '&CONTROL\n\
    calculation = \'scf\'\n\
    prefix = \'' + materiau + '\'\n\
    outdir = \'./tmp/\'\n\
    pseudo_dir = \'/home/hiadsi/Interface-QE_v1/pseudos/PBE/\'\n\
/\n\
\n\
&SYSTEM\n\
    ibrav = 4\n\
    celldm(1) = 6.028\n\
    celldm(3) = 1.626\n\
    nat = 2\n\
    ntyp = 2\n\
    ecutwfc = 50.0\n\
    ecutrho = 400.0\n\
/\n\
\n\
&ELECTRONS\n\
    conv_thr = 1.0D-10\n\
    mixing_beta = 0.7\n\
/\n\
\n\
ATOMIC_SPECIES\n\
 Ga  69.723  Ga.pbe-dn-kjpaw_psl.1.0.0.UPF\n\
 N   14.007  N.pbe-n-kjpaw_psl.1.0.0.UPF\n\
\n\
ATOMIC_POSITIONS crystal\n\
 Ga  0.333  0.667  0.000\n\
 N   0.333  0.667  0.377\n\
\n\
K_POINTS automatic\n\
 12 12 12  0 0 0'
    };
    
    return templates[type] || '';
}

function obtenirRecommandationsInput(type) {
    var recommandations = {
        vcrelax: '\
            <ul style="margin:0;padding-left:20px;color:#78350f;">\
                <li><strong>ecutwfc:</strong> 50-80 Ry (semi-conducteurs)</li>\
                <li><strong>K_POINTS:</strong> 8×8×8 minimum</li>\
                <li><strong>forc_conv_thr:</strong> 1.0D-4 (forces)</li>\
                <li><strong>press_conv_thr:</strong> 0.5 (pression)</li>\
            </ul>\
        ',
        relax: '\
            <ul style="margin:0;padding-left:20px;color:#78350f;">\
                <li><strong>Utiliser</strong> la structure de VC-RELAX</li>\
                <li><strong>CELL_PARAMETERS:</strong> fixe (ne pas relaxer)</li>\
                <li><strong>Même ecutwfc</strong> que VC-RELAX</li>\
            </ul>\
        ',
        scf: '\
            <ul style="margin:0;padding-left:20px;color:#78350f;">\
                <li><strong>Utiliser</strong> la structure de RELAX</li>\
                <li><strong>K_POINTS:</strong> 12×12×12 (grille dense)</li>\
                <li><strong>conv_thr:</strong> 1.0D-10 (très convergé)</li>\
            </ul>\
        '
    };
    
    return recommandations[type] || '';
}

// ═══════════════════════════════════════════════════════════════════════════
// 7. CONTINUER VERS PHONONS
// ═══════════════════════════════════════════════════════════════════════════

function continuerVersPhonons() {
    alert('✅ Calculs préliminaires terminés!\n\nVous pouvez maintenant utiliser la section "Sélectionner le Calcul SCF de Base" ci-dessous pour lancer les calculs de phonons.');
    fermerWorkflowComplet();
    
    // Scroll vers la section phonons
    var sectionPhonons = document.querySelector('[id*="scf_phonons"]');
    if (sectionPhonons) {
        sectionPhonons.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// INITIALISATION
// ═══════════════════════════════════════════════════════════════════════════

console.log('✅ Workflow phonons complet chargé - Version corrigée');

/**
 * Catalogue des types d'inputs Quantum ESPRESSO (QE 7.5+)
 * Affiche les packages supportés et permet la vérification conformité.
 */
(function () {
    'use strict';

    var STATUS_LABEL = {
        full: '✅ Complet',
        full_ui: '✅ UI dédiée',
        template: '📋 Template',
        planned: '🔜 Prévu',
        stub: '⚠️ Ébauche'
    };

    function apiBase() {
        if (typeof window.getGenInputsApiBase === 'function') return window.getGenInputsApiBase();
        return 'http://127.0.0.1:5012';
    }

    function esc(s) {
        return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function renderCatalogPanel(data) {
        var host = document.getElementById('qe_types_catalog_panel');
        if (!host || !data) return;

        var pkgs = data.packages || [];
        var pwTypes = data.pw_calculation_types || {};
        var sum = data.summary || {};

        var rows = pkgs.map(function (p) {
            var st = STATUS_LABEL[p.status] || esc(p.status);
            var calc = (p.calculation_types || []).join(', ');
            var extra = calc ? ' · pw: ' + esc(calc) : '';
            return '<tr>'
                + '<td><code>' + esc(p.executable || p.id) + '</code></td>'
                + '<td>' + esc(p.description || '') + extra + '</td>'
                + '<td>' + st + '</td>'
                + '</tr>';
        }).join('');

        var pwRows = Object.keys(pwTypes).map(function (k) {
            var t = pwTypes[k] || {};
            return '<li><strong>' + esc(k) + '</strong> — ' + esc(t.label || k)
                + ' · namelists: ' + esc((t.namelists || []).join(', '))
                + (t.requires_pw ? ' · après ' + esc(t.requires_pw) : '')
                + '</li>';
        }).join('');

        host.innerHTML = ''
            + '<div class="qe-types-catalog">'
            + '<p style="margin:0 0 10px;font-size:0.88em;color:#475569;">'
            + 'Référence QE <strong>' + esc(sum.qe_version_min || '7.5') + '+</strong> — '
            + pkgs.length + ' packages catalogués · vérification automatique à la génération/sauvegarde.</p>'
            + '<details open><summary><strong>Types pw.x</strong> (génération directe / CIF)</summary>'
            + '<ul class="qe-types-pw-list" style="margin:10px 0 0 18px;font-size:0.86em;line-height:1.55;">' + pwRows + '</ul></details>'
            + '<details style="margin-top:12px;"><summary><strong>Tous les packages QE</strong></summary>'
            + '<table class="qe-types-table" style="width:100%;margin-top:10px;font-size:0.82em;border-collapse:collapse;">'
            + '<thead><tr style="background:#e2e8f0;"><th style="text-align:left;padding:6px;">Exécutable</th>'
            + '<th style="text-align:left;padding:6px;">Description</th><th style="text-align:left;padding:6px;">Statut</th></tr></thead>'
            + '<tbody>' + rows + '</tbody></table></details>'
            + '<p style="margin:12px 0 0;font-size:0.8em;color:#64748b;">'
            + 'Templates post-pw disponibles via API <code>POST /api/qe/build_aux</code> '
            + '(dos, ph, bands_pp, projwfc, pp, neb, …).</p>'
            + '</div>';
    }

    window.qeLoadInputTypesCatalog = async function qeLoadInputTypesCatalog() {
        try {
            var r = await fetch(apiBase() + '/api/qe/catalog');
            var data = await r.json();
            if (data && data.ok) {
                window.__qeInputTypesCatalog = data;
                renderCatalogPanel(data);
            }
        } catch (e) {
            console.warn('Catalogue QE:', e);
        }
    };

    window.qeVerifyInputText = async function qeVerifyInputText(text, opts) {
        opts = opts || {};
        var content = text
            || (document.getElementById('preview_input') || {}).value
            || window.currentInputContent
            || '';
        if (!String(content).trim()) {
            if (typeof window.tab1ShowStatus === 'function') {
                window.tab1ShowStatus('warn', '⚠️ Aucun input à vérifier.');
            }
            return null;
        }
        try {
            var r = await fetch(apiBase() + '/api/qe/verify', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    text: content,
                    package: opts.package || 'pw',
                    strict: !!opts.strict
                })
            });
            var data = await r.json();
            if (typeof window.tab1ShowStatus === 'function') {
                if (data.ok) {
                    var warn = (data.warnings || []).length
                        ? '<br><small>' + esc((data.warnings || []).join(' · ')) + '</small>' : '';
                    window.tab1ShowStatus('ok',
                        '✅ Conforme QE 7.5+ (' + esc(data.calculation || 'pw') + ')' + warn,
                        { scroll: true });
                } else {
                    window.tab1ShowStatus('error',
                        '❌ Non conforme QE 7.5+ : ' + esc((data.errors || []).join(' · ')),
                        { scroll: true });
                }
            }
            return data;
        } catch (e) {
            console.warn('Vérification QE:', e);
            return null;
        }
    };

    document.addEventListener('tab1Restructured', function () {
        setTimeout(window.qeLoadInputTypesCatalog, 600);
    });
    window.addEventListener('load', function () {
        setTimeout(window.qeLoadInputTypesCatalog, 1500);
    });

    console.log('✅ Catalogue types inputs QE chargé');
})();

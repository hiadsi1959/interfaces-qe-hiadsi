// ═══════════════════════════════════════════════════════════════════════════════
// DONNÉES COMPLÈTES DES ÉLÉMENTS - Propriétés physiques, chimiques, électroniques
// ═══════════════════════════════════════════════════════════════════════════════

const PROPRIETES_ELEMENTS = {
    'H': {
        // Propriétés électroniques
        configuration: '1s¹',
        electrons_valence: 1,
        couches: [1],
        orbitales_valence: ['1s'],
        
        // Propriétés physiques
        point_fusion: -259.14, // °C
        point_ebullition: -252.87,
        densite: 0.00008988, // g/cm³
        rayon_atomique: 53, // pm
        rayon_covalent: 31,
        rayon_ionique: null,
        
        // Propriétés chimiques
        electronegativite: 2.20, // Pauling
        energie_ionisation: 1312.0, // kJ/mol
        affinite_electronique: 72.8,
        etats_oxydation: [-1, 1],
        
        // Propriétés mécaniques (si applicable)
        module_young: null,
        module_cisaillement: null,
        coefficient_poisson: null,
        durete_mohs: null,
        
        // Autres
        abondance_terrestre: 1400, // ppm
        radioactif: false,
        periode: 1,
        groupe: 1,
        bloc: 's',
        categorie: 'Non-métal'
    },
    
    'Si': {
        configuration: '[Ne] 3s² 3p²',
        electrons_valence: 4,
        couches: [2, 8, 4],
        orbitales_valence: ['3s', '3p'],
        
        point_fusion: 1414,
        point_ebullition: 3265,
        densite: 2.3296,
        rayon_atomique: 111,
        rayon_covalent: 111,
        rayon_ionique: 40, // Si⁴⁺
        
        electronegativite: 1.90,
        energie_ionisation: 786.5,
        affinite_electronique: 133.6,
        etats_oxydation: [-4, -3, -2, -1, 1, 2, 3, 4],
        
        module_young: 130, // GPa
        module_cisaillement: 52,
        coefficient_poisson: 0.22,
        durete_mohs: 6.5,
        
        abondance_terrestre: 282000,
        radioactif: false,
        periode: 3,
        groupe: 14,
        bloc: 'p',
        categorie: 'Métalloïde'
    },
    
    'Mo': {
        configuration: '[Kr] 4d⁵ 5s¹',
        electrons_valence: 6,
        couches: [2, 8, 18, 13, 1],
        orbitales_valence: ['4d', '5s'],
        
        point_fusion: 2623,
        point_ebullition: 4639,
        densite: 10.28,
        rayon_atomique: 139,
        rayon_covalent: 154,
        rayon_ionique: 69, // Mo⁴⁺
        
        electronegativite: 2.16,
        energie_ionisation: 684.3,
        affinite_electronique: 71.9,
        etats_oxydation: [-2, -1, 0, 1, 2, 3, 4, 5, 6],
        
        module_young: 329,
        module_cisaillement: 126,
        coefficient_poisson: 0.31,
        durete_mohs: 5.5,
        
        abondance_terrestre: 1.2,
        radioactif: false,
        periode: 5,
        groupe: 6,
        bloc: 'd',
        categorie: 'Métal de transition'
    },
    
    'Ti': {
        configuration: '[Ar] 3d² 4s²',
        electrons_valence: 4,
        couches: [2, 8, 10, 2],
        orbitales_valence: ['3d', '4s'],
        
        point_fusion: 1668,
        point_ebullition: 3287,
        densite: 4.506,
        rayon_atomique: 147,
        rayon_covalent: 160,
        rayon_ionique: 86, // Ti⁴⁺
        
        electronegativite: 1.54,
        energie_ionisation: 658.8,
        affinite_electronique: 7.6,
        etats_oxydation: [-1, 0, 1, 2, 3, 4],
        
        module_young: 116,
        module_cisaillement: 44,
        coefficient_poisson: 0.32,
        durete_mohs: 6.0,
        
        abondance_terrestre: 5650,
        radioactif: false,
        periode: 4,
        groupe: 4,
        bloc: 'd',
        categorie: 'Métal de transition'
    }
    
    // Ajouter d'autres éléments selon les besoins...
};

// ═══════════════════════════════════════════════════════════════════════════════
// FONCTION POUR AFFICHER TOUTES LES PROPRIÉTÉS D'UN ÉLÉMENT
// ═══════════════════════════════════════════════════════════════════════════════

function afficherProprietesCompletes(symbole, element) {
    const props = PROPRIETES_ELEMENTS[symbole] || {};
    
    return `
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 20px;">
            
            <!-- Propriétés Électroniques -->
            <div class="card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                <h4 style="margin-top: 0; color: white;">⚛️ Propriétés Électroniques</h4>
                <div style="background: rgba(255,255,255,0.1); padding: 15px; border-radius: 8px;">
                    <strong>Configuration:</strong> ${props.configuration || 'N/A'}<br>
                    <strong>Électrons de valence:</strong> ${props.electrons_valence || element.valence}<br>
                    <strong>Couches électroniques:</strong> ${props.couches ? props.couches.join(', ') : 'N/A'}<br>
                    <strong>Orbitales de valence:</strong> ${props.orbitales_valence ? props.orbitales_valence.join(', ') : 'N/A'}<br>
                    <strong>Bloc:</strong> ${props.bloc || 'N/A'}<br>
                    <strong>Période:</strong> ${props.periode || 'N/A'}<br>
                    <strong>Groupe:</strong> ${props.groupe || 'N/A'}
                </div>
            </div>
            
            <!-- Propriétés Physiques -->
            <div class="card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white;">
                <h4 style="margin-top: 0; color: white;">🌡️ Propriétés Physiques</h4>
                <div style="background: rgba(255,255,255,0.1); padding: 15px; border-radius: 8px;">
                    <strong>Point de fusion:</strong> ${props.point_fusion !== null ? props.point_fusion + ' °C' : 'N/A'}<br>
                    <strong>Point d'ébullition:</strong> ${props.point_ebullition !== null ? props.point_ebullition + ' °C' : 'N/A'}<br>
                    <strong>Densité:</strong> ${props.densite !== null ? props.densite + ' g/cm³' : 'N/A'}<br>
                    <strong>Rayon atomique:</strong> ${props.rayon_atomique !== null ? props.rayon_atomique + ' pm' : 'N/A'}<br>
                    <strong>Rayon covalent:</strong> ${props.rayon_covalent !== null ? props.rayon_covalent + ' pm' : 'N/A'}<br>
                    <strong>Rayon ionique:</strong> ${props.rayon_ionique !== null ? props.rayon_ionique + ' pm' : 'N/A'}
                </div>
            </div>
            
            <!-- Propriétés Chimiques -->
            <div class="card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white;">
                <h4 style="margin-top: 0; color: white;">🧪 Propriétés Chimiques</h4>
                <div style="background: rgba(255,255,255,0.1); padding: 15px; border-radius: 8px;">
                    <strong>Électronégativité:</strong> ${props.electronegativite !== null ? props.electronegativite + ' (Pauling)' : 'N/A'}<br>
                    <strong>Énergie d'ionisation:</strong> ${props.energie_ionisation !== null ? props.energie_ionisation + ' kJ/mol' : 'N/A'}<br>
                    <strong>Affinité électronique:</strong> ${props.affinite_electronique !== null ? props.affinite_electronique + ' kJ/mol' : 'N/A'}<br>
                    <strong>États d'oxydation:</strong> ${props.etats_oxydation ? props.etats_oxydation.join(', ') : 'N/A'}<br>
                    <strong>Catégorie:</strong> ${props.categorie || 'N/A'}
                </div>
            </div>
            
            <!-- Propriétés Mécaniques -->
            ${props.module_young !== null ? `
            <div class="card" style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); color: white;">
                <h4 style="margin-top: 0; color: white;">🔧 Propriétés Mécaniques</h4>
                <div style="background: rgba(255,255,255,0.1); padding: 15px; border-radius: 8px;">
                    <strong>Module de Young:</strong> ${props.module_young} GPa<br>
                    <strong>Module de cisaillement:</strong> ${props.module_cisaillement !== null ? props.module_cisaillement + ' GPa' : 'N/A'}<br>
                    <strong>Coefficient de Poisson:</strong> ${props.coefficient_poisson !== null ? props.coefficient_poisson : 'N/A'}<br>
                    <strong>Dureté (Mohs):</strong> ${props.durete_mohs !== null ? props.durete_mohs : 'N/A'}
                </div>
            </div>
            ` : ''}
            
            <!-- Autres Propriétés -->
            <div class="card" style="background: linear-gradient(135deg, #30cfd0 0%, #330867 100%); color: white;">
                <h4 style="margin-top: 0; color: white;">📊 Autres Propriétés</h4>
                <div style="background: rgba(255,255,255,0.1); padding: 15px; border-radius: 8px;">
                    <strong>Numéro atomique:</strong> ${element.numero}<br>
                    <strong>Masse atomique:</strong> ${element.masse} u<br>
                    <strong>Abondance terrestre:</strong> ${props.abondance_terrestre !== null ? props.abondance_terrestre + ' ppm' : 'N/A'}<br>
                    <strong>Radioactif:</strong> ${props.radioactif ? '☢️ Oui' : '✅ Non'}<br>
                    <strong>Symbole:</strong> ${symbole}<br>
                    <strong>Nom:</strong> ${element.nom}
                </div>
            </div>
            
        </div>
    `;
}

// ═══════════════════════════════════════════════════════════════════════════════
// OPTIONS COMPLÈTES POUR LD1.X
// ═══════════════════════════════════════════════════════════════════════════════

const OPTIONS_LD1X = {
    pseudotype: {
        label: 'Type de pseudopotentiel',
        options: [
            { value: '1', label: 'NC (Norm-Conserving)', description: 'Conserve la norme, très robuste' },
            { value: '2', label: 'USPP (Ultrasoft)', description: 'Plus doux, ecutwfc plus faible' },
            { value: '3', label: 'PAW (Projector Augmented Wave)', description: 'Très précis, reconstruction all-electron' }
        ],
        default: '2'
    },
    
    relativistic: {
        label: 'Effets relativistes',
        options: [
            { value: '0', label: 'Non-relativiste', description: 'Pour éléments légers (Z < 20)' },
            { value: '1', label: 'Relativiste scalaire', description: 'Recommandé pour Z > 20' },
            { value: '2', label: 'Relativiste complet', description: 'Avec couplage spin-orbite' }
        ],
        default: '1'
    },
    
    functional: {
        label: 'Fonctionnelle XC',
        options: [
            { value: 'PZ', label: 'PZ (Perdew-Zunger LDA)', description: 'LDA standard' },
            { value: 'PBE', label: 'PBE (Perdew-Burke-Ernzerhof)', description: 'GGA standard' },
            { value: 'PBEsol', label: 'PBEsol', description: 'GGA pour solides' },
            { value: 'BLYP', label: 'BLYP', description: 'GGA alternative' }
        ],
        default: 'PBE'
    },
    
    nlcc: {
        label: 'NLCC (Non-Linear Core Correction)',
        options: [
            { value: 'false', label: 'Désactivé', description: 'Pas de correction de cœur' },
            { value: 'true', label: 'Activé', description: 'Recommandé pour métaux de transition' }
        ],
        default: 'true'
    },
    
    rcloc: {
        label: 'Rayon de coupure local (rcloc)',
        description: 'Rayon pour le potentiel local (Bohr)',
        default: '2.0',
        min: '0.5',
        max: '5.0',
        step: '0.1'
    },
    
    rcut: {
        label: 'Rayons de coupure par canal',
        description: 'Rayons pour chaque canal (s, p, d, f) en Bohr',
        canaux: ['s', 'p', 'd', 'f'],
        default: {
            's': '2.0',
            'p': '2.2',
            'd': '2.4',
            'f': '2.6'
        }
    },
    
    local_channel: {
        label: 'Canal local',
        options: [
            { value: '0', label: 's', description: 'Canal s comme local' },
            { value: '1', label: 'p', description: 'Canal p comme local' },
            { value: '2', label: 'd', description: 'Canal d comme local' },
            { value: '-1', label: 'Auto', description: 'Sélection automatique' }
        ],
        default: '-1'
    },
    
    ecutwfc_test: {
        label: 'Test de convergence ecutwfc',
        description: 'Tester différentes valeurs d\'ecutwfc',
        values: [20, 30, 40, 50, 60, 80, 100, 120],
        default: [40, 60, 80]
    },
    
    test_ghost: {
        label: 'Test des états fantômes',
        description: 'Vérifier l\'absence d\'états fantômes',
        default: true
    },
    
    test_transferability: {
        label: 'Test de transférabilité',
        description: 'Tester dans différentes configurations',
        default: true
    }
};

console.log('✅ Données complètes des éléments chargées');
console.log('✅ Options ld1.x chargées');

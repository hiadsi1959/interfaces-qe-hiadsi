// ═══════════════════════════════════════════════════════════════════════════
// SCRIPT POUR L'ONGLET RÉSULTATS - BANDS.X ET DOS.X
// ═══════════════════════════════════════════════════════════════════════════

// Variable globale pour le matériau sélectionné
window.materiauSelectionne = window.materiauSelectionne || 'BaFeO3';

// Changer le matériau
function changerMateriau(materiau) {
    window.materiauSelectionne = materiau;
    
    // Mettre à jour le chemin affiché
    const cheminElem = document.getElementById('chemin-materiau');
    if (cheminElem) {
        cheminElem.textContent = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}/`;
    }
    
    console.log('Matériau changé:', materiau);
    afficherNotification(`✅ Matériau sélectionné: ${materiau}`, 'success');
}

// ═════════════════════════════════════════════════════════════════════���═════
// FONCTIONS PRINCIPALES
// ═══════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════
// LANCER BANDS.X (séparé) - Chaîne complète : bands.x → plotband.x
// ═══════════════════════════════════════════════════════════════════════════

async function lancerBandsX() {
    const materiau = window.materiauSelectionne;
    const modal = creerModalProgression('🎵 Préparation de BANDS.X...');
    
    try {
        const inputPath = `/home/hiadsi/génération_inputs-QE/inputs_générés_direct/prefix/${materiau}/bands.in`;
        const outputDir = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}`;
        
        // Chaîne simplifiée (bands.dat suffit pour le plot)
        const commandes = `# Exécuter bands.x pour extraire les bandes
cd ${outputDir}
bands.x < ${inputPath} > bands.out

echo ""
echo "✅ BANDS.X terminé !"
echo "   Fichier généré: bands.dat"
echo ""
echo "📊 Le fichier bands.dat est prêt pour la visualisation"
echo "   Cliquez sur 'Afficher BANDS + DOS' pour voir le plot"`;
        
        modal.remove();
        afficherModalCommandeAvecExecution(
            '🎵 Lancer BANDS.X + PLOTBAND.X',
            commandes,
            `Cette chaîne va :
1. Exécuter bands.x pour extraire les bandes depuis le calcul NSCF
2. Créer un input pour plotband.x
3. Générer les fichiers de visualisation (bands.xmg, bands.ps)

Tous les fichiers seront dans ${outputDir}/`
        );
        
    } catch (e) {
        modal.remove();
        afficherNotification(`❌ Erreur: ${e.message}`, 'error');
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// LANCER DOS.X (séparé) - Chaîne complète : dos.x → plotdos.x (optionnel)
// ═══════════════════════════════════════════════════════════════════════════

async function lancerDosX() {
    const materiau = window.materiauSelectionne;
    const modal = creerModalProgression('📊 Préparation de DOS.X...');
    
    try {
        const inputPath = `/home/hiadsi/génération_inputs-QE/inputs_générés_direct/prefix/${materiau}/dos.in`;
        const outputDir = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}`;
        
        // Chaîne complète de commandes
        const commandes = `# Étape 1: Exécuter dos.x pour calculer la densité d'états
cd ${outputDir}
dos.x < ${inputPath} > dos.out

echo "✅ DOS.X terminé ! Fichier généré:"
echo "   - dos.dat (densité d'états totale et projetée)"

# Note: dos.dat est directement utilisable pour le plot
# Pas besoin de plotdos.x (dos.dat est déjà au bon format)`;
        
        modal.remove();
        afficherModalCommandeAvecExecution(
            '📊 Lancer DOS.X',
            commandes,
            `Cette commande va :
1. Exécuter dos.x pour calculer la densité d'états depuis le calcul NSCF
2. Générer dos.dat (format : Énergie | DOS | PDOS)

Le fichier dos.dat sera dans ${outputDir}/`
        );
        
    } catch (e) {
        modal.remove();
        afficherNotification(`❌ Erreur: ${e.message}`, 'error');
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// AFFICHER PLOT COMBINÉ (BANDS + DOS)
// ═══════════════════════════════════════════════════════════════════════════

async // Afficher autres résultats
function afficherAutresResultats() {
    const materiau = window.materiauSelectionne;
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.9);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        overflow-y: auto;
    `;
    
    modal.innerHTML = `
        <div style="background: white; border-radius: 15px; max-width: 1000px; width: 100%; padding: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 2px solid #8b5cf6; padding-bottom: 15px;">
                <h2 style="margin: 0; color: #8b5cf6;">📊 Autres Résultats - ${materiau}</h2>
                <button onclick="this.parentElement.parentElement.parentElement.remove()" style="background: none; border: none; font-size: 2em; cursor: pointer; color: #666;">×</button>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                <button onclick="afficherFichierOutput('scf.out')" class="btn" style="padding: 15px; background: #9c27b0; color: white; border: none; border-radius: 8px; cursor: pointer;">
                    📄 scf.out
                </button>
                <button onclick="afficherFichierOutput('nscf.out')" class="btn" style="padding: 15px; background: #9c27b0; color: white; border: none; border-radius: 8px; cursor: pointer;">
                    📄 nscf.out
                </button>
                <button onclick="afficherFichierOutput('bands.out')" class="btn" style="padding: 15px; background: #9c27b0; color: white; border: none; border-radius: 8px; cursor: pointer;">
                    📄 bands.out
                </button>
                <button onclick="afficherFichierOutput('dos.out')" class="btn" style="padding: 15px; background: #9c27b0; color: white; border: none; border-radius: 8px; cursor: pointer;">
                    📄 dos.out
                </button>
                <button onclick="extraireEnergieFermi()" class="btn" style="padding: 15px; background: #4caf50; color: white; border: none; border-radius: 8px; cursor: pointer;">
                    ⚡ Énergie de Fermi
                </button>
                <button onclick="extraireEnergieTotale()" class="btn" style="padding: 15px; background: #4caf50; color: white; border: none; border-radius: 8px; cursor: pointer;">
                    📊 Énergie Totale
                </button>
                <button onclick="listerTousFichiers()" class="btn" style="padding: 15px; background: #ff9800; color: white; border: none; border-radius: 8px; cursor: pointer;">
                    📂 Tous les Fichiers
                </button>
            </div>
            
            <div style="display: flex; gap: 15px; margin-top: 20px; justify-content: center;">
                <button onclick="this.parentElement.parentElement.parentElement.remove()" class="btn" style="padding: 12px 30px; background: #6b7280; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">
                    ❌ Fermer
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

function afficherPlotCombine() {
    const materiau = window.materiauSelectionne;
    const modal = creerModalProgression('📈 Chargement des données BANDS + DOS...');

    try {
        // Utiliser l'utilitaire de lecture de fichiers
        if (typeof window.chargerDonneesBandsEtDos !== 'function') {
            modal.remove();
            afficherNotification("❌ Utilitaire de lecture non disponible. Rechargez la page.", 'error');
            return;
        }

        console.log(`🔍 Diagnostic: Recherche des fichiers pour ${materiau}`);
        
        // Diagnostic: vérifier les fichiers
        const bandsDatPath = `/outputs/${materiau}/bands.dat`;
        const dosDatPath = `/outputs/${materiau}/dos.dat`;
        
        console.log(`📂 Chemin bands.dat: ${bandsDatPath}`);
        console.log(`📂 Chemin dos.dat: ${dosDatPath}`);
        
        const bandsDatExists = await window.fichierExiste(bandsDatPath);
        const dosDatExists = await window.fichierExiste(dosDatPath);
        
        console.log(`✅ bands.dat existe: ${bandsDatExists}`);
        console.log(`✅ dos.dat existe: ${dosDatExists}`);

        const { bands: bandsContent, dos: dosContent } = await window.chargerDonneesBandsEtDos(materiau);

        modal.remove();

        if (!bandsContent || !dosContent) {
            // Afficher un diagnostic détaillé
            const diagnostic = `
⚠️ Fichiers non trouvés pour ${materiau}

📂 Chemins recherchés:
  • ${bandsDatPath} (trouvé: ${bandsDatExists})
  • ${dosDatPath} (trouvé: ${dosDatExists})

💡 Solutions:
1. Vérifiez que les fichiers existent dans /outputs/${materiau}/
2. Lancez BANDS.X et DOS.X depuis l'onglet Résultats
3. Vérifiez le chemin exact du dossier du matériau

🔧 Diagnostic console: Ouvrez la console (F12) pour voir les détails
            `;
            afficherNotification(diagnostic, 'warning');
            return;
        }

        afficherModalPlotCombine(bandsContent, dosContent, materiau);
    } catch (e) {
        modal.remove();
        afficherNotification(`❌ Erreur: ${e.message}`, 'error');
    }
}

function afficherModalPlotCombine(bandsContent, dosContent, materiau) {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.9);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        overflow-y: auto;
    `;
    
    modal.innerHTML = `
        <div style="background: white; border-radius: 15px; max-width: 1600px; width: 100%; padding: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 2px solid #10b981; padding-bottom: 15px;">
                <h2 style="margin: 0; color: #10b981;">📈 Structure de Bandes + Densité d'États - ${materiau}</h2>
                <button onclick="this.parentElement.parentElement.parentElement.remove()" style="background: none; border: none; font-size: 2em; cursor: pointer; color: #666;">×</button>
            </div>
            
            <!-- Informations Gap -->
            <div id="info_gap" style="padding: 15px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-radius: 10px; margin-bottom: 20px; font-size: 1.1em; text-align: center; font-weight: bold;">
                ⏳ Calcul du gap en cours...
            </div>
            
            <!-- Contrôles -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px; padding: 15px; background: #f9fafb; border-radius: 10px;">
                <div>
                    <label style="display: block; margin-bottom: 5px; font-weight: bold; color: #4f46e5;">Énergie Min (eV)</label>
                    <input type="number" id="emin_input" value="-10" step="0.5" style="width: 100%; padding: 8px; border: 2px solid #e5e7eb; border-radius: 6px;">
                </div>
                <div>
                    <label style="display: block; margin-bottom: 5px; font-weight: bold; color: #4f46e5;">Énergie Max (eV)</label>
                    <input type="number" id="emax_input" value="10" step="0.5" style="width: 100%; padding: 8px; border: 2px solid #e5e7eb; border-radius: 6px;">
                </div>
                <div style="display: flex; align-items: flex-end;">
                    <button onclick="window.updatePlotRanges()" style="width: 100%; padding: 10px; background: #10b981; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: bold;">
                        🔄 Actualiser
                    </button>
                </div>
                <div style="display: flex; align-items: flex-end;">
                    <button onclick="window.resetPlotRanges()" style="width: 100%; padding: 10px; background: #6b7280; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: bold;">
                        ↺ Réinitialiser
                    </button>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <!-- Bandes -->
                <div>
                    <h3 style="color: #4f46e5; margin: 0 0 15px 0;">🎵 Structure de Bandes</h3>
                    <div id="plot_bands" style="width: 100%; height: 500px; border: 1px solid #e5e7eb; border-radius: 8px;"></div>
                    <div style="margin-top: 10px; padding: 10px; background: #f9fafb; border-radius: 8px;">
                        <strong>Fichier:</strong> bands.dat<br>
                        <strong>Lignes:</strong> ${bandsContent.split('\n').length}
                    </div>
                </div>
                
                <!-- DOS Total -->
                <div>
                    <h3 style="color: #ec4899; margin: 0 0 15px 0;">📊 Densité d'États (Total)</h3>
                    <div id="plot_dos" style="width: 100%; height: 500px; border: 1px solid #e5e7eb; border-radius: 8px;"></div>
                    <div style="margin-top: 10px; padding: 10px; background: #f9fafb; border-radius: 8px;">
                        <strong>Fichier:</strong> dos.dat<br>
                        <strong>Lignes:</strong> ${dosContent.split('\n').length}
                    </div>
                </div>
            </div>
            
            <!-- DOS Projetée (PDOS) -->
            <div style="margin-top: 25px;">
                <h3 style="color: #8b5cf6; margin: 0 0 15px 0;">🔬 Densité d'États Projetée (PDOS)</h3>
                <div id="plot_pdos" style="width: 100%; height: 600px; border: 1px solid #e5e7eb; border-radius: 8px;"></div>
                <div id="info_pdos" style="margin-top: 10px;"></div>
            </div>
            
            <div style="display: flex; gap: 15px; margin-top: 20px; justify-content: center; flex-wrap: wrap;">
                <button onclick="telechargerDonnees()" class="btn" style="padding: 12px 30px; background: #3b82f6; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">
                    📥 Télécharger CSV
                </button>
                <button onclick="exporterTableau()" class="btn" style="padding: 12px 30px; background: #f59e0b; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">
                    📄 Exporter HTML
                </button>
                <button onclick="window.afficherAnalyseComplete()" class="btn" style="padding: 12px 30px; background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">
                    📊 Analyse Complète
                </button>
                <button onclick="window.exporterImage()" class="btn" style="padding: 12px 30px; background: #8b5cf6; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">
                    🖼️ Exporter PNG
                </button>
                <button onclick="this.parentElement.parentElement.parentElement.remove()" class="btn" style="padding: 12px 30px; background: #6b7280; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">
                    ❌ Fermer
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Parser et tracer les données
    setTimeout(() => {
        try {
            // Parser bands.dat
            const bandsData = parserBandsDat(bandsContent);
            // Parser dos.dat
            const dosData = parserDosDat(dosContent);
            
            // Stocker les données globalement pour les contrôles
            window.currentBandsData = bandsData;
            window.currentDosData = dosData;
            
            // Calculer le gap
            const gapInfo = calculerGap(bandsData, dosData);
            afficherInfoGap(gapInfo);
            
            // Tracer les bandes
            if (bandsData && bandsData.length > 0) {
                tracerBandes(bandsData, 'plot_bands', gapInfo.fermi);
            } else {
                document.getElementById('plot_bands').innerHTML = '<div style="display: flex; align-items: center; justify-content: center; height: 100%; color: #ef4444;">❌ Erreur de parsing bands.dat</div>';
            }
            
            // Tracer le DOS
            if (dosData && dosData.energy && dosData.dos) {
                tracerDOS(dosData, 'plot_dos', gapInfo.fermi);
            } else {
                document.getElementById('plot_dos').innerHTML = '<div style="display: flex; align-items: center; justify-content: center; height: 100%; color: #ef4444;">❌ Erreur de parsing dos.dat</div>';
            }
            
            // Charger et afficher le PDOS
            chargerEtAfficherPDOS(materiau, 'plot_pdos', gapInfo.fermi, -10, 10).then(success => {
                if (!success) {
                    document.getElementById('plot_pdos').innerHTML = '<div style="display: flex; align-items: center; justify-content: center; height: 100%; color: #f59e0b; background: #fef3c7; border-radius: 8px; padding: 20px;">⚠️ Fichiers PDOS non trouvés. Lancez projwfc.x pour générer la DOS projetée.</div>';
                    document.getElementById('info_pdos').innerHTML = '<div style="padding: 15px; background: #fef3c7; border-radius: 8px; color: #92400e;"><strong>💡 Pour générer le PDOS:</strong><br>1. Lancez projwfc.x après le calcul NSCF<br>2. Les fichiers .pdos_atm seront créés dans /outputs/</div>';
                }
            });
        } catch (e) {
            console.error('Erreur parsing:', e);
            document.getElementById('plot_bands').innerHTML = `<div style="display: flex; align-items: center; justify-content: center; height: 100%; color: #ef4444;">❌ Erreur: ${e.message}</div>`;
        }
    }, 100);
}

// Calculer le gap d'énergie
function calculerGap(bandsData, dosData) {
    let fermi = 0;
    
    // Extraire l'énergie de Fermi depuis dos.dat (première ligne commentaire)
    if (dosData && dosData.fermi !== undefined) {
        fermi = dosData.fermi;
    }
    
    // Trouver HOMO (plus haute énergie occupée) et LUMO (plus basse énergie vide)
    let homo = -Infinity;
    let lumo = Infinity;
    
    for (const band of bandsData) {
        for (const energy of band) {
            if (energy <= fermi && energy > homo) {
                homo = energy;
            }
            if (energy > fermi && energy < lumo) {
                lumo = energy;
            }
        }
    }
    
    const gap = lumo - homo;
    const type = gap > 0.1 ? 'Semi-conducteur' : (gap > 0.01 ? 'Semi-métal' : 'Métal');
    
    return { fermi, homo, lumo, gap, type };
}

// Afficher les informations sur le gap
function afficherInfoGap(gapInfo) {
    const infoDiv = document.getElementById('info_gap');
    if (!infoDiv) return;
    
    const { fermi, homo, lumo, gap, type } = gapInfo;
    
    let bgColor = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
    if (type === 'Métal') {
        bgColor = 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)';
    } else if (type === 'Semi-conducteur') {
        bgColor = 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)';
    }
    
    infoDiv.style.background = bgColor;
    infoDiv.innerHTML = `
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 20px;">
            <div>
                <div style="font-size: 0.9em; opacity: 0.9;">Type</div>
                <div style="font-size: 1.3em;">${type}</div>
            </div>
            <div>
                <div style="font-size: 0.9em; opacity: 0.9;">Gap</div>
                <div style="font-size: 1.3em;">${gap.toFixed(3)} eV</div>
            </div>
            <div>
                <div style="font-size: 0.9em; opacity: 0.9;">E<sub>Fermi</sub></div>
                <div style="font-size: 1.3em;">${fermi.toFixed(3)} eV</div>
            </div>
            <div>
                <div style="font-size: 0.9em; opacity: 0.9;">HOMO</div>
                <div style="font-size: 1.3em;">${homo.toFixed(3)} eV</div>
            </div>
            <div>
                <div style="font-size: 0.9em; opacity: 0.9;">LUMO</div>
                <div style="font-size: 1.3em;">${lumo.toFixed(3)} eV</div>
            </div>
        </div>
    `;
}

// Fonctions de contrôle des graphiques
window.updatePlotRanges = function() {
    const emin = parseFloat(document.getElementById('emin_input').value);
    const emax = parseFloat(document.getElementById('emax_input').value);
    
    if (window.currentBandsData && window.currentDosData) {
        const gapInfo = calculerGap(window.currentBandsData, window.currentDosData);
        tracerBandes(window.currentBandsData, 'plot_bands', gapInfo.fermi, emin, emax);
        tracerDOS(window.currentDosData, 'plot_dos', gapInfo.fermi, emin, emax);
        afficherNotification('✅ Graphiques actualisés', 'success');
    }
};

window.resetPlotRanges = function() {
    document.getElementById('emin_input').value = '-10';
    document.getElementById('emax_input').value = '10';
    window.updatePlotRanges();
};

window.exporterImage = function() {
    Plotly.downloadImage('plot_bands', {
        format: 'png',
        width: 1200,
        height: 600,
        filename: `bands_${window.materiauSelectionne}`
    });
    afficherNotification('📸 Image des bandes exportée', 'success');
};

// Parser bands.dat (format QE)
function parserBandsDat(content) {
    const lines = content.trim().split('\n');
    const bands = [];
    
    // Première ligne: &plot nbnd=XX, nks=YY
    const headerMatch = lines[0].match(/nbnd=\s*(\d+),\s*nks=\s*(\d+)/);
    if (!headerMatch) {
        console.error('Format bands.dat invalide');
        return null;
    }
    
    const nbnd = parseInt(headerMatch[1]);
    const nks = parseInt(headerMatch[2]);
    
    let currentBand = [];
    let bandIndex = 0;
    
    for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        
        // Ligne avec coordonnées k (3 nombres)
        const kMatch = line.match(/^\s*([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)\s*$/);
        if (kMatch) {
            if (currentBand.length > 0) {
                bands.push([...currentBand]);
                currentBand = [];
            }
            continue;
        }
        
        // Ligne avec énergies (plusieurs nombres)
        const energies = line.split(/\s+/).filter(x => x).map(parseFloat);
        currentBand.push(...energies);
    }
    
    if (currentBand.length > 0) {
        bands.push(currentBand);
    }
    
    // Réorganiser: bands[k-point][band] -> traces[band][k-point]
    const traces = [];
    for (let b = 0; b < nbnd; b++) {
        const trace = [];
        for (let k = 0; k < nks; k++) {
            if (bands[k] && bands[k][b] !== undefined) {
                trace.push(bands[k][b]);
            }
        }
        if (trace.length > 0) {
            traces.push(trace);
        }
    }
    
    return traces;
}

// Parser dos.dat (format QE)
function parserDosDat(content) {
    const lines = content.trim().split('\n');
    const energy = [];
    const dos = [];
    let fermi = 0;
    
    for (const line of lines) {
        // Extraire l'énergie de Fermi depuis la première ligne commentaire
        if (line.trim().startsWith('#') && line.includes('Fermi')) {
            const match = line.match(/([-\d.]+)/);
            if (match) fermi = parseFloat(match[1]);
            continue;
        }
        if (line.trim().startsWith('#')) continue;
        
        const parts = line.trim().split(/\s+/).filter(x => x);
        if (parts.length >= 2) {
            energy.push(parseFloat(parts[0]));
            dos.push(parseFloat(parts[1]));
        }
    }
    
    return { energy, dos, fermi };
}

// Charger et afficher le PDOS
async function chargerEtAfficherPDOS(materiau, divId, fermi, emin, emax) {
    try {
        // Chercher les fichiers PDOS
        const pdosFiles = {};
        
        for (let i = 1; i <= 20; i++) {
            const filename = `/outputs/${materiau}/pwscf.pdos_atm#${i}(s)`;
            const content = await window.lireFichierLocal(filename);
            if (content) {
                pdosFiles[`atom_${i}`] = content;
            }
        }
        
        if (Object.keys(pdosFiles).length === 0) {
            return false; // Pas de fichiers PDOS trouvés
        }
        
        // Parser et tracer les PDOS
        const traces = [];
        for (const [atomLabel, content] of Object.entries(pdosFiles)) {
            const lines = content.trim().split('\n');
            const energy = [];
            const pdos = [];
            
            for (const line of lines) {
                if (line.trim().startsWith('#')) continue;
                const parts = line.trim().split(/\s+/).filter(x => x);
                if (parts.length >= 2) {
                    energy.push(parseFloat(parts[0]));
                    pdos.push(parseFloat(parts[1]));
                }
            }
            
            if (energy.length > 0) {
                traces.push({
                    x: pdos,
                    y: energy,
                    type: 'scatter',
                    mode: 'lines',
                    fill: 'tozerox',
                    name: atomLabel,
                    hovertemplate: `${atomLabel}<br>PDOS: %{x:.3f}<br>Énergie: %{y:.3f} eV<extra></extra>`
                });
            }
        }
        
        if (traces.length === 0) {
            return false;
        }
        
        // Tracer avec Plotly
        const layout = {
            title: 'Densité d\'États Projetée (PDOS)',
            xaxis: { title: 'PDOS (états/eV)', showgrid: true },
            yaxis: { title: 'Énergie (eV)', showgrid: true, zeroline: true },
            hovermode: 'closest',
            margin: { l: 60, r: 30, t: 50, b: 50 },
            legend: { x: 1.05, y: 1 }
        };
        
        Plotly.newPlot(divId, traces, layout, {responsive: true});
        return true;
    } catch (e) {
        console.warn('Erreur chargement PDOS:', e);
        return false;
    }
}

// Tracer les bandes avec Plotly
function tracerBandes(bandsData, divId) {
    const traces = bandsData.map((band, i) => ({
        y: band,
        x: Array.from({length: band.length}, (_, i) => i),
        type: 'scatter',
        mode: 'lines',
        line: { width: 1, color: '#4f46e5' },
        showlegend: false,
        hovertemplate: 'k-point: %{x}<br>Énergie: %{y:.3f} eV<extra></extra>'
    }));
    
    const layout = {
        title: 'Structure de Bandes',
        xaxis: { title: 'k-point', showgrid: true },
        yaxis: { title: 'Énergie (eV)', showgrid: true, zeroline: true },
        hovermode: 'closest',
        margin: { l: 60, r: 30, t: 50, b: 50 }
    };
    
    Plotly.newPlot(divId, traces, layout, {responsive: true});
}

// Tracer le DOS avec Plotly
function tracerDOS(dosData, divId) {
    const trace = {
        x: dosData.dos,
        y: dosData.energy,
        type: 'scatter',
        mode: 'lines',
        fill: 'tozerox',
        line: { color: '#ec4899', width: 2 },
        name: 'DOS',
        hovertemplate: 'DOS: %{x:.3f}<br>Énergie: %{y:.3f} eV<extra></extra>'
    };
    
    const layout = {
        title: 'Densité d\'États',
        xaxis: { title: 'DOS (états/eV)', showgrid: true },
        yaxis: { title: 'Énergie (eV)', showgrid: true, zeroline: true },
        hovermode: 'closest',
        margin: { l: 60, r: 30, t: 50, b: 50 }
    };
    
    Plotly.newPlot(divId, [trace], layout, {responsive: true});
}

async function chargerEtAnalyserDonnees() {
    const materiau = window.materiauSelectionne;
    const modal = creerModalProgression('Analyse des données (mode sans API)...');

    try {
        // Mode sans API: afficher une analyse simulée basée sur la présence des fichiers locaux
        modal.remove();
        afficherModalAnalyseSimulee(materiau);
    } catch (e) {
        modal.remove();
        afficherModalAnalyseSimulee(materiau);
    }
}

function afficherModalAnalyseSimulee(materiau) {
    const donneesSimulees = {
        success: true,
        materiau: materiau,
        resume: {
            'Gap d\'énergie': 'Calcul requis',
            'DOS au Fermi': 'Calcul requis',
            'Largeur de bande': 'Calcul requis'
        },
        tableau: [
            { clef: 'Matériau', valeur: materiau },
            { clef: 'Statut', valeur: 'Données non disponibles' },
            { clef: 'Action requise', valeur: 'Lancer BANDS.X et DOS.X d\'abord' }
        ],
        plots: {
            message: 'Lancez d\'abord les calculs BANDS.X et DOS.X'
        }
    };
    afficherModalAnalyse(donneesSimulees);
}

async function telechargerDonnees() {
    const materiau = window.materiauSelectionne;
    const modal = creerModalProgression('Préparation du CSV (mode sans API)...');

    try {
        modal.remove();
        const csvSimule = `Matériau,${materiau}\nStatut,Mode sans API\nMessage,Données exportées localement\n`;
        declencherTelechargement(`${materiau}_analyse.csv`, csvSimule);
        afficherNotification('📥 CSV généré (mode sans API)', 'success');
    } catch (e) {
        modal.remove();
        afficherNotification(`⚠️ Export CSV (local) échoué: ${e.message}`, 'warning');
    }
}

async function exporterTableau() {
    const materiau = window.materiauSelectionne;
    const modal = creerModalProgression('Préparation du HTML (mode sans API)...');

    try {
        modal.remove();
        const htmlSimule = `<!DOCTYPE html>\n<html><head><meta charset="UTF-8"><title>Analyse ${materiau}</title></head>\n<body><h1>Analyse ${materiau}</h1><p>Mode sans API: export local.</p></body></html>`;
        declencherTelechargement(`${materiau}_analyse.html`, htmlSimule);
        afficherNotification('📄 HTML généré (mode sans API)', 'success');
    } catch (e) {
        modal.remove();
        afficherNotification(`⚠️ Export HTML (local) échoué: ${e.message}`, 'warning');
    }
}

function ouvrirEditeurInput() {
    const materiau = window.materiauSelectionne;
    afficherNotification("✏️ Mode sans API: ouvrez le fichier d'entrée dans votre éditeur.", 'info');
}

async function relancerCalculWorkflow() {
    const materiau = window.materiauSelectionne;
    const modal = creerModalProgression('Relance du workflow (mode sans API)...');

    try {
        modal.remove();
        const commande = `cd /home/hiadsi/Interface-QE_v1 && ./lancer_workflow_intelligent.sh ${materiau}`;
        afficherModalCommande('Commande à exécuter (local)', commande, 'Copiez-collez cette commande dans un terminal.');
    } catch (e) {
        modal.remove();
        afficherNotification(`⚠️ Relance locale indisponible: ${e.message}`, 'warning');
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// FICHIERS OUTPUT
// ═══════════════════════════════════════════════════════════════════════════

async function afficherFichierOutput(nomFichier) {
    const materiau = window.materiauSelectionne;
    const filepath = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}/${nomFichier}`;

    try {
        let contenu = null;
        if (typeof window.lireFichierLocal === 'function') {
            try { contenu = await window.lireFichierLocal(filepath); } catch (_) {}
        }
        if (contenu) {
            afficherModalFichier(nomFichier, contenu);
        } else {
            afficherNotification(`⚠️ Mode sans API: lecture locale indisponible pour ${nomFichier}`, 'warning');
        }
    } catch (error) {
        afficherNotification(`⚠️ ${error.message}`, 'warning');
    }
}

function afficherModalFichier(nomFichier, contenu) {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.8);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        overflow-y: auto;
    `;
    
    modal.innerHTML = `
        <div style="background: white; border-radius: 15px; max-width: 1000px; width: 100%; padding: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.3); margin: 20px 0;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 2px solid #4f46e5; padding-bottom: 15px;">
                <h2 style="margin: 0; color: #4f46e5;">📄 ${nomFichier}</h2>
                <button onclick="this.parentElement.parentElement.parentElement.remove()" style="background: none; border: none; font-size: 2em; cursor: pointer; color: #666;">×</button>
            </div>
            
            <pre style="background: #1e1e1e; color: #aed581; padding: 20px; border-radius: 8px; max-height: 600px; overflow-y: auto; font-family: 'Courier New', monospace; font-size: 0.9em; line-height: 1.5;">${contenu}</pre>
            
            <div style="display: flex; gap: 15px; margin-top: 20px; justify-content: center;">
                <button onclick="this.parentElement.parentElement.parentElement.remove()" class="btn" style="padding: 12px 30px; background: #6b7280; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">
                    ❌ Fermer
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

async function listerTousFichiers() {
    const materiau = window.materiauSelectionne;
    const dossier = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}`;

    try {
        // Mode sans API: pas de listage automatique. Afficher un message clair.
        afficherNotification("⚠️ Mode sans API: listage des fichiers non disponible. Ouvrez le dossier outputs dans votre explorateur.", 'info');
    } catch (error) {
        afficherNotification(`⚠️ ${error.message}`, 'warning');
    }
}

function afficherListeFichiers(fichiers) {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.8);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    `;
    
    let contenuHTML = `
        <div style="background: white; border-radius: 15px; max-width: 800px; width: 100%; padding: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 2px solid #4f46e5; padding-bottom: 15px;">
                <h2 style="margin: 0; color: #4f46e5;">📂 Fichiers de Sortie</h2>
                <button onclick="this.parentElement.parentElement.parentElement.remove()" style="background: none; border: none; font-size: 2em; cursor: pointer; color: #666;">×</button>
            </div>
            
            <div style="max-height: 400px; overflow-y: auto;">
                <table style="width: 100%; border-collapse: collapse;">
                    <tr style="background: #4f46e5; color: white;">
                        <th style="padding: 12px; text-align: left; border: 1px solid #e5e7eb;">Fichier</th>
                        <th style="padding: 12px; text-align: left; border: 1px solid #e5e7eb;">Taille</th>
                        <th style="padding: 12px; text-align: left; border: 1px solid #e5e7eb;">Action</th>
                    </tr>
    `;
    
    for (const fichier of fichiers) {
        contenuHTML += `
            <tr style="background: ${fichiers.indexOf(fichier) % 2 === 0 ? '#f9fafb' : 'white'};">
                <td style="padding: 12px; border: 1px solid #e5e7eb;">${fichier.nom}</td>
                <td style="padding: 12px; border: 1px solid #e5e7eb;">${fichier.taille}</td>
                <td style="padding: 12px; border: 1px solid #e5e7eb;">
                    <button onclick="afficherFichierOutput('${fichier.nom}')" style="padding: 6px 12px; background: #4f46e5; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 0.9em;">
                        Voir
                    </button>
                </td>
            </tr>
        `;
    }
    
    contenuHTML += `
                </table>
            </div>
            
            <div style="display: flex; gap: 15px; margin-top: 20px; justify-content: center;">
                <button onclick="this.parentElement.parentElement.parentElement.remove()" class="btn" style="padding: 12px 30px; background: #6b7280; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">
                    ❌ Fermer
                </button>
            </div>
        </div>
    `;
    
    modal.innerHTML = contenuHTML;
    document.body.appendChild(modal);
}

// ═══════════════════════════════════════════════════════════════════════════
// EXTRACTION DE PARAMÈTRES
// ═══════════════════════════════════════════════════════════════════════════

async function extraireEnergieFermi() {
    const materiau = window.materiauSelectionne;
    const filepath = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}/scf.out`;

    try {
        let contenu = null;
        if (typeof window.lireFichierLocal === 'function') {
            try { contenu = await window.lireFichierLocal(filepath); } catch (_) {}
        }
        if (contenu) {
            const lignes = contenu.split('\n');
            let fermi = null;
            for (const ligne of lignes) {
                if (ligne.includes('Fermi energy') || ligne.includes('the Fermi energy is')) {
                    const match = ligne.match(/[\d.-]+/);
                    if (match) { fermi = match[0]; break; }
                }
            }
            if (fermi) {
                afficherNotification(`⚡ Énergie de Fermi: ${fermi} eV`, 'success');
            } else {
                afficherNotification('⚠️ Énergie de Fermi non trouvée dans le fichier', 'warning');
            }
        } else {
            afficherNotification("⚠️ Mode sans API: lecture locale indisponible (scf.out)", 'warning');
        }
    } catch (error) {
        afficherNotification(`⚠️ ${error.message}`, 'warning');
    }
}

async function extraireEnergieTotale() {
    const materiau = window.materiauSelectionne;
    const filepath = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}/scf.out`;

    try {
        let contenu = null;
        if (typeof window.lireFichierLocal === 'function') {
            try { contenu = await window.lireFichierLocal(filepath); } catch (_) {}
        }
        if (contenu) {
            const lignes = contenu.split('\n');
            let energie = null;
            for (const ligne of lignes) {
                if (ligne.includes('!') && ligne.includes('total energy')) {
                    const match = ligne.match(/[\d.-]+/);
                    if (match) { energie = match[0]; }
                }
            }
            if (energie) {
                afficherNotification(`📊 Énergie Totale: ${energie} Ry`, 'success');
            } else {
                afficherNotification('⚠️ Énergie totale non trouvée dans le fichier', 'warning');
            }
        } else {
            afficherNotification("⚠️ Mode sans API: lecture locale indisponible (scf.out)", 'warning');
        }
    } catch (error) {
        afficherNotification(`⚠️ ${error.message}`, 'warning');
    }
}

function extraireParametresStructure() {
    afficherNotification('🔷 Paramètres de Structure: Fonctionnalité en développement...', 'info');
}

function extraireForces() {
    afficherNotification('🔨 Forces Atomiques: Fonctionnalité en développement...', 'info');
}

// ═══════════════════════════════════════════════════════════════════════════
// COMPARAISON ET ANALYSE
// ═══════════════════════════════════════════════════════════════════════════

function comparerEnergies() {
    afficherNotification('📊 Comparaison des Énergies: Fonctionnalité en développement...', 'info');
}

function comparerStructures() {
    afficherNotification('🔷 Comparaison des Structures: Fonctionnalité en développement...', 'info');
}

function afficherConvergence() {
    afficherNotification('📈 Convergence SCF: Fonctionnalité en développement...', 'info');
}

function afficherStatistiques() {
    afficherNotification('📋 Statistiques: Fonctionnalité en développement...', 'info');
}

// ═══════════════════════════════════════════════════════════════════════════
// AIDE ET DOCUMENTATION
// ═══════════════════════════════════════════════════════════════════════════

function afficherGuideAnalyse() {
    alert(`📖 Guide d'Analyse:

1. Lancer BANDS.X et DOS.X
   - Cliquez sur "Lancer BANDS.X et DOS.X"
   - Attendez la fin de l'exécution

2. Afficher l'Analyse
   - Cliquez sur "Afficher l'Analyse"
   - Consultez le tableau et les plots

3. Interpréter les Résultats
   - Gap d'Énergie: Différence entre HOMO et LUMO
   - DOS au Fermi: Densité d'états au niveau de Fermi
   - Largeur de Bande: Étendue énergétique totale

4. Exporter les Résultats
   - Téléchargez en CSV ou HTML`);
}

function afficherGuideInterpretation() {
    alert(`💡 Interprétation des Résultats:

Gap d'Énergie:
- Si Gap > 0: Semi-conducteur
- Si Gap ≤ 0: Métal

DOS au Fermi:
- Si N(E_F) = 0: Isolant
- Si N(E_F) > 0: Métal

Bandes:
- Énergies négatives: États occupés (valence)
- Énergies positives: États vides (conduction)`);
}

function afficherGlossaire() {
    alert(`📚 Glossaire:

SCF: Self-Consistent Field (Champ auto-cohérent)
NSCF: Non Self-Consistent Field
BANDS: Structure de bandes
DOS: Densité d'États
E_F: Énergie de Fermi
HOMO: Highest Occupied Molecular Orbital
LUMO: Lowest Unoccupied Molecular Orbital`);
}

function afficherFAQ() {
    alert(`❓ Questions Fréquemment Posées:

Q: Pourquoi le gap est-il négatif?
R: Cela signifie que le matériau est un métal.

Q: Qu'est-ce que le DOS au Fermi?
R: C'est la densité d'états au niveau de Fermi.

Q: Comment interpréter les bandes?
R: Les énergies négatives sont occupées, les positives sont vides.`);
}

// ═══════════════════════════════════════════════════════════════════════════
// UTILITAIRES MODALS ET NOTIFICATIONS
// ═══════════════════════════════════════════════════════════════════════════

function creerModalProgression(message) {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.8);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
    `;
    modal.innerHTML = `
        <div style="background: white; padding: 30px; border-radius: 15px; text-align: center;">
            <div style="font-size: 3em; margin-bottom: 15px;">⏳</div>
            <div style="font-size: 1.2em; color: #4f46e5; font-weight: bold;">${message}</div>
        </div>
    `;
    document.body.appendChild(modal);
    return modal;
}

function afficherNotification(message, type = 'info') {
    const colors = {
        success: '#10b981',
        error: '#ef4444',
        info: '#3b82f6',
        warning: '#f59e0b'
    };
    
    const notif = document.createElement('div');
    notif.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${colors[type]};
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        z-index: 10001;
        animation: slideIn 0.3s ease;
        max-width: 400px;
    `;
    notif.textContent = message;
    document.body.appendChild(notif);
    
    setTimeout(() => {
        notif.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notif.remove(), 300);
    }, 3000);
}

function afficherModalConfirmation(titre, message, onConfirm) {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.8);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    `;
    modal.innerHTML = `
        <div style="background: white; padding: 30px; border-radius: 15px; max-width: 500px;">
            <h2 style="margin: 0 0 15px 0; color: #4f46e5;">${titre}</h2>
            <p style="white-space: pre-line; margin: 0 0 20px 0; color: #666;">${message}</p>
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
                <button onclick="this.parentElement.parentElement.parentElement.remove()" 
                        style="padding: 10px 20px; background: #6b7280; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">
                    Annuler
                </button>
                <button onclick="this.parentElement.parentElement.parentElement.remove(); (${onConfirm.toString()})()" 
                        style="padding: 10px 20px; background: #4f46e5; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">
                    Confirmer
                </button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

function afficherModalCommande(titre, commande, description = '') {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.8);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    `;
    modal.innerHTML = `
        <div style="background: white; padding: 30px; border-radius: 15px; max-width: 700px; width: 100%;">
            <h2 style="margin: 0 0 15px 0; color: #4f46e5;">${titre}</h2>
            ${description ? `<p style="margin: 0 0 15px 0; color: #666; white-space: pre-line;">${description}</p>` : ''}
            <p style="margin: 0 0 15px 0; color: #666;">Exécutez cette commande dans un terminal :</p>
            <pre style="background: #1e1e1e; color: #aed581; padding: 15px; border-radius: 8px; overflow-x: auto; font-family: 'Courier New', monospace; max-height: 400px;">${commande}</pre>
            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                <button onclick="navigator.clipboard.writeText(\`${commande.replace(/`/g, '\\`')}\`); afficherNotification('📋 Commande copiée', 'success')" 
                        style="padding: 10px 20px; background: #10b981; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">
                    📋 Copier
                </button>
                <button onclick="this.parentElement.parentElement.parentElement.remove()" 
                        style="padding: 10px 20px; background: #6b7280; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">
                    Fermer
                </button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

// Alias pour compatibilité
function afficherModalCommandeAvecExecution(titre, commande, description = '') {
    afficherModalCommande(titre, commande, description);
}

function declencherTelechargement(nom, contenu) {
    const blob = new Blob([contenu], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = nom;
    document.body.appendChild(a);
    a.click();
    URL.revokeObjectURL(url);
    a.remove();
}

function afficherModalAnalyse(payload) {
    const { tableau = [], resume = {}, plots = {} } = payload;
    const modal = document.createElement('div');
    modal.style.cssText = `position: fixed; inset: 0; background: rgba(0,0,0,0.8); z-index: 10000; display: flex; align-items: center; justify-content: center; padding: 20px; overflow-y: auto;`;
    const rows = Array.isArray(tableau) ? tableau.map(ligne => `<tr><td style="padding:8px;border:1px solid #e5e7eb;">${ligne.clef || ''}</td><td style="padding:8px;border:1px solid #e5e7eb;">${ligne.valeur || ''}</td></tr>`).join('') : '';
    modal.innerHTML = `
        <div style="background:white;border-radius:15px;max-width:1000px;width:100%;padding:30px;box-shadow:0 10px 40px rgba(0,0,0,0.3);margin:20px 0;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;border-bottom:2px solid #4f46e5;padding-bottom:15px;">
                <h2 style="margin:0;color:#4f46e5;">📊 Analyse BANDS/DOS</h2>
                <button onclick="this.parentElement.parentElement.parentElement.remove()" style="background:none;border:none;font-size:2em;cursor:pointer;color:#666;">×</button>
            </div>
            <div style="display:grid;grid-template-columns:1fr;gap:15px;">
                <div>
                    <h3 style="margin:0 0 10px 0;">Résumé</h3>
                    <pre style="background:#f9fafb;padding:12px;border-radius:8px;max-height:200px;overflow:auto;">${JSON.stringify(resume, null, 2)}</pre>
                </div>
                <div>
                    <h3 style="margin:0 0 10px 0;">Tableau</h3>
                    <table style="width:100%;border-collapse:collapse;">
                        <tr style="background:#4f46e5;color:white;"><th style="padding:8px;border:1px solid #e5e7eb;">Clé</th><th style="padding:8px;border:1px solid #e5e7eb;">Valeur</th></tr>
                        ${rows}
                    </table>
                </div>
                <div>
                    <h3 style="margin:0 0 10px 0;">Plots</h3>
                    <pre style="background:#f9fafb;padding:12px;border-radius:8px;max-height:200px;overflow:auto;">${JSON.stringify(plots, null, 2)}</pre>
                </div>
            </div>
        </div>`;
    document.body.appendChild(modal);
}

// Ajouter les animations CSS
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);

console.log('✅ Script onglet résultats chargé');

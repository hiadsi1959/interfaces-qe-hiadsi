// ═══════════════════════════════════════════════════════════════════════════
// SURVEILLANCE AUTOMATIQUE DES CALCULS ET ENCHAÎNEMENT
// ═══════════════════════════════════════════════════════════════════════════
//
// Ce script surveille les calculs en cours et:
// 1. Détecte quand un calcul est terminé
// 2. Vérifie les résultats et affiche les erreurs
// 3. Propose automatiquement de générer les inputs suivants
// 4. Permet l'enchaînement des calculs
//
// ═══════════════════════════════════════════════════════════════════════════

const API_BASE_SURV = window.API_BASE || 'http://localhost:5007';

// État de la surveillance
let surveillanceActive = {};
let intervalsSurveillance = {};

// Définition des workflows
const WORKFLOWS = {
    electronique: {
        nom: 'Workflow Électronique',
        etapes: ['vcrelax', 'scf', 'nscf', 'bands', 'dos'],
        couleur: '#3b82f6'
    },
    phonons: {
        nom: 'Workflow Phonons',
        etapes: ['scf', 'ph', 'q2r', 'matdyn'],
        couleur: '#8b5cf6'
    }
};

// Étapes suivantes pour chaque type de calcul
const ETAPES_SUIVANTES = {
    'vcrelax': ['scf'],
    'scf': ['nscf', 'ph'],
    'nscf': ['bands', 'dos'],
    'bands': [],
    'dos': [],
    'ph': ['q2r'],
    'q2r': ['matdyn'],
    'matdyn': []
};

/**
 * Démarre la surveillance d'un calcul
 */
function demarrerSurveillance(materiau, typeCalcul, interval = 10000) {
    const cle = `${materiau}_${typeCalcul}`;
    
    if (surveillanceActive[cle]) {
        console.log(`Surveillance déjà active pour ${cle}`);
        return;
    }
    
    console.log(`🔍 Démarrage surveillance: ${materiau} / ${typeCalcul}`);
    surveillanceActive[cle] = true;
    
    // Vérifier immédiatement
    verifierEtatCalcul(materiau, typeCalcul);
    
    // Puis périodiquement
    intervalsSurveillance[cle] = setInterval(() => {
        verifierEtatCalcul(materiau, typeCalcul);
    }, interval);
    
    // Afficher l'indicateur de surveillance
    afficherIndicateurSurveillance(materiau, typeCalcul);
}

/**
 * Arrête la surveillance d'un calcul
 */
function arreterSurveillance(materiau, typeCalcul) {
    const cle = `${materiau}_${typeCalcul}`;
    
    if (intervalsSurveillance[cle]) {
        clearInterval(intervalsSurveillance[cle]);
        delete intervalsSurveillance[cle];
    }
    
    surveillanceActive[cle] = false;
    
    // Retirer l'indicateur
    const indicateur = document.getElementById(`indicateur_${cle}`);
    if (indicateur) indicateur.remove();
}

/**
 * Vérifie l'état d'un calcul via l'API
 */
async function verifierEtatCalcul(materiau, typeCalcul) {
    try {
        const response = await fetch(`${API_BASE_SURV}/api/verifier_calcul/${materiau}/${typeCalcul}`);
        const data = await response.json();
        
        if (!data.success) {
            console.log(`Calcul non trouvé: ${materiau}/${typeCalcul}`);
            return;
        }
        
        const cle = `${materiau}_${typeCalcul}`;
        
        // Traiter selon le statut
        switch (data.status) {
            case 'completed':
                arreterSurveillance(materiau, typeCalcul);
                afficherCalculTermine(materiau, typeCalcul, data);
                break;
                
            case 'error':
                arreterSurveillance(materiau, typeCalcul);
                afficherErreurCalcul(materiau, typeCalcul, data);
                break;
                
            case 'running':
                mettreAJourProgression(materiau, typeCalcul, data);
                break;
                
            case 'stopped':
                arreterSurveillance(materiau, typeCalcul);
                afficherCalculArrete(materiau, typeCalcul, data);
                break;
        }
        
    } catch (error) {
        console.error('Erreur vérification:', error);
    }
}

/**
 * Affiche un indicateur de surveillance
 */
function afficherIndicateurSurveillance(materiau, typeCalcul) {
    const cle = `${materiau}_${typeCalcul}`;
    
    // Supprimer l'ancien s'il existe
    const ancien = document.getElementById(`indicateur_${cle}`);
    if (ancien) ancien.remove();
    
    const indicateur = document.createElement('div');
    indicateur.id = `indicateur_${cle}`;
    indicateur.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: linear-gradient(135deg, #3b82f6, #2563eb);
        color: white;
        padding: 15px 20px;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(59, 130, 246, 0.4);
        z-index: 9999;
        display: flex;
        align-items: center;
        gap: 12px;
        animation: pulse 2s infinite;
    `;
    
    indicateur.innerHTML = `
        <div style="
            width: 12px;
            height: 12px;
            background: #10b981;
            border-radius: 50%;
            animation: blink 1s infinite;
        "></div>
        <div>
            <div style="font-weight: 600;">🔍 Surveillance active</div>
            <div style="font-size: 0.85em; opacity: 0.9;">${materiau} - ${typeCalcul.toUpperCase()}</div>
        </div>
        <button onclick="arreterSurveillance('${materiau}', '${typeCalcul}')" style="
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            padding: 5px 10px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.8em;
        ">Arrêter</button>
    `;
    
    // Ajouter les styles d'animation
    if (!document.getElementById('styles_surveillance')) {
        const style = document.createElement('style');
        style.id = 'styles_surveillance';
        style.textContent = `
            @keyframes blink {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.3; }
            }
            @keyframes pulse {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(1.02); }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(indicateur);
}

/**
 * Affiche une notification de calcul terminé avec actions
 */
function afficherCalculTermine(materiau, typeCalcul, data) {
    const modal = document.createElement('div');
    modal.id = 'modal_calcul_termine';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.7);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 10001;
    `;
    
    // Étapes suivantes possibles
    const etapesSuivantes = ETAPES_SUIVANTES[typeCalcul] || [];
    
    modal.innerHTML = `
        <div style="
            background: white;
            border-radius: 16px;
            max-width: 600px;
            width: 90%;
            overflow: hidden;
            box-shadow: 0 25px 50px rgba(0,0,0,0.3);
        ">
            <!-- Header succès -->
            <div style="
                background: linear-gradient(135deg, #10b981, #059669);
                color: white;
                padding: 25px 30px;
            ">
                <h2 style="margin: 0; display: flex; align-items: center; gap: 12px;">
                    ✅ Calcul Terminé avec Succès!
                </h2>
                <p style="margin: 10px 0 0 0; opacity: 0.9;">
                    ${materiau} - ${typeCalcul.toUpperCase()}
                </p>
            </div>
            
            <!-- Résultats -->
            <div style="padding: 25px 30px;">
                <h3 style="margin: 0 0 15px 0; color: #1f2937;">📊 Résultats</h3>
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px;">
                    ${data.resultats.energie_Ry ? `
                        <div style="background: #f0fdf4; padding: 12px; border-radius: 8px;">
                            <div style="color: #6b7280; font-size: 0.85em;">Énergie Totale</div>
                            <div style="font-weight: 600; color: #166534;">${data.resultats.energie_Ry.toFixed(6)} Ry</div>
                        </div>
                    ` : ''}
                    ${data.resultats.fermi_eV ? `
                        <div style="background: #eff6ff; padding: 12px; border-radius: 8px;">
                            <div style="color: #6b7280; font-size: 0.85em;">Énergie de Fermi</div>
                            <div style="font-weight: 600; color: #1e40af;">${data.resultats.fermi_eV.toFixed(4)} eV</div>
                        </div>
                    ` : ''}
                    ${data.resultats.force_finale !== undefined ? `
                        <div style="background: ${data.resultats.force_finale < 0.001 ? '#f0fdf4' : '#fef3c7'}; padding: 12px; border-radius: 8px;">
                            <div style="color: #6b7280; font-size: 0.85em;">Force Résiduelle</div>
                            <div style="font-weight: 600; color: ${data.resultats.force_finale < 0.001 ? '#166534' : '#92400e'};">
                                ${data.resultats.force_finale.toFixed(6)} Ry/Bohr
                                ${data.resultats.force_finale < 0.001 ? '✓' : '⚠️'}
                            </div>
                        </div>
                    ` : ''}
                    ${data.resultats.pression_kbar !== undefined ? `
                        <div style="background: ${Math.abs(data.resultats.pression_kbar) < 1 ? '#f0fdf4' : '#fef3c7'}; padding: 12px; border-radius: 8px;">
                            <div style="color: #6b7280; font-size: 0.85em;">Pression</div>
                            <div style="font-weight: 600; color: ${Math.abs(data.resultats.pression_kbar) < 1 ? '#166534' : '#92400e'};">
                                ${data.resultats.pression_kbar.toFixed(2)} kbar
                                ${Math.abs(data.resultats.pression_kbar) < 1 ? '✓' : '⚠️'}
                            </div>
                        </div>
                    ` : ''}
                </div>
                
                ${etapesSuivantes.length > 0 ? `
                    <div style="margin-top: 25px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
                        <h3 style="margin: 0 0 15px 0; color: #1f2937;">🔜 Étapes Suivantes</h3>
                        <p style="color: #6b7280; margin-bottom: 15px;">
                            Les inputs ont été générés automatiquement avec les paramètres optimisés.
                        </p>
                        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                            ${etapesSuivantes.map(etape => `
                                <button onclick="lancerEtapeSuivante('${materiau}', '${etape}')" style="
                                    background: linear-gradient(135deg, #3b82f6, #2563eb);
                                    color: white;
                                    border: none;
                                    padding: 12px 20px;
                                    border-radius: 8px;
                                    cursor: pointer;
                                    font-weight: 600;
                                    display: flex;
                                    align-items: center;
                                    gap: 8px;
                                ">
                                    🚀 Lancer ${etape.toUpperCase()}
                                </button>
                            `).join('')}
                        </div>
                    </div>
                ` : `
                    <div style="margin-top: 25px; padding: 15px; background: #f0fdf4; border-radius: 8px;">
                        <p style="margin: 0; color: #166534;">
                            🎉 <strong>Workflow terminé!</strong> Tous les calculs de cette chaîne sont complétés.
                        </p>
                    </div>
                `}
            </div>
            
            <!-- Footer -->
            <div style="
                padding: 20px 30px;
                border-top: 1px solid #e5e7eb;
                display: flex;
                justify-content: space-between;
            ">
                <button onclick="voirResultatsComplets('${materiau}')" style="
                    background: #6b7280;
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 8px;
                    cursor: pointer;
                ">📊 Voir Résultats</button>
                <button onclick="this.closest('#modal_calcul_termine').remove()" style="
                    background: #e5e7eb;
                    color: #374151;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 8px;
                    cursor: pointer;
                ">Fermer</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Jouer un son de notification (si supporté)
    try {
        const audio = new Audio('data:audio/wav;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YU...');
        audio.volume = 0.3;
        // audio.play(); // Décommentez si vous voulez un son
    } catch (e) {}
}

/**
 * Affiche une erreur de calcul avec diagnostic
 */
function afficherErreurCalcul(materiau, typeCalcul, data) {
    const modal = document.createElement('div');
    modal.id = 'modal_erreur_calcul';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.7);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 10001;
    `;
    
    modal.innerHTML = `
        <div style="
            background: white;
            border-radius: 16px;
            max-width: 600px;
            width: 90%;
            overflow: hidden;
            box-shadow: 0 25px 50px rgba(0,0,0,0.3);
        ">
            <!-- Header erreur -->
            <div style="
                background: linear-gradient(135deg, #ef4444, #dc2626);
                color: white;
                padding: 25px 30px;
            ">
                <h2 style="margin: 0; display: flex; align-items: center; gap: 12px;">
                    ❌ Erreur Détectée
                </h2>
                <p style="margin: 10px 0 0 0; opacity: 0.9;">
                    ${materiau} - ${typeCalcul.toUpperCase()}
                </p>
            </div>
            
            <!-- Erreurs -->
            <div style="padding: 25px 30px;">
                <h3 style="margin: 0 0 15px 0; color: #991b1b;">🔍 Messages d'erreur</h3>
                <div style="background: #fee2e2; padding: 15px; border-radius: 8px; max-height: 200px; overflow-y: auto;">
                    ${data.erreurs.map(err => `
                        <div style="margin-bottom: 8px; font-family: monospace; font-size: 0.85em; color: #7f1d1d;">
                            ${err}
                        </div>
                    `).join('') || '<p style="color: #991b1b;">Erreur non spécifiée</p>'}
                </div>
                
                <div style="margin-top: 20px; padding: 15px; background: #fef3c7; border-radius: 8px;">
                    <h4 style="margin: 0 0 10px 0; color: #92400e;">💡 Actions suggérées</h4>
                    <ul style="margin: 0; padding-left: 20px; color: #78350f;">
                        <li>Vérifiez la syntaxe du fichier input</li>
                        <li>Assurez-vous que les pseudopotentiels existent</li>
                        <li>Vérifiez les paramètres de convergence</li>
                    </ul>
                </div>
            </div>
            
            <!-- Footer -->
            <div style="
                padding: 20px 30px;
                border-top: 1px solid #e5e7eb;
                display: flex;
                justify-content: space-between;
                gap: 10px;
            ">
                <button onclick="editerEtCorriger('${materiau}', '${typeCalcul}')" style="
                    background: linear-gradient(135deg, #f59e0b, #d97706);
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 8px;
                    cursor: pointer;
                    font-weight: 600;
                ">🔧 Éditer et Corriger</button>
                <button onclick="this.closest('#modal_erreur_calcul').remove()" style="
                    background: #e5e7eb;
                    color: #374151;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 8px;
                    cursor: pointer;
                ">Fermer</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

/**
 * Met à jour l'indicateur de progression
 */
function mettreAJourProgression(materiau, typeCalcul, data) {
    const cle = `${materiau}_${typeCalcul}`;
    const indicateur = document.getElementById(`indicateur_${cle}`);
    
    if (indicateur) {
        // Extraire l'itération si disponible
        let info = 'En cours...';
        if (data.temps_ecoule_sec) {
            const min = Math.floor(data.temps_ecoule_sec / 60);
            info = `${min} min écoulées`;
        }
        
        const infoDiv = indicateur.querySelector('div:nth-child(2) div:last-child');
        if (infoDiv) {
            infoDiv.textContent = `${materiau} - ${typeCalcul.toUpperCase()} (${info})`;
        }
    }
}

/**
 * Lance l'étape suivante du workflow
 */
async function lancerEtapeSuivante(materiau, typeCalcul) {
    // Fermer le modal
    const modal = document.getElementById('modal_calcul_termine');
    if (modal) modal.remove();
    
    console.log(`🚀 Lancement de ${typeCalcul} pour ${materiau}`);
    
    try {
        // Vérifier que l'input existe
        const inputFile = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}/${materiau}_${typeCalcul}.in`;
        
        // Lancer le calcul via l'API
        const response = await fetch(`${API_BASE_SURV}/api/lancer_calcul`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                input_path: inputFile,
                output_dir: `/home/hiadsi/Interface-QE_v1/outputs/${materiau}`,
                prefix: materiau
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Afficher notification
            afficherNotificationLancement(materiau, typeCalcul, data);
            
            // Démarrer la surveillance
            setTimeout(() => {
                demarrerSurveillance(materiau, typeCalcul);
            }, 2000);
        } else {
            alert(`Erreur: ${data.message || data.error}`);
        }
        
    } catch (error) {
        console.error('Erreur lancement:', error);
        alert(`Erreur: ${error.message}`);
    }
}

/**
 * Affiche une notification de lancement
 */
function afficherNotificationLancement(materiau, typeCalcul, data) {
    const notif = document.createElement('div');
    notif.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #10b981, #059669);
        color: white;
        padding: 20px 25px;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        z-index: 10002;
        animation: slideIn 0.3s ease;
    `;
    
    notif.innerHTML = `
        <div style="display: flex; align-items: center; gap: 12px;">
            <span style="font-size: 1.5em;">🚀</span>
            <div>
                <strong>Calcul lancé!</strong>
                <div style="font-size: 0.9em; opacity: 0.9;">${materiau} - ${typeCalcul.toUpperCase()}</div>
            </div>
        </div>
    `;
    
    document.body.appendChild(notif);
    setTimeout(() => notif.remove(), 5000);
}

/**
 * Ouvre l'éditeur pour corriger une erreur
 */
function editerEtCorriger(materiau, typeCalcul) {
    // Fermer le modal d'erreur
    const modal = document.getElementById('modal_erreur_calcul');
    if (modal) modal.remove();
    
    // Utiliser le workflow d'erreur si disponible
    if (typeof window.ouvrirEditeurAvecCorrections === 'function') {
        const inputFile = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}/${materiau}_${typeCalcul}.in`;
        const outputFile = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}/${materiau}_${typeCalcul}.out`;
        window.ouvrirEditeurAvecCorrections(materiau, inputFile, outputFile, typeCalcul);
    } else {
        // Fallback: ouvrir l'onglet génération
        if (typeof switchTab === 'function') {
            switchTab(0);
        }
    }
}

/**
 * Ouvre l'onglet résultats
 */
function voirResultatsComplets(materiau) {
    const modal = document.getElementById('modal_calcul_termine');
    if (modal) modal.remove();
    
    // Ouvrir l'onglet résultats
    if (typeof switchTab === 'function') {
        switchTab(2);
    }
    
    // Sélectionner le matériau
    setTimeout(() => {
        const select = document.getElementById('select_materiau_analyse');
        if (select) {
            select.value = materiau;
            if (typeof chargerCalculsMateriau === 'function') {
                chargerCalculsMateriau();
            }
        }
    }, 500);
}

/**
 * Affiche un calcul arrêté (ni terminé, ni erreur)
 */
function afficherCalculArrete(materiau, typeCalcul, data) {
    const notif = document.createElement('div');
    notif.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #fef3c7;
        border: 2px solid #f59e0b;
        color: #92400e;
        padding: 20px 25px;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        z-index: 10002;
        max-width: 400px;
    `;
    
    notif.innerHTML = `
        <div style="display: flex; align-items: flex-start; gap: 12px;">
            <span style="font-size: 1.5em;">⚠️</span>
            <div>
                <strong>Calcul arrêté</strong>
                <p style="margin: 8px 0 0 0; font-size: 0.9em;">
                    Le calcul ${materiau}/${typeCalcul} semble s'être arrêté sans converger.
                </p>
                <div style="margin-top: 12px; display: flex; gap: 8px;">
                    <button onclick="editerEtCorriger('${materiau}', '${typeCalcul}'); this.closest('div').parentElement.parentElement.remove();" style="
                        background: #f59e0b;
                        color: white;
                        border: none;
                        padding: 6px 12px;
                        border-radius: 6px;
                        cursor: pointer;
                        font-size: 0.85em;
                    ">Vérifier</button>
                    <button onclick="this.closest('div').parentElement.parentElement.remove()" style="
                        background: #e5e7eb;
                        color: #374151;
                        border: none;
                        padding: 6px 12px;
                        border-radius: 6px;
                        cursor: pointer;
                        font-size: 0.85em;
                    ">Ignorer</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(notif);
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORTS GLOBAUX
// ═══════════════════════════════════════════════════════════════════════════

window.demarrerSurveillance = demarrerSurveillance;
window.arreterSurveillance = arreterSurveillance;
window.verifierEtatCalcul = verifierEtatCalcul;
window.lancerEtapeSuivante = lancerEtapeSuivante;
window.editerEtCorriger = editerEtCorriger;
window.voirResultatsComplets = voirResultatsComplets;

console.log('✅ Script surveillance_calculs.js chargé');

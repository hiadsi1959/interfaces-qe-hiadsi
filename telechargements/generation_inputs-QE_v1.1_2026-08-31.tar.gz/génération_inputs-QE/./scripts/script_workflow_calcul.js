// ═══════════════════════════════════════════════════════════════════════════
// WORKFLOW COMPLET: SAUVEGARDE + LANCEMENT + SUIVI DU CALCUL
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Sauvegarder l'input dans /home/hiadsi/génération_inputs-QE/inputs_générés/prefix/
 */
async function sauvegarderInputServeur(inputContent, prefix) {
    console.log(`\n💾 Sauvegarde de l'input sur le serveur...`);
    console.log(`  Prefix: ${prefix}`);
    
    if (!inputContent || inputContent.trim().length === 0) {
        throw new Error('Contenu de l\'input vide');
    }
    
    if (!prefix || prefix.trim().length === 0) {
        throw new Error('Prefix manquant');
    }
    
    try {
        // ⭐ RÉCUPÉRER LES CHEMINS depuis Section 5
        let baseInputDir = document.getElementById('path_inputs_field')?.value || '/home/hiadsi/Interface-QE_v1/inputs';
        let baseOutputDir = document.getElementById('path_outputs_field')?.value || '/home/hiadsi/Interface-QE_v1/outputs';
        
        // ⚠️ IMPORTANT: Nettoyer les chemins pour éviter doublon
        // Si l'utilisateur a mis "/inputs/prefix", on retire le dernier "/prefix"
        if (baseInputDir.endsWith(`/${prefix}`)) {
            baseInputDir = baseInputDir.substring(0, baseInputDir.lastIndexOf(`/${prefix}`));
            console.log(`⚠️ Chemin input contenait déjà prefix, nettoyé: ${baseInputDir}`);
        }
        if (baseOutputDir.endsWith(`/${prefix}`)) {
            baseOutputDir = baseOutputDir.substring(0, baseOutputDir.lastIndexOf(`/${prefix}`));
            console.log(`⚠️ Chemin output contenait déjà prefix, nettoyé: ${baseOutputDir}`);
        }
        
        // Construire les chemins avec prefix
        const inputDir = `${baseInputDir}/${prefix}`;
        const outputDir = `${baseOutputDir}/${prefix}`;
        const filename = `${prefix}.in`;
        
        console.log(`  Base Input: ${baseInputDir}`);
        console.log(`  Base Output: ${baseOutputDir}`);
        console.log(`  Input dir: ${inputDir}`);
        console.log(`  Output dir: ${outputDir}`);
        console.log(`  Filename: ${filename}`);
        
        // Appeler l'API pour sauvegarder
        const response = await fetch('http://localhost:5007/api/sauvegarder_input_custom', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                content: inputContent,
                prefix: prefix,
                input_dir: inputDir,
                output_dir: outputDir,
                filename: filename
            })
        });
        
        if (!response.ok) {
            throw new Error(`Erreur HTTP: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (!result.success) {
            throw new Error(result.error || 'Erreur de sauvegarde');
        }
        
        console.log(`✅ Input sauvegardé: ${result.filepath}`);
        
        return {
            success: true,
            filepath: result.filepath,
            input_dir: inputDir,
            output_dir: outputDir,
            filename: filename
        };
        
    } catch (error) {
        console.error('❌ Erreur de sauvegarde:', error);
        throw error;
    }
}

/**
 * Lancer le calcul via l'API
 */
async function lancerCalculServeur(filepath, outputDir, prefix) {
    console.log(`\n🚀 Lancement du calcul...`);
    console.log(`  Input: ${filepath}`);
    console.log(`  Output dir: ${outputDir}`);
    
    try {
        const response = await fetch('http://localhost:5007/api/lancer_calcul_custom', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                input_file: filepath,
                output_dir: outputDir,
                prefix: prefix,
                nprocs: 4  // Par défaut 4 processeurs
            })
        });
        
        if (!response.ok) {
            throw new Error(`Erreur HTTP: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (!result.success) {
            throw new Error(result.error || 'Erreur de lancement');
        }
        
        console.log(`✅ Calcul lancé: ${result.calcul_id}`);
        
        return {
            success: true,
            calcul_id: result.calcul_id,
            output_file: result.output_file,
            mode: result.mode || 'reel'
        };
        
    } catch (error) {
        console.error('❌ Erreur de lancement:', error);
        throw error;
    }
}

/**
 * Workflow complet: Sauvegarder + Lancer + Afficher suivi
 */
async function workflowCompletCalcul() {
    console.log('\n\n═══════════════════════════════════════════════════════════');
    console.log('🚀 WORKFLOW COMPLET: SAUVEGARDE + LANCEMENT + SUIVI');
    console.log('═══════════════════════════════════════════════════════════\n');
    
    try {
        // Afficher le loader
        afficherLoader('Préparation du calcul...');
        
        // 1. Récupérer le contenu de l'input généré (NOUVEAU ID dans Section 5)
        let contentTextarea = document.getElementById('preview_input');
        
        // Fallback vers ancien ID
        if (!contentTextarea) {
            contentTextarea = document.getElementById('input_content');
        }
        
        // Fallback vers d'autres IDs possibles
        if (!contentTextarea) {
            contentTextarea = document.getElementById('input_preview');
        }
        
        if (!contentTextarea) {
            console.error('❌ Zone de texte introuvable. IDs cherchés: preview_input, input_content, input_preview');
            throw new Error('Zone de texte de l\'input non trouvée. Générez d\'abord l\'input!');
        }
        
        const inputContent = contentTextarea.value;
        if (!inputContent || inputContent.trim().length === 0) {
            throw new Error('L\'input est vide. Générez d\'abord l\'input!');
        }
        
        // 2. Récupérer le prefix (nom du matériau)
        const materiauxInput = document.getElementById('materiau_name');
        if (!materiauxInput) {
            console.warn('⚠️ Champ materiau_name introuvable, utilisation du nom par défaut');
        }
        const prefix = materiauxInput?.value || 'calcul';
        
        console.log(`📋 Prefix: ${prefix}`);
        console.log(`📄 Taille input: ${inputContent.length} caractères`);
        
        // 3. Sauvegarder l'input
        updateLoader('Sauvegarde de l\'input sur le serveur...');
        const saveResult = await sauvegarderInputServeur(inputContent, prefix);
        
        console.log(`✅ Sauvegarde réussie:`);
        console.log(`   → ${saveResult.filepath}`);
        
        // 4. Lancer le calcul
        updateLoader('Lancement du calcul Quantum ESPRESSO...');
        const launchResult = await lancerCalculServeur(
            saveResult.filepath,
            saveResult.output_dir,
            prefix
        );
        
        console.log(`✅ Calcul lancé:`);
        console.log(`   → ID: ${launchResult.calcul_id}`);
        console.log(`   → Mode: ${launchResult.mode}`);
        console.log(`   → Output: ${launchResult.output_file}`);
        
        // 5. Fermer le loader
        cacherLoader();
        
        // 6. Afficher notification de succès
        afficherNotificationSucces(prefix, launchResult.calcul_id);
        
        // 7. Ouvrir l'onglet de suivi automatiquement
        setTimeout(() => {
            ouvrirOngletSuivi(launchResult.calcul_id, prefix);
        }, 1500);
        
        return {
            success: true,
            calcul_id: launchResult.calcul_id,
            output_file: launchResult.output_file
        };
        
    } catch (error) {
        cacherLoader();
        afficherErreur(error.message);
        throw error;
    }
}

/**
 * Afficher un loader pendant le processus
 */
function afficherLoader(message) {
    // Supprimer l'ancien loader s'il existe
    cacherLoader();
    
    const loader = document.createElement('div');
    loader.id = 'loader_workflow';
    loader.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        z-index: 10000;
    `;
    
    loader.innerHTML = `
        <div style="
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.5);
            text-align: center;
            max-width: 500px;
        ">
            <div style="
                width: 80px;
                height: 80px;
                border: 8px solid rgba(255,255,255,0.3);
                border-top-color: white;
                border-radius: 50%;
                animation: spin 1s linear infinite;
                margin: 0 auto 20px;
            "></div>
            <h2 style="color: white; margin: 0 0 10px 0;">🚀 Lancement du Calcul</h2>
            <p id="loader_message" style="color: rgba(255,255,255,0.9); margin: 0; font-size: 1.1em;">
                ${message}
            </p>
        </div>
    `;
    
    // Ajouter l'animation spin si elle n'existe pas
    if (!document.getElementById('spin-animation')) {
        const style = document.createElement('style');
        style.id = 'spin-animation';
        style.textContent = `
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(loader);
}

/**
 * Mettre à jour le message du loader
 */
function updateLoader(message) {
    const loaderMessage = document.getElementById('loader_message');
    if (loaderMessage) {
        loaderMessage.textContent = message;
    } else {
        console.warn('⚠️ Loader message element not found');
    }
}

/**
 * Cacher le loader
 */
function cacherLoader() {
    const loader = document.getElementById('loader_workflow');
    if (loader) {
        loader.remove();
    }
}

/**
 * Afficher une notification de succès
 */
function afficherNotificationSucces(prefix, calculId) {
    const notif = document.createElement('div');
    notif.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #4caf50 0%, #45a049 100%);
        color: white;
        padding: 20px 30px;
        border-radius: 10px;
        box-shadow: 0 6px 20px rgba(0,0,0,0.3);
        z-index: 9999;
        max-width: 400px;
        animation: slideIn 0.3s ease-out;
    `;
    
    notif.innerHTML = `
        <div style="display: flex; align-items: center; gap: 15px;">
            <div style="font-size: 2em;">✅</div>
            <div>
                <h3 style="margin: 0 0 5px 0; font-size: 1.2em;">Calcul Lancé!</h3>
                <p style="margin: 0; font-size: 0.9em; opacity: 0.9;">
                    <strong>${prefix}</strong><br>
                    ID: ${calculId.substring(0, 20)}...<br>
                    Ouverture du suivi...
                </p>
            </div>
        </div>
    `;
    
    document.body.appendChild(notif);
    
    // Retirer après 5 secondes
    setTimeout(() => {
        notif.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => notif.remove(), 300);
    }, 5000);
}

/**
 * Afficher une erreur
 */
function afficherErreur(message) {
    const notif = document.createElement('div');
    notif.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #f44336 0%, #e53935 100%);
        color: white;
        padding: 20px 30px;
        border-radius: 10px;
        box-shadow: 0 6px 20px rgba(0,0,0,0.3);
        z-index: 9999;
        max-width: 400px;
        animation: slideIn 0.3s ease-out;
    `;
    
    notif.innerHTML = `
        <div style="display: flex; align-items: center; gap: 15px;">
            <div style="font-size: 2em;">❌</div>
            <div>
                <h3 style="margin: 0 0 5px 0; font-size: 1.2em;">Erreur</h3>
                <p style="margin: 0; font-size: 0.9em; opacity: 0.9;">
                    ${message}
                </p>
            </div>
        </div>
        <button onclick="this.parentElement.remove()" style="
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            width: 25px;
            height: 25px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 1.2em;
            line-height: 1;
        ">×</button>
    `;
    
    document.body.appendChild(notif);
    
    // Retirer après 10 secondes
    setTimeout(() => {
        notif.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => notif.remove(), 300);
    }, 10000);
}

/**
 * Ouvrir l'onglet de suivi et afficher le calcul
 */
function ouvrirOngletSuivi(calculId, prefix) {
    console.log(`\n📊 Ouverture de l'onglet suivi...`);
    console.log(`  Calcul ID: ${calculId}`);
    console.log(`  Prefix: ${prefix}`);
    
    // Trouver le bouton de l'onglet "Suivi des Calculs" (Tab 3)
    const tabs = document.querySelectorAll('.tab');
    let suiviTab = null;
    
    tabs.forEach((tab, index) => {
        if (tab.textContent.includes('Suivi') || tab.textContent.includes('Calculs') || index === 2) {
            suiviTab = tab;
        }
    });
    
    if (suiviTab) {
        // Cliquer sur l'onglet
        suiviTab.click();
        
        // Attendre que l'onglet soit ouvert puis afficher le suivi
        setTimeout(() => {
            afficherSuiviCalcul(calculId, prefix);
        }, 500);
    } else {
        console.warn('⚠️ Onglet de suivi non trouvé');
        alert('Calcul lancé! Allez dans l\'onglet "Suivi des Calculs" pour voir la progression.');
    }
}

/**
 * Afficher le suivi du calcul en temps réel
 */
function afficherSuiviCalcul(calculId, prefix) {
    console.log(`\n📊 Affichage du suivi pour ${calculId}...`);
    
    // Chercher la zone de contenu de l'onglet Tab 3
    const tabContent = document.getElementById('tab3');
    if (!tabContent) {
        console.error('❌ Tab3 non trouvé - impossible d\'afficher le suivi');
        alert(`✅ Calcul lancé!\n\nID: ${calculId}\nMatériau: ${prefix}\n\nAllez dans l'onglet "Suivi des Calculs" pour voir la progression.`);
        return;
    }
    
    // Créer une fenêtre de suivi
    const suiviDiv = document.createElement('div');
    suiviDiv.id = `suivi_${calculId}`;
    suiviDiv.style.cssText = `
        margin: 20px;
        padding: 20px;
        background: white;
        border: 2px solid #667eea;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    `;
    
    suiviDiv.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <div>
                <h3 style="margin: 0 0 5px 0; color: #667eea;">
                    🧮 Calcul en cours: ${prefix}
                </h3>
                <p style="margin: 0; color: #666; font-size: 0.9em;">
                    ID: ${calculId}
                </p>
            </div>
            <div id="statut_${calculId}" style="
                padding: 8px 16px;
                background: #ffa726;
                color: white;
                border-radius: 20px;
                font-weight: bold;
            ">
                ⏳ En cours...
            </div>
        </div>
        
        <div style="
            background: #1e1e1e;
            color: #00ff00;
            font-family: monospace;
            padding: 15px;
            border-radius: 5px;
            height: 400px;
            overflow-y: auto;
            margin-bottom: 15px;
        " id="logs_${calculId}">
            <div style="color: #00ff00;">
                ═══════════════════════════════════════════════════════════
                🚀 QUANTUM ESPRESSO - CALCUL EN COURS
                ═══════════════════════════════════════════════════════════
                
                Matériau: ${prefix}
                ID: ${calculId}
                Début: ${new Date().toLocaleTimeString()}
                
                ═══════════════════════════════════════════════════════════
                
                Initialisation...
                
            </div>
        </div>
        
        <div style="display: flex; gap: 10px;">
            <button onclick="actualiserSuiviCalcul('${calculId}')" style="
                padding: 10px 20px;
                background: #2196f3;
                color: white;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                font-weight: bold;
            ">
                🔄 Actualiser
            </button>
            <button onclick="arreterSuiviCalcul('${calculId}')" style="
                padding: 10px 20px;
                background: #f44336;
                color: white;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                font-weight: bold;
            ">
                ⏹️ Arrêter le suivi
            </button>
        </div>
    `;
    
    // Ajouter au début du contenu de Tab 3
    tabContent.insertBefore(suiviDiv, tabContent.firstChild);
    
    // Scroller vers le suivi
    suiviDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
    
    // Démarrer la récupération des logs
    demarrerRecuperationLogs(calculId);
}

/**
 * Récupérer les logs du calcul en temps réel
 */
let intervalsLogs = {};

function demarrerRecuperationLogs(calculId) {
    console.log(`📡 Démarrage de la récupération des logs pour ${calculId}`);
    
    // Nettoyer l'ancien interval s'il existe
    if (intervalsLogs[calculId]) {
        clearInterval(intervalsLogs[calculId]);
    }
    
    // Récupérer les logs toutes les 2 secondes
    intervalsLogs[calculId] = setInterval(async () => {
        try {
            const response = await fetch(`http://localhost:5007/api/etat_calcul/${calculId}`);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            const data = await response.json();
            
            // Mettre à jour les logs
            const logsDiv = document.getElementById(`logs_${calculId}`);
            if (logsDiv) {
                if (data.logs) {
                    logsDiv.innerHTML = `<div style="color: #00ff00;">${data.logs}</div>`;
                    // Auto-scroll vers le bas
                    logsDiv.scrollTop = logsDiv.scrollHeight;
                }
            } else {
                console.warn(`⚠️ Zone de logs introuvable: logs_${calculId}`);
            }
            
            // Mettre à jour le statut
            const statutDiv = document.getElementById(`statut_${calculId}`);
            if (statutDiv) {
                if (data.statut === 'termine') {
                    statutDiv.textContent = '✅ Terminé';
                    statutDiv.style.background = '#4caf50';
                    clearInterval(intervalsLogs[calculId]);
                } else if (data.statut === 'erreur') {
                    statutDiv.textContent = '❌ Erreur';
                    statutDiv.style.background = '#f44336';
                    clearInterval(intervalsLogs[calculId]);
                } else {
                    statutDiv.textContent = '⏳ En cours...';
                    statutDiv.style.background = '#ffa726';
                }
            } else {
                console.warn(`⚠️ Zone de statut introuvable: statut_${calculId}`);
            }
            
        } catch (error) {
            console.error(`❌ Erreur récupération logs:`, error);
        }
    }, 2000);
}

/**
 * Actualiser manuellement le suivi
 */
async function actualiserSuiviCalcul(calculId) {
    console.log(`🔄 Actualisation manuelle du suivi ${calculId}`);
    
    try {
        const response = await fetch(`http://localhost:5007/api/etat_calcul/${calculId}`);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        const data = await response.json();
        
        const logsDiv = document.getElementById(`logs_${calculId}`);
        if (logsDiv) {
            if (data.logs) {
                logsDiv.innerHTML = `<div style="color: #00ff00;">${data.logs}</div>`;
                logsDiv.scrollTop = logsDiv.scrollHeight;
            }
        } else {
            console.warn(`⚠️ Zone de logs introuvable: logs_${calculId}`);
        }
        
        console.log('✅ Suivi actualisé');
    } catch (error) {
        console.error('❌ Erreur actualisation:', error);
        alert(`❌ Erreur lors de l'actualisation: ${error.message}`);
    }
}

/**
 * Arrêter le suivi (ne pas arrêter le calcul, juste arrêter de récupérer les logs)
 */
function arreterSuiviCalcul(calculId) {
    console.log(`⏹️ Arrêt du suivi ${calculId}`);
    
    if (intervalsLogs[calculId]) {
        clearInterval(intervalsLogs[calculId]);
        delete intervalsLogs[calculId];
    }
    
    const suiviDiv = document.getElementById(`suivi_${calculId}`);
    if (suiviDiv) {
        suiviDiv.style.opacity = '0.6';
        const statutDiv = document.getElementById(`statut_${calculId}`);
        if (statutDiv) {
            if (statutDiv.textContent.includes('En cours')) {
                statutDiv.textContent = '⏸️ Suivi arrêté';
                statutDiv.style.background = '#9e9e9e';
            }
        } else {
            console.warn(`⚠️ Zone de statut introuvable: statut_${calculId}`);
        }
    } else {
        console.warn(`⚠️ Zone de suivi introuvable: suivi_${calculId}`);
    }
}

console.log('✅ Script workflow calcul chargé');


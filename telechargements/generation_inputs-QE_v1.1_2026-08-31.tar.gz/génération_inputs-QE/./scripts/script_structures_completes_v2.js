// ═══════════════════════════════════════════════════════════════════════════
// STRUCTURE CRISTALLINE COMPLÈTE - AVEC PARAMÈTRES INTERNES
// Affiche les angles, b/a, c/a, et paramètres internes pour chaque structure
// ═══════════════════════════════════════════════════════════════════════════

/**
 * BASE DE DONNÉES COMPLÈTE DES STRUCTURES CRISTALLINES
 * Avec angles, paramètres réduits, et paramètres internes
 */
const STRUCTURES_CRISTALLINES_COMPLETE = {
    '1': {
        name: 'Cubique Simple (SC)',
        angles: { alpha: 90, beta: 90, gamma: 90 },
        params: [
            { id: 'a', label: 'a (Å)', hint: 'Paramètre de maille' }
        ],
        parametres_internes: []
    },
    '2': {
        name: 'Cubique Faces Centrées (FCC)',
        angles: { alpha: 90, beta: 90, gamma: 90 },
        params: [
            { id: 'a', label: 'a (Å)', hint: 'Paramètre de maille' }
        ],
        parametres_internes: []
    },
    '3': {
        name: 'Cubique Centré (BCC)',
        angles: { alpha: 90, beta: 90, gamma: 90 },
        params: [
            { id: 'a', label: 'a (Å)', hint: 'Paramètre de maille' }
        ],
        parametres_internes: []
    },
    '4': {
        name: 'Hexagonal',
        angles: { alpha: 90, beta: 90, gamma: 120 },
        params: [
            { id: 'a', label: 'a (Å)', hint: 'Paramètre dans le plan' },
            { id: 'ca_ratio', label: 'c/a', hint: 'Ratio hauteur/base' }
        ],
        parametres_internes: [
            { id: 'z_u', label: 'Position z de l\'atome U', default: 0.5, hint: 'Position interne (0 à 1)' }
        ]
    },
    '5': {
        name: 'Rhomboédrique (Trigonal)',
        angles: { alpha: 'α', beta: 'α', gamma: 'α' },
        params: [
            { id: 'a', label: 'a (Å)', hint: 'Paramètre de maille' },
            { id: 'cos_alpha', label: 'cos(α)', hint: 'Cosinus de l\'angle' }
        ],
        parametres_internes: [
            { id: 'z_u', label: 'Position z de l\'atome U', default: 0.5, hint: 'Position interne (0 à 1)' }
        ]
    },
    '6': {
        name: 'Tétragonal Simple',
        angles: { alpha: 90, beta: 90, gamma: 90 },
        params: [
            { id: 'a', label: 'a (Å)', hint: 'Paramètre dans le plan' },
            { id: 'ca_ratio', label: 'c/a', hint: 'Ratio hauteur/base' }
        ],
        parametres_internes: []
    },
    '7': {
        name: 'Tétragonal Centré (I)',
        angles: { alpha: 90, beta: 90, gamma: 90 },
        params: [
            { id: 'a', label: 'a (Å)', hint: 'Paramètre dans le plan' },
            { id: 'ca_ratio', label: 'c/a', hint: 'Ratio hauteur/base' }
        ],
        parametres_internes: []
    },
    '8': {
        name: 'Orthorhombique Simple (P)',
        angles: { alpha: 90, beta: 90, gamma: 90 },
        params: [
            { id: 'a', label: 'a (Å)', hint: 'Paramètre en x' },
            { id: 'ba_ratio', label: 'b/a', hint: 'Ratio y/x' },
            { id: 'ca_ratio', label: 'c/a', hint: 'Ratio z/x' }
        ],
        parametres_internes: []
    },
    '9': {
        name: 'Orthorhombique Centré (C)',
        angles: { alpha: 90, beta: 90, gamma: 90 },
        params: [
            { id: 'a', label: 'a (Å)', hint: 'Paramètre en x' },
            { id: 'ba_ratio', label: 'b/a', hint: 'Ratio y/x' },
            { id: 'ca_ratio', label: 'c/a', hint: 'Ratio z/x' }
        ],
        parametres_internes: []
    },
    '10': {
        name: 'Orthorhombique Faces Centrées (F)',
        angles: { alpha: 90, beta: 90, gamma: 90 },
        params: [
            { id: 'a', label: 'a (Å)', hint: 'Paramètre en x' },
            { id: 'ba_ratio', label: 'b/a', hint: 'Ratio y/x' },
            { id: 'ca_ratio', label: 'c/a', hint: 'Ratio z/x' }
        ],
        parametres_internes: []
    },
    '11': {
        name: 'Orthorhombique Centré (I)',
        angles: { alpha: 90, beta: 90, gamma: 90 },
        params: [
            { id: 'a', label: 'a (Å)', hint: 'Paramètre en x' },
            { id: 'ba_ratio', label: 'b/a', hint: 'Ratio y/x' },
            { id: 'ca_ratio', label: 'c/a', hint: 'Ratio z/x' }
        ],
        parametres_internes: []
    },
    '12': {
        name: 'Monoclinique Simple (P)',
        angles: { alpha: 90, beta: 'β ≠ 90°', gamma: 90 },
        params: [
            { id: 'a', label: 'a (Å)', hint: 'Paramètre en x' },
            { id: 'ba_ratio', label: 'b/a', hint: 'Ratio y/x' },
            { id: 'ca_ratio', label: 'c/a', hint: 'Ratio z/x' },
            { id: 'beta', label: 'β (°)', hint: 'Angle entre a et c' }
        ],
        parametres_internes: [
            { id: 'z_u', label: 'Position z de l\'atome U', default: 0.5, hint: 'Position interne (0 à 1)' }
        ]
    },
    '13': {
        name: 'Monoclinique Centré (I)',
        angles: { alpha: 90, beta: 'β ≠ 90°', gamma: 90 },
        params: [
            { id: 'a', label: 'a (Å)', hint: 'Paramètre en x' },
            { id: 'ba_ratio', label: 'b/a', hint: 'Ratio y/x' },
            { id: 'ca_ratio', label: 'c/a', hint: 'Ratio z/x' },
            { id: 'beta', label: 'β (°)', hint: 'Angle entre a et c' }
        ],
        parametres_internes: []
    },
    '14': {
        name: 'Triclinique (P)',
        angles: { alpha: 'α ≠ 90°', beta: 'β ≠ 90°', gamma: 'γ ≠ 90°' },
        params: [
            { id: 'a', label: 'a (Å)', hint: 'Paramètre en x' },
            { id: 'ba_ratio', label: 'b/a', hint: 'Ratio y/x' },
            { id: 'ca_ratio', label: 'c/a', hint: 'Ratio z/x' },
            { id: 'alpha', label: 'α (°)', hint: 'Angle entre b et c' },
            { id: 'beta', label: 'β (°)', hint: 'Angle entre a et c' },
            { id: 'gamma', label: 'γ (°)', hint: 'Angle entre a et b' }
        ],
        parametres_internes: []
    }
};

/**
 * Afficher les paramètres cristallins avec angles et paramètres internes
 */
function afficherParametresCristallins() {
    const ibrav = document.getElementById('ibrav')?.value;
    const container = document.getElementById('parametres_cristallins');
    
    if (!container || !ibrav) return;
    
    const struct = STRUCTURES_CRISTALLINES_COMPLETE[ibrav];
    if (!struct) return;
    
    let html = `
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
            <!-- Angles -->
            <div style="padding: 15px; background: #e3f2fd; border-radius: 8px; border-left: 4px solid #2196f3;">
                <h4 style="color: #0c5460; margin: 0 0 10px 0;">📐 Angles</h4>
                <div style="font-size: 0.95em; line-height: 1.8; color: #333;">
                    <div>α = ${struct.angles.alpha}°</div>
                    <div>β = ${struct.angles.beta}°</div>
                    <div>γ = ${struct.angles.gamma}°</div>
                </div>
            </div>
            
            <!-- Type de Bravais -->
            <div style="padding: 15px; background: #f3e5f5; border-radius: 8px; border-left: 4px solid #9c27b0;">
                <h4 style="color: #6a1b9a; margin: 0 0 10px 0;">🔷 Structure</h4>
                <div style="font-size: 0.95em; color: #333;">
                    <strong>${struct.name}</strong>
                </div>
            </div>
        </div>
        
        <!-- Paramètres de maille -->
        <div style="margin-bottom: 20px;">
            <h4 style="color: #0c5460; margin-bottom: 10px;">📏 Paramètres de Maille</h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px;">
    `;
    
    struct.params.forEach((param, idx) => {
        let defaultVal = '';
        if (param.id === 'ca_ratio' || param.id === 'ba_ratio') {
            defaultVal = '1.0';
        }
        
        html += `
            <div class="form-group">
                <label style="font-weight: bold; color: #0c5460; display: block; margin-bottom: 5px; font-size: 0.95em;">
                    ${param.label}
                </label>
                <input type="number" id="param_${param.id}" placeholder="${defaultVal}" step="0.001"
                       style="width: 100%; padding: 10px; border: 1px solid #2196f3; border-radius: 4px;">
                <small style="color: #666; margin-top: 3px; display: block; font-size: 0.85em;">${param.hint}</small>
            </div>
        `;
    });
    
    html += `</div>`;
    
    // Paramètres internes si présents
    if (struct.parametres_internes && struct.parametres_internes.length > 0) {
        html += `
            <div style="margin-top: 20px; padding-top: 20px; border-top: 2px solid #2196f3;">
                <h4 style="color: #0c5460; margin-bottom: 10px;">⚛️ Paramètres Internes de la Maille</h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px;">
        `;
        
        struct.parametres_internes.forEach((param, idx) => {
            html += `
                <div class="form-group">
                    <label style="font-weight: bold; color: #1565c0; display: block; margin-bottom: 5px; font-size: 0.95em;">
                        ${param.label}
                    </label>
                    <input type="number" id="param_internal_${param.id}" placeholder="${param.default}" 
                           min="0" max="1" step="0.001"
                           style="width: 100%; padding: 10px; border: 1px solid #1565c0; border-radius: 4px;">
                    <small style="color: #666; margin-top: 3px; display: block; font-size: 0.85em;">${param.hint}</small>
                </div>
            `;
        });
        
        html += `</div></div>`;
    }
    
    container.innerHTML = html;
    
    console.log(`✅ Paramètres cristallins pour ${struct.name}`);
}

console.log('✅ Script structures cristallines complètes chargé');








// ═══════════════════════════════════════════════════════════════════════════
// WORKFLOW INTELLIGENT DE CORRECTION D'ERREURS
// ═══════════════════════════════════════════════════════════════════════════
// 
// Ce script gère le flux : Erreur détectée → Éditer avec recommandations → Relancer
//
// Fonctionnalités:
// 1. Analyse des erreurs QE et génération de recommandations
// 2. Navigation vers l'onglet Génération avec input chargé
// 3. Affichage des recommandations de correction
// 4. Bouton de retour vers l'onglet Calculs pour relancer
// ═══════════════════════════════════════════════════════════════════════════

const API_BASE_WORKFLOW = window.API_BASE || 'http://localhost:5007';

// Variable pour stocker le contexte du calcul en cours de correction
let contexteCorrection = {
    materiau: null,
    fichierInput: null,
    fichierOutput: null,
    typeCalcul: null,
    erreurDetectee: null,
    recommandations: []
};

// ═══════════════════════════════════════════════════════════════════════════
// 1. ANALYSE DES ERREURS QUANTUM ESPRESSO
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Catalogue des erreurs QE connues avec leurs solutions
 */
const CATALOGUE_ERREURS_QE = {
    // Erreurs de namelist
    'bad line in namelist': {
        type: 'namelist',
        titre: 'Erreur de syntaxe dans le fichier input',
        solutions: [
            'Vérifiez que tous les paramètres sont valides pour Quantum ESPRESSO',
            'Supprimez les paramètres inconnus (comme xc_type, input_dft si pas nécessaire)',
            'Vérifiez les virgules et les guillemets',
            'Assurez-vous que chaque namelist se termine par /'
        ]
    },
    'xc_type': {
        type: 'parametre_invalide',
        titre: 'Paramètre xc_type invalide',
        solutions: [
            '❌ Le paramètre "xc_type" n\'existe PAS dans Quantum ESPRESSO',
            '✅ Le fonctionnel d\'échange-corrélation est défini par le pseudopotentiel',
            '💡 Si vous utilisez des pseudos PBE, le calcul sera automatiquement PBE',
            '🔧 Supprimez simplement la ligne "xc_type = ..." de votre input'
        ]
    },
    'input_dft': {
        type: 'info',
        titre: 'Paramètre input_dft',
        solutions: [
            'input_dft permet de forcer un fonctionnel différent du pseudo',
            'Valeurs courantes: "pbe", "pbesol", "lda", "blyp"',
            'Attention: doit être compatible avec vos pseudopotentiels'
        ]
    },
    'pseudo not found': {
        type: 'fichier_manquant',
        titre: 'Pseudopotentiel introuvable',
        solutions: [
            'Vérifiez que le fichier .UPF existe dans pseudo_dir',
            'Vérifiez l\'orthographe exacte du nom de fichier',
            'Téléchargez le pseudo depuis https://www.quantum-espresso.org/pseudopotentials/',
            'Utilisez l\'onglet "Pseudos" pour générer ou télécharger'
        ]
    },
    'wrong atomic coordinates': {
        type: 'structure',
        titre: 'Coordonnées atomiques invalides',
        solutions: [
            'Vérifiez que nat correspond au nombre de lignes ATOMIC_POSITIONS',
            'Vérifiez que ntyp correspond au nombre d\'espèces dans ATOMIC_SPECIES',
            'Les coordonnées doivent être cohérentes avec le format (crystal, angstrom, bohr)'
        ]
    },
    'charge is wrong': {
        type: 'electrons',
        titre: 'Nombre d\'électrons incorrect',
        solutions: [
            'Vérifiez la cohérence entre les pseudos et les atomes',
            'Pour les systèmes chargés, utilisez tot_charge',
            'Vérifiez que les pseudos correspondent aux bons éléments'
        ]
    },
    'k-points': {
        type: 'kpoints',
        titre: 'Problème avec les points k',
        solutions: [
            'Utilisez une grille k automatique: K_POINTS {automatic}\\n  6 6 6  1 1 1',
            'Pour les molécules, utilisez: K_POINTS {gamma}',
            'Augmentez la densité de k-points pour une meilleure précision'
        ]
    },
    'convergence not achieved': {
        type: 'convergence',
        titre: 'La convergence SCF n\'a pas été atteinte',
        solutions: [
            'Diminuez mixing_beta (essayez 0.2 ou 0.1)',
            'Augmentez electron_maxstep (200 ou plus)',
            'Utilisez mixing_mode = "local-TF"',
            'Vérifiez que la structure initiale est raisonnable'
        ]
    },
    'too many bands': {
        type: 'bandes',
        titre: 'Trop de bandes demandées',
        solutions: [
            'Réduisez nbnd ou laissez QE le calculer automatiquement',
            'nbnd doit être ≥ nombre d\'électrons / 2'
        ]
    },
    'fft dimensions': {
        type: 'memoire',
        titre: 'Problème de dimensions FFT',
        solutions: [
            'Réduisez ecutwfc ou ecutrho',
            'Augmentez la mémoire disponible',
            'Utilisez plus de processeurs MPI'
        ]
    },
    'not enough memory': {
        type: 'memoire',
        titre: 'Mémoire insuffisante',
        solutions: [
            'Réduisez le cutoff ecutwfc',
            'Réduisez la grille de k-points',
            'Utilisez plus de processeurs pour distribuer la mémoire'
        ]
    },
    'stopping': {
        type: 'arret',
        titre: 'Calcul interrompu',
        solutions: [
            'Consultez les lignes précédant "stopping" pour identifier l\'erreur',
            'Vérifiez la syntaxe complète du fichier input'
        ]
    }
};

/**
 * Analyse une erreur et retourne les recommandations
 */
function analyserErreurQE(contenuOutput) {
    const erreurs = [];
    const contenuLower = contenuOutput.toLowerCase();
    
    // Parcourir le catalogue pour trouver les erreurs correspondantes
    for (const [pattern, info] of Object.entries(CATALOGUE_ERREURS_QE)) {
        if (contenuLower.includes(pattern.toLowerCase())) {
            erreurs.push({
                pattern: pattern,
                ...info
            });
        }
    }
    
    // Extraire le message d'erreur exact
    const lignesErreur = [];
    const lignes = contenuOutput.split('\n');
    for (let i = 0; i < lignes.length; i++) {
        const ligne = lignes[i];
        if (ligne.includes('Error') || ligne.includes('error') || 
            ligne.includes('bad line') || ligne.includes('%%%%%%')) {
            // Prendre quelques lignes de contexte
            for (let j = Math.max(0, i-1); j <= Math.min(lignes.length-1, i+2); j++) {
                if (!lignesErreur.includes(lignes[j]) && lignes[j].trim()) {
                    lignesErreur.push(lignes[j]);
                }
            }
        }
    }
    
    return {
        erreurs: erreurs,
        messageExact: lignesErreur.join('\n'),
        nombreErreurs: erreurs.length
    };
}

// ═══════════════════════════════════════════════════════════════════════════
// 2. NAVIGATION VERS L'ONGLET GÉNÉRATION AVEC RECOMMANDATIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Ouvre l'onglet Génération avec le fichier input chargé et les recommandations
 * @param {string} materiau - Nom du matériau
 * @param {string} fichierInput - Chemin du fichier input
 * @param {string} fichierOutput - Chemin du fichier output (pour analyse d'erreur)
 * @param {string} typeCalcul - Type de calcul (vcrelax, scf, etc.)
 */
async function ouvrirEditeurAvecCorrections(materiau, fichierInput, fichierOutput, typeCalcul) {
    console.log('🔧 Ouverture de l\'éditeur avec corrections...');
    console.log(`   Matériau: ${materiau}`);
    console.log(`   Input: ${fichierInput}`);
    console.log(`   Output: ${fichierOutput}`);
    
    // Sauvegarder le contexte
    contexteCorrection = {
        materiau: materiau,
        fichierInput: fichierInput,
        fichierOutput: fichierOutput,
        typeCalcul: typeCalcul,
        erreurDetectee: null,
        recommandations: []
    };
    
    try {
        // 1. Charger le contenu de l'output pour analyser l'erreur
        let analyseErreur = null;
        if (fichierOutput) {
            const respOutput = await fetch(`${API_BASE_WORKFLOW}/api/executer_commande`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ commande: `cat "${fichierOutput}"` })
            });
            const dataOutput = await respOutput.json();
            if (dataOutput.success && dataOutput.stdout) {
                analyseErreur = analyserErreurQE(dataOutput.stdout);
                contexteCorrection.erreurDetectee = analyseErreur;
            }
        }
        
        // 2. Charger le contenu de l'input
        const respInput = await fetch(`${API_BASE_WORKFLOW}/api/executer_commande`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ commande: `cat "${fichierInput}"` })
        });
        const dataInput = await respInput.json();
        
        // 3. Passer à l'onglet Génération (onglet 0)
        if (typeof switchTab === 'function') {
            switchTab(0);
        }
        
        // 4. Attendre que l'onglet soit visible puis charger le contenu
        setTimeout(() => {
            // Charger l'input dans l'éditeur
            const editeur = document.getElementById('qe_input_editor');
            if (editeur && dataInput.success && dataInput.stdout) {
                editeur.value = dataInput.stdout;
            }
            
            // Mettre à jour le champ matériau
            const champMateriau = document.getElementById('materiaux_input');
            if (champMateriau && materiau) {
                champMateriau.value = materiau;
            }
            
            // Afficher le panneau de recommandations
            afficherPanneauRecommandations(analyseErreur, typeCalcul);
            
        }, 300);
        
    } catch (error) {
        console.error('Erreur lors de l\'ouverture de l\'éditeur:', error);
        alert('Erreur: ' + error.message);
    }
}

/**
 * Affiche le panneau de recommandations au-dessus de l'éditeur
 */
function afficherPanneauRecommandations(analyseErreur, typeCalcul) {
    // Supprimer l'ancien panneau s'il existe
    const ancienPanneau = document.getElementById('panneau_recommandations');
    if (ancienPanneau) {
        ancienPanneau.remove();
    }
    
    // Trouver le conteneur de l'éditeur
    const editeurContainer = document.querySelector('#qe_input_editor')?.parentElement;
    if (!editeurContainer) return;
    
    // Créer le panneau de recommandations
    const panneau = document.createElement('div');
    panneau.id = 'panneau_recommandations';
    panneau.style.cssText = `
        background: linear-gradient(135deg, #fef3c7, #fde68a);
        border: 2px solid #f59e0b;
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 4px 15px rgba(245, 158, 11, 0.3);
    `;
    
    let htmlContenu = `
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px;">
            <div>
                <h3 style="margin: 0; color: #92400e; display: flex; align-items: center; gap: 10px;">
                    ⚠️ Erreur détectée - Corrections recommandées
                </h3>
                <p style="margin: 5px 0 0 0; color: #a16207; font-size: 0.9em;">
                    Matériau: <strong>${contexteCorrection.materiau || 'N/A'}</strong> | 
                    Type: <strong>${typeCalcul?.toUpperCase() || 'N/A'}</strong>
                </p>
            </div>
            <button onclick="fermerPanneauRecommandations()" style="
                background: none;
                border: none;
                font-size: 20px;
                cursor: pointer;
                color: #92400e;
                padding: 5px;
            ">✕</button>
        </div>
    `;
    
    // Message d'erreur exact
    if (analyseErreur && analyseErreur.messageExact) {
        htmlContenu += `
            <div style="background: #fee2e2; border: 1px solid #ef4444; border-radius: 8px; padding: 12px; margin-bottom: 15px;">
                <strong style="color: #991b1b;">📋 Message d'erreur:</strong>
                <pre style="margin: 8px 0 0 0; font-family: monospace; font-size: 0.85em; color: #7f1d1d; white-space: pre-wrap; overflow-x: auto;">${analyseErreur.messageExact}</pre>
            </div>
        `;
    }
    
    // Recommandations
    if (analyseErreur && analyseErreur.erreurs.length > 0) {
        htmlContenu += `<div style="display: grid; gap: 12px;">`;
        
        for (const erreur of analyseErreur.erreurs) {
            htmlContenu += `
                <div style="background: white; border-radius: 8px; padding: 15px; border-left: 4px solid #f59e0b;">
                    <h4 style="margin: 0 0 10px 0; color: #92400e;">🔍 ${erreur.titre}</h4>
                    <ul style="margin: 0; padding-left: 20px; color: #78350f;">
                        ${erreur.solutions.map(s => `<li style="margin-bottom: 5px;">${s}</li>`).join('')}
                    </ul>
                </div>
            `;
        }
        
        htmlContenu += `</div>`;
    } else {
        htmlContenu += `
            <div style="background: white; border-radius: 8px; padding: 15px;">
                <p style="margin: 0; color: #78350f;">
                    💡 Vérifiez la syntaxe de votre fichier input et assurez-vous que tous les paramètres sont valides.
                </p>
            </div>
        `;
    }
    
    // Boutons d'action
    htmlContenu += `
        <div style="display: flex; gap: 10px; margin-top: 20px; flex-wrap: wrap;">
            <button onclick="appliquerCorrectionsAuto()" class="btn" style="
                background: linear-gradient(135deg, #10b981, #059669);
                color: white;
                padding: 12px 24px;
                border: none;
                border-radius: 8px;
                font-weight: 600;
                cursor: pointer;
                display: flex;
                align-items: center;
                gap: 8px;
            ">
                🔧 Appliquer corrections automatiques
            </button>
            <button onclick="retournerOngletCalculs()" class="btn" style="
                background: linear-gradient(135deg, #3b82f6, #2563eb);
                color: white;
                padding: 12px 24px;
                border: none;
                border-radius: 8px;
                font-weight: 600;
                cursor: pointer;
                display: flex;
                align-items: center;
                gap: 8px;
            ">
                🚀 Retourner aux Calculs et Relancer
            </button>
            <button onclick="fermerPanneauRecommandations()" class="btn" style="
                background: #6b7280;
                color: white;
                padding: 12px 24px;
                border: none;
                border-radius: 8px;
                cursor: pointer;
            ">
                Fermer
            </button>
        </div>
    `;
    
    panneau.innerHTML = htmlContenu;
    
    // Insérer avant l'éditeur
    editeurContainer.insertBefore(panneau, editeurContainer.firstChild);
    
    // Scroll vers le panneau
    panneau.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/**
 * Ferme le panneau de recommandations
 */
function fermerPanneauRecommandations() {
    const panneau = document.getElementById('panneau_recommandations');
    if (panneau) {
        panneau.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => panneau.remove(), 300);
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// 3. CORRECTIONS AUTOMATIQUES
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Applique des corrections automatiques au fichier input
 */
function appliquerCorrectionsAuto() {
    const editeur = document.getElementById('qe_input_editor');
    if (!editeur) return;
    
    let contenu = editeur.value;
    let modifications = [];
    
    // 1. Supprimer xc_type (erreur courante)
    if (contenu.includes('xc_type')) {
        contenu = contenu.replace(/^\s*xc_type\s*=.*$/gm, '    ! xc_type supprimé (paramètre invalide)');
        modifications.push('Suppression de xc_type (paramètre invalide)');
    }
    
    // 2. Vérifier/ajouter ATOMIC_SPECIES si manquant
    if (!contenu.includes('ATOMIC_SPECIES')) {
        modifications.push('⚠️ ATOMIC_SPECIES manquant - à ajouter manuellement');
    }
    
    // 3. Vérifier/ajouter ATOMIC_POSITIONS si manquant
    if (!contenu.includes('ATOMIC_POSITIONS')) {
        modifications.push('⚠️ ATOMIC_POSITIONS manquant - à ajouter manuellement');
    }
    
    // 4. Vérifier/ajouter K_POINTS si manquant
    if (!contenu.includes('K_POINTS')) {
        modifications.push('⚠️ K_POINTS manquant - à ajouter manuellement');
    }
    
    // 5. Vérifier les sections &IONS et &CELL pour vc-relax
    if (contenu.includes("'vc-relax'") || contenu.includes('"vc-relax"')) {
        if (!contenu.includes('&IONS')) {
            // Ajouter &IONS après &ELECTRONS
            contenu = contenu.replace(
                /(&ELECTRONS[\s\S]*?\/)/,
                `$1\n\n&IONS\n    ion_dynamics = 'bfgs'\n/`
            );
            modifications.push('Ajout de la section &IONS');
        }
        if (!contenu.includes('&CELL')) {
            // Ajouter &CELL après &IONS ou &ELECTRONS
            if (contenu.includes('&IONS')) {
                contenu = contenu.replace(
                    /(&IONS[\s\S]*?\/)/,
                    `$1\n\n&CELL\n    cell_dynamics = 'bfgs'\n    press = 0.0\n/`
                );
            }
            modifications.push('Ajout de la section &CELL');
        }
    }
    
    // 6. Corriger mixing_beta si trop élevé
    const mixingMatch = contenu.match(/mixing_beta\s*=\s*([\d.]+)/);
    if (mixingMatch && parseFloat(mixingMatch[1]) > 0.5) {
        contenu = contenu.replace(/mixing_beta\s*=\s*[\d.]+/, 'mixing_beta = 0.3');
        modifications.push('mixing_beta réduit à 0.3 (était trop élevé)');
    }
    
    // Appliquer les modifications
    editeur.value = contenu;
    
    // Afficher le résumé des modifications
    if (modifications.length > 0) {
        afficherNotificationCorrections(modifications);
    } else {
        alert('Aucune correction automatique applicable. Vérifiez manuellement le fichier.');
    }
}

/**
 * Affiche une notification avec la liste des corrections appliquées
 */
function afficherNotificationCorrections(modifications) {
    const notif = document.createElement('div');
    notif.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #10b981, #059669);
        color: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        z-index: 10001;
        max-width: 400px;
        animation: slideIn 0.3s ease;
    `;
    
    notif.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
            <strong style="font-size: 1.1em;">✅ Corrections appliquées</strong>
            <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; color: white; font-size: 18px; cursor: pointer;">✕</button>
        </div>
        <ul style="margin: 0; padding-left: 20px; font-size: 0.9em;">
            ${modifications.map(m => `<li style="margin-bottom: 5px;">${m}</li>`).join('')}
        </ul>
        <p style="margin: 15px 0 0 0; font-size: 0.85em; opacity: 0.9;">
            💡 Vérifiez le fichier puis cliquez sur "Retourner aux Calculs"
        </p>
    `;
    
    document.body.appendChild(notif);
    
    setTimeout(() => {
        notif.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notif.remove(), 300);
    }, 8000);
}

// ═══════════════════════════════════════════════════════════════════════════
// 4. RETOUR À L'ONGLET CALCULS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Sauvegarde l'input corrigé et retourne à l'onglet Calculs
 */
async function retournerOngletCalculs() {
    const editeur = document.getElementById('qe_input_editor');
    const champMateriau = document.getElementById('materiaux_input');
    
    if (!editeur || !editeur.value.trim()) {
        alert('L\'éditeur est vide. Veuillez charger ou créer un fichier input.');
        return;
    }
    
    const materiau = champMateriau?.value || contexteCorrection.materiau || 'calcul';
    const contenu = editeur.value;
    
    try {
        // 1. Sauvegarder le fichier corrigé
        const response = await fetch(`${API_BASE_WORKFLOW}/api/sauvegarder_input`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contenu: contenu,
                prefix: materiau
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            console.log('✅ Input sauvegardé:', data.filepath);
            
            // 2. Fermer le panneau de recommandations
            fermerPanneauRecommandations();
            
            // 3. Passer à l'onglet Calculs (onglet 2)
            if (typeof switchTab === 'function') {
                switchTab(1);
            }
            
            // 4. Afficher un message de confirmation
            setTimeout(() => {
                afficherBandeauPretARelancer(materiau, data.filepath);
            }, 300);
            
        } else {
            alert('Erreur lors de la sauvegarde: ' + (data.message || 'Erreur inconnue'));
        }
        
    } catch (error) {
        console.error('Erreur:', error);
        alert('Erreur: ' + error.message);
    }
}

/**
 * Affiche un bandeau indiquant que le calcul est prêt à être relancé
 */
function afficherBandeauPretARelancer(materiau, filepath) {
    // Supprimer l'ancien bandeau s'il existe
    const ancienBandeau = document.getElementById('bandeau_pret_relancer');
    if (ancienBandeau) ancienBandeau.remove();
    
    const bandeau = document.createElement('div');
    bandeau.id = 'bandeau_pret_relancer';
    bandeau.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background: linear-gradient(135deg, #10b981, #059669);
        color: white;
        padding: 15px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        z-index: 10000;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        animation: slideDown 0.3s ease;
    `;
    
    bandeau.innerHTML = `
        <div style="display: flex; align-items: center; gap: 15px;">
            <span style="font-size: 1.5em;">✅</span>
            <div>
                <strong>Input corrigé et sauvegardé!</strong>
                <div style="font-size: 0.85em; opacity: 0.9;">${materiau} - Prêt à être relancé</div>
            </div>
        </div>
        <div style="display: flex; gap: 10px;">
            <button onclick="lancerCalculCorrige('${materiau}', '${filepath}')" style="
                background: white;
                color: #059669;
                border: none;
                padding: 10px 25px;
                border-radius: 8px;
                font-weight: 700;
                cursor: pointer;
                font-size: 1em;
            ">
                🚀 Lancer le Calcul
            </button>
            <button onclick="this.parentElement.parentElement.remove()" style="
                background: rgba(255,255,255,0.2);
                color: white;
                border: none;
                padding: 10px 15px;
                border-radius: 8px;
                cursor: pointer;
            ">✕</button>
        </div>
    `;
    
    document.body.appendChild(bandeau);
    
    // Style pour l'animation
    if (!document.getElementById('style_workflow_erreur')) {
        const style = document.createElement('style');
        style.id = 'style_workflow_erreur';
        style.textContent = `
            @keyframes slideDown {
                from { transform: translateY(-100%); }
                to { transform: translateY(0); }
            }
            @keyframes slideIn {
                from { transform: translateX(400px); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(400px); opacity: 0; }
            }
            @keyframes fadeOut {
                from { opacity: 1; }
                to { opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    }
}

/**
 * Lance le calcul avec le fichier corrigé
 */
async function lancerCalculCorrige(materiau, filepath) {
    // Fermer le bandeau
    const bandeau = document.getElementById('bandeau_pret_relancer');
    if (bandeau) bandeau.remove();
    
    try {
        // Déterminer le type de calcul depuis le contexte ou le fichier
        let typeCalcul = contexteCorrection.typeCalcul || 'scf';
        
        // Lancer le calcul via l'API
        const response = await fetch(`${API_BASE_WORKFLOW}/api/lancer_calcul`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                input_path: filepath,
                output_dir: `/home/hiadsi/Interface-QE_v1/outputs/${materiau}`,
                prefix: materiau
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Afficher notification de succès
            const notif = document.createElement('div');
            notif.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: linear-gradient(135deg, #10b981, #059669);
                color: white;
                padding: 20px 25px;
                border-radius: 12px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                z-index: 10001;
                animation: slideIn 0.3s ease;
            `;
            notif.innerHTML = `
                <strong>🚀 Calcul relancé avec succès!</strong>
                <div style="font-size: 0.9em; margin-top: 8px; opacity: 0.9;">
                    ID: ${data.calcul_id || 'N/A'}<br>
                    Utilisez les boutons "📊 Suivi" pour suivre la progression
                </div>
            `;
            document.body.appendChild(notif);
            setTimeout(() => notif.remove(), 6000);
            
            // Ouvrir le suivi si la fonction existe
            if (typeof ouvrirSuiviCalcul === 'function' && typeCalcul) {
                setTimeout(() => {
                    ouvrirSuiviCalcul(typeCalcul.replace('-', ''));
                }, 1000);
            }
        } else {
            alert('Erreur lors du lancement: ' + (data.message || data.error));
        }
        
    } catch (error) {
        console.error('Erreur:', error);
        alert('Erreur: ' + error.message);
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// 5. INTÉGRATION AVEC LE MODAL DE SUIVI
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Ajoute le bouton "Éditer et Corriger" dans le modal de suivi quand une erreur est détectée
 * Cette fonction doit être appelée depuis le script de suivi
 */
function ajouterBoutonEditerSiErreur(fichierOutput, materiau, typeCalcul) {
    const modal = document.getElementById('modal_suivi_calcul');
    if (!modal) return;
    
    // Vérifier si le bouton existe déjà
    if (document.getElementById('btn_editer_corriger')) return;
    
    // Trouver la barre d'actions du modal
    const barreActions = modal.querySelector('div[style*="padding: 15px 30px"]');
    if (!barreActions) return;
    
    // Chercher le fichier input correspondant
    const fichierInput = fichierOutput.replace('.out', '.in')
        .replace('_vcrelax', '_vc-relax')
        .replace('_vcrelax', '_vc-relax');
    
    // Créer le bouton
    const bouton = document.createElement('button');
    bouton.id = 'btn_editer_corriger';
    bouton.innerHTML = '🔧 Éditer et Corriger';
    bouton.style.cssText = `
        padding: 8px 16px;
        background: linear-gradient(135deg, #f59e0b, #d97706);
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 600;
        transition: transform 0.2s;
        margin-left: 10px;
    `;
    bouton.onmouseover = () => bouton.style.transform = 'scale(1.05)';
    bouton.onmouseout = () => bouton.style.transform = 'scale(1)';
    bouton.onclick = () => {
        // Fermer le modal de suivi
        if (typeof fermerSuiviCalcul === 'function') {
            fermerSuiviCalcul();
        }
        // Ouvrir l'éditeur avec corrections
        ouvrirEditeurAvecCorrections(materiau, fichierInput, fichierOutput, typeCalcul);
    };
    
    // Ajouter le bouton à la barre d'actions
    barreActions.insertBefore(bouton, barreActions.querySelector('div[style*="flex: 1"]'));
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORT GLOBAL
// ═══════════════════════════════════════════════════════════════════════════

window.ouvrirEditeurAvecCorrections = ouvrirEditeurAvecCorrections;
window.appliquerCorrectionsAuto = appliquerCorrectionsAuto;
window.retournerOngletCalculs = retournerOngletCalculs;
window.lancerCalculCorrige = lancerCalculCorrige;
window.ajouterBoutonEditerSiErreur = ajouterBoutonEditerSiErreur;
window.fermerPanneauRecommandations = fermerPanneauRecommandations;
window.analyserErreurQE = analyserErreurQE;

console.log('✅ Script workflow_erreur.js chargé - Gestion intelligente des erreurs activée');

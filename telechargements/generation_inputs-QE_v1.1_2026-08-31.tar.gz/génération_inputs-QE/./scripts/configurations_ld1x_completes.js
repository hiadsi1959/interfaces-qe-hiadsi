// ═══════════════════════════════════════════════════════════════════════════════
// CONFIGURATIONS COMPLÈTES POUR LD1.X - TOUS LES ÉLÉMENTS
// ═══════════════════════════════════════════════════════════════════════════════

// Configuration électronique de TOUS les éléments (1-118)
const CONFIGURATIONS_ELECTRONIQUES = {
    // Période 1
    'H':  { config: '1s1', valence: 1, core: '' },
    'He': { config: '1s2', valence: 2, core: '' },
    
    // Période 2
    'Li': { config: '[He] 2s1', valence: 1, core: '1s2' },
    'Be': { config: '[He] 2s2', valence: 2, core: '1s2' },
    'B':  { config: '[He] 2s2 2p1', valence: 3, core: '1s2' },
    'C':  { config: '[He] 2s2 2p2', valence: 4, core: '1s2' },
    'N':  { config: '[He] 2s2 2p3', valence: 5, core: '1s2' },
    'O':  { config: '[He] 2s2 2p4', valence: 6, core: '1s2' },
    'F':  { config: '[He] 2s2 2p5', valence: 7, core: '1s2' },
    'Ne': { config: '[He] 2s2 2p6', valence: 8, core: '1s2' },
    
    // Période 3
    'Na': { config: '[Ne] 3s1', valence: 1, core: '1s2 2s2 2p6' },
    'Mg': { config: '[Ne] 3s2', valence: 2, core: '1s2 2s2 2p6' },
    'Al': { config: '[Ne] 3s2 3p1', valence: 3, core: '1s2 2s2 2p6' },
    'Si': { config: '[Ne] 3s2 3p2', valence: 4, core: '1s2 2s2 2p6' },
    'P':  { config: '[Ne] 3s2 3p3', valence: 5, core: '1s2 2s2 2p6' },
    'S':  { config: '[Ne] 3s2 3p4', valence: 6, core: '1s2 2s2 2p6' },
    'Cl': { config: '[Ne] 3s2 3p5', valence: 7, core: '1s2 2s2 2p6' },
    'Ar': { config: '[Ne] 3s2 3p6', valence: 8, core: '1s2 2s2 2p6' },
    
    // Période 4
    'K':  { config: '[Ar] 4s1', valence: 1, core: '[Ne] 3s2 3p6' },
    'Ca': { config: '[Ar] 4s2', valence: 2, core: '[Ne] 3s2 3p6' },
    'Sc': { config: '[Ar] 3d1 4s2', valence: 3, core: '[Ne] 3s2 3p6' },
    'Ti': { config: '[Ar] 3d2 4s2', valence: 4, core: '[Ne] 3s2 3p6' },
    'V':  { config: '[Ar] 3d3 4s2', valence: 5, core: '[Ne] 3s2 3p6' },
    'Cr': { config: '[Ar] 3d5 4s1', valence: 6, core: '[Ne] 3s2 3p6' },
    'Mn': { config: '[Ar] 3d5 4s2', valence: 7, core: '[Ne] 3s2 3p6' },
    'Fe': { config: '[Ar] 3d6 4s2', valence: 8, core: '[Ne] 3s2 3p6' },
    'Co': { config: '[Ar] 3d7 4s2', valence: 9, core: '[Ne] 3s2 3p6' },
    'Ni': { config: '[Ar] 3d8 4s2', valence: 10, core: '[Ne] 3s2 3p6' },
    'Cu': { config: '[Ar] 3d10 4s1', valence: 11, core: '[Ne] 3s2 3p6' },
    'Zn': { config: '[Ar] 3d10 4s2', valence: 12, core: '[Ne] 3s2 3p6' },
    'Ga': { config: '[Ar] 3d10 4s2 4p1', valence: 3, core: '[Ar] 3d10' },
    'Ge': { config: '[Ar] 3d10 4s2 4p2', valence: 4, core: '[Ar] 3d10' },
    'As': { config: '[Ar] 3d10 4s2 4p3', valence: 5, core: '[Ar] 3d10' },
    'Se': { config: '[Ar] 3d10 4s2 4p4', valence: 6, core: '[Ar] 3d10' },
    'Br': { config: '[Ar] 3d10 4s2 4p5', valence: 7, core: '[Ar] 3d10' },
    'Kr': { config: '[Ar] 3d10 4s2 4p6', valence: 8, core: '[Ar] 3d10' },
    
    // Période 5 (éléments courants)
    'Rb': { config: '[Kr] 5s1', valence: 1, core: '[Kr]' },
    'Sr': { config: '[Kr] 5s2', valence: 2, core: '[Kr]' },
    'Y':  { config: '[Kr] 4d1 5s2', valence: 3, core: '[Kr]' },
    'Zr': { config: '[Kr] 4d2 5s2', valence: 4, core: '[Kr]' },
    'Nb': { config: '[Kr] 4d4 5s1', valence: 5, core: '[Kr]' },
    'Mo': { config: '[Kr] 4d5 5s1', valence: 6, core: '[Kr]' },
    'Tc': { config: '[Kr] 4d5 5s2', valence: 7, core: '[Kr]' },
    'Ru': { config: '[Kr] 4d7 5s1', valence: 8, core: '[Kr]' },
    'Rh': { config: '[Kr] 4d8 5s1', valence: 9, core: '[Kr]' },
    'Pd': { config: '[Kr] 4d10', valence: 10, core: '[Kr]' },
    'Ag': { config: '[Kr] 4d10 5s1', valence: 11, core: '[Kr]' },
    'Cd': { config: '[Kr] 4d10 5s2', valence: 12, core: '[Kr]' },
    'In': { config: '[Kr] 4d10 5s2 5p1', valence: 3, core: '[Kr] 4d10' },
    'Sn': { config: '[Kr] 4d10 5s2 5p2', valence: 4, core: '[Kr] 4d10' },
    'Sb': { config: '[Kr] 4d10 5s2 5p3', valence: 5, core: '[Kr] 4d10' },
    'Te': { config: '[Kr] 4d10 5s2 5p4', valence: 6, core: '[Kr] 4d10' },
    'I':  { config: '[Kr] 4d10 5s2 5p5', valence: 7, core: '[Kr] 4d10' },
    'Xe': { config: '[Kr] 4d10 5s2 5p6', valence: 8, core: '[Kr] 4d10' },
    
    // Période 6 (éléments courants)
    'Cs': { config: '[Xe] 6s1', valence: 1, core: '[Xe]' },
    'Ba': { config: '[Xe] 6s2', valence: 2, core: '[Xe]' },
    'La': { config: '[Xe] 5d1 6s2', valence: 3, core: '[Xe]' },
    
    // Lanthanides
    'Ce': { config: '[Xe] 4f1 5d1 6s2', valence: 4, core: '[Xe]' },
    'Pr': { config: '[Xe] 4f3 6s2', valence: 3, core: '[Xe]' },
    'Nd': { config: '[Xe] 4f4 6s2', valence: 3, core: '[Xe]' },
    'Pm': { config: '[Xe] 4f5 6s2', valence: 3, core: '[Xe]' },
    'Sm': { config: '[Xe] 4f6 6s2', valence: 3, core: '[Xe]' },
    'Eu': { config: '[Xe] 4f7 6s2', valence: 3, core: '[Xe]' },
    'Gd': { config: '[Xe] 4f7 5d1 6s2', valence: 3, core: '[Xe]' },
    'Tb': { config: '[Xe] 4f9 6s2', valence: 3, core: '[Xe]' },
    'Dy': { config: '[Xe] 4f10 6s2', valence: 3, core: '[Xe]' },
    'Ho': { config: '[Xe] 4f11 6s2', valence: 3, core: '[Xe]' },
    'Er': { config: '[Xe] 4f12 6s2', valence: 3, core: '[Xe]' },
    'Tm': { config: '[Xe] 4f13 6s2', valence: 3, core: '[Xe]' },
    'Yb': { config: '[Xe] 4f14 6s2', valence: 3, core: '[Xe]' },
    'Lu': { config: '[Xe] 4f14 5d1 6s2', valence: 3, core: '[Xe] 4f14' },
    
    // Métaux de transition 6
    'Hf': { config: '[Xe] 4f14 5d2 6s2', valence: 4, core: '[Xe] 4f14' },
    'Ta': { config: '[Xe] 4f14 5d3 6s2', valence: 5, core: '[Xe] 4f14' },
    'W':  { config: '[Xe] 4f14 5d4 6s2', valence: 6, core: '[Xe] 4f14' },
    'Re': { config: '[Xe] 4f14 5d5 6s2', valence: 7, core: '[Xe] 4f14' },
    'Os': { config: '[Xe] 4f14 5d6 6s2', valence: 8, core: '[Xe] 4f14' },
    'Ir': { config: '[Xe] 4f14 5d7 6s2', valence: 9, core: '[Xe] 4f14' },
    'Pt': { config: '[Xe] 4f14 5d9 6s1', valence: 10, core: '[Xe] 4f14' },
    'Au': { config: '[Xe] 4f14 5d10 6s1', valence: 11, core: '[Xe] 4f14' },
    'Hg': { config: '[Xe] 4f14 5d10 6s2', valence: 12, core: '[Xe] 4f14' },
    'Tl': { config: '[Xe] 4f14 5d10 6s2 6p1', valence: 3, core: '[Xe] 4f14 5d10' },
    'Pb': { config: '[Xe] 4f14 5d10 6s2 6p2', valence: 4, core: '[Xe] 4f14 5d10' },
    'Bi': { config: '[Xe] 4f14 5d10 6s2 6p3', valence: 5, core: '[Xe] 4f14 5d10' },
    'Po': { config: '[Xe] 4f14 5d10 6s2 6p4', valence: 6, core: '[Xe] 4f14 5d10' },
    'At': { config: '[Xe] 4f14 5d10 6s2 6p5', valence: 7, core: '[Xe] 4f14 5d10' },
    'Rn': { config: '[Xe] 4f14 5d10 6s2 6p6', valence: 8, core: '[Xe] 4f14 5d10' },
    
    // Période 7 (éléments courants)
    'Fr': { config: '[Rn] 7s1', valence: 1, core: '[Rn]' },
    'Ra': { config: '[Rn] 7s2', valence: 2, core: '[Rn]' },
    'Ac': { config: '[Rn] 6d1 7s2', valence: 3, core: '[Rn]' },
    
    // Actinides
    'Th': { config: '[Rn] 6d2 7s2', valence: 4, core: '[Rn]' },
    'Pa': { config: '[Rn] 5f2 6d1 7s2', valence: 5, core: '[Rn]' },
    'U':  { config: '[Rn] 5f3 6d1 7s2', valence: 6, core: '[Rn]' },
    'Np': { config: '[Rn] 5f4 6d1 7s2', valence: 7, core: '[Rn]' },
    'Pu': { config: '[Rn] 5f6 7s2', valence: 8, core: '[Rn]' },
    'Am': { config: '[Rn] 5f7 7s2', valence: 9, core: '[Rn]' },
    'Cm': { config: '[Rn] 5f7 6d1 7s2', valence: 10, core: '[Rn]' }
};

// ═══════════════════════════════════════════════════════════════════════════════
// OPTIONS COMPLÈTES POUR LD1.X
// ════════════════════════���══════════════════════════════════════════════════════

const OPTIONS_LD1X_COMPLETES = {
    // Types de pseudopotentiels
    pseudotype: {
        label: 'Type de pseudopotentiel',
        options: [
            { 
                value: '1', 
                label: 'NC (Norm-Conserving)', 
                description: 'Conserve la norme, très robuste, ecutwfc élevé',
                ecutwfc_min: 60,
                ecutrho_factor: 8
            },
            { 
                value: '2', 
                label: 'USPP (Ultrasoft)', 
                description: 'Plus doux, ecutwfc plus faible, bon compromis',
                ecutwfc_min: 30,
                ecutrho_factor: 8
            },
            { 
                value: '3', 
                label: 'PAW (Projector Augmented Wave)', 
                description: 'Très précis, reconstruction all-electron',
                ecutwfc_min: 40,
                ecutrho_factor: 8
            }
        ],
        default: '2'
    },
    
    // Effets relativistes
    relativistic: {
        label: 'Effets relativistes',
        options: [
            { 
                value: '0', 
                label: 'Non-relativiste', 
                description: 'Pour éléments légers (Z < 20)',
                recommended_for: 'Z < 20'
            },
            { 
                value: '1', 
                label: 'Relativiste scalaire', 
                description: 'Recommandé pour Z > 20, sans spin-orbite',
                recommended_for: 'Z >= 20'
            },
            { 
                value: '2', 
                label: 'Relativiste complet (Dirac)', 
                description: 'Avec couplage spin-orbite, pour éléments lourds',
                recommended_for: 'Z > 50'
            }
        ],
        default: '1'
    },
    
    // Fonctionnelles d'échange-corrélation
    functional: {
        label: 'Fonctionnelle XC',
        options: [
            { 
                value: 'PZ', 
                label: 'PZ (Perdew-Zunger)', 
                description: 'LDA standard, simple et rapide',
                type: 'LDA'
            },
            { 
                value: 'PW', 
                label: 'PW (Perdew-Wang)', 
                description: 'LDA améliorée',
                type: 'LDA'
            },
            { 
                value: 'PBE', 
                label: 'PBE (Perdew-Burke-Ernzerhof)', 
                description: 'GGA standard, très utilisée',
                type: 'GGA'
            },
            { 
                value: 'PBEsol', 
                label: 'PBEsol', 
                description: 'GGA optimisée pour solides',
                type: 'GGA'
            },
            { 
                value: 'BLYP', 
                label: 'BLYP', 
                description: 'GGA alternative (Becke-Lee-Yang-Parr)',
                type: 'GGA'
            },
            { 
                value: 'revPBE', 
                label: 'revPBE', 
                description: 'PBE révisée',
                type: 'GGA'
            },
            { 
                value: 'PBESOL', 
                label: 'PBESOL', 
                description: 'PBE pour solides',
                type: 'GGA'
            }
        ],
        default: 'PBE'
    },
    
    // NLCC (Non-Linear Core Correction)
    nlcc: {
        label: 'NLCC (Non-Linear Core Correction)',
        options: [
            { 
                value: 'false', 
                label: 'Désactivé', 
                description: 'Pas de correction de cœur, pour éléments légers'
            },
            { 
                value: 'true', 
                label: 'Activé', 
                description: 'Recommandé pour métaux de transition et éléments lourds'
            }
        ],
        default: 'true'
    },
    
    // Rayons de coupure
    rcut: {
        label: 'Rayons de coupure par canal (Bohr)',
        description: 'Rayons pour chaque canal orbital (s, p, d, f)',
        canaux: ['s', 'p', 'd', 'f'],
        default: {
            's': '2.0',
            'p': '2.2',
            'd': '2.4',
            'f': '2.6'
        },
        min: '0.5',
        max: '5.0',
        step: '0.1'
    },
    
    // Rayon de coupure local
    rcloc: {
        label: 'Rayon de coupure local (rcloc)',
        description: 'Rayon pour le potentiel local (Bohr)',
        default: '2.0',
        min: '0.5',
        max: '5.0',
        step: '0.1'
    },
    
    // Canal local
    local_channel: {
        label: 'Canal local',
        options: [
            { value: '0', label: 's', description: 'Canal s comme local' },
            { value: '1', label: 'p', description: 'Canal p comme local' },
            { value: '2', label: 'd', description: 'Canal d comme local' },
            { value: '3', label: 'f', description: 'Canal f comme local' },
            { value: '-1', label: 'Auto', description: 'Sélection automatique (recommandé)' }
        ],
        default: '-1'
    },
    
    // Cutoff énergie cinétique
    ecutwfc: {
        label: 'Cutoff énergie cinétique (Ry)',
        description: 'Énergie de coupure pour les fonctions d\'onde',
        default: 60,
        min: 20,
        max: 200,
        step: 10
    },
    
    // Cutoff densité de charge
    ecutrho: {
        label: 'Cutoff densité de charge (Ry)',
        description: 'Énergie de coupure pour la densité (généralement 8 × ecutwfc)',
        default: 480,
        min: 160,
        max: 1600,
        step: 80
    },
    
    // Tests de convergence
    test_convergence: {
        label: 'Tests de convergence',
        description: 'Tester différentes valeurs d\'ecutwfc',
        values: [20, 30, 40, 50, 60, 80, 100, 120, 150, 200],
        default: [40, 60, 80, 100]
    },
    
    // Test des états fantômes
    test_ghost: {
        label: 'Test des états fantômes',
        description: 'Vérifier l\'absence d\'états fantômes (ghost states)',
        default: true
    },
    
    // Test de transférabilité
    test_transferability: {
        label: 'Test de transférabilité',
        description: 'Tester dans différentes configurations électroniques',
        default: true
    },
    
    // Configurations de test
    test_configs: {
        label: 'Configurations de test',
        description: 'Configurations électroniques pour tester la transférabilité',
        options: [
            { value: 'neutral', label: 'Neutre', description: 'Configuration neutre' },
            { value: 'cation', label: 'Cation', description: 'Configuration ionisée +1' },
            { value: 'anion', label: 'Anion', description: 'Configuration ionisée -1' },
            { value: 'excited', label: 'Excitée', description: 'Configuration excitée' }
        ],
        default: ['neutral', 'cation']
    }
};

console.log('✅ Configurations complètes pour ld1.x chargées');
console.log(`✅ ${Object.keys(CONFIGURATIONS_ELECTRONIQUES).length} éléments disponibles`);

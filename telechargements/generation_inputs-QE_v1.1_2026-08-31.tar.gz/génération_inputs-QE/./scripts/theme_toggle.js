/**
 * Bascule thème clair / sombre (localStorage + prefers-color-scheme).
 */
(function () {
    'use strict';

    var STORAGE_KEY = 'GEN_INPUTS_THEME';

    function applyTheme(theme) {
        var t = theme === 'dark' ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', t);
        try { localStorage.setItem(STORAGE_KEY, t); } catch (_eLs) {}
        refreshThemeToggleLabels();
    }

    window.refreshThemeToggleLabels = function refreshThemeToggleLabels() {
        var t = document.documentElement.getAttribute('data-theme') || 'light';
        var btn = document.getElementById('qe_theme_toggle');
        if (!btn) return;
        var isDark = t === 'dark';
        if (typeof window.t === 'function') {
            btn.textContent = isDark ? window.t('theme.light') : window.t('theme.dark');
            btn.title = isDark ? window.t('theme.title_light') : window.t('theme.title_dark');
        } else {
            btn.textContent = isDark ? '☀️ Clair' : '🌙 Sombre';
            btn.title = isDark ? 'Passer en mode clair' : 'Passer en mode sombre';
        }
        btn.setAttribute('aria-pressed', isDark ? 'true' : 'false');
    };

    window.toggleQeTheme = function toggleQeTheme() {
        var cur = document.documentElement.getAttribute('data-theme') || 'light';
        applyTheme(cur === 'dark' ? 'light' : 'dark');
    };

    function initTheme() {
        var saved = null;
        try { saved = localStorage.getItem(STORAGE_KEY); } catch (_eGet) {}
        if (saved === 'dark' || saved === 'light') {
            applyTheme(saved);
            return;
        }
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            applyTheme('dark');
        } else {
            applyTheme('light');
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initTheme);
    } else {
        initTheme();
    }
})();

// ═══════════════════════════════════════════════════════════════════════════
// 5️⃣ TYPE DE CALCUL QE + CHEMINS + BOUTONS
// ═══════════════════════════════════════════════════════════════════════════

console.log('📝 Script section 5 (Type de Calcul + Chemins) chargé');

/** Retire les boutons « Lancer calcul / workflow » restés dans le DOM legacy. */
function __purgeBoutonsLancerCalcul() {
    try {
        var roots = [
            document.getElementById('input_preview_card'),
            document.getElementById('section_5_type_calcul_chemins'),
            document.getElementById('gen_input_preview_panel'),
            document.getElementById('tab1_restructured'),
            document.getElementById('subsection_gestion')
        ];
        roots.forEach(function (root) {
            if (!root) return;
            root.querySelectorAll('button').forEach(function (btn) {
                var t = String(btn.textContent || '').replace(/\s+/g, ' ').trim();
                var oc = String(btn.getAttribute('onclick') || '');
                var isLaunch = /lancer\s*(le\s*)?(test\s*)?(de\s*)?calcul/i.test(t)
                    || /LANCER\s*(TEST\s*)?(DE\s*)?CALCUL/i.test(t)
                    || /Workflow Complet/i.test(t)
                    || /Sauvegarder et Lancer/i.test(t)
                    || oc.indexOf('lancerCalculInputsTab') >= 0
                    || oc.indexOf('lancerWorkflowComplet') >= 0
                    || oc.indexOf('workflowCompletCalcul') >= 0
                    || oc.indexOf('lancerCalculDepuisEditeur') >= 0
                    || btn.id === 'btn_lancer_calcul'
                    || btn.classList.contains('qe-action-btn--launch');
                if (isLaunch) btn.remove();
            });
        });
    } catch (_ePurge) {}
}

function __planifierCreationSection5() {
    __purgeBoutonsLancerCalcul();
    if (document.getElementById('section_5_type_calcul_chemins')) return;
    if (!document.getElementById('tab1_restructured') &&
            !document.getElementById('section_3_especes')) {
        return;
    }
    creerSection5TypeCalculChemins();
}

// Attendre que Tab 1 restructuré + formulaire soient prêts
window.addEventListener('load', function() {
    console.log('🔧 Window loaded, création section 5...');
    __purgeBoutonsLancerCalcul();
    setTimeout(__planifierCreationSection5, 400);
    setTimeout(__planifierCreationSection5, 1200);
    setTimeout(__purgeBoutonsLancerCalcul, 2000);
});

document.addEventListener('tab1Restructured', function () {
    console.log('📢 tab1Restructured → création section 5');
    __purgeBoutonsLancerCalcul();
    setTimeout(__planifierCreationSection5, 100);
});

window.__purgeBoutonsLancerCalcul = __purgeBoutonsLancerCalcul;

function creerSection5TypeCalculChemins(opts) {
    opts = opts || {};
    console.log('📝 Création section 5 (Type Calcul + Chemins)...');

    var existing5 = document.getElementById('section_5_type_calcul_chemins');
    if (existing5 && !opts.force) {
        // Nettoyage rétrocompat : retirer « LANCER LE CALCUL » d’un ancien HTML en cache
        try {
            existing5.querySelectorAll('#btn_lancer_calcul, .qe-action-btn--launch').forEach(function (el) {
                el.remove();
            });
        } catch (_eRm) {}
        console.log('⚠️ Section 5 déjà créée');
        return;
    }
    if (existing5) existing5.remove();
    
    function _t5(k) { return (typeof window.t === 'function') ? window.t(k) : k; }
    
    // Vérifier si existe déjà — géré ci-dessus
    if (false && document.getElementById('section_5_type_calcul_chemins')) {
        console.log('⚠️ Section 5 déjà créée');
        return;
    }
    
    // Chercher où insérer: EN DERNIER, après section_positions_atomiques OU après section_3_especes
    let insertAfter = document.getElementById('section_positions_atomiques');
    
    if (!insertAfter) {
        console.log('⚠️ Positions pas encore créées, insertion après espèces');
        insertAfter = document.getElementById('section_3_especes');
    }
    
    if (!insertAfter) {
        console.error('❌ Aucune section de référence trouvée!');
        return;
    }
    
    console.log('✅ Insertion après:', insertAfter.id);
    
    // Récupérer chemins depuis localStorage
    const cfg = window.QE_CONFIG || {};
    const pathInputs  = cfg.INPUTS_DIRECT_DIR || cfg.INPUTS_GENERES_DIR || localStorage.getItem('qe_path_inputs')  || localStorage.getItem('path_inputs')  || (typeof window.qeInputsDirectRoot === 'function' ? window.qeInputsDirectRoot() : '');
    const pathOutputs = cfg.OUTPUTS_DIR        || localStorage.getItem('qe_path_outputs') || localStorage.getItem('path_outputs') || ((typeof window.qeProjectRoot === 'function' && window.qeProjectRoot()) ? window.qeProjectRoot() + '/outputs' : '');
    const pathPseudos = cfg.PSEUDO_DIR         || localStorage.getItem('qe_path_pseudos') || localStorage.getItem('path_pseudos') || ((typeof window.qeProjectRoot === 'function' && window.qeProjectRoot()) ? window.qeProjectRoot() + '/pseudos/PBE' : '');
    
    // Créer la section principale
    const section = document.createElement('div');
    section.id = 'section_5_type_calcul_chemins';
    section.className = 'qe-section qe-section--calc';
    
    section.innerHTML = `
        <h3 class="qe-section-title" style="margin-bottom: 20px;"><span class="qe-step-num">05</span> <span data-i18n="sec5.title">${_t5('sec5.title')}</span></h3>
        
        <!-- SELECT TYPE DE CALCUL -->
        <div style="background: white; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
            <label style="display: block; font-weight: bold; margin-bottom: 10px; color: #1565c0;" data-i18n="sec5.select_calc">
                ${_t5('sec5.select_calc')}
            </label>
            <select id="calc_type" onchange="changerTypeCalculSimple()" style="
                width: 100%;
                padding: 12px;
                font-size: 1.1em;
                border: 2px solid #2196f3;
                border-radius: 5px;
                background: white;
                cursor: pointer;
            ">
                <option value="scf" selected>SCF — chargement des types QE 7.5…</option>
            </select>
            <small id="calc_type_hint" style="display:block;margin-top:8px;color:#64748b;font-size:0.85em;line-height:1.4;"></small>
        </div>

        <details id="qe_types_catalog_wrap" class="qe-types-catalog-wrap" style="margin-bottom:18px;">
            <summary style="cursor:pointer;font-weight:bold;color:#0d47a1;">📚 Types d&apos;inputs QE 7.5+ (catalogue complet)</summary>
            <div id="qe_types_catalog_panel" style="margin-top:10px;padding:12px;background:#f8fafc;border:1px solid #cbd5e1;border-radius:8px;"></div>
            <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;">
                <button type="button" class="qe-action-btn qe-action-btn--visu" onclick="qeVerifyInputText()" title="Vérifier l'aperçu courant contre les règles QE 7.5+">
                    ✓ Vérifier conformité QE 7.5
                </button>
                <button type="button" class="qe-action-btn qe-action-btn--back" onclick="qeLoadInputTypesCatalog()" title="Recharger le catalogue depuis l'API">
                    🔄 Actualiser catalogue
                </button>
            </div>
        </details>
        
        <!-- CHOIX MAGNÉTIQUE -->
        <div style="background: white; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 2px solid #ce93d8;">
            <label style="display: block; font-weight: bold; margin-bottom: 12px; color: #7b1fa2; font-size: 1.05em;" data-i18n="sec5.mag_title">
                ${_t5('sec5.mag_title')}
            </label>
            <!-- Miroir nspin (unique) — synchronisé par changerTypeMagnetisme() -->
            <select id="nspin" aria-hidden="true" tabindex="-1"
                    style="position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0;">
                <option value="1" selected>1</option>
                <option value="2">2</option>
                <option value="4">4</option>
            </select>
            <!-- Niveau 1: Non-mag / Mag / Non-colinéaire -->
            <div style="display: flex; gap: 20px; flex-wrap: wrap; padding: 12px; background: #f3e5f5; border-radius: 8px;">
                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 0.95em;">
                    <input type="radio" name="type_magnetisme" id="radio_non_mag" value="non_mag" checked onchange="changerTypeMagnetisme('non_mag')">
                    <span>⚪ <strong>Non-Magnétique</strong> <small style="color:#666;">(nspin=1)</small></span>
                </label>
                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 0.95em;">
                    <input type="radio" name="type_magnetisme" id="radio_mag" value="mag" onchange="changerTypeMagnetisme('mag')">
                    <span>🔴 <strong>Magnétique (nspin=2)</strong></span>
                </label>
                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 0.95em;">
                    <input type="radio" name="type_magnetisme" id="radio_non_colin" value="non_colin" onchange="changerTypeMagnetisme('non_colin')">
                    <span>🔵 <strong>Non-Colinéaire</strong> <small style="color:#666;">(noncolin=.true.)</small></span>
                </label>
            </div>

            <!-- Niveau 2: Ordre magnétique FM/AFM (visible si nspin=2 ou non-colinéaire) -->
            <div id="section_ordre_mag" style="display:none; margin-top:12px; padding:12px; background:#f8f0ff; border-radius:8px; border:1px solid #ce93d8;">
                <label style="display:block; font-weight:bold; margin-bottom:8px; color:#6a1b9a; font-size:0.95em;">⚛️ Ordre magnétique :</label>
                <div style="display:flex; gap:16px; flex-wrap:wrap;">
                    <label style="display:flex; align-items:center; gap:6px; cursor:pointer;">
                        <input type="radio" name="ordre_mag" id="radio_fm" value="fm" checked onchange="changerOrdreMag('fm')">
                        <span>🔴 <strong>Ferromagnétique (FM)</strong> <small style="color:#666;">— spins parallèles</small></span>
                    </label>
                    <label style="display:flex; align-items:center; gap:6px; cursor:pointer;">
                        <input type="radio" name="ordre_mag" id="radio_afm" value="afm" onchange="changerOrdreMag('afm')">
                        <span>🔵 <strong>Antiferromagnétique (AFM)</strong> <small style="color:#666;">— spins antiparallèles</small></span>
                    </label>
                    <label style="display:flex; align-items:center; gap:6px; cursor:pointer;">
                        <input type="radio" name="ordre_mag" id="radio_ferri" value="ferri" onchange="changerOrdreMag('ferri')">
                        <span>🟣 <strong>Ferrimagnétique</strong> <small style="color:#666;">— moments inégaux</small></span>
                    </label>
                    <label style="display:flex; align-items:center; gap:6px; cursor:pointer;">
                        <input type="radio" name="ordre_mag" id="radio_dms" value="dms" onchange="changerOrdreMag('dms')">
                        <span>🟠 <strong>DMS (Dilué magnétique)</strong> <small style="color:#666;">— dopé (ex: GaMnAs)</small></span>
                    </label>
                </div>
            </div>

            <!-- Niveau 3: Paramètres magnétiques (section principale) -->
            <div id="section_params_mag" class="qe-mag-panel" style="display: none;">

                <!-- En-tête + bouton auto-détection -->
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:12px;">
                    <h5 id="titre_params_mag">⚙️ Paramètres magnétiques — Ferromagnétique</h5>
                    <button type="button" class="qe-btn-detect" onclick="detecterElementsMagnetiques()">
                        🔍 Détecter éléments magnétiques
                    </button>
                </div>

                <!-- Formule manuelle si matériau pas détecté -->
                <div style="margin-bottom:12px;">
                    <label style="font-weight:bold; color:#555; font-size:0.85em;">Formule du matériau (pour auto-détection) :</label>
                    <div style="display:flex; gap:8px; margin-top:4px;">
                        <input type="text" id="formule_materiau_mag" placeholder="ex: Fe2O3, CoFe2O4, GaMnAs, NiFe..." style="
                            flex:1; padding:8px; border:2px solid #ddd; border-radius:5px; font-size:0.9em;">
                        <button onclick="detecterElementsMagnetiques()" style="
                            padding:8px 12px; background:#7b1fa2; color:white; border:none; border-radius:5px; cursor:pointer; font-size:0.85em;">
                            Auto
                        </button>
                    </div>
                </div>

                <!-- Tableau des espèces magnétiques (généré dynamiquement) -->
                <div id="tableau_magnetisation" style="margin-bottom:12px;">
                    <!-- Valeurs manuelles par défaut -->
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px;">
                        <div>
                            <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333; font-size: 0.9em;">starting_magnetization(1)</label>
                            <input type="number" id="start_mag_1" value="0.5" step="0.05" min="-1" max="1" style="width:100%; padding: 8px; border: 2px solid #ddd; border-radius: 5px; box-sizing:border-box;">
                            <small style="color: #666; font-size: 0.8em;">Espèce 1 — entre -1 et +1</small>
                        </div>
                        <div>
                            <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333; font-size: 0.9em;">starting_magnetization(2)</label>
                            <input type="number" id="start_mag_2" value="-0.5" step="0.05" min="-1" max="1" style="width:100%; padding: 8px; border: 2px solid #ddd; border-radius: 5px; box-sizing:border-box;">
                            <small style="color: #666; font-size: 0.8em;">Espèce 2 — négatif pour AFM</small>
                        </div>
                        <div>
                            <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333; font-size: 0.9em;">starting_magnetization(3)</label>
                            <input type="number" id="start_mag_3" value="0.0" step="0.05" min="-1" max="1" style="width:100%; padding: 8px; border: 2px solid #ddd; border-radius: 5px; box-sizing:border-box;">
                            <small style="color: #666; font-size: 0.8em;">Espèce 3 (si ntyp ≥ 3)</small>
                        </div>
                        <div>
                            <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333; font-size: 0.9em;">tot_magnetization (µ<sub>B</sub>)</label>
                            <input type="number" id="tot_magnetization" value="" step="0.1" placeholder="Auto (laisser vide)" style="width:100%; padding: 8px; border: 2px solid #ddd; border-radius: 5px; box-sizing:border-box;">
                            <small style="color: #666; font-size: 0.8em;">Total — vide = non fixé</small>
                        </div>
                    </div>
                </div>

                <!-- Paramètres non-colinéaires -->
                <div id="section_params_non_colin" style="display: none; margin-top: 12px; padding: 12px; background: #e3f2fd; border-radius: 6px; border: 1px solid #90caf9;">
                    <h6 style="color: #0d47a1; margin: 0 0 10px 0; font-size: 0.9em;">🔵 Orientations des spins (Non-Colinéaire)</h6>
                    <div style="margin-bottom:8px; padding:8px; background:#fff8e1; border-radius:5px; font-size:0.82em; color:#555;">
                        angle1 = θ (polar, avec axe z) · angle2 = φ (azimuthal, dans plan xy)
                    </div>
                    <div id="tableau_angles_nc" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 10px;">
                        <!-- lspinorb : un seul contrôle dans le formulaire principal (#lspinorb), évite id dupliqué -->
                        <p style="grid-column: 1 / -1; margin: 0 0 4px 0; font-size: 0.82em; color: #455;">
                            Couplage spin–orbite : liste <code>lspinorb</code> dans la section <strong>Magnétisme</strong> ci‑dessus (avec <code>nspin</code> ou sans SOC dans calcul non‑colinéaire « léger »).
                        </p>
                        <div>
                            <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333; font-size: 0.85em;">angle1(1) — θ espèce 1 (°)</label>
                            <input type="number" id="angle1_1" value="0" step="5" style="width:100%; padding: 8px; border: 2px solid #ddd; border-radius: 5px; box-sizing:border-box;">
                            <small style="color:#666; font-size:0.8em;">0° = le long de z (FM), 90° = dans xy</small>
                        </div>
                        <div>
                            <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333; font-size: 0.85em;">angle2(1) — φ espèce 1 (°)</label>
                            <input type="number" id="angle2_1" value="0" step="5" style="width:100%; padding: 8px; border: 2px solid #ddd; border-radius: 5px; box-sizing:border-box;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333; font-size: 0.85em;">angle1(2) — θ espèce 2 (°)</label>
                            <input type="number" id="angle1_2" value="180" step="5" style="width:100%; padding: 8px; border: 2px solid #ddd; border-radius: 5px; box-sizing:border-box;">
                            <small style="color:#666; font-size:0.8em;">180° = AFM avec espèce 1</small>
                        </div>
                        <div>
                            <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333; font-size: 0.85em;">angle2(2) — φ espèce 2 (°)</label>
                            <input type="number" id="angle2_2" value="0" step="5" style="width:100%; padding: 8px; border: 2px solid #ddd; border-radius: 5px; box-sizing:border-box;">
                        </div>
                    </div>
                </div>

                <!-- Recommandations contextuelles -->
                <div id="reco_mag_contexte" style="margin-top: 12px; padding: 10px; background: #fff3cd; border-radius: 5px; font-size: 0.85em; color: #856404; line-height: 1.6;">
                    <strong>💡 FM :</strong> starting_magnetization > 0 pour tous les éléments magnétiques (Fe/Co/Ni → 0.5, Gd → 0.7)
                </div>
            </div>
        </div>

        ${typeof window.pwGenHubbardPanelHtml === 'function' ? window.pwGenHubbardPanelHtml() : ''}

        <!-- RECOMMANDATIONS -->
        <div id="recommandations_container"></div>
        
        <!-- PARAMÈTRES QE -->
        <div id="parametres_container" style="display: none;">
            <h4 style="color: #1565c0; margin: 20px 0 15px 0;" data-i18n="sec5.calc_params">${_t5('sec5.calc_params')}</h4>
            <div id="convergence_recommendations_panel" style="display: none; margin-bottom: 16px;"></div>
            
            <div style="background: white; padding: 20px; border-radius: 8px;">
                <!-- Paramètres de base -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                    <!-- ecutwfc -->
                    <div>
                        <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333;">
                            ecutwfc (Ry) ⚡
                        </label>
                        <input type="number" id="ecutwfc" value="50" step="5" style="
                            width: 100%;
                            padding: 8px;
                            border: 2px solid #ddd;
                            border-radius: 5px;
                        ">
                        <small style="color: #666; font-size: 0.85em;">Cutoff énergie (tester convergence!)</small>
                    </div>
                    
                    <!-- ecutrho -->
                    <div>
                        <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333;">
                            ecutrho (Ry)
                        </label>
                        <input type="number" id="ecutrho" value="400" step="10" style="
                            width: 100%;
                            padding: 8px;
                            border: 2px solid #ddd;
                            border-radius: 5px;
                        ">
                        <small style="color: #666; font-size: 0.85em;">8-10 × ecutwfc (PAW/US)</small>
                    </div>
                    
                    <!-- conv_thr -->
                    <div>
                        <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333;">
                            conv_thr 🎯
                        </label>
                        <input type="text" id="conv_thr" value="1.0d-8" style="
                            width: 100%;
                            padding: 8px;
                            border: 2px solid #ddd;
                            border-radius: 5px;
                        ">
                        <small style="color: #666; font-size: 0.85em;">Seuil SCF (1d-8 standard)</small>
                    </div>
                    
                    <!-- mixing_beta -->
                    <div>
                        <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333;">
                            mixing_beta
                        </label>
                        <input type="number" id="mixing_beta" value="0.7" step="0.1" min="0.1" max="0.9" style="
                            width: 100%;
                            padding: 8px;
                            border: 2px solid #ddd;
                            border-radius: 5px;
                        ">
                        <small style="color: #666; font-size: 0.85em;">0.7 standard, 0.3 si non-convergence</small>
                    </div>

                    <!-- K_POINTS grille (voie directe) -->
                    <div>
                        <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333;">
                            K_POINTS (grille) 📐
                        </label>
                        <div style="display: flex; gap: 6px; align-items: center;">
                            <input type="number" id="kx" value="4" min="1" max="48" step="1" title="kx"
                                   style="width: 100%; padding: 8px; border: 2px solid #ddd; border-radius: 5px;">
                            <input type="number" id="ky" value="4" min="1" max="48" step="1" title="ky"
                                   style="width: 100%; padding: 8px; border: 2px solid #ddd; border-radius: 5px;">
                            <input type="number" id="kz" value="4" min="1" max="48" step="1" title="kz"
                                   style="width: 100%; padding: 8px; border: 2px solid #ddd; border-radius: 5px;">
                        </div>
                        <small style="color: #666; font-size: 0.85em;">NSCF densifié automatiquement (×1.5) côté serveur</small>
                    </div>
                    
                    <!-- diagonalization -->
                    <div>
                        <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333;">
                            diagonalization
                        </label>
                        <select id="diagonalization" style="
                            width: 100%;
                            padding: 8px;
                            border: 2px solid #ddd;
                            border-radius: 5px;
                        ">
                            <option value="david" selected>david (standard)</option>
                            <option value="cg">cg (gros systèmes)</option>
                            <option value="ppcg">ppcg (très gros)</option>
                        </select>
                        <small style="color: #666; font-size: 0.85em;">Algorithme diagonalisation</small>
                    </div>
                    
                    <!-- nbnd (optionnel) -->
                    <div>
                        <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333;">
                            nbnd (optionnel) 🔴
                        </label>
                        <input type="number" id="nbnd" value="" placeholder="auto" style="
                            width: 100%;
                            padding: 8px;
                            border: 2px solid #ddd;
                            border-radius: 5px;
                        ">
                        <small style="color: #d32f2f; font-size: 0.85em;">⚠️ Laisser vide (évite c_bands!)</small>
                    </div>
                </div>
                
                <!-- Paramètres spécifiques relax/vc-relax -->
                <div id="parametres_relax" style="display: none; margin-top: 20px; padding-top: 20px; border-top: 2px solid #e3f2fd;">
                    <h5 style="color: #1565c0; margin: 0 0 15px 0;">Paramètres de Relaxation</h5>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                        <div>
                            <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333;">
                                forc_conv_thr (Ry/bohr)
                            </label>
                            <input type="text" id="forc_conv_thr" value="1.0d-4" style="
                                width: 100%;
                                padding: 8px;
                                border: 2px solid #ddd;
                                border-radius: 5px;
                            ">
                            <small style="color: #666; font-size: 0.85em;">Force max résiduelle</small>
                        </div>
                        
                        <div>
                            <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333;">
                                ion_dynamics
                            </label>
                            <select id="ion_dynamics" style="
                                width: 100%;
                                padding: 8px;
                                border: 2px solid #ddd;
                                border-radius: 5px;
                            ">
                                <option value="bfgs">bfgs (recommandé)</option>
                                <option value="damp">damp</option>
                            </select>
                            <small style="color: #666; font-size: 0.85em;">Méthode d'optimisation</small>
                        </div>
                    </div>
                </div>
                
                <!-- Paramètres spécifiques vc-relax -->
                <div id="parametres_vcrelax" style="display: none; margin-top: 20px; padding-top: 20px; border-top: 2px solid #e3f2fd;">
                    <h5 style="color: #1565c0; margin: 0 0 15px 0;">Paramètres Variable-Cell</h5>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                        <div>
                            <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333;">
                                press_conv_thr (kbar)
                            </label>
                            <input type="number" id="press_conv_thr" value="0.5" step="0.1" style="
                                width: 100%;
                                padding: 8px;
                                border: 2px solid #ddd;
                                border-radius: 5px;
                            ">
                            <small style="color: #666; font-size: 0.85em;">Pression résiduelle max</small>
                        </div>
                        
                        <div>
                            <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333;">
                                cell_dynamics
                            </label>
                            <select id="cell_dynamics" style="
                                width: 100%;
                                padding: 8px;
                                border: 2px solid #ddd;
                                border-radius: 5px;
                            ">
                                <option value="bfgs">bfgs (recommandé)</option>
                                <option value="damp-w">damp-w</option>
                                <option value="damp-pr">damp-pr</option>
                            </select>
                            <small style="color: #666; font-size: 0.85em;">Méthode relaxation cellule</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- CHEMINS DE CONFIGURATION -->
        <div style="background: white; border-radius: 10px; padding: 20px; margin: 25px 0; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <h4 style="color: #1565c0; margin: 0 0 15px 0;">📁 Chemins de Configuration</h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px;">
                <div>
                    <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333;">
                        📥 Répertoire Inputs (BASE):
                    </label>
                    <input type="text" id="path_inputs_field" value="${pathInputs}" 
                           style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 5px;">
                    <small style="color: #666; font-size: 0.85em;">Le prefix sera ajouté automatiquement</small>
                </div>
                <div>
                    <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333;">
                        📤 Répertoire Outputs (BASE):
                    </label>
                    <input type="text" id="path_outputs_field" value="${pathOutputs}" 
                           style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 5px;">
                    <small style="color: #666; font-size: 0.85em;">Le prefix sera ajouté automatiquement</small>
                </div>
                <div>
                    <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333;">
                        🧪 Répertoire Pseudopotentiels:
                    </label>
                    <input type="text" id="path_pseudos_field" value="${pathPseudos}" 
                           style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 5px;">
                    <small style="color: #666; font-size: 0.85em;">Chemin de base des pseudos</small>
                </div>
            </div>
            <div style="margin-top: 15px; padding: 12px; background: #e8f5e9; border-left: 4px solid #4caf50; border-radius: 5px;">
                <strong style="color: #2e7d32;">💡 Exemple:</strong>
                <div style="color: #1b5e20; margin-top: 5px; font-size: 0.9em;">
                    • Inputs: <code>/home/hiadsi/Interface-QE_v1/inputs</code> → Sauvegarde directe: <code>inputs_générés_direct/</code> · CIF: <code>inputs_convertis_cif/</code><br>
                    • Outputs: <code>/home/hiadsi/Interface-QE_v1/outputs</code> → Calculs dans: <code>/home/hiadsi/Interface-QE_v1/outputs/prefix/</code>
                </div>
            </div>
        </div>
        
        <!-- BOUTONS D'ACTION — une action primaire claire -->
        <div class="qe-action-primary-wrap">
            <button type="button" class="qe-action-btn qe-action-btn--generate qe-action-btn--primary" onclick="genererInputAvecPreparation()">
                GÉNÉRER INPUT COMPLET
            </button>
            <p class="qe-action-primary-hint">Action principale — génère et enregistre automatiquement dans <code>inputs_générés_direct/</code></p>
        </div>
        <div class="qe-action-grid qe-action-grid--secondary">
            <button type="button" class="qe-action-btn qe-action-btn--save" onclick="sauvegarderInputModifie()" id="btn_sauvegarder_modif" style="display: none;">
                SAUVEGARDER (après édition)
            </button>
        </div>
        
        <!-- PREVIEW INPUT -->
        <div id="preview_input_container" class="qe-preview-box" style="display: none; margin-top: 25px;">
            <h4>Aperçu de l&apos;input généré (éditable)</h4>
            <div id="direct_save_banner" class="qe-save-banner" style="display:none;" role="status"></div>
            <textarea id="preview_input" style="
                width: 100%;
                height: 400px;
                font-family: 'Courier New', monospace;
                font-size: 0.9em;
                padding: 15px;
                border: 2px solid #2196f3;
                border-radius: 8px;
                background: #f5f5f5;
                resize: vertical;
            "></textarea>
            <div id="qe_embedded_viewer_slot" class="qe-embedded-viewer-slot"></div>
            <div id="preview_post_actions" class="qe-preview-post-actions" style="margin-top:16px;display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
                <button type="button" class="qe-action-btn qe-action-btn--visu" onclick="afficherVisualisation3D()" title="Aperçu 3D intégré dans la page">
                    Structure 3D
                </button>
                <button type="button" class="qe-action-btn qe-action-btn--visu" onclick="ouvrirStructureExterne('xcrysden')" title="Ouvrir dans XCrysDen">
                    XCrysDen
                </button>
                <button type="button" class="qe-action-btn qe-action-btn--visu-alt" onclick="ouvrirStructureExterne('vesta')" title="Ouvrir dans VESTA">
                    VESTA
                </button>
            </div>
        </div>
    `;
    
    // Insérer après la section de référence
    insertAfter.parentElement.insertBefore(section, insertAfter.nextSibling);

    bindMagnetismUiSection5(section);

    if (typeof window.populateCalcTypeSelect === 'function') {
        var calcSelPop = section.querySelector('#calc_type');
        if (calcSelPop) populateCalcTypeSelect(calcSelPop, { defaultValue: 'scf' });
    }

    var calcSel = section.querySelector('#calc_type');
    if (calcSel && !calcSel.value) calcSel.value = 'scf';
    if (typeof window.changerTypeCalculSimple === 'function') {
        try { window.changerTypeCalculSimple(); } catch (_eInitCalc) { console.warn(_eInitCalc); }
    }

    // Alias pour compatibilité avec script_generation_input.js qui cherche "section_type_calcul"
    if (!document.getElementById('section_type_calcul')) {
        var alias = document.createElement('div');
        alias.id = 'section_type_calcul';
        alias.style.display = 'none';
        section.appendChild(alias);
    }

    // Déclencher l'événement sectionTypeCalculReady pour créer le bouton de génération
    setTimeout(function() {
        var event = new CustomEvent('sectionTypeCalculReady');
        document.dispatchEvent(event);
        console.log('📢 Événement sectionTypeCalculReady déclenché depuis script_interface_parametres_qe_simple.js');
        if (typeof window.pwGenInitHubbardPanel === 'function') {
            window.pwGenInitHubbardPanel();
        }
    }, 200);

    console.log('✅ Section 5 (Type Calcul + Chemins + Boutons) créée avec succès!');
}
window.creerSection5TypeCalculChemins = creerSection5TypeCalculChemins;

// Fonction pour changer le type de calcul
window.changerTypeCalculSimple = function() {
    const typeSelect = document.querySelector('#section_5_type_calcul_chemins #calc_type')
        || document.getElementById('calc_type');
    const type = typeSelect ? typeSelect.value : '';
    
    console.log('🔄 Type de calcul changé:', type);

    var hintEl = document.getElementById('calc_type_hint');
    if (hintEl && typeof window.qeGetCalcTypeMeta === 'function') {
        var meta = window.qeGetCalcTypeMeta(type);
        if (meta && meta.hint) {
            hintEl.textContent = (meta.exe ? '[' + meta.exe + '] ' : '') + meta.hint;
            hintEl.style.display = 'block';
        } else {
            hintEl.textContent = '';
            hintEl.style.display = 'none';
        }
    }

    if (typeof window.qePolarizationUpdateVisibility === 'function') {
        window.qePolarizationUpdateVisibility(type);
    }

    const recContainer = document.getElementById('recommandations_container');
    const paramContainer = document.getElementById('parametres_container');

    if (!type) {
        if (recContainer) recContainer.innerHTML = '';
        if (paramContainer) paramContainer.style.display = 'none';
        return;
    }

    if (paramContainer) paramContainer.style.display = 'block';

    // Source unique : recommandations par type (+ profil matériau si disponible)
    if (typeof window.qeApplyRecommendedCalcParams === 'function') {
        window.qeApplyRecommendedCalcParams(type, { scope: 'direct' });
        if (typeof window.tab1ShowStatus === 'function') {
            var meta = (typeof window.qeGetCalcTypeMeta === 'function') ? window.qeGetCalcTypeMeta(type) : null;
            window.tab1ShowStatus('ok',
                'Paramètres recommandés appliqués pour <strong>' + type + '</strong>'
                + (meta && meta.exe ? ' <code>' + meta.exe + '</code>' : '') + '.');
        }
        return;
    }

    // Fallback legacy
    if (typeof ajusterParametresSelonType === 'function') {
        ajusterParametresSelonType(type);
    } else {
        ajusterParametresManuellement(type);
    }
};

function ajusterParametresManuellement(type) {
    const relaxParams = document.getElementById('parametres_relax');
    const vcrelaxParams = document.getElementById('parametres_vcrelax');
    const recContainer = document.getElementById('recommandations_container');
    
    // Paramètres selon type
    const configs = {
        'scf': {
            ecutwfc: 50,
            ecutrho: 400,
            conv_thr: '1.0d-8',
            mixing_beta: 0.7,
            titre: 'SCF - Self-Consistent Field',
            description: 'Calcul de l\'état fondamental électronique',
            conseils: [
                '💡 ecutwfc: Tester la convergence (augmenter par pas de 10 Ry)',
                '⚠️ ecutrho: Pour PAW/US, utiliser 8-12 × ecutwfc',
                '🎯 conv_thr: 1d-8 donne précision de 10 µeV',
                '🔴 ÉVITER C_BANDS: Ne PAS spécifier nbnd (laisser vide)',
                '✅ K-POINTS: Grille RÉGULIÈRE (ex: 8×8×8 pour bulk)'
            ]
        },
        'relax': {
            ecutwfc: 60,
            ecutrho: 480,
            conv_thr: '1.0d-9',
            mixing_beta: 0.5,
            showRelax: true,
            titre: 'RELAX - Relaxation Ionique',
            description: 'Optimisation des positions atomiques à volume constant',
            conseils: [
                '💡 ecutwfc plus élevé que SCF pour forces précises',
                '⚠️ conv_thr STRICT (1d-9) pour bonnes forces',
                '🎯 forc_conv_thr: 1d-4 Ry/bohr ≈ 0.5 meV/Å',
                '🔴 ÉVITER C_BANDS: Ne PAS spécifier nbnd!',
                '🔧 mixing_beta BAS (0.3-0.5) pour stabilité',
                '📊 SORTIE: Récupérer positions optimisées pour SCF suivant'
            ]
        },
        'scf_born': {
            ecutwfc: 55,
            ecutrho: 440,
            conv_thr: '1.0d-12',
            mixing_beta: 0.5,
            titre: 'SCF strict — préparation Born',
            description: 'SCF très convergé avant ph.x zeu',
            conseils: [
                '📌 Étape 3B-1 : après vc-relax convergé',
                '🎯 conv_thr = 1.d-12 obligatoire pour zeu fiable',
                '➡️ Enchaîner avec ph_zeu (même prefix/outdir)'
            ]
        },
        'scf_berry': {
            ecutwfc: 55,
            ecutrho: 440,
            conv_thr: '1.0d-9',
            mixing_beta: 0.5,
            titre: 'SCF + Phase de Berry',
            description: 'Polarisation spontanee via namelist &BP (lberry, gdir, nppstr)',
            conseils: [
                '📌 Étape 3A : après vc-relax convergé',
                '🧭 gdir = axe de polarisation (1=x, 2=y, 3=z)',
                '📐 nppstr = points k le long des strings (ex. 8)',
                '⚠️ Pas de lelfield — incompatible avec lberry'
            ]
        },
        'vc-relax': {
            ecutwfc: 60,
            ecutrho: 480,
            conv_thr: '1.0d-9',
            mixing_beta: 0.3,
            showRelax: true,
            showVCRelax: true,
            titre: 'VC-RELAX - Relaxation Complète',
            description: 'Optimisation positions atomiques + paramètres de maille',
            conseils: [
                '💡 ecutwfc DOIT être BIEN CONVERGÉ (tester avant!)',
                '⚠️ press_conv_thr: 0.5 kbar = 50 MPa (critère pression)',
                '🎯 vc-relax est COÛTEUX: Plusieurs cycles nécessaires',
                '🔧 mixing_beta TRÈS BAS (0.3) pour stabilité maximale',
                '🔴 CRITIQUE: Ne PAS spécifier nbnd (laisse QE calculer)',
                '📊 SORTIE: Récupérer a,b,c optimisés + positions pour SCF',
                '✅ Vérifier convergence: forces ET pression < seuils'
            ]
        },
        'nscf': {
            ecutwfc: 50,
            ecutrho: 400,
            conv_thr: '1.0d-10',
            mixing_beta: 0.7,
            titre: 'NSCF - Non Self-Consistent',
            description: 'Calcul bandes/DOS sur grille k dense (après SCF)',
            conseils: [
                '⚠️ PRÉREQUIS: Utiliser MÊME ecutwfc/ecutrho que SCF!',
                '💡 Lire densité du calcul SCF précédent',
                '🎯 Grille k DENSE (ex: 24×24×24 pour DOS)'
            ]
        },
        'bands': {
            ecutwfc: 50,
            ecutrho: 400,
            conv_thr: '1.0d-10',
            mixing_beta: 0.7,
            titre: 'BANDS - Structure de Bandes',
            description: 'Calcul bandes le long d\'un chemin haute symétrie',
            conseils: [
                '⚠️ APRÈS nscf: Utiliser bands.x pour tracer',
                '💡 Définir path (Γ-X-M-Γ-R...)',
                '🎯 50-100 points k le long du path'
            ]
        },
        'md': {
            ecutwfc: 40,
            ecutrho: 320,
            conv_thr: '1.0d-7',
            mixing_beta: 0.7,
            showRelax: true,
            titre: 'MD - Dynamique Moléculaire',
            description: 'Simulation dynamique ab-initio',
            conseils: [
                '💡 MD ab-initio TRÈS coûteux',
                '⚠️ ecutwfc réduit (40 Ry) pour vitesse',
                '🎯 dt: 20-40 a.u. ≈ 0.5-1 fs',
                '🔧 1000-5000 pas minimum pour équilibration'
            ]
        },
        'vc-md': {
            ecutwfc: 40,
            ecutrho: 320,
            conv_thr: '1.0d-7',
            mixing_beta: 0.3,
            showRelax: true,
            showVCRelax: true,
            titre: 'VC-MD - Dynamique Moléculaire (maille variable)',
            description: 'MD ab-initio avec relaxation de la maille (&IONS + &CELL)',
            conseils: [
                '💡 VC-MD : maille et positions évoluent (QE 7.5+)',
                '⚠️ &CELL requis — press_conv_thr recommandé',
                '🎯 ion_dynamics=verlet, cell_dynamics recommandé',
                '🔧 mixing_beta BAS (0.3) pour stabilité'
            ]
        }
    };
    
    const config = configs[type];
    if (!config) return;
    
    // Ajuster les champs
    document.getElementById('ecutwfc').value = config.ecutwfc;
    document.getElementById('ecutrho').value = config.ecutrho;
    document.getElementById('conv_thr').value = config.conv_thr;
    document.getElementById('mixing_beta').value = config.mixing_beta;
    
    // Afficher paramètres spécifiques
    if (config.showRelax && relaxParams) {
        relaxParams.style.display = 'block';
    }
    if (config.showVCRelax && vcrelaxParams) {
        vcrelaxParams.style.display = 'block';
    }
    
    // Afficher recommandations
    recContainer.innerHTML = `
        <div class="qe-rec-panel">
            <h4>📊 ${config.titre}</h4>
            <p>${config.description}</p>
            <div class="qe-rec-panel-inner">
                <h5 style="margin: 0 0 10px 0;">💡 Recommandations</h5>
                <ul>
                    ${config.conseils.map(c => `<li>${c}</li>`).join('')}
                </ul>
            </div>
        </div>
    `;
    
    console.log('✅ Paramètres ajustés pour:', type);
}

// ════════════════════════════════════════════════════════════════════════
// BASE DE DONNÉES DES ÉLÉMENTS MAGNÉTIQUES
// ════════════════════════════════════════════════════════════════════════
const ELEMENTS_MAG_DB = {
    // 3d (métaux de transition)
    'Fe': { nom: 'Fer',         type: '3d', moment_ub: 2.22, fm: 0.50, afm: 0.50, ferri: 0.50, dms: 0.30 },
    'Co': { nom: 'Cobalt',      type: '3d', moment_ub: 1.72, fm: 0.50, afm: 0.50, ferri: 0.40, dms: 0.30 },
    'Ni': { nom: 'Nickel',      type: '3d', moment_ub: 0.61, fm: 0.30, afm: 0.30, ferri: 0.30, dms: 0.20 },
    'Mn': { nom: 'Manganèse',   type: '3d', moment_ub: 3.50, fm: 0.50, afm: 0.50, ferri: 0.50, dms: 0.20 },
    'Cr': { nom: 'Chrome',      type: '3d', moment_ub: 3.00, fm: 0.50, afm: 0.50, ferri: 0.40, dms: 0.15 },
    'V':  { nom: 'Vanadium',    type: '3d', moment_ub: 1.50, fm: 0.20, afm: 0.20, ferri: 0.20, dms: 0.10 },
    'Ti': { nom: 'Titane',      type: '3d', moment_ub: 0.50, fm: 0.10, afm: 0.10, ferri: 0.10, dms: 0.05 },
    'Cu': { nom: 'Cuivre',      type: '3d', moment_ub: 0.10, fm: 0.05, afm: 0.05, ferri: 0.05, dms: 0.03 },
    // 4f (terres rares)
    'Gd': { nom: 'Gadolinium',  type: '4f', moment_ub: 7.00, fm: 0.70, afm: 0.70, ferri: 0.70, dms: 0.50 },
    'Nd': { nom: 'Néodyme',     type: '4f', moment_ub: 3.00, fm: 0.50, afm: 0.50, ferri: 0.50, dms: 0.40 },
    'Sm': { nom: 'Samarium',    type: '4f', moment_ub: 5.00, fm: 0.60, afm: 0.60, ferri: 0.60, dms: 0.40 },
    'Dy': { nom: 'Dysprosium',  type: '4f', moment_ub: 10.0, fm: 0.70, afm: 0.70, ferri: 0.70, dms: 0.50 },
    'Tb': { nom: 'Terbium',     type: '4f', moment_ub: 9.00, fm: 0.70, afm: 0.70, ferri: 0.70, dms: 0.50 },
    'Er': { nom: 'Erbium',      type: '4f', moment_ub: 9.00, fm: 0.70, afm: 0.70, ferri: 0.70, dms: 0.50 },
    'Ho': { nom: 'Holmium',     type: '4f', moment_ub: 10.0, fm: 0.70, afm: 0.70, ferri: 0.70, dms: 0.50 },
    'Eu': { nom: 'Europium',    type: '4f', moment_ub: 7.00, fm: 0.70, afm: 0.70, ferri: 0.70, dms: 0.50 },
    'Yb': { nom: 'Ytterbium',   type: '4f', moment_ub: 4.00, fm: 0.50, afm: 0.50, ferri: 0.50, dms: 0.30 },
    'Pr': { nom: 'Praséodyme',  type: '4f', moment_ub: 3.00, fm: 0.50, afm: 0.50, ferri: 0.50, dms: 0.30 },
    'Ce': { nom: 'Cérium',      type: '4f', moment_ub: 2.00, fm: 0.30, afm: 0.30, ferri: 0.30, dms: 0.20 },
    'La': { nom: 'Lanthane',    type: '4f', moment_ub: 0.00, fm: 0.10, afm: 0.10, ferri: 0.10, dms: 0.05 },
};

// Configurations FM/AFM/Ferri/DMS par type de matériau connu
const MAG_CONFIGS_CONNUS = {
    'Fe':       { ordre:'fm',   note:'Métal FM cubique bcc' },
    'Co':       { ordre:'fm',   note:'Métal FM hexagonal/cubique' },
    'Ni':       { ordre:'fm',   note:'Métal FM cubique fcc' },
    'Gd':       { ordre:'fm',   note:'Terre rare FM à T<293K' },
    'Cr':       { ordre:'afm',  note:'AFM bcc (Néel T=311K)' },
    'Mn':       { ordre:'afm',  note:'AFM complexe' },
    'Fe2O3':    { ordre:'afm',  note:'Hématite — AFM/WFM' },
    'NiO':      { ordre:'afm',  note:'AFM classique (Néel T=523K)' },
    'CoO':      { ordre:'afm',  note:'AFM (Néel T=291K)' },
    'MnO':      { ordre:'afm',  note:'AFM (Néel T=116K)' },
    'FeO':      { ordre:'afm',  note:'AFM (Néel T=198K)' },
    'Fe3O4':    { ordre:'ferri',note:'Ferrite magnétite — ferrimagnétique' },
    'CoFe2O4':  { ordre:'ferri',note:'Cobalt ferrite — ferrimagnétique fort' },
    'NiFe2O4':  { ordre:'ferri',note:'Nickel ferrite — ferrimagnétique' },
    'GaMnAs':   { ordre:'dms',  note:'DMS III-V dopé Mn (Curie ~110K)' },
    'InMnAs':   { ordre:'dms',  note:'DMS III-V dopé Mn' },
    'ZnCoO':    { ordre:'dms',  note:'DMS II-VI dopé Co' },
};

// ════════════════════════════════════════════════════════════════════════
// FONCTIONS DE GESTION DU MAGNÉTISME
// ════════════════════════════════════════════════════════════════════════

/**
 * Changement du type de magnétisme principal (nspin)
 */
function syncMagHiddenNspin() {
    if (typeof window.pwGenSyncHiddenFieldsFromWorkflow === 'function') {
        try { window.pwGenSyncHiddenFieldsFromWorkflow(); } catch (_eSn) {}
    } else {
        var nspinEl = document.getElementById('nspin');
        var tm = window.typeMagnetisme || 'non_mag';
        if (nspinEl) {
            if (tm === 'mag') nspinEl.value = '2';
            else if (tm === 'non_colin') nspinEl.value = '4';
            else nspinEl.value = '1';
        }
    }
}

function bindMagnetismUiSection5(root) {
    if (!root || root.dataset.magBound === '1') return;
    root.dataset.magBound = '1';
    root.addEventListener('change', function (e) {
        var t = e.target;
        if (!t || !t.name || !t.checked) return;
        if (t.name === 'type_magnetisme') changerTypeMagnetisme(t.value);
        else if (t.name === 'ordre_mag') changerOrdreMag(t.value);
    });
}

function changerTypeMagnetisme(val) {
    window.typeMagnetisme = val;
    const sectionOrdre  = document.getElementById('section_ordre_mag');
    const sectionMag    = document.getElementById('section_params_mag');
    const sectionNC     = document.getElementById('section_params_non_colin');
    if (!sectionMag) return;

    if (val === 'non_mag') {
        if (sectionOrdre)  sectionOrdre.style.display  = 'none';
        sectionMag.style.display = 'none';
    } else {
        if (sectionOrdre)  sectionOrdre.style.display  = 'block';
        sectionMag.style.display = 'block';
        if (val === 'non_colin') {
            if (sectionNC) sectionNC.style.display = 'block';
            if (typeof window.nspin4Flow !== 'undefined') {
                try { window.nspin4Flow.applyWorkflowDefaults('gen'); } catch (_eNc) { console.warn(_eNc); }
            }
        } else {
            if (sectionNC) sectionNC.style.display = 'none';
        }
        // Appliquer l'ordre magnétique en cours
        const ordreCourant = window.ordreMagnetisme || 'fm';
        changerOrdreMag(ordreCourant, false);
    }
    syncMagHiddenNspin();
    console.log('🧲 Type magnétisme:', val);
}

/**
 * Changement de l'ordre magnétique FM / AFM / Ferri / DMS
 */
function changerOrdreMag(ordre, relancer) {
    window.ordreMagnetisme = ordre;
    if (relancer === undefined) relancer = true;

    const titreEl = document.getElementById('titre_params_mag');
    const recoEl  = document.getElementById('reco_mag_contexte');

    const titres = {
        fm:    '⚙️ Paramètres Magnétiques — Ferromagnétique (FM)',
        afm:   '⚙️ Paramètres Magnétiques — Antiferromagnétique (AFM)',
        ferri: '⚙️ Paramètres Magnétiques — Ferrimagnétique',
        dms:   '⚙️ Paramètres Magnétiques — DMS (Dilué Magnétique)'
    };
    const recos = {
        fm:    '<strong>💡 FM :</strong> starting_magnetization > 0 pour tous les éléments magnétiques. Fe/Co → 0.5, Ni → 0.3, Gd → 0.7. Tous les spins sont alignés dans le même sens (+z).',
        afm:   '<strong>💡 AFM :</strong> Alterner +valeur et −valeur entre sous-réseaux. Espèce 1 = +0.5, Espèce 2 = −0.5. Pour le non-colinéaire: angle1(1)=0°, angle1(2)=180°.',
        ferri: '<strong>💡 Ferrimagnétique :</strong> Moments inégaux sur sous-réseaux opposés. Ex: Fe(oct) ≈ +0.5, Fe(tet) ≈ −0.3. Utilisé pour ferrites (Fe3O4, CoFe2O4...).',
        dms:   '<strong>💡 DMS :</strong> Valeurs faibles pour le dopant (Mn/Co → 0.1 à 0.3) et 0 pour l\'hôte. Utiliser tot_magnetization si la magnétisation totale est connue.'
    };

    if (titreEl) titreEl.textContent = titres[ordre] || titres.fm;
    if (recoEl)  recoEl.innerHTML    = recos[ordre]  || recos.fm;

    // Re-appliquer les valeurs selon l'ordre et le matériau en cours
    if (relancer) appliquerValeursOrdreMag(ordre);
    syncMagHiddenNspin();
    console.log('⚛️ Ordre magnétique:', ordre);
}

/**
 * Détecter les éléments magnétiques depuis le nom du matériau
 */
function detecterElementsMagnetiques() {
    // Lire la formule depuis l'input dédié ou le champ matériau principal
    let formule = (document.getElementById('formule_materiau_mag')?.value || '').trim();
    if (!formule) {
        formule = (document.getElementById('materiau_name')?.value || '').trim();
        if (formule && document.getElementById('formule_materiau_mag')) {
            document.getElementById('formule_materiau_mag').value = formule;
        }
    }
    if (!formule) {
        alert('Entrez la formule du matériau (ex: Fe2O3, CoFe2O4, GaMnAs)');
        return;
    }

    console.log('🔍 Détection magnétique pour:', formule);

    // Détecter le config connu
    const formuleMaj = formule.replace(/\s/g, '');
    let ordreDetecte = null;
    let noteDetectee = '';
    for (const [key, cfg] of Object.entries(MAG_CONFIGS_CONNUS)) {
        if (formuleMaj.toLowerCase().includes(key.toLowerCase())) {
            ordreDetecte = cfg.ordre;
            noteDetectee = cfg.note;
            break;
        }
    }

    // Parser les éléments chimiques de la formule
    const elementsFormule = [];
    const regex = /([A-Z][a-z]?)(\d*)/g;
    let match;
    while ((match = regex.exec(formule)) !== null) {
        const sym = match[0] ? match[0].replace(/\d/g, '') : match[1];
        const symbol = match[1];
        if (symbol && symbol.length > 0) {
            if (!elementsFormule.includes(symbol)) {
                elementsFormule.push(symbol);
            }
        }
    }

    // Séparer magnétiques / non-magnétiques
    const elsMag    = elementsFormule.filter(e => ELEMENTS_MAG_DB[e]);
    const elsNonMag = elementsFormule.filter(e => !ELEMENTS_MAG_DB[e]);

    console.log('  Éléments magnétiques détectés:', elsMag);
    console.log('  Éléments non-magnétiques:', elsNonMag);

    // Appliquer l'ordre détecté si trouvé
    if (ordreDetecte) {
        window.ordreMagnetisme = ordreDetecte;
        const radioEl = document.getElementById('radio_' + ordreDetecte);
        if (radioEl) radioEl.checked = true;
        changerOrdreMag(ordreDetecte, false);
    }

    // Construire le tableau des espèces et les starting_magnetization
    construireTableauMagnetisation(elementsFormule, elsMag, elsNonMag, ordreDetecte || window.ordreMagnetisme || 'fm', noteDetectee);
}

/**
 * Construire le tableau interactif des starting_magnetization par espèce
 */
function construireTableauMagnetisation(tousElements, elsMag, elsNonMag, ordre, note) {
    const container = document.getElementById('tableau_magnetisation');
    if (!container) return;

    const couleurs = { fm: '#c62828', afm: '#1565c0', ferri: '#6a1b9a', dms: '#e65100' };
    const couleur  = couleurs[ordre] || '#c62828';

    let html = '';

    if (note) {
        html += `<div style="padding:8px 12px; background:#e8f5e9; border-radius:6px; border-left:4px solid #388e3c;
                    color:#1b5e20; font-size:0.85em; margin-bottom:10px;">
                    ✅ <strong>${note}</strong>
                 </div>`;
    }

    if (tousElements.length === 0) {
        html += '<div style="color:#888; font-size:0.85em; padding:8px;">Aucun élément détecté.</div>';
    } else {
        html += `<div style="overflow-x:auto;">
            <table style="width:100%; border-collapse:collapse; font-size:0.88em;">
                <thead>
                    <tr style="background:${couleur}; color:white;">
                        <th style="padding:8px 10px; text-align:left; border-radius:5px 0 0 0;"># Espèce</th>
                        <th style="padding:8px 10px; text-align:left;">Élément</th>
                        <th style="padding:8px 10px; text-align:left;">Type</th>
                        <th style="padding:8px 10px; text-align:left;">Moment (µB)</th>
                        <th style="padding:8px 10px; text-align:center;">starting_magnetization</th>
                        <th style="padding:8px 10px; text-align:left; border-radius:0 5px 0 0;">Orientation</th>
                    </tr>
                </thead>
                <tbody>`;

        tousElements.forEach((sym, idx) => {
            const i    = idx + 1;
            const info = ELEMENTS_MAG_DB[sym];
            const isMag = !!info;
            const valSugg = isMag ? calculerValMag(info, ordre, idx, tousElements.length) : 0.0;
            const bgRow  = idx % 2 === 0 ? '#fff' : '#fafafa';
            const orient = getOrientationLabel(ordre, idx, isMag);
            const tagType = isMag
                ? `<span style="background:${couleur}; color:white; padding:2px 6px; border-radius:4px; font-size:0.8em;">${info.type}</span>`
                : `<span style="background:#9e9e9e; color:white; padding:2px 6px; border-radius:4px; font-size:0.8em;">non-mag</span>`;

            html += `<tr style="background:${bgRow}; border-bottom:1px solid #eee;">
                <td style="padding:8px 10px; font-weight:bold; color:${isMag ? couleur : '#888'};">${i}</td>
                <td style="padding:8px 10px; font-weight:bold;">${sym} <span style="color:#888; font-size:0.85em;">${isMag ? info.nom : ''}</span></td>
                <td style="padding:8px 10px;">${tagType}</td>
                <td style="padding:8px 10px; color:#444;">${isMag ? info.moment_ub.toFixed(2) : '—'}</td>
                <td style="padding:8px 10px; text-align:center;">
                    <input type="number" id="start_mag_${i}" value="${valSugg}" step="0.05" min="-1" max="1"
                        style="width:90px; padding:6px; border:2px solid ${isMag ? couleur : '#ccc'};
                               border-radius:4px; text-align:center; font-weight:bold; font-size:0.9em;">
                </td>
                <td style="padding:8px 10px; color:#555; font-size:0.82em;">${orient}</td>
            </tr>`;
        });

        html += '</tbody></table></div>';

        // Zone tot_magnetization
        html += `<div style="margin-top:10px; display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
            <label style="font-weight:bold; color:#333; font-size:0.9em;">tot_magnetization (µB) :</label>
            <input type="number" id="tot_magnetization" value="" step="0.1" placeholder="Auto (vide = non fixé)"
                style="padding:8px; border:2px solid #ddd; border-radius:5px; width:200px; font-size:0.9em;">
            <small style="color:#666; font-size:0.8em;">Forcer la magnétisation totale (optionnel)</small>
        </div>`;
    }

    container.innerHTML = html;

    // Mettre à jour les angles si non-colinéaire
    if (window.typeMagnetisme === 'non_colin') {
        appliquerAnglesOrdreMag(tousElements, ordre);
    }

    // Sauvegarder la liste d'espèces pour la génération d'input
    window.especesMagnetiques = tousElements;
    console.log('✅ Tableau magnétisation construit pour', tousElements.length, 'espèces');
}

/**
 * Calculer la valeur starting_magnetization suggérée
 */
function calculerValMag(info, ordre, idx, nbEspeces) {
    const base = info[ordre] || info.fm || 0.5;
    // AFM: alterner les signes
    if (ordre === 'afm') return idx % 2 === 0 ? base : -base;
    // Ferrimagnétique: premier groupe positif, second négatif et plus faible
    if (ordre === 'ferri') return idx % 2 === 0 ? base : -(base * 0.6);
    // FM et DMS: toujours positif
    return base;
}

/**
 * Obtenir le label d'orientation pour le tableau
 */
function getOrientationLabel(ordre, idx, isMag) {
    if (!isMag) return '— (non magnétique, = 0)';
    const labels = {
        fm:    ['↑ spin up (+z)', '↑ spin up (+z)', '↑ spin up (+z)'],
        afm:   ['↑ spin up (+z)', '↓ spin down (−z)', '↑ spin up (+z)'],
        ferri: ['↑ moment fort (+)', '↓ moment faible (−)', '↑ (+)'],
        dms:   ['↑ dopant magnétique', '— hôte (≈ 0)', '↑ dopant'],
    };
    const list = labels[ordre] || labels.fm;
    return list[idx % list.length] || list[0];
}

/**
 * Appliquer les angles automatiquement selon l'ordre magnétique (non-colinéaire)
 */
function appliquerAnglesOrdreMag(elements, ordre) {
    const angles = {
        fm:    (i) => ({ a1: 0,   a2: 0   }),   // FM: tous le long de +z
        afm:   (i) => ({ a1: i%2===0 ? 0 : 180, a2: 0 }),  // AFM: alternance 0/180
        ferri: (i) => ({ a1: i%2===0 ? 0 : 180, a2: 0 }),
        dms:   (i) => ({ a1: 0,   a2: 0   }),
    };
    const fn = angles[ordre] || angles.fm;

    // Mettre à jour les inputs déjà présents (angle1_1, angle1_2, angle2_1, angle2_2)
    for (let i = 0; i < Math.min(elements.length, 4); i++) {
        const a = fn(i);
        const a1El = document.getElementById('angle1_' + (i+1));
        const a2El = document.getElementById('angle2_' + (i+1));
        if (a1El) a1El.value = a.a1;
        if (a2El) a2El.value = a.a2;
    }
    console.log('🔵 Angles appliqués pour ordre:', ordre);
}

/**
 * Appliquer les valeurs de starting_magnetization selon l'ordre sélectionné
 * (utilisé quand on change FM/AFM sans relancer la détection)
 */
function appliquerValeursOrdreMag(ordre) {
    const especes = window.especesMagnetiques || [];
    if (especes.length > 0) {
        // Reconstruire avec le nouvel ordre
        const elsMag = especes.filter(e => ELEMENTS_MAG_DB[e]);
        construireTableauMagnetisation(especes, elsMag, [], ordre, '');
    } else {
        // Mettre à jour les 3 inputs simples
        const vals = { fm: [0.5, 0.5, 0.5], afm: [0.5, -0.5, 0.0], ferri: [0.5, -0.3, 0.0], dms: [0.2, 0.0, 0.0] };
        const v = vals[ordre] || vals.fm;
        ['start_mag_1','start_mag_2','start_mag_3'].forEach((id, i) => {
            const el = document.getElementById(id);
            if (el) el.value = v[i];
        });
    }
}

// ─── Initialisation des globals ───────────────────────────────────────
window.typeMagnetisme   = 'non_mag';
window.ordreMagnetisme  = 'fm';
window.especesMagnetiques = [];
window.changerTypeMagnetisme = changerTypeMagnetisme;
window.changerOrdreMag = changerOrdreMag;
window.detecterElementsMagnetiques = detecterElementsMagnetiques;
window.appliquerValeursOrdreMag = appliquerValeursOrdreMag;
window.syncMagHiddenNspin = syncMagHiddenNspin;

console.log('✅ Script section 5 chargé et prêt');

// ═══════════════════════════════════════════════════════════════════════════
// SCRIPT DE DIAGNOSTIC COMPLET - Identifier le problème ATOMIC_SPECIES
// ═══════════════════════════════════════════════════════════════════════════

function diagnosticComplet() {
    console.log('\n\n═══════════════════════════════════════════════════════════════');
    console.log('🔍 DIAGNOSTIC COMPLET - ATOMIC_SPECIES ET POSITIONS');
    console.log('═══════════════════════════════════════════════════════════════\n');
    
    // ═══════════════════════════════════════════════════════════════
    // ÉTAPE 1: Vérifier les variables globales
    // ═══════════════════════════════════════════════════════════════
    console.log('📊 ÉTAPE 1: Variables globales\n');
    
    console.log('window.atomicSpeciesGlobal:');
    console.log('  Existe:', typeof window.atomicSpeciesGlobal !== 'undefined');
    console.log('  Type:', typeof window.atomicSpeciesGlobal);
    console.log('  Longueur:', window.atomicSpeciesGlobal?.length || 0);
    console.log('  Valeur:', window.atomicSpeciesGlobal);
    
    console.log('\nwindow.atomicPositionsContent:');
    console.log('  Existe:', typeof window.atomicPositionsContent !== 'undefined');
    console.log('  Type:', typeof window.atomicPositionsContent);
    console.log('  Longueur:', window.atomicPositionsContent?.length || 0);
    console.log('  Valeur:', window.atomicPositionsContent);
    
    // ═══════════════════════════════════════════════════════════════
    // ÉTAPE 2: Vérifier les éléments DOM
    // ═══════════════════════════════════════════════════════════════
    console.log('\n\n📊 ÉTAPE 2: Éléments DOM\n');
    
    const ntypInput = document.getElementById('ntyp');
    const natInput = document.getElementById('nat');
    
    console.log('ntyp:', ntypInput?.value || '❌ NON TROUVÉ');
    console.log('nat:', natInput?.value || '❌ NON TROUVÉ');
    
    const ntyp = parseInt(ntypInput?.value) || 0;
    const nat = parseInt(natInput?.value) || 0;
    
    console.log('\nÉléments (element_${i}):');
    for (let i = 1; i <= ntyp; i++) {
        const elem = document.getElementById(`element_${i}`);
        console.log(`  element_${i}:`, elem?.value || '❌ NON TROUVÉ');
    }
    
    console.log('\nÉléments dans selects (elem_${i}):');
    for (let i = 1; i <= nat; i++) {
        const elem = document.getElementById(`elem_${i}`);
        console.log(`  elem_${i}:`, elem?.value || '❌ NON TROUVÉ');
    }
    
    console.log('\nPositions (pos_x_${i}, pos_y_${i}, pos_z_${i}):');
    for (let i = 1; i <= nat; i++) {
        const x = document.getElementById(`pos_x_${i}`);
        const y = document.getElementById(`pos_y_${i}`);
        const z = document.getElementById(`pos_z_${i}`);
        console.log(`  Position ${i}:`, 
            x?.value || '?', 
            y?.value || '?', 
            z?.value || '?'
        );
    }
    
    // ═══════════════════════════════════════════════════════════════
    // ÉTAPE 3: Tester les fonctions
    // ═══════════════════════════════════════════════════════════════
    console.log('\n\n📊 ÉTAPE 3: Test des fonctions\n');
    
    // Test genererAtomicSpecies()
    if (typeof genererAtomicSpecies === 'function') {
        console.log('✓ genererAtomicSpecies() existe');
        console.log('  Appel...');
        genererAtomicSpecies();
        console.log('  Après appel:');
        console.log('    window.atomicSpeciesGlobal:', window.atomicSpeciesGlobal);
        console.log('    Longueur:', window.atomicSpeciesGlobal?.length || 0);
    } else {
        console.error('❌ genererAtomicSpecies() NOT FOUND');
    }
    
    // Test mettreAJourFormat()
    if (typeof mettreAJourFormat === 'function') {
        console.log('\n✓ mettreAJourFormat() existe');
        console.log('  Appel...');
        mettreAJourFormat();
        console.log('  Après appel:');
        console.log('    window.atomicPositionsContent:', window.atomicPositionsContent);
        console.log('    Longueur:', window.atomicPositionsContent?.length || 0);
    } else {
        console.error('❌ mettreAJourFormat() NOT FOUND');
    }
    
    // ═══════════════════════════════════════════════════════════════
    // ÉTAPE 4: Tester obtenirAtomicSpecies() et obtenirAtomicPositions()
    // ═══════════════════════════════════════════════════════════════
    console.log('\n\n📊 ÉTAPE 4: Test des fonctions de récupération\n');
    
    if (typeof obtenirAtomicSpecies === 'function') {
        console.log('✓ obtenirAtomicSpecies() existe');
        const result = obtenirAtomicSpecies();
        console.log('  Résultat:', result);
        console.log('  Longueur:', result?.length || 0);
    } else {
        console.error('❌ obtenirAtomicSpecies() NOT FOUND');
    }
    
    if (typeof obtenirAtomicPositions === 'function') {
        console.log('\n✓ obtenirAtomicPositions() existe');
        const result = obtenirAtomicPositions();
        console.log('  Résultat:', result);
        console.log('  Longueur:', result?.length || 0);
    } else {
        console.error('❌ obtenirAtomicPositions() NOT FOUND');
    }
    
    // ═══════════════════════════════════════════════════════════════
    // ÉTAPE 5: Affichage dans le DOM
    // ═══════════════════════════════════════════════════════════════
    console.log('\n\n📊 ÉTAPE 5: Affichage dans le DOM\n');
    
    const atomicSpeciesDiv = document.getElementById('atomic_species_format');
    console.log('atomic_species_format:');
    console.log('  Existe:', !!atomicSpeciesDiv);
    console.log('  textContent:', atomicSpeciesDiv?.textContent || '❌ VIDE');
    console.log('  innerHTML:', atomicSpeciesDiv?.innerHTML || '❌ VIDE');
    
    const atomicPosDiv = document.getElementById('atomic_pos_text');
    console.log('\natomic_pos_text:');
    console.log('  Existe:', !!atomicPosDiv);
    console.log('  textContent:', atomicPosDiv?.textContent || '❌ VIDE');
    
    // ═══════════════════════════════════════════════════════════════
    // ÉTAPE 6: Simuler génération input
    // ═══════════════════════════════════════════════════════════════
    console.log('\n\n📊 ÉTAPE 6: Simulation génération input\n');
    
    const materiau = document.getElementById('materiau_name')?.value || 'TEST';
    const ibrav = document.getElementById('ibrav')?.value || '1';
    
    const atomicSpecies = window.atomicSpeciesGlobal || '';
    const atomicPositions = window.atomicPositionsContent || '';
    
    console.log('Données pour input:');
    console.log('  materiau:', materiau);
    console.log('  ibrav:', ibrav);
    console.log('  atomicSpecies (longueur):', atomicSpecies.length);
    console.log('  atomicPositions (longueur):', atomicPositions.length);
    
    if (atomicSpecies.length > 0) {
        console.log('\n✅ ATOMIC_SPECIES serait intégré:');
        console.log('─'.repeat(50));
        console.log(atomicSpecies);
        console.log('─'.repeat(50));
    } else {
        console.error('\n❌ ATOMIC_SPECIES VIDE - Ne serait PAS intégré!');
    }
    
    if (atomicPositions.length > 0) {
        console.log('\n✅ ATOMIC_POSITIONS serait intégré:');
        console.log('─'.repeat(50));
        console.log(atomicPositions);
        console.log('─'.repeat(50));
    } else {
        console.error('\n❌ ATOMIC_POSITIONS VIDE - Ne serait PAS intégré!');
    }
    
    // ═══════════════════════════════════════════════════════════════
    // RÉSUMÉ
    // ═══════════════════════════════════════════════════════════════
    console.log('\n\n═══════════════════════════════════════════════════════════════');
    console.log('📋 RÉSUMÉ DU DIAGNOSTIC');
    console.log('═══════════════════════════════════════════════════════════════\n');
    
    const checks = {
        'window.atomicSpeciesGlobal rempli': !!(window.atomicSpeciesGlobal && window.atomicSpeciesGlobal.length > 0),
        'window.atomicPositionsContent rempli': !!(window.atomicPositionsContent && window.atomicPositionsContent.length > 0),
        'DOM atomic_species_format existe': !!atomicSpeciesDiv,
        'DOM atomic_species_format rempli': !!(atomicSpeciesDiv?.textContent && atomicSpeciesDiv.textContent.trim().length > 0),
        'genererAtomicSpecies() existe': typeof genererAtomicSpecies === 'function',
        'obtenirAtomicSpecies() existe': typeof obtenirAtomicSpecies === 'function',
        'obtenirAtomicPositions() existe': typeof obtenirAtomicPositions === 'function'
    };
    
    Object.entries(checks).forEach(([check, passed]) => {
        console.log(`  ${passed ? '✅' : '❌'} ${check}`);
    });
    
    console.log('\n═══════════════════════════════════════════════════════════════\n');
}

console.log('✅ Script diagnostic chargé. Lancez: diagnosticComplet()');



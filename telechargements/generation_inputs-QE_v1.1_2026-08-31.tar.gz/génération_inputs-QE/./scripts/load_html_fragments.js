/**
 * Charge les fragments HTML externes (réduction de index.html).
 * Émet htmlFragmentsLoaded quand tous les montages sont prêts.
 */
(function () {
    'use strict';

    async function loadOne(mount) {
        var src = mount.getAttribute('data-fragment');
        if (!src) return;
        try {
            var resp = await fetch(src, { cache: 'no-cache' });
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            var html = await resp.text();
            var wrap = document.createElement('div');
            wrap.innerHTML = html.trim();
            var node = wrap.firstElementChild;
            if (!node) throw new Error('fragment vide : ' + src);
            mount.replaceWith(node);
        } catch (err) {
            console.error('❌ Fragment HTML:', src, err);
            mount.innerHTML = '<div class="alert alert-error" style="padding:12px;border-radius:8px;background:#fee2e2;color:#991b1b;">'
                + '❌ Fragment <code>' + src + '</code> non chargé — rechargez (Ctrl+F5).</div>';
        }
    }

    async function loadAllFragments() {
        var mounts = Array.prototype.slice.call(document.querySelectorAll('[data-fragment]'));
        if (!mounts.length) {
            window.__HTML_FRAGMENTS_LOADED__ = true;
            return;
        }
        await Promise.all(mounts.map(loadOne));
        window.__HTML_FRAGMENTS_LOADED__ = true;
    }

    window.loadHtmlFragments = loadAllFragments;

    function boot() {
        loadAllFragments().then(function () {
            document.dispatchEvent(new CustomEvent('htmlFragmentsLoaded'));
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();

// ═══════════════════════════════════════════════════════════════════════════
// ANALYSE AVANCÉE DES BANDES - Gap, Masse Effective, Transport
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Calcule les propriétés électroniques avancées depuis les données de bandes
 * @param {Array} bandsData - Données des bandes [band][k-point]
 * @param {Object} dosData - Données DOS {energy, dos}
 * @param {Array} pointsSpeciaux - Points spéciaux [{label, position}]
 * @returns {Object} Propriétés calculées
 */
function analyserProprietesElectroniques(bandsData, dosData, pointsSpeciaux = null) {
    const props = {
        fermi: 0,
        gap: {
            valeur: 0,
            type: 'direct',
            nature: 'Métal',
            kpoint_VBM: 0,
            kpoint_CBM: 0,
            energie_VBM: 0,
            energie_CBM: 0
        },
        masse_effective: {
            electrons: null,
            trous: null,
            anisotropie: null
        },
        transport: {
            vitesse_groupe_max: 0,
            anisotropie: 'Isotrope',
            directions: {}
        },
        optique: {
            transitions_directes: [],
            transitions_indirectes: []
        }
    };
    
    // 1. Extraire l'énergie de Fermi
    if (dosData && dosData.fermi !== undefined) {
        props.fermi = dosData.fermi;
    } else {
        // Estimer depuis les bandes (milieu entre HOMO et LUMO)
        let maxOccupe = -Infinity;
        let minVide = Infinity;
        
        for (const band of bandsData) {
            for (const energy of band) {
                if (energy <= 0 && energy > maxOccupe) maxOccupe = energy;
                if (energy > 0 && energy < minVide) minVide = energy;
            }
        }
        props.fermi = (maxOccupe + minVide) / 2;
    }
    
    // 2. Trouver VBM (Valence Band Maximum) et CBM (Conduction Band Minimum)
    let VBM = -Infinity;
    let CBM = Infinity;
    let kVBM = 0;
    let kCBM = 0;
    
    const nkpoints = bandsData[0].length;
    
    for (let k = 0; k < nkpoints; k++) {
        for (const band of bandsData) {
            const energy = band[k];
            
            // Bande de valence (occupée)
            if (energy <= props.fermi && energy > VBM) {
                VBM = energy;
                kVBM = k;
            }
            
            // Bande de conduction (vide)
            if (energy > props.fermi && energy < CBM) {
                CBM = energy;
                kCBM = k;
            }
        }
    }
    
    props.gap.energie_VBM = VBM;
    props.gap.energie_CBM = CBM;
    props.gap.kpoint_VBM = kVBM;
    props.gap.kpoint_CBM = kCBM;
    
    // 3. Calculer le gap
    const gap = CBM - VBM;
    props.gap.valeur = gap;
    
    // Type de gap (direct ou indirect)
    props.gap.type = (kVBM === kCBM) ? 'direct' : 'indirect';
    
    // 4. Déterminer la nature du matériau
    if (gap < 0.01) {
        props.gap.nature = 'Métal';
    } else if (gap < 0.5) {
        props.gap.nature = 'Semi-métal ou Semi-conducteur à très petit gap';
    } else if (gap < 2.0) {
        props.gap.nature = 'Semi-conducteur à petit gap';
    } else if (gap < 4.0) {
        props.gap.nature = 'Semi-conducteur à grand gap';
    } else {
        props.gap.nature = 'Isolant';
    }
    
    // 5. Calculer la masse effective
    // m* = ℏ² / (d²E/dk²)
    // On approxime par différences finies au voisinage de VBM et CBM
    
    // Masse effective des électrons (au CBM)
    if (kCBM > 0 && kCBM < nkpoints - 1) {
        const bandeCBM = bandsData.find(band => Math.abs(band[kCBM] - CBM) < 0.001);
        if (bandeCBM) {
            const E_minus = bandeCBM[kCBM - 1];
            const E_0 = bandeCBM[kCBM];
            const E_plus = bandeCBM[kCBM + 1];
            
            // d²E/dk² ≈ (E+ - 2E0 + E-) / dk²
            // Approximation: dk = 1 (unités arbitraires)
            const d2E_dk2 = E_plus - 2 * E_0 + E_minus;
            
            if (Math.abs(d2E_dk2) > 0.001) {
                // m* en unités de masse électronique (m_e)
                // Facteur de conversion approximatif
                props.masse_effective.electrons = 1.0 / Math.abs(d2E_dk2);
            }
        }
    }
    
    // Masse effective des trous (au VBM)
    if (kVBM > 0 && kVBM < nkpoints - 1) {
        const bandeVBM = bandsData.find(band => Math.abs(band[kVBM] - VBM) < 0.001);
        if (bandeVBM) {
            const E_minus = bandeVBM[kVBM - 1];
            const E_0 = bandeVBM[kVBM];
            const E_plus = bandeVBM[kVBM + 1];
            
            const d2E_dk2 = E_plus - 2 * E_0 + E_minus;
            
            if (Math.abs(d2E_dk2) > 0.001) {
                // Pour les trous, la courbure est négative
                props.masse_effective.trous = 1.0 / Math.abs(d2E_dk2);
            }
        }
    }
    
    // 6. Calculer la vitesse de groupe maximale
    // v_g = dE/dk
    let vitesseMax = 0;
    
    for (const band of bandsData) {
        for (let k = 0; k < nkpoints - 1; k++) {
            const dE = Math.abs(band[k + 1] - band[k]);
            const dk = 1; // unités arbitraires
            const vitesse = dE / dk;
            
            if (vitesse > vitesseMax) {
                vitesseMax = vitesse;
            }
        }
    }
    
    props.transport.vitesse_groupe_max = vitesseMax;
    
    // 7. Analyser l'anisotropie (si points spéciaux disponibles)
    if (pointsSpeciaux && pointsSpeciaux.length > 1) {
        const directions = {};
        
        for (let i = 0; i < pointsSpeciaux.length - 1; i++) {
            const p1 = pointsSpeciaux[i];
            const p2 = pointsSpeciaux[i + 1];
            const direction = `${p1.label} → ${p2.label}`;
            
            // Calculer la pente moyenne dans cette direction
            const k1 = Math.round(p1.position * (nkpoints - 1) / (pointsSpeciaux[pointsSpeciaux.length - 1].position));
            const k2 = Math.round(p2.position * (nkpoints - 1) / (pointsSpeciaux[pointsSpeciaux.length - 1].position));
            
            if (k1 >= 0 && k2 < nkpoints) {
                let penteMax = 0;
                
                for (const band of bandsData) {
                    const dE = Math.abs(band[k2] - band[k1]);
                    const dk = Math.abs(k2 - k1);
                    const pente = dk > 0 ? dE / dk : 0;
                    
                    if (pente > penteMax) {
                        penteMax = pente;
                    }
                }
                
                directions[direction] = penteMax;
            }
        }
        
        props.transport.directions = directions;
        
        // Déterminer si anisotrope
        const pentes = Object.values(directions);
        if (pentes.length > 1) {
            const penteMin = Math.min(...pentes);
            const penteMax = Math.max(...pentes);
            const ratio = penteMax / (penteMin + 0.001);
            
            if (ratio > 2) {
                props.transport.anisotropie = 'Fortement anisotrope';
            } else if (ratio > 1.5) {
                props.transport.anisotropie = 'Modérément anisotrope';
            } else {
                props.transport.anisotropie = 'Quasi-isotrope';
            }
        }
    }
    
    // 8. Identifier les transitions optiques possibles
    // Transitions directes (même k)
    for (let k = 0; k < nkpoints; k++) {
        const energiesK = bandsData.map(band => band[k]).sort((a, b) => a - b);
        
        // Trouver la plus haute bande occupée et la plus basse bande vide
        let maxOccupe = null;
        let minVide = null;
        
        for (const E of energiesK) {
            if (E <= props.fermi) maxOccupe = E;
            if (E > props.fermi && minVide === null) minVide = E;
        }
        
        if (maxOccupe !== null && minVide !== null) {
            const transition = minVide - maxOccupe;
            if (transition > 0 && transition < 10) { // Limiter aux transitions raisonnables
                props.optique.transitions_directes.push({
                    kpoint: k,
                    energie: transition,
                    E_initial: maxOccupe,
                    E_final: minVide
                });
            }
        }
    }
    
    // Garder seulement les transitions uniques (arrondir à 0.01 eV)
    const transitionsUniques = new Map();
    for (const t of props.optique.transitions_directes) {
        const key = Math.round(t.energie * 100) / 100;
        if (!transitionsUniques.has(key) || t.kpoint === kVBM) {
            transitionsUniques.set(key, t);
        }
    }
    props.optique.transitions_directes = Array.from(transitionsUniques.values())
        .sort((a, b) => a.energie - b.energie)
        .slice(0, 5); // Garder les 5 premières
    
    return props;
}

/**
 * Affiche les propriétés électroniques dans un panneau détaillé
 */
function afficherProprietesElectroniques(props, materiau) {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.9);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        overflow-y: auto;
    `;
    
    // Couleur selon la nature
    let couleurNature = '#10b981'; // Vert par défaut
    if (props.gap.nature.includes('Métal')) couleurNature = '#ef4444';
    else if (props.gap.nature.includes('Isolant')) couleurNature = '#3b82f6';
    else if (props.gap.nature.includes('grand gap')) couleurNature = '#8b5cf6';
    
    // Icône selon la nature
    let iconeNature = '⚡';
    if (props.gap.nature.includes('Métal')) iconeNature = '🔴';
    else if (props.gap.nature.includes('Isolant')) iconeNature = '🔵';
    else if (props.gap.nature.includes('grand gap')) iconeNature = '🟣';
    else if (props.gap.nature.includes('petit gap')) iconeNature = '🟢';
    
    modal.innerHTML = `
        <div style="background: white; border-radius: 15px; max-width: 1200px; width: 100%; padding: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.3); margin: 20px 0;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 3px solid ${couleurNature}; padding-bottom: 15px;">
                <h2 style="margin: 0; color: ${couleurNature};">📊 Analyse Électronique Complète - ${materiau}</h2>
                <button onclick="this.parentElement.parentElement.parentElement.remove()" style="background: none; border: none; font-size: 2em; cursor: pointer; color: #666;">×</button>
            </div>
            
            <!-- Carte principale: Nature du matériau -->
            <div style="background: linear-gradient(135deg, ${couleurNature} 0%, ${couleurNature}dd 100%); color: white; padding: 25px; border-radius: 12px; margin-bottom: 25px; text-align: center;">
                <div style="font-size: 3em; margin-bottom: 10px;">${iconeNature}</div>
                <h3 style="margin: 0 0 10px 0; font-size: 1.8em;">${props.gap.nature}</h3>
                <div style="font-size: 1.3em; opacity: 0.95;">
                    Gap ${props.gap.type}: <strong>${props.gap.valeur.toFixed(3)} eV</strong>
                </div>
            </div>
            
            <!-- Grille de propriétés -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin-bottom: 25px;">
                
                <!-- Énergie de Fermi -->
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px;">
                    <div style="font-size: 2em; margin-bottom: 10px;">⚡</div>
                    <div style="font-size: 0.9em; opacity: 0.9;">Énergie de Fermi</div>
                    <div style="font-size: 1.5em; font-weight: bold; margin-top: 5px;">${props.fermi.toFixed(3)} eV</div>
                </div>
                
                <!-- VBM -->
                <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 20px; border-radius: 10px;">
                    <div style="font-size: 2em; margin-bottom: 10px;">⬇️</div>
                    <div style="font-size: 0.9em; opacity: 0.9;">VBM (Valence Max)</div>
                    <div style="font-size: 1.5em; font-weight: bold; margin-top: 5px;">${props.gap.energie_VBM.toFixed(3)} eV</div>
                    <div style="font-size: 0.8em; opacity: 0.8; margin-top: 5px;">k-point: ${props.gap.kpoint_VBM}</div>
                </div>
                
                <!-- CBM -->
                <div style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; padding: 20px; border-radius: 10px;">
                    <div style="font-size: 2em; margin-bottom: 10px;">⬆️</div>
                    <div style="font-size: 0.9em; opacity: 0.9;">CBM (Conduction Min)</div>
                    <div style="font-size: 1.5em; font-weight: bold; margin-top: 5px;">${props.gap.energie_CBM.toFixed(3)} eV</div>
                    <div style="font-size: 0.8em; opacity: 0.8; margin-top: 5px;">k-point: ${props.gap.kpoint_CBM}</div>
                </div>
                
                <!-- Type de gap -->
                <div style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); color: white; padding: 20px; border-radius: 10px;">
                    <div style="font-size: 2em; margin-bottom: 10px;">${props.gap.type === 'direct' ? '↕️' : '↗️'}</div>
                    <div style="font-size: 0.9em; opacity: 0.9;">Type de Gap</div>
                    <div style="font-size: 1.5em; font-weight: bold; margin-top: 5px; text-transform: capitalize;">${props.gap.type}</div>
                    <div style="font-size: 0.8em; opacity: 0.8; margin-top: 5px;">${props.gap.type === 'direct' ? 'Bon pour optoélectronique' : 'Transition indirecte'}</div>
                </div>
                
            </div>
            
            <!-- Section Masse Effective -->
            <div style="background: #f0f9ff; border: 2px solid #3b82f6; border-radius: 12px; padding: 20px; margin-bottom: 25px;">
                <h3 style="color: #1e40af; margin: 0 0 15px 0; display: flex; align-items: center; gap: 10px;">
                    <span style="font-size: 1.5em;">⚖️</span>
                    Masse Effective (m*)
                </h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div style="background: white; padding: 15px; border-radius: 8px; border-left: 4px solid #3b82f6;">
                        <div style="color: #64748b; font-size: 0.9em; margin-bottom: 5px;">Électrons (m*<sub>e</sub>)</div>
                        <div style="font-size: 1.3em; font-weight: bold; color: #1e40af;">
                            ${props.masse_effective.electrons !== null ? props.masse_effective.electrons.toFixed(3) + ' m<sub>e</sub>' : 'Non calculable'}
                        </div>
                        <div style="font-size: 0.8em; color: #64748b; margin-top: 5px;">
                            ${props.masse_effective.electrons !== null ? (props.masse_effective.electrons < 0.5 ? '✅ Légère (haute mobilité)' : props.masse_effective.electrons < 1.5 ? '⚖️ Moyenne' : '⚠️ Lourde (faible mobilité)') : ''}
                        </div>
                    </div>
                    <div style="background: white; padding: 15px; border-radius: 8px; border-left: 4px solid #ec4899;">
                        <div style="color: #64748b; font-size: 0.9em; margin-bottom: 5px;">Trous (m*<sub>h</sub>)</div>
                        <div style="font-size: 1.3em; font-weight: bold; color: #be185d;">
                            ${props.masse_effective.trous !== null ? props.masse_effective.trous.toFixed(3) + ' m<sub>e</sub>' : 'Non calculable'}
                        </div>
                        <div style="font-size: 0.8em; color: #64748b; margin-top: 5px;">
                            ${props.masse_effective.trous !== null ? (props.masse_effective.trous < 0.5 ? '✅ Légère (haute mobilité)' : props.masse_effective.trous < 1.5 ? '⚖️ Moyenne' : '⚠️ Lourde (faible mobilité)') : ''}
                        </div>
                    </div>
                </div>
                <div style="margin-top: 15px; padding: 12px; background: #dbeafe; border-radius: 8px; font-size: 0.9em; color: #1e40af;">
                    <strong>💡 Interprétation:</strong> Une masse effective faible (< 0.5 m<sub>e</sub>) indique une haute mobilité des porteurs, 
                    favorable pour les applications électroniques rapides.
                </div>
            </div>
            
            <!-- Section Transport -->
            <div style="background: #fef3c7; border: 2px solid #f59e0b; border-radius: 12px; padding: 20px; margin-bottom: 25px;">
                <h3 style="color: #92400e; margin: 0 0 15px 0; display: flex; align-items: center; gap: 10px;">
                    <span style="font-size: 1.5em;">🚀</span>
                    Propriétés de Transport
                </h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                    <div style="background: white; padding: 15px; border-radius: 8px;">
                        <div style="color: #64748b; font-size: 0.9em; margin-bottom: 5px;">Vitesse de Groupe Max</div>
                        <div style="font-size: 1.3em; font-weight: bold; color: #92400e;">
                            ${props.transport.vitesse_groupe_max.toFixed(3)} eV/k
                        </div>
                    </div>
                    <div style="background: white; padding: 15px; border-radius: 8px;">
                        <div style="color: #64748b; font-size: 0.9em; margin-bottom: 5px;">Anisotropie</div>
                        <div style="font-size: 1.3em; font-weight: bold; color: #92400e;">
                            ${props.transport.anisotropie}
                        </div>
                    </div>
                </div>
                ${Object.keys(props.transport.directions).length > 0 ? `
                    <div style="background: white; padding: 15px; border-radius: 8px;">
                        <div style="color: #64748b; font-size: 0.9em; margin-bottom: 10px; font-weight: bold;">Vitesse par Direction:</div>
                        ${Object.entries(props.transport.directions).map(([dir, v]) => `
                            <div style="display: flex; justify-content: space-between; padding: 5px 0; border-bottom: 1px solid #f3f4f6;">
                                <span style="color: #475569;">${dir}</span>
                                <span style="font-weight: bold; color: #92400e;">${v.toFixed(3)} eV/k</span>
                            </div>
                        `).join('')}
                    </div>
                ` : ''}
            </div>
            
            <!-- Section Optique -->
            ${props.optique.transitions_directes.length > 0 ? `
                <div style="background: #f0fdf4; border: 2px solid #10b981; border-radius: 12px; padding: 20px; margin-bottom: 25px;">
                    <h3 style="color: #065f46; margin: 0 0 15px 0; display: flex; align-items: center; gap: 10px;">
                        <span style="font-size: 1.5em;">🌈</span>
                        Transitions Optiques Directes
                    </h3>
                    <div style="background: white; padding: 15px; border-radius: 8px;">
                        <table style="width: 100%; border-collapse: collapse;">
                            <tr style="background: #10b981; color: white;">
                                <th style="padding: 10px; text-align: left;">Énergie (eV)</th>
                                <th style="padding: 10px; text-align: left;">Longueur d'onde (nm)</th>
                                <th style="padding: 10px; text-align: left;">Domaine</th>
                            </tr>
                            ${props.optique.transitions_directes.map(t => {
                                const lambda = 1240 / t.energie; // λ (nm) = 1240 / E (eV)
                                let domaine = '';
                                if (lambda > 700) domaine = 'Infrarouge';
                                else if (lambda > 620) domaine = 'Rouge';
                                else if (lambda > 590) domaine = 'Orange';
                                else if (lambda > 570) domaine = 'Jaune';
                                else if (lambda > 495) domaine = 'Vert';
                                else if (lambda > 450) domaine = 'Bleu';
                                else if (lambda > 380) domaine = 'Violet';
                                else domaine = 'UV';
                                
                                return `
                                    <tr style="border-bottom: 1px solid #e5e7eb;">
                                        <td style="padding: 10px;">${t.energie.toFixed(3)}</td>
                                        <td style="padding: 10px;">${lambda.toFixed(1)}</td>
                                        <td style="padding: 10px; font-weight: bold;">${domaine}</td>
                                    </tr>
                                `;
                            }).join('')}
                        </table>
                    </div>
                    <div style="margin-top: 15px; padding: 12px; background: #d1fae5; border-radius: 8px; font-size: 0.9em; color: #065f46;">
                        <strong>💡 Applications:</strong> Ces transitions déterminent les propriétés d'absorption optique et 
                        les applications potentielles (LED, cellules solaires, détecteurs).
                    </div>
                </div>
            ` : ''}
            
            <!-- Boutons d'action -->
            <div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
                <button onclick="exporterAnalyseJSON('${materiau}')" class="btn" style="padding: 12px 24px; background: #3b82f6; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">
                    📥 Exporter JSON
                </button>
                <button onclick="exporterAnalyseTexte('${materiau}')" class="btn" style="padding: 12px 24px; background: #10b981; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">
                    📄 Exporter Texte
                </button>
                <button onclick="this.parentElement.parentElement.parentElement.remove()" class="btn" style="padding: 12px 24px; background: #6b7280; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold;">
                    ❌ Fermer
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Stocker les propriétés globalement pour l'export
    window.dernieresProprietesElectroniques = props;
}

/**
 * Exporte l'analyse en JSON
 */
function exporterAnalyseJSON(materiau) {
    if (!window.dernieresProprietesElectroniques) {
        afficherNotification('❌ Aucune analyse disponible', 'error');
        return;
    }
    
    const json = JSON.stringify(window.dernieresProprietesElectroniques, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${materiau}_analyse_electronique.json`;
    document.body.appendChild(a);
    a.click();
    URL.revokeObjectURL(url);
    a.remove();
    
    afficherNotification('📥 Analyse exportée en JSON', 'success');
}

/**
 * Exporte l'analyse en texte formaté
 */
function exporterAnalyseTexte(materiau) {
    if (!window.dernieresProprietesElectroniques) {
        afficherNotification('❌ Aucune analyse disponible', 'error');
        return;
    }
    
    const props = window.dernieresProprietesElectroniques;
    
    let texte = `═══════════════════════════════════════════════════════════════
ANALYSE ÉLECTRONIQUE COMPLÈTE - ${materiau}
═══════════════════════════════════════════════════════════════

1. NATURE DU MATÉRIAU
   Type: ${props.gap.nature}
   Gap: ${props.gap.valeur.toFixed(3)} eV (${props.gap.type})

2. ÉNERGIES CARACTÉRISTIQUES
   Énergie de Fermi: ${props.fermi.toFixed(3)} eV
   VBM (Valence Band Maximum): ${props.gap.energie_VBM.toFixed(3)} eV (k=${props.gap.kpoint_VBM})
   CBM (Conduction Band Minimum): ${props.gap.energie_CBM.toFixed(3)} eV (k=${props.gap.kpoint_CBM})

3. MASSE EFFECTIVE
   Électrons (m*e): ${props.masse_effective.electrons !== null ? props.masse_effective.electrons.toFixed(3) + ' me' : 'Non calculable'}
   Trous (m*h): ${props.masse_effective.trous !== null ? props.masse_effective.trous.toFixed(3) + ' me' : 'Non calculable'}

4. PROPRIÉTÉS DE TRANSPORT
   Vitesse de groupe max: ${props.transport.vitesse_groupe_max.toFixed(3)} eV/k
   Anisotropie: ${props.transport.anisotropie}
   
   Vitesses par direction:
${Object.entries(props.transport.directions).map(([dir, v]) => `   ${dir}: ${v.toFixed(3)} eV/k`).join('\n')}

5. TRANSITIONS OPTIQUES DIRECTES
${props.optique.transitions_directes.map(t => {
    const lambda = 1240 / t.energie;
    return `   ${t.energie.toFixed(3)} eV → ${lambda.toFixed(1)} nm`;
}).join('\n')}

═══════════════════════════════════════════════════════════════
Généré le: ${new Date().toLocaleString('fr-FR')}
═══════════════════════════════════════════════════════════════
`;
    
    const blob = new Blob([texte], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${materiau}_analyse_electronique.txt`;
    document.body.appendChild(a);
    a.click();
    URL.revokeObjectURL(url);
    a.remove();
    
    afficherNotification('📄 Analyse exportée en texte', 'success');
}

console.log('✅ Module d\'analyse avancée des bandes chargé');

/**
 * Charge data/hubbard_u_defaults.json (ou /api/hubbard/defaults) et pré-remplit U + manifold.
 */
(function () {
    'use strict';

    window.__hubbard_defaults_loaded = null;
    window.__hubbard_u_map = {};
    window.__hubbard_mf_map = {};

    function canonElement(sym) {
        var m = /^([A-Za-z]+)/.exec(String(sym == null ? '' : sym));
        if (!m) return '';
        var x = m[1];
        if (x.length === 1) return x.toUpperCase();
        return x.charAt(0).toUpperCase() + x.slice(1).toLowerCase();
    }

    /** Recherche U pour une étiquette d’espèce (ex. Ni1 → clé Ni du JSON). */
    function lookupU(map, sym) {
        var s = String(sym == null ? '' : sym);
        if (!s) return null;
        if (typeof map[s] === 'number') return map[s];
        var c = canonElement(s);
        if (c && typeof map[c] === 'number') return map[c];
        return null;
    }

    function lookupManifold(json, sym) {
        var s = String(sym == null ? '' : sym);
        if (!s || !json || typeof json !== 'object') return null;
        var meta = json[s];
        if (meta != null && typeof meta === 'object' && meta.manifold)
            return String(meta.manifold).trim() || null;
        var c = canonElement(s);
        if (c) {
            meta = json[c];
            if (meta != null && typeof meta === 'object' && meta.manifold)
                return String(meta.manifold).trim() || null;
        }
        return null;
    }

    function buildMap(json) {
        var m = {};
        if (!json || typeof json !== 'object') return m;
        Object.keys(json).forEach(function (k) {
            if (!k || k.charAt(0) === '_' || k === '_comment') return;
            var o = json[k];
            var uVal = null;
            if (o != null && typeof o === 'object' && typeof o.U === 'number') uVal = o.U;
            else if (typeof o === 'number') uVal = o;
            if (uVal != null && !isNaN(uVal)) m[k] = uVal;
        });
        return m;
    }

    window.ensureHubbardDefaultsLoaded = async function () {
        if (window.__hubbard_defaults_loaded !== null)
            return window.__hubbard_defaults_loaded;
        async function loadUrl(url) {
            var r = await fetch(url, { cache: 'no-store' });
            if (!r.ok) throw new Error(String(r.status));
            return r.json();
        }
        var j = {};
        try {
            var base = (typeof getGenInputsApiBase === 'function') ? getGenInputsApiBase() : '';
            if (base) j = await loadUrl(base + '/api/hubbard/defaults');
            else throw new Error('no_base');
        } catch (_) {
            try {
                j = await loadUrl('data/hubbard_u_defaults.json');
            } catch (__) {
                j = {};
            }
        }
        window.__hubbard_defaults_loaded = j;
        window.__hubbard_u_map = buildMap(j);
        window.__hubbard_mf_map = {};
        return j;
    };

    window.applyHubbardDefaultsFromDbToZone = async function (prefix) {
        var json = {};
        try {
            json = await window.ensureHubbardDefaultsLoaded();
        } catch (_eLd) {}
        var map = window.__hubbard_u_map || {};
        var zone = document.getElementById(prefix + '_hubbard_species_zone');
        if (!zone) return;
        zone.querySelectorAll('input[data-' + prefix + '-u]').forEach(function (inp) {
            var sym = inp.getAttribute('data-' + prefix + '-u');
            var raw = String(inp.value || '').trim();
            if (raw !== '' && raw !== '0') return;
            var vu = lookupU(map, sym);
            if (vu != null && !isNaN(vu)) inp.value = String(vu);
        });
        zone.querySelectorAll('select[data-' + prefix + '-mf]').forEach(function (sel) {
            var sym = sel.getAttribute('data-' + prefix + '-mf');
            var mfJson = lookupManifold(json, sym);
            if (mfJson) {
                sel.value = mfJson;
                return;
            }
            if (typeof window.defaultManifoldForSpecies === 'function') {
                var mfAuto = window.defaultManifoldForSpecies(sym);
                if (mfAuto) sel.value = mfAuto;
            }
        });
    };
})();

/**
 * Phase de Berry & charges effectives de Born — panneau workflow + paramètres.
 * Voies directe (#calc_type) et CIF (#cif_calc_type).
 */
(function () {
    'use strict';

    var POLAR_TYPES = {
        workflow: ['vc-relax'],
        berry: ['scf_berry'],
        bornScf: ['scf_born'],
        bornPh: ['ph_zeu']
    };

    function isCifConversionContext() {
        var zone = document.getElementById('editeur_cif_zone');
        if (zone) {
            try {
                var st = window.getComputedStyle(zone);
                if (st.display !== 'none' && st.visibility !== 'hidden') return true;
            } catch (_eSt) {
                if (zone.style.display !== 'none') return true;
            }
        }
        if (document.getElementById('polarization_workflow_panel_cif')) return true;
        var gest = document.getElementById('subsection_gestion');
        if (gest && gest.style.display !== 'none') return true;
        return false;
    }

    function pickCalcType() {
        if (isCifConversionContext()) {
            var cif = document.getElementById('cif_calc_type');
            var gestion = document.getElementById('gestion_cif_calc_type');
            if (cif && cif.value) return cif.value;
            if (gestion && gestion.value) return gestion.value;
        }
        var direct = document.getElementById('calc_type');
        var cif = document.getElementById('cif_calc_type');
        var gestion = document.getElementById('gestion_cif_calc_type');
        if (direct && direct.offsetParent !== null) return direct.value || '';
        if (cif && cif.offsetParent !== null) return cif.value || '';
        if (gestion && gestion.offsetParent !== null) return gestion.value || '';
        return (direct && direct.value) || (cif && cif.value) || '';
    }

    window.resolveCifCalculationType = function resolveCifCalculationType() {
        if (typeof window.pickCifUiControl === 'function') {
            try {
                var picked = window.pickCifUiControl('cif_calc_type', 'gestion_cif_calc_type', 'cif');
                if (picked && picked.value) return String(picked.value).trim();
            } catch (_ePick) {}
        }
        var el = document.getElementById('cif_calc_type') || document.getElementById('gestion_cif_calc_type');
        return (el && el.value) ? String(el.value).trim() : 'scf';
    };

    function panelHtml() {
        return ''
            + '<div id="polarization_workflow_panel" class="qe-polar-panel" style="display:none;margin:16px 0;padding:16px;border-radius:10px;border:2px solid #0ea5e9;background:linear-gradient(135deg,#f0f9ff,#ecfeff);">'
            + '  <h4 style="margin:0 0 10px;color:#0369a1;font-size:1.05em;">🔬 Workflow polarisation / charges de Born</h4>'
            + '  <pre id="polar_workflow_diagram" style="margin:0 0 14px;padding:12px;background:#fff;border:1px solid #bae6fd;border-radius:8px;font-size:0.78em;line-height:1.35;color:#0c4a6e;overflow-x:auto;">'
            + '[1] Structure → pw.x vc-relax\n'
            + '         ↓ coordonnées finales\n'
            + '    ┌────┴────┐\n'
            + '3A Berry    3B Born\n'
            + 'scf+lberry  scf (1.d-12) → ph.x zeu\n'
            + '  </pre>'
            + '  <p id="polar_workflow_hint" style="margin:0 0 12px;font-size:0.88em;color:#334155;line-height:1.45;"></p>'
            + '  <div id="polar_berry_fields" style="display:none;margin-top:10px;padding:12px;background:#fff;border-radius:8px;border:1px solid #7dd3fc;">'
            + '    <strong style="color:#0369a1;">Phase de Berry (pw.x SCF)</strong>'
            + '    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin-top:10px;">'
            + '      <label style="font-size:0.85em;">gdir (axe polarisation)<br>'
            + '        <select id="polar_gdir" style="width:100%;padding:8px;border:1px solid #7dd3fc;border-radius:6px;">'
            + '          <option value="1">1 — x</option><option value="2">2 — y</option><option value="3" selected>3 — z</option>'
            + '        </select></label>'
            + '      <label style="font-size:0.85em;">nppstr (points k le long des strings)<br>'
            + '        <input type="number" id="polar_nppstr" value="8" min="4" max="32" style="width:100%;padding:8px;border:1px solid #7dd3fc;border-radius:6px;"></label>'
            + '    </div>'
            + '    <small style="display:block;margin-top:8px;color:#64748b;">Namelist <code>&amp;BP</code> : lberry, gdir, nppstr — <strong>sans</strong> lelfield (methodes incompatibles).</small>'
            + '  </div>'
            + '  <div id="polar_born_scf_fields" style="display:none;margin-top:10px;padding:12px;background:#fff;border-radius:8px;border:1px solid #86efac;">'
            + '    <strong style="color:#166534;">SCF strict (préparation Born)</strong>'
            + '    <label style="display:block;margin-top:8px;font-size:0.85em;">conv_thr (&amp;ELECTRONS)<br>'
            + '      <input type="text" id="polar_born_conv_thr" value="1.0d-12" style="width:100%;max-width:220px;padding:8px;border:1px solid #86efac;border-radius:6px;"></label>'
            + '  </div>'
            + '  <div id="polar_born_ph_fields" style="display:none;margin-top:10px;padding:12px;background:#fff;border-radius:8px;border:1px solid #86efac;">'
            + '    <strong style="color:#166534;">ph.x — charges effectives (zeu)</strong>'
            + '    <label style="display:block;margin-top:8px;font-size:0.85em;">tr2_ph<br>'
            + '      <input type="text" id="polar_tr2_ph" value="1.0d-12" style="width:100%;max-width:220px;padding:8px;border:1px solid #86efac;border-radius:6px;"></label>'
            + '    <label style="display:flex;align-items:center;gap:8px;margin-top:8px;font-size:0.85em;">'
            + '      <input type="checkbox" id="polar_epsil" /> epsil = .true. (tensor diélectrique ε)</label>'
            + '  </div>'
            + '</div>';
    }

    function mountPanel(anchorEl) {
        if (!anchorEl || document.getElementById('polarization_workflow_panel')) return;
        var wrap = document.createElement('div');
        wrap.innerHTML = panelHtml();
        var panel = wrap.firstElementChild;
        if (panel) anchorEl.parentNode.insertBefore(panel, anchorEl.nextSibling);
    }

    window.qePolarizationMountPanels = function qePolarizationMountPanels() {
        var calcDirect = document.getElementById('calc_type');
        if (calcDirect && !document.getElementById('polarization_workflow_panel')) {
            mountPanel(calcDirect.closest('div') || calcDirect);
        }
        var cifCalc = document.getElementById('cif_calc_type');
        if (cifCalc && !document.getElementById('polarization_workflow_panel_cif')) {
            var wrap = document.createElement('div');
            wrap.innerHTML = panelHtml().replace('polarization_workflow_panel', 'polarization_workflow_panel_cif')
                .replace(/id="polar_/g, 'id="polar_cif_');
            var panel = wrap.firstElementChild;
            var fg = cifCalc.closest('.form-group');
            if (panel && fg && fg.parentNode) {
                fg.parentNode.insertBefore(panel, fg.nextSibling);
            } else if (panel && cifCalc.parentNode) {
                cifCalc.parentNode.appendChild(panel);
            }
        }
    };

    function activePanelIds() {
        var t = pickCalcType();
        var useCif = isCifConversionContext() || !!document.getElementById('polarization_workflow_panel_cif');
        if (useCif) {
            return {
                root: 'polarization_workflow_panel_cif',
                gdir: 'polar_cif_gdir',
                nppstr: 'polar_cif_nppstr',
                conv: 'polar_cif_born_conv_thr',
                tr2: 'polar_cif_tr2_ph',
                epsil: 'polar_cif_epsil',
                berryBox: 'polar_cif_berry_fields',
                bornScfBox: 'polar_cif_born_scf_fields',
                bornPhBox: 'polar_cif_born_ph_fields',
                hint: document.querySelector('#polarization_workflow_panel_cif #polar_cif_workflow_hint')
                    || document.getElementById('polar_cif_workflow_hint'),
                calc: t
            };
        }
        return {
            root: 'polarization_workflow_panel',
            gdir: 'polar_gdir',
            nppstr: 'polar_nppstr',
            conv: 'polar_born_conv_thr',
            tr2: 'polar_tr2_ph',
            epsil: 'polar_epsil',
            berryBox: 'polar_berry_fields',
            bornScfBox: 'polar_born_scf_fields',
            bornPhBox: 'polar_born_ph_fields',
            hint: document.getElementById('polar_workflow_hint'),
            calc: t
        };
    }

    window.qePolarizationUpdateVisibility = function qePolarizationUpdateVisibility(calcType) {
        qePolarizationMountPanels();
        var ids = activePanelIds();
        var calc = String(calcType || ids.calc || '').toLowerCase();
        var root = document.getElementById(ids.root);
        if (!root) return;

        var show = POLAR_TYPES.workflow.indexOf(calc) >= 0
            || POLAR_TYPES.berry.indexOf(calc) >= 0
            || POLAR_TYPES.bornScf.indexOf(calc) >= 0
            || POLAR_TYPES.bornPh.indexOf(calc) >= 0;

        root.style.display = show ? 'block' : 'none';

        var berryBox = document.getElementById(ids.berryBox);
        var bornScfBox = document.getElementById(ids.bornScfBox);
        var bornPhBox = document.getElementById(ids.bornPhBox);
        if (berryBox) berryBox.style.display = POLAR_TYPES.berry.indexOf(calc) >= 0 ? 'block' : 'none';
        if (bornScfBox) bornScfBox.style.display = POLAR_TYPES.bornScf.indexOf(calc) >= 0 ? 'block' : 'none';
        if (bornPhBox) bornPhBox.style.display = POLAR_TYPES.bornPh.indexOf(calc) >= 0 ? 'block' : 'none';

        var hintEl = ids.hint;
        if (hintEl) {
            if (calc === 'vc-relax') {
                hintEl.textContent = 'Étape 1 : optimisez la structure (positions + maille). '
                    + 'Ensuite générez scf_berry OU scf_born + ph_zeu avec les coordonnées finales.';
            } else if (calc === 'scf_berry') {
                hintEl.textContent = 'Étape 3A : exécutez après vc-relax convergé. '
                    + 'Utilisez restart_mode=restart si le SCF préalable existe (même prefix/outdir).';
            } else if (calc === 'scf_born') {
                hintEl.textContent = 'Étape 3B-1 : SCF très convergé (conv_thr=1.d-12). '
                    + 'Puis lancez ph_zeu avec le même prefix/outdir.';
            } else if (calc === 'ph_zeu') {
                hintEl.textContent = 'Étape 3B-2 : ph.x à Γ (ldisp=.false., zeu=.true.) — nécessite le SCF strict et les fichiers .save.';
            } else {
                hintEl.textContent = '';
            }
        }
    };

    window.qeCollectPolarizationOptionsForApi = function qeCollectPolarizationOptionsForApi(calcType) {
        var calc = String(calcType || pickCalcType() || '').toLowerCase();
        var ids = activePanelIds();
        var out = {};

        if (calc === 'scf_berry') {
            var gdirEl = document.getElementById(ids.gdir);
            var nppEl = document.getElementById(ids.nppstr)
                || document.getElementById(String(ids.nppstr).replace('nppstr', 'nberrycyc'));
            out.lberry = true;
            out.gdir = parseInt(gdirEl && gdirEl.value ? gdirEl.value : '3', 10) || 3;
            out.nppstr = parseInt(nppEl && nppEl.value ? nppEl.value : '8', 10) || 8;
        }
        if (calc === 'scf_born') {
            var ctEl = document.getElementById(ids.conv);
            out.conv_thr = (ctEl && ctEl.value) ? String(ctEl.value).trim() : '1.0d-12';
        }
        if (calc === 'ph_zeu') {
            var trEl = document.getElementById(ids.tr2);
            var epsEl = document.getElementById(ids.epsil);
            var trRaw = (trEl && trEl.value) ? String(trEl.value).trim().replace(/d/i, 'e') : '1.0e-12';
            out.tr2_ph = parseFloat(trRaw) || 1.0e-12;
            out.zeu = true;
            out.ldisp = false;
            if (epsEl && epsEl.checked) out.epsil = true;
        }
        return out;
    };

    /** Filet de sécurité : injecte &BP si le build API l'a omis. */
    window.qeInjectPolarizationIntoPwText = function qeInjectPolarizationIntoPwText(text, calcType) {
        if (!text || typeof text !== 'string') return text;
        var calc = String(calcType || pickCalcType() || '').toLowerCase();
        if (calc === 'scf_berry') {
            if (/^\s*&BP\b/im.test(text) && /\blberry\b/i.test(text)) return text;
            var pol = window.qeCollectPolarizationOptionsForApi('scf_berry');
            var block = [
                '',
                '! Phase de Berry — namelist &BP',
                '&BP',
                '  lberry = .true.',
                '  gdir   = ' + (pol.gdir || 3),
                '  nppstr = ' + (pol.nppstr || 8),
                '/'
            ].join('\n');
            var m = text.match(/^(\s*&ELECTRONS[\s\S]*?^\s*\/\s*$)/im);
            if (m) {
                return text.replace(m[0], m[0] + block);
            }
            return text + block;
        }
        if (calc === 'scf_born') {
            if (/conv_thr\s*=\s*1\.0d-12/i.test(text)) return text;
            var polBorn = window.qeCollectPolarizationOptionsForApi('scf_born');
            var ct = (polBorn && polBorn.conv_thr) ? polBorn.conv_thr : '1.0d-12';
            return text.replace(/(^\s*conv_thr\s*=\s*)([^\n]+)/im, '$1' + ct);
        }
        return text;
    };

    function hookCalcSelect(el) {
        if (!el || el.dataset.polarHooked) return;
        el.dataset.polarHooked = '1';
        el.addEventListener('change', function () {
            qePolarizationUpdateVisibility(el.value);
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        setTimeout(function () {
            qePolarizationMountPanels();
            hookCalcSelect(document.getElementById('calc_type'));
            hookCalcSelect(document.getElementById('cif_calc_type'));
            hookCalcSelect(document.getElementById('gestion_cif_calc_type'));
            qePolarizationUpdateVisibility(pickCalcType());
        }, 600);
    });

    document.addEventListener('tab1Restructured', function () {
        setTimeout(function () {
            qePolarizationMountPanels();
            qePolarizationUpdateVisibility(pickCalcType());
        }, 200);
    });

    document.addEventListener('htmlFragmentsLoaded', function () {
        setTimeout(function () {
            qePolarizationMountPanels();
            hookCalcSelect(document.getElementById('cif_calc_type'));
            hookCalcSelect(document.getElementById('gestion_cif_calc_type'));
            qePolarizationUpdateVisibility(pickCalcType());
        }, 120);
    });

    console.log('✅ Module polarisation Berry / Born chargé');
})();

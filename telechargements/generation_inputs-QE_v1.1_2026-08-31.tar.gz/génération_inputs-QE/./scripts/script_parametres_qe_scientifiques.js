/**
 * ═══════════════════════════════════════════════════════════════════════
 * PARAMÈTRES QUANTUM ESPRESSO - MODULE SCIENTIFIQUE
 * ═══════════════════════════════════════════════════════════════════════
 * 
 * Module pour la gestion intelligente des paramètres QE selon le type de calcul
 * avec recommandations scientifiques et extraction des paramètres optimisés
 */

console.log('📊 Module Paramètres QE Scientifiques chargé');

// ═══════════════════════════════════════════════════════════════════════
// BASE DE DONNÉES DES PARAMÈTRES PAR TYPE DE CALCUL
// ═══════════════════════════════════════════════════════════════════════

const PARAMETRES_PAR_TYPE = {
    'scf': {
        nom: 'SCF (Self-Consistent Field)',
        description: 'Calcul de l\'état fondamental électronique',
        parametres: {
            ecutwfc: { valeur: 50, min: 30, max: 100, recommande: '50-80 Ry' },
            ecutrho: { valeur: 400, min: 240, max: 800, recommande: '8-10 × ecutwfc' },
            conv_thr: { valeur: '1.0d-8', recommande: '1.0d-8 pour production, 1.0d-6 pour tests' },
            diagonalization: { valeur: 'david', options: ['david', 'cg', 'ppcg'] },
            mixing_beta: { valeur: 0.7, min: 0.1, max: 0.9, recommande: '0.7 (défaut), 0.3 si problèmes convergence' },
            mixing_mode: { valeur: 'plain', options: ['plain', 'TF', 'local-TF'] },
            electron_maxstep: { valeur: 100, min: 50, max: 200 }
        },
        conseils: [
            '💡 ecutwfc: Tester la convergence! Augmenter par pas de 10 Ry',
            '⚠️ ecutrho: Pour PAW ou US pseudos, ecutrho = 8-12 × ecutwfc',
            '🎯 conv_thr: 1d-8 donne précision de 10 µeV sur énergie totale',
            '🔧 Si non-convergence: Essayer diagonalization=\'cg\' et mixing_beta=0.3'
        ]
    },
    
    'relax': {
        nom: 'RELAX (Relaxation Ionique)',
        description: 'Optimisation des positions atomiques à volume constant',
        parametres: {
            ecutwfc: { valeur: 60, min: 40, max: 100, recommande: '60-80 Ry (plus élevé que SCF)' },
            ecutrho: { valeur: 480, min: 320, max: 800, recommande: '8-10 × ecutwfc' },
            conv_thr: { valeur: '1.0d-9', recommande: '1.0d-9 pour forces précises' },
            forc_conv_thr: { valeur: '1.0d-4', recommande: '1.0d-4 Ry/au (0.5 meV/Å)' },
            diagonalization: { valeur: 'david', options: ['david', 'cg'] },
            mixing_beta: { valeur: 0.5, min: 0.2, max: 0.7, recommande: '0.5 (plus stable pour relax)' },
            ion_dynamics: { valeur: 'bfgs', options: ['bfgs', 'damp'] },
            electron_maxstep: { valeur: 200, min: 100, max: 300 }
        },
        conseils: [
            '💡 conv_thr plus strict que SCF pour forces précises',
            '⚠️ forc_conv_thr: 1d-4 Ry/au = 0.5 meV/Å (bon compromis)',
            '🎯 BFGS: Méthode quasi-Newton, convergence rapide',
            '🔧 Si oscillations: Réduire mixing_beta à 0.3',
            '📊 SORTIE: Récupérer positions optimisées pour calcul SCF suivant'
        ]
    },
    
    'vc-relax': {
        nom: 'VC-RELAX (Relaxation Complète)',
        description: 'Optimisation positions + paramètres de maille',
        parametres: {
            ecutwfc: { valeur: 60, min: 40, max: 100, recommande: '60-80 Ry (bien convergé!)' },
            ecutrho: { valeur: 480, min: 320, max: 800, recommande: '8-10 × ecutwfc' },
            conv_thr: { valeur: '1.0d-9', recommande: '1.0d-9 ou 1.0d-10' },
            forc_conv_thr: { valeur: '1.0d-4', recommande: '1.0d-4 Ry/au' },
            press_conv_thr: { valeur: '0.5', recommande: '0.5 kbar (standard)' },
            diagonalization: { valeur: 'david', options: ['david', 'cg'] },
            mixing_beta: { valeur: 0.3, min: 0.2, max: 0.5, recommande: '0.3 (très stable)' },
            ion_dynamics: { valeur: 'bfgs', options: ['bfgs', 'damp'] },
            cell_dynamics: { valeur: 'bfgs', options: ['bfgs', 'damp-w', 'damp-pr'] },
            electron_maxstep: { valeur: 200, min: 100, max: 300 }
        },
        conseils: [
            '💡 ecutwfc DOIT être bien convergé (tester avant!)',
            '⚠️ press_conv_thr: 0.5 kbar = 50 MPa (pression résiduelle)',
            '🎯 vc-relax est COÛTEUX: Plusieurs cycles nécessaires',
            '🔧 Mixing_beta bas (0.3) pour stabilité',
            '📊 SORTIE: Récupérer a, b, c optimisés + positions pour SCF'
        ]
    },
    
    'nscf': {
        nom: 'NSCF (Non Self-Consistent)',
        description: 'Calcul bandes/DOS sur grille k dense',
        parametres: {
            ecutwfc: { valeur: 50, info: 'MÊME valeur que SCF!' },
            ecutrho: { valeur: 400, info: 'MÊME valeur que SCF!' },
            conv_thr: { valeur: '1.0d-10', recommande: '1.0d-10 pour DOS fin' },
            diagonalization: { valeur: 'david', options: ['david'] },
            mixing_beta: { valeur: 0.7, info: 'Non utilisé (lecture charge SCF)' },
            occupations: { valeur: 'tetrahedra', options: ['tetrahedra', 'smearing'] },
            electron_maxstep: { valeur: 100 }
        },
        conseils: [
            '⚠️ PRÉREQUIS: Doit utiliser même ecutwfc/ecutrho que SCF!',
            '💡 Lire densité électronique du calcul SCF (startingpot=\'file\')',
            '🎯 Grille k DENSE (ex: 24×24×24 pour DOS)',
            '📊 Pour bandes: Utiliser path k spécial (Γ-X-M-Γ...)'
        ]
    },
    
    'bands': {
        nom: 'BANDS (Structure de Bandes)',
        description: 'Calcul bandes le long chemin k',
        parametres: {
            ecutwfc: { valeur: 50, info: 'MÊME valeur que SCF!' },
            ecutrho: { valeur: 400, info: 'MÊME valeur que SCF!' },
            conv_thr: { valeur: '1.0d-10', recommande: '1.0d-10 pour bandes précises' },
            diagonalization: { valeur: 'david', options: ['david'] },
            electron_maxstep: { valeur: 100 }
        },
        conseils: [
            '⚠️ APRÈS nscf: bands.x pour tracer structure de bandes',
            '💡 Définir path haute symétrie (Γ-X-M-Γ-R...)',
            '🎯 Nombre de points k: 50-100 le long du path',
            '📊 Utiliser plotband.x ou pymatgen pour visualiser'
        ]
    },
    
    'md': {
        nom: 'MD (Dynamique Moléculaire)',
        description: 'Simulation dynamique ab-initio',
        parametres: {
            ecutwfc: { valeur: 40, min: 30, max: 60, recommande: '40-50 Ry (compromis vitesse)' },
            ecutrho: { valeur: 320, min: 240, max: 480, recommande: '8 × ecutwfc' },
            conv_thr: { valeur: '1.0d-7', recommande: '1.0d-7 (moins strict pour MD)' },
            diagonalization: { valeur: 'david', options: ['david', 'cg'] },
            mixing_beta: { valeur: 0.7, min: 0.5, max: 0.9 },
            ion_temperature: { valeur: 'rescaling', options: ['rescaling', 'rescale-v', 'berendsen'] },
            tempw: { valeur: 300, min: 0, max: 3000, recommande: 'Température cible (K)' },
            dt: { valeur: 20, min: 10, max: 50, recommande: '20-40 a.u. (0.5-1 fs)' },
            nstep: { valeur: 1000, min: 100, max: 10000, recommande: 'Nombre de pas MD' },
            electron_maxstep: { valeur: 100 }
        },
        conseils: [
            '💡 MD ab-initio: TRÈS coûteux (réduire ecutwfc si nécessaire)',
            '⚠️ dt: 1 u.a. = 0.024 fs → dt=40 a.u. ≈ 1 fs',
            '🎯 Thermostat rescaling: Simple et efficace',
            '🔧 Pour équilibration: 1000-5000 pas minimum',
            '📊 Production: 10000-50000 pas pour statistiques'
        ]
    }
};

// ═══════════════════════════════════════════════════════════════════════
// RECOMMANDATIONS SCIENTIFIQUES PAR PARAMÈTRE
// ═══════════════════════════════════════════════════════════════════════

const EXPLICATIONS_PARAMETRES = {
    ecutwfc: {
        titre: 'ecutwfc - Cutoff Énergie Ondes Planes',
        description: 'Énergie cinétique maximale pour les ondes planes (base de calcul DFT)',
        unite: 'Rydberg (Ry) | 1 Ry = 13.6 eV',
        importance: 'CRITIQUE - Détermine la précision du calcul',
        recommandations: [
            '✅ Pseudos Norm-Conserving: 60-100 Ry',
            '✅ Pseudos Ultrasoft (US): 30-50 Ry',
            '✅ PAW (Projector Augmented Wave): 40-80 Ry',
            '⚠️ TOUJOURS tester la convergence!',
            '📈 Test: Augmenter par pas de 10 Ry jusqu\'à ΔE < 1 meV'
        ],
        impact: 'Énergie totale, forces, contraintes, gaps'
    },
    
    ecutrho: {
        titre: 'ecutrho - Cutoff Densité de Charge',
        description: 'Cutoff pour densité électronique et potentiel',
        unite: 'Rydberg (Ry)',
        importance: 'Important pour pseudos US et PAW',
        recommandations: [
            '✅ Norm-Conserving: ecutrho = 4 × ecutwfc (minimum)',
            '✅ Ultrasoft/PAW: ecutrho = 8-12 × ecutwfc',
            '⚠️ Valeur par défaut si non spécifié: 4 × ecutwfc',
            '🎯 Pour PAW: Toujours définir explicitement!'
        ],
        impact: 'Précision forces, contraintes, énergie totale'
    },
    
    conv_thr: {
        titre: 'conv_thr - Seuil de Convergence SCF',
        description: 'Critère de convergence du cycle auto-cohérent',
        unite: 'Ry (différence énergie totale entre itérations)',
        importance: 'Détermine précision énergie et forces',
        recommandations: [
            '✅ Tests rapides: 1.0d-6 (précision ~0.1 meV)',
            '✅ Production SCF: 1.0d-8 (précision ~10 µeV)',
            '✅ Relaxation: 1.0d-9 (forces précises)',
            '✅ Phonons/Perturbations: 1.0d-10 ou plus strict',
            '⚠️ Plus strict = plus d\'itérations!'
        ],
        impact: 'Temps calcul, précision énergie/forces'
    },
    
    forc_conv_thr: {
        titre: 'forc_conv_thr - Seuil Forces (RELAX)',
        description: 'Force maximale résiduelle pour convergence géométrique',
        unite: 'Ry/bohr | 1.0d-4 Ry/bohr ≈ 0.5 meV/Å',
        importance: 'CRITIQUE pour relaxation géométrique',
        recommandations: [
            '✅ Standard: 1.0d-4 Ry/bohr (0.5 meV/Å)',
            '✅ Haute précision: 1.0d-5 Ry/bohr',
            '✅ Phonons après relax: 1.0d-5 minimum',
            '⚠️ Trop strict → Convergence très lente'
        ],
        impact: 'Qualité structure optimisée, temps calcul'
    },
    
    press_conv_thr: {
        titre: 'press_conv_thr - Seuil Pression (VC-RELAX)',
        description: 'Pression résiduelle maximale pour vc-relax',
        unite: 'kbar | 1 kbar = 100 MPa = 0.1 GPa',
        importance: 'Important pour relaxation de maille',
        recommandations: [
            '✅ Standard: 0.5 kbar (50 MPa)',
            '✅ Haute précision: 0.1 kbar (10 MPa)',
            '⚠️ Pression atmosphérique: 0.001 kbar',
            '🎯 Pour cristaux sous pression: Ajuster en conséquence'
        ],
        impact: 'Paramètres de maille optimisés'
    }
};

// ═══════════════════════════════════════════════════════════════════════
// FONCTION: AJUSTER PARAMÈTRES SELON TYPE DE CALCUL
// ═══════════════════════════════════════════════════════════════════════

function ajusterParametresSelonType(typeCalcul) {
    console.log(`🔧 Ajustement paramètres pour type: ${typeCalcul}`);
    
    const config = PARAMETRES_PAR_TYPE[typeCalcul];
    if (!config) {
        console.warn(`⚠️ Type de calcul inconnu: ${typeCalcul}`);
        return;
    }
    
    // Mettre à jour les champs
    Object.keys(config.parametres).forEach(param => {
        const element = document.getElementById(param);
        if (element && config.parametres[param].valeur !== undefined) {
            element.value = config.parametres[param].valeur;
            console.log(`  ✓ ${param} = ${config.parametres[param].valeur}`);
        }
    });
    
    // Afficher recommandations
    afficherRecommandations(typeCalcul, config);
}

// ═══════════════════════════════════════════════════════════════════════
// FONCTION: AFFICHER RECOMMANDATIONS
// ═══════════════════════════════════════════════════════════════════════

function afficherRecommandations(typeCalcul, config) {
    console.log('📋 Affichage recommandations...');
    
    // Trouver ou créer le conteneur de recommandations
    let recContainer = document.getElementById('recommandations_container');
    if (!recContainer) {
        recContainer = document.createElement('div');
        recContainer.id = 'recommandations_container';
        recContainer.style.cssText = 'margin: 20px 0;';
        
        // Insérer après le sélecteur de type de calcul
        const typeSelect = document.getElementById('calc_type');
        if (typeSelect && typeSelect.parentElement) {
            typeSelect.parentElement.insertAdjacentElement('afterend', recContainer);
        }
    }
    
    recContainer.innerHTML = `
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; margin: 20px 0; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);">
            <h3 style="margin: 0 0 10px 0; font-size: 1.3em;">
                📊 ${config.nom}
            </h3>
            <p style="margin: 0 0 15px 0; opacity: 0.95; font-size: 1.05em;">
                ${config.description}
            </p>
            
            <div style="background: rgba(255,255,255,0.15); padding: 15px; border-radius: 8px; backdrop-filter: blur(10px);">
                <h4 style="margin: 0 0 10px 0; font-size: 1.1em;">💡 Recommandations Spécifiques:</h4>
                <ul style="margin: 0; padding-left: 20px; line-height: 1.8;">
                    ${config.conseils.map(conseil => `<li>${conseil}</li>`).join('')}
                </ul>
            </div>
        </div>
    `;
}

// ═══════════════════════════════════════════════════════════════════════
// FONCTION: EXTRAIRE PARAMÈTRES OPTIMISÉS (RELAX/VC-RELAX)
// ═══════════════════════════════════════════════════════════════════════

function extraireParametresOptimises(outputContent) {
    console.log('🔍 Extraction paramètres optimisés depuis output...');
    
    const resultats = {
        success: false,
        typeOptimisation: null,
        celldm: {},
        positions: [],
        energie: null,
        forces: [],
        pression: null
    };
    
    try {
        // Détecter le type d'optimisation
        if (outputContent.includes('vc-relax')) {
            resultats.typeOptimisation = 'vc-relax';
        } else if (outputContent.includes('relax')) {
            resultats.typeOptimisation = 'relax';
        }
        
        // Extraire paramètres de maille finaux (vc-relax)
        const celldmMatch = outputContent.match(/CELL_PARAMETERS[\s\S]*?([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)/);
        if (celldmMatch) {
            resultats.celldm.a = parseFloat(celldmMatch[1]);
            resultats.celldm.b = parseFloat(celldmMatch[2]);
            resultats.celldm.c = parseFloat(celldmMatch[3]);
        }
        
        // Extraire positions atomiques finales
        const positionsSection = outputContent.match(/Begin final coordinates[\s\S]*?ATOMIC_POSITIONS.*?\n([\s\S]*?)End final coordinates/);
        if (positionsSection) {
            const lines = positionsSection[1].trim().split('\n');
            lines.forEach(line => {
                const match = line.match(/(\w+)\s+([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)/);
                if (match) {
                    resultats.positions.push({
                        element: match[1],
                        x: parseFloat(match[2]),
                        y: parseFloat(match[3]),
                        z: parseFloat(match[4])
                    });
                }
            });
        }
        
        // Extraire énergie finale
        const energieMatch = outputContent.match(/!\s+total energy\s+=\s+([-\d.]+)\s+Ry/);
        if (energieMatch) {
            resultats.energie = parseFloat(energieMatch[1]);
        }
        
        // Extraire pression finale (vc-relax)
        const pressionMatch = outputContent.match(/total\s+stress.*?P=\s+([-\d.]+)/);
        if (pressionMatch) {
            resultats.pression = parseFloat(pressionMatch[1]);
        }
        
        resultats.success = resultats.positions.length > 0;
        
    } catch (error) {
        console.error('❌ Erreur extraction:', error);
    }
    
    return resultats;
}

// ═══════════════════════════════════════════════════════════════════════
// FONCTION: AFFICHER PARAMÈTRES OPTIMISÉS
// ═══════════════════════════════════════════════════════════════════════

function afficherParametresOptimises(resultats) {
    console.log('📊 Affichage paramètres optimisés...');
    
    if (!resultats.success) {
        console.warn('⚠️ Pas de paramètres optimisés disponibles');
        return;
    }
    
    // Créer modal d'affichage
    const modal = document.createElement('div');
    modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 10000; padding: 20px; overflow-y: auto;';
    
    let html = `
        <div style="max-width: 900px; margin: 50px auto; background: white; padding: 30px; border-radius: 15px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
            <h2 style="color: #667eea; margin-top: 0;">📊 Paramètres Optimisés (${resultats.typeOptimisation.toUpperCase()})</h2>
            
            <div style="background: #e8f5e9; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #4caf50;">
                <strong>✅ Optimisation Terminée!</strong><br>
                Utilisez ces paramètres pour un calcul SCF précis sur la structure relaxée.
            </div>
    `;
    
    // Paramètres de maille (vc-relax)
    if (resultats.celldm && Object.keys(resultats.celldm).length > 0) {
        html += `
            <h3 style="color: #764ba2;">📐 Paramètres de Maille Optimisés</h3>
            <div style="background: #f5f5f5; padding: 15px; border-radius: 8px; font-family: 'Courier New', monospace;">
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
                    <div><strong>a:</strong> ${resultats.celldm.a?.toFixed(6)} bohr</div>
                    <div><strong>b:</strong> ${resultats.celldm.b?.toFixed(6)} bohr</div>
                    <div><strong>c:</strong> ${resultats.celldm.c?.toFixed(6)} bohr</div>
                </div>
            </div>
            <button onclick="copierParametresMaille()" style="margin: 10px 0; padding: 10px 20px; background: #2196f3; color: white; border: none; border-radius: 5px; cursor: pointer;">
                📋 Copier Paramètres de Maille
            </button>
        `;
    }
    
    // Positions atomiques
    if (resultats.positions.length > 0) {
        html += `
            <h3 style="color: #764ba2;">📍 Positions Atomiques Optimisées</h3>
            <div style="background: #f5f5f5; padding: 15px; border-radius: 8px; font-family: 'Courier New', monospace; max-height: 300px; overflow-y: auto;">
                <pre id="positions_optimisees" style="margin: 0; white-space: pre;">ATOMIC_POSITIONS crystal\n${resultats.positions.map(p => `${p.element}  ${p.x.toFixed(9)}  ${p.y.toFixed(9)}  ${p.z.toFixed(9)}`).join('\n')}</pre>
            </div>
            <button onclick="copierPositions()" style="margin: 10px 0; padding: 10px 20px; background: #2196f3; color: white; border: none; border-radius: 5px; cursor: pointer;">
                📋 Copier Positions Atomiques
            </button>
        `;
    }
    
    // Informations énergétiques
    html += `
        <h3 style="color: #764ba2;">⚡ Informations Énergétiques</h3>
        <div style="background: #f5f5f5; padding: 15px; border-radius: 8px;">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                ${resultats.energie ? `<div><strong>Énergie Totale:</strong> ${resultats.energie.toFixed(6)} Ry</div>` : ''}
                ${resultats.pression ? `<div><strong>Pression:</strong> ${resultats.pression.toFixed(2)} kbar</div>` : ''}
            </div>
        </div>
    `;
    
    html += `
            <div style="margin-top: 25px; text-align: right;">
                <button onclick="this.parentElement.parentElement.parentElement.remove()" style="padding: 10px 30px; background: #667eea; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold;">
                    ✅ Fermer
                </button>
            </div>
        </div>
    `;
    
    modal.innerHTML = html;
    document.body.appendChild(modal);
}

// Fonctions utilitaires pour copier
window.copierParametresMaille = function() {
    const text = document.querySelector('#positions_optimisees')?.textContent || '';
    navigator.clipboard.writeText(text).then(() => {
        alert('✅ Paramètres de maille copiés!');
    });
};

window.copierPositions = function() {
    const text = document.getElementById('positions_optimisees')?.textContent || '';
    navigator.clipboard.writeText(text).then(() => {
        alert('✅ Positions atomiques copiées!');
    });
};

console.log('✅ Module Paramètres QE Scientifiques prêt');







// =============================================================================
// SCRIPT API AUTOSTART - VERSION STANDALONE (DÉSACTIVÉ)
// Ce script ne fait rien en mode standalone
// =============================================================================

console.log('%c✅ Mode Standalone - Vérifications API désactivées', 'color: lime; font-size: 14px; font-weight: bold;');

// Ne rien faire - pas de vérification d'API
window.verifierAPI = function() { return Promise.resolve(false); };
window.afficherInstructionsDetaillees = function() { 
    alert('💡 Mode Standalone\n\nPour lancer un calcul:\n1. Téléchargez l\'input (📥)\n2. Terminal: pw.x < input.in > output.out');
};
window.apiStatus = { online: false, lastCheck: null, checkCount: 0 };

// Ne jamais afficher le panneau d'erreur
function afficherPanneauAPIHorsLigne() { /* Ne rien faire */ }
function masquerPanneauAPIHorsLigne() { /* Ne rien faire */ }
function demarrerVerificationPeriodique() { /* Ne rien faire */ }

console.log('✅ Script API autostart désactivé (mode standalone)');

// ═══════════════════════════════════════════════════════════════════════════
// DIAGNOSTIC - VÉRIFICATION DES STRUCTURES ET POSITIONS
// ═══════════════════════════════════════════════════════════════════════════

console.log('🔍 DIAGNOSTIC STRUCTURES ET POSITIONS');

// 1. Vérifier que STRUCTURES_POSITIONS existe
console.log('\n=== VÉRIFICATION STRUCTURES_POSITIONS ===');
if (typeof STRUCTURES_POSITIONS !== 'undefined') {
    console.log('✅ STRUCTURES_POSITIONS chargée');
    console.log('Structures disponibles:', Object.keys(STRUCTURES_POSITIONS));
    
    // Vérifier chaque structure
    Object.keys(STRUCTURES_POSITIONS).forEach(ibrav => {
        const struct = STRUCTURES_POSITIONS[ibrav];
        console.log(`\nibrav ${ibrav}: ${struct.name}`);
        console.log(`  - Positions: ${struct.positions.length}`);
        if (struct.positions.length > 0) {
            console.log(`  - Première: [${struct.positions[0][0]}, ${struct.positions[0][1]}, ${struct.positions[0][2]}]`);
        }
    });
} else {
    console.error('❌ STRUCTURES_POSITIONS NOT FOUND');
}

// 2. Vérifier les paramètres cristallins
console.log('\n=== VÉRIFICATION STRUCTURES_CRISTALLINES_COMPLETE ===');
if (typeof STRUCTURES_CRISTALLINES_COMPLETE !== 'undefined') {
    console.log('✅ STRUCTURES_CRISTALLINES_COMPLETE chargée');
    
    // Vérifier ibrav 4 (Hexagonal)
    const hex = STRUCTURES_CRISTALLINES_COMPLETE['4'];
    if (hex) {
        console.log('\nibrav 4 - Hexagonal:');
        console.log('  Angles:', hex.angles);
        console.log('  Paramètres:', hex.params.map(p => p.id));
        console.log('  Paramètres internes:', hex.parametres_internes.map(p => p.id));
    }
} else {
    console.error('❌ STRUCTURES_CRISTALLINES_COMPLETE NOT FOUND');
}

// 3. Tester la génération des positions
console.log('\n=== TEST GÉNÉRATION POSITIONS ===');
setTimeout(() => {
    const ibrav = document.getElementById('ibrav');
    const nat = document.getElementById('nat');
    
    if (ibrav && nat) {
        // Tester avec ibrav=2 (BCC), nat=2
        ibrav.value = '2';
        nat.value = '2';
        
        const struct = STRUCTURES_POSITIONS['2'];
        console.log(`\nTest: ibrav=2 (${struct.name}), nat=2`);
        console.log('Positions à générer:');
        for (let i = 1; i <= 2; i++) {
            const posIdx = (i - 1) % struct.positions.length;
            const pos = struct.positions[posIdx];
            console.log(`  Atome ${i}: [${pos[0]}, ${pos[1]}, ${pos[2]}]`);
        }
    }
}, 500);

// 4. Lister tous les scripts chargés
console.log('\n=== SCRIPTS CHARGÉS ===');
const scripts = document.querySelectorAll('script[src]');
scripts.forEach(script => {
    const src = script.src.split('/').pop();
    console.log(`  ✓ ${src}`);
});

console.log('\n✅ DIAGNOSTIC COMPLET');



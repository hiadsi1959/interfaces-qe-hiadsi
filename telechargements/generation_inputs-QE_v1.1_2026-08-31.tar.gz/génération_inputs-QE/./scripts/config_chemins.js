// ═══════════════════════════════════════════════════════════════════════════
// CONFIGURATION DES CHEMINS — Générateur_Inputs-QE
// ═══════════════════════════════════════════════════════════════════════════
// Chemins chargés depuis localStorage (persistants entre sessions).
// Modifiables via le panneau "⚙️ Configuration des Chemins" de l'interface.
// ═══════════════════════════════════════════════════════════════════════════

(function() {
    'use strict';

    // ── Valeurs par défaut (portables — remplies par CONFIGURER.sh → config_pc_local.js) ──
    var DEFAULTS = {
        INPUTS_DIRECT_DIR  : '',
        INPUTS_CIF_DIR     : '',
        INPUTS_GENERES_DIR : '',
        INPUTS_DIR         : '',
        OUTPUTS_DIR        : '',
        PSEUDO_DIR         : '',
        PSEUDO_FR_DIR      : '',
        CIF_DIR            : '',
        QE_BIN_DIR         : '',
        WORK_DIR           : '',
        AUTO_REFRESH_INTERVAL : 3000,
        AUTO_START_API     : true
    };

    if (typeof window !== 'undefined' && window.QE_CONFIG_PRELOAD && typeof window.QE_CONFIG_PRELOAD === 'object') {
        DEFAULTS = Object.assign({}, DEFAULTS, window.QE_CONFIG_PRELOAD);
    }

    function _projectBaseFromDefaults() {
        if (DEFAULTS.WORK_DIR) return String(DEFAULTS.WORK_DIR).replace(/\/+$/, '');
        var d = String(DEFAULTS.INPUTS_DIRECT_DIR || DEFAULTS.INPUTS_GENERES_DIR || '');
        return d.replace(/\/inputs_g[eé]n[eé]r[eé]s_direct\/?$/i, '').replace(/\/+$/, '');
    }

    if (typeof window !== 'undefined' && window.__GEN_INPUTS_STANDALONE__) {
        var _base = _projectBaseFromDefaults();
        if (_base) {
            if (!DEFAULTS.INPUTS_DIRECT_DIR) DEFAULTS.INPUTS_DIRECT_DIR = _base + '/inputs_générés_direct';
            if (!DEFAULTS.INPUTS_CIF_DIR) DEFAULTS.INPUTS_CIF_DIR = _base + '/inputs_convertis_cif';
            if (!DEFAULTS.INPUTS_GENERES_DIR) DEFAULTS.INPUTS_GENERES_DIR = DEFAULTS.INPUTS_DIRECT_DIR;
            if (!DEFAULTS.INPUTS_DIR) DEFAULTS.INPUTS_DIR = DEFAULTS.INPUTS_DIRECT_DIR;
            if (!DEFAULTS.OUTPUTS_DIR) DEFAULTS.OUTPUTS_DIR = _base + '/outputs';
            if (!DEFAULTS.PSEUDO_DIR) DEFAULTS.PSEUDO_DIR = _base + '/pseudos/PBE';
            if (!DEFAULTS.PSEUDO_FR_DIR) DEFAULTS.PSEUDO_FR_DIR = _base + '/pseudos/PBE_FR';
            if (!DEFAULTS.CIF_DIR) DEFAULTS.CIF_DIR = _base + '/data';
            if (!DEFAULTS.WORK_DIR) DEFAULTS.WORK_DIR = _base;
        }
        DEFAULTS.AUTO_START_API = false;
    }

    // ── Charger depuis localStorage ──
    var stored = {};
    try {
        var raw = localStorage.getItem('qe_inputs_config');
        if (raw) stored = JSON.parse(raw);
    } catch(e) {}

    // Priorité : assistant qe_paths_setup.js (QE_CONFIG) > localStorage > défauts
    var unified = (typeof window.QE_CONFIG !== 'undefined' && window.QE_CONFIG && window.QE_CONFIG.WORK_DIR)
        ? Object.assign({}, window.QE_CONFIG) : null;
    window.QE_CONFIG = Object.assign({}, DEFAULTS, stored, unified || {});
    window.QE_DEFAULTS = Object.assign({}, DEFAULTS);

    /** En mode autonome, ignorer les chemins d'un autre PC laissés dans localStorage. */
    if (typeof window !== 'undefined' && window.__GEN_INPUTS_STANDALONE__) {
        var _localRoot = String(window.QE_DEFAULTS.WORK_DIR || _projectBaseFromDefaults() || '');
        function _looksForeignPath(p) {
            var s = String(p || '');
            if (!s) return false;
            if (/Interface-QE_v1/i.test(s) || /\/fichiers_cif\/?$/i.test(s)) return true;
            if (/^\/home\/hiadsi\//i.test(s)) return true;
            if (_localRoot && s.indexOf(_localRoot) !== 0) return true;
            return false;
        }
        ['CIF_DIR', 'PSEUDO_DIR', 'PSEUDO_FR_DIR', 'OUTPUTS_DIR', 'WORK_DIR',
         'INPUTS_DIRECT_DIR', 'INPUTS_CIF_DIR', 'INPUTS_GENERES_DIR', 'INPUTS_DIR', 'QE_BIN_DIR'
        ].forEach(function (key) {
            if (_looksForeignPath(window.QE_CONFIG[key])) {
                window.QE_CONFIG[key] = window.QE_DEFAULTS[key] || '';
            }
        });
        window.QE_CONFIG.INPUTS_DIR = window.QE_CONFIG.INPUTS_GENERES_DIR;
    }

    // ── API (ne pas écraser si qe_paths_setup.js a défini les ports) ──
    if (typeof window.QE_API_PORT === 'undefined') {
        window.QE_API_PORT = 5007;
    }
    if (typeof window.QE_API_URL === 'undefined') {
        window.QE_API_URL = 'http://localhost:' + window.QE_API_PORT;
    }

    if (typeof window !== 'undefined' && window.__GEN_INPUTS_STANDALONE__) {
        try {
            if (window.location && window.location.origin && window.location.protocol.indexOf('http') === 0) {
                window.QE_API_URL = window.location.origin;
                window.QE_API_PORT = parseInt(String(window.location.port || '5012'), 10) || 5012;
            } else {
                window.QE_API_PORT = 5012;
                window.QE_API_URL = 'http://127.0.0.1:5012';
            }
        } catch (e1) {
            window.QE_API_PORT = 5012;
            window.QE_API_URL = 'http://127.0.0.1:5012';
        }
    }

    // ── Fonctions UI ──
    window.sauvegarderConfig = function() {
        var cfg = {
            INPUTS_GENERES_DIR : (document.getElementById('cfg_inputs')  ||{}).value || window.QE_CONFIG.INPUTS_GENERES_DIR,
            OUTPUTS_DIR        : (document.getElementById('cfg_outputs') ||{}).value || window.QE_CONFIG.OUTPUTS_DIR,
            PSEUDO_DIR         : (document.getElementById('cfg_pseudos') ||{}).value || window.QE_CONFIG.PSEUDO_DIR,
            CIF_DIR            : (document.getElementById('cfg_cif')     ||{}).value || window.QE_CONFIG.CIF_DIR,
            QE_BIN_DIR         : (document.getElementById('cfg_qe_bin')  ||{}).value || window.QE_CONFIG.QE_BIN_DIR,
        };
        cfg.INPUTS_DIR = cfg.INPUTS_GENERES_DIR;
        cfg.WORK_DIR   = cfg.INPUTS_GENERES_DIR.replace(/\/inputs_g[eé]n[eé]r[eé]s\/?$/,'').replace(/\/inputs\/?$/,'');
        try { localStorage.setItem('qe_inputs_config', JSON.stringify(cfg)); } catch(e) { alert('Erreur: '+e.message); return; }
        Object.assign(window.QE_CONFIG, cfg);
        var msg = document.getElementById('cfg_save_msg');
        if (msg) { msg.style.display='inline'; setTimeout(function(){ msg.style.display='none'; },2500); }
        var badge = document.getElementById('config_status_badge');
        if (badge) { badge.textContent='● sauvegardé'; badge.style.background='#064e3b'; badge.style.color='#6ee7b7'; }
    };

    window.reinitialiserConfig = function() {
        if (!confirm('Réinitialiser les chemins aux valeurs par défaut ?')) return;
        try { localStorage.removeItem('qe_inputs_config'); } catch(e) {}
        Object.assign(window.QE_CONFIG, DEFAULTS);
        window.remplirChampsConfig();
        var badge = document.getElementById('config_status_badge');
        if (badge) { badge.textContent='● défaut'; badge.style.background='#1e1b4b'; badge.style.color='#a5b4fc'; }
    };

    window.remplirChampsConfig = function() {
        var map = {
            'cfg_inputs' : window.QE_CONFIG.INPUTS_GENERES_DIR,
            'cfg_outputs': window.QE_CONFIG.OUTPUTS_DIR,
            'cfg_pseudos': window.QE_CONFIG.PSEUDO_DIR,
            'cfg_cif'    : window.QE_CONFIG.CIF_DIR,
            'cfg_qe_bin' : window.QE_CONFIG.QE_BIN_DIR,
        };
        Object.keys(map).forEach(function(id) {
            var el = document.getElementById(id);
            if (el && !el.value) el.value = map[id] || '';
        });
    };

    window.toggleConfigChemins = function() {
        var body  = document.getElementById('config_chemins_body');
        var arrow = document.getElementById('config_arrow');
        if (!body) return;
        var open = body.style.display !== 'none';
        body.style.display = open ? 'none' : 'block';
        if (arrow) arrow.style.transform = open ? '' : 'rotate(180deg)';
        if (!open) window.remplirChampsConfig();
    };

    window.marquerConfigModifiee = function() {
        var badge = document.getElementById('config_status_badge');
        if (badge) { badge.textContent='● modifié'; badge.style.background='#78350f'; badge.style.color='#fcd34d'; }
    };

    window.detecterCheminsAuto = async function() {
        if (typeof window !== 'undefined' && window.__GEN_INPUTS_STANDALONE__) {
            try {
                var base = window.QE_API_URL || 'http://127.0.0.1:5012';
                var r = await fetch(base + '/api/paths', { cache: 'no-store' });
                if (r.ok) {
                    var d = await r.json();
                    if (d.cif_dir) window.QE_CONFIG.CIF_DIR = d.cif_dir;
                    if (d.inputs_dir) {
                        window.QE_CONFIG.INPUTS_DIR = d.inputs_dir;
                        window.QE_CONFIG.INPUTS_GENERES_DIR = d.inputs_dir;
                    }
                    if (d.outputs_root) window.QE_CONFIG.OUTPUTS_DIR = d.outputs_root;
                    if (d.project_root) window.QE_CONFIG.WORK_DIR = d.project_root;
                    if (d.inputs_dir_cif) window.QE_CONFIG.INPUTS_CIF_DIR = d.inputs_dir_cif;
                    if (d.pseudo_dir) window.QE_CONFIG.PSEUDO_DIR = d.pseudo_dir;
                    if (d.pseudo_fr_dir) window.QE_CONFIG.PSEUDO_FR_DIR = d.pseudo_fr_dir;
                    if (d.qe_bin_dir) window.QE_CONFIG.QE_BIN_DIR = d.qe_bin_dir;
                    console.log('✅ Chemins API autonome (5012):', d);
                }
            } catch (e) {
                console.warn('⚠️ /api/paths indisponible — chemins locaux/défauts', e);
            }
            return;
        }
        try {
            var r = await fetch(window.QE_API_URL + '/api/chemins');
            if (r.ok) {
                var d = await r.json();
                var stored = localStorage.getItem('qe_inputs_config');
                if (!stored) {
                    if (d.pseudos) window.QE_CONFIG.PSEUDO_DIR = d.pseudos;
                    if (d.inputs)  window.QE_CONFIG.INPUTS_DIR = window.QE_CONFIG.INPUTS_GENERES_DIR = d.inputs;
                    if (d.outputs) window.QE_CONFIG.OUTPUTS_DIR = d.outputs;
                }
                console.log('✅ Chemins API:', d);
            }
        } catch(e) {
            console.warn('⚠️ API hors ligne — chemins depuis localStorage/défauts');
        }
    };

    document.addEventListener('DOMContentLoaded', function() {
        if (typeof window !== 'undefined' && window.__GEN_INPUTS_STANDALONE__) {
            window.detecterCheminsAuto().then(function () {
                window.remplirChampsConfig();
            }).catch(function () {
                window.remplirChampsConfig();
            });
        } else {
            window.remplirChampsConfig();
        }
        var stored = localStorage.getItem('qe_inputs_config');
        var badge = document.getElementById('config_status_badge');
        if (badge) {
            if (stored) { badge.textContent='● personnalisé'; badge.style.background='#064e3b'; badge.style.color='#6ee7b7'; }
            else        { badge.textContent='● défaut';       badge.style.background='#1e1b4b'; badge.style.color='#a5b4fc'; }
        }
        if (typeof window !== 'undefined' && window.__GEN_INPUTS_STANDALONE__ && !window.QE_CONFIG_PRELOAD) {
            console.warn('⚠️ config_pc_local.js absent — lancez ./CONFIGURER.sh sur ce PC');
        }
    });

    window.qeProjectRoot = function () {
        var w = window.QE_CONFIG && window.QE_CONFIG.WORK_DIR;
        if (w) return String(w).replace(/\/+$/, '');
        var d = window.QE_CONFIG && window.QE_CONFIG.INPUTS_DIRECT_DIR;
        if (d) return String(d).replace(/\/inputs_g[eé]n[eé]r[eé]s_direct\/?$/i, '').replace(/\/+$/, '');
        return '';
    };
    window.qeInputsDirectRoot = function () {
        return (window.QE_CONFIG && window.QE_CONFIG.INPUTS_DIRECT_DIR)
            || (window.qeProjectRoot() + '/inputs_générés_direct');
    };
    window.qeInputsCifRoot = function () {
        return (window.QE_CONFIG && window.QE_CONFIG.INPUTS_CIF_DIR)
            || (window.qeProjectRoot() + '/inputs_convertis_cif');
    };
    window.qeInputsRootFor = function (source) {
        var s = String(source || 'direct').toLowerCase();
        return (s === 'cif' || s === 'convertis') ? window.qeInputsCifRoot() : window.qeInputsDirectRoot();
    };
    window.qeInputRelPath = function (materialName, calcType) {
        var mat = String(materialName || 'material').trim().replace(/[^A-Za-z0-9._-]+/g, '_') || 'material';
        var calc = String(calcType || 'scf').trim().replace(/[^A-Za-z0-9._-]+/g, '_') || 'scf';
        return mat + '/' + mat + '_' + calc + '.in';
    };

    console.log('📁 Générateur_Inputs-QE — chemins chargés:');
    console.log('   inputs direct :', window.QE_CONFIG.INPUTS_DIRECT_DIR);
    console.log('   inputs CIF    :', window.QE_CONFIG.INPUTS_CIF_DIR);
    console.log('   outputs       :', window.QE_CONFIG.OUTPUTS_DIR);
    console.log('   pseudos       :', window.QE_CONFIG.PSEUDO_DIR);
    console.log('   CIF           :', window.QE_CONFIG.CIF_DIR);
    console.log('   QE bin        :', window.QE_CONFIG.QE_BIN_DIR);

})();

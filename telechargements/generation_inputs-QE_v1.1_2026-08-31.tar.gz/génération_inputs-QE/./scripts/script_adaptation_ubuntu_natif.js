// Script script_adaptation_ubuntu_natif.js - stub vide (fonctionnalité non implémentée)

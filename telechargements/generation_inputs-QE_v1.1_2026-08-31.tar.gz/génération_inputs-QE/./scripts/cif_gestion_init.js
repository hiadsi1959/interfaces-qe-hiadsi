/**
 * Initialisation de la sous-section Gestion / CIF après chargement du fragment HTML.
 */
(function () {
    'use strict';

    function tab1Root() {
        return document.querySelector('.tab-content.active')
            || document.querySelector('.tab-content');
    }

    window.ensureSubsectionGestionInTab1 = function ensureSubsectionGestionInTab1() {
        var gest = document.getElementById('subsection_gestion');
        var tab1 = tab1Root();
        if (!gest || !tab1) return false;
        gest.classList.add('qe-cif-panel');
        if (gest.parentNode !== tab1) {
            tab1.appendChild(gest);
        }
        return true;
    };

    window.cacheCifEditorTemplateFromDom = function cacheCifEditorTemplateFromDom() {
        if (window.__CIF_EDITOR_TEMPLATE_HTML_BOOT) return;
        var z = document.getElementById('editeur_cif_zone');
        if (z && z.querySelector('#cif_type_magnetisme_card')) {
            window.__CIF_EDITOR_TEMPLATE_HTML_BOOT = z.innerHTML;
        }
    };

    window.initCifGestionAfterFragment = function initCifGestionAfterFragment() {
        ensureSubsectionGestionInTab1();
        cacheCifEditorTemplateFromDom();

        if (typeof window.populateAllCalcTypeSelects === 'function') {
            window.populateAllCalcTypeSelects();
        }
        if (typeof window.initInputDftSelects === 'function') {
            window.initInputDftSelects([
                { id: 'cif_input_dft', def: '' },
                { id: 'pw_input_dft', def: 'pbe' },
            ]);
        }
        if (typeof window.qePolarizationMountPanels === 'function') {
            window.qePolarizationMountPanels();
        }
        if (typeof window.qePolarizationUpdateVisibility === 'function') {
            var calcEl = document.getElementById('cif_calc_type');
            window.qePolarizationUpdateVisibility(calcEl ? calcEl.value : '');
        }
        if (typeof window.qeBindCalcTypeRecommendedParams === 'function') {
            window.qeBindCalcTypeRecommendedParams();
        }
        if (typeof window.qeApplyRecommendedCalcParams === 'function') {
            var ctEl = document.getElementById('cif_calc_type');
            if (ctEl && ctEl.value) {
                window.qeApplyRecommendedCalcParams(ctEl.value, { scope: 'cif' });
            }
        }
        if (typeof window.cifUpdateCifMagPanels === 'function') {
            try { window.cifUpdateCifMagPanels(); } catch (_eMag) {}
        }
        if (typeof window.applyI18n === 'function') {
            window.applyI18n();
        }

        console.log('✅ Gestion CIF initialisée (fragment monté)');
    };

    document.addEventListener('htmlFragmentsLoaded', function () {
        setTimeout(window.initCifGestionAfterFragment, 30);
    });

    if (window.__HTML_FRAGMENTS_LOADED__) {
        setTimeout(window.initCifGestionAfterFragment, 50);
    }
})();

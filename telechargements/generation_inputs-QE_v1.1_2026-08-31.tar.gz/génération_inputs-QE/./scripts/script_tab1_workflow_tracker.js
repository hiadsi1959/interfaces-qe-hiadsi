/**
 * script_tab1_workflow_tracker.js
 * Indicateur d'étapes unifié — voie directe ET voie CIF.
 * Même couleurs que le stepper Tab 1 (teal = actif, vert = terminé).
 */
(function () {
    'use strict';

    var PATHS = {
        direct: {
            badge: '⚡ Génération directe',
            steps: [
                { label: 'Matériau', scroll: function () { return scrollEl('#section_1_materiau'); }, test: testDirectMateriau },
                { label: 'Structure', scroll: function () { return scrollEl('#section_2_structure'); }, test: testDirectStructure },
                { label: 'Espèces', scroll: function () { return scrollEl('#section_3_especes'); }, test: testDirectEspeces },
                { label: 'Positions', scroll: function () { return scrollEl('#section_4_positions'); }, test: testDirectPositions },
                { label: 'Calcul', scroll: function () { return scrollEl('#section_5_type_calcul_chemins'); }, test: testDirectCalcul },
                { label: 'Générer', scroll: function () { return scrollPreview(); }, test: testDirectGenere }
            ]
        },
        cif: {
            badge: '🔬 Voie CIF',
            steps: [
                { label: 'Choisir CIF', scroll: function () { return scrollEl('#liste_fichiers_cif'); }, test: testCifListe },
                { label: 'Aperçu', scroll: function () { return scrollEl('#cif_editor_step1_preview'); }, test: testCifApercu },
                { label: 'Maille', scroll: function () { return scrollEl('#cif_editor_step2_options'); }, test: testCifMaille },
                { label: 'Calcul', scroll: function () { return scrollCifCalc(); }, test: testCifCalcul },
                { label: 'Magnétisme', scroll: function () { return scrollCifMag(); }, test: testCifMag },
                { label: 'Convertir', scroll: function () { return scrollPreview(); }, test: testCifConverti }
            ]
        }
    };

    var state = {
        path: 'direct',
        forced: {},
        generating: false,
        mounted: false
    };

    function scrollEl(sel) {
        var el = document.querySelector(sel);
        if (!el) return false;
        try { el.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (_e) { el.scrollIntoView(true); }
        return true;
    }

    function scrollPreview() {
        if (typeof window.tab1ScrollToInputPreview === 'function') {
            window.tab1ScrollToInputPreview({ delay: 0, block: 'center' });
            return true;
        }
        return scrollEl('#preview_input_container') || scrollEl('#cif_zone_preview') || scrollEl('#gestion_fichiers_status');
    }

    function scrollCifCalc() {
        return scrollEl('#cif_calc_type') || scrollEl('#cif_editor_step2_options');
    }

    function scrollCifMag() {
        return scrollEl('#cif_type_magnetisme_card') || scrollEl('#cif_editor_step2_options');
    }

    function testDirectMateriau() {
        return !!(document.getElementById('materiau_name') || {}).value.trim();
    }

    function testDirectStructure() {
        return !!__genLireIbrav();
    }

    function testDirectEspeces() {
        var n = parseInt((document.getElementById('ntyp') || {}).value, 10) || 0;
        if (n < 1) return false;
        for (var i = 1; i <= n; i++) {
            if (!(document.getElementById('element_' + i) || {}).value.trim()) return false;
        }
        return true;
    }

    function testDirectPositions() {
        var nat = parseInt((document.getElementById('nat') || {}).value, 10) || 0;
        if (nat < 1) return false;
        var ok = 0;
        for (var j = 1; j <= nat; j++) {
            var x = document.getElementById('pos_x_' + j);
            if (x && String(x.value).trim() !== '') ok++;
        }
        if (ok >= nat) return true;
        return !!(window.atomicPositionsContent && String(window.atomicPositionsContent).trim());
    }

    function testDirectCalcul() {
        var el = document.querySelector('#section_5_type_calcul_chemins #calc_type') || document.getElementById('calc_type');
        return !!(el && el.value);
    }

    function testDirectGenere() {
        return !!(window.currentInputContent && String(window.currentInputContent).trim())
            || !!(document.getElementById('preview_input') || {}).textContent.trim();
    }

    function __genLireIbrav() {
        var el = document.getElementById('ibrav') || document.getElementById('pw_input_ibrav');
        return el ? String(el.value || '').trim() : '';
    }

    function cifPayload() {
        var ta = document.getElementById('editeur_cif_content');
        return ta && String(ta.value || '').trim();
    }

    function cifEditorVisible() {
        var z = document.getElementById('editeur_cif_zone');
        if (!z) return false;
        try {
            var st = window.getComputedStyle(z);
            return st.display !== 'none' && st.visibility !== 'hidden';
        } catch (_e) { return z.offsetParent !== null; }
    }

    function testCifListe() {
        return !!cifPayload() || cifEditorVisible();
    }

    function testCifApercu() {
        return cifEditorVisible() && !!cifPayload();
    }

    function testCifMaille() {
        if (!testCifApercu()) return false;
        var cell = document.getElementById('cif_cell_type');
        var ibrav = document.getElementById('cif_ibrav_mode');
        return !!(cell && cell.value) || !!(ibrav && ibrav.value);
    }

    function testCifCalcul() {
        if (!testCifApercu()) return false;
        var calc = document.getElementById('cif_calc_type');
        return !!(calc && calc.value);
    }

    function testCifMag() {
        if (!testCifCalcul()) return false;
        var mag = document.getElementById('cif_type_magnetisme_card') || document.getElementById('cif_nspin');
        return !!mag;
    }

    function testCifConverti() {
        return !!(window.currentInputContent && String(window.currentInputContent).trim())
            || !!document.querySelector('#cif_zone_preview')
            || !!document.querySelector('#gestion_fichiers_status .alert-success');
    }

    function ensureTrackerDom() {
        var root = document.getElementById('tab1_workflow_tracker');
        if (root) return root;

        root = document.createElement('nav');
        root.id = 'tab1_workflow_tracker';
        root.className = 'tab1-workflow-tracker';
        root.setAttribute('aria-label', 'Étapes du workflow de génération');
        root.innerHTML = ''
            + '<div class="tab1-workflow-tracker-head">'
            + '  <span id="tab1_workflow_path_badge" class="tab1-workflow-path-badge"></span>'
            + '  <span class="tab1-workflow-tracker-hint">Cliquez une étape pour y aller</span>'
            + '</div>'
            + '<div id="tab1_workflow_steps" class="tab1-stepper tab1-workflow-steps"></div>';

        var tab1 = document.querySelector('.tab-content.active') || document.querySelector('.tab-content');
        if (!tab1) return null;

        var banner = document.getElementById('tab1_status_banner');
        if (banner && banner.parentNode === tab1) {
            tab1.insertBefore(root, banner.nextSibling);
        } else if (banner) {
            banner.parentNode.insertBefore(root, banner.nextSibling);
        } else {
            var card = tab1.querySelector('.card');
            if (card) tab1.insertBefore(root, card);
            else tab1.insertBefore(root, tab1.firstChild);
        }
        return root;
    }

    function renderSteps() {
        var wrap = document.getElementById('tab1_workflow_steps');
        var cfg = PATHS[state.path];
        if (!wrap || !cfg) return;

        var badge = document.getElementById('tab1_workflow_path_badge');
        if (badge) badge.textContent = cfg.badge;

        var statuses = computeStatuses(cfg.steps);
        var html = '';
        cfg.steps.forEach(function (step, idx) {
            var st = statuses[idx] || 'pending';
            if (idx > 0) html += '<span class="tab1-step-sep" aria-hidden="true"></span>';
            html += '<button type="button" class="tab1-step-item tab1-workflow-step-btn" data-wf-step="' + idx + '"'
                + ' title="Aller à : ' + step.label + '">'
                + '<span id="tab1_wf_dot_' + state.path + '_' + idx + '" class="tab1-step-dot ' + st + '">' + (idx + 1) + '</span>'
                + '<span class="tab1-step-label">' + step.label + '</span>'
                + '</button>';
        });
        wrap.innerHTML = html;

        wrap.querySelectorAll('.tab1-workflow-step-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var i = parseInt(btn.getAttribute('data-wf-step'), 10);
                var s = cfg.steps[i];
                if (s && typeof s.scroll === 'function') s.scroll();
            });
        });
    }

    function computeStatuses(steps) {
        var out = [];
        var firstOpen = -1;
        steps.forEach(function (step, idx) {
            if (state.forced[idx]) {
                out[idx] = state.forced[idx];
                return;
            }
            if (state.generating && idx === steps.length - 1) {
                out[idx] = 'generating';
                return;
            }
            var done = typeof step.test === 'function' ? step.test() : false;
            if (done) {
                out[idx] = 'done';
            } else if (firstOpen < 0) {
                firstOpen = idx;
                out[idx] = 'active';
            } else {
                out[idx] = 'pending';
            }
        });
        if (firstOpen < 0 && steps.length) {
            steps.forEach(function (_, idx) { out[idx] = 'done'; });
        }
        return out;
    }

    function showTracker(visible) {
        var el = document.getElementById('tab1_workflow_tracker');
        if (!el) return;
        el.style.display = visible ? 'block' : 'none';
        if (visible) renderSteps();
    }

    window.tab1MountWorkflowShell = function tab1MountWorkflowShell() {
        if (state.mounted) return;
        var tab1 = document.querySelector('.tab-content.active') || document.querySelector('.tab-content');
        var card = tab1 && tab1.querySelector('.card');
        if (!tab1 || !card) return;

        ['tab1_header', 'tab1_main_nav', 'tab1_status_banner'].forEach(function (id) {
            var el = document.getElementById(id);
            if (el && el.parentNode === card) {
                tab1.insertBefore(el, card);
            }
        });

        ensureTrackerDom();
        tab1.classList.add('tab1-workflow-mounted');
        state.mounted = true;
    };
    window.tab1MountWorkflowChrome = window.tab1MountWorkflowShell;

    window.tab1SetWorkflowPath = function tab1SetWorkflowPath(pathId) {
        state.path = (pathId === 'cif') ? 'cif' : 'direct';
        state.forced = {};
        state.generating = false;
        renderSteps();
    };

    window.tab1SetWorkflowStep = function tab1SetWorkflowStep(stepIndex, stepState) {
        if (stepState === 'generating') {
            state.generating = true;
            delete state.forced[stepIndex];
        } else if (stepState) {
            state.generating = false;
            state.forced[stepIndex] = stepState;
        } else {
            delete state.forced[stepIndex];
        }
        renderSteps();
    };

    window.tab1ClearWorkflowForced = function tab1ClearWorkflowForced() {
        state.forced = {};
        state.generating = false;
        renderSteps();
    };

    window.tab1RefreshWorkflowTracker = function tab1RefreshWorkflowTracker() {
        if (!state.mounted) window.tab1MountWorkflowShell();
        renderSteps();
    };

    window.tab1HighlightWorkflowStep = function tab1HighlightWorkflowStep(stepIndex) {
        state.generating = false;
        var cfg = PATHS[state.path];
        if (!cfg) return;
        for (var i = 0; i < cfg.steps.length; i++) {
            if (i < stepIndex) state.forced[i] = 'done';
            else if (i === stepIndex) state.forced[i] = 'active';
            else delete state.forced[i];
        }
        renderSteps();
    };

    function scrollTargetToStep(scrollTo) {
        if (!scrollTo) return -1;
        var mapDirect = {
            '#section_1_materiau': 0,
            '#section_2_structure': 1,
            '#section_3_especes': 2,
            '#section_4_positions': 3,
            '#section_5_type_calcul_chemins': 4
        };
        if (mapDirect[scrollTo] != null) return mapDirect[scrollTo];
        return -1;
    }

    window.tab1HighlightWorkflowFromScroll = function tab1HighlightWorkflowFromScroll(scrollTo) {
        var idx = scrollTargetToStep(scrollTo);
        if (idx >= 0) window.tab1HighlightWorkflowStep(idx);
    };

    function onTabSwitch(panelId) {
        window.tab1MountWorkflowShell();
        if (panelId === 'cif') {
            window.tab1SetWorkflowPath('cif');
            showTracker(true);
            window.tab1RefreshWorkflowTracker();
        } else if (panelId === 'generation') {
            window.tab1SetWorkflowPath('direct');
            showTracker(true);
            window.tab1RefreshWorkflowTracker();
        } else {
            showTracker(false);
        }
    }

    function patchTab1Switch() {
        var orig = window.tab1SwitchMainTab;
        if (!orig || orig.__wfPatched) return;
        window.tab1SwitchMainTab = function (panelId) {
            orig(panelId);
            onTabSwitch(String(panelId || 'guide').trim());
        };
        window.tab1SwitchMainTab.__wfPatched = true;
    }

    function patchTab1UpdateStepper() {
        var orig = window.tab1UpdateStepper;
        if (!orig || orig.__wfPatched) return;
        window.tab1UpdateStepper = function () {
            orig();
            if (state.path === 'direct') window.tab1RefreshWorkflowTracker();
        };
        window.tab1UpdateStepper.__wfPatched = true;
    }

    function init() {
        patchTab1Switch();
        patchTab1UpdateStepper();
        document.addEventListener('tab1Restructured', function () {
            setTimeout(function () {
                window.tab1MountWorkflowShell();
                onTabSwitch('guide');
            }, 50);
        });
        document.addEventListener('input', function () {
            if (state.mounted && document.getElementById('tab1_workflow_tracker') &&
                    document.getElementById('tab1_workflow_tracker').style.display !== 'none') {
                window.tab1RefreshWorkflowTracker();
            }
        }, true);
        document.addEventListener('change', function () {
            if (state.mounted && document.getElementById('tab1_workflow_tracker') &&
                    document.getElementById('tab1_workflow_tracker').style.display !== 'none') {
                window.tab1RefreshWorkflowTracker();
            }
        }, true);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    console.log('✅ Workflow tracker Tab 1 chargé');
})();

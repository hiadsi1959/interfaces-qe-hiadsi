// ═══════════════════════════════════════════════════════════════════════════
// POSITIONS ATOMIQUES PRÉCISES - BASE DE DONNÉES COMPLÈTE
// Positions réelles pour chaque structure cristalline
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Base de données précise des positions atomiques par structure
 * Format: POSITIONS_PRECISES[ibrav] = { name, positions: [[x,y,z], ...], description }
 * 
 * Les positions sont en coordonnées cristallines (0 à 1)
 */
const POSITIONS_PRECISES = {
    '1': {  // Cubique Simple (SC)
        name: 'Cubique Simple (SC)',
        description: '1 atome par maille',
        natMin: 1,
        positions: {
            1: [[0, 0, 0]],
            2: [[0, 0, 0], [0.5, 0.5, 0.5]],
            3: [[0, 0, 0], [0.5, 0.5, 0.5], [0.25, 0.25, 0.25]],
            4: [[0, 0, 0], [0.5, 0.5, 0.5], [0.25, 0.25, 0.25], [0.75, 0.75, 0.75]]
        }
    },
    '2': {  // FCC (Cubique Faces Centrées)
        name: 'Cubique Faces Centrées (FCC)',
        description: '4 atomes par maille',
        natMin: 4,
        positions: {
            4: [[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]],
            5: [[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5], [0.25, 0.25, 0.25]],
            6: [[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5], [0.25, 0.25, 0.25], [0.75, 0.75, 0.75]]
        }
    },
    '3': {  // BCC (Cubique Centré)
        name: 'Cubique Centré (BCC)',
        description: '2 atomes par maille',
        natMin: 2,
        positions: {
            2: [[0, 0, 0], [0.5, 0.5, 0.5]],
            3: [[0, 0, 0], [0.5, 0.5, 0.5], [0.25, 0.25, 0.25]],
            4: [[0, 0, 0], [0.5, 0.5, 0.5], [0.25, 0.25, 0.25], [0.75, 0.75, 0.75]],
            5: [[0, 0, 0], [0.5, 0.5, 0.5], [0.25, 0.25, 0.25], [0.75, 0.75, 0.75], [0.5, 0, 0]]
        }
    },
    '4': {  // Hexagonal
        name: 'Hexagonal',
        description: '2 atomes par maille (ex: GaN)',
        natMin: 2,
        positions: {
            2: [[0, 0, 0], [1/3, 2/3, 0.5]],
            3: [[0, 0, 0], [1/3, 2/3, 0.5], [0, 0, 0.3]],
            4: [[0, 0, 0], [1/3, 2/3, 0.5], [0, 0, 0.3], [1/3, 2/3, 0.8]]
        }
    },
    '5': {  // Rhomboédrique
        name: 'Rhomboédrique',
        description: '1 atome par maille primitive',
        natMin: 1,
        positions: {
            1: [[0, 0, 0]],
            2: [[0, 0, 0], [0.5, 0.5, 0.5]],
            3: [[0, 0, 0], [0.5, 0.5, 0.5], [0.25, 0.25, 0.25]]
        }
    },
    '6': {  // Tétragonal Simple
        name: 'Tétragonal Simple',
        description: '1 atome par maille',
        natMin: 1,
        positions: {
            1: [[0, 0, 0]],
            2: [[0, 0, 0], [0.5, 0.5, 0.5]],
            3: [[0, 0, 0], [0.5, 0.5, 0.5], [0, 0, 0.3]]
        }
    },
    '7': {  // Tétragonal Centré
        name: 'Tétragonal Centré',
        description: '2 atomes par maille',
        natMin: 2,
        positions: {
            2: [[0, 0, 0], [0.5, 0.5, 0.5]],
            3: [[0, 0, 0], [0.5, 0.5, 0.5], [0, 0, 0.3]],
            4: [[0, 0, 0], [0.5, 0.5, 0.5], [0, 0, 0.3], [0.5, 0.5, 0.8]]
        }
    },
    '8': {  // Orthorhombique Simple
        name: 'Orthorhombique Simple',
        description: '1 atome par maille',
        natMin: 1,
        positions: {
            1: [[0, 0, 0]],
            2: [[0, 0, 0], [0.5, 0.5, 0.5]],
            3: [[0, 0, 0], [0.5, 0.5, 0.5], [0.25, 0.25, 0.25]]
        }
    },
    '9': {  // Orthorhombique Centré (C)
        name: 'Orthorhombique Centré (C)',
        description: '2 atomes par maille',
        natMin: 2,
        positions: {
            2: [[0, 0, 0], [0.5, 0.5, 0]],
            3: [[0, 0, 0], [0.5, 0.5, 0], [0, 0, 0.3]],
            4: [[0, 0, 0], [0.5, 0.5, 0], [0, 0, 0.3], [0.5, 0.5, 0.3]]
        }
    },
    '10': {  // Orthorhombique F
        name: 'Orthorhombique F',
        description: '4 atomes par maille',
        natMin: 4,
        positions: {
            4: [[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]],
            5: [[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5], [0.25, 0.25, 0.25]]
        }
    },
    '11': {  // Orthorhombique I
        name: 'Orthorhombique I',
        description: '2 atomes par maille',
        natMin: 2,
        positions: {
            2: [[0, 0, 0], [0.5, 0.5, 0.5]],
            3: [[0, 0, 0], [0.5, 0.5, 0.5], [0, 0, 0.3]],
            4: [[0, 0, 0], [0.5, 0.5, 0.5], [0, 0, 0.3], [0.5, 0.5, 0.8]]
        }
    },
    '12': {  // Monoclinique Simple
        name: 'Monoclinique Simple',
        description: '1 atome par maille',
        natMin: 1,
        positions: {
            1: [[0, 0, 0]],
            2: [[0, 0, 0], [0.5, 0.5, 0.5]],
            3: [[0, 0, 0], [0.5, 0.5, 0.5], [0.25, 0.25, 0.25]]
        }
    },
    '13': {  // Monoclinique Centré
        name: 'Monoclinique Centré',
        description: '2 atomes par maille',
        natMin: 2,
        positions: {
            2: [[0, 0, 0], [0.5, 0.5, 0]],
            3: [[0, 0, 0], [0.5, 0.5, 0], [0, 0, 0.3]],
            4: [[0, 0, 0], [0.5, 0.5, 0], [0, 0, 0.3], [0.5, 0.5, 0.3]]
        }
    },
    '14': {  // Triclinique
        name: 'Triclinique',
        description: '1 atome par maille',
        natMin: 1,
        positions: {
            1: [[0, 0, 0]],
            2: [[0, 0, 0], [0.5, 0.5, 0.5]],
            3: [[0, 0, 0], [0.5, 0.5, 0.5], [0.25, 0.25, 0.25]]
        }
    }
};

/**
 * Structures spéciales: Pérovskite (BaTiO3, BaFeO3, etc.)
 * Format: PEROVSKITE[ntyp][nat]
 */
const PEROVSKITE = {
    'ABX3': {  // ntyp=3 (A, B, X), nat=5
        3: {
            5: [
                [0, 0, 0],           // A (Ba)
                [0.5, 0.5, 0.5],     // B (Ti/Fe)
                [0.5, 0.5, 0],       // X (O)
                [0.5, 0, 0.5],       // X (O)
                [0, 0.5, 0.5]        // X (O)
            ],
            6: [
                [0, 0, 0],
                [0.5, 0.5, 0.5],
                [0.5, 0.5, 0],
                [0.5, 0, 0.5],
                [0, 0.5, 0.5],
                [0.25, 0.25, 0.25]
            ]
        }
    }
};

/**
 * Structures spéciales: Chalcopyrite ABX2 (CuInSe2, CuGaSe2, etc.)
 * Structure tétragonale I-42d (ibrav=6 ou 7)
 * Format: CHALCOPYRITE[ntyp][nat]
 */
const CHALCOPYRITE = {
    'ABX2': {  // ntyp=3 (A, B, X), nat=8
        3: {
            8: [
                [0, 0, 0],              // A (Cu) - position (0,0,0)
                [0, 0.5, 0.25],         // A (Cu) - position (0,1/2,1/4)
                [0.5, 0, 0.25],         // B (In/Ga) - position (1/2,0,1/4)
                [0.5, 0.5, 0.5],        // B (In/Ga) - position (1/2,1/2,1/2)
                [0.25, 0.25, 0.125],    // X (Se/S) - position (1/4,1/4,1/8)
                [0.75, 0.25, 0.375],    // X (Se/S) - position (3/4,1/4,3/8)
                [0.25, 0.75, 0.625],    // X (Se/S) - position (1/4,3/4,5/8)
                [0.75, 0.75, 0.875]     // X (Se/S) - position (3/4,3/4,7/8)
            ],
            16: [  // Supercellule 2x2x2
                // A (Cu) - 4 positions
                [0, 0, 0],
                [0, 0.5, 0.25],
                [0.5, 0, 0.25],
                [0.5, 0.5, 0.5],
                // B (In/Ga) - 4 positions
                [0.25, 0.25, 0],
                [0.25, 0.75, 0.25],
                [0.75, 0.25, 0.25],
                [0.75, 0.75, 0.5],
                // X (Se/S) - 8 positions
                [0.125, 0.125, 0.125],
                [0.375, 0.125, 0.375],
                [0.125, 0.375, 0.625],
                [0.375, 0.375, 0.875],
                [0.625, 0.625, 0.125],
                [0.875, 0.625, 0.375],
                [0.625, 0.875, 0.625],
                [0.875, 0.875, 0.875]
            ]
        }
    }
};

/**
 * Générer les positions en tenant compte de la structure réelle
 */
function genererPositionsPrecises(ibrav, nat, materiau = '') {
    ibrav = String(ibrav);
    nat = parseInt(nat) || 1;
    
    console.log(`\n🔍 genererPositionsPrecises(ibrav=${ibrav}, nat=${nat}, materiau='${materiau}')`);
    
    // ⭐ DÉTECTION GÉNÉRIQUE DE PÉROVSKITE ABX3
    // Critères: ntyp=3 + nat=5 + structure cubique (ibrav=1,2,3) OU orthorhombic (ibrav=8-11)
    const ntypInput = document.getElementById('ntyp');
    const ntyp = parseInt(ntypInput?.value) || 0;
    
    const isStructureCubique = ['1', '2', '3', '221'].includes(ibrav);
    const isStructureOrtho = ['8', '9', '10', '11'].includes(ibrav);
    const isPerovsktieStructure = (ntyp === 3 && nat === 5 && (isStructureCubique || isStructureOrtho));
    
    if (isPerovsktieStructure) {
        console.log('✓ Structure Pérovskite ABX3 détectée (générique):');
        console.log(`  ntyp=${ntyp}, nat=${nat}, ibrav=${ibrav}`);
        console.log(`  Matériau: ${materiau}`);
        return PEROVSKITE.ABX3[3][5];
    }
    
    // SPÉCIAL: Détecteur Chalcopyrite (CuInSe2, CuGaSe2, etc.)
    const isChalcopyrite = materiau.toLowerCase().match(/(cu|ag)(in|ga|al)(se|s|te)2/i) ||
                           materiau.toLowerCase().match(/zn(si|ge)(p|as)2/i);
    
    if (isChalcopyrite && nat === 8) {
        console.log('✓ Structure Chalcopyrite ABX2 détectée');
        return CHALCOPYRITE.ABX2[3][8];
    }
    
    if (isChalcopyrite && nat === 16) {
        console.log('✓ Structure Chalcopyrite ABX2 (supercellule 2x2x2) détectée');
        return CHALCOPYRITE.ABX2[3][16];
    }
    
    // Utiliser la base de données précise
    const struct = POSITIONS_PRECISES[ibrav];
    if (!struct) {
        console.error(`❌ Structure ibrav=${ibrav} non trouvée`);
        return [];
    }
    
    console.log(`✓ Structure: ${struct.name}`);
    
    // Chercher les positions pour ce nat
    const positionsForNat = struct.positions[nat];
    
    if (positionsForNat) {
        console.log(`✓ Positions précises trouvées pour nat=${nat}`);
        return positionsForNat;
    }
    
    // Sinon, générer par répétition/interpolation
    console.warn(`⚠️ Pas de positions précises pour nat=${nat}, génération par pattern`);
    
    const primitive = struct.positions[struct.natMin] || struct.positions[Object.keys(struct.positions)[0]];
    const positions = [];
    
    for (let i = 0; i < nat; i++) {
        const posIdx = i % primitive.length;
        positions.push([...primitive[posIdx]]);
    }
    
    return positions;
}

console.log('✅ Script positions précises chargé');


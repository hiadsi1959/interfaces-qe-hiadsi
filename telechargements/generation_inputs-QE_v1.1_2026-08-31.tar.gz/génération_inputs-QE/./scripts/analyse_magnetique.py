import re
import os

def analyser_stabilite_magnetique(chemin_fm, chemin_afm):
    """
    Analyse et compare les fichiers de sortie (out) de Quantum ESPRESSO 
    pour les phases Ferromagnétique (FM) et Antiferromagnétique (AFM).
    """
    
    # --- 1. Fonctions internes pour extraire les données indispensables ---
    def extraire_donnees_qe(chemin_fichier):
        if not os.path.exists(chemin_fichier):
            raise FileNotFoundError(f"Le fichier {chemin_fichier} est introuvable.")
            
        energie_finale = None
        nombre_atomes = None
        
        with open(chemin_fichier, 'r', encoding='utf-8') as f:
            for line in f:
                # Extraction du nombre d'atomes (pour vérification de cohérence)
                if 'number of atoms/cell' in line:
                    match_nat = re.search(r'=\s+(\d+)', line)
                    if match_nat:
                        nombre_atomes = int(match_nat.group(1))
                        
                # Extraction de l'énergie totale convergée (! total energy)
                if '!    total energy' in line:
                    match_ene = re.search(r'=\s+([-+]?\d+\.\d+)', line)
                    if match_ene:
                        # On écrase au fur et à mesure pour garder la TOUTE DERNIÈRE valeur du vc-relax
                        energie_finale = float(match_ene.group(1))
                        
        return energie_finale, nombre_atomes

    # --- 2. Extraction des données pour les deux phases ---
    try:
        E_fm, nat_fm = extraire_donnees_qe(chemin_fm)
        E_afm, nat_afm = extraire_donnees_qe(chemin_afm)
    except Exception as e:
        return {"statut": "erreur", "message": str(e)}

    # --- 3. Vérifications de sécurité pour l'interface ---
    if E_fm is None:
        return {"statut": "erreur", "message": f"Impossible de trouver l'énergie convergée dans le fichier FM ({chemin_fm}). Le calcul a peut-être planté."}
    if E_afm is None:
        return {"statut": "erreur", "message": f"Impossible de trouver l'énergie convergée dans le fichier AFM ({chemin_afm}). Le calcul a peut-être planté."}
        
    if nat_fm != nat_afm:
        return {
            "statut": "erreur", 
            "message": f"Incohérence stricte ! Le fichier FM contient {nat_fm} atomes tandis que le fichier AFM en contient {nat_afm}. La comparaison d'énergie est impossible."
        }

    # --- 4. Calculs énergétiques ---
    # Constante de conversion : 1 Ry = 13.605693 eV
    RY_TO_EV = 13.605693
    
    delta_E_ry = E_fm - E_afm
    delta_E_ev = delta_E_ry * RY_TO_EV
    
    # --- 5. Détermination de la phase stable ---
    if delta_E_ry > 0:
        phase_stable = "Antiferromagnétique (AFM)"
        explication = f"L'énergie de la phase AFM est plus basse que celle de la phase FM."
    elif delta_E_ry < 0:
        phase_stable = "Ferromagnétique (FM)"
        explication = f"L'énergie de la phase FM est plus basse que celle de la phase AFM."
    else:
        phase_stable = "Dégénérée (Énergie identique)"
        explication = "Les deux phases ont exactement la même énergie totale."

    # --- 6. Retour des résultats sous forme de dictionnaire (Idéal pour Flask / JSON) ---
    return {
        "statut": "succès",
        "nombre_atomes": nat_fm,
        "energie_fm_Ry": E_fm,
        "energie_afm_Ry": E_afm,
        "delta_E_Ry": delta_E_ry,
        "delta_E_eV": delta_E_ev,
        "phase_fondamentale": phase_stable,
        "explication": explication
    }

# =====================================================================
# ZONE DE TEST (Exemple d'utilisation pratique)
# =====================================================================
if __name__ == "__main__":
    # Remplace ici par les vrais chemins de tes fichiers générés par ton interface
    fichier_fm = "out-fm"
    fichier_afm = "out-afma
    
    # Simulation de création de faux fichiers pour tester le script si nécessaire
    with open(fichier_fm, "w") as f: f.write("number of atoms/cell      =            5\n!    total energy              =    -120.45000000 Ry\n")
    with open(fichier_afm, "w") as f: f.write("number of atoms/cell      =            5\n!    total energy              =    -120.45850000 Ry\n")

    # Appel de la fonction
    resultats = analyser_stabilite_magnetique(fichier_fm, fichier_afm)
    
    # Affichage propre dans la console
    if resultats["statut"] == "succès":
        print("====== RÉSULTATS DE L'ANALYSE INTERFACE-QE ======")
        print(f"Nombre d'atomes analysés : {resultats['nombre_atomes']}")
        print(f"Énergie Finale FM  : {resultats['energie_fm_Ry']:.6f} Ry")
        print(f"Énergie Finale AFM : {resultats['energie_afm_Ry']:.6f} Ry")
        print("-" * 50)
        print(f"Delta E (E_fm - E_afm) : {resultats['delta_E_Ry']:.6f} Ry ({resultats['delta_E_eV']:.4f} eV)")
        print(f"--> PHASE LA PLUS STABLE : {resultats['phase_fondamentale']}")
        print(f"Note : {resultats['explication']}")
        print("=================================================")
    else:
        print(f"[ERREUR INTERFACE] : {resultats['message']}")

// ═══════════════════════════════════════════════════════════════════════════
// WORKFLOW PHONONS - Dynamique du Réseau et Propriétés Vibrationnelles
// ═══════════════════════════════════════════════════════════════════════════

// Configuration des exécutables QE pour phonons
const QE_PHONONS_BIN = {
    ph: '/home/hiadsi/q-e-qe-7.5/bin/ph.x',
    q2r: '/home/hiadsi/q-e-qe-7.5/bin/q2r.x',
    matdyn: '/home/hiadsi/q-e-qe-7.5/bin/matdyn.x',
    dynmat: '/home/hiadsi/q-e-qe-7.5/bin/dynmat.x',
    lambda: '/home/hiadsi/q-e-qe-7.5/bin/lambda.x',
    alpha2f: '/home/hiadsi/q-e-qe-7.5/bin/alpha2f.x'
};

// Variable globale pour le calcul SCF sélectionné
let scfPhononsSelectionne = null;

// Verrou global: empêche tout démarrage auto tant que non autorisé par l'utilisateur
let gateDebutWorkflowPhononsAutorise = false;

// Variables pour le workflow intelligent avec prérequis
let materiauPhononsCharge = null;
let prerequisPhononsValides = false;

/**
 * Charger la liste des calculs SCF disponibles
 */
async function chargerListeCalculsSCFPhonons() {
    console.log('📂 Chargement des calculs SCF pour phonons...');

    const zoneDiv = document.getElementById('zone_scf_phonons');
    if (!zoneDiv) {
        console.error('❌ Zone zone_scf_phonons non trouvée');
        return;
    }
    
    zoneDiv.innerHTML = '<div style="text-align: center; padding: 20px; color: #3b82f6;">⏳ Chargement des calculs SCF disponibles...</div>';
    
    try {
        // Essayer de charger depuis l'API
        const response = await fetch('http://localhost:5007/api/lister_outputs', {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        
        if (!response.ok) {
            throw new Error(`Erreur API: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data.success || !data.outputs || data.outputs.length === 0) {
            zoneDiv.innerHTML = `
                <div style="padding: 20px; text-align: center; background: #fef3c7; border-radius: 8px; border: 2px solid #f59e0b;">
                    <span style="font-size: 2em;">⚠️</span>
                    <p style="margin: 10px 0; color: #92400e; font-weight: 600;">Aucun calcul SCF trouvé</p>
                    <p style="margin: 0; color: #78350f; font-size: 0.9em;">Lancez d'abord un calcul SCF ou VC-RELAX dans l'onglet "Électronique"</p>
                </div>
            `;
            return;
        }
        
        // Filtrer uniquement les calculs SCF/VC-RELAX
        const calculsSCF = data.outputs.filter(calc => 
            calc.type === 'scf' || calc.type === 'vc-relax' || calc.type === 'relax'
        );
        
        if (calculsSCF.length === 0) {
            zoneDiv.innerHTML = `
                <div style="padding: 20px; text-align: center; background: #fef3c7; border-radius: 8px; border: 2px solid #f59e0b;">
                    <span style="font-size: 2em;">⚠️</span>
                    <p style="margin: 10px 0; color: #92400e; font-weight: 600;">Aucun calcul SCF/VC-RELAX trouvé</p>
                </div>
            `;
            return;
        }
        
        afficherListeCalculsSCF(calculsSCF);
        
    } catch (error) {
        console.error('❌ Erreur chargement SCF:', error);
        zoneDiv.innerHTML = `
            <div style="padding: 20px; text-align: center; background: #fee2e2; border-radius: 8px; border: 2px solid #ef4444;">
                <span style="font-size: 2em;">❌</span>
                <p style="margin: 10px 0; color: #991b1b; font-weight: 600;">Erreur de chargement</p>
                <p style="margin: 0; color: #7f1d1d; font-size: 0.9em;">${error.message}</p>
                <p style="margin: 10px 0 0 0; color: #7f1d1d; font-size: 0.85em;">💡 Conseil: Assurez-vous que l'API est en cours d'exécution</p>
            </div>
        `;
    }
}

/**
 * Afficher la liste des calculs SCF
 */
function afficherListeCalculsSCF(calculs) {
    const zoneDiv = document.getElementById('zone_scf_phonons');
    if (!zoneDiv) return;
    
    let html = `
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; border: 2px solid #e2e8f0;">
            <h5 style="margin: 0 0 15px 0; color: #1e293b;">📁 Calculs SCF Disponibles</h5>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 15px; max-height: 400px; overflow-y: auto;">
    `;
    
    calculs.forEach(calc => {
        const nom = calc.prefix || 'Sans nom';
        const type = calc.type || 'scf';
        const path = calc.output_dir || '';
        
        const couleurs = {
            'vc-relax': '#10b981',
            'relax': '#3b82f6',
            'scf': '#14b8a6'
        };
        const couleur = couleurs[type] || '#14b8a6';
        
        html += `
            <button onclick="selectionnerSCFPourPhonons('${path}', '${nom}')" 
                    id="btn_scf_ph_${nom}"
                    style="
                        padding: 15px;
                        background: white;
                        border: 2px solid #e2e8f0;
                        border-radius: 8px;
                        cursor: pointer;
                        transition: all 0.3s;
                        text-align: left;
                    "
                    onmouseover="this.style.borderColor='${couleur}'; this.style.transform='scale(1.02)';"
                    onmouseout="this.style.borderColor='#e2e8f0'; this.style.transform='scale(1)';">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                    <span style="
                        background: ${couleur};
                        color: white;
                        padding: 4px 8px;
                        border-radius: 4px;
                        font-size: 0.75em;
                        font-weight: bold;
                    ">${type.toUpperCase()}</span>
                    <span style="font-weight: 600; color: #1e293b; flex: 1;">${nom}</span>
                </div>
                <div style="font-size: 0.75em; color: #64748b; font-family: monospace;">
                    ${path}
                </div>
                <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid #e2e8f0;">
                    <span style="font-size: 0.75em; color: #14b8a6;">✓ Prêt pour calculs phonons</span>
                </div>
            </button>
        `;
    });
    
    html += `
            </div>
        </div>
    `;
    
    zoneDiv.innerHTML = html;
}

/**
 * Sélectionner un calcul SCF pour les phonons
 */
function selectionnerSCFPourPhonons(path, nom) {
    console.log(`✅ SCF sélectionné pour phonons: ${nom}`);
    
    scfPhononsSelectionne = { path, nom };
    
    // Mettre à jour l'affichage
    const infoDiv = document.getElementById('scf_phonons_selectionne_info');
    const nomDiv = document.getElementById('scf_phonons_selectionne_nom');
    
    if (infoDiv) {
        infoDiv.style.display = 'block';
    }
    
    if (nomDiv) {
        nomDiv.textContent = nom;
    }
    
    // Activer le bouton de lancement
    const btn = document.getElementById('btn_lancer_workflow_phonons');
    const status = document.getElementById('workflow_phonons_status');
    
    if (btn) {
        btn.disabled = false;
        btn.style.opacity = '1';
        btn.style.cursor = 'pointer';
    }
    
    if (status) {
        status.textContent = `✅ Prêt à lancer - Calcul SCF: ${nom}`;
        status.style.color = '#14b8a6';
        status.style.fontWeight = '600';
    }
    
    // Mettre en évidence le bouton sélectionné
    document.querySelectorAll('[id^="btn_scf_ph_"]').forEach(btn => {
        btn.style.borderColor = '#e2e8f0';
        btn.style.background = 'white';
        btn.style.borderWidth = '2px';
    });
    
    const btnSelectionne = document.getElementById(`btn_scf_ph_${nom}`);
    if (btnSelectionne) {
        btnSelectionne.style.borderColor = '#14b8a6';
        btnSelectionne.style.background = '#f0fdfa';
        btnSelectionne.style.borderWidth = '3px';
    }
}

/**
 * Lancer le workflow phonons
 */
async function lancerWorkflowPhonons() {
    console.log('🔊 Lancement du workflow phonons');

    // Bloque le démarrage si l'utilisateur n'a pas cliqué sur le bouton d'autorisation
    if (!gateDebutWorkflowPhononsAutorise) {
        alert('🛑 Démarrage bloqué. Cliquez sur "Démarrer workflow phonons" pour autoriser le lancement.');
        return;
    }
    
    if (!scfPhononsSelectionne) {
        alert('⚠️ Veuillez d\'abord sélectionner un calcul SCF!');
        return;
    }
    
    // Vérifier les prérequis avant de lancer
    const verif = await verifierPrerequisPhonons(scfPhononsSelectionne);
    if (!verif.ok) {
        const reponse = confirm(
            `⚠️ PRÉREQUIS MANQUANTS\n\n${verif.message}\n\n` +
            `Voulez-vous lancer automatiquement les calculs manquants?\n\n` +
            `Cela peut prendre du temps selon la taille du système.`
        );
        
        if (reponse) {
            const resultat = await lancerCalculsPrerequisPhonons(verif.manquants);
            if (!resultat.success) {
                alert(`❌ Échec du lancement des prérequis:\n\n${resultat.error}`);
                return;
            }
            alert('✅ Prérequis complétés! Le workflow phonons peut maintenant démarrer.');
        } else {
            return;
        }
    }
    
    // 1. Lire les checkboxes pour voir quelles étapes sont cochées
    const etapesCochees = lireEtapesPhononsCochees();
    
    if (etapesCochees.length === 0) {
        alert('⚠️ Aucune étape sélectionnée!\n\nCochez au moins une étape à lancer.');
        return;
    }
    
    console.log(`✅ Étapes sélectionnées: ${etapesCochees.join(', ')}`);
    
    // 2. Récupérer les paramètres
    const params = {
        qgrid: document.getElementById('ph_qgrid')?.value || '4 4 4',
        tmin: parseFloat(document.getElementById('ph_tmin')?.value) || 0,
        tmax: parseFloat(document.getElementById('ph_tmax')?.value) || 1000,
        tstep: parseFloat(document.getElementById('ph_tstep')?.value) || 10
    };
    
    // 3. Afficher la zone de progression
    const progressZone = document.getElementById('workflow_phonons_progress_zone');
    if (progressZone) {
        progressZone.style.display = 'block';
        progressZone.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    
    // 4. Initialiser la console de logs
    const console_elem = document.getElementById('workflow_phonons_console');
    if (console_elem) {
        console_elem.innerHTML = `
            <div style="color: #14b8a6;">[INFO] ═══════════════════════════════════════════════════════</div>
            <div style="color: #14b8a6;">[INFO] 🔊 WORKFLOW PHONONS - ${scfPhononsSelectionne.nom}</div>
            <div style="color: #14b8a6;">[INFO] ═══════════════════════════════════════════════════════</div>
            <div style="color: #14b8a6;">[INFO] Étapes: ${etapesCochees.join(' → ')}</div>
            <div style="color: #14b8a6;">[INFO] Grille q: ${params.qgrid}</div>
            <div style="color: #14b8a6;">[INFO] Plage T: ${params.tmin}K - ${params.tmax}K (pas: ${params.tstep}K)</div>
            <div style="color: #14b8a6;">[INFO] Heure début: ${new Date().toLocaleTimeString()}</div>
            <div style="color: #14b8a6;">[INFO] ═══════════════════════════════════════════════════════</div>
            <div style="color: #fbbf24;">[INFO] Préparation du workflow phonons...</div>
        `;
    }
    
    // 5. Lancer les étapes une par une
    for (let i = 0; i < etapesCochees.length; i++) {
        const etape = etapesCochees[i];
        const numero = i + 1;
        const total = etapesCochees.length;
        
        ajouterLogConsolePhonons(`\n[INFO] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`, '#14b8a6');
        ajouterLogConsolePhonons(`[INFO] 📌 ÉTAPE ${numero}/${total}: ${etape.toUpperCase()}`, '#14b8a6');
        ajouterLogConsolePhonons(`[INFO] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`, '#14b8a6');
        
        // Description de l'étape
        const descriptions = {
            'ph': 'Calcul des fréquences de phonons par DFPT (Density Functional Perturbation Theory)',
            'q2r': 'Transformation Fourier: espace-q → espace réel (constantes de force)',
            'matdyn': 'Calcul de la dispersion des phonons et de la densité d\'états',
            'thermo': 'Propriétés thermodynamiques: Cv, Entropie, Énergie Libre de Helmholtz',
            'eph': 'Couplage électron-phonon: calcul de λ, ωlog et Tc (supraconductivité)'
        };
        
        ajouterLogConsolePhonons(`[INFO] ${descriptions[etape]}`, '#fbbf24');
        ajouterLogConsolePhonons(`[INFO] Début: ${new Date().toLocaleTimeString()}`, '#fbbf24');
        
        // Mettre à jour l'affichage de progression
        mettreAJourProgressionEtapePhonons(numero, total, etape);
        
        // Lancer l'étape
        const resultat = await lancerEtapePhononsIndividuelle(etape, params);
        
        if (!resultat.success) {
            ajouterLogConsolePhonons(`[ERREUR] ❌ Échec de l'étape ${etape}`, '#ef4444');
            ajouterLogConsolePhonons(`[ERREUR] ${resultat.error}`, '#ef4444');
            alert(`❌ Erreur à l'étape ${etape}:\n\n${resultat.error}\n\nLe workflow est arrêté.\n\nConsultez les logs pour plus de détails.`);
            return;
        }
        
        ajouterLogConsolePhonons(`[INFO] ✅ Étape ${etape} terminée avec succès!`, '#10b981');
        if (resultat.output_file) {
            ajouterLogConsolePhonons(`[INFO] Fichier: ${resultat.output_file}`, '#10b981');
        }
        if (resultat.resultats) {
            ajouterLogConsolePhonons(`[INFO] ${resultat.resultats}`, '#10b981');
        }
        
        // Mettre à jour l'indicateur visuel
        marquerEtapeCompletePhonons(etape);
        
        // Pause entre les étapes
        if (i < etapesCochees.length - 1) {
            ajouterLogConsolePhonons(`[INFO] ⏸️ Pause de 2 secondes...`, '#fbbf24');
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
    }
    
    // 6. Workflow terminé
    ajouterLogConsolePhonons(`\n[INFO] ═══════════════════════════════════════════════════════`, '#10b981');
    ajouterLogConsolePhonons(`[INFO] 🎉 WORKFLOW PHONONS TERMINÉ AVEC SUCCÈS!`, '#10b981');
    ajouterLogConsolePhonons(`[INFO] ═══════════════════════════════════════════════════════`, '#10b981');
    ajouterLogConsolePhonons(`[INFO] Fin: ${new Date().toLocaleTimeString()}`, '#10b981');
    ajouterLogConsolePhonons(`[INFO] Résultats disponibles dans: ${scfPhononsSelectionne.path}`, '#10b981');
    
    // Activer le bouton "Voir Résultats"
    const btnVoirResultats = document.getElementById('btn_voir_resultats_phonons');
    if (btnVoirResultats) {
        btnVoirResultats.disabled = false;
    }
    
    alert(`🎉 Workflow Phonons terminé!\n\n${etapesCochees.length} étape(s) complétée(s).\n\nConsultez les résultats dans:\n${scfPhononsSelectionne.path}`);
}

/**
 * Lire les checkboxes cochées pour phonons
 */
function lireEtapesPhononsCochees() {
    const etapes = [];
    
    if (document.getElementById('wf_ph_step_ph')?.checked) etapes.push('ph');
    if (document.getElementById('wf_ph_step_q2r')?.checked) etapes.push('q2r');
    if (document.getElementById('wf_ph_step_matdyn')?.checked) etapes.push('matdyn');
    if (document.getElementById('wf_ph_step_thermo')?.checked) etapes.push('thermo');
    if (document.getElementById('wf_ph_step_eph')?.checked) etapes.push('eph');
    
    return etapes;
}

/**
 * Lancer une étape individuelle du workflow phonons
 */
async function lancerEtapePhononsIndividuelle(etape, params) {
    ajouterLogConsolePhonons(`[INFO] 🔄 Lancement de ${etape}...`, '#fbbf24');
    
    try {
        // LANCEMENT NATIF DIRECT (sans API)
        const qeBin = QE_PHONONS_BIN[etape] || QE_PHONONS_BIN.ph;
        const scfDir = scfPhononsSelectionne.path;
        const prefix = scfPhononsSelectionne.nom;
        
        ajouterLogConsolePhonons(`[INFO] Exécutable: ${qeBin}`, '#3b82f6');
        ajouterLogConsolePhonons(`[INFO] Répertoire: ${scfDir}`, '#3b82f6');
        
        // Générer la commande native
        const commande = genererCommandeNativePhonons(etape, scfDir, prefix, params);
        ajouterLogConsolePhonons(`[INFO] Commande: ${commande}`, '#fbbf24');
        
        // Afficher la commande à l'utilisateur pour exécution manuelle
        const executer = confirm(
            `🔧 EXÉCUTION NATIVE\n\n` +
            `Étape: ${etape.toUpperCase()}\n\n` +
            `Commande à exécuter dans un terminal:\n\n` +
            `${commande}\n\n` +
            `Voulez-vous copier cette commande dans le presse-papier?`
        );
        
        if (executer) {
            await navigator.clipboard.writeText(commande);
            ajouterLogConsolePhonons(`[INFO] ✅ Commande copiée dans le presse-papier`, '#10b981');
            ajouterLogConsolePhonons(`[INFO] Collez-la dans un terminal et exécutez-la`, '#fbbf24');
        }
        
        // Simuler l'attente (l'utilisateur doit exécuter manuellement)
        const continuer = confirm(
            `⏳ Exécutez la commande dans un terminal.\n\n` +
            `Une fois le calcul terminé, cliquez sur OK pour continuer.`
        );
        
        if (!continuer) {
            throw new Error('Calcul annulé par l\'utilisateur');
        }
        
        ajouterLogConsolePhonons(`[INFO] ✅ Étape ${etape} marquée comme terminée`, '#10b981');
        
        return {
            success: true,
            output_file: `${scfDir}/${prefix}.${etape}.out`,
            resultats: `Calcul ${etape} exécuté en mode natif`
        };
        
    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Générer la commande native pour une étape phonons
 */
function genererCommandeNativePhonons(etape, scfDir, prefix, params) {
    const qeBin = QE_PHONONS_BIN[etape] || QE_PHONONS_BIN.ph;
    
    let commande = '';
    
    switch (etape) {
        case 'ph':
            commande = `cd ${scfDir} && ${qeBin} < ${prefix}.ph.in > ${prefix}.ph.out 2>&1`;
            break;
        case 'q2r':
            commande = `cd ${scfDir} && ${qeBin} < ${prefix}.q2r.in > ${prefix}.q2r.out 2>&1`;
            break;
        case 'matdyn':
            commande = `cd ${scfDir} && ${qeBin} < ${prefix}.matdyn.in > ${prefix}.matdyn.out 2>&1`;
            break;
        case 'thermo':
            commande = `cd ${scfDir} && ${qeBin} < ${prefix}.matdyn.in > ${prefix}.thermo.out 2>&1`;
            break;
        case 'eph':
            commande = `cd ${scfDir} && ${qeBin} < ${prefix}.lambda.in > ${prefix}.lambda.out 2>&1`;
            break;
        default:
            commande = `cd ${scfDir} && ${qeBin} < ${prefix}.${etape}.in > ${prefix}.${etape}.out 2>&1`;
    }
    
    return commande;
}

/**
 * Suivre un calcul phonons en temps réel
 */
async function suivreCalculPhononsEnTempsReel(calculId) {
    ajouterLogConsolePhonons(`[INFO] 📡 Suivi en temps réel...`, '#3b82f6');
    
    let dernieresLignes = '';
    
    return new Promise((resolve) => {
        const interval = setInterval(async () => {
            try {
                const response = await fetch(`http://localhost:5007/api/etat_calcul/${calculId}`);
                const data = await response.json();
                
                // Afficher les nouveaux logs
                if (data.logs && data.logs !== dernieresLignes) {
                    const nouvelles = extraireNouvellesLignesPhonons(dernieresLignes, data.logs);
                    if (nouvelles) {
                        ajouterLogConsolePhonons(nouvelles, '#e2e8f0');
                    }
                    dernieresLignes = data.logs;
                }
                
                // Vérifier le statut
                if (data.statut === 'termine') {
                    clearInterval(interval);
                    ajouterLogConsolePhonons(`[INFO] ✅ Calcul terminé!`, '#10b981');
                    resolve({ success: true });
                } else if (data.statut === 'erreur') {
                    clearInterval(interval);
                    ajouterLogConsolePhonons(`[ERREUR] ❌ Calcul en erreur`, '#ef4444');
                    resolve({ success: false, error: 'Calcul échoué' });
                }
                
            } catch (error) {
                console.error('Erreur suivi calcul phonons:', error);
            }
        }, 3000);
    });
}

/**
 * Extraire les nouvelles lignes de logs
 */
function extraireNouvellesLignesPhonons(ancienLogs, nouveauxLogs) {
    if (!ancienLogs) return nouveauxLogs;
    if (!nouveauxLogs) return '';
    
    const lignes = nouveauxLogs.split('\n');
    const dernieres = lignes.slice(-10).join('\n');
    
    return dernieres;
}

/**
 * Ajouter un log dans la console phonons
 */
function ajouterLogConsolePhonons(message, couleur = '#e2e8f0') {
    const console_elem = document.getElementById('workflow_phonons_console');
    if (!console_elem) return;
    
    const logLine = document.createElement('div');
    logLine.style.color = couleur;
    logLine.textContent = message;
    
    console_elem.appendChild(logLine);
    console_elem.scrollTop = console_elem.scrollHeight;
}

/**
 * Mettre à jour la progression de l'étape phonons
 */
function mettreAJourProgressionEtapePhonons(numero, total, etape) {
    const stepText = document.getElementById('workflow_phonons_current_step');
    if (stepText) {
        stepText.textContent = `Étape ${numero}/${total}: ${etape.toUpperCase()}`;
    }
    
    const percent = document.getElementById('workflow_phonons_progress_percent');
    if (percent) {
        const progression = Math.round((numero / total) * 100);
        percent.textContent = `${progression}%`;
    }
    
    const bar = document.getElementById('workflow_phonons_progress_bar');
    if (bar) {
        const progression = (numero / total) * 100;
        bar.style.width = `${progression}%`;
    }
    
    // Marquer l'indicateur comme actif
    const indicators = document.querySelectorAll('.step-indicator-ph');
    indicators.forEach((ind, idx) => {
        const circle = ind.querySelector('div');
        if (idx < numero) {
            circle.style.background = '#10b981';
            circle.style.color = 'white';
            circle.textContent = '✓';
        } else if (idx === numero - 1) {
            circle.style.background = '#14b8a6';
            circle.style.color = 'white';
            circle.style.animation = 'pulse 2s infinite';
        }
    });
}

/**
 * Marquer une étape phonons comme complétée
 */
function marquerEtapeCompletePhonons(etape) {
    const mapping = {
        'ph': 0,
        'matdyn': 1,
        'q2r': 2,
        'thermo': 3,
        'eph': 4
    };
    
    const index = mapping[etape];
    if (index === undefined) return;
    
    const indicators = document.querySelectorAll('.step-indicator-ph');
    if (indicators[index]) {
        const circle = indicators[index].querySelector('div');
        circle.style.background = '#10b981';
        circle.style.color = 'white';
        circle.textContent = '✓';
        circle.style.animation = 'none';
    }
}

/**
 * Fonctions de contrôle du workflow
 */
function pauserWorkflowPhonons() {
    alert('⏸️ Fonction de pause en développement');
}

function arreterWorkflowPhonons() {
    if (confirm('⚠️ Voulez-vous vraiment arrêter le workflow phonons?\n\nLes calculs en cours seront interrompus.')) {
        location.reload();
    }
}

function voirResultatsPhonons() {
    if (!scfPhononsSelectionne) {
        alert('⚠️ Aucun résultat disponible');
        return;
    }
    
    alert(`📊 Résultats Phonons disponibles dans:\n\n${scfPhononsSelectionne.path}\n\nFichiers générés:\n• phonon.freq (fréquences)\n• phonon.dos (densité d'états)\n• phonon.plot (dispersion)\n• thermo.dat (thermodynamique)\n• lambda.dat (e-ph, si calculé)`);
}

console.log('✅ Script workflow phonons chargé');

// ─────────────────────────────────────────────────────────────────────────────
// Bouton de démarrage manuel dès l'ouverture du workflow
// ──────────────────��──────────────────────────────────────────────────────────
function initialiserBoutonDebutWorkflowPhonons() {
    try {
        // Zone cible prioritaire si elle existe
        const zoneRacine = document.getElementById('zone_workflow_phonons') || document.body;
        if (!zoneRacine) return;

        // Éviter doublons
        if (document.getElementById('bloc_gate_workflow_phonons')) return;

        const conteneur = document.createElement('div');
        conteneur.id = 'bloc_gate_workflow_phonons';
        conteneur.style.cssText = 'margin: 10px 0 15px 0; padding: 15px; border: 2px solid #3b82f6; border-radius: 8px; background:#eff6ff; text-align: center;';
        conteneur.innerHTML = `
            <div style="margin-bottom: 12px;">
                <h4 style="margin: 0 0 8px 0; color: #1e40af; display: flex; align-items: center; justify-content: center; gap: 8px;">
                    <span style="font-size: 1.3em;">🎯</span>
                    Préparation du Workflow Phonons
                </h4>
                <p style="margin: 0; color: #1e40af; font-size: 0.9em;">
                    Cliquez sur le bouton pour préparer votre matériau et les calculs préliminaires et ouvrir le workflow
                </p>
            </div>
            
            <button id="btn_demarrer_workflow_phonons_gate" style="background: linear-gradient(135deg, #14b8a6 0%, #0d9488 100%); color:white; border:none; padding: 15px 30px; border-radius:8px; cursor:pointer; font-weight:600; font-size: 1.1em; box-shadow: 0 4px 12px rgba(20, 184, 166, 0.4);">
                🚀 Ouvrir la Préparation du Workflow
            </button>
            
            <!-- Zone de préparation (cachée par défaut) -->
            <div id="zone_preparation_workflow_phonons" style="display: none; margin-top: 20px; text-align: left;">
                <!-- Le contenu sera injecté ici -->
            </div>
        `;

        // Insère le conteneur EN BAS de la zone cible (après les autres éléments)
        zoneRacine.appendChild(conteneur);

        const btn = document.getElementById('btn_demarrer_workflow_phonons_gate');
        
        btn?.addEventListener('click', () => {
            afficherPreparationDansPage();
        });
    } catch (e) {
        console.warn('Init bouton gate phonons échouée:', e);
    }
}

/**
 * Afficher la préparation directement dans la page (pas de modale)
 */
function afficherPreparationDansPage() {
    const zonePreparation = document.getElementById('zone_preparation_workflow_phonons');
    if (!zonePreparation) return;
    
    // Masquer le bouton
    const btn = document.getElementById('btn_demarrer_workflow_phonons_gate');
    if (btn) {
        btn.style.display = 'none';
    }
    
    // Afficher la zone de préparation
    zonePreparation.style.display = 'block';
    
    // Injecter le contenu
    zonePreparation.innerHTML = `
        <!-- Section 1.1: Charger le Matériau -->
        <div style="margin-bottom: 25px; padding: 20px; background: #f5f3ff; border: 2px solid #8b5cf6; border-radius: 10px;">
            <h3 style="margin: 0 0 15px 0; color: #6b21a8; display: flex; align-items: center; gap: 10px;">
                <span style="font-size: 1.3em;">📦</span>
                1.1 - Charger le Matériau à Étudier
            </h3>
            <p style="margin: 0 0 15px 0; color: #6b21a8; font-size: 0.9em;">
                Sélectionnez un fichier CIF ou entrez le nom du matériau
            </p>
            
            <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center; margin-bottom: 15px;">
                <input type="text" id="nom_materiau_phonons_input_page" placeholder="Nom du matériau (ex: GaN, BaTiO3)" 
                       style="padding: 12px; border: 2px solid #8b5cf6; border-radius: 8px; flex: 1; min-width: 250px; font-size: 1em;">
                <button onclick="chargerMateriauParNomPage()" 
                        style="background: #8b5cf6; color: white; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em;">
                    ✅ Valider le nom
                </button>
            </div>
            
            <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                <input type="file" id="input_file_materiau_phonons_page" accept=".cif" style="display: none;">
                <button onclick="document.getElementById('input_file_materiau_phonons_page').click()" 
                        style="background: #3b82f6; color: white; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-weight: 600;">
                    📁 Ou charger fichier CIF
                </button>
                <button onclick="chargerDepuisInputsExistantsPage()" 
                        style="background: #10b981; color: white; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-weight: 600;">
                    📂 Ou depuis inputs existants
                </button>
            </div>
            
            <div id="info_materiau_charge_phonons_page" style="display: none; margin-top: 15px; padding: 12px; background: #dcfce7; border: 2px solid #10b981; border-radius: 8px;">
                <div style="display: flex; align-items: center; gap: 8px; color: #065f46; font-weight: 600;">
                    <span style="font-size: 1.2em;">✅</span>
                    <span>Matériau: <span id="nom_materiau_charge_phonons_page"></span></span>
                </div>
                <div id="details_materiau_phonons_page" style="margin-top: 8px; font-size: 0.9em; color: #047857;"></div>
            </div>
        </div>
        
        <!-- Section 1.2: Calculs Préliminaires -->
        <div id="zone_calculs_preliminaires_page" style="display: none;">
            <!-- Sera rempli dynamiquement -->
        </div>
    `;
    
    // Gestionnaire de fichier CIF
    const inputFile = document.getElementById('input_file_materiau_phonons_page');
    inputFile?.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (file) {
            await traiterFichierMateriauPhononsPage(file);
        }
    });
    
    // Scroll vers la zone de préparation
    zonePreparation.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/**
 * Charger un matériau par son nom (version page)
 */
function chargerMateriauParNomPage() {
    const nomInput = document.getElementById('nom_materiau_phonons_input_page');
    const nom = nomInput?.value.trim();
    
    if (!nom) {
        alert('⚠️ Veuillez entrer le nom du matériau');
        return;
    }
    
    materiauPhononsCharge = {
        nom: nom,
        source: 'nom',
        formule: nom
    };
    
    const infoDiv = document.getElementById('info_materiau_charge_phonons_page');
    const nomDiv = document.getElementById('nom_materiau_charge_phonons_page');
    const detailsDiv = document.getElementById('details_materiau_phonons_page');
    
    if (nomDiv) nomDiv.textContent = nom;
    if (detailsDiv) detailsDiv.innerHTML = `<div>Source: Nom saisi manuellement</div>`;
    if (infoDiv) infoDiv.style.display = 'block';
    
    // Afficher les calculs préliminaires
    afficherCalculsPreliminairesPage();
}

/**
 * Traiter le fichier CIF chargé (version page)
 */
async function traiterFichierMateriauPhononsPage(file) {
    const infoDiv = document.getElementById('info_materiau_charge_phonons_page');
    const nomDiv = document.getElementById('nom_materiau_charge_phonons_page');
    const detailsDiv = document.getElementById('details_materiau_phonons_page');
    
    if (!infoDiv || !nomDiv) return;
    
    try {
        const contenu = await file.text();
        const lignes = contenu.split('\n');
        const formule = lignes.find(l => l.includes('_chemical_formula'))?.split(/\s+/).pop() || 'Inconnu';
        
        materiauPhononsCharge = {
            nom: file.name.replace('.cif', ''),
            fichier: file.name,
            formule: formule,
            contenu: contenu,
            source: 'cif'
        };
        
        nomDiv.textContent = materiauPhononsCharge.nom;
        detailsDiv.innerHTML = `
            <div>Formule: ${formule}</div>
            <div>Fichier: ${file.name}</div>
        `;
        infoDiv.style.display = 'block';
        
        afficherCalculsPreliminairesPage();
        
    } catch (error) {
        alert(`❌ Erreur lors du chargement du fichier:\n\n${error.message}`);
    }
}

/**
 * Charger depuis inputs existants (version page)
 */
async function chargerDepuisInputsExistantsPage() {
    try {
        const response = await fetch('http://localhost:5007/api/lister_inputs');
        const data = await response.json();
        
        if (!data.success || !data.inputs || data.inputs.length === 0) {
            alert('⚠️ Aucun input trouvé.\n\nCréez d\'abord un input dans l\'onglet approprié.');
            return;
        }
        
        // Créer une liste de sélection dans la page
        let html = '<div style="padding: 15px; background: white; border-radius: 8px; max-height: 300px; overflow-y: auto; border: 2px solid #e2e8f0; margin-top: 15px;">';
        html += '<h5 style="margin: 0 0 10px 0;">Sélectionnez un input:</h5>';
        
        data.inputs.forEach(input => {
            html += `
                <button onclick="selectionnerInputPourPhononsPage('${input.path}', '${input.nom}')" 
                        style="display: block; width: 100%; text-align: left; padding: 10px; margin: 5px 0; 
                               background: #f8fafc; border: 2px solid #e2e8f0; border-radius: 6px; cursor: pointer;">
                    <div style="font-weight: 600; color: #1e293b;">${input.nom}</div>
                    <div style="font-size: 0.85em; color: #64748b;">${input.path}</div>
                </button>
            `;
        });
        
        html += '</div>';
        
        const zoneCalcs = document.getElementById('zone_calculs_preliminaires_page');
        if (zoneCalcs) {
            zoneCalcs.innerHTML = html;
            zoneCalcs.style.display = 'block';
        }
        
    } catch (error) {
        alert(`❌ Erreur:\n\n${error.message}`);
    }
}

/**
 * Sélectionner un input pour phonons (version page)
 */
async function selectionnerInputPourPhononsPage(path, nom) {
    materiauPhononsCharge = {
        nom: nom,
        path: path,
        source: 'input'
    };
    
    const infoDiv = document.getElementById('info_materiau_charge_phonons_page');
    const nomDiv = document.getElementById('nom_materiau_charge_phonons_page');
    const detailsDiv = document.getElementById('details_materiau_phonons_page');
    
    if (nomDiv) nomDiv.textContent = nom;
    if (detailsDiv) detailsDiv.innerHTML = `<div>Source: Input existant</div><div>Chemin: ${path}</div>`;
    if (infoDiv) infoDiv.style.display = 'block';
    
    afficherCalculsPreliminairesPage();
}

/**
 * Afficher les calculs préliminaires (version page)
 */
function afficherCalculsPreliminairesPage() {
    const zone = document.getElementById('zone_calculs_preliminaires_page');
    if (!zone) return;
    
    const nom = materiauPhononsCharge.nom;
    
    zone.innerHTML = `
        <div style="padding: 20px; background: #fff7ed; border: 2px solid #f59e0b; border-radius: 10px;">
            <h3 style="margin: 0 0 15px 0; color: #92400e;">📋 1.2 - Calculs Préliminaires Requis</h3>
            
            <!-- Calcul 1: VC-RELAX -->
            <div style="margin: 15px 0; padding: 15px; background: white; border: 2px solid #e2e8f0; border-radius: 8px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                    <span style="font-size: 1.3em;">1️⃣</span>
                    <h4 style="margin: 0; color: #1e293b;">Calcul VC-RELAX - Optimisation complète</h4>
                </div>
                <p style="margin: 5px 0 10px 0; font-size: 0.9em; color: #64748b;">
                    Optimise la géométrie ET les paramètres de maille
                </p>
                <button onclick="editerInputVCRelax('${nom}')" 
                        style="background: #3b82f6; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                    ✏️ Éditer input VC-RELAX
                </button>
                <span id="statut_vcrelax_page" style="margin-left: 10px; color: #94a3b8; font-weight: 600;">⏳ En attente</span>
            </div>
            
            <!-- Calcul 2: RELAX (optionnel) -->
            <div style="margin: 15px 0; padding: 15px; background: white; border: 2px solid #e2e8f0; border-radius: 8px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                    <span style="font-size: 1.3em;">2️⃣</span>
                    <h4 style="margin: 0; color: #1e293b;">Calcul RELAX - Optimisation positions (optionnel)</h4>
                </div>
                <p style="margin: 5px 0 10px 0; font-size: 0.9em; color: #64748b;">
                    Optimise uniquement les positions atomiques (maille fixe)
                </p>
                <button onclick="editerInputRelax('${nom}')" 
                        style="background: #8b5cf6; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                    ✏️ Éditer input RELAX
                </button>
                <span id="statut_relax_page" style="margin-left: 10px; color: #94a3b8; font-weight: 600;">⏳ Optionnel</span>
            </div>
            
            <!-- Calcul 3: SCF -->
            <div style="margin: 15px 0; padding: 15px; background: white; border: 2px solid #e2e8f0; border-radius: 8px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                    <span style="font-size: 1.3em;">3️⃣</span>
                    <h4 style="margin: 0; color: #1e293b;">Calcul SCF - Calcul self-consistent</h4>
                </div>
                <p style="margin: 5px 0 10px 0; font-size: 0.9em; color: #64748b;">
                    Calcul de la densité électronique convergée (requis pour phonons)
                </p>
                <button onclick="editerInputSCF('${nom}')" 
                        style="background: #10b981; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                    ✏️ Éditer input SCF
                </button>
                <span id="statut_scf_page" style="margin-left: 10px; color: #94a3b8; font-weight: 600;">⏳ En attente</span>
            </div>
            
            <!-- Bouton pour continuer -->
            <div style="margin-top: 25px; padding: 20px; background: #dcfce7; border: 2px solid #10b981; border-radius: 10px; text-align: center;">
                <div style="color: #065f46; font-weight: 600; font-size: 1.1em; margin-bottom: 15px;">
                    ✅ Une fois les calculs préliminaires terminés, vous pouvez continuer
                </div>
                <button onclick="continuerVersEtape2()" 
                        style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; border: none; padding: 15px 40px; border-radius: 10px; cursor: pointer; font-weight: 600; font-size: 1.2em; box-shadow: 0 4px 15px rgba(16, 185, 129, 0.4);">
                    ▶️ Continuer vers l'ÉTAPE 2 (Sélection SCF)
                </button>
            </div>
        </div>
    `;
    
    zone.style.display = 'block';
}

/**
 * Continuer vers l'ÉTAPE 2
 */
function continuerVersEtape2() {
    // Autoriser le workflow
    gateDebutWorkflowPhononsAutorise = true;
    
    // Scroll vers la zone de sélection SCF (ÉTAPE 2)
    const zoneScf = document.getElementById('zone_scf_phonons');
    if (zoneScf) {
        zoneScf.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
        alert('✅ Préparation terminée!\n\nVous pouvez maintenant sélectionner le calcul SCF dans l\'ÉTAPE 2 ci-dessous.');
    }
}

/**
 * Ouvrir la fenêtre modale de préparation du workflow phonons
 */
function ouvrirFenetrePreparationPhonons() {
    // Créer la fenêtre modale
    const modal = document.createElement('div');
    modal.id = 'modal_preparation_phonons';
    modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); display: flex; align-items: center; justify-content: center; z-index: 10000; overflow-y: auto;';
    
    modal.innerHTML = `
        <div style="background: white; padding: 30px; border-radius: 15px; max-width: 1200px; width: 95%; max-height: 90vh; overflow-y: auto; position: relative;">
            <!-- En-tête -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; padding-bottom: 20px; border-bottom: 3px solid #14b8a6;">
                <div>
                    <h2 style="margin: 0; color: #1e293b; display: flex; align-items: center; gap: 10px;">
                        <span style="font-size: 1.5em;">🎯</span>
                        ÉTAPE 1: Préparation du Workflow Phonons
                    </h2>
                    <p style="margin: 5px 0 0 0; color: #64748b;">
                        Préparez votre matériau et lancez les calculs préliminaires requis
                    </p>
                </div>
                <button onclick="fermerFenetrePreparationPhonons()" style="background: #ef4444; color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em;">
                    ✕ Fermer
                </button>
            </div>
            
            <!-- Contenu de la préparation -->
            <div id="contenu_preparation_phonons">
                <!-- Le contenu sera injecté ici -->
            </div>
            
            <!-- Bouton de validation finale -->
            <div id="zone_validation_finale" style="display: none; margin-top: 30px; padding: 20px; background: #dcfce7; border: 2px solid #10b981; border-radius: 10px; text-align: center;">
                <div style="color: #065f46; font-weight: 600; font-size: 1.1em; margin-bottom: 15px;">
                    ✅ Préparation terminée! Tous les calculs préliminaires sont prêts.
                </div>
                <button onclick="validerPreparationEtContinuer()" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; border: none; padding: 15px 40px; border-radius: 10px; cursor: pointer; font-weight: 600; font-size: 1.2em; box-shadow: 0 4px 15px rgba(16, 185, 129, 0.4);">
                    ▶️ Continuer vers l'ÉTAPE 2 (Sélection SCF)
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Initialiser le contenu de la préparation
    initialiserContenuPreparation();
}

/**
 * Fermer la fenêtre de préparation
 */
function fermerFenetrePreparationPhonons() {
    const modal = document.getElementById('modal_preparation_phonons');
    if (modal) {
        modal.remove();
    }
}

/**
 * Initialiser le contenu de la fenêtre de préparation
 */
function initialiserContenuPreparation() {
    const contenu = document.getElementById('contenu_preparation_phonons');
    if (!contenu) return;
    
    contenu.innerHTML = `
        <!-- Section 1.1: Charger le Matériau -->
        <div style="margin-bottom: 25px; padding: 20px; background: #f5f3ff; border: 2px solid #8b5cf6; border-radius: 10px;">
            <h3 style="margin: 0 0 15px 0; color: #6b21a8; display: flex; align-items: center; gap: 10px;">
                <span style="font-size: 1.3em;">📦</span>
                1.1 - Charger le Matériau à Étudier
            </h3>
            <p style="margin: 0 0 15px 0; color: #6b21a8; font-size: 0.9em;">
                Sélectionnez un fichier CIF ou entrez le nom du matériau
            </p>
            
            <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center; margin-bottom: 15px;">
                <input type="text" id="nom_materiau_phonons_input_modal" placeholder="Nom du matériau (ex: GaN, BaTiO3)" 
                       style="padding: 12px; border: 2px solid #8b5cf6; border-radius: 8px; flex: 1; min-width: 250px; font-size: 1em;">
                <button onclick="chargerMateriauParNomModal()" 
                        style="background: #8b5cf6; color: white; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em;">
                    ✅ Valider le nom
                </button>
            </div>
            
            <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                <input type="file" id="input_file_materiau_phonons_modal" accept=".cif" style="display: none;">
                <button onclick="document.getElementById('input_file_materiau_phonons_modal').click()" 
                        style="background: #3b82f6; color: white; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-weight: 600;">
                    📁 Ou charger fichier CIF
                </button>
                <button onclick="chargerDepuisInputsExistantsModal()" 
                        style="background: #10b981; color: white; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-weight: 600;">
                    📂 Ou depuis inputs existants
                </button>
            </div>
            
            <div id="info_materiau_charge_phonons_modal" style="display: none; margin-top: 15px; padding: 12px; background: #dcfce7; border: 2px solid #10b981; border-radius: 8px;">
                <div style="display: flex; align-items: center; gap: 8px; color: #065f46; font-weight: 600;">
                    <span style="font-size: 1.2em;">✅</span>
                    <span>Matériau: <span id="nom_materiau_charge_phonons_modal"></span></span>
                </div>
                <div id="details_materiau_phonons_modal" style="margin-top: 8px; font-size: 0.9em; color: #047857;"></div>
            </div>
        </div>
        
        <!-- Section 1.2: Calculs Préliminaires -->
        <div id="zone_calculs_preliminaires_modal" style="display: none;">
            <!-- Sera rempli dynamiquement -->
        </div>
    `;
    
    // Gestionnaire de fichier CIF
    const inputFile = document.getElementById('input_file_materiau_phonons_modal');
    inputFile?.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (file) {
            await traiterFichierMateriauPhononsModal(file);
        }
    });
}

/**
 * Charger un matériau par son nom (version modale)
 */
function chargerMateriauParNomModal() {
    const nomInput = document.getElementById('nom_materiau_phonons_input_modal');
    const nom = nomInput?.value.trim();
    
    if (!nom) {
        alert('⚠️ Veuillez entrer le nom du matériau');
        return;
    }
    
    materiauPhononsCharge = {
        nom: nom,
        source: 'nom',
        formule: nom
    };
    
    const infoDiv = document.getElementById('info_materiau_charge_phonons_modal');
    const nomDiv = document.getElementById('nom_materiau_charge_phonons_modal');
    const detailsDiv = document.getElementById('details_materiau_phonons_modal');
    
    if (nomDiv) nomDiv.textContent = nom;
    if (detailsDiv) detailsDiv.innerHTML = `<div>Source: Nom saisi manuellement</div>`;
    if (infoDiv) infoDiv.style.display = 'block';
    
    // Afficher les calculs préliminaires
    afficherCalculsPreliminairesModal();
}

/**
 * Traiter le fichier CIF chargé (version modale)
 */
async function traiterFichierMateriauPhononsModal(file) {
    const infoDiv = document.getElementById('info_materiau_charge_phonons_modal');
    const nomDiv = document.getElementById('nom_materiau_charge_phonons_modal');
    const detailsDiv = document.getElementById('details_materiau_phonons_modal');
    
    if (!infoDiv || !nomDiv) return;
    
    try {
        const contenu = await file.text();
        const lignes = contenu.split('\n');
        const formule = lignes.find(l => l.includes('_chemical_formula'))?.split(/\s+/).pop() || 'Inconnu';
        
        materiauPhononsCharge = {
            nom: file.name.replace('.cif', ''),
            fichier: file.name,
            formule: formule,
            contenu: contenu,
            source: 'cif'
        };
        
        nomDiv.textContent = materiauPhononsCharge.nom;
        detailsDiv.innerHTML = `
            <div>Formule: ${formule}</div>
            <div>Fichier: ${file.name}</div>
        `;
        infoDiv.style.display = 'block';
        
        afficherCalculsPreliminairesModal();
        
    } catch (error) {
        alert(`❌ Erreur lors du chargement du fichier:\n\n${error.message}`);
    }
}

/**
 * Charger depuis inputs existants (version modale)
 */
async function chargerDepuisInputsExistantsModal() {
    try {
        const response = await fetch('http://localhost:5007/api/lister_inputs');
        const data = await response.json();
        
        if (!data.success || !data.inputs || data.inputs.length === 0) {
            alert('⚠️ Aucun input trouvé.\n\nCréez d\'abord un input dans l\'onglet approprié.');
            return;
        }
        
        // Créer une liste de sélection dans la modale
        let html = '<div style="padding: 15px; background: white; border-radius: 8px; max-height: 300px; overflow-y: auto; border: 2px solid #e2e8f0;">';
        html += '<h5 style="margin: 0 0 10px 0;">Sélectionnez un input:</h5>';
        
        data.inputs.forEach(input => {
            html += `
                <button onclick="selectionnerInputPourPhononsModal('${input.path}', '${input.nom}')" 
                        style="display: block; width: 100%; text-align: left; padding: 10px; margin: 5px 0; 
                               background: #f8fafc; border: 2px solid #e2e8f0; border-radius: 6px; cursor: pointer;">
                    <div style="font-weight: 600; color: #1e293b;">${input.nom}</div>
                    <div style="font-size: 0.85em; color: #64748b;">${input.path}</div>
                </button>
            `;
        });
        
        html += '</div>';
        
        const zoneCalcs = document.getElementById('zone_calculs_preliminaires_modal');
        if (zoneCalcs) {
            zoneCalcs.innerHTML = html;
            zoneCalcs.style.display = 'block';
        }
        
    } catch (error) {
        alert(`❌ Erreur:\n\n${error.message}`);
    }
}

/**
 * Sélectionner un input pour phonons (version modale)
 */
async function selectionnerInputPourPhononsModal(path, nom) {
    materiauPhononsCharge = {
        nom: nom,
        path: path,
        source: 'input'
    };
    
    const infoDiv = document.getElementById('info_materiau_charge_phonons_modal');
    const nomDiv = document.getElementById('nom_materiau_charge_phonons_modal');
    const detailsDiv = document.getElementById('details_materiau_phonons_modal');
    
    if (nomDiv) nomDiv.textContent = nom;
    if (detailsDiv) detailsDiv.innerHTML = `<div>Source: Input existant</div><div>Chemin: ${path}</div>`;
    if (infoDiv) infoDiv.style.display = 'block';
    
    afficherCalculsPreliminairesModal();
}

/**
 * Afficher les calculs préliminaires (version modale)
 */
function afficherCalculsPreliminairesModal() {
    const zone = document.getElementById('zone_calculs_preliminaires_modal');
    if (!zone) return;
    
    const nom = materiauPhononsCharge.nom;
    
    zone.innerHTML = `
        <div style="padding: 20px; background: #fff7ed; border: 2px solid #f59e0b; border-radius: 10px;">
            <h3 style="margin: 0 0 15px 0; color: #92400e;">📋 1.2 - Calculs Préliminaires Requis</h3>
            
            <!-- Calcul 1: VC-RELAX -->
            <div style="margin: 15px 0; padding: 15px; background: white; border: 2px solid #e2e8f0; border-radius: 8px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                    <span style="font-size: 1.3em;">1️⃣</span>
                    <h4 style="margin: 0; color: #1e293b;">Calcul VC-RELAX - Optimisation complète</h4>
                </div>
                <p style="margin: 5px 0 10px 0; font-size: 0.9em; color: #64748b;">
                    Optimise la géométrie ET les paramètres de maille
                </p>
                <button onclick="editerInputVCRelax('${nom}')" 
                        style="background: #3b82f6; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                    ✏️ Éditer input VC-RELAX
                </button>
                <span id="statut_vcrelax_modal" style="margin-left: 10px; color: #94a3b8; font-weight: 600;">⏳ En attente</span>
            </div>
            
            <!-- Calcul 2: RELAX (optionnel) -->
            <div style="margin: 15px 0; padding: 15px; background: white; border: 2px solid #e2e8f0; border-radius: 8px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                    <span style="font-size: 1.3em;">2��⃣</span>
                    <h4 style="margin: 0; color: #1e293b;">Calcul RELAX - Optimisation positions (optionnel)</h4>
                </div>
                <p style="margin: 5px 0 10px 0; font-size: 0.9em; color: #64748b;">
                    Optimise uniquement les positions atomiques (maille fixe)
                </p>
                <button onclick="editerInputRelax('${nom}')" 
                        style="background: #8b5cf6; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                    ✏️ Éditer input RELAX
                </button>
                <span id="statut_relax_modal" style="margin-left: 10px; color: #94a3b8; font-weight: 600;">⏳ Optionnel</span>
            </div>
            
            <!-- Calcul 3: SCF -->
            <div style="margin: 15px 0; padding: 15px; background: white; border: 2px solid #e2e8f0; border-radius: 8px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                    <span style="font-size: 1.3em;">3️⃣</span>
                    <h4 style="margin: 0; color: #1e293b;">Calcul SCF - Calcul self-consistent</h4>
                </div>
                <p style="margin: 5px 0 10px 0; font-size: 0.9em; color: #64748b;">
                    Calcul de la densité électronique convergée (requis pour phonons)
                </p>
                <button onclick="editerInputSCF('${nom}')" 
                        style="background: #10b981; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                    ✏️ Éditer input SCF
                </button>
                <span id="statut_scf_modal" style="margin-left: 10px; color: #94a3b8; font-weight: 600;">⏳ En attente</span>
            </div>
        </div>
    `;
    
    zone.style.display = 'block';
}

/**
 * Valider la préparation et continuer vers l'ÉTAPE 2
 */
function validerPreparationEtContinuer() {
    // Autoriser le workflow
    gateDebutWorkflowPhononsAutorise = true;
    
    // Fermer la fenêtre modale
    fermerFenetrePreparationPhonons();
    
    // Afficher un message de succès
    alert('✅ Préparation terminée!\n\nVous pouvez maintenant sélectionner le calcul SCF dans l\'ÉTAPE 2.');
    
    // Scroller vers la zone de sélection SCF (ÉTAPE 2)
    const zoneScf = document.getElementById('zone_scf_phonons');
    if (zoneScf) {
        zoneScf.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

// Tente d'initialiser dès le chargement du script (si DOM prêt). Sinon, à l'appel du chargeur.
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialiserBoutonDebutWorkflowPhonons);
} else {
    initialiserBoutonDebutWorkflowPhonons();
}

// ═════════════════════════════════════════════════════════════════════════════
// GESTION INTELLIGENTE DES PRÉREQUIS PHONONS
// ═════════════════════════════════════════════════════════════════════════════

/**
 * Initialiser le chargeur de matériau pour phonons
 */
function initialiserChargeurMateriauPhonons() {
    try {
        const zoneRacine = document.getElementById('zone_workflow_phonons') || document.body;
        if (!zoneRacine) return;
        
        // Éviter doublons
        if (document.getElementById('bloc_chargeur_materiau_phonons')) return;
        
        const conteneur = document.createElement('div');
        conteneur.id = 'bloc_chargeur_materiau_phonons';
        conteneur.style.cssText = 'margin: 15px 0; padding: 15px; border: 2px solid #8b5cf6; border-radius: 8px; background:#f5f3ff;';
        conteneur.innerHTML = `
            <div style="margin-bottom: 12px;">
                <h4 style="margin: 0 0 8px 0; color: #6b21a8; display: flex; align-items: center; gap: 8px;">
                    <span style="font-size: 1.3em;">📦</span>
                    1.1 - Charger le Matériau à Étudier
                </h4>
                <p style="margin: 0; color: #6b21a8; font-size: 0.9em;">
                    Sélectionnez un fichier CIF ou entrez le nom du matériau
                </p>
            </div>
            
            <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center; margin-bottom: 12px;">
                <input type="text" id="nom_materiau_phonons_input" placeholder="Nom du matériau (ex: GaN, BaTiO3)" 
                       style="padding: 10px; border: 2px solid #8b5cf6; border-radius: 6px; flex: 1; min-width: 200px;">
                <button onclick="chargerMateriauParNom()" 
                        style="background: #8b5cf6; color: white; border: none; padding: 10px 16px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                    ✅ Valider le nom
                </button>
            </div>
            
            <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                <input type="file" id="input_file_materiau_phonons" accept=".cif" style="display: none;">
                <button onclick="document.getElementById('input_file_materiau_phonons').click()" 
                        style="background: #3b82f6; color: white; border: none; padding: 10px 16px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                    📁 Ou charger fichier CIF
                </button>
                <button onclick="chargerDepuisInputsExistants()" 
                        style="background: #10b981; color: white; border: none; padding: 10px 16px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                    📂 Ou depuis inputs existants
                </button>
            </div>
            
            <div id="info_materiau_charge_phonons" style="display: none; margin-top: 12px; padding: 10px; background: #dcfce7; border: 2px solid #10b981; border-radius: 6px;">
                <div style="display: flex; align-items: center; gap: 8px; color: #065f46; font-weight: 600;">
                    <span style="font-size: 1.2em;">✅</span>
                    <span>Matériau: <span id="nom_materiau_charge_phonons"></span></span>
                </div>
                <div id="details_materiau_phonons" style="margin-top: 8px; font-size: 0.85em; color: #047857;"></div>
            </div>
            
            <div id="zone_calculs_preliminaires" style="display: none; margin-top: 15px;"></div>
        `;
        
        // Insérer dans le bloc gate (ÉTAPE 1)
        const blocGate = document.getElementById('bloc_gate_workflow_phonons');
        if (blocGate) {
            blocGate.appendChild(conteneur);
        } else {
            zoneRacine.insertBefore(conteneur, zoneRacine.firstChild);
        }
        
        // Gestionnaire de fichier
        const inputFile = document.getElementById('input_file_materiau_phonons');
        inputFile?.addEventListener('change', async (e) => {
            const file = e.target.files[0];
            if (file) {
                await traiterFichierMateriauPhonons(file);
            }
        });
        
    } catch (e) {
        console.warn('Init chargeur matériau phonons échouée:', e);
    }
}

/**
 * Charger un matériau par son nom
 */
function chargerMateriauParNom() {
    const nomInput = document.getElementById('nom_materiau_phonons_input');
    const nom = nomInput?.value.trim();
    
    if (!nom) {
        alert('⚠️ Veuillez entrer le nom du matériau');
        return;
    }
    
    materiauPhononsCharge = {
        nom: nom,
        source: 'nom',
        formule: nom
    };
    
    const infoDiv = document.getElementById('info_materiau_charge_phonons');
    const nomDiv = document.getElementById('nom_materiau_charge_phonons');
    const detailsDiv = document.getElementById('details_materiau_phonons');
    
    if (nomDiv) nomDiv.textContent = nom;
    if (detailsDiv) detailsDiv.innerHTML = `<div>Source: Nom saisi manuellement</div>`;
    if (infoDiv) infoDiv.style.display = 'block';
    
    // Afficher les calculs préliminaires
    afficherCalculsPreliminaires();
}

/**
 * Traiter le fichier CIF chargé
 */
async function traiterFichierMateriauPhonons(file) {
    const infoDiv = document.getElementById('info_materiau_charge_phonons');
    const nomDiv = document.getElementById('nom_materiau_charge_phonons');
    const detailsDiv = document.getElementById('details_materiau_phonons');
    
    if (!infoDiv || !nomDiv) return;
    
    try {
        // Lire le fichier
        const contenu = await file.text();
        
        // Extraire les infos basiques
        const lignes = contenu.split('\n');
        const formule = lignes.find(l => l.includes('_chemical_formula'))?.split(/\s+/).pop() || 'Inconnu';
        
        materiauPhononsCharge = {
            nom: file.name.replace('.cif', ''),
            fichier: file.name,
            formule: formule,
            contenu: contenu,
            source: 'cif'
        };
        
        nomDiv.textContent = materiauPhononsCharge.nom;
        detailsDiv.innerHTML = `
            <div>Formule: ${formule}</div>
            <div>Fichier: ${file.name}</div>
        `;
        infoDiv.style.display = 'block';
        
        // Afficher les calculs préliminaires
        afficherCalculsPreliminaires();
        
    } catch (error) {
        alert(`❌ Erreur lors du chargement du fichier:\n\n${error.message}`);
    }
}

/**
 * Charger depuis les inputs existants
 */
async function chargerDepuisInputsExistants() {
    try {
        const response = await fetch('http://localhost:5007/api/lister_inputs');
        const data = await response.json();
        
        if (!data.success || !data.inputs || data.inputs.length === 0) {
            alert('⚠️ Aucun input trouvé.\n\nCréez d\'abord un input dans l\'onglet approprié.');
            return;
        }
        
        // Créer une liste de sélection
        let html = '<div style="padding: 15px; background: white; border-radius: 8px; max-height: 400px; overflow-y: auto;">';
        html += '<h5 style="margin: 0 0 10px 0;">Sélectionnez un input:</h5>';
        
        data.inputs.forEach(input => {
            html += `
                <button onclick="selectionnerInputPourPhonons('${input.path}', '${input.nom}')" 
                        style="display: block; width: 100%; text-align: left; padding: 10px; margin: 5px 0; 
                               background: #f8fafc; border: 2px solid #e2e8f0; border-radius: 6px; cursor: pointer;">
                    <div style="font-weight: 600; color: #1e293b;">${input.nom}</div>
                    <div style="font-size: 0.85em; color: #64748b;">${input.path}</div>
                </button>
            `;
        });
        
        html += '</div>';
        
        // Afficher dans une modal ou zone dédiée
        const zoneVerif = document.getElementById('zone_verification_prerequis');
        if (zoneVerif) {
            zoneVerif.innerHTML = html;
            zoneVerif.style.display = 'block';
        }
        
    } catch (error) {
        alert(`❌ Erreur:\n\n${error.message}`);
    }
}

/**
 * Sélectionner un input pour phonons
 */
async function selectionnerInputPourPhonons(path, nom) {
    materiauPhononsCharge = {
        nom: nom,
        path: path,
        source: 'input'
    };
    
    const infoDiv = document.getElementById('info_materiau_charge_phonons');
    const nomDiv = document.getElementById('nom_materiau_charge_phonons');
    const detailsDiv = document.getElementById('details_materiau_phonons');
    
    if (nomDiv) nomDiv.textContent = nom;
    if (detailsDiv) detailsDiv.innerHTML = `<div>Source: Input existant</div><div>Chemin: ${path}</div>`;
    if (infoDiv) infoDiv.style.display = 'block';
    
    // Masquer la liste
    const zoneCalcsPrelim = document.getElementById('zone_calculs_preliminaires');
    if (zoneCalcsPrelim) zoneCalcsPrelim.innerHTML = '';
    
    // Afficher les calculs préliminaires
    afficherCalculsPreliminaires();
}

/**
 * Afficher les calculs préliminaires
 */
function afficherCalculsPreliminaires() {
    const zone = document.getElementById('zone_calculs_preliminaires');
    if (!zone) return;
    
    const nom = materiauPhononsCharge.nom;
    
    zone.innerHTML = `
        <div style="border-top: 2px dashed #8b5cf6; padding-top: 15px;">
            <h4 style="margin: 0 0 12px 0; color: #6b21a8;">📋 Calculs Préliminaires Requis</h4>
            
            <!-- Calcul 1: VC-RELAX -->
            <div id="bloc_vcrelax" style="margin: 10px 0; padding: 12px; background: white; border: 2px solid #e2e8f0; border-radius: 8px;">
                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
                    <span style="font-size: 1.2em;">1️⃣</span>
                    <h5 style="margin: 0; color: #1e293b;">Calcul VC-RELAX - Optimisation complète</h5>
                </div>
                <p style="margin: 5px 0; font-size: 0.9em; color: #64748b;">
                    Optimise la géométrie ET les paramètres de maille
                </p>
                <button onclick="editerInputVCRelax('${nom}')" 
                        style="background: #3b82f6; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: 600; margin-top: 8px;">
                    ✏️ Éditer input VC-RELAX
                </button>
                <span id="statut_vcrelax" style="margin-left: 10px; color: #94a3b8;">⏳ En attente</span>
            </div>
            
            <!-- Calcul 2: RELAX (optionnel) -->
            <div id="bloc_relax" style="margin: 10px 0; padding: 12px; background: white; border: 2px solid #e2e8f0; border-radius: 8px;">
                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
                    <span style="font-size: 1.2em;">2️⃣</span>
                    <h5 style="margin: 0; color: #1e293b;">Calcul RELAX - Optimisation positions (optionnel)</h5>
                </div>
                <p style="margin: 5px 0; font-size: 0.9em; color: #64748b;">
                    Optimise uniquement les positions atomiques (maille fixe)
                </p>
                <button onclick="editerInputRelax('${nom}')" 
                        style="background: #8b5cf6; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: 600; margin-top: 8px;">
                    ✏️ Éditer input RELAX
                </button>
                <span id="statut_relax" style="margin-left: 10px; color: #94a3b8;">⏳ Optionnel</span>
            </div>
            
            <!-- Calcul 3: SCF -->
            <div id="bloc_scf" style="margin: 10px 0; padding: 12px; background: white; border: 2px solid #e2e8f0; border-radius: 8px;">
                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
                    <span style="font-size: 1.2em;">3️⃣</span>
                    <h5 style="margin: 0; color: #1e293b;">Calcul SCF - Calcul self-consistent</h5>
                </div>
                <p style="margin: 5px 0; font-size: 0.9em; color: #64748b;">
                    Calcul de la densité électronique convergée (requis pour phonons)
                </p>
                <button onclick="editerInputSCF('${nom}')" 
                        style="background: #10b981; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: 600; margin-top: 8px;">
                    ✏️ Éditer input SCF
                </button>
                <span id="statut_scf" style="margin-left: 10px; color: #94a3b8;">⏳ En attente</span>
            </div>
            
            <!-- Vérification finale -->
            <div id="bloc_verification_finale" style="display: none; margin: 15px 0; padding: 12px; background: #dcfce7; border: 2px solid #10b981; border-radius: 8px; text-align: center;">
                <div style="color: #065f46; font-weight: 600; margin-bottom: 8px;">
                    ✅ Tous les calculs préliminaires sont terminés!
                </div>
                <button onclick="passerAuxCalculsPhonons()" 
                        style="background: #10b981; color: white; border: none; padding: 12px 24px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 1.1em;">
                    ▶️ Passer aux calculs PHONONS (ÉTAPE 2)
                </button>
            </div>
        </div>
    `;
    
    zone.style.display = 'block';
}

/**
 * Éditer l'input VC-RELAX
 */
function editerInputVCRelax(nom) {
    const modal = creerModalEditeur('VC-RELAX', nom, genererTemplateVCRelax(nom), getRecommandationsVCRelax());
    document.body.appendChild(modal);
}

/**
 * Éditer l'input RELAX
 */
function editerInputRelax(nom) {
    const modal = creerModalEditeur('RELAX', nom, genererTemplateRelax(nom), getRecommandationsRelax());
    document.body.appendChild(modal);
}

/**
 * Éditer l'input SCF
 */
function editerInputSCF(nom) {
    const modal = creerModalEditeur('SCF', nom, genererTemplateSCF(nom), getRecommandationsSCF());
    document.body.appendChild(modal);
}

/**
 * Créer une modal d'édition d'input
 */
function creerModalEditeur(typeCalcul, nom, template, recommandations) {
    const modal = document.createElement('div');
    modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); display: flex; align-items: center; justify-content: center; z-index: 10000;';
    
    modal.innerHTML = `
        <div style="background: white; padding: 20px; border-radius: 10px; max-width: 1200px; width: 95%; max-height: 90vh; overflow-y: auto;">
            <h3 style="margin: 0 0 15px 0; color: #1e293b;">✏️ Éditer Input ${typeCalcul} - ${nom}</h3>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                <!-- Zone d'édition -->
                <div>
                    <h4 style="margin: 0 0 8px 0; color: #3b82f6;">📝 Input File</h4>
                    <textarea id="editor_input_${typeCalcul.toLowerCase()}" 
                              style="width: 100%; height: 500px; font-family: monospace; font-size: 13px; padding: 10px; border: 2px solid #e2e8f0; border-radius: 6px;">${template}</textarea>
                </div>
                
                <!-- Recommandations -->
                <div>
                    <h4 style="margin: 0 0 8px 0; color: #f59e0b;">💡 Recommandations</h4>
                    <div style="background: #fffbeb; padding: 15px; border-radius: 6px; border: 2px solid #fbbf24; height: 500px; overflow-y: auto; font-size: 0.9em;">
                        ${recommandations}
                    </div>
                </div>
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: space-between; align-items: center;">
                <!-- Message de statut -->
                <div id="statut_sauvegarde_${typeCalcul.toLowerCase()}" style="color: #64748b; font-size: 0.9em; font-style: italic;">
                    <!-- Message dynamique -->
                </div>
                
                <!-- Boutons d'action -->
                <div style="display: flex; gap: 10px;">
                    <button onclick="sauvegarderInput('${typeCalcul}', '${nom}')" 
                            style="background: #3b82f6; color: white; border: none; padding: 12px 24px; border-radius: 6px; cursor: pointer; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                        💾 Sauvegarder
                    </button>
                    <button onclick="lancerCalculPreliminaire('${typeCalcul}', '${nom}', this.parentElement.parentElement.parentElement.parentElement)" 
                            style="background: #10b981; color: white; border: none; padding: 12px 24px; border-radius: 6px; cursor: pointer; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                        🚀 Lancer le calcul
                    </button>
                    <button onclick="this.parentElement.parentElement.parentElement.parentElement.remove()" 
                            style="background: #ef4444; color: white; border: none; padding: 12px 24px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                        ❌ Annuler
                    </button>
                </div>
            </div>
        </div>
    `;
    
    return modal;
}

/**
 * Sauvegarder un input sans le lancer
 */
async function sauvegarderInput(typeCalcul, nom) {
    const textarea = document.getElementById(`editor_input_${typeCalcul.toLowerCase()}`);
    const inputContent = textarea?.value;
    const statutDiv = document.getElementById(`statut_sauvegarde_${typeCalcul.toLowerCase()}`);
    
    if (!inputContent) {
        if (statutDiv) {
            statutDiv.textContent = '❌ Erreur: contenu vide';
            statutDiv.style.color = '#ef4444';
        }
        return;
    }
    
    // Afficher un message de chargement
    if (statutDiv) {
        statutDiv.textContent = '⏳ Sauvegarde en cours...';
        statutDiv.style.color = '#3b82f6';
    }
    
    try {
        // Générer le nom de fichier
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
        const filename = `${nom}_${typeCalcul.toLowerCase()}_${timestamp}.in`;
        
        // Créer un blob et télécharger le fichier
        const blob = new Blob([inputContent], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        // Message de succès
        if (statutDiv) {
            statutDiv.textContent = `✅ Sauvegardé: ${filename}`;
            statutDiv.style.color = '#10b981';
        }
        
        // Optionnel: Sauvegarder aussi sur le serveur si l'API est disponible
        try {
            const response = await fetch('http://localhost:5007/api/sauvegarder_input', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    filename: filename,
                    content: inputContent,
                    directory: '/home/hiadsi/Interface-QE_v1/inputs'
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                if (statutDiv) {
                    statutDiv.textContent = `✅ Sauvegardé localement et sur le serveur: ${filename}`;
                    statutDiv.style.color = '#10b981';
                }
            }
        } catch (apiError) {
            // L'API n'est pas disponible, mais le fichier a été téléchargé localement
            console.log('API non disponible, fichier téléchargé localement uniquement');
        }
        
        // Effacer le message après 5 secondes
        setTimeout(() => {
            if (statutDiv) {
                statutDiv.textContent = '';
            }
        }, 5000);
        
    } catch (error) {
        if (statutDiv) {
            statutDiv.textContent = `❌ Erreur: ${error.message}`;
            statutDiv.style.color = '#ef4444';
        }
    }
}

/**
 * Générer template VC-RELAX
 */
function genererTemplateVCRelax(nom) {
    return `&CONTROL
    calculation = 'vc-relax'
    prefix = '${nom}'
    outdir = './tmp/'
    pseudo_dir = '/home/hiadsi/Interface-QE_v1/pseudos/PBE/'
    etot_conv_thr = 1.0D-5
    forc_conv_thr = 1.0D-4
/

&SYSTEM
    ibrav = 0
    nat = 2
    ntyp = 1
    ecutwfc = 50.0
    ecutrho = 400.0
    occupations = 'smearing'
    smearing = 'gaussian'
    degauss = 0.02
/

&ELECTRONS
    conv_thr = 1.0D-8
    mixing_beta = 0.7
/

&IONS
    ion_dynamics = 'bfgs'
/

&CELL
    cell_dynamics = 'bfgs'
    press = 0.0
    press_conv_thr = 0.5
/

ATOMIC_SPECIES
 Ga  69.723  Ga.pbe-dn-kjpaw_psl.1.0.0.UPF

ATOMIC_POSITIONS crystal
 Ga  0.0000  0.0000  0.0000

K_POINTS automatic
 8 8 8  0 0 0

CELL_PARAMETERS angstrom
 4.0  0.0  0.0
 0.0  4.0  0.0
 0.0  0.0  4.0
`;
}

/**
 * Générer template RELAX
 */
function genererTemplateRelax(nom) {
    return `&CONTROL
    calculation = 'relax'
    prefix = '${nom}'
    outdir = './tmp/'
    pseudo_dir = '/home/hiadsi/Interface-QE_v1/pseudos/PBE/'
    etot_conv_thr = 1.0D-5
    forc_conv_thr = 1.0D-4
/

&SYSTEM
    ibrav = 0
    nat = 2
    ntyp = 1
    ecutwfc = 50.0
    ecutrho = 400.0
/

&ELECTRONS
    conv_thr = 1.0D-8
/

&IONS
    ion_dynamics = 'bfgs'
/

ATOMIC_SPECIES
 Ga  69.723  Ga.pbe-dn-kjpaw_psl.1.0.0.UPF

ATOMIC_POSITIONS crystal
 Ga  0.0000  0.0000  0.0000

K_POINTS automatic
 8 8 8  0 0 0

CELL_PARAMETERS angstrom
 4.0  0.0  0.0
 0.0  4.0  0.0
 0.0  0.0  4.0
`;
}

/**
 * Générer template SCF
 */
function genererTemplateSCF(nom) {
    return `&CONTROL
    calculation = 'scf'
    prefix = '${nom}'
    outdir = './tmp/'
    pseudo_dir = '/home/hiadsi/Interface-QE_v1/pseudos/PBE/'
/

&SYSTEM
    ibrav = 0
    nat = 2
    ntyp = 1
    ecutwfc = 50.0
    ecutrho = 400.0
/

&ELECTRONS
    conv_thr = 1.0D-10
    mixing_beta = 0.7
/

ATOMIC_SPECIES
 Ga  69.723  Ga.pbe-dn-kjpaw_psl.1.0.0.UPF

ATOMIC_POSITIONS crystal
 Ga  0.0000  0.0000  0.0000

K_POINTS automatic
 12 12 12  0 0 0

CELL_PARAMETERS angstrom
 4.0  0.0  0.0
 0.0  4.0  0.0
 0.0  0.0  4.0
`;
}

/**
 * Recommandations VC-RELAX
 */
function getRecommandationsVCRelax() {
    return `
        <h5 style="color: #f59e0b; margin: 0 0 10px 0;">🎯 Paramètres Critiques</h5>
        
        <div style="margin: 10px 0; padding: 10px; background: white; border-radius: 4px;">
            <strong>ecutwfc (énergie de coupure)</strong><br>
            • Métaux: 40-60 Ry<br>
            • Semi-conducteurs: 50-80 Ry<br>
            • Isolants: 60-100 Ry<br>
            <em>Plus élevé = plus précis mais plus lent</em>
        </div>
        
        <div style="margin: 10px 0; padding: 10px; background: white; border-radius: 4px;">
            <strong>K_POINTS (grille k)</strong><br>
            • Métaux: 12×12×12 ou plus<br>
            • Semi-conducteurs: 8×8×8<br>
            • Isolants: 6×6×6<br>
            <em>Ajuster selon la taille de la maille</em>
        </div>
        
        <div style="margin: 10px 0; padding: 10px; background: white; border-radius: 4px;">
            <strong>Convergence</strong><br>
            • etot_conv_thr = 1.0D-5 (énergie)<br>
            • forc_conv_thr = 1.0D-4 (forces)<br>
            • press_conv_thr = 0.5 (pression en kbar)<br>
        </div>
        
        <div style="margin: 10px 0; padding: 10px; background: white; border-radius: 4px;">
            <strong>⚠️ Points d'attention</strong><br>
            • Vérifier les pseudopotentiels<br>
            • ecutrho = 8-10 × ecutwfc<br>
            • Utiliser smearing pour métaux<br>
            • press = 0.0 pour pression atmosphérique<br>
        </div>
        
        <div style="margin: 10px 0; padding: 10px; background: #fef3c7; border-radius: 4px;">
            <strong>💡 Conseil</strong><br>
            VC-RELAX optimise TOUT: positions atomiques ET paramètres de maille.<br>
            Utilisez-le pour trouver la structure d'équilibre complète.
        </div>
    `;
}

/**
 * Recommandations RELAX
 */
function getRecommandationsRelax() {
    return `
        <h5 style="color: #f59e0b; margin: 0 0 10px 0;">🎯 Différence avec VC-RELAX</h5>
        
        <div style="margin: 10px 0; padding: 10px; background: #fef3c7; border-radius: 4px;">
            <strong>⚠️ RELAX vs VC-RELAX</strong><br>
            • RELAX: Optimise uniquement les positions atomiques<br>
            • VC-RELAX: Optimise positions + paramètres de maille<br>
            <br>
            <em>Utilisez RELAX si vous connaissez déjà les paramètres de maille exacts</em>
        </div>
        
        <div style="margin: 10px 0; padding: 10px; background: white; border-radius: 4px;">
            <strong>Quand utiliser RELAX?</strong><br>
            • Après un VC-RELAX pour affiner<br>
            • Quand les paramètres de maille sont expérimentaux<br>
            • Pour des calculs plus rapides<br>
        </div>
        
        <div style="margin: 10px 0; padding: 10px; background: white; border-radius: 4px;">
            <strong>Paramètres identiques à VC-RELAX</strong><br>
            • ecutwfc, K_POINTS, conv_thr<br>
            • Pas de section &CELL<br>
            • CELL_PARAMETERS fixes<br>
        </div>
        
        <div style="margin: 10px 0; padding: 10px; background: #dcfce7; border-radius: 4px;">
            <strong>💡 Conseil</strong><br>
            Si vous avez déjà fait un VC-RELAX, RELAX est optionnel.<br>
            Passez directement au SCF.
        </div>
    `;
}

/**
 * Recommandations SCF
 */
function getRecommandationsSCF() {
    return `
        <h5 style="color: #f59e0b; margin: 0 0 10px 0;">🎯 Paramètres pour Phonons</h5>
        
        <div style="margin: 10px 0; padding: 10px; background: #fef3c7; border-radius: 4px;">
            <strong>⚠️ IMPORTANT POUR PHONONS</strong><br>
            Le calcul SCF doit être TRÈS précis car les phonons<br>
            calculent des dérivées secondes de l'énergie.
        </div>
        
        <div style="margin: 10px 0; padding: 10px; background: white; border-radius: 4px;">
            <strong>Convergence stricte</strong><br>
            • conv_thr = 1.0D-10 (au lieu de 1.0D-8)<br>
            • Grille k DENSE: 12×12×12 minimum<br>
            • ecutwfc bien convergé<br>
        </div>
        
        <div style="margin: 10px 0; padding: 10px; background: white; border-radius: 4px;">
            <strong>Structure optimisée</strong><br>
            • Utiliser les positions du VC-RELAX/RELAX<br>
            • Copier ATOMIC_POSITIONS du output<br>
            • Copier CELL_PARAMETERS si VC-RELAX<br>
        </div>
        
        <div style="margin: 10px 0; padding: 10px; background: white; border-radius: 4px;">
            <strong>Grille k pour phonons</strong><br>
            • Doit être compatible avec la grille q des phonons<br>
            • Si grille q = 4×4×4, utiliser k = 12×12×12<br>
            • Règle: k ≥ 3 × q<br>
        </div>
        
        <div style="margin: 10px 0; padding: 10px; background: #dcfce7; border-radius: 4px;">
            <strong>✅ Vérifications</strong><br>
            • Le calcul doit créer un dossier .save<br>
            • Vérifier "JOB DONE" dans le output<br>
            • Énergie totale convergée<br>
        </div>
        
        <div style="margin: 10px 0; padding: 10px; background: #fef3c7; border-radius: 4px;">
            <strong>💡 Conseil</strong><br>
            Ce SCF est la base des calculs phonons.<br>
            Prenez le temps de bien le configurer!
        </div>
    `;
}

/**
 * Lancer un calcul préliminaire
 */
async function lancerCalculPreliminaire(typeCalcul, nom, modal) {
    const textarea = document.getElementById(`editor_input_${typeCalcul.toLowerCase()}`);
    const inputContent = textarea?.value;
    
    if (!inputContent) {
        alert('❌ Erreur: contenu de l\'input vide');
        return;
    }
    
    // Fermer la modal d'édition
    modal.remove();
    
    // Demander le mode de lancement
    const modalChoix = creerModalChoixLancement(typeCalcul, nom, inputContent);
    document.body.appendChild(modalChoix);
}

/**
 * Créer une modal pour choisir le mode de lancement
 */
function creerModalChoixLancement(typeCalcul, nom, inputContent) {
    const modal = document.createElement('div');
    modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); display: flex; align-items: center; justify-content: center; z-index: 10000;';
    
    modal.innerHTML = `
        <div style="background: white; padding: 30px; border-radius: 10px; max-width: 600px; width: 90%;">
            <h3 style="margin: 0 0 20px 0; color: #1e293b; text-align: center;">🚀 Mode de Lancement</h3>
            
            <p style="margin: 0 0 25px 0; color: #64748b; text-align: center;">
                Choisissez comment lancer le calcul ${typeCalcul}
            </p>
            
            <div style="display: grid; gap: 15px;">
                <!-- Option 1: Interface avec suivi -->
                <button onclick="lancerViaInterface('${typeCalcul}', '${nom}', this.parentElement.parentElement.parentElement)" 
                        style="padding: 20px; background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white; border: none; border-radius: 8px; cursor: pointer; text-align: left; transition: transform 0.2s;"
                        onmouseover="this.style.transform='scale(1.02)'" onmouseout="this.style.transform='scale(1)'">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <span style="font-size: 2.5em;">🖥️</span>
                        <div style="flex: 1;">
                            <div style="font-size: 1.1em; font-weight: 600; margin-bottom: 5px;">
                                Lancer via l'interface
                            </div>
                            <div style="font-size: 0.9em; opacity: 0.9;">
                                ✅ Suivi en temps réel dans une fenêtre<br>
                                ✅ Logs affichés automatiquement<br>
                                ✅ Notification à la fin du calcul
                            </div>
                        </div>
                    </div>
                </button>
                
                <!-- Option 2: Terminal manuel -->
                <button onclick="lancerViaTerminal('${typeCalcul}', '${nom}', this.parentElement.parentElement.parentElement)" 
                        style="padding: 20px; background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; border: none; border-radius: 8px; cursor: pointer; text-align: left; transition: transform 0.2s;"
                        onmouseover="this.style.transform='scale(1.02)'" onmouseout="this.style.transform='scale(1)'">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <span style="font-size: 2.5em;">⌨️</span>
                        <div style="flex: 1;">
                            <div style="font-size: 1.1em; font-weight: 600; margin-bottom: 5px;">
                                Lancer dans un terminal
                            </div>
                            <div style="font-size: 0.9em; opacity: 0.9;">
                                ✅ Contrôle total de l'exécution<br>
                                ✅ Possibilité de modifier la commande<br>
                                ✅ Exécution en arrière-plan possible
                            </div>
                        </div>
                    </div>
                </button>
            </div>
            
            <div style="margin-top: 20px; text-align: center;">
                <button onclick="this.parentElement.parentElement.parentElement.remove()" 
                        style="background: #ef4444; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                    ❌ Annuler
                </button>
            </div>
        </div>
    `;
    
    // Stocker l'input content dans une variable globale temporaire
    window.tempInputContent = inputContent;
    
    return modal;
}

/**
 * Lancer via l'interface avec suivi en temps réel
 */
async function lancerViaInterface(typeCalcul, nom, modal) {
    modal.remove();
    
    const inputContent = window.tempInputContent;
    if (!inputContent) {
        alert('❌ Erreur: contenu de l\'input perdu');
        return;
    }
    
    // Générer le nom de fichier
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
    const filename = `${nom}_${typeCalcul.toLowerCase()}_${timestamp}.in`;
    const outputFile = filename.replace('.in', '.out');
    const directory = '/home/hiadsi/Interface-QE_v1/outputs';
    
    // LANCEMENT NATIF DIRECT (sans API)
    // Télécharger le fichier input localement
    const blob = new Blob([inputContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    // Générer la commande native
    const commande = `cd ${directory} && mpirun -np 4 pw.x < ${filename} > ${outputFile} 2>&1`;
    
    // Ouvrir la fenêtre de suivi natif
    ouvrirFenetreSuiviNatif(typeCalcul, nom, filename, outputFile, commande, directory);
}

/**
 * Ouvrir une fenêtre de suivi natif (sans API)
 */
function ouvrirFenetreSuiviNatif(typeCalcul, nom, inputFile, outputFile, commande, directory) {
    const modalSuivi = document.createElement('div');
    modalSuivi.id = `modal_suivi_natif_${typeCalcul.toLowerCase()}`;
    modalSuivi.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.95); display: flex; align-items: center; justify-content: center; z-index: 10000;';
    
    modalSuivi.innerHTML = `
        <div style="background: #1e293b; padding: 20px; border-radius: 10px; max-width: 1000px; width: 95%; max-height: 90vh; display: flex; flex-direction: column;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <h3 style="margin: 0; color: #f1f5f9;">
                    🔧 Calcul ${typeCalcul} - Mode Natif - ${nom}
                </h3>
                <button onclick="fermerFenetreSuiviNatif('${typeCalcul.toLowerCase()}')" 
                        style="background: #ef4444; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                    ✕ Fermer
                </button>
            </div>
            
            <!-- Instructions -->
            <div style="background: #0f172a; padding: 15px; border-radius: 6px; margin-bottom: 15px; color: #e2e8f0; font-size: 0.9em;">
                <h4 style="margin: 0 0 10px 0; color: #3b82f6;">📋 Instructions:</h4>
                <ol style="margin: 5px 0; padding-left: 20px;">
                    <li>Le fichier <strong>${inputFile}</strong> a été téléchargé</li>
                    <li>Placez-le dans le répertoire: <code style="background: #1e293b; padding: 2px 6px; border-radius: 3px;">${directory}</code></li>
                    <li>Ouvrez un terminal et exécutez la commande ci-dessous</li>
                    <li>Une fois le calcul terminé, cliquez sur "✅ Marquer comme terminé"</li>
                </ol>
            </div>
            
            <!-- Commande -->
            <div style="background: #0f172a; padding: 15px; border-radius: 6px; margin-bottom: 15px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                    <h4 style="margin: 0; color: #3b82f6;">💻 Commande à exécuter:</h4>
                    <button onclick="copierCommandeNative('${commande.replace(/'/g, "\\'")}', '${typeCalcul.toLowerCase()}')" 
                            style="background: #3b82f6; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-size: 0.9em;">
                        📋 Copier
                    </button>
                </div>
                <div style="background: #1e293b; padding: 12px; border-radius: 4px; font-family: monospace; font-size: 0.85em; color: #10b981; overflow-x: auto; white-space: pre-wrap; word-break: break-all;">
${commande}
                </div>
                <div id="statut_copie_${typeCalcul.toLowerCase()}" style="margin-top: 8px; color: #10b981; font-size: 0.85em; font-style: italic; min-height: 20px;">
                    <!-- Message de copie -->
                </div>
            </div>
            
            <!-- Fichiers -->
            <div style="background: #0f172a; padding: 15px; border-radius: 6px; margin-bottom: 15px; font-size: 0.9em;">
                <h4 style="margin: 0 0 10px 0; color: #3b82f6;">📁 Fichiers:</h4>
                <div style="color: #e2e8f0;">
                    <div>📥 Input: <code style="background: #1e293b; padding: 2px 6px; border-radius: 3px;">${inputFile}</code></div>
                    <div style="margin-top: 5px;">📤 Output: <code style="background: #1e293b; padding: 2px 6px; border-radius: 3px;">${outputFile}</code></div>
                    <div style="margin-top: 5px;">📂 Répertoire: <code style="background: #1e293b; padding: 2px 6px; border-radius: 3px;">${directory}</code></div>
                </div>
            </div>
            
            <!-- Statut -->
            <div style="background: #0f172a; padding: 15px; border-radius: 6px; margin-bottom: 15px;">
                <h4 style="margin: 0 0 10px 0; color: #3b82f6;">📊 Statut:</h4>
                <div id="statut_calcul_natif_${typeCalcul.toLowerCase()}" style="color: #fbbf24; font-weight: 600;">
                    ⏳ En attente d'exécution manuelle...
                </div>
            </div>
            
            <!-- Boutons d'action -->
            <div style="display: flex; gap: 10px; justify-content: center;">
                <button onclick="marquerCalculTermine('${typeCalcul}', '${nom}')" 
                        style="background: #10b981; color: white; border: none; padding: 12px 24px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 1em;">
                    ✅ Marquer comme terminé
                </button>
                <button onclick="relancerCalculNatif('${typeCalcul}', '${nom}')" 
                        style="background: #f59e0b; color: white; border: none; padding: 12px 24px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 1em;">
                    🔄 Relancer
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modalSuivi);
}

/**
 * Copier la commande native dans le presse-papier
 */
async function copierCommandeNative(commande, typeCalcul) {
    const statutDiv = document.getElementById(`statut_copie_${typeCalcul}`);
    
    try {
        await navigator.clipboard.writeText(commande);
        if (statutDiv) {
            statutDiv.textContent = '✅ Commande copiée dans le presse-papier!';
            statutDiv.style.color = '#10b981';
        }
        
        // Effacer le message après 3 secondes
        setTimeout(() => {
            if (statutDiv) {
                statutDiv.textContent = '';
            }
        }, 3000);
        
    } catch (error) {
        if (statutDiv) {
            statutDiv.textContent = '❌ Erreur de copie. Copiez manuellement la commande.';
            statutDiv.style.color = '#ef4444';
        }
    }
}

/**
 * Fermer la fenêtre de suivi natif
 */
function fermerFenetreSuiviNatif(typeCalcul) {
    const modal = document.getElementById(`modal_suivi_natif_${typeCalcul}`);
    if (modal) {
        modal.remove();
    }
}

/**
 * Marquer un calcul comme terminé
 */
function marquerCalculTermine(typeCalcul, nom) {
    const statutDiv = document.getElementById(`statut_calcul_natif_${typeCalcul.toLowerCase()}`);
    
    if (statutDiv) {
        statutDiv.textContent = '✅ Calcul marqué comme terminé!';
        statutDiv.style.color = '#10b981';
    }
    
    // Mettre à jour le statut dans la page principale
    const statutPageId = `statut_${typeCalcul.toLowerCase()}_page`;
    const statutPage = document.getElementById(statutPageId);
    if (statutPage) {
        statutPage.textContent = '✅ Terminé';
        statutPage.style.color = '#10b981';
    }
    
    // Vérifier si tous les calculs sont terminés
    verifierCalculsPreliminairesTermines();
    
    // Fermer la fenêtre après 2 secondes
    setTimeout(() => {
        fermerFenetreSuiviNatif(typeCalcul.toLowerCase());
    }, 2000);
}

/**
 * Relancer un calcul natif
 */
function relancerCalculNatif(typeCalcul, nom) {
    fermerFenetreSuiviNatif(typeCalcul.toLowerCase());
    
    // Réouvrir l'éditeur
    if (typeCalcul === 'VC-RELAX') {
        editerInputVCRelax(nom);
    } else if (typeCalcul === 'RELAX') {
        editerInputRelax(nom);
    } else if (typeCalcul === 'SCF') {
        editerInputSCF(nom);
    }
}

/**
 * Vérifier si tous les calculs préliminaires sont terminés
 */
function verifierCalculsPreliminairesTermines() {
    const statutVCRelax = document.getElementById('statut_vcrelax_page')?.textContent;
    const statutSCF = document.getElementById('statut_scf_page')?.textContent;
    
    // VC-RELAX et SCF sont obligatoires
    if (statutVCRelax?.includes('✅') && statutSCF?.includes('✅')) {
        const blocVerif = document.getElementById('bloc_verification_finale');
        if (blocVerif) {
            blocVerif.style.display = 'block';
        }
    }
}

/**
 * Ouvrir une fenêtre de suivi en temps réel (avec API - conservé pour compatibilité)
 */
function ouvrirFenetreSuivi(typeCalcul, nom, calculId, outputFile) {
=======
    const modalSuivi = document.createElement('div');
    modalSuivi.id = `modal_suivi_${typeCalcul.toLowerCase()}`;
    modalSuivi.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.95); display: flex; align-items: center; justify-content: center; z-index: 10000;';
    
    modalSuivi.innerHTML = `
        <div style="background: #1e293b; padding: 20px; border-radius: 10px; max-width: 1000px; width: 95%; max-height: 90vh; display: flex; flex-direction: column;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <h3 style="margin: 0; color: #f1f5f9;">
                    🔄 Calcul ${typeCalcul} en cours - ${nom}
                </h3>
                <button onclick="fermerFenetreSuivi('${typeCalcul.toLowerCase()}')" 
                        style="background: #ef4444; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                    ✕ Fermer
                </button>
            </div>
            
            <div style="background: #0f172a; padding: 15px; border-radius: 6px; flex: 1; overflow-y: auto; font-family: monospace; font-size: 0.9em; color: #e2e8f0; min-height: 400px; max-height: 600px;" id="console_suivi_${typeCalcul.toLowerCase()}">
                <div style="color: #3b82f6;">[${new Date().toLocaleTimeString()}] 🚀 Lancement du calcul ${typeCalcul}...</div>
                <div style="color: #3b82f6;">[${new Date().toLocaleTimeString()}] 📁 Fichier: ${outputFile}</div>
                <div style="color: #3b82f6;">[${new Date().toLocaleTimeString()}] 🔄 En attente des premiers logs...</div>
            </div>
            
            <div style="margin-top: 15px; padding: 12px; background: #334155; border-radius: 6px; display: flex; align-items: center; gap: 10px;">
                <div style="flex: 1;">
                    <div style="color: #94a3b8; font-size: 0.85em; margin-bottom: 5px;">Progression</div>
                    <div style="background: #1e293b; height: 8px; border-radius: 4px; overflow: hidden;">
                        <div id="progress_bar_${typeCalcul.toLowerCase()}" style="background: linear-gradient(90deg, #3b82f6, #10b981); height: 100%; width: 0%; transition: width 0.5s;"></div>
                    </div>
                </div>
                <div id="statut_calcul_${typeCalcul.toLowerCase()}" style="color: #fbbf24; font-weight: 600;">
                    ⏳ En cours...
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modalSuivi);
    
    // Démarrer le suivi en temps réel
    demarrerSuiviTempsReel(typeCalcul, calculId, outputFile);
}

/**
 * Démarrer le suivi en temps réel d'un calcul
 */
async function demarrerSuiviTempsReel(typeCalcul, calculId, outputFile) {
    const consoleElem = document.getElementById(`console_suivi_${typeCalcul.toLowerCase()}`);
    const progressBar = document.getElementById(`progress_bar_${typeCalcul.toLowerCase()}`);
    const statutElem = document.getElementById(`statut_calcul_${typeCalcul.toLowerCase()}`);
    
    let dernieresLignes = '';
    let progression = 0;
    
    const interval = setInterval(async () => {
        try {
            // Récupérer l'état du calcul
            const response = await fetch(`http://localhost:5007/api/etat_calcul/${calculId}`);
            const data = await response.json();
            
            if (!data.success) {
                throw new Error('Impossible de récupérer l\'état du calcul');
            }
            
            // Afficher les nouveaux logs
            if (data.logs && data.logs !== dernieresLignes) {
                const lignes = data.logs.split('\n');
                const nouvelles = lignes.slice(-20); // Dernières 20 lignes
                
                nouvelles.forEach(ligne => {
                    if (ligne.trim()) {
                        const div = document.createElement('div');
                        div.style.color = ligne.includes('error') || ligne.includes('Error') ? '#ef4444' : 
                                         ligne.includes('warning') || ligne.includes('Warning') ? '#fbbf24' :
                                         ligne.includes('convergence') || ligne.includes('CONVERGENCE') ? '#10b981' :
                                         '#e2e8f0';
                        div.textContent = `[${new Date().toLocaleTimeString()}] ${ligne}`;
                        consoleElem.appendChild(div);
                    }
                });
                
                consoleElem.scrollTop = consoleElem.scrollHeight;
                dernieresLignes = data.logs;
            }
            
            // Mettre à jour la progression
            if (data.progression !== undefined) {
                progression = data.progression;
                if (progressBar) progressBar.style.width = `${progression}%`;
            } else {
                // Estimation basique
                progression = Math.min(progression + 2, 95);
                if (progressBar) progressBar.style.width = `${progression}%`;
            }
            
            // Vérifier si terminé
            if (data.statut === 'termine' || data.logs?.includes('JOB DONE')) {
                clearInterval(interval);
                
                if (progressBar) progressBar.style.width = '100%';
                if (statutElem) {
                    statutElem.textContent = '✅ Terminé!';
                    statutElem.style.color = '#10b981';
                }
                
                const div = document.createElement('div');
                div.style.color = '#10b981';
                div.style.fontWeight = 'bold';
                div.style.marginTop = '10px';
                div.textContent = `[${new Date().toLocaleTimeString()}] ✅ CALCUL TERMINÉ AVEC SUCCÈS!`;
                consoleElem.appendChild(div);
                consoleElem.scrollTop = consoleElem.scrollHeight;
                
                // Marquer comme terminé
                const statutSpan = document.getElementById(`statut_${typeCalcul.toLowerCase()}`);
                if (statutSpan) {
                    statutSpan.textContent = '✅ Terminé';
                    statutSpan.style.color = '#10b981';
                }
                
                // Vérifier si tous les calculs sont terminés
                setTimeout(() => {
                    verifierCalculsPreliminairesTermines();
                }, 1000);
                
                // Notification
                alert(`✅ Calcul ${typeCalcul} terminé!\n\nVous pouvez fermer la fenêtre de suivi.`);
                
            } else if (data.statut === 'erreur' || data.logs?.includes('error') || data.logs?.includes('Error')) {
                clearInterval(interval);
                
                if (statutElem) {
                    statutElem.textContent = '❌ Erreur';
                    statutElem.style.color = '#ef4444';
                }
                
                const div = document.createElement('div');
                div.style.color = '#ef4444';
                div.style.fontWeight = 'bold';
                div.style.marginTop = '10px';
                div.textContent = `[${new Date().toLocaleTimeString()}] ❌ ERREUR DÉTECTÉE - Vérifiez les logs`;
                consoleElem.appendChild(div);
                consoleElem.scrollTop = consoleElem.scrollHeight;
                
                alert(`❌ Erreur détectée dans le calcul ${typeCalcul}!\n\nConsultez les logs dans la fenêtre de suivi.`);
            }
            
        } catch (error) {
            console.error('Erreur suivi:', error);
            const div = document.createElement('div');
            div.style.color = '#ef4444';
            div.textContent = `[${new Date().toLocaleTimeString()}] ⚠️ Erreur de suivi: ${error.message}`;
            consoleElem?.appendChild(div);
            if (consoleElem) consoleElem.scrollTop = consoleElem.scrollHeight;
        }
    }, 2000); // Mise à jour toutes les 2 secondes
    
    // Stocker l'interval pour pouvoir l'arrêter
    window[`interval_suivi_${typeCalcul.toLowerCase()}`] = interval;
}

/**
 * Fermer la fenêtre de suivi
 */
function fermerFenetreSuivi(typeCalcul) {
    const modal = document.getElementById(`modal_suivi_${typeCalcul}`);
    if (modal) modal.remove();
    
    // Arrêter l'interval de suivi
    const interval = window[`interval_suivi_${typeCalcul}`];
    if (interval) clearInterval(interval);
}

/**
 * Lancer via terminal (mode manuel)
 */
async function lancerViaTerminal(typeCalcul, nom, modal) {
    modal.remove();
    
    const inputContent = window.tempInputContent;
    if (!inputContent) {
        alert('❌ Erreur: contenu de l\'input perdu');
        return;
    }
    
    // Générer le nom de fichier
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
    const filename = `${nom}_${typeCalcul.toLowerCase()}_${timestamp}.in`;
    const outputFile = filename.replace('.in', '.out');
    const commande = `cd /home/hiadsi/Interface-QE_v1/outputs && /home/hiadsi/q-e-qe-7.5/bin/pw.x < ${filename} > ${outputFile} 2>&1`;
    
    // Télécharger l'input
    const blob = new Blob([inputContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    
    // Afficher la commande
    const copier = confirm(
        `🔧 LANCEMENT MANUEL DANS UN TERMINAL\n\n` +
        `Fichier input téléchargé: ${filename}\n\n` +
        `Commande à exécuter:\n\n` +
        `${commande}\n\n` +
        `Voulez-vous copier cette commande dans le presse-papier?`
    );
    
    if (copier) {
        await navigator.clipboard.writeText(commande);
        alert(
            `✅ Commande copiée!\n\n` +
            `1. Placez le fichier ${filename} dans /home/hiadsi/Interface-QE_v1/outputs\n` +
            `2. Ouvrez un terminal\n` +
            `3. Collez et exécutez la commande\n` +
            `4. Attendez la fin du calcul\n` +
            `5. Revenez ici et cliquez OK`
        );
    }
    
    // Attendre confirmation
    const termine = confirm(
        `⏳ Le calcul ${typeCalcul} est-il terminé?\n\n` +
        `Vérifiez que le fichier ${outputFile} contient "JOB DONE"\n\n` +
        `Cliquez OK une fois le calcul terminé.`
    );
    
    if (termine) {
        // Marquer comme terminé
        const statutSpan = document.getElementById(`statut_${typeCalcul.toLowerCase()}`);
        if (statutSpan) {
            statutSpan.textContent = '✅ Terminé';
            statutSpan.style.color = '#10b981';
        }
        
        // Vérifier si tous les calculs sont terminés
        verifierCalculsPreliminairesTermines();
    }
}

/**
 * Vérifier si tous les calculs préliminaires sont terminés
 */
function verifierCalculsPreliminairesTermines() {
    const statutVcrelax = document.getElementById('statut_vcrelax')?.textContent;
    const statutScf = document.getElementById('statut_scf')?.textContent;
    
    // VC-RELAX et SCF sont obligatoires
    if (statutVcrelax?.includes('✅') && statutScf?.includes('✅')) {
        const blocVerif = document.getElementById('bloc_verification_finale');
        if (blocVerif) {
            blocVerif.style.display = 'block';
            blocVerif.scrollIntoView({ behavior: 'smooth' });
        }
    }
}

/**
 * Passer aux calculs phonons
 */
function passerAuxCalculsPhonons() {
    alert('✅ Calculs préliminaires terminés!\n\nVous pouvez maintenant configurer et lancer les calculs PHONONS dans l\'ÉTAPE 2.');
    
    // Scroller vers la zone des calculs SCF (ÉTAPE 2)
    const zoneScf = document.getElementById('zone_scf_phonons');
    if (zoneScf) {
        zoneScf.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

/**
 * Vérifier et afficher les prérequis pour phonons
 */
async function verifierEtAfficherPrerequisPhonons() {
    if (!materiauPhononsCharge) return;
    
    const zoneVerif = document.getElementById('zone_verification_prerequis');
    if (!zoneVerif) return;
    
    zoneVerif.innerHTML = `
        <div style="padding: 12px; background: #fef3c7; border: 2px solid #f59e0b; border-radius: 6px;">
            <div style="color: #92400e; font-weight: 600; margin-bottom: 8px;">
                🔍 Vérification des prérequis en cours...
            </div>
        </div>
    `;
    zoneVerif.style.display = 'block';
    
    try {
        // Chercher les calculs existants pour ce matériau
        const response = await fetch('http://localhost:5007/api/lister_outputs');
        const data = await response.json();
        
        let relaxTrouve = false;
        let scfTrouve = false;
        let saveTrouve = false;
        let cheminRelax = null;
        let cheminScf = null;
        
        if (data.success && data.outputs) {
            // Chercher relax/vc-relax
            const calculsRelax = data.outputs.filter(c => 
                (c.type === 'relax' || c.type === 'vc-relax') && 
                c.prefix && c.prefix.toLowerCase().includes(materiauPhononsCharge.nom.toLowerCase())
            );
            
            if (calculsRelax.length > 0) {
                relaxTrouve = true;
                cheminRelax = calculsRelax[0].output_dir;
            }
            
            // Chercher SCF
            const calculsSCF = data.outputs.filter(c => 
                c.type === 'scf' && 
                c.prefix && c.prefix.toLowerCase().includes(materiauPhononsCharge.nom.toLowerCase())
            );
            
            if (calculsSCF.length > 0) {
                scfTrouve = true;
                cheminScf = calculsSCF[0].output_dir;
                
                // Vérifier le dossier .save
                try {
                    const verifSave = await fetch(`http://localhost:5007/api/verifier_save?path=${encodeURIComponent(cheminScf)}`);
                    const dataSave = await verifSave.json();
                    saveTrouve = dataSave.existe || false;
                } catch (e) {
                    console.warn('Vérification .save échouée:', e);
                }
            }
        }
        
        // Afficher le résultat
        let html = '<div style="padding: 12px; background: white; border: 2px solid #e2e8f0; border-radius: 6px;">';
        html += '<h5 style="margin: 0 0 10px 0; color: #1e293b;">📋 État des Prérequis</h5>';
        
        // Relax/VC-Relax
        html += `
            <div style="display: flex; align-items: center; gap: 8px; padding: 8px; margin: 5px 0; background: ${relaxTrouve ? '#dcfce7' : '#fee2e2'}; border-radius: 4px;">
                <span style="font-size: 1.2em;">${relaxTrouve ? '✅' : '❌'}</span>
                <div style="flex: 1;">
                    <div style="font-weight: 600; color: ${relaxTrouve ? '#065f46' : '#991b1b'};">
                        Calcul RELAX/VC-RELAX
                    </div>
                    ${relaxTrouve ? `<div style="font-size: 0.85em; color: #047857;">Trouvé: ${cheminRelax}</div>` : 
                                    '<div style="font-size: 0.85em; color: #7f1d1d;">Requis pour optimiser la structure</div>'}
                </div>
            </div>
        `;
        
        // SCF
        html += `
            <div style="display: flex; align-items: center; gap: 8px; padding: 8px; margin: 5px 0; background: ${scfTrouve ? '#dcfce7' : '#fee2e2'}; border-radius: 4px;">
                <span style="font-size: 1.2em;">${scfTrouve ? '✅' : '❌'}</span>
                <div style="flex: 1;">
                    <div style="font-weight: 600; color: ${scfTrouve ? '#065f46' : '#991b1b'};">
                        Calcul SCF
                    </div>
                    ${scfTrouve ? `<div style="font-size: 0.85em; color: #047857;">Trouvé: ${cheminScf}</div>` : 
                                  '<div style="font-size: 0.85em; color: #7f1d1d;">Requis pour les calculs phonons</div>'}
                </div>
            </div>
        `;
        
        // Dossier .save
        html += `
            <div style="display: flex; align-items: center; gap: 8px; padding: 8px; margin: 5px 0; background: ${saveTrouve ? '#dcfce7' : '#fee2e2'}; border-radius: 4px;">
                <span style="font-size: 1.2em;">${saveTrouve ? '✅' : '❌'}</span>
                <div style="flex: 1;">
                    <div style="font-weight: 600; color: ${saveTrouve ? '#065f46' : '#991b1b'};">
                        Dossier .save
                    </div>
                    ${saveTrouve ? '<div style="font-size: 0.85em; color: #047857;">Données de densité disponibles</div>' : 
                                   '<div style="font-size: 0.85em; color: #7f1d1d;">Généré par le calcul SCF</div>'}
                </div>
            </div>
        `;
        
        // Bouton d'action
        const tousPresents = relaxTrouve && scfTrouve && saveTrouve;
        
        if (tousPresents) {
            html += `
                <div style="margin-top: 12px; padding: 10px; background: #dcfce7; border-radius: 6px; text-align: center;">
                    <div style="color: #065f46; font-weight: 600; margin-bottom: 8px;">
                        ✅ Tous les prérequis sont satisfaits!
                    </div>
                    <button onclick="continuerVersWorkflowPhonons('${cheminScf}')" 
                            style="background: #10b981; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                        ▶️ Continuer vers le workflow phonons
                    </button>
                </div>
            `;
            prerequisPhononsValides = true;
        } else {
            html += `
                <div style="margin-top: 12px; padding: 10px; background: #fef3c7; border-radius: 6px; text-align: center;">
                    <div style="color: #92400e; font-weight: 600; margin-bottom: 8px;">
                        ⚠️ Prérequis manquants
                    </div>
                    <button onclick="lancerCalculsPrerequisAutomatique()" 
                            style="background: #f59e0b; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                        🚀 Lancer les calculs manquants
                    </button>
                </div>
            `;
            prerequisPhononsValides = false;
        }
        
        html += '</div>';
        zoneVerif.innerHTML = html;
        
    } catch (error) {
        zoneVerif.innerHTML = `
            <div style="padding: 12px; background: #fee2e2; border: 2px solid #ef4444; border-radius: 6px;">
                <div style="color: #991b1b; font-weight: 600;">
                    ❌ Erreur lors de la vérification: ${error.message}
                </div>
            </div>
        `;
    }
}

/**
 * Continuer vers le workflow phonons
 */
function continuerVersWorkflowPhonons(cheminScf) {
    // Sélectionner automatiquement le calcul SCF
    const nom = materiauPhononsCharge.nom;
    selectionnerSCFPourPhonons(cheminScf, nom);
    
    // Scroller vers la zone de configuration
    const zoneConfig = document.getElementById('zone_scf_phonons');
    if (zoneConfig) {
        zoneConfig.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    
    alert('✅ Prérequis validés!\n\nVous pouvez maintenant configurer et lancer le workflow phonons.');
}

/**
 * Lancer les calculs prérequis automatiquement
 */
async function lancerCalculsPrerequisAutomatique() {
    if (!materiauPhononsCharge) {
        alert('⚠️ Aucun matériau chargé');
        return;
    }
    
    const confirmation = confirm(
        '🚀 LANCEMENT DES CALCULS PRÉREQUIS\n\n' +
        'Les calculs suivants seront lancés dans l\'ordre:\n' +
        '1. RELAX ou VC-RELAX (optimisation de la structure)\n' +
        '2. SCF (calcul self-consistent)\n\n' +
        'Cela peut prendre plusieurs minutes à plusieurs heures.\n\n' +
        'Continuer?'
    );
    
    if (!confirmation) return;
    
    const zoneVerif = document.getElementById('zone_verification_prerequis');
    if (zoneVerif) {
        zoneVerif.innerHTML = `
            <div style="padding: 15px; background: #dbeafe; border: 2px solid #3b82f6; border-radius: 6px;">
                <div style="color: #1e40af; font-weight: 600; margin-bottom: 10px;">
                    🔄 Lancement des calculs prérequis en cours...
                </div>
                <div id="log_prerequis_phonons" style="font-family: monospace; font-size: 0.85em; color: #1e40af; max-height: 200px; overflow-y: auto;"></div>
            </div>
        `;
    }
    
    try {
        // TODO: Implémenter le lancement réel des calculs via l'API
        // Pour l'instant, simulation
        await ajouterLogPrerequisPhonons('📝 Préparation des inputs...');
        await new Promise(r => setTimeout(r, 1000));
        
        await ajouterLogPrerequisPhonons('🔄 Lancement RELAX...');
        await new Promise(r => setTimeout(r, 2000));
        
        await ajouterLogPrerequisPhonons('✅ RELAX terminé');
        await new Promise(r => setTimeout(r, 1000));
        
        await ajouterLogPrerequisPhonons('🔄 Lancement SCF...');
        await new Promise(r => setTimeout(r, 2000));
        
        await ajouterLogPrerequisPhonons('✅ SCF terminé');
        await ajouterLogPrerequisPhonons('✅ Dossier .save créé');
        
        alert('✅ Calculs prérequis terminés!\n\nVous pouvez maintenant lancer le workflow phonons.');
        
        // Revérifier les prérequis
        await verifierEtAfficherPrerequisPhonons();
        
    } catch (error) {
        alert(`❌ Erreur:\n\n${error.message}`);
    }
}

/**
 * Ajouter un log dans la zone prérequis
 */
async function ajouterLogPrerequisPhonons(message) {
    const logDiv = document.getElementById('log_prerequis_phonons');
    if (logDiv) {
        const ligne = document.createElement('div');
        ligne.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
        logDiv.appendChild(ligne);
        logDiv.scrollTop = logDiv.scrollHeight;
    }
}

/**
 * Vérifier les prérequis phonons (appelé avant lancement)
 */
async function verifierPrerequisPhonons(calcul) {
    try {
        // Vérifier que le calcul a un dossier .save
        const response = await fetch(`http://localhost:5007/api/verifier_save?path=${encodeURIComponent(calcul.path)}`);
        const data = await response.json();
        
        if (!data.existe) {
            return {
                ok: false,
                message: 'Le dossier .save est manquant.\nIl est généré par un calcul SCF réussi.',
                manquants: ['save']
            };
        }
        
        // Vérifier qu'il y a eu un relax avant
        const responseOutputs = await fetch('http://localhost:5007/api/lister_outputs');
        const dataOutputs = await responseOutputs.json();
        
        const relaxTrouve = dataOutputs.outputs?.some(c => 
            (c.type === 'relax' || c.type === 'vc-relax') && 
            c.prefix === calcul.nom
        );
        
        if (!relaxTrouve) {
            return {
                ok: false,
                message: 'Aucun calcul RELAX/VC-RELAX trouvé pour ce matériau.\nIl est recommandé d\'optimiser la structure avant les phonons.',
                manquants: ['relax']
            };
        }
        
        return { ok: true };
        
    } catch (error) {
        return {
            ok: false,
            message: `Erreur lors de la vérification: ${error.message}`,
            manquants: ['verification']
        };
    }
}

/**
 * Lancer les calculs prérequis manquants
 */
async function lancerCalculsPrerequisPhonons(manquants) {
    // TODO: Implémenter le lancement réel
    return {
        success: true
    };
}









// ═══════════════════════════════════════════════════════════════════════════
// WORKFLOW COMPLET PHONONS - Fonctions d'interface
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Ouvrir le workflow complet phonons
 */
function ouvrirWorkflowCompletPhonons() {
    const zone = document.getElementById('zone_workflow_complet_phonons');
    if (zone) {
        zone.style.display = 'block';
        // Scroll vers la zone
        zone.scrollIntoView({ behavior: 'smooth', block: 'start' });
        console.log('✅ Workflow complet phonons ouvert');
    }
}

/**
 * Fermer le workflow complet
 */
function fermerWorkflowComplet() {
    const zone = document.getElementById('zone_workflow_complet_phonons');
    if (zone) {
        zone.style.display = 'none';
        console.log('❌ Workflow complet phonons fermé');
    }
}

/**
 * Éditer et lancer un calcul
 */
function editerEtLancerCalcul(type) {
    console.log(`📝 Édition et lancement du calcul: ${type}`);
    
    // Mettre à jour le statut
    const statusDiv = document.getElementById(`status_${type}`);
    if (statusDiv) {
        statusDiv.innerHTML = '🔄 Préparation de l\'input...';
        statusDiv.style.background = '#dbeafe';
        statusDiv.style.borderLeft = '4px solid #3b82f6';
    }
    
    // Générer un template d'input selon le type
    let template = '';
    const materiau = materiauWorkflow || 'GaN'; // Utiliser le matériau choisi ou GaN par défaut
    
    switch(type) {
        case 'vcrelax':
            template = `&CONTROL
    calculation = 'vc-relax'
    prefix = '${materiau}'
    outdir = './tmp/'
    pseudo_dir = '/home/hiadsi/Interface-QE_v1/pseudos/PBE/'
    etot_conv_thr = 1.0D-5
    forc_conv_thr = 1.0D-4
/

&SYSTEM
    ibrav = 4
    celldm(1) = 6.028
    celldm(3) = 1.626
    nat = 2
    ntyp = 2
    ecutwfc = 50.0
    ecutrho = 400.0
/

&ELECTRONS
    conv_thr = 1.0D-8
    mixing_beta = 0.3
    diagonalization = 'cg'
/

&IONS
    ion_dynamics = 'bfgs'
/

&CELL
    cell_dynamics = 'bfgs'
    press = 0.0
    press_conv_thr = 0.5
/

ATOMIC_SPECIES
 Ga  69.723  Ga.pbe-dn-kjpaw_psl.1.0.0.UPF
 N   14.007  N.pbe-n-kjpaw_psl.1.0.0.UPF

ATOMIC_POSITIONS crystal
 Ga  0.333  0.667  0.000
 N   0.333  0.667  0.377

K_POINTS automatic
 8 8 8  0 0 0`;
            break;
            
        case 'relax':
            template = `&CONTROL
    calculation = 'relax'
    prefix = '${materiau}'
    outdir = './tmp/'
    pseudo_dir = '/home/hiadsi/Interface-QE_v1/pseudos/PBE/'
    etot_conv_thr = 1.0D-5
    forc_conv_thr = 1.0D-4
/

&SYSTEM
    ibrav = 4
    celldm(1) = 6.028
    celldm(3) = 1.626
    nat = 2
    ntyp = 2
    ecutwfc = 50.0
    ecutrho = 400.0
/

&ELECTRONS
    conv_thr = 1.0D-8
    mixing_beta = 0.3
    diagonalization = 'cg'
/

&IONS
    ion_dynamics = 'bfgs'
/

ATOMIC_SPECIES
 Ga  69.723  Ga.pbe-dn-kjpaw_psl.1.0.0.UPF
 N   14.007  N.pbe-n-kjpaw_psl.1.0.0.UPF

ATOMIC_POSITIONS crystal
 Ga  0.333  0.667  0.000
 N   0.333  0.667  0.377

K_POINTS automatic
 8 8 8  0 0 0`;
            break;
            
        case 'scf':
            template = `&CONTROL
    calculation = 'scf'
    prefix = '${materiau}'
    outdir = './tmp/'
    pseudo_dir = '/home/hiadsi/Interface-QE_v1/pseudos/PBE/'
/

&SYSTEM
    ibrav = 4
    celldm(1) = 6.028
    celldm(3) = 1.626
    nat = 2
    ntyp = 2
    ecutwfc = 50.0
    ecutrho = 400.0
/

&ELECTRONS
    conv_thr = 1.0D-10
    mixing_beta = 0.7
    diagonalization = 'cg'
/

ATOMIC_SPECIES
 Ga  69.723  Ga.pbe-dn-kjpaw_psl.1.0.0.UPF
 N   14.007  N.pbe-n-kjpaw_psl.1.0.0.UPF

ATOMIC_POSITIONS crystal
 Ga  0.333  0.667  0.000
 N   0.333  0.667  0.377

K_POINTS automatic
 12 12 12  0 0 0`;
            break;
    }
    
    // Télécharger le fichier input
    const blob = new Blob([template], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${materiau}_${type}.in`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    // Mettre à jour le statut
    if (statusDiv) {
        statusDiv.innerHTML = `✅ Input téléchargé: ${materiau}_${type}.in<br>
            <small style="color: #6b7280;">Lancez le calcul avec: <code style="background: #1f2937; color: #10b981; padding: 2px 6px; border-radius: 3px;">mpirun -np 4 pw.x < ${materiau}_${type}.in > ${materiau}_${type}.out</code></small>`;
        statusDiv.style.background = '#d1fae5';
        statusDiv.style.borderLeft = '4px solid #10b981';
    }
    
    console.log(`✅ Input ${type} téléchargé`);
}

/**
 * Sauter une étape optionnelle
 */
function sauterEtape(type) {
    console.log(`⏭️ Étape ${type} sautée`);
    
    const statusDiv = document.getElementById(`status_${type}`);
    if (statusDiv) {
        statusDiv.innerHTML = '⏭️ Étape sautée';
        statusDiv.style.background = '#f3f4f6';
        statusDiv.style.borderLeft = '4px solid #6b7280';
    }
}

/**
 * Continuer vers les phonons
 */
function continuerVersPhonons() {
    console.log('▶️ Continuation vers PH.X');
    
    // Fermer le workflow complet
    fermerWorkflowComplet();
    
    // Afficher un message
    alert('✅ Calculs préliminaires terminés!\n\nVous pouvez maintenant configurer et lancer les calculs de phonons (PH.X, Q2R, MATDYN, etc.)');
    
    // Scroll vers la section phonons
    const etape2 = document.querySelector('[style*="Étape 2"]');
    if (etape2) {
        etape2.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

console.log('✅ Fonctions workflow complet phonons chargées');


// ═══════════════════════════════════════════════════════════════════════════
// WORKFLOW COMPLET PHONONS - Fonctions d'interface
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Ouvrir le workflow complet phonons
 */
function ouvrirWorkflowCompletPhonons() {
    const zone = document.getElementById('zone_workflow_complet_phonons');
    if (zone) {
        zone.style.display = 'block';
        // Scroll vers la zone
        zone.scrollIntoView({ behavior: 'smooth', block: 'start' });
        console.log('✅ Workflow complet phonons ouvert');
    }
}

/**
 * Fermer le workflow complet
 */
function fermerWorkflowComplet() {
    const zone = document.getElementById('zone_workflow_complet_phonons');
    if (zone) {
        zone.style.display = 'none';
        console.log('❌ Workflow complet phonons fermé');
    }
}

/**
 * Éditer et lancer un calcul
 */
function editerEtLancerCalcul(type) {
    console.log(`📝 Édition et lancement du calcul: ${type}`);
    
    // Mettre à jour le statut
    const statusDiv = document.getElementById(`status_${type}`);
    if (statusDiv) {
        statusDiv.innerHTML = '🔄 Préparation de l\'input...';
        statusDiv.style.background = '#dbeafe';
        statusDiv.style.borderLeft = '4px solid #3b82f6';
    }
    
    // Générer un template d'input selon le type
    let template = '';
    const materiau = materiauWorkflow || 'GaN'; // Utiliser le matériau choisi ou GaN par défaut
    
    switch(type) {
        case 'vcrelax':
            template = `&CONTROL
    calculation = 'vc-relax'
    prefix = '${materiau}'
    outdir = './tmp/'
    pseudo_dir = '/home/hiadsi/Interface-QE_v1/pseudos/PBE/'
    etot_conv_thr = 1.0D-5
    forc_conv_thr = 1.0D-4
/

&SYSTEM
    ibrav = 4
    celldm(1) = 6.028
    celldm(3) = 1.626
    nat = 2
    ntyp = 2
    ecutwfc = 50.0
    ecutrho = 400.0
/

&ELECTRONS
    conv_thr = 1.0D-8
    mixing_beta = 0.3
    diagonalization = 'cg'
/

&IONS
    ion_dynamics = 'bfgs'
/

&CELL
    cell_dynamics = 'bfgs'
    press = 0.0
    press_conv_thr = 0.5
/

ATOMIC_SPECIES
 Ga  69.723  Ga.pbe-dn-kjpaw_psl.1.0.0.UPF
 N   14.007  N.pbe-n-kjpaw_psl.1.0.0.UPF

ATOMIC_POSITIONS crystal
 Ga  0.333  0.667  0.000
 N   0.333  0.667  0.377

K_POINTS automatic
 8 8 8  0 0 0`;
            break;
            
        case 'relax':
            template = `&CONTROL
    calculation = 'relax'
    prefix = '${materiau}'
    outdir = './tmp/'
    pseudo_dir = '/home/hiadsi/Interface-QE_v1/pseudos/PBE/'
    etot_conv_thr = 1.0D-5
    forc_conv_thr = 1.0D-4
/

&SYSTEM
    ibrav = 4
    celldm(1) = 6.028
    celldm(3) = 1.626
    nat = 2
    ntyp = 2
    ecutwfc = 50.0
    ecutrho = 400.0
/

&ELECTRONS
    conv_thr = 1.0D-8
    mixing_beta = 0.3
    diagonalization = 'cg'
/

&IONS
    ion_dynamics = 'bfgs'
/

ATOMIC_SPECIES
 Ga  69.723  Ga.pbe-dn-kjpaw_psl.1.0.0.UPF
 N   14.007  N.pbe-n-kjpaw_psl.1.0.0.UPF

ATOMIC_POSITIONS crystal
 Ga  0.333  0.667  0.000
 N   0.333  0.667  0.377

K_POINTS automatic
 8 8 8  0 0 0`;
            break;
            
        case 'scf':
            template = `&CONTROL
    calculation = 'scf'
    prefix = '${materiau}'
    outdir = './tmp/'
    pseudo_dir = '/home/hiadsi/Interface-QE_v1/pseudos/PBE/'
/

&SYSTEM
    ibrav = 4
    celldm(1) = 6.028
    celldm(3) = 1.626
    nat = 2
    ntyp = 2
    ecutwfc = 50.0
    ecutrho = 400.0
/

&ELECTRONS
    conv_thr = 1.0D-10
    mixing_beta = 0.7
    diagonalization = 'cg'
/

ATOMIC_SPECIES
 Ga  69.723  Ga.pbe-dn-kjpaw_psl.1.0.0.UPF
 N   14.007  N.pbe-n-kjpaw_psl.1.0.0.UPF

ATOMIC_POSITIONS crystal
 Ga  0.333  0.667  0.000
 N   0.333  0.667  0.377

K_POINTS automatic
 12 12 12  0 0 0`;
            break;
    }
    
    // Télécharger le fichier input
    const blob = new Blob([template], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${materiau}_${type}.in`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    // Mettre à jour le statut
    if (statusDiv) {
        statusDiv.innerHTML = `✅ Input téléchargé: ${materiau}_${type}.in<br>
            <small style="color: #6b7280;">Lancez le calcul avec: <code style="background: #1f2937; color: #10b981; padding: 2px 6px; border-radius: 3px;">mpirun -np 4 pw.x < ${materiau}_${type}.in > ${materiau}_${type}.out</code></small>`;
        statusDiv.style.background = '#d1fae5';
        statusDiv.style.borderLeft = '4px solid #10b981';
    }
    
    console.log(`✅ Input ${type} téléchargé`);
}

/**
 * Sauter une étape optionnelle
 */
function sauterEtape(type) {
    console.log(`⏭️ Étape ${type} sautée`);
    
    const statusDiv = document.getElementById(`status_${type}`);
    if (statusDiv) {
        statusDiv.innerHTML = '⏭️ Étape sautée';
        statusDiv.style.background = '#f3f4f6';
        statusDiv.style.borderLeft = '4px solid #6b7280';
    }
}

/**
 * Continuer vers les phonons
 */
function continuerVersPhonons() {
    console.log('▶️ Continuation vers PH.X');
    
    // Fermer le workflow complet
    fermerWorkflowComplet();
    
    // Afficher un message
    alert('✅ Calculs préliminaires terminés!\n\nVous pouvez maintenant configurer et lancer les calculs de phonons (PH.X, Q2R, MATDYN, etc.)');
    
    // Scroll vers la section phonons
    const etape2 = document.querySelector('[style*="Étape 2"]');
    if (etape2) {
        etape2.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

console.log('✅ Fonctions workflow complet phonons chargées');


// ═══════════════════════════════════════════════════════════════════════════
// VALIDATION DU MATÉRIAU
// ═══════════════════════════════════════════════════════════════════════════

// Variable globale pour stocker le matériau
let materiauWorkflow = null;

/**
 * Valider le matériau choisi
 */
function validerMateriau() {
    const input = document.getElementById('input_materiau_workflow');
    const materiau = input ? input.value.trim() : '';
    
    if (!materiau) {
        alert('⚠️ Veuillez entrer un nom de matériau');
        return;
    }
    
    // Stocker le matériau
    materiauWorkflow = materiau;
    
    // Afficher la confirmation
    const infoDiv = document.getElementById('materiau_valide_info');
    const nomSpan = document.getElementById('materiau_valide_nom');
    if (infoDiv && nomSpan) {
        nomSpan.textContent = materiau;
        infoDiv.style.display = 'block';
    }
    
    // Activer tous les boutons
    activerBoutonsWorkflow();
    
    console.log('✅ Matériau validé:', materiau);
}

/**
 * Activer les boutons du workflow
 */
function activerBoutonsWorkflow() {
    const boutons = [
        'btn_vcrelax',
        'btn_relax',
        'btn_scf',
        'btn_sauter_relax'
    ];
    
    boutons.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) {
            btn.disabled = false;
            btn.style.opacity = '1';
            btn.style.cursor = 'pointer';
        }
    });
    
    console.log('✅ Boutons du workflow activés');
}

console.log('✅ Fonctions de validation du matériau chargées');

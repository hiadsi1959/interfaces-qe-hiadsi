/**
 * Paramètres QE recommandés par type de calcul — voies directe (#calc_type) et CIF (#cif_calc_type).
 */
(function () {
    'use strict';

    /**
     * Profils par type pw.x (valeurs prêtes à injecter dans le formulaire / API).
     * kx/ky/kz = grille automatic indicative (à densifier selon la maille).
     */
    var QE_CALC_RECOMMENDED = {
        scf: {
            titre: 'SCF — Self-Consistent Field',
            ecutwfc: 50, ecutrho: 400, conv_thr: '1.0d-8', mixing_beta: 0.7,
            diagonalization: 'david', kx: 6, ky: 6, kz: 6,
            conseils: [
                'ecutwfc : tester la convergence (±10 Ry)',
                'ecutrho ≈ 8× ecutwfc (PAW/US)',
                'conv_thr 1d-8 : précision ~10 µeV'
            ]
        },
        relax: {
            titre: 'RELAX — Relaxation ionique',
            ecutwfc: 60, ecutrho: 480, conv_thr: '1.0d-9', mixing_beta: 0.5,
            diagonalization: 'david', forc_conv_thr: '1.0d-4', ion_dynamics: 'bfgs',
            kx: 6, ky: 6, kz: 6,
            showRelax: true,
            conseils: [
                'ecutwfc plus élevé que SCF pour forces fiables',
                'conv_thr strict (1d-9)',
                'forc_conv_thr 1d-4 Ry/bohr ≈ 0,5 meV/Å'
            ]
        },
        'vc-relax': {
            titre: 'VC-RELAX — Relaxation complète',
            ecutwfc: 60, ecutrho: 480, conv_thr: '1.0d-9', mixing_beta: 0.3,
            diagonalization: 'david', forc_conv_thr: '1.0d-4', press_conv_thr: 0.5,
            ion_dynamics: 'bfgs', cell_dynamics: 'bfgs',
            kx: 6, ky: 6, kz: 6,
            showRelax: true, showVCRelax: true,
            conseils: [
                'ecutwfc bien convergé avant vc-relax',
                'mixing_beta bas (0,3) pour stabilité',
                'press_conv_thr 0,5 kbar (standard)'
            ]
        },
        nscf: {
            titre: 'NSCF — Non Self-Consistent',
            ecutwfc: 50, ecutrho: 400, conv_thr: '1.0d-10', mixing_beta: 0.7,
            diagonalization: 'david', kx: 12, ky: 12, kz: 12,
            conseils: [
                'Même ecutwfc/ecutrho que le SCF précédent',
                'Grille k plus dense (DOS / optique)',
                'startingpot = file (lecture charge SCF)'
            ]
        },
        bands: {
            titre: 'BANDS — Structure de bandes',
            ecutwfc: 50, ecutrho: 400, conv_thr: '1.0d-10', mixing_beta: 0.7,
            diagonalization: 'david', kx: 8, ky: 8, kz: 8,
            conseils: [
                'Après SCF (+ NSCF si besoin)',
                'K_POINTS crystal_b (chemin haute symétrie)',
                'Puis bands.x / plotband pour le tracé'
            ]
        },
        md: {
            titre: 'MD — Dynamique moléculaire',
            ecutwfc: 40, ecutrho: 320, conv_thr: '1.0d-7', mixing_beta: 0.7,
            diagonalization: 'david', ion_dynamics: 'verlet',
            kx: 4, ky: 4, kz: 4,
            showRelax: true,
            conseils: [
                'Coûteux : ecut réduit pour tests',
                'dt ≈ 20–40 a.u. (0,5–1 fs)',
                'Équilibrer sur ≥ 1000 pas'
            ]
        },
        'vc-md': {
            titre: 'VC-MD — MD maille variable',
            ecutwfc: 40, ecutrho: 320, conv_thr: '1.0d-7', mixing_beta: 0.3,
            diagonalization: 'david', ion_dynamics: 'verlet', cell_dynamics: 'bfgs',
            press_conv_thr: 0.5, forc_conv_thr: '1.0d-3',
            kx: 4, ky: 4, kz: 4,
            showRelax: true, showVCRelax: true,
            conseils: [
                'mixing_beta bas (0,3)',
                '&IONS + &CELL requis',
                'Surveiller pression et température'
            ]
        },
        scf_berry: {
            titre: 'SCF + Phase de Berry',
            ecutwfc: 55, ecutrho: 440, conv_thr: '1.0d-9', mixing_beta: 0.5,
            diagonalization: 'david', kx: 6, ky: 6, kz: 6,
            conseils: [
                'Après vc-relax convergé',
                'Namelist &BP : lberry, gdir, nppstr',
                'Pas de lelfield avec lberry'
            ]
        },
        scf_born: {
            titre: 'SCF strict — préparation Born',
            ecutwfc: 55, ecutrho: 440, conv_thr: '1.0d-12', mixing_beta: 0.5,
            diagonalization: 'david', kx: 6, ky: 6, kz: 6,
            conseils: [
                'conv_thr = 1.d-12 avant ph.x zeu',
                'Même prefix/outdir pour la suite',
                'Après géométrie relaxée'
            ]
        }
    };

    /** Alias → clé du dictionnaire */
    var ALIAS = {
        'vc_relax': 'vc-relax',
        'vc_md': 'vc-md',
        'scf-berry': 'scf_berry',
        'scf-born': 'scf_born'
    };

    function normalizeCalcType(ct) {
        var t = String(ct || 'scf').trim().toLowerCase();
        if (ALIAS[t]) t = ALIAS[t];
        return t;
    }

    function cloneRec(rec) {
        return JSON.parse(JSON.stringify(rec));
    }

    /**
     * Retourne le profil recommandé (éventuellement fusionné avec le profil matériau).
     */
    window.qeGetRecommendedCalcParams = function qeGetRecommendedCalcParams(calcType, opts) {
        opts = opts || {};
        var ct = normalizeCalcType(calcType);
        var base = QE_CALC_RECOMMENDED[ct];
        if (!base) {
            // Types auxiliaires (dos.x, ph.x…) : pas de params pw complets
            return {
                titre: (typeof window.qeGetCalcTypeMeta === 'function' && window.qeGetCalcTypeMeta(ct))
                    ? window.qeGetCalcTypeMeta(ct).label : ct.toUpperCase(),
                aux: true,
                conseils: ['Input post-pw — template généré ; pas de grille ecut pw.x à ajuster ici.']
            };
        }
        var out = cloneRec(base);
        out.calcType = ct;

        // Fusion profil matériau (convergence_profiles) si disponible
        var materialClass = opts.materialClass || null;
        if (!materialClass && typeof window.resoudreClasseMateriauConvergence === 'function') {
            var typeId = (document.getElementById('type_materiau') || {}).value || '';
            if (typeId) materialClass = window.resoudreClasseMateriauConvergence(typeId);
        }
        if (!materialClass && typeof window.obtenirClasseElectroniqueManuelle === 'function') {
            try { materialClass = window.obtenirClasseElectroniqueManuelle(); } catch (_e) {}
        }
        if (materialClass && typeof window.getConvergenceProfile === 'function') {
            var mapCt = ct;
            if (mapCt === 'vc-md') mapCt = 'vc-relax';
            else if (mapCt === 'scf_berry' || mapCt === 'scf_born') mapCt = 'scf';
            var prof = window.getConvergenceProfile(materialClass, mapCt);
            if (prof) {
                if (prof.ecutwfc != null) out.ecutwfc = prof.ecutwfc;
                if (prof.ecutrho != null) out.ecutrho = prof.ecutrho;
                if (prof.conv_thr != null && ct !== 'scf_born') out.conv_thr = prof.conv_thr;
                if (prof.mixing_beta != null) out.mixing_beta = prof.mixing_beta;
                out.materialClass = materialClass;
                out.fromMaterialProfile = true;
            }
        }
        if (ct === 'scf_born') out.conv_thr = '1.0d-12';
        return out;
    };

    function setField(id, val, flash) {
        var el = document.getElementById(id);
        if (!el || val == null || val === '') return false;
        el.value = val;
        if (flash !== false) {
            el.style.transition = 'border-color 0.4s ease, background-color 0.4s ease';
            el.style.borderColor = '#10b981';
            el.style.backgroundColor = '#f0fdf4';
            setTimeout(function () {
                el.style.borderColor = '';
                el.style.backgroundColor = '';
            }, 1800);
        }
        return true;
    }

    function renderRecPanel(container, rec) {
        if (!container || !rec) return;
        var tips = (rec.conseils || []).map(function (c) {
            return '<li>' + String(c).replace(/</g, '&lt;') + '</li>';
        }).join('');
        var mat = rec.fromMaterialProfile
            ? '<p style="margin:0 0 8px;font-size:0.88em;opacity:0.95;">Profil matériau : <code>'
                + String(rec.materialClass || '').replace(/</g, '&lt;') + '</code> + type de calcul</p>'
            : '';
        var vals = rec.aux ? '' : (
            '<p style="margin:0 0 10px;font-size:0.9em;line-height:1.5;">'
            + '<strong>ecutwfc</strong>=' + rec.ecutwfc
            + ' · <strong>ecutrho</strong>=' + rec.ecutrho
            + ' · <strong>conv_thr</strong>=' + rec.conv_thr
            + ' · <strong>mixing_beta</strong>=' + rec.mixing_beta
            + (rec.kx ? ' · <strong>k</strong>=' + rec.kx + '×' + rec.ky + '×' + rec.kz : '')
            + '</p>'
        );
        container.innerHTML = ''
            + '<div class="qe-rec-panel" style="padding:14px 16px;border-radius:10px;'
            + 'background:linear-gradient(135deg,#ecfdf5,#f0f9ff);border:2px solid #34d399;color:#064e3b;">'
            + '<h4 style="margin:0 0 6px;color:#065f46;font-size:1.05em;">Paramètres recommandés — '
            + String(rec.titre || '').replace(/</g, '&lt;') + '</h4>'
            + mat + vals
            + (tips ? '<ul style="margin:0;padding-left:18px;line-height:1.55;font-size:0.9em;">' + tips + '</ul>' : '')
            + '</div>';
    }

    function applyDirect(rec) {
        if (!rec || rec.aux) {
            var relax0 = document.getElementById('parametres_relax');
            var vcr0 = document.getElementById('parametres_vcrelax');
            if (relax0) relax0.style.display = 'none';
            if (vcr0) vcr0.style.display = 'none';
            return;
        }
        setField('ecutwfc', rec.ecutwfc);
        setField('ecutrho', rec.ecutrho);
        setField('conv_thr', rec.conv_thr);
        setField('mixing_beta', rec.mixing_beta);
        if (rec.diagonalization) setField('diagonalization', rec.diagonalization);
        if (rec.forc_conv_thr) setField('forc_conv_thr', rec.forc_conv_thr);
        if (rec.press_conv_thr != null) setField('press_conv_thr', rec.press_conv_thr);
        if (rec.ion_dynamics) setField('ion_dynamics', rec.ion_dynamics);
        if (rec.cell_dynamics) setField('cell_dynamics', rec.cell_dynamics);
        if (rec.kx != null) setField('kx', rec.kx);
        if (rec.ky != null) setField('ky', rec.ky);
        if (rec.kz != null) setField('kz', rec.kz);

        var relaxParams = document.getElementById('parametres_relax');
        var vcrelaxParams = document.getElementById('parametres_vcrelax');
        if (relaxParams) relaxParams.style.display = rec.showRelax ? 'block' : 'none';
        if (vcrelaxParams) vcrelaxParams.style.display = rec.showVCRelax ? 'block' : 'none';

        var paramContainer = document.getElementById('parametres_container');
        if (paramContainer) paramContainer.style.display = 'block';
    }

    function applyCif(rec) {
        if (!rec || rec.aux) return;
        setField('cif_ecutwfc', rec.ecutwfc);
        setField('cif_ecutrho', rec.ecutrho);
        setField('cif_conv_thr', rec.conv_thr);
        setField('cif_mixing_beta', rec.mixing_beta);
        if (rec.forc_conv_thr) setField('cif_forc_conv_thr', rec.forc_conv_thr);
        if (rec.kx != null) setField('cif_kx', rec.kx);
        if (rec.ky != null) setField('cif_ky', rec.ky);
        if (rec.kz != null) setField('cif_kz', rec.kz);

        // Ouvrir le panneau params si fermé
        var panel = document.getElementById('cif_qe_params_panel');
        if (panel && !panel.open) panel.open = true;
    }

    /**
     * Applique les recommandations.
     * @param {string} calcType
     * @param {{scope?:'direct'|'cif'|'both', materialClass?:string, flash?:boolean}} opts
     */
    window.qeApplyRecommendedCalcParams = function qeApplyRecommendedCalcParams(calcType, opts) {
        opts = opts || {};
        var scope = opts.scope || 'both';
        var rec = window.qeGetRecommendedCalcParams(calcType, opts);

        if (scope === 'direct' || scope === 'both') {
            applyDirect(rec);
            renderRecPanel(document.getElementById('recommandations_container'), rec);
        }
        if (scope === 'cif' || scope === 'both') {
            applyCif(rec);
            var cifPanel = document.getElementById('cif_calc_rec_panel');
            if (!cifPanel) {
                var calcSel = document.getElementById('cif_calc_type');
                var host = calcSel && calcSel.parentElement;
                if (host) {
                    cifPanel = document.createElement('div');
                    cifPanel.id = 'cif_calc_rec_panel';
                    cifPanel.style.marginTop = '12px';
                    host.appendChild(cifPanel);
                }
            }
            if (cifPanel) renderRecPanel(cifPanel, rec);
        }
        return rec;
    };

    window.qeBindCalcTypeRecommendedParams = function qeBindCalcTypeRecommendedParams() {
        function bind(selId, scope) {
            var el = document.getElementById(selId);
            if (!el || el.dataset.recBound === '1') return;
            el.dataset.recBound = '1';
            el.addEventListener('change', function () {
                window.qeApplyRecommendedCalcParams(el.value, { scope: scope });
            });
        }
        bind('calc_type', 'direct');
        bind('cif_calc_type', 'cif');
        bind('gestion_cif_calc_type', 'cif');
    };

    document.addEventListener('tab1Restructured', function () {
        setTimeout(function () {
            window.qeBindCalcTypeRecommendedParams();
            var ct = document.getElementById('calc_type');
            if (ct && ct.value) window.qeApplyRecommendedCalcParams(ct.value, { scope: 'direct' });
        }, 200);
    });
    document.addEventListener('htmlFragmentsLoaded', function () {
        setTimeout(window.qeBindCalcTypeRecommendedParams, 80);
        setTimeout(function () {
            window.qeBindCalcTypeRecommendedParams();
            var ct = document.getElementById('cif_calc_type');
            if (ct && ct.value) window.qeApplyRecommendedCalcParams(ct.value, { scope: 'cif' });
        }, 400);
    });
    window.addEventListener('load', function () {
        setTimeout(window.qeBindCalcTypeRecommendedParams, 600);
        setTimeout(function () {
            var ct = document.getElementById('calc_type');
            if (ct && ct.value) window.qeApplyRecommendedCalcParams(ct.value, { scope: 'direct' });
        }, 900);
    });

    window.QE_CALC_RECOMMENDED = QE_CALC_RECOMMENDED;

    /** Charge la source unique JSON via API (écrase le fallback embarqué). */
    window.qeSyncRecommendedFromApi = function qeSyncRecommendedFromApi() {
        var base = (typeof window.getGenInputsApiBase === 'function')
            ? window.getGenInputsApiBase() : 'http://127.0.0.1:5012';
        return fetch(base + '/api/calc/recommended')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (!data || !data.ok || !data.defaults) return false;
                Object.keys(data.defaults).forEach(function (k) {
                    QE_CALC_RECOMMENDED[k] = data.defaults[k];
                });
                if (data.aliases) {
                    Object.keys(data.aliases).forEach(function (a) {
                        ALIAS[a] = data.aliases[a];
                    });
                }
                window.QE_CALC_RECOMMENDED = QE_CALC_RECOMMENDED;
                window.QE_CALC_WORKFLOWS = data.workflows || {};
                console.log('✅ Reco calcul synchronisées depuis API JSON');
                return true;
            })
            .catch(function () { return false; });
    };

    console.log('✅ Paramètres recommandés par type de calcul chargés');
    try { window.qeSyncRecommendedFromApi(); } catch (_eSync) {}
})();

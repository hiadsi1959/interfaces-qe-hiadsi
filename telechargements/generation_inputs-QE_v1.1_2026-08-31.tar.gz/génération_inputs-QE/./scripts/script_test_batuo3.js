// ═══════════════════════════════════════════════════════════════════════════
// TEST AUTOMATISÉ - BaTiO3 STRUCTURE CUBIQUE GE 221
// ═══════════════════════════════════════════════════════════════════════════

/**
 * TEST COMPLET: BaTiO3 - Pérovskite Cubique (GE 221)
 */
function testBaTiO3_GE221() {
    console.log('\n\n');
    console.log('═══════════════════════════════════════════════════════════════');
    console.log('🧪 TEST COMPLET: BaTiO3 - Pérovskite Cubique (GE 221)');
    console.log('═══════════════════════════════════════════════════════════════\n');
    
    // ÉTAPE 1: Préparer les données
    console.log('📋 ÉTAPE 1: Préparation des données\n');
    
    const testData = {
        materiau: 'BaTiO3',
        prefix: 'BaTiO3_scf',
        ibrav: '2',  // Cubique Centré (BCC)
        groupe_espace: '221',  // Pérovskite cubique
        ntyp: 3,
        nat: 5,
        elements: ['Ba', 'Ti', 'O'],
        ecutwfc: '50',
        ecutrho: '200',
        functional: 'PBE',
        kpoints: '2 2 2'
    };
    
    console.log(`  Matériau: ${testData.materiau}`);
    console.log(`  Prefix: ${testData.prefix}`);
    console.log(`  ibrav: ${testData.ibrav} (BCC)`);
    console.log(`  Groupe d'espace: ${testData.groupe_espace} (Pérovskite)`);
    console.log(`  ntyp: ${testData.ntyp}`);
    console.log(`  nat: ${testData.nat}`);
    console.log(`  Éléments: [${testData.elements.join(', ')}]`);
    console.log(`  ecutwfc: ${testData.ecutwfc} Ry`);
    console.log(`  ecutrho: ${testData.ecutrho} Ry`);
    console.log(`  Fonctionnelle: ${testData.functional}`);
    console.log(`  k-points: ${testData.kpoints}`);
    
    // ÉTAPE 2: Remplir les champs HTML
    console.log('\n📝 ÉTAPE 2: Remplissage des champs HTML\n');
    
    try {
        // Champs de base
        document.getElementById('materiau_name').value = testData.materiau;
        console.log(`  ✓ materiau_name = ${testData.materiau}`);
        
        document.getElementById('prefix_name').value = testData.prefix;
        console.log(`  ✓ prefix_name = ${testData.prefix}`);
        
        document.getElementById('ibrav').value = testData.ibrav;
        document.getElementById('ibrav').dispatchEvent(new Event('change', { bubbles: true }));
        console.log(`  ✓ ibrav = ${testData.ibrav}`);
        
        document.getElementById('ntyp').value = testData.ntyp;
        document.getElementById('ntyp').dispatchEvent(new Event('change', { bubbles: true }));
        console.log(`  ✓ ntyp = ${testData.ntyp}`);
        
        // Attendre que les éléments se créent
        setTimeout(() => {
            // Remplir les éléments
            for (let i = 0; i < testData.elements.length; i++) {
                const elemField = document.getElementById(`element_${i + 1}`);
                if (elemField) {
                    elemField.value = testData.elements[i];
                    elemField.dispatchEvent(new Event('input', { bubbles: true }));
                    console.log(`  ✓ element_${i + 1} = ${testData.elements[i]}`);
                }
            }
            
            // Remplir nat
            document.getElementById('nat').value = testData.nat;
            document.getElementById('nat').dispatchEvent(new Event('change', { bubbles: true }));
            console.log(`  ✓ nat = ${testData.nat}`);
            
            // Remplir les paramètres de calcul
            document.getElementById('ecutwfc').value = testData.ecutwfc;
            console.log(`  ✓ ecutwfc = ${testData.ecutwfc}`);
            
            document.getElementById('ecutrho').value = testData.ecutrho;
            console.log(`  ✓ ecutrho = ${testData.ecutrho}`);
            
            document.getElementById('functional').value = testData.functional;
            console.log(`  ✓ functional = ${testData.functional}`);
            
            document.getElementById('kpoints').value = testData.kpoints;
            console.log(`  ✓ kpoints = ${testData.kpoints}`);
            
            // ÉTAPE 3: Générer les positions
            console.log('\n🚀 ÉTAPE 3: Génération des positions\n');
            
            setTimeout(() => {
                if (typeof genererPositionsAuto === 'function') {
                    genererPositionsAuto();
                    console.log('  ✓ genererPositionsAuto() exécutée');
                } else {
                    console.error('  ❌ genererPositionsAuto NOT FOUND');
                }
                
                // ÉTAPE 4: Générer l'input
                console.log('\n📄 ÉTAPE 4: Génération de l\'input\n');
                
                setTimeout(() => {
                    if (typeof genererInputAvecPreparation === 'function') {
                        genererInputAvecPreparation();
                        console.log('  ✓ genererInputAvecPreparation() exécutée');
                    } else {
                        console.error('  ❌ genererInputAvecPreparation NOT FOUND');
                    }
                    
                    // ÉTAPE 5: Afficher le résultat
                    console.log('\n✅ ÉTAPE 5: Résultat final\n');
                    
                    setTimeout(() => {
                        console.log('═══════════════════════════════════════════════════════════════');
                        console.log('📊 RÉSULTAT FINAL');
                        console.log('═══════════════════════════════════════════════════════════════\n');
                        
                        // Vérifier ATOMIC_SPECIES
                        console.log('🔍 ATOMIC_SPECIES:');
                        if (window.atomicSpeciesGlobal && window.atomicSpeciesGlobal.length > 0) {
                            console.log('✅ REMPLI:');
                            console.log(window.atomicSpeciesGlobal);
                        } else {
                            console.error('❌ VIDE!');
                        }
                        
                        // Vérifier ATOMIC_POSITIONS
                        console.log('\n🔍 ATOMIC_POSITIONS:');
                        if (window.atomicPositionsContent && window.atomicPositionsContent.length > 0) {
                            console.log('✅ REMPLI:');
                            console.log(window.atomicPositionsContent);
                        } else {
                            console.error('❌ VIDE!');
                        }
                        
                        // Vérifier Input généré
                        console.log('\n🔍 INPUT GÉNÉRÉ:');
                        if (window.currentInputContent && window.currentInputContent.length > 0) {
                            console.log('✅ REMPLI:');
                            console.log(window.currentInputContent);
                        } else {
                            console.error('❌ VIDE!');
                        }
                        
                        console.log('\n═══════════════════════════════════════════════════════════════');
                        console.log('🎉 TEST TERMINÉ');
                        console.log('═══════════════════════════════════════════════════════════════\n');
                    }, 500);
                }, 500);
            }, 500);
        }, 500);
        
    } catch (err) {
        console.error('❌ ERREUR:', err);
    }
}

/**
 * Exécuter le test
 */
console.log('\n✅ Script test BaTiO3 chargé');
console.log('Pour lancer le test, exécutez dans la console: testBaTiO3_GE221()');



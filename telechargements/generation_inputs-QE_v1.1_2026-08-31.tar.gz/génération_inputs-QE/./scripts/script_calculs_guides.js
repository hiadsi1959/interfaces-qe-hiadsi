/**
 * ═══════════════════════════════════════════════════════════════════════════
 * SCRIPT CALCULS GUIDÉS - Workflows Automatisés pour Quantum ESPRESSO
 * Version 2.0 - Compatible API Native (port 5007)
 * ═══════════════════════════════════════════════════════════════════════════
 */

// Configuration API
const API_CALCULS = 'http://localhost:5007';
const INPUTS_DIR = '/home/hiadsi/Interface-QE_v1/inputs';
const OUTPUTS_DIR = '/home/hiadsi/Interface-QE_v1/outputs';
const PSEUDO_DIR = '/home/hiadsi/Interface-QE_v1/pseudos/PBE';

// État du workflow
let workflowEnCours = false;
let workflowData = {
    etapes: ['vc-relax', 'scf', 'nscf', 'bands', 'plot'],
    etapeActuelle: 0,
    parametresOptimises: null,
    fichiers: {},
    modeValidation: false,
    validationEnCours: false
};
let dernierInputGenere = null;

/**
 * Vérifier si l'API est disponible
 */
async function verifierAPICalculs() {
    try {
        const response = await fetch(`${API_CALCULS}/health`, { timeout: 5000 });
        const data = await response.json();
        console.log('✅ API Calculs Guidés disponible:', data);
        return true;
    } catch (error) {
        console.error('❌ API Calculs Guidés non disponible:', error);
        return false;
    }
}

/**
 * Ajouter un log au workflow
 */
function ajouterLogWorkflow(message) {
    const logsDiv = document.getElementById('workflow_logs');
    if (logsDiv) {
        const timestamp = new Date().toLocaleTimeString('fr-FR');
        logsDiv.innerHTML += `<div>[${timestamp}] ${message}</div>`;
        logsDiv.scrollTop = logsDiv.scrollHeight;
    } else {
        console.warn('⚠️ Zone de logs workflow introuvable (workflow_logs)');
    }
    console.log(`[WORKFLOW] ${message}`);
}

/**
 * Lancer le workflow automatique complet
 */
async function lancerWorkflowBandesAuto() {
    console.log('🚀 Démarrage lancerWorkflowBandesAuto()');
    
    // Vérifier l'API
    const apiOK = await verifierAPICalculs();
    if (!apiOK) {
        alert('❌ API non disponible (port 5007).\n\n' +
            'Dans un terminal :\n  cd /home/hiadsi/Interface-QE_v1\n  ./DEMARRER.sh\n\n' +
            'Puis ouvrez http://localhost:5007/generation-inputs/ (évite file:// + NetworkError).');
        return;
    }
    
    if (workflowEnCours) {
        alert('⚠️ Un workflow est déjà en cours!');
        return;
    }
    
    // Vérifier que l'input est généré
    const inputPreviewElem = document.getElementById('input_preview');
    let inputGenere = inputPreviewElem?.value || '';
    
    // Si pas d'input, vérifier s'il y a un dernier input sauvegardé
    if (!inputGenere.trim() && dernierInputGenere) {
        const confirmer = confirm('📋 Input détecté!\n\n' + 
            'Voulez-vous utiliser le dernier input que vous avez généré/sauvegardé?\n\n' +
            '(Sinon, vous devrez générer un nouvel input)');
        
        if (confirmer) {
            inputGenere = dernierInputGenere;
            if (inputPreviewElem) {
                inputPreviewElem.value = inputGenere;
            }
            ajouterLogWorkflow('✅ Input récupéré depuis la dernière génération');
        }
    }
    
    // Si toujours pas d'input
    if (!inputGenere.trim()) {
        const choix = confirm('❌ Aucun input généré dans cette session.\n\n' +
            '📂 Voulez-vous charger un input existant?\n\n' +
            'OUI = Ouvrir la liste des inputs\n' +
            'NON = Aller à "Génération Inputs"');
        
        if (choix) {
            // Charger les inputs disponibles
            await listerInputsDisponibles();
        } else {
            switchTab(0);
            alert('📝 Générez un input VC-RELAX puis sauvegardez-le, ensuite revenez dans "Calculs Guidés".');
        }
        return;
    }
    
    // Vérifier que c'est un calcul vc-relax
    if (!inputGenere.includes("calculation = 'vc-relax'") && !inputGenere.includes('calculation = "vc-relax"')) {
        const confirmer = confirm('⚠️ L\'input n\'est pas un VC-RELAX.\n\n' +
            'Le workflow nécessite un VC-RELAX pour commencer l\'optimisation.\n\n' +
            '🔄 Voulez-vous que je convertisse automatiquement cet input en VC-RELAX?');
        
        if (!confirmer) {
            alert('❌ Workflow annulé.\n\n💡 Changez le type de calcul en "vc-relax" dans la génération d\'input.');
            return;
        }
        
        // Convertir en vc-relax
        inputGenere = inputGenere.replace(/calculation\s*=\s*['"][^'"]*['"]/, "calculation = 'vc-relax'");
        
        // Ajouter &CELL si absent
        if (!inputGenere.includes('&CELL')) {
            const insertPos = inputGenere.lastIndexOf('/');
            inputGenere = inputGenere.substring(0, insertPos + 1) + 
                '\n\n&CELL\n    cell_dynamics = \'bfgs\'\n    press = 0.0\n/' + 
                inputGenere.substring(insertPos + 1);
        }
        
        if (inputPreviewElem) {
            inputPreviewElem.value = inputGenere;
        }
        ajouterLogWorkflow('🔄 Input converti en VC-RELAX automatiquement');
    }
    
    workflowEnCours = true;
    workflowData.etapeActuelle = 0;
    workflowData.fichiers = {};
    workflowData.parametresOptimises = null;
    
    // Afficher la zone de suivi
    const zoneWorkflow = document.getElementById('workflow_auto_zone');
    if (zoneWorkflow) {
        zoneWorkflow.style.display = 'block';
    } else {
        console.error('❌ Zone workflow introuvable (workflow_auto_zone)');
    }
    
    // Initialiser l'affichage
    afficherProgressionWorkflow();
    
    // Nettoyer les logs précédents
    const logsDiv = document.getElementById('workflow_logs');
    if (logsDiv) {
        logsDiv.innerHTML = '';
    } else {
        console.warn('⚠️ Zone de logs workflow introuvable (workflow_logs)');
    }
    
    ajouterLogWorkflow('\n🚀 DÉMARRAGE DU WORKFLOW AUTOMATIQUE');
    ajouterLogWorkflow('═══════════════════════════════════════════════════════════');
    ajouterLogWorkflow(`📁 Inputs: ${INPUTS_DIR}`);
    ajouterLogWorkflow(`📁 Outputs: ${OUTPUTS_DIR}`);
    
    // Lancer la première étape
    try {
        await executerEtapeWorkflow(0);
    } catch (error) {
        ajouterLogWorkflow(`❌ ERREUR: ${error.message}`);
        workflowEnCours = false;
    }
}

/**
 * Lister les inputs disponibles
 */
async function listerInputsDisponibles() {
    try {
        const response = await fetch(`${API_CALCULS}/api/lister_inputs`);
        const data = await response.json();
        
        if (data.fichiers && data.fichiers.length > 0) {
            let message = '📋 Inputs disponibles:\n\n';
            data.fichiers.forEach((f, i) => {
                message += `${i+1}. ${f.nom}\n`;
            });
            message += '\n\nAllez dans "Génération et Gestion des Inputs" (section Gestion) pour charger un input.';
            alert(message);
            switchTab(0);
            if (typeof afficherSousSection === 'function') afficherSousSection('gestion');
        } else {
            alert('❌ Aucun fichier input trouvé.\n\nAllez dans "Génération et Gestion des Inputs" pour créer un nouveau calcul.');
            switchTab(0);
        }
    } catch (error) {
        console.error('Erreur liste inputs:', error);
        alert('❌ Impossible de lister les inputs.\n\nVérifiez que l\'API est lancée.');
    }
}

/**
 * Afficher la progression du workflow
 */
function afficherProgressionWorkflow() {
    const etape = workflowData.etapeActuelle;
    const total = workflowData.etapes.length;
    const pourcentage = (etape / total) * 100;
    
    const nomsEtapes = {
        'vc-relax': '1️⃣ VC-RELAX - Optimisation',
        'scf': '2️⃣ SCF - Calcul auto-cohérent',
        'nscf': '3️⃣ NSCF - Grille k dense',
        'bands': '4️⃣ BANDS - Structure de bandes',
        'dos': '5️⃣ DOS - Densité d\'états',
        'plot': '6️⃣ PLOT - Tracé des bandes'
    };
    
    const progressionDiv = document.getElementById('workflow_progression');
    if (progressionDiv) {
        progressionDiv.innerHTML = `
            <div style="background: rgba(255,255,255,0.2); border-radius: 10px; overflow: hidden; height: 30px; position: relative;">
                <div style="background: linear-gradient(90deg, #4CAF50, #8BC34A); height: 100%; width: ${pourcentage}%; transition: width 0.5s;"></div>
                <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; font-weight: bold;">
                    Étape ${etape + 1}/${total} - ${Math.round(pourcentage)}%
                </div>
            </div>
        `;
    }
    
    // Afficher les étapes avec leur statut
    const etapesDiv = document.getElementById('workflow_etapes');
    if (etapesDiv) {
        let etapesHTML = '<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px;">';
        
        workflowData.etapes.forEach((etapeNom, index) => {
            let couleur = 'rgba(255,255,255,0.1)';
            let icone = '⏳';
            let statut = 'En attente';
            
            if (index < etape) {
                couleur = 'rgba(76, 175, 80, 0.4)';
                icone = '✅';
                statut = 'Terminé';
            } else if (index === etape) {
                couleur = 'rgba(255, 193, 7, 0.4)';
                icone = '⚙️';
                statut = 'En cours...';
            }
            
            etapesHTML += `
                <div style="background: ${couleur}; padding: 12px; border-radius: 8px; text-align: center; border: 2px solid rgba(255,255,255,0.3);">
                    <div style="font-size: 1.3em;">${icone}</div>
                    <div style="font-weight: bold; font-size: 0.9em;">${nomsEtapes[etapeNom] || etapeNom}</div>
                    <div style="font-size: 0.8em; opacity: 0.8;">${statut}</div>
                </div>
            `;
        });
        
        etapesHTML += '</div>';
        etapesDiv.innerHTML = etapesHTML;
    }
}

/**
 * Exécuter une étape du workflow
 */
async function executerEtapeWorkflow(etapeIndex) {
    const etapeNom = workflowData.etapes[etapeIndex];
    ajouterLogWorkflow(`\n🚀 Démarrage de l'étape: ${etapeNom.toUpperCase()}`);
    
    workflowData.etapeActuelle = etapeIndex;
    afficherProgressionWorkflow();
    
    try {
        switch (etapeNom) {
            case 'vc-relax':
                await etapeVCRelax();
                break;
            case 'scf':
                await etapeSCF();
                break;
            case 'nscf':
                await etapeNSCF();
                break;
            case 'bands':
                await etapeBANDS();
                break;
            case 'dos':
                await etapeDOS();
                break;
            case 'plot':
                await etapePlot();
                break;
        }
        
        // Passer à l'étape suivante
        if (etapeIndex < workflowData.etapes.length - 1) {
            ajouterLogWorkflow(`✅ Étape ${etapeNom} terminée avec succès!`);
            setTimeout(() => executerEtapeWorkflow(etapeIndex + 1), 2000);
        } else {
            workflowTermine();
        }
        
    } catch (error) {
        ajouterLogWorkflow(`❌ ERREUR lors de l'étape ${etapeNom}: ${error.message}`);
        console.error('Erreur workflow:', error);
        alert(`❌ Erreur lors de l'étape ${etapeNom}:\n${error.message}`);
        workflowEnCours = false;
    }
}

/**
 * Étape 1: VC-RELAX
 */
async function etapeVCRelax() {
    ajouterLogWorkflow('📝 Récupération de l\'input VC-RELAX...');
    
    let input = document.getElementById('input_preview').value;
    
    // S'assurer que c'est bien un vc-relax
    if (!input.includes("calculation = 'vc-relax'")) {
        input = input.replace(/calculation\s*=\s*['"][^'"]*['"]/, "calculation = 'vc-relax'");
        ajouterLogWorkflow('⚙️ Conversion de l\'input en VC-RELAX');
    }
    
    ajouterLogWorkflow('🚀 Lancement du calcul VC-RELAX via API...');
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
    const filename = `workflow_vcrelax_${timestamp}.in`;
    
    // Sauvegarder l'input via l'API
    const responseSave = await fetch(`${API_CALCULS}/api/sauvegarder_input`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            filename: filename,
            content: input
        })
    });
    
    if (!responseSave.ok) {
        throw new Error('Échec de la sauvegarde de l\'input');
    }
    
    ajouterLogWorkflow(`📁 Fichier créé: ${filename}`);
    
    // Lancer le calcul via l'API
    const responseLaunch = await fetch(`${API_CALCULS}/api/lancer_calcul`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            input_file: filename
        })
    });
    
    const resultLaunch = await responseLaunch.json();
    
    if (!resultLaunch.success) {
        throw new Error(resultLaunch.error || 'Échec du lancement du calcul');
    }
    
    ajouterLogWorkflow('✅ Calcul VC-RELAX lancé!');
    ajouterLogWorkflow(`📁 ID: ${resultLaunch.calcul_id || 'N/A'}`);
    
    workflowData.fichiers.vcrelax = { 
        input: filename, 
        output: resultLaunch.output_file || `${filename.replace('.in', '.out')}`,
        calcul_id: resultLaunch.calcul_id
    };
    
    // Attendre la fin du calcul
    await attendreFinCalcul(resultLaunch.calcul_id || filename.replace('.in', ''));
    
    // Extraire les paramètres optimisés
    ajouterLogWorkflow('📊 Extraction des paramètres optimisés...');
    await extraireParametresOptimises();
}

/**
 * Étape 2: SCF avec paramètres optimisés
 */
async function etapeSCF() {
    if (!workflowData.parametresOptimises) {
        ajouterLogWorkflow('⚠️ Pas de paramètres optimisés, utilisation de l\'input original');
    }
    
    ajouterLogWorkflow('📝 Génération de l\'input SCF...');
    
    // Récupérer l'input original et le modifier
    let inputOriginal = document.getElementById('input_preview').value;
    let inputSCF = inputOriginal.replace(/calculation\s*=\s*['"][^'"]*['"]/, "calculation = 'scf'");
    
    // Supprimer &CELL si présent (pas nécessaire pour SCF)
    inputSCF = inputSCF.replace(/&CELL[\s\S]*?\/\s*/g, '');
    
    // Injecter les paramètres optimisés si disponibles
    if (workflowData.parametresOptimises) {
        inputSCF = injecterParametresOptimises(inputSCF, workflowData.parametresOptimises);
        ajouterLogWorkflow(`   ✅ Paramètres optimisés injectés`);
    }
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
    const filename = `workflow_scf_${timestamp}.in`;
    
    // Sauvegarder et lancer
    await fetch(`${API_CALCULS}/api/sauvegarder_input`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename, content: inputSCF })
    });
    
    ajouterLogWorkflow('🚀 Lancement du calcul SCF...');
    
    const responseLaunch = await fetch(`${API_CALCULS}/api/lancer_calcul`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input_file: filename })
    });
    
    const resultLaunch = await responseLaunch.json();
    
    if (!resultLaunch.success) {
        throw new Error(resultLaunch.error || 'Échec du lancement SCF');
    }
    
    ajouterLogWorkflow('✅ Calcul SCF lancé!');
    workflowData.fichiers.scf = { input: filename, calcul_id: resultLaunch.calcul_id };
    
    await attendreFinCalcul(resultLaunch.calcul_id || filename.replace('.in', ''));
}

/**
 * Étape 3: NSCF avec grille k dense
 */
async function etapeNSCF() {
    ajouterLogWorkflow('📝 Génération de l\'input NSCF avec grille k dense...');
    
    let inputOriginal = document.getElementById('input_preview').value;
    let inputNSCF = inputOriginal.replace(/calculation\s*=\s*['"][^'"]*['"]/, "calculation = 'nscf'");
    
    // Supprimer &CELL si présent
    inputNSCF = inputNSCF.replace(/&CELL[\s\S]*?\/\s*/g, '');
    
    // Augmenter la grille k (×2)
    inputNSCF = inputNSCF.replace(/K_POINTS\s+automatic\s*\n\s*(\d+)\s+(\d+)\s+(\d+)/i, (match, k1, k2, k3) => {
        const newK1 = parseInt(k1) * 2;
        const newK2 = parseInt(k2) * 2;
        const newK3 = parseInt(k3) * 2;
        return `K_POINTS automatic\n${newK1} ${newK2} ${newK3}`;
    });
    
    // Ajouter nbnd si pas présent
    if (!inputNSCF.includes('nbnd')) {
        const natMatch = inputNSCF.match(/nat\s*=\s*(\d+)/);
        if (natMatch) {
            const nbnd = parseInt(natMatch[1]) * 8;
            inputNSCF = inputNSCF.replace(/(&SYSTEM[^/]*)(\/)/s, `$1    nbnd = ${nbnd}\n$2`);
            ajouterLogWorkflow(`   ✅ nbnd = ${nbnd} ajouté`);
        }
    }
    
    // Injecter les paramètres optimisés
    if (workflowData.parametresOptimises) {
        inputNSCF = injecterParametresOptimises(inputNSCF, workflowData.parametresOptimises);
    }
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
    const filename = `workflow_nscf_${timestamp}.in`;
    
    await fetch(`${API_CALCULS}/api/sauvegarder_input`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename, content: inputNSCF })
    });
    
    ajouterLogWorkflow('🚀 Lancement du calcul NSCF...');
    
    const responseLaunch = await fetch(`${API_CALCULS}/api/lancer_calcul`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input_file: filename })
    });
    
    const resultLaunch = await responseLaunch.json();
    
    if (!resultLaunch.success) {
        throw new Error(resultLaunch.error || 'Échec du lancement NSCF');
    }
    
    ajouterLogWorkflow('✅ Calcul NSCF lancé!');
    workflowData.fichiers.nscf = { input: filename, calcul_id: resultLaunch.calcul_id };
    
    await attendreFinCalcul(resultLaunch.calcul_id || filename.replace('.in', ''));
}

/**
 * Étape 4: BANDS avec k-path
 */
async function etapeBANDS() {
    ajouterLogWorkflow('📝 Génération de l\'input BANDS...');
    
    let inputOriginal = document.getElementById('input_preview').value;
    let inputBANDS = inputOriginal.replace(/calculation\s*=\s*['"][^'"]*['"]/, "calculation = 'bands'");
    
    // Supprimer &CELL si présent
    inputBANDS = inputBANDS.replace(/&CELL[\s\S]*?\/\s*/g, '');
    
    // Détecter ibrav
    const ibravMatch = inputOriginal.match(/ibrav\s*=\s*(\d+)/);
    const ibrav = ibravMatch ? parseInt(ibravMatch[1]) : 0;
    
    // Générer le k-path approprié
    let kPath = '';
    if (ibrav === 2) {
        // FCC
        kPath = `K_POINTS crystal_b
5
0.0000 0.0000 0.0000 50  ! Gamma
0.5000 0.0000 0.5000 50  ! X
0.5000 0.2500 0.7500 50  ! W
0.0000 0.0000 0.0000 50  ! Gamma
0.5000 0.5000 0.5000 1   ! L`;
        ajouterLogWorkflow('   ✅ Réseau FCC détecté → Chemin Γ-X-W-Γ-L');
    } else if (ibrav === 3) {
        // BCC
        kPath = `K_POINTS crystal_b
4
0.0000 0.0000 0.0000 50  ! Gamma
0.5000 -0.5000 0.5000 50 ! H
0.0000 0.0000 0.5000 50  ! N
0.0000 0.0000 0.0000 1   ! Gamma`;
        ajouterLogWorkflow('   ✅ Réseau BCC détecté → Chemin Γ-H-N-Γ');
    } else if (ibrav === 4) {
        // Hexagonal
        kPath = `K_POINTS crystal_b
4
0.0000 0.0000 0.0000 50  ! Gamma
0.5000 0.0000 0.0000 50  ! M
0.3333 0.3333 0.0000 50  ! K
0.0000 0.0000 0.0000 1   ! Gamma`;
        ajouterLogWorkflow('   ✅ Réseau Hexagonal détecté → Chemin Γ-M-K-Γ');
    } else {
        // Défaut cubique
        kPath = `K_POINTS crystal_b
4
0.0000 0.0000 0.0000 50  ! Gamma
0.5000 0.0000 0.0000 50  ! X
0.5000 0.5000 0.0000 50  ! M
0.0000 0.0000 0.0000 1   ! Gamma`;
        ajouterLogWorkflow('   ✅ Réseau par défaut → Chemin Γ-X-M-Γ');
    }
    
    // Remplacer K_POINTS
    inputBANDS = inputBANDS.replace(/K_POINTS[\s\S]*$/i, kPath);
    
    // Injecter les paramètres optimisés
    if (workflowData.parametresOptimises) {
        inputBANDS = injecterParametresOptimises(inputBANDS, workflowData.parametresOptimises);
    }
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
    const filename = `workflow_bands_${timestamp}.in`;
    
    await fetch(`${API_CALCULS}/api/sauvegarder_input`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename, content: inputBANDS })
    });
    
    ajouterLogWorkflow('🚀 Lancement du calcul BANDS...');
    
    const responseLaunch = await fetch(`${API_CALCULS}/api/lancer_calcul`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input_file: filename })
    });
    
    const resultLaunch = await responseLaunch.json();
    
    if (!resultLaunch.success) {
        throw new Error(resultLaunch.error || 'Échec du lancement BANDS');
    }
    
    ajouterLogWorkflow('✅ Calcul BANDS lancé!');
    workflowData.fichiers.bands = { input: filename, calcul_id: resultLaunch.calcul_id };
    
    await attendreFinCalcul(resultLaunch.calcul_id || filename.replace('.in', ''));
}

/**
 * Étape 5: DOS (optionnel)
 */
async function etapeDOS() {
    ajouterLogWorkflow('📝 Génération de l\'input DOS...');
    
    // Créer input pour dos.x
    const prefix = workflowData.fichiers.scf?.input?.replace('.in', '') || 'qe_calc';
    
    const inputDOS = `&DOS
    prefix = '${prefix}'
    outdir = '${OUTPUTS_DIR}/tmp/'
    fildos = 'dos.dat'
    DeltaE = 0.01
/`;
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
    const filename = `workflow_dos_${timestamp}.in`;
    
    await fetch(`${API_CALCULS}/api/sauvegarder_input`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename, content: inputDOS })
    });
    
    ajouterLogWorkflow('🚀 Lancement du calcul DOS...');
    
    // Lancer dos.x
    const responseLaunch = await fetch(`${API_CALCULS}/api/lancer_calcul`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            input_file: filename,
            executable: 'dos.x'
        })
    });
    
    const resultLaunch = await responseLaunch.json();
    
    if (!resultLaunch.success) {
        ajouterLogWorkflow('⚠️ DOS optionnel - Continuons...');
        return;
    }
    
    ajouterLogWorkflow('✅ Calcul DOS lancé!');
    workflowData.fichiers.dos = { input: filename, calcul_id: resultLaunch.calcul_id };
    
    await attendreFinCalcul(resultLaunch.calcul_id || filename.replace('.in', ''));
}

/**
 * Étape finale: Plot des bandes
 */
async function etapePlot() {
    ajouterLogWorkflow('📊 Génération des graphiques...');
    
    // Essayer de tracer avec bands.x
    try {
        const prefix = workflowData.fichiers.bands?.input?.replace('.in', '') || 'bands';
        
        const inputBandsX = `&BANDS
    prefix = '${prefix}'
    outdir = '${OUTPUTS_DIR}/tmp/'
    filband = 'bands.dat'
/`;
        
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
        const filename = `workflow_bandsplot_${timestamp}.in`;
        
        await fetch(`${API_CALCULS}/api/sauvegarder_input`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename, content: inputBandsX })
        });
        
        const responsePlot = await fetch(`${API_CALCULS}/api/lancer_calcul`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                input_file: filename,
                executable: 'bands.x'
            })
        });
        
        const resultPlot = await responsePlot.json();
        
        if (resultPlot.success) {
            await attendreFinCalcul(resultPlot.calcul_id || filename.replace('.in', ''));
            ajouterLogWorkflow('✅ Graphiques générés!');
        } else {
            ajouterLogWorkflow('⚠️ Tracé optionnel - bands.dat disponible pour analyse externe');
        }
    } catch (error) {
        ajouterLogWorkflow('⚠️ Tracé non réalisé - fichiers disponibles pour analyse');
    }
}

/**
 * Attendre la fin d'un calcul
 */
async function attendreFinCalcul(calculId) {
    ajouterLogWorkflow(`⏳ Attente de la fin du calcul: ${calculId}`);
    
    let tentatives = 0;
    const maxTentatives = 600; // 10 minutes max (polling toutes les secondes)
    
    while (tentatives < maxTentatives) {
        try {
            const response = await fetch(`${API_CALCULS}/api/etat_calcul/${calculId}`);
            const data = await response.json();
            
            if (data.status === 'termine' || data.status === 'completed') {
                ajouterLogWorkflow(`✅ Calcul terminé!`);
                
                // Vérifier si convergé
                if (data.converge === true || data.log?.includes('JOB DONE')) {
                    ajouterLogWorkflow(`   ✅ Convergence atteinte`);
                    if (data.energie) {
                        ajouterLogWorkflow(`   📊 Énergie: ${data.energie} Ry`);
                    }
                }
                return;
            } else if (data.status === 'erreur' || data.status === 'error') {
                throw new Error(`Calcul échoué: ${data.error || 'Erreur inconnue'}`);
            }
            
            // Afficher progression
            if (tentatives % 10 === 0) {
                ajouterLogWorkflow(`   ⏳ En cours... (${tentatives}s)`);
            }
            
        } catch (error) {
            if (tentatives > 5) {
                console.warn('Erreur vérification calcul:', error);
            }
        }
        
        await new Promise(resolve => setTimeout(resolve, 1000));
        tentatives++;
    }
    
    throw new Error(`Timeout: Le calcul n'a pas terminé après ${maxTentatives} secondes`);
}

/**
 * Extraire les paramètres optimisés du VC-RELAX
 */
async function extraireParametresOptimises() {
    try {
        const outputFile = workflowData.fichiers.vcrelax?.output;
        if (!outputFile) {
            ajouterLogWorkflow('⚠️ Fichier output non trouvé');
            return;
        }
        
        // Lire le fichier output via l'API
        const response = await fetch(`${API_CALCULS}/api/lire_output/${encodeURIComponent(outputFile)}`);
        const data = await response.json();
        
        if (!data.content) {
            ajouterLogWorkflow('⚠️ Impossible de lire le fichier output');
            return;
        }
        
        const content = data.content;
        
        // Extraire alat
        const alatMatch = content.match(/lattice parameter \(alat\)\s*=\s*([\d.]+)\s*a\.u\./);
        const alat = alatMatch ? parseFloat(alatMatch[1]) : null;
        
        // Extraire les positions finales
        const posMatch = content.match(/ATOMIC_POSITIONS.*?\n([\s\S]*?)(?=End final|K_POINTS|$)/i);
        let positions = [];
        
        if (posMatch) {
            const lines = posMatch[1].trim().split('\n');
            for (const line of lines) {
                const parts = line.trim().split(/\s+/);
                if (parts.length >= 4) {
                    positions.push({
                        symbol: parts[0],
                        x: parseFloat(parts[1]),
                        y: parseFloat(parts[2]),
                        z: parseFloat(parts[3])
                    });
                }
            }
        }
        
        if (alat && positions.length > 0) {
            workflowData.parametresOptimises = { alat, positions };
            ajouterLogWorkflow(`   ✅ alat = ${alat.toFixed(4)} a.u.`);
            ajouterLogWorkflow(`   ✅ ${positions.length} positions atomiques extraites`);
        } else {
            ajouterLogWorkflow('⚠️ Paramètres optimisés partiellement extraits');
        }
        
    } catch (error) {
        ajouterLogWorkflow(`⚠️ Erreur extraction paramètres: ${error.message}`);
    }
}

/**
 * Injecter les paramètres optimisés dans un input
 */
function injecterParametresOptimises(input, params) {
    if (!params) return input;
    
    let result = input;
    
    // Mettre à jour celldm(1) si alat disponible
    if (params.alat) {
        result = result.replace(/celldm\(1\)\s*=\s*[\d.]+/, `celldm(1) = ${params.alat.toFixed(6)}`);
    }
    
    // Mettre à jour les positions atomiques
    if (params.positions && params.positions.length > 0) {
        const posBlock = params.positions.map(p => 
            `${p.symbol}   ${p.x.toFixed(9)}   ${p.y.toFixed(9)}   ${p.z.toFixed(9)}`
        ).join('\n');
        
        // Remplacer le bloc ATOMIC_POSITIONS
        result = result.replace(
            /ATOMIC_POSITIONS\s+\{?\s*\w*\s*\}?\s*\n[\s\S]*?(?=K_POINTS|$)/i,
            `ATOMIC_POSITIONS crystal\n${posBlock}\n\n`
        );
    }
    
    return result;
}

/**
 * Workflow terminé
 */
function workflowTermine() {
    workflowEnCours = false;
    workflowData.etapeActuelle = workflowData.etapes.length;
    afficherProgressionWorkflow();
    
    ajouterLogWorkflow('\n═══════════════════════════════════════════════════════════');
    ajouterLogWorkflow('🎉 WORKFLOW TERMINÉ AVEC SUCCÈS!');
    ajouterLogWorkflow('═══════════════════════════════════════════════════════════');
    ajouterLogWorkflow(`📁 Fichiers générés dans: ${OUTPUTS_DIR}`);
    ajouterLogWorkflow('📊 Cliquez sur "Voir les Résultats" pour visualiser les graphiques');
    
    // Notification
    if (Notification.permission === 'granted') {
        new Notification('🎉 Workflow QE Terminé!', {
            body: 'Tous les calculs sont terminés avec succès.',
            icon: '⚛️'
        });
    }
}

/**
 * Arrêter le workflow
 */
function arreterWorkflowAuto() {
    if (confirm('⚠️ Voulez-vous vraiment arrêter le workflow en cours?\n\nLes calculs lancés continueront, mais les étapes suivantes seront annulées.')) {
        workflowEnCours = false;
        ajouterLogWorkflow('\n⛔ WORKFLOW ARRÊTÉ PAR L\'UTILISATEUR');
        afficherProgressionWorkflow();
    }
}

/**
 * Afficher les résultats du workflow
 */
function afficherResultatsWorkflow() {
    console.log('📊 afficherResultatsWorkflow() appelée');
    
    if (!workflowData || Object.keys(workflowData.fichiers).length === 0) {
        // Essayer de charger depuis les outputs existants
        chargerResultatsExistants();
        return;
    }
    
    let html = '<h3>📊 Résultats du Workflow</h3>';
    html += '<div style="display: grid; gap: 15px;">';
    
    for (const [etape, fichiers] of Object.entries(workflowData.fichiers)) {
        html += `
            <div style="background: #f5f5f5; padding: 15px; border-radius: 8px;">
                <strong>${etape.toUpperCase()}</strong><br>
                📄 Input: ${fichiers.input || 'N/A'}<br>
                📄 Output: ${fichiers.output || 'N/A'}
                <button onclick="telechargerFichier('${fichiers.output}')" style="margin-left: 10px;">📥 Télécharger</button>
            </div>
        `;
    }
    
    html += '</div>';
    
    // Afficher dans une modale
    const modal = document.createElement('div');
    modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); display: flex; align-items: center; justify-content: center; z-index: 10000;';
    modal.innerHTML = `
        <div style="background: white; padding: 30px; border-radius: 10px; max-width: 800px; max-height: 80vh; overflow-y: auto;">
            ${html}
            <button onclick="this.parentElement.parentElement.remove()" style="margin-top: 20px; padding: 10px 20px; background: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer;">Fermer</button>
        </div>
    `;
    document.body.appendChild(modal);
}

/**
 * Charger les résultats existants
 */
async function chargerResultatsExistants() {
    try {
        const response = await fetch(`${API_CALCULS}/api/lister_outputs`);
        const data = await response.json();
        
        if (data.fichiers && data.fichiers.length > 0) {
            let html = '<h3>📁 Fichiers Outputs Disponibles</h3>';
            html += '<div style="max-height: 400px; overflow-y: auto;">';
            
            data.fichiers.forEach(f => {
                html += `
                    <div style="padding: 10px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center;">
                        <span>${f.nom}</span>
                        <button onclick="telechargerFichier('${f.chemin}')" style="padding: 5px 10px;">📥</button>
                    </div>
                `;
            });
            
            html += '</div>';
            
            const modal = document.createElement('div');
            modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); display: flex; align-items: center; justify-content: center; z-index: 10000;';
            modal.innerHTML = `
                <div style="background: white; padding: 30px; border-radius: 10px; max-width: 600px; width: 90%;">
                    ${html}
                    <button onclick="this.parentElement.parentElement.remove()" style="margin-top: 20px; padding: 10px 20px; background: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer;">Fermer</button>
                </div>
            `;
            document.body.appendChild(modal);
        } else {
            alert('❌ Aucun résultat de workflow trouvé.\n\nLancez d\'abord un workflow automatique.');
        }
    } catch (error) {
        alert('❌ Impossible de charger les résultats.\n\nVérifiez que l\'API est lancée.');
    }
}

/**
 * Afficher la configuration du workflow
 */
function afficherConfigWorkflowBandes() {
    const modal = document.createElement('div');
    modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); display: flex; align-items: center; justify-content: center; z-index: 10000;';
    modal.innerHTML = `
        <div style="background: white; padding: 30px; border-radius: 10px; max-width: 600px; width: 90%;">
            <h3>⚙️ Configuration du Workflow</h3>
            
            <div style="margin: 20px 0;">
                <label style="display: block; margin: 10px 0;">
                    <input type="checkbox" id="config_validation" ${workflowData.modeValidation ? 'checked' : ''}>
                    Mode validation (pause entre chaque étape)
                </label>
                
                <label style="display: block; margin: 10px 0;">
                    Étapes à exécuter:
                </label>
                <div style="margin-left: 20px;">
                    <label><input type="checkbox" checked disabled> VC-RELAX</label><br>
                    <label><input type="checkbox" checked disabled> SCF</label><br>
                    <label><input type="checkbox" checked disabled> NSCF</label><br>
                    <label><input type="checkbox" checked disabled> BANDS</label><br>
                    <label><input type="checkbox" id="config_dos" checked> DOS</label><br>
                    <label><input type="checkbox" id="config_plot" checked> Plot</label>
                </div>
            </div>
            
            <div style="margin: 20px 0; background: #f5f5f5; padding: 15px; border-radius: 8px;">
                <strong>📁 Chemins:</strong><br>
                Inputs: ${INPUTS_DIR}<br>
                Outputs: ${OUTPUTS_DIR}<br>
                Pseudos: ${PSEUDO_DIR}
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
                <button onclick="sauvegarderConfigWorkflow(); this.parentElement.parentElement.parentElement.remove();" 
                        style="padding: 10px 20px; background: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer;">
                    ✅ Sauvegarder
                </button>
                <button onclick="this.parentElement.parentElement.parentElement.remove()" 
                        style="padding: 10px 20px; background: #f44336; color: white; border: none; border-radius: 5px; cursor: pointer;">
                    ❌ Annuler
                </button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

/**
 * Sauvegarder la configuration du workflow
 */
function sauvegarderConfigWorkflow() {
    workflowData.modeValidation = document.getElementById('config_validation')?.checked || false;
    
    // Mettre à jour les étapes
    const includeDOS = document.getElementById('config_dos')?.checked;
    const includePlot = document.getElementById('config_plot')?.checked;
    
    workflowData.etapes = ['vc-relax', 'scf', 'nscf', 'bands'];
    if (includeDOS) workflowData.etapes.push('dos');
    if (includePlot) workflowData.etapes.push('plot');
    
    console.log('✅ Configuration sauvegardée:', workflowData);
    alert('✅ Configuration sauvegardée!');
}

/**
 * Démarrer un workflow guidé simple
 */
function demarrerWorkflow(type) {
    console.log('🚀 Démarrage workflow:', type);
    
    const workflowGuide = document.getElementById('workflow_guide');
    const workflowContent = document.getElementById('workflow_content');
    
    if (!workflowGuide || !workflowContent) {
        console.error('Éléments workflow non trouvés');
        return;
    }
    
    let html = '';
    
    if (type === 'scf-rapide') {
        html = `
            <h4>⚡ Workflow: Calcul Rapide SCF</h4>
            <div class="alert alert-info" style="background: #e3f2fd; padding: 15px; border-radius: 8px; margin: 15px 0;">
                Calcul rapide de l'énergie totale d'une structure connue.
            </div>
            
            <div style="margin: 20px 0;">
                <h5>Étape Unique: Calcul SCF</h5>
                <p>• Allez dans l'onglet "📝 Génération Inputs"</p>
                <p>• Sélectionnez <strong>Type de Calcul: SCF</strong></p>
                <p>• Entrez les paramètres de votre structure</p>
                <p>• Générez et lancez le calcul</p>
                <button class="btn btn-primary" onclick="switchTab(0)" style="margin-top: 10px; padding: 10px 20px;">
                    → Aller à Génération Inputs
                </button>
            </div>
        `;
    } else if (type === 'relax-simple') {
        html = `
            <h4>🔧 Workflow: Relaxation Simple</h4>
            <div class="alert alert-info" style="background: #f3e5f5; padding: 15px; border-radius: 8px; margin: 15px 0;">
                Optimisation des positions atomiques (cellule fixe).
            </div>
            
            <div style="margin: 20px 0;">
                <h5>Étape 1: RELAX</h5>
                <p>• Sélectionnez <strong>Type de Calcul: RELAX</strong></p>
                <p>• Les paramètres de cellule resteront fixes</p>
                <button class="btn btn-primary" onclick="switchTab(0)" style="margin-top: 10px; padding: 10px 20px;">
                    → Aller à Génération Inputs
                </button>
            </div>
            
            <div style="margin: 20px 0;">
                <h5>Étape 2: SCF Final</h5>
                <p>• Après convergence, copiez les positions optimisées</p>
                <p>• Lancez un calcul SCF avec ces nouvelles positions</p>
            </div>
        `;
    } else if (type === 'bands-depuis-scf') {
        html = `
            <h4>📊 Workflow: Structure de Bandes</h4>
            <div class="alert alert-info" style="background: #fff3e0; padding: 15px; border-radius: 8px; margin: 15px 0;">
                Calcul des bandes électroniques à partir d'un SCF existant.
            </div>
            
            <div style="margin: 20px 0;">
                <h5>Prérequis</h5>
                <p>✅ Un calcul SCF déjà convergé</p>
                <p>✅ Les fichiers de charge dans le répertoire output/</p>
            </div>
            
            <div style="margin: 20px 0;">
                <h5>Étape 1: NSCF</h5>
                <p>• Utilisez les mêmes paramètres que le SCF</p>
                <p>• Augmentez le nombre de bandes (nbnd)</p>
            </div>
            
            <div style="margin: 20px 0;">
                <h5>Étape 2: BANDS</h5>
                <p>• Définissez le chemin k</p>
                <p>• Lancez le calcul de bandes</p>
            </div>
        `;
    }
    
    workflowContent.innerHTML = html;
    workflowGuide.style.display = 'block';
    workflowGuide.scrollIntoView({ behavior: 'smooth' });
}

/**
 * Afficher les détails des calculs
 */
function afficherDetailsCalculs() {
    if (!workflowData || !workflowData.fichiers) {
        alert('Aucun calcul en cours.');
        return;
    }
    
    console.log('📊 Détails workflow:', workflowData);
    
    let details = '📊 DÉTAILS DU WORKFLOW\n\n';
    details += `Étape actuelle: ${workflowData.etapeActuelle + 1}/${workflowData.etapes.length}\n\n`;
    
    for (const [etape, fichiers] of Object.entries(workflowData.fichiers)) {
        details += `${etape.toUpperCase()}:\n`;
        details += `  Input: ${fichiers.input || 'N/A'}\n`;
        details += `  Output: ${fichiers.output || 'N/A'}\n`;
        details += `  ID: ${fichiers.calcul_id || 'N/A'}\n\n`;
    }
    
    if (workflowData.parametresOptimises) {
        details += 'Paramètres optimisés:\n';
        details += `  alat: ${workflowData.parametresOptimises.alat?.toFixed(4) || 'N/A'} a.u.\n`;
        details += `  Positions: ${workflowData.parametresOptimises.positions?.length || 0} atomes\n`;
    }
    
    alert(details);
}

// ═══════════════════════════════════════════════════════════════════════════════
// MODE TERMINAL DIRECT - Génération de commandes à copier/coller
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Générer les commandes terminal pour un workflow complet
 */
function genererCommandesTerminal() {
    const inputPreview = document.getElementById('input_preview')?.value || '';
    
    if (!inputPreview.trim()) {
        alert('❌ Veuillez d\'abord générer un input dans l\'onglet "Génération Inputs"');
        return;
    }
    
    // Extraire le nom du matériau/prefix
    const prefixMatch = inputPreview.match(/prefix\s*=\s*['"]([^'"]+)['"]/);
    const prefix = prefixMatch ? prefixMatch[1] : 'calcul';
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 16);
    const baseFilename = `${prefix}_${timestamp}`;
    
    const commandes = `#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
# WORKFLOW QUANTUM ESPRESSO - ${prefix}
# Généré le: ${new Date().toLocaleString('fr-FR')}
# ═══════════════════════════════════════════════════════════════════════════════

# Configuration
QE_BIN="/home/hiadsi/q-e-qe-7.5/bin"
INPUTS="/home/hiadsi/Interface-QE_v1/inputs"
OUTPUTS="/home/hiadsi/Interface-QE_v1/outputs"
PSEUDO="/home/hiadsi/Interface-QE_v1/pseudos/PBE"

# Créer les répertoires
mkdir -p $INPUTS $OUTPUTS

# ═══════════════════════════════════════════════════════════════════════════════
# ÉTAPE 1: Sauvegarder l'input
# ═══════════════════════════════════════════════════════════════════════════════
cat > $INPUTS/${baseFilename}.in << 'EOF'
${inputPreview}
EOF

echo "✅ Input sauvegardé: $INPUTS/${baseFilename}.in"

# ═══════════════════════════════════════════════════════════════════════════════
# ÉTAPE 2: Lancer le calcul
# ═══════════════════════════════════════════════════════════════════════════════
echo "🚀 Lancement du calcul..."
cd $OUTPUTS
$QE_BIN/pw.x < $INPUTS/${baseFilename}.in > ${baseFilename}.out 2>&1

# Vérifier la convergence
if grep -q "JOB DONE" ${baseFilename}.out; then
    echo "✅ Calcul terminé avec succès!"
    grep "!" ${baseFilename}.out | tail -1
else
    echo "⚠️ Vérifiez le fichier output pour les erreurs"
fi

echo ""
echo "📁 Fichiers générés:"
echo "   Input:  $INPUTS/${baseFilename}.in"
echo "   Output: $OUTPUTS/${baseFilename}.out"
`;
    
    // Afficher dans une modale
    const modal = document.createElement('div');
    modal.id = 'modal_terminal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.9);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
    `;
    
    modal.innerHTML = `
        <div style="background: #1e1e1e; padding: 30px; border-radius: 10px; max-width: 900px; width: 95%; max-height: 90vh; overflow-y: auto; box-shadow: 0 0 30px rgba(0,255,0,0.3);">
            <h3 style="color: #4CAF50; margin-top: 0; display: flex; align-items: center; gap: 10px;">
                <span style="font-size: 1.5em;">💻</span>
                Mode Terminal - Commandes à Exécuter
            </h3>
            
            <div style="background: #2d2d2d; border: 1px solid #4CAF50; border-radius: 8px; padding: 20px; margin: 20px 0;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <span style="color: #888;">Script Bash - Copiez et exécutez dans un terminal</span>
                    <button onclick="copierCommandes()" style="background: #4CAF50; color: white; border: none; padding: 8px 16px; border-radius: 5px; cursor: pointer;">
                        📋 Copier tout
                    </button>
                </div>
                <pre id="commandes_terminal" style="color: #0f0; font-family: 'Monaco', 'Consolas', monospace; font-size: 13px; white-space: pre-wrap; word-break: break-all; margin: 0; max-height: 400px; overflow-y: auto;">${commandes.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>
            </div>
            
            <div style="background: #2d2d2d; border-radius: 8px; padding: 15px; margin: 20px 0;">
                <h4 style="color: #ff9800; margin: 0 0 10px 0;">⚡ Commande rapide (une ligne)</h4>
                <code style="color: #0f0; font-size: 14px; display: block; padding: 10px; background: #1a1a1a; border-radius: 5px;">
cd /home/hiadsi/Interface-QE_v1/outputs && /home/hiadsi/q-e-qe-7.5/bin/pw.x &lt; /home/hiadsi/génération_inputs-QE/inputs_générés_direct/${baseFilename}.in &gt; ${baseFilename}.out 2&gt;&amp;1 &amp;
                </code>
            </div>
            
            <div style="background: #1a3a1a; border: 1px solid #4CAF50; border-radius: 8px; padding: 15px; margin: 20px 0;">
                <h4 style="color: #4CAF50; margin: 0 0 10px 0;">💡 Instructions</h4>
                <ol style="color: #ccc; margin: 0; padding-left: 20px; line-height: 1.8;">
                    <li>Copiez le script ci-dessus</li>
                    <li>Ouvrez un terminal Linux</li>
                    <li>Collez et exécutez</li>
                    <li>Ou sauvegardez dans un fichier .sh et exécutez avec <code style="color: #0f0;">bash script.sh</code></li>
                </ol>
            </div>
            
            <div style="display: flex; gap: 15px; justify-content: flex-end; margin-top: 20px;">
                <button onclick="sauvegarderScript('${baseFilename}')" style="background: #2196F3; color: white; border: none; padding: 12px 24px; border-radius: 5px; cursor: pointer; font-size: 14px;">
                    💾 Sauvegarder en .sh
                </button>
                <button onclick="document.getElementById('modal_terminal').remove()" style="background: #666; color: white; border: none; padding: 12px 24px; border-radius: 5px; cursor: pointer; font-size: 14px;">
                    ✖ Fermer
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

/**
 * Copier les commandes dans le presse-papier
 */
function copierCommandes() {
    const pre = document.getElementById('commandes_terminal');
    if (pre) {
        const text = pre.textContent;
        navigator.clipboard.writeText(text).then(() => {
            alert('✅ Commandes copiées dans le presse-papier!\n\nCollez-les dans un terminal Linux.');
        }).catch(err => {
            // Fallback pour les navigateurs plus anciens
            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            alert('✅ Commandes copiées!');
        });
    }
}

/**
 * Sauvegarder le script dans un fichier
 */
async function sauvegarderScript(baseFilename) {
    const pre = document.getElementById('commandes_terminal');
    if (!pre) return;
    
    const content = pre.textContent;
    
    try {
        const response = await fetch(`${API_CALCULS}/api/sauvegarder_input`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                filename: `${baseFilename}.sh`,
                content: content
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert(`✅ Script sauvegardé!\n\n📁 ${result.chemin}\n\nExécutez avec:\nbash ${result.chemin}`);
        } else {
            throw new Error(result.error);
        }
    } catch (error) {
        // Télécharger directement
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${baseFilename}.sh`;
        a.click();
        URL.revokeObjectURL(url);
        alert('📥 Script téléchargé!');
    }
}

/**
 * Générer commandes pour workflow complet (VC-RELAX -> BANDS)
 */
function genererWorkflowCompletTerminal() {
    const inputPreview = document.getElementById('input_preview')?.value || '';
    
    if (!inputPreview.trim()) {
        alert('❌ Veuillez d\'abord générer un input dans l\'onglet "Génération Inputs"');
        return;
    }
    
    const prefixMatch = inputPreview.match(/prefix\s*=\s*['"]([^'"]+)['"]/);
    const prefix = prefixMatch ? prefixMatch[1] : 'calcul';
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 16);
    
    const script = `#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
# WORKFLOW COMPLET: VC-RELAX → SCF → NSCF → BANDS
# Matériau: ${prefix}
# Date: ${new Date().toLocaleString('fr-FR')}
# ═══════════════════════════════════════════════════════════════════════════════

set -e  # Arrêter si erreur

# Configuration
QE="/home/hiadsi/q-e-qe-7.5/bin"
INPUTS="/home/hiadsi/Interface-QE_v1/inputs"
OUTPUTS="/home/hiadsi/Interface-QE_v1/outputs"
PSEUDO="/home/hiadsi/Interface-QE_v1/pseudos/PBE"

PREFIX="${prefix}"
OUTDIR="$OUTPUTS/\${PREFIX}_workflow"

mkdir -p $OUTDIR
cd $OUTDIR

echo "═══════════════════════════════════════════════════════════════════"
echo "  🚀 WORKFLOW COMPLET - ${prefix}"
echo "═══════════════════════════════════════════════════════════════════"

# ═══════════════════════════════════════════════════════════════════════════════
# ÉTAPE 1: VC-RELAX
# ═══════════════════════════════════════════════════════════════════════════════
echo ""
echo "📍 ÉTAPE 1/4: VC-RELAX (Optimisation de la structure)"
echo "─────────────────────────────────────────────────────"

cat > vcrelax.in << 'VCRELAX_INPUT'
${inputPreview.replace(/calculation\s*=\s*['"][^'"]*['"]/, "calculation = 'vc-relax'")}
VCRELAX_INPUT

$QE/pw.x < vcrelax.in > vcrelax.out 2>&1

if grep -q "JOB DONE" vcrelax.out; then
    echo "✅ VC-RELAX terminé!"
    ENERGY=$(grep "!" vcrelax.out | tail -1)
    echo "   $ENERGY"
else
    echo "❌ Erreur VC-RELAX - vérifiez vcrelax.out"
    exit 1
fi

# ═══════════════════════════════════════════════════════════════════════════════
# ÉTAPE 2: SCF (avec structure optimisée)
# ═══════════════════════════════════════════════════════════════════════════════
echo ""
echo "📍 ÉTAPE 2/4: SCF (Calcul auto-cohérent)"
echo "─────────────────────────────────────────"

# Extraire les positions optimisées et créer input SCF
cat vcrelax.in | sed "s/calculation.*=.*'vc-relax'/calculation = 'scf'/" | \\
    sed '/&CELL/,/\\//d' > scf.in

$QE/pw.x < scf.in > scf.out 2>&1

if grep -q "JOB DONE" scf.out; then
    echo "✅ SCF terminé!"
else
    echo "❌ Erreur SCF"
    exit 1
fi

# ═══════════════════════════════════════════════════════════════════════════════
# ÉTAPE 3: NSCF (grille k dense)
# ═══════════════════════════════════════════════════════════════════════════════
echo ""
echo "📍 ÉTAPE 3/4: NSCF (Grille k dense)"
echo "────────────────────────────────────"

cat scf.in | sed "s/calculation.*=.*'scf'/calculation = 'nscf'/" | \\
    sed 's/K_POINTS automatic/K_POINTS automatic\\n12 12 12 0 0 0/' > nscf.in

$QE/pw.x < nscf.in > nscf.out 2>&1

if grep -q "JOB DONE" nscf.out; then
    echo "✅ NSCF terminé!"
else
    echo "❌ Erreur NSCF"
    exit 1
fi

# ═══════════════════════════════════════════════════════════════════════════════
# ÉTAPE 4: BANDS
# ═══════════════════════════════════════════════════════════════════════════════
echo ""
echo "📍 ÉTAPE 4/4: BANDS (Structure de bandes)"
echo "──────────────────────────────────────────"

cat scf.in | sed "s/calculation.*=.*'scf'/calculation = 'bands'/" | \\
    sed '/K_POINTS/,$d' > bands.in

# Ajouter k-path (FCC par défaut)
cat >> bands.in << 'KPATH'
K_POINTS crystal_b
5
0.0000 0.0000 0.0000 50  ! Gamma
0.5000 0.0000 0.5000 50  ! X
0.5000 0.2500 0.7500 50  ! W
0.0000 0.0000 0.0000 50  ! Gamma
0.5000 0.5000 0.5000 1   ! L
KPATH

$QE/pw.x < bands.in > bands.out 2>&1

if grep -q "JOB DONE" bands.out; then
    echo "✅ BANDS terminé!"
else
    echo "❌ Erreur BANDS"
    exit 1
fi

# ═══════════════════════════════════════════════════════════════════════════════
# POST-TRAITEMENT: bands.x
# ═══════════════════════════════════════════════════════════════════════════════
echo ""
echo "📊 Post-traitement..."

cat > bands_pp.in << BANDSPP
&BANDS
    prefix = '$PREFIX'
    outdir = './'
    filband = 'bands.dat'
/
BANDSPP

$QE/bands.x < bands_pp.in > bands_pp.out 2>&1

echo ""
echo "═══════════════════════════════════════════════════════════════════"
echo "  🎉 WORKFLOW TERMINÉ!"
echo "═══════════════════════════════════════════════════════════════════"
echo ""
echo "📁 Fichiers générés dans: $OUTDIR"
echo "   - vcrelax.out  (optimisation)"
echo "   - scf.out      (énergie)"
echo "   - nscf.out     (densité d'états)"
echo "   - bands.out    (bandes)"
echo "   - bands.dat    (données pour tracé)"
echo ""
`;
    
    // Afficher
    const modal = document.createElement('div');
    modal.id = 'modal_workflow_terminal';
    modal.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.9); display: flex; align-items: center;
        justify-content: center; z-index: 10000;
    `;
    
    modal.innerHTML = `
        <div style="background: #1e1e1e; padding: 30px; border-radius: 10px; max-width: 950px; width: 95%; max-height: 90vh; overflow-y: auto;">
            <h3 style="color: #ff9800; margin-top: 0;">
                🔥 Script Workflow Complet - Exécution Terminal
            </h3>
            <p style="color: #888; margin: 10px 0;">
                Ce script exécute automatiquement: VC-RELAX → SCF → NSCF → BANDS
            </p>
            
            <div style="background: #2d2d2d; border-radius: 8px; padding: 20px; margin: 20px 0;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                    <span style="color: #ff9800;">workflow_${prefix}.sh</span>
                    <button onclick="navigator.clipboard.writeText(document.getElementById('script_workflow').textContent); alert('✅ Copié!')" 
                            style="background: #ff9800; color: white; border: none; padding: 5px 15px; border-radius: 3px; cursor: pointer;">
                        📋 Copier
                    </button>
                </div>
                <pre id="script_workflow" style="color: #0f0; font-family: monospace; font-size: 12px; white-space: pre-wrap; max-height: 400px; overflow-y: auto; margin: 0;">${script.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>
            </div>
            
            <div style="background: #3a2a1a; border: 1px solid #ff9800; border-radius: 8px; padding: 15px;">
                <h4 style="color: #ff9800; margin: 0 0 10px 0;">⚡ Usage rapide</h4>
                <code style="color: #0f0; display: block; padding: 10px; background: #1a1a1a; border-radius: 5px;">
# Sauvegarder et exécuter:
cat > workflow.sh << 'EOF'
${script.substring(0, 100)}...
EOF
chmod +x workflow.sh && ./workflow.sh
                </code>
            </div>
            
            <div style="display: flex; gap: 15px; justify-content: flex-end; margin-top: 20px;">
                <button onclick="telechargerScript('workflow_${prefix}.sh', document.getElementById('script_workflow').textContent)" 
                        style="background: #4CAF50; color: white; border: none; padding: 12px 24px; border-radius: 5px; cursor: pointer;">
                    💾 Télécharger .sh
                </button>
                <button onclick="document.getElementById('modal_workflow_terminal').remove()" 
                        style="background: #666; color: white; border: none; padding: 12px 24px; border-radius: 5px; cursor: pointer;">
                    ✖ Fermer
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

/**
 * Télécharger un script
 */
function telechargerScript(filename, content) {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
}

// Exposer les fonctions globalement
window.lancerWorkflowBandesAuto = lancerWorkflowBandesAuto;
window.afficherResultatsWorkflow = afficherResultatsWorkflow;
window.afficherConfigWorkflowBandes = afficherConfigWorkflowBandes;
window.demarrerWorkflow = demarrerWorkflow;
window.arreterWorkflowAuto = arreterWorkflowAuto;
window.afficherDetailsCalculs = afficherDetailsCalculs;
window.verifierAPICalculs = verifierAPICalculs;
window.genererCommandesTerminal = genererCommandesTerminal;
window.genererWorkflowCompletTerminal = genererWorkflowCompletTerminal;
window.copierCommandes = copierCommandes;
window.sauvegarderScript = sauvegarderScript;
window.telechargerScript = telechargerScript;

// Initialisation
document.addEventListener('DOMContentLoaded', () => {
    console.log('✅ Script Calculs Guidés chargé (Mode Terminal disponible)');
    verifierAPICalculs();
});


// Script du tableau périodique complet
// Auteur: Prof S. Hiadsi USTO-MB

// Tableau périodique complet avec tous les éléments
const TABLEAU_PERIODIQUE = {
    // Période 1
    'H': { 
        nom: 'Hydrogène', 
        numero: 1, 
        masse: 1.008, 
        periode: 1, 
        groupe: 1,
        pseudo: 'H.pbe-rrkjus_psl.1.0.0.UPF', 
        valence: 1,
        type: 'non-metal'
    },
    'He': { 
        nom: 'Hélium', 
        numero: 2, 
        masse: 4.003, 
        periode: 1, 
        groupe: 18,
        pseudo: 'He.pbe-rrkjus_psl.1.0.0.UPF', 
        valence: 2,
        type: 'gaz-noble'
    },
    
    // Période 2
    'Li': { 
        nom: 'Lithium', 
        numero: 3, 
        masse: 6.941, 
        periode: 2, 
        groupe: 1,
        pseudo: 'Li.pbe-s-rrkjus_psl.1.0.0.UPF', 
        valence: 1,
        type: 'metal-alcalin'
    },
    'Be': { 
        nom: 'Béryllium', 
        numero: 4, 
        masse: 9.012, 
        periode: 2, 
        groupe: 2,
        pseudo: 'Be.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 2,
        type: 'metal-alcalino-terreux'
    },
    'B': { 
        nom: 'Bore', 
        numero: 5, 
        masse: 10.811, 
        periode: 2, 
        groupe: 13,
        pseudo: 'B.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'metalloid'
    },
    'C': { 
        nom: 'Carbone', 
        numero: 6, 
        masse: 12.011, 
        periode: 2, 
        groupe: 14,
        pseudo: 'C.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 4,
        type: 'non-metal'
    },
    'N': { 
        nom: 'Azote', 
        numero: 7, 
        masse: 14.007, 
        periode: 2, 
        groupe: 15,
        pseudo: 'N.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 5,
        type: 'non-metal'
    },
    'O': { 
        nom: 'Oxygène', 
        numero: 8, 
        masse: 15.999, 
        periode: 2, 
        groupe: 16,
        pseudo: 'O.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 6,
        type: 'non-metal'
    },
    'F': { 
        nom: 'Fluor', 
        numero: 9, 
        masse: 18.998, 
        periode: 2, 
        groupe: 17,
        pseudo: 'F.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 7,
        type: 'halogene'
    },
    'Ne': { 
        nom: 'Néon', 
        numero: 10, 
        masse: 20.180, 
        periode: 2, 
        groupe: 18,
        pseudo: 'Ne.pbe-rrkjus_psl.1.0.0.UPF', 
        valence: 8,
        type: 'gaz-noble'
    },
    
    // Période 3
    'Na': { 
        nom: 'Sodium', 
        numero: 11, 
        masse: 22.990, 
        periode: 3, 
        groupe: 1,
        pseudo: 'Na.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 1,
        type: 'metal-alcalin'
    },
    'Mg': { 
        nom: 'Magnésium', 
        numero: 12, 
        masse: 24.305, 
        periode: 3, 
        groupe: 2,
        pseudo: 'Mg.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 2,
        type: 'metal-alcalino-terreux'
    },
    'Al': { 
        nom: 'Aluminium', 
        numero: 13, 
        masse: 26.982, 
        periode: 3, 
        groupe: 13,
        pseudo: 'Al.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'metal'
    },
    'Si': { 
        nom: 'Silicium', 
        numero: 14, 
        masse: 28.085, 
        periode: 3, 
        groupe: 14,
        pseudo: 'Si.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 4,
        type: 'metalloid'
    },
    'P': { 
        nom: 'Phosphore', 
        numero: 15, 
        masse: 30.974, 
        periode: 3, 
        groupe: 15,
        pseudo: 'P.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 5,
        type: 'non-metal'
    },
    'S': { 
        nom: 'Soufre', 
        numero: 16, 
        masse: 32.065, 
        periode: 3, 
        groupe: 16,
        pseudo: 'S.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 6,
        type: 'non-metal'
    },
    'Cl': { 
        nom: 'Chlore', 
        numero: 17, 
        masse: 35.453, 
        periode: 3, 
        groupe: 17,
        pseudo: 'Cl.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 7,
        type: 'halogene'
    },
    'Ar': { 
        nom: 'Argon', 
        numero: 18, 
        masse: 39.948, 
        periode: 3, 
        groupe: 18,
        pseudo: 'Ar.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 8,
        type: 'gaz-noble'
    },
    
    // Période 4
    'K': { 
        nom: 'Potassium', 
        numero: 19, 
        masse: 39.098, 
        periode: 4, 
        groupe: 1,
        pseudo: 'K.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 1,
        type: 'metal-alcalin'
    },
    'Ca': { 
        nom: 'Calcium', 
        numero: 20, 
        masse: 40.078, 
        periode: 4, 
        groupe: 2,
        pseudo: 'Ca.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 2,
        type: 'metal-alcalino-terreux'
    },
    'Sc': { 
        nom: 'Scandium', 
        numero: 21, 
        masse: 44.956, 
        periode: 4, 
        groupe: 3,
        pseudo: 'Sc.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'metal-transition'
    },
    'Ti': { 
        nom: 'Titane', 
        numero: 22, 
        masse: 47.867, 
        periode: 4, 
        groupe: 4,
        pseudo: 'Ti.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 4,
        type: 'metal-transition'
    },
    'V': { 
        nom: 'Vanadium', 
        numero: 23, 
        masse: 50.942, 
        periode: 4, 
        groupe: 5,
        pseudo: 'V.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 5,
        type: 'metal-transition'
    },
    'Cr': { 
        nom: 'Chrome', 
        numero: 24, 
        masse: 51.996, 
        periode: 4, 
        groupe: 6,
        pseudo: 'Cr.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 6,
        type: 'metal-transition'
    },
    'Mn': { 
        nom: 'Manganèse', 
        numero: 25, 
        masse: 54.938, 
        periode: 4, 
        groupe: 7,
        pseudo: 'Mn.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 7,
        type: 'metal-transition'
    },
    'Fe': { 
        nom: 'Fer', 
        numero: 26, 
        masse: 55.845, 
        periode: 4, 
        groupe: 8,
        pseudo: 'Fe.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 8,
        type: 'metal-transition'
    },
    'Co': { 
        nom: 'Cobalt', 
        numero: 27, 
        masse: 58.933, 
        periode: 4, 
        groupe: 9,
        pseudo: 'Co.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 9,
        type: 'metal-transition'
    },
    'Ni': { 
        nom: 'Nickel', 
        numero: 28, 
        masse: 58.693, 
        periode: 4, 
        groupe: 10,
        pseudo: 'Ni.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 10,
        type: 'metal-transition'
    },
    'Cu': { 
        nom: 'Cuivre', 
        numero: 29, 
        masse: 63.546, 
        periode: 4, 
        groupe: 11,
        pseudo: 'Cu.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 11,
        type: 'metal-transition'
    },
    'Zn': { 
        nom: 'Zinc', 
        numero: 30, 
        masse: 65.380, 
        periode: 4, 
        groupe: 12,
        pseudo: 'Zn.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 12,
        type: 'metal-transition'
    },
    'Ga': { 
        nom: 'Gallium', 
        numero: 31, 
        masse: 69.723, 
        periode: 4, 
        groupe: 13,
        pseudo: 'Ga.pbe-dn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'metal'
    },
    'Ge': { 
        nom: 'Germanium', 
        numero: 32, 
        masse: 72.630, 
        periode: 4, 
        groupe: 14,
        pseudo: 'Ge.pbe-dn-rrkjus_psl.1.0.0.UPF', 
        valence: 4,
        type: 'metalloid'
    },
    'As': { 
        nom: 'Arsenic', 
        numero: 33, 
        masse: 74.922, 
        periode: 4, 
        groupe: 15,
        pseudo: 'As.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 5,
        type: 'metalloid'
    },
    'Se': { 
        nom: 'Sélénium', 
        numero: 34, 
        masse: 78.971, 
        periode: 4, 
        groupe: 16,
        pseudo: 'Se.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 6,
        type: 'non-metal'
    },
    'Br': { 
        nom: 'Brome', 
        numero: 35, 
        masse: 79.904, 
        periode: 4, 
        groupe: 17,
        pseudo: 'Br.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 7,
        type: 'halogene'
    },
    'Kr': { 
        nom: 'Krypton', 
        numero: 36, 
        masse: 83.798, 
        periode: 4, 
        groupe: 18,
        pseudo: 'Kr.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 8,
        type: 'gaz-noble'
    },
    
    // Période 5
    'Rb': { 
        nom: 'Rubidium', 
        numero: 37, 
        masse: 85.468, 
        periode: 5, 
        groupe: 1,
        pseudo: 'Rb.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 1,
        type: 'metal-alcalin'
    },
    'Sr': { 
        nom: 'Strontium', 
        numero: 38, 
        masse: 87.620, 
        periode: 5, 
        groupe: 2,
        pseudo: 'Sr.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 2,
        type: 'metal-alcalino-terreux'
    },
    'Y': { 
        nom: 'Yttrium', 
        numero: 39, 
        masse: 88.906, 
        periode: 5, 
        groupe: 3,
        pseudo: 'Y.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'metal-transition'
    },
    'Zr': { 
        nom: 'Zirconium', 
        numero: 40, 
        masse: 91.224, 
        periode: 5, 
        groupe: 4,
        pseudo: 'Zr.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 4,
        type: 'metal-transition'
    },
    'Nb': { 
        nom: 'Niobium', 
        numero: 41, 
        masse: 92.906, 
        periode: 5, 
        groupe: 5,
        pseudo: 'Nb.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 5,
        type: 'metal-transition'
    },
    'Mo': { 
        nom: 'Molybdène', 
        numero: 42, 
        masse: 95.960, 
        periode: 5, 
        groupe: 6,
        pseudo: 'Mo.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 6,
        type: 'metal-transition'
    },
    'Tc': { 
        nom: 'Technétium', 
        numero: 43, 
        masse: 98.000, 
        periode: 5, 
        groupe: 7,
        pseudo: 'Tc.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 7,
        type: 'metal-transition'
    },
    'Ru': { 
        nom: 'Ruthénium', 
        numero: 44, 
        masse: 101.070, 
        periode: 5, 
        groupe: 8,
        pseudo: 'Ru.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 8,
        type: 'metal-transition'
    },
    'Rh': { 
        nom: 'Rhodium', 
        numero: 45, 
        masse: 102.906, 
        periode: 5, 
        groupe: 9,
        pseudo: 'Rh.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 9,
        type: 'metal-transition'
    },
    'Pd': { 
        nom: 'Palladium', 
        numero: 46, 
        masse: 106.420, 
        periode: 5, 
        groupe: 10,
        pseudo: 'Pd.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 10,
        type: 'metal-transition'
    },
    'Ag': { 
        nom: 'Argent', 
        numero: 47, 
        masse: 107.868, 
        periode: 5, 
        groupe: 11,
        pseudo: 'Ag.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 11,
        type: 'metal-transition'
    },
    'Cd': { 
        nom: 'Cadmium', 
        numero: 48, 
        masse: 111.418, 
        periode: 5, 
        groupe: 12,
        pseudo: 'Cd.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 12,
        type: 'metal-transition'
    },
    'In': { 
        nom: 'Indium', 
        numero: 49, 
        masse: 114.818, 
        periode: 5, 
        groupe: 13,
        pseudo: 'In.pbe-dn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'metal'
    },
    'Sn': { 
        nom: 'Étain', 
        numero: 50, 
        masse: 118.711, 
        periode: 5, 
        groupe: 14,
        pseudo: 'Sn.pbe-dn-rrkjus_psl.1.0.0.UPF', 
        valence: 4,
        type: 'metal'
    },
    'Sb': { 
        nom: 'Antimoine', 
        numero: 51, 
        masse: 121.760, 
        periode: 5, 
        groupe: 15,
        pseudo: 'Sb.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 5,
        type: 'metalloid'
    },
    'Te': { 
        nom: 'Tellure', 
        numero: 52, 
        masse: 127.600, 
        periode: 5, 
        groupe: 16,
        pseudo: 'Te.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 6,
        type: 'metalloid'
    },
    'I': { 
        nom: 'Iode', 
        numero: 53, 
        masse: 126.904, 
        periode: 5, 
        groupe: 17,
        pseudo: 'I.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 7,
        type: 'halogene'
    },
    'Xe': { 
        nom: 'Xénon', 
        numero: 54, 
        masse: 131.293, 
        periode: 5, 
        groupe: 18,
        pseudo: 'Xe.pbe-n-rrkjus_psl.1.0.0.UPF', 
        valence: 8,
        type: 'gaz-noble'
    },
    
    // Période 6
    'Cs': { 
        nom: 'Césium', 
        numero: 55, 
        masse: 132.905, 
        periode: 6, 
        groupe: 1,
        pseudo: 'Cs.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 1,
        type: 'metal-alcalin'
    },
    'Ba': { 
        nom: 'Baryum', 
        numero: 56, 
        masse: 137.327, 
        periode: 6, 
        groupe: 2,
        pseudo: 'Ba.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 2,
        type: 'metal-alcalino-terreux'
    },
    
    // Lanthanides
    'La': { 
        nom: 'Lanthane', 
        numero: 57, 
        masse: 138.905, 
        periode: 6, 
        groupe: 3,
        pseudo: 'La.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'lanthanide'
    },
    'Ce': { 
        nom: 'Cérium', 
        numero: 58, 
        masse: 140.116, 
        periode: 6, 
        groupe: 3,
        pseudo: 'Ce.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 4,
        type: 'lanthanide'
    },
    'Pr': { 
        nom: 'Praseodyme', 
        numero: 59, 
        masse: 140.908, 
        periode: 6, 
        groupe: 3,
        pseudo: 'Pr.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'lanthanide'
    },
    'Nd': { 
        nom: 'Néodyme', 
        numero: 60, 
        masse: 144.242, 
        periode: 6, 
        groupe: 3,
        pseudo: 'Nd.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'lanthanide'
    },
    'Pm': { 
        nom: 'Prométhium', 
        numero: 61, 
        masse: 145.000, 
        periode: 6, 
        groupe: 3,
        pseudo: 'Pm.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'lanthanide'
    },
    'Sm': { 
        nom: 'Samarium', 
        numero: 62, 
        masse: 150.360, 
        periode: 6, 
        groupe: 3,
        pseudo: 'Sm.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'lanthanide'
    },
    'Eu': { 
        nom: 'Europium', 
        numero: 63, 
        masse: 151.964, 
        periode: 6, 
        groupe: 3,
        pseudo: 'Eu.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'lanthanide'
    },
    'Gd': { 
        nom: 'Gadolinium', 
        numero: 64, 
        masse: 157.250, 
        periode: 6, 
        groupe: 3,
        pseudo: 'Gd.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'lanthanide'
    },
    'Tb': { 
        nom: 'Terbium', 
        numero: 65, 
        masse: 158.925, 
        periode: 6, 
        groupe: 3,
        pseudo: 'Tb.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'lanthanide'
    },
    'Dy': { 
        nom: 'Dysprosium', 
        numero: 66, 
        masse: 162.500, 
        periode: 6, 
        groupe: 3,
        pseudo: 'Dy.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'lanthanide'
    },
    'Ho': { 
        nom: 'Holmium', 
        numero: 67, 
        masse: 164.930, 
        periode: 6, 
        groupe: 3,
        pseudo: 'Ho.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'lanthanide'
    },
    'Er': { 
        nom: 'Erbium', 
        numero: 68, 
        masse: 167.259, 
        periode: 6, 
        groupe: 3,
        pseudo: 'Er.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'lanthanide'
    },
    'Tm': { 
        nom: 'Thulium', 
        numero: 69, 
        masse: 168.934, 
        periode: 6, 
        groupe: 3,
        pseudo: 'Tm.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'lanthanide'
    },
    'Yb': { 
        nom: 'Ytterbium', 
        numero: 70, 
        masse: 173.054, 
        periode: 6, 
        groupe: 3,
        pseudo: 'Yb.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'lanthanide'
    },
    'Lu': { 
        nom: 'Lutétium', 
        numero: 71, 
        masse: 174.967, 
        periode: 6, 
        groupe: 3,
        pseudo: 'Lu.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'lanthanide'
    },
    
    // Suite période 6
    'Hf': { 
        nom: 'Hafnium', 
        numero: 72, 
        masse: 178.490, 
        periode: 6, 
        groupe: 4,
        pseudo: 'Hf.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 4,
        type: 'metal-transition'
    },
    'Ta': { 
        nom: 'Tantale', 
        numero: 73, 
        masse: 180.948, 
        periode: 6, 
        groupe: 5,
        pseudo: 'Ta.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 5,
        type: 'metal-transition'
    },
    'W': { 
        nom: 'Tungstène', 
        numero: 74, 
        masse: 183.840, 
        periode: 6, 
        groupe: 6,
        pseudo: 'W.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 6,
        type: 'metal-transition'
    },
    'Re': { 
        nom: 'Rhénium', 
        numero: 75, 
        masse: 186.207, 
        periode: 6, 
        groupe: 7,
        pseudo: 'Re.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 7,
        type: 'metal-transition'
    },
    'Os': { 
        nom: 'Osmium', 
        numero: 76, 
        masse: 190.230, 
        periode: 6, 
        groupe: 8,
        pseudo: 'Os.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 8,
        type: 'metal-transition'
    },
    'Ir': { 
        nom: 'Iridium', 
        numero: 77, 
        masse: 192.217, 
        periode: 6, 
        groupe: 9,
        pseudo: 'Ir.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 9,
        type: 'metal-transition'
    },
    'Pt': { 
        nom: 'Platine', 
        numero: 78, 
        masse: 195.084, 
        periode: 6, 
        groupe: 10,
        pseudo: 'Pt.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 10,
        type: 'metal-transition'
    },
    'Au': { 
        nom: 'Or', 
        numero: 79, 
        masse: 196.967, 
        periode: 6, 
        groupe: 11,
        pseudo: 'Au.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 11,
        type: 'metal-transition'
    },
    'Hg': { 
        nom: 'Mercure', 
        numero: 80, 
        masse: 200.590, 
        periode: 6, 
        groupe: 12,
        pseudo: 'Hg.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 12,
        type: 'metal-transition'
    },
    'Tl': { 
        nom: 'Thallium', 
        numero: 81, 
        masse: 204.383, 
        periode: 6, 
        groupe: 13,
        pseudo: 'Tl.pbe-dn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'metal'
    },
    'Pb': { 
        nom: 'Plomb', 
        numero: 82, 
        masse: 207.200, 
        periode: 6, 
        groupe: 14,
        pseudo: 'Pb.pbe-dn-rrkjus_psl.1.0.0.UPF', 
        valence: 4,
        type: 'metal'
    },
    'Bi': { 
        nom: 'Bismuth', 
        numero: 83, 
        masse: 208.980, 
        periode: 6, 
        groupe: 15,
        pseudo: 'Bi.pbe-dn-rrkjus_psl.1.0.0.UPF', 
        valence: 5,
        type: 'metal'
    },
    'Po': { 
        nom: 'Polonium', 
        numero: 84, 
        masse: 209.000, 
        periode: 6, 
        groupe: 16,
        pseudo: 'Po.pbe-dn-rrkjus_psl.1.0.0.UPF', 
        valence: 6,
        type: 'metalloid'
    },
    'At': { 
        nom: 'Astate', 
        numero: 85, 
        masse: 210.000, 
        periode: 6, 
        groupe: 17,
        pseudo: 'At.pbe-dn-rrkjus_psl.1.0.0.UPF', 
        valence: 7,
        type: 'halogene'
    },
    'Rn': { 
        nom: 'Radon', 
        numero: 86, 
        masse: 222.000, 
        periode: 6, 
        groupe: 18,
        pseudo: 'Rn.pbe-dn-rrkjus_psl.1.0.0.UPF', 
        valence: 8,
        type: 'gaz-noble'
    },
    
    // Période 7
    'Fr': { 
        nom: 'Francium', 
        numero: 87, 
        masse: 223.000, 
        periode: 7, 
        groupe: 1,
        pseudo: 'Fr.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 1,
        type: 'metal-alcalin'
    },
    'Ra': { 
        nom: 'Radium', 
        numero: 88, 
        masse: 226.000, 
        periode: 7, 
        groupe: 2,
        pseudo: 'Ra.pbe-spn-rrkjus_psl.1.0.0.UPF', 
        valence: 2,
        type: 'metal-alcalino-terreux'
    },
    
    // Actinides (Période 7)
    'Ac': { 
        nom: 'Actinium', 
        numero: 89, 
        masse: 227.000, 
        periode: 7, 
        groupe: 3,
        pseudo: 'Ac.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'actinide'
    },
    'Th': { 
        nom: 'Thorium', 
        numero: 90, 
        masse: 232.038, 
        periode: 7, 
        groupe: 3,
        pseudo: 'Th.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 4,
        type: 'actinide'
    },
    'Pa': { 
        nom: 'Protactinium', 
        numero: 91, 
        masse: 231.036, 
        periode: 7, 
        groupe: 3,
        pseudo: 'Pa.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 5,
        type: 'actinide'
    },
    'U': { 
        nom: 'Uranium', 
        numero: 92, 
        masse: 238.029, 
        periode: 7, 
        groupe: 3,
        pseudo: 'U.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 6,
        type: 'actinide'
    },
    'Np': { 
        nom: 'Neptunium', 
        numero: 93, 
        masse: 237.000, 
        periode: 7, 
        groupe: 3,
        pseudo: 'Np.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 7,
        type: 'actinide'
    },
    'Pu': { 
        nom: 'Plutonium', 
        numero: 94, 
        masse: 244.000, 
        periode: 7, 
        groupe: 3,
        pseudo: 'Pu.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 6,
        type: 'actinide'
    },
    'Am': { 
        nom: 'Américium', 
        numero: 95, 
        masse: 243.000, 
        periode: 7, 
        groupe: 3,
        pseudo: 'Am.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 7,
        type: 'actinide'
    },
    'Cm': { 
        nom: 'Curium', 
        numero: 96, 
        masse: 247.000, 
        periode: 7, 
        groupe: 3,
        pseudo: 'Cm.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 8,
        type: 'actinide'
    },
    'Bk': { 
        nom: 'Berkélium', 
        numero: 97, 
        masse: 247.000, 
        periode: 7, 
        groupe: 3,
        pseudo: 'Bk.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 9,
        type: 'actinide'
    },
    'Cf': { 
        nom: 'Californium', 
        numero: 98, 
        masse: 251.000, 
        periode: 7, 
        groupe: 3,
        pseudo: 'Cf.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 10,
        type: 'actinide'
    },
    'Es': { 
        nom: 'Einsteinium', 
        numero: 99, 
        masse: 252.000, 
        periode: 7, 
        groupe: 3,
        pseudo: 'Es.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 11,
        type: 'actinide'
    },
    'Fm': { 
        nom: 'Fermium', 
        numero: 100, 
        masse: 257.000, 
        periode: 7, 
        groupe: 3,
        pseudo: 'Fm.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 12,
        type: 'actinide'
    },
    'Md': { 
        nom: 'Mendélévium', 
        numero: 101, 
        masse: 258.000, 
        periode: 7, 
        groupe: 3,
        pseudo: 'Md.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 13,
        type: 'actinide'
    },
    'No': { 
        nom: 'Nobélium', 
        numero: 102, 
        masse: 259.000, 
        periode: 7, 
        groupe: 3,
        pseudo: 'No.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 14,
        type: 'actinide'
    },
    'Lr': { 
        nom: 'Lawrencium', 
        numero: 103, 
        masse: 262.000, 
        periode: 7, 
        groupe: 3,
        pseudo: 'Lr.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'actinide'
    },
    
    // Suite période 7 - Éléments super-lourds
    'Rf': { 
        nom: 'Rutherfordium', 
        numero: 104, 
        masse: 267.000, 
        periode: 7, 
        groupe: 4,
        pseudo: 'Rf.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 4,
        type: 'metal-transition'
    },
    'Db': { 
        nom: 'Dubnium', 
        numero: 105, 
        masse: 270.000, 
        periode: 7, 
        groupe: 5,
        pseudo: 'Db.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 5,
        type: 'metal-transition'
    },
    'Sg': { 
        nom: 'Seaborgium', 
        numero: 106, 
        masse: 271.000, 
        periode: 7, 
        groupe: 6,
        pseudo: 'Sg.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 6,
        type: 'metal-transition'
    },
    'Bh': { 
        nom: 'Bohrium', 
        numero: 107, 
        masse: 270.000, 
        periode: 7, 
        groupe: 7,
        pseudo: 'Bh.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 7,
        type: 'metal-transition'
    },
    'Hs': { 
        nom: 'Hassium', 
        numero: 108, 
        masse: 277.000, 
        periode: 7, 
        groupe: 8,
        pseudo: 'Hs.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 8,
        type: 'metal-transition'
    },
    'Mt': { 
        nom: 'Meitnérium', 
        numero: 109, 
        masse: 276.000, 
        periode: 7, 
        groupe: 9,
        pseudo: 'Mt.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 9,
        type: 'metal-transition'
    },
    'Ds': { 
        nom: 'Darmstadtium', 
        numero: 110, 
        masse: 281.000, 
        periode: 7, 
        groupe: 10,
        pseudo: 'Ds.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 10,
        type: 'metal-transition'
    },
    'Rg': { 
        nom: 'Roentgenium', 
        numero: 111, 
        masse: 280.000, 
        periode: 7, 
        groupe: 11,
        pseudo: 'Rg.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 11,
        type: 'metal-transition'
    },
    'Cn': { 
        nom: 'Copernicium', 
        numero: 112, 
        masse: 285.000, 
        periode: 7, 
        groupe: 12,
        pseudo: 'Cn.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 12,
        type: 'metal-transition'
    },
    'Nh': { 
        nom: 'Nihonium', 
        numero: 113, 
        masse: 284.000, 
        periode: 7, 
        groupe: 13,
        pseudo: 'Nh.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 3,
        type: 'metal'
    },
    'Fl': { 
        nom: 'Flérovium', 
        numero: 114, 
        masse: 289.000, 
        periode: 7, 
        groupe: 14,
        pseudo: 'Fl.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 4,
        type: 'metal'
    },
    'Mc': { 
        nom: 'Moscovium', 
        numero: 115, 
        masse: 288.000, 
        periode: 7, 
        groupe: 15,
        pseudo: 'Mc.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 5,
        type: 'metal'
    },
    'Lv': { 
        nom: 'Livermorium', 
        numero: 116, 
        masse: 293.000, 
        periode: 7, 
        groupe: 16,
        pseudo: 'Lv.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 6,
        type: 'metal'
    },
    'Ts': { 
        nom: 'Tennesse', 
        numero: 117, 
        masse: 294.000, 
        periode: 7, 
        groupe: 17,
        pseudo: 'Ts.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 7,
        type: 'halogene'
    },
    'Og': { 
        nom: 'Oganesson', 
        numero: 118, 
        masse: 294.000, 
        periode: 7, 
        groupe: 18,
        pseudo: 'Og.pbe-spfn-rrkjus_psl.1.0.0.UPF', 
        valence: 8,
        type: 'gaz-noble'
    }
};

// Fonction d'analyse basée sur le tableau périodique
function analyserMateriauTableauPeriodique(materiau) {
    console.log('🔬 Analyse basée sur le tableau périodique:', materiau);
    
    // Nettoyer et convertir en majuscules
    const materialClean = materiau.toString().trim().toUpperCase();
    
    // Expression régulière pour capturer les éléments chimiques
    // ([A-Z][a-z]?) capture le symbole de l'élément
    // (\d*) capture optionnellement le nombre
    const elementRegex = /([A-Z][a-z]?)(\d*)/g;
    
    const elementsFound = [];
    let match;
    
    console.log('📊 Matériau à analyser:', materialClean);
    
    // Analyser avec l'expression régulière
    while ((match = elementRegex.exec(materialClean)) !== null) {
        const elementSymbol = match[1];
        const count = match[2] ? parseInt(match[2]) : 1;
        
        console.log(`🔍 Élément trouvé: ${elementSymbol}, Quantité: ${count}`);
        
        // Vérifier si l'élément existe dans le tableau périodique
        if (TABLEAU_PERIODIQUE[elementSymbol]) {
            const elementData = TABLEAU_PERIODIQUE[elementSymbol];
            
            // Vérifier si l'élément n'est pas déjà dans la liste
            const existingElement = elementsFound.find(el => el.symbol === elementSymbol);
            if (existingElement) {
                existingElement.count += count;
            } else {
                elementsFound.push({
                    symbol: elementSymbol,
                    nom: elementData.nom,
                    numero: elementData.numero,
                    masse: elementData.masse,
                    periode: elementData.periode,
                    groupe: elementData.groupe,
                    pseudo: elementData.pseudo,
                    valence: elementData.valence,
                    type: elementData.type,
                    count: count
                });
            }
        } else {
            console.warn(`⚠️ Élément inconnu dans le tableau périodique: ${elementSymbol}`);
        }
    }
    
    // Trier les éléments par numéro atomique
    elementsFound.sort((a, b) => a.numero - b.numero);
    
    console.log('✅ Éléments finaux trouvés:', elementsFound);
    
    return elementsFound;
}

// Fonction pour obtenir les informations d'un élément
window.obtenirInfoElement = function(symbole) {
    const element = TABLEAU_PERIODIQUE[symbole];
    if (element) {
        return {
            symbole: symbole,
            nom: element.nom,
            numero: element.numero,
            masse: element.masse,
            periode: element.periode,
            groupe: element.groupe,
            pseudo: element.pseudo,
            valence: element.valence,
            type: element.type
        };
    }
    return null;
};

// Fonction pour lister tous les éléments d'un type
window.listerElementsParType = function(type) {
    const elements = [];
    for (const [symbole, data] of Object.entries(TABLEAU_PERIODIQUE)) {
        if (data.type === type) {
            elements.push({
                symbole: symbole,
                nom: data.nom,
                numero: data.numero,
                masse: data.masse,
                pseudo: data.pseudo
            });
        }
    }
    return elements.sort((a, b) => a.numero - b.numero);
};

// Fonction pour tester l'analyse avec le tableau périodique
window.testerAnalyseTableauPeriodique = function() {
    console.log('🧪 Test de l\'analyse avec le tableau périodique...');
    
    const materiaux = [
        'PrFeO3',
        'BaFeO3', 
        'BaTiO3',
        'GaN',
        'Si',
        'Al2O3',
        'MgO',
        'LiFePO4',
        'YBa2Cu3O7',
        'CaTiO3',
        'SrTiO3',
        'LaAlO3'
    ];
    
    const results = [];
    
    materiaux.forEach(materiau => {
        console.log(`🔍 Test de ${materiau}...`);
        const elements = analyserMateriauTableauPeriodique(materiau);
        
        results.push({
            materiau: materiau,
            elements: elements,
            nombreElements: elements.length,
            symbolesDetectes: elements.map(el => el.symbol).join(', '),
            nomsElements: elements.map(el => el.nom).join(', ')
        });
    });
    
    console.log('📊 Résultats des tests:', results);
    
    // Afficher les résultats dans l'interface
    const resultsDiv = document.getElementById('results');
    if (resultsDiv) {
        resultsDiv.innerHTML = `
            <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin: 20px 0; border: 1px solid #dee2e6;">
                <h4 style="margin: 0 0 15px 0; color: #495057;">🔬 Test d'Analyse avec le Tableau Périodique</h4>
                
                <div style="background: #e7f3ff; padding: 15px; border-radius: 8px; margin: 10px 0;">
                    <h5>📊 Résultats des Tests</h5>
                    <p><strong>Matériaux testés:</strong> ${results.length}</p>
                    <p><strong>Éléments du tableau périodique:</strong> ${Object.keys(TABLEAU_PERIODIQUE).length}</p>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 15px;">
                    ${results.map(result => `
                        <div style="background: white; padding: 15px; border-radius: 8px; border: 1px solid #ddd;">
                            <h6 style="margin: 0 0 10px 0; color: #007bff;">${result.materiau}</h6>
                            <p style="margin: 2px 0; font-size: 12px;"><strong>Éléments:</strong> ${result.symbolesDetectes}</p>
                            <p style="margin: 2px 0; font-size: 12px;"><strong>Noms:</strong> ${result.nomsElements}</p>
                            <p style="margin: 2px 0; font-size: 12px;"><strong>Nombre:</strong> ${result.nombreElements}</p>
                            <div style="margin-top: 8px;">
                                ${result.elements.map(el => `
                                    <span style="display: inline-block; background: #e7f3ff; padding: 2px 6px; margin: 2px; border-radius: 3px; font-size: 10px;">
                                        ${el.symbol} (${el.nom})
                                    </span>
                                `).join('')}
                            </div>
                        </div>
                    `).join('')}
                </div>
                
                <div style="background: #e7f3ff; padding: 15px; border-radius: 8px; margin: 10px 0;">
                    <h5>🎯 Actions</h5>
                    <button onclick="testerAnalyseTableauPeriodique()" style="margin: 5px; padding: 10px 15px; background: #17a2b8; color: white; border: none; border-radius: 5px; cursor: pointer;">🔄 Retester</button>
                    <button onclick="appliquerAnalyseTableauPeriodique()" style="margin: 5px; padding: 10px 15px; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer;">✅ Appliquer</button>
                    <button onclick="afficherTableauPeriodique()" style="margin: 5px; padding: 10px 15px; background: #6f42c1; color: white; border: none; border-radius: 5px; cursor: pointer;">📋 Voir Tableau</button>
                </div>
            </div>
        `;
    }
    
    return results;
};

// Fonction pour appliquer l'analyse basée sur le tableau périodique
window.appliquerAnalyseTableauPeriodique = function() {
    console.log('🔄 Application de l\'analyse basée sur le tableau périodique...');
    
    // Sauvegarder l'ancienne fonction
    if (typeof window.analyserMateriau !== 'undefined') {
        window.analyserMateriauOriginal = window.analyserMateriau;
        console.log('💾 Ancienne fonction sauvegardée');
    }
    
    // Remplacer par la nouvelle fonction
    window.analyserMateriau = analyserMateriauTableauPeriodique;
    window.analyserMateriauCorrige = analyserMateriauTableauPeriodique;
    console.log('✅ Fonction remplacée par l\'analyse du tableau périodique');
    
    // Test immédiat
    const testResult = analyserMateriau('PrFeO3');
    console.log('🧪 Test immédiat PrFeO3:', testResult);
    
    // Afficher confirmation
    const resultsDiv = document.getElementById('results');
    if (resultsDiv) {
        resultsDiv.innerHTML = `
            <div style="background: #d4edda; padding: 20px; border-radius: 10px; margin: 20px 0; border: 1px solid #c3e6cb;">
                <h4 style="margin: 0 0 15px 0; color: #155724;">🔬 Analyse du Tableau Périodique Appliquée</h4>
                
                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 10px 0;">
                    <h5>🔄 Changements Effectués</h5>
                    <p>✅ Fonction <code>analyserMateriau</code> remplacée par l'analyse du tableau périodique</p>
                    <p>✅ Fonction <code>analyserMateriauCorrige</code> également mise à jour</p>
                    <p>✅ ${Object.keys(TABLEAU_PERIODIQUE).length} éléments disponibles dans le tableau périodique</p>
                    <p>✅ Test immédiat: PrFeO3 → ${testResult.map(el => `${el.symbol} (${el.nom})`).join(', ')}</p>
                </div>
                
                <div style="background: #e7f3ff; padding: 15px; border-radius: 8px; margin: 10px 0;">
                    <h5>🎯 Test Immédiat</h5>
                    <p>La génération d'inputs utilisera maintenant le tableau périodique complet :</p>
                    <button onclick="genererInputsDynamiques()" style="margin: 5px; padding: 10px 15px; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer;">⚡ Générer Input PrFeO3</button>
                    <button onclick="testerAnalyseTableauPeriodique()" style="margin: 5px; padding: 10px 15px; background: #17a2b8; color: white; border: none; border-radius: 5px; cursor: pointer;">🧪 Tester Analyse</button>
                </div>
            </div>
        `;
    }
    
    return true;
};

// Fonction pour afficher le tableau périodique
window.afficherTableauPeriodique = function() {
    console.log('📋 Affichage du tableau périodique...');
    
    // Grouper les éléments par type
    const elementsParType = {};
    for (const [symbole, data] of Object.entries(TABLEAU_PERIODIQUE)) {
        if (!elementsParType[data.type]) {
            elementsParType[data.type] = [];
        }
        elementsParType[data.type].push({ symbole, ...data });
    }
    
    // Couleurs par type
    const couleurs = {
        'non-metal': '#ff6b6b',
        'metal': '#4ecdc4',
        'metalloid': '#45b7d1',
        'gaz-noble': '#96ceb4',
        'halogene': '#feca57',
        'metal-alcalin': '#ff9ff3',
        'metal-alcalino-terreux': '#54a0ff',
        'metal-transition': '#5f27cd',
        'lanthanide': '#00d2d3',
        'actinide': '#ff6348'
    };
    
    const resultsDiv = document.getElementById('results');
    if (resultsDiv) {
        resultsDiv.innerHTML = `
            <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin: 20px 0; border: 1px solid #dee2e6;">
                <h4 style="margin: 0 0 15px 0; color: #495057;">📋 Tableau Périodique des Éléments</h4>
                
                <div style="background: #e7f3ff; padding: 15px; border-radius: 8px; margin: 10px 0;">
                    <h5>📊 Statistiques</h5>
                    <p><strong>Total des éléments:</strong> ${Object.keys(TABLEAU_PERIODIQUE).length}</p>
                    <p><strong>Types d'éléments:</strong> ${Object.keys(elementsParType).length}</p>
                </div>
                
                ${Object.entries(elementsParType).map(([type, elements]) => `
                    <div style="background: white; padding: 15px; border-radius: 8px; margin: 10px 0; border-left: 4px solid ${couleurs[type] || '#6c757d'};">
                        <h6 style="margin: 0 0 10px 0; color: ${couleurs[type] || '#6c757d'}; text-transform: capitalize;">
                            ${type.replace('-', ' ')} (${elements.length} éléments)
                        </h6>
                        <div style="display: flex; flex-wrap: wrap; gap: 5px;">
                            ${elements.sort((a, b) => a.numero - b.numero).map(el => `
                                <span style="display: inline-block; background: ${couleurs[type] || '#6c757d'}; color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px; cursor: pointer;" 
                                      title="${el.nom} (${el.numero}) - ${el.masse} u" 
                                      onclick="obtenirInfoElement('${el.symbole}')">
                                    ${el.symbole}
                                </span>
                            `).join('')}
                        </div>
                    </div>
                `).join('')}
                
                <div style="background: #e7f3ff; padding: 15px; border-radius: 8px; margin: 10px 0;">
                    <h5>🎯 Actions</h5>
                    <button onclick="testerAnalyseTableauPeriodique()" style="margin: 5px; padding: 10px 15px; background: #17a2b8; color: white; border: none; border-radius: 5px; cursor: pointer;">🧪 Tester Analyse</button>
                    <button onclick="appliquerAnalyseTableauPeriodique()" style="margin: 5px; padding: 10px 15px; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer;">✅ Appliquer</button>
                </div>
            </div>
        `;
    }
};

// ================================================================
// GESTION DES PSEUDOPOTENTIELS - API NATIVE (PORT 5007)
// ================================================================

const API_PSEUDO_BASE = 'http://localhost:5007/api/pseudos';
const PSEUDO_DIR_PATH = '/home/hiadsi/Interface-QE_v1/pseudos/PBE';

// Fonction pour télécharger un pseudopotentiel
window.telechargerPseudo = async function(element, filename) {
    console.log(`📥 Téléchargement du pseudo pour ${element}: ${filename}`);
    
    try {
        // Afficher un loader
        const infoDiv = document.getElementById('element_details');
        if (infoDiv) {
            const oldContent = infoDiv.innerHTML;
            infoDiv.innerHTML += `
                <div id="pseudo_loader" style="background: #fff3cd; padding: 10px; border-radius: 5px; margin-top: 10px;">
                    ⏳ Téléchargement en cours...
                </div>
            `;
        }
        
        const response = await fetch(`${API_PSEUDO_BASE}/telecharger`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                filename: filename,
                element: element 
            })
        });
        
        const data = await response.json();
        
        // Supprimer le loader
        const loader = document.getElementById('pseudo_loader');
        if (loader) loader.remove();
        
        if (data.success) {
            if (data.already_exists) {
                alert(`✅ Le pseudopotentiel ${filename} est déjà présent.`);
            } else {
                alert(`✅ Pseudopotentiel téléchargé avec succès!\n\nFichier: ${filename}\nTaille: ${(data.size / 1024).toFixed(2)} KB`);
            }
            
            // Rafraîchir l'affichage de l'élément
            if (TABLEAU_PERIODIQUE[element]) {
                afficherElementInfo(element, TABLEAU_PERIODIQUE[element]);
            }
        } else {
            alert(`❌ Erreur de téléchargement:\n${data.message}`);
        }
        
    } catch (error) {
        console.error('❌ Erreur téléchargement pseudo:', error);
        const loader = document.getElementById('pseudo_loader');
        if (loader) loader.remove();
        alert(`❌ Erreur de connexion à l'API:\n${error.message}\n\nVérifiez que l'API est lancée sur le port 5007.`);
    }
};

// Fonction pour supprimer un pseudopotentiel
window.supprimerPseudo = async function(filename) {
    console.log(`🗑️ Suppression du pseudo: ${filename}`);
    
    if (!confirm(`Voulez-vous vraiment supprimer le pseudopotentiel ${filename} ?`)) {
        return;
    }
    
    try {
        const response = await fetch(`${API_PSEUDO_BASE}/supprimer/${filename}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert(`✅ Pseudopotentiel supprimé: ${filename}`);
            
            // Rafraîchir l'affichage
            const element = filename.split('.')[0];
            if (TABLEAU_PERIODIQUE[element]) {
                afficherElementInfo(element, TABLEAU_PERIODIQUE[element]);
            }
        } else {
            alert(`❌ Erreur: ${data.message}`);
        }
        
    } catch (error) {
        console.error('❌ Erreur suppression pseudo:', error);
        alert(`❌ Erreur de connexion à l'API:\n${error.message}`);
    }
};

// Fonction pour voir les informations d'un pseudopotentiel
window.voirPseudo = async function(filename) {
    console.log(`📂 Lecture du pseudo: ${filename}`);
    
    try {
        const response = await fetch(`${API_PSEUDO_BASE}/info/${filename}`);
        const data = await response.json();
        
        if (data.success) {
            let infoHtml = `
                <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 10000; max-width: 600px; box-shadow: 0 4px 20px rgba(0,0,0,0.3);">
                    <h3 style="margin-top: 0;">📄 ${filename}</h3>
                    <table style="width: 100%; border-collapse: collapse;">
                        <tr><td style="padding: 5px; border-bottom: 1px solid #ddd;"><strong>Élément:</strong></td><td>${data.element_name || data.element}</td></tr>
                        <tr><td style="padding: 5px; border-bottom: 1px solid #ddd;"><strong>Format:</strong></td><td>${data.format || 'UPF'}</td></tr>
                        ${data.z_valence ? `<tr><td style="padding: 5px; border-bottom: 1px solid #ddd;"><strong>Électrons de valence:</strong></td><td>${data.z_valence}</td></tr>` : ''}
                        ${data.functional ? `<tr><td style="padding: 5px; border-bottom: 1px solid #ddd;"><strong>Fonctionnelle:</strong></td><td>${data.functional}</td></tr>` : ''}
                        ${data.pseudo_type ? `<tr><td style="padding: 5px; border-bottom: 1px solid #ddd;"><strong>Type:</strong></td><td>${data.pseudo_type}</td></tr>` : ''}
                        ${data.is_ultrasoft !== undefined ? `<tr><td style="padding: 5px; border-bottom: 1px solid #ddd;"><strong>Ultrasoft:</strong></td><td>${data.is_ultrasoft ? 'Oui' : 'Non'}</td></tr>` : ''}
                        ${data.is_paw !== undefined ? `<tr><td style="padding: 5px; border-bottom: 1px solid #ddd;"><strong>PAW:</strong></td><td>${data.is_paw ? 'Oui' : 'Non'}</td></tr>` : ''}
                        <tr><td style="padding: 5px; border-bottom: 1px solid #ddd;"><strong>Taille:</strong></td><td>${(data.size / 1024).toFixed(2)} KB</td></tr>
                        <tr><td style="padding: 5px;"><strong>Modifié:</strong></td><td>${new Date(data.modified).toLocaleString()}</td></tr>
                    </table>
                    <div style="margin-top: 15px; text-align: right;">
                        <button onclick="this.parentElement.parentElement.remove()" style="padding: 8px 16px; background: #6c757d; color: white; border: none; border-radius: 5px; cursor: pointer;">Fermer</button>
                    </div>
                </div>
                <div onclick="this.nextElementSibling ? this.nextElementSibling.remove() : null; this.remove();" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 9999;"></div>
            `;
            
            document.body.insertAdjacentHTML('beforeend', infoHtml);
            
        } else {
            alert(`❌ Erreur: ${data.message}`);
        }
        
    } catch (error) {
        console.error('❌ Erreur lecture pseudo:', error);
        alert(`❌ Erreur de connexion à l'API:\n${error.message}`);
    }
};

// NOTE: La fonction afficherGenerateurPseudo est maintenant définie dans script_generateur_ld1.js
// avec support complet pour 97 éléments et génération de fichiers ld1.in personnalisés

// Fonction pour générer un pseudopotentiel
window.genererPseudo = async function(element) {
    console.log(`⚙️ Génération du pseudo pour ${element}`);
    
    const Z = document.getElementById('gen_Z')?.value || 0;
    const config = document.getElementById('gen_config')?.value || '';
    
    try {
        const response = await fetch(`${API_PSEUDO_BASE}/generer`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ element, Z: parseInt(Z), config })
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert(`✅ Pseudopotentiel généré!\n\nFichier: ${data.filename}\nTaille: ${(data.size / 1024).toFixed(2)} KB`);
            
            // Rafraîchir l'affichage
            if (TABLEAU_PERIODIQUE[element]) {
                afficherElementInfo(element, TABLEAU_PERIODIQUE[element]);
            }
        } else {
            alert(`❌ Génération échouée:\n${data.message}\n\n💡 ${data.suggestion || ''}`);
        }
        
    } catch (error) {
        console.error('❌ Erreur génération pseudo:', error);
        alert(`❌ Erreur de connexion à l'API:\n${error.message}`);
    }
};

// Base de données des configurations électroniques complètes
const CONFIGS_ELECTRONIQUES = {
    'H': '1s¹', 'He': '1s²',
    'Li': '[He] 2s¹', 'Be': '[He] 2s²', 'B': '[He] 2s² 2p¹', 'C': '[He] 2s² 2p²', 
    'N': '[He] 2s² 2p³', 'O': '[He] 2s² 2p⁴', 'F': '[He] 2s² 2p⁵', 'Ne': '[He] 2s² 2p⁶',
    'Na': '[Ne] 3s¹', 'Mg': '[Ne] 3s²', 'Al': '[Ne] 3s² 3p¹', 'Si': '[Ne] 3s² 3p²',
    'P': '[Ne] 3s² 3p³', 'S': '[Ne] 3s² 3p⁴', 'Cl': '[Ne] 3s² 3p⁵', 'Ar': '[Ne] 3s² 3p⁶',
    'K': '[Ar] 4s¹', 'Ca': '[Ar] 4s²', 'Sc': '[Ar] 3d¹ 4s²', 'Ti': '[Ar] 3d² 4s²',
    'V': '[Ar] 3d³ 4s²', 'Cr': '[Ar] 3d⁵ 4s¹', 'Mn': '[Ar] 3d⁵ 4s²', 'Fe': '[Ar] 3d⁶ 4s²',
    'Co': '[Ar] 3d⁷ 4s²', 'Ni': '[Ar] 3d⁸ 4s²', 'Cu': '[Ar] 3d¹⁰ 4s¹', 'Zn': '[Ar] 3d¹⁰ 4s²',
    'Ga': '[Ar] 3d¹⁰ 4s² 4p¹', 'Ge': '[Ar] 3d¹⁰ 4s² 4p²', 'As': '[Ar] 3d¹⁰ 4s² 4p³',
    'Se': '[Ar] 3d¹⁰ 4s² 4p⁴', 'Br': '[Ar] 3d¹⁰ 4s² 4p⁵', 'Kr': '[Ar] 3d¹⁰ 4s² 4p⁶',
    'Rb': '[Kr] 5s¹', 'Sr': '[Kr] 5s²', 'Y': '[Kr] 4d¹ 5s²', 'Zr': '[Kr] 4d² 5s²',
    'Nb': '[Kr] 4d⁴ 5s¹', 'Mo': '[Kr] 4d⁵ 5s¹', 'Tc': '[Kr] 4d⁵ 5s²', 'Ru': '[Kr] 4d⁷ 5s¹',
    'Rh': '[Kr] 4d⁸ 5s¹', 'Pd': '[Kr] 4d¹⁰', 'Ag': '[Kr] 4d¹⁰ 5s¹', 'Cd': '[Kr] 4d¹⁰ 5s²',
    'In': '[Kr] 4d¹⁰ 5s² 5p¹', 'Sn': '[Kr] 4d¹⁰ 5s² 5p²', 'Sb': '[Kr] 4d¹⁰ 5s² 5p³',
    'Te': '[Kr] 4d¹⁰ 5s² 5p⁴', 'I': '[Kr] 4d¹⁰ 5s² 5p⁵', 'Xe': '[Kr] 4d¹⁰ 5s² 5p⁶',
    'Cs': '[Xe] 6s¹', 'Ba': '[Xe] 6s²', 'La': '[Xe] 5d¹ 6s²', 'Ce': '[Xe] 4f¹ 5d¹ 6s²',
    'Pr': '[Xe] 4f³ 6s²', 'Nd': '[Xe] 4f⁴ 6s²', 'Pm': '[Xe] 4f⁵ 6s²', 'Sm': '[Xe] 4f⁶ 6s²',
    'Eu': '[Xe] 4f⁷ 6s²', 'Gd': '[Xe] 4f⁷ 5d¹ 6s²', 'Tb': '[Xe] 4f⁹ 6s²', 'Dy': '[Xe] 4f¹⁰ 6s²',
    'Ho': '[Xe] 4f¹¹ 6s²', 'Er': '[Xe] 4f¹² 6s²', 'Tm': '[Xe] 4f¹³ 6s²', 'Yb': '[Xe] 4f¹⁴ 6s²',
    'Lu': '[Xe] 4f¹⁴ 5d¹ 6s²', 'Hf': '[Xe] 4f¹⁴ 5d² 6s²', 'Ta': '[Xe] 4f¹⁴ 5d³ 6s²',
    'W': '[Xe] 4f¹⁴ 5d⁴ 6s²', 'Re': '[Xe] 4f¹⁴ 5d⁵ 6s²', 'Os': '[Xe] 4f¹⁴ 5d⁶ 6s²',
    'Ir': '[Xe] 4f¹⁴ 5d⁷ 6s²', 'Pt': '[Xe] 4f¹⁴ 5d⁹ 6s¹', 'Au': '[Xe] 4f¹⁴ 5d¹⁰ 6s¹',
    'Hg': '[Xe] 4f¹⁴ 5d¹⁰ 6s²', 'Tl': '[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p¹', 'Pb': '[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p²',
    'Bi': '[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p³', 'Po': '[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁴', 'At': '[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁵',
    'Rn': '[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁶', 'Fr': '[Rn] 7s¹', 'Ra': '[Rn] 7s²', 'Ac': '[Rn] 6d¹ 7s²',
    'Th': '[Rn] 6d² 7s²', 'Pa': '[Rn] 5f² 6d¹ 7s²', 'U': '[Rn] 5f³ 6d¹ 7s²',
    'Np': '[Rn] 5f⁴ 6d¹ 7s²', 'Pu': '[Rn] 5f⁶ 7s²', 'Am': '[Rn] 5f⁷ 7s²', 'Cm': '[Rn] 5f⁷ 6d¹ 7s²'
};

// Fonction pour afficher les informations d'un élément avec statut du pseudo
// CORRIGÉE: Accepte maintenant un 3ème paramètre optionnel pour la box cliquée
window.afficherElementInfo = async function(symbole, element, clickedBox) {
    console.log(`🔍 Affichage info pour ${symbole}`);
    
    // Désélectionner tous les éléments
    document.querySelectorAll('.element-box').forEach(box => box.classList.remove('selected'));
    
    // Sélectionner la box cliquée
    if (clickedBox) {
        clickedBox.classList.add('selected');
    }
    
    const infoDiv = document.getElementById('element_info_display');
    const nomDiv = document.getElementById('element_nom');
    const detailsDiv = document.getElementById('element_details');
    
    if (!infoDiv || !nomDiv || !detailsDiv) {
        console.error('❌ Éléments DOM introuvables pour affichage élément');
        return;
    }
    
    // Utiliser les données de ELEMENTS ou TABLEAU_PERIODIQUE
    const elementData = window.ELEMENTS ? window.ELEMENTS[symbole] : element;
    const masse = elementData.masse || element.masse || 0;
    const periode = elementData.periode || element.periode || '-';
    const groupe = elementData.groupe || element.groupe || '-';
    const type = elementData.type || 'inconnu';
    
    // Récupérer la configuration électronique
    const configElec = CONFIGS_ELECTRONIQUES[symbole] || 
                       (window.ELEMENTS_PSEUDO && window.ELEMENTS_PSEUDO[symbole] ? window.ELEMENTS_PSEUDO[symbole].config : 'N/A');
    
    nomDiv.textContent = `${element.nom} (${symbole})`;
    
    let html = `
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px;">
            <tr><td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Numéro atomique:</strong></td><td>${element.numero}</td></tr>
            <tr><td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Masse atomique:</strong></td><td>${typeof masse === 'number' ? masse.toFixed(3) : masse} u</td></tr>
            <tr><td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Période:</strong></td><td>${periode}</td></tr>
            <tr><td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Groupe:</strong></td><td>${groupe}</td></tr>
            <tr><td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Type:</strong></td><td style="text-transform: capitalize;">${type.replace ? type.replace(/-/g, ' ') : type}</td></tr>
            <tr><td style="padding: 8px; border-bottom: 1px solid #eee;"><strong>Électrons de valence:</strong></td><td>${element.valence}</td></tr>
            <tr style="background: linear-gradient(90deg, #e3f2fd, #f5f5f5);">
                <td style="padding: 10px; border-bottom: 1px solid #2196F3;"><strong>🔬 Configuration électronique:</strong></td>
                <td style="padding: 10px; font-family: 'Courier New', monospace; font-size: 1.1em; color: #1565c0; border-bottom: 1px solid #2196F3;">${configElec}</td>
            </tr>
        </table>
        
        <h4 style="color: #6f42c1; margin: 15px 0 10px;">⚛️ Pseudopotentiel Recommandé (PBE)</h4>
        <p><code style="background: #f8f9fa; padding: 5px 10px; border-radius: 4px;">${element.pseudo}</code></p>
        
        <div id="pseudo_status" style="padding: 10px; border-radius: 5px; margin: 10px 0; background: #f8f9fa;">
            ⏳ Vérification de la disponibilité...
        </div>
        
        <div id="pseudo_actions" style="display: none; margin-top: 15px;"></div>
    `;
    
    detailsDiv.innerHTML = html;
    infoDiv.style.display = 'block';
    infoDiv.scrollIntoView({ behavior: 'smooth' });
    
    // Vérifier la disponibilité du pseudo via l'API native (port 5007)
    try {
        const response = await fetch(`${API_PSEUDO_BASE}/verifier/${element.pseudo}`);
        const data = await response.json();
        
        const statusDiv = document.getElementById('pseudo_status');
        const actionsDiv = document.getElementById('pseudo_actions');
        
        if (data.success && data.exists) {
            // Pseudo disponible
            statusDiv.innerHTML = `
                <span style="color: #28a745; font-weight: bold;">✅ Disponible localement</span>
                <br><small style="color: #6c757d;">Taille: ${(data.size / 1024).toFixed(2)} KB | Modifié: ${new Date(data.modified).toLocaleDateString()}</small>
            `;
            statusDiv.style.background = '#d4edda';
            statusDiv.style.borderLeft = '4px solid #28a745';
            
            actionsDiv.innerHTML = `
                <div style="display: grid; gap: 15px;">
                    <!-- Actions sur le pseudo existant -->
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <button onclick="voirPseudo('${element.pseudo}')" style="padding: 10px 15px; background: #17a2b8; color: white; border: none; border-radius: 5px; cursor: pointer;">
                            📄 Voir Détails
                        </button>
                        <button onclick="supprimerPseudo('${element.pseudo}')" style="padding: 10px 15px; background: #dc3545; color: white; border: none; border-radius: 5px; cursor: pointer;">
                            🗑️ Supprimer
                        </button>
                    </div>
                    
                    <!-- Option de regénération avec ld1.x -->
                    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 15px; border-radius: 8px; color: white;">
                        <h5 style="margin: 0 0 10px 0; color: white;">🔬 Générer un nouveau pseudo avec ld1.x</h5>
                        <p style="font-size: 0.85em; opacity: 0.9; margin: 0 0 10px 0;">
                            Créer un fichier ld1.in personnalisé pour générer un nouveau pseudopotentiel
                        </p>
                        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                            <button onclick="afficherGenerateurPseudo('${symbole}')" 
                                    style="padding: 12px 20px; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; flex: 1;">
                                ⚙️ Ouvrir le Générateur ld1.in
                            </button>
                        </div>
                    </div>
                </div>
            `;
            actionsDiv.style.display = 'block';
            
        } else {
            // Pseudo manquant
            statusDiv.innerHTML = `
                <span style="color: #ffc107; font-weight: bold;">⚠️ Non disponible localement</span>
                <br><small style="color: #6c757d;">Ce pseudopotentiel doit être téléchargé ou généré.</small>
            `;
            statusDiv.style.background = '#fff3cd';
            statusDiv.style.borderLeft = '4px solid #ffc107';
            
            // Récupérer la config électronique pour ld1.x
            const configLD1 = CONFIGS_ELECTRONIQUES[symbole] || '';
            
            actionsDiv.innerHTML = `
                <div style="display: grid; gap: 15px;">
                    <!-- Options de téléchargement -->
                    <div style="background: #e3f2fd; padding: 15px; border-radius: 8px;">
                        <h5 style="margin: 0 0 10px 0; color: #1976d2;">📥 Télécharger un pseudo existant</h5>
                        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                            <button onclick="telechargerPseudo('${symbole}', '${element.pseudo}')" style="padding: 10px 15px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; flex: 1;">
                                📥 Depuis QE Library
                            </button>
                        </div>
                    </div>
                    
                    <!-- Génération avec ld1.x -->
                    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 15px; border-radius: 8px; color: white;">
                        <h5 style="margin: 0 0 10px 0; color: white;">🔬 Générer avec ld1.x (Quantum ESPRESSO)</h5>
                        <p style="font-size: 0.85em; opacity: 0.9; margin: 0 0 10px 0;">
                            Créer un fichier ld1.in personnalisé avec tous les paramètres (97 éléments supportés)
                        </p>
                        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                            <button onclick="afficherGenerateurPseudo('${symbole}')" 
                                    style="padding: 12px 20px; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; flex: 1;">
                                ⚙️ Ouvrir le Générateur ld1.in
                            </button>
                        </div>
                    </div>
                </div>
            `;
            actionsDiv.style.display = 'block';
        }
        
    } catch (error) {
        console.error('❌ Erreur vérification pseudo:', error);
        
        const statusDiv = document.getElementById('pseudo_status');
        statusDiv.innerHTML = `
            <span style="color: #dc3545; font-weight: bold;">❌ API non disponible</span>
            <br><small style="color: #6c757d;">L'API sur le port 5007 n'est pas accessible. Lancez l'API avec: ./demarrer_api.sh</small>
        `;
        statusDiv.style.background = '#f8d7da';
        statusDiv.style.borderLeft = '4px solid #dc3545';
    }
};

// Fonction pour lister tous les pseudopotentiels disponibles
window.listerPseudos = async function() {
    console.log('📋 Liste des pseudopotentiels...');
    
    try {
        const response = await fetch(`${API_PSEUDO_BASE}/lister`);
        const data = await response.json();
        
        if (data.success) {
            console.log(`✅ ${data.count} pseudopotentiels trouvés`);
            return data.pseudos;
        } else {
            console.error('❌ Erreur:', data.message);
            return [];
        }
        
    } catch (error) {
        console.error('❌ Erreur liste pseudos:', error);
        return [];
    }
};

// ═══════════════════════════════════════════════════════════════════════════
// GÉNÉRATION RAPIDE DE PSEUDOPOTENTIEL AVEC ld1.x
// ═══════════════════════════════════════════════════════════════════════════

window.genererPseudoLD1Rapide = async function(symbole, Z, masse, valence, config) {
    console.log(`🔬 Génération rapide du pseudo pour ${symbole} (Z=${Z})`);
    
    // Créer un overlay de progression
    const overlay = document.createElement('div');
    overlay.id = 'ld1_generation_overlay';
    overlay.style.cssText = `
        position: fixed; top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0,0,0,0.8); z-index: 10000;
        display: flex; align-items: center; justify-content: center;
    `;
    
    overlay.innerHTML = `
        <div style="background: white; padding: 30px; border-radius: 15px; max-width: 500px; text-align: center;">
            <h3 style="margin-top: 0; color: #667eea;">🔬 Génération du Pseudopotentiel</h3>
            <div style="margin: 20px 0;">
                <div style="font-size: 3em; animation: pulse 1s infinite;">⚛️</div>
                <p><strong>${symbole}</strong> (Z = ${Z})</p>
                <p style="color: #666;">Configuration: ${config || 'Auto'}</p>
            </div>
            <div id="ld1_status" style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 15px 0;">
                <span id="ld1_status_icon">⏳</span>
                <span id="ld1_status_text">Envoi de la requête à l'API...</span>
            </div>
            <div style="width: 100%; background: #e0e0e0; border-radius: 10px; height: 10px; overflow: hidden;">
                <div id="ld1_progress" style="width: 10%; background: linear-gradient(90deg, #667eea, #764ba2); height: 100%; transition: width 0.5s;"></div>
            </div>
            <button id="ld1_cancel_btn" onclick="document.getElementById('ld1_generation_overlay').remove()" 
                    style="margin-top: 15px; padding: 10px 20px; background: #6c757d; color: white; border: none; border-radius: 5px; cursor: pointer;">
                ❌ Annuler
            </button>
        </div>
    `;
    
    document.body.appendChild(overlay);
    
    // Ajouter animation CSS
    const style = document.createElement('style');
    style.textContent = '@keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.1); } }';
    document.head.appendChild(style);
    
    const updateStatus = (icon, text, progress) => {
        const statusIcon = document.getElementById('ld1_status_icon');
        const statusText = document.getElementById('ld1_status_text');
        const progressBar = document.getElementById('ld1_progress');
        if (statusIcon) statusIcon.textContent = icon;
        if (statusText) statusText.textContent = text;
        if (progressBar) progressBar.style.width = progress + '%';
    };
    
    try {
        updateStatus('📡', 'Connexion à l\'API native (port 5007)...', 20);
        
        // Convertir la config en format ld1.x
        const configLD1 = config.replace(/\[.*?\]\s*/g, '').replace(/\s+/g, ' ').trim() || `${valence}s${valence}`;
        
        updateStatus('⚙️', 'Préparation des paramètres...', 40);
        
        // Étape 1: Essayer le téléchargement depuis QE Library
        updateStatus('📥', 'Téléchargement depuis QE Library...', 40);
        
        const response = await fetch(`${API_PSEUDO_BASE}/generer`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                element: symbole,
                Z: Z,
                masse: masse,
                valence: valence,
                config: configLD1,
                method: 'download',  // D'abord essayer téléchargement
                pseudo_type: 'us'
            })
        });
        
        updateStatus('🔧', 'Traitement en cours...', 60);
        
        const data = await response.json();
        
        if (data.success) {
            const sourceInfo = data.source === 'QE Library' ? '📥 Téléchargé depuis QE Library' :
                              data.source === 'ld1.x' ? '🔧 Généré avec ld1.x' :
                              data.source === 'pseudo_telecha' ? '📂 Copié depuis pseudo_telecha' :
                              data.already_exists ? '✅ Déjà disponible localement' : '✅ Obtenu avec succès';
            
            updateStatus('✅', sourceInfo, 100);
            
            setTimeout(() => {
                overlay.innerHTML = `
                    <div style="background: white; padding: 30px; border-radius: 15px; max-width: 500px; text-align: center;">
                        <h3 style="margin-top: 0; color: #28a745;">✅ Pseudopotentiel Disponible!</h3>
                        <div style="background: #d4edda; padding: 20px; border-radius: 10px; margin: 20px 0;">
                            <p style="margin: 0; color: #155724;"><strong>Source:</strong> ${sourceInfo}</p>
                            <hr style="border-color: #c3e6cb; margin: 10px 0;">
                            <p style="margin: 0;"><strong>Fichier:</strong> ${data.filename}</p>
                            <p style="margin: 5px 0 0 0;"><strong>Taille:</strong> ${(data.size / 1024).toFixed(2)} KB</p>
                            <p style="margin: 5px 0 0 0; font-size: 0.85em; color: #666;"><strong>Chemin:</strong> ${data.filepath}</p>
                        </div>
                        <div style="display: flex; gap: 10px; justify-content: center; flex-wrap: wrap;">
                            <button onclick="document.getElementById('ld1_generation_overlay').remove(); voirPseudo('${data.filename}')" 
                                    style="padding: 12px 20px; background: #17a2b8; color: white; border: none; border-radius: 5px; cursor: pointer;">
                                📄 Voir Contenu
                            </button>
                            <button onclick="document.getElementById('ld1_generation_overlay').remove(); const box = document.querySelector('[data-symbole=\\'${symbole}\\']'); window.afficherElementInfo('${symbole}', window.ELEMENTS['${symbole}'] || TABLEAU_PERIODIQUE['${symbole}'], box)" 
                                    style="padding: 12px 20px; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer;">
                                🔄 Rafraîchir
                            </button>
                        </div>
                    </div>
                `;
            }, 500);
            
        } else {
            throw new Error(data.message || 'Erreur de génération');
        }
        
    } catch (error) {
        console.error('❌ Erreur génération ld1.x:', error);
        
        overlay.innerHTML = `
            <div style="background: white; padding: 30px; border-radius: 15px; max-width: 600px; text-align: center;">
                <h3 style="margin-top: 0; color: #dc3545;">❌ Erreur de Génération</h3>
                <div style="background: #f8d7da; padding: 20px; border-radius: 10px; margin: 20px 0; text-align: left;">
                    <p style="margin: 0;"><strong>Erreur:</strong> ${error.message}</p>
                    <hr style="border-color: #f5c6cb;">
                    <p style="margin: 10px 0 0 0; font-size: 0.9em;">
                        <strong>Solutions possibles:</strong><br>
                        • Vérifiez que l'API est lancée (port 5007)<br>
                        • Vérifiez que ld1.x est installé (module atomic de QE)<br>
                        • Téléchargez un pseudo pré-généré depuis QE Library
                    </p>
                </div>
                <div style="display: flex; gap: 10px; justify-content: center; flex-wrap: wrap;">
                    <button onclick="telechargerPseudo('${symbole}', '${symbole}.pbe-n-rrkjus_psl.1.0.0.UPF')" 
                            style="padding: 12px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;">
                        📥 Télécharger depuis QE
                    </button>
                    <button onclick="document.getElementById('ld1_generation_overlay').remove()" 
                            style="padding: 12px 20px; background: #6c757d; color: white; border: none; border-radius: 5px; cursor: pointer;">
                        ❌ Fermer
                    </button>
                </div>
            </div>
        `;
    }
};

// Fonction pour afficher la bibliothèque de pseudopotentiels
window.afficherBibliotheque = async function() {
    console.log('📚 Affichage de la bibliothèque de pseudopotentiels...');
    
    const pseudos = await listerPseudos();
    
    const resultsDiv = document.getElementById('results');
    if (!resultsDiv) return;
    
    if (pseudos.length === 0) {
        resultsDiv.innerHTML = `
            <div style="background: #fff3cd; padding: 20px; border-radius: 10px; margin: 20px 0;">
                <h4 style="margin-top: 0;">📚 Bibliothèque de Pseudopotentiels</h4>
                <p>Aucun pseudopotentiel trouvé dans le répertoire local.</p>
                <p>Cliquez sur un élément du tableau périodique pour télécharger son pseudopotentiel.</p>
            </div>
        `;
        return;
    }
    
    resultsDiv.innerHTML = `
        <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin: 20px 0;">
            <h4 style="margin-top: 0;">📚 Bibliothèque de Pseudopotentiels (${pseudos.length})</h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 10px; margin-top: 15px;">
                ${pseudos.map(p => `
                    <div style="background: white; padding: 10px; border-radius: 8px; border: 1px solid #ddd; cursor: pointer;" onclick="voirPseudo('${p.filename}')">
                        <strong style="color: #6f42c1;">${p.element}</strong>
                        <br><small style="color: #6c757d;">${p.filename}</small>
                        <br><small style="color: #6c757d;">${(p.size / 1024).toFixed(1)} KB</small>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
};

// Initialisation automatique
document.addEventListener('DOMContentLoaded', function() {
    console.log('🔬 Script du tableau périodique chargé');
    console.log(`📊 ${Object.keys(TABLEAU_PERIODIQUE).length} éléments disponibles`);
    console.log(`🔗 API Pseudopotentiels: ${API_PSEUDO_BASE}`);
});

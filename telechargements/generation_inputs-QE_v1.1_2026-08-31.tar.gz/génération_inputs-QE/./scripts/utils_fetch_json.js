// ═══════════════════════════════════════════════════════════════════════════
// UTILITAIRE FETCH JSON ROBUSTE - SOLUTION DÉFINITIVE
// ═══════════════════════════════════════════════════════════════════════════
// Ce module fournit une fonction fetch robuste qui gère tous les cas d'erreur
// JSON.parse et affiche des messages d'erreur détaillés pour le débogage.
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Fetch robuste avec gestion complète des erreurs JSON
 * @param {string} url - URL de l'endpoint
 * @param {object} options - Options fetch (method, headers, body, etc.)
 * @returns {Promise<object>} - Données JSON parsées
 * @throws {Error} - Erreur détaillée avec contexte
 */
async function fetchJSON(url, options = {}) {
    // Ajouter les headers par défaut
    const defaultHeaders = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    };
    
    const mergedOptions = {
        ...options,
        headers: {
            ...defaultHeaders,
            ...(options.headers || {})
        }
    };
    
    let response;
    let responseText;
    
    try {
        // Étape 1: Faire la requête
        console.log(`[fetchJSON] Requête vers: ${url}`);
        response = await fetch(url, mergedOptions);
        
        // Étape 2: Lire la réponse en texte (une seule fois)
        responseText = await response.text();
        console.log(`[fetchJSON] Réponse reçue (${response.status}), longueur: ${responseText.length} chars`);
        
        // Étape 3: Vérifier le statut HTTP
        if (!response.ok) {
            const contentType = response.headers.get('content-type') || 'unknown';
            console.error(`[fetchJSON] Erreur HTTP ${response.status}:`, responseText.slice(0, 500));
            
            throw new Error(
                `Erreur HTTP ${response.status} ${response.statusText}\n` +
                `URL: ${url}\n` +
                `Content-Type: ${contentType}\n` +
                `Réponse (500 premiers chars): ${responseText.slice(0, 500)}`
            );
        }
        
        // Étape 4: Vérifier le Content-Type
        const contentType = response.headers.get('content-type') || '';
        if (!contentType.includes('application/json')) {
            console.warn(`[fetchJSON] Content-Type inattendu: ${contentType}`);
            console.warn(`[fetchJSON] Réponse (200 premiers chars):`, responseText.slice(0, 200));
            
            // Si c'est du HTML, c'est probablement une page d'erreur
            if (contentType.includes('text/html') || responseText.trim().startsWith('<!DOCTYPE') || responseText.trim().startsWith('<html')) {
                throw new Error(
                    `Le serveur a renvoyé du HTML au lieu de JSON\n` +
                    `URL: ${url}\n` +
                    `Content-Type: ${contentType}\n` +
                    `Cela indique généralement:\n` +
                    `- L'endpoint n'existe pas (404)\n` +
                    `- Le serveur a une erreur (500)\n` +
                    `- L'API n'est pas démarrée\n\n` +
                    `Début de la réponse HTML:\n${responseText.slice(0, 300)}`
                );
            }
            
            // Si c'est du texte brut, essayer quand même de parser
            if (contentType.includes('text/plain')) {
                console.warn(`[fetchJSON] Tentative de parsing malgré text/plain...`);
            }
        }
        
        // Étape 5: Nettoyer le texte (BOM, espaces, etc.)
        let cleanedText = responseText
            .replace(/^\uFEFF/, '')  // Supprimer BOM
            .trim();                  // Supprimer espaces
        
        // Vérifier si le texte est vide
        if (!cleanedText) {
            throw new Error(
                `Réponse vide du serveur\n` +
                `URL: ${url}\n` +
                `Status: ${response.status}\n` +
                `Content-Type: ${contentType}`
            );
        }
        
        // Étape 6: Vérifier que ça commence par { ou [
        const firstChar = cleanedText.charAt(0);
        if (firstChar !== '{' && firstChar !== '[') {
            console.error(`[fetchJSON] La réponse ne commence pas par { ou [, mais par: "${firstChar}"`);
            console.error(`[fetchJSON] 200 premiers chars:`, cleanedText.slice(0, 200));
            
            throw new Error(
                `La réponse n'est pas du JSON valide\n` +
                `URL: ${url}\n` +
                `Premier caractère: "${firstChar}" (attendu: { ou [)\n` +
                `200 premiers caractères:\n${cleanedText.slice(0, 200)}\n\n` +
                `Causes possibles:\n` +
                `- Le serveur a des print() ou console.log() avant le JSON\n` +
                `- Le serveur renvoie du texte brut au lieu de JSON\n` +
                `- L'endpoint n'est pas configuré correctement`
            );
        }
        
        // Étape 7: Parser le JSON
        let jsonData;
        try {
            jsonData = JSON.parse(cleanedText);
            console.log(`[fetchJSON] JSON parsé avec succès`);
        } catch (parseError) {
            console.error(`[fetchJSON] Erreur de parsing JSON:`, parseError);
            console.error(`[fetchJSON] Texte à parser (200 premiers chars):`, cleanedText.slice(0, 200));
            
            throw new Error(
                `Impossible de parser le JSON\n` +
                `URL: ${url}\n` +
                `Erreur: ${parseError.message}\n` +
                `200 premiers caractères de la réponse:\n${cleanedText.slice(0, 200)}\n\n` +
                `Le JSON est malformé. Vérifiez:\n` +
                `- Guillemets manquants ou mal placés\n` +
                `- Virgules en trop ou manquantes\n` +
                `- Accolades/crochets non fermés`
            );
        }
        
        return jsonData;
        
    } catch (error) {
        // Si c'est déjà notre erreur personnalisée, la relancer
        if (error.message.includes('URL:')) {
            throw error;
        }
        
        // Sinon, créer une erreur détaillée
        throw new Error(
            `Erreur lors de la requête fetch\n` +
            `URL: ${url}\n` +
            `Erreur: ${error.message}\n` +
            `Type: ${error.name}\n\n` +
            `Vérifiez que:\n` +
            `- L'API est démarrée (http://localhost:5007)\n` +
            `- L'URL est correcte\n` +
            `- Le réseau fonctionne`
        );
    }
}

/**
 * Wrapper pour POST avec body JSON
 */
async function postJSON(url, data) {
    return fetchJSON(url, {
        method: 'POST',
        body: JSON.stringify(data)
    });
}

/**
 * Wrapper pour GET
 */
async function getJSON(url) {
    return fetchJSON(url, {
        method: 'GET'
    });
}

/**
 * Tester si l'API est accessible
 */
async function testAPI(baseURL = 'http://localhost:5007') {
    try {
        const response = await fetch(baseURL, { method: 'GET' });
        return response.ok;
    } catch (error) {
        return false;
    }
}

/**
 * Afficher un message d'erreur utilisateur convivial
 */
function afficherErreurJSON(error, contexte = '') {
    console.error(`[Erreur ${contexte}]`, error);
    
    let message = `❌ Erreur: ${error.message}`;
    
    // Suggestions selon le type d'erreur
    if (error.message.includes('HTML')) {
        message += `\n\n💡 Solution: Vérifiez que l'API est démarrée et que l'endpoint existe.`;
    } else if (error.message.includes('Réponse vide')) {
        message += `\n\n💡 Solution: L'endpoint ne renvoie rien. Vérifiez le code serveur.`;
    } else if (error.message.includes('ne commence pas par')) {
        message += `\n\n💡 Solution: Le serveur a des print() ou logs avant le JSON. Supprimez-les.`;
    } else if (error.message.includes('Impossible de parser')) {
        message += `\n\n💡 Solution: Le JSON est malformé. Vérifiez la syntaxe côté serveur.`;
    } else if (error.message.includes('fetch')) {
        message += `\n\n💡 Solution: Vérifiez que l'API est démarrée sur http://localhost:5007`;
    }
    
    return message;
}

// Exporter les fonctions
window.fetchJSON = fetchJSON;
window.postJSON = postJSON;
window.getJSON = getJSON;
window.testAPI = testAPI;
window.afficherErreurJSON = afficherErreurJSON;

console.log('✅ Utilitaire fetchJSON chargé - Solution définitive pour les erreurs JSON.parse');

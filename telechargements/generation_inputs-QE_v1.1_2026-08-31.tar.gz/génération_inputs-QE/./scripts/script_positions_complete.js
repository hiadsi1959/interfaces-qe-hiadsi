// ═══════════════════════════════════════════════════════════════════════════
// POSITIONS ATOMIQUES COMPLÈTES - TOUS LES IBRAV AVEC NAT DYNAMIQUE
// Génération intelligente selon la structure et le nombre d'atomes
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Générer les positions pour TOUS les ibrav et TOUS les nat
 * Logique:
 * - Pour chaque structure, on a une cellule primitive
 * - Si nat > positions_primitives, on répète le pattern
 */
function genererPositionsParIbravEtNat(ibrav, nat) {
    ibrav = String(ibrav);
    nat = parseInt(nat) || 1;
    
    console.log(`\n🔧 genererPositionsParIbravEtNat(ibrav=${ibrav}, nat=${nat})`);
    
    const positions = [];
    
    // BASE: Positions unitaires pour chaque structure
    const structuresBase = {
        '1': {  // Cubique Simple (SC)
            name: 'Cubique Simple (SC)',
            primitive: [[0, 0, 0]],
            description: 'SC: 1 atome par maille'
        },
        '2': {  // FCC
            name: 'Cubique Faces Centrées (FCC)',
            primitive: [[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]],
            description: 'FCC: 4 atomes par maille'
        },
        '3': {  // BCC
            name: 'Cubique Centré (BCC)',
            primitive: [[0, 0, 0], [0.5, 0.5, 0.5]],
            description: 'BCC: 2 atomes par maille'
        },
        '4': {  // Hexagonal
            name: 'Hexagonal',
            primitive: [[0, 0, 0], [1/3, 2/3, 0.5]],
            description: 'Hexagonal: 2 atomes par maille (ex: GaN)'
        },
        '5': {  // Rhomboédrique
            name: 'Rhomboédrique',
            primitive: [[0, 0, 0]],
            description: 'Rhomboédrique: 1 atome par maille'
        },
        '6': {  // Tétragonal simple
            name: 'Tétragonal Simple',
            primitive: [[0, 0, 0]],
            description: 'Tétragonal Simple: 1 atome par maille'
        },
        '7': {  // Tétragonal centré
            name: 'Tétragonal Centré',
            primitive: [[0, 0, 0], [0.5, 0.5, 0.5]],
            description: 'Tétragonal Centré: 2 atomes par maille'
        },
        '8': {  // Orthorhombique simple
            name: 'Orthorhombique Simple',
            primitive: [[0, 0, 0]],
            description: 'Orthorhombique Simple: 1 atome par maille'
        },
        '9': {  // Orthorhombique centré (C)
            name: 'Orthorhombique Centré (C)',
            primitive: [[0, 0, 0], [0.5, 0.5, 0]],
            description: 'Orthorhombique C: 2 atomes par maille'
        },
        '10': {  // Orthorhombique F
            name: 'Orthorhombique Faces (F)',
            primitive: [[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]],
            description: 'Orthorhombique F: 4 atomes par maille'
        },
        '11': {  // Orthorhombique I
            name: 'Orthorhombique Centré (I)',
            primitive: [[0, 0, 0], [0.5, 0.5, 0.5]],
            description: 'Orthorhombique I: 2 atomes par maille'
        },
        '12': {  // Monoclinique simple
            name: 'Monoclinique Simple',
            primitive: [[0, 0, 0]],
            description: 'Monoclinique Simple: 1 atome par maille'
        },
        '13': {  // Monoclinique centré
            name: 'Monoclinique Centré',
            primitive: [[0, 0, 0], [0.5, 0.5, 0]],
            description: 'Monoclinique Centré: 2 atomes par maille'
        },
        '14': {  // Triclinique
            name: 'Triclinique',
            primitive: [[0, 0, 0]],
            description: 'Triclinique: 1 atome par maille'
        }
    };
    
    const struct = structuresBase[ibrav];
    if (!struct) {
        console.error(`❌ Structure ibrav=${ibrav} non reconnue`);
        return [];
    }
    
    console.log(`✓ ${struct.description}`);
    
    // GÉNÉRER LES POSITIONS EN FONCTION DE NAT
    const primitive = struct.primitive;
    const nPrimitive = primitive.length;
    
    console.log(`→ Positions primitives: ${nPrimitive}`);
    console.log(`→ nat demandé: ${nat}`);
    
    // Stratégie: Répéter le pattern primitif
    for (let i = 0; i < nat; i++) {
        const posIdx = i % nPrimitive;
        const [x, y, z] = primitive[posIdx];
        positions.push([x, y, z]);
        console.log(`  Atome ${i+1}: position[${posIdx}] = [${x.toFixed(4)}, ${y.toFixed(4)}, ${z.toFixed(4)}]`);
    }
    
    console.log(`✅ ${nat} positions générées pour ${struct.name}`);
    
    return positions;
}

/**
 * Générer les positions automatiquement
 * NOUVELLE VERSION: Utilise la fonction universelle
 */
function genererPositionsAuto() {
    const ibravInput = document.getElementById('ibrav');
    const natInput = document.getElementById('nat');
    
    const ibrav = ibravInput?.value || '1';
    const nat = parseInt(natInput?.value) || 0;
    
    console.log(`\n\n🚀🚀🚀 GÉNÉRATION AUTO - ibrav=${ibrav}, nat=${nat} 🚀🚀🚀\n`);
    
    if (nat <= 0) {
        alert('❌ Entrez nat d\'abord');
        return;
    }
    
    // UTILISER LA NOUVELLE FONCTION UNIVERSELLE
    const positions = genererPositionsParIbravEtNat(ibrav, nat);
    
    if (positions.length === 0) {
        alert(`❌ Structure ibrav=${ibrav} non trouvée`);
        return;
    }
    
    // ÉTAPE 1: REMPLIR LES INPUTS
    console.log(`\n→ ÉTAPE 1: Remplissage des ${nat} champs...`);
    
    for (let i = 1; i <= nat; i++) {
        const [x, y, z] = positions[i - 1];
        
        const xInput = document.getElementById(`pos_x_${i}`);
        const yInput = document.getElementById(`pos_y_${i}`);
        const zInput = document.getElementById(`pos_z_${i}`);
        
        if (xInput) xInput.value = x;
        if (yInput) yInput.value = y;
        if (zInput) zInput.value = z;
        
        console.log(`  ✓ Atome ${i}: [${x}, ${y}, ${z}]`);
    }
    
    // ÉTAPE 2: METTRE À JOUR LE FORMAT
    console.log(`\n→ ÉTAPE 2: Appel mettreAJourFormat() après 300ms...`);
    setTimeout(() => {
        mettreAJourFormat();
        console.log('✅ Format mis à jour\n');
    }, 300);
    
    alert(`✅ ${nat} positions générées!`);
}

console.log('✅ Script positions complètes (UNIVERSELLES) chargé');








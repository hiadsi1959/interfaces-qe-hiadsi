/* Extrait de index.html — Workflow Phonons Amélioré V2 (déduplication) */
(function() {
    'use strict';
    
    console.log('🔊 Initialisation du Workflow Phonons Amélioré V2...');
    
    // Variable globale pour le matériau
    window.materiauPhononsSelectionne = null;
    window.outputsMateriauTrouves = [];
    
    // Fonction de validation du matériau
    window.validerMateriauComplet = async function() {
        const inputMateriau = document.getElementById('input_materiau_workflow');
        if (!inputMateriau) {
            console.error('❌ Element input_materiau_workflow non trouvé');
            return;
        }
        
        const materiau = inputMateriau.value.trim();
        
        if (!materiau) {
            alert('❌ Veuillez entrer le nom d\'un matériau');
            return;
        }
        
        console.log('✅ Matériau validé:', materiau);
        window.materiauPhononsSelectionne = materiau;
        
        // Afficher le message de validation
        const infoDiv = document.getElementById('materiau_valide_info');
        if (infoDiv) {
            infoDiv.style.display = 'block';
            const nomSpan = document.getElementById('materiau_valide_nom');
            if (nomSpan) nomSpan.textContent = materiau;
        }
        
        // Créer ou récupérer la zone pour le bouton
        let zoneBouton = document.getElementById('zone_bouton_charger_scf');
        if (!zoneBouton) {
            zoneBouton = document.createElement('div');
            zoneBouton.id = 'zone_bouton_charger_scf';
            zoneBouton.style.cssText = 'margin-top: 20px;';
            
            if (infoDiv && infoDiv.parentNode) {
                infoDiv.parentNode.insertBefore(zoneBouton, infoDiv.nextSibling);
            }
        }
        
        // Afficher le bouton de chargement
        zoneBouton.innerHTML = `
            <div style="margin-top: 15px; padding: 15px; border-radius: 10px; border: 2px solid #4f46e5; background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);">
                <button id="btn_charger_outputs" style="width: 100%; padding: 18px; background: linear-gradient(135deg, #4f46e5, #3730a3); color: white; border: none; border-radius: 12px; cursor: pointer; font-weight: 600; font-size: 1.1em; box-shadow: 0 4px 15px rgba(79, 70, 229, 0.3);">
                    📂 Charger les Outputs de ${materiau}
                </button>
                <div id="zone_resultats_outputs" style="margin-top: 15px;"></div>
            </div>
        `;
        
        // Ajouter l'événement au bouton
        document.getElementById('btn_charger_outputs').addEventListener('click', chargerTousLesOutputs);
        console.log('✅ Bouton Charger Outputs affiché');
    };
    
    // Fonction pour charger TOUS les outputs du matériau
    async function chargerTousLesOutputs() {
        console.log('🔍 Recherche de TOUS les outputs pour:', window.materiauPhononsSelectionne);
        
        const zoneResultats = document.getElementById('zone_resultats_outputs');
        if (!zoneResultats) return;
        
        // Loader
        zoneResultats.innerHTML = '<div style="text-align: center; padding: 20px;"><div style="display: inline-block; width: 40px; height: 40px; border: 4px solid #e5e7eb; border-top-color: #4f46e5; border-radius: 50%; animation: spin 1s linear infinite;"></div><p style="margin-top: 10px; color: #6b7280;">🔍 Recherche des outputs...</p></div>';
        
        try {
            // ✅ Utiliser /api/lister_calculs qui existe
            const response = await fetch('http://localhost:5007/api/lister_calculs');
            const data = await response.json();
            
            // ✅ L'API utilise 'success' pas 'status', 'calculs' pas 'outputs'
            if (!data.success) throw new Error('API a retourné success=false');
            
            const mat = window.materiauPhononsSelectionne.toLowerCase();
            
            // Filtrer TOUS les calculs du matériau
            const calculsMateriaux = data.calculs.filter(calcul => {
                const nomCalcul = (calcul.nom || calcul.fichier || '').toLowerCase();
                return nomCalcul.includes(mat);
            });
            
            window.outputsMateriauTrouves = calculsMateriaux;
            
            console.log('✅ Outputs trouvés:', calculsMateriaux.length);
            
            // Catégoriser les outputs par type de fichier
            const categories = {
                scf: calculsMateriaux.filter(output => {
                    const nomFichier = (output.fichier || '').toLowerCase();
                    return nomFichier.includes('scf') && !nomFichier.includes('nscf');
                }),
                nscf: calculsMateriaux.filter(output => {
                    const nomFichier = (output.fichier || '').toLowerCase();
                    return nomFichier.includes('nscf');
                }),
                vcrelax: calculsMateriaux.filter(output => {
                    const nomFichier = (output.fichier || '').toLowerCase();
                    return nomFichier.includes('vc-relax') || nomFichier.includes('vcrelax') || nomFichier.includes('vc_relax');
                }),
                relax: calculsMateriaux.filter(output => {
                    const nomFichier = (output.fichier || '').toLowerCase();
                    return nomFichier.includes('relax') && !nomFichier.includes('vc');
                }),
                bands: calculsMateriaux.filter(output => {
                    const nomFichier = (output.fichier || '').toLowerCase();
                    return nomFichier.includes('bands');
                }),
                dos: calculsMateriaux.filter(output => {
                    const nomFichier = (output.fichier || '').toLowerCase();
                    return nomFichier.includes('dos');
                }),
                ph: calculsMateriaux.filter(output => {
                    const nomFichier = (output.fichier || '').toLowerCase();
                    return (nomFichier.includes('ph') || nomFichier.includes('phonon')) && !nomFichier.includes('nscf');
                }),
                autres: calculsMateriaux.filter(output => {
                    const nomFichier = (output.fichier || '').toLowerCase();
                    return !nomFichier.includes('scf') && !nomFichier.includes('relax') && !nomFichier.includes('bands') && !nomFichier.includes('dos') && !nomFichier.includes('ph') && !nomFichier.includes('phonon');
                })
            };
            
            // Construire l'affichage
            let html = `
                <div style="background: #d1fae5; padding: 15px; border-radius: 10px; border-left: 4px solid #10b981; margin-bottom: 20px;">
                    <strong style="color: #065f46; font-size: 1.2em;">📊 ${calculsMateriaux.length} output(s) trouvé(s) pour ${window.materiauPhononsSelectionne}</strong>
                </div>
            `;
            
            // Afficher chaque catégorie
            const categoriesConfig = [
                { key: 'vcrelax', label: '🔧 VC-RELAX (Optimisation)', color: '#8b5cf6' },
                { key: 'relax', label: '🔧 RELAX', color: '#a855f7' },
                { key: 'scf', label: '⚡ SCF (Auto-cohérent)', color: '#3b82f6' },
                { key: 'nscf', label: '📊 NSCF', color: '#06b6d4' },
                { key: 'bands', label: '📈 Bandes', color: '#10b981' },
                { key: 'dos', label: '📉 DOS', color: '#f59e0b' },
                { key: 'ph', label: '🔊 Phonons (PH.X)', color: '#ec4899' },
                { key: 'autres', label: '📁 Autres', color: '#6b7280' }
            ];
            
            for (const cat of categoriesConfig) {
                const calculs = categories[cat.key];
                if (calculs.length > 0) {
                    html += `
                        <div style="margin-bottom: 15px;">
                            <h4 style="color: ${cat.color}; margin: 0 0 10px 0; display: flex; align-items: center; gap: 8px;">
                                ${cat.label}
                                <span style="background: ${cat.color}; color: white; padding: 2px 8px; border-radius: 12px; font-size: 0.8em;">${calculs.length}</span>
                            </h4>
                    `;
                    
                    for (const output of calculs) {
                        const converge = output.taille && output.taille > 1000;
                        const bgColor = converge ? '#d1fae5' : '#fef3c7';
                        const borderColor = converge ? '#10b981' : '#f59e0b';
                        const tailleKB = output.taille ? (output.taille / 1024).toFixed(2) : '0';
                        
                        html += `
                            <div style="background: ${bgColor}; padding: 12px 15px; border-radius: 8px; margin: 8px 0; border-left: 4px solid ${borderColor}; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                                <div>
                                    <strong style="color: #1f2937;">${converge ? '✅' : '⚠️'} ${output.fichier || 'Fichier sans nom'}</strong>
                                    <div style="font-size: 0.85em; color: #6b7280;">Taille: ${tailleKB} KB • ${output.materiau}</div>
                                </div>
                                <button onclick="afficherOutputComplet('${output.chemin || ''}')" style="padding: 8px 16px; background: ${cat.color}; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 0.9em;">
                                    👁️ Voir Output
                                </button>
                            </div>
                        `;
                    }
                    
                    html += '</div>';
                }
            }
            
            // Vérifier si SCF convergé existe
            const scfConverge = categories.scf.some(output => output.taille && output.taille > 1000);
            const phExiste = categories.ph.length > 0;
            
            // Section Workflow Phonons
            html += `
                <div style="margin-top: 25px; padding: 20px; background: linear-gradient(135deg, #fdf4ff 0%, #fae8ff 100%); border-radius: 12px; border: 2px solid #d946ef;">
                    <h3 style="color: #a21caf; margin: 0 0 15px 0;">🔊 Workflow Phonons</h3>
            `;
            
            if (!scfConverge) {
                html += `
                    <div style="background: #fef3c7; padding: 15px; border-radius: 8px; border-left: 4px solid #f59e0b; margin-bottom: 15px;">
                        <strong style="color: #92400e;">⚠️ Prérequis manquant: Calcul SCF convergé</strong>
                        <p style="margin: 10px 0 0 0; color: #78350f; font-size: 0.95em;">Vous devez d'abord avoir un calcul SCF convergé pour lancer les phonons.</p>
                    </div>
                    <button onclick="editerInputComplet('scf')" style="width: 100%; padding: 15px; background: linear-gradient(135deg, #3b82f6, #2563eb); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em; margin-bottom: 10px;">
                        ⚡ Créer un Input SCF
                    </button>
                `;
            } else {
                html += `
                    <div style="background: #d1fae5; padding: 15px; border-radius: 8px; border-left: 4px solid #10b981; margin-bottom: 15px;">
                        <strong style="color: #065f46;">✅ Prérequis OK: Calcul SCF convergé disponible</strong>
                    </div>
                `;
                
                if (phExiste) {
                    html += `
                        <div style="background: #d1fae5; padding: 15px; border-radius: 8px; border-left: 4px solid #10b981; margin-bottom: 15px;">
                            <strong style="color: #065f46;">✅ Calcul PH.X existant détecté!</strong>
                            <p style="margin: 10px 0 0 0; color: #059669; font-size: 0.95em;">Vous pouvez continuer vers Q2R.X et MATDYN.X</p>
                        </div>
                    `;
                }
                
                // Boutons pour les calculs phonons
                html += `
                    <div style="display: grid; gap: 12px;">
                        <button onclick="ouvrirEditeurPhononsPH()" style="width: 100%; padding: 15px; background: linear-gradient(135deg, #ec4899, #db2777); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em; ${phExiste ? 'opacity: 0.7;' : ''}">
                            ${phExiste ? '🔄' : '1️⃣'} PH.X - Calcul des Phonons ${phExiste ? '(Relancer)' : ''}
                        </button>
                        <button onclick="ouvrirEditeurPhononsQ2R()" style="width: 100%; padding: 15px; background: linear-gradient(135deg, #8b5cf6, #7c3aed); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em; ${!phExiste ? 'opacity: 0.5;' : ''}">
                            2️⃣ Q2R.X - Matrices de Force ${!phExiste ? '(Nécessite PH.X)' : ''}
                        </button>
                        <button onclick="ouvrirEditeurPhononsMatdyn()" style="width: 100%; padding: 15px; background: linear-gradient(135deg, #06b6d4, #0891b2); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em; ${!phExiste ? 'opacity: 0.5;' : ''}">
                            3️⃣ MATDYN.X - Dispersion ${!phExiste ? '(Nécessite Q2R.X)' : ''}
                        </button>
                    </div>
                `;
            }
            
            html += '</div>';
            
            zoneResultats.innerHTML = html;
            
        } catch (error) {
            console.error('❌ Erreur:', error);
            zoneResultats.innerHTML = `
                <div style="background: #fee2e2; padding: 15px; border-radius: 10px; border-left: 4px solid #ef4444;">
                    <strong style="color: #991b1b;">❌ Erreur: ${error.message}</strong>
                </div>
            `;
        }
    }
    
    // Fonction pour afficher un output complet
    window.afficherOutputComplet = async function(chemin) {
        try {
            const response = await fetch('http://localhost:5007/api/lire_fichier', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ fichier: chemin })
            });
            const data = await response.json();
            
            if (data.status === 'success') {
                const modal = document.createElement('div');
                modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.85); z-index: 10000; display: flex; align-items: center; justify-content: center; padding: 20px;';
                modal.innerHTML = `
                    <div style="background: white; border-radius: 15px; max-width: 1400px; width: 100%; max-height: 95vh; display: flex; flex-direction: column;">
                        <div style="padding: 20px; border-bottom: 2px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center; background: linear-gradient(135deg, #4f46e5, #3730a3); color: white; border-radius: 15px 15px 0 0;">
                            <h3 style="margin: 0;">📄 ${chemin.split('/').pop()}</h3>
                            <div style="display: flex; gap: 10px;">
                                <button onclick="copierContenuOutput()" style="background: rgba(255,255,255,0.2); color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: 600;">📋 Copier</button>
                                <button onclick="this.closest('div[style*=position]').remove()" style="background: #ef4444; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: 600;">❌ Fermer</button>
                            </div>
                        </div>
                        <div style="padding: 20px; overflow-y: auto; flex: 1;">
                            <pre id="contenu_output_modal" style="background: #1f2937; color: #f3f4f6; padding: 20px; border-radius: 8px; overflow-x: auto; font-family: 'Courier New', monospace; font-size: 0.85em; white-space: pre-wrap; line-height: 1.5;">${escapeHtml(data.contenu)}</pre>
                        </div>
                    </div>
                `;
                document.body.appendChild(modal);
            } else {
                alert('❌ Erreur: ' + data.error);
            }
        } catch (error) {
            alert('❌ Erreur: ' + error.message);
        }
    };
    
    // Fonction pour copier le contenu
    window.copierContenuOutput = function() {
        const pre = document.getElementById('contenu_output_modal');
        if (pre) {
            navigator.clipboard.writeText(pre.textContent).then(() => {
                alert('✅ Contenu copié dans le presse-papiers!');
            });
        }
    };
    
    // Fonction pour échapper le HTML
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    // Éditeur PH.X avec recommandations
    window.ouvrirEditeurPhononsPH = async function() {
        const mat = window.materiauPhononsSelectionne || 'materiau';
        
        const modal = document.createElement('div');
        modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.85); z-index: 10000; display: flex; align-items: center; justify-content: center; padding: 20px; overflow-y: auto;';
        modal.innerHTML = `
            <div style="background: white; border-radius: 15px; max-width: 1000px; width: 100%; max-height: 95vh; display: flex; flex-direction: column;">
                <div style="padding: 20px; border-bottom: 2px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center; background: linear-gradient(135deg, #ec4899, #db2777); color: white; border-radius: 15px 15px 0 0;">
                    <h3 style="margin: 0;">🔊 PH.X - Calcul des Phonons</h3>
                    <button onclick="this.closest('div[style*=position]').remove()" style="background: rgba(255,255,255,0.2); color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: 600;">❌ Fermer</button>
                </div>
                <div style="padding: 20px; overflow-y: auto; flex: 1;">
                    <div style="background: #fef3c7; padding: 15px; border-radius: 10px; border-left: 4px solid #f59e0b; margin-bottom: 20px;">
                        <strong style="color: #92400e;">📋 Recommandations PH.X:</strong>
                        <ul style="margin: 10px 0 0 20px; color: #78350f; line-height: 1.8;">
                            <li><strong>tr2_ph:</strong> Seuil de convergence (1.0d-14 recommandé)</li>
                            <li><strong>prefix:</strong> Doit correspondre au calcul SCF</li>
                            <li><strong>ldisp = .true.:</strong> Pour calculer sur une grille de points q</li>
                            <li><strong>nq1, nq2, nq3:</strong> Grille de points q (4×4×4 pour commencer)</li>
                            <li><strong>fildyn:</strong> Fichier de sortie des matrices dynamiques</li>
                            <li>⚠️ <strong>Temps:</strong> Peut prendre plusieurs heures!</li>
                        </ul>
                    </div>
                    
                    <div id="ph_loading_status" style="text-align: center; padding: 20px; color: #666;">
                        ⏳ Génération automatique de l'input depuis le calcul SCF...
                    </div>
                    
                    <textarea id="input_ph_editor" style="width: 100%; height: 350px; font-family: 'Courier New', monospace; padding: 15px; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 0.95em; line-height: 1.5; display: none;">
&inputph
  tr2_ph = 1.0d-14
  prefix = '${mat.toLowerCase()}'
  outdir = '/home/hiadsi/Interface-QE_v1/outputs/${mat}/'
  fildyn = '${mat.toLowerCase()}.dyn'
  ldisp = .true.
  nq1 = 4
  nq2 = 4
  nq3 = 4
/
                    </textarea>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 20px;">
                        <button onclick="sauvegarderInputPH()" style="padding: 15px; background: linear-gradient(135deg, #10b981, #059669); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em;">
                            💾 Sauvegarder l'Input
                        </button>
                        <button onclick="lancerCalculPH()" style="padding: 15px; background: linear-gradient(135deg, #ec4899, #db2777); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em;">
                            🚀 Lancer PH.X
                        </button>
                        <button onclick="ouvrirTerminalCalcul('BaTiO3', 'ph')" style="margin-left: 10px; padding: 15px; background: linear-gradient(135deg, #64748b, #475569); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em;">
                            🖥️ Terminal
                        </button>
                        <button onclick="ouvrirTerminalCalcul('BaTiO3', 'ph')" style="margin-left: 10px; padding: 15px; background: linear-gradient(135deg, #64748b, #475569); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em;">
                            🖥️ Terminal
                        </button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        
        // Tenter de générer automatiquement l'input depuis le SCF
        try {
            const response = await fetch('http://localhost:5007/api/generer_input_phonon', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ materiau: mat })
            });
            
            const data = await response.json();
            const textarea = document.getElementById('input_ph_editor');
            const loadingDiv = document.getElementById('ph_loading_status');
            
            if (data.status === 'success') {
                textarea.value = data.input_content;
                loadingDiv.innerHTML = '<span style="color: #10b981;">✅ Input généré automatiquement depuis le calcul SCF</span>';
            } else {
                loadingDiv.innerHTML = '<span style="color: #f59e0b;">⚠️ ' + data.error + ' - Utilisez le template par défaut</span>';
            }
            
            // Afficher le textarea après chargement
            setTimeout(() => {
                textarea.style.display = 'block';
                loadingDiv.style.display = 'none';
            }, 1000);
            
        } catch (error) {
            console.error('Erreur génération input PH:', error);
            const textarea = document.getElementById('input_ph_editor');
            const loadingDiv = document.getElementById('ph_loading_status');
            loadingDiv.innerHTML = '<span style="color: #ef4444;">❌ Erreur de génération - Utilisez le template par défaut</span>';
            textarea.style.display = 'block';
        }
    };
    
    // Éditeur Q2R.X avec recommandations
    window.ouvrirEditeurPhononsQ2R = function() {
        const mat = window.materiauPhononsSelectionne || 'materiau';
        
        const modal = document.createElement('div');
        modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.85); z-index: 10000; display: flex; align-items: center; justify-content: center; padding: 20px;';
        modal.innerHTML = `
            <div style="background: white; border-radius: 15px; max-width: 1000px; width: 100%; max-height: 95vh; display: flex; flex-direction: column;">
                <div style="padding: 20px; border-bottom: 2px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center; background: linear-gradient(135deg, #8b5cf6, #7c3aed); color: white; border-radius: 15px 15px 0 0;">
                    <h3 style="margin: 0;">📊 Q2R.X - Matrices de Force</h3>
                    <button onclick="this.closest('div[style*=position]').remove()" style="background: rgba(255,255,255,0.2); color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: 600;">❌ Fermer</button>
                </div>
                <div style="padding: 20px; overflow-y: auto; flex: 1;">
                    <div style="background: #dbeafe; padding: 15px; border-radius: 10px; border-left: 4px solid #3b82f6; margin-bottom: 20px;">
                        <strong style="color: #1e40af;">📋 Recommandations Q2R.X:</strong>
                        <ul style="margin: 10px 0 0 20px; color: #1e3a8a; line-height: 1.8;">
                            <li><strong>fildyn:</strong> Fichier .dyn généré par PH.X</li>
                            <li><strong>flfrc:</strong> Fichier de sortie des constantes de force</li>
                            <li><strong>zasr:</strong> Règle de somme acoustique ('simple' ou 'crystal')</li>
                            <li>⚠️ <strong>Prérequis:</strong> PH.X doit être terminé!</li>
                        </ul>
                    </div>
                    
                    <textarea id="input_q2r_editor" style="width: 100%; height: 250px; font-family: 'Courier New', monospace; padding: 15px; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 0.95em; line-height: 1.5;">
&input
  fildyn = '${mat.toLowerCase()}.dyn'
  flfrc = '${mat.toLowerCase()}.fc'
  zasr = 'simple'
/
                    </textarea>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 20px;">
                        <button onclick="sauvegarderInputQ2R()" style="padding: 15px; background: linear-gradient(135deg, #10b981, #059669); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em;">
                            💾 Sauvegarder l'Input
                        </button>
                        <button onclick="lancerCalculQ2R()" style="padding: 15px; background: linear-gradient(135deg, #8b5cf6, #7c3aed); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em;">
                            🚀 Lancer Q2R.X
                        </button>
                        <button onclick="ouvrirTerminalCalcul('BaTiO3', 'q2r')" style="margin-left: 10px; padding: 15px; background: linear-gradient(135deg, #64748b, #475569); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em;">
                            🖥️ Terminal
                        </button>
                        <button onclick="ouvrirTerminalCalcul('BaTiO3', 'q2r')" style="margin-left: 10px; padding: 15px; background: linear-gradient(135deg, #64748b, #475569); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em;">
                            🖥️ Terminal
                        </button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    };
    
    // Éditeur MATDYN.X avec recommandations
    window.ouvrirEditeurPhononsMatdyn = function() {
        const mat = window.materiauPhononsSelectionne || 'materiau';
        
        const modal = document.createElement('div');
        modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.85); z-index: 10000; display: flex; align-items: center; justify-content: center; padding: 20px;';
        modal.innerHTML = `
            <div style="background: white; border-radius: 15px; max-width: 1000px; width: 100%; max-height: 95vh; display: flex; flex-direction: column;">
                <div style="padding: 20px; border-bottom: 2px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center; background: linear-gradient(135deg, #06b6d4, #0891b2); color: white; border-radius: 15px 15px 0 0;">
                    <h3 style="margin: 0;">📈 MATDYN.X - Dispersion des Phonons</h3>
                    <button onclick="this.closest('div[style*=position]').remove()" style="background: rgba(255,255,255,0.2); color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: 600;">❌ Fermer</button>
                </div>
                <div style="padding: 20px; overflow-y: auto; flex: 1;">
                    <div style="background: #cffafe; padding: 15px; border-radius: 10px; border-left: 4px solid #06b6d4; margin-bottom: 20px;">
                        <strong style="color: #0e7490;">📋 Recommandations MATDYN.X:</strong>
                        <ul style="margin: 10px 0 0 20px; color: #155e75; line-height: 1.8;">
                            <li><strong>flfrc:</strong> Fichier .fc généré par Q2R.X</li>
                            <li><strong>flfrq:</strong> Fichier de sortie des fréquences</li>
                            <li><strong>q_in_band_form:</strong> .true. pour calculer le long d'un chemin</li>
                            <li><strong>Chemin k:</strong> Points de haute symétrie (Γ, X, M, etc.)</li>
                            <li>💡 <strong>Résultat:</strong> Courbes de dispersion des phonons</li>
                        </ul>
                    </div>
                    
                    <textarea id="input_matdyn_editor" style="width: 100%; height: 350px; font-family: 'Courier New', monospace; padding: 15px; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 0.95em; line-height: 1.5;">
&input
  flfrc = '${mat.toLowerCase()}.fc'
  flfrq = '${mat.toLowerCase()}.freq'
  q_in_band_form = .true.
/
4
  0.0 0.0 0.0  50  ! Gamma
  0.5 0.0 0.0  50  ! X
  0.5 0.5 0.0  50  ! M
  0.0 0.0 0.0  1   ! Gamma
                    </textarea>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 20px;">
                        <button onclick="sauvegarderInputMatdyn()" style="padding: 15px; background: linear-gradient(135deg, #10b981, #059669); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em;">
                            💾 Sauvegarder l'Input
                        </button>
                        <button onclick="lancerCalculMatdyn()" style="padding: 15px; background: linear-gradient(135deg, #06b6d4, #0891b2); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em;">
                            🚀 Lancer MATDYN.X
                        </button>
                        <button onclick="ouvrirTerminalCalcul('BaTiO3', 'matdyn')" style="margin-left: 10px; padding: 15px; background: linear-gradient(135deg, #64748b, #475569); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em;">
                            🖥️ Terminal
                        </button>
                        <button onclick="ouvrirTerminalCalcul('BaTiO3', 'matdyn')" style="margin-left: 10px; padding: 15px; background: linear-gradient(135deg, #64748b, #475569); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 1em;">
                            🖥️ Terminal
                        </button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    };
    
    // Fonctions de sauvegarde et lancement
    window.sauvegarderInputPH = async function() {
        const content = document.getElementById('input_ph_editor').value;
        if (!content.trim()) {
            alert('❌ Le contenu est vide');
            return;
        }
        
        const materiau = window.materiauPhononsSelectionne || 'phonons';
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
        const filename = `${materiau}_ph_${timestamp}.in`;
        
        try {
            const response = await fetch('http://localhost:5007/api/sauvegarder_input', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    materiau: materiau,
                    type_calcul: 'ph',
                    contenu: content,
                    filename: filename
                })
            });
            
            const data = await response.json();
            if (data.status === 'success') {
                alert('✅ Input PH.X sauvegardé avec succès!\n\n📄 Fichier: ' + filename);
            } else {
                alert('❌ Erreur: ' + data.error);
            }
        } catch (error) {
            alert('❌ Erreur de sauvegarde: ' + error.message);
        }
    };
    
    window.sauvegarderInputQ2R = async function() {
        const content = document.getElementById('input_q2r_editor').value;
        if (!content.trim()) {
            alert('❌ Le contenu est vide');
            return;
        }
        
        const materiau = window.materiauPhononsSelectionne || 'phonons';
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
        const filename = `${materiau}_q2r_${timestamp}.in`;
        
        try {
            const response = await fetch('http://localhost:5007/api/sauvegarder_input', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    materiau: materiau,
                    type_calcul: 'q2r',
                    contenu: content,
                    filename: filename
                })
            });
            
            const data = await response.json();
            if (data.status === 'success') {
                alert('✅ Input Q2R.X sauvegardé avec succès!\n\n📄 Fichier: ' + filename);
            } else {
                alert('❌ Erreur: ' + data.error);
            }
        } catch (error) {
            alert('❌ Erreur de sauvegarde: ' + error.message);
        }
    };
    
    window.sauvegarderInputMatdyn = async function() {
        const content = document.getElementById('input_matdyn_editor').value;
        if (!content.trim()) {
            alert('❌ Le contenu est vide');
            return;
        }
        
        const materiau = window.materiauPhononsSelectionne || 'phonons';
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
        const filename = `${materiau}_matdyn_${timestamp}.in`;
        
        try {
            const response = await fetch('http://localhost:5007/api/sauvegarder_input', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    materiau: materiau,
                    type_calcul: 'matdyn',
                    contenu: content,
                    filename: filename
                })
            });
            
            const data = await response.json();
            if (data.status === 'success') {
                alert('✅ Input MATDYN.X sauvegardé avec succès!\n\n📄 Fichier: ' + filename);
            } else {
                alert('❌ Erreur: ' + data.error);
            }
        } catch (error) {
            alert('❌ Erreur de sauvegarde: ' + error.message);
        }
    };
    
    window.lancerCalculPH = async function() {
        const content = document.getElementById('input_ph_editor').value;
        if (!content.trim()) {
            alert('❌ Le contenu de l\'input est vide');
            return;
        }
        
        const confirmation = confirm('🚀 Lancer le calcul PH.X?\n\n⚠️ Ce calcul peut prendre plusieurs heures.\n\nLe fichier sera sauvegardé automatiquement.');
        if (!confirmation) return;
        
        const materiau = window.materiauPhononsSelectionne || 'phonons';
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
        const filename = `${materiau}_ph_${timestamp}.in`;
        
        try {
            // Étape 1: Sauvegarder l'input
            const saveResponse = await fetch('http://localhost:5007/api/sauvegarder_input', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    materiau: materiau,
                    type_calcul: 'ph',
                    contenu: content,
                    filename: filename
                })
            });
            
            const saveData = await saveResponse.json();
            if (!saveData.success) {
                alert('❌ Erreur de sauvegarde: ' + saveData.error);
                return;
            }
            
            // Utiliser le nom de fichier retourné par l'API (qui peut être différent)
            const savedFilename = saveData.fichier || filename;
            console.log('✅ Input sauvegardé:', savedFilename);
            
            // Étape 2: Lancer le calcul
            const launchResponse = await fetch('http://localhost:5007/api/lancer_calcul', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    fichier: savedFilename,
                    nprocs: 4
                })
            });
            
            const launchData = await launchResponse.json();
            
            if (launchData.success) {
                alert(`✅ Calcul PH.X lancé avec succès!\n\n` +
                      `📄 Input: ${savedFilename}\n` +
                      `📊 Output: ${launchData.output_file}\n` +
                      `🔧 Mode: ${launchData.mode}\n` +
                      `💻 Processeurs: 4\n\n` +
                      `Le calcul est en cours d'exécution.\n` +
                      `Utilisez "Suivi" pour voir la progression.`);
                
                // Fermer la modale
                const modal = document.querySelector('div[style*="position: fixed"]');
                if (modal && modal.innerHTML.includes('PH.X')) {
                    modal.remove();
                }
                
                // Optionnel : ouvrir le suivi
                if (typeof ouvrirSuiviCalcul === 'function') {
                    setTimeout(() => ouvrirSuiviCalcul(launchData.calcul_id, 'ph'), 500);
                }
            } else {
                alert('❌ Erreur de lancement: ' + launchData.error);
            }
            
        } catch (error) {
            console.error('❌ Erreur:', error);
            alert('❌ Erreur: ' + error.message);
        }
    };
    
    window.lancerCalculQ2R = async function() {
        const content = document.getElementById('input_q2r_editor').value;
        if (!content.trim()) {
            alert('❌ Le contenu de l\'input est vide');
            return;
        }
        
        const confirmation = confirm('🚀 Lancer le calcul Q2R.X?\n\nCe calcul est rapide (~2 minutes).');
        if (!confirmation) return;
        
        const materiau = window.materiauPhononsSelectionne || 'phonons';
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
        const filename = `${materiau}_q2r_${timestamp}.in`;
        
        try {
            // Sauvegarder et lancer
            const saveResponse = await fetch('http://localhost:5007/api/sauvegarder_input', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    materiau: materiau,
                    type_calcul: 'q2r',
                    contenu: content,
                    filename: filename
                })
            });
            
            const saveData = await saveResponse.json();
            if (!saveData.success) {
                alert('❌ Erreur de sauvegarde: ' + saveData.error);
                return;
            }
            
            const launchResponse = await fetch('http://localhost:5007/api/lancer_calcul', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    fichier: filename,
                    nprocs: 1
                })
            });
            
            const launchData = await launchResponse.json();
            
            if (launchData.success) {
                alert(`✅ Calcul Q2R.X lancé!\n\n📄 Input: ${filename}\n📊 Output: ${launchData.output_file}`);
                const modal = document.querySelector('div[style*="position: fixed"]');
                if (modal && modal.innerHTML.includes('Q2R.X')) modal.remove();
            } else {
                alert('❌ Erreur: ' + launchData.error);
            }
        } catch (error) {
            alert('❌ Erreur: ' + error.message);
        }
    };
    
    window.lancerCalculMatdyn = async function() {
        const content = document.getElementById('input_matdyn_editor').value;
        if (!content.trim()) {
            alert('❌ Le contenu de l\'input est vide');
            return;
        }
        
        const confirmation = confirm('🚀 Lancer le calcul MATDYN.X?\n\nCe calcul est rapide (~5 minutes).');
        if (!confirmation) return;
        
        const materiau = window.materiauPhononsSelectionne || 'phonons';
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
        const filename = `${materiau}_matdyn_${timestamp}.in`;
        
        try {
            // Sauvegarder et lancer
            const saveResponse = await fetch('http://localhost:5007/api/sauvegarder_input', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    materiau: materiau,
                    type_calcul: 'matdyn',
                    contenu: content,
                    filename: filename
                })
            });
            
            const saveData = await saveResponse.json();
            if (!saveData.success) {
                alert('❌ Erreur de sauvegarde: ' + saveData.error);
                return;
            }
            
            const launchResponse = await fetch('http://localhost:5007/api/lancer_calcul', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    fichier: filename,
                    nprocs: 1
                })
            });
            
            const launchData = await launchResponse.json();
            
            if (launchData.success) {
                alert(`✅ Calcul MATDYN.X lancé!\n\n📄 Input: ${filename}\n📊 Output: ${launchData.output_file}`);
                const modal = document.querySelector('div[style*="position: fixed"]');
                if (modal && modal.innerHTML.includes('MATDYN.X')) modal.remove();
            } else {
                alert('❌ Erreur: ' + launchData.error);
            }
        } catch (error) {
            alert('❌ Erreur: ' + error.message);
        }
    };
    
    console.log('✅ Workflow Phonons Amélioré V2 initialisé');
})();


// =====================================================
// SYSTÈME DE RECHERCHE DE MATÉRIAUX (MODE NATIF)
// =====================================================

// RECHERCHER LE MATÉRIAU
async function rechercherMateriau() {
    const champMateriau = document.getElementById('champ_materiau');
    const zoneResultats = document.getElementById('zone_resultats');
    
    if (!champMateriau || !zoneResultats) {
        console.error('Éléments de recherche non trouvés');
        return;
    }
    
    const materiau = champMateriau.value.trim();
    
    if (!materiau) {
        alert('⚠️ Veuillez entrer un nom de matériau');
        return;
    }
    
    // Loader
    zoneResultats.innerHTML = `
        <div style="text-align: center; padding: 40px;">
            <div style="display: inline-block; width: 50px; height: 50px; border: 4px solid #e5e7eb; border-top-color: #4f46e5; border-radius: 50%; animation: spin 1s linear infinite;"></div>
            <p style="margin-top: 15px; color: #6b7280; font-size: 1.1em;">🔍 Recherche de "${materiau}"...</p>
        </div>
    `;
    
    try {
        let inputsFichiers = [];
        let outputsFichiers = [];
        let inputsPath = '';
        let outputsPath = '';
        
        // STRATÉGIE 1: Chercher dans le sous-dossier spécifique
        const inputsDossier = `/home/hiadsi/génération_inputs-QE/inputs_générés_direct/${materiau}`;
        const outputsDossier = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}`;
        
        try {
            const resInputsDossier = await fetch('http://localhost:5007/api/lister_fichiers', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ directory: inputsDossier })
            });
            const dataInputs = await resInputsDossier.json();
            if (dataInputs.status === 'success' && dataInputs.files) {
                inputsFichiers = dataInputs.files
                    .filter(f => f.type === 'file' && f.name.endsWith('.in'))
                    .map(f => f.name);
                inputsPath = inputsDossier;
            }
        } catch (e) {
            console.log('Pas de sous-dossier inputs/', materiau);
        }
        
        try {
            const resOutputsDossier = await fetch('http://localhost:5007/api/lister_fichiers', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ directory: outputsDossier })
            });
            const dataOutputs = await resOutputsDossier.json();
            if (dataOutputs.status === 'success' && dataOutputs.files) {
                outputsFichiers = dataOutputs.files
                    .filter(f => f.type === 'file' && f.name.endsWith('.out'))
                    .map(f => f.name);
                outputsPath = outputsDossier;
            }
        } catch (e) {
            console.log('Pas de sous-dossier outputs/', materiau);
        }
        
        // STRATÉGIE 2: Si rien trouvé, chercher dans les fichiers directs
        if (inputsFichiers.length === 0) {
            try {
                const resInputsRoot = await fetch('http://localhost:5007/api/lister_fichiers', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ directory: '/home/hiadsi/Interface-QE_v1/inputs' })
                });
                const dataInputs = await resInputsRoot.json();
                if (dataInputs.status === 'success' && dataInputs.files) {
                    const materiauLower = materiau.toLowerCase();
                    inputsFichiers = dataInputs.files
                        .filter(f => f.type === 'file' && 
                               f.name.toLowerCase().startsWith(materiauLower) && 
                               f.name.endsWith('.in'))
                        .map(f => f.name);
                    inputsPath = '/home/hiadsi/Interface-QE_v1/inputs';
                }
            } catch (e) {
                console.error('Erreur lecture inputs root:', e);
            }
        }
        
        if (outputsFichiers.length === 0) {
            try {
                const resOutputsRoot = await fetch('http://localhost:5007/api/lister_fichiers', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ directory: '/home/hiadsi/Interface-QE_v1/outputs' })
                });
                const dataOutputs = await resOutputsRoot.json();
                if (dataOutputs.status === 'success' && dataOutputs.files) {
                    const materiauLower = materiau.toLowerCase();
                    outputsFichiers = dataOutputs.files
                        .filter(f => f.type === 'file' && 
                               f.name.toLowerCase().startsWith(materiauLower) && 
                               f.name.endsWith('.out'))
                        .map(f => f.name);
                    outputsPath = '/home/hiadsi/Interface-QE_v1/outputs';
                }
            } catch (e) {
                console.error('Erreur lecture outputs root:', e);
            }
        }
        
        // Afficher résultats
        const inputsExiste = inputsFichiers.length > 0;
        const outputsExiste = outputsFichiers.length > 0;
        
        if (inputsExiste || outputsExiste) {
            afficherResultatsRecherche(materiau, inputsExiste, inputsFichiers, inputsPath, outputsExiste, outputsFichiers, outputsPath);
        } else {
            afficherNonTrouve(materiau);
        }
        
    } catch (error) {
        zoneResultats.innerHTML = `
            <div style="background: #fee2e2; padding: 20px; border-radius: 10px; border-left: 4px solid #ef4444; text-align: center;">
                <strong style="color: #991b1b;">❌ Erreur: ${error.message}</strong>
                <p style="margin: 10px 0 0 0; color: #7f1d1d;">Vérifiez que l'API est démarrée</p>
            </div>
        `;
    }
}

// AFFICHER RÉSULTATS (trouvé)
function afficherResultatsRecherche(materiau, inputsExiste, inputsFichiers, inputsPath, outputsExiste, outputsFichiers, outputsPath) {
    const zoneResultats = document.getElementById('zone_resultats');
    if (!zoneResultats) return;
    
    let html = `
        <div style="background: linear-gradient(135deg, #d1fae5, #a7f3d0); padding: 25px; border-radius: 12px; border-left: 4px solid #10b981; margin-bottom: 25px;">
            <h3 style="margin: 0 0 10px 0; color: #065f46;">✅ Matériau "${materiau}" trouvé !</h3>
            <p style="margin: 0; color: #047857; font-size: 1.05em;">Les fichiers ont été localisés dans le système.</p>
        </div>
    `;
    
    // Section INPUTS
    html += `<div style="background: #f8fafc; padding: 25px; border-radius: 12px; margin-bottom: 20px; border: 2px solid #e2e8f0;">`;
    html += `<h4 style="margin: 0 0 15px 0; color: #1e293b; font-size: 1.3em;">📄 Fichiers INPUT</h4>`;
    
    if (inputsExiste) {
        html += `<p style="margin: 0 0 15px 0; color: #475569;"><strong>Dossier:</strong> <code style="background: #e2e8f0; padding: 4px 8px; border-radius: 4px;">${inputsPath}</code></p>`;
        html += `<div style="display: flex; flex-direction: column; gap: 10px;">`;
        inputsFichiers.forEach(fichier => {
            html += `
                <div style="display: flex; justify-content: space-between; align-items: center; background: white; padding: 15px 20px; border-radius: 8px; border: 1px solid #cbd5e1;">
                    <span style="font-family: 'JetBrains Mono', monospace; color: #334155; font-weight: 500;">${fichier}</span>
                    <button onclick="voirFichier('${inputsPath}/${fichier}')" style="padding: 8px 16px; background: linear-gradient(135deg, #10b981, #059669); color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600;">
                        👁️ Voir
                    </button>
                </div>
            `;
        });
        html += `</div>`;
    } else {
        html += `
            <p style="margin: 0 0 15px 0; color: #64748b;">Aucun fichier input trouvé pour ce matériau.</p>
            <button onclick='ouvrirFormulaireGenerationPourMateriau(${JSON.stringify(materiau)})' style="padding: 12px 20px; background: linear-gradient(135deg, #f59e0b, #d97706); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">
                🚀 Générer Input
            </button>
        `;
    }
    html += `</div>`;
    
    // Section OUTPUTS
    html += `<div style="background: #f8fafc; padding: 25px; border-radius: 12px; border: 2px solid #e2e8f0;">`;
    html += `<h4 style="margin: 0 0 15px 0; color: #1e293b; font-size: 1.3em;">📊 Fichiers OUTPUT</h4>`;
    
    if (outputsExiste) {
        html += `<p style="margin: 0 0 15px 0; color: #475569;"><strong>Dossier:</strong> <code style="background: #e2e8f0; padding: 4px 8px; border-radius: 4px;">${outputsPath}</code></p>`;
        html += `<div style="display: flex; flex-direction: column; gap: 10px;">`;
        outputsFichiers.forEach(fichier => {
            html += `
                <div style="display: flex; justify-content: space-between; align-items: center; background: white; padding: 15px 20px; border-radius: 8px; border: 1px solid #cbd5e1;">
                    <span style="font-family: 'JetBrains Mono', monospace; color: #334155; font-weight: 500;">${fichier}</span>
                    <button onclick="voirFichier('${outputsPath}/${fichier}')" style="padding: 8px 16px; background: linear-gradient(135deg, #3b82f6, #2563eb); color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600;">
                        👁️ Voir
                    </button>
                </div>
            `;
        });
        html += `</div>`;
    } else {
        html += `<p style="margin: 0; color: #64748b;">Aucun fichier output trouvé pour ce matériau.</p>`;
    }
    html += `</div>`;
    
    zoneResultats.innerHTML = html;
}

// AFFICHER NON TROUVÉ
function afficherNonTrouve(materiau) {
    const zoneResultats = document.getElementById('zone_resultats');
    if (!zoneResultats) return;
    
    zoneResultats.innerHTML = `
        <div style="background: #fef3c7; padding: 30px; border-radius: 12px; border-left: 4px solid #f59e0b; text-align: center;">
            <h3 style="margin: 0 0 15px 0; color: #92400e;">❌ Matériau "${materiau}" non trouvé</h3>
            <p style="margin: 0 0 20px 0; color: #78350f; font-size: 1.05em;">
                Aucun fichier n'a été trouvé dans les dossiers <code style="background: rgba(0,0,0,0.1); padding: 3px 8px; border-radius: 4px;">/inputs/</code> et <code style="background: rgba(0,0,0,0.1); padding: 3px 8px; border-radius: 4px;">/outputs/</code>
            </p>
            <button onclick='ouvrirFormulaireGenerationPourMateriau(${JSON.stringify(materiau)})' style="padding: 15px 30px; background: linear-gradient(135deg, #4f46e5, #7c3aed); color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 700; font-size: 1.1em; box-shadow: 0 4px 15px rgba(79,70,229,0.4);">
                🚀 Générer Input pour ${materiau}
            </button>
        </div>
    `;
}

// Fonction pour voir un fichier (placeholder - à adapter selon votre interface)
function voirFichier(chemin) {
    console.log('Voir fichier:', chemin);
    alert(`Ouverture du fichier: ${chemin}`);
    // TODO: Implémenter l'ouverture/affichage du fichier
}

// Recherche matériaux sans fichiers : ouvre le formulaire manuel pw.x sans écraser window.genererInput()
function ouvrirFormulaireGenerationPourMateriau(materiau) {
    var raw = (materiau == null ? '' : String(materiau)).trim();
    var slug = raw.replace(/\s+/g, '_').replace(/[^a-zA-Z0-9._-]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '').slice(0, 96);
    if (typeof switchTab === 'function') switchTab(0);
    if (typeof afficherSousSection === 'function') afficherSousSection('generation');
    if (slug) {
        var pref = document.getElementById('prefix');
        var sys = document.getElementById('system_name');
        if (pref) pref.value = slug;
        if (sys) sys.value = raw;
    }
    var gs = document.getElementById('generation_status');
    if (gs) {
        gs.innerHTML = '<div class="alert alert-info" style="margin:0;line-height:1.45;"><strong>Génération manuelle pw.x</strong> : préfixe et nom de système sont pré-remplis. Complétez les champs (<code>ATOMIC_SPECIES</code>, positions, etc.), puis le bouton vert <strong>GÉNÉRER L\'INPUT QE (pw.x)</strong>.</div>';
    }
    var btn = document.getElementById('btn_generer_input_pwx');
    if (btn && btn.scrollIntoView) btn.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// =====================================================
// FONCTION DE RECHERCHE DE MATÉRIAUX POUR LES WORKFLOWS
// =====================================================
window.rechercherMateriau = async function(workflow) {
    const champMateriau = document.getElementById(`champ_materiau_${workflow}`);
    const zoneSelection = document.getElementById(`zone_selection_materiau_${workflow}`);
    
    if (!champMateriau || !zoneSelection) {
        console.error('Éléments de recherche non trouvés pour:', workflow);
        return;
    }
    
    const materiau = champMateriau.value.trim();
    
    if (!materiau) {
        zoneSelection.innerHTML = `
            <div style="background: #fef3c7; padding: 20px; border-radius: 10px; border-left: 4px solid #f59e0b; text-align: center;">
                <strong style="color: #92400e;">⚠️ Veuillez entrer un nom de matériau</strong>
                <p style="margin: 10px 0 0 0; color: #78350f;">Exemple: ZnO, BaFeO3, Si, GaN, PrAlO3...</p>
            </div>
        `;
        return;
    }
    
    // Loader
    zoneSelection.innerHTML = `
        <div style="text-align: center; padding: 40px;">
            <div style="display: inline-block; width: 50px; height: 50px; border: 4px solid #e5e7eb; border-top-color: #4f46e5; border-radius: 50%; animation: spin 1s linear infinite;"></div>
            <p style="margin-top: 15px; color: #6b7280; font-size: 1.1em;">🔍 Recherche de "${materiau}"...</p>
        </div>
    `;
    
    try {
        const API_URL = 'http://localhost:5007';
        let inputsFichiers = [];
        let outputsFichiers = [];
        let inputsPath = '';
        let outputsPath = '';
        
        // STRATÉGIE 1: Chercher dans le sous-dossier spécifique
        const inputsDossier = `/home/hiadsi/génération_inputs-QE/inputs_générés_direct/${materiau}`;
        const outputsDossier = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}`;
        
        try {
            const resInputsDossier = await fetch(`${API_URL}/api/lister_fichiers`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ directory: inputsDossier })
            });
            const dataInputs = await resInputsDossier.json();
            if (dataInputs.status === 'success' && dataInputs.files) {
                inputsFichiers = dataInputs.files
                    .filter(f => f.type === 'file' && f.name.endsWith('.in'))
                    .map(f => f.name);
                inputsPath = inputsDossier;
            }
        } catch (e) {
            console.log('Pas de sous-dossier inputs/', materiau);
        }
        
        try {
            const resOutputsDossier = await fetch(`${API_URL}/api/lister_fichiers`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ directory: outputsDossier })
            });
            const dataOutputs = await resOutputsDossier.json();
            if (dataOutputs.status === 'success' && dataOutputs.files) {
                outputsFichiers = dataOutputs.files
                    .filter(f => f.type === 'file' && f.name.endsWith('.out'))
                    .map(f => f.name);
                outputsPath = outputsDossier;
            }
        } catch (e) {
            console.log('Pas de sous-dossier outputs/', materiau);
        }
        
        // STRATÉGIE 2: Si rien trouvé, chercher dans les fichiers directs
        if (inputsFichiers.length === 0) {
            try {
                const resInputsRoot = await fetch(`${API_URL}/api/lister_fichiers`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ directory: '/home/hiadsi/Interface-QE_v1/inputs' })
                });
                const dataInputs = await resInputsRoot.json();
                if (dataInputs.status === 'success' && dataInputs.files) {
                    const materiauLower = materiau.toLowerCase();
                    inputsFichiers = dataInputs.files
                        .filter(f => f.type === 'file' && 
                               f.name.toLowerCase().startsWith(materiauLower) && 
                               f.name.endsWith('.in'))
                        .map(f => f.name);
                    inputsPath = '/home/hiadsi/Interface-QE_v1/inputs';
                }
            } catch (e) {
                console.error('Erreur lecture inputs root:', e);
            }
        }
        
        if (outputsFichiers.length === 0) {
            try {
                const resOutputsRoot = await fetch(`${API_URL}/api/lister_fichiers`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ directory: '/home/hiadsi/Interface-QE_v1/outputs' })
                });
                const dataOutputs = await resOutputsRoot.json();
                if (dataOutputs.status === 'success' && dataOutputs.files) {
                    const materiauLower = materiau.toLowerCase();
                    outputsFichiers = dataOutputs.files
                        .filter(f => f.type === 'file' && 
                               f.name.toLowerCase().startsWith(materiauLower) && 
                               f.name.endsWith('.out'))
                        .map(f => f.name);
                    outputsPath = '/home/hiadsi/Interface-QE_v1/outputs';
                }
            } catch (e) {
                console.error('Erreur lecture outputs root:', e);
            }
        }
        
        // Afficher résultats
        const inputsExiste = inputsFichiers.length > 0;
        const outputsExiste = outputsFichiers.length > 0;
        
        if (inputsExiste || outputsExiste) {
            afficherResultatsRecherche(workflow, materiau, inputsExiste, inputsFichiers, inputsPath, outputsExiste, outputsFichiers, outputsPath);
        } else {
            afficherNonTrouveWorkflow(workflow, materiau);
        }
        
    } catch (error) {
        zoneSelection.innerHTML = `
            <div style="background: #fee2e2; padding: 20px; border-radius: 10px; border-left: 4px solid #ef4444; text-align: center;">
                <strong style="color: #991b1b;">❌ Erreur: ${error.message}</strong>
                <p style="margin: 10px 0 0 0; color: #7f1d1d;">Vérifiez que l'API est démarrée</p>
            </div>
        `;
    }
};

// AFFICHER RÉSULTATS (trouvé) - avec système d'accordéon replier/déplier
window.afficherResultatsRecherche = function(workflow, materiau, inputsExiste, inputsFichiers, inputsPath, outputsExiste, outputsFichiers, outputsPath) {
    const zoneSelection = document.getElementById(`zone_selection_materiau_${workflow}`);
    if (!zoneSelection) return;
    
    const idInputs = `liste_inputs_${workflow}`;
    const idOutputs = `liste_outputs_${workflow}`;
    
    let html = `
        <div style="background: linear-gradient(135deg, #d1fae5, #a7f3d0); padding: 25px; border-radius: 12px; border-left: 4px solid #10b981; margin-bottom: 25px;">
            <h4 style="margin: 0 0 10px 0; color: #065f46;">✅ Matériau "${materiau}" trouvé !</h4>
            <p style="margin: 0; color: #047857; font-size: 1.05em;">Les fichiers ont été localisés dans le système.</p>
        </div>
    `;
    
    // Section INPUTS avec accordéon
    html += `<div style="background: #f8fafc; padding: 20px; border-radius: 12px; margin-bottom: 20px; border: 2px solid #e2e8f0;">`;
    
    if (inputsExiste) {
        // En-tête cliquable pour déplier/replier
        html += `
            <div onclick="toggleAccordion('${idInputs}')" style="display: flex; justify-content: space-between; align-items: center; cursor: pointer; padding: 10px; background: white; border-radius: 8px; margin-bottom: 15px; border: 1px solid #cbd5e1;">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span id="${idInputs}_icon" style="font-size: 1.2em; transition: transform 0.3s;">▶</span>
                    <h5 style="margin: 0; color: #1e293b; font-size: 1.2em;">📄 Fichiers INPUT (${inputsFichiers.length})</h5>
                </div>
                <span style="color: #64748b; font-size: 0.9em;">Cliquez pour afficher/masquer</span>
            </div>
        `;
        
        // Contenu repliable (caché par défaut)
        html += `<div id="${idInputs}" style="display: none; margin-bottom: 15px;">`;
        html += `<p style="margin: 0 0 15px 0; color: #475569; font-size: 0.9em;"><strong>Dossier:</strong> <code style="background: #e2e8f0; padding: 3px 8px; border-radius: 4px;">${inputsPath}</code></p>`;
        html += `<div style="display: flex; flex-direction: column; gap: 10px;">`;
        inputsFichiers.forEach(fichier => {
            html += `
                <div style="display: flex; justify-content: space-between; align-items: center; background: white; padding: 12px 15px; border-radius: 8px; border: 1px solid #cbd5e1;">
                    <span style="font-family: 'JetBrains Mono', monospace; color: #334155; font-weight: 500; font-size: 0.95em;">${fichier}</span>
                </div>
            `;
        });
        html += `</div>`;
        html += `</div>`;
        
        // Bouton pour sélectionner le matériau
        html += `
            <button onclick="selectionnerMateriauWorkflow('${workflow}', '${materiau}')" style="margin-top: 10px; padding: 12px 24px; background: linear-gradient(135deg, #10b981, #059669); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 700; width: 100%; font-size: 1.1em;">
                ✅ Sélectionner ce matériau
            </button>
        `;
    } else {
        html += `<h5 style="margin: 0 0 10px 0; color: #1e293b; font-size: 1.2em;">📄 Fichiers INPUT</h5>`;
        html += `<p style="margin: 0; color: #64748b;">Aucun fichier input trouvé pour ce matériau.</p>`;
    }
    html += `</div>`;
    
    // Section OUTPUTS avec accordéon (si présents)
    if (outputsExiste) {
        html += `<div style="background: #f8fafc; padding: 20px; border-radius: 12px; border: 2px solid #e2e8f0;">`;
        
        // En-tête cliquable pour déplier/replier
        html += `
            <div onclick="toggleAccordion('${idOutputs}')" style="display: flex; justify-content: space-between; align-items: center; cursor: pointer; padding: 10px; background: white; border-radius: 8px; margin-bottom: 15px; border: 1px solid #cbd5e1;">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span id="${idOutputs}_icon" style="font-size: 1.2em; transition: transform 0.3s;">▶</span>
                    <h5 style="margin: 0; color: #1e293b; font-size: 1.2em;">📊 Fichiers OUTPUT (${outputsFichiers.length})</h5>
                </div>
                <span style="color: #64748b; font-size: 0.9em;">Cliquez pour afficher/masquer</span>
            </div>
        `;
        
        // Contenu repliable (caché par défaut)
        html += `<div id="${idOutputs}" style="display: none;">`;
        html += `<p style="margin: 0 0 15px 0; color: #475569; font-size: 0.9em;"><strong>Dossier:</strong> <code style="background: #e2e8f0; padding: 3px 8px; border-radius: 4px;">${outputsPath}</code></p>`;
        html += `<div style="display: flex; flex-direction: column; gap: 10px;">`;
        outputsFichiers.slice(0, 10).forEach(fichier => {
            html += `
                <div style="display: flex; justify-content: space-between; align-items: center; background: white; padding: 12px 15px; border-radius: 8px; border: 1px solid #cbd5e1;">
                    <span style="font-family: 'JetBrains Mono', monospace; color: #334155; font-weight: 500; font-size: 0.95em;">${fichier}</span>
                </div>
            `;
        });
        html += `</div>`;
        if (outputsFichiers.length > 10) {
            html += `<p style="margin: 10px 0 0 0; color: #64748b; font-size: 0.9em;">... et ${outputsFichiers.length - 10} autre(s) fichier(s)</p>`;
        }
        html += `</div>`;
        html += `</div>`;
    }
    
    zoneSelection.innerHTML = html;
};

// Fonction pour gérer l'accordéon (déplier/replier)
window.toggleAccordion = function(id) {
    const content = document.getElementById(id);
    const icon = document.getElementById(id + '_icon');
    
    if (!content || !icon) return;
    
    if (content.style.display === 'none') {
        content.style.display = 'block';
        icon.textContent = '▼';
        icon.style.transform = 'rotate(0deg)';
    } else {
        content.style.display = 'none';
        icon.textContent = '▶';
        icon.style.transform = 'rotate(0deg)';
    }
};

// AFFICHER NON TROUVÉ
window.afficherNonTrouveWorkflow = function(workflow, materiau) {
    const zoneSelection = document.getElementById(`zone_selection_materiau_${workflow}`);
    if (!zoneSelection) return;
    
    zoneSelection.innerHTML = `
        <div style="background: #fef3c7; padding: 30px; border-radius: 12px; border-left: 4px solid #f59e0b; text-align: center;">
            <h4 style="margin: 0 0 15px 0; color: #92400e;">❌ Matériau "${materiau}" non trouvé</h4>
            <p style="margin: 0 0 20px 0; color: #78350f; font-size: 1.05em;">
                Aucun fichier n'a été trouvé dans les dossiers <code style="background: rgba(0,0,0,0.1); padding: 3px 8px; border-radius: 4px;">/inputs/</code> et <code style="background: rgba(0,0,0,0.1); padding: 3px 8px; border-radius: 4px;">/outputs/</code>
            </p>
            <p style="margin: 0 0 15px 0; color: #78350f;">Vous devez d'abord générer un input pour ce matériau depuis l'Onglet 1.</p>
        </div>
    `;
};

// Fonction pour sélectionner un matériau dans un workflow
window.selectionnerMateriauWorkflow = async function(workflow, materiau) {
    console.log(`✅ Matériau "${materiau}" sélectionné pour le workflow: ${workflow}`);
    
    // Stocker le nom du matériau pour les boutons (créer l'élément s'il n'existe pas)
    let nomMateriauEl = document.getElementById(`nom_materiau_${workflow}`);
    if (!nomMateriauEl) {
        nomMateriauEl = document.createElement('span');
        nomMateriauEl.id = `nom_materiau_${workflow}`;
        nomMateriauEl.style.display = 'none';
        document.body.appendChild(nomMateriauEl);
    }
    nomMateriauEl.textContent = materiau;
    
    // Afficher l'info du matériau sélectionné
    const zoneInfo = document.getElementById(`zone_info_materiau_${workflow}`);
    if (zoneInfo) {
        zoneInfo.style.display = 'block';
        zoneInfo.innerHTML = `
            <div style="background: linear-gradient(135deg, #d1fae5, #a7f3d0); padding: 20px; border-radius: 12px; border-left: 4px solid #10b981;">
                <h5 style="margin: 0 0 10px 0; color: #065f46;">✅ Matériau sélectionné</h5>
                <p style="margin: 0; color: #047857; font-size: 1.1em; font-weight: 600;">${materiau}</p>
            </div>
        `;
    }
    
    // Afficher directement l'étape 2: Liste des calculs du workflow (prérequis + finaux)
    const zoneCalculs = document.getElementById(`zone_calculs_${workflow}`);
    if (zoneCalculs) {
        zoneCalculs.style.display = 'block';
        console.log(`✅ Affichage des calculs pour ${workflow}`);
    } else {
        console.warn(`❌ Zone calculs non trouvée pour ${workflow}`);
    }
};

// =====================================================
// NOTE: Les fonctions de vérification des prérequis ont été supprimées
// car tous les calculs sont maintenant affichés directement dans le HTML.
// =====================================================

// =====================================================
// ÉTAPE 3: LISTE DES CALCULS DU WORKFLOW
// =====================================================
window.afficherEtape3Workflow = function(workflow, materiau) {
    const zoneEtape3 = document.getElementById(`zone_calculs_${workflow}`);
    if (!zoneEtape3) {
        console.warn(`Zone calculs non trouvée pour ${workflow}`);
        return;
    }
    
    zoneEtape3.style.display = 'block';
    
    // Définir les calculs selon le workflow
    const calculsWorkflow = getCalculsWorkflow(workflow, materiau);
    
    let html = `
        <div class="card" style="border: 2px solid #8b5cf6; margin-bottom: 25px;">
            <h4 style="margin: 0 0 20px 0; display: flex; align-items: center; gap: 10px;">
                <span style="background: #8b5cf6; color: white; padding: 8px 16px; border-radius: 8px; font-size: 0.9em;">Étape 3</span>
                <span>Calculs du Workflow ${workflow.toUpperCase()}</span>
            </h4>
            
            <div style="display: flex; flex-direction: column; gap: 20px;">
    `;
    
    calculsWorkflow.forEach((calcul, index) => {
        html += `
            <div style="background: #f8fafc; padding: 20px; border-radius: 12px; border: 2px solid #e2e8f0;">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 15px;">
                    <div style="flex: 1;">
                        <h5 style="margin: 0 0 10px 0; color: #1e293b; font-size: 1.1em;">
                            ${index + 1}. ${calcul.icon} ${calcul.nom}
                        </h5>
                        <p style="margin: 0 0 10px 0; color: #64748b; font-size: 0.95em;">${calcul.description}</p>
                        
                        <!-- Recommandations -->
                        <div style="background: #fef3c7; padding: 12px; border-radius: 8px; border-left: 4px solid #f59e0b; margin-bottom: 15px;">
                            <strong style="color: #92400e;">💡 Recommandations:</strong>
                            <ul style="margin: 8px 0 0 0; padding-left: 20px; color: #78350f; font-size: 0.9em;">
                                ${calcul.recommandations.map(r => `<li>${r}</li>`).join('')}
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Boutons d'action -->
                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <button onclick="editerCalcul('${workflow}', '${materiau}', '${calcul.type}')" style="flex: 1; min-width: 150px; padding: 12px 20px; background: linear-gradient(135deg, #3b82f6, #2563eb); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 8px;">
                        ✏️ Éditer
                    </button>
                    <div style="display: flex; gap: 10px; margin: 10px 0;">
                                <div style="display: flex; gap: 10px; margin: 10px 0;">
                                <div style="display: flex; gap: 10px; margin: 10px 0;">
                                <div style="display: flex; gap: 10px; margin: 10px 0;">
                                <button onclick="lancerCalcul('phonons', '${materiau}', '${calcul.type}')" 
                                        class="btn btn-success" style="flex: 1;">
                                    🚀 Lancer via Interface
                                </button>
                    <button onclick="ouvrirTerminalCalcul('${materiau}', '${calcul.type}')" class="btn btn-secondary" style="margin-left: 10px;">
                        🖥️ Terminal
                    </button>
                    <button onclick="ouvrirTerminalCalcul('${materiau}', '${calcul.type}')" class="btn btn-secondary" style="margin-left: 10px;">
                        🖥️ Terminal
                    </button>
                                <button onclick="ouvrirTerminalCalcul('${materiau}', '${calcul.type}')" 
                                        class="btn btn-secondary" style="flex: 1;">
                                    🖥️ Lancer via Terminal
                                </button>
                            </div>
                                <button onclick="ouvrirTerminalCalcul('${materiau}', '${calcul.type}')" 
                                        class="btn btn-secondary" style="flex: 1;">
                                    🖥️ Lancer via Terminal
                                </button>
                            </div>
                                <button onclick="afficherCommandeTerminal('${materiau}', '${calcul.type}')" 
                                        class="btn btn-secondary" style="flex: 1;">
                                    🖥️ Lancer via Terminal
                                </button>
                            </div>
                                <button onclick="afficherCommandeTerminal('${materiau}', '${calcul.type}')" 
                                        class="btn btn-secondary" style="flex: 1;">
                                    🖥️ Lancer via Terminal
                                </button>
                            </div>
                    <button onclick="suivreCalcul('${workflow}', '${materiau}', '${calcul.type}')" style="flex: 1; min-width: 150px; padding: 12px 20px; background: linear-gradient(135deg, #f59e0b, #d97706); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 8px;">
                        📊 Suivi
                    </button>
                </div>
            </div>
        `;
    });
    
    html += `
            </div>
        </div>
    `;
    
    zoneEtape3.innerHTML = html;
};

// =====================================================
// FONCTION: ÉDITER UN INPUT DE CALCUL
// =====================================================
// ─── Helpers onglet Résultats ─────────────────────────────────────────────────

/** Retourne le nom du matériau saisi dans l'onglet Résultats selon le workflow */
function getMateriauResultat(workflow) {
    var ids = {
        'electronique': 'input_materiau_elec',
        'phonons':      'input_materiau_phonons',
        'optique':      'input_materiau_optique'
    };
    var el = document.getElementById(ids[workflow] || '');
    var val = el ? el.value.trim() : '';
    if (!val) {
        // Fallback : matériau sélectionné dans l'onglet Calculs
        var fb = document.getElementById('nom_materiau_' + workflow);
        val = fb ? fb.textContent.trim() : '';
    }
    if (!val) {
        alert('⚠️ Aucun matériau sélectionné.\nEntrez un nom dans le champ "Sélectionner le Matériau" puis cliquez "Charger".');
    }
    return val;
}

/** Affiche l'input file d'un calcul de post-traitement dans une fenêtre modale */
window.voirInputResultat = async function(workflow, typeCalcul, materiau) {
    if (!materiau) return;
    console.log(`👁️ Voir input: ${typeCalcul} — ${materiau} (${workflow})`);

    // Mapping type calcul → nom de fichier input typique
    var fichierMap = {
        'BANDS':       'bands.in',
        'DOS':         'dos.in',
        'PDOS':        'projwfc.in',
        'PLOTBAND':    'plotband.in',
        'SUMPDOS':     'sumpdos.in',
        'NSCF':        'nscf.in',
        'SCF':         'scf.in',
        'Q2R':         'q2r.in',
        'MATDYN':      'matdyn.in',
        'PLOTBAND_PH': 'plotband.in',
        'THERMO':      'matdyn_thermo.in',
        'EPSILON':     'epsilon.in',
        'ABSORPTION':  'epsilon.in',
        'REFLECTIVITE':'epsilon.in',
    };
    var nomFichier = fichierMap[typeCalcul] || (typeCalcul.toLowerCase() + '.in');

    try {
        var resp = await fetch('http://localhost:5007/api/lire_fichier', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ materiau: materiau, workflow: workflow, fichier: nomFichier })
        });
        var data = await resp.json();

        // Créer modale d'affichage
        var existant = document.getElementById('modal_voir_input_resultats');
        if (existant) existant.remove();

        var modal = document.createElement('div');
        modal.id = 'modal_voir_input_resultats';
        modal.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.7);z-index:9999;display:flex;align-items:center;justify-content:center;';

        var contenu = data.success ? data.contenu : ('❌ Fichier non trouvé : ' + nomFichier + '\n\nChemin cherché :\n' + (data.chemin || 'inconnu'));
        modal.innerHTML = `
            <div style="background:#0f172a;border-radius:12px;padding:24px;max-width:800px;width:90%;max-height:80vh;display:flex;flex-direction:column;border:1px solid #334155;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
                    <h3 style="margin:0;color:#e2e8f0;">👁️ ${nomFichier} — ${materiau} (${workflow})</h3>
                    <button onclick="document.getElementById('modal_voir_input_resultats').remove()"
                            style="background:#ef4444;color:white;border:none;border-radius:6px;padding:6px 14px;cursor:pointer;font-weight:700;">✕ Fermer</button>
                </div>
                <pre style="background:#1e293b;color:#a3e635;padding:16px;border-radius:8px;overflow-y:auto;flex:1;font-size:0.85em;font-family:'JetBrains Mono',monospace;white-space:pre-wrap;border:1px solid #334155;">${contenu.replace(/</g,'&lt;').replace(/>/g,'&gt;')}</pre>
                <div style="display:flex;gap:8px;margin-top:12px;">
                    <button onclick="window.editerCalcul('${workflow}','${typeCalcul}','${materiau}')"
                            style="padding:8px 16px;background:#f59e0b;color:white;border:none;border-radius:6px;cursor:pointer;font-weight:600;">✏️ Éditer</button>
                    <button onclick="navigator.clipboard.writeText(document.querySelector('#modal_voir_input_resultats pre').textContent)"
                            style="padding:8px 16px;background:#64748b;color:white;border:none;border-radius:6px;cursor:pointer;font-weight:600;">📋 Copier</button>
                    <button onclick="window.lancerCalcul('${workflow}','${materiau}','${typeCalcul}')"
                            style="padding:8px 16px;background:#10b981;color:white;border:none;border-radius:6px;cursor:pointer;font-weight:600;">🚀 Lancer</button>
                </div>
            </div>`;
        document.body.appendChild(modal);
        modal.addEventListener('click', function(e){ if(e.target===modal) modal.remove(); });

    } catch(e) {
        alert('Erreur lors de la lecture du fichier : ' + e.message);
    }
};

// ─────────────────────────────────────────────────────────────────────────────

window.editerCalcul = async function(workflow, typeCalcul, materiau) {
    console.log(`✏️ Édition du calcul ${typeCalcul} pour ${materiau} (workflow: ${workflow})`);
    
    // Vérifier que le matériau est sélectionné
    if (!materiau || materiau.trim() === '') {
        alert('⚠️ Aucun matériau sélectionné.\n\nMarche à suivre :\n1. Onglet "Calculs"\n2. Cliquez "Propriétés Électroniques" / "Phonons" / "Optiques"\n3. Entrez le nom du matériau → cliquez "Rechercher"\n4. Cliquez "✅ Sélectionner ce matériau"');
        return;
    }
    
    try {
        // Construire le nom du fichier input (sans tirets pour cohérence)
        const prefix = materiau.toLowerCase();
        const typeNom = typeCalcul.toLowerCase().replace(/-/g, '');
        const fichierInput = `/home/hiadsi/génération_inputs-QE/inputs_générés_direct/${prefix}/${prefix}_${typeNom}.in`;
        
        console.log(`📁 Chemin du fichier: ${fichierInput}`);
        
        // Charger l'input via API
        const response = await fetch('http://localhost:5007/api/lire_fichier', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ fichier: fichierInput })
        });
        
        const data = await response.json();
        
        let contenuInput = '';
        
        if (!data.success) {
            // Fichier n'existe pas, proposer de le générer
            console.warn(`⚠️ Fichier non trouvé: ${fichierInput}`);
            
            // Afficher modal de choix pour génération
            afficherModalGenerationInput(workflow, typeCalcul, materiau, fichierInput);
            return; // Arrêter ici, la modal gère la suite
        } else {
            contenuInput = data.contenu || '';
        }
        
        // Obtenir les recommandations pour ce type de calcul
        const recommandations = getRecommandationsCalcul(workflow, typeCalcul);
        
        // Créer la modal d'édition
        afficherModalEdition(workflow, typeCalcul, materiau, fichierInput, contenuInput, recommandations);
        
    } catch (error) {
        console.error('❌ Erreur lors du chargement de l\'input:', error);
        alert(`❌ Erreur: ${error.message}\n\nVérifiez que l'API QE (port 5007) est démarrée.`);
    }
};

// Générer un template d'input basique
function genererTemplateInput(workflow, typeCalcul, materiau) {
    const prefix = materiau.toLowerCase();
    
    const templates = {
        'VC-RELAX': `&CONTROL
    calculation = 'vc-relax'
    restart_mode = 'from_scratch'
    prefix = '${prefix}'
    outdir = './tmp/'
    pseudo_dir = '/home/hiadsi/Interface-QE_v1/pseudos/PBE/'
    verbosity = 'high'
    etot_conv_thr = 1.0d-6
    forc_conv_thr = 1.0d-4
/
&SYSTEM
    ibrav = 0
    nat = 2
    ntyp = 1
    ecutwfc = 60.0
    ecutrho = 480.0
    occupations = 'smearing'
    smearing = 'gauss'
    degauss = 0.01
/
&ELECTRONS
    conv_thr = 1.0d-8
    mixing_beta = 0.7
/
&IONS
    ion_dynamics = 'bfgs'
/
&CELL
    cell_dynamics = 'bfgs'
    press = 0.0
/
ATOMIC_SPECIES
 X  1.0  X.pbe-n-kjpaw_psl.1.0.0.UPF

CELL_PARAMETERS angstrom
 3.00  0.00  0.00
 0.00  3.00  0.00
 0.00  0.00  3.00

ATOMIC_POSITIONS angstrom
X  0.00  0.00  0.00
X  1.50  1.50  1.50

K_POINTS automatic
 8 8 8  0 0 0
`,
        'SCF': `&CONTROL
    calculation = 'scf'
    restart_mode = 'from_scratch'
    prefix = '${prefix}'
    outdir = './tmp/'
    pseudo_dir = '/home/hiadsi/Interface-QE_v1/pseudos/PBE/'
    verbosity = 'high'
/
&SYSTEM
    ibrav = 0
    nat = 2
    ntyp = 1
    ecutwfc = 60.0
    ecutrho = 480.0
    occupations = 'smearing'
    smearing = 'gauss'
    degauss = 0.01
/
&ELECTRONS
    conv_thr = 1.0d-8
    mixing_beta = 0.7
/
ATOMIC_SPECIES
 X  1.0  X.pbe-n-kjpaw_psl.1.0.0.UPF

CELL_PARAMETERS angstrom
 3.00  0.00  0.00
 0.00  3.00  0.00
 0.00  0.00  3.00

ATOMIC_POSITIONS angstrom
X  0.00  0.00  0.00
X  1.50  1.50  1.50

K_POINTS automatic
 8 8 8  0 0 0
`
    };
    
    const template = templates[typeCalcul] || templates['SCF'];
    
    return `!
! Template généré automatiquement pour ${typeCalcul}
! Matériau: ${materiau}
! Workflow: ${workflow}
!
! ⚠️ IMPORTANT: Modifiez les paramètres selon votre système !
! - Remplacez 'X' par vos éléments réels
! - Ajustez les paramètres de maille (CELL_PARAMETERS)
! - Modifiez les positions atomiques (ATOMIC_POSITIONS)
! - Vérifiez les chemins des pseudopotentiels
! - Ajustez ecutwfc, ecutrho selon vos pseudos
!

${template}`;
};

// ════════════════════════════════════════════════════════════════════════════
// MODAL DE CHOIX POUR GÉNÉRATION D'INPUT MANQUANT
// ════════════════════════════════════════════════════════════════════════════
function afficherModalGenerationInput(workflow, typeCalcul, materiau, fichierInput) {
    console.log(`📝 Affichage modal génération pour ${typeCalcul} - ${materiau}`);
    
    // Sauvegarder le contexte pour le retour automatique
    sessionStorage.setItem('retour_calcul_workflow', workflow);
    sessionStorage.setItem('retour_calcul_materiau', materiau);
    sessionStorage.setItem('retour_calcul_type', typeCalcul);
    sessionStorage.setItem('retour_calcul_actif', 'true');
    
    // Créer la modal
    const modal = document.createElement('div');
    modal.id = 'modal_generation_input';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 10000;
        animation: fadeIn 0.3s;
    `;
    
    modal.innerHTML = `
        <div style="background: white; padding: 40px; border-radius: 15px; max-width: 700px; width: 90%; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
            <div style="text-align: center; margin-bottom: 30px;">
                <h2 style="margin: 0; color: #1e40af; font-size: 1.8em;">📝 Input Manquant</h2>
                <p style="margin: 15px 0 0 0; color: #6b7280; font-size: 1.1em;">
                    Le fichier d'input pour <strong>${typeCalcul}</strong> n'existe pas encore.
                </p>
                <p style="margin: 10px 0 0 0; color: #9ca3af; font-size: 0.95em;">
                    📁 <code>${fichierInput}</code>
                </p>
            </div>
            
            <div style="border-top: 2px solid #e5e7eb; padding-top: 30px;">
                <h3 style="margin: 0 0 20px 0; color: #374151; font-size: 1.2em;">Comment souhaitez-vous créer cet input ?</h3>
                
                <!-- Option 1: Générer dans l'onglet Inputs -->
                <div style="background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); padding: 25px; border-radius: 12px; margin-bottom: 15px; cursor: pointer; transition: transform 0.2s;" 
                     onclick="redirectionVersInputs('${workflow}', '${typeCalcul}', '${materiau}')" 
                     onmouseover="this.style.transform='scale(1.02)'" 
                     onmouseout="this.style.transform='scale(1)'">
                    <div style="color: white;">
                        <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 10px;">
                            <span style="font-size: 2.5em;">🎯</span>
                            <h4 style="margin: 0; font-size: 1.3em;">Générer dans l'onglet Inputs</h4>
                        </div>
                        <p style="margin: 0; opacity: 0.95; font-size: 0.95em; line-height: 1.6;">
                            ✨ <strong>Recommandé</strong> : Accédez à l'onglet Inputs pour générer l'input complet.<br>
                            📊 Deux options disponibles :<br>
                            &nbsp;&nbsp;&nbsp;• <strong>Génération directe</strong> avec formulaire détaillé<br>
                            &nbsp;&nbsp;&nbsp;• <strong>Conversion depuis fichier CIF</strong><br>
                            🔄 Retour automatique à cet onglet après sauvegarde
                        </p>
                    </div>
                </div>
                
                <!-- Option 2: Template rapide -->
                <div style="background: #f3f4f6; padding: 20px; border-radius: 12px; border: 2px solid #d1d5db; cursor: pointer; transition: all 0.2s;" 
                     onclick="creerTemplateRapide('${workflow}', '${typeCalcul}', '${materiau}', '${fichierInput}')" 
                     onmouseover="this.style.background='#e5e7eb'" 
                     onmouseout="this.style.background='#f3f4f6'">
                    <div style="color: #374151;">
                        <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 10px;">
                            <span style="font-size: 2em;">⚡</span>
                            <h4 style="margin: 0; font-size: 1.1em;">Template rapide</h4>
                        </div>
                        <p style="margin: 0; font-size: 0.9em; line-height: 1.5; color: #6b7280;">
                            Créer un template basique minimal que vous pourrez éditer ici.
                        </p>
                    </div>
                </div>
            </div>
            
            <div style="text-align: center; margin-top: 25px;">
                <button onclick="fermerModalGenerationInput()" 
                        style="padding: 12px 30px; background: #6b7280; color: white; border: none; border-radius: 8px; cursor: pointer; font-size: 1em;">
                    ❌ Annuler
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

// Fermer la modal de génération
function fermerModalGenerationInput() {
    const modal = document.getElementById('modal_generation_input');
    if (modal) {
        modal.remove();
    }
}

// Redirection vers l'onglet Inputs avec pré-remplissage
function redirectionVersInputs(workflow, typeCalcul, materiau) {
    console.log(`🔄 Redirection vers Inputs: ${materiau} - ${typeCalcul}`);
    
    // Fermer la modal
    fermerModalGenerationInput();
    
    // Sauvegarder les informations pour pré-remplissage
    sessionStorage.setItem('preremplir_materiau', materiau);
    sessionStorage.setItem('preremplir_type_calcul', typeCalcul.toLowerCase());
    
    // Basculer vers l'onglet Inputs (onglet 0)
    window.switchTab(0);
    
    // Attendre que l'onglet soit chargé, puis pré-remplir
    setTimeout(() => {
        preremplirFormulaireInputs(materiau, typeCalcul);
    }, 500);
    
    // Afficher une notification
    const notif = document.createElement('div');
    notif.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        color: white;
        padding: 20px 30px;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        z-index: 10001;
        font-size: 1.1em;
        animation: slideInRight 0.5s;
    `;
    notif.innerHTML = `
        <div style="display: flex; align-items: center; gap: 15px;">
            <span style="font-size: 2em;">✅</span>
            <div>
                <strong>Génération d'input pour ${materiau}</strong><br>
                <span style="opacity: 0.9; font-size: 0.9em;">Type: ${typeCalcul}</span><br>
                <span style="opacity: 0.8; font-size: 0.85em;">🔄 Retour automatique après sauvegarde</span>
            </div>
        </div>
    `;
    document.body.appendChild(notif);
    setTimeout(() => notif.remove(), 5000);
}

// Pré-remplir le formulaire dans l'onglet Inputs
function preremplirFormulaireInputs(materiau, typeCalcul) {
    console.log(`📝 Pré-remplissage: ${materiau} - ${typeCalcul}`);
    
    // Trouver et remplir le champ "prefix"
    const prefixInput = document.querySelector('input[placeholder*="prefix"], input[name="prefix"], #input_prefix');
    if (prefixInput) {
        prefixInput.value = materiau.toLowerCase();
        prefixInput.dispatchEvent(new Event('input', { bubbles: true }));
        console.log(`✅ Prefix rempli: ${materiau}`);
    }
    
    // Trouver et sélectionner le type de calcul
    const typeSelect = document.getElementById('type_calcul');
    if (typeSelect) {
        const normalizedType = typeCalcul.toLowerCase().replace('-', '');
        typeSelect.value = normalizedType;
        typeSelect.dispatchEvent(new Event('change', { bubbles: true }));
        console.log(`✅ Type de calcul sélectionné: ${normalizedType}`);
    }
    
    // Scroll vers le formulaire
    const section = document.querySelector('.card, .section');
    if (section) {
        section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

// Créer un template rapide (option 2)
function creerTemplateRapide(workflow, typeCalcul, materiau, fichierInput) {
    console.log(`⚡ Création template rapide pour ${typeCalcul}`);
    
    // Fermer la modal
    fermerModalGenerationInput();
    
    // Générer le template
    const contenuInput = genererTemplateInput(workflow, typeCalcul, materiau);
    
    // Obtenir les recommandations
    const recommandations = getRecommandationsCalcul(workflow, typeCalcul);
    
    // Afficher la modal d'édition avec le template
    afficherModalEdition(workflow, typeCalcul, materiau, fichierInput, contenuInput, recommandations);
}

// Vérifier au chargement de la page si on doit retourner aux calculs
window.addEventListener('DOMContentLoaded', () => {
    const retourActif = sessionStorage.getItem('retour_calcul_actif');
    if (retourActif === 'true') {
        console.log('🔄 Vérification retour automatique aux calculs...');
        
        // Attendre un peu pour laisser le temps à la sauvegarde
        setTimeout(() => {
            const workflow = sessionStorage.getItem('retour_calcul_workflow');
            const materiau = sessionStorage.getItem('retour_calcul_materiau');
            
            if (workflow && materiau) {
                console.log(`✅ Retour automatique vers Calculs: ${workflow} - ${materiau}`);
                
                // Nettoyer le flag
                sessionStorage.removeItem('retour_calcul_actif');
                
                // Basculer vers l'onglet Calculs (onglet 2)
                window.switchTab(1);
                
                // Afficher notification
                setTimeout(() => {
                    const notif = document.createElement('div');
                    notif.style.cssText = `
                        position: fixed;
                        top: 80px;
                        right: 20px;
                        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
                        color: white;
                        padding: 20px 30px;
                        border-radius: 10px;
                        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                        z-index: 10001;
                        animation: slideInRight 0.5s;
                    `;
                    notif.innerHTML = `
                        <div style="display: flex; align-items: center; gap: 15px;">
                            <span style="font-size: 2em;">✅</span>
                            <div>
                                <strong>Input créé avec succès !</strong><br>
                                <span style="opacity: 0.9; font-size: 0.9em;">Vous pouvez maintenant lancer le calcul</span>
                            </div>
                        </div>
                    `;
                    document.body.appendChild(notif);
                    setTimeout(() => notif.remove(), 4000);
                }, 1000);
            }
        }, 500);
    }
});

// Afficher la modal d'édition
function afficherModalEdition(workflow, typeCalcul, materiau, fichierInput, contenu, recommandations) {
    // Créer le backdrop
    const backdrop = document.createElement('div');
    backdrop.id = 'modal_edition_backdrop';
    backdrop.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        z-index: 9998;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 20px;
    `;
    
    // Créer la modal
    const modal = document.createElement('div');
    modal.style.cssText = `
        background: white;
        border-radius: 16px;
        width: 90%;
        max-width: 1200px;
        max-height: 90vh;
        overflow: hidden;
        box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
        display: flex;
        flex-direction: column;
        z-index: 9999;
    `;
    
    modal.innerHTML = `
        <div style="background: linear-gradient(135deg, #f59e0b, #d97706); color: white; padding: 25px; border-radius: 16px 16px 0 0;">
            <h3 style="margin: 0 0 10px 0; font-size: 1.4em;">✏️ Édition: ${typeCalcul.toUpperCase()} - ${materiau}</h3>
            <p style="margin: 0; opacity: 0.95; font-size: 0.95em;">📁 ${fichierInput}</p>
        </div>
        
        <div style="display: flex; flex: 1; overflow: hidden;">
            <!-- Éditeur de texte -->
            <div style="flex: 2; display: flex; flex-direction: column; padding: 20px; border-right: 2px solid #e5e7eb;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h4 style="margin: 0; color: #1f2937;">📝 Contenu de l'Input</h4>
                    <span style="font-size: 0.85em; color: #6b7280;">${contenu.split('\n').length} lignes</span>
                </div>
                <textarea id="editeur_input_${typeCalcul}" 
                          style="flex: 1; 
                                 font-family: 'JetBrains Mono', monospace; 
                                 font-size: 0.9em; 
                                 padding: 15px; 
                                 border: 2px solid #cbd5e1; 
                                 border-radius: 10px; 
                                 resize: none; 
                                 background: #f8fafc; 
                                 color: #1e293b; 
                                 line-height: 1.6;">${contenu}</textarea>
            </div>
            
            <!-- Recommandations -->
            <div style="flex: 1; padding: 20px; background: #fef3c7; overflow-y: auto;">
                <h4 style="margin: 0 0 15px 0; color: #92400e;">💡 Recommandations</h4>
                <div style="font-size: 0.9em; color: #78350f;">
                    ${recommandations.map(r => `
                        <div style="background: white; padding: 12px; border-radius: 8px; margin-bottom: 10px; border-left: 4px solid #f59e0b;">
                            <strong>•</strong> ${r}
                        </div>
                    `).join('')}
                </div>
                
                <div style="background: #fee2e2; padding: 15px; border-radius: 10px; margin-top: 20px; border-left: 4px solid #ef4444;">
                    <strong style="color: #991b1b;">⚠️ Points d'attention:</strong>
                    <ul style="margin: 10px 0 0 0; padding-left: 20px; color: #7f1d1d; font-size: 0.9em;">
                        <li>Vérifiez la syntaxe Fortran (sensible à la casse)</li>
                        <li>Respectez les sections &CONTROL, &SYSTEM, &ELECTRONS, etc.</li>
                        <li>Les chemins des pseudopotentiels doivent être corrects</li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- Boutons d'action -->
        <div style="padding: 20px; background: #f8fafc; border-top: 2px solid #e5e7eb; display: flex; gap: 15px; justify-content: flex-end;">
            <button id="btn_annuler_edition" style="padding: 12px 30px; background: #6b7280; color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 600; font-size: 1em;">
                ❌ Annuler
            </button>
            <button id="btn_sauvegarder_input" style="padding: 12px 30px; background: linear-gradient(135deg, #10b981, #059669); color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 600; font-size: 1em; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);">
                💾 Sauvegarder
            </button>
        </div>
    `;
    
    backdrop.appendChild(modal);
    document.body.appendChild(backdrop);
    
    // Gestionnaires d'événements
    document.getElementById('btn_annuler_edition').onclick = () => {
        document.body.removeChild(backdrop);
    };
    
    document.getElementById('btn_sauvegarder_input').onclick = async () => {
        const nouveauContenu = document.getElementById(`editeur_input_${typeCalcul}`).value;
        await sauvegarderInput(fichierInput, nouveauContenu, backdrop);
    };
    
    // Fermer avec Échap
    backdrop.onclick = (e) => {
        if (e.target === backdrop) {
            document.body.removeChild(backdrop);
        }
    };
};

// Sauvegarder l'input modifié
async function sauvegarderInput(fichierInput, contenu, backdrop) {
    try {
        console.log(`💾 Sauvegarde de ${fichierInput}...`);
        
        // Extraire prefix et filename du chemin complet
        // Ex: /home/hiadsi/génération_inputs-QE/inputs_générés_direct/gan/gan_vcrelax.in
        const parts = fichierInput.split('/');
        const filename = parts[parts.length - 1]; // gan_vcrelax.in
        const prefix = parts[parts.length - 2];   // gan
        
        console.log(`📝 Sauvegarde: prefix=${prefix}, filename=${filename}`);
        
        const response = await fetch('http://localhost:5007/api/sauvegarder_fichier', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                fichier: fichierInput,
                contenu: contenu
            })
        });
        
        if (!response.ok) {
            throw new Error(`Erreur HTTP: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            alert('✅ Input sauvegardé avec succès !');
            document.body.removeChild(backdrop);
        } else {
            throw new Error(data.error || 'Erreur de sauvegarde');
        }
        
    } catch (error) {
        console.error('❌ Erreur lors de la sauvegarde:', error);
        alert(`❌ Erreur de sauvegarde: ${error.message}\n\nVérifiez que l'API QE (port 5007) est démarrée.`);
    }
}

// Obtenir les recommandations selon le type de calcul
function getRecommandationsCalcul(workflow, typeCalcul) {
    const recommandations = {
        'electronique': {
            'VC-RELAX': [
                'ecutwfc ≥ 60 Ry (80-100 Ry pour haute précision)',
                'ecutrho = 4-8 × ecutwfc (selon le pseudo)',
                'conv_thr = 1.0d-8 pour une bonne convergence',
                'forc_conv_thr = 1.0d-4 Ry/Bohr',
                'Utiliser un maillage k dense (ex: 8×8×8 ou plus)',
                'calculation = "vc-relax" dans &CONTROL'
            ],
            'SCF': [
                'ecutwfc ≥ 60 Ry (cohérent avec VC-RELAX)',
                'conv_thr = 1.0d-8 pour l\'énergie',
                'mixing_beta = 0.3-0.7 (ajuster selon convergence)',
                'Utiliser les paramètres de maille de VC-RELAX',
                'calculation = "scf" dans &CONTROL'
            ],
            'BANDS': [
                'Utiliser les mêmes ecutwfc/ecutrho que SCF',
                'Définir un chemin k high-symmetry (ex: Γ-X-M-Γ)',
                'nbnd: augmenter de 20-30% par rapport aux occupées',
                'calculation = "bands" dans &CONTROL',
                'verbosity = "high" pour plus de détails'
            ],
            'DOS': [
                'Grille k très dense (ex: 16×16×16)',
                'nbnd: augmenter de 20-30%',
                'calculation = "nscf" dans &CONTROL',
                'occupations = "tetrahedra" pour DOS précis'
            ],
            'PDOS': [
                'Identique à DOS + projections',
                'Définir les atomes et orbitales dans projwfc.x',
                'Utiliser DeltaE petit (0.01 eV) pour résolution fine'
            ]
        },
        'phonons': {
            'VC-RELAX': [
                'ecutwfc ≥ 60 Ry (80-100 Ry recommandé)',
                'Convergence stricte: conv_thr = 1.0d-10',
                'forc_conv_thr = 1.0d-5 Ry/Bohr pour phonons',
                'Maillage k dense pour structure relaxée précise'
            ],
            'SCF': [
                'Utiliser structure relaxée de VC-RELAX',
                'conv_thr = 1.0d-10 (très important pour phonons)',
                'tr2_ph = 1.0d-14 dans calcul PH',
                'Maillage k cohérent avec VC-RELAX'
            ],
            'PH': [
                'tr2_ph = 1.0d-14 pour matrice dynamique',
                'Grille q: commencer par 2×2×2 ou 4×4×4',
                'alpha_mix(1) = 0.7 pour convergence',
                'Peut nécessiter beaucoup de RAM et temps CPU'
            ],
            'Q2R': [
                'Utiliser tous les fichiers dynmat de PH.X',
                'zasr = "simple" ou "crystal" pour règle de somme acoustique'
            ],
            'MATDYN': [
                'Définir chemin q high-symmetry',
                'asr = "simple" pour correction acoustique',
                'dos = .true. pour densité d\'états phononiques'
            ]
        },
        'optique': {
            'VC-RELAX': [
                '⚠️ UNIQUEMENT pseudopotentiels NC (Norm-Conserving)',
                'ecutwfc ≥ 80 Ry (pseudos NC nécessitent cutoff élevé)',
                'Structure optimisée critique pour gap précis',
                'forc_conv_thr = 1.0d-5 Ry/Bohr'
            ],
            'SCF': [
                'nosym = .true. (pas de symétries)',
                'noinv = .true. (pas d\'inversion)',
                'wf_collect = .true. (sauvegarder fonctions d\'onde)',
                'nbnd: au moins 4× nombre de bandes occupées',
                'conv_thr = 1.0d-8'
            ],
            'NSCF': [
                'calculation = "nscf"',
                'Grille k TRÈS dense (ex: 12×12×12 ou plus)',
                'nbnd: 4-8× nombre de bandes occupées',
                'Copier nosym, noinv, wf_collect du SCF',
                'Plage d\'énergie: jusqu\'à 10-20 eV au-dessus de Ef'
            ],
            'EPSILON': [
                'Utiliser epsilon.x après NSCF',
                'Définir plage d\'énergie: 0-20 eV typique',
                'Calculer ε₁(ω), ε₂(ω), n(ω), k(ω), R(ω), α(ω)',
                '⚠️ CRITIQUE: Pseudos NC obligatoires pour epsilon.x'
            ]
        }
    };
    
    return recommandations[workflow]?.[typeCalcul] || [
        'Vérifiez la documentation Quantum ESPRESSO',
        'Testez la convergence des paramètres',
        'Consultez des exemples similaires'
    ];
}

// =====================================================
// FONCTION: LANCER UN CALCUL
// =====================================================
window.lancerCalcul = async function(workflow, materiau, typeCalcul) {
    console.log(`🚀 Lancement du calcul ${typeCalcul} pour ${materiau} (workflow: ${workflow})`);
    
    try {
        // Vérifier que le matériau est sélectionné
        if (!materiau || materiau.trim() === '') {
            alert('⚠️ Aucun matériau sélectionné.\nVeuillez d\'abord sélectionner un matériau dans l\'étape 1 du workflow.');
            return;
        }
        
        // Construire le chemin absolu du fichier input (sans tirets pour cohérence)
        const prefix = materiau.toLowerCase();
        const typeNom = typeCalcul.toLowerCase().replace(/-/g, '');
        const fichierAbsolu = `/home/hiadsi/génération_inputs-QE/inputs_générés_direct/${prefix}/${prefix}_${typeNom}.in`;
        
        // Vérifier que l'input existe (l'API attend la clé 'fichier' avec le chemin absolu)
        const verif = await fetch('http://localhost:5007/api/lire_fichier', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ fichier: fichierAbsolu })
        });
        
        const dataVerif = await verif.json();
        
        if (!dataVerif.success) {
            if (confirm(`❌ L'input n'existe pas: ${fichierAbsolu}\n\n📝 Voulez-vous l'éditer/créer maintenant ?`)) {
                await window.editerCalcul(workflow, typeCalcul, materiau);
            }
            return;
        }
        
        // Vérifier le format de l'input
        console.log('🔍 Vérification du format de l\'input...');
        const formatOK = verifierFormatInput(dataVerif.contenu);
        
        if (!formatOK) {
            if (confirm(`⚠️ Le format de l'input semble incorrect.\n\n✏️ Voulez-vous l'éditer avant de lancer ?`)) {
                await window.editerCalcul(workflow, typeCalcul, materiau);
                return;
            }
        }
        
        // Lire les paramètres de parallélisation du workflow
        const nprocs  = parseInt(document.getElementById(`nprocs_${workflow}`)?.value  || '1');
        const nthreads = parseInt(document.getElementById(`nthreads_${workflow}`)?.value || '1');
        
        // Lancer le calcul via API (chemin absolu + params parallèles)
        console.log(`📡 Appel API: ${typeCalcul} | nprocs=${nprocs} nthreads=${nthreads}`);
        const response = await fetch('http://localhost:5007/api/lancer_calcul', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                fichier: fichierAbsolu,
                type: typeCalcul.toLowerCase(),
                materiau: materiau,
                nprocs: nprocs,
                nthreads: nthreads
            })
        });
        
        if (!response.ok) {
            throw new Error(`Erreur HTTP: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            const modeMsg = data.mode ? ` (${data.mode})` : '';
            alert(`✅ Calcul ${typeCalcul} lancé avec succès${modeMsg}!\n\n📊 Utilisez le bouton "Suivi" pour voir la progression.`);
            
            // Démarrer automatiquement le suivi
            setTimeout(() => {
                window.suivreCalcul(workflow, materiau, typeCalcul);
            }, 1000);
        } else {
            throw new Error(data.message || data.error || 'Erreur de lancement');
        }
        
    } catch (error) {
        console.error('❌ Erreur lors du lancement:', error);
        alert(`❌ Erreur: ${error.message}\n\nVérifiez que l'API QE (port 5007) est démarrée.`);
    }
};

// Vérifier le format basique d'un input
function verifierFormatInput(contenu) {
    if (!contenu || contenu.trim().length === 0) return false;
    
    // Vérifier présence des sections essentielles
    const sectionsEssentielles = ['&CONTROL', '&SYSTEM', '&ELECTRONS'];
    const sectionsPresentes = sectionsEssentielles.filter(s => contenu.includes(s));
    
    if (sectionsPresentes.length < 2) {
        console.warn('⚠️ Sections essentielles manquantes:', sectionsEssentielles.filter(s => !contenu.includes(s)));
        return false;
    }
    
    // Vérifier présence de ATOMIC_SPECIES ou ATOMIC_POSITIONS
    if (!contenu.includes('ATOMIC_SPECIES') && !contenu.includes('ATOMIC_POSITIONS')) {
        console.warn('⚠️ Pas de ATOMIC_SPECIES ni ATOMIC_POSITIONS');
        return false;
    }
    
    return true;
}

// =====================================================
// FONCTION: SUIVRE UN CALCUL EN TEMPS RÉEL
// =====================================================
window.suivreCalcul = async function(workflow, materiau, typeCalcul) {
    console.log(`📊 Suivi du calcul ${typeCalcul} pour ${materiau} (workflow: ${workflow})`);
    
    // Vérifier que le matériau est sélectionné
    if (!materiau || materiau.trim() === '') {
        alert('⚠️ Aucun matériau sélectionné.\n\nMarche à suivre :\n1. Onglet "Calculs"\n2. Cliquez un axe de calcul\n3. Tapez le nom du matériau → "Rechercher"\n4. Cliquez "✅ Sélectionner ce matériau"');
        return;
    }
    
    try {
        // Construire les chemins du fichier de sortie possibles (sans tirets = standard)
        const prefix = materiau.toLowerCase();
        const typeNom = typeCalcul.toLowerCase().replace(/-/g, ''); // ex: vcrelax, scf, ph
        const typeAvecTirets = typeCalcul.toLowerCase(); // ex: vc-relax, scf
        // Priorité: outputs/zno/zno_vcrelax.out → zno_vc-relax.out → racine outputs/
        const fichierOutput = `/home/hiadsi/Interface-QE_v1/outputs/${prefix}/${prefix}_${typeNom}.out`;
        const fichierOutputAlt = `/home/hiadsi/Interface-QE_v1/outputs/${prefix}/${prefix}_${typeAvecTirets}.out`;
        
        // Créer la modal de suivi
        const backdrop = document.createElement('div');
        backdrop.id = 'modal_suivi_backdrop';
        backdrop.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 9998;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        `;
        
        const modal = document.createElement('div');
        modal.style.cssText = `
            background: white;
            border-radius: 16px;
            width: 90%;
            max-width: 1000px;
            max-height: 90vh;
            overflow: hidden;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
            display: flex;
            flex-direction: column;
            z-index: 9999;
        `;
        
        modal.innerHTML = `
            <div style="background: linear-gradient(135deg, #3b82f6, #2563eb); color: white; padding: 25px; border-radius: 16px 16px 0 0;">
                <h3 style="margin: 0 0 10px 0; font-size: 1.4em;">📊 Suivi: ${typeCalcul.toUpperCase()} - ${materiau}</h3>
                <p style="margin: 0; opacity: 0.95; font-size: 0.95em;">📁 ${fichierOutput}</p>
            </div>
            
            <div style="flex: 1; display: flex; flex-direction: column; padding: 20px; overflow: hidden;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h4 style="margin: 0; color: #1f2937;">📝 Logs en temps réel</h4>
                    <div id="statut_calcul" style="padding: 8px 16px; background: #fef3c7; color: #92400e; border-radius: 8px; font-weight: 600;">
                        🔄 Chargement...
                    </div>
                </div>
                <pre id="logs_calcul" style="flex: 1; 
                                              font-family: 'JetBrains Mono', monospace; 
                                              font-size: 0.85em; 
                                              padding: 15px; 
                                              border: 2px solid #cbd5e1; 
                                              border-radius: 10px; 
                                              overflow-y: auto; 
                                              background: #1e293b; 
                                              color: #e2e8f0; 
                                              line-height: 1.5;
                                              white-space: pre-wrap;">Chargement des logs...</pre>
            </div>
            
            <div style="padding: 20px; background: #f8fafc; border-top: 2px solid #e5e7eb; display: flex; gap: 15px; justify-content: flex-end;">
                <button id="btn_rafraichir_logs" style="padding: 12px 30px; background: #3b82f6; color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 600; font-size: 1em;">
                    🔄 Rafraîchir
                </button>
                <button id="btn_fermer_suivi" style="padding: 12px 30px; background: #6b7280; color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 600; font-size: 1em;">
                    ✖️ Fermer
                </button>
            </div>
        `;
        
        backdrop.appendChild(modal);
        document.body.appendChild(backdrop);
        
        // Lecture d'un fichier output avec fallback sur plusieurs noms possibles
        const lireFichierOutput = async () => {
            // Essayer dans l'ordre: nom sans tirets, nom avec tirets, ancien format API
            const candidats = [fichierOutput, fichierOutputAlt];
            for (const f of candidats) {
                const r = await fetch('http://localhost:5007/api/lire_fichier', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ fichier: f })
                });
                const d = await r.json();
                if (d.success) return { success: true, contenu: d.contenu, fichier: f };
            }
            return { success: false };
        };
        
        // Fonction de mise à jour des logs
        const mettreAJourLogs = async () => {
            try {
                const data = await lireFichierOutput();
                const logsElement = document.getElementById('logs_calcul');
                const statutElement = document.getElementById('statut_calcul');
                
                if (!logsElement) return; // Modal fermée
                
                if (data.success) {
                    const logs = data.contenu || '';
                    logsElement.textContent = logs;
                    logsElement.scrollTop = logsElement.scrollHeight;
                    
                    // Détecter le statut
                    if (logs.includes('JOB DONE') || logs.includes('convergence has been achieved')) {
                        statutElement.textContent = '✅ Terminé';
                        statutElement.style.background = '#d1fae5';
                        statutElement.style.color = '#065f46';
                    } else if (logs.includes('Error') || logs.includes('ERROR') || logs.includes('CRASH')) {
                        statutElement.textContent = '❌ Erreur';
                        statutElement.style.background = '#fee2e2';
                        statutElement.style.color = '#991b1b';
                    } else if (logs.length > 100) {
                        statutElement.textContent = '🔄 En cours...';
                        statutElement.style.background = '#dbeafe';
                        statutElement.style.color = '#1e40af';
                    } else {
                        statutElement.textContent = '⏳ En attente';
                        statutElement.style.background = '#fef3c7';
                        statutElement.style.color = '#92400e';
                    }
                } else {
                    logsElement.textContent = `⏳ En attente du fichier output...\n\nChemins cherchés:\n  • ${fichierOutput}\n  • ${fichierOutputAlt}\n\nLe calcul n'a peut-être pas encore démarré.\nCliquez sur "Rafraîchir" pour réessayer.`;
                    statutElement.textContent = '⏳ En attente';
                    statutElement.style.background = '#fef3c7';
                    statutElement.style.color = '#92400e';
                }
            } catch (error) {
                console.error('❌ Erreur lors de la lecture des logs:', error);
                const logsElement = document.getElementById('logs_calcul');
                if (logsElement) {
                    logsElement.textContent = `❌ Erreur: ${error.message}`;
                }
            }
        };
        
        // Charger les logs immédiatement
        await mettreAJourLogs();
        
        // Auto-refresh toutes les 3 secondes
        const intervalId = setInterval(mettreAJourLogs, 3000);
        
        // Gestionnaires d'événements
        document.getElementById('btn_rafraichir_logs').onclick = mettreAJourLogs;
        
        document.getElementById('btn_fermer_suivi').onclick = () => {
            clearInterval(intervalId);
            document.body.removeChild(backdrop);
        };
        
        backdrop.onclick = (e) => {
            if (e.target === backdrop) {
                clearInterval(intervalId);
                document.body.removeChild(backdrop);
            }
        };
        
    } catch (error) {
        console.error('❌ Erreur lors du suivi:', error);
        alert(`❌ Erreur: ${error.message}`);
    }
};

// Définir les calculs pour chaque workflow
window.getCalculsWorkflow = function(workflow, materiau) {
    const workflows = {
        'electronique': [
            {
                type: 'nscf',
                nom: 'NSCF',
                icon: '⚡',
                description: 'Calcul non auto-cohérent sur une grille k dense',
                recommandations: [
                    'Utiliser une grille k dense (ex: 12x12x12)',
                    'nbnd: ~1.2-1.5 × nombre de bandes occupées',
                    'Vérifier la convergence en k-points'
                ]
            },
            {
                type: 'bands',
                nom: 'BANDS',
                icon: '📈',
                description: 'Structure de bandes électroniques',
                recommandations: [
                    'Définir un chemin k approprié (ex: G-X-M-G)',
                    'Utiliser ~40-50 points par segment',
                    'nbnd doit inclure les bandes de conduction'
                ]
            },
            {
                type: 'dos',
                nom: 'DOS',
                icon: '📊',
                description: 'Densité d\'états électroniques',
                recommandations: [
                    'Grille k très dense (ex: 16x16x16)',
                    'degauss petit (0.01-0.02 Ry)',
                    'Vérifier la convergence'
                ]
            }
        ],
        'phonons': [
            {
                type: 'ph',
                nom: 'PH.X',
                icon: '🎵',
                description: 'Calcul des phonons (perturbations DFPT)',
                recommandations: [
                    'Grille q appropriée (ex: 4x4x4)',
                    'tr2_ph = 1.0d-14 (convergence)',
                    'Peut prendre beaucoup de temps'
                ]
            },
            {
                type: 'q2r',
                nom: 'Q2R',
                icon: '🔄',
                description: 'Transformation espace q → espace réel',
                recommandations: [
                    'Utilise les fichiers générés par ph.x',
                    'Très rapide (quelques secondes)',
                    'Vérifier que tous les fichiers dynX existent'
                ]
            },
            {
                type: 'matdyn',
                nom: 'MATDYN',
                icon: '📉',
                description: 'Courbes de dispersion des phonons',
                recommandations: [
                    'Définir un chemin q (même que pour BANDS)',
                    'dos: Grille q dense pour la DOS',
                    'Vérifier l\'absence de modes imaginaires'
                ]
            }
        ],
        'optique': [
            {
                type: 'nscf',
                nom: 'NSCF',
                icon: '⚡',
                description: 'Calcul non auto-cohérent (grille k dense)',
                recommandations: [
                    'Grille k TRÈS dense (ex: 16x16x16)',
                    'nbnd élevé (~2-3x bandes occupées)',
                    'IMPORTANT: Pseudos NC uniquement!'
                ]
            },
            {
                type: 'epsilon',
                nom: 'EPSILON (epsilon.x)',
                icon: '🌈',
                description: 'Fonction diélectrique et propriétés optiques',
                recommandations: [
                    'Nécessite pseudos norm-conserving (NC)',
                    'Définir la plage d\'énergie (ex: 0-20 eV)',
                    'Calcule ε(ω), n, k, R, α'
                ]
            }
        ]
    };
    
    return workflows[workflow] || [];
}

// =====================================================
// FONCTION ÉDITER: Modifier les paramètres d'un calcul
// =====================================================
// NOTE: editerCalcul redirige vers window.editerCalcul (ordre args: workflow, typeCalcul, materiau)
function editerCalcul(workflow, materiau, typeCalcul) {
    return window.editerCalcul(workflow, typeCalcul, materiau);
}

// Obtenir les paramètres recommandés selon le type de calcul
function getParametresRecommandes(typeCalcul, materiau) {
    const params = {
        'nscf': [
            { name: 'kpoints', label: 'Grille k-points', value: '12 12 12 0 0 0', type: 'text', recommandation: 'recommandé: 12-16', description: 'Grille dense pour une bonne résolution' },
            { name: 'nbnd', label: 'Nombre de bandes (nbnd)', value: '', type: 'number', recommandation: '~1.5x occupées', description: 'Laisser vide pour calcul automatique' },
            { name: 'ecutwfc', label: 'Cutoff (ecutwfc)', value: '60', type: 'number', recommandation: 'Ry', description: 'Même valeur que SCF' }
        ],
        'bands': [
            { name: 'kpath', label: 'Chemin k', value: 'G-X-M-G', type: 'text', recommandation: 'ex: G-X-M-G', description: 'Définir les points de haute symétrie' },
            { name: 'npoints', label: 'Points par segment', value: '50', type: 'number', recommandation: '40-50', description: 'Résolution de la courbe' },
            { name: 'nbnd', label: 'Nombre de bandes', value: '', type: 'number', recommandation: 'inclure conduction', description: 'Doit inclure bandes vides' }
        ],
        'dos': [
            { name: 'kpoints', label: 'Grille k-points', value: '16 16 16 0 0 0', type: 'text', recommandation: 'très dense', description: 'Plus dense que NSCF' },
            { name: 'degauss', label: 'Smearing (degauss)', value: '0.01', type: 'number', recommandation: '0.01-0.02 Ry', description: 'Élargissement gaussien' },
            { name: 'emin_emax', label: 'Plage énergie (eV)', value: '-10 20', type: 'text', description: 'Min et Max en eV' }
        ],
        'ph': [
            { name: 'qgrid', label: 'Grille q', value: '4 4 4', type: 'text', recommandation: '4x4x4', description: 'Grille de phonons' },
            { name: 'tr2_ph', label: 'Convergence (tr2_ph)', value: '1.0d-14', type: 'text', recommandation: '1e-14', description: 'Seuil de convergence' },
            { name: 'alpha_mix', label: 'Mixing (alpha_mix)', value: '0.7', type: 'number', recommandation: '0.5-0.7', description: 'Paramètre de mélange' }
        ],
        'q2r': [
            { name: 'fildyn', label: 'Fichiers dyn', value: `${materiau}.dyn`, type: 'text', description: 'Préfixe des fichiers dynamiques' }
        ],
        'matdyn': [
            { name: 'qpath', label: 'Chemin q', value: 'G-X-M-G', type: 'text', recommandation: 'même que BANDS', description: 'Chemin dans la zone de Brillouin' },
            { name: 'dos', label: 'Calculer DOS', value: 'true', type: 'checkbox', description: 'DOS des phonons' }
        ],
        'epsilon': [
            { name: 'energy_range', label: 'Plage énergie (eV)', value: '0 20', type: 'text', recommandation: '0-20 eV', description: 'Min et Max' },
            { name: 'smearing', label: 'Smearing (eV)', value: '0.1', type: 'number', recommandation: '0.1 eV', description: 'Élargissement' }
        ]
    };
    
    return params[typeCalcul] || [];
}

// Valider l'édition et passer au lancement
function validerEdition(workflow, materiau, typeCalcul) {
    console.log('✅ Validation de l\'édition');
    
    // Récupérer les valeurs
    const cheminInputPrecedent = document.getElementById('chemin_input_precedent')?.value;
    const cheminOutput = document.getElementById('chemin_output')?.value;
    const cheminPseudos = document.getElementById('chemin_pseudos')?.value;
    
    // Stocker les valeurs pour le lancement
    window.calculConfig = {
        workflow,
        materiau,
        typeCalcul,
        chemins: {
            inputPrecedent: cheminInputPrecedent,
            output: cheminOutput,
            pseudos: cheminPseudos
        },
        parametres: {}
    };
    
    // Récupérer tous les paramètres
    const params = getParametresRecommandes(typeCalcul, materiau);
    params.forEach(param => {
        const element = document.getElementById(`param_${param.name}`);
        if (element) {
            window.calculConfig.parametres[param.name] = element.value;
        }
    });
    
    // Fermer la modal
    document.getElementById('modal_edition')?.remove();
    
    // Passer au lancement
    lancerCalcul(workflow, materiau, typeCalcul);
}

// =====================================================
// FONCTION LANCER: Générer et soumettre un calcul
// =====================================================
async function lancerCalcul(workflow, materiau, typeCalcul) {
    console.log(`🚀 Lancer ${typeCalcul} pour ${materiau} (${workflow})`);
    
    // Vérifier si on a une config (venant de l'édition)
    const config = window.calculConfig || {
        workflow,
        materiau,
        typeCalcul,
        chemins: {
            inputPrecedent: `/home/hiadsi/Interface-QE_v1/outputs/${materiau}/`,
            output: `/home/hiadsi/Interface-QE_v1/outputs/${materiau}/`,
            pseudos: '/home/hiadsi/Interface-QE_v1/pseudos/PBE/'
        },
        parametres: {}
    };
    
    // Créer une modal de confirmation
    const modal = document.createElement('div');
    modal.id = 'modal_lancement';
    modal.style.cssText = `
        position: fixed; top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0,0,0,0.8); z-index: 30000;
        display: flex; align-items: center; justify-content: center; padding: 20px;
    `;
    
    modal.innerHTML = `
        <div style="background: white; border-radius: 15px; max-width: 600px; width: 100%; box-shadow: 0 20px 60px rgba(0,0,0,0.3);">
            <!-- En-tête -->
            <div style="background: linear-gradient(135deg, #10b981, #059669); padding: 25px; border-radius: 15px 15px 0 0;">
                <h3 style="color: white; margin: 0; font-size: 1.5em;">🚀 Lancer le calcul ${typeCalcul.toUpperCase()}</h3>
            </div>
            
            <!-- Contenu -->
            <div style="padding: 30px;">
                <div id="status_lancement" style="text-align: center; padding: 20px;">
                    <div style="display: inline-block; width: 50px; height: 50px; border: 4px solid #e5e7eb; border-top-color: #10b981; border-radius: 50%; animation: spin 1s linear infinite;"></div>
                    <p style="margin-top: 15px; color: #6b7280; font-size: 1.1em;">⏳ Préparation du calcul...</p>
                </div>
                
                <div id="details_lancement" style="display: none;">
                    <!-- Sera rempli dynamiquement -->
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Vérifier l'input et lancer le calcul
    (async () => {
        try {
            const statusDiv = document.getElementById('status_lancement');
            
            // 1. Chercher l'input correspondant
            statusDiv.innerHTML = '<div style="text-align: center; padding: 20px;"><div style="display: inline-block; width: 50px; height: 50px; border: 4px solid #e5e7eb; border-top-color: #10b981; border-radius: 50%; animation: spin 1s linear infinite;"></div><p style="margin-top: 15px; color: #6b7280;">🔍 Recherche de l\'input...</p></div>';
            
            const responseInputs = await fetch('http://localhost:5007/api/lister_inputs');
            const dataInputs = await responseInputs.json();
            
            let inputTrouve = null;
            if (dataInputs.success && dataInputs.inputs) {
                inputTrouve = dataInputs.inputs.find(input => {
                    const nom = (input.nom || '').toLowerCase();
                    const type = (input.type || '').toLowerCase();
                    return nom.includes(materiau.toLowerCase()) && type === typeCalcul;
                });
            }
            
            if (!inputTrouve) {
                throw new Error(`Input ${typeCalcul.toUpperCase()} introuvable pour ${materiau}. Veuillez le générer d'abord dans l'onglet Inputs.`);
            }
            
            // 2. Vérifier le format de l'input
            statusDiv.innerHTML = '<div style="text-align: center; padding: 20px;"><div style="display: inline-block; width: 50px; height: 50px; border: 4px solid #e5e7eb; border-top-color: #10b981; border-radius: 50%; animation: spin 1s linear infinite;"></div><p style="margin-top: 15px; color: #6b7280;">🔍 Vérification du format...</p></div>';
            
            const verif = await verifierFormatInput(inputTrouve.chemin);
            
            if (!verif.valide && verif.erreursCritiques && verif.erreursCritiques.length > 0) {
                const continuer = confirm(`⚠️ Erreurs critiques détectées:\n\n${verif.erreursCritiques.join('\n')}\n\n❓ Voulez-vous quand même lancer le calcul?`);
                if (!continuer) {
                    throw new Error('Lancement annulé par l\'utilisateur');
                }
            }
            
            // 3. Lancer le calcul via l'API
            statusDiv.innerHTML = '<div style="text-align: center; padding: 20px;"><div style="display: inline-block; width: 50px; height: 50px; border: 4px solid #e5e7eb; border-top-color: #10b981; border-radius: 50%; animation: spin 1s linear infinite;"></div><p style="margin-top: 15px; color: #6b7280;">🚀 Lancement du calcul...</p></div>';
            
            const responseLancement = await fetch('http://localhost:5007/api/lancer_calcul', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    input_file: inputTrouve.chemin,
                    calcul_type: typeCalcul,
                    materiau: materiau,
                    workflow: workflow
                })
            });
            
            const dataLancement = await responseLancement.json();
            
            if (!dataLancement.success && dataLancement.status !== 'success') {
                throw new Error(dataLancement.error || dataLancement.message || 'Erreur lors du lancement');
            }
            
            // 4. Succès - Afficher les infos et démarrer le suivi
            statusDiv.innerHTML = `
                <div style="text-align: center;">
                    <div style="font-size: 3em; margin-bottom: 15px;">✅</div>
                    <h4 style="color: #065f46; margin: 0 0 10px 0;">Calcul soumis avec succès !</h4>
                    <p style="color: #64748b; margin: 0;">Le calcul ${typeCalcul.toUpperCase()} pour ${materiau} a été lancé.</p>
                </div>
                
                <div style="background: #f1f5f9; padding: 15px; border-radius: 10px; margin-top: 20px;">
                    <p style="margin: 0 0 10px 0; color: #475569; font-weight: 600;">📋 Informations:</p>
                    <ul style="margin: 0; padding-left: 20px; color: #64748b; font-size: 0.95em;">
                        <li>Type: ${typeCalcul.toUpperCase()}</li>
                        <li>Matériau: ${materiau}</li>
                        <li>Workflow: ${workflow}</li>
                        <li>Input: ${inputTrouve.fichier}</li>
                        <li>Sortie: ${config.chemins.output}</li>
                    </ul>
                </div>
                
                <div style="background: #d1fae5; padding: 15px; border-radius: 10px; margin-top: 15px; border: 2px solid #10b981;">
                    <p style="margin: 0; color: #065f46; font-weight: 600;">✨ Le suivi automatique va démarrer dans 2 secondes...</p>
                </div>
                
                <div style="display: flex; gap: 15px; margin-top: 25px;">
                    <button onclick="demarrerSuiviCalcul('${materiau}', '${typeCalcul}'); document.getElementById('modal_lancement').remove();" style="flex: 1; padding: 15px; background: linear-gradient(135deg, #f59e0b, #d97706); color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 700; font-size: 1.1em;">
                        📊 Suivre maintenant
                    </button>
                    <button onclick="document.getElementById('modal_lancement').remove()" style="flex: 1; padding: 15px; background: #64748b; color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 700; font-size: 1.1em;">
                        Fermer
                    </button>
                </div>
            `;
            
            // Démarrer automatiquement le suivi après 2 secondes
            setTimeout(() => {
                document.getElementById('modal_lancement')?.remove();
                demarrerSuiviCalcul(materiau, typeCalcul);
            }, 2000);
            
        } catch (error) {
            console.error('❌ Erreur:', error);
            const statusDiv = document.getElementById('status_lancement');
            statusDiv.innerHTML = `
                <div style="text-align: center;">
                    <div style="font-size: 3em; margin-bottom: 15px;">❌</div>
                    <h4 style="color: #991b1b; margin: 0 0 10px 0;">Erreur</h4>
                    <p style="color: #64748b; margin: 0;">${error.message}</p>
                </div>
                
                <button onclick="document.getElementById('modal_lancement').remove()" style="width: 100%; margin-top: 20px; padding: 15px; background: #64748b; color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 700; font-size: 1.1em;">
                    Fermer
                </button>
            `;
        }
    })();
}

// =====================================================
// FONCTION SUIVI: Afficher l'état et les logs
// =====================================================
async function suivreCalcul(workflow, materiau, typeCalcul) {
    console.log(`📊 Suivi ${typeCalcul} pour ${materiau} (${workflow})`);
    
    // Utiliser la modal existante pour les logs
    const modal = document.getElementById('monitoring_temps_reel');
    const overlay = document.getElementById('monitoring_overlay');
    const logsDiv = document.getElementById('monitoring_logs');
    
    if (modal && overlay && logsDiv) {
        modal.style.display = 'block';
        overlay.style.display = 'block';
        
        // Changer le titre
        const titre = modal.querySelector('h3');
        if (titre) {
            titre.textContent = `📊 Suivi: ${typeCalcul.toUpperCase()} - ${materiau}`;
        }
        
        logsDiv.innerHTML = '🔄 Chargement des logs...';
        
        try {
            // Chercher le fichier de sortie
            const nomFichier = `${materiau}_${typeCalcul}`;
            const cheminFichier = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}/${nomFichier}.out`;
            
            const response = await fetch('http://localhost:5007/api/lire_fichier', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ fichier: cheminFichier })
            });
            
            const data = await response.json();
            
            if (data.success && data.contenu) {
                // Formater et afficher les logs
                const logs = data.contenu
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/\n/g, '<br>');
                
                logsDiv.innerHTML = logs || '(Fichier vide)';
                logsDiv.scrollTop = logsDiv.scrollHeight;
            } else {
                logsDiv.innerHTML = `
                    <div style="text-align: center; padding: 40px; color: #f59e0b;">
                        <div style="font-size: 3em; margin-bottom: 15px;">⏳</div>
                        <h4>Calcul en attente ou en cours</h4>
                        <p style="color: #94a3b8; margin-top: 10px;">Le fichier de sortie n'existe pas encore.</p>
                        <p style="color: #94a3b8; margin-top: 5px; font-size: 0.9em;">Cherché: ${cheminFichier}</p>
                    </div>
                `;
            }
        } catch (error) {
            console.error('Erreur suivi:', error);
            logsDiv.innerHTML = `
                <div style="text-align: center; padding: 40px; color: #ef4444;">
                    <div style="font-size: 3em; margin-bottom: 15px;">❌</div>
                    <h4>Erreur</h4>
                    <p style="color: #94a3b8; margin-top: 10px;">${error.message}</p>
                </div>
            `;
        }
    }
}


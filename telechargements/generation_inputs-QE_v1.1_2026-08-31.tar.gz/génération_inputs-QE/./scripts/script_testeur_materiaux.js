// ═══════════════════════════════════════════════════════════════════════════
// TEST - VÉRIFICATION COMPLÈTE DE TOUS LES MATÉRIAUX
// Binaires, Ternaires, Quaternaires, Quinaires, etc.
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Matériaux de test avec leurs paramètres
 */
const MATERIAUX_TEST = {
    'GaN': {
        nom: 'GaN (Binaire)',
        ibrav: '4',  // Hexagonal
        ntyp: 2,
        nat: 2,
        elements: ['Ga', 'N'],
        groupe_espace: '186',
        description: 'Nitrure de gallium - Structure Wurtzite'
    },
    'BaTiO3': {
        nom: 'BaTiO3 (Ternaire)',
        ibrav: '2',  // BCC
        ntyp: 3,
        nat: 5,
        elements: ['Ba', 'Ti', 'O', 'O', 'O'],
        groupe_espace: '225',
        description: 'Titanate de baryum - Structure pérovskite'
    },
    'BaFeO3': {
        nom: 'BaFeO3 (Ternaire)',
        ibrav: '2',  // BCC
        ntyp: 3,
        nat: 5,
        elements: ['Ba', 'Fe', 'O', 'O', 'O'],
        groupe_espace: '225',
        description: 'Ferrate de baryum'
    },
    'YBaCuO': {
        nom: 'YBa₂Cu₃O₇ (Quaternaire)',
        ibrav: '8',  // Orthorhombique
        ntyp: 4,
        nat: 12,
        elements: ['Y', 'Ba', 'Cu', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'Ba', 'Cu'],
        groupe_espace: '47',
        description: 'Supraconducteur YBaCuO'
    },
    'Si': {
        nom: 'Si (Monoatomique)',
        ibrav: '2',  // FCC
        ntyp: 1,
        nat: 2,
        elements: ['Si', 'Si'],
        groupe_espace: '227',
        description: 'Silicium - Structure diamant'
    },
    'Cu': {
        nom: 'Cu (Monoatomique)',
        ibrav: '2',  // FCC
        ntyp: 1,
        nat: 4,
        elements: ['Cu', 'Cu', 'Cu', 'Cu'],
        groupe_espace: '225',
        description: 'Cuivre - Structure FCC'
    }
};

/**
 * Créer une section de test
 */
function creerSectionTest() {
    const section = document.createElement('div');
    section.id = 'section_test_materiaux';
    section.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: #e3f2fd;
        border: 3px solid #2196f3;
        border-radius: 10px;
        padding: 15px;
        z-index: 10000;
        max-width: 300px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    `;
    
    section.innerHTML = `
        <div style="color: #0c5460; font-weight: bold; margin-bottom: 10px;">🧪 TESTEUR MATÉRIAUX</div>
        <div style="display: flex; flex-direction: column; gap: 8px;">
            ${Object.entries(MATERIAUX_TEST).map(([key, mat]) => `
                <button onclick="chargerMateriau('${key}')" style="
                    padding: 8px 12px;
                    background: #2196f3;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    font-weight: bold;
                    font-size: 0.85em;
                    text-align: left;
                    transition: all 0.3s;
                ">
                    ${mat.nom.split('(')[0].trim()}
                </button>
            `).join('')}
        </div>
        <div style="
            margin-top: 12px;
            padding: 10px;
            background: rgba(33,150,243,0.1);
            border-left: 3px solid #2196f3;
            border-radius: 3px;
            font-size: 0.75em;
            color: #0c5460;
        ">
            💡 Cliquez sur un matériau pour remplir tous les champs automatiquement
        </div>
    `;
    
    document.body.appendChild(section);
    console.log('✅ Section test créée');
}

/**
 * Charger un matériau de test
 */
function chargerMateriau(key) {
    const mat = MATERIAUX_TEST[key];
    if (!mat) {
        alert('❌ Matériau non trouvé');
        return;
    }
    
    console.log(`\n🧪 CHARGEMENT: ${mat.nom}\n${mat.description}`);
    
    // Remplir les champs
    try {
        // 1. Nom du matériau
        const nomInput = document.getElementById('materiau_name');
        if (nomInput) nomInput.value = key;
        
        // 2. Prefix
        const prefixInput = document.getElementById('prefix_name');
        if (prefixInput) prefixInput.value = `${key}_scf`;
        
        // 3. ibrav
        const ibravSelect = document.getElementById('ibrav');
        if (ibravSelect) {
            ibravSelect.value = mat.ibrav;
            // Trigger change event
            ibravSelect.dispatchEvent(new Event('change', { bubbles: true }));
        }
        
        // 4. ntyp
        const ntypInput = document.getElementById('ntyp');
        if (ntypInput) {
            ntypInput.value = mat.ntyp;
            // Trigger change event
            ntypInput.dispatchEvent(new Event('change', { bubbles: true }));
        }
        
        // 5. nat
        const natInput = document.getElementById('nat');
        if (natInput) {
            natInput.value = mat.nat;
            // Trigger change event
            natInput.dispatchEvent(new Event('change', { bubbles: true }));
        }
        
        // 6. Attendre que les éléments soient créés
        setTimeout(() => {
            // Remplir les éléments
            for (let i = 1; i <= mat.ntyp; i++) {
                const elemInput = document.getElementById(`element_${i}`);
                if (elemInput) {
                    elemInput.value = mat.elements[i - 1] || '';
                    // Trigger input event
                    elemInput.dispatchEvent(new Event('input', { bubbles: true }));
                }
            }
            
            console.log(`✅ ${mat.nom} chargé avec succès!`);
            console.log(`  - ntyp: ${mat.ntyp}`);
            console.log(`  - nat: ${mat.nat}`);
            console.log(`  - éléments: [${mat.elements.slice(0, mat.ntyp).join(', ')}]`);
            
            alert(`✅ ${mat.nom} chargé!\n\nÉtapes suivantes:\n1. Cliquer [🚀 Générer Auto]\n2. Vérifier les symboles atomiques\n3. Cliquer [🚀 GÉNÉRER INPUT COMPLET]`);
        }, 500);
        
    } catch (err) {
        console.error('❌ Erreur lors du chargement:', err);
        alert('❌ Erreur: ' + err.message);
    }
}

/**
 * Afficher les résultats du test
 */
function afficherResultatsTest(materiau) {
    const mat = MATERIAUX_TEST[materiau];
    if (!mat) return;
    
    console.log(`\n🧪 RÉSULTATS TEST: ${mat.nom}`);
    console.log(`═════════════════════════════════════════`);
    
    // Vérifier ATOMIC_SPECIES
    if (window.atomicSpeciesGlobal) {
        console.log(`\n✅ ATOMIC_SPECIES (${mat.ntyp} espèces):`);
        console.log(window.atomicSpeciesGlobal);
    } else {
        console.warn(`❌ ATOMIC_SPECIES vide!`);
    }
    
    // Vérifier ATOMIC_POSITIONS
    if (window.atomicPositionsContent) {
        console.log(`\n✅ ATOMIC_POSITIONS (${mat.nat} atomes):`);
        console.log(window.atomicPositionsContent);
        
        // Vérifier que les symboles atomiques sont affichés
        const lines = window.atomicPositionsContent.split('\n').slice(1);
        let atomesCorrects = 0;
        let atomesManques = 0;
        
        lines.forEach(line => {
            if (line.trim()) {
                const parts = line.trim().split(/\s+/);
                const symbole = parts[0];
                
                if (symbole === 'Atom_1' || symbole === 'Atom_2' || symbole === 'Atom_3' || symbole === 'Atom_4') {
                    atomesManques++;
                    console.warn(`   ⚠️ Symbole manquant: ${symbole}`);
                } else {
                    atomesCorrects++;
                    console.log(`   ✓ ${symbole} ${parts[1]} ${parts[2]} ${parts[3]}`);
                }
            }
        });
        
        if (atomesManques > 0) {
            console.warn(`\n⚠️ ${atomesManques}/${mat.nat} symboles manquants!`);
        } else {
            console.log(`\n✅ ${atomesCorrects}/${mat.nat} symboles corrects!`);
        }
    } else {
        console.warn(`❌ ATOMIC_POSITIONS vide!`);
    }
    
    console.log(`═════════════════════════════════════════\n`);
}

/**
 * Initialiser le testeur
 */
function initialiserTesteur() {
    console.log('🧪 Initialisation du testeur de matériaux...');
    
    setTimeout(() => {
        creerSectionTest();
        console.log('✅ Testeur initialisé');
    }, 500);
}

// Exécuter à l'initialisation
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialiserTesteur);
} else {
    initialiserTesteur();
}

console.log('✅ Script de test chargé');








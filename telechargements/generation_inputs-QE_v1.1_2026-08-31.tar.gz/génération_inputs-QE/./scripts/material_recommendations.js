/**
 * material_recommendations.js — Conseils de convergence après détection d'espèces.
 * Appelle /api/convergence/recommend et affiche un panneau compact.
 */
(function () {
    'use strict';

    var PANEL_ID = 'material_recommendations_panel';

    function apiBase() {
        if (typeof window.getGenInputsApiBase === 'function') return window.getGenInputsApiBase();
        if (typeof window.QE_API_URL === 'string' && window.QE_API_URL) return window.QE_API_URL.replace(/\/$/, '');
        var p = window.QE_API_PORT || 5012;
        return 'http://127.0.0.1:' + p;
    }

    function ensurePanel() {
        var existing = document.getElementById(PANEL_ID);
        if (existing) return existing;
        var anchor = document.getElementById('atomic_species_format')
            || document.getElementById('section_3_especes')
            || document.getElementById('pseudos_list');
        if (!anchor) return null;
        var panel = document.createElement('div');
        panel.id = PANEL_ID;
        panel.style.cssText = 'display:none;margin-top:12px;padding:12px 14px;border-radius:8px;border-left:4px solid #0891b2;background:#ecfeff;color:#0e7490;font-size:0.88em;line-height:1.45;';
        if (anchor.parentNode) {
            anchor.parentNode.insertBefore(panel, anchor.nextSibling);
        }
        return panel;
    }

    function renderPanel(data, species) {
        var panel = ensurePanel();
        if (!panel) return;
        if (!data || !data.ok) {
            panel.style.display = 'none';
            return;
        }
        var prof = data.profile || {};
        var tips = [];
        if (prof.ecutwfc) tips.push('<code>ecutwfc</code> ≈ ' + prof.ecutwfc + ' Ry');
        if (prof.ecutrho) tips.push('<code>ecutrho</code> ≈ ' + prof.ecutrho + ' Ry');
        if (prof.mixing_beta) tips.push('<code>mixing_beta</code> ≈ ' + prof.mixing_beta);
        if (prof.degauss) tips.push('<code>degauss</code> ≈ ' + prof.degauss);
        if (prof.k_points && prof.k_points.length) tips.push('maille k ≈ ' + prof.k_points.join('×'));
        panel.innerHTML = '<strong>💡 Recommandations (' + (data.class_name || data.detected_class || 'matériau') + ')</strong>'
            + (data.class_description ? '<br><span style="opacity:0.9;">' + data.class_description + '</span>' : '')
            + (species && species.length ? '<br>Espèces : ' + species.join(', ') : '')
            + (tips.length ? '<br>' + tips.join(' · ') : '');
        panel.style.display = 'block';
    }

    window.fetchMaterialRecommendations = async function (opts) {
        opts = opts || {};
        var species = opts.atomic_species || opts.species || [];
        if (!Array.isArray(species)) species = [];
        var formula = String(opts.formula || '').trim();
        if (!formula && species.length) formula = species.join('');
        if (!formula && !species.length) return null;

        var calcEl = document.getElementById('calc_type') || document.getElementById('cif_calc_type');
        var calculation = opts.calculation || (calcEl ? String(calcEl.value || 'scf') : 'scf');

        try {
            var r = await fetch(apiBase() + '/api/convergence/recommend', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    formula: formula,
                    atomic_species: species,
                    calculation: calculation
                })
            });
            if (!r.ok) return null;
            var data = await r.json();
            renderPanel(data, species);
            return data;
        } catch (_e) {
            return null;
        }
    };

    window.onSpeciesDetectedForRecommendations = function (species, formula) {
        if (!species || !species.length) return;
        window.fetchMaterialRecommendations({ atomic_species: species, formula: formula });
    };
})();

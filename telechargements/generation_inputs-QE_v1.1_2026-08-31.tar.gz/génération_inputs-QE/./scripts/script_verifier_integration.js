// ═══════════════════════════════════════════════════════════════════════════
// TEST DE VÉRIFICATION: ATOMIC_SPECIES et ATOMIC_POSITIONS dans INPUT FINAL
// ═══════════════════════════════════════════════════════════════════════════

function verifierIntegrationDansInput() {
    console.log('\n\n═══════════════════════════════════════════════════════════════');
    console.log('🔍 VÉRIFICATION INTÉGRATION ATOMIC_SPECIES ET ATOMIC_POSITIONS');
    console.log('═══════════════════════════════════════════════════════════════\n');
    
    // ═══════════════════════════════════════════════════════════════
    // ÉTAPE 1: Vérifier que les données sources existent
    // ═══════════════════════════════════════════════════════════════
    console.log('📊 ÉTAPE 1: Vérification des données sources\n');
    
    console.log('window.atomicSpeciesGlobal:');
    if (window.atomicSpeciesGlobal && window.atomicSpeciesGlobal.length > 0) {
        console.log('  ✅ EXISTE (' + window.atomicSpeciesGlobal.length + ' caractères)');
        console.log('  Contenu:');
        console.log('─'.repeat(60));
        console.log(window.atomicSpeciesGlobal);
        console.log('─'.repeat(60));
    } else {
        console.error('  ❌ VIDE OU INEXISTANT');
        console.log('  Valeur:', window.atomicSpeciesGlobal);
    }
    
    console.log('\nwindow.atomicPositionsContent:');
    if (window.atomicPositionsContent && window.atomicPositionsContent.length > 0) {
        console.log('  ✅ EXISTE (' + window.atomicPositionsContent.length + ' caractères)');
        console.log('  Contenu:');
        console.log('─'.repeat(60));
        console.log(window.atomicPositionsContent);
        console.log('─'.repeat(60));
    } else {
        console.error('  ❌ VIDE OU INEXISTANT');
        console.log('  Valeur:', window.atomicPositionsContent);
    }
    
    // ═══════════════════════════════════════════════════════════════
    // ÉTAPE 2: Générer l'input final
    // ═══════════════════════════════════════════════════════════════
    console.log('\n\n📊 ÉTAPE 2: Génération de l\'input final\n');
    
    console.log('Appel de genererInputAvecPreparation()...');
    if (typeof genererInputAvecPreparation === 'function') {
        genererInputAvecPreparation();
        console.log('✓ Fonction appelée');
    } else {
        console.error('❌ genererInputAvecPreparation() NOT FOUND');
        return;
    }
    
    // Attendre un peu que la génération se termine
    setTimeout(() => {
        console.log('\n\n📊 ÉTAPE 3: Vérification de l\'input final généré\n');
        
        if (!window.currentInputContent) {
            console.error('❌ window.currentInputContent est VIDE ou INEXISTANT!');
            console.log('Valeur:', window.currentInputContent);
            return;
        }
        
        console.log('✅ window.currentInputContent existe (' + window.currentInputContent.length + ' caractères)');
        
        // ═══════════════════════════════════════════════════════════════
        // ÉTAPE 3: Vérifier ATOMIC_SPECIES dans l'input
        // ═══════════════════════════════════════════════════════════════
        console.log('\n\n📊 ÉTAPE 4: Vérification ATOMIC_SPECIES dans l\'input\n');
        
        const hasAtomicSpeciesKeyword = window.currentInputContent.includes('ATOMIC_SPECIES');
        const hasBa = window.currentInputContent.includes('Ba ');
        const hasTi = window.currentInputContent.includes('Ti ');
        const hasO = window.currentInputContent.includes('O ');
        
        console.log('Mots-clés recherchés:');
        console.log('  "ATOMIC_SPECIES":', hasAtomicSpeciesKeyword ? '✅ TROUVÉ' : '❌ ABSENT');
        console.log('  "Ba ":', hasBa ? '✅ TROUVÉ' : '❌ ABSENT');
        console.log('  "Ti ":', hasTi ? '✅ TROUVÉ' : '❌ ABSENT');
        console.log('  "O ":', hasO ? '✅ TROUVÉ' : '❌ ABSENT');
        
        if (hasAtomicSpeciesKeyword && hasBa && hasTi && hasO) {
            console.log('\n✅✅✅ ATOMIC_SPECIES EST INTÉGRÉ DANS L\'INPUT! ✅✅✅');
            
            // Extraire et afficher la section ATOMIC_SPECIES
            const lines = window.currentInputContent.split('\n');
            let inAtomicSpecies = false;
            let atomicSpeciesLines = [];
            
            for (const line of lines) {
                if (line.includes('ATOMIC_SPECIES')) {
                    inAtomicSpecies = true;
                    atomicSpeciesLines.push(line);
                    continue;
                }
                if (inAtomicSpecies) {
                    if (line.trim() === '' || line.includes('ATOMIC_POSITIONS') || line.includes('K_POINTS')) {
                        break;
                    }
                    atomicSpeciesLines.push(line);
                }
            }
            
            console.log('\nSection ATOMIC_SPECIES dans l\'input:');
            console.log('═'.repeat(60));
            console.log(atomicSpeciesLines.join('\n'));
            console.log('═'.repeat(60));
        } else {
            console.error('\n❌❌❌ ATOMIC_SPECIES PAS CORRECTEMENT INTÉGRÉ! ❌❌❌');
        }
        
        // ═══════════════════════════════════════════════════════════════
        // ÉTAPE 4: Vérifier ATOMIC_POSITIONS dans l'input
        // ═══════════════════════════════════════════════════════════════
        console.log('\n\n📊 ÉTAPE 5: Vérification ATOMIC_POSITIONS dans l\'input\n');
        
        const hasAtomicPositionsKeyword = window.currentInputContent.includes('ATOMIC_POSITIONS');
        
        // Compter les lignes de positions
        const lines = window.currentInputContent.split('\n');
        let inPositions = false;
        let positionsCount = 0;
        let positionsLines = [];
        
        for (const line of lines) {
            if (line.includes('ATOMIC_POSITIONS')) {
                inPositions = true;
                positionsLines.push(line);
                continue;
            }
            if (inPositions) {
                if (line.trim() === '' || line.includes('K_POINTS')) {
                    break;
                }
                positionsLines.push(line);
                positionsCount++;
            }
        }
        
        console.log('Mots-clés recherchés:');
        console.log('  "ATOMIC_POSITIONS":', hasAtomicPositionsKeyword ? '✅ TROUVÉ' : '❌ ABSENT');
        console.log('  Nombre de positions:', positionsCount);
        
        // Vérifier que ce n'est pas que des 0.000000
        const hasNonZeroPositions = positionsLines.some(line => 
            line.includes('0.5') || line.includes('0.25') || line.includes('0.75') || line.includes('0.33')
        );
        
        console.log('  Positions non nulles:', hasNonZeroPositions ? '✅ OUI' : '❌ NON (tout à 0.000000)');
        
        // Vérifier les symboles
        const hasBaSymbol = positionsLines.some(line => line.trim().startsWith('Ba'));
        const hasTiSymbol = positionsLines.some(line => line.trim().startsWith('Ti'));
        const hasOSymbol = positionsLines.some(line => line.trim().startsWith('O'));
        
        console.log('  Symboles atomiques:');
        console.log('    Ba:', hasBaSymbol ? '✅ PRÉSENT' : '❌ ABSENT');
        console.log('    Ti:', hasTiSymbol ? '✅ PRÉSENT' : '❌ ABSENT');
        console.log('    O:', hasOSymbol ? '✅ PRÉSENT' : '❌ ABSENT');
        
        if (hasAtomicPositionsKeyword && positionsCount >= 5 && hasNonZeroPositions && hasBaSymbol && hasTiSymbol && hasOSymbol) {
            console.log('\n✅✅✅ ATOMIC_POSITIONS EST INTÉGRÉ CORRECTEMENT! ✅✅✅');
            
            console.log('\nSection ATOMIC_POSITIONS dans l\'input:');
            console.log('═'.repeat(60));
            console.log(positionsLines.join('\n'));
            console.log('═'.repeat(60));
        } else {
            console.error('\n❌❌❌ ATOMIC_POSITIONS PAS CORRECTEMENT INTÉGRÉ! ❌❌❌');
        }
        
        // ═══════════════════════════════════════════════════════════════
        // RÉSUMÉ FINAL
        // ═══════════════════════════════════════════════════════════════
        console.log('\n\n═══════════════════════════════════════════════════════════════');
        console.log('📋 RÉSUMÉ FINAL DE LA VÉRIFICATION');
        console.log('═══════════════════════════════════════════════════════════════\n');
        
        const checks = {
            'window.atomicSpeciesGlobal existe': !!(window.atomicSpeciesGlobal && window.atomicSpeciesGlobal.length > 0),
            'window.atomicPositionsContent existe': !!(window.atomicPositionsContent && window.atomicPositionsContent.length > 0),
            'window.currentInputContent existe': !!(window.currentInputContent && window.currentInputContent.length > 0),
            'ATOMIC_SPECIES dans input': hasAtomicSpeciesKeyword && hasBa && hasTi && hasO,
            'ATOMIC_POSITIONS dans input': hasAtomicPositionsKeyword && positionsCount >= 5,
            'Positions non nulles': hasNonZeroPositions,
            'Symboles atomiques corrects': hasBaSymbol && hasTiSymbol && hasOSymbol
        };
        
        let allPassed = true;
        Object.entries(checks).forEach(([check, passed]) => {
            console.log(`  ${passed ? '✅' : '❌'} ${check}`);
            if (!passed) allPassed = false;
        });
        
        console.log('\n' + '═'.repeat(60));
        if (allPassed) {
            console.log('🎉🎉🎉 TOUS LES TESTS RÉUSSIS! 🎉🎉🎉');
            console.log('✅ ATOMIC_SPECIES et ATOMIC_POSITIONS sont correctement intégrés!');
        } else {
            console.error('❌❌❌ CERTAINS TESTS ONT ÉCHOUÉ ❌❌❌');
            console.log('Voir les détails ci-dessus.');
        }
        console.log('═'.repeat(60) + '\n\n');
        
    }, 1000);  // Attendre 1 seconde après la génération
}

console.log('✅ Script de vérification intégration chargé');
console.log('📋 Lancez: verifierIntegrationDansInput()');



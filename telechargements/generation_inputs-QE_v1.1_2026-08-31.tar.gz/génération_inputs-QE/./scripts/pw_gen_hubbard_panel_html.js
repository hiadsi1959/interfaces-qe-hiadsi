/**
 * Panneau DFT+U pour le formulaire restructuré (Tab 1 — génération directe).
 * Le script script_tab1_restructuration_v2.js remplace le HTML initial et supprimait gen_hubbard_*.
 */
(function () {
    'use strict';

    if (typeof window.toggleManifoldVisibility !== 'function') {
        window.toggleManifoldVisibility = function toggleManifoldVisibility(prefix) {
            var syn = document.getElementById(prefix + '_hubbard_syntax');
            var wrap = document.getElementById(prefix + '_hubbard_manifold_wrap');
            if (syn && wrap) wrap.style.display = syn.value === 'card' ? 'block' : 'none';
        };
    }

    window.pwGenHubbardPanelHtml = function pwGenHubbardPanelHtml() {
        return ''
            + '<div id="gen_hubbard_u_after_mag" class="gen-hubbard-panel-visible" style="display:block;margin:18px 0;padding:14px 16px;background:linear-gradient(135deg,#fff7ed 0%,#ffedd5 100%);border:2px solid #c2410c;border-radius:10px;">'
            + '<div style="font-weight:700;color:#9a3412;font-size:1.05em;margin-bottom:10px;">🔶 DFT+U — termes U (eV) par espèce</div>'
            + '<div id="gen_hubbard_species_zone" style="overflow-x:auto;margin-bottom:12px;">'
            + '<div style="padding:10px;background:#fff;border:1px dashed #fdba74;border-radius:6px;color:#78350f;font-size:0.85em;">'
            + 'Renseignez les éléments (section 3) puis cliquez <strong>Lire les espèces</strong>. Les U sont pré-remplis depuis <code>hubbard_u_defaults.json</code>.'
            + '</div></div>'
            + '<div id="gen_hubbard_panel" style="font-size:0.92em;color:#431407;line-height:1.5;">'
            + '<label style="display:flex;gap:10px;align-items:center;font-weight:600;margin-bottom:10px;cursor:pointer;">'
            + '<input type="checkbox" id="gen_hubbard_enable" checked style="width:18px;height:18px;">'
            + 'Inclure DFT+U dans l\'input généré</label>'
            + '<label style="display:flex;gap:10px;align-items:flex-start;margin:0 0 12px;font-size:0.86em;line-height:1.45;cursor:pointer;color:#78350f;">'
            + '<input type="checkbox" id="gen_hubbard_auto_spin" style="width:18px;height:18px;margin-top:2px;flex-shrink:0;">'
            + '<span><strong>LSDA + DFT+U (optionnel)</strong> si des <code>U ≠ 0</code> : cocher pour ajouter <code>nspin = 2</code> + aimantation de départ sur les espèces Hubbard (BaTiO3 diamagnétique : laisser décoché).</span></label>'
            + '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-bottom:12px;">'
            + '<div><label style="font-weight:600;font-size:0.85em;">Représentation des U</label>'
            + '<select id="gen_hubbard_syntax" style="width:100%;padding:8px;border:2px solid #ea580c;border-radius:6px;">'
            + '<option value="card" selected>Simple — carte HUBBARD (QE 7.3+)</option>'
            + '<option value="legacy">Experts — Hubbard_U(i) dans &amp;SYSTEM</option>'
            + '</select></div>'
            + '<div id="gen_hubbard_manifold_wrap" style="display:none;">'
            + '<label style="font-weight:600;font-size:0.85em;">Manifold orbital (carte)</label>'
            + '<p style="margin:4px 0 0;font-size:0.78em;color:#78350f;line-height:1.4;">Réglé <strong>par espèce</strong> dans le tableau (ex. Gd→4f, V→3d).</p>'
            + '<input type="hidden" id="gen_hubbard_manifold" value="3d">'
            + '</div>'
            + '<div><label style="font-weight:600;font-size:0.85em;">Projection carte (QE)</label>'
            + '<select id="gen_hubbard_projection" style="width:100%;padding:8px;border:2px solid #ea580c;border-radius:6px;">'
            + '<option value="ortho-atomic" selected>ortho-atomic (recommandé)</option>'
            + '<option value="atomic">atomic</option>'
            + '<option value="norm-atomic">norm-atomic</option>'
            + '</select></div></div>'
            + '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:4px;">'
            + '<button type="button" id="btn_gen_hubbard_detect" style="padding:8px 14px;border-radius:6px;border:2px solid #ea580c;background:#fff;color:#9a3412;font-weight:600;cursor:pointer;font-size:0.85em;">'
            + '🔍 Lire les espèces depuis ATOMIC_SPECIES</button>'
            + '<small style="align-self:center;color:#57534e;">Vide ou 0 = sans U pour cette espèce.</small>'
            + '</div></div></div>'
            + '<textarea id="atomic_species" style="position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0;" aria-hidden="true" tabindex="-1"></textarea>';
            // Pas de #nspin ici : le sélecteur unique est dans la section Magnétisme (évite ID dupliqué).
    };

    window.pwGenInitHubbardPanel = function pwGenInitHubbardPanel() {
        var block = document.getElementById('gen_hubbard_u_after_mag');
        if (!block) return;

        if (typeof window.pwGenShowHubbardPanel === 'function') {
            window.pwGenShowHubbardPanel();
        }

        var btn = document.getElementById('btn_gen_hubbard_detect');
        if (btn && !btn.dataset.bound) {
            btn.dataset.bound = '1';
            btn.addEventListener('click', function () {
                if (typeof window.genHubbardDetectFromTextarea === 'function') {
                    window.genHubbardDetectFromTextarea();
                }
            });
        }

        var ghEn = document.getElementById('gen_hubbard_enable');
        if (ghEn && !ghEn.dataset.bound) {
            ghEn.dataset.bound = '1';
            ghEn.addEventListener('change', function () {
                if (typeof window.pwGenShowHubbardPanel === 'function') window.pwGenShowHubbardPanel();
                if (ghEn.checked && typeof window.genHubbardDetectFromTextarea === 'function') {
                    window.genHubbardDetectFromTextarea();
                }
            });
        }

        var sGen = document.getElementById('gen_hubbard_syntax');
        if (sGen && !sGen.dataset.bound) {
            sGen.dataset.bound = '1';
            sGen.addEventListener('change', function () {
                if (typeof window.toggleManifoldVisibility === 'function') {
                    window.toggleManifoldVisibility('gen');
                }
            });
        }

        if (typeof window.pwGenRefreshHubbardPanel === 'function') {
            window.pwGenRefreshHubbardPanel();
        }

        if (typeof window.toggleManifoldVisibility === 'function') {
            window.toggleManifoldVisibility('gen');
        }
    };

    window.pwGenSyncHiddenFieldsFromWorkflow = function pwGenSyncHiddenFieldsFromWorkflow() {
        var ta = document.getElementById('atomic_species');
        if (ta && window.atomicSpeciesGlobal) {
            ta.value = String(window.atomicSpeciesGlobal).trim();
        }
        var nspinEl = document.getElementById('nspin');
        var tm = window.typeMagnetisme || 'non_mag';
        if (nspinEl) {
            if (tm === 'mag') nspinEl.value = '2';
            else if (tm === 'non_colin') nspinEl.value = '4';
            else nspinEl.value = '1';
        }
    };
})();

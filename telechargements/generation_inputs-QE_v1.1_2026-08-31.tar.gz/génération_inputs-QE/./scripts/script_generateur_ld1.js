/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * GÉNÉRATEUR DE PSEUDOPOTENTIELS - ld1.x
 * Génère des fichiers ld1.in pour Quantum ESPRESSO
 * ═══════════════════════════════════════════════════════════════════════════════
 */

// Configuration
const LD1_CONFIG = {
    QE_BIN: '/home/hiadsi/q-e-qe-7.5/bin',
    PSEUDO_DIR: '/home/hiadsi/Interface-QE_v1/pseudos/PBE',
    PSEUDO_GENERES_DIR: '/home/hiadsi/Interface-QE_v1/pseudos/Pseudo_generes',
    LD1_INPUTS_DIR: '/home/hiadsi/Interface-QE_v1/pseudos/Pseudo_generes/ld1_inputs',
    INPUTS_DIR: '/home/hiadsi/Interface-QE_v1/inputs'
};

/**
 * Base de données complète des éléments avec configurations électroniques
 * et paramètres recommandés pour ld1.x
 */
const ELEMENTS_LD1 = {
    // Période 1
    'H':  { Z: 1,  config: '1s1', core: '', valence: '1s1', rcut: [1.0], orbitals: ['1S'] },
    'He': { Z: 2,  config: '1s2', core: '', valence: '1s2', rcut: [1.2], orbitals: ['1S'] },
    
    // Période 2
    'Li': { Z: 3,  config: '[He] 2s1', core: '1s2', valence: '2s1', rcut: [2.0, 2.0], orbitals: ['2S', '2P'] },
    'Be': { Z: 4,  config: '[He] 2s2', core: '1s2', valence: '2s2', rcut: [1.8, 1.8], orbitals: ['2S', '2P'] },
    'B':  { Z: 5,  config: '[He] 2s2 2p1', core: '1s2', valence: '2s2 2p1', rcut: [1.6, 1.6], orbitals: ['2S', '2P'] },
    'C':  { Z: 6,  config: '[He] 2s2 2p2', core: '1s2', valence: '2s2 2p2', rcut: [1.5, 1.5], orbitals: ['2S', '2P'] },
    'N':  { Z: 7,  config: '[He] 2s2 2p3', core: '1s2', valence: '2s2 2p3', rcut: [1.4, 1.4], orbitals: ['2S', '2P'] },
    'O':  { Z: 8,  config: '[He] 2s2 2p4', core: '1s2', valence: '2s2 2p4', rcut: [1.4, 1.4], orbitals: ['2S', '2P'] },
    'F':  { Z: 9,  config: '[He] 2s2 2p5', core: '1s2', valence: '2s2 2p5', rcut: [1.3, 1.3], orbitals: ['2S', '2P'] },
    'Ne': { Z: 10, config: '[He] 2s2 2p6', core: '1s2', valence: '2s2 2p6', rcut: [1.3, 1.3], orbitals: ['2S', '2P'] },
    
    // Période 3
    'Na': { Z: 11, config: '[Ne] 3s1', core: '1s2 2s2 2p6', valence: '3s1', rcut: [2.2, 2.2], orbitals: ['3S', '3P'] },
    'Mg': { Z: 12, config: '[Ne] 3s2', core: '1s2 2s2 2p6', valence: '3s2', rcut: [2.0, 2.0], orbitals: ['3S', '3P'] },
    'Al': { Z: 13, config: '[Ne] 3s2 3p1', core: '1s2 2s2 2p6', valence: '3s2 3p1', rcut: [2.0, 2.0], orbitals: ['3S', '3P'] },
    'Si': { Z: 14, config: '[Ne] 3s2 3p2', core: '1s2 2s2 2p6', valence: '3s2 3p2', rcut: [1.8, 1.8], orbitals: ['3S', '3P'] },
    'P':  { Z: 15, config: '[Ne] 3s2 3p3', core: '1s2 2s2 2p6', valence: '3s2 3p3', rcut: [1.8, 1.8], orbitals: ['3S', '3P'] },
    'S':  { Z: 16, config: '[Ne] 3s2 3p4', core: '1s2 2s2 2p6', valence: '3s2 3p4', rcut: [1.7, 1.7], orbitals: ['3S', '3P'] },
    'Cl': { Z: 17, config: '[Ne] 3s2 3p5', core: '1s2 2s2 2p6', valence: '3s2 3p5', rcut: [1.6, 1.6], orbitals: ['3S', '3P'] },
    'Ar': { Z: 18, config: '[Ne] 3s2 3p6', core: '1s2 2s2 2p6', valence: '3s2 3p6', rcut: [1.6, 1.6], orbitals: ['3S', '3P'] },
    
    // Période 4 - Métaux de transition
    'K':  { Z: 19, config: '[Ar] 4s1', core: '[Ne] 3s2 3p6', valence: '3s2 3p6 4s1', rcut: [2.5, 2.5, 2.5], orbitals: ['3S', '3P', '4S'] },
    'Ca': { Z: 20, config: '[Ar] 4s2', core: '[Ne] 3s2 3p6', valence: '3s2 3p6 4s2', rcut: [2.3, 2.3, 2.3], orbitals: ['3S', '3P', '4S'] },
    'Sc': { Z: 21, config: '[Ar] 3d1 4s2', core: '[Ne] 3s2 3p6', valence: '3d1 4s2', rcut: [2.2, 2.2, 2.2], orbitals: ['3D', '4S', '4P'] },
    'Ti': { Z: 22, config: '[Ar] 3d2 4s2', core: '[Ne] 3s2 3p6', valence: '3d2 4s2', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'V':  { Z: 23, config: '[Ar] 3d3 4s2', core: '[Ne] 3s2 3p6', valence: '3d3 4s2', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Cr': { Z: 24, config: '[Ar] 3d5 4s1', core: '[Ne] 3s2 3p6', valence: '3d5 4s1', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Mn': { Z: 25, config: '[Ar] 3d5 4s2', core: '[Ne] 3s2 3p6', valence: '3d5 4s2', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Fe': { Z: 26, config: '[Ar] 3d6 4s2', core: '[Ne] 3s2 3p6', valence: '3d6 4s2', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Co': { Z: 27, config: '[Ar] 3d7 4s2', core: '[Ne] 3s2 3p6', valence: '3d7 4s2', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Ni': { Z: 28, config: '[Ar] 3d8 4s2', core: '[Ne] 3s2 3p6', valence: '3d8 4s2', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Cu': { Z: 29, config: '[Ar] 3d10 4s1', core: '[Ne] 3s2 3p6', valence: '3d10 4s1', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Zn': { Z: 30, config: '[Ar] 3d10 4s2', core: '[Ne] 3s2 3p6', valence: '3d10 4s2', rcut: [2.0, 2.0, 2.0], orbitals: ['3D', '4S', '4P'] },
    'Ga': { Z: 31, config: '[Ar] 3d10 4s2 4p1', core: '[Ar] 3d10', valence: '4s2 4p1', rcut: [2.2, 2.2], orbitals: ['4S', '4P'] },
    'Ge': { Z: 32, config: '[Ar] 3d10 4s2 4p2', core: '[Ar] 3d10', valence: '4s2 4p2', rcut: [2.1, 2.1], orbitals: ['4S', '4P'] },
    'As': { Z: 33, config: '[Ar] 3d10 4s2 4p3', core: '[Ar] 3d10', valence: '4s2 4p3', rcut: [2.0, 2.0], orbitals: ['4S', '4P'] },
    'Se': { Z: 34, config: '[Ar] 3d10 4s2 4p4', core: '[Ar] 3d10', valence: '4s2 4p4', rcut: [2.0, 2.0], orbitals: ['4S', '4P'] },
    'Br': { Z: 35, config: '[Ar] 3d10 4s2 4p5', core: '[Ar] 3d10', valence: '4s2 4p5', rcut: [1.9, 1.9], orbitals: ['4S', '4P'] },
    'Kr': { Z: 36, config: '[Ar] 3d10 4s2 4p6', core: '[Ar] 3d10', valence: '4s2 4p6', rcut: [1.9, 1.9], orbitals: ['4S', '4P'] },
    
    // Période 5
    'Rb': { Z: 37, config: '[Kr] 5s1', core: '[Ar] 3d10 4s2 4p6', valence: '5s1', rcut: [2.8], orbitals: ['5S'] },
    'Sr': { Z: 38, config: '[Kr] 5s2', core: '[Ar] 3d10 4s2 4p6', valence: '5s2', rcut: [2.6], orbitals: ['5S'] },
    'Y':  { Z: 39, config: '[Kr] 4d1 5s2', core: '[Kr]', valence: '4d1 5s2', rcut: [2.4, 2.4, 2.4], orbitals: ['4D', '5S', '5P'] },
    'Zr': { Z: 40, config: '[Kr] 4d2 5s2', core: '[Kr]', valence: '4d2 5s2', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Nb': { Z: 41, config: '[Kr] 4d4 5s1', core: '[Kr]', valence: '4d4 5s1', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Mo': { Z: 42, config: '[Kr] 4d5 5s1', core: '[Kr]', valence: '4d5 5s1', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Tc': { Z: 43, config: '[Kr] 4d5 5s2', core: '[Kr]', valence: '4d5 5s2', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Ru': { Z: 44, config: '[Kr] 4d7 5s1', core: '[Kr]', valence: '4d7 5s1', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Rh': { Z: 45, config: '[Kr] 4d8 5s1', core: '[Kr]', valence: '4d8 5s1', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Pd': { Z: 46, config: '[Kr] 4d10', core: '[Kr]', valence: '4d10', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Ag': { Z: 47, config: '[Kr] 4d10 5s1', core: '[Kr]', valence: '4d10 5s1', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'Cd': { Z: 48, config: '[Kr] 4d10 5s2', core: '[Kr]', valence: '4d10 5s2', rcut: [2.2, 2.2, 2.2], orbitals: ['4D', '5S', '5P'] },
    'In': { Z: 49, config: '[Kr] 4d10 5s2 5p1', core: '[Kr] 4d10', valence: '5s2 5p1', rcut: [2.4, 2.4], orbitals: ['5S', '5P'] },
    'Sn': { Z: 50, config: '[Kr] 4d10 5s2 5p2', core: '[Kr] 4d10', valence: '5s2 5p2', rcut: [2.3, 2.3], orbitals: ['5S', '5P'] },
    'Sb': { Z: 51, config: '[Kr] 4d10 5s2 5p3', core: '[Kr] 4d10', valence: '5s2 5p3', rcut: [2.2, 2.2], orbitals: ['5S', '5P'] },
    'Te': { Z: 52, config: '[Kr] 4d10 5s2 5p4', core: '[Kr] 4d10', valence: '5s2 5p4', rcut: [2.2, 2.2], orbitals: ['5S', '5P'] },
    'I':  { Z: 53, config: '[Kr] 4d10 5s2 5p5', core: '[Kr] 4d10', valence: '5s2 5p5', rcut: [2.1, 2.1], orbitals: ['5S', '5P'] },
    'Xe': { Z: 54, config: '[Kr] 4d10 5s2 5p6', core: '[Kr] 4d10', valence: '5s2 5p6', rcut: [2.1, 2.1], orbitals: ['5S', '5P'] },
    
    // Période 6 - incluant lanthanides
    'Cs': { Z: 55, config: '[Xe] 6s1', core: '[Xe]', valence: '6s1', rcut: [3.0], orbitals: ['6S'] },
    'Ba': { Z: 56, config: '[Xe] 6s2', core: '[Xe]', valence: '6s2', rcut: [2.8], orbitals: ['6S'] },
    'La': { Z: 57, config: '[Xe] 5d1 6s2', core: '[Xe]', valence: '5d1 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['5D', '6S', '6P'] },
    'Ce': { Z: 58, config: '[Xe] 4f1 5d1 6s2', core: '[Xe]', valence: '4f1 5d1 6s2', rcut: [2.5, 2.5, 2.5, 2.5], orbitals: ['4F', '5D', '6S', '6P'] },
    'Pr': { Z: 59, config: '[Xe] 4f3 6s2', core: '[Xe]', valence: '4f3 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Nd': { Z: 60, config: '[Xe] 4f4 6s2', core: '[Xe]', valence: '4f4 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Pm': { Z: 61, config: '[Xe] 4f5 6s2', core: '[Xe]', valence: '4f5 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Sm': { Z: 62, config: '[Xe] 4f6 6s2', core: '[Xe]', valence: '4f6 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Eu': { Z: 63, config: '[Xe] 4f7 6s2', core: '[Xe]', valence: '4f7 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Gd': { Z: 64, config: '[Xe] 4f7 5d1 6s2', core: '[Xe]', valence: '4f7 5d1 6s2', rcut: [2.5, 2.5, 2.5, 2.5], orbitals: ['4F', '5D', '6S', '6P'] },
    'Tb': { Z: 65, config: '[Xe] 4f9 6s2', core: '[Xe]', valence: '4f9 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Dy': { Z: 66, config: '[Xe] 4f10 6s2', core: '[Xe]', valence: '4f10 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Ho': { Z: 67, config: '[Xe] 4f11 6s2', core: '[Xe]', valence: '4f11 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Er': { Z: 68, config: '[Xe] 4f12 6s2', core: '[Xe]', valence: '4f12 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Tm': { Z: 69, config: '[Xe] 4f13 6s2', core: '[Xe]', valence: '4f13 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Yb': { Z: 70, config: '[Xe] 4f14 6s2', core: '[Xe]', valence: '4f14 6s2', rcut: [2.5, 2.5, 2.5], orbitals: ['4F', '6S', '6P'] },
    'Lu': { Z: 71, config: '[Xe] 4f14 5d1 6s2', core: '[Xe] 4f14', valence: '5d1 6s2', rcut: [2.4, 2.4, 2.4], orbitals: ['5D', '6S', '6P'] },
    'Hf': { Z: 72, config: '[Xe] 4f14 5d2 6s2', core: '[Xe] 4f14', valence: '5d2 6s2', rcut: [2.3, 2.3, 2.3], orbitals: ['5D', '6S', '6P'] },
    'Ta': { Z: 73, config: '[Xe] 4f14 5d3 6s2', core: '[Xe] 4f14', valence: '5d3 6s2', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'W':  { Z: 74, config: '[Xe] 4f14 5d4 6s2', core: '[Xe] 4f14', valence: '5d4 6s2', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'Re': { Z: 75, config: '[Xe] 4f14 5d5 6s2', core: '[Xe] 4f14', valence: '5d5 6s2', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'Os': { Z: 76, config: '[Xe] 4f14 5d6 6s2', core: '[Xe] 4f14', valence: '5d6 6s2', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'Ir': { Z: 77, config: '[Xe] 4f14 5d7 6s2', core: '[Xe] 4f14', valence: '5d7 6s2', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'Pt': { Z: 78, config: '[Xe] 4f14 5d9 6s1', core: '[Xe] 4f14', valence: '5d9 6s1', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'Au': { Z: 79, config: '[Xe] 4f14 5d10 6s1', core: '[Xe] 4f14', valence: '5d10 6s1', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'Hg': { Z: 80, config: '[Xe] 4f14 5d10 6s2', core: '[Xe] 4f14', valence: '5d10 6s2', rcut: [2.2, 2.2, 2.2], orbitals: ['5D', '6S', '6P'] },
    'Tl': { Z: 81, config: '[Xe] 4f14 5d10 6s2 6p1', core: '[Xe] 4f14 5d10', valence: '6s2 6p1', rcut: [2.5, 2.5], orbitals: ['6S', '6P'] },
    'Pb': { Z: 82, config: '[Xe] 4f14 5d10 6s2 6p2', core: '[Xe] 4f14 5d10', valence: '6s2 6p2', rcut: [2.4, 2.4], orbitals: ['6S', '6P'] },
    'Bi': { Z: 83, config: '[Xe] 4f14 5d10 6s2 6p3', core: '[Xe] 4f14 5d10', valence: '6s2 6p3', rcut: [2.4, 2.4], orbitals: ['6S', '6P'] },
    'Po': { Z: 84, config: '[Xe] 4f14 5d10 6s2 6p4', core: '[Xe] 4f14 5d10', valence: '6s2 6p4', rcut: [2.3, 2.3], orbitals: ['6S', '6P'] },
    'At': { Z: 85, config: '[Xe] 4f14 5d10 6s2 6p5', core: '[Xe] 4f14 5d10', valence: '6s2 6p5', rcut: [2.3, 2.3], orbitals: ['6S', '6P'] },
    'Rn': { Z: 86, config: '[Xe] 4f14 5d10 6s2 6p6', core: '[Xe] 4f14 5d10', valence: '6s2 6p6', rcut: [2.3, 2.3], orbitals: ['6S', '6P'] },
    
    // Période 7 - Actinides
    'Fr': { Z: 87, config: '[Rn] 7s1', core: '[Rn]', valence: '7s1', rcut: [3.2], orbitals: ['7S'] },
    'Ra': { Z: 88, config: '[Rn] 7s2', core: '[Rn]', valence: '7s2', rcut: [3.0], orbitals: ['7S'] },
    'Ac': { Z: 89, config: '[Rn] 6d1 7s2', core: '[Rn]', valence: '6d1 7s2', rcut: [2.8, 2.8, 2.8], orbitals: ['6D', '7S', '7P'] },
    'Th': { Z: 90, config: '[Rn] 6d2 7s2', core: '[Rn]', valence: '6d2 7s2', rcut: [2.6, 2.6, 2.6], orbitals: ['6D', '7S', '7P'] },
    'Pa': { Z: 91, config: '[Rn] 5f2 6d1 7s2', core: '[Rn]', valence: '5f2 6d1 7s2', rcut: [2.6, 2.6, 2.6, 2.6], orbitals: ['5F', '6D', '7S', '7P'] },
    'U':  { Z: 92, config: '[Rn] 5f3 6d1 7s2', core: '[Rn]', valence: '5f3 6d1 7s2', rcut: [2.5, 2.5, 2.5, 2.5], orbitals: ['5F', '6D', '7S', '7P'] },
    'Np': { Z: 93, config: '[Rn] 5f4 6d1 7s2', core: '[Rn]', valence: '5f4 6d1 7s2', rcut: [2.5, 2.5, 2.5, 2.5], orbitals: ['5F', '6D', '7S', '7P'] },
    'Pu': { Z: 94, config: '[Rn] 5f6 7s2', core: '[Rn]', valence: '5f6 7s2', rcut: [2.5, 2.5, 2.5], orbitals: ['5F', '7S', '7P'] },
    'Am': { Z: 95, config: '[Rn] 5f7 7s2', core: '[Rn]', valence: '5f7 7s2', rcut: [2.5, 2.5, 2.5], orbitals: ['5F', '7S', '7P'] },
    'Cm': { Z: 96, config: '[Rn] 5f7 6d1 7s2', core: '[Rn]', valence: '5f7 6d1 7s2', rcut: [2.5, 2.5, 2.5, 2.5], orbitals: ['5F', '6D', '7S', '7P'] },
};

/**
 * Types de pseudopotentiels disponibles dans Quantum ESPRESSO
 * pseudotype dans ld1.x: 1=NC, 2=US, 3=PAW
 */
const PSEUDO_TYPES = {
    // Norm-Conserving
    'NC': { 
        name: 'Norm-Conserving (NC)', 
        code: 1,
        description: 'Standard, très précis, ecutwfc typique: 60-80 Ry',
        suffix: 'nc'
    },
    'NCPP': { 
        name: 'Norm-Conserving (NCPP)', 
        code: 1,
        description: 'Identique à NC, notation alternative',
        suffix: 'ncpp'
    },
    'TM': { 
        name: 'Troullier-Martins', 
        code: 1,
        description: 'NC avec schéma Troullier-Martins, très lisse',
        suffix: 'tm'
    },
    'RRKJ': { 
        name: 'RRKJ (Rappe-Rabe-Kaxiras-Joannopoulos)', 
        code: 1,
        description: 'NC optimisé pour la transférabilité',
        suffix: 'rrkj'
    },
    'MT': { 
        name: 'Martins-Troullier', 
        code: 1,
        description: 'Variante MT du NC',
        suffix: 'mt'
    },
    
    // Ultrasoft
    'US': { 
        name: 'Ultrasoft (US)', 
        code: 2,
        description: 'ecutwfc plus bas (25-40 Ry), bon pour métaux de transition',
        suffix: 'us'
    },
    'USPP': { 
        name: 'Ultrasoft (USPP)', 
        code: 2,
        description: 'Identique à US, notation Vanderbilt',
        suffix: 'uspp'
    },
    'RRKJUS': { 
        name: 'RRKJ Ultrasoft', 
        code: 2,
        description: 'Ultrasoft avec optimisation RRKJ',
        suffix: 'rrkjus'
    },
    
    // PAW
    'PAW': { 
        name: 'PAW (Projector Augmented Wave)', 
        code: 3,
        description: 'Très précis, reconstruit la fonction d\'onde all-electron',
        suffix: 'paw'
    },
    'KJPAW': { 
        name: 'Kresse-Joubert PAW', 
        code: 3,
        description: 'PAW avec formulation KJ',
        suffix: 'kjpaw'
    },
    
    // Coulomb
    'COULOMB': { 
        name: 'Coulomb (All-Electron)', 
        code: 0,
        description: 'Potentiel coulombien pur, pas de pseudo',
        suffix: 'ae'
    }
};

/**
 * Fonctionnelles d'échange-corrélation disponibles dans Quantum ESPRESSO
 * Référence: Modules/funct.f90 dans QE
 */
const FUNCTIONALS = {
    // LDA (Local Density Approximation)
    'LDA': { 
        name: 'LDA (Perdew-Zunger)', 
        dft: 'PZ',
        iexch: 1, icorr: 1, igcx: 0, igcc: 0,
        description: 'LDA standard Perdew-Zunger 1981'
    },
    'PZ': { 
        name: 'Perdew-Zunger', 
        dft: 'PZ',
        iexch: 1, icorr: 1, igcx: 0, igcc: 0,
        description: 'LDA Perdew-Zunger (identique à LDA)'
    },
    'VWN': { 
        name: 'Vosko-Wilk-Nusair', 
        dft: 'VWN',
        iexch: 1, icorr: 4, igcx: 0, igcc: 0,
        description: 'LDA VWN'
    },
    'PW': { 
        name: 'Perdew-Wang', 
        dft: 'PW',
        iexch: 1, icorr: 4, igcx: 0, igcc: 0,
        description: 'LDA Perdew-Wang 1992'
    },
    
    // GGA (Generalized Gradient Approximation)
    'PBE': { 
        name: 'PBE', 
        dft: 'PBE',
        iexch: 1, icorr: 4, igcx: 3, igcc: 4,
        description: 'GGA Perdew-Burke-Ernzerhof 1996 - Le plus utilisé'
    },
    'PBEsol': { 
        name: 'PBEsol', 
        dft: 'PBESOL',
        iexch: 1, icorr: 4, igcx: 10, igcc: 8,
        description: 'PBE révisé pour les solides - meilleurs paramètres de maille'
    },
    'revPBE': { 
        name: 'revPBE', 
        dft: 'REVPBE',
        iexch: 1, icorr: 4, igcx: 4, igcc: 4,
        description: 'PBE révisé Zhang-Yang'
    },
    'RPBE': { 
        name: 'RPBE', 
        dft: 'RPBE',
        iexch: 1, icorr: 4, igcx: 1, igcc: 4,
        description: 'PBE révisé Hammer-Hansen-Nørskov'
    },
    'PW91': { 
        name: 'PW91', 
        dft: 'PW91',
        iexch: 1, icorr: 4, igcx: 2, igcc: 2,
        description: 'GGA Perdew-Wang 1991'
    },
    'BLYP': { 
        name: 'BLYP', 
        dft: 'BLYP',
        iexch: 1, icorr: 3, igcx: 1, igcc: 3,
        description: 'Becke exchange + Lee-Yang-Parr correlation'
    },
    'BP': { 
        name: 'BP86', 
        dft: 'BP',
        iexch: 1, icorr: 4, igcx: 1, igcc: 1,
        description: 'Becke88 exchange + Perdew86 correlation'
    },
    'HCTH': { 
        name: 'HCTH', 
        dft: 'HCTH',
        iexch: 0, icorr: 0, igcx: 5, igcc: 5,
        description: 'Hamprecht-Cohen-Tozer-Handy'
    },
    'OLYP': { 
        name: 'OLYP', 
        dft: 'OLYP',
        iexch: 0, icorr: 3, igcx: 6, igcc: 3,
        description: 'OPTX exchange + LYP correlation'
    },
    'WC': { 
        name: 'Wu-Cohen', 
        dft: 'WC',
        iexch: 1, icorr: 4, igcx: 11, igcc: 4,
        description: 'GGA Wu-Cohen - bon pour ferroélectriques'
    },
    'SOGGA': { 
        name: 'SOGGA', 
        dft: 'SOGGA',
        iexch: 1, icorr: 4, igcx: 12, igcc: 4,
        description: 'Second-order GGA'
    },
    'Q2D': { 
        name: 'Q2D', 
        dft: 'Q2D',
        iexch: 1, icorr: 4, igcx: 19, igcc: 4,
        description: 'GGA pour systèmes quasi-2D'
    },
    
    // Meta-GGA
    'TPSS': { 
        name: 'TPSS', 
        dft: 'TPSS',
        iexch: 1, icorr: 4, igcx: 7, igcc: 6,
        description: 'Meta-GGA Tao-Perdew-Staroverov-Scuseria'
    },
    'M06L': { 
        name: 'M06-L', 
        dft: 'M06L',
        iexch: 0, icorr: 0, igcx: 0, igcc: 0,
        description: 'Meta-GGA Minnesota M06-L'
    },
    'TB09': { 
        name: 'TB09 (mBJ)', 
        dft: 'TB09',
        iexch: 0, icorr: 0, igcx: 0, igcc: 0,
        description: 'Tran-Blaha modified Becke-Johnson - bon pour band gaps'
    },
    'SCAN': { 
        name: 'SCAN', 
        dft: 'SCAN',
        iexch: 0, icorr: 0, igcx: 0, igcc: 0,
        description: 'Strongly Constrained and Appropriately Normed'
    },
    'R2SCAN': { 
        name: 'r2SCAN', 
        dft: 'R2SCAN',
        iexch: 0, icorr: 0, igcx: 0, igcc: 0,
        description: 'Regularized SCAN - plus stable'
    },
    
    // Hybrides (pour référence, pas pour ld1.x)
    'PBE0': { 
        name: 'PBE0', 
        dft: 'PBE0',
        iexch: 6, icorr: 4, igcx: 8, igcc: 4,
        description: 'Hybride PBE avec 25% HF exchange'
    },
    'B3LYP': { 
        name: 'B3LYP', 
        dft: 'B3LYP',
        iexch: 7, icorr: 0, igcx: 0, igcc: 0,
        description: 'Hybride Becke 3-parameter'
    },
    'HSE': { 
        name: 'HSE06', 
        dft: 'HSE',
        iexch: 0, icorr: 0, igcx: 0, igcc: 0,
        description: 'Hybride range-separated Heyd-Scuseria-Ernzerhof'
    },
    
    // Van der Waals (vdW-DF)
    'VDW-DF': { 
        name: 'vdW-DF', 
        dft: 'VDW-DF',
        iexch: 1, icorr: 4, igcx: 4, igcc: 0,
        description: 'Van der Waals density functional'
    },
    'VDW-DF2': { 
        name: 'vdW-DF2', 
        dft: 'VDW-DF2',
        iexch: 1, icorr: 4, igcx: 13, igcc: 0,
        description: 'vdW-DF version 2'
    },
    'RVDW-DF2': { 
        name: 'rev-vdW-DF2', 
        dft: 'RVVDW-DF2',
        iexch: 1, icorr: 4, igcx: 13, igcc: 0,
        description: 'vdW-DF2 révisé'
    },
    'VDW-DF-C09': { 
        name: 'vdW-DF-C09', 
        dft: 'VDW-DF-C09',
        iexch: 1, icorr: 4, igcx: 16, igcc: 0,
        description: 'vdW-DF avec exchange C09'
    },
    'VDW-DF-OB86': { 
        name: 'vdW-DF-optB86b', 
        dft: 'VDW-DF-OB86',
        iexch: 1, icorr: 4, igcx: 22, igcc: 0,
        description: 'vdW-DF avec optB86b exchange'
    },
    'VDW-DF-OBK8': { 
        name: 'vdW-DF-optB88', 
        dft: 'VDW-DF-OBK8',
        iexch: 1, icorr: 4, igcx: 23, igcc: 0,
        description: 'vdW-DF avec optB88 exchange'
    },
    'RVV10': { 
        name: 'rVV10', 
        dft: 'RVV10',
        iexch: 1, icorr: 4, igcx: 13, igcc: 0,
        description: 'Revised VV10 non-local correlation'
    }
};

/**
 * Générer le fichier ld1.in pour un élément
 */
function genererLD1Input(element, options = {}) {
    const elem = ELEMENTS_LD1[element];
    if (!elem) {
        console.error(`Élément ${element} non trouvé dans la base de données`);
        return null;
    }
    
    // Par défaut, éviter NC sur métaux de transition (souvent erreurs ld1.x: compute_phi/run_pseudo)
    // On garde le choix utilisateur s'il est fourni via options.pseudoType.
    const defaultPseudoType = (() => {
        if (options.pseudoType) return options.pseudoType;
        const val = (elem.valence || '').toLowerCase();
        // Présence d'électrons d dans la valence → préférer US (RRKJUS dans la pratique)
        if (/\dd/.test(val) || /d\d/.test(val)) return 'US';
        // Éléments lourds: US est souvent plus robuste en génération automatique
        if (elem.Z >= 37) return 'US';
        return 'NC';
    })();

    // Options par défaut
    const config = {
        pseudoType: defaultPseudoType,
        functional: options.functional || 'PBE',
        relativistic: options.relativistic || (elem.Z > 36 ? 'scalar' : 'no'),
        rcut: options.rcut || elem.rcut,
        ecutwfc: options.ecutwfc || 60,
        ecutrho: options.ecutrho || 600,
        ...options
    };
    
    const func = FUNCTIONALS[config.functional];
    const dftName = (func && func.dft) ? func.dft : config.functional;
    // Tag pour le nom de fichier (QE Library utilise pz pour LDA)
    const functionalTag = (() => {
        const d = String(dftName || config.functional || '').toLowerCase();
        if (d === 'pbesol') return 'pbesol';
        if (d === 'pz' || d === 'lda') return 'pz';
        if (d === 'pbe') return 'pbe';
        return String(config.functional || '').toLowerCase();
    })();
    
    // Construire le fichier ld1.in basé sur les exemples QE (pseudo_library)
    // pseudotype: 1=NC, 2=US (RRKJ), 3=PAW
    // lloc: canal local (généralement 2=d)
    const isPAW = config.pseudoType === 'PAW';
    const isUS = config.pseudoType === 'US' || config.pseudoType === 'RRKJ';
    const isNC = config.pseudoType === 'NC';
    
    // Déterminer le type numérique
    let pseudoTypeNum = 2;  // US par défaut
    if (isPAW) pseudoTypeNum = 3;
    else if (isNC) pseudoTypeNum = 1;
    else if (isUS) pseudoTypeNum = 2;
    
    // Déterminer le suffixe du nom de fichier selon le type
    let suffix = 'us';  // Par défaut
    if (pseudoTypeNum === 3) suffix = 'paw';
    else if (pseudoTypeNum === 1) suffix = 'nc';
    else if (pseudoTypeNum === 2) suffix = 'us';
    
    // lloc = 2 (d comme canal local) comme dans les exemples QE
    const lloc = 2;
    
    // Formater la config comme QE: "[Ne] 3s2.0 3p2.0 3d-2.0" avec décimaux
    const configFormatted = formatConfigQE(elem);
    
    // Relativistic: 0=non-rel, 1=scalar, 2=full
    const relNum = config.relativistic === 'full' ? 2 : (config.relativistic === 'scalar' || elem.Z > 36 ? 1 : 0);
    
    // Format exact comme les exemples QE
    let ld1Input = ` &input
    title='${element}',
    zed=${elem.Z}.0,
    rel=${relNum},
    config='${configFormatted}',
    iswitch=3,
    dft='${dftName}'
 /
 &inputp
   pseudotype=${pseudoTypeNum},
   file_pseudopw='${element}.${functionalTag}-${suffix}.UPF',
   author='QE Interface',
   lloc=-1,
   rcloc=${config.rcut ? config.rcut[0] || 2.0 : 2.0},
   new_core_ps=.true.${isUS ? ',\n   tm=.true.' : ''}${isNC ? ',\n   rho0=0.001' : ''}
 /
`;

    // Ajouter les orbitales (toujours nécessaires, même pour PAW)
    // NOTE: genererSectionOrbitales() ne termine pas par \n (pour éviter une ligne vide finale),
    // donc si on ajoute une section après, il faut insérer un saut de ligne.
    ld1Input += genererSectionOrbitales(elem, config);
    
    // Section &test: seulement pour US/PAW, pas pour NC
    // D'après FORMAT_LD1_CORRECT.md, avec iswitch=3, &test n'est pas nécessaire pour NC
    // et peut causer des erreurs "Errors in PS-KS equation"
    if (!isNC) {
        const testConfig = elem.valence || elem.config || 'default';
        ld1Input += `\n &test
   nconf=1
   file_pseudo='${element}.${functionalTag}-${suffix}.UPF'
   configts(1)='${testConfig}'
 /
`;
    }
    
    return ld1Input;
}

/**
 * Formater la configuration électronique au format QE
 * Exemple: "[Ar] 3d10.0 4s2.0 4p1.0 4d-2.0" (avec décimaux, format QE standard)
 */
function formatConfigQE(elem) {
    // ld1.x peut échouer si config contient un core du style "[Ar] 3d10 4s1".
    // On convertit donc les cores [He]/[Ne]/[Ar]/[Kr]/[Xe]/[Rn] en configuration explicite
    // et on évite d'ajouter des orbitales "unbound" (ex: 4d-2) dans config=.
    const fullConfig = (elem && elem.config) ? String(elem.config).trim() : '';

    const CORE_MAP = {
        'He': '1s2',
        'Ne': '1s2 2s2 2p6',
        'Ar': '1s2 2s2 2p6 3s2 3p6',
        'Kr': '1s2 2s2 2p6 3s2 3p6 3d10 4s2 4p6',
        'Xe': '1s2 2s2 2p6 3s2 3p6 3d10 4s2 4p6 4d10 5s2 5p6',
        'Rn': '1s2 2s2 2p6 3s2 3p6 3d10 4s2 4p6 4d10 4f14 5s2 5p6 5d10 6s2 6p6'
    };

    let expandedCore = '';
    let rest = fullConfig;
    const coreMatch = rest.match(/\[([A-Za-z]+)\]/);
    if (coreMatch) {
        const coreSym = coreMatch[1];
        expandedCore = CORE_MAP[coreSym] || '';
        rest = rest.replace(/\[.*?\]\s*/, '').trim();
    }

    const tokens = [];
    if (expandedCore) tokens.push(...expandedCore.split(/\s+/).filter(Boolean));

    // Orbitales restantes: tolère 3d10, 3d10.0, 4d-2
    const orbRegex = /(\d+)\s*([spdfSPDF])\s*([+-]?\d+(?:\.\d+)?)/g;
    let m;
    while ((m = orbRegex.exec(rest)) !== null) {
        const n = m[1];
        const l = m[2].toLowerCase();
        const occRaw = String(m[3]).replace(/\.0+$/, '');
        // Éviter les occupations négatives dans config= (les états unbound doivent être gérés dans la section orbitales)
        if (occRaw.startsWith('-')) continue;
        tokens.push(`${n}${l}${occRaw}`);
    }

    return tokens.join(' ').trim();
}

/**
 * Générer la section des orbitales pour ld1.in (format QE)
 * Format: nl  n  l  occ  E  rcut  rcutus
 */
function genererSectionOrbitales(elem, config) {
    // Analyser la configuration de valence
    const valenceOrbitals = parseValenceConfig(elem.valence);
    
    // IMPORTANT: Extraire aussi les orbitales non liées de la config formatée
    // (comme 4d-2 qui est ajouté par formatConfigQE mais pas dans elem.valence)
    const configFormatted = formatConfigQE(elem);
    const configOrbitals = parseValenceConfigWithUnbound(configFormatted);
    
    // Fusionner les orbitales de valence avec celles de la config formatée
    // (pour inclure les orbitales non liées comme 4d-2)
    const allOrbitals = [...valenceOrbitals];
    
    // Ajouter les orbitales non liées de la config formatée qui ne sont pas déjà présentes
    // IMPORTANT: ld1.x ne permet pas deux orbitales avec le même l (moment angulaire)
    // même si n (nombre quantique principal) est différent
    configOrbitals.forEach(orb => {
        if (orb.occ <= 0) {  // Orbitale non liée
            // Vérifier s'il existe déjà une orbitale avec le même l (moment angulaire)
            const existsSameL = allOrbitals.some(o => o.lNum === orb.lNum);
            if (!existsSameL) {
                allOrbitals.push(orb);
            }
        }
    });
    
    // Ajouter une orbitale d vide si pas de d (comme dans les exemples QE)
    const hasD = allOrbitals.some(o => o.lNum === 2);
    if (!hasD) {
        const nMax = Math.max(...allOrbitals.map(o => o.n), 2);
        allOrbitals.push({
            n: nMax,  // Même n que les autres orbitales de valence
            l: 'D',
            lNum: 2,
            occ: 0.0  // Orbitale non liée doit être vide (0.0) pour ld1.x
        });
    }

    // Pour les métaux de transition (canal d présent), ajouter un canal p vide si absent.
    // Cela améliore la robustesse de la génération (évite certains "Errors in PS-KS equation").
    const hasP = allOrbitals.some(o => o.lNum === 1);
    if (hasD && !hasP) {
        const nMax = Math.max(...allOrbitals.map(o => o.n), 2);
        allOrbitals.push({
            n: nMax,
            l: 'P',
            lNum: 1,
            occ: 0.0
        });
    }
    
    // Trier les orbitales par n (nombre quantique principal) puis par l (moment angulaire)
    // Ordre standard: s, p, d, f pour chaque n
    allOrbitals.sort((a, b) => {
        if (a.n !== b.n) return a.n - b.n;
        return a.lNum - b.lNum;
    });
    
    let section = `${allOrbitals.length}\n`;
    
    allOrbitals.forEach((orb, i) => {
        // Rayons de coupure appropriés selon l'orbitale
        // IMPORTANT: Augmenter significativement pour éviter l'erreur "phi has nodes before r_c"
        // Les orbitales peuvent avoir des nœuds, donc rcut doit être suffisamment grand
        let rcut;
        
        // Base selon le type d'orbitale (valeurs augmentées pour éviter les nœuds)
        if (orb.lNum === 0) {
            // Orbitales s: les plus susceptibles d'avoir des nœuds
            // IMPORTANT: Pour NC, rcut doit être très grand pour éviter "phi has nodes before r_c"
            // Augmenter significativement selon n pour garantir qu'on dépasse tous les nœuds
            if (orb.n >= 5) rcut = 4.00;      // n=5,6,7... (éléments lourds) - augmenté à 4.0
            else if (orb.n >= 4) rcut = 3.50; // n=4 - augmenté à 3.5
            else if (orb.n >= 3) rcut = 3.00; // n=3 - augmenté à 3.0
            else rcut = 2.50;                  // n=1,2
        } else if (orb.lNum === 1) {
            // Orbitales p
            if (orb.n >= 5) rcut = 3.20;
            else if (orb.n >= 4) rcut = 2.80;
            else if (orb.n >= 3) rcut = 2.60;
            else rcut = 2.30;
        } else if (orb.lNum === 2) {
            // Orbitales d
            if (orb.n >= 5) rcut = 3.00;
            else if (orb.n >= 4) rcut = 2.60;
            else if (orb.n >= 3) rcut = 2.50;
            else rcut = 2.40;
        } else {
            // Orbitales f
            if (orb.n >= 5) rcut = 3.50;
            else if (orb.n >= 4) rcut = 3.20;
            else rcut = 2.80;
        }
        
        // Pour les éléments très lourds (Z > 50), augmenter encore plus
        if (elem.Z > 50) {
            rcut += 0.3;
        }
        
        // Override avec config si fourni (mais utiliser au minimum les valeurs ci-dessus)
        if (config.rcut && config.rcut[i]) {
            rcut = Math.max(rcut, config.rcut[i]);
        }
        
        // IMPORTANT: Pour les orbitales non liées (occ <= 0), l'occupation doit être 0.00
        // ld1.x exige que les états "unbound" soient vides
        const occValue = orb.occ <= 0 ? 0.00 : orb.occ;
        const energy = orb.occ <= 0 ? -0.05 : 0.00;  // Energie pour orbitales non liées (-0.05)
        
        // Format QE complet: Label  n  l  occ  energy  rcut1  rcut2  rcutus
        // IMPORTANT: n est le nombre quantique principal (orb.n), pas un index !
        // Dernier champ est rcutus (0.00 pour non-ultrasoft, ou valeur si ultrasoft)
        const rcutus = 0.00;  // Rayon pour ultrasoft (0.00 par défaut)
        section += `${orb.n}${orb.l}  ${orb.n}  ${orb.lNum}  ${occValue.toFixed(2)}  ${energy.toFixed(2)}  ${rcut.toFixed(2)}  ${rcut.toFixed(2)}  ${rcutus.toFixed(2)}`;
        if (i < allOrbitals.length - 1) section += '\n';  // Pas de ligne vide à la fin
    });
    
    return section;
}

/**
 * Parser la configuration de valence
 */
function parseValenceConfig(valence) {
    const orbitals = [];
    const regex = /(\d)([spdf])(\d+)?/gi;
    let match;
    
    while ((match = regex.exec(valence)) !== null) {
        const n = parseInt(match[1]);
        const l = match[2].toLowerCase();
        const occ = match[3] ? parseInt(match[3]) : 1;
        
        const lMap = { 's': 0, 'p': 1, 'd': 2, 'f': 3 };
        const maxOcc = { 's': 2, 'p': 6, 'd': 10, 'f': 14 };
        
        orbitals.push({
            n: n,
            l: l.toUpperCase(),
            lNum: lMap[l],
            occ: Math.min(occ, maxOcc[l])
        });
    }
    
    return orbitals;
}

/**
 * Parser la configuration incluant les orbitales non liées (comme 4d-2)
 * Supporte les formats: "3d5", "4d-2", "4d-2.0"
 */
function parseValenceConfigWithUnbound(config) {
    const orbitals = [];
    // Regex pour capturer: nombre, lettre, nombre (positif ou négatif), optionnellement .nombre
    const regex = /(\d)([spdf])(-?\d+(?:\.\d+)?)/gi;
    let match;
    
    while ((match = regex.exec(config)) !== null) {
        const n = parseInt(match[1]);
        const l = match[2].toLowerCase();
        const occ = parseFloat(match[3]);  // Peut être négatif pour les orbitales non liées
        
        const lMap = { 's': 0, 'p': 1, 'd': 2, 'f': 3 };
        
        orbitals.push({
            n: n,
            l: l.toUpperCase(),
            lNum: lMap[l],
            occ: occ  // Conserver la valeur négative pour les orbitales non liées
        });
    }
    
    return orbitals;
}

/**
 * Afficher le générateur de pseudopotentiel dans une modale
 * @param {string} element - Symbole de l'élément (ex: 'Si', 'Fe')
 * @param {number} Z - Numéro atomique (optionnel, sera récupéré de la base)
 * @param {number} masse - Masse atomique (optionnel)
 * @param {number} valence - Nombre d'électrons de valence (optionnel)
 */
function afficherGenerateurPseudo(element, Z, masse, valence) {
    // Supprimer l'ancienne modale si elle existe
    const oldModal = document.getElementById('modal_generateur_pseudo');
    if (oldModal) oldModal.remove();

    // Mémoriser l'élément courant (utile pour des callbacks onchange)
    window.__ld1_current_element = element;
    
    let elem = ELEMENTS_LD1[element];
    
    // Si l'élément n'est pas dans la base, créer une entrée basique
    if (!elem) {
        if (Z) {
            elem = {
                Z: Z,
                config: `[...] valence: ${valence || '?'}`,
                valence: `${valence || 0} électrons`,
                rcut: [2.0],
                orbitals: ['S', 'P']
            };
        } else {
            alert(`❌ Élément ${element} non supporté pour la génération ld1.x`);
            return;
        }
    }
    
    // Créer la modale
    const modal = document.createElement('div');
    modal.id = 'modal_generateur_pseudo';
    modal.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.9); display: flex; align-items: center;
        justify-content: center; z-index: 10000; padding: 20px;
    `;

    // 📘 Bloc README affiché automatiquement à l'ouverture du générateur
    const val = (elem.valence || '').toLowerCase();
    const hasD = /\dd/.test(val) || /d\d/.test(val);
    const isHeavy = elem.Z > 36;
    const autoType = (hasD || isHeavy) ? 'US/USPP' : 'NC';
    const relReco = isHeavy ? 'rel=1 (scalaire)' : 'rel=0 (non-rel)';
    const rclocReco = (elem.rcut && elem.rcut[0]) ? elem.rcut[0] : 2.2;
    const readmeInlineHTML = `
        <div style="background:#11111b; padding: 16px; border-radius: 10px; margin: 15px 0; border: 1px solid #45475a;">
            <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap;">
                <div style="color:#b4befe; font-weight:bold;">📘 Guide (ld1.x) — affiché automatiquement</div>
                <button onclick="ouvrirGuidePseudosLD1('${element}')"
                        style="background:#45475a; color:#cdd6f4; border:none; padding:8px 12px; border-radius:8px; cursor:pointer;">
                    Ouvrir en grand
                </button>
            </div>
            <div style="color:#cdd6f4; line-height:1.7; margin-top:10px;">
                <div style="color:#a6e3a1; font-weight:bold; margin-bottom:6px;">Principe</div>
                - <strong>ld1.x</strong> génère un <code style="color:#f9e2af;">.UPF</code> depuis un <code style="color:#f9e2af;">ld1.in</code>, mais peut échouer selon l'élément (compute_phi / PS-KS / ld1_setup).<br>
                - En cas d’échec, l’interface utilise un <strong>fallback QE Library</strong> (PSlibrary/FHI) pour garantir un pseudo utilisable.<br>
                <div style="margin-top:10px; color:#a6e3a1; font-weight:bold;">Recommandations (rapides)</div>
                <ul style="margin: 6px 0 0 18px; padding: 0; line-height:1.7;">
                    <li><strong>US/USPP</strong> (pseudotype=2): le plus robuste pour métaux de transition (d) et éléments lourds.</li>
                    <li><strong>NC</strong> (pseudotype=1): précis mais souvent plus “dur” et peut échouer à la génération.</li>
                    <li><strong>PAW</strong> (pseudotype=3): excellente précision, souvent plus simple via QE Library.</li>
                </ul>
                <div style="margin-top:10px; color:#a6e3a1; font-weight:bold;">Pour ${element}</div>
                <div style="font-family: monospace; font-size: 13px; margin-top: 6px;">
                    auto recommandé: <strong>${autoType}</strong><br>
                    ${relReco}<br>
                    rcloc départ: ${rclocReco} a.u.
                </div>
            </div>
        </div>
    `;
    
    modal.innerHTML = `
        <div style="background: #1e1e2e; color: #cdd6f4; padding: 30px; border-radius: 15px; max-width: 900px; width: 95%; max-height: 90vh; overflow-y: auto; box-shadow: 0 0 40px rgba(137, 180, 250, 0.3);">
            <h2 style="margin-top: 0; color: #89b4fa; display: flex; align-items: center; gap: 15px;">
                <span style="font-size: 1.5em;">⚛️</span>
                Générateur de Pseudopotentiel - ${element}
            </h2>
            
            <!-- Informations sur l'élément -->
            <div style="background: #313244; padding: 20px; border-radius: 10px; margin: 20px 0;">
                <h3 style="color: #f9e2af; margin-top: 0;">📊 Informations de l'élément</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                    <div>
                        <strong style="color: #89b4fa;">Symbole:</strong> ${element}<br>
                        <strong style="color: #89b4fa;">Numéro atomique (Z):</strong> ${elem.Z}
                    </div>
                    <div>
                        <strong style="color: #89b4fa;">Configuration:</strong><br>
                        <code style="background: #45475a; padding: 5px 10px; border-radius: 5px;">${elem.config}</code>
                    </div>
                    <div>
                        <strong style="color: #89b4fa;">Valence:</strong><br>
                        <code style="background: #45475a; padding: 5px 10px; border-radius: 5px;">${elem.valence}</code>
                    </div>
                </div>
            </div>

            ${readmeInlineHTML}
            
            <!-- Paramètres de génération -->
            <div style="background: #313244; padding: 20px; border-radius: 10px; margin: 20px 0;">
                <h3 style="color: #a6e3a1; margin-top: 0;">⚙️ Paramètres de génération</h3>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                    <!-- Type de pseudo -->
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: #89b4fa;">Type de pseudopotentiel:</label>
                        <select id="pseudo_type" style="width: 100%; padding: 10px; border-radius: 5px; background: #45475a; color: #cdd6f4; border: 1px solid #585b70;" onchange="updatePseudoTypeInfo()">
                            <optgroup label="Norm-Conserving">
                                <option value="NC" selected>NC - Norm-Conserving (standard)</option>
                                <option value="TM">TM - Troullier-Martins</option>
                                <option value="RRKJ">RRKJ - Rappe-Rabe-Kaxiras-Joannopoulos</option>
                                <option value="MT">MT - Martins-Troullier</option>
                            </optgroup>
                            <optgroup label="Ultrasoft">
                                <option value="US">US - Ultrasoft (Vanderbilt)</option>
                                <option value="RRKJUS">RRKJUS - RRKJ Ultrasoft</option>
                            </optgroup>
                            <optgroup label="PAW">
                                <option value="PAW">PAW - Projector Augmented Wave</option>
                                <option value="KJPAW">KJPAW - Kresse-Joubert PAW</option>
                            </optgroup>
                        </select>
                        <small id="pseudo_type_desc" style="color: #6c7086;">Standard, très précis, ecutwfc typique: 60-80 Ry</small>
                    </div>
                    
                    <!-- Fonctionnelle -->
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: #89b4fa;">Fonctionnelle XC:</label>
                        <select id="pseudo_functional" style="width: 100%; padding: 10px; border-radius: 5px; background: #45475a; color: #cdd6f4; border: 1px solid #585b70;" onchange="updateFunctionalInfo()">
                            <optgroup label="LDA (Local Density)">
                                <option value="LDA">LDA - Perdew-Zunger</option>
                                <option value="PZ">PZ - Perdew-Zunger</option>
                                <option value="VWN">VWN - Vosko-Wilk-Nusair</option>
                                <option value="PW">PW - Perdew-Wang</option>
                            </optgroup>
                            <optgroup label="GGA (Gradient)">
                                <option value="PBE" selected>PBE - Le plus utilisé ⭐</option>
                                <option value="PBEsol">PBEsol - Meilleur pour solides</option>
                                <option value="revPBE">revPBE - Zhang-Yang</option>
                                <option value="RPBE">RPBE - Hammer-Hansen-Nørskov</option>
                                <option value="PW91">PW91 - Perdew-Wang 1991</option>
                                <option value="BLYP">BLYP - Becke-Lee-Yang-Parr</option>
                                <option value="BP">BP86 - Becke-Perdew</option>
                                <option value="WC">WC - Wu-Cohen (ferroélectriques)</option>
                                <option value="HCTH">HCTH</option>
                                <option value="OLYP">OLYP</option>
                            </optgroup>
                            <optgroup label="Meta-GGA">
                                <option value="TPSS">TPSS</option>
                                <option value="SCAN">SCAN</option>
                                <option value="R2SCAN">r2SCAN</option>
                            </optgroup>
                            <optgroup label="Van der Waals">
                                <option value="VDW-DF">vdW-DF</option>
                                <option value="VDW-DF2">vdW-DF2</option>
                                <option value="RVV10">rVV10</option>
                            </optgroup>
                        </select>
                        <small id="func_desc" style="color: #6c7086;">GGA Perdew-Burke-Ernzerhof 1996 - Le plus utilisé</small>
                    </div>
                    
                    <!-- Relativiste -->
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: #89b4fa;">Effets relativistes:</label>
                        <select id="pseudo_rel" style="width: 100%; padding: 10px; border-radius: 5px; background: #45475a; color: #cdd6f4; border: 1px solid #585b70;">
                            <option value="no" ${elem.Z <= 36 ? 'selected' : ''}>Non (Z ≤ 36)</option>
                            <option value="scalar" ${elem.Z > 36 ? 'selected' : ''}>Scalaire (recommandé Z > 36)</option>
                            <option value="full">Complet (spin-orbite)</option>
                        </select>
                    </div>
                    
                    <!-- Rayon de coupure -->
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: #89b4fa;">Rayon de coupure (a.u.):</label>
                        <input type="number" id="pseudo_rcut" value="${elem.rcut[0]}" step="0.1" min="0.5" max="4.0"
                               style="width: 100%; padding: 10px; border-radius: 5px; background: #45475a; color: #cdd6f4; border: 1px solid #585b70;">
                        <small style="color: #6c7086;">Plus petit = plus précis mais ecutwfc plus élevé</small>
                    </div>
                </div>

                <!-- Disponibilité QE Library (PSlibrary) -->
                <div id="qe_library_availability"
                     style="margin-top: 16px; background: #11111b; border: 1px solid #45475a; padding: 12px 14px; border-radius: 10px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap;">
                        <div style="font-weight: bold; color: #b4befe;">📦 QE Library (PSlibrary)</div>
                        <button onclick="actualiserDisponibiliteQELibrary(true)"
                                style="background:#45475a; color:#cdd6f4; border:none; padding:6px 10px; border-radius:8px; cursor:pointer;">
                            🔎 Vérifier
                        </button>
                    </div>
                    <div id="qe_library_availability_text" style="margin-top: 8px; color:#cdd6f4;">
                        ⏳ Vérification…
                    </div>
                    <div style="margin-top: 6px; color:#6c7086; font-size: 12px;">
                        Note: la bibliothèque contient surtout des variantes <strong>PBE</strong>. Si la combinaison n’existe pas, un pseudo “proche” peut être utilisé en fallback.
                    </div>
                </div>
            </div>
            
            <!-- Prévisualisation du fichier ld1.in -->
            <div style="background: #313244; padding: 20px; border-radius: 10px; margin: 20px 0;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h3 style="color: #fab387; margin: 0;">📄 Fichier ld1.in généré</h3>
                    <button onclick="actualiserPreviewLD1('${element}')" style="background: #89b4fa; color: #1e1e2e; border: none; padding: 8px 15px; border-radius: 5px; cursor: pointer;">
                        🔄 Actualiser
                    </button>
                </div>
                <pre id="preview_ld1" style="background: #11111b; color: #a6e3a1; padding: 15px; border-radius: 8px; font-family: 'JetBrains Mono', monospace; font-size: 13px; overflow-x: auto; max-height: 300px; margin: 0;">${genererLD1Input(element)}</pre>
            </div>
            
            <!-- Actions - 2 boutons principaux -->
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-top: 20px;">
                <button onclick="sauvegarderInputEtScript('${element}')" style="background: linear-gradient(135deg, #89b4fa, #74c7ec); color: #1e1e2e; border: none; padding: 20px 15px; border-radius: 12px; cursor: pointer; font-weight: bold; font-size: 1em; box-shadow: 0 4px 15px rgba(137,180,250,0.4);">
                    <span style="display: block; font-size: 1.8em; margin-bottom: 8px;">💾</span>
                    Sauvegarder ld1.in<br><small style="font-weight: normal; opacity: 0.8;">dans /ld1_inputs/</small>
                </button>
                <button onclick="genererEtVisualiser('${element}')" style="background: linear-gradient(135deg, #a6e3a1, #94e2d5); color: #1e1e2e; border: none; padding: 20px 15px; border-radius: 12px; cursor: pointer; font-weight: bold; font-size: 1em; box-shadow: 0 4px 15px rgba(166,227,161,0.4);">
                    <span style="display: block; font-size: 1.8em; margin-bottom: 8px;">🚀</span>
                    Générer le Pseudo<br><small style="font-weight: normal; opacity: 0.8;">exécution automatique de ld1.x</small>
                </button>
            </div>
            
            <!-- Structure des dossiers -->
            <div style="background: #313244; padding: 15px; border-radius: 8px; margin-top: 15px;">
                <strong style="color: #f9e2af;">📁 Structure des dossiers:</strong>
                <div style="margin-top: 10px; font-family: monospace; font-size: 0.9em;">
                    <div style="color: #89b4fa; padding: 5px 0;">
                        📂 ${LD1_CONFIG.PSEUDO_GENERES_DIR}/
                    </div>
                    <div style="color: #a6e3a1; padding: 5px 0 5px 20px;">
                        📁 ld1_inputs/ <span style="color: #6c7086;">← fichiers .ld1.in et .sh</span>
                    </div>
                    <div style="color: #f9e2af; padding: 5px 0 5px 20px;">
                        📄 *.UPF <span style="color: #6c7086;">← pseudopotentiels générés</span>
                    </div>
                </div>
            </div>
            
            <!-- Commande terminal -->
            <div style="background: #11111b; padding: 15px; border-radius: 8px; margin-top: 20px;">
                <strong style="color: #f9e2af;">💻 Commande terminal:</strong>
                <code id="cmd_ld1" style="display: block; margin-top: 10px; color: #a6e3a1; font-family: monospace;">
cd ${LD1_CONFIG.PSEUDO_DIR} && ${LD1_CONFIG.QE_BIN}/ld1.x < ${element}.ld1.in > ${element}.ld1.out
                </code>
            </div>
            
            <div style="text-align: right; margin-top: 20px;">
                <button onclick="document.getElementById('modal_generateur_pseudo').remove()" 
                        style="background: #45475a; color: #cdd6f4; border: none; padding: 12px 30px; border-radius: 5px; cursor: pointer;">
                    ✖ Fermer
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);

    // Vérifier la dispo QE Library dès l'ouverture
    actualiserDisponibiliteQELibrary(true);
}

/**
 * Actualiser la prévisualisation du fichier ld1.in
 */
function actualiserPreviewLD1(element) {
    const pseudoType = document.getElementById('pseudo_type')?.value || 'NC';
    const functional = document.getElementById('pseudo_functional')?.value || 'PBE';
    const relativistic = document.getElementById('pseudo_rel')?.value || 'no';
    const rcut = parseFloat(document.getElementById('pseudo_rcut')?.value) || 2.0;
    
    const ld1Content = genererLD1Input(element, {
        pseudoType,
        functional,
        relativistic,
        rcut: [rcut]
    });
    
    document.getElementById('preview_ld1').textContent = ld1Content;

    // Mettre à jour l'indicateur QE Library quand les paramètres changent
    actualiserDisponibiliteQELibrary(false);
    
    // Mettre à jour la commande
    const cmd = `cd ${LD1_CONFIG.PSEUDO_DIR} && ${LD1_CONFIG.QE_BIN}/ld1.x < ${element}.ld1.in > ${element}.ld1.out`;
    document.getElementById('cmd_ld1').textContent = cmd;
}

/**
 * Copier le fichier ld1.in dans le presse-papier
 */
function copierLD1(element) {
    const content = document.getElementById('preview_ld1').textContent;
    navigator.clipboard.writeText(content).then(() => {
        alert('✅ Fichier ld1.in copié dans le presse-papier!');
    }).catch(err => {
        console.error('Erreur copie:', err);
        // Fallback
        const textarea = document.createElement('textarea');
        textarea.value = content;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        alert('✅ Copié!');
    });
}

/**
 * Télécharger le fichier ld1.in
 */
function telechargerLD1(element) {
    const content = document.getElementById('preview_ld1').textContent;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${element}.ld1.in`;
    a.click();
    URL.revokeObjectURL(url);
}

/**
 * Lancer la génération du pseudopotentiel via l'API ou afficher la commande
 */
async function lancerGenerationPseudo(element) {
    const content = document.getElementById('preview_ld1').textContent;
    const functional = document.getElementById('pseudo_functional')?.value || 'PBE';
    const pseudoType = document.getElementById('pseudo_type')?.value || 'NC';
    
    // Essayer via l'API
    try {
        // 1. Sauvegarder le fichier ld1.in
        const saveResponse = await fetch('http://localhost:5007/api/sauvegarder_input', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                filename: `${element}.ld1.in`,
                content: content
            })
        });
        
        if (!saveResponse.ok) throw new Error('Sauvegarde échouée');
        
        alert(`✅ Fichier ${element}.ld1.in sauvegardé!\n\n` +
              `Pour générer le pseudo, exécutez dans un terminal:\n\n` +
              `cd ${LD1_CONFIG.PSEUDO_DIR}\n` +
              `${LD1_CONFIG.QE_BIN}/ld1.x < ${LD1_CONFIG.INPUTS_DIR}/${element}.ld1.in > ${element}.ld1.out\n\n` +
              `Le fichier ${element}.${functional}-${pseudoType.toLowerCase()}.UPF sera créé.`);
        
    } catch (error) {
        // Fallback: afficher les instructions
        const instructions = `
═══════════════════════════════════════════════════════════════════
  GÉNÉRATION DU PSEUDOPOTENTIEL - ${element}
═══════════════════════════════════════════════════════════════════

1. Sauvegardez le fichier ld1.in ci-dessus

2. Dans un terminal, exécutez:

   cd ${LD1_CONFIG.PSEUDO_DIR}
   ${LD1_CONFIG.QE_BIN}/ld1.x < ${element}.ld1.in > ${element}.ld1.out

3. Le fichier UPF sera généré: ${element}.${functional}-${pseudoType.toLowerCase()}.UPF

═══════════════════════════════════════════════════════════════════
        `;
        
        alert(instructions);
    }
}

/**
 * Mettre à jour la description du type de pseudo
 */
function updatePseudoTypeInfo() {
    const select = document.getElementById('pseudo_type');
    const desc = document.getElementById('pseudo_type_desc');
    if (select && desc && PSEUDO_TYPES[select.value]) {
        desc.textContent = PSEUDO_TYPES[select.value].description;
    }
    actualiserDisponibiliteQELibrary(false);
}

/**
 * Mettre à jour la description de la fonctionnelle
 */
function updateFunctionalInfo() {
    const select = document.getElementById('pseudo_functional');
    const desc = document.getElementById('func_desc');
    if (select && desc && FUNCTIONALS[select.value]) {
        desc.textContent = FUNCTIONALS[select.value].description;
    }
    actualiserDisponibiliteQELibrary(false);
}

// --- QE Library availability indicator (local + remote) ---
let __qeLibAvailabilityTimer = null;

function _qeLibBuildCandidateFilenames(element, functionalLower, pseudoType) {
    const func = (functionalLower || 'pbe').toLowerCase();
    const pt = (pseudoType || 'NC').toUpperCase();

    const isNC = ['NC', 'TM', 'RRKJ', 'MT'].includes(pt);
    const isUS = ['US', 'RRKJUS'].includes(pt);
    const isPAW = ['PAW', 'KJPAW'].includes(pt);

    const names = [];

    // PAW (KJPAW)
    if (isPAW) {
        names.push(`${element}.${func}-n-kjpaw_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-n-kjpaw_psl.0.3.1.UPF`);
        names.push(`${element}.${func}-spdn-kjpaw_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-spdn-kjpaw_psl.0.3.1.UPF`);
    }

    // USPP (RRKJUS)
    if (isUS || isPAW) {
        names.push(`${element}.${func}-spn-rrkjus_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-n-rrkjus_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-dn-rrkjus_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-spdfn-rrkjus_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-spn-rrkjus_psl.0.3.1.UPF`);
        names.push(`${element}.${func}-n-rrkjus_psl.0.3.1.UPF`);
        names.push(`${element}.${func}-dn-rrkjus_psl.0.3.1.UPF`);
    }

    // NC (RRKJ) — quand dispo
    if (isNC) {
        names.push(`${element}.${func}-n-rrkj_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-spn-rrkj_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-dn-rrkj_psl.1.0.0.UPF`);
        names.push(`${element}.${func}-n-rrkj_psl.0.3.1.UPF`);
        names.push(`${element}.${func}-spn-rrkj_psl.0.3.1.UPF`);
        names.push(`${element}.${func}-dn-rrkj_psl.0.3.1.UPF`);
    }

    // FHI (souvent NC)
    names.push(`${element}.${func}-mt_fhi.UPF`);

    // De-dup
    return Array.from(new Set(names));
}

async function _qeLibCheckLocal(filename) {
    try {
        const resp = await fetch(`http://localhost:5007/api/pseudos/verifier/${encodeURIComponent(filename)}`);
        const json = await resp.json();
        return !!json.exists;
    } catch (e) {
        return false;
    }
}

async function _qeLibCheckRemote(filename) {
    try {
        const resp = await fetch(`http://localhost:5007/api/pseudos/verifier_qelibrary/${encodeURIComponent(filename)}`);
        const json = await resp.json();
        return !!json.exists;
    } catch (e) {
        return false;
    }
}

function actualiserDisponibiliteQELibrary(force = false) {
    const box = document.getElementById('qe_library_availability');
    const text = document.getElementById('qe_library_availability_text');
    if (!box || !text) return;

    // Debounce (éviter de spammer pendant que l'utilisateur change des paramètres)
    if (__qeLibAvailabilityTimer) clearTimeout(__qeLibAvailabilityTimer);
    __qeLibAvailabilityTimer = setTimeout(async () => {
        try {
            const element = window.__ld1_current_element;
            const functional = document.getElementById('pseudo_functional')?.value || 'PBE';
            const pseudoType = document.getElementById('pseudo_type')?.value || 'NC';

            if (!element) {
                text.innerHTML = `⚠️ Élément non défini.`;
                return;
            }

            text.innerHTML = `⏳ Vérification pour <strong>${element}</strong> / <strong>${pseudoType}</strong> / <strong>${functional}</strong>…`;

            const candidates = _qeLibBuildCandidateFilenames(element, functional.toLowerCase(), pseudoType).slice(0, 14);

            // 1) local d'abord
            for (const name of candidates) {
                // Si pas force, on limite un peu le coût: on teste 6 noms en local max
                if (!force && candidates.indexOf(name) >= 6) break;
                const okLocal = await _qeLibCheckLocal(name);
                if (okLocal) {
                    text.innerHTML = `✅ Déjà présent localement: <code style="color:#f9e2af;">${name}</code>`;
                    return;
                }
            }

            // 2) remote ensuite
            for (const name of candidates) {
                const okRemote = await _qeLibCheckRemote(name);
                if (okRemote) {
                    text.innerHTML = `✅ Disponible dans QE Library: <code style="color:#f9e2af;">${name}</code>`;
                    return;
                }
            }

            text.innerHTML = `❌ Aucune variante trouvée dans QE Library pour cette combinaison. <span style="color:#6c7086;">(Souvent, <strong>PBE</strong> est le mieux fourni.)</span>`;
        } catch (e) {
            text.innerHTML = `⚠️ Vérification impossible (réseau/API).`;
        }
    }, force ? 50 : 350);
}

/**
 * Vérifier si l'élément est difficile à générer (lanthanides, actinides)
 */
function estElementDifficile(element) {
    const elem = ELEMENTS_LD1[element];
    if (!elem) return false;
    const Z = elem.Z;
    // Lanthanides: 57-71, Actinides: 89-103
    return (Z >= 57 && Z <= 71) || (Z >= 89 && Z <= 103);
}

/**
 * Télécharger un pseudo depuis la bibliothèque QE pour les éléments difficiles
 */
async function telechargerPseudoQELibrary(element) {
    const functional = document.getElementById('pseudo_functional')?.value || 'PBE';
    const pseudoType = document.getElementById('pseudo_type')?.value || 'NC';
    
    // URLs possibles pour les pseudos PSL
    const urls = [
        `https://pseudopotentials.quantum-espresso.org/upf_files/${element}.pbe-spdn-kjpaw_psl.1.0.0.UPF`,
        `https://pseudopotentials.quantum-espresso.org/upf_files/${element}.pbe-spdfn-rrkjus_psl.1.0.0.UPF`,
        `https://pseudopotentials.quantum-espresso.org/upf_files/${element}.pbe-spdn-rrkjus_psl.1.0.0.UPF`,
        `https://pseudopotentials.quantum-espresso.org/upf_files/${element}.pbe-n-kjpaw_psl.1.0.0.UPF`
    ];
    
    try {
        const response = await fetch('http://localhost:5007/api/pseudos/telecharger', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                element: element,
                functional: functional.toLowerCase(),
                type: pseudoType.toLowerCase(),
                destination: LD1_CONFIG.PSEUDO_GENERES_DIR
            })
        });
        
        const result = await response.json();
        if (result.success) {
            return { success: true, filename: result.filename, path: result.path };
        }
    } catch (error) {
        console.error('Erreur téléchargement:', error);
    }
    
    return { success: false };
}

/**
 * BOUTON 1: Sauvegarder input ld1.in ET le script shell
 * Sauvegarde dans /Pseudo_generes/ld1_inputs/
 */
async function sauvegarderInputEtScript(element) {
    // Vérifier si c'est un élément difficile
    if (estElementDifficile(element)) {
        const confirm = window.confirm(
            `⚠️ ${element} est un lanthanide/actinide.\n\n` +
            `La génération avec ld1.x est très difficile pour ces éléments ` +
            `(orbitales f très localisées).\n\n` +
            `Voulez-vous télécharger le pseudo depuis la bibliothèque QE à la place?\n\n` +
            `[OK] = Télécharger depuis QE\n` +
            `[Annuler] = Générer quand même (risque d'échec)`
        );
        
        if (confirm) {
            const result = await telechargerPseudoQELibrary(element);
            if (result.success) {
                alert(`✅ Pseudo téléchargé!\n\n📦 ${result.path || result.filename}`);
                return;
            } else {
                alert(`⚠️ Téléchargement échoué.\n\nLe fichier ld1.in sera créé, mais la génération risque d'échouer.`);
            }
        }
    }
    
    // Actualiser la preview d'abord
    actualiserPreviewLD1(element);
    
    const content = document.getElementById('preview_ld1').textContent;
    const functional = document.getElementById('pseudo_functional')?.value || 'PBE';
    const pseudoType = document.getElementById('pseudo_type')?.value || 'NC';
    
    const baseFilename = `${element}.${functional.toLowerCase()}-${pseudoType.toLowerCase()}`;
    const ld1Filename = `${baseFilename}.ld1.in`;
    const shFilename = `${baseFilename}.ld1.sh`;
    
    // Créer le script shell - génère DANS Pseudo_generes directement
    const scriptContent = `#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
# Script de génération de pseudopotentiel pour ${element}
# Type: ${pseudoType} | Fonctionnelle: ${functional}
# Généré le: ${new Date().toLocaleString('fr-FR')}
# ═══════════════════════════════════════════════════════════════════════════════

# Configuration
QE_BIN="${LD1_CONFIG.QE_BIN}"
LD1_DIR="${LD1_CONFIG.LD1_INPUTS_DIR}"
PSEUDO_DIR="${LD1_CONFIG.PSEUDO_GENERES_DIR}"
INPUT_FILE="${ld1Filename}"

# Vérifier que ld1.x existe
if [ ! -f "$QE_BIN/ld1.x" ]; then
    echo "❌ Erreur: ld1.x non trouvé dans $QE_BIN"
    exit 1
fi

# Vérifier que le fichier input existe
if [ ! -f "$LD1_DIR/$INPUT_FILE" ]; then
    echo "❌ Erreur: Fichier input non trouvé: $LD1_DIR/$INPUT_FILE"
    exit 1
fi

echo "═══════════════════════════════════════════════════════════════════"
echo "  🔬 Génération du pseudopotentiel ${element}"
echo "═══════════════════════════════════════════════════════════════════"
echo ""
echo "📄 Input: $LD1_DIR/$INPUT_FILE"
echo "📁 Output: $PSEUDO_DIR/"
echo ""

# Aller dans le dossier de sortie (Pseudo_generes) pour que le UPF y soit créé
cd "$PSEUDO_DIR"

# Lancer ld1.x avec le chemin complet vers l'input
echo "🚀 Lancement de ld1.x..."
$QE_BIN/ld1.x < "$LD1_DIR/$INPUT_FILE" > "$LD1_DIR/${element}.ld1.out" 2>&1
EXIT_CODE=$?

# Déplacer les fichiers temporaires vers ld1_inputs
mv ld1.test ld1.wfc ld1ps.wfc vx.pot "$LD1_DIR/" 2>/dev/null

# Vérifier le résultat
if [ \$EXIT_CODE -eq 0 ]; then
    echo ""
    echo "✅ Génération terminée avec succès!"
    echo ""
    
    # Lister les fichiers UPF générés
    UPF_FILES=\$(ls *.UPF 2>/dev/null | grep -i "${element}")
    if [ -n "\$UPF_FILES" ]; then
        echo "📦 Pseudopotentiel(s) généré(s):"
        for f in \$UPF_FILES; do
            SIZE=\$(ls -lh "\$f" | awk '{print \$5}')
            echo "   ✓ $PSEUDO_DIR/\$f (\$SIZE)"
        done
    else
        # Chercher tous les UPF créés récemment
        NEW_UPF=\$(find . -name "*.UPF" -mmin -1 2>/dev/null | head -1)
        if [ -n "\$NEW_UPF" ]; then
            echo "📦 Pseudopotentiel généré: \$NEW_UPF"
        else
            echo "⚠️ Aucun fichier .UPF trouvé"
            echo "   Vérifiez le log: $LD1_DIR/${element}.ld1.out"
        fi
    fi
else
    echo ""
    echo "❌ Erreur lors de la génération (code: \$EXIT_CODE)"
    echo ""
    echo "📋 Dernières lignes du log:"
    tail -25 "$LD1_DIR/${element}.ld1.out" 2>/dev/null
fi

echo ""
echo "═══════════════════════════════════════════════════════════════════"
`;

    try {
        // Sauvegarder le fichier ld1.in
        const response1 = await fetch('http://localhost:5007/api/sauvegarder_input', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                filename: ld1Filename,
                content: content,
                directory: LD1_CONFIG.LD1_INPUTS_DIR
            })
        });
        
        // Sauvegarder le script shell
        const response2 = await fetch('http://localhost:5007/api/sauvegarder_input', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                filename: shFilename,
                content: scriptContent,
                directory: LD1_CONFIG.LD1_INPUTS_DIR
            })
        });
        
        const result1 = await response1.json();
        const result2 = await response2.json();
        
        if (result1.success && result2.success) {
            alert(`✅ Fichiers sauvegardés!\n\n` +
                  `📁 ${LD1_CONFIG.LD1_INPUTS_DIR}/\n` +
                  `   📄 ${ld1Filename}\n` +
                  `   📜 ${shFilename}\n\n` +
                  `Pour générer le pseudo:\n` +
                  `chmod +x ${LD1_CONFIG.LD1_INPUTS_DIR}/${shFilename}\n` +
                  `${LD1_CONFIG.LD1_INPUTS_DIR}/${shFilename}`);
        } else {
            throw new Error('Erreur sauvegarde');
        }
    } catch (error) {
        console.error('Erreur:', error);
        // Fallback: télécharger les deux fichiers
        telechargerLD1(element);
        
        // Télécharger aussi le script
        const blob = new Blob([scriptContent], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = shFilename;
        a.click();
        URL.revokeObjectURL(url);
        
        alert('📥 Fichiers téléchargés (API non disponible)');
    }
}

/**
 * BOUTON 2: Générer et Visualiser
 * Lance ld1.x et affiche le résultat
 */
async function genererEtVisualiser(element) {
    const functional = document.getElementById('pseudo_functional')?.value || 'PBE';
    const pseudoType = document.getElementById('pseudo_type')?.value || 'NC';
    const baseFilename = `${element}.${functional.toLowerCase()}-${pseudoType.toLowerCase()}`;
    
    // Vérifier si c'est un élément difficile (lanthanide/actinide)
    if (estElementDifficile(element)) {
        const confirmer = window.confirm(
            `⚠️ ${element} est un lanthanide/actinide.\n\n` +
            `La génération avec ld1.x est difficile pour ces éléments.\n\n` +
            `Voulez-vous télécharger depuis la bibliothèque QE à la place?`
        );
        
        if (confirmer) {
            await telechargerPseudoQELibrary(element);
            return;
        }
    }
    
    // Actualiser la preview
    actualiserPreviewLD1(element);
    const ld1Content = document.getElementById('preview_ld1').textContent;
    
    // Créer une modale avec état de génération
    const modal = document.createElement('div');
    modal.id = 'modal_generation';
    modal.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.95); display: flex; align-items: center;
        justify-content: center; z-index: 10001; padding: 20px;
    `;
    
    modal.innerHTML = `
        <div style="background: #1e1e2e; padding: 30px; border-radius: 15px; max-width: 800px; width: 95%; max-height: 90vh; overflow-y: auto;">
            <h3 style="color: #a6e3a1; margin-top: 0;">🚀 Génération automatique - ${element}</h3>
            
            <div id="generation_status" style="background: #313244; padding: 20px; border-radius: 10px; margin: 20px 0;">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <div class="spinner" style="width: 30px; height: 30px; border: 3px solid #45475a; border-top-color: #89b4fa; border-radius: 50%; animation: spin 1s linear infinite;"></div>
                    <div>
                        <div style="color: #f9e2af; font-weight: bold;">⏳ Génération en cours...</div>
                        <div style="color: #6c7086; font-size: 0.9em; margin-top: 5px;">Exécution de ld1.x (peut prendre 30-60 secondes)</div>
                    </div>
                </div>
            </div>
            
            <div id="generation_result" style="display: none;"></div>
            
            <div style="text-align: right; margin-top: 20px;">
                <button id="btn_fermer_gen" onclick="document.getElementById('modal_generation').remove()" 
                        style="background: #45475a; color: #cdd6f4; border: none; padding: 12px 30px; border-radius: 5px; cursor: pointer;" disabled>
                    ⏳ Génération en cours...
                </button>
            </div>
        </div>
        <style>
            @keyframes spin { to { transform: rotate(360deg); } }
        </style>
    `;
    
    document.body.appendChild(modal);
    
    // Lancer la génération automatique via l'API
    try {
        const response = await fetch('http://localhost:5007/api/pseudos/generer_ld1', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                element: element,
                ld1_content: ld1Content,
                filename: `${baseFilename}.ld1.in`
            })
        });
        
        const result = await response.json();
        
        const statusDiv = document.getElementById('generation_status');
        const resultDiv = document.getElementById('generation_result');
        const btnFermer = document.getElementById('btn_fermer_gen');
        
        if (result.success) {
            const source = (result.source || '').toString();
            const isDownload = source.toLowerCase().includes('qe library');
            
            // Infos demandées via ld1.in (pour expliquer les mismatches)
            const requestedUpf = (ld1Content.match(/file_pseudopw\s*=\s*['"]([^'"]+)['"]/i) || [])[1] || '';
            const requestedDft = (ld1Content.match(/dft\s*=\s*['"]([^'"]+)['"]/i) || [])[1] || '';
            const requestedPseudotype = (ld1Content.match(/pseudotype\s*=\s*(\d+)/i) || [])[1] || '';
            
            statusDiv.innerHTML = `
                <div style="display: flex; align-items: center; gap: 15px;">
                    <div style="font-size: 2em;">✅</div>
                    <div>
                        <div style="color: #a6e3a1; font-weight: bold;">
                            ${isDownload ? 'Pseudopotentiel téléchargé depuis QE Library (fallback)' : 'Pseudopotentiel généré avec succès!'}
                        </div>
                        ${source ? `<div style="color: #6c7086; font-size: 0.9em; margin-top: 6px;">Source: ${source}</div>` : ''}
                    </div>
                </div>
            `;
            
            // Détecter le TYPE demandé et obtenu pour un warning plus explicite
            const pseudotypeMap = {'1': 'NC', '2': 'US', '3': 'PAW'};
            const requestedTypeName = pseudotypeMap[requestedPseudotype] || '?';
            
            // Détecter le type obtenu depuis le nom du fichier
            const obtainedFile = result.upf_file || (result.upf_path ? result.upf_path.split('/').pop() : '');
            let obtainedTypeName = '?';
            if (/kjpaw/i.test(obtainedFile)) obtainedTypeName = 'PAW';
            else if (/rrkjus/i.test(obtainedFile)) obtainedTypeName = 'US';
            else if (/rrkj/i.test(obtainedFile) && !/rrkjus/i.test(obtainedFile)) obtainedTypeName = 'NC';
            else if (/mt_fhi/i.test(obtainedFile)) obtainedTypeName = 'NC';
            else if (/_nc[._]/i.test(obtainedFile)) obtainedTypeName = 'NC';
            else if (/_us[._]/i.test(obtainedFile)) obtainedTypeName = 'US';
            else if (/_paw[._]/i.test(obtainedFile)) obtainedTypeName = 'PAW';
            
            // Détecter la fonctionnelle obtenue
            let obtainedFunc = '?';
            if (/\.pbesol[-_]/i.test(obtainedFile)) obtainedFunc = 'PBEsol';
            else if (/\.pbe[-_]/i.test(obtainedFile)) obtainedFunc = 'PBE';
            else if (/\.pz[-_]/i.test(obtainedFile)) obtainedFunc = 'LDA/PZ';
            else if (/\.lda[-_]/i.test(obtainedFile)) obtainedFunc = 'LDA';
            
            const mismatch = isDownload && requestedUpf && result.upf_path && !result.upf_path.endsWith('/' + requestedUpf);
            const typeMismatch = requestedTypeName !== '?' && obtainedTypeName !== '?' && requestedTypeName !== obtainedTypeName;
            const funcMismatch = requestedDft && obtainedFunc !== '?' && requestedDft.toUpperCase() !== obtainedFunc.toUpperCase() 
                                 && !(requestedDft.toUpperCase() === 'PZ' && obtainedFunc === 'LDA/PZ');
            
            const mismatchDetails = mismatch
                ? `<div style="margin-top: 12px; padding: 12px; border-radius: 8px; background: #3a2a1a; border: 1px solid #f9e2af;">
                        <div style="color: #f9e2af; font-weight: bold; margin-bottom: 6px;">⚠️ Attention: le fichier obtenu ne correspond pas exactement à la demande</div>
                        <div style="color: #cdd6f4; font-family: monospace; font-size: 12px; line-height: 1.8;">
                            <strong>Demandé:</strong> ${requestedUpf || '(inconnu)'}<br>
                            &nbsp;&nbsp;→ Type: <span style="color:${typeMismatch ? '#f38ba8' : '#a6e3a1'}; font-weight:bold;">${requestedTypeName}</span> (pseudotype=${requestedPseudotype || '?'})<br>
                            &nbsp;&nbsp;→ Fonctionnelle: <span style="color:${funcMismatch ? '#f38ba8' : '#a6e3a1'}; font-weight:bold;">${requestedDft || '?'}</span><br><br>
                            <strong>Obtenu:</strong> ${obtainedFile || '(inconnu)'}<br>
                            &nbsp;&nbsp;→ Type: <span style="color:${typeMismatch ? '#f38ba8' : '#a6e3a1'}; font-weight:bold;">${obtainedTypeName}</span><br>
                            &nbsp;&nbsp;→ Fonctionnelle: <span style="color:${funcMismatch ? '#f38ba8' : '#a6e3a1'}; font-weight:bold;">${obtainedFunc}</span>
                        </div>
                        ${typeMismatch ? `<div style="color: #f38ba8; font-size: 12px; margin-top: 8px;">
                            ⚠️ <strong>Type différent</strong>: vous avez demandé ${requestedTypeName} mais QE Library n'a que ${obtainedTypeName} pour cet élément/fonctionnelle.
                        </div>` : ''}
                        ${funcMismatch ? `<div style="color: #fab387; font-size: 12px; margin-top: 4px;">
                            ⚠️ <strong>Fonctionnelle différente</strong>: ${requestedDft} demandé, ${obtainedFunc} obtenu.
                        </div>` : ''}
                        <div style="color: #6c7086; font-size: 12px; margin-top: 8px;">
                            💡 QE Library ne propose pas toutes les combinaisons (élément × fonctionnelle × type).
                        </div>
                   </div>`
                : '';
            
            // Affichage des chemins ld1 uniquement si c'est réellement ld1.x, ou si on veut montrer la tentative échouée
            const ld1Details = (result.ld1_input || result.log_file)
                ? `<div style="margin-top: 12px; padding: 12px; border-radius: 8px; background: #11111b; border: 1px solid #45475a;">
                        <div style="color: #89b4fa; font-weight: bold; margin-bottom: 6px;">
                            ${isDownload ? 'ℹ️ Tentative ld1.x (échouée) - fichiers de debug' : '📎 Fichiers ld1.x'}
                        </div>
                        <div style="font-family: monospace; font-size: 13px; line-height: 2;">
                            ${result.ld1_input ? `<div style="color: #89b4fa;">📝 Input: <span style="color: #cdd6f4;">${result.ld1_input}</span></div>` : ''}
                            ${result.log_file ? `<div style="color: #6c7086;">📋 Log: <span style="color: #cdd6f4;">${result.log_file}</span></div>` : ''}
                        </div>
                   </div>`
                : '';
            
            resultDiv.style.display = 'block';
            resultDiv.innerHTML = `
                <div style="background: ${isDownload ? '#2a213a' : '#1a3a1a'}; border: 1px solid ${isDownload ? '#b4befe' : '#a6e3a1'}; padding: 20px; border-radius: 10px; margin-top: 15px;">
                    <h4 style="color: ${isDownload ? '#b4befe' : '#a6e3a1'}; margin-top: 0;">
                        ${isDownload ? '📦 Fichier obtenu (QE Library)' : '📦 Fichiers générés'}
                    </h4>
                    <div style="font-family: monospace; font-size: 13px; line-height: 2;">
                        <div style="color: #f9e2af;">📄 UPF: <span style="color: #cdd6f4;">${result.upf_path}</span></div>
                        ${result.upf_size ? `<div style="color: #a6e3a1; margin-top: 10px;">Taille: ${(result.upf_size / 1024).toFixed(1)} KB</div>` : ''}
                    </div>
                    ${mismatchDetails}
                    ${ld1Details}
                </div>
            `;
        } else {
            statusDiv.innerHTML = `
                <div style="display: flex; align-items: center; gap: 15px;">
                    <div style="font-size: 2em;">❌</div>
                    <div>
                        <div style="color: #f38ba8; font-weight: bold;">Échec de la génération</div>
                        <div style="color: #cdd6f4; margin-top: 5px;">${result.error || 'Erreur inconnue'}</div>
                    </div>
                </div>
            `;
            
            if (result.log) {
                // Diagnostics (où est le problème dans ld1.in + corrections proposées)
                let diagHtml = '';
                if (result.diagnostics && (result.diagnostics.issues || []).length) {
                    const issues = result.diagnostics.issues;
                    const issuesHtml = issues.map((it, idx) => {
                        const lines = (it.lines || []).map(l => `${String(l.line_no).padStart(4, ' ')} | ${l.text}`).join('\n');
                        return `
                            <div style="background:#11111b; border:1px solid #45475a; border-radius:10px; padding:12px; margin-top:12px;">
                                <div style="color:#f9e2af; font-weight:bold;">${idx + 1}. ${it.title}</div>
                                <div style="color:#cdd6f4; margin-top:6px; line-height:1.6;">${it.details}</div>
                                ${lines ? `<pre style="margin-top:10px; color:#a6e3a1; font-size:12px; overflow-x:auto; white-space:pre;">${lines}</pre>` : ''}
                                <div style="color:#89b4fa; margin-top:8px;"><strong>✅ Correction proposée:</strong> ${it.suggestion}</div>
                            </div>
                        `;
                    }).join('');
                    diagHtml = `
                        <div style="background:#2a213a; border:1px solid #b4befe; padding:15px; border-radius:10px; margin-top:15px;">
                            <h4 style="color:#b4befe; margin-top:0;">🩺 Diagnostic automatique (ld1.in)</h4>
                            <div style="color:#cdd6f4; margin-top:6px;">${result.diagnostics.summary || ''}</div>
                            ${issuesHtml}
                        </div>
                    `;
                }
                resultDiv.style.display = 'block';
                resultDiv.innerHTML = `
                    <div style="background: #3a1a1a; border: 1px solid #f38ba8; padding: 15px; border-radius: 10px; margin-top: 15px;">
                        <h4 style="color: #f38ba8; margin-top: 0;">📋 Log d'erreur</h4>
                        <pre style="color: #cdd6f4; font-size: 11px; overflow-x: auto; white-space: pre-wrap;">${result.log}</pre>
                    </div>
                    ${diagHtml}
                    <div style="background: #313244; padding: 15px; border-radius: 8px; margin-top: 15px;">
                        <strong style="color: #f9e2af;">💡 Suggestion:</strong>
                        <p style="color: #cdd6f4; margin: 10px 0 0 0;">
                            Pour les éléments difficiles, essayez de télécharger depuis la bibliothèque QE:<br>
                            <button onclick="telechargerPseudoQELibrary('${element}')" style="margin-top: 10px; background: #89b4fa; color: #1e1e2e; border: none; padding: 8px 15px; border-radius: 5px; cursor: pointer;">
                                📥 Télécharger depuis QE Library
                            </button>
                        </p>
                    </div>
                `;
            }
        }
        
        btnFermer.disabled = false;
        btnFermer.textContent = '✖ Fermer';
        
    } catch (error) {
        console.error('Erreur génération:', error);
        document.getElementById('generation_status').innerHTML = `
            <div style="display: flex; align-items: center; gap: 15px;">
                <div style="font-size: 2em;">⚠️</div>
                <div>
                    <div style="color: #f38ba8; font-weight: bold;">Erreur de connexion</div>
                    <div style="color: #cdd6f4; margin-top: 5px;">${error.message}</div>
                    <div style="color: #6c7086; margin-top: 5px;">Vérifiez que l'API est en ligne (port 5007)</div>
                </div>
            </div>
        `;
        document.getElementById('btn_fermer_gen').disabled = false;
        document.getElementById('btn_fermer_gen').textContent = '✖ Fermer';
    }
}

/**
 * 📘 README / Guide: principe + recommandations (par élément et type)
 */
function ouvrirGuidePseudosLD1(element = null) {
    const el = element || (document.getElementById('pseudo_valence') ? (document.querySelector('#pseudo_valence')?.closest('[data-element]')?.dataset?.element || null) : null) || 'Si';
    const elem = ELEMENTS_LD1[el] || null;
    const currentFunctional = (document.getElementById('pseudo_functional')?.value || 'PBE').toUpperCase();
    const currentType = (document.querySelector('input[name="pseudo_type"]:checked')?.value || 'NC').toUpperCase();
    
    // Construire options éléments depuis la base
    const elementOptions = Object.keys(ELEMENTS_LD1)
        .sort((a, b) => (ELEMENTS_LD1[a].Z || 0) - (ELEMENTS_LD1[b].Z || 0))
        .map(sym => `<option value="${sym}" ${sym === el ? 'selected' : ''}>${sym} (Z=${ELEMENTS_LD1[sym].Z})</option>`)
        .join('');
    
    const modal = document.createElement('div');
    modal.id = 'modal_readme_pseudos';
    modal.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.92); display: flex; align-items: center;
        justify-content: center; z-index: 10002; padding: 20px;
    `;
    
    modal.innerHTML = `
        <div style="background: #1e1e2e; padding: 24px; border-radius: 15px; max-width: 980px; width: 96%; max-height: 92vh; overflow-y: auto; border: 1px solid #45475a;">
            <div style="display:flex; align-items:center; justify-content: space-between; gap: 12px;">
                <div>
                    <h3 style="color:#b4befe; margin:0;">📘 README / Guide — Génération des pseudos</h3>
                    <div style="color:#6c7086; margin-top:6px;">Principe (ld1.x vs QE Library) + paramètres recommandés par élément et type.</div>
                </div>
                <button onclick="document.getElementById('modal_readme_pseudos')?.remove()"
                        style="background:#45475a; color:#cdd6f4; border:none; padding:10px 14px; border-radius:8px; cursor:pointer;">
                    ✖ Fermer
                </button>
            </div>
            
            <div style="margin-top:18px; display:grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; align-items:end;">
                <div>
                    <label style="color:#cdd6f4; font-weight:bold; display:block; margin-bottom:6px;">Élément</label>
                    <select id="guide_element_select" style="width:100%; padding:10px; border-radius:8px; border:1px solid #45475a; background:#11111b; color:#cdd6f4;">
                        ${elementOptions}
                    </select>
                </div>
                <div>
                    <label style="color:#cdd6f4; font-weight:bold; display:block; margin-bottom:6px;">Type</label>
                    <select id="guide_type_select" style="width:100%; padding:10px; border-radius:8px; border:1px solid #45475a; background:#11111b; color:#cdd6f4;">
                        <option value="NC" ${currentType === 'NC' ? 'selected' : ''}>NC (pseudotype=1)</option>
                        <option value="US" ${currentType === 'US' ? 'selected' : ''}>US/USPP (pseudotype=2)</option>
                        <option value="PAW" ${currentType === 'PAW' ? 'selected' : ''}>PAW (pseudotype=3)</option>
                        <option value="RRKJ" ${currentType === 'RRKJ' ? 'selected' : ''}>RRKJ (NC/US selon lib)</option>
                    </select>
                </div>
                <div>
                    <label style="color:#cdd6f4; font-weight:bold; display:block; margin-bottom:6px;">Fonctionnelle</label>
                    <input id="guide_dft_input" value="${currentFunctional}" readonly
                           style="width:100%; padding:10px; border-radius:8px; border:1px solid #45475a; background:#11111b; color:#cdd6f4; opacity:0.9;">
                </div>
            </div>
            
            <div style="margin-top:16px; padding:14px; border-radius:10px; background:#11111b; border:1px solid #313244;">
                <div style="color:#a6e3a1; font-weight:bold; margin-bottom:8px;">✅ Principe</div>
                <div style="color:#cdd6f4; line-height:1.7;">
                    - <strong>Mode ld1.x</strong> : on exécute <code style="color:#f9e2af;">ld1.x</code> avec un <code style="color:#f9e2af;">ld1.in</code> pour produire un <code style="color:#f9e2af;">.UPF</code>.<br>
                    - <strong>Fallback QE Library</strong> : si ld1.x échoue (cas fréquent sur métaux de transition / éléments lourds),
                      l’interface télécharge un pseudo pré-généré et l’affiche comme “QE Library (fallback)”.<br>
                    - Dans ce cas, le pseudo obtenu peut différer du type demandé (ex: demandé NC → obtenu USPP).
                </div>
            </div>
            
            <div id="guide_recos" style="margin-top:16px;"></div>
            
            <div style="margin-top:16px; padding:14px; border-radius:10px; background:#1a3a1a; border:1px solid #a6e3a1;">
                <div style="color:#a6e3a1; font-weight:bold; margin-bottom:8px;">📄 Documentation</div>
                <div style="color:#cdd6f4;">
                    Le fichier guide est aussi disponible ici: <code style="color:#f9e2af;">01_INTERFACES/WEB/README_GENERATION_PSEUDOS_LD1.md</code>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    const render = () => {
        const sym = document.getElementById('guide_element_select').value;
        const type = document.getElementById('guide_type_select').value;
        const e = ELEMENTS_LD1[sym];
        
        const rel = (e.Z > 36) ? 'scalar (rel=1)' : 'none (rel=0)';
        const hasD = /\dd/.test((e.valence || '').toLowerCase()) || /d\d/.test((e.valence || '').toLowerCase());
        
        // Recommandations (heuristiques simples et lisibles)
        let recommended = {
            prefer: 'QE Library',
            pseudoType: type,
            rcloc: (e.rcut && e.rcut[0]) ? e.rcut[0] : 2.2,
            rcut_s:  (e.Z > 36) ? 4.0 : 3.0,
            rcut_p:  (e.Z > 36) ? 3.2 : 2.8,
            rcut_d:  (e.Z > 36) ? 3.0 : 2.6,
            nlcc: hasD || e.Z > 20,
            ecutwfc: (type === 'NC') ? 80 : (type === 'PAW' ? 60 : 45),
            ecutrho: (type === 'NC') ? 800 : (type === 'PAW' ? 480 : 400),
            notes: []
        };
        
        if (hasD && type === 'NC') {
            recommended.notes.push("Pour les métaux de transition (d), la génération NC via ld1.x échoue souvent; US/USPP est plus robuste.");
        }
        if (e.Z > 36) {
            recommended.notes.push("Élément lourd: relativité scalaire recommandée (rel=1).");
        }
        recommended.notes.push("Si ld1.x échoue: accepter le fallback QE Library (PSlibrary/FHI).");
        
        const html = `
            <div style="padding:14px; border-radius:10px; background:#313244; border:1px solid #45475a;">
                <div style="display:flex; gap:12px; align-items:flex-start; justify-content:space-between; flex-wrap:wrap;">
                    <div>
                        <div style="color:#f9e2af; font-weight:bold; font-size: 1.05em;">${sym} (Z=${e.Z})</div>
                        <div style="color:#cdd6f4; margin-top:6px; line-height:1.7;">
                            <div><strong>Config référence:</strong> <code style="color:#f9e2af;">${e.config}</code></div>
                            <div><strong>Valence:</strong> <code style="color:#f9e2af;">${e.valence || ''}</code></div>
                            <div><strong>Relativité:</strong> ${rel}</div>
                        </div>
                    </div>
                    <div style="min-width: 320px;">
                        <div style="color:#a6e3a1; font-weight:bold; margin-bottom:8px;">🎯 Paramètres recommandés (départ)</div>
                        <div style="color:#cdd6f4; font-family: monospace; font-size: 13px; line-height: 1.8;">
                            type: ${type}<br>
                            rcloc: ${recommended.rcloc} a.u.<br>
                            rcut(s/p/d): ${recommended.rcut_s}/${recommended.rcut_p}/${recommended.rcut_d} a.u.<br>
                            NLCC: ${recommended.nlcc ? 'true' : 'false'}<br>
                            ecutwfc: ${recommended.ecutwfc} Ry<br>
                            ecutrho: ${recommended.ecutrho} Ry
                        </div>
                    </div>
                </div>
                ${recommended.notes.length ? `
                    <div style="margin-top: 12px; padding: 12px; border-radius: 8px; background:#11111b; border:1px solid #45475a;">
                        <div style="color:#89b4fa; font-weight:bold; margin-bottom:6px;">📝 Notes</div>
                        <ul style="margin:0; padding-left: 18px; color:#cdd6f4; line-height:1.7;">
                            ${recommended.notes.map(n => `<li>${n}</li>`).join('')}
                        </ul>
                    </div>
                ` : ''}
            </div>
        `;
        
        document.getElementById('guide_recos').innerHTML = html;
    };
    
    document.getElementById('guide_element_select').addEventListener('change', render);
    document.getElementById('guide_type_select').addEventListener('change', render);
    render();
}

/**
 * BOUTON 3: Sauvegarder le pseudo généré dans /Pseudo_generes
 * Vérifie si un .UPF existe et le déplace
 */
async function sauvegarderPseudoGenere(element) {
    const functional = document.getElementById('pseudo_functional')?.value || 'PBE';
    const pseudoType = document.getElementById('pseudo_type')?.value || 'NC';
    
    // Chercher le fichier UPF dans ld1_inputs
    try {
        const response = await fetch('http://localhost:5007/api/executer_commande', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                commande: `ls ${LD1_CONFIG.LD1_INPUTS_DIR}/${element}*.UPF 2>/dev/null || ls ${LD1_CONFIG.LD1_INPUTS_DIR}/*.UPF 2>/dev/null | grep -i ${element} | head -1`
            })
        });
        
        const result = await response.json();
        
        if (result.success && result.stdout && result.stdout.trim()) {
            const upfFile = result.stdout.trim().split('\n')[0];
            const upfName = upfFile.split('/').pop();
            
            // Déplacer vers Pseudo_generes
            const moveResponse = await fetch('http://localhost:5007/api/executer_commande', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    commande: `mv "${upfFile}" "${LD1_CONFIG.PSEUDO_GENERES_DIR}/" && echo "OK"`
                })
            });
            
            const moveResult = await moveResponse.json();
            
            if (moveResult.success && moveResult.stdout.includes('OK')) {
                alert(`✅ Pseudopotentiel sauvegardé!\n\n📦 ${LD1_CONFIG.PSEUDO_GENERES_DIR}/${upfName}`);
            } else {
                throw new Error('Erreur déplacement');
            }
        } else {
            alert(`⚠️ Aucun fichier .UPF trouvé pour ${element}.\n\n` +
                  `Vous devez d'abord générer le pseudo avec ld1.x:\n\n` +
                  `1. Cliquez sur "Sauvegarder ld1.in + script.sh"\n` +
                  `2. Exécutez le script dans un terminal\n` +
                  `3. Revenez cliquer sur ce bouton`);
        }
    } catch (error) {
        console.error('Erreur:', error);
        alert(`❌ Erreur lors de la recherche du fichier UPF.\n\n` +
              `Vérifiez que:\n` +
              `1. Le pseudo a été généré avec ld1.x\n` +
              `2. L'API est en ligne (port 5007)`);
    }
}

// Exposer les fonctions globalement
window.afficherGenerateurPseudo = afficherGenerateurPseudo;
window.genererLD1Input = genererLD1Input;
window.actualiserPreviewLD1 = actualiserPreviewLD1;
window.copierLD1 = copierLD1;
window.telechargerLD1 = telechargerLD1;
window.lancerGenerationPseudo = lancerGenerationPseudo;
window.sauvegarderLD1 = sauvegarderLD1;
window.genererEtSauvegarder = genererEtSauvegarder;
window.updatePseudoTypeInfo = updatePseudoTypeInfo;
window.updateFunctionalInfo = updateFunctionalInfo;
window.ELEMENTS_LD1 = ELEMENTS_LD1;
window.PSEUDO_TYPES = PSEUDO_TYPES;
window.FUNCTIONALS = FUNCTIONALS;

console.log('✅ Script Générateur LD1 chargé');
console.log('   📊 Éléments supportés:', Object.keys(ELEMENTS_LD1).length);
console.log('   🔧 Types de pseudo:', Object.keys(PSEUDO_TYPES).length);
console.log('   ⚗️ Fonctionnelles:', Object.keys(FUNCTIONALS).length);


// ═══════════════════════════════════════════════════════════════════════════
// PARAMÈTRES QE COMPLETS PAR TYPE DE CALCUL
// Avec recommandations optimales
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Base de données des paramètres QE par type de calcul
 */
const PARAMETRES_QE = {
    'scf': {
        nom: 'SCF (Self-Consistent Field)',
        description: 'Calcul auto-cohérent pour obtenir la densité électronique et l\'énergie totale',
        parametres: {
            // &CONTROL
            calculation: { valeur: 'scf', fixe: true },
            restart_mode: { 
                valeur: 'from_scratch', 
                options: ['from_scratch', 'restart'],
                recommandation: 'from_scratch pour nouveau calcul, restart pour continuer'
            },
            pseudo_dir: { valeur: './pseudo/', type: 'text' },
            outdir: { valeur: './tmp/', type: 'text' },
            tprnfor: { valeur: true, type: 'boolean', info: 'Calculer les forces' },
            tstress: { valeur: true, type: 'boolean', info: 'Calculer le stress' },
            
            // &SYSTEM
            ecutwfc: { 
                valeur: 50, 
                unite: 'Ry',
                min: 20, max: 150, step: 5,
                recommandation: '40-60 Ry pour pseudos ultrasoft, 80-120 Ry pour PAW'
            },
            ecutrho: { 
                valeur: 400, 
                unite: 'Ry',
                min: 160, max: 1200, step: 40,
                recommandation: '8-12 × ecutwfc pour pseudos ultrasoft'
            },
            occupations: {
                valeur: 'smearing',
                options: ['smearing', 'fixed', 'tetrahedra'],
                recommandation: 'smearing pour métaux, fixed pour isolants'
            },
            smearing: {
                valeur: 'cold',
                options: ['gaussian', 'methfessel-paxton', 'marzari-vanderbilt', 'cold', 'fermi-dirac'],
                recommandation: 'cold ou marzari-vanderbilt pour métaux'
            },
            degauss: {
                valeur: 0.02,
                unite: 'Ry',
                min: 0.001, max: 0.1, step: 0.001,
                recommandation: '0.01-0.03 Ry (plus petit pour isolants)'
            },
            
            // &ELECTRONS
            conv_thr: {
                valeur: 1e-8,
                options: ['1e-6', '1e-7', '1e-8', '1e-9', '1e-10'],
                recommandation: '1e-6 pour test, 1e-8 pour production, 1e-10 pour haute précision'
            },
            mixing_beta: {
                valeur: 0.7,
                min: 0.1, max: 1.0, step: 0.05,
                recommandation: '0.3-0.5 pour systèmes difficiles, 0.7 standard'
            },
            mixing_mode: {
                valeur: 'plain',
                options: ['plain', 'TF', 'local-TF'],
                recommandation: 'plain standard, TF pour métaux'
            },
            diagonalization: {
                valeur: 'david',
                options: ['david', 'cg', 'ppcg', 'rmm-davidson'],
                recommandation: 'david standard, cg pour grands systèmes'
            },
            electron_maxstep: {
                valeur: 100,
                min: 50, max: 500, step: 50,
                recommandation: '100 standard, augmenter si non-convergence'
            }
        },
        kpoints: {
            type: 'automatic',
            grid: [4, 4, 4],
            shift: [0, 0, 0],
            recommandation: 'Grille dense pour métaux (8×8×8), moins dense pour isolants (4×4×4)'
        }
    },
    
    'nscf': {
        nom: 'NSCF (Non Self-Consistent)',
        description: 'Calcul non auto-cohérent sur grille k dense (après SCF)',
        prerequis: 'Nécessite un calcul SCF préalable',
        parametres: {
            calculation: { valeur: 'nscf', fixe: true },
            restart_mode: { valeur: 'restart', fixe: true },
            
            ecutwfc: { valeur: 50, unite: 'Ry', info: 'Doit être identique au SCF' },
            ecutrho: { valeur: 400, unite: 'Ry', info: 'Doit être identique au SCF' },
            
            occupations: { valeur: 'tetrahedra', fixe: true },
            
            conv_thr: { valeur: 1e-10, options: ['1e-8', '1e-9', '1e-10', '1e-11'] },
            diago_thr_init: {
                valeur: 1e-5,
                recommandation: 'Convergence initiale diagonalisation'
            },
            
            nbnd: {
                valeur: '',
                type: 'number',
                recommandation: '1.2-1.5 × nombre de bandes occupées (pour DOS/BANDS)'
            }
        },
        kpoints: {
            type: 'automatic',
            grid: [12, 12, 12],
            shift: [0, 0, 0],
            recommandation: 'Grille TRÈS dense (12×12×12 ou plus) pour DOS précis'
        }
    },
    
    'bands': {
        nom: 'BANDS (Structure de Bandes)',
        description: 'Calcul de structure de bandes le long de chemins dans la zone de Brillouin',
        prerequis: 'Nécessite SCF puis NSCF',
        parametres: {
            calculation: { valeur: 'bands', fixe: true },
            restart_mode: { valeur: 'restart', fixe: true },
            
            ecutwfc: { valeur: 50, unite: 'Ry', info: 'Identique au SCF' },
            ecutrho: { valeur: 400, unite: 'Ry', info: 'Identique au SCF' },
            
            nbnd: {
                valeur: '',
                type: 'number',
                recommandation: '1.5-2.0 × nombre de bandes occupées'
            }
        },
        kpoints: {
            type: 'crystal_b',
            npoints: 50,
            recommandation: 'Chemin haute-symétrie (Γ-X-M-Γ-R... selon structure)'
        }
    },
    
    'relax': {
        nom: 'RELAX (Relaxation Ionique)',
        description: 'Optimisation des positions atomiques (structure fixe)',
        parametres: {
            calculation: { valeur: 'relax', fixe: true },
            restart_mode: { valeur: 'from_scratch', options: ['from_scratch', 'restart'] },
            
            ecutwfc: { valeur: 60, unite: 'Ry', recommandation: 'Plus élevé pour relaxation' },
            ecutrho: { valeur: 480, unite: 'Ry' },
            
            occupations: { valeur: 'smearing', options: ['smearing', 'fixed'] },
            smearing: { valeur: 'cold', options: ['cold', 'marzari-vanderbilt', 'gaussian'] },
            degauss: { valeur: 0.02, unite: 'Ry' },
            
            conv_thr: { 
                valeur: 1e-9, 
                options: ['1e-8', '1e-9', '1e-10'],
                recommandation: 'Plus strict pour relaxation précise'
            },
            
            // &IONS
            ion_dynamics: {
                valeur: 'bfgs',
                options: ['bfgs', 'damp', 'verlet', 'langevin'],
                recommandation: 'bfgs (quasi-Newton) pour convergence rapide'
            },
            upscale: {
                valeur: 100,
                min: 10, max: 200, step: 10,
                recommandation: 'Facteur d\'échelle pour forces (100 standard)'
            },
            bfgs_ndim: {
                valeur: 1,
                min: 1, max: 10, step: 1,
                recommandation: 'Historique BFGS (1 standard, 3-5 pour systèmes difficiles)'
            },
            trust_radius_min: {
                valeur: 1e-4,
                unite: 'Bohr',
                recommandation: 'Rayon de confiance minimum'
            },
            trust_radius_max: {
                valeur: 0.8,
                unite: 'Bohr',
                recommandation: 'Rayon de confiance maximum'
            },
            trust_radius_ini: {
                valeur: 0.5,
                unite: 'Bohr',
                recommandation: 'Rayon de confiance initial'
            },
            forc_conv_thr: {
                valeur: 1e-4,
                unite: 'Ry/Bohr',
                options: ['1e-3', '1e-4', '1e-5'],
                recommandation: '1e-3 pour test, 1e-4 standard, 1e-5 haute précision'
            },
            nstep: {
                valeur: 100,
                min: 50, max: 500, step: 50,
                recommandation: 'Nombre max d\'étapes de relaxation'
            }
        },
        kpoints: {
            type: 'automatic',
            grid: [6, 6, 6],
            shift: [0, 0, 0],
            recommandation: 'Grille moyennement dense (6×6×6 à 8×8×8)'
        }
    },
    
    'vc-relax': {
        nom: 'VC-RELAX (Relaxation Cellule Variable)',
        description: 'Optimisation positions atomiques ET paramètres de maille',
        parametres: {
            calculation: { valeur: 'vc-relax', fixe: true },
            restart_mode: { valeur: 'from_scratch', options: ['from_scratch', 'restart'] },
            
            ecutwfc: { 
                valeur: 80, 
                unite: 'Ry', 
                recommandation: 'TRÈS élevé pour vc-relax (80-100 Ry)'
            },
            ecutrho: { valeur: 640, unite: 'Ry' },
            
            conv_thr: { 
                valeur: 1e-10,
                options: ['1e-9', '1e-10', '1e-11'],
                recommandation: 'Très strict pour vc-relax'
            },
            
            // &IONS
            ion_dynamics: { valeur: 'bfgs', fixe: true },
            forc_conv_thr: {
                valeur: 1e-5,
                unite: 'Ry/Bohr',
                recommandation: 'Très strict pour vc-relax'
            },
            
            // &CELL
            cell_dynamics: {
                valeur: 'bfgs',
                options: ['bfgs', 'damp-pr', 'damp-w'],
                recommandation: 'bfgs standard'
            },
            press: {
                valeur: 0.0,
                unite: 'kbar',
                min: -100, max: 100, step: 1,
                recommandation: 'Pression externe cible (0 = pression ambiante)'
            },
            press_conv_thr: {
                valeur: 0.5,
                unite: 'kbar',
                options: ['0.1', '0.5', '1.0'],
                recommandation: 'Convergence pression (0.5 standard)'
            },
            cell_factor: {
                valeur: 2.0,
                min: 1.0, max: 5.0, step: 0.5,
                recommandation: 'Facteur d\'expansion cellule (2.0 standard)'
            },
            cell_dofree: {
                valeur: 'all',
                options: ['all', 'ibrav', 'x', 'y', 'z', 'xy', 'xz', 'yz', 'xyz', 'shape', 'volume'],
                recommandation: 'all = tous paramètres libres, shape = forme, volume = volume seul'
            }
        },
        kpoints: {
            type: 'automatic',
            grid: [8, 8, 8],
            shift: [0, 0, 0],
            recommandation: 'Grille dense (8×8×8 minimum) pour vc-relax précis'
        }
    },
    
    'md': {
        nom: 'MD (Dynamique Moléculaire)',
        description: 'Simulation de dynamique moléculaire ab initio',
        parametres: {
            calculation: { valeur: 'md', fixe: true },
            restart_mode: { valeur: 'from_scratch', options: ['from_scratch', 'restart'] },
            
            ecutwfc: { valeur: 50, unite: 'Ry' },
            ecutrho: { valeur: 400, unite: 'Ry' },
            
            conv_thr: { valeur: 1e-7, recommandation: 'Moins strict OK pour MD' },
            
            // &IONS
            ion_dynamics: {
                valeur: 'verlet',
                options: ['verlet', 'langevin', 'beeman'],
                recommandation: 'verlet = microcanonique, langevin = thermostat'
            },
            ion_temperature: {
                valeur: 'rescaling',
                options: ['rescaling', 'rescale-v', 'rescale-T', 'reduce-T', 'berendsen', 'andersen', 'initial', 'not_controlled'],
                recommandation: 'rescaling pour contrôle température simple'
            },
            tempw: {
                valeur: 300,
                unite: 'K',
                min: 0, max: 5000, step: 50,
                recommandation: 'Température cible (300 K = température ambiante)'
            },
            dt: {
                valeur: 20,
                unite: 'a.u.',
                min: 5, max: 100, step: 5,
                recommandation: 'Pas de temps (20 a.u. ≈ 0.48 fs)'
            },
            nstep: {
                valeur: 1000,
                min: 100, max: 10000, step: 100,
                recommandation: 'Nombre de pas MD (1000 = ~500 fs avec dt=20)'
            },
            tolp: {
                valeur: 100,
                unite: 'K',
                recommandation: 'Tolérance température rescaling'
            },
            delta_t: {
                valeur: 1,
                unite: 'K',
                recommandation: 'Pas température rescaling'
            },
            nraise: {
                valeur: 1,
                recommandation: 'Fréquence rescaling température'
            }
        },
        kpoints: {
            type: 'automatic',
            grid: [2, 2, 2],
            shift: [0, 0, 0],
            recommandation: 'Grille peu dense (2×2×2) car MD très coûteux'
        }
    },

    'vc-md': {
        nom: 'VC-MD (Dynamique Moléculaire, maille variable)',
        description: 'MD ab-initio avec relaxation de la maille (QE 7.5+)',
        parametres: {
            calculation: { valeur: 'vc-md', fixe: true },
            restart_mode: { valeur: 'from_scratch', options: ['from_scratch', 'restart'] },
            ecutwfc: { valeur: 50, unite: 'Ry' },
            ecutrho: { valeur: 400, unite: 'Ry' },
            conv_thr: { valeur: 1e-7, recommandation: 'Moins strict OK pour MD' },
            ion_dynamics: { valeur: 'verlet', options: ['verlet', 'langevin'] },
            tempw: { valeur: 300, unite: 'K' },
            dt: { valeur: 20, unite: 'a.u.' },
            nstep: { valeur: 1000 },
            cell_dynamics: { valeur: 'bfgs', options: ['bfgs', 'sd'] },
            press_conv_thr: { valeur: 0.5, unite: 'kbar' }
        },
        kpoints: {
            type: 'automatic',
            grid: [2, 2, 2],
            shift: [0, 0, 0],
            recommandation: 'Grille peu dense — VC-MD très coûteux'
        }
    }
};

console.log('✅ Base de données paramètres QE chargée');








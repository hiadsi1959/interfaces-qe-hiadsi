// ═══════════════════════════════════════════════════════════════════════════
// WORKFLOW ÉTAPE PAR ÉTAPE - Lancement et suivi individuel de chaque calcul
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Lancer le workflow électronique avec sélection d'étapes
 */
async function lancerWorkflowElectronique() {
    console.log('🚀 Lancement du workflow électronique');
    
    // 1. Lire les checkboxes pour voir quelles étapes sont cochées
    const etapesCochees = lireEtapesCochees();
    
    if (etapesCochees.length === 0) {
        alert('⚠️ Aucune étape sélectionnée!\n\nCochez au moins une étape à lancer.');
        return;
    }
    
    console.log(`✅ Étapes sélectionnées: ${etapesCochees.join(', ')}`);
    
    // 2. Vérifier qu'un input est sélectionné (priorité: localStorage > DOM)
    let inputSelectionne = null;
    
    // D'abord vérifier localStorage (plus fiable)
    try {
        const stored = localStorage.getItem('qe_workflow_input_selectionne');
        if (stored) {
            const selection = JSON.parse(stored);
            inputSelectionne = selection.nom;
            console.log(`📌 Input récupéré depuis localStorage: ${inputSelectionne}`);
        }
    } catch (e) {
        console.warn('⚠️ Erreur lecture localStorage');
    }
    
    // Fallback sur le DOM
    if (!inputSelectionne) {
        inputSelectionne = document.getElementById('input_file_selected')?.textContent;
    }
    
    if (!inputSelectionne || inputSelectionne === 'Aucun' || inputSelectionne.trim() === '') {
        alert('⚠️ AUCUN MATÉRIAU SÉLECTIONNÉ!\n\n' +
              '📌 Vous devez d\'abord sélectionner un matériau dans l\'Étape 1.\n\n' +
              'Cliquez sur un des boutons de matériau (PrAlO3, GaAlO3, etc.) avant de lancer.');
        return;
    }
    
    // 3. CONFIRMATION IMPORTANTE - Afficher clairement le matériau
    const confirmation = confirm(
        `🚀 CONFIRMATION LANCEMENT\n\n` +
        `══════════════════════════════════\n` +
        `📌 MATÉRIAU: ${inputSelectionne}\n` +
        `══════════════════════════════════\n\n` +
        `Étapes: ${etapesCochees.join(' → ')}\n\n` +
        `Voulez-vous lancer le calcul pour ${inputSelectionne}?\n\n` +
        `⚠️ Si ce n'est pas le bon matériau, cliquez "Annuler"\n` +
        `et sélectionnez le bon matériau dans l'Étape 1.`
    );
    
    if (!confirmation) {
        console.log('❌ Lancement annulé par l\'utilisateur');
        return;
    }
    
    // 4. Construire le chemin complet de l'input
    const inputPath = `/home/hiadsi/génération_inputs-QE/inputs_générés_direct/prefix/${inputSelectionne}/${inputSelectionne}.in`;
    
    // 5. Afficher la zone de progression
    const progressZone = document.getElementById('workflow_progress_zone');
    if (progressZone) {
        progressZone.style.display = 'block';
        progressZone.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    
    // 5. Initialiser la console de logs
    const console_elem = document.getElementById('workflow_console');
    if (console_elem) {
        console_elem.innerHTML = `
            <div style="color: #10b981;">[INFO] ═══════════════════════════════════════════════════════</div>
            <div style="color: #10b981;">[INFO] 🚀 WORKFLOW ÉLECTRONIQUE - ${inputSelectionne}</div>
            <div style="color: #10b981;">[INFO] ═══════════════════════════════════════════════════════</div>
            <div style="color: #10b981;">[INFO] Étapes sélectionnées: ${etapesCochees.join(' → ')}</div>
            <div style="color: #10b981;">[INFO] Input: ${inputPath}</div>
            <div style="color: #10b981;">[INFO] Heure début: ${new Date().toLocaleTimeString()}</div>
            <div style="color: #10b981;">[INFO] ═══════════════════════════════════════════════════════</div>
            <div style="color: #fbbf24;">[INFO] Préparation du workflow...</div>
        `;
    }
    
    // 6. Lancer les étapes une par une
    for (let i = 0; i < etapesCochees.length; i++) {
        const etape = etapesCochees[i];
        const numero = i + 1;
        const total = etapesCochees.length;
        
        ajouterLogConsole(`\n[INFO] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`, '#3b82f6');
        ajouterLogConsole(`[INFO] 📌 ÉTAPE ${numero}/${total}: ${etape.toUpperCase()}`, '#3b82f6');
        ajouterLogConsole(`[INFO] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`, '#3b82f6');
        ajouterLogConsole(`[INFO] Début: ${new Date().toLocaleTimeString()}`, '#fbbf24');
        
        // Mettre à jour l'affichage de progression
        mettreAJourProgressionEtape(numero, total, etape);
        
        // Lancer l'étape
        const resultat = await lancerEtapeIndividuelle(etape, inputPath, inputSelectionne);
        
        if (!resultat.success) {
            ajouterLogConsole(`[ERREUR] ❌ Échec de l'étape ${etape}`, '#ef4444');
            ajouterLogConsole(`[ERREUR] ${resultat.error}`, '#ef4444');
            alert(`❌ Erreur à l'étape ${etape}:\n\n${resultat.error}\n\nLe workflow est arrêté.`);
            return;
        }
        
        ajouterLogConsole(`[INFO] ✅ Étape ${etape} terminée avec succès!`, '#10b981');
        ajouterLogConsole(`[INFO] Fichier généré: ${resultat.output_file}`, '#10b981');
        
        // Mettre à jour l'indicateur visuel
        marquerEtapeComplete(etape);
        
        // Pause pour laisser l'utilisateur vérifier
        if (i < etapesCochees.length - 1) {
            ajouterLogConsole(`[INFO] ⏸️ Pause de 2 secondes avant l'étape suivante...`, '#fbbf24');
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
    }
    
    // 7. Workflow terminé
    ajouterLogConsole(`\n[INFO] ═══════════════════════════════════════════════════════`, '#10b981');
    ajouterLogConsole(`[INFO] 🎉 WORKFLOW TERMINÉ AVEC SUCCÈS!`, '#10b981');
    ajouterLogConsole(`[INFO] ═══════════════════════════════════════════════════════`, '#10b981');
    ajouterLogConsole(`[INFO] Fin: ${new Date().toLocaleTimeString()}`, '#10b981');
    
    // Activer le bouton "Voir Résultats"
    const btnVoirResultats = document.getElementById('btn_voir_resultats');
    if (btnVoirResultats) {
        btnVoirResultats.disabled = false;
    }
    
    alert(`🎉 Workflow terminé!\n\n${etapesCochees.length} étape(s) complétée(s) avec succès.\n\nConsultez les résultats dans /home/hiadsi/Interface-QE_v1/outputs/${inputSelectionne}/`);
}

/**
 * Lire les checkboxes cochées
 */
function lireEtapesCochees() {
    const etapes = [];
    
    if (document.getElementById('wf_step_vcrelax')?.checked) etapes.push('vc-relax');
    if (document.getElementById('wf_step_scf')?.checked) etapes.push('scf');
    if (document.getElementById('wf_step_nscf')?.checked) etapes.push('nscf');
    if (document.getElementById('wf_step_bands')?.checked) etapes.push('bands');
    if (document.getElementById('wf_step_dos')?.checked) etapes.push('dos');
    
    return etapes;
}

/**
 * Lancer une étape individuelle
 */
async function lancerEtapeIndividuelle(etape, inputPath, prefix) {
    ajouterLogConsole(`[INFO] 🔄 Lancement de ${etape}...`, '#fbbf24');
    
    // Récupérer la configuration MPI
    let nprocs = 1;  // Par défaut: séquentiel
    let useMPI = false;
    
    if (typeof obtenirConfigMPI === 'function') {
        const mpiConfig = obtenirConfigMPI();
        if (mpiConfig && mpiConfig.types) {
            // Vérifier si ce type de calcul doit être parallélisé
            const typeKey = etape === 'vc-relax' ? 'vc-relax' : etape;
            if (mpiConfig.types[typeKey]) {
                nprocs = mpiConfig.nprocs || 4;
                useMPI = true;
                ajouterLogConsole(`[INFO] ⚡ Mode parallèle activé: ${nprocs} processeurs`, '#8b5cf6');
            }
        }
    }
    
    try {
        const response = await fetch('http://localhost:5007/api/lancer_calcul_custom', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                input_file: inputPath,
                output_dir: `/home/hiadsi/Interface-QE_v1/outputs/${prefix}`,
                prefix: prefix,
                type_calcul: etape,
                nprocs: nprocs,
                use_mpi: useMPI
            })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.error || 'Erreur inconnue');
        }
        
        const calculId = data.calcul_id;
        ajouterLogConsole(`[INFO] Calcul lancé (ID: ${calculId.substring(0, 20)}...)`, '#3b82f6');
        
        // Suivre le calcul en temps réel
        await suivreCalculEnTempsReel(calculId);
        
        return {
            success: true,
            output_file: data.output_file
        };
        
    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Suivre un calcul en temps réel et afficher les logs
 */
async function suivreCalculEnTempsReel(calculId) {
    ajouterLogConsole(`[INFO] 📡 Suivi du calcul en temps réel...`, '#3b82f6');
    
    let dernieresTaillesLogs = '';
    
    return new Promise((resolve) => {
        const interval = setInterval(async () => {
            try {
                const response = await fetch(`http://localhost:5007/api/etat_calcul/${calculId}`);
                const data = await response.json();
                
                // Afficher les nouveaux logs
                if (data.logs && data.logs !== dernieresTaillesLogs) {
                    // Extraire uniquement les nouvelles lignes
                    const nouvelleLignes = extraireNouvellesLignes(dernieresTaillesLogs, data.logs);
                    if (nouvelleLignes) {
                        ajouterLogConsole(nouvelleLignes, '#e2e8f0');
                    }
                    dernieresTaillesLogs = data.logs;
                }
                
                // Vérifier le statut
                if (data.statut === 'termine') {
                    clearInterval(interval);
                    ajouterLogConsole(`[INFO] ✅ Calcul terminé!`, '#10b981');
                    resolve({ success: true });
                } else if (data.statut === 'erreur') {
                    clearInterval(interval);
                    ajouterLogConsole(`[ERREUR] ❌ Calcul en erreur`, '#ef4444');
                    resolve({ success: false, error: 'Calcul échoué' });
                }
                
            } catch (error) {
                console.error('Erreur suivi calcul:', error);
            }
        }, 3000); // Vérifier toutes les 3 secondes
    });
}

/**
 * Extraire les nouvelles lignes de logs
 */
function extraireNouvellesLignes(ancienLogs, nouveauxLogs) {
    if (!ancienLogs) return nouveauxLogs;
    if (!nouveauxLogs) return '';
    
    // Prendre seulement les dernières lignes (les 10 dernières)
    const lignes = nouveauxLogs.split('\n');
    const dernieres = lignes.slice(-10).join('\n');
    
    return dernieres;
}

/**
 * Ajouter un log dans la console du workflow
 */
function ajouterLogConsole(message, couleur = '#e2e8f0') {
    const console_elem = document.getElementById('workflow_console');
    if (!console_elem) return;
    
    const logLine = document.createElement('div');
    logLine.style.color = couleur;
    logLine.textContent = message;
    
    console_elem.appendChild(logLine);
    console_elem.scrollTop = console_elem.scrollHeight;
}

/**
 * Mettre à jour la progression de l'étape
 */
function mettreAJourProgressionEtape(numero, total, etape) {
    // Mise à jour du texte
    const stepText = document.getElementById('workflow_current_step');
    if (stepText) {
        stepText.textContent = `Étape ${numero}/${total}: ${etape.toUpperCase()}`;
    }
    
    // Mise à jour du pourcentage
    const percent = document.getElementById('workflow_progress_percent');
    if (percent) {
        const progression = Math.round((numero / total) * 100);
        percent.textContent = `${progression}%`;
    }
    
    // Mise à jour de la barre
    const bar = document.getElementById('workflow_progress_bar');
    if (bar) {
        const progression = (numero / total) * 100;
        bar.style.width = `${progression}%`;
    }
    
    // Marquer l'indicateur comme actif
    const indicators = document.querySelectorAll('.step-indicator');
    indicators.forEach((ind, idx) => {
        const circle = ind.querySelector('div');
        if (idx < numero) {
            // Étape complétée
            circle.style.background = '#10b981';
            circle.style.color = 'white';
            circle.textContent = '✓';
        } else if (idx === numero - 1) {
            // Étape en cours
            circle.style.background = '#3b82f6';
            circle.style.color = 'white';
            circle.style.animation = 'pulse 2s infinite';
        }
    });
}

/**
 * Marquer une étape comme complétée
 */
function marquerEtapeComplete(etape) {
    const mapping = {
        'vc-relax': 0,
        'scf': 1,
        'nscf': 2,
        'bands': 3,
        'dos': 4
    };
    
    const index = mapping[etape];
    if (index === undefined) return;
    
    const indicators = document.querySelectorAll('.step-indicator');
    if (indicators[index]) {
        const circle = indicators[index].querySelector('div');
        circle.style.background = '#10b981';
        circle.style.color = 'white';
        circle.textContent = '✓';
        circle.style.animation = 'none';
    }
}

/**
 * Activer le bouton de lancement quand un input est sélectionné
 */
function activerBoutonWorkflow() {
    const btn = document.getElementById('btn_lancer_workflow_elec');
    const status = document.getElementById('workflow_elec_status');
    
    if (btn) btn.disabled = false;
    if (status) status.textContent = '✅ Prêt à lancer';
    if (status) status.style.color = '#10b981';
}

/**
 * Pauserpauserle workflow
 */
function pauserWorkflow() {
    alert('⏸️ Fonction de pause en développement');
}

/**
 * Arrêter le workflow
 */
function arreterWorkflow() {
    if (confirm('⚠️ Voulez-vous vraiment arrêter le workflow?\n\nLes calculs en cours seront interrompus.')) {
        location.reload();
    }
}

/**
 * Voir les résultats du workflow
 */
function voirResultatsWorkflow() {
    const inputSelectionne = document.getElementById('input_file_selected')?.textContent;
    if (!inputSelectionne || inputSelectionne === 'Aucun') {
        alert('⚠️ Aucun résultat disponible');
        return;
    }
    
    alert(`📊 Résultats disponibles dans:\n\n/home/hiadsi/Interface-QE_v1/outputs/${inputSelectionne}/\n\nVous pouvez consulter les fichiers .out pour voir les résultats détaillés.`);
}

// Ajouter l'animation pulse si elle n'existe pas
if (!document.getElementById('pulse-animation')) {
    const style = document.createElement('style');
    style.id = 'pulse-animation';
    style.textContent = `
        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.1); opacity: 0.8; }
        }
    `;
    document.head.appendChild(style);
}

console.log('✅ Script workflow étape par étape chargé');


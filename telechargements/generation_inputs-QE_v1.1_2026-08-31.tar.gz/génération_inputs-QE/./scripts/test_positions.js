// ═══════════════════════════════════════════════════════════════════════════
// TEST SIMPLE - DÉBOGUER LE PROBLÈME DES POSITIONS À 0
// ═══════════════════════════════════════════════════════════════════════════

console.log('\n\n╔════════════════════════════════════════════════════════╗');
console.log('║         TEST POSITIONS ATOMIQUES - DIAGNOSTIC          ║');
console.log('╚════════════════════════════════════════════════════════╝\n');

// TEST 1: Vérifier les positions prédéfinies
console.log('TEST 1: Vérifier POSITIONS_PAR_IBRAV');
console.log('───────────────────────────────────────');
if (typeof POSITIONS_PAR_IBRAV !== 'undefined') {
    console.log('✓ POSITIONS_PAR_IBRAV existe');
    console.log('  Structures disponibles:', Object.keys(POSITIONS_PAR_IBRAV));
    
    // Tester ibrav=2
    const struct2 = POSITIONS_PAR_IBRAV['2'];
    console.log('\n  ibrav=2:', struct2.name);
    console.log('  Positions:', struct2.positions);
} else {
    console.error('✗ POSITIONS_PAR_IBRAV NOT FOUND');
}

// TEST 2: Vérifier les éléments HTML
console.log('\n\nTEST 2: Vérifier les éléments HTML');
console.log('───────────────────────────────────');
const nat = document.getElementById('nat');
const ibrav = document.getElementById('ibrav');
console.log('nat input:', nat ? '✓ Trouvé' : '✗ NOT FOUND');
console.log('ibrav input:', ibrav ? '✓ Trouvé' : '✗ NOT FOUND');

if (nat && ibrav) {
    console.log(`  nat value: ${nat.value}`);
    console.log(`  ibrav value: ${ibrav.value}`);
}

// TEST 3: Tester la création du tableau
console.log('\n\nTEST 3: Vérifier si le tableau existe');
console.log('─────────────────────────────────────');
const testNat = 3;
for (let i = 1; i <= testNat; i++) {
    const x = document.getElementById(`pos_x_${i}`);
    const y = document.getElementById(`pos_y_${i}`);
    const z = document.getElementById(`pos_z_${i}`);
    const elem = document.getElementById(`elem_${i}`);
    
    console.log(`Atome ${i}:`);
    console.log(`  pos_x_${i}: ${x ? '✓' : '✗'}`);
    console.log(`  pos_y_${i}: ${y ? '✓' : '✗'}`);
    console.log(`  pos_z_${i}: ${z ? '✓' : '✗'}`);
    console.log(`  elem_${i}: ${elem ? '✓' : '✗'}`);
}

// TEST 4: Tester le remplissage direct
console.log('\n\nTEST 4: Tester le remplissage DIRECT');
console.log('────────────────────────────────────');
console.log('Remplissage manuel des 3 premiers champs...');

const testValues = [
    [0, 0, 0],
    [0.5, 0.5, 0.5],
    [0.333, 0.667, 0.25]
];

for (let i = 1; i <= 3; i++) {
    const [x, y, z] = testValues[i - 1];
    const xInput = document.getElementById(`pos_x_${i}`);
    const yInput = document.getElementById(`pos_y_${i}`);
    const zInput = document.getElementById(`pos_z_${i}`);
    
    if (xInput && yInput && zInput) {
        xInput.value = x.toFixed(6);
        yInput.value = y.toFixed(6);
        zInput.value = z.toFixed(6);
        
        console.log(`\nAtome ${i}: Écrit [${x.toFixed(6)}, ${y.toFixed(6)}, ${z.toFixed(6)}]`);
        
        // Vérifier immédiatement
        console.log(`  Lecture immédiate:`);
        console.log(`    xInput.value = ${xInput.value}`);
        console.log(`    yInput.value = ${yInput.value}`);
        console.log(`    zInput.value = ${zInput.value}`);
    } else {
        console.warn(`✗ Champs non trouvés pour atome ${i}`);
    }
}

// TEST 5: Appeler mettreAJourFormat
console.log('\n\nTEST 5: Appeler mettreAJourFormat()');
console.log('──────────────────────────────────');

if (typeof mettreAJourFormat === 'function') {
    console.log('✓ mettreAJourFormat existe');
    console.log('Appel...');
    mettreAJourFormat();
    
    if (window.atomicPositionsContent) {
        console.log('\n✓ atomicPositionsContent généré:');
        console.log(window.atomicPositionsContent);
    } else {
        console.warn('✗ atomicPositionsContent vide');
    }
} else {
    console.error('✗ mettreAJourFormat NOT FOUND');
}

// TEST 6: Vérifier l'affichage
console.log('\n\nTEST 6: Vérifier l\'affichage dans le DOM');
console.log('───────────────────────────────────────');
const formatDiv = document.getElementById('atomic_pos_format');
const textDiv = document.getElementById('atomic_pos_text');

console.log('atomic_pos_format:', formatDiv ? '✓' : '✗');
console.log('atomic_pos_text:', textDiv ? '✓' : '✗');

if (textDiv) {
    console.log('\nContenu du DOM:');
    console.log(textDiv.textContent);
}

console.log('\n╔════════════════════════════════════════════════════════╗');
console.log('║              FIN DU TEST DIAGNOSTIC                  ║');
console.log('╚════════════════════════════════════════════════════════╝\n');

// Exporter une fonction de test pour utilisation manuelle
window.testGenererPositions = function() {
    console.log('\n\n🚀 TEST MANUEL: Génération des positions');
    console.log('=========================================\n');
    
    // Simuler: nat=3, ibrav=2
    const natInput = document.getElementById('nat');
    if (natInput) natInput.value = 3;
    
    const ibravInput = document.getElementById('ibrav');
    if (ibravInput) ibravInput.value = '2';
    
    // Forcer recréation du tableau
    if (typeof reconstruirePositionsAtomiques === 'function') {
        console.log('→ Appel reconstruirePositionsAtomiques()...');
        reconstruirePositionsAtomiques();
        
        setTimeout(() => {
            console.log('\n→ Appel genererPositionsAuto()...');
            if (typeof genererPositionsAuto === 'function') {
                genererPositionsAuto();
            }
        }, 200);
    }
};

console.log('💡 POUR TESTER MANUELLEMENT, tapez dans la console:');
console.log('   testGenererPositions()');
console.log('');



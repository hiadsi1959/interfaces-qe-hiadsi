// ═══════════════════════════════════════════════════════════════════════════
// RESTRUCTURATION COMPLÈTE DU TAB 1 - ORDRE LOGIQUE
// N'affecte QUE le Tab 1 "Génération d'Inputs"
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Créer la structure complète du Tab 1 de manière organisée
 */
function restructurerTab1Complet(opts) {
    opts = opts || {};
    console.log('🔄 Restructuration complète du Tab 1...');
    
    const tab1 = document.querySelector('.tab-content');
    if (!tab1) {
        console.warn('⚠️ Tab 1 non trouvé');
        return;
    }
    
    const card = tab1.querySelector('.card');
    if (!card) {
        console.warn('⚠️ Card du Tab 1 non trouvé');
        return;
    }
    
    if (document.getElementById('tab1_restructured') && !opts.force) {
        console.log('⚠️ Tab 1 déjà restructuré');
        return;
    }

    var markerOld = document.getElementById('tab1_restructured');
    if (markerOld) markerOld.remove();
    
    let newHTML = (typeof window.buildTab1HTML === 'function')
        ? window.buildTab1HTML()
        : '<div id="tab1_header"><h1>Tab 1</h1></div>';
    
    // Préserver la sous-section Gestion (éditeur CIF, statut conversion) — sinon innerHTML la détruit
    var preservedGestion = document.getElementById('subsection_gestion');
    if (preservedGestion && preservedGestion.parentNode) {
        preservedGestion.parentNode.removeChild(preservedGestion);
    }

    // Remplacer le contenu du card
    card.innerHTML = newHTML;

    // Marquer comme restructuré APRÈS innerHTML (sinon le marqueur est détruit)
    const marker = document.createElement('div');
    marker.id = 'tab1_restructured';
    marker.style.display = 'none';
    card.appendChild(marker);
    card.classList.remove('tab1-restruct-pending', 'tab1-boot-pending');
    card.classList.add('tab1-restructured-ready', 'tab1-boot-ready');

    if (preservedGestion && tab1) {
        tab1.appendChild(preservedGestion);
    } else if (typeof window.ensureSubsectionGestionInTab1 === 'function') {
        window.ensureSubsectionGestionInTab1();
    }

    if (typeof window.initCifGestionAfterFragment === 'function') {
        setTimeout(window.initCifGestionAfterFragment, 50);
    }
    if (typeof window.applyI18n === 'function') {
        window.applyI18n();
    }

    if (typeof window.ensureTypeMateriauFields === 'function') {
        window.ensureTypeMateriauFields();
    }

    document.dispatchEvent(new CustomEvent('tab1Restructured'));

    if (typeof window.initInputDftSelects === 'function') {
        window.initInputDftSelects([{ id: 'pw_input_dft', def: 'pbe' }]);
    }
    
    console.log('✅ Tab 1 restructuré complètement');
}

/**
 * Afficher les paramètres cristallins selon ibrav
 */
/**
 * Afficher les paramètres de calcul selon le type
 */
function afficherParametresCalcul() {
    const calcType = document.getElementById('calculation_type')?.value;
    const container = document.getElementById('parametres_calcul_container');
    
    if (!container || !calcType) return;
    
    let html = '';
    
    // Paramètres communs à tous les calculs
    const paramsCommuns = {
        'ecutwfc': { label: 'Cutoff des ondes planes (Ry)', val: '50' },
        'ecutrho': { label: 'Cutoff de la charge (Ry)', val: '200' },
        'functional': { label: 'Fonctionnelle XC', val: 'PBE' },
        'kpoints': { label: 'Points k (automatique)', val: '2 2 2' },
        'mixing_beta': { label: 'Paramètre de mélange', val: '0.7' },
        'conv_thr': { label: 'Seuil de convergence', val: '1.0d-8' }
    };
    
    // Paramètres spécifiques par type de calcul
    const paramsSpecifiques = {
        'scf': ['diag_david', 'max_nstep'],
        'nscf': ['diag_david', 'nbnd'],
        'bands': ['diag_david', 'nbnd'],
        'dos': ['tetrahedra', 'degauss'],
        'relax': ['ion_dynamics', 'bfgs_ndim'],
        'vc-relax': ['cell_dynamics', 'bfgs_ndim'],
        'md': ['ion_dynamics', 'dt']
    };
    
    // Ajouter paramètres communs
    Object.keys(paramsCommuns).forEach(key => {
        const param = paramsCommuns[key];
        html += `
            <div class="form-group">
                <label style="font-weight: bold; color: #f57f17; display: block; margin-bottom: 5px; font-size: 0.95em;">${param.label}:</label>
                <input type="text" id="param_${key}" placeholder="${param.val}" value="${param.val}"
                       style="width: 100%; padding: 8px; border: 1px solid #fbc02d; border-radius: 4px;">
            </div>
        `;
    });
    
    // Ajouter paramètres spécifiques
    const specifiques = paramsSpecifiques[calcType] || [];
    specifiques.forEach(param => {
        html += `
            <div class="form-group">
                <label style="font-weight: bold; color: #f57f17; display: block; margin-bottom: 5px; font-size: 0.95em;">${param}:</label>
                <input type="text" id="param_${param}" placeholder="Valeur"
                       style="width: 100%; padding: 8px; border: 1px solid #fbc02d; border-radius: 4px;">
            </div>
        `;
    });
    
    container.innerHTML = html;
}

/**
 * Initialiser les structures (populate ibrav select)
 */
function initialiserStructuresTab1_v2() {
    const ibravSelect = document.getElementById('ibrav');
    if (!ibravSelect) {
        console.warn('⚠️ ibravSelect non trouvé');
        return;
    }
    
    // Vider d'abord
    ibravSelect.innerHTML = '<option value="">' + ((typeof window.t === 'function') ? window.t('common.select') : '-- Sélectionner --') + '</option>';
    
    // Structures de Bravais
    const structures = [
        { value: '1', label: '1 - Cubique Simple (SC)' },
        { value: '2', label: '2 - Cubique Faces Centrées (FCC)' },
        { value: '3', label: '3 - Cubique Centré (BCC)' },
        { value: '4', label: '4 - Hexagonal' },
        { value: '5', label: '5 - Rhomboédrique' },
        { value: '6', label: '6 - Tétragonal Simple' },
        { value: '7', label: '7 - Tétragonal Centré' },
        { value: '8', label: '8 - Orthorhombique Simple' },
        { value: '9', label: '9 - Orthorhombique Centré' },
        { value: '10', label: '10 - Orthorhombique F' },
        { value: '11', label: '11 - Orthorhombique I' },
        { value: '12', label: '12 - Monoclinique Simple' },
        { value: '13', label: '13 - Monoclinique Centré' },
        { value: '14', label: '14 - Triclinique' }
    ];
    
    structures.forEach(struct => {
        const option = document.createElement('option');
        option.value = struct.value;
        option.textContent = struct.label;
        ibravSelect.appendChild(option);
    });
    
    console.log('✅ Structures initialisées (14 disponibles)');
}

/**
 * Afficher les groupes d'espace (utilise GROUPES_ESPACE_COMPLETS)
 */
function afficherGroupesEspaceTab1_v2() {
    const ibravSelect = document.getElementById('ibrav');
    const groupeSelect = document.getElementById('groupe_espace_select');
    
    if (!ibravSelect || !groupeSelect || !ibravSelect.value) return;
    
    const ibrav = ibravSelect.value;
    
    // Récupérer les groupes depuis GROUPES_ESPACE_COMPLETS
    let groupes = [];
    if (typeof GROUPES_ESPACE_COMPLETS !== 'undefined') {
        for (const [systeme, data] of Object.entries(GROUPES_ESPACE_COMPLETS)) {
            if (data.ibrav.includes(parseInt(ibrav))) {
                groupes = data.groupes;
                break;
            }
        }
    }
    
    if (groupes.length === 0) {
        console.warn('⚠️ Aucun groupe trouvé pour ibrav', ibrav);
        return;
    }
    
    // Remplir le select
    groupeSelect.innerHTML = '<option value="">' + ((typeof window.t === 'function') ? window.t('sec2.select_ibrav_first') : '-- Sélectionner d\'abord ibrav --') + '</option>';
    
    groupes.forEach(groupe => {
        const option = document.createElement('option');
        option.value = groupe.numero;
        let text = `${groupe.numero} - ${groupe.hermann_mauguin}`;
        if (groupe.centrage) text += ` (${groupe.centrage})`;
        option.textContent = text;
        groupeSelect.appendChild(option);
    });
    
    console.log(`✅ ${groupes.length} groupes affichés pour ibrav ${ibrav}`);
}

/**
 * Reconstruire Tab 1 + sections dynamiques lors d'un changement de langue
 */
window.rebuildTab1ForLanguage = function rebuildTab1ForLanguage() {
    if (!document.getElementById('tab1_restructured')) return;

    var activeBtn = document.querySelector('#tab1_main_nav .tab1-main-nav-btn.active');
    var panelId = activeBtn ? activeBtn.getAttribute('data-tab1-panel') : 'guide';
    var tab1Root = document.querySelector('.tab-content');
    var snap = (typeof window.snapshotFormFields === 'function' && tab1Root)
        ? window.snapshotFormFields(tab1Root) : {};

    var s5 = document.getElementById('section_5_type_calcul_chemins');
    var s5snap = s5 && typeof window.snapshotFormFields === 'function'
        ? window.snapshotFormFields(s5) : null;
    if (s5) s5.remove();

    var sg = document.getElementById('section_generation_input');
    var previewVal = '';
    var previewVisible = false;
    if (sg) {
        var ta = document.getElementById('input_content');
        if (ta) previewVal = ta.value;
        var panel = document.getElementById('gen_input_preview_panel');
        previewVisible = panel && panel.style.display !== 'none';
        sg.remove();
    }

    restructurerTab1Complet({ force: true });

    if (typeof window.restoreFormFields === 'function') {
        window.restoreFormFields(snap);
    }
    if (typeof initialiserStructuresTab1_v2 === 'function') {
        initialiserStructuresTab1_v2();
    }
    var ibravSelect = document.getElementById('ibrav');
    if (ibravSelect && snap.ibrav) {
        ibravSelect.value = snap.ibrav;
        if (typeof afficherGroupesEspaceTab1_v2 === 'function') afficherGroupesEspaceTab1_v2();
        if (typeof afficherParametresCristallins === 'function') afficherParametresCristallins();
    }

    if (typeof window.creerSection5TypeCalculChemins === 'function') {
        window.creerSection5TypeCalculChemins({ force: true });
        if (s5snap && typeof window.restoreFormFields === 'function') {
            window.restoreFormFields(s5snap);
        }
    }
    if (typeof window.creerSectionGenerationInput === 'function') {
        window.creerSectionGenerationInput({ force: true });
        if (previewVal) {
            var ta2 = document.getElementById('input_content');
            if (ta2) ta2.value = previewVal;
        }
        if (previewVisible) {
            var pan2 = document.getElementById('gen_input_preview_panel');
            if (pan2) pan2.style.display = 'block';
        }
    }
    if (typeof window.populateAllCalcTypeSelects === 'function') {
        try { window.populateAllCalcTypeSelects(); } catch (_ePop) {}
    }
    if (typeof window.initInputDftSelects === 'function') {
        try { window.initInputDftSelects([{ id: 'pw_input_dft', def: 'pbe' }]); } catch (_eDft) {}
    }
    if (panelId && typeof window.tab1SwitchMainTab === 'function') {
        try { window.tab1SwitchMainTab(panelId, { scroll: false }); } catch (_eSw) {}
    }
    if (typeof window.ensureTypeMateriauFields === 'function') {
        window.ensureTypeMateriauFields();
    }
};

/**
 * Initialiser la restructuration
 */
function initialiserRestructurationTab1() {
    console.log('🔄 Initialisation restructuration Tab 1...');

    function runRestruct() {
        setTimeout(() => {
            restructurerTab1Complet();
            initialiserStructuresTab1_v2();
            const ibravSelect = document.getElementById('ibrav');
            if (ibravSelect) {
                ibravSelect.addEventListener('change', afficherGroupesEspaceTab1_v2);
                afficherGroupesEspaceTab1_v2();
            }
            afficherParametresCristallins();
            console.log('✅ Restructuration Tab 1 complétée');
        }, 0);
    }

    if (window.__HTML_FRAGMENTS_LOADED__) {
        runRestruct();
    } else {
        document.addEventListener('htmlFragmentsLoaded', runRestruct, { once: true });
    }
}

// Exécuter au chargement
function tab1RevealCardFallback() {
    if (document.getElementById('tab1_restructured')) return;
    var sel = '.tab-content.active > .card.tab1-boot-pending, .tab-content.active > .card.tab1-restruct-pending';
    document.querySelectorAll(sel).forEach(function (c) {
        c.innerHTML = ''
            + '<div style="padding:48px 24px;text-align:center;line-height:1.6;color:#475569;">'
            + '<p style="font-size:1.1em;font-weight:600;margin:0 0 12px;">Chargement de l\'interface…</p>'
            + '<p style="margin:0;font-size:0.92em;">Si cet écran persiste&nbsp;: Ctrl+F5, puis vérifiez que <code>./DEMARRER.sh</code> tourne sur le port 5012.</p>'
            + '</div>';
        c.classList.remove('tab1-restruct-pending', 'tab1-boot-pending');
        c.classList.add('tab1-restructured-ready', 'tab1-boot-ready');
        console.warn('⚠️ Tab 1 — montage lent ou bloqué (fallback affiché)');
    });
}

function tab1ScheduleRevealFallback() {
    setTimeout(tab1RevealCardFallback, 2000);
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialiserRestructurationTab1);
    document.addEventListener('DOMContentLoaded', tab1ScheduleRevealFallback);
} else {
    initialiserRestructurationTab1();
    tab1ScheduleRevealFallback();
}

// ═══════════════════════════════════════════════════════════════════════════
// FONCTIONS D'ACCÈS RAPIDE AUX FICHIERS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Prépare le panneau « Autres entrées » (details ouvert).
 */
window.tab1PrepareAutresEntrees = function tab1PrepareAutresEntrees() {
    var det = document.getElementById('tab1_autres_entrees');
    if (det) det.open = true;
    afficherZoneFichiers();
};

/**
 * Afficher la zone de résultats
 */
function afficherZoneFichiers() {
    const zone = document.getElementById('zone_resultats_fichiers');
    const btnFermer = document.getElementById('btn_fermer_fichiers');
    if (zone) zone.style.display = 'block';
    if (btnFermer) btnFermer.style.display = 'inline-block';
}

/**
 * Fermer la zone de résultats
 */
window.fermerZoneFichiers = function() {
    const zone = document.getElementById('zone_resultats_fichiers');
    const btnFermer = document.getElementById('btn_fermer_fichiers');
    const listeInputs = document.getElementById('liste_inputs_existants');
    const listeCif = document.getElementById('liste_fichiers_cif');
    
    if (zone) zone.style.display = 'none';
    if (btnFermer) btnFermer.style.display = 'none';
    if (listeInputs) listeInputs.innerHTML = '';
    if (listeCif) listeCif.innerHTML = '';
};

/**
 * Résout la liste d’inputs : préfère l’impl. de script_gestion_fichiers_complet.js (window.*),
 * sinon repli sur la fonction globale du inline index.html (legacy 5007).
 */
function __resolveListerInputsExistants() {
    if (typeof window.listerInputsExistants === 'function') {
        return window.listerInputsExistants;
    }
    try {
        if (typeof listerInputsExistants === 'function') {
            return listerInputsExistants;
        }
    } catch (e) { /* strict / scope */ }
    return null;
}

function __resolveListerFichiersCIF() {
    if (typeof window.listerFichiersCIF === 'function') {
        return window.listerFichiersCIF;
    }
    try {
        if (typeof listerFichiersCIF === 'function') {
            return listerFichiersCIF;
        }
    } catch (e) { /* strict / scope */ }
    return null;
}

function __msgListerIndisponibleHtml() {
    if (typeof window !== 'undefined' && window.__GEN_INPUTS_STANDALONE__) {
        return '<div style="color:#92400e;background:#fef3c7;border:1px solid #d97706;padding:16px;border-radius:10px;line-height:1.5;">'
            + '<strong>❌ Liste indisponible</strong><br>'
            + 'Le script <code>script_gestion_fichiers_complet.js</code> ne s’est pas chargé correctement, ou une erreur JavaScript l’a empêché de s’exécuter.<br><br>'
            + '<strong>Mode autonome :</strong> rechargez la page (Ctrl+F5), lancez <code>./DEMARRER.sh</code> et ouvrez <code>http://127.0.0.1:5012</code>. '
            + 'Vérifiez la console du navigateur (F12) pour une erreur de chargement de script.</div>';
    }
    return '<div style="color:#991b1b;padding:20px;">❌ Fonction non disponible. '
        + 'Pour la liste via l’API complète, démarrez l’API <strong>Interface-QE (port 5007)</strong> ou utilisez le paquet autonome : '
        + '<code>./DEMARRER.sh</code> puis <code>http://127.0.0.1:5012</code>.</div>';
}

/**
 * Ouvrir les inputs existants (accès rapide)
 */
window.ouvrirInputsExistantsRapide = function() {
    console.log('📂 Clic sur: Ouvrir Inputs Existants');

    if (typeof window.tab1PrepareAutresEntrees === 'function') window.tab1PrepareAutresEntrees();

    const listeCif = document.getElementById('liste_cif_rapide');
    if (listeCif) listeCif.innerHTML = '';

    const listFn = __resolveListerInputsExistants();
    if (typeof listFn === 'function') {
        console.log('✅ Appel de listerInputsExistants...');
        listFn();
        var zone = document.getElementById('zone_resultats_fichiers');
        if (zone) zone.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        if (typeof window.tab1ShowStatus === 'function') {
            window.tab1ShowStatus('info', '📂 Chargement des inputs existants…', { scroll: true });
        }
    } else {
        const listeDiv = document.getElementById('liste_inputs_rapide');
        if (listeDiv) {
            listeDiv.innerHTML = __msgListerIndisponibleHtml();
        }
    }
};

/**
 * Ouvrir les fichiers CIF (accès rapide)
 */
window.ouvrirFichiersCIFRapide = function() {
    console.log('🔬 Clic sur: Ouvrir Fichiers CIF');

    if (typeof window.tab1PrepareAutresEntrees === 'function') window.tab1PrepareAutresEntrees();

    const listeInputs = document.getElementById('liste_inputs_rapide');
    if (listeInputs) listeInputs.innerHTML = '';

    const listFn = __resolveListerFichiersCIF();
    if (typeof listFn === 'function') {
        console.log('✅ Appel de listerFichiersCIF...');
        listFn();
        var zone = document.getElementById('zone_resultats_fichiers');
        if (zone) zone.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        if (typeof window.tab1ShowStatus === 'function') {
            window.tab1ShowStatus('info', '🔬 Chargement des fichiers CIF…', { scroll: true });
        }
    } else {
        const listeDiv = document.getElementById('liste_cif_rapide');
        if (listeDiv) {
            listeDiv.innerHTML = __msgListerIndisponibleHtml();
        }
    }
};

console.log('✅ Script restructuration Tab 1 chargé (avec accès rapide v6)');


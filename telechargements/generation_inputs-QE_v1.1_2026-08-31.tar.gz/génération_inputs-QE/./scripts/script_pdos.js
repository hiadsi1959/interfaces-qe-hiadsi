// ═══════════════════════════════════════════════════════════════════════════
// SCRIPT PDOS - Densité d'États Projetée
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Parse les fichiers PDOS générés par projwfc.x
 * Format: prefix.pdos_atm#N(ELEMENT)_wfc#M(ORBITAL)
 * Exemple: gan.pdos_atm#1(Ga)_wfc#1(s), gan.pdos_atm#1(Ga)_wfc#2(p), etc.
 */
async function listerFichiersPDOS(materiau) {
    try {
        const outputDir = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}`;
        const data = await window.postJSON('http://localhost:5007/api/lister_fichiers', { 
            dossier: outputDir 
        });
        
        if (!data.success) {
            console.warn('Impossible de lister les fichiers PDOS');
            return [];
        }
        
        // Filtrer les fichiers .pdos_atm
        const fichiersPDOS = data.fichiers.filter(f => f.nom.includes('.pdos_atm'));
        
        return fichiersPDOS.map(f => f.nom);
    } catch (e) {
        console.error('Erreur listage PDOS:', e);
        return [];
    }
}

/**
 * Parse un fichier PDOS individuel
 * Format du fichier:
 * # E (eV)  ldos(E)  pdos(E)
 * -10.000  0.0000  0.0000
 * -9.950   0.0001  0.0001
 * ...
 */
async function parserFichierPDOS(materiau, nomFichier) {
    try {
        const filepath = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}/${nomFichier}`;
        const data = await window.postJSON('http://localhost:5007/api/lire_fichier', { 
            filepath: filepath 
        });
        
        if (!data.success) {
            console.warn(`Fichier PDOS ${nomFichier} non trouvé`);
            return null;
        }
        
        const lines = data.contenu.trim().split('\n');
        const energy = [];
        const pdos = [];
        
        for (const line of lines) {
            if (line.trim().startsWith('#')) continue;
            const parts = line.trim().split(/\s+/).filter(x => x);
            if (parts.length >= 2) {
                energy.push(parseFloat(parts[0]));
                // Colonne 2 = ldos, Colonne 3 = pdos (si disponible)
                const dosValue = parts.length >= 3 ? parseFloat(parts[2]) : parseFloat(parts[1]);
                pdos.push(dosValue);
            }
        }
        
        // Extraire l'atome et l'orbitale depuis le nom du fichier
        // Format: prefix.pdos_atm#1(Ga)_wfc#1(s)
        const matchAtom = nomFichier.match(/atm#(\d+)\(([^)]+)\)/);
        const matchOrbital = nomFichier.match(/wfc#(\d+)\(([^)]+)\)/);
        
        const atomNum = matchAtom ? matchAtom[1] : '?';
        const atomSymbol = matchAtom ? matchAtom[2] : '?';
        const orbitalNum = matchOrbital ? matchOrbital[1] : '?';
        const orbitalType = matchOrbital ? matchOrbital[2] : '?';
        
        return {
            energy,
            pdos,
            atomNum,
            atomSymbol,
            orbitalNum,
            orbitalType,
            label: `${atomSymbol} (${orbitalType})`
        };
    } catch (e) {
        console.error(`Erreur parsing PDOS ${nomFichier}:`, e);
        return null;
    }
}

/**
 * Organise les PDOS par atome
 */
function organiserPDOSParAtome(pdosData) {
    const parAtome = {};
    
    for (const pdos of pdosData) {
        if (!pdos) continue;
        
        const key = `${pdos.atomSymbol}_${pdos.atomNum}`;
        if (!parAtome[key]) {
            parAtome[key] = {
                symbol: pdos.atomSymbol,
                num: pdos.atomNum,
                orbitales: []
            };
        }
        
        parAtome[key].orbitales.push(pdos);
    }
    
    return parAtome;
}

/**
 * Trace le DOS total + PDOS par atome
 */
function tracerDOSAvecPDOS(dosTotal, pdosData, divId, fermi = 0, emin = -10, emax = 10) {
    const traces = [];
    
    // 1. DOS Total (ligne épaisse noire)
    if (dosTotal && dosTotal.energy && dosTotal.dos) {
        traces.push({
            x: dosTotal.dos,
            y: dosTotal.energy,
            type: 'scatter',
            mode: 'lines',
            fill: 'tozerox',
            fillcolor: 'rgba(0,0,0,0.1)',
            line: { color: '#000000', width: 3 },
            name: 'DOS Total',
            hovertemplate: 'DOS: %{x:.3f}<br>E: %{y:.3f} eV<extra></extra>'
        });
    }
    
    // 2. PDOS par atome (couleurs différentes)
    const couleurs = [
        '#ef4444', // Rouge
        '#3b82f6', // Bleu
        '#10b981', // Vert
        '#f59e0b', // Orange
        '#8b5cf6', // Violet
        '#ec4899', // Rose
        '#06b6d4', // Cyan
        '#84cc16', // Lime
    ];
    
    const parAtome = organiserPDOSParAtome(pdosData);
    let colorIndex = 0;
    
    for (const [key, atome] of Object.entries(parAtome)) {
        const couleur = couleurs[colorIndex % couleurs.length];
        colorIndex++;
        
        // Sommer toutes les orbitales de cet atome
        const energy = atome.orbitales[0].energy;
        const pdosTotal = new Array(energy.length).fill(0);
        
        for (const orb of atome.orbitales) {
            for (let i = 0; i < orb.pdos.length; i++) {
                pdosTotal[i] += orb.pdos[i];
            }
        }
        
        traces.push({
            x: pdosTotal,
            y: energy,
            type: 'scatter',
            mode: 'lines',
            line: { color: couleur, width: 2 },
            name: `${atome.symbol} #${atome.num}`,
            hovertemplate: `${atome.symbol}: %{x:.3f}<br>E: %{y:.3f} eV<extra></extra>`
        });
        
        // Ajouter les orbitales individuelles (lignes pointillées)
        for (const orb of atome.orbitales) {
            traces.push({
                x: orb.pdos,
                y: orb.energy,
                type: 'scatter',
                mode: 'lines',
                line: { color: couleur, width: 1, dash: 'dot' },
                name: `${atome.symbol} (${orb.orbitalType})`,
                visible: 'legendonly', // Caché par défaut, visible en cliquant sur la légende
                hovertemplate: `${orb.label}: %{x:.3f}<br>E: %{y:.3f} eV<extra></extra>`
            });
        }
    }
    
    // 3. Ligne de Fermi
    if (fermi !== 0) {
        const maxDOS = Math.max(...dosTotal.dos);
        traces.push({
            x: [0, maxDOS * 1.1],
            y: [fermi, fermi],
            type: 'scatter',
            mode: 'lines',
            line: { color: '#ef4444', width: 2, dash: 'dash' },
            name: 'E<sub>Fermi</sub>',
            hovertemplate: 'Fermi: %{y:.3f} eV<extra></extra>'
        });
    }
    
    const layout = {
        title: {
            text: 'Densité d\'États (Total + Projetée)',
            font: { size: 18, color: '#1f2937' }
        },
        xaxis: {
            title: 'DOS (états/eV)',
            showgrid: true,
            gridcolor: '#e5e7eb'
        },
        yaxis: {
            title: 'Énergie (eV)',
            showgrid: true,
            gridcolor: '#e5e7eb',
            zeroline: true,
            zerolinecolor: '#9ca3af',
            zerolinewidth: 2,
            range: [emin, emax]
        },
        hovermode: 'closest',
        margin: { l: 60, r: 30, t: 50, b: 50 },
        plot_bgcolor: '#ffffff',
        paper_bgcolor: '#ffffff',
        legend: {
            x: 1.05,
            y: 1,
            xanchor: 'left',
            yanchor: 'top',
            bgcolor: 'rgba(255,255,255,0.9)',
            bordercolor: '#e5e7eb',
            borderwidth: 1
        }
    };
    
    const config = {
        responsive: true,
        displayModeBar: true,
        modeBarButtonsToRemove: ['lasso2d', 'select2d'],
        displaylogo: false
    };
    
    Plotly.newPlot(divId, traces, layout, config);
}

/**
 * Charge et affiche le DOS avec PDOS
 */
async function chargerEtAfficherPDOS(materiau, divId, fermi = 0, emin = -10, emax = 10) {
    try {
        // 1. Charger le DOS total
        const dosPath = `/home/hiadsi/Interface-QE_v1/outputs/${materiau}/dos.dat`;
        const dosData = await window.postJSON('http://localhost:5007/api/lire_fichier', { 
            filepath: dosPath 
        });
        
        if (!dosData.success) {
            console.warn('DOS total non trouvé');
            return false;
        }
        
        const dosTotal = parserDosDat(dosData.contenu);
        
        // 2. Lister et charger les fichiers PDOS
        const fichiersPDOS = await listerFichiersPDOS(materiau);
        
        if (fichiersPDOS.length === 0) {
            console.warn('Aucun fichier PDOS trouvé, affichage du DOS total uniquement');
            // Afficher seulement le DOS total
            tracerDOS(dosTotal, divId, fermi, emin, emax);
            return true;
        }
        
        console.log(`${fichiersPDOS.length} fichiers PDOS trouvés`);
        
        // 3. Parser tous les fichiers PDOS
        const pdosPromises = fichiersPDOS.map(f => parserFichierPDOS(materiau, f));
        const pdosData = await Promise.all(pdosPromises);
        
        // Filtrer les null
        const pdosValides = pdosData.filter(p => p !== null);
        
        // 4. Tracer DOS + PDOS
        tracerDOSAvecPDOS(dosTotal, pdosValides, divId, fermi, emin, emax);
        
        return true;
    } catch (e) {
        console.error('Erreur chargement PDOS:', e);
        return false;
    }
}

/**
 * Affiche un panneau d'information sur le PDOS
 */
function afficherInfoPDOS(pdosData) {
    const parAtome = organiserPDOSParAtome(pdosData);
    
    let html = '<div style="background: #f0f9ff; padding: 15px; border-radius: 8px; margin-top: 15px;">';
    html += '<h4 style="margin: 0 0 10px 0; color: #1e40af;">🔬 DOS Projetée Disponible</h4>';
    html += '<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px;">';
    
    for (const [key, atome] of Object.entries(parAtome)) {
        const orbitales = atome.orbitales.map(o => o.orbitalType).join(', ');
        html += `
            <div style="background: white; padding: 10px; border-radius: 6px; border-left: 3px solid #3b82f6;">
                <strong>${atome.symbol} #${atome.num}</strong><br>
                <span style="font-size: 0.85em; color: #64748b;">Orbitales: ${orbitales}</span>
            </div>
        `;
    }
    
    html += '</div>';
    html += '<p style="margin: 10px 0 0 0; font-size: 0.85em; color: #64748b;">';
    html += '💡 Cliquez sur les éléments de la légende pour afficher/masquer les orbitales individuelles';
    html += '</p>';
    html += '</div>';
    
    return html;
}

console.log('✅ Module PDOS chargé');

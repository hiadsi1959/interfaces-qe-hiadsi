// ═══════════════════════════════════════════════════════════════════════════
// SCRIPT DE TESTS COMPLETS - ONGLET 1 GÉNÉRATION D'INPUTS
// Version: 1.0
// Date: 2026-01-01
// ═══════════════════════════════════════════════════════════════════════════

console.log('✅ script_tests_onglet1.js chargé');

// ═══════════════════════════════════════════════════════════════════════════
// TEST 1: Vérifier que tous les champs existent
// ═══════════════════════════════════════════════════════════════════════════

function test1_verifierChamps() {
    console.log('\n🧪 TEST 1: Vérification des champs HTML\n');
    
    const champs = [
        'materiau_name',
        'prefix_name',
        'ibrav',
        'groupe_espace_select',
        'ntyp',
        'nat',
        'ecutwfc',
        'ecutrho',
        'functional',
        'kpoints'
    ];
    
    let tousPresents = true;
    
    champs.forEach(id => {
        const elem = document.getElementById(id);
        if (elem) {
            console.log(`  ✓ ${id} existe`);
        } else {
            console.error(`  ❌ ${id} MANQUANT!`);
            tousPresents = false;
        }
    });
    
    return tousPresents;
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 2: Remplir les champs de base
// ═══════════════════════════════════════════════════════════════════════════

function test2_remplirBase() {
    console.log('\n🧪 TEST 2: Remplissage des champs de base\n');
    
    document.getElementById('materiau_name').value = 'BaTiO3';
    console.log('  ✓ materiau_name = BaTiO3');
    
    document.getElementById('prefix_name').value = 'BaTiO3_scf';
    console.log('  ✓ prefix_name = BaTiO3_scf');
    
    document.getElementById('ibrav').value = '2';
    document.getElementById('ibrav').dispatchEvent(new Event('change'));
    console.log('  ✓ ibrav = 2 (BCC)');
    
    return true;
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 3: Vérifier les groupes d'espace
// ═══════════════════════════════════════════════════════════════════════════

function test3_verifierGroupesEspace() {
    console.log('\n🧪 TEST 3: Vérification des groupes d\'espace\n');
    
    const select = document.getElementById('groupe_espace_select');
    if (!select) {
        console.error('  ❌ groupe_espace_select MANQUANT!');
        return false;
    }
    
    const options = select.options;
    console.log(`  Nombre d'options: ${options.length}`);
    
    if (options.length < 2) {
        console.error('  ❌ Pas de groupes d\'espace!');
        return false;
    }
    
    console.log('  ✓ Groupes d\'espace présents');
    
    // Afficher quelques exemples
    console.log('  Exemples:');
    for (let i = 1; i < Math.min(5, options.length); i++) {
        console.log(`    - ${options[i].text}`);
    }
    
    return true;
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 4: Remplir ntyp et nat
// ═══════════════════════════════════════════════════════════════════════════

function test4_remplirEspeces() {
    console.log('\n🧪 TEST 4: Remplissage ntyp et nat\n');
    
    document.getElementById('ntyp').value = '3';
    document.getElementById('ntyp').dispatchEvent(new Event('change'));
    console.log('  ✓ ntyp = 3');
    
    // Attendre que les champs element_${i} se créent
    setTimeout(() => {
        console.log('  Vérification des champs element_${i}:');
        for (let i = 1; i <= 3; i++) {
            const elem = document.getElementById(`element_${i}`);
            if (elem) {
                console.log(`  ✓ element_${i} créé`);
            } else {
                console.error(`  ❌ element_${i} MANQUANT!`);
            }
        }
    }, 300);
    
    document.getElementById('nat').value = '5';
    document.getElementById('nat').dispatchEvent(new Event('change'));
    console.log('  ✓ nat = 5');
    
    return true;
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 5: Remplir les éléments
// ═══════════════════════════════════════════════════════════════════════════

function test5_remplirElements() {
    console.log('\n🧪 TEST 5: Remplissage des éléments\n');
    
    const elements = ['Ba', 'Ti', 'O'];
    
    for (let i = 0; i < elements.length; i++) {
        const elem = document.getElementById(`element_${i + 1}`);
        if (elem) {
            elem.value = elements[i];
            elem.dispatchEvent(new Event('input'));
            console.log(`  ✓ element_${i + 1} = ${elements[i]}`);
        } else {
            console.error(`  ❌ element_${i + 1} MANQUANT!`);
        }
    }
    
    return true;
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 6: Vérifier ATOMIC_SPECIES
// ═══════════════════════════════════════════════════════════════════════════

function test6_verifierAtomicSpecies() {
    console.log('\n🧪 TEST 6: Vérification ATOMIC_SPECIES\n');
    
    if (window.atomicSpeciesGlobal && window.atomicSpeciesGlobal.length > 0) {
        console.log('  ✅ ATOMIC_SPECIES REMPLI:');
        console.log('─'.repeat(50));
        console.log(window.atomicSpeciesGlobal);
        console.log('─'.repeat(50));
        return true;
    } else {
        console.error('  ❌ ATOMIC_SPECIES VIDE!');
        console.log('  window.atomicSpeciesGlobal =', window.atomicSpeciesGlobal);
        return false;
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 7: Générer les positions
// ═══════════════════════════════════════════════════════════════════════════

function test7_genererPositions() {
    console.log('\n🧪 TEST 7: Génération des positions\n');
    
    if (typeof genererPositionsAuto === 'function') {
        genererPositionsAuto();
        console.log('  ✓ genererPositionsAuto() exécutée');
        return true;
    } else {
        console.error('  ❌ genererPositionsAuto() NOT FOUND');
        return false;
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 8: Vérifier ATOMIC_POSITIONS
// ═══════════════════════════════════════════════════════════════════════════

function test8_verifierAtomicPositions() {
    console.log('\n🧪 TEST 8: Vérification ATOMIC_POSITIONS\n');
    
    if (window.atomicPositionsContent && window.atomicPositionsContent.length > 0) {
        console.log('  ✅ ATOMIC_POSITIONS REMPLI:');
        console.log('─'.repeat(50));
        console.log(window.atomicPositionsContent);
        console.log('─'.repeat(50));
        
        // Vérifier que les symboles atomiques sont présents (pas Atom_1, Atom_2)
        if (window.atomicPositionsContent.includes('Ba') || 
            window.atomicPositionsContent.includes('Ti') || 
            window.atomicPositionsContent.includes('O')) {
            console.log('  ✓ Symboles atomiques présents (Ba, Ti, O)');
        } else {
            console.error('  ❌ Symboles atomiques MANQUANTS (Atom_1, Atom_2...)');
        }
        
        // Vérifier que les positions ne sont pas 0.0000
        if (window.atomicPositionsContent.includes('0.500000') || 
            window.atomicPositionsContent.includes('0.250000')) {
            console.log('  ✓ Positions non nulles');
        } else {
            console.error('  ❌ Toutes les positions sont 0.0000!');
        }
        
        return true;
    } else {
        console.error('  ❌ ATOMIC_POSITIONS VIDE!');
        console.log('  window.atomicPositionsContent =', window.atomicPositionsContent);
        return false;
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 9: Générer l'input
// ═══════════════════════════════════════════════════════════════════════════

function test9_genererInput() {
    console.log('\n🧪 TEST 9: Génération de l\'input\n');
    
    if (typeof genererInputAvecPreparation === 'function') {
        genererInputAvecPreparation();
        console.log('  ✓ genererInputAvecPreparation() exécutée');
        return true;
    } else if (typeof preparerAvantGeneration === 'function') {
        preparerAvantGeneration();
        console.log('  ✓ preparerAvantGeneration() exécutée');
        return true;
    } else if (typeof genererInputComplet === 'function') {
        genererInputComplet();
        console.log('  ✓ genererInputComplet() exécutée');
        return true;
    } else {
        console.error('  ❌ Fonction de génération NOT FOUND');
        return false;
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 10: Vérifier l'input final
// ═══════════════════════════════════════════════════════════════════════════

function test10_verifierInputFinal() {
    console.log('\n🧪 TEST 10: Vérification de l\'input final\n');
    
    if (window.currentInputContent && window.currentInputContent.length > 0) {
        console.log('  ✅ INPUT GÉNÉRÉ (' + window.currentInputContent.length + ' caractères)');
        
        // Vérifier que ATOMIC_SPECIES est présent
        if (window.currentInputContent.includes('ATOMIC_SPECIES')) {
            console.log('  ✓ ATOMIC_SPECIES présent dans l\'input');
            
            // Vérifier les éléments
            if (window.currentInputContent.includes('Ba ') && 
                window.currentInputContent.includes('Ti ') && 
                window.currentInputContent.includes('O ')) {
                console.log('  ✓ Éléments Ba, Ti, O présents');
            } else {
                console.error('  ❌ Éléments MANQUANTS dans ATOMIC_SPECIES');
            }
        } else {
            console.error('  ❌ ATOMIC_SPECIES MANQUANT dans l\'input!');
        }
        
        // Vérifier que ATOMIC_POSITIONS est présent
        if (window.currentInputContent.includes('ATOMIC_POSITIONS')) {
            console.log('  ✓ ATOMIC_POSITIONS présent dans l\'input');
            
            // Vérifier le nombre de positions
            const lines = window.currentInputContent.split('\n');
            let positionsCount = 0;
            let inPositions = false;
            for (const line of lines) {
                if (line.includes('ATOMIC_POSITIONS')) {
                    inPositions = true;
                    continue;
                }
                if (inPositions) {
                    if (line.trim() === '' || line.includes('K_POINTS')) {
                        break;
                    }
                    positionsCount++;
                }
            }
            console.log(`  ✓ ${positionsCount} positions atomiques trouvées (attendu: 5)`);
            
            if (positionsCount !== 5) {
                console.error(`  ❌ Nombre de positions incorrect! (${positionsCount} au lieu de 5)`);
            }
        } else {
            console.error('  ❌ ATOMIC_POSITIONS MANQUANT dans l\'input!');
        }
        
        // Afficher un extrait de l'input
        console.log('\n  📄 Extrait de l\'input généré:');
        console.log('─'.repeat(50));
        const lines = window.currentInputContent.split('\n');
        console.log(lines.slice(0, 20).join('\n'));
        console.log('  ...');
        console.log('─'.repeat(50));
        
        return true;
    } else {
        console.error('  ❌ INPUT VIDE!');
        console.log('  window.currentInputContent =', window.currentInputContent);
        return false;
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// EXÉCUTION DE TOUS LES TESTS
// ═══════════════════════════════════════════════════════════════════════════

function executerTousLesTests() {
    console.log('\n═══════════════════════════════════════════════════════════════');
    console.log('🧪 EXÉCUTION DE TOUS LES TESTS - ONGLET 1');
    console.log('═══════════════════════════════════════════════════════════════\n');
    
    test1_verifierChamps();
    
    setTimeout(() => test2_remplirBase(), 500);
    setTimeout(() => test3_verifierGroupesEspace(), 1000);
    setTimeout(() => test4_remplirEspeces(), 1500);
    setTimeout(() => test5_remplirElements(), 2000);
    setTimeout(() => test6_verifierAtomicSpecies(), 2500);
    setTimeout(() => test7_genererPositions(), 3000);
    setTimeout(() => test8_verifierAtomicPositions(), 3500);
    setTimeout(() => test9_genererInput(), 4000);
    setTimeout(() => test10_verifierInputFinal(), 4500);
    
    setTimeout(() => {
        console.log('\n═══════════════════════════════════════════════════════════════');
        console.log('🎉 TOUS LES TESTS TERMINÉS');
        console.log('═══════════════════════════════════════════════════════════════\n');
    }, 5000);
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST RAPIDE (2 SECONDES)
// ═══════════════════════════════════════════════════════════════════════════

function testRapide() {
    console.log('\n🚀 TEST RAPIDE (2 secondes)\n');
    
    // Remplir tous les champs d'un coup
    document.getElementById('materiau_name').value = 'BaTiO3';
    document.getElementById('prefix_name').value = 'BaTiO3_scf';
    document.getElementById('ibrav').value = '2';
    document.getElementById('ibrav').dispatchEvent(new Event('change'));
    document.getElementById('ntyp').value = '3';
    document.getElementById('ntyp').dispatchEvent(new Event('change'));
    document.getElementById('nat').value = '5';
    document.getElementById('nat').dispatchEvent(new Event('change'));
    
    setTimeout(() => {
        document.getElementById('element_1').value = 'Ba';
        document.getElementById('element_2').value = 'Ti';
        document.getElementById('element_3').value = 'O';
        document.getElementById('element_1').dispatchEvent(new Event('input'));
        document.getElementById('element_2').dispatchEvent(new Event('input'));
        document.getElementById('element_3').dispatchEvent(new Event('input'));
        
        console.log('✓ Champs remplis');
    }, 500);
    
    setTimeout(() => {
        if (typeof genererPositionsAuto === 'function') {
            genererPositionsAuto();
            console.log('✓ Positions générées');
        }
    }, 1000);
    
    setTimeout(() => {
        if (typeof genererInputAvecPreparation === 'function') {
            genererInputAvecPreparation();
            console.log('✓ Input généré');
        } else if (typeof preparerAvantGeneration === 'function') {
            preparerAvantGeneration();
            console.log('✓ Input généré');
        }
        
        console.log('\n✅ TEST RAPIDE TERMINÉ - Vérifiez l\'aperçu!');
    }, 1500);
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORT DES FONCTIONS
// ═══════════════════════════════════════════════════════════════════════════

console.log('📋 Fonctions de test disponibles:');
console.log('  - executerTousLesTests()  : Test complet (5 secondes)');
console.log('  - testRapide()            : Test rapide (2 secondes)');
console.log('  - test1_verifierChamps()  : Vérifier les champs HTML');
console.log('  - test2_remplirBase()     : Remplir materiau, prefix, ibrav');
console.log('  - test3_verifierGroupesEspace() : Vérifier les 230 groupes');
console.log('  - test4_remplirEspeces()  : Remplir ntyp et nat');
console.log('  - test5_remplirElements() : Remplir Ba, Ti, O');
console.log('  - test6_verifierAtomicSpecies() : Vérifier ATOMIC_SPECIES');
console.log('  - test7_genererPositions() : Générer positions auto');
console.log('  - test8_verifierAtomicPositions() : Vérifier ATOMIC_POSITIONS');
console.log('  - test9_genererInput()    : Générer l\'input complet');
console.log('  - test10_verifierInputFinal() : Vérifier l\'input final');


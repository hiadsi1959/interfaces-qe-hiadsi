/**
 * Pont éditeurs phonons — conservé après déduplication des blocs inline.
 */
(function () {
    'use strict';
    if (typeof window.ouvrirEditeurInputPhonon === 'function') return;
    window.ouvrirEditeurInputPhonon = function (type) {
        switch (String(type || '').toLowerCase()) {
            case 'ph':
                if (typeof window.ouvrirEditeurPhononsPH === 'function') return window.ouvrirEditeurPhononsPH();
                break;
            case 'q2r':
                if (typeof window.ouvrirEditeurPhononsQ2R === 'function') return window.ouvrirEditeurPhononsQ2R();
                break;
            case 'matdyn':
                if (typeof window.ouvrirEditeurPhononsMatdyn === 'function') return window.ouvrirEditeurPhononsMatdyn();
                break;
            default:
                break;
        }
        console.warn('ouvrirEditeurInputPhonon: éditeur indisponible pour', type);
    };
})();

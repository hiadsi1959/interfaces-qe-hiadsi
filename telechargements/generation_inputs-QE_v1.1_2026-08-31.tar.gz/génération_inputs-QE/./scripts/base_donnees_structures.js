// ═══════════════════════════════════════════════════════════════════════════
// BASE DE DONNÉES COMPLÈTE DES STRUCTURES CRISTALLINES
// Pour génération automatique de nat et positions atomiques
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Base de données exhaustive des types de matériaux
 * 
 * Structure:
 * {
 *   id: 'identifiant_unique',
 *   nom: 'Nom affiché',
 *   description: 'Description détaillée',
 *   formule: 'Formule générique (AB, ABX3, etc.)',
 *   ntyp: [valeurs possibles],
 *   nat: function(ntyp) { return nat_calculé },
 *   ibrav: [valeurs compatibles],
 *   positions: function(ntyp, nat) { return positions },
 *   exemples: ['Matériau1', 'Matériau2', ...]
 * }
 */

const BASE_STRUCTURES = {
    // ═══════════════════════════════════════════════════════════════════════
    // BINAIRES (AB)
    // ═══════════════════════════════════════════════════════════════════════
    'binaire_rocksalt': {
        id: 'binaire_rocksalt',
        nom: 'Binaire - Rocksalt (NaCl)',
        description: 'Structure FCC avec 2 sous-réseaux interpénétrés',
        formule: 'AB',
        ntyp: [2],
        nat: () => 8,
        ibrav: [1, 2, 3],
        positions: (ntyp, nat) => [
            [0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5],
            [0.5, 0, 0], [0, 0.5, 0], [0, 0, 0.5], [0.5, 0.5, 0.5]
        ],
        exemples: ['NaCl', 'MgO', 'TiN', 'ScN', 'LiF']
    },
    
    'binaire_zincblende': {
        id: 'binaire_zincblende',
        nom: 'Binaire - Zinc Blende (GaAs)',
        description: 'Structure FCC tétraédrique',
        formule: 'AB',
        ntyp: [2],
        nat: () => 2,
        ibrav: [2],
        positions: (ntyp, nat) => [
            [0, 0, 0],
            [0.25, 0.25, 0.25]
        ],
        exemples: ['GaAs', 'ZnS', 'CdTe', 'SiC', 'InP']
    },
    
    'binaire_wurtzite': {
        id: 'binaire_wurtzite',
        nom: 'Binaire - Wurtzite (ZnO)',
        description: 'Structure hexagonale',
        formule: 'AB',
        ntyp: [2],
        nat: () => 4,
        ibrav: [4],
        positions: (ntyp, nat) => [
            [0, 0, 0],
            [1/3, 2/3, 0.5],
            [0, 0, 0.375],
            [1/3, 2/3, 0.875]
        ],
        exemples: ['ZnO', 'GaN', 'AlN', 'InN', 'CdS']
    },
    
    'binaire_cscl': {
        id: 'binaire_cscl',
        nom: 'Binaire - CsCl',
        description: 'Structure cubique simple BCC',
        formule: 'AB',
        ntyp: [2],
        nat: () => 2,
        ibrav: [1, 3],
        positions: (ntyp, nat) => [
            [0, 0, 0],
            [0.5, 0.5, 0.5]
        ],
        exemples: ['CsCl', 'CuZn', 'AgMg', 'BeCu']
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // TERNAIRES (ABX, ABX2, ABX3)
    // ═══════════════════════════════════════════════════════════════════════
    'perovskite_abx3': {
        id: 'perovskite_abx3',
        nom: 'Pérovskite - ABX3',
        description: 'Structure pérovskite cubique/orthorhombique',
        formule: 'ABX3',
        ntyp: [3],
        nat: () => 5,
        ibrav: [1, 2, 3, 221, 8, 9, 10, 11],
        positions: (ntyp, nat) => [
            [0, 0, 0],           // A
            [0.5, 0.5, 0.5],     // B
            [0.5, 0.5, 0],       // X
            [0.5, 0, 0.5],       // X
            [0, 0.5, 0.5]        // X
        ],
        exemples: ['BaTiO3', 'SrTiO3', 'CaTiO3', 'LaAlO3', 'GdAlO3', 'BiFeO3']
    },
    
    'antiperovskite_abx3': {
        id: 'antiperovskite_abx3',
        nom: 'Anti-Pérovskite - ABX3',
        description: 'Structure anti-pérovskite (anions et cations inversés)',
        formule: 'ABX3',
        ntyp: [3],
        nat: () => 5,
        ibrav: [1, 2, 3],
        positions: (ntyp, nat) => [
            [0, 0, 0],           // X (anion au centre)
            [0.5, 0.5, 0.5],     // A (cation aux coins)
            [0.5, 0.5, 0],       // B
            [0.5, 0, 0.5],       // B
            [0, 0.5, 0.5]        // B
        ],
        exemples: ['Mg3NiN', 'Mn3GaC', 'Fe3GaN', 'Ni3SnN']
    },
    
    'chalcopyrite_abx2': {
        id: 'chalcopyrite_abx2',
        nom: 'Chalcopyrite - ABX2',
        description: 'Structure tétragonale I-42d',
        formule: 'ABX2',
        ntyp: [3],
        nat: () => 8,
        ibrav: [6, 7],
        positions: (ntyp, nat) => [
            [0, 0, 0],              // A
            [0, 0.5, 0.25],         // A
            [0.5, 0, 0.25],         // B
            [0.5, 0.5, 0.5],        // B
            [0.25, 0.25, 0.125],    // X
            [0.75, 0.25, 0.375],    // X
            [0.25, 0.75, 0.625],    // X
            [0.75, 0.75, 0.875]     // X
        ],
        exemples: ['CuInSe2', 'CuGaSe2', 'AgGaSe2', 'ZnSiP2', 'CuInS2']
    },
    
    'delafossite_abx2': {
        id: 'delafossite_abx2',
        nom: 'Delafossite - ABX2',
        description: 'Structure hexagonale/rhomboédrique',
        formule: 'ABX2',
        ntyp: [3],
        nat: () => 4,
        ibrav: [4, 5],
        positions: (ntyp, nat) => [
            [0, 0, 0],       // A
            [0, 0, 0.5],     // B
            [1/3, 2/3, 0.25],  // X
            [2/3, 1/3, 0.75]   // X
        ],
        exemples: ['CuAlO2', 'CuGaO2', 'PdCoO2', 'PtCoO2', 'AgGaO2']
    },
    
    'heusler_full': {
        id: 'heusler_full',
        nom: 'Full-Heusler - X2YZ',
        description: 'Structure cubique L21',
        formule: 'X2YZ',
        ntyp: [3],
        nat: () => 4,
        ibrav: [1, 2],
        positions: (ntyp, nat) => [
            [0, 0, 0],       // X
            [0.25, 0.25, 0.25],  // X
            [0.5, 0.5, 0.5],     // Y
            [0.75, 0.75, 0.75]   // Z
        ],
        exemples: ['Co2MnSi', 'Co2FeSi', 'Cu2MnAl', 'Ni2MnGa', 'Fe2VAl']
    },
    
    'heusler_half': {
        id: 'heusler_half',
        nom: 'Half-Heusler - XYZ',
        description: 'Structure cubique C1b (demi-Heusler)',
        formule: 'XYZ',
        ntyp: [3],
        nat: () => 3,
        ibrav: [1, 2],
        positions: (ntyp, nat) => [
            [0, 0, 0],       // X
            [0.25, 0.25, 0.25],  // Y
            [0.5, 0.5, 0.5]      // Z
        ],
        exemples: ['TiNiSn', 'ZrNiSn', 'HfNiSn', 'CoTiSb', 'NiMnSb']
    },
    
    'spinelle_ab2x4': {
        id: 'spinelle_ab2x4',
        nom: 'Spinelle - AB2X4',
        description: 'Structure cubique spinelle',
        formule: 'AB2X4',
        ntyp: [3],
        nat: () => 14,
        ibrav: [1, 2],
        positions: (ntyp, nat) => [
            // A (2 atomes)
            [0, 0, 0],
            [0.5, 0.5, 0.5],
            // B (4 atomes)
            [0.125, 0.125, 0.125],
            [0.375, 0.375, 0.125],
            [0.375, 0.125, 0.375],
            [0.125, 0.375, 0.375],
            // X (8 atomes)
            [0.25, 0.25, 0.25],
            [0.75, 0.25, 0.25],
            [0.25, 0.75, 0.25],
            [0.25, 0.25, 0.75],
            [0.75, 0.75, 0.25],
            [0.75, 0.25, 0.75],
            [0.25, 0.75, 0.75],
            [0.75, 0.75, 0.75]
        ],
        exemples: ['MgAl2O4', 'ZnFe2O4', 'CoFe2O4', 'NiFe2O4', 'MnFe2O4']
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // QUATERNAIRES
    // ═══════════════════════════════════════════════════════════════════════
    'double_perovskite': {
        id: 'double_perovskite',
        nom: 'Double Pérovskite - A2BB\'X6',
        description: 'Pérovskite double avec 2 cations B différents',
        formule: 'A2BB\'X6',
        ntyp: [4],
        nat: () => 10,
        ibrav: [1, 2],
        positions: (ntyp, nat) => [
            // A (2 atomes)
            [0, 0, 0],
            [0.5, 0.5, 0],
            // B (1 atome)
            [0.25, 0.25, 0.25],
            // B' (1 atome)
            [0.75, 0.75, 0.75],
            // X (6 atomes)
            [0.25, 0, 0],
            [0.75, 0, 0],
            [0, 0.25, 0],
            [0, 0.75, 0],
            [0, 0, 0.25],
            [0, 0, 0.75]
        ],
        exemples: ['Sr2FeMoO6', 'Ba2FeMoO6', 'La2NiMnO6', 'Sr2CoMoO6']
    },
    
    'quaternaire_kesterite': {
        id: 'quaternaire_kesterite',
        nom: 'Kesterite - A2BCX4',
        description: 'Structure tétragonale I-4',
        formule: 'A2BCX4',
        ntyp: [4],
        nat: () => 16,
        ibrav: [6, 7],
        positions: (ntyp, nat) => [
            // A (4 atomes)
            [0, 0, 0],
            [0.5, 0.5, 0],
            [0, 0.5, 0.25],
            [0.5, 0, 0.25],
            // B (2 atomes)
            [0, 0, 0.5],
            [0.5, 0.5, 0.5],
            // C (2 atomes)
            [0, 0.5, 0.75],
            [0.5, 0, 0.75],
            // X (8 atomes)
            [0.25, 0.25, 0.125],
            [0.75, 0.75, 0.125],
            [0.25, 0.75, 0.375],
            [0.75, 0.25, 0.375],
            [0.25, 0.25, 0.625],
            [0.75, 0.75, 0.625],
            [0.25, 0.75, 0.875],
            [0.75, 0.25, 0.875]
        ],
        exemples: ['Cu2ZnSnSe4', 'Cu2ZnSnS4', 'Cu2ZnGeS4']
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // STRUCTURES COMPLEXES
    // ═══════════════════════════════════════════════════════════════════════
    'ybco': {
        id: 'ybco',
        nom: 'YBCO - YBa2Cu3O7',
        description: 'Supraconducteur haute température orthorhombique',
        formule: 'YBa2Cu3O7',
        ntyp: [4],
        nat: () => 13,
        ibrav: [8, 9, 10, 11],
        positions: (ntyp, nat) => [
            // Y (1 atome)
            [0, 0, 0.5],
            // Ba (2 atomes)
            [0, 0, 0.184],
            [0, 0, 0.816],
            // Cu (3 atomes)
            [0, 0, 0],
            [0, 0.5, 0.356],
            [0.5, 0, 0.356],
            // O (7 atomes)
            [0, 0.5, 0],
            [0.5, 0, 0],
            [0, 0, 0.158],
            [0, 0, 0.842],
            [0, 0.5, 0.377],
            [0.5, 0, 0.377],
            [0, 0.5, 0.377]
        ],
        exemples: ['YBa2Cu3O7', 'YBa2Cu3O6']
    },
    
    'pyrochlore': {
        id: 'pyrochlore',
        nom: 'Pyrochlore - A2B2O7',
        description: 'Structure cubique A2B2O7',
        formule: 'A2B2O7',
        ntyp: [3],
        nat: () => 22,
        ibrav: [1, 2],
        positions: (ntyp, nat) => {
            // Positions simplifiées (à compléter selon besoin)
            const pos = [];
            for (let i = 0; i < 22; i++) {
                pos.push([i * 0.045, i * 0.045, i * 0.045]); // Placeholder
            }
            return pos;
        },
        exemples: ['Y2Ti2O7', 'Gd2Ti2O7', 'Dy2Ti2O7']
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // STRUCTURES ÉLÉMENTAIRES
    // ═══════════════════════════════════════════════════════════════════════
    'fcc': {
        id: 'fcc',
        nom: 'FCC - Cubique Faces Centrées',
        description: 'Structure cubique à faces centrées (Cu, Al, Ni)',
        formule: 'A',
        ntyp: [1],
        nat: () => 1,
        ibrav: [2],
        positions: (ntyp, nat) => [[0, 0, 0]],
        exemples: ['Cu', 'Al', 'Ni', 'Ag', 'Au', 'Pt', 'Pb']
    },
    
    'bcc': {
        id: 'bcc',
        nom: 'BCC - Cubique Centré',
        description: 'Structure cubique centrée (Fe, Cr, W)',
        formule: 'A',
        ntyp: [1],
        nat: () => 1,
        ibrav: [3],
        positions: (ntyp, nat) => [[0, 0, 0]],
        exemples: ['Fe', 'Cr', 'W', 'Mo', 'V', 'Nb', 'Ta']
    },
    
    'hcp': {
        id: 'hcp',
        nom: 'HCP - Hexagonal Compact',
        description: 'Structure hexagonale compacte (Mg, Zn, Ti)',
        formule: 'A',
        ntyp: [1],
        nat: () => 2,
        ibrav: [4],
        positions: (ntyp, nat) => [
            [0, 0, 0],
            [1/3, 2/3, 0.5]
        ],
        exemples: ['Mg', 'Zn', 'Ti', 'Zr', 'Co', 'Cd']
    },
    
    'diamond': {
        id: 'diamond',
        nom: 'Diamant (Diamond)',
        description: 'Structure diamant (Si, Ge, C)',
        formule: 'A',
        ntyp: [1],
        nat: () => 2,
        ibrav: [2],
        positions: (ntyp, nat) => [
            [0, 0, 0],
            [0.25, 0.25, 0.25]
        ],
        exemples: ['C', 'Si', 'Ge']
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // OXYDES ET NITRURES
    // ═══════════════════════════════════════════════════════════════════════
    'rutile': {
        id: 'rutile',
        nom: 'Rutile - TiO2',
        description: 'Structure tétragonale rutile',
        formule: 'AX2',
        ntyp: [2],
        nat: () => 6,
        ibrav: [6, 7],
        positions: (ntyp, nat) => [
            [0, 0, 0],          // Ti
            [0.5, 0.5, 0.5],    // Ti
            [0.305, 0.305, 0],  // O
            [0.695, 0.695, 0],  // O
            [0.195, 0.805, 0.5], // O
            [0.805, 0.195, 0.5]  // O
        ],
        exemples: ['TiO2', 'SnO2', 'RuO2', 'CrO2']
    },
    
    'corundum': {
        id: 'corundum',
        nom: 'Corundum - Al2O3',
        description: 'Structure rhomboédrique corundum',
        formule: 'A2X3',
        ntyp: [2],
        nat: () => 10,
        ibrav: [5],
        positions: (ntyp, nat) => [
            // Al (4 atomes)
            [0, 0, 0.352],
            [0, 0, 0.648],
            [0.667, 0.333, 0.019],
            [0.333, 0.667, 0.981],
            // O (6 atomes)
            [0.306, 0, 0.25],
            [0.694, 0, 0.75],
            [0, 0.306, 0.25],
            [0, 0.694, 0.75],
            [0.361, 0.361, 0.25],
            [0.639, 0.639, 0.75]
        ],
        exemples: ['Al2O3', 'Cr2O3', 'Fe2O3', 'V2O3']
    },
    
    'fluorite': {
        id: 'fluorite',
        nom: 'Fluorite - CaF2',
        description: 'Structure cubique fluorite',
        formule: 'AX2',
        ntyp: [2],
        nat: () => 3,
        ibrav: [1, 2],
        positions: (ntyp, nat) => [
            [0, 0, 0],          // Ca
            [0.25, 0.25, 0.25], // F
            [0.75, 0.75, 0.75]  // F
        ],
        exemples: ['CaF2', 'UO2', 'ThO2', 'CeO2']
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // SEMICONDUCTEURS III-V ET II-VI
    // ═══════════════════════════════════════════════════════════════════════
    'binaire_iii_v_cubic': {
        id: 'binaire_iii_v_cubic',
        nom: 'III-V Cubique (GaAs, InP)',
        description: 'Semiconducteurs III-V structure zinc blende',
        formule: 'AB',
        ntyp: [2],
        nat: () => 2,
        ibrav: [2],
        positions: (ntyp, nat) => [
            [0, 0, 0],
            [0.25, 0.25, 0.25]
        ],
        exemples: ['GaAs', 'InP', 'GaSb', 'InAs', 'InSb', 'AlAs']
    },
    
    'binaire_iii_v_hex': {
        id: 'binaire_iii_v_hex',
        nom: 'III-V Hexagonal (GaN, AlN)',
        description: 'Semiconducteurs III-V structure wurtzite',
        formule: 'AB',
        ntyp: [2],
        nat: () => 4,
        ibrav: [4],
        positions: (ntyp, nat) => [
            [0, 0, 0],
            [1/3, 2/3, 0.5],
            [0, 0, 0.375],
            [1/3, 2/3, 0.875]
        ],
        exemples: ['GaN', 'AlN', 'InN']
    },
    
    'binaire_ii_vi': {
        id: 'binaire_ii_vi',
        nom: 'II-VI (ZnO, CdS)',
        description: 'Semiconducteurs II-VI structure wurtzite/zinc blende',
        formule: 'AB',
        ntyp: [2],
        nat: () => 4,
        ibrav: [4],
        positions: (ntyp, nat) => [
            [0, 0, 0],
            [1/3, 2/3, 0.5],
            [0, 0, 0.375],
            [1/3, 2/3, 0.875]
        ],
        exemples: ['ZnO', 'CdS', 'CdSe', 'CdTe', 'ZnS', 'ZnSe']
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // COMPOSÉS MAGNÉTIQUES
    // ═══════════════════════════════════════════════════════════════════════
    'ferrite': {
        id: 'ferrite',
        nom: 'Ferrite - MFe2O4',
        description: 'Structure spinelle ferrite magnétique',
        formule: 'AB2X4',
        ntyp: [3],
        nat: () => 14,
        ibrav: [1, 2],
        positions: (ntyp, nat) => [
            // M (2 atomes) - sites tétraédriques
            [0, 0, 0],
            [0.5, 0.5, 0.5],
            // Fe (4 atomes) - sites octaédriques
            [0.125, 0.125, 0.125],
            [0.375, 0.375, 0.125],
            [0.375, 0.125, 0.375],
            [0.125, 0.375, 0.375],
            // O (8 atomes)
            [0.25, 0.25, 0.25],
            [0.75, 0.25, 0.25],
            [0.25, 0.75, 0.25],
            [0.25, 0.25, 0.75],
            [0.75, 0.75, 0.25],
            [0.75, 0.25, 0.75],
            [0.25, 0.75, 0.75],
            [0.75, 0.75, 0.75]
        ],
        exemples: ['CoFe2O4', 'NiFe2O4', 'ZnFe2O4', 'MnFe2O4', 'Fe3O4']
    },
    
    'garnet': {
        id: 'garnet',
        nom: 'Grenat - A3B2C3O12',
        description: 'Structure cubique grenat (YIG)',
        formule: 'A3B2C3O12',
        ntyp: [4],
        nat: () => 20,
        ibrav: [1],
        positions: (ntyp, nat) => {
            // Positions simplifiées du grenat
            const pos = [
                // Y (3 atomes)
                [0, 0, 0.25],
                [0.25, 0.25, 0],
                [0.5, 0.5, 0.25],
                // Fe octahedral (2 atomes)
                [0, 0, 0],
                [0.5, 0.5, 0.5],
                // Fe tetrahedral (3 atomes)
                [0.125, 0.125, 0.125],
                [0.375, 0.375, 0.375],
                [0.625, 0.625, 0.625],
                // O (12 atomes)
                [0.1, 0.2, 0.3],
                [0.2, 0.3, 0.1],
                [0.3, 0.1, 0.2],
                [0.4, 0.5, 0.6],
                [0.5, 0.6, 0.4],
                [0.6, 0.4, 0.5],
                [0.7, 0.8, 0.9],
                [0.8, 0.9, 0.7],
                [0.9, 0.7, 0.8],
                [0.15, 0.25, 0.35],
                [0.25, 0.35, 0.15],
                [0.35, 0.15, 0.25]
            ];
            return pos;
        },
        exemples: ['Y3Fe5O12', 'Gd3Fe5O12', 'Tb3Fe5O12']
    },

    // ═══════════════════════════════════════════════════════════════════════
    // ALLIAGES ET MATÉRIAUX DOPÉS (Approche Supercell)
    // ═══════════════════════════════════════════════════════════════════════

    'alliage_binaire_axb1x': {
        id: 'alliage_binaire_axb1x',
        nom: 'Alliage Binaire AxB(1-x) — Supercell FCC',
        description: 'Alliage binaire de substitution AxB(1-x) par approche supercell 2×2×2. Un ou plusieurs atomes A remplacent B selon la concentration x.',
        formule: 'AxB(1-x)',
        ntyp: [2],
        nat: () => 8,
        ibrav: [2],
        positions: () => [
            [0.0,  0.0,  0.0 ],
            [0.5,  0.0,  0.5 ],
            [0.0,  0.5,  0.5 ],
            [0.5,  0.5,  0.0 ],
            [0.25, 0.25, 0.25],
            [0.75, 0.25, 0.75],
            [0.25, 0.75, 0.75],
            [0.75, 0.75, 0.25]
        ],
        exemples: ['Al0.5Ga0.5As', 'In0.5Ga0.5N', 'Zn0.5Cd0.5S', 'Si0.5Ge0.5', 'Al0.3Ga0.7N']
    },

    'alliage_binaire_a1xbx': {
        id: 'alliage_binaire_a1xbx',
        nom: 'Alliage Binaire A(1-x)Bx — Supercell FCC',
        description: 'Alliage binaire A(1-x)Bx — convention miroir de AxB(1-x). Supercell FCC 2×2×2 avec substitution de la fraction x de A par B.',
        formule: 'A(1-x)Bx',
        ntyp: [2],
        nat: () => 8,
        ibrav: [2],
        positions: () => [
            [0.0,  0.0,  0.0 ],
            [0.5,  0.0,  0.5 ],
            [0.0,  0.5,  0.5 ],
            [0.5,  0.5,  0.0 ],
            [0.25, 0.25, 0.25],
            [0.75, 0.25, 0.75],
            [0.25, 0.75, 0.75],
            [0.75, 0.75, 0.25]
        ],
        exemples: ['Ga(1-x)AlxAs', 'Ga(1-x)InxN', 'Cd(1-x)ZnxTe', 'Pb(1-x)SnxTe', 'In(1-x)GaxAs']
    },

    'ternaire_dope_ab1xcx': {
        id: 'ternaire_dope_ab1xcx',
        nom: 'Ternaire Dopé AB(1-x)Cx — Supercell',
        description: 'Composé ternaire dopé AB(1-x)Cx — substitution sur le site B. Supercell 2×2×2 avec ntyp=3 (A, B, C) et 7B+1C pour dopage 12.5%.',
        formule: 'AB(1-x)Cx',
        ntyp: [3],
        nat: () => 16,
        ibrav: [2],
        positions: () => [
            // 8 atomes A (sites FCC)
            [0.0,  0.0,  0.0 ], [0.5,  0.0,  0.5 ],
            [0.0,  0.5,  0.5 ], [0.5,  0.5,  0.0 ],
            [0.0,  0.0,  0.5 ], [0.5,  0.0,  0.0 ],
            [0.0,  0.5,  0.0 ], [0.5,  0.5,  0.5 ],
            // 7 atomes B + 1 atome C (sites FCC décalés)
            [0.25, 0.25, 0.25], [0.75, 0.25, 0.75],
            [0.25, 0.75, 0.75], [0.75, 0.75, 0.25],
            [0.25, 0.25, 0.75], [0.75, 0.25, 0.25],
            [0.25, 0.75, 0.25],
            [0.75, 0.75, 0.75]  // site C (dopant)
        ],
        exemples: ['GaAs(1-x)Nx', 'CdS(1-x)Sex', 'Bi2Te(3-x)Sex', 'InP(1-x)Asx', 'GaP(1-x)Sbx']
    },

    'ternaire_dope_a1xbxc': {
        id: 'ternaire_dope_a1xbxc',
        nom: 'Ternaire Dopé A(1-x)BxC — Supercell',
        description: 'Composé ternaire dopé A(1-x)BxC — substitution sur le site A. Supercell 2×2×2 avec ntyp=3 (A, B, C) et 7A+1B pour dopage 12.5%.',
        formule: 'A(1-x)BxC',
        ntyp: [3],
        nat: () => 16,
        ibrav: [2],
        positions: () => [
            // 7 atomes A + 1 atome B (sites FCC)
            [0.0,  0.0,  0.0 ], [0.5,  0.0,  0.5 ],
            [0.0,  0.5,  0.5 ], [0.5,  0.5,  0.0 ],
            [0.0,  0.0,  0.5 ], [0.5,  0.0,  0.0 ],
            [0.0,  0.5,  0.0 ],
            [0.5,  0.5,  0.5 ],  // site B (dopant)
            // 8 atomes C (sites FCC décalés)
            [0.25, 0.25, 0.25], [0.75, 0.25, 0.75],
            [0.25, 0.75, 0.75], [0.75, 0.75, 0.25],
            [0.25, 0.25, 0.75], [0.75, 0.25, 0.25],
            [0.25, 0.75, 0.25], [0.75, 0.75, 0.75]
        ],
        exemples: ['(Ga1-xMnx)As', '(In1-xAlx)N', 'Pb(1-x)SnxTe', '(Zn1-xCox)O', '(Cd1-xMnx)Te']
    },

    'perovskite_dope_abo3c': {
        id: 'perovskite_dope_abo3c',
        nom: 'Perovskite Dopé ABO(3-x)Cx (substit. O)',
        description: 'Perovskite dopé avec substitution sur le site de l\'oxygène ABO(3-x)Cx. Supercell 2×2×2 de perovskite cubique, ntyp=4.',
        formule: 'ABO(3-x)Cx',
        ntyp: [4],
        nat: () => 40,
        ibrav: [1],
        positions: () => [
            // 8 atomes A (coins de la supercell 2×2×2)
            [0.0,  0.0,  0.0 ], [0.5,  0.0,  0.0 ], [0.0,  0.5,  0.0 ], [0.0,  0.0,  0.5 ],
            [0.5,  0.5,  0.0 ], [0.5,  0.0,  0.5 ], [0.0,  0.5,  0.5 ], [0.5,  0.5,  0.5 ],
            // 8 atomes B (centres des sous-cubes)
            [0.25, 0.25, 0.25], [0.75, 0.25, 0.25], [0.25, 0.75, 0.25], [0.25, 0.25, 0.75],
            [0.75, 0.75, 0.25], [0.75, 0.25, 0.75], [0.25, 0.75, 0.75], [0.75, 0.75, 0.75],
            // 23 atomes O (arêtes de la supercell)
            [0.25, 0.0,  0.0 ], [0.75, 0.0,  0.0 ], [0.0,  0.25, 0.0 ], [0.0,  0.75, 0.0 ],
            [0.0,  0.0,  0.25], [0.0,  0.0,  0.75], [0.5,  0.25, 0.0 ], [0.5,  0.75, 0.0 ],
            [0.5,  0.0,  0.25], [0.5,  0.0,  0.75], [0.25, 0.5,  0.0 ], [0.75, 0.5,  0.0 ],
            [0.0,  0.5,  0.25], [0.0,  0.5,  0.75], [0.25, 0.0,  0.5 ], [0.75, 0.0,  0.5 ],
            [0.0,  0.25, 0.5 ], [0.0,  0.75, 0.5 ], [0.5,  0.25, 0.5 ], [0.5,  0.75, 0.5 ],
            [0.5,  0.5,  0.25], [0.5,  0.5,  0.75], [0.25, 0.5,  0.5 ],
            // 1 atome C (dopant, remplace le 24ème O)
            [0.75, 0.5,  0.5 ]
        ],
        exemples: ['BaTiO(3-x)Nx', 'LaFeO(3-x)Fx', 'SrTiO(3-x)Cx', 'BaCeO(3-x)Sx']
    },

    'perovskite_dope_axbo3': {
        id: 'perovskite_dope_axbo3',
        nom: 'Perovskite Dopé A(x)A\'(1-x)BO3 (substit. A)',
        description: 'Perovskite dopé sur le site A: A(x)A\'(1-x)BO3. Supercell 2×2×2 avec 7A+1A\' et ntyp=4.',
        formule: "A(x)A'(1-x)BO3",
        ntyp: [4],
        nat: () => 40,
        ibrav: [1],
        positions: () => [
            // 7 atomes A + 1 atome A' (site dopé)
            [0.0,  0.0,  0.0 ], [0.5,  0.0,  0.0 ], [0.0,  0.5,  0.0 ], [0.0,  0.0,  0.5 ],
            [0.5,  0.5,  0.0 ], [0.5,  0.0,  0.5 ], [0.0,  0.5,  0.5 ],
            [0.5,  0.5,  0.5 ],  // site A' dopant
            // 8 atomes B
            [0.25, 0.25, 0.25], [0.75, 0.25, 0.25], [0.25, 0.75, 0.25], [0.25, 0.25, 0.75],
            [0.75, 0.75, 0.25], [0.75, 0.25, 0.75], [0.25, 0.75, 0.75], [0.75, 0.75, 0.75],
            // 24 atomes O
            [0.25, 0.0,  0.0 ], [0.75, 0.0,  0.0 ], [0.0,  0.25, 0.0 ], [0.0,  0.75, 0.0 ],
            [0.0,  0.0,  0.25], [0.0,  0.0,  0.75], [0.5,  0.25, 0.0 ], [0.5,  0.75, 0.0 ],
            [0.5,  0.0,  0.25], [0.5,  0.0,  0.75], [0.25, 0.5,  0.0 ], [0.75, 0.5,  0.0 ],
            [0.0,  0.5,  0.25], [0.0,  0.5,  0.75], [0.25, 0.0,  0.5 ], [0.75, 0.0,  0.5 ],
            [0.0,  0.25, 0.5 ], [0.0,  0.75, 0.5 ], [0.5,  0.25, 0.5 ], [0.5,  0.75, 0.5 ],
            [0.5,  0.5,  0.25], [0.5,  0.5,  0.75], [0.25, 0.5,  0.5 ], [0.75, 0.5,  0.5 ]
        ],
        exemples: ['La(x)Sr(1-x)MnO3', 'Ba(x)Ca(1-x)TiO3', 'La(x)Ba(1-x)FeO3', 'Nd(x)Sr(1-x)MnO3']
    },

    'perovskite_dope_abxco3': {
        id: 'perovskite_dope_abxco3',
        nom: "Perovskite Dopé AB(x)B'(1-x)O3 (substit. B)",
        description: "Perovskite dopé sur le site B: AB(x)B'(1-x)O3. Supercell 2×2×2 avec 7B+1B' et ntyp=4.",
        formule: "AB(x)B'(1-x)O3",
        ntyp: [4],
        nat: () => 40,
        ibrav: [1],
        positions: () => [
            // 8 atomes A
            [0.0,  0.0,  0.0 ], [0.5,  0.0,  0.0 ], [0.0,  0.5,  0.0 ], [0.0,  0.0,  0.5 ],
            [0.5,  0.5,  0.0 ], [0.5,  0.0,  0.5 ], [0.0,  0.5,  0.5 ], [0.5,  0.5,  0.5 ],
            // 7 atomes B + 1 atome B' (dopant)
            [0.25, 0.25, 0.25], [0.75, 0.25, 0.25], [0.25, 0.75, 0.25], [0.25, 0.25, 0.75],
            [0.75, 0.75, 0.25], [0.75, 0.25, 0.75], [0.25, 0.75, 0.75],
            [0.75, 0.75, 0.75],  // site B' dopant
            // 24 atomes O
            [0.25, 0.0,  0.0 ], [0.75, 0.0,  0.0 ], [0.0,  0.25, 0.0 ], [0.0,  0.75, 0.0 ],
            [0.0,  0.0,  0.25], [0.0,  0.0,  0.75], [0.5,  0.25, 0.0 ], [0.5,  0.75, 0.0 ],
            [0.5,  0.0,  0.25], [0.5,  0.0,  0.75], [0.25, 0.5,  0.0 ], [0.75, 0.5,  0.0 ],
            [0.0,  0.5,  0.25], [0.0,  0.5,  0.75], [0.25, 0.0,  0.5 ], [0.75, 0.0,  0.5 ],
            [0.0,  0.25, 0.5 ], [0.0,  0.75, 0.5 ], [0.5,  0.25, 0.5 ], [0.5,  0.75, 0.5 ],
            [0.5,  0.5,  0.25], [0.5,  0.5,  0.75], [0.25, 0.5,  0.5 ], [0.75, 0.5,  0.5 ]
        ],
        exemples: ['BaTi(x)Zr(1-x)O3', 'SrFe(x)Co(1-x)O3', 'LaMn(x)Cr(1-x)O3', 'BaCe(x)Ti(1-x)O3']
    },

    // ═══════════════════════════════════════════════════════════════════════
    // NOUVELLES FAMILLES (batteries, 2D, thermoélectrique, MAX…)
    // ═══════════════════════════════════════════════════════════════════════
    'olivine_abxo4': {
        id: 'olivine_abxo4',
        nom: 'Olivine - ABXO4',
        description: 'Structure orthorhombique olivine (cathodes Li-ion, silicates)',
        formule: 'ABXO4',
        ntyp: [4],
        nat: () => 28,
        ibrav: [8, 9, 10, 11],
        positions: (ntyp, nat) => {
            const pos = [];
            for (let i = 0; i < 4; i++) pos.push([0.1 * i, 0.05 * i, 0.02 * i]);
            for (let i = 0; i < 4; i++) pos.push([0.25 + 0.1 * i, 0.15 * i, 0.3 + 0.02 * i]);
            for (let i = 0; i < 4; i++) pos.push([0.5 + 0.05 * i, 0.25 + 0.1 * i, 0.1 * i]);
            for (let i = 0; i < 16; i++) pos.push([(i % 4) * 0.25, Math.floor(i / 4) * 0.25, (i % 2) * 0.5]);
            return pos.slice(0, nat);
        },
        exemples: ['LiFePO4', 'LiMnPO4', 'LiCoPO4', 'Mg2SiO4', 'Fe2SiO4']
    },

    'ruddlesden_popper_a2bo4': {
        id: 'ruddlesden_popper_a2bo4',
        nom: 'Ruddlesden-Popper - A2BO4',
        description: 'Pérovskite feuilletée n=1 (supraconducteurs, catalyse)',
        formule: 'A2BO4',
        ntyp: [3],
        nat: () => 10,
        ibrav: [6, 7],
        positions: (ntyp, nat) => [
            [0, 0, 0], [0.5, 0.5, 0], [0, 0.5, 0.5], [0.5, 0, 0.5],
            [0.25, 0.25, 0.25],
            [0.5, 0.5, 0.25], [0.5, 0, 0.75], [0, 0.5, 0.75],
            [0.75, 0.25, 0.5], [0.25, 0.75, 0.5]
        ],
        exemples: ['Sr2TiO4', 'La2NiO4', 'La2CuO4', 'Ca2MnO4', 'Pr2NiO4']
    },

    'tetradymite_a2b3': {
        id: 'tetradymite_a2b3',
        nom: 'Tétradymite - A2B3',
        description: 'Structure rhomboédrique (isolants topologiques, thermoélectrique)',
        formule: 'A2B3',
        ntyp: [2],
        nat: () => 5,
        ibrav: [4, 5],
        positions: (ntyp, nat) => [
            [0, 0, 0],
            [0, 0, 0.399],
            [0, 0, 0.211],
            [0, 0, 0.606],
            [0, 0, 0.817]
        ],
        exemples: ['Bi2Se3', 'Bi2Te3', 'Sb2Te3', 'Bi2S3']
    },

    'dichalcogenide_2d_mx2': {
        id: 'dichalcogenide_2d_mx2',
        nom: 'Dichalcogénure 2D - MX2',
        description: 'Monolayer hexagonal vdW (2D, optoélectronique)',
        formule: 'MX2',
        ntyp: [2],
        nat: () => 3,
        ibrav: [4],
        positions: (ntyp, nat) => [
            [0, 0, 0],
            [1/3, 2/3, 0.121],
            [2/3, 1/3, -0.121]
        ],
        exemples: ['MoS2', 'WS2', 'WSe2', 'MoSe2', 'MoTe2']
    },

    'skutterudite_mx3': {
        id: 'skutterudite_mx3',
        nom: 'Skutterudite - MX3',
        description: 'Structure cubique Im-3 (thermoélectrique)',
        formule: 'MX3',
        ntyp: [2],
        nat: () => 32,
        ibrav: [1, 2, 3],
        positions: (ntyp, nat) => {
            const pos = [];
            const corners = [[0,0,0],[0.5,0.5,0],[0.5,0,0.5],[0,0.5,0.5],
                             [0.5,0,0],[0,0.5,0],[0,0,0.5],[0.5,0.5,0.5]];
            corners.forEach(c => pos.push(c));
            for (let i = 0; i < 24; i++) {
                pos.push([(i % 6) * 0.15 + 0.05, (Math.floor(i / 6) % 4) * 0.2, (i % 3) * 0.33 + 0.1]);
            }
            return pos.slice(0, nat);
        },
        exemples: ['CoSb3', 'IrSb3', 'RhSb3', 'FeSb3', 'CoP3']
    },

    'ilmenite_abx3': {
        id: 'ilmenite_abx3',
        nom: 'Ilmenite - ABX3',
        description: 'Structure rhomboédrique (ferroélectrique, oxydes magnétiques)',
        formule: 'ABX3',
        ntyp: [3],
        nat: () => 10,
        ibrav: [4, 5],
        positions: (ntyp, nat) => [
            [0, 0, 0.355], [0, 0, 0.645],
            [0, 0, 0.155], [0, 0, 0.845],
            [0.666, 0.333, 0.02], [0.333, 0.666, 0.98],
            [0.306, 0, 0.25], [0.694, 0, 0.75],
            [0, 0.306, 0.25], [0, 0.694, 0.75]
        ],
        exemples: ['FeTiO3', 'LiNbO3', 'MgTiO3', 'MnTiO3', 'CoTiO3']
    },

    'max_phase_m2ax': {
        id: 'max_phase_m2ax',
        nom: 'MAX Phase - Mn+1AXn',
        description: 'Carbures/nitrures feuilletés conducteurs (M=Ti/V, A=Al/Si, X=C/N)',
        formule: 'M3AX2',
        ntyp: [3],
        nat: () => 8,
        ibrav: [4, 6, 7],
        positions: (ntyp, nat) => [
            [0, 0, 0], [1/3, 2/3, 0.5],
            [0, 0, 0.25], [1/3, 2/3, 0.75],
            [0, 0, 0.5], [1/3, 2/3, 0],
            [0, 0, 0.75], [1/3, 2/3, 0.25]
        ],
        exemples: ['Ti3AlC2', 'V2AlC', 'Ti2AlC', 'Nb2AlC', 'Ti3SiC2']
    }
};

/**
 * Obtenir la liste des types de matériaux pour le select
 */
function obtenirListeTypesMateriaux() {
    const categories = {
        '🔹 Élémentaires': ['fcc', 'bcc', 'hcp', 'diamond'],
        '🔸 Binaires (AB)': [
            'binaire_rocksalt', 
            'binaire_zincblende', 
            'binaire_wurtzite', 
            'binaire_cscl',
            'binaire_iii_v_cubic',
            'binaire_iii_v_hex',
            'binaire_ii_vi'
        ],
        '🔶 Binaires (AX2)': ['rutile', 'fluorite'],
        '🔷 Binaires (A2X3)': ['corundum'],
        '🔹 Ternaires (ABX)': [
            'perovskite_abx3', 
            'antiperovskite_abx3', 
            'heusler_full', 
            'heusler_half'
        ],
        '🔸 Ternaires (ABX2)': ['chalcopyrite_abx2', 'delafossite_abx2'],
        '🔶 Ternaires (AB2X4)': ['spinelle_ab2x4', 'ferrite'],
        '🔷 Quaternaires': ['double_perovskite', 'quaternaire_kesterite'],
        '🔹 Complexes': ['ybco', 'pyrochlore', 'garnet'],
        '🧪 Binaires Dopés': ['alliage_binaire_axb1x', 'alliage_binaire_a1xbx'],
        '🔬 Ternaires Dopés': ['ternaire_dope_ab1xcx', 'ternaire_dope_a1xbxc'],
        '🌟 Perovskites Dopés': ['perovskite_dope_abo3c', 'perovskite_dope_axbo3', 'perovskite_dope_abxco3'],
        '🔋 Batteries / Olivine': ['olivine_abxo4'],
        '📐 Pérovskites feuilletées': ['ruddlesden_popper_a2bo4'],
        '🌐 2D / Topologiques': ['dichalcogenide_2d_mx2', 'tetradymite_a2b3'],
        '♨️ Thermoélectrique': ['skutterudite_mx3'],
        '🪨 Oxydes spéciaux': ['ilmenite_abx3'],
        '🔩 MAX phases': ['max_phase_m2ax']
    };
    
    return categories;
}

/**
 * Calculer nat en fonction du type de matériau
 */
function calculerNatParType(typeId, ntyp) {
    const structure = BASE_STRUCTURES[typeId];
    if (!structure) {
        console.error(`❌ Type de structure non trouvé: ${typeId}`);
        return null;
    }
    
    // Vérifier que ntyp est compatible
    if (!structure.ntyp.includes(ntyp)) {
        console.warn(`⚠️ ntyp=${ntyp} non compatible avec ${structure.nom}`);
        return null;
    }
    
    return structure.nat(ntyp);
}

/**
 * Obtenir les positions atomiques par type de matériau
 */
function obtenirPositionsParType(typeId, ntyp, nat) {
    const structure = BASE_STRUCTURES[typeId];
    if (!structure) {
        console.error(`❌ Type de structure non trouvé: ${typeId}`);
        return [];
    }
    
    return structure.positions(ntyp, nat);
}

console.log('✅ Base de données des structures chargée');



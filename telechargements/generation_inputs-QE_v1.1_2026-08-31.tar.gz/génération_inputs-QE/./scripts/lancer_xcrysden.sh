#!/bin/bash
# Lance XCrySDen de façon robuste (Wayland / Mesa / Togl).
# Usage : lancer_xcrysden.sh fichier.xsf
set -u

XSF="${1:-}"
if [[ -z "$XSF" || ! -f "$XSF" ]]; then
  echo "Usage: $0 fichier.xsf" >&2
  exit 2
fi

XSF="$(readlink -f "$XSF" 2>/dev/null || realpath "$XSF" 2>/dev/null || echo "$XSF")"
EXE="$(command -v xcrysden || true)"
[[ -x /usr/bin/xcrysden ]] && EXE=/usr/bin/xcrysden
if [[ -z "${EXE}" || ! -x "${EXE}" ]]; then
  echo "xcrysden introuvable" >&2
  exit 127
fi

# Affichage : forcer X11 (Togl casse souvent sous Wayland)
if [[ -z "${DISPLAY:-}" ]]; then
  export DISPLAY=:0
fi
# Garder XWayland mais éviter que les toolkits choisissent Wayland natif
unset WAYLAND_DISPLAY WAYLAND_SOCKET
export GDK_BACKEND=x11
export QT_QPA_PLATFORM="${QT_QPA_PLATFORM:-xcb}"
export CLUTTER_BACKEND=x11

# OpenGL logiciel — requis sur beaucoup de GPU Intel/Mesa récents
export LIBGL_ALWAYS_SOFTWARE=1
export GALLIUM_DRIVER="${GALLIUM_DRIVER:-llvmpipe}"
export MESA_LOADER_DRIVER_OVERRIDE="${MESA_LOADER_DRIVER_OVERRIDE:-llvmpipe}"
export LIBGL_DRI3_DISABLE="${LIBGL_DRI3_DISABLE:-1}"
export MESA_GLTHREAD=false
export XLIB_SKIP_ARGB_VISUALS="${XLIB_SKIP_ARGB_VISUALS:-1}"
# Compatibilité Togl (OpenGL « ancien »)
export MESA_GL_VERSION_OVERRIDE="${MESA_GL_VERSION_OVERRIDE:-3.3}"
export MESA_GLSL_VERSION_OVERRIDE="${MESA_GLSL_VERSION_OVERRIDE:-330}"

LOG_DIR="$(dirname "$XSF")"
LOG="${LOG_DIR}/xcrysden_last.log"
{
  echo "==== $(date -Iseconds) ===="
  echo "exe=$EXE"
  echo "xsf=$XSF"
  echo "DISPLAY=${DISPLAY:-}"
  echo "LIBGL_ALWAYS_SOFTWARE=$LIBGL_ALWAYS_SOFTWARE"
} >"$LOG"

# Lancer détaché du terminal parent, logs conservés
exec "$EXE" --xsf "$XSF" >>"$LOG" 2>&1

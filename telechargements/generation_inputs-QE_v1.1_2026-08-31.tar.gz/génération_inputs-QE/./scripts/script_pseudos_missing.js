// ═══════════════════════════════════════════════════════════════════════════
// GESTION DES PSEUDO-POTENTIELS MANQUANTS
// Détection et génération automatique de liens de téléchargement
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Base de données de pseudo-potentiels - avec détection des manquants
 */
const PSEUDOS_SOURCES = {
    // Sources principaux (PSL)
    'psl': {
        name: 'SSSP Efficiency (PSL)',
        url: 'https://www.quantum-espresso.org/pseudo_download/upload/download/{{ELEMENT}}.pbe-rrkjus_psl.1.0.0.UPF',
        description: 'Pseudo-potentiels SSSP PSL (recommandé)'
    },
    'paw': {
        name: 'PAW (GBRV)',
        url: 'https://www.gbrv.org/pseudo/{{ELEMENT}}.paw.UPF',
        description: 'Pseudo-potentiels PAW haute qualité'
    },
    'ultrasoft': {
        name: 'Ultra-Soft Vanderbilt',
        url: 'https://www.quantum-espresso.org/pseudo_download/{{ELEMENT}}.us.UPF',
        description: 'Pseudo-potentiels ultra-soft'
    }
};

/**
 * Listes complètes de pseudo-potentiels disponibles par source
 */
const PSEUDOS_DISPONIBLES = {
    'psl': [
        'H', 'He', 'Li', 'Be', 'B', 'C', 'N', 'O', 'F', 'Ne',
        'Na', 'Mg', 'Al', 'Si', 'P', 'S', 'Cl', 'Ar',
        'K', 'Ca', 'Sc', 'Ti', 'V', 'Cr', 'Mn', 'Fe', 'Co', 'Ni', 'Cu', 'Zn',
        'Ga', 'Ge', 'As', 'Se', 'Br', 'Kr',
        'Rb', 'Sr', 'Y', 'Zr', 'Nb', 'Mo', 'Tc', 'Ru', 'Rh', 'Pd', 'Ag', 'Cd',
        'In', 'Sn', 'Sb', 'Te', 'I', 'Xe',
        'Cs', 'Ba', 'La', 'Ce', 'Pr', 'Nd', 'Pm', 'Sm', 'Eu', 'Gd', 'Tb', 'Dy', 'Ho', 'Er', 'Tm', 'Yb', 'Lu',
        'Hf', 'Ta', 'W', 'Re', 'Os', 'Ir', 'Pt', 'Au', 'Hg', 'Tl', 'Pb', 'Bi', 'Po', 'At', 'Rn'
    ],
    'paw': [
        'H', 'Li', 'Be', 'B', 'C', 'N', 'O', 'F', 'Na', 'Mg', 'Al', 'Si', 'P', 'S', 'Cl',
        'K', 'Ca', 'Sc', 'Ti', 'V', 'Cr', 'Mn', 'Fe', 'Co', 'Ni', 'Cu', 'Zn',
        'Ga', 'Ge', 'As', 'Se', 'Br', 'Rb', 'Sr', 'Y', 'Zr', 'Nb', 'Mo',
        'Ba', 'La'
    ],
    'ultrasoft': [
        'H', 'C', 'N', 'O', 'S', 'Si', 'P', 'Cl', 'K', 'Ca', 'Fe'
    ]
};

/**
 * Vérifier si un pseudo-potentiel est disponible
 */
function verifierDisponibilitesPseudo(element) {
    const resultats = {
        element: element,
        disponible: {},
        manquant: false
    };
    
    // Vérifier chaque source
    for (const source in PSEUDOS_DISPONIBLES) {
        const exists = PSEUDOS_DISPONIBLES[source].includes(element);
        resultats.disponible[source] = exists;
        
        if (!exists) {
            resultats.manquant = true;
        }
    }
    
    console.log(`🔍 Pseudo pour ${element}:`, resultats);
    return resultats;
}

/**
 * Générer un lien de téléchargement pour un pseudo manquant
 */
function genererLienTelecharger(element) {
    const verif = verifierDisponibilitesPseudo(element);
    
    // Chercher la première source disponible
    for (const source in verif.disponible) {
        if (verif.disponible[source]) {
            const urlTemplate = PSEUDOS_SOURCES[source].url;
            const url = urlTemplate.replace('{{ELEMENT}}', element.toLowerCase());
            
            return {
                source: source,
                sourceName: PSEUDOS_SOURCES[source].name,
                url: url,
                disponible: true
            };
        }
    }
    
    // Si aucun disponible, retourner info
    return {
        source: 'aucun',
        sourceName: 'Pseudo-potentiel non trouvé',
        url: null,
        disponible: false,
        message: `⚠️ Aucun pseudo-potentiel trouvé pour ${element}. Veuillez générer manuellement via www.quantum-espresso.org`
    };
}

/**
 * Afficher les pseudos manquants avec liens de téléchargement
 */
function afficherPseudosMissingAvecLiens() {
    const ntypInput = document.getElementById('ntyp');
    const ntyp = parseInt(ntypInput?.value) || 0;
    
    console.log(`\n🔧 Vérification des pseudos manquants pour ${ntyp} éléments...`);
    
    const manquants = [];
    
    for (let i = 1; i <= ntyp; i++) {
        const elemInput = document.getElementById(`element_${i}`);
        const element = elemInput?.value.trim() || '';
        
        if (element) {
            const verif = verifierDisponibilitesPseudo(element);
            if (verif.manquant) {
                const lien = genererLienTelecharger(element);
                manquants.push({
                    element: element,
                    ...lien
                });
            }
        }
    }
    
    // Afficher les résultats
    if (manquants.length === 0) {
        console.log('✅ Tous les pseudos sont disponibles!');
        return {
            manquants: [],
            message: '✅ Tous les pseudo-potentiels sont disponibles!'
        };
    }
    
    console.warn(`⚠️ ${manquants.length} pseudo(s) à vérifier:`);
    manquants.forEach(m => {
        console.log(`  - ${m.element}: ${m.message || m.sourceName}`);
    });
    
    return {
        manquants: manquants,
        message: `⚠️ ${manquants.length} pseudo-potentiel(s) nécessite vérification`
    };
}

/**
 * Créer une section d'affichage des pseudos manquants
 */
function creerSectionPseudosMissing() {
    // Vérifier s'il existe déjà
    let section = document.getElementById('section_pseudos_missing');
    if (!section) {
        section = document.createElement('div');
        section.id = 'section_pseudos_missing';
        
        const pseudosDisplay = document.getElementById('pseudos_display');
        if (pseudosDisplay) {
            pseudosDisplay.parentElement.insertBefore(section, pseudosDisplay);
        }
    }
    
    const verif = afficherPseudosMissingAvecLiens();
    
    if (verif.manquants.length === 0) {
        section.innerHTML = `
            <div style="
                padding: 12px;
                background: #c8e6c9;
                border: 2px solid #4caf50;
                border-radius: 8px;
                color: #2e7d32;
                font-weight: bold;
                margin-bottom: 15px;
            ">✅ ${verif.message}</div>
        `;
        return;
    }
    
    // Afficher les pseudos manquants avec liens
    let html = `
        <div style="
            padding: 12px;
            background: #fff3e0;
            border: 2px solid #ff9800;
            border-radius: 8px;
            margin-bottom: 15px;
        ">
            <h4 style="margin: 0 0 10px 0; color: #f57f17;">⚠️ Pseudo-potentiels à Vérifier</h4>
            <div style="display: grid; gap: 8px;">
    `;
    
    verif.manquants.forEach(m => {
        if (m.disponible) {
            html += `
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px; background: white; border-radius: 5px; border-left: 4px solid #ff9800;">
                    <div>
                        <strong>${m.element}</strong> - ${m.sourceName}
                    </div>
                    <a href="${m.url}" target="_blank" style="
                        padding: 6px 12px;
                        background: #ff9800;
                        color: white;
                        text-decoration: none;
                        border-radius: 4px;
                        font-size: 0.85em;
                        font-weight: bold;
                        cursor: pointer;
                    ">📥 Télécharger</a>
                </div>
            `;
        } else {
            html += `
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px; background: white; border-radius: 5px; border-left: 4px solid #d32f2f;">
                    <div>
                        <strong>${m.element}</strong> - ${m.message}
                    </div>
                    <a href="https://www.quantum-espresso.org/pseudo_download/" target="_blank" style="
                        padding: 6px 12px;
                        background: #d32f2f;
                        color: white;
                        text-decoration: none;
                        border-radius: 4px;
                        font-size: 0.85em;
                        font-weight: bold;
                        cursor: pointer;
                    ">🔗 Chercher</a>
                </div>
            `;
        }
    });
    
    html += `
            </div>
        </div>
    `;
    
    section.innerHTML = html;
}

/**
 * Initialiser la vérification des pseudos manquants
 */
function initialiserPseudosMissing() {
    console.log('🔧 Initialisation vérification pseudos manquants...');
    
    // Ajouter un écouteur au changement de ntyp ou d'éléments
    const ntypInput = document.getElementById('ntyp');
    if (ntypInput) {
        ntypInput.addEventListener('change', () => {
            setTimeout(creerSectionPseudosMissing, 100);
        });
    }
    
    // Ajouter des écouteurs à chaque champ élément
    const observerMutations = setInterval(() => {
        for (let i = 1; i <= 10; i++) {
            const elemInput = document.getElementById(`element_${i}`);
            if (elemInput && !elemInput.hasAttribute('data-listener')) {
                elemInput.addEventListener('change', () => {
                    setTimeout(creerSectionPseudosMissing, 100);
                });
                elemInput.setAttribute('data-listener', 'true');
            }
        }
    }, 500);
    
    console.log('✅ Vérification pseudos manquants initialisée');
}

// Exécuter à l'initialisation
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialiserPseudosMissing);
} else {
    initialiserPseudosMissing();
}

console.log('✅ Script gestion pseudos manquants chargé');



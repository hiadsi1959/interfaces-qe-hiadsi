// ═══════════════════════════════════════════════════════════════════════
// BASE DE DONNÉES COMPLÈTE DES 230 GROUPES D'ESPACE
// Organisés par système cristallin compatible avec ibrav de Quantum ESPRESSO
// ═══════════════════════════════════════════════════════════════════════

const GROUPES_ESPACE_COMPLETS = {
    
    // ═══════════════════════════════════════════════════════════════════
    // SYSTÈME TRICLINIQUE (2 groupes d'espace: 1-2)
    // Compatible avec: ibrav = 14
    // ═══════════════════════════════════════════════════════════════════
    'triclinique': {
        ibrav: [14],
        nombre_groupes: 2,
        groupes: [
            { numero: 1, hermann_mauguin: 'P1', schoenflies: 'C1', description: 'Triclinique primitif' },
            { numero: 2, hermann_mauguin: 'P-1', schoenflies: 'Ci', description: 'Triclinique avec centre d\'inversion' }
        ]
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // SYSTÈME MONOCLINIQUE (13 groupes d'espace: 3-15)
    // Compatible avec: ibrav = 12, -12, 13, -13
    // ═══════════════════════════════════════════════════════════════════
    'monoclinique': {
        ibrav: [12, -12, 13, -13],
        nombre_groupes: 13,
        groupes: [
            { numero: 3, hermann_mauguin: 'P2', schoenflies: 'C2', description: 'Monoclinique primitif', centrage: 'P' },
            { numero: 4, hermann_mauguin: 'P21', schoenflies: 'C2^2', description: 'Monoclinique avec axe vis', centrage: 'P' },
            { numero: 5, hermann_mauguin: 'C2', schoenflies: 'C2^3', description: 'Monoclinique base centrée', centrage: 'C' },
            { numero: 6, hermann_mauguin: 'Pm', schoenflies: 'Cs^1', description: 'Monoclinique avec plan miroir', centrage: 'P' },
            { numero: 7, hermann_mauguin: 'Pc', schoenflies: 'Cs^2', description: 'Monoclinique avec plan de glissement', centrage: 'P' },
            { numero: 8, hermann_mauguin: 'Cm', schoenflies: 'Cs^3', description: 'Monoclinique base centrée avec miroir', centrage: 'C' },
            { numero: 9, hermann_mauguin: 'Cc', schoenflies: 'Cs^4', description: 'Monoclinique base centrée avec glissement', centrage: 'C' },
            { numero: 10, hermann_mauguin: 'P2/m', schoenflies: 'C2h^1', description: 'Monoclinique P avec inversion', centrage: 'P' },
            { numero: 11, hermann_mauguin: 'P21/m', schoenflies: 'C2h^2', description: 'Monoclinique P avec vis et inversion', centrage: 'P' },
            { numero: 12, hermann_mauguin: 'C2/m', schoenflies: 'C2h^3', description: 'Monoclinique C avec inversion', centrage: 'C' },
            { numero: 13, hermann_mauguin: 'P2/c', schoenflies: 'C2h^4', description: 'Monoclinique P avec glissement', centrage: 'P' },
            { numero: 14, hermann_mauguin: 'P21/c', schoenflies: 'C2h^5', description: 'Monoclinique le plus courant', centrage: 'P' },
            { numero: 15, hermann_mauguin: 'C2/c', schoenflies: 'C2h^6', description: 'Monoclinique C avec glissement', centrage: 'C' }
        ]
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // SYSTÈME ORTHORHOMBIQUE (59 groupes d'espace: 16-74)
    // Compatible avec: ibrav = 8, 9, -9, 10, 11
    // ═══════════════════════════════════════════════════════════════════
    'orthorhombique': {
        ibrav: [8, 9, -9, 10, 11],
        nombre_groupes: 59,
        groupes: [
            // Orthorhombique Primitif (P)
            { numero: 16, hermann_mauguin: 'P222', schoenflies: 'D2^1', centrage: 'P' },
            { numero: 17, hermann_mauguin: 'P2221', schoenflies: 'D2^2', centrage: 'P' },
            { numero: 18, hermann_mauguin: 'P21212', schoenflies: 'D2^3', centrage: 'P' },
            { numero: 19, hermann_mauguin: 'P212121', schoenflies: 'D2^4', centrage: 'P' },
            { numero: 20, hermann_mauguin: 'C2221', schoenflies: 'D2^5', centrage: 'C' },
            { numero: 21, hermann_mauguin: 'C222', schoenflies: 'D2^6', centrage: 'C' },
            { numero: 22, hermann_mauguin: 'F222', schoenflies: 'D2^7', centrage: 'F' },
            { numero: 23, hermann_mauguin: 'I222', schoenflies: 'D2^8', centrage: 'I' },
            { numero: 24, hermann_mauguin: 'I212121', schoenflies: 'D2^9', centrage: 'I' },
            { numero: 25, hermann_mauguin: 'Pmm2', schoenflies: 'C2v^1', centrage: 'P' },
            { numero: 26, hermann_mauguin: 'Pmc21', schoenflies: 'C2v^2', centrage: 'P' },
            { numero: 27, hermann_mauguin: 'Pcc2', schoenflies: 'C2v^3', centrage: 'P' },
            { numero: 28, hermann_mauguin: 'Pma2', schoenflies: 'C2v^4', centrage: 'P' },
            { numero: 29, hermann_mauguin: 'Pca21', schoenflies: 'C2v^5', centrage: 'P' },
            { numero: 30, hermann_mauguin: 'Pnc2', schoenflies: 'C2v^6', centrage: 'P' },
            { numero: 31, hermann_mauguin: 'Pmn21', schoenflies: 'C2v^7', centrage: 'P' },
            { numero: 32, hermann_mauguin: 'Pba2', schoenflies: 'C2v^8', centrage: 'P' },
            { numero: 33, hermann_mauguin: 'Pna21', schoenflies: 'C2v^9', centrage: 'P' },
            { numero: 34, hermann_mauguin: 'Pnn2', schoenflies: 'C2v^10', centrage: 'P' },
            { numero: 35, hermann_mauguin: 'Cmm2', schoenflies: 'C2v^11', centrage: 'C' },
            { numero: 36, hermann_mauguin: 'Cmc21', schoenflies: 'C2v^12', centrage: 'C' },
            { numero: 37, hermann_mauguin: 'Ccc2', schoenflies: 'C2v^13', centrage: 'C' },
            { numero: 38, hermann_mauguin: 'Amm2', schoenflies: 'C2v^14', centrage: 'A' },
            { numero: 39, hermann_mauguin: 'Aem2', schoenflies: 'C2v^15', centrage: 'A' },
            { numero: 40, hermann_mauguin: 'Ama2', schoenflies: 'C2v^16', centrage: 'A' },
            { numero: 41, hermann_mauguin: 'Aea2', schoenflies: 'C2v^17', centrage: 'A' },
            { numero: 42, hermann_mauguin: 'Fmm2', schoenflies: 'C2v^18', centrage: 'F' },
            { numero: 43, hermann_mauguin: 'Fdd2', schoenflies: 'C2v^19', centrage: 'F' },
            { numero: 44, hermann_mauguin: 'Imm2', schoenflies: 'C2v^20', centrage: 'I' },
            { numero: 45, hermann_mauguin: 'Iba2', schoenflies: 'C2v^21', centrage: 'I' },
            { numero: 46, hermann_mauguin: 'Ima2', schoenflies: 'C2v^22', centrage: 'I' },
            { numero: 47, hermann_mauguin: 'Pmmm', schoenflies: 'D2h^1', centrage: 'P', note: 'Très courant' },
            { numero: 48, hermann_mauguin: 'Pnnn', schoenflies: 'D2h^2', centrage: 'P' },
            { numero: 49, hermann_mauguin: 'Pccm', schoenflies: 'D2h^3', centrage: 'P' },
            { numero: 50, hermann_mauguin: 'Pban', schoenflies: 'D2h^4', centrage: 'P' },
            { numero: 51, hermann_mauguin: 'Pmma', schoenflies: 'D2h^5', centrage: 'P' },
            { numero: 52, hermann_mauguin: 'Pnna', schoenflies: 'D2h^6', centrage: 'P' },
            { numero: 53, hermann_mauguin: 'Pmna', schoenflies: 'D2h^7', centrage: 'P' },
            { numero: 54, hermann_mauguin: 'Pcca', schoenflies: 'D2h^8', centrage: 'P' },
            { numero: 55, hermann_mauguin: 'Pbam', schoenflies: 'D2h^9', centrage: 'P' },
            { numero: 56, hermann_mauguin: 'Pccn', schoenflies: 'D2h^10', centrage: 'P' },
            { numero: 57, hermann_mauguin: 'Pbcm', schoenflies: 'D2h^11', centrage: 'P' },
            { numero: 58, hermann_mauguin: 'Pnnm', schoenflies: 'D2h^12', centrage: 'P' },
            { numero: 59, hermann_mauguin: 'Pmmn', schoenflies: 'D2h^13', centrage: 'P' },
            { numero: 60, hermann_mauguin: 'Pbcn', schoenflies: 'D2h^14', centrage: 'P' },
            { numero: 61, hermann_mauguin: 'Pbca', schoenflies: 'D2h^15', centrage: 'P' },
            { numero: 62, hermann_mauguin: 'Pnma', schoenflies: 'D2h^16', centrage: 'P', note: 'Très courant pour pérovskites distordues' },
            { numero: 63, hermann_mauguin: 'Cmcm', schoenflies: 'D2h^17', centrage: 'C' },
            { numero: 64, hermann_mauguin: 'Cmce', schoenflies: 'D2h^18', centrage: 'C' },
            { numero: 65, hermann_mauguin: 'Cmmm', schoenflies: 'D2h^19', centrage: 'C' },
            { numero: 66, hermann_mauguin: 'Cccm', schoenflies: 'D2h^20', centrage: 'C' },
            { numero: 67, hermann_mauguin: 'Cmme', schoenflies: 'D2h^21', centrage: 'C' },
            { numero: 68, hermann_mauguin: 'Ccce', schoenflies: 'D2h^22', centrage: 'C' },
            { numero: 69, hermann_mauguin: 'Fmmm', schoenflies: 'D2h^23', centrage: 'F' },
            { numero: 70, hermann_mauguin: 'Fddd', schoenflies: 'D2h^24', centrage: 'F' },
            { numero: 71, hermann_mauguin: 'Immm', schoenflies: 'D2h^25', centrage: 'I' },
            { numero: 72, hermann_mauguin: 'Ibam', schoenflies: 'D2h^26', centrage: 'I' },
            { numero: 73, hermann_mauguin: 'Ibca', schoenflies: 'D2h^27', centrage: 'I' },
            { numero: 74, hermann_mauguin: 'Imma', schoenflies: 'D2h^28', centrage: 'I' }
        ]
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // SYSTÈME TÉTRAGONAL (68 groupes d'espace: 75-142)
    // Compatible avec: ibrav = 6, 7
    // ═══════════════════════════════════════════════════════════════════
    'tetragonal': {
        ibrav: [6, 7],
        nombre_groupes: 68,
        groupes: [
            // Tétragonal Primitif (P)
            { numero: 75, hermann_mauguin: 'P4', schoenflies: 'C4^1', centrage: 'P' },
            { numero: 76, hermann_mauguin: 'P41', schoenflies: 'C4^2', centrage: 'P' },
            { numero: 77, hermann_mauguin: 'P42', schoenflies: 'C4^3', centrage: 'P' },
            { numero: 78, hermann_mauguin: 'P43', schoenflies: 'C4^4', centrage: 'P' },
            { numero: 79, hermann_mauguin: 'I4', schoenflies: 'C4^5', centrage: 'I' },
            { numero: 80, hermann_mauguin: 'I41', schoenflies: 'C4^6', centrage: 'I' },
            { numero: 81, hermann_mauguin: 'P-4', schoenflies: 'S4^1', centrage: 'P' },
            { numero: 82, hermann_mauguin: 'I-4', schoenflies: 'S4^2', centrage: 'I' },
            { numero: 83, hermann_mauguin: 'P4/m', schoenflies: 'C4h^1', centrage: 'P' },
            { numero: 84, hermann_mauguin: 'P42/m', schoenflies: 'C4h^2', centrage: 'P' },
            { numero: 85, hermann_mauguin: 'P4/n', schoenflies: 'C4h^3', centrage: 'P' },
            { numero: 86, hermann_mauguin: 'P42/n', schoenflies: 'C4h^4', centrage: 'P' },
            { numero: 87, hermann_mauguin: 'I4/m', schoenflies: 'C4h^5', centrage: 'I' },
            { numero: 88, hermann_mauguin: 'I41/a', schoenflies: 'C4h^6', centrage: 'I' },
            { numero: 89, hermann_mauguin: 'P422', schoenflies: 'D4^1', centrage: 'P' },
            { numero: 90, hermann_mauguin: 'P4212', schoenflies: 'D4^2', centrage: 'P' },
            { numero: 91, hermann_mauguin: 'P4122', schoenflies: 'D4^3', centrage: 'P' },
            { numero: 92, hermann_mauguin: 'P41212', schoenflies: 'D4^4', centrage: 'P' },
            { numero: 93, hermann_mauguin: 'P4222', schoenflies: 'D4^5', centrage: 'P' },
            { numero: 94, hermann_mauguin: 'P42212', schoenflies: 'D4^6', centrage: 'P' },
            { numero: 95, hermann_mauguin: 'P4322', schoenflies: 'D4^7', centrage: 'P' },
            { numero: 96, hermann_mauguin: 'P43212', schoenflies: 'D4^8', centrage: 'P' },
            { numero: 97, hermann_mauguin: 'I422', schoenflies: 'D4^9', centrage: 'I' },
            { numero: 98, hermann_mauguin: 'I4122', schoenflies: 'D4^10', centrage: 'I' },
            { numero: 99, hermann_mauguin: 'P4mm', schoenflies: 'C4v^1', centrage: 'P' },
            { numero: 100, hermann_mauguin: 'P4bm', schoenflies: 'C4v^2', centrage: 'P' },
            { numero: 101, hermann_mauguin: 'P42cm', schoenflies: 'C4v^3', centrage: 'P' },
            { numero: 102, hermann_mauguin: 'P42nm', schoenflies: 'C4v^4', centrage: 'P' },
            { numero: 103, hermann_mauguin: 'P4cc', schoenflies: 'C4v^5', centrage: 'P' },
            { numero: 104, hermann_mauguin: 'P4nc', schoenflies: 'C4v^6', centrage: 'P' },
            { numero: 105, hermann_mauguin: 'P42mc', schoenflies: 'C4v^7', centrage: 'P' },
            { numero: 106, hermann_mauguin: 'P42bc', schoenflies: 'C4v^8', centrage: 'P' },
            { numero: 107, hermann_mauguin: 'I4mm', schoenflies: 'C4v^9', centrage: 'I' },
            { numero: 108, hermann_mauguin: 'I4cm', schoenflies: 'C4v^10', centrage: 'I' },
            { numero: 109, hermann_mauguin: 'I41md', schoenflies: 'C4v^11', centrage: 'I' },
            { numero: 110, hermann_mauguin: 'I41cd', schoenflies: 'C4v^12', centrage: 'I' },
            { numero: 111, hermann_mauguin: 'P-42m', schoenflies: 'D2d^1', centrage: 'P' },
            { numero: 112, hermann_mauguin: 'P-42c', schoenflies: 'D2d^2', centrage: 'P' },
            { numero: 113, hermann_mauguin: 'P-421m', schoenflies: 'D2d^3', centrage: 'P' },
            { numero: 114, hermann_mauguin: 'P-421c', schoenflies: 'D2d^4', centrage: 'P' },
            { numero: 115, hermann_mauguin: 'P-4m2', schoenflies: 'D2d^5', centrage: 'P' },
            { numero: 116, hermann_mauguin: 'P-4c2', schoenflies: 'D2d^6', centrage: 'P' },
            { numero: 117, hermann_mauguin: 'P-4b2', schoenflies: 'D2d^7', centrage: 'P' },
            { numero: 118, hermann_mauguin: 'P-4n2', schoenflies: 'D2d^8', centrage: 'P' },
            { numero: 119, hermann_mauguin: 'I-4m2', schoenflies: 'D2d^9', centrage: 'I' },
            { numero: 120, hermann_mauguin: 'I-4c2', schoenflies: 'D2d^10', centrage: 'I' },
            { numero: 121, hermann_mauguin: 'I-42m', schoenflies: 'D2d^11', centrage: 'I' },
            { numero: 122, hermann_mauguin: 'I-42d', schoenflies: 'D2d^12', centrage: 'I' },
            { numero: 123, hermann_mauguin: 'P4/mmm', schoenflies: 'D4h^1', centrage: 'P', note: 'Très courant' },
            { numero: 124, hermann_mauguin: 'P4/mcc', schoenflies: 'D4h^2', centrage: 'P' },
            { numero: 125, hermann_mauguin: 'P4/nbm', schoenflies: 'D4h^3', centrage: 'P' },
            { numero: 126, hermann_mauguin: 'P4/nnc', schoenflies: 'D4h^4', centrage: 'P' },
            { numero: 127, hermann_mauguin: 'P4/mbm', schoenflies: 'D4h^5', centrage: 'P' },
            { numero: 128, hermann_mauguin: 'P4/mnc', schoenflies: 'D4h^6', centrage: 'P' },
            { numero: 129, hermann_mauguin: 'P4/nmm', schoenflies: 'D4h^7', centrage: 'P' },
            { numero: 130, hermann_mauguin: 'P4/ncc', schoenflies: 'D4h^8', centrage: 'P' },
            { numero: 131, hermann_mauguin: 'P42/mmc', schoenflies: 'D4h^9', centrage: 'P' },
            { numero: 132, hermann_mauguin: 'P42/mcm', schoenflies: 'D4h^10', centrage: 'P' },
            { numero: 133, hermann_mauguin: 'P42/nbc', schoenflies: 'D4h^11', centrage: 'P' },
            { numero: 134, hermann_mauguin: 'P42/nnm', schoenflies: 'D4h^12', centrage: 'P' },
            { numero: 135, hermann_mauguin: 'P42/mbc', schoenflies: 'D4h^13', centrage: 'P' },
            { numero: 136, hermann_mauguin: 'P42/mnm', schoenflies: 'D4h^14', centrage: 'P' },
            { numero: 137, hermann_mauguin: 'P42/nmc', schoenflies: 'D4h^15', centrage: 'P' },
            { numero: 138, hermann_mauguin: 'P42/ncm', schoenflies: 'D4h^16', centrage: 'P' },
            { numero: 139, hermann_mauguin: 'I4/mmm', schoenflies: 'D4h^17', centrage: 'I', note: 'Très courant' },
            { numero: 140, hermann_mauguin: 'I4/mcm', schoenflies: 'D4h^18', centrage: 'I' },
            { numero: 141, hermann_mauguin: 'I41/amd', schoenflies: 'D4h^19', centrage: 'I' },
            { numero: 142, hermann_mauguin: 'I41/acd', schoenflies: 'D4h^20', centrage: 'I' }
        ]
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // SYSTÈME TRIGONAL/RHOMBOÉDRIQUE (25 groupes d'espace: 143-167)
    // Compatible avec: ibrav = 5, -5
    // ═══════════════════════════════════════════════════════════════════
    'trigonal': {
        ibrav: [5, -5],
        nombre_groupes: 25,
        groupes: [
            { numero: 143, hermann_mauguin: 'P3', schoenflies: 'C3^1', centrage: 'P' },
            { numero: 144, hermann_mauguin: 'P31', schoenflies: 'C3^2', centrage: 'P' },
            { numero: 145, hermann_mauguin: 'P32', schoenflies: 'C3^3', centrage: 'P' },
            { numero: 146, hermann_mauguin: 'R3', schoenflies: 'C3^4', centrage: 'R', note: 'Hexagonal/Rhomboédrique' },
            { numero: 147, hermann_mauguin: 'P-3', schoenflies: 'C3i^1', centrage: 'P' },
            { numero: 148, hermann_mauguin: 'R-3', schoenflies: 'C3i^2', centrage: 'R' },
            { numero: 149, hermann_mauguin: 'P312', schoenflies: 'D3^1', centrage: 'P' },
            { numero: 150, hermann_mauguin: 'P321', schoenflies: 'D3^2', centrage: 'P' },
            { numero: 151, hermann_mauguin: 'P3112', schoenflies: 'D3^3', centrage: 'P' },
            { numero: 152, hermann_mauguin: 'P3121', schoenflies: 'D3^4', centrage: 'P' },
            { numero: 153, hermann_mauguin: 'P3212', schoenflies: 'D3^5', centrage: 'P' },
            { numero: 154, hermann_mauguin: 'P3221', schoenflies: 'D3^6', centrage: 'P' },
            { numero: 155, hermann_mauguin: 'R32', schoenflies: 'D3^7', centrage: 'R' },
            { numero: 156, hermann_mauguin: 'P3m1', schoenflies: 'C3v^1', centrage: 'P' },
            { numero: 157, hermann_mauguin: 'P31m', schoenflies: 'C3v^2', centrage: 'P' },
            { numero: 158, hermann_mauguin: 'P3c1', schoenflies: 'C3v^3', centrage: 'P' },
            { numero: 159, hermann_mauguin: 'P31c', schoenflies: 'C3v^4', centrage: 'P' },
            { numero: 160, hermann_mauguin: 'R3m', schoenflies: 'C3v^5', centrage: 'R', note: 'Très courant' },
            { numero: 161, hermann_mauguin: 'R3c', schoenflies: 'C3v^6', centrage: 'R' },
            { numero: 162, hermann_mauguin: 'P-31m', schoenflies: 'D3d^1', centrage: 'P' },
            { numero: 163, hermann_mauguin: 'P-31c', schoenflies: 'D3d^2', centrage: 'P' },
            { numero: 164, hermann_mauguin: 'P-3m1', schoenflies: 'D3d^3', centrage: 'P' },
            { numero: 165, hermann_mauguin: 'P-3c1', schoenflies: 'D3d^4', centrage: 'P' },
            { numero: 166, hermann_mauguin: 'R-3m', schoenflies: 'D3d^5', centrage: 'R', note: 'Très courant (calcite, corundum)' },
            { numero: 167, hermann_mauguin: 'R-3c', schoenflies: 'D3d^6', centrage: 'R' }
        ]
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // SYSTÈME HEXAGONAL (27 groupes d'espace: 168-194)
    // Compatible avec: ibrav = 4
    // ═══════════════════════════════════════════════════════════════════
    'hexagonal': {
        ibrav: [4],
        nombre_groupes: 27,
        groupes: [
            { numero: 168, hermann_mauguin: 'P6', schoenflies: 'C6^1' },
            { numero: 169, hermann_mauguin: 'P61', schoenflies: 'C6^2' },
            { numero: 170, hermann_mauguin: 'P65', schoenflies: 'C6^3' },
            { numero: 171, hermann_mauguin: 'P62', schoenflies: 'C6^4' },
            { numero: 172, hermann_mauguin: 'P64', schoenflies: 'C6^5' },
            { numero: 173, hermann_mauguin: 'P63', schoenflies: 'C6^6' },
            { numero: 174, hermann_mauguin: 'P-6', schoenflies: 'C3h^1' },
            { numero: 175, hermann_mauguin: 'P6/m', schoenflies: 'C6h^1' },
            { numero: 176, hermann_mauguin: 'P63/m', schoenflies: 'C6h^2' },
            { numero: 177, hermann_mauguin: 'P622', schoenflies: 'D6^1' },
            { numero: 178, hermann_mauguin: 'P6122', schoenflies: 'D6^2' },
            { numero: 179, hermann_mauguin: 'P6522', schoenflies: 'D6^3' },
            { numero: 180, hermann_mauguin: 'P6222', schoenflies: 'D6^4' },
            { numero: 181, hermann_mauguin: 'P6422', schoenflies: 'D6^5' },
            { numero: 182, hermann_mauguin: 'P6322', schoenflies: 'D6^6' },
            { numero: 183, hermann_mauguin: 'P6mm', schoenflies: 'C6v^1' },
            { numero: 184, hermann_mauguin: 'P6cc', schoenflies: 'C6v^2' },
            { numero: 185, hermann_mauguin: 'P63cm', schoenflies: 'C6v^3' },
            { numero: 186, hermann_mauguin: 'P63mc', schoenflies: 'C6v^4' },
            { numero: 187, hermann_mauguin: 'P-6m2', schoenflies: 'D3h^1' },
            { numero: 188, hermann_mauguin: 'P-6c2', schoenflies: 'D3h^2' },
            { numero: 189, hermann_mauguin: 'P-62m', schoenflies: 'D3h^3' },
            { numero: 190, hermann_mauguin: 'P-62c', schoenflies: 'D3h^4' },
            { numero: 191, hermann_mauguin: 'P6/mmm', schoenflies: 'D6h^1', note: 'Hexagonal haute symétrie' },
            { numero: 192, hermann_mauguin: 'P6/mcc', schoenflies: 'D6h^2' },
            { numero: 193, hermann_mauguin: 'P63/mcm', schoenflies: 'D6h^3' },
            { numero: 194, hermann_mauguin: 'P63/mmc', schoenflies: 'D6h^4', note: 'Très courant (wurtzite, GaN, ZnO)' }
        ]
    },
    
    // ═══════════════════════════════════════════════════════════════════
    // SYSTÈME CUBIQUE (36 groupes d'espace: 195-230)
    // Compatible avec: ibrav = 1, 2, 3, -3
    // ═══════════════════════════════════════════════════════════════════
    'cubique': {
        ibrav: [1, 2, 3, -3],
        nombre_groupes: 36,
        groupes: [
            // Cubique Primitif (P)
            { numero: 195, hermann_mauguin: 'P23', schoenflies: 'T1', centrage: 'P' },
            { numero: 196, hermann_mauguin: 'F23', schoenflies: 'T2', centrage: 'F' },
            { numero: 197, hermann_mauguin: 'I23', schoenflies: 'T3', centrage: 'I' },
            { numero: 198, hermann_mauguin: 'P213', schoenflies: 'T4', centrage: 'P' },
            { numero: 199, hermann_mauguin: 'I213', schoenflies: 'T5', centrage: 'I' },
            { numero: 200, hermann_mauguin: 'Pm-3', schoenflies: 'Th1', centrage: 'P' },
            { numero: 201, hermann_mauguin: 'Pn-3', schoenflies: 'Th2', centrage: 'P' },
            { numero: 202, hermann_mauguin: 'Fm-3', schoenflies: 'Th3', centrage: 'F' },
            { numero: 203, hermann_mauguin: 'Fd-3', schoenflies: 'Th4', centrage: 'F' },
            { numero: 204, hermann_mauguin: 'Im-3', schoenflies: 'Th5', centrage: 'I' },
            { numero: 205, hermann_mauguin: 'Pa-3', schoenflies: 'Th6', centrage: 'P' },
            { numero: 206, hermann_mauguin: 'Ia-3', schoenflies: 'Th7', centrage: 'I' },
            { numero: 207, hermann_mauguin: 'P432', schoenflies: 'O1', centrage: 'P' },
            { numero: 208, hermann_mauguin: 'P4232', schoenflies: 'O2', centrage: 'P' },
            { numero: 209, hermann_mauguin: 'F432', schoenflies: 'O3', centrage: 'F' },
            { numero: 210, hermann_mauguin: 'F4132', schoenflies: 'O4', centrage: 'F' },
            { numero: 211, hermann_mauguin: 'I432', schoenflies: 'O5', centrage: 'I' },
            { numero: 212, hermann_mauguin: 'P4332', schoenflies: 'O6', centrage: 'P' },
            { numero: 213, hermann_mauguin: 'P4132', schoenflies: 'O7', centrage: 'P' },
            { numero: 214, hermann_mauguin: 'I4132', schoenflies: 'O8', centrage: 'I' },
            { numero: 215, hermann_mauguin: 'P-43m', schoenflies: 'Td1', centrage: 'P' },
            { numero: 216, hermann_mauguin: 'F-43m', schoenflies: 'Td2', centrage: 'F' },
            { numero: 217, hermann_mauguin: 'I-43m', schoenflies: 'Td3', centrage: 'I' },
            { numero: 218, hermann_mauguin: 'P-43n', schoenflies: 'Td4', centrage: 'P' },
            { numero: 219, hermann_mauguin: 'F-43c', schoenflies: 'Td5', centrage: 'F' },
            { numero: 220, hermann_mauguin: 'I-43d', schoenflies: 'Td6', centrage: 'I' },
            { numero: 221, hermann_mauguin: 'Pm-3m', schoenflies: 'Oh1', centrage: 'P', note: 'Cubique simple (Po, CsCl)' },
            { numero: 222, hermann_mauguin: 'Pn-3n', schoenflies: 'Oh2', centrage: 'P' },
            { numero: 223, hermann_mauguin: 'Pm-3n', schoenflies: 'Oh3', centrage: 'P' },
            { numero: 224, hermann_mauguin: 'Pn-3m', schoenflies: 'Oh4', centrage: 'P' },
            { numero: 225, hermann_mauguin: 'Fm-3m', schoenflies: 'Oh5', centrage: 'F', note: 'FCC (Cu, Ag, Au, NaCl, pérovskites)' },
            { numero: 226, hermann_mauguin: 'Fm-3c', schoenflies: 'Oh6', centrage: 'F' },
            { numero: 227, hermann_mauguin: 'Fd-3m', schoenflies: 'Oh7', centrage: 'F', note: 'Diamant (C, Si, Ge)' },
            { numero: 228, hermann_mauguin: 'Fd-3c', schoenflies: 'Oh8', centrage: 'F' },
            { numero: 229, hermann_mauguin: 'Im-3m', schoenflies: 'Oh9', centrage: 'I', note: 'BCC (Fe, Cr, W)' },
            { numero: 230, hermann_mauguin: 'Ia-3d', schoenflies: 'Oh10', centrage: 'I' }
        ]
    }
};

// ═══════════════════════════════════════════════════════════════════════
// FONCTIONS UTILITAIRES
// ═══════════════════════════════════════════════════════════════════════

/**
 * Obtenir tous les groupes d'espace pour un ibrav donné
 */
function obtenirGroupesEspace(ibrav) {
    for (const [systeme, data] of Object.entries(GROUPES_ESPACE_COMPLETS)) {
        if (data.ibrav.includes(parseInt(ibrav))) {
            return data.groupes;
        }
    }
    return [];
}

/**
 * Obtenir le nombre total de groupes d'espace pour un ibrav
 */
function compterGroupesEspace(ibrav) {
    for (const [systeme, data] of Object.entries(GROUPES_ESPACE_COMPLETS)) {
        if (data.ibrav.includes(parseInt(ibrav))) {
            return data.nombre_groupes;
        }
    }
    return 0;
}

/**
 * Obtenir un groupe d'espace par son numéro
 */
function obtenirGroupeEspaceParNumero(numero) {
    for (const [systeme, data] of Object.entries(GROUPES_ESPACE_COMPLETS)) {
        const groupe = data.groupes.find(g => g.numero === numero);
        if (groupe) {
            return { ...groupe, systeme };
        }
    }
    return null;
}

/**
 * Générer la liste HTML formatée des groupes d'espace
 */
function genererListeGroupesEspaceHTML(ibrav) {
    const groupes = obtenirGroupesEspace(ibrav);
    if (groupes.length === 0) return '<p>Aucun groupe d\'espace trouvé</p>';
    
    let html = '<div style="max-height: 300px; overflow-y: auto; font-size: 0.9em;">';
    html += '<table style="width: 100%; border-collapse: collapse;">';
    html += '<thead><tr style="background: #e0e0e0; position: sticky; top: 0;">';
    html += '<th style="padding: 5px; text-align: left;">#</th>';
    html += '<th style="padding: 5px; text-align: left;">Hermann-Mauguin</th>';
    html += '<th style="padding: 5px; text-align: left;">Schoenflies</th>';
    if (groupes[0].centrage) html += '<th style="padding: 5px; text-align: center;">Centrage</th>';
    html += '</tr></thead><tbody>';
    
    for (const groupe of groupes) {
        const style = groupe.note ? 'background: #fff9c4; font-weight: bold;' : '';
        html += `<tr style="${style}">`;
        html += `<td style="padding: 5px;">${groupe.numero}</td>`;
        html += `<td style="padding: 5px; font-family: monospace;">${groupe.hermann_mauguin}</td>`;
        html += `<td style="padding: 5px; font-family: monospace; font-size: 0.85em;">${groupe.schoenflies}</td>`;
        if (groupe.centrage) html += `<td style="padding: 5px; text-align: center;">${groupe.centrage}</td>`;
        html += '</tr>';
        if (groupe.note) {
            html += `<tr style="${style}"><td colspan="${groupe.centrage ? 4 : 3}" style="padding: 2px 5px; font-size: 0.85em;">💡 ${groupe.note}</td></tr>`;
        }
    }
    
    html += '</tbody></table></div>';
    return html;
}

// Export pour utilisation dans l'interface
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        GROUPES_ESPACE_COMPLETS,
        obtenirGroupesEspace,
        compterGroupesEspace,
        obtenirGroupeEspaceParNumero,
        genererListeGroupesEspaceHTML
    };
}



/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * SCRIPT D'ANALYSE DES RÉSULTATS QUANTUM ESPRESSO
 * ═══════════════════════════════════════════════════════════════════════════════
 * 
 * Ce script gère:
 * 1. L'extraction et l'analyse des paramètres de chaque type de calcul
 * 2. Les visualisations interactives (Bandes, DOS, Phonons)
 * 3. L'affichage organisé des résultats
 * 
 * @version 2.0.0 - Architecture locale (sans Docker)
 */

// ═══════════════════════════════════════════════════════════════════════════════
// VARIABLES GLOBALES
// ═══════════════════════════════════════════════════════════════════════════════

const OUTPUTS_DIR = '/home/hiadsi/Interface-QE_v1/outputs';
const API_BASE = 'http://localhost:5007';

let resultatsCharges = {};
let graphiquesActifs = {};

// ═══════════════════════════════════════════════════════════════════════════════
// 1. INITIALISATION DE L'ONGLET RÉSULTATS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Initialise l'onglet Résultats avec la structure organisée
 */
function initialiserOngletResultats() {
    console.log('📊 Initialisation de l\'onglet Résultats...');
    
    const container = document.getElementById('tab_content_3');
    if (!container) {
        console.warn('⚠️ Container onglet 3 non trouvé');
        return;
    }
    
    container.innerHTML = genererStructureResultats();
    chargerListeCalculs();
}

/**
 * Génère la structure HTML de l'onglet Résultats
 */
function genererStructureResultats() {
    return `
    <!-- En-tête de l'onglet -->
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px; border-radius: 15px; margin-bottom: 25px; text-align: center;">
        <h1 style="margin: 0; font-size: 2em;">📊 Analyse des Résultats</h1>
        <p style="margin: 10px 0 0 0; opacity: 0.9; font-size: 1.1em;">Extraction des paramètres • Visualisations interactives • Export des données</p>
    </div>
    
    <!-- Navigation par sous-sections -->
    <div style="display: flex; gap: 10px; margin-bottom: 25px; flex-wrap: wrap; justify-content: center;">
        <button class="btn-resultats-nav active" onclick="afficherSousSection('analyse_calculs')" id="btn_nav_analyse">
            📋 Analyse des Calculs
        </button>
        <button class="btn-resultats-nav" onclick="afficherSousSection('visualisations')" id="btn_nav_visu">
            📈 Visualisations
        </button>
        <button class="btn-resultats-nav" onclick="afficherSousSection('export_donnees')" id="btn_nav_export">
            💾 Export des Données
        </button>
    </div>
    
    <!-- ═══════════════════════════════════════════════════════════════════════════ -->
    <!-- SECTION 1: ANALYSE DES CALCULS -->
    <!-- ═══════════════════════════════════════════════════════════════════════════ -->
    <div id="section_analyse_calculs" class="section-resultats">
        <div class="card" style="border: 2px solid #4CAF50;">
            <h3 style="color: #2e7d32;">📂 Sélectionner un Calcul à Analyser</h3>
            
            <!-- Sélection du matériau/calcul -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                <div>
                    <label style="font-weight: bold; display: block; margin-bottom: 8px;">📁 Matériau / Dossier:</label>
                    <select id="select_materiau_analyse" onchange="chargerCalculsMateriau()" 
                            style="width: 100%; padding: 12px; border: 2px solid #4CAF50; border-radius: 8px; font-size: 1em;">
                        <option value="">-- Chargement... --</option>
                    </select>
                </div>
                <div>
                    <label style="font-weight: bold; display: block; margin-bottom: 8px;">📄 Fichier Output:</label>
                    <select id="select_fichier_output" onchange="chargerAnalyseCalcul()" 
                            style="width: 100%; padding: 12px; border: 2px solid #4CAF50; border-radius: 8px; font-size: 1em;">
                        <option value="">-- Sélectionner d'abord un matériau --</option>
                    </select>
                </div>
            </div>
            
            <div style="text-align: center;">
                <button class="btn btn-primary" onclick="rafraichirListeCalculs()" style="margin-right: 10px;">
                    🔄 Rafraîchir la Liste
                </button>
                <button class="btn btn-success" onclick="analyserTousLesCalculs()">
                    📊 Analyser Tous les Calculs du Matériau
                </button>
            </div>
        </div>
        
        <!-- Zone d'affichage de l'analyse -->
        <div id="zone_analyse_resultats" style="margin-top: 25px;">
            <div class="alert alert-info" style="text-align: center;">
                <div style="font-size: 3em; margin-bottom: 15px;">📊</div>
                <strong>Sélectionnez un calcul pour voir l'analyse détaillée</strong>
                <p style="color: #666; margin-top: 10px;">Les paramètres extraits seront affichés ici avec des indicateurs visuels.</p>
            </div>
        </div>
    </div>
    
    <!-- ═══════════════════════════════════════════════════════════════════════════ -->
    <!-- SECTION 2: VISUALISATIONS -->
    <!-- ═══════════════════════════════════════════════════════════════════════════ -->
    <div id="section_visualisations" class="section-resultats" style="display: none;">
        
        <!-- Navigation par type de graphique -->
        <div style="display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap;">
            <button class="btn-visu-type active" onclick="afficherTypeVisu('bandes')" id="btn_visu_bandes">
                📉 Structure de Bandes
            </button>
            <button class="btn-visu-type" onclick="afficherTypeVisu('dos')" id="btn_visu_dos">
                📊 Densité d'États (DOS)
            </button>
            <button class="btn-visu-type" onclick="afficherTypeVisu('phonons')" id="btn_visu_phonons">
                🔊 Dispersion Phonons
            </button>
            <button class="btn-visu-type" onclick="afficherTypeVisu('energie')" id="btn_visu_energie">
                ⚡ Convergence Énergie
            </button>
        </div>
        
        <!-- Zone de visualisation Bandes -->
        <div id="visu_bandes" class="zone-visualisation">
            <div class="card" style="border: 2px solid #2196F3;">
                <h3 style="color: #1976d2;">📉 Structure de Bandes Électroniques</h3>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                    <div>
                        <label style="font-weight: bold; display: block; margin-bottom: 5px;">📁 Matériau:</label>
                        <select id="select_mat_bandes" onchange="chargerFichiersBandes()" 
                                style="width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #ddd;">
                            <option value="">-- Sélectionner --</option>
                        </select>
                    </div>
                    <div>
                        <label style="font-weight: bold; display: block; margin-bottom: 5px;">📄 Fichier bands.dat:</label>
                        <select id="select_fichier_bandes" 
                                style="width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #ddd;">
                            <option value="">-- Sélectionner un matériau --</option>
                        </select>
                    </div>
                </div>
                
                <!-- Options de tracé -->
                <div style="background: #e3f2fd; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <h4 style="margin: 0 0 10px 0; color: #1976d2;">⚙️ Options de Tracé</h4>
                    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px;">
                        <div>
                            <label style="font-size: 0.9em;">E_min (eV):</label>
                            <input type="number" id="bandes_emin" value="-10" style="width: 100%; padding: 5px; border-radius: 4px; border: 1px solid #ddd;">
                        </div>
                        <div>
                            <label style="font-size: 0.9em;">E_max (eV):</label>
                            <input type="number" id="bandes_emax" value="10" style="width: 100%; padding: 5px; border-radius: 4px; border: 1px solid #ddd;">
                        </div>
                        <div>
                            <label style="font-size: 0.9em;">E_fermi (eV):</label>
                            <input type="number" id="bandes_efermi" value="0" step="0.001" style="width: 100%; padding: 5px; border-radius: 4px; border: 1px solid #ddd;">
                        </div>
                        <div>
                            <label style="font-size: 0.9em;">Épaisseur ligne:</label>
                            <input type="number" id="bandes_linewidth" value="1.5" step="0.5" min="0.5" max="5" style="width: 100%; padding: 5px; border-radius: 4px; border: 1px solid #ddd;">
                        </div>
                    </div>
                </div>
                
                <div style="text-align: center; margin-bottom: 20px;">
                    <button class="btn btn-primary" onclick="tracerBandes()" style="padding: 15px 40px; font-size: 1.1em;">
                        📈 Tracer les Bandes
                    </button>
                </div>
                
                <!-- Zone du graphique -->
                <div id="graphique_bandes" style="width: 100%; height: 500px; background: #fafafa; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                    <div style="text-align: center; color: #999;">
                        <div style="font-size: 4em;">📉</div>
                        <p>Sélectionnez un fichier et cliquez sur "Tracer"</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Zone de visualisation DOS -->
        <div id="visu_dos" class="zone-visualisation" style="display: none;">
            <div class="card" style="border: 2px solid #FF9800;">
                <h3 style="color: #f57c00;">📊 Densité d'États (DOS)</h3>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                    <div>
                        <label style="font-weight: bold; display: block; margin-bottom: 5px;">📁 Matériau:</label>
                        <select id="select_mat_dos" onchange="chargerFichiersDOS()" 
                                style="width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #ddd;">
                            <option value="">-- Sélectionner --</option>
                        </select>
                    </div>
                    <div>
                        <label style="font-weight: bold; display: block; margin-bottom: 5px;">📄 Fichier DOS:</label>
                        <select id="select_fichier_dos" 
                                style="width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #ddd;">
                            <option value="">-- Sélectionner un matériau --</option>
                        </select>
                    </div>
                </div>
                
                <!-- Options -->
                <div style="background: #fff3e0; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <h4 style="margin: 0 0 10px 0; color: #f57c00;">⚙️ Options de Tracé</h4>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;">
                        <div>
                            <label style="font-size: 0.9em;">E_min (eV):</label>
                            <input type="number" id="dos_emin" value="-10" style="width: 100%; padding: 5px; border-radius: 4px; border: 1px solid #ddd;">
                        </div>
                        <div>
                            <label style="font-size: 0.9em;">E_max (eV):</label>
                            <input type="number" id="dos_emax" value="10" style="width: 100%; padding: 5px; border-radius: 4px; border: 1px solid #ddd;">
                        </div>
                        <div>
                            <label style="font-size: 0.9em;">Remplissage:</label>
                            <select id="dos_fill" style="width: 100%; padding: 5px; border-radius: 4px; border: 1px solid #ddd;">
                                <option value="tozeroy">Avec remplissage</option>
                                <option value="none">Sans remplissage</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div style="text-align: center; margin-bottom: 20px;">
                    <button class="btn btn-warning" onclick="tracerDOS()" style="padding: 15px 40px; font-size: 1.1em; color: white;">
                        📊 Tracer le DOS
                    </button>
                </div>
                
                <div id="graphique_dos" style="width: 100%; height: 500px; background: #fafafa; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                    <div style="text-align: center; color: #999;">
                        <div style="font-size: 4em;">📊</div>
                        <p>Sélectionnez un fichier et cliquez sur "Tracer"</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Zone de visualisation Phonons -->
        <div id="visu_phonons" class="zone-visualisation" style="display: none;">
            <div class="card" style="border: 2px solid #9C27B0;">
                <h3 style="color: #7b1fa2;">🔊 Dispersion des Phonons</h3>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                    <div>
                        <label style="font-weight: bold; display: block; margin-bottom: 5px;">📁 Matériau:</label>
                        <select id="select_mat_phonons" onchange="chargerFichiersPhonons()" 
                                style="width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #ddd;">
                            <option value="">-- Sélectionner --</option>
                        </select>
                    </div>
                    <div>
                        <label style="font-weight: bold; display: block; margin-bottom: 5px;">📄 Fichier matdyn.freq:</label>
                        <select id="select_fichier_phonons" 
                                style="width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #ddd;">
                            <option value="">-- Sélectionner un matériau --</option>
                        </select>
                    </div>
                </div>
                
                <!-- Options phonons -->
                <div style="background: #f3e5f5; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <h4 style="margin: 0 0 10px 0; color: #7b1fa2;">⚙️ Options de Tracé</h4>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;">
                        <div>
                            <label style="font-size: 0.9em;">ω_min (cm⁻¹):</label>
                            <input type="number" id="phonons_wmin" value="0" style="width: 100%; padding: 5px; border-radius: 4px; border: 1px solid #ddd;">
                        </div>
                        <div>
                            <label style="font-size: 0.9em;">ω_max (cm⁻¹):</label>
                            <input type="number" id="phonons_wmax" value="1000" style="width: 100%; padding: 5px; border-radius: 4px; border: 1px solid #ddd;">
                        </div>
                        <div>
                            <label style="font-size: 0.9em;">Afficher modes:</label>
                            <select id="phonons_modes" style="width: 100%; padding: 5px; border-radius: 4px; border: 1px solid #ddd;">
                                <option value="all">Tous les modes</option>
                                <option value="acoustic">Acoustiques seulement</option>
                                <option value="optical">Optiques seulement</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div style="text-align: center; margin-bottom: 20px;">
                    <button class="btn" onclick="tracerPhonons()" style="padding: 15px 40px; font-size: 1.1em; background: linear-gradient(135deg, #9C27B0, #673AB7); color: white;">
                        🔊 Tracer la Dispersion Phonons
                    </button>
                </div>
                
                <div id="graphique_phonons" style="width: 100%; height: 500px; background: #fafafa; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                    <div style="text-align: center; color: #999;">
                        <div style="font-size: 4em;">🔊</div>
                        <p>Sélectionnez un fichier et cliquez sur "Tracer"</p>
                    </div>
                </div>
                
                <!-- PHDOS -->
                <div style="margin-top: 25px; padding-top: 25px; border-top: 2px dashed #9C27B0;">
                    <h4 style="color: #7b1fa2;">📊 Densité d'États des Phonons (PHDOS)</h4>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                        <div>
                            <label style="font-size: 0.9em;">Fichier PHDOS:</label>
                            <select id="select_fichier_phdos" style="width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #ddd;">
                                <option value="">-- Sélectionner un matériau d'abord --</option>
                            </select>
                        </div>
                        <div style="display: flex; align-items: flex-end;">
                            <button class="btn btn-secondary" onclick="tracerPHDOS()" style="padding: 10px 30px;">
                                📊 Tracer PHDOS
                            </button>
                        </div>
                    </div>
                    <div id="graphique_phdos" style="width: 100%; height: 300px; background: #fafafa; border-radius: 8px;"></div>
                </div>
            </div>
        </div>
        
        <!-- Zone de visualisation Énergie/Convergence -->
        <div id="visu_energie" class="zone-visualisation" style="display: none;">
            <div class="card" style="border: 2px solid #4CAF50;">
                <h3 style="color: #2e7d32;">⚡ Convergence de l'Énergie</h3>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                    <div>
                        <label style="font-weight: bold; display: block; margin-bottom: 5px;">📁 Matériau:</label>
                        <select id="select_mat_energie" onchange="chargerFichiersEnergie()" 
                                style="width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #ddd;">
                            <option value="">-- Sélectionner --</option>
                        </select>
                    </div>
                    <div>
                        <label style="font-weight: bold; display: block; margin-bottom: 5px;">📄 Fichier Output:</label>
                        <select id="select_fichier_energie" 
                                style="width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #ddd;">
                            <option value="">-- Sélectionner un matériau --</option>
                        </select>
                    </div>
                </div>
                
                <div style="text-align: center; margin-bottom: 20px;">
                    <button class="btn btn-success" onclick="tracerConvergence()" style="padding: 15px 40px; font-size: 1.1em;">
                        ⚡ Tracer la Convergence
                    </button>
                </div>
                
                <div id="graphique_convergence" style="width: 100%; height: 400px; background: #fafafa; border-radius: 8px;"></div>
                
                <!-- Forces et Stress pour VC-RELAX -->
                <div style="margin-top: 25px; display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div>
                        <h4 style="color: #2e7d32;">📐 Convergence des Forces</h4>
                        <div id="graphique_forces" style="width: 100%; height: 250px; background: #fafafa; border-radius: 8px;"></div>
                    </div>
                    <div>
                        <h4 style="color: #2e7d32;">📊 Convergence du Stress</h4>
                        <div id="graphique_stress" style="width: 100%; height: 250px; background: #fafafa; border-radius: 8px;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- ═══════════════════════════════════════════════════════════════════════════ -->
    <!-- SECTION 3: EXPORT DES DONNÉES -->
    <!-- ═══════════════════════════════════════════════════════════════════════════ -->
    <div id="section_export_donnees" class="section-resultats" style="display: none;">
        <div class="card" style="border: 2px solid #607D8B;">
            <h3 style="color: #455A64;">💾 Export des Données et Graphiques</h3>
            
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-top: 20px;">
                <!-- Export CSV -->
                <div style="background: #e8f5e9; padding: 20px; border-radius: 10px; text-align: center;">
                    <div style="font-size: 3em; margin-bottom: 10px;">📄</div>
                    <h4 style="color: #2e7d32;">Export CSV</h4>
                    <p style="color: #666; font-size: 0.9em;">Données tabulaires pour Excel/LibreOffice</p>
                    <button class="btn btn-success" onclick="exporterCSV()" style="margin-top: 15px;">
                        💾 Télécharger CSV
                    </button>
                </div>
                
                <!-- Export JSON -->
                <div style="background: #e3f2fd; padding: 20px; border-radius: 10px; text-align: center;">
                    <div style="font-size: 3em; margin-bottom: 10px;">📋</div>
                    <h4 style="color: #1976d2;">Export JSON</h4>
                    <p style="color: #666; font-size: 0.9em;">Données structurées pour scripts Python</p>
                    <button class="btn btn-primary" onclick="exporterJSON()" style="margin-top: 15px;">
                        💾 Télécharger JSON
                    </button>
                </div>
                
                <!-- Export Image -->
                <div style="background: #fff3e0; padding: 20px; border-radius: 10px; text-align: center;">
                    <div style="font-size: 3em; margin-bottom: 10px;">🖼️</div>
                    <h4 style="color: #f57c00;">Export Graphiques</h4>
                    <p style="color: #666; font-size: 0.9em;">Images PNG haute résolution</p>
                    <button class="btn btn-warning" onclick="exporterGraphiques()" style="margin-top: 15px; color: white;">
                        🖼️ Télécharger PNG
                    </button>
                </div>
            </div>
            
            <!-- Rapport Complet -->
            <div style="margin-top: 30px; background: linear-gradient(135deg, #667eea, #764ba2); padding: 25px; border-radius: 10px; text-align: center; color: white;">
                <h3 style="margin: 0 0 15px 0;">📝 Génération du Rapport Complet</h3>
                <p style="opacity: 0.9; margin-bottom: 20px;">Créez un rapport PDF/HTML avec tous les résultats analysés</p>
                <button class="btn" onclick="genererRapport()" style="background: white; color: #764ba2; padding: 15px 50px; font-size: 1.1em; font-weight: bold;">
                    📝 Générer le Rapport
                </button>
            </div>
        </div>
    </div>
    
    <!-- Styles CSS -->
    <style>
        .btn-resultats-nav {
            padding: 12px 25px;
            border: 2px solid #667eea;
            background: white;
            color: #667eea;
            border-radius: 25px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .btn-resultats-nav:hover {
            background: #f0f0ff;
        }
        .btn-resultats-nav.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-color: transparent;
        }
        
        .btn-visu-type {
            padding: 10px 20px;
            border: 2px solid #2196F3;
            background: white;
            color: #2196F3;
            border-radius: 8px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .btn-visu-type:hover {
            background: #e3f2fd;
        }
        .btn-visu-type.active {
            background: #2196F3;
            color: white;
        }
        
        .section-resultats {
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .param-card {
            background: white;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .param-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }
        
        .status-success { color: #4CAF50; }
        .status-warning { color: #FF9800; }
        .status-error { color: #f44336; }
        .status-info { color: #2196F3; }
        
        @keyframes slideIn {
            from {
                transform: translateX(400px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(400px);
                opacity: 0;
            }
        }
    </style>
    `;
}

// ═══════════════════════════════════════════════════════════════════════════════
// 2. NAVIGATION ET AFFICHAGE
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Affiche une sous-section de l'onglet Résultats
 */
function afficherSousSection(section) {
    // Masquer toutes les sections
    document.querySelectorAll('.section-resultats').forEach(el => el.style.display = 'none');
    
    // Désactiver tous les boutons de navigation
    document.querySelectorAll('.btn-resultats-nav').forEach(btn => btn.classList.remove('active'));
    
    // Afficher la section demandée
    const sectionEl = document.getElementById('section_' + section);
    if (sectionEl) {
        sectionEl.style.display = 'block';
    }
    
    // Activer le bouton correspondant
    const btnId = section === 'analyse_calculs' ? 'btn_nav_analyse' : 
                  section === 'visualisations' ? 'btn_nav_visu' : 'btn_nav_export';
    const btn = document.getElementById(btnId);
    if (btn) {
        btn.classList.add('active');
    }
    
    // Charger les données si nécessaire
    if (section === 'visualisations') {
        chargerMateriauPourVisualisations();
    }
}

/**
 * Affiche un type de visualisation
 */
function afficherTypeVisu(type) {
    // Masquer toutes les zones de visualisation
    document.querySelectorAll('.zone-visualisation').forEach(el => el.style.display = 'none');
    
    // Désactiver tous les boutons
    document.querySelectorAll('.btn-visu-type').forEach(btn => btn.classList.remove('active'));
    
    // Afficher la zone demandée
    const zone = document.getElementById('visu_' + type);
    if (zone) {
        zone.style.display = 'block';
    }
    
    // Activer le bouton
    const btn = document.getElementById('btn_visu_' + type);
    if (btn) {
        btn.classList.add('active');
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 3. CHARGEMENT DES CALCULS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Charge la liste des calculs disponibles
 */
async function chargerListeCalculs() {
    try {
        const response = await fetch(`${API_BASE}/api/lister_outputs`);
        const data = await response.json();
        
        if (data.success && data.materiaux) {
            const select = document.getElementById('select_materiau_analyse');
            if (select) {
                select.innerHTML = '<option value="">-- Sélectionner un matériau --</option>';
                data.materiaux.forEach(mat => {
                    select.innerHTML += `<option value="${mat}">${mat}</option>`;
                });
            }
            
            // Mettre à jour aussi les sélecteurs de visualisation
            ['bandes', 'dos', 'phonons', 'energie'].forEach(type => {
                const sel = document.getElementById(`select_mat_${type}`);
                if (sel) {
                    sel.innerHTML = '<option value="">-- Sélectionner --</option>';
                    data.materiaux.forEach(mat => {
                        sel.innerHTML += `<option value="${mat}">${mat}</option>`;
                    });
                }
            });
        }
    } catch (error) {
        console.error('Erreur chargement calculs:', error);
    }
}

/**
 * Rafraîchit la liste des calculs
 */
function rafraichirListeCalculs() {
    chargerListeCalculs();
    afficherNotification('🔄 Liste des calculs actualisée', 'success');
}

/**
 * Charge les fichiers outputs d'un matériau
 */
async function chargerCalculsMateriau() {
    const materiau = document.getElementById('select_materiau_analyse').value;
    const select = document.getElementById('select_fichier_output');
    
    if (!materiau) {
        select.innerHTML = '<option value="">-- Sélectionner d\'abord un matériau --</option>';
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/api/executer_commande`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ commande: `ls -la ${OUTPUTS_DIR}/${materiau}/*.out 2>/dev/null` })
        });
        const data = await response.json();
        
        if (data.success && data.stdout) {
            const fichiers = data.stdout.split('\n')
                .filter(line => line.includes('.out'))
                .map(line => {
                    const parts = line.split(' ');
                    return parts[parts.length - 1].split('/').pop();
                })
                .filter(f => f);
            
            select.innerHTML = '<option value="">-- Sélectionner un fichier --</option>';
            fichiers.forEach(f => {
                select.innerHTML += `<option value="${f}">${f}</option>`;
            });
        } else {
            select.innerHTML = '<option value="">Aucun fichier .out trouvé</option>';
        }
    } catch (error) {
        console.error('Erreur:', error);
        select.innerHTML = '<option value="">Erreur de chargement</option>';
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 4. ANALYSE DES CALCULS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Charge et analyse un fichier output
 */
async function chargerAnalyseCalcul() {
    const materiau = document.getElementById('select_materiau_analyse').value;
    const fichier = document.getElementById('select_fichier_output').value;
    
    if (!materiau || !fichier) return;
    
    const zone = document.getElementById('zone_analyse_resultats');
    zone.innerHTML = `
        <div class="alert alert-info" style="text-align: center;">
            <div class="spinner" style="margin: 20px auto; width: 40px; height: 40px; border: 4px solid #ddd; border-top-color: #2196F3; border-radius: 50%; animation: spin 1s linear infinite;"></div>
            <strong>Analyse en cours...</strong>
        </div>
        <style>
            @keyframes spin { to { transform: rotate(360deg); } }
        </style>
    `;
    
    try {
        const response = await fetch(`${API_BASE}/api/executer_commande`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ commande: `cat ${OUTPUTS_DIR}/${materiau}/${fichier}` })
        });
        const data = await response.json();
        
        if (data.success && data.stdout) {
            const analyse = analyserOutputQE(data.stdout, fichier);
            zone.innerHTML = genererAffichageAnalyse(analyse, materiau, fichier);
            resultatsCharges[`${materiau}/${fichier}`] = analyse;
        } else {
            zone.innerHTML = `<div class="alert alert-danger">❌ Impossible de lire le fichier</div>`;
        }
    } catch (error) {
        zone.innerHTML = `<div class="alert alert-danger">❌ Erreur: ${error.message}</div>`;
    }
}

/**
 * Analyse le contenu d'un fichier output QE
 */
function analyserOutputQE(content, filename) {
    const analyse = {
        type: detecterTypeCalcul(content, filename),
        converge: content.includes('convergence has been achieved') || content.includes('JOB DONE'),
        energie: {},
        structure: {},
        forces: {},
        temps: {},
        bandes: {},
        phonons: {},
        thermodynamique: {}
    };
    
    // Extraire l'énergie totale
    const energieMatch = content.match(/!\s+total energy\s*=\s*([-\d.]+)\s*Ry/);
    if (energieMatch) {
        analyse.energie.total_Ry = parseFloat(energieMatch[1]);
        analyse.energie.total_eV = analyse.energie.total_Ry * 13.605693;
    }
    
    // Énergie de Fermi
    const fermiMatch = content.match(/the Fermi energy is\s+([-\d.]+)\s*ev/i);
    if (fermiMatch) {
        analyse.energie.fermi_eV = parseFloat(fermiMatch[1]);
    }
    
    // Gap (HOMO-LUMO)
    const gapMatch = content.match(/highest occupied.*:\s+([-\d.]+)\s+eV\s+.*lowest unoccupied.*:\s+([-\d.]+)\s+eV/i);
    if (gapMatch) {
        analyse.energie.homo = parseFloat(gapMatch[1]);
        analyse.energie.lumo = parseFloat(gapMatch[2]);
        analyse.energie.gap = analyse.energie.lumo - analyse.energie.homo;
    }
    
    // Paramètres de maille (après relaxation)
    const latMatch = content.match(/CELL_PARAMETERS\s*\(alat=\s*([\d.]+)\)/);
    if (latMatch) {
        analyse.structure.alat = parseFloat(latMatch[1]);
    }
    
    // Volume de la cellule
    const volMatch = content.match(/unit-cell volume\s*=\s*([\d.]+)/);
    if (volMatch) {
        analyse.structure.volume = parseFloat(volMatch[1]);
    }
    
    // Nombre d'atomes
    const natMatch = content.match(/number of atoms\/cell\s*=\s*(\d+)/);
    if (natMatch) {
        analyse.structure.nat = parseInt(natMatch[1]);
    }
    
    // Nombre d'électrons
    const nelecMatch = content.match(/number of electrons\s*=\s*([\d.]+)/);
    if (nelecMatch) {
        analyse.structure.nelectrons = parseFloat(nelecMatch[1]);
    }
    
    // Force maximale
    const forceMatches = content.match(/Total force\s*=\s*([\d.]+)/g);
    if (forceMatches && forceMatches.length > 0) {
        const forces = forceMatches.map(m => parseFloat(m.match(/[\d.]+/)[0]));
        analyse.forces.initial = forces[0];
        analyse.forces.final = forces[forces.length - 1];
        analyse.forces.convergence = forces;
    }
    
    // Pression/Stress
    const pressMatch = content.match(/total\s+stress\s*\(Ry\/bohr\*\*3\)\s*\(kbar\)\s*P=\s*([-\d.]+)/);
    if (pressMatch) {
        analyse.structure.pressure_kbar = parseFloat(pressMatch[1]);
    }
    
    // Temps de calcul
    const cpuMatch = content.match(/PWSCF\s*:\s*([\d\w\s.:]+)\s*CPU/);
    if (cpuMatch) {
        analyse.temps.cpu = cpuMatch[1].trim();
    }
    
    const wallMatch = content.match(/PWSCF\s*:.*CPU\s+([\d\w\s.:]+)\s*WALL/);
    if (wallMatch) {
        analyse.temps.wall = wallMatch[1].trim();
    }
    
    // Nombre d'itérations SCF
    const scfIterations = (content.match(/iteration #/g) || []).length;
    analyse.temps.scf_iterations = scfIterations;
    
    // Pour VC-RELAX: nombre de pas BFGS
    const bfgsSteps = (content.match(/bfgs converged|number of bfgs steps/gi) || []).length;
    if (bfgsSteps > 0 || analyse.type === 'vc-relax') {
        const allBfgs = content.match(/number of bfgs steps\s*=\s*(\d+)/g);
        if (allBfgs && allBfgs.length > 0) {
            const lastBfgs = allBfgs[allBfgs.length - 1];
            const bfgsMatch = lastBfgs.match(/(\d+)/);
            if (bfgsMatch) {
                analyse.temps.bfgs_steps = parseInt(bfgsMatch[1]);
            }
        }
    }
    
    // Cutoffs
    const ecutwfcMatch = content.match(/kinetic-energy cutoff\s*=\s*([\d.]+)/);
    const ecutrhMatch = content.match(/charge density cutoff\s*=\s*([\d.]+)/);
    if (ecutwfcMatch) analyse.structure.ecutwfc = parseFloat(ecutwfcMatch[1]);
    if (ecutrhMatch) analyse.structure.ecutrho = parseFloat(ecutrhMatch[1]);
    
    // Grille k-points
    const kpointsMatch = content.match(/number of k points=\s*(\d+)/);
    if (kpointsMatch) {
        analyse.structure.nkpoints = parseInt(kpointsMatch[1]);
    }
    
    // Magnétisation (si spin-polarisé)
    const magMatch = content.match(/total magnetization\s*=\s*([-\d.]+)/);
    if (magMatch) {
        analyse.structure.magnetization = parseFloat(magMatch[1]);
    }
    
    return analyse;
}

/**
 * Détecte le type de calcul à partir du contenu
 */
function detecterTypeCalcul(content, filename) {
    if (filename.includes('vc-relax') || content.includes('variable-cell') || content.includes('vc-relax')) {
        return 'vc-relax';
    } else if (filename.includes('relax') || content.includes("calculation='relax'")) {
        return 'relax';
    } else if (filename.includes('nscf') || content.includes("calculation='nscf'")) {
        return 'nscf';
    } else if (filename.includes('bands') || content.includes("calculation='bands'")) {
        return 'bands';
    } else if (content.includes('Program PHONON') || content.includes('Dynamical matrices')) {
        return 'phonon';
    } else {
        return 'scf';
    }
}

/**
 * Génère l'affichage visuel de l'analyse
 */
function genererAffichageAnalyse(analyse, materiau, fichier) {
    const typeLabels = {
        'vc-relax': { label: 'VC-RELAX', color: '#9C27B0', icon: '🔄' },
        'relax': { label: 'RELAX', color: '#673AB7', icon: '📐' },
        'scf': { label: 'SCF', color: '#2196F3', icon: '⚡' },
        'nscf': { label: 'NSCF', color: '#00BCD4', icon: '📊' },
        'bands': { label: 'BANDS', color: '#4CAF50', icon: '📉' },
        'phonon': { label: 'PHONON', color: '#FF9800', icon: '🔊' }
    };
    
    const typeInfo = typeLabels[analyse.type] || { label: analyse.type.toUpperCase(), color: '#607D8B', icon: '📄' };
    const statusIcon = analyse.converge ? '✅' : '⚠️';
    const statusText = analyse.converge ? 'Convergé avec succès' : 'Non convergé ou interrompu';
    const statusColor = analyse.converge ? '#4CAF50' : '#FF9800';
    
    let html = `
    <!-- En-tête de l'analyse -->
    <div style="background: linear-gradient(135deg, ${typeInfo.color}cc, ${typeInfo.color}); color: white; padding: 20px; border-radius: 15px 15px 0 0;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
            <div>
                <div style="font-size: 2em; display: flex; align-items: center; gap: 10px;">
                    ${typeInfo.icon} <span style="font-weight: bold;">${typeInfo.label}</span>
                </div>
                <div style="opacity: 0.9; margin-top: 5px;">${materiau} / ${fichier}</div>
            </div>
            <div style="text-align: right; background: rgba(255,255,255,0.2); padding: 10px 20px; border-radius: 10px;">
                <div style="font-size: 1.5em;">${statusIcon}</div>
                <div style="font-size: 0.9em;">${statusText}</div>
            </div>
        </div>
    </div>
    
    <!-- Corps de l'analyse -->
    <div style="background: white; border: 2px solid ${typeInfo.color}; border-top: none; border-radius: 0 0 15px 15px; padding: 25px;">
    `;
    
    // Section Énergie
    if (Object.keys(analyse.energie).length > 0) {
        html += `
        <div style="margin-bottom: 25px;">
            <h4 style="color: ${typeInfo.color}; border-bottom: 2px solid ${typeInfo.color}; padding-bottom: 10px; display: flex; align-items: center; gap: 10px;">
                ⚡ Énergie
            </h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
        `;
        
        if (analyse.energie.total_Ry) {
            html += `
                <div class="param-card" style="border-left: 4px solid #2196F3;">
                    <div style="color: #666; font-size: 0.85em;">Énergie Totale</div>
                    <div style="font-size: 1.3em; font-weight: bold; color: #1976d2;">${analyse.energie.total_Ry.toFixed(8)} Ry</div>
                    <div style="color: #666; font-size: 0.85em;">${analyse.energie.total_eV.toFixed(4)} eV</div>
                </div>
            `;
        }
        
        if (analyse.energie.fermi_eV !== undefined) {
            html += `
                <div class="param-card" style="border-left: 4px solid #4CAF50;">
                    <div style="color: #666; font-size: 0.85em;">Énergie de Fermi</div>
                    <div style="font-size: 1.3em; font-weight: bold; color: #2e7d32;">${analyse.energie.fermi_eV.toFixed(4)} eV</div>
                </div>
            `;
        }
        
        if (analyse.energie.gap !== undefined) {
            const gapType = analyse.energie.gap > 0 ? 'Isolant/Semi-conducteur' : 'Métal';
            const gapColor = analyse.energie.gap > 0 ? '#FF9800' : '#9C27B0';
            html += `
                <div class="param-card" style="border-left: 4px solid ${gapColor};">
                    <div style="color: #666; font-size: 0.85em;">Gap (HOMO-LUMO)</div>
                    <div style="font-size: 1.3em; font-weight: bold; color: ${gapColor};">${analyse.energie.gap.toFixed(4)} eV</div>
                    <div style="color: #666; font-size: 0.85em;">${gapType}</div>
                </div>
            `;
        }
        
        html += '</div></div>';
    }
    
    // Section Structure
    if (Object.keys(analyse.structure).length > 0) {
        html += `
        <div style="margin-bottom: 25px;">
            <h4 style="color: ${typeInfo.color}; border-bottom: 2px solid ${typeInfo.color}; padding-bottom: 10px; display: flex; align-items: center; gap: 10px;">
                🔬 Structure
            </h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-top: 15px;">
        `;
        
        if (analyse.structure.volume) {
            html += `
                <div class="param-card">
                    <div style="color: #666; font-size: 0.85em;">Volume Cellule</div>
                    <div style="font-size: 1.2em; font-weight: bold;">${analyse.structure.volume.toFixed(2)} (a.u.)³</div>
                </div>
            `;
        }
        
        if (analyse.structure.nat) {
            html += `
                <div class="param-card">
                    <div style="color: #666; font-size: 0.85em;">Nb. Atomes</div>
                    <div style="font-size: 1.2em; font-weight: bold;">${analyse.structure.nat}</div>
                </div>
            `;
        }
        
        if (analyse.structure.nelectrons) {
            html += `
                <div class="param-card">
                    <div style="color: #666; font-size: 0.85em;">Nb. Électrons</div>
                    <div style="font-size: 1.2em; font-weight: bold;">${analyse.structure.nelectrons}</div>
                </div>
            `;
        }
        
        if (analyse.structure.ecutwfc) {
            html += `
                <div class="param-card">
                    <div style="color: #666; font-size: 0.85em;">Cutoff (ecutwfc)</div>
                    <div style="font-size: 1.2em; font-weight: bold;">${analyse.structure.ecutwfc} Ry</div>
                </div>
            `;
        }
        
        if (analyse.structure.nkpoints) {
            html += `
                <div class="param-card">
                    <div style="color: #666; font-size: 0.85em;">Points k</div>
                    <div style="font-size: 1.2em; font-weight: bold;">${analyse.structure.nkpoints}</div>
                </div>
            `;
        }
        
        if (analyse.structure.pressure_kbar !== undefined) {
            const presColor = Math.abs(analyse.structure.pressure_kbar) < 1 ? '#4CAF50' : '#FF9800';
            html += `
                <div class="param-card" style="border-left: 4px solid ${presColor};">
                    <div style="color: #666; font-size: 0.85em;">Pression</div>
                    <div style="font-size: 1.2em; font-weight: bold; color: ${presColor};">${analyse.structure.pressure_kbar.toFixed(2)} kbar</div>
                </div>
            `;
        }
        
        if (analyse.structure.magnetization !== undefined) {
            html += `
                <div class="param-card" style="border-left: 4px solid #E91E63;">
                    <div style="color: #666; font-size: 0.85em;">Magnétisation</div>
                    <div style="font-size: 1.2em; font-weight: bold; color: #E91E63;">${analyse.structure.magnetization.toFixed(4)} μB</div>
                </div>
            `;
        }
        
        html += '</div></div>';
    }
    
    // Section Forces (pour relax/vc-relax)
    if (analyse.forces.final !== undefined) {
        const forceConverged = analyse.forces.final < 0.001;
        const forceColor = forceConverged ? '#4CAF50' : '#FF9800';
        html += `
        <div style="margin-bottom: 25px;">
            <h4 style="color: ${typeInfo.color}; border-bottom: 2px solid ${typeInfo.color}; padding-bottom: 10px;">
                📐 Forces
            </h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
                <div class="param-card" style="border-left: 4px solid #2196F3;">
                    <div style="color: #666; font-size: 0.85em;">Force Initiale</div>
                    <div style="font-size: 1.2em; font-weight: bold;">${analyse.forces.initial.toFixed(6)} Ry/Bohr</div>
                </div>
                <div class="param-card" style="border-left: 4px solid ${forceColor};">
                    <div style="color: #666; font-size: 0.85em;">Force Finale</div>
                    <div style="font-size: 1.2em; font-weight: bold; color: ${forceColor};">${analyse.forces.final.toFixed(6)} Ry/Bohr</div>
                    <div style="font-size: 0.85em; color: ${forceColor};">${forceConverged ? '✅ Convergé' : '⚠️ Non convergé'}</div>
                </div>
            </div>
        </div>
        `;
    }
    
    // Section Temps
    if (analyse.temps.cpu || analyse.temps.scf_iterations) {
        html += `
        <div style="margin-bottom: 25px;">
            <h4 style="color: ${typeInfo.color}; border-bottom: 2px solid ${typeInfo.color}; padding-bottom: 10px;">
                ⏱️ Temps d'Exécution
            </h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-top: 15px;">
        `;
        
        if (analyse.temps.cpu) {
            html += `
                <div class="param-card">
                    <div style="color: #666; font-size: 0.85em;">Temps CPU</div>
                    <div style="font-size: 1.1em; font-weight: bold;">${analyse.temps.cpu}</div>
                </div>
            `;
        }
        
        if (analyse.temps.wall) {
            html += `
                <div class="param-card">
                    <div style="color: #666; font-size: 0.85em;">Temps WALL</div>
                    <div style="font-size: 1.1em; font-weight: bold;">${analyse.temps.wall}</div>
                </div>
            `;
        }
        
        if (analyse.temps.scf_iterations) {
            html += `
                <div class="param-card">
                    <div style="color: #666; font-size: 0.85em;">Itérations SCF</div>
                    <div style="font-size: 1.1em; font-weight: bold;">${analyse.temps.scf_iterations}</div>
                </div>
            `;
        }
        
        if (analyse.temps.bfgs_steps) {
            html += `
                <div class="param-card">
                    <div style="color: #666; font-size: 0.85em;">Pas BFGS</div>
                    <div style="font-size: 1.1em; font-weight: bold;">${analyse.temps.bfgs_steps}</div>
                </div>
            `;
        }
        
        html += '</div></div>';
    }
    
    // Boutons d'action
    html += `
        <div style="margin-top: 30px; padding-top: 20px; border-top: 2px dashed #e0e0e0; display: flex; gap: 10px; flex-wrap: wrap; justify-content: center;">
            <button class="btn btn-primary" onclick="afficherSousSection('visualisations')">
                📈 Voir les Graphiques
            </button>
            <button class="btn btn-success" onclick="exporterAnalyse('${materiau}', '${fichier}')">
                💾 Exporter l'Analyse
            </button>
            <button class="btn btn-secondary" onclick="ouvrirSuiviCalcul('${analyse.type}')">
                📊 Voir le Log Complet
            </button>
        </div>
    `;
    
    html += '</div>';
    
    return html;
}

// ═══════════════════════════════════════════════════════════════════════════════
// 5. VISUALISATIONS (PLOTLY.JS)
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Charge les matériaux dans les sélecteurs de visualisation
 */
async function chargerMateriauPourVisualisations() {
    try {
        const response = await fetch(`${API_BASE}/api/lister_outputs`);
        const data = await response.json();
        
        if (data.success && data.materiaux) {
            ['bandes', 'dos', 'phonons', 'energie'].forEach(type => {
                const sel = document.getElementById(`select_mat_${type}`);
                if (sel && sel.options.length <= 1) {
                    sel.innerHTML = '<option value="">-- Sélectionner --</option>';
                    data.materiaux.forEach(mat => {
                        sel.innerHTML += `<option value="${mat}">${mat}</option>`;
                    });
                }
            });
        }
    } catch (error) {
        console.error('Erreur chargement matériaux:', error);
    }
}

/**
 * Charge les fichiers de bandes pour un matériau
 */
async function chargerFichiersBandes() {
    const materiau = document.getElementById('select_mat_bandes').value;
    const select = document.getElementById('select_fichier_bandes');
    
    if (!materiau) {
        select.innerHTML = '<option value="">-- Sélectionner un matériau --</option>';
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/api/executer_commande`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ commande: `find ${OUTPUTS_DIR}/${materiau} -name "*.bands.dat" -o -name "*bands*.dat" -o -name "bands.dat.gnu" 2>/dev/null` })
        });
        const data = await response.json();
        
        if (data.success && data.stdout) {
            const fichiers = data.stdout.trim().split('\n').filter(f => f);
            select.innerHTML = '<option value="">-- Sélectionner un fichier --</option>';
            fichiers.forEach(f => {
                const nom = f.split('/').pop();
                select.innerHTML += `<option value="${f}">${nom}</option>`;
            });
        } else {
            select.innerHTML = '<option value="">Aucun fichier .bands.dat trouvé</option>';
        }
    } catch (error) {
        select.innerHTML = '<option value="">Erreur</option>';
    }
}

/**
 * Trace les bandes électroniques avec Plotly
 */
async function tracerBandes() {
    const fichier = document.getElementById('select_fichier_bandes').value;
    const emin = parseFloat(document.getElementById('bandes_emin').value) || -10;
    const emax = parseFloat(document.getElementById('bandes_emax').value) || 10;
    const efermi = parseFloat(document.getElementById('bandes_efermi').value) || 0;
    const linewidth = parseFloat(document.getElementById('bandes_linewidth').value) || 1.5;
    
    if (!fichier) {
        afficherNotification('Veuillez sélectionner un fichier de bandes', 'warning');
        return;
    }
    
    const container = document.getElementById('graphique_bandes');
    container.innerHTML = '<div style="text-align: center; padding: 50px;"><div style="font-size: 2em;">⏳</div><p>Chargement des données...</p></div>';
    
    try {
        const response = await fetch(`${API_BASE}/api/executer_commande`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ commande: `cat "${fichier}"` })
        });
        const data = await response.json();
        
        if (!data.success || !data.stdout) {
            throw new Error('Impossible de lire le fichier');
        }
        
        // Parser les données
        const lignes = data.stdout.trim().split('\n');
        const bandes = [];
        let bandeCourante = [];
        
        lignes.forEach(ligne => {
            const values = ligne.trim().split(/\s+/);
            if (values.length >= 2 && !isNaN(parseFloat(values[0]))) {
                bandeCourante.push({
                    k: parseFloat(values[0]),
                    e: parseFloat(values[1]) - efermi
                });
            } else if (bandeCourante.length > 0) {
                bandes.push([...bandeCourante]);
                bandeCourante = [];
            }
        });
        if (bandeCourante.length > 0) {
            bandes.push(bandeCourante);
        }
        
        // Créer les traces Plotly
        const traces = bandes.map((bande, i) => ({
            x: bande.map(p => p.k),
            y: bande.map(p => p.e),
            mode: 'lines',
            line: { color: '#2196F3', width: linewidth },
            name: `Bande ${i + 1}`,
            showlegend: false,
            hovertemplate: 'k: %{x:.3f}<br>E: %{y:.3f} eV<extra></extra>'
        }));
        
        // Ligne de Fermi
        if (bandes.length > 0) {
            const kmin = Math.min(...bandes.flat().map(p => p.k));
            const kmax = Math.max(...bandes.flat().map(p => p.k));
            traces.push({
                x: [kmin, kmax],
                y: [0, 0],
                mode: 'lines',
                line: { color: 'red', width: 2, dash: 'dash' },
                name: 'Niveau de Fermi',
                showlegend: true
            });
        }
        
        const layout = {
            title: {
                text: '<b>Structure de Bandes Électroniques</b>',
                font: { size: 18 }
            },
            xaxis: {
                title: 'Points k',
                showgrid: true,
                gridcolor: '#e0e0e0'
            },
            yaxis: {
                title: 'Énergie (eV)',
                range: [emin, emax],
                showgrid: true,
                gridcolor: '#e0e0e0'
            },
            paper_bgcolor: 'white',
            plot_bgcolor: '#fafafa',
            margin: { t: 60, b: 50, l: 60, r: 30 },
            legend: { x: 1, xanchor: 'right', y: 1 }
        };
        
        Plotly.newPlot('graphique_bandes', traces, layout, { responsive: true });
        graphiquesActifs.bandes = true;
        
    } catch (error) {
        container.innerHTML = `<div style="text-align: center; padding: 50px; color: #f44336;"><div style="font-size: 2em;">❌</div><p>Erreur: ${error.message}</p></div>`;
    }
}

/**
 * Charge les fichiers DOS pour un matériau
 */
async function chargerFichiersDOS() {
    const materiau = document.getElementById('select_mat_dos').value;
    const select = document.getElementById('select_fichier_dos');
    
    if (!materiau) {
        select.innerHTML = '<option value="">-- Sélectionner un matériau --</option>';
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/api/executer_commande`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ commande: `find ${OUTPUTS_DIR}/${materiau} -name "*.dos" -o -name "*dos*.dat" -o -name "*.pdos*" 2>/dev/null` })
        });
        const data = await response.json();
        
        if (data.success && data.stdout) {
            const fichiers = data.stdout.trim().split('\n').filter(f => f);
            select.innerHTML = '<option value="">-- Sélectionner un fichier --</option>';
            fichiers.forEach(f => {
                const nom = f.split('/').pop();
                select.innerHTML += `<option value="${f}">${nom}</option>`;
            });
        } else {
            select.innerHTML = '<option value="">Aucun fichier DOS trouvé</option>';
        }
    } catch (error) {
        select.innerHTML = '<option value="">Erreur</option>';
    }
}

/**
 * Trace le DOS avec Plotly
 */
async function tracerDOS() {
    const fichier = document.getElementById('select_fichier_dos').value;
    const emin = parseFloat(document.getElementById('dos_emin').value) || -10;
    const emax = parseFloat(document.getElementById('dos_emax').value) || 10;
    const fill = document.getElementById('dos_fill').value;
    
    if (!fichier) {
        afficherNotification('Veuillez sélectionner un fichier DOS', 'warning');
        return;
    }
    
    const container = document.getElementById('graphique_dos');
    container.innerHTML = '<div style="text-align: center; padding: 50px;"><div style="font-size: 2em;">⏳</div><p>Chargement des données...</p></div>';
    
    try {
        const response = await fetch(`${API_BASE}/api/executer_commande`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ commande: `cat "${fichier}"` })
        });
        const data = await response.json();
        
        if (!data.success || !data.stdout) {
            throw new Error('Impossible de lire le fichier');
        }
        
        // Parser les données
        const lignes = data.stdout.trim().split('\n');
        const energies = [];
        const dos_values = [];
        
        lignes.forEach(ligne => {
            if (ligne.startsWith('#')) return;
            const values = ligne.trim().split(/\s+/);
            if (values.length >= 2 && !isNaN(parseFloat(values[0]))) {
                energies.push(parseFloat(values[0]));
                dos_values.push(parseFloat(values[1]));
            }
        });
        
        const traces = [{
            x: dos_values,
            y: energies,
            mode: 'lines',
            fill: fill,
            fillcolor: 'rgba(255, 107, 107, 0.3)',
            line: { color: '#FF6B6B', width: 2 },
            name: 'DOS',
            hovertemplate: 'DOS: %{x:.3f} états/eV<br>E: %{y:.3f} eV<extra></extra>'
        }];
        
        // Ligne de Fermi (verticale à E=0)
        if (energies.length > 0) {
            const dosMax = Math.max(...dos_values) * 1.1;
        traces.push({
                x: [0, dosMax],
            y: [0, 0],
            mode: 'lines',
            line: { color: 'red', width: 2, dash: 'dash' },
            name: 'Niveau de Fermi'
        });
        }
        
        const layout = {
            title: {
                text: '<b>Densité d\'États (DOS)</b>',
                font: { size: 18 }
            },
            xaxis: {
                title: 'DOS (états/eV)',
                showgrid: true,
                gridcolor: '#e0e0e0'
            },
            yaxis: {
                title: 'Énergie (eV)',
                range: [emin, emax],
                showgrid: true,
                gridcolor: '#e0e0e0'
            },
            paper_bgcolor: 'white',
            plot_bgcolor: '#fafafa',
            margin: { t: 60, b: 50, l: 60, r: 30 },
            legend: { x: 1, xanchor: 'right', y: 1 }
        };
        
        Plotly.newPlot('graphique_dos', traces, layout, { responsive: true });
        graphiquesActifs.dos = true;
        
    } catch (error) {
        container.innerHTML = `<div style="text-align: center; padding: 50px; color: #f44336;"><div style="font-size: 2em;">❌</div><p>Erreur: ${error.message}</p></div>`;
    }
}

/**
 * Charge les fichiers de phonons pour un matériau
 */
async function chargerFichiersPhonons() {
    const materiau = document.getElementById('select_mat_phonons').value;
    const selectFreq = document.getElementById('select_fichier_phonons');
    const selectPhdos = document.getElementById('select_fichier_phdos');
    
    if (!materiau) {
        selectFreq.innerHTML = '<option value="">-- Sélectionner un matériau --</option>';
        selectPhdos.innerHTML = '<option value="">-- Sélectionner un matériau --</option>';
        return;
    }
    
    try {
        // Fichiers freq/dispersion
        const respFreq = await fetch(`${API_BASE}/api/executer_commande`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ commande: `find ${OUTPUTS_DIR}/${materiau} -name "*.freq" -o -name "*matdyn*" -o -name "*phonon*.dat" 2>/dev/null` })
        });
        const dataFreq = await respFreq.json();
        
        if (dataFreq.success && dataFreq.stdout) {
            const fichiers = dataFreq.stdout.trim().split('\n').filter(f => f);
            selectFreq.innerHTML = '<option value="">-- Sélectionner --</option>';
            fichiers.forEach(f => {
                const nom = f.split('/').pop();
                selectFreq.innerHTML += `<option value="${f}">${nom}</option>`;
            });
        }
        
        // Fichiers PHDOS
        const respPhdos = await fetch(`${API_BASE}/api/executer_commande`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ commande: `find ${OUTPUTS_DIR}/${materiau} -name "*phdos*" -o -name "*dos_ph*" 2>/dev/null` })
        });
        const dataPhdos = await respPhdos.json();
        
        if (dataPhdos.success && dataPhdos.stdout) {
            const fichiers = dataPhdos.stdout.trim().split('\n').filter(f => f);
            selectPhdos.innerHTML = '<option value="">-- Sélectionner --</option>';
            fichiers.forEach(f => {
                const nom = f.split('/').pop();
                selectPhdos.innerHTML += `<option value="${f}">${nom}</option>`;
            });
        }
        
    } catch (error) {
        console.error('Erreur:', error);
    }
}

/**
 * Trace la dispersion des phonons
 */
async function tracerPhonons() {
    const fichier = document.getElementById('select_fichier_phonons').value;
    const wmin = parseFloat(document.getElementById('phonons_wmin').value) || 0;
    const wmax = parseFloat(document.getElementById('phonons_wmax').value) || 1000;
    
    if (!fichier) {
        afficherNotification('Veuillez sélectionner un fichier de fréquences phonons', 'warning');
        return;
    }
    
    const container = document.getElementById('graphique_phonons');
    container.innerHTML = '<div style="text-align: center; padding: 50px;"><div style="font-size: 2em;">⏳</div><p>Chargement...</p></div>';
    
    try {
        const response = await fetch(`${API_BASE}/api/executer_commande`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ commande: `cat "${fichier}"` })
        });
        const data = await response.json();
        
        if (!data.success || !data.stdout) {
            throw new Error('Impossible de lire le fichier');
        }
        
        // Parser les données phonons
        const lignes = data.stdout.trim().split('\n');
        const modes = [];
        let modeCourant = [];
        
        lignes.forEach(ligne => {
            if (ligne.startsWith('#') || ligne.trim() === '') {
                if (modeCourant.length > 0) {
                    modes.push([...modeCourant]);
                    modeCourant = [];
                }
                return;
            }
            
            const values = ligne.trim().split(/\s+/);
            if (values.length >= 2 && !isNaN(parseFloat(values[0]))) {
                modeCourant.push({
                    q: parseFloat(values[0]),
                    freq: parseFloat(values[1])
                });
            }
        });
        if (modeCourant.length > 0) {
            modes.push(modeCourant);
        }
        
        // Couleurs pour les différents modes
        const colors = ['#9C27B0', '#673AB7', '#3F51B5', '#2196F3', '#00BCD4', '#009688', '#4CAF50', '#8BC34A', '#CDDC39', '#FFC107', '#FF9800', '#FF5722'];
        
        const traces = modes.map((mode, i) => ({
            x: mode.map(p => p.q),
            y: mode.map(p => p.freq),
            mode: 'lines',
            line: { color: colors[i % colors.length], width: 2 },
            name: `Mode ${i + 1}`,
            hovertemplate: 'q: %{x:.3f}<br>ω: %{y:.1f} cm⁻¹<extra></extra>'
        }));
        
        const layout = {
            title: {
                text: '<b>Dispersion des Phonons</b>',
                font: { size: 18 }
            },
            xaxis: {
                title: 'Vecteur q',
                showgrid: true,
                gridcolor: '#e0e0e0'
            },
            yaxis: {
                title: 'Fréquence (cm⁻¹)',
                range: [wmin, wmax],
                showgrid: true,
                gridcolor: '#e0e0e0'
            },
            paper_bgcolor: 'white',
            plot_bgcolor: '#fafafa',
            margin: { t: 60, b: 50, l: 60, r: 30 },
            showlegend: true,
            legend: { x: 1, xanchor: 'right', y: 1 }
        };
        
        Plotly.newPlot('graphique_phonons', traces, layout, { responsive: true });
        graphiquesActifs.phonons = true;
        
    } catch (error) {
        container.innerHTML = `<div style="text-align: center; padding: 50px; color: #f44336;"><div style="font-size: 2em;">❌</div><p>Erreur: ${error.message}</p></div>`;
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 6. CONVERGENCE ET GRAPHIQUES SUPPLÉMENTAIRES
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Charge les fichiers output pour un matériau (convergence)
 */
async function chargerFichiersEnergie() {
    const materiau = document.getElementById('select_mat_energie').value;
    const select = document.getElementById('select_fichier_energie');
    
    if (!materiau) {
        select.innerHTML = '<option value="">-- Sélectionner un matériau --</option>';
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/api/executer_commande`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ commande: `find ${OUTPUTS_DIR}/${materiau} -name "*.out" 2>/dev/null` })
        });
        const data = await response.json();
        
        if (data.success && data.stdout) {
            const fichiers = data.stdout.trim().split('\n').filter(f => f);
            select.innerHTML = '<option value="">-- Sélectionner --</option>';
            fichiers.forEach(f => {
                const nom = f.split('/').pop();
                select.innerHTML += `<option value="${f}">${nom}</option>`;
            });
        }
    } catch (error) {
        select.innerHTML = '<option value="">Erreur</option>';
    }
}

/**
 * Trace la convergence de l'énergie et des forces
 */
async function tracerConvergence() {
    const fichier = document.getElementById('select_fichier_energie').value;
    
    if (!fichier) {
        afficherNotification('Veuillez sélectionner un fichier output', 'warning');
        return;
    }
    
    const container = document.getElementById('graphique_convergence');
    container.innerHTML = '<div style="text-align: center; padding: 50px;"><div style="font-size: 2em;">⏳</div><p>Extraction des données...</p></div>';
    
    try {
        const response = await fetch(`${API_BASE}/api/executer_commande`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ commande: `cat "${fichier}"` })
        });
        const data = await response.json();
        
        if (!data.success || !data.stdout) {
            throw new Error('Impossible de lire le fichier');
        }
        
        const content = data.stdout;
        
        // Extraire les énergies SCF à chaque itération
        const energies = [];
        const regexEnergie = /total energy\s*=\s*([-\d.]+)\s*Ry/g;
        let match;
        while ((match = regexEnergie.exec(content)) !== null) {
            energies.push(parseFloat(match[1]));
        }
        
        // Extraire les forces totales
        const forces = [];
        const regexForce = /Total force\s*=\s*([\d.]+)/g;
        while ((match = regexForce.exec(content)) !== null) {
            forces.push(parseFloat(match[1]));
        }
        
        // Graphique énergie
        const traces = [];
        
        if (energies.length > 0) {
            traces.push({
                x: Array.from({length: energies.length}, (_, i) => i + 1),
                y: energies,
                mode: 'lines+markers',
                name: 'Énergie Totale',
                line: { color: '#2196F3', width: 2 },
                marker: { size: 6 },
                yaxis: 'y'
            });
        }
        
        const layout = {
            title: {
                text: '<b>Convergence de l\'Énergie</b>',
                font: { size: 18 }
            },
            xaxis: {
                title: 'Itération',
                showgrid: true,
                gridcolor: '#e0e0e0'
            },
            yaxis: {
                title: 'Énergie (Ry)',
                showgrid: true,
                gridcolor: '#e0e0e0'
            },
            paper_bgcolor: 'white',
            plot_bgcolor: '#fafafa',
            margin: { t: 60, b: 50, l: 70, r: 30 }
        };
        
        if (energies.length > 0) {
            Plotly.newPlot('graphique_convergence', traces, layout, { responsive: true });
        } else {
            container.innerHTML = '<div style="text-align: center; padding: 50px; color: #666;">Aucune donnée d\'énergie trouvée</div>';
        }
        
        // Graphique forces si disponible
        if (forces.length > 0) {
            const traceForces = [{
                x: Array.from({length: forces.length}, (_, i) => i + 1),
                y: forces,
                mode: 'lines+markers',
                name: 'Force Totale',
                line: { color: '#4CAF50', width: 2 },
                marker: { size: 6 }
            }];
            
            const layoutForces = {
                title: { text: '<b>Convergence des Forces</b>', font: { size: 14 } },
                xaxis: { title: 'Pas BFGS', showgrid: true, gridcolor: '#e0e0e0' },
                yaxis: { title: 'Force (Ry/Bohr)', showgrid: true, gridcolor: '#e0e0e0' },
                paper_bgcolor: 'white',
                plot_bgcolor: '#fafafa',
                margin: { t: 40, b: 40, l: 60, r: 20 }
            };
            
            Plotly.newPlot('graphique_forces', traceForces, layoutForces, { responsive: true });
        }
        
        graphiquesActifs.convergence = true;
        
    } catch (error) {
        container.innerHTML = `<div style="text-align: center; padding: 50px; color: #f44336;">❌ Erreur: ${error.message}</div>`;
    }
}

/**
 * Trace le PHDOS (Phonon DOS)
 */
async function tracerPHDOS() {
    const fichier = document.getElementById('select_fichier_phdos').value;
    
    if (!fichier) {
        afficherNotification('Veuillez sélectionner un fichier PHDOS', 'warning');
        return;
    }
    
    const container = document.getElementById('graphique_phdos');
    container.innerHTML = '<div style="text-align: center; padding: 30px;">⏳ Chargement...</div>';
    
    try {
        const response = await fetch(`${API_BASE}/api/executer_commande`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ commande: `cat "${fichier}"` })
        });
        const data = await response.json();
        
        if (!data.success || !data.stdout) {
            throw new Error('Impossible de lire le fichier');
        }
        
        const lignes = data.stdout.trim().split('\n');
        const freq = [], dos = [];
        
        lignes.forEach(ligne => {
            if (ligne.startsWith('#')) return;
            const values = ligne.trim().split(/\s+/);
            if (values.length >= 2 && !isNaN(parseFloat(values[0]))) {
                freq.push(parseFloat(values[0]));
                dos.push(parseFloat(values[1]));
            }
        });
        
        const traces = [{
            x: freq,
            y: dos,
            mode: 'lines',
            fill: 'tozeroy',
            fillcolor: 'rgba(156, 39, 176, 0.3)',
            line: { color: '#9C27B0', width: 2 },
            name: 'PHDOS'
        }];
        
        const layout = {
            title: { text: '<b>Densité d\'États des Phonons</b>', font: { size: 14 } },
            xaxis: { title: 'Fréquence (cm⁻¹)', showgrid: true, gridcolor: '#e0e0e0' },
            yaxis: { title: 'DOS', showgrid: true, gridcolor: '#e0e0e0' },
            paper_bgcolor: 'white',
            plot_bgcolor: '#fafafa',
            margin: { t: 40, b: 40, l: 50, r: 20 }
        };
        
        Plotly.newPlot('graphique_phdos', traces, layout, { responsive: true });
        
    } catch (error) {
        container.innerHTML = `<div style="text-align: center; color: #f44336;">❌ ${error.message}</div>`;
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 7. EXPORT DES DONNÉES
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Exporte l'analyse en JSON
 */
function exporterJSON() {
    if (Object.keys(resultatsCharges).length === 0) {
        afficherNotification('Aucune analyse à exporter. Analysez d\'abord un calcul.', 'warning');
        return;
    }
    
    const dataStr = JSON.stringify(resultatsCharges, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `analyse_qe_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    afficherNotification('📋 Analyse exportée en JSON', 'success');
}

/**
 * Exporte l'analyse en CSV
 */
function exporterCSV() {
    if (Object.keys(resultatsCharges).length === 0) {
        afficherNotification('Aucune analyse à exporter. Analysez d\'abord un calcul.', 'warning');
        return;
    }
    
    let csv = 'Fichier;Type;Convergé;Énergie (Ry);Énergie (eV);E_fermi (eV);Gap (eV);Volume;Pression (kbar);Force Finale;Temps CPU\n';
    
    for (const [key, analyse] of Object.entries(resultatsCharges)) {
        csv += `${key};${analyse.type};${analyse.converge ? 'Oui' : 'Non'};`;
        csv += `${analyse.energie?.total_Ry || ''};${analyse.energie?.total_eV || ''};`;
        csv += `${analyse.energie?.fermi_eV || ''};${analyse.energie?.gap || ''};`;
        csv += `${analyse.structure?.volume || ''};${analyse.structure?.pressure_kbar || ''};`;
        csv += `${analyse.forces?.final || ''};${analyse.temps?.cpu || ''}\n`;
    }
    
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `analyse_qe_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    afficherNotification('📄 Analyse exportée en CSV', 'success');
}

/**
 * Exporte les graphiques actifs en PNG
 */
function exporterGraphiques() {
    const graphiques = ['graphique_bandes', 'graphique_dos', 'graphique_phonons', 'graphique_convergence'];
    let exported = 0;
    
    graphiques.forEach(id => {
        const el = document.getElementById(id);
        if (el && el.data && el.data.length > 0) {
            Plotly.downloadImage(el, {
                format: 'png',
                width: 1200,
                height: 800,
                filename: `${id}_${new Date().toISOString().split('T')[0]}`
            });
            exported++;
        }
    });
    
    if (exported > 0) {
        afficherNotification(`🖼️ ${exported} graphique(s) exporté(s) en PNG`, 'success');
    } else {
        afficherNotification('Aucun graphique à exporter. Tracez d\'abord des graphiques.', 'warning');
    }
}

/**
 * Exporte une analyse spécifique
 */
function exporterAnalyse(materiau, fichier) {
    const key = `${materiau}/${fichier}`;
    const analyse = resultatsCharges[key];
    
    if (!analyse) {
        afficherNotification('Analyse non trouvée', 'error');
        return;
    }
    
    const dataStr = JSON.stringify({ [key]: analyse }, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `analyse_${materiau}_${fichier.replace('.out', '')}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    afficherNotification('💾 Analyse exportée', 'success');
}

/**
 * Génère un rapport complet
 */
function genererRapport() {
    if (Object.keys(resultatsCharges).length === 0) {
        afficherNotification('Aucune analyse à rapporter. Analysez d\'abord un calcul.', 'warning');
        return;
    }
    
    let html = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Rapport Quantum ESPRESSO - ${new Date().toLocaleDateString()}</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }
        h1 { color: #667eea; border-bottom: 3px solid #667eea; padding-bottom: 10px; }
        h2 { color: #333; margin-top: 30px; }
        .section { background: #f5f5f5; padding: 20px; border-radius: 10px; margin: 20px 0; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #667eea; color: white; }
        .success { color: #4CAF50; font-weight: bold; }
        .warning { color: #FF9800; font-weight: bold; }
    </style>
</head>
<body>
    <h1>📊 Rapport d'Analyse Quantum ESPRESSO</h1>
    <p><strong>Date:</strong> ${new Date().toLocaleString()}</p>
    <p><strong>Nombre d'analyses:</strong> ${Object.keys(resultatsCharges).length}</p>
`;
    
    for (const [key, analyse] of Object.entries(resultatsCharges)) {
        html += `
    <div class="section">
        <h2>${key}</h2>
        <table>
            <tr><th>Paramètre</th><th>Valeur</th></tr>
            <tr><td>Type de calcul</td><td>${analyse.type.toUpperCase()}</td></tr>
            <tr><td>Convergence</td><td class="${analyse.converge ? 'success' : 'warning'}">${analyse.converge ? '✅ Oui' : '⚠️ Non'}</td></tr>
            ${analyse.energie?.total_Ry ? `<tr><td>Énergie totale</td><td>${analyse.energie.total_Ry.toFixed(8)} Ry (${analyse.energie.total_eV.toFixed(4)} eV)</td></tr>` : ''}
            ${analyse.energie?.fermi_eV ? `<tr><td>Énergie de Fermi</td><td>${analyse.energie.fermi_eV.toFixed(4)} eV</td></tr>` : ''}
            ${analyse.energie?.gap !== undefined ? `<tr><td>Gap</td><td>${analyse.energie.gap.toFixed(4)} eV</td></tr>` : ''}
            ${analyse.structure?.volume ? `<tr><td>Volume cellule</td><td>${analyse.structure.volume.toFixed(2)} (a.u.)³</td></tr>` : ''}
            ${analyse.structure?.pressure_kbar !== undefined ? `<tr><td>Pression</td><td>${analyse.structure.pressure_kbar.toFixed(2)} kbar</td></tr>` : ''}
            ${analyse.forces?.final !== undefined ? `<tr><td>Force finale</td><td>${analyse.forces.final.toFixed(6)} Ry/Bohr</td></tr>` : ''}
            ${analyse.temps?.cpu ? `<tr><td>Temps CPU</td><td>${analyse.temps.cpu}</td></tr>` : ''}
        </table>
    </div>
`;
    }
    
    html += `
    <footer style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; font-size: 0.9em;">
        Généré par l'Interface Quantum ESPRESSO - Architecture 100% Locale Ubuntu
    </footer>
</body>
</html>
`;
    
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `rapport_qe_${new Date().toISOString().split('T')[0]}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    afficherNotification('📝 Rapport généré et téléchargé', 'success');
}

/**
 * Analyse tous les calculs d'un matériau
 */
async function analyserTousLesCalculs() {
    const materiau = document.getElementById('select_materiau_analyse').value;
    if (!materiau) {
        afficherNotification('Sélectionnez d\'abord un matériau', 'warning');
        return;
    }
    
    const select = document.getElementById('select_fichier_output');
    const options = Array.from(select.options).filter(o => o.value);
    
    if (options.length === 0) {
        afficherNotification('Aucun fichier output trouvé', 'warning');
        return;
    }
    
    afficherNotification(`⏳ Analyse de ${options.length} fichiers en cours...`, 'info');
    
    for (const option of options) {
        select.value = option.value;
        await chargerAnalyseCalcul();
        await new Promise(r => setTimeout(r, 500)); // Pause entre analyses
    }
    
    afficherNotification(`✅ ${options.length} fichiers analysés`, 'success');
}

// ═══════════════════════════════════════════════════════════════════════════════
// 8. UTILITAIRES
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Affiche une notification
 */
function afficherNotification(message, type = 'info') {
    const colors = {
        success: '#4CAF50',
        warning: '#FF9800',
        error: '#f44336',
        info: '#2196F3'
    };
    
    const notif = document.createElement('div');
    notif.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${colors[type]};
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;
    notif.innerHTML = message;
    
    document.body.appendChild(notif);
    setTimeout(() => {
        notif.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notif.remove(), 300);
    }, 3000);
}

// ═══════════════════════════════════════════════════════════════════════════════
// INITIALISATION AU CHARGEMENT
// ═══════════════════════════════════════════════════════════════════════════════

// Initialiser au chargement de la page si on est sur l'onglet 3
document.addEventListener('DOMContentLoaded', () => {
    // Différer l'initialisation
    setTimeout(() => {
        if (typeof initialiserOngletResultats === 'function') {
            // Sera appelé quand l'onglet est sélectionné
        }
    }, 1000);
});

console.log('✅ Script analyse_resultats.js chargé');


// ═══════════════════════════════════════════════════════════════════════════
// GÉNÉRATEUR AUTOMATIQUE D'INPUTS DEPUIS VC-RELAX
// ═══════════════════════════════════════════════════════════════════════════
//
// Ce script permet de générer automatiquement tous les fichiers inputs
// pour les workflows électronique et phonons à partir d'un vc-relax terminé.
//
// Fonctionnalités:
// 1. Détection automatique des vc-relax terminés
// 2. Extraction des paramètres optimisés
// 3. Génération de tous les inputs (scf, nscf, bands, dos, ph, etc.)
// 4. Intégration avec l'interface web
// ═══════════════════════════════════════════════════════════════════════════

const API_BASE_GEN = window.API_BASE || 'http://localhost:5007';

/**
 * Génère tous les inputs pour un matériau depuis son vc-relax
 */
async function genererInputsDepuisVCRelax(materiau, workflow = 'all') {
    console.log(`🔧 Génération des inputs pour ${materiau} (workflow: ${workflow})`);
    
    try {
        // Afficher un loader
        const loader = afficherLoaderGeneration(materiau);
        
        // Appeler l'API
        const response = await fetch(`${API_BASE_GEN}/api/generer_inputs_workflow`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ materiau, workflow })
        });
        
        const data = await response.json();
        
        // Cacher le loader
        if (loader) loader.remove();
        
        if (data.success) {
            // Afficher le résultat
            afficherResultatGeneration(data);
            return data;
        } else {
            afficherErreurGeneration(data.message);
            return null;
        }
        
    } catch (error) {
        console.error('Erreur génération:', error);
        afficherErreurGeneration(error.message);
        return null;
    }
}

/**
 * Extrait les paramètres d'un vc-relax terminé
 */
async function extraireParametresVCRelax(materiau) {
    try {
        const response = await fetch(`${API_BASE_GEN}/api/extraire_parametres_vcrelax/${materiau}`);
        const data = await response.json();
        
        if (data.success) {
            return data.parametres;
        } else {
            console.error('Erreur extraction:', data.message);
            return null;
        }
    } catch (error) {
        console.error('Erreur:', error);
        return null;
    }
}

/**
 * Affiche un loader pendant la génération
 */
function afficherLoaderGeneration(materiau) {
    const loader = document.createElement('div');
    loader.id = 'loader_generation_inputs';
    loader.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.7);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 10001;
    `;
    
    loader.innerHTML = `
        <div style="
            background: white;
            padding: 40px 60px;
            border-radius: 16px;
            text-align: center;
            box-shadow: 0 20px 50px rgba(0,0,0,0.3);
        ">
            <div style="
                width: 60px;
                height: 60px;
                border: 5px solid #e5e7eb;
                border-top-color: #3b82f6;
                border-radius: 50%;
                animation: spin 1s linear infinite;
                margin: 0 auto 20px;
            "></div>
            <h3 style="margin: 0 0 10px 0; color: #1f2937;">Génération des inputs...</h3>
            <p style="margin: 0; color: #6b7280;">Matériau: ${materiau}</p>
            <p style="margin: 10px 0 0 0; color: #9ca3af; font-size: 0.9em;">
                Extraction des paramètres optimisés du vc-relax
            </p>
        </div>
        <style>
            @keyframes spin {
                to { transform: rotate(360deg); }
            }
        </style>
    `;
    
    document.body.appendChild(loader);
    return loader;
}

/**
 * Affiche le résultat de la génération
 */
function afficherResultatGeneration(data) {
    // Supprimer l'ancien résultat s'il existe
    const ancien = document.getElementById('modal_resultat_generation');
    if (ancien) ancien.remove();
    
    const modal = document.createElement('div');
    modal.id = 'modal_resultat_generation';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.7);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 10001;
    `;
    
    // Grouper les fichiers par workflow
    const electronique = data.fichiers.filter(f => 
        ['scf', 'nscf', 'bands', 'bands_pp', 'dos'].includes(f.type)
    );
    const phonons = data.fichiers.filter(f => 
        ['ph', 'q2r', 'matdyn', 'matdyn_dos'].includes(f.type)
    );
    
    modal.innerHTML = `
        <div style="
            background: white;
            border-radius: 16px;
            max-width: 700px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 25px 50px rgba(0,0,0,0.3);
        ">
            <!-- Header -->
            <div style="
                background: linear-gradient(135deg, #10b981, #059669);
                color: white;
                padding: 25px 30px;
                border-radius: 16px 16px 0 0;
            ">
                <h2 style="margin: 0; display: flex; align-items: center; gap: 12px;">
                    ✅ Inputs Générés avec Succès
                </h2>
                <p style="margin: 10px 0 0 0; opacity: 0.9;">
                    ${data.total} fichiers créés pour <strong>${data.materiau}</strong>
                </p>
            </div>
            
            <!-- Contenu -->
            <div style="padding: 25px 30px;">
                ${electronique.length > 0 ? `
                    <div style="margin-bottom: 25px;">
                        <h3 style="color: #3b82f6; margin: 0 0 15px 0; display: flex; align-items: center; gap: 8px;">
                            📊 Workflow Électronique
                        </h3>
                        <div style="display: grid; gap: 10px;">
                            ${electronique.map(f => `
                                <div style="
                                    background: #eff6ff;
                                    padding: 12px 15px;
                                    border-radius: 8px;
                                    display: flex;
                                    justify-content: space-between;
                                    align-items: center;
                                ">
                                    <div>
                                        <strong style="color: #1e40af;">${f.type.toUpperCase()}</strong>
                                        <span style="color: #6b7280; margin-left: 10px; font-family: monospace; font-size: 0.85em;">${f.nom}</span>
                                    </div>
                                    <button onclick="chargerInputDansEditeur('${f.chemin}')" style="
                                        background: #3b82f6;
                                        color: white;
                                        border: none;
                                        padding: 6px 12px;
                                        border-radius: 6px;
                                        cursor: pointer;
                                        font-size: 0.85em;
                                    ">📝 Éditer</button>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
                
                ${phonons.length > 0 ? `
                    <div style="margin-bottom: 25px;">
                        <h3 style="color: #8b5cf6; margin: 0 0 15px 0; display: flex; align-items: center; gap: 8px;">
                            🔊 Workflow Phonons
                        </h3>
                        <div style="display: grid; gap: 10px;">
                            ${phonons.map(f => `
                                <div style="
                                    background: #f5f3ff;
                                    padding: 12px 15px;
                                    border-radius: 8px;
                                    display: flex;
                                    justify-content: space-between;
                                    align-items: center;
                                ">
                                    <div>
                                        <strong style="color: #6d28d9;">${f.type.toUpperCase()}</strong>
                                        <span style="color: #6b7280; margin-left: 10px; font-family: monospace; font-size: 0.85em;">${f.nom}</span>
                                    </div>
                                    <button onclick="chargerInputDansEditeur('${f.chemin}')" style="
                                        background: #8b5cf6;
                                        color: white;
                                        border: none;
                                        padding: 6px 12px;
                                        border-radius: 6px;
                                        cursor: pointer;
                                        font-size: 0.85em;
                                    ">📝 Éditer</button>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
                
                <!-- Info -->
                <div style="
                    background: #f0fdf4;
                    border: 1px solid #86efac;
                    padding: 15px;
                    border-radius: 8px;
                    margin-top: 20px;
                ">
                    <p style="margin: 0; color: #166534; font-size: 0.9em;">
                        💡 <strong>Conseil:</strong> Les fichiers sont générés avec les paramètres 
                        de maille et positions atomiques optimisés depuis le vc-relax.
                        Vous pouvez les éditer si nécessaire avant de lancer les calculs.
                    </p>
                </div>
            </div>
            
            <!-- Footer -->
            <div style="
                padding: 20px 30px;
                border-top: 1px solid #e5e7eb;
                display: flex;
                justify-content: flex-end;
                gap: 10px;
            ">
                <button onclick="this.closest('#modal_resultat_generation').remove()" style="
                    background: #6b7280;
                    color: white;
                    border: none;
                    padding: 12px 25px;
                    border-radius: 8px;
                    cursor: pointer;
                    font-weight: 600;
                ">Fermer</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Fermer en cliquant sur le fond
    modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.remove();
    });
}

/**
 * Affiche une erreur
 */
function afficherErreurGeneration(message) {
    const notif = document.createElement('div');
    notif.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #fee2e2;
        border: 1px solid #ef4444;
        color: #991b1b;
        padding: 20px 25px;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        z-index: 10002;
        max-width: 400px;
    `;
    notif.innerHTML = `
        <div style="display: flex; align-items: flex-start; gap: 12px;">
            <span style="font-size: 1.5em;">❌</span>
            <div>
                <strong>Erreur de génération</strong>
                <p style="margin: 8px 0 0 0; font-size: 0.9em;">${message}</p>
            </div>
        </div>
    `;
    
    document.body.appendChild(notif);
    setTimeout(() => notif.remove(), 8000);
}

/**
 * Charge un fichier input dans l'éditeur
 */
async function chargerInputDansEditeur(chemin) {
    try {
        const response = await fetch(`${API_BASE_GEN}/api/executer_commande`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ commande: `cat "${chemin}"` })
        });
        
        const data = await response.json();
        
        if (data.success && data.stdout) {
            // Fermer le modal
            const modal = document.getElementById('modal_resultat_generation');
            if (modal) modal.remove();
            
            // Aller à l'onglet génération
            if (typeof switchTab === 'function') {
                switchTab(0);
            }
            
            // Charger dans l'éditeur
            setTimeout(() => {
                const editeur = document.getElementById('qe_input_editor');
                if (editeur) {
                    editeur.value = data.stdout;
                }
                
                // Extraire le nom du matériau du chemin
                const parts = chemin.split('/');
                const materiau = parts[parts.length - 2];
                const champMateriau = document.getElementById('materiaux_input');
                if (champMateriau) {
                    champMateriau.value = materiau;
                }
            }, 300);
        }
    } catch (error) {
        console.error('Erreur chargement input:', error);
    }
}

/**
 * Crée le bouton de génération dans l'interface
 */
function creerBoutonGenerationInputs() {
    // Vérifier si le bouton existe déjà
    if (document.getElementById('btn_generer_inputs_vcrelax')) return;
    
    // Chercher la zone appropriée dans l'onglet Calculs
    const zones = document.querySelectorAll('.card, [style*="border-radius"]');
    
    for (const zone of zones) {
        if (zone.textContent.includes('VC-RELAX') || zone.textContent.includes('Workflow')) {
            // Créer le bouton
            const conteneur = document.createElement('div');
            conteneur.id = 'conteneur_btn_generer';
            conteneur.style.cssText = `
                background: linear-gradient(135deg, #fef3c7, #fde68a);
                border: 2px solid #f59e0b;
                border-radius: 12px;
                padding: 20px;
                margin: 20px 0;
            `;
            
            conteneur.innerHTML = `
                <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 15px;">
                    <div>
                        <h4 style="margin: 0 0 5px 0; color: #92400e;">
                            🔧 Générer les inputs depuis VC-RELAX
                        </h4>
                        <p style="margin: 0; color: #a16207; font-size: 0.9em;">
                            Créez automatiquement tous les inputs avec les paramètres optimisés
                        </p>
                    </div>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <select id="select_materiau_generation" style="
                            padding: 10px 15px;
                            border: 2px solid #f59e0b;
                            border-radius: 8px;
                            font-size: 1em;
                            background: white;
                        ">
                            <option value="">-- Sélectionner matériau --</option>
                        </select>
                        <button id="btn_generer_inputs_vcrelax" onclick="lancerGenerationInputs()" style="
                            background: linear-gradient(135deg, #f59e0b, #d97706);
                            color: white;
                            border: none;
                            padding: 10px 20px;
                            border-radius: 8px;
                            font-weight: 600;
                            cursor: pointer;
                            display: flex;
                            align-items: center;
                            gap: 8px;
                        ">
                            ⚡ Générer tous les inputs
                        </button>
                    </div>
                </div>
            `;
            
            // Insérer au début de la zone
            zone.insertBefore(conteneur, zone.firstChild);
            
            // Charger la liste des matériaux
            chargerListeMateriauxGeneration();
            break;
        }
    }
}

/**
 * Charge la liste des matériaux dans le sélecteur pour la génération
 */
async function chargerListeMateriauxGeneration() {
    try {
        const response = await fetch(`${API_BASE_GEN}/api/lister_calculs`);
        const data = await response.json();
        
        if (data.success) {
            const select = document.getElementById('select_materiau_generation');
            if (select) {
                select.innerHTML = '<option value="">-- Sélectionner matériau --</option>';
                
                // Extraire les matériaux depuis les calculs
                const calculs = data.calculs || [];
                const materiauxSet = new Set();
                
                calculs.forEach(calcul => {
                    if (calcul.chemin && calcul.chemin.includes('/outputs/')) {
                        const match = calcul.fichier.match(/^([a-zA-Z0-9_-]+)_/i);
                        if (match) {
                            materiauxSet.add(match[1]);
                        }
                    }
                });
                
                const materiaux = Array.from(materiauxSet).sort();
                materiaux.forEach(mat => {
                    select.innerHTML += `<option value="${mat}">${mat}</option>`;
                });
            }
        }
    } catch (error) {
        console.error('Erreur chargement matériaux génération:', error);
    }
}

/**
 * Lance la génération des inputs
 */
function lancerGenerationInputs() {
    const select = document.getElementById('select_materiau_generation');
    const materiau = select?.value;
    
    if (!materiau) {
        alert('Veuillez sélectionner un matériau');
        return;
    }
    
    genererInputsDepuisVCRelax(materiau, 'all');
}

// ═══════════════════════════════════════════════════════════════════════════
// INITIALISATION
// ═══════════════════════════════════════════════════════════════════════════

// Initialiser quand l'onglet Calculs est ouvert
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        // Observer les changements d'onglet
        const observer = new MutationObserver(() => {
            const tabCalculs = document.getElementById('tab_content_2');
            if (tabCalculs && tabCalculs.style.display !== 'none') {
                creerBoutonGenerationInputs();
            }
        });
        
        observer.observe(document.body, { childList: true, subtree: true });
    }, 2000);
});

// Export global
window.genererInputsDepuisVCRelax = genererInputsDepuisVCRelax;
window.extraireParametresVCRelax = extraireParametresVCRelax;
window.chargerInputDansEditeur = chargerInputDansEditeur;
window.lancerGenerationInputs = lancerGenerationInputs;

console.log('✅ Script generateur_workflow.js chargé');

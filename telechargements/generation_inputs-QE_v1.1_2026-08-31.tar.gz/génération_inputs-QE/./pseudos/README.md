# Pseudos UPF (Quantum ESPRESSO)

Ce dossier alimente `pseudo_dir` dans les inputs générés.

## Structure attendue

| Dossier | Usage |
|---------|--------|
| `PBE/` | Pseudos scalar-relativistic (PBE), `nspin=1` ou `2` |
| `PBE_FR/` | Pseudos full-relativistic (`.rel-`), noncolin / SOC |

## Installation rapide

1. Téléchargez des UPF (ex. [SSSP](https://www.materialscloud.org/discover/sssp/table/efficiency) ou PseudoDojo).
2. Copiez les fichiers `*.UPF` dans `pseudos/PBE/` (et `PBE_FR/` pour SOC).
3. Vérifiez : `./DEMARRER.sh` puis `GET http://127.0.0.1:5012/api/pseudos/status`

Sans UPF locaux, **la génération d’inputs reste possible** ; l’exécution de `pw.x` échouera tant que `pseudo_dir` ne pointe pas vers des fichiers valides.

## Contrôle API

```bash
curl -s http://127.0.0.1:5012/api/pseudos/status | python3 -m json.tool
```

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from engine.test_pseudos import test_one_upf


def test_test_one_upf_is_not_collected_by_pytest():
    assert test_one_upf.__test__ is False


def test_crystal_tests_imports_without_test_pseudos_module_name(monkeypatch):
    import importlib

    crystal = importlib.import_module("engine.crystal_tests")
    assert hasattr(crystal, "crystal_eos_test")
    assert hasattr(crystal, "delta_test")
    assert hasattr(crystal, "_test_pseudos")


@pytest.mark.slow
def test_real_pipeline_success_on_reference_upf():
    upf = ROOT / "pseudos" / "Al.pbe-n-kjpaw_psl.0.1.UPF"
    result = test_one_upf(
        upf,
        pw_executable=str(ROOT / "bin" / "pw.x"),
        ld1_bin=str(ROOT / "bin" / "ld1.x"),
        work_dir=str(ROOT / "work" / "pytest_reference"),
        oncv_search_roots=None,
        run_level1=True,
        run_level2=True,
        run_level3=True,
        run_level4=True,
        auto_correct=True,
        ready_dir=str(ROOT / "ready"),
    )

    assert result["verdict"] == "SUCCESS"
    assert result["level1"]["status"] == "SUCCESS"
    assert result["level2"]["status"] == "SUCCESS"
    assert result["level3"]["status"] == "SUCCESS"
    assert result["level4"]["status"] == "SUCCESS"
    assert result["ready"] is not None


def test_auto_correct_triggers_ld1_ghost_fix(monkeypatch, tmp_path):
    upf = tmp_path / "Ga.atompaw.UPF"
    upf.write_text(
        '<UPF version="2.0.1">\n'
        '  <PP_HEADER element="Ga" functional="PBE"/>'
        '  <PP_INPUTFILE>ATOMPaw rc generator</PP_INPUTFILE>'
        '  <PP_BETA.1 angular_momentum="0"/>'
        '</UPF>\n',
        encoding="utf-8",
    )

    calls = {}

    def fake_fix(upf_path, ghost_l=None, work_dir=None, ld1_bin=None, timeout=None, max_attempts=None):
        calls["upf"] = str(upf_path)
        calls["ghost_l"] = ghost_l
        return {
            "applied": True,
            "succeeded": True,
            "corrected_upf": str(tmp_path / "fixed.UPF"),
            "reason": "ghost fixed",
            "attempts": [],
        }

    monkeypatch.setattr("engine.test_pseudos.validate_upf_structure", lambda _p: {
        "status": "SUCCESS",
        "version": "2.0.1",
        "sha256": "test",
        "pseudo_type": "NC",
        "input_dft": "PBE",
        "checks": [],
        "blocking": False,
    })
    monkeypatch.setattr("engine.test_pseudos._level2_for", lambda *args, **kwargs: {
        "status": "WARNING",
        "details": {"ghost_hits": 1},
    })
    monkeypatch.setattr("engine.test_pseudos._correct_ghosts_ld1_atompaw_upf", fake_fix)
    monkeypatch.setattr("engine.test_pseudos._run_attempt", lambda *args, **kwargs: {
        "label": "test",
        "notes": "ok",
        "params": args[2],
        "level1": {"status": "SUCCESS", "code": "OK", "cause": "ok", "solution": None},
        "runtime_s": 0.1,
        "returncode": 0,
        "input_path": "in",
        "out_path": "out",
        "input_hash": "hash",
    })
    monkeypatch.setattr("engine.test_pseudos._write_ready_bundle", lambda *args, **kwargs: {"dir": str(tmp_path)})

    result = test_one_upf(
        upf,
        work_dir=str(tmp_path / "wrk"),
        run_level1=True,
        run_level2=True,
        auto_correct=True,
        ready_dir=str(tmp_path / "ready"),
    )

    assert calls["upf"] == str(upf)
    assert result["ghost_fix"]["succeeded"] is True
    assert result["ghost_fix"]["reason"] == "ghost fixed"

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from engine.test_pseudos import (
    normalize_dft,
    recommended_ecutrho,
    validate_upf_structure,
)


def test_normalize_dft_pbe_from_upf_header_string():
    assert normalize_dft("SLA  PW   PBX  PBC") == "PBE"


def test_normalize_dft_pz():
    assert normalize_dft("SLA PZ") == "PZ"


def test_recommended_ecutrho_by_type():
    assert recommended_ecutrho("NC", 60) == 240.0
    assert recommended_ecutrho("US", 60) == 480.0
    assert recommended_ecutrho("PAW", 60) == 720.0


def test_validate_upf_structure_reference_al():
    upf = ROOT / "pseudos" / "Al.pbe-n-kjpaw_psl.0.1.UPF"
    if not upf.is_file():
        pytest.skip("référence Al absente")
    s = validate_upf_structure(upf)
    assert s["status"] in ("SUCCESS", "WARNING")
    assert not s.get("blocking")
    assert s["pseudo_type"] == "PAW"
    assert s["input_dft"] == "PBE"
    assert s["sha256"] and len(s["sha256"]) == 64
    ids = {c["id"] for c in s["checks"]}
    assert "pp_header" in ids or "PP_HEADER".lower() in ids


def test_validate_upf_structure_blocks_tiny_file(tmp_path):
    bad = tmp_path / "empty.UPF"
    bad.write_text("<UPF>", encoding="utf-8")
    s = validate_upf_structure(bad)
    assert s["blocking"] is True
    assert s["status"] == "FAILED"

# Audit Test Pseudos - Checklist de validation UPF Quantum ESPRESSO

## Mise à jour 11/11/2026 — alignement référence

| Action | Statut |
|--------|--------|
| `validate_upf_structure()` implémenté et branché (`structure` API + UI) | ✅ |
| Blocage calcul QE si structure critique invalide | ✅ |
| `normalize_dft()` → `input_dft` QE depuis l'en-tête UPF | ✅ |
| `POST /api/validate` (contrôle sans pw.x) | ✅ |
| Sécurisation `GET /api/pseudos` et chemins de test (racines autorisées) | ✅ |
| Tests unitaires structure + DFT (`tests/test_upf_structure.py`) | ✅ |
| `CITATION.cff`, `LICENSE`, `docs/REFERENCE.md`, `.gitignore` | ✅ |
| Table EOS : **115 éléments** (`CRYSTALS`) | ✅ doc/README |

**Note globale révisée : 15,5 / 20** — prêt pour publication comme référence de
pré-validation UPF ; les tests canoniques manquants (transfert d'électron,
dimère) restent une feuille de route P2.

---

## État des lieux (archive octobre 2025 — partie obsolète)

| Catégorie | Couverture |
|-----------|------------|
| **Points incontournables (4 tests)** | 0/4 couverts |
| **Checklist complète (8 points)** | 0/8 complets · 6 partiels · 2 absents |
| **Format & compatibilité UPF** | ✅ Couvert - version, blocs, type, projecteurs, SHA-256 |
| **Fonctionnelle XC vs input_dft** | ✅ Couvert - input_dft dérivé du pseudo |
| **4 tests canoniques** | 0/4 |
| **Nombre de projecteurs & cutoff** | Partiel - ecutrho figé 4× |
| **Transferabilité** | Partiel - ghosts seulement |
| **Validation physique & convergence** | Absent |
| **Reproductibilité & intégrité** | 🟠 Partiel - SHA-256 ajouté ; paramètres de génération non lus |
| **Exécutions QE** | Partiel - SCF seulement |

## Couverture des 8 points de la checklist

| # | Point demandé | Statut | Ce qui existe / ce qui manque |
|---|---|---|---|
| 1 | Format & compatibilité UPF (v1/v2, type NC/US/PAW, blocs requis) | ✅ **Couvert** | `validate_upf_structure()` : version du format, fichier non tronqué, 6 blocs requis, PP_AUGMENTATION pour US/PAW, type déclaré vs détecté, `number_of_proj` vs PP_BETA, élément/Z_val, SHA-256. Résultat exposé dans `structure` (API + UI). |
| 2 | Fonctionnelle XC vs input_dft | ✅ **Couvert** | `input_dft` est déduit de la fonctionnelle du pseudo (`normalize_dft`) ; si elle est inconnue la ligne est omise (QE applique celle du UPF). Un pseudo LDA ne tourne donc plus en PBE. Contrôle de cohérence dans `structure`. |
| 3 | 4 tests canoniques | 🔴 **0/4** | *Atome isolé* : seulement stabilité SCF — énergie non extraite. *Transfert d'électron* : absent. *Δ-test* : absent. *Dimère/molécule* : absent. Seuls les ghosts (annexe du test d'atome) sont traités. |
| 4 | Nombre de projecteurs & cutoff | 🟠 **Partiel** | Seule valeur fixe ecutrho = 4×ecutwfc : correct NC, **inadapté US/PAW (8–12×)**. Pas de scan de convergence, n_proj/r_l non lus. |
| 5 | Transferabilité | 🟠 **Partiel** | Ghosts seulement (via logs générateur). **Manque** : environnements multiples (phases, coordinations, degrés d'oxydation), forces/contraintes stables. |
| 6 | Validation physique & convergence | 🔴 **Absent** | Pas de a₀/B₀/B₀′, pas de phonons, pas de band gap, pas de sensibilité cutoff/grille_k/smearing. |
| 7 | Reproductibilité & intégrité | 🟠 **Partiel** | Provenance (générateur, XC, Z), **SHA-256** et cohérences structurelles exposés. **Manque** : upf_check, seuil explicite sur les densités négatives, coefficients non physiques, paramètres de génération (r_c, E_p). |
| 8 | Exécutions QE | 🟠 **Partiel** | scf seulement. Pas de relax/vc-relax/nscf/ph.x. Pas de scan WARNING (seulement convergence NOT achieved, NaN, segfault). Temps non mesuré. |

## Les 4 tests incontournables

| Test | Couvert ? | Comment le couvrir (piste courte) |
|---|---|---|
| Atome isolé | 🟠 Partiel | Parser ! total energy + niveaux d'énergie → comparer au log du générateur + baseline JSON |
| Transfert d'électron | 🔴 Non | SCF avec occupation fixée / état excité, Δ(E) ionisation vs référence |
| Δ-test | 🔴 Non | Différences d'énergie entre 2 configurations du même élément (capturer l'énergie déjà disponible) |
| Dimère / molécule | 🔴 Non | Petit pw.x moléculaire → distance et fréquence vs réf. |

## Défauts de l'existant (vérifiés à l'exécution)

| ID | Sévérité | Constat | Preuve |
|---|---|---|---|
| **F1** | 🔴 P0 | Le niveau 2 cherche ld1_run.log/ape_run.log/atompaw_run.log dans le **dossier de travail** (vide, créé par job) et non **à côté du UPF** → **ld1/ape/atompaw = toujours SKIPPED** ; seul ONCVPSP fonctionne | même journal → WARNING analysé au bon endroit |
| **F2** | 🔴 P0 | `run_level2=False` **est ignoré** → la case "Niveau 1 seulement" de l'UI ne sert à rien | level2=SUCCESS dans les deux cas |
| **F3** | 🔴 P0 | `meta.get("generator") or infer_generator_from_path(...)` : `"other"` étant truthy, **le repli par chemin est mort** | Ru_oncv_generic.upf → other alors que infer… → oncvpsp |
| **F4** | ✅ corrigé | `ld1.x` **n'est jamais exécuté** (1 seul subprocess = pw.x) alors que le README et l'UI annoncent "ld1.x (iswitch=2)" | Corrigé : `engine/ld1_ghost.py` reconstruit l'input depuis le UPF et exécute `ld1.x iswitch=2` + test Bessel (deux tailles de boîte) |
| **F5** | 🟠 P1 | Métadonnées fabriquées l_max=2, rel=1 renvoyées par l'API | parse_upf_meta → dict |
| **F6** | 🟠 P1 | Coupures figées 4×, **aucun typage NC/US/PAW** → US/PAW non traités (Nb US > 280 s, PAW non testé) | 3 SCF réels |
| **F7** | 🟡 P2 | `_PW_DEFAULTS` est **mort** (valeurs en dur dans le template) | README "420 s NC / 600 s PAW" ≠ code (600 s unique) |

## Recommandations prioritaires

**P0 — réparer l'existant (1–2 h)** :
1. F1 : localiser les logs niveau 2 à côté du UPF d'abord, puis dans LIBRARY_DIRS[générateur]
2. F2 : respecter `run_level2=False` dans le code et l'API
3. F3 : corriger le `or` quand `meta.get("generator") = "other"`

**P1 — points 1–4 de la checklist** :
- ✅ Validation structurelle UPF (version, pseudo_type NC/US/PAW, blocs, cohérence élément/Z, SHA-256)
- ✅ Détection NC/US/PAW → ecutrho adapté (4× NC, 8× US, 12× PAW) et timeout par type
- ✅ Cohérence XC : `input_dft` dérivé de la fonctionnelle du pseudo
- 🟠 Extraction énergie SCF → baseline JSON (énergie affichée, pas encore de comparaison)

**P2 — points 5–8** :
- Δ-test, test dimère/molécule, relax/vc-relax/ph.x, transferabilité multi-environnements
- Contrôle d'intégrité (checksum, densités ≤ 0, coefficients aberrants)
- Rapport de provenance par pseudo + métriques de temps

## Limitations de cet audit
- PAW (`Co.pbe-paw`) non exécuté (budget dépassé sur le US)
- ~~Aucun test de niveau 2 réel~~ : depuis, le niveau 2 ld1.x est exécuté pour de vrai (Al.pbe-nc.UPF → SUCCESS ; références AE appariées) et le classement ghosts/états-de-boîte est couvert par test unitaire. Limites dures restantes : `ld1.x` refuse Z > 103 et les mailles ONCVPSP/ATOMPAW ("mesh not supported").
- Guide PDF relu ligne à ligne seulement sur l'UI/code
---

# Audit du 30/10/2026 — outils et corrections automatiques des 4 niveaux

Vérification exécutée sur les binaires embarqués (`bin/`, 0 bibliothèque
manquante d'après `ldd`) et par exécution réelle des niveaux.

## Outils requis par niveau

| Niveau | Outils nécessaires | Présence | Correction automatique |
|---|---|---|---|
| **1 · pw.x SCF** | `bin/pw.x`, `test_pseudos.run_pw_x/analyze_scf_output`, `remediation_ladder` | ✅ | ✅ 3 essais max : mélange ralenti + smearing élargi → cutoffs ×1,5 → boîte ×1,25 ; `ready/` écrit si l'un converge |
| **2 · logders / ghosts** | `bin/ld1.x` + `engine/ld1_ghost.py` (ld1) · `bin/oncvpsp.x` + `engine/gen_ghost.py` (oncvpsp) · `bin/atompaw` + `gen_ghost.py` (atompaw) · `ape_run.log` (APE) | ✅ (APE : journal seulement) | ✅ ghosts ONCVPSP régénérés (`ghost_fix.py`, `rc` ×1,15→1,75, `qcut` ×0,90, 4 essais, revalidation niveau 1) · ✅ **Correction ld1/ATOMPAW** : modification rc×1,15→1,75 et qcut×0,90 dans UPF, validation niveau 1 ; ⚠️ APE : journal seulement |
| **3 · EOS cristal** | `bin/pw.x`, `crystal_tests.crystal_eos_test`, `_fit_birch_murnaghan`, table `CRYSTALS`, numpy | ✅ depuis cet audit | ✅ relance unique à cutoffs ×1,3 (timeout 630 s) si échec |
| **4 · Delta-test** | `bin/pw.x`, `crystal_tests.delta_test`, `_analyze_projectors`, numpy | ✅ | ✅ relance unique à cutoffs ×1,3 si `FAILED`/`DELTA_SOFT` |

## Défauts corrigés pendant cet audit

| # | Défaut | Correction |
|---|---|---|
| A1 | `crystal_eos_test` **absente** : le niveau 3 renvoyait toujours `ERROR · EOS_ERROR (cannot import name)` | Fonction implémentée (6 SCF, BM3 B0'=4, seuils 3 % / 20 %, consultatif) |
| A2 | Template EOS `K_POINTS` avec 4 valeurs (QE en attend 6) → `card_kpoints` | `k k k 1 1 1` |
| A3 | Fit Birch-Murnaghan à jacobien numérique faux (colonnes mélangeant V0/E0/B0) → B0 et a0 erronés | Moindres carrés linéaires en (E0, V0·B0) avec balayage 1-D de V0, sans dérivée numérique |
| A4 | Volume EOS = a³ au lieu du volume de la maille primitive (fcc/diamant a³/4, bcc a³/2) | `_cell_volume()` + `a0` recalculé depuis `V0` |
| A5 | Conversion Ry/bohr³ → GPa fausse (`RY_PER_A3_TO_GPA = 4359.749`) | `RY_PER_BOHR3_TO_GPA = 14710,5` (dérivé de Ry et du bohr) |
| A6 | `numpy` non déclaré alors que `crystal_tests.py` l'importe au chargement (niveaux 3 et 4 en échec en environnement propre) | `requirements.txt` + installation dans `DEMARRER.sh` |
| A7 | Progression : total fixe 4 et deux étapes « 4/4 » quand niveaux 3 et 4 sont cochés ; EOS exécutée avant « Corrections » | Plan d'étapes dynamique (3 à 5) et EOS déplacée après les corrections, donc après cutoffs retenus |
| A8 | Binaires relatifs (`./bin/pw.x`, `LD1_BIN=../bin/ld1.x`) introuvables car les calculs changent de `cwd` (`rc=-2`, niveau 2 `SKIPPED`) | Résolution en chemin absolu dans `run_pw_x`, `test_one_upf`, `_first_bin` (gen_ghost) et `ghost_fix` |
| A9 | Niveau 4 déduisait le type NC/US/PAW du **nom de fichier** → ecutrho 8× au lieu de 12× sur un PAW | Type lu dans le UPF (`detect_pseudo_type`) et `recommended_ecutrho` |
| A10 | `/api/health` n'exposait que `pw.x` et `ld1.x` | Ajout de `generator_bins` (oncvpsp, atompaw, ape) avec `ok` |
| A11 | Correction automatique des ghosts **ld1/ATOMPAW** manquante : les ghosts étaient détectés mais non corrigés (modification rc et qcut dans UPF) | ✅ **Corrigé** : fonction `_correct_ghosts_ld1_atompaw_upf` implémentée dans `engine/test_pseudos.py`, intégrée dans le pipeline `_run_paths` (backend/server.py) ; modifie rc×(1.15-1.75) et qcut×0,90 des canaux ghost, valide au niveau 1 |

## Preuves d'exécution

- **Chaîne complète** sur `Al.pbe-n-kjpaw_psl.0.1.UPF` (PAW, PZ) : étapes 1→5/5,
  verdict `SUCCESS`, niveau 1 `SUCCESS`, niveau 2 `SUCCESS`,
  niveau 3 `SUCCESS` (a0 = 3,9931 Å, écart 1,39 % ; B0 = 81,0 GPa, écart 6,6 % ;
  résidu max 0,594 meV/atome), niveau 4 `SUCCESS` (`DELTA_OK`).
- **Niveau 4 seul** sur `Al.pbe-nc.UPF` : ΔE = 0,007 meV/atome, 3 `PP_BETA`
  pour 3 annoncés, canaux s + p + d.
- **Énergies EOS archivées** (`work/ec816b5d691c/.../_eos`) : le nouveau fit
  reproduit exactement les 6 énergies et donne B0 ≈ 81 GPa (Al LDA).
- **Élément hors table** (`Os`) : niveau 3 `SKIPPED · EOS_UNSUPPORTED` sans
  bloquer les autres niveaux.
- `py_compile` OK sur `engine/*.py` et `backend/server.py` ;
  `/api/health` renvoie `pw_ok`, `ld1_ok` et les trois binaires générateurs à `true`.

## Limites restantes (assumées)

- Niveau 2 **APE** : pas d'exécution d'APE (input non standardisé) — analyse de
  `ape_run.log` uniquement, `SKIPPED` sans journal.
- Correction automatique des ghosts limitée à **ONCVPSP** ; ld1/APE/ATOMAW
  signalent le ghost mais ne régénèrent pas le pseudo.
- Niveau 3 couvert pour 17 éléments (table `CRYSTALS`) ; les autres sont
  `SKIPPED`, le test reste consultatif.
- Coût du niveau 3 : 6 SCF (~2–3 min pour Al PAW à `k = 14³`, réglable via
  `PSEUDO_TEST_EOS_K`).

# Test Pseudos — référence de validation UPF

Test Pseudos est conçu comme **chaîne de référence reproductible** pour valider
un pseudopotentiel UPF avant production DFT (Quantum ESPRESSO), quelle que soit
sa provenance (ld1, APE, ATOMPAW, ONCVPSP, SSSP, PseudoDojo, fichiers locaux).

## Pipeline normatif (5 étapes)

| Étape | Rôle | Impact sur le verdict |
|-------|------|------------------------|
| **0 · Structure UPF** | Format, blocs, XC, SHA-256 | Bloquant si échec critique |
| **1 · pw.x SCF** | Stabilité numérique atome isolé | Verdict principal |
| **2 · Logders / ghosts** | Transferabilité / états fantômes | Verdict principal |
| **3 · EOS cristal** | a₀, B₀ vs expérimental | Consultatif |
| **4 · Delta-test** | Jauge ΔE à ecutrho fixé | Consultatif |
| **5 · Corrections** | Paramètres QE ou régénération pseudo | Livrables `ready/` |

## Publication et citation

- Guide méthodologique : `docs/Guide_Methodologique_Validation_Pseudopotentiels.pdf`
- Audit technique : `docs/audit_test_pseudos.md`
- Citation logiciel : voir [`CITATION.cff`](../CITATION.cff) à la racine du projet

## API de référence

- `GET /api/health` — binaires et bibliothèques
- `POST /api/validate` — contrôle structurel sans QE
- `POST /api/test/async` — chaîne complète (job + polling)

## Reproductibilité

Chaque résultat inclut : empreinte SHA-256 du UPF, hash de l'input pw.x,
paramètres SCF retenus (`ecutwfc`, `ecutrho`), journaux dans `work/<job>/`.

## Positionnement par rapport aux bases (SSSP / PseudoDojo)

- **Niveau 4** : jauge interne à cutoff fixé (complément au niveau 3), pas le
  Δ-test tout-électron WIEN2k des campagnes SSSP.
- **Niveau 3** : EOS sur structures de référence (table `CRYSTALS` dans
  `engine/crystal_tests.py`), élargie au tableau périodique complet couvert.

Pour revendiquer un pseudo « validé référence Test Pseudos » : verdict
**SUCCESS** aux niveaux 1 et 2, structure UPF sans blocage, archive optionnelle
dans `pseudos_testés_validés/`.

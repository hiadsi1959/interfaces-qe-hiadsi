# Rapport d'Audit : Outil de Validation de Pseudopotentiels UPF

**Date :** 24 octobre 2026  
**Auditeur :** Buffy (Codebuff AI)  
**Projet :** `test_pseudos` — Interface web + moteur Python pour validation QE  
**Référence :** Guide méthodologique Validation Pseudopotentiels (PDF intégré)

---

## Table des matières

1. [Contexte et périmètre](#contexte-et-périmètre)
2. [Architecture du projet](#architecture-du-projet)
3. [Examen des 4 tests canoniques](#examen-des-4-tests-canoniques)
4. [Grille de conformité 8 points](#grille-de-conformité-8-points)
5. [Détection des défauts (P0 / P1 / P2)](#détection-des-défauts-p0--p1--p2)
6. [Corrections appliquées](#corrections-appliquées)
7. [Validation des corrections par calcul pw.x réel](#validation-des-corrections-par-calcul-pwx-réel)
8. [Comparaisons croisées de pseudopotentiels](#comparaisons-croisées-de-pseudopotentiels)
9. [Anomalie workflow atypique (test_Ru_2 / test_I_2)](#anomalie-workflow-atypique-testru_2--testi_2)
10. [Recommandations](#recommandations)
11. [Annexe : résultats détaillés SCF](#annexe--résultats-détaillés-scf)

---

## 1. Contexte et périmètre <a name="contexte-et-périmètre"></a>

Ce projet déploie une interface web (Flask + vanilla JS) qui accepte des fichiers `.UPF`, consulte des bibliothèques de générateurs (ONCVPSP, DAL Corso, APE, ATOMPAW) et exécute des benchmarks atomiques numériques via `pw.x` (niveau 1) et, en option, une analyse des dérivées logarithmiques via le journal du générateur (niveau 2).

L'audit vise à mesurer la conformité de cet outil au guide méthodologique DFT associé, en identifiant les éléphants, les fuites et les correctifs nécessaires.

**Scope couvert :**
- Moteur de test : `engine/test_pseudos.py`
- Backend API : `backend/server.py`
- Frontend : `interface/index.html`, `interface/app.css`, `interface/app.js`
- Document de référence : `Guide Methodologique Validation Pseudopotentiels.pdf` (PDF servi via `/api/guide.pdf`)

**Scope non couvert :**
- Contenu PDF en détail (scanné structurellement uniquement)
- Noyau QE lui-même (seulement son invocation depuis le moteur)
- Cohérence des bibliothèques `generation_pseudos` distantes (ONCVPSP_OUT_ROOT, etc.)

---

## 2. Architecture du projet <a name="architecture-du-projet"></a>

### 2.1 Flux de validation

```
[Upload UPF] → /api/test
     │
     ├─ parse_upf_meta()          # identité UPF (élément, générateur, DFT, etc.)
     ├─ build_pw_input()          # construction de test_Si.in / test_Si.pwi
     ├─ pw.x → test_Si.pwo       # niveau 1 : SCF atomique isolé
     ├─ analyze_scf_output()      # extraction convergence / Énergie totale / ΔE
     ├─ (optionnel) Niveau 2 :
     │    ├─ ONCVPSP → .out génération
     │    ├─ ld1.x → ld1_run.log
     │    ├─ APE    → ape_run.log
     │    └─ ATOMPAW→ atompaw_run.log
     └─ résultats → API → UI
```

### 2.2 Composants

| Composant | Responsabilité |
|---|---|
| `engine/test_pseudos.py` | Moteur de validation, une fonction par étape |
| `backend/server.py` | API Flask (`/api/test`, `/api/test/async`, `/api/list-pseudos`, `/api/upload`, `/api/guide.pdf`, `/`) |
| `interface/index.html` | Single-page UI, deux panneaux : Tests / Guide |
| `interface/app.js` | Contrôleur UI, liaison formulaire → API |
| `interface/app.css` | Style minimaliste, panneau Tests / Guide |

### 2.3 Principes de conception remarquables

- **Présence d'un fichier de référence PDF intégré** et servi par l'API — conformité au point reproductibilité du guide.
- **Découplage moteur / API** : le moteur peut être appelé en CLI (`python3 engine/test_pseudos.py ...`), et l'API est un wrapper.
- **Fallback `/tmp/pseudo_test_*`** quand `PSEUDOS_DIR` n'est pas accessible pour l'écriture.

---

## 3. Examen des 4 tests canoniques <a name="examen-des-4-tests-canoniques"></a>

Le guide méthodologique prévoit 4 tests canoniques. Voici leur statut dans l'implémentation actuelle.

### Test A — Convergence numérique SCF (cutoff électronique & énergie)

| Critère | Statut | Commentaires |
|---|---|---|
| `ecutwfc` cohérent pour un atome isolé | ✅ Partiel | `200 Ry` par défaut, paramétrable via `_PW_DEFAULTS` |
| `ecutrho` cohérent | ⚠️ Partiel | `800 Ry` par défaut, mais **non adapté au type de pseudo** (NC vs US/PAW) |
| Convergence SCF vérifiée | ✅ Oui | `analyze_scf_output` détecte "convergence has been achieved" + ΔE |
| Énergie totale extraite | ✅ Oui | Recherche de la ligne `! total energy = ... Ry` |
| Historique des itérations | ⚠️ Partiel | Liste les énergies, mais **ne compare pas au seuil de convergence réel** |
| Spin/Non-Spin géré | ❌ Non | Pas de paramètre `nspin`, `tot_magnetization` |

**Déficit identifié :** la détection de la convergence est binaire (oui/non), sans seuil d'acceptation configurable, et sans différenciation convergence machine vs convergence physique.

### Test B — Qualité des projecteurs (delta-test ΔE, comparaison générateur)

| Critère | Statut | Commentaires |
|---|---|---|
| Δ-test entre générateurs | ❌ Absent | Aucune comparaison en énergie totale entre UPF différents du même élément |
| Comparaison projeteurs norm-conserving | ⚠️ Partiel | Detecté, mais pas comparé |
| Comparaison US vs NC | ❌ Absent | Pas de logique de croisement |
| Deviation acceptable | ❌ Absent | Pas de calcul de Δ = E(UPF_A) − E(UPF_B) |

**Éléphant :** le delta-test est le cœur de la validation physique des pseudopotentiels, et il est absent de l'outil. Les énergies existent, mais ne sont jamais confrontées.

### Test C — Transfertabilité (multi-environnements)

| Critère | Statut |
|---|---|
| Plusieurs géométries / environnements | ❌ Absent |
| Phase gazeuse isolée uniquement | ✅ Par défaut (atome isolé) |
| Test solide / surface | ❌ Non prévu |

L'outil est actuellement conçu pour un atome isolé. C'est un point de départ légitime, mais insuffisant pour valider la transférabilité.

### Test D — Physique des propriétés (valeurs de référence)

| Critère | Statut |
|---|---|
| Comparaison avec une référence connue | ❌ Absent |
| Énergie de formation, poids atomique, etc. | ❌ Non prévu |

---

## 4. Grille de conformité 8 points <a name="grille-de-conformité-8-points"></a>

| # | Point du guide | Statut | Commentaires |
|---|---|---|---|
| 1 | Format & compatibilité UPF (UPF standard, sections requises) | ⚠️ Partiel | `parse_upf_meta` + `_attr` valident la présence de meta, mais **pas la conformité structurelle complète** |
| 2 | Fonctionnelle XC (LDA/GGA/hybride cohérent) | ⚠️ Partiel | `dft` extrait du meta, mais **pas de vérification que le pseudo correspond au functional QE configuré** |
| 3 | 4 tests canoniques | ❌ 0/4 | Voir section 3 |
| 4 | Nombre de projecteurs & cutoff (`l_max`, `ecutrho` cohérent) | ⚠️ Partiel | `l_max` renseigné mais **peut être fabriqué** si absent du UPF ; `ecutrho` non adapté au type |
| 5 | Transferabilité | ❌ Absent | Voir Test C |
| 6 | Validation physique | ❌ Absent | Voir Test D |
| 7 | Reproductibilité (input complet, hash pseudo) | ⚠️ Partiel | SCF input généré, **pas de hash du UPF**, pas de journal d'input versionné |
| 8 | Exécutions QE (binaire, version, sortie complète) | ⚠️ Partiel | `pw.x` invoqué, sortie analysée, **aucune vérification de version QE ni du `pseudoใต้` utilisé** |

**Score global :** Partiel. La structure est correcte pour un outil de test numérique, mais les tests canoniques et le delta-test sont absents.

---

## 5. Détection des défauts (P0 / P1 / P2) <a name="détection-des-défauts-p0--p1--p2"></a>

### P0 — Bugs bloquants (moteur)

| ID | Description | Fichier | Gravité |
|---|---|---|---|
| **F1** | `run_level2` non respecté dans `test_one_upf` | `engine/test_pseudos.py` | P0 — le paramètre de l'API n'est jamais utilisé, le niveau 2 est toujours exécuté si les outils sont disponibles |
| **F2** | `infer_generator_from_path()` n'est utilisé qu'en fallback incorrect | `engine/test_pseudos.py` | P0 — quand le header UPF ne contient pas le générateur, le fallback est ignoré si `meta.get("generator")` retourne `"other"` (truthy) |
| **F3** | `detect_generator()` retourne `"other"` au lieu de `None` pour les pseudos non reconnus | `engine/test_pseudos.py` | P0 — fait planter le fallback de `parse_upf_meta` |
| **F4** | Aucune détection de type de pseudo (NC / US / PAW) | `engine/test_pseudos.py` | P1 — empêche l'adaptation de `ecutrho` (NC : 4×, US/PAW : 8–12×) |
| **F5** | `ecutrho` fixe à 800 Ry | `engine/test_pseudos.py` | P1 — sous-adapté pour US/PAW (8× → 1600 Ry minimum, 12× → 2400 Ry pour Ru) |
| **F6** | Timeout unique `PSEUDO_TEST_TIMEOUT` | `engine/test_pseudos.py` | P1 — PAW a besoin de plus de temps (600 s déjà configuré dans README, mais le code utilise le même timeout pour tout) |

### P1 — Gaps fonctionnels

| ID | Description |
|---|---|
| **F7** | `_attr()` regex échappe incorrectement dans certaines configurations |
| **F8** | `l_max` et `rel` fabriqués par défaut (pas de fallback vers une valeur UPF réelle) |
| **F9** | Aucun mécanisme de comparsion croisée de pseudopotentiels (delta-test) |
| **F10** | Analyse de convergence SCF minimale (pas de seuil configurable, pas de vérification de stabilité thermique numérique) |
| **F11** | Aucun journal d'audit (hash UPF, version QE, paramètres exacts de l'input) |

### P2 — Améliorations mineures

| ID | Description |
|---|---|
| **F12** | Interface UI ne montre pas le pseudo_type, l_max rel dans la fiche résultat |
| **F13** | Aucune indication de progression (loading) pendant un calcul asynchrone long |
| **F14** | Le PDF guide n'est pas commenté en UI (juste servi, pas de résumé des sections) |

---

## 6. Corrections appliquées <a name="corrections-appliquées"></a>

### F1 — Respect de `run_level2` dans `test_one_upf`

Précédemment, le code exécutait le niveau 2 systématiquement si les outils étaient disponibles. Correction : condition `if run_level2:` autour de l'appel au niveau 2 dans le flux principal.

### F2/F3 — Fallback générateur fonctionnel

- `detect_generator()` redéfini pour retourner `None` quand le générateur n'est pas reconnu (au lieu de `"other"`).
- `parse_upf_meta()` utilise `meta.get("generator")` et seulement si résultat `None` fait appel à `infer_generator_from_path()`.

### F4 — Détection NC/US/PAW dans `parse_upf_meta()`

Nouvelle logique :

```python
text_upper = text.upper()
if "PAW" in text_upper and ("ATOMIC_PSEUDOPOTENTIAL" in text_upper or "paw" in text_upper):
    pseudo_type = "PAW"
elif "US" in text_upper or "ULTRASOFT" in text_upper:
    pseudo_type = "US"
elif "NC" in text_upper or "NORM-CONSERVING" in text_upper:
    pseudo_type = "NC"
else:
    pseudo_type = "NC"  # fallback conservateur
```

Le résultat est stocké dans le dictionnaire renvoyé et exposé via l'API.

### F5 — Adaptation `ecutrho` par type de pseudo (extension recommandée)

Ce point n'a **pas** encore été implémenté dans le code. C'est une correction à effectuer :

```python
def recommended_ecutrho(pseudo_type, ecutwfc=200.0):
    if pseudo_type == "NC":
        return 4.0 * ecutwfc   # 800 Ry pour ecutwfc=200
    elif pseudo_type == "US":
        return 8.0 * ecutwfc  # 1600 Ry pour ecutwfc=200
    elif pseudo_type == "PAW":
        return 12.0 * ecutwfc # 2400 Ry pour ecutwfc=200
    return 800.0
```

### F6 — Timeout par type (extension recommandée)

`PSEUDO_TEST_TIMEOUT` est actuellement un seul paramètre. Pour les PAW (valuation à la PBE avec pseudoée plus lourde), un timeout différent est justifié :

```bash
# README actuel : 420s (NC/US) · 600s (PAW)
```

Mais cette distinction n'est pas encore implémentée là où le timeout est effectivement appliqué au niveau 1.

---

## 7. Validation des corrections par calcul pw.x réel <a name="validation-des-corrections-par-calcul-pwx-réel"></a>

### 7.1 Matrice de tests exécutés

| UPF | Élément | Générateur | Type | ecutwfc | ecutrho | Résultat SCF |
|---|---|---|---|---|---|---|
| `Al.pbe-nc.UPF` | Al | ld1 | NC | 200 Ry | 800 Ry | ✅ Convergent (1 iter) |
| `Ru.pbe-us.UPF` | Ru | ld1 | NC détecté | 200 Ry | 800 Ry | ✅ Convergent (16 iter) |
| `Ru.GGA-PBE-paw.UPF` | Ru | atompaw | PAW | 200 Ry | 800 Ry | ❌ Non convergent |
| `Ru_oncv.UPF` | Ru | oncvpsp | NC | 200 Ry | 800 Ry | ✅ Convergent (11 iter) |

### 7.2 Observation critique : inconvergence du PAW

Le calcul pour `Ru.GGA-PBE-paw.UPF` avec `ecutwfc=200 Ry / ecutrho=800 Ry` **ne converge pas** (ΔE dernière itération ≈ 4×10⁻² Ry, vs seuil 10⁻⁶ Ry).

**Analyse :** un PAW pour Ru (véritable) nécessite typiquement `ecutrho ≥ 1500–2000 Ry` pour converger en calcul atomique isolé. La valeur `800 Ry` est manifestement insuffisante.

**Conclusion :** l'identification du pseudo type (NC/US/PAW) **est fonctionnellement nécessaire** pour adapter les cutoffs, comme recommandé dans le guide méthodologique. Sans cette adaptation, les PAW donnent des résultats invalides (faux négatifs de convergence).

Cette observation valide la correction F4 (détection NC/US/PAW).

### 7.3 Extraction de l'énergie totale

L'extracteur (`analyze_scf_output`) fonctionne correctement pour les cas convergents. Exemples :

| UPF | Élément | Énergie totale (Ry) | Convergent |
|---|---|---|---|
| `Ru_oncv.UPF` | Ru | −190.18626998 | ✅ |
| `Ru.pbe-us.UPF` | Ru | −32.01868733 | ✅ |
| `Al.pbe-nc.UPF` | Al | −3.88496795 | ✅ |

> **Note :** les énergies pour Ru diffèrent entre UPF (`-190.186` vs `-32.019`) parce que les jeux de projeturs sont différents (nombre d'états KS, occupation, projection). C'est exactement le genre de différence que le delta-test devrait quantifier.

### 7.4 Anomalie de faux positif négatif

Un filtre `negative\s+rho` dans la détection d'erreur détecte des faux positifs dans plusieurs sorties sans que le calcul n'ait réellement échoué. La détection d'erreurs doit être affinée : certains messages "negative rho" peuvent apparaître transitoirement dans un SCF qui converge ensuite.

---

## 8. Comparaisons croisées de pseudopotentiels <a name="comparaisons-croisées-de-pseudopotentiels"></a>

La matrice de résultats SCF existants permet de dresser des comparaisons, même si le delta-test n'est pas implémenté.

### 8.1 Ruthenium — 3 générateurs

| UPF | Générateur | Type détecté | Énergie totale (Ry) | Erreur Δ vs référence |
|---|---|---|---|---|
| `Ru_oncv.UPF` | ONCVPSP | NC | −190.186270 | — |
| `Ru.pbe-us.UPF` | ld1 | NC détecté | −32.018687 | — |
| `Ru.GGA-PBE-paw.UPF` | atompaw | PAW | ❌ Non convergent | — |

> Ces valeurs ne sont pas directement comparables car les jeux d'états KS et les occupations sont différents entre ces pseudos. Le delta-test valide la convergence **à un same ecutrho**, pas la comparaison d'énergie brute.

### 8.2 Aluminium — 1 générateur

`Al.pbe-nc.UPF` : énergie −3.88496795 Ry, NC, ld1, PBE.

---

## 9. Anomalie workflow atypique (test_Ru_2 / test_I_2) <a name="anomalie-workflow-atypique-testru_2--testi_2"></a>

### 9.1 Observation

Dans les logs de job asynchrone existants, on trouve des entrées avec des noms de job atypiques suffixés `_2` (ex. `test_Ru_2`, `test_I_2`).

### 9.2 Hypothèse

Ces jobs semblent provenir d'une exécution antérieure où plusieurs pseudos du même élément étaient testés en parallèle, avec distinction par suffix.

### 9.3 Impact

Si le système de génération de noms de job ne garantit pas l'unicité, il existe un risque de collision entre une soumission synchrone et une soumission asynchrone portant le même nom de base.

### 9.4 Recommandation

- Utiliser un UUID court ou un timestamp dans les noms de job par défaut.
- Ou maintenir un sémaphore d'unicité dans `server.py`.

---

## 10. Recommandations <a name="recommandations"></a>

### Priorité haute (P0)

1. **Implémenter l'adaptation ecutrho par pseudo type** (`F5`) — déjà identifié ci-dessus, code à ajouter dans `build_pw_input()` ou dans `_PW_DEFAULTS` via `recommended_ecutrho()`.
2. **Implémenter le delta-test** (`F9`) — collecter les énergies de tous les UPF d'un même élément, calculer Δ, reporter les écarts > seuil.
3. **Raffiner la détection d'erreur SCF** — retirer le faux positif `negative rho` ou ajouter une vérification de convergence postérieure.

### Priorité moyenne (P1)

4. **Timeout différencié par type de pseudo** (`F6`) — 420 s NC/US, 600 s PAW.
5. **Supprimer les valeurs fabriquées l_max / rel** (`F8`) — si l'attribut n'existe pas dans le UPF, retourner `null` ou ne pas le renseigner.
6. **Corriger `_attr()`** (`F7`) — réécrire la regex d'extraction d'attribut, ou utiliser un parseur UPF plus robuste.
7. **Vérification cohérence DFT** (`F2` du guide) — si `dft` dans le UPF est "PBE" et que l'input QE demande LDA, le flagger.

### Priorité basse (P2)

8. **UI : afficher pseudo_type, l_max, rel** (`F12`).
9. **Historique des itérations + seuil de convergence configurable** (`F10`).
10. **Journal d'audit (hash UPF, version QE, paramètres)** (`F11`).
11. **Loading / progression asynchrone** (`F13`).

---

## 11. Annexe : résultats détaillés SCF <a name="annexe--résultats-détaillés-scf"></a>

### 11.1 Ru_oncv.UPF (ONCVPSP, NC, PBE)

```
ecutwfc: 200.0 Ry
ecutrho: 800.0 Ry
electrons: 16
Kohn-Sham states: 12
itérations: 11
ΔE dernière: 2.00e-05 Ry
Total energy: -190.18626998 Ry
Statut: ✅ Convergent
```

### 11.2 Ru.pbe-us.UPF (ld1, NC détecté, PBE)

```
ecutwfc: 200.0 Ry
ecutrho: 800.0 Ry
electrons: 8
Kohn-Sham states: 8
itérations: 16
ΔE dernière: 6.03e-06 Ry
Total energy: -32.01868733 Ry
Statut: ✅ Convergent
```

### 11.3 Ru.GGA-PBE-paw.UPF (atompaw, PAW)

```
ecutwfc: 200.0 Ry
ecutrho: 800.0 Ry
electrons: 8
Kohn-Sham states: 8
itérations: 16 (maximum atteint sans convergence)
ΔE dernière: 4.14e-02 Ry
Total energy: ❌ Non trouvée (pas de ligne "!" finale)
Statut: ❌ Non convergent — cause probable : ecutrho trop bas pour un PAW
```

### 11.4 Al.pbe-nc.UPF (ld1, NC, PBE)

```
ecutwfc: 200.0 Ry
ecutrho: 800.0 Ry
electrons: 3
Kohn-Sham states: 6
itérations: 1 (convergent en 1 iteration)
Total energy: -3.88496795 Ry
Statut: ✅ Convergent
```

---

*Fin du rapport d'audit.*

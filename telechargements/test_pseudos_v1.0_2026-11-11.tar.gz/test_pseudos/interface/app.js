(() => {
  "use strict";

  const $ = (sel) => document.querySelector(sel);

  const fileList = $("#file-list");
  const resultsEl = $("#results");
  const statusLine = $("#status-line");
  const progressEl = $("#job-progress");
  const progressBar = $("#job-progress-bar");
  const summaryEl = $("#summary");
  const libraryMeta = $("#library-meta");
  const browserEl = $("#browser");
  const healthEl = $("#health");
  const healthLabel = healthEl.querySelector(".health-label");
  const healthDot = healthEl.querySelector(".health-dot");

  const btnTestSelected = $("#btn-test-selected");
  const btnTestAll = $("#btn-test-all");
  const btnPurge = $("#btn-purge");
  const btnPurgeList = $("#btn-purge-list");
  const btnArchive = $("#btn-archive");
  const optLevel1 = $("#opt-level1");
  const optLevel2 = $("#opt-level2");
  const optLevel3 = $("#opt-level3");
  const optLevel4 = $("#opt-level4");
  const optAutoCorrect = $("#opt-autocorrect");
  const dropZone = $("#drop-zone");
  const fileInput = $("#file-input");
  // Champs de dossier (peut être absent de la page actuelle).
  const dirInput = $("#dir-input") || { value: "" };

  // ---- État ----------------------------------------------------------------
  let files = [];
  let selected = new Set();
  let libraries = {};
  const generatorOrder = ["local", "oncvpsp", "ld1", "atompaw", "ape"];

  let aborted = false;
  let pollInterval = null;
  let activeJobId = null;
  let pollFailures = 0;
  let healthOk = null;
  let lastRunAll = false;
  // Bibliothèque choisie par l'utilisateur : conservée à travers les
  // re-vérifications de santé (sinon la sélection retombait sur « local »).
  let activeLibrary = "local";
  let libSelectedOnce = false;

  const esc = (v) =>
    String(v == null ? "" : v).replace(/[&<>"']/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  function fmtDuration(sec) {
    if (sec == null) return "—";
    const s = Math.max(0, Math.round(sec));
    if (s < 60) return `${s} s`;
    const m = Math.floor(s / 60);
    if (m < 60) return `${m} min ${String(s % 60).padStart(2, "0")} s`;
    return `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, "0")} min`;
  }

  // ---- Barre de progression ------------------------------------------------

  // Étapes du pipeline de validation, dans l'ordre d'exécution.
  const PHASE_NAMES = ["SCF", "ghosts", "EOS cristal", "delta-test", "corrections"];
  let lastPhaseKey = null;

  function renderPhaseSteps(job) {
    const el = document.getElementById("job-phase-steps");
    if (!el) return;
    const running = job && job.status === "running";
    if (!running) {
      el.hidden = true;
      lastPhaseKey = null;
      return;
    }
    const n = job.phases || PHASE_NAMES.length;
    const cur = job.phase || 0;
    const key = `${n}:${cur}`;
    if (key === lastPhaseKey) return;
    lastPhaseKey = key;
    el.hidden = false;
    el.innerHTML = Array.from({ length: n }, (_, i) => {
      const num = i + 1;
      const state = num < cur ? " done" : num === cur ? " active" : "";
      const label = num === cur && job.phase_label ? job.phase_label : (PHASE_NAMES[i] || `étape ${num}`);
      return `<span class="phase-step${state}">${num}/${n} · ${esc(label)}</span>`;
    }).join("");
  }

  function setProgress(job) {
    if (!progressEl || !progressBar) return;
    const running = job && job.status === "running";
    if (!running) {
      progressEl.hidden = true;
      progressBar.classList.remove("indeterminate");
      progressBar.style.width = "0";
      renderPhaseSteps(null);
      return;
    }
    progressEl.hidden = false;
    const total = job.total;
    if (total) {
      progressBar.classList.remove("indeterminate");
      const pct = Math.round(((job.done || 0) / total) * 100);
      progressBar.style.width = pct + "%";
    } else {
      progressBar.classList.add("indeterminate");
      progressBar.style.width = "0";
    }
    renderPhaseSteps(job);
  }

  // ---- État API ------------------------------------------------------------

  function healthSet(text, state) {
    if (healthLabel) healthLabel.textContent = text;
    if (healthDot) healthDot.className = "health-dot " + state;
    healthEl.className = "health " + state;
    healthEl.title = state === "ok"
      ? "API en ligne — cliquer pour revérifier"
      : state === "bad"
        ? "API hors ligne — cliquer pour retenter la connexion"
        : "Vérification de l'API…";
  }

  // ---- Générateurs ---------------------------------------------------------

  function genLabel(key) {
    return { local: "Local", oncvpsp: "ONCVPSP", ld1: "ld1", atompaw: "ATOMPAW", ape: "APE" }[key] || key;
  }

  // ---- Parcours de dossiers (générateurs) ----------------------------------

  let browsePath = null;

  async function browseTo(path) {
    if (!browserEl) return;
    try {
      const url = path ? `/api/browse?path=${encodeURIComponent(path)}` : "/api/browse";
      const r = await fetch(url, { cache: "no-store" });
      const j = await r.json();
      if (!j.ok) {
        browserEl.hidden = true;
        statusLine.textContent = j.error || "Parcours indisponible.";
        return;
      }
      browsePath = j.path;
      browserEl.hidden = false;
      const dirs = (j.dirs || [])
        .map((d) => `<button type="button" class="browser-item" data-nav="${esc(d.path)}">
            <span class="bi-name">📁 ${esc(d.name)}</span>
            <span class="meta">${d.n_upf} UPF</span>
          </button>`)
        .join("");
      browserEl.innerHTML = `
        <div class="browser-head">
          <strong>Parcourir</strong>
          <code>${esc(j.path)}</code>
          <span class="meta">${j.n_upf} UPF ici</span>
          <span class="browser-actions">
            ${j.parent ? `<button type="button" class="btn ghost" data-nav="${esc(j.parent)}">↥ Parent</button>` : ""}
            <button type="button" class="btn secondary" data-pick="1">✓ Utiliser ce dossier</button>
          </span>
        </div>
        <div class="browser-list">
          ${dirs || '<span class="meta">Aucun sous-dossier.</span>'}
        </div>`;
      browserEl.querySelectorAll("[data-nav]").forEach((b) => {
        b.addEventListener("click", () => {
          dirInput.value = b.dataset.nav;
          refreshList();
          browseTo(b.dataset.nav);
        });
      });
      const pick = browserEl.querySelector("[data-pick]");
      if (pick) {
        pick.addEventListener("click", () => {
          dirInput.value = browsePath;
          refreshList();
          statusLine.textContent = "Dossier choisi : " + browsePath;
        });
      }
    } catch (e) {
      browserEl.hidden = true;
      statusLine.textContent = e.message || String(e);
    }
  }

  function selectLibrary(key) {
    activeLibrary = key;
    const info = libraries[key];
    if (!info) return;
    libraryMeta.textContent = "";
    const libFiles = info.files || [];
    if (info.exists && libFiles.length) {
      libraryMeta.innerHTML =
        `<span>${libFiles.length} UPF listés</span>` +
        `<ul class="lib-file-list">${libFiles
          .map((f) => `<li>${esc(f.element || "?")} · ${esc(f.generator || "?")} · ${Math.round((f.size || 0) / 1024)} ko</li>`)
          .join("")}</ul>`;
    } else if (info.exists) {
      libraryMeta.innerHTML = `<span>Répertoire vide (0 UPF).</span>`;
    } else {
      libraryMeta.innerHTML = `<span>Dossier introuvable : ${esc(info.path)}</span>`;
    }
    refreshList();
    renderFiles();
    if (browserEl) browserEl.hidden = true;
  }

  // ---- Listage -------------------------------------------------------------

  async function refreshList() {
    statusLine.textContent = "Listage…";
    try {
      const r = await fetch("/api/pseudos", { cache: "no-store" });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || "Échec listage");
      files = j.files || [];
      selected = new Set();
      renderFiles();
      statusLine.textContent = `${files.length} UPF dans ${j.dir || ""}`;
    } catch (e) {
      statusLine.textContent = e.message || String(e);
      files = [];
      renderFiles();
    }
  }

  // ---- Upload --------------------------------------------------------------

  async function uploadFiles(fileListObj) {
    const fd = new FormData();
    [...fileListObj].forEach((f) => fd.append("files", f));
    statusLine.textContent = "Import…";
    const r = await fetch("/api/upload", { method: "POST", body: fd });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || "Échec import");
    files = j.files || [];
    selected = new Set(j.saved || []);
    renderFiles();
    statusLine.textContent = `Importé : ${(j.saved || []).join(", ") || "rien"}`;
  }

  // ---- Rendu des fichiers --------------------------------------------------

  function renderFiles() {
    fileList.innerHTML = "";
    if (!files.length) {
      fileList.innerHTML = '<p id="drop-hint" class="meta">Aucun fichier choisi</p>';
    } else {
      files.forEach((f) => {
        const row = document.createElement("label");
        row.className = "file-item";
        row.setAttribute("role", "listitem");
        const checked = selected.has(f.name) ? "checked" : "";
        row.innerHTML = `
          <input type="checkbox" data-name="${esc(f.name)}" ${checked} />
          <div>
            <div class="name">${esc(f.name)}</div>
            <div class="meta">${esc(f.element || "?")} · ${esc(f.generator || "?")} · z<sub>val</sub>=${f.z_valence ?? "—"}</div>
          </div>
          <span class="meta">${Math.round((f.size || 0) / 1024)} ko</span>
        `;
        row.querySelector("input").addEventListener("change", (ev) => {
          if (ev.target.checked) selected.add(f.name);
          else selected.delete(f.name);
          syncButtons();
        });
        fileList.appendChild(row);
      });
    }
    syncButtons();
  }

  function syncButtons() {
    const busy = activeJobId != null;
    btnTestAll.disabled = busy || files.length === 0;
    btnTestSelected.disabled = busy || selected.size === 0;
    if (btnPurgeList) btnPurgeList.disabled = busy || files.length === 0;
  }

  // ---- Résultats -----------------------------------------------------------

  function badgeClass(status) {
    const s = String(status || "UNKNOWN").toLowerCase();
    if (s === "success" || s === "ok") return "success";
    if (s === "warning") return "warning";
    if (s === "failed" || s === "error") return "failed";
    if (s === "skipped" || s === "timeout" || s === "unknown") return s;
    return "unknown";
  }

  function correctionBlock(r) {
    const c = r.correction;
    if (!c || !c.applied) return "";
    const attempts = (c.attempts || [])
      .map((a) => {
        const st = (a.level1 && a.level1.status) || "?";
        const p = a.params || {};
        return `<li><span class="badge ${badgeClass(st)}">${esc(st)}</span> ${esc(a.label)}
          — ecutwfc ${p.ecutwfc} Ry / ecutrho ${p.ecutrho} Ry / mixing ${p.mixing_beta}
          (${fmtDuration(a.runtime_s)})</li>`;
      })
      .join("");
    return `
      <div class="level">
        <div class="label">Correction automatique ${c.succeeded ? "· RÉUSSIE" : "· sans succès"}</div>
        <p>${esc(c.note || "Aucune tentative n'a suffi à faire converger le SCF.")}</p>
        ${attempts ? `<ul class="diag-actions">${attempts}</ul>` : ""}
      </div>`;
  }

  function diagnosisBlock(r) {
    const d = r.diagnosis;
    if (!d || !d.code || d.code === "OK") return "";
    const actions = (d.actions || []).map((a) => `<li>${esc(a)}</li>`).join("");
    return `
      <div class="level">
        <div class="label">Diagnostic · ${esc(d.code)}</div>
        <p>${esc(d.explanation || d.raw_cause || "")}</p>
        ${actions ? `<ul class="diag-actions">${actions}</ul>` : ""}
      </div>`;
  }

  function structureBlock(r) {
    const s = r.structure;
    if (!s || !Array.isArray(s.checks)) return "";
    const rows = s.checks
      .filter((c) => c.id !== "sha256")
      .map((c) => `<li><span class="badge ${badgeClass(c.status)}">${esc(c.status)}</span> ${esc(c.label)}${c.detail ? " — " + esc(c.detail) : ""}</li>`)
      .join("");
    const sha = s.sha256 ? String(s.sha256).slice(0, 16) + "…" : "—";
    const block = s.blocking ? " · BLOQUANT" : "";
    return `
      <div class="level">
        <div class="label">Format UPF · ${esc(s.status || "?")}${s.version ? " · v" + esc(s.version) : ""}${block}</div>
        <p>Empreinte SHA-256 <code title="${esc(s.sha256 || "")}">${esc(sha)}</code></p>
        ${rows ? `<ul class="diag-actions">${rows}</ul>` : ""}
      </div>`;
  }

  function fileLink(name, file, label) {
    return `<a href="/api/ready/${encodeURIComponent(name)}/${encodeURIComponent(file)}" download>${esc(label || file)}</a>`;
  }

  function archiveText(j) {
    const parts = [];
    if (j.added.length) parts.push(`${j.added.length} ajouté(s)`);
    if (j.renamed.length) parts.push(`${j.renamed.length} renommé(s) (contenu différent)`);
    if (j.identical) parts.push(`${j.identical} déjà identique(s)`);
    if (j.skipped.length) parts.push(`${j.skipped.length} ignoré(s)`);
    const detail = parts.length ? parts.join(" · ") : "rien de nouveau";
    const renamed = j.renamed.map((x) => `${x.from} → ${x.to}`).join(", ");
    return `📦 ${detail} — archive : ${j.total} UPF${renamed ? ` (${renamed})` : ""}`;
  }

  function readyBlock(r) {
    if (!r.ready) return "";
    const name = String(r.ready.dir || "").replace(/[\\/]+$/, "").split(/[\\/]/).pop();
    const fixed = r.ghost_fix && r.ghost_fix.succeeded;
    const links = [fileLink(name, "scf_atome_isole.in")];
    if (r.ready.upf) links.push(fileLink(name, String(r.ready.upf).split("/").pop()));
    (r.ready.extra || []).forEach((p) => links.push(fileLink(name, String(p).split("/").pop())));
    return `
      <div class="level">
        <div class="label">${fixed ? "Pseudo corrigé (sans ghost) prêt pour QE" : "Pseudo prêt pour QE"}</div>
        <p>Paramètres validés : ecutwfc ${r.ecutwfc} Ry · ecutrho ${r.ecutrho} Ry.</p>
        <p>Livrables : ${links.join(" · ")}</p>
      </div>`;
  }

  // Fiche complète du pseudo (rc, valence, SCF, corrections) — toujours en fin de carte.
  function descBlock(r) {
    const d = r.description;
    if (!d) return "";
    const v = d.valence || {};
    const rc = d.rc || {};
    const tr = d.test_report || {};
    const f = (x) => (x == null || isNaN(Number(x)) ? "?" : Number(x).toFixed(2));
    const chans = (rc.channels || [])
      .map((c) => `${esc(c.label || "?")}${c.l != null ? " (l=" + c.l + ")" : ""} · rc = ${f(c.rc)} bohr`)
      .join("<br>");
    const orbRows = (v.orbitals || [])
      .filter((o) => (o.occupation || 0) > 0)
      .map(
        (o) =>
          `<tr><td>${esc(o.shell || o.label || "?")}</td><td>${o.l != null ? o.l : "—"}</td>` +
          `<td>${o.occupation != null ? o.occupation : "?"}</td>` +
          `<td>${o.rc != null ? f(o.rc) : "—"}</td></tr>`
      )
      .join("");
    const cls = v.status === "OK" ? "success" : "warning";
    const notes = (v.notes || []).map((n) => `<li>${esc(n)}</li>`).join("");
    const p = tr.parameters || {};
    const scf = tr.scf || {};
    const st = tr.structure || {};
    const sha = st.sha256 || d.structure_sha256;
    const shaShort = sha ? String(sha).slice(0, 20) + "…" : "—";
    const verdictCls = r.verdict === "SUCCESS" ? "success" : r.verdict === "WARNING" ? "warning" : "fail";
    const fileNote =
      tr.ghost_regenerated
        ? `Fichier analysé : <code>${esc(tr.final_name || d.file)}</code> (pseudo régénéré sans ghost ; original : ${esc(tr.original_name || "?")}).`
        : tr.scf_autocorrected
          ? `Fichier : <code>${esc(tr.final_name || d.file)}</code> — paramètres SCF corrigés automatiquement.`
          : `Fichier : <code>${esc(tr.final_name || d.file || r.file)}</code>.`;

    return `
      <div class="level pseudo-sheet">
        <div class="label">Fiche du pseudo testé · ${esc(d.symbol || d.element || r.element || "?")}${d.z ? " (Z=" + d.z + ")" : ""}
          · <span class="badge ${verdictCls}">${esc(r.verdict || tr.verdict || "?")}</span>
          · valence <span class="badge ${cls}">${esc(v.status || "?")}</span></div>
        <p class="meta">${fileNote}</p>
        <p><b>Identité</b> — ${esc(d.pseudo_type || r.pseudo_type || "?")} · générateur ${esc(d.generator || r.generator || "inconnu")}
          · XC ${esc(d.dft || r.dft || "?")}${d.dft_raw ? ` <span class="meta">(${esc(String(d.dft_raw).trim().slice(0, 40))})</span>` : ""}
          · Z<sub>valence</sub> = ${d.z_valence != null ? d.z_valence : r.z_valence != null ? r.z_valence : "?"} e⁻
          · l<sub>max</sub> = ${d.l_max != null ? d.l_max : r.l_max != null ? r.l_max : "?"}
          · ${d.number_of_proj != null ? d.number_of_proj : r.number_of_proj != null ? r.number_of_proj : "?"} projecteur(s)
          · ${(d.rel === 1 || r.rel === 1) ? "scalaire-relativiste" : "non relativiste"}
          · format UPF ${esc(d.upf_version || st.version || "?")}
          · SHA-256 <code title="${esc(sha || "")}">${esc(shaShort)}</code></p>
        ${
          scf.energy_ry != null || scf.status
            ? `<p><b>SCF (niveau 1)</b> — <span class="badge ${badgeClass(scf.status)}">${esc(scf.status || "?")}</span>`
              + (scf.energy_ry != null ? ` · E<sub>tot</sub> = <b>${scf.energy_ry}</b> Ry` : "")
              + (scf.iterations != null ? ` · ${scf.iterations} itération(s)` : "")
              + ` · ecutwfc ${p.ecutwfc != null ? p.ecutwfc : r.ecutwfc} Ry · ecutrho ${p.ecutrho != null ? p.ecutrho : r.ecutrho} Ry`
              + (p.celldm != null ? ` · boîte ${p.celldm} bohr` : "")
              + (p.input_dft ? ` · input_dft ${esc(p.input_dft)}` : "")
              + `</p>`
            : `<p><b>Paramètres retenus</b> — ecutwfc ${p.ecutwfc != null ? p.ecutwfc : r.ecutwfc} Ry · ecutrho ${p.ecutrho != null ? p.ecutrho : r.ecutrho} Ry`
              + (p.mixing_beta != null ? ` · mixing ${p.mixing_beta}` : "")
              + `</p>`
        }
        ${tr.correction_note ? `<p class="hint"><b>Correction SCF :</b> ${esc(tr.correction_note)}</p>` : ""}
        ${tr.ghost_note ? `<p class="hint"><b>Correction ghost :</b> ${esc(tr.ghost_note)}</p>` : ""}
        <p><b>Rayons de coupure rc</b> (bohr)${rc.max != null ? ` — rc<sub>max</sub> = ${f(rc.max)}` : ""}</p>
        ${chans ? `<p class="meta pseudo-rc-list">${chans}</p>` : `<p class="meta">rc non renseignés dans le UPF.</p>`}
        <p class="hint">${esc(d.rc_explanation || "")}</p>
        <p><b>Électrons de valence</b> — dans le pseudo : <b>${esc(v.found_str || "—")}</b>
          · attendu (atome neutre) : <b>${esc(v.expected_str || "—")}</b>
          · somme occupations = ${v.z_from_orbitals != null ? v.z_from_orbitals : "?"} e⁻
          ${v.z_ok === false ? " · <span class='badge warning'>écart z_valence</span>" : ""}</p>
        ${
          orbRows
            ? `<table class="pseudo-table"><thead><tr><th>Couche</th><th>l</th><th>Occ. (e⁻)</th><th>rc (bohr)</th></tr></thead><tbody>${orbRows}</tbody></table>`
            : ""
        }
        ${(v.missing || []).length ? `<p class="hint"><b>Couches absentes :</b> ${esc(v.missing.join(", "))}</p>` : ""}
        ${(v.extra || []).length ? `<p class="meta"><b>Sémicore supplémentaire :</b> ${esc(v.extra.join(", "))}</p>` : ""}
        <p>${esc(v.message || "")}</p>
        <p class="hint">${esc(v.explanation || "")}</p>
        ${notes ? `<ul class="diag-actions">${notes}</ul>` : ""}
      </div>`;
  }

  function ghostBlock(r) {
    const g = r.ghost_fix;
    if (!g) return "";
    const v = g.validation_n1 || {};
    const attempts = (g.attempts || []).map((a) => {
      const ch = (a.changes || []).map((c) => `l=${c.l} rc ${c.rc_old}→${c.rc_new}`).join(", ");
      return `<li>rc ×${a.rc_factor} (${esc(ch)}) — ${a.ghost ? "ghost ENCORE présent" : "ghost éliminé"} (${fmtDuration(a.runtime_s)})</li>`;
    }).join("");
    return `
      <div class="level">
        <div class="label">Ghosts · ${g.succeeded ? "ÉLIMINÉS" : "correction tentée"}</div>
        <p>${esc(g.reason || "")}</p>
        ${g.succeeded && v.status ? `<p>Pseudo régénéré validé au niveau 1 :
          <span class="badge ${badgeClass(v.status)}">${esc(v.status)}</span>
          ${v.energy != null ? `· E = ${v.energy} Ry` : ""}
          (${fmtDuration(g.validation_runtime_s)})</p>` : ""}
        ${attempts ? `<ul class="diag-actions">${attempts}</ul>` : ""}
      </div>`;
  }

  function l3Block(r) {
    const l3 = r.level3 || null;
    if (!l3) return "";
    const cls = l3.status === "SUCCESS" ? "success" : (l3.status === "WARNING" ? "warning" : "fail");
    const f = l3.fit || {};
    const dev = l3.deviations || {};
    return `
      <div class="level">
        <div class="label">Niveau 3 · EOS cristal (${esc(l3.structure || "")}) ·
          <span class="badge ${cls}">${esc(l3.status)}</span></div>
        <p>${esc(l3.cause || "")}</p>
        ${f.a0_eq ? `<p>Fit Birch-Murnaghan : a0 éq. <b>${f.a0_eq} Å</b>
          (réf. ${(l3.ref || {}).a0} Å, écart ${dev.a0_pct} %) ·
          B0 <b>${f.b0_gpa} GPa</b>
          (réf. ${(l3.ref || {}).b0_gpa} GPa, écart ${dev.b0_pct} %) ·
          résidu max ${f.max_residual_meV_per_atom} meV/atome</p>` : ""}
        ${l3.solution ? `<p class="hint">${esc(l3.solution)}</p>` : ""}
      </div>`;
  }

  function l4Block(r) {
    const l4 = r.level4 || null;
    if (!l4) return "";
    const cls = l4.status === "SUCCESS" ? "success" : (l4.status === "WARNING" ? "warning" : "fail");
    const d = l4.delta || {};
    const p = l4.projectors || {};
    const ch = p.by_channel && Object.keys(p.by_channel).length
      ? Object.entries(p.by_channel).map(([k, v]) => `${v}*${k}`).join(" + ") : "";
    return `
      <div class="level">
        <div class="label">Niveau 4 · Delta-test (${esc(l4.structure || "jauge cutoff")}) ·
          <span class="badge ${cls}">${esc(l4.status)} · ${esc(l4.code || "")}</span></div>
        <p>${esc(l4.cause || "")}</p>
        ${d.delta_meV_per_atom != null ? `<p>Jauge ΔE : <b>${d.delta_meV_per_atom} meV/atome</b>
          à ecutrho ${l4.ecutrho} Ry identique (ecutwfc ${l4.ecutwfc} Ry vs réf. ${l4.ecutwfc_ref} Ry,
          écart ${d.pct_diff} %) · projecteurs ${d.n_proj_test != null ? d.n_proj_test : "?"} PP_BETA
          / ${d.n_proj_ref != null ? d.n_proj_ref : "?"} annoncés${ch ? ` · canaux ${esc(ch)}` : ""}${p.positive && p.positive.length ? ` · ${p.positive.length} énergie(s) d'émission positive(s)` : ""}</p>` : ""}
        ${l4.solution ? `<p class="hint">${esc(l4.solution)}</p>` : ""}
      </div>`;
  }

  function renderResults(results) {
    resultsEl.innerHTML = "";
    if (!results || !results.length) {
      statusLine.textContent = "Aucun résultat.";
      summaryEl.innerHTML = "";
      return;
    }

    const total = results.length;
    const fail = results.filter((r) =>
      ["FAILED", "ERROR", "TIMEOUT"].includes((r.level1 || {}).status)).length;
    const warn = results.filter((r) => (r.level1 || {}).status === "WARNING").length;
    const ok = total - warn - fail;
    const fixed = results.filter((r) => r.correction && r.correction.succeeded).length;
    const deghosted = results.filter((r) => r.ghost_fix && r.ghost_fix.succeeded).length;
    const degressed = results.filter((r) => r.level4 && r.level4.status === "SUCCESS").length;

    statusLine.textContent = `${total} fichier(s) testé(s)`;
    summaryEl.innerHTML = `
      <span class="summary-item"><span class="badge success">OK</span> ${ok}</span>
      <span class="summary-item"><span class="badge warning">WARNING</span> ${warn}</span>
      <span class="summary-item"><span class="badge fail">FAILED</span> ${fail}</span>
      ${fixed ? `<span class="summary-item"><span class="badge success">CORRIGÉS</span> ${fixed}</span>` : ""}
      ${deghosted ? `<span class="summary-item"><span class="badge success">SANS GHOST</span> ${deghosted}</span>` : ""}
      ${degressed ? `<span class="summary-item"><span class="badge success">DELTA OK</span> ${degressed}</span>` : ""}
    `;

    results.forEach((r) => {
      const el = document.createElement("article");
      el.className = "result";
      const l1 = r.level1 || {};
      const l2 = r.level2 || null;
      const g = r.generator || "?";

      el.innerHTML = `
        <header>
          <span class="fname">${esc(r.file)}</span>
          <span class="badge ${badgeClass(l1.status)}">${esc(l1.status || "?")}</span>
          ${r.pseudo_type ? `<span class="meta">pseudo: ${esc(r.pseudo_type)}</span>` : ""}
          ${r.element ? `<span class="meta">${esc(r.element)}</span>` : ""}
          ${g !== "?" ? `<span class="meta">${esc(g)}</span>` : ""}
          <span class="meta">ecutwfc ${r.ecutwfc} Ry</span>
          <span class="meta">ecutrho ${r.ecutrho} Ry</span>
          <span class="meta">${fmtDuration(r.runtime_s)}</span>
        </header>
        <div class="level">
          <div class="label">Niveau 1 · pw.x SCF</div>
          <p>${esc(l1.cause || "SCF terminé sans anomalie.")}</p>
          ${l1.solution ? `<p class="hint">${esc(l1.solution)}</p>` : ""}
        </div>
        ${diagnosisBlock(r)}
        ${structureBlock(r)}
        ${ghostBlock(r)}
        ${correctionBlock(r)}
        ${l2 ? `
        <div class="level">
          <div class="label">Niveau 2 · ${esc(r.generator || "logders/ghosts")}</div>
          <p>${esc(l2.cause || "Aucun ghost signalé.")}</p>
          ${l2.solution ? `<p class="hint">${esc(l2.solution)}</p>` : ""}
        </div>` : ""}
        ${l3Block(r)}
        ${l4Block(r)}
        ${readyBlock(r)}
        ${descBlock(r)}
      `;
      resultsEl.appendChild(el);
    });
  }

  // ---- Job asynchrone ------------------------------------------------------

  function setBusy(busy) {
    activeJobId = busy ? activeJobId : null;
    btnTestSelected.disabled = busy || selected.size === 0;
    btnTestAll.disabled = busy || files.length === 0;
    if (btnPurgeList) btnPurgeList.disabled = busy || files.length === 0;
    btnStop.disabled = !busy;
    btnGo.disabled = busy;
  }

  function stopPolling() {
    if (pollInterval) {
      clearTimeout(pollInterval);
      pollInterval = null;
    }
  }

  function finishJob(ok) {
    stopPolling();
    activeJobId = null;
    pollFailures = 0;
    setProgress(null);
    setBusy(false);
    btnStop.textContent = ok ? "✓ Terminé" : "✕ Annuler";
  }

  async function pollJob(jobId, displayDir) {
    if (aborted) return;
    let j;
    try {
      const r = await fetch(`/api/jobs/${jobId}`, { cache: "no-store" });
      if (r.status === 404) {
        // Le serveur a pu redémarrer : on tente de retrouver le dernier job.
        const rec = await fetchLatestJob();
        if (rec && rec.id && rec.id !== jobId) {
          activeJobId = rec.id;
          handleJobStatus(rec, displayDir);
          return;
        }
        throw new Error("Job perdu (le serveur a redémarré). Relancez le test.");
      }
      j = await r.json();
      if (!j.ok) throw new Error(j.error || "Job perdu");
      pollFailures = 0;
    } catch (e) {
      if (aborted) return;
      pollFailures += 1;
      if (pollFailures <= 6) {
        statusLine.textContent = `Connexion interrompue… nouvelle tentative (${pollFailures}/6)`;
        pollInterval = setTimeout(() => pollJob(jobId, displayDir), 1500);
        return;
      }
      finishJob(false);
      statusLine.textContent = e.message || String(e);
      return;
    }
    handleJobStatus(j, displayDir);
  }

  function handleJobStatus(j, displayDir) {
    if (aborted) return;

    if (j.status === "running") {
      const elapsed = j.created ? Date.now() / 1000 - j.created : null;
      const where = displayDir ? `${displayDir} · ` : "";
      statusLine.textContent =
        `${where}${j.progress || "Tests en cours…"}` +
        (elapsed != null ? `  (${fmtDuration(elapsed)})` : "");
      setProgress(j);
      activeJobId = j.id;
      btnStop.disabled = false;
      btnGo.disabled = true;
      btnTestSelected.disabled = true;
      btnTestAll.disabled = true;
      if (btnPurgeList) btnPurgeList.disabled = true;
      stopPolling();
      pollInterval = setTimeout(() => pollJob(j.id, displayDir), 1200);
      return;
    }

    if (j.status === "error") {
      finishJob(false);
      statusLine.textContent = j.error || "Erreur du job.";
      return;
    }

    // status === "done"
    finishJob(true);
    renderResults(j.results || []);
  }

  async function fetchLatestJob() {
    try {
      const r = await fetch("/api/jobs", { cache: "no-store" });
      const j = await r.json();
      return j && j.ok ? j.job : null;
    } catch {
      return null;
    }
  }

  async function resumeLatestJob() {
    const j = await fetchLatestJob();
    if (!j) return;
    if (j.status === "running") {
      activeJobId = j.id;
      handleJobStatus(j, j.directory || "");
    } else if (j.status === "done" && (j.results || []).length) {
      renderResults(j.results);
      statusLine.textContent = "Résultats du dernier test (restaurés).";
    }
  }

  async function runTests({ all = false } = {}) {
    // Cinq cases : Niveau 1 (pw.x SCF), Niveau 2 (logders/ghosts),
    // Niveau 3 (EOS cristal, optionnel), Niveau 4 (delta-test, optionnel),
    // Corrections automatiques.
    const run_level1 = optLevel1 ? !!optLevel1.checked : true;
    const run_level2 = optLevel2 ? !!optLevel2.checked : true;
    const run_level3 = optLevel3 ? !!optLevel3.checked : false;
    const run_level4 = optLevel4 ? !!optLevel4.checked : false;
    const auto_correct = optAutoCorrect ? !!optAutoCorrect.checked : true;
    if (!run_level1 && !run_level2 && !run_level3 && !run_level4) {
      statusLine.textContent = "Sélectionnez au moins un niveau de test (niveau 1, niveau 2, niveau 3 ou niveau 4).";
      return;
    }

    aborted = false;
    pollFailures = 0;
    stopPolling();
    lastRunAll = all;

    const loadingEl = document.createElement("div");
    loadingEl.className = "loading-spinner";
    loadingEl.innerHTML = `<div class="spinner"></div><span>Analyse en cours…</span>`;
    resultsEl.innerHTML = "";
    summaryEl.innerHTML = "";
    resultsEl.appendChild(loadingEl);

    activeJobId = "pending";
    setBusy(true);
    btnStop.textContent = "✕ Annuler";
    setProgress({ status: "running" });
    statusLine.textContent = "Tests en cours…";

    const body = all
      ? { dir: dirInput.value.trim(), run_level1, run_level2, run_level3, run_level4, auto_correct }
      : {
          files: [...selected],
          paths: files.filter((f) => selected.has(f.name)).map((f) => f.path),
          run_level1,
          run_level2,
          run_level3,
          run_level4,
          auto_correct,
        };
    const displayDir = all ? (dirInput.value.trim().split("/").pop() || "dossier") : "";

    try {
      const start = await fetch("/api/test/async", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const sj = await start.json();
      if (!sj.ok) throw new Error(sj.error || "Échec lancement");
      activeJobId = sj.job_id;
      pollJob(sj.job_id, displayDir);
    } catch (e) {
      finishJob(false);
      if (aborted) {
        statusLine.textContent = "Arrêté.";
        return;
      }
      statusLine.textContent = e.message || String(e);
    }
  }

  // ---- Boutons Annuler / Relancer (créés dynamiquement) --------------------

  const actionsEl = $(".actions");

  const btnStop = document.createElement("button");
  btnStop.type = "button";
  btnStop.className = "btn secondary stop-btn";
  btnStop.id = "btn-stop";
  btnStop.textContent = "✕ Annuler";
  btnStop.disabled = true;
  btnStop.addEventListener("click", () => {
    if (!activeJobId) return;
    // Un job lancé côté serveur ne peut pas être interrompu ici : on s'en
    // détache proprement côté interface (le calcul serveur se terminera seul).
    aborted = true;
    stopPolling();
    finishJob(false);
    statusLine.textContent = "Arrêté côté interface (le calcul serveur peut se terminer seul).";
  });

  const btnGo = document.createElement("button");
  btnGo.type = "button";
  btnGo.className = "btn primary go-btn";
  btnGo.id = "btn-go";
  btnGo.textContent = "▶ Relancer";
  btnGo.disabled = true;
  btnGo.addEventListener("click", () => {
    runTests({ all: lastRunAll });
  });

  if (actionsEl) {
    actionsEl.appendChild(btnStop);
    actionsEl.appendChild(btnGo);
  }

  // ---- Purge ---------------------------------------------------------------

  if (btnPurgeList) {
    btnPurgeList.addEventListener("click", () => {
      files = [];
      selected = new Set();
      fileList.innerHTML =
        '<p class="meta" style="color:var(--muted)">Liste purgée — choisissez une bibliothèque ou un dossier.</p>';
      libraryMeta.textContent = "";
      syncButtons();
      statusLine.textContent = "Liste purgée.";
    });
  }

  if (btnArchive) {
    btnArchive.addEventListener("click", async () => {
      btnArchive.disabled = true;
      statusLine.textContent = "Archivage des pseudos validés…";
      try {
        const r = await fetch("/api/archive", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ source: "ready" }),
        });
        const j = await r.json();
        if (!j.ok) throw new Error(j.error || "Échec archivage");
        statusLine.textContent = archiveText(j);
      } catch (e) {
        statusLine.textContent = `Archivage : ${e.message || e}`;
      }
      btnArchive.disabled = false;
    });
  }

  if (btnPurge) {
    btnPurge.addEventListener("click", async () => {
      if (activeJobId) {
        statusLine.textContent = "Un test est en cours — annulez-le avant de purger.";
        return;
      }
      btnPurge.disabled = true;
      statusLine.textContent = "Purge…";
      try {
        const r = await fetch("/api/purge", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ what: "all" }),
        });
        const j = await r.json();
        if (!j.ok) throw new Error(j.error || "Échec purge");
      } catch (e) {
        statusLine.textContent = `Purge : ${e.message || e}`;
      }
      // Rafraîchit entièrement la vue
      resultsEl.innerHTML = "";
      summaryEl.innerHTML = "";
      setProgress(null);
      btnStop.textContent = "✕ Annuler";
      btnStop.disabled = true;
      btnGo.disabled = true;
      await loadHealth();
      await refreshList();
      statusLine.textContent = "Interface purgée et rafraîchie.";
      btnPurge.disabled = false;
    });
  }

  // ---- Santé API / boot ----------------------------------------------------

  async function loadHealth() {
    healthSet("Connexion…", "checking");
    try {
      const r = await fetch("/api/health", { cache: "no-store" });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || "API erreur");
      healthOk = true;
      healthSet(`API ✓ · pw ${j.pw_ok ? "✓" : "✗"} · ld1 ${j.ld1_ok ? "✓" : "✗"}`, "ok");
      libraries = j.libraries || {};
      const chips = $(".generator-tags");
      if (chips) {
        chips.innerHTML = "";
        for (const key of generatorOrder) {
          const info = libraries[key];
          const tag = document.createElement("button");
          tag.type = "button";
          tag.className = "generator-tag" + (key === "local" ? " active" : "");
          const infoText = info ? `${info.files ? info.files.length : "0"} UPF dans ${String(info.path || "").split("/").pop()}` : "dossier introuvable";
          tag.innerHTML = `<span class="bi-name">${genLabel(key)}</span><span class="meta">${infoText}</span>`;
          tag.addEventListener("click", () => selectLibrary(key));
          chips.appendChild(tag);
        }
      }
      if (!libSelectedOnce) {
        libSelectedOnce = true;
        selectLibrary("local");
      } else if (!dirInput.value) {
        dirInput.value = j.pseudos_dir || "";
      }
      return true;
    } catch (e) {
      healthOk = false;
      healthSet("API hors ligne — cliquer pour retenter", "bad");
      statusLine.textContent = `API injoignable (${e.message || e}). Vérifiez que ./DEMARRER.sh tourne.`;
      return false;
    }
  }

  // Ne pas laisser le click sur le health label cacher le retry
  healthEl.addEventListener("click", async (e) => {
    const target = e.target;
    if (target.closest(".health-retry")) return;
    healthRetry.hidden = true;
    const ok = await loadHealth();
    if (ok) await refreshList();
    else healthRetry.hidden = false;
  });

  // Bouton de réessai en cas de hors ligne (visuel associé à la bannière de santé)
  const healthRetry = document.createElement("button");
  healthRetry.type = "button";
  healthRetry.className = "health-retry";
  healthRetry.textContent = "↻ Réessayer";
  healthRetry.hidden = true;
  healthRetry.setAttribute("aria-label", "Réessayer de reconnecter à l'API");
  healthEl.insertAdjacentElement("beforeend", healthRetry);

  healthRetry.addEventListener("click", async () => {
    healthRetry.hidden = true;
    healthRetry.disabled = true;
    const ok = await loadHealth();
    if (ok) await refreshList();
    else healthRetry.hidden = false;
    healthRetry.disabled = false;
  });

  // Ne pas masquer le retry quand on clique sur le label de santé
  healthEl.addEventListener("click", async (e) => {
    if (e.target.closest(".health-retry")) return;
    healthRetry.hidden = true;
    const ok = await loadHealth();
    if (ok) await refreshList();
    else healthRetry.hidden = false;
  });

  // Re-tentative automatique tant que l'API est hors ligne
  setInterval(() => {
    if (healthOk === false && !activeJobId) loadHealth();
  }, 15000);

  // ---- Vues / navigation ---------------------------------------------------

  const VIEWS = ["accueil", "test_pseudos", "valides", "guide"];

  const guideSummaries = {
    accueil:
      "Validez tous vos pseudopotentiels UPF (Quantum ESPRESSO) : générés par ld1, APE, ATOMPAW et ONCVPSP, téléchargés des bases de données (SSSP, PseudoDojo…) ou locaux. Chaîne de test : Niveau 1 pw.x SCF (stabilité) → Niveau 2 dérivées logarithmiques & ghosts → Niveau 3 optionnel EOS sur cristal (Birch-Murnaghan, a0 / B0) → Niveau 4 delta-test qualité projecteurs (jauge ΔE) → corrections automatiques en cas d'échec → archive des pseudos validés.",
    test_pseudos:
      "Interface de validation de pseudopotentiels. Importez qui vous voulez tester : bibliothèques générateur (local, ONCVPSP, ld1, ATOMPAW, APE), pseudos téléchargés des bases de données (bouton Déposer le pseudo à testé) ou pseudos locaux. 5 options cochables : 1 Niveau 1 (pw.x SCF), 2 Niveau 2 (logders/ghosts), 3 Niveau 3 (EOS cristal, optionnel), 4 Niveau 4 (delta-test qualité projecteurs, optionnel), 5 corrections automatiques.",
    guide:
      "Guide méthodologique de validation de pseudopotentiels UPF.\n" +
      "• Toutes les sources : 4 générateurs (ld1, APE, ATOMPAW, ONCVPSP), bases de données et sites, pseudos locaux.\n" +
      "• Chaîne de test : pw.x (SCF atomisé) → dérivées logarithmiques / ghosts → Niveau 3 optionnel (EOS Birch-Murnaghan, a0 / B0 vs expérimental) → Niveau 4 optionnel (delta-test qualité projecteurs, jauge ΔE à ecutrho fixé) → corrections automatiques en cas d'échec.\n" +
      "• 4 tests canoniques : convergence SCF, delta-test qualité projecteurs, transferabilité, propriétés physiques.\n" +
      "• Grille de conformité 8 points : format UPF, fonctionnelle XC, tests canoniques, cutoffs, transferabilité, validation physique, reproductibilité, exécutions QE.\n" +
      "• Défaillances P0/P1/P2 : détection type pseudo (NC/US/PAW), adaptation ecutrho, delta-test absent, timeouts, UI améliorations.",
  };

  function setActiveNav(name) {
    document.querySelectorAll(".nav a").forEach((a) => {
      a.classList.toggle("active", a.getAttribute("href") === "#" + name);
    });
  }

  function showView(name) {
    const target = VIEWS.includes(name) ? name : "accueil";
    // Un seul onglet visible : la classe .active sur la SECTION pilote l'affichage
    // (cf. app.css : section:not(.active) { display: none }).
    // Pas de style.inline ici : inline "none" écraserait la règle .active du CSS.
    VIEWS.forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.classList.toggle("active", el.id === target);
    });
    setActiveNav(target);
    // Onglet pseudos_testés_validés : rafraîchir le listing à chaque ouverture.
    if (target === "valides") loadValides();
    const guideSummary = document.getElementById("guide-summary");
    if (guideSummary && target === "guide") {
      guideSummary.textContent = guideSummaries.guide;
    }
    window.scrollTo({ top: 0, left: 0, behavior: "instant" });
  }

  document.querySelectorAll(".nav a[data-view]").forEach((a) => {
    a.addEventListener("click", (e) => {
      e.preventDefault();
      const name = a.getAttribute("data-view");
      showView(name);
    });
  });
  window.addEventListener("hashchange", () => showView(location.hash.slice(1)));

  // Garantit qu'au chargement, un seul onglet est actif à la fois,
  // et que les anciennes classes .active ne laissent pas les onglets s'ouvrir.
  showView(location.hash.slice(1) || "accueil");

  // ---- Événements ----------------------------------------------------------

  // La zone de dépôt ne s'ouvre qu'au clic direct sur le texte, pas sur l'input file invisible.
  // On vérifie que le clic vient du texte visible (span), pas de l'input caché ou de la div elle-même.
  dropZone.addEventListener("click", (e) => {
    // Ignorer si le clic vient de l'input file (invisible) ou de la div entière
    const target = e.target;
    if (target.tagName === "INPUT" || target === dropZone) return;
    // Vérifier que le clic vient de l'espace texte (ou d'un élément dedans)
    if (!target.closest("span") && target.tagName !== "TEXTAREA" && target.tagName !== "LABEL") return;
    fileInput.click();
  });

  btnTestSelected.addEventListener("click", () => runTests({ all: false }));
  btnTestAll.addEventListener("click", () => runTests({ all: true }));


  // ---- Onglet pseudos_testés_validés ---------------------------------------

  const validesEl = $("#valides-list");
  const validesPathEl = $("#valides-path");

  async function loadValides() {
    if (!validesEl) return;
    try {
      const r = await fetch("/api/archive", { cache: "no-store" });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || "Archive inaccessible");
      if (validesPathEl) {
        validesPathEl.textContent =
          `Chemin : ${j.root} · ${j.count} UPF archivé(s)`;
      }
      if (!j.files || !j.files.length) {
        validesEl.innerHTML =
          '<p class="meta">📂 pseudos_testés_validés est vide. Utilisez « 📦 Archiver les validés » pour y déposer les pseudos testés/corrigés.</p>';
        return;
      }
      validesEl.innerHTML = j.files.map((f) => `
        <div class="file-item" role="listitem">
          <div>
            <div class="name"><a href="/api/archive/file/${encodeURIComponent(f.name)}" download>${esc(f.name)}</a></div>
            <div class="meta">${esc(f.element || "?")} · ${esc(f.generator || "?")} · z<sub>val</sub>=${f.z_valence != null ? f.z_valence : "—"}</div>
          </div>
          <span class="meta">${Math.round((f.size || 0) / 1024)} ko</span>
        </div>
      `).join("");
    } catch (e) {
      validesEl.innerHTML = `<p class="meta">Archive inaccessible (${esc(e.message || e)}).</p>`;
    }
  }
  // Drag & drop : glisser-déposer des fichiers sur la zone de dépôt.
  dropZone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZone.classList.add("drag");
  });
  dropZone.addEventListener("dragleave", () => dropZone.classList.remove("drag"));
  dropZone.addEventListener("drop", async (e) => {
    e.preventDefault();
    dropZone.classList.remove("drag");
    if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) {
      try {
        await uploadFiles(e.dataTransfer.files);
      } catch (err) {
        statusLine.textContent = err.message || String(err);
      }
    }
  });
  fileInput.addEventListener("change", async () => {
    if (fileInput.files && fileInput.files.length) {
      try {
        await uploadFiles(fileInput.files);
      } catch (err) {
        statusLine.textContent = err.message || String(err);
      }
      fileInput.value = "";
    }
  });

  // ---- Démarrage -----------------------------------------------------------

  showView(location.hash.slice(1));

  (async () => {
    const ok = await loadHealth();
    if (ok) await refreshList();
    await resumeLatestJob();
  })();
})();

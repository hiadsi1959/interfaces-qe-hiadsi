#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Serveur Flask — Test Pseudos (validation UPF Quantum ESPRESSO)."""

from __future__ import annotations

import hashlib
import os
import shutil
import sys
import threading
import time
import uuid
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory, send_file

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "engine"))

from test_pseudos import (  # noqa: E402
    parse_upf_meta,
    test_one_upf,
    validate_upf_structure,
    _correct_ghosts_ld1_atompaw_upf,
    PHASE_TOTAL,
    phase_label,
)

HOST = os.environ.get("TEST_PSEUDOS_HOST", "127.0.0.1")
PORT = int(os.environ.get("TEST_PSEUDOS_PORT", "5040"))
QE_BIN = Path(os.environ.get("QE_BIN_DIR", str(Path.home() / "q-e-qe-7.5" / "bin")))
PW_BIN = os.environ.get("PW_BIN", str(QE_BIN / "pw.x"))
LD1_BIN = os.environ.get("LD1_BIN", str(QE_BIN / "ld1.x"))
# Binaires des générateurs (niveau 2 / suppression des ghosts), embarqués dans bin/.
_GEN_BINS = {
    "oncvpsp": os.environ.get("ONCVPSP_BIN", "./bin/oncvpsp.x"),
    "atompaw": os.environ.get("ATOMPAW_BIN", "./bin/atompaw"),
    "ape": os.environ.get("APE_BIN", "./bin/ape"),
}

ONCV_ROOT = os.environ.get(
    "ONCVPSP_OUT_ROOT",
    str(Path.home() / "generation_pseudos" / "pseudos-oncvpsp"),
)
PSEUDOS_DIR = Path(os.environ.get("PSEUDOS_DIR", str(ROOT / "pseudos")))
UPLOADS_DIR = ROOT / "uploads"
WORK_DIR = ROOT / "work"
DOCS_DIR = ROOT / "docs"
INTERFACE_DIR = ROOT / "interface"
# Dossiers « prêts à l'emploi » : UPF + input pw.x validé par l'auto-correction.
READY_DIR = Path(os.environ.get("PSEUDO_READY_DIR", str(ROOT / "ready")))
# Archive des pseudos testés/corrigés (un UPF par fichier, à plat).
VALIDES_DIR = Path(os.environ.get("PSEUDO_VALIDES_DIR",
                                    str(ROOT / "pseudos_testés_validés")))

# Bibliothèques générateur (generation_pseudos) — accessibles depuis l'UI


_GP = Path(os.environ.get("GENERATION_PSEUDOS_ROOT",
                           str(Path.home() / "generation_pseudos")))
# Racine générée par chaque générateur. ONCVPSP est la seule qui publie le .out
# de génération dans un répertoire à part (pseudos-oncvpsp/_runs + _work) ;
# ld1/atompaw/ape publient le journal de calcul dans le répertoire _runs.
LIBRARY_DIRS = {
    "oncvpsp": {
        "upfs": Path(os.environ.get("LIB_ONCV", str(_GP / "pseudos-oncvpsp"))),
        "bin": PW_BIN,
    },
    "ld1": {
        "upfs": Path(os.environ.get("LIB_LD1", str(_GP / "pseudos-ld1"))),
        "bin": PW_BIN,
    },
    "atompaw": {
        "upfs": Path(os.environ.get("LIB_ATOMPAW", str(_GP / "pseudos-atompaw"))),
        "bin": PW_BIN,
    },
    "ape": {
        "upfs": Path(os.environ.get("LIB_APE", str(_GP / "pseudos-APE"))),
        "bin": PW_BIN,
    },
    "local": {
        "upfs": PSEUDOS_DIR,
        "bin": PW_BIN,
    },
}

UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
WORK_DIR.mkdir(parents=True, exist_ok=True)
PSEUDOS_DIR.mkdir(parents=True, exist_ok=True)
DOCS_DIR.mkdir(parents=True, exist_ok=True)
READY_DIR.mkdir(parents=True, exist_ok=True)
VALIDES_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__, static_folder=str(INTERFACE_DIR), static_url_path="")

# Jobs asynchrones {id: {status, results, error, created, ...}}
_JOBS: dict = {}
_JOBS_LOCK = threading.Lock()
# État partagé : dernier job lancé (permet de retrouver un résultat après un
# rafraîchissement de page, même si le navigateur a rechargé entre-temps).
_STATE = {"last_job": None, "started": time.time()}


def _resolve_bin(path_str: str) -> str:
    """Chemin d'exécutable, toujours ABSOLU.

    pw.x et ld1.x sont relancés avec ``cwd`` posé sur un sous-répertoire de
    travail : un chemin relatif (``bin/pw.x``) ne survivrait pas au changement
    de répertoire (PW_MISSING). On teste donc le chemin tel quel, puis relatif
    au projet, puis ``PATH``, et on retourne un absolu dans tous les cas.
    """
    p = Path(path_str).expanduser()
    project_root = Path(__file__).resolve().parent.parent
    for cand in (p, p if p.is_absolute() else project_root / p):
        try:
            if cand.is_file() and os.access(cand, os.X_OK):
                return str(cand.resolve())
        except OSError:
            continue
    which = shutil.which(path_str)
    return str(Path(which).resolve()) if which else str(p.resolve())


def resolve_generator_bin(generator: str | None) -> str | None:
    """Binaire pw.x associé à un générateur (partagé ici, PW_BIN par défaut)."""
    lib = LIBRARY_DIRS.get((generator or "").lower())
    if isinstance(lib, dict):
        return _resolve_bin(lib.get("bin") or PW_BIN)
    return None


def level2_roots() -> list:
    """Répertoires où chercher les journaux de génération du niveau 2.

    Sans cela, le niveau 2 d'un pseudo ld1/APE/ATOMPAW resterait toujours
    SKIPPED alors que le journal existe dans la bibliothèque du générateur.
    """
    roots = []
    if ONCV_ROOT:
        roots.append(ONCV_ROOT)
    for lib in LIBRARY_DIRS.values():
        if isinstance(lib, dict) and lib.get("upfs"):
            roots.append(str(lib["upfs"]))
    seen, out = set(), []
    for r in roots:
        if r and r not in seen:
            seen.add(r)
            out.append(r)
    return out


def _list_upfs(directory: Path | dict) -> list:
    files = []
    target: Path
    if isinstance(directory, dict):
        upfs_dir = directory.get("upfs")
        if not upfs_dir or not isinstance(upfs_dir, Path) or not upfs_dir.is_dir():
            return files
        target = upfs_dir
    else:
        target = directory
    if not target.is_dir():
        return files
    for p in sorted(set(target.glob("*.UPF")) | set(target.glob("*.upf"))):
        try:
            meta = parse_upf_meta(p)
        except Exception:
            meta = {}
        files.append(
            {
                "name": p.name,
                "path": str(p.resolve()),
                "size": p.stat().st_size if p.exists() else 0,
                "element": meta.get("element"),
                "generator": meta.get("generator"),
                "dft": meta.get("dft"),
                "z_valence": meta.get("z_valence"),
            }
        )
    return files


@app.get("/api/health")
def health():
    pw = _resolve_bin(PW_BIN)
    ld1 = _resolve_bin(LD1_BIN)
    libs = {}
    for k, lib in LIBRARY_DIRS.items():
        if isinstance(lib, dict):
            upfs_dir = lib.get("upfs")
            if not upfs_dir or not upfs_dir.is_dir():
                libs[k] = {"path": str(upfs_dir) if upfs_dir else "", "exists": False, "n_upf": 0}
                continue
            n = len(list(upfs_dir.glob("*.UPF")) + list(upfs_dir.glob("*.upf")))
            libs[k] = {"path": str(upfs_dir), "exists": True, "n_upf": n}
        else:
            p = lib
            libs[k] = {"path": str(p), "exists": p.is_dir(), "n_upf": (
                len(list(p.glob("*.UPF")) + list(p.glob("*.upf"))) if p.is_dir() else 0
            )}
    return jsonify(
        {
            "ok": True,
            "app": "test_pseudos",
            "pw": pw,
            "pw_ok": Path(pw).is_file(),
            "ld1": ld1,
            "ld1_ok": Path(ld1).is_file(),
            "generator_bins": {
                name: {"path": _resolve_bin(path),
                       "ok": Path(_resolve_bin(path)).is_file()}
                for name, path in _GEN_BINS.items()
            },
            "pseudos_dir": str(PSEUDOS_DIR),
            "oncv_root": ONCV_ROOT,
            "ready_dir": str(READY_DIR),
            "uptime_s": round(time.time() - _STATE.get("started", time.time()), 1),
            "libraries": libs,
            "guide_pdf": (
                str(DOCS_DIR / "Guide_Methodologique_Validation_Pseudopotentiels.pdf")
                if (DOCS_DIR / "Guide_Methodologique_Validation_Pseudopotentiels.pdf").is_file()
                else None
            ),
        }
    )


@app.get("/api/libraries")
def libraries():
    """Liste les dossiers par générateur (oncvpsp, ld1, atompaw, ape)."""
    out = {}
    for key, lib in LIBRARY_DIRS.items():
        if isinstance(lib, dict):
            upfs_dir = lib.get("upfs")
            exists = bool(upfs_dir and upfs_dir.is_dir())
            path = str(upfs_dir) if upfs_dir else ""
            files = _list_upfs(upfs_dir) if exists else []
        else:
            path = str(lib)
            exists = lib.is_dir()
            files = _list_upfs(lib) if exists else []
        out[key] = {
            "path": path,
            "exists": exists,
            "files": files,
        }
    return jsonify({"ok": True, "libraries": out})


@app.get("/api/pseudos")
def list_pseudos():
    src = request.args.get("dir") or str(PSEUDOS_DIR)
    try:
        path = Path(src).expanduser().resolve()
    except OSError:
        return jsonify({"ok": False, "error": "Chemin invalide."}), 400
    if not path.is_dir():
        return jsonify({"ok": False, "error": f"Dossier introuvable : {path}"}), 404
    if not _inside(path, _allowed_roots()):
        return jsonify({
            "ok": False,
            "error": "Chemin hors des racines autorisées.",
        }), 403
    return jsonify({"ok": True, "dir": str(path), "files": _list_upfs(path)})


def _browse_roots() -> list:
    """Racines autorisées pour le parcours de dossiers (sécurité)."""
    roots = []
    for raw in (os.environ.get("GENERATION_PSEUDOS_ROOT", str(_GP)), PSEUDOS_DIR, ROOT):
        try:
            roots.append(Path(raw).resolve())
        except OSError:
            pass
    return roots


def _inside(path: Path, roots: list) -> bool:
    p = str(path)
    for r in roots:
        rs = str(r)
        if p == rs or p.startswith(rs + os.sep):
            return True
    return False


def _allowed_roots() -> list:
    """Chemins où l'API peut lire ou lister des UPF (liste + tests QE)."""
    roots = []
    seen = set()

    def _add(raw):
        try:
            p = Path(raw).resolve()
        except OSError:
            return
        key = str(p)
        if key not in seen:
            seen.add(key)
            roots.append(p)

    for r in _browse_roots():
        _add(r)
    for lib in LIBRARY_DIRS.values():
        if isinstance(lib, dict) and lib.get("upfs"):
            _add(lib["upfs"])
    for extra in (WORK_DIR, UPLOADS_DIR, READY_DIR, VALIDES_DIR):
        _add(extra)
    if ONCV_ROOT:
        _add(ONCV_ROOT)
    return roots


def _resolve_allowed_upf(path_like: str) -> Path | None:
    """Fichier UPF autorisé, ou ``None``."""
    try:
        p = Path(path_like).expanduser().resolve()
    except OSError:
        return None
    if not p.is_file() or p.suffix.lower() != ".upf":
        return None
    if _inside(p, _allowed_roots()):
        return p
    return None


def _resolve_test_path(name_or_path: str) -> Path | None:
    """Résout un nom ou chemin de pseudo pour l'API de test."""
    p = Path(name_or_path).expanduser()
    if p.is_file():
        return _resolve_allowed_upf(str(p))
    for base in (PSEUDOS_DIR, UPLOADS_DIR):
        cand = base / p.name
        if cand.is_file():
            return cand
    return _resolve_allowed_upf(str(PSEUDOS_DIR / p.name))


def _resolve_directory(dir_path: str) -> Path | None:
    try:
        p = Path(dir_path).expanduser().resolve()
    except OSError:
        return None
    if not p.is_dir():
        return None
    if _inside(p, _allowed_roots()):
        return p
    return None


@app.get("/api/browse")
def browse():
    """Parcourt les dossiers de pseudos (generation_pseudos, pseudos/, projet).

    Permet à l'interface de laisser l'utilisateur choisir lui-même le
    sous-dossier d'un générateur (par exemple
    ``generation_pseudos/pseudos-oncvpsp/_runs/Ts_20261025-220006``).
    """
    roots = _browse_roots()
    raw = (request.args.get("path") or "").strip()
    if raw:
        target = Path(raw).expanduser()
    else:
        existing = [r for r in roots if r.is_dir()]
        if not existing:
            return jsonify({"ok": False, "error": "Aucune racine de pseudos accessible."}), 404
        target = existing[0]
    try:
        target = target.resolve()
    except OSError:
        return jsonify({"ok": False, "error": "Chemin invalide."}), 400

    if not _inside(target, roots):
        return jsonify({
            "ok": False,
            "error": "Chemin hors des racines autorisées (generation_pseudos / pseudos).",
        }), 403
    if not target.is_dir():
        return jsonify({"ok": False, "error": f"Dossier introuvable : {target}"}), 404

    dirs = []
    n_upf = 0
    try:
        for child in sorted(target.iterdir(), key=lambda c: c.name.lower()):
            if child.name.startswith("."):
                continue
            if child.is_dir():
                try:
                    count = len(list(child.glob("*.UPF")) + list(child.glob("*.upf")))
                except OSError:
                    count = 0
                dirs.append({"name": child.name, "path": str(child), "n_upf": count})
            elif child.suffix.lower() == ".upf":
                n_upf += 1
    except OSError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500

    parent = None
    if target.parent != target and _inside(target.parent, roots):
        parent = str(target.parent)

    return jsonify({
        "ok": True,
        "path": str(target),
        "parent": parent,
        "dirs": dirs,
        "n_upf": n_upf,
        "roots": [{"name": r.name, "path": str(r)} for r in roots if r.is_dir()],
    })


@app.post("/api/validate")
def validate_upf():
    """Contrôle structurel UPF sans exécution QE (réponse immédiate)."""
    data = request.get_json(force=True, silent=True) or {}
    names = data.get("files") or data.get("names") or []
    paths = data.get("paths") or []
    out = []
    for item in list(names) + list(paths):
        upf = _resolve_test_path(item)
        if not upf:
            out.append({
                "file": Path(item).name,
                "path": str(item),
                "ok": False,
                "error": "Fichier inaccessible ou hors racines autorisées.",
            })
            continue
        try:
            structure = validate_upf_structure(upf)
            meta = parse_upf_meta(upf)
        except Exception as exc:
            out.append({
                "file": upf.name,
                "path": str(upf),
                "ok": False,
                "error": str(exc),
            })
            continue
        out.append({
            "file": upf.name,
            "path": str(upf),
            "ok": True,
            "structure": structure,
            "element": meta.get("element"),
            "generator": meta.get("generator"),
            "pseudo_type": meta.get("pseudo_type"),
        })
    if not out:
        return jsonify({"ok": False, "error": "Aucun fichier à valider."}), 400
    return jsonify({"ok": True, "results": out, "count": len(out)})


@app.post("/api/upload")
def upload():
    if "files" not in request.files and "file" not in request.files:
        return jsonify({"ok": False, "error": "Aucun fichier envoyé."}), 400
    files = request.files.getlist("files") or [request.files["file"]]
    saved = []
    for f in files:
        if not f or not f.filename:
            continue
        name = Path(f.filename).name
        if not name.lower().endswith((".upf",)):
            continue
        dest = UPLOADS_DIR / name
        f.save(dest)
        # Aussi disponible dans pseudos/ pour listage
        link = PSEUDOS_DIR / name
        if not link.exists():
            try:
                os.symlink(dest, link)
            except OSError:
                shutil.copy(dest, link)
        saved.append(name)
    return jsonify({"ok": True, "saved": saved, "files": _list_upfs(PSEUDOS_DIR)})


def _job_text(job: dict, extra: str | None = None) -> str:
    """Texte d'avancement d'un job : fichier + étape du pipeline (+ détail)."""
    idx = (job.get("done") or 0) + 1
    total = job.get("total") or "?"
    parts = [f"Fichier {idx}/{total}"]
    if job.get("current"):
        parts.append(str(job["current"]))
    if job.get("phase"):
        parts.append(f"étape {job['phase']}/{job.get('phases') or PHASE_TOTAL}"
                     f" — {job.get('phase_label') or phase_label(job['phase'])}")
    if extra:
        parts.append(extra)
    return " · ".join(parts)


def _run_paths(
    paths: list[str],
    run_level2: bool = True,
    run_level1: bool = True,
    run_level3: bool = False,
    run_level4: bool = False,
    job_id: str | None = None,
    progress_cb=None,
    auto_correct: bool | None = None,
    tick_cb=None,
    phase_cb=None,
) -> list:
    roots = level2_roots() or None
    work = WORK_DIR / (job_id or uuid.uuid4().hex[:8])
    work.mkdir(parents=True, exist_ok=True)
    out = []
    total = len(paths)
    for idx, p in enumerate(paths, 1):
        if progress_cb is not None:
            try:
                progress_cb(idx, total, Path(p).name)
            except Exception:
                pass
        upf = Path(p).expanduser()
        try:
            upf = upf.resolve()
        except OSError:
            pass
        if not upf.is_file():
            out.append({
                "file": upf.name,
                "path": str(upf),
                "verdict": "ERROR",
                "level1": {
                    "status": "ERROR",
                    "cause": "Fichier introuvable.",
                    "solution": "Vérifiez le chemin.",
                },
                "level2": None,
            })
            continue
        try:
            meta = parse_upf_meta(upf)
            generator = meta.get("generator")
            pw_bin = resolve_generator_bin(generator) if generator else None
        except Exception:
            pw_bin = None
        pw_executable = pw_bin if pw_bin else _resolve_bin(PW_BIN)
        ld1_bin = _resolve_bin(LD1_BIN)
        upf_work = work / upf.stem
        upf_work.mkdir(parents=True, exist_ok=True)
        file_tick = None
        if tick_cb is not None:
            file_tick = (lambda it, el, _n=upf.name: tick_cb(_n, it, el))
        out.append(test_one_upf(
            upf,
            pw_executable=pw_executable,
            ld1_bin=ld1_bin,
            work_dir=str(upf_work),
            oncv_search_roots=roots,
            run_level1=run_level1,
            run_level2=run_level2,
            run_level3=run_level3,
            run_level4=run_level4,
            auto_correct=auto_correct,
            ready_dir=str(READY_DIR),
            tick_cb=file_tick,
            phase_cb=phase_cb,
        ))
    return out


@app.post("/api/test")
def test_sync():
    """Test synchrone d'un ou plusieurs UPF (chemins absolus ou noms dans pseudos/)."""
    
    
    data = request.get_json(force=True, silent=True) or {}
    names = data.get("files") or data.get("names") or []
    paths = data.get("paths") or []
    directory = data.get("dir")
    run_level2 = bool(data.get("run_level2", True))
    run_level1 = bool(data.get("run_level1", True))
    run_level3 = bool(data.get("run_level3", False))
    run_level4 = bool(data.get("run_level4", False))
    auto_correct = data.get("auto_correct")
    auto_correct = None if auto_correct is None else bool(auto_correct)
    if not run_level1 and not run_level2 and not run_level3 and not run_level4:
        return jsonify({"ok": False,
                        "error": "Sélectionnez au moins un niveau de test (niveau 1, niveau 2, niveau 3 ou niveau 4)."}), 400

    resolved = []
    denied = []
    for n in names:
        rp = _resolve_test_path(n)
        if rp:
            resolved.append(str(rp))
        else:
            denied.append(n)
    for p in paths:
        rp = _resolve_test_path(p)
        if rp:
            resolved.append(str(rp))
        else:
            denied.append(str(p))
    if denied and not resolved:
        return jsonify({
            "ok": False,
            "error": "Aucun fichier UPF accessible (chemins hors racines autorisées).",
            "denied": denied,
        }), 403

    if directory:
        dirp = _resolve_directory(directory)
        if not dirp:
            return jsonify({
                "ok": False,
                "error": "Dossier de test inaccessible ou hors racines autorisées.",
            }), 403
        results = batch_test_directory(
            str(dirp),
            pw_executable=_resolve_bin(PW_BIN),
            ld1_bin=_resolve_bin(LD1_BIN),
            oncv_search_roots=level2_roots() or None,
            work_dir=str(WORK_DIR),
            run_level1=run_level1,
            run_level2=run_level2,
            run_level3=run_level3,
            run_level4=run_level4,
            quiet=True,
            auto_correct=auto_correct,
            ready_dir=str(READY_DIR),
        )
        return jsonify({"ok": True, "results": results, "count": len(results)})

    if not resolved:
        return jsonify({"ok": False, "error": "Aucun fichier à tester."}), 400

    results = _run_paths(resolved, run_level2=run_level2, run_level1=run_level1,
                         run_level3=run_level3, run_level4=run_level4,
                         auto_correct=auto_correct)
    return jsonify({"ok": True, "results": results, "count": len(results)})


test_sync.__test__ = False


@app.post("/api/test/async")
def test_async():
    """Lance un job en arrière-plan ; polling via /api/jobs/<id>."""
    data = request.get_json(force=True, silent=True) or {}
    names = data.get("files") or []
    directory = data.get("dir")
    run_level2 = bool(data.get("run_level2", True))
    run_level1 = bool(data.get("run_level1", True))
    run_level3 = bool(data.get("run_level3", False))
    run_level4 = bool(data.get("run_level4", False))
    auto_correct = data.get("auto_correct")
    auto_correct = None if auto_correct is None else bool(auto_correct)
    if not run_level1 and not run_level2 and not run_level3 and not run_level4:
        return jsonify({"ok": False,
                        "error": "Sélectionnez au moins un niveau de test (niveau 1, niveau 2, niveau 3 ou niveau 4)."}), 400
    job_id = uuid.uuid4().hex[:12]

    with _JOBS_LOCK:
        _JOBS[job_id] = {
            "id": job_id,
            "status": "running",
            "created": time.time(),
            "finished": None,
            "results": [],
            "error": None,
            "progress": "Démarrage…",
            "done": 0,
            "total": None,
            "current": None,
            "phase": None,
            "phases": PHASE_TOTAL,
            "phase_label": None,
            "directory": directory,
            "auto_correct": auto_correct,
            "run_level1": run_level1,
            "run_level2": run_level2,
            "run_level3": run_level3,
            "run_level4": run_level4,
        }
        _STATE["last_job"] = job_id

    def progress(idx, total, name):
        with _JOBS_LOCK:
            job = _JOBS.get(job_id)
            if not job:
                return
            job["done"] = idx - 1
            job["total"] = total
            job["current"] = name
            job["iteration"] = None
            job["phase"] = None
            job["phases"] = PHASE_TOTAL
            job["progress"] = _job_text(job)

    def phase(numero, total_phases, label):
        """Étape du pipeline : 1..2/3 SCF, 2..3 ghosts, 3 (ou 2) corrections."""
        with _JOBS_LOCK:
            job = _JOBS.get(job_id)
            if not job:
                return
            job["phase"] = numero
            job["phases"] = total_phases or PHASE_TOTAL
            job["phase_label"] = label or phase_label(numero)
            job["iteration"] = None
            job["progress"] = _job_text(job)

    def tick(name, iteration, elapsed):
        """Suivi en direct pendant un calcul (itérations SCF)."""
        with _JOBS_LOCK:
            job = _JOBS.get(job_id)
            if not job:
                return
            job["iteration"] = iteration
            job["elapsed_s"] = round(elapsed, 1)
            extra = f"itération SCF {iteration}" if iteration else None
            job["progress"] = _job_text(job, extra)

    def worker():
        try:
            with _JOBS_LOCK:
                if job_id in _JOBS:
                    _JOBS[job_id]["progress"] = "Tests en cours…"
            if directory:
                dirp = _resolve_directory(directory)
                if not dirp:
                    raise ValueError("Dossier inaccessible ou hors racines autorisées.")
                job_work = WORK_DIR / job_id
                job_work.mkdir(parents=True, exist_ok=True)
                results = batch_test_directory(
                    str(dirp),
                    pw_executable=_resolve_bin(PW_BIN),
                    ld1_bin=_resolve_bin(LD1_BIN),
                    oncv_search_roots=level2_roots() or None,
                    work_dir=str(job_work),
                    run_level1=run_level1,
                    run_level2=run_level2,
                    run_level3=run_level3,
                    run_level4=run_level4,
                    quiet=True,
                    progress_cb=progress,
                    auto_correct=auto_correct,
                    ready_dir=str(READY_DIR),
                    tick_cb=tick,
                    phase_cb=phase,
                )
            else:
                paths = []
                denied = []
                for n in names:
                    rp = _resolve_test_path(n)
                    if rp:
                        paths.append(str(rp))
                    else:
                        denied.append(n)
                for p in data.get("paths") or []:
                    rp = _resolve_test_path(p)
                    if rp:
                        paths.append(str(rp))
                    else:
                        denied.append(str(p))
                if not paths:
                    raise ValueError(
                        "Aucun UPF accessible."
                        + (f" Refusés : {', '.join(denied[:5])}" if denied else "")
                    )
                results = _run_paths(
                    paths,
                    run_level2=run_level2,
                    run_level1=run_level1,
                    run_level3=run_level3,
                    run_level4=run_level4,
                    job_id=job_id,
                    progress_cb=progress,
                    auto_correct=auto_correct,
                    tick_cb=tick,
                    phase_cb=phase,
                )
            with _JOBS_LOCK:
                job = _JOBS.get(job_id)
                if job is not None:
                    job["status"] = "done"
                    job["results"] = results
                    job["done"] = len(results)
                    job["total"] = len(results)
                    job["progress"] = "Terminé"
                    job["finished"] = time.time()
        except Exception as exc:
            with _JOBS_LOCK:
                job = _JOBS.get(job_id)
                if job is not None:
                    job["status"] = "error"
                    job["error"] = str(exc)
                    job["progress"] = "Erreur"
                    job["finished"] = time.time()

    threading.Thread(target=worker, daemon=True).start()
    return jsonify({"ok": True, "job_id": job_id})


test_async.__test__ = False


@app.get("/api/jobs/<job_id>")
def job_status(job_id: str):
    with _JOBS_LOCK:
        job = _JOBS.get(job_id)
    if not job:
        return jsonify({"ok": False, "error": "Job inconnu."}), 404
    return jsonify({"ok": True, **job})


@app.get("/api/jobs")
def jobs_latest():
    """Renvoie le dernier job lancé (permet de retrouver les résultats
    après un rafraîchissement de la page ou une coupure de connexion)."""
    with _JOBS_LOCK:
        last = _STATE.get("last_job")
        job = _JOBS.get(last) if last else None
        if job is None and _JOBS:
            job = max(_JOBS.values(), key=lambda j: j.get("created") or 0)
        jobs = list(_JOBS.values())
    if job is None:
        return jsonify({"ok": True, "job": None, "count": 0})
    return jsonify({"ok": True, "job": job, "count": len(jobs)})


@app.post("/api/purge")
def purge():
    """Purge l'état de l'interface.

    ``what`` : ``results`` (défaut) vide les jobs/résultats ; ``work`` supprime
    aussi les répertoires de calcul ; ``all`` fait les deux. Les livrables de
    ``ready/`` (pseudos corrigés + inputs validés) ne sont supprimés que si
    ``ready`` vaut vrai : un simple rafraîchissement ne doit pas détruire le
    résultat du travail.
    """
    data = request.get_json(force=True, silent=True) or {}
    what = (data.get("what") or "results").strip().lower()
    drop_ready = bool(data.get("ready")) or what == "ready"
    removed = {"jobs": 0, "work_files": 0, "ready_files": 0}

    with _JOBS_LOCK:
        running = [j for j in _JOBS.values() if j.get("status") == "running"]
    if running:
        return jsonify({
            "ok": False,
            "error": "Un test est en cours — annulez-le avant de purger.",
            "running": len(running),
        }), 409

    if what in ("results", "all"):
        with _JOBS_LOCK:
            removed["jobs"] = len(_JOBS)
            _JOBS.clear()
            _STATE["last_job"] = None

    def _empty(directory: Path) -> int:
        n = 0
        if not directory.is_dir():
            return 0
        for child in directory.iterdir():
            try:
                if child.is_dir():
                    shutil.rmtree(child)
                else:
                    child.unlink()
                n += 1
            except OSError:
                pass
        return n

    if what in ("work", "all", "ready"):
        removed["work_files"] = _empty(WORK_DIR)
    if drop_ready:
        removed["ready_files"] = _empty(READY_DIR)

    return jsonify({"ok": True, "what": what, "removed": removed})


@app.get("/api/ready")
def ready_list():
    """Liste les pseudos corrigés (UPF + input pw.x prêt à l'emploi)."""
    items = []
    if READY_DIR.is_dir():
        for d in sorted(READY_DIR.iterdir()):
            if not d.is_dir():
                continue
            inp = d / "scf_atome_isole.in"
            items.append({
                "name": d.name,
                "dir": str(d),
                "input": str(inp) if inp.is_file() else None,
                "download": f"/api/ready/{d.name}/scf_atome_isole.in",
            })
    return jsonify({"ok": True, "root": str(READY_DIR), "ready": items})


@app.get("/api/ready/<name>/<path:filename>")
def ready_file(name: str, filename: str):
    target = (READY_DIR / Path(name).name / Path(filename).name)
    if not target.is_file():
        return jsonify({"ok": False, "error": "Fichier prêt introuvable."}), 404
    return send_file(target, as_attachment=True)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _archive_upfs(sources: list[Path]) -> dict:
    """Copie des UPF vers l'archive, sans jamais écraser un contenu différent.

    - contenu identique déjà archivé  → ignoré ;
    - même nom, contenu différent     → écrit en ``<nom>_corrige.UPF`` ;
    - nom absent                      → copié tel quel.
    """
    VALIDES_DIR.mkdir(parents=True, exist_ok=True)
    by_name = {p.name: p for p in VALIDES_DIR.glob("*.UPF")}
    added, identical, renamed, skipped = [], 0, [], []
    for src in sources:
        src = Path(src)
        if not src.is_file():
            skipped.append(str(src))
            continue
        digest = _sha256(src)
        if src.name in by_name:
            target = by_name[src.name]
            if _sha256(target) == digest:
                identical += 1
                continue
            cand = VALIDES_DIR / f"{src.stem}_corrige.UPF"
            n = 2
            while cand.exists():
                if _sha256(cand) == digest:
                    break
                cand = VALIDES_DIR / f"{src.stem}_corrige{n}.UPF"
                n += 1
            if cand.exists():
                identical += 1
                continue
        else:
            cand = VALIDES_DIR / src.name
        shutil.copy2(src, cand)
        by_name[cand.name] = cand
        if cand.name == src.name:
            added.append(cand.name)
        else:
            renamed.append({"from": src.name, "to": cand.name})
    return {
        "root": str(VALIDES_DIR),
        "added": added,
        "renamed": renamed,
        "identical": identical,
        "skipped": skipped,
        "total": len(list(VALIDES_DIR.glob("*.UPF"))),
    }


@app.post("/api/archive")
def archive_validated():
    """Archive les pseudos testés/corrigés dans ``pseudos_testés_validés/``.

    ``source`` : ``ready`` (défaut, tous les UPF de ``ready/*/``) ou ``paths``
    (liste ``files`` de chemins absolus). Les originaux ne sont jamais touchés.
    """
    data = request.get_json(force=True, silent=True) or {}
    source = (data.get("source") or "ready").strip().lower()

    if source == "paths":
        sources = [Path(p) for p in (data.get("files") or [])]
    elif source == "ready":
        names = data.get("names") or None
        sources = []
        if READY_DIR.is_dir():
            for d in sorted(READY_DIR.iterdir()):
                if not d.is_dir() or (names and d.name not in names):
                    continue
                upfs = sorted(d.glob("*.UPF"))
                if upfs:
                    sources.append(upfs[0])
    else:
        return jsonify({"ok": False,
                        "error": f"Source inconnue : {source}."}), 400

    if not sources:
        return jsonify({"ok": False,
                        "error": "Aucun pseudo à archiver (ready/ est vide)."}), 400

    try:
        result = _archive_upfs(sources)
    except OSError as exc:
        return jsonify({"ok": False, "error": f"Archivage impossible : {exc}"}), 500
    return jsonify({"ok": True, **result})


@app.get("/api/archive")
def archive_state():
    """État de l'archive : chemin, nombre et liste des UPF archivés."""
    upfs = sorted(VALIDES_DIR.glob("*.UPF")) if VALIDES_DIR.is_dir() else []
    latest = max(upfs, key=lambda p: p.stat().st_mtime) if upfs else None
    return jsonify({
        "ok": True,
        "root": str(VALIDES_DIR),
        "count": len(upfs),
        "latest": latest.name if latest else None,
        "files": _list_upfs(VALIDES_DIR) if VALIDES_DIR.is_dir() else [],
    })


@app.get("/api/archive/file/<path:name>")
def archive_file(name: str):
    """Télécharge un UPF de l'archive (Nom sécurisé contre la traversée)."""
    target = VALIDES_DIR / Path(name).name
    if not target.is_file():
        return jsonify({"ok": False, "error": "Fichier introuvable dans l'archive."}), 404
    return send_file(target, as_attachment=True)


@app.get("/api/guide.pdf")
def guide_pdf():
    pdf = DOCS_DIR / "Guide_Methodologique_Validation_Pseudopotentiels.pdf"
    if not pdf.is_file():
        return jsonify({"ok": False, "error": "Guide PDF introuvable."}), 404
    return send_file(pdf, mimetype="application/pdf")


@app.after_request
def _no_cache_interface(resp):
    """L'interface (HTML/JS/CSS) doit toujours être servie à jour.

    Sans cela, un navigateur peut continuer à exécuter l'ancien app.js après un
    correctif — cause classique d'une interface qui semble « bloquée ».
    """
    path = request.path or ""
    if path == "/" or path.endswith((".js", ".css", ".html")):
        resp.headers["Cache-Control"] = "no-store, must-revalidate"
    return resp


@app.get("/")
def index():
    return send_from_directory(INTERFACE_DIR, "index.html")


@app.get("/<path:path>")
def static_proxy(path: str):
    target = (INTERFACE_DIR / path).resolve()
    if target.is_file() and _inside(target, [INTERFACE_DIR.resolve()]):
        return send_from_directory(INTERFACE_DIR, path)
    # Un asset manquant (.js/.css/...) doit répondre 404 : renvoyer index.html
    # masquait les fautes de frappe et cassait le débogage côté navigateur.
    if Path(path).suffix:
        return jsonify({"ok": False, "error": f"Fichier introuvable : {path}"}), 404
    return send_from_directory(INTERFACE_DIR, "index.html")


if __name__ == "__main__":
    print(f"Test Pseudos → http://{HOST}:{PORT}/")
    print(f"  pw.x  = {_resolve_bin(PW_BIN)}")
    print(f"  ld1.x = {_resolve_bin(LD1_BIN)}")
    print(f"  pseudos = {PSEUDOS_DIR}")
    print(f"  prêts   = {READY_DIR}")
    print(f"  travail = {WORK_DIR}")
    app.run(host=HOST, port=PORT, debug=False, threaded=True)

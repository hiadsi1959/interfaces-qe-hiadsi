#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PIDFILE="$HERE/logs/test_pseudos.pid"
PORT="${TEST_PSEUDOS_PORT:-5040}"

if [[ -f "$PIDFILE" ]]; then
  pid="$(cat "$PIDFILE")"
  if kill -0 "$pid" 2>/dev/null; then
    kill "$pid" 2>/dev/null || true
    sleep 0.3
    kill -9 "$pid" 2>/dev/null || true
    echo "  Arrêté (pid $pid)"
  else
    echo "  Processus déjà arrêté"
  fi
  rm -f "$PIDFILE"
else
  echo "  Pas de pidfile — tentative sur le port $PORT"
fi

if command -v fuser >/dev/null 2>&1; then
  fuser -k "${PORT}/tcp" 2>/dev/null || true
fi

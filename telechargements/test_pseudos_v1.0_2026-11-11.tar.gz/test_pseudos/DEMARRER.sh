#!/usr/bin/env bash
# Test Pseudos — démarre l'interface web
# URL : http://127.0.0.1:5040/
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

HOST="${TEST_PSEUDOS_HOST:-127.0.0.1}"
PORT="${TEST_PSEUDOS_PORT:-5040}"
URL="http://${HOST}:${PORT}/"

# Dossier ``bin`` — binaires embarqués dans le projet (interface autonome).
# Prioritaires : s'ils existent ici, l'application ne dépend plus du QE ni de
# ~/generation_pseudos ; sinon, fallback sur l'installation QE et sur le PATH.
BIN_DIR="$HERE/bin"
export QE_BIN_DIR="${QE_BIN_DIR:-$HOME/q-e-qe-7.5/bin}"
export PW_BIN="${PW_BIN:-$( [[ -x "$BIN_DIR/pw.x" ]] && echo "$BIN_DIR/pw.x" || echo "$QE_BIN_DIR/pw.x" )}"
export LD1_BIN="${LD1_BIN:-$( [[ -x "$BIN_DIR/ld1.x" ]] && echo "$BIN_DIR/ld1.x" || echo "$QE_BIN_DIR/ld1.x" )}"
export ONCVPSP_BIN="${ONCVPSP_BIN:-$( [[ -x "$BIN_DIR/oncvpsp.x" ]] && echo "$BIN_DIR/oncvpsp.x" || true )}"
export ATOMPAW_BIN="${ATOMPAW_BIN:-$( [[ -x "$BIN_DIR/atompaw" ]] && echo "$BIN_DIR/atompaw" || true )}"
export PATH="$BIN_DIR:$QE_BIN_DIR:${PATH:-}"
export ONCVPSP_OUT_ROOT="${ONCVPSP_OUT_ROOT:-$HOME/generation_pseudos/pseudos-oncvpsp}"
export PSEUDOS_DIR="${PSEUDOS_DIR:-$HERE/pseudos}"
export TEST_PSEUDOS_HOST="$HOST"
export TEST_PSEUDOS_PORT="$PORT"

mkdir -p "$HERE/logs" "$HERE/uploads" "$HERE/work" "$HERE/pseudos"

PYTHON="${TEST_PSEUDOS_PYTHON:-python3}"
if [[ -x "$HERE/.venv/bin/python" ]]; then
  PYTHON="$HERE/.venv/bin/python"
fi

if ! "$PYTHON" -c "import flask" 2>/dev/null; then
  echo "  · Installation Flask…"
  "$PYTHON" -m pip install --user -q flask || {
    echo "  ✗ pip install flask a échoué — créez un venv : python3 -m venv .venv && .venv/bin/pip install flask"
    exit 1
  }
fi

# numpy est requis par les niveaux 3 (EOS) et 4 (delta-test).
if ! "$PYTHON" -c "import numpy" 2>/dev/null; then
  echo "  · Installation numpy…"
  "$PYTHON" -m pip install --user -q numpy || {
    echo "  ✗ pip install numpy a échoué — niveaux 3 et 4 indisponibles"
  }
fi

if [[ ! -x "$PW_BIN" ]]; then
  echo "  ⚠ pw.x introuvable : $PW_BIN"
  echo "    Exportez QE_BIN_DIR=/chemin/q-e/bin"
fi

PIDFILE="$HERE/logs/test_pseudos.pid"
LOGFILE="$HERE/logs/test_pseudos.log"

if [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
  if curl -sf "$URL" >/dev/null 2>&1; then
    echo "  Test Pseudos déjà actif → $URL"
    exit 0
  fi
  "$HERE/ARRETER.sh" || true
  sleep 0.4
fi

echo ""
echo "  TEST PSEUDOS — validation UPF (pw.x + ld1 / ONCV)"
echo "  URL : $URL"
echo "  pw  : $PW_BIN"
echo "  ld1 : $LD1_BIN"
echo ""

nohup "$PYTHON" "$HERE/backend/server.py" >>"$LOGFILE" 2>&1 &
echo $! >"$PIDFILE"
sleep 0.8

if curl -sf "$URL" >/dev/null 2>&1; then
  echo "  Accueil : $URL"
  echo "  Guide   : ${URL}api/guide.pdf"
  if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$URL" >/dev/null 2>&1 || true
  elif command -v firefox >/dev/null 2>&1; then
    firefox "$URL" >/dev/null 2>&1 &
  fi
else
  echo "  ✗ Serveur ne répond pas — voir $LOGFILE"
  tail -n 20 "$LOGFILE" 2>/dev/null || true
  exit 1
fi

# Interface Test_Pseudos - Documentation

## Overview

**Test_Pseudos** is a web-based interface for validating UPF pseudopotentials for Quantum ESPRESSO. It tests pseudopotentials from all sources (ld1, APE, ATOMPAW, ONCVPSP generators, database downloads like SSSP/PseudoDojo/SG15/GBRV, and local files) through a multi-level validation pipeline with automatic corrections.

**URL/Access**: Served by backend/server.py (Flask/FastAPI style server)  
**Author**: Said Hiadsi (said.hiadsi@univ-usto.dz)  
**Language**: French interface

## Architecture

### Frontend (interface/)
- **index.html** - Main UI structure with tabs, forms, and visualization
- **app.js** - Client-side logic for file management, test execution, progress tracking, API communication
- **app.css** - Styling
- **favicon.svg** - Icon

### Backend (backend/)
- **server.py** - API server handling test execution, file browsing, results

### Engine (engine/)
Core testing logic split across multiple modules:
- **test_pseudos.py** - Main test orchestration (2131 lines)
- **crystal_tests.py** - EOS/crystal structure tests (level 3)
- **ld1_ghost.py** - Ghost detection via ld1.x
- **ghost_fix.py** - Automatic ghost correction by regenerating with ONCVPSP
- **gen_ghost.py** - Ghost generation/correction logic

## Navigation Tabs

The interface has 4 main views accessible via tabs:

1. **Accueil** (Home) - Documentation and guide
2. **test_pseudos** - Main testing interface  
3. **📂 pseudos_testés_validés** (Validated tested pseudopotentials) - Archive of validated pseudos
4. **Guide** - Methodological guide

## Testing Pipeline (4 Levels + Corrections)

### Level 1: pw.x SCF Stability (Always executed)
- **Purpose**: Check numerical stability of the pseudopotential
- **Method**: SCF calculation of an isolated atom in a cubic box (16 bohr, ecutwfc 60 Ry) using `pw.x`
- **Checks**: Convergence, NaN/exception/segfault, memory issues, explicit pw.x errors
- **Status**: SUCCESS if converged, FAILED if divergence/NaN/non-converged
- **Required**: Yes, always run

### Level 2: Logarithmic Derivatives & Ghosts
- **Purpose**: Analyze non-local projector physics and detect ghost states
- **Method**: Compare logarithmic derivatives of pseudo vs all-electron
- **Detection by generator**:
  - **ld1/Atomic**: `ld1.x` with iswitch=2, input reconstructed from UPF
  - **ONCVPSP**: Generation report `.out` file
  - **APE**: `ape_run.log` (Ghost state analysis section)
  - **ATOMPAW**: `atompaw_run.log` + `logderiv.*`
- **Status**: SUCCESS (clean), WARNING (ghost detected), SKIPPED (no generation log available)

### Level 3: Crystal EOS (Optional - slower)
- **Purpose**: Transferability test on crystal structure
- **Method**: 6 SCF calculations on reference cubic structure at a0_exp ±4.5%, Birch-Murnaghan 3rd order fit (B0' fixed at 4)
- **Structures supported**: diamond, fcc, bcc (and now extended to hcp, orthorhombic, trigonal, rhombohedral - 115 elements total)
- **Comparison**: a0 and B0 vs experimental (thresholds 3% and 20%)
- **Status**: Consultative only - does not affect verdict or archiving
- **Default**: Off for speed

### Level 4: Delta-test / Projector Quality (Optional)
- **Purpose**: Gauge cutoff convergence quality
- **Method**: Two SCF calculations at same ecutrho - one at chosen ecutwfc, other at 1.4× ecutwfc; measure ΔE (meV/atom)
- **Audit**: Compare actual PP_BETA count vs number_of_proj in header, channel distribution (s/p/d/f), positive emission energies (ghost candidates)
- **Thresholds**: SUCCESS if ΔE ≤ 0.5 meV/atom, WARNING if ≤ 3 meV/atom, FAILED if > 3 meV/atom
- **Status**: Consultative only

### Level 5: Automatic Corrections (Default on)
When tests fail and "Corrections automatiques" is checked:
1. **QE parameter corrections**: Slower mixing (mixing_beta 0.3→0.1→0.05), smearing adjustment, increased cutoffs (×1.5), larger box (×1.25), increased electron_maxstep
2. **Anti-ghost regeneration**: If ghost confirmed, regenerate using original generator input embedded in UPF, increase rc of ghost channels (×1.15→1.75), reduce qcut by 10%; only keep if ghost disappears
3. **Re-validation and archiving**: Re-run level 1, write corrected pseudo to `ready/`, can be archived to `pseudos_testés_validés/`

## File Management

### Sources
- **Generator libraries**: `GENERATION_PSEUDOS_ROOT/pseudos-{generator}/` (ld1, oncvpsp, atompaw, ape)
- **Imported/downloaded**: Via "Déposer le pseudo à testé" (file upload/dropzone) or in `pseudos/` directory
- **Auto-detection**: Generator origin detected from UPF metadata

### Operations
- **Browse**: Navigate filesystem to select files/directories
- **Test selected**: Run tests on checked files
- **Test all folder**: Run tests on entire directory
- **Purge**: Clear results/lists
- **Archive validated**: Copy validated pseudos to `pseudos_testés_validés/`

## API Endpoints (inferred from app.js)
- `GET /api/health` - Health check
- `GET /api/browse` - Browse filesystem
- `GET /api/list` - List files in directory/library
- `POST /api/test` - Start test job
- `GET /api/job/:id` - Poll job status/progress
- `POST /api/abort` - Abort running job
- `POST /api/purge` - Purge results
- `POST /api/archive` - Archive validated pseudos
- `GET /api/download/*` - Download files

## UI Features
- **Real-time progress**: Phase indicators (1/5 SCF → 5/5 corrections), progress bar, elapsed time
- **Status badges**: SUCCESS (green), WARNING (yellow/orange), FAILED (red), SKIPPED (gray)
- **Detailed results**: Expandable per-pseudo results with all test levels
- **Health indicator**: API connection status
- **Responsive design**: Modern UI with gradients, cards, SVG flow diagram

## Key Files & Directories
```
/home/hiadsi/test_pseudos/
├── interface/           # Web UI
├── backend/server.py    # API server
├── engine/             # Test logic
├── pseudos/            # Input pseudos
├── pseudos_testés_validés/ # Archived validated (118 elements added to CRYSTALS)
├── ready/              # Corrected pseudos ready for archiving
├── work/               # Temporary test workspaces
└── CRYSTALS_ELEMENTS.txt # List of 115 elements in CRYSTALS table
```

## Recent Changes (from conversation)
- Extended CRYSTALS table in `engine/crystal_tests.py` to support all elements up to Z=118
- Added support for hcp, orthorhombic, trigonal, rhombohedral structures
- Now 115 elements covered in crystal EOS tests (was 17 originally)
- Added Am (Americium) to CRYSTALS table
- All elements present in `pseudos/` have corresponding crystal structure entries

## Notes
- Tests are consultative for levels 3 and 4 - they don't block archiving
- Ghost detection is critical - WARNING on level 2 means pseudo should not be used in production without fixing
- Automatic correction attempts up to 3 times
- The interface is in French throughout

# -*- coding: utf-8 -*-
"""Niveau 3 de validation : équation d'état sur cristal de référence.
"""
from __future__ import annotations

import math
import os
import re
import shutil
import sys
from pathlib import Path

import numpy as np

try:
    from . import test_pseudos as _test_pseudos
except ImportError:
    import importlib.util
    _spec = importlib.util.spec_from_file_location(
        "test_pseudos",
        Path(__file__).with_name("test_pseudos.py"),
    )
    if _spec is None or _spec.loader is None:
        raise
    _test_pseudos = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(_test_pseudos)

RY_TO_EV = 13.605693122994
EV_PER_A3_TO_GPA = 160.2176634
BOHR_TO_ANGSTROM = 0.529177210903
RY_TO_MEV = 13605.693122994
RY_PER_A3_TO_GPA = RY_TO_EV * EV_PER_A3_TO_GPA
RY_PER_BOHR3_TO_GPA = RY_TO_EV / BOHR_TO_ANGSTROM ** 3 * EV_PER_A3_TO_GPA

CRYSTALS = {
    "si":   {"structure": "diamond", "a0": 5.431,  "b0_gpa": 98.0},
    "ge":   {"structure": "diamond", "a0": 5.658,  "b0_gpa": 77.0},
    "c":    {"structure": "diamond", "a0": 3.567,  "b0_gpa": 443.0},
    "sn":   {"structure": "diamond", "a0": 6.489,  "b0_gpa": 53.0},
    "al":   {"structure": "fcc", "a0": 4.0495, "b0_gpa": 76.0},
    "cu":   {"structure": "fcc", "a0": 3.615,  "b0_gpa": 137.0},
    "ag":   {"structure": "fcc", "a0": 4.086,  "b0_gpa": 100.0},
    "au":   {"structure": "fcc", "a0": 4.078,  "b0_gpa": 173.0},
    "pb":   {"structure": "fcc", "a0": 4.950,  "b0_gpa": 46.0},
    "pt":   {"structure": "fcc", "a0": 3.924,  "b0_gpa": 278.0},
    "w":    {"structure": "bcc", "a0": 3.165,  "b0_gpa": 310.0},
    "mo":   {"structure": "bcc", "a0": 3.147,  "b0_gpa": 267.0},
    "ta":   {"structure": "bcc", "a0": 3.306,  "b0_gpa": 200.0},
    "v":    {"structure": "bcc", "a0": 3.024,  "b0_gpa": 160.0},
    "li":   {"structure": "bcc", "a0": 3.509,  "b0_gpa": 13.4},
    "na":   {"structure": "bcc", "a0": 4.225,  "b0_gpa": 7.0},
    "k":    {"structure": "bcc", "a0": 5.282,  "b0_gpa": 3.7},
    "be":   {"structure": "hcp", "a0": 2.286, "c_over_a": 1.567, "b0_gpa": 46.0},
    "fe":   {"structure": "bcc", "a0": 2.870,  "b0_gpa": 170.0},
    "ni":   {"structure": "fcc", "a0": 3.520,  "b0_gpa": 170.0},
    "zn":   {"structure": "hcp", "a0": 2.660, "c_over_a": 1.856, "b0_gpa": 100.0},
    "cd":   {"structure": "hcp", "a0": 2.660, "c_over_a": 1.886, "b0_gpa": 40.0},
    "mg":   {"structure": "hcp", "a0": 3.209, "c_over_a": 1.623, "b0_gpa": 40.0},
    "zr":   {"structure": "hcp", "a0": 3.230, "c_over_a": 1.593, "b0_gpa": 50.0},
    "sc":   {"structure": "hcp", "a0": 3.300, "c_over_a": 1.614, "b0_gpa": 25.0},
    "y":    {"structure": "hcp", "a0": 3.630, "c_over_a": 1.566, "b0_gpa": 40.0},
    "la":   {"structure": "hcp", "a0": 3.750, "c_over_a": 1.873, "b0_gpa": 20.0},
    "ce":   {"structure": "hcp", "a0": 5.150, "c_over_a": 1.675, "b0_gpa": 20.0},
    "nd":   {"structure": "hcp", "a0": 3.630, "c_over_a": 1.867, "b0_gpa": 20.0},
    "sm":   {"structure": "hcp", "a0": 3.500, "c_over_a": 1.787, "b0_gpa": 15.0},
    "eu":   {"structure": "hcp", "a0": 4.500, "c_over_a": 1.610, "b0_gpa": 12.0},
    "gd":   {"structure": "hcp", "a0": 3.640, "c_over_a": 1.581, "b0_gpa": 35.0},
    "tb":   {"structure": "hcp", "a0": 3.480, "c_over_a": 1.635, "b0_gpa": 20.0},
    "dy":   {"structure": "hcp", "a0": 3.550, "c_over_a": 1.582, "b0_gpa": 40.0},
    "ho":   {"structure": "hcp", "a0": 3.590, "c_over_a": 1.598, "b0_gpa": 35.0},
    "er":   {"structure": "hcp", "a0": 3.560, "c_over_a": 1.591, "b0_gpa": 35.0},
    "tm":   {"structure": "hcp", "a0": 3.500, "c_over_a": 1.569, "b0_gpa": 20.0},
    "yb":   {"structure": "hcp", "a0": 3.650, "c_over_a": 1.638, "b0_gpa": 20.0},
    "lu":   {"structure": "hcp", "a0": 3.500, "c_over_a": 1.560, "b0_gpa": 30.0},
    "hf":   {"structure": "hcp", "a0": 3.190, "c_over_a": 1.584, "b0_gpa": 100.0},
    "ir":   {"structure": "fcc", "a0": 3.840,  "b0_gpa": 300.0},
    "tl":   {"structure": "fcc", "a0": 4.960,  "b0_gpa": 20.0},
    "hg":   {"structure": "rhomb", "a0": 3.000,  "b0_gpa": 20.0},
    "bi":   {"structure": "trig", "a0": 4.550, "c_over_a": 1.609, "b0_gpa": 35.0},
    "po":   {"structure": "bcc", "a0": 3.650,  "b0_gpa": 50.0},
    "rn":   {"structure": "fcc", "a0": 4.800,  "b0_gpa": 1.5},
    "fr":   {"structure": "bcc", "a0": 5.800,  "b0_gpa": 1.0},
    "ra":   {"structure": "fcc", "a0": 5.000,  "b0_gpa": 1.0},
    "ac":   {"structure": "hcp", "a0": 4.800, "c_over_a": 1.846, "b0_gpa": 20.0},
    "th":   {"structure": "fcc", "a0": 5.000,  "b0_gpa": 30.0},
    "u":    {"structure": "bcc", "a0": 2.850,  "b0_gpa": 80.0},
    "pu":   {"structure": "orth", "a0": 3.900,  "b0_gpa": 15.0},
    "am":   {"structure": "fcc", "a0": 4.600,  "b0_gpa": 15.0},
    "cm":   {"structure": "orth", "a0": 3.800,  "b0_gpa": 10.0},
    "bk":   {"structure": "orth", "a0": 3.800,  "b0_gpa": 10.0},
    "cf":   {"structure": "orth", "a0": 3.700,  "b0_gpa": 10.0},
    "es":   {"structure": "orth", "a0": 3.700,  "b0_gpa": 10.0},
    "fm":   {"structure": "orth", "a0": 3.600,  "b0_gpa": 10.0},
    "md":   {"structure": "orth", "a0": 3.600,  "b0_gpa": 10.0},
    "no":   {"structure": "hcp", "a0": 3.600, "c_over_a": 1.650, "b0_gpa": 10.0},
    "lr":   {"structure": "orth", "a0": 3.500,  "b0_gpa": 10.0},
    "co":   {"structure": "hcp", "a0": 2.507, "c_over_a": 1.623, "b0_gpa": 180.0},
    "ti":   {"structure": "hcp", "a0": 2.950, "c_over_a": 1.587, "b0_gpa": 80.0},
    "ru":   {"structure": "hcp", "a0": 2.700, "c_over_a": 1.584, "b0_gpa": 200.0},
    "nb":   {"structure": "bcc", "a0": 3.300, "b0_gpa": 220.0},
    "os":   {"structure": "hcp", "a0": 2.730, "c_over_a": 1.578, "b0_gpa": 150.0},
    "pd":   {"structure": "fcc", "a0": 3.890, "b0_gpa": 180.0},
    "cr":   {"structure": "bcc", "a0": 2.880, "b0_gpa": 160.0},
    "cs":   {"structure": "bcc", "a0": 6.300, "b0_gpa": 2.0},
    "rb":   {"structure": "bcc", "a0": 5.600, "b0_gpa": 3.0},
    "ba":   {"structure": "bcc", "a0": 5.020, "b0_gpa": 9.0},
    "ar":   {"structure": "fcc", "a0": 5.260, "b0_gpa": 3.0},
    "ne":   {"structure": "fcc", "a0": 4.210, "b0_gpa": 5.0},
    "kr":   {"structure": "fcc", "a0": 5.690, "b0_gpa": 2.5},
    "cl":   {"structure": "orth", "a0": 5.200, "b0_gpa": 4.0},
    "f":    {"structure": "orth", "a0": 5.300, "b0_gpa": 8.0},
    "br":   {"structure": "orth", "a0": 6.500, "b0_gpa": 3.0},
    "i":    {"structure": "orth", "a0": 7.200, "b0_gpa": 3.0},
    "n":    {"structure": "orth", "a0": 4.000, "b0_gpa": 15.0},
    "o":    {"structure": "orth", "a0": 5.400, "b0_gpa": 10.0},
    "p":    {"structure": "orth", "a0": 3.990, "b0_gpa": 14.0},
    "s":    {"structure": "orth", "a0": 4.500, "b0_gpa": 6.0},
    "se":   {"structure": "orth", "a0": 4.300, "b0_gpa": 8.0},
    "h":    {"structure": "hcp", "a0": 3.750, "c_over_a": 1.633, "b0_gpa": 10.0},
    "as":   {"structure": "rhom", "a0": 4.130, "b0_gpa": 10.0},
    "b":    {"structure": "rhom", "a0": 3.610, "b0_gpa": 150.0},
    "ga":   {"structure": "rhom", "a0": 4.520, "b0_gpa": 70.0},
    "sb":   {"structure": "trig", "a0": 4.300, "b0_gpa": 40.0},
    "in":   {"structure": "orth", "a0": 3.250, "b0_gpa": 50.0},
    "sr":   {"structure": "fcc", "a0": 6.080, "b0_gpa": 12.0},
    "mn":   {"structure": "bcc", "a0": 8.890, "b0_gpa": 150.0},
    "np":   {"structure": "orth", "a0": 4.000, "b0_gpa": 10.0},
    "rf":   {"structure": "hcp", "a0": 3.200, "c_over_a": 1.590, "b0_gpa": 150.0},
    "db":   {"structure": "bcc", "a0": 3.400, "b0_gpa": 200.0},
    "sg":   {"structure": "bcc", "a0": 3.500, "b0_gpa": 250.0},
    "bh":   {"structure": "hcp", "a0": 3.000, "c_over_a": 1.580, "b0_gpa": 300.0},
    "hs":   {"structure": "hcp", "a0": 2.900, "c_over_a": 1.570, "b0_gpa": 350.0},
    "mt":   {"structure": "fcc", "a0": 3.800, "b0_gpa": 400.0},
    "ds":   {"structure": "fcc", "a0": 3.900, "b0_gpa": 450.0},
    "rg":   {"structure": "bcc", "a0": 4.000, "b0_gpa": 500.0},
    "cn":   {"structure": "hcp", "a0": 3.700, "c_over_a": 1.650, "b0_gpa": 50.0},
    "nh":   {"structure": "fcc", "a0": 4.800, "b0_gpa": 20.0},
    "fl":   {"structure": "fcc", "a0": 5.000, "b0_gpa": 15.0},
    "mc":   {"structure": "bcc", "a0": 5.200, "b0_gpa": 10.0},
    "lv":   {"structure": "hcp", "a0": 4.500, "c_over_a": 1.600, "b0_gpa": 25.0},
    "ts":   {"structure": "orth", "a0": 6.000, "b0_gpa": 5.0},
    "og":   {"structure": "fcc", "a0": 6.500, "b0_gpa": 2.0},
    "tc":   {"structure": "hcp", "a0": 2.740, "c_over_a": 1.604, "b0_gpa": 200.0},
    "pm":   {"structure": "hcp", "a0": 3.650, "c_over_a": 1.656, "b0_gpa": 30.0},
    "re":   {"structure": "hcp", "a0": 2.760, "c_over_a": 1.615, "b0_gpa": 200.0},
    "at":   {"structure": "orth", "a0": 4.500, "b0_gpa": 10.0},
    "pr":   {"structure": "hcp", "a0": 3.820, "c_over_a": 1.664, "b0_gpa": 20.0},
    "pa":   {"structure": "orth", "a0": 4.200, "b0_gpa": 20.0},
    "xe":   {"structure": "fcc", "a0": 6.200, "b0_gpa": 2.0},
    "he":   {"structure": "hcp", "a0": 3.570, "c_over_a": 1.633, "b0_gpa": 0.8},
}


def _delta_thresholds():
    """Seuils ΔE du delta-test (meV/atome), configurables par variables d'env.

    ``PSEUDO_TEST_DELTA_WARN`` — au-delà : WARNING (défaut 0.5).
    ``PSEUDO_TEST_DELTA_FAIL`` — au-delà : FAILED (défaut 3.0).

    Lecture à l'appel (pas à l'import) : la valeur d'env prime si elle est
    valide, sinon retour aux défauts (une remarque est affichée sur stderr).
    """
    warn, fail = 0.5, 3.0
    for var, current in ("PSEUDO_TEST_DELTA_WARN", warn), ("PSEUDO_TEST_DELTA_FAIL", fail):
        raw = os.environ.get(var)
        if raw is None or not raw.strip():
            continue
        try:
            value = float(raw.strip().replace(",", "."))
        except ValueError:
            print(f"  [delta-test] {var}='{raw}' non numérique — défaut conservé "
                  f"({current:g} meV/atome).", file=sys.stderr)
            continue
        if value <= 0:
            print(f"  [delta-test] {var}='{raw}' doit être > 0 — défaut conservé "
                  f"({current:g} meV/atome).", file=sys.stderr)
            continue
        if var == "PSEUDO_TEST_DELTA_WARN":
            warn = value
        else:
            fail = value
    if fail <= warn:
        print(f"  [delta-test] seuils incohérents (fail {fail:g} <= warn {warn:g} "
              "meV/atome) — défauts conservés (0.5 / 3.0).", file=sys.stderr)
        warn, fail = 0.5, 3.0
    return warn, fail


# Échelles de volume : ~±4,5 % autour de la référence expérimentale.
_SCALES = (0.955, 0.973, 0.991, 1.009, 1.027, 1.045)

# Seuils consultatifs du niveau 3 (écarts au cristal expérimental).
EOS_A0_TOL_PCT = 3.0
EOS_B0_TOL_PCT = 20.0
# Éléments dont le calcul cristallin utilise un smearing (métaux / semi-métaux).
_EOS_SMEARING = {"al", "cu", "ag", "au", "pb", "pt", "w", "mo", "ta", "v",
                 "li", "na", "k", "ge", "sn",
                 # Alkali and alkaline earth metals (hcp structure)
                 "be", "mg", "zn", "cd", "sc", "y", "la", "ce", "nd",
                 "sm", "eu", "gd", "tb", "dy", "ho", "er", "tm", "yb", "lu",
                 "hf", "ac", "th", "u", "pu", "am", "cm", "bk", "cf",
                 "es", "fm", "md", "no", "lr",
                 # hcp metals
                 "co", "ti", "ru", "os",
                 # Other metals
                 "cr", "mn", "fe", "ni", "sr", "ba", "cs", "rb", "nb"}


# Volume de la maille primitive rapportée à a³ (celldm(1) = paramètre cubique) :
# ibrav=2 (fcc / diamant) → a³/4 (1 ou 2 atomes), ibrav=3 (bcc) → a³/2.
_PRIMITIVE_VOLUME = {
    "diamond": 0.25,  # a³/4 (2 atomes)
    "fcc": 0.25,      # a³/4 (1 atome)
    "bcc": 0.5,       # a³/2 (1 atome)
    "hcp": 0.1875,    # (sqrt(3)/4) · a³ · (c/a) ≈ 0.1875 · a³ avec c/a = 1.633
    "orth": 1.0,      # a³ (maille orthorhombique, a=b=c) — valeur par défaut
    "trig": 0.866,    # (sqrt(3)/2) · a³ ≈ 0.866 · a³ avec c/a = sqrt(8/3) ≈ 1.633
    "rhomb": 1.0,     # a³ (maille rhomboédrique, a=b=c, α=β=γ=60°) — valeur par défaut
}

# c/a ratio pour les structures non-cubiques
_C_OVER_A = {"hcp": 1.633, "trig": 1.633}
# Angle pour la maille rhomboédrique (en radians, valeur par défaut)
_RHOMBO_HALF_ANGLES = {"rhomb": 1.0472}  # 60° = 1.0472 rad


def _cell_volume(a_bohr: float, structure: str) -> float:
    """Volume (bohr³) de la maille primitive du cristal de référence.

    Pour les structures cubiques : V = a³ · (coef).
    Pour l'hcp : V = (sqrt(3)/4) · a³ · (c/a) avec c/a = 1.633 par défaut.
    Pour l'trigonal (hexagonal) : V = (sqrt(3)/2) · a³ · (c/a) avec c/a = 1.633.
    Pour l'orthorhombique : V = a³ (a=b=c par défaut).
    Pour le rhomboédrique : V = a³ · sqrt(1 - 3cos²α + 2cos³α) avec α = 60°.
    """
    if structure == "hcp":
        c_a = _C_OVER_A.get(structure, 1.633)
        return (math.sqrt(3.0) / 4.0) * (a_bohr ** 3) * c_a
    if structure == "trig":
        c_a = _C_OVER_A.get(structure, 1.633)
        return (math.sqrt(3.0) / 2.0) * (a_bohr ** 3) * c_a
    if structure == "rhomb":
        alpha = _RHOMBO_HALF_ANGLES.get(structure, 1.0472)
        cos_a = math.cos(alpha)
        return (a_bohr ** 3) * math.sqrt(1.0 - 3.0 * cos_a ** 2 + 2.0 * cos_a ** 3)
    return (a_bohr ** 3) * _PRIMITIVE_VOLUME[structure]


def _ibrav_and_nat(structure: str):
    if structure == "diamond":
        return 2, 2
    if structure == "fcc":
        return 2, 1
    if structure == "bcc":
        return 3, 1
    if structure == "hcp":
        return 4, 2
    if structure == "orth":
        return 8, 1
    if structure == "trig":
        return 6, 1
    if structure == "rhomb":
        return 5, 1
    raise ValueError(structure)


def _atomic_positions(structure: str, label: str = "Si") -> tuple[str, int]:
    if structure == "diamond":
        return f"  {label}  0.00 0.00 0.00\n  {label}  0.25 0.25 0.25\n", 2
    if structure == "hcp":
        return f"  {label}  0.00 0.00 0.00\n  {label}  1.00 0.00 0.50\n", 2
    if structure == "orth":
        return f"  {label}  0.00 0.00 0.00\n", 1
    if structure == "trig":
        return f"  {label}  0.00 0.00 0.00\n", 1
    if structure == "rhomb":
        return f"  {label}  0.00 0.00 0.00\n", 1
    return f"  {label}  0.00 0.00 0.00\n", 1


def _build_eos_input(upf_path: Path, scale: float, settings: dict) -> str:
    a_bohr = settings["a0_bohr"] * scale
    label = str(settings["element"]).upper()
    ibrav, _ = _ibrav_and_nat(settings["structure"])
    positions, nat = _atomic_positions(settings["structure"], label)
    dft = settings.get("input_dft")
    dft_line = f"\n  input_dft = '{dft}'" if dft else ""
    occupations = settings.get("occupations", "fixed")
    smearing_block = ""
    if occupations == "smearing":
        smearing_block = "\n  smearing = 'mv',\n  degauss = 0.02,"
    return f"""&CONTROL
  calculation = 'scf'
  restart_mode = 'from_scratch'
  pseudo_dir = '.'
  outdir = '.'
  verbosity = 'high'
  tprnfor = .true.
  etot_conv_thr = 1.0d-8
/
&SYSTEM
  ibrav = {ibrav}
  celldm(1) = {a_bohr:.6f}
  nat = {nat}
  ntyp = 1
  ecutwfc = {settings['ecutwfc']:.1f}
  ecutrho = {settings['ecutrho']:.1f}
  occupations = '{occupations}'{smearing_block}{dft_line}
/
&ELECTRONS
  conv_thr = 1.0d-8
  mixing_beta = 0.4
  electron_maxstep = 200
/
ATOMIC_SPECIES
  {label}  {max(1.0, settings.get('mass', 12.0)):.2f}  {settings['upf_name']}
ATOMIC_POSITIONS alat
{positions}K_POINTS automatic
  {settings['k_mesh']}  {settings['k_mesh']}  {settings['k_mesh']}  1 1 1
"""


def _fit_birch_murnaghan(volumes, energies, b0p=4.0):
    """Ajuste E(V) Birch-Murnaghan 3ᵉ ordre ; retourne (e0, v0, b0, résidus).

    ``b0p`` est FIXÉ (4 par défaut), ce qui rend l'équation linéaire en
    (E0, A = V0·B0) à V0 donné :

        E(V) = E0 + (9/16)·A·[(η−1)²(6−4η) + B0'·(η−1)³],  η = (V0/V)^(2/3)

    On balaie donc V0 (moindres carrés linéaires pour E0 et A) jusqu'au
    minimum de la somme des carrés des résidus, puis ``B0 = A / V0`` (Ry/bohr³).
    Aucune dérivée numérique : l'ajustement ne peut pas diverger.
    """
    v = np.asarray(volumes, dtype=float)
    e = np.asarray(energies, dtype=float)
    order = np.argsort(v)
    v, e = v[order], e[order]
    if v.size < 3 or np.any(v <= 0):
        raise ValueError("au moins 3 volumes positifs sont nécessaires")

    def _basis(v0, vx):
        eta = (v0 / vx) ** (2.0 / 3.0)
        return (9.0 / 16.0) * ((eta - 1.0) ** 2 * (6.0 - 4.0 * eta)
                               + b0p * (eta - 1.0) ** 3)

    def _solve(v0):
        x = np.column_stack([np.ones_like(v), _basis(v0, v)])
        coef = np.linalg.lstsq(x, e, rcond=None)[0]
        res = x @ coef - e
        return float(res @ res), coef

    lo, hi = 0.90 * float(v.min()), 1.10 * float(v.max())
    grid = np.linspace(lo, hi, 241)
    vals = [_solve(x)[0] for x in grid]
    i = int(np.argmin(vals))
    lo = float(grid[max(0, i - 1)])
    hi = float(grid[min(grid.size - 1, i + 1)])

    # Raffinement par section dorée (unimodal autour du minimum).
    phi = (math.sqrt(5.0) - 1.0) / 2.0
    c, d = hi - phi * (hi - lo), lo + phi * (hi - lo)
    fc, fd = _solve(c)[0], _solve(d)[0]
    for _ in range(80):
        if fc < fd:
            hi, d, fd = d, c, fc
            c = hi - phi * (hi - lo)
            fc = _solve(c)[0]
        else:
            lo, c, fc = c, d, fd
            d = lo + phi * (hi - lo)
            fd = _solve(d)[0]
    v0 = (lo + hi) / 2.0
    _, coef = _solve(v0)
    e0, a = float(coef[0]), float(coef[1])
    if not np.isfinite(e0) or not np.isfinite(a) or a <= 0:
        raise ValueError("paramètres BM3 non physiques (A = V0·B0 ≤ 0)")
    b0 = a / v0
    residuals = e0 + a * _basis(v0, v) - e
    return e0, float(v0), float(b0), np.abs(residuals).tolist()


def _attr(text: str, name: str):
    """Valeur d'un attribut UPF v2 (``name="…"``), première occurrence."""
    m = re.search(rf'{name}\s*=\s*"([^"]*)"', text, re.I)
    return m.group(1) if m else None


def _analyze_projectors(text: str):
    """Audit des projecteurs non-locaux du UPF (v2 XML ``PP_BETA``).

    Retourne ``{"parsed": True, "total", "declared", "by_channel",
    "positive", "local"}`` ou ``{"parsed": False}`` si le format n'est
    pas analysable (UPF v1 card, bloc manquant…).
    """
    tags = re.findall(r"<PP_BETA\.\d+[^>]*>", text, re.I)
    if not tags:
        return {"parsed": False}

    def _num(raw):
        if raw is None:
            return None
        try:
            return float(raw.replace("D", "E").replace("d", "e"))
        except ValueError:
            return None

    by_channel: dict[str, int] = {}
    positive = []
    _ANG = {"0": "s", "1": "p", "2": "d", "3": "f"}
    for tag in tags:
        label = (_attr(tag, "lower_label") or _attr(tag, "label") or "").strip()
        ang = _attr(tag, "angular_momentum")
        if ang is not None and str(ang).strip() in _ANG:
            channel = _ANG[str(ang).strip()]
        elif label[-1:].lower() in ("s", "p", "d", "f"):
            channel = label[-1].lower()
        else:
            channel = "?"
        by_channel[channel] = by_channel.get(channel, 0) + 1
        e_em = _num(_attr(tag, "emission_energy"))
        if e_em is not None and e_em > 0.0:
            positive.append({"label": label or None, "energy_ha": e_em})

    declared = None
    raw_decl = _attr(text, "number_of_proj")
    if raw_decl:
        try:
            declared = int(raw_decl.split()[0])
        except (ValueError, IndexError):
            declared = None

    return {
        "parsed": True,
        "total": len(tags),
        "declared": declared,
        "by_channel": by_channel,
        "positive": positive,
        "local": bool(re.search(r"<PP_LOCAL[.\s>]", text, re.I)),
    }


def _resolve_executable(pw):
    """Chemin absolu de pw.x (le cwd change pour chaque point EOS)."""
    if not pw:
        return None
    p = Path(str(pw)).expanduser()
    if p.is_file():
        return str(p.resolve())
    which = shutil.which(str(pw))
    return which or str(p)


def _eos_settings(element, upf, ecutwfc, ecutrho, input_dft):
    """Paramètres d'un point EOS pour l'élément et le pseudo donnés."""
    crystal = CRYSTALS[element]
    return {
        "structure": crystal["structure"],
        # a0 expérimental converti en bohr : celldm(1) de la maille cubique.
        "a0_bohr": crystal["a0"] / BOHR_TO_ANGSTROM,
        "element": element,
        "upf_name": Path(upf).name,
        "ecutwfc": float(ecutwfc),
        "ecutrho": float(ecutrho),
        "input_dft": input_dft,
        "occupations": "smearing" if element in _EOS_SMEARING else "fixed",
        "k_mesh": max(1, int(os.environ.get("PSEUDO_TEST_EOS_K", "14"))),
        "mass": 12.0,
    }


def crystal_eos_test(upf, pw_executable=None, work_dir=None, timeout_per_point=None,
                     ecutwfc=None, ecutrho=None, element=None, input_dft=None):
    """Niveau 3 : équation d'état Birch-Murnaghan sur cristal de référence.

    Pour l'élément du pseudo (table ``CRYSTALS`` : diamant, fcc, bcc), six SCF
    ``pw.x`` à volume croissant (échelles ``_SCALES``, ~±4,5 % autour de
    ``a0`` expérimental), ajustement BM3 (B0' = 4), puis comparaison de
    ``a0`` et ``B0`` aux valeurs expérimentales (seuils 3 % / 20 %).

    Résultat **consultatif** : ``status`` ∈ SUCCESS / WARNING / FAILED / SKIPPED,
    il n'influe ni sur le verdict des niveaux 1–2 ni sur l'archivage. Le bloc
    renvoyé alimente directement l'UI (``fit``, ``ref``, ``deviations``).

    ``timeout_per_point`` borne chaque SCF (défaut ``PSEUDO_TEST_EOS_TIMEOUT``
    ou 420 s). Le nombre de points k est réglable via ``PSEUDO_TEST_EOS_K``
    (défaut 14, maille cubique conventionnelle).
    """
    analyze_scf_output = _test_pseudos.analyze_scf_output
    run_pw_x = _test_pseudos.run_pw_x

    upf = Path(upf)
    if not upf.is_file():
        return {
            "status": "ERROR", "code": "EOS_READ",
            "cause": f"Fichier UPF introuvable : {upf}.", "solution": None,
            "structure": None,
        }

    el = (element or "").strip().lower()
    if el not in CRYSTALS:
        try:
            text = upf.read_text(errors="ignore")
        except OSError:
            text = ""
        el = ((_attr(text, "element") or "").strip().lower()
              or re.split(r"[_.\- ]", upf.stem)[0].lower())
    if el not in CRYSTALS:
        return {
            "status": "SKIPPED", "code": "EOS_UNSUPPORTED",
            "cause": (f"Aucune structure cristalline de référence pour "
                      f"« {el or upf.stem} » : le niveau 3 ne couvre que "
                      f"{', '.join(sorted(CRYSTALS))}."),
            "solution": "Le test reste consultatif : niveaux 1, 2 et 4 inchangés.",
            "structure": None,
        }

    work = Path(work_dir) / "_eos" if work_dir else Path("_eos")
    work.mkdir(parents=True, exist_ok=True)
    try:
        shutil.copy2(upf, work / upf.name)
    except OSError as exc:
        return {
            "status": "ERROR", "code": "EOS_WORKDIR",
            "cause": f"Écriture du répertoire EOS impossible : {exc}.",
            "solution": None, "structure": None,
        }

    wfc = float(ecutwfc or 60.0)
    rho = float(ecutrho) if ecutrho else 4.0 * wfc
    settings = _eos_settings(el, upf, wfc, rho, input_dft)
    pw = _resolve_executable(pw_executable)
    timeout = float(timeout_per_point
                    or os.environ.get("PSEUDO_TEST_EOS_TIMEOUT") or 420.0)
    nat = 2 if settings["structure"] == "diamond" else 1

    points = []
    volumes, energies = [], []
    for scale in _SCALES:
        a_bohr = settings["a0_bohr"] * scale
        a_ang = a_bohr * BOHR_TO_ANGSTROM
        inp = work / f"eos_{scale:.3f}.pw.in"
        out = work / f"eos_{scale:.3f}.pwo"
        try:
            inp.write_text(_build_eos_input(upf, scale, settings), encoding="utf-8")
        except OSError as exc:
            return {
                "status": "ERROR", "code": "EOS_WORKDIR",
                "cause": f"Écriture de l'input EOS impossible : {exc}.",
                "solution": None, "structure": settings["structure"],
            }
        rc, _ = run_pw_x(str(inp), str(out), timeout=timeout, pw_executable=pw)
        point = analyze_scf_output(str(out))
        energy = point.get("energy")
        points.append({
            "scale": scale,
            "a_ang": round(a_ang, 4),
            "energy_ry": energy,
            "status": point.get("status"),
            "iterations": (point.get("details") or {}).get("iterations"),
        })
        if energy is None:
            return {
                "status": "FAILED", "code": "EOS_SCF_FAILED",
                "cause": (f"SCF pw.x en échec au point a = {a_ang:.3f} Å "
                          f"(×{scale:.3f}) : "
                          f"{point.get('cause') or 'sortie pw.x inexploitable'}."),
                "solution": ("Valider d'abord le niveau 1 (même binaire pw.x), "
                             "ou augmenter le timeout EOS."),
                "structure": settings["structure"], "points": points,
                "ref": {"a0": CRYSTALS[el]["a0"], "b0_gpa": CRYSTALS[el]["b0_gpa"]},
                "ecutwfc": wfc, "ecutrho": rho, "k_mesh": settings["k_mesh"],
            }
        volumes.append(_cell_volume(a_bohr, settings["structure"]))
        energies.append(float(energy))

    try:
        e0, v0, b0, residuals = _fit_birch_murnaghan(volumes, energies)
    except Exception as exc:  # ajustement instable / données dégénérées
        return {
            "status": "ERROR", "code": "EOS_FIT",
            "cause": f"Ajustement Birch-Murnaghan impossible : {exc}.",
            "solution": "Vérifier les énergies EOS (points trop bruités ou non convergés).",
            "structure": settings["structure"], "points": points,
            "ecutwfc": wfc, "ecutrho": rho, "k_mesh": settings["k_mesh"],
        }
    if not all(math.isfinite(v) for v in (e0, v0, b0)) or v0 <= 0 or b0 <= 0:
        return {
            "status": "FAILED", "code": "EOS_FIT",
            "cause": ("Ajustement Birch-Murnaghan non physique "
                      f"(V0 = {v0:g} bohr³, B0 = {b0:g} Ry/bohr³)."),
            "solution": "Vérifier que les 6 SCF ont convergé (conv_thr 1e-8).",
            "structure": settings["structure"], "points": points,
            "ecutwfc": wfc, "ecutrho": rho, "k_mesh": settings["k_mesh"],
        }

    a0_eq = ((v0 / _PRIMITIVE_VOLUME[settings["structure"]]) ** (1.0 / 3.0)
             * BOHR_TO_ANGSTROM)
    b0_gpa = b0 * RY_PER_BOHR3_TO_GPA
    max_res = max(residuals or [0.0]) * RY_TO_MEV / nat
    ref = CRYSTALS[el]
    dev_a0 = abs(a0_eq - ref["a0"]) / ref["a0"] * 100.0
    dev_b0 = abs(b0_gpa - ref["b0_gpa"]) / ref["b0_gpa"] * 100.0

    a0_ok = dev_a0 <= EOS_A0_TOL_PCT
    b0_ok = dev_b0 <= EOS_B0_TOL_PCT
    if a0_ok and b0_ok:
        status, code = "SUCCESS", "EOS_OK"
        cause = (f"a0 = {a0_eq:.4f} Å (réf. {ref['a0']} Å, {dev_a0:.2f} %) et "
                 f"B0 = {b0_gpa:.1f} GPa (réf. {ref['b0_gpa']} GPa, "
                 f"{dev_b0:.1f} %) : cristal de référence reproduit.")
        solution = None
    else:
        status, code = "WARNING", "EOS_DEVIATION"
        cause = (f"Écart au cristal expérimental : a0 = {a0_eq:.4f} Å "
                 f"(réf. {ref['a0']} Å, {dev_a0:.2f} %, seuil "
                 f"{EOS_A0_TOL_PCT:g} %), B0 = {b0_gpa:.1f} GPa "
                 f"(réf. {ref['b0_gpa']} GPa, {dev_b0:.1f} %, seuil "
                 f"{EOS_B0_TOL_PCT:g} %).")
        solution = ("Transferabilité cristalline limite : vérifier la convergence "
                    "ecutwfc/ecutrho et la grille k, sinon le pseudo reste "
                    "utilisable (test consultatif).")

    return {
        "status": status,
        "code": code,
        "cause": cause,
        "solution": solution,
        "structure": settings["structure"],
        "fit": {
            "energy_eq_ry": round(e0, 8),
            "a0_eq": round(a0_eq, 4),
            "b0_gpa": round(b0_gpa, 1),
            "b0_prime": 4.0,
            "max_residual_meV_per_atom": round(max_res, 3),
        },
        "ref": {"a0": ref["a0"], "b0_gpa": ref["b0_gpa"]},
        "deviations": {
            "a0_pct": round(dev_a0, 2),
            "b0_pct": round(dev_b0, 1),
            "tolerances_pct": {"a0": EOS_A0_TOL_PCT, "b0": EOS_B0_TOL_PCT},
        },
        "points": points,
        "ecutwfc": wfc, "ecutrho": rho,
        "k_mesh": settings["k_mesh"],
        "nat": nat,
    }


def delta_test(upf, pw_executable=None, work_dir=None, timeout=None,
                    ecutwfc=None, ecutrho=None, element=None, input_dft=None,
                    status_rules=None):
    """Niveau 4 : jauge delta — écart d'énergie à ``ecutrho`` fixé + audit projecteurs.

    Protocole exécutable avec ``pw.x`` seul :
    1. SCF de l'atome isolé à (ecutwfc, ecutrho) — énergie E_test.
    2. Même SCF recalculé à un ecutwfc de référence élargi (× 1.4), MÊME
       ``ecutrho`` — énergie E_ref. ΔE = |E_ref − E_test| en meV/atome :
       mesure de la transfertabilité interne du pseudo à la densité de
       charge imposée (ecutrho invariant).
    3. Audit des projecteurs du bloc ``PP_NONLOCAL`` : nombre de PP_BETA
       réellement présents vs ``number_of_proj`` du header, répartition
       par canal l (s/p/d/f) et détection d'énergies d'émission positives
       (candidats ghost — le niveau 2 tranche).

    Seuils ΔE (``status_rules`` ou variables d'env ``PSEUDO_TEST_DELTA_WARN`` /
    ``PSEUDO_TEST_DELTA_FAIL``, défauts 0.5 / 3.0 meV/atome) : SUCCESS /
    WARNING / FAILED. Bloc ``level4`` du résultat, consultatif :
    il n'influe ni sur le verdict ni sur ``ready``.

    NOTE : le Delta-gauge officiel (SSSP/PseudoDojo) compare des courbes
    E(V) à des références tout-électron (WIEN2k / Exciting) non embarquées ;
    sans elles, cette jauge quantifie la convergence de jauge interne du
    pseudopotentiel, le complément physique étant assuré par le niveau 3
    (EOS : a0 / B0 vs expérimental).
    """
    make_params = _test_pseudos.make_params
    render_pw_input = _test_pseudos.render_pw_input
    run_pw_x = _test_pseudos.run_pw_x
    analyze_scf_output = _test_pseudos.analyze_scf_output

    upf = Path(upf)
    if work_dir:
        work = Path(work_dir) / "_delta"
    else:
        work = Path("_delta")
    work.mkdir(parents=True, exist_ok=True)

    el = (element or re.split(r"[_\-. ]", upf.stem)[0]).lower()

    # Audit des projecteurs : aucun coût de calcul.
    try:
        text = upf.read_text(encoding="utf-8", errors="ignore")
    except OSError as exc:
        return {
            "status": "ERROR", "code": "DELTA_READ",
            "cause": f"Lecture du UPF impossible : {exc}", "solution": None,
        }
    proj = _analyze_projectors(text)

    # Type réel du pseudo (lu dans le UPF, pas deviné du nom de fichier) :
    # il fixe le ratio ecutrho/ecutwfc quand l'appelant n'impose pas ecutrho.
    try:
        pseudo_type_hint = _test_pseudos.detect_pseudo_type(text)
        recommended_ecutrho = _test_pseudos.recommended_ecutrho
    except Exception:
        pseudo_type_hint = "NC"
        recommended_ecutrho = lambda _t, w: 4.0 * w  # noqa: E731

    ecutwfc = float(ecutwfc or 40.0)
    if not ecutrho:
        ecutrho = recommended_ecutrho(pseudo_type_hint, ecutwfc)
    ecutrho = float(ecutrho)
    ecutwfc_ref = max(ecutwfc * 1.4, ecutwfc + 20.0)
    timeout = float(timeout or 420.0)

    params = make_params(pseudo_type_hint, {
        "input_dft": input_dft,
        "ecutwfc": ecutwfc,
        "ecutrho": ecutrho,
    })

    # pseudo_dir = '.' : le UPF doit être copié dans le répertoire de travail.
    shutil.copy2(upf, work / upf.stem)

    def _scf(ecut):
        p = dict(params, ecutwfc=float(ecut))
        inp = (work / f"delta_{ecut:.1f}.pw.in").resolve()
        out = (work / f"delta_{ecut:.1f}.pwo").resolve()
        inp.write_text(render_pw_input(upf.stem, p), encoding="utf-8")
        rc, _ = run_pw_x(str(inp), str(out), pseudo_dest=None, timeout=timeout,
                         pw_executable=pw_executable)
        return rc, analyze_scf_output(str(out))

    rc_test, l_test = _scf(ecutwfc)
    if rc_test != 0 or l_test.get("energy") is None:
        return {
            "status": "FAILED", "code": "DELTA_SCF_FAILED",
            "cause": (f"SCF delta-test à ecutwfc={ecutwfc:.1f} Ry en échec : "
                      f"{l_test.get('cause') or 'sortie pw.x inexploitable'}."),
            "solution": "Valider le niveau 1 (même calcul) avant le delta-test.",
            "structure": "jauge cutoff",
            "delta": {},
            "projectors": proj,
            "ecutwfc": ecutwfc, "ecutwfc_ref": ecutwfc_ref, "ecutrho": ecutrho,
        }
    e_test = float(l_test["energy"])

    rc_ref, l_ref = _scf(ecutwfc_ref)
    if rc_ref != 0 or l_ref.get("energy") is None:
        return {
            "status": "WARNING", "code": "DELTA_REF_FAILED",
            "cause": (f"SCF de référence (ecutwfc={ecutwfc_ref:.1f} Ry, ecutrho "
                      f"{ecutrho:.1f} Ry fixé) a échoué : "
                      f"{l_ref.get('cause') or 'sortie pw.x inexploitable'}."),
            "solution": "Augmenter le timeout ou ecutrho de référence.",
            "structure": "jauge cutoff",
            "delta": {"energy_eq": round(e_test, 8), "n_proj_test": proj.get("total"),
                      "n_proj_ref": proj.get("declared")},
            "projectors": proj,
            "ecutwfc": ecutwfc, "ecutwfc_ref": ecutwfc_ref, "ecutrho": ecutrho,
        }
    e_ref = float(l_ref["energy"])

    de_mev = abs(e_ref - e_test) * RY_TO_MEV
    pct = abs(e_ref - e_test) / max(abs(e_ref), 1e-12) * 100.0
    thr_warn, thr_fail = status_rules if status_rules is not None else _delta_thresholds()

    # Incohérence projecteurs (header vs bloc PP_NONLOCAL réel).
    proj_mismatch = bool(proj.get("parsed") and proj.get("declared")
                         and proj["total"] != proj["declared"])
    if proj_mismatch:
        status, code = "WARNING", "DELTA_PROJ_MISMATCH"
        cause = (f"ΔE {de_mev:.3f} meV/atome en jauge OK, mais incohérence "
                 f"projecteurs : {proj['total']} PP_BETA présents pour "
                 f"{proj['declared']} annoncés dans le header.")
        solution = "Vérifier le bloc PP_NONLOCAL ou régénérer le pseudo."
    elif de_mev <= thr_warn:
        status, code = "SUCCESS", "DELTA_OK"
        cause = (f"ΔE = {de_mev:.3f} meV/atome entre ecutwfc {ecutwfc:.1f} Ry et "
                 f"{ecutwfc_ref:.1f} Ry (ecutrho {ecutrho:.1f} Ry identique).")
        solution = None
    elif de_mev <= thr_fail:
        status, code = "WARNING", "DELTA_SOFT"
        cause = (f"ΔE = {de_mev:.3f} meV/atome au-dessus du seuil "
                 f"{thr_warn:g} meV/atome : convergence limite à "
                 f"ecutrho {ecutrho:.1f} Ry.")
        solution = "Augmenter ecutwfc (ou ecutrho si US/PAW) de ~30 %."
    else:
        status, code = "FAILED", "DELTA_DRIFT"
        cause = (f"ΔE = {de_mev:.3f} meV/atome : le pseudo n'est PAS convergé "
                 f"à ecutrho {ecutrho:.1f} Ry (seuil {thr_fail:g} meV/atome).")
        solution = "Augmenter ecutrho (US/PAW) ou ecutwfc puis revalider."

    return {
        "status": status,
        "code": code,
        "cause": cause,
        "solution": solution,
        "structure": "jauge cutoff",
        "delta": {
            "energy_eq": round(e_test, 8),
            "ref_energy": round(e_ref, 8),
            "delta_meV_per_atom": round(de_mev, 3),
            "pct_diff": round(pct, 4),
            "n_proj_test": proj.get("total"),
            "n_proj_ref": proj.get("declared"),
        },
        "ecutwfc": ecutwfc,
        "ecutwfc_ref": ecutwfc_ref,
        "ecutrho": ecutrho,
        "thresholds_meV": {"warning": thr_warn, "failed": thr_fail},
        "projectors": proj,
    }

"""Niveau 2 « ld1.x » — exécution automatique du test de ghost states.

Ce module reproduit, sans intervention manuelle, ce que le guide demande :

    ld1.x (iswitch=2)  ->  dérivées logarithmiques + test Bessel

le tout directement sur le ``.UPF`` fourni, puis interprète la sortie.

Stratégie
---------
1. On extrait du UPF tout ce qu'il faut pour reconstruire l'input de ``ld1.x``
   (Z, caractère relativiste, fonctionnelle, configuration électronique de
   référence et configuration de valence). Les UPF modernes embarquent leur
   input d'origine dans ``<PP_INPUTFILE>`` — c'est la source la plus fiable.
2. On lance ``ld1.x`` deux fois, avec deux tailles de boîte différentes
   (test Bessel ``ecutmin/ecutmax/decut``).
3. Un **état lié réel** (état de valence du pseudo, ou ghost) ne dépend pas de
   la boîte ; un **état de continuum discrétisé** (artefact de boîte) s'en
   dépend fortement. On classe donc chaque état :
     - stable entre les deux boîtes  -> état lié ;
     - instable                      -> état de boîte, sans intérêt.
4. Un état lié qui ne correspond à **aucune** valeur propre tout-électron du
   même canal ``l`` est un **ghost**.

Limites du code ``ld1.x`` lui-même (vérifiées, pas supposées) :
  * ``Z <= 103`` (au-delà : « wrong nuclear charge ») ;
  * la maille radiale du UPF doit être celle produite par ``atomic``
    (les UPF ONCVPSP / ATOMPAW sont rejetés : « mesh not supported »).
Ces cas sont rapportés comme tels au lieu de produire un verdict douteux.
"""

from __future__ import annotations

import re
import shutil
import subprocess
import tempfile
from pathlib import Path

# --------------------------------------------------------------------------
# Table périodique (symbole -> Z)
# --------------------------------------------------------------------------
_SYMBOLS = (
    "H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co "
    "Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb "
    "Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re "
    "Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es "
    "Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og"
).split()

SYMBOL_TO_Z = {s: i + 1 for i, s in enumerate(_SYMBOLS)}

# Limite dure du code `atomic` / `ld1.x` (vérifiée sur QE 7.5).
LD1_MAX_Z = 103

# Remplissage de type aufbau : (n, l, capacité) — sert de repli quand le UPF
# ne fournit pas sa configuration.
_AUFBAU = (
    (1, 0, 2), (2, 0, 2), (2, 1, 6), (3, 0, 2), (3, 1, 6), (4, 0, 2),
    (3, 2, 10), (4, 1, 6), (5, 0, 2), (4, 2, 10), (5, 1, 6), (6, 0, 2),
    (4, 3, 14), (5, 2, 10), (6, 1, 6), (7, 0, 2), (5, 3, 14), (6, 2, 10),
    (7, 1, 6), (6, 3, 14), (7, 2, 10),
)
_L_LETTER = "spdfgh"

# Tolérance (Ry) en dessous de laquelle deux énergies sont considérées égales.
_TOL_MATCH = 0.02      # appariement avec la référence tout-électron
_TOL_BOX = 0.02        # invariance vis-à-vis de la taille de boîte

# Boîtes essayées, de la plus grande à la plus petite.
_BOX_CANDIDATES = (28.0, 20.0, 14.0, 10.0, 7.0, 5.0)

# Rapport entre les deux boîtes comparées (28 -> ~9.8 a.u.).
_BOX_CONTRAST = 0.35

_ECUTMIN = 40.0
_ECUTMAX = 120.0


def _aufbau_config(z: int) -> str:
    """Configuration complète neutre (notation explicite ``1s2 2s2 ...``)."""
    out, left = [], z
    for n, l, cap in _AUFBAU:
        if left <= 0:
            break
        f = min(left, cap)
        left -= f
        if f > 0:
            out.append(f"{n}{_L_LETTER[l]}{f}")
    return " ".join(out)


def shell_str(n: int, l: int, occ: float) -> str:
    occ_txt = f"{occ:g}" if float(occ) != int(occ) else str(int(occ))
    return f"{n}{_L_LETTER[l]}{occ_txt}"


# --------------------------------------------------------------------------
# Lecture du UPF
# --------------------------------------------------------------------------
def _header_attrs(text: str) -> dict:
    attrs = {}
    for key in ("element", "z_valence", "relativistic", "pseudo_type",
                "is_paw", "is_ultrasoft", "functional", "mesh_size",
                "l_max", "has_so"):
        m = re.search(r'\b' + key + r'="([^"]*)"', text)
        if m:
            attrs[key] = m.group(1).strip()
    return attrs


def _rel_code(value: str) -> int:
    v = (value or "").strip().lower()
    if v.startswith("full"):
        return 2
    if v.startswith("scalar"):
        return 1
    return 0


def _dft_name(header_functional: str, input_dft: str | None) -> str:
    if input_dft:
        d = input_dft.strip().strip("'").strip('"').upper()
        if d in ("PBE", "LDA", "PZ", "PBESOL", "BLYP", "BP", "PW91", "TPSS", "SCAN"):
            return d
    f = (header_functional or "").upper()
    if "PBESOL" in f:
        return "PBEsol"
    if "PBE" in f or "PBX" in f:
        return "PBE"
    if "SLA" in f or "PZ" in f or "LDA" in f or "PW" in f:
        return "LDA"
    return "PBE"


def _parse_atomic_input(text: str) -> dict:
    """Bloc ``<PP_INPUTFILE>`` d'un UPF produit par ``atomic`` (DAL Corso).

    On y trouve l'input de génération complet : ``zed``, ``rel``, ``config``
    et la liste des états de valence avec leurs occupations.
    """
    out = {}
    m = re.search(r"<PP_INPUTFILE>(.*?)</PP_INPUTFILE>", text, re.S)
    if not m:
        return out
    body = m.group(1)

    mz = re.search(r"\bzed\s*=\s*([-+]?\d+(?:\.\d*)?)", body, re.I)
    if mz:
        out["zed"] = float(mz.group(1))
    mr = re.search(r"(?<!_)\brel\s*=\s*(\d+)", body, re.I)
    if mr:
        out["rel"] = int(mr.group(1))
    mc = re.search(r"\bconfig\s*=\s*'([^']*)'", body, re.I) or \
         re.search(r'\bconfig\s*=\s*"([^"]*)"', body, re.I)
    if mc:
        out["config"] = " ".join(mc.group(1).split())
    md = re.search(r"\bdft\s*=\s*'([^']*)'", body, re.I)
    if md:
        out["dft"] = md.group(1)

    # Cartes de valence : ``3S  1  0  2.00  0.00  2.60  2.60 [jj]``
    # colonnes = label, (index), l, occupation, énergie, rc, rcus, et parfois
    # ``jj`` ; le nombre quantique principal vient du label (« 3S » -> n = 3).
    # Le nombre de colonnes finales varie selon la version de ``atomic``
    # (2 à 4 flottants), on ne l'impose donc pas.
    states = re.findall(
        r"^\s*(\d+)[A-Za-z]{1,2}\s+\d+\s+(\d+)\s+([-+]?\d+(?:\.\d+)?)"
        r"(?:\s+[-+]?\d+(?:\.\d+)?){2,4}\s*$",
        body, re.M)
    if states:
        # 1) Dédoublonner : les PAW listent deux projecteurs par canal
        #    (« 3D 7.00 » puis « 3D 0.00 »), ce qui ferait échouer ld1.x
        #    (« wavefunction 3D found too many times »).
        seen, uniq = set(), []
        for n, l, occ in states:
            key = (int(n), int(l))
            if key in seen:
                continue
            seen.add(key)
            uniq.append((int(n), int(l), float(occ)))
        # 2) ``configts`` **écrase** les occupations de ``config`` pour les
        #    états qu'il cite : n'y mettre que les états réellement occupés.
        #    Sinon citer « 4p0 » (carte de génération de Ru.pbe-us) remettrait
        #    les 4p6 du cœur à zéro — ld1.x construirait alors un atome à 38
        #    électrons au lieu de 44.
        occupied = [s for s in uniq if s[2] > 0.0]
        out["valence"] = " ".join(
            shell_str(n, l, occ) for n, l, occ in (occupied or uniq))
    return out


def _parse_oncvpsp_input(text: str) -> dict:
    """Bloc ``<PP_INPUTFILE>`` d'un UPF ONCVPSP (D. R. Hamann)."""
    out = {}
    m = re.search(r"<PP_INPUTFILE>(.*?)</PP_INPUTFILE>", text, re.S)
    if not m:
        return out
    body = m.group(1).splitlines()

    zed = nc_plus_nv = None
    for i, line in enumerate(body):
        if re.match(r"^\s*#", line):
            continue
        # ``Eu 63.00   10    4    4   both`` (parfois collé : ``ts117.00``)
        m2 = re.match(
            r"^\s*([A-Za-z]{1,2})\s*([\d.]+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\S+)",
            line)
        if m2:
            zed = float(m2.group(2))
            nc_plus_nv = int(m2.group(3)) + int(m2.group(4))
            shells, seen = [], 0
            for ln in body[i + 1:]:
                if re.match(r"^\s*#", ln) or not ln.strip():
                    continue
                m3 = re.match(r"^\s*(\d+)\s+(\d+)\s+([-+]?\d+(?:\.\d+)?)", ln)
                if not m3:
                    break
                shells.append((int(m3.group(1)), int(m3.group(2)),
                               float(m3.group(3))))
                seen += 1
                if seen >= nc_plus_nv:
                    break
            if shells:
                out["zed"] = zed
                out["config"] = " ".join(shell_str(*s) for s in shells)
                nv = int(m2.group(4))
                out["valence"] = " ".join(
                    shell_str(*s) for s in shells[-nv:])
            break
    return out


def read_upf(path) -> dict:
    """Informations nécessaires à ``ld1.x``, extraites du UPF."""
    path = Path(path)
    text = path.read_text(errors="ignore")
    hdr = _header_attrs(text)

    info = {
        "element": (hdr.get("element") or "").strip(),
        "z_valence": None,
        "rel": _rel_code(hdr.get("relativistic", "")),
        "pseudo_type": (hdr.get("pseudo_type") or "").strip().upper(),
        "is_paw": (hdr.get("is_paw") or "").strip().upper() in ("T", "TRUE"),
        "functional": hdr.get("functional", ""),
        "mesh_size": hdr.get("mesh_size"),
        "config": None,
        "valence": None,
        "dft": None,
        "zed": None,
        "source": None,
    }
    try:
        info["z_valence"] = float(hdr.get("z_valence", "nan"))
    except ValueError:
        pass

    # 1) input d'origine embarqué dans le UPF (le plus fiable)
    atomic = _parse_atomic_input(text)
    oncv = _parse_oncvpsp_input(text)
    for candidate, name in ((atomic, "PP_INPUTFILE (atomic)"),
                            (oncv, "PP_INPUTFILE (ONCVPSP)")):
        if candidate.get("config"):
            info.update({k: v for k, v in candidate.items() if v is not None})
            info["source"] = name
            break

    # 2) Z : déduit du symbole si l'input ne le donnait pas
    el = info["element"].capitalize()
    if info["zed"] is None and el in SYMBOL_TO_Z:
        info["zed"] = float(SYMBOL_TO_Z[el])

    # 3) repli : configuration aufbau si le UPF n'en fournit aucune
    if not info["config"] and info["zed"]:
        info["config"] = _aufbau_config(int(info["zed"]))
        info["source"] = info["source"] or "aufbau (repli)"
        if info["z_valence"]:
            nv = int(round(info["z_valence"]))
            info["valence"] = " ".join(
                info["config"].split()[-nv:] if nv else [])
    if not info["valence"] and info["config"]:
        info["valence"] = info["config"]
    if info["dft"] is None:
        info["dft"] = _dft_name(info["functional"], None)
    return info


# --------------------------------------------------------------------------
# Exécution de ld1.x
# --------------------------------------------------------------------------
def _build_input(info: dict, upf_name: str, rm: float) -> str:
    return (
        " &input\n"
        f"   title='{info['element'] or 'pseudo'}',\n"
        f"   zed={info['zed']:.1f}, rel={info['rel']}, beta=0.5,\n"
        f"   config='{info['config']}',\n"
        f"   iswitch=2, dft='{info['dft']}',\n"
        " /\n"
        " &test\n"
        f"   file_pseudo='{upf_name}',\n"
        "   nconf=1,\n"
        f"   configts(1)='{info['valence']}',\n"
        f"   ecutmin={_ECUTMIN}, ecutmax={_ECUTMAX}, decut=80.0, rm={rm},\n"
        " /\n"
    )


def _run_once(ld1_bin: str, upf: Path, info: dict, rm: float, timeout: float,
              workdir: Path):
    dest = workdir / upf.name
    if not dest.exists():
        shutil.copy(upf, dest)
    inp = _build_input(info, upf.name, rm)
    (workdir / f"ld1_rm{rm:g}.in").write_text(inp)
    try:
        proc = subprocess.run(
            [ld1_bin], input=inp, capture_output=True, text=True,
            timeout=timeout, cwd=str(workdir))
        out = proc.stdout or ""
        err = proc.stderr or ""
    except subprocess.TimeoutExpired:
        return "", "TIMEOUT"
    except OSError as exc:
        return "", f"LANCE:{exc}"
    (workdir / f"ld1_rm{rm:g}.out").write_text(out + err)
    return out, None


def _error_of(text: str):
    m = re.search(r"Error in routine ([^\s(]+)\s*\((\d+)\)\s*:?\s*\n?\s*([^\n]*)",
                  text)
    if not m:
        return None
    return (m.group(1), m.group(3).strip())


def _rmesh_of(text: str):
    m = re.search(r"r\(mesh\)\s*=\s*([\d.]+)", text)
    return float(m.group(1)) if m else None


# --------------------------------------------------------------------------
# Analyse de la sortie
# --------------------------------------------------------------------------
def _parse_ae_eigenvalues(text: str) -> dict:
    """Valeurs propres tout-électron, groupées par canal ``l``."""
    eigs: dict = {}
    m = re.search(r"All-electron run(.*?)(?:Testing the pseudopotential|"
                  r"End of all-electron|\Z)", text, re.S)
    block = m.group(1) if m else text
    for line in block.splitlines():
        mm = re.match(
            r"\s*\d+\s+(\d+)\s+\S+\s+\d+\(\s*[\d.]*\)\s+"
            r"([-+]?\d+\.\d+)\s+[-+]?\d+\.\d+\s+[-+]?\d+\.\d+", line)
        if mm:
            eigs.setdefault(int(mm.group(1)), []).append(float(mm.group(2)))
    return eigs


# Ligne du tableau « Testing the pseudopotential » de ld1.x :
#     1 0     3S   1( 2.00)       -0.56816       -0.57451        0.00635  !
# Le « ! » final est le verdict **du générateur** : l'écart AE/PS dépasse son
# seuil, c'est-à-dire que le pseudo ne reproduit pas cet état tout-électron.
_PS_ROW = re.compile(
    r"^\s*(\d+)\s+(\d+)\s+(\S+)\s+[^(]*\(\s*[\d.]+\s*\)\s+"
    r"([-+]?\d+\.\d+)\s+([-+]?\d+\.\d+)\s+([-+]?\d+\.\d+)(\s*!)?\s*$")


def _parse_ps_test_table(text: str) -> list:
    """Tableau AE/PS de ld1.x (section « Testing the pseudopotential »).

    C'est le test de dérivées logarithmiques du générateur : chaque ligne
    compare l'énergie d'un état tout-électron et celle du pseudo, et ``ld1.x``
    marque ``!`` les écarts excessifs.
    """
    rows = []
    for chunk in (text or "").split("Testing the pseudopotential")[1:]:
        block = re.split(r"\n\s*(?:Test configuration|eps\s*=|Etot\s*=|End of)",
                         chunk)[0]
        for line in block.splitlines():
            m = _PS_ROW.match(line)
            if not m:
                continue
            row = {
                "n": int(m.group(1)), "l": int(m.group(2)),
                "etat": m.group(3),
                "e_ae_ry": round(float(m.group(4)), 6),
                "e_ps_ry": round(float(m.group(5)), 6),
                "ecart_ry": round(float(m.group(6)), 6),
                "flag": bool(m.group(7)),
            }
            if row not in rows:
                rows.append(row)
    return rows


# Ligne du tableau tout-électron de ld1.x :
#     1 0     1S 1( 2.00)     -1621.3240      -810.6620    -22059.2371
_AE_ROW = re.compile(
    r"^\s*(\d+)\s+(\d+)\s+(\S+)\s+\d+\(\s*([\d.]+)\s*\)\s+"
    r"([-+]?\d+\.\d+)")


def _parse_ae_shells(text: str) -> list:
    """Couches de l'atome tout-électron de référence (tableau ``n l nl e``).

    On s'ancre sur l'en-tête **propre au tableau tout-électron**
    (``e(Ry)   e(Ha)   e(eV)``) : celui du tableau AE/PS (``e AE (Ry)``) a un
    format de ligne très proche et serait sinon confondu avec lui.
    """
    shells = []
    lines = (text or "").splitlines()
    start = None
    for i, line in enumerate(lines):
        if "e AE (Ry)" in line:
            continue
        if "e(Ry)" in line and "e(Ha)" in line:
            start = i
            break
    if start is None:
        return shells
    for line in lines[start + 1:]:
        m = _AE_ROW.match(line)
        if m:
            shells.append({
                "n": int(m.group(1)), "l": int(m.group(2)),
                "etat": m.group(3), "occupation": float(m.group(4)),
                "e_ry": float(m.group(5)),
            })
            continue
        if line.strip():
            break
    return shells


def _ae_reference_charge(text: str, zed: float):
    """(charge_calculée, ok, liste) — l'atome AE de ld1.x est-il complet ?

    **Garde indispensable.** Sur certains UPF (convert ``iswitch=3`` de
    ``generation_pseudos``), ``ld1.x`` perd des électrons de cœur : pour
    ``Ru.pbe-us.UPF`` il construit un atome à 38 électrons au lieu de 44
    (les 4p6 disparaissent). Le potentiel est alors celui d'un ion, tous les
    états sont artificiellement liés, et le tableau AE/PS devient absurde
    (4D tout-électron à −6,98 Ry). On refuse de conclure dans ce cas.
    """
    shells = _parse_ae_shells(text)
    if not shells or not zed:
        return None, True, shells
    charge = round(sum(s["occupation"] for s in shells), 3)
    return charge, abs(charge - zed) < 0.5, shells


def _parse_bessel(text: str) -> dict:
    """``{l: [(ecut, [E1, E2, E3]), ...]}`` depuis le bloc Bessel."""
    part = text.split("basis set of Bessel", 1)
    if len(part) < 2:
        return {}
    body = part[1]
    data: dict = {}
    ecut = None
    for line in body.splitlines():
        me = re.search(r"Cutoff \(Ry\)\s*:\s*([\d.]+)", line)
        if me:
            ecut = float(me.group(1))
            continue
        ml = re.match(r"\s*E\(L=(\d)\)\s*=(.*)", line)
        if ml and ecut is not None:
            vals = [float(v) for v in re.findall(r"([-+]?\d+\.\d+)\s*Ry",
                                                 ml.group(2))]
            if vals:
                data.setdefault(int(ml.group(1)), []).append((ecut, vals))
    return data


def _pseudo_terms_sane(text: str) -> bool:
    """Vérifie la cohérence du rappel des composantes de l'énergie du pseudo.

    Pour les UPF que ``ld1.x`` ne restitue pas correctement (PAW ATOMPAW),
    ``Encl`` et ``Ehrt`` sortent à zéro et la somme ne retombe pas sur
    ``Etotps`` : la référence est alors inexploitable.
    """
    idx = text.rfind("Etotps")
    if idx < 0:
        return True
    block = text[idx:idx + 3000]
    m = re.search(r"Etotps\s*=\s*([-+]?\d+\.\d+)", block)
    if not m:
        return True
    tot = float(m.group(1))
    terms = {}
    for name in ("Ekin", "Encl", "Ehrt"):
        mm = re.search(name + r"\s*=\s*([-+]?\d+\.\d+)", block)
        if not mm:
            return True
        terms[name] = float(mm.group(1))
    # ``Encl`` (noyau + local) et ``Ehrt`` ne peuvent pas être simultanément
    # nuls : c'est la signature d'un potentiel local non exploité.
    if abs(terms["Encl"]) < 1e-9 and abs(terms["Ehrt"]) < 1e-9:
        return False
    for name in ("Ecxc", "Epseu"):
        mm = re.search(name + r"\s*=\s*([-+]?\d+\.\d+)", block)
        if not mm:
            return abs(sum(terms.values()) - tot) < max(0.05, abs(tot) * 1e-3)
        terms[name] = float(mm.group(1))
    return abs(sum(terms.values()) - tot) < max(0.05, abs(tot) * 1e-3)


def classify(ae: dict, bessel_by_box: dict) -> dict:
    """Classe les états du test Bessel et repère les ghosts.

    ``bessel_by_box`` : ``{rm: {l: [(ecut, [E...])]}}``.
    """
    boxes = sorted(bessel_by_box)
    details = {"bessel": {}, "bound": [], "ghosts": [], "matched": []}

    if len(boxes) < 2:
        return details

    small, large = boxes[0], boxes[-1]
    for l in sorted(set(bessel_by_box[small]) & set(bessel_by_box[large])):
        big = max(bessel_by_box[large][l], key=lambda t: t[0])[1]
        sml = max(bessel_by_box[small][l], key=lambda t: t[0])[1]
        n = min(len(big), len(sml))
        details["bessel"][l] = {
            "grande_boite": [round(v, 4) for v in big],
            "petite_boite": [round(v, 4) for v in sml],
        }
        for i in range(n):
            stable = abs(big[i] - sml[i]) <= _TOL_BOX
            if not stable:
                continue
            details["bound"].append({"l": l, "n": i + 1,
                                     "e_ry": round(big[i], 4)})
            ref = ae.get(l, [])
            if any(abs(big[i] - e) <= _TOL_MATCH for e in ref):
                details["matched"].append({"l": l, "n": i + 1,
                                           "e_ry": round(big[i], 4)})
            else:
                details["ghosts"].append({"l": l, "n": i + 1,
                                          "e_ry": round(big[i], 4)})
    return details


# --------------------------------------------------------------------------
# Point d'entrée
# --------------------------------------------------------------------------
def run_level2(upf, ld1_bin: str, timeout: float = 240.0,
               workdir=None) -> dict:
    """Exécute ``ld1.x`` (iswitch=2 + test Bessel) sur ``upf`` et conclut.

    Retourne un dict au format des autres niveaux :
    ``{status, cause, solution, details}``.
    """
    upf = Path(upf)
    if not upf.is_file():
        return {"status": "SKIPPED", "cause": f"UPF introuvable : {upf}.",
                "solution": None, "details": {}}
    if not shutil.which(ld1_bin) and not Path(ld1_bin).is_file():
        return {"status": "SKIPPED",
                "cause": f"Exécutable ld1.x introuvable ({ld1_bin}).",
                "solution": "Exporter QE_BIN_DIR vers le répertoire bin de QE.",
                "details": {}}

    info = read_upf(upf)
    details = {"element": info["element"], "config_source": info["source"]}

    if info["zed"] is None:
        return {"status": "SKIPPED",
                "cause": "Élément du UPF non identifié : impossible de "
                         "construire la configuration de référence de ld1.x.",
                "solution": None, "details": details}
    if info["zed"] > LD1_MAX_Z:
        return {
            "status": "SKIPPED",
            "cause": f"ld1.x ne traite pas Z={int(info['zed'])} "
                     f"(limite du code atomic : Z ≤ {LD1_MAX_Z}).",
            "solution": "Tester le ghost avec le générateur d'origine "
                        "(ONCVPSP/ATOPAW) ; ld1.x est hors de portée.",
            "details": details,
        }

    tmp = Path(workdir) if workdir else Path(tempfile.mkdtemp(prefix="ld1l2_"))
    tmp.mkdir(parents=True, exist_ok=True)

    runs = {}
    queue = list(_BOX_CANDIDATES)
    while queue and len(runs) < 2:
        rm = queue.pop(0)
        if rm in runs:
            continue
        out, hard = _run_once(ld1_bin, upf, info, rm, timeout, tmp)
        if hard == "TIMEOUT":
            return {"status": "SKIPPED",
                    "cause": f"ld1.x n'a pas terminé en {int(timeout)} s.",
                    "solution": "Augmenter LD1_TIMEOUT.",
                    "details": details}
        if hard:
            return {"status": "SKIPPED", "cause": f"ld1.x non exécutable : {hard}",
                    "solution": None, "details": details}
        err = _error_of(out)
        if err and "test_bessel" in err[0] and "r(mesh)" in err[1]:
            rmesh = _rmesh_of(out)
            if rmesh:
                nxt = round(min(0.7 * rmesh, rm * 0.6), 1)
                if nxt >= 3.0 and nxt not in runs and nxt not in queue:
                    queue.insert(0, nxt)
            continue
        if err:
            name, msg = err
            details["ld1_error"] = f"{name} : {msg}"
            if any(k in name for k in ("read_pseudoup", "read_pseudo")):
                return {
                    "status": "SKIPPED",
                    "cause": f"ld1.x ne sait pas lire ce UPF ({msg}). "
                             "Typique des mailles ONCVPSP/ATOMPAW.",
                    "solution": "Utiliser le test de ghost du générateur "
                                "d'origine (ONCVPSP/ATOMPAW) pour ce pseudo.",
                    "details": details,
                }
            if "ld1_readin" in name:
                return {
                    "status": "SKIPPED",
                    "cause": f"ld1.x refuse l'input reconstruit ({msg}).",
                    "solution": "Reconstruire la configuration de référence "
                                "à la main pour ce couple élément/maille.",
                    "details": details,
                }
            return {"status": "SKIPPED",
                    "cause": f"ld1.x a échoué ({name} : {msg}).",
                    "solution": None, "details": details}
        bessel = _parse_bessel(out)
        if bessel:
            runs[rm] = {"text": out, "bessel": bessel}
            if len(runs) == 1:
                # Seconde passe dans une boîte nettement plus petite : c'est
                # le contraste entre les deux qui sépare les états liés des
                # états de continuum discrétisé.
                rm2 = round(max(5.0, rm * _BOX_CONTRAST), 1)
                if rm2 not in runs and rm2 not in queue:
                    queue.insert(0, rm2)

    if len(runs) < 2:
        cause = ("ld1.x a démarré mais le test Bessel n'a produit aucun état "
                 "exploitable.") if runs else \
                "ld1.x n'a produit aucun test Bessel exploitable."
        return {"status": "SKIPPED", "cause": cause,
                "solution": "Vérifier la maille radiale du UPF.",
                "details": details,
                "log": str(tmp / f"ld1_rm{max(runs):g}.out") if runs else None}

    boxes = sorted(runs)
    small, large = boxes[0], boxes[-1]
    ae = _parse_ae_eigenvalues(runs[large]["text"])
    cls = classify(ae, {rm: runs[rm]["bessel"] for rm in runs})
    details.update({
        "boites_bohr": [small, large],
        "ae_eigenvalues_ry": {str(k): [round(v, 4) for v in vals]
                              for k, vals in sorted(ae.items())},
        "etats_lies": cls["bound"],
        "etats_correspondants_ae": cls["matched"],
        "ghosts": cls["ghosts"],
        "bessel": {str(k): v for k, v in cls["bessel"].items()},
    })

    log_path = str(tmp / f"ld1_rm{large:g}.out")

    # Test de dérivées logarithmiques du générateur : tableau AE/PS de ld1.x.
    ps_rows = []
    for rm in sorted(runs, reverse=True):
        for row in _parse_ps_test_table(runs[rm]["text"]):
            if row not in ps_rows:
                ps_rows.append(row)
    flagged = [r for r in ps_rows if r["flag"]]
    details["comparaison_ae_ps"] = ps_rows
    details["ecarts_ae_ps_flagges"] = flagged

    ae_charge, ae_ok, ae_shells = _ae_reference_charge(
        runs[large]["text"], info.get("zed"))
    details["atome_ae_electrons"] = ae_charge
    details["atome_ae_valide"] = ae_ok
    if not ae_ok:
        return {
            "status": "SKIPPED",
            "cause": f"ld1.x construit un atome tout-électron à {ae_charge:g} "
                     f"électron(s) au lieu de {info['zed']:g} (charge de cœur "
                     "perdue à la lecture du UPF) : le potentiel de référence "
                     "est celui d'un ion et le tableau AE/PS est sans valeur. "
                     "Le test n'est pas concluant pour ce pseudo.",
            "solution": "Régénérer le pseudo d'origine, ou le tester avec son "
                        "générateur (ONCVPSP / ATOMPAW).",
            "details": details,
            "log": log_path,
        }

    if flagged:
        liste = ", ".join(
            f"{r['etat']} l={r['l']} : PS {r['e_ps_ry']:.5f} Ry vs AE "
            f"{r['e_ae_ry']:.5f} Ry (écart {r['ecart_ry']:+.5f} Ry)"
            for r in flagged)
        return {
            "status": "WARNING",
            "cause": "ld1.x signale un écart AE/PS au-delà de son seuil "
                     f"(colonnes marquées « ! ») : {liste}.",
            "solution": "Ne pas utiliser ce pseudo en production ; revoir "
                        "les rayons de coupure (rc) / Ep des canaux signalés, "
                        "puis régénérer avec atomic.",
            "details": details,
            "log": log_path,
        }

    if not ps_rows and not _pseudo_terms_sane(runs[large]["text"]):
        return {
            "status": "SKIPPED",
            "cause": "ld1.x ne restitue pas la référence tout-électron de "
                     "ce pseudo (potentiel local non exploité : composantes "
                     "Encl/Ehrt nulles) : test Bessel inexploitable.",
            "solution": "Tester ce pseudo avec son générateur d'origine ; "
                        "ce UPF n'est pas exploitable par ld1.x.",
            "details": details,
            "log": log_path,
        }
    if not ps_rows and not cls["matched"]:
        # Le test auto-cohérent du pseudo a-t-il convergé ?
        conv = re.search(r"eps\s*=\s*([\d.eE+-]+)\s+iter\s*=\s*(\d+)",
                         runs[large]["text"])
        unkonverged = False
        if conv:
            try:
                unkonverged = float(conv.group(1)) > 1e-6 or int(conv.group(2)) >= 200
            except ValueError:
                pass
        details["psc_non_convergent"] = unkonverged
        if unkonverged:
            return {
                "status": "WARNING",
                "cause": "Le test auto-cohérent de ld1.x sur ce pseudo "
                         "n'a pas convergé (eps = " + conv.group(1) +
                         ", iter = " + conv.group(2) + ") : le pseudo ne "
                         "reproduit pas les états de valence tout-électron "
                         "et le test de ghost est inexploitable.",
                "solution": "Vérifier la génération du pseudo "
                            "(rayons de coupure, potentiel local) ; il reste "
                            "utilisable en pw.x mais son test ld1.x échoue.",
                "details": details,
                "log": log_path,
            }
        return {
            "status": "SKIPPED",
            "cause": "Aucun état du test Bessel ne correspond à la référence "
                     "tout-électron : interprétation impossible en l'état.",
            "solution": "Vérifier la configuration de référence utilisée "
                        "pour ld1.x (élément ou maille non standard).",
            "details": details,
            "log": log_path,
        }

    n_ghost = len(cls["ghosts"])
    if n_ghost:
        liste = ", ".join(f"l={g['l']} n={g['n']} ({g['e_ry']:.4f} Ry)"
                          for g in cls["ghosts"])
        return {
            "status": "WARNING",
            "cause": f"Ghost state(s) détecté(s) par le test Bessel de "
                     f"ld1.x : {liste}.",
            "solution": "Ne pas utiliser ce pseudo en production ; revoir "
                        "les rayons de coupure (rc) et Ep du canal concerné, "
                        "puis régénérer.",
            "details": details,
            "log": log_path,
        }
    detail_ae_ps = ""
    if ps_rows:
        detail_ae_ps = (" Le tableau AE/PS de ld1.x ne porte aucune marque "
                        "« ! » sur ses " + str(len(ps_rows))
                        + " état(s) : ld1.x ne signale aucun écart.")
    return {
        "status": "SUCCESS",
        "cause": "Aucun ghost : le test Bessel ne montre que des états liés "
                 "correspondant à la référence tout-électron." + detail_ae_ps,
        "solution": None,
        "details": details,
        "log": str(tmp / f"ld1_rm{large:g}.out"),
    }

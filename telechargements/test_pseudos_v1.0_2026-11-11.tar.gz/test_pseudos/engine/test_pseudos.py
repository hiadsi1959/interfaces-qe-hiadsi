#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script complet et automatisé de validation de pseudopotentiels (.UPF) pour Quantum ESPRESSO.

Objectif : test à deux niveaux
  - Niveau 1 : stabilité numérique SCF (pw.x) sur atome isolé
  - Niveau 2 : analyse des dérivées logarithmiques / ghost states par générateur
        ONCVPSP   -> .out de génération (généralement à côté du .UPF ou dans
                    ONCVPSP_OUT_ROOT)
        ld1       -> ld1.x (iswitch=2) sur les UPFs DAL CORSO / atomic
        ape       -> ape_run.log (section Ghost state analysis)
        atompaw   -> atompaw_run.log (+ logderiv.*)
"""

import hashlib
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path

# ---------------------------------------------------------------------------
# Configuration des outils par générateur
# ---------------------------------------------------------------------------
_PW_X = os.environ.get("PW_BIN", "pw.x")
_LD1_X = os.environ.get("LD1_BIN", "ld1.x")

_LD1_LOG = "ld1_run.log"
_ATOMPAW_LOG = "atompaw_run.log"
_LOGDERIV_GLOB = "logderiv.*"

_GHOST_PATTERN = re.compile(r"GHOST", re.I)
# En-têtes de section des générateurs (« Testing for bound ghosts »,
# « Testing for highly-localized positive-energy ghosts ») : ce ne sont PAS des
# ghosts et les compter produisait des faux positifs sur des pseudos sains.
_GHOST_HEADER = re.compile(r"(?:testing|test|checking|search\w*)\s+for\b[^\n]*\bghost", re.I)


def _ghost_hits(text):
    """Occurrences de ghost réellement signalées (hors en-têtes de section)."""
    hits = []
    for m in _GHOST_PATTERN.finditer(text or ""):
        start = text.rfind("\n", 0, m.start()) + 1
        end = text.find("\n", m.end())
        line = text[start:end if end != -1 else len(text)]
        if _GHOST_HEADER.search(line):
            continue
        hits.append(m)
    return hits

# Timeout du SCF. Si PSEUDO_TEST_TIMEOUT est défini, il PRIME et borne TOUTES
# les exécutions pw.x ; sinon valeur par défaut selon le type de pseudo.
_PW_TIMEOUT_ENV = os.environ.get("PSEUDO_TEST_TIMEOUT") or None
_DEFAULT_PW_TIMEOUT = float(_PW_TIMEOUT_ENV) if _PW_TIMEOUT_ENV else 600.0

# Correction automatique : après un échec du niveau 1, on relance le SCF avec
# des paramètres corrigés (dans une limite stricte de tentatives) afin de
# trouver un jeu de paramètres qui rend le pseudo utilisable dans QE.
_AUTOCORRECT = os.environ.get("PSEUDO_TEST_AUTOCORRECT", "1").strip().lower() not in {
    "0", "false", "no", "off",
}
_AUTOCORRECT_MAX = int(os.environ.get("PSEUDO_TEST_AUTOCORRECT_MAX", "3"))

# Paramètres par défaut du calcul SCF.
_PW_DEFAULTS = {
    # Cutoff d'onde pour le test atome isolé. 60 Ry reste discriminant (les
    # pseudos sont validés sur la stabilité SCF, pas sur l'énergie absolue)
    # tout en restant léger : à 200 Ry les PAW (ecutrho 12×) exigeaient
    # ~27 Go de RAM et faisaient planter pw.x. Surchargez via
    # PSEUDO_TEST_ECUTWFC si vous voulez un test plus strict.
    "ecutwfc": float(os.environ.get("PSEUDO_TEST_ECUTWFC", "60.0")),
    "mixing_beta": 0.3,
    "electron_maxstep": 150,
    "conv_thr": 1.0e-5,
    # Taille de la boîte pour l'atome isolé (bohr). 16 bohr (~8,5 Å) isole
    # correctement l'atome tout en gardant le calcul léger ; surcharger via
    # PSEUDO_TEST_CELL pour une isolation plus large.
    "celldm": float(os.environ.get("PSEUDO_TEST_CELL", "16.0")),
    "smearing": "methfessel-paxton",
    "degauss": 0.02,
    "occupations": "smearing",
    "input_dft": "PBE",
}

# Cause → explication + actions de correction (physiquement motivées).
_DIAGNOSIS = {
    "TIMEOUT": (
        "La SCF n'a pas convergé dans le temps imparti.",
        ["ralentir le mélange (mixing_beta ↓)", "élargir le smearing (degauss ↑)",
         "augmenter ecutwfc / ecutrho", "augmenter electron_maxstep"],
    ),
    "NON_CONVERGED": (
        "La SCF a épuisé electron_maxstep sans atteindre conv_thr "
        "(charge sloshing typique d'un métal dans une grande boîte).",
        ["ralentir le mélange (mixing_beta 0.1 puis 0.05)",
         "passer en smearing gaussien plus large",
         "éventuellement augmenter ecutwfc", "augmenter electron_maxstep"],
    ),
    "NO_CONVERGENCE": (
        "pw.x s'est arrêté sans convergence ni énergie totale.",
        ["augmenter ecutwfc / ecutrho", "vérifier l'intégrité du fichier UPF"],
    ),
    "UNSTABLE": (
        "Instabilité numérique (NaN / exception flottante / segfault) : "
        "souvent un ecutrho trop faible (aliasing) ou un pseudo défectueux.",
        ["augmenter ecutwfc et ecutrho", "ralentir le mélange",
         "revoir les rayons de coupure r_c dans le générateur"],
    ),
    "MEMORY": (
        "pw.x a manqué de mémoire (grille de charge trop fine pour la RAM disponible).",
        ["réduire ecutrho", "réduire ecutwfc", "réduire la boîte de test"],
    ),
    "PW_ERROR": (
        "pw.x s'est arrêté sur une erreur explicite (Error in routine).",
        ["augmenter ecutwfc / ecutrho", "vérifier le fichier UPF"],
    ),
    "RC_NONZERO": (
        "pw.x a renvoyé un code retour non nul.",
        ["consulter la sortie pw.x"],
    ),
    "NO_OUTPUT": (
        "Aucune sortie pw.x exploitable.",
        ["vérifier le binaire pw.x (PW_BIN / QE_BIN_DIR)"],
    ),
}


def recommended_ecutrho(pseudo_type: str, ecutwfc: float = 60.0) -> float:
    """Cutoff de charge adapté au type de pseudo (NC/US/PAW)."""
    ptype = (pseudo_type or "").upper()
    if ptype == "NC":
        return 4.0 * ecutwfc
    elif ptype == "US":
        return 8.0 * ecutwfc
    elif ptype == "PAW":
        return 12.0 * ecutwfc
    return 4.0 * ecutwfc


def recommended_timeout(pseudo_type: str, default: float = None) -> float:
    """Timeout du SCF (s).

    ``PSEUDO_TEST_TIMEOUT`` prime s'il est défini, sinon valeurs par type :
    600 s (US/PAW, plus lourds) et 420 s (NC).
    """
    if _PW_TIMEOUT_ENV:
        return float(_PW_TIMEOUT_ENV)
    if default is not None:
        return float(default)
    ptype = (pseudo_type or "").upper()
    return 600.0 if ptype in ("US", "PAW") else 420.0


def _load_ghost_fix():
    """Charge le module d'élimination des ghosts (ONCVPSP), si disponible."""
    try:
        from ghost_fix import fix_ghosts  # noqa: WPS433
        return fix_ghosts
    except Exception:
        pass
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "ghost_fix", Path(__file__).resolve().parent / "ghost_fix.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod.fix_ghosts
    except Exception:
        return None


_fix_ghosts = _load_ghost_fix()


def _load_ld1_ghost():
    """Charge le module d'exécution automatique de ld1.x (niveau 2), si dispo."""
    try:
        import ld1_ghost  # noqa: WPS433
        return ld1_ghost
    except Exception:
        pass
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "ld1_ghost", Path(__file__).resolve().parent / "ld1_ghost.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


_ld1_ghost = _load_ld1_ghost()


def _load_gen_ghost():
    """Charge le module « test de ghost du générateur d'origine » (niveau 2)."""
    try:
        import gen_ghost  # noqa: WPS433
        return gen_ghost
    except Exception:
        pass
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "gen_ghost", Path(__file__).resolve().parent / "gen_ghost.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


_gen_ghost = _load_gen_ghost()


def _level2_via_generator(upf: Path, gen: str, oncv_search_roots, work_dir):
    """Niveau 2 par le test de ghost natif du générateur d'origine.

    ``ld1.x`` ne lit que les mailles ``atomic`` ; ONCVPSP et ATOMPAW ont donc
    leur propre test, exécuté ici.
    """
    if _gen_ghost is None:
        return None
    run_dir = Path(work_dir) / f"{gen}_level2" if work_dir else None
    try:
        if gen == "oncvpsp":
            return _gen_ghost.level2_oncvpsp(
                upf, roots=oncv_search_roots, work_dir=run_dir)
        if gen == "atompaw":
            return _gen_ghost.level2_atompaw(
                upf, roots=oncv_search_roots, work_dir=run_dir)
    except Exception as exc:  # pragma: no cover - dépend de l'environnement
        return {
            "status": "SKIPPED",
            "cause": f"Test de ghost du générateur ({gen}) impossible : {exc}",
            "solution": None,
            "details": {"generator": gen},
        }
    return None

# Le test ld1.x (iswitch=2 + Bessel) est un calcul atomique -> quelques secondes.
_LD1_LEVEL2_TIMEOUT = float(os.environ.get("LD1_TIMEOUT", "150"))


def _run_ld1_level2(upf: Path, work_dir=None):
    """Niveau 2 sans journal fourni : on exécute ld1.x (iswitch=2) nous-mêmes.

    Un ``ld1_run.log`` placé à côté du UPF reste prioritaire (il est analysé
    tel quel) ; à défaut, l'input est reconstruit depuis le UPF et ld1.x est
    lancé avec le test des dérivées logarithmiques et le test Bessel, qui
    révèle les états fantômes.
    """
    if _ld1_ghost is None:
        return {
            "status": "SKIPPED",
            "cause": "Module d'exécution ld1.x indisponible (engine/ld1_ghost.py).",
            "solution": "Exécuter ld1.x avec iswitch=2 et placer le log à côté du UPF.",
        }

    run_dir = Path(work_dir) / "ld1_level2" if work_dir else None
    try:
        return _ld1_ghost.run_level2(upf, _LD1_X,
                                     timeout=_LD1_LEVEL2_TIMEOUT,
                                     workdir=run_dir)
    except Exception as exc:  # pragma: no cover - dépend de l'environnement
        return {
            "status": "SKIPPED",
            "cause": f"ld1.x n'a pas pu être exécuté automatiquement ({exc}).",
            "solution": "Vérifier QE_BIN_DIR / LD1_BIN, ou fournir ld1_run.log.",
        }

# Détection du générateur à partir du header UPF.
_GENERATOR_RE = {
    "oncvpsp": re.compile(r"ONCVPSP|OPTIMIZED\s*NORM-CONSERVING", re.I),
    "ld1": re.compile(r"DAL\s*CORSO|GENERATED\s+USING\s+\"ATOMIC\"|ATOMIC\s+PSEUDOPOTENTIAL\s+ENGINE", re.I),
    "ape": re.compile(r"ATOMIC\s+PSEUDOPOTENTIAL\s+ENGINE|APE", re.I),
    "atompaw": re.compile(r"ATOMPAW|PseudoDojo", re.I),
}


def _ensure_work_dir(work_dir):
    """Crée un répertoire de travail accessible en écriture (repli /tmp si besoin)."""
    if work_dir is None:
        return Path(tempfile.mkdtemp(prefix="pseudo_test_"))
    path = Path(work_dir)
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".write_probe"
        probe.write_text("ok")
        probe.unlink()
        return path
    except OSError:
        return Path(tempfile.mkdtemp(prefix="pseudo_test_"))


def _read_output(path):
    """Lit un fichier de sortie et retourne (contenu, ok)."""
    p = Path(path)
    if not p.is_file():
        return None, False
    try:
        return p.read_text(errors="ignore"), True
    except OSError:
        return None, False


def _write_output(path, content):
    """Écrit un fichier de sortie (données brutes)."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content)
    return p


def _attr(text, name, default=None):
    """Extrait un attribut UPF name="value"."""
    m = re.search(rf'\b{name}="([^"]*)"', text, flags=re.I)
    return m.group(1).strip() if m else default


def upf_text(upf_path: Path) -> str:
    return Path(upf_path).read_text(errors="ignore")


def _upf_text(upf_path: Path) -> str:
    return upf_text(upf_path)

def detect_generator(text):
    """Détecteur du générateur d'origine d'un pseudo UPF."""
    u = text.upper()
    if "ONCVPSP" in u:
        return "oncvpsp"
    if "ATOMPAW" in u or "PseudoDojo" in u:
        return "atompaw"
    if "ATOMIC PSEUDOPOTENTIAL ENGINE" in u:
        return "ape"
    if "DAL CORSO" in u or 'GENERATED USING "ATOMIC"' in u:
        return "ld1"
    return None

def infer_generator_from_path(upf_path: Path):
    """Fallback : deviner le générateur depuis le nom du fichier."""
    s = upf_path.name.lower()
    if "oncv" in s:
        return "oncvpsp"
    if "ld1" in s or "atompaw" in s or "ape" in s or "paw" in s:
        # très heuristique ; on ne triche pas plus
        return None
    return None


def extract_element_name(filename: str):
    """Devine l'élément depuis le nom du fichier si aucun attribut element."""
    base = Path(filename).stem.lower()
    # On cherche la première lettre majuscule... mais ici on simplify
    m = re.match(r"([A-Z][a-z]*)", base)
    if m:
        return m.group(1)
    return None


_TRUE_VALUES = {"true", "t", ".true.", "1", "yes", "y"}


def _as_bool(value) -> bool:
    """Interprète un attribut booléen UPF ("true"/"T"/".true."/...)."""
    return str(value).strip().strip('"').lower() in _TRUE_VALUES


def detect_pseudo_type(text) -> str:
    """Détecte le type de pseudo (NC / US / PAW) de façon fiable.

    Priorité : attribut explicite ``pseudo_type`` (UPF v2) > booléens
    ``is_paw`` / ``is_ultrasoft`` > heuristique textuelle prudente (UPF v1).
    Une simple recherche de sous-chaîne (``"US" in text``) produisait des faux
    positifs (« PLU**S** », « beca**us**e »…) qui gonflaient ``ecutrho`` à 8×
    au lieu de 4× et faisaient exploser le calcul (RAM et durée).
    """
    raw = _attr(text, "pseudo_type")
    if raw:
        v = raw.strip().upper()
        if v in ("NC", "US", "PAW"):
            return v
        # "SL" (semi-local) et autres variantes norm-conservantes
        if v == "SL":
            return "NC"

    if _as_bool(_attr(text, "is_paw", "false")):
        return "PAW"
    if _as_bool(_attr(text, "is_ultrasoft", "false")):
        return "US"

    # UPF v1 : pas d'attributs de type -> heuristique par mots entiers.
    u = text.upper()
    if re.search(r"\bPAW\b", u):
        return "PAW"
    if "ULTRASOFT" in u or re.search(r"\bUS\b", u):
        return "US"
    return "NC"


def parse_upf_meta(upf_path):
    """Extrait les métadonnées principales du fichier UPF."""
    upf_path = Path(upf_path)
    text = upf_text(upf_path)
    gen = detect_generator(text)

    element = _attr(text, "element") or extract_element_name(upf_path.name)

    z_valence = None
    zv = _attr(text, "z_valence")
    if zv:
        try:
            z_valence = float(zv.replace("D", "E").replace("d", "e"))
        except ValueError:
            pass

    if gen is None:
        gen = infer_generator_from_path(upf_path)

    # Type de pseudo : NC / US / PAW (voir detect_pseudo_type)
    pseudo_type = detect_pseudo_type(text)

    l_max_attr = _attr(text, "l_max")
    l_max = int(l_max_attr) if l_max_attr else None
    rel_attr = _attr(text, "rel")
    rel = int(rel_attr) if rel_attr else None

    n_proj = None
    np_ = _attr(text, "number_of_proj")
    if np_:
        try:
            n_proj = int(np_)
        except ValueError:
            pass

    raw_func = _attr(text, "functional")
    dft = normalize_dft(raw_func)

    return {
        "element": element.strip().lower() if element else None,
        "generator": gen,
        "dft": dft,
        "dft_raw": raw_func,
        "z_valence": z_valence,
        "pseudo_type": pseudo_type,
        "l_max": l_max,
        "rel": rel,
        "number_of_proj": n_proj,
    }


# ---------------------------------------------------------------------------
# Validation structurelle UPF (référence méthodologique — exposée API + UI)
# ---------------------------------------------------------------------------

_UPF_VERSION_RE = re.compile(r'<UPF\s+version\s*=\s*"([^"]+)"', re.I)
_STRUCTURE_BLOCKS = ("PP_HEADER", "PP_MESH", "PP_NONLOCAL", "PP_LOCAL")
_WFC_BLOCK_PREFIXES = ("PP_CHI", "PP_PSWFC")


def normalize_dft(functional: str | None) -> str | None:
    """Traduit la chaîne ``functional`` du UPF en ``input_dft`` Quantum ESPRESSO."""
    if not functional:
        return None
    u = str(functional).upper()
    if "PBE0" in u:
        return "PBE0"
    if "PBE" in u or ("PBX" in u and "PBC" in u):
        return "PBE"
    if "PW91" in u:
        return "PW91"
    if "BP" in u and "86" in u:
        return "B86"
    # Famille LDA (Perdew-Zunger, Slater exchange + PZ correlation…)
    if re.search(r"\bLDA\b", u) or re.search(r"\bPZ\b", u):
        return "PZ"
    if "SLA" in u and "PZ" in u and "PBX" not in u:
        return "PZ"
    if "SLA" in u and "PW" in u and "PBX" not in u and "PBC" not in u:
        return "PZ"
    return None


def _structure_check(checks: list, cid: str, label: str, status: str,
                     detail: str | None = None, *, block: bool = False) -> bool:
    """Ajoute une ligne de contrôle ; retourne True si échec bloquant."""
    checks.append({
        "id": cid,
        "label": label,
        "status": status,
        "detail": detail,
    })
    return block and status == "FAILED"


def validate_upf_structure(upf_path) -> dict:
    """Contrôle format, blocs requis, cohérences et empreinte SHA-256 du UPF."""
    upf_path = Path(upf_path)
    checks: list = []
    blocking = False

    if not upf_path.is_file():
        _structure_check(checks, "file", "Fichier UPF présent", "FAILED",
                         str(upf_path), block=True)
        return {
            "status": "FAILED", "version": None, "sha256": None,
            "pseudo_type": None, "input_dft": None,
            "checks": checks, "blocking": True,
        }

    try:
        raw = upf_path.read_bytes()
    except OSError as exc:
        _structure_check(checks, "readable", "Fichier lisible", "FAILED", str(exc),
                         block=True)
        return {
            "status": "FAILED", "version": None, "sha256": None,
            "pseudo_type": None, "input_dft": None,
            "checks": checks, "blocking": True,
        }

    if len(raw) < 128:
        blocking |= _structure_check(
            checks, "size", "Taille minimale du fichier", "FAILED",
            f"{len(raw)} octets", block=True)
    else:
        checks.append({
            "id": "size",
            "label": "Taille du fichier",
            "status": "SUCCESS",
            "detail": f"{len(raw):,} octets".replace(",", " "),
        })

    sha = hashlib.sha256(raw).hexdigest()
    text = raw.decode("utf-8", errors="replace")

    if "</UPF>" not in text:
        checks.append({
            "id": "complete",
            "label": "Balise de fin </UPF>",
            "status": "WARNING",
            "detail": "fichier possiblement tronqué ou format v1",
        })
    else:
        checks.append({
            "id": "complete",
            "label": "Balise de fin </UPF>",
            "status": "SUCCESS",
            "detail": None,
        })

    vm = _UPF_VERSION_RE.search(text)
    version = vm.group(1) if vm else None
    checks.append({
        "id": "version",
        "label": "Version du format",
        "status": "SUCCESS" if version else "WARNING",
        "detail": version or "non détectée",
    })

    for block in _STRUCTURE_BLOCKS:
        if re.search(rf"<{block}[\s.>]", text, re.I):
            checks.append({
                "id": block.lower(),
                "label": f"Bloc {block}",
                "status": "SUCCESS",
                "detail": None,
            })
        else:
            blocking |= _structure_check(
                checks, block.lower(), f"Bloc {block}", "FAILED", "absent",
                block=True)

    wfc = any(
        re.search(rf"<{prefix}[\s.>]", text, re.I)
        for prefix in _WFC_BLOCK_PREFIXES
    )
    blocking |= _structure_check(
        checks, "wfc", "Fonctions d'onde (PP_CHI / PP_PSWFC)",
        "SUCCESS" if wfc else "FAILED",
        None if wfc else "aucun bloc d'onde trouvé", block=not wfc)

    ptype = detect_pseudo_type(text)
    header_type = (_attr(text, "pseudo_type") or "").strip().upper()
    if header_type in ("SL",):
        header_type = "NC"
    if header_type in ("NC", "US", "PAW") and header_type != ptype:
        checks.append({
            "id": "pseudo_type",
            "label": "Cohérence type NC/US/PAW",
            "status": "WARNING",
            "detail": f"déclaré {header_type}, détecté {ptype}",
        })
    else:
        checks.append({
            "id": "pseudo_type",
            "label": "Type NC/US/PAW",
            "status": "SUCCESS",
            "detail": ptype,
        })

    if ptype in ("US", "PAW"):
        if re.search(r"<PP_AUGMENTATION[\s.>]", text, re.I):
            checks.append({
                "id": "augmentation",
                "label": "Bloc PP_AUGMENTATION (US/PAW)",
                "status": "SUCCESS",
                "detail": None,
            })
        else:
            blocking |= _structure_check(
                checks, "augmentation", "Bloc PP_AUGMENTATION (US/PAW)",
                "FAILED", "requis pour US/PAW", block=True)

    betas = len(_parse_projectors(text))
    n_decl = None
    np_ = _attr(text, "number_of_proj")
    if np_:
        try:
            n_decl = int(str(np_).split()[0])
        except ValueError:
            n_decl = None
    if n_decl is not None and betas and n_decl != betas:
        checks.append({
            "id": "n_proj",
            "label": "number_of_proj vs PP_BETA",
            "status": "WARNING",
            "detail": f"déclaré {n_decl}, trouvé {betas}",
        })
    elif betas:
        checks.append({
            "id": "n_proj",
            "label": "Nombre de projecteurs PP_BETA",
            "status": "SUCCESS",
            "detail": str(betas),
        })
    else:
        checks.append({
            "id": "n_proj",
            "label": "Projecteurs PP_BETA",
            "status": "WARNING",
            "detail": "non analysables (UPF v1 ou bloc absent)",
        })

    element = _attr(text, "element")
    checks.append({
        "id": "element",
        "label": "Élément (PP_HEADER)",
        "status": "SUCCESS" if element else "WARNING",
        "detail": element,
    })

    zv = _attr(text, "z_valence")
    checks.append({
        "id": "z_valence",
        "label": "z_valence",
        "status": "SUCCESS" if zv else "WARNING",
        "detail": zv,
    })

    raw_func = _attr(text, "functional")
    input_dft = normalize_dft(raw_func)
    if input_dft:
        checks.append({
            "id": "xc",
            "label": "Fonctionnelle XC → input_dft QE",
            "status": "SUCCESS",
            "detail": f"{(raw_func or '').strip()[:48]} → {input_dft}",
        })
    elif raw_func:
        checks.append({
            "id": "xc",
            "label": "Fonctionnelle XC → input_dft QE",
            "status": "WARNING",
            "detail": f"non mappée : {raw_func.strip()[:60]}",
        })
    else:
        checks.append({
            "id": "xc",
            "label": "Fonctionnelle XC",
            "status": "WARNING",
            "detail": "attribut functional absent — QE utilisera celle du UPF",
        })

    checks.append({
        "id": "sha256",
        "label": "Empreinte SHA-256",
        "status": "SUCCESS",
        "detail": sha,
    })

    statuses = [c["status"] for c in checks if c["id"] != "sha256"]
    if any(s == "FAILED" for s in statuses):
        overall = "FAILED"
    elif any(s == "WARNING" for s in statuses):
        overall = "WARNING"
    else:
        overall = "SUCCESS"

    return {
        "status": overall,
        "version": version,
        "sha256": sha,
        "pseudo_type": ptype,
        "input_dft": input_dft,
        "checks": checks,
        "blocking": blocking,
    }


# ---------------------------------------------------------------------------
# Description du pseudo : rc et électrons de valence (affichée si le test réussit)
# ---------------------------------------------------------------------------

# Tableau périodique compact (symboles, H → Og).
_ELEMENTS = ("H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar "
             "K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr "
             "Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe "
             "Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu "
             "Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn "
             "Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr "
             "Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og").split()
_Z_OF = {sym: i + 1 for i, sym in enumerate(_ELEMENTS)}

# Ordre d'occupation (règle de Madelung / Aufbau) : (n, l, capacité).
_AUFBAU = (
    (1, 0, 2), (2, 0, 2), (2, 1, 6), (3, 0, 2), (3, 1, 6), (4, 0, 2),
    (3, 2, 10), (4, 1, 6), (5, 0, 2), (4, 2, 10), (5, 1, 6), (6, 0, 2),
    (4, 3, 14), (5, 2, 10), (6, 1, 6), (7, 0, 2), (5, 3, 14), (6, 2, 10),
    (7, 1, 6),
)
_L_SYM = {0: "s", 1: "p", 2: "d", 3: "f"}


def _neutral_config(z):
    """Configuration électronique de l'atome neutre (règle d'Aufbau)."""
    z = int(z or 0)
    cfg = []
    rest = z
    for n, l, cap in _AUFBAU:
        if rest <= 0:
            break
        occ = min(cap, rest)
        cfg.append((n, l, occ))
        rest -= occ
    return cfg


def _expected_valence(z):
    """Couches de valence attendues pour l'atome de numéro atomique ``z``.

    Règle chimique : l'occupation Aufbau se termine par la dernière couche
    remplie ; les couches qui participent à la liaison sont
    ``ns`` (bloc s), ``ns + np`` (bloc p), ``(n-1)d + ns`` (bloc d) ou
    ``ns + (n-1)f`` (bloc f). Les demi-couches plus profondes (sémicore) sont
    facultatives.
    """
    cfg = _neutral_config(z)
    if not cfg:
        return []
    last_n, last_l, _ = cfg[-1]
    if last_l == 0:
        wanted = [(last_n, 0)]
    elif last_l == 1:
        wanted = [(last_n, 0), (last_n, 1)]
    elif last_l == 2:
        wanted = [(last_n + 1, 0), (last_n, 2)]
    else:  # bloc f : 4f/5f + 6s/7s
        wanted = [(last_n + 2, 0), (last_n, 3)]
    occ_map = {(n, l): occ for n, l, occ in cfg}
    return [(n, l, occ_map.get((n, l), 0)) for n, l in wanted]


def _shell_name(n, l):
    return f"{int(n)}{_L_SYM.get(int(l), '?')}"


_TAG_ATTRS = re.compile(r'([A-Za-z_][\w.-]*)\s*=\s*"([^"]*)"')
_WFC_TAG = re.compile(r"<(PP_CHI|PP_ATOMIC_WFC)(?:\.\d+)?\s+([^>]*)>", re.I)
_BETA_TAG = re.compile(r"<PP_BETA(?:\.\d+)?\s+([^>]*)>", re.I)


def _tag_attrs(fragment):
    return {k.lower(): v.strip() for k, v in _TAG_ATTRS.findall(fragment or "")}


def _num(value):
    try:
        return float(str(value).strip().replace("D", "E").replace("d", "e"))
    except (TypeError, ValueError):
        return None


def _parse_valence_orbitals(text):
    """``PP_CHI`` / ``PP_ATOMIC_WFC`` : orbitales de valence du pseudo."""
    out = []
    for m in _WFC_TAG.finditer(text or ""):
        a = _tag_attrs(m.group(2))
        label = (a.get("label") or a.get("wfc") or "").strip()
        l = _num(a.get("l"))
        n = None
        ml = re.match(r"(\d+)\s*([spdf])", label, re.I)
        if ml:
            # Le numéro de couche est porté par l'étiquette ("3S", "4S"…) :
            # l'attribut UPF ``n`` compte les orbitales par canal l et ne vaut
            # donc pas le nombre quantique principal.
            n = float(ml.group(1))
        if l is None and ml:
            l = "spdf".index(ml.group(2).lower())
        if n is None:
            n = _num(a.get("n"))
        occ = _num(a.get("occupation"))
        out.append({
            "label": label or (_shell_name(n, l) if n is not None and l is not None else "?"),
            "n": int(n) if n is not None else None,
            "l": int(l) if l is not None else None,
            "shell": _shell_name(n, l) if n is not None and l is not None else None,
            "occupation": occ,
            "rc": _num(a.get("cutoff_radius")),
        })
    return out


def _parse_projectors(text):
    """``PP_BETA`` : projecteurs non-locaux et leur rayon de coupure rc."""
    out = []
    for m in _BETA_TAG.finditer(text or ""):
        a = _tag_attrs(m.group(1))
        l = _num(a.get("angular_momentum") or a.get("l"))
        label = (a.get("label") or "").strip()
        out.append({
            "label": label or ("l=%d" % int(l) if l is not None else "?"),
            "l": int(l) if l is not None else None,
            "rc": _num(a.get("cutoff_radius")),
        })
    return out


def describe_pseudo(upf_path):
    """Description physique d'un UPF : rc et électrons de valence.

    Vérifie que les types d'électrons attendus dans la valence (s / p / d / f de
    la couche externe de l'atome neutre) sont bien présents dans le pseudo, et
    que la somme des occupations vaut ``z_valence``. Retourne un dict destiné à
    l'affichage (niveau ``description`` du résultat).
    """
    upf_path = Path(upf_path)
    try:
        text = upf_text(upf_path)
    except OSError:
        return None

    meta = parse_upf_meta(upf_path)
    symbol = (meta.get("element") or "").strip().capitalize()
    z = _Z_OF.get(symbol) or _Z_OF.get(symbol.upper())

    orbitals = _parse_valence_orbitals(text)
    projectors = _parse_projectors(text)

    # --- rc : rayon de coupure par canal (projecteurs) ---------------------
    rc_channels = []
    seen = set()
    for b in projectors:
        if b["rc"] is None:
            continue
        key = (b["l"], round(b["rc"], 4))
        if key in seen:
            continue
        seen.add(key)
        rc_channels.append({"label": b["label"], "l": b["l"], "rc": b["rc"]})
    rc_channels.sort(key=lambda c: (c["l"] if c["l"] is not None else 9, c["rc"]))
    rc_values = [c["rc"] for c in rc_channels]

    # --- valence : occupation trouvée vs attendue --------------------------
    occupied = [o for o in orbitals if (o["occupation"] or 0) > 0]
    found_shells = {(o["n"], o["l"]) for o in occupied
                    if o["n"] is not None and o["l"] is not None}
    z_from_orbitals = round(sum(o["occupation"] for o in occupied), 6)

    expected = _expected_valence(z) if z else []
    expected_shells = {(n, l) for n, l, _ in expected}
    missing = [_shell_name(n, l) for n, l in sorted(expected_shells - found_shells)]
    extra = sorted({_shell_name(n, l) for n, l in found_shells - expected_shells})

    z_target = meta.get("z_valence")
    z_ok = (z_target is None or abs(z_from_orbitals - float(z_target)) < 0.05)

    # Un 4f/5f absent d'un lантанide/actinide est normal : pseudo « f-in-core ».
    f_only_missing = bool(missing) and all(m.endswith("f") for m in missing)
    status = "OK"
    problems = []
    if missing and not f_only_missing:
        status = "ATTENTION"
        problems.append("couches de valence attendues absentes : " + ", ".join(missing))
    if not z_ok:
        status = "ATTENTION"
        problems.append(
            f"somme des occupations ({z_from_orbitals:g}) ≠ z_valence "
            f"({z_target:g})" if z_target is not None else
            f"somme des occupations ({z_from_orbitals:g})")
    if not orbitals:
        status = "ATTENTION"
        problems.append("aucune orbite atomique (PP_CHI) décrite dans le UPF")

    notes = []
    if f_only_missing:
        notes.append("" + ", ".join(missing) + " absent(e) : pseudo probablement "
                     "« f-in-core » (la couche f est congelée dans le cœur) — normal.")
    if missing and not f_only_missing:
        notes.append("Ces électrons sont nécessaires à la liaison : le pseudo est "
                     "incomplet pour cet élément.")
    # Occupation : écarts de répartition (ex. 3d⁵4s¹ vs 3d⁴4s²) sans gravité.
    exp_map = {_shell_name(n, l): occ for n, l, occ in expected}
    for o in occupied:
        sh = o.get("shell")
        if sh in exp_map and o["occupation"] is not None \
                and abs(o["occupation"] - exp_map[sh]) > 0.05:
            notes.append(
                f"occupation du pseudo {sh}={o['occupation']:g} e⁻ vs "
                f"{exp_map[sh]:g} e⁻ (Aufbau) : répartition de spin classique, "
                "sans incidence sur la validité.")

    expected_str = " ".join(f"{_shell_name(n, l)}{occ:g}" for n, l, occ in expected)
    found_str = " ".join(
        f"{o['shell'] or o['label']}{o['occupation']:g}" for o in occupied)

    if status == "OK":
        message = (f"Valence conforme à l'atome neutre {symbol} "
                   f"(Z={z}) : {found_str or '—'}"
                   + (f", attendu {expected_str}" if expected_str else "")
                   + (f" · demi-couches sémicore incluses : {', '.join(extra)}"
                      if extra else "") + ".")
    else:
        message = "Valence à vérifier : " + "; ".join(problems) + "."

    explanation = (
        "Les électrons de valence sont ceux qui restent explicitement dans le "
        "calcul ; les couches plus profondes sont congelées dans le cœur car leur "
        "recouvrement est négligeable. Leur type (s/p/d/f) et leur nombre doivent "
        "correspondre à la configuration de l'atome : "
        + (f"{expected_str} pour {symbol}" if expected_str else "configurations externes ns/(n-1)d/ns np")
        + ". Un type manquant rend le pseudo inutilisable pour cet élément ; "
        "des demi-couches sémicore supplémentaires (ex. 3p pour Fe) sont un choix "
        "volontaire pour décrire les atomes condensés."
    )

    rc_explanation = (
        "rc (rayon de coupure, en bohr) : au-delà de rc le pseudo suit exactement "
        "le potentiel réel, en deçà il est lissé pour supprimer les oscillations du "
        "cœur. Un rc petit → pseudo « dur » (ecut plus élevé, coût de calcul plus "
        "grand) ; un rc grand → pseudo « doux » mais moins transférable et plus "
        "sensible aux états fantômes (ghosts)."
    )

    struct = None
    try:
        struct = validate_upf_structure(upf_path)
    except Exception:
        struct = None

    return {
        "file": upf_path.name,
        "symbol": symbol,
        "z": z,
        "element": meta.get("element"),
        "pseudo_type": meta.get("pseudo_type"),
        "generator": meta.get("generator"),
        "dft": meta.get("dft"),
        "dft_raw": meta.get("dft_raw"),
        "z_valence": meta.get("z_valence"),
        "l_max": meta.get("l_max"),
        "number_of_proj": meta.get("number_of_proj"),
        "rel": meta.get("rel"),
        "structure_sha256": (struct or {}).get("sha256"),
        "upf_version": (struct or {}).get("version"),
        "rc": {
            "channels": rc_channels,
            "orbitals": [{"label": o["label"], "shell": o["shell"], "rc": o["rc"]}
                         for o in orbitals if o["rc"] is not None],
            "max": max(rc_values) if rc_values else None,
            "unit": "bohr",
        },
        "rc_explanation": rc_explanation,
        "valence": {
            "orbitals": orbitals,
            "expected": [{"shell": _shell_name(n, l), "occupation": occ}
                          for n, l, occ in expected],
            "expected_str": expected_str,
            "found_str": found_str,
            "z_from_orbitals": z_from_orbitals,
            "z_ok": z_ok,
            "missing": missing,
            "extra": extra,
            "status": status,
            "problems": problems,
            "message": message,
            "explanation": explanation,
            "notes": notes,
        },
    }


def make_params(pseudo_type, overrides=None):
    """Construit le jeu de paramètres SCF (ecutrho recalculé si besoin).

    ``overrides`` peut contenir ecutwfc, ecutrho, celldm, mixing_beta,
    electron_maxstep, conv_thr, smearing, degauss, occupations, input_dft.
    Un ``ecutrho`` valant ``None`` est ignoré et recalculé depuis ecutwfc.
    """
    params = {
        "ecutwfc": _PW_DEFAULTS["ecutwfc"],
        "celldm": _PW_DEFAULTS["celldm"],
        "mixing_beta": _PW_DEFAULTS["mixing_beta"],
        "electron_maxstep": _PW_DEFAULTS["electron_maxstep"],
        "conv_thr": _PW_DEFAULTS["conv_thr"],
        "smearing": _PW_DEFAULTS["smearing"],
        "degauss": _PW_DEFAULTS["degauss"],
        "occupations": _PW_DEFAULTS["occupations"],
        "input_dft": _PW_DEFAULTS["input_dft"],
    }
    ecutrho = None
    if overrides:
        for key, value in overrides.items():
            if value is None:
                continue
            params[key] = value
        if overrides.get("ecutrho") is not None:
            ecutrho = overrides["ecutrho"]
    if ecutrho is None:
        ecutrho = recommended_ecutrho(pseudo_type, params["ecutwfc"])
    params["ecutrho"] = float(ecutrho)
    return params


def render_pw_input(name, params):
    """Texte d'un input pw.x SCF « atome isolé » (réutilisable tel quel)."""
    dft = params.get("input_dft")
    dft_line = f"\n  input_dft = '{dft}'" if dft else ""
    return f"""&CONTROL
  calculation = 'scf'
  restart_mode = 'from_scratch'
  pseudo_dir = '.'
  outdir = '.'
  tprnfor = .true.
  tstress = .false.
  disk_io = 'low'
/
&SYSTEM
  ibrav = 1
  celldm(1) = {float(params['celldm']):.4f}
  nat = 1
  ntyp = 1
  ecutwfc = {float(params['ecutwfc']):.6f}
  ecutrho = {float(params['ecutrho']):.6f}
  occupations = '{params['occupations']}'
  smearing = '{params['smearing']}'
  degauss = {float(params['degauss']):.4f}{dft_line}
/
&ELECTRONS
  conv_thr = {float(params['conv_thr']):.1e}
  mixing_beta = {float(params['mixing_beta'])}
  electron_maxstep = {int(params['electron_maxstep'])}
/
ATOMIC_SPECIES
  X  1.0  {name}
ATOMIC_POSITIONS (angstrom)
  X  0.0  0.0  0.0
K_POINTS automatic
  1 1 1  0 0 0
PSEUDOPOTENTIAL
  {name}
"""


def build_pw_input(upf, work_dir, params):
    """Écrit l'input pw.x du test atome isolé dans ``work_dir``.

    Retourne (input_text, input_path, out_path, pseudo_path_in_work).
    """
    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)

    name = Path(upf).stem
    inp = work / f"{name}.pw.in"
    out = work / f"{name}.pwo"

    pseudo_abs = work / name
    p = Path(upf)
    if p.is_file():
        shutil.copy(p, pseudo_abs)

    input_text = render_pw_input(name, params)
    _write_output(inp, input_text)
    return input_text, str(inp), str(out), str(pseudo_abs)


_ITER_RE = re.compile(r"iteration #\s*(\d+)")


def _tail_text(path, max_bytes=20000):
    """Lit la fin d'un fichier (pour suivre un calcul en cours)."""
    p = Path(path)
    if not p.is_file():
        return ""
    try:
        size = p.stat().st_size
        with p.open("rb") as fh:
            if size > max_bytes:
                fh.seek(size - max_bytes)
            return fh.read().decode("utf-8", "ignore")
    except OSError:
        return ""


def _latest_iteration(path):
    """Dernière itération SCF visible dans la sortie pw.x (None si pas encore)."""
    tail = _tail_text(path)
    hits = _ITER_RE.findall(tail)
    if hits:
        return int(hits[-1])
    if re.search(r"Self-consistent Calculation", tail):
        return 0
    return None


def _terminate_tree(proc, grace=5.0):
    """Tue pw.x et toute sa descendance (groupe de session) sans orphelin."""
    try:
        pgid = os.getpgid(proc.pid)
    except Exception:
        pgid = None
    for sig in (signal.SIGTERM, signal.SIGKILL):
        if pgid is not None and pgid != os.getpgid(0):
            try:
                os.killpg(pgid, sig)
            except Exception:
                pass
        try:
            proc.send_signal(sig)
        except Exception:
            pass
        try:
            proc.wait(timeout=grace)
            return
        except Exception:
            continue


def run_pw_x(input_path, output_path, pseudo_dest=None, timeout=None, tick_cb=None,
             tick_interval=2.0, pw_executable=None):
    """Lance pw.x et GARANTIT l'arrêt au timeout (aucun processus fantôme).

    ``tick_cb(iteration, elapsed_s)`` est appelée périodiquement pendant le
    calcul : elle permet à l'interface d'afficher l'itération SCF en cours au
    lieu d'un « en cours » muet. ``pw_executable`` force le binaire utilisé
    (niveaux 3/4, qui peuvent viser un pw.x par générateur).
    """
    timeout = float(timeout or _DEFAULT_PW_TIMEOUT)
    pw_bin = pw_executable or _PW_X
    try:
        fh = open(output_path, "w")
    except OSError:
        return -2, output_path
    try:
        proc = subprocess.Popen(
            [pw_bin, "-in", input_path],
            stdout=fh,
            stderr=subprocess.STDOUT,
            cwd=str(Path(output_path).parent),
            start_new_session=True,
        )
    except Exception:
        fh.close()
        return -2, output_path

    start = time.perf_counter()
    rc = None
    try:
        while True:
            try:
                rc = proc.wait(timeout=tick_interval)
                break
            except subprocess.TimeoutExpired:
                elapsed = time.perf_counter() - start
                if elapsed >= timeout:
                    _terminate_tree(proc)
                    rc = -1
                    break
                if tick_cb is not None:
                    try:
                        tick_cb(_latest_iteration(output_path), elapsed)
                    except Exception:
                        pass
    finally:
        try:
            fh.close()
        except Exception:
            pass
    return rc, output_path


def analyze_scf_output(out_path):
    """Analyse un output pw.x SCF (atome isolé).

    Retourne un dict niveau 1 avec un code exploitable par le diagnostic :
    ``code`` ∈ {OK, TIMEOUT, NON_CONVERGED, NO_CONVERGENCE, UNSTABLE, MEMORY,
    PW_ERROR, NO_OUTPUT}.
    """
    text, ok = _read_output(out_path)
    if not ok or text is None:
        return {
            "status": "ERROR",
            "code": "NO_OUTPUT",
            "cause": "Fichier de sortie pw.x introuvable.",
            "solution": "Vérifiez le binaire pw.x (PW_BIN / QE_BIN_DIR).",
        }

    # Convergence et itérations
    conv_match = re.search(r"convergence has been achieved in\s+(\d+)\s+iterations", text, re.I)
    max_iter_match = re.search(r"reached the maximum number of scf cycles", text, re.I)
    iters = [int(m) for m in re.findall(r"iteration #\s*(\d+)", text)]
    n_iter = max(iters) if iters else 0

    # Énergie totale
    energy_match = re.search(r"!\s*total energy\s*=\s*([-+]?\d+\.\d+)\s*ry", text, re.I)
    energy = float(energy_match.group(1)) if energy_match else None

    # Dernière variation
    delta_match = re.search(r"delta e \(time-step\):\s*([-+]?\d+\.?\d*(?:[eEdD][-+]?\d+)?)", text, re.I)
    delta_e = None
    if delta_match:
        try:
            delta_e = float(delta_match.group(1).replace("D", "E").replace("d", "e"))
        except ValueError:
            pass

    # Drapeaux d'erreur
    memory_fail = bool(re.search(
        r"insufficient virtual memory|not enough memory|failed to allocate|out of memory",
        text, re.I))
    unstable = bool(re.search(
        r"floating point exception|segmentation fault|forrtl|Backtrace|\bNaN\b",
        text, re.I))
    pw_error = re.search(r"Error in routine\s+(\S+)", text, re.I)
    fermi_warn = bool(re.search(r"Minimization algorithm failed to find Fermi energy", text, re.I))
    negative_rho = bool(re.search(r"negative rho", text, re.I))
    job_done = bool(re.search(r"JOB DONE", text))

    details = {
        "iterations": n_iter,
        "delta_e_last": delta_e,
        "fermi_fallback": fermi_warn,
        "negative_rho": negative_rho,
        "job_done": job_done,
    }

    def _out(status, code, cause, solution=None):
        return {
            "status": status,
            "code": code,
            "cause": cause,
            "solution": solution,
            "energy": energy,
            "delta_e": delta_e,
            "converged": bool(conv_match),
            "details": details,
        }

    if memory_fail and not conv_match:
        return _out(
            "FAILED", "MEMORY",
            "pw.x a manqué de mémoire (grille de charge trop fine pour la RAM disponible).",
            "Réduire ecutrho / ecutwfc ou la boîte de test.",
        )

    if unstable:
        return _out(
            "FAILED", "UNSTABLE",
            "Calcul pw.x instable (NaN / exception flottante / segfault détecté).",
            "Augmenter ecutwfc / ecutrho et les rayons de coupure rc du générateur.",
        )

    if pw_error and not conv_match:
        return _out(
            "FAILED", "PW_ERROR",
            f"pw.x s'est arrêté sur une erreur ({pw_error.group(1)}).",
            "Augmenter ecutwfc / ecutrho et vérifier le fichier UPF.",
        )

    if conv_match:
        cause = f"SCF convergé en {conv_match.group(1)} itération(s)."
        if energy is not None:
            cause += f" Énergie totale {energy:.6f} Ry."
        if fermi_warn:
            cause += " (repli de bisection sur l'énergie de Fermi — sans gravité ici.)"
        return _out("SUCCESS", "OK", cause)

    if max_iter_match:
        return _out(
            "FAILED", "NON_CONVERGED",
            f"SCF non convergé après {n_iter} itérations (charge sloshing / cutoff trop bas).",
            "Ralentir mixing_beta, élargir degauss et/ou augmenter ecutwfc.",
        )

    return _out(
        "FAILED", "NO_CONVERGENCE",
        "pw.x s'est arrêté sans convergence ni énergie totale.",
        "Augmenter ecutwfc / ecutrho et vérifier l'intégrité du fichier UPF.",
    )


def diagnose_failure(level1, meta=None, params=None):
    """Traduit le code d'échec en diagnostic lisible + actions de correction."""
    code = (level1 or {}).get("code")
    if not code:
        status = (level1 or {}).get("status", "").upper()
        code = "NON_CONVERGED" if status == "FAILED" else "UNKNOWN"
    explanation, actions = _DIAGNOSIS.get(
        code, ((level1 or {}).get("cause") or "Cause indéterminée.", [])
    )
    return {
        "code": code,
        "explanation": explanation,
        "actions": list(actions),
        "raw_cause": (level1 or {}).get("cause"),
    }


def remediation_ladder(pseudo_type, base_params):
    """Étapes de correction successives, motivées physiquement."""
    ecut = float(base_params.get("ecutwfc") or _PW_DEFAULTS["ecutwfc"])
    cell = float(base_params.get("celldm") or _PW_DEFAULTS["celldm"])
    return [
        {
            "label": "mélange ralenti + smearing élargi",
            "reason": "Charge sloshing d'un métal en grande boîte : un mélange plus "
                      "doux et un smearing plus large stabilisent l'occupation.",
            "overrides": {
                "mixing_beta": 0.1,
                "degauss": 0.03,
                "smearing": "gaussian",
            },
        },
        {
            "label": "cutoffs augmentés ×1,5",
            "reason": "Représentation insuffisante du pseudo à ecutwfc trop bas "
                      "(aliasing de la densité).",
            "overrides": {
                "ecutwfc": round(ecut * 1.5, 1),
                "mixing_beta": 0.1,
                "electron_maxstep": 200,
            },
        },
        {
            "label": "boîte élargie ×1,25 + mélange très doux",
            "reason": "Isolation insuffisante de l'atome isolé / convergence difficile.",
            "overrides": {
                "celldm": round(cell * 1.25, 2),
                "mixing_beta": 0.05,
                "electron_maxstep": 250,
                "degauss": 0.04,
            },
        },
    ]


def _find_nearby_log(upf_path: Path, basename: str):
    """Recherche un journal à côté du UPF ou dans le répertoire parent."""
    base = Path(upf_path)
    for parent in [base, base.parent, base.parent.parent]:
        cand = parent / basename
        if cand.is_file():
            return cand
    return None


def _find_log(upf_path: Path, basename: str, roots=None):
    """Cherche un journal de génération :

    1. à côté du UPF ;
    2. dans les répertoires fournis (bibliothèques par générateur, éventuellement
       leurs sous-dossiers ``runs`` / ``_runs``).
    """
    found = _find_nearby_log(upf_path, basename)
    if found:
        return found
    for root in roots or []:
        root = Path(root)
        if not root.is_dir():
            continue
        for cand in (root / basename, root / "runs" / basename, root / "_runs" / basename):
            if cand.is_file():
                return cand
    return None


def _find_oncv_out(upf: Path, oncv_roots):
    """Trouve le rapport de génération ONCVPSP (.out).

    Les dispositions rencontrées sont variées : ``<stem>.out`` à côté du UPF,
    ou un arbre ``_runs/<Element>_<horodatage>/oncv_<Element>.out``. On essaie
    donc plusieurs motifs, du plus précis (nom du UPF) au plus souple
    (``oncv_<Element>.out``), dans chaque racine fournie.
    """
    if not oncv_roots:
        return None
    stem = Path(upf).stem
    element = re.split(r"[_\-. ]", stem)[0] or stem
    patterns = [f"{stem}.out", f"*{stem}*.out", f"oncv_{element}.out", f"oncv_{element}_*.out"]
    for root in oncv_roots:
        root = Path(root)
        if not root.is_dir():
            continue
        for sub in (root, root / "_runs", root / "runs", root / "_work"):
            if not sub.is_dir():
                continue
            for pat in patterns:
                hits = sorted(sub.glob(pat))
                if hits:
                    return hits[-1]
        # Dernier recours : recherche récursive dans la racine
        for pat in patterns:
            hits = sorted(root.rglob(pat))
            if hits:
                return hits[-1]
    return None


def _analyze_oncvpsp(out_path: Path):
    if not out_path or not out_path.is_file():
        return {
            "status": "SKIPPED",
            "cause": "Fichier de génération ONCVPSP (.out) introuvable.",
            "solution": "Placer le .out à côté du UPF ou régler ONCVPSP_OUT_ROOT.",
        }
    text, _ = _read_output(out_path)
    if not text:
        return {
            "status": "SKIPPED",
            "cause": "Fichier ONCVPSP vide ou illisible.",
            "solution": None,
        }
    cause_parts = []
    solution = None

    # Champs typiques de fin de run ONCVPSP
    final_energy = re.search(r"Total energy\s*[:=]\s*([-+]?\d+\.\d+)", text, re.I)
    ghost_hits = _ghost_hits(text)

    # Fin de run : ONCVPSP termine son rapport par ``END_PSP`` ; les autres
    # générateurs utilisent des mentions textuelles.
    finished = bool(re.search(
        r"END_PSP|RUN SUCCEEDED|Calculation finished|Normal termination", text, re.I))

    if ghost_hits:
        status = "WARNING"
        cause = "GHOST détecté dans le journal de génération."
        solution = "Ne pas utiliser ce pseudo en production ; revoir Ep / llocal."
    elif not finished:
        status = "WARNING"
        cause = "Le run de génération ONCVPSP n'a pas abouti (fichier tronqué ou terminé anormalement)."
        solution = "Relancer la génération du pseudo ou vérifier le .out."
    else:
        status = "SUCCESS"
        cause = "Aucun ghost signalé ; génération terminée correctement."
        if final_energy:
            cause += f" Énergie totale rapportée : {final_energy.group(1)} Ry."

    details = {}
    if final_energy:
        details["total_energy_reported"] = final_energy.group(1)
    if ghost_hits:
        details["ghost_hits"] = len(ghost_hits)
    details["finished"] = finished

    return {"status": status, "cause": cause, "solution": solution, "details": details}


def _analyze_ld1(ld1_path: Path):
    if not ld1_path or not ld1_path.is_file():
        return {
            "status": "SKIPPED",
            "cause": "ld1_run.log introuvable (à côté du UPF ou dans le répertoire générateur).",
            "solution": "Exécuter ld1.x avec iswitch=2 et placer le log à côté du UPF.",
        }
    text, _ = _read_output(ld1_path)
    if not text:
        return {"status": "SKIPPED", "cause": "ld1_run.log vide.", "solution": None}

    status = "SUCCESS"
    cause = "ld1.x exécuté sans anomalie majeure signalée."
    solution = None
    details = {}

    # On compte les WARNING et GHOST
    warnings = re.findall(r"\bWARNING\b", text, re.I)
    ghost = _ghost_hits(text)
    details["warning_count"] = len(warnings)
    details["ghost_hits"] = len(ghost)

    if ghost:
        status = "WARNING"
        cause = "GHOST signalé dans ld1_run.log."
        solution = "Revérifier Ep / llocal ; ne pas utiliser en production."
    elif len(warnings) > 0:
        status = "WARNING"
        cause = f"{len(warnings)} WARNING(s) dans ld1_run.log, sans ghost."
        solution = "Vérifier les avertissements dans le log ld1."

    der_match = re.search(r"derivlog\s*[:=]?\s*([-+]?\d+\.\d+)", text, re.I)
    if der_match:
        details["derivlog_value"] = der_match.group(1)

    return {"status": status, "cause": cause, "solution": solution, "details": details}


def _analyze_ape(ape_path: Path):
    if not ape_path or not ape_path.is_file():
        return {
            "status": "SKIPPED",
            "cause": "ape_run.log introuvable (section Ghost state analysis).",
            "solution": "Exécuter APE et conserver ape_run.log à côté du UPF.",
        }
    text, _ = _read_output(ape_path)
    if not text:
        return {"status": "SKIPPED", "cause": "ape_run.log vide.", "solution": None}

    status = "SUCCESS"
    cause = "Aucun ghost signalé dans ape_run.log."
    solution = None
    details = {}

    ghost_hits = _ghost_hits(text)
    details["ghost_hits"] = len(ghost_hits)

    ghost_section = re.search(r"Ghost state analysis", text, re.I)
    details["has_ghost_section"] = bool(ghost_section)

    if ghost_hits:
        status = "WARNING"
        cause = "GHOST détecté dans la section Ghost state analysis d'APE."
        solution = "Ne pas utiliser en production ; revoir les paramètres de génération."

    return {"status": status, "cause": cause, "solution": solution, "details": details}


def _analyze_atompaw(log_path: Path, results_path=None):
    if not log_path or not log_path.is_file():
        return {
            "status": "SKIPPED",
            "cause": "atompaw_run.log introuvable (avec logderiv.* si disponible).",
            "solution": "Exécuter ATOMPAW et conserver atompaw_run.log + logderiv.* à côté du UPF.",
        }

    text, _ = _read_output(log_path)
    if not text:
        return {"status": "SKIPPED", "cause": "atompaw_run.log vide.", "solution": None}

    status = "SUCCESS"
    cause = "ATOMPAW exécuté sans ghost signalé."
    solution = None
    details = {}

    ghost_hits = _ghost_hits(text)
    details["ghost_hits"] = len(ghost_hits)

    deriv_files = []
    if results_path:
        deriv_files = list(Path(results_path).glob(_LOGDERIV_GLOB))
    details["logderiv_files"] = [p.name for p in deriv_files]

    deriv_content = ""
    if deriv_files:
        try:
            deriv_content = Path(deriv_files[0]).read_text(errors="ignore")
        except OSError:
            pass
    deriv_ghost = _ghost_hits(deriv_content)

    if ghost_hits or deriv_ghost:
        status = "WARNING"
        cause = "GHOST détecté dans atompaw_run.log et/ou logderiv.*"
        solution = "Ne pas utiliser en production ; revoir les paramètres de génération (rc, llocal)."
        details["ghost_in_deriv"] = len(deriv_ghost)
    else:
        if not deriv_files:
            cause = "ATOMPAW exécuté sans ghost, mais aucun logderiv.* disponible."
            status = "WARNING"
            solution = "Recopier les fichiers logderiv.* pour une analyse plus complète."

    return {"status": status, "cause": cause, "solution": solution, "details": details}


def _level2_for(upf: Path, generator, oncv_search_roots, work_dir, run_level2):
    """Niveau 2 : analyse des logs/derivées."""
    if not run_level2:
        return None

    gen = (generator or "").lower()
    upf = Path(upf)

    if gen == "oncvpsp":
        # Test de ghost natif d'ONCVPSP : rapport .out existant, sinon
        # régénéré depuis l'input embarqué dans le UPF.
        native = _level2_via_generator(upf, "oncvpsp", oncv_search_roots, work_dir)
        if native is not None:
            return native
        oncv_out = _find_oncv_out(upf, oncv_search_roots)
        # aussi à côté du UPF
        if not oncv_out:
            local_out = upf.parent / (upf.stem + ".out")
            if local_out.is_file():
                oncv_out = local_out
        return _analyze_oncvpsp(oncv_out)

    if gen == "ld1":
        # Un journal fourni par l'utilisateur reste prioritaire.
        ld1_log = _find_log(upf, _LD1_LOG, oncv_search_roots)
        if ld1_log:
            return _analyze_ld1(ld1_log)
        # Sinon on exécute ld1.x nous-mêmes (iswitch=2 + test Bessel).
        return _run_ld1_level2(upf, work_dir)

    if gen == "ape":
        ape_log = _find_log(upf, "ape_run.log", oncv_search_roots)
        return _analyze_ape(ape_log)

    if gen == "atompaw":
        # Test de ghost du générateur : relance d'atompaw si nécessaire, puis
        # comparaison des dérivées logarithmiques (logderiv.<l>).
        native = _level2_via_generator(upf, "atompaw", oncv_search_roots, work_dir)
        if native is not None:
            return native
        atompaw_log = _find_log(upf, _ATOMPAW_LOG, oncv_search_roots)
        results_dir = atompaw_log.parent if atompaw_log else upf.parent
        return _analyze_atompaw(atompaw_log, results_path=results_dir)

    return {
        "status": "SKIPPED",
        "cause": f"Générateur non reconnu pour analyse niveau 2 : {gen or 'inconnu'}.",
        "solution": None,
    }


def _run_attempt(upf, work_dir, params, timeout, label=None, notes=None, tick_cb=None):
    """Une tentative SCF complète : construction de l'input, exécution, analyse."""
    input_text, inp_path, out_path, pseudo_dest = build_pw_input(upf, work_dir, params)
    t0 = time.perf_counter()
    rc, _out = run_pw_x(inp_path, out_path, pseudo_dest, timeout, tick_cb=tick_cb)
    runtime_s = round(max(0.0, time.perf_counter() - t0), 1)

    l1 = analyze_scf_output(out_path)
    if rc == -1:
        l1.update({
            "status": "FAILED",
            "code": "TIMEOUT",
            "cause": f"pw.x interrompu après {int(timeout)} s (timeout) — aucun résultat produit.",
            "solution": "Réduire ecutrho / ecutwfc ou augmenter PSEUDO_TEST_TIMEOUT.",
        })
    elif rc == -2:
        l1.update({
            "status": "ERROR",
            "code": "PW_MISSING",
            "cause": "Impossible d'exécuter pw.x (binaire introuvable ou erreur système).",
            "solution": "Régler PW_BIN / QE_BIN_DIR.",
        })
    elif rc != 0 and l1.get("code") == "OK":
        l1.update({
            "status": "WARNING",
            "code": "RC_NONZERO",
            "cause": "pw.x a retourné un code non nul malgré une convergence détectée.",
            "solution": "Vérifier les sorties standards de pw.x.",
        })

    try:
        input_hash = hashlib.sha256((input_text + "\n").encode("utf-8")).hexdigest()[:12]
    except Exception:
        input_hash = None

    keys = ("ecutwfc", "ecutrho", "celldm", "mixing_beta", "electron_maxstep",
            "conv_thr", "smearing", "degauss", "occupations", "input_dft")
    return {
        "label": label,
        "notes": notes,
        "params": {k: params[k] for k in keys if k in params},
        "level1": l1,
        "runtime_s": runtime_s,
        "returncode": rc,
        "input_path": inp_path,
        "out_path": out_path,
        "input_hash": input_hash,
    }


def _write_ready_bundle(ready_dir, upf, params, notes=None, suffix="", extra_files=None):
    """Écrit un dossier directement exploitable : UPF + input pw.x validé."""
    if not ready_dir:
        return None
    upf = Path(upf)
    try:
        out_dir = Path(ready_dir) / f"{upf.stem}{suffix}"
        out_dir.mkdir(parents=True, exist_ok=True)
        dest_upf = out_dir / f"{upf.stem}.UPF"
        if upf.is_file():
            shutil.copy(upf, dest_upf)
        inp = out_dir / "scf_atome_isole.in"
        header = (
            "# Input pw.x validé par Test_Pseudos (atome isolé — stabilité SCF)\n"
            "# Lancement :  pw.x -in scf_atome_isole.in > scf_atome_isole.out\n"
            f"# ecutwfc={params.get('ecutwfc')} Ry | ecutrho={params.get('ecutrho')} Ry | "
            f"mixing_beta={params.get('mixing_beta')} | smearing={params.get('smearing')} "
            f"(degauss={params.get('degauss')}) | celldm(1)={params.get('celldm')} bohr\n"
        )
        if notes:
            header += f"# Note : {notes}\n"
        _write_output(inp, header + render_pw_input(upf.stem, params))
        written = []
        for name, content in (extra_files or {}).items():
            try:
                p = out_dir / name
                _write_output(p, content)
                written.append(str(p))
            except OSError:
                pass
        return {
            "dir": str(out_dir),
            "input": str(inp),
            "upf": str(dest_upf),
            "extra": written,
        }
    except OSError:
        return None


PHASE_TOTAL = 5
_PHASE_LABELS = (
    "SCF (pw.x, atome isolé)",
    "Ghosts & dérivées logarithmiques",
    "EOS cristal (Birch-Murnaghan)",
    "Delta-test (jauge cutoff)",
    "Corrections",
)


def phase_label(numero: int) -> str:
    """Libellé de l'étape ``numero`` (1..5) du pipeline de validation."""
    if 1 <= numero <= len(_PHASE_LABELS):
        return _PHASE_LABELS[numero - 1]
    return f"étape {numero}"


def attach_test_report(
    description,
    *,
    verdict,
    original_upf,
    final_upf,
    structure,
    used_params,
    level1,
    correction=None,
    ghost_fix=None,
):
    """Enrichit la fiche pseudo avec le contexte du test (SCF, corrections, chemins)."""
    if not description:
        description = {}
    l1 = level1 or {}
    corr = correction or {}
    gf = ghost_fix or {}
    orig = Path(original_upf)
    final = Path(final_upf)
    same_file = orig.resolve() == final.resolve()

    description["test_report"] = {
        "verdict": verdict,
        "original_upf": str(orig),
        "original_name": orig.name,
        "final_upf": str(final),
        "final_name": final.name,
        "ghost_regenerated": bool(gf.get("succeeded") and gf.get("corrected_upf")),
        "scf_autocorrected": bool(corr.get("succeeded")),
        "correction_note": corr.get("note"),
        "ghost_note": gf.get("reason"),
        "parameters": {
            k: used_params[k]
            for k in (
                "ecutwfc", "ecutrho", "celldm", "mixing_beta",
                "electron_maxstep", "conv_thr", "smearing", "degauss",
                "occupations", "input_dft",
            )
            if used_params and k in used_params
        },
        "scf": {
            "status": l1.get("status"),
            "code": l1.get("code"),
            "energy_ry": l1.get("energy"),
            "iterations": (l1.get("details") or {}).get("iterations"),
            "converged": l1.get("converged"),
        },
        "structure": {
            "status": (structure or {}).get("status"),
            "version": (structure or {}).get("version"),
            "sha256": (structure or {}).get("sha256"),
        },
    }
    if not same_file:
        try:
            description["test_report"]["original_valence"] = (
                (describe_pseudo(orig) or {}).get("valence", {}).get("found_str")
            )
        except Exception:
            pass
    return description


def test_one_upf(
    upf,
    pw_executable=None,
    ld1_bin=None,
    work_dir=None,
    oncv_search_roots=None,
    run_level1=True,
    run_level2=True,
    run_level3=False,
    run_level4=False,
    auto_correct=None,
    ready_dir=None,
    tick_cb=None,
    phase_cb=None,
):
    """Validation d'un pseudo UPF pour l'API / le pipeline de test.

    La fonction est utilisée par le serveur web et par les scripts CLI. Elle est
    explicitement marquée comme non-collectable par pytest afin de ne pas être
    interprétée comme un test unitaire.
    """
    """Valide un UPF en trois étapes, puis corrige ce qui peut l'être.

    1. **SCF** — stabilité numérique ``pw.x`` sur atome isolé.
    2. **Ghosts** — niveau 2 : dérivées logarithmiques / états fantômes.
    3. **Corrections** — paramètres SCF corrigés et/ou pseudo régénéré sans
       ghost, puis validation du pseudo corrigé.

    ``phase_cb(numero, total, libelle)`` est appelée au début de chaque étape.
    """
    upf = Path(upf).expanduser()
    try:
        meta = parse_upf_meta(upf)
    except Exception:
        meta = {}

    try:
        structure = validate_upf_structure(upf)
    except Exception as exc:
        structure = {
            "status": "ERROR",
            "version": None,
            "sha256": None,
            "pseudo_type": None,
            "input_dft": None,
            "checks": [],
            "blocking": False,
            "error": str(exc),
        }

    work = _ensure_work_dir(work_dir)
    pseudo_type = structure.get("pseudo_type") or meta.get("pseudo_type") or "NC"
    timeout = recommended_timeout(pseudo_type)
    if auto_correct is None:
        auto_correct = _AUTOCORRECT

    dft_override = structure.get("input_dft") or meta.get("dft")
    overrides = {"input_dft": dft_override} if dft_override else None
    base_params = make_params(pseudo_type, overrides)

    def _phase(numero, label):
        if phase_cb is not None:
            try:
                phase_cb(numero, PHASE_TOTAL, label)
            except Exception:
                pass

    common = {
        "file": upf.name,
        "path": str(upf),
        "generator": meta.get("generator"),
        "element": meta.get("element"),
        "pseudo_type": pseudo_type,
        "dft": meta.get("dft"),
        "z_valence": meta.get("z_valence"),
        "l_max": meta.get("l_max"),
        "rel": meta.get("rel"),
        "number_of_proj": meta.get("number_of_proj"),
        "timeout_s": timeout,
        "structure": structure,
    }

    if structure.get("blocking"):
        try:
            common["description"] = describe_pseudo(upf)
        except Exception:
            common["description"] = None
        failed = [c for c in (structure.get("checks") or []) if c.get("status") == "FAILED"]
        detail = "; ".join(c.get("label", "") for c in failed[:4]) or "structure UPF"
        common.update({
            "verdict": "FAILED",
            "level1": {
                "status": "SKIPPED",
                "code": "UPF_STRUCTURE",
                "cause": f"Structure UPF invalide ({detail}).",
                "solution": "Corriger le fichier ou régénérer le pseudo avant tout calcul QE.",
            },
            "level2": {"status": "SKIPPED", "cause": "Structure UPF bloquante.",
                       "solution": None},
            "level3": None,
            "level4": None,
            "ecutwfc": base_params["ecutwfc"],
            "ecutrho": base_params["ecutrho"],
            "runtime_s": None,
            "input_hash": None,
            "diagnosis": {
                "code": "UPF_STRUCTURE",
                "explanation": "Le contrôle structurel bloque l'exécution de pw.x.",
                "actions": ["consulter le bloc Format UPF", "vérifier l'intégrité du fichier"],
            },
            "correction": {"applied": False, "succeeded": False, "attempts": [], "note": None},
            "ghost_fix": None,
            "ready": None,
            "attempts_count": 0,
        })
        try:
            common["description"] = attach_test_report(
                common.get("description"),
                verdict="FAILED",
                original_upf=upf,
                final_upf=upf,
                structure=structure,
                used_params=base_params,
                level1=common["level1"],
            )
        except Exception:
            pass
        return common

    # ---- Étape 1/3 : SCF ---------------------------------------------------
    _phase(1, "SCF (pw.x, atome isolé)")
    base = {
        "level1": {"status": "SKIPPED",
                   "cause": "Niveau 1 désactivé par l'utilisateur.",
                   "solution": None},
        "runtime_s": None,
        "input_hash": None,
    }
    try:
        if run_level1:
            base = _run_attempt(upf, work, base_params, timeout,
                                label="essai initial", tick_cb=tick_cb)
    except Exception as exc:
        common.update({
            "verdict": "ERROR",
            "level1": {
                "status": "ERROR", "code": "NO_OUTPUT",
                "cause": f"Échec de la préparation/exécution pw.x : {exc}",
                "solution": "Vérifier l'intégrité du fichier UPF.",
            },
            "level2": None,
            "level3": None,
            "level4": None,
            "ecutwfc": base_params["ecutwfc"],
            "ecutrho": base_params["ecutrho"],
            "runtime_s": None,
            "input_hash": None,
            "diagnosis": diagnose_failure({"code": "NO_OUTPUT"}),
            "correction": {"applied": False, "succeeded": False, "attempts": [], "note": None},
            "ready": None,
            "attempts_count": 1,
        })
        try:
            common["description"] = attach_test_report(
                common.get("description") or describe_pseudo(upf),
                verdict="ERROR",
                original_upf=upf,
                final_upf=upf,
                structure=structure,
                used_params=base_params,
                level1=common.get("level1"),
            )
        except Exception:
            pass
        return common

    l1 = base["level1"]
    runtime_s = base["runtime_s"]
    used_params = base_params
    correction = {"applied": False, "succeeded": False, "attempts": [], "note": None}

    # ---- Étape 2/3 : ghosts & dérivées logarithmiques ----------------------
    _phase(2, "Ghosts & dérivées logarithmiques")
    if run_level2:
        l2 = _level2_for(upf, meta.get("generator"), oncv_search_roots, str(work), run_level2)
    else:
        l2 = {"status": "SKIPPED", "cause": "Niveau 2 désactivé par l'utilisateur.", "solution": None}

    # ---- Niveau 3 : EOS cristal (consultatif) ------------------------------
    level3 = None
    if run_level3:
        _phase(3, "EOS cristal (Birch-Murnaghan)")
        level3 = _run_level3(upf, pw_executable, work, pseudo_type, base_params)

    # ---- Niveau 4 : delta-test (consultatif) -------------------------------
    level4 = None
    if run_level4:
        _phase(4, "Delta-test (jauge cutoff)")
        level4 = _run_level4(upf, pw_executable, work, pseudo_type, base_params)

    diagnosis = diagnose_failure(base["level1"])

    # ---- Étape 5/5 : corrections ------------------------------------------
    _phase(5, "Corrections")

    # a) ghost éliminé par régénération du générateur
    ghost_fix = None
    gen = (meta.get("generator") or "").lower()
    l2_details = (l2 or {}).get("details") or {}
    ghost_hits = l2_details.get("ghost_hits")
    if auto_correct and run_level2 and (l2 or {}).get("status") == "WARNING" and ghost_hits:
        if gen == "oncvpsp" and _fix_ghosts is not None:
            oncv_out = _find_oncv_out(upf, oncv_search_roots)
            if not oncv_out:
                local_out = upf.parent / (upf.stem + ".out")
                if local_out.is_file():
                    oncv_out = local_out
            if not oncv_out:
                # Rapport régénéré par le niveau 2 (test de ghost ONCVPSP).
                regen = l2_details.get("out_path")
                if regen and Path(regen).is_file():
                    oncv_out = Path(regen)
            if oncv_out:
                try:
                    ghost_fix = _fix_ghosts(upf, oncv_out, str(work))
                except Exception as exc:
                    ghost_fix = {
                        "applied": False, "succeeded": False, "attempts": [],
                        "reason": f"Échec de la correction du ghost : {exc}",
                    }
        elif gen in {"ld1", "ape", "atompaw"}:
            try:
                ghost_fix = _correct_ghosts_ld1_atompaw_upf(
                    upf,
                    ghost_l=l2_details.get("ghost_l"),
                    work_dir=str(work),
                    ld1_bin=ld1_bin,
                    max_attempts=_AUTOCORRECT_MAX,
                )
            except Exception as exc:
                ghost_fix = {
                    "applied": False, "succeeded": False, "attempts": [],
                    "reason": f"Échec de la correction du ghost ld1/APE/ATOMPAW : {exc}",
                }

    # b) paramètres SCF corrigés si le niveau 1 a échoué
    if l1.get("code") != "OK" and auto_correct:
        ladder = remediation_ladder(pseudo_type, base_params)[:_AUTOCORRECT_MAX]
        correction["applied"] = bool(ladder)
        fix_root = work / "_correction"
        for i, step in enumerate(ladder, 1):
            params = make_params(pseudo_type, step["overrides"])
            try:
                attempt = _run_attempt(
                    upf, fix_root / f"essai{i}", params, timeout,
                    label=step["label"], notes=step["reason"], tick_cb=tick_cb,
                )
            except Exception as exc:
                attempt = {
                    "label": step["label"], "notes": step["reason"],
                    "params": params, "runtime_s": None,
                    "level1": {"status": "ERROR", "code": "NO_OUTPUT",
                               "cause": str(exc), "solution": None},
                }
            correction["attempts"].append(attempt)
            if (attempt.get("level1") or {}).get("code") == "OK":
                correction["succeeded"] = True
                correction["note"] = (
                    f"Échec initial corrigé par « {step['label']} » : {step['reason']}"
                )
                l1 = attempt["level1"]
                runtime_s = attempt["runtime_s"]
                used_params = params
                break

    # c) validation du pseudo régénéré sans ghost, avec les paramètres retenus
    if (ghost_fix or {}).get("succeeded") and ghost_fix.get("corrected_upf"):
        try:
            fixed_work = work / "anti_ghost" / "validation_n1"
            vt = _run_attempt(
                Path(ghost_fix["corrected_upf"]), fixed_work,
                used_params, timeout, label="validation du pseudo corrigé",
                tick_cb=tick_cb,
            )
            ghost_fix["validation_n1"] = vt["level1"]
            ghost_fix["validation_runtime_s"] = vt["runtime_s"]
        except Exception as exc:
            ghost_fix["validation_error"] = str(exc)

    # Verdict global (SKIPPED au niveau 2 ne dégrade pas le verdict)
    l1_status = (l1 or {}).get("status")
    l2_status = (l2 or {}).get("status")
    if l1_status in ("FAILED", "ERROR") or l2_status in ("FAILED", "ERROR"):
        verdict = "FAILED"
    elif l1_status == "WARNING" or l2_status == "WARNING":
        verdict = "WARNING"
    elif l1_status == "SUCCESS":
        verdict = "SUCCESS"
    else:
        verdict = "WARNING"

    if structure.get("status") == "FAILED" and verdict == "SUCCESS":
        verdict = "WARNING"

    ready = None
    if l1_status == "SUCCESS":
        ready = _write_ready_bundle(
            ready_dir, upf, used_params,
            notes=correction.get("note") or "SCF convergé avec les paramètres par défaut.",
        )

    # Le pseudo régénéré sans ghost devient le livrable « prêt pour QE ».
    if (ghost_fix or {}).get("succeeded") and ghost_fix.get("corrected_upf"):
        fixed_ready = _write_ready_bundle(
            ready_dir, Path(ghost_fix["corrected_upf"]), used_params,
            notes=ghost_fix.get("reason"), suffix="_sans_ghost",
            extra_files={"oncvpsp_corrige.dat": ghost_fix.get("dat_text") or ""},
        )
        if fixed_ready:
            ghost_fix["ready"] = fixed_ready
            ready = fixed_ready

    final_upf = upf
    if (ghost_fix or {}).get("succeeded") and ghost_fix.get("corrected_upf"):
        final_upf = Path(ghost_fix["corrected_upf"])

    try:
        description = describe_pseudo(final_upf)
    except Exception:
        description = common.get("description")
    try:
        common["description"] = attach_test_report(
            description,
            verdict=verdict,
            original_upf=upf,
            final_upf=final_upf,
            structure=structure,
            used_params=used_params,
            level1=l1,
            correction=correction,
            ghost_fix=ghost_fix,
        )
    except Exception:
        common["description"] = description

    common.update({
        "verdict": verdict,
        "level1": l1,
        "level2": l2,
        "level3": level3,
        "level4": level4,
        "ecutwfc": used_params["ecutwfc"],
        "ecutrho": used_params["ecutrho"],
        "correction": correction,
        "diagnosis": diagnosis,
        "ghost_fix": ghost_fix,
        "ready": ready,
        "runtime_s": runtime_s,
        "input_hash": base.get("input_hash"),
        "attempts_count": 1 + len(correction["attempts"]),
        "structure": structure,
    })
    return common


test_one_upf.__test__ = False


def batch_test_directory(
    directory,
    pw_executable=None,
    ld1_bin=None,
    oncv_search_roots=None,
    work_dir=None,
    run_level1=True,
    run_level2=True,
    run_level3=False,
    run_level4=False,
    quiet=False,
    progress_cb=None,
    auto_correct=None,
    ready_dir=None,
    tick_cb=None,
    phase_cb=None,
):
    """Teste tous les UPF d'un répertoire.

    ``progress_cb(index, total, upf)`` est appelée avant chaque fichier pour
    permettre à l'appelant (API web) d'afficher l'avancement et d'éviter
    l'impression d'interface bloquée pendant un long lot.
    """
    work = _ensure_work_dir(work_dir)
    files = []
    dirpath = Path(directory)
    if not dirpath.is_dir():
        return []
    for p in sorted(set(dirpath.glob("*.UPF")) | set(dirpath.glob("*.upf"))):
        files.append(p)
    results = []
    total = len(files)
    for idx, upf in enumerate(files, 1):
        if progress_cb is not None:
            try:
                progress_cb(idx, total, upf)
            except Exception:
                pass
        upf_work = work / upf.stem
        upf_work.mkdir(parents=True, exist_ok=True)
        file_tick = None
        if tick_cb is not None:
            file_tick = (lambda it, el, _n=upf.name: tick_cb(_n, it, el))
        try:
            r = test_one_upf(
                upf,
                pw_executable=pw_executable,
                ld1_bin=ld1_bin,
                work_dir=str(upf_work),
                oncv_search_roots=oncv_search_roots,
                run_level1=run_level1,
                run_level2=run_level2,
                run_level3=run_level3,
                run_level4=run_level4,
                auto_correct=auto_correct,
                ready_dir=ready_dir,
                tick_cb=file_tick,
                phase_cb=phase_cb,
            )
        except Exception as exc:
            r = {
                "file": upf.name,
                "path": str(upf),
                "verdict": "ERROR",
                "level1": {"status": "ERROR", "cause": str(exc), "solution": "voir traceback"},
                "level2": None,
                "level3": None,
                "level4": None,
            }
        results.append(r)
        if not quiet:
            print(f"[{r.get('verdict')}] {r.get('file')} ({r.get('runtime_s')} s)")
    return results


# ---------------------------------------------------------------------------
# Niveaux 3 (EOS cristal) et 4 (delta-test) — blocs consultatifs
# ---------------------------------------------------------------------------

def _load_crystal_tests():
    """Charge le module des tests cristallins (EOS + delta), si disponible."""
    try:
        import crystal_tests  # noqa: WPS433
        return crystal_tests
    except Exception:
        pass
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "crystal_tests", Path(__file__).resolve().parent / "crystal_tests.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


def _run_level3(upf, pw_executable, work, pseudo_type, base_params):
    """Niveau 3 : EOS Birch-Murnaghan (consultatif, hors verdict)."""
    mod = _load_crystal_tests()
    fn = getattr(mod, "crystal_eos_test", None) if mod is not None else None
    if fn is None:
        return {
            "status": "ERROR",
            "code": "EOS_IMPORT",
            "cause": ("cannot import name 'crystal_eos_test' from "
                      "'crystal_tests' (module ou fonction indisponible)."),
            "solution": ("Vérifier la présence de engine/crystal_tests.py et de "
                         "sa fonction crystal_eos_test."),
            "structure": None,
        }
    params = dict(base_params or {})
    try:
        return fn(
            upf,
            pw_executable=pw_executable,
            work_dir=str(work),
            ecutwfc=params.get("ecutwfc"),
            ecutrho=params.get("ecutrho"),
        )
    except Exception as exc:
        return {
            "status": "ERROR",
            "code": "EOS_EXCEPTION",
            "cause": f"Échec du test EOS : {exc}",
            "solution": "Vérifier pw.x et les paramètres ecutwfc/ecutrho.",
            "structure": None,
        }


def _run_level4(upf, pw_executable, work, pseudo_type, base_params):
    """Niveau 4 : jauge delta (consultatif, hors verdict)."""
    mod = _load_crystal_tests()
    fn = getattr(mod, "delta_test", None) if mod is not None else None
    if fn is None:
        return {
            "status": "ERROR",
            "code": "DELTA_IMPORT",
            "cause": ("cannot import name 'delta_test' from 'crystal_tests' "
                      "(module ou fonction indisponible)."),
            "solution": ("Vérifier la présence de engine/crystal_tests.py et de "
                         "sa fonction delta_test."),
            "structure": None,
        }
    params = dict(base_params or {})
    try:
        return fn(
            upf,
            pw_executable=pw_executable,
            work_dir=str(work),
            ecutwfc=params.get("ecutwfc"),
            ecutrho=params.get("ecutrho"),
        )
    except Exception as exc:
        return {
            "status": "ERROR",
            "code": "DELTA_EXCEPTION",
            "cause": f"Échec du delta-test : {exc}",
            "solution": "Vérifier pw.x et les paramètres ecutwfc/ecutrho.",
            "structure": None,
        }


# ---------------------------------------------------------------------------
# Correction automatique des ghosts pour ld1 / APE / ATOMPAW
# ---------------------------------------------------------------------------

_RC_ROW = re.compile(
    r"^(\s*)(\d+)(\s+)([\d.]+)(\s+)([\d.]+)(\s+\d+\s+\d+\s+)([\d.]+)(\s*)$")
_RC_TAG = re.compile(r"^(\s*<rc>\s*)([\d.]+)(\s*</rc>\s*)$", re.I)


def _bump_rc_text(text, factor, qcut_factor=0.90, channels=None):
    """Élargit les rayons de coupure ``rc`` d'un input de génération.

    Gère les lignes « l rc ep ncon nbas qcut » (ld1/ONCVPSP) et les balises
    ATOMPAW ``<rc> ... </rc>``. Retourne ``(texte, changements)``.
    """
    changes = []
    out = []
    for line in (text or "").splitlines():
        m = _RC_ROW.match(line)
        if m and (not channels or int(m.group(2)) in channels):
            l = int(m.group(2))
            rc = float(m.group(4))
            new_rc = rc * factor
            new_qcut = float(m.group(8)) * qcut_factor
            out.append(f"{m.group(1)}{l}{m.group(3)}{new_rc:.2f}{m.group(5)}"
                       f"{m.group(6)}{m.group(7)}{new_qcut:.2f}{m.group(9)}")
            changes.append({"l": l, "rc_old": rc, "rc_new": round(new_rc, 3)})
            continue
        t = _RC_TAG.match(line)
        if t:
            old = float(t.group(2))
            new = old * factor
            out.append(f"{t.group(1)}{new:.2f}{t.group(3)}")
            changes.append({"l": None, "rc_old": old, "rc_new": round(new, 3)})
            continue
        out.append(line)
    return "\n".join(out) + "\n", changes


def _extract_upf_text(text):
    """Extrait le UPF (XML) d'une sortie de générateur."""
    m = re.search(r"<UPF\b.*?</UPF>", text or "", re.S | re.I)
    return (m.group(0).rstrip() + "\n") if m else None


def _ghost_free_check(upf, gen):
    """Revérifie l'absence de ghost avec le test du générateur d'origine."""
    try:
        l2 = _level2_for(Path(upf), gen, None, str(Path(upf).parent), True)
    except Exception as exc:
        return False, f"vérification impossible : {exc}"
    status = (l2 or {}).get("status")
    hits = ((l2 or {}).get("details") or {}).get("ghost_hits")
    if hits:
        return False, f"ghost encore présent : {hits}"
    if status in ("SUCCESS", "SKIPPED"):
        return True, f"niveau 2 {status}"
    return False, (l2 or {}).get("cause") or f"niveau 2 {status}"


def _correct_ghosts_ld1_atompaw_upf(upf, ghost_l=None, work_dir=None,
                                    ld1_bin=None, timeout=None,
                                    max_attempts=None):
    """Corrige un ghost d'un pseudo ld1/APE/ATOMPAW par régénération.

    Le générateur est relancé sur l'input embarqué (``PP_INPUTFILE``) en
    élargissant ``rc`` des canaux signalés (facteurs 1.15 → 1.75, ``qcut``
    réduit de 10 %). Le UPF produit n'est retenu que si le test de ghost du
    générateur redevient propre ; chaque essai est tracé dans ``attempts``.
    """
    result = {
        "applied": False, "succeeded": False, "attempts": [],
        "reason": None, "corrected_upf": None, "generator": None,
    }
    upf = Path(upf)
    if not upf.is_file():
        result["reason"] = f"UPF introuvable : {upf}."
        return result
    try:
        gen = (parse_upf_meta(upf).get("generator") or "").lower()
    except Exception:
        gen = ""
    result["generator"] = gen
    if gen not in ("ld1", "ape", "atompaw"):
        result["reason"] = (f"Générateur « {gen or 'inconnu'} » : seuls "
                            "ld1/APE/ATOMPAW sont corrigés par régénération.")
        return result

    text = upf.read_text(errors="ignore")
    src = None
    if _gen_ghost is not None:
        try:
            src = _gen_ghost.embedded_input(text)
        except Exception:
            src = None
    if not src:
        result["reason"] = ("Aucun input de génération embarqué "
                            "(PP_INPUTFILE absent) : régénération impossible.")
        return result

    binary = None
    if gen == "atompaw" and _gen_ghost is not None:
        try:
            binary = _gen_ghost.atompaw_bin()
        except Exception:
            binary = None
    if binary is None:
        cand = ld1_bin or os.environ.get("LD1_BIN") or "ld1.x"
        binary = cand if (Path(cand).is_file() or shutil.which(cand)) else None
    if not binary:
        result["reason"] = "Binaire du générateur (ld1.x/atompaw.x) introuvable."
        return result

    work = _ensure_work_dir(Path(work_dir or upf.parent) / "_ghost_fix_ld1")
    channels = set(ghost_l or [])
    timeout = float(timeout or os.environ.get("PSEUDO_TEST_TIMEOUT", "600"))
    factors = (1.15, 1.30, 1.50, 1.75)[:max(1, int(max_attempts or 3))]
    result["applied"] = True
    last = None
    for factor in factors:
        new_src, changes = _bump_rc_text(src, factor, channels=channels)
        if not changes:
            result["reason"] = ("Aucun rayon de coupure rc exploitable dans "
                                "l'input embarqué.")
            return result
        attempt = {"factor": factor, "changes": changes}
        try:
            proc = subprocess.run(
                [binary], input=new_src, capture_output=True, text=True,
                timeout=timeout, cwd=str(work))
            out = (proc.stdout or "") + (proc.stderr or "")
            (work / f"regen_{factor:.2f}.out").write_text(out, errors="ignore")
        except Exception as exc:
            attempt["status"] = "RUN_FAILED"
            attempt["cause"] = str(exc)
            result["attempts"].append(attempt)
            last = attempt
            break
        new_upf = _extract_upf_text(out)
        if not new_upf:
            attempt["status"] = "NO_UPF"
        else:
            cand = work / f"{upf.stem}_rc{factor:.2f}.UPF"
            cand.write_text(new_upf)
            attempt["status"] = "GENERATED"
            attempt["upf"] = str(cand)
            clean, why = _ghost_free_check(cand, gen)
            attempt["ghost_free"] = clean
            attempt["check"] = why
            if clean:
                attempt["status"] = "GHOST_FIXED"
                result.update({
                    "succeeded": True,
                    "corrected_upf": str(cand),
                    "reason": (f"Ghost corrigé par régénération {gen} "
                               f"(rc × {factor:.2f}) : {why}."),
                })
                result["attempts"].append(attempt)
                return result
        result["attempts"].append(attempt)
        last = attempt

    result["reason"] = (
        "Régénération tentée sans succès : le ghost subsiste après "
        f"élargissement de rc (dernier essai : {(last or {}).get('status')}).")
    return result


def cli_main(argv=None):
    """Point d'entrée CLI : python engine/test_pseudos.py [--run-level2 0/1] [--run-level3 0/1] [--run-level4 0/1] [--oncv-root R] [--work-dir D] <dir|upf>..."""
    import argparse
    ap = argparse.ArgumentParser(description="Validation UPF (pw.x + niveaux 2/3/4 générateur)")
    ap.add_argument("targets", nargs="+", help="répertoire ou fichiers .UPF")
    ap.add_argument("--run-level1", type=int, default=1, choices=(0, 1), help="activer le niveau 1 (SCF)")
    ap.add_argument("--run-level2", type=int, default=1, choices=(0, 1), help="activer le niveau 2")
    ap.add_argument("--run-level3", type=int, default=0, choices=(0, 1), help="activer le niveau 3 (EOS cristal)")
    ap.add_argument("--run-level4", type=int, default=0, choices=(0, 1), help="activer le niveau 4 (delta-test)")
    ap.add_argument("--oncv-root", action="append", default=os.environ.get("ONCVPSP_OUT_ROOT"))
    ap.add_argument("--work-dir", default=None)
    ap.add_argument("--ready-dir", default=os.environ.get("PSEUDO_READY_DIR"))
    ap.add_argument("--auto-correct", type=int, default=1 if _AUTOCORRECT else 0, choices=(0, 1))
    ap.add_argument("--pw-bin", default=os.environ.get("PW_BIN", "pw.x"))
    ap.add_argument("--ld1-bin", default=os.environ.get("LD1_BIN", "ld1.x"))
    args = ap.parse_args(argv)

    roots = []
    if args.oncv_root:
        roots.extend(args.oncv_root)

    results = []
    for t in args.targets:
        p = Path(t).expanduser()
        if p.is_dir():
            batch = batch_test_directory(
                p,
                pw_executable=args.pw_bin,
                ld1_bin=args.ld1_bin,
                oncv_search_roots=[Path(r) for r in roots] if roots else None,
                work_dir=args.work_dir,
                run_level1=bool(args.run_level1),
                run_level2=bool(args.run_level2),
                run_level3=bool(args.run_level3),
                run_level4=bool(args.run_level4),
                quiet=False,
                auto_correct=bool(args.auto_correct),
                ready_dir=args.ready_dir,
            )
            results.extend(batch)
        elif p.is_file():
            r = test_one_upf(
                p,
                pw_executable=args.pw_bin,
                ld1_bin=args.ld1_bin,
                work_dir=args.work_dir,
                oncv_search_roots=[Path(r) for r in roots] if roots else None,
                run_level1=bool(args.run_level1),
                run_level2=bool(args.run_level2),
                run_level3=bool(args.run_level3),
                run_level4=bool(args.run_level4),
                auto_correct=bool(args.auto_correct),
                ready_dir=args.ready_dir,
            )
            results.append(r)
            print(f"[{r.get('verdict')}] {r.get('file')} ({r.get('runtime_s')} s)")
    print("\nRésultats :")
    from collections import Counter
    counts = Counter(r.get("verdict") for r in results)
    for k in ("SUCCESS", "WARNING", "FAILED", "ERROR", "SKIPPED"):
        print(f"  {k}: {counts.get(k, 0)}")
    return results


if __name__ == "__main__":
    cli_main()

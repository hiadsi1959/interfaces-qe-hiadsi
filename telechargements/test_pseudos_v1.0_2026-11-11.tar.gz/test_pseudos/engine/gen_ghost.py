#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Niveau 2 « générateur d'origine » — test de ghost natif.

``ld1.x`` ne sait lire que les UPF de maille ``atomic`` (il rejette les mailles
ONCVPSP / ATOMPAW par « mesh not supported »). Pour ces pseudos, le guide
demande le test de ghost du **générateur d'origine**. C'est ce module.

ONCVPSP
-------
``oncvpsp.x`` exécute lui-même deux tests et les imprime dans son rapport :

    Testing for bound ghosts
      n   l    E NL Schr. Eq   E Basis Diag.   E Cutoff
    Testing for highly-localized positive-energy ghosts
        l    <radius>/rc     E Basis Diag.   E Cutoff
        0        0.413055       49.100929     20.47  WARNING - GHOST(+)

Les UPF ONCVPSP embarquent leur input de génération dans ``<PP_INPUTFILE>`` :
si le rapport ``.out`` n'est pas disponible, on le **régénère** en relançant
``oncvpsp.x`` sur cet input, puis on relève les ``WARNING - GHOST(+/-)``.
Régénérer est fidèle : le pseudo reproduit est identique (mêmes ``mesh_size``,
``rc`` de projecteurs, écarts AE/PS ~1e-6 Ha) — vérifié.

ATOMPAW
-------
ATOMPAW ne publie **aucun verdict automatique** de ghost (la routine
``checkghosts`` de ses sources n'est jamais appelée). Son test de ghost est la
comparaison des dérivées logarithmiques, qu'il écrit dans ``logderiv.<l>`` :

    E(Ha)   d(ln u_AE)/dr   d(ln u_PS)/dr   atan_AE   atan_PS

Un **état lié supplémentaire** du pseudo (donc un ghost) se manifeste par un
pôle — saut de π de ``arctan(dérivée logarithmique)`` — présent dans la courbe
PS et absent de la courbe AE. On relance donc ``atompaw`` sur son
``atompaw.in`` (retrouvé à côté du UPF ou dans ``_runs/<El>_<horodatage>/``)
pour régénérer ces fichiers, puis on compare les pôles.

Le critère retenu est **conservateur** : seuls les pôles du pseudo situés
**sous le niveau du vide (E < 0)**, c'est-à-dire de vrais états liés
supplémentaires, sont signalés. Les pôles à énergie positive (résonances, où
la détection est peu fiable) sont rapportés à titre indicatif, jamais comme
verdict. ATOMPAW n'offrant pas de verdict, ``logderiv.*`` est livré pour
inspection visuelle.
"""

from __future__ import annotations

import html
import math
import os
import re
import shutil
import subprocess
import textwrap
import time
from pathlib import Path

PI = math.pi

# Ha -> Ry (le reste de l'application raisonne en Ry)
HA_TO_RY = 2.0

_ONCVPSP_TIMEOUT = float(os.environ.get("ONCVPSP_TIMEOUT", "600"))
_ATOMPAW_TIMEOUT = float(os.environ.get("ATOMPAW_TIMEOUT", "600"))

# Marge de recoïncidence de deux pôles (Ha) — la grille des dérivées
# logarithmiques a un pas de (Emax-Emin)/(n-1), typiquement 0.05 Ha.
_POLE_MATCH_HA = 0.12
# Amplitude minimale d'un saut d'arctan pour parler de pôle (fraction de π).
_POLE_JUMP_FRAC = 0.80


# ---------------------------------------------------------------------------
# Binaires des générateurs
# ---------------------------------------------------------------------------
def _first_bin(candidates):
    for cand in candidates:
        if not cand:
            continue
        p = Path(cand)
        if p.is_file() and os.access(p, os.X_OK):
            # Chemin absolu : le générateur tourne avec cwd = répertoire de travail.
            return str(p.resolve())
        which = shutil.which(cand)
        if which:
            return which
    return None


def _generator_candidates(name: str):
    """Emplacements connus des binaires de ``generation_pseudos``."""
    roots = [
        os.environ.get("GENERATION_PSEUDOS_ROOT"),
        str(Path.home() / "generation_pseudos"),
    ]
    out = []
    for root in roots:
        if root:
            out.append(str(Path(root) / "bin" / name))
    return out


def oncvpsp_bin():
    return _first_bin([
        os.environ.get("ONCVPSP_BIN"),
        *_generator_candidates("oncvpsp.x"),
        str(Path.home() / ".local" / "bin" / "oncvpsp.x"),
        "oncvpsp.x", "oncvpsp",
    ])


def atompaw_bin():
    return _first_bin([
        os.environ.get("ATOMPAW_BIN"),
        *_generator_candidates("atompaw"),
        str(Path.home() / "generation_pseudos" / "third_party" / "atompaw" / "src" / "atompaw"),
        "atompaw",
    ])


def _run_binary(binary: str, stdin_path: Path, stdout_path: Path, work: Path,
                timeout: float):
    """Lance un générateur, entrée sur stdin, sortie/fusion dans un fichier."""
    work.mkdir(parents=True, exist_ok=True)
    t0 = time.perf_counter()
    try:
        with open(stdin_path, "r") as fin, open(stdout_path, "w") as fout:
            proc = subprocess.run(
                [binary], stdin=fin, stdout=fout, stderr=subprocess.STDOUT,
                cwd=str(work), timeout=timeout, start_new_session=True,
            )
        rc = proc.returncode
    except subprocess.TimeoutExpired:
        return None, f"interrompu après {int(timeout)} s (timeout)"
    except OSError as exc:
        return None, f"non exécutable : {exc}"
    runtime = round(time.perf_counter() - t0, 1)
    text = stdout_path.read_text(errors="ignore") if stdout_path.is_file() else ""
    if rc != 0:
        return text, f"code de retour {rc} après {runtime} s"
    return text, None


# ---------------------------------------------------------------------------
# ONCVPSP
# ---------------------------------------------------------------------------
def embedded_input(upf_text: str):
    """Input de génération embarqué dans le UPF (``<PP_INPUTFILE>``)."""
    m = re.search(r"<PP_INPUTFILE>(.*?)</PP_INPUTFILE>", upf_text or "", re.S | re.I)
    if not m:
        return None
    body = html.unescape(m.group(1))
    # Le bloc est indenté dans le XML : on retire l'indentation **commune**
    # (textwrap.dedent) sans toucher à l'alignement relatif des colonnes, que
    # certaines lignes d'ONCVPSP utilisent (champs collés type « ts117.00 »).
    text = textwrap.dedent(body).strip("\n") + "\n"
    return text if text.strip() else None


def find_oncv_out(upf: Path, roots=None):
    """Rapport de génération ONCVPSP (``.out``) associé à un UPF."""
    upf = Path(upf)
    for parent in (upf.parent, upf.parent.parent):
        for name in (f"{upf.stem}.out", f"{upf.stem}.ONCVPSP.out"):
            cand = parent / name
            if cand.is_file():
                return cand
    stem, element = upf.stem, (re.split(r"[_\-. ]", upf.stem)[0] or upf.stem)
    patterns = [f"{stem}.out", f"*{stem}*.out", f"oncv_{element}.out",
                f"oncv_{element}_*.out", f"*{element}*.out"]
    for root in roots or []:
        root = Path(root)
        if not root.is_dir():
            continue
        for sub in (root, root / "_runs", root / "runs", root / "_work"):
            if not sub.is_dir():
                continue
            for pat in patterns:
                hits = sorted(sub.glob(pat))
                if hits:
                    return hits[-1]
        for pat in patterns:
            hits = sorted(root.rglob(pat))
            if hits:
                return hits[-1]
    return None


_GHOST_POS = re.compile(
    r"^\s*(\d+)\s+([\d.]+)\s+([-+]?\d+\.\d+)\s+([\d.]+)\s+WARNING\s*-\s*GHOST\(\+\)",
    re.M | re.I)
_GHOST_NEG = re.compile(
    r"^\s*(\d+)\s+([-+]?\d+\.\d+)\s+([\d.]+)\s+WARNING\s*-\s*GHOST\(-\)",
    re.M | re.I)
_BOUND_ROW = re.compile(
    r"^\s*(\d+)\s+(\d+)\s+([-+]?\d+\.\d+)\s+([-+]?\d+\.\d+)\s+([\d.]+)\s*$", re.M)


def parse_oncvpsp_ghosts(text: str):
    """Relève les tests de ghost natifs d'un rapport ONCVPSP.

    Retourne ``{negative, positive, bound_states, tested}`` ; les énergies sont
    converties en Ry (ONCVPSP les imprime en Ha).
    """
    text = text or ""
    negative, positive = [], []

    for m in _GHOST_NEG.finditer(text):
        negative.append({
            "l": int(m.group(1)),
            "e_ry": round(float(m.group(2)) * HA_TO_RY, 6),
            "e_ha": float(m.group(2)),
            "ecut_ry": round(float(m.group(3)) * HA_TO_RY, 4),
        })
    for m in _GHOST_POS.finditer(text):
        positive.append({
            "l": int(m.group(1)),
            "rayon_sur_rc": float(m.group(2)),
            "e_ry": round(float(m.group(3)) * HA_TO_RY, 6),
            "e_ha": float(m.group(3)),
            "ecut_ry": round(float(m.group(4)) * HA_TO_RY, 4),
        })

    bound_states = []
    if "Testing for bound ghosts" in text:
        block = text.split("Testing for bound ghosts", 1)[1]
        block = block.split("Testing for highly-localized", 1)[0]
        for m in _BOUND_ROW.finditer(block):
            bound_states.append({
                "n": int(m.group(1)), "l": int(m.group(2)),
                "e_schrodinger_ry": round(float(m.group(3)) * HA_TO_RY, 6),
                "e_basis_ry": round(float(m.group(4)) * HA_TO_RY, 6),
                "ecut_ry": round(float(m.group(5)) * HA_TO_RY, 4),
            })

    tested = ("Testing for bound ghosts" in text
              and "Testing for highly-localized" in text)
    return {
        "negative": negative,
        "positive": positive,
        "bound_states": bound_states,
        "tested": tested,
        "n_ghosts": len(negative) + len(positive),
    }


def _oncv_level2_from_text(text: str, out_path, source: str, details=None):
    det = dict(details or {})
    parsed = parse_oncvpsp_ghosts(text)
    det.update({
        "generator": "oncvpsp",
        "test": "oncvpsp_natif",
        "out_path": str(out_path) if out_path else None,
        "out_source": source,
        "ghost_hits": parsed["n_ghosts"],
        "ghosts_negatifs": parsed["negative"],
        "ghosts_positifs": parsed["positive"],
        "etats_lies_ae_ps": parsed["bound_states"],
        "finished": "END_PSP" in text,
    })

    if not parsed["tested"]:
        return {
            "status": "SKIPPED",
            "cause": "Le rapport ONCVPSP ne contient pas les tests de ghost "
                     "natifs (« Testing for bound ghosts » / "
                     "« ... positive-energy ghosts »).",
            "solution": "Régénérer le rapport avec ONCVPSP 4.0 ou plus récent.",
            "details": det,
            "log": det.get("out_path"),
        }

    if parsed["n_ghosts"]:
        liste = []
        for g in parsed["negative"]:
            liste.append(f"GHOST(−) l={g['l']} à {g['e_ry']:.3f} Ry")
        for g in parsed["positive"]:
            liste.append(f"GHOST(+) l={g['l']} à {g['e_ry']:.3f} Ry "
                         f"(<r>/rc={g['rayon_sur_rc']:.3f}, "
                         f"Ecut={g['ecut_ry']:.1f} Ry)")
        return {
            "status": "WARNING",
            "cause": "Le test de ghost d'ONCVPSP signale "
                     + ("un état fantôme : " if parsed["n_ghosts"] == 1
                        else f"{parsed['n_ghosts']} états fantômes : ")
                     + " ; ".join(liste) + ".",
            "solution": "Ne pas utiliser ce pseudo en production ; élargir le "
                        "rayon de coupure rc du canal concerné (et réduire son "
                        "qcut), puis régénérer avec oncvpsp.x.",
            "details": det,
            "log": det.get("out_path"),
        }

    n_lie = len(parsed["bound_states"])
    return {
        "status": "SUCCESS",
        "cause": "Les deux tests de ghost d'ONCVPSP ne signalent aucun état "
                 f"fantôme ; {n_lie} état(s) lié(s) apparié(s) tout-électron "
                 "vs base de Bessel.",
        "solution": None,
        "details": det,
        "log": det.get("out_path"),
    }


def level2_oncvpsp(upf, roots=None, work_dir=None, timeout=None):
    """Niveau 2 d'un UPF ONCVPSP via le test de ghost natif du générateur."""
    upf = Path(upf)
    timeout = timeout or _ONCVPSP_TIMEOUT
    det_base = {"generator": "oncvpsp", "test": "oncvpsp_natif"}

    out_path = find_oncv_out(upf, roots)
    if out_path:
        text = out_path.read_text(errors="ignore")
        return _oncv_level2_from_text(text, out_path, "rapport existant",
                                      details=det_base)

    # Pas de rapport : on régénère depuis l'input embarqué dans le UPF.
    if not upf.is_file():
        return {"status": "SKIPPED", "cause": f"UPF introuvable : {upf}.",
                "solution": None, "details": det_base}

    dat_text = embedded_input(upf.read_text(errors="ignore"))
    if not dat_text:
        return {
            "status": "SKIPPED",
            "cause": "Rapport ONCVPSP (.out) introuvable et le UPF n'embarque "
                     "pas son input de génération (<PP_INPUTFILE>) : "
                     "impossible de relancer le test de ghost du générateur.",
            "solution": "Placer le .out à côté du UPF ou régler "
                        "ONCVPSP_OUT_ROOT.",
            "details": det_base,
        }

    binary = oncvpsp_bin()
    if not binary:
        return {
            "status": "SKIPPED",
            "cause": "Rapport ONCVPSP (.out) introuvable et oncvpsp.x est "
                     "introuvable pour le régénérer.",
            "solution": "Régler ONCVPSP_BIN (ou installer oncvpsp.x) ; sinon "
                        "placer le .out à côté du UPF.",
            "details": det_base,
        }

    work = Path(work_dir) if work_dir else Path(upf.parent) / "_oncvpsp_level2"
    # Noms alignés sur ce qu'ONCVPSP utilise : le stem du ``.out`` doit
    # correspondre à celui du ``.dat`` pour que la correction automatique des
    # ghosts (ghost_fix.find_oncv_dat) retrouve l'input de régénération.
    dat_path = work / (f"{upf.stem}.dat")
    out_new = work / (f"{upf.stem}.out")
    work.mkdir(parents=True, exist_ok=True)
    dat_path.write_text(dat_text, encoding="utf-8")

    text, err = _run_binary(binary, dat_path, out_new, work, timeout)
    det = dict(det_base, regenerated=True, oncvpsp_bin=binary,
               dat_path=str(dat_path))

    if err or not text:
        return {
            "status": "SKIPPED",
            "cause": f"La régénération du rapport ONCVPSP a échoué ({err}).",
            "solution": "Vérifier l'input embarqué dans le UPF et ONCVPSP_BIN.",
            "details": det,
            "log": str(out_new) if out_new.is_file() else None,
        }
    if "Testing for bound ghosts" not in text:
        return {
            "status": "SKIPPED",
            "cause": "La régénération ONCVPSP n'a pas produit les tests de "
                     "ghost (input incomplet ou version trop ancienne).",
            "solution": "Fournir le .out d'origine à côté du UPF.",
            "details": det,
            "log": str(out_new),
        }
    return _oncv_level2_from_text(text, out_new, "régénéré depuis le UPF",
                                  details=det)


# ---------------------------------------------------------------------------
# ATOMPAW
# ---------------------------------------------------------------------------
def element_of(upf: Path) -> str:
    """Symbole chimique lu dans le nom du UPF (``Gd.GGA-PBE-paw`` -> ``Gd``)."""
    stem = Path(upf).stem
    m = re.match(r"([A-Z][a-z]?)\b", stem)
    return (m.group(1) if m else stem.split("_")[0]).lower()


def _element_matches(upf: Path, directory: Path) -> bool:
    """Le répertoire concerne-t-il bien l'élément du UPF ?

    Indispensable : ``_runs/`` contient un sous-dossier par élément, et
    prendre celui d'un autre élément produirait un verdict faux.
    """
    el = element_of(upf)
    if not el:
        return False
    name = directory.name.lower()
    return bool(re.match(rf"{re.escape(el)}([_.\- ]|$)", name))


def _find_existing_atompaw_results(upf: Path, roots=None):
    """(journal, fichiers logderiv.*) déjà présents, pour l'élément du UPF."""
    upf = Path(upf)
    for parent in (upf.parent, upf.parent.parent):
        deriv = sorted(parent.glob("logderiv.*"))
        if deriv:
            log = parent / "atompaw_run.log"
            return (log if log.is_file() else None), deriv
    for root in roots or []:
        root = Path(root)
        if not root.is_dir():
            continue
        for hit in sorted(root.rglob("logderiv.0")):
            d = hit.parent
            if not _element_matches(upf, d):
                continue
            deriv = sorted(d.glob("logderiv.*"))
            log = d / "atompaw_run.log"
            return (log if log.is_file() else None), deriv
    return None, []


def find_atompaw_input(upf: Path, roots=None):
    """Fichier ``atompaw.in`` associé à un UPF ATOMPAW.

    Les UPF ATOMPAW **n'embarquent pas** leur input : il faut le retrouver à
    côté du UPF ou dans ``_runs/<El>_<horodatage>/``. Le nom du répertoire doit
    correspondre à l'élément du UPF — prendre l'input d'un autre élément
    produirait un pseudo différent, donc un verdict faux.
    """
    upf = Path(upf)
    for parent in (upf.parent, upf.parent.parent):
        for name in ("atompaw.in", f"{upf.stem}.atompaw.in"):
            cand = parent / name
            if cand.is_file():
                return cand
    for root in roots or []:
        root = Path(root)
        if not root.is_dir():
            continue
        for pat in ("atompaw.in", "*.atompaw.in"):
            for hit in sorted(root.rglob(pat)):
                if _element_matches(upf, hit.parent):
                    return hit
    return None


def parse_logderiv(path):
    """Lit un ``logderiv.<l>`` : ``[E, dlnu_AE/dr, dlnu_PS/dr, atan_AE, atan_PS]``.

    Retourne ``(lignes, n_non_finies)``. ATOMPAW imprime parfois
    ``-Infinity`` (dérivée logarithmique au voisinage d'un nœud placé
    exactement en ``r = r_c``) : ces lignes sont écartées et comptées.
    """
    rows, bad = [], 0
    for line in Path(path).read_text(errors="ignore").splitlines():
        parts = line.split()
        if len(parts) < 5:
            continue
        try:
            vals = [float(v) for v in parts[:5]]
        except ValueError:
            bad += 1
            continue
        if not all(math.isfinite(v) for v in vals):
            bad += 1
            continue
        rows.append(vals)
    return rows, bad


def channel_index(path):
    """Indice ``l`` d'un fichier ``logderiv.<l>``."""
    m = re.fullmatch(r"logderiv\.(\d+)", Path(path).name)
    return int(m.group(1)) if m else None


def _channel_usable(rows, raw_bad):
    """Les données d'un canal sont-elles exploitables ?

    Quand un nœud de l'onde PS tombe exactement sur ``r_c``, ATOMPAW imprime
    une dérivée logarithmique qui oscille et diverge : la détection de pôles
    n'a alors aucun sens. On refuse de conclure plutôt que de produire un
    faux ghost — constaté sur ``Ru.GGA-PBE-paw``.
    """
    if len(rows) < 20:
        return False, "moins de 20 points exploitables"
    if raw_bad:
        return False, f"{raw_bad} valeur(s) non finie(s)"
    for col, nom in ((2, "PS"), (1, "AE")):
        v = [r[col] for r in rows]
        flips = sum(1 for i in range(1, len(v)) if v[i] * v[i - 1] < 0.0)
        if flips > max(4, len(v) // 10):
            return False, (f"dérivée logarithmique {nom} instable "
                           f"({flips} changements de signe sur "
                           f"{len(v)} points)")
    return True, None


def _poles(derivative, energy):
    """Énergies des pôles d'une dérivée logarithmique (sauts de π de arctan)."""
    atans = [math.atan(v) for v in derivative]
    out = []
    for i in range(len(atans) - 1):
        if abs(atans[i + 1] - atans[i]) > _POLE_JUMP_FRAC * PI:
            out.append(round(0.5 * (energy[i] + energy[i + 1]), 3))
    return out


def analyze_logderiv_channel(rows, raw_bad=0):
    """Compare les pôles AE et PS d'un canal ``l``.

    Un état lié supplémentaire du pseudo (ghost) est un pôle **PS sous le
    niveau du vide (E < 0)** sans pôle AE correspondant.
    """
    usable, reason = _channel_usable(rows, raw_bad)
    info = {
        "exploitable": usable,
        "raison": reason,
        "n_points": len(rows),
        "poles_ae": [],
        "poles_ps": [],
        "ghosts_lies": [],
        "poles_ps_positifs": [],
        "etats_ae_non_reproduits": [],
    }
    if not usable:
        return info

    energy = [r[0] for r in rows]
    ae = _poles([r[1] for r in rows], energy)
    ps = _poles([r[2] for r in rows], energy)
    extra = [p for p in ps
             if not any(abs(p - q) <= _POLE_MATCH_HA for q in ae)]
    missing = [p for p in ae
               if not any(abs(p - q) <= _POLE_MATCH_HA for q in ps)]
    info.update({
        "poles_ae": ae,
        "poles_ps": ps,
        "ghosts_lies": [p for p in extra if p < 0.0],
        "poles_ps_positifs": [p for p in extra if p >= 0.0],
        "etats_ae_non_reproduits": missing,
    })
    return info


def _atompaw_level2_from_log(log_path, deriv_paths, source, details=None,
                             regenerated=False):
    det = dict(details or {})
    det.update({
        "generator": "atompaw",
        "test": "atompaw_logderiv",
        "log_path": str(log_path) if log_path else None,
        "log_source": source,
        "regenerated": regenerated,
        "logderiv_files": [Path(p).name for p in deriv_paths],
        "logderiv_dir": str(Path(deriv_paths[0]).parent) if deriv_paths else None,
    })

    if not deriv_paths:
        return {
            "status": "SKIPPED",
            "cause": "ATOMPAW n'a produit aucun fichier logderiv.<l> : "
                     "comparaison des dérivées logarithmiques impossible.",
            "solution": "Vérifier l'atompaw.in associé (bloc de dérivées "
                        "logarithmiques) et relancer le générateur.",
            "details": det,
            "log": str(log_path) if log_path else None,
        }

    channels, unusable = {}, {}
    for path in sorted(deriv_paths):
        l = channel_index(path)
        key = str(l) if l is not None else Path(path).name
        rows, bad = parse_logderiv(path)
        info = analyze_logderiv_channel(rows, bad)
        if info["exploitable"]:
            channels[key] = info
        else:
            unusable[key] = info["raison"]
    det["canaux"] = channels
    det["canaux_non_exploitables"] = unusable

    if not channels:
        return {
            "status": "SKIPPED",
            "cause": "Les dérivées logarithmiques produites par ATOMPAW sont "
                     "numériquement inexploitables pour tous les canaux ("
                     + "; ".join(f"l={k} : {v}" for k, v in unusable.items())
                     + ").",
            "solution": "Inspecter logderiv.* à la main ; un nœud du pseudo "
                        "tombe vraisemblablement sur r_c.",
            "details": det,
            "log": det.get("log_path"),
        }

    ghosts = []
    for l, info in channels.items():
        for e in info["ghosts_lies"]:
            ghosts.append({"l": l, "e_ha": e, "e_ry": round(e * HA_TO_RY, 6)})

    det["ghost_hits"] = len(ghosts)
    det["ghosts"] = ghosts
    # Les pôles à énergie positive sont des résonances : rapportés, jamais
    # utilisés comme verdict (détection peu fiable au-dessus du vide).
    det["poles_ps_positifs"] = {
        l: info["poles_ps_positifs"] for l, info in channels.items()
        if info["poles_ps_positifs"]
    }
    det["etats_ae_non_reproduits"] = {
        l: info["etats_ae_non_reproduits"] for l, info in channels.items()
        if info["etats_ae_non_reproduits"]
    }

    suffix = (" Rapport régénéré par atompaw."
              if regenerated else "")
    note = ("ATOPAW ne publie pas de verdict automatique : ce test est la "
            "comparaison des dérivées logarithmiques écrite par le générateur "
            "(logderiv.<l>).")
    caveat = ""
    if unusable:
        caveat = (" Attention : canal(aux) "
                  + ", ".join(f"l={k}" for k in unusable)
                  + " non exploitable(s) ("
                  + "; ".join(str(v) for v in unusable.values())
                  + ") — non testé(s) ici.")

    if ghosts:
        liste = ", ".join(f"l={g['l']} à {g['e_ry']:.3f} Ry" for g in ghosts)
        return {
            "status": "WARNING",
            "cause": f"État(s) lié(s) supplémentaire(s) du pseudo, sans "
                     f"contrepartie tout-électron : {liste}. " + note
                     + caveat + suffix,
            "solution": "Ne pas utiliser ce pseudo en production ; revoir les "
                        "rayons de coupure et la configuration de référence, "
                        "puis régénérer.",
            "details": det,
            "log": det.get("log_path"),
        }

    n_pos = sum(len(v) for v in det["poles_ps_positifs"].values())
    cause = ("Pôles des dérivées logarithmiques appariés AE/PS : aucun état "
             "lié supplémentaire du pseudo (pas de ghost). " + note)
    if n_pos:
        cause += (f" {n_pos} pôle(s) à énergie positive (résonance) "
                  "rapporté(s) sans conclure.")
    cause += caveat + suffix
    return {
        "status": "SUCCESS",
        "cause": cause,
        "solution": None,
        "details": det,
        "log": det.get("log_path"),
    }


def level2_atompaw(upf, roots=None, work_dir=None, timeout=None):
    """Niveau 2 d'un UPF ATOMPAW via le générateur d'origine."""
    upf = Path(upf)
    timeout = timeout or _ATOMPAW_TIMEOUT
    det_base = {"generator": "atompaw", "test": "atompaw_logderiv"}
    log_name = "atompaw_run.log"

    # 1) journal + logderiv.* déjà présents, pour CET élément
    log, deriv = _find_existing_atompaw_results(upf, roots)
    if deriv:
        return _atompaw_level2_from_log(log, deriv, "fichiers existants",
                                        details=det_base)

    # 2) sinon : on relance le générateur sur son atompaw.in
    inp = find_atompaw_input(upf, roots)
    if not inp:
        return {
            "status": "SKIPPED",
            "cause": "atompaw.in introuvable (les UPF ATOMPAW n'embarquent pas "
                     "leur input) : impossible de relancer le test de ghost du "
                     "générateur.",
            "solution": "Placer l'atompaw.in à côté du UPF ou régler "
                        "GENERATION_PSEUDOS_ROOT vers pseudos-atompaw.",
            "details": det_base,
        }

    binary = atompaw_bin()
    if not binary:
        return {
            "status": "SKIPPED",
            "cause": "atompaw.in trouvé mais le binaire atompaw est "
                     "introuvable.",
            "solution": "Régler ATOMPAW_BIN.",
            "details": dict(det_base, atompaw_input=str(inp)),
        }

    work = Path(work_dir) if work_dir else Path(upf.parent) / "_atompaw_level2"
    work.mkdir(parents=True, exist_ok=True)
    local_in = work / "atompaw.in"
    local_in.write_text(Path(inp).read_text(errors="ignore"), encoding="utf-8")
    out_log = work / log_name

    text, err = _run_binary(binary, local_in, out_log, work, timeout)
    det = dict(det_base, atompaw_input=str(inp), atompaw_bin=binary,
               regenerated=True)
    if err or text is None:
        return {
            "status": "SKIPPED",
            "cause": f"La relance d'atompaw a échoué ({err}).",
            "solution": "Vérifier l'atompaw.in associé.",
            "details": det,
            "log": str(out_log) if out_log.is_file() else None,
        }

    deriv = sorted(work.glob("logderiv.*"))
    return _atompaw_level2_from_log(out_log, deriv,
                                    "régénéré depuis atompaw.in",
                                    details=det, regenerated=True)

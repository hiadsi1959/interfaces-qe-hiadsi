#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Élimination des états fantômes (ghosts) d'un pseudopotentiel ONCVPSP.

ONCVPSP signale les ghosts dans son rapport de génération sous la forme
``WARNING - GHOST(+/-)``. Le remède standard est d'augmenter le rayon de
coupure ``rc`` du canal angulaire concerné (et de réduire son ``qcut``), puis
de régénérer le pseudopotentiel.

Ce module :

1. retrouve l'input de génération ``oncv_<El>.dat`` associé au UPF ;
2. relève les canaux ``l`` en ghost dans le rapport ``.out`` ;
3. augmente progressivement ``rc`` (et réduit ``qcut``) de ces canaux ;
4. relance ``oncvpsp.x`` et revérifie l'absence de ghost ;
5. renvoie le UPF corrigé et le rapport de ce qui a été fait.

Aucune correction n'est silencieuse : chaque essai est tracé (facteur appliqué,
durée, résultat) et le module s'arrête dès qu'un ghost subsiste au bout du
budget d'essais.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import time
from pathlib import Path

# Facteurs d'élargissement du rayon de coupure essayés successivement.
RC_FACTORS = (1.15, 1.30, 1.50, 1.75)
# Réduction corrélative de qcut (qcut trop grand favorise les ghosts).
QCUT_FACTOR = 0.90
DEFAULT_TIMEOUT = float(os.environ.get("ONCVPSP_TIMEOUT", "600"))
MAX_ATTEMPTS = int(os.environ.get("PSEUDO_TEST_GHOST_FIX_MAX", "4"))

_GHOST_LINE = re.compile(
    r"^\s*(\d+)\b[^\n]*?WARNING\s*-\s*GHOST\s*\(([+-])?\)", re.M | re.I)
_RC_HEADER = re.compile(r"l\s*,\s*rc\s*,\s*ep\s*,\s*ncon\s*,\s*nbas\s*,\s*qcut", re.I)
_LLOC_HEADER = re.compile(r"lloc\s*,\s*lpopt", re.I)


def oncvpsp_bin() -> str | None:
    """Chemin du binaire oncvpsp.x, ou None s'il est introuvable."""
    candidates = [
        os.environ.get("ONCVPSP_BIN"),
        str(Path.home() / ".local" / "bin" / "oncvpsp.x"),
        shutil.which("oncvpsp.x"),
        shutil.which("oncvpsp"),
    ]
    for cand in candidates:
        if cand and Path(cand).is_file() and os.access(cand, os.X_OK):
            # Absolu : oncvpsp.x est lancé avec cwd = répertoire de travail.
            return str(Path(cand).resolve())
    return None


def find_oncv_dat(out_path) -> Path | None:
    """Retrouve l'input ONCVPSP ``.dat`` associé à un rapport ``.out``."""
    if not out_path:
        return None
    out_path = Path(out_path)
    d = out_path.parent
    stem = out_path.stem                       # ex. « oncv_Ts »
    for name in (f"{stem}.dat", f"{stem}.in"):
        cand = d / name
        if cand.is_file():
            return cand
    hits = sorted(list(d.glob("oncv_*.dat")) + list(d.glob("*.dat")))
    return hits[0] if hits else None


def extract_upf_from_out(out_text: str) -> str | None:
    """Extrait le UPF embarqué dans le rapport ONCVPSP.

    Avec ``psfile = both``, ONCVPSP écrit le UPF (XML) dans sa sortie standard
    entre ``Begin PSP_UPF`` et ``END_PSP``, et le PSML dans ``ONCVPSP.psml``.
    """
    if not out_text:
        return None
    m = re.search(r"Begin PSP_UPF(.*?)END_PSP", out_text, re.S | re.I)
    body = m.group(1) if m else out_text
    u = re.search(r"<UPF\b.*?</UPF>", body, re.S | re.I)
    if not u:
        return None
    return u.group(0).rstrip() + "\n"


def ghost_channels(out_text: str) -> list:
    """Canaux angulaires ``l`` pour lesquels ONCVPSP signale un ghost."""
    lvals = []
    for m in _GHOST_LINE.finditer(out_text or ""):
        l = int(m.group(1))
        if l not in lvals:
            lvals.append(l)
    return lvals


def has_ghost(out_text: str) -> bool:
    return bool(_GHOST_LINE.search(out_text or ""))


def _data_block(text: str, header_re) -> tuple:
    """Retourne (indices des lignes de données, lignes) suivant un en-tête."""
    lines = text.splitlines()
    start = None
    for i, line in enumerate(lines):
        if line.lstrip().startswith("#") and header_re.search(line):
            start = i
            break
    if start is None:
        return [], lines
    idx = []
    for j in range(start + 1, len(lines)):
        stripped = lines[j].strip()
        if not stripped:
            if idx:
                break
            continue
        if stripped.startswith("#"):
            break
        idx.append(j)
    return idx, lines


def bump_channels(dat_text: str, l_values, rc_factor: float, qcut_factor: float = QCUT_FACTOR):
    """Augmente ``rc`` (et réduit ``qcut``) des canaux ``l`` visés.

    Retourne ``(nouveau_texte, changements)`` où ``changements`` décrit chaque
    ligne modifiée (ancien/nouveau rc et qcut).
    """
    idx, lines = _data_block(dat_text, _RC_HEADER)
    if not idx:
        return dat_text, []
    changes = []
    for j in idx:
        parts = lines[j].split()
        if len(parts) < 2:
            continue
        try:
            l = int(float(parts[0]))
        except ValueError:
            continue
        if l not in l_values:
            continue
        try:
            rc = float(parts[1])
        except ValueError:
            continue
        ep = parts[2] if len(parts) > 2 else "0.00"
        ncon = parts[3] if len(parts) > 3 else "0"
        nbas = parts[4] if len(parts) > 4 else "7"
        try:
            qcut = float(parts[5])
        except (ValueError, IndexError):
            qcut = None
        new_rc = rc * rc_factor
        new_qcut = (qcut * qcut_factor) if qcut else None
        lines[j] = (
            f"{l:>5}{new_rc:>9.2f}{float(ep):>9.2f}{int(float(ncon)):>6}"
            f"{int(float(nbas)):>6}{('%.2f' % new_qcut) if new_qcut else ' 0.00':>8}"
        )
        changes.append({
            "l": l,
            "rc_old": rc, "rc_new": round(new_rc, 3),
            "qcut_old": qcut, "qcut_new": round(new_qcut, 3) if new_qcut else None,
        })
    return "\n".join(lines) + "\n", changes


def run_oncvpsp(dat_text: str, work_dir, timeout: float = DEFAULT_TIMEOUT,
                tick_cb=None):
    """Écrit l'input et lance oncvpsp.x. Retourne (ok, out_text, paths)."""
    binary = oncvpsp_bin()
    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)
    dat_path = work / "oncvpsp.in"
    out_path = work / "oncvpsp.out"
    if not binary:
        return False, "", {"dat": str(dat_path), "out": str(out_path),
                           "error": "oncvpsp.x introuvable (ONCVPSP_BIN)."}
    dat_path.write_text(dat_text, encoding="utf-8")
    t0 = time.perf_counter()
    try:
        with open(out_path, "w") as fh:
            proc = subprocess.run(
                [binary], stdin=open(dat_path, "r"),
                stdout=fh, stderr=subprocess.STDOUT,
                cwd=str(work), timeout=timeout, start_new_session=True,
            )
        rc = proc.returncode
    except subprocess.TimeoutExpired:
        return False, "", {"dat": str(dat_path), "out": str(out_path),
                           "error": f"oncvpsp.x interrompu après {int(timeout)} s.",
                           "runtime_s": round(time.perf_counter() - t0, 1)}
    except Exception as exc:  # pragma: no cover - dépend de l'environnement
        return False, "", {"dat": str(dat_path), "out": str(out_path),
                           "error": str(exc)}
    runtime = round(time.perf_counter() - t0, 1)
    text = out_path.read_text(errors="ignore") if out_path.is_file() else ""
    ok = rc == 0 and "END_PSP" in text
    return ok, text, {"dat": str(dat_path), "out": str(out_path),
                      "runtime_s": runtime, "returncode": rc}


def fix_ghosts(upf, out_path, work_dir, max_attempts: int = MAX_ATTEMPTS,
               tick_cb=None):
    """Tente d'éliminer les ghosts d'un pseudo ONCVPSP par régénération.

    Retourne un dict ::

        {applied, succeeded, reason, ghost_l, dat, attempts[], corrected_upf}
    """
    result = {
        "applied": False,
        "succeeded": False,
        "reason": None,
        "ghost_l": [],
        "dat": None,
        "attempts": [],
        "corrected_upf": None,
        "corrected_out": None,
    }

    out_path = Path(out_path) if out_path else None
    out_text = out_path.read_text(errors="ignore") if out_path and out_path.is_file() else ""
    lvals = ghost_channels(out_text)
    result["ghost_l"] = lvals
    if not lvals:
        result["reason"] = "Aucun ghost signalé dans le rapport de génération."
        return result

    binary = oncvpsp_bin()
    if not binary:
        result["reason"] = ("oncvpsp.x introuvable : impossible de régénérer le "
                            "pseudo pour supprimer le ghost.")
        return result

    dat = find_oncv_dat(out_path)
    if not dat:
        result["reason"] = ("Input de génération (oncv_<El>.dat) introuvable à côté "
                            "du rapport .out : régénération impossible.")
        return result

    result["dat"] = str(dat)
    base_text = dat.read_text(errors="ignore")
    work = Path(work_dir) / "anti_ghost"
    work.mkdir(parents=True, exist_ok=True)
    result["applied"] = True

    for i, factor in enumerate(RC_FACTORS[:max_attempts], 1):
        new_text, changes = bump_channels(base_text, lvals, factor)
        if not changes:
            result["reason"] = ("Impossible de modifier les canaux "
                                f"{lvals} dans {dat.name}.")
            break
        attempt_dir = work / f"essai{i}"
        ok, text, meta = run_oncvpsp(new_text, attempt_dir, tick_cb=tick_cb)
        attempt = {
            "n": i,
            "rc_factor": factor,
            "changes": changes,
            "ok": ok,
            "ghost": has_ghost(text),
            "ghost_l": ghost_channels(text),
            "runtime_s": meta.get("runtime_s"),
            "error": meta.get("error"),
        }
        result["attempts"].append(attempt)
        if ok and not attempt["ghost"]:
            result["succeeded"] = True
            result["reason"] = (
                f"Ghost({lvals}) éliminé en élargissant rc de ×{factor} "
                f"(qcut ×{QCUT_FACTOR})."
            )
            upfs = sorted(attempt_dir.glob("*.UPF")) + sorted(attempt_dir.glob("*.upf"))
            if upfs:
                result["corrected_upf"] = str(upfs[0])
            else:
                # ONCVPSP embarque le UPF dans son rapport : on l'en extrait.
                upf_text = extract_upf_from_out(text)
                if upf_text:
                    stem = Path(upf).stem if upf else "pseudo"
                    target = attempt_dir / f"{stem}.UPF"
                    target.write_text(upf_text, encoding="utf-8")
                    result["corrected_upf"] = str(target)
            outs = sorted(attempt_dir.glob("*.out"))
            if outs:
                result["corrected_out"] = str(outs[0])
            result["dat_text"] = new_text
            break

    if not result["succeeded"] and not result["reason"]:
        result["reason"] = (
            f"Ghost({lvals}) toujours présent après {len(result['attempts'])} "
            "tentative(s) d'élargissement de rc."
        )
    return result

#!/usr/bin/env bash
# =============================================================================
# fetch_pseudos.sh — récupère les pseudopotentiels Quantum ESPRESSO PSlibrary.
#
# But : si vous avez construit le tarball avec --exclude-pseudos (default)
#       (cf. scripts/build_release.sh), ou si vous venez de cloner le dépôt,
#       ce script récupère le set de .UPF recommandé pour 5 profils P1..P5
#       depuis la PSlibrary officielle de Quantum ESPRESSO.
#
# Stratégie de téléchargement :
#   - Le site quantum-espresso.org ne fournit PAS d'URL stable par fichier.
#     On télécharge la TABLE périodique PBE/PAW recommandée (1 archive par
#     élément) et on extrait les .UPF attendus dans pseudos/PBE/ (et
#     pseudos/PBEsol/ si --include-pbesol).
#   - Tous les téléchargements utilisent HTTPS avec timeout — pas d'erreur
#     silencieuse. Les .UPF déjà présents sont conservés (idempotent).
#
# Usage :
#   ./scripts/fetch_pseudos.sh                  # récupère PBE (124 fichiers)
#   ./scripts/fetch_pseudos.sh --include-pbesol # ajoute PBEsol (~37 fichiers)
#   ./scripts/fetch_pseudos.sh --element Si    # un seul élément
#   ./scripts/fetch_pseudos.sh --dry-run       # affiche ce qui manque sans DL
#   ./scripts/fetch_pseudos.sh --help
#
# Pré-requis : curl (Ubuntu : sudo apt-get install curl).
# =============================================================================
set -euo pipefail

_src="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
if command -v realpath >/dev/null 2>&1; then
    SCRIPT_DIR="$(realpath "$_src")"
elif command -v readlink >/dev/null 2>&1 && readlink -f / >/dev/null 2>&1; then
    SCRIPT_DIR="$(readlink -f "$_src")"
else
    SCRIPT_DIR="$_src"
fi
unset _src
THERMO_PW_ROOT="$(dirname "$SCRIPT_DIR")"
cd "$THERMO_PW_ROOT"

# ─── Palette ANSI ─────────────────────────────────────────────────────────
if [[ -t 1 ]]; then
    C_RESET=$'\033[0m'; C_BOLD=$'\033[1m'; C_DIM=$'\033[2m'
    C_RED=$'\033[31m'; C_GREEN=$'\033[32m'; C_YELLOW=$'\033[33m'
    C_CYAN=$'\033[36m'; C_BOLD_CYAN=$'\033[1;36m'
    C_BOLD_GREEN=$'\033[1;32m'; C_BOLD_YELLOW=$'\033[1;33m'
else
    C_RESET=""; C_BOLD=""; C_DIM=""; C_RED=""; C_GREEN=""; C_YELLOW=""
    C_CYAN=""; C_BOLD_CYAN=""; C_BOLD_GREEN=""; C_BOLD_YELLOW=""
fi
say()  { printf "%b\n" "$*"; }
hdr()  { printf "\n"; say "${C_BOLD_CYAN}━━━ $* ━━━${C_RESET}"; }
ok()   { say "  ${C_BOLD_GREEN}[OK]${C_RESET}    $*"; }
warn() { say "  ${C_BOLD_YELLOW}[WARN]${C_RESET}  $*"; }
err()  { say "  ${C_BOLD_RED}[ERR]${C_RESET}   $*"; }
note() { say "  ${C_DIM}…${C_RESET}       $*"; }

# ─── Parsing arguments ───────────────────────────────────────────────────
INCLUDE_PBESOL=0
DRY_RUN=0
ONLY_ELEMENT=""
ALL_ELEMENTS=(
    H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V
    Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr
)

while [[ $# -gt 0 ]]; do
    case "$1" in
        --include-pbesol)  INCLUDE_PBESOL=1; shift ;;
        --element)         ONLY_ELEMENT="${2:-}"; shift 2 ;;
        --dry-run)         DRY_RUN=1; shift ;;
        --help|-h)
            cat <<EOF
${C_BOLD_CYAN}━━━ THERMO_PW  ·  fetch_pseudos.sh ━━━${C_RESET}

Usage : $0 [options]

Options :
  --include-pbesol    Récupère aussi PBEsol (~37 fichiers).
  --element ELEMENT   Récupère un seul élément (ex. Si, Fe).
  --dry-run           Affiche ce qui manque sans télécharger.
  --help, -h          Cette aide.

Cible : $THERMO_PW_ROOT/pseudos/PBE (+ PBEsol/ si --include-pbesol).

Source : PSlibrary officielle sur quantum-espresso.org (Quantum ESPRESSO 7.x).
EOF
            exit 0 ;;
        *) err "Argument inconnu : $1 (essayez --help)"; exit 1 ;;
    esac
done

# ─── Sanity checks ────────────────────────────────────────────────────────
hdr "fetch_pseudos.sh"

if ! command -v curl >/dev/null 2>&1; then
    err "curl introuvable. Installez-le : sudo apt-get install curl"
    exit 1
fi

mkdir -p pseudos/PBE
[[ $INCLUDE_PBESOL -eq 1 ]] && mkdir -p pseudos/PBEsol

# Filtre éventuel (mode --element)
if [[ -n "$ONLY_ELEMENT" ]]; then
    ALL_ELEMENTS=("$ONLY_ELEMENT")
    note "Mode single-élément : $ONLY_ELEMENT"
fi

# ─── Téléchargement d'un .UPF ───────────────────────────────────────────
# URL de la PSlibrary : on télécharge l'archive de l'élément, on extrait
# uniquement les fichiers .UPF. Cette approche est plus robuste que les
# liens directs (qui peuvent changer entre versions QE).
download_upf() {
    local element="$1"
    local functional="$2"          # "PBE" ou "PBEsol"
    local target_dir="pseudos/$functional"
    local upf_basename

    case "$element" in
        H)
            upf_basename="H.pbe-rrkjus_psl.1.0.0.UPF"  # H requiert RRKJUS
            ;;
        *)
            if [[ "$functional" == "PBE" ]]; then
                upf_basename="${element}.pbe-n-kjpaw_psl.1.0.0.UPF"
                # Magnétiques : utiliser *_spn-*
                case "$element" in
                    Fe|Co|Ni|Mn|Cr|V|Cu|Mo|W|Ta|Hf|Ti|Zr|Nb|Ru|Rh|Pd|Ag|Au|Pt|Re|Os|Ir|Y|La|Ce|Pr|Nd|Sm|Eu|Gd|Tb|Dy|Ho|Er|Tm|Yb|Lu|U|Pu|Th|Ca|Na|K|Rb|Cs|Ba|Sr)
                        upf_basename="${element}.pbe-spn-kjpaw_psl.1.0.0.UPF"
                        ;;
                esac
            else
                upf_basename="${element}.${functional,,}-n-kjpaw_psl.1.0.0.UPF"
            fi
            ;;
    esac

    local target="$target_dir/$upf_basename"
    if [[ -f "$target" ]]; then
        note "$functional : $upf_basename déjà présent (skip)"
        return 0
    fi

    # Source alternative : on propose le repack PBE_PSl sur qe-Forge ou GitLab.
    # Si le téléchargement direct échoue, on indique à l'utilisateur de le
    # récupérer manuellement depuis
    #   https://www.quantum-espresso.org/pseudopotentials/
    # et de placer le fichier dans $target_dir/.
    local url="https://www.quantum-espresso.org/UPF_files/${upf_basename}"
    if [[ $DRY_RUN -eq 1 ]]; then
        note "DRY : $target (depuis $url)"
        return 0
    fi

    if ! curl -fL --max-time 60 --retry 3 --retry-delay 5 "$url" -o "$target.tmp.$$" 2>/dev/null; then
        # Échec : tentative miroir https://github.com/dceresoli/qe-pseudo
        # (repo de re-hébergement tolérant vis-à-vis des versions).
        local mirror_url="https://raw.githubusercontent.com/dceresoli/qe-pseudo/master/${upf_basename}"
        say "  ${C_YELLOW}[WARN]${C_RESET} Source officielle inaccessible pour ${upf_basename}, tentative miroir GitHub…"
        if ! curl -fL --max-time 60 --retry 3 --retry-delay 5 "$mirror_url" -o "$target.tmp.$$" 2>/dev/null; then
            warn "Échec source officielle + miroir pour ${upf_basename}. Récupérez-le manuellement :"
            warn "    https://www.quantum-espresso.org/pseudopotentials/"
            warn "    ou : https://github.com/dceresoli/qe-pseudo"
            warn "    et placez-le dans : $target"
            rm -f "$target.tmp.$$"
            return 1
        fi
    fi

    # Sanity : le fichier doit commencer par "<UPF" (en-tête magic).
    if ! head -c 4 "$target.tmp.$$" 2>/dev/null | grep -q '<UPF'; then
        err "Le fichier téléchargé pour $upf_basename ne semble pas être un .UPF valide."
        rm -f "$target.tmp.$$"
        return 1
    fi

    mv "$target.tmp.$$" "$target"
    ok "$functional : $upf_basename téléchargé"
}

# ─── Mode dry-run : listing des .UPF manquants ───────────────────────────
hdr "Inventaire"
missing=0
for elt in "${ALL_ELEMENTS[@]}"; do
    local_upf="$elt.pbe-n-kjpaw_psl.1.0.0.UPF"
    [[ "$elt" == "H" ]] && local_upf="H.pbe-rrkjus_psl.1.0.0.UPF"
    case "$elt" in
        Fe|Co|Ni|Mn|Cr|V|Cu|Mo|W|Ta|Hf|Ti|Zr|Nb|Ru|Rh|Pd|Ag|Au|Pt|Re|Os|Ir|Y|La|Ce|Pr|Nd|Sm|Eu|Gd|Tb|Dy|Ho|Er|Tm|Yb|Lu|U|Pu|Th|Ca|Na|K|Rb|Cs|Ba|Sr)
            # Magnétiques / alcalins : UPFs spin-polarizes (spn-*) préférés.
            # Variante rrkjus tolérée en fallback (legacy QE 6.x).
            if [[ -f "pseudos/PBE/$elt.pbe-spn-kjpaw_psl.1.0.0.UPF" ]]; then
                continue
            elif [[ -f "pseudos/PBE/$elt.pbe-spn-rrkjus_psl.0.3.1.UPF" ]]; then
                continue
            else
                say "  ${C_YELLOW}[ ]${C_RESET}  $elt  (PBE spin-polarized manquant)"
                missing=$((missing+1))
            fi
            ;;
    esac

    # Cas général
    if [[ ! -f "pseudos/PBE/$local_upf" ]]; then
        say "  ${C_YELLOW}[ ]${C_RESET}  $elt  (PBE manquant)"
        missing=$((missing+1))
    fi
done

if [[ $missing -eq 0 ]]; then
    ok "Tous les éléments demandés sont déjà présents."
    exit 0
fi

if [[ $DRY_RUN -eq 1 ]]; then
    note "DRY : $missing .UPF manquants — relancez sans --dry-run pour les télécharger."
    exit 0
fi

# ─── Téléchargement effectif ──────────────────────────────────────────────
hdr "Téléchargement depuis la PSlibrary officielle"
note "Source : https://www.quantum-espresso.org/pseudopotentials/"
note "Timeout 60s par fichier, 3 tentatives avec backoff 5s."

fail=0
for elt in "${ALL_ELEMENTS[@]}"; do
    # Skip ceux déjà présents en PBE
    local_upf=""
    case "$elt" in
        H)                                  local_upf="H.pbe-rrkjus_psl.1.0.0.UPF" ;;
        Fe|Co|Ni|Mn|Cr|V|Cu|Mo|W|Ta|Hf|Ti|Zr|Nb|Ru|Rh|Pd|Ag|Au|Pt|Re|Os|Ir|Ca|Na|K|Rb|Cs|Ba|Sr)
                                                 # magnétiques ou alcalins/alkalino-terreux : on utilise spn-*
                                                 local_upf="${elt}.pbe-spn-kjpaw_psl.1.0.0.UPF" ;;
        *)                                   local_upf="${elt}.pbe-n-kjpaw_psl.1.0.0.UPF" ;;
    esac
    [[ -f "pseudos/PBE/$local_upf" ]] && continue
    if ! download_upf "$elt" "PBE"; then
        fail=$((fail+1))
    fi
    [[ $INCLUDE_PBESOL -eq 1 ]] && download_upf "$elt" "PBEsol" || true
done

# ─── Récap ────────────────────────────────────────────────────────────────
hdr "Récapitulatif"
pbe_count=$(ls pseudos/PBE/ 2>/dev/null | wc -l)
size_pbe=$(du -sh pseudos/PBE/ 2>/dev/null | awk '{print $1}')
say "  ${C_DIM}…${C_RESET}       pseudos/PBE/       : ${C_BOLD}${pbe_count}${C_RESET} fichiers (${size_pbe})"
if [[ $INCLUDE_PBESOL -eq 1 ]]; then
    pbesol_count=$(ls pseudos/PBEsol/ 2>/dev/null | wc -l)
    size_pbesol=$(du -sh pseudos/PBEsol/ 2>/dev/null | awk '{print $1}')
    say "  ${C_DIM}…${C_RESET}       pseudos/PBEsol/    : ${C_BOLD}${pbesol_count}${C_RESET} fichiers (${size_pbesol})"
fi

if [[ $fail -gt 0 ]]; then
    warn "${fail} téléchargement(s) ont échoué — complétez manuellement si nécessaire."
    note "Source manuelle : https://www.quantum-espresso.org/pseudopotentials/"
else
    ok "fetch_pseudos.sh terminé (tous les .UPF présents)."
fi

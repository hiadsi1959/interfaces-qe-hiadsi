# Installation de `thermo_pw` sur un autre PC Ubuntu

Guide pas-à-pas pour transférer le tarball depuis le PC source vers un PC Ubuntu
(20.04+, 24.04 LTS « Noble » recommandé) et le rendre opérationnel.

> **Deux scripts à la racine du projet** : `config_autre_pc.sh` (install + config) et `DEMARRER.sh` (lancer / arrêter l'UI).

---

## 1. Préparer le tarball sur le PC source

```bash
cd ~/thermo_pw
./scripts/build_release.sh              # → dist/thermo_pw_<YYYYMMDD>.tar.gz (~750 Ko)
# ou depuis la racine :
./emballer.sh
# ou avec pseudos embarqués (~195 Mo) :
./scripts/build_release.sh --include-pseudos

sha256sum dist/thermo_pw_*.tar.gz       # noter pour vérification côté cible
```

## 2. Transfert

```bash
# SCP :
scp dist/thermo_pw_<DATE>.tar.gz user@cible:~/

# Clé USB : copier le .tar.gz puis sur la cible :
sha256sum ~/thermo_pw_<DATE>.tar.gz     # comparer avec le hash source
```

## 3. Extraction (important)

L'archive contient un dossier **`thermo_pw/`** à la racine. Extraire dans **`$HOME`**, pas dans un sous-dossier déjà nommé `thermo_pw` :

```bash
tar -xzf ~/thermo_pw_<DATE>.tar.gz -C ~/
cd ~/thermo_pw
ls -la config_autre_pc.sh DEMARRER.sh    # les 2 seuls scripts racine
```

> **Erreur fréquente** : `tar -xzf … -C ~/thermo_pw/` crée `~/thermo_pw/thermo_pw/` — à éviter.

## 4. Fix `sources.list` (Ubuntu 24.04+ uniquement si apt échoue)

Si `config_autre_pc.sh` affiche `libxml2` ou paquets introuvables :

```bash
CODENAME=$(lsb_release -cs)
sudo tee /etc/apt/sources.list.d/ubuntu.sources >/dev/null <<EOF
Types: deb
URIs: http://archive.ubuntu.com/ubuntu
Suites: $CODENAME $CODENAME-updates $CODENAME-security
Components: main universe
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg
EOF
sudo apt-get update
```

Puis relancer `./config_autre_pc.sh`.

## 5. `config_autre_pc.sh` — tout-en-un (install + config)

```bash
cd ~/thermo_pw
chmod +x config_autre_pc.sh DEMARRER.sh
./config_autre_pc.sh
```

Ce script unique :

1. Installe les paquets système (`apt-get`) : Python, venv, Cairo/Pango, gnuplot, MPI…
2. Crée `venv/` et installe `backend/requirements.txt`
3. Détecte Quantum ESPRESSO (`pw.x`, `ph.x`, `thermo_pw.x`)
4. Demande le nombre de processus MPI
5. Génère **`env/local.sh`** (chemins QE, pseudos, work, port…)

Options :

```bash
SKIP_APT=1 ./config_autre_pc.sh    # paquets déjà installés
SKIP_PIP=1 ./config_autre_pc.sh    # venv déjà à jour
```

Idempotent : relançable sans casse (`env/local.sh` sauvegardé en `.bak`).

## 6. Pseudos (si tarball sans `--include-pseudos`)

```bash
./scripts/fetch_pseudos.sh
ls pseudos/PBE/ | wc -l    # ~125 attendus
```

## 7. Quantum ESPRESSO (si absent)

`config_autre_pc.sh` **ne compile pas** QE. Si `pw.x` est introuvable :

```bash
sudo apt-get install -y gfortran openmpi-bin libopenmpi-dev
# Compiler QE 7.x + thermo_pw.x, puis :
./config_autre_pc.sh    # re-détecte pw.x et met à jour env/local.sh
```

## 8. `DEMARRER.sh` — lancer / arrêter l'UI

```bash
./DEMARRER.sh                 # foreground + navigateur → http://127.0.0.1:8000/
./DEMARRER.sh --daemon        # détaché (terminal libéré)
./DEMARRER.sh --stop          # arrêt propre du serveur
```

Logs : `backend/api_server.log`

## 9. Vérifications

```bash
curl -sS http://127.0.0.1:8000/api/health
curl -sS http://127.0.0.1:8000/api/pipeline/profiles | python3 -m json.tool | head -20
```

Navigateur : 5 tuiles P1–P5, workflow ①②③④.

---

## Troubleshooting

| Symptôme | Fix |
|---|---|
| `libxml2` introuvable (apt) | §4 sources.list, puis `./config_autre_pc.sh` |
| Port 8000 occupé | `lsof -i :8000` ou `THERMO_PORT=8001 ./DEMARRER.sh` |
| `ModuleNotFoundError: flask` | `./config_autre_pc.sh` (recrée venv + pip) |
| UI vide / profiles 404 | `./DEMARRER.sh --stop && ./DEMARRER.sh` |
| `pw.x` introuvable | installer QE puis `./config_autre_pc.sh` |

---

## Résumé (PC cible)

```bash
tar -xzf thermo_pw_*.tar.gz -C ~/
cd ~/thermo_pw
./config_autre_pc.sh
./DEMARRER.sh
# arrêt :
./DEMARRER.sh --stop
```

#!/usr/bin/env bash
# =============================================================================
# config_autre_pc.sh — Installation + configuration de THERMO_PW sur un nouveau PC.
#
# Script unique pour le PC cible (apres extraction du tarball) :
#   1. Installe les paquets systeme (apt) + venv Python + pip
#   2. Detecte QE, MPI, gnuplot
#   3. Genere env/local.sh
#
# Usage :
#   cd ~/thermo_pw && ./config_autre_pc.sh
#   tar -xzf thermo_pw_*.tar.gz -C ~/ && cd ~/thermo_pw && ./config_autre_pc.sh
#
# Options : --skip-apt  --skip-pip  --help
# Variables : SKIP_APT=1  SKIP_PIP=1  THERMO_QE_BIN=/path/to/bin
# =============================================================================
set -euo pipefail

# --- Resolution du repertoire racine ---
_src="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
if command -v realpath >/dev/null 2>&1; then
    REPO_ROOT="$(realpath "$_src")"
elif command -v readlink >/dev/null 2>&1 && readlink -f / >/dev/null 2>&1; then
    REPO_ROOT="$(readlink -f "$_src")"
else
    REPO_ROOT="$_src"
fi
unset _src
cd "$REPO_ROOT"

if [[ ! -d "$REPO_ROOT/backend" ]] || [[ ! -d "$REPO_ROOT/interface" ]]; then
    echo "[ERR] Ce script doit etre lance depuis la racine thermo_pw (backend/ et interface/ absents)."
    exit 1
fi

# --- Palette ANSI ---
if [[ -t 1 ]]; then
    R=$'\033[0m'; B=$'\033[1m'; D=$'\033[2m'
    RED=$'\033[31m'; GRN=$'\033[32m'; YLW=$'\033[33m'; CYN=$'\033[36m'
    BGRN=$'\033[1;32m'; BYLW=$'\033[1;33m'; BRED=$'\033[1;31m'; BCYN=$'\033[1;36m'
else
    R=""; B=""; D=""; RED=""; GRN=""; YLW=""; CYN=""
    BGRN=""; BYLW=""; BRED=""; BCYN=""
fi

hdr()  { printf "\n%b\n" "${BCYN}━━━ $* ━━━${R}"; }
ok()   { printf "  %b\n" "${BGRN}[OK]${R}    $*"; }
warn() { printf "  %b\n" "${BYLW}[WARN]${R}  $*"; }
err()  { printf "  %b\n" "${BRED}[ERR]${R}   $*"; }
info() { printf "  %b\n" "${D}...${R}       $*"; }
ask()  { printf "  %b" "${CYN}[?]${R}     $*"; }

SKIP_APT="${SKIP_APT:-0}"
SKIP_PIP="${SKIP_PIP:-0}"
while [[ $# -gt 0 ]]; do
    case "$1" in
        --skip-apt) SKIP_APT=1; shift ;;
        --skip-pip) SKIP_PIP=1; shift ;;
        --help|-h)
            cat <<EOF
Usage : $0 [options]

Installe (apt + venv) et configure THERMO_PW sur ce PC.
Ensuite : ./DEMARRER.sh

Options :
  --skip-apt    Ne pas lancer apt-get (deps deja installees)
  --skip-pip    Ne pas pip install (venv deja a jour)
  --help        Cette aide

Variables : SKIP_APT=1  SKIP_PIP=1  THERMO_QE_BIN=/chemin/bin
EOF
            exit 0 ;;
        *) err "Argument inconnu : $1 (essayez --help)"; exit 1 ;;
    esac
done

SUDO_CMD=""
if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
    if command -v sudo >/dev/null 2>&1; then
        SUDO_CMD="sudo"
    fi
fi

do_install_env() {
    hdr "2. Installation systeme + Python (venv)"

    if [[ "$SKIP_APT" == "1" ]]; then
        info "SKIP_APT=1 — apt-get saute."
    elif command -v apt-get >/dev/null 2>&1; then
        if [[ -z "$SUDO_CMD" ]] && [[ ${EUID:-$(id -u)} -ne 0 ]]; then
            warn "sudo absent — installez manuellement python3-venv, gnuplot-nox, openmpi-bin…"
        else
            ${SUDO_CMD:-} apt-get update -y || warn "apt-get update a echoue."
            info "Paquets : python3, venv, Cairo/Pango, gnuplot, MPI…"
            ${SUDO_CMD:-} DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
                python3 python3-venv python3-pip python3-dev \
                libcairo2 libpango-1.0-0 libgdk-pixbuf-2.0-0 libffi-dev \
                libxml2 libxslt1.1 libjpeg-dev zlib1g-dev \
                gnuplot-nox gfortran openmpi-bin libopenmpi-dev \
                curl ca-certificates \
                || warn "apt-get install partiellement echoue — verifiez sources.list (Ubuntu 24.04+)."
            ok "Paquets systeme OK."
        fi
    else
        warn "apt-get introuvable — SKIP_APT=1 ou installation manuelle requise."
    fi

    PY_SYS=""
    for cand in python3 python; do
        command -v "$cand" >/dev/null 2>&1 && PY_SYS="$(command -v "$cand")" && break
    done
    if [[ -z "$PY_SYS" ]]; then
        err "python3 introuvable."
        return 1
    fi
    if ! "$PY_SYS" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)'; then
        err "Python >= 3.9 requis."
        return 1
    fi

    VENV_DIR="$REPO_ROOT/venv"
    if [[ ! -d "$VENV_DIR" ]]; then
        info "Creation du venv : $VENV_DIR"
        "$PY_SYS" -m venv "$VENV_DIR"
        ok "venv cree."
    else
        ok "venv deja present : $VENV_DIR"
    fi

    if [[ "$SKIP_PIP" == "1" ]]; then
        info "SKIP_PIP=1 — pip saute."
        return 0
    fi

    # shellcheck disable=SC1091
    source "$VENV_DIR/bin/activate"
    if [[ ! -f "$REPO_ROOT/backend/requirements.txt" ]]; then
        err "backend/requirements.txt manquant — tarball incomplet ?"
        return 1
    fi
    python -m pip install --upgrade pip setuptools wheel >/dev/null 2>&1 || true
    python -m pip install -r "$REPO_ROOT/backend/requirements.txt" \
        || { err "pip install echoue (reseau ?)."; return 1; }
    ok "Dependances Python installees."
}

# --- Banniere ---
printf "\n"
printf "  %b\n" "${BCYN}╔════════════════════════════════════════════════════════════╗${R}"
printf "  %b\n" "${BCYN}║${R}  ${B}THERMO_PW — Configuration pour un nouveau PC${R}            ${BCYN}║${R}"
printf "  %b\n" "${BCYN}║${R}  5 profils · workflow 4 etapes · lancement 1 clic         ${BCYN}║${R}"
printf "  %b\n" "${BCYN}╚════════════════════════════════════════════════════════════╝${R}"

# =========================================================================
# 1. DIAGNOSTIC SYSTEME
# =========================================================================
hdr "1. Diagnostic systeme"

# OS
OS_NAME="inconnu"
if command -v lsb_release >/dev/null 2>&1; then
    OS_NAME="$(lsb_release -ds 2>/dev/null || echo 'inconnu')"
elif [[ -f /etc/os-release ]]; then
    OS_NAME="$(. /etc/os-release && echo "${PRETTY_NAME:-$NAME $VERSION_ID}")"
fi
info "OS           : ${B}${OS_NAME}${R}"

# CPU
CPU_CORES="$(nproc 2>/dev/null || echo '?')"
CPU_MODEL="$(grep -m1 'model name' /proc/cpuinfo 2>/dev/null | sed 's/.*: //' || echo '?')"
info "CPU          : ${B}${CPU_MODEL}${R}"
info "Coeurs       : ${B}${CPU_CORES}${R}"

# RAM
RAM_TOTAL="$(free -h 2>/dev/null | awk '/^Mem:/{print $2}' || echo '?')"
info "RAM          : ${B}${RAM_TOTAL}${R}"

# Python
PY_BIN=""
PY_VERSION=""
for cand in "$REPO_ROOT/venv/bin/python" python3 python; do
    if command -v "$cand" >/dev/null 2>&1; then
        PY_BIN="$(command -v "$cand")"
        PY_VERSION="$("$PY_BIN" -V 2>&1 | awk '{print $2}')"
        break
    fi
done
if [[ -n "$PY_BIN" ]]; then
    ok "Python       : ${B}${PY_VERSION}${R}  ($PY_BIN)"
    if "$PY_BIN" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
        ok "Version >= 3.9 — compatible."
    else
        warn "Version < 3.9 — THERMO_PW necessite Python >= 3.9."
    fi
else
    err "Python3 non trouve. Installez-le : sudo apt-get install python3 python3-venv python3-pip"
fi

# MPI
MPI_BIN=""
if command -v mpirun >/dev/null 2>&1; then
    MPI_BIN="$(command -v mpirun)"
    MPI_VERSION="$(mpirun --version 2>&1 | head -1 || echo '?')"
    ok "MPI          : ${B}${MPI_VERSION}${R}"
elif command -v mpiexec >/dev/null 2>&1; then
    MPI_BIN="$(command -v mpiexec)"
    ok "MPI (mpiexec): ${B}${MPI_BIN}${R}"
else
    warn "MPI non trouve. Installez : sudo apt-get install openmpi-bin libopenmpi-dev"
fi

# gnuplot
if command -v gnuplot >/dev/null 2>&1; then
    GP_VERSION="$(gnuplot --version 2>&1 || echo '?')"
    ok "gnuplot      : ${B}${GP_VERSION}${R}"
else
    warn "gnuplot non trouve. Installez : sudo apt-get install gnuplot-nox"
fi

# gfortran
if command -v gfortran >/dev/null 2>&1; then
    GF_VERSION="$(gfortran --version 2>&1 | head -1 || echo '?')"
    ok "gfortran     : ${B}${GF_VERSION}${R}"
else
    warn "gfortran non trouve (necessaire pour compiler QE). Installez : sudo apt-get install gfortran"
fi

do_install_env || warn "Installation Python partielle — relancez ./config_autre_pc.sh apres correction."

# =========================================================================
# 3. RECHERCHE DE QUANTUM ESPRESSO
# =========================================================================
hdr "3. Recherche de Quantum ESPRESSO"

QE_FOUND=""
QE_SEARCH_DIRS=(
    "${THERMO_QE_BIN:-}"
    "$HOME/q-e-qe-7.5/bin"
    "$HOME/q-e-qe-7.4/bin"
    "$HOME/q-e-qe-7.3/bin"
    "$HOME/qe-7.5/bin"
    "$HOME/qe-7.4/bin"
)

# Recherche elargie dans les chemins courants
for pattern in "$HOME"/q-e-qe-*/bin "$HOME"/qe-*/bin /opt/q-e-qe-*/bin /opt/qe-*/bin /opt/quantum-*/bin /usr/local/Quantum*/bin; do
    for d in $pattern; do
        [[ -d "$d" ]] && QE_SEARCH_DIRS+=("$d")
    done
done

# Recherche dans le PATH
if command -v pw.x >/dev/null 2>&1; then
    QE_SEARCH_DIRS+=("$(dirname "$(command -v pw.x)")")
fi

# Deduplication
declare -A _seen
QE_CANDIDATES=()
for d in "${QE_SEARCH_DIRS[@]}"; do
    [[ -z "$d" ]] && continue
    [[ -n "${_seen[$d]:-}" ]] && continue
    _seen["$d"]=1
    QE_CANDIDATES+=("$d")
done

for cand in "${QE_CANDIDATES[@]}"; do
    if [[ -x "$cand/pw.x" ]] && [[ -x "$cand/ph.x" ]] && [[ -x "$cand/thermo_pw.x" ]]; then
        QE_FOUND="$cand"
        ok "Quantum ESPRESSO detecte : ${B}${QE_FOUND}${R}"
        # Verifier les binaires optionnels
        for bin in q2r.x matdyn.x dynmat.x bands.x dos.x epsilon.x turbo_lanczos.x; do
            if [[ -x "$cand/$bin" ]]; then
                info "  $bin — present"
            else
                warn "  $bin — ${YLW}absent${R} (certains profils pourraient echouer)"
            fi
        done
        break
    fi
done

if [[ -z "$QE_FOUND" ]]; then
    warn "Quantum ESPRESSO NON TROUVE sur ce PC."
    info "Chemins testes :"
    for c in "${QE_CANDIDATES[@]}"; do
        info "  $c"
    done
    printf "\n"
    ask "Saisissez le chemin vers le dossier bin/ de QE (ou Entree pour sauter) : "
    read -r QE_MANUAL
    if [[ -n "$QE_MANUAL" ]] && [[ -x "$QE_MANUAL/pw.x" ]]; then
        QE_FOUND="$QE_MANUAL"
        ok "QE accepte : ${B}${QE_FOUND}${R}"
    elif [[ -n "$QE_MANUAL" ]]; then
        err "pw.x non trouve dans $QE_MANUAL — QE sera absent de la config."
    else
        info "QE saute — vous pourrez le configurer plus tard dans env/local.sh."
    fi
fi

# =========================================================================
# 3. CONFIGURATION MPI
# =========================================================================
hdr "4. Configuration MPI"

# Recommandation basee sur les coeurs physiques
RECOMMENDED_NPROC="4"
if [[ "$CPU_CORES" =~ ^[0-9]+$ ]]; then
    if (( CPU_CORES >= 32 )); then
        RECOMMENDED_NPROC="24"
    elif (( CPU_CORES >= 16 )); then
        RECOMMENDED_NPROC="16"
    elif (( CPU_CORES >= 8 )); then
        RECOMMENDED_NPROC="$(( CPU_CORES - 2 ))"
    elif (( CPU_CORES >= 4 )); then
        RECOMMENDED_NPROC="$CPU_CORES"
    fi
fi

info "Coeurs detectes : ${B}${CPU_CORES}${R} — recommandation MPI : ${B}${RECOMMENDED_NPROC}${R} processus"
ask "Nombre de processus MPI [${RECOMMENDED_NPROC}] : "
read -r USER_NPROC
MPI_NPROC="${USER_NPROC:-$RECOMMENDED_NPROC}"
ok "MPI nproc = ${B}${MPI_NPROC}${R}"

# Plafond memoire MPI
RAM_BYTES=0
if [[ -f /proc/meminfo ]]; then
    RAM_KB="$(awk '/^MemTotal:/{print $2}' /proc/meminfo 2>/dev/null || echo 0)"
    RAM_BYTES=$(( RAM_KB * 1024 ))
fi

MPI_RLIMIT="8589934592"  # 8 GiB par defaut
if (( RAM_BYTES > 0 )); then
    RAM_GB=$(( RAM_BYTES / 1024 / 1024 / 1024 ))
    if (( RAM_GB >= 128 )); then
        MPI_RLIMIT=$(( 32 * 1024 * 1024 * 1024 ))
        info "RAM ${RAM_GB} Go — plafond MPI releve a 32 GiB"
    elif (( RAM_GB >= 64 )); then
        MPI_RLIMIT=$(( 16 * 1024 * 1024 * 1024 ))
        info "RAM ${RAM_GB} Go — plafond MPI releve a 16 GiB"
    elif (( RAM_GB >= 32 )); then
        MPI_RLIMIT=$(( 12 * 1024 * 1024 * 1024 ))
        info "RAM ${RAM_GB} Go — plafond MPI a 12 GiB"
    elif (( RAM_GB < 16 )); then
        MPI_RLIMIT=$(( 4 * 1024 * 1024 * 1024 ))
        info "RAM ${RAM_GB} Go — plafond MPI reduit a 4 GiB (PC modeste)"
    fi
fi

# =========================================================================
# 4. PSEUDOPOTENTIELS
# =========================================================================
hdr "5. Pseudopotentiels"

PSEUDOS_DIR="$REPO_ROOT/pseudos/PBE"
PSEUDOS_COUNT=0
if [[ -d "$PSEUDOS_DIR" ]]; then
    PSEUDOS_COUNT=$(find "$PSEUDOS_DIR" -maxdepth 1 -name '*.UPF' -o -name '*.upf' 2>/dev/null | wc -l)
fi

if (( PSEUDOS_COUNT > 0 )); then
    ok "Pseudopotentiels PBE : ${B}${PSEUDOS_COUNT} fichiers UPF${R} dans pseudos/PBE/"
else
    warn "Aucun pseudopotentiel dans pseudos/PBE/."
    info "Pour les telecharger : bash scripts/fetch_pseudos.sh"
    info "Ou copiez vos .UPF dans : $PSEUDOS_DIR"
fi

# PBEsol
PSEUDOS_SOL_DIR="$REPO_ROOT/pseudos/PBEsol"
PSEUDOS_SOL_COUNT=0
if [[ -d "$PSEUDOS_SOL_DIR" ]]; then
    PSEUDOS_SOL_COUNT=$(find "$PSEUDOS_SOL_DIR" -maxdepth 1 -name '*.UPF' -o -name '*.upf' 2>/dev/null | wc -l)
fi
if (( PSEUDOS_SOL_COUNT > 0 )); then
    ok "Pseudopotentiels PBEsol : ${B}${PSEUDOS_SOL_COUNT} fichiers UPF${R}"
fi

# =========================================================================
# 5. MATERIAUX DISPONIBLES
# =========================================================================
hdr "6. Materiaux disponibles"

INPUTS_DIR="$REPO_ROOT/inputs"
MAT_COUNT=0
if [[ -d "$INPUTS_DIR" ]]; then
    MAT_LIST=()
    for d in "$INPUTS_DIR"/*/; do
        [[ -d "$d" ]] || continue
        name="$(basename "$d")"
        [[ "$name" == "__pycache__" ]] && continue
        in_count=$(find "$d" -maxdepth 1 -name '*.in' 2>/dev/null | wc -l)
        MAT_LIST+=("$name ($in_count .in)")
        MAT_COUNT=$(( MAT_COUNT + 1 ))
    done
    if (( MAT_COUNT > 0 )); then
        ok "${B}${MAT_COUNT}${R} materiaux trouves dans inputs/ :"
        for m in "${MAT_LIST[@]}"; do
            info "  $m"
        done
    else
        warn "Aucun materiau dans inputs/. Ajoutez un dossier inputs/<Mat>/ avec vos .in"
    fi
fi

# =========================================================================
# 6. GENERATION DE env/local.sh
# =========================================================================
hdr "7. Generation de env/local.sh"

LOCAL_SH="$REPO_ROOT/env/local.sh"

if [[ -f "$LOCAL_SH" ]]; then
    BACKUP="$LOCAL_SH.bak.$(date +%Y%m%d_%H%M%S)"
    cp "$LOCAL_SH" "$BACKUP"
    ok "env/local.sh existant sauvegarde → ${B}$(basename "$BACKUP")${R}"
fi

# Determination du port
THERMO_PORT="${THERMO_PORT:-8000}"
ask "Port HTTP pour l'interface [${THERMO_PORT}] : "
read -r USER_PORT
THERMO_PORT="${USER_PORT:-$THERMO_PORT}"

# Ecoute reseau local ?
THERMO_HOST="127.0.0.1"
ask "Ouvrir l'API sur le reseau local (LAN) ? [o/N] : "
read -r USER_LAN
if [[ "$USER_LAN" =~ ^[oOyY] ]]; then
    THERMO_HOST="0.0.0.0"
    ok "THERMO_HOST=0.0.0.0 — accessible depuis le reseau local"
fi

cat > "$LOCAL_SH" <<LOCALEOF
#!/usr/bin/env bash
# =============================================================================
# env/local.sh — configuration THERMO_PW pour ce PC
#
# Genere automatiquement par config_autre_pc.sh le $(date '+%Y-%m-%d a %H:%M')
# Systeme : ${OS_NAME}
# CPU     : ${CPU_CORES} coeurs — ${CPU_MODEL}
# RAM     : ${RAM_TOTAL}
#
# DEMARRER.sh charge ce fichier automatiquement s'il existe.
# Editez les chemins ci-dessous si votre configuration change.
# =============================================================================

export USER_HOME="\${USER_HOME:-\$HOME}"

# --- Quantum ESPRESSO (binaires pw.x, ph.x, thermo_pw.x, etc.) ---
export THERMO_QE_BIN="${QE_FOUND:-\$USER_HOME/q-e-qe-7.5/bin}"

# --- Racine du depot (auto-detectee si non definie) ---
# export THERMO_REPO_ROOT="$REPO_ROOT"

# --- Repertoires de travail ---
export THERMO_WORK_ROOT="\${THERMO_WORK_ROOT:-$REPO_ROOT/work}"
export THERMO_INPUTS_DIR="\${THERMO_INPUTS_DIR:-$REPO_ROOT/inputs}"
export THERMO_OUTPUTS_DIR="\${THERMO_OUTPUTS_DIR:-$REPO_ROOT/outputs}"

# --- Pseudopotentiels ---
export THERMO_PSEUDOS_DIR="\${THERMO_PSEUDOS_DIR:-$REPO_ROOT/pseudos/PBE}"

# --- MPI ---
export THERMO_MPI_NPROC="${MPI_NPROC}"
export OMP_NUM_THREADS="1"

# Plafond memoire par sous-process MPI (evite OOM-kill de l'API)
export THERMO_MPI_RLIMIT_AS_BYTES="${MPI_RLIMIT}"

# --- Serveur Flask ---
export THERMO_HOST="${THERMO_HOST}"
export THERMO_PORT="${THERMO_PORT}"
# export THERMO_NO_BROWSER="1"  # decommenter pour serveur headless (SSH)

# --- libfabric / OFI (contournement crash MPI_Init) ---
export THERMO_FI_PROVIDER="tcp"
export THERMO_I_MPI_FABRICS="shm"

# --- Autres outils (optionnel) ---
# export INTERFACE_QE_V1="\$USER_HOME/Interface-QE_v1"
# export GEN_INPUTS_QE="\$USER_HOME/generation_inputs-QE"
# export GEN_PSEUDOS="\$USER_HOME/generation_pseudos"

# --- PATH (ajoute QE au PATH si absent) ---
case ":\$PATH:" in
  *:"\$THERMO_QE_BIN":*) ;;
  *) export PATH="\$PATH:\$THERMO_QE_BIN" ;;
esac
LOCALEOF

chmod +x "$LOCAL_SH"
ok "env/local.sh genere avec succes."

# =========================================================================
# 8. VERIFICATION FINALE
# =========================================================================
hdr "8. Verification finale"

VENV_DIR="$REPO_ROOT/venv"
SCORE=0
TOTAL=7
ISSUES=()

# 1. Python
if [[ -n "$PY_BIN" ]] && "$PY_BIN" -c 'import sys; sys.exit(0 if sys.version_info >= (3,9) else 1)' 2>/dev/null; then
    (( SCORE++ ))
else
    ISSUES+=("Python >= 3.9 manquant")
fi

# 2. venv
if [[ -d "$VENV_DIR" ]] && [[ -x "$VENV_DIR/bin/python" ]]; then
    (( SCORE++ ))
else
    ISSUES+=("venv Python absent — relancez ./config_autre_pc.sh")
fi

# 3. QE
if [[ -n "$QE_FOUND" ]] && [[ -x "$QE_FOUND/pw.x" ]]; then
    (( SCORE++ ))
else
    ISSUES+=("Quantum ESPRESSO non configure")
fi

# 4. MPI
if [[ -n "$MPI_BIN" ]]; then
    (( SCORE++ ))
else
    ISSUES+=("MPI (mpirun) absent")
fi

# 5. gnuplot
if command -v gnuplot >/dev/null 2>&1; then
    (( SCORE++ ))
else
    ISSUES+=("gnuplot absent (traces impossibles)")
fi

# 6. Pseudos
if (( PSEUDOS_COUNT > 10 )); then
    (( SCORE++ ))
else
    ISSUES+=("Pseudopotentiels PBE insuffisants ($PSEUDOS_COUNT fichiers)")
fi

# 7. env/local.sh
if [[ -f "$LOCAL_SH" ]]; then
    (( SCORE++ ))
else
    ISSUES+=("env/local.sh absent")
fi

# Affichage
printf "\n"
if (( SCORE == TOTAL )); then
    printf "  %b\n" "${BGRN}╔══════════════════════════════════════════════╗${R}"
    printf "  %b\n" "${BGRN}║  ✓ TOUT EST PRET — ${SCORE}/${TOTAL} verifications OK   ║${R}"
    printf "  %b\n" "${BGRN}╚══════════════════════════════════════════════╝${R}"
else
    printf "  %b\n" "${BYLW}╔══════════════════════════════════════════════╗${R}"
    printf "  %b\n" "${BYLW}║  ! PARTIELLEMENT PRET — ${SCORE}/${TOTAL} OK              ║${R}"
    printf "  %b\n" "${BYLW}╚══════════════════════════════════════════════╝${R}"
    printf "\n"
    info "Points a corriger :"
    for issue in "${ISSUES[@]}"; do
        warn "$issue"
    done
fi

# =========================================================================
# 9. PROCHAINES ETAPES
# =========================================================================
hdr "9. Prochaines etapes"

printf "\n"
info "1. ${B}Verifiez env/local.sh${R} si besoin :"
info "   \$ nano env/local.sh"
printf "\n"
info "2. ${B}Lancez l'interface${R} :"
info "   \$ ./DEMARRER.sh               ${D}# foreground + navigateur${R}"
info "   \$ ./DEMARRER.sh --daemon      ${D}# detache (terminal libre)${R}"
printf "\n"
info "3. ${B}Ouvrez dans le navigateur${R} :"
info "   ${BCYN}http://${THERMO_HOST}:${THERMO_PORT}/${R}"
printf "\n"
info "4. ${B}Arret propre${R} :"
info "   \$ ./DEMARRER.sh --stop"
printf "\n"

if [[ -z "$QE_FOUND" ]]; then
    printf "\n"
    warn "Quantum ESPRESSO n'est pas configure."
    info "Pour l'installer :"
    info "  1. sudo apt-get install gfortran openmpi-bin libopenmpi-dev"
    info "  2. wget https://www.quantum-espresso.org/...qe-7.5.tar.gz"
    info "  3. tar -xzf qe-7.5.tar.gz && cd qe-7.5"
    info "  4. ./configure MPIF90=mpif90 && make -j\$(nproc)"
    info "  5. Editez env/local.sh : export THERMO_QE_BIN=\$HOME/q-e-qe-7.5/bin"
fi

ok "config_autre_pc.sh termine."

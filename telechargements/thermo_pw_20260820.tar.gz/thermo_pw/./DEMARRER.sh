#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# DEMARRER.sh — lanceur de l'interface THERMO_PW (5 profils unifiés P1..P5).
#
# - Démarre le serveur Flask (backend/api_server.py) qui sert aussi l'UI statique
#   (interface/index_v2.html, app_v2.js, app_v2.css, api_v2.js).
# - Ouvre dans le navigateur par défaut : http://127.0.0.1:8000/.
# - Logs : backend/api_server.log (écrasés à chaque démarrage, ancien fichier .prev).
# - Ctrl+C : tue proprement le serveur Flask (PID stocké dans backend/.api.pid).
#
# Variables d'environnement reconnues :
#   THERMO_HOST              (défaut 127.0.0.1) — interface d'écoute Flask
#   THERMO_PORT              (défaut 8000)     — port HTTP (→ Flask via THERMO_API_PORT)
#   THERMO_API_RESTART_TOKEN (optionnel)       — active POST /api/admin/restart
#   THERMO_WORK_ROOT         (optionnel)       — redirige work/ ailleurs
#   THERMO_NO_BROWSER=1      (optionnel)       — désactive l'ouverture auto du navigateur
#   THERMO_BROWSER           (optionnel)       — ex. firefox (défaut), google-chrome, xdg-open
#
# Argument :
#   --daemon, --detach, -d   Détache le serveur de ce terminal : le script
#                             retourne dès que l'API répond /api/health, le
#                             serveur continue à tourner sous son propre
#                             session leader (setsid). Terminal libéré.
#   --stop, --arreter, -s    Arrête le serveur Flask et quitte.
#   --help, -h               Affiche l'aide et quitte.
#
# Diagnostic de fin (mode foreground uniquement) :
#   Quand le serveur s'arrête, le script affiche désormais :
#     • qui a tué quoi (utilisateur via Ctrl+C / kill explicite / fermeture
#       du terminal vs mort naturelle de Flask),
#     • le VRAI code retour de Flask (sans le masque « || true » qui
#       forçait 0 auparavant).
#
# Exemples :
#   ./DEMARRER.sh                          # par défaut : 127.0.0.1:8000 + navigateur (bloquant)
#   ./DEMARRER.sh --daemon                 # daemon : terminal libéré, serveur en arrière-plan
#   ./DEMARRER.sh --stop                   # arrêt du serveur
#   THERMO_PORT=9000 ./DEMARRER.sh         # change de port
#   THERMO_HOST=0.0.0.0 ./DEMARRER.sh      # ouvre l'API sur le réseau local
#   THERMO_NO_BROWSER=1 ./DEMARRER.sh      # ne lance pas le navigateur
#   THERMO_BROWSER=firefox ./DEMARRER.sh   # force un navigateur précis
# -----------------------------------------------------------------------------
set -euo pipefail

# Résolution du dépôt (le script doit se trouver à la racine du repo).
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
cd "$SCRIPT_DIR"

# Choix Python : préférence à un venv local ./venv puis python3 système.
# ----- Palette ANSI (auto-désactivée hors tty pour rester lisible
#       quand le stdout est redirigé vers un fichier de log).
#       Placée en tête pour que TOUS les messages d'erreur en profitent
#       (les codes littéraux \\033… pollueraient les logs depuis la CI).
if [[ -t 1 ]]; then
    C_RESET=$'\033[0m'
    C_BOLD=$'\033[1m'
    C_DIM=$'\033[2m'
    C_RED=$'\033[31m'
    C_GREEN=$'\033[32m'
    C_YELLOW=$'\033[33m'
    C_CYAN=$'\033[36m'
    C_BOLD_CYAN=$'\033[1;36m'
    C_BOLD_GREEN=$'\033[1;32m'
    C_BOLD_YELLOW=$'\033[1;33m'
    C_BOLD_RED=$'\033[1;31m'
else
    C_RESET=""; C_BOLD=""; C_DIM=""
    C_RED=""; C_GREEN=""; C_YELLOW=""
    C_CYAN=""; C_BOLD_CYAN=""
    C_BOLD_GREEN=""; C_BOLD_YELLOW=""; C_BOLD_RED=""
fi

# ----- Parsing des arguments (avant tout pour pouvoir court-circuiter). -----
DETACH=0
STOP=0
while [[ $# -gt 0 ]]; do
    case "$1" in
        --daemon|--detach|-d)
            DETACH=1; shift ;;
        --stop|--arreter|-s)
            STOP=1; shift ;;
        --help|-h)
            cat <<EOF
${C_BOLD_CYAN}━━━ THERMO_PW  ·  lanceur de l'interface 5 profils ━━━${C_RESET}

Usage : $0 [options]

Options :
  --daemon, --detach, -d   Serveur en arrière-plan (terminal libéré).
  --stop, --arreter, -s    Arrête le serveur Flask en cours.
  --help, -h               Affiche cette aide.

Variables d'env :
  THERMO_HOST (défaut 127.0.0.1)   THERMO_PORT (défaut 8000)
  THERMO_NO_BROWSER=1              THERMO_WORK_ROOT (optionnel)
  THERMO_API_RESTART_TOKEN (optionnel)
EOF
            exit 0 ;;
        *)
            echo "  ${C_RED}[ERREUR]${C_RESET}  Argument inconnu : $1 (essayez --help)" >&2
            exit 1 ;;
    esac
done

stop_server() {
    local pid_file="backend/.api.pid"
    local log_file="backend/api_server.log"
    local force="${THERMO_FORCE:-0}"

    if [[ ! -f "$pid_file" ]]; then
        echo "  ${C_BOLD_YELLOW}[NOTE]${C_RESET} Pas de fichier PID ($pid_file) — rien à arrêter."
        local orphan
        orphan="$(pgrep -f 'python.*backend/api_server.py' 2>/dev/null || true)"
        if [[ -n "$orphan" ]]; then
            echo "  ${C_DIM}Processus orphelin : PID=${orphan}${C_RESET}"
        fi
        return 0
    fi

    local pid
    pid="$(cat "$pid_file" 2>/dev/null || true)"
    if [[ -z "$pid" ]] || ! kill -0 "$pid" 2>/dev/null; then
        echo "  ${C_BOLD_YELLOW}[NOTE]${C_RESET} PID $pid absent — nettoyage."
        rm -f "$pid_file"
        return 0
    fi

    echo "  ${C_BOLD_CYAN}[ARRET]${C_RESET}  Serveur THERMO_PW (PID/pgid ${C_BOLD}${pid}${C_RESET})."
    if [[ "$force" == "1" ]]; then
        kill -KILL -- "-${pid}" 2>/dev/null || kill -KILL "${pid}" 2>/dev/null || true
    else
        kill -TERM -- "-${pid}" 2>/dev/null || kill -TERM "${pid}" 2>/dev/null || true
        for _ in 1 2 3 4 5 6; do
            kill -0 "$pid" 2>/dev/null || break
            sleep 0.5
        done
        if kill -0 "$pid" 2>/dev/null; then
            kill -KILL -- "-${pid}" 2>/dev/null || kill -KILL "${pid}" 2>/dev/null || true
        fi
    fi
    rm -f "$pid_file"
    echo "  ${C_BOLD_GREEN}[OK]${C_RESET}     Serveur arrêté. Logs : $SCRIPT_DIR/$log_file"
}

if (( STOP == 1 )); then
    stop_server
    exit 0
fi

PYTHON_BIN="${PYTHON:-}"
if [[ -z "$PYTHON_BIN" && -x "$SCRIPT_DIR/venv/bin/python" ]]; then
    PYTHON_BIN="$SCRIPT_DIR/venv/bin/python"
fi
if [[ -z "$PYTHON_BIN" ]]; then
    PYTHON_BIN="$(command -v python3 || true)"
fi
if [[ -z "$PYTHON_BIN" ]]; then
    echo "  ${C_RED}[ERREUR]${C_RESET}  Python 3 introuvable. Installez python3 ≥ 3.9 ou créez ./venv." >&2
    exit 1
fi

# Test de version numérique (pas lexicographique : \"3.10\" < \"3.9\" en string).
if ! "$PYTHON_BIN" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)'; then
    echo "  ${C_RED}[ERREUR]${C_RESET}  Python ≥ 3.9 requis (actuellement : $("$PYTHON_BIN" -V 2>&1))." >&2
    exit 1
fi

HOST="${THERMO_HOST:-127.0.0.1}"
PORT="${THERMO_PORT:-8000}"
# URL à donner au navigateur : reste en loopback même quand Flask bind 0.0.0.0.
DISPLAY_HOST="$HOST"
if [[ "$DISPLAY_HOST" == "0.0.0.0" ]]; then
    DISPLAY_HOST="127.0.0.1"
fi
URL="http://${DISPLAY_HOST}:${PORT}/"

PID_FILE="backend/.api.pid"
LOG_FILE="backend/api_server.log"
LOG_PREV="backend/api_server.log.prev"

mkdir -p backend

# Rotation simple du log précédent (1 génération).
if [[ -f "$LOG_FILE" ]]; then
    mv -f "$LOG_FILE" "$LOG_PREV" 2>/dev/null || true
fi

# Anti double-démarrage : si un PID précédent répond encore, on prévient.
if [[ -f "$PID_FILE" ]]; then
    OLD_PID="$(cat "$PID_FILE" 2>/dev/null || true)"
    if [[ -n "$OLD_PID" ]] && kill -0 "$OLD_PID" 2>/dev/null; then
        echo "  ${C_BOLD_YELLOW}[ATTENTION]${C_RESET} Un serveur tourne déjà (PID $OLD_PID, fichier $PID_FILE)." >&2
        echo "             Lancez : kill $OLD_PID   puis relancez DEMARRER.sh." >&2
        exit 2
    fi
    rm -f "$PID_FILE"
fi

# Sanity check : backend + interface présents.
if [[ ! -f "$SCRIPT_DIR/backend/api_server.py" ]]; then
    echo "  ${C_RED}[ERREUR]${C_RESET}  backend/api_server.py introuvable (suis-je bien à la racine ?)." >&2
    exit 1
fi
if [[ ! -f "$SCRIPT_DIR/interface/index_v2.html" ]]; then
    echo "  ${C_RED}[ERREUR]${C_RESET}  interface/index_v2.html introuvable. Vérifiez le refactor 5 profils." >&2
    exit 1
fi

# ----- Ouverture automatique du navigateur --------------------------------
# Priorité : THERMO_BROWSER → Mozilla Firefox (défaut projet) → xdg-open →
# Chrome/Chromium. Firefox évite des décalages d'affichage observés sur Chrome
# (transform 3D + background-clip sur le titre, grilles flex).
# Ouvre dans une NOUVELLE fenêtre pour ne pas voler l'onglet courant.
open_browser() {
    local url="$1"

    # Pas d'écran graphique (SSH sans X) → on évite l'erreur d'opener.
    if [[ -z "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]] && [[ "$(uname -s)" != "Darwin" ]]; then
        printf "  ${C_DIM}(Pas de session graphique : ouvrez ${C_BOLD_CYAN}%s${C_RESET}${C_DIM} manuellement.)${C_RESET}\n" "$url"
        return 0
    fi

    local opener=""
    local opener_note=""

    # 0) Override explicite
    if [[ -n "${THERMO_BROWSER:-}" ]]; then
        if command -v "$THERMO_BROWSER" >/dev/null 2>&1; then
            opener="$THERMO_BROWSER"
        else
            printf "  ${C_YELLOW}⚠${C_RESET}  THERMO_BROWSER=%s introuvable — cascade automatique.\n" "$THERMO_BROWSER"
        fi
    fi

    # 1) Mozilla Firefox — navigateur par défaut thermo_pw (affichage fiable)
    if [[ -z "$opener" ]]; then
        for cand in firefox firefox-esr; do
            if command -v "$cand" >/dev/null 2>&1; then
                opener="$cand"
                opener_note="Firefox (défaut thermo_pw)"
                break
            fi
        done
    fi

    # 2) Navigateur par défaut du système (xdg-open → souvent Chrome)
    if [[ -z "$opener" ]]; then
        for cand in xdg-open open; do
            if command -v "$cand" >/dev/null 2>&1; then
                opener="$cand"
                opener_note="défaut système"
                break
            fi
        done
    fi

    # 3) Chrome / Chromium (secours)
    if [[ -z "$opener" ]]; then
        for cand in google-chrome google-chrome-stable chromium chromium-browser chrome; do
            if command -v "$cand" >/dev/null 2>&1; then
                opener="$cand"
                opener_note="Chrome (secours — préférez Firefox si l'UI est décalée)"
                break
            fi
        done
    fi

    # 4) Derniers recours desktop
    if [[ -z "$opener" ]]; then
        for cand in kde-open gnome-open wslview; do
            if command -v "$cand" >/dev/null 2>&1; then
                opener="$cand"
                break
            fi
        done
    fi

    if [[ -z "$opener" ]]; then
        printf "  ${C_DIM}(Aucun navigateur détecté — ouvrez ${C_BOLD_CYAN}%s${C_RESET}${C_DIM} manuellement.)${C_RESET}\n" "$url"
        return 0
    fi

    if [[ -n "$opener_note" ]]; then
        printf "  ${C_CYAN}→${C_RESET} Ouverture dans ${C_BOLD}%s${C_RESET} ${C_DIM}(%s)${C_RESET}…\n" "$opener" "$opener_note"
    else
        printf "  ${C_CYAN}→${C_RESET} Ouverture dans ${C_BOLD}%s${C_RESET}…\n" "$opener"
    fi

    case "$opener" in
        google-chrome*|chromium*|chrome)
            # --new-window : force une nouvelle fenêtre (pas un onglet parasite).
            "$opener" --new-window "$url" >/dev/null 2>&1 &
            ;;
        firefox*)
            "$opener" --new-window "$url" >/dev/null 2>&1 &
            ;;
        xdg-open|open|kde-open|gnome-open|wslview)
            "$opener" "$url" >/dev/null 2>&1 &
            ;;
        *)
            "$opener" "$url" >/dev/null 2>&1 &
            ;;
    esac
    disown 2>/dev/null || true
}

# ----- Bannière de démarrage ---------------------------------------------
printf "\n"
printf "${C_BOLD_CYAN}━━━ THERMO_PW${C_RESET}${C_BOLD}  ·  5 profils unifiés P1..P5${C_RESET}${C_BOLD_CYAN} ━━━${C_RESET}\n"
printf "  ${C_DIM}Python${C_RESET}    : ${C_BOLD}%s${C_RESET}\n" "$("$PYTHON_BIN" -V 2>&1)"
printf "  ${C_DIM}Backend${C_RESET}   : %s\n" "$SCRIPT_DIR/backend/api_server.py"
printf "  ${C_DIM}UI${C_RESET}        : %s\n" "$SCRIPT_DIR/interface/index_v2.html"
printf "  ${C_DIM}URL${C_RESET}       : ${C_BOLD_CYAN}%s${C_RESET}\n" "$URL"
printf "  ${C_DIM}Log${C_RESET}       : %s\n" "$SCRIPT_DIR/$LOG_FILE"
printf "  ${C_DIM}Ctrl+C${C_RESET}    : arrêt propre du serveur.\n"
printf "  ${C_DIM}NoBrowser${C_RESET} : THERMO_NO_BROWSER=1 pour désactiver l'ouverture auto.\n"
printf "  ${C_DIM}Browser${C_RESET}   : Firefox par défaut (THERMO_BROWSER=google-chrome|xdg-open pour override).\n"
printf "\n"

# Pré-vol : tester que le port est libre.
if command -v ss >/dev/null 2>&1; then
    if ss -ltn "sport = :$PORT" 2>/dev/null | grep -q LISTEN; then
        echo "  ${C_RED}[ERREUR]${C_RESET}  Port $PORT déjà occupé (un autre serveur tourne ?)." >&2
        echo "             THERMO_PORT=<autre> ./DEMARRER.sh   # ou tuez l'ancien." >&2
        exit 3
    fi
fi

# Lancement Flask.
# Stratégie d'env :
#   - On utilise `env -i PATH=… VAR=val …` pour propager nos variables vers Python
#     de manière fiable, sans dépendre d'un bash -c multi-niveau fragile.
#   - Python lira THERMO_HOST et THERMO_API_PORT dans os.environ.
#   - setsid détache la session → SIGTERM du parent shell ne tue pas Flask.
#   - PYTHONUNBUFFERED=1 évite que Flask attende les '\n' pour logger.

CMD=(env -i
    "PATH=${PATH}"
    "HOME=${HOME}"
    "PYTHONUNBUFFERED=1"
    "THERMO_HOST=${HOST}"
    "THERMO_API_PORT=${PORT}"
    "LD_LIBRARY_PATH=${LD_LIBRARY_PATH:-}")

if command -v setsid >/dev/null 2>&1; then
    # setsid : nouvelle session → process group indépendant, kill ciblé.
    "${CMD[@]}" setsid "$PYTHON_BIN" "$SCRIPT_DIR/backend/api_server.py" \
        >"$LOG_FILE" 2>&1 &
    SERVER_PID=$!
else
    # Fallback macOS / BSD : pas de setsid disponible, on perd cette protection.
    (
        cd "$SCRIPT_DIR"
        "${CMD[@]}" "$PYTHON_BIN" backend/api_server.py
    ) >"$LOG_FILE" 2>&1 &
    SERVER_PID=$!
fi
echo "$SERVER_PID" >"$PID_FILE"

# ----- Diagnostic de fin -----------------------------------------------------
# EXIT_CAUSE_SERVER : renseigné par les traps INT/TERM/HUP du mode foreground
# pour identifier la cause côté SCRIPT (vs côté Flask). Vide si Flask est mort
# tout seul (sans intervention utilisateur).
EXIT_CAUSE_SERVER=""

cleanup() {
    # Anti-ré-entrance : un 2e signal pendant le sleep 1 (HUP impatient,
    # double Ctrl+C) ne relance pas cleanup en plein milieu.
    trap '' INT TERM HUP
    if [[ -n "${SERVER_PID:-}" ]] && kill -0 "$SERVER_PID" 2>/dev/null; then
        # setsid : le pgid est SERVER_PID lui-même, kill -TERM -- -PID = pgid.
        kill -TERM -- -"$SERVER_PID" 2>/dev/null || kill -TERM "$SERVER_PID" 2>/dev/null || true
        sleep 1
        if kill -0 "$SERVER_PID" 2>/dev/null; then
            kill -KILL -- -"$SERVER_PID" 2>/dev/null || kill -KILL "$SERVER_PID" 2>/dev/null || true
        fi
    fi
    rm -f "$PID_FILE"
}

if (( DETACH == 1 )); then
    # Mode daemon : ignorer INT/TERM/HUP pour que Ctrl+C, kill ou une
    # fermeture de terminal malpropre ne tue PAS Flask après le retour de
    # ce script. `setsid` côté lancement crée déjà une nouvelle session
    # pour Python (immune à HUP du contrôleur de terminal), mais on
    # désarme aussi ici pour plus de clarté et pour que bash lui-même
    # ne tente pas de cleanup au moment où il sort.
    trap '' INT TERM HUP
else
    # Mode foreground : capter INT/TERM/HUP séparément. Chaque trap note la
    # cause dans EXIT_CAUSE_SERVER (diagnostic final) puis appelle cleanup
    # qui désarme à son tour pour éviter les courses (HUP pendant sleep).
    trap 'EXIT_CAUSE_SERVER=INT; cleanup' INT
    trap 'EXIT_CAUSE_SERVER=TERM; cleanup' TERM
    trap 'EXIT_CAUSE_SERVER=HUP; cleanup' HUP
fi

# Attente que le serveur réponde (max ~10 s), avec feedback visible.
printf "  ${C_DIM}…${C_RESET} Attente du démarrage (/api/health)…\n"

SERVER_READY=0
LAST_PCT=0
for i in $(seq 1 20); do
    if curl -sf "http://$HOST:$PORT/api/health" >/dev/null 2>&1; then
        printf "\n  ${C_BOLD_GREEN}[OK]${C_RESET}   Serveur prêt (après ~%d ms).\n" "$((i*500))"
        SERVER_READY=1
        break
    fi
    if ! kill -0 "$SERVER_PID" 2>/dev/null; then
        printf "\n"
        echo "  ${C_RED}[ERREUR]${C_RESET}  Le serveur s'est arrêté pendant le démarrage. Voir $LOG_FILE :" >&2
        tail -n 40 "$LOG_FILE" >&2 || true
        rm -f "$PID_FILE"
        exit 4
    fi
    PCT=$((i * 5))
    if (( PCT - LAST_PCT >= 25 )); then
        printf "  ${C_DIM}…${C_RESET} toujours en attente (%d %% du délai 10 s)\n" "$PCT"
        LAST_PCT="$PCT"
    fi
    sleep 0.5
done

if (( SERVER_READY == 0 )) && ! curl -sf "http://$HOST:$PORT/api/health" >/dev/null 2>&1; then
    printf "\n"
    echo "  ${C_BOLD_YELLOW}[ATTENTION]${C_RESET} /api/health ne répond pas après 10 s. Voir $LOG_FILE :" >&2
    tail -n 30 "$LOG_FILE" >&2 || true
    printf "  ${C_DIM}Le serveur continue de tourner ; Ctrl+C pour l'arrêter.${C_RESET}\n"
fi

# ----- Ouverture du navigateur (foreground uniquement).
if (( DETACH == 0 )) && (( SERVER_READY == 1 )) && [[ "${THERMO_NO_BROWSER:-0}" != "1" ]]; then
    open_browser "$URL"
fi

if (( DETACH == 1 )); then
    # Mode daemon : on rend la main aussitôt, sans bloquer sur Ctrl+C.
    # Le serveur tourne sous son propre session leader (setsid) + disown,
    # donc la fermeture du terminal qui a lancé DEMARRER.sh ne le tue pas.
    disown 2>/dev/null || true
    printf "\n"
    if (( SERVER_READY == 1 )); then
        printf "  ${C_BOLD_GREEN}[DAEMON]${C_RESET}  Serveur détaché ${C_BOLD}(PID/pgid %s)${C_RESET}.\n" "$SERVER_PID"
        printf "  ${C_DIM}Navigateur :${C_RESET} ${C_BOLD_CYAN}%s${C_RESET}\n" "$URL"
        printf "  ${C_DIM}Logs       :${C_RESET} %s\n" "$SCRIPT_DIR/$LOG_FILE"
        printf "  ${C_DIM}Pour arrêter :${C_RESET} ./DEMARRER.sh --stop  ${C_DIM}(ou : kill -- -%s)${C_RESET}\n" "$SERVER_PID"
        printf "  ${C_DIM}Vous pouvez maintenant fermer ce terminal — Flask continue.${C_RESET}\n"
    else
        printf "  ${C_BOLD_YELLOW}[DAEMON]${C_RESET} Serveur lancé mais /api/health n'a pas répondu en 10 s.\n"
        printf "                       PID=%s, logs=%s\n" "$SERVER_PID" "$SCRIPT_DIR/$LOG_FILE"
    fi
    printf "\n"
    # Sortie explicite pour ne PAS retomber dans le wait $SERVER_PID.
    # Le trap est désarmé plus haut en mode daemon : la fermeture du
    # terminal qui a lancé ce script ne tue pas Flask.
    exit 0
fi

printf "\n"
printf "  ${C_DIM}Navigateur :${C_RESET} ${C_BOLD_CYAN}%s${C_RESET}\n" "$URL"
if (( SERVER_READY == 1 )); then
    printf "  ${C_DIM}Serveur :${C_RESET}   ${C_BOLD_GREEN}UP${C_RESET} (%s)\n" "$URL"
fi
printf "  ${C_DIM}Pour relancer après édition du code : Ctrl+C puis relancer ce script.${C_RESET}\n"
printf "\n"

# ----- Attente + diagnostic final ------------------------------------------
# `wait` est débloqué par :
#   (a) Ctrl+C / kill / fermeture du terminal → un trap pose EXIT_CAUSE_SERVER
#       puis cleanup() tue Flask ; wait retourne 128+signal (130, 143, 129),
#   (b) mort naturelle de Flask → wait retourne le vrai code retour de
#       python (0 = propre, 1..127 = crash applicatif, 128+N = Flask tué
#       par un signal OS — typiquement SIGKILL de l'OOM-killer).
#
# On capture le VRAI code retour (sans le masque « || true » qui forçait
# toujours 0 auparavant).
WAIT_RC=0
set +e
wait "$SERVER_PID" 2>/dev/null
WAIT_RC=$?
set -e

# cleanup() est idempotent : kill -0 court-circuite si Flask est déjà mort.
cleanup || true
rm -f "$PID_FILE"

# ----- Diagnostic final -----------------------------------------------------
printf "\n"
if [[ -n "$EXIT_CAUSE_SERVER" ]]; then
    # Cas (a) : on a reçu un signal côté SCRIPT.
    case "$EXIT_CAUSE_SERVER" in
        INT)  WHY="Ctrl+C (SIGINT)" ;;
        TERM) WHY="kill explicite (SIGTERM)" ;;
        HUP)  WHY="fermeture du terminal (SIGHUP)" ;;
        *)    WHY="signal $EXIT_CAUSE_SERVER" ;;
    esac
    printf "  ${C_BOLD_YELLOW}[FLASK_DOWN]${C_RESET} Arrêt demandé par vous : ${C_BOLD}%s${C_RESET}.\n" "$WHY"
else
    # Cas (b) : Flask est mort tout seul.
    if (( WAIT_RC >= 128 )); then
        SIG_NUM=$(( WAIT_RC - 128 ))
        printf "  ${C_BOLD_RED}[FLASK_DOWN]${C_RESET} Le serveur a été tué par signal %d (vérifier %s).\n" "$SIG_NUM" "$SCRIPT_DIR/$LOG_FILE"
    elif (( WAIT_RC == 0 )); then
        printf "  ${C_BOLD_YELLOW}[FLASK_DOWN]${C_RESET} Le serveur s'est terminé tout seul (code 0). Pour un arrêt demandé depuis l'UI, c'est inattendu — voir %s.\n" "$SCRIPT_DIR/$LOG_FILE"
    else
        printf "  ${C_BOLD_RED}[FLASK_DOWN]${C_RESET} Le serveur a planté (vrai code : %d). Diagnostic dans %s.\n" "$WAIT_RC" "$SCRIPT_DIR/$LOG_FILE"
    fi
fi
if [[ -f "$LOG_FILE" ]]; then
    printf "  ${C_DIM}Logs disponibles :${C_RESET} %s\n" "$SCRIPT_DIR/$LOG_FILE"
fi

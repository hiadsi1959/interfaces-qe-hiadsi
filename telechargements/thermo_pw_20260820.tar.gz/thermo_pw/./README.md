# THERMO_PW — 5 profiles · 4-step workflow · one-click launch

![tagline](https://img.shields.io/badge/Quantum_ESPRESSO-7.x-blueviolet?style=flat-square)
![Python](https://img.shields.io/badge/Python-≥3.9-blue?style=flat-square)
![Ubuntu](https://img.shields.io/badge/Ubuntu-20.04%2B-orange?style=flat-square)
![License](https://img.shields.io/badge/License-TBD-lightgrey?style=flat-square)

> **🇬🇧 English** — [Jump to English section](#english) | **🇫🇷 Français** — [Aller à la section française](#français)

---

<a id="english"></a>

## 🇬🇧 English

### Overview

THERMO_PW is a unified orchestration platform for **Quantum ESPRESSO (QE) 7.x** and `thermo_pw.x`. It turns a long chain of manual CLI calls (`pw.x` → `ph.x` → `q2r.x` → `matdyn.x` → `thermo_pw.x`) into a **single click** from a local browser UI, with 5 calibrated scientific profiles.

### The 5 profiles (P1–P5)

**Common base (all profiles):** DFPT phonons (ph.x → q2r.x → matdyn.x), dynamic stability, electronic bands + DOS (ichamp=3).

| # | Profile | `what=` | Specific calculations | Key outputs |
|---|---------|---------|----------------------|-------------|
| 1 | **P1** Mechanics 0 K | `scf_elastic_constants` | SCF V₀ → Voigt deformations → C_ij | `output_el_cons.dat`, B/G/E/ν |
| 2 | **P2** Thermal QHA | `mur_lc_t` | 7-point EOS grid → QHA ΔT=50 K | `eos_ev.png`, Cv(T), Debye T |
| 3 | **P3** Full study | `elastic_constants_geo` | P2 + C_ij(V₀,T) 0→1000 K | P2 + C_ij vs T |
| 4 | **P4** Phonon lifetimes | `ph_life` | P3 + τ_λ(ω), γ linewidth | P3 + κ_lattice(T) |
| 5 | **P5** Dielectric | `dielectric` | SCF V₀ → ε∞ tensor, Born Z* | BORN, ε_∞(3×3), Z* |

### 4-step workflow

1. **① Material & `scf.in`** — Select material and DFT input file
2. **② `thermo_pw.in`** — Auto-generated preview based on profile + material
3. **③ Run** — Single click "Run calculations"; Cancel / Resume available
4. **④ Results** — Live profile-aware metrics, plots, artifacts; load previous runs; downloadable fact sheet (HTML/Markdown/PDF)

### Quick start (this PC — git clone)

```bash
git clone <repo> thermo_pw && cd thermo_pw
./config_autre_pc.sh   # apt + venv + detects QE → env/local.sh
./DEMARRER.sh          # starts Flask API + opens browser → http://127.0.0.1:8000/
```

### Install on another PC (Option A — tarball)

```bash
# Source PC:
./emballer.sh                    # → dist/thermo_pw_YYYYMMDD.tar.gz (~750 Ko)

# Target PC:
tar -xzf thermo_pw_*.tar.gz -C ~/
cd ~/thermo_pw
./config_autre_pc.sh
./DEMARRER.sh
```

See [`INSTALL_ON_REMOTE.md`](INSTALL_ON_REMOTE.md). **Two root scripts only** : `config_autre_pc.sh` + `DEMARRER.sh`.

### Prerequisites

- **OS**: Ubuntu 20.04+ / Debian 11+
- **Python**: ≥ 3.9
- **Quantum ESPRESSO**: 7.x (compiled with `thermo_pw.x`)
- **MPI**: OpenMPI or Intel MPI
- **gnuplot**: `gnuplot-nox` recommended

### Job control

| Button | When visible | Action |
|--------|-------------|--------|
| **Cancel** | Job running | Stops the MPI calculation → status `cancelled` |
| **Resume calculation** (full chain) | Job error/cancelled/interrupted | Smart restart — completed steps skipped (EOS, phonons, …) |
| **Resume thermo_pw** | Job error after EOS + phonons OK | Skips EOS/phonons — cleans partial QHA geometry, relaunches `thermo_pw.x` only |
| **Clean up** | Results picker | Batch remove failed + orphan runs |

> After a power outage or PC reboot, use **Full chain resume**. After a **thermo_pw crash mid-QHA** (MKL/FFT, OOM), use **Resume thermo_pw** — EOS and phonon outputs on disk are kept.

### Results (section ④)

- **Profile-aware metrics** — only quantities declared for the loaded profile (P2: EOS + QHA thermo; P5-only ε₀ / Z* not shown on P2).
- **Live refresh** — parsed values update during polling; pending fields explain why (QHA geometry 5/9, α missing, etc.).
- **Artifacts panel** — parsed quantities + clickable files on disk; re-parse disk without relaunching MPI.

---

<a id="français"></a>

## 🇫🇷 Français

# THERMO_PW — Interface 5 profils · workflow 4 étapes · lancement 1 clic

> **Plateforme unifiée d'orchestration de calculs Quantum ESPRESSO + thermo_pw.**
>
> 5 profils scientifiques prêts à l'emploi (P1 mécanique 0 K, P2 thermique QHA, P3 étude complète, P4 durées de vie phonons, P5 propriétés diélectriques), pilotés depuis une interface web locale, sans script shell manuel.

---

## Table des matières

1. [Vue d'ensemble](#1-vue-densemble)
2. [Les 5 profils P1..P5](#2-les-5-profils-p1p5)
3. [Workflow utilisateur en 4 étapes](#3-workflow-utilisateur-en-4-étapes)
4. [Prérequis](#4-prérequis)
5. [Installation sur Ubuntu (pas-à-pas)](#5-installation-sur-ubuntu-pas-à-pas)
6. [Installation sur un autre PC — Option A (tarball, recommandé)](#6-installation-sur-un-autre-pc--option-a-tarball-recommandé)
7. [Configuration `env/local.sh`](#7-configuration-envlocalsh)
8. [Démarrage / arrêt / daemon](#8-démarrage--arrêt--daemon)
9. [Endpoints API principaux](#9-endpoints-api-principaux)
10. [Troubleshooting — erreurs courantes](#10-troubleshooting--erreurs-courantes)
11. [Structure du projet](#11-structure-du-projet)
12. [Scripts utilitaires](#12-scripts-utilitaires)
13. [Build & packaging](#13-build--packaging)
14. [Développement & contribution](#14-développement--contribution)
15. [Crédits licence mentions](#15-crédits-licence-mentions)

---

## 1. Vue d'ensemble

THERMO_PW est une couche d'orchestration au-dessus de **Quantum ESPRESSO (QE) 7.x** et du module `thermo_pw.x` qui l'accompagne. Il transforme une longue succession d'appels CLI manuels (`pw.x` → `ph.x` → `q2r.x` → `matdyn.x` → `thermo_pw.x`, paramètres à recopier, gnuplot après-coup) en **un clic unique** dans le navigateur, décliné en 5 profils scientifiques calibrés.

L'architecture est volontairement simple : **deux scripts à la racine** — `config_autre_pc.sh` (install + configuration) et `DEMARRER.sh` (lancer / arrêter l'UI). Pas de Docker Compose, pas de Kubernetes. L'API Flask sert à la fois :

- les routes REST (`/api/pipeline/...`, `/api/materials`, `/api/workflow1/...`, `/api/admin/restart`, etc.),
- **et** les fichiers statiques de l'UI (`interface/index_v2.html`, `app_v2.js`, `app_v2.css`, `api_v2.js`).

Tout est exécuté sous un **venv Python local**. Relancer `./config_autre_pc.sh` est sans danger (idempotent, préserve ou sauvegarde `env/local.sh`).

### Public cible

- Étudiants M2 / doctorat ERP (état, propriétés, relaxation de phase) en sciences des matériaux.
- HPCistes / équipes de calcul en accès workstation multi-cœurs (16-32 cœurs MPI typiques).
- Enseignants-chercheurs qui veulent mettre en route P1..P5 sans passer ½ journée à configurer QE.

---

## 2. Les 5 profils P1..P5

### Base commune (tous les profils)

Chaque profil P1..P5 exécute automatiquement, en plus de ses calculs spécifiques :

- **Phonons DFPT** : `ph.x` → `q2r.x` → `matdyn.x` (grille q 4×4×4) → dispersions phononiques + DOS phononique
- **Stabilité dynamique** : détection des fréquences imaginaires (ω < −0.5 cm⁻¹) → verdict STABLE / UNSTABLE
- **Bandes électroniques** : NSCF + `dos.x` + `bands.x` (`ichamp=3`) → E_Fermi, gap (direct/indirect), E(k)
- **DOS électronique** : densité d'états totale

### Calculs spécifiques par profil

| # | Profil         | `what=` thermo_pw v7         | Calculs spécifiques (en plus de la base commune)             | Sorties clés spécifiques                                                      | Physique couverte                                                                 |
|---|----------------|------------------------------|--------------------------------------------------------------|-------------------------------------------------------------------------------|-----------------------------------------------------------------------------------|
| 1 | **P1** Mécanique 0 K | `scf_elastic_constants`     | SCF V₀ → thermo_pw (déformations de Voigt, T = 0 K) → C_ij  | `output_el_cons.dat`, `thermo_pw_run.out`                                     | Constantes élastiques C_ij, modules polycristallins (B/G/E/ν)                    |
| 2 | **P2** Thermique QHA  | `thermo` (canonique 7.x : `mur_lc_t`)    | Grille EOS 7 pts (±3 %) → thermo_pw QHA ΔT = 50 K           | `eos_ev.png`, `eos_summary.json`, `thermo_pw_run.out`                         | Équation d'état (Birch-Murnaghan), Cv(T), température de Debye, ZPE              |
| 3 | **P3** Étude complète | `elastic_constants_geo` (canonique 7.x) | P2 + C_ij(V₀,T) sur grille T 0→1000 K                       | P2 + `elastic_constants_vs_T.dat`                                              | P2 + variation des constantes élastiques avec T                                   |
| 4 | **P4** Durée de vie phonons | `ph_life`                    | P3 + durée de vie τ_λ(ω) (conv_thr ≤ 1e-12)                 | P3 + τ_λ(ω), γ linewidth, κ_lattice(T)                                        | P3 + couplage anharmonique 3-phonons, conductivité thermique du réseau           |
| 5 | **P5** Propriétés diélectriques | `dielectric`                 | SCF V₀ → thermo_pw ε∞ (tenseur 3×3, charges de Born Z*)      | `BORN`, ε_∞(3×3), Z*, indice n                                                | Tenseur diélectrique haute fréquence ε∞ + charges effectives de Born Z*           |

> **Sorties communes** à tous les profils : `phonon_bands.png`, `phonon_dos.png`, `ebands.png`, `edos.png`, `phonon.freq`, `phonon.dos`, `fc.out`.

> 🧲 **Magnétisme** : pour un matériau ferromagnétique (Fe, Co, Ni, Mn...), fournir un `scf.in` avec `nspin = 2` + `starting_magnetization(...)` ; le pipeline respecte la polarisation de spin et le panneau « résultats » remonte automatiquement la magnétisation détectée (tous profils).

> 💡 **P5 opt-in** : la chaîne optique complète ε(ω) (epsilon.x + turbo_lanczos.x + turbo_davidson.x) est activable via la case à cocher UI « Réponse diélectrique ε(ω) complète ». Les extras thermo_pw (plot_bz, piézoélectrique, susceptibilité magnétique) sont également opt-in.

---

## 3. Workflow utilisateur en 4 étapes

L'UI est rigoureusement découpée en quatre sections numérotées ①②③④ — le bandeau du haut l'affiche comme tagline. Chaque section a une responsabilité unique.

### ① Matériau & `scf.in`

- Menu déroulant listant les sous-dossiers de `inputs/<Mat>/`.
- Chaque sous-dossier expose ses fichiers `.in` (préféré : un `*scf.in` non-`*nscf.in` et non-`*vc-relax.in`).
- Aperçu cliquable du `scf.in` (lecture seule par défaut, sauvegarde activée sous l'onglet « Édition »).
- Pour créer un nouveau matériau : poser vos `.in` dans `inputs/<NouveauMat>/`, redémarrer voir simplement attendre la prochaine rotation du badge « API en ligne ».

### ② `thermo_pw.in` (preview structuré)

- Choix du profil via les 5 tuiles colorées (P1 🟢 · P2 🌡️ · P3 👑 · P4 🎯 · P5 🌈).
- Génération à la volée d'un aperçu pseudo-structuré de `thermo_pw.in` à partir du matériau + profil + `nproc`.
- Tableau récapitulatif : `what`, `tmin`, `tmax`, `deltat`, `eos_grid`, `phonon_grid`, etc.
- Volet « P5 extras » apparaît uniquement pour P5 (panneau de cases à cocher : `plot_bz`, `piezoelectric_tensor`, `magnetic_susceptibility`, `magnetoelectric_tensor`, `scf_dielectric`).

### ③ Lancer

- Bouton « ▶ Lancer la série de calculs » — un seul clic.
- État du calcul remonté en temps réel dans un journal pré-formaté (`logBox`, max 600 lignes).
- Boutons d'action : ⏸ Pause · ▶ Resume · ⏹ Stop · ↻ Restart · ❌ Annuler (cf. `POST /api/pipeline/jobs/<id>/...`).
- **Reprise après échec** (août 2026) — deux modes distincts :
  - **Reprendre thermo_pw** (recommandé si EOS + phonons OK) : nettoie les géométries QHA partielles, relance `thermo_pw.x` seul.
  - **Reprise complète** : relance toute la chaîne en sautant les étapes marquées DONE.
- Badge de progression + bandeau vert « ✅ CALCULS TERMINÉS » sur terminaison.

### ④ Résultats

- **Métriques profil-aware** (août 2026) : la grille et le panneau Artefacts n'affichent que les grandeurs du contrat `expected_results` du profil chargé (ex. P2 : EOS + thermo QHA + électronique + stabilité — pas ε₀ / Z* réservés au P5).
- **Rafraîchissement live** : valeurs parsées (Cᵥ, F, S, stabilité…) mises à jour pendant le polling ; champs en attente avec message explicite (géom. QHA 5/9, α absent, Cₚ = Cᵥ sans α, etc.).
- **Stabilité dynamique** (tous profils) : verdict STABLE / UNSTABLE, nombre de modes imaginaires, ω_min (cm⁻¹).
- **Bandes + DOS** (tous profils) : `phonon_bands.png`, `phonon_dos.png`, `ebands.png`, `edos.png` servis en live.
- Tracés spécifiques par profil : `eos_ev.png` (P2-P4), `elastic_constants_vs_T.png` (P3-P4), etc.
- **Panneau Artefacts** — grandeurs parsées (profil-aware) + listing exhaustif cliquable PNG/PDF/text via `/api/pipeline/runs/<id>/result_file`.
- **Re-parse disque** — bouton dans le picker pour rafraîchir `results` sans relancer MPI.
- Fiche technique téléchargeable (Markdown / HTML / PDF) via 📋 Fiche technique sur un run sélectionné dans le picker.
- Sanity-checks scientifiques (Born stability, Poisson, B', forces résiduelles, stabilité dynamique).

---

## 4. Prérequis

### Matériel

| Composant | Minimum (P1/P5)      | Recommandé (P2/P3/P4) | HPC sérieux (full phonon grid 6×6×6) |
|-----------|----------------------|------------------------|----------------------------------------|
| CPU       | 4 cœurs              | 16-24 cœurs physiques  | 32+ cœurs MPI + OpenMP                |
| RAM       | 16 Go                | 64 Go                  | 128 Go+                              |
| Disque    | 50 Go                | 200 Go                 | SSD NVMe 1 To+                       |
| GPU       | —                    | —                      | — (QE exploite CPU seulement)         |

> ⚠️ **Tous les profils** exécutent la chaîne phonon DFPT (ph.x + q2r.x + matdyn.x). P1 est plus léger que P2-P4 (pas de grille EOS) mais nécessite quand même ~15 min sur 4 cœurs pour un matériau simple (Si). Bench P3 : grille EOS 7 pts + phonons 4×4×4 + QHA 0-1000 K = ~30 min sur 16 cœurs, ~10 min sur 32 cœurs, ~3 min sur workstation HPC 128 cœurs.

### Logiciel

- **OS** : Ubuntu 20.04 LTS, 22.04 LTS, 24.04 LTS, ou Debian 11+ (nécessaire pour `apt-get`).
- **Python** : ≥ 3.9 (≥ 3.10 recommandé pour `match`/`case`).
- **Quantum ESPRESSO** : 7.x (le profil canonique utilise `what='scf_elastic_constants'` etc. 7.x — pas de rétro-compatibilité 6.x).
- **MPI** : OpenMPI (`openmpi-bin libopenmpi-dev`) ou Intel MPI.
- **gnuplot** : `gnuplot-nox` recommandé (suffixe `-nox` = pas de dépendance X11 inutile sur serveur).
- **Pour le PDF de la fiche technique** : WeasyPrint (52+) + natives système `libcairo2 libpango-1.0-0 libgdk-pixbuf-2.0-0 libffi-dev`. Optionnel ; sans cela, HTML et Markdown restent pleinement fonctionnels.

---

## 5. Installation sur Ubuntu (pas-à-pas)

Installation **sur la machine où vous avez cloné le dépôt** (développement ou premier poste).

### Étape 1 — Récupérer le projet

```bash
cd ~/
git clone <url_depot> thermo_pw
cd thermo_pw
```

> Pour installer sur **un autre PC sans git**, préférez l’[option A (tarball)](#6-installation-sur-un-autre-pc--option-a-tarball-recommandé).

### Étape 2 — Configurer (`config_autre_pc.sh`)

```bash
chmod +x config_autre_pc.sh DEMARRER.sh
./config_autre_pc.sh
```

Installe apt + venv + pip, détecte QE/MPI, génère `env/local.sh`. Options : `SKIP_APT=1`, `SKIP_PIP=1`.

### Étape 3 — QE et pseudos (si absents)

- **QE** : compiler séparément, puis relancer `./config_autre_pc.sh`
- **Pseudos** : `./scripts/fetch_pseudos.sh` si `pseudos/PBE/` est vide

### Étape 4 — Lancer

```bash
./DEMARRER.sh
# arrêt : ./DEMARRER.sh --stop
```

---

## 6. Installation sur un autre PC — Option A (tarball, recommandé)

Méthode officielle pour déployer THERMO_PW **sans copier tout le dossier de dev** ni reconfigurer à la main. Vous transférez **une archive** (~5 Mo sans pseudos, ~195 Mo avec pseudos), puis vous installez.

### Ce que contient / ne contient pas le tarball

| Inclus dans l’archive | **Non** inclus (à installer sur le PC cible) |
|------------------------|-----------------------------------------------|
| Interface web P1–P5 + API Flask | **Quantum ESPRESSO** (`pw.x`, `ph.x`, `thermo_pw.x`, …) |
| Orchestrateur Python (`backend/`) | **MPI** (OpenMPI) — installé par `config_autre_pc.sh` |
| Gabarits, inputs exemples, scripts | **gnuplot** — installé par `config_autre_pc.sh` |
| `config_autre_pc.sh`, `DEMARRER.sh` | Pseudos `.UPF` (optionnel : `--include-pseudos` ou `fetch_pseudos.sh`) |

### Étape 1 — Construire l’archive (PC source)

```bash
cd ~/thermo_pw
./scripts/build_release.sh
# → dist/thermo_pw_YYYYMMDD.tar.gz
# → dist/SHA256SUMS  (vérifier l’intégrité après transfert)

# Avec pseudos PSlibrary embarqués (~195 Mo) :
./scripts/build_release.sh --include-pseudos
```

### Étape 2 — Transférer

```bash
# Réseau (SCP) :
scp dist/thermo_pw_*.tar.gz user@pc-cible:~/

# Ou clé USB — puis sur le PC cible :
sha256sum ~/thermo_pw_*.tar.gz   # comparer avec dist/SHA256SUMS sur la source
```

### Étape 3 — Extraire et configurer (PC cible)

```bash
tar -xzf ~/thermo_pw_*.tar.gz -C ~/
cd ~/thermo_pw
chmod +x config_autre_pc.sh DEMARRER.sh
./config_autre_pc.sh
```

> **Important** : extraire avec `-C ~/` (pas `-C ~/thermo_pw/`) pour obtenir `~/thermo_pw/` directement.

Durée typique : **~10 min** (sans compilation QE).

### Étape 4 — Pseudos et QE (si besoin)

`config_autre_pc.sh` **ne compile pas** QE. Si `which pw.x` ne renvoie rien :

```bash
sudo apt-get install -y gfortran openmpi-bin libopenmpi-dev
# Compiler QE 7.x + thermo_pw.x (voir INSTALL_ON_REMOTE.md §7)
# Puis relancer : ./config_autre_pc.sh
```

### Étape 5 — Démarrer et vérifier

```bash
./DEMARRER.sh

# Dans un autre terminal :
curl -sS http://127.0.0.1:8000/api/health
curl -sS http://127.0.0.1:8000/api/pipeline/profiles | python3 -m json.tool | head -20
```

Navigateur : **http://127.0.0.1:8000/** — 5 tuiles P1–P5, workflow ①②③④.

### Guide détaillé et dépannage

Documentation complète (sources.list Ubuntu 24.04, durées, test P1, tableau troubleshooting) :

**[`INSTALL_ON_REMOTE.md`](INSTALL_ON_REMOTE.md)**

### Récapitulatif des commandes (PC cible)

```bash
tar -xzf thermo_pw_*.tar.gz -C ~/ && cd ~/thermo_pw
./config_autre_pc.sh && ./DEMARRER.sh
```

---

## 7. Configuration `env/local.sh`

Chaque variable est chargée **automatiquement** par `DEMARRER.sh` si `env/local.sh` existe (généré par `config_autre_pc.sh`).

| Variable                  | Défaut                                    | Rôle                                                                 |
|---------------------------|-------------------------------------------|----------------------------------------------------------------------|
| `THERMO_REPO_ROOT`        | auto-détecté (`parent de backend/`)       | Racine du dépôt ; ne **PAS** toucher sauf cas pathologique           |
| `THERMO_QE_BIN`           | `$HOME/q-e-qe-7.5/bin`                     | Binaires QE (`pw.x ph.x q2r.x matdyn.x thermo_pw.x …`)               |
| `THERMO_INPUTS_DIR`       | `<repo>/inputs`                            | Dossier parent des matériaux (`<Mat>/*.in`)                          |
| `THERMO_OUTPUTS_DIR`      | `<repo>/outputs`                           | Sorties QE intermédiaires                                           |
| `THERMO_PSEUDOS_DIR`      | `<repo>/pseudos/PBE`                       | Pseudopotentiels utilisés dans les `scf.in` (`pseudo_dir =`)         |
| `THERMO_WORK_ROOT`        | `<repo>/work`                              | Calculs en cours (`work/<Mat>/pipeline_P*_*`)                       |
| `THERMO_MPI_NPROC`        | `4`                                        | Nb de processus MPI par défaut (surchargeable côté UI)              |
| `OMP_NUM_THREADS`         | non défini (1)                             | Threads OpenMP ; laisser 1 pour MPI pur, monter si build hybride    |
| `THERMO_MPI_RLIMIT_AS_BYTES` | `8589934592` (8 GiB)                     | Plafond mémoire par sous-process MPI (évite OOM-kill de l'API)      |
| `THERMO_FI_PROVIDER`      | `tcp`                                      | Override libfabric / OFI (cf. `backend/config.py`)                  |
| `THERMO_I_MPI_FABRICS`    | `shm`                                      | Override Intel MPI fabrics (sm POSIX, robuste)                      |

---

## 8. Démarrage / arrêt / daemon

### Démarrage (mode interactif)

```bash
./DEMARRER.sh
```

- Affiche une bannière THERMO_PW · 5 profils unifiés.
- Ouvre `http://127.0.0.1:8000/` dans le navigateur (défaut : `xdg-open` / navigateur système ; secours Chrome → Firefox). Override : `THERMO_BROWSER=firefox`.
- Logs dans `backend/api_server.log` (rotation simple : `.prev` à chaque redémarrage).
- **Ctrl+C** : `cleanup()` envoie `SIGTERM` au groupe MPI du serveur, attend 1 s, escalade en `SIGKILL` si besoin.

### Mode daemon (libère le terminal)

```bash
./DEMARRER.sh --daemon
```

- Le serveur tourne sous son propre session leader (`setsid`), terminal libéré.
- Pare-feu : Ctrl+C, kill du shell d'origine, fermeture du terminal ne tuent **PAS** Flask.
- Logs dans `backend/api_server.log`.

### Variables de tuning

```bash
THERMO_PORT=9000 ./DEMARRER.sh           # changer de port
THERMO_HOST=0.0.0.0 ./DEMARRER.sh        # ouvrir l'API sur le réseau local
THERMO_NO_BROWSER=1 ./DEMARRER.sh        # ne PAS lancer le navigateur (serveur headless)
THERMO_BROWSER=google-chrome ./DEMARRER.sh  # force un navigateur précis
```

### Arrêt

```bash
./DEMARRER.sh --stop                        # arrêt propre (SIGTERM puis SIGKILL)
THERMO_FORCE=1 ./DEMARRER.sh --stop         # SIGKILL immédiat
```

---

## 9. Endpoints API principaux

> ⚠️ **Backend Flask sur `0.0.0.0:THERMO_PORT/THERMO_API_PORT`**. En local (loopback) par défaut. Pour réseau local : `THERMO_HOST=0.0.0.0 ./DEMARRER.sh`.

### Système / santé

- `GET /api/health` — Santé globale (présence QE, gnuplot, factsheet, mémoire API…)
- `GET /api/version` — Build tag + PID + mtime source (anti-vieux-processus)
- `POST /api/admin/restart` — Re-exec du serveur (sans jeton par défaut — à verrouiller en prod)

### Matériaux & aperçus

- `GET /api/materials` — Liste tous les matériaux sous `inputs/<Mat>/`
- `GET /api/inputs/thermo` — Liste arborescence matériaux
- `GET /api/inputs/scf_in_preview?material_id=…&basename=…` — Aperçu texte d'un `scf.in`
- `GET /api/inputs/preview?path=…` — Aperçu d'un fichier `.in` (chemin absolu)
- `POST /api/inputs/cif_to_pw` — Convertit un `.cif` en `scf.in` pseudo-structuré
- `POST /api/inputs/transform` — `thermo_paths` / `reinforce_light` / `reinforce_medium` sur un contenu

### 5 profils P1..P5

- `GET /api/pipeline/profiles` — Métadonnées complètes des 5 profils (id, name, emoji, what_qe, description, storage_hint, expected_results, default_extra_whats)
- `POST /api/pipeline/run` — Lancement d'un run (body : `material_id`, `profile_id`, `scf_in_basename`, `nproc`, `work_dir?`, `p1_full_preset?`, `extra_whats?`)
- `GET /api/pipeline/jobs/<job_id>` — Polling live toutes les 1,5 s (status, message, steps, logs, results, progress)
- `GET /api/pipeline/thermo_pw_in_preview?…` — Aperçu structuré du futur `thermo_pw.in`

### Contrôle des jobs

- `POST /api/pipeline/jobs/<id>/cancel` — Annulation d'un job running/queued → statut `cancelled`
- `POST /api/pipeline/jobs/<id>/pause` — Mise en pause (reprise possible via `/resume`)
- `POST /api/pipeline/jobs/<id>/resume` — Reprendre un job en pause
- `POST /api/pipeline/jobs/<id>/stop` — Arrêt définitif (work_dir conservé, non reprenable)
- `POST /api/pipeline/jobs/<id>/restart` — Relance intelligente d'un job error/cancelled/interrupted (chaîne complète)
- `GET /api/pipeline/jobs/<id>/resume_thermo_pw/options` — Diagnostic reprise thermo_pw (géom. QHA, cibles, phonons OK)
- `POST /api/pipeline/jobs/<id>/resume_thermo_pw` — Reprise thermo_pw seule (EOS/phonons conservés)
- `POST /api/pipeline/jobs/<id>/reparse` — Re-parse les sorties sans relancer MPI
- `POST /api/pipeline/jobs/recover_zombies` — Récupération des jobs interrompus

### Picker « Charger un calcul précédent » (juin 2026)

- `GET /api/pipeline/runs?limit=50` — Liste des runs persistés
- `POST /api/pipeline/runs/<id>/load` — Charge un run terminé en mémoire (re-rendering live)
- `GET /api/pipeline/runs/<id>/sanity` — Sanity-checks scientifiques (Born stability, Poisson, B')
- `DELETE /api/pipeline/runs/<id>` — Suppression destructive (registre + work_dir)
- `POST /api/pipeline/runs/purge_failed` | `…/purge_stale` — Purge en lot terminaux KO / orphelins
- `GET /api/pipeline/runs/<id>/files` — Listing exhaustif des artefacts (PNG/PDF/dat/out…)
- `GET /api/pipeline/runs/<id>/result_file?path=…&inline=1&tail=N` — Sert un artefact (preview inline ou tail)

### Fiche technique (juillet 2026)

- `GET /api/pipeline/runs/<id>/factsheet?format=md|html|pdf` — Fiche technique téléchargeable (10 sections profil-aware, analyse experte rule-based)

### Workflow 1 EOS (héritage)

- `POST /api/workflow1/eos` — Lance l'EOS classique (rétro-compat)
- `POST /api/workflow1/eos/fit-only` — Ajustement Birch-Murnaghan seul (sans pw.x)
- `POST /api/workflow1/eos/purge_active` — Purge active des jobs thermo_pw.x

---

## 10. Troubleshooting — erreurs courantes

### 10.1 `ModuleNotFoundError: No module named 'flake8'…`

`config_autre_pc.sh` n'a pas été lancé ou a échoué. Relancer `./config_autre_pc.sh`.

### 10.2 `Address already in use` au démarrage

Le port 8000 (ou `THERMO_PORT`) est déjà occupé.

```bash
ss -ltn "sport = :8000"            # voir qui écoute
sudo fuser -k 8000/tcp             # ou : THERMO_PORT=8001 ./DEMARRER.sh
```

### 10.3 `NameError: name 'flatten_eos_summary_into_results' is not defined`

Le P2 a laissé un marqueur disque corrompu (`work/<Mat>/pipeline_P2_*/pipeline_api_job_state.json`). Solution simple : supprimer le `work_dir` du run cassé puis relancer. Si le problème est récurrent : cf. `backend/pipeline.py:26` (commentaire qui désactive explicitement l'import — fonction `flatten_eos_summary_into_results` jamais git-add).

### 10.4 `OFI fi_getinfo() failed`

Quantum ESPRESSO plante au `MPI_Init` (provider libfabric).

```bash
export THERMO_FI_PROVIDER=tcp        # ou : ofi_rxm, sockets, verbs
./DEMARRER.sh
```

### 10.5 OOM-kill d'un sous-process MPI

`thermo_pw.x` ou `matdyn.x` consomme plus que la RAM dispo ; l'OS tue et l'API perd son registre (`_REGISTRY` vidé → UI : « Job perdu »).

```bash
export THERMO_MPI_RLIMIT_AS_BYTES=0  # désactiver le plafond (laisser l'OS s'occuper)
# ou : THERMO_MPI_RLIMIT_AS_BYTES=$(echo "16*1024^3" | bc)  # plafond 16 GiB
```

### 10.6 Navigateur ne s'ouvre pas

Mode headless (SSH sans X) ou `xdg-open` absent : OK, juste ouvrir manuellement `http://127.0.0.1:8000/`.

Sinon, fixer avec `THERMO_NO_BROWSER=1` puis ouvrir à la main.

### 10.7 `The server encountered an internal error` (UI)

500 sur POST `/api/pipeline/run`. Consulter `backend/api_server.log` pour la trace. Cause fréquente : `scf.in` introuvable (`backend.scf_in_preview` retourne 404) ou `material_id` mal orthographié.

### 10.8 WeasyPrint absent / PDF de la fiche technique HS

L'UI grise automatiquement le bouton PDF si `/api/health` retourne `factsheet_pdf_available=false`. Re-install : `sudo apt-get install libcairo2 libpango-1.0-0 libgdk-pixbuf-2.0-0 libffi-dev && pip install weasyprint`.

### 10.9 Crash `thermo_pw.x` en milieu de QHA (MKL/FFT, code 7, SIGTERM)

Symptôme : job en `error` sur une géométrie QHA (ex. g5/9), EOS + phonons déjà terminés.

1. **Ne pas relancer toute la chaîne** si EOS/phonons sont OK — utiliser **Reprendre thermo_pw** (section ③, carte bleue).
2. Réduire `nproc` (ex. 2–3 sur laptop) pour limiter les crash MKL/FFT.
3. Section ④ → **Charger ce run** → les métriques déjà parsées (Cᵥ, F, S…) s'affichent ; Θ Debye et α restent en attente tant que la grille QHA n'est pas complète.
4. **Re-parse disque** après reprise pour rafraîchir le panneau Artefacts.

---

## 11. Structure du projet

```
thermo_pw/
├── config_autre_pc.sh         # install (apt+venv) + config QE → env/local.sh
├── DEMARRER.sh                # lanceur Flask + UI (--daemon, --stop)
├── emballer.sh                # PC source : compacter en dist/*.tar.gz
├── INSTALL_ON_REMOTE.md       # guide détaillé option A (tarball)
├── README.md                  # ce fichier
├── LICENSE                    # (à ajouter — placeholder TBD)
│
├── backend/                   # API Flask + orchestrateur
│   ├── api_server.py          # point d'entrée Flask (~16 Ko)
│   ├── pipeline.py            # orchestrateur 5 profils P1..P5 (~220 Ko)
│   ├── thermo_pw_resume.py    # reprise thermo_pw seule (QHA partielle)
│   ├── config.py              # chemins + THERMO_* env helpers
│   ├── requirements.txt       # deps Python
│   ├── material_inputs.py · input_editor.py · cif_to_pw.py · …
│   ├── phonon_chain_qe.py · phonon_gnuplot.py · eos_gnuplot.py
│   ├── parsers/ · factsheet.py · factsheet_ai.py · optical_props.py · …
│
├── interface/                 # UI statique servie par Flask
│   ├── index_v2.html          # page d'accueil (~20 Ko)
│   ├── app_v2.js              # logique UI 5 profils + 4 étapes (130 Ko)
│   ├── app_v2.css             # thème « volcano + ice »
│   ├── api_v2.js              # client HTTP pour /api/pipeline/*
│   └── index_v2.html.tplProfileTile · …
│
├── inputs/                    # matériaux par sous-dossier
│   ├── README.txt             # convention de nommage
│   ├── Si/ · BaTiO3/ · …      # un sous-dossier = un matériau
│
├── templates/                 # gabarits thermo_pw.in / pw / ph / optics
│   ├── thermo_control.template · thermo_elastic_note.txt
│   ├── pw_template_Ev_comment.in · ph_template_comment.in
│   ├── optics/ · cheatsheet/ · lo_to/ · qe_bands/ · thermo_control_keys/
│
├── pseudos/                   # pseudopotentiels PSlibrary (PBE + PBEsol)
│   ├── PBE/                   # majorité (124 fichiers, ~130 Mo)
│   └── PBEsol/                # complément (~37 fichiers, ~60 Mo)
│
├── env/
│   ├── portable_paths.example.sh   # modèle → copier en local.sh
│   └── local.sh               # ⚠️ généré par config_autre_pc.sh, pas versionné
│
├── scripts/                   # utilitaires (build, fetch, repairs, tests)
│   ├── build_release.sh       # production du tarball
│   ├── fetch_pseudos.sh       # téléchargement PSlibrary (optionnel)
│   ├── repair_magnetism_*.py  # rattrapage après une grosse modif « magnétisme » (juillet 2026)
│   └── validate_ui_header.py
│
├── patches/                   # micro-patches temporaires (transitoires)
│
├── logs/                      # logs serveur (rotation manuelle)
├── outputs/                   # sorties QE intermédiaires (rare)
└── work/                      # ⚠️ calculs utilisateur — JAMAIS versionné
```

---

## 12. Scripts utilitaires

| Script                        | Rôle                                                                 |
|-------------------------------|----------------------------------------------------------------------|
| `config_autre_pc.sh`          | **PC cible** : apt + venv + pip + détection QE/MPI + `env/local.sh` |
| `DEMARRER.sh`                 | Lance / arrête Flask + UI (`--daemon`, `--stop`)                    |
| `scripts/fetch_pseudos.sh`    | Téléchargement optionnel des pseudos PSlibrary                      |
| `emballer.sh`                 | **PC source** : raccourci → `dist/thermo_pw_<date>.tar.gz`         |
| `scripts/build_release.sh`    | Moteur de packaging (appelé par `emballer.sh`)                       |

---

## 13. Build & packaging

Voir [`scripts/build_release.sh`](scripts/build_release.sh) et le guide cible [`INSTALL_ON_REMOTE.md`](INSTALL_ON_REMOTE.md).

### Cas par défaut (distrib compacte ~5 Mo)

```bash
./emballer.sh
# équivalent : ./scripts/build_release.sh
# produit : dist/thermo_pw_YYYYMMDD.tar.gz
#          dist/MANIFEST.txt  dist/SHA256SUMS
```

Le tarball :

- **Exclut** automatiquement : `work/`, `outputs/`, `logs/`, `dist/`, `build/`, `.venv/`, `.pytest_cache/`, `.git/`, `__pycache__/`, `*.pyc`, `*.log`, `*.log.prev`, `pipeline_api_job_state.json`, `.api.pid`.
- **Inclut** : `backend/`, `interface/`, `inputs/`, `templates/`, `env/`, `scripts/fetch_pseudos.sh`, **`config_autre_pc.sh`**, **`DEMARRER.sh`**, **`INSTALL_ON_REMOTE.md`**, `README.md`, et `pseudos/` si `--include-pseudos`.
- **Exclut** (dev / PC source) : `scripts/build_release.sh`, `scripts/dev/`, scripts de repair, `work/`, `venv/`, etc.
- Contient un dossier top-level `thermo_pw/` (extraction : `tar -xzf … -C ~/ && cd ~/thermo_pw`).
- **N'inclut pas** Quantum ESPRESSO — à installer sur le PC cible puis `./config_autre_pc.sh`.

### Installation sur le PC cible (rappel option A)

```bash
tar -xzf thermo_pw_*.tar.gz -C ~/
cd ~/thermo_pw
./config_autre_pc.sh && ./DEMARRER.sh
```

### Options

```bash
./scripts/build_release.sh --include-pseudos          # inclure pseudos/PBE + PBEsol (~195 Mo total)
./scripts/build_release.sh --exclude-pseudos          # explicite (défaut)
./scripts/build_release.sh --include-git              # inclure .git/ pour reproductibilité
./scripts/build_release.sh --output-dir /tmp/pack     # changer la destination
./scripts/build_release.sh --help                     # aide
```

### Récupérer les pseudos sur le PC cible

Si le tarball a été construit sans pseudos :

```bash
./scripts/fetch_pseudos.sh                       # récupère les .UPF PBE courants (~130 Mo)
# ou manuellement depuis https://www.quantum-espresso.org/pseudopotentials/
```

---

## 14. Développement & contribution

### Workflow de dev local

```bash
# Dans un venv séparé (à côté du venv utilisateur) :
python3 -m venv .venv-dev
source .venv-dev/bin/activate
pip install -r backend/requirements.txt
pip install pytest black flake8 mypy
pytest backend/tests/                                    # tests unitaires (lents)
black backend/                                          # formatage
flake8 backend/                                         # lint
```

### Convention de code

- Python ≥ 3.9, indent 4 espaces, type hints partout où c'est raisonnable.
- Docstrings : `"""…"""` sur toutes les fonctions non-triviales.
- Messages utilisateur via `appendLog("…", cls)` côté UI ou `print()` / `current_app.logger.warning()` côté backend.
- Pas de PII dans les logs (`job_id` = 12 hex, c'est OK).
- Pas de `print()` côté API — préférer `current_app.logger.warning/info/error`.

### Tests

- `pytest backend/tests/` pour les tests unitaires (parsing, parsers, helpers).
- `python3 -m py_compile backend/pipeline.py` pour la validation syntaxique.
- Live test (P1 = élasticité + phonons + bandes, ~15 min / 4 cœurs) : `./DEMARRER.sh`, puis `curl -X POST http://127.0.0.1:8000/api/pipeline/run -H 'Content-Type: application/json' -d '{"material_id":"Si","profile_id":"P1","scf_in_basename":"si_scf.in","nproc":4}'`.

### Process de release

1. Mettre à jour `backend/api_server.py:API_BUILD_TAG` (incrémenter la date).
2. `./scripts/build_release.sh` (tarball compact ~5 Mo, défaut).
3. `./scripts/build_release.sh --include-pseudos` (tarball complet ~195 Mo pour distribution).
4. Tag git + push.
5. Tester l'extraction sur un PC Ubuntu vierge (cf. [§6 — option A](#6-installation-sur-un-autre-pc--option-a-tarball-recommandé)).

---

## 15. Crédits licence mentions

### Crédits — développement

Plateforme développée dans le cadre de travaux de recherche en **science des matériaux** (état, propriétés élastiques & diélectriques, durées de vie phonons, magnétisme) à l'aide de Quantum ESPRESSO et de ses modules `thermo_pw`, `epsilon.x`, `turbo_lanczos.x`.

**Auteur principal : _Voir [`interface/app_v2.js`](interface/app_v2.js) → popover auteur (clic sur la bannière USTO-MB en haut de l'UI) pour le nom complet, l'affiliation et l'email de contact._**

> ⚠️ Cette section est volontairement évasive — l'auteur exact du projet (nom, affiliation, email) est exposé **uniquement** dans le popover d'autorité de l'UI, pour éviter toute attribution incorrecte ici. Si vous forkez ou redistribuez le projet, **mettez cette section à jour** avec vos coordonnées.

### Crédits scientifiques

À utiliser dans toutes publications :

> *Ab initio structural, elastic and dielectric properties were computed using Quantum ESPRESSO [\@QE-cite] with the THERMO_PW orchestration platform [\@THERMO_PW-cite]. Phonon dispersions and quasi-harmonic approximation were obtained via thermo_pw.x [\@thermo_pw-cite].*

### Mentions légales

- **Quantum ESPRESSO** est un logiciel libre distribué sous licence GPLv2 — [`https://www.quantum-espresso.org`](https://www.quantum-espresso.org).
- Le **logo Quantum ESPRESSO** est une marque déposée ; son utilisation est soumise à autorisation.
- **WeasyPrint** est sous licence BSD.
- **Flask**, **NumPy**, **SciPy**, **Matplotlib**, **ASE** sont sous licences BSD ou MIT compatibles.

### Licence du projet THERMO_PW

À DÉFINIR (`LICENSE` à ajouter à la racine — MIT / GPLv2 / Apache 2.0 selon contexte de diffusion). Le projet a vocation academic-research-first ; une licence permissive type MIT ou Apache 2.0 favorise la réutilisation par la communauté thermo_pw/QE.

---

**Bonne simulation !** *Pour toute question ou bug, ouvrir un ticket sur le dépôt.*

Chemins k et tracé des bandes électroniques E(k) — Quantum ESPRESSO
======================================================================
Références : tutoriel PWscf « bands », Howto §1.2 thermo_pw, doc PWscf « K_POINTS ».

Les coordonnées ci‑dessous sont en **fractionnaires du réseau réciproque** (mode commun
`K_POINTS {crystal_b}`). Vérifier toujours avec seekpath / Sumo / XCrySDen et la **maille
primitive** réellement utilisée dans votre `pw.x` (`ibrav`, axes).


1) Chaîne minimale
------------------
  • SCF convergé (même préfixe / même géométrie).
  • Calcul `bands` + bloc `K_POINTS` listant les sommets du chemin et le nombre de pas
    entre deux sommets successifs.
  • `bands.x` puis en général `plotbands.x` pour produire des colonnes exploitables par gnuplot.


2) Répertoire des points spéciaux et chemins types (par classe QE / ibrav)
--------------------------------------------------------------------------

  **2.1 Cubique simple — Simple Cubic, ibrav = 1**

    Points clés : Γ (0,0,0), X (0.5,0,0), M (0.5,0.5,0), R (0.5,0.5,0.5)

    Chemin type : Γ − X − M − Γ − R − X | M − R

  **2.2 Cubique faces centrées — FCC, ibrav = 2** (ex. Si, diamant ; BZ = octaèdre tronqué)

    Points clés :
      Γ (0, 0, 0)
      X (0, 0.5, 0.5)
      L (0.5, 0.5, 0.5)
      W (0.25, 0.5, 0.75)
      K (0.375, 0.375, 0.75)

    Chemin type : Γ − X − W − K − Γ − L − U − W − L − K

  **2.3 Cubique centré — BCC, ibrav = 3**

    Points clés :
      Γ (0, 0, 0)
      H (0.5, −0.5, 0.5)
      P (0.25, 0.25, 0.25)
      N (0, 0, 0.5)

    Chemin type : Γ − H − N − Γ − P − H

  **2.4 Hexagonal — ibrav = 4** (ex. graphite, ZnO, GaN)

    Points clés :
      Γ (0, 0, 0)
      M (0.5, 0, 0)
      K (1/3, 1/3, 0)
      A (0, 0, 0.5)
      L (0.5, 0, 0.5)
      H (1/3, 1/3, 0.5)

    Chemin type : Γ − M − K − Γ − A − L − H − A | L − M | K − H

  **2.5 Tétragonal simple — ibrav = 6**

    Points clés :
      Γ (0, 0, 0)
      X (0.5, 0, 0)
      M (0.5, 0.5, 0)
      Z (0, 0, 0.5)
      R (0.5, 0, 0.5)
      A (0.5, 0.5, 0.5)

    Chemin type : Γ − X − M − Γ − Z − R − A − Z | X − R | M − A


3) Tableau récapitulatif (extraits — coordonnées cristallines k)
----------------------------------------------------------------

  Structure (famille)    Symbole    Coordonnées (kx, ky, kz)

  Toutes                 Γ          (0, 0, 0)

  FCC                    X          (0, 0.5, 0.5)
  FCC                    L          (0.5, 0.5, 0.5)

  BCC                    H          (0.5, −0.5, 0.5)
  BCC                    N          (0, 0, 0.5)

  Hexagonal              M          (0.5, 0, 0)
  Hexagonal              K          (0.333…, 0.333…, 0)


4) Conseils pour le fichier d’entrée (K_POINTS)
-----------------------------------------------

  Dans QE on utilise souvent **`crystal_b`** (fractionnaires réciproques cristallographes)
  ou **`tpiba_b`** (2π/a — voir doc selon votre convention de maille).

  Exemple **illustratif — cubique simple** (nombre de segments et pas à ajuster) :

    K_POINTS crystal_b
    5
    0.0 0.0 0.0 20 ! Gamma
    0.5 0.0 0.0 20 ! X
    0.5 0.5 0.0 20 ! M
    0.0 0.0 0.0 20 ! Gamma
    0.5 0.5 0.5  1 ! R

  Le dernier entier sur chaque ligne (ex. 20) est le nombre de **points intermédiaires**
  sur le segment vers le **sommet suivant** — contrôle le lissage de la courbe.

  Pour **Si / FCC (ibrav = 2)** : reprendre les coordonnées §2.2 et enchaîner les segments
  du chemin recommandé dans le même formalisme (une ligne par sommet avec le pas vers la suivante).


5) Post-traitement et axe horizontal avec Γ, X, …
-----------------------------------------------

  bands.x   (selon votre fichier .pp/.in)

  Puis **plotbands.x** en général pour obtenir distance cumulée × énergie et faciliter
  les étiquettes aux jonctions entre segments.

  Sans plotbands.x : placer `set xtics ("Γ" d0, "X" d1, …)` et traits verticaux aux distances
  cumulées dᵢ correspondant aux ruptures entre segments du chemin défini au §4.


6) Exemple gnuplot minimaliste (à adapter au fichier produit)
--------------------------------------------------------------

  set arrow from x1, graph 0 to x1, graph 1 nohead lt -1 lc rgb "#cccccc"
  set xtics ("Γ" 0, "X" x1, "L" x2, "Γ" x3)
  plot "votre_bands.dat" u 1:2 w l notitle


7) Lien avec cette interface web
---------------------------------

  Les tracés gnuplot boutonnés ici couvrent surtout E(V), phonons, élasticités vs T, ε(ω).
  Le diagramme **E(k)** avec points spéciaux reste une chaîne **QE** dans le terminal ;
  copier les chemins §2–§4 dans vos `bands.in` sous `inputs/` ou dans le dossier `work/`.

README — Comment obtenir LO/TO au point Γ
=========================================
(Date : juillet 2026 — refonte 5 profils P1..P5)

OBJECTIF
--------
Clarifier le contrat LO/TO (séparation Longitudinal Optique / Transverse
Optique au point Γ) pour les utilisateurs du pipeline thermo_pw unifié.

La séparation LO/TO vient du COUPLAGE NON-ANALYTIQUE dans la matrice
dynamique au point Γ :

    D_αβ^{NA}(q → 0) = (4π/e²) · (Z*_α · u) (Z*_β · u) / (ε_∞ · q·q)

où :
  * ε_∞ est le tenseur diélectrique statique haute fréquence (matrice 3×3)
    issu d'un calcul DFPT (epsilon.x OU thermo_pw dielectric).
  * Z* (au numérateur) sont les CHARGES EFFECTIVES DE BORN — vecteurs 3×3
    par atome, calculés en parallèle de la DFPT des phonons.
  * q → 0 — le couplage diverge si ε_∞ n'est pas dispo ou si Z* est nulle.

Sans ε_∞ et sans Z*, la séparation LO/TO est ZÉRO — tous les modes
optiques dégénèrent en triplets (LO) et (TO) identiques à q=Γ.

LA VOIE CANONIQUE : LANCER P5
-----------------------------
Le profil **P5** (``what='dielectric'``) NATIVEMENT fait :
  1. SCF équilibre (``scf.in`` + ``pw_scf_V0_for_phonon.in``).
  2. ph.x DFPT sur grille q (par défaut 4×4×4).
  3. q2r.x → ``fc.out``.
  4. matdyn.x → ``phonon.freq`` (bandes phononiques) + ``phonon.dos``.
  5. thermo_pw.x ``what='dielectric'`` → ε∞ (matrice 3×3) + Z* par atome.
  6. matdyn re-run avec correction non-analytique (NA) AUTOMATIQUE :
     ``epsilon.dat`` + ``BORN`` lus en interne → LO/TO splitting au point Γ.

C'est la voie la PLUS EFFICACE : tout est calculé en un coup dans le
work_dir du job P5, et l'UI expose ``dielectric.lo_to_splitting_cm-1``
(dans ``expected_results.metrics`` du profil P5).

Pré-requis matériel P5 :
  * **Pseudos Norm-Conserving uniquement** (US-PP / PAW refusés par
    epsilon.x : la non-colinéarité de la correction NC n'est pas
    définie pour les pseudos à canaux d'augmentation).
  * Au moins ``nbnd ≥ nat × 8`` (QE recommande ≥ 1.5× nbnd métal).
  * Grille k-points SCF suffisamment dense pour ε∞ propre
    (recommandé : 8×8×8 cubique, ou équivalent Monkhorst-Pack).

L'OPTION P1 : lo_to_opt_in=True (sous-run, JUILLET 2026)
---------------------------------------------------------
Si vous tenez à rester sur PROFIL P1 (Mécanique 0 K) pour des raisons
de workflow (cipher-file, compat run précédent, etc.) mais avez besoin
des LO/TO, l'option ``lo_to_opt_in=True`` existe dans
``PipelineJob.__init__`` (alias côté API :
``POST /api/pipeline/run { …, "lo_to_opt_in": true }``).

Effet :
  * Faite rapide NC : ``backend/lo_to_chain.py:check_pseudos_are_nc``
    refuse US-PP/PAW/Paw(upstream avec message clair.
  * Sous-run léger : ph.x (grille q grossière) + q2r + matdyn +
    thermo_pw ``what='dielectric'`` → ε∞ + Z*.
  * Écriture ``BORN`` (format VOIGT 6 floats + 9 floats par atome Z*)
    via ``lo_to_chain.write_born_file``.
  * Re-run matdyn avec ``non_analytic=.true.`` +
    ``BORN_INPUT_FILE='BORN'`` injectés idempotentement via
    ``lo_to_chain.extend_matdyn_in_for_non_analytic``.
  * Parse LO/TO splitting au point Γ → exposé sous
    ``results.dielectric.lo_to_splitting_cm-1`` + ``lo_to_LO_freq_cm-1``
    + ``lo_to_TO_freq_cm-1``.

REMARQUE IMPORTANTE
-------------------
Activer ``lo_to_opt_in=True`` sur P1 fait passer le job d'un SCF
unique (≈3-5 min selon grille k) à un workflow comparable à P2 sur
grille q grossière (≈30-90 min selon matériau). Si vous n'avez pas
de contrainte forte à rester en P1, PRÉFÉREZ RELANCER AVEC
``profile_id="P5"`` — c'est strictement équivalent fonctionnellement
et mieux documenté dans l'UI (tuiles ε∞, Z*, n, etc. présentes).

CE QUE MATDYN FAIT AVEC LE BORN FILE
-------------------------------------
Le fichier ``BORN`` (format QE Quantum-ESPRESSO 6+/7.x) contient, sur
la première ligne, 6 flottants en notation VOIGT :

    ε_xx  ε_xy  ε_xz  ε_yy  ε_yz  ε_zz

suivi d'une ligne par atome, contenant 9 flottants (tenseur 3×3
row-major : Z*xx Z*xy Z*xz Z*yx Z*yy Z*yz Z*zx Z*zy Z*zz).

matdyn lit ce fichier si, et seulement si, le namelist ``&INPUT``
de ``matdyn.in`` contient :
    non_analytic = .true.,
    BORN_INPUT_FILE = 'BORN',

Notre helper ``lo_to_chain.extend_matdyn_in_for_non_analytic``
injecte ces deux lignes idempotemment (sans casser les autres
paramètres : ``flfrc``, ``asr``, grille q restent intacts).

QUAND UTILISER ltherm_freq (P4) vs LO/TO
-----------------------------------------
``ltherm_freq`` (sortie thermo_pw mode-par-mode) ≠ LO/TO :
  * LO/TO = séparation au point Γ via correction non-analytique
    ε∞ + Z*. Applicable UNIQUEMENT aux isolants (sinon ε∞ = 1 métallisé).
  * ``ltherm_freq`` = sortie thermo_pw qui écrit la contribution
    thermique MODE-PAR-MODE dans des fichiers ``.freq_…`` (P4).
    C'est ce qu'on trace pour γ(ω) (« largeur de raie » par mode).

Les deux mécanismes sont complémentaires : P4 utilise ltherm_freq pour
γ(ω) et la séparation LO/TO est négligeable dans les métaux ; P5
utilise thermo_pw ``dielectric`` pour ε∞ + Z* + LO/TO.

VOIR AUSSI
----------
* ``backend/lo_to_chain.py`` — module helpers (NC check, BORN writer,
  extension matdyn idempotente, parse LO/TO Γ). PRODUIT en juillet 2026
  (cf. ``_NEW_INFRASTRUCTURE`` ci-dessous).
* ``backend/phonon_chain_qe.py:write_thermo_control_minimal`` — helper bas-
  niveau utilisé par lo_to_chain pour VC injection si on veut éventuellement
  la combiner avec un autre flow.
* ``backend/parsers/dielectric.py:parse_dielectric`` — ε∞ + Z* consumer
  (sortie thermo_pw ``what='dielectric'``).
* ``backend/optical_props.py`` — chaîne epsilon.x opt-in sur P5
  (ε(ω) IPA/RPA ; ne PAS confondre avec ε∞ statique).
* ``templates/thermo_control_keys/README_ltherm_freq_vs_ltherm_dos.txt``
  — sémantique des commutateurs thermo_pw (ltherm_dos vs ltherm_freq).

POINT D'ATTENTION : PARITÉ AVEC thermo_pw 7.x
---------------------------------------------
thermo_pw 7.x LIT le bloc ``&INPUT_THERMO`` en mode strict Fortran 2003
namelist. Toutes les clés DOIVENT être séparées par virgule (sauf la
dernière). Notre writer ``backend/work_thermo.write_thermo_control`` ET
``backend/phonon_chain_qe.write_thermo_control_minimal`` produisent
du code conforme (cf. commit juillet 2026). Si vous éditez
manuellement ``thermo_control`` à la main, vérifiez que chaque entrée
NAMELIST finit par une virgule si d'autres suivent — la syntaxe
précise du fichier est cruciale pour thermo_pw.x (sinon :
``Error in routine read_namelist``).

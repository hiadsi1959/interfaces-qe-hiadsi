README — thermo_pw : ltherm_dos vs ltherm_freq
==============================================
(Date : juillet 2026)
Auteur UI/Pipeline : équipe thermo_pw (5 profils P1..P5, refonte juin 2026).

OBJECTIF DE CET ENCART
----------------------
Clarifier une confusion fréquente côté UI : ``ltherm_dos`` et
``ltherm_freq`` ne sont PAS des commutateurs « activer la DOS » vs «
activer les fréquences ». Ce sont deux MODES DE REPRÉSENTATION du même
spectre dans le fichier de sortie ``thermo_pw_run.out``. Ils lisent
tous deux le MÊME ``fc.out`` / ``ph_dyn`` (issu de ph.x + q2r.x). Le
non-déverrouillage (``ltherm_dos=.false.`` + ``ltherm_freq=.false.``)
n'ÉTEINT PAS un calcul — il choisit simplement l'encodage de sortie.

DÉFINITIONS CANONIQUES
-----------------------
``ltherm_dos=.true.`` (défaut projet pour P2/P3) — thermo_pw.x écrit
les contributions thermiques en DENSITÉ D'ÉTATS intégrée par bande
d'énergie (mode DOS). C'est la sortie standard pour ``qha.dat`` et
``thermo_cons.dat``. Choisissez ce mode pour tracer une Cv(T), Debye(T),
énergie libre F(T) etc. (plots courbes vs T).

``ltherm_freq=.true.`` — thermo_pw.x écrit les contributions thermiques
MODE-PAR-MODE (``frequency-resolved``) : un fichier ``<prefix>.freq_…``
par mode phononique, contenant les contributions thermique et la largeur
de raie anharmonique γ(ω) par mode. C'est ce mode qu'on active pour
les sorties LIFE (``ph_life`` « durée de vie des phonons », P4).

``ltherm_dos=.false.`` + ``ltherm_freq=.false.`` — sortie minimale :
uniquement les scalaires (Cv globale à une T, Debye, énergie libre).
Aucun fichier ``*.dat`` mode-par-mode ni DOS phononique.

MATRICE D'APPLICATION PAR PROFIL
--------------------------------
  P1 (what='scf_elastic_constants' ;  ltherm_dos/ltherm_freq INERTES
       legacy UI 'elastic' sans      (T=0 K, pas de grille T).
       grille T réécrit par l'API     Valeurs historiques perdues.
       en 'scf_elastic_constants'
       canonique 7.x)

  P2 (what='mur_lc_t' QHA —           ltherm_dos=True   (défaut projet)
       legacy UI 'thermo' réécrit        ltherm_freq=False
       par l'API en 'mur_lc_t'
       canonique 7.x ; voir
       phonon_chain_qe.run_thermo_pw_mpi)

  P3 (what='elastic_constants_geo' ;   ltherm_dos=True   (défaut projet)
       legacy UI 'mur_lc_t_           ltherm_freq=False
       elastic_constants' + legacy
       API 'elastic'+grille T
       réécrits par l'API en
       canonique 7.x)

  P4 (what='ph_life' ;                 ltherm_dos=False  (P4 évite la DOS
       legacy UI/API 'qha_lif'         ltherm_freq=False (les τ_λ(ω) viennent
       réécrit par l'API en
       'ph_life' canonique 7.x)
                                                          du bloc dédié
                                                          ``ph_life`` de
                                                          thermo_pw, pas d'un
                                                          mode « freq_… »)
                                       -- NB : P4 pourrait techniquement
                                       passer ltherm_freq=.true. pour écrire
                                       un ``.freq_…`` mode-par-mode, mais
                                       le PROFILES courant ne le fait PAS
                                       (cf. pipeline.py::_thermo_opts_qha).
                                       Le pipeline ``ph_life`` produit
                                       les anharmonicités via son propre
                                       bloc en sortie directe ``thermo_pw_run.out``.

  P5 (what='dielectric')              ltherm_dos/ltherm_freq INERTES
                                       (calcul statique ε∞ : pas de chaîne
                                       phononique QHA). Utilisez ``lo_to_opt_in``
                                       sur P1 ou relancez avec P5 pour LO/TO.

EXEMPLES DE SORTIE
-------------------
``ltherm_dos=True`` seul → ``thermo_cons.dat`` (scalaires par T) +
``qha.dat`` (bindings intégrés) — idéal pour DOS_plot.gp.

``ltherm_freq=True`` seul → ``<prefix>.freq_…`` (un fichier par mode
phononique + prefix) — idéal pour γ(ω) plot (P4 / ``ph_life``).

Les deux en ``.true.`` → écrit les deux familles de fichiers (coût
disque ×2 sur le work_dir, mais aucune redondance de calcul).

QUAND ÇA NE PRODUIT RIEN
-------------------------
Si vous voyez ``ltherm_dos=False`` + ``ltherm_freq=False`` et que
aucune sortie phononique n'apparaît dans ``thermo_pw_run.out``, c'est
NORMAL : thermo_pw.x n'a RIEN d'autre à écrire (les scalaires sont
toujours là, en mode minimal). NE PANIQUEZ PAS en pensant que « la
chaîne phonon est cassée » — c'est juste le mode de représentation.

Pour réactiver un mode verbeux : éditez le fichier ``thermo_control``
dans le work_dir (``work/<mat>/pipeline_<pid>_<ts>_.../thermo_control``)
en passant l'un des deux drapeaux à ``.true.``, puis relancez
``thermo_pw.x`` SEUL (sans rejouer ph.x / q2r.x — ``fc.out`` est déjà
sur disque).

RÉFÉRENCE THERMO_PW OFFICIELLE
------------------------------
User guide thermo_pw §1.22 — clés de contrôle du bloc ``&INPUT_THERMO``
(``what``, ``zasr``, ``fildyn``, ``ltherm_dos``, ``ltherm_freq``).
``ltherm_dos`` ajouté en thermo_pw 6.x ; ``ltherm_freq`` ajouté en 7.0.
Les deux clés sont **mutuellement compatibles** (thermo_pw accepte
``.true.`` sur les deux sans warning) ; quand une seule est ``.true.``,
l'autre est ignorée.

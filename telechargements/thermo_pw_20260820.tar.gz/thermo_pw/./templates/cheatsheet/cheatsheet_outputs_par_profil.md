# Cheatsheet — Sorties attendues par profil (juillet 2026)

> **Source de vérité** : `backend/pipeline.py` → `PROFILES[id]["outputs"]` + `PROFILES[id]["expected_results"]["files"]`. Cette table est alignée manuellement sur le backend; toute modification d'un profil **doit** être reportée ici (voir « Maintenance » en bas).

Ce document liste l'intégralité des fichiers générés dans le `work_dir` du run par le pipeline unifié `thermo_pw` selon le profil `P1` à `P5`. Pour chaque fichier, on donne : (a) son rôle en 1 ligne, (b) le binaire QE / sous-étape qui l'a produit, (c) s'il est conditionnel à un opt-in UI.

> ⚠️ **Note nomenclature** : Le journal thermo_pw est nommé `thermo_pw_run.out` (PAS `thermo_pw.out`) par le backend pour éviter les collisions entre plusieurs runs concurrents dans le même dossier. Les noms canoniques ci-dessous sont les noms effectivement écrits sur disque — ils correspondent 1:1 à ce que `pipeline_api_job_state.json` expose côté UI (section ④ Résultats).

---

## Tableau comparatif des résultats par profil (P1..P5)

> **Légende** : `✓` = résultat toujours produit · `—` = non applicable · `(opt-in)` = produit si l'option UI est activée.
>
> **Sections de la fiche technique** : la dernière colonne renvoie aux numéros de sections de `render_factsheet_md` (cf. `backend/factsheet.py`). Une section qui n'est pas peuplée pour un profil donné est tout simplement absente du rendu (pas d'erreur).

| Grandeur / Résultat | P1 | P2 | P3 | P4 | P5 | Section fiche |
|---|---|---|---|---|---|---|
| **Structure cristalline** | | | | | | |
| Paramètres de maille (a, b, c, α, β, γ) | ✓ | ✓ | ✓ | ✓ | ✓ | identification |
| Volume d'équilibre V₀ (Birch–Murnaghan) | — | ✓ | ✓ | ✓ | — | §1 |
| **Équation d'état (EOS)** | | | | | | |
| B₀ (module de compressibilité) | — | ✓ | ✓ | ✓ | — | §1 |
| B' (dérivée de B₀, pressure derivative) | — | ✓ | ✓ | ✓ | — | §1 |
| E₀ (énergie d'équilibre) | — | ✓ | ✓ | ✓ | — | §1 |
| **Constantes élastiques (T=0K)** | | | | | | |
| C₁₁, C₁₂, C₄₄ (notation Voigt) | ✓ | — | ✓ | ✓ | — | §2 |
| Modules polycristallins VRH (B, G, E, ν) | ✓ | — | ✓ | ✓ | — | §2 |
| Anisotropie Zener (A), rapport Pugh (B/G) | ✓ | — | ✓ | ✓ | — | §2 |
| **Constantes élastiques vs Température (P3/P4)** | | | | | | |
| C_ij(V₀, T) sur grille 0→1000 K | — | — | ✓ | ✓ | — | §2b |
| Modules VRH(T) (B/G/E/ν) | — | — | ✓ | ✓ | — | §2b |
| Stabilité de Born (T=0K + T=T_max) | ✓ (T=0K) | ✓ (T=0K) | ✓ | ✓ | — | §2b, §5 |
| **Propriétés électroniques** | | | | | | |
| E_Fermi, gap, VBM, CBM, type (metal/semi) | ✓ | ✓ | ✓ | ✓ | ✓ | §3 |
| Bandes électroniques E(k) + DOS | ✓ | ✓ | ✓ | ✓ | ✓ | §3, §8b |
| **Magnétisme** | | | | | | |
| **Spin config lue dans scf.in** (nspin, starting_magnetization, ordre magnétique) | ✓ | ✓ | ✓ | ✓ | ✓ | identification |
| **Énergie spin-polarisée + m(T)** (3 clés : `magnetism.m_per_atom` + `magnetism.total_magnetization` + `magnetism.projected_moments_per_atom` — calculé si nspin>1 dans scf.in) | (opt-in) | (opt-in) | (opt-in) | (opt-in) | (opt-in) | §4 |
| **Phonons (DFPT)** | | | | | | |
| Bandes phononiques + DOS phononique (livrable) | ✓ | ✓ | ✓ | ✓ | ✓ | §5 |
| Phonon input DFPT (ph.in, fc.out — prereq) | ✓ | ✓ | ✓ | ✓ | ✓ | §5 |
| Stabilité dynamique (ω_min, modes imaginaires) | ✓ | ✓ | ✓ | ✓ | ✓ | §5 |
| Mode LO/TO au point Γ (non-analytique) | (opt-in) | — | — | — | (opt-in) | §7 |
| **Thermodynamique QHA (P2/P3/P4)** | | | | | | |
| Θ Debye (température de Debye) | — | ✓ | ✓ | ✓ | — | §5 (QHA) |
| ZPE (énergie de point zéro) | — | ✓ | ✓ | ✓ | — | §5 (QHA) |
| **Anharmonicité (P4)** | | | | | | |
| τ_λ (durée de vie des phonons par mode) | — | — | — | ✓ | — | §6 |
| γ linewidth (largeur de raie) | — | — | — | ✓ | — | §6 |
| κ_lattice (conductivité thermique réseau) | — | — | — | ✓ | — | §6 |
| Paramètre de Grüneisen γ̄, |γ|_max | — | — | — | ✓ | — | §6 |
| **Diélectrique (P5)** | | | | | | |
| ε_xx, ε_yy, ε_zz (tenseur ε∞) | — | — | — | — | ✓ | §7 |
| ε∞ moyenne, anisotropie, indice n | — | — | — | — | ✓ | §7 |
| Charges effectives Born Z* par atome | — | — | — | — | ✓ | §7 |
| **Optique ε(ω) (P5 opt-in)** | | | | | | |
| ε(ω) IPA/RPA, TDDFPT Lanczos/Davidson | — | — | — | — | (opt-in) | (hors fiche) |

**Profil par profil (synthèse)** :

- **P1** — Mécanique 0 K : pas de grille T, pas d'EOS. Phonons DFPT (4×4×4) inclus pour la stabilité dynamique + dispersions + DOS phononique. Opt-in LO/TO pour le mode Γ non-analytique.
- **P2** — = P1 + **EOS** (Birch–Murnaghan : V₀, B₀, B', E₀) + **thermodynamique QHA** (Θ Debye, ZPE, F(T), Cv(T) sur grille 0→1000 K pas 50 K). Phonons déjà inclus dans P1.
- **P3** — = P2 + **C_ij(V₀, T)** sur la grille T 0→1000 K (thermo_pw `what='elastic_constants_geo'` + `use_free_energy` + `elastic_algorithm='energy'`). Produits : `elastic_constants_vs_T.dat` + `elastic_vs_T_plot.png`.
- **P4** — = P3 + **anharmonicité 3-phonons** (thermo_pw `what='ph_life'`) : τ_λ par mode, γ linewidth, κ_lattice(T), paramètre de Grüneisen. Demande `conv_thr ≤ 1.0D-12` dans `scf.in`.
- **P5** — **Diélectrique** : tenseur ε∞ (Berry phase) + charges effectives de Born Z* par atome (chaîne DFPT). Chaîne optique ε(ω) IPA/RPA + TDDFPT Lanczos/Davidson **opt-in** (case à cocher UI ; pseudos Norm-Conserving obligatoires).

**Évolution par cumul** : P1 (élasticité + phonons + bandes) ⊂ P2 (+ EOS + QHA) ⊂ P3 (+ C_ij(T)) ⊂ P4 (+ anharmonicité). Tous les profils incluent phonons DFPT + bandes électroniques. P5 est orthogonal (diélectrique + optique, indépendant des autres profils pour le calcul ε∞ et Z*).

> **⚠️ Juillet 2026 — Option A** : depuis le correctif de la contradiction cumulative, **les fichiers `q2r.in`, `phonon.freq` et `phonon.dos` apparaissent dans les listes de P3 et P4** (héritage P2/P3) — avant cette révision, `PROFILES['P3']` / `PROFILES['P4']` dans `backend/pipeline.py` ne les listaient pas alors que l'orchestrateur les écrit bien sur disque (steps P2/P3 substeps). Cette ligne de garde-fou empêchera toute régression silencieuse.

---

## P1 — Mécanique 0 K (`what='scf_elastic_constants'` ; legacy UI/API `elastic` sans grille T réécrit par l'API → canonique 7.x)

Calcul des constantes élastiques à **T = 0 K strict** (pas de grille QHA) + **phonons DFPT** (stabilité dynamique, dispersions, DOS phononique) + **bandes électroniques** (ichamp=3).

### Fichiers de sortie

| Fichier | Description | Origine (binaire/étape) | Conditionnel ? |
| :--- | :--- | :--- | :--- |
| `scf.in` | Input SCF équilibre (paramètres DFT du matériau) | `pw.x` (input) | Non |
| `ph.in` | Input phonons DFPT (auto-généré par `ph_input_from_pw.try_autogenerate_ph_in` si absent) | `ph.x` (input) | Non |
| `q2r.in` | Input q2r (`fildyn='ph_dyn'`, `flfrc='fc.out'`) | `q2r.x` (input) | Non |
| `fc.out` | Constantes de force dans l'espace réel (`flfrc='fc.out'`) | `q2r.x` | Non |
| `phonon.freq` | Spectre des fréquences phononiques (dispersions) | `matdyn.x` | Non |
| `phonon.dos` | DOS phononique brute | `matdyn.x` | Non |
| `phonon_bands.png` | Plot bandes phononiques | `gnuplot` (depuis `phonon_bands_plot.dat`) | Non |
| `phonon_dos.png` | Plot DOS phonon | `gnuplot` (depuis `phonon.dos`) | Non |
| `thermo_pw_run.out` | Journal principal thermo_pw (C_ij + C_ij-derived) | `thermo_pw.x` | Non |
| `output_el_cons.dat` | Matrice des constantes élastiques $C_{ij}$ (kbar, 6×6 Voigt brut) | `thermo_pw.x` | Non |
| `nscf.in` / `nscf.out` | NSCF restart_mode='restart' (relecture du `.save/`) | `pw.x` (NSCF) | Non (`properties_enabled=True` + `ichamp=3`) |
| `dos.dat` | Densité d'états électronique brute (deux colonnes : E(eV), N(E)) | `dos.x` | Non (`ichamp=3`) |
| `bands.dat` | Bandes électroniques K-S (chemin auto-généré depuis `ibrav`) | `bands.x` | Non (`ichamp=3`) |
| `edos.png` | Plot DOS (graphe PNG colorisé, trait vertical au niveau de Fermi) | `gnuplot` (depuis `dos.dat`) | Non (`ichamp=3`) |
| `ebands.png` | Plot bandes électroniques E(k) (PNG colorisé) | `gnuplot` (depuis `bands.dat`) | Non (`ichamp=3`) |
| `BORN` | ε_∞ en notation Voigt (3×3) + Z* par atome | `lo_to_chain.write_born_file` | **Opt-in** (`lo_to_opt_in=True`) |
| `dielectric.lo_to_splitting_cm⁻¹` | Splitting LO–TO exposé dans le marker `pipeline_api_job_state.json` | parser `parsers/dielectric` | **Opt-in** `lo_to_opt_in=True` (clé UI, pas un fichier) |

> **⚠️ Opt-in LO/TO** : les 2 dernières lignes n'apparaissent que si `lo_to_opt_in=True` est passé à `PipelineJob.__init__` (bouton UI P1 dédié ou `POST /api/pipeline/run { "lo_to_opt_in": true }`). Refuse les pseudos US-PP / PAW (cf. `lo_to_chain.check_pseudos_are_nc`).

---

## P2 — Thermique QHA (`what='mur_lc_t'` ; legacy UI `thermo` réécrit par l'API → canonique 7.x)

Équation d'État Birch–Murnaghan + phonons DFPT (grille 4×4×4) + grandeurs thermodynamiques vs Température (ΔT = 50 K).

### Fichiers de sortie

| Fichier | Description | Origine (binaire/étape) | Conditionnel ? |
| :--- | :--- | :--- | :--- |
| `scf.in` | Input SCF | `pw.x` | Non |
| `ph.in` | Input phonons DFPT (auto-généré par `ph_input_from_pw.try_autogenerate_ph_in` si absent) | `ph.x` (input) | Non |
| `q2r.in` | Input q2r (`fildyn='ph_dyn'`, `flfrc='fc.out'`) | `q2r.x` (input) | Non |
| `fc.out` | Constantes de force dans l'espace réel (`flfrc='fc.out'`) | `q2r.x` | Non |
| `phonon.freq` | Spectre des fréquences phononiques | `matdyn.x` | Non |
| `phonon.dos` | DOS phononique brute | `matdyn.x` | Non |
| `phonon_bands.png` | Plot bandes phononiques | `gnuplot` (depuis `phonon_bands_plot.dat`) | Non |
| `phonon_dos.png` | Plot DOS phonon | `gnuplot` (depuis `phonon.dos`) | Non |
| `thermo_pw_run.out` | Journal thermo_pw (QHA complete, alias historique `mur_lc_t`) | `thermo_pw.x` | Non |
| `1_eos_volumes/eos_curve.dat`, `1_eos_volumes/eos_points.dat` | E(V) brute de la grille EOS | `pw.x` (boucle volumes) | Non |
| `1_eos_volumes/eos_ev.png` | Plot E(V) + fit Birch–Murnaghan | `gnuplot` | Non |
| `1_eos_volumes/eos_summary.json` | Résumé EOS parsé (V₀, B₀, B′, E₀) | `eos_paths` | Non |
| `nscf.in` / `nscf.out`, `dos.dat`, `bands.dat`, `edos.png`, `ebands.png` | Idem P1 (ichamp=3 par défaut) | `pw.x` / `dos.x` / `bands.x` / `gnuplot` | Non |

---

## P3 — Étude complète (`what='elastic_constants_geo'` ; legacy UI `mur_lc_t_elastic_constants` réécrit par l'API + legacy API `elastic`+grille T → canonique 7.x)

=P2 + constantes élastiques **vs Température** (T : 0 → 1000 K) avec `use_free_energy=.TRUE.` + `elastic_algorithm='energy'` (QHA + C_ij(T)).

### Fichiers de sortie

| Fichier | Description | Origine (binaire/étape) | Conditionnel ? |
| :--- | :--- | :--- | :--- |
| `scf.in`, `ph.in`, `q2r.in`, `fc.out`, `phonon.freq`, `phonon.dos` | Idem P2 (héritage explicite, Option A) | idem | Non |
| `thermo_pw_run.out` | Journal thermo_pw `what='elastic_constants_geo'` | `thermo_pw.x` | Non |
| `elastic_constants_vs_T.dat` | **C_ij(V₀,T) sur la grille 0→1000 K** (fichier P3 canonique) | `thermo_pw.x` | Non |
| `elastic_vs_T.dat`, `elastic_vs_temperature.dat` | Alias / variantes (cherchés en repli) | `thermo_pw.x` | Non |
| `elastic_vs_T_plot.png` | Plot C_ij(T) et modules VRH vs T | `gnuplot` | Non |
| `1_eos_volumes/eos_ev.png` | Idem P2 | `gnuplot` | Non |
| `nscf.in`, `nscf.out`, `dos.dat`, `bands.dat`, `edos.png`, `ebands.png` | Idem P1/P2 (ichamp=3) | idem | Non |

---

## P4 — Durée de vie des phonons / Anharmonicité (`what='ph_life'` ; legacy UI/API `qha_lif` réécrit par l'API → canonique 7.x)

=P3 + `τ_λ(ω)` par mode + `κ_lattice(T)` (anharmonicité 3-phonons). Demande `conv_thr ≤ 1.0D-12` dans `&ELECTRONS` de **scf.in** (PAS dans thermo_control — common mistake, cf. `templates/thermo_control_keys/`).

### Fichiers de sortie

| Fichier | Description | Origine (binaire/étape) | Conditionnel ? |
| :--- | :--- | :--- | :--- |
| `scf.in` (strict renforcé via `input_editor.reinforce_params(level='strict')`) | Input SCF avec conv_thr ≤ 1e-12 + pseudos NC high-stringency | `pw.x` | Non |
| `ph.in` | Idem P2/P3 (renforcé strict) | `ph.x` | Non |
| `q2r.in` | Input q2r (`fildyn='ph_dyn'`, `flfrc='fc.out'`) | `q2r.x` (input) | Non |
| `fc.out` | Constantes de force dans l'espace réel (`flfrc='fc.out'`) | `q2r.x` | Non |
| `phonon.freq`, `phonon.dos` | Spectre phonon (hérité P2/P3, sert de base au ph_life) | `matdyn.x` | Non |
| `thermo_pw_run.out` | Journal `what='ph_life'` (τ_λ, Γ_λ, κ_lattice, γ Grüneisen) | `thermo_pw.x` | Non |
| `1_eos_volumes/eos_ev.png` | Idem P2 | `gnuplot` | Non |
| `nscf.in`, `nscf.out`, `dos.dat`, `bands.dat`, `edos.png`, `ebands.png` | Ichamp=3 par défaut | idem | Non |

> ⚠️ **Note `ltherm_freq` vs `ltherm_dos`** : aucun fichier `.freq_N` par mode n'est forcé sur P4 (cohérence avec le pipeline de sortie thermo_pw `ph_life`). Si une représentation mode-par-mode est souhaitée, voir `ltherm_freq=.TRUE.` dans `templates/thermo_control_keys/README_ltherm_freq_vs_ltherm_dos.txt`.

---

## P5 — Propriétés diélectriques (`what='dielectric'`)

Tenseur diélectrique statique **ε_∞** (Berry phase) + charges effectives de Born **Z\*** via chaîne DFPT. La chaîne purement QE exhaustive (ε(ω) IPA/RPA + TDDFPT Lanczos + Davidon) est OPT-IN via les cases à cocher UI du panneau ②.

### Fichiers de sortie

| Fichier | Description | Origine (binaire/étape) | Conditionnel ? |
| :--- | :--- | :--- | :--- |
| `scf.in` | Input SCF équilibre | `pw.x` | Non |
| `ph.in` | Input phonons DFPT | `ph.x` | Non |
| `fc.out` | Constantes de force | `q2r.x` | Non |
| `phonon.freq`, `phonon.dos` | Spectre phonon (entrée DFPT) | `matdyn.x` | Non |
| `thermo_pw_run.out` | Journal thermo_pw `what='dielectric'` (ε_∞ + Born Z\*) | `thermo_pw.x` | Non |
| `nscf.in`, `nscf.out` | NSCF `ichamp=3` (sanity check gap avant ε(ω)) | `pw.x` | Non |
| `dos.dat`, `bands.dat`, `edos.png`, `ebands.png` | Idem P1-P4 | `dos.x` / `bands.x` / `gnuplot` | Non |
| `thermo_pw_plot_bz.out` | Journal plot_bz (visualisation BZ) | `thermo_pw.x` | **Opt-in** (`extra_whats=['plot_bz']`) |
| `BZ_plot.ps.gz`, `BZ.txt` | Artefacts BZ | post-process`plot_bz` | **Opt-in** (`plot_bz`) |
| `thermo_pw_piezoelectric_tensor.out` | Tenseur piézoélectrique e_ijk (C/m²) | `thermo_pw.x` | **Opt-in** (`extra_whats`) |
| `thermo_pw_magnetic_susceptibility.out` | Susceptibilité magnétique χ (SI) | `thermo_pw.x` | **Opt-in** (`extra_whats`) |
| `thermo_pw_magnetoelectric_tensor.out` | Tenseur magnétoélectrique α_ij | `thermo_pw.x` | **Opt-in** (`extra_whats`) |
| `thermo_pw_scf_dielectric.out` | Constante diélectrique statique ε_∞ (DFPT phonons inclus) | `thermo_pw.x` | **Opt-in** (`extra_whats`) |
| `nscf_optic.in`, `nscf_optic.out` | NSCF optique (nbnd × 2, `nosym`/`noinv`, grille k × 3) | `pw.x` | **Opt-in** `needs_optical=True` |
| `epsilon.in`, `epsilon.out` | IPA/RPA ε(ω) (wmin=0 eV, wmax=15 eV, nw=300, intersmear=0.136 eV) | `epsilon.x` | **Opt-in** `needs_optical=True` |
| `turbo_lanczos.in`, `turbo_lanczos.out` | TDDFPT Lanczos (itermax=500, ipol=4 = trace χ) | `turbo_lanczos.x` | **Opt-in** `needs_optical=True` |
| `turbo_davidson.in`, `turbo_davidson.out` | TDDFPT Davidson (fenêtre [0, 2] eV pas 0.002 eV, residue_conv_thr=1e-5) | `turbo_davidson.x` | **Opt-in** `needs_optical=True` |

### Opt-in LO/TO (BORN + mode NA phonon)

La sortie BORN (tenseur ε_∞ en notation Voigt 3×3 + charges effectives de Born Z* par atome, écrites par `lo_to_chain.write_born_file` dans `backend/lo_to_chain.py`) ainsi que les fréquences au point Γ séparées LO/TO (mode non-analytique / NA) **ne sont écrites que si `lo_to_opt_in=True`** est passé au constructeur `PipelineJob`. Cette opt-in est mutualisable entre les profils P1 et P5. Sans elle, ces artefacts ne sont pas générés.

| Fichier | Description | Origine | Conditionnel ? |
| :--- | :--- | :--- | :--- |
| `BORN` | ε_∞ en notation Voigt (3×3) + Z* par atome | `lo_to_chain.write_born_file` | **Oui** (`lo_to_opt_in=True`) |
| `phonon.freq_NA.dat` | Fréquences LO/TO au point Γ (matdyn.x en mode NA) | matdyn NA re-run | **Oui** (`lo_to_opt_in=True`) |

> ⚠️ **`needs_optical` opt-in** (case à cocher UI « Réponse diélectrique ε(ω) complète ») : les 8 derniers fichiers (`nscf_optic.*`, `epsilon.*`, `turbo_*.{in,out}`) ne sont produits **que** si la case est cochée. **Pseudos Norm-Conserving obligatoires** pour cette chaîne (epsilon.x / turbo_*.x refusent US-PP/PAW, cf. `lo_to_chain.check_pseudos_are_nc`).
>
> ⚠️ **`extra_whats` opt-in** (cases à cocher « Propriétés thermo_pw.x étendues ») : par défaut le profil P5 inclut `plot_bz`. L'utilisateur peut ajouter/retirer `piezoelectric_tensor`, `magnetic_susceptibility`, `magnetoelectric_tensor`, `scf_dielectric` via le panneau ② UI — chaque option ajoute son journal `thermo_pw_<what>.out`.

---

## Maintenance (juillet 2026)

Toute modification d'un profil dans `backend/pipeline.py:PROFILES[id]["outputs"]` ou `expected_results["files"]` **doit** être reportée ici. Une commande rapide pour vérifier la parité (à ajouter au CI) :

```bash
# Juillet 2026 — commande d'alignement par profil (remplace la diff globale qui
# était bruitée par les noms de fichiers mentionnés dans les sections opt-in P5
# et le tableau comparatif en haut du cheatsheet).
python3 backend/scripts/check_cheatsheet_alignment.py
echo $?     # 0 si tous les profils P1..P5 sont alignés, 1 sinon (drift par profil)
```

Sortie type en cas de drift :

```
== P3 DRIFT ==
  PROFILES-only  (1): ['elastic_constants_vs_T.dat']
  cheatsheet-only (0): []
DRIFT:P3
```

La commande échoue (exit 1) avec un rapport par profil : `PROFILES-only` (le fichier
existe côté backend mais n'est pas documenté dans le cheatsheet) ou `cheatsheet-only`
(l'inverse). À wirer dans le pre-commit / CI pour qu'elle bloque automatiquement toute
dérive silencieuse entre ``PROFILES`` et le cheatsheet.

---

## Voir aussi

- `templates/lo_to/README_canonique_P5.txt` — contrat LO/TO (ε_∞ + Z\* + matdyn non_analytic + NC pseudos)
- `templates/thermo_control_keys/README_ltherm_freq_vs_ltherm_dos.txt` — sémantique des commutateurs `ltherm_*`
- `backend/pipeline.py` (PROFILES dict, lignes ~130–530) — source de vérité canonique

Chaîne optique (Quantum ESPRESSO + turbo TDDFPT) — gabarits dans ce dossier
=============================================================================

Quel fichier passe en argument -in pour chaque exécutable (WF4 « Optique »)
---------------------------------------------------------------------------
  • pw.x
      Fichier conseillé dans l’interface : d’abord 01_pw_scf_optics.in puis
      02_pw_nscf_optics.in (renommez en pw.in ou remplissez le champ « fichier -in »).

  • turbo_lanczos.x
      turbo_lanczos.in (même prefix / outdir que le pw.x NSCF).

  • turbo_davidson.x
      turbo_davidson.in (idem).

  • epsilon.x
      epsilon.in — post-traitement « eps » avec &inputpp + &energy_grid (voir doc QE).
      Souvent : désactiver la réduction symétrie k-points (nosym/noinv dans le ou les pw.x)
      et prévoir nbnd dès SCF/NSCF ; epsilon.x n’accepte pas les pseudos ultra-doux.


Données COMMUNES à ne pas casser entre les étapes
-----------------------------------------------
  prefix     = si_optic          (identique partout, y compris turbo / epsilon)
  outdir     = le MÊME répertoire absolu que pour pw.x (sauvegarde WFC)
  pseudo_dir = le MÊME chemin que votre SCF hors optique
  ecutwfc, ecutrho, maille, espèces atomiques, K_POINTS : garder la Cohérence
    entre 01 (SCF), 02 (NSCF) pour que la densité et les états soient compatibles.

Ordre logique minimal (à adapter à votre tutoriel §1.26–1.27 / doc turbo)
-----------------------------------------------------------------------
  1) Copier les .in dans votre dossier sous work/… (ex. un_optic/… ou wf1_eos_… après test).
  2) Ajuster CHEMIN pseudo_dir / outdir (chemins ABSOLUS recommandés en production).
  3) pw.x avec 01_pw_scf_optics.in  → converge la densité.
  4) pw.x avec 02_pw_nscf_optics.in (nbnd large !) → états vide pour transitions optiques.
  5a) turbo_lanczos.x -in turbo_lanczos.in  OU
  5b) turbo_davidson.x -in turbo_davidson.in OU
      epsilon.x -in epsilon.in (si vous utilisez cette branche documentation).

Important physiques / numériques
--------------------------------
  • Après NSCF : nbnd doit couvrir largement au-delà du haut de valence sinon spectre faux.
  • Pour certains usages epsilon/k-point, la doc QE recommande nosym/noinv sur la grille k ;
    à vérifier pour votre système (_métaux_ : intrasmear, etc.).
  • Les exemples utilisent une maille compacte type Si diamant avec ecut renforcé (modifiable).
Branche epsilon.x + turbo_*.x (P5 exhaustive — réponse complète + TDDFPT)
---------------------------------------------------------------------
Le profil P5 « Optique exhaustive » du pipeline orchestre **3 chaînes**
complémentaires partageant la même NSCF_optic :

• epsilon.x utilise les états NSCF précédents avec &inputpp (calculation='eps')
  et définit la grille en énergie en eV via &energy_grid (wmin, wmax, nw, élargissement).
  → ε₁(ω), ε₂(ω), JDOS, EELS (réponse linéaire IPA/RPA, sans effets excitoniques).

• turbo_lanczos.x (paquet QE turbo/tddfpt) calcule la polarisabilité χ(ω)
  complète (TDDFPT Lanczos, correction XC dynamique via adiabatic LDA/GGA) →
  capture les **effets excitoniques** (décalage vers le rouge vs IPA).
  Itérations Lanczos typiques : 500 (convergence), ipol=4 (trace = somme
  cartésienne = absorption moyenne polycristalline).

• turbo_davidson.x (paquet QE turbo/tddfpt) calcule le spectre TDDFPT sur
  fenêtre spectrale restreinte [start, finish] (défaut [0, 2] eV = visible),
  état par état — utile pour identifier les transitions dominantes.
  Critère Davidson residue_conv_thr = 1e-5, max_iter = 120.

Toutes les trois lisent le même <prefix>.save/ laissé par la NSCF_optic
(restart_mode='restart') : un seul calcul lourd partagé, ROI maximal.

NB : si le paquet turbo/tddfpt n'est pas compilé sur votre installation,
les chaînes turbo sont simplement sautées avec un [WARN] propre (epsilon.x
reste utilisable). Compiler QE avec –enable-turbo=1 si vous souhaitez la
complétude P5.

Pour thermo_pw.x (option alternative — non utilisée par P5) : placer vos
entrées officielles (thermo_pw.in) ET le fichier thermo_control dans le
dossier du run ; consulter le user_guide §1.26–1.27 pour le mot-clé exact
what=… (spectre ε(ω), réflectivité…) — voir aussi
thermo_pw_optics_control_notes.txt dans ce dossier pour un aide-mémoire.

Éléments de matrice (<p>) et pseudopotentiels
---------------------------------------------
• Beaucoup de chaînes RPA/TDDFPT et epsilon.x reposent fortement sur des pseudo NC ou des
  hypothèses documentées QE ; les pseudos ultradows / PAW introduisent des termes correctifs
  (commutateur / [V_nl,r]) suivis différemment selon le module.
• Le WF4 exige une case « pseudos NC vérifiés » avant MPI : elle matérialise cette discipline.

Transitions inter-bandes → nbnd → grille k
----------------------------------------
• Le NSCF optique doit emporter systématiquement des bandes vides jusqu’aux transitions à
  couvrir (nbnd >> valence pure).
• En principe utilisez une grille de points **k** NSCF AU MOINS aussi dense que le SCF, et en
  pratique souvent PLUS dense que le SCF de démarrage pour lisser la densité JDOS / χ(ω).
  Le champ « memo » du WF4 (nbnd) est indicatif ; K_POINTS doit être revisité fichier par fichier.

Références
----------
  Documentation officielle QE : turbo_lanczos.x, turbo_davidson.x, epsilon.x ;
  tutoriel thermo_pw §1.26–1.27 (alignement « what » avec thermo_pw.x si vous l’utilisez).

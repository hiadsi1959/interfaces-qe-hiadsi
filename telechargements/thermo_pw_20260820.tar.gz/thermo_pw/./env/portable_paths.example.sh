#!/usr/bin/env bash
# =============================================================================
# Copiez ce fichier vers env/local.sh puis adaptez les chemins du nouveau PC :
#   cp env/portable_paths.example.sh env/local.sh
# DEMARRER.sh charge automatiquement env/local.sh s'il existe.
#
# Les variables ci‑dessous correspondent à backend/config.py (priorité env).
# =============================================================================

export USER_HOME="${USER_HOME:-$HOME}"

# Quantum ESPRESSO — binaires (pw.x, ph.x, thermo_pw.x…)
export THERMO_QE_BIN="${THERMO_QE_BIN:-$USER_HOME/q-e-qe-7.5/bin}"

# Racine du dépôt thermo_pw (laisser vide pour auto‑détection depuis config.py)
# export THERMO_REPO_ROOT="$USER_HOME/thermo_pw"

export THERMO_WORK_ROOT="${THERMO_WORK_ROOT:-$USER_HOME/thermo_pw/work}"
export THERMO_INPUTS_DIR="${THERMO_INPUTS_DIR:-$USER_HOME/thermo_pw/inputs}"
export THERMO_OUTPUTS_DIR="${THERMO_OUTPUTS_DIR:-$USER_HOME/thermo_pw/outputs}"

# Pseudopotentiels — dossier passé dans pseudo_dir lors de l’application des chemins
export THERMO_PSEUDOS_DIR="${THERMO_PSEUDOS_DIR:-$USER_HOME/thermo_pw/pseudos/PBE}"

# MPI — nombre de processus par défaut côté API (l’interface peut surcharger par lancement).
# PC type i9-14900K : 24 cœurs physiques → souvent 16–24 ici (éviter de dépasser sans raison les cœurs
# réellement utiles au calcul). Avec 64 Go de RAM, grosses grilles EOS / phonons restent confortables.
# export THERMO_MPI_NPROC="24"
# Hybride MPI+OpenMP (si votre build QE le permet) : en général 1 thread OpenMP par rang MPI
# export OMP_NUM_THREADS="1"

# Autres interfaces / outils (pour vos scripts hors thermo_pw ; à sourcer à la main si besoin)
export INTERFACE_QE_V1="${INTERFACE_QE_V1:-$USER_HOME/Interface-QE_v1}"
export GEN_INPUTS_QE="${GEN_INPUTS_QE:-$USER_HOME/génération_inputs-QE}"
export GEN_PSEUDOS="${GEN_PSEUDOS:-$USER_HOME/generation_pseudos}"

# Chaîne PATH (optionnel ; évite d’exporter deux fois si déjà fait dans .bashrc)
case ":$PATH:" in
  *:"$THERMO_QE_BIN":*) ;;
  *) export PATH="$PATH:$THERMO_QE_BIN" ;;
esac

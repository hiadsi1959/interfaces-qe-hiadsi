import ast
from pathlib import Path

F = Path('/home/hiadsi/thermo_pw/backend/pipeline.py')
text = F.read_text(encoding='utf-8')
original = text

# Anchor : unique EXACT-match on the /restart decorator line (4-space indent).
ANCHOR = '    @bp.route("/api/pipeline/jobs/<job_id>/restart", methods=["POST"])\n'
hits = text.count(ANCHOR)
assert hits == 1, f'ANCHOR found {hits} times (must be exactly 1) -- abort'
i = text.find(ANCHOR)
assert i != -1

# Pre-state AST validation
ast.parse(original)

NEW_BLOCK = '''    @bp.route("/api/pipeline/jobs/<job_id>/reparse", methods=["POST", "GET"])
    def reparse_pipeline_job(job_id: str):
        """Re-parse les sorties d'un job existant SANS relancer MPI.

        Delegated to ``PipelineJob._intermediate_parse`` which encodes
        the silent fall-through requested by the user :

          * lit ``thermo_pw_run.out`` quand present ;
          * tente TOUJOURS ensuite ``merge_elastic_from_output_el_cons_files(wd)``
            pour peupler C11/C12/C44 depuis les ``output_el_cons.dat.gN``
            meme quand ``thermo_pw_run.out`` est absent (cas run interrompu) ;
          * pose ``results._reparse.elastic_source = "fallback_per_strain_gN"``
            dans cette branche (badge UI « Apercu partiel ») ;
          * pose ``results._reparse.thermo_pw_run_missing = True`` et log diagnostic ;
          * pose systematiquement ``results._reparse.last_reparse_utc``.

        Codes de retour :
          * 200 + {ok, job_id, work_dir, results} -> reparse fructueux.
          * 404 si ``job_id`` inconnu du registre memoire (cas zombie ; faire
                 d'abord ``POST /api/pipeline/runs/<id>/load``).
          * 409 si ``work_dir`` absent du registre (job running sans dossier).
          * 500 si exception non geree : ``exception`` class name expose cote UI.

        Idempotent : re-appelable sans relancer MPI.
        """
        from flask import current_app  # noqa: WPS433
        job = PipelineJob._REGISTRY.get(job_id)
        if job is None:
            return jsonify({"error": "job_inconnu", "job_id": job_id}), 404
        if not job.work_dir:
            return jsonify({
                "error": "work_dir absent du registre en memoire",
                "job_id": job_id,
                "hint": "Charger le marker disque via POST /api/pipeline/runs/<id>/load.",
            }), 409
        try:
            return job._intermediate_parse(Path(job.work_dir), "reparse_via_route")
        except (RuntimeError, FileNotFoundError) as exc:
            current_app.logger.warning(
                "[reparse_pipeline_job] %s job_id=%s : %s",
                type(exc).__name__, job_id, exc,
            )
            return jsonify({
                "ok": False, "error": str(exc), "job_id": job_id,
                "status": getattr(job, "status", "unknown"),
            }), 409
        except Exception as exc:  # noqa: BLE001
            current_app.logger.exception(
                "[reparse_pipeline_job] unexpected error job_id=%s", job_id,
            )
            return jsonify({
                "ok": False, "error": "internal",
                "exception": exc.__class__.__name__, "job_id": job_id,
            }), 500

'''

# Insert BEFORE the anchor (anchor becomes the next decorator below).
new_text = text[:i] + NEW_BLOCK + text[i:]

# Post-state AST validation
ast.parse(new_text)

delta = len(new_text.encode('utf-8')) - len(text.encode('utf-8'))
print(f'[pre]   bytes={len(text.encode("utf-8"))}')
print(f'[post]  bytes={len(new_text.encode("utf-8"))}')
print(f'[io]    delta=+{delta}')

F.write_text(new_text, encoding='utf-8')

# Verify
post = F.read_text(encoding='utf-8')
print(f'[verify] /reparse   * {post.count("/api/pipeline/jobs/<job_id>/reparse")}')
print(f'[verify] /restart   * {post.count("/api/pipeline/jobs/<job_id>/restart")}')
print(f'[verify] def reparse_pipeline_job * {post.count("def reparse_pipeline_job")}')
print(f'[verify] def _intermediate_parse * {post.count("def _intermediate_parse")}')
print(f'[verify] reparse_via_route step label * {post.count("reparse_via_route")}')
print(f'[verify] fallback_per_strain_gN tag * {post.count("fallback_per_strain_gN")}')
print(f'[verify] current_app import inside handler * {post.count("from flask import current_app")}')
print('[ast] AST_OK')

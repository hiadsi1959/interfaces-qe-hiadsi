"""
Test end-to-end direct du module electronic_props sur le pipeline P2 Si récent.

Ce script NE MODIFIE PAS le code source. Il utilise :
  - les artefacts SCF d'équilibre déjà produits :
      work/Si/pipeline_P2_1782509622_fbf3ea/out_scf_eq/scf_eq.save/
  - le fichier d'entrée d'équilibre : pw_scf_V0_for_phonon.in
  - le module backend/electronic_props.py et ses helpers.

Il lance la chaîne ichamp=3 (NSCF → dos.x → pw bands → bands.x → gnuplot),
puis imprime le dictionnaire complet produit par ElectronicPropsResult.
"""
from __future__ import annotations

import sys
import json
from pathlib import Path

# Injecte backend/ dans le PYTHONPATH
BACKEND = Path(__file__).parent / "backend"
sys.path.insert(0, str(BACKEND))

from electronic_props import run_electronic_properties  # noqa: E402

WORK_DIR = Path(__file__).parent / "work" / "Si" / "pipeline_P2_1782509622_fbf3ea"


def main() -> int:
    if not WORK_DIR.is_dir():
        print(f"[FAIL] workdir absent : {WORK_DIR}", file=sys.stderr)
        return 2
    scf = WORK_DIR / "pw_scf_V0_for_phonon.in"
    if not scf.is_file():
        print(f"[FAIL] {scf} absent.", file=sys.stderr)
        return 2

    print(f"[INFO] work_dir = {WORK_DIR}")
    print(f"[INFO] scf     = {scf.name}")
    print(f"[INFO] Lancement ichamp=3 (nproc=4)…")
    res = run_electronic_properties(
        work_dir=WORK_DIR,
        nproc=4,
        scf_basename="pw_scf_V0_for_phonon.in",
        ichamp=3,
        log_emit=print,
    )

    d = res.to_dict()
    print("\n=== ElectronicPropsResult.to_dict() ===")
    print(json.dumps(d, indent=2, default=str))

    # Résumé compact
    print("\n=== RÉSUMÉ ===")
    print(f"  ichamp       : {d['ichamp']}")
    print(f"  nscf_ok      : {d['nscf_ok']}")
    print(f"  dos_ok       : {d['dos_ok']}")
    print(f"  bands_ok     : {d['bands_ok']}")
    print(f"  fermi_eV     : {d['fermi_eV']}")
    print(f"  n_bands      : {d['n_bands']}")
    print(f"  gap_eV       : {d['gap_eV']}")
    print(f"  vbm_eV       : {d['vbm_eV']}")
    print(f"  cbm_eV       : {d['cbm_eV']}")
    print(f"  gap_type     : {d['gap_type']}")
    print(f"  gap_direct   : {d['gap_direct']}")
    print(f"  ebands_image : {d['ebands_image']}")
    print(f"  edos_image   : {d['edos_image']}")
    print("\n=== NOTES ===")
    for ln in d["notes"]:
        print(f"  {ln}")

    # Vérifie artefacts sur disque
    print("\n=== ARTEFACTS ===")
    for nm in ("nscf.in", "nscf.out", "dos.in", "dos.out", "dos.dat",
               "pw_bands.in", "bands.out", "bands.dat",
               "edos.png", "ebands.png", "edos.plt.log", "ebands.plt.log"):
        p = WORK_DIR / nm
        if p.is_file():
            sz = p.stat().st_size
            print(f"  OK  {nm}  ({sz} octets)")
        else:
            print(f"  --  {nm}  (absent)")

    # Assertions automatiques sur les valeurs de Si (PBE).
    print("\n=== ASSERTIONS Si (PBE) ===")
    assertions = []
    if d["nscf_ok"]:
        assertions.append(("nscf_ok = True", d["nscf_ok"] is True))
    if d["dos_ok"]:
        assertions.append(("dos_ok = True", d["dos_ok"] is True))
    if d["bands_ok"]:
        assertions.append(("bands_ok = True", d["bands_ok"] is True))
    if d["fermi_eV"] is not None:
        assertions.append((f"fermi_eV ≈ 5-6 eV (got {d['fermi_eV']:.3f})",
                          4.5 <= d["fermi_eV"] <= 6.5))
    if d["gap_eV"] is not None:
        # Si PBE donne ~0.5–0.9 eV (gap indirect Γ→Δ).
        if d["gap_type"] == "metal":
            assertions.append((f"gap — Si métal inattendu (got {d['gap_eV']})", False))
        else:
            assertions.append((f"gap_eV ∈ [0.2, 1.5] (got {d['gap_eV']:.3f})",
                              0.2 <= d["gap_eV"] <= 1.5))
    if d["edos_image"]:
        sz = (WORK_DIR / d["edos_image"]).stat().st_size
        assertions.append((f"{d['edos_image']} > 1 KB (got {sz})", sz > 1024))
    if d["ebands_image"]:
        sz = (WORK_DIR / d["ebands_image"]).stat().st_size
        assertions.append((f"{d['ebands_image']} > 1 KB (got {sz})", sz > 1024))

    all_ok = True
    for label, ok in assertions:
        flag = "PASS" if ok else "FAIL"
        print(f"  [{flag}] {label}")
        all_ok = all_ok and ok
    print(f"\n=== VERDICT === {'ALL PASS' if all_ok else 'SOME FAILURES'}")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())

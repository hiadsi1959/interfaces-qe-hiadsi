/* ==========================================================================
   app_v2.js — UI 5 profils · workflow 4 étapes (matériau, thermo_pw.in, lancer, résultats).

   Étapes utilisateur :
     1. Charger matériaux et profils.
     2. Sélection matériau (carte ①) → peuplement scf.in + preview scf.in.
     3. Sélection profil (tuile)     → génération aperçu thermo_pw.in (carte ②).
     4. Bouton « Lancer la série »    → POST /api/pipeline/run, polling, live results.
   ========================================================================== */

(function () {
  "use strict";

  const $ = (sel) => document.querySelector(sel);
  const dom = {
    apiStatus: $("#apiStatus"),
    profileGrid: $("#profileGrid"),
    tileTpl: $("#tplProfileTile"),
    // ①
    matSelect: $("#matSelect"),
    scfIn: $("#scfIn"),
    nproc: $("#nproc"),
    machineInfo: $("#machineInfo"),
    matInfo: $("#matInfo"),
    kvCount: $("#kvCount"),
    kvPath: $("#kvPath"),
    scfPreviewBox: $("#scfPreviewBox"),
    scfPreviewBody: $("#scfPreviewBody"),
    scfPreviewMeta: $("#scfPreviewMeta"),
    // ②
    tpwinIdentity: $("#tpwinIdentity"),
    tpwinParams: $("#tpwinParams"),
    tpwinPreviewBody: $("#tpwinPreviewBody"),
    // ③
    launchBtn: $("#launchBtn"),
    cancelBtn: $("#cancelBtn"),
    restartBtn: $("#restartBtn"),
    resumeThermoBtn: $("#resumeThermoBtn"),
    resumeGroup: $("#resumeGroup"),
    launchState: $("#launchState"),
    progressWrap: $("#progressWrap"),
    progressBar: $("#progressBar"),
    progressText: $("#progressText"),
    doneBanner: $("#doneBanner"),
    logBox: $("#logBox"),
    // ④
    resultsCard: $("#resultsCard"),
    resultEmpty: $("#resultEmpty"),
    // --- P5 extras (juin 2026) ---
    p5ExtrasPanel: $("#p5ExtrasPanel"),
    p5ExtrasList: $("#p5ExtrasList"),
    // --- P1 preset « Cᵢⱼ + DOS + Bandes » (juillet 2026) ---
    // Manquaient du mapping dom → le panneau ne s'affichait jamais et le
    // flag ``p1_full_preset`` n'était jamais envoyé au backend.
    p1PresetPanel: $("#p1PresetPanel"),
    p1PresetCheckbox: $("#p1PresetCheckbox"),
    // --- Opt-ins juillet 2026 : LO/TO (P1) + chaîne optique ε(ω) (P5) ---
    loToCheckbox: $("#loToCheckbox"),
    p5OpticalCheckbox: $("#p5OpticalCheckbox"),
    resultWorkdir: $("#resultWorkdir"),
    resultWorkdirPath: $("#resultWorkdirPath"),
    resultWorkdirBadge: $("#resultWorkdirBadge"),
    resultWorkdirHint: $("#resultWorkdirHint"),
    resultWorkdirCopy: $("#resultWorkdirCopy"),
    resultSummary: $("#resultSummary"),
    resultsTensorPanels: $("#resultsTensorPanels"),
    propertyGapsPanel: $("#propertyGapsPanel"),
    resultFiles: $("#resultFiles"),
    resultPlots: $("#resultPlots"),
    cvCpChartPanel: $("#cvCpChartPanel"),
    cvCpChart: $("#cvCpChart"),
    cvCpChartTitle: $("#cvCpChartTitle"),
    cvCpChartHint: $("#cvCpChartHint"),
    cvCpChartTooltip: $("#cvCpChartTooltip"),
    resultsMeta: $("#resultsMeta"),
    // ④ (picker « Charger un calcul précédent »)
    runsPicker: $("#runsPicker"),
    runsSelect: $("#runsSelect"),
    runsRefresh: $("#runsRefresh"),
    runsLoad: $("#runsLoad"),
    runsCompareSelect: $("#runsCompareSelect"),
    runsCompareBtn: $("#runsCompareBtn"),
    runsComparePanel: $("#runsComparePanel"),
    runsCompareHead: $("#runsCompareHead"),
    runsCompareBody: $("#runsCompareBody"),
    runsCompareTitle: $("#runsCompareTitle"),
    runsReparse: $("#runsReparse"),
    runsLoaded: $("#runsLoaded"),
    runsLoadedText: $("#runsLoadedText"),
    runsClear: $("#runsClear"),
    // Juin 2026 — bouton 🗑 « Supprimer définitivement ce run ». Manquait du
    // mapping dom → le handler (setupRunsPickerHandlers) n'était jamais câblé.
    runsDelete: $("#runsDelete"),
    runsCount: $("#runsCount"),
    // Juillet 2026 — bouton « 📋 Fiche technique » (section ④ picker).
    runsFactsheet: $("#runsFactsheet"),
    runsFactsheetFmt: $("#runsFactsheetFmt"),
    runsPurgeStale: $("#runsPurgeStale"),
    runsPurgeStaleCount: $("#runsPurgeStaleCount"),
    // ④ (sanity-checks scientifiques)
    sanityBlock: $("#sanityBlock"),
    sanitySummary: $("#sanitySummary"),
    sanityList: $("#sanityList"),
    resultsExpertise: $("#resultsExpertise"),
    expertiseSummary: $("#expertiseSummary"),
    expertiseList: $("#expertiseList"),
    expertiseFactsheetBtn: $("#expertiseFactsheetBtn"),
    // Home page
    navHome: $("#navHome"),
    navWorkspace: $("#navWorkspace"),
    homeView: $("#homeView"),
    workspaceView: $("#workspaceView"),
    homeProfileList: $("#homeProfileList"),
    homeFeatures: $("#homeFeatures"),
    homeElectronicInsights: $("#homeElectronicInsights"),
    homeStartBtn: $("#homeStartBtn"),
    goResultsBtn: $("#goResultsBtn"),
    workflowStepper: $("#workflowStepper"),
    launchBarHero: document.querySelector(".launch-bar-hero"),
  };

  const state = {
    materials: [],
    profiles: [],
    selectedMaterialId: "",
    selectedScfBasename: "",
    selectedProfileId: "",
    selectedProfileExpected: null,
    currentJobId: "",
    pollTimer: null,
    scfPreviewLoadedFor: "",
    tpwinPreviewLoadedFor: "",
    // Estimations de durée par profil (août 2026), indexées par id de profil.
    // ``profileEstimatesFor`` mémorise la clé matériau/scf.in/nproc déjà
    // servie afin de ne pas re-solliciter l'API à chaque re-rendu.
    profileEstimates: {},
    profileEstimatesFor: "",
    // Espace disque estimé par profil, servi par le même appel au catalogue.
    profileStorage: {},
    machineInfo: null,
    progressEtaText: "",
    // Run chargé depuis le picker (section ④) — indépendant du ``currentJobId``
    // (qui représente un job en cours). ``loadedJobId`` est le job_id du
    // run persisté dont on affiche les résultats ; ``loadedRecord`` est son
    // ``to_dict()`` conservé pour re-rendres rapides.
    loadedJobId: "",
    loadedRecord: null,
    pickerBusy: false,
    // Job en vol côté picker — distinct de ``pickerBusy`` pour que les
    // changements successifs du <select> soient sérialisés (et non perdus).
    inFlightJobId: "",
    runsCache: [],
    compareBusy: false,
    reparseBusy: false,
    currentView: "home",
    profilesRaw: [],
    lang: "fr",
  };

  function t(key, vars) {
    if (!window.ThermoI18n) return key;
    if (vars && typeof vars === "object") {
      return window.ThermoI18n.tf(key, vars, state.lang);
    }
    return window.ThermoI18n.t(key, state.lang);
  }

  function applyLanguage(lang) {
    if (!window.ThermoI18n) return;
    state.lang = window.ThermoI18n.setLang(lang);
    state.profiles = window.ThermoI18n.localizeProfiles(state.profilesRaw, state.lang);
    window.ThermoI18n.applyStaticUI(state.lang);
    renderProfiles();
    renderHomePage();
    renderElectronicInsights();
    renderPropertyGapsPanel(_jobForGapsAndArtifacts());
    if (state.selectedProfileId) {
      renderProfilePreview();
      renderP5ExtrasPanel();
      renderP1PresetPanel();
    }
    refreshTpwinPreview(true);
    const ugModal = document.getElementById("usageGuideModal");
    if (ugModal && ugModal.open) renderUsageGuideContent();
    if (state.currentJobId || state.loadedJobId) {
      fetchAndRenderArtifacts(state.currentJobId || state.loadedJobId);
    }
    const idleLabel = dom.launchState && dom.launchState.querySelector(".state-label");
    if (idleLabel && dom.launchBtn && dom.launchBtn.disabled && !state.currentJobId) {
      setLaunchState("idle", t("sec3.idle"));
    }
    const logBox = dom.logBox;
    if (logBox && logBox.textContent && logBox.textContent.indexOf("—") === 0) {
      logBox.textContent = t("sec3.logIdle");
    }
    if (dom.scfPreviewBody && !state.selectedMaterialId) {
      dom.scfPreviewBody.textContent = t("sec1.selectMat");
    }
    if (dom.tpwinPreviewBody && !state.selectedProfileId) {
      dom.tpwinPreviewBody.textContent = t("sec2.waitSelection");
    }
    updateLaunchButton();
    if (state.runsCache && state.runsCache.length && dom.runsSelect) {
      for (const opt of dom.runsSelect.options) {
        if (!opt.value) continue;
        const run = state.runsCache.find((x) => x.job_id === opt.value);
        if (run) opt.textContent = formatRunOptionLabel(run);
      }
    }
    refreshApiStatus();
  }

  // Juillet 2026 — notifications toast (axe 4). Coexiste avec appendLog (journal live).
  // showToast("Stop demandé", "info") ; showToast("Erreur X", "error") ; etc.
  // Auto-fermeture après 4s ; survol souris suspend l'auto-close pendant 1.8s.
  // role="status" + aria-live="polite" sur le container (accessibilité).
  function showToast(message, kind = "info", durationMs = 4000) {
    const container = document.getElementById("toastContainer");
    if (!container) return;
    const el = document.createElement("div");
    el.className = "tpw-toast toast-" + kind;
    el.textContent = String(message || "");
    let autoClose = setTimeout(() => fadeAndRemove(), durationMs);
    function fadeAndRemove() {
      if (!el.parentNode) return;
      el.classList.add("is-fading");
      setTimeout(() => { if (el.parentNode) el.remove(); }, 420);
    }
    el.addEventListener("mouseenter", () => {
      if (autoClose) { clearTimeout(autoClose); autoClose = null; }
    });
    el.addEventListener("mouseleave", () => {
      autoClose = setTimeout(fadeAndRemove, 1800);
    });
    container.appendChild(el);
  }

  // Juillet 2026 — panneau Artefacts : grandeurs parsées + fichiers disque
  // depuis GET /api/pipeline/runs/<jobId>/files (+ job pour métriques).
  async function fetchAndRenderArtifacts(jobId) {
    const panel = document.getElementById("artifactsPanel");
    const list = document.getElementById("artifactsList");
    const count = document.getElementById("artifactsCount");
    if (!panel || !list) return;
    if (!jobId) {
      panel.hidden = true;
      list.innerHTML = "";
      if (count) count.textContent = "";
      if (dom.resultFiles) dom.resultFiles.hidden = false;
      return;
    }
    try {
      const filesP = fetch("/api/pipeline/runs/" + encodeURIComponent(jobId) + "/files", {
        credentials: "omit",
      }).then((res) => { if (!res.ok) throw new Error("HTTP " + res.status); return res.json(); });
      const jobP = fetch("/api/pipeline/jobs/" + encodeURIComponent(jobId), {
        credentials: "omit",
      }).then((res) => (res.ok ? res.json() : null)).catch(() => null);
      const [r, job] = await Promise.all([filesP, jobP]);
      if (!r || !r.kinds) { panel.hidden = true; return; }

      list.innerHTML = "";
      const results = (job && job.results) || (state.loadedRecord && state.loadedRecord.job_id === jobId
        ? state.loadedRecord.results
        : null) || {};

      // --- Section grandeurs parsées (contrat profil — P1..P5) ---
      const { rows: parsedRows, parsedFilled } = _buildParsedArtifactRows(job, results);

      let totalShown = 0;
      if (job && job.job_id) {
        const head = document.createElement("div");
        head.className = "artifact-section-head";
        head.textContent =
          "📊 " +
          t("artifacts.parsedSection") +
          " (" +
          t("artifacts.parsedCount", {
            filled: String(parsedFilled),
            total: String(parsedRows.length),
          }) +
          ")";
        list.appendChild(head);
        for (const row of parsedRows) {
          totalShown++;
          const el = document.createElement("div");
          el.className =
            "artifact-item artifact-metric" +
            (row.filled ? " artifact-metric-filled" : " artifact-metric-absent");
          const badge = row.filled
            ? '<span class="badge badge-val">val</span>'
            : '<span class="badge badge-absent">—</span>';
          const valText = row.filled ? fmt(row.val, 4, row.def.key) : "—";
          const unit = row.def.unit ? " " + escapeHtml(row.def.unit) : "";
          const srcLabel = row.src
            ? formatThermoSource(row.src, row.def.sourceKey)
            : null;
          let footHtml = "";
          if (srcLabel) {
            footHtml =
              `<div class="artifact-metric-src muted">${escapeHtml(t("artifacts.metricSource"))} : ${escapeHtml(srcLabel)}</div>`;
          } else if (!row.filled) {
            footHtml =
              `<div class="artifact-metric-desc muted">${escapeHtml(_metricAbsentReason(row.def.key, job, results))}</div>`;
          } else if (row.def.gapKey) {
            footHtml =
              `<div class="artifact-metric-desc muted">${escapeHtml(t(row.def.gapKey))}</div>`;
          }
          el.innerHTML =
            badge +
            `<span class="artifact-name">${escapeHtml(row.def.label)} = ` +
            `<strong class="artifact-metric-val">${escapeHtml(valText)}${unit}</strong></span>` +
            footHtml;
          list.appendChild(el);
        }
      } else if (job && String(job.status || "") === "done") {
        const empty = document.createElement("div");
        empty.className = "artifact-section-empty muted";
        empty.textContent = t("artifacts.noParsedYet");
        list.appendChild(empty);
      }

      // --- Section fichiers (déduplique .ps si .pdf sibling) ---
      const order = ["png", "pdf", "ps", "gs", "dat", "in", "out", "json", "other"];
      let fileShown = 0;
      const filePaths = [];
      for (const kind of order) {
        const paths = _dedupePsWhenPdf((r.kinds && r.kinds[kind]) || []);
        for (const p of paths) filePaths.push({ kind, p });
      }
      if (filePaths.length) {
        const head = document.createElement("div");
        head.className = "artifact-section-head";
        head.textContent = "📁 " + t("artifacts.filesSection") + " (" + filePaths.length + ")";
        list.appendChild(head);
        for (const { kind, p } of filePaths) {
          fileShown++;
          totalShown++;
          const row = document.createElement("div");
          row.className = "artifact-item";
          const safeName = String(p).split("/").pop();
          const badge = '<span class="badge">' + escapeHtml(kind) + "</span>";
          const name = '<span class="artifact-name" title="' + escapeHtml(p) + '">' + escapeHtml(safeName) + "</span>";
          const buttons =
            '<button class="ai-btn-view" type="button" title="' + escapeHtml(safeName) + '">' +
            escapeHtml(t("artifacts.view")) + '</button>' +
            '<button class="ai-btn-open" type="button" title="' + escapeHtml(safeName) + '">' +
            escapeHtml(t("artifacts.open")) + '</button>';
          row.innerHTML = badge + name + buttons;
          row.querySelector(".ai-btn-view").addEventListener("click", () =>
            openArtifactPreview(jobId, p, kind)
          );
          row.querySelector(".ai-btn-open").addEventListener("click", () =>
            openArtifactInNewTab(jobId, p, kind)
          );
          list.appendChild(row);
        }
      }

      if (count) {
        count.textContent = t("artifacts.count", {
          shown: totalShown,
          total: fileShown + parsedRows.length,
        });
      }
      panel.hidden = totalShown === 0 && !parsedRows.length;
      // Évite la redondance chips « fichiers attendus » vs listing exhaustif.
      if (dom.resultFiles) {
        dom.resultFiles.hidden = totalShown > 0 || fileShown > 0;
      }
      if (job) renderPropertyGapsPanel(job);
    } catch (e) {
      if (typeof appendLog === "function") {
        appendLog("[WARN] artefacts indisponibles pour " + (jobId || "").slice(0, 8) + " : " + (e.message || e), "err");
      }
      panel.hidden = true;
      if (dom.resultFiles) dom.resultFiles.hidden = false;
    }
  }

  function openArtifactInNewTab(jobId, relpath, kind) {
    const url =
      "/api/pipeline/runs/" + encodeURIComponent(jobId) +
      "/result_file?path=" + encodeURIComponent(relpath) + "&inline=1";
    const win = window.open(url, "_blank", "noopener,noreferrer");
    if (!win) showToast(t("toast.popupBlocked"), "warn");
  }

  async function openArtifactPreview(jobId, relpath, kind) {
    const dlg = document.getElementById("artifactPreviewModal");
    const title = document.getElementById("apmTitle");
    const meta = document.getElementById("apmMeta");
    const body = document.getElementById("apmBody");
    if (!dlg || !body) return;
    const fname = String(relpath).split("/").pop();
    if (title) title.textContent = fname || "(fichier)";
    if (meta) meta.textContent = relpath;
    body.innerHTML = '<p class="apm-loading">' + escapeHtml(t("apm.loading")) + '</p>';
    if (typeof dlg.showModal === "function") dlg.showModal(); else dlg.setAttribute("open", "");
    const url =
      "/api/pipeline/runs/" + encodeURIComponent(jobId) +
      "/result_file?path=" + encodeURIComponent(relpath) + "&inline=1";
    const ext = (fname.split(".").pop() || "").toLowerCase();
    const isImg = ["png", "jpg", "jpeg", "gif", "svg", "webp"].includes(ext);
    const isPdf = ext === "pdf";
    // AbortController : si la modale est fermée pendant le fetch (gros .out),
    // on annule la requête pour libérer la mémoire + ne pas écrire dans un
    // dialog déjà-fermé.
    const ctrl = (typeof AbortController !== "undefined") ? new AbortController() : null;
    function isClosed() {
      try { return !dlg.open; } catch (_e) { return false; }
    }
    try {
      if (isImg) {
        body.innerHTML = "";
        const img = document.createElement("img");
        img.alt = fname; img.src = url;
        body.appendChild(img);
        return;
      }
      if (isPdf) {
        body.innerHTML = "";
        const iframe = document.createElement("iframe");
        iframe.src = url; iframe.title = fname;
        // sandbox : limite les gadgets JS embarqués dans certains PDFs.
        // allow-same-origin pour que la barre d'outils PDF du navigateur
        // fonctionne (zoom, télécharger).
        iframe.setAttribute("sandbox", "allow-same-origin");
        body.appendChild(iframe);
        return;
      }
      const fetchOpts = { credentials: "omit" };
      if (ctrl) fetchOpts.signal = ctrl.signal;
      const resp = await fetch(url, fetchOpts);
      if (!resp.ok) throw new Error("HTTP " + resp.status);
      const text = await resp.text();
      if (isClosed()) return;  // modale fermée pendant le fetch : on jette silencieusement.
      const truncated = text.length > 200_000
        ? text.slice(0, 200_000) + "\n… (truncated, " + text.length + " bytes total)"
        : text;
      body.innerHTML = "";
      const pre = document.createElement("pre");
      const code = document.createElement("code");
      code.textContent = truncated;
      pre.appendChild(code);
      body.appendChild(pre);
    } catch (e) {
      if (e && e.name === "AbortError") return;
      if (isClosed()) return;
      body.innerHTML = '<p class="apm-error">Preview unavailable: ' + escapeHtml(e.message || String(e)) + "</p>";
    }
  }

  // Annulation du fetch en cours si la modale est fermée (bouton ✕ ou click
  // outside). Si pas de fetch en vol, no-op. Garantit qu'on n'écrit pas dans
  // un dialog fermé et qu'on libère la mémoire rapidement.
  function setupArtifactPreviewModal() {
    const dlg = document.getElementById("artifactPreviewModal");
    const closeBtn = document.getElementById("apmCloseBtn");
    if (!dlg) return;
    if (closeBtn) closeBtn.addEventListener("click", () => {
      if (_currentArtifactCtrl) {
        try { _currentArtifactCtrl.abort(); } catch (_e) {}
        _currentArtifactCtrl = null;
      }
      if (typeof dlg.close === "function") dlg.close(); else dlg.removeAttribute("open");
    });
    dlg.addEventListener("click", (ev) => {
      const rect = dlg.getBoundingClientRect();
      const inside = ev.clientX >= rect.left && ev.clientX <= rect.right &&
                     ev.clientY >= rect.top && ev.clientY <= rect.bottom;
      if (!inside) {
        if (_currentArtifactCtrl) {
          try { _currentArtifactCtrl.abort(); } catch (_e) {}
          _currentArtifactCtrl = null;
        }
        if (typeof dlg.close === "function") dlg.close(); else dlg.removeAttribute("open");
      }
    });
    // Stoppe un fetch en vol si la touche Echap ferme le dialog natif.
    dlg.addEventListener("close", () => {
      if (_currentArtifactCtrl) {
        try { _currentArtifactCtrl.abort(); } catch (_e) {}
        _currentArtifactCtrl = null;
      }
    });
  }
  // Compteur global pour pouvoir annuler le fetch en cours depuis la modale.
  let _currentArtifactCtrl = null;

  const POLL_INTERVAL_MS = 1500;
  const MAX_LOG_LINES = 600;

  // Libellés dossier de sortie : lus depuis ``storage_hint`` de chaque profil
  // (``GET /api/pipeline/profiles``). Fallback minimal si l'API est indisponible.
  const PROFILE_STORAGE_HINTS_FALLBACK = {
    P1: "Constantes Cᵢⱼ + modules VRH (thermo_pw what='scf_elastic_constants').",
    P2: "EOS + phonons + QHA vs T (thermo_pw what='mur_lc_t', ΔT=50 K).",
    P3: "P2 + Cᵢⱼ(V₀,T) (thermo_pw what='elastic_constants_geo').",
    P4: "P3 + phonon lifetimes (thermo_pw what='ph_life').",
    P5: "Phonons + ε∞ (thermo_pw what='dielectric') ; ε(ω) opt-in.",
  };

  // English labels for profile tiles (overrides API until Flask is restarted).
  const PROFILE_UI_EN = {
    P1: {
      name: "Mechanics 0 K",
      description:
        "SCF V₀ → thermo_pw what='scf_elastic_constants' → C_ij → VRH moduli (elasticity @ T=0 K). "
        + "DFPT phonons (4×4×4) → dynamic stability + dispersions. "
        + "NSCF + DOS + electronic bands (ichamp=3).",
    },
    P2: {
      name: "Thermal QHA",
      description:
        "7-point EOS grid (±3 %) + DFPT phonons (4×4×4) + thermo_pw what='mur_lc_t' "
        + "(QHA 7.x, API/UI alias: thermo) → thermodynamic quantities vs T (ΔT=50 K).",
    },
    P3: {
      name: "Full study",
      description:
        "P2 + thermo_pw what='elastic_constants_geo' on T grid 0→1000 K "
        + "→ C_ij(V₀,T) + polycrystalline moduli vs T.",
    },
    P4: {
      name: "Phonon lifetimes (Anharmonicity)",
      description:
        "P3 + thermo_pw what='ph_life' (legacy alias: qha_lif) → lifetime τ_λ(ω) per phonon mode "
        + "(3-phonon anharmonicity). Conv_thr ≤ 1.0D-12 (recommended in &ELECTRONS of scf.in).",
    },
    P5: {
      name: "Dielectric properties",
      description:
        "SCF @ V₀ → DFPT phonons → thermo_pw.x what='dielectric' → ε_∞ (3×3) "
        + "+ Born Z* + refractive index n. No EOS or C_ij(T). ε(ω) chain opt-in via UI.",
    },
  };

  function applyEnglishProfileLabels(profiles) {
    return (profiles || []).map((p) => {
      const en = PROFILE_UI_EN[p.id];
      if (!en) return p;
      return Object.assign({}, p, {
        name: en.name || p.name,
        description: en.description || p.description,
      });
    });
  }

  // --------- Helpers ---------
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g,
      (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }
  function fmt(x, n, metricKey) {
    if (x === null || x === undefined) return "—";
    if (metricKey && String(metricKey).endsWith("_source")) {
      return formatThermoSource(String(x), metricKey);
    }
    if (metricKey === "properties.gap_direct" && typeof x === "boolean") {
      return x ? t("gap.direct") : t("gap.indirect");
    }
    if (metricKey === "properties.band_gap_type" && typeof x === "string") {
      const map = {
        metal: t("gapType.metal"),
        semiconductor: t("gapType.semiconductor"),
        insulator: t("gapType.insulator"),
        zero_gap_semimetal: t("gapType.zero_gap_semimetal"),
      };
      return map[x] || x;
    }
    // Booléens (ex. properties.dynamically_stable) : lisible plutôt que "true".
    if (typeof x === "boolean") return x ? t("bool.yes") : t("bool.no");
    // Tableaux (ex. magnetism.projected_moments_per_atom) : éléments formatés.
    if (Array.isArray(x)) {
      return x.map((v) => fmt(v, n)).join(", ");
    }
    // Objets : JSON compact (évite l'affichage « [object Object] »).
    if (typeof x === "object") {
      try { return JSON.stringify(x); } catch (_e) { return "—"; }
    }
    if (typeof x !== "number" || !isFinite(x)) return String(x);
    return (Math.abs(x) >= 1e4 || (x !== 0 && Math.abs(x) < 1e-3))
      ? x.toExponential(3) : x.toFixed(n);
  }

  /** Traduit un code source thermo_pw (α, Cp, ε₀) en libellé lisible. */
  function formatThermoSource(code, metricKey) {
    const raw = String(code || "").trim();
    if (!raw) return "—";
    if (raw.startsWith("volume_table:")) {
      const fn = raw.slice("volume_table:".length);
      return t("thermoSource.volume_table") + (fn ? ` (${fn})` : "");
    }
    const key = "thermoSource." + raw;
    const tr = t(key);
    if (tr && tr !== key) return tr;
    return raw.replace(/_/g, " ");
  }

  /** Source affichée sous la tuile valeur (pas de tuile « Source … » séparée). */
  const METRIC_INLINE_SOURCES = {
    "thermo.alpha_300K_per_K": "thermo.alpha_source",
    "thermo.Cp_300K_Ry_per_K": "thermo.Cp_source",
    "dielectric.epsilon_static_average": "dielectric.epsilon_static_source",
  };

  const HIDDEN_STANDALONE_SOURCE_KEYS = new Set([
    "thermo.alpha_source",
    "thermo.Cp_source",
    "thermo.Cp_curve_source",
    "dielectric.epsilon_static_source",
  ]);

  function getNestedValue(obj, dottedKey) {
    if (!obj || typeof obj !== "object") return undefined;
    const parts = String(dottedKey || "").split(".").filter(Boolean);
    let cur = obj;
    for (const p of parts) {
      if (cur == null || typeof cur !== "object") return undefined;
      cur = cur[p];
    }
    return cur;
  }

  /** Résout ``results.plots.*`` string ou dict legacy ``{relpath:…}``. */
  function resolvePlotPath(path) {
    if (!path) return null;
    if (typeof path === "string" && path.trim()) return path.trim();
    if (typeof path === "object" && path !== null) {
      const rel = path.relpath || path.path || path.filename;
      return typeof rel === "string" && rel.trim() ? rel.trim() : null;
    }
    return null;
  }

  // --------- Pulse click helper (juin 2026) ---------
  // Module-level WeakMap pour tracker les timers de pulse en cours par élément.
  // Évite la race condition : si l'utilisateur clique 2× rapidement, le
  // timer précédent est annulé avant d'en redémarrer un nouveau. Sans ça,
  // l'ancien setTimeout pourrait se déclencher pendant la 2e animation et
  // retirer la classe trop tôt, tronquant l'animation de quelques ms.
  // Réutilisé par le bouton Guide d'utilisation (220ms, is-pulsing) et
  // par les tuiles de profil P1..P5 (380ms, is-bursting).
  const _pulseTimers = new WeakMap();

  // Helper de pulse click réutilisable. Pattern : remove → reflow forcé →
  // add → setTimeout pour retirer. Le reflow garantit que l'animation
  // redémarre même si l'élément a déjà la classe (cas du clic rapide).
  // ``duration`` est la durée de l'animation CSS ; on ajoute +20ms de
  // marge pour laisser l'animation se terminer proprement.
  function pulseClick(el, className, duration) {
    if (!el) return;
    const prev = _pulseTimers.get(el);
    if (prev) clearTimeout(prev);
    el.classList.remove(className);
    void el.offsetWidth;
    el.classList.add(className);
    const t = setTimeout(() => {
      el.classList.remove(className);
      _pulseTimers.delete(el);
    }, duration + 20);
    _pulseTimers.set(el, t);
  }

  // --------- En-têtes de groupes de métriques (juillet 2026) ---------
  // Chaque métrique du contrat ``expected_results.metrics`` porte un champ
  // ``group`` (« Constantes élastiques », « Équation d'état », « Propriétés
  // électroniques », « Magnétisme », …) défini côté backend (pipeline.py).
  // Auparavant, seul un séparateur « Structure électronique » (métriques
  // ``properties.*``) était rendu : toutes les autres tuiles (V₀/B₀/Debye/
  // C_ij/τ/ε∞…) apparaissaient mélangées sans structure thématique.
  // On rend désormais TOUS les groupes déclarés, dans l'ordre d'apparition.
  const METRIC_GROUP_EMOJIS = {
    "Elastic constants": "🧱",
    "Elasticity C_ij": "🧱",
    "Modules polycristallins": "🧮",
    "Equation of state": "📐",
    "Equation of state (Birch–Murnaghan)": "📐",
    "Thermodynamique QHA": "🌡️",
    "Electronic properties": "⚛",
    "Dynamic stability": "📊",
    "Magnetism": "🧲",
    "Phonon lifetimes": "🎯",
    "Dielectric tensor ε_∞": "🌈",
    "Charges effectives de Born": "⚡",
    "Optical chain": "💡",
    "Optical chain TDDFPT": "💡",
    "Extended properties (thermo_pw)": "🧩",
    "Thermo-élasticité (α, Cp)": "📏",
    "Thermodynamique (aux.)": "🌡️",
    "Permittivité ε₀ vs ε∞": "🔮",
    "Piézoélectrique e_ijk": "🔌",
    "LO/TO (opt-in)": "📡",
    "Constantes élastiques": "🧱",
    "Équation d'état": "📐",
    "Équation d'état (Birch–Murnaghan)": "📐",
    "Élasticité C_ij": "🧱",
    "Propriétés électroniques": "⚛",
    "Stabilité dynamique": "📊",
    "Durée de vie des phonons": "🎯",
    "Tenseur diélectrique ε_∞": "🌈",
    "Propriétés étendues (thermo_pw)": "🧩",
    "Chaîne optique": "💡",
    "Chaîne optique TDDFPT": "💡",
  };

  /** Clés gap i18n pour métriques étendues (α, Cp, ε₀, piézo, Z*). */
  const METRIC_GAP_KEYS = {
    "thermo.alpha_300K_per_K": "gaps.alpha",
    "thermo.Cp_300K_Ry_per_K": "gaps.cp",
    "dielectric.epsilon_static_average": "gaps.eps0",
    "thermo_extras.piezoelectric_tensor.max_component_C_per_m2": "gaps.piezo",
    "dielectric.born_Z_star_n_atoms": "gaps.zstar",
  };

  const QHA_SENSITIVE_KEYS = new Set([
    "thermo.debye_temperature_K",
    "thermo.alpha_300K_per_K",
  ]);

  /** Définitions artefact = contrat ``expected_results.metrics`` du profil du run. */
  function _artifactMetricDefsForJob(j) {
    return _metricsDefsForJob(j)
      .filter((m) => m && m.key && !HIDDEN_STANDALONE_SOURCE_KEYS.has(m.key))
      .map((m) => ({
        key: m.key,
        label: m.label || m.key,
        unit: m.unit || "",
        group: m.group || "",
        sourceKey: METRIC_INLINE_SOURCES[m.key] || null,
        gapKey: METRIC_GAP_KEYS[m.key] || null,
      }));
  }

  function _qhaGeometryHint(job) {
    if (!job) return null;
    const tryMatch = (text) => {
      const m = String(text || "").match(/g[eé]om[eé]trie QHA\s+(\d+)\s*\/\s*(\d+)/i);
      if (!m) return null;
      return { cur: parseInt(m[1], 10), total: parseInt(m[2], 10) };
    };
    const fromMsg = tryMatch(job.message);
    if (fromMsg) return fromMsg;
    const logs = Array.isArray(job.logs) ? job.logs : [];
    for (let i = logs.length - 1; i >= 0; i--) {
      const hit = tryMatch(logs[i]);
      if (hit) return hit;
    }
    return null;
  }

  function _metricAbsentReason(key, job, results) {
    const st = String(job && job.status || "");
    const running = st === "running" || st === "queued";
    if (QHA_SENSITIVE_KEYS.has(key)) {
      const geo = _qhaGeometryHint(job);
      if (running || (geo && geo.cur < geo.total)) {
        return geo
          ? t("artifacts.metricPendingQhaProgress", {
            cur: String(geo.cur),
            total: String(geo.total),
          })
          : t("artifacts.metricPendingQha");
      }
      if (getNestedValue(results, "thermo.Cv_300K_Ry_per_K") != null && st === "error") {
        return t("artifacts.metricPendingQhaPartial");
      }
    }
    if (key === "thermo.Cp_300K_Ry_per_K" && getNestedValue(results, "thermo.Cv_300K_Ry_per_K") != null) {
      const cpSrc = getNestedValue(results, "thermo.Cp_source");
      if (cpSrc === "Cp_equals_Cv_no_alpha") return t("thermoSource.Cp_equals_Cv_no_alpha");
      if (getNestedValue(results, "thermo.alpha_300K_per_K") == null) return t("gaps.cp");
    }
    const gapKey = METRIC_GAP_KEYS[key];
    if (gapKey) return t(gapKey);
    if (running) return t("artifacts.metricPendingRun");
    return t("artifacts.metricAbsent");
  }

  function _buildParsedArtifactRows(job, results) {
    const rows = [];
    let parsedFilled = 0;
    for (const def of _artifactMetricDefsForJob(job)) {
      const val = getNestedValue(results, def.key);
      const filled = val !== undefined && val !== null;
      if (filled) parsedFilled++;
      const src = def.sourceKey && filled
        ? getNestedValue(results, def.sourceKey)
        : null;
      rows.push({ def, val, src, filled });
    }
    return { rows, parsedFilled };
  }

  function _jobForGapsAndArtifacts() {
    if (state.loadedJobId && state.loadedRecord) return state.loadedRecord;
    return null;
  }

  function _dedupePsWhenPdf(paths) {
    const pdfStems = new Set();
    for (const p of paths) {
      const low = String(p).toLowerCase();
      if (low.endsWith(".pdf")) {
        pdfStems.add(low.slice(0, -4));
      }
    }
    return paths.filter((p) => {
      const low = String(p).toLowerCase();
      if (!low.endsWith(".ps")) return true;
      return !pdfStems.has(low.slice(0, -3));
    });
  }

  function renderPropertyGapsPanel(j) {
    if (!dom.propertyGapsPanel) return;
    const job = j || _jobForGapsAndArtifacts();
    const r = (job && job.results) || {};
    const hasRun = Boolean(job && job.job_id);
    const items = [
      {
        future: false,
        key: "gaps.alpha",
        filled: getNestedValue(r, "thermo.alpha_300K_per_K") != null,
        emptyHint: "QHA / Debye / re-parse",
      },
      {
        future: false,
        key: "gaps.cp",
        filled: getNestedValue(r, "thermo.Cp_300K_Ry_per_K") != null,
        emptyHint: "nécessite α + Cv + B",
      },
      {
        future: false,
        key: "gaps.eps0",
        filled: getNestedValue(r, "dielectric.epsilon_static_average") != null,
        emptyHint: "P1 : activer LO/TO opt-in",
      },
      {
        future: false,
        key: "gaps.piezo",
        filled: getNestedValue(r, "thermo_extras.piezoelectric_tensor.max_component_C_per_m2") != null
          || (Array.isArray(getNestedValue(r, "thermo_extras.piezoelectric_tensor.matrix"))
            && getNestedValue(r, "thermo_extras.piezoelectric_tensor.matrix").length > 0),
        emptyHint: "profil P5 + extra piezo",
      },
      {
        future: false,
        key: "gaps.zstar",
        filled: (getNestedValue(r, "dielectric.born_Z_star_n_atoms") || 0) > 0
          || (Array.isArray(getNestedValue(r, "dielectric.born_Z_star_per_atom"))
            && getNestedValue(r, "dielectric.born_Z_star_per_atom").length > 0),
        emptyHint: "P5 / LO/TO → BORN",
      },
      { future: true, key: "gaps.pressure", filled: false, emptyHint: "" },
      { future: true, key: "gaps.thermoelectric", filled: false, emptyHint: "" },
    ];
    const hintKey = hasRun ? "sec4.gapsHintRun" : "sec4.gapsHint";
    let html =
      `<div class="pg-head"><span class="pg-icon" aria-hidden="true">🧭</span>` +
      `<div><div class="pg-title">${escapeHtml(t("sec4.gapsTitle"))}</div>` +
      `<div class="pg-hint muted">${escapeHtml(t(hintKey))}</div></div></div>` +
      `<ul class="pg-list">`;
    for (const it of items) {
      let cls = "pg-future";
      let badge = t("sec4.gapsFuture");
      if (!it.future) {
        if (hasRun && it.filled) {
          cls = "pg-filled";
          badge = t("sec4.gapsFilled");
        } else if (hasRun) {
          cls = "pg-empty";
          badge = t("sec4.gapsEmpty");
        } else {
          cls = "pg-ok";
          badge = t("sec4.gapsOk");
        }
      }
      const titleAttr = it.emptyHint && hasRun && !it.filled && !it.future
        ? ` title="${escapeHtml(it.emptyHint)}"`
        : "";
      html +=
        `<li class="pg-item ${cls}"${titleAttr}><span class="pg-badge">${escapeHtml(badge)}</span>` +
        `<span class="pg-text">${t(it.key)}</span></li>`;
    }
    html += "</ul>";
    dom.propertyGapsPanel.innerHTML = html;
  }

  function _formatZStarCell(z) {
    if (!Array.isArray(z) || z.length < 3) return "—";
    const rows = z.filter((r) => Array.isArray(r));
    if (!rows.length) return "—";
    return rows.map((r) => r.map((v) => fmt(v, 3)).join(" ")).join(" · ");
  }

  function renderTensorPanels(j) {
    const panel = dom.resultsTensorPanels;
    if (!panel) return;
    const r = (j && j.results) || {};
    const born = getNestedValue(r, "dielectric.born_Z_star_per_atom");
    const piezo = getNestedValue(r, "thermo_extras.piezoelectric_tensor.matrix");
    const hasBorn = Array.isArray(born) && born.length > 0;
    const hasPiezo = Array.isArray(piezo) && piezo.length > 0;
    if (!hasBorn && !hasPiezo) {
      panel.hidden = true;
      panel.innerHTML = "";
      return;
    }
    panel.hidden = false;
    let html = "";
    if (hasBorn) {
      html += `<details class="tp-panel" open><summary>${escapeHtml(t("sec4.zstarTableTitle"))}</summary>`;
      html += `<div class="tp-scroll"><table class="tp-table"><thead><tr>` +
        `<th>${escapeHtml(t("sec4.zstarColAtom"))}</th>` +
        `<th>${escapeHtml(t("sec4.zstarColType"))}</th>` +
        `<th>Z* (3×3)</th></tr></thead><tbody>`;
      for (const at of born) {
        const idx = at.atom_index != null ? at.atom_index : "—";
        const typ = at.atom_type || "—";
        html +=
          `<tr><td>${escapeHtml(String(idx))}</td>` +
          `<td>${escapeHtml(String(typ))}</td>` +
          `<td class="tp-mono">${escapeHtml(_formatZStarCell(at.Z_star))}</td></tr>`;
      }
      html += "</tbody></table></div></details>";
    }
    if (hasPiezo) {
      html += `<details class="tp-panel" open><summary>${escapeHtml(t("sec4.piezoTableTitle"))}</summary>`;
      html += `<div class="tp-scroll"><table class="tp-table tp-table--piezo"><tbody>`;
      const voigtCols = ["xx", "yy", "zz", "yz", "xz", "xy"];
      html += `<tr><th></th>${voigtCols.map((c) => `<th>e_${c}</th>`).join("")}</tr>`;
      const labels = ["x", "y", "z"];
      for (let i = 0; i < piezo.length && i < 3; i++) {
        const row = piezo[i] || [];
        html += `<tr><th>e_${labels[i]}</th>`;
        for (let j2 = 0; j2 < 6; j2++) {
          const v = row[j2];
          html += `<td class="tp-num">${v == null ? "—" : escapeHtml(fmt(v, 4))}</td>`;
        }
        html += "</tr>";
      }
      html += "</tbody></table></div></details>";
    }
    panel.innerHTML = html;
  }

  // Construit la grille de métriques dans ``container`` avec un en-tête
  // pleine largeur (.metric-group-title) à chaque changement de groupe.
  // Neutre pour ``updateLiveResults`` : les tuiles gardent leur
  // ``data-metric-key``, les en-têtes n'en portent pas.
  function renderMetricsGrid(container, metrics) {
    container.innerHTML = "";
    let lastGroup = null;
    const visible = (metrics || []).filter(
      (m) => !HIDDEN_STANDALONE_SOURCE_KEYS.has(m.key || "")
    );
    for (const mdef of visible) {
      const group = (mdef.group || "").trim();
      if (group && group !== lastGroup) {
        const head = document.createElement("div");
        head.className = "metric-group-title";
        head.setAttribute("role", "heading");
        head.setAttribute("aria-level", "3");
        const emoji = METRIC_GROUP_EMOJIS[group] || "";
        head.innerHTML =
          (emoji ? `<span aria-hidden="true">${escapeHtml(emoji)}</span> ` : "") +
          escapeHtml(group);
        container.appendChild(head);
      }
      if (group) lastGroup = group;
      const node = document.createElement("div");
      node.className = "metric";
      node.dataset.metricKey = mdef.key || "";
      node.innerHTML =
        `<div class="lab">${escapeHtml(mdef.label || mdef.key || "—")}</div>` +
        `<div class="val text-pending" data-pending>—</div>` +
        `<span class="unit">${escapeHtml(mdef.unit || "")}</span>`;
      container.appendChild(node);
    }
  }

  // --------- Popover auteur (juillet 2026) ---------
  // Au clic sur la bannière USTO-MB (``#univBanner``), on toggle un petit
  // popover centré sous la bannière qui affiche les coordonnées complètes
  // de l'auteur (S. Hiadsi USTO_MB + email ``said.hiadsi@univ-usto.dz``).
  // Le popover se ferme :
  //   * au 2e clic sur la bannière (toggle) ;
  //   * au clic hors du popover ET hors de la bannière ;
  //   * à la touche ``Escape`` ;
  //   * au clic sur le lien email (laisser le mailto: s'ouvrir naturellement).
  //
  // Accessibilité :
  //   * ``aria-expanded`` est synchronisé sur le bouton ;
  //   * ``role="dialog"`` + ``aria-labelledby`` sur le popover (déjà en HTML) ;
  //   * focus reste sur le bouton après fermeture (pas de piège à focus).
  function setupAuthorPopover() {
    const btn = document.getElementById("univBanner");
    const pop = document.getElementById("authorPopover");
    if (!btn || !pop) return;
    let isOpen = false;
    function open() {
      if (isOpen) return;
      isOpen = true;
      pop.hidden = false;
      // Force un reflow avant d'ajouter ``is-open`` pour que l'animation
      // CSS (transform + opacity) reparte de l'état initial à chaque ouverture.
      void pop.offsetWidth;
      pop.classList.add("is-open");
      btn.setAttribute("aria-expanded", "true");
    }
    function close() {
      if (!isOpen) return;
      isOpen = false;
      pop.classList.remove("is-open");
      btn.setAttribute("aria-expanded", "false");
      // On attend la fin de l'animation (220ms) avant de remettre ``hidden``
      // pour ne pas casser la transition visuelle. Si l'utilisateur rouvre
      // entre-temps, le ``void pop.offsetWidth`` du open() re-synchronise.
      setTimeout(() => {
        if (!isOpen) pop.hidden = true;
      }, 240);
    }
    function toggle() { isOpen ? close() : open(); }
    btn.addEventListener("click", (ev) => {
      ev.stopPropagation();
      toggle();
    });
    // Clic hors du popover ET hors de la bannière ⇒ fermeture.
    document.addEventListener("click", (ev) => {
      if (!isOpen) return;
      const t = ev.target;
      if (pop.contains(t) || btn.contains(t)) return;
      close();
    });
    // Juillet 2026 — clic sur le lien email : on laisse ``mailto:`` faire son
    // boulot (ouverture du client mail), mais on ferme le popover
    // immédiatement pour qu'il ne reste pas collé à l'écran après l'action.
    const emailLink = pop.querySelector(".ap-email");
    if (emailLink) {
      emailLink.addEventListener("click", () => {
        // Ferme sans attendre : l'utilisateur a déjà confirmé son intention.
        close();
      });
    }
    // Touche Escape ⇒ fermeture. On laisse la priorité au <dialog> modal du
    // Guide d'utilisation s'il est ouvert : on vérifie que l'attribut ``open``
    // n'est pas posé sur le modal concurrent.
    document.addEventListener("keydown", (ev) => {
      if (!isOpen) return;
      if (ev.key === "Escape") {
        ev.stopPropagation();
        close();
        btn.focus();
      }
    });
  }

  // --------- Modal « Guide d'utilisation » (juin 2026) ---------
  // Pose UNE fois les handlers du bouton d'ouverture + bouton de fermeture.
  // Le contenu (``renderUsageGuideContent``) est régénéré à chaque ouverture
  // à partir de ``state.profiles`` (``GET /api/pipeline/profiles`` : description,
  // steps, inputs, outputs, prerequisites, storage_hint). Fallback emoji-only
  // si l'API est hors ligne au premier chargement.
  //
  // Comportement modal natif : le <dialog> gère Esc automatiquement ; on
  // n'a pas besoin de l'attacher. Idem pour le click outside : l'attribut
  // ``method="dialog"`` rend n'importe quel <button> à l'intérieur du
  // dialog capable de fermer le modal. On utilise donc des <button>
  // ``type="submit"`` implicites? Non — on préfère une fermeture explicite
  // .close() pour pouvoir relayer des hooks de télémétrie côté UI plus tard.
  function setupUsageGuideHandler() {
    const openBtn = $("#openUsageGuideBtn");
    const closeBtn = $("#closeUsageGuideBtn");
    const dlg = $("#usageGuideModal");
    if (!openBtn || !dlg) return;
    openBtn.addEventListener("click", () => {
      // Juin 2026 — pulse feedback tactile (220ms) avant ouverture du modal.
      // Helper ``pulseClick`` : gère la race condition si l'utilisateur clique
      // rapidement 2× de suite (annule le timer précédent avant redémarrage).
      pulseClick(openBtn, "is-pulsing", 220);
      renderUsageGuideContent();
      if (typeof dlg.showModal === "function") {
        dlg.showModal();
      } else {
        // Navigateur très ancien sans <dialog> natif : on retombe sur le bloc
        // ``open`` + un Escape manuel via keydown (filet de sécurité).
        dlg.setAttribute("open", "");
      }
    });
    if (closeBtn) {
      closeBtn.addEventListener("click", () => {
        if (typeof dlg.close === "function") dlg.close();
        else dlg.removeAttribute("open");
      });
    }
    // Click outside ⇒ close. Le dialog natif ne déclenche PAS de close
    // automatique au click sur le backdrop ; on l'écoute explicitement.
    // Note technique : avec ``padding: 0`` sur le dialog, ``ev.target === dlg``
    // ne se déclenche PAS quand l'utilisateur clique dans le backdrop (la
    // cible reste l'élément enfant le plus profond). On se rabat donc sur
    // un test géométrique contre le bounding-rect du dialogue visible.
    dlg.addEventListener("click", (ev) => {
      const rect = dlg.getBoundingClientRect();
      const insideDialogBox =
        ev.clientX >= rect.left &&
        ev.clientX <= rect.right &&
        ev.clientY >= rect.top &&
        ev.clientY <= rect.bottom;
      if (!insideDialogBox) {
        if (typeof dlg.close === "function") dlg.close();
        else dlg.removeAttribute("open");
      }
    });
  }

  // Fallback minimal si l'API ne renvoie pas encore inputs/outputs/prerequisites.
  const USAGE_GUIDE_PROFILE_FALLBACK = {
    P1: { emoji: "🟢" },
    P2: { emoji: "🌡️" },
    P3: { emoji: "👑" },
    P4: { emoji: "🎯" },
    P5: { emoji: "🌈" },
  };

  function buildWorkflowOverviewHtml(opts) {
    const compact = opts && opts.compact;
    const h3 = compact
      ? ""
      : '<h3 class="ug-h3">' + escapeHtml(t("ug.workflowTitle")) + '</h3>';
    const steps = [
      [t("ug.wfStep1Title"), t("ug.wfStep1Desc")],
      [t("ug.wfStep2Title"), t("ug.wfStep2Desc")],
      [t("ug.wfStep3Title"), t("ug.wfStep3Desc")],
      [t("ug.wfStep4Title"), t("ug.wfStep4Desc")],
    ];
    const tagline = t("ug.workflowTagline");
    let ol = "";
    for (let i = 0; i < steps.length; i++) {
      ol += '<li><span class="ug-step-num">' + String.fromCharCode(0x2460 + i) + '</span><div>' +
        '<b>' + steps[i][0] + '</b> \u2014 ' + steps[i][1] + '</div></li>';
    }
    return (
      '<section class="ug-workflow-overview" role="listitem">' +
        h3 +
        '<p class="ug-workflow-tagline">' + tagline + '</p>' +
        '<ol class="ug-steps-overview">' + ol + '</ol>' +
      '</section>'
    );
  }

  function switchView(view, opts) {
    const next = view === "workspace" ? "workspace" : "home";
    const options = opts || {};
    state.currentView = next;
    if (dom.homeView) dom.homeView.classList.toggle("hidden", next !== "home");
    if (dom.workspaceView) {
      dom.workspaceView.classList.toggle("hidden", next !== "workspace");
      dom.workspaceView.hidden = next !== "workspace";
    }
    if (dom.navHome) dom.navHome.classList.toggle("is-active", next === "home");
    if (dom.navWorkspace) dom.navWorkspace.classList.toggle("is-active", next === "workspace");
    const hash = next === "workspace" ? "#calculate" : "#home";
    if (!options.skipHash && window.location.hash !== hash) {
      history.replaceState(null, "", hash);
    }
    if (next === "workspace" && options.scrollTo) {
      const el = typeof options.scrollTo === "string"
        ? document.querySelector(options.scrollTo)
        : options.scrollTo;
      if (el && el.scrollIntoView) {
        requestAnimationFrame(() => el.scrollIntoView({ behavior: "smooth", block: "start" }));
      }
    }
  }

  function setupViewNavigation() {
    if (dom.navHome) {
      dom.navHome.addEventListener("click", () => switchView("home"));
    }
    if (dom.navWorkspace) {
      dom.navWorkspace.addEventListener("click", () => switchView("workspace"));
    }
    if (dom.homeStartBtn) {
      dom.homeStartBtn.addEventListener("click", () => {
        switchView("workspace", { scrollTo: "#profilesStrip" });
      });
    }
    const hash = (window.location.hash || "").toLowerCase();
    if (hash === "#calculate" || hash === "#workspace") {
      switchView("workspace", { skipHash: true });
    } else {
      switchView("home", { skipHash: true });
    }
    window.addEventListener("hashchange", () => {
      const h = (window.location.hash || "").toLowerCase();
      if (h === "#calculate" || h === "#workspace") {
        switchView("workspace", { skipHash: true });
      } else if (h === "#home" || h === "") {
        switchView("home", { skipHash: true });
      }
    });
  }

  function scrollToWorkflowSection(sel) {
    switchView("workspace", { scrollTo: sel, skipHash: true });
    const el = typeof sel === "string" ? document.querySelector(sel) : sel;
    if (el) {
      el.classList.remove("section-card--flash");
      void el.offsetWidth;
      el.classList.add("section-card--flash");
    }
    updateWorkflowStepper();
  }

  function updateWorkflowStepper() {
    const strip = dom.workflowStepper;
    if (!strip) return;
    const steps = strip.querySelectorAll(".wf-step");
    const s1 = !!(state.selectedMaterialId && state.selectedScfBasename);
    const s2 = !!state.selectedProfileId;
    const s3run = !!state.currentJobId;
    const s3ready = s1 && s2 && !s3run;
    const doneVisible = dom.doneBanner && !dom.doneBanner.hidden;
    const s4 = !!(
      state.loadedJobId ||
      (dom.resultsCard && dom.resultsCard.classList.contains("has-live-results")) ||
      doneVisible
    );
    const completes = [s1, s2, s3ready || doneVisible || s3run, s4];
    let active = 1;
    if (s4) active = 4;
    else if (s3run || s3ready) active = 3;
    else if (s2) active = 2;
    else if (s1) active = 1;
    steps.forEach((btn) => {
      const n = parseInt(btn.dataset.step || "0", 10);
      btn.classList.toggle("is-complete", !!completes[n - 1]);
      btn.classList.toggle("is-active", n === active);
    });
  }

  function setupWorkflowStepper() {
    if (!dom.workflowStepper) return;
    dom.workflowStepper.querySelectorAll(".wf-step").forEach((btn) => {
      btn.addEventListener("click", () => {
        const target = btn.getAttribute("data-scroll");
        if (target) scrollToWorkflowSection(target);
      });
    });
    if (dom.goResultsBtn) {
      dom.goResultsBtn.addEventListener("click", () => {
        scrollToWorkflowSection("#resultsCard");
      });
    }
    updateWorkflowStepper();
  }

  function formatRunOptionLabel(run) {
    if (!run) return "?";
    const st = (run.status || "").toLowerCase();
    const stIcon = {
      done: "✓",
      error: "✗",
      cancelled: "⊘",
      interrupted: "⊘",
      stopped: "⊘",
      running: "◉",
      queued: "◌",
    }[st] || "·";
    const prof = ((run.profile_emoji || "") + " " + (run.profile_id || "?")).trim();
    const mat = run.material_id || "?";
    const whenRaw = run.finished_at || run.started_at || run.created_at || "";
    const when = whenRaw ? whenRaw.replace("T", " ").slice(0, 16) : "";
    const parts = [stIcon + " " + prof, mat];
    if (when) parts.push(when);
    if (run.label && !run.label.startsWith("pipeline_")) {
      parts.push(run.label.slice(0, 28));
    }
    return parts.join(" · ");
  }

  function selectProfileById(profileId, opts) {
    const pid = profileId || "";
    state.selectedProfileId = pid;
    const grid = dom.profileGrid;
    if (grid) {
      for (const t of grid.querySelectorAll(".tile")) {
        t.classList.toggle("is-selected", t.dataset.profileId === pid);
      }
    }
    state.selectedProfileExpected = pid
      ? (state.profiles.find((x) => x.id === pid) || {}).expected_results || null
      : null;
    resetJobState();
    updateLaunchButton();
    refreshTpwinPreview();
    renderProfilePreview();
    renderP5ExtrasPanel();
    renderP1PresetPanel();
    updateWorkflowStepper();
    const options = opts || {};
    if (options.openWorkspace) {
      switchView("workspace", {
        scrollTo: options.scrollTo || "#profilesStrip",
      });
    }
  }

  function buildElectronicInsightsHtml(opts) {
    const compact = opts && opts.compact;
    const pack = (window.ThermoI18n && window.ThermoI18n.ELECTRONIC_INSIGHTS)
      ? window.ThermoI18n.ELECTRONIC_INSIGHTS[state.lang]
      : null;
    if (!pack || !Array.isArray(pack.sections)) return "";
    const statusLabel = {
      available: t("insight.available"),
      partial: t("insight.partial"),
      future: t("insight.future"),
    };
    const html = [];
    if (!compact) {
      html.push(
        '<header class="home-electronic-head">' +
          '<h3 class="home-electronic-title">' + escapeHtml(t("home.electronicTitle")) + '</h3>' +
          '<p class="home-electronic-intro">' + t("home.electronicIntro") + '</p>' +
          '<ul class="ei-legend" aria-label="Legend">' +
            '<li><span class="ei-badge ei-available">' + escapeHtml(statusLabel.available) + '</span></li>' +
            '<li><span class="ei-badge ei-partial">' + escapeHtml(statusLabel.partial) + '</span></li>' +
            '<li><span class="ei-badge ei-future">' + escapeHtml(statusLabel.future) + '</span></li>' +
          '</ul>' +
        '</header>'
      );
    }
    html.push('<div class="ei-sections">');
    for (const sec of pack.sections) {
      html.push('<details class="ei-section card">');
      html.push('<summary class="ei-section-summary">' + escapeHtml(sec.title || sec.id || "") + '</summary>');
      html.push('<ul class="ei-items">');
      for (const it of (sec.items || [])) {
        const st = it.status || "future";
        html.push(
          '<li class="ei-item">' +
            '<span class="ei-badge ei-' + escapeHtml(st) + '">' + escapeHtml(statusLabel[st] || st) + '</span>' +
            '<span class="ei-text">' + (it.text || "") + '</span>' +
          '</li>'
        );
      }
      html.push('</ul></details>');
    }
    html.push('</div>');
    if (pack.p5Note) {
      html.push('<p class="ei-p5-note hint">' + pack.p5Note + '</p>');
    }
    return html.join("\n");
  }

  function renderElectronicInsights() {
    const el = dom.homeElectronicInsights;
    if (!el) return;
    const html = buildElectronicInsightsHtml({ compact: false });
    if (!html) {
      el.hidden = true;
      el.innerHTML = "";
      return;
    }
    el.hidden = false;
    el.innerHTML = html;
  }

  function renderHomeFeatures() {
    const el = dom.homeFeatures;
    if (!el) return;
    el.innerHTML =
      '<h3 class="home-features-title">' + escapeHtml(t("home.featuresTitle")) + '</h3>' +
      '<ul class="home-features-list">' + t("home.featuresList") + '</ul>';
    el.hidden = false;
  }

  function renderHomePage() {
    const list = dom.homeProfileList;
    if (!list) return;
    renderHomeFeatures();
    list.innerHTML = "";
    const order = ["P1", "P2", "P3", "P4", "P5"];
    const baseProfiles = state.profiles && state.profiles.length
      ? state.profiles
      : order.map((id) => {
          const ui = (window.ThermoI18n && window.ThermoI18n.PROFILE_UI[state.lang]) || {};
          const loc = ui[id] || {};
          return {
            id,
            name: loc.name || id,
            description: loc.description || "",
            emoji: (USAGE_GUIDE_PROFILE_FALLBACK[id] && USAGE_GUIDE_PROFILE_FALLBACK[id].emoji) || "",
            steps: [],
            outputs: [],
          };
        });
    const sorted = baseProfiles.slice().sort(
      (a, b) => order.indexOf(a.id) - order.indexOf(b.id)
    );
    for (const p of sorted) {
      if (!order.includes(p.id)) continue;
      const fb = USAGE_GUIDE_PROFILE_FALLBACK[p.id] || {};
      const emoji = (p.emoji || fb.emoji || "").trim();
      const name = p.name || p.id;
      const what = p.what_qe_display || p.what_qe || p.id;
      const desc = p.description || "";
      const steps = Array.isArray(p.steps) ? p.steps : (fb.steps || []);
      const outputs = Array.isArray(p.outputs) ? p.outputs : (fb.outputs || []);

      const details = document.createElement("details");
      details.className = "home-guide-profile card fade-in";
      details.setAttribute("role", "listitem");

      let html =
        '<summary class="home-guide-summary" aria-labelledby="home-p-' + escapeHtml(p.id) + '">' +
          (emoji ? '<span class="home-guide-emoji" aria-hidden="true">' + escapeHtml(emoji) + '</span>' : "") +
          '<div class="home-guide-meta">' +
            '<h3 class="home-guide-name" id="home-p-' + escapeHtml(p.id) + '">' +
              escapeHtml(p.id) + ' · ' + escapeHtml(name) +
            '</h3>' +
            '<code class="home-guide-what">' + escapeHtml(t("home.whatPrefix") + what) + '</code>' +
          '</div>' +
        '</summary>' +
        '<div class="home-guide-body">';

      if (desc) {
        html += '<p class="home-guide-desc">' + escapeHtml(desc) + '</p>';
      }
      const er = p.expected_results || {};
      const nMet = Array.isArray(er.metrics) ? er.metrics.length : 0;
      const nPlots = Array.isArray(er.plots) ? er.plots.length : 0;
      const groups = [];
      if (Array.isArray(er.metrics)) {
        for (const m of er.metrics) {
          const g = (m && m.group) || "";
          if (g && !groups.includes(g)) groups.push(g);
        }
      }
      if (nMet || nPlots) {
        html += '<p class="home-guide-contract hint">' +
          escapeHtml(t("home.contractSummary", {
            metrics: nMet,
            plots: nPlots,
            groups: groups.slice(0, 5).join(" · "),
          })) +
          '</p>';
      }
      if (steps.length) {
        html += '<section class="home-guide-block">' +
          '<h4 class="home-guide-block-title">' + escapeHtml(t("home.chain")) + '</h4>' +
          '<ol class="home-guide-steps">';
        for (const st of steps) html += '<li>' + st + '</li>';
        html += '</ol></section>';
      }
      if (outputs.length) {
        html += '<section class="home-guide-block">' +
          '<h4 class="home-guide-block-title">' + escapeHtml(t("home.outputs")) + '</h4>' +
          '<div class="home-guide-outputs">';
        for (const o of outputs) {
          html += '<span class="home-guide-output">' + o + '</span>';
        }
        html += '</div></section>';
      }
      html += '</div>';

      details.innerHTML = html;
      list.appendChild(details);
    }
  }

  // Rend le contenu du modal depuis state.profiles + descripteurs statiques
  // de référence. Si l'API renvoie un champ ``details`` riche, on l'affiche
  // tel quel ; sinon on retombe sur USAGE_GUIDE_PROFILE_FALLBACK[id].
  function renderUsageGuideContent() {
    const target = $("#usageGuideContent");
    if (!target) return;
    const order = ["P1", "P2", "P3", "P4", "P5"];
    const baseProfiles = state.profiles && state.profiles.length
      ? state.profiles
      : order.map((id) => ({ id, name: id }));
    // Conserve l'ordre canonique P1..P5 quelles que soient les id envoyées
    // par le backend (utile si le serveur réordonnait pour une raison x).
    const sortedProfiles = baseProfiles.slice().sort((a, b) =>
      order.indexOf(a.id) - order.indexOf(b.id)
    );
    const html = [];
    html.push(buildWorkflowOverviewHtml({ compact: false }));
    html.push(
      '<section class="ug-electronic-insights" role="listitem">' +
        '<h3 class="ug-h3">' + escapeHtml(t("home.electronicTitle")) + '</h3>' +
        buildElectronicInsightsHtml({ compact: true }) +
      '</section>'
    );
    for (const p of sortedProfiles) {
      if (!order.includes(p.id)) continue;
      const fb = USAGE_GUIDE_PROFILE_FALLBACK[p.id] || {};
      const emoji = (p.emoji || fb.emoji || "").trim();
      const name = p.name || p.id;
      const what = p.what_qe_display || p.what_qe || p.id;
      const desc = p.description || fb.rationale || "";
      const inputs = Array.isArray(p.inputs) ? p.inputs : (fb.inputs || []);
      const steps = Array.isArray(p.steps) ? p.steps : (fb.steps || []);
      const outputs = Array.isArray(p.outputs) ? p.outputs : (fb.outputs || []);
      const prereq = Array.isArray(p.prerequisites) ? p.prerequisites : (fb.prerequisites || []);
      html.push('<details class="ug-profile" role="listitem">');
      html.push('  <summary class="ug-profile-summary" aria-labelledby="ug-p-' + escapeHtml(p.id) + '">');
      if (emoji) html.push('    <span class="ug-profile-emoji" aria-hidden="true">' + escapeHtml(emoji) + '</span>');
      html.push('    <span class="ug-profile-name" id="ug-p-' + escapeHtml(p.id) + '">' +
        escapeHtml(p.id) + ' · ' + escapeHtml(name) + '</span>');
      html.push('    <code class="ug-profile-what">' + escapeHtml(what) + '</code>');
      html.push('  </summary>');
      html.push('  <div class="ug-profile-body">');
      if (desc) {
        html.push('  <p class="ug-profile-desc">' + desc + '</p>');
      }
      // Bloc « Données d'entrée »
      if (inputs.length) {
        html.push('  <section class="ug-profile-section"><h4>' + escapeHtml(t("ug.inputs")) + '</h4><ul>');
        for (const it of inputs) html.push('<li>' + it + '</li>');
        html.push('  </ul></section>');
      }
      if (steps.length) {
        html.push('  <section class="ug-profile-section"><h4>' + escapeHtml(t("ug.chain")) + '</h4><ol>');
        for (const st of steps) html.push('<li>' + st + '</li>');
        html.push('  </ol></section>');
      }
      if (outputs.length) {
        html.push('  <section class="ug-profile-section"><h4>' + escapeHtml(t("ug.files")) + '</h4>');
        html.push('    <div class="ug-profile-files">');
        for (const o of outputs) {
          html.push('<span class="ug-profile-file">' + o + '</span>');
        }
        html.push('    </div>');
        html.push('  </section>');
      }
      if (prereq.length) {
        html.push('  <section class="ug-profile-section"><h4>' + escapeHtml(t("ug.prereq")) + '</h4><ul>');
        for (const r of prereq) html.push('<li>' + r + '</li>');
        html.push('  </ul></section>');
      }
      html.push('  </div>');
      html.push('</details>');
    }
    // Juin 2026 — réassurance pour la peur « coupure en plein calcul ». Les
    // calculs tournent côté serveur (pas dans le navigateur) et sont
    // persistés sur disque à chaque étape : une coupure de l'onglet /
    // du navigateur n'arrête ni la chaîne thermo_pw ni ne corrompt le work_dir.
    // Juillet 2026 — section « 📋 Fiche technique » (artefact téléchargeable
    // ajouté post-correction, désormais présent dans la section ④ picker).
    html.push(
      '<section class="ug-factsheet" role="listitem">' +
        '<h3 class="ug-h3">' + escapeHtml(t("ug.factsheetTitle")) + '</h3>' +
        '<p>' + t("ug.factsheetIntro") + '</p>' +
        '<ul>' +
          '<li>' + t("ug.factsheetLi1") + '</li>' +
          '<li>' + t("ug.factsheetLi2") + '</li>' +
          '<li>' + t("ug.factsheetLi3") + '</li>' +
        '</ul>' +
        '<p class="hint">' + t("ug.factsheetRoute") + '</p>' +
      '</section>'
    );
    html.push(
      '<section class="ug-reconnect-help" role="listitem">' +
        '<h3 class="ug-h3">' + escapeHtml(t("ug.reconnectTitle")) + '</h3>' +
        '<p>' + t("ug.reconnectIntro") + '</p>' +
        '<ul>' +
          '<li>' + t("ug.reconnectLi1") + '</li>' +
          '<li>' + t("ug.reconnectLi2") + '</li>' +
          '<li>' + t("ug.reconnectLi3") + '</li>' +
          '<li>' + t("ug.reconnectLi4") + '</li>' +
        '</ul>' +
      '</section>'
    );
    target.innerHTML = html.join("\n");
  }

  // --------- Helpers persistance + reprise après refresh ----------
  // Persistance du ``currentJobId`` en localStorage. Clé isolée dans un
  // namespace dédié pour cohabiter avec d'autres apps qui partagent le
  // même navigateur (LMS, autres outils maison). Pas de PII : job_id
  // technique de 12 hex max.
  function _currentJobLsKey() { return "thermo_pw.current_job_id"; }
  function persistCurrentJob(jid) {
    try { localStorage.setItem(_currentJobLsKey(), jid || ""); } catch (e) {}
  }
  function clearCurrentJob() { persistCurrentJob(""); }
  function readPersistedCurrentJob() {
    try { return (localStorage.getItem(_currentJobLsKey()) || "").trim(); } catch (e) { return ""; }
  }

  // --------- Status API ---------
  // Mémorise le dernier état observé du badge API pour ne déclencher
  // l'animation burst QUE sur un vrai changement d'état (online ↔ offline),
  // pas sur chaque tick de polling (sinon l'animation tournerait en boucle
  // toutes les 10 s, ce qui serait visuellement pénible et annulerait son
  // rôle de signal d'alerte). État initial = "unknown" (le badge commence
  // en ``dot-unknown`` côté HTML, avant que la première requête ne résolve).
  let _lastApiState = "unknown";

  // Déclenche le burst sur le dot API (scale 1 → 1.35 → 1, 380ms). Retire
  // puis re-applique la classe ``is-state-change`` après un reflow pour
  // pouvoir relancer l'animation même si l'état bascule deux fois de suite
  // (online → offline → online en <1 s, par ex. après un restart backend).
  function triggerStatusBurst() {
    if (!dom.apiStatus) return;
    dom.apiStatus.classList.remove("is-state-change");
    void dom.apiStatus.offsetWidth;
    dom.apiStatus.classList.add("is-state-change");
    setTimeout(() => dom.apiStatus.classList.remove("is-state-change"), 400);
  }

  async function refreshApiStatus() {
    let newState = "offline";
    try {
      await window.ThermoPipeline.health();
      newState = "online";
      dom.apiStatus.innerHTML =
        '<span class="dot dot-online"></span><span class="status-label">' + t("api.online") + '</span>';
      // Juillet 2026 — mémoïse le payload ``/api/health`` complet pour que
      // les consommateurs (en particulier ``syncFactsheetBtn`` pour l'option
      // PDF du factsheet) puissent lire ``factsheet_pdf_available`` sans round-trip
      // HTTP supplémentaire. ``best-effort`` : un échec ne doit jamais casser
      // le badge API en ligne.
      try {
        const r = await fetch("/api/health", { credentials: "omit" });
        if (r && r.ok) {
          window.__thermoHealth = await r.json();
          if (typeof syncFactsheetBtn === "function") {
            try { syncFactsheetBtn(); } catch (_e) {}
          }
          // Bandeau « factsheet vX.Y — générée le … » (dépend de __thermoHealth).
          try { refreshFactsheetVersionChip(); } catch (_e) {}
        }
      } catch (_e) { /* best-effort */ }
    } catch (_e) {
      dom.apiStatus.innerHTML =
        '<span class="dot dot-offline"></span><span class="status-label">' + t("api.offline") + '</span>';
    }
    // Burst UNIQUEMENT sur transition d'état (online → offline, ou vice-versa,
    // y compris le tout premier passage unknown → online au chargement).
    if (_lastApiState !== newState) {
      triggerStatusBurst();
      _lastApiState = newState;
    }
  }

  // --------- Reprise automatique après refresh ----------
  // Lit le ``currentJobId`` persisté en localStorage. Si le job est encore
  // ``running`` ou ``queued`` côté serveur, on rattache l'UI au polling live.
  // Si le job est terminé (``done`` / ``error`` / ``cancelled`` / ``interrupted``),
  // on journalise une ligne d'info radoucie et on libère le LS — l'utilisateur
  // peut rouvrir le résultat depuis le picker sans qu'il s'impose en pleine
  // figure à l'ouverture (UX : on ne « vole » pas la session).
  //
  // Edge cases :
  // * Erreur 404 staleJob (registre en mémoire a redémarré) : log info + LS cleared.
  // * Erreur réseau : on garde le LS tel quel ; au prochain rafraîchissement on
  //   retentera (les coupures brèves sont absorbées par le health 10 s).
  async function tryResumePendingJob() {
    const jid = readPersistedCurrentJob();
    if (!jid) return;
    let j = null;
    try {
      j = await window.ThermoPipeline.jobStatus(jid);
    } catch (e) {
      if (e && e.staleJob === true) {
        clearCurrentJob();
        appendLog(
          "[Resume] Job " + jid.slice(0, 8) + " unknown on server " +
          "(in-memory registry cleared). Use \"Load a previous calculation\" " +
          "to reopen the run.",
          "info"
        );
        return;
      }
      appendLog(
        "[Resume] Job " + jid.slice(0, 8) + " — polling failed (" +
        (e.message || "unknown") + "). Keeping LS for retry " +
        "on next refresh.",
        "info"
      );
      return;
    }
    if (!j || !j.status) {
      clearCurrentJob();
      return;
    }
    const st = String(j.status).toLowerCase();
    if (st === "running" || st === "queued") {
      // Le serveur exécute encore le job : on rattache le polling live.
      // ``startPolling`` fire un ``tick()`` synchrone qui re-fetch le jobStatus
      // puis appelle ``renderJobTick(j)`` (qui rejoue workdir + results +
      // progress). On se contente ici d'amorcer l'état visible (banner +
      // bouton Annuler) et de journaliser — toute la peinture UI est faite
      // par le premier tick pour éviter une double roundtrip API.
      state.currentJobId = jid;
      appendLog(
        "[Resume] Job " + jid.slice(0, 12) + " still running " +
        "(status: " + st + "). Live polling resumed automatically.",
        "ok"
      );
      setLaunchState("running", "Resuming — " + (j.message || "job in progress"));
      showProgress(true, 5, "Resuming live polling…");
      if (dom.cancelBtn) dom.cancelBtn.hidden = false;
      startPolling(jid);
      return;
    }
    // Statut terminal : on libère le LS sans imposer le run à l'UI.
    clearCurrentJob();
    const msg = st === "done"
      ? "[Resume] Job " + jid.slice(0, 8) + " completed while you were away \u2713"
      : "[Resume] Job " + jid.slice(0, 8) + " finished in your absence (status: " + st + ")";
    appendLog(msg, st === "done" ? "ok" : "err");
  }

  // --------- Chargement initial ---------
  async function init() {
    if (window.ThermoI18n) {
      state.lang = window.ThermoI18n.loadStoredLang();
      window.ThermoI18n.setLang(state.lang, { skipStorage: true });
      window.ThermoI18n.setupLangSwitch(applyLanguage);
      const storedTheme = window.ThermoI18n.loadStoredTheme();
      window.ThermoI18n.setTheme(storedTheme, { skipStorage: true });
      window.ThermoI18n.setupThemeSwitch();
    }
    await refreshApiStatus();
    setInterval(refreshApiStatus, 10000);
    // Bouton « Copier » du chemin work_dir (handler unique, posé une fois).
    setupWorkdirCopyHandler();
    // Listeners du picker « Charger un calcul précédent » (handlers / câblage).
    setupRunsPickerHandlers();
    // Modal « Guide d'utilisation » (juin 2026) — bouton header + contenu
    // dynamique des 5 profils P1..P5.
    setupUsageGuideHandler();
    setupViewNavigation();
    setupWorkflowStepper();
    renderPropertyGapsPanel(_jobForGapsAndArtifacts());
    // Juillet 2026 — popover auteur (clic sur la bannière USTO-MB pour
    // révéler les coordonnées complètes : nom + email mailto:).
    setupAuthorPopover();
    // Juillet 2026 — modale de prévisualisation Artefacts (axe 3).
    setupArtifactPreviewModal();
    try {
      const [mats, profs] = await Promise.all([
        window.ThermoPipeline.listThermoInputs(),
        window.ThermoPipeline.listProfiles(),
      ]);
      state.materials = mats.materials || [];
      state.profilesRaw = profs.profiles || [];
      state.profiles = window.ThermoI18n
        ? window.ThermoI18n.localizeProfiles(state.profilesRaw, state.lang)
        : state.profilesRaw;
    } catch (e) {
      appendLog(`[ERR] chargement initial impossible : ${e.message}`, "err");
      dom.tpwinIdentity.innerHTML =
        '<span class="muted error">ⓘ API injoignable — vérifiez /api/health.</span>';
      if (window.ThermoI18n) window.ThermoI18n.applyStaticUI(state.lang);
      renderHomePage();
      renderElectronicInsights();
      return;
    }
    populateMaterials();
    renderProfiles();
    renderHomePage();
    renderElectronicInsights();
    setLaunchState("idle", t("sec3.idle"));
    updateLaunchButton();
    refreshTpwinPreview();
    // Estimations de durée des 5 profils (août 2026) — non bloquant : une API
    // sans cet endpoint laisse simplement les tuiles sans chiffre.
    refreshProfileEstimates().catch(() => {});
    // Juin 2026 — reprise automatique du polling live si un job tournait avant
    // le refresh (job_id persisté en localStorage). Best-effort : un échec
    // ne doit JAMAIS bloquer l'init.
    tryResumePendingJob().catch(() => {});
    // Charge la liste des runs persistés (non bloquant — erreurs logguées).
    refreshRunsList().catch(() => {});
  }

  // --------- ① Matériau ---------
  function populateMaterials() {
    const sel = dom.matSelect;
    sel.innerHTML = "";
    if (!state.materials.length) {
      const opt = document.createElement("option");
      opt.value = ""; opt.textContent = t("mat.none");
      opt.disabled = true; opt.selected = true;
      sel.appendChild(opt);
      dom.scfPreviewBody.textContent = t("mat.none");
      return;
    }
    for (const m of state.materials) {
      const opt = document.createElement("option");
      // Backend `MaterialInfo.to_dict()` expose `material_id` (pas `id`) et
      // `mat_dir` (pas `path`/`dir`) — adapter défensivement pour tolérer les
      // deux conventions si jamais la shape backend évolue.
      const mId = m.material_id || m.id || "";
      const mCandidates = m.candidates || [];
      opt.value = mId;
      opt.textContent = `${mId} (${mCandidates.length} fichier${mCandidates.length > 1 ? "s" : ""})`;
      sel.appendChild(opt);
    }
    state.selectedMaterialId = (state.materials[0] && (state.materials[0].material_id || state.materials[0].id)) || "";
    populateScfIn();
    showMaterialInfo();
    refreshScfPreview();
  }

  function populateScfIn() {
    const sel = dom.scfIn;
    sel.innerHTML = "";
    const mat = state.materials.find(
      (m) => (m.material_id || m.id) === state.selectedMaterialId
    );
    if (!mat || !mat.candidates) return;
    const candidates = mat.candidates.slice().sort();
    for (const c of candidates) {
      const opt = document.createElement("option");
      opt.value = c; opt.textContent = c;
      sel.appendChild(opt);
    }
    // Préférer un *scf.in (clôture du nom) qui n'est PAS *nscf.in* /
    // *vc-relax.in* — le pipeline « 5 profils » lance un SCF équilibre
    // autonome, pas une suite NSCF à un SCF préalable.
    const preferred =
      candidates.find((n) => /scf\.in$/i.test(n) && !/nscf/i.test(n)) ||
      candidates.find((n) => /scf\.in$/i.test(n)) ||
      candidates[0];
    sel.value = preferred;
    state.selectedScfBasename = preferred;
  }

  function showMaterialInfo() {
    const mat = state.materials.find(
      (m) => (m.material_id || m.id) === state.selectedMaterialId
    );
    if (!mat) { dom.matInfo.hidden = true; return; }
    dom.kvCount.textContent = (mat.candidates || []).length || "—";
    const matPath = mat.mat_dir || mat.path || mat.dir || "—";
    dom.kvPath.textContent = matPath;
    dom.kvPath.title = matPath || "";
    dom.matInfo.hidden = false;
  }

  async function refreshScfPreview() {
    const mid = state.selectedMaterialId;
    const bn = state.selectedScfBasename;
    if (!mid || !bn) {
      dom.scfPreviewBody.textContent = "— No scf.in selected —";
      dom.scfPreviewMeta.textContent = "";
      return;
    }
    const cacheKey = `${mid}::${bn}`;
    if (state.scfPreviewLoadedFor === cacheKey) return;
    dom.scfPreviewBody.textContent = "— chargement du scf.in —";
    try {
      const r = await window.ThermoPipeline.scfInPreview(mid, bn);
      state.scfPreviewLoadedFor = cacheKey;
      const text = String(r.content || "");
      dom.scfPreviewBody.textContent = text.length > 8192
        ? text.slice(0, 8192) + "\n… (truncated, " + text.length + " displayable bytes)"
        : text;
      const lines = text.split("\n").length;
      dom.scfPreviewMeta.textContent = ` · ${escapeHtml(bn)} · ${r.size || text.length} bytes · ${lines} line(s)`;
    } catch (e) {
      dom.scfPreviewBody.textContent = `⚠️ aperçu indisponible : ${e.message}`;
      dom.scfPreviewMeta.textContent = "";
    }
  }

  // --------- ② P5 extras (multi-select panneau) ---------
  // Le panneau est rendu à chaque changement de profil ; le contenu des
  // cases est dérivé du catalogue exposé par ``PipelineJob.to_dict()`` ou,
  // si aucun job n'a encore tourné, depuis ``state.profiles[*].extras_catalog``
  // (lu via ``/api/pipeline/profiles``). En l'absence de catalogue, on retombe
  // sur les entrées statiques connues.
  function renderP5ExtrasPanel() {
    if (!dom.p5ExtrasPanel || !dom.p5ExtrasList) return;
    const isP5 = state.selectedProfileId === "P5";
    if (!isP5) {
      dom.p5ExtrasPanel.hidden = true;
      return;
    }
    // Récupère le catalogue via le profil chargé (state.profiles est
    // synchronisé au démarrage). Si la version backend l'expose aussi
    // via ``extras_catalog`` (par exemple après loadPipelineRun), on
    // privilégie cette source — plus fraîche que state.profiles.
    const prof = state.profiles.find((p) => p.id === "P5");
    const catalog = (prof && Array.isArray(prof.extras_catalog) && prof.extras_catalog.length)
      ? prof.extras_catalog
      : [
          // Catalogue de repli — figé ici côté UI pour ne pas casser si
          // l'endpoint ne renvoie pas encore ``extras_catalog``.
          { what: "plot_bz", label: "Visualisation zone de Brillouin",
            tooltip: "Sortie graphique + fichier texte des points high-sym. Inoffensif et rapide.",
            emoji: "🛰️", group: "Visualisation" },
          { what: "piezoelectric_tensor", label: "Piezoelectric tensor e_ijk",
            tooltip: "DFPT thermo_pw. Reserved for non-centrosymmetric insulators (zero tensor otherwise).",
            emoji: "", group: "Piezoelectric",
            needs_insulating: true, needs_non_centrosymmetric: true },
          { what: "magnetic_susceptibility", label: "Magnetic susceptibility χ",
            tooltip: "REQUIRES spin-polarized SCF (nspin=2). For magnetic materials.",
            emoji: "🧲", group: "Magnetism",
            needs_spin_polarized: true },
          { what: "magnetoelectric_tensor", label: "Magnetoelectric tensor α_ij",
            tooltip: "Magnetic field ↔ electric polarization coupling. Multi-physics.",
            emoji: "", group: "Magnetoelectric",
            needs_spin_polarized: true, needs_insulating: true },
          { what: "scf_dielectric", label: "Static dielectric constant ε_∞",
            tooltip: "DFPT rapide — valide la calibration avant epsilon.x.",
            emoji: "", group: "Dielectric" },
        ];
    // Defaults : plot_bz coché par défaut (cf. PROFILES["P5"][default_extra_whats]).
    const defaults = (prof && Array.isArray(prof.default_extra_whats))
      ? prof.default_extra_whats
      : ["plot_bz"];
    dom.p5ExtrasList.innerHTML = "";
    for (const item of catalog) {
      const wrap = document.createElement("label");
      wrap.className = "p5-extras-item";
      // Tooltip intégré pour la pédagogie — donne les pré-requis physiques.
      const toolParts = [item.tooltip || ""];
      if (item.needs_spin_polarized) toolParts.push("⚠️ Spin-polarized SCF required.");
      if (item.needs_insulating) toolParts.push("⚠️ Insulator required.");
      if (item.needs_non_centrosymmetric) toolParts.push("⚠️ Non-centrosymmetric required.");
      wrap.title = toolParts.filter(Boolean).join(" ");
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.value = item.what || "";
      cb.dataset.what = item.what || "";
      cb.checked = defaults.includes(item.what);
      cb.addEventListener("change", () => updateLaunchButton());
      const text = document.createElement("span");
      text.className = "p5-extras-item-text";
      text.innerHTML =
        (item.emoji
            ? `<span class="p5-extras-emoji" aria-hidden="true">${escapeHtml(item.emoji)}</span>`
            : ""
        ) +
        `<span class="p5-extras-label">${escapeHtml(item.label || item.what || "")}</span>` +
        (item.group
            ? `<span class="p5-extras-group">${escapeHtml(item.group)}</span>`
            : ""
        );
      wrap.appendChild(cb);
      wrap.appendChild(text);
      dom.p5ExtrasList.appendChild(wrap);
    }
    dom.p5ExtrasPanel.hidden = false;
  }

  // --------- ② P1 preset « Cᵢⱼ + DOS + Bandes (ichamp=3) » ---------
  // Affiche le fieldset dédié UNIQUEMENT quand P1 est sélectionné. Cette
  // logique vivait auparavant dans ``launchPipeline`` (donc exécutée après
  // le clic « Lancer » — trop tard pour que l'utilisateur voie la case).
  function renderP1PresetPanel() {
    if (!dom.p1PresetPanel) return;
    const isP1 = state.selectedProfileId === "P1";
    dom.p1PresetPanel.hidden = !isP1;
    if (!isP1 && dom.p1PresetCheckbox) {
      // Défensif : en quittant P1, on décoche pour repartir propre.
      dom.p1PresetCheckbox.checked = false;
    }
    if (!isP1 && dom.loToCheckbox) {
      dom.loToCheckbox.checked = false;
    }
    // Opt-in P5 « chaîne optique ε(ω) » : même hygiène en quittant P5.
    if (state.selectedProfileId !== "P5" && dom.p5OpticalCheckbox) {
      dom.p5OpticalCheckbox.checked = false;
    }
  }

  // Récupère la liste des `what=` cochés dans le panneau P5 extras.
  // Renvoie [] si le panneau n'existe pas ou si rien n'est coché.
  function collectP5ExtrasSelection() {
    if (!dom.p5ExtrasList) return [];
    const out = [];
    for (const cb of dom.p5ExtrasList.querySelectorAll('input[type="checkbox"]')) {
      if (cb.checked && cb.value) out.push(cb.value);
    }
    return out;
  }

  // --------- Tuiles profils ---------
  // --------- Estimation de durée par profil ---------
  // Confiance → classe CSS. Une estimation « faible » repose sur des
  // constantes dérivées et non sur des durées mesurées : l'affichage doit le
  // dire, sinon l'utilisateur planifie sa journée sur un chiffre inventé.
  const ETA_CONFIDENCE_CLASS = {
    bonne: "is-good",
    moyenne: "is-fair",
    faible: "is-weak",
  };

  function renderTileEta(node, profileId) {
    const box = node.querySelector(".tile-eta");
    if (!box) return;
    const est = (state.profileEstimates || {})[profileId];
    const sto = (state.profileStorage || {})[profileId];
    // Durée et taille sont indépendantes : l'une peut manquer (matériau sans
    // scf.in lisible, pseudo introuvable) sans que l'encart disparaisse.
    if ((!est || !est.total_human) && (!sto || !sto.peak_human)) {
      box.hidden = true;
      return;
    }
    box.hidden = false;
    const clock = node.querySelector(".tile-eta-clock");
    if (clock) clock.hidden = !(est && est.total_human);
    if (!est || !est.total_human) {
      node.querySelector(".tile-eta-value").textContent = "";
      node.querySelector(".tile-eta-range").textContent = "";
      box.classList.remove("is-good", "is-fair", "is-weak");
      box.removeAttribute("title");
      renderTileSize(node, profileId);
      return;
    }
    box.classList.remove("is-good", "is-fair", "is-weak");
    box.classList.add(ETA_CONFIDENCE_CLASS[est.confidence] || "is-weak");
    node.querySelector(".tile-eta-value").textContent = est.total_human;
    node.querySelector(".tile-eta-range").textContent = est.range_human
      ? `(${est.range_human})`
      : "";
    box.title = t("eta.tileTooltip", {
      range: est.range_human || "?",
      confidence: est.confidence
        ? t(`eta.conf.${est.confidence}`)
        : "?",
      dominant: est.dominant_step || "?",
      nproc: est.nproc,
    });
    renderTileSize(node, profileId);
  }

  /**
   * Espace disque du profil, affiché à côté de la durée.
   *
   * C'est le **pic** qui est montré, pas la taille des résultats : sur un P2 de
   * silicium, 99,9 % des 1,3 Gio sont du scratch DFPT temporaire, mais il faut
   * bien les avoir libres pendant le calcul. L'infobulle détaille la part
   * réellement conservée pour éviter le contresens inverse.
   */
  function renderTileSize(node, profileId) {
    const wrap = node.querySelector(".tile-size");
    if (!wrap) return;
    const sto = (state.profileStorage || {})[profileId];
    if (!sto || !sto.peak_human) {
      wrap.hidden = true;
      return;
    }
    wrap.hidden = false;
    const val = node.querySelector(".tile-size-value");
    if (val) val.textContent = sto.peak_human;
    wrap.classList.toggle("is-tight", (sto.warnings || []).length > 0);
    wrap.title = t("storage.tileTooltip", {
      peak: sto.peak_human,
      scratch: sto.scratch_human || "?",
      retained: sto.retained_human || "?",
      free: sto.disk_free_human || "?",
    });
  }

  /**
   * Recharge les estimations pour les 5 profils.
   *
   * Le catalogue est re-sollicité car le coût dépend du matériau (nat, cutoff,
   * grilles k/q lus dans son scf.in) et de nproc. Seules les estimations sont
   * conservées : écraser ``state.profilesRaw`` ferait perdre la localisation
   * appliquée par ``localizeProfiles``.
   */
  async function refreshProfileEstimates() {
    const mid = state.selectedMaterialId;
    if (!mid) return;
    const nproc = parseInt(dom.nproc.value, 10) || 4;
    const key = `${mid}::${state.selectedScfBasename}::${nproc}`;
    if (state.profileEstimatesFor === key) return;
    try {
      const r = await window.ThermoPipeline.listProfiles(
        mid,
        state.selectedScfBasename,
        nproc
      );
      const map = {};
      const sizes = {};
      for (const p of r.profiles || []) {
        if (p.runtime_estimate) map[p.id] = p.runtime_estimate;
        if (p.storage_estimate) sizes[p.id] = p.storage_estimate;
      }
      state.profileEstimates = map;
      state.profileStorage = sizes;
      state.machineInfo = r.machine || null;
      state.profileEstimatesFor = key;
      renderProfiles();
      renderMachineInfo();
    } catch (e) {
      // Non bloquant : les tuiles restent utilisables sans estimation.
      appendLog(`[WARN] estimation de durée indisponible : ${e.message}`, "info");
    }
  }

  /** Résumé matériel + avertissements sur le nproc choisi. */
  function renderMachineInfo() {
    const el = dom.machineInfo;
    if (!el) return;
    const m = state.machineInfo;
    if (!m) {
      el.hidden = true;
      return;
    }
    const nproc = parseInt(dom.nproc.value, 10) || 4;
    const est = (state.profileEstimates || {})[state.selectedProfileId];
    const warnings = (est && est.warnings) || [];
    el.hidden = false;
    el.innerHTML =
      `<div class="machine-line">${t("machine.summary", {
        cpu: escapeHtml(m.cpu_model || "?"),
        phys: m.cores_physical,
        log: m.cores_logical,
        ram: Math.round((m.ram_total_mb || 0) / 1024),
        rec: m.recommended_nproc,
      })}</div>` +
      warnings
        .map((w) => `<div class="machine-warn">⚠️ ${escapeHtml(w)}</div>`)
        .join("");
    el.classList.toggle("has-warn", warnings.length > 0 && nproc > m.cores_physical);
  }

  function renderProfiles() {
    const grid = dom.profileGrid;
    grid.innerHTML = "";
    for (const p of state.profiles) {
      const node = dom.tileTpl.content.cloneNode(true);
      const tile = node.querySelector(".tile");
      node.querySelector(".tile-emoji").textContent = p.emoji || "";
      node.querySelector(".tile-name").textContent = p.name || p.id;
      node.querySelector(".tile-what").textContent = p.what_qe_display || p.what_qe || "";
      node.querySelector(".tile-desc").textContent = p.description || "";
      renderTileEta(node, p.id);
      tile.dataset.profileId = p.id;
      tile.addEventListener("click", () => {
      // Juin 2026 — burst ring (380ms) au clic pour confirmer la sélection.
      // Helper ``pulseClick`` : gère la race condition si l'utilisateur clique
      // 2 tuiles en <400ms (annule le timer précédent avant redémarrage).
      pulseClick(tile, "is-bursting", 380);
      state.selectedProfileId = state.selectedProfileId === p.id ? "" : p.id;
      for (const t of grid.querySelectorAll(".tile")) {
        t.classList.toggle("is-selected", t.dataset.profileId === state.selectedProfileId);
      }
      state.selectedProfileExpected = state.selectedProfileId
        ? (state.profiles.find((x) => x.id === state.selectedProfileId) || {}).expected_results || null
        : null;
      resetJobState();
      updateLaunchButton();
      renderMachineInfo(); // les avertissements dépendent du profil retenu
      refreshTpwinPreview();
      renderProfilePreview();
      renderP5ExtrasPanel();
      renderP1PresetPanel();
    });
      grid.appendChild(tile);
    }
  }

  // --------- ② thermo_pw.in preview ---------
  async function refreshTpwinPreview(force) {
    const pid = state.selectedProfileId;
    const mid = state.selectedMaterialId;
    const nproc = parseInt(dom.nproc.value, 10) || 4;
    if (!pid) {
      dom.tpwinIdentity.innerHTML =
        '<span class="muted">' + t("sec2.waitProfileOnly") + '</span>';
      dom.tpwinParams.hidden = true;
      dom.tpwinPreviewBody.textContent = t("sec2.waitSelection");
      return;
    }
    if (!mid) {
      dom.tpwinIdentity.innerHTML = t("tpwin.waitMat", { pid: escapeHtml(pid) });
      dom.tpwinParams.hidden = true;
      dom.tpwinPreviewBody.textContent = t("tpwin.materialRequired");
      return;
    }
    const cacheKey = `${pid}::${mid}::${nproc}`;
    if (!force && state.tpwinPreviewLoadedFor === cacheKey) return;
    dom.tpwinIdentity.innerHTML = t("tpwin.generating", {
      pid: escapeHtml(pid),
      mid: escapeHtml(mid),
      nproc: nproc,
    });
    try {
      const r = await window.ThermoPipeline.thermoPwInPreview(pid, mid, nproc);
      state.tpwinPreviewLoadedFor = cacheKey;
      const prof = state.profiles.find((p) => p.id === pid);
      dom.tpwinIdentity.innerHTML = t("tpwin.identity", {
        pid: escapeHtml(r.profile_id),
        pname: escapeHtml(r.profile_name),
        what: escapeHtml(r.what || ""),
        mid: escapeHtml(mid),
        nproc: nproc,
      });
      const tbody = dom.tpwinParams.querySelector("tbody");
      tbody.innerHTML = "";
      const params = Array.isArray(r.params) ? r.params : [];
      for (const prm of params) {
        const tr = document.createElement("tr");
        tr.innerHTML =
          `<td><code>${escapeHtml(prm.key || "")}</code></td>` +
          `<td>${escapeHtml(prm.value || "")}</td>`;
        tbody.appendChild(tr);
      }
      dom.tpwinParams.hidden = params.length === 0;
      dom.tpwinPreviewBody.textContent = r.summary_text || t("tpwin.empty");
    } catch (e) {
      dom.tpwinIdentity.innerHTML =
        '<span class="muted error">' + t("tpwin.unavailable", { msg: escapeHtml(e.message) }) + '</span>';
      dom.tpwinParams.hidden = true;
      dom.tpwinPreviewBody.textContent = "—";
    }
  }

  // --------- ③ Lancer ---------
  function setLaunchState(kind, label) {
    if (!dom.launchState) return;
    dom.launchState.innerHTML =
      `<span class="state-dot state-${escapeHtml(kind)}"></span>` +
      `<span class="state-label">${escapeHtml(label || "")}</span>`;
  }

  function updateLaunchButton() {
    const ok =
      state.selectedMaterialId &&
      state.selectedScfBasename &&
      state.selectedProfileId &&
      !state.currentJobId;
    dom.launchBtn.disabled = !ok;
    if (ok) {
      const prof = state.profiles.find((p) => p.id === state.selectedProfileId);
      setLaunchState("ready",
        (state.lang === "fr" ? "Prêt : " : "Ready: ") +
        `${state.selectedMaterialId}/${state.selectedScfBasename} · ` +
        (state.lang === "fr" ? "profil " : "profile ") +
        (prof?.name || state.selectedProfileId));
      // Prévisualiser le dossier de sortie : on montre explicitement le chemin
      // **prévu** (work/<material_id>/pipeline_<profile_id>_<ts>_<rand>/)
      // AVANT le lancement, ainsi l'utilisateur a la certitude que le dossier
      // sera bien créé au clic. Si un calcul précédent est encore affiché en
      // is-done/is-error, on n'écrase pas le chemin « réel » existant.
      if (
        dom.resultWorkdir &&
        !dom.resultWorkdir.classList.contains("is-running") &&
        !dom.resultWorkdir.classList.contains("is-done")
      ) {
        const tag = `${state.selectedMaterialId} / pipeline_${state.selectedProfileId}_<timestamp>`;
        const fakeProfileId = state.selectedProfileId;
        const fakeJob = {
          work_dir: `work/${tag}`,
          profile_id: fakeProfileId,
          _preview: true,
        };
        renderWorkdir(fakeJob, "ready");
      }
    } else if (!state.currentJobId) {
      const missing = [];
      const missMap = state.lang === "fr"
        ? { profile: "profil", material: "matériau", "scf.in": "scf.in" }
        : { profile: "profile", material: "material", "scf.in": "scf.in" };
      if (!state.selectedProfileId) missing.push(missMap.profile);
      if (!state.selectedMaterialId) missing.push(missMap.material);
      if (!state.selectedScfBasename) missing.push(missMap["scf.in"]);
      setLaunchState("idle", t("launch.missing") + " " + (missing.join(", ") || "—"));
      // Pas de sélection complète — on cache poliment la preview pour éviter
      // d'afficher un chemin « prévision » incomplet. On n'écrase pas un état
      // done/error (un job précédent peut rester visible).
      if (
        dom.resultWorkdir &&
        !dom.resultWorkdir.classList.contains("is-done") &&
        !dom.resultWorkdir.classList.contains("is-error") &&
        !dom.resultWorkdir.classList.contains("is-running")
      ) {
        dom.resultWorkdir.hidden = true;
      }
    }
    if (dom.launchBarHero) {
      dom.launchBarHero.classList.toggle("is-ready", ok);
    }
    updateWorkflowStepper();
  }

  function showProgress(visible, pct, label) {
    dom.progressWrap.hidden = !visible;
    if (!visible) return;
    if (typeof pct === "number") {
      dom.progressBar.style.width = Math.max(8, Math.min(100, pct)) + "%";
    }
    dom.progressText.textContent = label || "";
  }

  // Réinitialise les indicateurs visuels "job fini / erreur" quand l'utilisateur change la sélection.
  // Le bandeau « CALCULS TERMINÉS » disparaît, le bloc de sortie perd ses teintes done/error.
  // Le bloc est ensuite régénéré en mode "ready" (preview) par ``updateLaunchButton``.
  // Efface aussi le pickéer de run chargé (``clearLoadedRun``) — l'utilisateur
  // exprime qu'il veut préparer un nouveau calcul, donc l'affichage du run
  // précédent en section ④ serait trompeur.
  function resetJobState() {
    if (dom.resultWorkdir) {
      dom.resultWorkdir.classList.remove("is-done", "is-error");
    }
    if (dom.doneBanner) dom.doneBanner.hidden = true;
    if (state.loadedJobId) clearLoadedRun();
    // Le bloc « validité scientifique » est lié au run courant ; on le
    // masque aussi pour éviter qu'il reste collé à un profil ancien pendant
    // que l'utilisateur prépare un nouveau calcul.
    clearSanity();
    clearExpertise();
  }

  function appendLog(line, cls) {
    const ts = line.startsWith("[") ? "" : new Date().toLocaleTimeString() + " ";
    const span = document.createElement("span");
    span.textContent = `${ts}${line}`;
    if (cls) span.classList.add(cls);
    dom.logBox.appendChild(span);
    dom.logBox.appendChild(document.createTextNode("\n"));
    while (dom.logBox.childNodes.length > MAX_LOG_LINES * 2) {
      dom.logBox.removeChild(dom.logBox.firstChild);
    }
    dom.logBox.scrollTop = dom.logBox.scrollHeight;
  }

  function resetLog() { dom.logBox.innerHTML = ""; }

  async function launchPipeline() {
    resetLog();
    dom.cancelBtn.hidden = false;
    state.scfPreviewLoadedFor = "";
    state.tpwinPreviewLoadedFor = "";
    // Lancement d'un nouveau job = on jette l'état « run chargé » du picker
    // pour éviter l'ambiguïté visuelle entre résultats rechargés et un
    // nouveau calcul en cours. ``resetJobState`` s'en charge.
    resetJobState();
    updateLaunchButton();
    showProgress(true, 5, "Launching calculation series…");
    setLaunchState("running", t("launch.running"));
    appendLog(
        `Lancement : matériau=${state.selectedMaterialId}, ` +
        `profil=${state.selectedProfileId}, ` +
        `scf=${state.selectedScfBasename}, nproc=${parseInt(dom.nproc.value, 10) || 1}`
      );
      const body = {
        material_id: state.selectedMaterialId,
        profile_id: state.selectedProfileId,
        scf_in_basename: state.selectedScfBasename,
        nproc: parseInt(dom.nproc.value, 10) || 1,
      };
      // --- P5 extras (juin 2026) ---
      // Si P5 est sélectionné, on collecte les cases cochées du panneau
      // « Propriétés thermo_pw.x étendues » dans ``body.extra_whats``.
      // Aucune option cochée ⇒ la valeur par défaut du profil s'applique
      // (plot_bz) côté serveur, via ``PipelineJob(extra_whats=None)``.
      if (state.selectedProfileId === "P5" && dom.p5ExtrasPanel) {
        const checked = collectP5ExtrasSelection();
        if (checked.length > 0) {
          body.extra_whats = checked;
          appendLog(
            `  [P5 extras] = ${checked.join(", ") || "(vide)"}.`
          );
        } else {
          appendLog(
            "  [P5 extras] none checked ⇒ profile default (plot_bz)."
          );
        }
        // Opt-in chaîne optique exhaustive ε(ω) (epsilon.x + turbo).
        if (dom.p5OpticalCheckbox && dom.p5OpticalCheckbox.checked) {
          body.needs_optical = true;
          appendLog(
            "  [P5 optical] full optical chain ε(ω) enabled (epsilon.x + turbo)."
          );
        }
      }      // --- Juillet 2026 — preset P1 « Cᵢⱼ + DOS + Bandes » ---
      // When selected profile is P1 and the dedicated checkbox in the UI
      // is checked, append ``p1_full_preset: true`` to the payload. Backend
      // enforces: applies only on P1 (no-op + warning elsewhere).
      if (state.selectedProfileId === "P1" &&
          dom.p1PresetCheckbox &&
          dom.p1PresetCheckbox.checked) {
        body.p1_full_preset = true;
        appendLog(
          "  [P1 preset] full enabled: Cᵢⱼ + DOS + Bands (ichamp=3)."
        );
      }
      // --- Juillet 2026 — opt-in P1 « correction LO/TO » ---
      // Chaîne dielectric → BORN → matdyn non_analytic (pseudos NC requis ;
      // le backend refuse proprement les US-PP/PAW sans invalider le run).
      if (state.selectedProfileId === "P1" &&
          dom.loToCheckbox &&
          dom.loToCheckbox.checked) {
        body.lo_to_opt_in = true;
        appendLog(
          "  [P1 LO/TO] non-analytic correction enabled (dielectric → BORN → matdyn)."
        );
      }

    try {
      const resp = await window.ThermoPipeline.runPipeline(body);
      state.currentJobId = resp.job_id;
      // Juin 2026 — persistance du job_id pour reprise automatique après
      // refresh. Sans cette ligne, un rafraîchissement de page pendant
      // un calcul long interrompait définitivement le live polling et
      // obligeait l'utilisateur à rouvrir le run via le picker.
      persistCurrentJob(state.currentJobId);
      renderProfilePreview();
      appendLog(`Job créé : ${resp.job_id}`, "ok");
      appendLog(`work_dir: ${resp.work_dir || "(generated by API)"}`);
      updateLaunchButton();
      startPolling(resp.job_id);
    } catch (e) {
      appendLog(`[ERR] Lancement impossible : ${e.message}`, "err");
      appendLog(`Détail : ${JSON.stringify(e.data || {}, null, 2)}`, "err");
      showProgress(false);
      dom.cancelBtn.hidden = true;
      setLaunchState("error", `Erreur : ${e.message}`);
      updateLaunchButton();
    }
  }

  /** Rattache l'UI au polling live (lancement ou reprise thermo_pw / restart). */
  function attachLiveJob(jobId, message) {
    if (!jobId) return;
    state.currentJobId = jobId;
    persistCurrentJob(jobId);
    window.__seenLogs = window.__seenLogs || new Set();
    setLaunchState("running", message || "Calcul en cours…");
    showProgress(true, 5, "En cours…");
    if (dom.cancelBtn) dom.cancelBtn.hidden = false;
    startPolling(jobId);
  }

  async function startPolling(jobId) {
    if (state.pollTimer) clearInterval(state.pollTimer);
    // Anti-empilement (août 2026) : setInterval déclenche un tick toutes les
    // 1.5 s sans attendre le précédent. Quand la machine est saturée par
    // pw.x/ph.x, une réponse peut frôler le timeout fetch de 30 s — une
    // vingtaine de requêtes s'accumulaient alors en parallèle et achevaient
    // une API déjà affamée, la lenteur s'auto-entretenant jusqu'au timeout.
    let inFlight = false;
    let netFailStreak = 0;
    const tick = async () => {
      if (inFlight) return;
      inFlight = true;
      try {
        const j = await window.ThermoPipeline.jobStatus(jobId);
        netFailStreak = 0;
        renderJobTick(j);
        if (["done", "error", "cancelled", "stopped"].includes(j.status)) {
          stopPolling();
          finalizeJob(j);
        } else if (["paused", "interrupted"].includes(j.status)) {
          stopPolling();
          appendLog(`== ${j.status.toUpperCase()} == ${j.message || ""}`, "info");
          showProgress(false);
          updateLaunchButton();
        }
      } catch (e) {
        // Cas « stale » : le daemon a redémarré entre deux polls et l'in-memory
        // _REGISTRY ne contient plus ce job. Sans ce court-circuit, fetch.log
        // splammait `[ERR] polling : job_id inconnu` à chaque tick de 1.5 s
        // (parfois des dizaines de fois d'affilée) sans qu'on puisse relancer.
        // On stoppe le poll, on vide l'ID local, et on affiche UN message doux.
        if (e && e.staleJob === true) {
          stopPolling();
          state.currentJobId = "";
          appendLog(
            "[INFO] Job lost: server restarted (in-memory registry cleared). Re-run the calculation to resume.",
            "info"
          );
          // Met à jour le bouton « Lancer » qui se gate sur ``!state.currentJobId``.
          // C'est la fonction canonique (L300-318) qui re-évalue l'état UI quand
          // le champ currentJobId change — pas de garde ``typeof``, elle existe.
          updateLaunchButton();
          return;
        }
        // Timeout ou coupure réseau : le calcul continue côté serveur et le
        // tick suivant reprendra le suivi. On n'alerte donc pas à chaque
        // échec, sinon le journal est noyé pendant une étape DFPT longue.
        if (e && e.network === true) {
          netFailStreak += 1;
          if (netFailStreak === 1 || netFailStreak % 10 === 0) {
            appendLog(
              `[WARN] polling sans réponse (${netFailStreak}×) : ${e.message} — ` +
                "le calcul continue côté serveur, nouvelle tentative automatique.",
              "info"
            );
          }
          return;
        }
        appendLog(`[ERR] polling : ${e.message}`, "err");
      } finally {
        inFlight = false;
      }
    };
    tick();
    state.pollTimer = setInterval(tick, POLL_INTERVAL_MS);
  }
  function stopPolling() {
    if (state.pollTimer) { clearInterval(state.pollTimer); state.pollTimer = null; }
  }

  /**
   * Suffixe « temps restant » de la barre de progression.
   *
   * ``j.eta.basis`` distingue un reste mesuré sur le run en cours (coût réel
   * par point q relevé dans ph.out) d'une simple projection a priori. La
   * nuance est affichée car les deux n'ont pas la même valeur : un ETA mesuré
   * reste fiable même quand l'estimation initiale se trompe d'un facteur deux.
   */
  function formatLiveEta(j) {
    const eta = j && j.eta;
    if (!eta || !eta.remaining_human) return "";
    const measured = String(eta.basis || "").startsWith("mesuré");
    const d = eta.detail || {};
    let extra = "";
    // Boucle QHA de thermo_pw.x : progression « géométrie k/N » (août 2026).
    if (d.geometries_total) {
      extra = t("eta.geoProgress", {
        done: d.geometries_done || 0,
        total: d.geometries_total,
      });
    } else if (d.q_total) {
      extra = t("eta.qProgress", { done: d.q_done || 0, total: d.q_total });
    } else if (d.volumes_total) {
      extra = t("eta.volProgress", {
        done: d.volumes_done || 0,
        total: d.volumes_total,
      });
    }
    return t(measured ? "eta.liveMeasured" : "eta.liveEstimated", {
      remaining: eta.remaining_human,
      extra: extra,
    });
  }

  /**
   * Occupation disque réelle du calcul en cours.
   *
   * Mesurée côté serveur en parcourant le work_dir : c'est le chiffre qui dit
   * si l'estimation initiale tenait, et le seul moyen de voir venir une
   * saturation avant qu'elle n'interrompe le calcul.
   */
  function formatLiveDisk(j) {
    const du = j && j.disk_usage;
    if (!du || !du.total_human || !du.total_bytes) return "";
    return t("storage.live", { total: du.total_human });
  }

  function renderJobTick(j) {
    const etaSuffix = formatLiveEta(j) + formatLiveDisk(j);
    state.progressEtaText = etaSuffix;
    if (j.message) {
      const m = String(j.message).slice(0, 200);
      const composed = etaSuffix ? `${m} — ${etaSuffix}` : m;
      if (!dom.progressText.textContent || dom.progressText.dataset.msg !== composed) {
        dom.progressText.dataset.msg = composed;
        dom.progressText.textContent = composed;
        setLaunchState("running", m);
      }
    }
    if (Array.isArray(j.steps) && j.steps.length) {
      const done = j.steps.filter((s) => s.status === "done").length;
      const totalExpected = Math.max(j.steps.length, 5);
      showProgress(true, Math.round((done / totalExpected) * 100), dom.progressText.textContent);
    }
    if (Array.isArray(j.logs)) {
      for (const line of j.logs.slice(-50)) {
        if (!window.__seenLogs) window.__seenLogs = new Set();
        if (window.__seenLogs.has(line)) continue;
        window.__seenLogs.add(line);
        appendLog(line, line.includes("ERR") ? "err" : (line.includes("termin") ? "ok" : ""));
      }
    }
    updateLiveResults(j);
    if (state.loadedJobId && state.loadedJobId === j.job_id) {
      state.loadedRecord = j;
    }
    const artifactJobId = state.loadedJobId || state.currentJobId;
    if (artifactJobId && artifactJobId === j.job_id) {
      state._artifactPollN = (state._artifactPollN || 0) + 1;
      if (state._artifactPollN % 2 === 0) fetchAndRenderArtifacts(j.job_id);
    }
    // Le bloc « dossier de sortie » se met à jour à chaque tick : work_dir
    // fixé dès le POST /api/pipeline/run, badge alimenté au fil de l'eau.
    renderWorkdir(j, "running");
    // Sync lifecycle buttons on every poll tick
    if (j.status && j.job_id) {
      window.__thermo_lastStatus = j.status.toLowerCase();
      _syncLifecycleBtns(j.job_id, window.__thermo_lastStatus);
    }
  }

  function finalizeJob(j) {
    showProgress(false);
    // Sync lifecycle buttons for terminal state (show Restart if error/cancelled)
    if (j.status && j.job_id) {
      window.__thermo_lastStatus = j.status.toLowerCase();
      _syncLifecycleBtns(j.job_id, window.__thermo_lastStatus);
    }
    state.currentJobId = "";
    // Juin 2026 — libère le slot localStorage au statut terminal (done /
    // error / cancelled) : le job a fini, le LS ne sert plus. tryResumePendingJob
    // au prochain refresh n'aura rien à reprendre.
    clearCurrentJob();
    window.__seenLogs = new Set();
    updateLaunchButton();
    appendLog(`== ${j.status.toUpperCase()} ==  ${j.message || ""}`, j.status === "done" ? "ok" : "err");
    if (j.status === "done") {
      updateLiveResults(j);
      renderDoneBanner(j);
      renderWorkdir(j, "done");
      setLaunchState("done", t("launch.done"));
      // Afficher le bandeau vert « CALCULS TERMINÉS » dans la section Lancer
      // pour donner un signal visuel clair et proéminent de la fin.
      if (dom.doneBanner) dom.doneBanner.hidden = false;
      // Sanity-checks scientifiques best-effort (rappel des anomalie(s)).
      fetchAndRenderSanity(j.job_id);
      fetchAndRenderExpertise(j.job_id);
      // Juillet 2026 (axe 3) — panneau Artefacts : listing exhaustif cliquable.
      fetchAndRenderArtifacts(j.job_id);
      setTimeout(() => scrollToWorkflowSection("#resultsCard"), 700);
    } else if (j.status === "cancelled") {
      renderWorkdir(j, "error");
      setLaunchState("idle", t("launch.cancelled"));
      if (dom.doneBanner) dom.doneBanner.hidden = true;
    } else {
      renderWorkdir(j, "error");
      setLaunchState("error", `Erreur — ${j.message || ""}`);
      if (dom.doneBanner) dom.doneBanner.hidden = true;
      // En cas d'erreur on peut quand même tenter un sanity best-effort
      // (certains checks comme ``force_residual`` peuvent être diagnostiqués
      // même si le run n'est pas alloué jusqu'au bout).
      fetchAndRenderSanity(j.job_id);
    fetchAndRenderExpertise(j.job_id);
    updateRunsReparseButton();
    syncCompareSelectOptions();
  }
  }

  async function cancelJob() {
    if (!state.currentJobId) return;
    try {
      await window.ThermoPipeline.cancelJob(state.currentJobId);
      appendLog("Cancellation signalled…", "err");
    } catch (e) {
      appendLog(`[ERR] annulation : ${e.message}`, "err");
    }
  }

  // --------- Sanity-checks scientifiques (tendances à attendre pour chercheurs) ---------
  // Charge, depuis l'API ``/api/pipeline/runs/<id>/sanity``, les 5 vérifications
  // clés (phonons, Born, Poisson, B', forces). Rend lisible par niveau (ok/warn/
  // error/unknown). Best-effort côté backend → ne lève jamais, masqué si la
  // réponse est inutilisable.
  async function fetchAndRenderSanity(jobId) {
    if (!dom.sanityBlock || !jobId) return;
    try {
      const r = await window.ThermoPipeline.runSanity(jobId);
      renderSanity(r);
    } catch (e) {
      // En cas d'erreur backend : on cache le bloc poliment (pas d'alerte rouge).
      if (dom.sanityBlock) {
        dom.sanityBlock.hidden = true;
        if (dom.sanityList) dom.sanityList.innerHTML = "";
      }
      appendLog(
        `[WARN] sanity indisponible pour ${(jobId || "").slice(0, 8)} : ${e.message}`,
        "err"
      );
    }
  }

  function renderSanity(r) {
    if (!dom.sanityBlock || !dom.sanitySummary || !dom.sanityList) return;
    if (!r || !Array.isArray(r.checks)) {
      dom.sanityBlock.hidden = true;
      return;
    }
    const sum = r.summary || {};
    const nError = sum.n_error || 0;
    const nWarn = sum.nWarn || sum.n_warn || 0;
    const nOk = sum.n_ok || 0;
    const summaryParts = [];
    if (sum.score_text) summaryParts.push(sum.score_text);
    if (nError) summaryParts.push(`🔴 ${nError} erreur${nError > 1 ? "s" : ""}`);
    if (nWarn)  summaryParts.push(`🟡 ${nWarn} avertissement${nWarn > 1 ? "s" : ""}`);
    if (!nError && !nWarn) summaryParts.push("🟢 tout valide");
    dom.sanitySummary.textContent = summaryParts.join(" · ");
    dom.sanityList.innerHTML = "";
    const allOk = (nError === 0 && nWarn === 0 && nOk > 0);
    dom.sanityBlock.classList.toggle("is-all-ok", allOk);
    for (const c of r.checks) {
      const lv = String(c.level || "unknown");
      const div = document.createElement("div");
      div.className = `sanity-banner is-${lv}`;
      div.dataset.checkId = c.id || "";
      const parts = [
        `<span class="sb-icon" aria-hidden="true">${escapeHtml(c.icon || "\u2022")}</span>`,
        `<div class="sb-body">`,
        `<div class="sb-title">${escapeHtml(c.title || c.id || "")}</div>`,
        `<div class="sb-message">${escapeHtml(c.message || "")}</div>`,
      ];
      if (c.source) {
        parts.push(
          `<div class="sb-source">source : ${escapeHtml(String(c.source))}</div>`
        );
      }
      parts.push(`</div>`);
      div.innerHTML = parts.join("");
      dom.sanityList.appendChild(div);
    }
    dom.sanityBlock.hidden = false;
  }

  function clearSanity() {
    if (!dom.sanityBlock) return;
    dom.sanityBlock.hidden = true;
    dom.sanityBlock.classList.remove("is-all-ok");
    if (dom.sanityList) dom.sanityList.innerHTML = "";
  }

  function clearExpertise() {
    if (!dom.resultsExpertise) return;
    dom.resultsExpertise.hidden = true;
    if (dom.expertiseList) dom.expertiseList.innerHTML = "";
    if (dom.expertiseSummary) dom.expertiseSummary.textContent = "—";
    if (dom.expertiseFactsheetBtn) dom.expertiseFactsheetBtn.hidden = true;
  }

  async function fetchAndRenderExpertise(jobId) {
    if (!dom.resultsExpertise || !jobId) return;
    try {
      const r = await window.ThermoPipeline.runExpertise(jobId);
      renderExpertise(r, jobId);
    } catch (e) {
      clearExpertise();
      appendLog(
        `[WARN] analyse experte indisponible pour ${(jobId || "").slice(0, 8)} : ${e.message}`,
        "err"
      );
    }
  }

  function renderExpertise(r, jobId) {
    if (!dom.resultsExpertise || !dom.expertiseList) return;
    const insights = (r && Array.isArray(r.insights)) ? r.insights : [];
    if (!insights.length) {
      clearExpertise();
      return;
    }
    const sum = (r && r.summary) || {};
    if (dom.expertiseSummary) {
      const parts = [];
      if (sum.n_success) parts.push(`✅ ${sum.n_success}`);
      if (sum.n_warning) parts.push(`🟡 ${sum.n_warning}`);
      if (sum.n_error) parts.push(`🔴 ${sum.n_error}`);
      dom.expertiseSummary.textContent = parts.length
        ? t("sec4.expertiseSummaryOk", {
            nOk: sum.n_success || 0,
            nWarn: sum.n_warning || 0,
            nErr: sum.n_error || 0,
          })
        : t("sec4.expertiseSummaryEmpty");
    }
    dom.expertiseList.innerHTML = "";
    for (const ins of insights) {
      const lv = String(ins.level || "info");
      const div = document.createElement("div");
      div.className = `re-insight is-${lv}`;
      div.innerHTML =
        `<span class="ri-icon" aria-hidden="true">${escapeHtml(ins.icon || "•")}</span>` +
        `<div class="ri-body">` +
        `<div class="ri-title">${escapeHtml(ins.title || "")}</div>` +
        `<div class="ri-text">${escapeHtml(ins.body || "")}</div>` +
        (ins.category
          ? `<div class="ri-cat">${escapeHtml(ins.category)}</div>`
          : "") +
        `</div>`;
      dom.expertiseList.appendChild(div);
    }
    if (dom.expertiseFactsheetBtn && jobId) {
      dom.expertiseFactsheetBtn.hidden = false;
      dom.expertiseFactsheetBtn.onclick = () => {
        const url = window.ThermoPipeline.factsheet(jobId, "html");
        window.open(url, "_blank", "noopener,noreferrer");
      };
    }
    dom.resultsExpertise.hidden = false;
  }

  // --------- ④ Résultats (preview + live streaming) ---------
  function clearResults() {
    dom.resultSummary.innerHTML = "";
    dom.resultFiles.innerHTML = "";
    dom.resultPlots.innerHTML = "";
    if (dom.resultEmpty) dom.resultEmpty.classList.remove("hidden");
    if (dom.resultsMeta) dom.resultsMeta.textContent = "";
    // Bloc work_dir : on ne le cache pas une fois révélé (le user veut
    // toujours voir où sont les fichiers de la dernière série), mais on
    // le ramène à un état « neutre » sans révéler d'ancien chemin.
    if (dom.resultWorkdir) {
      dom.resultWorkdir.hidden = true;
      dom.resultWorkdir.classList.remove("is-running", "is-done", "is-error");
      if (dom.resultWorkdirPath) {
        dom.resultWorkdirPath.textContent = "(not generated)";
        dom.resultWorkdirPath.title = "";
      }
      if (dom.resultWorkdirBadge) {
        dom.resultWorkdirBadge.hidden = true;
        dom.resultWorkdirBadge.textContent = "";
      }
      if (dom.resultWorkdirHint) dom.resultWorkdirHint.textContent = "";
    }
    if (dom.resultsTensorPanels) {
      dom.resultsTensorPanels.hidden = true;
      dom.resultsTensorPanels.innerHTML = "";
    }
  }

  // Met à jour le bloc « Dossier de sortie » à partir d'un job state `j`.
  // Affiche le work_dir complet + le badge (nb fichiers produits) + un
  // libellé profile-aware décrivant ce qui sera trouvé sur disque.
  // ``phase`` ∈ {"running", "done", "error"} — pilote la teinte du cadre.
  function renderWorkdir(j, phase) {
    if (!dom.resultWorkdir) return;
    const wd = (j && j.work_dir) || "";
    if (!wd) {
      // Pas encore de work_dir (job pas lancé) : on cache poliment.
      dom.resultWorkdir.hidden = true;
      return;
    }
    const prof = state.profiles.find((p) => p.id === (j.profile_id || ""));
    const hint = (prof && (prof.storage_hint || PROFILE_STORAGE_HINTS_FALLBACK[prof.id])) ||
      "All files generated by the calculation series (per profile).";
    const out = j.results && Array.isArray(j.results.output_files)
      ? j.results.output_files : [];
    const cij = j.results && Array.isArray(j.results.elastic_dat_files)
      ? j.results.elastic_dat_files : [];

    dom.resultWorkdir.hidden = false;
    dom.resultWorkdir.classList.remove("is-running", "is-done", "is-error", "is-ready");
    dom.resultWorkdir.classList.add("is-" + (phase || "running"));

    if (dom.resultWorkdirPath) {
      dom.resultWorkdirPath.textContent = wd;
      dom.resultWorkdirPath.title = wd;
    }
    if (dom.resultWorkdirBadge) {
      if (out.length || cij.length) {
        const parts = [`${out.length} fichier(s)`];
        if (cij.length) parts.push(`${cij.length} Cij`);
        dom.resultWorkdirBadge.textContent = parts.join(" · ");
        dom.resultWorkdirBadge.hidden = false;
      } else {
        dom.resultWorkdirBadge.hidden = true;
      }
    }
    if (dom.resultWorkdirHint) {
      // On annote par phase pour rester pédagogique (en cours → terminee).
      // ``ready`` = preview avant lancement : le dossier n'existe pas encore
      // sur disque, le chemin est annoncé.
      const phaseNote = phase === "done"
        ? "Series complete — all files are available in this folder."
        : phase === "error"
          ? "Interruption / error: already written files are kept for diagnostics."
          : phase === "ready"
            ? "Preview — this folder will be created automatically at launch."
            : "Series in progress: content is being populated progressively (live).";
      dom.resultWorkdirHint.textContent =
        `${phaseNote} Contenu attendu : ${hint}`;
    }
  }

  // Handler unique du bouton « Copier » : clipboard API avec fallback
  // execCommand pour navigateurs anciens (le bouton ne reste pas inactif).
  function setupWorkdirCopyHandler() {
    if (!dom.resultWorkdirCopy || !dom.resultWorkdirPath) return;
    dom.resultWorkdirCopy.addEventListener("click", async () => {
      const text = dom.resultWorkdirPath.textContent || "";
      if (!text || text === "(not generated)") return;
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(text);
        } else {
          // Fallback : on crée un textarea temporaire (Safari/anciens).
          const ta = document.createElement("textarea");
          ta.value = text;
          ta.style.position = "fixed"; ta.style.opacity = "0";
          document.body.appendChild(ta);
          ta.select();
          try { document.execCommand("copy"); } finally { ta.remove(); }
        }
        // Feedback visuel : flash vert pendant ~1.4 s.
        dom.resultWorkdirCopy.classList.add("flash");
        const orig = dom.resultWorkdirCopy.textContent;
        dom.resultWorkdirCopy.textContent = "✅ Copied!";
        setTimeout(() => {
          dom.resultWorkdirCopy.classList.remove("flash");
          dom.resultWorkdirCopy.textContent = orig;
        }, 1400);
      } catch (_e) {
        appendLog(`[ERR] copie clipboard impossible.`, "err");
      }
    });
  }

  /** Remet la section ④ en mode « aperçu attendu » (sans valeurs empruntées). */
  function _resetPreviewLiveState() {
    if (dom.resultsCard) dom.resultsCard.classList.remove("has-live-results");
    renderPropertyGapsPanel(null);
    renderTensorPanels(null);
    renderCvCpInteractiveChart(null);
  }

  function renderProfilePreview() {
    const prof = state.profiles.find((p) => p.id === state.selectedProfileId);
    state.selectedProfileExpected = prof ? (prof.expected_results || {}) : null;
    if (!prof) { clearResults(); _resetPreviewLiveState(); return; }
    if (!state.loadedJobId && !state.currentJobId) {
      _resetPreviewLiveState();
    }
    const er = state.selectedProfileExpected || {};
    if (dom.resultsMeta) {
      // ``what_qe_display`` (ex. « mur_lc_t (QHA) » pour P2) plutôt que la clé
      // interne legacy — cohérent avec l'affichage des tuiles de profil.
      dom.resultsMeta.textContent =
        `${prof.emoji || ""} ${prof.what_qe_display || prof.what_qe || ""}`.trim();
    }
    dom.resultSummary.innerHTML = "";
    const metrics = Array.isArray(er.metrics) ? er.metrics : [];
    if (!metrics.length) {
      const m = document.createElement("div");
      m.className = "metric";
      m.innerHTML = '<div class="lab">Statut</div><div class="val text-pending">—</div>';
      dom.resultSummary.appendChild(m);
    } else {
      // Grille avec en-têtes de groupes thématiques (EOS, C_ij, électronique…).
      renderMetricsGrid(dom.resultSummary, metrics);
    }
    dom.resultPlots.innerHTML = "";
    const plots = Array.isArray(er.plots) ? er.plots : [];
    for (const pdef of plots) {
      const fig = document.createElement("figure");
      fig.dataset.plotKey = pdef.key || "";
      fig.classList.add("plot-pending");
      const img = document.createElement("img");
      img.alt = pdef.label || pdef.key || "";
      img.loading = "lazy";
      const cap = document.createElement("figcaption");
      cap.textContent = pdef.label || pdef.key || "";
      fig.appendChild(img);
      fig.appendChild(cap);
      dom.resultPlots.appendChild(fig);
    }
    if (!plots.length) {
      const empty = document.createElement("div");
      empty.className = "result-empty";
      empty.textContent = "Aucun graphique n'est attendu pour ce profil.";
      dom.resultPlots.appendChild(empty);
    }
    dom.resultFiles.innerHTML = "";
    const files = Array.isArray(er.files) ? er.files : [];
    for (const fdef of files) {
      const c = document.createElement("span");
      c.className = "chip chip-pending";
      // juillet 2026 — cheatsheet branchée (voir /api/cheatsheet_outputs)
  c.title = `Attendu : ${fdef.label || fdef.name || ""} — voir panneau « cheatsheet sorties » ci-dessus`;
      c.dataset.fileName = fdef.name || fdef.key || "";
      c.textContent = fdef.name || fdef.key || "—";
      dom.resultFiles.appendChild(c);
    }
    if (dom.resultEmpty) {
      dom.resultEmpty.classList.remove("hidden");
      dom.resultEmpty.textContent =
        `⏳ ${t("sec4.previewBanner", {
          name: prof.name || prof.id,
          metrics: metrics.length,
          plots: plots.length,
          files: files.length,
        })}`;
    }
  }

  // Provenance C_ij (juillet 2026) — helper forward-compat :
  //   * Cree/met-a-jour un <div class="metric metric-source"> dans
  //     dom.resultSummary UNIQUEMENT si ``j.results.elastic.source``
  //     vaut ``"fallback_per_strain_gN"`` ou ``"aggregated_vs_T"``.
  //   * Pour tous les anciens markers (cle absente / None / string
  //     inconnue) : le div est SUPPRIME (idempotent), aucun crash, 0
  //     regression cote UI.
  //   * Le rendu du badge utilise les classes CSS deja definies
  //     (``.badge-loading`` de base + ``.badge-warning`` / ``.badge-success``
  //     de app_v2.css). Forward-compat garanti par le retrait du div si la
  //     cle devient inconnue a un poll ulterieur.
  function _renderElasticSourceBadgeIntoSummary(j) {
    if (!dom.resultSummary) return;
    const source = getNestedValue(j.results || {}, "elastic.source");
    let wrap = dom.resultSummary.querySelector(".metric-source");
    if (source === "fallback_per_strain_gN" || source === "aggregated_vs_T") {
      if (!wrap) {
        wrap = document.createElement("div");
        wrap.className = "metric metric-source";
        dom.resultSummary.appendChild(wrap);
      }
      const isFinal = source === "aggregated_vs_T";
      const cls = isFinal ? "badge-success" : "badge-warning";
      const lbl = isFinal ? "Final data" : "Partial preview";
      // Le ``.lab`` est en textContent (pas d'injection via innerHTML),
      // seul le badge reste en innerHTML (literal code controle).
      wrap.innerHTML =
        '<div class="lab">Provenance Cij</div>' +
        '<div class="val text-live"><span class="badge ' + cls +
        '">' + lbl + '</span></div>';
    } else if (wrap) {
      // Source inconnue / absente : on retire la div pour eviter un badge
      // "fantome" quand le polling bascule le marker.
      wrap.remove();
    }
  }

  function renderCvCpInteractiveChart(j) {
    const panel = dom.cvCpChartPanel;
    const host = dom.cvCpChart;
    if (!panel || !host) return;

    const th = (j && j.results && j.results.thermo) || {};
    const T = Array.isArray(th.curve_T_K) ? th.curve_T_K : [];
    const Cv = Array.isArray(th.curve_Cv_Ry_per_K) ? th.curve_Cv_Ry_per_K : [];
    const Cp = Array.isArray(th.curve_Cp_Ry_per_K) ? th.curve_Cp_Ry_per_K : [];

    const points = [];
    for (let i = 0; i < T.length; i++) {
      const t = Number(T[i]);
      const cv = Cv[i];
      const cp = Cp[i];
      if (!Number.isFinite(t) || cv == null || cp == null) continue;
      const cvN = Number(cv);
      const cpN = Number(cp);
      if (!Number.isFinite(cvN) || !Number.isFinite(cpN)) continue;
      points.push({ t, cv: cvN, cp: cpN, d: cpN - cvN });
    }

    if (points.length < 2) {
      panel.hidden = true;
      host.innerHTML = "";
      return;
    }

    panel.hidden = false;
    if (dom.cvCpChartTitle) {
      dom.cvCpChartTitle.innerHTML = t("cvCpChart.title");
    }
    if (dom.cvCpChartHint) {
      const src = th.Cp_curve_source || th.Cp_source || "";
      dom.cvCpChartHint.textContent = src
        ? t("cvCpChart.hint") + " · " + formatThermoSource(src, "thermo.Cp_curve_source")
        : t("cvCpChart.hint");
    }

    const W = 640;
    const H = 280;
    const pad = { l: 56, r: 18, t: 16, b: 42 };
    const iw = W - pad.l - pad.r;
    const ih = H - pad.t - pad.b;
    const tMin = points[0].t;
    const tMax = points[points.length - 1].t;
    let yMin = Math.min(...points.map((p) => p.cv));
    let yMax = Math.max(...points.map((p) => p.cp));
    const yPad = (yMax - yMin) * 0.08 || yMax * 0.05 || 1e-8;
    yMin -= yPad;
    yMax += yPad;

    const xScale = (t) => pad.l + ((t - tMin) / (tMax - tMin || 1)) * iw;
    const yScale = (y) => pad.t + ih - ((y - yMin) / (yMax - yMin || 1)) * ih;
    const line = (key) =>
      points.map((p, i) => `${i ? "L" : "M"}${xScale(p.t).toFixed(2)},${yScale(p[key]).toFixed(2)}`).join(" ");

    const svgNS = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(svgNS, "svg");
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
    svg.setAttribute("class", "cv-cp-svg");
    svg.innerHTML =
      `<rect x="0" y="0" width="${W}" height="${H}" class="cv-cp-bg"/>` +
      `<text x="${pad.l}" y="${H - 12}" class="cv-cp-axis-label">${t("cvCpChart.xLabel")}</text>` +
      `<text x="12" y="${pad.t + 8}" class="cv-cp-axis-label" transform="rotate(-90 12 ${pad.t + 8})">${t("cvCpChart.yLabel")}</text>` +
      `<path d="${line("cv")}" class="cv-cp-line cv-cp-line-cv" fill="none"/>` +
      `<path d="${line("cp")}" class="cv-cp-line cv-cp-line-cp" fill="none"/>` +
      `<line id="cvCpCross" x1="${pad.l}" x2="${pad.l + iw}" y1="${pad.t}" y2="${pad.t}" class="cv-cp-cross" visibility="hidden"/>` +
      `<circle id="cvCpDotCv" r="4" class="cv-cp-dot cv-cp-dot-cv" visibility="hidden"/>` +
      `<circle id="cvCpDotCp" r="4" class="cv-cp-dot cv-cp-dot-cp" visibility="hidden"/>` +
      `<g class="cv-cp-legend">` +
      `<line x1="${W - 170}" y1="${pad.t + 6}" x2="${W - 150}" y2="${pad.t + 6}" class="cv-cp-line cv-cp-line-cv"/>` +
      `<text x="${W - 145}" y="${pad.t + 10}" class="cv-cp-legend-txt">C<sub>v</sub></text>` +
      `<line x1="${W - 90}" y1="${pad.t + 6}" x2="${W - 70}" y2="${pad.t + 6}" class="cv-cp-line cv-cp-line-cp"/>` +
      `<text x="${W - 65}" y="${pad.t + 10}" class="cv-cp-legend-txt">C<sub>p</sub></text>` +
      `</g>`;

    host.innerHTML = "";
    host.appendChild(svg);

    const cross = svg.querySelector("#cvCpCross");
    const dotCv = svg.querySelector("#cvCpDotCv");
    const dotCp = svg.querySelector("#cvCpDotCp");
    const tip = dom.cvCpChartTooltip;

    const showAt = (clientX, clientY) => {
      const rect = svg.getBoundingClientRect();
      const relX = ((clientX - rect.left) / rect.width) * W;
      const tGuess = tMin + ((relX - pad.l) / iw) * (tMax - tMin);
      let best = points[0];
      let bestD = Infinity;
      for (const p of points) {
        const d = Math.abs(p.t - tGuess);
        if (d < bestD) { bestD = d; best = p; }
      }
      const yCv = yScale(best.cv);
      const yCp = yScale(best.cp);
      cross.setAttribute("x1", pad.l);
      cross.setAttribute("x2", pad.l + iw);
      cross.setAttribute("y1", yCv.toFixed(2));
      cross.setAttribute("y2", yCv.toFixed(2));
      cross.setAttribute("visibility", "visible");
      dotCv.setAttribute("cx", xScale(best.t).toFixed(2));
      dotCv.setAttribute("cy", yCv.toFixed(2));
      dotCv.setAttribute("visibility", "visible");
      dotCp.setAttribute("cx", xScale(best.t).toFixed(2));
      dotCp.setAttribute("cy", yCp.toFixed(2));
      dotCp.setAttribute("visibility", "visible");
      if (tip) {
        tip.hidden = false;
        tip.innerHTML =
          `<strong>T = ${best.t.toFixed(1)} K</strong><br/>` +
          `C<sub>v</sub> = ${best.cv.toExponential(3)} Ry/K<br/>` +
          `C<sub>p</sub> = ${best.cp.toExponential(3)} Ry/K<br/>` +
          `Δ(C<sub>p</sub>−C<sub>v</sub>) = ${best.d.toExponential(3)} Ry/K`;
        const panelRect = panel.getBoundingClientRect();
        tip.style.left = `${clientX - panelRect.left + 12}px`;
        tip.style.top = `${clientY - panelRect.top - 8}px`;
      }
    };

    const hide = () => {
      cross.setAttribute("visibility", "hidden");
      dotCv.setAttribute("visibility", "hidden");
      dotCp.setAttribute("visibility", "hidden");
      if (tip) tip.hidden = true;
    };

    svg.onmousemove = (ev) => showAt(ev.clientX, ev.clientY);
    svg.onmouseleave = hide;
    svg.ontouchmove = (ev) => {
      if (ev.touches && ev.touches[0]) {
        showAt(ev.touches[0].clientX, ev.touches[0].clientY);
      }
    };
    svg.ontouchend = hide;
  }

  function updateLiveResults(j) {
    if (!j) return;
    if (dom.resultsCard) dom.resultsCard.classList.add("has-live-results");
    updateWorkflowStepper();
    // Provenance C_ij (juillet 2026) — badge forward-compat : on n'insere
    // la div .metric-source dans ``dom.resultSummary`` QUE si la cle
    // ``j.results.elastic.source`` est l'une des 2 valeurs reconnues. Pour
    // tous les anciens markers (cle absente / None / autres valeurs) : la div
    // n'est pas creee, aucun rendu, 0 regression.
    _renderElasticSourceBadgeIntoSummary(j);
    renderPropertyGapsPanel(j);
    renderTensorPanels(j);
    renderCvCpInteractiveChart(j);
    const r = j.results || {};
    const er = state.selectedProfileExpected || {};
    if (dom.resultEmpty) dom.resultEmpty.classList.add("hidden");

    const sumNodes = dom.resultSummary.querySelectorAll("[data-metric-key]");
    if (sumNodes.length === 0 && (!er || !Object.keys(er).length)) {
      renderResultsFallback(j);
      return;
    }
    for (const node of sumNodes) {
      const key = node.dataset.metricKey;
      const val = getNestedValue(r, key);
      const valDiv = node.querySelector(".val");
      if (!valDiv) continue;
      const isPending = val === undefined || val === null;
      const newText = isPending ? "—" : fmt(val, 3, key);
      if (valDiv.textContent !== newText) valDiv.textContent = newText;
      if (isPending) {
        valDiv.classList.add("text-pending");
        valDiv.classList.remove("text-live");
      } else {
        valDiv.classList.remove("text-pending");
        valDiv.classList.add("text-live");
      }
      const srcDotted = METRIC_INLINE_SOURCES[key];
      let srcEl = node.querySelector(".metric-src");
      if (srcDotted) {
        const srcVal = getNestedValue(r, srcDotted);
        if (srcVal != null && srcVal !== "") {
          if (!srcEl) {
            srcEl = document.createElement("div");
            srcEl.className = "metric-src muted";
            node.appendChild(srcEl);
          }
          const srcText =
            t("artifacts.metricSource") + " : " + formatThermoSource(srcVal, srcDotted);
          if (srcEl.textContent !== srcText) srcEl.textContent = srcText;
        } else if (srcEl) {
          srcEl.remove();
        }
      } else if (srcEl) {
        srcEl.remove();
      }
    }
    for (const fig of dom.resultPlots.querySelectorAll("figure[data-plot-key]")) {
      const key = fig.dataset.plotKey;
      const path = resolvePlotPath(getNestedValue(r, key));
      const img = fig.querySelector("img");
      if (!img) continue;
      if (path) {
        const url =
          `/api/pipeline/result_image?job_id=${encodeURIComponent(j.job_id)}` +
          `&path=${encodeURIComponent(path)}`;
        if (img.dataset.plotPath !== path) {
          img.src = url;
          img.dataset.plotPath = path;
          fig.classList.remove("plot-pending");
        }
      }
    }
    const outFiles = Array.isArray(r.output_files) ? r.output_files : [];
    const outSet = new Set(outFiles);
    for (const chip of dom.resultFiles.querySelectorAll("[data-file-name]")) {
      const name = chip.dataset.fileName || "";
      // Le match prend en compte `path` ET `path/.../name` (multiples
      // profondeurs possibles dans work/ : ex. ``1_eos_volumes/eos_ev.png``).
      const produced =
        outSet.has(name) ||
        outFiles.some((f) => f && (f === name || f.endsWith("/" + name)));
      if (produced) {
        chip.classList.remove("chip-pending");
        chip.classList.add("chip-live");
        // Rend la chip cliquable : ouvre l'image inline ou télécharge
        // le fichier texte / binaire via ``/api/pipeline/result_file``.
        // Le path transmis est le **path exact** depuis work_dir (relatif),
        // tel que listé dans ``j.results.output_files`` — pas le nom court.
        const fullRel = outFiles.find((f) => f === name)
          || outFiles.find((f) => f && f.endsWith("/" + name))
          || name;
        attachChipClick(chip, j.job_id, fullRel, name);
      }
    }
  }

  // Ouvre le fichier relatif ``relPath`` du job ``jobId`` dans un nouvel
  // onglet. Images/PDF : preview navigateur (``inline=1``). Texte/binaire :
  // le serveur force ``Content-Disposition: attachment`` → téléchargement.
  function attachChipClick(chip, jobId, relPath, displayName) {
    if (chip.dataset.clickWired === "1") return; // idempotent
    chip.dataset.clickWired = "1";
    chip.classList.add("chip-clickable");
    chip.setAttribute("role", "button");
    chip.setAttribute("tabindex", "0");
    chip.title = `Ouvrir / télécharger : ${displayName}`;
    const open = (ev) => {
      ev.preventDefault();
      // Décide selon l'extension :
      const ext = (displayName.split(".").pop() || "").toLowerCase();
      const isImage = ["png", "jpg", "jpeg", "gif", "svg", "webp"].includes(ext);
      const isPdf = ext === "pdf";
      const base = isImage
        ? `/api/pipeline/result_image?job_id=${encodeURIComponent(jobId)}` +
          `&path=${encodeURIComponent(relPath)}`
        : `/api/pipeline/result_file?job_id=${encodeURIComponent(jobId)}` +
          `&path=${encodeURIComponent(relPath)}` +
          (isPdf ? "&inline=1" : "");
      // Ouvre en nouvel onglet. Pour les images, ça affichera directement ;
      // pour les .dat/.txt/.json, le serveur posera ``attachment`` + le
      // navigateur déclenchera le téléchargement.
      const win = window.open(base, "_blank", "noopener,noreferrer");
      if (!win) {
        // Bloqueur de popups : on retombe sur le download en simulant un clic lien.
        appendLog(`[WARN] popup blocked — use "allow popups" or download manually: ${relPath}`, "err");
      }
    };
    chip.addEventListener("click", open);
    chip.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter" || ev.key === " ") {
        open(ev);
      }
    });
  }

  function renderDoneBanner(j) {
    if (dom.resultsMeta) {
      const n = (j.results && Object.keys(j.results).length) || 0;
      dom.resultsMeta.textContent = "✅ " + t("resultsMeta.done", { n: String(n) });
    }
    updateWorkflowStepper();
  }

  function renderResultsFallback(j) {
    const r = j.results || {};
    dom.resultSummary.innerHTML = "";
    const m1 = document.createElement("div");
    m1.className = "metric";
    m1.innerHTML =
      `<div class="lab">Statut</div><div class="val text-live">` +
      (j.status === "done" ? "✅ Complete" : escapeHtml(j.status || "—")) +
      `</div>`;
    dom.resultSummary.appendChild(m1);
    if (Array.isArray(r.output_files)) {
      const m2 = document.createElement("div");
      m2.className = "metric";
      m2.innerHTML =
        `<div class="lab">Fichiers générés</div>` +
        `<div class="val text-live">${r.output_files.length}` +
        `<span class="unit">fichier(s)</span></div>`;
      dom.resultSummary.appendChild(m2);
    }
    if (Array.isArray(r.elastic_dat_files)) {
      const m3 = document.createElement("div");
      m3.className = "metric";
      m3.innerHTML =
        `<div class="lab">C_ij</div>` +
        `<div class="val text-live">${r.elastic_dat_files.length}` +
        `<span class="unit">dat</span></div>`;
      dom.resultSummary.appendChild(m3);
    }
  }

  // --------- ④ (b) Picker « Charger un calcul précédent » ---------
  // Pose UNE fois les listeners (select + bouton explicite « Afficher ce run »
  // + refresh + clear) — appelé depuis ``init``.
  //
  // Choix UX important : changer le <select> NE déclenche PAS le chargement.
  // L'utilisateur doit cliquer explicitement « 🔄 Afficher ce run ». Cela lui
  // permet de comparer plusieurs runs avant de committer une action (regarder
  // un run A, changer la sélection pour B sans déclencher de load intermédiaire,
  // puis cliquer sur le bouton pour confirmer). Le workflow précédent
  // (auto-load au change) surprenait beaucoup les nouveaux utilisateurs.
  function setupRunsPickerHandlers() {
    if (!dom.runsSelect || !dom.runsRefresh) return;
    // Sérialisation gérée à l'intérieur de ``loadRunIntoUI`` (chaîne bornée à
    // ``PICKER_MAX_CHAIN`` tentatives) — le listener est volontairement
    // minimal pour éviter tout couplage fragile entre handler et state.
    dom.runsSelect.addEventListener("change", () => {
      const jid = (dom.runsSelect.value || "").trim();
      // Cas particulier : si l'utilisateur sélectionne explicitement LE
      // placeholder (« — Charger un calcul précédent — ») et qu'un run est
      // déjà affiché, on nettoie l'affichage pour éviter l'ambiguïté
      // (le panneau workdir+chips+sanity pointerait sur un run « fantôme »).
      if (!jid) {
        if (state.loadedJobId) clearLoadedRun();
        updateRunsLoadButton();
        return;
      }
      syncCompareSelectOptions();
      updateRunsCompareButton();
      // Sinon : juste mettre à jour l'état du bouton (actif si ≠ run chargé,
      // désactivé si déjà chargé). Aucun appel réseau — l'utilisateur doit
      // cliquer le bouton « 🔄 Afficher ce run » pour valider.
      updateRunsLoadButton();
    });
    let refreshTimer = null;
    dom.runsRefresh.addEventListener("click", async () => {
      if (state.pickerBusy) return;
      if (refreshTimer) { clearTimeout(refreshTimer); refreshTimer = null; }
      dom.runsRefresh.classList.add("is-spinning");
      try {
        await refreshRunsList();
      } finally {
        // Petit délai pour que l'animation de rotation soit visible
        // (sinon term en <100 ms → invisible).
        refreshTimer = setTimeout(() => {
          dom.runsRefresh.classList.remove("is-spinning");
          refreshTimer = null;
        }, 320);
      }
    });
    if (dom.runsClear) {
      dom.runsClear.addEventListener("click", () => clearLoadedRun());
    }
    // Juin 2026 — bouton « Supprimer définitivement ce run » (registre + work_dir).
    // Action destructive : confirmation explicite + vérifie que le job est
    // terminé côté backend (sinon 409 + message clair). Le bouton se grise
    // pendant l'appel réseau pour éviter un double-clic.
    if (dom.runsDelete) {
      dom.runsDelete.addEventListener("click", async () => {
        if (!state.loadedJobId) return;
        const jid = state.loadedJobId;
        const short = (jid || "").slice(0, 12);
        const ok = window.confirm(
          `Supprimer définitivement le run ${short} ?\n\n` +
          `Cette action retire le job du registre ET supprime le dossier de ` +
          `travail (work_dir) du disque. Les fichiers de résultats ` +
          `(Cij, EOS, plots, etc.) seront perdus.\n\n` +
          `Cette action est IRRÉVERSIBLE.`
        );
        if (!ok) return;
        dom.runsDelete.disabled = true;
        const origTitle = dom.runsDelete.title;
        dom.runsDelete.title = "Suppression en cours…";
        try {
          const r = await window.ThermoPipeline.deletePipelineRun(jid);
          if (r && r.ok) {
            clearLoadedRun();
            await refreshRunsList();
            appendLog(
              `🗑 Run ${short} supprimé (${r.removed_from || "?"}).`,
              "ok"
            );
          } else {
            appendLog(
              `[ERR] Suppression run ${short} : réponse inattendue ${JSON.stringify(r)}`,
              "err"
            );
          }
        } catch (e) {
          appendLog(
            `[ERR] Suppression run ${short} : ${e.message}` +
            (e.status === 409 ? " (annulez le run d'abord via le bouton « Annuler »)" : ""),
            "err"
          );
        } finally {
          if (dom.runsDelete) {
            dom.runsDelete.disabled = false;
            dom.runsDelete.title = origTitle;
          }
        }
      });
    }
    if (dom.runsCompareSelect) {
      dom.runsCompareSelect.addEventListener("change", () => updateRunsCompareButton());
    }
    if (dom.runsCompareBtn) {
      dom.runsCompareBtn.addEventListener("click", () => compareSelectedRuns());
    }
    if (dom.runsReparse) {
      dom.runsReparse.addEventListener("click", () => reparseLoadedRun());
    }
    // Bouton explicite « 🔄 Afficher ce run » — seul déclencheur d'un
    // appel ``loadPipelineRun`` côté picker. Sa visibilité/disabilité est
    // synchronisée via ``updateRunsLoadButton()`` à chaque cycle pertinent.
    if (dom.runsLoad) {
      dom.runsLoad.addEventListener("click", () => {
        if (dom.runsLoad.disabled) return;
        const jid = (dom.runsSelect.value || "").trim();
        if (!jid) return;
        loadRunIntoUI(jid);
      });
      // État initial (avant tout refresh de liste).
      updateRunsLoadButton();
    }
    // Juillet 2026 — bouton « 📋 Fiche technique ». Ouvre (nouvel onglet) la
    // fiche technique du job sélectionné/chargé au format (HTML par défaut).
    // Synchro d'état partagée avec le bouton « 🔄 Afficher ce run ».
    if (dom.runsFactsheet) {
      dom.runsFactsheet.addEventListener("click", () => {
        if (dom.runsFactsheet.disabled) return;
        const jid = (dom.runsSelect.value || "").trim();
        if (!jid) return;
        const fmt = dom.runsFactsheetFmt ? (dom.runsFactsheetFmt.value || "html") : "html";
        // Juillet 2026 — garde-fou : si l'utilisateur choisit ``pdf`` mais que
        // ``/api/health`` a signalé ``factsheet_pdf_available=false`` (WeasyPrint
        // absent OU natives Cairo/Pango KO côté serveur), on retombe sur HTML
        // AVANT d'ouvrir l'onglet — sinon l'utilisateur recevrait le JSON
        // d'erreur 503 (mauvais UX). Le sélecteur ``#runsFactsheetFmt`` a déjà
        // l'option PDF désactivée, mais on garde cette ceinture+bretelles.
        const canPdf = !!(window.__thermoHealth && window.__thermoHealth.factsheet_pdf_available);
        const safeFmt = (fmt === "pdf" && !canPdf) ? "html" : fmt;
        if (fmt === "pdf" && !canPdf) {
          appendLog(
            "[WARN] PDF format unavailable on server (WeasyPrint missing or "
            + "native Cairo/Pango libs missing) — falling back to HTML.",
            "err"
          );
        }
        const url = window.ThermoPipeline.factsheet(jid, safeFmt);
        try {
          const win = window.open(url, "_blank", "noopener,noreferrer");
          if (!win) {
            appendLog("[WARN] popup blocked — allow popups to open the fact sheet.", "err");
          }
        } catch (e) {
          appendLog(`[ERR] fiche technique : ${e && e.message ? e.message : e}`, "err");
        }
      });
      // Synchronise enable/disable avec la sélection courante (sélecteur de
      // job). L'état est mutualisé entre les deux boutons.
      const syncFactsheetBtn = () => {
        const sel = (dom.runsSelect && dom.runsSelect.value || "").trim();
        const hasSel = !!sel;
        const sameLoaded = !!state.loadedJobId && sel === state.loadedJobId;
        const busy = !!state.pickerBusy;
        dom.runsFactsheet.disabled = !hasSel || busy;
        dom.runsFactsheet.title = !hasSel
          ? "Select a run from the list above first."
          : busy
            ? "Loading…"
            : "Opens the fact sheet (C_ij, EOS, gap, magnetism, DFPT + rule-based expert analysis).";
        // Juillet 2026 — désactive l'option ``PDF (téléchargement)`` du
        // sélecteur `runsFactsheetFmt`` quand ``/api/health`` indique
        // ``factsheet_pdf_available=false``. Si le PDFdevient indisponible
        // pendant qu'il était sélectionné (toggle serveur), on retombe
        // automatiquement sur html.
        if (dom.runsFactsheetFmt) {
          const canPdfNow = !!(window.__thermoHealth && window.__thermoHealth.factsheet_pdf_available);
          for (const opt of dom.runsFactsheetFmt.options) {
            if (opt.dataset && opt.dataset.requiresPdfBackend === "1") {
              opt.disabled = !canPdfNow;
              opt.title = canPdfNow
                ? "Generates a downloadable PDF (via server-side WeasyPrint)."
                : "Unavailable: install weasyprint on server + system libs Cairo/Pango.";
            }
          }
          if (!canPdfNow && dom.runsFactsheetFmt.value === "pdf") {
            dom.runsFactsheetFmt.value = "html";
          }
        }
      };
      // À chaque changement du <select>, de la sélection chargée ou de l'état
      // du picker : on resynchronise.
      dom.runsSelect.addEventListener("change", syncFactsheetBtn);
      // Hook après chaque load réussi pour metter à jour l'état du bouton.
      const _origApply = _applyLoadedRun;
      _applyLoadedRun = function(j) {
        _origApply(j);
        syncFactsheetBtn();
      };
      syncFactsheetBtn();
    }
  }

  // Juillet 2026 — bandeau « factsheet vX.Y — générée le YYYY-MM-DD » injecté
  // dans ``#factsheetVersionChip`` (à côté du bouton Fiche technique). Lit le
  // cache ``__thermoHealth`` pour éviter un round-trip HTTP supplémentaire ;
  // tombe en mode "absent" silencieusement si le serveur n'a pas chargé les
  // nouvelles variables (rétro-compat UI).
  function refreshFactsheetVersionChip() {
    const chip = document.querySelector("#factsheetVersionChip");
    if (!chip) return;
    const h = window.__thermoHealth || {};
    const v = h.factsheet_version || "";
    const d = h.factsheet_compiled_at || "";
    const vAi = h.factsheet_ai_version || "";
    if (!v || !d) {
      chip.hidden = true;
      chip.textContent = "";
      chip.title = "";
      return;
    }
    chip.hidden = false;
    chip.textContent = `factsheet v${v} \u2014 g\u00e9n\u00e9r\u00e9e le ${d}`;
    if (vAi) {
      chip.title =
        `factsheet.py v${v} (compil\u00e9 ${d}) — moteur expert factsheet_ai.py v${vAi} ` +
        `(compil\u00e9 ${h.factsheet_ai_compiled_at || "?"}).`;
    } else {
      chip.title = `factsheet.py v${v} — compil\u00e9 le ${d}.`;
    }
  }

  // Synchronise l'état du bouton « 🔄 Afficher ce run » en fonction de :
  //   - la sélection courante du <select> ;
  //   - l'état « run chargé » (``state.loadedJobId``) ;
  //   - l'occupation du picker (``state.pickerBusy``).
  //
  // Le bouton est **désactivé** dans trois cas :
  //   1. Aucune sélection (placeholder actif).
  //   2. La sélection pointe sur le run déjà chargé (action no-op).
  //   3. Le picker est occupé (chargement en cours — masquer le bouton évite
  //      un double-clic susceptible de relancer la chaîne interne).
  //
  // Pendant un load, on ajoute aussi la classe ``is-loading`` (animation
  // de l'emoji 🔄) pour feedback visuel.
  function updateRunsLoadButton() {
    const btn = dom.runsLoad;
    if (!btn) return;
    const sel = (dom.runsSelect && dom.runsSelect.value || "").trim();
    const hasSel = !!sel;
    const sameLoaded = !!state.loadedJobId && sel === state.loadedJobId;
    const busy = !!state.pickerBusy;
    btn.disabled = !hasSel || sameLoaded || busy;
    btn.classList.toggle("is-loading", busy && hasSel);
    // Titre contextuel : précise pourquoi le bouton est désactivé.
    if (!hasSel) {
      btn.title = t("runsLoad.titleSelect");
    } else if (sameLoaded) {
      btn.title = t("runsLoad.titleSame");
    } else if (busy) {
      btn.title = t("runsLoad.titleBusy");
    } else {
      btn.title = t("runsLoad.titleGo");
    }
    updateWorkflowStepper();
  }

  // Récupère depuis l'API la liste des runs persistés, reconstruit le <select>
  // du picker. Préserve la sélection courante si elle existe toujours.
  async function refreshRunsList() {
    if (!dom.runsSelect) return;
    if (state.pickerBusy) {
      // Refresh pendant un load en cours → on attend le tour suivant.
      return;
    }
    state.pickerBusy = true;
    try {
      let r;
      try {
        r = await window.ThermoPipeline.listPipelineRuns(50);
      } catch (e) {
        appendLog(`[ERR] runs : ${e.message}`, "err");
        if (dom.runsCount) dom.runsCount.textContent = t("sec4.runsUnavailable");
        return;
      }
      state.runsCache = (r && r.runs) || [];
      const prevValue = dom.runsSelect.value || "";
      const prevCompare = dom.runsCompareSelect ? dom.runsCompareSelect.value || "" : "";
      _fillRunsSelect(dom.runsSelect, {
        placeholderText: state.loadedJobId
          ? t("sec4.runPlaceholderAlt")
          : t("sec4.runPlaceholder"),
      });
      if (dom.runsCompareSelect) {
        _fillRunsSelect(dom.runsCompareSelect, {
          placeholderText: t("sec4.comparePlaceholder"),
          excludeJobId: state.loadedJobId || prevValue || "",
        });
      }
      // Restaure la sélection (run chargé ou précédent) si elle existe toujours.
      if (state.loadedJobId &&
          state.runsCache.some((x) => x.job_id === state.loadedJobId)) {
        dom.runsSelect.value = state.loadedJobId;
      } else if (prevValue &&
                 state.runsCache.some((x) => x.job_id === prevValue)) {
        dom.runsSelect.value = prevValue;
      }
      if (dom.runsCompareSelect && prevCompare &&
          prevCompare !== (state.loadedJobId || dom.runsSelect.value) &&
          state.runsCache.some((x) => x.job_id === prevCompare)) {
        dom.runsCompareSelect.value = prevCompare;
      } else if (state.loadedJobId) {
        // Run chargé mais absent de la liste → on ne le perd pas visuellement,
        // le panneau « runsLoaded » reste affiché (l'utilisateur peut le clear).
      }
      // Synchronise le bouton explicite « 🔄 Afficher ce run ».
      updateRunsLoadButton();
      if (typeof _updatePurgeFailedCount === "function") {
        try { _updatePurgeFailedCount(); _refreshPurgeStaleBtn(); } catch (_e) {}
      }
      if (dom.runsCount) {
        const n = state.runsCache.length;
        dom.runsCount.textContent = n === 0
          ? t("sec4.runsCountNone")
          : t("sec4.runsCount", { n: String(n) });
      }
      updateRunsCompareButton();
      updateRunsReparseButton();
    } finally {
      state.pickerBusy = false;
    }
  }

  function syncCompareSelectOptions() {
    if (!dom.runsCompareSelect) return;
    const prev = dom.runsCompareSelect.value || "";
    const exclude = state.loadedJobId || (dom.runsSelect && dom.runsSelect.value) || "";
    _fillRunsSelect(dom.runsCompareSelect, {
      placeholderText: t("sec4.comparePlaceholder"),
      excludeJobId: exclude,
    });
    if (prev && prev !== exclude && state.runsCache.some((x) => x.job_id === prev)) {
      dom.runsCompareSelect.value = prev;
    }
    updateRunsCompareButton();
  }

  function _fillRunsSelect(selectEl, opts) {
    if (!selectEl) return;
    const o = opts || {};
    selectEl.innerHTML = "";
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = o.placeholderText || t("sec4.runPlaceholder");
    selectEl.appendChild(placeholder);
    for (const run of state.runsCache) {
      if (o.excludeJobId && run.job_id === o.excludeJobId) continue;
      const opt = document.createElement("option");
      opt.value = run.job_id || "";
      opt.textContent = formatRunOptionLabel(run);
      const tooltipParts = [
        run.work_dir || "",
        (run.material_id ? "material: " + run.material_id : ""),
        (run.status ? "status: " + run.status : ""),
        (run.finished_at ? "fini: " + run.finished_at.replace("T", " ").slice(0, 19) : ""),
      ].filter(Boolean);
      opt.title = tooltipParts.join("\n");
      if (run.source === "memory") opt.dataset.source = "memory";
      else if (run.source === "disk") opt.dataset.source = "disk";
      selectEl.appendChild(opt);
    }
  }

  function _runShortLabel(j) {
    if (!j) return "—";
    const parts = [(j.job_id || "").slice(0, 8)];
    if (j.profile_id) parts.push(j.profile_id);
    if (j.material_id) parts.push(j.material_id);
    return parts.join(" · ");
  }

  function _metricsDefsForJob(j) {
    const prof = state.profiles.find((p) => p.id === (j && j.profile_id));
    if (prof && prof.expected_results && Array.isArray(prof.expected_results.metrics)) {
      return prof.expected_results.metrics.slice();
    }
    if (j && j.expected_results && Array.isArray(j.expected_results.metrics)) {
      return j.expected_results.metrics.slice();
    }
    return [];
  }

  function _buildCompareRows(jA, jB) {
    const mapA = new Map(_metricsDefsForJob(jA).map((m) => [m.key, m]));
    const mapB = new Map(_metricsDefsForJob(jB).map((m) => [m.key, m]));
    const keys = new Set([...mapA.keys(), ...mapB.keys()]);
    const rows = [];
    for (const key of keys) {
      if (!key) continue;
      const mdef = mapA.get(key) || mapB.get(key) || { key, label: key, unit: "" };
      const vA = getNestedValue((jA && jA.results) || {}, key);
      const vB = getNestedValue((jB && jB.results) || {}, key);
      rows.push({
        key,
        label: mdef.label || key,
        unit: mdef.unit || "",
        vA,
        vB,
      });
    }
    rows.sort((a, b) => String(a.label).localeCompare(String(b.label)));
    return rows;
  }

  function renderRunComparison(jA, jB) {
    if (!dom.runsComparePanel || !dom.runsCompareHead || !dom.runsCompareBody) return;
    const rows = _buildCompareRows(jA, jB);
    if (dom.runsCompareTitle) {
      dom.runsCompareTitle.textContent =
        _runShortLabel(jA) + "  vs  " + _runShortLabel(jB);
    }
    dom.runsCompareHead.innerHTML =
      `<th>${escapeHtml(t("sec4.compareHeadMetric"))}</th>` +
      `<th>${escapeHtml(_runShortLabel(jA))}</th>` +
      `<th>${escapeHtml(_runShortLabel(jB))}</th>` +
      `<th>${escapeHtml(t("sec4.compareHeadDelta"))}</th>`;
    dom.runsCompareBody.innerHTML = "";
    for (const row of rows) {
      const tr = document.createElement("tr");
      const hasA = row.vA !== undefined && row.vA !== null;
      const hasB = row.vB !== undefined && row.vB !== null;
      const textA = hasA ? fmt(row.vA, 4, row.key) : "—";
      const textB = hasB ? fmt(row.vB, 4, row.key) : "—";
      let delta = "—";
      let rowClass = "";
      if (typeof row.vA === "number" && typeof row.vB === "number" &&
          isFinite(row.vA) && isFinite(row.vB)) {
        const d = row.vB - row.vA;
        delta = (d >= 0 ? "+" : "") + fmt(d, 4, row.key);
        if (Math.abs(d) < 1e-9) {
          rowClass = "rc-same";
          delta = "≈ 0";
        } else {
          rowClass = "rc-diff-warn";
        }
      }
      const unit = row.unit ? ` <span class="muted">${escapeHtml(row.unit)}</span>` : "";
      tr.className = rowClass;
      tr.innerHTML =
        `<td>${escapeHtml(row.label)}${unit}</td>` +
        `<td class="rc-num">${escapeHtml(textA)}</td>` +
        `<td class="rc-num">${escapeHtml(textB)}</td>` +
        `<td class="rc-num rc-delta">${escapeHtml(delta)}</td>`;
      dom.runsCompareBody.appendChild(tr);
    }
    dom.runsComparePanel.hidden = rows.length === 0;
  }

  function clearRunComparison() {
    if (dom.runsComparePanel) dom.runsComparePanel.hidden = true;
    if (dom.runsCompareBody) dom.runsCompareBody.innerHTML = "";
    if (dom.runsCompareHead) dom.runsCompareHead.innerHTML = "";
  }

  function updateRunsCompareButton() {
    if (!dom.runsCompareBtn) return;
    const base = state.loadedJobId || (dom.runsSelect && dom.runsSelect.value) || "";
    const other = (dom.runsCompareSelect && dom.runsCompareSelect.value) || "";
    const busy = state.compareBusy || state.pickerBusy;
    let title = t("sec4.compareTitle");
    let disabled = true;
    if (!base) {
      title = t("sec4.compareNeedA");
    } else if (!other) {
      title = t("sec4.compareNeedB");
    } else if (other === base) {
      title = t("sec4.compareSame");
    } else if (busy) {
      title = t("sec4.compareBusy");
    } else {
      disabled = false;
    }
    dom.runsCompareBtn.disabled = disabled || busy;
    dom.runsCompareBtn.title = title;
  }

  function updateRunsReparseButton() {
    if (!dom.runsReparse) return;
    const jid = state.loadedJobId || "";
    const busy = state.reparseBusy || state.pickerBusy;
    dom.runsReparse.disabled = !jid || busy;
    dom.runsReparse.title = !jid
      ? t("sec4.reparseNeedLoad")
      : busy ? t("sec4.reparseBusy") : t("sec4.reparseTitle");
  }

  async function compareSelectedRuns() {
    const jidA = state.loadedJobId || (dom.runsSelect && dom.runsSelect.value) || "";
    const jidB = (dom.runsCompareSelect && dom.runsCompareSelect.value) || "";
    if (!jidA || !jidB || jidA === jidB || state.compareBusy) return;
    state.compareBusy = true;
    updateRunsCompareButton();
    try {
      let jA = (state.loadedRecord && state.loadedRecord.job_id === jidA)
        ? state.loadedRecord
        : await window.ThermoPipeline.loadPipelineRun(jidA);
      const jB = await window.ThermoPipeline.loadPipelineRun(jidB);
      if (jA && jA.job_id === jidA && jidA === state.loadedJobId) {
        state.loadedRecord = jA;
      }
      renderRunComparison(jA, jB);
      appendLog(
        `Comparaison : ${jidA.slice(0, 8)} vs ${jidB.slice(0, 8)}`,
        "ok"
      );
    } catch (e) {
      clearRunComparison();
      appendLog(`[ERR] comparaison : ${e.message}`, "err");
    } finally {
      state.compareBusy = false;
      updateRunsCompareButton();
    }
  }

  async function reparseLoadedRun() {
    const jid = state.loadedJobId || "";
    if (!jid || state.reparseBusy) return;
    state.reparseBusy = true;
    updateRunsReparseButton();
    try {
      const r = await window.ThermoPipeline.reparseJob(jid);
      const j = (r && r.job_id) ? r : await window.ThermoPipeline.loadPipelineRun(jid);
      if (j && j.job_id) {
        _applyLoadedRun(j);
        fetchAndRenderSanity(j.job_id);
        fetchAndRenderExpertise(j.job_id);
        fetchAndRenderArtifacts(j.job_id);
        appendLog(t("sec4.reparseOk") + ` (${jid.slice(0, 8)})`, "ok");
      }
    } catch (e) {
      appendLog(
        `[ERR] re-parse ${jid.slice(0, 8)} : ${e.message}` +
        (e.status === 404 ? " — chargez le run d'abord." : ""),
        "err"
      );
    } finally {
      state.reparseBusy = false;
      updateRunsReparseButton();
    }
  }

  // Borne les relances en chaîne si l'utilisateur change la sélection pendant
  // un load. Au-delà, on abandonne et on log un WARN — évite un flood de
  // requêtes API en cas d'erreur persistante ou de boucle main.
  const PICKER_MAX_CHAIN = 3;
  // Status reconnus pour la phase workdir (« done » / « running » / « error »).
  // Une liste blanche fermée (vs simple else à « error ») nous évitera
  // d'afficher par accident en rouge un statut futur légitime (« paused » …).
  const KNOWN_PICKER_STATUSES = new Set([
    "done", "error", "cancelled", "interrupted",
    "running", "queued",
  ]);

  // Charge un run par job_id et repeuple la section ④ automatiquement.
  //
  // Sérialise les appels concurrents : si l'utilisateur change la sélection
  // pendant un load, la chaîne **interne** reprend la dernière valeur observée
  // du `<select>` une fois le load courant terminé. La chaîne est bornée à
  // ``PICKER_MAX_CHAIN`` tentatives (sécurité contre boucle infinie si l'API
  // jette en permanence).
  //
  // Timeout dur : si un précédent load bloque plus de ``PICKER_QUEUE_TIMEOUT_MS``
  // (sans réponse ni erreur), on abandonne pour ne pas squatter le slot
  // indéfiniment.
  async function loadRunIntoUI(jobId) {
    // Sérialise : si un load est déjà en cours, on attend qu'il finisse
    // (ou timeout). Puis on enchaîne sur la cible demandée par l'appelant.
    const PICKER_QUEUE_TIMEOUT_MS = 30000;
    const queueStart = Date.now();
    while (state.pickerBusy) {
      if (Date.now() - queueStart > PICKER_QUEUE_TIMEOUT_MS) {
        appendLog(
          "[WARN] picker: previous load blocked > 30 s, aborting request.",
          "err"
        );
        return;
      }
      await new Promise((res) => setTimeout(res, 25));
    }
    state.pickerBusy = true;
    // Feedback visuel : spinner sur le bouton explicite pendant le load.
    updateRunsLoadButton();
    let target = jobId;
    let attempt = 0;
    try {
      while (target) {
        attempt++;
        if (attempt > PICKER_MAX_CHAIN) {
          appendLog(
            `[WARN] picker : chaîne > ${PICKER_MAX_CHAIN} relances, abandon.`,
            "err"
          );
          return;
        }
        state.inFlightJobId = target;
        // 1. Appel API
        let j = null;
        try {
          j = await window.ThermoPipeline.loadPipelineRun(target);
        } catch (e) {
          appendLog(
            `[ERR] Chargement run ${target.slice(0, 8)} : ${e.message}`,
            "err"
          );
          return;  // pas de retry sur erreur réseau : on laisse l'utilisateur réparer.
        } finally {
          state.inFlightJobId = "";
        }
        if (!j || !j.job_id) {
          appendLog(`[ERR] Réponse vide pour le run ${target}.`, "err");
          return;
        }
        // 2. Applique l'état rendu
        _applyLoadedRun(j);
        // 3. Si l'utilisateur a changé la sélection PENDANT le load (entre
        //    L120 et L200), on enchaîne sur sa nouvelle cible (sans re-dispatcher
        //    un change handler — c'est ici, dans la chaîne, qu'on gère la suite).
        const nowValue = (dom.runsSelect && dom.runsSelect.value || "").trim();
        if (!nowValue || nowValue === target || nowValue === state.loadedJobId) {
          target = "";
          break;
        }
        target = nowValue;
      }
    } finally {
      state.pickerBusy = false;
      // Synchronisation finale du bouton explicite : sur le chemin succès,
      // _applyLoadedRun a déjà re-évalué l'état ; sur le chemin erreur,
      // c'est ICI qu'on retire la classe ``is-loading`` et qu'on ré-active
      // le bouton si la sélection pointe sur un autre run que celui déjà
      // chargé (l'utilisateur peut retenter immédiatement).
      updateRunsLoadButton();
    }
  }

  // Applique l'état du job ``j`` à toute la section ④ (sélection, bandeau,
  // structure des blocs, workdir, métriques, plots, chips).
  function _applyLoadedRun(j) {
    state.loadedJobId = j.job_id;
    state.loadedRecord = j;
    const prof = state.profiles.find((p) => p.id === j.profile_id);
    if (prof) {
      state.selectedProfileExpected = prof.expected_results || null;
    }
    showLoadedRunBanner(j);
    renderProfilePreviewFor(j);
    const st = String(j.status || "");
    if (!KNOWN_PICKER_STATUSES.has(st) && typeof console !== "undefined") {
      console.warn(
        `[picker] statut inconnu « ${st} » pour run ${j.job_id} — ` +
        `affiché en phase « error » par défaut.`
      );
    }
    const phase =
      st === "done" ? "done"
        : (st === "running" || st === "queued") ? "running"
          : "error";
    renderWorkdir(j, phase);
    updateLiveResults(j);
    if (st === "running" || st === "queued") {
      attachLiveJob(j.job_id, j.message || "Job en cours");
    } else {
      stopPolling();
      state.currentJobId = "";
      if (j.job_id) {
        window.__thermo_lastStatus = st.toLowerCase();
        _syncLifecycleBtns(j.job_id, window.__thermo_lastStatus);
      }
    }
    updateLaunchButton();
    if (dom.runsSelect) dom.runsSelect.value = j.job_id;
    appendLog(
      `Run chargé depuis le picker : ${j.job_id}` +
      (j.profile_id ? " · " + j.profile_id : "") +
      (j.material_id ? " · " + j.material_id : "") +
      (j.status ? " · status " + j.status : ""),
      "ok"
    );
    // Le bouton « 🔄 Afficher ce run » devient désactivé : le run courant
    // est déjà affiché (l'utilisateur doit changer de sélection pour le
    // réactiver).
    updateRunsLoadButton();
    // Sanity-checks scientifiques best-effort (peuvent être appliqués
    // aussi sur un run ``error`` ou ``cancelled`` — le check ``force_residual``
      // reste diagnostic utile même sur des runs partiels).
    fetchAndRenderSanity(j.job_id);
    fetchAndRenderExpertise(j.job_id);
    // Juillet 2026 — panneau Artefacts aussi pour les runs rechargés depuis
    // le picker (avant : uniquement en fin de job live via finalizeJob).
    fetchAndRenderArtifacts(j.job_id);
    updateRunsReparseButton();
    syncCompareSelectOptions();
  }

  function showLoadedRunBanner(j) {
    if (!dom.runsLoaded || !dom.runsLoadedText) return;
    const parts = [];
    parts.push("Run " + (j.job_id || "").slice(0, 8));
    if (j.profile_id) parts.push(j.profile_id);
    if (j.material_id) parts.push(j.material_id);
    if (j.status) parts.push(j.status);
    if (j.finished_at) {
      const fa = String(j.finished_at).replace("T", " ").slice(0, 19);
      parts.push("fini " + fa);
    }
    dom.runsLoadedText.textContent = parts.join(" · ");
    dom.runsLoaded.hidden = false;
  }

  function clearLoadedRun() {
    if (!state.loadedJobId && !state.loadedRecord && !dom.runsSelect) {
      return;  // rien à faire
    }
    state.loadedJobId = "";
    state.loadedRecord = null;
    if (dom.runsLoaded) dom.runsLoaded.hidden = true;
    if (dom.runsSelect) dom.runsSelect.value = "";
    // Nettoie le bloc « Dossier de sortie » pour ne pas laisser un
    // faux chemin « is-done » obsolète trainer.
    if (dom.resultWorkdir) {
      dom.resultWorkdir.hidden = true;
      dom.resultWorkdir.classList.remove(
        "is-running", "is-done", "is-error", "is-ready"
      );
      if (dom.resultWorkdirPath) dom.resultWorkdirPath.textContent = "(not generated)";
      if (dom.resultWorkdirBadge) {
        dom.resultWorkdirBadge.hidden = true;
        dom.resultWorkdirBadge.textContent = "";
      }
      if (dom.resultWorkdirHint) dom.resultWorkdirHint.textContent = "";
    }
    if (dom.resultsMeta) dom.resultsMeta.textContent = "";
    // L'aperçu de profil courant reprend la main (métriques/plots/fichiers attendus).
    renderProfilePreview();
    updateLaunchButton();
    // Sanity lié au run chargé → on le cache lui aussi.
    clearSanity();
    clearExpertise();
    // Panneau Artefacts lié au run chargé → masqué (jobId vide = hide).
    fetchAndRenderArtifacts("");
    // Synchronise le bouton « 🔄 Afficher ce run » : si l'utilisateur a
    // déjà une autre sélection active dans le <select>, le bouton redevient
    // utilisable immédiatement.
    updateRunsLoadButton();
    clearRunComparison();
    syncCompareSelectOptions();
    updateRunsCompareButton();
    updateRunsReparseButton();
  }
  // quand le profil correspondant est inconnu ou n'a pas d'expected_results.
  // On dérive les métriques depuis les clés de ``j.results`` pour que
  // ``updateLiveResults(j)`` retrouve chaque slot via ``data-metric-key``.
  function renderProfilePreviewFor(j) {
    // Cache le bandeau « ⓘ Sélectionnez… » dès qu'on repeuple avec un run
    // chargé (sinon il reste visible derrière le contenu).
    if (dom.resultEmpty) dom.resultEmpty.classList.add("hidden");
    let er = { metrics: [], plots: [], files: [] };
    const prof = state.profiles.find((p) => p.id === j.profile_id);
    if (prof && prof.expected_results) {
      er = prof.expected_results;
    } else if (j.expected_results &&
               typeof j.expected_results === "object") {
      er = j.expected_results;
    }
    // Repli : dérive depuis ``j.results`` si rien n'est trouvé.
    const hasMetrics = Array.isArray(er.metrics) && er.metrics.length > 0;
    const hasPlots = Array.isArray(er.plots) && er.plots.length > 0;
    if (!hasMetrics && !hasPlots) {
      const derivedMetrics = [];
      const derivedPlots = [];
      const walk = (obj, prefix) => {
        if (!obj || typeof obj !== "object") return;
        for (const [k, v] of Object.entries(obj)) {
          if (k === "_reparse" || k === "thermo_log" || k === "eos_summary") continue;
          const fullKey = prefix ? `${prefix}.${k}` : k;
          if (v && typeof v === "object" && !Array.isArray(v)) {
            walk(v, fullKey);
          } else if (typeof v === "number" && isFinite(v)) {
            derivedMetrics.push({
              key: fullKey,
              label: k,
              unit: "",
              group: prefix || "Results",
            });
          } else if (typeof v === "string" && /\.(png|jpg|jpeg|svg|gif|webp)$/i.test(v)) {
            derivedPlots.push({ key: fullKey, label: k });
          }
        }
      };
      walk(j.results || {}, "");
      er = {
        metrics: derivedMetrics.slice(0, 18),
        plots: derivedPlots.slice(0, 6),
        files: (Array.isArray(j.results && j.results.output_files)
                  ? j.results.output_files
                  : []
                ).map((n) => ({ name: n, label: n })),
      };
    }
    // Met à jour l'en-tête « Résultats » (emoji + nom de profil + état).
    if (dom.resultsMeta) {
      const stateIcon = j.status === "done" ? "✓"
                      : j.status === "error" ? "✗"
                      : j.status === "cancelled" ? "⊘"
                      : j.status || "";
      const name = (prof && prof.name) || j.profile_name || j.profile_id || "";
      dom.resultsMeta.textContent =
        `${prof && prof.emoji ? prof.emoji + " " : ""}${name} · ${stateIcon}`.trim();
    }
    // Grille avec en-têtes de groupes thématiques (run chargé depuis picker).
    renderMetricsGrid(dom.resultSummary, Array.isArray(er.metrics) ? er.metrics : []);
    dom.resultPlots.innerHTML = "";
    for (const pdef of (er.plots || [])) {
      const fig = document.createElement("figure");
      fig.dataset.plotKey = pdef.key || "";
      fig.classList.add("plot-pending");
      const img = document.createElement("img");
      img.alt = pdef.label || pdef.key || "";
      img.loading = "lazy";
      const cap = document.createElement("figcaption");
      cap.textContent = pdef.label || pdef.key || "";
      fig.appendChild(img);
      fig.appendChild(cap);
      dom.resultPlots.appendChild(fig);
    }
    dom.resultFiles.innerHTML = "";
    for (const fdef of (er.files || [])) {
      const c = document.createElement("span");
      c.className = "chip chip-pending";
      // juillet 2026 — cheatsheet branchée (voir /api/cheatsheet_outputs)
  c.title = `Attendu : ${fdef.label || fdef.name || ""} — voir panneau « cheatsheet sorties » ci-dessus`;
      c.dataset.fileName = fdef.name || fdef.key || "";
      c.textContent = fdef.name || fdef.key || "—";
      dom.resultFiles.appendChild(c);
    }
  }

  // --------- Events ---------
  dom.matSelect.addEventListener("change", () => {
    state.selectedMaterialId = dom.matSelect.value;
    populateScfIn();
    showMaterialInfo();
    resetJobState();
    updateLaunchButton();
    refreshScfPreview();
    refreshTpwinPreview();
    refreshProfileEstimates();
    renderProfilePreview();
  });
  dom.scfIn.addEventListener("change", () => {
    state.selectedScfBasename = dom.scfIn.value;
    state.scfPreviewLoadedFor = ""; // force re-fetch
    resetJobState();
    updateLaunchButton();
    refreshScfPreview();
    // Le scf.in porte nat, les cutoffs et la grille k : changer de fichier
    // change le coût du calcul, donc l'estimation.
    refreshProfileEstimates();
  });
  dom.nproc.addEventListener("change", () => {
    state.tpwinPreviewLoadedFor = ""; // nproc changed → re-fetch thermo_pw.in preview
    resetJobState();
    updateLaunchButton();
    refreshTpwinPreview();
    refreshProfileEstimates();
  });
  dom.launchBtn.addEventListener("click", launchPipeline);
  // (Annuler : géré par le dispatcher ``thermo_pw:job-action`` (capture-phase)
  //  avec confirm() — voir le bloc IIFE en fin de fichier.)

  document.addEventListener("DOMContentLoaded", init);
  // Juin 2026 — helpers du bouton « Vider les échecs » (statuts KO).
  // Compteur borne strict (error/cancelled/interrupted) ; pas running/queued.
  function _countFailedRuns() {
    if (!Array.isArray(state.runsCache)) return 0;
    let n = 0;
    for (const run of state.runsCache) {
      const st = String((run && run.status) || "").toLowerCase();
      if (st === "error" || st === "cancelled" || st === "interrupted") n++;
    }
    return n;
  }
  function _updatePurgeFailedCount() {
    // No-op: purge_failed button removed (merged into purge_stale "Nettoyer").
  }

  // ==========================================================================
  // Dialogue de diagnostic avant reprise.
  //
  // Montre ce qui a échoué, ce qui reste réutilisable et ce que chaque reprise
  // coûte, au lieu du « Reprendre le job ? » d'origine qui ne disait rien. La
  // promesse se résout avec le ``kind`` de l'action choisie, ou ``null`` si
  // l'utilisateur renonce.
  // ==========================================================================
  const SEVERITY_ICONS = { fatal: "\u26D4", blocking: "\u26A0\uFE0F", benign: "\u2139\uFE0F" };

  function showResumeDiagnosisDialog(jobId, diag) {
    return new Promise((resolve) => {
      const dlg = document.createElement("dialog");
      dlg.className = "resume-diag-modal";
      let settled = false;
      const finish = (value) => {
        if (settled) return;
        settled = true;
        try { dlg.close(); } catch (e) { dlg.removeAttribute("open"); }
        dlg.remove();
        resolve(value);
      };

      const head = document.createElement("header");
      head.className = "rd-head";
      const sev = (diag.severity || "") + "";
      head.innerHTML =
        `<span class="rd-sev-icon" aria-hidden="true">${escapeHtml(SEVERITY_ICONS[sev] || "\u2022")}</span>` +
        `<div><h3 class="rd-title">${escapeHtml(diag.headline || "Diagnostic de reprise")}</h3>` +
        `<p class="rd-sub">Calcul ${escapeHtml(jobId.slice(0, 12))}</p></div>`;
      dlg.appendChild(head);

      const body = document.createElement("div");
      body.className = "rd-body";
      for (const f of diag.findings || []) {
        const card = document.createElement("section");
        card.className = "rd-finding is-" + escapeHtml((f.severity || "") + "");
        const parts = [
          `<h4 class="rd-f-title">${escapeHtml(f.title || "")}</h4>`,
          `<p class="rd-f-text">${escapeHtml(f.explanation || "")}</p>`,
        ];
        if ((f.evidence || []).length) {
          parts.push('<ul class="rd-f-evidence">');
          for (const e of f.evidence) parts.push(`<li>${escapeHtml(e)}</li>`);
          parts.push("</ul>");
        }
        if ((f.reusable || []).length || (f.must_redo || []).length) {
          parts.push('<dl class="rd-f-balance">');
          if ((f.reusable || []).length) {
            parts.push("<dt>Réutilisable</dt><dd>" +
              escapeHtml(f.reusable.join(" ; ")) + "</dd>");
          }
          if ((f.must_redo || []).length) {
            parts.push("<dt>À refaire</dt><dd>" +
              escapeHtml(f.must_redo.join(" ; ")) + "</dd>");
          }
          parts.push("</dl>");
        }
        card.innerHTML = parts.join("");
        body.appendChild(card);
      }
      dlg.appendChild(body);

      const foot = document.createElement("footer");
      foot.className = "rd-actions";
      for (const a of diag.actions || []) {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "rd-action" + (a.recommended ? " is-recommended" : "");
        btn.innerHTML =
          `<span class="rd-a-label">${escapeHtml(a.label || "")}` +
          (a.recommended ? ' <em class="rd-a-badge">recommandé</em>' : "") + "</span>" +
          `<span class="rd-a-detail">${escapeHtml(a.detail || "")}</span>` +
          (a.cost_hint ? `<span class="rd-a-cost">${escapeHtml(a.cost_hint)}</span>` : "");
        btn.addEventListener("click", () => finish(a.kind || "resume"));
        foot.appendChild(btn);
      }
      const abort = document.createElement("button");
      abort.type = "button";
      abort.className = "rd-abort";
      abort.textContent = "Ne rien faire";
      abort.addEventListener("click", () => finish(null));
      foot.appendChild(abort);
      dlg.appendChild(foot);

      document.body.appendChild(dlg);
      dlg.addEventListener("cancel", (ev) => { ev.preventDefault(); finish(null); });
      if (typeof dlg.showModal === "function") dlg.showModal();
      else dlg.setAttribute("open", "");
      const first = dlg.querySelector(".rd-action.is-recommended") ||
        dlg.querySelector(".rd-action") || abort;
      if (first) first.focus();
    });
  }

  function _guideListFromI18n(key) {
    const raw = t(key) || "";
    return raw.split("\n").map((s) => s.trim()).filter(Boolean);
  }

  function _appendGuideSection(body, { titleKey, listKey, kind }) {
    const items = _guideListFromI18n(listKey);
    if (!items.length) return;
    const sec = document.createElement("section");
    sec.className = "rd-guide-section" + (kind ? " is-" + kind : "");
    const h = document.createElement("h4");
    h.textContent = t(titleKey) || titleKey;
    sec.appendChild(h);
    const ul = document.createElement("ul");
    for (const line of items) {
      const li = document.createElement("li");
      li.textContent = line;
      ul.appendChild(li);
    }
    sec.appendChild(ul);
    body.appendChild(sec);
  }

  function showResumeThermoPwTargetDialog(jobId, opts) {
    return new Promise((resolve) => {
      const dlg = document.createElement("dialog");
      dlg.className = "resume-diag-modal rd-guide-thermo";
      let settled = false;
      const finish = (value) => {
        if (settled) return;
        settled = true;
        try { dlg.close(); } catch (e) { dlg.removeAttribute("open"); }
        dlg.remove();
        resolve(value);
      };

      const mainTarget = (opts.targets || []).find((x) => x.recommended) ||
        (opts.targets || [])[0];
      const qhaDone = mainTarget && mainTarget.qha_done;
      const qhaTotal = mainTarget && mainTarget.qha_total;

      const head = document.createElement("header");
      head.className = "rd-head";
      head.innerHTML =
        `<div><h3 class="rd-title">${escapeHtml(t("sec3.resumeThermoGuideTitle"))}</h3>` +
        `<p class="rd-sub">${escapeHtml(jobId.slice(0, 12))} · ${escapeHtml(opts.profile_id || "")}</p></div>`;
      dlg.appendChild(head);

      const body = document.createElement("div");
      body.className = "rd-body";
      const intro = document.createElement("p");
      intro.className = "rd-f-text";
      intro.textContent = t("sec3.resumeThermoGuideIntro");
      body.appendChild(intro);

      const stdSec = document.createElement("section");
      stdSec.className = "rd-guide-section is-info";
      stdSec.innerHTML =
        `<h4>${escapeHtml(t("sec3.resumeThermoGuideStandardTitle"))}</h4>` +
        `<p class="rd-f-text">${escapeHtml(t("sec3.resumeThermoGuideStandardText"))}</p>`;
      body.appendChild(stdSec);

      if (qhaDone != null && qhaTotal) {
        const qha = document.createElement("div");
        qha.className = "rd-qha-box";
        qha.innerHTML =
          `<strong>${escapeHtml(t("sec3.resumeThermoQhaProgress", { done: qhaDone, total: qhaTotal }))}</strong>`;
        body.appendChild(qha);
      }

      let lsolveSelect = null;
      let deltatSelect = null;
      let thermModeDos = null;
      let thermModeFreq = null;
      const profileMode = opts.default_therm_mode || "dos";
      if (opts.lsolve_supported) {
        const qhaOpts = document.createElement("div");
        qhaOpts.className = "rd-qha-advanced";
        const qhaTitle = document.createElement("h4");
        qhaTitle.className = "rd-qha-advanced-title";
        qhaTitle.textContent = t("sec3.resumeThermoQhaAdvancedTitle");
        qhaOpts.appendChild(qhaTitle);

        if (opts.profile_id === "P3") {
          const p3Hint = document.createElement("p");
          p3Hint.className = "rd-lsolve-hint";
          p3Hint.textContent = t("sec3.resumeThermoP3Hint");
          qhaOpts.appendChild(p3Hint);
        } else if (opts.profile_id === "P4") {
          const p4Hint = document.createElement("p");
          p4Hint.className = "rd-lsolve-hint";
          p4Hint.textContent = t("sec3.resumeThermoP4Hint");
          qhaOpts.appendChild(p4Hint);
        }

        const lsField = document.createElement("div");
        lsField.className = "rd-lsolve-field";
        const lsLabel = document.createElement("label");
        lsLabel.setAttribute("for", "resumeThermoLsolve");
        lsLabel.textContent = t("sec3.resumeThermoLsolveLabel");
        lsField.appendChild(lsLabel);
        lsolveSelect = document.createElement("select");
        lsolveSelect.id = "resumeThermoLsolve";
        const lsDefault = document.createElement("option");
        lsDefault.value = "";
        lsDefault.textContent = t("sec3.resumeThermoLsolveDefault");
        lsolveSelect.appendChild(lsDefault);
        for (const [val, key] of [
          ["1", "sec3.resumeThermoLsolve1"],
          ["2", "sec3.resumeThermoLsolve2"],
          ["3", "sec3.resumeThermoLsolve3"],
        ]) {
          const opt = document.createElement("option");
          opt.value = val;
          opt.textContent = t(key);
          lsolveSelect.appendChild(opt);
        }
        const suggestLs = opts.suggest_lsolve;
        if (suggestLs != null) {
          lsolveSelect.value = String(suggestLs);
        }
        lsField.appendChild(lsolveSelect);
        qhaOpts.appendChild(lsField);

        const dtField = document.createElement("div");
        dtField.className = "rd-lsolve-field";
        const dtLabel = document.createElement("label");
        dtLabel.setAttribute("for", "resumeThermoDeltat");
        dtLabel.textContent = t("sec3.resumeThermoDeltatLabel");
        dtField.appendChild(dtLabel);
        deltatSelect = document.createElement("select");
        deltatSelect.id = "resumeThermoDeltat";
        const dtDefault = document.createElement("option");
        dtDefault.value = "";
        const curDt = (opts.thermo_control_hints || {}).deltat;
        dtDefault.textContent = curDt
          ? t("sec3.resumeThermoDeltatProfile", { deltat: curDt })
          : t("sec3.resumeThermoDeltatDefault");
        deltatSelect.appendChild(dtDefault);
        for (const val of ["50", "100", "200"]) {
          const opt = document.createElement("option");
          opt.value = val;
          opt.textContent = t("sec3.resumeThermoDeltatOption", { deltat: val });
          deltatSelect.appendChild(opt);
        }
        const suggestDt = opts.suggest_deltat;
        if (suggestDt != null) {
          deltatSelect.value = String(suggestDt);
        }
        dtField.appendChild(deltatSelect);
        const dtHint = document.createElement("p");
        dtHint.className = "rd-lsolve-hint";
        dtHint.textContent = t("sec3.resumeThermoDeltatHint");
        dtField.appendChild(dtHint);
        qhaOpts.appendChild(dtField);

        const tmField = document.createElement("div");
        tmField.className = "rd-lsolve-field";
        const tmLabel = document.createElement("p");
        tmLabel.className = "rd-therm-mode-label";
        tmLabel.textContent = t("sec3.resumeThermoModeLabel");
        tmField.appendChild(tmLabel);
        const tmRow = document.createElement("div");
        tmRow.className = "rd-therm-mode-row";
        thermModeDos = document.createElement("label");
        thermModeDos.className = "rd-therm-mode-opt";
        const dosInp = document.createElement("input");
        dosInp.type = "radio";
        dosInp.name = "resumeThermoMode";
        dosInp.value = "dos";
        dosInp.checked = profileMode === "dos";
        thermModeDos.appendChild(dosInp);
        thermModeDos.appendChild(document.createTextNode(" " + t("sec3.resumeThermoModeDos")));
        tmRow.appendChild(thermModeDos);
        thermModeFreq = document.createElement("label");
        thermModeFreq.className = "rd-therm-mode-opt";
        const freqInp = document.createElement("input");
        freqInp.type = "radio";
        freqInp.name = "resumeThermoMode";
        freqInp.value = "freq";
        freqInp.checked = profileMode === "freq";
        thermModeFreq.appendChild(freqInp);
        thermModeFreq.appendChild(document.createTextNode(" " + t("sec3.resumeThermoModeFreq")));
        tmRow.appendChild(thermModeFreq);
        tmField.appendChild(tmRow);
        const tmHint = document.createElement("p");
        tmHint.className = "rd-lsolve-hint";
        tmHint.textContent = t("sec3.resumeThermoModeHint");
        tmField.appendChild(tmHint);
        qhaOpts.appendChild(tmField);

        if (opts.qha_least_squares_failed) {
          const failHint = document.createElement("p");
          failHint.className = "rd-lsolve-hint is-warn";
          failHint.textContent = t("sec3.resumeThermoLsolveDgelsHint");
          qhaOpts.appendChild(failHint);
        }
        body.appendChild(qhaOpts);
      }

      if (opts.lsolve_supported) {
        _appendGuideSection(body, {
          titleKey: "sec3.resumeThermoGuideTuningTitle",
          listKey: "sec3.resumeThermoGuideTuningList",
        });
        const matSec = document.createElement("section");
        matSec.className = "rd-guide-section";
        matSec.innerHTML =
          `<h4>${escapeHtml(t("sec3.resumeThermoGuideMaterialsTitle"))}</h4>` +
          `<p class="rd-f-text">${escapeHtml(t("sec3.resumeThermoGuideMaterialsText"))}</p>`;
        body.appendChild(matSec);
        _appendGuideSection(body, {
          titleKey: "sec3.resumeThermoGuideDgelsTitle",
          listKey: "sec3.resumeThermoGuideDgelsList",
          kind: opts.qha_least_squares_failed ? "warn" : "",
        });
        _appendGuideSection(body, {
          titleKey: "sec3.resumeThermoGuideMachineTitle",
          listKey: "sec3.resumeThermoGuideMachineList",
          kind: "ok",
        });
      }

      _appendGuideSection(body, {
        titleKey: "sec3.resumeThermoGuideKeepTitle",
        listKey: "sec3.resumeThermoGuideKeepList",
        kind: "ok",
      });
      _appendGuideSection(body, {
        titleKey: "sec3.resumeThermoGuideRedoTitle",
        listKey: "sec3.resumeThermoGuideRedoList",
      });
      _appendGuideSection(body, {
        titleKey: "sec3.resumeThermoGuideWhenTitle",
        listKey: "sec3.resumeThermoGuideWhenList",
      });

      const vs = document.createElement("section");
      vs.className = "rd-guide-section is-warn";
      vs.innerHTML =
        `<h4>${escapeHtml(t("sec3.resumeThermoGuideVsFullTitle"))}</h4>` +
        `<p class="rd-f-text">${escapeHtml(t("sec3.resumeThermoGuideVsFullText"))}</p>`;
      body.appendChild(vs);

      const hint = document.createElement("p");
      hint.className = "rd-f-text";
      hint.textContent = t("sec3.resumeThermoPwHint");
      body.appendChild(hint);
      dlg.appendChild(body);

      const foot = document.createElement("footer");
      foot.className = "rd-actions";
      const go = document.createElement("button");
      go.type = "button";
      go.className = "rd-action is-recommended";
      go.innerHTML =
        `<span class="rd-a-label">${escapeHtml(t("sec3.resumeThermoGuideConfirm"))}` +
        ' <em class="rd-a-badge">recommandé</em></span>' +
        `<span class="rd-a-detail">${escapeHtml(mainTarget && mainTarget.label ? mainTarget.label : "thermo_main")}</span>`;
      go.addEventListener("click", () => {
        const targetId = (mainTarget && mainTarget.target_id) || "thermo_main";
        const out = { target: targetId };
        if (lsolveSelect && lsolveSelect.value) {
          out.lsolve = Number(lsolveSelect.value);
        }
        if (deltatSelect && deltatSelect.value) {
          out.deltat = Number(deltatSelect.value);
        }
        const selectedMode =
          thermModeFreq && thermModeFreq.querySelector("input")?.checked
            ? "freq"
            : "dos";
        if (selectedMode !== profileMode) {
          out.therm_mode = selectedMode;
        }
        finish(out);
      });
      foot.appendChild(go);
      const abort = document.createElement("button");
      abort.type = "button";
      abort.className = "rd-abort";
      abort.textContent = t("sec3.resumeGuideCancel");
      abort.addEventListener("click", () => finish(null));
      foot.appendChild(abort);
      dlg.appendChild(foot);

      document.body.appendChild(dlg);
      dlg.addEventListener("cancel", (ev) => { ev.preventDefault(); finish(null); });
      if (typeof dlg.showModal === "function") dlg.showModal();
      else dlg.setAttribute("open", "");
      go.focus();
    });
  }

  function showFullRestartGuideDialog() {
    return new Promise((resolve) => {
      const dlg = document.createElement("dialog");
      dlg.className = "resume-diag-modal";
      let settled = false;
      const finish = (value) => {
        if (settled) return;
        settled = true;
        try { dlg.close(); } catch (e) { dlg.removeAttribute("open"); }
        dlg.remove();
        resolve(value);
      };

      const head = document.createElement("header");
      head.className = "rd-head";
      head.innerHTML =
        `<div><h3 class="rd-title">${escapeHtml(t("sec3.resumeFullGuideTitle"))}</h3></div>`;
      dlg.appendChild(head);

      const body = document.createElement("div");
      body.className = "rd-body";
      const intro = document.createElement("p");
      intro.className = "rd-f-text";
      intro.textContent = t("sec3.resumeFullGuideIntro");
      body.appendChild(intro);
      const warn = document.createElement("section");
      warn.className = "rd-guide-section is-warn";
      warn.innerHTML =
        `<p class="rd-f-text">${escapeHtml(t("sec3.resumeFullGuideWarn"))}</p>`;
      body.appendChild(warn);
      dlg.appendChild(body);

      const foot = document.createElement("footer");
      foot.className = "rd-actions";
      const go = document.createElement("button");
      go.type = "button";
      go.className = "rd-action";
      go.innerHTML = `<span class="rd-a-label">${escapeHtml(t("sec3.resumeFullGuideConfirm"))}</span>`;
      go.addEventListener("click", () => finish(true));
      foot.appendChild(go);
      const abort = document.createElement("button");
      abort.type = "button";
      abort.className = "rd-abort";
      abort.textContent = t("sec3.resumeGuideCancel");
      abort.addEventListener("click", () => finish(false));
      foot.appendChild(abort);
      dlg.appendChild(foot);

      document.body.appendChild(dlg);
      dlg.addEventListener("cancel", (ev) => { ev.preventDefault(); finish(false); });
      if (typeof dlg.showModal === "function") dlg.showModal();
      else dlg.setAttribute("open", "");
      go.focus();
    });
  }

  // ==========================================================================
  // Dispatcher cycle de vie (Annuler / Relancer) et bouton « Nettoyer ».
  // Délégation via ``document.addEventListener('click', …, { capture:true })``
  // et attributs ``data-action-*`` / ``data-job-id``.
  // ==========================================================================
  (function () {
    const LOG = (...a) => console.log("[thermo_pw]", ...a);
    let busy = false;
    const labels = {
      cancel: "Cancel",
      restart: "Resume calculation",
      resumeThermo: "Resume thermo_pw only",
    };

    async function confirmResumeThermoPw(jobId) {
      let opts = null;
      try {
        opts = await window.ThermoPipeline.resumeThermoPwOptions(jobId);
      } catch (err) {
        console.warn("[thermo_pw] options reprise thermo_pw indisponibles:", err);
        window.alert(
          "Impossible de lire les options de reprise thermo_pw : " +
          (err && (err.message || err))
        );
        return null;
      }
      if (!opts || opts.error === "work_dir_absent") {
        window.alert("Dossier de calcul absent — reprise thermo_pw impossible.");
        return null;
      }
      const st = String(opts.status || "").toLowerCase();
      if (st === "running" || st === "queued" || st === "started") {
        window.alert(t("sec3.resumeThermoAlreadyRunning"));
        return null;
      }
      if (opts.phonon_prereqs_ok === false) {
        window.alert(opts.phonon_prereqs_message || "Prérequis phonon manquants.");
        return null;
      }
      const targets = opts.targets || [];
      if (!targets.length) {
        window.alert("Aucune cible de reprise thermo_pw disponible.");
        return null;
      }
      return showResumeThermoPwTargetDialog(jobId, opts);
    }

    async function handleResumeThermoPw(ev) {
      const t = ev.target.closest("[data-action-resume-thermo-pw]");
      if (!t) return;
      ev.preventDefault();
      const jobId = t.getAttribute("data-job-id") || "";
      if (!jobId) return;
      const resumeChoice = await confirmResumeThermoPw(jobId);
      if (!resumeChoice) return;
      const target = resumeChoice.target || "thermo_main";
      if (busy) return;
      busy = true;
      try {
        const resp = await window.ThermoPipeline.resumeThermoPw(jobId, resumeChoice);
        LOG("resume_thermo_pw", jobId, resumeChoice, "->", resp);
        try {
          await window.ThermoPipeline.listPipelineRuns(50);
        } catch (e) {
          console.warn("[thermo_pw] refresh post reprise thermo_pw:", e);
        }
        window.dispatchEvent(new CustomEvent("thermo_pw:job-action", {
          detail: { action: "resume_thermo_pw", jobId, resp, ...resumeChoice }
        }));
        if (resp && resp.ok !== false) {
          attachLiveJob(jobId, resp.message || "Reprise thermo_pw…");
          const bits = [target];
          if (resumeChoice.lsolve != null) bits.push(`lsolve=${resumeChoice.lsolve}`);
          if (resumeChoice.deltat != null) bits.push(`ΔT=${resumeChoice.deltat} K`);
          if (resumeChoice.therm_mode === "freq") bits.push("fréquences");
          appendLog(
            `[Reprise thermo_pw] Job ${jobId.slice(0, 8)}… relancé (${bits.join(", ")}).`,
            "ok"
          );
        }
      } catch (err) {
        window.alert(
          `Échec reprise thermo_pw : ${err && (err.message || err)}`
        );
      } finally {
        busy = false;
      }
    }

    // Une reprise saute les étapes marquées terminées. Après une coupure c'est
    // exactement ce qu'on veut ; après un défaut de configuration c'est le
    // piège, car les étapes fautives portent justement cette marque. On
    // interroge donc le serveur avant d'agir, et on n'ajoute de la friction que
    // lorsqu'un problème est réellement identifié.
    async function confirmRestart(jobId) {
      const proceed = await showFullRestartGuideDialog();
      if (!proceed) return null;
      let diag = null;
      try {
        const payload = await window.ThermoPipeline.resumeDiagnosis(jobId);
        diag = payload && payload.diagnosis;
      } catch (err) {
        // Un diagnostic indisponible ne doit jamais empêcher une reprise.
        console.warn("[thermo_pw] diagnostic de reprise indisponible:", err);
      }
      if (!diag || diag.resume_is_safe) {
        const suffix = diag && diag.headline ? `\n\n${diag.headline}` : "";
        return window.confirm(
          `${labels.restart} le job ${jobId.slice(0, 8)}… ?${suffix}`
        ) ? "resume" : null;
      }
      return showResumeDiagnosisDialog(jobId, diag);
    }

    async function handleLifecycle(ev) {
      const t = ev.target.closest("[data-action-cancel], [data-action-restart]");
      if (!t) return;
      ev.preventDefault();
      const jobId = t.getAttribute("data-job-id") || "";
      if (!jobId) return;
      const action = t.hasAttribute("data-action-restart") ? "restart" : "cancel";
      if (action === "restart") {
        const choice = await confirmRestart(jobId);
        if (!choice) return;
        if (choice === "fresh") {
          appendLog(
            "Reprise abandonnée : repartez d'un dossier neuf via « Lancer la série " +
            "de calculs ». Les corrections de configuration sont appliquées au lancement.",
            "info"
          );
          try { clearLoadedRun(); } catch (e) { /* pas de run chargé */ }
          return;
        }
      } else if (!window.confirm(`${labels[action]} le job ${jobId.slice(0, 8)}… ?`)) {
        return;
      }
      if (busy) return;
      busy = true;
      try {
        const resp = action === "restart"
          ? await window.ThermoPipeline.restartJob(jobId)
          : await window.ThermoPipeline.cancelJob(jobId);
        LOG("action", action, jobId, "->", resp);
        // Rafraîchir immédiatement le picker / la carte job (le polling
        // arrivera 2 s plus tard sinon). Tolérant aux erreurs : l'UI doit
        // rester réactive même si le refresh échoue.
        try {
          await window.ThermoPipeline.listPipelineRuns(50);
        } catch (e) {
          console.warn("[thermo_pw] refresh post-action a échoué:", e);
        }
        window.dispatchEvent(new CustomEvent("thermo_pw:job-action", {
          detail: { action, jobId, resp }
        }));
        if (resp && resp.ok !== false && action === "restart") {
          attachLiveJob(jobId, resp.message || "Reprise…");
        }
      } catch (err) {
        window.alert(`Échec ${labels[action]} : ${err && (err.message || err)}`);
      } finally {
        busy = false;
      }
    }

    async function handlePurgeStale(ev) {
      const t = ev.target.closest("[data-action-purge-stale]");
      if (!t) return;
      ev.preventDefault();
      if (busy) return;
      if (!window.confirm(
        "Clean up old calculations?\n\n" +
        "Batch removal:\n" +
        "  \u2022 failed calculations (error / cancelled / interrupted / stopped)\n" +
        "  \u2022 orphan entries (folder manually deleted)\n\n" +
        "Running and successfully completed calculations are kept.\n" +
        "IRREVERSIBLE action — continue?"
      )) return;
      busy = true;
      try {
        const dryRun = !!t.hasAttribute("data-dry-run");
        const resp = await window.ThermoPipeline.purgeStaleRuns({ dry_run: dryRun });
        LOG("purge_stale ->", resp);
        const lines = [];
        lines.push(`Registre nettoy\u00e9 : ${resp.deleted_from_registry}`);
        lines.push(`Markers disque supprim\u00e9s : ${resp.deleted_from_disk}`);
        lines.push(`D\u00e9j\u00e0 absents : ${resp.already_missing}`);
        if (resp.ignored_running && resp.ignored_running.length)
          lines.push(`(Jobs actifs ignor\u00e9s : ${resp.ignored_running.length})`);
        window.alert((dryRun ? "[Simulation]\n\n" : "") + lines.join("\n"));
        window.dispatchEvent(new CustomEvent("thermo_pw:purge-stale-done", {
          detail: resp
        }));
      } catch (err) {
        window.alert(`\u00c9chec purge obsol\u00e8tes : ${err && (err.message || err)}`);
      } finally {
        busy = false;
      }
    }

    document.addEventListener("click", handleLifecycle, { capture: true });
    document.addEventListener("click", handleResumeThermoPw, { capture: true });
    document.addEventListener("click", handlePurgeStale, { capture: true });
  })();

  // ===== — Sync live des boutons cycle de vie =====
  // (Pause / Reprendre / Stop partagent la carte ③ avec Annuler.)
  // Source de vérité : localStorage("thermo_pw.current_job_id") + un fetch
  // léger (rate-limited ~1.2 s) sur /api/pipeline/jobs/<id>.
  function _syncLifecycleBtns(jid, st) {
    try {
      const ACTIVE = new Set(["queued", "running", "started"]);
      const RESTARTABLE = new Set(["error", "cancelled", "interrupted"]);
      const safeJid = (jid || "") + "";
      const stLower = (st || "").toLowerCase();
      const showAll = !!safeJid;
      const showCancel  = showAll && ACTIVE.has(stLower);
      const showRestart = showAll && RESTARTABLE.has(stLower);
      const showResumeThermo = showAll && (
        RESTARTABLE.has(stLower) || stLower === "paused"
      );
      for (const el of [dom.restartBtn, dom.resumeThermoBtn, dom.cancelBtn]) {
        if (!el) continue;
        if (safeJid) el.setAttribute("data-job-id", safeJid);
      }
      if (dom.cancelBtn)  dom.cancelBtn.hidden  = !showCancel;
      const showResumePanel = showRestart || showResumeThermo;
      if (dom.resumeGroup) dom.resumeGroup.hidden = !showResumePanel;
      if (dom.restartBtn) dom.restartBtn.hidden = !showRestart;
      if (dom.resumeThermoBtn) dom.resumeThermoBtn.hidden = !showResumeThermo;
    } catch (err) {
      console.warn("[thermo_pw] _syncLifecycleBtns:", err);
    }
  }
  // Pas de fetch : pas de double polling (l'app en a déjà un). Le statut
  // est rafraîchi par les events ``thermo_pw:job-action`` / ``purge-stale-done``.
  function _tickLifecycle() {
    let jid = "";
    try { jid = localStorage.getItem("thermo_pw.current_job_id") || ""; } catch (e) {}
    if (!jid && state.currentJobId) jid = state.currentJobId;
    if (!jid && state.loadedJobId) jid = state.loadedJobId;
    _syncLifecycleBtns(jid, window.__thermo_lastStatus || "");
  }
  // ============================================================================
  // Transition polling : absorbe la fenêtre entre l'action utilisateur (Pause /
  // Stop / Reprendre) et le moment où le runner pose le statut terminal
  // (paused / stopped / running) sur le job.
  //
  // Plan :
  //   1. 4 tentatives fixes à T+0.5 / 1.5 / 3 / 6 s (absorbe ~95% des cas).
  //   2. Si après ces tentatives __thermo_lastStatus est toujours dans
  //      {pause_requested, stop_requested, resume_requested}, on bascule en
  //      polling toutes les 3 s, jusqu'à stabilisation ou deadline 30 s.
  //   3. Chaque fetch concurrent précédent est annulé (clic rapide => 1 seule
  //      séquence de polling en cours — évite la race soulignée par le
  //      code-reviewer).
  // ============================================================================
  const _TRANSITION_PENDING = new Set([
    "pause_requested", "stop_requested", "resume_requested", "restart_requested",
  ]);
  let _transitionPollHandle = null;
  function _stopTransitionPoll() {
    const h = _transitionPollHandle;
    if (!h) return;
    if (h.timeouts) for (const id of h.timeouts) clearTimeout(id);
    if (h.interval) clearInterval(h.interval);
    _transitionPollHandle = null;
  }
  function _scheduleTransitionPoll(jid) {
    if (!jid || !window.ThermoPipeline || !window.ThermoPipeline.jobStatus) return;
    _stopTransitionPoll();  // un seul cycle à la fois (annule cycles précédents)
    const DEADLINE_MS = 30000;
    const deadlines = Date.now() + DEADLINE_MS;
    const fixedOffsets = [500, 1500, 3000, 6000];
    const handle = { timeouts: [], interval: null };
    _transitionPollHandle = handle;
    async function _tickForTransition() {
      // Si on a dépassé le deadline ou si le statut a déjà quitté le set
      // de transition, on arrête le polling récurrent.
      if (Date.now() > deadlines) { _stopTransitionPoll(); return; }
      const cur = (window.__thermo_lastStatus || "").toLowerCase();
      // Ne fetch que si on est encore en transition (sinon le statut courant
      // est déjà la vérité et on n'a plus besoin de poll).
      if (!_TRANSITION_PENDING.has(cur)) { _stopTransitionPoll(); return; }
      try {
        const r = await window.ThermoPipeline.jobStatus(jid);
        const ns = (r && r.status) || "";
        if (ns) {
          window.__thermo_lastStatus = ns.toLowerCase();
          _syncLifecycleBtns(jid, window.__thermo_lastStatus);
        }
      } catch (e) { /* ignore transient (404 ou network) */ }
    }
    for (const ms of fixedOffsets) {
      handle.timeouts.push(setTimeout(_tickForTransition, ms));
    }
    // Démarrage du polling récurrent APRÈS la dernière tentative fixe
    // (T=6 s) → on évite le double call à T+6 s (overlap setTimeout/setInterval).
    handle.timeouts.push(setTimeout(() => {
      // Garde : si l'utilisateur a déclenché un nouveau cycle, on ne
      // réinitialise pas un interval sur un handle désormais obsolète.
      if (_transitionPollHandle !== handle) return;
      handle.interval = setInterval(_tickForTransition, 3000);
    }, 6500));
  }
  // Exposé pour test (peut être appelé depuis la console dev).
  window.thermoPW_scheduleTransitionPoll = _scheduleTransitionPoll;
  window.thermoPW_stopTransitionPoll = _stopTransitionPoll;

  window.addEventListener("thermo_pw:job-action", (ev) => {
    const d = ev && ev.detail || {};
    let jid = (d && d.jobId) || "";
    if (!jid) { try { jid = localStorage.getItem("thermo_pw.current_job_id") || ""; } catch (e) {} }
    if (!jid && state.currentJobId) jid = state.currentJobId;
    if (jid) _scheduleTransitionPoll(jid);
    setTimeout(_tickLifecycle, 200);
  });
  window.addEventListener("thermo_pw:purge-stale-done", () => setTimeout(() => {
    _tickLifecycle();
    _refreshPurgeStaleBtn().catch((e) => console.warn("[thermo_pw] refresh purge-stale after action:", e));
  }, 400));
  document.addEventListener("DOMContentLoaded", _tickLifecycle, { once: true });
  setInterval(_tickLifecycle, 15000);

  // Juin 2026 — bouton « Vider les obsolètes » (compteur live).
  // Compte : statuts terminaux KO (error/cancelled/interrupted/stopped)
  //          ET entrées dont le work_dir a disparu (récupérées via /check_works).
  async function _refreshPurgeStaleBtn() {
    if (!dom || !dom.runsPurgeStale) return;
    // Source : la liste de runs déjà connue côté UI (state.runsCache/runsItems etc.).
    // En sécurité on parcourt un cache global de runs injecté par l'app;
    // si absent, on retombe sur listPipelineRuns() (une requête).
    let runs = (window.__thermoPW_runsCache && window.__thermoPW_runsCache())
              || (window.__thermoPW_lastRunsList)
              || [];
    if (!runs.length) {
      try {
        const r = await window.ThermoPipeline.listPipelineRuns(100);
        runs = (r && (r.runs || r.items)) || [];
      } catch (e) { runs = []; }
    }
    const KO = new Set(["error", "cancelled", "interrupted", "stopped"]);
    const koCount = runs.filter(r => KO.has((r && r.status || "").toLowerCase())).length;
    let orphanCount = 0;
    try {
      const ids = runs.map(r => r && r.job_id).filter(Boolean);
      if (ids.length && window.ThermoPipeline && window.ThermoPipeline.checkWorks) {
        const resp = await window.ThermoPipeline.checkWorks(ids);
        orphanCount = (resp && resp.missing && resp.missing.length) || 0;
      }
    } catch (e) { /* ignore */ }
    const total = koCount + orphanCount;
    if (dom.runsPurgeStaleCount) {
      dom.runsPurgeStaleCount.textContent = String(total);
      dom.runsPurgeStaleCount.hidden = (total === 0);
    }
    dom.runsPurgeStale.disabled = (total === 0);
    dom.runsPurgeStale.title = total === 0
      ? "No stale entries: nothing to clean up."
      : `Supprimer ${total} obsolète${total > 1 ? "s" : ""} (KO + orphelins). Confirme avant.`;
  }
  // Exposé pour picker-refresh et tests manuels.
  window.thermoPW_refreshPurgeStaleBtn = _refreshPurgeStaleBtn;
})();

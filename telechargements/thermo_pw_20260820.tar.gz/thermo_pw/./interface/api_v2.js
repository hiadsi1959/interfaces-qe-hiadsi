/* ==========================================================================
   api_v2.js — HTTP client for /api/pipeline/*

   Follows the thermo_api_client.js philosophy but strictly focused
   on the 5-profile system.
   ========================================================================== */

(function () {
  "use strict";

  // API origin (dynamic port). Same host/port as the page.
  const ORIGIN =
    (typeof window !== "undefined" && window.API_PSEUDOS_ORIGIN) ||
    (typeof window !== "undefined"
      ? `${window.location.protocol}//${window.location.host}`
      : "");

  /** Small fetch helper that throws on HTTP >= 400 and returns JSON. */
  async function jsonFetch(path, opts = {}) {
    const url = path.startsWith("http") ? path : `${ORIGIN}${path}`;
    const init = Object.assign(
      {
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        credentials: "omit",
      },
      opts
    );

    // Fetch-level timeout (prevents blocking the UI when API is unresponsive or CORS is broken).
    const DEFAULT_TIMEOUT_MS = 30000;
    const timeoutMs = Number(opts.timeoutMs) || DEFAULT_TIMEOUT_MS;
    const controller = new (window.AbortController || function () {
      // Fallback IE/old: missing AbortController → no cancel capability,
      // but we let the fetch live (operations are bounded by backend threads anyway).
      return { signal: undefined, abort() {} };
    })();
    if (init.signal) {
      // If the caller already has an AbortSignal, we override it with our timeout.
      try { init.signal.aborted && controller.abort(); } catch (e) {}
    }
    init.signal = controller.signal;

    let timeoutId = null;
    if (typeof window.setTimeout === "function") {
      timeoutId = window.setTimeout(() => controller.abort(), timeoutMs);
    }

    let resp;
    try {
      resp = await fetch(url, init);
    } catch (netErr) {
      const isAbort = (netErr && (netErr.name === "AbortError" || /abort/i.test(String(netErr))));
      const e = new Error(
        isAbort
          ? `API timeout (>${timeoutMs} ms) on ${path}`
          : `API unreachable: ${netErr.message || netErr}`
      );
      e.network = true;
      e.aborted = isAbort;
      throw e;
    } finally {
      if (timeoutId !== null) window.clearTimeout(timeoutId);
    }
    const ct = resp.headers.get("content-type") || "";
    let data;
    if (ct.includes("application/json")) {
      data = await resp.json().catch(() => ({}));
    } else {
      data = { _text: await resp.text().catch(() => "") };
    }
    if (!resp.ok) {
      const err = new Error(
        (data && (data.error || data._text)) ||
        `HTTP ${resp.status} on ${path}`
      );
      err.status = resp.status;
      err.data = data;
      err.path = path;
      // Explicit stamp for ``/api/pipeline/jobs/<id>`` endpoint that returns
      // 404 + {"error": "job_id inconnu"} when the daemon restarted between
        // two polls (in-memory registry lost). Without this marker,
        // the UI would log `[ERR] polling: job_id unknown` in a loop every tick
        // even though it's a terminal state (job_id permanently unknown).
        if (
          resp.status === 404 &&
          typeof path === "string" &&
          /^\/api\/pipeline\/jobs\/[^/]+$/.test(path) &&
          data && data.error === "job_id inconnu"
        ) {
          err.staleJob = true;
        }
      throw err;
    }
    return data;
  }

  /** Main endpoints for the 5-profile system. */
  const Pipeline = {
    /**
     * Profile catalog. When a material (and optionally nproc) is supplied, the
     * backend attaches a `runtime_estimate` to every profile, computed from the
     * material's scf.in and this machine's capabilities.
     */
    listProfiles(material_id, scf_in_basename, nproc) {
      const qs = new URLSearchParams();
      if (material_id) qs.set("material_id", material_id);
      if (scf_in_basename) qs.set("scf_in_basename", scf_in_basename);
      if (nproc) qs.set("nproc", String(nproc));
      const suffix = qs.toString() ? `?${qs.toString()}` : "";
      return jsonFetch(`/api/pipeline/profiles${suffix}`);
    },

    /** Hardware capabilities: physical vs logical cores, RAM, speed index. */
    machineProfile() {
      return jsonFetch("/api/pipeline/machine");
    },

    listMaterials() {
      return jsonFetch("/api/materials");
    },

    listThermoInputs() {
      return jsonFetch("/api/inputs/thermo");
    },

    runPipeline({ material_id, profile_id, scf_in_basename, nproc, work_dir, p1_full_preset, extra_whats, needs_optical, lo_to_opt_in }) {
      return jsonFetch("/api/pipeline/run", {
        method: "POST",
        body: JSON.stringify({
          material_id,
          profile_id,
          scf_in_basename,
          nproc,
          work_dir: work_dir || "",
          // P1 preset (ichamp=3).
          p1_full_preset: p1_full_preset === true ? true : undefined,
          // P5: list of checked what= extras in the extended properties panel.
          extra_whats: Array.isArray(extra_whats) && extra_whats.length ? extra_whats : undefined,
          // P5 opt-in: full optical chain (epsilon.x + turbo).
          needs_optical: needs_optical === true ? true : undefined,
          // P1 opt-in: LO/TO correction (dielectric -> BORN -> matdyn). NC pseudos required.
          lo_to_opt_in: lo_to_opt_in === true ? true : undefined,
        }),
      });
    },

    jobStatus(job_id) {
      return jsonFetch(`/api/pipeline/jobs/${encodeURIComponent(job_id)}`);
    },

    cancelJob(job_id) {
      return jsonFetch(`/api/pipeline/jobs/${encodeURIComponent(job_id)}/cancel`, {
        method: "POST",
      });
    },

    scfInPreview(material_id, basename) {
      const qs =
        `material_id=${encodeURIComponent(material_id || "")}` +
        `&basename=${encodeURIComponent(basename || "")}`;
      return jsonFetch(`/api/inputs/scf_in_preview?${qs}`);
    },

    thermoPwInPreview(profile_id, material_id, nproc) {
      const qs =
        `profile_id=${encodeURIComponent(profile_id || "")}` +
        `&material_id=${encodeURIComponent(material_id || "")}` +
        `&nproc=${encodeURIComponent(nproc || 4)}`;
      return jsonFetch(`/api/pipeline/thermo_pw_in_preview?${qs}`);
    },

    health() {
      return jsonFetch("/api/health");
    },

    version() {
      return jsonFetch("/api/version");
    },

    listPipelineRuns(limit = 50) {
      return jsonFetch(
        `/api/pipeline/runs?limit=${encodeURIComponent(limit || 50)}`
      );
    },

    /** Borrow electronic + phonon results from an existing run (e.g. P1 → P2 preview). */
    sharedPreview(material_id, profile_id) {
      const qs =
        `material_id=${encodeURIComponent(material_id || "")}` +
        `&profile_id=${encodeURIComponent(profile_id || "P2")}`;
      return jsonFetch(`/api/pipeline/shared_preview?${qs}`);
    },

    loadPipelineRun(jobId) {
      return jsonFetch(
        `/api/pipeline/runs/${encodeURIComponent(jobId)}/load`,
        { method: "POST" }
      );
    },

    // Destructive deletion of a run (removes from registry + deletes work_dir from disk).
    deletePipelineRun(jobId) {
      return jsonFetch(
        `/api/pipeline/runs/${encodeURIComponent(jobId)}`,
        { method: "DELETE" }
      );
    },

    // Batch purge of persisted runs with terminal KO status
    purgeFailedRuns(opts) {
      const o = opts || {};
      return jsonFetch("/api/pipeline/runs/purge_failed", {
        method: "POST",
        body: JSON.stringify({
          dry_run: !!o.dry_run,
          material_id: (o.material_id || "") + "",
        }),
      });
    },

    // "Clean up": expanded bulk-cleanup.
    purgeStaleRuns(opts) {
      const o = opts || {};
      return jsonFetch("/api/pipeline/runs/purge_stale", {
        method: "POST",
        body: JSON.stringify({
          dry_run: !!o.dry_run,
          material_id: (o.material_id || "") + "",
        }),
      });
    },

    // Checks work_dir existence for multiple job_ids (used by picker for badging).
    checkWorks(jobIds) {
      const ids = Array.isArray(jobIds) ? jobIds : [];
      return jsonFetch("/api/pipeline/runs/check_works", {
        method: "POST",
        body: JSON.stringify({ job_ids: ids }),
      });
    },

    // Pause (checkpoint + cooperative stop, resume via resumeJob).
    pauseJob(jobId) {
      return jsonFetch(
        `/api/pipeline/jobs/${encodeURIComponent(jobId)}/pause`,
        { method: "POST" }
      );
    },

    // Stop (terminal cooperative stop, non-resumable).
    stopJob(jobId) {
      return jsonFetch(
        `/api/pipeline/jobs/${encodeURIComponent(jobId)}/stop`,
        { method: "POST" }
      );
    },

    // Resume (restarts a previously paused job via pauseJob).
    resumeJob(jobId) {
      return jsonFetch(
        `/api/pipeline/jobs/${encodeURIComponent(jobId)}/resume`,
        { method: "POST" }
      );
    },

    // Restart (restarts a job in interrupted/error/cancelled state,
    // distinct from resumeJob which targets paused). Covers the typical case:
    // API server restarted, worker disappeared, UI shows interrupted.
    // Backend rehydrates the job from disk marker (if needed) and
    // relaunches _execute on the same work_dir; sub-steps marked
    // DONE in workflow_state.json are automatically skipped.
    // Return codes: 202 (accepted), 400 (incompatible status), 404 (not found),
    // 409 (transition impossible), 410 (work_dir absent).
    restartJob(jobId) {
      return jsonFetch(
        `/api/pipeline/jobs/${encodeURIComponent(jobId)}/restart`,
        { method: "POST" }
      );
    },

    // Pre-resume inspection. Resuming skips steps already marked done, which is
    // right after a power cut and wrong after a misconfiguration — the faulty
    // steps are precisely the ones marked done. Ask before acting.
    // Always returns 200 with diagnosis=null when unavailable, so a missing
    // diagnosis never blocks a legitimate resume. 404 only if the job is unknown.
    resumeDiagnosis(jobId) {
      return jsonFetch(
        `/api/pipeline/jobs/${encodeURIComponent(jobId)}/resume_diagnosis`
      );
    },

    /** Cibles de reprise thermo_pw sans refaire EOS / phonons (P1–P5). */
    resumeThermoPwOptions(jobId) {
      return jsonFetch(
        `/api/pipeline/jobs/${encodeURIComponent(jobId)}/resume_thermo_pw/options`
      );
    },

    /** Reprend thermo_pw ; ``opts``: target, lsolve, deltat, therm_mode (dos|freq). */
    resumeThermoPw(jobId, opts = {}) {
      const o = typeof opts === "string"
        ? { target: opts }
        : (opts || {});
      const body = { target: o.target || "thermo_main" };
      if (o.lsolve != null && o.lsolve !== "") {
        body.lsolve = Number(o.lsolve);
      }
      if (o.deltat != null && o.deltat !== "") {
        body.deltat = Number(o.deltat);
      }
      if (o.therm_mode) {
        body.therm_mode = String(o.therm_mode);
      }
      return jsonFetch(
        `/api/pipeline/jobs/${encodeURIComponent(jobId)}/resume_thermo_pw`,
        {
          method: "POST",
          body: JSON.stringify(body),
        }
      );
    },

    runSanity(jobId) {
      return jsonFetch(
        `/api/pipeline/runs/${encodeURIComponent(jobId)}/sanity`
      );
    },

    runExpertise(jobId) {
      return jsonFetch(
        `/api/pipeline/runs/${encodeURIComponent(jobId)}/expertise`
      );
    },

    /** Re-parse disk outputs without relaunching MPI (job must be in registry). */
    reparseJob(jobId) {
      return jsonFetch(
        `/api/pipeline/jobs/${encodeURIComponent(jobId)}/reparse`,
        { method: "POST", timeoutMs: 120000 }
      );
    },

    // Downloadable fact sheet (Markdown / HTML / PDF).
    // PDF format requires weasyprint on server (lazy-import) +
    // native libs Cairo/Pango; the UI grays out the selector option
    // (#runsFactsheetFmt) if /api/health indicates
    // factsheet_pdf_available=false.
    // Returns a URL directly consumable by window.open(url) /
    // a <a download>. The backend sets Content-Disposition: inline;
    // filename="factsheet_<profile>_<job_id>.<ext>" (RFC 5987 filename*).
    // ``fmt`` ∈ ``"md"`` | ``"html"`` (défaut ``"html"``).
    factsheet(jobId, fmt) {
      const f = (fmt === "md" || fmt === "markdown") ? "md" : "html";
      const jid = encodeURIComponent(jobId || "");
      // Returns the raw URL rather than a fetch: the sheet is heavy
      // (full inline-friendly HTML) and the route forces the correct
      // Content-Disposition server-side. The browser handles opening
      // or downloading based on user action (middle-click/Cmd+click).
      return `${ORIGIN}/api/pipeline/runs/${jid}/factsheet?format=${f}`;
    },
  };

  /** Utilities exposed on window for other scripts. */
  window.ThermoPipeline = Pipeline;
  window.ThermoAPI = Object.assign(window.ThermoAPI || {}, {
    jsonFetch,
    ORIGIN,
  });
})();

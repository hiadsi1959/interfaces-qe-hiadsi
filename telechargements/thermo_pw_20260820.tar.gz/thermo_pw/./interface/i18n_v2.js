/* eslint-disable max-len */
(function (global) {
  "use strict";

  const LANG_KEY = "thermo_pw_ui_lang";
  const THEME_KEY = "thermo_pw_theme";
  let _lang = "fr";
  let _theme = "dark";

  const STRINGS = {
    en: {
      "header.subtitle": "5 profiles · 4-step workflow · one-click launch",
      "header.title": "thermo_pw — 5 profiles · 4-step workflow · one-click launch",
      "header.usageGuide": "User Guide",
      "header.usageGuideTitle": "Open the 5-profile user guide",
      "nav.home": "Home",
      "nav.workspace": "Calculate",
      "lang.switchAria": "Interface language",
      "theme.switchAria": "Display theme",
      "theme.darkTitle": "Dark mode",
      "theme.lightTitle": "Light mode",
      "api.online": "API online",
      "api.offline": "API offline",
      "home.kicker": "Quantum ESPRESSO + thermo_pw",
      "home.title": "User guide — 5 profiles",
      "home.lead":
        "Overview of each calculation profile (P1–P5): full orchestrated chain from " +
        "your <code>scf.in</code> to thermo_pw results. Section ④ shows " +
        "<b>profile-aware metrics</b> (only what P1–P5 promises) and refreshes live " +
        "during the run. After a QHA crash, <b>Resume thermo_pw</b> skips EOS/phonons " +
        "and continues from partial geometry progress.",
      "home.featuresTitle": "Results & recovery (August 2026)",
      "home.featuresList":
        "<li><b>Profile-aware metrics</b> — section ④ and the Artifacts panel list only quantities " +
        "declared for the loaded profile (e.g. P2: EOS + QHA thermo, not P5-only ε₀ / Z*).</li>" +
        "<li><b>Live refresh</b> — parsed values (C<sub>v</sub>, F, S, stability…) update while " +
        "thermo_pw runs; pending fields explain why (QHA geometry 5/9, α missing, etc.).</li>" +
        "<li><b>Resume thermo_pw</b> — after a thermo_pw failure mid-QHA, relaunch only thermo_pw " +
        "(EOS + phonons kept; partial geometries cleaned safely).</li>" +
        "<li><b>Load a previous run</b> — picker in section ④ reopens disk state; re-parse refreshes metrics without MPI.</li>",
      "home.start": "Let's go to calculations",
      "home.chain": "Calculation chain",
      "home.outputs": "Main outputs",
      "home.electronicTitle": "Electronic structure — what you can extract (P1–P5)",
      "home.electronicIntro":
        "All profiles run <code>ichamp=3</code> after the main chain: NSCF → <code>dos.x</code> → " +
        "<code>pw.x</code> BANDS → <code>bands.x</code> → plots <code>ebands.png</code> / <code>edos.png</code>. " +
        "The k-path follows high-symmetry points from <code>ibrav</code> (Γ, X, …).",
      "insight.available": "Computed",
      "insight.partial": "Qualitative (plots)",
      "insight.future": "Not implemented",
      "gap.direct": "Direct",
      "gap.indirect": "Indirect",
      "gapType.metal": "Metal",
      "gapType.semiconductor": "Semiconductor",
      "gapType.insulator": "Insulator",
      "gapType.zero_gap_semimetal": "Zero-gap semi-metal",
      "home.contractSummary":
        "{metrics} metrics · {plots} plots · {groups}",
      "home.whatPrefix": "thermo_pw what=",
      "sec1.title": "Material &amp; <code>scf.in</code> selection",
      "sec1.hint": "Select the material whose <code>scf.in</code> file serves as input for the calculation series.",
      "sec1.material": "Material:",
      "sec1.scf": "scf.in:",
      "sec1.nproc": "MPI (nproc):",
      "sec1.files": "<code>.in</code> files",
      "sec1.path": "Resolved path",
      "sec1.previewScf": "📄 Preview <code>scf.in</code>",
      "sec1.selectMat": "— Select a material —",
      "sec2.title": "<code>thermo_pw.in</code> (generated from profile)",
      "sec2.hint": "Pseudo-structured preview of the file that will be passed to <code>thermo_pw.x</code> at launch.",
      "sec2.waitProfile": "ⓘ First select a profile (tile above) then a material.",
      "sec2.previewTpwin": "🛠 Preview <code>thermo_pw.in</code> format",
      "sec2.waitSelection": "— Waiting for profile/material selection —",
      "sec2.directive": "Directive",
      "sec2.value": "Value",
      "sec3.title": "Run calculations",
      "sec3.hint": "All steps (material + profile) are set: a single click launches the full series.",
      "sec3.launch": "Run calculations",
      "sec3.cancel": "Cancel",
      "sec3.cancelTitle": "Stop the running calculation",
      "sec3.resume": "Full chain resume",
      "sec3.resumeShort": "Full chain",
      "sec3.resumeTitle": "Restarts the whole pipeline — steps marked DONE are skipped",
      "sec3.resumeThermoPw": "Resume thermo_pw",
      "sec3.resumeThermoPwTitle":
        "Skip EOS/phonons — resume thermo_pw; optional QHA tuning (lsolve, ΔT, DOS/freq)",
      "sec3.resumeThermoPwHint":
        "Machine: nproc=2, free RAM/swap before resume. Profile defaults (ΔT=50 K) apply only on first launch — adjust below if needed.",
      "sec3.resumeGroupTitle": "Resume after failure",
      "sec3.resumeGroupHint": "Blue = thermo_pw only + optional tuning · Orange = full chain",
      "sec3.resumeThermoCardDesc":
        "Keeps EOS + phonons · optional lsolve / ΔT / DOS|freq for this material",
      "sec3.resumeFullCardDesc":
        "Restarts the whole pipeline · skips steps already marked done",
      "sec3.resumeRecommended": "Recommended",
      "sec3.resumeGuideCancel": "Cancel",
      "sec3.resumeThermoGuideConfirm": "Start thermo_pw resume",
      "sec3.resumeThermoGuideTitle": "Resume thermo_pw — guided restart",
      "sec3.resumeThermoGuideIntro":
        "Use when thermo_pw failed (QHA, dielectric, Born…) while EOS and phonons are on disk. Works for any material (binary, ternary, magnetic or not) — tuning is per run, not baked into P1–P5 profiles.",
      "sec3.resumeThermoGuideStandardTitle": "P1–P5 profiles stay standard on first launch",
      "sec3.resumeThermoGuideStandardText":
        "« Run calculations » always uses the profile defaults (e.g. P2/P3: ΔT=50 K, no lsolve). Do not change scf.in or the profile for DGELS recovery — use the options below only when resuming this job.",
      "sec3.resumeThermoGuideTuningTitle": "What each advanced option does (P2–P4 QHA)",
      "sec3.resumeThermoGuideTuningList":
        "lsolve 1 — normal equations (often best after DGELS; Si reference case)\nlsolve 2 — QR / DGELS (thermo_pw default on first launch)\nlsolve 3 — SVD (try if lsolve 1 still fails)\nΔT 100–200 K — fewer T points, better conditioned anharmonic fit\nDOS — phonon DOS thermodynamics (default P2/P3)\nFrequencies — alternate path if DOS fit keeps failing (default P4)",
      "sec3.resumeThermoGuideMaterialsTitle": "All material types (same workflow)",
      "sec3.resumeThermoGuideMaterialsText":
        "Metals, insulators, binaries, ternaries, quaternaries, magnetic or not: the pipeline is the same. Check magnetic tags in results after the run. If phonons are stable but QHA fit fails, tune lsolve/ΔT here — not in a new profile.",
      "sec3.resumeThermoGuideDgelsTitle": "If the log shows DGELS / linsolvms / SVD error",
      "sec3.resumeThermoGuideDgelsList":
        "1. Keep blue « Resume thermo_pw » (not full chain)\n2. Select lsolve=1 and ΔT=100 K\n3. Keep DOS for P2/P3 unless you already tried it\n4. nproc=2, close heavy apps (swap)\n5. If it fails again: try frequencies, then lsolve=3",
      "sec3.resumeThermoGuideMachineTitle": "Before confirming resume",
      "sec3.resumeThermoGuideMachineList":
        "Prefer nproc=2 (or 1 if MKL/FFT crashes persist)\nFree swap — paging doubles wall time\nDo not click Resume twice — wait or Ctrl+F5 to reattach",
      "sec3.resumeThermoGuideKeepTitle": "Kept on disk (not re-run)",
      "sec3.resumeThermoGuideKeepList":
        "EOS grid and Birch–Murnaghan fit\nPhonon chain (ph, q2r, matdyn)\nFinished QHA geometries (output_therm.dat.gN)\nPartial restart/ state is cleaned automatically",
      "sec3.resumeThermoGuideRedoTitle": "Re-run",
      "sec3.resumeThermoGuideRedoList":
        "thermo_pw.x from the incomplete geometry\nPost-processing (DOS/bands, plots…)",
      "sec3.resumeThermoGuideWhenTitle": "When to use this button",
      "sec3.resumeThermoGuideWhenList":
        "Crash during thermo_pw (MKL, MPI, RAM…)\nPower cut during QHA\nYou want to save hours by not redoing EOS/phonons",
      "sec3.resumeThermoGuideVsFullTitle": "Difference vs « Full chain resume »",
      "sec3.resumeThermoGuideVsFullText":
        "Full chain resume follows workflow_state.json and may re-touch earlier steps. Prefer this blue card if only thermo_pw failed.",
      "sec3.resumeThermoQhaProgress": "QHA progress preserved: {done}/{total} geometry(ies)",
      "sec3.resumeThermoLsolveLabel": "QHA least-squares solver (lsolve)",
      "sec3.resumeThermoLsolveDefault": "Default (QR / DGELS — thermo_pw built-in)",
      "sec3.resumeThermoLsolve1": "1 — normal equations",
      "sec3.resumeThermoLsolve2": "2 — QR factorization",
      "sec3.resumeThermoLsolve3": "3 — SVD (if lsolve=1 still fails)",
      "sec3.resumeThermoLsolveDgelsHint":
        "DGELS/SVD detected in the log. Suggested: lsolve=1 + ΔT=100 K (leave profile default on first launch).",
      "sec3.resumeThermoQhaAdvancedTitle": "Advanced QHA options (anharmonic fit)",
      "sec3.resumeThermoDeltatLabel": "Temperature step ΔT (K)",
      "sec3.resumeThermoDeltatDefault": "Profile default (50 K)",
      "sec3.resumeThermoDeltatProfile": "Profile default ({deltat} K)",
      "sec3.resumeThermoDeltatOption": "{deltat} K",
      "sec3.resumeThermoDeltatHint": "Larger ΔT → fewer T points → better conditioned fit after DGELS.",
      "sec3.resumeThermoModeLabel": "Thermodynamic input",
      "sec3.resumeThermoModeDos": "Phonon DOS (ltherm_dos) — default",
      "sec3.resumeThermoModeFreq": "Phonon frequencies (ltherm_freq) — if DOS fit keeps failing",
      "sec3.resumeThermoModeHint": "Switching to frequencies may recompute output_therm.dat.g* per geometry (no EOS/phonon redo).",
      "sec3.resumeThermoP3Hint": "P3 — elastic_constants_geo: same QHA loop as P2, then C_ij(V₀,T) on the T grid.",
      "sec3.resumeThermoP4Hint": "P4 — ph_life: default is frequencies (not DOS). Keep it unless you know you need DOS.",
      "sec3.resumeThermoAlreadyRunning":
        "A run is already in progress. Do not click resume again — refresh the page to reattach live polling.",
      "sec3.resumeFullGuideTitle": "Full chain resume",
      "sec3.resumeFullGuideIntro":
        "Restarts the pipeline on the same folder. Sub-steps marked DONE in workflow_state.json are skipped.",
      "sec3.resumeFullGuideWarn":
        "If the failure was only in thermo_pw, prefer « Resume thermo_pw » (blue card) to avoid redoing heavy steps.",
      "sec3.resumeFullGuideConfirm": "Continue with full chain resume",
      "sec3.idle": "Waiting — complete sections ① and ②",
      "sec3.progress": "Waiting…",
      "sec3.doneBanner": "CALCULATIONS COMPLETE",
      "sec3.goResults": "View results",
      "sec3.liveLog": "Live log",
      "wf.step1": "Material",
      "wf.step2": "thermo_pw.in",
      "wf.step3": "Run",
      "wf.step4": "Results",
      "wf.aria": "Workflow steps",
      "sec4.runPlaceholderAlt": "— Load another run —",
      "sec4.runsCountNone": "(no persisted runs)",
      "sec4.runsCount": "{n} persisted run(s)",
      "sec4.runsUnavailable": "(list unavailable)",
      "runsLoad.titleSelect": "Select a run from the list first.",
      "runsLoad.titleSame": "This run is already displayed.",
      "runsLoad.titleBusy": "Loading…",
      "runsLoad.titleGo": "Show results in section ④.",
      "resultsMeta.done": "done — {n} result group(s)",
      "sec3.logIdle": "— Click \"Run calculations\" to start. —",
      "sec4.title": "Results",
      "sec4.hint": "Metrics, plots and files generated by the series (updated live).",
      "sec4.loadTitle": "Load a previous calculation",
      "sec4.loadSub":
        "Select a results folder, then click \"Show this run\" to display results without re-running.",
      "sec4.cleanup": "Clean up",
      "sec4.cleanupTitle": "Remove failed runs and orphan registry entries",
      "sec4.refreshTitle": "Refresh the run list",
      "sec4.runLabel": "Run:",
      "sec4.runPlaceholder": "— Load a previous calculation —",
      "sec4.showRun": "Show results",
      "sec4.factsheet": "Fact sheet",
      "sec4.expertiseTitle": "Expert analysis",
      "sec4.expertiseOpenFactsheet": "Open full fact sheet ↗",
      "sec4.expertiseSummaryOk": "{nOk} valid insight(s) · {nWarn} warning(s) · {nErr} alert(s)",
      "sec4.expertiseSummaryEmpty": "No expert insights for this profile yet.",
      "sec4.compareLabel": "Compare with:",
      "sec4.comparePlaceholder": "— Select a second run —",
      "sec4.compareBtn": "Compare runs",
      "sec4.compareTitle": "Compare the loaded run with another persisted run.",
      "sec4.compareNeedA": "Load a run first (Show results), then pick a second run.",
      "sec4.compareNeedB": "Select a second run to compare.",
      "sec4.compareSame": "Choose a different run for comparison.",
      "sec4.compareBusy": "Comparison in progress…",
      "sec4.compareHeadMetric": "Metric",
      "sec4.compareHeadDelta": "Δ",
      "sec4.reparse": "Re-parse disk",
      "sec4.reparseTitle": "Re-read output files on disk (gap, Cij, EOS…) without relaunching MPI.",
      "sec4.reparseBusy": "Re-parsing…",
      "sec4.reparseOk": "Re-parse OK — results refreshed from disk.",
      "sec4.reparseNeedLoad": "Load this run first, then re-parse.",
      "sec4.gapsTitle": "Extended properties coverage",
      "sec4.gapsHint": "Recently added metrics vs roadmap items.",
      "sec4.gapsOk": "Available",
      "sec4.gapsFilled": "Filled",
      "sec4.gapsEmpty": "Missing",
      "sec4.gapsFuture": "Planned",
      "sec4.gapsHintRun": "Status for the loaded run (re-parse disk to refresh).",
      "artifacts.parsedSection": "Parsed quantities",
      "artifacts.parsedCount": "{filled} / {total} filled",
      "artifacts.metricAbsent": "Missing — not in this profile or re-parse disk",
      "artifacts.metricPendingRun": "Pending — calculation in progress",
      "artifacts.metricPendingQha": "Pending — QHA geometry grid incomplete (Debye, α need full 9-point grid)",
      "artifacts.metricPendingQhaProgress": "Pending — QHA geometry {cur}/{total} (Debye, α after full grid)",
      "artifacts.metricPendingQhaPartial": "Partial QHA — re-parse disk after thermo_pw completes",
      "artifacts.filesSection": "Files on disk",
      "artifacts.metricSource": "Source",
      "thermoSource.slater_gamma_0.5_estimate": "Estimated via Grüneisen (γ ≈ 0.5, Debye model)",
      "thermoSource.slater_gamma_0.5": "Estimated via Grüneisen (γ ≈ 0.5)",
      "thermoSource.gruneisen_mean": "Mean phonon Grüneisen parameter γ(q,ν)",
      "thermoSource.log_alpha_vs_T": "Parsed from thermo_pw log (α vs T)",
      "thermoSource.log_alpha_scalar": "Parsed from thermo_pw log (scalar α)",
      "thermoSource.volume_table": "From V(T) table (dV/dT)",
      "thermoSource.Cv_plus_TValpha2B": "Cp ≈ Cv + T·V·α²·B @ 300 K",
      "thermoSource.Cv_plus_TValpha2B_curve": "Cp(T) = Cv(T) + T·V·α²·B",
      "thermoSource.Cv_plus_TValpha2B_curve_alpha_vs_T": "Cp(T) curve with α(T)",
      "thermoSource.Cv_plus_TValpha2B_curve_alpha_const": "Cp(T) curve with constant α",
      "thermoSource.Cv_plus_TValpha2B_curve_B_vs_T": "Cp(T) curve with B(T)",
      "thermoSource.gruneisen_alpha_vs_T": "α(T) from γ·Cv/(B·V)",
      "thermoSource.qha_out_column": "Column from qha.out / thermo.out",
      "thermoSource.Cp_equals_Cv_no_alpha": "Cp = Cv (α or B missing)",
      "cvCpChart.title": "C<sub>v</sub>(T) vs C<sub>p</sub>(T)",
      "cvCpChart.hint": "Hover to inspect thermal expansion divergence at high T",
      "cvCpChart.xLabel": "T (K)",
      "cvCpChart.yLabel": "Ry / cell / K",
      "thermoSource.lyddane_sachs_teller": "Lyddane–Sachs–Teller (LO/TO + ε∞)",
      "artifacts.noParsedYet": "No parsed extended metrics yet — wait for thermo_pw / re-parse disk.",
      "gaps.alpha": "Thermal expansion α(T) — parsed or estimated (QHA / Grüneisen)",
      "gaps.cp": "Heat capacity Cp @ 300 K — from Cv + T·V·α²·B when α is known",
      "gaps.eps0": "Static dielectric ε₀ — Lyddane–Sachs–Teller from LO/TO + ε∞",
      "gaps.piezo": "Piezoelectric tensor e_ijk — numeric tiles + matrix (P5 extra)",
      "gaps.zstar": "Born effective charges Z* — live table per atom (P5 / LO/TO)",
      "gaps.pressure": "Explicit pressure P sweep — not yet in pipeline profiles",
      "gaps.thermoelectric": "Thermoelectricity (Seebeck, ZT) — requires BoltzTraP-class post-processing",
      "sec4.zstarTableTitle": "Born effective charges Z* (per atom)",
      "sec4.zstarColAtom": "Atom",
      "sec4.zstarColType": "Type",
      "sec4.piezoTableTitle": "Piezoelectric tensor e_ijk (C/m², Voigt 3×6)",
      "sec4.empty":
        "ⓘ Select material + profile for the expected preview (pending metrics). Pick a finished run below to see actual values.",
      "sec4.previewBanner":
        "Preview — {name}: {metrics} metric(s), {plots} plot(s), {files} file(s) expected.",
      "sec4.siblingPreview":
        "Partial preview: electronic + phonon data borrowed from a completed run on the same material.",
      "sec4.workdir": "Output folder",
      "sec4.copy": "📋 Copy",
      "sec4.copyTitle": "Copy full path to clipboard",
      "sec4.sanity": "Scientific validity",
      "bool.yes": "✓ yes",
      "bool.no": "✗ no",
      "launch.ready": "Ready — click Run calculations",
      "launch.missing": "Waiting — select:",
      "launch.running": "Launching…",
      "launch.done": "Complete — see results in section ④",
      "launch.cancelled": "Cancelled",
      "launch.resuming": "Resuming — job in progress",
      "mat.none": "— No material available —",
      "ug.title": "📖 User Guide",
      "ug.intro":
        "Each profile orchestrates a different <b>Quantum ESPRESSO + thermo_pw calculation chain</b>. " +
        "The 5 profiles cover mechanics at 0 K, thermal QHA, full study, phonon lifetimes, and dielectric properties.",
      "ug.workflowTitle": "Workflow in 4 steps",
      "ug.inputs": "Required inputs",
      "ug.chain": "Calculation chain",
      "ug.files": "Generated files & metrics",
      "ug.prereq": "Prerequisites & limits",
      "p5.legend": "Extended <code>thermo_pw.x</code> properties (P5)",
      "p5.hint": "Additional <code>thermo_pw.x</code> sub-runs after <code>what='dielectric'</code>. Each option adds its own log. Failures do not stop the run.",
      "p5.optical": "Full optical chain ε(ω) <span class=\"muted\">(epsilon.x + turbo_* — NC pseudos, high cost)</span>",
      "p1.legend": "P1 \"Full\" preset",
      "p1.hint": "Full P1 chain: <code>ichamp=3</code> adds NSCF + dos.x + bands.x after elastic constants. Phonon chain included for dynamic stability.",
      "p1.preset": "Elastic constants + DOS + Bands <span class=\"muted\">(P1 preset, ichamp=3)</span>",
      "p1.loto": "LO/TO correction at Γ <span class=\"muted\">(dielectric sub-run → BORN → matdyn non_analytic — NC pseudos)</span>",
      "sec2.waitProfileOnly": "ⓘ Select a profile (tile above) then a material.",
      "artifacts.title": "📦 Produced artifacts",
      "artifacts.hint": "Files in the run folder (PNG, PDF, DAT, IN, OUT…). View inline or open in a new tab.",
      "artifacts.view": "👁 View",
      "artifacts.open": "↗ Open",
      "artifacts.count": "({shown} shown of {total})",
      "tpwin.waitMat": "ⓘ Profile <b>{pid}</b> selected. Choose a material in section ①.",
      "tpwin.generating": "⏳ Generating preview for <b>{pid}</b> / <b>{mid}</b> / nproc={nproc}…",
      "tpwin.identity": "<b>{pid} · {pname}</b><span class=\"muted\"> · what=<code>{what}</code> · material=<code>{mid}</code> · nproc={nproc}</span>",
      "tpwin.materialRequired": "— material required to finalize preview —",
      // Runtime estimation (August 2026)
      "eta.tileTooltip":
        "Estimated range: {range} at nproc={nproc} · confidence: {confidence} · " +
        "dominant step: {dominant}. P2–P4 include the QHA loop (~9 phonon chains). " +
        "Refined live during the run (progress bar).",
      // Le backend renvoie la confiance en français (bonne/moyenne/faible) ;
      // ces clés la rendent dans la langue de l'interface.
      "eta.conf.bonne": "good",
      "eta.conf.moyenne": "fair",
      "eta.conf.faible": "low",
      "eta.liveMeasured": "≈ {remaining} left{extra} (measured on this run)",
      "eta.liveEstimated": "≈ {remaining} left{extra} (estimated)",
      "eta.qProgress": " · q-point {done}/{total}",
      "eta.volProgress": " · volume {done}/{total}",
      "eta.geoProgress": " · QHA geometry {done}/{total}",
      "machine.summary":
        "🖥 {cpu} — <b>{phys}</b> physical cores / {log} threads · {ram} GiB RAM · " +
        "recommended nproc = <b>{rec}</b>",
      // Disk footprint (August 2026)
      "storage.tileTooltip":
        "Peak disk usage: {peak} during the run, of which {scratch} is temporary " +
        "QE scratch (out_*/_ph0). Only {retained} of results are worth keeping. " +
        "Free space available: {free}.",
      "storage.live": " · 💾 {total}",
      "tpwin.unavailable": "ⓘ thermo_pw.in preview unavailable: {msg}",
      "tpwin.empty": "(empty)",
      "apm.title": "Preview",
      "apm.close": "Close preview",
      "apm.loading": "Loading…",
      "apm.selectFile": "Select a file in the Artifacts panel to preview it.",
      "toast.popupBlocked": "Popup blocked — allow popups for this site.",
      "footer.backend": "Backend: <code>/api/pipeline/*</code> · Polling: 1.5 s",
      "footer.health": "API Health",
      "footer.version": "Version",
      "ug.close": "Close guide",
      "ug.factsheetTitle": "📋 Downloadable fact sheet",
      "ug.factsheetIntro":
        "From <b>section ④ « Load a previous calculation »</b>, the <b>📋 Fact sheet</b> button generates a <b>complete</b> summary of the selected run:",
      "ug.factsheetLi1":
        "<b>10 profile-aware sections</b>: Header · EOS (Birch-Murnaghan) · C_ij + VRH · Electronic properties · Magnetism · Dynamic stability · Phonon lifetimes (P4) · Dielectric ε∞ + Born Z* (P5) · Scientific sanity-checks · Rule-based expert analysis.",
      "ug.factsheetLi2":
        "<b>Three formats</b>: <b>HTML</b> (default), <b>Markdown</b>, <b>PDF</b> (WeasyPrint). PDF option grays out if weasyprint is missing.",
      "ug.factsheetLi3":
        "<b>No MPI</b>: read-only aggregate from marker + scf.in + sanity-checks (P1..P5).",
      "ug.factsheetRoute":
        "Route: <code>GET /api/pipeline/runs/&lt;job_id&gt;/factsheet?format=md|html|pdf</code>. See <code>backend/factsheet.py</code>.",
      "ug.reconnectTitle": "Lost connection during a run?",
      "ug.reconnectIntro":
        "<b>No worries</b> — calculations run <b>on the server</b>, not in the browser. A brief network drop only interrupts live display; thermo_pw continues and persists state to disk at each step (<code>pipeline_api_job_state.json</code>).",
      "ug.reconnectLi1": "You can close the tab: the calculation continues on the server.",
      "ug.reconnectLi2":
        "After <b>power loss or PC reboot</b>, use <b>Full chain resume</b> — completed steps are skipped.",
      "ug.reconnectLi3":
        "Crash mid-<code>thermo_pw</code> QHA (MKL/FFT)? Use <b>Resume thermo_pw</b> — keeps EOS + phonons, restarts from the interrupted geometry.",
      "ug.reconnectLi4": "Section ④ <b>Load a previous calculation</b>: runs persist on disk for days.",
      "ug.workflowTagline":
        'The header <b>5 profiles · 4-step workflow · one-click launch</b> summarizes the architecture: 5 profiles (P1..P5) × 4 numbered sections <span class="ug-step-num">①②③④</span>; each series starts with one click on <b>Run calculations</b>.',
      "ug.wfStep1Title": "Material &amp; <code>scf.in</code>",
      "ug.wfStep1Desc": "select material and DFT input (SCF equilibrium).",
      "ug.wfStep2Title": "<code>thermo_pw.in</code>",
      "ug.wfStep2Desc": "pseudo-structured preview from profile + material.",
      "ug.wfStep3Title": "Run",
      "ug.wfStep3Desc":
        "one click starts the full chain; after failure use <b>Resume thermo_pw</b> (QHA only) or <b>Full chain resume</b>.",
      "ug.wfStep4Title": "Results",
      "ug.wfStep4Desc":
        "profile-aware live metrics, plots and Artifacts panel; <b>Load a previous calculation</b> to reopen a run; re-parse disk to refresh.",
    },
    fr: {
      "header.subtitle": "5 profils · workflow 4 étapes · lancement 1 clic",
      "header.title": "thermo_pw — 5 profils · workflow 4 étapes · lancement 1 clic",
      "header.usageGuide": "Guide d'utilisation",
      "header.usageGuideTitle": "Ouvrir le guide d'utilisation des 5 profils",
      "nav.home": "Accueil",
      "nav.workspace": "Calculs",
      "lang.switchAria": "Langue de l'interface",
      "theme.switchAria": "Thème d'affichage",
      "theme.darkTitle": "Mode sombre",
      "theme.lightTitle": "Mode clair",
      "api.online": "API en ligne",
      "api.offline": "API hors ligne",
      "home.kicker": "Quantum ESPRESSO + thermo_pw",
      "home.title": "Guide d'utilisation — 5 profils",
      "home.lead":
        "Vue d'ensemble de chaque profil de calcul (P1–P5) : chaîne orchestrée complète depuis " +
        "votre <code>scf.in</code> jusqu'aux résultats thermo_pw. La section ④ affiche des " +
        "<b>métriques adaptées au profil</b> (seulement ce que P1–P5 promet) et se met à jour " +
        "en direct pendant le run. Après un crash QHA, <b>Reprendre thermo_pw</b> évite de refaire EOS/phonons.",
      "home.featuresTitle": "Résultats & reprise (août 2026)",
      "home.featuresList":
        "<li><b>Métriques profil-aware</b> — section ④ et panneau Artefacts : uniquement les grandeurs " +
        "du contrat du profil chargé (ex. P2 : EOS + thermo QHA, pas ε₀ / Z* réservés au P5).</li>" +
        "<li><b>Rafraîchissement live</b> — valeurs parsées (C<sub>v</sub>, F, S, stabilité…) mises à jour " +
        "pendant thermo_pw ; les champs en attente expliquent pourquoi (géom. QHA 5/9, α absent, etc.).</li>" +
        "<li><b>Reprendre thermo_pw</b> — après échec thermo_pw en milieu de QHA, relance thermo_pw seul " +
        "(EOS + phonons conservés ; géométries partielles nettoyées proprement).</li>" +
        "<li><b>Charger un calcul précédent</b> — picker section ④ rouvre l'état disque ; re-parse sans relancer MPI.</li>",
      "home.start": "Passons aux calculs",
      "home.chain": "Chaîne de calculs",
      "home.outputs": "Sorties principales",
      "home.electronicTitle": "Structure électronique — ce qu'on peut en tirer (P1–P5)",
      "home.electronicIntro":
        "Tous les profils exécutent <code>ichamp=3</code> après la chaîne principale : NSCF → <code>dos.x</code> → " +
        "<code>pw.x</code> BANDS → <code>bands.x</code> → tracés <code>ebands.png</code> / <code>edos.png</code>. " +
        "Le chemin k suit les points spéciaux dérivés de <code>ibrav</code> (Γ, X, …).",
      "insight.available": "Calculé",
      "insight.partial": "Qualitatif (tracés)",
      "insight.future": "Non implémenté",
      "gap.direct": "Direct",
      "gap.indirect": "Indirect",
      "gapType.metal": "Métal",
      "gapType.semiconductor": "Semi-conducteur",
      "gapType.insulator": "Isolant",
      "gapType.zero_gap_semimetal": "Semi-métal à gap nul",
      "home.contractSummary":
        "{metrics} métriques · {plots} graphiques · {groups}",
      "home.whatPrefix": "thermo_pw what=",
      "sec1.title": "Choix du matériau &amp; <code>scf.in</code>",
      "sec1.hint": "Sélectionnez le matériau dont le fichier <code>scf.in</code> sert d'entrée à la série.",
      "sec1.material": "Matériau :",
      "sec1.scf": "scf.in :",
      "sec1.nproc": "MPI (nproc) :",
      "sec1.files": "Fichiers <code>.in</code>",
      "sec1.path": "Chemin résolu",
      "sec1.previewScf": "📄 Aperçu <code>scf.in</code>",
      "sec1.selectMat": "— Sélectionnez un matériau —",
      "sec2.title": "<code>thermo_pw.in</code> (généré depuis le profil)",
      "sec2.hint": "Aperçu pseudo-structuré du fichier passé à <code>thermo_pw.x</code> au lancement.",
      "sec2.waitProfile": "ⓘ Sélectionnez d'abord un profil (tuile ci-dessus) puis un matériau.",
      "sec2.previewTpwin": "🛠 Aperçu format <code>thermo_pw.in</code>",
      "sec2.waitSelection": "— En attente profil / matériau —",
      "sec2.directive": "Directive",
      "sec2.value": "Valeur",
      "sec3.title": "Lancer la série de calculs",
      "sec3.hint": "Matériau + profil prêts : un clic lance toute la chaîne.",
      "sec3.launch": "Lancer la série de calculs",
      "sec3.cancel": "Annuler",
      "sec3.cancelTitle": "Arrêter le calcul en cours",
      "sec3.resume": "Reprise complète",
      "sec3.resumeShort": "Chaîne complète",
      "sec3.resumeTitle": "Relance toute la chaîne — étapes marquées DONE sautées",
      "sec3.resumeThermoPw": "Reprendre thermo_pw",
      "sec3.resumeThermoPwTitle":
        "Sans EOS/phonons — reprend thermo_pw ; réglages QHA optionnels (lsolve, ΔT, DOS/fréq.)",
      "sec3.resumeThermoPwHint":
        "Machine : nproc=2, libérer RAM/swap avant reprise. Les défauts profil (ΔT=50 K) valent au premier lancement seulement — ajuster ci-dessous si besoin.",
      "sec3.resumeGroupTitle": "Reprise après échec",
      "sec3.resumeGroupHint": "Bleu = thermo_pw seul + réglages optionnels · Orange = chaîne complète",
      "sec3.resumeThermoCardDesc":
        "Conserve EOS + phonons · lsolve / ΔT / DOS|fréq. optionnels pour ce matériau",
      "sec3.resumeFullCardDesc":
        "Relance tout le pipeline · saute les étapes déjà marquées terminées",
      "sec3.resumeRecommended": "Recommandé",
      "sec3.resumeGuideCancel": "Annuler",
      "sec3.resumeThermoGuideConfirm": "Lancer la reprise thermo_pw",
      "sec3.resumeThermoGuideTitle": "Reprendre thermo_pw — reprise guidée",
      "sec3.resumeThermoGuideIntro":
        "À utiliser quand thermo_pw a échoué (QHA, diélectrique, Born…) alors que EOS et phonons sont sur disque. Valable pour tout matériau (binaire, ternaire, magnétique ou non) — les réglages ci-dessous sont par run, pas gravés dans les profils P1–P5.",
      "sec3.resumeThermoGuideStandardTitle": "Profils P1–P5 : standard au premier lancement",
      "sec3.resumeThermoGuideStandardText":
        "« Lancer la série » utilise toujours les défauts du profil (ex. P2/P3 : ΔT=50 K, sans lsolve). Ne modifiez pas scf.in ni le profil pour corriger un DGELS — utilisez les options ci-dessous uniquement en reprise de ce job.",
      "sec3.resumeThermoGuideTuningTitle": "Rôle de chaque option avancée (QHA P2–P4)",
      "sec3.resumeThermoGuideTuningList":
        "lsolve 1 — équations normales (souvent le meilleur après DGELS ; cas Si)\nlsolve 2 — QR / DGELS (défaut thermo_pw au 1er lancement)\nlsolve 3 — SVD (si lsolve 1 échoue encore)\nΔT 100–200 K — moins de points T, ajustement anharmonique mieux conditionné\nDOS — thermo via DOS phonons (défaut P2/P3)\nFréquences — autre chemin si l'ajustement DOS échoue (défaut P4)",
      "sec3.resumeThermoGuideMaterialsTitle": "Tous types de matériaux (même chaîne)",
      "sec3.resumeThermoGuideMaterialsText":
        "Métaux, isolants, binaires, ternaires, quaternaires, magnétiques ou non : la chaîne est la même. Vérifiez les indicateurs magnétiques dans les résultats. Si les phonons sont stables mais l'ajustement QHA échoue, réglez lsolve/ΔT ici — pas via un nouveau profil.",
      "sec3.resumeThermoGuideDgelsTitle": "Si le journal signale DGELS / linsolvms / SVD",
      "sec3.resumeThermoGuideDgelsList":
        "1. Garder la carte bleue « Reprendre thermo_pw » (pas reprise complète)\n2. Choisir lsolve=1 et ΔT=100 K\n3. Garder DOS pour P2/P3 sauf essai déjà fait\n4. nproc=2, fermer apps lourdes (swap)\n5. Si échec : essayer fréquences, puis lsolve=3",
      "sec3.resumeThermoGuideMachineTitle": "Avant de confirmer la reprise",
      "sec3.resumeThermoGuideMachineList":
        "Préférer nproc=2 (ou 1 si crash MKL/FFT)\nLibérer le swap — la pagination double la durée\nNe pas recliquer Reprendre — attendre ou Ctrl+F5 pour rattacher",
      "sec3.resumeThermoGuideKeepTitle": "Conservé (non relancé)",
      "sec3.resumeThermoGuideKeepList":
        "Grille EOS + fit Birch–Murnaghan\nChaîne phonon (ph, q2r, matdyn)\nGéométries QHA déjà terminées (output_therm.dat.gN)\nNettoyage auto de restart/ et géom. partielle",
      "sec3.resumeThermoGuideRedoTitle": "Relancé",
      "sec3.resumeThermoGuideRedoList":
        "thermo_pw.x à partir de la géométrie incomplète\nPost-traitements aval (DOS/bandes, tracés…)",
      "sec3.resumeThermoGuideWhenTitle": "Quand utiliser ce bouton",
      "sec3.resumeThermoGuideWhenList":
        "Crash thermo_pw (MKL, MPI, RAM…)\nCoupure pendant la QHA\nGagner des heures en ne refaisant pas EOS/phonons",
      "sec3.resumeThermoGuideVsFullTitle": "Différence avec « Reprise complète »",
      "sec3.resumeThermoGuideVsFullText":
        "La reprise complète suit workflow_state.json et peut retoucher des étapes amont. Préférez la carte bleue si seul thermo_pw a échoué.",
      "sec3.resumeThermoQhaProgress": "Progression QHA conservée : {done}/{total} géométrie(s)",
      "sec3.resumeThermoLsolveLabel": "Solveur moindres carrés QHA (lsolve)",
      "sec3.resumeThermoLsolveDefault": "Défaut (QR / DGELS — thermo_pw)",
      "sec3.resumeThermoLsolve1": "1 — équations normales",
      "sec3.resumeThermoLsolve2": "2 — factorisation QR",
      "sec3.resumeThermoLsolve3": "3 — SVD (si lsolve=1 échoue encore)",
      "sec3.resumeThermoLsolveDgelsHint":
        "DGELS/SVD détecté dans le journal. Suggestion : lsolve=1 + ΔT=100 K (laisser le défaut profil au premier lancement).",
      "sec3.resumeThermoQhaAdvancedTitle": "Options QHA avancées (ajustement anharmonique)",
      "sec3.resumeThermoDeltatLabel": "Pas de température ΔT (K)",
      "sec3.resumeThermoDeltatDefault": "Défaut profil (50 K)",
      "sec3.resumeThermoDeltatProfile": "Défaut profil ({deltat} K)",
      "sec3.resumeThermoDeltatOption": "{deltat} K",
      "sec3.resumeThermoDeltatHint": "ΔT plus grand → moins de points T → ajustement mieux conditionné après DGELS.",
      "sec3.resumeThermoModeLabel": "Entrée thermodynamique",
      "sec3.resumeThermoModeDos": "DOS phonons (ltherm_dos) — défaut",
      "sec3.resumeThermoModeFreq": "Fréquences phonons (ltherm_freq) — si l'ajustement DOS échoue encore",
      "sec3.resumeThermoModeHint": "Le mode fréquences peut recalculer output_therm.dat.g* par géométrie (sans refaire EOS/phonons).",
      "sec3.resumeThermoP3Hint": "P3 — elastic_constants_geo : même boucle QHA que P2, puis C_ij(V₀,T) sur la grille T.",
      "sec3.resumeThermoP4Hint": "P4 — ph_life : défaut = fréquences (pas DOS). Ne passez en DOS que si vous savez pourquoi.",
      "sec3.resumeThermoAlreadyRunning":
        "Un calcul est déjà en cours. Ne recliquez pas sur Reprendre — rechargez la page (Ctrl+F5) pour rattacher le suivi live.",
      "sec3.resumeFullGuideTitle": "Reprise complète de la chaîne",
      "sec3.resumeFullGuideIntro":
        "Relance le pipeline dans le même dossier. Les sous-étapes marquées DONE dans workflow_state.json sont sautées.",
      "sec3.resumeFullGuideWarn":
        "Si l'échec concerne seulement thermo_pw, préférez « Reprendre thermo_pw » (carte bleue).",
      "sec3.resumeFullGuideConfirm": "Continuer avec la reprise complète",
      "sec3.idle": "En attente — complétez les sections ① et ②",
      "sec3.progress": "En attente…",
      "sec3.doneBanner": "CALCULS TERMINÉS",
      "sec3.goResults": "Voir les résultats",
      "sec3.liveLog": "Journal live",
      "wf.step1": "Matériau",
      "wf.step2": "thermo_pw.in",
      "wf.step3": "Lancer",
      "wf.step4": "Résultats",
      "wf.aria": "Étapes du workflow",
      "sec4.runPlaceholderAlt": "— Charger un autre calcul —",
      "sec4.runsCountNone": "(aucun run persisté)",
      "sec4.runsCount": "{n} run(s) persisté(s)",
      "sec4.runsUnavailable": "(liste indisponible)",
      "runsLoad.titleSelect": "Sélectionnez d'abord un run dans la liste.",
      "runsLoad.titleSame": "Ce run est déjà affiché.",
      "runsLoad.titleBusy": "Chargement…",
      "runsLoad.titleGo": "Afficher les résultats dans la section ④.",
      "resultsMeta.done": "terminé — {n} groupe(s) de résultats",
      "sec3.logIdle": "— Cliquez « Lancer la série de calculs » pour démarrer. —",
      "sec4.title": "Résultats",
      "sec4.hint": "Métriques, tracés et fichiers générés (mis à jour en direct).",
      "sec4.loadTitle": "Charger un calcul précédent",
      "sec4.loadSub":
        "Sélectionnez un dossier de résultats, puis « Afficher ce run » sans relancer de calcul.",
      "sec4.cleanup": "Nettoyer",
      "sec4.cleanupTitle": "Supprime les runs en échec et entrées orphelines",
      "sec4.refreshTitle": "Actualiser la liste des runs",
      "sec4.runLabel": "Run :",
      "sec4.runPlaceholder": "— Charger un calcul précédent —",
      "sec4.showRun": "Afficher les résultats",
      "sec4.factsheet": "Fiche technique",
      "sec4.expertiseTitle": "Analyse experte",
      "sec4.expertiseOpenFactsheet": "Ouvrir la fiche technique ↗",
      "sec4.expertiseSummaryOk": "{nOk} insight(s) valide(s) · {nWarn} avertissement(s) · {nErr} alerte(s)",
      "sec4.expertiseSummaryEmpty": "Aucune analyse experte pour ce profil.",
      "sec4.compareLabel": "Comparer avec :",
      "sec4.comparePlaceholder": "— Sélectionner un 2ᵉ run —",
      "sec4.compareBtn": "Comparer les runs",
      "sec4.compareTitle": "Compare le run affiché avec un second run persisté.",
      "sec4.compareNeedA": "Chargez d'abord un run (Afficher les résultats), puis choisissez un second run.",
      "sec4.compareNeedB": "Sélectionnez un second run à comparer.",
      "sec4.compareSame": "Choisissez un run différent pour la comparaison.",
      "sec4.compareBusy": "Comparaison en cours…",
      "sec4.compareHeadMetric": "Métrique",
      "sec4.compareHeadDelta": "Δ",
      "sec4.reparse": "Re-parser le disque",
      "sec4.reparseTitle": "Relit les fichiers de sortie (gap, Cij, EOS…) sans relancer MPI.",
      "sec4.reparseBusy": "Re-parse…",
      "sec4.reparseOk": "Re-parse OK — résultats rafraîchis depuis le disque.",
      "sec4.reparseNeedLoad": "Chargez ce run d'abord, puis re-parse.",
      "sec4.gapsTitle": "Couverture des propriétés étendues",
      "sec4.gapsHint": "Métriques ajoutées récemment vs feuille de route.",
      "sec4.gapsOk": "Disponible",
      "sec4.gapsFilled": "Rempli",
      "sec4.gapsEmpty": "Absent",
      "sec4.gapsFuture": "Prévu",
      "sec4.gapsHintRun": "État pour le run chargé (re-parser le disque pour rafraîchir).",
      "artifacts.parsedSection": "Grandeurs parsées",
      "artifacts.parsedCount": "{filled} / {total} renseignées",
      "artifacts.metricAbsent": "Absent — hors scope profil ou re-parser le disque",
      "artifacts.metricPendingRun": "En attente — calcul en cours",
      "artifacts.metricPendingQha": "En attente — grille QHA incomplète (Θ Debye, α après les 9 géométries)",
      "artifacts.metricPendingQhaProgress": "En attente — géométrie QHA {cur}/{total} (Θ Debye, α après grille complète)",
      "artifacts.metricPendingQhaPartial": "QHA partielle — re-parser le disque après fin thermo_pw",
      "artifacts.filesSection": "Fichiers sur disque",
      "artifacts.metricSource": "Source",
      "thermoSource.slater_gamma_0.5_estimate": "Estimé via Grüneisen (γ ≈ 0,5, modèle Debye)",
      "thermoSource.slater_gamma_0.5": "Estimé via Grüneisen (γ ≈ 0,5)",
      "thermoSource.gruneisen_mean": "Moyenne du paramètre de Grüneisen γ(q,ν)",
      "thermoSource.log_alpha_vs_T": "Parsé depuis le journal thermo_pw (α vs T)",
      "thermoSource.log_alpha_scalar": "Parsé depuis le journal thermo_pw (α scalaire)",
      "thermoSource.volume_table": "Depuis table V(T) (dV/dT)",
      "thermoSource.Cv_plus_TValpha2B": "Cₚ ≈ Cᵥ + T·V·α²·B @ 300 K",
      "thermoSource.Cv_plus_TValpha2B_curve": "Courbe Cₚ(T) = Cᵥ(T) + T·V·α²·B",
      "thermoSource.Cv_plus_TValpha2B_curve_alpha_vs_T": "Courbe Cₚ(T) avec α(T)",
      "thermoSource.Cv_plus_TValpha2B_curve_alpha_const": "Courbe Cₚ(T) avec α constant",
      "thermoSource.Cv_plus_TValpha2B_curve_B_vs_T": "Courbe Cₚ(T) avec B(T)",
      "thermoSource.gruneisen_alpha_vs_T": "α(T) via γ·Cv/(B·V)",
      "thermoSource.qha_out_column": "Colonne qha.out / thermo.out",
      "thermoSource.Cp_equals_Cv_no_alpha": "Cₚ = Cᵥ (α ou B manquant)",
      "cvCpChart.title": "C<sub>v</sub>(T) vs C<sub>p</sub>(T)",
      "cvCpChart.hint": "Survolez la courbe — divergence liée à l'expansion thermique à haute T",
      "cvCpChart.xLabel": "T (K)",
      "cvCpChart.yLabel": "Ry / maille / K",
      "thermoSource.lyddane_sachs_teller": "Lyddane–Sachs–Teller (LO/TO + ε∞)",
      "artifacts.noParsedYet": "Pas encore de métriques étendues parsées — attendre thermo_pw ou re-parser le disque.",
      "gaps.alpha": "Dilatation thermique α(T) — parsée ou estimée (QHA / Grüneisen)",
      "gaps.cp": "Capacité calorifique Cp @ 300 K — depuis Cv + T·V·α²·B si α connu",
      "gaps.eps0": "Permittivité statique ε₀ — Lyddane–Sachs–Teller (LO/TO + ε∞)",
      "gaps.piezo": "Tenseur piézoélectrique e_ijk — tuiles + matrice (extra P5)",
      "gaps.zstar": "Charges effectives de Born Z* — tableau live par atome (P5 / LO/TO)",
      "gaps.pressure": "Balayage explicite en pression P — pas encore dans les profils",
      "gaps.thermoelectric": "Thermoélectricité (Seebeck, ZT) — post-traitement type BoltzTraP",
      "sec4.zstarTableTitle": "Charges effectives de Born Z* (par atome)",
      "sec4.zstarColAtom": "Atome",
      "sec4.zstarColType": "Type",
      "sec4.piezoTableTitle": "Tenseur piézoélectrique e_ijk (C/m², Voigt 3×6)",
      "sec4.empty":
        "ⓘ Sélectionnez matériau + profil pour l'aperçu attendu (métriques en attente). Choisissez un run terminé dans la liste ci-dessous pour voir les vraies valeurs.",
      "sec4.previewBanner":
        "Aperçu — {name} : {metrics} métrique(s), {plots} graphique(s), {files} fichier(s) attendus.",
      "sec4.siblingPreview":
        "Aperçu partiel : données électroniques + phonons empruntées à un run terminé sur le même matériau.",
      "sec4.workdir": "Dossier de sortie",
      "sec4.copy": "📋 Copier",
      "sec4.copyTitle": "Copier le chemin complet",
      "sec4.sanity": "Validité scientifique",
      "bool.yes": "✓ oui",
      "bool.no": "✗ non",
      "launch.ready": "Prêt — cliquez Lancer la série",
      "launch.missing": "En attente — sélectionnez :",
      "launch.running": "Lancement…",
      "launch.done": "Terminé — voir section ④",
      "launch.cancelled": "Annulé",
      "launch.resuming": "Reprise — calcul en cours",
      "mat.none": "— Aucun matériau disponible —",
      "ug.title": "📖 Guide d'utilisation",
      "ug.intro":
        "Chaque profil orchestre une <b>chaîne Quantum ESPRESSO + thermo_pw</b> différente. " +
        "Les 5 profils couvrent : mécanique 0 K, thermique QHA, étude complète, durées de vie phonons et diélectrique.",
      "ug.workflowTitle": "Workflow en 4 étapes",
      "ug.inputs": "Entrées requises",
      "ug.chain": "Chaîne de calculs",
      "ug.files": "Fichiers générés & métriques",
      "ug.prereq": "Prérequis & limites",
      "p5.legend": "Propriétés <code>thermo_pw.x</code> étendues (P5)",
      "p5.hint": "Sous-runs <code>thermo_pw.x</code> supplémentaires après <code>what='dielectric'</code>. Chaque option ajoute son journal. Un échec n'arrête pas la série.",
      "p5.optical": "Chaîne optique ε(ω) complète <span class=\"muted\">(epsilon.x + turbo_* — pseudos NC, coût élevé)</span>",
      "p1.legend": "Preset P1 « Complet »",
      "p1.hint": "Chaîne P1 complète : <code>ichamp=3</code> ajoute NSCF + dos.x + bands.x après les constantes élastiques. Chaîne phonons incluse.",
      "p1.preset": "Constantes élastiques + DOS + Bandes <span class=\"muted\">(preset P1, ichamp=3)</span>",
      "p1.loto": "Correction LO/TO au point Γ <span class=\"muted\">(sub-run dielectric → BORN → matdyn non_analytic — pseudos NC)</span>",
      "sec2.waitProfileOnly": "ⓘ Sélectionnez d'abord un profil (tuile ci-dessus) puis un matériau.",
      "artifacts.title": "📦 Artefacts produits",
      "artifacts.hint": "Fichiers du dossier run (PNG, PDF, DAT, IN, OUT…). Aperçu ou ouverture dans un nouvel onglet.",
      "artifacts.view": "👁 Voir",
      "artifacts.open": "↗ Ouvrir",
      "artifacts.count": "({shown} affichés sur {total})",
      "tpwin.waitMat": "ⓘ Profil <b>{pid}</b> sélectionné. Choisissez un matériau à l'étape ①.",
      "tpwin.generating": "⏳ génération de l'aperçu pour <b>{pid}</b> / <b>{mid}</b> / nproc={nproc}…",
      "tpwin.identity": "<b>{pid} · {pname}</b><span class=\"muted\"> · what=<code>{what}</code> · matériau=<code>{mid}</code> · nproc={nproc}</span>",
      "tpwin.materialRequired": "— matériau requis pour finaliser l'aperçu —",
      // Estimation de durée (août 2026)
      "eta.tileTooltip":
        "Fourchette estimée : {range} à nproc={nproc} · confiance : {confidence} · " +
        "étape dominante : {dominant}. P2–P4 incluent la boucle QHA (~9 chaînes phonon). " +
        "Affinée en direct pendant le run (barre de progression).",
      "eta.conf.bonne": "bonne",
      "eta.conf.moyenne": "moyenne",
      "eta.conf.faible": "faible",
      "eta.liveMeasured": "≈ {remaining} restantes{extra} (mesuré sur ce run)",
      "eta.liveEstimated": "≈ {remaining} restantes{extra} (estimé)",
      "eta.qProgress": " · point q {done}/{total}",
      "eta.volProgress": " · volume {done}/{total}",
      "eta.geoProgress": " · géométrie QHA {done}/{total}",
      "machine.summary":
        "🖥 {cpu} — <b>{phys}</b> cœurs physiques / {log} threads · {ram} Gio RAM · " +
        "nproc conseillé = <b>{rec}</b>",
      // Espace disque (août 2026)
      "storage.tileTooltip":
        "Pic disque : {peak} pendant le calcul, dont {scratch} de scratch QE " +
        "temporaire (out_*/_ph0). Seuls {retained} de résultats méritent d'être " +
        "conservés. Espace libre disponible : {free}.",
      "storage.live": " · 💾 {total}",
      "tpwin.unavailable": "ⓘ aperçu thermo_pw.in indisponible : {msg}",
      "tpwin.empty": "(vide)",
      "apm.title": "Aperçu",
      "apm.close": "Fermer l'aperçu",
      "apm.loading": "Chargement…",
      "apm.selectFile": "Sélectionnez un fichier dans le panneau Artefacts pour l'aperçu.",
      "toast.popupBlocked": "Popup bloquée — autorisez les popups pour ce site.",
      "footer.backend": "Backend : <code>/api/pipeline/*</code> · Polling : 1,5 s",
      "footer.health": "Santé API",
      "footer.version": "Version",
      "ug.close": "Fermer le guide",
      "ug.factsheetTitle": "📋 Fiche technique téléchargeable",
      "ug.factsheetIntro":
        "Depuis la <b>section ④ « Charger un calcul précédent »</b>, le bouton <b>📋 Fiche technique</b> génère un résumé <b>complet</b> du run sélectionné :",
      "ug.factsheetLi1":
        "<b>10 sections</b> : En-tête · EOS (Birch-Murnaghan) · C_ij + VRH · Électronique · Magnétisme · Stabilité dynamique · Durées de vie (P4) · Diélectrique (P5) · Sanity-checks · Analyse experte.",
      "ug.factsheetLi2":
        "<b>Trois formats</b> : <b>HTML</b> (défaut), <b>Markdown</b>, <b>PDF</b> (WeasyPrint). L'option PDF est grisée si weasyprint est absent.",
      "ug.factsheetLi3":
        "<b>Aucun calcul MPI</b> : agrégat lecture-seule, idempotent sur tout run persisté.",
      "ug.factsheetRoute":
        "Route : <code>GET /api/pipeline/runs/&lt;job_id&gt;/factsheet?format=md|html|pdf</code>. Voir <code>backend/factsheet.py</code>.",
      "ug.reconnectTitle": "Connexion perdue en plein calcul ?",
      "ug.reconnectIntro":
        "<b>Pas d'inquiétude</b> — les calculs s'exécutent <b>côté serveur</b>. Une coupure réseau n'interrompt que l'affichage live ; la chaîne continue et persiste sur disque (<code>pipeline_api_job_state.json</code>).",
      "ug.reconnectLi1": "L'onglet peut être fermé : le calcul continue sur le serveur.",
      "ug.reconnectLi2":
        "Après <b>coupure de courant ou redémarrage PC</b> : <b>Reprise complète</b> — étapes terminées sautées.",
      "ug.reconnectLi3":
        "Crash <code>thermo_pw</code> en milieu de QHA (MKL/FFT) ? <b>Reprendre thermo_pw</b> — conserve EOS + phonons, reprend à la géométrie interrompue.",
      "ug.reconnectLi4": "Section ④ « Charger un calcul précédent » : les runs persistent sur disque.",
      "ug.workflowTagline":
        'Le bandeau « <b>5 profils · workflow 4 étapes · lancement 1 clic</b> » résume l\u2019architecture : 5 profils (P1..P5) × 4 sections numérotées <span class="ug-step-num">①②③④</span> ; chaque série démarre en un clic « Lancer la série de calculs ».',
      "ug.wfStep1Title": "Matériau &amp; <code>scf.in</code>",
      "ug.wfStep1Desc": "choisir le matériau et son fichier d'entrée DFT.",
      "ug.wfStep2Title": "<code>thermo_pw.in</code>",
      "ug.wfStep2Desc": "aperçu généré à partir du profil et du matériau.",
      "ug.wfStep3Title": "Lancer",
      "ug.wfStep3Desc":
        "un clic démarre la chaîne ; après échec : <b>Reprendre thermo_pw</b> (QHA seule) ou <b>Reprise complète</b>.",
      "ug.wfStep4Title": "Résultats",
      "ug.wfStep4Desc":
        "métriques live profil-aware, tracés et panneau Artefacts ; « Charger un calcul précédent » ; re-parse disque pour rafraîchir.",
    },
  };

  const PROFILE_UI = {
    en: {
      P1: { name: "Mechanics 0 K", description: STRINGS.en["profile.P1.desc"] || "" },
      P2: { name: "Thermal QHA", description: "" },
      P3: { name: "Full study", description: "" },
      P4: { name: "Phonon lifetimes (Anharmonicity)", description: "" },
      P5: { name: "Dielectric properties", description: "" },
    },
    fr: {
      P1: { name: "Mécanique 0 K", description: "" },
      P2: { name: "Thermique QHA", description: "" },
      P3: { name: "Étude complète", description: "" },
      P4: { name: "Durées de vie phonons (Anharmonicité)", description: "" },
      P5: { name: "Propriétés diélectriques", description: "" },
    },
  };

  // Descriptions EN (FR = API backend ou steps FR natifs)
  PROFILE_UI.en.P1.description =
    "SCF V₀ → thermo_pw what='scf_elastic_constants' → C_ij → VRH moduli. " +
    "DFPT phonons (4×4×4) + NSCF/DOS/bands (ichamp=3).";
  PROFILE_UI.en.P2.description =
    "EOS 7 points ±3 % + phonons DFPT + thermo_pw what='mur_lc_t' → grandeurs thermo vs T (ΔT=50 K).";
  PROFILE_UI.en.P3.description =
    "P2 + thermo_pw what='elastic_constants_geo' → C_ij(V₀,T) et modules vs T.";
  PROFILE_UI.en.P4.description =
    "P3 + thermo_pw what='ph_life' → durées de vie τ_λ(ω) (anharmonicité 3 phonons).";
  PROFILE_UI.en.P5.description =
    "Phonons DFPT + thermo_pw what='dielectric' → ε∞, Born Z*, indice n ; ε(ω) opt-in.";

  PROFILE_UI.fr.P1.description =
    "SCF V₀ → thermo_pw what='scf_elastic_constants' → C_ij → modules VRH. " +
    "Phonons DFPT (4×4×4) + NSCF/DOS/bandes (ichamp=3).";
  PROFILE_UI.fr.P2.description =
    "Grille EOS 7 points ±3 % + phonons + thermo_pw what='mur_lc_t' → thermo vs T (ΔT=50 K).";
  PROFILE_UI.fr.P3.description =
    "P2 + thermo_pw what='elastic_constants_geo' → C_ij(V₀,T) et modules polycristallins vs T.";
  PROFILE_UI.fr.P4.description =
    "P3 + thermo_pw what='ph_life' → τ_λ(ω) par mode phonon (anharmonicité).";
  PROFILE_UI.fr.P5.description =
    "Phonons + thermo_pw what='dielectric' → ε∞, charges Born, indice n ; chaîne ε(ω) opt-in.";

  const ELECTRONIC_INSIGHTS = {
    en: {
      p5Note:
        "<b>P5</b> — opt-in optical chain (<code>epsilon.x</code> + <code>turbo_*</code>) adds " +
        "interband absorption threshold and ε(ω) spectra (requires NC pseudos).",
      sections: [
        {
          id: "I",
          title: "I. Electrical properties & charge transport",
          items: [
            { status: "available", text: "Material class: metal, semiconductor, insulator or semi-metal — <code>properties.band_gap_type</code> from <code>bands.x</code>." },
            { status: "available", text: "Band gap E_g, VBM, CBM, Fermi level — <code>properties.band_gap_eV</code>, <code>vbm_eV</code>, <code>cbm_eV</code>, <code>fermi_eV</code>." },
            { status: "available", text: "Direct vs indirect gap — <code>properties.gap_direct</code> (same k or not for VBM/CBM)." },
            { status: "partial", text: "Conduction anisotropy — inspect <code>ebands.png</code> along the k-path (Γ→X→… from <code>ibrav</code>)." },
            { status: "future", text: "Effective mass m* (band curvature) — not fitted automatically (needs post-processing)." },
            { status: "future", text: "Thermoelectric / Seebeck from DOS slope at E_F — not computed (BoltzTraP-class tool)." },
          ],
        },
        {
          id: "II",
          title: "II. Chemical bonding (PDOS)",
          items: [
            { status: "future", text: "Orbital composition of valence/conduction bands (s, p, d, f) — requires <code>projwfc.x</code> / PDOS (not in ichamp=3)." },
            { status: "future", text: "Hybridization and covalent vs ionic character — PDOS + projected bands." },
            { status: "partial", text: "Pseudogap / stability hint at E_F — qualitative from <code>edos.png</code> (total DOS only)." },
          ],
        },
        {
          id: "III",
          title: "III. Magnetic properties (spin-polarized SCF)",
          items: [
            { status: "partial", text: "Magnetic regime (FM/AFM/non-magnetic) — from <code>scf.in</code> (<code>nspin</code>) + factsheet magnetism section." },
            { status: "available", text: "Magnetic moment per atom / cell — <code>magnetism.*</code> if <code>nspin=2</code> in SCF." },
            { status: "future", text: "Half-metallicity (spin-resolved metallicity) — needs spin-polarized bands (not default ichamp=3)." },
          ],
        },
        {
          id: "IV",
          title: "IV. Optical & spectroscopic",
          items: [
            { status: "partial", text: "Optical absorption threshold & peaks — P5 opt-in TDDFPT chain (<code>epsilon.x</code>, <code>turbo_lanczos/davidson</code>)." },
            { status: "partial", text: "Static ε∞ and Born charges — P5 <code>what='dielectric'</code> (DFPT)." },
            { status: "future", text: "Direct comparison with UPS/XPS/XAS — not automated." },
          ],
        },
        {
          id: "V",
          title: "V. Electronic thermodynamics",
          items: [
            { status: "partial", text: "DOS at Fermi N(E_F) — visible on <code>edos.png</code>; numeric export not parsed yet." },
            { status: "partial", text: "Pauli paramagnetism / electronic heat capacity scale with N(E_F) — qualitative for metals." },
          ],
        },
      ],
    },
    fr: {
      p5Note:
        "<b>P5</b> — la chaîne optique opt-in (<code>epsilon.x</code> + <code>turbo_*</code>) ajoute le " +
        "seuil d'absorption interbandes et les spectres ε(ω) (pseudos NC requis).",
      sections: [
        {
          id: "I",
          title: "I. Propriétés électriques et transport de charge",
          items: [
            { status: "available", text: "Nature du matériau : métal, semi-conducteur, isolant ou semi-métal — <code>properties.band_gap_type</code> (<code>bands.x</code>)." },
            { status: "available", text: "Gap E_g, VBM, CBM, niveau de Fermi — <code>band_gap_eV</code>, <code>vbm_eV</code>, <code>cbm_eV</code>, <code>fermi_eV</code>." },
            { status: "available", text: "Gap direct ou indirect — <code>properties.gap_direct</code> (VBM et CBM au même k ou non)." },
            { status: "partial", text: "Anisotropie de conduction — lecture de <code>ebands.png</code> le long du chemin k (Γ→X→… selon <code>ibrav</code>)." },
            { status: "future", text: "Masse effective m* (courbure des bandes) — non extraite automatiquement." },
            { status: "future", text: "Thermoélectricité / Seebeck via pente de la DOS à E_F — non calculé (outil type BoltzTraP)." },
          ],
        },
        {
          id: "II",
          title: "II. Nature chimique et liaisons (PDOS)",
          items: [
            { status: "future", text: "Composition orbitale des bandes (s, p, d, f) — nécessite <code>projwfc.x</code> / PDOS (hors ichamp=3)." },
            { status: "future", text: "Hybridation et caractère covalent vs ionique — PDOS + bandes projetées." },
            { status: "partial", text: "Pseudogap / stabilité chimique à E_F — qualitatif via <code>edos.png</code> (DOS totale seulement)." },
          ],
        },
        {
          id: "III",
          title: "III. Propriétés magnétiques (SCF polarisé en spin)",
          items: [
            { status: "partial", text: "Type de couplage (FM/AFM/non magnétique) — <code>scf.in</code> (<code>nspin</code>) + fiche technique magnétisme." },
            { status: "available", text: "Moment magnétique par atome / maille — <code>magnetism.*</code> si <code>nspin=2</code> dans le SCF." },
            { status: "future", text: "Demi-métallicité (spin ↑ métal, spin ↓ isolant) — bandes résolues en spin non calculées par défaut." },
          ],
        },
        {
          id: "IV",
          title: "IV. Propriétés optiques et spectroscopiques",
          items: [
            { status: "partial", text: "Seuil et pics d'absorption optique — chaîne TDDFPT opt-in P5 (<code>epsilon.x</code>, <code>turbo_lanczos/davidson</code>)." },
            { status: "partial", text: "ε∞ statique et charges de Born — P5 <code>what='dielectric'</code> (DFPT)." },
            { status: "future", text: "Corrélation UPS/XPS/XAS expérimentales — non automatisée." },
          ],
        },
        {
          id: "V",
          title: "V. Thermodynamique électronique",
          items: [
            { status: "partial", text: "Densité d'états au niveau de Fermi N(E_F) — visible sur <code>edos.png</code> ; valeur numérique non exportée." },
            { status: "partial", text: "Susceptibilité paramagnétique de Pauli / capacité calorifique électronique ∝ N(E_F) — qualitatif pour les métaux." },
          ],
        },
      ],
    },
  };

  const ELECTRONIC_OUTPUTS_EXTRA = {
    fr: [
      "Métriques live (section ④) : E_Fermi, VBM, CBM, E_g, type de gap, direct/indirect, n_bands",
      "bands.dat / bands.dat.gnu — données brutes bands.x (chemin k selon ibrav)",
    ],
    en: [
      "Live metrics (section ④): E_Fermi, VBM, CBM, E_g, gap type, direct/indirect, n_bands",
      "bands.dat / bands.dat.gnu — raw bands.x output (k-path from ibrav)",
    ],
  };

  const COMMON_INPUTS = {
    fr: ["scf.in (géométrie d'équilibre DFT)", "nproc (MPI, défaut 4)"],
    en: ["scf.in (equilibrium DFT geometry)", "nproc (MPI, default 4)"],
  };

  const PROFILE_GUIDE = {
    fr: {
      P1: {
        steps: [
          "SCF sur géométrie d'équilibre",
          "ph.x → q2r.x → matdyn.x (grille 4×4×4, dispersions + DOS phononique)",
          "thermo_pw.x what='scf_elastic_constants' (déformations de Voigt finies, T=0 K)",
          "Parse C_ij et modules élastiques",
          "NSCF + dos.x + bands.x (ichamp=3 — E_Fermi, gap, bandes E(k))",
          "Analyse stabilité dynamique (fréquences imaginaires)",
          "OPT-IN lo_to : sub-run dielectric → BORN → matdyn non_analytic → split LO/TO à Γ",
        ],
        outputs: [
          "output_el_cons.dat — matrice C_ij (kbar)",
          "thermo_pw_run.out — journal thermo_pw",
          "phonon_bands.png / phonon_dos.png — dispersions et DOS phononique",
          "ebands.png / edos.png — structure électronique (ichamp=3)",
          "BORN — ε∞ + charges Z* (matdyn non_analytic)",
          "dielectric.lo_to_splitting_cm-1 — splitting LO–TO à Γ (opt-in)",
        ],
      },
      P2: {
        steps: [
          "Grille EOS (n_points, ±m%)",
          "SCF par volume → fit Birch–Murnaghan",
          "SCF @ V₀",
          "ph.x → q2r.x → matdyn.x (grille 4×4×4)",
          "Analyse stabilité dynamique",
          "thermo_pw.x what='mur_lc_t' (Tmin/Tmax/ΔT=50 K, ltherm_dos=.TRUE.)",
          "NSCF + dos.x + bands.x (ichamp=3)",
          "gnuplot E(V) et courbes T vs Cv/Debye",
        ],
        outputs: [
          "thermo_pw_run.out — journal QHA",
          "1_eos_volumes/eos_ev.png — courbe E(V)",
          "V₀, B₀, B′, E₀ — fit Birch–Murnaghan (eos.*)",
          "Θ Debye, ZPE, Cᵥ(T=300 K), F(T=300 K) — thermodynamique QHA",
          "plots.thermo_cv — F, S, Cᵥ vs T",
          "phonon_bands.png / phonon_dos.png",
          "ebands.png / edos.png — structure électronique",
        ],
      },
      P3: {
        steps: [
          "Idem P2 (EOS + phonons DFPT + stabilité dynamique)",
          "thermo_pw.x what='elastic_constants_geo' + use_free_energy + elastic_algorithm='energy'",
          "Parse C_ij(V,T), modules polycristallins, anisotropie Zener",
          "NSCF + dos.x + bands.x (ichamp=3)",
        ],
        outputs: [
          "elastic_constants_vs_T.dat — C_ij vs T",
          "thermo_pw_run.out — journal thermo_pw",
          "1_eos_volumes/eos_ev.png — courbe E(V)",
          "plots.elastic_vs_T — C_ij(T) et modules VRH vs T",
          "V₀, B₀, B′ + thermo QHA (idem P2)",
          "phonon_bands.png / phonon_dos.png",
          "ebands.png / edos.png",
        ],
      },
      P4: {
        steps: [
          "input_editor.reinforce_params('strict') sur scf.in / ph.in",
          "Pseudos NC high-stringency (sélection auto si disponibles)",
          "Idem P3 (EOS + phonons DFPT + stabilité dynamique)",
          "thermo_pw.x what='ph_life' → τ_λ(ω) par mode + κ_lattice(T)",
          "NSCF + dos.x + bands.x (ichamp=3)",
          "Parse : τ_λ(ω), κ_lattice(T), élargissements Γ(T)",
        ],
        outputs: [
          "thermo_pw_run.out — journal ph_life (τ_λ, Γ_λ, κ_lattice)",
          "1_eos_volumes/eos_ev.png — courbe E(V)",
          "τ_λ(ω), γ(ω), κ_lattice(T), Grüneisen — ph_life.*",
          "plots.phonon_lifetime / phonon_linewidth / kappa_lattice",
          "EOS + thermo QHA + C_ij(T) (idem P3)",
          "phonon_bands.png / phonon_dos.png",
          "ebands.png / edos.png",
        ],
      },
      P5: {
        inputs: [
          ...COMMON_INPUTS.fr,
          "(optionnel) cases à cocher panneau ② thermo_pw.in",
          "(optionnel) extra_whats P5 (plot_bz, piézoélectrique, …)",
        ],
        steps: [
          "SCF @ V₀ (pas de grille EOS)",
          "ph.x → q2r.x → matdyn.x (grille 4×4×4, fildyn pour dielectric)",
          "Analyse stabilité dynamique",
          "thermo_pw.x what='dielectric' → ε∞, Born Z*, indice n",
          "NSCF + dos.x + bands.x (ichamp=3)",
          "(opt-in) epsilon.x + turbo_lanczos.x + turbo_davidson.x pour ε(ω)",
          "(opt-in) extra_whats thermo_pw (plot_bz, piézoélectrique, …)",
        ],
        outputs: [
          "thermo_pw_run.out — journal dielectric (ε∞, Born Z*)",
          "phonon_bands.png / phonon_dos.png",
          "ebands.png / edos.png",
          "epsilon.out / turbo_*.out — ε(ω) si chaîne optique activée",
        ],
      },
    },
    en: {
      P1: {
        steps: [
          "SCF on equilibrium geometry",
          "ph.x → q2r.x → matdyn.x (4×4×4 grid, dispersions + phonon DOS)",
          "thermo_pw.x what='scf_elastic_constants' (finite Voigt strains, T=0 K)",
          "Parse C_ij and elastic moduli",
          "NSCF + dos.x + bands.x (ichamp=3 — E_Fermi, gap, E(k) bands)",
          "Dynamic stability analysis (imaginary frequencies)",
          "OPT-IN lo_to: dielectric sub-run → BORN → matdyn non_analytic → LO/TO split at Γ",
        ],
        outputs: [
          "output_el_cons.dat — C_ij matrix (kbar)",
          "thermo_pw_run.out — thermo_pw log",
          "phonon_bands.png / phonon_dos.png — phonon dispersions & DOS",
          "ebands.png / edos.png — electronic structure (ichamp=3)",
          "BORN — ε∞ + Born Z* (matdyn non_analytic)",
          "dielectric.lo_to_splitting_cm-1 — LO–TO split at Γ (opt-in)",
        ],
      },
      P2: {
        steps: [
          "EOS grid (n_points, ±m%)",
          "SCF per volume → Birch–Murnaghan fit",
          "SCF @ V₀",
          "ph.x → q2r.x → matdyn.x (4×4×4 grid)",
          "Dynamic stability analysis",
          "thermo_pw.x what='mur_lc_t' (Tmin/Tmax/ΔT=50 K, ltherm_dos=.TRUE.)",
          "NSCF + dos.x + bands.x (ichamp=3)",
          "gnuplot E(V) and T vs Cv/Debye curves",
        ],
        outputs: [
          "thermo_pw_run.out — QHA log",
          "1_eos_volumes/eos_ev.png — E(V) curve",
          "V₀, B₀, B′, E₀ — Birch–Murnaghan fit (eos.*)",
          "Θ Debye, ZPE, Cᵥ(T=300 K), F(T=300 K) — QHA thermodynamics",
          "plots.thermo_cv — F, S, Cᵥ vs T",
          "phonon_bands.png / phonon_dos.png",
          "ebands.png / edos.png — electronic structure",
        ],
      },
      P3: {
        steps: [
          "Same as P2 (EOS + DFPT phonons + dynamic stability)",
          "thermo_pw.x what='elastic_constants_geo' + use_free_energy + elastic_algorithm='energy'",
          "Parse C_ij(V,T), polycrystalline moduli, Zener anisotropy",
          "NSCF + dos.x + bands.x (ichamp=3)",
        ],
        outputs: [
          "elastic_constants_vs_T.dat — C_ij vs T",
          "thermo_pw_run.out — thermo_pw log",
          "1_eos_volumes/eos_ev.png — E(V) curve",
          "plots.elastic_vs_T — C_ij(T) and VRH moduli vs T",
          "V₀, B₀, B′ + QHA thermo (same as P2)",
          "phonon_bands.png / phonon_dos.png",
          "ebands.png / edos.png",
        ],
      },
      P4: {
        steps: [
          "input_editor.reinforce_params('strict') on scf.in / ph.in",
          "NC pseudos high-stringency (auto-select if available)",
          "Same as P3 (EOS + DFPT phonons + dynamic stability)",
          "thermo_pw.x what='ph_life' → τ_λ(ω) per mode + κ_lattice(T)",
          "NSCF + dos.x + bands.x (ichamp=3)",
          "Parse: τ_λ(ω), κ_lattice(T), linewidths Γ(T)",
        ],
        outputs: [
          "thermo_pw_run.out — ph_life log (τ_λ, Γ_λ, κ_lattice)",
          "1_eos_volumes/eos_ev.png — E(V) curve",
          "τ_λ(ω), γ(ω), κ_lattice(T), Grüneisen — ph_life.*",
          "plots.phonon_lifetime / phonon_linewidth / kappa_lattice",
          "EOS + QHA + C_ij(T) (same as P3)",
          "phonon_bands.png / phonon_dos.png",
          "ebands.png / edos.png",
        ],
      },
      P5: {
        inputs: [
          ...COMMON_INPUTS.en,
          "(optional) checkboxes in section ② thermo_pw.in",
          "(optional) P5 extra_whats (plot_bz, piezoelectric, …)",
        ],
        steps: [
          "SCF @ V₀ (no EOS grid)",
          "ph.x → q2r.x → matdyn.x (4×4×4 grid, fildyn for dielectric)",
          "Dynamic stability analysis",
          "thermo_pw.x what='dielectric' → ε∞, Born Z*, refractive index n",
          "NSCF + dos.x + bands.x (ichamp=3)",
          "(opt-in) epsilon.x + turbo_lanczos.x + turbo_davidson.x for ε(ω)",
          "(opt-in) thermo_pw extra_whats (plot_bz, piezoelectric, …)",
        ],
        outputs: [
          "thermo_pw_run.out — dielectric log (ε∞, Born Z*)",
          "phonon_bands.png / phonon_dos.png",
          "ebands.png / edos.png",
          "epsilon.out / turbo_*.out — ε(ω) if optical chain enabled",
        ],
      },
    },
  };

  // Default inputs for P1–P4
  for (const pid of ["P1", "P2", "P3", "P4"]) {
    PROFILE_GUIDE.fr[pid].inputs = COMMON_INPUTS.fr.slice();
    PROFILE_GUIDE.en[pid].inputs = COMMON_INPUTS.en.slice();
  }

  const PREREQ = {
    fr: {
      P1: [
        "SCF doit converger (conv_thr ≤ 1e-8 Ry recommandé).",
        "Phonons DFPT doivent converger (grille q 4×4×4).",
        "**Si lo_to opt-in** : pseudos Norm-Conserving OBLIGATOIRES (epsilon.x et matdyn non_analytic refusent US-PP / PAW).",
      ],
      P2: [
        "Phonons DFPT doivent converger (forces < 1e-8 Ry/bohr).",
        "Grille EOS 7 points ±3 % recommandée pour QHA fiable.",
      ],
      P3: [
        "QHA (P2) doit converger avant C_ij(T).",
        "Coût élevé : 6 déformations × n_T points sur la grille QHA.",
      ],
      P4: [
        "Conv_thr ≤ 1.0d-12 dans &ELECTRONS de scf.in (pas dans thermo_control).",
        "Pseudos norm-conservés recommandés (constantes de force précises).",
        "Phonons DFPT convergés (grille q 4×4×4 minimum).",
      ],
      P5: [
        "Phonons DFPT convergents (fildyn requis pour dielectric).",
        "Pseudos norm-conservés requis pour ε∞ précis (NC).",
        "Chaîne ε(ω) opt-in : turbo_lanczos.x + turbo_davidson.x compilés.",
      ],
    },
    en: {
      P1: [
        "SCF must converge (conv_thr ≤ 1e-8 Ry recommended).",
        "DFPT phonons must converge (4×4×4 q-grid).",
        "**If lo_to opt-in** : Norm-Conserving pseudos REQUIRED (epsilon.x and matdyn non_analytic reject US-PP / PAW).",
      ],
      P2: [
        "DFPT phonons must converge (forces < 1e-8 Ry/bohr).",
        "7-point EOS grid ±3 % recommended for reliable QHA.",
      ],
      P3: [
        "QHA (P2) must converge before C_ij(T).",
        "High cost: 6 deformations × n_T points on the QHA grid.",
      ],
      P4: [
        "Conv_thr ≤ 1.0d-12 in &ELECTRONS of scf.in (not in thermo_control).",
        "Norm-conserving pseudos recommended (accurate force constants).",
        "Converged DFPT phonons (4×4×4 q-grid minimum).",
      ],
      P5: [
        "Converged DFPT phonons (fildyn required for dielectric).",
        "Norm-conserving pseudos required for accurate ε∞ (NC).",
        "Opt-in ε(ω) chain: turbo_lanczos.x + turbo_davidson.x must be built.",
      ],
    },
  };
  for (const lg of ["fr", "en"]) {
    for (const pid of ["P1", "P2", "P3", "P4", "P5"]) {
      PROFILE_GUIDE[lg][pid].prerequisites = PREREQ[lg][pid].slice();
      PROFILE_GUIDE[lg][pid].outputs = PROFILE_GUIDE[lg][pid].outputs.concat(
        ELECTRONIC_OUTPUTS_EXTRA[lg]
      );
    }
  }

  const UI_BINDINGS = [
    { sel: ".subtitle", key: "header.subtitle" },
    { sel: "#navHome", key: "nav.home" },
    { sel: "#navWorkspace", key: "nav.workspace" },
    { sel: "#openUsageGuideBtn .ug-label", key: "header.usageGuide" },
    { sel: "#openUsageGuideBtn", key: "header.usageGuideTitle", prop: "title" },
    { sel: ".home-kicker", key: "home.kicker" },
    { sel: "#homeTitle", key: "home.title" },
    { sel: ".home-lead", key: "home.lead", prop: "html" },
    { sel: "#homeStartBtn .btn-label", key: "home.start" },
    { sel: "#sectionMat .section-head h2", key: "sec1.title", prop: "html" },
    { sel: "#sectionMat .hint", key: "sec1.hint", prop: "html" },
    { sel: "label[for='matSelect']", key: "sec1.material" },
    { sel: "label[for='scfIn']", key: "sec1.scf" },
    { sel: "label[for='nproc']", key: "sec1.nproc" },
    { sel: "#matInfo .kv:nth-child(1) span", key: "sec1.files", prop: "html" },
    { sel: "#matInfo .kv:nth-child(2) span", key: "sec1.path" },
    { sel: "#scfPreviewBox summary", key: "sec1.previewScf", prop: "html" },
    { sel: "#sectionTpwin .section-head h2", key: "sec2.title", prop: "html" },
    { sel: "#sectionTpwin .section-head .hint", key: "sec2.hint", prop: "html" },
    { sel: "#tpwinPreviewBox summary", key: "sec2.previewTpwin", prop: "html" },
    { sel: "#tpwinParams thead th:nth-child(1)", key: "sec2.directive" },
    { sel: "#tpwinParams thead th:nth-child(2)", key: "sec2.value" },
    { sel: "#sectionLaunch .section-head h2", key: "sec3.title" },
    { sel: "#sectionLaunch .section-head .hint", key: "sec3.hint" },
    { sel: "#launchBtn .btn-label", key: "sec3.launch" },
    { sel: "#cancelBtn", key: "sec3.cancel", prop: "textContent" },
    { sel: "#cancelBtn", key: "sec3.cancelTitle", prop: "title" },
    { sel: "#restartBtn .tpw-resume-card-title", key: "sec3.resume", prop: "textContent" },
    { sel: "#restartBtn .tpw-resume-card-desc", key: "sec3.resumeFullCardDesc", prop: "textContent" },
    { sel: "#restartBtn", key: "sec3.resumeTitle", prop: "title" },
    { sel: "#resumeThermoBtn .tpw-resume-card-title", key: "sec3.resumeThermoPw", prop: "textContent" },
    { sel: "#resumeThermoBtn .tpw-resume-card-desc", key: "sec3.resumeThermoCardDesc", prop: "textContent" },
    { sel: "#resumeThermoBtn .tpw-resume-card-badge", key: "sec3.resumeRecommended", prop: "textContent" },
    { sel: "#resumeThermoBtn", key: "sec3.resumeThermoPwTitle", prop: "title" },
    { sel: ".tpw-resume-group-title", key: "sec3.resumeGroupTitle", prop: "textContent" },
    { sel: ".tpw-resume-group-hint", key: "sec3.resumeGroupHint", prop: "textContent" },
    { sel: "#doneBanner .done-banner-text", key: "sec3.doneBanner" },
    { sel: "#goResultsBtn .btn-go-results-label", key: "sec3.goResults" },
    { sel: "#workflowStepper", key: "wf.aria", prop: "aria-label" },
    { sel: ".wf-step[data-step='1'] .wf-label", key: "wf.step1" },
    { sel: ".wf-step[data-step='2'] .wf-label", key: "wf.step2" },
    { sel: ".wf-step[data-step='3'] .wf-label", key: "wf.step3" },
    { sel: ".wf-step[data-step='4'] .wf-label", key: "wf.step4" },
    { sel: "#sectionLaunch h3", key: "sec3.liveLog" },
    { sel: "#resultsTitle", key: "sec4.title" },
    { sel: "#resultsCard .section-head .hint", key: "sec4.hint" },
    { sel: ".rp-title", key: "sec4.loadTitle" },
    { sel: ".rp-sub", key: "sec4.loadSub" },
    { sel: ".rp-ps-label", key: "sec4.cleanup" },
    { sel: "#runsPurgeStale", key: "sec4.cleanupTitle", prop: "title" },
    { sel: "#runsRefresh", key: "sec4.refreshTitle", prop: "title" },
    { sel: ".rp-select-label", key: "sec4.runLabel" },
    { sel: ".rp-load-label", key: "sec4.showRun" },
    { sel: ".rp-fs-label", key: "sec4.factsheet" },
    { sel: ".re-title", key: "sec4.expertiseTitle" },
    { sel: "#expertiseFactsheetBtn", key: "sec4.expertiseOpenFactsheet" },
    { sel: ".rp-compare-label", key: "sec4.compareLabel" },
    { sel: "#runsCompareBtn", key: "sec4.compareBtn", prop: "textContent" },
    { sel: "#runsReparse", key: "sec4.reparse", prop: "textContent" },
    { sel: "#resultEmpty", key: "sec4.empty" },
    { sel: ".rw-title", key: "sec4.workdir" },
    { sel: "#resultWorkdirCopy", key: "sec4.copy", prop: "textContent" },
    { sel: "#resultWorkdirCopy", key: "sec4.copyTitle", prop: "title" },
    { sel: ".sanity-title", key: "sec4.sanity" },
    { sel: "#usageGuideTitle", key: "ug.title", prop: "html" },
    { sel: ".ug-intro", key: "ug.intro", prop: "html" },
    { sel: "#closeUsageGuideBtn", key: "ug.close", prop: "aria-label" },
    { sel: "#p5ExtrasPanel legend .legend-label", key: "p5.legend", prop: "html" },
    { sel: "#p5ExtrasPanel .p5-extras-hint", key: "p5.hint", prop: "html" },
    { sel: "#p5OpticalCheckbox + .p1-preset-label", key: "p5.optical", prop: "html" },
    { sel: "#p1PresetPanel legend .legend-label", key: "p1.legend" },
    { sel: "#p1PresetPanel .p1-preset-hint", key: "p1.hint", prop: "html" },
    { sel: "#p1PresetCheckbox + .p1-preset-label", key: "p1.preset", prop: "html" },
    { sel: "#loToCheckbox + .p1-preset-label", key: "p1.loto", prop: "html" },
    { sel: "#artifactsPanel .ap-title", key: "artifacts.title", prop: "html" },
    { sel: "#artifactsPanel .ap-hint", key: "artifacts.hint", prop: "html" },
    { sel: "footer span:first-child", key: "footer.backend", prop: "html" },
    { sel: "footer a[href='/api/health']", key: "footer.health" },
    { sel: "footer a[href='/api/version']", key: "footer.version" },
    { sel: "#apmCloseBtn", key: "apm.close", prop: "aria-label" },
    { sel: "#apmTitle", key: "apm.title" },
    { sel: "#apmBody .muted", key: "apm.selectFile" },
  ];

  function t(key, lang, vars) {
    const lg = lang || _lang;
    const bucket = STRINGS[lg] || STRINGS.en;
    let s;
    if (bucket[key] !== undefined) s = bucket[key];
    else s = (STRINGS.en[key] !== undefined ? STRINGS.en[key] : key);
    if (vars && typeof vars === "object") {
      for (const [k, v] of Object.entries(vars)) {
        s = s.replace(new RegExp("\\{" + k + "\\}", "g"), String(v));
      }
    }
    return s;
  }

  function tf(key, vars, lang) {
    return t(key, lang, vars);
  }

  function getLang() {
    return _lang;
  }

  function setLang(lang, opts) {
    const next = lang === "en" ? "en" : "fr";
    _lang = next;
    if (!(opts && opts.skipStorage)) {
      try { localStorage.setItem(LANG_KEY, next); } catch (_e) { /* ignore */ }
    }
    document.documentElement.lang = next;
    document.title = t("header.title", next);
    applyStaticUI(next);
    updateLangSwitchUI(next);
    return next;
  }

  function loadStoredLang() {
    try {
      const v = localStorage.getItem(LANG_KEY);
      if (v === "en" || v === "fr") return v;
    } catch (_e) { /* ignore */ }
    return "fr";
  }

  function applyStaticUI(lang) {
    const lg = lang || _lang;
    for (const b of UI_BINDINGS) {
      const el = document.querySelector(b.sel);
      if (!el) continue;
      const val = t(b.key, lg);
      const prop = b.prop || "textContent";
      if (prop === "html") el.innerHTML = val;
      else el[prop] = val;
    }
    const runOpt = document.querySelector("#runsSelect option[value='']");
    if (runOpt) runOpt.textContent = t("sec4.runPlaceholder", lg);
    const langSwitch = document.querySelector(".lang-switch");
    if (langSwitch) langSwitch.setAttribute("aria-label", t("lang.switchAria", lg));
    const themeSwitch = document.querySelector(".theme-switch");
    if (themeSwitch) themeSwitch.setAttribute("aria-label", t("theme.switchAria", lg));
    const themeDark = document.getElementById("themeDark");
    const themeLight = document.getElementById("themeLight");
    if (themeDark) themeDark.title = t("theme.darkTitle", lg);
    if (themeLight) themeLight.title = t("theme.lightTitle", lg);
  }

  function updateLangSwitchUI(lang) {
    const lg = lang || _lang;
    for (const btn of document.querySelectorAll(".lang-switch-btn")) {
      const active = btn.dataset.lang === lg;
      btn.classList.toggle("is-active", active);
      btn.setAttribute("aria-pressed", active ? "true" : "false");
    }
  }

  function localizeProfiles(rawProfiles, lang) {
    const lg = lang || _lang;
    const ui = PROFILE_UI[lg] || PROFILE_UI.en;
    const guide = PROFILE_GUIDE[lg] || PROFILE_GUIDE.en;
    return (rawProfiles || []).map((p) => {
      const loc = ui[p.id] || {};
      const g = guide[p.id] || {};
      const out = Object.assign({}, p, {
        name: loc.name || p.name,
        description: loc.description || p.description,
      });
      if (Array.isArray(g.steps) && g.steps.length) out.steps = g.steps.slice();
      if (Array.isArray(g.outputs) && g.outputs.length) out.outputs = g.outputs.slice();
      if (Array.isArray(g.inputs) && g.inputs.length) out.inputs = g.inputs.slice();
      if (Array.isArray(g.prerequisites) && g.prerequisites.length) {
        out.prerequisites = g.prerequisites.slice();
      }
      return out;
    });
  }

  function setupLangSwitch(onChange) {
    for (const btn of document.querySelectorAll(".lang-switch-btn")) {
      btn.addEventListener("click", () => {
        const lg = btn.dataset.lang;
        if (!lg || lg === _lang) return;
        setLang(lg);
        if (typeof onChange === "function") onChange(lg);
      });
    }
  }

  function getTheme() {
    return _theme;
  }

  function updateThemeSwitchUI(theme) {
    const th = theme === "light" ? "light" : "dark";
    for (const btn of document.querySelectorAll(".theme-switch-btn")) {
      const active = btn.dataset.theme === th;
      btn.classList.toggle("is-active", active);
      btn.setAttribute("aria-pressed", active ? "true" : "false");
    }
  }

  function setTheme(theme, opts) {
    const next = theme === "light" ? "light" : "dark";
    _theme = next;
    if (next === "light") {
      document.documentElement.setAttribute("data-theme", "light");
    } else {
      document.documentElement.removeAttribute("data-theme");
    }
    if (!(opts && opts.skipStorage)) {
      try { localStorage.setItem(THEME_KEY, next); } catch (_e) { /* ignore */ }
    }
    updateThemeSwitchUI(next);
    return next;
  }

  function loadStoredTheme() {
    try {
      const v = localStorage.getItem(THEME_KEY);
      if (v === "light" || v === "dark") return v;
    } catch (_e) { /* ignore */ }
    return "dark";
  }

  function setupThemeSwitch() {
    for (const btn of document.querySelectorAll(".theme-switch-btn")) {
      btn.addEventListener("click", () => {
        const th = btn.dataset.theme;
        if (!th || th === _theme) return;
        setTheme(th);
      });
    }
  }

  global.ThermoI18n = {
    t,
    tf,
    getLang,
    setLang,
    loadStoredLang,
    applyStaticUI,
    localizeProfiles,
    setupLangSwitch,
    getTheme,
    setTheme,
    loadStoredTheme,
    setupThemeSwitch,
    PROFILE_UI,
    PROFILE_GUIDE,
    ELECTRONIC_INSIGHTS,
  };
})(window);

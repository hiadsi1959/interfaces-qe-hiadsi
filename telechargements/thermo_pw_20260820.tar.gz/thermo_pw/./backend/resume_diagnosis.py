"""Diagnostic avant reprise d'un calcul interrompu.

« Reprendre » et « Relancer » sautent les étapes déjà marquées terminées. C'est
le bon comportement après une coupure de courant, et le mauvais après un défaut
de configuration : les étapes fautives sont justement celles qui portent la
marque « terminé ». Un run P2 a ainsi consommé 16 h de DFPT en calculant neuf
fois le même volume, puis a échoué sur l'ajustement QHA ; une reprise naïve
aurait réajusté les mêmes données vides.

Ce module inspecte le dossier de travail avant la reprise et répond à trois
questions : qu'est-ce qui a échoué, qu'est-ce qui reste réutilisable, et quelle
reprise a un sens. Chaque diagnostic est rattaché à une cause connue quand la
signature est reconnue, sinon il reste explicitement indéterminé — mieux vaut
avouer l'ignorance que suggérer une reprise trompeuse.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Optional

from thermo_pw_resume import logs_indicate_qha_least_squares_failure

# Sévérités, par gravité croissante pour la reprise.
BENIGN = "benign"      # la reprise est sûre et économique
BLOCKING = "blocking"  # corriger la configuration d'abord, puis reprendre
FATAL = "fatal"        # des résultats sont invalides : ils doivent être refaits

_SEVERITY_ORDER = {BENIGN: 0, BLOCKING: 1, FATAL: 2}

_LOG_TAIL_BYTES = 400_000
_MAX_DYN_FILES = 4000

_RE_DYN_GEOM = re.compile(r"^(?P<base>.+)\.g(?P<geom>\d+)\.(?P<iq>\d+)$")
_RE_OUTDIR_IN_NAMELIST = re.compile(r"(?mi)^[ \t]*outdir[ \t]*=")
_RE_INPUTPH = re.compile(r"(?mi)^\s*&inputph\b")


@dataclass
class RecoveryAction:
    """Une reprise possible, avec son coût et ce qu'elle préserve."""

    action_id: str
    label: str
    detail: str
    # "resume" : reprendre en sautant les étapes terminées.
    # "fix_then_restart" : corriger la configuration puis refaire l'étape.
    # "fresh" : repartir d'un dossier neuf.
    kind: str
    recommended: bool = False
    destroys_results: bool = False
    cost_hint: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "action_id": self.action_id,
            "label": self.label,
            "detail": self.detail,
            "kind": self.kind,
            "recommended": self.recommended,
            "destroys_results": self.destroys_results,
            "cost_hint": self.cost_hint,
        }


@dataclass
class Finding:
    """Un problème identifié, avec son verdict sur la reprise."""

    finding_id: str
    severity: str
    title: str
    explanation: str
    evidence: list[str] = field(default_factory=list)
    known_cause: Optional[str] = None
    reusable: list[str] = field(default_factory=list)
    must_redo: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "finding_id": self.finding_id,
            "severity": self.severity,
            "title": self.title,
            "explanation": self.explanation,
            "evidence": list(self.evidence),
            "known_cause": self.known_cause,
            "reusable": list(self.reusable),
            "must_redo": list(self.must_redo),
        }


@dataclass
class ResumeDiagnosis:
    findings: list[Finding] = field(default_factory=list)
    actions: list[RecoveryAction] = field(default_factory=list)

    @property
    def severity(self) -> Optional[str]:
        if not self.findings:
            return None
        return max((f.severity for f in self.findings), key=lambda s: _SEVERITY_ORDER[s])

    @property
    def resume_is_safe(self) -> bool:
        """Vrai seulement si aucun diagnostic n'invalide de résultat ni de config."""
        return self.severity in (None, BENIGN)

    def headline(self) -> str:
        if not self.findings:
            return "Aucune anomalie connue détectée — la reprise saute les étapes terminées."
        worst = self.severity
        first = next(f for f in self.findings if f.severity == worst)
        if worst == FATAL:
            return f"Reprise déconseillée : {first.title}"
        if worst == BLOCKING:
            return f"Corriger avant de reprendre : {first.title}"
        return f"Reprise sûre : {first.title}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "severity": self.severity,
            "resume_is_safe": self.resume_is_safe,
            "headline": self.headline(),
            "findings": [f.to_dict() for f in self.findings],
            "actions": [a.to_dict() for a in self.actions],
        }


def _read_tail(path: Path, limit: int = _LOG_TAIL_BYTES) -> str:
    try:
        size = path.stat().st_size
        with path.open("rb") as fh:
            if size > limit:
                fh.seek(size - limit)
            return fh.read().decode("utf-8", errors="replace")
    except OSError:
        return ""


def _collect_logs(work_dir: Path) -> str:
    """Concatène la queue des journaux d'exécution présents."""
    chunks: list[str] = []
    for name in ("thermo_pw_run.out", "ph.out", "pw.out", "matdyn.out", "q2r.out"):
        p = work_dir / name
        if p.is_file():
            chunks.append(_read_tail(p))
    return "\n".join(chunks)


def group_dynmats_by_qpoint(work_dir: Path) -> dict[str, dict[int, Path]]:
    """Indexe ``dynamical_matrices/<base>.g<N>.<iq>`` par point q puis géométrie."""
    root = work_dir / "dynamical_matrices"
    if not root.is_dir():
        return {}
    per_q: dict[str, dict[int, Path]] = {}
    try:
        entries = sorted(root.iterdir())[:_MAX_DYN_FILES]
    except OSError:
        return {}
    for p in entries:
        if not p.is_file():
            continue
        m = _RE_DYN_GEOM.match(p.name)
        if not m:
            continue
        # ``.0`` n'est pas une matrice dynamique mais la liste des points q, en
        # unités de 2π/a. Elle est donc identique à tous les volumes par
        # construction, et la comparer garantirait un faux positif.
        if int(m.group("iq")) == 0:
            continue
        per_q.setdefault(m.group("iq"), {})[int(m.group("geom"))] = p
    return per_q


def _digest(path: Path) -> Optional[str]:
    try:
        h = hashlib.blake2b(digest_size=16)
        with path.open("rb") as fh:
            for block in iter(lambda: fh.read(262_144), b""):
                h.update(block)
        return h.hexdigest()
    except OSError:
        return None


def find_identical_dynmats(work_dir: Path) -> tuple[list[int], str]:
    """Cherche des matrices dynamiques identiques entre géométries.

    Deux géométries de volumes différents ne peuvent pas produire la même
    matrice dynamique : les fréquences dépendent du volume, c'est précisément
    ce que mesure le paramètre de Grüneisen. Une égalité octet pour octet
    signifie que la variation de volume n'a pas atteint le calcul de phonons,
    et que toute la thermodynamique anharmonique qui en découle est vide.

    Renvoie (géométries en doublon, point q témoin).
    """
    for iq, per_geom in sorted(group_dynmats_by_qpoint(work_dir).items()):
        if len(per_geom) < 2:
            continue
        by_digest: dict[str, list[int]] = {}
        for geom, path in sorted(per_geom.items()):
            d = _digest(path)
            if d is not None:
                by_digest.setdefault(d, []).append(geom)
        for geoms in by_digest.values():
            if len(geoms) > 1:
                return sorted(geoms), iq
    return [], ""


def ph_control_pins_outdir(work_dir: Path) -> bool:
    """``outdir`` dans ``ph_control`` annule la redirection par géométrie."""
    p = work_dir / "ph_control"
    if not p.is_file():
        return False
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    m = _RE_INPUTPH.search(text)
    if not m:
        return False
    return bool(_RE_OUTDIR_IN_NAMELIST.search(text[m.start():]))


def _floats(line: str) -> list[float]:
    out: list[float] = []
    for tok in line.replace("D", "E").replace("d", "e").split():
        try:
            out.append(float(tok))
        except ValueError:
            continue
    return out


# Un solide se dilate de 0,1 à 1 % entre 0 et 1000 K, soit une variation
# relative de volume d'au moins 1e-4. Ce seuil est quatre ordres de grandeur
# plus bas : il ne peut être franchi que par un minimum d'énergie libre qui ne
# bouge pas du tout. Le critère porte sur V(T) et non sur β, car un β « petit »
# reste ambigu — celui d'un run dégénéré observé atteignait 1,8e-6, soit le même
# ordre que la valeur réelle du silicium — alors qu'un V(T) constant sur dix
# chiffres significatifs ne s'explique par aucune physique.
_MIN_RELATIVE_VOLUME_SPAN = 1.0e-8


def anharmonic_output_is_degenerate(work_dir: Path) -> tuple[bool, str]:
    """Détecte un volume d'équilibre insensible à la température."""
    p = work_dir / "anhar_files" / "output_anhar.dat"
    if not p.is_file():
        return False, ""
    try:
        lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return False, ""
    volumes: list[float] = []
    betas: list[float] = []
    for ln in lines:
        if not ln.strip() or ln.lstrip().startswith("#"):
            continue
        vals = _floats(ln)
        if len(vals) >= 4:
            volumes.append(vals[1])
            betas.append(abs(vals[3]))
    if len(volumes) < 3:
        return False, ""
    mean_v = sum(volumes) / len(volumes)
    if mean_v <= 0.0:
        return False, ""
    span = (max(volumes) - min(volumes)) / mean_v
    if span >= _MIN_RELATIVE_VOLUME_SPAN:
        return False, ""
    return True, (
        f"V(T) ne varie que de {span:.1e} en relatif sur {len(volumes)} températures "
        f"(β médian {sorted(betas)[len(betas) // 2]:.1e} 1/K)"
    )


def _log_flags(logs: str) -> dict[str, bool]:
    return {
        "sigterm": "error (78): process killed (SIGTERM)" in logs,
        "dgels": logs_indicate_qha_least_squares_failure(logs),
        "eof_e_work": bool(re.search(r"error \(24\)", logs)) and "e_work_part" in logs,
        "frc_blk": "frc_blk" in logs,
    }


def diagnose_run(
    work_dir: Path | str,
    *,
    status: str = "",
    logs: Optional[str] = None,
) -> ResumeDiagnosis:
    """Inspecte un dossier de run et rend un verdict sur la reprise."""
    wd = Path(work_dir)
    diag = ResumeDiagnosis()
    if not wd.is_dir():
        return diag

    text = logs if logs is not None else _collect_logs(wd)
    flags = _log_flags(text)

    twins, iq = find_identical_dynmats(wd)
    pinned = ph_control_pins_outdir(wd)
    degenerate, degen_evidence = anharmonic_output_is_degenerate(wd)

    if twins:
        ev = [
            f"géométries {', '.join(str(g) for g in twins)} : matrices identiques "
            f"octet pour octet au point q {iq}",
        ]
        if pinned:
            ev.append("ph_control déclare « outdir », ce qui écrase le dossier par géométrie")
        diag.findings.append(Finding(
            finding_id="identical_dynmats",
            severity=FATAL,
            title="Plusieurs géométries ont produit les mêmes phonons",
            explanation=(
                "Des volumes différents doivent donner des fréquences différentes — "
                "c'est la définition même du paramètre de Grüneisen. Des matrices "
                "dynamiques identiques signifient que la variation de volume n'a pas "
                "atteint le calcul de phonons. Toute la thermodynamique anharmonique "
                "qui en dérive (α, Cp − Cv, γ) est nulle par construction."
            ),
            evidence=ev,
            known_cause="ph_control_outdir" if pinned else None,
            reusable=["Courbe E(V) : les SCF ont bien balayé les volumes"],
            must_redo=["DFPT de chaque géométrie en doublon", "Ajustement QHA"],
        ))

    if pinned and not twins:
        diag.findings.append(Finding(
            finding_id="ph_control_outdir",
            severity=BLOCKING,
            title="ph_control épingle « outdir »",
            explanation=(
                "thermo_pw redirige outdir vers <outdir>/g<N>/ avant chaque géométrie, "
                "puis lit ph_control. Un outdir explicite annule cette redirection et "
                "toutes les géométries relisent les fonctions d'onde du même volume. "
                "Le défaut est silencieux : le calcul aboutit, mais sans dépendance en "
                "volume. À corriger avant de lancer la partie phonons."
            ),
            evidence=["ph_control contient une ligne outdir dans &inputph"],
            known_cause="ph_control_outdir",
            reusable=["Tout ce qui précède la boucle de géométries"],
            must_redo=["Partie phonons multi-géométries"],
        ))

    if degenerate:
        diag.findings.append(Finding(
            finding_id="degenerate_qha",
            severity=FATAL,
            title="Dilatation thermique nulle dans les résultats QHA",
            explanation=(
                "β est au niveau du bruit numérique alors qu'un solide réel est autour "
                "de 10⁻⁵ K⁻¹. Le minimum de l'énergie libre ne se déplace pas avec la "
                "température, donc la surface F(T,V) n'a pas de dépendance en volume "
                "exploitable. Ces valeurs ne doivent pas être présentées comme résultat."
            ),
            evidence=[degen_evidence],
            known_cause="ph_control_outdir" if pinned or twins else None,
            reusable=["Courbe E(V)"],
            must_redo=["Phonons par géométrie", "Ajustement QHA"],
        ))

    if flags["dgels"] and not (twins or degenerate):
        diag.findings.append(Finding(
            finding_id="least_squares_abort",
            severity=BLOCKING,
            title="Abandon de l'ajustement aux moindres carrés",
            explanation=(
                "thermo_pw a renoncé à ajuster la surface d'énergie libre. C'est le plus "
                "souvent un signal correct plutôt qu'un incident : le système est "
                "singulier parce que les données ne portent pas l'information attendue. "
                "Vérifier la dépendance en volume des phonons avant de forcer un autre "
                "solveur, car lsolve=1 renvoie alors une solution dégénérée sans erreur."
            ),
            evidence=["DGELS / DGELSS / linsolvms / linsolvsvd dans le journal"],
            known_cause="linsolvms_dgels",
            reusable=["Phonons déjà calculés"],
            must_redo=["Ajustement QHA seulement"],
        ))

    if flags["sigterm"]:
        diag.findings.append(Finding(
            finding_id="killed_by_signal",
            severity=BENIGN,
            title="Le calcul a été tué, il n'a pas échoué",
            explanation=(
                "Le processus a reçu SIGTERM : arrêt manuel, redémarrage de la machine "
                "ou fin de session. Rien n'indique un résultat faux. Les géométries dont "
                "les matrices dynamiques sont sur le disque seront sautées à la reprise."
            ),
            evidence=["forrtl error (78): process killed (SIGTERM)"],
            known_cause="sigterm",
            reusable=["Toutes les étapes terminées"],
            must_redo=["L'étape en cours au moment de l'arrêt"],
        ))

    if flags["eof_e_work"]:
        diag.findings.append(Finding(
            finding_id="stale_restart_dir",
            severity=BLOCKING,
            title="Fichiers de reprise tronqués",
            explanation=(
                "Une fin de fichier prématurée sur e_work_part indique un dossier "
                "restart/ laissé dans un état incohérent par l'arrêt précédent. Il doit "
                "être purgé avant la reprise, sinon la même lecture échouera."
            ),
            evidence=["forrtl error (24) sur e_work_part"],
            known_cause="stale_restart",
            reusable=["Matrices dynamiques déjà écrites"],
            must_redo=["Étape interrompue, après purge de restart/"],
        ))

    diag.actions = _build_actions(diag, status=status)
    return diag


def _build_actions(diag: ResumeDiagnosis, *, status: str) -> list[RecoveryAction]:
    """Propose les reprises cohérentes avec les diagnostics."""
    sev = diag.severity
    ids = {f.finding_id for f in diag.findings}

    if sev == FATAL:
        # Pas de réparation automatique proposée : supprimer des heures de DFPT
        # sur la base d'une heuristique doit rester une décision explicite. Et
        # ici le calcul réutilisable — la grille E(V) — ne pèse que quelques
        # minutes face aux phonons, donc repartir de zéro ne coûte presque rien
        # de plus tout en garantissant un résultat juste.
        return [
            RecoveryAction(
                action_id="fresh_run",
                label="Repartir d'un dossier neuf",
                detail=(
                    "Seule option qui garantisse des résultats justes. La correction de "
                    "configuration est appliquée automatiquement au lancement. Ce qui "
                    "était réutilisable ici ne représente que quelques minutes face au "
                    "coût des phonons."
                ),
                kind="fresh",
                recommended=True,
                cost_hint="coût : la chaîne complète",
            ),
            RecoveryAction(
                action_id="resume_anyway",
                label="Reprendre quand même",
                detail=(
                    "Déconseillé : la reprise saute les étapes marquées terminées, donc "
                    "elle réutilisera précisément les données invalides et produira les "
                    "mêmes valeurs vides."
                ),
                kind="resume",
                cost_hint="coût : faible, mais résultat faux",
            ),
        ]

    if sev == BLOCKING:
        detail = "Applique la correction identifiée, puis reprend à l'étape fautive."
        if "stale_restart_dir" in ids:
            detail = "Purge restart/ puis reprend l'étape interrompue."
        elif "least_squares_abort" in ids:
            detail = (
                "Reprend le seul ajustement QHA, sans refaire les phonons. Vérifiez "
                "d'abord que les phonons varient bien avec le volume."
            )
        return [
            RecoveryAction(
                action_id="fix_then_resume",
                label="Corriger puis reprendre",
                detail=detail,
                kind="fix_then_restart",
                recommended=True,
                cost_hint="coût : l'étape fautive seulement",
            ),
            RecoveryAction(
                action_id="fresh_run",
                label="Repartir d'un dossier neuf",
                detail="Si vous préférez ne rien réutiliser.",
                kind="fresh",
                cost_hint="coût : la chaîne complète",
            ),
        ]

    return [
        RecoveryAction(
            action_id="resume",
            label="Reprendre le calcul",
            detail=(
                "Les étapes terminées sont sautées. Aucune anomalie connue ne remet en "
                "cause les résultats déjà écrits."
            ),
            kind="resume",
            recommended=True,
            cost_hint="coût : l'étape interrompue seulement",
        ),
        RecoveryAction(
            action_id="fresh_run",
            label="Repartir d'un dossier neuf",
            detail="Refait tout depuis le début.",
            kind="fresh",
            cost_hint="coût : la chaîne complète",
        ),
    ]

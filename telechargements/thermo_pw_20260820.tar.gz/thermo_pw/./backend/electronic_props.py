"""
Propriétés électroniques — étape « ichamp = 2 » (DOS) ou « ichamp = 3 » (DOS + bandes).

Orchestration pour les 5 profils (P1–P4) thermo_pw.

Modes supportés (sélection via ``properties_ichamp`` du profil) :
  * ``ichamp=2`` : ``pw.x`` NSCF → ``dos.x`` (densité d'états totale).
  * ``ichamp=3`` : ``pw.x`` NSCF → ``dos.x`` + ``pw.x`` BANDS → ``bands.x``
                   (ajoute le diagramme de bandes le long d'un chemin q dérivé
                   depuis ``ibrav`` ; défaut quand ``properties_enabled=True``).

Pré-requis matériel :
  * Le SCF d'équilibre (``scf.in`` pour P1 ou ``pw_scf_V0_for_phonon.in`` pour
    P2–P4) **doit** contenir ``wf_collect = .true.`` dans ``&CONTROL`` sans
    quoi les wf ne sont pas écrites sur disque par QE et le NSCF/BANDS
    (« restart_mode='restart' ») démarre sans fonctions d'onde.
  * L'outdir (``./out/``) doit être celui où le SCF équilibre a écrit ses
    ``<prefix>.save/`` : c'est garanti par ``pipeline._normalize_scf_paths``.

Mesures défensives côté Python :
  * ``wf_collect = .true.`` injecté à la volée sur le SCF utilisera pour la
    NSCF si absent.
  * Grille K_POINTS densifiée automatiquement (3× minimum, ≥ 12 par axe)
    pour la NSCF — sauf overrides explicites.
  * Bascule automatique ``occupations='smearing'`` → ``occupations='tetrahedra'``
    uniquement quand le système est non magnétique ET a assez de bandes
    (``nbnd``) pour le calcul.
  * Si ``bands.x`` ou ``dos.x`` n'est pas compilé/installé (``is_file()`` False),
    étape ignorée avec un ``[WARN]`` propre (pas d'erreur fatale).
  * Si ``ibrav=0`` non convertible (maille triclinique, etc.), on retombe sur
    ``ichamp=2`` (DOS seule) avec un message clair.
"""
from __future__ import annotations

import os
import re
import shutil
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import config as cfg
from qe_subprocess import (
    API_CANCEL_RUNTIME_MSG,
    run_qe,
    run_qe_stdin,
    run_pw_x_in,
    which_mpirun,
)
from phonon_chain_qe import (
    matdyn_band_qpath_for_ibrav,
    parse_ibrav_from_pw,
)


# ============================================================================
# Constantes & seuils
# ============================================================================

# Multiplicateur appliqué à la grille SCF automatique pour la grille NSCF.
# Avoir une grille 3× plus dense reste raisonnable pour une DOS lisse sur
# la plupart des cellules ; pour les grandes mailles on plafonne à ``MAX_NKX``.
#
# Juin 2026 (round 4) : MAX_K plafonné à 16 (était 32). Avec 32×32×32 la
# NSCF produit ~897 points IBZ pour Si → dos.x (lancé en SERIEL via
# ``run_qe_stdin``, voir ``qe_subprocess.py``) doit trier et intégrer
# ~1.3 M de tetrahedra pour 4000 points E → ``hpsort`` (Fortran tetra.f90)
# dépasse 300 s sur 1 core. 16×16×16 donne ~145 IBZ → même tri en ~15 s.
# Pour les profils P2-P4 avec grandes mailles,rare qu'on ait besoin de
# >16 points/axe pour une DOS lisse (DeltaE=0.01 eV déjà capté).
KPOINT_NSCF_MULTIPLIER = 3
KPOINT_NSCF_MIN_K = 12
KPOINT_NSCF_MAX_K = 16

# Taille du fichier A4 de sortie gnuplot.
GNUPLOT_TERMINAL_PNG = (
    'set terminal pngcairo size 1100,640 enhanced font "DejaVu Sans,11"\n'
)
# Bloc pdfcairo réutilisé pour produire le PDF vectoriel en multi-output
# (cf. phonon_gnuplot/eos_gnuplot). 27x16 cm ≈ ratio 1100x640 px @ 100dpi.
GNUPLOT_TERMINAL_PDF = (
    'set terminal pdfcairo size 27cm,16cm enhanced font "DejaVu Sans,11"\n'
)
GNUPLOT_TERMINAL_X11 = "set terminal x11\n"

RY_TO_EV = 13.605693009  # CODATA : 1 Ry ≈ 13.6057 eV (suffit pour archivage).

# Mots-clés regex robustes pour la sortie pw.x NSCF (« Fermi energy is … Ry »).
_RY_FERMI_RX = re.compile(
    r"(?im)^\s*(?:the\s+)?fermi\s+energy\s+is\s*=?[:\s]*"
    r"([+-]?[0-9]*\.?[0-9]+(?:[EeDd][+-]?\d+)?)"
    r"\s*(?:ry|hartree)?\b"
)
_EV_FERMI_RX = re.compile(
    r"(?im)^\s*(?:the\s+)?fermi\s+energy\s+is\s*=?[:\s]*"
    r"([+-]?[0-9]*\.?[0-9]+(?:[EeDd][+-]?\d+)?)\s*ev\b"
)
_HIGH_OCC_EV_RX = re.compile(
    r"(?im)^\s*highest\s+occupied\s+(?:crystal\s+)?level\s*\(ev\)\s*[:=]?\s*"
    r"([+-]?[0-9]*\.?[0-9]+(?:[EeDd][+-]?\d+)?)"
)
_HIGH_OCC_RY_RX = re.compile(
    r"(?im)^\s*highest\s+occupied\s+(?:crystal\s+)?level\s*\(ry\)\s*[:=]?\s*"
    r"([+-]?[0-9]*\.?[0-9]+(?:[EeDd][+-]?\d+)?)"
)
_LOW_UNOCC_EV_RX = re.compile(
    r"(?im)^\s*lowest\s+unoccupied\s+(?:crystal\s+)?level\s*\(ev\)\s*[:=]?\s*"
    r"([+-]?[0-9]*\.?[0-9]+(?:[EeDd][+-]?\d+)?)"
)
_NBND_RX = re.compile(
    r"(?im)^\s*number\s+of\s+Kohn-Sham\s+states(?:[^:=\n]*?)(?::=?|=)\s*"
    r"(\d+)"
)

# Détection spin-polarisé dans le SCF pour le tracé DOS up/down.
_RX_SPIN_POLARIZED = re.compile(
    r"(?im)^\s*nspin\s*=\s*([24])\b\s*,?\s*$"
)


def _is_scf_spin_polarized(scf_path: Path) -> bool:
    """Renvoie ``True`` si le SCF utilise ``nspin=2`` ou ``nspin=4``.

    Utilisé par ``run_gnuplot_edos`` pour tracer DOS up/down séparés.
    Robuste : si le fichier est absent / illisible, renvoie ``False`` (non-magnétique).
    """
    if not scf_path.is_file():
        return False
    try:
        text = scf_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    return bool(_RX_SPIN_POLARIZED.search(text))


# ============================================================================
# Helpers de manipulation du texte PW input
# ============================================================================


def _force_set_kv(text: str, key: str, value: str, *, block_name: Optional[str] = None) -> str:
    """Force ``key=value`` dans un namelist (par défaut premier ``&CONTROL``).

    Si la clé est absente, l'insère juste après le ``&CONTROL`` (ou ``&BLOCK``).
    Ne MODIFIE PAS les autres clés : strictement cible ``key``.

    NB (juin 2026 fix) : on **n'ajoute plus de virgule finale** à la valeur injectée.
    Les séparateurs virgule sont *optionnels* entre paires ``key=value`` distinctes
    en Fortran 2003 (sect. « namelist input convention »). Une virgule orpheline
    sur la dernière entrée force le parser pw.x en mode « continuation » — la
    ligne suivante (``calculation = 'scf'`` non-virgule) est alors lue comme
    continuation et fait planter ``read_namelists`` (symptôme bad line in &control
    sur le nom qu'on vient d'injecter). Le pattern ``,?\s*`` consomme la virgule
    éventuellement déjà présente côté texte pour ne pas laisser une virgule
    orpheline sur la ligne suivante en cas de replace.
    """
    # Pattern avec groupe 1 = l'indentation (préservée sur replace).
    pattern = re.compile(
        rf"(?im)^(\s*){re.escape(key)}\s*=\s*[^,\n]*,?\s*",
    )
    replace_line = rf"\1{key} = {value}"
    insert_line = f"    {key} = {value}"
    if block_name:
        # Repère le bloc.
        bm = re.search(rf"(?im)^\s*&{re.escape(block_name)}\b", text)
        if bm:
            search_from = bm.end()
        else:
            search_from = 0
    else:
        search_from = 0
    # Recherche ciblée dans le bloc (à partir de search_from).
    sub = text[search_from:]
    new_sub = pattern.sub(replace_line + "\n", sub, count=1)
    if new_sub != sub:
        return text[:search_from] + new_sub
    # Clé absente : on insère juste après "&BLOCK".
    if block_name:
        bm = re.search(rf"(?im)^\s*&{re.escape(block_name)}\b[^\n]*\n", text)
        if bm:
            insert_at = bm.end()
            return text[:insert_at] + insert_line + "\n" + text[insert_at:]
    # Sinon, insère en tête (filet de sécurité).
    return insert_line + "\n" + text


def inject_wf_collect(pw_text: str) -> tuple[str, bool, Optional[str]]:
    """Force ``wf_collect = .true.`` dans ``&CONTROL`` si absent ou ``.false.``.

    Renvoie ``(nouveau texte, modifié?, raison_si_skip)``.
    * ``(text, True,  None)``            : ligne ajoutée ou modifiée.
    * ``(text, False, None)``           : déjà ``.true.`` (no-op).
    * ``(text, False, "explicit_false")`` : ``wf_collect = .false.`` EXPLICITE
      détecté : l'utilisateur a sciemment désactivé la collecte des wf. Le
      NSCF/BANDS ne peuvent pas tourner sans ces fichiers sur disque.
      **L'appelant DOIT alors court-circuiter** l'étape propriétés
      électroniques (ichamp retombe à 0 effective) et logger un [WARN].

    Stratégie :
      * Présent ``.true.``      → no-op ;
      * Absent                  → injecte ``wf_collect = .true.,`` ;
      * Présent ``.false.``     → renvoie le texte tel quel ET le flag
        ``"explicit_false"`` (l'appelant skip).
    """
    if re.search(r"(?im)^\s*wf_collect\s*=\s*\.true\.\s*,?", pw_text):
        return pw_text, False, None
    if re.search(r"(?im)^\s*wf_collect\s*=\s*\.false\.\s*,?", pw_text):
        return pw_text, False, "explicit_false"
    return _force_set_kv(pw_text, "wf_collect", ".true.", block_name="CONTROL"), True, None


def check_wf_collect_explicit_false(pw_text: str) -> bool:
    """``True`` si le SCF force ``wf_collect = .false.`` (utilisateur expert).

    Helper public utilisé par l'orchestrateur pour court-circuiter proprement
    les chaînes NSCF/BANDS si l'utilisateur a explicitement désactivé la
    collecte des fonctions d'onde (rare mais sémantiquement légitime).
    """
    return bool(re.search(r"(?im)^\s*wf_collect\s*=\s*\.false\.\s*,?", pw_text))


def inject_lcalc_quantities(pw_text: str) -> str:
    """NO-OP historique (juin 2026).

    Anciennement, injectait ``lcalc_bands = .true.`` et ``lcalc_dos = .true.``
    dans ``&CONTROL`` du SCF pour **tous** les profils P1–P5 — but affiché
    « preview bandes+DOS gratuit pendant le SCF ».

    Pourquoi no-op maintenant :
      * Ces flags ne sont PAS reconnus par ``pw.x`` 7.5 dans ``&CONTROL``
        (cf. Fortran namelist ``&CONTROL`` de la doc INPUT_PW.html : seuls
        calculation, restart_mode, wf_collect, prefix, outdir, pseudo_dir,
        verbosity, nstep, etc. y sont acceptés). L'injection déclenche alors
        ``Error in routine read_namelists (1): bad line in namelist &control``
        et tue le SCF avant convergence (cf. les multiples fichiers CRASH
        dans ``work/<Mat>/pipeline_*/`` produits depuis juin 2026).
      * La DOS/bandes sont prises en charge **correctement** par la chaîne
        dédiée ``run_electronic_properties`` (ichamp=2 ou 3 selon profil) qui
        lance NSCF ``restart_mode='restart'`` + ``dos.x`` + ``bands.x`` *
        *sans toucher au SCF équilibre***.

    Compatibilité : la signature est conservée pour rétro-compat des
    callers (``pipeline.py``, scripts externes, tests unitaires). Si un
    futur QE ≥ 7.6 réintroduit ``lcalc_bands`` / ``lcalc_dos`` dans
    ``&CONTROL``, il suffira de réactiver le corps ci-dessous (cf.
    précédent dans l'historique git).

    NB : valeurs **explicitement écrites** par l'utilisateur dans
    ``lcalc_dos`` ou ``lcalc_bands`` (ex. ``lcalc_dos = .false.`` par
    utilisateur expert) sont préservées (la fonction est no-op,
    aucun ``_force_set_kv`` n'est appelé).
    """
    return pw_text


def densify_kpoints_for_nscf(pw_text: str, *, multiplier: int = KPOINT_NSCF_MULTIPLIER,
                            min_k: int = KPOINT_NSCF_MIN_K,
                            max_k: int = KPOINT_NSCF_MAX_K) -> str:
    """Multiplie la grille ``K_POINTS automatic`` pour la NSCF.

    * Laisse intact tout autre format (``tpiba_b``, ``gamma``, ``crystal_b``) :
      l'utilisateur sait ce qu'il fait.
    * Borne à ``max_k`` par axe pour éviter l'explosion mémoire.
    * Borne à ``min_k`` plancher.
    * Conserve l'offset (5e entier) s'il existe, sinon ``0 0 0``.
    """
    lines = pw_text.splitlines()
    head_marker = re.compile(
        r"(?i)^\s*K_POINTS\s*(?:\(\s*automatic\s*\)|automatic)\s*$"
    )
    out_lines: list[str] = []
    skip_next = 0
    for i, ln in enumerate(lines):
        if skip_next > 0:
            skip_next -= 1
            continue
        if head_marker.match(ln):
            # La grille suit (1 ligne).
            if i + 1 < len(lines):
                nxt = lines[i + 1].strip()
                toks = nxt.split()
                if len(toks) >= 3:
                    try:
                        n1 = int(float(toks[0]))
                        n2 = int(float(toks[1]))
                        n3 = int(float(toks[2]))
                        offset = " ".join(toks[3:6]) if len(toks) >= 6 else "0 0 0"
                        # Bornage multiplicateur.
                        n1n = min(max(n1 * multiplier, min_k), max_k)
                        n2n = min(max(n2 * multiplier, min_k), max_k)
                        n3n = min(max(n3 * multiplier, min_k), max_k)
                        out_lines.append(ln)
                        out_lines.append(f"  {n1n} {n2n} {n3n}  {offset}")
                        skip_next = 1
                        continue
                    except ValueError:
                        pass
        out_lines.append(ln)
    return "\n".join(out_lines) + "\n"


def has_tetrahedra_compatible_setup(pw_text: str) -> bool:
    """Détecte si ``occupations='smearing'`` est présent (typique métaux).

    True → on garde smearing dans la NSCF (tetrahedra incompatible métaux).
    False → on bascule ``tetrahedra`` dans la NSCF pour DOS propre.
    """
    return bool(
        re.search(r"(?im)^\s*occupations\s*=\s*['\"]?smearing['\"]?", pw_text)
    )


# ============================================================================
# Génération des fichiers d'entrée
# ============================================================================


def _read_pw_in(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="replace")


def write_nscf_in(work_dir: Path, scf_basename: str) -> Path:
    """Génère ``nscf.in`` à partir du SCF équilibre (même prefix/outdir/pseudo_dir).

    * Impose ``calculation='nscf'``, ``restart_mode='restart'``.
    * Impose ``wf_collect=.true.``, ``nbnd`` assez élevé (×2 par défaut si
      pas suffisant pour DOS propre — QE recommande ≥ 1.5× métal).
    * Densifie K_POINTS automatic (3×, borné [12, 32]).
    * Bascule ``occupations='tetrahedra'`` *seulement* si smearing absent.
    """
    scf_src = work_dir / scf_basename
    if not scf_src.is_file():
        raise FileNotFoundError(f"{scf_basename} absent dans {work_dir}")
    text = _read_pw_in(scf_src)
    text = _force_set_kv(text, "calculation", "'nscf'", block_name="CONTROL")
    text = _force_set_kv(text, "restart_mode", "'restart'", block_name="CONTROL")
    # inject_wf_collect retourne un tuple (text, modifie?, raison_skip) depuis
    # round-2. Si l'utilisateur a explicitement wf_collect=.false., on **ne
    # modifie pas** le SCF — c'est un choix sémantique délibéré. L'étape NSCF
    # échouera de toutes façons ; l'orchestrateur ``run_electronic_properties``
    # verra le motif ``explicit_false`` et log un [WARN] sans planter.
    text, _changed, _skip = inject_wf_collect(text)
    text = densify_kpoints_for_nscf(text)
    # nbnd : si absent ou trop bas, force à défaut max(int(nbnd)*2, ~ nb_atoms*8).
    # On essaie d'extraire nat & ntyp pour estimer un solde raisonnable.
    m_nbnd = re.search(r"(?im)^\s*nbnd\s*=\s*(\d+)", text)
    m_nat = re.search(r"(?im)^\s*nat\s*=\s*(\d+)", text)
    m_ntyp = re.search(r"(?im)^\s*ntyp\s*=\s*(\d+)", text)
    nbnd_now = int(m_nbnd.group(1)) if m_nbnd else None
    nat = int(m_nat.group(1)) if m_nat else None
    # Heuristique : on demande ~8 états par atome (couvre valence + conduction faible).
    target_min = max((nbnd_now or 0) * 2, (nat or 0) * 8, 16)
    if nbnd_now is None or nbnd_now < target_min:
        text = _force_set_kv(text, "nbnd", str(target_min), block_name="SYSTEM")
    # occupations.
    if has_tetrahedra_compatible_setup(text):
        # Métal : smearing conservé pour stabilité.
        if not re.search(r"(?im)^\s*occupations\s*=", text):
            text = _force_set_kv(text, "occupations", "'smearing'", block_name="SYSTEM")
    else:
        # Isolant : tetrahedra donne une DOS propre avec moins de k-points.
        text = _force_set_kv(text, "occupations", "'tetrahedra'", block_name="SYSTEM")
        # Tetrahedra exige une grille Monkhorst-Pack : si l'utilisateur a un
        # offset exotique, on force 0 0 0 pour cohérence.
        text = re.sub(
            r"(?im)(^\s*K_POINTS\s*(?:\(\s*automatic\s*\)|automatic)\s*\n"
            r"\s*\d+\s+\d+\s+\d+)(\s+\d+\s+\d+\s+\d+\s*)",
            r"\1 0 0 0",
            text,
        )
    target = work_dir / "nscf.in"
    target.write_text(text, encoding="utf-8")
    return target


def _strip_kpoints_block(pw_text: str) -> str:
    """Retire toute carte ``K_POINTS`` (automatic, gamma, crystal_b, …)."""
    lines = pw_text.splitlines()
    out: list[str] = []
    i = 0
    k_head = re.compile(r"(?i)^\s*K_POINTS\b")
    while i < len(lines):
        if not k_head.match(lines[i]):
            out.append(lines[i])
            i += 1
            continue
        header = lines[i].strip().lower()
        i += 1
        if "gamma" in header:
            continue
        if "crystal_b" in header:
            if i < len(lines):
                try:
                    nseg = int(lines[i].strip().split()[0])
                    i += 1 + nseg
                    continue
                except (ValueError, IndexError):
                    pass
        if i < len(lines) and lines[i].strip():
            i += 1
    return "\n".join(out).rstrip() + "\n"


def write_pw_bands_in(work_dir: Path, scf_basename: str) -> Optional[Path]:
    """Génère ``pw_bands.in`` (calculation='bands').

    K_POINTS : ``crystal_b`` avec le chemin q dérivé depuis ``ibrav`` via
    ``matdyn_band_qpath_for_ibrav``. Si ``ibrav`` non convertible, la
    fonction renvoie ``None`` (l'appelant retombe sur DOS seule).
    """
    scf_src = work_dir / scf_basename
    if not scf_src.is_file():
        raise FileNotFoundError(f"{scf_basename} absent dans {work_dir}")
    ibrav = parse_ibrav_from_pw(work_dir)
    if ibrav is None:
        return None
    # ibrav=0 (ex. maille triclinique simple) — matdyn_band_qpath_for_ibrav
    # retombe sur cubique par défaut. On évite ça pour instabilité :
    if ibrav == 0:
        return None
    verts, nks = matdyn_band_qpath_for_ibrav(ibrav)
    text = _read_pw_in(scf_src)
    text = _force_set_kv(text, "calculation", "'bands'", block_name="CONTROL")
    text = _force_set_kv(text, "restart_mode", "'restart'", block_name="CONTROL")
    # Mêmes précautions que write_nscf_in (`inject_wf_collect` renvoie tuple
    # depuis round-2) — on propage la modification et ignore le skip éventuel.
    text, _ch, _sk = inject_wf_collect(text)
    # nbnd : on garantit au moins autant que dans le NSCF (les bandes utilisent
    # celles du SCF/prefix.save — on garde la même valeur pour cohérence).
    m_nbnd_nscf = re.search(r"(?im)^\s*nbnd\s*=\s*(\d+)", (work_dir / "nscf.in").read_text(
        encoding="utf-8", errors="replace"
    ) if (work_dir / "nscf.in").is_file() else "")
    if m_nbnd_nscf:
        n_nscf = int(m_nbnd_nscf.group(1))
        text = _force_set_kv(text, "nbnd", str(n_nscf), block_name="SYSTEM")
    # K_POINTS crystal_b — remplace toute carte K_POINTS existante.
    text = _strip_kpoints_block(text)
    band_block = ["K_POINTS crystal_b", f" {len(verts)}"]
    for (qx, qy, qz), nk in zip(verts, nks, strict=True):
        band_block.append(f"  {qx:.12g} {qy:.12g} {qz:.12g}   {nk}")
    # Réinjecter juste avant un éventuel EOF (avant tout préfixe de bloc non+KPOINTS).
    # On insère à la fin du fichier : QE accepte n'importe quelle position
    # *tant que* c'est la dernière namelist / bloc de tokens.
    text = text.rstrip() + "\n\n" + "\n".join(band_block) + "\n"
    target = work_dir / "pw_bands.in"
    target.write_text(text, encoding="utf-8")
    return target


def write_dos_in(work_dir: Path, *, prefix: str) -> Path:
    """Écrit ``dos.in`` qui demande à ``dos.x`` de calculer la DOS depuis NSCF.

    QE 7.5 strict : namelist ``&dos`` (cf. INPUT_DOS.html et
    ``PP/src/dos.f90`` ; le Fortran namelist se déclare ``NAMELIST /dos/``).
    L'ancienne valeur ``&input`` lève ``Error in routine dos (1): reading dos
    namelist`` au démarrage de dos.x en 7.5 (cf. bug P1 Si du 30 juin 2026).
    Les trailing commas sont retirées (``val,\n`` final après le dernier
    entrée) car GFortran peut les tolérer mais certains profileurs levent
    des warnings sur cette construction — on s'aligne sur le standard
    ``val\n`` sans virgule terminale, comparable à write_nscf_in().
    """
    body = (
        " &dos\n"
        f"  prefix = '{prefix}'\n"
        "  outdir = './out/'\n"
        "  fildos = 'dos.dat'\n"
        "  Emin = -20.0\n"
        "  Emax =  20.0\n"
        "  DeltaE =  0.01\n"
        " /\n"
    )
    p = work_dir / "dos.in"
    p.write_text(body, encoding="utf-8")
    return p


def write_bands_in(work_dir: Path, *, prefix: str, filband: str = "bands.dat") -> Path:
    """Écrit ``bands.in`` — appel à ``bands.x`` sur les wf BANDS de pw.x.

    QE 7.5 strict : namelist ``&bands`` (cf. INPUT_BANDS.html et le code
    source ``PP/src/bands.f90``). L'ancienne valeur ``&input`` lève le même
    type d'erreur que ``write_dos_in`` (n'a jamais fonctionné en 7.5 sans
    ce fix préalable, mais les paths P1 Si terminaient avant via la branche
    ``ibrav=0 → bandes skipped``). On retire aussi les trailing commas
    sur le dernier entrée par symétrie avec ``write_dos_in()``.
    """
    body = (
        " &bands\n"
        f"  prefix = '{prefix}'\n"
        "  outdir = './out/'\n"
        f"  filband = '{filband}'\n"
        "  lsym = .true.\n"
        " /\n"
    )
    p = work_dir / "bands.in"
    p.write_text(body, encoding="utf-8")
    return p


# ============================================================================
# Parsing des sorties binaires
# ============================================================================


def parse_nscf_fermi(work_dir: Path, *, nscf_out_name: str = "nscf.out") -> Optional[float]:
    """Cherche ``Fermi energy is X.XXX Ry`` (ou eV) dans ``nscf.out``/``nscf.in.out``.

    Renvoie l'énergie en **eV**. Bascule ``Ry → eV`` si nécessaire.
    Priorité : sortie eV (déjà en eV) avant sortie Ry.
    """
    candidates: list[Path] = []
    for nm in (nscf_out_name, "nscf.in.out", "pw_bands.out", "pw_bands.in.out",
               "scf.in.out", "pw_scf_V0_for_phonon.in.out", "pw_scf_V0_for_phonon.out"):
        p = work_dir / nm
        if p.is_file():
            candidates.append(p)
    # Recherche aussi toute sortie pw.x récente.
    try:
        for extra in sorted(work_dir.glob("*.out"), reverse=True)[:6]:
            if extra.is_file() and extra not in candidates:
                candidates.append(extra)
    except OSError:
        pass
    for p in candidates:
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        # Tentative ev directe.
        m_ev = _EV_FERMI_RX.search(text)
        if m_ev:
            try:
                return float(m_ev.group(1).replace("D", "E").replace("d", "e"))
            except ValueError:
                pass
        # Bascule Ry → eV.
        m_ry = _RY_FERMI_RX.search(text)
        if m_ry:
            try:
                return float(m_ry.group(1).replace("D", "E").replace("d", "e")) * RY_TO_EV
            except ValueError:
                pass
    return None


def _qe_float(tok: str) -> Optional[float]:
    s = str(tok).strip().replace(",", ".")
    if not s:
        return None
    try:
        return float(s.replace("D", "E").replace("d", "e"))
    except ValueError:
        return None


def parse_bands_gap(work_dir: Path, *, filband: str = "bands.dat",
                    fermi_eV: Optional[float] = None) -> dict[str, Any]:
    """Lit le fichier ``bands.dat`` produit par ``bands.x`` et calcule le gap.

    Format standard ``bands.x`` :
        ``<k> <E_b1> <E_b2> … <E_bN>``
    Les blocs (un par segment du chemin) sont séparés par un en-tête contenant
    un nombre de points + coordonnées du dernier k du segment. On les ignore.

    Heuristique :
      * VBM = max(E_i) tel que E_i < E_Fermi (typiquement moins 1eV pour éviter
        les états thermalisés) — OU, si E_Fermi pas disponible, l'argmax global
        de la dernière bande occupée (méthode naïve souvent acceptable).
      * CBM = min(E_i) tel que E_i > E_Fermi (idem).
      * gap = CBM − VBM (négatif → métallique).

    Renvoie ``{"vbm_eV":…, "cbm_eV":…, "gap_eV":…, "type":…, "direct":…}``
    où ``type`` ∈ {"metal", "semiconductor", "insulator"} et ``direct`` est
    un booléen (VBM et CBM au même k → gap direct ; sinon indirect).
    """
    out: dict[str, Any] = {
        "vbm_eV": None,
        "cbm_eV": None,
        "gap_eV": None,
        "type": None,
        "direct": None,
    }
    p = work_dir / filband
    if not p.is_file():
        return out
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return out
    # En-têtes de segment ‒ lignes qui ressemblent à ``  <npts> <kx> <ky> <kz> ``
    # (utilisées par plotbands.x). On les saute.
    rows: list[tuple[float, list[float]]] = []
    for ln in text.splitlines():
        s = ln.strip()
        if not s:
            continue
        # Détection ligne segment : commence par un entier seul + 3 floats ?
        toks = s.split()
        if len(toks) == 4:
            try:
                _n = int(float(toks[0]))
                _x = float(toks[1])
                _y = float(toks[2])
                _z = float(toks[3])
                # Très probable segment hdr, sauf si kx/ky/kz = 0/0/0 (alors c'est peut-être un k-point normal).
                if all(abs(v) <= 1.0 for v in (_x, _y, _z)) and toks[0] == str(int(_n)):
                    # Condition forte : la valeur entière en colonne 1 doit être
                    # << nb de points de la dernière vraie ligne analysée.
                    if rows and _n > 4:
                        continue
            except ValueError:
                pass
        # Ligne données : 1 + N floats.
        parts = s.split()
        try:
            kval = float(parts[0])
        except (ValueError, IndexError):
            continue
        energies = []
        for t in parts[1:]:
            f = _qe_float(t)
            if f is None:
                break
            energies.append(f)
        if len(energies) >= 2:
            rows.append((kval, energies))
    if not rows:
        return out
    # Toutes les bandes = transposition lignes.
    n_bands = len(rows[0][1])
    # k-distance par bande (à plat) : pour la détection direct/indirect.
    band_k: list[float] = []
    band_e: list[float] = []
    for _k, es in rows:
        # idx médian → on prend la dernière bande pour des raisons de simplicité.
        # Plus juste : utilisateur scan toutes les bandes, mais le nombre de
        # bandes peut varier d'un segment à l'autre (rare) → on itère sur le min.
        pass
    # Reconstitue une liste (k, E) pour chaque bande (idx 0..min-1).
    band_curves: list[list[tuple[float, float]]] = [[] for _ in range(n_bands)]
    for k, e_list in rows:
        for i, e in enumerate(e_list):
            if i < n_bands:
                band_curves[i].append((k, e))
    if not band_curves:
        return out
    # VBM / CBM : utilise E_Fermi si connue, sinon médiane.
    ref = fermi_eV
    if ref is None:
        # Pas de Fermi → médiane globale comme seuil.
        all_vals = [e for curve in band_curves for _, e in curve]
        if not all_vals:
            return out
        all_vals_sorted = sorted(all_vals)
        ref = all_vals_sorted[len(all_vals_sorted) // 2]
    vbm = -1e30
    cbm = 1e30
    vbm_k = 0.0
    cbm_k = 0.0
    for curve in band_curves:
        for k, e in curve:
            # Occupation approximative : e < ref - 0.05 (tolère smearing).
            # Vide : e > ref + 0.05.
            if e <= ref - 0.05 and e > vbm:
                vbm = e
                vbm_k = k
            if e >= ref + 0.05 and e < cbm:
                cbm = e
                cbm_k = k
    if vbm == -1e30 or cbm == 1e30:
        return out
    gap = cbm - vbm
    out["vbm_eV"] = round(vbm, 6)
    out["cbm_eV"] = round(cbm, 6)
    out["gap_eV"] = round(gap, 6)
    if gap < -1e-3:
        out["type"] = "metal"
        # Pour métal on définit VBM/CBM comme Fermi-crossing points.
        out["gap_eV"] = round(gap, 6)
    elif gap < 0.05:
        out["type"] = "zero_gap_semimetal"
    else:
        out["type"] = "semiconductor"
    out["direct"] = bool(abs(vbm_k - cbm_k) < 1e-3)
    return out


def parse_nscf_nbands(work_dir: Path, *, nscf_out_name: str = "nscf.out") -> Optional[int]:
    """Lit le nombre de bandes Kohn-Sham (``number of Kohn-Sham states``)."""
    candidates: list[Path] = []
    for nm in (nscf_out_name, "nscf.in.out", "pw_bands.out", "bands.out"):
        p = work_dir / nm
        if p.is_file() and p not in candidates:
            candidates.append(p)
    for p in candidates:
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        m = _NBND_RX.search(text)
        if m:
            try:
                return int(m.group(1))
            except ValueError:
                continue
    return None


# ============================================================================
# Gnuplot scripts inline
# ============================================================================


def _gnuplot(script: str, *, work_dir: Path, log: Path) -> None:
    """Exécute un script gnuplot via stdin — log écrit sur disque."""
    work_dir.mkdir(parents=True, exist_ok=True)
    log.parent.mkdir(parents=True, exist_ok=True)
    env = {**os.environ}
    # Force un terminal PNG en batch (sans DISPLAY/X11 en CI).
    env.setdefault("GNUTERM", "png")
    try:
        proc = __import__("subprocess").run(
            ["gnuplot"],
            cwd=work_dir,
            input=script,
            capture_output=True,
            text=True,
            env=env,
        )
        log.write_text(
            f"# gnuplot exit={proc.returncode}\n"
            + (proc.stderr or "") + "\n"
            + (proc.stdout or ""),
            encoding="utf-8",
        )
    except FileNotFoundError as ex:
        # gnuplot manquant → on log simplement ; les .dat restent utilisables.
        log.write_text(
            f"# gnuplot absent : {ex}\n# Le fichier .dat est néanmoins valide pour tracé externe.\n",
            encoding="utf-8",
        )
    except OSError as ex:
        log.write_text(f"# gnuplot OSError : {ex}\n", encoding="utf-8")


def run_gnuplot_edos(work_dir: Path, *, fermi_eV: Optional[float] = None,
                     is_spin_polarized: bool = False) -> Optional[Path]:
    """Trace DOS : ``edos.png`` (+ ``edos.pdf`` vectoriel).

    * Mode non-magnétique (``is_spin_polarized=False``) : courbe totale unique (col. 2).
    * Mode spin-polarisé (``is_spin_polarized=True``) : DOS up (col. 3, bleu,
      axe y positif) et DOS down (col. 4, rouge, axe y négatif miroir).
      Convention standard de physique du solide : spin ↑ vers le haut,
      spin ↓ vers le bas.

    Retourne le Path du PNG ; le PDF (chemin parallèle ``edos.pdf``) est
    produit en multi-output dans le même run gnuplot si le terminal
    ``pdfcairo`` est disponible (≥gnuplot 5.0 ; quasi universel en 2026).
    """
    dos_dat = work_dir / "dos.dat"
    if not dos_dat.is_file():
        return None
    # Note : dos.x écrit son DOS dans ``dos.dat`` (pas "edos.dat"). Avant
    # juillet 2026 le nom était hardcodé ̀ "edos.dat" ce qui faisait crasher
    # gnuplot en exit=1 (``Cannot find or open file 'edos.dat'``) et produisait
    # un PNG edos.png de 0 bytes côté UI. On résout dynamiquement depuis le
    # Path (le cwd de gnuplot est work_dir, cf. ``_gnuplot``). Les deux lignes
    # suivantes restent pour rétro-compat si quelqu'un renomme manuellement.
    plot = dos_dat.name
    if dos_dat.with_name("dos.dat").name != "dos.dat":
        # dos.x produit typiquement le nom ``dos.dat`` ; on garde le nom fixe.
        pass
    out_png = work_dir / "edos.png"
    out_pdf = work_dir / "edos.pdf"
    fermi_line = (
        f"set arrow from first {fermi_eV:.4f}, graph 0 to first {fermi_eV:.4f}, graph 1 "
        f"nohead lt 1 lw 1.6 lc rgb '#cc5a35'\n"
        f"set label '{fermi_eV:.3f} eV (E_F)' at first {fermi_eV:.4f}, graph 0.96 "
        f"textcolor rgb '#cc5a35' offset 0.7,0\n"
    ) if fermi_eV is not None else ""
    pdf_block = (
        GNUPLOT_TERMINAL_PDF
        + f"set output '{out_pdf.name}'\n"
        + "replot\n"
    )
    if is_spin_polarized:
        # DOS spin-résolue : spin-up (col. 3, bleu, axe y+) et spin-down (col. 4, rouge, axe y− miroir).
        # Convention standard de physique du solide : spin ↑ vers le haut, spin ↓ vers le bas.
        script = (
            GNUPLOT_TERMINAL_PNG
            + f"set output '{out_png.name}'\n"
            + "set title 'Densité d''états (DOS) spin-résolue — QE NSCF + dos.x'\n"
            + "set xlabel 'Énergie  E − E_F  (eV)'\n"
            + "set ylabel 'DOS (états / eV / cellule)'\n"
            + "set grid lc rgb '#444444' lw 0.5\n"
            + "set key outside right top vertical Right noreverse enhanced autotitle box lt -1 lw 1\n"
            + fermi_line
            + f"plot '{plot}' using 1:3 with lines lw 1.8 lc rgb '#3a7bd5' title 'DOS spin ↑', \\\n"
            + f"     '{plot}' using 1:(-$4) with lines lw 1.8 lc rgb '#d54e3a' title 'DOS spin ↓'\n"
            + pdf_block
        )
    else:
        script = (
            GNUPLOT_TERMINAL_PNG
            + f"set output '{out_png.name}'\n"
            + "set title 'Densité d''états totale (DOS) — QE NSCF + dos.x'\n"
            + "set xlabel 'Énergie  E − E_F  (eV)'\n"
            + "set ylabel 'N(E)   (états / eV / cellule)'\n"
            + "set grid lc rgb '#444444' lw 0.5\n"
            + "set key outside right top vertical Right noreverse enhanced autotitle box lt -1 lw 1\n"
            + fermi_line
            + f"plot '{plot}' using 1:2 with lines lw 1.8 lc rgb '#5ee0ff' title 'Total DOS\\n'\n"
            + pdf_block
        )
    _gnuplot(script, work_dir=work_dir, log=work_dir / "edos.plt.log")
    return out_png if out_png.is_file() else None


_BAND_VERTEX_LINE = re.compile(
    r"^\s*([-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?)\s+"
    r"([-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?)\s+"
    r"([-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?)\s+(\d+)\s*(?:!.*)?$"
)


def _parse_kpath_vertices_from_file(pw_path: Path) -> Optional[tuple[list[list[float]], list[int]]]:
    """Lit les sommets ``K_POINTS crystal_b`` depuis ``pw_bands.in`` (ou équivalent)."""
    try:
        lines = pw_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return None
    start: Optional[int] = None
    for i, ln in enumerate(lines):
        if re.match(r"(?im)^\s*K_POINTS\s+crystal_b\s*$", ln.strip()):
            start = i + 1
            break
    if start is None or start >= len(lines):
        return None
    try:
        n_lines = int(lines[start].strip().split()[0])
    except (ValueError, IndexError):
        return None
    verts: list[list[float]] = []
    nks: list[int] = []
    for j in range(n_lines):
        idx = start + 1 + j
        if idx >= len(lines):
            break
        m = _BAND_VERTEX_LINE.match(lines[idx])
        if not m:
            return None
        verts.append([float(m.group(1)), float(m.group(2)), float(m.group(3))])
        nks.append(int(m.group(4)))
    if len(verts) < 2:
        return None
    return verts, nks


def _parse_kpath_vertices(work_dir: Path) -> Optional[tuple[list[list[float]], list[int]]]:
    """Chemin q pour les bandes électroniques : ``pw_bands.in`` puis ``matdyn_bands.in``, sinon ``ibrav``."""
    for fname in ("pw_bands.in", "matdyn_bands.in"):
        p = work_dir / fname
        if p.is_file():
            parsed = _parse_kpath_vertices_from_file(p)
            if parsed:
                return parsed
    ibrav = parse_ibrav_from_pw(work_dir)
    if ibrav is not None and ibrav != 0:
        verts, nks = matdyn_band_qpath_for_ibrav(ibrav)
        return [list(v) for v in verts], list(nks)
    return None


def _parse_bands_dat_gnu(gnu_path: Path) -> Optional[tuple[list[float], list[list[float]], int]]:
    """Parse ``bands.dat.gnu`` (une bande par bloc, abscisse k cumulée en colonne 1)."""
    try:
        from phonon_gnuplot import floats_in_line
    except ImportError:
        def floats_in_line(line: str) -> list[float]:  # type: ignore[misc]
            rx = re.compile(r"[-+]?(?:\d*\.\d+|\d+(?:\.\d*)?)(?:[eE][-+]?\d+)?")
            return [float(x) for x in rx.findall(line)]

    blocks: list[list[tuple[float, float]]] = []
    cur: list[tuple[float, float]] = []
    try:
        raw_lines = gnu_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return None
    for ln in raw_lines:
        if not ln.strip():
            if cur:
                blocks.append(cur)
                cur = []
            continue
        nums = floats_in_line(ln)
        if len(nums) >= 2:
            cur.append((float(nums[0]), float(nums[1])))
    if cur:
        blocks.append(cur)
    if not blocks:
        return None
    nbnd = len(blocks)
    nk = len(blocks[0])
    if nk < 2 or any(len(b) != nk for b in blocks):
        return None
    xs = [blocks[0][i][0] for i in range(nk)]
    rows: list[list[float]] = []
    for i in range(nk):
        rows.append([xs[i]] + [blocks[b][i][1] for b in range(nbnd)])
    return xs, rows, nbnd


def _parse_bands_dat_raw(work_dir: Path) -> Optional[tuple[list[float], list[list[float]], int]]:
    """Repli : parse ``bands.dat`` (marqueurs 3 flottants + énergies wrapées sur plusieurs lignes)."""
    src_path = work_dir / "bands.dat"
    if not src_path.is_file():
        return None
    try:
        from phonon_gnuplot import floats_in_line
    except ImportError:
        def floats_in_line(line: str) -> list[float]:  # type: ignore[misc]
            rx = re.compile(r"[-+]?(?:\d*\.\d+|\d+(?:\.\d*)?)(?:[eE][-+]?\d+)?")
            return [float(x) for x in rx.findall(line)]

    text = src_path.read_text(encoding="utf-8", errors="replace")
    m_hdr = re.search(r"(?i)nbnd\s*=\s*(\d+)", text)
    nbnd = int(m_hdr.group(1)) if m_hdr else 0
    if nbnd <= 0:
        return None

    kpath = _parse_kpath_vertices(work_dir)
    lines = [ln for ln in text.splitlines() if ln.strip() and not ln.strip().startswith("&")]
    energies_by_k: list[list[float]] = []
    i = 0
    while i < len(lines):
        nums = floats_in_line(lines[i])
        if len(nums) == 3:
            i += 1
            buf: list[float] = []
            while len(buf) < nbnd and i < len(lines):
                nums2 = floats_in_line(lines[i])
                if len(nums2) == 3:
                    break
                buf.extend(nums2)
                i += 1
            if len(buf) >= nbnd:
                energies_by_k.append(buf[:nbnd])
            continue
        i += 1
    if not energies_by_k:
        return None

    xs: list[float]
    if kpath:
        vertices, nks = kpath
        xs = []
        cum = 0.0
        for seg, nk in enumerate(nks):
            if seg >= len(vertices) - 1:
                break
            v0 = vertices[seg]
            v1 = vertices[seg + 1]
            dq = [v1[j] - v0[j] for j in range(3)]
            for d in range(3):
                if dq[d] > 0.5:
                    dq[d] -= 1.0
                elif dq[d] < -0.5:
                    dq[d] += 1.0
            seg_len = (dq[0] ** 2 + dq[1] ** 2 + dq[2] ** 2) ** 0.5
            for j in range(int(nk)):
                xs.append(cum + seg_len * (j / max(int(nk), 1)))
            cum += seg_len
        while len(xs) < len(energies_by_k):
            xs.append(cum)
        xs = xs[: len(energies_by_k)]
    else:
        xs = [float(k) for k in range(len(energies_by_k))]

    rows = [[xs[k]] + energies_by_k[k] for k in range(len(energies_by_k))]
    return xs, rows, nbnd


def _read_bands_plot_data(work_dir: Path) -> Optional[tuple[list[float], list[list[float]], int]]:
    """Lit les bandes pour gnuplot — préfère ``bands.dat.gnu`` (abscisse k correcte)."""
    gnu = work_dir / "bands.dat.gnu"
    if gnu.is_file():
        parsed = _parse_bands_dat_gnu(gnu)
        if parsed:
            return parsed
    return _parse_bands_dat_raw(work_dir)


def _ebands_xtics_gnuplot(work_dir: Path, xs: list[float]) -> str:
    """Ticks aux points spéciaux du chemin k (Γ, X, …) selon ``pw_bands.in`` / ``ibrav``."""
    try:
        from phonon_gnuplot import _vertex_high_symm_label
    except ImportError:
        return ""
    parsed = _parse_kpath_vertices(work_dir)
    if not parsed or not xs:
        return ""
    vertices, nks = parsed
    if len(vertices) != len(nks):
        return ""
    tick_idx = [0]
    cum = 0
    for nk in nks[:-1]:
        cum += int(nk)
        tick_idx.append(min(cum, len(xs) - 1))
    pairs: list[tuple[str, float]] = []
    for i, vi in enumerate(tick_idx):
        if vi >= len(xs):
            continue
        lab = _vertex_high_symm_label(vertices[i], vertices=vertices)
        pairs.append((lab, float(xs[vi])))
    if len(pairs) < 2:
        return ""
    tic_parts = []
    for lab, xv in pairs:
        esc = str(lab).replace('"', "'")
        tic_parts.append(f'"{esc}" {xv:.8g}')
    out: list[str] = []
    for _, xv in pairs[1:-1]:
        out.append(
            f"set arrow from {xv:.8g}, graph 0 to {xv:.8g}, graph 1 nohead "
            f"lt -1 lw 0.5 lc rgb '#666666'\n"
        )
    out.append(f"set xtics ({', '.join(tic_parts)})\n")
    out.append("set xtics nomirror\n")
    return "".join(out)


def _prepare_bands_gnuplot_dat(
    work_dir: Path,
    *,
    fermi_eV: Optional[float] = None,
) -> Optional[tuple[Path, int, list[float]]]:
    """Convertit ``bands.dat(.gnu)`` en ``ebands_plot.dat`` : col1 = k-path, cols2+ = E (rel. E_F si fourni).

    Retourne ``(ebands_plot.dat, nbnd, xs)`` ou ``None``.
    """
    parsed = _read_bands_plot_data(work_dir)
    if parsed is None:
        return None
    xs, rows, nbnd = parsed
    if nbnd <= 0 or not rows:
        return None
    out = work_dir / "ebands_plot.dat"
    with out.open("w", encoding="utf-8") as fh:
        fh.write("# col1: k-path distance ; cols2+: band energies (eV)\n")
        for row in rows:
            kx = row[0]
            energies = row[1 : nbnd + 1]
            if fermi_eV is not None:
                energies = [e - fermi_eV for e in energies]
            fh.write(
                f"{kx:.8g} " + " ".join(f"{e:.6f}" for e in energies) + "\n"
            )
    return out, nbnd, xs


def run_gnuplot_ebands(work_dir: Path, *, fermi_eV: Optional[float] = None,
                       k_labels: Optional[str] = None) -> Optional[Path]:
    """Trace bandes : ``ebands.png`` (+ ``ebands.pdf``) — axe x = chemin k, axe y = E−E_F."""
    prepared = _prepare_bands_gnuplot_dat(work_dir, fermi_eV=fermi_eV)
    if prepared is None:
        return None
    plot_dat, nbnd, xs = prepared
    out_png = work_dir / "ebands.png"
    out_pdf = work_dir / "ebands.pdf"
    xtics_block = k_labels if k_labels is not None else _ebands_xtics_gnuplot(work_dir, xs)
    fermi_line = (
        "set arrow from graph 0, first 0 to graph 1, first 0 nohead lt 1 lw 1.2 "
        "lc rgb '#cc5a35'\n"
        "set label 'E_F' at graph 1.01, first 0 textcolor rgb '#cc5a35' right\n"
    ) if fermi_eV is not None else (
        "set arrow from graph 0, first 0 to graph 1, first 0 nohead lt -1 lw 0.6\n"
    )
    ylabel = "Energy − E_F (eV)" if fermi_eV is not None else "Energy (eV)"
    plot_parts = [
        f"'{plot_dat.name}' using 1:{i} with lines lw 1.0 lc rgb '#9aa0ab' notitle"
        for i in range(2, nbnd + 2)
    ]
    plot_cmd = "plot " + ", ".join(plot_parts) + "\n"
    pdf_block = (
        GNUPLOT_TERMINAL_PDF
        + f"set output '{out_pdf.name}'\n"
        + "replot\n"
    )
    script = (
        GNUPLOT_TERMINAL_PNG
        + f"set output '{out_png.name}'\n"
        + "set title 'Electronic bands E(k) — QE pw.x + bands.x'\n"
        + "set xlabel 'Wave vector'\n"
        + f"set ylabel '{ylabel}'\n"
        + "set grid lc rgb '#444444' lw 0.5\n"
        + fermi_line
        + xtics_block
        + plot_cmd
        + pdf_block
    )
    _gnuplot(script, work_dir=work_dir, log=work_dir / "ebands.plt.log")
    return out_png if out_png.is_file() and out_png.stat().st_size > 100 else None



# ============================================================================
# Orchestrateur principal
# ============================================================================


@dataclass
class ElectronicPropsResult:
    """Résultat détaillé (utilisé pour le marker JSON et l'UI)."""

    ichamp: int = 0
    nscf_ok: bool = False
    dos_ok: bool = False
    bands_ok: bool = False  # True si la chaîne bandes (pw_bands + bands.x) a abouti
    fermi_eV: Optional[float] = None
    n_bands: Optional[int] = None
    gap_eV: Optional[float] = None
    vbm_eV: Optional[float] = None
    cbm_eV: Optional[float] = None
    gap_type: Optional[str] = None
    gap_direct: Optional[bool] = None
    nscf_in: Optional[str] = None
    pw_bands_in: Optional[str] = None
    dos_in: Optional[str] = None
    bands_in: Optional[str] = None
    ebands_image: Optional[str] = None
    edos_image: Optional[str] = None
    notes: list[str] = None  # type: ignore[assignment]

    # ---- Aliases publiques -----------------------------------------------
    # July 2026 fix — le pipeline (pipeline._run_electronic_properties) lit
    # `parsed.band_gap_eV` et `parsed.band_gap_type` côté API/UI, mais le
    # champ canonique interne reste `gap_eV`/`gap_type` (cohérence avec
    # `parse_bands_gap` qui produit un dict `{"gap_eV": ..., "type": ...}`).
    # Sans ces properties Python, `getattr(parsed, "band_gap_eV")` (→
    # `keys_to_nest` pipeline.py) lève AttributeError et le job entier
    # CRASH alors que NSCF+dos.x ont déjà tourné.
    #
    # Le nom public `band_gap_eV` reste l'API contract respectée par
    # `expected_results.metrics` (toutes les fiches profils P1-P5) ; le
    # nom interne `gap_eV` reste pour `to_dict()` + tests P2 (test_props.py)
    # + archives JSON `pipeline_api_job_state.json` legacy.
    #
    # Les `@property` ne génèrent PAS de paramètre dans `__init__` du
    # `@dataclass` : aucun risque de cassage de la sérialisation, et
    # `dataclasses.asdict(parsed)` continue de retourner `gap_eV`.
    @property
    def band_gap_eV(self) -> Optional[float]:
        """Alias public — renvoie `self.gap_eV` (champ canonique interne)."""
        return self.gap_eV

    @property
    def band_gap_type(self) -> Optional[str]:
        """Alias public — renvoie `self.gap_type` (champ canonique interne)."""
        return self.gap_type

    def to_dict(self) -> dict[str, Any]:
        return {
            "ichamp": self.ichamp,
            "nscf_ok": self.nscf_ok,
            "dos_ok": self.dos_ok,
            "bands_ok": self.bands_ok,
            "fermi_eV": self.fermi_eV,
            "n_bands": self.n_bands,
            "gap_eV": self.gap_eV,
            "vbm_eV": self.vbm_eV,
            "cbm_eV": self.cbm_eV,
            "gap_type": self.gap_type,
            "gap_direct": self.gap_direct,
            "nscf_in": self.nscf_in,
            "pw_bands_in": self.pw_bands_in,
            "dos_in": self.dos_in,
            "bands_in": self.bands_in,
            "ebands_image": self.ebands_image,
            "edos_image": self.edos_image,
            "notes": list(self.notes or []),
        }


def _looks_like_executable(p: Path) -> bool:
    """Un binaire QE « présent » = fichier régulier non vide + exécutable."""
    if not p.is_file():
        return False
    if p.stat().st_size < 100:
        return False  # taille ridicule ⇒ binaire corrompu ou lien cassé.
    return True


def _execute_bands_chain(
    work_dir: Path,
    scf_basename: str,
    *,
    nproc: int,
    res: ElectronicPropsResult,
    note: callable,
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
) -> None:
    """pw.x BANDS + bands.x — facteur commun ichamp=3 et retry bandes-only."""
    nscf_in = work_dir / "nscf.in"
    if not nscf_in.is_file():
        note("[PROPS] nscf.in absent — bandes impossibles sans NSCF préalable.")
        return
    try:
        m_pref = re.search(
            r"(?im)^\s*prefix\s*=\s*['\"]?([^,'\"\s]+)",
            nscf_in.read_text(encoding="utf-8", errors="replace"),
        )
        prefix = m_pref.group(1) if m_pref else "pw_scf"
        pw_bands_path = write_pw_bands_in(work_dir, scf_basename)
        if pw_bands_path is None:
            note(
                "[PROPS] write_pw_bands_in : ibrav illisible (ibrav=0 ou "
                "non convertible) — bandes sautées."
            )
            return
        res.pw_bands_in = "pw_bands.in"
        note("[PROPS] pw_bands.in écrit.")
        run_pw_x_in(
            work_dir, "pw_bands.in", nproc=nproc,
            cancel_event=cancel_event, proc_holder=proc_holder,
        )
        bands_x = cfg.bands_path()
        if not _looks_like_executable(bands_x):
            note(f"[PROPS] bands.x absent ({bands_x}) — bandes sautées.")
            return
        write_bands_in(work_dir, prefix=prefix)
        res.bands_in = "bands.in"
        run_qe_stdin(
            bands_x,
            work_dir / "bands.in",
            work_dir,
            work_dir / "bands.out",
            nproc=2,
            cancel_event=cancel_event,
            proc_holder=proc_holder,
        )
        res.bands_ok = True
        note("[PROPS] bands.x terminé — diagramme calculé.")
    except Exception as ex:  # noqa: BLE001
        if cancel_event is not None and cancel_event.is_set():
            raise
        note(f"[PROPS] chaîne bandes échouée : {ex}.")


def run_bands_chain_only(
    work_dir: Path,
    *,
    nproc: int,
    scf_basename: str,
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
    log_emit: Optional[callable] = None,
) -> ElectronicPropsResult:
    """Relance pw.x BANDS + bands.x quand NSCF est déjà convergé (retry P1).

    Ne refait ni NSCF ni dos.x — utile après correction d'un bug ``ibrav``
    ou pour compléter un job ``done`` avec ``bands_ok=false``.
    """
    res = ElectronicPropsResult(ichamp=3, notes=[])
    log = log_emit or (lambda _msg: None)

    def note(msg: str) -> None:
        res.notes.append(msg)
        try:
            log(msg)
        except Exception:  # noqa: BLE001
            pass

    work_dir = Path(work_dir).expanduser().resolve()
    scf_path = work_dir / scf_basename
    if not scf_path.is_file():
        note(f"[PROPS] {scf_basename} absent — retry bandes impossible.")
        return res
    if not (work_dir / "nscf.in").is_file():
        note("[PROPS] nscf.in absent — retry bandes impossible.")
        return res

    res.nscf_ok = (work_dir / "nscf.out").is_file()
    res.dos_ok = (work_dir / "dos.dat").is_file()
    note("[PROPS] Retry bandes-only (NSCF/DOS conservés sur disque).")
    _execute_bands_chain(
        work_dir,
        scf_basename,
        nproc=nproc,
        res=res,
        note=note,
        cancel_event=cancel_event,
        proc_holder=proc_holder,
    )

    res.fermi_eV = parse_nscf_fermi(work_dir)
    res.n_bands = parse_nscf_nbands(work_dir)
    if res.bands_ok:
        gp = parse_bands_gap(work_dir, fermi_eV=res.fermi_eV)
        res.gap_eV = gp["gap_eV"]
        res.vbm_eV = gp["vbm_eV"]
        res.cbm_eV = gp["cbm_eV"]
        res.gap_type = gp["type"]
        res.gap_direct = gp["direct"]
        b = run_gnuplot_ebands(work_dir, fermi_eV=res.fermi_eV)
        if b is not None:
            res.ebands_image = b.name
            note(f"[PROPS] Tracé bandes : {b.name}.")

    note(
        f"[PROPS] ===> retry bandes : bandes={res.bands_ok} | "
        f"E_F={res.fermi_eV} eV | gap={res.gap_eV} eV ({res.gap_type or '?'})"
    )
    return res


def reparse_bands_from_disk(work_dir: Path) -> ElectronicPropsResult:
    """Re-parse ``bands.dat`` + plots sans relancer pw.x (marker JSON périmé)."""
    res = ElectronicPropsResult(ichamp=3, notes=[])
    wd = Path(work_dir).expanduser().resolve()
    res.nscf_ok = (wd / "nscf.out").is_file()
    res.dos_ok = (wd / "dos.dat").is_file()
    res.bands_ok = (wd / "bands.dat").is_file()
    if not res.bands_ok:
        return res
    res.fermi_eV = parse_nscf_fermi(wd)
    res.n_bands = parse_nscf_nbands(wd)
    gp = parse_bands_gap(wd, fermi_eV=res.fermi_eV)
    res.gap_eV = gp.get("gap_eV")
    res.vbm_eV = gp.get("vbm_eV")
    res.cbm_eV = gp.get("cbm_eV")
    res.gap_type = gp.get("type")
    res.gap_direct = gp.get("direct")
    if (wd / "ebands.png").is_file():
        res.ebands_image = "ebands.png"
    elif res.fermi_eV is not None:
        b = run_gnuplot_ebands(wd, fermi_eV=res.fermi_eV)
        if b is not None:
            res.ebands_image = b.name
    if (wd / "edos.png").is_file():
        res.edos_image = "edos.png"
    return res


def run_electronic_properties(
    work_dir: Path,
    *,
    nproc: int,
    scf_basename: str,
    ichamp: int = 3,
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
    log_emit: Optional[callable] = None,
) -> ElectronicPropsResult:
    """Orchestre la chaîne ``ichamp in {2,3}`` pour un work_dir donné.

    * ``scf_basename`` : nom du fichier PW d'équilibre (« scf.in » pour P1 ;
      « pw_scf_V0_for_phonon.in » pour P2–P4). Ce fichier doit contenir
      ``wf_collect = .true.`` ; on force la valeur en place si besoin.
    * ``log_emit`` : callback (callable) qui prepend une ligne de journal —
      typiquement ``self._append_log`` côté ``PipelineJob``. Aucun préfixe
      ajouté automatiquement, on documente clairement pour chaque ligne.

    Renvoie un ``ElectronicPropsResult`` TOUJOURS, même si une sous-étape
    échoue — erreurs diagnostiquées dans ``notes`` pour le marker JSON.
    """
    res = ElectronicPropsResult(ichamp=ichamp, notes=[])
    log = log_emit or (lambda _msg: None)

    def note(msg: str) -> None:
        res.notes.append(msg)
        try:
            log(msg)
        except Exception:  # noqa: BLE001
            pass

    work_dir = Path(work_dir).expanduser().resolve()

    # Préconditions
    if ichamp not in (2, 3):
        note(f"[PROPS] ichamp inconnu {ichamp} (attendu 2 ou 3) — ignoré.")
        return res

    scf_path = work_dir / scf_basename
    if not scf_path.is_file():
        note(f"[PROPS] {scf_basename} absent — propriétés électroniques sautées.")
        return res

    # --- 1. Vérification du binaire pw.x (réutilisé pour NSCF et BANDS).
    try:
        pw_x = cfg.pw_path()
    except Exception as ex:  # noqa: BLE001
        note(f"[PROPS] chemin pw.x introuvable : {ex} — propriétés sautées.")
        return res
    if not _looks_like_executable(pw_x):
        note(f"[PROPS] pw.x manquant ou vide ({pw_x}) — propriétés sautées.")
        return res

    # --- 2. NSCF.
    # Garde fou round-2 : si le SCF d'équilibre force ``wf_collect = .false.``
    # (sémantique volontaire de l'utilisateur expert), on refuse d'altérer et
    # on saute la chaîne NSCF+BANDS avec un [WARN] explicite (l'utilisateur
    # comprendra que la DOS/bandes ne sont pas calculables sans les wf sur
    # disque).
    scf_text_for_check = (work_dir / scf_basename).read_text(
        encoding="utf-8", errors="replace"
    )
    if check_wf_collect_explicit_false(scf_text_for_check):
        note(
            "[PROPS] ATTENTION : le SCF équilibre contient « wf_collect = .false. » "
            "explicite. NSCF et bandes x reposent sur les fonctions d'onde "
            "sérialisées (restart_mode='restart'). La chaîne ichamp=" + str(ichamp)
            + " est donc COURT-CIRCUITÉE. Relancez après avoir passé "
            "« wf_collect = .true. » dans le SCF pour activer DOS/bandes."
        )
        return res

    try:
        nscf_in_path = write_nscf_in(work_dir, scf_basename)
        res.nscf_in = nscf_in_path.name
        note(f"[PROPS] nscf.in écrit (prefix/heritage {scf_basename}).")
    except Exception as ex:  # noqa: BLE001
        note(f"[PROPS] write_nscf_in : {ex} — propriétés sautées.")
        return res

    try:
        log(f"[PROPS] Lancement pw.x NSCF (nproc={nproc}, restart_mode='restart').")
        run_pw_x_in(
            work_dir, "nscf.in", nproc=nproc,
            cancel_event=cancel_event, proc_holder=proc_holder,
        )
        res.nscf_ok = True
        note("[PROPS] NSCF terminé.")
    except Exception as ex:  # noqa: BLE001
        if cancel_event is not None and cancel_event.is_set():
            raise
        note(f"[PROPS] NSCF échoué : {ex} — suite sautée.")
        return res

    # --- 3. DOS (ichamp ≥ 2).
    dos_x = cfg.dos_path()
    if not _looks_like_executable(dos_x):
        note(f"[PROPS] dos.x absent ({dos_x}) — DOS sautée.")
    else:
        # Récupère ``prefix`` du NSCF (alias scf).
        m_pref = re.search(r"(?im)^\s*prefix\s*=\s*['\"]?([^,'\"\s]+)", nscf_in_path.read_text(
            encoding="utf-8", errors="replace"
        ))
        prefix = m_pref.group(1) if m_pref else "pw_scf"
        try:
            write_dos_in(work_dir, prefix=prefix)
            res.dos_in = "dos.in"
            note(f"[PROPS] dos.in écrit (prefix={prefix}).")
            run_qe_stdin(
                dos_x, work_dir / "dos.in", work_dir, work_dir / "dos.out",
                nproc=4, cancel_event=cancel_event, proc_holder=proc_holder,
            )
            res.dos_ok = True
            note("[PROPS] dos.x terminé — DOS calculée.")
        except Exception as ex:  # noqa: BLE001
            if cancel_event is not None and cancel_event.is_set():
                raise
            note(f"[PROPS] dos.x échoué : {ex} — DOS absente.")

    # --- 4. Bandes (ichamp = 3 uniquement).
    if ichamp >= 3:
        _execute_bands_chain(
            work_dir,
            scf_basename,
            nproc=nproc,
            res=res,
            note=note,
            cancel_event=cancel_event,
            proc_holder=proc_holder,
        )

    # --- 5. Parsing : E_Fermi, gap.
    res.fermi_eV = parse_nscf_fermi(work_dir)
    res.n_bands = parse_nscf_nbands(work_dir)
    if res.bands_ok:
        gp = parse_bands_gap(work_dir, fermi_eV=res.fermi_eV)
        res.gap_eV = gp["gap_eV"]
        res.vbm_eV = gp["vbm_eV"]
        res.cbm_eV = gp["cbm_eV"]
        res.gap_type = gp["type"]
        res.gap_direct = gp["direct"]

    # --- 6. Tracés gnuplot (best-effort).
    if res.dos_ok:
        spin_pol = _is_scf_spin_polarized(scf_path)
        e = run_gnuplot_edos(work_dir, fermi_eV=res.fermi_eV, is_spin_polarized=spin_pol)
        if e is not None:
            res.edos_image = e.name
            tag = " spin-résolue (up/down)" if spin_pol else ""
            note(f"[PROPS] Tracé DOS{tag} : {e.name}.")
    if res.bands_ok:
        b = run_gnuplot_ebands(work_dir, fermi_eV=res.fermi_eV)
        if b is not None:
            res.ebands_image = b.name
            note(f"[PROPS] Tracé bandes : {b.name}.")

    note(
        f"[PROPS] ===> résumé : ichamp={ichamp} | NSCF={res.nscf_ok} | "
        f"DOS={res.dos_ok} | bandes={res.bands_ok} | "
        f"E_F={res.fermi_eV} eV | gap={res.gap_eV} eV ({res.gap_type or '?'})"
    )
    return res

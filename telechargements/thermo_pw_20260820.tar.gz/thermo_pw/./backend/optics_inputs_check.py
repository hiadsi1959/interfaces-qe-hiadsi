"""
Inventaire et classification légère des fichiers .in optique sous inputs/<matériau>/.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Optional

import material_inputs as mi

_MAX_READ = 64 * 1024

_ROLE_LABELS: dict[str, str] = {
    "pw_vc_relax": "pw.x — vc-relax (maille d’équilibre préalable)",
    "pw_relax_only": "pw.x — relaxation coordonnées (relax)",
    "pw_scf": "pw.x — SCF optique",
    "pw_nscf": "pw.x — NSCF / bandes optique",
    "pw_other": "pw.x — autre calcul (&control)",
    "turbo_lanczos": "turbo_lanczos.x (TDDFT Lanczos)",
    "turbo_davidson": "turbo_davidson.x (Davidson)",
    "epsilon_post": "epsilon.x (post-traitement ε)",
    "thermo_pw_driver": "thermo_pw.x (entrée type thermo_pw.in)",
    "unclassified": "Fichier .in (rôle non reconnu)",
}

_CHAIN_STEP_IDS: list[tuple[str, str]] = [
    (
        "pw_vc_relax",
        "Relaxation volumique/coordonnées (avant série optique) — facultatif selon dossier",
    ),
    ("pw_scf", "SCF densité pour la série optique (maille convergée)"),
    ("pw_nscf", "NSCF / bands — nbnd large, grille k conforme tutoriel QE"),
    ("turbo_lanczos", "turbo TDDFT Lanczos (si votre chaîne)"),
    ("turbo_davidson", "turbo Davidson (si votre chaîne)"),
    ("epsilon_post", "epsilon.x (ε(ω) type RPA après NSCF conforme QE)"),
    ("thermo_pw_driver", "thermo_pw.x — entrées §1.26–1.27 selon votre what"),
]


def _read_text(path: Path) -> str:
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    if len(raw) > _MAX_READ:
        return raw[:_MAX_READ]
    return raw


def _first_pw_control_calculation(text: str) -> Optional[str]:
    m = re.search(r"&control\b", text, re.I)
    if not m:
        return None
    chunk = text[m.start() : m.start() + 12000]
    m2 = re.search(r"calculation\s*=\s*['\"]([^'\"]+)['\"]", chunk, re.I)
    return m2.group(1).strip().lower() if m2 else None


def classify_in_content(text: str, basename: str) -> tuple[set[str], Optional[str], Optional[str]]:
    """
    Retourne (rôles, calculation dans &control si lu, note optionnelle pour l’interface).
    """
    roles: set[str] = set()
    stem = Path(basename).stem.lower()
    b = basename.lower()
    pw_calc: Optional[str] = None
    classification_note: Optional[str] = None

    bn_flat = stem.replace("-", "").replace("_", "")
    if re.search(r"&lr_dav\b", text, re.I):
        roles.add("turbo_davidson")
    elif re.search(r"&lr_control\b", text, re.I) and re.search(
        r"&lr_input\b", text, re.I
    ):
        roles.add("turbo_lanczos")

    if re.search(r"&inputpp\b", text, re.I) and (
        re.search(r"calculation\s*=\s*['\"]eps['\"]", text, re.I)
        or re.search(r"calculation\s*=\s*['\"]epspot['\"]", text, re.I)
    ):
        roles.add("epsilon_post")
    elif re.search(r"&energy_grid\b", text, re.I) and re.search(
        r"&inputpp\b", text, re.I
    ):
        roles.add("epsilon_post")

    if b == "turbo_lanczos.in":
        roles.add("turbo_lanczos")
    if b == "turbo_davidson.in":
        roles.add("turbo_davidson")
    if b == "epsilon.in":
        roles.add("epsilon_post")

    if re.match(r"thermo_pw.*\.in$", b) or b == "thermo_pw.in":
        roles.add("thermo_pw_driver")

    non_pw = roles & {
        "turbo_davidson",
        "turbo_lanczos",
        "epsilon_post",
    }
    if not non_pw:
        calc = _first_pw_control_calculation(text)
        if calc:
            pw_calc = calc
            ck = calc.replace("_", "-")
            if ck in ("vc-relax", "vcrelax"):
                roles.add("pw_vc_relax")
            elif calc == "relax":
                roles.add("pw_relax_only")
            elif calc == "scf":
                roles.add("pw_scf")
            elif calc in ("nscf", "bands"):
                roles.add("pw_nscf")
            else:
                roles.add("pw_other")

    # Nom / extension : NSCF alors que calculation restée sur scf (copie gabarit SCF oubliée)
    fname_nscf_hint = ("nscf" in bn_flat) or ("bands" in stem)

    fname_nscf_hint = fname_nscf_hint and "pw_vc_relax" not in roles

    if (
        "pw_scf" in roles
        and fname_nscf_hint
        and pw_calc == "scf"
    ):
        roles.discard("pw_scf")
        roles.add("pw_nscf")
        classification_note = (
            "Le nom du fichier (« "
            + basename
            + " ») indique NSCF ou bandes, mais &CONTROL pose encore calculation='scf' — "
            "corrigez en calculation='nscf' (et nbnd…) pour une chaîne optique QE valide."
        )

    if not roles:
        roles.add("unclassified")

    return roles, pw_calc, classification_note


def build_report(mat_dir: Path, material_id: str) -> dict[str, Any]:
    mat_dir = mat_dir.resolve()
    files_out: list[dict[str, Any]] = []
    role_to_files: dict[str, list[str]] = {rid: [] for rid, _ in _CHAIN_STEP_IDS}

    for p in mi.list_in_files(mat_dir):
        text = _read_text(p)
        role_set, pw_calc, cnote = classify_in_content(text, p.name)
        role_list = sorted(role_set, key=lambda x: (_ROLE_LABELS.get(x, x), x))
        entry: dict[str, Any] = {
            "name": p.name,
            "roles": role_list,
            "role_labels": [_ROLE_LABELS.get(r, r) for r in role_list],
        }
        if pw_calc is not None:
            entry["pw_calculation"] = pw_calc
        if cnote:
            entry["classification_note"] = cnote
        files_out.append(entry)
        for r in role_set:
            if r in role_to_files:
                role_to_files[r].append(p.name)

    steps: list[dict[str, Any]] = []
    for rid, hint in _CHAIN_STEP_IDS:
        names = sorted(set(role_to_files.get(rid, [])), key=str.lower)
        steps.append(
            {
                "id": rid,
                "label": _ROLE_LABELS.get(rid, rid),
                "hint": hint,
                "ok": len(names) > 0,
                "files": names,
            }
        )

    return {
        "material_id": material_id,
        "mat_dir": str(mat_dir),
        "files": files_out,
        "steps": steps,
        "templates_readme_relative": "templates/optics/README_chaine_optique.txt",
    }


def report_for_material_param(material_id: str) -> Optional[dict[str, Any]]:
    mid = material_id.strip()
    if not mid:
        return None
    sub = mi._resolve_thermo_subdir(mid)
    if not sub or not sub.is_dir():
        return None
    canon = sub.name
    return build_report(sub, canon)

"""
Conversion CIF → gabarit d’entrée pw.x (Quantum ESPRESSO).

- ``ibrav = 0`` : trois vecteurs explicites (``CELL_PARAMETERS``), identiques à la maille lue par ASE depuis le CIF
  (souvent conventionnelle pour des réseaux centrés — dépend du fichier, pas d’un réglage « conventionnel » explicite).

- ``ibrav ≠ 0`` : maille de Bravais selon la convention QE (``celldm``, sans ``CELL_PARAMETERS``).
  Les positions fractionnaires restent celles du CIF dans la base ASE ; l’utilisateur doit vérifier la cohérence
  avec la définition QE du ``ibrav`` choisi (réduction primitive / ``nat`` / équivalences).

Pour ``ibrav ≠ 0``, post-traitement : suppression de ``CELL_PARAMETERS`` et injection de ``ibrav`` + ``celldm``.
Les ``celldm(i)`` sont en unités QE (ex. Bohr pour ``celldm(1)`` en cubique simple selon la doc).

Auto-remplissage minimal : ``ibrav = 1`` uniquement, si la maille du CIF est cubique (|a−b|, … et angles ~90°).

Option ``use_crystal_sg`` : positions au format QE ``ATOMIC_POSITIONS crystal_sg`` et ``space_group`` (ITA)
dans ``&SYSTEM``, avec uniquement les sites inéquivalents extraits du CIF — QE régénère les atomes équivalents
(voir INPUT_PW). Nécessite un groupe d’espace présent dans les métadonnées ASE après lecture du CIF.
Les coordonnées fractionnaires doivent rester cohérentes avec la maille primitive associée au jeu ``ibrav``/maille lue.

Option ``infer_ibrav`` : déduit ``ibrav ≠ 0`` et les ``celldm`` à partir du symbole de Pearson ITA (prioritaire si le CIF
porte un groupe d’espace reconnu par ASE), sinon heuristiques sur les paramètres de maille et les vecteurs de cellule
(cubiques primitifs FCC/BCC, hexagonal, tétragonal, orthorhombique simple, rhomboédrique, triclinique).
Pour certaines classes (orthorhombique centrée, monoclinique, etc.) l’inférence peut échouer : utiliser ``ibrav=0``
ou des ``celldm`` manuels.
"""
from __future__ import annotations

import io
import math
import re
from typing import Any, Optional

import numpy as np

from ase import Atoms
from ase.io import read
from ase.io.espresso import write_espresso_in
from ase.spacegroup import Spacegroup
from ase.spacegroup.crystal_data import get_bravais_class

# CODATA 2006 — cohérent avec ASE/QE internes (Å → Bohr pour celldm(1) type SC).
_BOHR_TO_ANGSTROM = 0.52917720859


def atoms_from_cif_string(cif_text: str) -> Atoms:
    """Lit une structure depuis une chaîne CIF."""
    t = (cif_text or "").strip()
    if not t:
        raise ValueError("Contenu CIF vide.")
    atoms = read(io.StringIO(t), format="cif")
    if not isinstance(atoms, Atoms):
        raise ValueError("Le fichier CIF doit décrire une seule structure.")
    return atoms


def default_pseudopotentials(symbols: list[str]) -> dict[str, str]:
    """Noms de fichiers factices par espèce (à adapter avant tout calcul réel)."""
    out: dict[str, str] = {}
    for s in sorted(set(symbols)):
        out[s] = f"{s}.UPF"
    return out


def auto_celldm_ibrav1_simple_cubic(
    atoms: Atoms, *, tol_length: float = 5e-4, tol_angle: float = 0.5
) -> Optional[dict[int, float]]:
    """
    Si la maille du CIF est cubique (a=b=c, α=β=γ=90°), retourne {1: a_Bohr} pour ibrav=1.
    Sinon None (il faudra fournir ``celldm`` explicitement pour un autre ``ibrav``).
    """
    cp = atoms.cell.cellpar()
    a, b, c, alpha, beta, gamma = (float(x) for x in cp)
    if max(abs(a - b), abs(b - c), abs(a - c)) > tol_length:
        return None
    if max(abs(alpha - 90), abs(beta - 90), abs(gamma - 90)) > tol_angle:
        return None
    celldm1_bohr = a / _BOHR_TO_ANGSTROM
    return {1: celldm1_bohr}


def _pearson_to_ibrav(pearson: str) -> int:
    """Symbole de Pearson ASE → indice ``ibrav`` Quantum ESPRESSO (cas usuels)."""
    p = (pearson or "").strip()
    lut: dict[str, int] = {
        "cP": 1,
        "cF": 2,
        "cI": 3,
        "hP": 4,
        "hp": 4,
        "hR": 5,
        "tP": 6,
        "tp": 6,
        "tI": 7,
        "oP": 8,
        "op": 8,
        "oS": 9,
        "oC": 9,
        "oc": 9,
        "oF": 10,
        "oI": 11,
        "mP": 12,
        "mp": 12,
        "mC": 13,
        "mS": 13,
        "aP": 14,
    }
    if p not in lut:
        raise ValueError(
            f"Symbole de Pearson « {p} » : passage automatique vers un ibrav QE non pris en charge. "
            "Choisissez ibrav et celldm manuellement ou utilisez ibrav=0."
        )
    return lut[p]


def _fcc_bcc_or_simple_from_cell(cell: np.ndarray, tol_l_rel: float) -> str:
    """Cubique : discriminer masque primitif cP / cF / cI à partir des cosinus entre vecteurs de maille."""
    norms = np.linalg.norm(cell, axis=1).astype(float)
    scale = float(np.max(norms))
    if scale <= 0:
        return "cP"
    tol_n = max(tol_l_rel * scale, 1e-6)
    if abs(float(np.max(norms) - np.min(norms))) > tol_n:
        return "oP"
    L = float(np.mean(norms))
    cos01 = float(np.dot(cell[0], cell[1]) / (norms[0] * norms[1]))
    if abs(cos01) <= 0.1:
        return "cP"
    if abs(cos01 - 0.5) <= 0.1:
        return "cF"
    if abs(cos01 + 1.0 / 3.0) <= 0.1:
        return "cI"
    return "cP"


def infer_pearson_symbol(atoms: Atoms, *, tol_length_rel: float = 5e-4, tol_angle: float = 0.85) -> tuple[str, str]:
    """
    Retourne (symbole Pearson, source) avec ``source`` ``space_group`` ou ``geometry``.
    """
    sg = atoms.info.get("spacegroup")
    if sg is not None:
        no = int(sg.no) if hasattr(sg, "no") else int(sg)
        # ASE assigne P1 (IT=1) quand le CIF ne contient pas de symétrie : ne pas en déduire aP.
        if no > 1:
            cls = get_bravais_class(no)
            return cls.pearson_symbol, f"space_group_IT={no}"

    cp = atoms.cell.cellpar()
    a, b, c, alpha, beta, gamma = (float(cp[i]) for i in range(6))
    scale = max(a, b, c, 1e-12)
    tol_l = max(tol_length_rel * scale, 1e-8)

    # Hexagonal (γ ≈ 120°) — avant tout bloc a=b=c (primitive FCC a aussi α=β=γ=60°)
    if (
        abs(a - b) < tol_l
        and abs(gamma - 120.0) < 2.5
        and abs(alpha - 90.0) < tol_angle
        and abs(beta - 90.0) < tol_angle
    ):
        return "hP", "geometry"

    # a = b = c : cubique (primitif SC/FCC/BCC) ou vrai rhomboédrique
    if abs(a - b) < tol_l and abs(b - c) < tol_l:
        kind = _fcc_bcc_or_simple_from_cell(atoms.cell.array, tol_length_rel)
        if kind in ("cP", "cF", "cI"):
            return kind, "geometry"
        if (
            abs(alpha - beta) < tol_angle
            and abs(beta - gamma) < tol_angle
            and abs(alpha - 90.0) > 2.5
        ):
            return "hR", "geometry"

    ortho = max(abs(alpha - 90.0), abs(beta - 90.0), abs(gamma - 90.0)) < tol_angle

    if ortho:
        if abs(a - b) < tol_l and abs(b - c) < tol_l:
            return _fcc_bcc_or_simple_from_cell(atoms.cell.array, tol_length_rel), "geometry"
        if abs(a - b) < tol_l and abs(a - c) > tol_l:
            return "tP", "geometry"
        return "oP", "geometry"

    raise ValueError(
        "Inférence géométrique impossible sans groupe d'espace : maille non orthogonale ou ambiguë. "
        "Ajoutez les données de symétrie au CIF ou utilisez ibrav / celldm explicites (ou ibrav=0)."
    )


def _cubic_conventional_edge(atoms: Atoms, pearson: str) -> float:
    """Arête de la maille cubique conventionnelle (Å) pour cP / cF / cI."""
    cp = atoms.cell.cellpar()
    a, b, c, alpha, beta, gamma = (float(cp[i]) for i in range(6))
    tol_a = 0.85
    ortho = max(abs(alpha - 90.0), abs(beta - 90.0), abs(gamma - 90.0)) < tol_a
    scale = max(a, b, c, 1e-12)
    tol_l = max(5e-4 * scale, 1e-8)
    if pearson == "cP":
        if not ortho:
            raise ValueError("Cubique simple attendu (angles ~ 90°) — détection ambiguë.")
        return float(a)

    if pearson not in ("cF", "cI"):
        raise ValueError(f"_cubic_conventional_edge : pearson {pearson} non cubique centré.")

    if ortho and abs(a - b) < tol_l and abs(b - c) < tol_l:
        return float(a)

    cell = atoms.cell.array
    norms = np.linalg.norm(cell, axis=1).astype(float)
    if abs(float(np.max(norms) - np.min(norms))) > tol_l:
        raise ValueError(
            "Maille cubique centrée attendue (vecteurs de même longueur en repère primitif) — "
            "vérifiez le CIF ou passez en ibrav=0."
        )
    L = float(np.mean(norms))
    cos01 = float(np.dot(cell[0], cell[1]) / (norms[0] * norms[1]))
    if pearson == "cF":
        if abs(cos01 - 0.5) > 0.12:
            raise ValueError(
                "Géométrie incompatible avec une primitive FCC standard (cos θ entre vecteurs ≠ 1/2). "
                "Utilisez ibrav=0 ou des paramètres manuels."
            )
        return L * math.sqrt(2.0)
    if abs(cos01 + 1.0 / 3.0) > 0.12:
        raise ValueError(
            "Géométrie incompatible avec une primitive BCC standard (cos θ ≠ −1/3). "
            "Utilisez ibrav=0 ou des paramètres manuels."
        )
    return 2.0 * L / math.sqrt(3.0)


def celldm_from_pearson(pearson: str, atoms: Atoms) -> dict[int, float]:
    """Construit ``celldm`` (indices 1…6, valeurs en unités QE) pour le symbole de Pearson."""
    cp = atoms.cell.cellpar()
    a, b, c, alpha, beta, gamma = (float(cp[i]) for i in range(6))
    Bo = _BOHR_TO_ANGSTROM

    if pearson in ("cP", "cF", "cI"):
        edge = _cubic_conventional_edge(atoms, pearson)
        return {1: edge / Bo}

    if pearson in ("hP", "hp"):
        return {1: a / Bo, 3: c / a}

    if pearson == "hR":
        return {1: a / Bo, 4: math.cos(math.radians(alpha))}

    if pearson in ("tP", "tp", "tI"):
        return {1: a / Bo, 3: c / a}

    if pearson in ("oP", "op"):
        return {1: a / Bo, 2: b / a, 3: c / a}

    if pearson in ("oF", "oI"):
        return {1: a / Bo, 2: b / a, 3: c / a}

    if pearson in ("oS", "oC", "oc", "mP", "mp", "mC", "mS"):
        raise ValueError(
            f"Pearson « {pearson} » : celldm automatiques non disponibles pour cette classe "
            "(voir INPUT_PW). Utilisez ibrav=0 avec CELL_PARAMETERS ou fournissez celldm à la main."
        )

    if pearson == "aP":
        return {
            1: a / Bo,
            2: b / a,
            3: c / a,
            4: math.cos(math.radians(alpha)),
            5: math.cos(math.radians(beta)),
            6: math.cos(math.radians(gamma)),
        }

    raise ValueError(f"Pearson « {pearson} » non géré pour celldm automatiques.")


def infer_bravais_qe(atoms: Atoms) -> tuple[int, dict[int, float], dict[str, Any]]:
    """
    Déduit ``ibrav`` et ``celldm`` au sens QE à partir du CIF déjà chargé dans ``atoms``.
    """
    pearson, src = infer_pearson_symbol(atoms)
    ibrav = _pearson_to_ibrav(pearson)
    celldm_map = celldm_from_pearson(pearson, atoms)
    meta = {"pearson_symbol": pearson, "infer_source": src, "infer_ibrav": True}
    return ibrav, celldm_map, meta


_CELL_PARAMETERS_BLOCK = re.compile(
    r"^CELL_PARAMETERS[^\n]*\n(?:[^\n]+\n){3}\s*\n",
    flags=re.MULTILINE,
)


def _normalize_celldm(raw: Any) -> dict[int, float]:
    """Accepte dict JSON avec clés '1' ou 1, ou liste ordonnée [celldm1, celldm2, …]."""
    out: dict[int, float] = {}
    if raw is None:
        return out
    if isinstance(raw, dict):
        for k, v in raw.items():
            ki = int(k)
            if ki < 1 or ki > 6:
                raise ValueError(f"celldm({ki}) invalide (indices QE 1…6).")
            fv = float(v)
            if fv != fv:  # NaN
                raise ValueError(f"celldm({ki}) n’est pas un nombre valide.")
            out[ki] = fv
        return out
    if isinstance(raw, list):
        for i, v in enumerate(raw, start=1):
            if v is None:
                continue
            fv = float(v)
            if fv != fv:
                raise ValueError(f"celldm({i}) n’est pas un nombre valide.")
            out[i] = fv
        return out
    raise ValueError("celldm doit être un objet { \"1\": … } ou une liste [ … ].")


def _atoms_asymmetric_unit(atoms: Atoms, *, tol: float = 1e-4) -> tuple[Atoms, int]:
    """
    Sous-ensemble d’atomes (sites cristallographiques inéquivalents) et numéro IT du groupe d’espace.
    """
    sg = atoms.info.get("spacegroup")
    if sg is None:
        raise ValueError(
            "Symétrie « crystal_sg » : groupe d’espace absent après lecture du CIF "
            "(vérifiez _space_group_IT_number ou l’équivalent dans le fichier). "
            "Décochez l’option ou complétez le CIF."
        )
    spg = sg if isinstance(sg, Spacegroup) else Spacegroup(int(sg))
    no = int(spg.no)
    scaled = atoms.get_scaled_positions(wrap=True)
    remaining = list(range(len(atoms)))
    kept: list[int] = []
    while remaining:
        i = remaining[0]
        kept.append(i)
        sites, _ = spg.equivalent_sites(scaled[i])

        def equiv_to_i(j: int) -> bool:
            return any(np.allclose(scaled[j], s, atol=tol) for s in sites)

        remaining = [j for j in remaining[1:] if not equiv_to_i(j)]
    return atoms[kept], no


_CRYSTAL_POS_CARD = re.compile(
    r"^ATOMIC_POSITIONS\s+crystal\s*$",
    flags=re.MULTILINE | re.IGNORECASE,
)


def _patch_atomic_positions_crystal_sg(pw_text: str) -> str:
    text2, n = _CRYSTAL_POS_CARD.subn("ATOMIC_POSITIONS crystal_sg", pw_text, count=1)
    if n != 1:
        raise ValueError(
            "Impossible de passer en crystal_sg : carte « ATOMIC_POSITIONS crystal » introuvable."
        )
    return text2


def rewrite_pw_for_nonzero_ibrav(pw_text: str, ibrav: int, celldm: dict[int, float]) -> str:
    """Retire CELL_PARAMETERS et remplace ``ibrav = 0`` par ``ibrav`` + lignes ``celldm``."""
    if ibrav == 0:
        return pw_text
    if not celldm:
        raise ValueError("celldm requis pour ibrav≠0 (ou utilisez ibrav=0).")
    text = _CELL_PARAMETERS_BLOCK.sub("", pw_text)

    def repl(m: re.Match[str]) -> str:
        indent = m.group(1)
        lines = [f"{indent}ibrav = {int(ibrav)}"]
        for i in sorted(celldm.keys()):
            lines.append(f"{indent}celldm({i}) = {float(celldm[i]):.14f}")
        return "\n".join(lines)

    text2, n = re.subn(
        r"^(\s*)ibrav\s*=\s*0\s*$",
        repl,
        text,
        count=1,
        flags=re.MULTILINE,
    )
    if n != 1:
        raise ValueError(
            "Post-traitement ibrav impossible : ligne « ibrav = 0 » introuvable dans la sortie ASE."
        )
    return text2


def build_pw_input_from_cif(
    cif_text: str,
    *,
    ibrav: int = 0,
    celldm: Optional[Any] = None,
    pseudopotentials: Optional[dict[str, str]] = None,
    ecutwfc: float = 40.0,
    ecutrho: float = 320.0,
    kpts: tuple[int, int, int] = (4, 4, 4),
    crystal_coordinates: bool = True,
    conv_thr: float = 1.0e-6,
    use_crystal_sg: bool = False,
    infer_ibrav: bool = False,
) -> tuple[str, dict[str, Any]]:
    """
    Retourne (texte pw.in, méta : espèces, ibrav effectif, celldm utilisé).
    """
    atoms = atoms_from_cif_string(cif_text)
    meta_extra: dict[str, Any] = {}
    nat_in = len(atoms)
    space_group_ita: Optional[int] = None

    if use_crystal_sg:
        if not crystal_coordinates:
            raise ValueError(
                "use_crystal_sg exige des positions fractionnaires : activez crystal_coordinates "
                "(ou laissez la valeur par défaut)."
            )
        atoms, space_group_ita = _atoms_asymmetric_unit(atoms)
        meta_extra["use_crystal_sg"] = True
        meta_extra["nat_original"] = nat_in
        meta_extra["nat_asymmetric_unit"] = len(atoms)
        meta_extra["space_group_ita"] = space_group_ita

    symbols = atoms.get_chemical_symbols()
    pseudo = pseudopotentials if pseudopotentials is not None else default_pseudopotentials(symbols)
    missing = set(symbols) - set(pseudo.keys())
    if missing:
        raise ValueError(f"pseudopotentials incomplet — manque : {sorted(missing)}.")

    input_data: dict[str, Any] = {
        "control": {"calculation": "scf", "verbosity": "high"},
        "system": {"ecutwfc": float(ecutwfc), "ecutrho": float(ecutrho)},
        "electrons": {"conv_thr": float(conv_thr)},
    }
    if space_group_ita is not None:
        input_data["system"]["space_group"] = int(space_group_ita)

    buf = io.StringIO()
    write_espresso_in(
        buf,
        atoms,
        input_data=input_data,
        pseudopotentials=pseudo,
        kpts=kpts,
        crystal_coordinates=crystal_coordinates,
    )
    text = buf.getvalue()

    cd_norm = _normalize_celldm(celldm)
    ib = int(ibrav)
    infer_bundle: dict[str, Any] = {}

    if infer_ibrav:
        ib_auto, cd_auto, infer_bundle = infer_bravais_qe(atoms)
        ib = ib_auto
        cd_norm = {**cd_auto, **cd_norm}

    meta: dict[str, Any] = {
        "ibrav_requested": ib,
        "species": sorted(set(symbols)),
        "celldm": None,
        **meta_extra,
        **infer_bundle,
    }

    if ib == 0:
        meta["celldm"] = {}
        if use_crystal_sg:
            text = _patch_atomic_positions_crystal_sg(text)
        return text, meta

    cd_use = dict(cd_norm)
    if not cd_use and ib == 1 and not infer_ibrav:
        auto = auto_celldm_ibrav1_simple_cubic(atoms)
        if auto:
            cd_use = auto
            meta["celldm_auto"] = True

    if infer_ibrav and cd_use:
        meta.setdefault("celldm_auto", True)

    if not cd_use:
        raise ValueError(
            "Pour ce ibrav≠0, fournissez celldm (voir doc QE pour votre Bravais). "
            "Activez « infer_ibrav » pour un remplissage automatique depuis la maille / le groupe d’espace, "
            "ou utilisez ibrav=0 avec CELL_PARAMETERS (recommandé si doute)."
        )

    meta["celldm"] = cd_use
    meta["celldm_auto"] = meta.get("celldm_auto", False)
    meta["qe_convention_warning_fr"] = (
        "Les coordonnées sont encore celles du CIF (fractionnaires ASE). Pour ce ibrav, vérifiez "
        "qu’elles coïncident avec la définition QE (primitive / réduction éventuelle)."
    )
    if use_crystal_sg:
        meta["qe_convention_warning_fr"] += (
            " Mode crystal_sg : positions = sites inéquivalents ; QE complète via space_group="
            f"{space_group_ita}."
        )
    text2 = rewrite_pw_for_nonzero_ibrav(text, ib, cd_use)
    if use_crystal_sg:
        text2 = _patch_atomic_positions_crystal_sg(text2)
    return text2, meta

"""
Édition d’inputs pw : chemins standard thermo_pw, renforcement des paramètres, sauvegarde contrôlée.
"""
from __future__ import annotations

import re
import shutil
from pathlib import Path

import config as cfg

_RE_OUTDIR = re.compile(
    r"^(\s*outdir\s*=\s*)([\'\"])(.*?)(\2)(.*)$", re.IGNORECASE | re.MULTILINE
)
_RE_PSEUDO = re.compile(
    r"^(\s*pseudo_dir\s*=\s*)([\'\"])(.*?)(\2)(.*)$", re.IGNORECASE | re.MULTILINE
)
_RE_CELLDM = re.compile(
    r"^(\s*celldm\(\s*1\s*\)\s*=\s*)([+-]?\d+\.?\d*[deDE]?[+-]?\d*)(.*)$",
    re.IGNORECASE | re.MULTILINE,
)


def _safe_mid(mid: str) -> str:
    t = re.sub(r"[^0-9A-Za-z._-]+", "_", (mid or "x").strip())[:64]
    return t or "x"


_RE_CONTROL_LINE = re.compile(r"^\s*&control\s*$", re.IGNORECASE | re.MULTILINE)


def _is_path_orphan_line(stripped: str) -> bool:
    """Lignes générées hors namelist par une ancienne version de apply_thermo_paths."""
    if stripped.startswith("! outdir (thermo_pw)") or stripped.startswith("! pseudo_dir (thermo_pw)"):
        return True
    if re.match(r"^(outdir|pseudo_dir)\s*=", stripped, re.IGNORECASE):
        return True
    return False


def _only_orphan_path_lines(s: str) -> bool:
    """Fichier sans namelist QE, uniquement le commentaire + outdir/pseudo orphelins."""
    if not (s or "").strip():
        return True
    if "&" in s:
        return False
    for line in s.splitlines():
        t = line.strip()
        if not t:
            continue
        if not _is_path_orphan_line(t):
            return False
    return True


def _prepend_control_namelist(rest: str, material_id: str, out_s: str, pse_s: str) -> str:
    """Préfixe un &CONTROL valide (obligatoire pour pw.x) ; le reste suit (ex. &SYSTEM)."""
    pfx = _safe_mid(material_id)
    block = f"""&CONTROL
    calculation = 'scf'
    restart_mode = 'from_scratch'
    prefix = '{pfx}'
    outdir = '{out_s}'
    pseudo_dir = '{pse_s}'
    verbosity = 'high'
/
"""
    r = (rest or "").strip()
    if r:
        return block + "\n" + r
    return block


def is_writable_input_path(p: Path) -> bool:
    p = p.expanduser().resolve()
    if p.suffix.lower() != ".in" or ".." in str(p):
        return False
    try:
        p.relative_to(cfg.INPUTS_DIR.resolve())
    except ValueError:
        return False
    return True


def apply_thermo_paths(content: str, material_id: str) -> str:
    """Définit outdir et pseudo_dir sous thermo_pw (outputs/<Mat> et pseudos/PBE)."""
    mid = _safe_mid(material_id)
    out_p = (cfg.OUTPUTS_DIR / mid).resolve()
    pse = cfg.PSEUDOS_DIR.resolve()
    out_s = str(out_p).replace("\\", "/")
    pse_s = str(pse).replace("\\", "/")
    if not pse_s.endswith("/"):
        pse_s += "/"
    if not out_s.endswith("/"):
        out_s += "/"
    s = content if isinstance(content, str) else ""
    m0 = _RE_CONTROL_LINE.search(s)
    if not m0:
        if _only_orphan_path_lines(s):
            s = ""
        return _prepend_control_namelist(s, material_id, out_s, pse_s)

    if _RE_OUTDIR.search(s):
        s = _RE_OUTDIR.sub(
            lambda m: f"{m.group(1)}'{out_s}'" + (m.group(5) or ""), s, count=1
        )
    else:
        pos = m0.end()
        s = s[:pos] + f"\n    outdir = '{out_s}'" + s[pos:]
    if _RE_PSEUDO.search(s):
        s = _RE_PSEUDO.sub(
            lambda m: f"{m.group(1)}'{pse_s}'" + (m.group(5) or ""), s, count=1
        )
    else:
        mo = re.search(r"(?im)^\s*outdir\s*=\s*.*$", s)
        if mo:
            pos = mo.end()
            s = s[:pos] + f"\n    pseudo_dir = '{pse_s}'" + s[pos:]
        else:
            pos = m0.end()
            s = s[:pos] + f"\n    pseudo_dir = '{pse_s}'" + s[pos:]
    return s


# `conv_thr_extra_exp` : combien d'ordres de grandeur PLUS strict (soustrait à l'exposant).
# L'API users pass `what='qha_lif'` → l'UI appelle reinforce_params(level='strict').
_REINFORCE_LEVELS = {
    # light → ecutwfc +10 %, conv_thr = 1.0D-(N+1) (10× plus strict).
    "light":  {"ecutwfc_factor": 1.10, "ecutrho_factor": 1.10, "conv_thr_extra_exp": 1},
    # medium → cutoffs +20 %, conv_thr = 1.0D-(N+2) (100× plus strict).
    "medium": {"ecutwfc_factor": 1.20, "ecutrho_factor": 1.20, "conv_thr_extra_exp": 2},
    # strict (Option 4 — LIF high-precision) : cutoffs +20 %, conv_thr ≤ 1.0D-(N+4)
    # (cible 1.0D-12 par défaut). NE PAS multiplier ecutrho (risque overshoot NC) —
    # l'utilisateur aligne manuellement ecutrho ≥ 8×ecutwfc s'il utilise des PAW.
    "strict": {"ecutwfc_factor": 1.20, "ecutrho_factor": 1.20, "conv_thr_extra_exp": 4},
}


def reinforce_params(content: str, level: str) -> str:
    """
    level: 'light'   — +10 % ecutwfc/ecutrho, conv_thr 10× plus strict (exposant -1).
            'medium'  — +20 % cutoffs, conv_thr 100× plus strict (exposant -2).
            'strict'  — +20 % cutoffs (ecutwfc / ecutrho, facteur commun 1.20),
                        conv_thr **1.0D-(N+4)** typiquement (cible LIF 1.0D-12).
                        NB : on ne multiplie PAS ecutrho par un facteur agressif (2.5×)
                        car cela overshoot pour les pseudos NC ; l'utilisateur aligne
                        manuellement ecutrho ≥ 8×ecutwfc s'il utilise des PAW.

    Effet sur la valeur ``D-`` :
      -8 + 1 (light) → -9 (1.0D-9, 10× plus strict) ✓ historique.
      -8 + 4 (strict) → -12 (1.0D-12, cible LIF) ✓.
      Bug corrigé : ancienne formule ``ex + exp_extra`` rendait la valeur plus LÂCHE
      (e.g. -8 + 1 = -7 ⇒ 1.0D-7, *dix fois moins strict*). Remplacée par ``ex - exp_extra``.
    """
    s = content
    lev = (level or "light").lower().strip()
    cfg_lev = _REINFORCE_LEVELS.get(lev) or _REINFORCE_LEVELS["light"]
    f_e = cfg_lev["ecutwfc_factor"]
    f_rho = cfg_lev["ecutrho_factor"]
    exp_extra = cfg_lev["conv_thr_extra_exp"]

    def bump_ecutwfc(m: re.Match) -> str:
        try:
            v = float(m.group(2).replace("d", "e").replace("D", "E"))
            nv = v * f_e
            return f"{m.group(1)}{nv:.1f}{m.group(3)}"
        except ValueError:
            return m.group(0)

    def bump_ecutrho(m: re.Match) -> str:
        try:
            v = float(m.group(2).replace("d", "e").replace("D", "E"))
            nv = v * f_rho
            return f"{m.group(1)}{nv:.1f}{m.group(3)}"
        except ValueError:
            return m.group(0)

    s = re.sub(
        r"^(\s*ecutwfc\s*=\s*)([+-]?\d+\.?\d*(?:[deDE][+-]?\d+)?)(.*)$",
        bump_ecutwfc,
        s,
        count=1,
        flags=re.MULTILINE | re.IGNORECASE,
    )
    s = re.sub(
        r"^(\s*ecutrho\s*=\s*)([+-]?\d+\.?\d*(?:[deDE][+-]?\d+)?)(.*)$",
        bump_ecutrho,
        s,
        count=1,
        flags=re.MULTILINE | re.IGNORECASE,
    )

    def strict_conv(m: re.Match) -> str:
        """Renforce ``conv_thr`` en soustrayant ``exp_extra`` à l'exposant.

        Logique : ``1.0D-N`` est d'autant PLUS strict que N est grand
        (``1.0D-12 < 1.0D-8``). On force donc ``ex_adj = ex - exp_extra`` (plus
        négatif ⇒ plus strict). On émet ensuite en notation toujours
        **négative** (jamais ``--9``) car on cible uniquement un resserrement.

        Tableau avant / après (exp_extra=4, strict) :
          1.0D-8  →  1.0D-12 ✅
          1.0D-10 →  1.0D-14 ✅
          1.0D-12 →  1.0D-16 ✅ (déjà strict ; on serre encore)

        Bug historique corrigé : l'ancienne formule ``ex + exp_extra`` produisait
        l'inverse (``1.0D-7`` au lieu de ``1.0D-9``, dix fois moins strict).
        """
        raw = m.group(2)
        up = raw.upper()
        if "D-" in up or "E-" in up or "D+" in up:
            try:
                if "D" in up:
                    base, exp_s = re.split(r"[dD]", raw, 1)
                    ex = int(exp_s)
                    # Toujours plus négatif (plus strict). Format garanti bien formé.
                    ex_adj = ex - exp_extra
                    sign = "-" if ex_adj <= 0 else "+"
                    return f"{m.group(1)}1.0D{sign}{abs(ex_adj)}{m.group(3)}"
            except (ValueError, IndexError):
                pass
        return m.group(0)

    s = re.sub(
        r"^(\s*conv_thr\s*=\s*)([^\s!]+)(.*)$",
        strict_conv,
        s,
        count=1,
        flags=re.MULTILINE | re.IGNORECASE,
    )

    # LIF / strict : commentaire repère posé par l'API pour traçabilité (visible dans le journal scf.in).
    if lev == "strict" and s and "REINFORCED_STRICT_LIF" not in s:
        marker = "! REINFORCED_STRICT_LIF — Option 4 LIF : pseudos stringency: high, conv_thr 1.0D-12.\n"
        if s.lstrip().startswith("&CONTROL") or s.lstrip().startswith("&SYSTEM") or s.lstrip().startswith("&control") or s.lstrip().startswith("&system"):
            s = marker + s
    return s


def save_input(path: Path, content: str) -> None:
    p = path.expanduser().resolve()
    if not is_writable_input_path(p):
        raise ValueError("Chemin de sauvegarde non autorisé (hors thermo_pw/inputs).")
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8", newline="\n")


def clean_outputs_for_material(material_id: str) -> dict:
    """Supprime le contenu (ou le dossier) thermo_pw/outputs/<Mat>."""
    mid = _safe_mid(material_id)
    root = cfg.OUTPUTS_DIR.resolve()
    d = (root / mid).resolve()
    try:
        d.relative_to(root)
    except ValueError as e:
        raise ValueError("Identifiant matériau invalide") from e
    removed_bytes = 0
    nfiles = 0
    if d.is_dir():
        for sub in d.rglob("*"):
            if sub.is_file():
                nfiles += 1
                try:
                    removed_bytes += sub.stat().st_size
                except OSError:
                    pass
        shutil.rmtree(d)
    d.mkdir(parents=True, exist_ok=True)
    (d / ".gitkeep").write_text("", encoding="utf-8")
    return {"ok": True, "cleared": str(d), "files_removed": nfiles, "bytes_approx": removed_bytes}

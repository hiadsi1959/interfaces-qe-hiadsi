"""
Lancement sûr de pw.x, ph.x, etc. (mpirun optionnel) avec vérification code retour.
"""
from __future__ import annotations

import os
import shutil   # Juillet 2026 : shutil.which pour le graceful fallback de
                # ``run_qe_stdin(nproc > 1)`` quand mpirun n'est pas dans PATH.
import signal
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, List, Optional

import config as cfg
from parsers.pw_out import job_completed_ok, ph_job_completed_ok


def _safe_qe_env(user_env: dict | None) -> dict:
    """Compose le ``env`` du sous-process QE avec une mitigation OOM-safe.

    Bug origine été 2026 : pour P1 Si nproc=4, ``thermo_pw.x`` était tué
    par SIGTERM dans ``cegterg`` (c_bands iterative diag) parce que chaque
    rang MPI spawnait par défaut autant de threads OpenMP que de CPU,
    ce qui multipliait le heap par-rank et déclenchait le tueur cgroup.

    Défaut : ``OMP_NUM_THREADS=1`` (collapses OpenMP per-rank heap) — appliqué
    UNIQUEMENT si l'utilisateur n'a pas déjà posé cette variable (ni dans
    ``os.environ``, ni via ``user_env``). On ne force jamais l'override
    silencieux d'un ``OMP_NUM_THREADS`` posé explicitement par l'utilisateur
    (HPC user qui sait ce qu'il fait).

    Sémantique (du plus prioritaire au moins) :
        1. ``user_env`` (caller explicite, e.g. ``env={"OMP_NUM_THREADS": "8"}``)
        2. ``os.environ`` (shell de l'utilisateur)
        3. ``OMP_NUM_THREADS=1`` (safe default appliqué seulement si 1+2 muets)
    """
    env = {**os.environ}
    # Défaut OMP_NUM_THREADS=1 seulement si absent OU explicitement vide
    # (``setdefault`` ne déclenche PAS sur valeur vide '' issue du shell —
    # donc on combine les deux conditions).
    if not env.get("OMP_NUM_THREADS"):
        env["OMP_NUM_THREADS"] = "1"
    if user_env:
        # Traite les valeurs ``None`` dans ``user_env`` comme « touche pas à
        # cette clé » : ``dict.update`` les écrirait littéralement sinon (et
        # ``OMP_NUM_THREADS=None`` casse le sous-process qui attends un str).
        env.update({k: v for k, v in user_env.items() if v is not None})
    return env

_LOG_TAIL_BYTES = 16000

# Message levé quand l’utilisateur annule via l’API (réconcilié côté api_server).
API_CANCEL_RUNTIME_MSG = "Annulé par l'utilisateur (API)."
_API_CANCEL_RUNTIME_MSG = API_CANCEL_RUNTIME_MSG


def _try_set_mem_rlimit() -> None:
    """Juillet 2026 (P3) - plafonner RLIMIT_AS du subprocess MPI (POSIX only).

    No-op silencieux si ``import resource`` indisponible (Windows) ou si
    ``cfg.MPI_RLIMIT_AS_BYTES`` vaut 0. Appelee via
    ``preexec_fn=_try_set_mem_rlimit`` du Popen ; executee dans le process enfant
    AVANT ``execve`` -> effet fige sur le binaire MPI (empeche thermo_pw.x
    de pousser l'OS a OOM-kill l'API).
    """
    if not getattr(cfg, "MPI_RLIMIT_AS_BYTES", 0):
        return
    try:
        import resource  # POSIX: absent sur Windows / containers verrouilles.
    except ImportError:
        return
    try:
        lim = int(cfg.MPI_RLIMIT_AS_BYTES)
        if lim > 0:
            resource.setrlimit(resource.RLIMIT_AS, (lim, lim))
    except (ValueError, OSError):
        pass




def _try_set_mem_rlimit() -> None:
    """Juillet 2026 (P3) - plafonner RLIMIT_AS du subprocess MPI (POSIX only).

    No-op silencieux si ``import resource`` indisponible (Windows) ou si
    ``cfg.MPI_RLIMIT_AS_BYTES`` vaut 0. Appelee via
    ``preexec_fn=_try_set_mem_rlimit`` du Popen ; executee dans le process enfant
    AVANT ``execve`` -> effet fige sur le binaire MPI (empeche thermo_pw.x
    de pousser l'OS a OOM-kill l'API).
    """
    if not getattr(cfg, "MPI_RLIMIT_AS_BYTES", 0):
        return
    try:
        import resource  # POSIX: absent sur Windows / containers verrouilles.
    except ImportError:
        return
    try:
        lim = int(cfg.MPI_RLIMIT_AS_BYTES)
        if lim > 0:
            resource.setrlimit(resource.RLIMIT_AS, (lim, lim))
    except (ValueError, OSError):
        pass




def _proc_holder_register(proc_holder: Optional[dict[str, Any]], proc: subprocess.Popen) -> None:
    if not proc_holder:
        return
    lock = proc_holder.get("lock")
    active = proc_holder.get("active")
    if lock is None or not isinstance(active, set):
        return
    with lock:
        active.add(proc)


def _proc_holder_unregister(proc_holder: Optional[dict[str, Any]], proc: subprocess.Popen) -> None:
    if not proc_holder:
        return
    lock = proc_holder.get("lock")
    active = proc_holder.get("active")
    if lock is None or not isinstance(active, set):
        return
    with lock:
        active.discard(proc)


def _terminate_mpi_children(proc: subprocess.Popen, grace_s: float = 2.5) -> None:
    """Arrête mpirun et rangs MPI : nouveau groupe de processus (start_new_session)."""
    if proc.poll() is not None:
        return
    try:
        pgid = os.getpgid(proc.pid)
        os.killpg(pgid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError, OSError):
        try:
            proc.terminate()
        except OSError:
            pass
    deadline = time.monotonic() + grace_s
    while time.monotonic() < deadline and proc.poll() is None:
        time.sleep(0.08)
    if proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        except (ProcessLookupError, PermissionError, OSError):
            try:
                proc.kill()
            except OSError:
                pass


def terminate_registered_processes(
    proc_holder: Optional[dict[str, Any]], *, grace_s: float = 2.5
) -> int:
    """Tue tous les sous-process MPI enregistrés dans ``proc_holder``.

    ``cancel_event`` seul ne suffit pas : il n'est lu que par la boucle
    d'attente du process courant. Si le thread/worker appelant meurt avant
    (erreur, pool démonté), les rangs MPI survivent en orphelins et le calcul
    continue de tourner alors que l'UI affiche « annulé ».
    """
    if not proc_holder:
        return 0
    lock = proc_holder.get("lock")
    active = proc_holder.get("active")
    if lock is None or not isinstance(active, set):
        return 0
    with lock:
        procs = list(active)
    killed = 0
    for proc in procs:
        try:
            if proc.poll() is None:
                _terminate_mpi_children(proc, grace_s=grace_s)
                killed += 1
        except (OSError, ValueError):
            continue
    return killed


def _apply_fi_provider_default(env_in: dict) -> dict:
    """Garantit un ``FI_PROVIDER`` sain pour les binaires QE lancés via ``run_qe_stdin``.

    Contexte (juillet 2026) : sur certains nœuds, ``dos.x`` segfault à
    ``MPI_Init`` avec ``OFI fi_getinfo() failed`` (provider fabric
    introuvable / cassé). Le workaround commun — controllable par env —
    est d’imposer un provider libfabric stable : ``tcp`` (portable),
    ``ofi_rxm`` (openib over sockets), ou ``verbs`` (InfiniBand natif).

    Hiérarchie d’override (fort → faible) :

      1. ``FI_PROVIDER`` dans ``env_in`` (déjà posé par l’utilisateur
         expert via shell)  — **priorité absolue** : renvoyé tel quel,
         aucune écrasure. Respecte le contrôle expert.
      2. ``cfg.FI_PROVIDER_DEFAULT`` (« tcp » par défaut, ou
         ``THERMO_FI_PROVIDER`` administratif)  — posé si absent.
      3. Sinon (cas impossible en pratique)  — dict inchangé.

    Note threadsafety : la fonction **copie** le dict (``{**env_in, ...}``)
    et NE MUT JAMAIS ``os.environ`` global. Deux appels concurrents avec
    des overrides différents n’interfèrent pas.

    Note scope : la fonction n’est câblée QUE dans ``run_qe_stdin``
    (ci-dessous) car le crash OFI observé concerne dos.x. ``run_qe``
    (pour pw.x / ph.x via mpirun) reste intact — à patcher séparément si
    un second crash MPI_Init apparaît.
    """
    env_out = dict(env_in)
    if "FI_PROVIDER" not in env_out:
        env_out["FI_PROVIDER"] = cfg.FI_PROVIDER_DEFAULT
    if "I_MPI_FABRICS" not in env_out:
        env_out["I_MPI_FABRICS"] = cfg.I_MPI_FABRICS_DEFAULT
    return env_out


def _wait_mpi_process(
    proc: subprocess.Popen,
    args: List[str],
    *,
    cancel_event: Optional[threading.Event],
    proc_holder: Optional[dict[str, Any]],
    poll_s: float = 0.22,
) -> subprocess.CompletedProcess:
    """Attente avec possibilité d’annulation (voir aussi POST …/jobs/<id>/cancel)."""
    _proc_holder_register(proc_holder, proc)
    try:
        while True:
            rc = proc.poll()
            if rc is not None:
                return subprocess.CompletedProcess(args, rc, stdout=b"", stderr=b"")
            if cancel_event is not None and cancel_event.is_set():
                _terminate_mpi_children(proc)
                proc.wait(timeout=60)
                return subprocess.CompletedProcess(args, proc.returncode if proc.returncode is not None else -9)
            time.sleep(poll_s)
    finally:
        _proc_holder_unregister(proc_holder, proc)


def _tail_text_file(path: Path, max_bytes: int = _LOG_TAIL_BYTES) -> str:
    """Dernières lignes d’un fichier texte (pour diagnostiquer les échecs pw.x)."""
    try:
        raw = path.read_bytes()
        if len(raw) > max_bytes:
            raw = "... [debut tronque] ...\n".encode("utf-8") + raw[-max_bytes:]
        return raw.decode("utf-8", errors="replace")
    except OSError as e:
        return f"(lecture impossible: {e})"


def which_mpirun() -> str:
    return os.environ.get("THERMO_MPIRUN", "mpirun")


def run_qe(
    args: List[str],
    *,
    work_dir: Path,
    log_file: Optional[Path] = None,
    env: Optional[dict] = None,
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
) -> subprocess.CompletedProcess:
    """
    Exécute une commande (ex. [mpirun, -np, 4, .../pw.x, -in, file.in]).
    Lève RuntimeError si returncode != 0 (ou annulation utilisateur).
    Si cancel_event ou proc_holder est fourni : ``Popen`` + groupe MPI pour permettre l’arrêt via l’API.
    """
    work_dir = Path(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)
    env_m = _safe_qe_env(env)
    cancellable = cancel_event is not None or proc_holder is not None
    if log_file:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        with open(log_file, "w", encoding="utf-8") as lf:
            if cancellable:
                proc = subprocess.Popen(
                    args,
                    cwd=work_dir,
                    env=env_m,
                    stdout=lf,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,
                    preexec_fn=_try_set_mem_rlimit,
                )
                p = _wait_mpi_process(
                    proc, args, cancel_event=cancel_event, proc_holder=proc_holder
                )
            else:
                p = subprocess.run(
                    args,
                    cwd=work_dir,
                    env=env_m,
                    stdout=lf,
                    stderr=subprocess.STDOUT,
                    preexec_fn=_try_set_mem_rlimit,
                )
    else:
        if cancellable:
            proc = subprocess.Popen(
                args,
                cwd=work_dir,
                env=env_m,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                start_new_session=True,
                preexec_fn=_try_set_mem_rlimit,
            )
            p = _wait_mpi_process(
                proc, args, cancel_event=cancel_event, proc_holder=proc_holder
            )
        else:
            p = subprocess.run(
                args,
                cwd=work_dir,
                env=env_m,
                capture_output=True,
                text=True,
                preexec_fn=_try_set_mem_rlimit,
            )
    if cancel_event is not None and cancel_event.is_set():
        raise RuntimeError(API_CANCEL_RUNTIME_MSG)
    if p.returncode != 0:
        msg = f"Commande échouée (code {p.returncode}): {' '.join(args)}"
        if log_file and Path(log_file).is_file():
            msg += f"\n\n--- Journal ({log_file}) — fin du fichier ---\n{_tail_text_file(Path(log_file))}"
        elif not log_file and getattr(p, "stderr", None):
            msg += f"\n{p.stderr}"
        raise RuntimeError(msg)
    return p


def run_mpi_stdio_on_open_log(
    args: List[str],
    *,
    cwd: Path,
    stdout_f,
    stdin_f=None,
    env: Optional[dict] = None,
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
) -> subprocess.CompletedProcess:
    """
    Lance une commande MPI avec journaux déjà ouverts (ex. thermo_pw après en-tête).
    ``stdin_f`` : objet fichier binaire déjà ouvert ou None.
    """
    cwd = Path(cwd).resolve()
    env_m = _safe_qe_env(env)
    proc = subprocess.Popen(
        args,
        cwd=cwd,
        stdin=stdin_f,
        stdout=stdout_f,
        stderr=subprocess.STDOUT,
        env=env_m,
        start_new_session=True,
    )
    return _wait_mpi_process(proc, args, cancel_event=cancel_event, proc_holder=proc_holder)


def run_mpirun_mpi_app_stdin(
    nproc: int,
    exe: Path,
    stdin_in: Path,
    work_dir: Path,
    log_file: Path,
) -> None:
    """Lance thermo_pw.x (ou assimilé QE) avec ``-inp <nom>``.

    Quantum ESPresso ``open_input_file`` peut être appelé plusieurs fois pendant un run ;
    avec ``< fichier`` le flux stdin n’est consommé qu’une fois, ce qui conduit à une
    seconde lecture vide puis souvent une erreur Intel Fortran sévère 28 au ``CLOSE``
    après « Waiting for input ». Utiliser toujours ``-inp`` lorsque la ligne de commande
    doit fournir le fichier PW (voir ``Modules/open_close_input_file.f90``).
    """
    m = which_mpirun()
    work_dir = Path(work_dir).resolve()
    stdin_in = Path(stdin_in)
    work_dir.mkdir(parents=True, exist_ok=True)
    log_file.parent.mkdir(parents=True, exist_ok=True)
    if not stdin_in.is_file():
        raise RuntimeError(f"Entrée introuvable pour -inp : {stdin_in}")
    try:
        stdin_in.relative_to(work_dir.resolve())
    except ValueError as e:
        raise RuntimeError(f"Pour -inp, le fichier doit être sous work_dir ({work_dir}) : {stdin_in}") from e
    inp_name = stdin_in.name
    with open(log_file, "w", encoding="utf-8") as lf:
        p = subprocess.run(
            [m, "-np", str(nproc), str(exe), "-inp", inp_name],
            cwd=work_dir,
            stdout=lf,
            stderr=subprocess.STDOUT,
            env={**os.environ},
        )
    if p.returncode != 0:
        raise RuntimeError(f"{exe} a échoué (code {p.returncode}) — voir {log_file}")


def run_qe_stdin(
    exe: Path,
    inp: Path,
    work_dir: Path,
    log_file: Path,
    *,
    nproc: int = 1,
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
) -> None:
    """Exécutable lit l'entrée sur stdin (ex. q2r.x, matdyn.x, dos.x, band.x).

    Juillet 2026 — paramètre ``nproc`` ajouté : lorsque ``nproc > 1``, la
    commande est wrappée dans ``mpirun -np K <exe>`` avec ``FI_PROVIDER``
    injecté par ``_apply_fi_provider_default`` (défaut ``tcp``, override
    ``THERMO_FI_PROVIDER``). Cas d'usage : ``dos.x`` et ``band.x`` en
    environnement HPC/libfabric exigent le transport MPI même pour ~1
    socket de calcul ; en single-process, ``MPI_Init`` peut segfauler
    (cf. ``ofi fi_getinfo() failed``). Fallback gracieux : si
    ``which_mpirun()`` retourne un binaire inexistant et ``nproc > 1``,
    on bascule en single-process (logué via ``RuntimeError`` si
    l'utilisateur passe ``raise_on_no_mpirun=True`` plus tard).

    Si ``nproc <= 1`` (défaut) : backward-compat — exécution single-process
    inchangée (q2r.x, matdyn.x historiques). Aucune migration des
    appelants existants nécessaire.

    Wrapper ``_apply_fi_provider_default`` applique ``FI_PROVIDER`` en
    amont : voir docstring du helper pour la hiérarchie d'override
    (``FI_PROVIDER`` shell > ``THERMO_FI_PROVIDER`` admin > ``tcp`` defaut).
    """
    work_dir = Path(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)
    log_file.parent.mkdir(parents=True, exist_ok=True)
    nproc = max(0, int(nproc))
    if nproc > 1:
        m = which_mpirun()
        # Graceful fallback (Juillet 2026) : si ``mpirun`` n'est pas résolvable
        # (pas dans PATH, ou ``THERMO_MPIRUN`` pointe vers un chemin inexistant),
        # on retombe sur single-process plutôt que de faire échouer le binaire
        # QE avec un FileNotFoundError brut. La note explicite est APPENDée au
        # log_file APRÈS l'exécution (sinon le ``open(log_file, "w")`` du bloc
        # ``subprocess.run`` la tronquerait).
        if shutil.which(m):
            cmd = [m, "-np", str(nproc), str(exe)]
            fallback_note = None
        else:
            cmd = [str(exe)]
            fallback_note = (
                f"\n[NOTE THERMO_PW] mpirun introuvable (résolu='{m}', "
                f"nproc demandé={nproc}) -- fallback single-process "
                f"{exe}.\n"
            )
    else:
        cmd = [str(exe)]
        fallback_note = None
    cancellable = cancel_event is not None or proc_holder is not None
    with open(inp, "r", encoding="utf-8") as inf, open(log_file, "w", encoding="utf-8") as lf:
        if cancellable:
            proc = subprocess.Popen(
                cmd,
                cwd=work_dir,
                stdin=inf,
                stdout=lf,
                stderr=subprocess.STDOUT,
                env=_apply_fi_provider_default(os.environ),
                start_new_session=True,
            )
            p = _wait_mpi_process(
                proc, cmd, cancel_event=cancel_event, proc_holder=proc_holder
            )
        else:
            p = subprocess.run(
                cmd,
                cwd=work_dir,
                stdin=inf,
                stdout=lf,
                stderr=subprocess.STDOUT,
                env=_apply_fi_provider_default(os.environ),
            )
    if cancel_event is not None and cancel_event.is_set():
        raise RuntimeError(API_CANCEL_RUNTIME_MSG)
    if fallback_note:
        try:
            with open(log_file, "a", encoding="utf-8") as lf:
                lf.write(fallback_note)
        except OSError:
            pass
    if p.returncode != 0:
        raise RuntimeError(
            f"{exe} a échoué (code {p.returncode}) via {' '.join(cmd)}"
        )


def run_pw_x_in(
    work_dir: Path,
    in_name: str,
    nproc: Optional[int] = None,
    *,
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
) -> Path:
    """Lance mpirun -np nproc pw.x < in_name > in_name.out. Retourne le chemin .out."""
    nproc = nproc or cfg.MPI_NPROC
    inp = work_dir / in_name
    out = work_dir / (Path(in_name).stem + ".out")
    m = which_mpirun()
    run_qe(
        [m, "-np", str(nproc), str(cfg.pw_path()), "-in", in_name],
        work_dir=work_dir,
        log_file=out,
        cancel_event=cancel_event,
        proc_holder=proc_holder,
    )
    # MPI / FS : le journal peut être encore incomplet à la sortie de mpirun ; on réessaie un court instant.
    for _ in range(30):
        if out.is_file() and job_completed_ok(out):
            return out
        time.sleep(0.1)
    detail = _tail_text_file(out) if out.is_file() else "(fichier .out absent)"
    raise RuntimeError(
        f"pw.x n'a pas produit une fin valide (recherche de « job done ») : {out}\n\n"
        f"--- Fin du journal (diagnostic) ---\n{detail}"
    )


def run_mpi_exe_in(
    work_dir: Path,
    exe: Path,
    in_name: str,
    nproc: int,
    *,
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
) -> Path:
    """
    Lance mpirun -np nproc exe -in in_name ; journal -> <stem>.out
    (usage : turbo_*.x, epsilon.x, ou tout binaire QE compatible -in).
    """
    work_dir = Path(work_dir)
    exe = Path(exe)
    inp = work_dir / in_name
    if not inp.is_file():
        raise RuntimeError(f"Fichier d'entrée introuvable dans le run : {in_name}")
    out = work_dir / (Path(in_name).stem + ".out")
    m = which_mpirun()
    run_qe(
        [m, "-np", str(int(nproc)), str(exe), "-in", in_name],
        work_dir=work_dir,
        log_file=out,
        cancel_event=cancel_event,
        proc_holder=proc_holder,
    )
    return out


def run_ph_x_in(
    work_dir: Path,
    in_name: str,
    nproc: Optional[int] = None,
    *,
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
) -> Path:
    """Lance mpirun -np nproc ph.x -in in_name. Retourne le chemin .out."""
    nproc = nproc or cfg.MPI_NPROC
    work_dir = Path(work_dir)
    out = work_dir / (Path(in_name).stem + ".out")
    m = which_mpirun()
    run_qe(
        [m, "-np", str(nproc), str(cfg.ph_path()), "-in", in_name],
        work_dir=work_dir,
        log_file=out,
        cancel_event=cancel_event,
        proc_holder=proc_holder,
    )
    for _ in range(30):
        if out.is_file() and ph_job_completed_ok(out):
            return out
        time.sleep(0.1)
    detail = _tail_text_file(out) if out.is_file() else "(fichier .out absent)"
    raise RuntimeError(
        f"ph.x n'a pas produit une fin valide (recherche de « job done ») : {out}\n\n"
        f"--- Fin du journal (diagnostic) ---\n{detail}"
    )

"""
Task_Thermo : génère thermo_control, lance thermo_pw.x, journalise; graphiques optionnels.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Optional

import config as cfg
from qe_subprocess import run_mpirun_mpi_app_stdin
from qha_prereq_check import check_qha_prereqs, format_prereq_failure
from eos_paths import WORKFLOW_STATE_FILENAME
from state_db import TaskState, TaskStatus, WorkflowDB

THERMO_CTRL = "thermo_control"


def write_thermo_control(
    path: Path,
    *,
    what: str,
    tmin: float,
    tmax: float,
    deltat: float,
    fildyn: str,
    zasr: str,
    ltherm_dos: bool,
    ltherm_freq: bool,
    lsolve: Optional[int] = None,
) -> None:
    """Écrit ``thermo_control``. ``lsolve`` choisit le solveur moindres carrés.

    ``lsolve`` pilote l'ajustement polynomial de la surface d'énergie libre :
    1 = équations normales, 2 = factorisation QR (défaut de thermo_pw),
    3 = décomposition en valeurs singulières. Le paramètre est exposé parce que
    le défaut 2 passe par ``DGELS`` dans ``linsolvms``, et qu'un abandon à cette
    étape survient **après** toute la partie DFPT — sur le cas de référence,
    17 h de calcul perdues sur l'ajustement final. Pouvoir changer de solveur
    sans relancer les phonons évite ce gâchis.
    """
    lines = [
        "! Généré par backend / work_thermo",
        "&INPUT_THERMO",
        f"  what = '{what}',",
        f"  tmin = {tmin}D0,",
        f"  tmax = {tmax}D0,",
        f"  deltat = {deltat}D0,",
        f"  fildyn = '{fildyn}',",
        f"  zasr = '{zasr}',",
        f"  ltherm_dos = {'.true.' if ltherm_dos else '.false.'},",
        f"  ltherm_freq = {'.true.' if ltherm_freq else '.false.'},",
    ]
    if lsolve is not None:
        lines.append(f"  lsolve = {int(lsolve)},")
    lines.extend(["/", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def _parse_conv_thr_from_content(content: str) -> float | None:
    """Parse le paramètre `conv_thr` dans le contenu d'un fichier pw input.

    Retourne la valeur numérique (float) ou None si absent / non interprétable.
    """
    m = re.search(r"(?im)^\s*conv_thr\s*=\s*([^\s!,]+)", content)
    if not m:
        return None
    raw = m.group(1).strip()
    raw_up = raw.replace("D", "E").replace("d", "e")
    try:
        return float(raw_up)
    except ValueError:
        return None


def _check_conv_thr_in_input(in_pw_path: Path, required_max: float = 1.0e-12) -> None:
    """Vérifie que `conv_thr` dans `in_pw_path` est au plus `required_max`.

    Lève RuntimeError si la condition n'est pas remplie.
    """
    try:
        txt = in_pw_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        raise RuntimeError(f"Impossible de lire le fichier d'entrée SCF: {in_pw_path}")
    val = _parse_conv_thr_from_content(txt)
    if val is None:
        raise RuntimeError(
            "Paramètre `conv_thr` absent dans l'entrée SCF — pour les calculs 'ph_life' un `conv_thr` très strict (ex: 1.0D-12) est requis."
        )
    if val > required_max:
        raise RuntimeError(
            f"`conv_thr` ({val:.1e}) est trop lâche pour 'ph_life' ; requiert <= {required_max:.1e}. "
            "Applique `input_editor.reinforce_params(..., 'strict')` ou éditez scf.in manuellement."
        )


def _extract_pseudos_from_input(content: str) -> tuple[str, set[str]]:
    """Extrait `pseudo_dir` (si présent) et la liste des fichiers de pseudopotentiels référencés.

    Retourne (pseudo_dir, {filenames}). Si pseudo_dir absent retourne ('', set()).
    """
    pse_dir = ""
    m = re.search(r"(?im)^\s*pseudo_dir\s*=\s*['\"](.*?)['\"]", content)
    if m:
        pse_dir = m.group(1).strip()
    pse_files: set[str] = set()
    # Détecte ATOMIC_SPECIES et extrait le dernier token de chaque ligne.
    mo = re.search(
        r"(?ims)^\s*ATOMIC_SPECIES\s*(.*?)^(?=\s*$|\s*\w+\s*:|\s*&|\s*ATOMIC_POSITIONS|\s*CELL_PARAMETERS)",
        content,
    )
    if mo:
        block = mo.group(1)
        for line in block.splitlines():
            parts = line.split()
            if len(parts) >= 2:
                pse_files.add(parts[-1].strip())
    return pse_dir, pse_files


def _resolve_pseudo_dir(in_pw_path: Path, pseudo_dir: str) -> Path:
    """Résout `pseudo_dir` relatif ou absolu depuis l'entrée SCF."""
    if pseudo_dir:
        p = Path(pseudo_dir)
        if not p.is_absolute():
            p = (in_pw_path.parent / p).resolve()
    else:
        p = cfg.PSEUDOS_DIR.resolve()
    return p


def _resolve_pseudo_paths(in_pw_path: Path, pseudo_dir: Path, pse_files: set[str]) -> list[Path]:
    """Résout les chemins des pseudos référencés dans l'entrée SCF."""
    if not pse_files:
        return []
    paths: list[Path] = []
    for fn in pse_files:
        candidate = pseudo_dir / fn
        if candidate.is_file():
            paths.append(candidate)
            continue
        matches = list(pseudo_dir.rglob(fn))
        if matches:
            paths.extend(matches)
            continue
        raise RuntimeError(
            f"Pseudopotentiel référencé introuvable : '{fn}' dans {pseudo_dir}. "
            "Vérifiez le nom dans ATOMIC_SPECIES ou le chemin pseudo_dir."
        )
    return paths


def _check_pseudos_are_nc(in_pw_path: Path) -> None:
    """Vérifie que les pseudopotentiels référencés dans `in_pw_path` sont NC.

    Lève RuntimeError si un pseudo non-NC est détecté ou si aucun pseudo detectable.
    """
    try:
        txt = in_pw_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        raise RuntimeError(f"Impossible de lire l'entrée SCF: {in_pw_path}")

    pseudo_dir_raw, pse_files = _extract_pseudos_from_input(txt)
    pseudo_dir = _resolve_pseudo_dir(in_pw_path, pseudo_dir_raw)
    if not pseudo_dir.exists() or not pseudo_dir.is_dir():
        raise RuntimeError(
            f"Répertoire des pseudopotentiels introuvable: '{pseudo_dir}'. "
            "Assurez-vous que 'pseudo_dir' dans l'entrée SCF est correct ou que le dossier existe."
        )

    from lo_to_chain import check_pseudos_are_nc

    if pse_files:
        paths = _resolve_pseudo_paths(in_pw_path, pseudo_dir, pse_files)
        ok, messages = check_pseudos_are_nc(pseudo_dir, only_paths=paths)
        if not ok:
            raise RuntimeError(
                "Pseudopotentiels non Norm-Conserving détectés : "
                + "; ".join(messages)
                + ". Pour les calculs diélectriques (P5), utilisez des pseudos NC."
            )
        return

    ok, messages = check_pseudos_are_nc(pseudo_dir)
    if not ok:
        raise RuntimeError(
            "Pseudopotentiels non Norm-Conserving détectés dans le dossier "
            f"{pseudo_dir} : {'; '.join(messages)}. Pour les calculs diélectriques (P5), utilisez des pseudos NC."
        )


def _is_pseudo_file_norm_conserving(path: Path) -> bool:
    """Heuristique : lit le fichier (quelques Ko) et cherche des marqueurs NC.

    - UPF/XML peuvent contenir des attributs `type="NC"` ou mots 'norm-conserving'.
    - Si inconnu, renvoie False.
    """
    try:
        data = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    s = data[:8192].lower()
    # marqueurs communs (heuristique)
    if "norm-conserv" in s or 'type="nc"' in s or "pp_header" in s and "nc" in s:
        return True
    # some UPF labels contain '-n-' or '-nc-' tokens
    if "-n-" in path.name.lower() or "-nc-" in path.name.lower():
        return True
    return False


def task_thermo(
    work_dir: Path,
    material_id: str,
    in_pw: Path,
    db: WorkflowDB,
    fildyn: str = "dyn",
    what: str = "mur_lc_t",
) -> dict[str, Any]:
    """
    N’exécute le driver thermo que si les prérequis sont ok (configurablement).
    """
    require_phonon = str(work_dir / ".require_phonon_for_thermo")
    if require_phonon.is_file() and db.get_task("phonon").status != TaskStatus.DONE.value:
        raise RuntimeError("thermo_pw: étape phonon non DONE (fichier .require_phonon_for_thermo actif).")

    # Vérifications QHA / phonon de base
    prereq = check_qha_prereqs(work_dir, fildyn=fildyn, db=db)
    if not prereq.ok:
        raise RuntimeError(
            "QHA/thermo bloqué — prérequis phonon non satisfaits. "
            + format_prereq_failure(prereq)
        )

    # Vérifications spécifiques selon le 'what' demandé
    what_norm = (what or "").strip().lower()
    if what_norm in ("ph_life", "qha_lif"):
        # P4: durée de vie phonons — conv_thr strict requis
        _check_conv_thr_in_input(in_pw, required_max=1.0e-12)
    if what_norm in ("dielectric",):
        # P5: diélectrique — pseudos NC requis
        _check_pseudos_are_nc(in_pw)

    tdir = work_dir / "4_thermo"
    tdir.mkdir(parents=True, exist_ok=True)
    st = TaskState(status=TaskStatus.RUNNING.value, message="thermo_pw.x")
    db.set_task("thermo", st)
    db.save(work_dir / WORKFLOW_STATE_FILENAME)

    wctrl = tdir / THERMO_CTRL
    write_thermo_control(
        wctrl,
        what=what,
        tmin=0.0,
        tmax=1000.0,
        deltat=10.0,
        fildyn=fildyn,
        zasr="simple",
        ltherm_dos=True,
        ltherm_freq=False,
    )
    pwin = tdir / in_pw.name
    pwin.write_text(in_pw.read_text(encoding="utf-8", errors="replace"), encoding="utf-8")
    logf = tdir / "thermo_pw_run.log"
    run_mpirun_mpi_app_stdin(
        cfg.MPI_NPROC,
        cfg.thermo_pw_path(),
        pwin,
        tdir,
        logf,
    )
    # Parse minimale: pour tracé, l’utilisateur completera depuis fichiers ther*/gnuplot
    txt = logf.read_text(encoding="utf-8", errors="replace")
    plot_ok = False

    out = {
        "log": str(logf),
        "plot_cv_attempted": plot_ok,
        "thermo_control": str(wctrl),
    }
    (tdir / "thermo_summary.json").write_text(
        json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    st = TaskState(status=TaskStatus.DONE.value, message="thermo_pw lancé", data=out)
    db.set_task("thermo", st)
    db.save(work_dir / WORKFLOW_STATE_FILENAME)
    return out

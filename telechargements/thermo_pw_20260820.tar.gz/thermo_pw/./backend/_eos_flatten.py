"""Juillet 2026 (bugfix v4) - helper isole pour le double-nesting eos_summary.

v4 - difference vs v3 :
  * Propagation de ``eos_summary["B0_GPa_approx"]`` (cle DISQUE top-level,
    soeur de ``eos_summary["eos"]``) vers ``results.eos["B0_GPa"]``. Le
    helper iterait jusqu'ici SEULEMENT sur ``eos_summary.eos`` (inner
    dict), donc la cle top-level etait ignoree et B0_GPa etait toujours
    re-calcule depuis B0_Ry_bohr3. Le re-patch script contournait via
    ``merged.update(disk_eos)``, mais le patch in-pipeline
    (``_intermediate_parse``) ratait cette cle. v4 unifie les deux paths.
  * Warning sur divergence d'aliasing : si ``B0_prime`` et ``B0prime``
    sont TOUS DEUX non-None mais avec des valeurs differentes, on log
    un warning (le silent trap signale par le reviewer). On ne touche
    pas aux valeurs (preserve ``results.eos`` comme source de verite
    en memoire) mais on alerte l'operateur. Si l'utilisateur veut
    forcer la synchro, il peut re-loader le run depuis le disque.
  * ``import warnings`` et warning sur fallback ``fit_eos`` non charge
    (meme raison : silent trap si fit_eos evolue).

Invariant documente : ``parse_thermo_pw_log`` ne pose que des sentinelles
``None`` dans ``results.eos`` (jamais de valeurs reelles pour V0/B0/B'/E0).
L'overwrite des None sentinelles est donc safe - voir aussi le test
``test_flatten_overwrites_none_sentinelles``. Si un futur code path
pre-alloue ``0.0`` ou ``""`` comme sentinelle, ce helper ne les
touchera pas (et il faudra explicitement ajouter un check par sentinel).
"""
from __future__ import annotations

import warnings
from typing import Any, Dict

# Tente d'utiliser la fonction canonique. Si l'import echoue (ModuleNotFoundError
# uniquement - on laisse les autres exceptions se propager), fallback dur
# + warning explicite (sinon silent trap si fit_eos evolue).
try:
    from fit_eos import b0_GPa as _b0_GPa, RY_BOHR3_TO_GPA as _RY_BOHR3_TO_GPA  # noqa: WPS433
except ImportError:  # pragma: no cover - filet de securite (CI sans backend/ en path)
    # 1 Ry/bohr^3 = 14710 GPa (CODATA-2018). Marge 0.1 % acceptable.
    _RY_BOHR3_TO_GPA = 14710.0
    warnings.warn(
        f"[_eos_flatten] fit_eos.b0_GPa introuvable, fallback dur facteur "
        f"{_RY_BOHR3_TO_GPA}. Verifier que backend/ est sur sys.path ou que "
        f"fit_eos.py est present.",
        ImportWarning,
        stacklevel=2,
    )

    def _b0_GPa(x):
        return float(x) * _RY_BOHR3_TO_GPA


# Aliases : (nom source, nom alias) - chaque paire est bidirectionnelle.
# B0_prime <-> B0prime : la factsheet (``_section_eos``) lit ``B0prime``
# (sans underscore) mais le disque (``eos_summary.json``) ecrit
# ``B0_prime``. Le marker pre-alloue egalement ``B0prime`` comme sentinelle
# None. Sans aliasing, le helper ne peut pas remplir la cle que la factsheet
# attend.
_B0_ALIASES = (("B0_prime", "B0prime"),)


def _apply_aliases(target: Dict[str, Any]) -> None:
    """Pour chaque paire d'aliases, si l'une des deux cles est None et
    l'autre est non-None, on copie la valeur reelle vers la sentinelle None.
    Si les deux sont non-None avec des valeurs identiques, no-op.
    Si les deux sont non-None avec des valeurs DIFFERENTES, WARNING (le
    silent trap signale par le reviewer) - on ne touche pas pour ne pas
    masquer une possible valeur in-memory plus fraiche, mais on alerte
    pour qu'un operateur puisse investiguer.
    """
    for src, dst in _B0_ALIASES:
        src_v = target.get(src)
        dst_v = target.get(dst)
        if src_v is not None and dst_v is None:
            target[dst] = src_v
        elif dst_v is not None and src_v is None:
            target[src] = dst_v
        elif src_v is not None and dst_v is not None and src_v != dst_v:
            warnings.warn(
                f"[_eos_flatten] aliasing divergent : {src}={src_v!r} vs "
                f"{dst}={dst_v!r}. Le helper preserve les deux (pas d'overwrite) "
                f"- verifier la source de verite (disque vs memoire).",
                UserWarning,
                stacklevel=2,
            )


def flatten_eos_summary_into_results(results: Dict[str, Any]) -> None:
    """Unnest ``results["eos_summary"]["eos"]`` into ``results["eos"]``.

    See module docstring. No-op silencieux si ``results`` ou
    ``eos_summary.eos`` manquent / sont malformes. Ecrase UNIQUEMENT les
    valeurs ``None`` (sentinelles pre-allouees par parse_thermo_pw_log) ;
    ne touche jamais une cle deja posee avec une valeur reelle.
    Propage aussi ``eos_summary["B0_GPa_approx"]`` (cle top-level du
    disque) vers ``results.eos["B0_GPa"]`` si la sentinelle est None.
    """
    if not isinstance(results, dict):
        return
    es = results.get("eos_summary")
    if not isinstance(es, dict):
        return
    eos_sub = es.get("eos")
    if not isinstance(eos_sub, dict) or not eos_sub:
        return
    target = results.setdefault("eos", {})
    if not isinstance(target, dict):
        return
    # (1) Unnest inner dict (overwrite None sentinelles seulement).
    for k, v in eos_sub.items():
        if target.get(k) is None:
            target[k] = v
    # (2) B0_GPa : priorite a ``B0_GPa_approx`` (cle DISQUE top-level,
    # pre-calculee par task_optimize), fallback sur calcul depuis
    # B0_Ry_bohr3 si absent ou si sentinelle None deja posee.
    approx = es.get("B0_GPa_approx")
    if isinstance(approx, (int, float)) and target.get("B0_GPa") is None:
        try:
            target["B0_GPa"] = round(float(approx), 3)
        except (TypeError, ValueError):
            pass
    elif "B0_Ry_bohr3" in target and target.get("B0_GPa") is None:
        try:
            target["B0_GPa"] = round(float(_b0_GPa(target["B0_Ry_bohr3"])), 3)
        except (TypeError, ValueError):
            pass
    # (3) Aliases (B0_prime <-> B0prime) : remet a niveau apres l'unnest.
    _apply_aliases(target)

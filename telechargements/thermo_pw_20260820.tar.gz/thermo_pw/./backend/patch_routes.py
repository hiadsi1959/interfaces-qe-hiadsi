"""Patch in-place backend/pipeline.py.

Ajoute :
  1. Helper top-level ``_list_persisted_pipeline_runs(limit)`` qui scan
     work/<M>/pipeline_*/pipeline_api_job_state.json et inclut
     ``work_dir_exists`` (+ couleurs côté UI via le picker).
  2. Helper ``_scanner_work_dir_exists(run_dir)`` rapide (utilise stat).
  3. Handler ``_pause_job``, ``_stop_job``, ``_resume_job`` (sous
     register_pipeline_blueprint) → POST /jobs/<id>/pause|stop|resume.
  4. Handler ``_post_purge_stale_pipeline_runs`` → POST /runs/purge_stale.
  5. Mutation handler existant ``_get_pipeline_runs`` (GET /runs) pour
     annoter chaque ligne avec ``work_dir_exists`` et un ``_stale`` flag
     ``True`` si status ∈ {error,cancelled,interrupted,paused,stopped} OU
     work_dir manquant (côté UI : bouton 🧹 'Vider les obsolètes').

L'écriture est idempotente : le script no-op si les ancres existent déjà.
"""
import re
from pathlib import Path

FILE = Path("backend/pipeline.py")
src = FILE.read_text(encoding="utf-8")

# --- Idempotence check : si déjà patché, sortir sans rien faire. ---
if "def _list_persisted_pipeline_runs(" in src:
    print("[patch] already patched, skipping")
    raise SystemExit(0)


# -----------------------------------------------------------------------------
# 1) Helpers top-level + handler pause/stop/resume/purge_stale :
#    on les insère juste AVANT ``def register_pipeline_blueprint``.
# -----------------------------------------------------------------------------
HELPERS_AND_HANDLERS = '''def _scanner_work_dir_exists(run_dir: str) -> bool:
    """Renvoie True si le dossier ``run_dir`` existe et est lisible.

    Coût : un appel stat() — appelé pour chaque ligne pivot retournée
    par ``_list_persisted_pipeline_runs`` ; on borne la durée totale à
    ~5 ms par run (souvent < 100 µs sur SSD). En cas d'erreur OS, on
    traite comme absent (retour False) pour signaler le besoin de purge
    à l'UI plutôt que de masquer l'erreur.
    """
    if not run_dir:
        return False
    try:
        return Path(run_dir).is_dir()
    except OSError:
        return False


def _list_persisted_pipeline_runs(limit: int = 50) -> dict[str, Any]:
    """Énumère les ``pipeline_api_job_state.json`` persistés sur disque
    sous ``cfg.WORK_ROOT/**/*.pipeline_api_job_state.json`` (et les jobs
    actuellement en mémoire du registre, fusionnés).

    Chaque ligne inclut un flag ``work_dir_exists`` qui permet à l'UI
    d'afficher un badge 👻 « sans dossier de sortie » pour les jobs
    manifestement obsolètes (work_dir effacé manuellement). Le scanner
    est volontairement borné (``limit`` max, déduplication par job_id
    preférant l'entrée en mémoire si elle existe). En cas de marker
    corrompu (JSON invalide), la ligne est skippée silencieusement.
    """
    out: list[dict[str, Any]] = []
    by_id: dict[str, dict[str, Any]] = {}

    def _ingest(d: dict[str, Any], source: str) -> None:
        jid = str(d.get("job_id") or "").strip()
        if not jid or jid in by_id:
            return
        wd = str(d.get("work_dir") or "").strip()
        by_id[jid] = {
            "job_id": jid,
            "material_id": str(d.get("material_id") or ""),
            "profile_id": str(d.get("profile_id") or ""),
            "profile_emoji": d.get("profile_emoji", ""),
            "label": str(d.get("profile_name") or d.get("profile_id") or ""),
            "status": str(d.get("status") or "interrupted"),
            "work_dir": wd or None,
            "work_dir_exists": _scanner_work_dir_exists(wd) if wd else False,
            "created_at": d.get("created_at"),
            "finished_at": d.get("finished_at"),
            "message": str(d.get("message") or ""),
            "source": source,
        }

    # 1. Mémoire : source autoritative (statut à jour, work_dir effectuable).
    with PipelineJob._REGISTRY_LOCK:
        for jid, job in PipelineJob._REGISTRY.items():
            try:
                r: dict[str, Any] = {
                    "job_id": jid,
                    "material_id": getattr(job, "material_id", ""),
                    "profile_id": getattr(job, "profile_id", ""),
                    "profile_emoji": getattr(job, "profile", {}).get("emoji", ""),
                    "profile_name": getattr(job, "profile", {}).get("name", ""),
                    "status": getattr(job, "status", "unknown"),
                    "work_dir": str(job.work_dir) if getattr(job, "work_dir", None) else None,
                    "work_dir_exists": _scanner_work_dir_exists(
                        str(job.work_dir) if getattr(job, "work_dir", None) else ""
                    ),
                    "created_at": getattr(job, "created_at", None),
                    "finished_at": getattr(job, "finished_at", None),
                    "message": getattr(job, "message", ""),
                    "interrupt_intent": getattr(job, "interrupt_intent", None),
                }
            except Exception:  # noqa: BLE001
                continue
            _ingest(r, "memory")

    # 2. Disque : glob récursif sous cfg.WORK_ROOT. Plus lent, mais permet
    #    d'attraper les jobs terminés entre deux redémarrages serveur et
    #    dont le registre en mémoire a été évincé (FIFO ``_MAX_JOBS_KEPT``).
    try:
        work_root = cfg.WORK_ROOT.resolve()
        if work_root.is_dir():
            # rglob peut renvoyer beaucoup d'entrées sur de vieilles
            # installations : on plafonne à ``limit * 4`` pour ne pas
            # exploser la latence du GET /api/pipeline/runs.
            paths = list(work_root.rglob(PipelineJob._MARKER_FILENAME))
            for p in paths[: limit * 4]:
                try:
                    raw = json.loads(p.read_text(encoding="utf-8", errors="replace"))
                except (OSError, json.JSONDecodeError):
                    continue
                _ingest(raw, "disk")
    except OSError:
        pass

    # 3. Tri : plus récent d'abord (finished_at puis created_at desc).
    def _ts(d: dict[str, Any]) -> str:
        return str(d.get("finished_at") or d.get("created_at") or "")

    items = sorted(by_id.values(), key=_ts, reverse=True)
    items = items[: max(1, int(limit))]
    return {"runs": items, "count": len(items)}


def purge_stale_pipeline_runs(
    *,
    ignore_statuses: tuple[str, ...] = ("running", "queued", "started"),
    include_terminal_ko: bool = True,
    include_workdir_missing: bool = True,
) -> dict[str, Any]:
    """Purge en lot les runs obsolètes (post-juillet 2026).

    Statuts considérés comme « obsolètes » (KO terminé) :
      * ``error``, ``cancelled``, ``interrupted``, ``paused``, ``stopped``
        — options ``include_terminal_ko=True`` (par défaut).
      * work_dir absent du disque (supprimé manuellement) — option
        ``include_workdir_missing=True`` (par défaut). Ces runs sont
        toujours purgés, quel que soit leur statut disque, car ils ne
        peuvent plus être relus depuis le picker (l'UI affichait déjà
        👻 fantôme).

    Sémantique « safe » :
      * ``ignore_statuses`` (running/queued/started) → NE TOUCHE JAMAIS
        les jobs encore en cours, même si leur work_dir a été effacé
        manuellement (le thread de orchestration a un pointeur en
        mémoire, on attend son arrêt naturel avant de le sortir du
        registre). C'est le filet de sécurité « pas de perte de job ».
      * Pas de suppression du work_dir sur disque par défaut (les
        fichiers de résultats sont précieux) : seul le registre et le
        marker ``pipeline_api_job_state.json`` sont retirés. Si
        l'utilisateur veut ensuite supprimer aussi work_dir, il passe
        par le bouton 🗑 « Supprimer définitivement ce run » déjà
        câblé côté UI et confirmé côté backend
        (``/api/pipeline/runs/<job_id>`` DELETE) ou via rm manuel.

    Retourne un rapport détaillé pour journal côté UI :
      * ``deleted``       : job_ids retirés du registre + de leur marker
      * ``kept_running``  : job_ids en running/queued volontairement skippés
      * ``missing_wd``    : job_ids sans work_dir (même statut preserved)
      * ``errors``        : erreurs OS ponctuelles (par job_id)
    """
    deleted: list[str] = []
    kept_running: list[str] = []
    missing_wd: list[str] = []
    errors: list[dict[str, Any]] = []
    ignore_set = {str(s).lower() for s in ignore_statuses}

    with PipelineJob._REGISTRY_LOCK:
        for jid, job in list(PipelineJob._REGISTRY.items()):
            st = str(getattr(job, "status", "") or "").lower()
            wd = getattr(job, "work_dir", None)
            wd_str = str(wd) if wd else ""
            wd_exists = _scanner_work_dir_exists(wd_str)
            try:
                if st in ignore_set:
                    kept_running.append(jid)
                    continue
                is_terminal_ko = (
                    include_terminal_ko and st in (
                        "error", "cancelled", "interrupted", "paused", "stopped",
                    )
                )
                is_wd_missing = include_workdir_missing and not wd_exists
                if not (is_terminal_ko or is_wd_missing):
                    continue
                # 1. Sortir du registre
                PipelineJob._REGISTRY.pop(jid, None)
                # 2. Retirer le marker disque s'il existe
                if wd:
                    marker = Path(wd_str) / PipelineJob._MARKER_FILENAME
                    try:
                        if marker.is_file():
                            marker.unlink()
                    except OSError as ex:
                        errors.append({"job_id": jid, "stage": "marker_unlink", "error": str(ex)})
                deleted.append(jid)
                if is_wd_missing:
                    missing_wd.append(jid)
            except Exception as ex:  # noqa: BLE001
                errors.append({"job_id": jid, "stage": "purge", "error": str(ex)})

    # 4. Aussi : scans les markers disque orphelins (job_id plus dans le registre
    #    mais marker toujours présent → job terminé après éviction FIFO).
    try:
        work_root = cfg.WORK_ROOT.resolve()
        if work_root.is_dir() and include_terminal_ko:
            # Limiter à 500 markers lus pour rester rapide (peut être
            # étendu si demande expresse de l'utilisateur).
            paths = list(work_root.rglob(PipelineJob._MARKER_FILENAME))[:500]
            for p in paths:
                try:
                    raw = json.loads(p.read_text(encoding="utf-8", errors="replace"))
                except (OSError, json.JSONDecodeError):
                    continue
                jid = str(raw.get("job_id") or "").strip()
                if not jid or jid in deleted or jid in kept_running:
                    continue
                st = str(raw.get("status") or "").lower()
                wd = str(raw.get("work_dir") or "").strip() or None
                if st in ignore_set:
                    continue
                is_terminal_ko = st in (
                    "error", "cancelled", "interrupted", "paused", "stopped",
                )
                is_wd_missing = include_workdir_missing and not _scanner_work_dir_exists(wd or "")
                if not (is_terminal_ko or is_wd_missing):
                    continue
                try:
                    p.unlink()
                    deleted.append(jid)
                    if is_wd_missing:
                        missing_wd.append(jid)
                except OSError as ex:
                    errors.append({"job_id": jid, "stage": "orphan_marker_unlink", "error": str(ex)})
    except OSError:
        pass

    return {
        "deleted": deleted,
        "kept_running": kept_running,
        "missing_wd": missing_wd,
        "errors": errors,
        "scanned": len(deleted) + len(kept_running) + len(missing_wd),
        "message": (
            f"Purge obsolètes : {len(deleted)} retiré(s) "
            f"(incl. {len(missing_wd)} work_dir manquant), "
            f"{len(kept_running)} running/queued conservé(s)."
        ),
    }


'''


# -----------------------------------------------------------------------------
# 2) Mutation _get_pipeline_runs pour annoter chaque ligne avec work_dir_exists
#    + un flag _stale (KO terminé OU work_dir_missing) pour le bouton UI.
# -----------------------------------------------------------------------------
# On remplace la fonction existante. Trouvons l'ancre exacte dans le fichier.
# Pattern: "@bp.route("/api/pipeline/runs", methods=["GET"])" puis la def.
HANDLER_RUNS_OLD = '''@bp.route("/api/pipeline/runs", methods=["GET"])
def list_pipeline_runs():
    """Liste combinée registre + disque (post-juillet 2026).

    Remplace une implémentation en-mémoire trop étroite : on parcourt
    aussi ``cfg.WORK_ROOT/**/pipeline_api_job_state.json`` pour
    rattraper les runs terminés entre deux redémarrages serveur et dont
    le registre a été évincé (FIFO ``_MAX_JOBS_KEPT``).

    Chaque ligne annotée avec ``work_dir_exists`` (+ couleurs côté UI :
    badge 👻 si False). Le mécanisme ``_stale`` (KO OU work_dir_missing)
    alimente le compteur du bouton 🧹 'Vider les obsolètes'.
    """'''

HANDLER_RUNS_NEW = ''''''


# -----------------------------------------------------------------------------
# 3) Insérer les routes pause/stop/resume + handler body + purge_stale handler
#    juste après le bloc ``@bp.route("/api/pipeline/jobs/<job_id>/cancel", ...)``.
#    Trouvons l'ancre exacte.
# -----------------------------------------------------------------------------
# L'ancre de la fonction cancel_job finit avec "raise RuntimeError(...)" —
# on ajoute APRÈS elle.
CANCEL_ANCHOR = '''    raise RuntimeError(
        f"Job sans mécanisme d'annulation (version ancienne du serveur). Redémarrer api_server.py.",
        f"job_id": job_id,
    )
    return'''  # ne va PAS matcher tel quel : on cherche un marqueur unique

# Recherche d'une meilleure ancre : la fin du bloc cancel_job (juste avant
# la route suivante). On construit à partir de l'output grep.
CANCEL_END_MARKER = 'job_id": job_id,'
print("[patch] locating cancel endpoint anchor...")

# -----------------------------------------------------------------------------
# Apply edits.
# -----------------------------------------------------------------------------
new_src = src

# 1. Insérer les helpers juste avant ``def register_pipeline_blueprint``.
anchor_register = "def register_pipeline_blueprint(app) -> None:"
if anchor_register not in new_src:
    raise SystemExit("[patch] anchor 'register_pipeline_blueprint' introuvable")
new_src = new_src.replace(
    anchor_register,
    HELPERS_AND_HANDLERS + anchor_register,
    1,
)

# 2. Remplacer list_pipeline_runs. Lecture/écriture directe du bloc complet.
#    On cherche la ligne @bp.route("/api/pipeline/runs", methods=["GET"]) jusqu'à
#    la ligne ``return jsonify({...})`` qui clôt la fonction.
#    Pour idempotence et robustesse, on définit un bloc OLD complet.
LIST_RUNS_OLD = '''@bp.route("/api/pipeline/runs", methods=["GET"])
def list_pipeline_runs():
    """Liste combinée registre + disque (post-juillet 2026).

    Remplace une implémentation en-mémoire trop étroite : on parcourt
    aussi ``cfg.WORK_ROOT/**/pipeline_api_job_state.json`` pour
    rattraper les runs terminés entre deux redémarrages serveur et dont
    le registre a été évincé (FIFO ``_MAX_JOBS_KEPT``).

    Chaque ligne annotée avec ``work_dir_exists`` (+ couleurs côté UI :
    badge 👻 si False). Le mécanisme ``_stale`` (KO OU work_dir_missing)
    alimente le compteur du bouton 🧹 'Vider les obsolètes'.
    """'''
assert LIST_RUNS_OLD in new_src, "[patch] list_pipeline_runs anchor not found"
LIST_RUNS_BODY = '''    """Liste combinée registre + disque (post-juillet 2026).

    Remplace une implémentation en-mémoire trop étroite : on parcourt
    aussi ``cfg.WORK_ROOT/**/pipeline_api_job_state.json`` pour
    rattraper les runs terminés entre deux redémarrages serveur et dont
    le registre a été évincé (FIFO ``_MAX_JOBS_KEPT``).

    Chaque ligne annotée avec ``work_dir_exists`` (+ couleurs côté UI :
    badge 👻 si False). Le mécanisme ``_stale`` (KO OU work_dir_missing)
    alimente le compteur du bouton 🧹 'Vider les obsolètes'.
    """
    try:
        limit = int(request.args.get("limit") or 50)
    except (TypeError, ValueError):
        limit = 50
    data = _list_persisted_pipeline_runs(limit=limit)
    # Annotation ``_stale`` pour l'UI : True si terminal KO OU work_dir_missing.
    for r in data["runs"]:
        st = str(r.get("status") or "").lower()
        r["_stale"] = st in (
            "error", "cancelled", "interrupted", "paused", "stopped",
        ) or not r.get("work_dir_exists", True)
    return jsonify(data)
'''
new_src = new_src.replace(LIST_RUNS_OLD, LIST_RUNS_OLD + LIST_RUNS_BODY, 1)
print("[patch] list_pipeline_runs re-hydratée avec limit / _stale.")


# -----------------------------------------------------------------------------
# 3) Ajouter pause/stop/resume/purge_stale/routes+handlers d'un coup.
# -----------------------------------------------------------------------------
PAUSE_STOP_RESUME_BLOCK = '''


# ============================================================================
# Juillet 2026 — cycle de vie interactif (Pause / Stop / Resume).
#
# Sémantique figée :
#   - Pause : SIGTERM MPI + exit coopérant + status ``paused`` → REPRENABLE.
#     Le worker checkpoint via workflow_state.json. À la reprise, un nouveau
#     thread réutilise ``self.work_dir`` et saute les sous-étapes done.
#   - Stop  : kill doux + status ``stopped``. NON reprenable. work_dir intact.
#   - Cancel historique (Annuler) → status ``cancelled``.
# ============================================================================
@bp.route("/api/pipeline/jobs/<job_id>/pause", methods=["POST"])
def pause_pipeline_job(job_id: str):
    with PipelineJob._REGISTRY_LOCK:
        job = PipelineJob._REGISTRY.get(job_id)
    if not job:
        return jsonify({"error": "job_id inconnu"}), 404
    st = str(job.status or "").lower()
    if st not in ("running", "queued"):
        return jsonify({
            "error": "pause réservée aux jobs running/queued",
            "status": st,
        }), 409
    try:
        job.request_pause()
    except RuntimeError as ex:
        return jsonify({"error": str(ex), "status": st}), 400
    return jsonify({
        "job_id": job_id,
        "status": "pause_requested",
        "message": (
            "Pause demandée. Le runner stoppera le subprocess MPI courant "
            "(SIGTERM) puis sortira au prochain checkpoint (status=paused)."
        ),
    }), 202


@bp.route("/api/pipeline/jobs/<job_id>/stop", methods=["POST"])
def stop_pipeline_job(job_id: str):
    with PipelineJob._REGISTRY_LOCK:
        job = PipelineJob._REGISTRY.get(job_id)
    if not job:
        return jsonify({"error": "job_id inconnu"}), 404
    st = str(job.status or "").lower()
    if st not in ("running", "queued"):
        return jsonify({
            "error": "stop réservé aux jobs running/queued",
            "status": st,
        }), 409
    try:
        job.request_stop()
    except RuntimeError as ex:
        return jsonify({"error": str(ex), "status": st}), 400
    return jsonify({
        "job_id": job_id,
        "status": "stop_requested",
        "message": (
            "Stop demandé. Le runner termine le subprocess et bascule en "
            "status=stopped. work_dir conservé sur disque, NON reprenable."
        ),
    }), 202


@bp.route("/api/pipeline/jobs/<job_id>/resume", methods=["POST"])
def resume_pipeline_job(job_id: str):
    with PipelineJob._REGISTRY_LOCK:
        job = PipelineJob._REGISTRY.get(job_id)
    if not job:
        return jsonify({"error": "job_id inconnu"}), 404
    try:
        job.request_resume()
    except RuntimeError as ex:
        return jsonify({"error": str(ex), "status": job.status}), 400
    except FileNotFoundError as ex:
        return jsonify({"error": str(ex), "status": job.status}), 409
    return jsonify({
        "job_id": job_id,
        "status": "running",
        "message": (
            "Reprise acceptée. Le runner redé marre sur le même work_dir ; "
            "les sous-étapes ``DONE`` du workflow_state.json sont sautées."
        ),
    }), 202


@bp.route("/api/pipeline/runs/purge_stale", methods=["POST", "OPTIONS"])
def post_purge_stale_pipeline_runs():
    """Purge en lot les runs obsolètes (post-juillet 2026).

    Différent de ``purge_failed`` historique : en plus de purger les
    statuts ``error/cancelled/interrupted``, ce nouveau endpoint capture
    aussi les statuts ``paused/stopped`` ET les runs dont le work_dir
    n'existe plus sur disque (jobs manifestement supprimés manuellement
    par l'utilisateur → badge 👻 côté UI).

    Sémantique (sûre par défaut) :
      * running/queued/started → JAMAIS touchés (filet « pas de perte »).
      * suppression = sortir du registre in-memory + effacer le marker
        disque ``pipeline_api_job_state.json``. Le work_dir sur disque
        N'est PAS touché (l'utilisateur peut le supprimer via le bouton
        🗑 unitaire déjà câblé, ou via rm manuel).
    """
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    include_terminal_ko = bool(data.get("include_terminal_ko", True))
    include_workdir_missing = bool(data.get("include_workdir_missing", True))
    dry_run = bool(data.get("dry_run", False))
    if dry_run:
        # Mode dry_run : on simule sans toucher au registre/au disque.
        simulated = {
            "deleted": [],
            "kept_running": [],
            "missing_wd": [],
            "dry_run": True,
            "would_delete_count": 0,
            "would_keep_running_count": 0,
        }
        with PipelineJob._REGISTRY_LOCK:
            for jid, job in PipelineJob._REGISTRY.items():
                st = str(getattr(job, "status", "") or "").lower()
                wd = getattr(job, "work_dir", None)
                wd_str = str(wd) if wd else ""
                wd_exists = _scanner_work_dir_exists(wd_str)
                if st in ("running", "queued", "started"):
                    simulated["kept_running"].append(jid)
                    continue
                is_terminal_ko = (
                    include_terminal_ko and st in (
                        "error", "cancelled", "interrupted", "paused", "stopped",
                    )
                )
                is_wd_missing = include_workdir_missing and not wd_exists
                if is_terminal_ko or is_wd_missing:
                    simulated["deleted"].append({
                        "job_id": jid,
                        "status": st,
                        "work_dir_exists": wd_exists,
                        "reason": (
                            "work_dir_missing" if is_wd_missing and not is_terminal_ko
                            else "terminal_ko" if is_terminal_ko and not is_wd_missing
                            else "both"
                        ),
                    })
        simulated["would_delete_count"] = len(simulated["deleted"])
        simulated["would_keep_running_count"] = len(simulated["kept_running"])
        return jsonify(simulated), 200
    report = purge_stale_pipeline_runs(
        include_terminal_ko=include_terminal_ko,
        include_workdir_missing=include_workdir_missing,
    )
    return jsonify(report), 202


'''

# Insérer juste après le bloc cancel_job (avant la route reparse).
# Ancre = la route qui suit dans l'ordre du fichier (d'après grep : line 2472+).
REPARSE_ANCHOR = '@bp.route("/api/pipeline/jobs/<job_id>/reparse"'
if REPARSE_ANCHOR not in new_src:
    raise SystemExit("[patch] reparse route anchor introuvable")
new_src = new_src.replace(
    REPARSE_ANCHOR,
    PAUSE_STOP_RESUME_BLOCK + REPARSE_ANCHOR,
    1,
)
print("[patch] pause/stop/resume/purge_stale routes + handlers insérés.")


FILE.write_text(new_src, encoding="utf-8")
print(f"[patch] écrit {FILE} ({len(new_src)} chars vs {len(src)} avant)")

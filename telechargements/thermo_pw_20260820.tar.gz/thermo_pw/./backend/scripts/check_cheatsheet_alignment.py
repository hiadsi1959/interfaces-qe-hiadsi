#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
check_cheatsheet_alignment.py (juillet 2026)

Vérifie que les fichiers listés dans ``PROFILES[id]['expected_results']['files']``
(``backend/pipeline.py``, source canonique) sont cohérents avec les noms de fichiers
mentionnés en backticks dans chaque section ``## Pn — …`` du cheatsheet
(``templates/cheatsheet/cheatsheet_outputs_par_profil.md``).

Comparaison **par profil** (P1, P2, P3, P4, P5), scope étroit :

    PROFILES[id]['expected_results']['files']  ⇔  backticks data-files dans ## Pn …

Filtrage des faux positifs : on ignore les backticks qui pointent vers des binaires QE
(``pw.x``, ``matdyn.x``, …), des chemins de modules Python (``backend/foo.py``), des
références de fonctions (``PipelineJob.__init__``), ou des cellules de tableau
multi-noms (``scf.in, ph.in, fc.out``). Seuls les backticks qui ressemblent à un vrai
fichier de données (basename + extension parmi ``.in .out .dat .png .json .gz .py .save``)
comptent.

Pas de comparaison avec ``outputs`` (texte libre avec `` — `` comme séparateur, trop
bruitée). Pas de comparaison globale (le grep matchait les noms de fichiers dans les
sections opt-in P5 et dans le tableau comparatif en haut du cheatsheet).

Usage (depuis la racine du repo) :

    python3 backend/scripts/check_cheatsheet_alignment.py
    echo $?     # 0 si aligné, 1 sinon (drift par profil, détaillé)

Codes de sortie :
    0  toutes les sections P1..P5 sont alignées (même ensemble de fichiers).
    1  au moins une section diverge (la sortie liste le détail par profil).
    2  erreur bloquante (cheatsheet introuvable, import cassé, …).
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT / "backend"))

from pipeline import PROFILES  # noqa: E402

CHEATSHEET = REPO_ROOT / "templates" / "cheatsheet" / "cheatsheet_outputs_par_profil.md"

# Section "## Pn — …" jusqu'au prochain "## Pn+1 …" / "## Voir aussi" / "## Maintenance"
_SECTION_RE = re.compile(
    r"^## (P[1-5])[^\n]*\n(.*?)(?=^## (?:P[1-5]|Voir aussi|Maintenance)|\Z)",
    re.MULTILINE | re.DOTALL,
)
# Backticks : `xxx.yyy_zz`. On capture tout, le filtrage se fait après.
_BACKTICK_RE = re.compile(r"`([^`]+)`")

# Extensions acceptées pour les backticks considérés comme de vrais fichiers de données
# (sorties QE : input/output, data tables, plots, markers, gaz-saving archives).
_DATA_FILE_EXTS = (".in", ".out", ".dat", ".png", ".json", ".gz", ".save")

# Path suffixes / prefixes / chaînes explicitement NON considérés comme fichiers
# (binaires QE, modules Python, fonctions, paramètres, doc-cross-refs).
_NON_FILE_NAMES = frozenset({
    # Binaires QE et outils de tracé
    "pw.x", "matdyn.x", "q2r.x", "ph.x", "dos.x", "bands.x",
    "epsilon.x", "turbo_lanczos.x", "turbo_davidson.x",
    "gnuplot", "thermo_pw.x", "matdyn", "q2r",
    # Réflexions de fonctions / classes / modules Python
    "PipelineJob.__init__", "BORN_INPUT_FILE", "BORN_FILE",
    "lo_to_chain.check_pseudos_are_nc", "lo_to_chain.write_born_file",
    "parsers/dielectric", "ph_input_from_pw.try_autogenerate_ph_in",
    # Cross-refs doc
    "templates/cheatsheet/cheatsheet_outputs_par_profil.md",
    "templates/lo_to/README_canonique_P5.txt",
    "templates/thermo_control_keys/",
    # Paramètres / clés namelist
    "ibrav", "outdir", "pseudo_dir", "prefix", "ltherm_freq", "ltherm_dos",
    # Constantes programme
    "pipeline_api_job_state.json",  # marker UI, pas une sortie du run
})


def _looks_like_data_filename(name: str) -> bool:
    """True si `name` ressemble à un fichier de données (basename + extension data)."""
    basename = name.rsplit("/", 1)[-1]
    return any(basename.endswith(ext) for ext in _DATA_FILE_EXTS)


def _filter_backticks(raw: list[str]) -> list[str]:
    """Filtre les backticks pour ne garder que les fichiers de données réels."""
    kept = []
    for n in raw:
        n = n.strip()
        if n in _NON_FILE_NAMES:
            continue
        if not _looks_like_data_filename(n):
            continue
        # Exclut les suffixes de chemins (ex. `.save/`)
        if n.endswith("/"):
            continue
        kept.append(n)
    return sorted(set(kept))


def _load_struct() -> dict[str, list[str]]:
    """Liste structurée depuis PROFILES (le contrat canonique)."""
    return {
        pid: sorted(
            f["name"] for f in p.get("expected_results", {}).get("files", [])
        )
        for pid, p in PROFILES.items()
    }


def _load_doc() -> dict[str, list[str]]:
    """Liste depuis chaque section `## Pn — …` du cheatsheet (backticks data-files)."""
    if not CHEATSHEET.is_file():
        print(f"ERROR: cheatsheet introuvable : {CHEATSHEET}", file=sys.stderr)
        sys.exit(2)
    text = CHEATSHEET.read_text(encoding="utf-8")
    doc: dict[str, list[str]] = {}
    for m in _SECTION_RE.finditer(text):
        pid = m.group(1)
        section = m.group(2)
        doc[pid] = _filter_backticks(_BACKTICK_RE.findall(section))
    return doc


def main() -> int:
    struct = _load_struct()
    doc = _load_doc()
    drift_pids: list[str] = []
    for pid in ("P1", "P2", "P3", "P4", "P5"):
        s = set(struct.get(pid, []))
        d = set(doc.get(pid, []))
        only_struct = sorted(s - d)
        only_doc = sorted(d - s)
        if only_struct or only_doc:
            drift_pids.append(pid)
            print(f"== {pid} DRIFT ==")
            if only_struct:
                print(f"  PROFILES-only  ({len(only_struct)}): {only_struct}")
            if only_doc:
                print(f"  cheatsheet-only ({len(only_doc)}): {only_doc}")
        else:
            print(f"== {pid} OK ({len(s)} fichiers alignés) ==")
    if drift_pids:
        print()
        print(f"DRIFT:{':'.join(drift_pids)}")
        print(f"\n🔍 {len(drift_pids)} profil(s) divergent entre PROFILES et cheatsheet.")
        return 1
    print("\n✅ Toutes les sections P1..P5 sont alignées avec PROFILES.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

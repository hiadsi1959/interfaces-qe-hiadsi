#!/usr/bin/env python3
"""Juillet 2026 (bugfix) - patch idempotent v2 : import + appel du helper.

Difference vs v1 : le helper est dans ``backend/_eos_flatten.py`` (module
isole, importe de partout). Le patcher fait juste :
  1. Ajouter ``from _eos_flatten import flatten_eos_summary_into_results``
     dans la section imports de pipeline.py.
  2. Inserer ``flatten_eos_summary_into_results(self.results)`` dans le bloc
     ``_intermediate_parse`` apres le load de ``eos_summary.json``.

Idempotent : skip si les deux ancres sont deja posees.
"""
import re
import sys
from pathlib import Path

TARGET = Path("/home/hiadsi/thermo_pw/backend/pipeline.py")

# On importe l'import apres les imports locaux (apres `from . import` ou
# `from state_db import` selon l'ordre actuel). Ancre : on insere juste
# apres la derniere ligne ``^from <module_local> import`` du bloc d'imports
# en haut du fichier.
IMPORT_LINE = "from _eos_flatten import flatten_eos_summary_into_results\n"

CALL_LINE = "                    flatten_eos_summary_into_results(self.results)\n"


def _already_patched(src: str) -> bool:
    return (
        "from _eos_flatten import flatten_eos_summary_into_results" in src
        and "flatten_eos_summary_into_results(self.results)" in src
    )


def _find_import_insertion_idx(src: str) -> int:
    """Trouve la fin du bloc d'imports en haut du fichier (avant la 1ere
    definition de classe ou de fonction module-level). Heuristique : la
    derniere ligne d'import consecutive (sans ligne vide) avant la 1ere
    ligne non-import / non-commentaire."""
    lines = src.split("\n")
    last_import_idx = -1
    for i, ln in enumerate(lines):
        stripped = ln.strip()
        if stripped.startswith("import ") or stripped.startswith("from "):
            last_import_idx = i
        elif stripped == "" or stripped.startswith("#"):
            continue
        else:
            # 1ere ligne non-import / non-comment : on insere apres
            # last_import_idx si on en a trouve un.
            if last_import_idx >= 0:
                return _offset_to_index(lines, last_import_idx + 1)
            # Sinon, on insere au tout debut.
            return 0
    return _offset_to_index(lines, last_import_idx + 1) if last_import_idx >= 0 else 0


def _offset_to_index(lines, i):
    return sum(len(ln) + 1 for ln in lines[:i])


def main() -> int:
    src = TARGET.read_text(encoding="utf-8")

    if _already_patched(src):
        print("SKIP: pipeline.py deja patche (import + appel presents).")
        return 0

    new_src = src
    changes = []

    # 1. Insertion de l'import en haut du fichier.
    if "from _eos_flatten import flatten_eos_summary_into_results" not in new_src:
        insert_idx = _find_import_insertion_idx(new_src)
        new_src = new_src[:insert_idx] + IMPORT_LINE + new_src[insert_idx:]
        changes.append(f"import _eos_flatten ajoute (offset {insert_idx})")

    # 2. Insertion de l'appel dans _intermediate_parse. Ancre : on cherche le
    # pattern exact de la fin du json.loads(...)
    ANCHOR = (
        '                    self.results["eos_summary"] = json.loads(\n'
        '                        es_json.read_text(encoding="utf-8", errors="replace")\n'
        '                    )\n'
    )
    REPLACEMENT = ANCHOR + (
        "                    # Juillet 2026 (bugfix) - unnest eos_summary.eos\n"
        "                    # into self.results['eos'] pour UI + factsheet.\n"
        + CALL_LINE
    )
    if ANCHOR in new_src and "flatten_eos_summary_into_results(self.results)" not in new_src:
        new_src = new_src.replace(ANCHOR, REPLACEMENT, 1)
        changes.append("appel flatten_eos_summary_into_results insere dans _intermediate_parse")
    elif "flatten_eos_summary_into_results(self.results)" in new_src:
        changes.append("appel deja present (import seulement)")
    else:
        # Fallback regex si l'ancre exacte ne match pas (formatage legerement different).
        pat = re.compile(
            r'(self\.results\["eos_summary"\] = json\.loads\(\s*\n'
            r'\s+es_json\.read_text\([^)]+\)\s*\n'
            r'\s+\))\n(\s+)(except \(OSError, json\.JSONDecodeError\))',
            re.MULTILINE,
        )
        m = pat.search(new_src)
        if m and "flatten_eos_summary_into_results(self.results)" not in new_src:
            new_src = (
                new_src[: m.end(1)]
                + "\n                    # Juillet 2026 (bugfix)\n"
                + CALL_LINE
                + new_src[m.end(1):]
            )
            changes.append("appel insere via regex fallback")
        else:
            print("ERR: _intermediate_parse : ancre ET regex fallback introuvables")
            return 1

    TARGET.write_text(new_src, encoding="utf-8")
    for c in changes:
        print(f"[OK] pipeline.py : {c}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

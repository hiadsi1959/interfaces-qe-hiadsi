"""Estimation de la durée d'un calcul, par profil P1..P5 et par machine.

Principe
--------
Une durée QE se factorise en trois termes indépendants :

    T_étape  =  C_étape  ×  W(matériau)  /  D(machine, nproc)

* ``C_étape`` — constante de calibration propre à l'étape (grille EOS, ph.x,
  thermo_pw…), exprimée en « secondes normalisées ». Les valeurs livrées ont
  été **mesurées** sur un run P2/Si de référence ; celles qui ne l'ont pas été
  sont dérivées du coût d'un SCF et marquées comme telles (``provenance``),
  pour que l'interface n'affiche jamais une précision qu'elle n'a pas.
* ``W`` — travail dimensionnel du matériau, tiré de ``scf.in`` : nombre
  d'atomes, points k irréductibles, cutoff. Pour ph.x s'y ajoutent le nombre de
  points q irréductibles et les 3·nat modes.
* ``D`` — débit de la machine (``machine_profile``), qui combine vitesse par
  cœur et accélération parallèle réelle. C'est ce terme qui fait qu'un même P2
  passe de quelques heures à une vingtaine d'heures selon le matériel.

Auto-calibration
----------------
Chaque étape terminée est enregistrée avec ses descripteurs dans
``.runtime_calibration.json``. Les mesures locales corrigent ensuite les
constantes livrées : l'estimation s'affine à chaque calcul sur la machine.

Progression live
----------------
Avant lancement, le nombre de points q irréductibles est approché par symétrie.
Dès que ``ph.out`` existe, il est lu **exactement**, ce qui rend l'ETA en cours
de run beaucoup plus fiable que l'estimation a priori.
"""
from __future__ import annotations

import json
import math
import re
import threading
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from machine_profile import MachineProfile, detect_machine

# ---------------------------------------------------------------------------
# Référence de calibration (run P2 sur Si, mesuré le 18/08/2026, nproc=2)
# ---------------------------------------------------------------------------
# Machine : i7-7500U, 2 cœurs physiques / 4 threads, nproc=2 → débit 1.82.
# Matériau : Si, nat=2, ibrav=2 (fcc), ecutwfc=60 Ry, k 12×12×12 (72 k irr,
#            confirmés par QE), q 4×4×4 (8 q irréductibles lus dans ph.out),
#            6 modes.
#
# Un premier jeu de constantes avait été tiré d'un run à nproc=4 sur la même
# machine et le même matériau. Il surestimait tout d'un facteur ~5 : ce run
# était pathologique (4 rangs MPI sur 2 cœurs physiques, 3 Gio déjà en swap,
# navigateur actif). Les constantes ci-dessous viennent du run propre à
# nproc=2 ; le régime dégradé est désormais traité par le modèle parallèle de
# ``machine_profile``, pas absorbé dans les constantes.
REF_NAT = 2
REF_NK_IRR = 72
REF_ECUTWFC = 60.0

# Exposants de mise à l'échelle. Le coût d'un SCF croît comme le cube du nombre
# de bandes dans la diagonalisation mais reste dominé par les FFT en pratique :
# 2.3 est le compromis usuel pour des cellules de quelques atomes.
NAT_EXPONENT = 2.3
ECUT_EXPONENT = 1.5


@dataclass
class StepCost:
    """Constante de calibration d'une étape + provenance de la valeur."""

    seconds_normalized: float
    provenance: str  # "mesuré" | "dérivé"
    comment: str = ""


# Secondes normalisées pour W=1 (matériau de référence), débit 1.0.
#
# ``eos_grid`` est par volume ; ``ph`` est par (point q × mode). Les valeurs
# mesurées viennent des horodatages du run de référence et, pour ph.x, des
# lignes « total cpu time » de ph.out — la mesure la plus fiable dont on
# dispose puisqu'elle est produite par QE lui-même.
STEP_COSTS: dict[str, StepCost] = {
    "scf_eq": StepCost(144.0, "mesuré", "SCF @ V₀ : 79 s à débit 1.82"),
    "eos_grid_per_volume": StepCost(
        142.0, "mesuré",
        "7 volumes en 383 s, débit agrégé 2.6 — soit le même coût qu'un SCF "
        "isolé, ce qui confirme le découpage du modèle",
    ),
    "ph_per_q_mode": StepCost(
        479.0, "mesuré",
        "8 q × 6 modes en 3 h 30 (ph.out : « PHONON 3h30m WALL »)",
    ),
    "q2r": StepCost(2.0, "mesuré", "fc.out écrit en moins d'une seconde"),
    "matdyn": StepCost(16.0, "mesuré", "bandes + DOS en 9 s"),
    "electronic_props": StepCost(
        432.0, "dérivé", "NSCF sur grille densifiée + dos.x + bands.x ≈ 3 SCF",
    ),
    "optical_props": StepCost(
        1150.0, "dérivé", "NSCF à bandes vides + epsilon.x + turbo_* ≈ 8 SCF",
    ),
    # thermo_pw.x : le coût dépend entièrement du mot-clé ``what`` du profil.
    "thermo_pw_scf_elastic_constants": StepCost(
        1730.0, "dérivé", "~12 SCF sur cellules déformées (P1)",
    ),
    "thermo_pw_thermo": StepCost(
        6000.0, "mesure partielle",
        "P2 : plus de 54 min observées sans être terminé — borne inférieure. "
        "Bien au-delà d'une simple intégration de DOS, contrairement à "
        "l'hypothèse initiale",
    ),
    "thermo_pw_elastic_constants_geo": StepCost(
        6000.0, "dérivé", "élastique répété sur plusieurs géométries (P3)",
    ),
    "thermo_pw_ph_life": StepCost(
        9000.0, "dérivé", "durées de vie phononiques, anharmonique (P4)",
    ),
    "thermo_pw_dielectric": StepCost(
        1440.0, "dérivé", "DFPT diélectrique + Z* à Γ (P5)",
    ),
    "thermo_extra": StepCost(120.0, "dérivé", "un what supplémentaire P5"),
    "lo_to": StepCost(1800.0, "dérivé", "dielectric + rechaîne ph/q2r/matdyn (P1)"),
}

# Nombre d'opérations de symétrie du groupe ponctuel, par ibrav QE.
_IBRAV_SYMOPS: dict[int, int] = {
    0: 4,  # inconnu (CELL_PARAMETERS libre) — hypothèse prudente
    1: 48, 2: 48, 3: 48, -3: 48,          # cubique
    4: 24,                                 # hexagonal
    5: 12, -5: 12,                         # trigonal / rhomboédrique
    6: 16, 7: 16,                          # tétragonal
    8: 8, 9: 8, -9: 8, 10: 8, 11: 8,       # orthorhombique
    12: 4, -12: 4, 13: 4, -13: 4,          # monoclinique
    14: 2,                                 # triclinique
}

# Comptes exacts de points irréductibles pour les grilles n×n×n non décalées
# les plus courantes en cubique. La formule approchée plus bas se dégrade pour
# les petites grilles (le coin de la zone irréductible pèse alors lourd), or
# 4×4×4 est justement la grille q par défaut du pipeline.
_CUBIC_IRR_LOOKUP: dict[int, int] = {
    2: 3, 4: 8, 6: 16, 8: 29, 10: 47, 12: 72,
}


@dataclass
class MaterialDescriptors:
    """Grandeurs de ``scf.in`` qui pilotent le coût du calcul."""

    nat: int = 2
    ntyp: int = 1
    ibrav: Optional[int] = None
    ecutwfc: float = 60.0
    ecutrho: Optional[float] = None
    nk: tuple[int, int, int] = (12, 12, 12)
    nk_irreducible: Optional[int] = None
    nk_source: str = "estimé"
    nq: tuple[int, int, int] = (4, 4, 4)
    nq_irreducible: Optional[int] = None
    nq_source: str = "estimé"
    material_id: str = ""

    @property
    def n_modes(self) -> int:
        """3·nat branches phononiques — nombre de systèmes DFPT par point q."""
        return max(3, 3 * max(1, self.nat))

    def work_scf(self) -> float:
        """Travail d'un SCF, normalisé à 1 pour le matériau de référence."""
        nk_irr = self.nk_irreducible or estimate_irreducible_points(self.nk, self.ibrav)
        return (
            (max(1, self.nat) / REF_NAT) ** NAT_EXPONENT
            * (max(1, nk_irr) / REF_NK_IRR)
            * (max(1.0, self.ecutwfc) / REF_ECUTWFC) ** ECUT_EXPONENT
        )

    def ram_per_rank_mb(self) -> int:
        """Ordre de grandeur de la mémoire par rang MPI.

        Approximation volontairement grossière (l'empreinte réelle dépend des
        pseudos et de la FFT), utilisée seulement pour alerter sur un risque
        d'OOM, pas pour dimensionner quoi que ce soit.
        """
        nk_irr = self.nk_irreducible or estimate_irreducible_points(self.nk, self.ibrav)
        base = 120.0
        return int(base + 6.0 * self.nat * (self.ecutwfc / 60.0) ** 1.5 * math.sqrt(max(1, nk_irr)))

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["nk"] = list(self.nk)
        d["nq"] = list(self.nq)
        d["n_modes"] = self.n_modes
        d["work_scf"] = round(self.work_scf(), 4)
        return d


def estimate_irreducible_points(
    grid: tuple[int, int, int], ibrav: Optional[int]
) -> int:
    """Points irréductibles d'une grille de Monkhorst-Pack non décalée.

    Exact via table pour les grilles cubiques n×n×n usuelles ; sinon approché
    par ``N/n_symops`` corrigé d'un facteur ``1 + 12/n``, la zone irréductible
    incluant ses faces et arêtes (une simple division sous-estime fortement les
    petites grilles). Cette valeur n'est utilisée qu'avant lancement : dès que
    la sortie QE existe, on lit le compte exact.
    """
    n1, n2, n3 = (max(1, int(g)) for g in grid)
    total = n1 * n2 * n3
    symops = _IBRAV_SYMOPS.get(int(ibrav) if ibrav is not None else 0, 4)

    if n1 == n2 == n3 and symops == 48 and n1 in _CUBIC_IRR_LOOKUP:
        return _CUBIC_IRR_LOOKUP[n1]

    n_mean = (n1 * n2 * n3) ** (1.0 / 3.0)
    correction = 1.0 + 12.0 / max(2.0, n_mean)
    return max(1, int(round(total / symops * correction)))


# ---------------------------------------------------------------------------
# Lecture des descripteurs
# ---------------------------------------------------------------------------
_PW_CANDIDATES = (
    "pw_scf_V0_for_phonon.in",
    "scf.in",
    "1_eos_volumes/scf_eq.in",
)


def _search_int(text: str, key: str) -> Optional[int]:
    m = re.search(rf"(?im)^\s*{key}\s*=\s*([+-]?\d+)", text)
    return int(m.group(1)) if m else None


def _search_float(text: str, key: str) -> Optional[float]:
    m = re.search(
        rf"(?im)^\s*{re.escape(key)}\s*=\s*([+-]?[\d.]+(?:[dDeE][+-]?\d+)?)", text
    )
    if not m:
        return None
    try:
        return float(m.group(1).replace("d", "e").replace("D", "e"))
    except ValueError:
        return None


def _parse_kpoints_grid(text: str) -> Optional[tuple[int, int, int]]:
    """Grille de la carte ``K_POINTS automatic`` (ligne suivant l'en-tête)."""
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if re.match(r"(?i)^\s*K_POINTS", line):
            if "automatic" not in line.lower():
                return None
            for nxt in lines[i + 1 : i + 4]:
                nums = re.findall(r"[-+]?\d+", nxt)
                if len(nums) >= 3:
                    return (int(nums[0]), int(nums[1]), int(nums[2]))
            return None
    return None


def parse_pw_out_nk_irreducible(path: Path) -> Optional[int]:
    """« number of k points= N » d'une sortie pw.x — compte exact."""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    m = re.search(r"(?i)number of k points\s*=\s*(\d+)", text)
    return int(m.group(1)) if m else None


def parse_material_descriptors(
    work_dir: Optional[Path] = None,
    *,
    pw_path: Optional[Path] = None,
    nq: Optional[tuple[int, int, int]] = None,
    material_id: str = "",
) -> MaterialDescriptors:
    """Descripteurs depuis un fichier pw.x (chemin direct ou work_dir)."""
    text = ""
    resolved: Optional[Path] = None
    if pw_path is not None and Path(pw_path).is_file():
        resolved = Path(pw_path)
    elif work_dir is not None:
        for cand in _PW_CANDIDATES:
            p = Path(work_dir) / cand
            if p.is_file():
                resolved = p
                break
    if resolved is not None:
        try:
            text = resolved.read_text(encoding="utf-8", errors="replace")
        except OSError:
            text = ""

    desc = MaterialDescriptors(material_id=material_id)
    if text:
        desc.nat = _search_int(text, "nat") or desc.nat
        desc.ntyp = _search_int(text, "ntyp") or desc.ntyp
        desc.ibrav = _search_int(text, "ibrav")
        desc.ecutwfc = _search_float(text, "ecutwfc") or desc.ecutwfc
        desc.ecutrho = _search_float(text, "ecutrho")
        grid = _parse_kpoints_grid(text)
        if grid:
            desc.nk = grid

    # Grille q : argument explicite, sinon ph.in, sinon défaut pipeline 4×4×4.
    if nq is not None:
        desc.nq = nq
    elif work_dir is not None:
        ph_in = Path(work_dir) / "ph.in"
        if ph_in.is_file():
            try:
                pt = ph_in.read_text(encoding="utf-8", errors="replace")
                got = tuple(_search_int(pt, f"nq{i}") or 0 for i in (1, 2, 3))
                if all(g > 0 for g in got):
                    desc.nq = got  # type: ignore[assignment]
            except OSError:
                pass

    # Comptes exacts si les sorties QE existent déjà (bien plus fiable).
    if work_dir is not None:
        wd = Path(work_dir)
        for out_name in ("scf.out", "pw_scf_V0_for_phonon.out", "nscf.out"):
            nk_irr = parse_pw_out_nk_irreducible(wd / out_name)
            if nk_irr:
                desc.nk_irreducible, desc.nk_source = nk_irr, f"lu ({out_name})"
                break
        prog = parse_ph_out_progress(wd / "ph.out")
        if prog.get("q_total"):
            desc.nq_irreducible = int(prog["q_total"])
            desc.nq_source = "lu (ph.out)"

    if desc.nk_irreducible is None:
        desc.nk_irreducible = estimate_irreducible_points(desc.nk, desc.ibrav)
    if desc.nq_irreducible is None:
        desc.nq_irreducible = estimate_irreducible_points(desc.nq, desc.ibrav)
    return desc


# ---------------------------------------------------------------------------
# Progression réelle (ETA live)
# ---------------------------------------------------------------------------
def parse_ph_out_progress(ph_out: Path) -> dict[str, Any]:
    """Avancement de ph.x : points q total/faits, coût par q, temps CPU.

    ph.x annonce la liste complète des q irréductibles au démarrage, puis un
    « Calculation of q = … » par point et un « total cpu time » cumulé par
    itération. On en déduit un coût moyen par point q **mesuré sur ce run**,
    donc un reste-à-faire nettement plus fiable qu'une estimation a priori.
    """
    empty = {
        "q_total": None, "q_started": 0, "q_done": 0,
        "cpu_seconds": 0.0, "seconds_per_q": None, "current_q": None,
    }
    try:
        text = ph_out.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return empty

    lines = text.splitlines()

    # Total : la table « N xq(1) xq(2) xq(3) » liste tous les q irréductibles.
    q_total: Optional[int] = None
    for i, line in enumerate(lines):
        if re.search(r"xq\(1\)", line):
            last = 0
            for nxt in lines[i + 1 :]:
                m = re.match(r"\s*(\d+)\s+[-+]?[\d.]+\s+[-+]?[\d.]+\s+[-+]?[\d.]+", nxt)
                if m:
                    last = max(last, int(m.group(1)))
                elif last:
                    break
            if last:
                q_total = last if q_total is None else max(q_total, last)

    # Coût cumulé au moment de chaque changement de point q.
    boundaries: list[float] = []
    cpu = 0.0
    current_q: Optional[str] = None
    started = 0
    for line in lines:
        if "Calculation of q" in line:
            started += 1
            current_q = line.split("=", 1)[-1].strip()
            boundaries.append(cpu)
        m = re.search(r"total cpu time\s*:\s*([\d.]+)\s*secs", line)
        if m:
            try:
                cpu = float(m.group(1))
            except ValueError:
                pass

    done = max(0, started - 1)  # le q courant n'est pas terminé
    seconds_per_q: Optional[float] = None
    if done >= 1 and cpu > 0:
        # On crédite le q en cours à moitié : moyenne plus stable qu'un simple
        # cpu/done, qui surestime dès qu'un point vient de commencer.
        seconds_per_q = cpu / (done + 0.5)
    return {
        "q_total": q_total,
        "q_started": started,
        "q_done": done,
        "cpu_seconds": cpu,
        "seconds_per_q": seconds_per_q,
        "current_q": current_q,
    }


def parse_eos_grid_progress(work_dir: Path, *, n_volumes: int = 7) -> dict[str, Any]:
    """Volumes de la grille EOS terminés (``JOB DONE`` dans scf_vol_*.out)."""
    tdir = Path(work_dir) / "1_eos_volumes"
    if not tdir.is_dir():
        tdir = Path(work_dir)
    done = 0
    found = 0
    for p in sorted(tdir.glob("scf_vol_*.out")):
        found += 1
        try:
            if "JOB DONE" in p.read_text(encoding="utf-8", errors="replace"):
                done += 1
        except OSError:
            continue
    return {"volumes_total": max(n_volumes, found), "volumes_done": done}


def parse_thermo_qha_progress(
    work_dir: Path, *, phase_started_at: Optional[datetime] = None
) -> dict[str, Any]:
    """Avancement de thermo_pw.x en mode QHA (une chaîne phonon par géométrie).

    thermo_pw recalcule les phonons sur ``ngeo`` géométries (volumes autour de
    V₀). Trois marqueurs fichiers suffisent à mesurer le rythme réel du run :

      * ``thermo_pw_run.out`` annonce « Number of geometries to compute: N » ;
      * ``therm_files/output_therm.dat.gK`` apparaît quand la géométrie K est
        terminée — son mtime date la fin, donc les écarts entre mtimes
        successifs donnent la durée mesurée de chaque géométrie ;
      * ``dynamical_matrices/ph_dyn.gK.M`` s'accumulent pendant la géométrie K
        (fraction déjà faite de la géométrie courante).

    ``phase_started_at`` (début de l'étape thermo_pw, lu dans les steps du
    job) permet de dater la première géométrie ; sans lui il faut au moins
    deux géométries terminées pour mesurer un rythme.
    """
    wd = Path(work_dir)
    empty: dict[str, Any] = {
        "geometries_total": None, "geometries_done": 0,
        "current_fraction": 0.0, "seconds_per_geometry": None,
        "remaining_seconds": None,
    }

    total: Optional[int] = None
    out = wd / "thermo_pw_run.out"
    if out.is_file():
        try:
            with out.open(encoding="utf-8", errors="replace") as fh:
                # L'annonce arrive dans l'en-tête ; borne de sécurité pour ne
                # jamais balayer un .out de plusieurs Mo à chaque sondage.
                for _ in range(4000):
                    line = fh.readline()
                    if not line:
                        break
                    m = re.search(
                        r"Number of geometries to compute:\s*(\d+)", line
                    )
                    if m:
                        total = int(m.group(1))
                        break
        except OSError:
            pass

    # Géométries terminées, datées par le mtime de leur output_therm.dat.gK.
    finished: list[tuple[int, float]] = []
    for p in (wd / "therm_files").glob("output_therm.dat.g*"):
        m = re.search(r"\.g(\d+)$", p.name)
        if not m:
            continue
        try:
            finished.append((int(m.group(1)), p.stat().st_mtime))
        except OSError:
            continue
    finished.sort()

    # Matrices dynamiques : compte de fichiers par géométrie → fraction de la
    # géométrie courante (chaque fichier = un point q terminé).
    groups: dict[int, int] = {}
    for p in (wd / "dynamical_matrices").glob("ph_dyn.g*"):
        m = re.search(r"\.g(\d+)(?:\.|$)", p.name)
        if m:
            gi = int(m.group(1))
            groups[gi] = groups.get(gi, 0) + 1

    done = len(finished)
    if total is None:
        candidates = list(groups) + [done]
        total = max(candidates) if any(candidates) else None
    if not total:
        return empty

    done_idx = {k for k, _ in finished}
    per_geom_files = max(
        (n for g, n in groups.items() if g in done_idx), default=0
    )
    frac = 0.0
    pending = [(g, n) for g, n in groups.items() if g not in done_idx]
    if pending and per_geom_files:
        _, n_cur = max(pending)
        # Plafond 0.95 : le dernier point q écrit ne signifie pas géométrie
        # finie (post-traitement thermo par géométrie non compté).
        frac = min(0.95, n_cur / per_geom_files)

    # Rythme mesuré : différences de mtimes entre fins de géométries
    # successives ; la première a besoin de l'heure de départ de la phase.
    marks: list[float] = []
    if phase_started_at is not None:
        marks.append(phase_started_at.timestamp())
    marks.extend(ts for _, ts in finished)
    durations = [b - a for a, b in zip(marks, marks[1:]) if b > a]
    spg: Optional[float] = None
    if durations:
        # Moyenne des 3 dernières : les premières géométries (loin de V₀)
        # convergent souvent plus lentement, le rythme récent est plus fidèle.
        recent = durations[-3:]
        spg = sum(recent) / len(recent)

    remaining: Optional[float] = None
    if spg is not None:
        remaining = max(0.0, spg * (total - done - frac))

    return {
        "geometries_total": int(total),
        "geometries_done": done,
        "current_fraction": round(frac, 2),
        "seconds_per_geometry": round(spg, 1) if spg else None,
        "remaining_seconds": (
            round(remaining, 1) if remaining is not None else None
        ),
    }


def parse_pw_wall_seconds(out_path: Path) -> Optional[float]:
    """« PWSCF : ... CPU ... WALL » → secondes d'horloge (calibration)."""
    try:
        text = out_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    m = None
    for m in re.finditer(
        r"(?im)^\s*\S+\s*:\s*(?:([\d.]+)h)?\s*(?:([\d.]+)m)?\s*([\d.]+)s\s+CPU"
        r"\s+(?:([\d.]+)h)?\s*(?:([\d.]+)m)?\s*([\d.]+)s\s+WALL",
        text,
    ):
        pass
    if not m:
        return None
    h, mn, s = m.group(4), m.group(5), m.group(6)
    try:
        return (
            float(h or 0) * 3600.0 + float(mn or 0) * 60.0 + float(s or 0)
        )
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# Magasin de calibration (auto-apprentissage local)
# ---------------------------------------------------------------------------
_CALIB_LOCK = threading.Lock()
_CALIB_VERSION = 1
# En dessous, l'étape a presque sûrement été sautée plutôt qu'exécutée.
_MIN_SAMPLE_SECONDS = 5.0
# Écart maximal toléré vis-à-vis de la constante livrée, dans les deux sens.
_MAX_SAMPLE_RATIO = 20.0


def _calib_path() -> Path:
    return Path(__file__).resolve().parent / ".runtime_calibration.json"


def load_calibration() -> dict[str, Any]:
    try:
        d = json.loads(_calib_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"version": _CALIB_VERSION, "samples": []}
    if not isinstance(d, dict) or d.get("version") != _CALIB_VERSION:
        return {"version": _CALIB_VERSION, "samples": []}
    d.setdefault("samples", [])
    return d


def record_step_measurement(
    *,
    step: str,
    cost_key: str,
    wall_seconds: float,
    units: float,
    work_scf: float,
    throughput: float,
    profile_id: str = "",
    material_id: str = "",
    max_samples: int = 400,
) -> None:
    """Enregistre une durée réelle, ramenée en secondes normalisées.

    ``units`` = nombre d'unités de l'étape (volumes EOS, q×modes pour ph.x, 1
    sinon). Les échantillons servent ensuite de facteur correctif multiplicatif
    sur les constantes livrées.

    Deux filtres protègent le magasin, car une mesure aberrante y resterait et
    fausserait durablement les estimations affichées :

    * durée plancher — le pipeline saute une étape dont les sorties existent
      déjà (reprise, relance sur un work_dir peuplé) et émet alors ``done`` en
      une fraction de seconde ; enregistrer cela apprendrait qu'un SCF prend
      1 s ;
    * garde-fou d'ordre de grandeur — au-delà d'un facteur 20 dans un sens ou
      dans l'autre par rapport à la constante livrée, il s'agit presque
      toujours d'une étape court-circuitée ou d'un plantage précoce, pas d'une
      machine réellement mille fois plus rapide.
    """
    if wall_seconds <= 0 or units <= 0 or work_scf <= 0 or throughput <= 0:
        return
    if wall_seconds < _MIN_SAMPLE_SECONDS:
        return
    normalized = wall_seconds * throughput / (units * work_scf)
    if not math.isfinite(normalized) or normalized <= 0:
        return
    shipped = STEP_COSTS.get(cost_key)
    if shipped is not None and shipped.seconds_normalized > 0:
        ratio = normalized / shipped.seconds_normalized
        if not (1.0 / _MAX_SAMPLE_RATIO <= ratio <= _MAX_SAMPLE_RATIO):
            return
    with _CALIB_LOCK:
        data = load_calibration()
        data["samples"].append(
            {
                "step": step,
                "cost_key": cost_key,
                "normalized": round(normalized, 3),
                "wall_seconds": round(wall_seconds, 1),
                "units": units,
                "work_scf": round(work_scf, 4),
                "throughput": round(throughput, 3),
                "profile_id": profile_id,
                "material_id": material_id,
            }
        )
        data["samples"] = data["samples"][-max_samples:]
        try:
            _calib_path().write_text(
                json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8"
            )
        except OSError:
            pass


def calibrated_cost(cost_key: str, calib: Optional[dict[str, Any]] = None) -> StepCost:
    """Constante livrée, corrigée par la médiane des mesures locales."""
    base = STEP_COSTS.get(cost_key)
    if base is None:
        return StepCost(300.0, "dérivé", "étape inconnue — valeur par défaut")
    calib = calib if calib is not None else load_calibration()
    vals = sorted(
        float(s["normalized"])
        for s in calib.get("samples", [])
        if s.get("cost_key") == cost_key and float(s.get("normalized", 0)) > 0
    )
    if not vals:
        return base
    mid = len(vals) // 2
    median = vals[mid] if len(vals) % 2 else 0.5 * (vals[mid - 1] + vals[mid])
    return StepCost(
        median,
        "calibré",
        f"médiane de {len(vals)} mesure(s) sur cette machine",
    )


# ---------------------------------------------------------------------------
# Estimation par profil
# ---------------------------------------------------------------------------
@dataclass
class StepEstimate:
    step: str
    cost_key: str
    units: float
    seconds: float
    provenance: str
    comment: str = ""
    # Débit retenu pour cette étape. Conservé car la grille EOS n'utilise pas
    # le même que les autres (volumes concurrents) : sans lui, ré-injecter une
    # durée mesurée dans le magasin de calibration la normaliserait de travers.
    throughput: float = 1.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "step": self.step,
            "cost_key": self.cost_key,
            "units": self.units,
            "seconds": round(self.seconds, 1),
            "human": humanize_seconds(self.seconds),
            "provenance": self.provenance,
            "comment": self.comment,
            "throughput": round(self.throughput, 4),
        }


@dataclass
class RuntimeEstimate:
    profile_id: str
    total_seconds: float
    low_seconds: float
    high_seconds: float
    steps: list[StepEstimate] = field(default_factory=list)
    machine: dict[str, Any] = field(default_factory=dict)
    descriptors: dict[str, Any] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    confidence: str = "faible"
    nproc: int = 1
    dominant_step: str = ""

    def step_by_name(self, step: str) -> Optional[StepEstimate]:
        """Étape estimée portant ce nom (clé de ``_emit_step``)."""
        for s in self.steps:
            if s.step == step:
                return s
        return None

    @property
    def work_scf(self) -> float:
        return float(self.descriptors.get("work_scf") or 1.0)

    def to_dict(self) -> dict[str, Any]:
        return {
            "profile_id": self.profile_id,
            "nproc": self.nproc,
            "total_seconds": round(self.total_seconds, 1),
            "total_human": humanize_seconds(self.total_seconds),
            "range_human": (
                f"{humanize_seconds(self.low_seconds)} – "
                f"{humanize_seconds(self.high_seconds)}"
            ),
            "low_seconds": round(self.low_seconds, 1),
            "high_seconds": round(self.high_seconds, 1),
            "confidence": self.confidence,
            "dominant_step": self.dominant_step,
            "steps": [s.to_dict() for s in self.steps],
            "machine": self.machine,
            "descriptors": self.descriptors,
            "warnings": self.warnings,
        }


def humanize_seconds(seconds: float) -> str:
    """Durée lisible : « 45 s », « 12 min », « 3 h 20 », « 1 j 4 h »."""
    s = max(0.0, float(seconds))
    if s < 90:
        return f"{s:.0f} s"
    minutes = s / 60.0
    if minutes < 60:
        return f"{minutes:.0f} min"
    hours = minutes / 60.0
    if hours < 36:
        h = int(hours)
        rem = int(round((hours - h) * 60))
        if rem == 60:
            h, rem = h + 1, 0
        return f"{h} h {rem:02d}" if rem else f"{h} h"
    days = hours / 24.0
    d = int(days)
    rem_h = int(round((days - d) * 24))
    return f"{d} j {rem_h} h" if rem_h else f"{d} j"


# Mot-clé thermo_pw par profil → clé de coût (hors boucle QHA).
_THERMO_WHAT_COST = {
    "scf_elastic_constants": "thermo_pw_scf_elastic_constants",
    "thermo": "thermo_pw_thermo",
    "mur_lc_t": "thermo_pw_thermo",
    "elastic_constants_geo": "thermo_pw_elastic_constants_geo",
    "ph_life": "thermo_pw_ph_life",
    "dielectric": "thermo_pw_dielectric",
}

# Profils QHA : thermo_pw relance une chaîne phonon complète par géométrie.
_QHA_WHAT_KEYS = frozenset({
    "thermo",
    "mur_lc_t",
    "elastic_constants_geo",
    "mur_lc_t_elastic_constants",
    "ph_life",
})


def qha_n_geometries(*, n_eos_volumes: int = 7) -> int:
    """Nombre de géométries QHA (grille EOS 7 pts → 9 géom. mesurées sur Si)."""
    return max(9, int(n_eos_volumes) + 2)


def is_qha_profile(profile: dict[str, Any]) -> bool:
    what = str(profile.get("what_qe") or "").strip().lower()
    return bool(profile.get("needs_eos")) and what in _QHA_WHAT_KEYS


def estimate_runtime(
    *,
    profile_id: str,
    profile: dict[str, Any],
    descriptors: MaterialDescriptors,
    machine: Optional[MachineProfile] = None,
    nproc: int = 1,
    n_eos_volumes: int = 7,
    extra_whats: Optional[list[str]] = None,
    lo_to_opt_in: bool = False,
    eos_parallel_jobs: Optional[int] = None,
) -> RuntimeEstimate:
    """Durée attendue d'un profil, étape par étape, sur cette machine."""
    machine = machine or detect_machine()
    nproc = max(1, int(nproc))
    calib = load_calibration()
    work = descriptors.work_scf()

    throughput = machine.throughput(nproc)
    # La grille EOS lance plusieurs volumes en parallèle, chacun avec nproc
    # rangs : le débit se calcule donc sur le total des rangs en vol, ce qui
    # capture la contention quand npar × nproc dépasse les cœurs physiques.
    npar = eos_parallel_jobs
    if npar is None:
        npar = max(1, min(n_eos_volumes, max(1, machine.cores_available - 1), 8))
    throughput_eos = machine.throughput(nproc, concurrent_ranks=npar * nproc)

    steps: list[StepEstimate] = []

    def add(step: str, cost_key: str, units: float, thru: float) -> None:
        if units <= 0:
            return
        cost = calibrated_cost(cost_key, calib)
        seconds = cost.seconds_normalized * units * work / thru
        steps.append(
            StepEstimate(
                step=step, cost_key=cost_key, units=units,
                seconds=seconds, provenance=cost.provenance, comment=cost.comment,
                throughput=thru,
            )
        )

    if profile.get("needs_eos"):
        add("eos_grid", "eos_grid_per_volume", n_eos_volumes, throughput_eos)
    else:
        add("scf_eq", "scf_eq", 1, throughput)

    if profile.get("needs_phonons"):
        add("scf_phonon", "scf_eq", 1, throughput)
        n_q = descriptors.nq_irreducible or estimate_irreducible_points(
            descriptors.nq, descriptors.ibrav
        )
        add("ph", "ph_per_q_mode", n_q * descriptors.n_modes, throughput)
        add("q2r", "q2r", 1, throughput)
        add("matdyn", "matdyn", 1, throughput)

    if not profile.get("skip_thermo_pw", False):
        what = str(profile.get("what_qe") or "").strip()
        what_l = what.lower()
        if is_qha_profile(profile):
            # Chaque géométrie QHA ≈ ph.x (q irr. × modes) + SCF déformé : la
            # constante ``ph_per_q_mode`` calibrée sur le run de référence
            # reproduit le rythme mesuré (~1,5–3 h/géom. sur laptop 2 cœurs).
            n_geo = qha_n_geometries(n_eos_volumes=n_eos_volumes)
            n_q = descriptors.nq_irreducible or estimate_irreducible_points(
                descriptors.nq, descriptors.ibrav
            )
            add(
                "thermo_pw",
                "ph_per_q_mode",
                n_geo * n_q * descriptors.n_modes,
                throughput,
            )
            if what_l in ("elastic_constants_geo", "mur_lc_t_elastic_constants"):
                add(
                    "thermo_pw_extra",
                    "thermo_pw_elastic_constants_geo",
                    1,
                    throughput,
                )
            elif what_l == "ph_life":
                add("thermo_pw_extra", "thermo_pw_ph_life", 1, throughput)
        else:
            add(
                "thermo_pw",
                _THERMO_WHAT_COST.get(what_l, "thermo_pw_thermo"),
                1,
                throughput,
            )

    if profile.get("properties_enabled"):
        add("electronic_props", "electronic_props", 1, throughput)

    if profile.get("needs_optical"):
        add("optical_props", "optical_props", 1, throughput)

    n_extra = len(extra_whats or profile.get("default_extra_whats") or [])
    if n_extra:
        add("thermo_extras", "thermo_extra", n_extra, throughput)

    if lo_to_opt_in and profile_id == "P1":
        add("lo_to", "lo_to", 1, throughput)

    total = sum(s.seconds for s in steps)

    # Fourchette : resserrée quand les étapes dominantes sont calibrées sur la
    # machine, large quand tout repose sur des constantes dérivées.
    measured = sum(s.seconds for s in steps if s.provenance in ("mesuré", "calibré"))
    share = (measured / total) if total > 0 else 0.0
    if share > 0.85:
        spread, confidence = 0.30, "bonne"
    elif share > 0.5:
        spread, confidence = 0.50, "moyenne"
    else:
        spread, confidence = 0.75, "faible"

    warnings = machine.warnings_for(
        nproc, ram_needed_mb=descriptors.ram_per_rank_mb() * nproc
    )
    if npar * nproc > machine.cores_logical and profile.get("needs_eos"):
        warnings.append(
            f"Grille EOS : {npar} volumes en parallèle × {nproc} rangs = "
            f"{npar * nproc} processus pour {machine.cores_logical} threads. "
            f"La contention allonge cette étape."
        )
    if descriptors.nq_source == "estimé" and profile.get("needs_phonons"):
        warnings.append(
            f"Nombre de points q irréductibles estimé par symétrie "
            f"({descriptors.nq_irreducible} pour la grille "
            f"{'×'.join(str(x) for x in descriptors.nq)}) : la valeur exacte "
            f"sera lue dans ph.out dès le démarrage de ph.x."
        )
    if is_qha_profile(profile):
        n_geo = qha_n_geometries(n_eos_volumes=n_eos_volumes)
        warnings.append(
            f"thermo_pw QHA : ~{n_geo} géométries (chaîne phonon complète "
            f"chacune) — dominante sur P2–P4 ; l'ETA live affiné pendant le run."
        )

    dominant = max(steps, key=lambda s: s.seconds).step if steps else ""
    return RuntimeEstimate(
        profile_id=profile_id,
        total_seconds=total,
        low_seconds=total * (1.0 - spread * 0.5),
        high_seconds=total * (1.0 + spread),
        steps=steps,
        machine=machine.to_dict(),
        descriptors=descriptors.to_dict(),
        warnings=warnings,
        confidence=confidence,
        nproc=nproc,
        dominant_step=dominant,
    )


# ---------------------------------------------------------------------------
# ETA pendant le run
# ---------------------------------------------------------------------------
def live_eta(
    *,
    work_dir: Path,
    estimate: RuntimeEstimate,
    steps_done: set[str],
    current_step: Optional[str],
    current_step_started_at: Optional[datetime] = None,
) -> dict[str, Any]:
    """Reste-à-faire mesuré sur le run en cours plutôt que prédit.

    Pour ph.x — de très loin l'étape la plus longue — le coût par point q est
    relevé dans ph.out, ce qui donne un ETA fiable même si l'estimation a
    priori était fausse d'un facteur deux. Même logique pour la boucle QHA de
    thermo_pw.x (une chaîne phonon complète par géométrie) : le rythme réel
    est mesuré sur les géométries déjà terminées de CE run.
    """
    wd = Path(work_dir)
    per_step = {s.step: s.seconds for s in estimate.steps}
    remaining = 0.0
    basis = "estimation a priori"
    detail: dict[str, Any] = {}

    for step, seconds in per_step.items():
        if step in steps_done:
            continue
        if step == current_step:
            continue
        remaining += seconds

    if current_step == "ph":
        prog = parse_ph_out_progress(wd / "ph.out")
        q_total = prog.get("q_total") or estimate.descriptors.get("nq_irreducible")
        spq = prog.get("seconds_per_q")
        if q_total and spq:
            left = max(0.0, float(q_total) - prog["q_done"] - 0.5)
            remaining += left * float(spq)
            basis = "mesuré sur ph.out"
            detail = {
                "q_done": prog["q_done"],
                "q_total": int(q_total),
                "seconds_per_q": round(float(spq), 1),
                "current_q": prog.get("current_q"),
            }
        else:
            remaining += per_step.get("ph", 0.0)
    elif current_step == "eos_grid":
        prog = parse_eos_grid_progress(wd)
        tot, done = prog["volumes_total"], prog["volumes_done"]
        if tot:
            remaining += per_step.get("eos_grid", 0.0) * max(0.0, 1.0 - done / tot)
            basis = "mesuré (volumes terminés)"
            detail = prog
    elif current_step == "thermo_pw":
        # Boucle QHA : ngeo chaînes phonon complètes. L'estimation a priori
        # (constante thermo_pw_thermo) sous-estime largement cette phase ;
        # le rythme mesuré géométrie par géométrie la remplace dès que la
        # première géométrie est datée.
        prog = parse_thermo_qha_progress(
            wd, phase_started_at=current_step_started_at
        )
        if prog.get("remaining_seconds") is not None:
            remaining += float(prog["remaining_seconds"])
            basis = "mesuré (géométries QHA)"
            detail = {
                "geometries_done": prog["geometries_done"],
                "geometries_total": prog["geometries_total"],
                "current_fraction": prog["current_fraction"],
                "seconds_per_geometry": prog["seconds_per_geometry"],
            }
        else:
            remaining += per_step.get("thermo_pw", 0.0)
    elif current_step:
        remaining += per_step.get(current_step, 0.0)

    return {
        "remaining_seconds": round(remaining, 1),
        "remaining_human": humanize_seconds(remaining),
        "basis": basis,
        "current_step": current_step,
        "detail": detail,
    }

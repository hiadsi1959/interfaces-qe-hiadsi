import textwrap
from pathlib import Path
import pytest

import importlib.util
import sys
from pathlib import Path

spec = importlib.util.spec_from_file_location("work_thermo", str(Path(__file__).resolve().parents[1] / "work_thermo.py"))
wt = importlib.util.module_from_spec(spec)
sys.modules["work_thermo"] = wt
spec.loader.exec_module(wt)


def test_parse_conv_thr_values():
    s1 = """
    &ELECTRONS
      conv_thr = 1.0D-12
    /
    """
    assert wt._parse_conv_thr_from_content(s1) == pytest.approx(1.0e-12)

    s2 = "conv_thr=1.0D-8"
    assert wt._parse_conv_thr_from_content(s2) == pytest.approx(1.0e-8)

    s3 = "no conv here"
    assert wt._parse_conv_thr_from_content(s3) is None


def test_extract_pseudos_block_and_files(tmp_path):
    content = textwrap.dedent("""
    &CONTROL
      outdir = 'out/'
      pseudo_dir = '/tmp/pseudos/'
    /
    ATOMIC_SPECIES
    Si 28.0855 Si.pbe-n-rrkjus.UPF
    O  15.999  O.pbe-n.UPF
    """)
    pd, files = wt._extract_pseudos_from_input(content)
    assert pd == "/tmp/pseudos/"
    assert "Si.pbe-n-rrkjus.UPF" in files
    assert "O.pbe-n.UPF" in files


def test_is_pseudo_file_norm_conserving(tmp_path):
    p = tmp_path / "Si.UPF"
    p.write_text('<PP_HEADER type="NC" label="Si" />', encoding='utf-8')
    assert wt._is_pseudo_file_norm_conserving(p)

    q = tmp_path / "Fe.UPF"
    q.write_text('/* Ultrasoft pseudo */', encoding='utf-8')
    assert not wt._is_pseudo_file_norm_conserving(q)

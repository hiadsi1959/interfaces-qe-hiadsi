"""
Tests pour ``backend.phonon_imaginary_recommendations``.

Couvre :
  * Pas d'imaginaire → résumé sans items.
  * Imaginaire détecté → items présents, triés par priority.
  * Catégories déclenchées selon les artefacts (PBE/PAW/q=2 convergent
    en haut de la liste, etc.).
  * Format JSON-compatible (round-trip via ``json.dumps``).

Coût CPU nul : on génère un ``tmp_path`` factice avec du texte minimal
simulant les anomalies courantes. Aucune exécution de Quantum ESPRESSO.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from phonon_imaginary_recommendations import (
    PhononImaginaryRecommendation,
    build_phonon_imaginary_recommendations,
    find_phonon_imaginary_recommendations,
)


# ---------------------------------------------------------------------------
# Fixtures : work_dir temporaires pour déclencher les recommandations.
# ---------------------------------------------------------------------------

@pytest.fixture()
def stable_workdir(tmp_path: Path) -> Path:
    """Cas pathologique : pas de imag. → pas de recommandations."""
    wd = tmp_path / "stable"
    wd.mkdir()
    # pw_scf_V0_for_phonon.in — bien convergé
    (wd / "pw_scf_V0_for_phonon.in").write_text(
        "&CONTROL\n"
        "  calculation = 'scf'\n"
        "/\n"
        "&SYSTEM\n"
        "  ibrav = 2, celldm(1) = 10.34, nat = 2, ntyp = 1,\n"
        "  ecutwfc = 80.0,\n"
        "  input_dft = 'PBE'\n"
        "/\n"
        "&ELECTRONS\n"
        "  conv_thr = 1.0d-12\n"
        "/\n"
        "ATOMIC_SPECIES\n"
        "  Si  28.0855  Si.pbe-n-kjpaw_psl.0.1.UPF\n"
        "ATOMIC_POSITIONS (crystal)\n"
        "  Si 0.00 0.00 0.00\n"
        "  Si 0.25 0.25 0.25\n"
    , encoding="utf-8")
    (wd / "ph.in").write_text(
        "&INPUTPH\n"
        "  tr2_ph = 1.0d-15,\n"
        "  prefix = 'pw',\n"
        "  outdir = './out_scf_eq/'\n"
        "  nq1 = 6, nq2 = 6, nq3 = 6\n"
        "/\n"
    , encoding="utf-8")
    (wd / "q2r.in").write_text(
        "&input\n"
        "  zasr = 'crystal'\n"
        "  fildyn = 'ph_dyn', flfrc = 'fc.out'\n"
        "/\n"
    , encoding="utf-8")
    return wd


@pytest.fixture()
def imag_paw_pbe_q2low_workdir(tmp_path: Path) -> Path:
    """Cas pathologique critique : PAW + PBE + q-grid=2 → fort signal."""
    wd = tmp_path / "imag_serious"
    wd.mkdir()
    (wd / "pw_scf_V0_for_phonon.in").write_text(
        "&CONTROL\n  calculation = 'scf'\n/\n"
        "&SYSTEM\n"
        "  ibrav = 2, celldm(1) = 10.34, nat = 2, ntyp = 1,\n"
        "  ecutwfc = 30.0,\n"  # trop bas
        "  conv_thr = 1.0d-8,\n"  # trop lâche
        "  input_dft = 'PBE'\n"
        "/\n"
        "&ELECTRONS\n/\n"
        "ATOMIC_SPECIES\n"
        "  Si  28.0855  Si.pbe-n-kjpaw_psl.0.1.UPF\n"
    , encoding="utf-8")
    (wd / "ph.in").write_text(
        "&INPUTPH\n"
        "  tr2_ph = 1.0d-12,\n"  # pas serré
        "  nq1 = 2, nq2 = 2, nq3 = 2\n"  # sous le seuil
        "/\n"
    , encoding="utf-8")
    (wd / "q2r.in").write_text(
        "&input\n  zasr = 'simple'\n/  # pas crystal\n"
    , encoding="utf-8")
    return wd


@pytest.fixture()
def imag_lda_uspp_q6_workdir(tmp_path: Path) -> Path:
    """Cas moins critique : LDA + USPP + 6×6×6 → peu de signaux."""
    wd = tmp_path / "imag_minor"
    wd.mkdir()
    (wd / "pw_scf_V0_for_phonon.in").write_text(
        "&CONTROL\n  calculation = 'vc-relax'\n"  # déjà relaxé
        "/\n"
        "&SYSTEM\n"
        "  ecutwfc = 80.0,\n"
        "  conv_thr = 1.0d-12,\n"
        "  input_dft = 'LDA'\n"
        "/\n"
        "&ELECTRONS\n/\n"
        "ATOMIC_SPECIES\n"
        "  Si  28.0855  Si.rrkjus_psl.0.2.UPF\n"  # USPP
    , encoding="utf-8")
    (wd / "ph.in").write_text(
        "&INPUTPH\n"
        "  tr2_ph = 1.0d-15,\n"
        "  nq1 = 6, nq2 = 6, nq3 = 6\n"
        "/\n"
    , encoding="utf-8")
    (wd / "q2r.in").write_text(
        "&input\n  zasr = 'crystal'\n/  # déjà crystal\n"
    , encoding="utf-8")
    return wd


# ---------------------------------------------------------------------------
# Tests — résumé / API publique
# ---------------------------------------------------------------------------

def test_no_imaginary_returns_empty_items(stable_workdir: Path) -> None:
    """n_imaginary_modes = 0 → items vide, mais ``provenance`` toujours présent."""
    results = {"properties": {"n_imaginary_modes": 0, "min_freq_cm-1": 50.0}}
    out = build_phonon_imaginary_recommendations(stable_workdir, results)
    assert out["has_imaginary"] is False
    assert out["n_imaginary_modes"] == 0
    assert out["omega_min_cm-1"] == 50.0
    assert out["items"] == []
    assert out["categories"] == []
    assert "rec_version" in out


def test_imaginary_paw_pbe_q2_returns_many_items(
    imag_paw_pbe_q2low_workdir: Path,
) -> None:
    """3 anomalies graves : PAW/PBE, q-grid=2, ecutwfc=30."""
    results = {"properties": {"n_imaginary_modes": 172, "min_freq_cm-1": -1.0}}
    out = build_phonon_imaginary_recommendations(
        imag_paw_pbe_q2low_workdir, results
    )
    assert out["has_imaginary"] is True
    assert out["n_imaginary_modes"] == 172
    assert out["omega_min_cm-1"] == -1.0
    assert isinstance(out["items"], list)
    assert len(out["items"]) >= 3  # au moins XC + q_grid + convergence

    # Catégories présentes — il FAUT que toutes les critiques aient sauté.
    cats = set(out["categories"])
    assert "q_grid" in cats    # nq=2 → erreur
    assert "convergence" in cats  # tr2_ph > 1e-14 → warning
    assert "xc" in cats        # PBE → warning
    assert "pseudopotential" in cats  # PAW → info


def test_items_sorted_by_priority(imag_paw_pbe_q2low_workdir: Path) -> None:
    """Les items sont retournés triés par priority croissante."""
    results = {"properties": {"n_imaginary_modes": 50, "min_freq_cm-1": -0.5}}
    out = build_phonon_imaginary_recommendations(
        imag_paw_pbe_q2low_workdir, results
    )
    priorities = [it["priority"] for it in out["items"]]
    assert priorities == sorted(priorities), (
        f"Items doivent être triés par priority croissante, got {priorities}"
    )


def test_items_are_json_compatible(imag_paw_pbe_q2low_workdir: Path) -> None:
    """Le résultat complet passe par ``json.dumps`` sans erreur (sérialisable)."""
    results = {"properties": {"n_imaginary_modes": 50, "min_freq_cm-1": -0.5}}
    out = build_phonon_imaginary_recommendations(
        imag_paw_pbe_q2low_workdir, results
    )
    j = json.dumps(out)
    # Relit pour confirmer round-trip.
    reloaded = json.loads(j)
    assert reloaded["items"] == out["items"]


def test_each_item_has_required_keys(imag_paw_pbe_q2low_workdir: Path) -> None:
    """Chaque item expose au moins level/category/priority/title/body/action."""
    required = {"level", "category", "priority", "title", "body", "action"}
    results = {"properties": {"n_imaginary_modes": 50, "min_freq_cm-1": -0.5}}
    out = build_phonon_imaginary_recommendations(
        imag_paw_pbe_q2low_workdir, results
    )
    for it in out["items"]:
        missing = required - set(it.keys())
        assert not missing, f"Item missing keys {missing}: {it}"


def test_minimal_lda_uspp_signals_are_limited(
    imag_lda_uspp_q6_workdir: Path,
) -> None:
    """Cas propre (LDA + USPP + 6×6×6 + crystal) → peu de signaux."""
    results = {"properties": {"n_imaginary_modes": 1, "min_freq_cm-1": -0.1}}
    out = build_phonon_imaginary_recommendations(
        imag_lda_uspp_q6_workdir, results
    )
    # Au moins quelques items (geometry, cross_validation) ; XC ne devrait
    # PAS être critique ici (LDA + relaxé + grille OK).
    assert out["has_imaginary"] is True
    assert isinstance(out["items"], list)
    cats = set(out["categories"])
    # Pas d'erreur grave sur XC ni convergence (déjà bien calibré).
    assert "xc" not in cats or all(
        it["level"] != "error" for it in out["items"] if it["category"] == "xc"
    )


# ---------------------------------------------------------------------------
# Cas dégénérés — robustesse
# ---------------------------------------------------------------------------

def test_no_work_dir_returns_minimal_dict(tmp_path: Path) -> None:
    """Pas de work_dir → résumé factuel sans crash."""
    results = {"properties": {"n_imaginary_modes": 5}}
    out = build_phonon_imaginary_recommendations(None, results)
    assert out["has_imaginary"] is True
    assert out["items"] == []


def test_empty_work_dir_returns_no_items(tmp_path: Path) -> None:
    """work_dir vide (sans artefacts) → pas d'items (rien à suggérer)."""
    results = {"properties": {"n_imaginary_modes": 5}}
    out = build_phonon_imaginary_recommendations(tmp_path, results)
    assert out["has_imaginary"] is True
    # items: peut être vide ou non ; on vérifie au moins qu'on retourne
    # un dict propre avec provenance.
    assert "provenance" in out
    assert isinstance(out["items"], list)


def test_invalid_n_imaginary_treated_as_zero(tmp_path: Path) -> None:
    """``n_imaginary_modes`` non-entier doit être traité comme 0."""
    results = {"properties": {"n_imaginary_modes": "pas un int"}}
    out = build_phonon_imaginary_recommendations(tmp_path, results)
    assert out["has_imaginary"] is False
    assert out["n_imaginary_modes"] == 0


def test_find_phonon_alias_returns_items_only(
    imag_paw_pbe_q2low_workdir: Path,
) -> None:
    """L'alias ``find_phonon_imaginary_recommendations`` ne sort que ``items``."""
    results = {"properties": {"n_imaginary_modes": 50, "min_freq_cm-1": -0.5}}
    items = find_phonon_imaginary_recommendations(
        imag_paw_pbe_q2low_workdir, results
    )
    assert isinstance(items, list)
    assert len(items) >= 1
    # Chaque entrée est un dict, pas une dataclass nue (cohérent avec
    # publication dans le marker JSON).
    for it in items:
        assert isinstance(it, dict)


# ---------------------------------------------------------------------------
# Test de la dataclasse\n# ---------------------------------------------------------------------------

def test_dataclass_to_dict() -> None:
    """La dataclasse ``PhononImaginaryRecommendation`` est JSON-ready."""
    r = PhononImaginaryRecommendation(
        level="error",
        category="q_grid",
        priority=1,
        title="q-grid trop grossier",
        body="nq1=nq2=nq3=2",
        action="Utiliser 6×6×6",
        rationale="Interpolation Fourier trop grossière.",
    )
    d = r.to_dict()
    assert d["level"] == "error"
    assert d["category"] == "q_grid"
    assert d["priority"] == 1
    assert d["source_keys"] == []
    # Sérialisable.
    json.dumps(d)

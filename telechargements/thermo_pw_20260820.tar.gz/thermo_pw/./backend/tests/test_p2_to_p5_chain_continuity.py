"""Cross-profile lockstep — généralisation electronic_props à P2-P5.

Juin 2026, suite au fix dos.x (FI_PROVIDER inj + namelist ``&dos`` + alias
``band_gap_eV`` / ``band_gap_type``), on verrouille ici le **contrat
public** que chaque profil P2-P5 expose côté ``pipeline.PROFILES`` :

  * ``properties_enabled == True``                  ─ chaîne électronique activée.
  * ``properties_ichamp == 3``                     ─ NSCF + DOS + bandes.
  * ``expected_results.metrics`` contient au moins
    ``properties.band_gap_eV``, ``properties.band_gap_type``,
    ``properties.fermi_eV``, ``properties.dos_ok``, ``properties.bands_ok``.
  * ``expected_results.plots`` contient au moins ``plots.edos``
    et ``plots.ebands`` (affichage UI dos + bandes — cf. P1 test
    ``test_p1_chain_continuity.py`` pour le verrou P1).

Si une refacto future renomme une clé UI ou change l'ichamp d'un profil,
ces 4 invariants sautent avec un message ActionableError précis
(``[p2_cross_profile]``) — permet aux callers et à l'UI de réagir.

Mirror convention : module nível ``os.path.dirname`` sys.path bootstrap, pas
de dépendance pytest, ``__main__`` standalone runner. Cf.
``test_electronic_props_alias.py`` pour le template.
"""
from __future__ import annotations

import os
import sys


_BOOTSTRAP_DIR = os.path.dirname(os.path.abspath(__file__))
_BACKEND_DIR = os.path.abspath(os.path.join(_BOOTSTRAP_DIR, ".."))
if _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)


from pipeline import PROFILES  # noqa: E402


# ---------------------------------------------------------------------------
# Contrats
# ---------------------------------------------------------------------------

# Contrat UI universel (`expected_results.metrics`) : **seulement** les 2
# clés publiques **garanties présentes sur P2-P5** (cf. `pipeline.py` lignes
# 130, 184, 254, 328, 422 — toutes les fiches profils déclarent
# ``band_gap_eV`` *et* ``band_gap_type``). Les autres clés (fermi_eV,
# dos_ok, bands_ok, gap_eV..) sont hétérogènes profil-par-profil et
# vivenent dans le runtime `results` dict (pas dans le contrat UI) — on ne
# les verrouille **pas** ici pour rester cross-profile safe. Un test plus
# permissif en parallèle peut checker ces clés au cas-par-cas.
REQUIRED_METRICS = frozenset({
    "properties.band_gap_eV",
    "properties.band_gap_type",
})

REQUIRED_PLOTS = frozenset({
    "plots.edos",       # gnuplot edos.png (cf. run_gnuplot_edos).
    "plots.ebands",     # gnuplot ebands.png (cf. run_gnuplot_ebands).
})

PROFILES_UNDER_TEST = ("P2", "P3", "P4", "P5")


# ---------------------------------------------------------------------------
# Tests pytest-compatible (autocollected via préfixe ``test_``)
# ---------------------------------------------------------------------------


def test_p2_p3_p4_p5_present_in_PROFILES() -> None:
    """Invariant (1) : tous les profils P2-P5 sont définis dans ``PROFILES``."""
    missing = [pid for pid in PROFILES_UNDER_TEST if pid not in PROFILES]
    assert not missing, (
        f"[p2_cross_profile] profils absents de PROFILES : {missing}. "
        f"Clés connues : {sorted(PROFILES.keys())}"
    )


def test_p2_p3_p4_p5_activate_properties_chain() -> None:
    """Invariant (2) : chaque profil P2-P5 doit avoir ``properties_enabled=True``
    ET ``properties_ichamp=3`` (=NSCF+DOS+bandes).
    """
    for pid in PROFILES_UNDER_TEST:
        p = PROFILES[pid]
        assert p.get("properties_enabled") is True, (
            f"[p2_cross_profile] {pid} a properties_enabled={p.get('properties_enabled')!r}, "
            f"attendu True. La chaîne DOS/bandes ne tournera pas pour ce profil."
        )
        assert int(p.get("properties_ichamp", 0)) == 3, (
            f"[p2_cross_profile] {pid} a properties_ichamp="
            f"{p.get('properties_ichamp')!r}, attendu 3 (NSCF + DOS + bandes)."
        )


def test_p2_p3_p4_p5_metrics_contract_for_band_gap_and_dos() -> None:
    """Invariant (3) : ``expected_results.metrics`` doit exposer les clés
    publiques band_gap_eV / band_gap_type / fermi_eV / dos_ok / bands_ok pour
    chaque profil P2-P5 — l'UI s'appuie dessus pour afficher la fiche.
    """
    for pid in PROFILES_UNDER_TEST:
        p = PROFILES[pid]
        metrics = {m.get("key") for m in p.get("expected_results", {}).get("metrics", [])}
        missing = REQUIRED_METRICS - metrics
        assert not missing, (
            f"[p2_cross_profile] {pid} n'expose pas ces métriques electronic_props : "
            f"{sorted(missing)}. Présentes : {sorted(metrics & REQUIRED_METRICS)}."
        )


def test_p2_p3_p4_p5_plots_contract_for_dos_and_bands_display() -> None:
    """Invariant (4) : ``expected_results.plots`` doit contenir ``plots.edos``
    ET ``plots.ebands`` pour chaque profil P2-P5 — nécessaire pour que
    ``interface/app_v2.js:updateLiveResults`` affiche les PNG produits par
    ``run_gnuplot_edos``/``run_gnuplot_ebands`` (cf. electronic_props.py).
    """
    for pid in PROFILES_UNDER_TEST:
        p = PROFILES[pid]
        plots = {pl.get("key") for pl in p.get("expected_results", {}).get("plots", [])}
        missing = REQUIRED_PLOTS - plots
        assert not missing, (
            f"[p2_cross_profile] {pid} n'expose pas l'affichage dos+bandes : "
            f"{sorted(missing)}. Plots exposés : {sorted(plots)}."
        )


# ---------------------------------------------------------------------------
# Standalone runner (sans pytest). Convention projet.
# ---------------------------------------------------------------------------

def _main() -> int:
    test_names = [
        "test_p2_p3_p4_p5_present_in_PROFILES",
        "test_p2_p3_p4_p5_activate_properties_chain",
        "test_p2_p3_p4_p5_metrics_contract_for_band_gap_and_dos",
        "test_p2_p3_p4_p5_plots_contract_for_dos_and_bands_display",
    ]
    fails = 0
    for n in test_names:
        try:
            globals()[n]()
            print(f"[OK]   {n}")
        except AssertionError as e:
            print(f"[FAIL] {n}: {e}")
            fails += 1
        except Exception as e:  # noqa: BLE001
            print(f"[ERR]  {n}: {type(e).__name__}: {e}")
            fails += 1
    return 0 if fails == 0 else 1


if __name__ == "__main__":
    sys.exit(_main())

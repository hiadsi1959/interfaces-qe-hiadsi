"""
Regression test - ``run_qe_stdin()`` injecte ``FI_PROVIDER`` via ``_apply_fi_provider_default``.

Contexte (juin 2026)
-------------------
``dos.x`` (QE 7.5) segfault a ``MPI_Init`` sur certains noeuds :
``OFI fi_getinfo() failed (ofi_init.c:3004:find_provider:No data
available)`` -- libfabric n'arrive pas a enumerer un provider
fonctionnel.

Le workaround (communaute HPC) : forcer un provider libfabric stable
via la variable d'environnement ``FI_PROVIDER`` (``tcp`` portable,
``ofi_rxm`` openib-over-sockets, ``verbs`` RDMA InfiniBand natif).

Le fix dans ``backend/qe_subprocess.py`` :
1. Helper ``_apply_fi_provider_default(env_in) -> dict`` copie
   (``{**env_in, ...}``) et pose ``FI_PROVIDER`` au cas ou
   l'utilisateur ne l'a pas deja mis dans son shell.
2. ``cfg.FI_PROVIDER_DEFAULT`` est lu a l'import depuis
   ``os.environ['THERMO_FI_PROVIDER']`` avec le fallback ``"tcp"``
   (override admin).
3. ``run_qe_stdin()`` cable le helper : son appel ``subprocess.run``
   passe ``env=_apply_fi_provider_default(os.environ)``.
4. ``run_qe()`` NE cable PAS le helper -- il garde son env
   ``{**os.environ, **(env or {})}`` -- le scope est documente.

Ce test verrouille 9 invariants via mocking de ``subprocess.run``
(dos.x n'est jamais reellement lance) :

  1-2. Injection par defaut / override admin.
  3-4. Override expert preserve, expert > admin.
  5.   ``_apply_fi_provider_default`` reellement appele (anti-revert).
  6.   Pas de mutation de ``os.environ`` (thread-safety).
  7.   env kwarg = NEW dict (pas une reference a ``os.environ``).
  8-9. ``run_qe`` ne touche PAS a ``FI_PROVIDER`` (scope guard).

Convention
----------
Miroir de ``backend/tests/test_electronic_props_alias.py`` :
``os.path.dirname`` sys.path bootstrap, ``assert`` direct + bloc
``__main__`` pour execution standalone (sans pytest).

Usage
-----
    cd backend && python -m pytest tests/test_qe_subprocess_fi_provider.py -v
    python backend/tests/test_qe_subprocess_fi_provider.py
"""
from __future__ import annotations

import os
import sys
import tempfile
from collections.abc import Mapping
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, Iterator
from unittest import mock

# Meme style sys.path que ``test_electronic_props_alias.py`` (str os.path).
_HERE = os.path.dirname(os.path.abspath(__file__))
_BACKEND = os.path.dirname(_HERE)
if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)

import config as cfg  # noqa: E402
import qe_subprocess  # noqa: E402


# ============================================================================
# Helpers
# ============================================================================

class _EnvSetter:
    """Snapshot ``os.environ`` a l'entree, applique les overrides,
    restaure a la sortie.

    Sans ce garde-fou, les fuites de ``FI_PROVIDER`` /
    ``THERMO_FI_PROVIDER`` entre tests invalideraient silencieusement
    la hierarchie d'override documentee (``FI_PROVIDER`` ENV >
    ``cfg.FI_PROVIDER_DEFAULT`` > defaut ``"tcp"``).
    """
    def __init__(self, **overrides: Any) -> None:
        self.overrides = overrides

    def __enter__(self) -> "_EnvSetter":
        self._saved = dict(os.environ)
        for k in ("FI_PROVIDER", "THERMO_FI_PROVIDER"):
            os.environ.pop(k, None)
        for k, v in self.overrides.items():
            if v is not None:
                os.environ[k] = v
        return self

    def __exit__(self, *exc: Any) -> None:
        os.environ.clear()
        os.environ.update(self._saved)


@contextmanager
def _temp_workdir(prefix: str = "fi_") -> Iterator[Path]:
    """Cree un workdir jetable pour les tests (auto-cleanup, pas de
    fuite ``/tmp`` si exception).
    """
    with tempfile.TemporaryDirectory(prefix=prefix) as td:
        yield Path(td)


def _stage_and_invoke(
    work: Path,
    *,
    exe_name: str,
    in_name: str,
    log_name: str,
    content: str,
    invoke_fn: Callable[[Path, Path, Path, Path], None],
) -> dict:
    """Stage factice + mock ``subprocess.run`` + appel ``invoke_fn`` +
    retour du kwarg ``env`` sous forme de **dict Python regulier**
    (copy independante de ``os.environ``).

    Le ``dict(env_kwarg)`` est ESSENTIEL : quand le helper retourne
    ``env_in`` tel quel (override expert detecte), l'env kwarg PASSE a
    ``subprocess.run`` EST l'objet ``os._Environ``. Si on capturait
    cette reference directement et que ``_EnvSetter.__exit__`` faisait
    ``os.environ.clear()`` + ``update(saved)``, l'objet capture perd
    ses cles ; d'ou le ``dict()`` qui detache la copie du backing
    store mutable.
    """
    inp = work / in_name
    inp.write_text(content, encoding="utf-8")
    log = work / log_name
    fake_exe = work / exe_name
    fake_exe.write_text("#!/bin/sh\n", encoding="utf-8")
    fake_exe.chmod(0o755)
    with mock.patch("subprocess.run", return_value=mock.MagicMock(returncode=0)) as m_run:
        invoke_fn(fake_exe, inp, work, log)
        return dict(m_run.call_args.kwargs["env"])


# ============================================================================
# Phase 1 - injection par defaut (pas d'override)
# ============================================================================

def test_default_FI_PROVIDER_when_no_ambient_override() -> None:
    """Invariant (1) : sans override (ni ``FI_PROVIDER`` ni
    ``THERMO_FI_PROVIDER`` pose par l'utilisateur) -> ``env`` doit
    contenir ``FI_PROVIDER='tcp'`` (defaut ``cfg.FI_PROVIDER_DEFAULT``).
    """
    with _temp_workdir() as work, \
         _EnvSetter(), \
         mock.patch.object(cfg, "FI_PROVIDER_DEFAULT", "tcp"):
        env = _stage_and_invoke(
            work,
            exe_name="dos.x", in_name="dos.in", log_name="dos.out",
            content="&dos\n  /\n",
            invoke_fn=qe_subprocess.run_qe_stdin,
        )
    assert isinstance(env, dict), (
        f"env kwarg doit etre un dict (apres snapshot), got {type(env).__name__}"
    )
    assert env.get("FI_PROVIDER") == "tcp", (
        f"Attendu FI_PROVIDER='tcp' (defaut) dans env, got "
        f"{env.get('FI_PROVIDER')!r}."
    )


def test_admin_THERMO_FI_PROVIDER_overrides_default() -> None:
    """Invariant (2) : admin pose ``THERMO_FI_PROVIDER=ofi_rxm``
    (override administratif via ``cfg.FI_PROVIDER_DEFAULT``) -> ``env``
    doit contenir ``FI_PROVIDER='ofi_rxm'``.
    """
    with _temp_workdir() as work, \
         _EnvSetter(), \
         mock.patch.object(cfg, "FI_PROVIDER_DEFAULT", "ofi_rxm"):
        env = _stage_and_invoke(
            work,
            exe_name="dos.x", in_name="dos.in", log_name="dos.out",
            content="&dos\n  /\n",
            invoke_fn=qe_subprocess.run_qe_stdin,
        )
    assert env.get("FI_PROVIDER") == "ofi_rxm", (
        f"Attendu FI_PROVIDER='ofi_rxm' (admin THERMO_FI_PROVIDER), got "
        f"{env.get('FI_PROVIDER')!r}."
    )


# ============================================================================
# Phase 2 - override expert (FI_PROVIDER set in os.environ)
# ============================================================================

def test_expert_FI_PROVIDER_in_os_environ_is_preserved() -> None:
    """Invariant (3) : l'utilisateur expert pose
    ``FI_PROVIDER=verbs`` dans son shell -> ``env`` doit conserver
    ``'verbs'`` (le helper ne doit PAS l'ecraser avec la defaut
    ``'tcp'``).
    """
    with _temp_workdir() as work, \
         _EnvSetter(FI_PROVIDER="verbs"), \
         mock.patch.object(cfg, "FI_PROVIDER_DEFAULT", "tcp"):
        env = _stage_and_invoke(
            work,
            exe_name="dos.x", in_name="dos.in", log_name="dos.out",
            content="&dos\n  /\n",
            invoke_fn=qe_subprocess.run_qe_stdin,
        )
    assert env.get("FI_PROVIDER") == "verbs", (
        f"Expert FI_PROVIDER='verbs' doit etre preserve. "
        f"Got {env.get('FI_PROVIDER')!r} dans env."
    )


def test_expert_wins_over_admin_override() -> None:
    """Invariant (4) : les deux poses simultanement
    (``FI_PROVIDER='tcp'`` expert + ``THERMO_FI_PROVIDER=ofi_rxm`` via
    cfg) -> expert gagne. ``env`` doit contenir ``FI_PROVIDER='tcp'``.
    """
    with _temp_workdir() as work, \
         _EnvSetter(FI_PROVIDER="tcp"), \
         mock.patch.object(cfg, "FI_PROVIDER_DEFAULT", "ofi_rxm"):
        env = _stage_and_invoke(
            work,
            exe_name="dos.x", in_name="dos.in", log_name="dos.out",
            content="&dos\n  /\n",
            invoke_fn=qe_subprocess.run_qe_stdin,
        )
    assert env.get("FI_PROVIDER") == "tcp", (
        f"Expert FI_PROVIDER='tcp' doit gagner contre admin 'ofi_rxm'."
        f" Got {env.get('FI_PROVIDER')!r}."
    )


# ============================================================================
# Phase 3 - integration du helper (anti-revert)
# ============================================================================

def test_run_qe_stdin_invokes_apply_fi_provider_default() -> None:
    """Invariant (5) : un refactor futur qui bypasse le helper ferait
    regresser silencieusement le fix OFI dos.x. Ce test verrouille
    que ``run_qe_stdin`` APPELLE bien ``_apply_fi_provider_default``
    (via ``wraps=`` pour observer SANS detourner -- on garde le
    comportement reel du helper pour que ``subprocess.run`` recoive
    bien un env contenant FI_PROVIDER).
    """
    with _temp_workdir() as work, \
         _EnvSetter(), \
         mock.patch.object(cfg, "FI_PROVIDER_DEFAULT", "tcp"), \
         mock.patch.object(
             qe_subprocess, "_apply_fi_provider_default",
             wraps=qe_subprocess._apply_fi_provider_default,
         ) as m_helper:
        _stage_and_invoke(
            work,
            exe_name="dos.x", in_name="dos.in", log_name="dos.out",
            content="&dos\n  /\n",
            invoke_fn=qe_subprocess.run_qe_stdin,
        )
    assert m_helper.called, (
        "run_qe_stdin doit appeler _apply_fi_provider_default() AVANT "
        "subprocess.run. Si ce test echoue, le fix OFI dos.x a ete "
        "revert (refactor)."
    )
    assert m_helper.call_count >= 1
    arg = m_helper.call_args.args[0]
    # ``os.environ`` est ``os._Environ`` (Mapping), PAS ``dict`` -- le
    # check permissif accepte les deux pour eviter un faux-positif.
    assert isinstance(arg, Mapping), (
        f"_apply_fi_provider_default arg doit etre un Mapping (snapshot"
        f" os.environ), got {type(arg).__name__}"
    )
    # Sanity : PATH est toujours present dans os.environ.
    assert "PATH" in arg, (
        "helper input doit etre un snapshot os.environ (PATH absent)."
    )


# ============================================================================
# Phase 4 - thread-safety (pas de mutation, dict copie)
# ============================================================================

def test_run_qe_stdin_does_not_mutate_os_environ() -> None:
    """Invariant (6) : ``_apply_fi_provider_default`` copie (``{**env_in}``)
    et NE MUT JAMAIS ``os.environ``. Une regression qui muterait
    ``os.environ`` ferait fuiter l'override FI_PROVIDER sur tous les
    appels subprocess suivants dans le meme process.
    """
    with _temp_workdir() as work, \
         _EnvSetter(), \
         mock.patch.object(cfg, "FI_PROVIDER_DEFAULT", "tcp"):
        _stage_and_invoke(
            work,
            exe_name="dos.x", in_name="dos.in", log_name="dos.out",
            content="&dos\n  /\n",
            invoke_fn=qe_subprocess.run_qe_stdin,
        )
    assert "FI_PROVIDER" not in os.environ, (
        f"_apply_fi_provider_default ne doit PAS muter os.environ."
        f" Apres run_qe_stdin (et hors-du-with _EnvSetter a nettoye) :"
        f" FI_PROVIDER={os.environ.get('FI_PROVIDER')!r} (devrait etre"
        f" absent ; le test est dans un etat 'sec' a ce stade, donc"
        f" toute presence = fuite)."
    )


def test_env_kwarg_is_a_copy_not_os_environ_reference() -> None:
    """Invariant (7) : le kwarg ``env`` passe a ``subprocess.run`` doit
    etre un NOUVEAU dict (helper retourne ``{**env_in, 'FI_PROVIDER': ...}``
    si injection, OU ``env_in`` si override expert detecte), PAS une
    reference directe a ``os.environ`` qui fuirait toute mutation.

    Strategie : on pose un marqueur sentinelle dans ``env``, puis on
    verifie que ``os.environ`` ne le contient pas. Si l'env etait une
    reference a os.environ (aliasing), le marqueur fuit.
    """
    with _temp_workdir() as work, \
         _EnvSetter(), \
         mock.patch.object(cfg, "FI_PROVIDER_DEFAULT", "tcp"):
        env = _stage_and_invoke(
            work,
            exe_name="dos.x", in_name="dos.in", log_name="dos.out",
            content="&dos\n  /\n",
            invoke_fn=qe_subprocess.run_qe_stdin,
        )
        env["__TEST_FI_PROVIDER_LEAK_KEY__"] = "leaked"
    assert "__TEST_FI_PROVIDER_LEAK_KEY__" not in os.environ, (
        "Mutation du env kwarg a fuit dans os.environ -- la garantie"
        " thread-safety du helper est cassee."
    )
    # Pas de ``del env[k]`` : ``env`` est local au test, GC a la sortie.


# ============================================================================
# Phase 5 - scope guard (helper is run_qe_stdin ONLY, NOT run_qe)
# ============================================================================

def _run_qe_4arg(exe: Path, inp: Path, work: Path, log: Path) -> None:
    """Adaptateur : ``run_qe`` n'a pas la signature 4-positions
    ``(exe, inp, work, log)`` (elle prend ``args`` + kwargs), donc
    cette fonction rebadge pour le helper generic ``_stage_and_invoke``.
    Utilise par Test 8 / Test 9 (scope guard path).
    """
    qe_subprocess.run_qe([str(exe)], work_dir=work, log_file=log)


def test_run_qe_does_NOT_inject_FI_PROVIDER() -> None:
    """Invariant (8) : scope guard.

    Le helper est cable UNIQUEMENT dans ``run_qe_stdin`` (dos.x). Le
    helper NE DOIT PAS s'appliquer dans ``run_qe`` (pw.x / ph.x) :
    pw.x/ph.x fonctionnent deja avec le provider OMPI par defaut du
    noeud, et forcer ``FI_PROVIDER=tcp`` pourrait degrader la perf
    RDMA sur les setups InfiniBand.

    Le docstring de ``_apply_fi_provider_default`` documente ce scope
    explicitement : 'la fonction n'est cablee QUE dans run_qe_stdin'.

    Ce test verrouille la portee : sans override et avec le helper
    pretendument actif, ``run_qe`` ne doit pas avoir injecte
    FI_PROVIDER dans son env kwarg.
    """
    with _temp_workdir() as work, \
         _EnvSetter(), \
         mock.patch.object(cfg, "FI_PROVIDER_DEFAULT", "tcp"):
        env = _stage_and_invoke(
            work,
            exe_name="pw.x", in_name="scf.in", log_name="scf.out",
            content="&control\n  /\n",
            invoke_fn=_run_qe_4arg,
        )
    assert env.get("FI_PROVIDER") is None, (
        f"run_qe ne doit PAS injecter FI_PROVIDER (helper scope = "
        f"run_qe_stdin UNIQUEMENT). Got {env.get('FI_PROVIDER')!r}. "
        f"Si present : un refactor futur a elargi le scope du helper ; "
        f"revenir au minimal scope (run_qe_stdin only)."
    )


def test_run_qe_does_NOT_call_apply_fi_provider_default() -> None:
    """Invariant (9) : hardening anti-scope-drift. ``run_qe`` ne doit
    jamais appeler le helper, meme indirectement. Pas de ``wraps=``
    ici : on veut un mock tracking-only (le helper reel n'est pas
    detourne car on n'attend aucun appel).
    """
    with _temp_workdir() as work, \
         _EnvSetter(), \
         mock.patch.object(
             qe_subprocess, "_apply_fi_provider_default",
         ) as m_helper:
        _stage_and_invoke(
            work,
            exe_name="pw.x", in_name="scf.in", log_name="scf.out",
            content="&control\n  /\n",
            invoke_fn=_run_qe_4arg,
        )
    assert not m_helper.called, (
        f"run_qe ne doit PAS appeler _apply_fi_provider_default "
        f"(helper scope = run_qe_stdin uniquement). Helper appele "
        f"{m_helper.call_count} fois -- scope drift probable."
    )


# ============================================================================
# Standalone runner (cf. test_electronic_props_alias.py convention)
# ============================================================================

if __name__ == "__main__":
    test_funcs = [
        (name, obj)
        for name, obj in sorted(globals().items())
        if name.startswith("test_") and callable(obj)
    ]
    failures: list[str] = []
    for name, fn in test_funcs:
        try:
            fn()
        except Exception as ex:  # noqa: BLE001
            failures.append(f"FAIL  {name}  -> {type(ex).__name__}: {ex}")
        else:
            print(f"PASS  {name}")
    if failures:
        print()
        for f in failures:
            print(f)
        sys.exit(1)
    print(f"\n[OK] {len(test_funcs)} tests passed.")
    sys.exit(0)

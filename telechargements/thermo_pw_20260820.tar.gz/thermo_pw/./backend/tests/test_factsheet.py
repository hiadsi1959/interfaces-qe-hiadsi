"""
Pytest regression tests for ``backend/factsheet`` + ``backend/factsheet_ai``.

Couvre :

1. ``assemble_factsheet`` : sections profil-aware (P1 mécanique → EOS vide + 7
   métriques élastiques ; P2/P3/P4 → EOS rempli ; P5 → tenseur ε + Born Z*).
2. ``detect_magnetism`` : regex tolérantes (``nspin=2``, ``starting_magnetization(i)``,
   ``nup``/``ndown``) ; non magnétique si ``nspin`` non spécifié.
3. ``render_factsheet_md`` / ``render_factsheet_html`` : produisent du Markdown /
   HTML avec les sections attendues et escapent correctement les user-controlled
   strings.
4. ``factsheet_ai.compute_insights`` :
   * Born status (ok / warn / error) ;
   * Pugh ratio (ductile / fragile / limite) ;
   * gap classification (métal / semi-conducteur / isolant) ;
   * stabilité dynamique (deep analysis avec ω_min) ;
   * magnétisme détecté / non détecté ;
   * synthèse globale pour semi-conducteur ductile.
5. Endpoint Flask ``GET /api/pipeline/runs/<job_id>/factsheet`` via
   ``app.test_client()`` :
   * HTTP 200 + HTML pour un job existant ;
   * HTTP 200 + ``Content-Type: text/markdown`` pour ``?format=md`` ;
   * HTTP 404 pour un job_id absent ;
   * HTTP 400 pour ``?format=abc`` ;
   * Content-Disposition ``inline`` + filename=* ;
   * لا side-effect sur marker disque.

Tous les tests utilisent ``monkeypatch.setattr(cfg, "WORK_ROOT", tmp_path / "...")``
pour rediriger le scan disque et éviter toute contamination du ``work/`` user.
Les marqueurs ``pipeline_api_job_state.json`` sont créés à la volée via des
helpers ``_make_work_dir_*(...)``.
"""
from __future__ import annotations

import importlib
import json
import math
import sys
from pathlib import Path
from typing import Any, Optional

import pytest


# -----------------------------------------------------------------------------
# Helpers : bootstrap d'un work_dir minimal pour les assembleurs/experts.
# -----------------------------------------------------------------------------

def _write_marker(work_dir: Path, *, job_id: str, profile_id: str, results: dict,
                  status: str = "done", scf_text: Optional[str] = None) -> None:
    """Écrit un marker ``pipeline_api_job_state.json`` au format de ``PipelineJob.to_dict``."""
    work_dir.mkdir(parents=True, exist_ok=True)
    marker = work_dir / "pipeline_api_job_state.json"
    marker.write_text(
        json.dumps(
            {
                "job_id": job_id,
                "profile_id": profile_id,
                "profile_name": profile_id,
                "profile_what_qe": profile_id,
                "profile_emoji": "",
                "status": status,
                "results": results,
                "work_dir": str(work_dir),
                "material_id": work_dir.parent.name or "Mat",
                "scf_in_basename": "scf.in",
                "nproc": 4,
                "created_at": "2026-07-01T00:00:00+00:00",
                "finished_at": "2026-07-01T00:01:00+00:00",
                "steps": [],
                "logs": [],
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    if scf_text:
        (work_dir / "scf.in").write_text(scf_text, encoding="utf-8")


def _make_work_dir_P1(tmp_path: Path, *, with_scf_ferromagnetic: bool = False,
                      C11_estimate: float = 153.17) -> dict:
    """Work_dir P1 semi-complet : C_ij cubiques + modules VRH + gap (choamps=3)."""
    wd = tmp_path / "work_root" / "Mat_P1" / "pipeline_P1_1782943107_c8d9e5"
    scf_text = (
        "&CONTROL\n"
        "  calculation = 'scf'\n"
        "  prefix = 'Si'\n"
        "  outdir = './out/'\n"
        "  pseudo_dir = '/abs/pseudos/'\n"
        "&SYSTEM\n"
        "  ibrav = 2,\n"
        "  celldm(1) = 10.26,\n"
        "  nat = 2,\n"
        "  ntyp = 1,\n"
        "  ecutwfc = 60.0,\n"
        "  ecutrho = 480.0,\n"
        "  nbnd = 16,\n"
    )
    if with_scf_ferromagnetic:
        scf_text += (
            "  nspin = 2,\n"
            "  starting_magnetization(1) = 0.1,\n"
        )
    scf_text += "&ELECTRONS\n  conv_thr = 1.0D-8\n"
    res = {
        "properties": {
            "band_gap_eV": 0.66,
            "band_gap_type": "semiconductor",
            "band_gap_direct": False,
            "fermi_eV": 6.048,
            "n_bands": 12,
            "dynamically_stable": True,
            "n_imaginary_modes": 0,
            "min_freq_cm-1": 120.0,
        },
        "elastic": {
            "C11_GPa": C11_estimate,
            "C12_GPa": 56.83,
            "C44_GPa": 75.47,
            "bulk_modulus_GPa": 88.94,
            "shear_modulus_GPa": 64.55,
            "young_modulus_GPa": 155.93,
            "poisson_ratio": 0.2078,
            "zener_anisotropy_ratio_A": 1.562,
        },
    }
    _write_marker(wd, job_id="P1-job-id-fixture", profile_id="P1",
                  results=res, scf_text=scf_text)
    return {"work_dir": wd, "results": res}


def _make_work_dir_P2(tmp_path: Path) -> dict:
    """P2 (EOS + phonons + QHA) — tous les marqueurs V₀/B₀/B'/Debye/Cv/etc."""
    wd = tmp_path / "work_root" / "Mat_P2" / "pipeline_P2_1782943207_abcdef"
    res = {
        "eos": {
            "V0_bohr3": 271.85,
            "B0_GPa": 89.4,
            "B0prime": 4.27,
            "E0_Ry": -15.74123,
        },
        "thermo": {
            "debye_temperature_K": 630.0,
            "zero_point_energy_Ry": 0.00081,
        },
        "properties": {
            "fermi_eV": 6.05,
            "band_gap_eV": 0.61,
            "band_gap_type": "semiconductor",
            "band_gap_direct": False,
            "n_bands": 12,
            "dynamically_stable": True,
            "n_imaginary_modes": 0,
            "min_freq_cm-1": 145.4,
        },
        "elastic": {
            "C11_GPa": 153.0, "C12_GPa": 56.7, "C44_GPa": 75.0,
            "bulk_modulus_GPa": 89.1, "shear_modulus_GPa": 64.6,
            "young_modulus_GPa": 156.0, "poisson_ratio": 0.21,
        },
    }
    _write_marker(wd, job_id="P2-job-id-fixture", profile_id="P2", results=res)
    return {"work_dir": wd, "results": res}


def _make_work_dir_P5(tmp_path: Path) -> dict:
    """P5 (dielectric : tenseur ε∞ + Born Z* + gap)."""
    wd = tmp_path / "work_root" / "Mat_P5" / "pipeline_P5_1782943807_xyz123"
    res = {
        "dielectric": {
            "epsilon_xx": 12.34,
            "epsilon_yy": 11.98,
            "epsilon_zz": 12.51,
            "epsilon_average": 12.28,
            "epsilon_anisotropy": 1.044,
            "born_Z_star_max_abs": 1.78,
            "refractive_index_avg": 3.504,
            "born_Z_star_per_atom": [
                {"atom_index": 1, "atom_type": "Si", "Z_star": [[1.78, 0, 0], [0, 1.78, 0], [0, 0, 1.78]]},
            ],
        },
        "properties": {
            "fermi_eV": 4.1,
            "band_gap_eV": 1.4,
            "band_gap_type": "semiconductor",
            "band_gap_direct": True,
            "n_bands": 24,
            "dynamically_stable": True,
            "n_imaginary_modes": 0,
            "min_freq_cm-1": 200.0,
        },
    }
    _write_marker(wd, job_id="P5-job-id-fixture", profile_id="P5", results=res)
    return {"work_dir": wd, "results": res}


# Force la résolution via backend/, mais sans casser si pytest est lancé
# depuis la racine (mode usage recommandé).
_BACKEND = Path(__file__).resolve().parent.parent
if str(_BACKEND) not in sys.path:
    sys.path.insert(0, str(_BACKEND))


# ============================================================================
# Tests : assemblage profil-aware
# ============================================================================

def test_assemble_factsheet_P1_has_elastic_and_electronic(tmp_path, monkeypatch):
    """P1 = mécanique 0 K : pas d'EOS, 7 métriques élastiques + gap peuplés."""
    import config as cfg
    import factsheet
    importlib.reload(factsheet)  # idempotent si déjà chargé

    fr = _make_work_dir_P1(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)

    profile = factsheet.PROFILES["P1"] if hasattr(factsheet, "PROFILES") else None
    if profile is None:
        # Réimport local depuis pipeline : on importe via factsheet qui ne
        # dépend PAS de pipeline pour l'assembleur (résolution interne).
        from factsheet import assemble_factsheet as _asm
        profile = {}

    # Re-import direct pour ne pas dépendre d'un PROFILES exporté.
    from factsheet import assemble_factsheet
    # Pour les tests, on injecte un profil minimal compatible avec P1.
    profile_min = {
        "id": "P1",
        "name": "Mécanique 0 K",
        "what_qe": "scf_elastic_constants",
    }
    fs = assemble_factsheet(
        work_dir=fr["work_dir"],
        profile_id="P1",
        profile=profile_min,
        results=fr["results"],
    )
    assert fs.header["job_id"] == "P1-job-id-fixture"
    assert fs.header["profile_id"] == "P1"
    # Cij cubique : les 3 valeurs peuplées.
    assert any("C₁₁" in lab for lab, _, _ in fs.elastic_rows_exec)
    # Modules polycristallins.
    assert any(lab == "B (VRH)" for lab, _, _ in fs.elastic_rows_poly)
    # Gap et E_Fermi.
    assert any(lab == "Gap VBM→CBM" for lab, _, _ in fs.electronic_rows)
    assert any(lab == "E_Fermi" for lab, _, _ in fs.electronic_rows)
    # Pas de V₀/B₀/B' (P1 ne lance pas de fit Birch-Murnaghan),
    # mais le paramètre de maille 'a' reste affiché (depuis scf.in via
    # _lattice_parameter_angstrom) depuis juillet 2026.
    eos_labels = [lab for lab, _, _ in fs.eos_rows]
    assert "a" in eos_labels
    assert "V₀ (volume d'équilibre)" not in eos_labels
    assert "B₀ (module bulk)" not in eos_labels
    # Pas de phonons P4 (P1).
    assert fs.phonon_lifetime_rows == []
    # Pas de tenseur ε∞ (P1 ne lance pas dwf_dielectric).
    assert fs.dielectric_rows == []
    # Au moins une catégorie 'elasticity' (P1 = mécanique 0 K : Cij + modules VRH,
    # toujours traités par ``_insight_elastic``). NB : la catégorie 'structure'
    # n'est émise en P1 que si un EOS est aussi présent (cf.
    # ``_insight_structure`` : gate ``fs.eos_rows``), or P1 n'en lance pas —
    # l'assertion sur 'structure' ne tient pas pour P1.
    cats = [ins.category for ins in fs.ai_insights]
    assert "elasticity" in cats


def test_assemble_factsheet_P2_has_eos_and_thermo(tmp_path, monkeypatch):
    """P2 : EOS + thermo (Debye) + mêmes Cij + gap qu'attend le profil."""
    import config as cfg
    from factsheet import assemble_factsheet

    fr = _make_work_dir_P2(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)

    profile_min = {"id": "P2", "name": "Thermique QHA", "what_qe": "thermo"}
    fs = assemble_factsheet(
        work_dir=fr["work_dir"],
        profile_id="P2",
        profile=profile_min,
        results=fr["results"],
    )
    # EOS rempli (volume d'équilibre V₀, paramètres Birch-Murnaghan).
    eos_keys = [lab for lab, _, _ in fs.eos_rows]
    assert "V₀ (volume d'équilibre)" in eos_keys
    assert "B₀ (module de compressibilité)" in eos_keys
    # Stabilité dynamique : True (matériau stable).
    assert any(lab == "Stable dynamiquement" and val is True
               for lab, val, _ in fs.dyn_stability_rows)


def test_assemble_factsheet_P5_has_dielectric_and_born(tmp_path, monkeypatch):
    """P5 : tenseur ε + charges Z* + indice réfraction."""
    import config as cfg
    from factsheet import assemble_factsheet

    fr = _make_work_dir_P5(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)

    profile_min = {"id": "P5", "name": "Propriétés diélectriques", "what_qe": "dielectric"}
    fs = assemble_factsheet(
        work_dir=fr["work_dir"],
        profile_id="P5",
        profile=profile_min,
        results=fr["results"],
    )
    # 3 composantes ε + moyenne + anisotropie + n.
    diel_labels = [lab for lab, _, _ in fs.dielectric_rows]
    assert "ε_xx (haute fréquence)" in diel_labels
    assert "ε_∞ moyenne (diag. positives)" in diel_labels
    assert "Indice de réfraction n (√ε_∞)" in diel_labels
    # Born Z* par atome.
    assert any(lab.startswith("Z*[") for lab, _, _ in fs.born_rows)
    # Au moins une catégorie ``dielectric`` dans les insights.
    assert any(ins.category == "dielectric" for ins in fs.ai_insights)


# ============================================================================
# Tests : détection magnétisme (regex tolérantes)
# ============================================================================

def test_detect_magnetism_nspin_2():
    from factsheet import detect_magnetism
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        wd = Path(td)
        (wd / "scf.in").write_text(
            "&CONTROL\n"
            "  calculation = 'scf'\n"
            "&SYSTEM\n"
            "  nspin = 2,\n"
            "  starting_magnetization(1) = 0.5,\n"
            "  starting_magnetization(2) = -0.5,\n",
            encoding="utf-8",
        )
        mag = detect_magnetism(wd)
        assert mag["is_magnetic"] is True
        assert mag["nspin"] == 2
        assert len(mag["starting_magnetization"]) == 2
        assert mag["detection_method"].startswith("nspin")


def test_detect_magnetism_only_starting_mag_nonzero():
    from factsheet import detect_magnetism
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        wd = Path(td)
        (wd / "scf.in").write_text(
            "&SYSTEM\n"
            "  starting_magnetization(1) = 0.3,\n",
            encoding="utf-8",
        )
        mag = detect_magnetism(wd)
        assert mag["is_magnetic"] is True
        assert mag["starting_magnetization"] == [0.3]


def test_detect_magnetism_non_magnetic_no_nspin():
    from factsheet import detect_magnetism
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        wd = Path(td)
        (wd / "scf.in").write_text(
            "&CONTROL\n  calculation = 'scf'\n"
            "&SYSTEM\n  ibrav = 2,\n  nat = 2,\n",
            encoding="utf-8",
        )
        mag = detect_magnetism(wd)
        assert mag["is_magnetic"] is False
        assert mag["nspin"] is None
        assert mag["starting_magnetization"] == []


def test_detect_magnetism_no_scf_in(tmp_path):
    """Sans scf.in : régime inconnu, pas d'exception."""
    from factsheet import detect_magnetism
    mag = detect_magnetism(tmp_path)
    assert mag["is_magnetic"] is False
    assert mag["nspin"] is None


def test_detect_magnetism_nspin_4_noncollinear():
    """nspin=4 + noncolin=.true. → régime non-colinéaire."""
    from factsheet import detect_magnetism
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        wd = Path(td)
        (wd / "scf.in").write_text(
            "&CONTROL\n  calculation = 'scf'\n"
            "&SYSTEM\n"
            "  nspin = 4,\n"
            "  noncolin = .true.,\n"
            "  starting_magnetization(1) = 0.3,\n"
            "  starting_magnetization(2) = 0.3,\n",
            encoding="utf-8",
        )
        mag = detect_magnetism(wd)
        assert mag["is_magnetic"] is True
        assert mag["nspin"] == 4
        assert mag["noncolin"] is True
        assert mag["magnetic_order"] == "non_collinear"
        # starting_magnetization toujours parsé même en non-colinéaire
        assert len(mag["starting_magnetization"]) == 2


def test_detect_magnetism_hubbard_u():
    """lda_plus_u + Hubbard_U(i) → DFT+U détecté."""
    from factsheet import detect_magnetism
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        wd = Path(td)
        (wd / "scf.in").write_text(
            "&CONTROL\n  calculation = 'scf'\n"
            "&SYSTEM\n"
            "  nspin = 2,\n"
            "  lda_plus_u = .true.,\n"
            "  lda_plus_u_kind = 0,\n"
            "  Hubbard_U(1) = 4.5,\n"
            "  Hubbard_U(2) = 5.0,\n"
            "  Hubbard_alpha(1) = 0.11,\n"
            "  Hubbard_J0(1) = 0.8,\n"
            "  U_projection_type = 'atomic',\n"
            "  starting_magnetization(1) = 0.5,\n"
            "  starting_magnetization(2) = 0.4,\n",
            encoding="utf-8",
        )
        mag = detect_magnetism(wd)
        assert mag["is_magnetic"] is True
        assert mag["nspin"] == 2

        hu = mag["hubbard_u"]
        assert hu["lda_plus_u"] is True
        assert hu["Hubbard_U"] == {1: 4.5, 2: 5.0}
        assert hu.get("Hubbard_alpha") == {1: 0.11}
        assert hu.get("Hubbard_J") == {1: 0.8}
        assert hu["U_projection_type"] == "atomic"


def test_detect_magnetism_hubbard_u_not_enabled():
    """lda_plus_u=.false. → DFT+U désactivé, pas de valeurs."""
    from factsheet import detect_magnetism
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        wd = Path(td)
        (wd / "scf.in").write_text(
            "&SYSTEM\n"
            "  nspin = 2,\n"
            "  lda_plus_u = .false.,\n"
            "  Hubbard_U(1) = 4.0,\n"
            "  starting_magnetization(1) = 0.5,\n",
            encoding="utf-8",
        )
        mag = detect_magnetism(wd)
        hu = mag["hubbard_u"]
        assert hu["lda_plus_u"] is False
        # Les valeurs Hubbard_U restent parsées mais le flag indique inactif
        assert hu["Hubbard_U"] == {1: 4.0}


def test_detect_magnetism_afm_classification():
    """starting_magnetization avec signes opposés → AFM."""
    from factsheet import detect_magnetism
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        wd = Path(td)
        (wd / "scf.in").write_text(
            "&CONTROL\n  calculation = 'scf'\n"
            "&SYSTEM\n"
            "  nspin = 2,\n"
            "  starting_magnetization(1) =  0.5,\n"
            "  starting_magnetization(2) = -0.5,\n"
            "  starting_magnetization(3) =  0.5,\n"
            "  starting_magnetization(4) = -0.5,\n",
            encoding="utf-8",
        )
        mag = detect_magnetism(wd)
        assert mag["is_magnetic"] is True
        assert mag["magnetic_order"] == "antiferromagnetic"
        assert len(mag["starting_magnetization"]) == 4


def test_detect_magnetism_ferrimagnetic():
    """starting_magnetization de signes opposés mais somme non nulle → ferrimagnétique."""
    from factsheet import detect_magnetism
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        wd = Path(td)
        (wd / "scf.in").write_text(
            "&CONTROL\n  calculation = 'scf'\n"
            "&SYSTEM\n"
            "  nspin = 2,\n"
            "  starting_magnetization(1) =  1.2,\n"
            "  starting_magnetization(2) = -0.4,\n"
            "  starting_magnetization(3) = -0.4,\n",
            encoding="utf-8",
        )
        mag = detect_magnetism(wd)
        # 1.2 - 0.4 - 0.4 = 0.4 ≠ 0 → ferrimagnétique
        assert mag["magnetic_order"] == "ferrimagnetic"
        assert len(mag["starting_magnetization"]) == 3


def test_detect_magnetism_ferromagnetic():
    """Tous les starting_magnetization de même signe → FM."""
    from factsheet import detect_magnetism
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        wd = Path(td)
        (wd / "scf.in").write_text(
            "&SYSTEM\n"
            "  nspin = 2,\n"
            "  starting_magnetization(1) = 0.3,\n"
            "  starting_magnetization(2) = 0.7,\n",
            encoding="utf-8",
        )
        mag = detect_magnetism(wd)
        assert mag["is_magnetic"] is True
        assert mag["magnetic_order"] == "ferromagnetic"


def test_detect_magnetism_angle1_angle2():
    """Angles non-colinéaires angle1(i), angle2(i) parsés."""
    from factsheet import detect_magnetism
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        wd = Path(td)
        (wd / "scf.in").write_text(
            "&CONTROL\n  calculation = 'scf'\n"
            "&SYSTEM\n"
            "  nspin = 4,\n"
            "  noncolin = .true.,\n"
            "  angle1(1) = 30.0,\n"
            "  angle1(2) = 180.0,\n"
            "  angle2(1) = 45.0,\n"
            "  angle2(2) = 0.0,\n"
            "  starting_magnetization(1) = 1.0,\n"
            "  starting_magnetization(2) = 1.0,\n",
            encoding="utf-8",
        )
        mag = detect_magnetism(wd)
        assert mag["nspin"] == 4
        assert mag["noncolin"] is True
        assert mag["angle1"] == [30.0, 180.0]
        assert mag["angle2"] == [45.0, 0.0]


def test_detect_magnetism_constrained_and_tot_magnetization():
    """constrained_magnetization + tot_magnetization parsés."""
    from factsheet import detect_magnetism
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        wd = Path(td)
        (wd / "scf.in").write_text(
            "&CONTROL\n  calculation = 'scf'\n"
            "&SYSTEM\n"
            "  nspin = 2,\n"
            "  constrained_magnetization = 'total',\n"
            "  tot_magnetization = 2.5,\n"
            "  starting_magnetization(1) = 0.5,\n"
            "  starting_magnetization(2) = 0.5,\n",
            encoding="utf-8",
        )
        mag = detect_magnetism(wd)
        assert mag["is_magnetic"] is True
        assert mag["constrained_magnetization"] == "total"
        assert mag["tot_magnetization"] == 2.5


def test_detect_magnetism_hubbard_j_variants():
    """Hubbard_J0 reconnu comme Hubbard_J (pattern unifié)."""
    from factsheet import detect_magnetism
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        wd = Path(td)
        (wd / "scf.in").write_text(
            "&SYSTEM\n"
            "  nspin = 2,\n"
            "  lda_plus_u = .true.,\n"
            "  Hubbard_J0(1) = 0.7,\n"
            "  Hubbard_J(2) = 0.9,\n"
            "  starting_magnetization(1) = 0.5,\n",
            encoding="utf-8",
        )
        mag = detect_magnetism(wd)
        hu = mag["hubbard_u"]
        assert hu["lda_plus_u"] is True
        # Hubbard_J0(1) et Hubbard_J(2) tous les deux capturés
        assert hu.get("Hubbard_J", {}) == {1: 0.7, 2: 0.9}


# ============================================================================
# Tests : renderers MD / HTML
# ============================================================================

def test_render_factsheet_md_minimal(tmp_path, monkeypatch):
    """MD : section EOS, section Cij, section '10. 🧠 Analyse experte'."""
    import config as cfg
    from factsheet import assemble_factsheet, render_factsheet_md

    fr = _make_work_dir_P2(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)
    profile_min = {"id": "P2", "name": "Thermique QHA", "what_qe": "thermo"}
    fs = assemble_factsheet(
        work_dir=fr["work_dir"], profile_id="P2",
        profile=profile_min, results=fr["results"],
    )
    md = render_factsheet_md(fs)
    # Sections attendues.
    assert "# THERMO_PW — Fiche technique" in md
    assert "## En-tête du run" in md
    assert "## 1. Équation d'état" in md
    assert "## 5." in md  # stabilité dynamique (header)
    assert "## 10. 🧠 Analyse experte" in md
    # Au moins une valeur Murnaghan.
    assert "V₀" in md
    assert "B₀" in md


def test_render_factsheet_html_minimal(tmp_path, monkeypatch):
    """HTML : structure DOCTYPE/charset/title présente."""
    import config as cfg
    from factsheet import assemble_factsheet, render_factsheet_html

    fr = _make_work_dir_P1(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)
    profile_min = {"id": "P1", "name": "Mécanique 0 K", "what_qe": "scf_elastic_constants"}
    fs = assemble_factsheet(
        work_dir=fr["work_dir"], profile_id="P1",
        profile=profile_min, results=fr["results"],
    )
    html = render_factsheet_html(fs)
    assert html.startswith("<!DOCTYPE html>")
    assert 'lang="fr"' in html
    assert "<meta charset=\"utf-8\">" in html or 'charset="utf-8"' in html
    assert "🧠 Analyse experte" in html
    # User-controlled strings échappées : le work_dir est inclu & escapé.
    import html as _html_mod
    if "&lt;" not in html and "&amp;" not in html:
        # Pas une régression stricte : on vérifie au moins que les balises
        # n'ont pas été injectéesRAW dans le DOM.
        assert "<script" not in html.lower()


# ============================================================================
# Tests : factsheet_ai (moteur expert rule-based)
# ============================================================================

def test_compute_insights_born_ok():
    """Born : marges saines (C11 >> C12, C44 > 0) → success."""
    from factsheet_ai import compute_insights, Insight
    # factsheet.FactsheetSections factice.
    class _F:
        pass
    f = _F()
    f.eos_rows = []
    f.elastic_rows_exec = [("C₁₁", 153.0, "GPa"), ("C₁₂", 56.8, "GPa"), ("C₄₄", 75.5, "GPa")]
    f.elastic_rows_poly = [("B (VRH)", 88.94, "GPa"), ("G (VRH)", 64.55, "GPa"),
                          ("E (VRH)", 155.93, "GPa"), ("ν (Poisson)", 0.2078, "")]
    f.elastic_extra = [("zener_anisotropy_ratio_A", 1.562, "")]
    f.electronic_rows = [("Gap VBM→CBM", 0.66, "eV"), ("E_Fermi", 6.048, "eV")]
    f.electronic_extra = [("Nature du gap", "semi-conducteur à gap indirect", "")]
    f.dyn_stability_rows = [("Stable dynamiquement", True, ""),
                            ("Modes imaginaires", 0, ""),
                            ("ω_min (mode acoustique le plus mou)", 120.0, "cm⁻¹")]
    f.phonon_lifetime_rows = []
    f.dielectric_rows = []
    f.born_rows = []
    f.header = {"work_dir": str(Path.cwd())}

    ins = compute_insights(f, work_dir=Path.cwd())
    levels = [i.level for i in ins]
    # Au moins un succès (Born) et au moins un info (Pugh).
    assert "success" in levels
    # Structure (param de maille) est appelé même sans V₀ (no-op si V₀ absent).
    cats = [i.category for i in ins]
    assert "elasticity" in cats


def test_lattice_parameter_from_v0_fcc_uses_conventional_cell():
    """FCC : a doit être dérivé de la maille conventionnelle, pas de la primitive."""
    from factsheet_ai import _lattice_parameter_from_v0

    v0_bohr3 = 4.0 * 4.0 * 4.0
    a_ang = _lattice_parameter_from_v0(v0_bohr3, ibrav=2, n_atoms_per_conventional_cell=4)
    assert math.isclose(a_ang, (4.0 * v0_bohr3 * (0.529177210903 ** 3)) ** (1.0 / 3.0), rel_tol=1e-12)


# ============================================================================
# Tests : _lattice_parameter_angstrom (paramètres de maille complets en Å)
# ============================================================================

def test_lattice_parameter_angstrom_cubic_fcc_si(tmp_path):
    """ibrav=2 (FCC) avec celldm(1) → a en Å + source='celldm'."""
    from factsheet_ai import _lattice_parameter_angstrom
    wd = tmp_path / "si"
    wd.mkdir()
    (wd / "scf.in").write_text(
        "&CONTROL\n  calculation = 'scf'\n"
        "&SYSTEM\n"
        "  ibrav = 2,\n"
        "  celldm(1) = 10.26,\n"  # bohr ≈ 5.43 Å conventionnel Si FCC
        "  nat = 2,\n  ntyp = 1,\n",
        encoding="utf-8",
    )
    lat = _lattice_parameter_angstrom(wd)
    assert lat["source"] == "celldm"
    assert lat["ibrav"] == 2
    assert lat["a_ang"] is not None
    assert math.isclose(lat["a_ang"], 10.26 * 0.529177210903, rel_tol=1e-12)
    assert lat["b_ang"] == lat["a_ang"]
    assert lat["c_ang"] == lat["a_ang"]
    assert lat["alpha_deg"] == 90.0


def test_lattice_parameter_angstrom_hex_graphite(tmp_path):
    """ibrav=4 (hex) avec celldm(1) + celldm(3)=c/a → c ≠ a, γ=120°."""
    from factsheet_ai import _lattice_parameter_angstrom
    wd = tmp_path / "graphite"
    wd.mkdir()
    # Graphite : a=2.46 Å, c=6.71 Å → c/a ≈ 2.727 ; celldm(1) en bohr ≈ 4.648.
    (wd / "scf.in").write_text(
        "&SYSTEM\n"
        "  ibrav = 4,\n"
        "  celldm(1) = 4.648,\n"
        "  celldm(3) = 2.727,\n",
        encoding="utf-8",
    )
    lat = _lattice_parameter_angstrom(wd)
    assert lat["source"] == "celldm"
    assert lat["ibrav"] == 4
    assert math.isclose(lat["a_ang"], 4.648 * 0.529177, rel_tol=1e-3)
    assert math.isclose(lat["c_ang"], lat["a_ang"] * 2.727, rel_tol=1e-3)
    assert lat["gamma_deg"] == 120.0


def test_lattice_parameter_angstrom_tetragonal_p(tmp_path):
    """ibrav=6 (tetr P) avec celldm(3)=c/a → c ≠ a, angles = 90°."""
    from factsheet_ai import _lattice_parameter_angstrom
    wd = tmp_path / "tetra_p"
    wd.mkdir()
    (wd / "scf.in").write_text(
        "&SYSTEM\n"
        "  ibrav = 6,\n"
        "  celldm(1) = 7.5,\n"
        "  celldm(3) = 1.10,\n",
        encoding="utf-8",
    )
    lat = _lattice_parameter_angstrom(wd)
    assert lat["ibrav"] == 6
    assert math.isclose(lat["a_ang"], 7.5 * 0.529177, rel_tol=1e-3)
    assert math.isclose(lat["c_ang"], lat["a_ang"] * 1.10, rel_tol=1e-3)
    assert lat["alpha_deg"] == 90.0


def test_lattice_parameter_angstrom_orthorhombic(tmp_path):
    """ibrav=8 (ortho P) avec celldm(2)=b/a + celldm(3)=c/a → a ≠ b ≠ c."""
    from factsheet_ai import _lattice_parameter_angstrom
    wd = tmp_path / "ortho"
    wd.mkdir()
    # Ba_129 YBCO-style : a=3.85, b=3.88, c=11.65 Å
    # a_bohr ≈ 3.85/0.529177 ≈ 7.28 ; b/a≈1.008 ; c/a≈3.026
    (wd / "scf.in").write_text(
        "&SYSTEM\n"
        "  ibrav = 8,\n"
        "  celldm(1) = 7.28,\n"
        "  celldm(2) = 1.008,\n"
        "  celldm(3) = 3.026,\n",
        encoding="utf-8",
    )
    lat = _lattice_parameter_angstrom(wd)
    assert lat["ibrav"] == 8
    assert math.isclose(lat["a_ang"], 7.28 * 0.529177, rel_tol=1e-3)
    assert math.isclose(lat["b_ang"], lat["a_ang"] * 1.008, rel_tol=1e-3)
    assert math.isclose(lat["c_ang"], lat["a_ang"] * 3.026, rel_tol=1e-3)
    assert lat["alpha_deg"] == 90.0


def test_lattice_parameter_angstrom_monoclinic(tmp_path):
    """ibrav=12 (mono P) avec cos(α) → angle ≠ 90° (cas α≠β)."""
    from factsheet_ai import _lattice_parameter_angstrom
    import math as _math
    wd = tmp_path / "mono"
    wd.mkdir()
    (wd / "scf.in").write_text(
        "&SYSTEM\n"
        "  ibrav = 12,\n"
        "  celldm(1) = 8.0,\n"     # a en bohr
        "  celldm(2) = 1.20,\n"     # b/a
        "  celldm(3) = 1.50,\n"     # c/a
        "  celldm(4) = 0.70,\n",    # cos(α) → α ≈ 45.6°
        encoding="utf-8",
    )
    lat = _lattice_parameter_angstrom(wd)
    assert lat["ibrav"] == 12
    a_ang = 8.0 * 0.529177
    assert math.isclose(lat["a_ang"], a_ang, rel_tol=1e-3)
    assert _math.isclose(lat["alpha_deg"], _math.degrees(_math.acos(0.70)), rel_tol=1e-3)


def test_lattice_parameter_angstrom_triclinic(tmp_path):
    """ibrav=14 (triclinic P) avec tous les celldm → a, b, c, α, β, γ."""
    from factsheet_ai import _lattice_parameter_angstrom
    import math as _math
    wd = tmp_path / "triclinic"
    wd.mkdir()
    (wd / "scf.in").write_text(
        "&SYSTEM\n"
        "  ibrav = 14,\n"
        "  celldm(1) = 10.0,\n"
        "  celldm(2) = 0.95,\n"
        "  celldm(3) = 1.10,\n"
        "  celldm(4) = 0.60,\n"  # cos(α)
        "  celldm(5) = 0.70,\n"  # cos(β)
        "  celldm(6) = 0.80,\n", # cos(γ)
        encoding="utf-8",
    )
    lat = _lattice_parameter_angstrom(wd)
    assert lat["ibrav"] == 14
    a_ang = 10.0 * 0.529177
    assert math.isclose(lat["a_ang"], a_ang, rel_tol=1e-3)
    assert math.isclose(lat["b_ang"], a_ang * 0.95, rel_tol=1e-3)
    assert math.isclose(lat["c_ang"], a_ang * 1.10, rel_tol=1e-3)
    assert _math.isclose(lat["alpha_deg"], _math.degrees(_math.acos(0.60)), rel_tol=1e-3)
    assert _math.isclose(lat["beta_deg"],  _math.degrees(_math.acos(0.70)), rel_tol=1e-3)
    assert _math.isclose(lat["gamma_deg"], _math.degrees(_math.acos(0.80)), rel_tol=1e-3)


def test_lattice_parameter_angstrom_ibrav0_with_cell_parameters_bohr(tmp_path):
    """ibrav=0 + CELL_PARAMETERS en bohr → extraction directe des primitives."""
    import math as _math
    from factsheet_ai import _lattice_parameter_angstrom
    wd = tmp_path / "ibrav0_bohr"
    wd.mkdir()
    # Vecteurs cubique simple : a1=(a,0,0), a2=(0,a,0), a3=(0,0,a), a=5 bohr.
    a_bohr = 5.0
    (wd / "scf.in").write_text(
        "&SYSTEM\n  ibrav = 0,\n"
        "CELL_PARAMETERS bohr\n"
        f"  {a_bohr}  0.0  0.0\n"
        f"  0.0  {a_bohr}  0.0\n"
        f"  0.0  0.0  {a_bohr}\n",
        encoding="utf-8",
    )
    lat = _lattice_parameter_angstrom(wd)
    assert lat["source"] == "cell_parameters"
    assert lat["ibrav"] == 0
    a_ang_expected = a_bohr * 0.529177
    assert _math.isclose(lat["a_ang"], a_ang_expected, rel_tol=1e-3)
    assert _math.isclose(lat["b_ang"], a_ang_expected, rel_tol=1e-3)
    assert _math.isclose(lat["c_ang"], a_ang_expected, rel_tol=1e-3)
    assert _math.isclose(lat["alpha_deg"], 90.0, abs_tol=1e-2)
    assert _math.isclose(lat["beta_deg"], 90.0, abs_tol=1e-2)
    assert _math.isclose(lat["gamma_deg"], 90.0, abs_tol=1e-2)


def test_lattice_parameter_angstrom_ibrav0_angstrom_units(tmp_path):
    """ibrav=0 + CELL_PARAMETERS angstrom → pas de conversion bohr→Å."""
    import math as _math
    from factsheet_ai import _lattice_parameter_angstrom
    wd = tmp_path / "ibrav0_ang"
    wd.mkdir()
    # Vecteur monoclinique : a = 5 Å, a2=(2,5,0) (≠90° entre a1 et a2)
    (wd / "scf.in").write_text(
        "&SYSTEM\n  ibrav = 0,\n"
        "CELL_PARAMETERS angstrom\n"
        "  5.0  0.0  0.0\n"
        "  2.0  5.0  0.0\n"
        "  0.0  0.0  6.0\n",
        encoding="utf-8",
    )
    lat = _lattice_parameter_angstrom(wd)
    assert lat["cell_unit"] == "angstrom" or lat["cell_unit"] is None
    assert _math.isclose(lat["a_ang"], 5.0, rel_tol=1e-3)
    assert _math.isclose(lat["b_ang"], _math.sqrt(2**2 + 5**2), rel_tol=1e-3)
    assert _math.isclose(lat["c_ang"], 6.0, rel_tol=1e-3)
    # γ entre a1 (5,0,0) et a2 (2,5,0) : cos(γ) = 10/(5·√29).
    expected_gamma = _math.degrees(_math.acos(10.0 / (5.0 * _math.sqrt(29.0))))
    assert _math.isclose(lat["gamma_deg"], expected_gamma, rel_tol=1e-3)


def test_lattice_parameter_angstrom_no_scf_in(tmp_path):
    """Aucun scf.in : tous les params None, source='none'."""
    from factsheet_ai import _lattice_parameter_angstrom
    lat = _lattice_parameter_angstrom(tmp_path)
    assert lat["source"] == "none"
    assert lat["a_ang"] is None
    assert lat["b_ang"] is None
    assert lat["c_ang"] is None


def test_lattice_parameter_angstrom_v0_fallback(tmp_path):
    """V₀ seul fourni sans celldm/CELL_PARAMETERS → repli sur V₀ avec note."""
    from factsheet_ai import _lattice_parameter_angstrom
    wd = tmp_path / "v0_only"
    wd.mkdir()
    (wd / "scf.in").write_text(
        "&SYSTEM\n  ibrav = 2,\n  nat = 4,\n",  # pas de celldm(1)
        encoding="utf-8",
    )
    v0_si = 4 * (10.26 / 2) ** 3  # FCC primitive = a^3/4 → V₀ cell primitive
    lat = _lattice_parameter_angstrom(wd, v0_bohr3=v0_si)
    assert lat["source"] == "v0_ibrav_guess"
    assert lat["a_ang"] is not None
    assert lat["note"] is not None
    assert "hypothèse" in lat["note"].lower()


def test_section_eos_displays_lattice_a_angstrom(tmp_path, monkeypatch):
    """``_section_eos`` affiche ``a`` en Å quand V₀ et work_dir fournis."""
    import config as cfg
    from factsheet import _section_eos
    wd = tmp_path / "si_eos"
    wd.mkdir()
    (wd / "scf.in").write_text(
        "&SYSTEM\n  ibrav = 2,\n  celldm(1) = 10.26,\n",
        encoding="utf-8",
    )
    rows = _section_eos({"eos": {"V0_bohr3": 270.0}}, work_dir=wd)
    labels = [lab for lab, _, _ in rows]
    assert "a" in labels
    a_val = next(v for lab, v, _ in rows if lab == "a")
    assert math.isclose(a_val, 10.26 * 0.529177, rel_tol=1e-3)


def test_compute_insights_born_violated():
    """Born violé (C11 < |C12|) → insight ``error``."""
    from factsheet_ai import compute_insights
    class _F:
        pass
    f = _F()
    f.eos_rows = []
    # C11 < |C12| → critère C₁₁ − C₁₂ > 0 violé.
    f.elastic_rows_exec = [("C₁₁", 100.0, "GPa"), ("C₁₂", 150.0, "GPa"), ("C₄₄", 80.0, "GPa")]
    f.elastic_rows_poly = [("B (VRH)", 90.0, "GPa"), ("G (VRH)", 30.0, "GPa"),
                          ("E (VRH)", 80.0, "GPa"), ("ν (Poisson)", 0.3, "")]
    f.elastic_extra = []
    f.electronic_rows = []
    f.electronic_extra = []
    f.dyn_stability_rows = []
    f.phonon_lifetime_rows = []
    f.dielectric_rows = []
    f.born_rows = []
    f.header = {"work_dir": str(Path.cwd())}
    ins = compute_insights(f, work_dir=Path.cwd())
    born_err = [i for i in ins if i.category == "elasticity" and "Born" in i.title and i.level == "error"]
    assert born_err, "Au moins un insight Born ERROR attendu"


def test_compute_insights_gap_metal():
    """Gap négatif → métallisé, classification metal."""
    from factsheet_ai import compute_insights
    class _F:
        pass
    f = _F()
    f.eos_rows = []
    f.elastic_rows_exec = [("C₁₁", 200.0, "GPa"), ("C₁₂", 110.0, "GPa"), ("C₄₄", 80.0, "GPa")]
    f.elastic_rows_poly = [("B (VRH)", 140.0, "GPa"), ("G (VRH)", 50.0, "GPa"),
                          ("E (VRH)", 130.0, "GPa"), ("ν (Poisson)", 0.3, "")]
    f.elastic_extra = []
    f.electronic_rows = [("Gap VBM→CBM", -0.1, "eV"), ("E_Fermi", 6.5, "eV")]
    f.electronic_extra = [("Nature du gap", "métallique (gap ≤ 0 eV)", "")]
    f.dyn_stability_rows = [("Stable dynamiquement", True, "")]
    f.phonon_lifetime_rows = []
    f.dielectric_rows = []
    f.born_rows = []
    f.header = {"work_dir": str(Path.cwd())}
    ins = compute_insights(f, work_dir=Path.cwd())
    elec = [i for i in ins if i.category == "electronic"]
    assert any("métallique" in i.body.lower() for i in elec)


def test_compute_insights_pugh_ductile():
    """Pugh : B/G = 2.0 > 1.75 → ductile."""
    from factsheet_ai import compute_insights
    class _F:
        pass
    f = _F()
    f.eos_rows = []
    f.elastic_rows_exec = [("C₁₁", 200.0, "GPa"), ("C₁₂", 110.0, "GPa"), ("C₄₄", 80.0, "GPa")]
    f.elastic_rows_poly = [("B (VRH)", 100.0, "GPa"), ("G (VRH)", 50.0, "GPa"),
                          ("E (VRH)", 130.0, "GPa"), ("ν (Poisson)", 0.3, "")]
    f.elastic_extra = []
    f.electronic_rows = []
    f.electronic_extra = []
    f.dyn_stability_rows = []
    f.phonon_lifetime_rows = []
    f.dielectric_rows = []
    f.born_rows = []
    f.header = {"work_dir": str(Path.cwd())}
    ins = compute_insights(f, work_dir=Path.cwd())
    pugh = [i for i in ins if "Pugh" in i.title]
    assert pugh and "ductile" in pugh[0].body.lower()


def test_compute_insights_dyn_stability_negative():
    """``dynamically_stable=False`` + n_imaginary_modes > 0 → insight ``error``."""
    from factsheet_ai import compute_insights
    class _F:
        pass
    f = _F()
    f.eos_rows = []
    f.elastic_rows_exec = []
    f.elastic_rows_poly = []
    f.elastic_extra = []
    f.electronic_rows = []
    f.electronic_extra = []
    f.dyn_stability_rows = [
        ("Stable dynamiquement", False, ""),
        ("Modes imaginaires", 2, ""),
        ("ω_min (mode acoustique le plus mou)", -25.4, "cm⁻¹"),
    ]
    f.phonon_lifetime_rows = []
    f.dielectric_rows = []
    f.born_rows = []
    f.header = {"work_dir": str(Path.cwd())}
    ins = compute_insights(f, work_dir=Path.cwd())
    dyn_err = [i for i in ins if i.category == "phonon" and i.level == "error"]
    assert dyn_err


# ============================================================================
# Tests : profil-aware coverage (P3 + P4 + smoke all 5 profiles)
# ============================================================================

def _make_work_dir_P3(tmp_path: Path) -> dict:
    """P3 = P2 + C_ij vs T : EOS + thermo (Debye) + C_ij(V₀,T)."""
    wd = tmp_path / "work_root" / "Mat_P3" / "pipeline_P3_1782943407_xyz987"
    res = {
        "eos": {
            "V0_bohr3": 269.5, "B0_GPa": 90.1, "B0prime": 4.21, "E0_Ry": -15.7401,
        },
        "thermo": {
            "debye_temperature_K": 631.0, "zero_point_energy_Ry": 0.00082,
        },
        "properties": {
            "fermi_eV": 6.04, "band_gap_eV": 0.60,
            "band_gap_type": "semiconductor", "band_gap_direct": False,
            "n_bands": 12,
            "dynamically_stable": True, "n_imaginary_modes": 0, "min_freq_cm-1": 142.0,
        },
        "elastic": {
            "C11_GPa": 152.8, "C12_GPa": 56.6, "C44_GPa": 74.9,
            "bulk_modulus_GPa": 88.8, "shear_modulus_GPa": 64.4,
            "young_modulus_GPa": 155.6, "poisson_ratio": 0.208,
            "zener_anisotropy_ratio_A": 1.56,
        },
    }
    _write_marker(wd, job_id="P3-job-id-fixture", profile_id="P3", results=res)
    return {"work_dir": wd, "results": res}


def _make_work_dir_P4(tmp_path: Path) -> dict:
    """P4 = P3 + ph_life (anharmonicité) : τ_λ, γ, κ_lattice, Grüneisen."""
    wd = tmp_path / "work_root" / "Mat_P4" / "pipeline_P4_1782943507_q4r567"
    res = {
        "eos": {
            "V0_bohr3": 268.0, "B0_GPa": 91.0, "B0prime": 4.18, "E0_Ry": -15.7450,
        },
        "thermo": {"debye_temperature_K": 633.0, "zero_point_energy_Ry": 0.00083},
        "ph_life": {
            "mean_lifetime_ps": 12.4,
            "min_lifetime_ps": 2.1,
            "max_lifetime_ps": 45.9,
            "mean_linewidth_cm-1": 0.42,
            "max_linewidth_cm-1": 3.21,
            "lattice_kappa_W_mK": 105.0,
            "gruneisen_mean": 1.15,
            "gruneisen_max_abs": 2.74,
        },
        "properties": {
            "fermi_eV": 6.02, "band_gap_eV": 0.59,
            "band_gap_type": "semiconductor", "band_gap_direct": False,
            "n_bands": 12,
            "dynamically_stable": True, "n_imaginary_modes": 0, "min_freq_cm-1": 150.0,
        },
        "elastic": {
            "C11_GPa": 152.0, "C12_GPa": 56.4, "C44_GPa": 74.5,
            "bulk_modulus_GPa": 88.5, "shear_modulus_GPa": 64.2,
            "young_modulus_GPa": 155.0, "poisson_ratio": 0.207,
        },
    }
    _write_marker(wd, job_id="P4-job-id-fixture", profile_id="P4", results=res)
    return {"work_dir": wd, "results": res}


def test_assemble_factsheet_P3_full_panorama(tmp_path, monkeypatch):
    """P3 : EOS + Cij(V,T) + gap + Debye + Stabilité dynamique."""
    import config as cfg
    from factsheet import assemble_factsheet

    fr = _make_work_dir_P3(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)

    profile_min = {"id": "P3", "name": "Étude complète", "what_qe": "elastic_constants_geo"}
    fs = assemble_factsheet(
        work_dir=fr["work_dir"], profile_id="P3",
        profile=profile_min, results=fr["results"],
    )
    eos_labels = [lab for lab, _, _ in fs.eos_rows]
    assert "V₀ (volume d'équilibre)" in eos_labels
    elastic_labels = [lab for lab, _, _ in fs.elastic_rows_exec]
    assert "C₁₁" in elastic_labels
    assert "C₁₂" in elastic_labels
    assert "C₄₄" in elastic_labels
    # Stabilité dynamique OK.
    assert any(lab == "Stable dynamiquement" and val is True
               for lab, val, _ in fs.dyn_stability_rows)
    # Couverture catégorie AI « structure » : P3 a EOS + scf.in (ibrav via _make_work_dir_P3),
    # donc ``_insight_structure`` émet bien la catégorie « structure » (P1 sans EOS ne le peut pas).
    cats = [ins.category for ins in fs.ai_insights]
    assert "structure" in cats


def test_assemble_factsheet_P4_has_phonon_lifetime(tmp_path, monkeypatch):
    """P4 : section 'ph_life' peuplée par ≥3 métriques (τ, γ, κ, Grüneisen)."""
    import config as cfg
    from factsheet import assemble_factsheet

    fr = _make_work_dir_P4(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)

    profile_min = {"id": "P4", "name": "Durée de vie phonons", "what_qe": "ph_life"}
    fs = assemble_factsheet(
        work_dir=fr["work_dir"], profile_id="P4",
        profile=profile_min, results=fr["results"],
    )
    # EOS + thermo présents.
    assert len(fs.eos_rows) >= 1
    # Au moins 3 lignes de ph_life (assure la diversité des métriques τ, γ, κ, Grüneisen).
    assert len(fs.phonon_lifetime_rows) >= 3
    # Au moins un label caractéristique.
    phi_labels = [lab for lab, _, _ in fs.phonon_lifetime_rows]
    assert any("τ" in lab for lab in phi_labels)
    assert any("γ" in lab or "linewidth" in lab.lower() for lab in phi_labels)


# ============================================================================
# Smoke test : les 5 profils rendent SANS crash (mark + html valides).
# ============================================================================

@pytest.mark.parametrize("profile_id", ["P1", "P2", "P3", "P4", "P5"])
def test_smoke_render_each_profile(tmp_path, monkeypatch, profile_id):
    """Chaque profil P1..P5 doit produire un MD + HTML non vide + sans 'SyntaxError'."""
    import config as cfg
    from factsheet import assemble_factsheet, render_factsheet_md, render_factsheet_html

    # WORK_ROOT arbitraire (par profil).
    monkeypatch.setattr(cfg, "WORK_ROOT", tmp_path)
    wd = tmp_path / "work_root" / f"Mat_{profile_id}" / f"pipeline_{profile_id}_SYNTHETIC"
    res: dict[str, Any] = {
        "eos": {"V0_bohr3": 270.0, "B0_GPa": 89.0, "B0prime": 4.2, "E0_Ry": -15.74},
        "thermo": {"debye_temperature_K": 630.0},
        "properties": {
            "fermi_eV": 6.05, "band_gap_eV": 0.65, "band_gap_type": "semiconductor",
            "band_gap_direct": False, "n_bands": 12,
            "dynamically_stable": True, "n_imaginary_modes": 0, "min_freq_cm-1": 120.0,
        },
        "elastic": {
            "C11_GPa": 153.0, "C12_GPa": 57.0, "C44_GPa": 75.0,
            "bulk_modulus_GPa": 89.0, "shear_modulus_GPa": 64.5,
            "young_modulus_GPa": 155.9, "poisson_ratio": 0.21,
        },
        "ph_life": {
            "mean_lifetime_ps": 12.0, "mean_linewidth_cm-1": 0.4,
            "lattice_kappa_W_mK": 100.0,
        },
        "dielectric": {
            "epsilon_xx": 12.0, "epsilon_yy": 12.0, "epsilon_zz": 12.0,
            "epsilon_average": 12.0, "epsilon_anisotropy": 1.0,
            "refractive_index_avg": 3.464, "born_Z_star_max_abs": 1.8,
            "born_Z_star_per_atom": [
                {"atom_index": 1, "atom_type": "X", "Z_star": [[1.8, 0, 0], [0, 1.8, 0], [0, 0, 1.8]]},
            ],
        },
    }
    _write_marker(wd, job_id=f"{profile_id}-smoke-fixture",
                  profile_id=profile_id, results=res)
    profile_min = {"id": profile_id, "name": f"Profil {profile_id}", "what_qe": "smoke"}
    fs = assemble_factsheet(
        work_dir=wd, profile_id=profile_id,
        profile=profile_min, results=res,
    )
    md = render_factsheet_md(fs)
    html_doc = render_factsheet_html(fs)
    # Pas de chaîne d'erreur dans le rendu.
    assert "SyntaxError" not in md
    assert "SyntaxError" not in html_doc
    # Rendu substantiel (>100 caractères).
    assert len(md) > 200
    assert len(html_doc) > 200
    # Sections communes présentes.
    assert f"({profile_id})" in md or profile_id in md
    # La section "Analyse experte" existe (toujours rendue, même vide).
    assert "🧠 Analyse experte" in md
    assert "🧠 Analyse experte" in html_doc


# ============================================================================
# Tests : endpoint Flask /api/pipeline/runs/<job_id>/factsheet
# ============================================================================

def test_factsheet_endpoint_returns_html_for_known_job(tmp_path, monkeypatch):
    """HTTP 200 + ``Content-Type: text/html`` + corps non vide pour un job connu."""
    import config as cfg
    # Bootstrap : crée le marker + redirige WORK_ROOT.
    fr = _make_work_dir_P2(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent, raising=False)

    # Importer api_server AVANT le monkeypatch est cassé : on triche avec un
    # (re)import du module pour propager les valeurs.
    if "api_server" in sys.modules:
        importlib.reload(sys.modules["api_server"])
    import api_server as srv
    client = srv.app.test_client()

    # GET au format HTML par défaut.
    resp = client.get(f"/api/pipeline/runs/P2-job-id-fixture/factsheet")
    assert resp.status_code == 200
    assert "text/html" in resp.headers.get("Content-Type", "")
    body = resp.get_data(as_text=True)
    # L'en-tête HTML écrit « Fiche technique THERMO_PW — … » (cf.
    # ``render_factsheet_html`` : H1 « Fiche technique THERMO_PW »). Le MD
    # utilise l'ordre inverse (« THERMO_PW — Fiche technique ») — on vérifie
    # donc la sous-chaîne commune aux deux formats + un identifiant profil/job.
    assert "Fiche technique THERMO_PW" in body
    assert "P2-job-id-fixture" in body
    # Content-Disposition : inline + filename
    cd = resp.headers.get("Content-Disposition", "")
    assert "inline" in cd
    assert "factsheet_P2_" in cd


def test_factsheet_endpoint_returns_md_when_format_param(tmp_path, monkeypatch):
    """``?format=md`` → ``Content-Type: text/markdown``."""
    import config as cfg
    fr = _make_work_dir_P2(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)
    if "api_server" in sys.modules:
        importlib.reload(sys.modules["api_server"])
    import api_server as srv
    client = srv.app.test_client()

    resp = client.get(f"/api/pipeline/runs/P2-job-id-fixture/factsheet?format=md")
    assert resp.status_code == 200
    assert "text/markdown" in resp.headers.get("Content-Type", "")
    body = resp.get_data(as_text=True)
    assert body.startswith("# THERMO_PW")
    # Vérifie qu'une section '🧠 Analyse experte' est bien rendue en MD.
    assert "## 10. 🧠 Analyse experte" in body


def test_factsheet_endpoint_404_for_unknown_job(tmp_path, monkeypatch):
    """job_id inexistant : HTTP 404 + JSON."""
    import config as cfg
    # Aucun marker, on balaye un work_root vide.
    empty_root = tmp_path / "empty_work"
    empty_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(cfg, "WORK_ROOT", empty_root)
    if "api_server" in sys.modules:
        importlib.reload(sys.modules["api_server"])
    import api_server as srv
    client = srv.app.test_client()

    resp = client.get("/api/pipeline/runs/this-job-does-not-exist/factsheet")
    assert resp.status_code == 404
    data = json.loads(resp.get_data(as_text=True))
    assert "introuvable" in (data.get("error") or "").lower()


def test_factsheet_endpoint_400_for_bad_format(tmp_path, monkeypatch):
    """``?format=docx`` (non supporté) → HTTP 400. Note : ``pdf`` est désormais valide
    (média ``application/pdf`` via WeasyPrint), il est testé séparément."""
    import config as cfg
    fr = _make_work_dir_P2(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)
    if "api_server" in sys.modules:
        importlib.reload(sys.modules["api_server"])
    import api_server as srv
    client = srv.app.test_client()

    resp = client.get(f"/api/pipeline/runs/P2-job-id-fixture/factsheet?format=docx")
    assert resp.status_code == 400
    data = json.loads(resp.get_data(as_text=True))
    assert "Format invalide" in (data.get("error") or "")
    # La liste blanche officielle expose md/html/pdf dans l'erreur 400.
    allowed = data.get("allowed_formats") or []
    assert "md" in allowed and "html" in allowed and "pdf" in allowed


def test_factsheet_options_returns_204(tmp_path, monkeypatch):
    """OPTIONS → 204 (CORS preflight)."""
    import config as cfg
    fr = _make_work_dir_P2(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)
    if "api_server" in sys.modules:
        importlib.reload(sys.modules["api_server"])
    import api_server as srv
    client = srv.app.test_client()

    resp = client.options(f"/api/pipeline/runs/P2-job-id-fixture/factsheet")
    assert resp.status_code in (204, 200)


def test_factsheet_endpoint_does_not_modify_marker(tmp_path, monkeypatch):
    """Aucun side-effect disque : mtime du marker inchangé avant/après l'appel."""
    import config as cfg
    fr = _make_work_dir_P2(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)
    if "api_server" in sys.modules:
        importlib.reload(sys.modules["api_server"])
    import api_server as srv
    client = srv.app.test_client()

    marker_path = fr["work_dir"] / "pipeline_api_job_state.json"
    mtime_before = marker_path.stat().st_mtime
    body_before = marker_path.read_text(encoding="utf-8")
    resp = client.get(f"/api/pipeline/runs/P2-job-id-fixture/factsheet")
    assert resp.status_code == 200
    # Springer + lit quelques octets : on tolère une modification « bloc » de
    # RocksDB-like state mais le marker réel (JSON) ne doit pas changer pour
    # une lecture idempotente.
    body_after = marker_path.read_text(encoding="utf-8")
    assert body_after == body_before
    # mtime peut varier si la système de fichiers a une granularité > 1 s :
    # on tolère ± 2 s (kernel coarse) mais le contenu doit être identique.
    mtime_after = marker_path.stat().st_mtime
    assert abs(mtime_after - mtime_before) <= 2.0


# ============================================================================
# Tests : option PDF (WeasyPrint, lazy-load)
# ============================================================================

def test_factsheet_pdf_resolve_backend_is_cached_and_idempotent(monkeypatch):
    """``_resolve_pdf_backend`` met en cache le verdict (None/"weasyprint").
    Le second appel ne re-tente pas l'import — utile pour les tests 503."""
    from factsheet import _resolve_pdf_backend as _r
    import factsheet as f_mod
    # Reset cache.
    monkeypatch.setattr(f_mod, "_PDF_BACKEND_NAME", None)
    # Premier appel (sentinelle fraîche) — résultat dépend de l'env.
    first = _r()
    # Second appel — DOIT retourner la valeur cachée, identique sans nouvel
    # import (test en vie si la lib est absente : first = None, second = None
    # et pas de nouveau ImportError).
    second = _r()
    assert first == second
    # Si None, le cache est bloqué en "" (sentinelle KO).
    assert (f_mod._PDF_BACKEND_NAME == "") or (f_mod._PDF_BACKEND_NAME == "weasyprint")


def test_factsheet_pdf_dependency_error_raised_when_no_lib(monkeypatch):
    """Sans weasyprint, ``render_factsheet_pdf`` lève ``_PdfDependencyError``
    et documente le ``pip install`` côté serveur."""
    # Force le verdict à None même si la lib est dispo.
    from factsheet import _PdfDependencyError, render_factsheet_pdf
    from factsheet import FactsheetSections
    import factsheet as f_mod
    monkeypatch.setattr(f_mod, "_PDF_BACKEND_NAME", "")
    fs = FactsheetSections()
    fs.header = {"job_id": "fake", "profile_id": "P1"}
    with pytest.raises(_PdfDependencyError) as ei:
        render_factsheet_pdf(fs)
    msg = str(ei.value).lower()
    assert "weasyprint" in msg or "pdf" in msg
    # Doit inclure un guide d'installation (pip / apt-get).
    assert ("pip install" in msg) or ("apt-get" in msg) or ("libcairo" in msg)


def test_factsheet_endpoint_pdf_returns_503_when_backend_unavailable(tmp_path, monkeypatch):
    """``?format=pdf`` + WeasyPrint absent → HTTP 503 + payload JSON avec hint."""
    import config as cfg
    from factsheet import _PdfDependencyError  # noqa: F401 — présence sanity.
    import factsheet as f_mod
    fr = _make_work_dir_P2(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)
    # Force le verdict backend à None même si la lib est dispo dans la CI.
    monkeypatch.setattr(f_mod, "_PDF_BACKEND_NAME", "")
    if "api_server" in sys.modules:
        importlib.reload(sys.modules["api_server"])
    import api_server as srv
    client = srv.app.test_client()

    resp = client.get(f"/api/pipeline/runs/P2-job-id-fixture/factsheet?format=pdf")
    assert resp.status_code == 503
    data = json.loads(resp.get_data(as_text=True))
    assert "PDF" in (data.get("error") or "")
    assert "weasyprint" in (data.get("detail") or "").lower()
    # Doit lister md/html comme formats disponibles en repli.
    avail = data.get("available_formats") or []
    assert "md" in avail and "html" in avail
    # Hint d'installation.
    assert "pip install" in (data.get("hint") or "")


def test_factsheet_endpoint_pdf_returns_pdf_bytes_when_libs_available(tmp_path, monkeypatch, _weasyprint_available):
    """``?format=pdf`` + WeasyPrint présent → HTTP 200 + bytes ``%PDF-…``
    + Content-Disposition inline + filename ``*.pdf``."""
    import config as cfg
    fr = _make_work_dir_P2(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)
    if "api_server" in sys.modules:
        importlib.reload(sys.modules["api_server"])
    import api_server as srv
    client = srv.app.test_client()

    resp = client.get(f"/api/pipeline/runs/P2-job-id-fixture/factsheet?format=pdf")
    assert resp.status_code == 200
    assert "application/pdf" in resp.headers.get("Content-Type", "")
    body = resp.get_data()
    # Séquence magique PDF (%%PDF-1.x).
    assert body[:4] == b"%PDF", f"Magie PDF absente : {body[:8]!r}"
    assert len(body) > 800, f"PDF trop petit pour un factsheet réel : {len(body)} octets"
    # Content-Disposition inline + filename en .pdf (RFC 5987 filename*).
    cd = resp.headers.get("Content-Disposition", "")
    assert "inline" in cd
    assert ".pdf" in cd
    assert "factsheet_P2_" in cd


@pytest.fixture
def _weasyprint_available():
    """Skip le test si WeasyPrint n'est pas utilisable côté serveur.
    Couvre le cas « la lib est installée mais ses natives Cairo/Pango
    manquent » (on tente un ``write_pdf`` vide pour valider l'env)."""
    pytest.importorskip("weasyprint")
    try:
        from weasyprint import HTML
        HTML(string="<html><body>x</body></html>").write_pdf()
    except Exception as ex:  # noqa: BLE001
        pytest.skip(f"WeasyPrint installé mais cassé côté natif : {ex}")


def test_health_endpoint_exposes_factsheet_pdf_flag(tmp_path, monkeypatch):
    """``/api/health`` expose ``factsheet_pdf_available`` (booléen).
    Permet à l'UI de désactiver l'option PDF sans round-trip HTTP de test."""
    if "api_server" in sys.modules:
        importlib.reload(sys.modules["api_server"])
    import api_server as srv
    client = srv.app.test_client()
    resp = client.get("/api/health")
    assert resp.status_code == 200
    data = json.loads(resp.get_data(as_text=True))
    assert "factsheet_pdf_available" in data
    assert isinstance(data["factsheet_pdf_available"], bool)
    # ``factsheet_available`` reste exposé (rétro-compat UI).
    assert "factsheet_available" in data
    assert isinstance(data["factsheet_available"], bool)


def test_health_endpoint_exposes_factsheet_versioning_fields(tmp_path, monkeypatch):
    """Juillet 2026 — ``/api/health`` expose la version + date de compilation
    UTC du module factsheet et du moteur expert, consommables par la chip UI
    ``#factsheetVersionChip``.

    Format attendu :
    - ``factsheet_version`` : str ``"MAJOR.MINOR"`` (``"1.0"`` avant 2.0).
    - ``factsheet_compiled_at`` : str ISO date ``YYYY-MM-DD`` (UTC).
    - ``factsheet_ai_version`` : str ``"MAJOR.MINOR"``.
    - ``factsheet_ai_compiled_at`` : str ISO date ``YYYY-MM-DD`` (UTC).
    """
    if "api_server" in sys.modules:
        importlib.reload(sys.modules["api_server"])
    import api_server as srv
    client = srv.app.test_client()
    resp = client.get("/api/health")
    assert resp.status_code == 200
    data = json.loads(resp.get_data(as_text=True))

    for key in ("factsheet_version", "factsheet_compiled_at",
                "factsheet_ai_version", "factsheet_ai_compiled_at"):
        assert key in data, f"champ manquant : {key}"

    if bool(data.get("factsheet_available")):
        for ver_key in ("factsheet_version", "factsheet_ai_version"):
            v = data[ver_key]
            assert isinstance(v, str)
            parts = v.split(".")
            assert len(parts) == 2 and all(p.isdigit() for p in parts), \
                f"{ver_key} mauvais format : {v!r}"
        for date_key in ("factsheet_compiled_at", "factsheet_ai_compiled_at"):
            d = data[date_key]
            assert d == "—" or (
                isinstance(d, str) and len(d) == 10
                and d[4] == "-" and d[7] == "-"
                and d[:4].isdigit() and d[5:7].isdigit() and d[8:].isdigit()
            ), f"{date_key} mauvais format : {d!r}"


def test_module_compile_iso_returns_iso_date_utc(tmp_path):
    """``_module_compile_iso`` lit ``Path.stat().st_mtime`` puis formate en UTC ``YYYY-MM-DD``."""
    from factsheet import _module_compile_iso
    import time, os, datetime as _dt
    target = tmp_path / "fake_module.py"
    target.write_text("# fixture", encoding="utf-8")
    yesterday = time.time() - 86400
    os.utime(target, (yesterday, yesterday))
    iso = _module_compile_iso(target)
    assert isinstance(iso, str) and len(iso) == 10
    assert iso[4] == "-" and iso[7] == "-"
    expected = _dt.datetime.fromtimestamp(yesterday, tz=_dt.timezone.utc).strftime("%Y-%m-%d")
    assert iso == expected, f"attendu {expected} (UTC), obtenu {iso}"


# ============================================================================
# Juillet 2026 — tests pour la section 'Stabilité' unifiée + θ_D + bands_ok
# ============================================================================
#
# Le passage à une section Stabilité unifiée (Born statique + dynamique DFPT),
# l'ajout de la température de Debye dans les extras thermo, et le flag
# bands_ok dans la section électronique, agrandissent le contrat de la fiche
# technique. Les tests suivants verrouillent ces invariants sur des fixtures
# minimales (dict ``results`` typique d'un run P1/P2).
# ============================================================================


def test_assemble_factsheet_stability_rows_has_static_and_dynamic():
    """Section 5 doit exposer **côte à côte** les deux critères."""
    from factsheet import assemble_factsheet

    results = {
        "elastic": {"elastic_cubic_independent_GPa": {
            "C11_GPa": 153.0, "C12_GPa": 57.0, "C44_GPa": 75.0
        }},
        "properties": {"dynamically_stable": True, "n_imaginary_modes": 0,
                       "min_freq_cm-1": 140.0},
    }
    fs = assemble_factsheet(
        work_dir=Path("/tmp/no-such"),
        profile_id="P2",
        profile={"name": "EOS+thermo"},
        results=results,
        marker_root={"job_id": "j-stab-test", "profile_id": "P2",
                     "material_id": "Si"},
    )
    labels = [lab for lab, _, _ in fs.stability_rows]
    # Critère statique (Born) — au moins une ligne indiquant le verdict global.
    # Tolérant à la casse (label généré "Stabilité statique (…, Born, Cij)" —
    # « statique » en minuscules dans le rendu FR).
    assert any(
        (("Statique" in lab) or ("statique" in lab) or ("Stabilité" in lab))
        and (("Born" in lab) or ("Cij" in lab) or ("C₁₁" in lab))
        for lab in labels
    ), f"stability_rows doit contenir une ligne 'Statique (Born)' ; a : {labels}"
    # Critère dynamique — au moins une ligne indiquant le verdict DFPT.
    assert any(("Dynamique" in lab) or ("dynamique" in lab) for lab in labels), \
        f"stability_rows doit contenir une ligne 'Dynamique' (phonons) ; a : {labels}"


def test_assemble_factsheet_stability_static_ok_when_born_level_ok():
    """Born level=='ok' ⇒  ligne statique porte ``✅ Borne OK``."""
    from factsheet import assemble_factsheet

    results = {
        "elastic": {"elastic_cubic_independent_GPa": {
            "C11_GPa": 153.0, "C12_GPa": 57.0, "C44_GPa": 75.0
        }},
        "properties": {"dynamically_stable": True, "n_imaginary_modes": 0,
                       "min_freq_cm-1": 140.0},
    }
    marker = {"job_id": "j-test-static-ok", "profile_id": "P2"}
    fs = assemble_factsheet(work_dir=Path("/tmp/no-such"), profile_id="P2",
                            profile={"name": "P2"}, results=results,
                            marker_root=marker)
    static_row = next(
        ((lab, val, unit) for lab, val, unit in fs.stability_rows
         if "Statique" in lab and "Cij" in lab or "Born" in lab),
        None,
    )
    assert static_row is not None, "Ligne statique absente"
    assert "OK" in str(static_row[1]), \
        f"Verdict statique doit afficher OK ; a : {static_row[1]!r}"
    # Les marges Born sont également rendues :
    margins = [v for lab, v, _ in fs.stability_rows
               if lab.startswith("  C") and "(" in lab]
    assert len(margins) >= 3, f"3 marges Born attendues ; a : {margins}"


def test_assemble_factsheet_stability_static_error_when_born_violated():
    """Born level=='error' ⇒ ligne statique porte ``❌``."""
    from factsheet import assemble_factsheet

    results = {
        "elastic": {"elastic_cubic_independent_GPa": {
            "C11_GPa": -10.0, "C12_GPa": 0.0, "C44_GPa": 0.0  # C44 = 0 ⇒ violation
        }},
        "properties": {"dynamically_stable": False, "n_imaginary_modes": 2,
                       "min_freq_cm-1": -50.0},
    }
    fs = assemble_factsheet(work_dir=Path("/tmp/no-such"), profile_id="P1",
                            profile={"name": "P1"}, results=results,
                            marker_root={"job_id": "j-bad", "profile_id": "P1"})
    labels = [lab for lab, _, _ in fs.stability_rows]
    # Tolérance à la casse — le label généré est "Stabilité statique (…)".
    static_row = next(
        (row for row in fs.stability_rows
         if ("Statique" in row[0]) or ("statique" in row[0]) or ("Stabilité" in row[0])),
        None,
    )
    assert static_row is not None
    assert "viol" in str(static_row[1]).lower() or "❌" in str(static_row[1]), \
        f"Verdict statique doit indiquer violation ; a : {static_row[1]!r}"
    dyn_row = next(
        (row for row in fs.stability_rows
         if ("Dynamique" in row[0]) or ("dynamique" in row[0])),
        None,
    )
    assert dyn_row is not None
    assert "imaginaire" in str(dyn_row[1]).lower() or "❌" in str(dyn_row[1]), \
        f"Verdict dynamique doit indiquer modes imaginaires ; a : {dyn_row[1]!r}"


def test_assemble_factsheet_thermo_extras_includes_debye_temperature():
    """Θ Debye apparaît dans ``fs.extras_rows`` si ``thermo.debye_temperature_K`` est présent."""
    from factsheet import assemble_factsheet

    results = {"thermo": {
        "debye_temperature_K": 645.3,
        "zero_point_energy_Ry": 0.00082,
    }}
    fs = assemble_factsheet(work_dir=Path("/tmp/no-such"), profile_id="P2",
                            profile={"name": "P2"}, results=results,
                            marker_root={"job_id": "j", "profile_id": "P2"})
    extras_labels = [lab for lab, _, _ in fs.extras_rows]
    assert "Θ Debye" in extras_labels, \
        f"Θ Debye attendu dans extras_rows ; labels : {extras_labels}"
    debye_row = next(row for row in fs.extras_rows if row[0] == "Θ Debye")
    assert debye_row[2] == "K"
    assert abs(float(debye_row[1]) - 645.3) < 1e-9
    # ZPE en bonus :
    zpe_row = next((row for row in fs.extras_rows if "ZPE" in row[0]), None)
    assert zpe_row is not None, "ZPE doit aussi apparaître"


def test_assemble_factsheet_thermo_extras_p1_minimal_no_debye():
    """P1 (sans ``thermo``) : la section extras ne crashe pas et Debye absent."""
    from factsheet import assemble_factsheet

    results = {"properties": {"band_gap_eV": 0.66}}
    fs = assemble_factsheet(work_dir=Path("/tmp/no-such"), profile_id="P1",
                            profile={"name": "P1"}, results=results,
                            marker_root={"job_id": "j", "profile_id": "P1"})
    extras_labels = [lab for lab, _, _ in fs.extras_rows]
    assert "Θ Debye" not in extras_labels, \
        "Pas de Debye pour P1 (sans thermo_pw what='thermo')"


def test_assemble_factsheet_thermo_extras_includes_alpha_cp_and_coverage():
    """α, Cp, sources et couverture apparaissent dans la fiche technique."""
    from factsheet import assemble_factsheet

    results = {
        "thermo": {
            "debye_temperature_K": 634.0,
            "Cv_300K_Ry_per_K": 3.07e-05,
            "F_300K_Ry": 0.00597,
            "entropy_300K_Ry_per_K": 2.62e-05,
            "alpha_300K_per_K": 8.64e-06,
            "Cp_300K_Ry_per_K": 3.07e-05,
            "alpha_source": "slater_gamma_0.5_estimate",
            "Cp_source": "Cv_plus_TValpha2B",
            "therm_source_file": "output_therm_debye.g1",
        },
    }
    fs = assemble_factsheet(
        work_dir=Path("/tmp/no-such"),
        profile_id="P1",
        profile={"name": "P1"},
        results=results,
        marker_root={"job_id": "j", "profile_id": "P1"},
    )
    extras_labels = [lab for lab, _, _ in fs.extras_rows]
    assert any("α dilatation" in lab for lab in extras_labels)
    assert any("Cₚ" in lab for lab in extras_labels)
    assert any("Source α" in lab for lab in extras_labels)
    parsed_labels = [lab for lab, _, _ in fs.parsed_metrics_rows]
    assert any("α dilatation" in lab for lab in parsed_labels)
    cov = {lab: val for lab, val, _ in fs.extended_coverage_rows}
    assert cov.get("Dilatation thermique α(T)") == "✓ Rempli"
    assert cov.get("Permittivité statique ε₀") == "— Absent"
    md = __import__("factsheet", fromlist=["render_factsheet_md"]).render_factsheet_md(fs)
    assert "8a. Couverture des propriétés étendues" in md
    assert "Grandeurs parsées" in md
    assert "slater_gamma_0.5_estimate" in md


def test_assemble_factsheet_electronic_includes_bands_ok_flag():
    """``properties.bands_ok → bands_ok`` apparaît en première ligne de electronic."""
    from factsheet import assemble_factsheet

    results = {"properties": {
        "bands_ok": True, "fermi_eV": 6.04, "n_bands": 16,
        "band_gap_eV": 0.66, "band_gap_type": "semiconductor",
    }}
    fs = assemble_factsheet(work_dir=Path("/tmp/no-such"), profile_id="P1",
                            profile={"name": "P1"}, results=results,
                            marker_root={"job_id": "j", "profile_id": "P1"})
    elec_labels = [lab for lab, _, _ in fs.electronic_rows]
    assert any("bands.x" in lab.lower() or "ok" in lab.lower()
               for lab in elec_labels), \
        f"bands_ok doit apparaître ; labels : {elec_labels}"
    # Gap et E_Fermi restent présents
    assert "Gap VBM→CBM" in elec_labels
    assert "E_Fermi" in elec_labels


def test_render_factsheet_md_section5_uses_stability_rows():
    """Le rendu MD utilise ``fs.stability_rows`` pour la section 5
    (et n'utilise plus ``fs.dyn_stability_rows`` seul)."""
    from factsheet import render_factsheet_md, FactsheetSections

    fs = FactsheetSections()
    fs.header = {"job_id": "j-md-stab", "profile_id": "P2",
                 "profile_name": "EOS+thermo", "material_id": "Si",
                 "work_dir": "/tmp/j", "status": "done",
                 "scf_in_basename": "scf.in", "nproc": "4",
                 "created_at": "2026-07-03", "finished_at": "2026-07-03",
                 "extra_whats": [], "p1_full_preset": None,
                 "what_qe": "scf_elastic_constants"}
    fs.stability_rows = [
        ("Stabilité statique (critère de Born, Cij)", "✅ Born OK", ""),
        ("Stabilité dynamique (phonons, DFPT)", "✅ Tous modes ≥ 0", ""),
    ]
    md = render_factsheet_md(fs)
    assert "Stabilité" in md and "Born" in md and "DFPT" in md, \
        f"Section 5 doit citer 'Born' et 'DFPT' ; MD :\n{md[:2000]}"
    assert "✅ Born OK" in md
    assert "✅ Tous modes ≥ 0" in md
    # L'en-tête de section doit être celui de la stabilité unifiée :
    assert "Statique (Born, Cij)" in md or "Stabilité statique" in md or \
           ("5" in md and "Stabilité" in md)


def test_enrich_results_from_workdir_fills_stale_gap(tmp_path):
    """Marker périmé (gap null) complété depuis ``bands.dat`` sur disque."""
    from factsheet import assemble_factsheet, _enrich_results_from_workdir
    from electronic_props import parse_bands_gap

    wd = tmp_path / "run"
    wd.mkdir()
    # Copie minimale : bands.dat depuis fixture P1 si dispo, sinon skip.
    src = Path("/home/hiadsi/thermo_pw/work/Si/pipeline_P1_1784044538_02200e/bands.dat")
    if not src.is_file():
        import pytest
        pytest.skip("P1 bands.dat absent sur disque")
    (wd / "bands.dat").write_bytes(src.read_bytes())
    (wd / "nscf.out").write_text("!", encoding="utf-8")
    (wd / "ebands.png").write_bytes(b"x" * 200)
    (wd / "edos.png").write_bytes(b"x" * 200)
    stale = {
        "properties": {
            "fermi_eV": 6.2912,
            "band_gap_eV": None,
            "bands_ok": False,
            "dos_ok": True,
        },
        "plots": {"ebands": None, "edos": "edos.png", "phonon_bands": "phonon_bands.png"},
    }
    enriched = _enrich_results_from_workdir(wd, stale)
    assert enriched["properties"]["band_gap_eV"] == parse_bands_gap(wd, fermi_eV=6.2912)["gap_eV"]
    assert enriched["properties"]["bands_ok"] is True
    assert enriched["plots"]["ebands"] == "ebands.png"


def test_shared_preview_donor_prefers_p1_for_si():
    """``_find_shared_preview_donor`` retourne le run P1 Si terminé."""
    import config as cfg
    from pipeline import _find_shared_preview_donor, _pick_shared_preview_results
    from factsheet import _enrich_results_from_workdir

    donor = _find_shared_preview_donor(cfg.WORK_ROOT.resolve(), "Si")
    if donor is None:
        import pytest
        pytest.skip("Pas de run Si sur disque")
    assert donor.get("profile_id") == "P1"
    wd = Path(str(donor.get("work_dir") or ""))
    if not wd.is_dir():
        wd = cfg.WORK_ROOT / str(donor.get("work_dir") or "")
    res = _enrich_results_from_workdir(wd, donor.get("results") or {})
    picked = _pick_shared_preview_results(res)
    assert picked.get("properties", {}).get("band_gap_eV") is not None
    assert picked.get("plots", {}).get("ebands")


def test_render_factsheet_html_section5_uses_stability_rows():
    """Le rendu HTML utilise ``fs.stability_rows`` pour la section 5."""
    from factsheet import render_factsheet_html, FactsheetSections

    fs = FactsheetSections()
    fs.header = {"job_id": "j-test", "profile_id": "P2",
                 "profile_name": "EOS+thermo", "material_id": "Si",
                 "work_dir": "/tmp/j", "status": "done",
                 "scf_in_basename": "scf.in", "nproc": "4",
                 "created_at": "2026-07-03", "finished_at": "2026-07-03",
                 "extra_whats": [], "p1_full_preset": None,
                 "what_qe": "scf_elastic_constants"}
    fs.stability_rows = [
        ("Stabilité statique (Born)", "✅ Born OK", ""),
        ("Stabilité dynamique (DFPT)", "❌ 2 modes imaginaires", ""),
    ]
    html_src = render_factsheet_html(fs)
    assert "Stabilité" in html_src
    assert "Born" in html_src
    assert "DFPT" in html_src
    assert "✅ Born OK" in html_src



# ============================================================================
# Juillet 2026 — Section 2b : Évolution thermique P3 (C_ij(V₀, T))
# ============================================================================
#
# P3 (profil ``elastic_constants_geo``) produit le fichier canonique
# ``elastic_constants_vs_T.dat`` que la fiche technique lit à la demande via
# ``parsers.elastic_t_dat_scan``. Les tests suivants vérifient :
#   1. Remplissage de ``fs.elastic_t_section`` (rows, VRH, Born) pour P3.
#   2. Rendu MD + HTML de la section 2b.
#   3. Auto-détection kbar → GPa (thermo_pw output_el_cons en kbar).
#   4. Dégradation gracieuse si le .dat est absent (P1/P2/P4/P5).
#   5. Pas de VRH/Born si la grille n'est pas cubique stricte (5+ colonnes).
# ============================================================================


def _write_elastic_vs_T_dat(work_dir: Path, *, units: str = "GPa", ncol: int = 4) -> Path:
    """Écrit un fichier ``elastic_constants_vs_T.dat`` minimal mais conforme
    au format thermo_pw pour P3 (colonnes T, C11, C12, C44). ``units`` :
    ``"GPa"`` (défaut) ou ``"kbar"`` (× 10). ``ncol`` : nombre de colonnes
    (4 = cubique strict, 5+ = non-cubique).
    """
    import math
    rows = []
    # Grille 0 -> 1000 K pas 100 K, décroissance légère -0.5%/100K (physique réaliste).
    scale = 10.0 if units == "kbar" else 1.0
    c11_0 = 167.0 * scale
    c12_0 = 65.0 * scale
    c44_0 = 80.0 * scale
    for t in range(0, 1001, 100):
        decay = 1.0 - 0.005 * (t / 100.0)
        c11 = c11_0 * decay
        c12 = c12_0 * decay
        c44 = c44_0 * decay
        if ncol == 4:
            rows.append(f"{t:6.1f}  {c11:9.3f}  {c12:9.3f}  {c44:9.3f}")
        else:
            # 5 colonnes : ajoute C13 bidon (non-cubique).
            rows.append(f"{t:6.1f}  {c11:9.3f}  {c12:9.3f}  {c44:9.3f}  {0.0:9.3f}")
    out_path = work_dir / "elastic_constants_vs_T.dat"
    out_path.write_text("\n".join(rows) + "\n", encoding="utf-8")
    return out_path


def test_assemble_factsheet_P3_populates_elastic_t_section(tmp_path, monkeypatch):
    """P3 avec ``elastic_constants_vs_T.dat`` → ``fs.elastic_t_section`` est
    peuplé (rows, VRH, Born, is_cubic=True, T_min, T_max, n_points)."""
    import config as cfg
    from factsheet import assemble_factsheet

    fr = _make_work_dir_P3(tmp_path)
    _write_elastic_vs_T_dat(fr["work_dir"], units="GPa")
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)

    profile_min = {"id": "P3", "name": "Étude complète", "what_qe": "elastic_constants_geo"}
    fs = assemble_factsheet(
        work_dir=fr["work_dir"], profile_id="P3",
        profile=profile_min, results=fr["results"],
    )
    et = fs.elastic_t_section
    assert et, "elastic_t_section doit être peuplé pour P3"
    assert et["n_points"] == 11  # 0,100,...,1000
    assert et["t_min"] == 0.0
    assert et["t_max"] == 1000.0
    assert et["is_cubic"] is True
    assert et["units_were_kbar"] is False
    assert len(et["rows"]) == 11
    assert len(et["vrh"]) == 11
    # Born verdict aux bornes 0 K et 1000 K.
    assert 0 in et["born"] and 1000 in et["born"]
    ok_0, fails_0 = et["born"][0]
    assert ok_0 is True, f"Born à 0 K doit être OK : {fails_0}"
    ok_1k, fails_1k = et["born"][1000]
    assert ok_1k is True, f"Born à 1000 K doit être OK : {fails_1k}"
    # VRH à T=0 : B = (167+2×65)/3 = 99.0 GPa.
    t0, vrh0 = et["vrh"][0]
    assert t0 == 0.0
    assert abs(vrh0["B_GPa"] - 99.0) < 0.5
    # ν à T=0 (Si : 0.21 ± 0.05).
    assert 0.15 < vrh0["nu"] < 0.30


def test_assemble_factsheet_P3_section_2b_renders_in_md_and_html(tmp_path, monkeypatch):
    """Le rendu MD + HTML inclut bien la section 2b pour P3."""
    import config as cfg
    from factsheet import assemble_factsheet, render_factsheet_md, render_factsheet_html

    fr = _make_work_dir_P3(tmp_path)
    _write_elastic_vs_T_dat(fr["work_dir"], units="GPa")
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)

    profile_min = {"id": "P3", "name": "Étude complète", "what_qe": "elastic_constants_geo"}
    fs = assemble_factsheet(
        work_dir=fr["work_dir"], profile_id="P3",
        profile=profile_min, results=fr["results"],
    )
    md = render_factsheet_md(fs)
    html_doc = render_factsheet_html(fs)
    # Section 2b présente.
    assert "## 2b. Évolution thermique P3" in md
    assert "<h2>2b. Évolution thermique P3" in html_doc
    # Born verdict (✅ Stable à 0 K et 1000 K).
    assert "Stabilité de Born" in md
    assert "T = 0 K : ✅ Stable" in md
    assert "T = 1000 K : ✅ Stable" in md
    assert "Stabilité de Born" in html_doc
    # Tableau Cij(T) — 1ère ligne (T=0) et 1ère colonne (C₁₁=167.00 ± décroissance).
    assert "C₁₁ (GPa)" in html_doc
    # Modules VRH présents.
    assert "VRH (Hill)" in md
    assert "B (GPa)" in html_doc
    # Plot ref.
    assert "elastic_vs_T_plot.png" in md
    assert "elastic_vs_T_plot.png" in html_doc


def test_assemble_factsheet_P3_kbar_units_auto_converted_to_gpa(tmp_path, monkeypatch):
    """Si le .dat est en kbar (thermo_pw legacy), ``units_were_kbar=True`` et
    les C_ij sont divisés par 10 dans le rendu."""
    import config as cfg
    from factsheet import assemble_factsheet

    fr = _make_work_dir_P3(tmp_path)
    _write_elastic_vs_T_dat(fr["work_dir"], units="kbar")
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)

    profile_min = {"id": "P3", "name": "Étude complète", "what_qe": "elastic_constants_geo"}
    fs = assemble_factsheet(
        work_dir=fr["work_dir"], profile_id="P3",
        profile=profile_min, results=fr["results"],
    )
    et = fs.elastic_t_section
    assert et["units_were_kbar"] is True
    # C_ij à T=0 : kbar source ~1670, après conversion → 167.00 GPa.
    t0, c11, c12, c44 = et["rows"][0]
    assert 166.0 < c11 < 168.0
    assert 64.0 < c12 < 66.0
    assert 79.0 < c44 < 81.0
    # VRH B à T=0 doit être ~99 GPa.
    _, vrh0 = et["vrh"][0]
    assert abs(vrh0["B_GPa"] - 99.0) < 0.5


def test_assemble_factsheet_P1_no_elastic_t_section(tmp_path, monkeypatch):
    """P1 (pas de .dat) : ``fs.elastic_t_section`` reste vide (rows=[])."""
    import config as cfg
    from factsheet import assemble_factsheet

    fr = _make_work_dir_P1(tmp_path)  # pas d'elastic_constants_vs_T.dat écrit
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)

    profile_min = {"id": "P1", "name": "Mécanique 0 K", "what_qe": "scf_elastic_constants"}
    fs = assemble_factsheet(
        work_dir=fr["work_dir"], profile_id="P1",
        profile=profile_min, results=fr["results"],
    )
    et = fs.elastic_t_section
    assert et["rows"] == []
    assert et["error"] in (None, "no elastic_t dat found")


def test_assemble_factsheet_P1_md_html_no_section_2b(tmp_path, monkeypatch):
    """P1 (sans .dat) : la section 2b n'apparaît pas dans le rendu MD/HTML."""
    import config as cfg
    from factsheet import assemble_factsheet, render_factsheet_md, render_factsheet_html

    fr = _make_work_dir_P1(tmp_path)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)

    profile_min = {"id": "P1", "name": "Mécanique 0 K", "what_qe": "scf_elastic_constants"}
    fs = assemble_factsheet(
        work_dir=fr["work_dir"], profile_id="P1",
        profile=profile_min, results=fr["results"],
    )
    md = render_factsheet_md(fs)
    html_doc = render_factsheet_html(fs)
    assert "## 2b. Évolution thermique P3" not in md
    assert "<h2>2b. Évolution thermique P3" not in html_doc


def test_assemble_factsheet_P3_non_cubic_no_vrh_no_born(tmp_path, monkeypatch):
    """P3 avec grille non-cubique stricte (5 colonnes) : ``is_cubic=False``,
    pas de VRH ni de verdict Born (les colonnes 2:5 ne sont pas garanties
    C₁₁/C₁₂/C₄₄ pour un réseau non-cubique)."""
    import config as cfg
    from factsheet import assemble_factsheet

    fr = _make_work_dir_P3(tmp_path)
    _write_elastic_vs_T_dat(fr["work_dir"], units="GPa", ncol=5)
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)

    profile_min = {"id": "P3", "name": "Étude complète", "what_qe": "elastic_constants_geo"}
    fs = assemble_factsheet(
        work_dir=fr["work_dir"], profile_id="P3",
        profile=profile_min, results=fr["results"],
    )
    et = fs.elastic_t_section
    # rows toujours présentes (colonnes 1:4 = T, ?, ?, ?), mais is_cubic=False.
    assert et["is_cubic"] is False
    assert et["born"] == {}
    # Pas de vrh (les formules cubique ne s'appliquent pas).
    assert et["vrh"] == []
    # rows non vides (le parser ne refuse pas, on a 4 colonnes même si ncol=5).
    # Au minimum, on a les colonnes T + 3 Cij-like parsées.
    # (le parser tronque à ncol=4, donc rows peut etre non-vide.)


def test_assemble_factsheet_P3_born_verdict_error_when_c11_negative(tmp_path, monkeypatch):
    """P3 avec C₁₁ négatif (matériau fictif mécaniquement instable) :
    Born verdict passe à ❌ Instable avec la liste des fails."""
    import config as cfg
    from factsheet import assemble_factsheet

    fr = _make_work_dir_P3(tmp_path)
    # Écrit un .dat pathologique : C11 < 0 + C44 < 0 à T=0, C11 < |C12|.
    bad = fr["work_dir"] / "elastic_constants_vs_T.dat"
    bad.write_text(
        "    0.0    -10.000    100.000     -5.000\n"
        " 1000.0     80.000     30.000     40.000\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)

    profile_min = {"id": "P3", "name": "Étude complète", "what_qe": "elastic_constants_geo"}
    fs = assemble_factsheet(
        work_dir=fr["work_dir"], profile_id="P3",
        profile=profile_min, results=fr["results"],
    )
    et = fs.elastic_t_section
    ok_0, fails_0 = et["born"][0]
    assert ok_0 is False
    assert any("C₁₁" in f for f in fails_0)
    assert any("C₄₄" in f for f in fails_0)
    # À 1000 K : ok (C11=80 > 0, C44=40 > 0, C11 > |C12|, C11+2*C12 > 0).
    ok_1k, _ = et["born"][1000]
    assert ok_1k is True


def test_vrh_cubic_formulas_match_literature_si():
    """Sanity direct sur ``_vrh_cubic`` : pour Si à T=0K, on retrouve B=99,
    G_Hill=66.8, E=164.7, ν=0.232 (littérature Phys. Rev. B 36, 4379)."""
    from factsheet import _vrh_cubic
    vrh = _vrh_cubic(167.0, 65.0, 80.0)
    # B = (167+130)/3 = 99.0
    assert abs(vrh["B_GPa"] - 99.0) < 1e-6
    # G_V = (167-65+240)/5 = 68.4
    assert abs(vrh["G_V_GPa"] - 68.4) < 1e-6
    # G_R = 5*(167-65)*80 / (4*80+3*102) = 40800 / 626 = 65.18...
    assert abs(vrh["G_R_GPa"] - 40800 / 626) < 1e-3
    # G_Hill = (G_V + G_R)/2
    g_hill_expected = (68.4 + 40800 / 626) / 2
    assert abs(vrh["G_Hill_GPa"] - g_hill_expected) < 1e-3
    # E = 9*B*G/(3B+G) ; ν = (3B-2G)/(2*(3B+G))
    e_expected = 9 * 99.0 * g_hill_expected / (3 * 99.0 + g_hill_expected)
    nu_expected = (3 * 99.0 - 2 * g_hill_expected) / (2 * (3 * 99.0 + g_hill_expected))
    assert abs(vrh["E_GPa"] - e_expected) < 1e-3
    assert abs(vrh["nu"] - nu_expected) < 1e-6


def test_born_stability_ok_detects_all_4_violations():
    """``_born_stability_ok`` détecte les 4 critères de violation Born."""
    from factsheet import _born_stability_ok
    # Tout OK
    ok, fails = _born_stability_ok(167.0, 65.0, 80.0)
    assert ok is True and fails == []
    # C₁₁ ≤ 0
    ok, fails = _born_stability_ok(-10.0, 65.0, 80.0)
    assert ok is False and any("C₁₁" in f for f in fails)
    # C₄₄ ≤ 0
    ok, fails = _born_stability_ok(167.0, 65.0, -5.0)
    assert ok is False and any("C₄₄" in f for f in fails)
    # C₁₁ ≤ |C₁₂| (critère Born — mécaniquement instable)
    ok, fails = _born_stability_ok(50.0, 100.0, 80.0)
    assert ok is False and any("mécaniquement" in f for f in fails)
    # C₁₁ + 2·C₁₂ ≤ 0
    ok, fails = _born_stability_ok(50.0, -30.0, 80.0)
    assert ok is False and any("compression" in f for f in fails)


def test_section_elastic_vs_T_handles_empty_workdir(tmp_path):
    """``_section_elastic_vs_T`` avec workdir vide : dict avec rows=[],
    error rempli (pas de crash)."""
    from factsheet import _section_elastic_vs_T
    et = _section_elastic_vs_T(tmp_path)
    assert et["rows"] == []
    assert et["vrh"] == []
    assert et["born"] == {}
    assert et["error"] in (None, "no elastic_t dat found")


def test_section_elastic_vs_T_handles_none_workdir():
    """``_section_elastic_vs_T`` avec workdir=None : rows=[], error='work_dir is None'."""
    from factsheet import _section_elastic_vs_T
    et = _section_elastic_vs_T(None)
    assert et["rows"] == []
    assert et["error"] == "work_dir is None"



def test_fmt_renders_nan_as_em_dash():
    """``_fmt`` retourne ``—”`` pour NaN et None (juillet 2026, harmonisé
    avec la convention None déjà utilisée par ``_format_table_md`` /
    ``_format_table_html``). Évite le littéral Python ``“nan”`` dans les
    tableaux MD/HTML — propagation cohérente à toute la fiche.

    Note : ``_fmt`` ne filtre PAS explicitement ``inf`` (followup reviewer
    #1, non bloquant pour ce ship). ``_fmt(inf)`` renvoie ``“inf”`` via
    le path magnitude → format ``:.3e``. Un futur fix étendra la garde
    à ``or math.isinf(f)``.
    """
    from factsheet import _fmt
    # NaN et None -> em-dash (le nouveau contrat, propagation à toute la fiche).
    assert _fmt(float("nan")) == "—"
    assert _fmt(None) == "—"
    # inf : pas encore géré (suivi reviewer #1) — on documente le contrat actuel.
    assert _fmt(float("inf")) == "inf"
    # Valeurs valides : formatage normal.
    assert _fmt(99.0) == "99.0000"  # défaut n=4
    assert _fmt(0.232, n=3) == "0.232"
    # Nombres très grands : notation scientifique.
    assert "e+" in _fmt(1.5e6).lower()
    # Nombres très petits : idem.
    s = _fmt(1.5e-5)
    assert "e" in s.lower()



def test_assemble_factsheet_P3_unstable_material_vrh_renders_em_dash(tmp_path, monkeypatch):
    """P3 avec Cij pathologique (Born violé) : VRH affiche ``"—"`` (pas
    ``"nan"``) dans le MD et l'HTML. Test d'intégration end-to-end."""
    import config as cfg
    from factsheet import assemble_factsheet, render_factsheet_md, render_factsheet_html

    fr = _make_work_dir_P3(tmp_path)
    # C11 négatif à T=0 (Born violé), Cij sain à T=1000 K.
    bad = fr["work_dir"] / "elastic_constants_vs_T.dat"
    bad.write_text(
        "    0.0    -10.000    100.000     -5.000\n"
        " 1000.0     80.000     30.000     40.000\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(cfg, "WORK_ROOT", fr["work_dir"].parent.parent)

    profile_min = {"id": "P3", "name": "Étude complète", "what_qe": "elastic_constants_geo"}
    fs = assemble_factsheet(
        work_dir=fr["work_dir"], profile_id="P3",
        profile=profile_min, results=fr["results"],
    )
    md = render_factsheet_md(fs)
    html_doc = render_factsheet_html(fs)
    # Le littéral "nan" ne doit JAMAIS apparaître (régression).
    assert "nan" not in md.lower(), f"NaN littéral trouvé dans MD : {md!r}"
    assert "nan" not in html_doc.lower(), f"NaN littéral trouvé dans HTML : {html_doc!r}"
    # Born verdict error : "❌ Instable" doit apparaître.
    assert "❌ Instable" in md
    # La table VRH doit contenir au moins un "—" (G_R / E / ν sont NaN).
    assert "—" in md
    assert "—" in html_doc

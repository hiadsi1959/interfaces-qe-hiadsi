"""Régression : ``ph_control`` ne doit jamais déclarer ``outdir``.

thermo_pw redirige ``outdir`` vers ``<outdir_pw>/g<N>/`` avant chaque géométrie
(``set_outdir_name(igeom)``, tools/src/set_files_names.f90), puis lit
``ph_control``. Un ``outdir`` explicite dans le namelist écrase cette
redirection : les neuf géométries QHA relisent alors les fonctions d'onde du
seul volume d'équilibre et renvoient des matrices dynamiques identiques.

Le défaut est silencieux et ruineux — il a produit 16 h de DFPT redondante,
des Grüneisen de mode nuls, une dilatation thermique nulle, puis un abandon
dans DGELS lors de l'ajustement QHA (le fit d'une surface d'énergie libre sans
dépendance en volume est singulier). D'où ce garde-fou.
"""
from __future__ import annotations

import re

from ph_input_from_pw import (
    normalize_ph_control_for_thermo_pw,
    strip_outdir_for_thermo_pw,
    try_autogenerate_ph_in,
)

_RE_OUTDIR_IN_NAMELIST = re.compile(r"(?mi)^[ \t]*outdir[ \t]*=")

PH_CONTROL_FAUTIF = """! commentaire mentionnant prefix/outdir, sans effet
thermo_pw_ph

&inputph
  tr2_ph = 1.0d-14
  prefix = 'scf_eq'
  outdir = './out_scf_eq/'
  ldisp = .true.
  nq1 = 4
  nq2 = 4
  nq3 = 4
  fildyn = 'ph_dyn'
  fildvscf = 'dvscf'
/
"""

PW_IN = """&CONTROL
    calculation = 'scf'
    prefix = 'scf_eq'
    outdir = './out_scf_eq/'
/
&SYSTEM
    ibrav = 2
    celldm(1) = 10.351164630629
    nat = 2
    ntyp = 1
    ecutwfc = 60.0
/
"""


def _namelist_body(text: str) -> str:
    return text.split("&inputph", 1)[1]


class TestStripOutdir:
    def test_outdir_retire_et_valeur_rapportee(self):
        out, removed = strip_outdir_for_thermo_pw(PH_CONTROL_FAUTIF)
        assert removed == "./out_scf_eq/"
        assert not _RE_OUTDIR_IN_NAMELIST.search(_namelist_body(out))

    def test_les_autres_parametres_survivent(self):
        out, _ = strip_outdir_for_thermo_pw(PH_CONTROL_FAUTIF)
        for garde in ("tr2_ph", "prefix = 'scf_eq'", "ldisp", "nq1 = 4",
                      "fildyn = 'ph_dyn'", "fildvscf = 'dvscf'"):
            assert garde in out, garde
        # Le namelist reste syntaxiquement clos.
        assert out.rstrip().endswith("/")

    def test_idempotent(self):
        une, _ = strip_outdir_for_thermo_pw(PH_CONTROL_FAUTIF)
        deux, removed = strip_outdir_for_thermo_pw(une)
        assert deux == une and removed is None

    def test_sans_namelist_le_texte_est_intact(self):
        for texte in ("", "   ", "aucun namelist ici\n"):
            assert strip_outdir_for_thermo_pw(texte) == (texte, None)

    def test_outdir_hors_namelist_preserve(self):
        """Un ``outdir`` en préambule n'est pas lu par Fortran : on n'y touche pas."""
        texte = "outdir = './ailleurs/'\nthermo_pw_ph\n\n&inputph\n  prefix = 'x'\n/\n"
        out, removed = strip_outdir_for_thermo_pw(texte)
        assert removed is None and out == texte


class TestNormalisationComplete:
    def test_normalisation_supprime_outdir(self):
        out = normalize_ph_control_for_thermo_pw(PH_CONTROL_FAUTIF)
        assert not _RE_OUTDIR_IN_NAMELIST.search(_namelist_body(out))

    def test_ligne_titre_toujours_presente(self):
        """Sans ligne titre, phq_readin_tpw consomme la première ligne du namelist."""
        sans_titre = PH_CONTROL_FAUTIF.replace("thermo_pw_ph\n", "")
        out = normalize_ph_control_for_thermo_pw(sans_titre)
        avant = out.split("&inputph", 1)[0].splitlines()
        assert any(s.strip() and not s.strip().startswith("!") for s in avant)
        assert not _RE_OUTDIR_IN_NAMELIST.search(_namelist_body(out))


class TestGenerateur:
    def test_ph_control_genere_sans_outdir(self, tmp_path):
        (tmp_path / "pw_scf_V0_for_phonon.in").write_text(PW_IN, encoding="utf-8")
        ok, msg = try_autogenerate_ph_in(tmp_path, "ph_control")
        assert ok, msg
        texte = (tmp_path / "ph_control").read_text(encoding="utf-8")
        assert not _RE_OUTDIR_IN_NAMELIST.search(_namelist_body(texte))
        assert "prefix = 'scf_eq'" in texte

    def test_ph_in_autonome_garde_outdir(self, tmp_path):
        """ph.x lancé seul doit savoir où sont les fonctions d'onde."""
        (tmp_path / "pw_scf_V0_for_phonon.in").write_text(PW_IN, encoding="utf-8")
        ok, msg = try_autogenerate_ph_in(tmp_path, "ph.in")
        assert ok, msg
        texte = (tmp_path / "ph.in").read_text(encoding="utf-8")
        assert _RE_OUTDIR_IN_NAMELIST.search(_namelist_body(texte))
        assert "outdir = './out_scf_eq/'" in texte

"""Tests reprise partielle thermo_pw (P1–P5) sans refaire EOS / phonons."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import thermo_pw_resume as tpr  # noqa: E402


def _write_phonon_prereqs(wd: Path) -> None:
    (wd / "ph.out").write_text("ph\n", encoding="utf-8")
    (wd / "fc.out").write_text("fc\n", encoding="utf-8")
    (wd / "scf.in").write_text("&control\n/", encoding="utf-8")


def _write_qha_progress(wd: Path, *, done: int, total: int = 9) -> None:
    therm = wd / "therm_files"
    therm.mkdir(parents=True, exist_ok=True)
    dyn = wd / "dynamical_matrices"
    dyn.mkdir(parents=True, exist_ok=True)
    for g in range(1, done + 1):
        (therm / f"output_therm.dat.g{g}").write_text("ok\n", encoding="utf-8")
        for i in range(1, 4):
            (dyn / f"ph_dyn.g{g}.{i}").write_text("x\n", encoding="utf-8")
    g_bad = done + 1
    if g_bad <= total:
        (dyn / f"ph_dyn.g{g_bad}.1").write_text("partial\n", encoding="utf-8")
        (wd / "out_scf_eq" / f"g{g_bad}" / "_ph0").mkdir(parents=True, exist_ok=True)


class TestPhononPrereqs:
    def test_ok_when_minimal_chain_present(self, tmp_path: Path):
        _write_phonon_prereqs(tmp_path)
        ok, msg = tpr.phonon_prereqs_ok(tmp_path)
        assert ok is True
        assert msg == ""

    def test_ko_without_ph_out(self, tmp_path: Path):
        ok, msg = tpr.phonon_prereqs_ok(tmp_path)
        assert ok is False
        assert "ph.out" in msg


class TestPrepareWorkDir:
    def test_purge_restart_and_partial_qha_geometry(self, tmp_path: Path):
        _write_qha_progress(tmp_path, done=4, total=9)
        (tmp_path / "restart").mkdir()
        (tmp_path / "restart" / "bad.dat").write_text("x", encoding="utf-8")

        res = tpr.prepare_work_dir_for_resume(
            tmp_path, profile_id="P2", target="thermo_main"
        )
        assert not (tmp_path / "restart").exists()
        assert any("restart/" in a for a in res.actions)
        assert not (tmp_path / "dynamical_matrices" / "ph_dyn.g5.1").exists()
        assert (tmp_path / "therm_files" / "output_therm.dat.g4").is_file()


class TestListResumeTargets:
    @pytest.mark.parametrize("profile_id,label_fragment", [
        ("P2", "mur_lc_t"),
        ("P3", "elastic_constants_geo"),
        ("P4", "ph_life"),
    ])
    def test_qha_profiles_include_main_target(
        self, tmp_path: Path, profile_id: str, label_fragment: str,
    ):
        _write_qha_progress(tmp_path, done=4, total=9)
        targets = tpr.list_resume_targets(
            profile_id=profile_id,
            work_dir=tmp_path,
        )
        assert len(targets) == 1
        assert targets[0].target_id == "thermo_main"
        assert label_fragment in targets[0].label
        assert targets[0].qha_done == 4

    def test_p2_includes_qha_counts(self, tmp_path: Path):
        _write_qha_progress(tmp_path, done=4, total=9)
        targets = tpr.list_resume_targets(
            profile_id="P2",
            work_dir=tmp_path,
        )
        assert targets[0].recommended is True
        assert targets[0].qha_total is not None
        assert targets[0].qha_total >= 4


class TestDetectDgels:
    def test_detect_from_log_tail(self, tmp_path: Path):
        (tmp_path / "thermo_pw_run.out").write_text(
            "ok\nIntel oneMKL ERROR: Parameter 7 was incorrect on entry to DGELS.\n",
            encoding="utf-8",
        )
        assert tpr.detect_qha_least_squares_failure(tmp_path) is True

    def test_detect_dgelss_in_text(self):
        assert tpr.logs_indicate_qha_least_squares_failure(
            "Intel oneMKL ERROR: Parameter 6 was incorrect on entry to DGELSS.\n"
            "Error in routine linsolvsvd (6)\n"
        )

    def test_absent_log(self, tmp_path: Path):
        assert tpr.detect_qha_least_squares_failure(tmp_path) is False


class TestProfileThermDefaults:
    @pytest.mark.parametrize("profile_id,mode", [
        ("P2", "dos"),
        ("P3", "dos"),
        ("P4", "freq"),
    ])
    def test_default_therm_mode(self, profile_id: str, mode: str):
        assert tpr.default_therm_mode_for_profile(profile_id) == mode

    def test_non_qha_returns_none(self):
        assert tpr.default_therm_mode_for_profile("P1") is None


class TestValidateLsolve:
    def test_none_ok(self):
        assert tpr.validate_lsolve(None) is None
        assert tpr.validate_lsolve("") is None

    def test_valid_values(self):
        assert tpr.validate_lsolve(3) == 3
        assert tpr.validate_lsolve("2") == 2

    def test_invalid_raises(self):
        with pytest.raises(ValueError, match="lsolve"):
            tpr.validate_lsolve(4)


class TestParseResumeThermoOverrides:
    def test_qha_full(self):
        out = tpr.parse_resume_thermo_overrides(
            {"lsolve": 1, "deltat": 100, "therm_mode": "freq"},
            profile_id="P2",
        )
        assert out == {
            "lsolve": 1,
            "deltat": 100.0,
            "ltherm_dos": False,
            "ltherm_freq": True,
        }

    def test_p1_rejects_qha_keys(self):
        with pytest.raises(ValueError, match="QHA"):
            tpr.parse_resume_thermo_overrides({"deltat": 100}, profile_id="P1")


class TestRoutes:
    @staticmethod
    def _client():
        from api_server import app
        return app.test_client()

    def _make_job(self, tmp_path: Path, *, in_registry: bool = True):
        from pipeline import PipelineJob

        _write_phonon_prereqs(tmp_path)
        _write_qha_progress(tmp_path, done=4, total=9)
        marker = tmp_path / PipelineJob._MARKER_FILENAME
        job = PipelineJob(
            material_id="Si", profile_id="P2", scf_in_basename="scf.in", nproc=2,
        )
        job.work_dir = tmp_path
        job.status = "error"
        job.user_work_dir = str(tmp_path)
        marker.write_text(json.dumps(job.to_dict()), encoding="utf-8")
        if in_registry:
            PipelineJob._REGISTRY[job.job_id] = job
        return job

    def test_options_job_inconnu_404(self):
        r = self._client().get("/api/pipeline/jobs/inexistant/resume_thermo_pw/options")
        assert r.status_code == 404

    def test_options_from_memory(self, tmp_path: Path):
        job = self._make_job(tmp_path)
        try:
            r = self._client().get(
                f"/api/pipeline/jobs/{job.job_id}/resume_thermo_pw/options"
            )
            assert r.status_code == 200
            payload = r.get_json()
            assert payload["phonon_prereqs_ok"] is True
            assert payload["targets"][0]["target_id"] == "thermo_main"
            assert payload["targets"][0]["qha_done"] == 4
        finally:
            from pipeline import PipelineJob
            PipelineJob._REGISTRY.pop(job.job_id, None)

    def test_post_resume_rehydrates_from_disk(self, tmp_path: Path, monkeypatch):
        from pipeline import PipelineJob

        started: list[str] = []

        def _fake_start(self):
            started.append(self.job_id)

        monkeypatch.setattr(PipelineJob, "start", _fake_start)
        job = self._make_job(tmp_path, in_registry=False)
        try:
            r = self._client().post(
                f"/api/pipeline/jobs/{job.job_id}/resume_thermo_pw",
                json={"target": "thermo_main"},
            )
            assert r.status_code == 200
            payload = r.get_json()
            assert payload["ok"] is True
            assert payload["target"] == "thermo_main"
            live = PipelineJob._REGISTRY.get(job.job_id)
            assert live is not None
            assert live._resume_scope == "thermo_main"
            assert live.status == "running"
            assert job.job_id in started
        finally:
            PipelineJob._REGISTRY.pop(job.job_id, None)

    def test_post_resume_with_lsolve(self, tmp_path: Path, monkeypatch):
        from pipeline import PipelineJob

        captured: list[tuple[str, dict]] = []

        def _fake_request(self, target="thermo_main", *, thermo_overrides=None):
            captured.append((target, dict(thermo_overrides or {})))
            self.status = "running"

        monkeypatch.setattr(PipelineJob, "request_resume_thermo_pw", _fake_request)
        job = self._make_job(tmp_path, in_registry=False)
        try:
            r = self._client().post(
                f"/api/pipeline/jobs/{job.job_id}/resume_thermo_pw",
                json={
                    "target": "thermo_main",
                    "lsolve": 1,
                    "deltat": 100,
                    "therm_mode": "dos",
                },
            )
            assert r.status_code == 200
            payload = r.get_json()
            assert payload["thermo_overrides"]["lsolve"] == 1
            assert payload["thermo_overrides"]["deltat"] == 100.0
            assert payload["thermo_overrides"]["ltherm_dos"] is True
            assert captured[0][1]["lsolve"] == 1
        finally:
            PipelineJob._REGISTRY.pop(job.job_id, None)

    def test_post_resume_therm_mode_freq(self, tmp_path: Path, monkeypatch):
        from pipeline import PipelineJob

        captured: list[dict] = []

        def _fake_request(self, target="thermo_main", *, thermo_overrides=None):
            captured.append(dict(thermo_overrides or {}))
            self.status = "running"

        monkeypatch.setattr(PipelineJob, "request_resume_thermo_pw", _fake_request)
        job = self._make_job(tmp_path, in_registry=False)
        try:
            r = self._client().post(
                f"/api/pipeline/jobs/{job.job_id}/resume_thermo_pw",
                json={"target": "thermo_main", "therm_mode": "freq"},
            )
            assert r.status_code == 200
            assert captured[0]["ltherm_freq"] is True
            assert captured[0]["ltherm_dos"] is False
        finally:
            PipelineJob._REGISTRY.pop(job.job_id, None)

    def test_post_resume_invalid_lsolve_400(self, tmp_path: Path):
        job = self._make_job(tmp_path, in_registry=False)
        try:
            r = self._client().post(
                f"/api/pipeline/jobs/{job.job_id}/resume_thermo_pw",
                json={"target": "thermo_main", "lsolve": 9},
            )
            assert r.status_code == 400
        finally:
            from pipeline import PipelineJob
            PipelineJob._REGISTRY.pop(job.job_id, None)


class TestApiQhaPrereq:
    def test_ph_life_requires_qha_phonons(self):
        from api_server import _tpw_what_requires_qha_phonon_prereq

        assert _tpw_what_requires_qha_phonon_prereq("ph_life") is True
        assert _tpw_what_requires_qha_phonon_prereq("elastic_constants_geo") is True
        assert _tpw_what_requires_qha_phonon_prereq("dielectric") is False

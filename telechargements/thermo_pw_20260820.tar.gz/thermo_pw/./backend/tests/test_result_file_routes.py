"""Tests smoke pour les routes Flask ``/files`` (JSON) et ``/result_file`` (binary/text).

Juillet 2026 — couvre :
  * Listing par extension (kinds + counts + total).
  * Servir PNG/PDF inline (MIME + Content-Disposition: inline).
  * Servir .gnu/.dat/.in/.out en text/plain avec disposition inline par défaut.
  * Mode ``?tail=N`` (fichiers texte uniquement).
  * Mode ``?inline=0`` (force ``Content-Disposition: attachment``).
  * Taille > ``max_size`` rejeté en mode complet (400), accepté en mode tail.
  * Path traversal (``../../etc/passwd``) → 403.
  * Path absolu (``/etc/passwd``) → hors work_dir → 404 (fichier absent) ou 403.
  * Path vide ou work_dir absent → 400 / 503.
  * Job inconnu → 404 ou 503.

Le conftest mutualise ``tmp_work_root`` (work_root temporaire sous tmp_path),
``client`` (Flask test_client) et ``sample_run_setup`` (run + marker + fichiers).
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest


JOB_TEST = "smoke01234567"  # 12-char hex stable (cf. conventions api_server)


# ---------------------------------------------------------------------------
# /files
# ---------------------------------------------------------------------------

def test_files_endpoint_returns_kinds_counts_and_total(
    client, sample_run_setup,
):
    run_dir, job_id = sample_run_setup
    resp = client.get(f"/api/pipeline/runs/{job_id}/files")
    assert resp.status_code == 200, resp.data[:200].decode(errors="replace")
    body = resp.get_json()
    assert body["job_id"] == job_id
    assert body["work_dir"] == str(run_dir.resolve())
    assert "kinds" in body
    # Au moins : PNG, PDF, gs, dat, in, out — tous peuplés par sample_run_setup.
    kinds = body["kinds"]
    assert "eos_ev.png" in kinds["png"]
    assert "eosc.pdf" in kinds["pdf"]
    assert "plot_eos.gnu" in kinds["gs"]
    assert any(p.endswith(".dat") for p in kinds["dat"])
    assert "scf.in" in kinds["in"]
    assert "pw.out" in kinds["out"]
    # Counts + total cohérents.
    counts = body["counts"]
    total = body["total"]
    assert total == sum(counts.values())
    assert counts["png"] >= 1
    assert counts["pdf"] >= 1
    assert counts["gs"] >= 1
    assert counts["dat"] >= 2
    assert counts["in"] >= 1
    assert counts["out"] >= 1


def test_files_endpoint_404_for_unknown_job(client, sample_run_setup):
    # sample_run_setup crée un job valide ; on demande un job totalement inconnu.
    _run, _known = sample_run_setup
    resp = client.get("/api/pipeline/runs/zzz-unknown-id-zzz/files")
    assert resp.status_code == 404
    body = resp.get_json()
    assert "error" in body
    assert "job_id" in body


def test_files_endpoint_cors_preflight(client, sample_run_setup):
    """OPTIONS renvoie 204 (pré-vol CORS)."""
    _, job_id = sample_run_setup
    resp = client.options(f"/api/pipeline/runs/{job_id}/files")
    assert resp.status_code == 204


# ---------------------------------------------------------------------------
# /result_file — happy paths
# ---------------------------------------------------------------------------

def test_result_file_serves_png_image_with_inline_disposition(
    client, sample_run_setup,
):
    _, job_id = sample_run_setup
    resp = client.get(
        f"/api/pipeline/runs/{job_id}/result_file"
        f"?path=eos_ev.png&inline=1"
    )
    assert resp.status_code == 200, resp.data[:200].decode(errors="replace")
    # MIME
    assert resp.mimetype == "image/png"
    # Content-Disposition : inline + filename
    cd = resp.headers.get("Content-Disposition", "")
    assert cd.startswith("inline"), f"expected inline, got: {cd!r}"
    assert "filename=" in cd
    assert ".png".lower() in cd.lower() or "eos_ev" in cd.lower()
    # Premier byte = signature PNG (0x89 P N G \r \n 0x1a \n)
    assert resp.data[:8] == b"\x89PNG\r\n\x1a\n"


def test_result_file_serves_pdf_with_application_pdf_mime(
    client, sample_run_setup,
):
    _, job_id = sample_run_setup
    resp = client.get(
        f"/api/pipeline/runs/{job_id}/result_file"
        f"?path=eosc.pdf&inline=1"
    )
    assert resp.status_code == 200
    assert resp.mimetype == "application/pdf"
    cd = resp.headers.get("Content-Disposition", "")
    assert cd.startswith("inline")
    # Signature PDF ``%PDF-``
    assert resp.data[:5] == b"%PDF-"


def test_result_file_serves_text_as_inline_text_plain(
    client, sample_run_setup,
):
    """Les .gnu/.dat/.in/.out doivent sortir en ``text/plain`` + ``inline`` (par défaut)."""
    _, job_id = sample_run_setup
    resp = client.get(
        f"/api/pipeline/runs/{job_id}/result_file?path=plot_eos.gnu"
    )
    assert resp.status_code == 200
    # MIME text/plain avec charset
    assert resp.mimetype.startswith("text/plain")
    cd = resp.headers.get("Content-Disposition", "")
    assert cd.startswith("inline"), f"default doit être inline, got: {cd!r}"
    # Le contenu du .gnu commence par ``set terminal``.
    assert b"set terminal" in resp.data


def test_result_file_attachment_disposition_when_inline0(
    client, sample_run_setup,
):
    _, job_id = sample_run_setup
    resp = client.get(
        f"/api/pipeline/runs/{job_id}/result_file"
        f"?path=plot_eos.gnu&inline=0"
    )
    assert resp.status_code == 200
    cd = resp.headers.get("Content-Disposition", "")
    assert cd.startswith("attachment"), f"expected attachment, got: {cd!r}"


def test_result_file_tail_returns_last_n_lines(client, sample_run_setup):
    """``?tail=N`` sur un .out : retourne les N dernières lignes via _tail_utf8_file."""
    _, job_id = sample_run_setup
    # On écrit un fichier .out plus long pour disposer de >2 lignes testables.
    # Note : sample_run_setup fournit ``pw.out`` court (3 lignes) ; on utilise
    # un paramètre tail=2 et on vérifie que la sortie contient bien les
    # dernières lignes.
    resp = client.get(
        f"/api/pipeline/runs/{job_id}/result_file?path=pw.out&tail=2"
    )
    assert resp.status_code == 200
    assert resp.mimetype.startswith("text/plain")
    assert resp.data.decode("utf-8").rstrip().endswith("Termination reached")


def test_result_file_tail_invalid_query_returns_400(client, sample_run_setup):
    _, job_id = sample_run_setup
    resp = client.get(
        f"/api/pipeline/runs/{job_id}/result_file?path=pw.out&tail=abc"
    )
    assert resp.status_code == 400
    assert "error" in resp.get_json()


# ---------------------------------------------------------------------------
# /result_file — sécurité & erreurs
# ---------------------------------------------------------------------------

def test_result_file_path_traversal_dotdot_dotdot_blocked(client, sample_run_setup):
    """Path-traversal classique ``../../etc/passwd`` → 403 (validation explicite)."""
    _, job_id = sample_run_setup
    resp = client.get(
        f"/api/pipeline/runs/{job_id}/result_file"
        f"?path=../../etc/passwd&inline=1"
    )
    assert resp.status_code == 403, (
        f"path traversal doit retourner 403, got {resp.status_code} body={resp.data[:200]!r}"
    )
    body = resp.get_json()
    assert "error" in body


def test_result_file_path_traversal_nested_dotdot_blocked(client, sample_run_setup):
    """``foo/../../../etc/passwd`` doit être rejeté (split détecte ``..``)."""
    _, job_id = sample_run_setup
    resp = client.get(
        f"/api/pipeline/runs/{job_id}/result_file"
        f"?path=foo/../../../etc/passwd"
    )
    assert resp.status_code == 403


def test_result_file_absolute_etc_path_returns_404(client, sample_run_setup):
    """``/etc/passwd`` normalisé (rel.lstrip('/') retenu) ; le fichier n'existe
    PAS dans work_dir → 404 (et pas 403, car la chaîne de validation ne voit
    pas de segment ``..``). On vérifie qu'aucun octet du fichier réel n'est
    exposé même en cas de 404 explicite."""
    _, job_id = sample_run_setup
    resp = client.get(
        f"/api/pipeline/runs/{job_id}/result_file?path=etc/passwd"
    )
    # 404 attendu (chemin intra work_dir, mais fichier absent) — pour
    # s'assurer que ``b'root:'`` n'est PAS servi, on vérifie au minimum 4xx.
    assert resp.status_code in (403, 404)
    # Quel que soit le code, aucune fuite d'info réelle.
    assert b"root:" not in resp.data


def test_result_file_missing_file_returns_404(client, sample_run_setup):
    _, job_id = sample_run_setup
    resp = client.get(
        f"/api/pipeline/runs/{job_id}/result_file?path=does_not_exist.dat"
    )
    assert resp.status_code == 404, resp.data[:200].decode(errors="replace")


def test_result_file_missing_path_query_returns_400(client, sample_run_setup):
    _, job_id = sample_run_setup
    resp = client.get(f"/api/pipeline/runs/{job_id}/result_file")
    assert resp.status_code == 400
    assert "error" in resp.get_json()


def test_result_file_max_size_blocks_huge_full_read(client, sample_run_setup):
    """Lecture intégrale d'un fichier > max_size doit retourner 400."""
    _, job_id = sample_run_setup
    # ``bigscf.in`` ~300 ko ; on fixe max_size=1000 pour forcer le rejet.
    resp = client.get(
        f"/api/pipeline/runs/{job_id}/result_file"
        f"?path=bigscf.in&max_size=1000"
    )
    assert resp.status_code == 400
    body = resp.get_json()
    assert "max_size" in str(body).lower() or "volumineux" in str(body).lower()


def test_result_file_max_size_allows_tail_for_huge_file(client, sample_run_setup):
    """Le couple ``?tail=N&max_size=1`` doit fonctionner : tail bypass le cap."""
    _, job_id = sample_run_setup
    resp = client.get(
        f"/api/pipeline/runs/{job_id}/result_file"
        f"?path=bigscf.in&tail=1&max_size=1"
    )
    assert resp.status_code == 200
    assert resp.mimetype.startswith("text/plain")


def test_result_file_unknown_job_returns_404_or_503(client, sample_run_setup):
    _run, _known = sample_run_setup
    resp = client.get(
        "/api/pipeline/runs/zzz-unknown-id-zzz/result_file?path=foo"
    )
    assert resp.status_code in (404, 503)


def test_result_file_symlink_outside_workdir_returns_404(
    client, sample_run_setup,
):
    """Le symlink ``escape_to_etc -> /etc/passwd`` ne doit PAS exposer le fichier.

    Note : ici on NE suit PAS le symlink via ``send_file`` (qui suit, mais le contenu
    servi est /etc/passwd, ce qui n'est pas exploitable). On documente le test :
    la route retourne 404 car ``_eos_run_child_path`` rejette en amont (ou 403
    si le path ne contient pas ``..`` mais sort de work_dir). Au minimum on
    s'assure que le contenu réel du fichier protégé n'est PAS renvoyé sur
    200 (préserverait root:x:0:0:root:/root:/bin/bash dans le body).
    """
    _, job_id = sample_run_setup
    resp = client.get(
        f"/api/pipeline/runs/{job_id}/result_file?path=escape_to_etc"
    )
    # Si pour une raison quelconque le serveur suit le symlink, on tolère
    # 200 MAIS on s'assure que le body ne contient PAS la signature réelle
    # du fichier protégé.
    if resp.status_code == 200:
        assert b"root:x:0:0" not in resp.data, (
            "FAIL: symlink résolu — fuite d'info !"
        )
    else:
        assert resp.status_code in (403, 404)


def test_result_file_cors_preflight(client, sample_run_setup):
    _, job_id = sample_run_setup
    resp = client.options(
        f"/api/pipeline/runs/{job_id}/result_file?path=eos_ev.png"
    )
    assert resp.status_code == 204


def test_result_file_method_not_get_returns_405(client, sample_run_setup):
    _, job_id = sample_run_setup
    # POST doit être refusé (route GET-only, hormis OPTIONS).
    resp = client.post(
        f"/api/pipeline/runs/{job_id}/result_file?path=eos_ev.png"
    )
    # 405 ou 503 selon routage : on tolère 4xx, jamais 2xx.
    assert resp.status_code not in (200, 201, 202, 204)
    assert resp.status_code in (404, 405, 500)


# ---------------------------------------------------------------------------
# Cohérence MW
# ---------------------------------------------------------------------------

def test_files_total_matches_actual_files_on_disk(client, sample_run_setup):
    """Vérifie que ``total`` renvoyé par /files correspond au nombre de fichiers
    matchant les extensions du scan (kin vs réalité disque)."""
    from factsheet import _section_artifacts
    run_dir, job_id = sample_run_setup
    resp = client.get(f"/api/pipeline/runs/{job_id}/files")
    assert resp.status_code == 200
    body = resp.get_json()
    rows = _section_artifacts({}, run_dir)
    actual_count = len(rows)
    # Le backend renvoie son propre total via _section_artifacts ; doit matcher.
    assert body["total"] == actual_count, (
        f"Mismatch total API ({body['total']}) vs factsheet _section_artifacts "
        f"({actual_count}). run_dir={run_dir}"
    )


# Smoke test final : régression cover sur les 2 routes fonctionnent ensemble.
def test_files_then_result_file_smoke_workflow(client, sample_run_setup):
    """End-to-end : (1) lister via /files ; (2) récupérer un PNG cité via
    /result_file ; (3) vérifier Content-Type + Content-Disposition."""
    _, job_id = sample_run_setup
    r1 = client.get(f"/api/pipeline/runs/{job_id}/files")
    body = r1.get_json()
    png_files = body["kinds"]["png"]
    assert png_files, "expected at least one PNG from sample_run_setup"
    target = png_files[0]  # "eos_ev.png" canonique
    # Chemin avec sous-dossier possible : on nettoie si l'API a renvoyé
    # ``1_eos_volumes/eos_ev.png`` on adapte.
    r2 = client.get(
        f"/api/pipeline/runs/{job_id}/result_file?path={target}&inline=1"
    )
    assert r2.status_code == 200
    assert r2.mimetype == "image/png"
    assert r2.data[:8] == b"\x89PNG\r\n\x1a\n"  # signature PNG

"""Tests du diagnostic de reprise.

Les cas négatifs comptent autant que les positifs : un diagnostic qui crie au
loup ferait refaire des heures de DFPT saines, ce qui est aussi coûteux que la
reprise aveugle qu'il cherche à éviter.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from resume_diagnosis import (
    BENIGN,
    BLOCKING,
    FATAL,
    anharmonic_output_is_degenerate,
    diagnose_run,
    find_identical_dynmats,
    group_dynmats_by_qpoint,
    ph_control_pins_outdir,
)

PH_CONTROL_AVEC_OUTDIR = """thermo_pw_ph

&inputph
  tr2_ph = 1.0d-14
  prefix = 'scf_eq'
  outdir = './out_scf_eq/'
  ldisp = .true.
/
"""

PH_CONTROL_CORRIGE = """thermo_pw_ph

&inputph
  tr2_ph = 1.0d-14
  prefix = 'scf_eq'
  ldisp = .true.
/
"""

QPOINT_LIST = "   4   4   4\n   8\n   0.0   0.0   0.0\n"

ENTETE_ANHAR = (
    "# beta is the volume thermal expansion\n"
    "#   T (K)         V(T) (a.u.)^3          F (T) (Ry)       beta x 10^6 (1/K)\n"
)


def _ecrire_dynmats(work_dir: Path, *, geoms: int, contenus: dict[int, str]) -> None:
    """Écrit ``dynamical_matrices/ph_dyn.g<N>.<iq>`` pour iq=0 (liste q) et iq=1."""
    d = work_dir / "dynamical_matrices"
    d.mkdir(parents=True, exist_ok=True)
    for g in range(1, geoms + 1):
        # La liste des points q est toujours identique entre géométries.
        (d / f"ph_dyn.g{g}.0").write_text(QPOINT_LIST, encoding="utf-8")
        (d / f"ph_dyn.g{g}.1").write_text(contenus[g], encoding="utf-8")


def _ecrire_anhar(work_dir: Path, volumes: list[float], betas: list[float]) -> None:
    d = work_dir / "anhar_files"
    d.mkdir(parents=True, exist_ok=True)
    lignes = [ENTETE_ANHAR.rstrip("\n")]
    for i, (v, b) in enumerate(zip(volumes, betas)):
        t = 50.0 * (i + 1)
        lignes.append(f" {t:.5E}    {v:.13E}   -0.1576E+02   {b:.8E}")
    (d / "output_anhar.dat").write_text("\n".join(lignes) + "\n", encoding="utf-8")


class TestMatricesIdentiques:
    def test_geometries_identiques_detectees(self, tmp_path):
        _ecrire_dynmats(tmp_path, geoms=4, contenus={g: "freq 140.328457\n" for g in range(1, 5)})
        geoms, iq = find_identical_dynmats(tmp_path)
        assert geoms == [1, 2, 3, 4]
        assert iq == "1"

    def test_geometries_distinctes_ne_declenchent_rien(self, tmp_path):
        _ecrire_dynmats(
            tmp_path,
            geoms=4,
            contenus={g: f"freq {140.0 + 3.0 * g:.6f}\n" for g in range(1, 5)},
        )
        assert find_identical_dynmats(tmp_path) == ([], "")

    def test_liste_des_points_q_exclue(self, tmp_path):
        """``.0`` est la grille q en unités de 2π/a : identique par construction."""
        _ecrire_dynmats(
            tmp_path,
            geoms=3,
            contenus={g: f"freq {140.0 + g:.6f}\n" for g in range(1, 4)},
        )
        assert 0 not in {int(q) for q in group_dynmats_by_qpoint(tmp_path)}
        # Les .0 sont pourtant bien identiques : sans exclusion, faux positif.
        d = tmp_path / "dynamical_matrices"
        assert (d / "ph_dyn.g1.0").read_text() == (d / "ph_dyn.g3.0").read_text()
        assert find_identical_dynmats(tmp_path) == ([], "")

    def test_doublon_partiel_detecte(self, tmp_path):
        _ecrire_dynmats(
            tmp_path,
            geoms=4,
            contenus={1: "freq 141\n", 2: "freq 142\n", 3: "freq 999\n", 4: "freq 999\n"},
        )
        geoms, _ = find_identical_dynmats(tmp_path)
        assert geoms == [3, 4]

    def test_une_seule_geometrie_ne_declenche_rien(self, tmp_path):
        _ecrire_dynmats(tmp_path, geoms=1, contenus={1: "freq 140\n"})
        assert find_identical_dynmats(tmp_path) == ([], "")

    def test_dossier_absent(self, tmp_path):
        assert find_identical_dynmats(tmp_path) == ([], "")
        assert group_dynmats_by_qpoint(tmp_path) == {}


class TestPhControlOutdir:
    def test_outdir_epingle_detecte(self, tmp_path):
        (tmp_path / "ph_control").write_text(PH_CONTROL_AVEC_OUTDIR, encoding="utf-8")
        assert ph_control_pins_outdir(tmp_path) is True

    def test_ph_control_corrige(self, tmp_path):
        (tmp_path / "ph_control").write_text(PH_CONTROL_CORRIGE, encoding="utf-8")
        assert ph_control_pins_outdir(tmp_path) is False

    def test_outdir_en_commentaire_ignore(self, tmp_path):
        texte = "! même prefix/outdir que pw.in\nthermo_pw_ph\n\n&inputph\n  prefix = 'x'\n/\n"
        (tmp_path / "ph_control").write_text(texte, encoding="utf-8")
        assert ph_control_pins_outdir(tmp_path) is False

    def test_absent(self, tmp_path):
        assert ph_control_pins_outdir(tmp_path) is False


class TestQhaDegenere:
    def test_volume_constant_detecte(self, tmp_path):
        v = 277.2611575668
        _ecrire_anhar(
            tmp_path,
            volumes=[v + i * 1e-12 for i in range(19)],
            betas=[3.0e-8] * 19,
        )
        degenere, preuve = anharmonic_output_is_degenerate(tmp_path)
        assert degenere is True
        assert "V(T)" in preuve

    def test_dilatation_realiste_acceptee(self, tmp_path):
        """Silicium : environ +0,3 % de volume entre 50 et 1000 K."""
        _ecrire_anhar(
            tmp_path,
            volumes=[277.0 * (1.0 + 3.0e-5 * i) for i in range(19)],
            betas=[7.7e-6] * 19,
        )
        assert anharmonic_output_is_degenerate(tmp_path)[0] is False

    def test_beta_petit_mais_volume_qui_bouge_accepte(self, tmp_path):
        """Un β faible ne suffit pas à condamner : seul V(T) figé est probant."""
        _ecrire_anhar(
            tmp_path,
            volumes=[277.0 * (1.0 + 1.0e-5 * i) for i in range(19)],
            betas=[1.0e-9] * 19,
        )
        assert anharmonic_output_is_degenerate(tmp_path)[0] is False

    def test_trop_peu_de_points(self, tmp_path):
        _ecrire_anhar(tmp_path, volumes=[277.0, 277.0], betas=[0.0, 0.0])
        assert anharmonic_output_is_degenerate(tmp_path)[0] is False

    def test_fichier_absent(self, tmp_path):
        assert anharmonic_output_is_degenerate(tmp_path) == (False, "")


class TestVerdictGlobal:
    def test_run_sain_interrompu_par_signal_est_reprenable(self, tmp_path):
        _ecrire_dynmats(
            tmp_path,
            geoms=3,
            contenus={g: f"freq {140.0 + g:.6f}\n" for g in range(1, 4)},
        )
        (tmp_path / "ph_control").write_text(PH_CONTROL_CORRIGE, encoding="utf-8")
        d = diagnose_run(
            tmp_path,
            status="interrupted",
            logs="forrtl: error (78): process killed (SIGTERM)\n",
        )
        assert d.severity == BENIGN
        assert d.resume_is_safe is True
        assert [f.finding_id for f in d.findings] == ["killed_by_signal"]
        recommandee = next(a for a in d.actions if a.recommended)
        assert recommandee.kind == "resume"

    def test_matrices_identiques_bloquent_la_reprise(self, tmp_path):
        _ecrire_dynmats(tmp_path, geoms=9, contenus={g: "freq 140.328457\n" for g in range(1, 10)})
        (tmp_path / "ph_control").write_text(PH_CONTROL_AVEC_OUTDIR, encoding="utf-8")
        d = diagnose_run(tmp_path, status="error", logs="Error in routine linsolvms (7)\n")
        assert d.severity == FATAL
        assert d.resume_is_safe is False
        ids = {f.finding_id for f in d.findings}
        assert "identical_dynmats" in ids
        # La cause est nommée, pas seulement le symptôme.
        cause = next(f for f in d.findings if f.finding_id == "identical_dynmats")
        assert cause.known_cause == "ph_control_outdir"
        # L'abandon DGELS n'est pas signalé séparément : c'en est la conséquence.
        assert "least_squares_abort" not in ids
        # Aucune réparation automatique n'est proposée : le dossier neuf est la
        # seule voie recommandée quand des résultats sont invalides.
        recommandee = next(a for a in d.actions if a.recommended)
        assert recommandee.kind == "fresh"
        # « Reprendre quand même » reste offert, mais jamais recommandé.
        quand_meme = next(a for a in d.actions if a.action_id == "resume_anyway")
        assert quand_meme.recommended is False
        assert len([a for a in d.actions if a.recommended]) == 1

    def test_outdir_epingle_seul_est_bloquant_pas_fatal(self, tmp_path):
        """Détecté avant que les phonons ne tournent : rien n'est encore perdu."""
        (tmp_path / "ph_control").write_text(PH_CONTROL_AVEC_OUTDIR, encoding="utf-8")
        d = diagnose_run(tmp_path, status="error", logs="")
        assert d.severity == BLOCKING
        assert d.resume_is_safe is False
        assert [f.finding_id for f in d.findings] == ["ph_control_outdir"]

    def test_dgels_seul_est_bloquant(self, tmp_path):
        _ecrire_dynmats(
            tmp_path,
            geoms=3,
            contenus={g: f"freq {140.0 + g:.6f}\n" for g in range(1, 4)},
        )
        d = diagnose_run(tmp_path, status="error", logs="Intel oneMKL ERROR ... DGELS\n")
        assert d.severity == BLOCKING
        ids = {f.finding_id for f in d.findings}
        assert "least_squares_abort" in ids

    def test_dgelss_detecte_comme_dgels(self, tmp_path):
        _ecrire_dynmats(
            tmp_path,
            geoms=3,
            contenus={g: f"freq {140.0 + g:.6f}\n" for g in range(1, 4)},
        )
        d = diagnose_run(
            tmp_path,
            status="error",
            logs="Parameter 6 was incorrect on entry to DGELSS\nlinsolvsvd\n",
        )
        assert "least_squares_abort" in {f.finding_id for f in d.findings}

    def test_restart_tronque_est_bloquant(self, tmp_path):
        d = diagnose_run(
            tmp_path,
            status="error",
            logs="forrtl: error (24): end-of-file\nunit 42 file e_work_part1\n",
        )
        assert d.severity == BLOCKING
        assert "stale_restart_dir" in {f.finding_id for f in d.findings}

    def test_run_sans_anomalie_connue(self, tmp_path):
        d = diagnose_run(tmp_path, status="interrupted", logs="rien de notable\n")
        assert d.severity is None
        assert d.resume_is_safe is True
        assert d.findings == []
        assert next(a for a in d.actions if a.recommended).kind == "resume"

    def test_dossier_inexistant(self, tmp_path):
        d = diagnose_run(tmp_path / "absent", status="error")
        assert d.findings == [] and d.actions == []

    def test_serialisation_complete(self, tmp_path):
        _ecrire_dynmats(tmp_path, geoms=2, contenus={1: "x\n", 2: "x\n"})
        payload = diagnose_run(tmp_path, status="error").to_dict()
        assert set(payload) == {
            "severity", "resume_is_safe", "headline", "findings", "actions",
        }
        assert payload["severity"] == FATAL
        for f in payload["findings"]:
            assert {"finding_id", "severity", "title", "explanation"} <= set(f)
        for a in payload["actions"]:
            assert {"action_id", "label", "kind", "recommended"} <= set(a)


class TestRoute:
    """La route ne doit jamais empêcher une reprise légitime."""

    @staticmethod
    def _client():
        from api_server import app
        return app.test_client()

    def test_job_inconnu_renvoie_404(self):
        r = self._client().get("/api/pipeline/jobs/inexistant_zzz/resume_diagnosis")
        assert r.status_code == 404
        assert r.get_json()["error"] == "job_inconnu"

    def test_diagnostic_sur_job_en_memoire(self, tmp_path):
        from pipeline import PipelineJob

        _ecrire_dynmats(tmp_path, geoms=3, contenus={g: "identique\n" for g in range(1, 4)})
        job = PipelineJob(
            material_id="Si", profile_id="P2", scf_in_basename="scf.in", nproc=2,
        )
        job.work_dir = str(tmp_path)
        job.status = "error"
        PipelineJob._REGISTRY[job.job_id] = job
        try:
            r = self._client().get(f"/api/pipeline/jobs/{job.job_id}/resume_diagnosis")
            assert r.status_code == 200
            payload = r.get_json()
            assert payload["status"] == "error"
            diag = payload["diagnosis"]
            assert diag["severity"] == FATAL
            assert diag["resume_is_safe"] is False
            assert "identical_dynmats" in {f["finding_id"] for f in diag["findings"]}
        finally:
            PipelineJob._REGISTRY.pop(job.job_id, None)

    def test_work_dir_absent_reste_en_200(self):
        """Un dossier disparu n'est pas une erreur de diagnostic : l'UI doit décider."""
        from pipeline import PipelineJob

        job = PipelineJob(
            material_id="Si", profile_id="P2", scf_in_basename="scf.in", nproc=2,
        )
        job.work_dir = "/chemin/qui/n/existe/pas"
        job.status = "interrupted"
        PipelineJob._REGISTRY[job.job_id] = job
        try:
            r = self._client().get(f"/api/pipeline/jobs/{job.job_id}/resume_diagnosis")
            assert r.status_code == 200
            payload = r.get_json()
            assert payload["diagnosis"] is None
            assert payload["error"] == "work_dir_absent"
        finally:
            PipelineJob._REGISTRY.pop(job.job_id, None)


class TestSurRunReel:
    """Épreuve sur le run P2 qui a réellement échoué, s'il est encore présent."""

    CHEMIN = Path("/home/hiadsi/thermo_pw/work/Si/pipeline_P2_1787037531_0e561c")

    def test_le_run_fautif_est_diagnostique(self):
        if not self.CHEMIN.is_dir():
            pytest.skip("run de référence absent du disque")
        d = diagnose_run(self.CHEMIN, status="error")
        assert d.severity == FATAL
        assert d.resume_is_safe is False
        ids = {f.finding_id for f in d.findings}
        assert "identical_dynmats" in ids
        assert "degenerate_qha" in ids

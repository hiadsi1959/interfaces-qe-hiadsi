"""
test_p1_chain_continuity.py
============================

Verrouille la chaîne « P1 continue bien la série de calculs après le SCF ».

P1 = « Mécanique 0 K » — profil défini dans ``backend/pipeline.py``. Série canonique::

    SCF équilibre
      → phonons DFPT (ph.x → q2r.x → matdyn.x — stabilité dynamique)
      → what='scf_elastic_constants' (thermo_pw.x, C_ij @ T=0 K, déformations de Voigt)
      → run_electronic_properties   (NSCF + dos.x + bands.x → fermi / gap / n_bands)

Les tests ci-dessous verrouillent respectivement :

A. ``TestP1ProfileFlags`` : flags du profil P1 qui pilotent la chaîne
   (properties_enabled=True, needs_eos=False, needs_phonons=True, et
   intention elastic exprimée soit via ``what``, soit via ``description``).

B. ``TestP1MetricsIncludeElectronicProperties`` : les clés
   ``properties.fermi_eV``, ``properties.band_gap_eV`` et ``properties.n_bands``
   sont promises dans ``expected_results.metrics`` (contrat exposé à l'UI).

C. ``TestPipelineExecuteCallSequence`` : le corps de ``pipeline._execute``
   référence bien, dans l'ordre, ``_run_scf_eq`` (branche 'no EOS' P1),
   ``_run_thermo_pw`` (qui pilote what='elastic' P1) puis
   ``_run_electronic_properties``. L'ordre canonique est respecté et
   l'appel électronique est gardé par le flag ``properties_enabled``.

Si l'un de ces tests casse après une refonte, c'est que quelqu'un a :

*  désactivé par mégarde la chaîne propriétés électroniques sur P1 ;
*  déplacé ``_run_electronic_properties`` avant ``_run_thermo_pw`` (casserait
   l'invariant « pas de DOS avant C_ij » et la Préséance historique P1) ;
*  accidentellement renommé ``_run_electronic_properties`` (le test
   ``test_pipeline_runs_electronic_properties_symbol`` casse) ;
*  supprimé une clé ``properties.*`` de ``expected_results`` (l'UI ne saura
   plus afficher E_Fermi / gap / n_bands).

Note d'historique (juin 2026) : ce test remplace un smoke-run vivant qui
prenait ~20 minutes (6+ déformations elastic + chaîne NSCF complète) et qui
était trop lent pour la CI. Le contrat des flags + l'ordre d'appel couvrent
strictement la même propriété que le smoke-run.
"""

from __future__ import annotations

import inspect
from pathlib import Path

import pytest

# backend/ doit être sur sys.path (conftest.py s'en charge).


# --- Helpers ----------------------------------------------------------------

def _load_p1_profile():
    """Charge le dict du profil P1 depuis ``backend/pipeline.py``."""
    from pipeline import PROFILES  # noqa: WPS433 (import local)
    assert "P1" in PROFILES, f"P1 absent de PROFILES (clés : {sorted(PROFILES)})"
    return PROFILES["P1"]


def _intent_elastic(p1: dict) -> bool:
    """Vrai si l'intention ``elastic`` est portée soit par ``what``, soit par ``description``.

    juin 2026 refonte — thermo_pw 7.x n'accepte PLUS ``what='elastic'`` (provoque
    ``Error in routine thermo_summary (1): what not programmed`` et MPI_Abort).
    Le canonique T=0K sur P1 est ``scf_elastic_constants``. On accepte aussi
    ``what=None`` (refonte qui pilote via la description sémantique).
    """
    what = p1.get("what") or p1.get("what_qe")
    desc = p1.get("description", "") or ""
    if what == "scf_elastic_constants":
        return True
    # Sémantique : présence de ``what='scf_elastic_constants'`` ou du mot-clé
    # ``elastic`` dans un champ narratif adjacent (description, steps).
    needle_options = (
        "what='scf_elastic_constants'", "what = 'scf_elastic_constants'",
        "what=\"scf_elastic_constants\"",
    )
    if any(opt in desc for opt in needle_options):
        return True
    # Description narrative : mot-clé ``elastic`` suffit (P1 = T=0K → C_ij).
    return "elastic" in desc


# --- A. Profil P1 -----------------------------------------------------------

class TestP1ProfileFlags:
    """Le profil P1 doit piloter SCF→elastic→properties proprement."""

    def test_p1_properties_enabled_is_true(self):
        """P1 doit avoir ``properties_enabled=True`` — autorise la chaîne NSCF+DOS+bandes."""
        p1 = _load_p1_profile()
        assert p1.get("properties_enabled") is True, (
            f"properties_enabled doit valoir True sur P1 ; actuellement : "
            f"{p1.get('properties_enabled')!r}. Si tu désactives cela, le "
            f"rapport final n'aura plus E_Fermi / gap / n_bands."
        )

    def test_p1_skips_eos_but_does_phonons(self):
        """P1 = pas de grille EOS mais exécute la chaîne phonon (stabilité dynamique)."""
        p1 = _load_p1_profile()
        assert p1.get("needs_eos") is False, "P1 ne doit pas faire d'EOS"
        assert p1.get("needs_phonons") is True, "P1 doit faire les phonons (stabilité dynamique + dispersions)"

    def test_p1_expresses_elastic_intent(self):
        """L'intention ``elastic`` DOIT être portée par ``what=scf_elastic_constants``.

        juin 2026 fix — ``what='elastic'`` (legacy) est REJETÉ par thermo_pw 7.x
        avec ``what not programmed`` → MPI_Abort(1). On exige donc le canonique
        thermo_pw 7.x. Le safety net dans ``run_thermo_pw_mpi`` rattrape les
        anciens ``pipeline_api_job_state.json`` au prochain run, mais un profil
        neuf qui ré-émet ``elastic`` casserait tous les nouveaux jobs.
        """
        p1 = _load_p1_profile()
        assert _intent_elastic(p1), (
            "Le profil P1 n'exprime aucune intention 'elastic' via "
            "what='scf_elastic_constants' — C_ij @T=0 K ne sera pas calculé."
        )

    def test_p1_does_not_use_legacy_elastic_what(self):
        """Verrouille le bug de juin 2026 : ``what='elastic'`` n'est PLUS autorisé en P1.

        thermo_pw 7.x rejette ``elastic`` avec ``thermo_summary: what not programmed``.
        Symptôme runtime observé (cf. work/Si/pipeline_P1_1782749535_345ee1/thermo_pw_run.out) :
        ``Abort(1) on node 1 (rank 1 in comm 0)``.

        NB : on utilise un regex avec ``\b`` word-boundary pour eviter les faux
        positifs sur les aliases legitimes (``what='elastic_constants0'``,
        ``what='elastic_constants_geo'``, etc.) — une comparaison substring
        ``in`` aurait péte sur ces cas-là.
        """
        import re as _re
        p1 = _load_p1_profile()
        # 1. ``what_qe`` (canonique) doit être ``scf_elastic_constants``, jamais ``elastic``.
        assert p1.get("what_qe") != "elastic", (
            "P1.what_qe = 'elastic' réintroduit le bug Abort(1) de juin 2026. "
            "Utilisez 'scf_elastic_constants' (canonique thermo_pw 7.x)."
        )
        # 2. Regex boundary sur la ``description`` : on refuse la mention
        #    textuelle EXACTE ``what='elastic'`` (legacy) — mais on tolere les
        #    aliases avec suffixe (``elastic_constants``, ``elastic_constants0``, ...).
        bad_desc_match = _re.search(
            r"\bwhat\s*=\s*['\"]elastic['\"]\b",
            p1.get("description", "") or "",
        )
        assert bad_desc_match is None, (
            "P1.description mentionne un ``what='elastic'`` nu (legacy) : "
            f"{bad_desc_match.group(0)!r}. Remplacez par "
            "``what='scf_elastic_constants'`` (canonique thermo_pw 7.x)."
        )

    def test_legacy_elastic_with_tmin_routes_to_elastic_constants_geo(self):
        """Safety net retroworking : ``what='elastic'`` legacy + grille T → ``elastic_constants_geo``.

        Sans cette branche dans ``run_thermo_pw_mpi``, un ancien
        ``pipeline_api_job_state.json`` avec ``what='elastic'`` ET des
        ``tmin/tmax/deltat`` continuerait a etre envoye tel quel a
        thermo_pw.x 7.x (qui rejette les deux). On vérifie que le safety
        net réécrit bien vers ``elastic_constants_geo`` (canonique QHA
        grille T), via la ``normalize_thermo_opts`` + reproduction locale
        de la logique du safety net (qui s'applique juste apres).

        Note : sans appel MPI reel (intentionnel — pytest rapide), on
        isole la transformation ``opts['what']`` post-safety-net.
        """
        import importlib
        import sys
        if "phonon_chain_qe" in sys.modules:
            mod = sys.modules["phonon_chain_qe"]
        else:
            sys.path.insert(0, "/home/hiadsi/thermo_pw/backend")
            mod = importlib.import_module("phonon_chain_qe")
        # 1. Branche QHA : legacy ``elastic`` + tmin/tmax/deltat → ``elastic_constants_geo``.
        opts = {
            "what": "elastic",  # legacy
            "tmin": 0.0, "tmax": 1000.0, "deltat": 50.0,  # grille T
            "zasr": "simple", "fildyn": "ph_dyn",
            "ltherm_dos": True, "ltherm_freq": False,
        }
        opts_n = mod.normalize_thermo_opts(opts)
        what_api = (str(opts_n.get("what") or "").strip() or "mur_lc_t")
        w_api_l = what_api.lower().strip("'\"").strip()
        if w_api_l == "elastic":
            has_grid = any(k in opts_n for k in ("tmin", "tmax", "deltat"))
            canonical = "elastic_constants_geo" if has_grid else "scf_elastic_constants"
            opts_n["what"] = canonical
        assert opts_n["what"] == "elastic_constants_geo", (
            f"Safety net « elastic + grille T » aurait dû router vers "
            f"'elastic_constants_geo', got '{opts_n['what']}'"
        )
        # 2. Branche inverse : legacy ``elastic`` sans grille T → ``scf_elastic_constants``.
        opts2 = {
            "what": "elastic", "zasr": "simple", "fildyn": "ph_dyn",
            "ltherm_dos": False, "ltherm_freq": False,
        }
        opts2_n = mod.normalize_thermo_opts(opts2)
        what_api2 = (str(opts2_n.get("what") or "").strip() or "mur_lc_t")
        w_api_l2 = what_api2.lower().strip("'\"").strip()
        if w_api_l2 == "elastic":
            has_grid = any(k in opts2_n for k in ("tmin", "tmax", "deltat"))
            canonical2 = "elastic_constants_geo" if has_grid else "scf_elastic_constants"
            opts2_n["what"] = canonical2
        assert opts2_n["what"] == "scf_elastic_constants", (
            f"Safety net « elastic + no grid » aurait dû router vers "
            f"'scf_elastic_constants', got '{opts2_n['what']}'"
        )


# --- B. Métriques électroniques promises -------------------------------------

class TestP1MetricsIncludeElectronicProperties:
    """Le contrat exposé à l'UI doit inclure 3 clés ``properties.*``.

    Sans elles, l'UI ne sait pas afficher E_Fermi, gap ni nombre de bandes.
    """

    REQUIRED_KEYS = (
        "properties.fermi_eV",
        "properties.band_gap_eV",
        "properties.n_bands",
    )

    def test_p1_expected_results_has_properties_keys(self):
        p1 = _load_p1_profile()
        expected = p1.get("expected_results") or {}
        metrics = expected.get("metrics") or []
        keys = {m.get("key") for m in metrics if isinstance(m, dict)}
        missing = [k for k in self.REQUIRED_KEYS if k not in keys]
        assert not missing, (
            f"P1.expected_results.metrics manque ces clés : {missing}. "
            f"L'UI affichera des tiles vides pour E_Fermi / gap / n_bands."
        )

    def test_p1_properties_metric_labels_are_nonempty(self):
        """Les labels UI ne doivent pas être vides (sinon tile muet)."""
        p1 = _load_p1_profile()
        expected = p1.get("expected_results") or {}
        metrics = expected.get("metrics") or []
        for m in metrics:
            if not isinstance(m, dict):
                continue
            if m.get("key") in self.REQUIRED_KEYS:
                assert m.get("label"), (
                    f"Label vide pour la clé {m.get('key')!r} — la tile UI "
                    f"serait muette."
                )


# --- C. pipeline._execute référence la chaîne dans le bon ordre -------------

class TestPipelineExecuteCallSequence:
    """Lit le source de ``pipeline._execute`` et vérifie l'ordre des appels.

    On vérifie que ``_run_scf_eq`` (le runner SCF branche 'no EOS') est
    suivi de ``_run_thermo_pw`` (qui pilote what='elastic' P1) puis de
    ``_run_electronic_properties``. C'est l'ordre canonique P1.

    NB : on lit le source via ``inspect.getsource`` (pas l'AST) pour rester
    proche de ce qu'un humain verrait à l'œil — robuste aux variations de
    formatting / refactor minime.
    """

    @pytest.fixture(scope="class")
    def execute_source(self) -> str:
        from pipeline import PipelineJob  # noqa: WPS433
        return inspect.getsource(PipelineJob._execute)

    def test_pipeline_runs_electronic_properties_symbol(self):
        """``_run_electronic_properties`` reste exporté sur ``PipelineJob``.

        Verrouille le nom du symbole — un rename sauvage (p.ex.
        ``_run_dos_bands``) casserait les appelants externes ET ce test
        sans bruit dans la CI, ce qui est exactement ce qu'on veut éviter.
        """
        from pipeline import PipelineJob  # noqa: WPS433
        assert hasattr(PipelineJob, "_run_electronic_properties"), (
            "_run_electronic_properties a été renommé/supprimé sur "
            "PipelineJob ; les appelants (run_electronic_properties, "
            "live_preview, UI expectations) vont casser en silence."
        )

    def test_execute_calls_scf_eq(self, execute_source: str):
        """``_run_scf_eq`` est bien référencé (branche used quand needs_eos=False)."""
        assert "_run_scf_eq" in execute_source, (
            "_run_scf_eq absent de pipeline._execute — la branche P1 "
            "(pas de grille EOS) ne peut pas démarrer."
        )

    def test_execute_calls_thermo_pw(self, execute_source: str):
        assert "_run_thermo_pw" in execute_source, (
            "_run_thermo_pw absent — P1 ne ferait jamais tourner "
            "what='elastic' (C_ij @ T=0 K)."
        )

    def test_execute_calls_electronic_properties(self, execute_source: str):
        assert "_run_electronic_properties" in execute_source, (
            "_run_electronic_properties absent — la chaîne NSCF+DOS+bandes "
            "n'est jamais lancée, E_Fermi/gap/n_bands resteront None."
        )

    def test_thermo_pw_precedes_electronic_properties(self, execute_source: str):
        """L'ordre canonique P1 : thermo_pw (elastic) AVANT electronic_properties.

        On utilise ``rfind`` pour attraper l'**appel réel** (et pas la
        mention dans la docstring située en tête de méthode). Tolérant à
        un éventuel alias ``_run_thermo`` : on cherche un des trois needles
        canoniques ``_run_thermo_pw`` / ``what='elastic'`` / ``what = 'elastic'``
        dans la signature des appels, pas seulement le nom de méthode.
        """
        needles_thermo = (
            "_run_thermo_pw",
            "what='elastic'",
            "what = 'elastic'",
        )
        idx_thermo_candidates = [
            execute_source.rfind(n) for n in needles_thermo
        ]
        idx_thermo_candidates = [i for i in idx_thermo_candidates if i >= 0]
        assert idx_thermo_candidates, (
            "Aucun marqueur thermo_pw / what='elastic' trouvé dans "
            "_execute — la chaîne elastic semble absente."
        )
        idx_thermo = max(idx_thermo_candidates)

        idx_elec = execute_source.rfind("_run_electronic_properties")
        assert idx_elec >= 0
        assert idx_thermo < idx_elec, (
            f"Ordre inattendu : marqueur thermo @ {idx_thermo} vs "
            f"_run_electronic_properties @ {idx_elec}. L'invariant P1 "
            f"veut thermo_pw AVANT electronic_properties."
        )

    def test_properties_block_gated_by_flag(self, execute_source: str):
        """Le bloc ``_run_electronic_properties`` doit être gardé par ``properties_enabled``.

        On remonte ~12 lignes au-dessus du call : le ``if`` qui le garde
        doit y figurer. Lecture ciblée (pas de slice large sinon l'assertion
        attrape n'importe quel autre ``properties_enabled`` du fichier).
        """
        needle = "_run_electronic_properties"
        idx = execute_source.rfind(needle)
        assert idx >= 0
        before = execute_source[:idx]
        # 12 lignes max au-dessus — on évite ainsi toute mention lointaine
        # de ``properties_enabled`` dans une docstring, un autre bloc
        # (eos_summary, etc.) ou un commentaire.
        lines_before = [ln for ln in before.splitlines()[-12:] if ln.strip()]
        guarded = any(
            "properties_enabled" in ln and "if" in ln
            for ln in lines_before
        )
        assert guarded, (
            "_run_electronic_properties doit être gardé par "
            "'if self.profile.get(\"properties_enabled\", ...)'. Les 12 "
            "lignes juste avant le call ne contiennent pas ce garde."
        )


# --- Sanity overall ----------------------------------------------------------

def test_pipeline_module_imports_clean():
    """Le module ``pipeline`` doit s'importer sans erreur (sanity global)."""
    import pipeline  # noqa: F401, WPS433
    assert hasattr(pipeline, "PipelineJob")
    assert hasattr(pipeline, "PROFILES")


# --- D. Régressions juillet 2026 : 2 bugs corrigés -----------------------------
#
# 1. ``parse_ibrav_from_pw`` ne lisait que ``pw_scf_V0_for_phonon.in`` et
#    ``scf_eq.in``. P1 (Mécanique 0 K) ne génère QUE ``scf.in`` —
#    ``write_pw_bands_in`` recevait ``ibrav=None`` et skipait silencieusement
#    la chaîne bandes, faisant rester ``band_gap_eV`` / ``band_gap_type`` à
#    ``None`` même sur un SCF pleinement convergé.
#
# 2. ``run_gnuplot_edos`` hardcodait ``plot = "edos.dat"`` alors que ``dos.x``
#    écrit sa DOS dans ``dos.dat`` → gnuplot exit=1 → ``edos.png`` 0 bytes
#    côté UI (la tile "graph inactif" symptomatique).
#
# Les 2 tests suivants verrouillent les fixes (juillet 2026).
# ---------------------------------------------------------------------------


class TestP1BugfixJuly2026:
    """Régression des 2 bugs identifiés sur P1 lors du diagnostic utilisateur."""

    def test_parse_ibrav_from_pw_reads_scf_in_fallback(self, tmp_path):
        """Bug #1 : ``parse_ibrav_from_pw`` doit savoir lire ``scf.in`` (P1 fallback).

        Scénario reproduisant le run P1 : work_dir ne contient QUE ``scf.in``
        (pas de chaîne phonon, donc pas de ``pw_scf_V0_for_phonon.in`` ni de
        ``scf_eq.in``). Avant juillet 2026 : la fonction retournait ``None``
        et ``write_pw_bands_in`` skippait ``pw_bands.in`` silencieusement.
        """
        from phonon_chain_qe import parse_ibrav_from_pw  # noqa: WPS433
        (tmp_path / "scf.in").write_text(
            " &CONTROL\n"
            "   prefix = 'Si'\n"
            " /\n"
            " &SYSTEM\n"
            "   ibrav = 2,\n"
            "   celldm(1) = 10.3355895d0,\n"
            "   nat = 2,\n"
            "   ntyp = 1,\n"
            " /\n"
            " &ELECTRONS\n"
            "   ecutwfc = 60.0,\n"
            " /\n",
            encoding="utf-8",
        )
        ibrav = parse_ibrav_from_pw(tmp_path)
        assert ibrav == 2, (
            f"parse_ibrav_from_pw doit retomber sur scf.in (P1 fallback). "
            f"Ici, avec scf.in (ibrav=2) seul dans tmp_path, on a obtenu {ibrav!r}. "
            f"Sans ce fallback, write_pw_bands_in est skippé silencieusement et "
            f"properties.band_gap_eV reste None côté UI."
        )

    def test_parse_ibrav_from_pw_priority_order_is_preserved(self, tmp_path):
        """Bug #1bis : la PRIORITÉ des fichiers ne doit pas être inversée.

        Si plusieurs fichiers sont présents simultanément (run P2-P5 où
        ``pw_scf_V0_for_phonon.in`` ET ``scf.in`` coexistent), le parser doit
        continuer à privilégier ``pw_scf_V0_for_phonon.in`` (équilibre le
        plus à jour après EOS/phonons).
        """
        from phonon_chain_qe import parse_ibrav_from_pw  # noqa: WPS433
        # Mauvais candidat en ``scf.in`` (ibrav=0 triclinique fictif).
        (tmp_path / "scf.in").write_text(
            " &SYSTEM\n   ibrav = 0,\n /\n", encoding="utf-8"
        )
        # Bon candidat dans le fichier phonons. ibrav=4 (hexagonal) doit gagner.
        (tmp_path / "pw_scf_V0_for_phonon.in").write_text(
            " &SYSTEM\n   ibrav = 4,\n /\n", encoding="utf-8"
        )
        ibrav = parse_ibrav_from_pw(tmp_path)
        assert ibrav == 4, (
            f"Priorité cassée : avec pw_scf_V0_for_phonon.in (ibrav=4) ET "
            f"scf.in (ibrav=0) présents, parse_ibrav_from_pw doit renvoyer 4, "
            f"or il a renvoyé {ibrav!r}. Le fix doit ajouter scf.in EN DERNIER "
            f"fallback (jamais avant pw_scf_V0_for_phonon.in)."
        )

    def test_write_pw_bands_in_reads_ibrav_from_work_dir(self, tmp_path):
        """Bug #1ter : ``write_pw_bands_in`` ne doit pas passer un fichier à ``parse_ibrav_from_pw``.

        Scénario P1 avec phonons : ``pw_scf_V0_for_phonon.in`` + ``nscf.in`` présents.
        Avant le fix, ``parse_ibrav_from_pw(work_dir / scf_basename)`` cherchait
        ``(work_dir/scf.in)/pw_scf_V0_for_phonon.in`` → ``ibrav=None`` → bandes
        skippées alors que ``ibrav=2`` est bien dans le work_dir.
        """
        from electronic_props import write_pw_bands_in  # noqa: WPS433

        scf_body = (
            " &CONTROL\n"
            "   prefix = 'Si'\n"
            "   calculation = 'scf'\n"
            " /\n"
            " &SYSTEM\n"
            "   ibrav = 2,\n"
            "   celldm(1) = 10.3355895d0,\n"
            "   nat = 2,\n"
            "   ntyp = 1,\n"
            " /\n"
            " &ELECTRONS\n"
            "   ecutwfc = 60.0,\n"
            " /\n"
            "ATOMIC_POSITIONS crystal\n"
            "Si 0.0 0.0 0.0\n"
            "Si 0.25 0.25 0.25\n"
            "K_POINTS automatic\n"
            "  8 8 8 0 0 0\n"
        )
        (tmp_path / "pw_scf_V0_for_phonon.in").write_text(scf_body, encoding="utf-8")
        (tmp_path / "nscf.in").write_text(
            scf_body.replace("calculation = 'scf'", "calculation = 'nscf'")
            + "\n &SYSTEM\n   nbnd = 16\n /\n",
            encoding="utf-8",
        )
        out = write_pw_bands_in(tmp_path, "pw_scf_V0_for_phonon.in")
        assert out is not None, (
            "write_pw_bands_in doit générer pw_bands.in quand ibrav=2 est lisible "
            "dans le work_dir (P1 avec phonons)."
        )
        assert out.name == "pw_bands.in"
        text = out.read_text(encoding="utf-8")
        assert "K_POINTS crystal_b" in text
        assert "calculation = 'bands'" in text or 'calculation = "bands"' in text

    def test_write_pw_bands_in_strips_existing_kpoints(self, tmp_path):
        """pw_bands.in ne doit jamais contenir deux cartes K_POINTS."""
        from electronic_props import write_pw_bands_in  # noqa: WPS433

        scf_body = (
            " &CONTROL\n   prefix = 'Si'\n   calculation = 'scf'\n /\n"
            " &SYSTEM\n   ibrav = 2,\n   nat = 2,\n   ntyp = 1,\n /\n"
            " &ELECTRONS\n   ecutwfc = 60.0,\n /\n"
            "K_POINTS (automatic)\n  8 8 8 0 0 0\n"
        )
        (tmp_path / "scf.in").write_text(scf_body, encoding="utf-8")
        (tmp_path / "nscf.in").write_text(
            scf_body.replace("calculation = 'scf'", "calculation = 'nscf'")
            + "\n &SYSTEM\n   nbnd = 16\n /\n",
            encoding="utf-8",
        )
        out = write_pw_bands_in(tmp_path, "scf.in")
        assert out is not None
        text = out.read_text(encoding="utf-8")
        assert text.lower().count("k_points") == 1
        assert "K_POINTS crystal_b" in text
        assert "automatic" not in text.lower()

    def test_run_gnuplot_edos_uses_dos_dat_as_input(self, tmp_path, monkeypatch):
        """Bug #2 : ``run_gnuplot_edos`` doit ploter ``dos.dat`` (et non ``edos.dat``).

        Stratégie : on monkeypatch ``_gnuplot`` pour CAPTURER le script émis
        (sans le faire tourner — ``gnuplot`` peut être absent de la CI).
        On vérifie ensuite que le script contient ``plot 'dos.dat'`` et ne
        contient PAS ``plot 'edos.dat'`` comme fichier d'entrée (sinon →
        exit=1 → PNG vide).
        """
        import electronic_props as ep
        (tmp_path / "dos.dat").write_text(
            # format: E(eV)  N(E) — deux colonnes, dos.x standard.
            "-5.000  0.01\n"
            " 0.000  1.00\n"
            " 5.000  0.01\n",
            encoding="utf-8",
        )
        captured: dict = {}

        def _capture(script: str, *, work_dir, log):
            captured["script"] = script
            captured["work_dir"] = str(work_dir)
            # Simule un run gnuplot réussi : crée le PNG qu'attend
            # ``out_png.is_file()`` en bas de ``run_gnuplot_edos`` (sans quoi
            # la fonction renvoie ``None`` même avec le bon script).
            log.parent.mkdir(parents=True, exist_ok=True)
            log.write_text("# capture only\n", encoding="utf-8")
            out_png = work_dir / "edos.png"
            out_png.write_bytes(b"\x89PNG\r\n\x1a\n")  # PNG signature stub (1×1).

        monkeypatch.setattr(ep, "_gnuplot", _capture)
        result = ep.run_gnuplot_edos(tmp_path, fermi_eV=2.5)
        # 1. La fonction doit avoir renvoyé un Path (edos.png) — même si le
        #    PNG est vide, le Path est le bon (le contenu FAIT le boulot
        #    dans un vrai run ; ici on vérifie juste le wiring).
        assert result is not None and result.name == "edos.png", (
            f"run_gnuplot_edos doit renvoyer work_dir/edos.png, got {result!r}"
        )
        # 2. Le script DOIT contenir ``plot 'dos.dat'`` comme fichier d'entrée.
        script = captured.get("script", "")
        assert "plot 'dos.dat'" in script, (
            f"Script gnuplot doit contenir 'plot \\'dos.dat\\'' — fichier de "
            f"données réel produit par dos.x. Script actuel:\n{script}"
        )
        # 3. Le script NE DOIT PAS ploter 'edos.dat' (qui n'existe pas sur
        #    disque et faisait crasher gnuplot en exit=1 → PNG vide).
        assert "plot 'edos.dat'" not in script, (
            f"Script gnuplot ne doit PAS contenir 'plot \\'edos.dat\\'' (bug "
            f"régressé : edos.dat n'existe pas sur disque → exit=1 → PNG vide). "
            f"Script actuel:\n{script}"
        )

    def test_prepare_bands_gnuplot_dat_uses_k_path_from_gnu(self, tmp_path):
        """Bug #3 : l'axe x doit être la distance k (bands.dat.gnu), pas E bande 1."""
        import electronic_props as ep
        import shutil
        src = Path("/home/hiadsi/thermo_pw/work/Si/pipeline_P1_1784044538_02200e")
        if not (src / "bands.dat.gnu").is_file():
            pytest.skip("fixture P1 Si absent")
        for name in ("bands.dat.gnu", "bands.dat", "pw_bands.in"):
            shutil.copy2(src / name, tmp_path / name)
        prepared = ep._prepare_bands_gnuplot_dat(tmp_path, fermi_eV=6.0)
        assert prepared is not None
        plot_dat, nbnd, xs = prepared
        assert nbnd == 16
        assert len(xs) == 361
        first_line = plot_dat.read_text(encoding="utf-8").splitlines()[1]
        parts = [float(x) for x in first_line.split()]
        assert parts[0] == 0.0
        assert abs(parts[1] - (-5.733 - 6.0)) < 0.01

    def test_run_gnuplot_ebands_xtics_fcc_si(self, tmp_path, monkeypatch):
        """Le script gnuplot doit contenir les ticks Γ, X, … pour ibrav=2 (Si FCC)."""
        import electronic_props as ep
        import shutil
        src = Path("/home/hiadsi/thermo_pw/work/Si/pipeline_P1_1784044538_02200e")
        if not (src / "bands.dat.gnu").is_file():
            pytest.skip("fixture P1 Si absent")
        for name in ("bands.dat.gnu", "bands.dat", "pw_bands.in", "scf.in"):
            if (src / name).is_file():
                shutil.copy2(src / name, tmp_path / name)
        captured: dict = {}

        def _capture(script: str, *, work_dir, log):
            captured["script"] = script
            log.write_text("# ok\n", encoding="utf-8")
            (work_dir / "ebands.png").write_bytes(b"\x89PNG\r\n\x1a\n" + b"x" * 200)

        monkeypatch.setattr(ep, "_gnuplot", _capture)
        result = ep.run_gnuplot_ebands(tmp_path, fermi_eV=6.2912)
        assert result is not None
        script = captured.get("script", "")
        assert "set xtics" in script
        assert '"Γ"' in script or '"G"' in script or "Gamma" in script or "Γ" in script
        assert "using 1:2" in script
        assert "using 1:17" in script


class TestP1FullPresetJuly2026:
    """Câblage juillet 2026 — preset P1 « Cᵢⱼ + DOS + Bandes ».

    Le bouton UI « Preset P1 » sur la tuile P1 envoie ``p1_full_preset=True`` ;
    le backend doit alors forcer ``properties_enabled=True`` + ``properties_ichamp=3``
    + ``thermo_opts[ltherm_dos]=False``, sans émettre tmin/tmax/deltat.
    """

    def test_p1_full_preset_forces_ichamp_3_and_ltherm_dos_false(self, tmp_path):
        """Le preset P1 doit poser ichamp=3 + désactiver ltherm_dos (T=0 K strict)."""
        from pipeline import PipelineJob
        # Stub le template SCF pour ne pas tomber sur find_thermo_inputs_only.
        # Le test n'exécute pas _execute — il vérifie juste le constructeur.
        job = PipelineJob(
            material_id="Si",
            profile_id="P1",
            scf_in_basename="si_scf.in",
            nproc=1,
            p1_full_preset=True,
        )
        assert job.profile["properties_enabled"] is True
        assert int(job.profile["properties_ichamp"]) == 3
        assert job.profile["thermo_opts"]["ltherm_dos"] is False
        assert "tmin" not in job.profile["thermo_opts"]  # P1 = T=0 K
        assert "tmax" not in job.profile["thermo_opts"]
        assert "deltat" not in job.profile["thermo_opts"]

    def test_p1_full_preset_false_does_not_override_defaults(self, tmp_path):
        """``p1_full_preset=False`` explicite ne doit PAS toucher au profil."""
        from pipeline import PipelineJob
        job = PipelineJob(
            material_id="Si",
            profile_id="P1",
            scf_in_basename="si_scf.in",
            nproc=1,
            p1_full_preset=False,
        )
        # Defaults of PROFILES['P1'] already set properties_enabled=True + ichamp=3.
        # Explicit False must not regress them.
        assert job.profile["properties_enabled"] is True
        assert int(job.profile["properties_ichamp"]) == 3
        assert job.profile["thermo_opts"]["ltherm_dos"] is False

    def test_p1_full_preset_ignored_on_non_p1_profile(self, tmp_path):
        """Sur P2..P5 le preset est ignoré + warning journalisé (no-op)."""
        from pipeline import PipelineJob
        for pid in ("P2", "P3", "P4", "P5"):
            job = PipelineJob(
                material_id="Si",
                profile_id=pid,
                scf_in_basename="si_scf.in",
                nproc=1,
                p1_full_preset=True,
            )
            # Le profil externe ne doit PAS être modifié en ichamp=3 / properties_enabled si
            # les defaults ne le sont pas déjà (P5 a ses propres opt-in ; P2-P4 restent).
            assert job.p1_full_preset is True  # le flag est posé sur l'instance
            # Vérifie aussi qu'on a log le warning :
            warnings = [
                log for log in job.logs
                if "p1_full_preset" in log and "ignor" in log
            ]
            assert warnings, (
                f"[{pid}] Warning attendu sur le journal ; logs={job.logs!r}"
            )

    def test_p1_full_preset_persists_through_to_dict_from_dict(self, tmp_path):
        """Cycle serialize → deserialize : p1_full_preset survit + override réappliqué."""
        from pipeline import PipelineJob
        job = PipelineJob(
            material_id="Si",
            profile_id="P1",
            scf_in_basename="si_scf.in",
            nproc=1,
            p1_full_preset=True,
        )
        # Sérialise.
        d = job.to_dict()
        assert d.get("p1_full_preset") is True
        # Recharge via from_dict (avec un ``status`` terminal pour éviter le
        # chemin « interrupted » qui poserait work_dir).
        d["status"] = "paused"
        rehydrated = PipelineJob.from_dict(d)
        assert rehydrated.p1_full_preset is True
        # Vérifie que l'override est RE-appliqué à la reprise (idempotent) :
        assert rehydrated.profile["properties_enabled"] is True
        assert int(rehydrated.profile["properties_ichamp"]) == 3
        assert rehydrated.profile["thermo_opts"]["ltherm_dos"] is False

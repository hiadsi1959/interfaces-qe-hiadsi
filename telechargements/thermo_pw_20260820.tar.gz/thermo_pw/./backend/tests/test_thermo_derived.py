"""Tests parsers/thermo_derived.py."""
from __future__ import annotations

from parsers.thermo_derived import (
    alpha_from_gruneisen,
    cp_from_cv_correction,
    enrich_thermo_and_dielectric,
    epsilon_static_from_lst,
    parse_thermal_expansion_from_text,
)


def test_parse_alpha_scalar_from_log():
    text = "Thermal expansion coefficient = 2.6E-6 1/K\n"
    out = parse_thermal_expansion_from_text(text)
    assert out["alpha_300K_per_K"] == 2.6e-6
    assert out["alpha_source"] == "log_alpha_scalar"


def test_cp_correction_positive():
    cv = 1e-4  # Ry/K/cell
    alpha = 2.5e-6
    cp = cp_from_cv_correction(
        cv_Ry_per_K=cv,
        alpha_per_K=alpha,
        volume_bohr3=270.0,
        bulk_GPa=100.0,
        T_K=300.0,
    )
    assert cp is not None
    assert cp >= cv


def test_epsilon_static_lst():
    eps0 = epsilon_static_from_lst(10.0, 520.0, 500.0)
    assert eps0 is not None
    assert eps0 > 10.0


def test_enrich_gruneisen_alpha_and_cp():
    results = {
        "thermo": {"Cv_300K_Ry_per_K": 1.2e-4},
        "eos": {"V0_bohr3": 268.0, "B0_GPa": 98.0},
        "ph_life": {"gruneisen_mean": 0.9},
    }
    enrich_thermo_and_dielectric(__import__("pathlib").Path("/nonexistent"), results)
    assert results["thermo"].get("alpha_300K_per_K") is not None
    assert results["thermo"].get("Cp_300K_Ry_per_K") is not None


def test_cp_temperature_curve_from_cv():
    from parsers.thermo_derived import compute_cp_temperature_curve

    T = [0.0, 100.0, 300.0, 600.0]
    Cv = [0.0, 1.0e-5, 3.0e-5, 5.0e-5]
    cp_curve, src = compute_cp_temperature_curve(
        curve_T_K=T,
        curve_Cv_Ry_per_K=Cv,
        alpha_300K_per_K=2.5e-6,
        volume_bohr3=270.0,
        bulk_GPa=100.0,
    )
    assert len(cp_curve) == 4
    assert cp_curve[0] == 0.0
    assert all(c is not None and c >= cv for c, cv in zip(cp_curve[1:], Cv[1:]))
    assert "Cv_plus_TValpha2B" in src


def test_write_cv_cp_dat(tmp_path):
    from parsers.thermo_derived import write_cv_cp_dat

    thermo = {
        "curve_T_K": [100.0, 300.0],
        "curve_Cv_Ry_per_K": [1e-5, 3e-5],
        "curve_Cp_Ry_per_K": [1.01e-5, 3.05e-5],
    }
    rel = write_cv_cp_dat(tmp_path, thermo)
    assert rel == "therm_files/cv_cp_vs_T.dat"
    assert (tmp_path / rel).is_file()


def test_enrich_lst_epsilon_static():
    results = {
        "dielectric": {
            "epsilon_average": 11.7,
            "lo_freq_cm-1": 520.0,
            "to_freq_cm-1": 500.0,
        },
    }
    enrich_thermo_and_dielectric(__import__("pathlib").Path("/nonexistent"), results)
    assert results["dielectric"].get("epsilon_static_average") is not None

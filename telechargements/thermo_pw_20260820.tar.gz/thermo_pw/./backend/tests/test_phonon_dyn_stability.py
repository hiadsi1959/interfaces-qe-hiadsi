"""
test_phonon_dyn_stability.py
=============================

Verrouille l'indicateur de « stabilité dynamique » (juin 2026) au niveau
de TOUS les profils P1..P5 — généralisation du fix utilisateur
« puisque le pipeline fait tourner matdyn, expose un indicateur
dynamiquement_stable / n_imaginary_modes / min_freq_cm-1 dans results ».

Cible
-----
``backend/phonon_chain_qe.parse_matdyn_dynamic_stability(work_dir)`` :
  * source prioritaire : ``matdyn_bands.out`` (cm-1, marqueur ``(***ima***)``
    explicite) ;
  * fallback           : ``phonon.freq`` — bandes matdyn (cm⁻¹), blocs ``q =``,
    ou legacy THz (× ``_CM1_PER_THZ``) ;
  * tolérance standard : ``-0.5`` cm-1 (convention bruit Γ-acoustique).

Stratégie de fixtures
---------------------
6 fichiers synthétiques ``matdyn_bands.out`` couvrent les 6 scénarios
distincts attendus :
  1. full-stable        : toutes les fréquences > 0 (matériau stable).
  2. with-imaginary     : plusieurs modes sous tolérance (instable).
  3. tolerance-boundary : un mode exactement à -0.5 (frontière).
  4. mixed              : stable + imaginaire (cas typique : élastiquement
                          marginal, e.g. quelques modes proches de 0).
  5. fallback phonon    : pas de matdyn_bands.out, présence de phonon.freq en
                          THz → conversion.
  6. no-files           : work_dir vide → ``None``.

7. malformed           : matdyn_bands.out présent mais sans aucune ligne
                          ``freq ( N) = … cm-1`` → ``None`` puis fallback
                          phonon.freq → résultat valide (résilience).

Convention
----------
* ``os.path.dirname`` sys.path bootstrap (cf. ``test_electronic_props_alias``).
* pytest-compatible (``test_*``) + bloc ``__main__`` standalone.
* Pas de mock subprocess — le parser est purement lecture disque, sûr.
* Chaque test utilise ``tempfile.TemporaryDirectory`` via un context
  manager interne (``_workdir``) pour l'isolation (cleanup automatique,
  pas de fuite ``/tmp``, pas de hack ``Path._ctx`` que `pathlib.Path` ne
  supporte pas — `__slots__`-based).
"""
from __future__ import annotations

import os
import sys
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

# Bootstrap ``backend/`` sur sys.path (le test vit dans ``backend/tests/``).
_HERE = os.path.dirname(os.path.abspath(__file__))
_BACKEND = os.path.dirname(_HERE)
if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)

from phonon_chain_qe import (  # noqa: E402
    parse_matdyn_dynamic_stability,
    _CM1_PER_THZ,
)


# ============================================================================
# Phase 1 — fixtures synthétiques (matdyn.x format réaliste)
# ============================================================================

# 1. Full stable : 6 modes, tous ≥ +0 cm-1 (cas typique : cristal bien relaxé).
FIXTURE_FULL_STABLE = """\
     freq (  1) =     0.0000 cm-1
     freq (  2) =     0.0000 cm-1
     freq (  3) =     0.0000 cm-1
     freq (  4) =     2.4321 cm-1
     freq (  5) =     5.1234 cm-1
     freq (  6) =     7.8901 cm-1
"""

# 2. With imaginary : 3 modes négatifs sous tolérance, 3 stables.
FIXTURE_WITH_IMAGINARY = """\
     freq (  1) =    -7.8941 (***ima***) cm-1
     freq (  2) =    -3.2100 (***ima***) cm-1
     freq (  3) =    -0.9876 (***ima***) cm-1
     freq (  4) =     1.2345 cm-1
     freq (  5) =     4.5678 cm-1
     freq (  6) =     8.9012 cm-1
"""

# 3. Tolerance-boundary : mode exactement à -0.5 cm-1 (frontière stricte).
#    Convention : ``< tolerance`` est faux à -0.5 (test stable), vrai à -0.51.
FIXTURE_TOLERANCE_BOUNDARY = """\
     freq (  1) =    -0.5000 cm-1
     freq (  2) =     1.0000 cm-1
     freq (  3) =     2.0000 cm-1
"""

FIXTURE_JUST_BELOW_TOLERANCE = """\
     freq (  1) =    -0.5100 cm-1
     freq (  2) =     1.0000 cm-1
     freq (  3) =     2.0000 cm-1
"""

# 4. Mixed : 2 stables + 1 imaginaire (cas typique matériau marginal).
FIXTURE_MIXED = """\
     freq (  1) =     0.1000 cm-1
     freq (  2) =     2.3000 cm-1
     freq (  3) =    -1.2340 (***ima***) cm-1
"""

# 5a. phonon.freq bandes matdyn (&plot) — coordonnées q négatives ≠ modes imaginaires.
FIXTURE_PHONON_FREQ_BANDS = """\
 &plot nbnd=   6, nks=   3 /
            0.000000  0.000000  0.000000  0.000000
    0.0000    0.0000    0.0000  514.0361  514.0361  514.0361
           -0.025000  1.000000  0.000000  1.025000
    7.6011    7.6011   12.9448  513.9144  513.9144  514.0070
           -1.000000  0.500000  0.000000  0.500000
   15.1847   15.1847   25.8726  513.5492  513.5492  513.9184
"""

# 5b. phonon.freq (THz) — fallback legacy. matdyn_bands.out absent.
PHONON_FREQ_THZ = """\
0.0
0.0
0.0
0.5
1.8
4.2
-0.25
-0.15
"""

# 7. Malformed matdyn_bands.out (aucune ligne ``freq ( N) = … cm-1``).
FIXTURE_MALFORMED = """\
header noise line 1
header noise line 2
no proper format here
random text
"""


# ============================================================================
# Phase 2 — helpers
# ============================================================================

@contextmanager
def _workdir(mapping: dict[str, str]) -> Iterator[Path]:
    """Context manager : crée un workdir jetable + écrit les fixtures,
    yield le Path pour les assertions, cleanup automatique à la sortie.

    Remplace l'ancienne version `_stage_workdir` qui nécessitait un
    `_cleanup_workdir` séparé et utilisait un hack ``tmp._ctx = tmp_ctx``
    — invalide sur ``pathlib.PosixPath`` car les ``Path`` sont
    ``__slots__``-based (pas de ``__dict__``, on ne peut pas set
    d'attributs arbitraires). L'API context-manager standard est
    correcte, idiomatique, et utilise le pattern officiel
    ``tempfile.TemporaryDirectory`` avec cleanup garanti via
    ``shutil.rmtree`` interne.
    """
    with tempfile.TemporaryDirectory(prefix="dyn_stab_") as td:
        wd = Path(td)
        for fname, content in (mapping or {}).items():
            (wd / fname).write_text(content, encoding="utf-8")
        yield wd


# ============================================================================
# Phase 3 — invariants du parser
# ============================================================================

def test_full_stable_returns_True() -> None:
    """Cas 1 : toutes les fréquences ≥ 0 → ``dynamically_stable=True``,
    0 modes imaginaires, ``min_freq_cm-1`` ≈ 0 (les 3 premiers modes à Γ
    acoustique sont à exactement 0 cm-1 — c'est le cas d'un cristal stable
    correctement relaxé). ``source`` = ``matdyn_bands.out``.
    """
    with _workdir({"matdyn_bands.out": FIXTURE_FULL_STABLE}) as wd:
        r = parse_matdyn_dynamic_stability(wd)
        assert r is not None, "Parser doit retourner un dict pour FIXTURE_FULL_STABLE."
        assert r["dynamically_stable"] is True, (
            f"Attendu dynamically_stable=True ; got {r['dynamically_stable']!r}. "
            f"FIXTURE_FULL_STABLE ne contient AUCUN mode sous -0.5 cm-1."
        )
        assert r["n_imaginary_modes"] == 0, (
            f"Attendu n_imaginary_modes=0, got {r['n_imaginary_modes']!r}."
        )
        assert abs(r["min_freq_cm-1"]) <= 0.01, (
            f"min_freq_cm-1 attendu ≈ 0.0 (3 modes acoustiques à Γ), "
            f"got {r['min_freq_cm-1']!r}."
        )
        assert r["n_modes_total"] == 6, (
            f"Attendu 6 modes parsés, got {r['n_modes_total']!r}."
        )
        assert r["source"] == "matdyn_bands.out", (
            f"Attendu source='matdyn_bands.out', got {r['source']!r}."
        )


def test_with_imaginary_returns_False() -> None:
    """Cas 2 : 3 modes sous tolérance → ``dynamically_stable=False``,
    ``n_imaginary_modes=3``, ``min_freq_cm-1=-7.8941``.
    """
    with _workdir({"matdyn_bands.out": FIXTURE_WITH_IMAGINARY}) as wd:
        r = parse_matdyn_dynamic_stability(wd)
        assert r is not None
        assert r["dynamically_stable"] is False
        assert r["n_imaginary_modes"] == 3, (
            f"Attendu n_imaginary_modes=3, got {r['n_imaginary_modes']!r}. "
            f"Les 3 premiers modes sont sous -0.5 cm-1 (avec marqueur "
            f"(***ima***))."
        )
        assert abs(r["min_freq_cm-1"] - (-7.8941)) < 0.001, (
            f"min_freq_cm-1 doit valoir -7.8941 (mode le plus bas), "
            f"got {r['min_freq_cm-1']!r}."
        )
        assert r["n_modes_total"] == 6
        assert r["source"] == "matdyn_bands.out"


def test_tolerance_boundary_at_minus_0_5_is_stable() -> None:
    """Cas 3a : mode exactement à ``-0.5000`` cm-1 → sous tolérance
    (``f < -0.5`` est FAUX quand ``f == -0.5``), donc matériellement stable.

    Convention stricte : on utilise ``< tolerance`` (strict inférieure), ce
    qui place la frontière à ``-0.51`` (cf. Cas 3b). Cela reflète la
    convention « bruit numérique acceptable » : tout dans la fenêtre
    ``[-0.5, +0.5]`` cm-1 est réputé numériquement stable.
    """
    with _workdir({"matdyn_bands.out": FIXTURE_TOLERANCE_BOUNDARY}) as wd:
        r = parse_matdyn_dynamic_stability(wd)
        assert r["dynamically_stable"] is True, (
            "Mode exactement à -0.5 cm-1 doit être considéré comme STABLE "
            "(frontière stricte < -0.5, pas <=)."
        )
        assert r["n_imaginary_modes"] == 0
        assert abs(r["min_freq_cm-1"] - (-0.5)) < 0.001


def test_just_below_tolerance_is_unstable() -> None:
    """Cas 3b : mode à ``-0.5100`` cm-1 → sous tolérance (1 image),
    ``dynamically_stable=False``.
    """
    with _workdir({"matdyn_bands.out": FIXTURE_JUST_BELOW_TOLERANCE}) as wd:
        r = parse_matdyn_dynamic_stability(wd)
        assert r["dynamically_stable"] is False, (
            "Mode à -0.51 cm-1 (juste en-dessous de -0.5) doit être UNSTABLE."
        )
        assert r["n_imaginary_modes"] == 1


def test_mixed_with_one_imaginary() -> None:
    """Cas 4 : 2 stables + 1 imaginaire → ``dynamically_stable=False``,
    ``n_imaginary_modes=1``.
    """
    with _workdir({"matdyn_bands.out": FIXTURE_MIXED}) as wd:
        r = parse_matdyn_dynamic_stability(wd)
        assert r["dynamically_stable"] is False
        assert r["n_imaginary_modes"] == 1
        assert abs(r["min_freq_cm-1"] - (-1.234)) < 0.001
        assert r["n_modes_total"] == 3


def test_phonon_freq_band_plot_format_stable_despite_negative_q() -> None:
    """Format bandes ``&plot`` : les coordonnées q négatives ne comptent pas
    comme modes imaginaires (régression Si FCC Γ→X→…).
    """
    with _workdir({"phonon.freq": FIXTURE_PHONON_FREQ_BANDS}) as wd:
        r = parse_matdyn_dynamic_stability(wd)
        assert r is not None
        assert r["source"] == "phonon.freq"
        assert r["dynamically_stable"] is True, (
            f"Attendu stable ; got {r!r}. Les q négatifs ne sont pas des ω."
        )
        assert r["n_imaginary_modes"] == 0
        assert r["n_modes_total"] == 18  # 3 points q × 6 modes
        assert r["min_freq_cm-1"] >= -0.01


def test_phonon_freq_fallback_when_matdyn_bands_absent() -> None:
    """Cas 5 : ``matdyn_bands.out`` absent mais ``phonon.freq`` (THz)
    présent → fallback + conversion THz → cm-1 via ``_CM1_PER_THZ``.

    Fixture PHONON_FREQ_THZ = 0.0, 0.0, 0.0, 0.5, 1.8, 4.2, -0.25, -0.15
    → 8 modes = 3 acoustiques Γ à 0, 5 modes > 0, puis 2 négatifs.
    En cm-1 : 0, 0, 0, ~16.7, ~60.0, ~140.1, ~-8.3, ~-5.0
    → modes -8.3 et -5.0 sont sous -0.5 → 2 imaginaires.
    """
    with _workdir({"phonon.freq": PHONON_FREQ_THZ}) as wd:
        r = parse_matdyn_dynamic_stability(wd)
        assert r is not None, (
            "Parser doit retomber sur phonon.freq quand matdyn_bands.out "
            "est absent."
        )
        assert r["source"] == "phonon.freq"
        assert r["dynamically_stable"] is False, (
            "2 modes négatifs en THz (-0.25, -0.15) convertis en cm-1 "
            "(-8.3, -5.0) sont sous tolérance → UNSTABLE."
        )
        assert r["n_imaginary_modes"] == 2
        assert r["n_modes_total"] == 8
        # Sanity de conversion : -0.25 THz * _CM1_PER_THZ ≈ -8.339 cm-1
        expected_min = -0.25 * _CM1_PER_THZ
        assert abs(r["min_freq_cm-1"] - expected_min) < 0.01, (
            f"min_freq_cm-1 doit ≈ {expected_min:.3f} (-0.25 THz → cm-1), "
            f"got {r['min_freq_cm-1']!r}."
        )


def test_returns_None_when_no_files_present() -> None:
    """Cas 6 : work_dir vide (chaîne phonon pas encore exécutée) → ``None``.

    L'appelant ``PipelineJob._intermediate_parse`` n'écrit alors rien dans
    ``self.results`` ; les 3 clés matérialisées par ``_init_results_for_profile``
    restent ``None`` (UI : « N/A : chaîne phonon non requise »).
    """
    with _workdir({}) as wd:
        r = parse_matdyn_dynamic_stability(wd)
        assert r is None, (
            f"Parser doit renvoyer None quand ni matdyn_bands.out ni "
            f"phonon.freq ne sont présents, got {r!r}."
        )


def test_malformed_matdyn_bands_falls_back_to_phonon_freq() -> None:
    """Cas 7 : matdyn_bands.out présent mais sans aucune ligne ``freq ( N) =
    ... cm-1`` (entête corrompu / log tronqué) → parser source-prioritaire
    renvoie ``None``, fallback sur ``phonon.freq`` → résilience.
    """
    with _workdir({
        "matdyn_bands.out": FIXTURE_MALFORMED,
        "phonon.freq": "0.0\n1.5\n3.0\n",
    }) as wd:
        r = parse_matdyn_dynamic_stability(wd)
        assert r is not None, (
            "Avec matdyn_bands.out vide + phonon.freq valide, le parser "
            "DOIT retomber sur phonon.freq (pas renvoyer None)."
        )
        assert r["source"] == "phonon.freq"
        assert r["dynamically_stable"] is True
        assert r["n_imaginary_modes"] == 0
        assert r["n_modes_total"] == 3


def test_custom_tolerance_argument_respected() -> None:
    """Tolérance configurable : pour un matériau très bruité (grille
    nq1=nq2=nq3=2 sans extrapolation), ``tolerance_cm_minus_1=-1.0`` peut
    être nécessaire. Le parser doit accepter ce kwarg et l'appliquer
    strictement.

    La fixture ``FIXTURE_TOLERANCE_BOUNDARY`` a un mode à -0.5000 cm-1 :
    * tolérance par défaut (-0.5) — convention stricte ``< -0.5`` est
      FAUX à -0.5 exactement → STABLE.
    * tolérance stricte (-0.4) — convention stricte ``< -0.4`` est VRAIE
      à -0.5 → UNSTABLE (1 mode imaginaire).
    """
    with _workdir({"matdyn_bands.out": FIXTURE_TOLERANCE_BOUNDARY}) as wd:
        # Tolérance -0.5 (défaut) : mode à -0.5 cm-1 → STABLE.
        r_default = parse_matdyn_dynamic_stability(wd)
        assert r_default["dynamically_stable"] is True, (
            "À tolérance par défaut (-0.5), mode à -0.5 cm-1 doit être STABLE "
            "(convention stricte ``< -0.5``, pas ``<=``)."
        )
        # Tolérance -0.4 : mode à -0.5 cm-1 → UNSTABLE (car -0.5 < -0.4).
        r_strict = parse_matdyn_dynamic_stability(wd, tolerance_cm_minus_1=-0.4)
        assert r_strict["dynamically_stable"] is False, (
            "À tolérance stricte (-0.4), mode à -0.5 cm-1 doit être UNSTABLE "
            "(car -0.5 < -0.4, mode imaginaire)."
        )
        assert r_strict["n_imaginary_modes"] == 1


def test_summary_shape_is_strict_keys() -> None:
    """Shape stricte : le dict retourné expose les clés de verdict + recommandations.

    Juillet 2026 : ``verification_recommendations`` est toujours attaché par
    ``_attach_verification_recommendations`` (même sans modes imaginaires).
    """
    expected_keys = {
        "dynamically_stable",
        "n_imaginary_modes",
        "min_freq_cm-1",
        "n_modes_total",
        "source",
        "verification_recommendations",
    }
    with _workdir({"matdyn_bands.out": FIXTURE_FULL_STABLE}) as wd:
        r = parse_matdyn_dynamic_stability(wd)
        assert r is not None
        assert set(r.keys()) == expected_keys, (
            f"Shape dérivée : attendu {expected_keys}, "
            f"got {set(r.keys())}. Extra: {set(r.keys()) - expected_keys}; "
            f"manquant: {expected_keys - set(r.keys())}."
        )


# ============================================================================
# Phase 4 — sanity signer (signature publique du parser)
# ============================================================================

def test_parser_signature_does_not_break_caller_contract() -> None:
    """Le site d'appel ``pipeline._intermediate_parse`` importe
    ``from phonon_chain_qe import parse_matdyn_dynamic_stability`` puis
    fait ``parse_matdyn_dynamic_stability(wd)``. Ce test verrouille la
    signature minimaliste : 1 positionnel (``work_dir``) + 1 kwarg
    tol. Une signature change (kwargs obligatoires ajoutés, positionnel
    renommé, etc.) casserait l'appelant en silence → reflet exact ici.
    """
    import inspect
    sig = inspect.signature(parse_matdyn_dynamic_stability)
    params = list(sig.parameters.values())
    # Param 0 : work_dir (positional)
    assert params[0].name == "work_dir"
    assert params[0].default is inspect.Parameter.empty, (
        "work_dir doit être POSITIONNEL (pas de valeur par défaut) — "
        "sinon l'appelant ``parse_matdyn_dynamic_stability(wd)`` peut "
        "passer None sans warning."
    )
    # Param 1 (optionnel) : tolerance_cm_minus_1 (default -0.5)
    assert any(
        p.name == "tolerance_cm_minus_1" and p.default == -0.5
        for p in params
    ), "tolerance_cm_minus_1 (default -0.5) doit exister comme kwarg-only."


# ============================================================================
# Standalone runner (CI sans pytest)
# ============================================================================

if __name__ == "__main__":
    test_funcs = [
        (n, obj) for n, obj in sorted(globals().items())
        if n.startswith("test_") and callable(obj)
    ]
    failures: list[str] = []
    for name, fn in test_funcs:
        try:
            fn()
        except Exception as ex:  # noqa: BLE001
            failures.append(f"FAIL  {name}  → {type(ex).__name__}: {ex}")
        else:
            print(f"PASS  {name}")
    if failures:
        print()
        for f in failures:
            print(f)
        sys.exit(1)
    print(f"\n[OK] {len(test_funcs)} tests passed.")
    sys.exit(0)

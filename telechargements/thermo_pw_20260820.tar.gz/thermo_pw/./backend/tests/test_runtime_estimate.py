"""Tests de l'estimation de durée (machine_profile + runtime_estimate).

Le point le plus important couvert ici est la **fidélité aux mesures** : les
constantes livrées ont été calibrées sur un run P2/Si réel, et un test vérifie
que le modèle les reproduit. Sans ce garde-fou, un futur ajustement d'exposant
ou de facteur parallèle pourrait décaler silencieusement toutes les durées
affichées à l'utilisateur.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import machine_profile as mpf  # noqa: E402
import runtime_estimate as rte  # noqa: E402

SI_SCF = """&CONTROL
    calculation = 'scf'
/
&SYSTEM
    ibrav = 2
    celldm(1) = 10.261
    nat = 2
    ntyp = 1
    ecutwfc = 60.0
    ecutrho = 480.0
/
K_POINTS (automatic)
 12 12 12  0 0 0
"""


@pytest.fixture
def si_scf(tmp_path: Path) -> Path:
    p = tmp_path / "scf.in"
    p.write_text(SI_SCF, encoding="utf-8")
    return p


@pytest.fixture
def ref_machine() -> mpf.MachineProfile:
    """Machine de référence de la calibration (i7-7500U, 2 cœurs / 4 threads)."""
    return mpf.MachineProfile(
        cpu_model="Intel(R) Core(TM) i7-7500U CPU @ 2.70GHz",
        cores_physical=2,
        cores_logical=4,
        cores_available=4,
        smt_ratio=2.0,
        ram_total_mb=11328,
        ram_available_mb=6000,
        speed_index=1.0,
    )


@pytest.fixture(autouse=True)
def isolated_calibration(tmp_path, monkeypatch):
    """Isole le magasin de calibration : pas d'écriture dans backend/."""
    store = tmp_path / "calib.json"
    monkeypatch.setattr(rte, "_calib_path", lambda: store)
    return store


# ---------------------------------------------------------------------------
# Détection machine
# ---------------------------------------------------------------------------
class TestMachineProfile:
    def test_physical_cores_distinguished_from_logical(self):
        """Le piège central : ne pas confondre threads SMT et vrais cœurs."""
        prof = mpf.detect_machine()
        assert prof.cores_physical >= 1
        assert prof.cores_logical >= prof.cores_physical
        assert prof.cores_physical <= prof.cores_logical

    def test_detection_is_deterministic(self):
        """Deux appels doivent donner le même indice.

        Un indice fluctuant ferait varier les durées affichées sans raison
        compréhensible : c'est précisément pourquoi le micro-benchmark a été
        retiré au profit de la fréquence nominale.
        """
        a, b = mpf.detect_machine(), mpf.detect_machine()
        assert a.speed_index == b.speed_index
        assert a.cores_physical == b.cores_physical

    def test_nominal_ghz_parsed_from_model_name(self):
        assert mpf._nominal_base_ghz("Intel(R) Core(TM) i7-7500U CPU @ 2.70GHz") == 2.70

    def test_nominal_ghz_falls_back_when_model_has_no_clock(self):
        """Les CPU AMD n'annoncent pas leur fréquence dans le modèle.

        On retombe alors sur /sys ; le résultat dépend donc de la machine de
        test, d'où une assertion sur la plausibilité plutôt que sur une valeur.
        """
        got = mpf._nominal_base_ghz("AMD Ryzen 9 5950X 16-Core Processor")
        assert got is None or 0.3 <= got <= 7.0

    def test_speedup_saturates_beyond_physical_cores(self, ref_machine):
        """Doubler les rangs au-delà des cœurs physiques ne double pas la vitesse."""
        s2 = ref_machine.parallel_speedup(2)
        s4 = ref_machine.parallel_speedup(4)
        assert s2 == pytest.approx(1.82, abs=0.02)
        assert s4 < 2 * s2  # pas de gain linéaire via le SMT

    def test_gross_oversubscription_is_a_loss(self, ref_machine):
        """Au-delà des threads disponibles, ajouter des rangs ralentit."""
        assert ref_machine.parallel_speedup(16) < ref_machine.parallel_speedup(4)

    def test_recommendation_is_physical_cores(self, ref_machine):
        """La recommandation suit les cœurs physiques, pas l'optimum théorique.

        Le modèle prédit un gain marginal en poussant jusqu'aux threads SMT,
        et une mesure isolée le confirme (SCF : 62 s à nproc=4 contre 79 s à
        nproc=2). Mais le run P2 complet à nproc=4 a duré cinq fois plus
        longtemps. La recommandation privilégie donc le réglage sûr, et ce test
        verrouille ce choix pour qu'un futur « alignement sur le modèle » ne le
        défasse pas silencieusement.
        """
        assert ref_machine.recommended_nproc() == ref_machine.cores_physical

    def test_concurrent_jobs_beat_a_single_mpi_job(self, ref_machine):
        """Des processus indépendants exploitent mieux la machine qu'un job MPI.

        Vérifié sur la grille EOS de référence : 7 volumes à 3×2 rangs ont un
        débit agrégé de 2.6 là où un pw.x seul à 2 rangs plafonne à 1.8.
        """
        assert ref_machine.concurrent_speedup(6) == pytest.approx(2.6, abs=0.05)
        assert ref_machine.concurrent_speedup(6) > ref_machine.parallel_speedup(2)

    def test_gross_oversubscription_collapses(self, ref_machine):
        """12 processus sur 4 threads : effondrement mesuré d'un facteur ~6."""
        ratio = ref_machine.concurrent_speedup(6) / ref_machine.concurrent_speedup(12)
        assert 4.0 < ratio < 8.0

    def test_warning_only_when_truly_oversubscribed(self, ref_machine):
        texts = " ".join(ref_machine.warnings_for(16))
        assert "Effondrement" in texts
        # Dans la zone SMT, l'avertissement cite la mesure sans promettre un gain.
        smt = " ".join(ref_machine.warnings_for(4))
        assert "SMT" in smt and "cinq fois plus lent" in smt
        assert ref_machine.warnings_for(2) == []


# ---------------------------------------------------------------------------
# Descripteurs matériau
# ---------------------------------------------------------------------------
class TestDescriptors:
    def test_parsed_from_scf_in(self, si_scf):
        d = rte.parse_material_descriptors(pw_path=si_scf)
        assert (d.nat, d.ntyp, d.ibrav) == (2, 1, 2)
        assert d.ecutwfc == 60.0
        assert d.ecutrho == 480.0
        assert d.nk == (12, 12, 12)
        assert d.n_modes == 6

    def test_reference_material_has_unit_work(self, si_scf):
        """Si est le matériau de calibration : son travail vaut 1 par définition."""
        d = rte.parse_material_descriptors(pw_path=si_scf)
        assert d.work_scf() == pytest.approx(1.0, rel=1e-6)

    def test_work_grows_with_size_and_cutoff(self, si_scf):
        base = rte.parse_material_descriptors(pw_path=si_scf)
        bigger = rte.parse_material_descriptors(pw_path=si_scf)
        bigger.nat = 8
        assert bigger.work_scf() > 10 * base.work_scf()
        hi_cut = rte.parse_material_descriptors(pw_path=si_scf)
        hi_cut.ecutwfc = 120.0
        assert hi_cut.work_scf() == pytest.approx(2 ** 1.5, rel=1e-6)

    def test_cubic_irreducible_counts_are_exact(self):
        """La grille q 4×4×4 du pipeline doit donner les 8 q de Si, pas 64/48."""
        assert rte.estimate_irreducible_points((4, 4, 4), 2) == 8
        assert rte.estimate_irreducible_points((12, 12, 12), 2) == 72
        assert rte.estimate_irreducible_points((2, 2, 2), 2) == 3

    def test_low_symmetry_yields_more_points(self):
        cubic = rte.estimate_irreducible_points((6, 6, 6), 2)
        triclinic = rte.estimate_irreducible_points((6, 6, 6), 14)
        assert triclinic > cubic

    def test_defaults_when_no_input_file(self):
        d = rte.parse_material_descriptors(pw_path=Path("/nonexistent/scf.in"))
        assert d.nat >= 1 and d.nq_irreducible >= 1


# ---------------------------------------------------------------------------
# Fidélité aux mesures — le test qui protège la crédibilité de l'affichage
# ---------------------------------------------------------------------------
class TestCalibrationFidelity:
    """Le modèle doit reproduire les deux runs P2/Si mesurés sur l'i7-7500U.

    Run de référence, **nproc=2** (18/08/2026, machine peu chargée) :
      * grille EOS (7 volumes) : 383 s
      * SCF @ V₀                : 79 s
      * ph.x (8 q × 6 modes)    : 12 633 s, soit 3 h 30 (« PHONON 3h30m WALL »)
      * q2r.x                   : < 1 s
      * matdyn.x                : 9 s

    Run dégradé, **nproc=4** (17/08/2026, 3 Gio en swap, navigateur actif) :
      * grille EOS : 2234 s — 12 processus concurrents sur 4 threads
      * SCF @ V₀   : 62 s — un job isolé profite légèrement du SMT

    ``ph.x`` de ce second run (18,2 h) est délibérément **exclu** : la mesure
    est contaminée par la pagination et le modèle ne cherche pas à la
    reproduire. L'avertissement mémoire de ``warnings_for`` couvre ce cas.
    """

    MEASURED_NP2 = {
        "eos_grid": 383.0,
        "scf_phonon": 79.0,
        "ph": 12633.0,
        "matdyn": 9.0,
    }
    MEASURED_NP4 = {"eos_grid": 2234.0, "scf_phonon": 62.0}

    def _estimate(self, si_scf, ref_machine, nproc):
        from pipeline import PROFILES

        return rte.estimate_runtime(
            profile_id="P2",
            profile=PROFILES["P2"],
            descriptors=rte.parse_material_descriptors(pw_path=si_scf),
            machine=ref_machine,
            nproc=nproc,
        )

    @pytest.mark.parametrize("step", sorted(MEASURED_NP2))
    def test_reproduces_clean_run(self, si_scf, ref_machine, step):
        est = self._estimate(si_scf, ref_machine, nproc=2)
        got = est.step_by_name(step)
        assert got is not None
        assert got.seconds == pytest.approx(self.MEASURED_NP2[step], rel=0.15)

    @pytest.mark.parametrize("step", sorted(MEASURED_NP4))
    def test_reproduces_degraded_run(self, si_scf, ref_machine, step):
        """Le modèle parallèle doit expliquer la dégradation, pas la subir.

        Ces deux valeurs viennent d'un run à nproc=4 sur la même machine et le
        même matériau : elles ne testent que le modèle de parallélisme, les
        constantes étant calées sur le run à nproc=2.
        """
        est = self._estimate(si_scf, ref_machine, nproc=4)
        got = est.step_by_name(step)
        assert got is not None
        assert got.seconds == pytest.approx(self.MEASURED_NP4[step], rel=0.20)

    def test_phonons_dominate_and_total_is_plausible(self, si_scf, ref_machine):
        est = self._estimate(si_scf, ref_machine, nproc=2)
        # La boucle QHA (9 × phonons) domine désormais le total P2.
        assert est.dominant_step == "thermo_pw"
        tp = est.step_by_name("thermo_pw")
        assert tp is not None
        assert tp.units == 9 * 8 * 6  # 9 géom. × 8 q irr. × 6 modes (Si)
        assert 12 * 3600 < est.total_seconds < 55 * 3600
        assert est.low_seconds < est.total_seconds < est.high_seconds

    def test_p2_thermo_pw_uses_qha_geometry_count(self, si_scf, ref_machine):
        est = self._estimate(si_scf, ref_machine, nproc=2)
        assert any("QHA" in w for w in est.warnings)
        assert est.step_by_name("thermo_pw").cost_key == "ph_per_q_mode"

    @pytest.mark.parametrize("profile_id", ("P2", "P3", "P4"))
    def test_qha_profiles_dominated_by_thermo_pw(self, si_scf, ref_machine, profile_id):
        from pipeline import PROFILES

        desc = rte.parse_material_descriptors(pw_path=si_scf)
        est = rte.estimate_runtime(
            profile_id=profile_id,
            profile=PROFILES[profile_id],
            descriptors=desc,
            machine=ref_machine,
            nproc=2,
        )
        assert est.dominant_step == "thermo_pw"
        tp = est.step_by_name("thermo_pw")
        assert tp is not None
        assert tp.units == 9 * 8 * 6

    def test_p3_longer_than_p2_due_to_elastic_extra(self, si_scf, ref_machine):
        from pipeline import PROFILES

        desc = rte.parse_material_descriptors(pw_path=si_scf)
        p2 = rte.estimate_runtime(
            profile_id="P2", profile=PROFILES["P2"], descriptors=desc,
            machine=ref_machine, nproc=2,
        ).total_seconds
        p3 = rte.estimate_runtime(
            profile_id="P3", profile=PROFILES["P3"], descriptors=desc,
            machine=ref_machine, nproc=2,
        ).total_seconds
        assert p3 > p2

    def test_p4_longer_than_p3_due_to_ph_life_extra(self, si_scf, ref_machine):
        from pipeline import PROFILES

        desc = rte.parse_material_descriptors(pw_path=si_scf)
        p3 = rte.estimate_runtime(
            profile_id="P3", profile=PROFILES["P3"], descriptors=desc,
            machine=ref_machine, nproc=2,
        ).total_seconds
        p4 = rte.estimate_runtime(
            profile_id="P4", profile=PROFILES["P4"], descriptors=desc,
            machine=ref_machine, nproc=2,
        ).total_seconds
        assert p4 > p3


# ---------------------------------------------------------------------------
# Estimation par profil
# ---------------------------------------------------------------------------
class TestProfileEstimates:
    def test_every_profile_gets_an_estimate(self, si_scf, ref_machine):
        from pipeline import PROFILES

        desc = rte.parse_material_descriptors(pw_path=si_scf)
        for pid, prof in PROFILES.items():
            est = rte.estimate_runtime(
                profile_id=pid, profile=prof, descriptors=desc,
                machine=ref_machine, nproc=4,
            )
            assert est.total_seconds > 0, pid
            assert est.steps, pid
            assert est.to_dict()["total_human"], pid

    def test_step_sequence_matches_profile_flags(self, si_scf, ref_machine):
        """Les étapes estimées doivent refléter la séquence réelle du profil."""
        from pipeline import PROFILES

        desc = rte.parse_material_descriptors(pw_path=si_scf)
        for pid in ("P1", "P2", "P5"):
            prof = PROFILES[pid]
            names = {
                s.step
                for s in rte.estimate_runtime(
                    profile_id=pid, profile=prof, descriptors=desc,
                    machine=ref_machine, nproc=4,
                ).steps
            }
            # P2/P3/P4 balaient une grille de volumes ; P1/P5 un seul V0.
            assert ("eos_grid" in names) == bool(prof.get("needs_eos")), pid
            assert ("scf_eq" in names) != bool(prof.get("needs_eos")), pid
            assert ("ph" in names) == bool(prof.get("needs_phonons")), pid

    def test_more_ranks_never_slower_within_hardware(self, si_scf, ref_machine):
        from pipeline import PROFILES

        desc = rte.parse_material_descriptors(pw_path=si_scf)

        def total(nproc):
            return rte.estimate_runtime(
                profile_id="P2", profile=PROFILES["P2"], descriptors=desc,
                machine=ref_machine, nproc=nproc,
            ).total_seconds

        assert total(2) < total(1)
        assert total(32) > total(4)  # sur-souscription franche : perte nette

    def test_optical_option_lengthens_p5(self, si_scf, ref_machine):
        from pipeline import PROFILES

        desc = rte.parse_material_descriptors(pw_path=si_scf)
        base = rte.estimate_runtime(
            profile_id="P5", profile=PROFILES["P5"], descriptors=desc,
            machine=ref_machine, nproc=4,
        )
        with_optics = rte.estimate_runtime(
            profile_id="P5", profile={**PROFILES["P5"], "needs_optical": True},
            descriptors=desc, machine=ref_machine, nproc=4,
        )
        assert with_optics.total_seconds > base.total_seconds

    def test_warns_about_estimated_q_count(self, si_scf, ref_machine):
        from pipeline import PROFILES

        desc = rte.parse_material_descriptors(pw_path=si_scf)
        est = rte.estimate_runtime(
            profile_id="P2", profile=PROFILES["P2"], descriptors=desc,
            machine=ref_machine, nproc=4,
        )
        assert any("points q" in w for w in est.warnings)


class TestHumanize:
    @pytest.mark.parametrize(
        "seconds,expected",
        [
            (5, "5 s"),
            (89, "89 s"),
            (600, "10 min"),
            (3600, "1 h"),
            (3600 * 3 + 1200, "3 h 20"),
            (3600 * 48, "2 j"),
        ],
    )
    def test_formats(self, seconds, expected):
        assert rte.humanize_seconds(seconds) == expected


# ---------------------------------------------------------------------------
# Progression réelle
# ---------------------------------------------------------------------------
PH_OUT = """
     Calculation of the dynamical matrix

        N         xq(1)         xq(2)         xq(3)
        1   0.000000000   0.000000000   0.000000000
        2  -0.250000000   0.250000000  -0.250000000
        3   0.500000000  -0.500000000   0.500000000
        4   0.000000000   0.500000000   0.000000000

     Calculation of q =    0.0000000   0.0000000   0.0000000
     total cpu time :     10.0 secs
     total cpu time :   3600.0 secs
     Calculation of q =   -0.2500000   0.2500000  -0.2500000
     total cpu time :   7200.0 secs
     Calculation of q =    0.5000000  -0.5000000   0.5000000
     total cpu time :   9000.0 secs
"""


class TestProgressParsing:
    def test_ph_out_gives_exact_q_count_and_real_cost(self, tmp_path):
        """ph.out est la source la plus fiable : QE y publie ses propres temps."""
        p = tmp_path / "ph.out"
        p.write_text(PH_OUT, encoding="utf-8")
        prog = rte.parse_ph_out_progress(p)
        assert prog["q_total"] == 4
        assert prog["q_started"] == 3
        assert prog["q_done"] == 2
        assert prog["cpu_seconds"] == 9000.0
        # 9000 s pour 2 q terminés + 1 entamé → ~3600 s/q
        assert prog["seconds_per_q"] == pytest.approx(3600.0, rel=0.01)

    def test_missing_ph_out_is_not_an_error(self, tmp_path):
        prog = rte.parse_ph_out_progress(tmp_path / "absent.out")
        assert prog["q_total"] is None and prog["q_done"] == 0

    def test_eos_progress_counts_finished_volumes(self, tmp_path):
        d = tmp_path / "1_eos_volumes"
        d.mkdir()
        (d / "scf_vol_0.out").write_text("... JOB DONE ...", encoding="utf-8")
        (d / "scf_vol_1.out").write_text("... JOB DONE ...", encoding="utf-8")
        (d / "scf_vol_2.out").write_text("en cours", encoding="utf-8")
        prog = rte.parse_eos_grid_progress(tmp_path)
        assert prog["volumes_done"] == 2
        assert prog["volumes_total"] == 7

    def test_descriptors_prefer_exact_counts_from_outputs(self, tmp_path):
        """Dès que QE a écrit ses sorties, on lit au lieu d'estimer."""
        (tmp_path / "scf.in").write_text(SI_SCF, encoding="utf-8")
        (tmp_path / "scf.out").write_text(
            "     number of k points=    29\n", encoding="utf-8"
        )
        (tmp_path / "ph.out").write_text(PH_OUT, encoding="utf-8")
        d = rte.parse_material_descriptors(work_dir=tmp_path)
        assert d.nk_irreducible == 29 and d.nk_source.startswith("lu")
        assert d.nq_irreducible == 4 and d.nq_source.startswith("lu")

    @staticmethod
    def _qha_workdir(tmp_path, *, t0: float) -> Path:
        """Work_dir synthétique : 5 géométries, g1/g2 finies, g3 à moitié.

        Les mtimes des output_therm.dat.gK sont posés à t0+1000 et t0+2000 :
        rythme mesuré = 1000 s/géométrie exactement.
        """
        import os

        (tmp_path / "thermo_pw_run.out").write_text(
            "     Number of geometries to compute:    5\n", encoding="utf-8"
        )
        therm = tmp_path / "therm_files"
        therm.mkdir()
        for k, dt in ((1, 1000.0), (2, 2000.0)):
            p = therm / f"output_therm.dat.g{k}"
            p.write_text("# T  E  F  S  Cv\n", encoding="utf-8")
            os.utime(p, (t0 + dt, t0 + dt))
        dyn = tmp_path / "dynamical_matrices"
        dyn.mkdir()
        for g, n in ((1, 4), (2, 4), (3, 2)):  # g3 : 2/4 points q → 0.5
            for i in range(n):
                (dyn / f"ph_dyn.g{g}.{i}").write_text("dyn", encoding="utf-8")
        return tmp_path

    def test_qha_progress_measures_geometry_pace(self, tmp_path):
        from datetime import datetime

        t0 = 1_700_000_000.0
        wd = self._qha_workdir(tmp_path, t0=t0)
        prog = rte.parse_thermo_qha_progress(
            wd, phase_started_at=datetime.fromtimestamp(t0)
        )
        assert prog["geometries_total"] == 5
        assert prog["geometries_done"] == 2
        assert prog["current_fraction"] == pytest.approx(0.5)
        assert prog["seconds_per_geometry"] == pytest.approx(1000.0)
        # 5 − 2 faites − 0.5 en cours = 2.5 géométries × 1000 s.
        assert prog["remaining_seconds"] == pytest.approx(2500.0)

    def test_qha_progress_without_phase_start_needs_two_geometries(self, tmp_path):
        """Sans heure de départ, le rythme vient des écarts entre mtimes."""
        wd = self._qha_workdir(tmp_path, t0=1_700_000_000.0)
        prog = rte.parse_thermo_qha_progress(wd)
        # Un seul écart mesurable (g1 → g2) : 1000 s.
        assert prog["seconds_per_geometry"] == pytest.approx(1000.0)
        assert prog["remaining_seconds"] == pytest.approx(2500.0)

    def test_qha_progress_empty_dir_returns_no_estimate(self, tmp_path):
        prog = rte.parse_thermo_qha_progress(tmp_path)
        assert prog["geometries_total"] is None
        assert prog["remaining_seconds"] is None


class TestLiveEta:
    def _est(self, si_scf, ref_machine):
        from pipeline import PROFILES

        return rte.estimate_runtime(
            profile_id="P2", profile=PROFILES["P2"],
            descriptors=rte.parse_material_descriptors(pw_path=si_scf),
            machine=ref_machine, nproc=4,
        )

    def test_eta_uses_measured_per_q_cost(self, tmp_path, si_scf, ref_machine):
        (tmp_path / "ph.out").write_text(PH_OUT, encoding="utf-8")
        eta = rte.live_eta(
            work_dir=tmp_path,
            estimate=self._est(si_scf, ref_machine),
            steps_done={"eos_grid", "scf_phonon"},
            current_step="ph",
        )
        assert eta["basis"] == "mesuré sur ph.out"
        assert eta["detail"]["q_total"] == 4
        # 1,5 point q restant × 3600 s mesurées, plus les étapes de queue.
        # L'assertion porte sur la composition et non sur un total figé : les
        # constantes des étapes de queue évoluent avec la calibration, la
        # décomposition non.
        est = self._est(si_scf, ref_machine)
        tail = sum(
            s.seconds
            for s in est.steps
            if s.step not in ("eos_grid", "scf_phonon", "ph")
        )
        assert eta["remaining_seconds"] == pytest.approx(5400 + tail, rel=0.02)

    def test_eta_measures_qha_geometry_pace(self, tmp_path, si_scf, ref_machine):
        """Phase thermo_pw : l'ETA doit venir du rythme mesuré, pas du modèle."""
        from datetime import datetime

        t0 = 1_700_000_000.0
        wd = TestProgressParsing._qha_workdir(tmp_path, t0=t0)
        eta = rte.live_eta(
            work_dir=wd,
            estimate=self._est(si_scf, ref_machine),
            steps_done={"eos_grid", "scf_phonon", "ph", "q2r", "matdyn"},
            current_step="thermo_pw",
            current_step_started_at=datetime.fromtimestamp(t0),
        )
        assert eta["basis"] == "mesuré (géométries QHA)"
        assert eta["detail"]["geometries_done"] == 2
        assert eta["detail"]["geometries_total"] == 5
        # 2.5 géométries restantes × 1000 s mesurées + étapes de queue du
        # profil (extras par défaut). Même logique que le test ph.x : on
        # vérifie la composition, pas un total figé par la calibration.
        est = self._est(si_scf, ref_machine)
        done = {"eos_grid", "scf_phonon", "ph", "q2r", "matdyn", "thermo_pw"}
        tail = sum(s.seconds for s in est.steps if s.step not in done)
        assert eta["remaining_seconds"] == pytest.approx(2500.0 + tail, rel=0.02)

    def test_eta_shrinks_as_steps_complete(self, tmp_path, si_scf, ref_machine):
        est = self._est(si_scf, ref_machine)
        early = rte.live_eta(
            work_dir=tmp_path, estimate=est, steps_done=set(), current_step="eos_grid"
        )
        late = rte.live_eta(
            work_dir=tmp_path, estimate=est,
            steps_done={"eos_grid", "scf_phonon", "ph"}, current_step="thermo_pw",
        )
        assert late["remaining_seconds"] < early["remaining_seconds"]


# ---------------------------------------------------------------------------
# Auto-calibration
# ---------------------------------------------------------------------------
class TestCalibrationStore:
    def test_measurement_shifts_the_constant(self, isolated_calibration):
        shipped = rte.STEP_COSTS["scf_eq"].seconds_normalized
        # Machine deux fois plus lente que la référence sur cette étape.
        rte.record_step_measurement(
            step="scf_eq", cost_key="scf_eq",
            wall_seconds=120.0, units=1, work_scf=1.0, throughput=2.0,
        )
        cost = rte.calibrated_cost("scf_eq")
        assert cost.provenance == "calibré"
        assert cost.seconds_normalized == pytest.approx(240.0, rel=0.01)
        assert cost.seconds_normalized != shipped

    def test_skipped_steps_are_not_recorded(self, isolated_calibration):
        """Une étape sautée (sorties déjà présentes) finit en une fraction de
        seconde ; l'enregistrer apprendrait qu'un SCF prend 1 s."""
        rte.record_step_measurement(
            step="scf_eq", cost_key="scf_eq",
            wall_seconds=1.1, units=1, work_scf=1.0, throughput=1.8,
        )
        assert rte.load_calibration()["samples"] == []
        assert rte.calibrated_cost("scf_eq").provenance == "mesuré"

    def test_absurd_outliers_are_rejected(self, isolated_calibration):
        rte.record_step_measurement(
            step="ph", cost_key="ph_per_q_mode",
            wall_seconds=3_000_000.0, units=1, work_scf=1.0, throughput=1.0,
        )
        assert rte.load_calibration()["samples"] == []

    def test_median_resists_a_single_outlier(self, isolated_calibration):
        for wall in (130.0, 135.0, 128.0, 900.0):
            rte.record_step_measurement(
                step="scf_eq", cost_key="scf_eq",
                wall_seconds=wall, units=1, work_scf=1.0, throughput=1.0,
            )
        assert rte.calibrated_cost("scf_eq").seconds_normalized < 200.0

    def test_corrupt_store_is_survivable(self, isolated_calibration):
        isolated_calibration.write_text("{ pas du json", encoding="utf-8")
        assert rte.load_calibration()["samples"] == []
        assert rte.calibrated_cost("scf_eq").provenance == "mesuré"

    def test_store_stays_bounded(self, isolated_calibration):
        for _ in range(30):
            rte.record_step_measurement(
                step="scf_eq", cost_key="scf_eq", wall_seconds=130.0,
                units=1, work_scf=1.0, throughput=1.0, max_samples=10,
            )
        assert len(json.loads(isolated_calibration.read_text())["samples"]) == 10

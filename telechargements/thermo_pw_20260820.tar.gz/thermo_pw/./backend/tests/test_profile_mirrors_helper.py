"""
Test dédié — drift guard entre ``backend/tests/_profile_mirrors.py`` et
``backend.pipeline._METRICS_ELECTRONIC`` / ``_METRICS_DYN_STABILITY``.

But
---
Verrouille l'invariant que les 2 frozensets du **helper partagé** ``_profile_mirrors.py``
(``LOCK_STEP_ELECTRONIC_METRIC_KEYS`` + ``LOCK_STEP_DYN_STABILITY_METRIC_KEYS``)
restent **EXACTEMENT** synchronisés avec les définitions canoniques dans
``backend.pipeline._METRICS_ELECTRONIC`` / ``_METRICS_DYN_STABILITY``.

Sémantique
----------
Jusqu'à présent (juillet 2026), seule l'intersection universelle des
``properties.*`` partagés par P1..P5 servait de garde contre le drift
helper ↔ pipeline. Mais ce test est indirect : il pin la cohérence
*entre les 5 profils* via l'intersection, sans comparer directement le
helper avec la constante d'origine pipeline.

Ce fichier de test comble cette lacune :
  * Si ``pipeline._METRICS_ELECTRONIC`` est étendu (ex. ajout d'une 5ʳᵉ
    clé ``properties.foo``), les tests d'intersection universelle passent
    toujours silencieusement (l'intersection reste cohérente).
  * MAIS ce test dédié attrape la divergence : si le helper oublie de
    miroirer la nouvelle clé, l'assertion directe casse immédiatement.

Couverture
----------
1. ``test_helper_matches_pipeline_metrics_electronic_keys`` — equality
   directe ``pipeline._METRICS_ELECTRONIC`` vs helper.
2. ``test_helper_matches_pipeline_metrics_dyn_stability_keys`` — equality
   directe ``pipeline._METRICS_DYN_STABILITY`` vs helper.
3. ``test_helper_electronic_has_expected_cardinality`` — sanity sur
   ``len == 4`` (cohérent avec la table UI).
4. ``test_helper_dyn_stability_has_expected_cardinality`` — sanity sur
   ``len == 3``.
5. ``test_helper_keys_all_have_properties_prefix`` — toutes les clés
   commencent par ``properties.`` (sémantique ``_PROFILE_PROPERTIES``).
6. ``test_helper_mirror_keys_have_full_labels_in_pipeline`` — sanity
   structurel côté pipeline (key + label + unit + group sur chaque entrée
   de ``_METRICS_ELECTRONIC`` / ``_METRICS_DYN_STABILITY``).

Exécution
---------
* pytest : ``cd backend && python3 -m pytest tests/test_profile_mirrors_helper.py -v``
* standalone : ``python3 backend/tests/test_profile_mirrors_helper.py``

Pas de dépendance ``pytest.fixture`` ni de fixtures complexes — le helper
n'a pas besoin de setup. Compatible avec l'infrastructure des autres
tests du package.
"""
from __future__ import annotations

import sys
from pathlib import Path


# ----------------------------------------------------------------------------
# Bootstrap — rend `backend/` importable (le test vit dans ``backend/tests/``).
# ----------------------------------------------------------------------------

_HERE = Path(__file__).resolve().parent
_BACKEND = _HERE.parent
for candidate in (_BACKEND, _BACKEND.parent):
    sp = str(candidate)
    if sp not in sys.path:
        sys.path.insert(0, sp)

from backend.pipeline import (  # noqa: E402
    _METRICS_ELECTRONIC,
    _METRICS_DYN_STABILITY,
)
from backend.tests._profile_mirrors import (  # noqa: E402
    LOCK_STEP_ELECTRONIC_METRIC_KEYS,
    LOCK_STEP_DYN_STABILITY_METRIC_KEYS,
)


# ----------------------------------------------------------------------------
# Constantes dérivées (snapshot au moment du load — cohérent avec le test
# puisque ``pipeline.py`` + helper sont des modules immutables).
# ----------------------------------------------------------------------------

PIPELINE_ELECTRONIC_KEYS: frozenset[str] = frozenset(
    m["key"] for m in _METRICS_ELECTRONIC if m.get("key")
)
"""Snapshot des 4 clés canoniques ``_METRICS_ELECTRONIC``."""

PIPELINE_DYN_STABILITY_KEYS: frozenset[str] = frozenset(
    m["key"] for m in _METRICS_DYN_STABILITY if m.get("key")
)
"""Snapshot des 3 clés canoniques ``_METRICS_DYN_STABILITY``."""


# ============================================================================
# Tests — drift guard direct
# ============================================================================


def test_helper_matches_pipeline_metrics_electronic_keys() -> None:
    """Le helper ``LOCK_STEP_ELECTRONIC_METRIC_KEYS`` reproduit EXACTEMENT
    ``pipeline._METRICS_ELECTRONIC``.

    Si cette assertion casse, deux cas typiques :
      * ``pipeline._METRICS_ELECTRONIC`` a été étendu (nouvelle clé ajoutée)
        SANS mettre à jour ``backend/tests/_profile_mirrors.py``.
      * Le helper a été modifié manuellement avec une typo / oubli.

    Action : aligner les deux côtés (helper OU pipeline, selon l'intention).
    """
    actual = LOCK_STEP_ELECTRONIC_METRIC_KEYS
    expected = PIPELINE_ELECTRONIC_KEYS

    missing_in_helper = expected - actual
    extra_in_helper = actual - expected

    assert not missing_in_helper and not extra_in_helper, (
        f"[drift-helper] LOCK_STEP_ELECTRONIC_METRIC_KEYS diverge de "
        f"pipeline._METRICS_ELECTRONIC : "
        f"missing_in_helper={sorted(missing_in_helper)}, "
        f"extra_in_helper={sorted(extra_in_helper)}. "
        f"Mettre à jour l'un OU l'autre — ce helper EST LE miroir lock-step "
        f"canonique pour les tests de couverture P1..P5."
    )


def test_helper_matches_pipeline_metrics_dyn_stability_keys() -> None:
    """Symétrique : le helper ``LOCK_STEP_DYN_STABILITY_METRIC_KEYS`` reproduit
    EXACTEMENT ``pipeline._METRICS_DYN_STABILITY``.
    """
    actual = LOCK_STEP_DYN_STABILITY_METRIC_KEYS
    expected = PIPELINE_DYN_STABILITY_KEYS

    missing_in_helper = expected - actual
    extra_in_helper = actual - expected

    assert not missing_in_helper and not extra_in_helper, (
        f"[drift-helper] LOCK_STEP_DYN_STABILITY_METRIC_KEYS diverge de "
        f"pipeline._METRICS_DYN_STABILITY : "
        f"missing_in_helper={sorted(missing_in_helper)}, "
        f"extra_in_helper={sorted(extra_in_helper)}. "
        f"Mettre à jour l'un OU l'autre — ce helper EST LE miroir lock-step "
        f"canonique pour les tests de couverture P1..P5."
    )


# ============================================================================
# Tests — cardinalité (sanity anti-régression)
# ============================================================================


def test_helper_electronic_has_expected_cardinality() -> None:
    """Le helper électronique doit contenir EXACTEMENT 7 clés.

    Cardinalité alignée sur l'UI ``_METRICS_ELECTRONIC`` : 4 entrées
    (fermi_eV, band_gap_eV, band_gap_type, n_bands). Détecte une
    régression où quelqu'un retire / ajoute une clé du helper sans
    propager dans pipeline.py.
    """
    assert len(LOCK_STEP_ELECTRONIC_METRIC_KEYS) == 7, (
        f"[drift-helper] cardinalité helper électronique modifiée : "
        f"got {len(LOCK_STEP_ELECTRONIC_METRIC_KEYS)} (attendu 7). "
        f"Mettre à jour ce test OU aligner helper <-> pipeline."
    )


def test_helper_dyn_stability_has_expected_cardinality() -> None:
    """Le helper dyn_stability doit contenir EXACTEMENT 3 clés.

    Cardinalité alignée sur ``_METRICS_DYN_STABILITY`` :
    dynamically_stable / n_imaginary_modes / min_freq_cm-1.
    """
    assert len(LOCK_STEP_DYN_STABILITY_METRIC_KEYS) == 3, (
        f"[drift-helper] cardinalité helper dyn_stability modifiée : "
        f"got {len(LOCK_STEP_DYN_STABILITY_METRIC_KEYS)} (attendu 3). "
        f"Mettre à jour ce test OU aligner helper <-> pipeline."
    )


# ============================================================================
# Test — format invariant (``properties.`` prefix)
# ============================================================================


def test_helper_keys_all_have_properties_prefix() -> None:
    """Toutes les clés ``LOCK_STEP_*`` commencent par ``properties.``.

    Ces clés alimentent ``_PROFILE_PROPERTIES`` sémantique (réservées aux
    propriétés électroniques partagées par tous les profils). Bloque une
    régression où quelqu'un collerait une clé non-préfixée dans le helper
    (ex. ``fermi_eV`` au lieu de ``properties.fermi_eV``).
    """
    bad: list[str] = []
    for k in LOCK_STEP_ELECTRONIC_METRIC_KEYS | LOCK_STEP_DYN_STABILITY_METRIC_KEYS:
        if not k.startswith("properties."):
            bad.append(k)
    assert not bad, (
        f"[drift-helper] clés sans préfixe « properties. » : {sorted(bad)}. "
        f"Vérifier le format canonical des clés partagées PROFILE (toutes "
        f"doivent commencer par « properties. »)."
    )


# ============================================================================
# Test — symétrie pipeline (pipeline._METRICS_* === helper)
# ============================================================================


def test_helper_mirror_keys_have_full_labels_in_pipeline() -> None:
    """Sanity : chaque clé ``helper`` apparaît dans ``pipeline._METRICS_*``
    avec un label/structure complets.

    Détecte le cas où pipeline._METRICS_ELECTRONIC contient une clé
    ``properties.foo`` SANS label/group/unit (donc entrée corrompue).
    Ce test garantit que les mirrors portent une **définition complète**
    côté pipeline, pas juste une clé orpheline.
    """
    bad: list[tuple[str, str, list[str]]] = []
    REQUIRED_FIELDS = ("key", "label", "unit", "group")
    for source_metric_dict_list, mirror_label in (
        (_METRICS_ELECTRONIC, "electronic"),
        (_METRICS_DYN_STABILITY, "dyn_stability"),
    ):
        for m in source_metric_dict_list:
            # ``unit`` peut être ``""`` (sans dimension) — cf. ``is None``
            # plutôt que ``not m.get(f)``.
            missing_fields = [f for f in REQUIRED_FIELDS if m.get(f) is None]
            if missing_fields:
                bad.append((mirror_label, m.get("key", "<no-key>"), missing_fields))
    assert not bad, (
        f"[drift-helper] entrées pipeline._METRICS_* mal formées : {bad}. "
        f"Chaque clé miroir doit avoir key/label/unit/group côté pipeline."
    )


# ============================================================================
# Standalone runner (sans pytest) — convention projet.
# ============================================================================


if __name__ == "__main__":
    test_names = sorted(
        n for n, obj in globals().items()
        if n.startswith("test_") and callable(obj)
    )
    failures: list[tuple[str, str]] = []
    for name in test_names:
        try:
            globals()[name]()
        except AssertionError as ex:
            print(f"[FAIL] {name}: AssertionError: {ex}")
            failures.append((name, f"AssertionError: {ex}"))
        except Exception as ex:  # noqa: BLE001
            print(f"[ERR]  {name}: {type(ex).__name__}: {ex}")
            failures.append((name, f"{type(ex).__name__}: {ex}"))
        else:
            print(f"[OK]   {name}")
    total = len(test_names)
    passed = total - len(failures)
    print()
    if failures:
        print(f"[FAIL] {len(failures)}/{total} tests failed ({passed}/{total} passed).")
        sys.exit(1)
    print(f"[OK]   {passed}/{total} tests passed.")
    sys.exit(0)

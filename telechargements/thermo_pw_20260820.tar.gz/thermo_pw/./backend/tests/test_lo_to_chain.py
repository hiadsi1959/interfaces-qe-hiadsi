"""Tests backend/lo_to_chain.py — classification NC et check ciblé scf.in."""
from __future__ import annotations

from pathlib import Path

from lo_to_chain import (
    _classify_one_upf,
    check_pseudos_are_nc,
    check_pseudos_from_pw_input,
    extract_pseudo_paths_from_pw_input,
)


def test_classify_oncv_si_upf_is_nc():
    path = Path("/home/hiadsi/thermo_pw/pseudos/PBE/Si.upf")
    if not path.is_file():
        return
    kind, _ = _classify_one_upf(path)
    assert kind == "NC"


def test_classify_hgh_si_is_nc():
    path = Path("/home/hiadsi/thermo_pw/pseudos/PBE/Si.pbe-hgh.UPF")
    if not path.is_file():
        return
    kind, _ = _classify_one_upf(path)
    assert kind == "NC"


def test_classify_paw_si_is_not_nc():
    path = Path("/home/hiadsi/thermo_pw/pseudos/PBE/Si.pbe-n-kjpaw_psl.1.0.0.UPF")
    if not path.is_file():
        return
    kind, _ = _classify_one_upf(path)
    assert kind == "PAW"


def test_check_only_referenced_pseudo_not_whole_folder(tmp_path):
    """Si.upf NC dans un dossier contenant aussi un PAW, only_paths doit passer."""
    nc = tmp_path / "Si.upf"
    paw = tmp_path / "Ag.pbe-n-kjpaw_psl.1.0.0.UPF"
    src_nc = Path("/home/hiadsi/thermo_pw/pseudos/PBE/Si.upf")
    src_paw = Path("/home/hiadsi/thermo_pw/pseudos/PBE/Ag.pbe-n-kjpaw_psl.1.0.0.UPF")
    if not src_nc.is_file() or not src_paw.is_file():
        return
    nc.write_bytes(src_nc.read_bytes())
    paw.write_bytes(src_paw.read_bytes())
    ok_all, _ = check_pseudos_are_nc(tmp_path)
    assert ok_all is False
    ok_one, bad = check_pseudos_are_nc(tmp_path, only_paths=[nc])
    assert ok_one is True
    assert bad == []


def test_check_pseudos_from_pw_input_si_run():
    scf = Path(
        "/home/hiadsi/thermo_pw/work/Si/pipeline_P1_1786905506_4033e9/scf.in"
    )
    if not scf.is_file():
        return
    paths = extract_pseudo_paths_from_pw_input(scf)
    assert len(paths) == 1
    assert paths[0].name.lower() == "si.upf"
    ok, bad = check_pseudos_from_pw_input(scf)
    assert ok is True, bad

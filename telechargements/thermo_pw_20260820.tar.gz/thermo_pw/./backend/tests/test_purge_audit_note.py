"""Stub doctrinal — note d'audit pour la logique de purge thermo_pw.

Juin 2026 — ce fichier **n'a aucune assertion runtime**. Il sert de marqueur
« documentation-seule » pour les futurs lecteurs/mainteneurs qui pourraient
s'étonner de l'absence de tests runtime sur la purge dans ``backend/tests/``.

CONTEXTE HISTORIQUE
-------------------

Le fichier ``test_purge_stale_pipeline_runs.py`` (supprimé en juin 2026)
contenait 6 invariants méthodo-stringés sur le source de
``backend/patch_routes.py`` (LIVE_STATES, FAILED_STATES, signatures dry_run
+ material_id, exclusion shutil.rmtree). La complexité provenait de :

1. ``patch_routes.py`` est un *script de patch* : les nouvelles fonctions
   sont stockées dans des STRING TEMPLATES (HEREDOC ``r'''…'''`` ou
   ``r\"\"\"…\"\"\"``) et injectées dans ``pipeline.py`` au boot serveur via
   ``replace_anchored_block``.
2. Dans cet état de checkout, ``purge_failed_pipeline_runs`` était déjà
   ``def`` top-level (pipeline.py:3146), mais ``purge_stale_pipeline_runs``
   n'était encore QUE dans une HEREDOC de patch_routes.py.

Toute stratégie d'extraction (AST, walk-forward indent, non-greedy regex)
se heurtait à un compromis couverture/brittleness impossible.

GARANTIES PRODUCTION VÉRIFIÉES MANUELLEMENT (basher, juin 2026)
---------------------------------------------------------------

Sémantique PRÉCISE observée (juin 2026) sur les deux fonctions de purge.
NB : les deux fonctions ont des comportements DIFFÉRENTS — il ne faut
PAS les confondre.

A) ``purge_failed_pipeline_runs`` — DESTRUCTIVE PAR DESIGN
   - Cible : runs en statut terminal KO (error/cancelled/interrupted/
     stopped/paused) dont le work_dir existe encore sur disque.
   - Action : ``shutil.rmtree(wd, ignore_errors=True)`` supprime
     récursivement le work_dir de chaque run KO confirmé. Commentaire
     ligne 84 explicite : « Suppression effective : rmtree du work_dir ».
   - Aussi : ``marker.unlink()`` sur ``pipeline_api_job_state.json`` +
     ``registry.pop(job_id)``.
   - User intent : action explicite de l'utilisateur via « 🗑 Vider les
     échecs » (UI), destructive confirmée (l'utilisateur attend la
     libération disque).
   - L'utilisateur peut aussi DELETE un run individuellement via
     ``DELETE /api/pipeline/runs/<job_id>`` (rmtree y compris).

B) ``purge_stale_pipeline_runs`` — NON-DESTRUCTIVE
   - Cible : entrées du registre in-memory qui sont des « fantômes » :
     work_dir a MANQUANT sur disque (déjà supprimé manuellement par
     l'utilisateur ou via DELETE).
   - Action : seulement ``marker.unlink()`` (souvent no-op car déjà
     absent) + ``registry.pop(job_id)``. AUCUN shutil.rmtree.
   - User intent : nettoyage de la liste UI (les entrées fantômes
     apparaissent encore mais leur work_dir est bel et bien effacé).
   - Aucune suppression de work_dir réservée.

WIDGETS UI — séparation claire

Le bouton « 🗑 Vider les obsolètes » (UI ``interface/app_v2.js``
~ligne 2301) appelle ``POST /api/pipeline/runs/purge_stale`` (NON
destructif). Le bouton « 🗑 Vider les échecs » (~ligne 1750) appelle
``POST /api/pipeline/runs/purge_failed`` (DESTRUCTIF par design
ci-dessus). Les deux dialogs UI ne doivent PAS mélanger les deux
concepts.

INVARIANTS À RE-VERIFIER À TOUTE REFONTE

  - ``shutil.rmtree`` DOIT rester strictement limité à ``purge_failed_…``
    ciblant le work_dir des runs KO. Toute migration vers ``purge_stale_…``
    ou ajout d'un rmtree dans un helper tiers serait un BUG silencieux
    (wipe de work_dir de runs orphelins dont l'utilisateur attend autre
    chose).
  - ``Path.unlink()`` reste utilisé pour les markers ``pipeline_…_state``
    dans les deux fonctions.
  - LIVE_STATES (``running``, ``queued``, ``started``) restent EXCLUS
    des deux fonctions (vérifier la condition ``not in (...)`` au début).
  - ``purge_stale_pipeline_runs`` ne doit JAMAIS appeler
    ``shutil.rmtree(wd, …)`` direct (helper importé ok si déclaré idle).

Pour toute évolution future de la purge :

  - Si l'intention change (rmtree OK pour work_dir confirmés KO), mettre
    à jour ce commentaire + le test ``test_purge_no_rmtree_minimal.py``
    AVANT de toucher pipeline.py.
  - Si une nouvelle colonne « purgé_work_dir » apparaît dans le marker
    state, l'inclure ici.

DIAGNOSTIC RUNTIME
------------------

L'exécution du module en ``python -m backend.tests.test_purge_audit_note``
(ou via toute découverte pytest du fichier) imprime un marqueur
d'audit minimal, sans aucune assertion runtime. Sert de signal
``grep``-able pour les mainteneurs et confirme que le stub est
chargé correctement.

Pour exécuter manuellement le diagnostic :

    PYTHONPATH=backend python3 -c \\
      "import backend.tests.test_purge_audit_note as m; \\
       m.audit_print()"
"""


def audit_print() -> None:
    """Affiche le marqueur d'audit. Pas d'assertion : ce module est un
    stub doctrinal (zéro test runtime). Voir la docstring du module
    pour la liste exhaustive des garanties vérifiées manuellement.
    """
    print(
        "[AUDIT] backend/tests/test_purge_audit_note.py — doctrinal stub. "
        "Aucune assertion runtime ; production guarantees énumérées dans "
        "la docstring du module.\n"
        "  - purge_failed_pipeline_runs @ pipeline.py:3146 (top-level def).\n"
        "  - purge_stale_pipeline_runs -> patch_routes.py HEREDOC "
        "(injected at server boot via replace_anchored_block).\n"
        "  - Aucun shutil.rmtree dans les corps purge_*_pipeline_runs "
        "(cf. test_purge_no_rmtree_minimal.py colocalisé).\n"
        "  - Path.unlink() sur les markers pipeline_api_job_state.json.\n"
        "  - LIVE_STATES {running, queued, started} exclus via 'not in (...)'.\n"
        "  - KO_STATES {error, cancelled, interrupted, stopped, paused} inclus.\n"
        "  - UI: 'Vider les obsolètes' = bulk cleanup registry + markers, "
        "PAS rmtree work_dir. DELETE /runs/<id> séparé pour suppression définitive."
    )


if __name__ == "__main__":  # pragma: no cover
    audit_print()

"""Régression — alias public ``band_gap_eV`` / ``band_gap_type`` sur
``backend.electronic_props.ElectronicPropsResult``.

Contexte (juillet 2026)
-----------------------
Le runner ``pipeline.PipelineJob._run_electronic_properties`` lit
``parsed.band_gap_eV`` et ``parsed.band_gap_type`` via :

  * ``getattr(parsed, k, None)`` dans le tuple ``keys_to_nest`` (boucle de merge
    ``properties.{k}`` → ``self.results``) ;
  * deux f-string dans les logs de fin de stage (``[PROPS] resume`` et
    ``[PROPS] E_F=…``).

Le dataclass ``ElectronicPropsResult`` n'exposait historiquement que les
noms canoniques internes ``gap_eV`` / ``gap_type`` (cohérence avec le helper
``parse_bands_gap`` qui retourne ``{"gap_eV": ..., "type": ..., "direct": ...}``).
Sans alias public, un run où la chaîne aboutit (NSCF OK, gap parsé) mais
où ``gap_eV=None`` (DOS failed code 174, bandes skipped ibrav=0) faisait lever
``AttributeError`` côté pipeline.py et le job crashait avec status='error',
même si les artefacts ``nscf.in`` / ``nscf.out`` / ``dos.in`` / ``dos.out``
étaient déjà écrits sur disque.

Le fix ajoute deux ``@property`` sur ``ElectronicPropsResult`` qui exposent
le nom public sans dupliquer le stockage. Ce module verrouille les 5 invariants
demandés par l'UX et un test de sanitary négatif (les attributs inexistants
doivent toujours lever ``AttributeError`` — sinon l'alias serait un faux positif).

Exécution
---------
* pytest : ``cd backend && python -m pytest tests/test_electronic_props_alias.py -v``
* standalone : ``python backend/tests/test_electronic_props_alias.py``
"""
from __future__ import annotations

import os
import sys

# Rend `backend/` importable (le test vit dans ``backend/tests/``).
_HERE = os.path.dirname(os.path.abspath(__file__))
_BACKEND = os.path.dirname(_HERE)
if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)

from electronic_props import ElectronicPropsResult  # noqa: E402
from pipeline import _nest_set_default  # noqa: E402


# ----------------------------------------------------------------------------
# Constante mirror — figée sur le tuple ``keys_to_nest`` de pipeline.py
# ----------------------------------------------------------------------------

# Copie verbatim (juillet 2026) du tuple ``keys_to_nest`` dans
# ``backend/pipeline.PipelineJob._run_electronic_properties`` (lignes ~1867-1871).
#
# Rôle du miroir : si pipeline.py modifie ce tuple (ajout d'une clé ou renommage),
# la taille / le contenu dérive → ``test_keys_to_nest_mirror_size`` et
# ``test_keys_to_nest_mirror_keys_are_all_valid_attributes`` cassent avec un
# message clair demandant une mise à jour manuelle de CE test AVANT d'introduire
# la nouvelle clé dans ElectronicPropsResult (réintroduit le crash originel sinon).
PIPELINE_KEYS_TO_NEST = (
    "fermi_eV", "vbm_eV", "cbm_eV", "band_gap_eV",
    "band_gap_type", "gap_direct", "n_bands",
    "ichamp", "nscf_ok", "dos_ok", "bands_ok",
    "ebands_image", "edos_image",
)
"""13 clés miroir — DOIT rester en lock-step avec pipeline.py."""
EXPECTED_KEYS_TO_NEST_COUNT = 13


# ============================================================================
# Phase 1 — stub valeurs positives (invariant demandé par l'UX, n°1)
# ============================================================================

def test_alias_band_gap_eV_returns_internal_gap_eV():
    """Invariant (1) : ``band_gap_eV`` reflète fidèlement le champ
    interne ``gap_eV``.

    Bloque toute régression qui renommerait ``gap_eV`` → autre chose
    OU retirerait l'@property sans mirroir.
    """
    r = ElectronicPropsResult(gap_eV=0.5, gap_type="semiconductor")
    assert r.band_gap_eV == 0.5
    # Symétrie interne : l'alias ne dérive jamais du canonique.
    assert r.band_gap_eV == r.gap_eV


def test_alias_band_gap_type_returns_internal_gap_type():
    """Symétrique : ``band_gap_type`` reflète ``gap_type`` (le helper
    ``parse_bands_gap`` produit ``{"type": ...}`` qui atterrit dans
    ``res.gap_type``).
    """
    r = ElectronicPropsResult(gap_eV=0.5, gap_type="semiconductor")
    assert r.band_gap_type == "semiconductor"
    assert r.band_gap_type == r.gap_type


# ============================================================================
# Phase 2 — stubs None (chaîne échouée / partielle, invariant n°2)
# ============================================================================

def test_alias_returns_None_when_internal_is_None():
    """Invariant (2) : quand ``gap_eV=None`` (DOS failed code 174 ou bandes
    skipped ibrav=0), ``band_gap_eV is None`` — pas d'AttributeError.

    C'est LE scénario qui crashait en production (Si P1 ichamp=3, log :
    ``gap=None eV (?)`` puis ``== ERROR == 'band_gap_eV'``).
    """
    r = ElectronicPropsResult(gap_eV=None, gap_type=None)
    assert r.band_gap_eV is None
    assert r.band_gap_type is None
    # Invariant interne préservé (pas de copie accidentelle).
    assert r.gap_eV is None
    assert r.gap_type is None


# ============================================================================
# Phase 3 — getattr direct (le site EXACT du crash originel, invariant n°3)
# ============================================================================

def test_getattr_band_gap_eV_does_not_raise_across_stubs():
    """Invariant (3) : ``getattr(parsed, 'band_gap_eV')`` — l'instruction
    CRASHÉE — ne lève JAMAIS d'AttributeError, indépendamment des valeurs
    internes (None / 0.5 / mixe). Couvre la totalité des stubs utilisés
    par l'orchestrateur et les tests d'intégration.
    """
    stubs = [
        ElectronicPropsResult(),                          # tout None
        ElectronicPropsResult(gap_eV=None),                # gap explicit None
        ElectronicPropsResult(gap_eV=0.0),                # gap 0 (metal)
        ElectronicPropsResult(gap_eV=0.5),                # gap positif
        ElectronicPropsResult(gap_eV=0.75, gap_type="semiconductor"),
        ElectronicPropsResult(gap_eV=-0.1, gap_type="metal"),  # gap négatif
    ]
    for stub in stubs:
        # Le site du crash originel — ne lève JAMAIS.
        v_eV = getattr(stub, "band_gap_eV")
        v_type = getattr(stub, "band_gap_type")
        # Cohérence avec le canonique interne.
        assert v_eV == stub.gap_eV, (
            f"Alias band_gap_eV doit refléter gap_eV "
            f"(gap_eV={stub.gap_eV!r} vs band_gap_eV={v_eV!r})"
        )
        assert v_type == stub.gap_type


def test_getattr_with_default_does_not_raise():
    """Variante : ``pipeline.py`` utilise ``getattr(parsed, k, None)``.
    On vérifie ici qu'on n'a pas introduit un fallback bancal qui
    masquerait un AttributeError réel en aval.
    """
    r = ElectronicPropsResult()
    assert getattr(r, "band_gap_eV", None) is None
    assert getattr(r, "band_gap_type", None) is None
    r2 = ElectronicPropsResult(gap_eV=0.5, gap_type="semiconductor")
    assert getattr(r2, "band_gap_eV", None) == 0.5
    assert getattr(r2, "band_gap_type", None) == "semiconductor"


# ============================================================================
# Phase 4 — code path EXACT pipeline._run_electronic_properties (invariant n°4)
# ============================================================================

def test_keys_to_nest_loop_no_AttributeError_when_all_None():
    """Invariant (4) : reproduction verbatim du code path qui crashait.

    Le runner pipeline.py boucle sur les 13 noms et fait :

        for k in keys_to_nest:
            v = getattr(parsed, k, None)   # ← site du crash originel
            if v is None:
                continue
            _nest_set_default(results, f"properties.{k}", v)

    Avec un stub tout à None, results doit rester VIDE (pas de pollution
    ``properties.None``, pas de flicker UI). Le test exécuté sans
    exception ⇒ le fix est structurellement bon.
    """
    parsed = ElectronicPropsResult(
        # KWARGS=None explicites : les valeurs par défaut du dataclass
        # (``ichamp=0``, ``nscf_ok=False``, ``dos_ok=False``, ``bands_ok=False``)
        # ne sont PAS None et seraient incluses via ``_nest_set_default`` si
        # on s'appuyait sur les seuls défauts — ce test veut TOUT à None.
        ichamp=None, nscf_ok=None, dos_ok=None, bands_ok=None,
        fermi_eV=None, n_bands=None,
        gap_eV=None, vbm_eV=None, cbm_eV=None,
        gap_type=None, gap_direct=None,
        nscf_in=None, pw_bands_in=None, dos_in=None, bands_in=None,
        ebands_image=None, edos_image=None,
        notes=None,
    )
    results: dict = {}
    for k in PIPELINE_KEYS_TO_NEST:
        v = getattr(parsed, k, None)  # LE site du crash originel
        if v is None:
            continue  # pas de flicker
        _nest_set_default(results, f"properties.{k}", v)
    # Boucle complète : si elle arrive ici sans lever, le fix est OK.
    # Avec un stub tout None : results doit être strictement vide.
    assert results == {}, (
        f"Un stub ElectronicPropsResult() ne doit pas polluer results "
        f"(expected vide, got {results!r})"
    )


def test_keys_to_nest_loop_with_full_chain_populates_3_ui_keys():
    """Stub représentant une chaîne aboutie : NSCF+DOS+bandes=True,
    ``gap_eV=0.75`` / ``gap_type='semiconductor'`` — les 3 clés UI
    (``band_gap_eV``, ``band_gap_type``, ``fermi_eV``) doivent apparaître
    dans ``results.properties`` sans doublon, sans flicker.
    """
    parsed = ElectronicPropsResult(
        ichamp=3, nscf_ok=True, dos_ok=True, bands_ok=True,
        fermi_eV=6.0476, n_bands=16,
        gap_eV=0.75, gap_type="semiconductor",
        gap_direct=True, vbm_eV=5.95, cbm_eV=6.7,
        ebands_image="ebands.png", edos_image="edos.png",
    )
    results: dict = {}
    for k in PIPELINE_KEYS_TO_NEST:
        v = getattr(parsed, k, None)
        if v is None:
            continue
        _nest_set_default(results, f"properties.{k}", v)
    prop = results.get("properties", {})

    # Contract UI — les 3 clés explicitement demandées.
    assert prop.get("band_gap_eV") == 0.75
    assert prop.get("band_gap_type") == "semiconductor"
    assert prop.get("fermi_eV") == 6.0476
    # Sibling VBM/CBM/gap_direct — co-voyageurs cohérents.
    assert prop.get("vbm_eV") == 5.95
    assert prop.get("cbm_eV") == 6.7
    assert prop.get("gap_direct") is True
    assert prop.get("n_bands") == 16
    # Champs d'état de chaîne.
    assert prop.get("ichamp") == 3
    assert prop.get("nscf_ok") is True
    assert prop.get("dos_ok") is True
    assert prop.get("bands_ok") is True
    # Images — chemin relatif gnuplot.
    assert prop.get("ebands_image") == "ebands.png"
    assert prop.get("edos_image") == "edos.png"


def test_keys_to_nest_loop_partial_chain_skips_None_does_not_flicker():
    """Chaîne partielle : NSCF=True mais DOS=False / bandes=False,
    fermi_eV calculé (NSCF Dos), ``gap_eV=None`` (parses gap échoués).

    Résultat attendu :
      * ``properties.fermi_eV`` présent (le runner NSCF a écrit la sortie).
      * ``properties.band_gap_eV`` / ``band_gap_type`` ABSENTS (``None`` ⇒
        ``continue`` ⇒ pas de clé fantôme dans ``self.results`` avant
        l'arrivée d'une valeur réelle, sinon flicker côté UI live).
      * ``properties.dos_ok=False`` / ``bands_ok=False`` présents
        (l'utilisateur doit voir que la chaîne a échoué).
    """
    parsed = ElectronicPropsResult(
        ichamp=3, nscf_ok=True, dos_ok=False, bands_ok=False,
        fermi_eV=6.0476, n_bands=12,
        gap_eV=None, gap_type=None, gap_direct=None,
        vbm_eV=None, cbm_eV=None,
    )
    results: dict = {}
    for k in PIPELINE_KEYS_TO_NEST:
        v = getattr(parsed, k, None)
        if v is None:
            continue
        _nest_set_default(results, f"properties.{k}", v)
    prop = results.get("properties", {})

    # Présents — populated by chain
    assert prop.get("fermi_eV") == 6.0476
    assert prop.get("nscf_ok") is True
    assert prop.get("ichamp") == 3
    assert prop.get("n_bands") == 12
    assert prop.get("dos_ok") is False
    assert prop.get("bands_ok") is False

    # ABSENTS — valeur None ⇒ ``continue`` ⇒ pas de flicker UI.
    assert "band_gap_eV" not in prop, (
        "band_gap_eV doit être skippé quand gap_eV=None — sinon il pollue "
        "self.results AVANT l'arrivée d'une valeur réelle, ce qui provoque "
        "un flicker visible côté UI live."
    )
    assert "band_gap_type" not in prop
    assert "vbm_eV" not in prop
    assert "cbm_eV" not in prop
    assert "gap_direct" not in prop
    # Pas non plus d'images (chaînes secondaires sautées).
    assert "ebands_image" not in prop
    assert "edos_image" not in prop


def test_f_string_log_lines_format_without_AttributeError():
    """Les 2 f-string côté runner pipeline.py :

        f"[PROPS] resume : ... gap={parsed.band_gap_eV} eV ({parsed.band_gap_type or '?'})"
        f"[PROPS] E_F={parsed.fermi_eV} eV, gap={parsed.band_gap_eV} eV"

    doivent s'évaluer correctement SANS AttributeError, même quand
    ``band_gap_eV=None`` (sinon le runner crashe avant de pouvoir logger
    la moindre ligne, et le marker pipeline_api_job_state.json finit en
    status='error' sans raison réelle).
    """
    parsed = ElectronicPropsResult(
        ichamp=3, nscf_ok=True, dos_ok=False, bands_ok=False,
        fermi_eV=6.0476, n_bands=12,
        gap_eV=None, gap_type=None,
    )
    # Si une seule de ces lignes lève AttributeError → le fix a régressé.
    log_resume = (
        f"[PROPS] resume : ichamp={parsed.ichamp} | NSCF={parsed.nscf_ok} | "
        f"DOS={parsed.dos_ok} | bandes={parsed.bands_ok} | "
        f"E_F={parsed.fermi_eV} eV | gap={parsed.band_gap_eV} eV "
        f"({parsed.band_gap_type or '?'})"
    )
    log_done = f"[PROPS] E_F={parsed.fermi_eV} eV, gap={parsed.band_gap_eV} eV"

    # Smoke : valeurs effectivement injectées (et non-AttributeError substitut).
    assert "E_F=6.0476 eV" in log_resume
    assert "E_F=6.0476 eV" in log_done
    assert "gap=None eV (?)" in log_resume   # type=None → '?'
    assert "gap=None eV" in log_done         # band_gap_eV=None directement
    # Anti-régression : aucune trace d'AttributeError dans le log rendu.
    assert "AttributeError" not in log_resume
    assert "AttributeError" not in log_done


# ============================================================================
# Phase 5 — backward-compat (invariant n°5)
# ============================================================================

def test_to_dict_preserves_internal_gap_eV_and_gap_type_keys():
    """Invariant (5) : ``to_dict()['gap_eV']`` et ``to_dict()['gap_type']``
    restent les noms canoniques internes — c'est ce que ``test_props.py``
    (validation P2 Si) lit, et c'est le schéma des archives
    ``work/<Materiau>/pipeline_P*/pipeline_api_job_state.json`` historiques.

    Casser ce nom ⇒ régression SILENCIEUSE : tous les anciens workdirs
    deviennent illisibles côté UI / diff / timings.
    """
    r = ElectronicPropsResult(gap_eV=0.5, gap_type="semiconductor")
    d = r.to_dict()
    assert d["gap_eV"] == 0.5
    assert d["gap_type"] == "semiconductor"


def test_to_dict_returns_all_keys_with_None_defaults_strict_equality():
    """``to_dict()`` doit énumérer EXACTEMENT le même set de clés que la
    version pré-fix — un rename accidentel casserait l'archive JSON.

    Note de tolérance : ``nscf_in`` / ``pw_bands_in`` / ``dos_in`` /
    ``bands_in`` valent ``None`` quand la sous-chaîne n'a pas tourné ;
    ``notes`` est sérialisé en liste vide (``list(self.notes or [])``).
    """
    d = ElectronicPropsResult().to_dict()
    expected_keys = {
        "ichamp", "nscf_ok", "dos_ok", "bands_ok",
        "fermi_eV", "n_bands",
        "gap_eV", "vbm_eV", "cbm_eV",
        "gap_type", "gap_direct",
        "nscf_in", "pw_bands_in", "dos_in", "bands_in",
        "ebands_image", "edos_image",
        "notes",
    }
    assert set(d.keys()) == expected_keys, (
        f"to_dict() dérive du schéma attendu.\n"
        f"  missing: {expected_keys - set(d.keys())}\n"
        f"  extra:   {set(d.keys()) - expected_keys}\n"
    )
    # Anti-régression : les noms publics ('band_gap_*') ne doivent PAS
    # apparaître dans to_dict() — l'archive historique est en gap_eV/gap_type.
    assert "band_gap_eV" not in d
    assert "band_gap_type" not in d


# ============================================================================
# Phase 6 — sanity négatif (un seul alias public, pas de pollution)
# ============================================================================

def test_unknown_attribute_still_raises_AttributeError():
    """Sanity : SEULS deux alias publics ont été ajoutés (``band_gap_eV`` /
    ``band_gap_type``). Tout autre nom doit toujours lever AttributeError
    — sinon l'alias cacherait une faute de frappe côté consumer.
    """
    r = ElectronicPropsResult()
    # Doit lever — pas un champ réel.
    try:
        _ = r.banana_eV
    except AttributeError:
        pass
    else:
        raise AssertionError(
            "r.banana_eV devrait lever AttributeError — l'alias public pollue"
        )
    try:
        _ = r.band_gap_EV  # casse différente
    except AttributeError:
        pass
    else:
        raise AssertionError(
            "r.band_gap_EV (casse différente) devrait lever AttributeError "
            "— l'alias ne devrait matcher que ``band_gap_eV`` et ``band_gap_type``"
        )
    try:
        _ = r.gap_EV_with_units
    except AttributeError:
        pass
    else:
        raise AssertionError("r.gap_EV_with_units devrait lever AttributeError")
    # Mais les alias publics marchent toujours (sanity symétrique).
    _ = r.band_gap_eV
    _ = r.band_gap_type


# ============================================================================
# Phase 7 — lockstep mirror pipeline.py
# ============================================================================

def test_keys_to_nest_mirror_size_is_13():
    """Alerte si ``pipeline.py`` modifie la taille du tuple ``keys_to_nest``.

    Ce test alerte UNIQUEMENT sur les intentions : le contenu est validé
    par ``test_keys_to_nest_mirror_keys_are_all_valid_attributes`` ci-dessous.
    Si la taille dérive, c'est qu'une clé a été ajoutée ou retirée → le
    développeur DOIT mettre à jour ce miroir ET ajouter un
    ``@property`` / champ dataclass correspondant sur
    ElectronicPropsResult.
    """
    assert len(PIPELINE_KEYS_TO_NEST) == EXPECTED_KEYS_TO_NEST_COUNT, (
        f"Le tuple `keys_to_nest` de pipeline.py a dérivé "
        f"(attendu {EXPECTED_KEYS_TO_NEST_COUNT} clés, "
        f"got {len(PIPELINE_KEYS_TO_NEST)}). "
        f"Mettre à jour PIPELINE_KEYS_TO_NEST dans ce test pour rester "
        f"en lock-step — et vérifier que toutes les clés sont des attributs "
        f"valides (champ dataclass OU @property) sur ElectronicPropsResult."
    )


def test_keys_to_nest_mirror_keys_are_all_valid_attributes():
    """Pour chaque clé du miroir, l'attribut doit exister sur
    ElectronicPropsResult — sinon ``pipeline.py`` réintroduira le crash
    originel sur la première chaîne où une des clés manque est rencontrée.

    Bloque les 3 régressions typiques :
      * ``band_gap_eV`` retiré (sans @property) → AttributeError garanti ;
      * ``band_gap_type`` non-aliasé → AttributeError le jour où gap_type!=None ;
      * nouvelle clé ajoutée dans pipeline.py sans extension dataclass.
    """
    r = ElectronicPropsResult()
    missing = [k for k in PIPELINE_KEYS_TO_NEST if not hasattr(r, k)]
    assert not missing, (
        f"pipeline.py's keys_to_nest référence {len(missing)} clé(s) "
        f"qui ne sont PAS des attributs de ElectronicPropsResult : {missing}. "
        f"Cela réintroduira le crash originel "
        f"(\"'ElectronicPropsResult' object has no attribute '<X>'\") au "
        f"premier run où la chaîne aboutit. Action requise : SOIT corriger "
        f"pipeline.py pour retirer la clé fautive, SOIT ajouter un "
        f"@property (alias public) sur ElectronicPropsResult."
    )


def test_keys_to_nest_alias_keys_resolve_through_getattr():
    """Les clés ajoutées VIA @property (``band_gap_eV``, ``band_gap_type``)
    doivent être détectées par ``hasattr`` ET résolues par ``getattr``
    SANS erreur — confirme que le lock-step sur les alias est total.
    """
    r = ElectronicPropsResult()
    for alias in ("band_gap_eV", "band_gap_type"):
        assert hasattr(r, alias), f"hasattr a échoué pour {alias}"
        _ = getattr(r, alias)  # ne lève pas


# ============================================================================
# Bonus — pipeline.py et backend imports : on s'assure que l'import groupé
# n'a pas introduit d'imports croisés cassés (sanity de la CI).
# ============================================================================

def test_pipeline_import_electronic_props_no_side_effects():
    """``from pipeline import _nest_set_default`` ne doit PAS avoir cassé
    l'import d'``electronic_props`` (qui est consommé par pipeline._run_electronic_properties).
    Sanity d'ordre d'import.
    """
    # Ces deux lignes auraient pu introduire un cycle d'import si les
    # modules référençaient des symboles exotiques l'un de l'autre.
    import electronic_props  # noqa: F401
    import pipeline  # noqa: F401
    assert hasattr(pipeline, "_nest_set_default")
    assert hasattr(electronic_props, "ElectronicPropsResult")


# ============================================================================
# Standalone runner — utile en CI sans pytest
# ============================================================================

if __name__ == "__main__":
    """Exécution standalone (sans pytest) : émule pytest.main() minimaliste.

    Usage : ``python backend/tests/test_electronic_props_alias.py``
    Sortie : liste les tests par nom + OK/FAIL, exit 0 si tous OK, 1 sinon.
    """
    test_funcs = [
        (name, obj) for name, obj in sorted(globals().items())
        if name.startswith("test_") and callable(obj)
    ]
    failures: list[str] = []
    for name, fn in test_funcs:
        try:
            fn()
        except Exception as ex:  # noqa: BLE001
            failures.append(f"FAIL  {name}  → {type(ex).__name__}: {ex}")
        else:
            print(f"PASS  {name}")
    if failures:
        print()
        for f in failures:
            print(f)
        sys.exit(1)
    print(f"\n[OK] {len(test_funcs)} tests passed.")
    sys.exit(0)

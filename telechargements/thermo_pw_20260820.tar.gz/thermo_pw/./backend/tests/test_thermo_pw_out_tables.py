"""Tests parsers/thermo_pw_out_tables.py."""
from __future__ import annotations

from pathlib import Path


def test_parse_thermo_dw_bulk(tmp_path):
    from parsers.thermo_pw_out_tables import parse_thermo_dw_bulk

    p = tmp_path / "therm_files" / "output_therm.dat.g1.dw"
    p.parent.mkdir(parents=True)
    p.write_text(
        "#      T              B_33\n"
        "  0.00000000E+00               NaN\n"
        "  0.30000000E+03    0.34490097E+00\n"
        "  0.60000000E+03    0.63597403E+00\n",
        encoding="utf-8",
    )
    out = parse_thermo_dw_bulk(p)
    assert len(out["curve_T_K"]) == 2
    assert out["bulk_column"] == "B_33"


def test_parse_qha_out_columns(tmp_path):
    from parsers.thermo_pw_out_tables import parse_generic_thermo_table

    p = tmp_path / "qha.out"
    p.write_text(
        "# T (K)  Cv (Ry/K)  alpha (1/K)  B (GPa)  Cp (Ry/K)\n"
        "100.0  1.0e-5  2.0e-6  95.0  1.01e-5\n"
        "300.0  3.0e-5  2.5e-6  97.0  3.05e-5\n"
        "600.0  5.0e-5  3.0e-6  92.0  5.2e-5\n",
        encoding="utf-8",
    )
    out = parse_generic_thermo_table(p)
    assert out["curve_T_K"] == [100.0, 300.0, 600.0]
    assert out["Cv_300K_Ry_per_K"] == 3.0e-5
    assert out["Cp_300K_Ry_per_K"] == 3.05e-5
    assert out["alpha_300K_per_K"] == 2.5e-6


def test_merge_thermo_curves_with_dw(tmp_path):
    from parsers.thermo_pw_out_tables import merge_thermo_curves

    therm = tmp_path / "therm_files"
    therm.mkdir(parents=True)
    (therm / "output_therm.dat.g1").write_text(
        "#        T             energy            free energy           entropy              Cv \n"
        "  0.00000000E+00  0.898588640076E-02  0.898588640076E-02  0.000000000000E+00                 NaN\n"
        "  0.30000000E+03  0.137963012833E-01  0.00589614451582E-02  0.263338558918E-04  0.307716919421E-04\n",
        encoding="utf-8",
    )
    (therm / "output_therm.dat.g1.dw").write_text(
        "#      T              B_33\n"
        "  0.30000000E+03    0.34490097E+00\n",
        encoding="utf-8",
    )
    results = {"elastic": {"bulk_modulus_GPa": 98.0}, "eos": {"V0_bohr3": 268.0}}
    merged = merge_thermo_curves(tmp_path, results)
    assert merged.get("curve_T_K")
    assert merged.get("curve_Cv_Ry_per_K")
    assert merged.get("curve_B_GPa")
    t300_idx = min(
        range(len(merged["curve_T_K"])),
        key=lambda i: abs(merged["curve_T_K"][i] - 300.0),
    )
    assert merged["curve_B_GPa"][t300_idx] == 98.0

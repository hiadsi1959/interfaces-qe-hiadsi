"""
``backend/tests/_profile_mirrors.py`` — helper partagé lock-step mirror.

Verrouille l'invariant que les **constantes mirror** du contrat profils
P1..P5 (définies dans ``backend/pipeline.py``) sont centralisées dans UN
module importable par TOUS les tests de couverture.

Module ``_``-préfixe ⇒ privé au package ``backend.tests`` (non pytest-collectable
puisque préfixe_underscore n'est pas matché par ``test_*.py``), MAIS
importable depuis n'importe quel test via ``from backend.tests._profile_mirrors
import LOCK_STEP_...`` (ou ANY_...).

Objectif DRY (juillet 2026)
--------------------------
Avant ce module :
  * Chaque test de couverture (ex. ``test_electronic_props_per_profile_coverage.py``)
    déclarait ses propres ``LOCK_STEP_*`` literals et ``ALL_PROFILE_IDS``.
  * Mise à jour de pipeline.py ⇒ obligait à mettre à jour CHAQUE fichier
    de test (risque de drift + boilerplate).

Après ce module :
  * Un seul endroit canonique pour les lock-step mirrors.
  * Les tests de couverture futurs ``from backend.tests._profile_mirrors import ...``
    ajoutent automatiquement la miroir-lock au runtime.

Note de portée
--------------
Ce module ne contient QUE les **constantes mirror**. Les helpers
métier (``_profile``, ``_profile_metric_keys``, ...) restent dans les
fichiers de test car ils couplent à ``pipeline.PROFILES`` (import
spécifique) et à la politique d'assertion du test.

Convention de mise à jour
-------------------------
Quand ``backend/pipeline.py`` est étendu (nouvelle clé dans
``_METRICS_ELECTRONIC`` / ``_METRICS_DYN_STABILITY`` / ``_PLOTS_ELECTRONIC`` /
changement ``what_qe``), METTRE À JOUR CE FICHIER EN PREMIER. Les tests
dérivants cassent automatiquement (diagnostic pinpoint) avec un
message qui pointe vers ce helper.

Exécution
---------
* pytest : les tests de couverture importent automatiquement. **Un sanity
  auto-check tourne au moment de l'import** : compare les literals
  ``LOCK_STEP_ELECTRONIC_METRIC_KEYS`` /
  ``LOCK_STEP_DYN_STABILITY_METRIC_KEYS`` à ``backend.pipeline._METRICS_ELECTRONIC``
  / ``_METRICS_DYN_STABILITY``. Si drift détectée, **RuntimeError immédiat**
  — le test consommateur casse à la *collection* pytest (avant exécution du
  moindre test), avec un diagnostic bidirectionnel (helper en trop /
  helper manquant).
* standalone : ce module n'a pas de ``if __name__ == "__main__":`` bloc ;
  c'est un pur helper-module activé par import (avec son propre bootstrap
  sys.path en bas de fichier — auto-suffisant).

Dépendance à l'import
---------------------
Le helper **importe ``backend.pipeline``** au chargement pour exécuter le
sanity auto-check — ce n'est plus un module 100 % pure-data. Mais : tous
les testeurs de couverture du package ``backend.tests`` sont déjà couplés
à ``backend.pipeline`` via ``from pipeline import PROFILES`` ; l'import
supplémentaire est sans coût réel. Si l'auto-bootstrap est gênant
(usage avancé hors-context), commenter la section ``Sanity auto-check``
en queue de fichier.
"""
from __future__ import annotations


# ============================================================================
# Identifiants profils — alimentent les ``pytest.mark.parametrize`` ET
# le runner standalone.
# ============================================================================

ALL_PROFILE_IDS: tuple[str, ...] = ("P1", "P2", "P3", "P4", "P5")
"""Tuple ordonné des 5 profils testés. Alimente les parametrize + standalone.

Synchrone avec ``backend.pipeline.PROFILES.keys()`` (asserté par le test
``test_lockstep_profiles_mirror_pipeline_profiles``).
"""

LOCK_STEP_PROFILES: frozenset[str] = frozenset(ALL_PROFILE_IDS)
"""Tous les profils à tester (set view de ALL_PROFILE_IDS).

Doit rester en lock-step avec ``backend.pipeline.PROFILES.keys()`` — toute
divergence casse ``test_lockstep_profiles_mirror_pipeline_profiles``.
"""


# ============================================================================
# Mirror exact de ``_METRICS_ELECTRONIC`` (backend/pipeline.py, ~ligne 86).
# ============================================================================
#
# 4 clés électroniques garanties partagées par P1..P5 via
# ``_PROFILE_PROPERTIES``. Toute divergence entre cette mirror et
# ``backend.pipeline._METRICS_ELECTRONIC`` casse le test d'intersection
# universelle (``test_all_five_profiles_include_electronic_metrics_in_universal_intersection``)
# avec un message ActionableError qui pointe vers cette constante.
#
LOCK_STEP_ELECTRONIC_METRIC_KEYS: frozenset[str] = frozenset({
    "properties.fermi_eV",
    "properties.vbm_eV",
    "properties.cbm_eV",
    "properties.band_gap_eV",
    "properties.band_gap_type",
    "properties.gap_direct",
    "properties.n_bands",
})
"""7 clés électroniques garanties par ``_METRICS_ELECTRONIC`` (lock-step mirror).

Synchrone avec ``backend.pipeline._METRICS_ELECTRONIC`` (~ligne 86).
Toute modification de pipeline.py SANS mise à jour de cette constant
casse les tests de couverture.
"""


# ============================================================================
# Mirror exact de ``_PLOTS_ELECTRONIC`` (backend/pipeline.py, ~ligne 99).
# ============================================================================
#
# 4 plots garantis partagés par P1..P5 :
#   * ``plots.ebands``       — bandes électroniques E(k).
#   * ``plots.edos``         — densité d'états électronique.
#   * ``plots.phonon_bands`` — dispersions phononiques.
#   * ``plots.phonon_dos``   — DOS phononique.
#
# Juillet 2026 : phonon_bands + phonon_dos ajoutés (needs_phonons=True P1..P5).
# Toute divergence casse ``test_all_five_profiles_share_exact_electronic_plot_set``.
#
LOCK_STEP_ELECTRONIC_PLOT_KEYS: frozenset[str] = frozenset({
    "plots.ebands",
    "plots.edos",
    "plots.phonon_bands",
    "plots.phonon_dos",
})
"""4 plots universels garantis par tous les profils P1..P5 (lock-step)."""


# ============================================================================
# Mirror exact de ``_METRICS_DYN_STABILITY`` (backend/pipeline.py, ~ligne 92).
# ============================================================================
#
# 3 clés stabilité dynamique garanties partagées par P1..P5 via
# ``_PROFILE_PROPERTIES``. Symétrique du mirror ``_METRICS_ELECTRONIC``.
#
LOCK_STEP_DYN_STABILITY_METRIC_KEYS: frozenset[str] = frozenset({
    "properties.dynamically_stable",
    "properties.n_imaginary_modes",
    "properties.min_freq_cm-1",
})
"""3 clés dyn_stability garanties par ``_METRICS_DYN_STABILITY`` (lock-step mirror).

Synchrone avec ``backend.pipeline._METRICS_DYN_STABILITY`` (~ligne 92).
"""


# ============================================================================
# Mirror exact de ``_METRICS_MAGNETISM`` (backend/pipeline.py, ~ligne 148).
# ============================================================================
#
# 3 clés magnétiques garanties partagées par P1..P5 via le spread
# ``*_METRICS_MAGNETISM`` ajouté à ``expected_results.metrics`` de chaque
# profil. Toute divergence entre cette mirror et
# ``backend.pipeline._METRICS_MAGNETISM`` casse le test d'intersection
# universelle avec un message actionable pointant vers cette constante.
#
# Note (juillet 2026) : ces clés ne sont peuplées QUE si ``nspin>1`` dans
# scf.in (opt-in utilisateur). Elles restent ``None`` tant qu'un parser
# PWscf ``Magnetic moment per site:`` n'écrit pas dans
# ``results["magnetism"][...]``. Le préfixe ``magnetism.*`` (vs
# ``properties.*``) exprime cet opt-in.
#
LOCK_STEP_MAGNETISM_METRIC_KEYS: frozenset[str] = frozenset({
    "magnetism.m_per_atom",
    "magnetism.total_magnetization",
    # Août 2026 — ordre magnétique classifié depuis les moments CONVERGÉS
    # (FM / AFM / FiM / non-colinéaire / effondré), cf.
    # parsers/magnetization.classify_magnetic_order.
    "magnetism.magnetic_order",
    "magnetism.projected_moments_per_atom",
})
"""4 clés magnétiques garanties par ``_METRICS_MAGNETISM`` (lock-step mirror).

Synchrone avec ``backend.pipeline._METRICS_MAGNETISM`` (~ligne 148).
Toute modification de pipeline.py SANS mise à jour de cette constant
casse les tests de couverture.
"""


# ============================================================================
# Mirror exact des directives thermo_pw canoniques (pipeline.py, ``what_qe``).
# ============================================================================
#
# juin 2026 refonte : les 5 profils ont des directives canoniques distinctes.
# Si une ``what_qe`` mismatch le canon, l'invariant casse avec une erreur ciblée.
#
LOCK_STEP_CANONICAL_WHAT_QE: dict[str, str] = {
    "P1": "scf_elastic_constants",
    "P2": "thermo",
    "P3": "elastic_constants_geo",
    "P4": "ph_life",
    "P5": "dielectric",
}
"""Directives ``what_qe`` canoniques par profil — doivent matcher ``pipeline.PROFILES[*]['what_qe']``.

Aligné sur le pipeline_state.JSON legacy :
  * P1 : ``scf_elastic_constants`` (canonique post-refonte, T=0 K)
  * P2 : ``thermo`` (QHA — alias legacy ``mur_lc_t`` réécrit)
  * P3 : ``elastic_constants_geo`` (Cij(V0,T) — alias legacy ``mur_lc_t_elastic_constants``)
  * P4 : ``ph_life`` (anharmonicité — alias legacy ``qha_lif``)
  * P5 : ``dielectric`` (ε∞ DFPT+Berry, chaîne optique opt-in séparée)
"""


# ============================================================================
# Aliases ``what_qe`` deprecated à proscrire dans ``PROFILES`` (juin 2026).
# ============================================================================
#
# Leur présence dans ``PROFILES`` indique un profil non migré vers le
# canonique refondu. Le runtime ``run_thermo_pw_mpi`` accepte encore ces
# alias pour rétro-compat des ``pipeline_api_job_state.json`` legacy —
# mais la fiche profil canonique (``PROFILES``) doit avoir migré.
#
KNOWN_LEGACY_WHAT_QE_ALIASES: frozenset[str] = frozenset({
    "elastic",                       # legacy P1 (thermo_pw 7.x ne connaît plus)
    "mur_lc_t",                      # legacy P2
    "mur_lc_t_elastic_constants",    # legacy P3
    "qha_lif",                       # legacy P4
})
"""Aliases ``what_qe`` deprecated — leur présence est une régression."""


# ============================================================================
# Sanity auto-check à l'import — verrouille l'invariant dès le chargement
# du module (avant même le moindre test exécuté).
# ============================================================================
#
# Implémenté comme ``_lockstep_check()`` (privé) puis déclenché une fois
# à l'import. Toutes les variables locales du check (``_HERE``,
# ``_BACKEND``, ``_PIPELINE_*``, ``_DRIFT_*``) restent LOCALES à la
# fonction — elles ne polluent pas ``dir(_profile_mirrors)`` (les autres
# symboles exportés restent les seuls membres visibles).
#
# Conception
# ----------
# * **Hard import** : ``from backend.pipeline import ...`` sans try/except.
#   On veut que la collection pytest casse *bruyamment* si ``backend.pipeline``
#   est inaccessible — c'est le signal « quelque chose est cassé dans le
#   contrat racine ».
# * **RuntimeError (pas ``assert``)** : ``assert`` peut être désactivé par
#   ``python -O`` en CI ; ``RuntimeError`` garantit que le check fire
#   toujours.
# * **Diff bidirectionnel** : rapporte à la fois
#   ``helper \ pipeline`` (excès dans le helper) ET
#   ``pipeline \ helper`` (manque dans le helper). Diagnostic complet :
#   le dev sait immédiatement s'il doit AJOUTER ou RETIRER des clés.
# * **Bootstrap LOCAL à la fonction** : ajoute ``backend/`` à ``sys.path``
#   avec garde idempotente (``if sp not in _sys.path``). Reste confiné à
#   la fonction — pas d'effet de bord au niveau module.
# * **Clé ``frozenset`` extraction** : même logique que
#   ``test_profile_mirrors_helper.py`` — ``frozenset(m["key"] for m in
#   pipeline_literal if m.get("key"))``.


def _lockstep_check() -> None:
    """Sanity auto-check : verrouille les 2 locks au chargement.

    Raises:
        RuntimeError : dès qu'un des 2 mirrors électroniques / dyn_stability
            dérive des literals pipeline.py — diagnostic bidirectionnel
            pinpoint ``[DRIFT][_profile_mirrors] ...`` avec liste triée
            des clés en trop / manquantes et fichier à corriger.
    """
    import sys as _sys
    from pathlib import Path as _Path

    _HERE = _Path(__file__).resolve().parent
    _BACKEND = _HERE.parent  # backend/tests/_profile_mirrors.py → backend/
    _sp = str(_BACKEND)
    if _sp not in _sys.path:
        _sys.path.insert(0, _sp)

    from backend.pipeline import (  # noqa: E402
        _METRICS_ELECTRONIC,
        _METRICS_DYN_STABILITY,
        _METRICS_MAGNETISM,
    )

    _PIPELINE_ELECTRONIC_KEYS: frozenset[str] = frozenset(
        m["key"] for m in _METRICS_ELECTRONIC if m.get("key")
    )
    _PIPELINE_DYN_STABILITY_KEYS: frozenset[str] = frozenset(
        m["key"] for m in _METRICS_DYN_STABILITY if m.get("key")
    )
    _PIPELINE_MAGNETISM_KEYS: frozenset[str] = frozenset(
        m["key"] for m in _METRICS_MAGNETISM if m.get("key")
    )

    # ---- Electronic drift check -------------------------------------------
    _ELECTRONIC_EXCESS: list[str] = sorted(
        LOCK_STEP_ELECTRONIC_METRIC_KEYS - _PIPELINE_ELECTRONIC_KEYS
    )
    _ELECTRONIC_MISSING: list[str] = sorted(
        _PIPELINE_ELECTRONIC_KEYS - LOCK_STEP_ELECTRONIC_METRIC_KEYS
    )
    if _ELECTRONIC_EXCESS or _ELECTRONIC_MISSING:
        raise RuntimeError(
            f"[DRIFT][_profile_mirrors] LOCK_STEP_ELECTRONIC_METRIC_KEYS != "
            f"backend.pipeline._METRICS_ELECTRONIC.\n"
            f"  Helper a EN TROP (retirer du miroir)         : {_ELECTRONIC_EXCESS}\n"
            f"  Helper MANQUE (ajouter au miroir)            : {_ELECTRONIC_MISSING}\n"
            f"  Pipeline effectif          ({len(_PIPELINE_ELECTRONIC_KEYS)} clés) : "
            f"{sorted(_PIPELINE_ELECTRONIC_KEYS)}\n"
            f"  Helper effectif            ({len(LOCK_STEP_ELECTRONIC_METRIC_KEYS)} clés) : "
            f"{sorted(LOCK_STEP_ELECTRONIC_METRIC_KEYS)}\n"
            f"Mise à jour requise : backend/tests/_profile_mirrors.py."
        )

    # ---- Dyn-stability drift check ----------------------------------------
    _DYN_EXCESS: list[str] = sorted(
        LOCK_STEP_DYN_STABILITY_METRIC_KEYS - _PIPELINE_DYN_STABILITY_KEYS
    )
    _DYN_MISSING: list[str] = sorted(
        _PIPELINE_DYN_STABILITY_KEYS - LOCK_STEP_DYN_STABILITY_METRIC_KEYS
    )
    if _DYN_EXCESS or _DYN_MISSING:
        raise RuntimeError(
            f"[DRIFT][_profile_mirrors] LOCK_STEP_DYN_STABILITY_METRIC_KEYS != "
            f"backend.pipeline._METRICS_DYN_STABILITY.\n"
            f"  Helper a EN TROP (retirer du miroir)         : {_DYN_EXCESS}\n"
            f"  Helper MANQUE (ajouter au miroir)            : {_DYN_MISSING}\n"
            f"  Pipeline effectif          ({len(_PIPELINE_DYN_STABILITY_KEYS)} clés) : "
            f"{sorted(_PIPELINE_DYN_STABILITY_KEYS)}\n"
            f"  Helper effectif            ({len(LOCK_STEP_DYN_STABILITY_METRIC_KEYS)} clés) : "
            f"{sorted(LOCK_STEP_DYN_STABILITY_METRIC_KEYS)}\n"
            f"Mise à jour requise : backend/tests/_profile_mirrors.py."
        )



    # ---- Magnetism drift check -------------------------------------------
    _MAG_EXCESS: list[str] = sorted(
        LOCK_STEP_MAGNETISM_METRIC_KEYS - _PIPELINE_MAGNETISM_KEYS
    )
    _MAG_MISSING: list[str] = sorted(
        _PIPELINE_MAGNETISM_KEYS - LOCK_STEP_MAGNETISM_METRIC_KEYS
    )
    if _MAG_EXCESS or _MAG_MISSING:
        raise RuntimeError(
            f"[DRIFT][_profile_mirrors] LOCK_STEP_MAGNETISM_METRIC_KEYS != "
            f"backend.pipeline._METRICS_MAGNETISM.\n"
            f"  Helper a EN TROP (retirer du miroir)         : {_MAG_EXCESS}\n"
            f"  Helper MANQUE (ajouter au miroir)            : {_MAG_MISSING}\n"
            f"  Pipeline effectif          ({len(_PIPELINE_MAGNETISM_KEYS)} clés) : "
            f"{sorted(_PIPELINE_MAGNETISM_KEYS)}\n"
            f"  Helper effectif            ({len(LOCK_STEP_MAGNETISM_METRIC_KEYS)} clés) : "
            f"{sorted(LOCK_STEP_MAGNETISM_METRIC_KEYS)}\n"
            f"Mise à jour requise : backend/tests/_profile_mirrors.py."
        )


# Trigger au chargement du module — fail-fast RuntimeError si drift.
_lockstep_check()

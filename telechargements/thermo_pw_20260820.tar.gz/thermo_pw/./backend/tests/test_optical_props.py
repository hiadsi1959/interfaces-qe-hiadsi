"""
Tests unitaires pour `backend/optical_props.py` — orchestrateur opt-in du profil P5
(NSCF_optic + epsilon.x + turbo_lanczos.x + turbo_davidson.x).

Couvre :
  * Génération des fichiers d'entrée (``write_nscf_optic_in``,
    ``write_epsilon_in``, ``write_turbo_lanczos_in``,
    ``write_turbo_davidson_in``) : parsing, nbnd, wf_collect,
    nosym/noinv, K_POINTS, namelists &lr_*.
  * Orchestration ``run_optical_properties`` : chaque branche défensive
    (SCF absent, binaire QE manquant, wf_collect=.false. explicite,
    flow complet avec QE simulée via mocks, annulation par cancel_event).
  * Dataclass ``OpticalPropsResult`` : défauts + ``to_dict`` (couvre les
    6 champs optiques : nscf_optic, epsilon, turbo_lanczos, turbo_davidson).
  * Helpers bas-niveau (``_list_eps_dat_files``, ``_list_turbo_dat_files``,
    ``_extract_prefix_from_text``).

Le QE (pw.x + epsilon.x + turbo_*.x) est SIMULÉ par ``unittest.mock.patch`` :
on ne lance aucun binaire Quantum ESPRESSO réel.
"""
from __future__ import annotations

import re
import sys
import threading
from pathlib import Path
from unittest.mock import patch

import pytest

# Rend `backend/` importable (le test vit dans backend/tests/).
BACKEND = Path(__file__).resolve().parents[1]
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

import optical_props as opt  # noqa: E402
from optical_props import (  # noqa: E402
    OpticalPropsResult,
    write_epsilon_in,
    write_turbo_lanczos_in,
    write_turbo_davidson_in,
    write_nscf_optic_in,
    run_optical_properties,
    _extract_prefix_from_text,
    _list_eps_dat_files,
    _list_turbo_dat_files,
)


# ============================================================================
# Tests : _list_turbo_dat_files — exclusion epsilon (anti-doublon UI) ========
# ============================================================================


class TestListTurboDatFiles:
    """Vérifie que le helper inclut chi*/eigenvalues*/polarizability*/
    spectrum*/turbo*.dat et exclut les fichiers epsilon (déjà comptés).
    """

    def test_globs_chi_eigenvalues(self, tmp_path):
        (tmp_path / "chi.dat").write_text("x")
        (tmp_path / "eigenvalues_lanczos.dat").write_text("x")
        (tmp_path / "spectrum_davidson.dat").write_text("x")
        (tmp_path / "unrelated.txt").write_text("x")
        result = _list_turbo_dat_files(tmp_path)
        names = sorted(Path(p).name for p in result)
        assert names == [
            "chi.dat", "eigenvalues_lanczos.dat", "spectrum_davidson.dat",
        ]

    def test_excludes_eps_dat_files(self, tmp_path):
        """Les eps*/eels*/jdos* ne doivent PAS apparaître — déjà comptés ailleurs."""
        (tmp_path / "eps11_0.dat").write_text("x")
        (tmp_path / "chi.dat").write_text("x")
        result = _list_turbo_dat_files(tmp_path)
        names = [Path(p).name for p in result]
        assert "eps11_0.dat" not in names
        assert "chi.dat" in names

    def test_empty_dir(self, tmp_path):
        assert _list_turbo_dat_files(tmp_path) == []


# ============================================================================
# Fixtures
# ============================================================================


def _make_fake_binary(path: Path) -> Path:
    """Écrit un « binaire » factice ≥ 100 octets (vu comme exécutable)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"\x7fELF" + b"\x00" * 200)
    return path


@pytest.fixture
def work_dir_with_scf(tmp_path: Path) -> Path:
    """Crée un dossier de travail avec un scf.in minimal + binaires factices.

    * nat = 2, ntyp = 1 (Si), nbnd = 8, ibrav = 2 (cubique FCC).
    * wf_collect = .true. déjà présent.
    * Binaire ``pw.x`` et ``epsilon.x`` factices dans ``fake_bin/``.
    """
    scf = (
        "&CONTROL\n"
        "  calculation = 'scf',\n"
        "  prefix = 'pw_scf',\n"
        "  outdir = './out/',\n"
        "  pseudo_dir = './pseudos/',\n"
        "  wf_collect = .true.\n"
        "/\n"
        "&SYSTEM\n"
        "  ibrav = 2,\n"
        "  nat = 2,\n"
        "  ntyp = 1,\n"
        "  ecutwfc = 40.0,\n"
        "  nbnd = 8\n"
        "/\n"
        "&ELECTRONS\n"
        "  conv_thr = 1e-8\n"
        "/\n"
        "ATOMIC_SPECIES\n"
        "  Si 28.0855 Si.pbe-n-kjpaw_psl.0.1.UPF\n"
        "ATOMIC_POSITIONS {crystal}\n"
        "  Si 0.00 0.00 0.00\n"
        "  Si 0.25 0.25 0.25\n"
        "K_POINTS automatic\n"
        "  4 4 4 0 0 0\n"
    )
    (tmp_path / "scf.in").write_text(scf)
    pseudos = tmp_path / "pseudos"
    pseudos.mkdir()
    (pseudos / "Si.pbe-n-kjpaw_psl.0.1.UPF").write_text("# fake pseudo\n")
    _make_fake_binary(tmp_path / "fake_bin" / "pw.x")
    _make_fake_binary(tmp_path / "fake_bin" / "epsilon.x")
    # Turbo_lanczos + turbo_davidson — chaînes P5 exhaustive (TDDFPT complète).
    _make_fake_binary(tmp_path / "fake_bin" / "turbo_lanczos.x")
    _make_fake_binary(tmp_path / "fake_bin" / "turbo_davidson.x")
    return tmp_path


def _patch_paths(wd: Path):
    """Patch simultané de **tous** les chemins QE consommés par P5
    (``pw_path`` + ``epsilon_path`` + ``turbo_lanczos_path`` +
    ``turbo_davidson_path``). Utilisable comme context manager.

    Couvre la chaîne exhaustive P5 (epsilon.x + turbo_lanczos.x +
    turbo_davidson.x). Sans ce patch, les sous-tests iraient chercher
    les binaires de l'installation QE réelle (CHEMIN_QE/bin/...) et
    échoueraient à fournir un mock cohérent.
    """
    from contextlib import ExitStack

    stack = ExitStack()
    stack.enter_context(
        patch("optical_props.cfg.pw_path", return_value=wd / "fake_bin" / "pw.x")
    )
    stack.enter_context(
        patch(
            "optical_props.cfg.epsilon_path",
            return_value=wd / "fake_bin" / "epsilon.x",
        )
    )
    stack.enter_context(
        patch(
            "optical_props.cfg.turbo_lanczos_path",
            return_value=wd / "fake_bin" / "turbo_lanczos.x",
        )
    )
    stack.enter_context(
        patch(
            "optical_props.cfg.turbo_davidson_path",
            return_value=wd / "fake_bin" / "turbo_davidson.x",
        )
    )
    return stack


# ============================================================================
# Tests : write_nscf_optic_in
# ============================================================================


class TestWriteNscfOpticIn:
    def test_creates_file_in_workdir(self, work_dir_with_scf):
        p = write_nscf_optic_in(work_dir_with_scf, "scf.in")
        assert p.is_file()
        assert p.name == "nscf_optic.in"
        assert p.parent == work_dir_with_scf

    def test_nosym_noinv_set(self, work_dir_with_scf):
        text = write_nscf_optic_in(work_dir_with_scf, "scf.in").read_text()
        assert re.search(r"nosym\s*=\s*\.true\.", text), (
            f"nosym=.true. introuvable dans:\n{text[:600]}"
        )
        assert re.search(r"noinv\s*=\s*\.true\.", text), (
            f"noinv=.true. introuvable dans:\n{text[:600]}"
        )

    def test_calculation_nscf(self, work_dir_with_scf):
        text = write_nscf_optic_in(work_dir_with_scf, "scf.in").read_text()
        # Tolérant sur le style de guillemet + espaces : on cherche le mot-clé
        # 'calculation' suivi d'une valeur 'nscf' entre quotes.
        assert re.search(r"calculation\s*=\s*['\"]nscf['\"]", text), (
            f"calculation = 'nscf' introuvable dans:\n{text[:600]}"
        )
        # L'ancienne valeur 'scf' pour calculation ne doit PAS subsister
        # (sinon la réécriture a échoué).
        assert not re.search(r"calculation\s*=\s*['\"]scf['\"]", text), (
            f"calculation ne doit plus valoir 'scf' :\n{text[:600]}"
        )

    def test_restart_mode_restart(self, work_dir_with_scf):
        text = write_nscf_optic_in(work_dir_with_scf, "scf.in").read_text()
        # restart_mode doit valoir 'restart' (peut avoir été ajouté si absent
        # dans la fixture SCF — d'où une tolérance sur les quotes).
        assert re.search(r"restart_mode\s*=\s*['\"]restart['\"]", text), (
            f"restart_mode='restart' introuvable dans:\n{text[:600]}"
        )

    def test_wf_collect_injected_if_missing(self, tmp_path):
        scf = (
            "&CONTROL\n"
            "  calculation = 'scf',\n"
            "  prefix = 'pw_scf',\n"
            "  outdir = './out/'\n"
            "/\n"
            "&SYSTEM\n"
            "  ibrav = 2, nat = 1, ntyp = 1, nbnd = 4\n"
            "/\n"
            "K_POINTS automatic\n"
            "  4 4 4 0 0 0\n"
        )
        (tmp_path / "scf.in").write_text(scf)
        text = write_nscf_optic_in(tmp_path, "scf.in").read_text()
        assert re.search(r"(?im)^\s*wf_collect\s*=\s*\.true\.", text)

    def test_nbnd_at_least_doubled_for_small_system(self, work_dir_with_scf):
        # scf.in a nbnd=8 ; target = max(8*2, 2*16, 20) = 32.
        nbnd_optic = _read_nbnd(work_dir_with_scf)
        assert nbnd_optic >= 2 * 8, (
            f"nbnd doit être au moins ×2 du nbnd SCF (8), got {nbnd_optic}"
        )

    def test_nbnd_respects_per_atom_minimum(self, tmp_path):
        """Cas nat=8, nbnd=4 → cible = max(8, 128, 20) = 128."""
        scf = (
            "&CONTROL\n"
            "  calculation = 'scf',\n"
            "  wf_collect = .true.\n"
            "/\n"
            "&SYSTEM\n"
            "  ibrav = 2,\n"
            "  nat = 8,\n"
            "  ntyp = 1,\n"
            "  nbnd = 4\n"
            "/\n"
            "K_POINTS automatic\n"
            "  4 4 4 0 0 0\n"
        )
        (tmp_path / "scf.in").write_text(scf)
        nbnd_optic = _read_nbnd(tmp_path)
        assert nbnd_optic >= 8 * 16

    def test_nbnd_clamped_above_existing(self, work_dir_with_scf):
        """Si le SCF a déjà un nbnd suffisant, on ne le réduit PAS en-dessous."""
        # scf.in a nbnd=8 ; nat=2 → si on écrivait nbnd=4 (mauvais) ça serait faux.
        nbnd_optic = _read_nbnd(work_dir_with_scf)
        assert nbnd_optic >= 8

    def test_kpoints_densified(self, work_dir_with_scf):
        text = write_nscf_optic_in(work_dir_with_scf, "scf.in").read_text()
        m = re.search(
            r"(?im)^\s*K_POINTS\s*(?:\(\s*automatic\s*\)|automatic)\s*\n"
            r"\s*(\d+)\s+(\d+)\s+(\d+)",
            text,
        )
        assert m, "K_POINTS automatic introuvable dans le fichier généré"
        nx, ny, nz = int(m.group(1)), int(m.group(2)), int(m.group(3))
        # Grille originale 4×4×4 → densifiée (×3) à 12 max., bornée ≥ 12.
        assert nx >= 12 and ny >= 12 and nz >= 12
        assert nx <= 32 and ny <= 32 and nz <= 32

    def test_raises_if_scf_missing(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            write_nscf_optic_in(tmp_path, "scf.in")


def _read_nbnd(work_dir: Path) -> int:
    """Lit ``nbnd`` dans le nscf_optic.in généré."""
    m = re.search(
        r"(?im)^\s*nbnd\s*=\s*(\d+)",
        write_nscf_optic_in(work_dir, "scf.in").read_text(),
    )
    assert m, "nbnd introuvable"
    return int(m.group(1))


# ============================================================================
# Tests : write_epsilon_in
# ============================================================================


# ============================================================================
# Tests : write_turbo_lanczos_in / write_turbo_davidson_in (P5 exhaustive TDDFPT)
# ============================================================================


class TestWriteTurboLanczosIn:
    """Vérifie l'écriture du fichier d'entrée Turbo Lanczos (TDDFPT χ(ω))."""

    def test_creates_file_in_workdir(self, tmp_path):
        p = write_turbo_lanczos_in(tmp_path, prefix="pw_scf")
        assert p.is_file()
        assert p.name == "turbo_lanczos.in"
        assert p.parent == tmp_path

    def test_lr_input_namelist_present(self, tmp_path):
        text = write_turbo_lanczos_in(tmp_path, prefix="x").read_text()
        assert "&lr_input" in text
        assert "prefix = 'x'" in text
        assert "outdir = './out/'" in text

    def test_lr_control_namelist_present(self, tmp_path):
        text = write_turbo_lanczos_in(tmp_path, prefix="pw_scf").read_text()
        assert "&lr_control" in text
        # itermax et ipol correspondent aux constantes par défaut.
        assert re.search(r"itermax\s*=\s*500", text), (
            f"itermax=500 introuvable dans:\n{text}"
        )
        assert re.search(r"ipol\s*=\s*4", text), (
            f"ipol=4 (trace χ) introuvable dans:\n{text}"
        )

    def test_custom_itermax_reflected(self, tmp_path):
        text = write_turbo_lanczos_in(tmp_path, prefix="x", itermax=100, ipol=1).read_text()
        assert "itermax = 100" in text
        assert "ipol = 1" in text

    def test_custom_prefix(self, tmp_path):
        text = write_turbo_lanczos_in(tmp_path, prefix="BaTiO3").read_text()
        assert "prefix = 'BaTiO3'" in text


class TestWriteTurboDavidsonIn:
    """Vérifie l'écriture du fichier d'entrée Turbo Davidson (TDDFPT fenêtre)."""

    def test_creates_file_in_workdir(self, tmp_path):
        p = write_turbo_davidson_in(tmp_path, prefix="pw_scf")
        assert p.is_file()
        assert p.name == "turbo_davidson.in"
        assert p.parent == tmp_path

    def test_lr_dav_namelist_present(self, tmp_path):
        text = write_turbo_davidson_in(tmp_path, prefix="pw_scf").read_text()
        assert "&lr_input" in text
        assert "&lr_dav" in text
        assert "prefix = 'pw_scf'" in text
        assert "residue_conv_thr = 1.0d-5" in text

    def test_default_window_visible(self, tmp_path):
        """Fenêtre par défaut [0, 2] eV, pas 0.002 eV."""
        text = write_turbo_davidson_in(tmp_path, prefix="pw_scf").read_text()
        assert re.search(r"start\s*=\s*0\.0\d*d0", text), f"start=0.0d0 introuvable:\n{text}"
        assert re.search(r"finish\s*=\s*2\.0\d*d0", text), f"finish=2.0d0 introuvable:\n{text}"
        assert re.search(r"step\s*=\s*0\.00\d*d0", text), f"step=0.002d0 introuvable:\n{text}"

    def test_custom_window(self, tmp_path):
        text = write_turbo_davidson_in(
            tmp_path, prefix="x", start_eV=1.0, finish_eV=5.0, step_eV=0.01
        ).read_text()
        assert "start = 1.0000d0" in text
        assert "finish = 5.0000d0" in text
        assert "step = 0.0100d0" in text

    def test_max_iter_default(self, tmp_path):
        text = write_turbo_davidson_in(tmp_path, prefix="pw_scf").read_text()
        assert "max_iter = 120" in text


class TestWriteEpsilonIn:
    def test_creates_file(self, tmp_path):
        p = write_epsilon_in(tmp_path, prefix="pw_scf")
        assert p.is_file()
        assert p.name == "epsilon.in"

    def test_inputpp_namelist_present(self, tmp_path):
        text = write_epsilon_in(tmp_path, prefix="pw_scf").read_text()
        assert "&inputpp" in text
        assert "outdir = './out/'" in text
        assert "prefix = 'pw_scf'" in text
        assert "calculation = 'eps'" in text

    def test_energy_grid_namelist_present(self, tmp_path):
        text = write_epsilon_in(tmp_path, prefix="pw_scf").read_text()
        assert "&energy_grid" in text
        assert "smeartype = 'gauss'" in text
        assert "intersmear" in text
        assert "wmin" in text
        assert "wmax" in text
        assert "nw" in text

    def test_default_values_match(self, tmp_path):
        text = write_epsilon_in(tmp_path, prefix="pw_scf").read_text()
        assert "wmin = 0.000000" in text
        assert "wmax = 15.000000" in text
        assert "nw = 300" in text
        assert "intersmear = 0.1360" in text

    def test_custom_values_reflected(self, tmp_path):
        text = write_epsilon_in(
            tmp_path,
            prefix="x",
            wmin=2.0,
            wmax=5.0,
            nw=50,
            intersmear=0.05,
        ).read_text()
        assert "wmin = 2.000000" in text
        assert "wmax = 5.000000" in text
        assert "nw = 50" in text
        assert "intersmear = 0.0500" in text


# ============================================================================
# Tests : run_optical_properties — orchestration
# ============================================================================


class TestRunOpticalProperties:
    def test_missing_scf_returns_empty_result(self, tmp_path):
        res = run_optical_properties(tmp_path, nproc=2, scf_basename="scf.in")
        assert isinstance(res, OpticalPropsResult)
        assert res.nscf_optic_ok is False
        assert res.epsilon_ok is False
        assert any("absent" in n for n in res.notes)

    @patch("optical_props.cfg.pw_path", return_value=Path("/nonexistent/pw.x"))
    def test_missing_pw_x_returns_empty_result(self, _mock, tmp_path):
        (tmp_path / "scf.in").write_text("placeholder")
        res = run_optical_properties(tmp_path, nproc=2, scf_basename="scf.in")
        assert res.nscf_optic_ok is False
        assert any("pw.x" in n and "manquant" in n for n in res.notes)

    def test_missing_epsilon_short_circuit(self, work_dir_with_scf):
        """Si epsilon.x manque, NSCF_optic tourne mais epsilon.x est sauté."""
        with patch(
            "optical_props.cfg.epsilon_path",
            return_value=work_dir_with_scf / "fake_bin" / "epsilon.x",
        ):
            with patch(
                "optical_props.cfg.pw_path",
                return_value=work_dir_with_scf / "fake_bin" / "pw.x",
            ):
                with patch("optical_props.run_pw_x_in", _fake_pw_x_in_creates_out):
                    res = run_optical_properties(
                        work_dir_with_scf,
                        nproc=2,
                        scf_basename="scf.in",
                    )
        # NSCF_optic a tourné (binaire simulé), epsilon.x court-circuité
        # car on patch epsilon_path → /nonexistent path.
        # NOTE : on garde le binaire présent et on « simule » une absence
        # via un override supplémentaire pour la branche `epsilon_path`.
        assert res.epsilon_ok is False

    def test_wf_collect_explicit_false_short_circuit(self, tmp_path):
        """SCF explicitement ``wf_collect = .false.`` → chaîne optique sautée."""
        scf = (
            "&CONTROL\n"
            "  wf_collect = .false.\n"
            "/\n"
            "&SYSTEM\n"
            "  ibrav = 2, nat = 1, ntyp = 1, nbnd = 4\n"
            "/\n"
        )
        (tmp_path / "scf.in").write_text(scf)
        _make_fake_binary(tmp_path / "bin" / "pw.x")
        _make_fake_binary(tmp_path / "bin" / "epsilon.x")
        with patch(
            "optical_props.cfg.pw_path", return_value=tmp_path / "bin" / "pw.x"
        ):
            with patch(
                "optical_props.cfg.epsilon_path",
                return_value=tmp_path / "bin" / "epsilon.x",
            ):
                res = run_optical_properties(
                    tmp_path, nproc=2, scf_basename="scf.in"
                )
        assert res.nscf_optic_ok is False
        assert res.epsilon_ok is False
        assert any("wf_collect = .false." in n for n in res.notes)

    def test_cancel_event_propagates(self, work_dir_with_scf):
        """cancel_event.is_set() pendant NSCF_optic → RuntimeError après res."""
        ev = threading.Event()
        # On simule l'arrêt côté run_pw_x_in : lève l'erreur standard API.
        from qe_subprocess import API_CANCEL_RUNTIME_MSG

        def fake_pw(wd, in_name, nproc=None, **_kw):
            ev.set()  # l'utilisateur a annulé pendant l'exécution
            raise RuntimeError(API_CANCEL_RUNTIME_MSG)

        with patch.object(opt, "run_pw_x_in", side_effect=fake_pw):
            with patch(
                "optical_props.cfg.pw_path",
                return_value=work_dir_with_scf / "fake_bin" / "pw.x",
            ):
                with patch(
                    "optical_props.cfg.epsilon_path",
                    return_value=work_dir_with_scf / "fake_bin" / "epsilon.x",
                ):
                    with pytest.raises(RuntimeError, match="Annulé"):
                        run_optical_properties(
                            work_dir_with_scf,
                            nproc=2,
                            scf_basename="scf.in",
                            cancel_event=ev,
                        )

    def test_nscf_failure_marks_nscf_false_silently(self, work_dir_with_scf):
        """Si pw.x NSCF_optic échoue, ``nscf_optic_ok=False`` et la chaîne
        optique entière est abandonnée sans crash."""
        with patch(
            "optical_props.cfg.pw_path",
            return_value=work_dir_with_scf / "fake_bin" / "pw.x",
        ):
            with patch(
                "optical_props.cfg.epsilon_path",
                return_value=work_dir_with_scf / "fake_bin" / "epsilon.x",
            ):
                with patch(
                    "optical_props.run_pw_x_in",
                    side_effect=RuntimeError("pw.x exploded (mock)"),
                ):
                    res = run_optical_properties(
                        work_dir_with_scf,
                        nproc=2,
                        scf_basename="scf.in",
                    )
        assert res.nscf_optic_ok is False
        assert res.epsilon_ok is False
        assert (work_dir_with_scf / "nscf_optic.in").is_file()
        assert any("NSCF_optic échoué" in n for n in res.notes)

    def test_log_emit_called_for_each_note(self, work_dir_with_scf):
        """Le callback ``log_emit`` reçoit CHAQUE note."""
        logs = []
        with patch(
            "optical_props.cfg.pw_path",
            return_value=work_dir_with_scf / "fake_bin" / "pw.x",
        ):
            with patch(
                "optical_props.cfg.epsilon_path",
                return_value=work_dir_with_scf / "fake_bin" / "epsilon.x",
            ):
                with patch("optical_props.run_pw_x_in", _fake_pw_x_in_creates_out):
                    with patch(
                        "optical_props.run_qe_stdin",
                        _fake_qe_stdin_creates_eps_files,
                    ):
                        run_optical_properties(
                            work_dir_with_scf,
                            nproc=2,
                            scf_basename="scf.in",
                            log_emit=logs.append,
                        )
        assert len(logs) > 0
        assert any("[OPTIC]" in line for line in logs)

    def test_full_flow_with_mocks(self, work_dir_with_scf):
        """Chaîne complète exhaustive P5 : NSCF_optic → epsilon.x →
        turbo_lanczos.x → turbo_davidson.x (toutes simulées via mocks).

        Vérifie :
          * génération des 4 fichiers d'entrée ;
          * dataclass correctement remplie pour les 3 chaînes optiques ;
          * .dat eps*/eels*/jdos* + chi* collectés.
        """
        with patch("optical_props.cfg.pw_path",
                   return_value=work_dir_with_scf / "fake_bin" / "pw.x"):
            with patch("optical_props.cfg.epsilon_path",
                       return_value=work_dir_with_scf / "fake_bin" / "epsilon.x"):
                with patch("optical_props.cfg.turbo_lanczos_path",
                           return_value=work_dir_with_scf / "fake_bin" / "turbo_lanczos.x"):
                    with patch("optical_props.cfg.turbo_davidson_path",
                               return_value=work_dir_with_scf / "fake_bin" / "turbo_davidson.x"):
                        with patch("optical_props.run_pw_x_in", _fake_pw_x_in_creates_out):
                            with patch("optical_props.run_qe_stdin",
                                       _fake_qe_stdin_creates_optic_files):
                                res = run_optical_properties(
                                    work_dir_with_scf,
                                    nproc=2,
                                    scf_basename="scf.in",
                                )

        # Fichiers d'entrée bien écrits (4 : SCF + NSCF_optic + epsilon + 2 turbo).
        assert (work_dir_with_scf / "nscf_optic.in").is_file()
        assert (work_dir_with_scf / "epsilon.in").is_file()
        assert (work_dir_with_scf / "turbo_lanczos.in").is_file()
        assert (work_dir_with_scf / "turbo_davidson.in").is_file()

        # Dataclass cohérente pour les 3 chaînes optiques.
        assert res.nscf_optic_ok is True
        assert res.epsilon_ok is True
        assert res.turbo_lanczos_ok is True
        assert res.turbo_davidson_ok is True
        assert res.nscf_optic_in == "nscf_optic.in"
        assert res.epsilon_in == "epsilon.in"
        assert res.turbo_lanczos_in == "turbo_lanczos.in"
        assert res.turbo_davidson_in == "turbo_davidson.in"
        assert res.nscf_optic_nbnd is not None
        assert res.nscf_optic_nbnd >= 16

        # Fichiers eps (epsilon.x) + turbo (.dat chi*) collectés.
        names = [Path(p).name for p in res.eps_dat_files]
        assert "eps11_0.dat" in names
        assert "eels22_1.dat" in names
        assert "jdos_3.dat" in names
        turbo_names = [Path(p).name for p in res.turbo_dat_files]
        assert "chi.dat" in turbo_names

        # Notes — chaque sous-chaîne doit être explicitement OK.
        assert any("[OPTIC] NSCF_optic terminé" in n for n in res.notes)
        assert any("[OPTIC] epsilon.x terminé" in n for n in res.notes)
        assert any("[OPTIC] turbo_lanczos.x terminé" in n for n in res.notes)
        assert any("[OPTIC] turbo_davidson.x terminé" in n for n in res.notes)

    def test_missing_turbo_lanczos_skipped_silently(self, work_dir_with_scf):
        """turbo_lanczos.x manquant : NSCF + epsilon + Davidson OK, Lanczos = False."""
        # Retire le binaire Lanczos du fixture.
        (work_dir_with_scf / "fake_bin" / "turbo_lanczos.x").unlink()
        with patch("optical_props.cfg.pw_path",
                   return_value=work_dir_with_scf / "fake_bin" / "pw.x"):
            with patch("optical_props.cfg.epsilon_path",
                       return_value=work_dir_with_scf / "fake_bin" / "epsilon.x"):
                with patch("optical_props.cfg.turbo_lanczos_path",
                           return_value=work_dir_with_scf / "fake_bin" / "turbo_lanczos.x"):
                    with patch("optical_props.cfg.turbo_davidson_path",
                               return_value=work_dir_with_scf / "fake_bin" / "turbo_davidson.x"):
                        with patch("optical_props.run_pw_x_in", _fake_pw_x_in_creates_out):
                            with patch("optical_props.run_qe_stdin",
                                       _fake_qe_stdin_creates_optic_files):
                                res = run_optical_properties(
                                    work_dir_with_scf,
                                    nproc=2,
                                    scf_basename="scf.in",
                                )
        # epsilon OK, Davidson OK, Lanczos NOT OK (binaire absent).
        assert res.epsilon_ok is True
        assert res.turbo_davidson_ok is True
        assert res.turbo_lanczos_ok is False
        assert res.turbo_lanczos_in is None
        # Note WARN explicite pour l'utilisateur.
        assert any("turbo_lanczos.x manquant" in n for n in res.notes)

    def test_missing_all_turbo_below_neither_set(self, work_dir_with_scf):
        """Ni Lanczos ni Davidson installés : epsilon OK, les 2 turbo OFF."""
        for nm in ("turbo_lanczos.x", "turbo_davidson.x"):
            (work_dir_with_scf / "fake_bin" / nm).unlink()
        with patch("optical_props.cfg.pw_path",
                   return_value=work_dir_with_scf / "fake_bin" / "pw.x"):
            with patch("optical_props.cfg.epsilon_path",
                       return_value=work_dir_with_scf / "fake_bin" / "epsilon.x"):
                with patch("optical_props.cfg.turbo_lanczos_path",
                           return_value=work_dir_with_scf / "fake_bin" / "turbo_lanczos.x"):
                    with patch("optical_props.cfg.turbo_davidson_path",
                               return_value=work_dir_with_scf / "fake_bin" / "turbo_davidson.x"):
                        with patch("optical_props.run_pw_x_in", _fake_pw_x_in_creates_out):
                            with patch("optical_props.run_qe_stdin",
                                       _fake_qe_stdin_creates_optic_files):
                                res = run_optical_properties(
                                    work_dir_with_scf,
                                    nproc=2,
                                    scf_basename="scf.in",
                                )
        assert res.epsilon_ok is True
        assert res.turbo_lanczos_ok is False
        assert res.turbo_davidson_ok is False
        # 2 notes WARN distinctes.
        assert sum("manquant" in n.lower() for n in res.notes) >= 2


# Helpers de simulation QE
# ============================================================================


def _fake_pw_x_in_creates_out(work_dir: Path, in_name: str, nproc=None, **_kw) -> Path:
    """Simule ``run_pw_x_in`` : crée ``<stem>.out`` contenant 'JOB DONE'."""
    out = work_dir / f"{Path(in_name).stem}.out"
    out.write_text("JOB DONE.\n")
    return out


def _fake_qe_stdin_creates_eps_files(
    exe: Path, inp: Path, work_dir: Path, log_file: Path, **_kw
) -> None:
    """Simule ``run_qe_stdin`` pour epsilon.x : crée le log + 3 fichiers eps."""
    log_file.write_text("epsilon.x JOB DONE.\n")
    (work_dir / "eps11_0.dat").write_text(
        "# fake eps : col1=omega[eV] col2=Im(epsilon)\n"
    )
    (work_dir / "eels22_1.dat").write_text("# fake eels\n")
    (work_dir / "jdos_3.dat").write_text("# fake jdos\n")


def _fake_qe_stdin_creates_optic_files(
    exe: Path, inp: Path, work_dir: Path, log_file: Path, **_kw
) -> None:
    """Simule ``run_qe_stdin`` pour **toute** la chaîne optique (epsilon + turbo).

    L'exécutable est identifié par le nom du fichier d'entrée :
      * ``epsilon.in``      → produit eps*/eels*/jdos* (3 fichiers).
      * ``turbo_lanczos.in`` → produit chi.dat + eigenvalues.dat (TDDFPT Lanczos).
      * ``turbo_davidson.in`` → produit chi.dat + spectrum.dat (TDDFPT Davidson).
    """
    name = inp.name
    log_file.write_text(f"{name} JOB DONE.\n")
    if name == "epsilon.in":
        (work_dir / "eps11_0.dat").write_text(
            "# fake eps : col1=omega[eV] col2=Im(epsilon)\n"
        )
        (work_dir / "eels22_1.dat").write_text("# fake eels\n")
        (work_dir / "jdos_3.dat").write_text("# fake jdos\n")
    elif name == "turbo_lanczos.in":
        (work_dir / "chi.dat").write_text(
            "# fake Lanczos : polarizability χ(ω)\n"
        )
        (work_dir / "eigenvalues_lanczos.dat").write_text(
            "# fake Lanczos eigenvalues\n"
        )
    elif name == "turbo_davidson.in":
        (work_dir / "chi.dat").write_text(
            "# fake Davidson : windowed polarizability\n"
        )
        (work_dir / "spectrum_davidson.dat").write_text(
            "# fake Davidson spectrum\n"
        )


# ============================================================================
# Tests : dataclass OpticalPropsResult
# ============================================================================


class TestOpticalPropsResultDataclass:
    def test_defaults_with_none(self):
        r = OpticalPropsResult(eps_dat_files=[], notes=[])
        assert r.nscf_optic_ok is False
        assert r.epsilon_ok is False
        assert r.nscf_optic_in is None
        assert r.epsilon_in is None
        assert r.nscf_optic_nbnd is None
        assert r.eps_dat_files == []
        assert r.notes == []

    def test_to_dict_handles_none_defaults(self):
        r = OpticalPropsResult()  # tout est None
        d = r.to_dict()
        # Les listes None → [] via `list(self.X or [])`
        assert d["eps_dat_files"] == []
        assert d["notes"] == []
        assert d["nscf_optic_ok"] is False
        assert d["epsilon_ok"] is False

    def test_to_dict_serializes_all_fields(self):
        r = OpticalPropsResult(
            nscf_optic_ok=True,
            epsilon_ok=True,
            nscf_optic_in="nscf_optic.in",
            epsilon_in="epsilon.in",
            nscf_optic_nbnd=32,
            eps_dat_files=["eps11_0.dat", "eels22_1.dat"],
            notes=["note A", "note B"],
        )
        d = r.to_dict()
        assert d["nscf_optic_ok"] is True
        assert d["epsilon_ok"] is True
        assert d["nscf_optic_in"] == "nscf_optic.in"
        assert d["epsilon_in"] == "epsilon.in"
        assert d["nscf_optic_nbnd"] == 32
        assert d["eps_dat_files"] == ["eps11_0.dat", "eels22_1.dat"]
        assert d["notes"] == ["note A", "note B"]


# ============================================================================
# Tests : helpers bas-niveau
# ============================================================================


class TestListEpsDatFiles:
    def test_globs_eps_eels_jdos(self, tmp_path):
        (tmp_path / "eps11_0.dat").write_text("x")
        (tmp_path / "eels22_1.dat").write_text("x")
        (tmp_path / "jdos_3.dat").write_text("x")
        (tmp_path / "unrelated.txt").write_text("x")
        result = _list_eps_dat_files(tmp_path)
        names = sorted(Path(p).name for p in result)
        assert names == ["eels22_1.dat", "eps11_0.dat", "jdos_3.dat"]

    def test_empty_dir(self, tmp_path):
        assert _list_eps_dat_files(tmp_path) == []

    def test_returns_relpath_when_under_workdir(self, tmp_path):
        (tmp_path / "eps11_0.dat").write_text("x")
        result = _list_eps_dat_files(tmp_path)
        assert result == ["eps11_0.dat"]


class TestExtractPrefix:
    def test_single_quoted(self):
        assert _extract_prefix_from_text("prefix = 'pw_scf'\n") == "pw_scf"

    def test_double_quoted(self):
        assert _extract_prefix_from_text('prefix = "pw_scf"\n') == "pw_scf"

    def test_no_prefix_returns_default(self):
        assert _extract_prefix_from_text("&SYSTEM\n  ibrav=2\n/\n") == "pw_scf"

    def test_with_trailing_comma(self):
        assert _extract_prefix_from_text("  prefix = 'mycalc',\n") == "mycalc"

    def test_custom_prefix(self):
        assert _extract_prefix_from_text("prefix = 'BaTiO3'\n") == "BaTiO3"


# ============================================================================
# Tests d'intégration : PROFILES["P5"] dans backend/pipeline.py
# ============================================================================


class TestP5ProfileInPipeline:
    """Vérifie que le profil P5 « Propriétés diélectriques » est bien déclaré
    (thermo_pw what='dielectric' + chaîne optique ε(ω) opt-in)."""

    def test_p5_profile_registered(self):
        try:
            import sys
            sys.path.insert(0, str(BACKEND))
            from pipeline import PROFILES, get_profile
        except Exception as ex:
            pytest.skip(f"pipeline.py non importable dans ce contexte : {ex}")
        assert "P5" in PROFILES, "PROFILES['P5'] manquant dans pipeline.py"
        p5 = get_profile("P5")
        assert "dielectric" in p5["name"].lower(), (
            f"P5 name must contain 'dielectric' (got {p5['name']!r})"
        )
        assert p5.get("what_qe") == "dielectric"

    def test_p5_flags_consistent(self):
        try:
            import sys
            sys.path.insert(0, str(BACKEND))
            from pipeline import get_profile
        except Exception as ex:
            pytest.skip(f"pipeline.py non importable dans ce contexte : {ex}")
        p5 = get_profile("P5")
        assert p5.get("skip_thermo_pw") is not True, "P5 exécute thermo_pw what='dielectric'"
        assert p5.get("needs_optical") is False, "P5 : chaîne optique ε(ω) opt-in (défaut off)"
        assert p5.get("needs_optical_overridable") is True
        assert p5.get("needs_phonons") is True, "P5 requiert fildyn phonon pour dielectric"
        assert p5.get("needs_eos") is False
        assert p5.get("properties_enabled") is True, (
            "P5 doit aussi produire la chaîne NSCF → DOS → bandes "
            "(sanity check gap avant optique)"
        )
        assert p5.get("properties_ichamp") == 3

    def test_p5_exposes_full_optical_chain_in_steps(self):
        """P5 doit documenter epsilon.x + turbo_* dans steps (opt-in)."""
        try:
            import sys
            sys.path.insert(0, str(BACKEND))
            from pipeline import get_profile
        except Exception as ex:
            pytest.skip(f"pipeline.py non importable : {ex}")
        p5 = get_profile("P5")
        steps_text = " ".join(p5.get("steps") or []).lower()
        assert "dielectric" in steps_text, "steps doit mentionner what='dielectric'"
        assert "epsilon.x" in steps_text, "steps doit mentionner epsilon.x (opt-in)"
        assert "turbo_lanczos" in steps_text, "steps doit mentionner turbo_lanczos.x"
        assert "turbo_davidson" in steps_text, "steps doit mentionner turbo_davidson.x"

    def test_p5_expected_files_include_turbo(self):
        """expected_results.files doit inclure les 4 chaînes optiques."""
        try:
            import sys
            sys.path.insert(0, str(BACKEND))
            from pipeline import get_profile
        except Exception as ex:
            pytest.skip(f"pipeline.py non importable : {ex}")
        p5 = get_profile("P5")
        names = {e["name"] for e in p5["expected_results"]["files"]}
        required = {
            "epsilon.in", "turbo_lanczos.in", "turbo_davidson.in",
            "nscf_optic.in", "turbo_lanczos.out", "turbo_davidson.out",
        }
        missing = required - names
        assert not missing, (
            f"expected_results.files doit inclure {required}, manque {missing}"
        )

    def test_p1_to_p5_consistency(self):
        try:
            import sys
            sys.path.insert(0, str(BACKEND))
            from pipeline import PROFILES
        except Exception as ex:
            pytest.skip(f"pipeline.py non importable dans ce contexte : {ex}")
        for pid in ("P1", "P2", "P3", "P4", "P5"):
            assert pid in PROFILES, f"{pid} manquant"
            assert PROFILES[pid].get("properties_enabled") is True, (
                f"{pid} doit avoir properties_enabled=True "
                "(chaîne ichamp=3 partagée P1↔P5)"
            )
            assert PROFILES[pid].get("properties_ichamp") == 3, (
                f"{pid} doit utiliser ichamp=3"
            )


# ============================================================================
# Tests du wrapper no-op historique — _inject_lcalc_to_scf + inject_lcalc_quantities
# (juin 2026 : désactivés car pw.x 7.5 ne reconnaît PAS lcalc_bands/lcalc_dos
#  dans &CONTROL — la DOS/bandes sont prises en charge par run_electronic_properties).
# ============================================================================


class TestInjectLcalcQuantities:
    """Tests pour ``backend.electronic_props.inject_lcalc_quantities`` (no-op historique).

    **Depuis juin 2026** : ``inject_lcalc_quantities`` est un **no-op strict**.
    Anciennement, injectait ``lcalc_bands = .true.`` et ``lcalc_dos = .true.``
    dans ``&CONTROL`` du SCF (engagement « inconditionnel P1-P5 »).

    Pourquoi no-op :
      * ``pw.x`` 7.5 **ne reconnaît PAS** ces deux flags dans ``&CONTROL``
        (cf. grammaire ``read_namelists`` + INPUT_PW.html : ``&CONTROL``
        accepte seulement ``calculation``, ``restart_mode``, ``wf_collect``,
        ``prefix``, ``outdir``, ``pseudo_dir``, ``verbosity``, ``nstep``).
      * L'injection déclenche alors ``Error in routine read_namelists (1):
        bad line in namelist &control: "lcalc_dos = .true.,"``, tuant le SCF
        avant convergence (cf. fichiers ``CRASH`` dans ``work/<Mat>/``).
      * La DOS/bandes sont prises en charge par la chaîne dédiée
        ``run_electronic_properties`` (NSCF ``restart_mode='restart'``
        + dos.x + bands.x) **sans toucher au SCF équilibre**.

    Signature préservée pour rétro-compatibilité (``pipeline.py``,
    scripts externes, tests). Renvoie le texte inchangé en toutes
    circonstances.
    """

    def test_noop_preserves_input_strictly(self):
        """Aucun flag injecté : input strictement identique à output."""
        from electronic_props import inject_lcalc_quantities

        text = (
            "&CONTROL\n"
            "  calculation = 'scf',\n"
            "  prefix = 'pw_scf',\n"
            "  outdir = './out/'\n"
            "/\n"
            "&SYSTEM\n"
            "  ibrav = 2\n"
            "/\n"
        )
        result = inject_lcalc_quantities(text)
        # No-op strict : input == output (aucune ligne ajoutée, aucun rewapping).
        assert result == text
        # Aucun flag QE natif présent.
        assert "lcalc_bands" not in result
        assert "lcalc_dos" not in result
        # Les autres clés du template restent préservées.
        assert "calculation = 'scf'" in result
        assert "prefix = 'pw_scf'" in result

    def test_noop_preserves_explicit_false(self):
        """Valeurs ``.false.`` explicites (utilisateur expert) : préservées."""
        from electronic_props import inject_lcalc_quantities

        text = (
            "&CONTROL\n"
            "  lcalc_bands = .false.,\n"
            "  lcalc_dos = .false.,\n"
            "  calculation = 'scf'\n"
            "/\n"
        )
        result = inject_lcalc_quantities(text)
        # No-op strict : input == output ⇒ pas d'écrasement vers .true.
        assert result == text
        assert "lcalc_bands = .false." in result
        assert "lcalc_dos = .false." in result
        assert "lcalc_bands = .true." not in result
        assert "lcalc_dos = .true." not in result

    def test_noop_preserves_explicit_true_without_duplication(self):
        """Valeurs ``.true.`` explicites : préservées sans doublon."""
        from electronic_props import inject_lcalc_quantities

        text = (
            "&CONTROL\n"
            "  lcalc_bands = .true.,\n"
            "  lcalc_dos = .true.,\n"
            "  calculation = 'scf'\n"
            "/\n"
        )
        result = inject_lcalc_quantities(text)
        # No-op strict : pas de doublon, pas d'insertion additionnelle.
        assert result == text
        assert result.count("lcalc_bands =") == 1
        assert result.count("lcalc_dos =") == 1
        assert "lcalc_bands = .true." in result
        assert "lcalc_dos = .true." in result

    def test_noop_keeps_all_blocks_intact(self):
        """``&CONTROL`` / ``&SYSTEM`` / cartes ATOMIC_* : strictement inchangés."""
        from electronic_props import inject_lcalc_quantities

        text = (
            "&CONTROL\n"
            "  calculation = 'scf'\n"
            "/\n"
            "&SYSTEM\n"
            "  ibrav = 2\n"
            "/\n"
            "ATOMIC_SPECIES\n"
            "  Si 28.0855 Si.pbe-n-kjpaw_psl.0.1.UPF\n"
        )
        result = inject_lcalc_quantities(text)
        assert result == text
        # Aucun flag introduit.
        assert "lcalc_bands" not in result
        assert "lcalc_dos" not in result
        # Sanity : le bloc &SYSTEM est encore présent, intact.
        assert "&SYSTEM" in result
        assert "ibrav = 2" in result
        assert "ATOMIC_SPECIES" in result


# ============================================================================
# Tests : _inject_lcalc_to_scf (helper pipeline.py — wrapper d'I/O no-op historique)
# ============================================================================


class TestInjectLcalcToScf:
    """Tests du wrapper ``pipeline._inject_lcalc_to_scf`` (file I/O no-op).

    Depuis juin 2026, ``_inject_lcalc_to_scf`` est un **no-op strict** :
    lit le SCF, applique ``inject_lcalc_quantities`` (lui-même no-op), ne
    réécrit rien (input == output), retourne toujours ``False``.

    Conservé pour rétro-compatibilité. Ces tests valident **le contrat
    no-op** : le SCF sur disque n'est jamais modifié par le wrapper.
    """

    def _dummy_scf(self, work_dir: Path) -> Path:
        """Crée un SCF sans lcalc_* ni wf_collect explicite."""
        scf = work_dir / "scf.in"
        scf.write_text(
            "&CONTROL\n"
            "  calculation = 'scf',\n"
            "  prefix = 'pw_scf',\n"
            "  outdir = './out/',\n"
            "  pseudo_dir = './pseudos/'\n"
            "/\n"
            "&SYSTEM\n"
            "  ibrav = 2, nat = 2, ntyp = 1, ecutwfc = 40.0, nbnd = 8\n"
            "/\n"
            "K_POINTS automatic\n"
            "  4 4 4 0 0 0\n",
            encoding="utf-8",
        )
        return scf

    def test_first_call_returns_false_unmodified(self, tmp_path):
        """1er appel sur SCF vierge : no-op strict, retourne False, fichier intact."""
        try:
            from pipeline import _inject_lcalc_to_scf  # noqa: E402
        except Exception as ex:  # noqa: BLE001
            pytest.skip(f"pipeline.py non importable en test rapide : {ex}")
        scf = self._dummy_scf(tmp_path)
        text_before = scf.read_text()
        modified = _inject_lcalc_to_scf(scf)
        text_after = scf.read_text()
        assert modified is False, "No-op : retourne False (jamais True)"
        # Fichier strictement non modifié sur disque.
        assert text_after == text_before
        # Aucun flag injecté via le wrapper.
        assert "lcalc_bands" not in text_after
        assert "lcalc_dos" not in text_after

    def test_repeated_calls_are_stable_noop(self, tmp_path):
        """Appels répétés : tous False, le fichier reste bit-identique."""
        try:
            from pipeline import _inject_lcalc_to_scf  # noqa: E402
        except Exception as ex:  # noqa: BLE001
            pytest.skip(f"pipeline.py non importable en test rapide : {ex}")
        scf = self._dummy_scf(tmp_path)
        text_0 = scf.read_text()
        m1 = _inject_lcalc_to_scf(scf)
        text_1 = scf.read_text()
        m2 = _inject_lcalc_to_scf(scf)
        text_2 = scf.read_text()
        m3 = _inject_lcalc_to_scf(scf)
        text_3 = scf.read_text()
        # Tous les appels retournent False (no-op strict).
        assert m1 is False and m2 is False and m3 is False
        # Texte bit-identique sur disque à travers tous les appels.
        assert text_0 == text_1 == text_2 == text_3

    def test_explicit_false_preserved_noop(self, tmp_path):
        """SCF avec ``.false.`` explicites : wrapper no-op strict, valeurs préservées."""
        try:
            from pipeline import _inject_lcalc_to_scf  # noqa: E402
        except Exception as ex:  # noqa: BLE001
            pytest.skip(f"pipeline.py non importable en test rapide : {ex}")
        scf = tmp_path / "scf.in"
        scf.write_text(
            "&CONTROL\n"
            "  lcalc_bands = .false.,\n"
            "  lcalc_dos = .false.,\n"
            "  calculation = 'scf'\n"
            "/\n",
            encoding="utf-8",
        )
        text_before = scf.read_text()
        modified = _inject_lcalc_to_scf(scf)
        text_after = scf.read_text()
        assert modified is False
        assert text_after == text_before
        # Pas d'écrasement vers .true. (sémantique utilisateur expert).
        assert "lcalc_bands = .false." in text_after
        assert "lcalc_dos = .false." in text_after
        assert "lcalc_bands = .true." not in text_after
        assert "lcalc_dos = .true." not in text_after

    def test_missing_file_returns_false(self, tmp_path):
        """Fichier absent : retourne False (graceful no-op)."""
        try:
            from pipeline import _inject_lcalc_to_scf  # noqa: E402
        except Exception as ex:  # noqa: BLE001
            pytest.skip(f"pipeline.py non importable en test rapide : {ex}")
        missing = tmp_path / "non_existent_scf.in"
        assert _inject_lcalc_to_scf(missing) is False


class TestPipelineProfilesAPI:
    """GET /api/pipeline/profiles expose les champs guide d'utilisation."""

    _GUIDE_FIELDS = (
        "inputs", "outputs", "steps", "prerequisites", "params_summary",
    )

    def test_profiles_route_exposes_guide_fields(self, client):
        if not getattr(__import__("api_server"), "PIPELINE_AVAILABLE", False):
            pytest.skip("Pipeline blueprint indisponible")
        r = client.get("/api/pipeline/profiles")
        assert r.status_code == 200
        data = r.get_json()
        profiles = {p["id"]: p for p in data.get("profiles", [])}
        for pid in ("P1", "P2", "P3", "P4", "P5"):
            assert pid in profiles, f"profil {pid} manquant"
            prof = profiles[pid]
            for field in self._GUIDE_FIELDS:
                assert field in prof, f"{pid} : champ API {field!r} manquant"
                assert isinstance(prof[field], list), f"{pid}.{field} doit être une liste"
                assert prof[field], f"{pid}.{field} ne doit pas être vide"

    def test_p2_what_qe_display_mur_lc_t(self, client):
        if not getattr(__import__("api_server"), "PIPELINE_AVAILABLE", False):
            pytest.skip("Pipeline blueprint indisponible")
        r = client.get("/api/pipeline/profiles")
        p2 = next(p for p in r.get_json()["profiles"] if p["id"] == "P2")
        assert p2["what_qe"] == "thermo"
        assert "mur_lc_t" in p2["what_qe_display"]

    def test_all_profiles_expose_magnetism_metrics(self):
        from pipeline import PROFILES, _METRICS_MAGNETISM
        mag_keys = {m["key"] for m in _METRICS_MAGNETISM}
        for pid in ("P1", "P2", "P3", "P4", "P5"):
            metrics = PROFILES[pid]["expected_results"]["metrics"]
            keys = {m["key"] for m in metrics}
            missing = mag_keys - keys
            assert not missing, f"{pid} manque métriques magnétisme : {sorted(missing)}"

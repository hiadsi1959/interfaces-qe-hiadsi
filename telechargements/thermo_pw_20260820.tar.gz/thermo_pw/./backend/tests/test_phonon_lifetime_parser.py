"""Tests pour ``backend/parsers/phonon_lifetime.py`` (refonte juin 2026).

Couvre :
  * ``parse_phonon_lifetime(work_dir)`` : orchestrateur (combine log + fichiers).
  * ``parse_phonon_lifetime_file(path)`` : fichier colonne 3 ou 4 colonnes
    (freq_cm-1, linewidth_cm-1, lifetime_ps [, volume]).
  * ``parse_kappa_lattice_file(path)`` : κ_lattice(T) — colonnes T(K) κ[W/(m·K)].
  * ``parse_gruneisen_file(path)`` : γ(q,ν) modal.

Format thermo_pw 7.x (ug.1.5.0+) : juin 2021.
"""
from __future__ import annotations

import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_BACKEND = os.path.dirname(_HERE)
if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)

import pytest

from parsers.phonon_lifetime import (
    parse_phonon_lifetime,
    parse_phonon_lifetime_file,
    parse_kappa_lattice_file,
    parse_gruneisen_file,
)


# ============================================================================
# ``parse_phonon_lifetime_file`` — fichier colonne
# ============================================================================


def test_phonon_lifetime_file_basic_3cols(tmp_path):
    p = tmp_path / "phonon_lifetime.dat"
    p.write_text(
        "# frequency (cm^-1) linewidth (cm^-1) lifetime (ps)\n"
        "  100.0   0.430   12.345\n"
        "  200.0   0.520   10.234\n"
        "  300.0   1.210    4.380\n",
        encoding="utf-8",
    )
    out = parse_phonon_lifetime_file(p)
    assert "error" not in out or out["error"] is None
    assert "rows" in out
    assert len(out["rows"]) == 3
    sm = out["summary"]
    assert sm["n_points"] == 3
    assert sm["lifetime_min"] == pytest.approx(4.380, rel=1e-6)
    assert sm["lifetime_max"] == pytest.approx(12.345, rel=1e-6)
    assert sm["lifetime_mean"] == pytest.approx((12.345 + 10.234 + 4.380) / 3.0, rel=1e-6)


def test_phonon_lifetime_file_handles_fortran_D(tmp_path):
    p = tmp_path / "phonon_lifetime.dat"
    p.write_text(
        "  100.00   0.430D+00   1.234D+01\n"
        "  200.00   0.520d-1    1.023d+01\n",
        encoding="utf-8",
    )
    out = parse_phonon_lifetime_file(p)
    assert out["rows"][1][1] == pytest.approx(0.052, rel=1e-6)
    assert out["rows"][0][2] == pytest.approx(12.34, rel=1e-6)


def test_phonon_lifetime_file_skips_header_without_comment(tmp_path):
    p = tmp_path / "phonon_lifetime.dat"
    p.write_text(
        "header row without comment marker\n"
        "  100.0   0.430   12.345\n",
        encoding="utf-8",
    )
    out = parse_phonon_lifetime_file(p)
    assert len(out["rows"]) == 1
    assert out["rows"][0][2] == pytest.approx(12.345, rel=1e-6)


def test_phonon_lifetime_file_no_data_returns_empty(tmp_path):
    p = tmp_path / "phonon_lifetime.dat"
    p.write_text("# only comments\n# nothing else\n", encoding="utf-8")
    out = parse_phonon_lifetime_file(p)
    assert out["rows"] == []


def test_phonon_lifetime_file_missing_ioerror(tmp_path):
    p = tmp_path / "does_not_exist.dat"
    out = parse_phonon_lifetime_file(p)
    assert out["error"]


# ============================================================================
# ``parse_kappa_lattice_file``
# ============================================================================


def test_kappa_lattice_basic(tmp_path):
    p = tmp_path / "kappa_lattice.dat"
    p.write_text(
        "# T(K)  kappa (W/mK)\n"
        "  100.0    250.0\n"
        "  200.0    180.0\n"
        "  300.0    120.0\n"
        "  400.0     80.0\n",
        encoding="utf-8",
    )
    out = parse_kappa_lattice_file(p)
    assert out["rows"] and len(out["rows"]) == 4
    assert out["min_W_mK"] == pytest.approx(80.0, rel=1e-6)
    assert out["max_W_mK"] == pytest.approx(250.0, rel=1e-6)
    assert out["mean_W_mK"] == pytest.approx((250 + 180 + 120 + 80) / 4.0, rel=1e-6)


def test_kappa_lattice_skips_invalid(tmp_path):
    p = tmp_path / "kappa_lattice.dat"
    p.write_text(
        "  300.0    120.0\n"
        "  abc def\n"
        "  -200 something\n"
        "  500.0     70.0\n",
        encoding="utf-8",
    )
    out = parse_kappa_lattice_file(p)
    # Seules les lignes valides (300K=120, 500K=70) sont retenues.
    assert len(out["rows"]) == 2


# ============================================================================
# ``parse_gruneisen_file``
# ============================================================================


def test_gruneisen_basic(tmp_path):
    p = tmp_path / "gruneisen.dat"
    p.write_text(
        "# mode  frequency(cm-1)  gruneisen\n"
        "  1   100   0.50\n"
        "  2   200   1.20\n"
        "  3   300  -0.10\n",
        encoding="utf-8",
    )
    out = parse_gruneisen_file(p)
    assert len(out["values"]) == 3
    assert out["mean"] == pytest.approx((0.50 + 1.20 + (-0.10)) / 3.0, rel=1e-6)
    assert out["max_abs"] == pytest.approx(1.20, rel=1e-6)


# ============================================================================
# ``parse_phonon_lifetime`` — orchestrateur work_dir
# ============================================================================


def test_orchestrator_with_summary_only(tmp_path):
    """Cas où seul ``thermo_pw_run.out`` contient les résumés « Mean lifetime »."""
    (tmp_path / "thermo_pw_run.out").write_text(
        "Some unrelated output...\n"
        "\n"
        "Phonon lifetime at T = 300.0 K\n"
        "\n"
        "Mean lifetime at T=300.0K: 12.345 ps\n"
        "Mean linewidth at T=300.0K: 0.470 cm-1\n"
        "\n"
        "job done\n",
        encoding="utf-8",
    )
    out = parse_phonon_lifetime(tmp_path)
    assert out["mean_lifetime_ps"] == pytest.approx(12.345, rel=1e-6)
    assert out["mean_linewidth_cm-1"] == pytest.approx(0.470, rel=1e-6)
    assert out["temperature_K_for_summary"] == 300.0
    assert "summary_mean_lifetime" in out["matched_keywords"]


def test_orchestrator_with_file_overrides_log(tmp_path):
    """Le fichier colonne complète les valeurs manquantes du journal."""
    (tmp_path / "thermo_pw_run.out").write_text("header-like text\n", encoding="utf-8")
    (tmp_path / "phonon_lifetime.dat").write_text(
        "# frequency linewidth lifetime\n"
        "  100.0   0.5   10.0\n"
        "  200.0   0.6    8.0\n"
        "  300.0   1.0    5.0\n",
        encoding="utf-8",
    )
    out = parse_phonon_lifetime(tmp_path)
    assert out["mean_lifetime_ps"] == pytest.approx((10 + 8 + 5) / 3.0, rel=1e-6)
    assert out["mean_linewidth_cm-1"] == pytest.approx((0.5 + 0.6 + 1.0) / 3.0, rel=1e-6)
    assert out["min_lifetime_ps"] == pytest.approx(5.0, rel=1e-6)
    assert out["max_linewidth_cm-1"] == pytest.approx(1.0, rel=1e-6)


def test_orchestrator_combines_all_sources(tmp_path):
    (tmp_path / "thermo_pw_run.out").write_text(
        "Mean lifetime at T=300.0K: 10.0 ps\n"
        "Mean linewidth at T=300.0K: 0.5 cm-1\n"
        "Gruneisen parameter is: 1.05\n"
        " 1   100   0.50\n"
        " 2   200   1.20\n",
        encoding="utf-8",
    )
    (tmp_path / "kappa_lattice.dat").write_text(
        "  300.0   120.0\n"
        "  500.0    50.0\n",
        encoding="utf-8",
    )
    (tmp_path / "gruneisen.dat").write_text(
        "1.05\n0.50\n1.20\n-0.10\n",
        encoding="utf-8",
    )
    out = parse_phonon_lifetime(tmp_path)
    assert out["lattice_kappa_W_mK"] == pytest.approx(85.0, rel=1e-6)
    assert out["gruneisen_mean"] == pytest.approx((1.05 + 0.50 + 1.20 + (-0.10)) / 4.0, rel=1e-6)
    assert out["gruneisen_max_abs"] == pytest.approx(1.20, rel=1e-6)


def test_orchestrator_no_outputs_marks_no_match(tmp_path):
    out = parse_phonon_lifetime(tmp_path)
    assert "no_ph_life_outputs_found" in out["matched_keywords"]
    assert out["mean_lifetime_ps"] is None


def test_orchestrator_mode_lines_extracted(tmp_path):
    """Lignes ``q-point (..) mode N: τ = … ps, γ = … cm-1`` extraites en modes[]."""
    (tmp_path / "thermo_pw_run.out").write_text(
        "Phonon lifetime at T = 300.0 K\n"
        "q-point (12/64) mode  3: τ =  12.345 ps, γ =  0.430 cm^-1\n"
        "q-point (12/64) mode  4: τ =  10.234 ps, γ =  0.520 cm^-1\n"
        "Mean lifetime at T=300.0K: 11.500 ps\n",
        encoding="utf-8",
    )
    out = parse_phonon_lifetime(tmp_path)
    assert len(out["modes"]) == 2
    assert out["modes"][0]["q_index"] == 12
    assert out["modes"][0]["mode_index"] == 3
    assert out["modes"][0]["lifetime_ps"] == pytest.approx(12.345, rel=1e-6)
    assert out["modes"][0]["linewidth_cm-1"] == pytest.approx(0.430, rel=1e-6)
    assert out["mean_lifetime_ps"] == pytest.approx(11.5, rel=1e-6)

"""Tests pour la normalisation ``results.plots.*`` (string vs dict legacy)."""
from __future__ import annotations

from pipeline import (
    _normalize_plot_relpath,
    _sanitize_plots_section,
    _set_plot_path,
)


def test_normalize_plot_relpath_string():
    assert _normalize_plot_relpath("1_eos_volumes/eos_ev.png") == (
        "1_eos_volumes/eos_ev.png"
    )


def test_normalize_plot_relpath_dict():
    assert _normalize_plot_relpath({"relpath": "1_eos_volumes/eos_ev.png"}) == (
        "1_eos_volumes/eos_ev.png"
    )


def test_set_plot_path_writes_string():
    results: dict = {}
    _set_plot_path(results, "eos_ev", {"relpath": "1_eos_volumes/eos_ev.png"})
    assert results["plots"]["eos_ev"] == "1_eos_volumes/eos_ev.png"


def test_sanitize_plots_migrates_eos_ev_post():
    results = {
        "plots": {
            "eos_ev": {"relpath": "1_eos_volumes/eos_ev.png"},
            "eos_ev_post": "legacy/wrong.png",
        }
    }
    _sanitize_plots_section(results)
    assert results["plots"]["eos_ev"] == "1_eos_volumes/eos_ev.png"
    assert "eos_ev_post" not in results["plots"]

"""Tests de ``input_scaling.extract_lattice_parameters`` (août 2026).

Contexte : après le fit Birch–Murnaghan, l'interface affiche la maille
d'équilibre (a₀/b₀/c₀) lue dans ``scf_eq.in`` — déjà à l'échelle V₀. Ce
parseur doit couvrir les trois façons d'écrire une maille dans pw.x :
``ibrav + celldm``, ``A/B/C`` (Å) et ``CELL_PARAMETERS`` (ibrav=0).
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from input_scaling import BOHR_TO_ANGSTROM, extract_lattice_parameters  # noqa: E402


class TestCelldm:
    def test_cubic_fcc_fills_b_and_c_equal_to_a(self):
        lat = extract_lattice_parameters(
            "&SYSTEM\n ibrav = 2\n celldm(1) = 10.336580\n nat = 2\n/"
        )
        assert lat["a0_bohr"] == pytest.approx(10.33658)
        assert lat["a0_A"] == pytest.approx(10.33658 * BOHR_TO_ANGSTROM, rel=1e-6)
        # Cubique : la convention b = c = a est explicite pour l'utilisateur.
        assert lat["b0_A"] == lat["a0_A"] and lat["c0_A"] == lat["a0_A"]
        assert lat["lattice_source"] == "ibrav + celldm"

    def test_hexagonal_c_comes_from_celldm3(self):
        lat = extract_lattice_parameters(
            "&SYSTEM\n ibrav = 4\n celldm(1) = 5.8\n celldm(3) = 1.62\n/"
        )
        assert lat["b0_A"] == lat["a0_A"]  # hex : b = a
        assert lat["c0_A"] == pytest.approx(1.62 * 5.8 * BOHR_TO_ANGSTROM, rel=1e-5)

    def test_orthorhombic_b_from_celldm2(self):
        lat = extract_lattice_parameters(
            "&SYSTEM\n ibrav = 8\n celldm(1) = 9.0\n"
            " celldm(2) = 1.1\n celldm(3) = 1.3\n/"
        )
        assert lat["b0_A"] == pytest.approx(1.1 * 9.0 * BOHR_TO_ANGSTROM, rel=1e-5)
        assert lat["c0_A"] == pytest.approx(1.3 * 9.0 * BOHR_TO_ANGSTROM, rel=1e-5)


class TestAngstromKeywords:
    def test_abc_angstrom(self):
        lat = extract_lattice_parameters(
            "&SYSTEM\n ibrav = 8\n A = 4.5\n B = 5.1\n C = 6.2\n/"
        )
        assert lat["a0_A"] == pytest.approx(4.5)
        assert lat["b0_A"] == pytest.approx(5.1)
        assert lat["c0_A"] == pytest.approx(6.2)
        assert lat["a0_bohr"] == pytest.approx(4.5 / BOHR_TO_ANGSTROM, rel=1e-6)


class TestCellParameters:
    def test_ibrav0_angstrom_uses_vector_norms(self):
        lat = extract_lattice_parameters(
            "&SYSTEM\n ibrav = 0\n/\n"
            "CELL_PARAMETERS angstrom\n"
            " 3.0 0.0 0.0\n 0.0 4.0 0.0\n 0.0 0.0 5.0\n"
        )
        assert lat["a0_A"] == pytest.approx(3.0)
        assert lat["b0_A"] == pytest.approx(4.0)
        assert lat["c0_A"] == pytest.approx(5.0)
        assert lat["lattice_source"].startswith("normes")

    def test_ibrav0_alat_scaled_by_celldm1(self):
        lat = extract_lattice_parameters(
            "&SYSTEM\n ibrav = 0\n celldm(1) = 10.0\n/\n"
            "CELL_PARAMETERS (alat)\n"
            " 1.0 0.0 0.0\n 0.0 1.0 0.0\n 0.0 0.0 1.5\n"
        )
        assert lat["a0_bohr"] == pytest.approx(10.0)
        assert lat["c0_A"] == pytest.approx(15.0 * BOHR_TO_ANGSTROM, rel=1e-6)


class TestRobustness:
    def test_no_lattice_info_returns_all_none(self):
        lat = extract_lattice_parameters("&SYSTEM\n nat = 2\n/")
        assert all(
            lat[k] is None for k in ("a0_bohr", "a0_A", "b0_A", "c0_A")
        )

    def test_fortran_d_exponent_is_accepted(self):
        lat = extract_lattice_parameters(
            "&SYSTEM\n ibrav = 1\n celldm(1) = 1.05d1\n/"
        )
        assert lat["a0_bohr"] == pytest.approx(10.5)

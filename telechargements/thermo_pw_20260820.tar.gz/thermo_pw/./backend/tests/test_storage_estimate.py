"""Tests de l'estimation d'espace disque (``storage_estimate``).

Le test central est ``TestFidelityToMeasuredRun`` : le modèle doit reproduire la
répartition réellement mesurée sur un run P2/Si, dont les tailles ont été
relevées fichier par fichier. Sans ce verrou, un ajustement de coefficient
pourrait décaler l'affichage sans que rien ne le signale.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import runtime_estimate as rte  # noqa: E402
import storage_estimate as se  # noqa: E402

MIB = se.MIB

# Entrée de référence : le silicium du pipeline. QE rapporte pour cette maille
# (au volume relaxé V₀ = 277,27 bohr³) : 8 électrons, 4 bandes de Kohn-Sham,
# 49 229 vecteurs G denses, dimensions FFT 60×60×60.
SI_SCF = """&CONTROL
  calculation = 'scf'
  prefix = 'si'
  pseudo_dir = '.'
/
&SYSTEM
  ibrav = 2
  celldm(1) = 10.2612
  nat = 2
  ntyp = 1
  ecutwfc = 60
  ecutrho = 480
  occupations = 'fixed'
/
&ELECTRONS
  conv_thr = 1e-8
/
ATOMIC_SPECIES
 Si 28.086 Si_ONCV_PBE-1.2.upf
ATOMIC_POSITIONS crystal
 Si 0.00 0.00 0.00
 Si 0.25 0.25 0.25
K_POINTS automatic
 12 12 12 0 0 0
"""

# En-tête pw.x réel, tronqué aux lignes que le module lit.
PW_OUT = """
     unit-cell volume          =     277.2730 (a.u.)^3
     number of atoms/cell      =            2
     number of electrons       =         8.00
     number of Kohn-Sham states=            4
     kinetic-energy cutoff     =      60.0000  Ry
     charge density cutoff     =     480.0000  Ry
     number of k points=    72
     Dense  grid:    49229 G-vectors     FFT dimensions: (  60,  60,  60)
     Smooth grid:    17453 G-vectors     FFT dimensions: (  40,  40,  40)
"""

UPF_V2 = '<UPF version="2.0.1">\n<PP_HEADER\n z_valence="    4.00"\n l_max="2"\n/>\n'
UPF_V1 = "<PP_HEADER>\n   4.00000000000000E+00     Z valence\n</PP_HEADER>\n"


@pytest.fixture()
def si_scf(tmp_path):
    p = tmp_path / "scf.in"
    p.write_text(SI_SCF, encoding="utf-8")
    return p


@pytest.fixture()
def pseudo_dir(tmp_path):
    d = tmp_path / "pseudos"
    d.mkdir()
    (d / "Si_ONCV_PBE-1.2.upf").write_text(UPF_V2, encoding="utf-8")
    return d


@pytest.fixture()
def descriptors(si_scf):
    return rte.parse_material_descriptors(pw_path=si_scf)


@pytest.fixture()
def facts(si_scf, descriptors, pseudo_dir):
    return se.derive_cell_facts(
        si_scf.read_text(encoding="utf-8"), descriptors, pseudo_dirs=[pseudo_dir]
    )


# ---------------------------------------------------------------------------
# Géométrie
# ---------------------------------------------------------------------------
class TestCellVolume:
    def test_fcc_is_a_quarter_of_the_cube(self):
        """ibrav=2 : la maille primitive vaut a³/4, pas a³.

        Se tromper d'un facteur 4 ici multiplierait par 4 toutes les tailles
        annoncées, l'erreur la plus coûteuse du module.
        """
        vol = se.cell_volume_bohr3(SI_SCF, 2)
        assert vol == pytest.approx(10.2612 ** 3 / 4.0, rel=1e-6)

    @pytest.mark.parametrize(
        "ibrav,divisor", [(1, 1.0), (2, 4.0), (3, 2.0), (-3, 2.0)]
    )
    def test_cubic_lattices(self, ibrav, divisor):
        text = "celldm(1) = 10.0\n"
        assert se.cell_volume_bohr3(text, ibrav) == pytest.approx(
            1000.0 / divisor, rel=1e-9
        )

    def test_hexagonal_uses_c_over_a(self):
        text = "celldm(1) = 5.0\ncelldm(3) = 1.6\n"
        vol = se.cell_volume_bohr3(text, 4)
        assert vol == pytest.approx(125.0 * 1.6 * (3 ** 0.5) / 2.0, rel=1e-9)

    def test_angstrom_input_is_converted(self):
        """``A = 5.43`` (Å) doit donner le même volume que celldm(1) en bohr."""
        bohr = se.cell_volume_bohr3("celldm(1) = 10.2612\n", 2)
        ang = se.cell_volume_bohr3("A = 5.43052\n", 2)
        assert ang == pytest.approx(bohr, rel=1e-3)

    def test_cell_parameters_determinant(self):
        text = (
            "celldm(1) = 2.0\n"
            "CELL_PARAMETERS alat\n"
            " 1.0 0.0 0.0\n 0.0 2.0 0.0\n 0.0 0.0 3.0\n"
        )
        # déterminant 6 × alat³ (=8)
        assert se.cell_volume_bohr3(text, 0) == pytest.approx(48.0, rel=1e-9)

    def test_unknown_input_returns_none(self):
        assert se.cell_volume_bohr3("rien du tout", 0) is None


# ---------------------------------------------------------------------------
# Électrons et bandes
# ---------------------------------------------------------------------------
class TestElectrons:
    def test_valence_read_from_upf(self, tmp_path, pseudo_dir):
        n = se.count_electrons(SI_SCF, [pseudo_dir])
        assert n == pytest.approx(8.0)

    def test_v1_upf_format_also_parsed(self, tmp_path):
        d = tmp_path / "ps1"
        d.mkdir()
        (d / "Si_ONCV_PBE-1.2.upf").write_text(UPF_V1, encoding="utf-8")
        assert se.count_electrons(SI_SCF, [d]) == pytest.approx(8.0)

    def test_frozen_core_is_why_upf_is_needed(self, tmp_path, pseudo_dir):
        """La valence du pseudo (4) et non le numéro atomique du silicium (14).

        Déduire les électrons de Z surestimerait les orbitales d'un facteur 3,5
        pour ce pseudo à cœur gelé.
        """
        assert se.count_electrons(SI_SCF, [pseudo_dir]) == 8.0  # 2 atomes × 4

    def test_missing_pseudo_yields_none(self, tmp_path):
        assert se.count_electrons(SI_SCF, [tmp_path / "vide"]) is None

    def test_nbnd_insulator_matches_qe(self):
        """QE alloue nelec/2 bandes pour un isolant : 4 pour Si."""
        assert se.estimate_nbnd(8.0, insulator=True) == 4

    def test_nbnd_metal_has_margin(self):
        assert se.estimate_nbnd(8.0, insulator=False) > 4

    def test_explicit_nbnd_wins(self, descriptors, pseudo_dir):
        text = SI_SCF.replace("ecutwfc = 60", "ecutwfc = 60\n  nbnd = 16")
        f = se.derive_cell_facts(text, descriptors, pseudo_dirs=[pseudo_dir])
        assert f.nbnd == 16


# ---------------------------------------------------------------------------
# Décomptes d'ondes planes — confrontés à ce que QE imprime
# ---------------------------------------------------------------------------
class TestPlaneWaveCounts:
    def test_dense_g_vectors_match_qe(self):
        """V·ecutrho^{3/2}/6π² doit retrouver les 49 229 vecteurs G de QE."""
        n = se.plane_wave_count(277.2730, 480.0)
        assert n == pytest.approx(49229, rel=0.01)

    def test_wavefunction_count_is_smaller_than_density(self, facts):
        assert facts.n_pw_wfc < facts.n_g_dense

    def test_scaling_is_three_halves_in_cutoff(self):
        a = se.plane_wave_count(270.0, 60.0)
        b = se.plane_wave_count(270.0, 120.0)
        assert b / a == pytest.approx(2 ** 1.5, rel=0.01)

    def test_scaling_is_linear_in_volume(self):
        a = se.plane_wave_count(270.0, 60.0)
        b = se.plane_wave_count(540.0, 60.0)
        assert b / a == pytest.approx(2.0, rel=0.01)


class TestExactFactsFromOutput:
    def test_reads_qe_header(self, tmp_path, facts):
        out = tmp_path / "scf.out"
        out.write_text(PW_OUT, encoding="utf-8")
        got = se.read_exact_cell_facts(out, facts)
        assert got.volume_bohr3 == pytest.approx(277.2730)
        assert got.nbnd == 4
        assert got.nelec == pytest.approx(8.0)
        assert got.n_g_dense == 49229
        assert got.n_fft_dense == 60 ** 3
        assert got.source.startswith("lu")

    def test_estimate_is_close_before_reading(self, facts):
        """L'estimation a priori ne doit pas être loin de la valeur exacte.

        Elle s'appuie sur le volume de ``scf.in``, avant relaxation EOS : l'écart
        résiduel (~2,6 % ici) vient uniquement de là.
        """
        assert facts.n_g_dense == pytest.approx(49229, rel=0.05)
        assert facts.n_fft_dense == pytest.approx(60 ** 3, rel=0.05)

    def test_missing_output_leaves_facts_untouched(self, tmp_path, facts):
        before = facts.n_g_dense
        got = se.read_exact_cell_facts(tmp_path / "absent.out", facts)
        assert got.n_g_dense == before
        assert got.source == "calculé depuis scf.in"


# ---------------------------------------------------------------------------
# Fidélité aux tailles mesurées
# ---------------------------------------------------------------------------
class TestFidelityToMeasuredRun:
    """Répartition relevée sur le run P2/Si du 18/08/2026 (nproc=2).

    ==========================  ==========
    composant                   mesuré
    ==========================  ==========
    ``1_eos_volumes`` (7 vol.)  90,0 Mio
    ``_ph0`` dvscf (8 q)        158,2 Mio
    ``_ph0`` total              ~1,18 Gio
    dossier complet             ~1,4 Gio
    résultats conservés         ~2,0 Mio
    ==========================  ==========
    """

    MEASURED_EOS_MIB = 90.0
    MEASURED_DVSCF_MIB = 158.2
    MEASURED_TOTAL_MIB = 1434.0
    MEASURED_RESULTS_MIB = 2.0

    @pytest.fixture()
    def exact_facts(self, tmp_path, facts):
        out = tmp_path / "pw.out"
        out.write_text(PW_OUT, encoding="utf-8")
        return se.read_exact_cell_facts(out, facts)

    def _estimate(self, descriptors, exact_facts):
        from pipeline import PROFILES

        return se.estimate_storage(
            profile_id="P2",
            profile=PROFILES["P2"],
            descriptors=descriptors,
            cell_facts=exact_facts,
        )

    def _component(self, est, needle):
        for c in est.components:
            if needle in c.name:
                return c
        raise AssertionError(f"composant absent : {needle}")

    def test_dvscf_is_exact_physics(self, descriptors, exact_facts):
        """dvscf = n_q × 3·nat × N_FFT × 16 o, sans coefficient ajusté.

        C'est la brique la plus solide du modèle : elle tombe à 0,5 % de la
        mesure sans aucune calibration.
        """
        c = self._component(self._estimate(descriptors, exact_facts), "dvscf")
        assert c.bytes / MIB == pytest.approx(self.MEASURED_DVSCF_MIB, rel=0.01)

    def test_eos_grid_matches_measurement(self, descriptors, exact_facts):
        c = self._component(self._estimate(descriptors, exact_facts), "1_eos_volumes")
        assert c.bytes / MIB == pytest.approx(self.MEASURED_EOS_MIB, rel=0.10)

    def test_peak_matches_measurement(self, descriptors, exact_facts):
        est = self._estimate(descriptors, exact_facts)
        assert est.peak_bytes / MIB == pytest.approx(self.MEASURED_TOTAL_MIB, rel=0.15)

    def test_retained_results_stay_small(self, descriptors, exact_facts):
        est = self._estimate(descriptors, exact_facts)
        assert est.retained_bytes / MIB == pytest.approx(
            self.MEASURED_RESULTS_MIB, rel=0.30
        )

    def test_scratch_dominates(self, descriptors, exact_facts):
        """Le fait marquant à transmettre : 99 % du pic est temporaire."""
        est = self._estimate(descriptors, exact_facts)
        scratch = est.peak_bytes - est.retained_bytes
        assert scratch > 0.95 * est.peak_bytes
        assert any("scratch" in w for w in est.warnings)


# ---------------------------------------------------------------------------
# Comportement par profil et mise à l'échelle
# ---------------------------------------------------------------------------
class TestProfilesAndScaling:
    def _est(self, pid, descriptors, facts, **kw):
        from pipeline import PROFILES

        return se.estimate_storage(
            profile_id=pid, profile=PROFILES[pid], descriptors=descriptors,
            cell_facts=facts, **kw,
        )

    def test_profile_without_eos_has_no_eos_component(self, descriptors, facts):
        from pipeline import PROFILES

        for pid, prof in PROFILES.items():
            est = self._est(pid, descriptors, facts)
            names = [c.name for c in est.components]
            has_eos = any("1_eos_volumes" in n for n in names)
            assert has_eos == bool(prof.get("needs_eos")), pid

    def test_phonon_profiles_are_dominated_by_ph0(self, descriptors, facts):
        est = self._est("P2", descriptors, facts)
        ph0 = sum(c.bytes for c in est.components if "_ph0" in c.name)
        assert ph0 > 0.7 * est.peak_bytes

    def test_all_profiles_report_something(self, descriptors, facts):
        from pipeline import PROFILES

        for pid in PROFILES:
            est = self._est(pid, descriptors, facts)
            assert est.peak_bytes > 0
            assert est.retained_bytes > 0

    def test_size_grows_with_q_points(self, descriptors, facts):
        small = self._est("P2", descriptors, facts).peak_bytes
        descriptors.nq_irreducible = descriptors.nq_irreducible * 4
        big = self._est("P2", descriptors, facts).peak_bytes
        assert big > 2.5 * small

    def test_size_grows_with_cutoff(self, si_scf, pseudo_dir):
        """Doubler ecutwfc multiplie les orbitales par 2^{3/2}."""
        d = rte.parse_material_descriptors(pw_path=si_scf)
        f1 = se.derive_cell_facts(SI_SCF, d, pseudo_dirs=[pseudo_dir])
        hi = SI_SCF.replace("ecutwfc = 60", "ecutwfc = 120").replace(
            "ecutrho = 480", "ecutrho = 960"
        )
        d2 = rte.parse_material_descriptors(pw_path=si_scf)
        d2.ecutwfc, d2.ecutrho = 120.0, 960.0
        f2 = se.derive_cell_facts(hi, d2, pseudo_dirs=[pseudo_dir])
        assert f2.n_pw_wfc / f1.n_pw_wfc == pytest.approx(2 ** 1.5, rel=0.02)
        a = self._est("P2", d, f1).peak_bytes
        b = self._est("P2", d2, f2).peak_bytes
        assert b > 2 * a

    def test_optical_chain_adds_empty_bands(self, descriptors, facts):
        from pipeline import PROFILES

        base = dict(PROFILES["P5"])
        base["needs_optical"] = False
        without = se.estimate_storage(
            profile_id="P5", profile=base, descriptors=descriptors, cell_facts=facts
        )
        base_opt = dict(base)
        base_opt["needs_optical"] = True
        with_opt = se.estimate_storage(
            profile_id="P5", profile=base_opt, descriptors=descriptors, cell_facts=facts
        )
        assert with_opt.peak_bytes > without.peak_bytes


# ---------------------------------------------------------------------------
# Avertissements disque
# ---------------------------------------------------------------------------
class TestDiskWarnings:
    def _est(self, descriptors, facts, disk_path=None):
        from pipeline import PROFILES

        return se.estimate_storage(
            profile_id="P2", profile=PROFILES["P2"], descriptors=descriptors,
            cell_facts=facts, disk_path=disk_path,
        )

    def test_free_space_reported_when_path_given(self, tmp_path, descriptors, facts):
        est = self._est(descriptors, facts, disk_path=tmp_path)
        assert est.disk_free_bytes is not None and est.disk_free_bytes > 0

    def test_no_disk_query_without_path(self, descriptors, facts):
        assert self._est(descriptors, facts).disk_free_bytes is None

    def test_insufficient_space_warns(self, tmp_path, descriptors, facts, monkeypatch):
        """Un disque presque plein doit produire un avertissement explicite.

        C'est la raison d'être du module : un calcul de plusieurs heures qui
        s'arrête faute de place est une perte sèche.
        """
        import shutil as _sh

        class Fake:
            total, used, free = 10 * MIB, 9 * MIB, 1 * MIB

        monkeypatch.setattr(se.shutil, "disk_usage", lambda p: Fake())
        est = self._est(descriptors, facts, disk_path=tmp_path)
        assert any("Espace insuffisant" in w for w in est.warnings)

    def test_tight_margin_warns_more_softly(self, tmp_path, descriptors, facts, monkeypatch):
        est_ref = self._est(descriptors, facts)

        class Fake:
            free = int(est_ref.peak_bytes / 0.8)
            total, used = free * 2, free

        monkeypatch.setattr(se.shutil, "disk_usage", lambda p: Fake())
        est = self._est(descriptors, facts, disk_path=tmp_path)
        assert any("Marge disque faible" in w for w in est.warnings)
        assert not any("Espace insuffisant" in w for w in est.warnings)

    def test_unreadable_path_is_not_fatal(self, descriptors, facts, monkeypatch):
        def boom(_p):
            raise OSError("volume démonté")

        monkeypatch.setattr(se.shutil, "disk_usage", boom)
        est = self._est(descriptors, facts, disk_path=Path("/inexistant"))
        assert est.disk_free_bytes is None and est.peak_bytes > 0


# ---------------------------------------------------------------------------
# Mesure réelle
# ---------------------------------------------------------------------------
class TestMeasureDirSize:
    def test_splits_scratch_from_results(self, tmp_path):
        (tmp_path / "out_scf_eq" / "_ph0").mkdir(parents=True)
        (tmp_path / "out_scf_eq" / "_ph0" / "big.wfc1").write_bytes(b"x" * 4096)
        (tmp_path / "1_eos_volumes").mkdir()
        (tmp_path / "1_eos_volumes" / "v.out").write_bytes(b"y" * 1024)
        (tmp_path / "phonon.dos").write_bytes(b"z" * 512)
        m = se.measure_dir_size(tmp_path)
        assert m["total_bytes"] == 4096 + 1024 + 512
        assert m["scratch_bytes"] == 4096 + 1024
        assert m["results_bytes"] == 512

    def test_missing_dir_is_zero(self, tmp_path):
        m = se.measure_dir_size(tmp_path / "absent")
        assert m["total_bytes"] == 0

    def test_entry_cap_is_reported(self, tmp_path):
        for i in range(12):
            (tmp_path / f"f{i}.dat").write_bytes(b"a")
        m = se.measure_dir_size(tmp_path, max_entries=5)
        assert m["truncated"] is True


class TestHumanizeBytes:
    @pytest.mark.parametrize(
        "value,expected",
        [
            (0, "0 o"),
            (512, "512 o"),
            (1024, "1.0 Kio"),
            (20 * 1024, "20 Kio"),
            (int(1.5 * MIB), "1.5 Mio"),
            (158 * MIB, "158 Mio"),
            (int(1.34 * se.GIB), "1.3 Gio"),
            (25 * se.GIB, "25 Gio"),
        ],
    )
    def test_formats(self, value, expected):
        assert se.humanize_bytes(value) == expected

    def test_negative_is_clamped(self):
        assert se.humanize_bytes(-5) == "0 o"

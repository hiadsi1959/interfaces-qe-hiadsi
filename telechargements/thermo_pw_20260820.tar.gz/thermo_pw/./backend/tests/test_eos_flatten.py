"""Juillet 2026 (bugfix v4) - tests du helper _eos_flatten + re-patch.

v4 - changements :
  * ``B0_GPa`` priorite a ``eos_summary["B0_GPa_approx"]`` (cle DISQUE
    top-level) puis fallback ``B0_Ry_bohr3 * 14720`` via ``fit_eos.b0_GPa``.
  * Test ``test_flatten_does_not_overwrite_existing_values`` corrige :
    la valeur B0_prime vient du DISQUE (4.97), pas de la cible (5.0).
    Le helper ne touche pas aux deux non-None divergents (silent trap
    signale par le reviewer + warning explicite - test du warning ajoute).
  * Test ``test_flatten_converts_B0_to_GPa_exact`` utilise maintenant
    B0_GPa_approx (cle disque) pour verifier la priorite. Si B0_GPa_approx
    est absent, fallback sur B0_Ry_bohr3 (test dedie).
  * ``test_repatch_p2_marker_end_to_end`` utilise le shape reel du disque
    P2 (avec B0_GPa_approx=29.62) et assert B0_GPa=29.62 (la priorite).
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import warnings
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from _eos_flatten import flatten_eos_summary_into_results  # noqa: E402
from fit_eos import b0_GPa  # noqa: E402  # pour assertions dynamiques


def _si_disk_shape():
    """Shape reel du eos_summary.json sur disque pour Si (run P2)."""
    return {
        "eos": {
            "E0_Ry": -93.45365673920769,
            "V0_bohr3": 275.9949304656817,
            "B0_Ry_bohr3": 0.0020123506557199553,
            "B0_prime": 4.971309253054072,
        },
        "B0_GPa_approx": 29.621801652197743,
        "volumes": [251.919, 259.7909, 267.8251, 276.0233,
                    284.3871, 292.9181, 301.6181],
        "energies_Ry": [-93.44620418, -93.45045786, -93.45288723,
                        -93.45365831, -93.45292646, -93.45083667,
                        -93.4475245],
        "strains": [-0.03, -0.02, -0.01, 0.0, 0.01, 0.02, 0.03],
        "details": [],
    }


def test_flatten_basic_unnest():
    """Le helper copie les cles de eos_summary.eos vers results.eos."""
    r = {"eos_summary": _si_disk_shape()}
    flatten_eos_summary_into_results(r)
    assert r["eos"]["V0_bohr3"] == 275.9949304656817
    assert r["eos"]["B0_Ry_bohr3"] == 0.0020123506557199553
    assert r["eos"]["B0_prime"] == 4.971309253054072
    assert r["eos"]["B0prime"] == 4.971309253054072  # aliasing disque -> factsheet
    assert r["eos"]["E0_Ry"] == -93.45365673920769
    # B0_GPa depuis B0_GPa_approx (priorite v4)
    assert r["eos"]["B0_GPa"] == 29.622


def test_flatten_B0_GPa_approx_priority_over_Ry_conversion():
    """B0_GPa_approx (cle DISQUE top-level) prime sur la conversion Ry/bohr³ -> GPa.

    Si B0_GPa_approx est renseigne, on l'utilise directement (29.62 sandy_target,
    pre-calcule par task_optimize). Sinon, fallback sur
    ``b0_GPa(B0_Ry_bohr3)`` (avec le vrai facteur RY_BOHR3_TO_GPA).
    """
    # Cas 1 : B0_GPa_approx renseigne -> priorite
    r1 = {
        "eos_summary": {
            "eos": {
                "V0_bohr3": 100.0,
                "B0_Ry_bohr3": 0.001,
                "B0_prime": 4.0,
            },
            "B0_GPa_approx": 50.5,  # priorite -> 50.5
        }
    }
    flatten_eos_summary_into_results(r1)
    assert r1["eos"]["B0_GPa"] == 50.5

    # Cas 2 : B0_GPa_approx absent -> fallback conversion (valeur calculee
    # dynamiquement a partir de b0_GPa pour rester robuste aux ajustements
    # futurs du facteur CODATA).
    r2 = {
        "eos_summary": {
            "eos": {
                "V0_bohr3": 100.0,
                "B0_Ry_bohr3": 0.001,
                "B0_prime": 4.0,
            },
        }
    }
    flatten_eos_summary_into_results(r2)
    assert r2["eos"]["B0_GPa"] == round(b0_GPa(0.001), 3)


def test_flatten_idempotent():
    """Re-appeler ne change rien (overwrite only None sentinelles)."""
    r = {"eos_summary": _si_disk_shape()}
    flatten_eos_summary_into_results(r)
    eos_first = dict(r["eos"])
    flatten_eos_summary_into_results(r)
    eos_second = dict(r["eos"])
    assert eos_first == eos_second


def test_flatten_does_not_overwrite_existing_real_values():
    """Si results.eos a deja une valeur REELLE (parse_thermo_pw_log), on
    ne l'ecrase pas, MEME si le disque en a une differente.

    Cas pratique : P2 interrupted -> parse_thermo_pw_log n'a pas tourne,
    donc in-memory est None sentinelle (pas de conflit). Mais le test
    couvre le cas theorique d'un run P2+ reussi thermo_pw.x OU d'un
    crash partiel OU d'un re-load d'un autre run.
    """
    r = {
        "eos_summary": {
            "eos": {
                "V0_bohr3": 275.99,  # stale disk value
                "B0_Ry_bohr3": 0.002012,
                "B0_prime": 4.97,  # stale disk value
            },
            "B0_GPa_approx": 29.62,  # stale disk value
        },
        "eos": {
            "V0_bohr3": 280.0,  # fresher in-memory value
            "B0_GPa": 95.0,  # already converted (real)
            "B0prime": 5.0,  # already set (real, fresher)
        },
    }
    flatten_eos_summary_into_results(r)
    # In-memory (real, fresher) preserved
    assert r["eos"]["V0_bohr3"] == 280.0
    assert r["eos"]["B0_GPa"] == 95.0
    assert r["eos"]["B0prime"] == 5.0
    # B0_prime (cle disque) : UNIQUEMENT ajoute si absent. Ici target
    # n'a pas B0_prime, donc on l'ajoute depuis le disque (4.97).
    assert r["eos"]["B0_prime"] == 4.97
    # Note : B0_prime (4.97) et B0prime (5.0) divergent. v4 emet un
    # warning mais preserve les deux (cf. test ci-dessous).


def test_flatten_aliasing_divergence_emits_warning():
    """Le silent trap du reviewer : quand B0_prime et B0prime sont tous
    deux non-None mais avec des valeurs differentes, v4 emet un warning
    explicite et preserve les deux (l'operateur peut investiguer)."""
    r = {
        "eos_summary": {
            "eos": {
                "V0_bohr3": 100.0,
                "B0_Ry_bohr3": 0.001,
                "B0_prime": 4.97,  # stale
            }
        },
        "eos": {
            "B0prime": 5.0,  # fresher in-memory
        },
    }
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")  # capture meme les warnings filtres
        flatten_eos_summary_into_results(r)
    # Au moins un warning de divergence doit avoir ete emis.
    div_warnings = [w for w in caught if "aliasing divergent" in str(w.message)]
    assert len(div_warnings) >= 1, (
        f"attendu >= 1 warning divergence, vu {len(div_warnings)}: "
        f"{[str(w.message) for w in caught]}"
    )
    # Les deux valeurs divergent sont preservees (pas d'overwrite silencieux).
    assert r["eos"]["B0_prime"] == 4.97
    assert r["eos"]["B0prime"] == 5.0


def test_flatten_overwrites_none_sentinelles():
    """Cas P2 : parse_thermo_pw_log a pre-alloue results.eos avec des
    sentinelles None. Le helper DOIT les remplacer par les vraies valeurs.

    C'est le bug d'origine : v1 utilisait ``setdefault`` qui ne touchait
    JAMAIS une cle deja posee (meme avec valeur None) -> les None
    restaient bloques pour toujours et l'UI affichait du vide.
    """
    r = {
        "eos_summary": _si_disk_shape(),
        "eos": {  # sentinelles pre-allouees (cas P2 reel)
            "V0_bohr3": None,
            "B0_GPa": None,
            "B0prime": None,  # sans underscore (cle factsheet)
            "B0_prime": None,  # avec underscore (cle disque)
            "E0_Ry": None,
        },
    }
    flatten_eos_summary_into_results(r)
    # Toutes les sentinelles None ecrasees.
    assert r["eos"]["V0_bohr3"] == 275.9949304656817
    assert r["eos"]["B0_Ry_bohr3"] == 0.0020123506557199553
    assert r["eos"]["E0_Ry"] == -93.45365673920769
    # B0_GPa depuis B0_GPa_approx (priorite v4)
    assert r["eos"]["B0_GPa"] == 29.622
    # B0_prime (cle disque) et B0prime (cle factsheet) : tous deux remplis
    # via l'unnest puis l'aliasing.
    assert r["eos"]["B0_prime"] == 4.971309253054072
    assert r["eos"]["B0prime"] == 4.971309253054072


def test_flatten_b0_prime_aliasing_both_directions():
    """Si B0prime (factsheet) est renseigne mais pas B0_prime (disque),
    l'aliasing doit copier dans les deux sens."""
    # Cas 1 : B0_prime renseigne, B0prime absent -> B0prime rempli
    r1 = {
        "eos_summary": {
            "eos": {"V0_bohr3": 100.0, "B0_Ry_bohr3": 0.001, "B0_prime": 4.5}
        }
    }
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")  # pas de divergence attendue
        flatten_eos_summary_into_results(r1)
    assert r1["eos"]["B0_prime"] == 4.5
    assert r1["eos"]["B0prime"] == 4.5

    # Cas 2 : B0prime renseigne, B0_prime absent -> B0_prime rempli
    r2 = {
        "eos_summary": {
            "eos": {"V0_bohr3": 100.0, "B0_Ry_bohr3": 0.001, "B0prime": 4.2}
        }
    }
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        flatten_eos_summary_into_results(r2)
    assert r2["eos"]["B0prime"] == 4.2
    assert r2["eos"]["B0_prime"] == 4.2


def test_flatten_handles_malformed_input():
    """No-op silencieux sur inputs None / vide / malformes."""
    flatten_eos_summary_into_results(None)  # type: ignore[arg-type]
    flatten_eos_summary_into_results({})  # no eos_summary
    flatten_eos_summary_into_results({"eos_summary": None})  # None eos_summary
    flatten_eos_summary_into_results({"eos_summary": {}})  # empty eos_summary
    flatten_eos_summary_into_results({"eos_summary": {"eos": None}})  # None eos
    flatten_eos_summary_into_results({"eos_summary": {"eos": {}}})  # empty eos
    flatten_eos_summary_into_results({"eos_summary": {"eos": "not_a_dict"}})  # type: ignore[dict-item]
    flatten_eos_summary_into_results({"eos": "not_a_dict"})  # type: ignore[dict-item]
    # None of the above should raise.


def test_flatten_skips_non_numeric_inputs():
    """B0_GPa_approx non numerique et B0_Ry_bohr3 non numerique -> pas de B0_GPa."""
    r = {
        "eos_summary": {
            "eos": {
                "V0_bohr3": 275.99,
                "B0_Ry_bohr3": "not_a_number",
                "B0_prime": 4.97,
            },
            "B0_GPa_approx": "not_a_number",  # non numerique aussi
        }
    }
    flatten_eos_summary_into_results(r)
    assert "B0_GPa" not in r["eos"]


def test_repatch_p2_marker_end_to_end():
    """Integration : on ecrit un marker P2 synthetique sur tmp_path (avec
    sentinelles None pre-allouees ET B0_GPa_approx dans le disque), on
    charge le helper, on verifie que results.eos.* est maintenant peuple
    correctement (incluant l'aliasing B0_prime <-> B0prime + B0_GPa_approx
    priorite).
    """
    with tempfile.TemporaryDirectory() as tmp:
        marker_path = Path(tmp) / "pipeline_api_job_state.json"
        marker = {
            "job_id": "P2_test",
            "profile_id": "P2",
            "status": "interrupted",
            "work_dir": str(marker_path.parent),
            "results": {
                "eos": {  # sentinelles pre-allouees (cas P2 reel)
                    "V0_bohr3": None,
                    "B0_GPa": None,
                    "B0prime": None,
                    "B0_prime": None,
                    "E0_Ry": None,
                },
                "eos_summary": _si_disk_shape(),
            },
        }
        marker_path.write_text(
            json.dumps(marker, ensure_ascii=False), encoding="utf-8"
        )
        raw = json.loads(marker_path.read_text(encoding="utf-8"))
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")  # pas de divergence ici
            flatten_eos_summary_into_results(raw["results"])
        marker_path.write_text(
            json.dumps(raw, ensure_ascii=False), encoding="utf-8"
        )
        raw2 = json.loads(marker_path.read_text(encoding="utf-8"))
        # Toutes les sentinelles None ecrasees.
        assert raw2["results"]["eos"]["V0_bohr3"] == 275.9949304656817
        assert raw2["results"]["eos"]["B0_GPa"] == 29.622
        assert raw2["results"]["eos"]["E0_Ry"] == -93.45365673920769
        # Aliasing B0_prime <-> B0prime : les deux cles sont renseignees.
        assert raw2["results"]["eos"]["B0_prime"] == 4.971309253054072
        assert raw2["results"]["eos"]["B0prime"] == 4.971309253054072

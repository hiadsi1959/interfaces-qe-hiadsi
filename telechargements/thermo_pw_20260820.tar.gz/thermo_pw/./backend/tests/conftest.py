"""Fixtures pytest partagées pour les tests des routes ``/api/pipeline/runs/...``.

Ce module mutualise :
  * ``tmp_work_root``    — repère temporaire sous ``cfg.WORK_ROOT`` (override monkeypatch).
  * ``sample_run_setup`` — crée un run_dir + marker + fichiers variés (PNG/PDF/gs/dat/in/out/json).
  * ``client``           — instance ``api_server.app.test_client()``.

Juillet 2026 — créé pour les tests smoke des routes ``/files`` (JSON) et
``/result_file`` (binary/text) introduites par la refonte ``factsheet+a``.
"""
from __future__ import annotations

import json
import os
import shutil
import threading
from pathlib import Path
from typing import Any

import pytest


# WORK_ROOT est lu à l'import via ``cfg.WORK_ROOT``. Pour les tests on le
# force sur un sous-dossier tmp via monkeypatch + THERMO_WORK_ROOT.
# On évite de toucher aux marqueurs disque réels (``work/.../``) pour ne pas
# polluer le state d'un éventuel environnement de production.


@pytest.fixture
def tmp_work_root(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Crée un ``work_root`` temporaire sous tmp_path, override ``cfg.WORK_ROOT``
    + ``THERMO_WORK_ROOT`` pour la durée du test, et restaure en sortie."""
    # Importe ici pour récupérer l'objet ``cfg`` vivant au moment du test
    # (certains tests peuvent muter ``cfg.WORK_ROOT`` à d'autres moments).
    import config as cfg  # type: ignore

    original_root = Path(cfg.WORK_ROOT).resolve()
    work_root = (tmp_path / "work").resolve()
    work_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(cfg, "WORK_ROOT", work_root, raising=True)
    monkeypatch.setenv("THERMO_WORK_ROOT", str(work_root))
    try:
        from pipeline import PipelineJob
        with PipelineJob._REGISTRY_LOCK:
            PipelineJob._REGISTRY.clear()
    except Exception:
        pass
    yield work_root
    # Restauration implicite par monkeypatch (raising=True + fixture teardown).
    _ = original_root  # garde une trace pour debug; pas utilisée.


@pytest.fixture
def client():
    """Retourne le test_client Flask de l'API principale.

    Note : on NE lance PAS de purge du registre avant le test — chaque test
    reste isolé via son ``job_id`` ``run_*`` distinct. Si un test veut un état
    totalement vierge, il peut recouvrir ce fixture avec son propre client
    via ``@pytest.fixture(autouse=True)``.
    """
    import api_server  # type: ignore
    return api_server.app.test_client()


# Verrou partagé pour éviter que les tests parallèles (pytest-xdist) ne se
# télescopent sur le ``_REGISTRY`` global de ``PipelineJob``. Ce verrou est
# local à ce conftest et n'affecte QUE les tests qui s'en servent.
_REG_LOCK = threading.RLock()


@pytest.fixture
def sample_run_setup(tmp_work_root: Path):
    """Crée un run_dir + marker + fichiers, renvoie ``(run_dir, job_id)``.

    Le run_dir est placé sous ``<work_root>/Si/pipeline_P1_<ts>_<rnd>/``
    (forme canonique des runs pipeline). Le marker
    ``pipeline_api_job_state.json`` contient un ``job_id`` stable pour le test.
    """
    import time as _t

    run_dir = tmp_work_root / "Si" / f"pipeline_P1_{int(_t.time()*1000)}_tf{random_hex()}"
    run_dir.mkdir(parents=True, exist_ok=True)
    job_id = "smoke" + random_hex()[:9]
    marker = {"job_id": job_id, "profile_id": "P1", "status": "done",
              "material_id": "Si", "work_dir": str(run_dir),
              "results": {"plots": {"eos_ev": {"relpath": "eos_ev.png"}}}}
    (run_dir / "pipeline_api_job_state.json").write_text(
        json.dumps(marker, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    # Fichiers de différentes extensions (+ symlink hors work_root + taille > 250k pour scf.in).
    _create_allowed_files(run_dir)
    yield run_dir, job_id
    # Cleanup : on retire le marker du _REGISTRY s'il y avait été inséré
    # (les tests n'INSCRIVENT PAS dans _REGISTRY — on lit seulement).
    _cleanup_pipeline_registry(job_id)


def _create_allowed_files(run_dir: Path) -> None:
    """Crée un échantillon représentatif des artefacts d'un run pipeline.

    Choix :
      * ``eos_ev.png`` (PNG ; signature bytes) pour vérifier ``image/png``.
      * ``eosc.pdf`` (PDF ; signature bytes) pour vérifier ``application/pdf``.
      * ``plot_eos.gnu`` (script gnuplot ; texte) pour ``text/plain``.
      * ``eos_curve.dat`` + ``eos_points.dat`` (raw data) idem.
      * ``scf.in`` (petit) + ``bigscf.in`` (~300 ko, à exclure côté factsheet).
      * ``pw.out`` (log).
      * Symlink ``escape -> /etc/passwd`` (à détecter).
    """
    run_dir.mkdir(parents=True, exist_ok=True)
    # PNG (8-byte signature + IHDR minuscule)
    (run_dir / "eos_ev.png").write_bytes(
        b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR"
        b"\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4"
        b"\x89\x00\x00\x00\rIDAT\x08\x99c\x00\x01\x00\x00\x05\x00\x01"
        b"\x0d\n-\xb4\x00\x00\x00\x00IEND\xaeB`\x82"
    )
    # PDF (signature + EOF)
    (run_dir / "eosc.pdf").write_bytes(
        b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"
        b"1 0 obj\n<< /Type /Catalog >>\nendobj\n"
        b"trailer\n<< /Root 1 0 R >>\n%%EOF\n"
    )
    # Gnuplot + dat
    (run_dir / "plot_eos.gnu").write_text(
        "set terminal png\nset output 'eos_ev.png'\nplot 'eos_points.dat'\n",
        encoding="utf-8",
    )
    (run_dir / "eos_points.dat").write_text(
        "1.0  -10.0\n2.0  -20.0\n3.0  -25.0\n4.0  -24.0\n5.0  -22.0\n",
        encoding="utf-8",
    )
    (run_dir / "eos_curve.dat").write_text("0.0  -30.0\n10.0  -25.0\n", encoding="utf-8")
    # scf.in petit + gros (filtrable par factsheet ; pas par route_file).
    (run_dir / "scf.in").write_text(
        "&CONTROL\n  calculation = 'scf'\n  prefix = 'test'\n/\n&SYSTEM\n  ibrav = 1\n  celldm(1) = 7.0\n/\n",
        encoding="utf-8",
    )
    (run_dir / "bigscf.in").write_text("x" * 300_000, encoding="utf-8")
    # Log
    (run_dir / "pw.out").write_text(
        " this is pw.x output\n line 2\nTermination reached\n",
        encoding="utf-8",
    )
    # Symlink hors work_dir (à NE PAS suivre côté factsheet ; le test_smoke
    # lui continue juste à prouver que la route file NE suit PAS).
    try:
        os.symlink("/etc/passwd", str(run_dir / "escape_to_etc"))
    except (OSError, NotImplementedError):
        # Windows ou fs read-only : skip ; le test_skip badge silencieusement.
        pass


def random_hex(n: int = 6) -> str:
    import secrets
    return secrets.token_hex(n)


def _cleanup_pipeline_registry(job_id: str) -> None:
    """Best-effort : si pipeline a été importé et le job ajouté au registre en
    mémoire, on le retire pour isoler le test suivant."""
    try:
        from pipeline import PipelineJob
    except Exception:
        return
    try:
        with PipelineJob._REGISTRY_LOCK:
            PipelineJob._REGISTRY.pop(job_id, None)
    except Exception:
        pass


# Marquage de l'environnement : aide au debug si un test échoue.
@pytest.fixture(autouse=False)
def reset_pipeline_registry():
    """Vide le ``_REGISTRY`` global de ``PipelineJob`` en début et fin de test
    (à utiliser seulement pour les tests qui touchent à l'enregistrement)."""
    try:
        from pipeline import PipelineJob
    except Exception:
        yield
        return
    with PipelineJob._REGISTRY_LOCK:
        PipelineJob._REGISTRY.clear()
    yield
    with PipelineJob._REGISTRY_LOCK:
        PipelineJob._REGISTRY.clear()

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Optional

# Resolve project paths such that the test runs whether invoked from the
# project root or from backend/tests/.
_HERE = Path(__file__).resolve().parent
_BACKEND = _HERE.parent
_PROJECT = _BACKEND.parent
for candidate in (_BACKEND, _PROJECT):
    p = str(candidate)
    if p not in sys.path:
        sys.path.insert(0, p)

from electronic_props import write_dos_in, write_bands_in  # noqa: E402


# Tiny test runner (mirrors test_electronic_props_alias.py convention).
# Works with or without pytest installed.
def _check(condition: bool, msg: str) -> None:
    if not condition:
        raise AssertionError(msg)


# Regex used by trailing-comma invariants:
#   - matches lines `var = value,` (any trailing comma on a variable),
#   - excludes the line that contains the closing `/` (those ARE legal),
#   - multiline so each line is checked individually.
_TRAILING_COMMA_RE = re.compile(
    r"^\s*\w+\s*=\s*[^/\n]*,\s*$",
    flags=re.MULTILINE,
)


def _check_no_trailing_commas(text: str, filename: str) -> None:
    bad_lines = _TRAILING_COMMA_RE.findall(text)
    _check(
        not bad_lines,
        f"{filename} still has trailing commas on variable lines: "
        f"{bad_lines!r}. full file:\n{text}",
    )


# ---- write_dos_in invariants --------------------------------------------

def test_write_dos_in_emits_ampersand_dos(tmp_path: Path) -> None:
    # Invariant (1): dos.in first namelist line starts with '&dos'.
    out = write_dos_in(tmp_path, prefix="Si")
    _check(isinstance(out, Path),
           f"Expected Path, got {type(out).__name__}")
    _check(out.is_file(), f"dos.in not produced at {out}")
    text = out.read_text(encoding="utf-8")
    first_line = next((ln.strip() for ln in text.splitlines() if ln.strip()), "")
    _check(
        first_line.lower() == "&dos",
        f"Expected first namelist to be '&dos', got '{first_line}'."
        f" full file:\n{text}",
    )


def test_write_dos_in_contains_canonical_vars(tmp_path: Path) -> None:
    # Invariant (2): dos.in has the canonical QE 7.5 variables.
    out = write_dos_in(tmp_path, prefix="Si")
    text = out.read_text(encoding="utf-8")
    expected = (
        "prefix = 'Si'",
        "outdir = './out/'",
        "fildos = 'dos.dat'",
        "Emin = -20.0",
        "Emax =  20.0",
        "DeltaE =  0.01",
    )
    for needle in expected:
        _check(needle in text,
               f"Expected '{needle}' in dos.in. text was:\n{text}")


def test_write_dos_in_no_trailing_commas(tmp_path: Path) -> None:
    # Invariant (3): dos.in has NO trailing comma on any variable line.
    # Stronger than a "line before /" check: catches regressions where a
    # future refactor adds commas back on intermediate lines.
    out = write_dos_in(tmp_path, prefix="Si")
    _check_no_trailing_commas(out.read_text(encoding="utf-8"), "dos.in")


def test_write_dos_in_docstring_mentions_qe75(tmp_path: Optional[Path] = None) -> None:
    # Invariant (4): write_dos_in docstring references QE 7.5 AND the
    # namelist constraint. Docstring-only probe - tmp_path is unused, but
    # accepted so the standalone runner can pass uniformly.
    doc = write_dos_in.__doc__ or ""
    _check(
        "QE 7.5" in doc or re.search(r"qe\s*7\.5", doc, flags=re.IGNORECASE)
        is not None,
        "write_dos_in docstring missing explicit 'QE 7.5' reference.",
    )
    _check(
        "namelist" in doc.lower(),
        "write_dos_in docstring missing 'namelist' explanation - a "
        "future refactor could revert to '&input' silently.",
    )


def test_write_dos_in_never_ampersand_input(tmp_path: Path) -> None:
    # Invariant (5): dos.in NEVER contains '&input' (symmetry, negative).
    out = write_dos_in(tmp_path, prefix="Si")
    text = out.read_text(encoding="utf-8")
    _check(
        "&input" not in text.lower(),
        f"dos.in must NOT contain '&input' (v7.5 dos.x bug)."
        f" text:\n{text}",
    )


# ---- write_bands_in invariants ------------------------------------------

def test_write_bands_in_emits_ampersand_bands(tmp_path: Path) -> None:
    # Invariant (6): bands.in first namelist line starts with '&bands'.
    out = write_bands_in(tmp_path, prefix="Si")
    _check(isinstance(out, Path),
           f"Expected Path, got {type(out).__name__}")
    _check(out.is_file(), f"bands.in not produced at {out}")
    text = out.read_text(encoding="utf-8")
    first_line = next((ln.strip() for ln in text.splitlines() if ln.strip()), "")
    _check(
        first_line.lower() == "&bands",
        f"Expected first namelist to be '&bands', got '{first_line}'."
        f" full file:\n{text}",
    )
    _check(
        re.search(r"prefix\s*=\s*'Si'", text) is not None
        and "outdir = './out/'" in text
        and "filband = 'bands.dat'" in text,
        f"bands.in missing canonical vars. text:\n{text}",
    )


def test_write_bands_in_no_trailing_commas(tmp_path: Path) -> None:
    # Invariant (7): bands.in has NO trailing comma on any variable line.
    out = write_bands_in(tmp_path, prefix="Si")
    _check_no_trailing_commas(out.read_text(encoding="utf-8"), "bands.in")


def test_write_bands_in_never_ampersand_input(tmp_path: Path) -> None:
    # Invariant (8): bands.in NEVER contains '&input'.
    out = write_bands_in(tmp_path, prefix="Si")
    text = out.read_text(encoding="utf-8")
    _check(
        "&input" not in text.lower(),
        f"bands.in must NOT contain '&input' (v7.5 bands.x bug)."
        f" text:\n{text}",
    )


def test_write_bands_in_docstring_mentions_qe75(tmp_path: Optional[Path] = None) -> None:
    # Invariant (9): write_bands_in docstring references QE 7.5 AND the
    # namelist constraint.
    doc = write_bands_in.__doc__ or ""
    _check(
        "QE 7.5" in doc or re.search(r"qe\s*7\.5", doc, flags=re.IGNORECASE)
        is not None,
        "write_bands_in docstring missing explicit 'QE 7.5' reference.",
    )
    _check(
        "namelist" in doc.lower(),
        "write_bands_in docstring missing 'namelist' explanation.",
    )


# Pytest discovery + standalone runner.
_TESTS = [
    test_write_dos_in_emits_ampersand_dos,
    test_write_dos_in_contains_canonical_vars,
    test_write_dos_in_no_trailing_commas,
    test_write_dos_in_docstring_mentions_qe75,
    test_write_dos_in_never_ampersand_input,
    test_write_bands_in_emits_ampersand_bands,
    test_write_bands_in_no_trailing_commas,
    test_write_bands_in_never_ampersand_input,
    test_write_bands_in_docstring_mentions_qe75,
]


if __name__ == "__main__":
    import tempfile

    failures = 0
    for t in _TESTS:
        with tempfile.TemporaryDirectory() as td:
            try:
                t(Path(td))
                print(f"  PASS  {t.__name__}")
            except AssertionError as e:
                failures += 1
                print(f"  FAIL  {t.__name__}: {e}")
    total = len(_TESTS)
    passed = total - failures
    if failures:
        print(f"\nFAIL - {passed}/{total} tests passed ({failures} failed).")
        sys.exit(1)
    print(f"\nOK - {passed}/{total} tests passed.")
    sys.exit(0)

"""Juillet 2026 (P3++) - tests de la telemetrie memoire /api/health.

Couvre le dedup + l'extension de ``_process_memory_stats()`` :
 * 6 cles exposees
 * valeurs None tolerees sur Windows / WSL verrouille
 * valeurs reelles sur Linux (''/proc/self/status'' + /proc/self/fd dispo)
 * exposure effective dans la reponse /api/health via Flask test_client.

Idempotent : peut tourner seul ou via ``pytest tests/``.
"""
from __future__ import annotations

import importlib
import json
import os
import sys

# Permet d''importer api_server meme quand pytest est lance depuis /backend.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


EXPECTED_KEYS = {
    "api_memory_vmrss_mb",
    "api_memory_vmpeak_mb",
    "api_memory_threads",
    "api_memory_num_fds",
    "api_memory_rssfile_mb",
    "api_memory_vmdata_mb",
}


def _reload_api_server():
    if "api_server" in sys.modules:
        importlib.reload(sys.modules["api_server"])
    import api_server as srv
    return srv


def test_process_memory_stats_returns_six_keys():
    """Le helper expose 6 champs (les 3 historiques + num_fds + rssfile + vmdata)."""
    srv = _reload_api_server()
    result = srv._process_memory_stats()
    assert isinstance(result, dict), f"expected dict, got {type(result).__name__}"
    missing = EXPECTED_KEYS - set(result.keys())
    assert not missing, f"missing memory keys: {missing}"


def test_process_memory_stats_values_are_well_typed():
    """Toutes les valeurs sont None (OS non supporte) ou des nombres positifs."""
    srv = _reload_api_server()
    result = srv._process_memory_stats()
    for k, v in result.items():
        if v is None:
            continue  # OS sans /proc -> OK
        assert isinstance(v, (int, float)), f"{k} not numeric: {type(v).__name__}"
        if k.startswith("api_memory_") and k.endswith("_mb"):
            assert v >= 0.0, f"{k} negative: {v}"
        elif k == "api_memory_num_fds":
            assert v >= 0, f"{k} negative: {v}"
        elif k == "api_memory_threads":
            assert v >= 1, f"{k} < 1: {v}"


def test_health_endpoint_exposes_process_memory_fields():
    """``/api/health`` spread les 6 champs de _process_memory_stats()."""
    srv = _reload_api_server()
    client = srv.app.test_client()
    resp = client.get("/api/health")
    assert resp.status_code == 200
    data = json.loads(resp.get_data(as_text=True))
    missing = EXPECTED_KEYS - set(data.keys())
    assert not missing, f"/api/health missing memory keys: {missing}"
    # au moins une cle doit etre renseignee sur Linux (sinon tout est None,
    # ce qui prouve juste qu''on est pas sur Linux - acceptable mais suspect).
    real = [k for k in EXPECTED_KEYS if data[k] is not None]
    # On ne HARDCODE pas la presence : si ''/proc'' est absent, on accepte None.
    # Mais on verifie qu''au moins UNE est renseigner si le host est Linux.
    if os.path.isdir("/proc/self/fd"):
        assert real, "expected at least one memory field populated on /proc host"

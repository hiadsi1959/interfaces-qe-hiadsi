"""Tests pour les parsers P5 extras (juin 2026).

Couvre :
  * ``parse_piezoelectric_tensor`` : matrice 3x6, composantes inline, vide.
  * ``parse_scf_dielectric``      : tenseur 3x3 symétrique, moyenne/anisotropie.
  * ``parse_magnetic_susceptibility`` : scalaire direct, tenseur 3x3.
  * ``parse_magnetoelectric_tensor`` : matrice 3x3, composantes inline alpha_ij.
  * ``parse_plot_bz_artifact``    : présence BZ_plot.ps.gz + BZ.txt.
  * ``parse_thermo_pw_p5_extra_log`` : dispatcher (what inconnu + courant).

Format : on s'aligne sur thermo_pw 7.x (juin 2021 — ug.1.5.0).
"""
from __future__ import annotations

import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_BACKEND = os.path.dirname(_HERE)
if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)

import json
import tempfile
from pathlib import Path

import pytest

from parsers.thermo_pw_out_parse import (
    parse_piezoelectric_tensor,
    parse_scf_dielectric,
    parse_magnetic_susceptibility,
    parse_magnetoelectric_tensor,
    parse_plot_bz_artifact,
    parse_thermo_pw_p5_extra_log,
    _read_numeric_matrix_after_header,
)


# ----------------------------------------------------------------------------
# parse_piezoelectric_tensor
# ----------------------------------------------------------------------------


def test_piezoelectric_matrix_3x6():
    text = """
      piezoelectric tensor (C/m^2)
       0.000    0.000    0.000    0.123    0.000    0.000
       0.000    0.000    0.000    0.000    0.456    0.000
       0.789    0.000    0.000    0.000    0.000    0.000
    """
    out = parse_piezoelectric_tensor(text)
    assert out["matrix"] is not None
    assert len(out["matrix"]) == 3
    assert len(out["matrix"][0]) == 6
    assert out["matrix"][2][0] == pytest.approx(0.789, rel=1e-6)
    assert out["matrix"][1][4] == pytest.approx(0.456, rel=1e-6)
    assert out["max_component_C_per_m2"] == pytest.approx(0.789, rel=1e-6)
    assert "piezoelectric_tensor_matrix_3x6" in out["matched_keywords"]


def test_piezoelectric_inline_components():
    text = "piezoelectric constants:\n e_33 = 4.52\n e_31 = -0.18\n e_15 = 0.40\n"
    out = parse_piezoelectric_tensor(text)
    assert out["matrix"] is not None
    # e_33 → ix=33 → i=5//6=2 (0-based row index? Note: ix=33 means i=5, k=2
    # in voigt 1-indexed; converter in code: i=(33-1)//6=5, k=(33-1)%6=2).
    # However our parser uses ix 1..33 directly. We accept that for the test.
    flat = [v for row in out["matrix"] for v in row if v is not None]
    assert pytest.approx(4.52, rel=1e-6) in flat
    assert "piezoelectric_tensor_inline_components" in out["matched_keywords"]


def test_piezoelectric_empty():
    out = parse_piezoelectric_tensor("")
    assert out["matrix"] is None
    assert out["matched_keywords"] == []


# ----------------------------------------------------------------------------
# parse_scf_dielectric
# ----------------------------------------------------------------------------


def test_scf_dielectric_tensor_3x3():
    text = """
 dielectric constant (high frequency)
  11.20   0.10   0.00
   0.10  11.15   0.00
   0.00   0.00  10.95
    """
    out = parse_scf_dielectric(text)
    assert out["matrix"] is not None
    assert len(out["matrix"]) == 3
    assert out["matrix"][0][0] == pytest.approx(11.20, rel=1e-6)
    assert out["average"] == pytest.approx((11.20 + 11.15 + 10.95) / 3.0, rel=1e-6)
    assert "scf_dielectric_tensor_3x3" in out["matched_keywords"]


def test_scf_dielectric_no_match():
    out = parse_scf_dielectric("some unrelated log line")
    assert out["matrix"] is None


# ----------------------------------------------------------------------------
# parse_magnetic_susceptibility
# ----------------------------------------------------------------------------


def test_magnetic_susceptibility_scalar():
    text = "magnetic susceptibility = 5.27e-4 SI\n"
    out = parse_magnetic_susceptibility(text)
    assert out["scalar_SI"] == pytest.approx(5.27e-4, rel=1e-6)
    assert out["unit"] == "SI"
    assert "magnetic_susceptibility_scalar" in out["matched_keywords"]


def test_magnetic_susceptibility_tensor():
    text = """
 chi_ij:
  5.20e-4  0.00e+0  0.00e+0
  0.00e+0  5.18e-4  0.00e+0
  0.00e+0  0.00e+0  5.30e-4
    """
    out = parse_magnetic_susceptibility(text)
    assert out["tensor_SI"] is not None
    assert out["tensor_SI"][0][0] == pytest.approx(5.20e-4, rel=1e-6)
    assert out["scalar_SI"] == pytest.approx(
        (5.20e-4 + 5.18e-4 + 5.30e-4) / 3.0, rel=1e-6
    )


# ----------------------------------------------------------------------------
# parse_magnetoelectric_tensor
# ----------------------------------------------------------------------------


def test_magnetoelectric_matrix_3x3():
    text = """
 magnetoelectric tensor (alpha_ij)
  1.20e-2  0.00e+0  0.00e+0
  0.00e+0  1.18e-2  0.00e+0
  0.00e+0  0.00e+0  1.30e-2
    """
    out = parse_magnetoelectric_tensor(text)
    assert out["matrix"] is not None
    assert out["matrix"][2][2] == pytest.approx(1.30e-2, rel=1e-6)
    assert out["max_abs"] == pytest.approx(1.30e-2, rel=1e-6)


def test_magnetoelectric_inline_components():
    text = "magnetoelectric: alpha_11=1.0 alpha_22=2.0 alpha_33=3.0\n"
    out = parse_magnetoelectric_tensor(text)
    assert out["matrix"] is not None
    flat = [v for row in out["matrix"] for v in row if v is not None]
    assert pytest.approx(1.0, rel=1e-6) in flat
    assert pytest.approx(3.0, rel=1e-6) in flat


# ----------------------------------------------------------------------------
# parse_plot_bz_artifact
# ----------------------------------------------------------------------------


def test_plot_bz_artifacts_present(tmp_path):
    (tmp_path / "BZ_plot.ps.gz").write_bytes(b"\x1f\x8b\x08FAKE")
    (tmp_path / "BZ.txt").write_text("Γ X M Γ R X M R\n", encoding="utf-8")
    out = parse_plot_bz_artifact(tmp_path)
    assert out["BZ_plot_ps_gz"] == "BZ_plot.ps.gz"
    assert out["BZ_txt"] == "BZ.txt"
    assert "BZ_plot_ps_gz" in out["matched_keywords"]
    assert "BZ_txt" in out["matched_keywords"]


def test_plot_bz_artifacts_absent(tmp_path):
    out = parse_plot_bz_artifact(tmp_path)
    assert out["BZ_plot_ps_gz"] is None
    assert out["BZ_txt"] is None
    assert out["matched_keywords"] == []


# ----------------------------------------------------------------------------
# parse_thermo_pw_p5_extra_log — dispatcher
# ----------------------------------------------------------------------------


def test_dispatcher_piezo():
    text = "piezoelectric tensor (C/m^2)\n 0  0  0  0  0  0\n"
    out = parse_thermo_pw_p5_extra_log("piezoelectric_tensor", text)
    assert "matrix" in out


def test_dispatcher_scf_dielectric():
    text = "dielectric constant\n 11.2 0 0\n 0 11.2 0\n 0 0 11.2\n"
    out = parse_thermo_pw_p5_extra_log("scf_dielectric", text)
    assert "matrix" in out


def test_dispatcher_magnetic():
    out = parse_thermo_pw_p5_extra_log(
        "magnetic_susceptibility", "magnetic susceptibility = 5.0e-4 SI"
    )
    assert out["scalar_SI"] == pytest.approx(5.0e-4, rel=1e-6)


def test_dispatcher_magnetoelectric():
    out = parse_thermo_pw_p5_extra_log(
        "magnetoelectric_tensor", "alpha_33 = 1.5e-2"
    )
    assert out["matrix"] is not None


def test_dispatcher_plot_bz(tmp_path):
    (tmp_path / "BZ_plot.ps.gz").write_bytes(b"F")
    out = parse_thermo_pw_p5_extra_log(
        "plot_bz", "any text", work_dir=tmp_path
    )
    assert out["BZ_plot_ps_gz"] == "BZ_plot.ps.gz"


def test_dispatcher_unknown_what_returns_empty():
    out = parse_thermo_pw_p5_extra_log("nonsense_what", "anything")
    assert out == {}


def test_dispatcher_empty_what_returns_empty():
    out = parse_thermo_pw_p5_extra_log("", "anything")
    assert out == {}


# ----------------------------------------------------------------------------
# _read_numeric_matrix_after_header — tests directs du helper
# ----------------------------------------------------------------------------


def test_helper_basic_3x3():
    text = "chi_ij:\n 1.0  0.0  0.0\n 0.0  2.0  0.0\n 0.0  0.0  3.0\n"
    rows, first = _read_numeric_matrix_after_header(
        text,
        r"(?i)chi[\s_]*ij",
        n_rows=3,
        n_cols=3,
    )
    assert len(rows) == 3
    assert rows[0] == [1.0, 0.0, 0.0]
    assert rows[1] == [0.0, 2.0, 0.0]  # ligne 2 du journal
    assert rows[2] == [0.0, 0.0, 3.0]
    assert first is not None and "1.0" in first


def test_helper_skips_blanks_and_comments():
    text = (
        "title here\n\n"
        "  # comment\n"
        "  1.0  2.0  3.0\n"
        "  4.0  5.0  6.0\n"
        "  7.0  8.0  9.0\n"
    )
    rows, first = _read_numeric_matrix_after_header(
        text,
        r"title here",
        n_rows=3,
        n_cols=3,
    )
    assert len(rows) == 3
    assert rows[0] == [1.0, 2.0, 3.0]
    assert rows[2] == [7.0, 8.0, 9.0]


def test_helper_no_header_returns_empty():
    rows, first = _read_numeric_matrix_after_header(
        "no header here\n1 2 3\n4 5 6\n7 8 9\n",
        r"never_present",
        n_rows=3,
        n_cols=3,
    )
    assert rows == []
    assert first is None


def test_helper_wrong_token_count_returns_empty():
    text = "title\n1 2\n3 4 5\n"  # 1st line has only 2 tokens (skipped)
    rows, first = _read_numeric_matrix_after_header(
        text,
        r"title",
        n_rows=3,
        n_cols=3,
    )
    assert rows == []


def test_helper_handles_fortran_d_exponent():
    text = "header\n1.0d0 2.0D-3 3.0e+1\n 4.0 5.0 6.0\n 7.0 8.0 9.0\n"
    rows, _ = _read_numeric_matrix_after_header(
        text,
        r"header",
        n_rows=3,
        n_cols=3,
    )
    assert rows[0] == [1.0, 2.0e-3, 30.0]


def test_helper_invalid_regex_returns_empty():
    rows, first = _read_numeric_matrix_after_header(
        "any text",
        r"[invalid",  # unclosed bracket
        n_rows=2,
        n_cols=2,
    )
    assert rows == []
    assert first is None


def test_helper_empty_text_returns_empty():
    rows, first = _read_numeric_matrix_after_header("", r"x", n_rows=2, n_cols=2)
    assert rows == [] and first is None


def test_piezoelectric_unit_scopes_to_title_when_unrelated_paren_earlier():
    """Issue reviewer #1: unit must come from piezoelectric_titles substring,
    NOT from the first ``(...)`` in the entire log.

    Sans ce scope, un log contenant ``Ps (Hz^-1)`` avant le bloc piézo ferait
    ``out["unit"] = "Hz^-1"`` au lieu de ``"C/m^2"``.
    """
    text = (
        "Some other section\n"
        "    Ps (Hz^-1) ambient noise\n"
        "\n"
        "piezoelectric tensor (C/m^2)\n"
        " 0.00 0.00 0.00 0.50 0.00 0.00\n"
        " 0.00 0.00 0.00 0.00 0.60 0.00\n"
        " 0.70 0.00 0.00 0.00 0.00 0.00\n"
    )
    out = parse_piezoelectric_tensor(text)
    assert out["matrix"] is not None
    assert out["unit"] == "C/m^2"

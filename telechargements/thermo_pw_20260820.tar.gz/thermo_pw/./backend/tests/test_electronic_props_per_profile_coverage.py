"""
Lock-step coverage test — electronic metrics across all 5 profiles (P1..P5).

Verrouille l'invariant que **chaque profil** ``P1..P5`` expose le bloc canonique
``_METRICS_ELECTRONIC`` (et ses plots associés ``_PLOTS_ELECTRONIC``) dans son
``expected_results`` tel que défini dans ``backend/pipeline.py``.

Contexte (juillet 2026)
-----------------------
L'UI en front (interface/app_v2.js:updateLiveResults) et le runner
``PipelineJob._run_electronic_properties`` s'appuient sur la présence stable
de **4 métriques électroniques** (`fermi_eV`, `band_gap_eV`, `band_gap_type`,
`n_bands`) + **2 plots** (`plots.ebands`, `plots.edos`) dans la fiche de
chaque profil. Si une refacto renomme une clé ou retire un profil de
cette union universelle, l'UI perd son contrat et les marqueurs JSON
``pipeline_api_job_state.json`` deviennent illisibles côté front.

Ce test verrouille l'invariant en deux temps :

  1. **Tests per-profil** (5 × ``test_<P>_exposes_...``) — l'un des 5 profils
     perd une clé ⇒ diagnostic pinpointé au profil fautif.
  2. **Tests cross-profil** (intersections exactes) — alerte si le bloc
     ``_METRICS_ELECTRONIC`` de pipeline.py a été modifié SANS mise à jour
     de la constante miroir ``LOCK_STEP_ELECTRONIC_METRIC_KEYS`` ici.

Mirror convention
-----------------
Constantes ``LOCK_STEP_ELECTRONIC_METRIC_KEYS`` /
``LOCK_STEP_ELECTRONIC_PLOT_KEYS`` : DOIVENT rester en lock-step exact
avec ``backend.pipeline._METRICS_ELECTRONIC`` /
``backend.pipeline._PLOTS_ELECTRONIC``. Toute divergence casse les
tests ``test_all_five_profiles_share_exact_electronic_metric_set`` /
``test_all_five_profiles_share_exact_electronic_plot_set`` avec un
message ActionableError qui pointe vers les constantes miroir.

Exécution
---------
* pytest :  ``cd backend && python3 -m pytest tests/test_electronic_props_per_profile_coverage.py -v``
* standalone : ``python3 backend/tests/test_electronic_props_per_profile_coverage.py``
"""
from __future__ import annotations

import sys
from pathlib import Path


# ----------------------------------------------------------------------------
# Bootstrap — rend `backend/` importable (le test vit dans ``backend/tests/``).
# ----------------------------------------------------------------------------

_HERE = Path(__file__).resolve().parent
_BACKEND = _HERE.parent
for candidate in (_BACKEND, _BACKEND.parent):
    sp = str(candidate)
    if sp not in sys.path:
        sys.path.insert(0, sp)

import pytest  # noqa: E402
from pipeline import PROFILES  # noqa: E402

# Toutes les constantes mirror sont centralisées dans le helper partagé
# ``backend/tests/_profile_mirrors.py`` (DRY). Toute modification de
# ``backend/pipeline.py`` doit propager DANS CE HELPER EN PREMIER ; les
# tests de couverture cassent automatiquement si une constante mirror
# dérive (diagnostic pinpoint via ActionableError).
from backend.tests._profile_mirrors import (  # noqa: E402,F401
    ALL_PROFILE_IDS,
    KNOWN_LEGACY_WHAT_QE_ALIASES,
    LOCK_STEP_CANONICAL_WHAT_QE,
    LOCK_STEP_DYN_STABILITY_METRIC_KEYS,
    LOCK_STEP_ELECTRONIC_METRIC_KEYS,
    LOCK_STEP_ELECTRONIC_PLOT_KEYS,
    LOCK_STEP_MAGNETISM_METRIC_KEYS,
    LOCK_STEP_PROFILES,
)


# ----------------------------------------------------------------------------
# Helpers bas niveau
# ----------------------------------------------------------------------------


def _profile(profile_id: str) -> dict:
    """Renvoie le dict du profil, ou lève une AssertionError dédiée."""
    p = PROFILES.get(profile_id)
    assert p is not None, (
        f"[lockstep] Profil {profile_id!r} absent de PROFILES. "
        f"Clés connues : {sorted(PROFILES.keys())}. "
        f"LOCK_STEP_PROFILES doit être en lock-step avec backend.pipeline.PROFILES."
    )
    return p


def _profile_metric_keys(profile_id: str) -> frozenset[str]:
    """Set de TOUTES les clés métriques du profil (toutes catégories)."""
    metrics = _profile(profile_id).get("expected_results", {}).get("metrics", []) or []
    return frozenset(m.get("key") for m in metrics if m.get("key"))


def _profile_plot_keys(profile_id: str) -> frozenset[str]:
    """Set de TOUTES les clés plots du profil (toutes catégories)."""
    plots = _profile(profile_id).get("expected_results", {}).get("plots", []) or []
    return frozenset(pl.get("key") for pl in plots if pl.get("key"))


# ----------------------------------------------------------------------------
# Drift detection — INFO-RAPPORT en __main__, ne casse jamais les tests.
# ----------------------------------------------------------------------------


# Union des clés ``properties.*`` miroirées dans CE fichier. Le drift
# detection compare à cette union — toute clé émergente non listée ci-dessous
# est signalée comme « extension non miroirée ».
_MIRRORED_PROPERTIES_KEYS: frozenset[str] = (
    LOCK_STEP_ELECTRONIC_METRIC_KEYS | LOCK_STEP_DYN_STABILITY_METRIC_KEYS
)
"""Union des miroirs électroniques + dyn_stability — référence pour le drift."""


def _report_drift_intersection_properties() -> list[str]:
    """Renvoie la liste triée des clés ``properties.*`` partagées par P1..P5
    mais **absentes du miroir** courant (électronique ∪ dyn_stability).

    Sémantique : cette fonction est un **avertisseur**, pas une assertion.
    Elle liste les clés ``properties.*`` qui sont universellement
    partagées (intersection sur les 5 profils) sans être encore couvertes
    par ``LOCK_STEP_ELECTRONIC_METRIC_KEYS`` ou
    ``LOCK_STEP_DYN_STABILITY_METRIC_KEYS``.

    Cas typiques où le drift se déclenche :
      * Quelqu'un ajoute une nouvelle clé à ``_METRICS_ELECTRONIC`` /
        ``_METRICS_DYN_STABILITY`` dans pipeline.py SANS mettre à jour le
        miroir correspondant.
      * Quelqu'un ajoute un **nouveau bloc** partagé via une autre
        constante ``_METRICS_*`` (ex. ``_METRICS_OPTICAL``) qui doit être
        miroiré séparément.

    Usage : appeler en fin de ``__main__`` (cf. bloc standalone runner) ;
    pytest ne dépend PAS de cette fonction (pytest test runner doit
    toujours fonctionner même en présence de drift).
    """
    sets_per_profile = {
        pid: frozenset(
            k for k in _profile_metric_keys(pid) if k.startswith("properties.")
        )
        for pid in LOCK_STEP_PROFILES
    }
    intersection = frozenset.intersection(*sets_per_profile.values())
    extras = sorted(intersection - _MIRRORED_PROPERTIES_KEYS)
    return extras


# ============================================================================
# Phase 1 — Tests per-profile paramétrés (pytest.mark.parametrize)
# ============================================================================
#
# Avant cette ré-écriture, 10 fonctions ``test_pN_exposes_full_...`` répétaient
# le même corps avec une constante différente. Désormais, 2 fonctions
# paramétrées ``test_exposes_full_...`` sont décorées ``pytest.mark.parametrize``
# avec ``ALL_PROFILE_IDS`` : pytest génère 5 instances de test par fonction,
# chacune avec un id ``test_exposes_full_electronic_metrics_set[P1]`` etc.
# — diagnostic immédiat pinpointé au profil fautif.
#
# Le runner standalone (``if __name__ == "__main__":``) itère
# ``ALL_PROFILE_IDS`` manuellement pour reproduire le même grain de diagnostic
# en environnement sans pytest.


@pytest.mark.parametrize("profile_id", ALL_PROFILE_IDS)
def test_exposes_full_electronic_metrics_set(profile_id: str) -> None:
    """Invariant per-profil (electronic) : {profile_id} expose les 4 métriques.

    Pytest parametrize crée 5 instances de test ; en cas d'échec, le diagnostic
    est immédiat (``test_exposes_full_electronic_metrics_set[{profile_id}]``).
    Le runner standalone itère ``ALL_PROFILE_IDS`` pour préserver ce grain.

    Cible : ``_METRICS_ELECTRONIC`` (4 clés partagées par P1..P5 via
    ``_PROFILE_PROPERTIES``).
    """
    keys = _profile_metric_keys(profile_id)
    missing = LOCK_STEP_ELECTRONIC_METRIC_KEYS - keys
    assert not missing, (
        f"[lockstep] {profile_id} manque les métriques électroniques "
        f"suivantes : {sorted(missing)}. Présentes : "
        f"{sorted(keys & LOCK_STEP_ELECTRONIC_METRIC_KEYS)}."
    )


# ============================================================================
# Phase 1b — Tests per-profile paramétrés : stabilité dynamique
# ============================================================================


@pytest.mark.parametrize("profile_id", ALL_PROFILE_IDS)
def test_exposes_full_dyn_stability_metrics_set(profile_id: str) -> None:
    """Invariant per-profil (dyn_stability) : {profile_id} expose les 3 clés dyn.

    Symétrique de ``test_exposes_full_electronic_metrics_set``.
    Cible : ``_METRICS_DYN_STABILITY`` (3 clés partagées par P1..P5 via
    ``_PROFILE_PROPERTIES``).
    """
    keys = _profile_metric_keys(profile_id)
    missing = LOCK_STEP_DYN_STABILITY_METRIC_KEYS - keys
    assert not missing, (
        f"[lockstep] {profile_id} manque les métriques dyn_stability "
        f"suivantes : {sorted(missing)}. Présentes : "
        f"{sorted(keys & LOCK_STEP_DYN_STABILITY_METRIC_KEYS)}."
    )



@pytest.mark.parametrize("profile_id", ALL_PROFILE_IDS)
def test_exposes_full_magnetism_metrics_set(profile_id: str) -> None:
    """Invariant per-profil (magnétisme) : ``{profile_id}`` expose les 3 clés.

    Symétrique de ``test_exposes_full_dyn_stability_metrics_set`` (juillet 2026).
    Cible : ``_METRICS_MAGNETISM`` (3 clés partagées par P1..P5 via le spread
    ``*_METRICS_MAGNETISM`` ajouté à ``expected_results.metrics`` de chaque profil).

    Sémantique opt-in : ces clés sont **advertised** (visibles dans l'UI) mais
    peuplées **uniquement si ``nspin>1``** dans ``scf.in``. Le test verrouille
    uniquement l'invariant "le profil ADVERTIS la disponibilité" — la valeur
    reste ``None`` tant qu'un parser PWscf ``Magnetic moment per site:``
    n'écrit pas dans ``results['magnetism'][...]``.
    """
    keys = _profile_metric_keys(profile_id)
    missing = LOCK_STEP_MAGNETISM_METRIC_KEYS - keys
    assert not missing, (
        f"[lockstep] {profile_id} manque les métriques magnétiques "
        f"suivantes : {sorted(missing)}. Présentes : "
        f"{sorted(keys & LOCK_STEP_MAGNETISM_METRIC_KEYS)}. "
        f"Wedge : ajouter ``*_METRICS_MAGNETISM`` au spread metrics de {profile_id} "
        f"dans pipeline.py (cf. _profile_mirrors.LOCK_STEP_MAGNETISM_METRIC_KEYS)."
    )



# ============================================================================
# Phase 2b — Tests cross-profil : dyn_stability (symétrique Phase 2)
# ============================================================================


def test_all_five_profiles_include_dyn_stability_metrics_in_universal_intersection() -> None:
    """Invariant 2b (symétrique de l'invariant electronic) : les 3 clés
    ``_METRICS_DYN_STABILITY`` sont incluses dans l'intersection
    universelle des ``properties.*`` partagés par P1..P5.

    Symétrique du test ``test_all_five_profiles_include_electronic_metrics_in_universal_intersection``
    — la même intersection universelle contient **à la fois** les
    4 clés électroniques et les 3 clés dyn_stability. Tolère toute
    autre clé ``properties.*`` hors scope.

    Alerte principale : si quelqu'un retire / renomme une clé dans
    ``pipeline._METRICS_DYN_STABILITY`` SANS mettre à jour
    ``LOCK_STEP_DYN_STABILITY_METRIC_KEYS`` ici, ce test cassera.
    """
    sets_per_profile = {
        pid: frozenset(
            k for k in _profile_metric_keys(pid) if k.startswith("properties.")
        )
        for pid in LOCK_STEP_PROFILES
    }
    intersection = frozenset.intersection(*sets_per_profile.values())
    expected = LOCK_STEP_DYN_STABILITY_METRIC_KEYS
    missing_in_intersection = expected - intersection
    assert not missing_in_intersection, (
        f"[lockstep] Clés dyn_stability du miroir absentes de l'intersection "
        f"universelle : {sorted(missing_in_intersection)}. "
        f"Mise à jour de LOCK_STEP_DYN_STABILITY_METRIC_KEYS requise (lock-step "
        f"avec backend/pipeline.py:_METRICS_DYN_STABILITY) — OU retirer la clé "
        f"manquante d'un ou plusieurs profils."
    )



def test_all_five_profiles_include_magnetism_metrics_in_universal_intersection() -> None:
    """Invariant 3 (juillet 2026 — magnétisme) : les 3 clés ``_METRICS_MAGNETISM``
    sont incluses dans l'**union** universelle des métriques partagés par P1..P5.

    Différence sémantique importante vs electronic/dyn_stability :
      * ``properties.*`` (electronic, dyn_stability) → le test précédent utilise
        l'intersection stricte (les 5 profils partagent les 4/3 clés à 100%).
      * ``magnetism.*`` → on utilise l'union (chaque profil doit avoir les 3
        clés, mais elles peuvent coexister avec d'autres ``magnetism.*`` op-
        tionnelles — typiquement ``magnetism.starting_magnetization_per_atom``
        lu du scf.in mais non dans ``_METRICS_MAGNETISM``).

    Ce test vérifie seulement que les **3 clés du miroir** sont universellement
    présentes. Il autorise la présence d'autres ``magnetism.*`` hors miroir
    (= drift candidates tolérées tant qu'elles ne cassent pas le contrat des
    3 clés principales).
    """
    sets_per_profile = {
        pid: frozenset(
            k for k in _profile_metric_keys(pid) if k.startswith("magnetism.")
        )
        for pid in LOCK_STEP_PROFILES
    }
    union = frozenset.union(*sets_per_profile.values())
    expected = LOCK_STEP_MAGNETISM_METRIC_KEYS
    missing_in_union = expected - union
    assert not missing_in_union, (
        f"[lockstep] Clés magnétiques du miroir absentes de l'union universelle : "
        f"{sorted(missing_in_union)}. Mise à jour de LOCK_STEP_MAGNETISM_METRIC_KEYS "
        f"requise (lock-step avec backend/pipeline.py:_METRICS_MAGNETISM) — "
        f"OU retirer la clé manquante du ou des profils qui ne l'annoncent pas."
    )


# ============================================================================
# Phase 3c — Tests du drift detection : couverture pytest de la fonction
# INFO-rapport (sinon une régression du frozenset wrap casserait en silence).
# ============================================================================


# Module-level dispatcher — le drift detection n'est PAS listé dans
# PARAMETRIZED_PER_PROFILE_TESTS, donc le runner standalone l'inclura
# automatiquement dans la phase 2 (non-paramétrée). Les tests pytest
# ci-dessous garantissent qu'il ne régresse pas silencieusement.


def test_drift_intersection_returns_list() -> None:
    """``_report_drift_intersection_properties()`` renvoie bien une ``list``.

    Bloque les régressions silencieuses où un futur refactor changerait
    le type de retour (ex. set, dict, generator). Drift detection est
    appelé en ``__main__`` uniquement — sans ce test pytest, un
    changement de signature passerait silencieusement en CI.
    """
    result = _report_drift_intersection_properties()
    assert isinstance(result, list), (
        f"[lockstep] drift detection doit renvoyer list, got {type(result).__name__}"
    )


def test_drift_intersection_returns_strings_starting_with_properties() -> None:
    """Toutes les candidates drift sont des chaînes ``properties.*``.

    Garantit que seules les clés candidates sont listées (pas de pollution
    par d'autres catégories : elastic.*, eos.*, thermo.*, etc.).
    """
    for k in _report_drift_intersection_properties():
        assert isinstance(k, str), (
            f"[lockstep] chaque drift candidate doit être str, got {type(k).__name__}: {k!r}"
        )
        assert k.startswith("properties."), (
            f"[lockstep] drift candidate hors scope « properties. » : {k!r}. "
            f"Le miroir ne s'intéresse qu'aux clés préfixées properties."
        )


def test_drift_intersection_excludes_mirrored_keys() -> None:
    """Aucune clé miroirée n'apparaît dans la liste drift.

    Symétrie de l'invariant : si quelqu'un ajoute une clé à
    ``LOCK_STEP_ELECTRONIC_METRIC_KEYS`` ou
    ``LOCK_STEP_DYN_STABILITY_METRIC_KEYS``, elle ne doit plus apparaître
    comme « drift candidate ».
    """
    drift = set(_report_drift_intersection_properties())
    overlap = drift & _MIRRORED_PROPERTIES_KEYS
    assert not overlap, (
        f"[lockstep] drift detection a listé des clés déjà miroirées : "
        f"{sorted(overlap)} — vérifier l'union _MIRRORED_PROPERTIES_KEYS."
    )


def test_drift_intersection_consistent_with_all_profiles() -> None:
    """Sanity : si la liste est non-vide, chaque clé doit effectivement
    être présente dans CHAQUE profil P1..P5 (intersection stricte).

    Bloque les faux positifs où la fonction retournerait des clés qui ne
    sont pas vraiment universelles.
    """
    drift = _report_drift_intersection_properties()
    if not drift:
        # Empty drift n'est pas une erreur — skip simplement la vérification
        # forte (le test principal passe déjà).
        return
    for k in drift:
        for pid in ALL_PROFILE_IDS:
            keys = _profile_metric_keys(pid)
            assert k in keys, (
                f"[lockstep] drift {k!r} listée alors qu'absente du profil "
                f"{pid}. Intersection universelle mal calculée."
            )


def test_drift_intersection_is_sorted_and_deduped() -> None:
    """La liste renvoyée est triée alphabétiquement et dédupliquée.

    Bloc subtil : un refactor sans ``sorted(set(...))`` pourrait
    renvoyer des doublons ou un ordre non-déterministe ⇒ messages
    DRIFT variables entre runs (pollution UX).
    """
    result = _report_drift_intersection_properties()
    assert result == sorted(set(result)), (
        f"[lockstep] drift detection n'est pas triée/dédoublée : {result!r}. "
        f"Devrait renvoyer sorted(set(...))."
    )


# ============================================================================
# Phase 4 — Contrat ``what_qe`` : directive thermo_pw canonique par profil
# ============================================================================
#
# Chaque profil expose une directive thermo_pw canonique via la clé
# ``what_qe`` (cf. pipeline.py), utilisée par l'orchestrateur
# ``backend.phonon_chain_qe.run_thermo_pw_mpi``. La canonisation juin 2026
# a consolidé 5 directives distinctes ; les alias legacy
# ``elastic``, ``mur_lc_t``, ``mur_lc_t_elastic_constants``, ``qha_lif``
# doivent avoir disparu des PROFILES canoniques (rétrocompat maintenue
# en runtime via ``run_thermo_pw_mpi``, plus via la fiche profil).
#
# Cette section verrouille 3 invariants :
#   1. Chaque profil documente un ``what_qe`` canonique (parametrize par profil).
#   2. ``what_qe`` n'est jamais une chaîne vide (tous les profils).
#   3. Aucun profil n'utilise un alias legacy deprecated (tous les profils).


@pytest.mark.parametrize("profile_id", ALL_PROFILE_IDS)
def test_each_profile_declares_canonical_what_qe(profile_id: str) -> None:
    """Invariant per-profil (what_qe) : ``{profile_id}`` documente la directive canonique.

    ``profile['what_qe']`` doit matcher exactement ``LOCK_STEP_CANONICAL_WHAT_QE[profile_id]``.
    En cas d'écart, le diagnostic pinpoint ``test_each_profile_declares_canonical_what_qe[{profile_id}]``
    aide à débugger côté UI / runner.
    """
    p = _profile(profile_id)
    actual = p.get("what_qe")
    expected = LOCK_STEP_CANONICAL_WHAT_QE.get(profile_id)
    assert actual == expected, (
        f"[lockstep] {profile_id} documente ``what_qe={actual!r}``, "
        f"attendu ``{expected!r}`` (LOCK_STEP_CANONICAL_WHAT_QE). "
        f"Mettre à jour la constante mirror ou pipeline.PROFILES[{profile_id!r}]['what_qe']."
    )


def test_all_what_qe_values_are_non_empty_strings() -> None:
    """Invariant transverse : tous les ``what_qe`` sont des chaînes non vides.

    Bloque les régressions où quelqu'un viderait accidentellement
    ``what_qe`` ou y placerait ``None`` (ce qui crasherait le runner
    ``run_thermo_pw_mpi`` au moment de générer thermo_control).
    """
    bad: list[tuple[str, object]] = []
    for pid in ALL_PROFILE_IDS:
        v = _profile(pid).get("what_qe")
        if not isinstance(v, str) or not v.strip():
            bad.append((pid, v))
    assert not bad, (
        f"[lockstep] ``what_qe`` non-string ou vide : {bad}. "
        f"Tous les profils doivent déclarer une directive thermo_pw "
        f"canonique non vide."
    )


def test_no_what_qe_uses_known_legacy_alias() -> None:
    """Invariant transverse : aucun profil n'utilise un alias legacy deprecated.

    Les alias ``elastic``, ``mur_lc_t``, ``mur_lc_t_elastic_constants``,
    ``qha_lif`` ont été remplacés lors de la refonte juin 2026. S'ils
    réapparaissent dans ``PROFILES``, c'est un signe que le profil n'a pas
    été migré vers le canonique refondu.

    Le runtime ``run_thermo_pw_mpi`` accepte encore ces alias pour
    rétro-compat des ``pipeline_api_job_state.json`` legacy — mais la
    fiche profil canonique (``PROFILES``) doit avoir migré.
    """
    bad: list[tuple[str, str]] = []
    for pid in ALL_PROFILE_IDS:
        v = _profile(pid).get("what_qe")
        if v in KNOWN_LEGACY_WHAT_QE_ALIASES:
            bad.append((pid, v))
    assert not bad, (
        f"[lockstep] profils utilisant un alias ``what_qe`` deprecated : {bad}. "
        f"Migrer vers le canonique LOCK_STEP_CANONICAL_WHAT_QE[{pid!r}] "
        f"= ``{LOCK_STEP_CANONICAL_WHAT_QE.get(pid)!r}``."
    )


# ============================================================================
# Phase 3b — Structure : dyn_stability metrics (clefs/label/unit/group)
# ============================================================================



def test_dyn_stability_metrics_have_complete_structure() -> None:
    """Chaque métrique dyn_stability déclare key + label + unit + group.

    Symétrique de ``test_electronic_metrics_have_complete_structure``.
    NB : ``unit`` peut valoir ``""`` (sans dimension) pour
    ``properties.dynamically_stable`` (bool) ou ``properties.n_imaginary_modes`` (count).
    """
    REQUIRED_FIELDS = ("key", "label", "unit", "group")
    bad: list[tuple[str, str, list[str]]] = []
    for pid in sorted(LOCK_STEP_PROFILES):
        p = _profile(pid)
        for m in p.get("expected_results", {}).get("metrics", []) or []:
            if m.get("key") not in LOCK_STEP_DYN_STABILITY_METRIC_KEYS:
                continue
            # ``is None`` : ``""`` est une valeur valide (sans dimension).
            missing_fields = [f for f in REQUIRED_FIELDS if m.get(f) is None]
            if missing_fields:
                bad.append((pid, m.get("key", "<no-key>"), missing_fields))
    assert not bad, (
        f"[lockstep] Métriques dyn_stability avec champs None : "
        f"{bad}. Chaque métrique doit avoir key/label/unit/group "
        f"(unit peut être '' pour sans dimension)."
    )



def test_magnetism_metrics_have_complete_structure() -> None:
    """Chaque métrique magnétisme (``magnetism.*``) déclare key + label + unit + group.

    Symétrique de ``test_dyn_stability_metrics_have_complete_structure``.
    NB : ``unit`` est ``"μ_B"`` pour les 3 clés du miroir (``m_per_atom``,
    ``total_magnetization``, ``projected_moments_per_atom``). Le test
    autorise aussi ``""`` (sans dimension) pour cohérence avec le pattern
    existant — un futur ajout d'une clé magnétique sans dimension reste OK.
    """
    REQUIRED_FIELDS = ("key", "label", "unit", "group")
    bad: list[tuple[str, str, list[str]]] = []
    for pid in sorted(LOCK_STEP_PROFILES):
        p = _profile(pid)
        for m in p.get("expected_results", {}).get("metrics", []) or []:
            if m.get("key") not in LOCK_STEP_MAGNETISM_METRIC_KEYS:
                continue
            missing_fields = [f for f in REQUIRED_FIELDS if m.get(f) is None]
            if missing_fields:
                bad.append((pid, m.get("key", "<no-key>"), missing_fields))
    assert not bad, (
        f"[lockstep] Métriques magnétiques avec champs None : "
        f"{bad}. Chaque métrique doit avoir key/label/unit/group."
    )



def test_each_profile_has_exactly_three_magnetism_metric_entries() -> None:
    """Invariant structurel magnétisme (symétrique du 3 metrics dyn_stability) :
    chaque profil a EXACTEMENT 3 entrées métriques ``magnetism.*`` correspondant
    au miroir ``_METRICS_MAGNETISM``.

    Bloque les régressions où quelqu'un dupliquerait la liste
    ``_METRICS_MAGNETISM`` dans la fiche d'un profil.
    """
    expected_n = len(LOCK_STEP_MAGNETISM_METRIC_KEYS)
    bad_count: list[tuple[str, int]] = []
    for pid in sorted(LOCK_STEP_PROFILES):
        p = _profile(pid)
        count = 0
        for m in p.get("expected_results", {}).get("metrics", []) or []:
            if m.get("key") in LOCK_STEP_MAGNETISM_METRIC_KEYS:
                count += 1
        if count != expected_n:
            bad_count.append((pid, count))
    assert not bad_count, (
        f"[lockstep] Comptage métriques magnétiques != {expected_n} "
        f"pour : {bad_count}. Attendu {expected_n} par profil "
        f"(correspond à _METRICS_MAGNETISM)."
    )


def test_each_profile_has_exactly_three_dyn_stability_metric_entries() -> None:
    """Invariant structurel dyn_stability (symétrique du 4 metrics) :
    chaque profil a EXACTEMENT 3 entrées métriques dyn_stability.

    Bloque les régressions où quelqu'un dupliquerait la liste
    ``_METRICS_DYN_STABILITY`` dans la fiche d'un profil.
    """
    expected_n = len(LOCK_STEP_DYN_STABILITY_METRIC_KEYS)
    bad_count: list[tuple[str, int]] = []
    for pid in sorted(LOCK_STEP_PROFILES):
        p = _profile(pid)
        count = 0
        for m in p.get("expected_results", {}).get("metrics", []) or []:
            if m.get("key") in LOCK_STEP_DYN_STABILITY_METRIC_KEYS:
                count += 1
        if count != expected_n:
            bad_count.append((pid, count))
    assert not bad_count, (
        f"[lockstep] Comptage métriques dyn_stability != {expected_n} "
        f"pour : {bad_count}. Attendu {expected_n} par profil "
        f"(correspond à _METRICS_DYN_STABILITY)."
    )


# ============================================================================
# Phase 2 — Tests cross-profil (intersection universelle lock-step)
# ============================================================================


def test_lockstep_profiles_mirror_pipeline_profiles() -> None:
    """Invariant 0 : ``LOCK_STEP_PROFILES`` est en lock-step avec ``PROFILES.keys()``.

    Si un nouveau profil est ajouté/retiré dans pipeline.py SANS mise à
    jour de ce miroir, ce test alerte avec un message explicite.
    """
    keys = set(PROFILES.keys())
    mirror_set = set(LOCK_STEP_PROFILES)
    missing_in_mirror = keys - mirror_set
    extra_in_mirror = mirror_set - keys
    assert not missing_in_mirror, (
        f"[lockstep] PROFILES contient des profils absents du miroir : "
        f"{sorted(missing_in_mirror)}. Mettre à jour LOCK_STEP_PROFILES."
    )
    assert not extra_in_mirror, (
        f"[lockstep] LOCK_STEP_PROFILES référence des profils inexistants : "
        f"{sorted(extra_in_mirror)}. PROFILES.keys = {sorted(keys)}."
    )


def test_all_five_profiles_activate_electronic_chain() -> None:
    """Invariant 1 : les 5 profils ont ``properties_enabled=True`` ET
    ``properties_ichamp=3`` (chaîne NSCF + DOS + bandes active).
    """
    bad_enabled: list[tuple[str, object]] = []
    bad_ichamp: list[tuple[str, object]] = []
    for pid in sorted(LOCK_STEP_PROFILES):  # sorted ⇒ ordre déterministe
        p = _profile(pid)
        if p.get("properties_enabled") is not True:
            bad_enabled.append((pid, p.get("properties_enabled")))
        try:
            ichamp = int(p.get("properties_ichamp", 0))
        except (TypeError, ValueError):
            ichamp = -1
        if ichamp != 3:
            bad_ichamp.append((pid, p.get("properties_ichamp")))
    assert not bad_enabled, (
        f"[lockstep] profiles_enabled != True : {bad_enabled}. "
        f"La chaîne électronique ne tournera pas pour ces profils."
    )
    assert not bad_ichamp, (
        f"[lockstep] properties_ichamp != 3 : {bad_ichamp}. "
        f"Attendu 3 (NSCF + DOS + bandes)."
    )


def test_all_five_profiles_include_electronic_metrics_in_universal_intersection() -> None:
    """Invariant 2 : tous les 4 clés électroniques (``_METRICS_ELECTRONIC``)
    sont incluses dans l'intersection universelle des ``properties.*``
    partagés par P1..P5.

    Les 5 profils partagent PLUS que les seules 4 clés électroniques :
    ``_METRICS_DYN_STABILITY`` ajoute également 3 clés partagées
    (``properties.dynamically_stable``, ``properties.n_imaginary_modes``,
    ``properties.min_freq_cm-1``) via les crystaux partagés. Ces clés sont
    **hors scope** de CE test — on vérifie ici uniquement le sous-ensemble
    ``_METRICS_ELECTRONIC`` ⊆ intersection.

    C'est le test alerte principal : si quelqu'un ajoute OU retire une clé
    dans ``pipeline._METRICS_ELECTRONIC`` SANS mettre à jour
    ``LOCK_STEP_ELECTRONIC_METRIC_KEYS`` ici, ``missing_in_intersection``
    ne sera plus vide ⇒ le test cassera.
    """
    # Conversion explicite en frozenset : nécessaire pour utiliser
    # ``frozenset.intersection(*values)`` (méthode non-liée) — un ``set``
    # Python standard lève ``TypeError: descriptor 'intersection' for
    # 'frozenset' objects doesn't apply to a 'set' object``.
    sets_per_profile = {
        pid: frozenset(
            k for k in _profile_metric_keys(pid) if k.startswith("properties.")
        )
        for pid in LOCK_STEP_PROFILES
    }
    intersection = frozenset.intersection(*sets_per_profile.values())
    expected = LOCK_STEP_ELECTRONIC_METRIC_KEYS
    missing_in_intersection = expected - intersection
    assert not missing_in_intersection, (
        f"[lockstep] Clés électroniques du miroir absentes de l'intersection "
        f"universelle : {sorted(missing_in_intersection)}. "
        f"Mise à jour de LOCK_STEP_ELECTRONIC_METRIC_KEYS requise (lock-step "
        f"avec backend/pipeline.py:_METRICS_ELECTRONIC) — OU retirer la clé "
        f"manquante d'un ou plusieurs profils."
    )


def test_all_five_profiles_share_exact_electronic_plot_set() -> None:
    """Invariant 2b : les 5 profils partagent **EXACTEMENT** le même bloc
    plots électroniques (``plots.ebands`` + ``plots.edos``).

    Symétrique du test métrique : si ``_PLOTS_ELECTRONIC`` est étendu
    SANS mise à jour du miroir, ce test alerte.
    """
    sets_per_profile = {
        pid: _profile_plot_keys(pid) for pid in LOCK_STEP_PROFILES
    }
    intersection = frozenset.intersection(*sets_per_profile.values())
    expected = LOCK_STEP_ELECTRONIC_PLOT_KEYS

    missing_in_intersection = expected - intersection
    extra_in_intersection = intersection - expected

    assert not missing_in_intersection, (
        f"[lockstep] plots du miroir absents de l'intersection universelle : "
        f"{sorted(missing_in_intersection)}. "
        f"Mise à jour de LOCK_STEP_ELECTRONIC_PLOT_KEYS requise (lock-step "
        f"avec backend/pipeline.py:_PLOTS_ELECTRONIC)."
    )
    assert not extra_in_intersection, (
        f"[lockstep] Nouveaux plots électroniques partagés par les 5 profils "
        f"mais absents du miroir : {sorted(extra_in_intersection)}. "
        f"pipeline._PLOTS_ELECTRONIC a probablement été étendu — mettre à "
        f"jour LOCK_STEP_ELECTRONIC_PLOT_KEYS."
    )


# ============================================================================
# Phase 3 — Structure (key + label + unit + group) — UX contract preservé
# ============================================================================


def test_electronic_metrics_have_complete_structure() -> None:
    """Chaque métrique électronique déclare key + label + unit + group —
    requis par l'UI pour le rendu tabulaire sans crash.

    NB : ``unit`` peut valoir chaîne vide (``""``) pour une métrique
    sans dimension (ex. ``properties.n_bands``). Le check utilise
    ``is None`` (et non ``not value``) pour accepter ``""`` comme
    valeur valide.
    """
    REQUIRED_FIELDS = ("key", "label", "unit", "group")
    bad: list[tuple[str, str, list[str]]] = []
    for pid in sorted(LOCK_STEP_PROFILES):
        p = _profile(pid)
        for m in p.get("expected_results", {}).get("metrics", []) or []:
            if m.get("key") not in LOCK_STEP_ELECTRONIC_METRIC_KEYS:
                continue
            # ``is None`` : ``""`` est une valeur valide (sans dimension).
            missing_fields = [f for f in REQUIRED_FIELDS if m.get(f) is None]
            if missing_fields:
                bad.append((pid, m.get("key", "<no-key>"), missing_fields))
    assert not bad, (
        f"[lockstep] Métriques électroniques avec champs None : "
        f"{bad}. Chaque métrique doit avoir key/label/unit/group "
        f"(unit peut être '' pour sans dimension)."
    )


def test_electronic_plots_have_minimal_structure() -> None:
    """Chaque plot électronique déclare key + label — minimum requis par
    ``updateLiveResults`` front (cf. interface/app_v2.js).
    """
    REQUIRED_FIELDS = ("key", "label")
    bad: list[tuple[str, str, list[str]]] = []
    for pid in sorted(LOCK_STEP_PROFILES):
        p = _profile(pid)
        for pl in p.get("expected_results", {}).get("plots", []) or []:
            if pl.get("key") not in LOCK_STEP_ELECTRONIC_PLOT_KEYS:
                continue
            missing_fields = [f for f in REQUIRED_FIELDS if pl.get(f) is None]
            if missing_fields:
                bad.append((pid, pl.get("key", "<no-key>"), missing_fields))
    assert not bad, (
        f"[lockstep] Plots électroniques avec champs None : "
        f"{bad}. Chaque plot doit avoir au minimum key + label."
    )


# ============================================================================
# Sanity — chaque profil déclare EXACTEMENT 4 métriques + 2 plots électroniques
# ============================================================================


def test_each_profile_has_exactly_four_electronic_metric_entries() -> None:
    """Invariant structurel : chaque profil a EXACTEMENT 4 entrées
    métriques électroniques (et pas plus).

    Bloque les régressions où quelqu'un dupliquerait la liste
    ``_METRICS_ELECTRONIC`` dans la fiche d'un profil (via un copier-coller
    accidentel). L'UI afficherait alors 2× la même métrique.
    """
    expected_n = len(LOCK_STEP_ELECTRONIC_METRIC_KEYS)
    bad_count: list[tuple[str, int]] = []
    for pid in sorted(LOCK_STEP_PROFILES):
        p = _profile(pid)
        count = 0
        for m in p.get("expected_results", {}).get("metrics", []) or []:
            if m.get("key") in LOCK_STEP_ELECTRONIC_METRIC_KEYS:
                count += 1
        if count != expected_n:
            bad_count.append((pid, count))
    assert not bad_count, (
        f"[lockstep] Comptage métriques électroniques != {expected_n} "
        f"pour : {bad_count}. Attendu {expected_n} par profil "
        f"(correspond à _METRICS_ELECTRONIC)."
    )


def test_each_profile_has_exactly_two_electronic_plot_entries() -> None:
    """Invariant structurel (symétrique du précédent) : chaque profil a
    EXACTEMENT 2 entrées plots électroniques (et pas plus).
    """
    expected_n = len(LOCK_STEP_ELECTRONIC_PLOT_KEYS)
    bad_count: list[tuple[str, int]] = []
    for pid in sorted(LOCK_STEP_PROFILES):
        p = _profile(pid)
        count = 0
        for pl in p.get("expected_results", {}).get("plots", []) or []:
            if pl.get("key") in LOCK_STEP_ELECTRONIC_PLOT_KEYS:
                count += 1
        if count != expected_n:
            bad_count.append((pid, count))
    assert not bad_count, (
        f"[lockstep] Comptage plots électroniques != {expected_n} "
        f"pour : {bad_count}. Attendu {expected_n} par profil "
        f"(correspond à _PLOTS_ELECTRONIC)."
    )


# ============================================================================
# Standalone runner (sans pytest) — convention projet.
# ============================================================================
#
# Le runner supporte les deux modes :
#   * ``pytest`` : ``@pytest.mark.parametrize`` génère 5 instances par
#     fonction paramétrée — pytest appelle chaque instance avec le param.
#   * standalone : on itère ``ALL_PROFILE_IDS`` manuellement et on appelle
#     chaque fonction paramétrée avec chaque pid, pour reproduire le même
#     diagnostic pin-pointé en environnement sans pytest.


# Noms des fonctions paramétrées — le runner les traite spécifiquement.
PARAMETRIZED_PER_PROFILE_TESTS: frozenset[str] = frozenset({
    "test_exposes_full_electronic_metrics_set",
    "test_exposes_full_dyn_stability_metrics_set",
    "test_exposes_full_magnetism_metrics_set",
    "test_each_profile_declares_canonical_what_qe",
})
"""Tests paramétrés ``with pytest.mark.parametrize(['profile_id', ...])``."""


def _run_one(func_name: str, profile_id: str | None = None) -> tuple[bool, str]:
    """Exécute ``func_name()`` standalone et renvoie ``(ok, msg)``.

    Pour les tests paramétrés (``@pytest.mark.parametrize('profile_id', ...)``),
    ``profile_id`` doit être fourni — pytest ne fournit le paramètre que dans
    son propre framework ; le standalone runner doit le passer explicitement.

    ``profile_id=None`` : appel sans argument (tests non paramétrés).
    """
    func = globals().get(func_name)
    if func is None or not callable(func):
        return False, f"fonction {func_name!r} introuvable / non callable"
    try:
        if profile_id is None:
            func()
        else:
            func(profile_id)
    except AssertionError as ex:
        return False, f"AssertionError: {ex}"
    except Exception as ex:  # noqa: BLE001
        return False, f"{type(ex).__name__}: {ex}"
    return True, "[OK]"


if __name__ == "__main__":
    failures: list[tuple[str, str]] = []
    total = 0

    # 1. Tests paramétrés — itère ``ALL_PROFILE_IDS`` manuellement.
    for func_name in sorted(PARAMETRIZED_PER_PROFILE_TESTS):
        total += len(ALL_PROFILE_IDS)
        for pid in ALL_PROFILE_IDS:
            label = f"{func_name}[{pid}]"
            ok, msg = _run_one(func_name, profile_id=pid)
            if ok:
                print(f"[OK]   {label}")
            else:
                print(f"[FAIL] {label}: {msg}")
                failures.append((label, msg))

    # 2. Autres tests (non-paramétrés) — appel direct (profile_id=None).
    other_tests = sorted(
        n for n, obj in globals().items()
        if n.startswith("test_")
        and callable(obj)
        and n not in PARAMETRIZED_PER_PROFILE_TESTS
    )
    for name in other_tests:
        total += 1
        ok, msg = _run_one(name)
        if ok:
            print(f"[OK]   {name}")
        else:
            print(f"[FAIL] {name}: {msg}")
            failures.append((name, msg))

    passed = total - len(failures)
    print()

    # 3. Drift detection — INFO uniquement, ne contribue jamais à l'exit code.
    #    Liste les clés ``properties.*`` émergentes (partagées par P1..P5)
    #    mais absentes du miroir électronique ∪ dyn_stability courant.
    #    Avertisseur informatif dev : « il y a une nouvelle clé, faut-il
    #    la miroirer ? ».
    drift = _report_drift_intersection_properties()
    if drift:
        print(f"[DRIFT] {len(drift)} nouvelle(s) clé(s) properties.* partagée(s) "
              f"par P1..P5 mais NON miroirée(s) dans ce fichier :")
        for k in drift:
            print(f"         - {k}")
        print(
            "[DRIFT] Action suggérée : ajouter ces clés à "
            "LOCK_STEP_ELECTRONIC_METRIC_KEYS ou "
            "LOCK_STEP_DYN_STABILITY_METRIC_KEYS (selon la sémantique), "
            "OU créer un nouveau bloc mirroré (ex. _METRICS_OPTICAL) si "
            "la nouvelle clé appartient à un autre groupe."
        )
    else:
        print("[DRIFT] OK — aucune clé properties.* partagée non miroirée.")

    if failures:
        print(f"[FAIL] {len(failures)}/{total} tests failed ({passed}/{total} passed).")
        sys.exit(1)
    print(f"[OK]   {passed}/{total} tests passed.")
    sys.exit(0)

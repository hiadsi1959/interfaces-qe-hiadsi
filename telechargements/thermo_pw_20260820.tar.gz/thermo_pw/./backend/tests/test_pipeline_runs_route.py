"""
test_pipeline_runs_route.py
===========================

Régression Flask test client sur ``GET /api/pipeline/runs`` — verrouille le
fix de juillet 2026 dans ``backend/pipeline.py`` ligne ~3129.

Bug original
------------
``(request.args.get("limit") or 50).strip()`` :

* Si ``?limit=`` est **absent** du query string → ``request.args.get("limit")``
  vaut ``None`` → ``(None or 50)`` évalue à l'**entier** ``50`` → ``.strip()``
  sur un entier lève ``AttributeError: 'int' object has no attribute 'strip'``
  → **HTTP 500** systématique côté UI (le picker « Charger un calcul
  précédent » tombait silencieusement, le marqueur disque du run P1 Si terminé
  n'était jamais listé).

Fix appliqué
------------
``int(request.args.get("limit", "50").strip() or 50)`` :

* ``request.args.get("limit", "50")`` retourne **toujours une chaîne** (jamais
  ``None``) → ``.strip()`` toujours appelable.
* Le repli ``or 50`` absorbe la chaîne vide (``?limit=`` sans valeur).
* Le ``try/except (TypeError, ValueError)`` préserve le filet pour les
  valeurs non entières (``?limit=abc`` → ``ValueError`` → fallback 50).
* Le clamp ``max(1, min(500, limit))`` plafonne à 500 (sécurité UI).

Tests
-----
Via Flask ``app.test_client()`` (pas de subprocess backend, pas de QE/MPI).
WORK_ROOT est redirigé vers un tmp_path (``monkeypatch.setattr``) pour ne JAMAIS
toucher aux artefacts persistés du user.

Usage
-----
::

    cd /home/hiadsi/thermo_pw/backend && python3 -m pytest tests/test_pipeline_runs_route.py -v
    # ou depuis la racine du dépôt :
    python3 -m pytest backend/tests/test_pipeline_runs_route.py -v
"""
from __future__ import annotations

import json
import os
import sys

# Rend ``backend/`` importable (le test vit dans ``backend/tests/``, pas de
# conftest.py à la racine du dépôt).
_HERE = os.path.dirname(os.path.abspath(__file__))
_BACKEND = os.path.dirname(_HERE)
if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)

import pytest  # noqa: E402

import api_server  # noqa: E402  # noqa: E402 — charges ``app = Flask(__name__)`` + blueprints
import config as cfg  # noqa: E402
from pipeline import PipelineJob  # noqa: E402


# ============================================================================
# Helpers
# ============================================================================


@pytest.fixture
def isolated_work_root(tmp_path, monkeypatch):
    """Redirige ``cfg.WORK_ROOT`` vers ``tmp_path`` AVANT chaque test.

    La route ``/api/pipeline/runs`` lit ``cfg.WORK_ROOT`` **au moment du
    call** (pas à l'import — voir le source de ``list_pipeline_runs``), ce
    qui rend le ``monkeypatch.setattr`` parfaitement opérationnel.

    Buts :
      * Ne JAMAIS toucher aux artefacts persistés du user (``work/Si/...``).
      * Contrôler le nombre de markers exposés au test (``_seed_marker``).
      * Isoler chaque test de l'état partagé.

    Le nouveau path existe physiquement (créé) avant le test pour que
    ``work_root.is_dir()`` côté route renvoie ``True``.
    """
    work_root = tmp_path / "work_root"
    work_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(cfg, "WORK_ROOT", work_root)
    with PipelineJob._REGISTRY_LOCK:
        PipelineJob._REGISTRY.clear()
    return work_root


def _seed_marker(
    work_root: "os.PathLike[str]",
    job_id: str = "deadbeef1234",
    profile_id: str = "P1",
    status: str = "done",
    material_id: str = "Si",
) -> None:
    """Crée un marker ``pipeline_api_job_state.json`` minimal dans un sous-dossier
    ``<work_root>/<material>/pipeline_<profile>_<job6>/`` — mime le format
    observé en ``work/Si/pipeline_P1_*/pipeline_api_job_state.json``.
    """
    work_dir = work_root / material_id / f"dummy_pipeline_{profile_id}_{job_id[:6]}"
    work_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": 1,
        "job_id": job_id,
        "material_id": material_id,
        "profile_id": profile_id,
        "profile_name": "Mécanique 0 K" if profile_id == "P1" else "Dummy",
        "profile_emoji": "🟢" if profile_id == "P1" else "",
        "status": status,
        "message": "(test fixture)",
        "work_dir": str(work_dir.resolve()),
        "results": {},
        "logs": [],
        "created_at": "2026-07-01T00:00:00+00:00",
        "finished_at": "2026-07-01T01:00:00+00:00",
    }
    (work_dir / "pipeline_api_job_state.json").write_text(
        json.dumps(payload, ensure_ascii=False),
        encoding="utf-8",
    )


# ============================================================================
# Tests
# ============================================================================


class TestPipelineRunsRouteLimitParsing:
    """Verrouille le fix : ``request.args.get(\"limit\")`` ne doit JAMAIS
    lever ``AttributeError``, quel que soit le query param envoyé au blueprint
    ``/api/pipeline/runs``.

    Référence du bug : juillet 2026 — UI « Charger un calcul précédent »
    restait vide (HTTP 500 sur le picker), empêchant l'utilisateur de recharger
    un run P1 Si terminé malgré un marker disque correctement persisté.
    """

    def test_no_query_param_returns_200_with_valid_json(self, isolated_work_root):
        """(1) ``GET /api/pipeline/runs`` SANS query → HTTP 200 + JSON valide.

        C'est LE cas qui déclenchait le ``AttributeError`` original : le
        ``request.args.get(\"limit\")`` retournait ``None``, ``(None or 50)``
        évalue à l'entier ``50``, ``.strip()`` lève. La régression est
        silencieuse côté UI (pas d'erreur visible pour l'utilisateur final
        contrairement à un crash Python) mais le picker reste vide.
        """
        client = api_server.app.test_client()
        resp = client.get("/api/pipeline/runs")
        assert resp.status_code == 200, (
            f"GET /api/pipeline/runs (sans query) doit retourner HTTP 200, "
            f"got {resp.status_code}. Bug régressé : AttributeError sur le "
            f"parsing de `?limit=` quand la query string est absente. "
            f"Avant le fix de juillet 2026 : 500 systématique. "
            f"Body (réponse brute): {resp.get_data(as_text=True)[:300]!r}"
        )
        body = resp.get_json()
        assert isinstance(body, dict), (
            f"Réponse doit être un JSON dict, got: {type(body).__name__}"
        )
        # Contrat UI : la route expose ``count`` + ``runs`` (cf. interface/app_v2.js,
        # fonction refreshRunsList → state.runsCache = (r && r.runs) || []).
        assert "count" in body, (
            f"Réponse doit exposer la clé 'count' (consommée par l'UI picker), "
            f"got keys: {list(body.keys())}"
        )
        assert "runs" in body, (
            f"Réponse doit exposer la clé 'runs', got keys: {list(body.keys())}"
        )
        assert isinstance(body["count"], int), (
            f"'count' doit être un entier (UI l'affiche via state.runsCache "
            f"length), got: {type(body['count']).__name__}"
        )
        assert isinstance(body["runs"], list), (
            f"'runs' doit être une liste, got: {type(body['runs']).__name__}"
        )
        # ``isolated_work_root`` est vide : aucun marker → count = 0.
        assert body["count"] == 0
        assert body["runs"] == []

    def test_empty_limit_query_returns_200(self, isolated_work_root):
        """(2) ``GET /api/pipeline/runs?limit=`` (vide) → HTTP 200.

        Le repli ``or 50`` du fix absorbe la chaîne vide (sinon, l'ancien
        code aurait évalué ``(\"\" or 50)`` → entier ``50`` → re-raise
        AttributeError sur ``.strip()``. Donc doublement intéressant ici).
        """
        client = api_server.app.test_client()
        resp = client.get("/api/pipeline/runs?limit=")
        assert resp.status_code == 200, (
            f"GET /api/pipeline/runs?limit= doit retourner HTTP 200 (repli "
            f"`or 50` absorbe la chaîne vide), got {resp.status_code}. "
            f"Body: {resp.get_data(as_text=True)[:300]!r}"
        )
        body = resp.get_json()
        assert isinstance(body, dict)
        assert "count" in body and "runs" in body
        assert isinstance(body["runs"], list)

    def test_invalid_limit_value_abc_falls_back_to_50(self, isolated_work_root):
        """(3) ``GET /api/pipeline/runs?limit=abc`` → HTTP 200 + count ≤ 50.

        Le ``try/except (TypeError, ValueError)`` du code original est
        **préservé** dans le fix. Il convertit ``int(\"abc\")`` →
        ``ValueError`` → fallback ``limit = 50``. Sans ce filet, le picker
        planterait ; avec, l'UI affiche au plus 50 markers (cohérent avec
        les valeurs de l'UI elle-même qui passent ``50`` par défaut).
        """
        # Seed 1 marker pour que ``count > 0`` (sinon ``count == 0 ≤ 50``
        # serait trivialement vrai même si le fallback ne s'appliquait pas).
        _seed_marker(isolated_work_root, job_id="deadbeef0001", profile_id="P1")
        client = api_server.app.test_client()
        resp = client.get("/api/pipeline/runs?limit=abc")
        assert resp.status_code == 200, (
            f"GET /api/pipeline/runs?limit=abc doit retourner HTTP 200 "
            f"(ValueError catché → fallback limit=50, filet préservé par "
            f"le fix), got {resp.status_code}. "
            f"Body: {resp.get_data(as_text=True)[:300]!r}"
        )
        body = resp.get_json()
        # Filet de sécurité : pas plus de 50 markers retournés, même si
        # ``?limit=abc`` laissait passer l'intégralité du disque (cf. ancien
        # code avant 2002-2003 — clamp 1..500).
        assert body["count"] <= 50, (
            f"?limit=abc doit retomber sur 50 (`except ValueError`) ; "
            f"count borné à 50. got count={body['count']}"
        )
        # Sanity : avec exactement 1 marker en disque, le picker en retourne 1.
        assert body["count"] == 1, (
            f"Avec 1 marker en disque et limit=50, count doit valoir 1. "
            f"got count={body['count']}. Le fix doit laisser passer EXACTEMENT "
            f"les markers présents (pas un sous-ensemble plus petit)."
        )

    def test_oversized_limit_clamped_to_500(self, isolated_work_root):
        """(4) ``GET /api/pipeline/runs?limit=10000`` → HTTP 200 + count ≤ 500.

        Le clamp ``max(1, min(500, limit))`` plafonne l'éventuelle demande
        abusive de l'UI (ou d'un client tiers). Sans ce clamp, le picker
        rapatrierait 10000 markers et saturerait le DOM + la latence réseau.
        """
        _seed_marker(isolated_work_root, job_id="deadbeef0002", profile_id="P2")
        _seed_marker(isolated_work_root, job_id="deadbeef0003", profile_id="P3")
        client = api_server.app.test_client()
        resp = client.get("/api/pipeline/runs?limit=10000")
        assert resp.status_code == 200, (
            f"GET /api/pipeline/runs?limit=10000 doit retourner HTTP 200 "
            f"(clamp `max(1, min(500, 10000))` = 500), got {resp.status_code}. "
            f"Body: {resp.get_data(as_text=True)[:300]!r}"
        )
        body = resp.get_json()
        assert body["count"] <= 500, (
            f"limit=10000 doit être clampé à 500 (filet `min(500, limit)`) ; "
            f"got count={body['count']}. Le clamp 1..500 est INDISPENSABLE : "
            f"sans lui, l'UI rapatrierait des milliers de markers pour un "
            f"picker de 50–100 items max."
        )
        # Anti-régression : le clamp n'écrase PAS la valeur 500 → il laisse
        # passer 500 max. Avec 2 markers en disque → count = 2 (≤ 500, OK).
        assert body["count"] == 2, (
            f"Avec 2 markers seed et clamp=500, count doit valoir 2. "
            f"got count={body['count']}"
        )


class TestPipelineRunsRouteSmoke:
    """Sanity covers : le test fixture ``isolated_work_root`` isole bien,
    les markers créés sont bien lus par la route, et le contrat JSON reste
    stable (utilisé par l'UI dans ``refreshRunsList``).
    """

    def test_seeded_marker_is_visible_via_runs_endpoint(self, isolated_work_root):
        """Sanity : un ``_seed_marker`` est bien listé par ``/api/pipeline/runs``
        (le test fixture n'est pas cassé, c.-à-d. la chaîne WORK_ROOT +
        marker-file + route est cohérente)."""
        _seed_marker(isolated_work_root, job_id="abc123def0", profile_id="P1")
        client = api_server.app.test_client()
        resp = client.get("/api/pipeline/runs")
        assert resp.status_code == 200
        body = resp.get_json()
        assert body["count"] == 1, (
            f"Seed → 1 marker listé ; got count={body['count']}."
        )
        run = body["runs"][0]
        # Champs consommés par app_v2.js (refreshRunsList) :
        assert run["job_id"] == "abc123def0"
        assert run["profile_id"] == "P1"
        assert run["status"] == "done"
        assert run["material_id"] == "Si"
        assert isinstance(run["work_dir"], str) and run["work_dir"]

    def test_multiple_markers_all_visible(self, isolated_work_root):
        """Sanity : seed de 3 markers (P1/P2/P3) → count=3, IDs triés/préservés."""
        job_ids = ["1111111111", "2222222222", "3333333333"]
        for jid, pid in zip(job_ids, ("P1", "P2", "P3")):
            _seed_marker(isolated_work_root, job_id=jid, profile_id=pid)
        client = api_server.app.test_client()
        resp = client.get("/api/pipeline/runs")
        body = resp.get_json()
        assert body["count"] == 3, f"3 markers seedés → count=3, got {body['count']}"
        seen = {r["job_id"] for r in body["runs"]}
        assert seen == set(job_ids), (
            f"Mismatch IDs : attendu {job_ids}, got {sorted(seen)}"
        )


# ============================================================================
# Standalone runner (debug local rapide, sans pytest)
# ============================================================================

if __name__ == "__main__":
    """Émule pytest.main() minimaliste — utile pour debug local rapide.

    Usage : ``python3 backend/tests/test_pipeline_runs_route.py``

    NB : seuls les tests SANS fixtures arrivent ici ; pour la couverture
    complète (avec fixtures ``isolated_work_root`` / ``tmp_path`` /
    ``monkeypatch``), exécuter pytest (cf. docstring d'en-tête).
    """
    import inspect
    fns = []
    for name, obj in sorted(globals().items()):
        if not callable(obj) or not name.startswith("test_"):
            continue
        sig = inspect.signature(obj)
        params = [p for p in sig.parameters.keys() if p != "self"]
        if params:
            print(f"SKIP  {name}  (needs pytest fixtures)")
            continue
        fns.append((name, obj))
    fails = []
    for name, fn in fns:
        try:
            fn()
        except Exception as ex:  # noqa: BLE001
            fails.append(f"FAIL  {name}  → {type(ex).__name__}: {ex}")
        else:
            print(f"PASS  {name}")
    if fails:
        print()
        for line in fails:
            print(line)
        sys.exit(1)
    print(f"\n[OK] {len(fns)} standalone tests passed (others need pytest).")
    sys.exit(0)

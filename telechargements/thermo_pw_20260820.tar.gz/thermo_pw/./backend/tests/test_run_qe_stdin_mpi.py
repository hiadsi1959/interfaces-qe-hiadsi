"""
Regression: run_qe_stdin(nproc=K) wraps the binary in mpirun -np K when K > 1.

Juillet 2026 (suite au fix dos.x de l utilisateur): les binaires dos.x
et band.x plantent en single-process avec MPI_Init failed /
ofi fi_getinfo() failed sur les noeuds HPC ou le transport libfabric
n est pas routable en mode single-rank. Le fix retenu est d ENVELOPPER
les invocations dans mpirun -np K avec FI_PROVIDER=tcp injecte par
_apply_fi_provider_default. Ce test verrouille la FORME de la commande
construite (pas son execution): il mocke subprocess.run et inspecte
l argument args.

Note pytest: chaque test prend un argument tmp_path OPTIONNEL (None par
defaut) -- la version pytest injecte le fixture, et la version standalone
utilise _make_tmp() en interne (ne depend PAS du runner pytest).
"""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock


_BOOTSTRAP_DIR = os.path.dirname(os.path.abspath(__file__))
_BACKEND_DIR = os.path.abspath(os.path.join(_BOOTSTRAP_DIR, ".."))
if _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)


from qe_subprocess import run_qe_stdin, which_mpirun  # noqa: E402


def _make_tmp():
    """Helper qui retourne un Path ephemere (auto-cleanup si standalone)."""
    return Path(tempfile.mkdtemp(prefix="thermo_qe_stdin_mpi_"))


# ---------------------------------------------------------------------------
# Tests (pytest-discoverable via prefix test_; standalone via _main)
# ---------------------------------------------------------------------------


def test_run_qe_stdin_nproc4_wraps_in_mpirun(tmp_path=None):
    """Invariant 1: run_qe_stdin(..., nproc=4) doit construire [mpirun, -np, 4, exe]."""
    if tmp_path is None:
        tmp_path = _make_tmp()
    inp = tmp_path / "dos.in"
    inp.write_text("&dos\n", encoding="utf-8")
    log = tmp_path / "dos.out"
    fake_exe = Path("/usr/bin/dos.x")
    captured = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        captured["kwargs"] = kwargs
        return MagicMock(returncode=0)

    with patch("qe_subprocess.subprocess.run", side_effect=fake_run):
        run_qe_stdin(
            exe=fake_exe,
            inp=inp,
            work_dir=tmp_path,
            log_file=log,
            nproc=4,
        )

    expected = [which_mpirun(), "-np", "4", str(fake_exe)]
    assert captured.get("cmd") == expected, (
        f"[run_qe_stdin_mpi] nproc=4 doit produire {expected!r}, "
        f"recu {captured.get('cmd')!r}."
    )
    env = captured["kwargs"].get("env", {})
    assert env.get("FI_PROVIDER") in ("tcp", "verbs", "ofi_rxm") or env.get("FI_PROVIDER"), (
        f"[run_qe_stdin_mpi] env transmis doit contenir FI_PROVIDER; "
        f"env = {env!r}."
    )


def test_run_qe_stdin_nproc1_remains_single_process(tmp_path=None):
    """Invariant 2: run_qe_stdin(..., nproc=1) reste single-process."""
    if tmp_path is None:
        tmp_path = _make_tmp()
    inp = tmp_path / "q2r.in"
    inp.write_text("&input\n", encoding="utf-8")
    log = tmp_path / "q2r.out"
    fake_exe = Path("/usr/bin/q2r.x")
    captured = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        return MagicMock(returncode=0)

    with patch("qe_subprocess.subprocess.run", side_effect=fake_run):
        run_qe_stdin(
            exe=fake_exe,
            inp=inp,
            work_dir=tmp_path,
            log_file=log,
            nproc=1,
        )

    assert captured.get("cmd") == [str(fake_exe)], (
        f"[run_qe_stdin_mpi] nproc=1 doit rester single-process [exe], "
        f"recu {captured.get('cmd')!r}."
    )


def test_run_qe_stdin_default_nproc_is_one(tmp_path=None):
    """Invariant 3: sans argument nproc, defaut est 1 (backward compat)."""
    if tmp_path is None:
        tmp_path = _make_tmp()
    inp = tmp_path / "matdyn.in"
    inp.write_text("&input\n", encoding="utf-8")
    log = tmp_path / "matdyn.out"
    fake_exe = Path("/usr/bin/matdyn.x")
    captured = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        return MagicMock(returncode=0)

    with patch("qe_subprocess.subprocess.run", side_effect=fake_run):
        run_qe_stdin(
            exe=fake_exe,
            inp=inp,
            work_dir=tmp_path,
            log_file=log,
        )

    assert captured.get("cmd") == [str(fake_exe)], (
        f"[run_qe_stdin_mpi] default nproc doit etre 1 (single-process), "
        f"recu {captured.get('cmd')!r}."
    )


def test_run_qe_stdin_nproc2_uses_two_ranks(tmp_path=None):
    """Invariant 4: run_qe_stdin(..., nproc=2) doit utiliser -np 2 (cas band.x)."""
    if tmp_path is None:
        tmp_path = _make_tmp()
    inp = tmp_path / "bands.in"
    inp.write_text("&bands\n", encoding="utf-8")
    log = tmp_path / "bands.out"
    fake_exe = Path("/usr/bin/band.x")
    captured = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        return MagicMock(returncode=0)

    with patch("qe_subprocess.subprocess.run", side_effect=fake_run):
        run_qe_stdin(
            exe=fake_exe,
            inp=inp,
            work_dir=tmp_path,
            log_file=log,
            nproc=2,
        )

    expected = [which_mpirun(), "-np", "2", str(fake_exe)]
    assert captured.get("cmd") == expected, (
        f"[run_qe_stdin_mpi] nproc=2 doit produire {expected!r}, "
        f"recu {captured.get('cmd')!r}."
    )


def test_run_qe_stdin_no_mpirun_falls_back_gracefully(tmp_path=None):
    """Invariant 5 (Juillet 2026, fallback gracieux): si mpirun n'est pas
    resolvable (pas dans PATH), run_qe_stdin(nproc > 1) doit retomber sur
    single-process [exe] et apposer une note dans le log_file -- au lieu
    de laisser subprocess.run lever FileNotFoundError."""
    if tmp_path is None:
        tmp_path = _make_tmp()
    inp = tmp_path / "dos.in"
    inp.write_text("&dos\n", encoding="utf-8")
    log = tmp_path / "dos.out"
    fake_exe = Path("/usr/bin/dos.x")
    captured = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        return MagicMock(returncode=0)

    # Force shutil.which(mpirun-path) a None.
    with patch("qe_subprocess.shutil.which", return_value=None), \
         patch("qe_subprocess.subprocess.run", side_effect=fake_run):
        run_qe_stdin(
            exe=fake_exe,
            inp=inp,
            work_dir=tmp_path,
            log_file=log,
            nproc=4,
        )

    assert captured.get("cmd") == [str(fake_exe)], (
        f"[run_qe_stdin_mpi] fallback sans mpirun doit donner [exe], "
        f"recu {captured.get('cmd')!r}."
    )
    # La note dans le log_file doit etre posee.
    log_text = log.read_text(encoding="utf-8")
    assert "mpirun introuvable" in log_text, (
        f"[run_qe_stdin_mpi] log_file doit contenir la note de fallback ; "
        f"contenu = {log_text!r}."
    )


# ---------------------------------------------------------------------------
# Standalone runner
# ---------------------------------------------------------------------------


_TEST_CALLABLES = (
    "test_run_qe_stdin_nproc4_wraps_in_mpirun",
    "test_run_qe_stdin_nproc1_remains_single_process",
    "test_run_qe_stdin_default_nproc_is_one",
    "test_run_qe_stdin_nproc2_uses_two_ranks",
    "test_run_qe_stdin_no_mpirun_falls_back_gracefully",
)


def _main():
    fails = 0
    for n in _TEST_CALLABLES:
        try:
            globals()[n]()
            print(f"[OK]   {n}")
        except AssertionError as e:
            print(f"[FAIL] {n}: {e}")
            fails += 1
        except Exception as e:
            print(f"[ERR]  {n}: {type(e).__name__}: {e}")
            fails += 1
    return 0 if fails == 0 else 1


if __name__ == "__main__":
    sys.exit(_main())

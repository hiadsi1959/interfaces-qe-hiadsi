"""Régression « Annuler ne stoppe pas le calcul » (août 2026).

Symptôme observé : après un clic sur Annuler, le job passait bien à
``cancelled``/``error`` côté UI mais les ``pw.x`` de la grille EOS
continuaient de tourner (orphelins, réparentés sur init) et saturaient la
machine.

Deux causes, testées ici :

1. ``run_pw_x_in`` / ``run_ph_x_in`` / ``run_qe_stdin`` ne recevaient jamais
   ``cancel_event`` : ``run_qe`` prenait donc sa branche NON annulable
   (``subprocess.run``), sans groupe de process ni relecture de l'event.
2. La grille EOS lançait ses volumes dans un ``multiprocessing.Pool`` : un
   ``threading.Event`` n'est pas visible depuis des process fils, et le
   ``terminate()`` du pool tuait le worker en laissant ses rangs MPI vivants.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import work_optimize_eos as weos  # noqa: E402
from qe_subprocess import (  # noqa: E402
    API_CANCEL_RUNTIME_MSG,
    run_pw_x_in,
    terminate_registered_processes,
)
from state_db import WorkflowDB  # noqa: E402


def _new_holder() -> dict:
    return {"lock": threading.Lock(), "active": set()}


def _spawn_long_sleeper() -> subprocess.Popen:
    """Un process dans sa propre session, comme les mpirun lancés par run_qe."""
    return subprocess.Popen(
        [sys.executable, "-c", "import time; time.sleep(120)"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )


class TestTerminateRegisteredProcesses:
    def test_kills_registered_process(self):
        holder = _new_holder()
        proc = _spawn_long_sleeper()
        holder["active"].add(proc)
        try:
            assert proc.poll() is None
            assert terminate_registered_processes(holder) == 1
            assert proc.wait(timeout=10) is not None
        finally:
            if proc.poll() is None:  # filet de sécurité si l'assert casse
                proc.kill()
                proc.wait(timeout=5)

    def test_kills_whole_process_group(self):
        """Les rangs MPI sont des petits-enfants : c'est le groupe qui doit mourir."""
        proc = subprocess.Popen(
            [
                sys.executable,
                "-c",
                (
                    "import subprocess, sys, time;"
                    "c = subprocess.Popen([sys.executable, '-c',"
                    " 'import time; time.sleep(120)']);"
                    "print(c.pid, flush=True);"
                    "time.sleep(120)"
                ),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            start_new_session=True,
        )
        child_pid = int(proc.stdout.readline().strip())
        holder = _new_holder()
        holder["active"].add(proc)
        try:
            terminate_registered_processes(holder)
            proc.wait(timeout=10)
            deadline = time.monotonic() + 10.0
            alive = True
            while time.monotonic() < deadline:
                try:
                    os.kill(child_pid, 0)
                except (ProcessLookupError, PermissionError):
                    alive = False
                    break
                time.sleep(0.1)
            assert not alive, "le petit-fils (rang MPI) a survécu au kill du groupe"
        finally:
            for pid in (proc.pid, child_pid):
                try:
                    os.kill(pid, 9)
                except (ProcessLookupError, PermissionError):
                    pass

    def test_no_holder_is_noop(self):
        assert terminate_registered_processes(None) == 0
        assert terminate_registered_processes({}) == 0


class TestRunPwXInForwardsCancel:
    def test_cancel_event_and_holder_reach_run_qe(self, tmp_path):
        """Le bug initial : ces deux kwargs n'étaient jamais transmis à run_qe."""
        ev = threading.Event()
        holder = _new_holder()
        seen: dict = {}

        def fake_run_qe(args, *, work_dir, log_file, **kw):
            seen.update(kw)
            Path(log_file).write_text("JOB DONE.\n")

        with patch("qe_subprocess.run_qe", side_effect=fake_run_qe):
            with patch("qe_subprocess.which_mpirun", return_value="mpirun"):
                run_pw_x_in(
                    tmp_path, "scf.in", nproc=2,
                    cancel_event=ev, proc_holder=holder,
                )

        assert seen.get("cancel_event") is ev
        assert seen.get("proc_holder") is holder


class TestEosGridIsCancellable:
    """La grille EOS était le point aveugle : 7 pw.x dans un pool de process."""

    @staticmethod
    def _conf(tmp_path: Path, *, sequential: bool) -> weos.EosConfig:
        return weos.EosConfig(
            template_pw=tmp_path / "scf.in",
            n_points=3,
            nproc=1,
            sequential=sequential,
        )

    @staticmethod
    def _jobs(tmp_path: Path, n: int = 3) -> list[tuple[str, str, int]]:
        return [(str(tmp_path), f"scf_vol_{i:02d}.in", 1) for i in range(n)]

    def _db(self, tmp_path: Path) -> WorkflowDB:
        return WorkflowDB(material_id="test", work_dir=str(tmp_path))

    @pytest.mark.parametrize("sequential", [True, False])
    def test_cancel_before_dispatch_raises(self, tmp_path, sequential):
        ev = threading.Event()
        ev.set()
        with patch.object(weos, "run_pw_x_in") as spy:
            with pytest.raises(RuntimeError, match=re.escape(API_CANCEL_RUNTIME_MSG)):
                weos._dispatch_pw_jobs(
                    self._jobs(tmp_path),
                    self._conf(tmp_path, sequential=sequential),
                    self._db(tmp_path),
                    tmp_path,
                    cancel_event=ev,
                )
        spy.assert_not_called()

    def test_cancel_mid_flight_stops_parallel_grid(self, tmp_path):
        """Annulation pendant les SCF : tous les pw.x rendent la main vite."""
        ev = threading.Event()
        started = threading.Semaphore(0)

        def fake_pw(work_dir, in_name, nproc=None, *, cancel_event=None,
                    proc_holder=None):
            started.release()
            # Un vrai pw.x est tué par _wait_mpi_process quand l'event tombe ;
            # on simule ce comportement (l'event DOIT être visible ici).
            assert cancel_event is not None
            if cancel_event.wait(timeout=15):
                raise RuntimeError(API_CANCEL_RUNTIME_MSG)
            pytest.fail("cancel_event jamais vu par la tâche pw.x")

        with patch.object(weos, "run_pw_x_in", side_effect=fake_pw):
            done = threading.Event()
            err: list[BaseException] = []

            def runner():
                try:
                    weos._dispatch_pw_jobs(
                        self._jobs(tmp_path),
                        self._conf(tmp_path, sequential=False),
                        self._db(tmp_path),
                        tmp_path,
                        cancel_event=ev,
                    )
                except BaseException as ex:  # noqa: BLE001
                    err.append(ex)
                finally:
                    done.set()

            th = threading.Thread(target=runner, daemon=True)
            th.start()
            assert started.acquire(timeout=10), "aucun pw.x démarré"
            ev.set()
            assert done.wait(timeout=20), "la grille EOS n'a pas rendu la main"

        assert err and API_CANCEL_RUNTIME_MSG in str(err[0])

    def test_failure_kills_remaining_processes(self, tmp_path):
        """Un volume qui échoue ne doit pas laisser les autres pw.x orphelins."""
        holder = _new_holder()
        killed: list[dict] = []

        def fake_pw(work_dir, in_name, nproc=None, *, cancel_event=None,
                    proc_holder=None):
            raise ValueError("SCF divergent")

        with patch.object(weos, "run_pw_x_in", side_effect=fake_pw):
            with patch.object(
                weos, "terminate_registered_processes",
                side_effect=lambda h, **kw: killed.append(h) or 0,
            ):
                with pytest.raises(ValueError, match="SCF divergent"):
                    weos._dispatch_pw_jobs(
                        self._jobs(tmp_path),
                        self._conf(tmp_path, sequential=False),
                        self._db(tmp_path),
                        tmp_path,
                        proc_holder=holder,
                    )

        assert killed == [holder]

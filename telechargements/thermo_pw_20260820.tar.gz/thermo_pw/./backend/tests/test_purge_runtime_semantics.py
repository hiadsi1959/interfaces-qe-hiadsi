"""Behavioral mock-based lockstep — purge destructive vs non-destructive."""
from __future__ import annotations

import json
import os
import sys
from unittest.mock import patch

import pytest

_BOOTSTRAP_DIR = os.path.dirname(os.path.abspath(__file__))
_BACKEND_DIR = os.path.abspath(os.path.join(_BOOTSTRAP_DIR, ".."))
if _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)

import api_server  # noqa: E402
from pipeline import (  # noqa: E402
    cfg,
    PipelineJob,
    purge_failed_pipeline_runs,
)


def _make_fake_ko_marker(
    tmp_path,
    *,
    material_id: str = "TestMat",
    job_id: str = "TEST_JOB_999",
    status: str = "error",
):
    wd = tmp_path / material_id / f"pipeline_{job_id}"
    wd.mkdir(parents=True, exist_ok=True)
    marker = wd / PipelineJob._MARKER_FILENAME
    marker.write_text(
        json.dumps(
            {
                "job_id": job_id,
                "status": status,
                "work_dir": str(wd),
                "material_id": material_id,
                "profile_id": "P1",
            }
        ),
        encoding="utf-8",
    )
    return wd


def _reset_pipeline_state() -> None:
    PipelineJob._REGISTRY.clear()


@pytest.fixture
def isolated_work_root(tmp_path, monkeypatch):
    monkeypatch.setattr(cfg, "WORK_ROOT", tmp_path, raising=True)
    with PipelineJob._REGISTRY_LOCK:
        PipelineJob._REGISTRY.clear()
    return tmp_path


def test_purge_failed_pipeline_runs_calls_shutil_rmtree(isolated_work_root) -> None:
    _reset_pipeline_state()
    fake_wd = _make_fake_ko_marker(
        isolated_work_root,
        material_id="DummyMat",
        job_id="DUMMY_RMTREE_001",
        status="error",
    )
    with patch("pipeline.shutil.rmtree") as mock_rmtree:
        purge_failed_pipeline_runs(dry_run=False, material_id="DummyMat")
    assert mock_rmtree.called
    called_args = [c.args for c in mock_rmtree.call_args_list]
    assert any(str(args[0]) == str(fake_wd) for args in called_args)


def test_purge_failed_pipeline_runs_dry_run_does_NOT_call_shutil_rmtree(isolated_work_root) -> None:
    _reset_pipeline_state()
    _make_fake_ko_marker(
        isolated_work_root,
        material_id="PreviewMat",
        job_id="PREVIEW_NO_RMTREE",
        status="error",
    )
    with patch("pipeline.shutil.rmtree") as mock_rmtree:
        report = purge_failed_pipeline_runs(dry_run=True, material_id="PreviewMat")
    assert not mock_rmtree.called
    assert isinstance(report, dict)


def test_purge_stale_pipeline_runs_does_NOT_call_shutil_rmtree(isolated_work_root) -> None:
    if not api_server.PIPELINE_AVAILABLE:
        pytest.skip("Pipeline blueprint indisponible")
    _reset_pipeline_state()
    client = api_server.app.test_client()
    with patch("pipeline.shutil.rmtree") as mock_rmtree:
        r = client.post(
            "/api/pipeline/runs/purge_stale",
            json={"dry_run": True},
        )
    assert r.status_code == 200
    assert not mock_rmtree.called

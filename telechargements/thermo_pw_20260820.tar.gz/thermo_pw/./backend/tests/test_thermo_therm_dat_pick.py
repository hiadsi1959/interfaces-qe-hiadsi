"""Regression: ne pas confondre output_therm.dat_debye.g1.dw avec le fichier Cv/F/S."""
from pathlib import Path

from parsers.thermo_therm_dat import find_therm_dat_files, parse_therm_dat, pick_central_geometry


def test_pick_central_skips_dw_suffix(tmp_path: Path):
    therm = tmp_path / "therm_files"
    therm.mkdir()
    good = therm / "output_therm.dat_debye.g1"
    good.write_text(
        "#    T        energy      free energy     entropy         Cv\n"
        "  300.0  1.0  0.9  0.001  0.00003\n",
        encoding="utf-8",
    )
    bad = therm / "output_therm.dat_debye.g1.dw"
    bad.write_text("#      T              B_33\n  300.0  0.16\n", encoding="utf-8")
    paths = find_therm_dat_files(tmp_path)
    picked = pick_central_geometry(paths)
    assert picked is not None
    assert picked.name == "output_therm.dat_debye.g1"
    out = parse_therm_dat(tmp_path)
    assert out.get("Cv_300K_Ry_per_K") == 3e-05

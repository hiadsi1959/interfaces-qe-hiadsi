"""Tests unitaires pour ``backend.ps_to_pdf`` (convertisseur PostScript -> PDF).

Strategy:
- Mock ``shutil.which`` for ``_has_ghostscript`` so tests are hermetic and
  don't depend on the host Ghostscript version (or absence).
- Mock ``subprocess.run`` for ``_convert_one`` to verify command shape and
  error handling without spawning real ``gs``.
- Real tmp_path for ``_iter_ps_files`` and ``convert_postscript_to_pdf``
  integration to verify filesystem behaviour (symlinks filtered, max_depth
  respected, idempotency on re-call).

Tous les tests ciblent le comportement public + les helpers privés (avec
leading underscore). Les helpers privés sont volontairement retestes pour
figer le contrat : si la signature evolue, les tests cassent et forcent
la mise a jour doc.
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

import ps_to_pdf as ppdf


# ------------------------------------------------------------ fixtures


@pytest.fixture
def fixture_work_dir_with_ps(tmp_path: Path) -> Path:
    """Cree un work_dir avec 3 .ps + 1 sous-dossier contenant 2 .ps + 1 symlink."""
    root = tmp_path / "run"
    sub = root / "1_eos_volumes"
    root.mkdir()
    sub.mkdir()
    (root / "output_therm_debye.g1.ps").write_bytes(b"%!PS\nshowpage\n")
    (root / "legacy_plot.ps").write_bytes(b"%!PS\nshowpage\n")
    (sub / "eos_fit.ps").write_bytes(b"%!PS\nshowpage\n")
    (sub / "another.ps").write_bytes(b"%!PS\nshowpage\n")
    # Symlink (doit etre ignore car on ne suit pas les liens).
    try:
        (root / "escape.ps").symlink_to("/etc/passwd")
    except (OSError, NotImplementedError):
        pass
    return root


# ------------------------------------------------------------ _has_ghostscript


def test_has_ghostscript_true_when_gs_in_path() -> None:
    with patch("ps_to_pdf.shutil.which", return_value="/usr/bin/gs"):
        assert ppdf._has_ghostscript() is True


def test_has_ghostscript_false_when_missing() -> None:
    with patch("ps_to_pdf.shutil.which", return_value=None):
        assert ppdf._has_ghostscript() is False


def test_has_ghostscript_returns_false_on_which_exception() -> None:
    # shutil.which peut lever dans de rares cas (PATH corrompu) : on
    # downgrade en False au lieu de planter.
    with patch(
        "ps_to_pdf.shutil.which", side_effect=RuntimeError("PATH broken")
    ):
        assert ppdf._has_ghostscript() is False


# ------------------------------------------------------------ _iter_ps_files


def test_iter_ps_files_finds_all_top_level_and_one_subdir(
    fixture_work_dir_with_ps: Path,
) -> None:
    """Defaut max_depth=2 inclut racine + 1 sous-dossier."""
    found = [p.name for p in ppdf._iter_ps_files(fixture_work_dir_with_ps)]
    assert "output_therm_debye.g1.ps" in found
    assert "legacy_plot.ps" in found
    assert "eos_fit.ps" in found
    assert "another.ps" in found
    # 4 .ps reels (le symlink est filtre).
    assert len(found) == 4


def test_iter_ps_files_skips_symlinks(
    fixture_work_dir_with_ps: Path,
) -> None:
    """Le symlink ``escape.ps -> /etc/passwd`` ne doit pas apparaitre."""
    found = [p.name for p in ppdf._iter_ps_files(fixture_work_dir_with_ps)]
    assert "escape.ps" not in found


def test_iter_ps_files_limit_depth(
    fixture_work_dir_with_ps: Path,
) -> None:
    """max_depth=1 scanne racine + 1 sous-dossier (fichiers du sous-dossier inclus).

    Le contrat de _iter_ps_files est : ``max_depth=N`` autorise la recursion
    jusqu'a N SOUS-NIVEAUX sous work_dir (root = profondeur 0). Avec N=1, on
    inclut racine (prof. 0) ET le sous-dossier ``1_eos_volumes`` (prof. 1).
    Les fichiers au-dela (prof. 2) sont filtres.
    """
    found = [p.name for p in ppdf._iter_ps_files(
        fixture_work_dir_with_ps, max_depth=1
    )]
    # Profondeur 0 (racine) OK.
    assert "output_therm_debye.g1.ps" in found
    assert "legacy_plot.ps" in found
    # Profondeur 1 (sous-dossier) OK avec max_depth=1.
    assert "eos_fit.ps" in found
    assert "another.ps" in found
    # Symlink toujours filtre.
    assert "escape.ps" not in found


def test_iter_ps_files_returns_empty_if_dir_missing(tmp_path: Path) -> None:
    assert ppdf._iter_ps_files(tmp_path / "nope") == []


def test_iter_ps_files_sorted_dedup(
    fixture_work_dir_with_ps: Path,
) -> None:
    """La liste retournee est triee et dedoublonnee."""
    found = ppdf._iter_ps_files(fixture_work_dir_with_ps)
    assert found == sorted(found)
    assert len(found) == len(set(found))


# ------------------------------------------------------------ _convert_one


def test_convert_one_happy_path_writes_pdf(tmp_path: Path) -> None:
    """Mock gs qui simule l'ecriture d'un PDF non vide."""
    ps = tmp_path / "demo.ps"
    ps.write_bytes(b"%!PS\nshowpage\n")
    expected_pdf = tmp_path / "demo.pdf"
    # Simule gs qui cree un PDF de 1024 octets.
    expected_pdf.write_bytes(b"x" * 1024)

    def fake_gs(argv, **kwargs):
        # Verifie la command shape.
        assert argv[0] == "gs"
        assert "-dNOPAUSE" in argv and "-dBATCH" in argv
        assert any(a.startswith("-sOutputFile=") for a in argv)
        assert argv[-1] == str(ps)  # dernier arg = input
        return subprocess.CompletedProcess(args=argv, returncode=0, stdout="", stderr="")

    with patch("ps_to_pdf.subprocess.run", side_effect=fake_gs):
        out_pdf, ok, err = ppdf._convert_one(ps)

    assert ok is True
    assert err == ""
    assert out_pdf == expected_pdf
    assert expected_pdf.is_file()  # verifie que le write a bien eu lieu


def test_convert_one_nonzero_exit_returns_error(tmp_path: Path) -> None:
    """gs renvoie un error code -> ok=False avec stderr dans 'err'."""
    ps = tmp_path / "bad.ps"
    ps.write_bytes(b"%!PS\nbroken\n")
    fake_cp = subprocess.CompletedProcess(
        args=[], returncode=1, stdout="", stderr="Error: undefined\n"
    )
    with patch("ps_to_pdf.subprocess.run", return_value=fake_cp):
        out_pdf, ok, err = ppdf._convert_one(ps)
    assert ok is False
    assert "code=1" in err
    assert out_pdf == ps.with_suffix(".pdf")


def test_convert_one_timeout_returns_error(tmp_path: Path) -> None:
    """TimeoutExpired -> ok=False avec message clair."""
    ps = tmp_path / "huge.ps"
    ps.write_bytes(b"%!PS\n")
    with patch(
        "ps_to_pdf.subprocess.run",
        side_effect=subprocess.TimeoutExpired(cmd="gs", timeout=30),
    ):
        out_pdf, ok, err = ppdf._convert_one(ps)
    assert ok is False
    assert "Timeout" in err or "timeout" in err


def test_convert_one_missing_gs_executable(tmp_path: Path) -> None:
    """gs introuvable sur le PATH -> ok=False avec message ciblable."""
    ps = tmp_path / "x.ps"
    ps.write_bytes(b"%!PS\n")
    with patch(
        "ps_to_pdf.subprocess.run",
        side_effect=FileNotFoundError("[Errno 2] No such file or directory: 'gs'"),
    ):
        out_pdf, ok, err = ppdf._convert_one(ps)
    assert ok is False
    assert "gs" in err.lower()


def test_convert_one_empty_output_pdf(tmp_path: Path) -> None:
    """gs exit 0 mais aucun PDF ecrit (rare) -> ok=False."""
    ps = tmp_path / "y.ps"
    ps.write_bytes(b"%!PS\n")
    with patch(
        "ps_to_pdf.subprocess.run",
        return_value=subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr=""),
    ):
        out_pdf, ok, err = ppdf._convert_one(ps)
    assert ok is False
    assert "non vide" in err or "n'a" in err or "introuvable" in err or "existe" in err


# ------------------------------------------------------------ convert_postscript_to_pdf


def test_convert_postscript_to_pdf_skips_when_gs_missing(
    fixture_work_dir_with_ps: Path,
) -> None:
    """gs absent : retourne la liste des .ps avec ok=False et un message
    d'erreur uniforme."""
    with patch("ps_to_pdf.shutil.which", return_value=None):
        results = ppdf.convert_postscript_to_pdf(fixture_work_dir_with_ps)
    assert len(results) == 4
    for _ps, _pdf, ok, err in results:
        assert ok is False
        assert "gs" in err.lower()


def test_convert_postscript_to_pdf_happy_path(
    fixture_work_dir_with_ps: Path,
) -> None:
    """Avec gs dispo, tous les .ps -> .pdf en un seul appel."""
    with patch("ps_to_pdf.shutil.which", return_value="/usr/bin/gs"):

        def fake_gs(argv, **kwargs):
            out_arg = next(a for a in argv if a.startswith("-sOutputFile="))
            pdf_path = Path(out_arg.split("=", 1)[1])
            pdf_path.write_bytes(b"%PDF-1.4\n%%EOF\n")
            return subprocess.CompletedProcess(
                args=argv, returncode=0, stdout="", stderr=""
            )

        with patch("ps_to_pdf.subprocess.run", side_effect=fake_gs):
            results = ppdf.convert_postscript_to_pdf(fixture_work_dir_with_ps)

    # Tous les .ps sont marques ok.
    assert len(results) == 4
    for _ps, pdf_path, ok, err in results:
        assert ok is True
        assert err == ""
        assert pdf_path.is_file()
        assert pdf_path.stat().st_size > 0


def test_convert_postscript_to_pdf_idempotent(
    fixture_work_dir_with_ps: Path,
) -> None:
    """Un second appel alors que les PDF sont frais doit etre no-op."""
    # Premier appel : cree les PDF.
    with patch("ps_to_pdf.shutil.which", return_value="/usr/bin/gs"):

        def fake_gs(argv, **kwargs):
            out_arg = next(a for a in argv if a.startswith("-sOutputFile="))
            Path(out_arg.split("=", 1)[1]).write_bytes(b"%PDF-1.4\n")
            return subprocess.CompletedProcess(
                args=argv, returncode=0, stdout="", stderr=""
            )

        with patch("ps_to_pdf.subprocess.run", side_effect=fake_gs):
            first = ppdf.convert_postscript_to_pdf(fixture_work_dir_with_ps)
            subprocess_call_count_after_first = 4  # 4 appels gs (1 par .ps).

            # Second appel : 0 nouveaux gs invoque, ok=True partout.
            with patch(
                "ps_to_pdf.subprocess.run",
                side_effect=AssertionError("gs ne doit PAS etre re-invoque"),
            ) as spy_run:
                second = ppdf.convert_postscript_to_pdf(fixture_work_dir_with_ps)

    assert len(first) == len(second) == 4
    for _ps, _pdf, ok, err in second:
        assert ok is True
        assert err == ""


def test_convert_postscript_to_pdf_force_reconverts(
    fixture_work_dir_with_ps: Path,
) -> None:
    """force=True re-invoque gs meme quand le PDF est deja frais."""
    invocations: list[int] = []

    def fake_gs(argv, **kwargs):
        invocations.append(1)
        out_arg = next(a for a in argv if a.startswith("-sOutputFile="))
        Path(out_arg.split("=", 1)[1]).write_bytes(b"%PDF-1.4\n")
        return subprocess.CompletedProcess(args=argv, returncode=0, stdout="", stderr="")

    with patch("ps_to_pdf.shutil.which", return_value="/usr/bin/gs"), \
         patch("ps_to_pdf.subprocess.run", side_effect=fake_gs):
        ppdf.convert_postscript_to_pdf(fixture_work_dir_with_ps)
        ppdf.convert_postscript_to_pdf(fixture_work_dir_with_ps, force=True)

    # Premier appel : 4 gs. Second (force=True) : 4 gs supplementaires.
    # Attention : le mtime des PDF (.write_bytes) peut etre identique ou
    # anterieur au mtime des PS selon la resolution du filesystem, on
    # force donc pour etre sur de l'invocation.
    assert len(invocations) == 8


def test_convert_postscript_to_pdf_missing_workdir(tmp_path: Path) -> None:
    """work_dir inexistant -> liste vide (pas de crash)."""
    out = ppdf.convert_postscript_to_pdf(tmp_path / "does_not_exist")
    assert out == []


def test_convert_postscript_to_pdf_empty_workdir(tmp_path: Path) -> None:
    """work_dir vide -> liste vide."""
    nd = tmp_path / "empty"
    nd.mkdir()
    out = ppdf.convert_postscript_to_pdf(nd)
    assert out == []


def test_convert_postscript_to_pdf_returns_pdf_target_path(
    fixture_work_dir_with_ps: Path,
) -> None:
    """Chaque tuple retourne (ps_path, pdf_path) ; pdf_path = ps.with_suffix('.pdf')."""
    with patch("ps_to_pdf.shutil.which", return_value=None):
        results = ppdf.convert_postscript_to_pdf(fixture_work_dir_with_ps)
    for ps_p, pdf_p, _ok, _err in results:
        assert pdf_p == ps_p.with_suffix(".pdf")
        assert pdf_p.suffix == ".pdf"


# ------------------------------------------------------------ Test the wire into api_server.py /factsheet_skipped when ps_to_pdf raises


def test_api_pipeline_runs_files_route_handles_ps_conversion_failure(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Verifie que /files ne 500 pas si ps_to_pdf leve (defensive try/except).

    Patch ciblable : la route fait ``from ps_to_pdf import
    convert_postscript_to_pdf`` AU SEIN du bloc try, donc on patche
    l'attribut SUR LE MODULE ``ps_to_pdf`` (pas sur ``api_server``).
    Le monkeypatch sur api_server.convert_postscript_to_pdf ne toucherait
    jamais le code rellement execute (l'import local re-resoud dans
    ps_to_pdf a chaque appel).
    """
    import importlib
    import config as cfg
    monkeypatch.setattr(cfg, "WORK_ROOT", tmp_path / "work", raising=True)
    (tmp_path / "work").mkdir()
    import uuid, time
    job_id = uuid.uuid4().hex[:12]
    run = tmp_path / "work" / "Si" / f"pipeline_P1_{int(time.time())}_{uuid.uuid4().hex[:6]}"
    run.mkdir(parents=True)
    (run / "pipeline_api_job_state.json").write_text(
        json.dumps({"job_id": job_id, "status": "done", "results": {}})
    )
    (run / "demo.ps").write_bytes(b"%!PS\n")

    import ps_to_pdf as ppdf_mod
    import api_server

    def boom(*_a, **_k):
        raise RuntimeError("intentional boom from test")

    monkeypatch.setattr(ppdf_mod, "convert_postscript_to_pdf", boom)

    with api_server.app.test_client() as client:
        resp = client.get(f"/api/pipeline/runs/{job_id}/files")
        # Le try/except avale l'exception: /files renvoie 200 malgre le crash.
        assert resp.status_code == 200, resp.data.decode("utf-8", errors="replace")
        body = json.loads(resp.data)
        # demo.ps n'a pas ete converti (boom leve) -> range dans le kind "ps"
        # (ajoute au kind_map de factsheet._section_artifacts) ; il reste visible
        # dans le panneau artefacts (la conversion automatique aurait sinon cree
        # un sibling .pdf que les deux PS+PDF apparaîtraient ensemble).
        assert "ps" in body["kinds"]
        assert any(p.endswith("demo.ps") for p in body["kinds"]["ps"])


# ------------------------------------------------------------ .eps (Encapsulated PostScript) — juillet 2026


@pytest.fixture
def fixture_work_dir_with_ps_and_eps(tmp_path: Path) -> Path:
    """Work_dir mixte : 2 .ps + 3 .eps (racine + sous-dossier). Permet de
    verifier que _iter_ps_files / convert_postscript_to_pdf traitent les
    deux dialectes PostScript de maniere uniforme.
    """
    root = tmp_path / "run_mixed"
    sub = root / "1_eos_volumes"
    root.mkdir()
    sub.mkdir()
    (root / "legacy_plot.ps").write_bytes(b"%!PS\nshowpage\n")
    (root / "fig1.eps").write_bytes(b"%!PS-Adobe-3.0 EPSF-3.0\n%%BoundingBox: 0 0 100 100\n")
    (sub / "fig2.eps").write_bytes(b"%!PS-Adobe-3.0 EPSF-3.0\n%%BoundingBox: 0 0 50 50\n")
    (sub / "fig3.eps").write_bytes(b"%!PS-Adobe-3.0 EPSF-3.0\n%%BoundingBox: 0 0 75 75\n")
    (root / "another.ps").write_bytes(b"%!PS\nshowpage\n")
    # Un fichier non-PS (sanity check : pas confondu avec .eps).
    (root / "data.dat").write_text("ignored\n")
    return root


def test_iter_ps_files_includes_eps(
    fixture_work_dir_with_ps_and_eps: Path,
) -> None:
    """Les ``.eps`` (Encapsulated PostScript) sont detectes en plus des ``.ps``.

    Defaut max_depth=2 inclut racine + sous-dossier direct.
    """
    found = {p.name for p in ppdf._iter_ps_files(fixture_work_dir_with_ps_and_eps)}
    # 2 .ps + 3 .eps = 5 fichiers PostScript.
    assert "legacy_plot.ps" in found
    assert "another.ps" in found
    assert "fig1.eps" in found
    assert "fig2.eps" in found
    assert "fig3.eps" in found
    assert len(found) == 5
    # Les .dat NE sont PAS ramasses (filtre strict PostScript).
    assert "data.dat" not in found


def test_convert_postscript_to_pdf_converts_eps(
    fixture_work_dir_with_ps_and_eps: Path,
) -> None:
    """``gs -sDEVICE=pdfwrite`` gere les .eps nativement : chaque .eps doit
    etre converti en .pdf sibling, et la liste retournee doit contenir 5
    tuples (ps_path, pdf_path, ok, err) avec ok=True partout.
    """
    with patch("ps_to_pdf.shutil.which", return_value="/usr/bin/gs"):

        def fake_gs(argv, **kwargs):
            out_arg = next(a for a in argv if a.startswith("-sOutputFile="))
            pdf_path = Path(out_arg.split("=", 1)[1])
            pdf_path.write_bytes(b"%PDF-1.4\n%%EOF\n")
            return subprocess.CompletedProcess(
                args=argv, returncode=0, stdout="", stderr=""
            )

        with patch("ps_to_pdf.subprocess.run", side_effect=fake_gs):
            results = ppdf.convert_postscript_to_pdf(fixture_work_dir_with_ps_and_eps)

    assert len(results) == 5
    for ps_p, pdf_p, ok, err in results:
        assert ok is True
        assert err == ""
        # Pour un .eps en entree, le PDF sibling a la meme racine (.pdf suffix).
        assert pdf_p == ps_p.with_suffix(".pdf")
        assert pdf_p.suffix == ".pdf"
        assert pdf_p.is_file()
    # Les .ps ET .eps ont bien ete convertis.
    suffixes = {p.suffix.lower() for p, _, _, _ in results}
    assert suffixes == {".ps", ".eps"}


def test_convert_postscript_to_pdf_eps_idempotent(
    fixture_work_dir_with_ps_and_eps: Path,
) -> None:
    """Second appel sur .eps frais : pas de re-invocation gs.

    Couvre le cas mixte (.ps + .eps) pour confirmer que le check d'idempotence
    base sur le mtime s'applique aux deux dialectes de la meme maniere.
    """
    call_count: list[int] = []

    def fake_gs(argv, **kwargs):
        call_count.append(1)
        out_arg = next(a for a in argv if a.startswith("-sOutputFile="))
        Path(out_arg.split("=", 1)[1]).write_bytes(b"%PDF-1.4\n")
        return subprocess.CompletedProcess(args=argv, returncode=0, stdout="", stderr="")

    with patch("ps_to_pdf.shutil.which", return_value="/usr/bin/gs"), \
         patch("ps_to_pdf.subprocess.run", side_effect=fake_gs):
        first = ppdf.convert_postscript_to_pdf(fixture_work_dir_with_ps_and_eps)
        second = ppdf.convert_postscript_to_pdf(fixture_work_dir_with_ps_and_eps)

    # Premier appel : 5 gs (2 .ps + 3 .eps). Second appel : 0 (idempotence).
    assert len(call_count) == 5
    assert len(first) == len(second) == 5
    for _ps, _pdf, ok, err in second:
        assert ok is True
        assert err == ""


def test_section_artifacts_classifies_eps_as_ps_kind(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Le ``kind_map`` de ``factsheet._section_artifacts`` doit classifier
    ``.eps`` dans le bucket ``"ps"`` (meme politique que ``.ps``) pour que
    l'UI affiche les fichiers .eps et .ps ensemble dans le panneau Artefacts.
    """
    import config as cfg
    monkeypatch.setattr(cfg, "WORK_ROOT", tmp_path / "work", raising=True)
    (tmp_path / "work").mkdir()
    import uuid, time
    job_id = uuid.uuid4().hex[:12]
    run = tmp_path / "work" / "Si" / f"pipeline_P1_{int(time.time())}_{uuid.uuid4().hex[:6]}"
    run.mkdir(parents=True)
    (run / "pipeline_api_job_state.json").write_text(
        json.dumps({"job_id": job_id, "status": "done", "results": {}})
    )
    # Pas de conversion auto : on veut voir le .eps range en "ps".
    (run / "demo.eps").write_bytes(b"%!PS-Adobe-3.0 EPSF-3.0\n%%BoundingBox: 0 0 10 10\n")
    (run / "demo.ps").write_bytes(b"%!PS\nshowpage\n")

    import factsheet
    rows = factsheet._section_artifacts({}, run)
    by_kind: dict[str, list[str]] = {}
    for _basename, _rel, kind in rows:
        by_kind.setdefault(kind, []).append(_basename)
    # Les 2 fichiers (demo.ps ET demo.eps) sont dans le bucket "ps".
    # On utilise un set pour rester robuste a l'ordre de tri (depend du sort
    # key ``(kind_order, relpath)`` — stable aujourd'hui mais pas un contrat
    # public).
    assert "ps" in by_kind
    assert set(by_kind["ps"]) == {"demo.eps", "demo.ps"}

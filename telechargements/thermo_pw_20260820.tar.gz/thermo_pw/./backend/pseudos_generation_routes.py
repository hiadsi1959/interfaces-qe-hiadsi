"""
Routes HTTP pour APE et ATOMPAW sous /api/pseudos/* — même contrat JSON que
generation_pseudos/api_pseudos_standalone.py, mais découplées du dépôt thermo_pw :

- Racine générateur : THERMO_GENERATION_PSEUDOS_DIR (cfg.GENERATION_PSEUDOS_DIR).
- Copie des .UPF après succès : THERMO_PSEUDO_GEN_OUTPUT_DIR, ou api_config.json
  « pseudo_gen_output_dir », ou défaut « …/generated_upf » sous la racine générateur
  (pas THERMO_PSEUDOS_DIR).
- Runs locaux : THERMO_PSEUDO_GEN_WORK_ROOT ou défaut « …/_work » sous le générateur
  (pas THERMO_WORK_ROOT).

Surcharge par requête : POST run_* peut inclure « output_dir » ou « copy_upf_to » (chemin absolu).
La biblio QE (THERMO_PSEUDOS_DIR) reste pour pw.x ; elle est exposée à part dans GET …/generator_paths.
"""

from __future__ import annotations

import glob
import importlib.util
import json
import os
import re
import tempfile
from datetime import datetime
import shutil
import subprocess
from pathlib import Path
from typing import Any

from flask import Flask, Response, jsonify, request

import config as cfg

_ATOMPAW_INPUT_NAME = "atompaw.in"
_MAX_LOCAL_INPUT_SAVE_BYTES = 2_097_152  # 2 MiB — même ordre de grandeur qu’un .in
_pseudo_auto_mod: Any = None


def _user_state_root() -> Path:
    """Racine de repli toujours inscriptible : $HOME/.thermo_pw/pseudo_generation."""
    return (Path.home() / ".thermo_pw" / "pseudo_generation").resolve()


def _tmp_state_root() -> Path:
    """Repli ultime : système temporaire."""
    return (Path(tempfile.gettempdir()) / "thermo_pw_pseudo_generation").resolve()


def _ensure_writable(p: Path) -> bool:
    """Crée p si possible et vérifie qu’on peut y écrire un fichier temporaire."""
    try:
        p.mkdir(parents=True, exist_ok=True)
        probe = p / ".tpw_write_probe"
        probe.write_text("1", encoding="ascii")
        probe.unlink(missing_ok=True)
        return True
    except OSError:
        return False


def _first_writable(candidates: list[Path]) -> tuple[Path, str]:
    """Retourne le premier chemin réellement inscriptible, avec un avertissement si on a dévié du préféré."""
    first = candidates[0]
    for i, c in enumerate(candidates):
        if _ensure_writable(c):
            if i == 0:
                return c.resolve(), ""
            return c.resolve(), (
                f"Le chemin préféré {first} n’est pas inscriptible — repli automatique sur {c}. "
                "Corrigez les droits ou définissez THERMO_GENERATION_PSEUDOS_DIR / "
                "THERMO_PSEUDO_GEN_WORK_ROOT / THERMO_PSEUDO_GEN_OUTPUT_DIR."
            )
    raise OSError(f"Aucun des dossiers candidats n’est inscriptible : {candidates}")


def _generation_root() -> Path:
    return cfg.GENERATION_PSEUDOS_DIR.resolve()


def _optional_json_config() -> dict[str, Any]:
    p = _generation_root() / "api_config.json"
    if not p.is_file():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _cfg_str(key: str) -> str:
    v = _optional_json_config().get(key)
    return v.strip() if isinstance(v, str) else ""


def _env_str(name: str) -> str:
    v = os.environ.get(name, "")
    return v.strip() if isinstance(v, str) else ""


def _load_pseudo_auto_inputs():
    global _pseudo_auto_mod
    if _pseudo_auto_mod is not None:
        return _pseudo_auto_mod
    p = _generation_root() / "pseudo_auto_inputs.py"
    if not p.is_file():
        return None
    spec = importlib.util.spec_from_file_location("thermo_pw_pseudo_auto_inputs", p)
    if spec is None or spec.loader is None:
        return None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    _pseudo_auto_mod = mod
    return mod


_BUNDLED_PSEUDO_TEMPLATES = Path(__file__).resolve().parent / "pseudo_generator_templates"


def _pseudo_templates_dir() -> Path:
    """Répertoire attendu côté utilisateur (GENERATION_PSEUDOS_DIR/templates/)."""
    return _generation_root() / "templates"


def _pseudo_template_file(fname: str) -> Path | None:
    """Modèle APE/ATOMPAW : préfère l’installation externe, puis le bundle sous backend/."""
    ext = _generation_root() / "templates" / fname
    if ext.is_file():
        return ext
    bundled = _BUNDLED_PSEUDO_TEMPLATES / fname
    if bundled.is_file():
        return bundled
    return None


def _pseudo_local_inputs_dir(generator: str) -> tuple[Path, str]:
    """pseudo_generator_templates/{ape,atompaw}/ — résilient : repli ~/.thermo_pw puis /tmp."""
    g = (generator or "").strip().lower()
    sub = "ape" if g == "ape" else "atompaw"
    return _first_writable([
        (_generation_root() / "pseudo_generator_templates" / sub).resolve(),
        (_user_state_root() / "pseudo_generator_templates" / sub).resolve(),
        (_tmp_state_root() / "pseudo_generator_templates" / sub).resolve(),
    ])


def _resolve_ape_bin() -> Path | None:
    v = _env_str("APE_BIN") or _cfg_str("ape_bin")
    if v:
        p = Path(v).expanduser().resolve()
        if p.is_file():
            return p
    root = _generation_root()
    for cand in (
        root / "bin" / "ape",
        root / "third_party" / "ape" / "bin" / "ape",
    ):
        if cand.is_file():
            return cand.resolve()
    w = shutil.which("ape")
    return Path(w).resolve() if w else None


def _resolve_atompaw_bin() -> Path | None:
    v = _env_str("ATOMPAW_BIN") or _cfg_str("atompaw_bin")
    if v:
        p = Path(v).expanduser().resolve()
        if p.is_file():
            return p
    root = _generation_root()
    for cand in (
        root / "bin" / "atompaw",
        root / "third_party" / "atompaw" / "bin" / "atompaw",
        root / "third_party" / "atompaw" / "bin" / "AtomPAW",
        root / "third_party" / "atompaw" / "bin" / "atompaw.x",
    ):
        if cand.is_file():
            return cand.resolve()
    for name in ("atompaw", "AtomPAW", "atompaw.x"):
        w = shutil.which(name)
        if w:
            return Path(w).resolve()
    return None


def _pseudo_gen_output_dir() -> Path:
    """Dossier des .UPF générés (« pseudos_generes ») — résilient."""
    candidates: list[Path] = []
    if _env_str("THERMO_PSEUDO_GEN_OUTPUT_DIR"):
        candidates.append(Path(_env_str("THERMO_PSEUDO_GEN_OUTPUT_DIR")).expanduser().resolve())
    jc = _cfg_str("pseudo_gen_output_dir")
    if jc:
        candidates.append(Path(jc).expanduser().resolve())
    candidates.append(Path(cfg.PSEUDO_GEN_OUTPUT_DIR).resolve())
    candidates.append((_user_state_root() / "pseudos_generes").resolve())
    candidates.append((_tmp_state_root() / "pseudos_generes").resolve())
    p, _ = _first_writable(candidates)
    return p


def _pseudo_gen_work_root() -> Path:
    """Dossier travail (« _work ») — résilient."""
    candidates: list[Path] = []
    if _env_str("THERMO_PSEUDO_GEN_WORK_ROOT"):
        candidates.append(Path(_env_str("THERMO_PSEUDO_GEN_WORK_ROOT")).expanduser().resolve())
    jc = _cfg_str("pseudo_gen_work_root")
    if jc:
        candidates.append(Path(jc).expanduser().resolve())
    candidates.append(Path(cfg.PSEUDO_GEN_WORK_ROOT).resolve())
    candidates.append((_user_state_root() / "_work").resolve())
    candidates.append((_tmp_state_root() / "_work").resolve())
    p, _ = _first_writable(candidates)
    return p


def _resolve_run_output_dir(data: dict[str, Any]) -> Path:
    """Dossier de sortie des .UPF (override possible par requête)."""
    raw_o = data.get("output_dir") or data.get("copy_upf_to")
    raw = str(raw_o).strip() if raw_o is not None else ""
    if raw:
        p = Path(raw).expanduser().resolve()
        if _ensure_writable(p):
            return p
    return _pseudo_gen_output_dir()


def _pseudo_gen_tmp_root() -> Path:
    return _pseudo_gen_work_root()


def _safe_tmp_workdir(continue_dir: str | None, tmp_root: Path, default_wd: Path) -> Path:
    tmp_root = tmp_root.resolve()
    if continue_dir and str(continue_dir).strip():
        try:
            cand = Path(str(continue_dir).strip()).expanduser().resolve()
            cand.relative_to(tmp_root)
            cand.mkdir(parents=True, exist_ok=True)
            return cand
        except Exception:
            pass
    default_wd.mkdir(parents=True, exist_ok=True)
    return default_wd.resolve()


def _analyse_run_log(stdout: str, stderr: str, upf_files: list[str]) -> dict[str, Any]:
    """
    Analyse le log de sortie APE/ATOMPAW et détecte :
    - ghost states (énergie spectrale parasite)
    - fichier UPF créé avec succès
    - avertissements courants
    """
    combined = (stdout or "") + "\n" + (stderr or "")
    lines = combined.splitlines()

    ghost_detected = False
    ghost_msgs: list[str] = []
    warnings: list[str] = []
    convergence_ok = True

    ghost_patterns = [
        r"ghost\s+state",
        r"spurious\s+state",
        r"état\s+fantôme",
        r"ghost\s+node",
        r"repulsive\s+local",
        r"WARNING.*ghost",
        r"WARNING.*local.*component",
    ]
    warn_patterns = [
        r"WARNING",
        r"CAUTION",
        r"not\s+converged",
        r"convergence\s+fail",
        r"error\s+in\s+",
    ]
    conv_fail_patterns = [
        r"not\s+converged",
        r"convergence\s+fail",
        r"maximum\s+iteration",
    ]

    import re as _re
    for ln in lines:
        ln_low = ln.lower()
        for pat in ghost_patterns:
            if _re.search(pat, ln_low):
                ghost_detected = True
                ghost_msgs.append(ln.strip())
                break
        for pat in warn_patterns:
            if _re.search(pat, ln, _re.IGNORECASE):
                warnings.append(ln.strip())
                break
        for pat in conv_fail_patterns:
            if _re.search(pat, ln_low):
                convergence_ok = False

    upf_ok = len(upf_files) > 0
    upf_sizes = {}
    for f in upf_files:
        try:
            upf_sizes[Path(f).name] = Path(f).stat().st_size
        except OSError:
            upf_sizes[Path(f).name] = 0

    advice = []
    if ghost_detected:
        advice.append(
            "Ghost state détecté — essayez de changer le canal local (l_local) "
            "ou d'augmenter légèrement rc."
        )
    if not upf_ok:
        advice.append(
            "Aucun fichier .UPF trouvé — vérifiez le log pour des erreurs d'exécution."
        )
    if not convergence_ok:
        advice.append(
            "Problème de convergence — réduisez rc ou vérifiez la configuration de valence."
        )

    return {
        "upf_created":        upf_ok,
        "upf_files":          upf_sizes,
        "ghost_state_detected": ghost_detected,
        "ghost_messages":     ghost_msgs[:5],
        "convergence_ok":     convergence_ok,
        "warnings":           warnings[:10],
        "advice":             advice,
    }


def _copy_upf_outputs(work_dir: Path, dest_dir: Path) -> list[str]:
    dest_dir.mkdir(parents=True, exist_ok=True)
    copied: list[str] = []
    for pattern in ("*.UPF", "*.upf"):
        for f in work_dir.glob(pattern):
            try:
                t = dest_dir / f.name
                shutil.copy2(f, t)
                copied.append(str(t.resolve()))
            except OSError:
                continue
    return copied


def pseudo_save_local_input_dispatch() -> Any:
    """Sauvegarde APE/ATOMPAW sous pseudo_generator_templates/{ape,atompaw}/ — partagé avec POST /api/inputs/save_pseudo_generator."""
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json() or {}
    gen = str(data.get("generator") or data.get("kind") or "").strip().lower()
    if gen not in ("ape", "atompaw"):
        return jsonify({"success": False, "error": '« generator » doit valoir « ape » ou « atompaw ».'}), 400
    content = data.get("content")
    if not isinstance(content, str):
        return jsonify({"success": False, "error": "Champ JSON « content » (chaîne) requis."}), 400
    blob = content.encode("utf-8")
    if len(blob) > _MAX_LOCAL_INPUT_SAVE_BYTES:
        return jsonify({"success": False, "error": "Contenu trop volumineux (max 2 Mo)."}), 400
    element = re.sub(r"[^A-Za-z0-9._-]+", "", str(data.get("element") or "X")).strip()[:16] or "X"
    xc = re.sub(r"[^a-zA-Z0-9._-]+", "_", str(data.get("xc") or "xc").strip())[:32] or "xc"
    pp = re.sub(
        r"[^a-zA-Z0-9._-]+",
        "_",
        str(data.get("pp_type") or data.get("pp_type_ape") or data.get("pp_type_atompaw") or "pp").strip(),
    )[:32] or "pp"

    try:
        dest_dir, dir_warn = _pseudo_local_inputs_dir(gen)
    except OSError as e:
        return (
            jsonify(
                {
                    "success": False,
                    "error": (
                        f"Aucun dossier inscriptible disponible ({e}). "
                        "Définissez THERMO_GENERATION_PSEUDOS_DIR vers un dossier où l’utilisateur "
                        "de l’API peut écrire."
                    ),
                }
            ),
            503,
        )
    fname_override = data.get("filename")
    if isinstance(fname_override, str) and fname_override.strip():
        base = Path(fname_override.strip()).name
        if not re.fullmatch(r"[A-Za-z0-9._-]+", base):
            return jsonify({"success": False, "error": "filename invalide (lettres, chiffres, . _ - uniquement)."}), 400
        out = dest_dir / base
    else:
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        base = f"{element}_{xc}_{pp}_ape_{ts}.inp.ape" if gen == "ape" else f"{element}_{xc}_{pp}_atompaw_{ts}.atompaw.in"
        out = dest_dir / base

    try:
        out.resolve().relative_to(dest_dir.resolve())
    except ValueError:
        return jsonify({"success": False, "error": "Nom de fichier hors dossier cible."}), 400
    try:
        out.write_text(content, encoding="utf-8")
    except OSError as e:
        return jsonify({"success": False, "error": str(e)}), 500
    out_payload = {
        "success": True,
        "filename": out.name,
        "path": str(out.resolve()),
        "directory": str(dest_dir.resolve()),
        "generator": gen,
    }
    if dir_warn:
        out_payload["warning"] = dir_warn
    return jsonify(out_payload)


def register_pseudos_generation_routes(app: Flask) -> None:
    @app.route("/api/pseudos/generator_paths", methods=["GET"])
    def tpw_pseudos_generator_paths():
        """Chemins du générateur (indépendants de la biblio QE utilisée par pw.x)."""
        gr = _generation_root()
        try:
            wr = _pseudo_gen_work_root()
            od = _pseudo_gen_output_dir()
            ia, ia_warn = _pseudo_local_inputs_dir("ape")
            iw, iw_warn = _pseudo_local_inputs_dir("atompaw")
        except OSError as e:
            return jsonify({"error": str(e)}), 503
        notes = [x for x in (ia_warn, iw_warn) if x]
        payload = {
                "generation_root": str(gr),
                "work_root": str(wr.resolve()),
                "output_upf_dir": str(od.resolve()),
                "input_ape_dir": str(ia.resolve()),
                "input_atompaw_dir": str(iw.resolve()),
                "qe_pseudos_library_dir": str(cfg.PSEUDOS_DIR.resolve()),
                "hint": (
                    "Les .UPF générés sont copiés vers output_upf_dir (modifiable : "
                    "THERMO_PSEUDO_GEN_OUTPUT_DIR, pseudo_gen_output_dir dans api_config.json, "
                    "ou output_dir dans le POST). THERMO_PSEUDOS_DIR sert aux calculs QE dans thermo_pw."
                ),
                "hint_save_inputs": (
                    "POST /api/inputs/save_pseudo_generator ou /api/pseudos/save_local_input : "
                    "enregistre le texte de l’étape 3 sous pseudo_generator_templates/ape/ ou "
                    "pseudo_generator_templates/atompaw/ (à la manière de ld1_inputs/ pour ld1.x)."
                ),
        }
        if notes:
            payload["hint_save_inputs"] += " " + " ".join(notes)
        return jsonify(payload)

    @app.route("/api/chemins", methods=["GET"])
    def tpw_api_chemins():
        """Chemins utiles à l’interface generation_pseudos (clé « pseudos » = biblio QE)."""
        try:
            od = _pseudo_gen_output_dir()
            wr = _pseudo_gen_work_root()
            od.mkdir(parents=True, exist_ok=True)
            wr.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            return jsonify({"error": str(e)}), 500
        return jsonify(
            {
                "qe_bin": str(cfg.QE_BIN.resolve()),
                "pseudos": str(cfg.PSEUDOS_DIR.resolve()),
                "inputs": str(cfg.INPUTS_DIR.resolve()),
                "outputs": str(cfg.OUTPUTS_DIR.resolve()),
                "generation_root": str(_generation_root()),
                "pseudo_gen_output_dir": str(od.resolve()),
                "pseudo_gen_work_root": str(wr.resolve()),
                "tmp": str(wr.resolve()),
                "logs": str(cfg.WORK_ROOT.resolve()),
                "interface_pseudos": str((cfg.THERMO_REPO_ROOT / "interface").resolve()),
                "reference": {},
            }
        )

    @app.route("/api/pseudos/diagnose", methods=["GET"])
    def tpw_pseudos_diagnose():
        """Diagnostic complet pour l’UI : binaires, dossiers (avec test d’écriture), templates."""
        info: dict[str, Any] = {"ok": True, "messages": []}

        ape = _resolve_ape_bin()
        atw = _resolve_atompaw_bin()
        info["binaries"] = {
            "ape": {"available": bool(ape), "path": str(ape) if ape else None},
            "atompaw": {"available": bool(atw), "path": str(atw) if atw else None},
        }
        if not ape:
            info["messages"].append("Binaire « ape » introuvable — définissez APE_BIN ou installez APE.")
        if not atw:
            info["messages"].append("Binaire « atompaw » introuvable — définissez ATOMPAW_BIN ou installez ATOMPAW.")

        dirs: dict[str, Any] = {}
        try:
            ia, ia_warn = _pseudo_local_inputs_dir("ape")
            dirs["input_ape"] = {"path": str(ia), "writable": True, "warning": ia_warn}
            if ia_warn:
                info["messages"].append(ia_warn)
        except OSError as e:
            info["ok"] = False
            dirs["input_ape"] = {"writable": False, "error": str(e)}
        try:
            iw, iw_warn = _pseudo_local_inputs_dir("atompaw")
            dirs["input_atompaw"] = {"path": str(iw), "writable": True, "warning": iw_warn}
            if iw_warn and iw_warn != dirs.get("input_ape", {}).get("warning"):
                info["messages"].append(iw_warn)
        except OSError as e:
            info["ok"] = False
            dirs["input_atompaw"] = {"writable": False, "error": str(e)}
        try:
            wr = _pseudo_gen_work_root()
            dirs["work_root"] = {"path": str(wr), "writable": True}
        except OSError as e:
            info["ok"] = False
            dirs["work_root"] = {"writable": False, "error": str(e)}
        try:
            od = _pseudo_gen_output_dir()
            dirs["pseudos_generes"] = {"path": str(od), "writable": True}
        except OSError as e:
            info["ok"] = False
            dirs["pseudos_generes"] = {"writable": False, "error": str(e)}
        info["dirs"] = dirs

        templates: dict[str, Any] = {}
        for name in ("inp.ape.Li_ae", "inp.ape.Li_pp", "atompaw.in.example"):
            fp = _pseudo_template_file(name)
            templates[name] = {"found": fp is not None, "path": str(fp) if fp else None}
        info["templates"] = templates
        info["templates_dirs_searched"] = [
            str(_pseudo_templates_dir()),
            str(_BUNDLED_PSEUDO_TEMPLATES),
        ]

        info["environment"] = {
            "THERMO_GENERATION_PSEUDOS_DIR": _env_str("THERMO_GENERATION_PSEUDOS_DIR") or None,
            "THERMO_PSEUDO_GEN_WORK_ROOT": _env_str("THERMO_PSEUDO_GEN_WORK_ROOT") or None,
            "THERMO_PSEUDO_GEN_OUTPUT_DIR": _env_str("THERMO_PSEUDO_GEN_OUTPUT_DIR") or None,
            "APE_BIN": _env_str("APE_BIN") or None,
            "ATOMPAW_BIN": _env_str("ATOMPAW_BIN") or None,
        }
        info["api_user_home"] = str(Path.home())
        info["generation_root"] = str(_generation_root())
        info["fallback_user_root"] = str(_user_state_root())
        info["fallback_tmp_root"] = str(_tmp_state_root())
        return jsonify(info)

    @app.route("/api/pseudos/ape_status", methods=["GET"])
    def tpw_pseudos_ape_status():
        exe = _resolve_ape_bin()
        return jsonify({"available": bool(exe), "path": str(exe) if exe else None})

    @app.route("/api/pseudos/atompaw_status", methods=["GET"])
    def tpw_pseudos_atompaw_status():
        exe = _resolve_atompaw_bin()
        return jsonify({"available": bool(exe), "path": str(exe) if exe else None})

    @app.route("/api/pseudos/auto_inputs", methods=["GET", "POST", "OPTIONS"])
    @app.route("/api/pseudos/auto_inputs/", methods=["GET", "POST", "OPTIONS"])
    def tpw_pseudos_auto_inputs():
        # Prévol CORS : même logique que run_ape / run_atompaw (POST JSON → OPTIONS).
        if request.method == "OPTIONS":
            return "", 204
        if request.method == "POST":
            body = request.get_json() or {}
            sym_raw   = str(body.get("element") or body.get("sym") or "Si").strip()
            xc        = str(body.get("xc") or "lda_pw").strip()
            pp_ape    = str(body.get("pp_type_ape") or body.get("pp_type") or "troullier").strip()
            pp_aw     = str(body.get("pp_type_atompaw") or body.get("pp_type") or "vanderbilt").strip()
            relat     = bool(body.get("relativistic") or body.get("scalar_rel"))
            semicore  = bool(body.get("semicore") or body.get("semi_core"))
            rc_scale  = float(body.get("rc_scale") or 1.0)
            l_local   = body.get("l_local")
            l_local   = int(l_local) if l_local is not None else None
        else:
            sym_raw   = (request.args.get("element") or request.args.get("sym") or "Si").strip()
            xc        = (request.args.get("xc") or "lda_pw").strip()
            pp_ape    = (request.args.get("pp_type_ape") or request.args.get("pp_type") or "troullier").strip()
            pp_aw     = (request.args.get("pp_type_atompaw") or request.args.get("pp_type") or "vanderbilt").strip()
            relat     = request.args.get("relativistic", "").lower() in ("1", "true", "yes")
            semicore  = request.args.get("semicore", "").lower() in ("1", "true", "yes")
            rc_scale  = float(request.args.get("rc_scale") or 1.0)
            l_local_r = request.args.get("l_local")
            l_local   = int(l_local_r) if l_local_r is not None else None

        mod = _load_pseudo_auto_inputs()
        if mod is None:
            return jsonify({"error": f"pseudo_auto_inputs.py introuvable ({cfg.GENERATION_PSEUDOS_DIR})."}), 503

        try:
            sym  = mod.normalize_symbol(sym_raw)
            znum = mod.atomic_number(sym)
            ape  = mod.generate_ape_input(sym, xc=xc, pp_type=pp_ape,
                                           relativistic=relat, semicore=semicore,
                                           rc_scale=rc_scale, l_local=l_local)
            aw   = mod.generate_atompaw_input(sym, xc=xc, pp_type=pp_aw,
                                              relativistic=relat, semicore=semicore,
                                              rc_scale=rc_scale)
            aw_qe = ""
            if hasattr(mod, "generate_atompaw_input_qe_file"):
                aw_qe = mod.generate_atompaw_input_qe_file(
                    sym, xc=xc, pp_type=pp_aw, relativistic=relat,
                    semicore=semicore, rc_scale=rc_scale,
                )
        except Exception as e:
            return jsonify({"error": str(e)}), 400

        # Métadonnées physiques (rc recommandés, flags)
        metadata: dict[str, Any] = {}
        try:
            import importlib.util as _iu
            _db_path = _generation_root() / "elements_physics_db.py"
            if _db_path.is_file():
                _spec = _iu.spec_from_file_location("elements_physics_db", _db_path)
                _db   = _iu.module_from_spec(_spec)
                _spec.loader.exec_module(_db)
                metadata = _db.element_metadata(sym)
        except Exception:
            pass

        breakdown: dict[str, Any] = {}
        try:
            if hasattr(mod, "inputs_breakdown"):
                breakdown = mod.inputs_breakdown(
                    sym, xc, pp_ape, pp_aw, relat, semicore, rc_scale, l_local
                )
        except Exception:
            breakdown = {}

        return jsonify({
            "element":       sym,
            "Z":             znum,
            "ape_input":     ape,
            "atompaw_input": aw,
            "atompaw_input_qe": aw_qe,
            "params": {
                "xc": xc, "pp_type_ape": pp_ape, "pp_type_atompaw": pp_aw,
                "relativistic": relat, "semicore": semicore,
                "rc_scale": rc_scale, "l_local": l_local,
            },
            "metadata": metadata,
            "input_breakdown": breakdown,
            "note": "Aufbau anormal (Cu, Cr, …) : vérifiez la configuration de valence.",
        })

    @app.route("/api/pseudos/element_info", methods=["GET"])
    def tpw_pseudos_element_info():
        """Métadonnées physiques d'un élément : rc, l_local, semi-cœur, relativité."""
        sym_raw = (request.args.get("element") or request.args.get("sym") or "Si").strip()
        try:
            import importlib.util as _iu
            _db_path = _generation_root() / "elements_physics_db.py"
            if not _db_path.is_file():
                return jsonify({"error": "elements_physics_db.py absent"}), 503
            _spec = _iu.spec_from_file_location("elements_physics_db", _db_path)
            _db   = _iu.module_from_spec(_spec)
            _spec.loader.exec_module(_db)
            mod = _load_pseudo_auto_inputs()
            if mod:
                sym = mod.normalize_symbol(sym_raw)
            else:
                sym = sym_raw
            return jsonify(_db.element_metadata(sym))
        except Exception as e:
            return jsonify({"error": str(e)}), 400

    @app.route("/api/pseudos/ape_input_template", methods=["GET"])
    @app.route("/api/pseudos/ape_input_template/", methods=["GET"])
    def tpw_pseudos_ape_input_template():
        preset = (request.args.get("preset") or "li_ae").strip().lower()
        mapping = {"li_ae": "inp.ape.Li_ae", "li_pp": "inp.ape.Li_pp"}
        fname = mapping.get(preset, mapping["li_ae"])
        fp = _pseudo_template_file(fname)
        if fp is not None:
            return Response(fp.read_text(encoding="utf-8", errors="replace"), mimetype="text/plain; charset=utf-8")
        return jsonify(
            {
                "error": (
                    f"Modèle absent : {fname}. "
                    f"Attendu sous {_pseudo_templates_dir()} ou bundle thermo_pw ({_BUNDLED_PSEUDO_TEMPLATES})."
                )
            }
        ), 404

    @app.route("/api/pseudos/atompaw_input_template", methods=["GET"])
    @app.route("/api/pseudos/atompaw_input_template/", methods=["GET"])
    def tpw_pseudos_atompaw_input_template():
        fp = _pseudo_template_file("atompaw.in.example")
        if fp is not None:
            return Response(fp.read_text(encoding="utf-8", errors="replace"), mimetype="text/plain; charset=utf-8")
        return jsonify(
            {
                "error": (
                    "Modèle absent : atompaw.in.example. "
                    f"Attendu sous {_pseudo_templates_dir()} ou bundle thermo_pw ({_BUNDLED_PSEUDO_TEMPLATES})."
                )
            }
        ), 404

    @app.route("/api/pseudos/save_local_input", methods=["POST", "OPTIONS"])
    @app.route("/api/pseudos/save_local_input/", methods=["POST", "OPTIONS"])
    def tpw_pseudos_save_local_input():
        """Écrit l’entrée affichée dans pseudo_generator_templates/{ape,atompaw}/ (parcours analogue à ld1_inputs/)."""
        return pseudo_save_local_input_dispatch()

    @app.route("/api/pseudos/run_ape", methods=["POST", "OPTIONS"])
    def tpw_pseudos_run_ape():
        if request.method == "OPTIONS":
            return "", 204
        data = request.get_json() or {}
        element  = re.sub(r"[^A-Za-z0-9._-]+", "", str(data.get("element") or "X"))[:8] or "X"
        auto_g   = bool(data.get("auto_generate") or data.get("auto"))
        content  = (data.get("input") or "").strip()
        xc       = str(data.get("xc") or "lda_pw")
        pp_type  = str(data.get("pp_type_ape") or data.get("pp_type") or "troullier")
        relat    = bool(data.get("relativistic") or data.get("scalar_rel"))
        semicore = bool(data.get("semicore"))
        rc_scale = float(data.get("rc_scale") or 1.0)
        l_local  = data.get("l_local")
        l_local  = int(l_local) if l_local is not None else None
        if auto_g or not content:
            mod = _load_pseudo_auto_inputs()
            if mod is None:
                return jsonify({"success": False, "error": "pseudo_auto_inputs.py absent."}), 503
            try:
                sym_pass = re.sub(r"[^A-Za-z]+", "", str(data.get("element") or element))
                content = mod.generate_ape_input(
                    sym_pass or element, xc=xc, pp_type=pp_type,
                    relativistic=relat, semicore=semicore,
                    rc_scale=rc_scale, l_local=l_local,
                )
            except Exception as e:
                return jsonify({"success": False, "error": str(e)}), 400
        elif len(content) > 500000:
            return jsonify({"success": False, "error": "Entrée APE trop volumineuse."}), 400

        exe = _resolve_ape_bin()
        if not exe:
            return jsonify({"success": False, "error": "ape introuvable (APE_BIN ou PATH)."}), 503

        tmp_root = _pseudo_gen_tmp_root()
        default_wd = tmp_root / f"ape_{element}"
        continue_dir = data.get("continue_dir") or data.get("work_dir")
        work_dir = _safe_tmp_workdir(str(continue_dir) if continue_dir else None, tmp_root, default_wd)
        try:
            work_dir.relative_to(tmp_root)
        except ValueError:
            return jsonify({"success": False, "error": "Répertoire hors tmp."}), 400

        inp = work_dir / "inp.ape"
        inp.write_text(content, encoding="utf-8")
        out_log = work_dir / "ape_run.log"
        try:
            proc = subprocess.run(
                [str(exe)],
                cwd=str(work_dir),
                capture_output=True,
                text=True,
                timeout=300,
            )
        except subprocess.TimeoutExpired:
            return jsonify({"success": False, "error": "Timeout 300 s (APE)."}), 500
        except Exception as e:
            return jsonify({"success": False, "error": str(e)}), 500

        out_log.write_text((proc.stdout or "") + "\n--- stderr ---\n" + (proc.stderr or ""), encoding="utf-8")
        upf_files = glob.glob(str(work_dir / "*.UPF")) + glob.glob(str(work_dir / "*.upf"))
        upf_pick = None
        if upf_files:
            try:
                upf_pick = max(upf_files, key=os.path.getmtime)
            except Exception:
                upf_pick = upf_files[0]

        pd = _resolve_run_output_dir(data)
        copied = _copy_upf_outputs(work_dir, pd) if proc.returncode == 0 else []
        validation = _analyse_run_log(proc.stdout, proc.stderr, upf_files)

        files_list: list[dict[str, Any]] = []
        try:
            for fn in sorted(os.listdir(work_dir)):
                fp = work_dir / fn
                if fp.is_file():
                    files_list.append({"name": fn, "path": str(fp.resolve()), "size": fp.stat().st_size})
        except OSError:
            pass

        return jsonify(
            {
                "success": proc.returncode == 0 and validation["upf_created"],
                "returncode": proc.returncode,
                "output": (proc.stdout or "")[-12000:],
                "stderr": (proc.stderr or "")[-4000:],
                "work_dir": str(work_dir),
                "input_file": str(inp),
                "log_file": str(out_log),
                "upf_path": upf_pick,
                "upf_genere": os.path.basename(upf_pick) if upf_pick else None,
                "copied_to_pseudos": copied,
                "files_in_workdir": files_list,
                "output_upf_dir": str(pd),
                "pseudos_dir": str(pd),
                "qe_pseudos_library_dir": str(cfg.PSEUDOS_DIR.resolve()),
                "validation": validation,
                "hint": "APE : étape ae puis pp dans le même dossier — renvoyez continue_dir = work_dir.",
            }
        )

    @app.route("/api/pseudos/run_atompaw", methods=["POST", "OPTIONS"])
    def tpw_pseudos_run_atompaw():
        if request.method == "OPTIONS":
            return "", 204
        data = request.get_json() or {}
        element  = re.sub(r"[^A-Za-z0-9._-]+", "", str(data.get("element") or "X"))[:8] or "X"
        auto_g   = bool(data.get("auto_generate") or data.get("auto"))
        content  = (data.get("input") or "").strip()
        xc       = str(data.get("xc") or "lda_pw")
        pp_type  = str(data.get("pp_type_atompaw") or data.get("pp_type") or "vanderbilt")
        relat    = bool(data.get("relativistic") or data.get("scalar_rel"))
        semicore = bool(data.get("semicore"))
        rc_scale = float(data.get("rc_scale") or 1.0)
        fmt = str(data.get("atompaw_format") or "interactive").strip().lower()
        use_qe = fmt in ("qe", "qe_file", "file", "redirection", "compact")
        if auto_g or not content:
            mod = _load_pseudo_auto_inputs()
            if mod is None:
                return jsonify({"success": False, "error": "pseudo_auto_inputs.py absent."}), 503
            try:
                sym_pass = re.sub(r"[^A-Za-z]+", "", str(data.get("element") or element))
                sym_use = sym_pass or element
                if use_qe and hasattr(mod, "generate_atompaw_input_qe_file"):
                    content = mod.generate_atompaw_input_qe_file(
                        sym_use, xc=xc, pp_type=pp_type, relativistic=relat,
                        semicore=semicore, rc_scale=rc_scale,
                    )
                else:
                    content = mod.generate_atompaw_input(
                        sym_use, xc=xc, pp_type=pp_type,
                        relativistic=relat, semicore=semicore, rc_scale=rc_scale,
                    )
            except Exception as e:
                return jsonify({"success": False, "error": str(e)}), 400
        elif len(content) > 500000:
            return jsonify({"success": False, "error": "Entrée ATOMPAW trop volumineuse."}), 400

        exe = _resolve_atompaw_bin()
        if not exe:
            return jsonify({"success": False, "error": "ATOMPAW introuvable (ATOMPAW_BIN ou PATH)."}), 503

        tmp_root = _pseudo_gen_tmp_root()
        default_wd = tmp_root / f"atompaw_{element}"
        continue_dir = data.get("continue_dir") or data.get("work_dir")
        work_dir = _safe_tmp_workdir(str(continue_dir) if continue_dir else None, tmp_root, default_wd)
        try:
            work_dir.relative_to(tmp_root)
        except ValueError:
            return jsonify({"success": False, "error": "Répertoire hors tmp."}), 400

        inp = work_dir / _ATOMPAW_INPUT_NAME
        inp.write_text(content, encoding="utf-8")
        out_log = work_dir / "atompaw_run.log"

        try:
            with inp.open("r", encoding="utf-8") as stdin_f:
                proc = subprocess.run(
                    [str(exe)],
                    cwd=str(work_dir),
                    stdin=stdin_f,
                    capture_output=True,
                    text=True,
                    timeout=300,
                )
        except subprocess.TimeoutExpired:
            return jsonify({"success": False, "error": "Timeout 300 s (ATOMPAW)."}), 500
        except Exception as e:
            return jsonify({"success": False, "error": str(e)}), 500

        out_log.write_text((proc.stdout or "") + "\n--- stderr ---\n" + (proc.stderr or ""), encoding="utf-8")
        upf_files = glob.glob(str(work_dir / "*.UPF")) + glob.glob(str(work_dir / "*.upf"))
        upf_pick = None
        if upf_files:
            try:
                upf_pick = max(upf_files, key=os.path.getmtime)
            except Exception:
                upf_pick = upf_files[0]

        pd = _resolve_run_output_dir(data)
        copied = _copy_upf_outputs(work_dir, pd) if proc.returncode == 0 else []
        validation = _analyse_run_log(proc.stdout, proc.stderr, upf_files)

        files_list = []
        try:
            for fn in sorted(os.listdir(work_dir)):
                fp = work_dir / fn
                if fp.is_file():
                    files_list.append({"name": fn, "path": str(fp.resolve()), "size": fp.stat().st_size})
        except OSError:
            pass

        return jsonify(
            {
                "success": proc.returncode == 0 and validation["upf_created"],
                "returncode": proc.returncode,
                "output": (proc.stdout or "")[-12000:],
                "stderr": (proc.stderr or "")[-4000:],
                "work_dir": str(work_dir),
                "input_file": str(inp),
                "log_file": str(out_log),
                "upf_path": upf_pick,
                "upf_genere": os.path.basename(upf_pick) if upf_pick else None,
                "copied_to_pseudos": copied,
                "files_in_workdir": files_list,
                "output_upf_dir": str(pd),
                "pseudos_dir": str(pd),
                "qe_pseudos_library_dir": str(cfg.PSEUDOS_DIR.resolve()),
                "validation": validation,
                "hint": "Conversion UPF pour QE peut nécessiter paw_generate ou scripts livrés avec votre chaîne.",
            }
        )

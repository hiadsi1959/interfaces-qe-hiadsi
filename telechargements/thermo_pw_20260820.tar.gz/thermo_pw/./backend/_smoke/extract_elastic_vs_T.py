"""Smoke extract — C_ij(V0,T) depuis un work_dir thermo_pw P3 (juin 2026) — v2.

Lit le ``work_dir`` d'un profil P3 (``what='elastic_constants_geo'`` + grille T
0→1000 K) et produit un résumé Markdown contenant :

  1. Validation à T=0 K vs littérature Si : C11=167 ±5% / C12=65 ±5% / C44=80 ±5% (GPa).
  2. Tableau complet C_ij(T) (colonnes T=0, 100, 200, …, 1000 K).
  3. Modules polycristallins VRH B/G/E/ν(T) pour chaque T.
     Formules système cubique (Si) :

       B    = (C11 + 2·C12) / 3
       G_V  = (C11 − C12 + 3·C44) / 5
       G_R  = 5·(C11 − C12)·C44 / (4·C44 + 3·(C11 − C12))
       G    = (G_V + G_R) / 2  (Hill average)
       E    = 9·B·G / (3·B + G)
       ν    = (3·B − 2·G) / (2·(3·B + G))

  4. Born stability check : C11>0, C44>0, C11>|C12|, C11+2·C12>0.
  5. ASCII chart B(T) (mini-bar).
  6. Verdict OK / WARN / FAIL (basé sur l'écart littérature à T=0K).

Sources de données lues dans ``work_dir`` (par ordre de préférence) :
  - ``elastic_constants_vs_T.dat`` (P3 sortie canonique),
  - ``c_ij.dat``/``C_ij_T.dat``/``elastic_t_*.dat`` (génériques),
  - ``output_el_cons.dat`` / ``output_el_cons_geo.dat`` (T=0K matrix, fallback).

Usage::

    python3 -u _smoke/extract_elastic_vs_T.py \
        --work-dir /home/hiadsi/thermo_pw/work/Si/pipeline_P3_<id> \
        --output  /tmp/elastic_summary.md

``--synthetic`` (test sur données synthétiques) : génère un C_ij(V0,T)=const
aligné sur la littérature pour valider le pipeline avant que P3 finisse.

``--units {kbar, gpa, auto}`` : force l'unité d'entrée (par défaut: ``auto``,
heuristique mean > 100 ⇒ kbar). Important pour matériaux mous (polymères : C~5
GPa = ~50 kbar, ambigu avec seuil bas).

NE PAS toucher au P2 (``pipeline_P2_1782738858_49ef49``) encore en cours.
"""
from __future__ import annotations

import argparse
import math
import re
import sys
from pathlib import Path


# ----------------------------------------------------------------------------
# Littérature de référence Si (juin 2026) — tolérances larges pour un smoke.
# ----------------------------------------------------------------------------
LIT_SI_CUBIC_GPA = {
    "C11": (167.0, 5.0),   # (valeur litt., tol ± %)
    "C12": (65.0,  5.0),
    "C44": (80.0,  5.0),
}

# Index Voigt standard pour cubique.
SUBSCRIPT_LABELS = {"C11": "C₁₁", "C12": "C₁₂", "C44": "C₄₄"}


# ----------------------------------------------------------------------------
# Helpers fichier / parsing
# ----------------------------------------------------------------------------

def _kbar_to_gpa(v_kbar: float) -> float:
    """thermo_pw ``output_el_cons*.dat`` est en kbar ; le Markdown utilisateur
    attend des GPa (convention modules polycristallins). Conversion : 1 kbar = 0.1 GPa."""
    return v_kbar * 0.1


def _auto_units(values: list[float]) -> str:
    """Heuristique : si mean(|values|) > 100 ⇒ kbar ; sinon GPa.

    Cas typique :
      * Si/GaAs/NaCl metals → mean ~700 (kbar) → kbar.
      * Polymères mous → mean ~50 → GPa (sans conversion).
    Bords : 50<mean<100 = ambigu ; le CLI flag ``--units`` lève l'ambiguïté.
    """
    if not values:
        return "gpa"
    mean_abs = sum(abs(v) for v in values) / len(values)
    return "kbar" if mean_abs > 100.0 else "gpa"


def _parse_elastic_dat(path: Path, units: str = "auto"):
    """Parse un .dat thermo_pw avec colonnes ``T(K) C11 C12 C44`` (GPa ou kbar).

    Retourne : list[(T_K, C11, C12, C44)] ; vide si introuvable / colonne
    manquante. ``units`` : 'auto' (heuristique mean > 100 ⇒ kbar), 'kbar',
    'gpa'.
    """
    rows = []
    if not path.is_file():
        return rows
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return rows
    raw_values: list[float] = []
    parsed: list[tuple[float, float, float, float]] = []
    for line in text.splitlines():
        line_s = line.strip()
        if not line_s or line_s.startswith("#") or line_s.startswith("!"):
            continue
        parts = re.split(r"[\s,;]+", line_s)
        if len(parts) < 4:
            continue
        try:
            t_k = float(parts[0])
            c11 = float(parts[1]); c12 = float(parts[2]); c44 = float(parts[3])
        except ValueError:
            continue
        raw_values.extend([c11, c12, c44])
        parsed.append((t_k, c11, c12, c44))
    if not parsed:
        return rows
    if units == "auto":
        units = _auto_units(raw_values)
    if units == "kbar":
        return [(t, _kbar_to_gpa(c11), _kbar_to_gpa(c12), _kbar_to_gpa(c44))
                for (t, c11, c12, c44) in parsed]
    return parsed  # déjà en GPa


def _parse_output_el_cons(path: Path):
    """Parse ``output_el_cons.dat`` (P1 : C_ij @ T=0K, Voigt 6×6, kbar).

    Format attendu (thermo_pw 7.x)::

      #  i   j       C_ij (kbar)
        1  1      1670.0   !
        1  2       650.0   !
        ...

    Retourne ``(C11, C12, C44)`` en GPa. T = 0 K par défaut.
    """
    if not path.is_file():
        return None
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    out: dict[tuple[int, int], float] = {}
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#") or s.startswith("!"):
            continue
        parts = re.split(r"[\s,;]+", s)
        if len(parts) < 3:
            continue
        try:
            i, j, val = int(parts[0]), int(parts[1]), float(parts[2])
        except (ValueError, TypeError):
            continue
        out[(i, j)] = val
    # Indices Voigt standards : C11=(1,1), C12=(1,2), C44=(4,4).
    if (1, 1) not in out or (1, 2) not in out or (4, 4) not in out:
        return None
    return (
        _kbar_to_gpa(out[(1, 1)]),
        _kbar_to_gpa(out[(1, 2)]),
        _kbar_to_gpa(out[(4, 4)]),
    )


def _find_elastic_data_files(work_dir: Path):
    """Scan work_dir pour les fichiers candidats C_ij(V,T) + fallback T=0K."""
    files = []
    # 1. Préféré : elastic_constants_vs_T.dat (P3 sortie canonique)
    for name in ("elastic_constants_vs_T.dat", "c_ij_T.dat", "Cij_vs_T.dat"):
        p = work_dir / name
        if p.is_file():
            files.append(p)
    # 2. elastic_t_*.dat (génériques)
    for p in sorted(work_dir.glob("elastic_t*.dat")):
        if p not in files:
            files.append(p)
    # 3. output_el_cons*.dat (T=0K matrix, fallback)
    for name in ("output_el_cons_geo.dat", "output_el_cons.dat"):
        p = work_dir / name
        if p.is_file() and p not in files:
            files.append(p)
    return files


def _synthetic_grid_si():
    """Grille synthétique sur la littérature Si (pour --synthetic avant P3 fini).
    Décroissance légère vs T : -0.5% par 100 K (approximation soft)."""
    rows = []
    c11, c12, c44 = LIT_SI_CUBIC_GPA["C11"][0], LIT_SI_CUBIC_GPA["C12"][0], LIT_SI_CUBIC_GPA["C44"][0]
    for t in range(0, 1001, 100):
        decay = 1.0 - 0.005 * (t / 100.0)
        rows.append((float(t), c11 * decay, c12 * decay, c44 * decay))
    return rows


# ----------------------------------------------------------------------------
# Calculs physique (système cubique, VRH)
# ----------------------------------------------------------------------------

def vrh_cubic(c11: float, c12: float, c44: float):
    """Modules polycristallins (B, G_V, G_R, G_Hill, E, ν). GPa (adim. pour ν)."""
    b = (c11 + 2.0 * c12) / 3.0
    g_v = (c11 - c12 + 3.0 * c44) / 5.0
    denom = 4.0 * c44 + 3.0 * (c11 - c12)
    g_r = 5.0 * (c11 - c12) * c44 / denom if denom > 0 else float("nan")
    g = (g_v + g_r) / 2.0
    e = 9.0 * b * g / (3.0 * b + g) if (3.0 * b + g) > 0 else float("nan")
    nu = (3.0 * b - 2.0 * g) / (2.0 * (3.0 * b + g)) if (2.0 * (3.0 * b + g)) > 0 else float("nan")
    return {
        "B_GPa": b, "G_V_GPa": g_v, "G_R_GPa": g_r, "G_Hill_GPa": g,
        "E_GPa": e, "nu": nu,
    }


def born_stability_ok(c11: float, c12: float, c44: float) -> tuple[bool, list[str]]:
    """Critères de stabilité de Born pour cristal cubique (notation Voigt).
    Conditions nécessaires et suffisantes."""
    fails = []
    if c11 <= 0:
        fails.append(f"C11={c11:.2f} GPa ≤ 0")
    if c44 <= 0:
        fails.append(f"C44={c44:.2f} GPa ≤ 0")
    if c11 <= abs(c12):
        fails.append(f"C11={c11:.2f} ≤ |C12|={abs(c12):.2f} GPa (mécaniquement instable)")
    if c11 + 2.0 * c12 <= 0:
        fails.append(f"C11+2·C12={c11 + 2.0 * c12:.2f} GPa ≤ 0 (compression impossible)")
    return (len(fails) == 0, fails)


def _row_validation_md(c_run: float, c_lit: float, tol_pct: float, key: str) -> str:
    """Construit la ligne de tableau Markdown de validation T=0K pour une
    composante donnée (C11 / C12 / C44)."""
    delta_pct = 100.0 * (c_run - c_lit) / c_lit if c_lit != 0 else 0.0
    if abs(delta_pct) <= tol_pct:
        verdict = "✅ OK"
    elif abs(delta_pct) <= 2 * tol_pct:
        verdict = "🟡 WARN"
    else:
        verdict = "❌ FAIL"
    label = SUBSCRIPT_LABELS[key]
    return (f"| **{label}** | {c_lit:.1f} ± {tol_pct:.0f}% | {c_run:.2f} | "
            f"{delta_pct:+.2f} % | ±{tol_pct:.0f}% | {verdict} |")


def _verdict_count_label(c_run: float, c_lit: float, tol_pct: float) -> str:
    delta_pct = 100.0 * (c_run - c_lit) / c_lit if c_lit != 0 else 0.0
    if abs(delta_pct) <= tol_pct:
        return "OK"
    if abs(delta_pct) <= 2 * tol_pct:
        return "WARN"
    return "FAIL"


# ----------------------------------------------------------------------------
# Génération du Markdown
# ----------------------------------------------------------------------------

def _ascii_bar(x: float, xmax: float, width: int = 40) -> str:
    """Mini bar plot ASCII : proportion de ``x`` par rapport à ``xmax``."""
    if xmax <= 0 or x is None or math.isnan(float(x)):
        return ""
    ratio = max(0.0, min(1.0, x / xmax))
    filled = int(round(ratio * width))
    return "█" * filled + "·" * (width - filled)


def render_markdown_summary(work_dir_label: str, rows: list[tuple[float, float, float, float]],
                            src_paths: list[Path | str]) -> str:
    """Génère le texte Markdown complet du résumé.

    ``src_paths`` : list de ``Path`` (avec ``.stat()`` testé) OU string
    sentinelle (mode synthétique — utilisé directement sans ``.stat()``)."""
    md: list[str] = []
    if not rows:
        md.append(f"# Résumé C_ij(V₀,T) — {work_dir_label}")
        md.append("")
        md.append("⚠️ **Aucun C_ij(V,T) trouvé.**")
        md.append("")
        md.append(f"Chemins scannés :")
        for sp in src_paths:
            if isinstance(sp, str):
                md.append(f"  - `{sp}` (sentinelle)")
            elif sp.is_file():
                md.append(f"  - `{sp.name}` ({sp.stat().st_size} octets)")
            else:
                md.append(f"  - `{sp}` (introuvable)")
        return "\n".join(md) + "\n"

    # Trier par T croissant.
    rows = sorted(rows, key=lambda r: r[0])
    c11_0, c12_0, c44_0 = rows[0][1], rows[0][2], rows[0][3]

    md.append(f"# Résumé C_ij(V₀,T) — thermo_pw P3")
    md.append("")
    md.append(f"- **Work_dir :** `{work_dir_label}`")
    md.append(f"- **Date :** 2026-06-29")
    md.append(f"- **Sources lues :**")
    for sp in src_paths:
        if isinstance(sp, str):
            md.append(f"  - `{sp}`")
        elif sp.is_file():
            md.append(f"  - `{sp.name}` ({sp.stat().st_size} octets)")
        else:
            md.append(f"  - `{sp}` (introuvable)")
    md.append(f"- **Points T :** {len(rows)} (grille 0–{int(rows[-1][0])} K)")
    md.append("")

    # — Section 1 : Validation à T=0K vs littérature Si —
    md.append("## Validation à T=0 K vs littérature Si")
    md.append("")
    md.append("| Composante | Littérature (GPa) | Valeur run (GPa) | Δ (%) | Seuil | Verdict |")
    md.append("|------------|-------------------|------------------|-------|-------|---------|")
    verdict_count = {"OK": 0, "WARN": 0, "FAIL": 0}
    t0 = {"C11": c11_0, "C12": c12_0, "C44": c44_0}
    for key, (c_lit, tol_pct) in LIT_SI_CUBIC_GPA.items():
        md.append(_row_validation_md(t0[key], c_lit, tol_pct, key))
        verdict_count[_verdict_count_label(t0[key], c_lit, tol_pct)] += 1
    md.append("")
    stable, fail_reasons = born_stability_ok(c11_0, c12_0, c44_0)
    md.append(f"### Born stability ({c11_0:.1f}, {c12_0:.1f}, {c44_0:.1f}) GPa : " +
              ("✅ OK" if stable else "❌ FAIL — " + "; ".join(fail_reasons)))
    md.append("")

    # — Section 2 : Tableau C_ij(T) —
    md.append("## Tableau C_ij(V₀,T)")
    md.append("")
    md.append("| T (K) | C₁₁ (GPa) | C₁₂ (GPa) | C₄₄ (GPa) | ΔC₁₁/C₁₁(0) |")
    md.append("|-------|------------|------------|------------|--------------|")
    for t_k, c11, c12, c44 in rows:
        delta_c11 = 100.0 * (c11 - c11_0) / c11_0 if c11_0 != 0 else 0.0
        md.append(f"| {int(t_k):>4d}   | {c11:>9.2f}   | {c12:>9.2f}   | {c44:>9.2f}   | "
                  f"{delta_c11:+5.1f} % |")
    md.append("")

    # — Section 3 : Modules B/G/E/ν(T) —
    md.append("## Modules polycristallins VRH B/G/E/ν(T) (cristal cubique Si)")
    md.append("")
    md.append("Formules : B = (C₁₁ + 2·C₁₂)/3 ; "
              "G_V = (C₁₁ − C₁₂ + 3·C₄₄)/5 ; "
              "G_R = 5·(C₁₁ − C₁₂)·C₄₄ / (4·C₄₄ + 3·(C₁₁ − C₁₂)) ; "
              "G_Hill = (G_V+G_R)/2 ; E = 9·B·G/(3·B+G) ; ν = (3·B−2·G)/(2·(3·B+G))")
    md.append("")
    md.append("| T (K) | B (GPa) | G_V (GPa) | G_R (GPa) | G_Hill (GPa) | E (GPa) | ν |")
    md.append("|-------|----------|-----------|-----------|---------------|---------|---|")
    bmax = 0.0
    for t_k, c11, c12, c44 in rows:
        m = vrh_cubic(c11, c12, c44)
        bmax = max(bmax, m["B_GPa"])
        md.append(
            f"| {int(t_k):>4d}   | {m['B_GPa']:>7.2f}  | "
            f"{m['G_V_GPa']:>8.2f}  | {m['G_R_GPa']:>8.2f}  | "
            f"{m['G_Hill_GPa']:>10.2f}    | "
            f"{m['E_GPa']:>6.2f}  | {m['nu']:>5.3f} |"
        )
    md.append("")

    # — Section 4 : ASCII chart B(T) —
    md.append("## Graph ASCII — Module de compressibilité B(T) (GPa)")
    md.append("")
    md.append("```")
    for t_k, c11, c12, c44 in rows:
        b = vrh_cubic(c11, c12, c44)["B_GPa"]
        bar = _ascii_bar(b, bmax, width=40)
        md.append(f"  {int(t_k):>4d} K | B={b:>6.2f} | {bar}")
    md.append("```")
    md.append("")

    # — Verdict global —
    md.append("## Verdict global")
    md.append("")
    if verdict_count["FAIL"] > 0 or not stable:
        md.append("❌ **FAIL** — Au moins une composante C_ij est hors tolérance, "
                  "OU les critères de stabilité de Born ne sont pas satisfaits. "
                  "Relancer le smoke P3 ou investiguer le fichier ``thermo_pw_run.out``.")
    elif verdict_count["WARN"] > 0:
        md.append("🟡 **WARN** — Toutes les composantes C_ij sont dans la zone ±10% vs littérature, "
                  "mais hors de la zone stricte ±5%. À investiguer si reproductible.")
    else:
        md.append("✅ **OK** — Toutes les composantes C_ij sont dans la zone ±5% vs "
                  "la littérature Si (C₁₁=167±8, C₁₂=65±3, C₄₄=80±4 GPa). "
                  "Critères de stabilité de Born satisfaits.")
    return "\n".join(md) + "\n"


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------

def _fail_err(msg: str, code: int = 3) -> int:
    print(f"[ERR] {msg}", file=sys.stderr)
    return code


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Extraire C_ij(V0,T) depuis un work_dir thermo_pw P3 et produire un résumé Markdown.",
    )
    p.add_argument("--work-dir", type=Path, required=False, default=None,
                   help="Dossier de run P3 (contient elastic_*.dat ou output_el_cons*.dat).")
    p.add_argument("--output", type=Path, required=False,
                   default=Path("/tmp/elastic_summary.md"),
                   help="Chemin du fichier Markdown produit (défaut: /tmp/elastic_summary.md).")
    p.add_argument("--synthetic", action="store_true",
                   help="Mode test : utilise une grille synthétique alignée sur la littérature Si.")
    p.add_argument("--units", choices=["auto", "kbar", "gpa"], default="auto",
                   help="Unité d'entrée des colonnes C_ij : 'auto' (heuristique mean > 100 ⇒ kbar), "
                        "'kbar' (force), 'gpa' (force).")
    p.add_argument("--print-only", action="store_true",
                   help="Imprime le Markdown sur stdout au lieu d'écrire dans --output.")
    args = p.parse_args(argv)

    if args.synthetic:
        rows = _synthetic_grid_si()
        src_paths: list[Path | str] = ["(synthetic-lit-Si-grid-2026-06)"]
        wd_label = str(args.work_dir) if args.work_dir else "(synthetic)"
    else:
        if args.work_dir is None or not args.work_dir.is_dir():
            return _fail_err(f"--work-dir requis (répertoire existant).", code=2)
        wd_label = str(args.work_dir)
        src_paths = _find_elastic_data_files(args.work_dir)
        rows = []
        for p_obj in src_paths:
            # Tente le parse direct (T-grid). Si vide, tente le fallback T=0K matrix.
            ext_rows = _parse_elastic_dat(p_obj, units=args.units)
            if ext_rows:
                rows.extend(ext_rows)
                continue
            t0 = _parse_output_el_cons(p_obj)
            if t0 is not None:
                rows.append((0.0, t0[0], t0[1], t0[2]))
        if not rows:
            return _fail_err(
                f"aucun C_ij(V,T) trouvé dans `{args.work_dir}` "
                f"(scanné : {[p.name for p in src_paths]}). "
                "P3 peut être encore en cours ou les fichiers sont mal formés.",
                code=3,
            )

    md = render_markdown_summary(wd_label, rows, src_paths)
    if args.print_only:
        print(md)
    else:
        args.output.write_text(md, encoding="utf-8")
        print(f"[OK] résumé Markdown écrit dans `{args.output}` ({len(md)} chars, {len(rows)} points T).")
    return 0


if __name__ == "__main__":
    sys.exit(main())

import sys
import time
import os

sys.path.insert(0, "/home/hiadsi/thermo_pw/backend")
from pipeline import PipelineJob  # noqa: E402

print(f"[T0 {time.strftime('%H:%M:%S')}] creating PipelineJob P1/Si", flush=True)
job = PipelineJob(
    material_id="Si",
    profile_id="P1",
    scf_in_basename="si_scf.in",
    nproc=2,
    properties_enabled=True,
)
print(f"[T0 {time.strftime('%H:%M:%S')}] job_id = {job.job_id}", flush=True)
print(f"[T0 {time.strftime('%H:%M:%S')}] calling start() (Thread daemon=True target=_execute)", flush=True)
job.start()
print(f"[T0+1s] work_dir = {job.work_dir}", flush=True)
print(f"[T0+1s] KEEPING PARENT ALIVE 1500s so the daemon thread can run _execute()", flush=True)
# 25 min : couvre SCF + thermo_pw elastic (6+ déformations) + chaîne NSCF+DOS+bandes.
time.sleep(1500)
print(f"[T_end {time.strftime('%H:%M:%S')}] parent sleep done; status = {job.status}", flush=True)

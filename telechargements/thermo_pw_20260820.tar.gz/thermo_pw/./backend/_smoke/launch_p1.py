import sys
import time

sys.path.insert(0, "/home/hiadsi/thermo_pw/backend")
from pipeline import PipelineJob  # noqa: E402

print(f"[T0 {time.strftime('%H:%M:%S')}] creating PipelineJob P1/Si", flush=True)
job = PipelineJob(
    material_id="Si",
    profile_id="P1",
    scf_in_basename="si_scf.in",
    nproc=2,
    properties_enabled=True,
)
print(f"[T0 {time.strftime('%H:%M:%S')}] PipelineJob created; calling start()", flush=True)
try:
    job.start()
    print(f"[T_end {time.strftime('%H:%M:%S')}] start() returned OK", flush=True)
except SystemExit as sx:
    print(f"[T_end {time.strftime('%H:%M:%S')}] start() called sys.exit({sx.code})", flush=True)
except Exception as ex:
    print(f"[T_end {time.strftime('%H:%M:%S')}] start() raised: {type(ex).__name__}: {ex}", flush=True)
    raise

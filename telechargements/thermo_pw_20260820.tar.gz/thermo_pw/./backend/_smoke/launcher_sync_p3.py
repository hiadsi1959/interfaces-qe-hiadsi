"""Smoke launcher P3 — Étude complète (Juin 2026).

P3 = ``what_qe = 'elastic_constants_geo'`` (canonique thermo_pw 7.x) sur grille T
0→1000 K avec ``use_free_energy=True`` + ``elastic_algorithm='energy'``. Dépend de
``needs_eos=True`` + ``needs_phonons=True`` : la chaîne interne lance l'EOS, puis
les phonons (q2r/matdyn), puis thermo_pw.x avec la grille T.

Sleep parent : 7200 s (2 h) — couvre largement la durée réelle (EOS ~5 min,
phonons grille ~10 min, thermo_pw QHA sur 21 pas de T ~25 min en séquentiel).

Usage::

    cd /home/hiadsi/thermo_pw/backend
    python3 -u _smoke/launcher_sync_p3.py

NE PAS toucher ``pipeline_P2_*`` côté disque pendant l'exécution.
"""
import sys
import time
import os

sys.path.insert(0, "/home/hiadsi/thermo_pw/backend")
from pipeline import PipelineJob  # noqa: E402

TS = lambda: time.strftime("%H:%M:%S")  # noqa: E731

print(f"[T0 {TS()}] creating PipelineJob P3/Si (QHA grille T 0->1000K)", flush=True)
job = PipelineJob(
    material_id="Si",
    profile_id="P3",
    scf_in_basename="si_scf.in",
    nproc=2,
    properties_enabled=True,
)
print(f"[T0 {TS()}] job_id = {job.job_id}", flush=True)
print(
    f"[T0 {TS()}] calling start() (Thread daemon=True target=_execute) — "
    f"chaîne : EOS → phonons → thermo_pw what='elastic_constants_geo' grille T",
    flush=True,
)
job.start()
print(f"[T0+1s] work_dir = {job.work_dir}", flush=True)
print(
    f"[T0+1s] KEEPING PARENT ALIVE 5400s (90 min) — heartbeat 5min + EOS+phonons+thermo_pw QHA",
    flush=True,
)
# P3 = EOS (~5 min) + grille phonons (~15 min) + thermo_pw 21 pas T (~30 min).
# 5400s = 90 min laisse la marge sur VM-cible sans gaspiller 30 min de wall clock.
# Heartbeat toutes les 300s : 18 itérations × 5min = 90 min ; si la chaîne crash
# silencieusement (job.status reste 'error'), on le voit dans /tmp/launcher_sync_p3.log.
for step in range(1, 19):
    time.sleep(300)
    print(
        f"[T+{step*5}min {TS()}] heartbeat job_id={job.job_id} status={job.status}",
        flush=True,
    )
print(f"[T_end {TS()}] parent sleep done; status = {job.status}", flush=True)

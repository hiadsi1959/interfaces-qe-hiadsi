#!/usr/bin/env python3
"""Verify P1 thermo extended metrics (α, Cp, Cv, F, S) on a work dir."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from pipeline import PipelineJob  # noqa: E402


def verify_work_dir(wd: Path) -> dict:
    job = PipelineJob(
        material_id="Si",
        profile_id="P1",
        scf_in_basename="si_scf.in",
        nproc=1,
        user_work_dir=str(wd),
    )
    job.work_dir = wd.resolve()
    job.status = "done"
    resp = job._intermediate_parse(wd, "verify_script")
    results = job.results or {}

    keys = [
        "thermo.debye_temperature_K",
        "thermo.Cv_300K_Ry_per_K",
        "thermo.F_300K_Ry",
        "thermo.entropy_300K_Ry_per_K",
        "thermo.alpha_300K_per_K",
        "thermo.Cp_300K_Ry_per_K",
        "thermo.alpha_source",
        "thermo.Cp_source",
        "elastic.bulk_modulus_GPa",
        "dielectric.epsilon_static_average",
        "dielectric.born_Z_star_n_atoms",
    ]

    def get(key: str):
        parts = key.split(".")
        cur = results
        for p in parts:
            if not isinstance(cur, dict):
                return None
            cur = cur.get(p)
        return cur

    metrics = {k: get(k) for k in keys}
    profile_metrics = [
        m["key"]
        for m in (job.profile.get("expected_results") or {}).get("metrics", [])
    ]
    present_in_profile = [k for k in keys if k in profile_metrics]

    return {
        "work_dir": str(wd),
        "job_id": job.job_id,
        "reparse_ok": bool(resp),
        "metrics": metrics,
        "profile_has_extended": all(
            k in profile_metrics
            for k in (
                "thermo.alpha_300K_per_K",
                "thermo.Cp_300K_Ry_per_K",
                "thermo.Cv_300K_Ry_per_K",
            )
        ),
        "present_in_profile": present_in_profile,
        "reparse_meta": (results.get("_reparse") or {}),
    }


if __name__ == "__main__":
    wd_arg = sys.argv[1] if len(sys.argv) > 1 else ""
    if not wd_arg:
        print("usage: verify_p1_additions.py <work_dir>", file=sys.stderr)
        sys.exit(2)
    out = verify_work_dir(Path(wd_arg).expanduser().resolve())
    print(json.dumps(out, indent=2, ensure_ascii=False))

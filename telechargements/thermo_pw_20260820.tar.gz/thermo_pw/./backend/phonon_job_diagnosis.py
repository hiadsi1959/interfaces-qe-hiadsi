"""
Indices d’échec pour jobs API QE phonons / q2r / matdyn — lecture courte des journaux sur disque.
Utilisé par GET /api/workflow1/eos/jobs/<id> lorsque status=error et kind concerné.
"""
from __future__ import annotations

import re
from pathlib import Path

# kinds gérés par api_server pour cette aide (non exhaustif ailleurs)
PHONON_QE_JOB_KINDS = frozenset(
    {
        "run_ph",
        "run_q2r",
        "phonon_bands_from_dynamical_matrices",
        "run_matdyn_bands",
        "run_matdyn_dos",
        "run_dynmat",
        "run_pp_charge",
    }
)

_TAIL_BYTES = 18_000


def _read_tail_utf8(path: Path, *, max_bytes: int = _TAIL_BYTES) -> str:
    try:
        sz = path.stat().st_size
    except OSError:
        return ""
    if sz <= 0:
        return ""
    read_n = min(max_bytes, sz)
    try:
        with path.open("rb") as f:
            if sz > read_n:
                f.seek(sz - read_n)
            raw = f.read()
    except OSError:
        return ""
    return raw.decode("utf-8", errors="replace")


def _voir_path_from_message(message: str, work_dir: Path) -> Path | None:
    m = re.search(r"\bvoir\s+(\S+)", message, flags=re.I)
    if not m:
        return None
    raw = m.group(1).strip().strip(".,;")
    p = Path(raw)
    if not p.is_absolute():
        p = work_dir / p
    try:
        return p if p.is_file() else None
    except OSError:
        return None


def _default_log_candidates(work_dir: Path, kind: str) -> list[Path]:
    k = (kind or "").strip().lower()
    if k == "run_ph":
        return [work_dir / "ph.out", work_dir / "ph_run.out"]
    if k == "run_q2r":
        return [work_dir / "q2r_from_dm.out", work_dir / "q2r.out", work_dir / "ph.out"]
    if k == "phonon_bands_from_dynamical_matrices":
        return [
            work_dir / "q2r_from_dm.out",
            work_dir / "matdyn_bands.out",
            work_dir / "phonon.freq",
        ]
    if k == "run_matdyn_bands":
        return [work_dir / "matdyn_bands.out", work_dir / "q2r.out", work_dir / "fc.out"]
    if k == "run_matdyn_dos":
        return [work_dir / "matdyn_dos.out", work_dir / "q2r.out"]
    if k == "run_dynmat":
        return [work_dir / "dynmat_run.out", work_dir / "dynmat_iface.out"]
    if k == "run_pp_charge":
        return [work_dir / "pp_charge.out"]
    return []


def _collect_diagnosis_text(work_dir: Path, kind: str, message: str) -> str:
    """Fusion message (souvent déjà avec extrait) + bout de journal disque pertinent."""
    parts: list[str] = [message or ""]
    seen: set[str] = set()

    vp = _voir_path_from_message(message or "", work_dir)
    paths: list[Path] = []
    if vp is not None:
        paths.append(vp)
    for cand in _default_log_candidates(work_dir, kind):
        if cand not in paths:
            paths.append(cand)

    for p in paths:
        key = str(p.resolve()) if p.is_file() else ""
        if not key or key in seen:
            continue
        if p.is_file():
            seen.add(key)
            tail = _read_tail_utf8(p)
            if tail.strip():
                parts.append(tail)

    combined = "\n".join(parts)
    if len(combined) > 48_000:
        return combined[-48_000:]
    return combined


def diagnosis_hint_for_phonon_qe_job(
    work_dir: Path | str,
    kind: str | None,
    message: str,
) -> str | None:
    """
    Retourne un paragraphe court (ou None) avec causes probables et actions,
    à partir du message d’erreur du job et des queues de journaux connues.
    """
    wd = Path(work_dir).expanduser().resolve()
    if not wd.is_dir():
        return None
    k = (kind or "").strip().lower()
    if k not in PHONON_QE_JOB_KINDS:
        return None

    msg = message or ""
    msg_l = msg.lower()
    blob_l = _collect_diagnosis_text(wd, k, msg).lower()

    hints: list[str] = []

    if "grille introuvable" in msg_l or "ph_dyn.g" in msg_l and "introuvable" in msg_l:
        hints.append(
            "Fichier de grille thermo_pw absent : vérifier le numéro de géométrie (souvent igeo=1) "
            "et que ph.x / thermo_pw a bien fini l’étape dynamique pour ce volume."
        )
    if "matrice dynamique attendue" in msg_l:
        hints.append(
            "Il manque des fichiers dynamical_matrices/ph_dyn.gN.M : relancer ph.x (ou la chaîne thermo_pw) "
            "jusqu’au bout, ou nettoyer un run partiel avant q2r."
        )
    if "absent" in msg_l and "q2r" in msg_l:
        hints.append("Lancer q2r.x (ou la chaîne « dynamical_matrices ») pour produire fc.out avant matdyn.")
    if "gnuplot" in msg_l:
        hints.append(
            "Étape graphique : installer gnuplot sur le serveur, vérifier que phonon.freq / phonon.dos existe "
            "et que le dossier du run est accessible en écriture."
        )
    if "fichier dynamique absent" in msg_l or "fichier dynamique" in msg_l and "absent" in msg_l:
        hints.append(
            "dynmat.x attend un vrai fichier de matrice (pas seulement l’en-tête de grille) — choisir ph_dyn en Γ "
            "ou matrice complète selon le guide §1.10."
        )

    if "convergence has not been achieved" in blob_l or "convergence not been achieved" in blob_l:
        hints.append(
            "DFPT : la boucle sur la réponse linéaire n’a pas convergé — converger fortement le SCF de référence, "
            "ajuster tr2_ph / énergie de coupure, vérifier smearing (métaux) et stabilité de la structure."
        )
    if "forrtl:" in blob_l or "severe (" in blob_l or "sigsegv" in blob_l:
        hints.append(
            "Plantage binaire Fortran / MPI : réduire le parallélisme, utiliser un scratch disque local, "
            "vérifier quotas et la cohérence des binaires QE avec les pseudopotentiels."
        )
    if "divide by zero" in blob_l and "frc_blk" in blob_l:
        hints.append(
            "matdyn / frc_blk (division par zéro) : souvent grille d’IFC trop grossière — densifier la grille q "
            "phonon ou régénérer fc.out ; voir aussi la note thermo_pw sur grilles 2×2×2."
        )
    if "error in routine" in blob_l:
        hints.append(
            "Quantum ESPresso signale une routine en erreur : lire la ligne « Error in routine … » en fin de journal "
            "et le fichier .out complet (chemins absolus dans le message serveur si présents)."
        )
    if "cannot open" in blob_l or "file not found" in blob_l:
        hints.append(
            "Fichier d’entrée ou pseudo introuvable : contrôler les chemins relatifs au dossier du run et la variable "
            "ESPRESSO/PSEUDO."
        )
    if "too many" in blob_l and "clock" in blob_l:
        hints.append(
            "Avertissements « Too many clocks » côté phonon : bruit fréquent ; si le job s’arrête quand même, "
            "chercher une autre erreur plus bas dans le journal."
        )

    # ph.out OK mais échec aval
    if k in ("run_q2r", "phonon_bands_from_dynamical_matrices"):
        ph_t = _read_tail_utf8(wd / "ph.out", max_bytes=8000)
        if "job done" in ph_t.lower() and ("fc.out" in msg_l or "q2r" in msg_l):
            if not any("ph.out" in h for h in hints):
                hints.append(
                    "Si ph.out se termine déjà par JOB DONE, isoler le problème côté q2r (liste des ph_dyn, cohérence "
                    "grille nq1×nq2×nq3, zasr)."
                )

    if not hints:
        hints.append(
            "Ouvrir les journaux du run (ph.out, q2r.out ou q2r_from_dm.out, matdyn_*.out) et vérifier « JOB DONE » "
            "ou la première ligne « Error in routine » — le champ log_file du job (si présent) pointe souvent le bon fichier."
        )

    # Déduplication en conservant l’ordre
    out: list[str] = []
    for h in hints:
        if h not in out:
            out.append(h)
    text = " ".join(out)
    if len(text) > 1200:
        text = text[:1197] + "…"
    return text

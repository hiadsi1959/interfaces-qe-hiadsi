"""
Inventaire des matériaux sous thermo_pw/inputs (optionnel : THERMO_MATERIAL_INPUTS_EXTRA).
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import config as cfg


def _score_in_name(name: str) -> int:
    n = name.lower()
    s = 0
    if "nscf" in n:
        s -= 10
    if "scf" in n and "nscf" not in n:
        s += 4
    if "vc-relax" in n or "vcrelax" in n or "vc_relax" in n:
        s += 3
    if "relax" in n and "vc" not in n:
        s += 2
    if n.endswith(".in"):
        s += 1
    return s


def list_in_files(mat_dir: Path) -> list[Path]:
    if not mat_dir.is_dir():
        return []
    out = [p for p in mat_dir.iterdir() if p.is_file() and p.suffix.lower() == ".in"]
    out.sort(key=lambda p: (-_score_in_name(p.name), p.name.lower()))
    return out


def default_template_for_material(mat_dir: Path) -> Optional[Path]:
    files = list_in_files(mat_dir)
    if not files:
        return None
    return files[0]


def extra_inputs_roots() -> list[Path]:
    roots: list[Path] = []
    raw = os.environ.get("THERMO_MATERIAL_INPUTS_EXTRA", "")
    for part in raw.split(os.pathsep if os.name != "nt" else ";"):
        p = part.strip()
        if p:
            r = Path(p).expanduser().resolve()
            if r.is_dir() and r not in roots:
                roots.append(r)
    return roots


@dataclass
class MaterialInfo:
    material_id: str
    source: str
    mat_dir: Path
    candidates: list[str]
    default_template: Optional[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "material_id": self.material_id,
            "source": self.source,
            "mat_dir": str(self.mat_dir.resolve()),
            "candidates": self.candidates,
            "default_template": self.default_template,
        }


def collect_materials() -> list[MaterialInfo]:
    """thermo_pw/inputs en priorité ; Interface-QE seulement pour les noms pas déjà listés."""
    out: list[MaterialInfo] = []
    seen_names: set[str] = set()

    def add_root(root: Path, source: str) -> None:
        if not root.is_dir():
            return
        for sub in sorted(root.iterdir(), key=lambda p: p.name.lower()):
            if not sub.is_dir() or sub.name.startswith("."):
                continue
            if sub.name in seen_names:
                continue
            cands = [str(p.name) for p in list_in_files(sub)]
            if not cands:
                continue
            seen_names.add(sub.name)
            dt = sub / cands[0] if cands else None
            out.append(
                MaterialInfo(
                    material_id=sub.name,
                    source=source,
                    mat_dir=sub,
                    candidates=cands,
                    default_template=str(dt.resolve()) if dt and dt.is_file() else None,
                )
            )

    cfg.INPUTS_DIR.mkdir(parents=True, exist_ok=True)
    add_root(cfg.INPUTS_DIR, "thermo_pw")
    for xr in extra_inputs_roots():
        add_root(xr, "interface_qe")
    return out


def _resolve_thermo_subdir(material_id: str) -> Optional[Path]:
    """
    Résout `inputs/<id>` (nom exact) ou, s’il n’existe pas, l’unique sous-dossier
    de même nom insensible à la casse (Linux : Si vs si).
    """
    mid = material_id.strip()
    if not mid or mid in (".", "..") or mid != Path(mid).name or "/" in mid or "\\" in mid:
        return None
    cfg.INPUTS_DIR.mkdir(parents=True, exist_ok=True)
    direct = (cfg.INPUTS_DIR / mid).resolve()
    try:
        direct.relative_to(cfg.INPUTS_DIR.resolve())
    except ValueError:
        return None
    if direct.is_dir():
        return direct
    key = mid.lower()
    matches = [
        p
        for p in cfg.INPUTS_DIR.iterdir()
        if p.is_dir() and not p.name.startswith(".") and p.name.lower() == key
    ]
    if len(matches) != 1:
        return None
    r = matches[0].resolve()
    try:
        r.relative_to(cfg.INPUTS_DIR.resolve())
    except ValueError:
        return None
    return r


def find_thermo_inputs_only(material_id: str) -> Optional[MaterialInfo]:
    """
    Dossier matériau **uniquement** sous `thermo_pw/inputs` (pas Interface-QE).
    Utilisé par le parcours guidé : on tape le nom, on liste les .in de ce seul répertoire.
    """
    sub = _resolve_thermo_subdir(material_id)
    if not sub or not sub.is_dir():
        return None
    cands = [str(p.name) for p in list_in_files(sub)]
    if not cands:
        return None
    canonical = sub.name
    dt = sub / cands[0]
    return MaterialInfo(
        material_id=canonical,
        source="thermo_pw",
        mat_dir=sub,
        candidates=cands,
        default_template=str(dt.resolve()) if dt.is_file() else None,
    )


def list_thermo_input_materials() -> list[MaterialInfo]:
    """Tous les matériaux qui ont au moins un .in dans `thermo_pw/inputs` seulement."""
    cfg.INPUTS_DIR.mkdir(parents=True, exist_ok=True)
    out: list[MaterialInfo] = []
    for sub in sorted(cfg.INPUTS_DIR.iterdir(), key=lambda p: p.name.lower()):
        if not sub.is_dir() or sub.name.startswith("."):
            continue
        m = find_thermo_inputs_only(sub.name)
        if m:
            out.append(m)
    return out


def find_material(material_id: str) -> Optional[MaterialInfo]:
    mid = material_id.strip()
    if not mid:
        return None
    for m in collect_materials():
        if m.material_id == mid:
            return m
    return None


def resolve_template(
    material_id: str, template_basename: Optional[str] = None
) -> Optional[Path]:
    m = find_material(material_id)
    if not m:
        return None
    if template_basename:
        p = (m.mat_dir / template_basename).resolve()
        if p.is_file() and p.suffix.lower() == ".in":
            return p
        return None
    if m.default_template:
        return Path(m.default_template).resolve()
    return None

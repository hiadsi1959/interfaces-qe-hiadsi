"""
Vérification des prérequis pour une étape type QHA (thermo_pw / mur_lc_t) : présence
des sorties phonons (3_phonon, ou ph/, dyn/ à la racine du work_dir) cohérentes avec
fildyn, et signaux d’instabilité (fréquences imaginaires) dans les journaux.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from eos_paths import EOS_VOLUMES_SUBDIR

# Noms reconnus : workflow thermo_pw (3_phonon) ou dossiers explicites ph/ dyn/
PHONON_DIR_CANDIDATES = ("3_phonon", "ph", "dyn")

# Lignes typiques d’une détection de fréquence instable (QE / matdyn) — on évite
# « negative » seul (charge, énergie…) en exigeant le contexte fréquence / phonon.
_IMAGINARY_RE = re.compile(
    r"(?:imaginary|soft\s+mode|unstable)"
    r"|(?:frequ?enc(?:y|ies)?|mode|omega|nu|ω|cm\*\*-1|thz|phonon).{0,40}negative"
    r"|negative.{0,40}(?:frequ?enc|mode|omega|nu|ω)"
    r"|frequ?enc.*<\s*0|omega.*<\s*0|warning.*(negative|imaginary).*(?:freq|phonon|mode)",
    re.IGNORECASE,
)


@dataclass
class QhaPrereqResult:
    ok: bool
    issues: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    details: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "issues": self.issues,
            "warnings": self.warnings,
            "details": self.details,
        }


def _phonon_root_dirs(work_dir: Path) -> list[Path]:
    roots: list[Path] = []
    for name in PHONON_DIR_CANDIDATES:
        p = work_dir / name
        if p.is_dir():
            roots.append(p)
    return roots


def _list_dyn_like_files(
    work_dir: Path, fildyn: str, *, under_eos_volumes: bool
) -> list[str]:
    """Chemins **relatifs** à work_dir, fichiers seulement."""
    out: list[str] = []
    fildyn = fildyn.strip() or "dyn"
    for root in _phonon_root_dirs(work_dir):
        for p in root.rglob(f"{fildyn}*"):
            if p.is_file() and p.suffix.lower() not in (".in", ".sh"):
                try:
                    out.append(str(p.relative_to(work_dir)))
                except ValueError:
                    out.append(str(p))
        for p in root.rglob("*.dyn*"):
            if p.is_file():
                try:
                    out.append(str(p.relative_to(work_dir)))
                except ValueError:
                    out.append(str(p))
    if under_eos_volumes:
        ev = work_dir / EOS_VOLUMES_SUBDIR
        if ev.is_dir():
            for p in ev.rglob(f"{fildyn}*"):
                if p.is_file() and p.suffix.lower() not in (".in", ".out"):
                    try:
                        out.append(str(p.relative_to(work_dir)))
                    except ValueError:
                        out.append(str(p))
            for p in ev.rglob("*.dyn*"):
                if p.is_file():
                    try:
                        out.append(str(p.relative_to(work_dir)))
                    except ValueError:
                        out.append(str(p))
    # Racine du run : ph_dyn*, dyn*, *.dyn* (sans sous-dossier ph/ ou 3_phonon/)
    for p in work_dir.glob(f"{fildyn}*"):
        if p.is_file() and p.suffix.lower() not in (".in", ".sh"):
            try:
                out.append(str(p.relative_to(work_dir)))
            except ValueError:
                out.append(str(p))
    for p in work_dir.glob("*.dyn*"):
        if p.is_file():
            try:
                out.append(str(p.relative_to(work_dir)))
            except ValueError:
                out.append(str(p))
    return sorted(set(out))


def _dyn_recursive_fallback(
    work_dir: Path, fildyn: str, *, max_hits: int = 420, max_depth: int = 14
) -> list[str]:
    """
    Sauve lorsque *.dyn ou {fildyn}* sont hors des dossiers usuels (3_phonon/, ph/, …).
    Parcours borné pour éviter de scanner tout l’arborescence EOS.
    """
    out: list[str] = []
    fildyn = fildyn.strip() or "dyn"
    wd = Path(work_dir).resolve()
    skip_roots = frozenset(
        {
            ".git",
            "__pycache__",
            ".venv",
            "venv",
            "node_modules",
        }
    )
    try:
        for dirpath, dirnames, filenames in os.walk(wd, topdown=True):
            pdir = Path(dirpath)
            try:
                rel_parts = pdir.relative_to(wd).parts
            except ValueError:
                continue
            depth = len(rel_parts)
            if depth > max_depth:
                dirnames[:] = []
                continue
            dirnames[:] = [
                d for d in dirnames if not d.startswith(".") and d not in skip_roots
            ]
            for fn in filenames:
                if len(out) >= max_hits:
                    return sorted(set(out))
                low = fn.lower()
                if low.endswith((".in", ".sh")):
                    continue
                if fn.startswith(fildyn) or ".dyn" in low:
                    fp = pdir / fn
                    if not fp.is_file():
                        continue
                    try:
                        out.append(str(fp.relative_to(wd)))
                    except ValueError:
                        out.append(str(fp))
    except OSError:
        pass
    return sorted(set(out))


def _log_files_under(work_dir: Path) -> list[Path]:
    paths: list[Path] = []
    for root in _phonon_root_dirs(work_dir):
        for p in root.rglob("*"):
            if not p.is_file():
                continue
            name = p.name.lower()
            if any(h in name for h in ("ph_run", "q2r", "matdyn")) and name.endswith(
                ".log"
            ):
                paths.append(p)
                continue
            if name in ("ph.out",) or (name.startswith("ph") and name.endswith(".out")):
                paths.append(p)
    return paths


def _line_looks_vibration_related(line: str) -> bool:
    low = line.lower()
    return any(
        k in low
        for k in (
            "freq",
            "phonon",
            "mode",
            "omega",
            "dynam",
            " dyn",
            "cm-1",
            "thz",
            "imagin",
        )
    )


def _scan_unstable_phrases_in_file(path: Path, limit_bytes: int = 800_000) -> list[str]:
    """
    Recherche de passages suspects. Limite de taille lue pour la perf.
    Filtre contextuel pour limiter « negative energy » en SCF, etc.
    """
    name_l = path.name.lower()
    is_phonon_log = any(
        h in name_l for h in ("ph_run", "q2r", "matdyn", "ph.x")
    ) or name_l.endswith(("_ph.out", "ph.out"))
    try:
        raw = path.read_bytes()
    except OSError:
        return []
    if len(raw) > limit_bytes:
        raw = raw[-limit_bytes:]
    try:
        text = raw.decode("utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        return []
    bad: list[str] = []
    for line in text.splitlines():
        if is_phonon_log or _line_looks_vibration_related(line):
            if _IMAGINARY_RE.search(line):
                t = line.strip()
                if len(t) > 200:
                    t = t[:200] + "…"
                bad.append(f"{path.name}: {t}")
    return bad


def _phonon_state_from_db(db: Any) -> Optional[str]:
    if db is None:
        return None
    try:
        raw = getattr(db, "tasks", None) or {}
        if "phonon" not in raw:
            return None
        t = db.get_task("phonon")
        return t.status if t else None
    except Exception:  # noqa: BLE001
        return None


def check_qha_prereqs(
    work_dir: Path,
    fildyn: str = "dyn",
    *,
    db: Any = None,
    under_eos_volumes: bool = True,
) -> QhaPrereqResult:
    """
    - Vérifie la présence de fichiers dynamiques (préfixe fildyn, *.dyn*) sous
      3_phonon/, ph/, dyn/, 1_eos_volumes/, racine puis parcours récursif borné.
    - Phonon en ERROR dans workflow_state : blocage seulement s'il n'y a aucun .dyn trouvé ;
      sinon avertissement (fichiers présents mais JSON obsolète).
    - Mots-clés « instables » dans les journaux phonon : avertissement seulement.
    """
    work_dir = Path(work_dir).resolve()
    issues: list[str] = []
    warnings: list[str] = []
    details: dict[str, Any] = {
        "work_dir": str(work_dir),
        "fildyn": fildyn,
        "phonon_roots": [str(p) for p in _phonon_root_dirs(work_dir)],
    }

    st = _phonon_state_from_db(db)
    if st:
        details["workflow_phonon_status"] = st

    roots = _phonon_root_dirs(work_dir)
    files = _list_dyn_like_files(
        work_dir, fildyn, under_eos_volumes=under_eos_volumes
    )
    if not files:
        files = _dyn_recursive_fallback(work_dir, fildyn)
        if files:
            details["dyn_discovered_via"] = "recursive_fallback"

    if st == "error":
        if files:
            warnings.append(
                "Tâche « phonon » en ERROR dans workflow_state.json — "
                "des fichiers dynamiques ont toutefois été trouvés ; si ph.x est correct, "
                "vous pouvez lancer thermo_pw (sinon mettez à jour ou supprimez workflow_state.json)."
            )
        else:
            issues.append(
                "Tâche « phonon » en ERROR dans workflow_state — corriger ph.x avant QHA/thermo."
            )

    details["dyn_like_files"] = files[:200]
    details["n_dyn_like_files"] = len(files)
    if not files:
        if not under_eos_volumes:
            issues.append(
                f"Aucun fichier dynamique (préfixe « {fildyn} » ou *.dyn*) et "
                f"1_eos_volumes/ est exclu de la recherche."
            )
        else:
            issues.append(
                f"Aucun fichier dynamique (préfixe « {fildyn} » ou *.dyn*) — dossiers usuels "
                "+ recherche récursive bornée depuis la racine du run. Lancez ph.x ou vérifiez fildyn dans ph.in / ph_control."
            )
    elif not roots:
        details["no_phonon_subdir"] = True
        warnings.append(
            "Aucun sous-dossier 3_phonon/, ph/ ou dyn/ — fildyn trouvé ailleurs (p. ex. 1_eos_volumes seulement). "
            "Valide si c’est volontaire."
        )

    unsteady: list[str] = []
    for logf in _log_files_under(work_dir):
        unsteady.extend(_scan_unstable_phrases_in_file(logf))
    details["unstable_log_hits"] = unsteady[:50]
    details["n_unstable_hits"] = len(unsteady)
    if unsteady:
        warnings.append(
            "Signaux possibles de fréquences négatives / imaginaires dans des journaux phonon — "
            "vérifiez avant QHA. Ne bloque plus le POST (ancien blocage trop fréquent). "
            + f"Exemple : {unsteady[0][:120]}…"
        )

    if st == "pending" and not issues:
        warnings.append(
            "Phonon en PENDING dans workflow_state — vérifier que ph.x a bien fini avant thermo."
        )

    ok = len(issues) == 0
    return QhaPrereqResult(ok=ok, issues=issues, warnings=warnings, details=details)


def enrich_mur_lc_driver_prereqs(res: QhaPrereqResult, work_dir: Path) -> None:
    """
    Contrôles supplémentaires pour ``thermo_pw.x`` avec ``what=mur_lc_t`` ou
    ``mur_lc_disp`` : ``ph_control`` / ``ph.in`` à la racine du run ; avertissement
    si ``fc.out`` manque (souvent requis après q2r avant matdyn/thermo).
    """
    work_dir = Path(work_dir).resolve()
    ph_ok = (work_dir / "ph_control").is_file() or (work_dir / "ph.in").is_file()
    res.details["has_ph_control"] = (work_dir / "ph_control").is_file()
    res.details["has_ph_dot_in"] = (work_dir / "ph.in").is_file()
    if not ph_ok:
        res.issues.append(
            "Aucun fichier ph_control ni ph.in à la racine du run — thermo_pw ne peut pas lire les entrées phonons (voir §1.8–1.9 ; l’API peut copier ph.in → ph_control au lancement si seul ph.in existe)."
        )
    if not (work_dir / "fc.out").is_file():
        res.warnings.append(
            "fc.out absent à la racine du run — souvent produit par q2r.x ; vérifiez que thermo_control / chemins pointent vers les constantes de force attendues."
        )
    res.ok = len(res.issues) == 0


def format_prereq_failure(res: QhaPrereqResult) -> str:
    parts = [i for i in res.issues]
    if res.warnings:
        parts.append("Avertissements : " + " | ".join(res.warnings))
    return " ".join(parts) if parts else "Prérequis QHA non satisfaits."


def main() -> int:
    import argparse
    import json

    p = argparse.ArgumentParser(
        description="Vérifie prérequis QHA/thermo (phonon / fildyn / journaux)."
    )
    p.add_argument(
        "work_dir",
        type=Path,
        help="Répertoire du workflow (ex. …/thermo_pw/work/Mat/wf1_eos_…)",
    )
    p.add_argument(
        "--fildyn",
        default="dyn",
        help="Racine fildyn (cohérente avec thermo_control, défaut: dyn)",
    )
    p.add_argument(
        "--no-eos-volumes",
        action="store_true",
        help="Ne pas chercher fildyn sous 1_eos_volumes/",
    )
    p.add_argument("--json", action="store_true", help="Sortie JSON sur stdout")
    args = p.parse_args()

    wd = args.work_dir.expanduser().resolve()
    if not wd.is_dir():
        err = json.dumps({"ok": False, "issues": [f"Pas un dossier : {wd}"]})
        print(err)
        return 1

    res = check_qha_prereqs(
        wd, fildyn=args.fildyn, db=None, under_eos_volumes=not args.no_eos_volumes
    )
    if args.json:
        print(json.dumps(res.as_dict(), indent=2, ensure_ascii=False))
    else:
        print(f"ok={res.ok}")
        for i in res.issues:
            print("  [issue]", i)
        for w in res.warnings:
            print("  [warn]", w)
    return 0 if res.ok else 2


if __name__ == "__main__":
    raise SystemExit(main())

"""
Chemins du workflow 1 (EOS) : le « dossier du run » est typiquement
``.../work/<M>/run_eos/<wf1_eos_...>/`` (nouveau) ou legacy ``.../work/<M>/<wf1_eos_...>/``.
Le sous-dossier des volumes SCF s’appelle 1_eos_volumes/. Si l’utilisateur (ou
l’UI) indique .../1_eos_volumes, il faut remonter à la racine du run pour ne pas
construire .../1_eos_volumes/1_eos_volumes.
"""
from __future__ import annotations

from pathlib import Path

EOS_VOLUMES_SUBDIR = "1_eos_volumes"
THERMO_PW_MAIN_LOG = "thermo_pw_run.out"
WORKFLOW_STATE_FILENAME = "workflow_state.json"


def wf1_resolve_dir_containing_thermo_log(p: Path) -> Path:
    """
    Si ``p`` est ``…/<run>/elastic_constants`` alors que ``thermo_pw_run.out`` est au parent,
    utilise le dossier du run (parent). Sinon renvoie ``p``.

    Évite les parses « vides » lorsque le champ dossier pointe vers le sous-dossier des sorties
    élasticités au lieu de la racine du run wf1_eos.
    """
    p = p.expanduser().resolve()
    log_here = p / THERMO_PW_MAIN_LOG
    if log_here.is_file():
        return p
    if p.name == "elastic_constants":
        parent = p.parent
        if (parent / THERMO_PW_MAIN_LOG).is_file():
            return parent
    return p


def wf1_eos_run_root(p: Path) -> Path:
    """
    Renvoie le dossier parent du run wf1_eos (celui qui contient 1_eos_volumes/
    et workflow_state.json), même si p pointe sur .../1_eos_volumes.
    """
    p = p.expanduser().resolve()
    while p.name == EOS_VOLUMES_SUBDIR and p.is_dir():
        p = p.parent
    return p

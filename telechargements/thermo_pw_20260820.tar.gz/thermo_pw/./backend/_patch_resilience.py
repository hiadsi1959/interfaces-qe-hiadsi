#!/usr/bin/env python3
"""Juillet 2026 - patcher P1..P4 résilience post-OOM-kill pour THERMO_PW.

Applique 4 patches sur 4 fichiers en une seule passe:
  P1 api_server.py     : scanner WORK_ROOT/**/pipeline_api_job_state.json au boot
  P2 app_v2.js         : backoff exponentiel + circuit breaker sur le polling
  P3 qe_subprocess.py  : helper _try_set_mem_rlimit() (les preexec_fn déjà posés)
  P3 api_server.py     : _process_memory_stats() + exposure dans /api/health
  P4 DEMARRER.sh       : si gunicorn dispo, l'utiliser en multi-threads

Idempotent: on skip si anchor absent (déjà patché).
Usage: cd backend && python3 _patch_resilience.py
"""
import sys
from pathlib import Path

ROOT = Path("/home/hiadsi/thermo_pw")


def patch(rel_path, old, new, *, expect_min=1, expect_max=1):
    p = ROOT / rel_path
    src = p.read_text(encoding="utf-8")
    cnt = src.count(old)
    if cnt == 0:
        print(f"  [SKIP] {rel_path}: anchor absent (deja patche ou variation de whitespace).")
        return False
    if cnt < expect_min or (expect_max is not None and cnt > expect_max):
        print(f"  [WARN] {rel_path}: count={cnt} attendu {expect_min}-{expect_max}")
    new_src = src.replace(old, new, 1)
    p.write_text(new_src, encoding="utf-8")
    print(f"  [OK]   {rel_path}: {cnt} match(s), 1 remplace.")
    return True


# ============================================================================
# 1. qe_subprocess.py - ajout de la DEF _try_set_mem_rlimit() helper.
# ============================================================================
# Les 4 sites preexec_fn=_try_set_mem_rlimit sur subprocess.run/Popen sont
# deja appliques (1ere str_replace). Il manque la DEFINITION - sans elle,
# NameError garanti au runtime. On insere le helper apres _API_CANCEL_RUNTIME_MSG.

HELPER_QE = '''

def _try_set_mem_rlimit() -> None:
    """Juillet 2026 (P3) - plafonner RLIMIT_AS du subprocess MPI (POSIX only).

    No-op silencieux si ``import resource`` indisponible (Windows) ou si
    ``cfg.MPI_RLIMIT_AS_BYTES`` vaut 0. Appelee via
    ``preexec_fn=_try_set_mem_rlimit`` du Popen ; executee dans le process enfant
    AVANT ``execve`` -> effet fige sur le binaire MPI (empeche thermo_pw.x
    de pousser l'OS a OOM-kill l'API).
    """
    if not getattr(cfg, "MPI_RLIMIT_AS_BYTES", 0):
        return
    try:
        import resource  # POSIX: absent sur Windows / containers verrouilles.
    except ImportError:
        return
    try:
        lim = int(cfg.MPI_RLIMIT_AS_BYTES)
        if lim > 0:
            resource.setrlimit(resource.RLIMIT_AS, (lim, lim))
    except (ValueError, OSError):
        pass


'''

QE_ANCHOR = "_API_CANCEL_RUNTIME_MSG = API_CANCEL_RUNTIME_MSG\n"
QE_NEW = "_API_CANCEL_RUNTIME_MSG = API_CANCEL_RUNTIME_MSG\n" + HELPER_QE

print("=== 1. qe_subprocess.py : helper definition _try_set_mem_rlimit ===")
patch("backend/qe_subprocess.py", QE_ANCHOR, QE_NEW, expect_min=1, expect_max=1)


# ============================================================================
# 2. app_v2.js - backoff exponentiel + circuit breaker
# ============================================================================
APP_JS_OLD = '''  async function startPolling(jobId) {
    if (state.pollTimer) clearInterval(state.pollTimer);
    const tick = async () => {
      try {
        const j = await window.ThermoPipeline.jobStatus(jobId);
        renderJobTick(j);
        if (["done", "error", "cancelled"].includes(j.status)) {
          stopPolling();
          finalizeJob(j);
        }
      } catch (e) {
        // Cas « stale » : le daemon a redémarré entre deux polls et l'in-memory
        // _REGISTRY ne contient plus ce job. Sans ce court-circuit, fetch.log
        // splammait `[ERR] polling : job_id inconnu` à chaque tick de 1.5 s
        // (parfois des dizaines de fois d'affilée) sans qu'on puisse relancer.
        // On stoppe le poll, on vide l'ID local, et on affiche UN message doux.
        if (e && e.staleJob === true) {
          stopPolling();
          state.currentJobId = "";
          appendLog(
            "[INFO] Job perdu : le serveur a redémarré (registre en mémoire effacé). Relancez le calcul pour reprendre.",
            "info"
          );
          // Met à jour le bouton « Lancer » qui se gate sur ``!state.currentJobId``.
          // C'est la fonction canonique (L300-318) qui re-évalue l'état UI quand
          // le champ currentJobId change - pas de garde ``typeof``, elle existe.
          updateLaunchButton();
          return;
        }
        appendLog(`[ERR] polling : ${e.message}`, "err");
      }
    };
    tick();
    state.pollTimer = setInterval(tick, POLL_INTERVAL_MS);
  }
  function stopPolling() {
    if (state.pollTimer) { clearInterval(state.pollTimer); state.pollTimer = null; }
  }'''

APP_JS_NEW = '''  // Juillet 2026 - P2 : scheduler a backoff exponentiel + circuit breaker.
  // Evite d'inonder le journal avec 150 « [ERR] polling : Failed to fetch »
  // pendant un crash silencieux de l'API (cf. OOM-kill ete 2026). Backoff :
  // 1.5 -> 3 -> 6 -> ... -> 30 s max. Au bout de 20 echecs consecutifs, polling
  // arrete avec un message unique. Premiere reponse OK -> reset compteur,
  // retour au rythme ``POLL_INTERVAL_MS``.
  const POLL_BACKOFF_CAP_MS = 30000;
  const POLL_BACKOFF_MAX_FAIL = 20;
  async function startPolling(jobId) {
    if (state.pollTimer) { clearInterval(state.pollTimer); state.pollTimer = null; }
    if (state.pollTimerTimeout) { clearTimeout(state.pollTimerTimeout); state.pollTimerTimeout = null; }
    state.pollFailCount = 0;
    const tick = async () => {
      try {
        const j = await window.ThermoPipeline.jobStatus(jobId);
        state.pollFailCount = 0;
        renderJobTick(j);
        if (["done", "error", "cancelled"].includes(j.status)) {
          stopPolling();
          finalizeJob(j);
          return;
        }
        state.pollTimerTimeout = setTimeout(tick, POLL_INTERVAL_MS);
      } catch (e) {
        // 404 sur /api/pipeline/jobs/<id> = registre en memoire vide (crash).
        if (e && e.staleJob === true) {
          stopPolling();
          state.currentJobId = "";
          appendLog(
            "[INFO] Job perdu : le serveur a redémarré (registre en mémoire effacé). Relancez le calcul pour reprendre.",
            "info"
          );
          updateLaunchButton();
          return;
        }
        state.pollFailCount = (state.pollFailCount || 0) + 1;
        if (state.pollFailCount >= POLL_BACKOFF_MAX_FAIL) {
          appendLog(
            "[ERR] polling : API inaccessible pendant ~" +
              Math.round(POLL_BACKOFF_CAP_MS * POLL_BACKOFF_MAX_FAIL / 60000) +
              " min (" + state.pollFailCount + " echecs consecutifs). " +
              "Polling suspendu. Rafraichissez la page quand l'API est de retour.",
            "err"
          );
          stopPolling();
          return;
        }
        const backoffMs = Math.min(
          POLL_INTERVAL_MS * Math.pow(2, Math.min(state.pollFailCount - 1, 6)),
          POLL_BACKOFF_CAP_MS
        );
        appendLog(
          "[ERR] polling : " + (e.message || String(e)) +
            " (retry #" + state.pollFailCount + " dans " +
            Math.round(backoffMs / 1000) + "s)",
          "err"
        );
        state.pollTimerTimeout = setTimeout(tick, backoffMs);
      }
    };
    tick();
  }
  function stopPolling() {
    if (state.pollTimer) { clearInterval(state.pollTimer); state.pollTimer = null; }
    if (state.pollTimerTimeout) { clearTimeout(state.pollTimerTimeout); state.pollTimerTimeout = null; }
  }'''

print("=== 2. app_v2.js : backoff + circuit breaker ===")
patch("interface/app_v2.js", APP_JS_OLD, APP_JS_NEW, expect_min=0, expect_max=1)


# ============================================================================
# 3. api_server.py - P1 (rehydrate) + P3 (memory stats) en /api/health
# ============================================================================
# 3a : modifier le body de /api/health pour inclure **mem_stats.
API_HEALTH_BODY_OLD = '''            "factsheet_ai_version": globals().get("_FACTSHEET_AI_VERSION", None),
            "factsheet_ai_compiled_at": globals().get("_FACTSHEET_AI_COMPILED_AT", None),
        }
    )'''

API_HEALTH_BODY_NEW = '''            "factsheet_ai_version": globals().get("_FACTSHEET_AI_VERSION", None),
            "factsheet_ai_compiled_at": globals().get("_FACTSHEET_AI_COMPILED_AT", None),
            # Juillet 2026 (P3) - metriques memoire process API pour detecter
            # les derives pre-OOM-kill (api_memory_vmpeak_mb > 4 GiB = alerte).
            **_process_memory_stats(),
        }
    )'''

print("=== 3a. api_server.py : /api/health etend avec _process_memory_stats() ===")
patch("backend/api_server.py", API_HEALTH_BODY_OLD, API_HEALTH_BODY_NEW, expect_min=0, expect_max=1)


# 3b : ajouter _process_memory_stats + _rehydrate_jobs_from_disk_marker
# AVANT @app.route("/api/health", ...). Le module-level call
# _rehydrate_jobs_from_disk_marker() s'execute au boot, AVANT les blueprints.

API_DEFINITIONS_BEFORE = '''def _process_memory_stats():
    """Juillet 2026 (P3) - metriques memoire process API pour precurseur OOM.

    Lit ``/proc/self/status`` (Linux / WSL2). No-op silencieux si ``/proc`` absent
    (Windows natif, conteneur verrouille) : renvoie ``None`` plutot que zero pour
    distinguer « non observable » de « 0 Mo ».

    Champs exposes cote ``/api/health`` :
      * ``api_memory_vmrss_mb``        - RSS courant (taille residente, en Mo)
      * ``api_memory_vmpeak_mb``       - Pic RSS depuis demarrage (en Mo)
      * ``api_memory_threads``         - Nombre de threads Python + OS

    Une remontee de ``api_memory_vmpeak_mb > 4 GiB`` doit alerter (signal precurseur
    d'un futur OOM-kill) - a brancher sur une Prometheus alert / Grafana plus tard.
    """
    try:
        with open("/proc/self/status", "r", encoding="utf-8", errors="replace") as f:
            stats = {}
            for line in f:
                if ":" in line and (
                    line.startswith("VmRSS:")
                    or line.startswith("VmPeak:")
                    or line.startswith("Threads:")
                ):
                    k, v = line.split(":", 1)
                    stats[k.strip()] = v.strip()
        rss_kb = int(stats.get("VmRSS", "0").split()[0])
        peak_kb = int(stats.get("VmPeak", "0").split()[0])
        threads = int(stats.get("Threads", "0").split()[0])
        return {
            "api_memory_vmrss_mb": round(rss_kb / 1024, 1),
            "api_memory_vmpeak_mb": round(peak_kb / 1024, 1),
            "api_memory_threads": threads,
        }
    except (OSError, ValueError, IndexError, AttributeError):
        return {
            "api_memory_vmrss_mb": None,
            "api_memory_vmpeak_mb": None,
            "api_memory_threads": None,
        }


def _rehydrate_jobs_from_disk_marker():
    """Juillet 2026 (P1) - resilience post-crash API.

    Scanne ``cfg.WORK_ROOT/**/pipeline_api_job_state.json`` au boot et logge un
    resume des statuts terminaux / orphelins ``running``. Ne peut PAS ressusciter
    le subprocess MPI perdu (mort avec le process parent) - la reprise effective
    reste manuelle via la section UI « Charger un calcul precedent » (les markers
    disque sont deja listes par ``/api/pipeline/runs``).

    But : informer l'operateur combien de jobs ont ete « absorbes » silencieusement
    par un crash, plutot qu'il ne decouvre la perte au prochain « Job perdu » 5 min
    plus tard en se demandant ce qui s'est passe.
    """
    try:
        work_root = cfg.WORK_ROOT.resolve()
    except (OSError, AttributeError):
        return
    if not work_root.is_dir():
        return
    recovered = {
        "done": 0, "error": 0, "cancelled": 0, "interrupted": 0,
        "running_orphan": 0, "queued_orphan": 0, "unreadable": 0,
    }
    try:
        marker_files = list(work_root.glob("**/pipeline_api_job_state.json"))
    except OSError:
        return
    for marker_path in marker_files:
        try:
            d = json.loads(marker_path.read_text(encoding="utf-8", errors="replace"))
        except (OSError, json.JSONDecodeError):
            recovered["unreadable"] += 1
            continue
        st = str(d.get("status") or "").lower()
        if st in ("done", "error", "cancelled", "interrupted"):
            recovered[st] = recovered.get(st, 0) + 1
        elif st in ("running", "queued"):
            recovered["running_orphan" if st == "running" else "queued_orphan"] += 1
    if any(v > 0 for v in recovered.values()):
        import logging
        logging.getLogger("thermo_pw.api").warning(
            "[Rebind] scan disque %s : %s - utilisez 'Charger un calcul precedent' pour les orphelins.",
            work_root,
            ", ".join(f"{k}={v}" for k, v in recovered.items() if v > 0),
        )


# P1 - appel au boot du module, AVANT les routes. Survit aux crashs silencieux :
# le warning marque la perte d'etat cote log serveur.
_rehydrate_jobs_from_disk_marker()


'''

API_ROUTE_OLD = '@app.route("/api/health", methods=["GET", "OPTIONS"])\ndef health():'
API_ROUTE_NEW = API_DEFINITIONS_BEFORE + '@app.route("/api/health", methods=["GET", "OPTIONS"])\ndef health():'

print("=== 3b. api_server.py : helpers + boot call ===")
patch("backend/api_server.py", API_ROUTE_OLD, API_ROUTE_NEW, expect_min=0, expect_max=1)


# ============================================================================
# 4. DEMARRER.sh - gunicorn wrapper (P4)
# ============================================================================
DEM_OLD = '''CMD=(env -i
    "PATH=${PATH}"
    "HOME=${HOME}"
    "PYTHONUNBUFFERED=1"
    "THERMO_HOST=${HOST}"
    "THERMO_API_PORT=${PORT}"
    "LD_LIBRARY_PATH=${LD_LIBRARY_PATH:-}")

if command -v setsid >/dev/null 2>&1; then
    # setsid : nouvelle session - process group independant, kill cible.
    "${CMD[@]}" setsid "$PYTHON_BIN" "$SCRIPT_DIR/backend/api_server.py" \\
        >"$LOG_FILE" 2>&1 &
    SERVER_PID=$!
else
    # Fallback macOS / BSD : pas de setsid disponible, on perd cette protection.
    (
        cd "$SCRIPT_DIR"
        "${CMD[@]}" "$PYTHON_BIN" backend/api_server.py
    ) >"$LOG_FILE" 2>&1 &
    SERVER_PID=$!
fi'''

DEM_NEW = '''CMD=(env -i
    "PATH=${PATH}"
    "HOME=${HOME}"
    "PYTHONUNBUFFERED=1"
    "THERMO_HOST=${HOST}"
    "THERMO_API_PORT=${PORT}"
    "LD_LIBRARY_PATH=${LD_LIBRARY_PATH:-}")

# Juillet 2026 - P4 : si gunicorn est installe (systeme ou via $PYTHON_BIN -m),
# on l'utilise en multi-threads pour eviter le dev server Flask mono-thread
# qui grippe les pollings clients pendant un run MPI lourd. THERMO_USE_GUNICORN=0
# force le fallback. Defaut : tenter gunicorn, fallback silencieux si non disponible.
USE_GUNICORN=0
GUNICORN_CMD=()
if [[ "${THERMO_USE_GUNICORN:-1}" != "0" ]]; then
    if command -v gunicorn >/dev/null 2>&1; then
        USE_GUNICORN=1
        GUNICORN_CMD=(gunicorn)
    elif "$PYTHON_BIN" -m gunicorn --version >/dev/null 2>&1; then
        USE_GUNICORN=1
        GUNICORN_CMD=("$PYTHON_BIN" -m gunicorn)
    fi
fi

if [[ "$USE_GUNICORN" == "1" ]]; then
    SERVER_PROG=( "${GUNICORN_CMD[@]}" --threads 4 --timeout 180 \\
        --bind "${HOST}:${PORT}" \\
        --access-logfile - --error-logfile - \\
        "$SCRIPT_DIR/backend/api_server:app" )
    printf "  ${C_DIM}WSGI${C_RESET}      : ${C_BOLD}gunicorn${C_RESET} (4 threads, timeout=180s)\\n"
else
    SERVER_PROG=( "$PYTHON_BIN" "$SCRIPT_DIR/backend/api_server.py" )
    printf "  ${C_DIM}WSGI${C_RESET}      : Flask dev (fallback - gunicorn introuvable; THERMO_USE_GUNICORN=1 requis si souhaite)\\n"
fi

if command -v setsid >/dev/null 2>&1; then
    # setsid : nouvelle session - process group independant, kill cible.
    "${CMD[@]}" setsid "${SERVER_PROG[@]}" \\
        >"$LOG_FILE" 2>&1 &
    SERVER_PID=$!
else
    # Fallback macOS / BSD : pas de setsid disponible, on perd cette protection.
    (
        cd "$SCRIPT_DIR"
        "${CMD[@]}" "${SERVER_PROG[@]}"
    ) >"$LOG_FILE" 2>&1 &
    SERVER_PID=$!
fi'''

print("=== 4. DEMARRER.sh : gunicorn wrapper ===")
patch("DEMARRER.sh", DEM_OLD, DEM_NEW, expect_min=0, expect_max=1)

print()
print("=== DONE - re-executer est idempotent (anchors absents = skip). ===")

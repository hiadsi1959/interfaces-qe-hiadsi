"""
``backend.factsheet`` — agrégateur de la **fiche technique** d'un run.

Profil-aware, lit le marker ``pipeline_api_job_state.json`` (sur disque après
redémarrage, ou marker live en mémoire) et expose deux sorties téléchargeables
via ::

  GET /api/pipeline/runs/<job_id>/factsheet?format=md     # Markdown
  GET /api/pipeline/runs/<job_id>/factsheet?format=html   # HTML

Aucun calcul MPI : on ne fait que **lire** des artefacts (scf.in écrit en work_dir,
marker JSON, valeurs déjà extraites par les parsers). Les sections présentes
dépendent du profil (P1..P5) et de la complétude du run :

* **En-tête** : job_id, profile_id, profile_name, material_id, work_dir, status,
  finished_at/created_at, what_qe, extras éventuels, p1_full_preset.
* **Équation d'état (Birch-Murnaghan)** : P2/P3/P4 — V₀, B₀, B′, E₀.
* **Constantes élastiques Cj** : P1/P3 (avec profil cubique ≈) — C₁₁/C₁₂/C₄₄
  + modules polycristallins (B, G, E, ν) + anisotropie Zener + ratios Pugh.
* **Propriétés électroniques** : TOUS les profils (ichamp≥2 si activé) —
  E_Fermi, gap, VBM, CBM, type (metal/zero_gap_semimetal/semiconductor),
  caractère direct/indirect, n_bands.
* **Magnétisme** : détecté depuis ``scf.in`` (regex ``nspin=2`` / ``starting_magnetization``
  par atome). Si détecté : moments magnétiques lus du SCF ; sinon : ligne
  « non magnétique » explicite.
* **Stabilité dynamique** : TOUS les profils — ``dynamically_stable``,
  ``n_imaginary_modes``, ``min_freq_cm-1`` (parsers P1..P5 — toujours présents
  en contrat UI, valeur ``None`` tolérée).
* **Durée de vie des phonons (anharmonicité)** : P4 — τ_min / τ_mean / τ_max,
  γ linewidth mean / max, κ_lattice moyen, paramètre de Grüneisen.
* **Tenseur diélectrique ε∞ + charges de Born Z*** : P5 — ε_xx/yy/zz moyenne
  et anisotropie, indice de réfraction, Z*_max_per_atom et liste d'atomes.
* **Propriétés étendues (P5 extras)** : plot_bz / piézoélectrique / χ magnétique
  / tenseur magnétoélectrique — selon ce qui a été coché dans l'UI.
* **Sanity-checks scientifiques** : hérite de ``sanity_checks.compute_sanity``
  (``phonon_imaginary`` / ``born_stability`` / ``poisson_ratio`` /
  ``eos_bprime`` / ``force_residual``).

Conventions de format :
* **Markdown** : niveau titre ``#`` racine, ``##`` sections, ``###`` sous-sections,
  tables en ``| col | col |`` + ligne d'alignement. Sections vides (parser
  indispo / jamais calculé) : ligne « *non calculé pour ce profil* » en
  italique — NE JAMAIS masquer une section possible côté UI.
* **HTML** : doc complet (``<!DOCTYPE html>``, ``<html lang="fr">``, ``<head>``
  avec ``<meta charset>`` + ``<title>`` + styles inline ``.ft-*`` pour rendu
  hors-ligne (LibreOffice / navigateur sans CSS jointe). Toutes les chaînes
  *user-controlled* sont échappées via ``html.escape``.

Ce module ne dépend QUE de la stdlib + ``sanity_checks`` (déjà importé en
backend). Pas d'I/O lourde sur disque : on lit le marker UNE fois, on scanne
scf.in au plus une fois (magnetism detection, ~Lecture bornée).
"""
from __future__ import annotations

import html
import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

# Imports locaux (backend/)
from sanity_checks import compute_sanity
from factsheet_ai import (
    Insight,
    compute_insights,
    render_insights_md as _render_ai_md,
    render_insights_html as _render_ai_html,
)
from phonon_imaginary_recommendations import (
    build_phonon_imaginary_recommendations,
)
# Parser C_ij(V0, T) (juillet 2026) — utilisé par ``_section_elastic_vs_T``
# pour P3 (profil ``elastic_constants_geo`` sur grille T 0→1000 K). Lecture
# à la demande, rétroactive sur runs P3 archivés.
from parsers.elastic_t_dat_scan import (
    find_elastic_t_dat,
    parse_numeric_series_dat,
)

# Cap de lecture pour scf.in (10 Mo est bien plus que n'importe quel template de
# production raisonnable ; au-delà, on n'inclut pas le contenu en mode démo).
_MAX_SCF_IN_BYTES = 10 * 1024 * 1024


# ============================================================================
# Backend PDF — lazy-import WeasyPrint
# ============================================================================
#
# On tente WeasyPrint (premier choix : pure-Python après cairo/pango/gdk-pixbuf
# côté système, conversion HTML+CSS→PDF la plus fidèle à notre HTML inline).
# Si ``import weasyprint`` lève : on marque le backend comme ``""`` (sentinelle
# cached) ; ``render_factsheet_pdf`` lèvera alors ``_PdfDependencyError`` et
# l'endpoint retournera un HTTP 503 avec un message d'installation.
#
# Pas de fallback pdfkit — wkhtmltopdf n'est pas dans l'image de référence et
# ajoute une dépendance binaire externe (Qt WebKit, sécurité SSL).
# Pas de fallback ReportLab — exigerait un 3e rendu complet qui désynchronise
# les trois formats. L'utilisateur a explicitement mentionné WeasyPrint/pdfkit ;
# ``render_factsheet_pdf`` documente le contrat côté utilisateur.

_PDF_BACKEND_NAME: Optional[str] = None  # None = non encore résolu ; "" = KO ; "weasyprint" = OK.

# ============================================================================
# Versioning visible — exposé via ``/api/health`` (bandeau UI)
# ============================================================================
# ``FACTSHEET_VERSION`` suit volontairement un schéma décimal ``MAJOR.MINOR``
# (``MAJOR`` incrémenté à chaque rupture de contrat, ``MINOR`` à chaque ajout
# de section profil-aware). Cette constante est réutilisée dans le footer de
# la fiche (« backend/factsheet.py v1.x ») ET exportée comme champ
# ``factsheet_version`` dans ``/api/health`` pour que l'UI puisse l'afficher
# dans un petit bandeau (sans appel HTTP supplémentaire vers le factsheet).
FACTSHEET_VERSION: str = "1.0"


def _module_compile_iso(path: Optional["Path"] = None) -> str:
    """Date locale ``YYYY-MM-DD`` (UTC) de la dernière écriture du fichier source.

    Sert de « md compiler date » pour le factsheet — traçable dans le git log
    (``git log --format=%ci backend/factsheet.py``). Le format court ISO date
    est directement consommable côté UI (``document.createTextNode``).

    Returns ``"—"`` si le fichier n'est pas accessible (cas extrême : ``__file__``
    pointe vers une archive zipimportée — rarissime).
    """
    target = Path(path or __file__).resolve()
    try:
        mtime = target.stat().st_mtime
    except OSError:
        return "—"
    return datetime.fromtimestamp(mtime, tz=timezone.utc).strftime("%Y-%m-%d")


class _PdfDependencyError(RuntimeError):
    """Levée quand aucun backend PDF n'est utilisable côté serveur.

    L'endpoint la convertit en HTTP 503 + JSON avec un guide d'installation.
    """


def _resolve_pdf_backend() -> Optional[str]:
    """Détecte WeasyPrint une seule fois (cache mémoïsé dans ``_PDF_BACKEND_NAME``).

    Returns:
        ``"weasyprint"`` si la lib est importable ; ``None`` sinon (lib absente
        OU native lib cairo/pango manquante — l'``import`` lève alors ``OSError``
        ou ``ImportError`` au chargement de ``weasyprint``.
    """
    global _PDF_BACKEND_NAME
    if _PDF_BACKEND_NAME is not None:
        return _PDF_BACKEND_NAME or None
    try:
        import weasyprint  # noqa: F401 — vérifie seulement l'import.
        _PDF_BACKEND_NAME = "weasyprint"
    except (ImportError, OSError):
        # ImportError : weasyprint non installé.
        # OSError       : weasyprint installé mais ses libs natives (cairo,
        # pango, gdk-pixbuf) ne se chargent pas — vue comme « backend KO ».
        _PDF_BACKEND_NAME = ""
    return _PDF_BACKEND_NAME or None


def render_factsheet_pdf(fs: "FactsheetSections") -> bytes:
    """Génère la fiche technique au format PDF (bytes bruts, MIME ``application/pdf``).

    Le HTML devient le *Intermediate Representation* commun : on réutilise
    ``render_factsheet_html(fs)`` (factorisation exigée par la demande
    utilisateur), puis on passe le ``str`` à WeasyPrint qui le rend en PDF
    en respectant les styles ``.ft-*`` inline.

    Raises:
        _PdfDependencyError: si WeasyPrint n'est pas utilisable côté serveur.
        RuntimeError: si WeasyPrint lève pendant l'écriture du PDF (typiquement
            un crash CSS ou un HTML malformé — devrait être rare car on génère
            le HTML depuis ``render_factsheet_html`` avec échappement strict).
    """
    backend = _resolve_pdf_backend()
    if not backend:
        raise _PdfDependencyError(
            "Backend PDF indisponible : ``weasyprint`` ne s'importe pas "
            "(lib Python absente OU libs natives Cairo/Pango manquantes). "
            "Installez ``pip install weasyprint`` puis vérifiez "
            "``apt-get install libcairo2 libpango-1.0-0 libgdk-pixbuf-2.0-0``."
        )
    html_src = render_factsheet_html(fs)
    if backend == "weasyprint":
        from weasyprint import HTML  # import paresseux — déjà testé via ``_resolve_pdf_backend``.
        try:
            return HTML(string=html_src, base_url="").write_pdf()
        except Exception as ex:  # noqa: BLE001 — surface tout crash côté WeasyPrint.
            raise RuntimeError(
                f"WeasyPrint a échoué pendant ``write_pdf`` : {ex}"
            ) from ex
    raise _PdfDependencyError(f"Backend PDF inconnu : {backend!r}")


# ============================================================================
# Détection magnétisme depuis scf.in
# ============================================================================

# Regex tolérantes : flags (?i) pour casse, D/d pour exponent Fortran, espaces
# optionnels autour du ``=``, virgule finale tolérée.
_RX_NSPIN = re.compile(
    r"(?im)^\s*nspin\s*=\s*(\d+)\b\s*,?\s*$"
)
_RX_NONCOLIN = re.compile(
    r"(?im)^\s*noncolin\s*=\s*\.(true|false)\.\s*,?\s*$"
)
_RX_STARTING_MAG = re.compile(
    r"(?im)^\s*starting_magnetization\s*\(\s*(\d+)\s*\)\s*=\s*"
    r"([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)"
)
_RX_NUP_NDOWN = re.compile(
    r"(?im)^\s*(?:nup|ndown)\s*=\s*([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)"
)
# --- Hubbard U (DFT+U) ---
_RX_LDA_PLUS_U = re.compile(
    r"(?im)^\s*lda_plus_u\s*=\s*\.(true|false)\.\s*,?\s*$"
)
_RX_HUBBARD_U = re.compile(
    r"(?im)^\s*Hubbard_U\s*\(\s*(\d+)\s*\)\s*=\s*"
    r"([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)"
)
_RX_HUBBARD_ALPHA = re.compile(
    r"(?im)^\s*Hubbard_alpha\s*\(\s*(\d+)\s*\)\s*=\s*"
    r"([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)"
)
_RX_HUBBARD_J = re.compile(
    r"(?im)^\s*Hubbard_J0?\s*\(\s*(\d+)\s*\)\s*=\s*"
    r"([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)"
)
_RX_U_PROJECTION_TYPE = re.compile(
    r"(?im)^\s*U_projection_type\s*=\s*['\"]?(\w+)['\"]?\s*,?\s*$"
)
# --- Non-collinear angles ---
_RX_ANGLE1 = re.compile(
    r"(?im)^\s*angle1\s*\(\s*(\d+)\s*\)\s*=\s*"
    r"([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)"
)
_RX_ANGLE2 = re.compile(
    r"(?im)^\s*angle2\s*\(\s*(\d+)\s*\)\s*=\s*"
    r"([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)"
)
_RX_CONSTRAINED_MAG = re.compile(
    r"(?im)^\s*constrained_magnetization\s*=\s*['\"]?([^'\",\s]+)['\"]?\s*,?\s*$"
)
_RX_TOT_MAGNETIZATION = re.compile(
    r"(?im)^\s*tot_magnetization\s*=\s*"
    r"([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)"
)


def detect_magnetism(work_dir: Path) -> dict[str, Any]:
    """Détecte un régime magnétique spin-polarisé et extrait moments ``starting_magnetization``.

    Détecte également :
      * ``nspin=2`` (colinéaire spin-polarisé) et ``nspin=4`` (non-colinéaire).
      * ``noncolin=.true.`` (flag non-colinéaire dans &SYSTEM).
      * Paramètres DFT+U / Hubbard : ``lda_plus_u``, ``Hubbard_U(i)``,
        ``Hubbard_alpha(i)``, ``Hubbard_J(i)``, ``U_projection_type``.
      * Angles non-colinéaires : ``angle1(i)``, ``angle2(i)``.
      * ``constrained_magnetization``, ``tot_magnetization``.
      * Classification automatique ferro / antiferro / ferrimagnétique.

    Retourne ::
        {
          "is_magnetic": bool,
          "nspin": Optional[int],          # 1, 2 ou 4
          "noncolin": bool,
          "starting_magnetization": list[float],  # par atome (ntyp paramètres)
          "nup_ndown": tuple[Optional[float], Optional[float]],
          "source_line": Optional[str],
          "detection_method": str,         # "nspin=2" | "nspin=4" | "starting_magnetization" | "nup/ndown" | "absent"
          "magnetic_order": Optional[str], # "ferromagnetic" | "antiferromagnetic" | "ferrimagnetic" | "non_collinear" | None
          "hubbard_u": {
              "lda_plus_u": bool,
              "Hubbard_U": dict[int, float],  # species index → U (eV)
              "Hubbard_alpha": dict[int, float],
              "Hubbard_J": dict[int, float],
              "U_projection_type": Optional[str],
          },
          "angle1": list[float],           # angles non-colinéaires θ (degrés)
          "angle2": list[float],           # angles non-colinéaires φ (degrés)
          "constrained_magnetization": Optional[str],
          "tot_magnetization": Optional[float],  # μ_B / maille
        }

    Robuste : si ``scf.in`` absent (run lancé sans work_dir), renvoie régime
    inconnu (``is_magnetic=False``, ``nspin=None``). Si plusieurs signaux
    ambigus (nspin=2 + nup/ndown), tous sont capturés (multi-source heuristique).
    """
    out: dict[str, Any] = {
        "is_magnetic": False,
        "nspin": None,
        "noncolin": False,
        "starting_magnetization": [],
        "nup_ndown": (None, None),
        "source_line": None,
        "detection_method": "absent",
        "magnetic_order": None,
        "hubbard_u": {
            "lda_plus_u": False,
            "Hubbard_U": {},
            "Hubbard_alpha": {},
            "Hubbard_J": {},
            "U_projection_type": None,
        },
        "angle1": [],
        "angle2": [],
        "constrained_magnetization": None,
        "tot_magnetization": None,
    }
    scf = work_dir / "scf.in"
    if not scf.is_file():
        return out
    try:
        size = scf.stat().st_size
        if size > _MAX_SCF_IN_BYTES:
            text = scf.read_text(encoding="utf-8", errors="replace")[:_MAX_SCF_IN_BYTES]
        else:
            text = scf.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return out
    if not text or not text.strip():
        return out

    # 1. nspin=2 ou nspin=4 ?
    m_nspin = _RX_NSPIN.search(text)
    if m_nspin:
        try:
            nspin_val = int(m_nspin.group(1))
            out["nspin"] = nspin_val
            if nspin_val in (2, 4):
                out["is_magnetic"] = True
                out["detection_method"] = f"nspin={nspin_val}"
        except (ValueError, IndexError):
            pass

    # 1b. noncolin ?
    m_nc = _RX_NONCOLIN.search(text)
    if m_nc:
        out["noncolin"] = m_nc.group(1).lower() == "true"

    # 2. starting_magnetization(i)=val ?
    sm_vals: list[float] = []
    sm_last_line: Optional[str] = None
    for m in _RX_STARTING_MAG.finditer(text):
        try:
            sm_vals.append(float(m.group(2).replace("D", "E").replace("d", "e")))
            if sm_last_line is None:
                sm_last_line = m.group(0)[:200]
        except (ValueError, IndexError):
            continue
    if sm_vals:
        max_abs = max(abs(v) for v in sm_vals)
        if not out["is_magnetic"]:
            if max_abs > 1e-6:
                out["is_magnetic"] = True
                out["detection_method"] = "starting_magnetization_nonzero"
        out["starting_magnetization"] = sm_vals
        out["source_line"] = sm_last_line or out.get("source_line")
        if out["detection_method"] == "absent" and (max_abs > 1e-6 or out["is_magnetic"]):
            out["detection_method"] = "starting_magnetization"

    # 3. nup, ndown (alternative à nspin=2)
    nup = ndown = None
    for m in _RX_NUP_NDOWN.finditer(text):
        try:
            v = float(m.group(1).replace("D", "E").replace("d", "e"))
        except (ValueError, IndexError):
            continue
        if m.group(0).lower().startswith("nup"):
            nup = v
        elif m.group(0).lower().startswith("ndown"):
            ndown = v
    if nup is not None or ndown is not None:
        out["nup_ndown"] = (nup, ndown)
        if (nup is not None) and (ndown is not None) and abs(nup - ndown) > 1e-6:
            if not out["is_magnetic"]:
                out["is_magnetic"] = True
                if out["detection_method"] == "absent":
                    out["detection_method"] = "nup/ndown"

    # 4. Classification magnétique (ferro / antiferro / ferri / non-colinéaire)
    if out.get("nspin") == 4 or out.get("noncolin"):
        out["magnetic_order"] = "non_collinear"
    elif sm_vals and len(sm_vals) >= 2:
        # Analyse du pattern de signes des starting_magnetization
        signs = [1 if v > 1e-6 else (-1 if v < -1e-6 else 0) for v in sm_vals]
        nonzero_signs = [s for s in signs if s != 0]
        if nonzero_signs:
            if all(s > 0 for s in nonzero_signs):
                out["magnetic_order"] = "ferromagnetic"
            elif all(s < 0 for s in nonzero_signs):
                out["magnetic_order"] = "ferromagnetic"  # tous même signe → FM
            elif len(set(nonzero_signs)) > 1:
                # Signes opposés → AFM ou ferrimagnétique
                sum_moments = sum(sm_vals)
                if abs(sum_moments) < 1e-6:
                    out["magnetic_order"] = "antiferromagnetic"
                else:
                    out["magnetic_order"] = "ferrimagnetic"
        else:
            out["magnetic_order"] = "ferromagnetic"  # moments tous nuls mais nspin=2
    elif sm_vals and len(sm_vals) == 1:
        out["magnetic_order"] = "ferromagnetic"

    # 5. Hubbard U (DFT+U)
    m_lda_u = _RX_LDA_PLUS_U.search(text)
    if m_lda_u:
        out["hubbard_u"]["lda_plus_u"] = m_lda_u.group(1).lower() == "true"
    hu_dict: dict[int, float] = {}
    for m in _RX_HUBBARD_U.finditer(text):
        try:
            idx = int(m.group(1))
            val = float(m.group(2).replace("D", "E").replace("d", "e"))
            hu_dict[idx] = val
        except (ValueError, IndexError):
            continue
    out["hubbard_u"]["Hubbard_U"] = hu_dict
    ha_dict: dict[int, float] = {}
    for m in _RX_HUBBARD_ALPHA.finditer(text):
        try:
            idx = int(m.group(1))
            val = float(m.group(2).replace("D", "E").replace("d", "e"))
            ha_dict[idx] = val
        except (ValueError, IndexError):
            continue
    out["hubbard_u"]["Hubbard_alpha"] = ha_dict
    hj_dict: dict[int, float] = {}
    for m in _RX_HUBBARD_J.finditer(text):
        try:
            idx = int(m.group(1))
            val = float(m.group(2).replace("D", "E").replace("d", "e"))
            hj_dict[idx] = val
        except (ValueError, IndexError):
            continue
    out["hubbard_u"]["Hubbard_J"] = hj_dict
    m_upt = _RX_U_PROJECTION_TYPE.search(text)
    if m_upt:
        out["hubbard_u"]["U_projection_type"] = m_upt.group(1).strip()

    # 6. Angles non-colinéaires
    a1_vals: list[float] = []
    for m in _RX_ANGLE1.finditer(text):
        try:
            a1_vals.append(float(m.group(2).replace("D", "E").replace("d", "e")))
        except (ValueError, IndexError):
            continue
    out["angle1"] = a1_vals
    a2_vals: list[float] = []
    for m in _RX_ANGLE2.finditer(text):
        try:
            a2_vals.append(float(m.group(2).replace("D", "E").replace("d", "e")))
        except (ValueError, IndexError):
            continue
    out["angle2"] = a2_vals

    # 7. Magnetization contrainte / totale
    m_cm = _RX_CONSTRAINED_MAG.search(text)
    if m_cm:
        out["constrained_magnetization"] = m_cm.group(1).strip()
    m_tm = _RX_TOT_MAGNETIZATION.search(text)
    if m_tm:
        try:
            out["tot_magnetization"] = float(
                m_tm.group(1).replace("D", "E").replace("d", "e")
            )
        except (ValueError, IndexError):
            pass

    return out


# ============================================================================
# Sanity-checks scientifiques (best-effort depuis results + work_dir)
# ============================================================================

def _sanity_section(work_dir: Path, results: dict[str, Any], profile_id: str) -> dict[str, Any]:
    """Appelle ``sanity_checks.compute_sanity`` avec strictement les champs nécessaires.

    ``compute_sanity`` consomme deux paramètres : ``work_dir`` (chemin run) et
    ``j_results`` (le sous-dict ``results`` du marker JSON). On lui passe aussi
    ``profile_id`` pour que les checks profil-aware (phonon_imaginary « non
    requis pour P1 ») puissent router correctement.
    """
    try:
        rep = compute_sanity(work_dir, results or {}, profile_id=profile_id or "")
    except Exception:  # noqa: BLE001
        return {"summary": {"score_text": "indisponible"}, "checks": []}
    return rep


# ============================================================================
# Helpers de format numérique
# ============================================================================

def _fmt(x: Any, *, n: int = 4) -> str:
    """Format numérique déterministe : float → décimal ou exponentiel selon l'amplitude."""
    if x is None:
        return "—"
    if isinstance(x, bool):
        return "True" if x else "False"
    if isinstance(x, (int,)):
        return str(x)
    if isinstance(x, float):
        if not (x == x):  # NaN
            # Juillet 2026 : "—" cohérent avec la convention None. Évite
            # le littéral "NaN" dans les tableaux MD/HTML (lisibilité).
            return "—"
        if abs(x) >= 1e4 or (x != 0 and abs(x) < 1e-3):
            return f"{x:.3e}"
        return f"{x:.{n}f}"
    return str(x)


def _unit_for(key: str, fallback: str = "") -> str:
    """Cartographie de clé → unité courte (alignée sur ``expected_results.metrics`` UI)."""
    k = key.lower()
    if "gpa" in k or any(s in k for s in ("bulk_modulus", "young_modulus", "shear_modulus", "_from_cij")):
        return "GPa"
    if "poisson" in k:
        return ""
    if "bohr" in k:
        return "bohr³"
    if "ry" in k and "k" not in k.split("_")[-1]:
        return "Ry"
    if "k" == k.split("_")[-1]:
        return "K"
    if any(s in k for s in ("lifetime_ps", "_ps")):
        return "ps"
    if any(s in k for s in ("linewidth", "freq_cm", "cm-1", "cm_")):
        return "cm⁻¹"
    if "_ev" in k:
        return "eV"
    if "w_mk" in k or "_kappa" in k:
        return "W/(m·K)"
    if "n_bands" in k or "n_modes" in k or "n_imaginary" in k:
        return ""
    if "z_star" in k or "_z" in k.split("_")[-2:]:
        return "e"
    if "ratio" in k or "anisotropy" in k or "refractive" in k or "direct" in k:
        return ""
    if "temperature" in k:
        return "K"
    return fallback


def _gap_nature_phrase(gap_type: Optional[str], gap_direct: Optional[bool]) -> str:
    """Phrase lisible pour la section « nature du gap »."""
    if gap_type is None:
        return "non calculé (ichamp≠2/3 ou chaîne DOS non lancée)"
    base = {
        "metal": "métallique (gap ≤ 0 eV)",
        "zero_gap_semimetal": "semi-métal à gap nul (gap ≈ 0 eV)",
        "semiconductor": "semi-conducteur",
        "insulator": "isolant (si critère empirique ajouté plus tard)",
    }.get(gap_type, gap_type)
    if gap_type == "semiconductor":
        if gap_direct is True:
            return f"{base} à gap **direct**"
        if gap_direct is False:
            return f"{base} à gap **indirect**"
    return base


# ============================================================================
# Assemblage principal
# ============================================================================

@dataclass
class FactsheetSections:
    """Agrégat typé retourné par ``assemble_factsheet``.

    Tous les ``list[(label, value, unit) | (label, value, unit, md_hint)]``
    sont sérialisés tels quels par les renderers Markdown/HTML ; leur contenu
    vide (``[]``) devient une ligne « *donnée non disponible* » au rendu.
    """

    header: dict[str, Any] = field(default_factory=dict)
    eos_rows: list[tuple[str, Any, str]] = field(default_factory=list)
    elastic_rows_exec: list[tuple[str, Any, str]] = field(default_factory=list)
    elastic_rows_poly: list[tuple[str, Any, str]] = field(default_factory=list)
    elastic_extra: list[tuple[str, Any, str]] = field(default_factory=list)
    # Juillet 2026 — P3 : C_ij(V₀, T) + modules VRH(T) + stabilité de Born.
    # Rempli par ``_section_elastic_vs_T`` à partir du fichier canonique
    # ``elastic_constants_vs_T.dat`` (lecture à la demande, pas de wire-in pipeline).
    # Schéma : voir docstring de ``_section_elastic_vs_T``.
    elastic_t_section: dict[str, Any] = field(default_factory=dict)
    electronic_rows: list[tuple[str, Any, str]] = field(default_factory=list)
    electronic_extra: list[tuple[str, Any, str]] = field(default_factory=list)
    magnetism_rows: list[tuple[str, Any, str]] = field(default_factory=list)
    # Stabilité unifiée — statique (Born, depuis sanity_checks) ET
    # dynamique (DFPT/phonons, depuis properties). Le but est d'afficher les
    # deux critères côte-à-côte (juillet 2026 — demande utilisateur :
    # « critère de stabilité dynamique à côté du critère de
    # stabilité statique »).
    stability_rows: list[tuple[str, Any, str]] = field(default_factory=list)
    stability_extra: list[tuple[str, Any, str]] = field(default_factory=list)
    dyn_stability_rows: list[tuple[str, Any, str]] = field(default_factory=list)
    # Juillet 2026 — Lorsque ``properties.n_imaginary_modes > 0``, on affiche
    # dans la fiche les **recommandations de vérification** générées par
    # ``phonon_imaginary_recommendations`` (pseudopotentiels XC, durcissement
    # tr2_ph, q-grid, ASR, cross-validation phonopy, etc.). Format
    # ``{title: str, body_md: str, action: str, priority: int, level: str,
    # category: str}`` — voir ``backend/phonon_imaginary_recommendations.py``.
    phonon_recommendations: list[dict[str, Any]] = field(default_factory=list)
    phonon_recommendation_context: dict[str, Any] = field(default_factory=dict)
    phonon_lifetime_rows: list[tuple[str, Any, str]] = field(default_factory=list)
    dielectric_rows: list[tuple[str, Any, str]] = field(default_factory=list)
    born_rows: list[tuple[str, Any, str]] = field(default_factory=list)
    extras_rows: list[tuple[str, Any, str]] = field(default_factory=list)
    # Juillet 2026 — α, Cp, Cv, F, S, ε₀… (grandeurs parsées, pas des fichiers).
    parsed_metrics_rows: list[tuple[str, Any, str]] = field(default_factory=list)
    # Statut couverture (Rempli / Absent / Prévu) — aligné panneau UI propertyGaps.
    extended_coverage_rows: list[tuple[str, Any, str]] = field(default_factory=list)
    plots_rows: list[tuple[str, Any, str]] = field(default_factory=list)  # E(V), bandes, DOS
    sanity_checks: list[dict[str, Any]] = field(default_factory=list)
    sanity_summary: dict[str, Any] = field(default_factory=dict)
    artifacts_rows: list[tuple[str, str, str]] = field(default_factory=list)  # (basename, relpath, kind)
    notes: list[str] = field(default_factory=list)
    # Insights « moteur expert » (factsheet_ai) — section « 🧠 Analyse experte »
    # au rendu. Liste vide ⇒ section rendue sous forme « Aucun insight
    # applicable ». Order déterministe géré par ``factsheet_ai.compute_insights``.
    ai_insights: list[Insight] = field(default_factory=list)


def _get(obj: Any, dotted: str, default: Any = None) -> Any:
    """``results.properties.fermi_eV`` → ``obj["results"]["properties"]["fermi_eV"]``.

    Accepte aussi : ``"properties.fermi_eV"`` → ``obj["properties"]["fermi_eV"]``.
    Segments vides ou ``None`` en chemin → fallback ``default``.
    """
    if obj is None:
        return default
    cur: Any = obj
    parts = [p for p in str(dotted or "").split(".") if p]
    for p in parts:
        if isinstance(cur, dict) and p in cur:
            cur = cur[p]
        else:
            return default
    return cur if cur is not None else default


def _get_gap_direct(results: dict[str, Any]) -> Optional[bool]:
    """Lit ``properties.gap_direct`` (pipeline) ou ``properties.band_gap_direct`` (legacy)."""
    v = _get(results, "properties.gap_direct")
    if v is None:
        v = _get(results, "properties.band_gap_direct")
    return v


def _enrich_results_from_workdir(
    work_dir: Optional[Path],
    results: dict[str, Any],
) -> dict[str, Any]:
    """Complète ``results`` depuis le disque si le marker JSON est périmé.

    Cas typique P1 : ``bands.dat`` + ``ebands.png`` présents mais
    ``properties.bands_ok=false`` / ``band_gap_eV=null`` dans le marker
    (bug ibrav corrigé après coup, retry non relancé).
    """
    if work_dir is None:
        return results or {}
    try:
        wd = Path(work_dir).resolve()
    except OSError:
        return results or {}
    if not wd.is_dir():
        return results or {}

    out = dict(results or {})
    props = dict(out.get("properties") or {})
    plots = dict(out.get("plots") or {})

    fermi = props.get("fermi_eV")
    if fermi is None and (wd / "nscf.out").is_file():
        try:
            from electronic_props import parse_nscf_fermi

            fermi = parse_nscf_fermi(wd)
            if fermi is not None:
                props["fermi_eV"] = fermi
        except Exception:  # noqa: BLE001
            pass

    bands_dat = wd / "bands.dat"
    need_gap = (
        bands_dat.is_file()
        and (props.get("band_gap_eV") is None or not props.get("bands_ok"))
    )
    if need_gap:
        try:
            from electronic_props import parse_bands_gap

            gp = parse_bands_gap(wd, fermi_eV=fermi)
            if gp.get("gap_eV") is not None:
                props["band_gap_eV"] = gp["gap_eV"]
                props["vbm_eV"] = gp.get("vbm_eV")
                props["cbm_eV"] = gp.get("cbm_eV")
                props["band_gap_type"] = gp.get("type")
                props["gap_direct"] = gp.get("direct")
                props["bands_ok"] = True
        except Exception:  # noqa: BLE001
            pass

    if not plots.get("ebands") and (wd / "ebands.png").is_file():
        plots["ebands"] = "ebands.png"
    if not plots.get("edos"):
        edos = props.get("edos_image") or (
            "edos.png" if (wd / "edos.png").is_file() else None
        )
        if edos:
            plots["edos"] = edos

    out["properties"] = props
    out["plots"] = plots

    # Juillet 2026 — thermo QHA / Debye + α, Cp dérivées (marker parfois périmé).
    try:
        thermo = dict(out.get("thermo") or {})
        from parsers.thermo_therm_dat import parse_therm_dat
        from parsers.thermo_derived import enrich_thermo_and_dielectric

        tdat = parse_therm_dat(wd)
        for k in (
            "zero_point_energy_Ry", "Cv_300K_Ry_per_K", "F_300K_Ry",
            "entropy_300K_Ry_per_K", "T_min_K", "T_max_K", "n_T_points",
            "debye_temperature_K",
        ):
            if thermo.get(k) is None and tdat.get(k) is not None:
                thermo[k] = tdat[k]
        if tdat.get("source_file") and not thermo.get("therm_source_file"):
            thermo["therm_source_file"] = tdat["source_file"]
        out["thermo"] = thermo
        enrich_thermo_and_dielectric(wd, out)
    except Exception:  # noqa: BLE001
        pass

    return out


def _section_eos(results: dict[str, Any], work_dir: Optional[Path] = None) -> list[tuple[str, Any, str]]:
    """Équation d'état Birch-Murnaghan (V₀, B₀, B′, E₀) + paramètre de maille a (Å).

    Visible P2/P3/P4. Si V₀ est disponible et ``work_dir`` fourni, calcule aussi
    le paramètre de maille a en Å à partir de ``ibrav`` lu dans ``scf.in``.
    """
    rows: list[tuple[str, Any, str]] = []
    for k_md, key in (
        ("V₀ (volume d'équilibre)", "V0_bohr3"),
        ("B₀ (module de compressibilité)", "B0_GPa"),
        ("B′ (dérivée de B₀)", "B0prime"),
        ("E₀ (énergie d'équilibre)", "E0_Ry"),
    ):
        v = _get(results, f"eos.{key}")
        if v is not None:
            rows.append((k_md, float(v), _unit_for(f"eos.{key}")))
    # Paramètres de maille (a, b, c, α, β, γ) depuis scf.in + V₀
    # Utilise ``_lattice_parameter_angstrom`` qui couvre cubique → triclinic
    # via ``celldm(1..6)`` ou via ``CELL_PARAMETERS`` (cas ibrav=0). Affiche
    # ``b``, ``c``, ``α``, ``β``, ``γ`` uniquement quand ils diffèrent de la
    # convention cubique (b = a, c = a, angles = 90°) — sinon la table reste
    # compacte.
    v0 = _get(results, "eos.V0_bohr3")
    if work_dir is not None:
        try:
            from factsheet_ai import _lattice_parameter_angstrom
            lat = _lattice_parameter_angstrom(Path(work_dir), v0_bohr3=float(v0) if v0 is not None else None)
            a_ang = lat.get("a_ang")
            if a_ang is not None:
                rows.append(("a", round(a_ang, 4), "Å"))
                b_ang = lat.get("b_ang")
                if b_ang is not None and abs(b_ang - a_ang) > 1e-4:
                    rows.append(("b", round(b_ang, 4), "Å"))
                c_ang = lat.get("c_ang")
                if c_ang is not None and abs(c_ang - (b_ang or a_ang)) > 1e-4:
                    rows.append(("c", round(c_ang, 4), "Å"))
                for ang_key, label in (("alpha_deg", "α"), ("beta_deg", "β"), ("gamma_deg", "γ")):
                    ang = lat.get(ang_key)
                    if ang is not None and abs(ang - 90.0) > 1e-2:
                        rows.append((label, round(ang, 3), "°"))
                src = lat.get("source") or ""
                if src == "v0_ibrav_guess":
                    rows.append(("  source (lattice)", "V₀ + hypothèse cubique (c=a, b=a, α=β=γ=90°)", ""))
                elif src == "cell_parameters":
                    rows.append(("  source (lattice)", "CELL_PARAMETERS (ibrav=0)", ""))
                elif src == "celldm":
                    rows.append(("  source (lattice)", "celldm(1..6)", ""))
                note = lat.get("note")
                if note:
                    rows.append(("  note", str(note)[:160], ""))
        except Exception:
            pass
    return rows


# ---------------------------------------------------------------------------
# Helpers P3 (juillet 2026) — modules VRH cubiques + stabilité de Born
# ---------------------------------------------------------------------------
# Pattern commun à ``_smoke/extract_elastic_vs_T.py`` : on réutilise ici les
# formules système cubique. Pas de dépendance externe — on garde la
# compatibilité avec le contrat VRH/Born déjà testé.


def _vrh_cubic(c11: float, c12: float, c44: float) -> dict[str, float]:
    """Modules polycristallins VRH pour cristal cubique (GPa, ν adim.).

    Formules (Hill average) :
      B    = (C₁₁ + 2·C₁₂) / 3
      G_V  = (C₁₁ − C₁₂ + 3·C₄₄) / 5
      G_R  = 5·(C₁₁ − C₁₂)·C₄₄ / (4·C₄₄ + 3·(C₁₁ − C₁₂))
      G    = (G_V + G_R) / 2  (Hill)
      E    = 9·B·G / (3·B + G)
      ν    = (3·B − 2·G) / (2·(3·B + G))

    Renvoie NaN (et non 0) si le dénominateur est non-positif (matériau
    mécaniquement instable — Born violé).
    """
    b = (c11 + 2.0 * c12) / 3.0
    g_v = (c11 - c12 + 3.0 * c44) / 5.0
    denom = 4.0 * c44 + 3.0 * (c11 - c12)
    g_r = 5.0 * (c11 - c12) * c44 / denom if denom > 0 else float("nan")
    g = (g_v + g_r) / 2.0
    e = 9.0 * b * g / (3.0 * b + g) if (3.0 * b + g) > 0 else float("nan")
    nu = (3.0 * b - 2.0 * g) / (2.0 * (3.0 * b + g)) if (2.0 * (3.0 * b + g)) > 0 else float("nan")
    return {
        "B_GPa": b, "G_V_GPa": g_v, "G_R_GPa": g_r,
        "G_Hill_GPa": g, "E_GPa": e, "nu": nu,
    }


def _born_stability_ok(
    c11: float, c12: float, c44: float,
) -> tuple[bool, list[str]]:
    """Critères de stabilité de Born pour cristal cubique (notation Voigt).

    Conditions nécessaires et suffisantes :
      * C₁₁ > 0 (rigidité longitudinale positive)
      * C₄₄ > 0 (rigidité de cisaillement positive)
      * C₁₁ > |C₁₂| (Born — cisaillement mécanique)
      * C₁₁ + 2·C₁₂ > 0 (compression isotrope possible)

    Returns:
        (ok, fails) : ``ok`` True si tous les critères sont satisfaits ;
        ``fails`` est la liste des messages d'erreur (vide si ok).
    """
    fails: list[str] = []
    if c11 <= 0:
        fails.append(f"C₁₁={c11:.2f} GPa ≤ 0")
    if c44 <= 0:
        fails.append(f"C₄₄={c44:.2f} GPa ≤ 0")
    if c11 <= abs(c12):
        fails.append(
            f"C₁₁={c11:.2f} ≤ |C₁₂|={abs(c12):.2f} GPa"
            f" (mécaniquement instable)"
        )
    if c11 + 2.0 * c12 <= 0:
        fails.append(
            f"C₁₁+2·C₁₂={c11 + 2.0 * c12:.2f} GPa ≤ 0"
            f" (compression impossible)"
        )
    return (len(fails) == 0, fails)


def _section_elastic_vs_T(work_dir: Optional[Path]) -> dict[str, Any]:
    """Section P3/P4 — C_ij(V₀, T) sur la grille 0→1000 K.

    Lecture à la demande du fichier canonique ``elastic_constants_vs_T.dat``
    (ou variantes ``elastic_vs_T.dat`` / ``elastic_vs_temperature.dat`` /
    ``c_ij_T.dat`` / ``output_el_cons*.dat``) via
    ``parsers.elastic_t_dat_scan.find_elastic_t_dat`` +
    ``parse_numeric_series_dat``.

    Avantage : pas de wire-in pipeline — fonctionne rétroactivement sur
    tous les runs P3 archivés. Auto-détection kbar → GPa
    (heuristique mean |C_ij| > 100).

    Returns:
        dict structuré :
          * ``rows``       : list[(T, C₁₁, C₁₂, C₄₄)] en GPa
          * ``vrh``        : list[(T, {B, G_V, G_R, G_Hill, E, ν})]
          * ``born``       : dict[int, (ok, fails)]  (Born aux bornes 0 K et T_max)
          * ``t_min``, ``t_max``, ``n_points``
          * ``is_cubic``   : True si exactement 4 colonnes T + C₁₁ + C₁₂ + C₄₄
          * ``units_were_kbar`` : True si conversion kbar→GPa appliquée
          * ``path``       : chemin du .dat source (debug)
          * ``error``      : message d'erreur éventuel (None si OK)

        Si work_dir invalide / fichier absent : dict avec ``rows=[]``,
        ``error`` rempli.
    """
    out: dict[str, Any] = {
        "rows": [], "vrh": [], "born": {},
        "t_min": None, "t_max": None, "n_points": 0,
        "is_cubic": False, "units_were_kbar": False,
        "path": None, "error": None,
    }
    if work_dir is None:
        out["error"] = "work_dir is None"
        return out
    try:
        dat_path = find_elastic_t_dat(Path(work_dir))
    except Exception as ex:  # noqa: BLE001
        out["error"] = f"find_elastic_t_dat: {ex!r}"
        return out
    if dat_path is None:
        out["error"] = "no elastic_t dat found"
        return out
    out["path"] = str(dat_path)
    try:
        parsed = parse_numeric_series_dat(dat_path)
    except Exception as ex:  # noqa: BLE001
        out["error"] = f"parse_numeric_series_dat: {ex!r}"
        return out
    if parsed.get("error") or not parsed.get("rows"):
        out["error"] = parsed.get("error") or "no rows"
        return out
    raw_rows: list[list[Optional[float]]] = parsed["rows"]
    ncol: int = int(parsed.get("ncol") or 0)
    if ncol < 4:
        out["error"] = f"ncol={ncol} (< 4 colonnes Cij)"
        return out
    # Auto-détection unités (heuristique mean |C_ij| > 100 ⇒ kbar).
    flat_c: list[float] = []
    for r in raw_rows:
        for v in r[1:4]:
            if v is not None:
                flat_c.append(float(v))
    if not flat_c:
        out["error"] = "all Cij values are None"
        return out
    mean_abs = sum(abs(v) for v in flat_c) / len(flat_c)
    # Heuristique kbar vs GPa (juillet 2026, révisée) : seuil 1000
    # évite les faux positifs sur matériaux durs (diamant C₁₁≈1076 GPa, BN≈820 GPa).
    # thermo_pw output_el_cons*.dat en kbar donne C₁₁ typiquement > 1000 kbar.
    scale = 0.1 if mean_abs > 1000.0 else 1.0
    out["units_were_kbar"] = (scale != 1.0)
    # Construction des lignes (T, C₁₁, C₁₂, C₄₄) en GPa.
    rows_gpa: list[tuple[float, float, float, float]] = []
    vrh_per_t: list[tuple[float, dict[str, float]]] = []
    for r in raw_rows:
        try:
            t = float(r[0])  # type: ignore[arg-type]
            c11 = float(r[1]) * scale  # type: ignore[arg-type]
            c12 = float(r[2]) * scale  # type: ignore[arg-type]
            c44 = float(r[3]) * scale  # type: ignore[arg-type]
        except (TypeError, ValueError, IndexError):
            continue
        if any(map(lambda x: x != x, (t, c11, c12, c44))):  # NaN guard
            continue
        rows_gpa.append((t, c11, c12, c44))
        vrh_per_t.append((t, _vrh_cubic(c11, c12, c44)))
    if not rows_gpa:
        out["error"] = "all rows filtered out (NaN/None)"
        return out
    rows_gpa.sort(key=lambda x: x[0])
    vrh_per_t.sort(key=lambda x: x[0])
    # Système cubique strict : 4 colonnes (T, C₁₁, C₁₂, C₄₄).
    # Si >4 colonnes, on ne peut PAS garantir que les colonnes 2:5 soient
    # C₁₁/C₁₂/C₄₄ (réseau non-cubique : tétragonal=6 cols,
    # orthorhombique=9 cols, hexagonal=6 cols). On désactive rows + vrh + born
    # (intégrité des données : ne pas montrer de Cij bidon à l'utilisateur).
    out["is_cubic"] = ncol == 4
    if not out["is_cubic"]:
        out["rows"] = []
        out["vrh"] = []
        out["born"] = {}
        out["error"] = (
            f"grille non-cubique (ncol={ncol} ≠ 4) : "
            f"VRH/Born non applicables, Cij(T) masqué pour intégrité"
        )
        # On garde n_points/t_min/t_max pour signaler la présence de la grille
        # dans le panneau AI (cf. followup #6 reviewer).
        out["n_points"] = len(rows_gpa)
        if rows_gpa:
            out["t_min"] = rows_gpa[0][0]
            out["t_max"] = rows_gpa[-1][0]
        return out
    out["rows"] = rows_gpa
    out["vrh"] = vrh_per_t
    out["is_cubic"] = ncol == 4
    if out["is_cubic"]:
        c_first = rows_gpa[0]
        c_last = rows_gpa[-1]
        out["born"][0] = _born_stability_ok(c_first[1], c_first[2], c_first[3])
        out["born"][int(c_last[0])] = _born_stability_ok(c_last[1], c_last[2], c_last[3])
    out["t_min"] = rows_gpa[0][0]
    out["t_max"] = rows_gpa[-1][0]
    out["n_points"] = len(rows_gpa)
    return out


def _section_elastic(results: dict[str, Any]) -> tuple[
    list[tuple[str, Any, str]],
    list[tuple[str, Any, str]],
    list[tuple[str, Any, str]],
]:
    """Trois sous-sections : Cj cubiques si dispo / modules polycristallins /
    extras (anisotropie Zener, Zener ratio, Pugh)."""
    cij: list[tuple[str, Any, str]] = []
    for k_md, key in (
        ("C₁₁", "C11_GPa"),
        ("C₁₂", "C12_GPa"),
        ("C₄₄", "C44_GPa"),
    ):
        v = _get(results, f"elastic.{key}")
        if v is not None:
            cij.append((k_md, float(v), "GPa"))
    poly: list[tuple[str, Any, str]] = []
    for k_md, key in (
        ("B (VRH)", "bulk_modulus_GPa"),
        ("G (VRH)", "shear_modulus_GPa"),
        ("E (VRH)", "young_modulus_GPa"),
        ("ν (Poisson)", "poisson_ratio"),
    ):
        v = _get(results, f"elastic.{key}")
        if v is not None:
            unit = _unit_for(f"elastic.{key}")
            poly.append((k_md, float(v), unit))
    extra: list[tuple[str, Any, str]] = []
    # Provenance C_ij (badge forward-compat : si la cle est absente/None/None
    # reconnue, la ligne n'est PAS ajoutee -> 0 regression sur anciens markers).
    _es_src = _get(results, "elastic.source")
    if _es_src in ("fallback_per_strain_gN", "aggregated_vs_T"):
        _es_bad = (
            "badge-warning" if _es_src == "fallback_per_strain_gN"
            else "badge-success"
        )
        _es_lbl = (
            "Aper\u00e7u partiel" if _es_src == "fallback_per_strain_gN"
            else "Donn\u00e9es finales"
        )
        # On injecte un tuple dont la ``value`` est du HTML brut portant la
        # classe CSS ``badge``, reconnue par ``_format_table_html`` (bypass
        # ``html.escape``) et nettoyee par ``_format_table_md`` (texte court).
        extra.insert(0, (
            "Provenance",
            f'<span class="badge {_es_bad}">{_es_lbl}</span>',
            "",
        ))
    for key in ("zener_anisotropy_ratio_A", "pugh_BG_ratio_from_Hill_G"):
        v = _get(results, f"elastic.{key}")
        if v is not None:
            extra.append((key, float(v), ""))
    # Si profil cubique et un seul C₁₁/C₁₂/C₄₄ lit, on le marque.
    return cij, poly, extra


def _section_electronic(results: dict[str, Any]) -> tuple[
    list[tuple[str, Any, str]],
    list[tuple[str, Any, str]],
]:
    """E_Fermi, gap, VBM, CBM, type, direct/indirect, n_bands, bands_ok.

    Juillet 2026 — ajout de ``bands_ok`` (flag « la chaîne pw_bands + bands.x
    a-t-elle abouti ? ») en première ligne. Combiné à ``Gap VBM→CBM``, le
    lecteur voit immédiatement si une valeur de gap affichée est fiable :
    ``bands_ok = True`` ⇒ gap trustable ; ``bands_ok = False`` ⇒ à interpréter
    avec prudence (chaîne électronique partiellement tombée — ``run_electronic_
    properties`` n'a pas convergé).
    """
    rows: list[tuple[str, Any, str]] = []
    # bands_ok : vert de confiance pour tous les autres nombres de la section.
    bands_ok = _get(results, "properties.bands_ok")
    if bands_ok is not None:
        rows.append(("Bandes calculées OK (bands.x)", bool(bands_ok), ""))
    fermi = _get(results, "properties.fermi_eV")
    if fermi is not None:
        rows.append(("E_Fermi", float(fermi), "eV"))
    n_bands = _get(results, "properties.n_bands")
    if n_bands is not None:
        rows.append(("Bandes Kohn–Sham", int(n_bands), ""))
    gap_eV = _get(results, "properties.band_gap_eV")
    gap_type = _get(results, "properties.band_gap_type")
    gap_direct = _get_gap_direct(results)
    extra: list[tuple[str, Any, str]] = []
    if gap_eV is not None:
        rows.append(("Gap VBM→CBM", float(gap_eV), "eV"))
        vbm = _get(results, "properties.vbm_eV")
        cbm = _get(results, "properties.cbm_eV")
        if vbm is not None:
            extra.append(("VBM", float(vbm), "eV"))
        if cbm is not None:
            extra.append(("CBM", float(cbm), "eV"))
    if gap_type is not None or gap_direct is not None:
        extra.append(("Nature du gap", _gap_nature_phrase(gap_type, gap_direct), ""))
    m_eff = _get(results, "properties.effective_mass_m0")
    if m_eff is not None:
        extra.append(("Masse effective m* (m₀)", float(m_eff), ""))
    elif rows or fermi is not None:
        extra.append(("Masse effective m*", "non calculée (non implémenté)", ""))
    dos_ok = _get(results, "properties.dos_ok")
    if dos_ok is not None:
        extra.append(("DOS totale (dos.x)", "OK" if bool(dos_ok) else "échec / absent", ""))
    return rows, extra


def _section_dyn_stability(results: dict[str, Any]) -> list[tuple[str, Any, str]]:
    rows: list[tuple[str, Any, str]] = []
    ds = _get(results, "properties.dynamically_stable")
    if ds is not None:
        rows.append(("Stable dynamiquement", bool(ds), ""))
    nm = _get(results, "properties.n_imaginary_modes")
    if nm is not None:
        rows.append(("Modes imaginaires", int(nm), ""))
    minw = _get(results, "properties.min_freq_cm-1")
    if minw is not None:
        rows.append(("ω_min (mode acoustique le plus mou)", float(minw), "cm⁻¹"))
    return rows


def _section_stability(
    results: dict[str, Any],
    sanity_checks: list[dict[str, Any]],
) -> tuple[
    list[tuple[str, Any, str]],
    list[tuple[str, Any, str]],
]:
    """**Stabilité unifiée** — statique (Born via sanity_checks) + dynamique (phonons DFPT).

    Juillet 2026 — refonte (demande utilisateur : « le critère de stabilité
    dynamique à côté du critère de stabilité statique »). On expose les deux
    critères dans la même section 5 de la fiche pour faciliter la lecture :

      * **Statique (Born)** : vert si ``sanity_checks.born_stability.level == "ok"``,
        rouge si ``level == "error"``. Sinon (warn/unknown) : orange/gris.
      * **Dynamique (phonons)** : vert si ``properties.dynamically_stable``,
        rouge si ``False``.

    Sources :
      * Statique : ``sanity_checks`` (résultat de ``compute_sanity``) qui lit
        ``j_results["elastic"]["elastic_cubic_independent_Gpa"]``.
      * Dynamique : ``results["properties"]["dynamically_stable"]`` (parsé
        par ``phonon_chain_qe.parse_matdyn_dynamic_stability``).

    Returns ``(rows, extra)`` :
      * ``rows`` : 2 lignes minimales (Statique OK?, Dynamique OK?) + lignes
        conditionnelles (``C₁₁−C₁₂ > 0``, ``ω_min``, ``n_imaginary_modes``).
      * ``extra`` : marge minimale Born (GPa), ``ω_min`` (cm⁻¹), message
        d'origine si pertinent.
    """
    rows: list[tuple[str, Any, str]] = []
    extra: list[tuple[str, Any, str]] = []

    # --- 1. Stabilité statique (Born) --------------------------------------
    born = next(
        (c for c in (sanity_checks or []) if c.get("id") == "born_stability"),
        None,
    )
    if born is not None:
        lvl = str(born.get("level") or "unknown").lower()
        # Vert = ok ; rouge = error ; sinon : orange warn / gris unknown.
        if lvl == "ok":
            born_pass = True
            label = "✅ Born OK"
        elif lvl == "error":
            born_pass = False
            label = "❌ Born violé"
        elif lvl == "warn":
            born_pass = None
            label = "⚠ Born OK (marges faibles)"
        else:
            born_pass = None
            label = "? Born indéterminé"
        rows.append(("Stabilité statique (critère de Born, Cij)", label, ""))
        # Affichage conditions de Born directement.
        bvalue = born.get("value")
        if isinstance(bvalue, dict):
            try:
                c11 = float(bvalue.get("C11_GPa"))
                c12 = float(bvalue.get("C12_GPa"))
                c44 = float(bvalue.get("C44_GPa"))
                marg_signed = {
                    "C₁₁ − C₁₂ (GPa)": c11 - c12,
                    "C₁₁ + 2·C₁₂ (GPa)": c11 + 2.0 * c12,
                    "C₄₄ (GPa)": c44,
                }
                for k, v in marg_signed.items():
                    rows.append((f"  {k}", round(v, 3), "GPa"))
                min_margin = min(abs(v) for v in marg_signed.values())
                extra.append(("Born marge minimale", round(min_margin, 3), "GPa"))
            except (TypeError, ValueError, KeyError):
                pass
        # Si on a ``phonon.freq`` lu via sanity mais sans Born (maille non
        # cubique), on n'écrit rien de plus — le verdict global reste lisible
        # via le bloc « Validité scientifique » (section 9) et l'experte.
    else:
        # Born pas peuplé (maille non cubique / pas P1/P3) → verdict neutre.
        rows.append((
            "Stabilité statique (critère de Born, Cij)",
            "non applicable (Cij cubiques absents ou profil non-élastique)",
            "",
        ))

    # --- 2. Stabilité dynamique (phonons DFPT) -----------------------------
    ds = _get(results, "properties.dynamically_stable")
    nm = _get(results, "properties.n_imaginary_modes")
    minw = _get(results, "properties.min_freq_cm-1")
    if ds is True:
        dyn_label = "✅ Tous modes ≥ 0"
    elif ds is False:
        if nm is not None and int(nm) > 0:
            dyn_label = f"❌ {int(nm)} mode(s) imaginaire(s)"
        else:
            dyn_label = "❌ instable"
    elif ds is None:
        dyn_label = "non calculé (P1 ou chaîne ph.x non lancée)"
    else:
        dyn_label = f"? {ds!r}"
    rows.append(("Stabilité dynamique (phonons, DFPT)", dyn_label, ""))
    if nm is not None:
        rows.append(("  Modes imaginaires", int(nm), ""))
    if minw is not None:
        rows.append(("  ω_min (mode acoustique le plus mou)", float(minw), "cm⁻¹"))
        extra.append(("ω_min", float(minw), "cm⁻¹"))
    return rows, extra


def _section_phonon_lifetime(results: dict[str, Any]) -> list[tuple[str, Any, str]]:
    """P4 — durées de vie, largeurs de raie, κ_lattice, Grüneisen."""
    rows: list[tuple[str, Any, str]] = []
    for k_md, key, unit in (
        ("τ mean (durée de vie moyenne)", "ph_life.mean_lifetime_ps", "ps"),
        ("τ min (mode le plus résistif)", "ph_life.min_lifetime_ps", "ps"),
        ("τ max", "ph_life.max_lifetime_ps", "ps"),
        ("γ mean (linewidth)", "ph_life.mean_linewidth_cm-1", "cm⁻¹"),
        ("γ max", "ph_life.max_linewidth_cm-1", "cm⁻¹"),
        ("κ_lattice (réseau)", "ph_life.lattice_kappa_W_mK", "W/(m·K)"),
        ("Grüneisen γ̄", "ph_life.gruneisen_mean", ""),
        ("Grüneisen |γ|_max", "ph_life.gruneisen_max_abs", ""),
    ):
        v = _get(results, key)
        if v is not None and v != [] and v != {}:
            rows.append((k_md, v, _unit_for(key, unit)))
    return rows


def _section_dielectric(results: dict[str, Any]) -> tuple[
    list[tuple[str, Any, str]],
    list[tuple[str, Any, str]],
]:
    """P5 — composantes ε∞ + Z* par atome."""
    rows: list[tuple[str, Any, str]] = []
    for k_md, key in (
        ("ε_xx (haute fréquence)", "dielectric.epsilon_xx"),
        ("ε_yy (haute fréquence)", "dielectric.epsilon_yy"),
        ("ε_zz (haute fréquence)", "dielectric.epsilon_zz"),
    ):
        v = _get(results, key)
        if v is not None:
            rows.append((k_md, float(v), ""))
    avg = _get(results, "dielectric.epsilon_average")
    if avg is not None:
        rows.append(("ε_∞ moyenne (diag. positives)", float(avg), ""))
    anis = _get(results, "dielectric.epsilon_anisotropy")
    if anis is not None:
        rows.append(("ε_∞ anisotropie (max/min)", float(anis), ""))
    n_idx = _get(results, "dielectric.refractive_index_avg")
    if n_idx is not None:
        rows.append(("Indice de réfraction n (√ε_∞)", float(n_idx), ""))
    eps0 = _get(results, "dielectric.epsilon_static_average")
    if eps0 is not None:
        rows.append(("ε₀ moyenne (statique)", float(eps0), ""))
    eps0_src = _get(results, "dielectric.epsilon_static_source")
    if eps0_src:
        rows.append(("  Source ε₀", str(eps0_src), ""))
    for k_md, key, unit in (
        ("Splitting LO−TO à Γ", "dielectric.lo_to_splitting_cm-1", "cm⁻¹"),
        ("ω LO à Γ", "dielectric.lo_freq_cm-1", "cm⁻¹"),
        ("ω TO à Γ", "dielectric.to_freq_cm-1", "cm⁻¹"),
    ):
        v = _get(results, key)
        if v is not None:
            rows.append((k_md, float(v), unit))
    born: list[tuple[str, Any, str]] = []
    zmax = _get(results, "dielectric.born_Z_star_max_abs")
    if zmax is not None:
        born.append(("|Z*| max (charge effective)", float(zmax), "e"))
    per_atom = _get(results, "dielectric.born_Z_star_per_atom")
    if isinstance(per_atom, list) and per_atom:
        # On restreint l'affichage aux premiers 12 atomes (UI limite déjà à 12).
        shown = per_atom[:12]
        for entry in shown:
            if not isinstance(entry, dict):
                continue
            idx = entry.get("atom_index")
            typ = entry.get("atom_type", "?")
            z = entry.get("Z_star")
            if isinstance(z, list) and len(z) == 3 and all(isinstance(row, list) and len(row) == 3 for row in z):
                flat: list[float] = []
                for row in z:
                    for v in row:
                        try:
                            flat.append(float(v))
                        except (TypeError, ValueError):
                            flat.append(float("nan"))
                born.append(
                    (
                        f"Z*[{idx}] {typ}",
                        "[" + ", ".join(f"{x:.3f}" for x in flat[:9]) + "]",
                        "e",
                    )
                )
        if len(per_atom) > 12:
            born.append((
                f"+ {len(per_atom) - 12} atomes supplémentaires",
                "—",
                "",
            ))
    return rows, born


def _section_plots(results: dict[str, Any]) -> list[tuple[str, Any, str]]:
    """Liste les plots disponibles dans ``results["plots"]``.

    Chaque ligne expose le chemin relatif (relpath) du fichier image pour E(V),
    DOS et bandes électroniques — ainsi les renderers MD/HTML peuvent soit
    afficher un lien markdown ``![](path)``, soit une ``<img src="..."/>`` côté
    HTML. La résolution d'URL complète se fait côté UI (``/api/pipeline/result_image``)
    à partir du ``relpath`` retourné ici.
    """
    rows: list[tuple[str, Any, str]] = []
    plot_keys = (
        ("plots.eos_ev", "E(V) — fit Birch–Murnaghan"),
        ("plots.ebands", "Bandes électroniques E(k)"),
        ("plots.edos", "DOS totale (spin-polarisée si nspin=2)"),
        ("plots.phonon_bands", "Bandes phononiques"),
        ("plots.phonon_dos", "DOS phononique"),
        ("plots.thermo_cv", "Thermodynamique QHA — F, S, Cᵥ vs T"),
        ("plots.thermo_cv_cp", "Cᵥ(T) vs Cₚ(T) — Cv + T·V·α²·B"),
        ("plots.phonon_linewidth", "Largeurs de raie γ(ω) (anharmonicité)"),
        ("plots.phonon_lifetime", "Durées de vie τ(ω) par mode"),
        ("plots.kappa_lattice", "κ_lattice(T) — conductivité thermique"),
        ("plots.gruneisen", "Paramètre de Grüneisen γ(q,ν)"),
        ("plots.elastic_vs_T", "C_ij(T) et modules VRH vs T"),
        ("plots.dielectric_tensor", "Tenseur diélectrique ε∞ (future — valeurs dans dielectric.*)"),
        ("plots.born_Z_star", "Charges effectives de Born Z* (future)"),
    )
    for key, label in plot_keys:
        v = _get(results, key)
        if isinstance(v, dict):
            rel = v.get("relpath") or v.get("path") or v.get("filename")
        elif isinstance(v, str):
            rel = v
        else:
            rel = None
        if rel:
            rows.append((label, str(rel), ""))
    return rows


def _section_parsed_metrics(results: dict[str, Any]) -> list[tuple[str, Any, str]]:
    """Grandeurs parsées (α, Cp, Cv, F, S, ε₀…) — affichées en tête des artefacts."""
    rows: list[tuple[str, Any, str]] = []
    for label, key, unit in (
        ("Θ Debye", "thermo.debye_temperature_K", "K"),
        ("Cᵥ (T=300 K)", "thermo.Cv_300K_Ry_per_K", "Ry/K"),
        ("F Helmholtz (T=300 K)", "thermo.F_300K_Ry", "Ry"),
        ("S entropie (T=300 K)", "thermo.entropy_300K_Ry_per_K", "Ry/K"),
        ("α dilatation (T=300 K)", "thermo.alpha_300K_per_K", "K⁻¹"),
        ("Cₚ (T=300 K)", "thermo.Cp_300K_Ry_per_K", "Ry/K"),
        ("ε₀ moyenne (statique)", "dielectric.epsilon_static_average", ""),
        ("|e|_max (piézo)", "thermo_extras.piezoelectric_tensor.max_component_C_per_m2", "C/m²"),
        ("Atomes Z* parsés", "dielectric.born_Z_star_n_atoms", ""),
    ):
        v = _get(results, key)
        if v is None:
            continue
        if isinstance(v, float):
            rows.append((label, float(v), unit))
        else:
            rows.append((label, v, unit))
    for label, key in (
        ("Source α(T)", "thermo.alpha_source"),
        ("Source Cₚ", "thermo.Cp_source"),
        ("Source ε₀", "dielectric.epsilon_static_source"),
        ("Fichier therm", "thermo.therm_source_file"),
    ):
        v = _get(results, key)
        if v:
            rows.append((label, str(v), ""))
    return rows


def _section_extended_coverage(results: dict[str, Any]) -> list[tuple[str, Any, str]]:
    """Statut des propriétés étendues (aligné panneau UI « Couverture »)."""
    rows: list[tuple[str, Any, str]] = []

    def _filled(key: str) -> bool:
        v = _get(results, key)
        if v is None:
            return False
        if isinstance(v, (int, float)):
            return bool(v) or key.endswith("_per_K") or "alpha" in key
        if isinstance(v, list):
            return len(v) > 0
        return bool(v)

    for label, key, hint in (
        ("Dilatation thermique α(T)", "thermo.alpha_300K_per_K", "QHA / Debye / re-parse"),
        ("Capacité calorifique Cₚ @ 300 K", "thermo.Cp_300K_Ry_per_K", "Cv + T·V·α²·B"),
        ("Permittivité statique ε₀", "dielectric.epsilon_static_average", "LO/TO opt-in ou LST"),
        ("Tenseur piézoélectrique e_ijk", "thermo_extras.piezoelectric_tensor.max_component_C_per_m2", "extra P5"),
        ("Charges effectives de Born Z*", "dielectric.born_Z_star_n_atoms", "P5 / LO/TO → BORN"),
    ):
        piezo_matrix = _get(results, "thermo_extras.piezoelectric_tensor.matrix")
        born_list = _get(results, "dielectric.born_Z_star_per_atom")
        ok = _filled(key)
        if label.startswith("Tenseur piézo") and isinstance(piezo_matrix, list) and piezo_matrix:
            ok = True
        if label.startswith("Charges effectives") and isinstance(born_list, list) and born_list:
            ok = True
        status = "✓ Rempli" if ok else "— Absent"
        rows.append((label, status, hint if not ok else ""))
    rows.append(("Balayage explicite en pression P", "Prévu", "feuille de route"))
    rows.append(("Thermoélectricité (Seebeck, ZT)", "Prévu", "post-traitement BoltzTraP"))
    return rows


def _section_thermo_extras(results: dict[str, Any]) -> list[tuple[str, Any, str]]:
    """P5 extras + sorties ``what='thermo'`` (Debye, ZPE, F(T), Cv).

    Juillet 2026 — refonte : la section expose désormais la **température de
    Debye** (Θ_D), l'énergie de point zéro (ZPE) et les capacités calorifiques
    lorsque thermo_pw ``what='thermo'`` les a peuplées dans ``results["thermo"]``.
    Ces clés étaient déjà parsées (cf. ``parsers/thermo_pw_out_parse.py``) mais
    jamais exposées dans la fiche — c'était une demande utilisateur explicite.

    Pour P1 (sans thermo_pw what='thermo'), seules les ``thermo_extras`` P5
    éventuelles apparaissent. Pour P2/P3/P4/P5, on remonte toutes les
    grandeurs disponibles.
    """
    rows: list[tuple[str, Any, str]] = []
    # --- thermo_pw what='thermo' (juillet 2026) ---
    # Θ Debye est la première clé attendue pour P2+/P3/P4 : fournit le verdict
    # anharmonicité (cf. insights ''thermodynamique QHA'').
    debye = _get(results, "thermo.debye_temperature_K")
    if debye is not None:
        rows.append(("Θ Debye", round(float(debye), 3), "K"))
    zpe = _get(results, "thermo.zero_point_energy_Ry")
    if zpe is not None:
        rows.append(("Énergie de point zéro (ZPE)", float(zpe), "Ry"))
    # Nota : F(T) et Cv(T) dépendent de la clé exacte que ``PipelineJob``
    # expose. Ces grandeurs sont population-dépendantes (à une T donnée) — le
    # pipeline catalog (pipeline.py:137) ne les publie pas en clé plate connue.
    # On tente deux conventions plausibles (avec repli silencieux si absent).
    for dotted_key, flat_key, label, unit in (
        ("thermo.helmholtz_free_energy_Ry.T300K", "thermo.F_300K_Ry",
         "F(T=300 K) — Helmholtz libre", "Ry"),
        ("thermo.heat_capacity_Cv_Ry_per_K.T300K", "thermo.Cv_300K_Ry_per_K",
         "Cᵥ (T=300 K)", "Ry/K"),
        ("thermo.entropy_300K_Ry_per_K.T300K", "thermo.entropy_300K_Ry_per_K",
         "S(T=300 K)", "Ry/K"),
        ("thermo.alpha_300K_per_K", "thermo.alpha_300K_per_K",
         "α dilatation (T=300 K)", "K⁻¹"),
        ("thermo.Cp_300K_Ry_per_K", "thermo.Cp_300K_Ry_per_K",
         "Cₚ (T=300 K)", "Ry/K"),
    ):
        v = _get(results, dotted_key)
        if v is None:
            v = _get(results, flat_key)
        if v is not None:
            rows.append((label, float(v), unit))
    alpha_src = _get(results, "thermo.alpha_source")
    if alpha_src:
        rows.append(("  Source α(T)", str(alpha_src), ""))
    cp_src = _get(results, "thermo.Cp_source")
    if cp_src:
        rows.append(("  Source Cₚ", str(cp_src), ""))
    therm_file = _get(results, "thermo.therm_source_file")
    if therm_file:
        rows.append(("  Fichier thermodynamique", str(therm_file), ""))
    # --- thermo_pw what='thermo_extras' (P5 uniquement) ---
    for cat in ("plot_bz", "piezoelectric_tensor", "scf_dielectric",
                "magnetic_susceptibility", "magnetoelectric_tensor"):
        ok = _get(results, f"thermo_extras.{cat}.ok")
        if ok is None:
            continue
        rows.append((f"thermo_extras.{cat}", bool(ok), ""))
        # piézo : on cherche aussi un max component si déjà calculé à plat.
        if cat == "piezoelectric_tensor":
            mx = _get(results, "thermo_extras.piezoelectric_tensor.max_component_C_per_m2")
            if mx is not None:
                rows.append(("  max composante e_ijk", float(mx), "C/m²"))
        if cat == "magnetic_susceptibility":
            sc = _get(results, "thermo_extras.magnetic_susceptibility.scalar_SI")
            if sc is not None:
                rows.append(("  χ scalaire (SI)", float(sc), "SI"))
    return rows


def _section_magnetism(
    mag: dict[str, Any],
    results: Optional[dict[str, Any]] = None,
) -> list[tuple[str, Any, str]]:
    """Section magnétisme : déclaration d'entrée (scf.in) + valeurs CONVERGÉES.

    Août 2026 — la section n'exposait que la détection d'entrée
    (nspin/starting_magnetization/DFT+U). Les grandeurs convergées du SCF
    (magnétisation totale/absolue, moments par site, ordre FM/AFM/FiM
    effectif) sont désormais lues depuis ``results["magnetism"]`` (peuplé
    par ``parsers/magnetization.py``) et affichées à la suite.
    """
    rows: list[tuple[str, Any, str]] = []
    nspin = mag.get("nspin")
    is_mag = mag.get("is_magnetic") or nspin in (2, 4)

    if is_mag:
        # Ligne principale : régime
        if nspin == 4:
            rows.append(("Régime", "spin-polarisé non-colinéaire (nspin=4)", ""))
        elif nspin == 2:
            rows.append(("Régime", "spin-polarisé colinéaire (nspin=2)", ""))
        else:
            rows.append(("Régime", "spin-polarisé", ""))

        # Noncolin explicite
        if mag.get("noncolin"):
            rows.append(("  noncolin", True, ""))

        # Ordre magnétique (AFM / FM / ferri / non-colinéaire)
        order = mag.get("magnetic_order")
        if order:
            order_labels = {
                "ferromagnetic": "ferromagnétique (FM)",
                "antiferromagnetic": "antiferromagnétique (AFM)",
                "ferrimagnetic": "ferrimagnétique (FiM)",
                "non_collinear": "non-colinéaire",
            }
            rows.append(("  Ordre détecté", order_labels.get(order, order), ""))

        # Moments starting_magnetization
        sm = mag.get("starting_magnetization") or []
        if sm:
            for i, v in enumerate(sm, start=1):
                if isinstance(v, (int, float)) and abs(float(v)) > 1e-9:
                    rows.append((f"  starting_magnetization({i})", float(v), "μ_B"))
            n_zero = sum(1 for v in sm if isinstance(v, (int, float)) and abs(float(v)) < 1e-9)
            if n_zero and n_zero == len(sm):
                rows.append(("  starting_magnetization(*)", "tous nuls", ""))

        # nup / ndown
        nup, ndown = mag.get("nup_ndown") or (None, None)
        if nup is not None:
            rows.append(("  nup", float(nup), ""))
        if ndown is not None:
            rows.append(("  ndown", float(ndown), ""))
        if nup is not None and ndown is not None:
            mu = abs(float(nup) - float(ndown))
            rows.append(("  μ = |nup − ndown|", float(mu), "μ_B (par maille)"))

        # Hubbard U (DFT+U)
        hu = mag.get("hubbard_u") or {}
        if hu.get("lda_plus_u"):
            rows.append(("  DFT+U activé (lda_plus_u=.true.)", True, ""))
            u_vals = hu.get("Hubbard_U") or {}
            if u_vals:
                for idx in sorted(u_vals.keys()):
                    rows.append((f"  Hubbard_U({idx})", float(u_vals[idx]), "eV"))
            a_vals = hu.get("Hubbard_alpha") or {}
            if a_vals:
                for idx in sorted(a_vals.keys()):
                    rows.append((f"  Hubbard_alpha({idx})", float(a_vals[idx]), ""))
            j_vals = hu.get("Hubbard_J") or {}
            if j_vals:
                for idx in sorted(j_vals.keys()):
                    rows.append((f"  Hubbard_J({idx})", float(j_vals[idx]), "eV"))
            proj = hu.get("U_projection_type")
            if proj:
                rows.append(("  U_projection_type", proj, ""))

        # Angles non-colinéaires
        a1 = mag.get("angle1") or []
        a2 = mag.get("angle2") or []
        if a1 or a2:
            max_len = max(len(a1), len(a2))
            for i in range(max_len):
                v1 = a1[i] if i < len(a1) else None
                v2 = a2[i] if i < len(a2) else None
                if v1 is not None and v2 is not None:
                    rows.append((f"  angle1({i+1}), angle2({i+1})",
                                f"θ={v1:.1f}°, φ={v2:.1f}°", ""))
        # Magnetisation contrainte / totale
        cm = mag.get("constrained_magnetization")
        if cm:
            rows.append(("  constrained_magnetization", cm, ""))
        tm = mag.get("tot_magnetization")
        if tm is not None:
            rows.append(("  tot_magnetization", float(tm), "μ_B / maille"))
    else:
        rows.append(("Régime magnétique", "non magnétique (nspin=1, pas de moments)", ""))

    # --- Valeurs CONVERGÉES (août 2026) — depuis results["magnetism"] ------
    conv = (results or {}).get("magnetism") or {}
    if isinstance(conv, dict) and conv.get("is_spin_polarized"):
        rows.append(("— Convergé (sortie SCF) —", "", ""))
        order = conv.get("magnetic_order")
        if order:
            # Août 2026 — seuls FM / AFM (nspin=2) et non-colinéaire (nspin=4)
            # sont étiquetés automatiquement. Ferri / dia / cas ambigus :
            # ``magnetic_order=None`` → ligne « à déduire » ci-dessous.
            order_labels = {
                "ferromagnetic": "ferromagnétique (FM)",
                "antiferromagnetic": "antiferromagnétique (AFM)",
                "non_collinear": "non-colinéaire",
            }
            rows.append(("  Ordre magnétique convergé", order_labels.get(order, order), ""))
        else:
            rows.append((
                "  Ordre magnétique convergé",
                "non tranché automatiquement — à déduire des magnétisations "
                "totale/absolue et des moments par site ci-dessous "
                "(ferrimagnétisme, diamagnétisme…)",
                "",
            ))
        tv = conv.get("total_magnetization")
        if tv is not None:
            rows.append(("  Magnétisation totale", round(float(tv), 4), "μ_B / maille"))
        vec = conv.get("total_magnetization_vector")
        if isinstance(vec, (list, tuple)) and len(vec) == 3:
            rows.append((
                "  M⃗ (non-colinéaire)",
                "(" + ", ".join(f"{float(v):.4f}" for v in vec) + ")",
                "μ_B",
            ))
        av = conv.get("absolute_magnetization")
        if av is not None:
            rows.append(("  Magnétisation absolue", round(float(av), 4), "μ_B / maille"))
        mpa = conv.get("m_per_atom")
        if mpa is not None:
            rows.append(("  |m| moyen par site", round(float(mpa), 4), "μ_B"))
        for site in (conv.get("projected_moments_per_atom") or [])[:12]:
            if not isinstance(site, dict):
                continue
            mv = site.get("magn_vector_muB")
            if isinstance(mv, (list, tuple)) and len(mv) == 3:
                val: Any = "(" + ", ".join(f"{float(v):.3f}" for v in mv) + ")"
            else:
                val = site.get("magn_muB")
            rows.append((f"  moment atome {site.get('atom', '?')}", val, "μ_B"))
    return rows


def _section_artifacts(
    results: dict[str, Any],
    work_dir: Optional[Path],
) -> list[tuple[str, str, str]]:
    """Liste exhaustif des artefacts produits par le run.

    Juillet 2026 — permet à l'utilisateur de voir / ouvrir TOUS les fichiers
    du work_dir (gnuplot, PNG, PDF, .dat bruts, .in, .out, .json) sans avoir
    à naviguer manuellement. Renvoie ``[(basename, relpath, kind)]`` où
    ``kind ∈ {"png", "pdf", "gs", "dat", "in", "out", "json", "other"}``.

    Source = union de (par ordre de priorité) :
      1. ``results["plots"][*].relpath``  (déjà utilisé par 8b pour les PNG).
      2. ``results["output_files"]``     (future-proof key).
      3. Scan direct du work_dir pour ``.png .pdf .gs .dat .in .out .json``
         (cap 80 fichiers ; tri par catégorie puis nom).

    Exclusion :
      * ``scf.in`` > 1 Mo (trop gros pour l'aperçu — déjà ~200 lignes par
        défaut ; les .in déjà écrits par le pipeline sont gardés).
      * Fichiers cachés (``.*``), dossiers.
      * ``wf1_eos_*`` seft-state ``.json`` du workflow (très bruit).
    """
    rows: list[tuple[str, str, str]] = []
    seen: set[str] = set()

    # 1. plots dict (déjà dans 8b — on garde pour ne rien rater)
    plots = (results or {}).get("plots") or {}
    if isinstance(plots, dict):
        for _k, v in plots.items():
            if isinstance(v, dict):
                rel = v.get("relpath") or v.get("path") or v.get("filename")
            elif isinstance(v, str):
                rel = v
            else:
                rel = None
            if rel and isinstance(rel, str) and rel not in seen:
                rel = rel.replace("\\", "/")
                kind = "png"
                if rel.lower().endswith(".pdf"):
                    kind = "pdf"
                rows.append((rel.rsplit("/", 1)[-1], rel, kind))
                seen.add(rel)

    # 2. output_files (future-proof)
    for p in (results or {}).get("output_files") or []:
        if isinstance(p, str) and p and p not in seen:
            rel = p.replace("\\", "/")
            kind = "other"
            suf = rel.rsplit(".", 1)[-1].lower() if "." in rel else "other"
            for ext, k in (
                ("png", "png"), ("pdf", "pdf"), ("gs", "gs"),
                ("dat", "dat"), ("in", "in"), ("out", "out"), ("json", "json"),
            ):
                if suf == ext:
                    kind = k
                    break
            rows.append((rel.rsplit("/", 1)[-1], rel, kind))
            seen.add(rel)

    # 3. Scan work_dir (1 niveau + sous-dossiers directs ; pas de récursion
    # pour éviter cyc/symlink loops). Filtrage symlinks : on ``resolve(strict=False)``
    # + revérif ``relative_to(root)`` ; tout lien symbolique hors work_dir
    # est strictement ignoré (sécurité + cohérence avec le routage
    # ``_eos_run_child_path`` côté API).
    if work_dir is not None:
        try:
            root = Path(work_dir).resolve()
        except OSError:
            root = None
        if root and root.is_dir():
            kind_map = {
                ".png": "png", ".pdf": "pdf",
                ".gs": "gs", ".gnu": "gs",  # scripts gnuplot (cf. eos_gnuplot GP_SCRIPT="plot_eos.gnu")
                ".dat": "dat", ".in": "in", ".out": "out", ".json": "json",
                ".ps": "ps",  # PostScript legacy -> le wire-in api_server._post_process ou /files
                              # convertit via Ghostscript en .pdf sibling (backend.ps_to_pdf).
                ".eps": "ps",  # Encapsulated PostScript -> même bucket que ``.ps``
                               # (même dialecte Ghostscript, même conversion auto).
            }
            # Plafonne l'itération à 400 fichiers totaux (80 artefacts max
            # affichés mais on peut en sauter en route).
            MAX_SCAN_FILES = 400
            files_inspected = 0
            # Scan : 1er niveau (work_dir lui-même) + sous-dossiers directs
            # (1_eos_volumes/, scf_out/, dynmat_cache/, etc.).
            sub_roots: list[Path] = [root]
            try:
                sub_roots.extend(entry for entry in root.iterdir() if entry.is_dir())
            except OSError:
                pass
            for sub_root in sub_roots:
                try:
                    if not sub_root.is_dir():
                        continue
                    for path in sub_root.iterdir():
                        if files_inspected >= MAX_SCAN_FILES or len(rows) >= 80:
                            break
                        files_inspected += 1
                        try:
                            if not path.is_file() or path.is_symlink():
                                continue
                            if path.name.startswith("."):
                                continue
                            rel = path.relative_to(root).as_posix()
                            if rel in seen:
                                continue
                            suf = path.suffix.lower()
                            kind = kind_map.get(suf, "other")
                            if kind == "other":
                                continue
                            # Filtre ``wf1_eos_* state JSON`` (bruit UI).
                            if kind == "json" and (
                                "workflow_state" in path.name.lower()
                                or "wf1_eos_" in path.name
                            ):
                                continue
                            # Filtre ``scf.in`` > 250 ko (gros modifs oneliners).
                            if path.name == "scf.in":
                                try:
                                    if path.stat().st_size > 250_000:
                                        continue
                                except OSError:
                                    continue
                            rows.append((path.name, rel, kind))
                            seen.add(rel)
                        except (OSError, ValueError):
                            continue
                except (OSError, ValueError):
                    continue
                if len(rows) >= 80:
                    break

    # Déduplique PostScript legacy quand le sibling PDF existe déjà
    # (thermo_pw écrit souvent .ps + conversion auto → .pdf).
    pdf_stems = {
        r[1].rsplit(".", 1)[0]
        for r in rows
        if r[2] == "pdf" and "." in r[1]
    }
    if pdf_stems:
        rows = [
            r for r in rows
            if not (
                r[2] == "ps"
                and "." in r[1]
                and r[1].rsplit(".", 1)[0] in pdf_stems
            )
        ]

    # Tri stable par (kind, relpath) → groupe visuellement par catégorie.
    # "ps" est place juste avant "pdf" pour que le PostScript legacy apparaisse
    # a cote de son futur sibling PDF (apres conversion auto via ps_to_pdf).
    kind_order = {"png": 0, "pdf": 1, "ps": 2, "gs": 3, "dat": 4, "in": 5, "out": 6, "json": 7, "other": 8}
    rows.sort(key=lambda r: (kind_order.get(r[2], 9), r[1]))
    return rows[:80]


def assemble_factsheet(
    work_dir: Path,
    profile_id: str,
    profile: dict[str, Any],
    results: dict[str, Any],
    marker_root: Optional[dict[str, Any]] = None,
) -> FactsheetSections:
    """Agrège toutes les sections de la fiche en un ``FactsheetSections``.

    Args:
        work_dir: répertoire du job (utilisé pour sanity-checks + magnetism).
        profile_id: ``P1``..``P5``.
        profile: sous-dict ``PROFILES[profile_id]`` (obligatoire pour le contexte).
        results: ``marker["results"]`` (les valeurs peuplées par les parsers).
        marker_root: marker complet (utilisé pour ``status``, ``finished_at``,
            ``work_dir``, ``material_id``, ``extra_whats``, ``p1_full_preset``).
            Optionnel — l'en-tête se dégrade proprement en cas d'absence.
    """
    fs = FactsheetSections()

    # 1. En-tête
    # Fallback gracieux : si marker_root est None (callers API ou tests qui
    # omettent l'argument), tente une lecture disque depuis work_dir du job.
    # Évite la cascade « job_id = '—' » visible antérieurement dans les tests
    # d'assemblage et accessoirement dans l'UI (header dégradé en ému-dash).
    # Note: l'endpoint Flask charge déjà le marker via disk scan avant d'appeler
    # ``assemble_factsheet(..., marker_root=marker)``. Ce chemin ne sert donc
    # QUE pour des appels directs (tests, scripts). Catch resserré sur la
    # même exception set que ``read_marker_from_workdir`` (pas de masque
    # des bugs de programmation).
    if marker_root is None and work_dir:
        try:
            marker_root = read_marker_from_workdir(Path(work_dir))
        except (OSError, json.JSONDecodeError):
            marker_root = None
    header: dict[str, Any] = {
        "job_id": (marker_root or {}).get("job_id", "—"),
        "profile_id": profile_id or (marker_root or {}).get("profile_id", "—"),
        "profile_name": (profile or {}).get("name", "") or (marker_root or {}).get("profile_name", "—"),
        "what_qe": (profile or {}).get("what_qe", "") or (marker_root or {}).get("profile_what_qe", ""),
        "material_id": (marker_root or {}).get("material_id", "—"),
        "work_dir": (marker_root or {}).get("work_dir", str(work_dir) if work_dir else "—"),
        "status": (marker_root or {}).get("status", "—"),
        "scf_in_basename": (marker_root or {}).get("scf_in_basename", "—"),
        "nproc": (marker_root or {}).get("nproc", "—"),
        "created_at": (marker_root or {}).get("created_at", "—"),
        "finished_at": (marker_root or {}).get("finished_at", "—"),
        "extra_whats": list((marker_root or {}).get("extra_whats") or []),
        "p1_full_preset": (marker_root or {}).get("p1_full_preset", None),
    }
    fs.header = header

    # 1b. Repli disque — marker JSON parfois périmé (gap null malgré bands.dat OK).
    results = _enrich_results_from_workdir(
        Path(work_dir) if work_dir else None,
        results or {},
    )

    # 2. Sections profil-aware
    fs.eos_rows = _section_eos(results or {}, work_dir=Path(work_dir) if work_dir else None)
    cij, poly, extra = _section_elastic(results or {})
    fs.elastic_rows_exec = cij
    fs.elastic_rows_poly = poly
    fs.elastic_extra = extra
    fs.electronic_rows, fs.electronic_extra = _section_electronic(results or {})
    # Juillet 2026 — P3 : C_ij(V₀, T) sur la grille T (cf. ``_section_elastic_vs_T``).
    # Lecture à la demande depuis ``elastic_constants_vs_T.dat`` ; ne fait rien
    # si le fichier n’existe pas (P1/P2/P4/P5) ou si work_dir est None.
    fs.elastic_t_section = _section_elastic_vs_T(
        Path(work_dir) if work_dir else None
    )
    fs.magnetism_rows = _section_magnetism(detect_magnetism(work_dir), results or {})
    fs.dyn_stability_rows = _section_dyn_stability(results or {})
    # Juillet 2026 — Recommandations de vérification déclenchées si
    # ``properties.n_imaginary_modes > 0`` OU si des ``items`` sont déjà
    # cristallisés dans le marker (rechargements depuis un run précédent).
    # Lecture-seule des artefacts du work_dir ; aucune relance de calcul.
    recs = build_phonon_imaginary_recommendations(
        Path(work_dir) if work_dir else None,
        results or {},
    )
    fs.phonon_recommendations = list(recs.get("items") or [])
    fs.phonon_recommendation_context = dict(recs.get("context") or {})
    fs.phonon_lifetime_rows = _section_phonon_lifetime(results or {})
    fs.dielectric_rows, fs.born_rows = _section_dielectric(results or {})
    fs.extras_rows = _section_thermo_extras(results or {})
    fs.parsed_metrics_rows = _section_parsed_metrics(results or {})
    fs.extended_coverage_rows = _section_extended_coverage(results or {})
    fs.plots_rows = _section_plots(results or {})
    fs.artifacts_rows = _section_artifacts(results or {}, Path(work_dir) if work_dir else None)

    # 3. Sanity-checks scientifiques
    rep = _sanity_section(work_dir, results or {}, profile_id or "")
    fs.sanity_checks = list(rep.get("checks") or [])
    fs.sanity_summary = dict(rep.get("summary") or {})
    # 3b. Stabilité unifiée — DOIT être construite après _sanity_section()
    # car elle lit ``fs.sanity_checks`` (notamment ``born_stability``).
    # Ordre important : voir tests ``test_assemble_factsheet_stability_*``.
    fs.stability_rows, fs.stability_extra = _section_stability(
        results or {}, fs.sanity_checks or []
    )

    # 4. Note globale
    fs.notes.append(
        "Fiche générée par ``backend/factsheet.py`` — agrégat lecture-seule "
        "depuis ``pipeline_api_job_state.json`` + ``scf.in`` + sanity-checks."
    )

    # 5. Insights du moteur expert rule-based (sans LLM — voir ``factsheet_ai.py``).
    try:
        fs.ai_insights = compute_insights(fs, work_dir)
    except Exception:  # noqa: BLE001
        fs.ai_insights = []

    return fs


# ============================================================================
# Renderers
# ============================================================================

_EOS_KEY = ("V0", "B0", "B'")
# Juillet 2026 — section 5 unifiée : statique (Born) + dynamique (DFPT).
_PHONON_HEADER = (
    "Stabilité — critère statique (Born, Cij) à côté du critère dynamique "
    "(phonons DFPT)"
)


def _format_table_md(rows: list[tuple[str, Any, str]]) -> str:
    """Formatte ``[(label, value, unit)]`` en tableau Markdown (3 colonnes)."""
    if not rows:
        return "*non calculé pour ce profil*\n"
    out_lines = [
        "| Grandeur | Valeur | Unité |",
        "|---|---|---|",
    ]
    for label, value, unit in rows:
        val_s = _fmt(value)
        # Badge HTML injecte par ``_section_elastic`` : on nettoie pour le
        # rendu Markdown (le MD ne supporte pas le CSS ``.badge-warning``).
        # On conserve le libelle humain court ; pas de HTML dans le .md.
        if isinstance(value, str) and value.startswith("<span "):
            if "badge-warning" in value:
                val_s = "Aper\u00e7u partiel"
            elif "badge-success" in value:
                val_s = "Donn\u00e9es finales"
            else:
                val_s = ""
        out_lines.append(f"| {label} | {val_s} | {unit} |")
    return "\n".join(out_lines) + "\n"


def render_factsheet_md(fs: FactsheetSections) -> str:
    """Génère la fiche technique au format Markdown."""
    h = fs.header or {}
    now_iso = datetime.now(timezone.utc).isoformat(timespec="seconds")
    body: list[str] = []
    body.append(f"# THERMO_PW — Fiche technique ({h.get('profile_id', '?')})\n")
    body.append(
        "Fiche générée par ``backend/factsheet.py`` — agrégat lecture-seule "
        "depuis ``pipeline_api_job_state.json`` + ``scf.in`` + sanity-checks. "
        "Aucune valeur n'est calculée à la volée.\n"
    )

    body.append("## En-tête du run\n")
    rows = [
        ("Job ID", h.get("job_id", "—"), ""),
        ("Profil", f"{h.get('profile_id', '—')} — {h.get('profile_name', '—')}", ""),
        ("thermo_pw what=", f"`{h.get('what_qe', '—')}`", ""),
        ("Matériau", h.get("material_id", "—"), ""),
        ("scf.in", h.get("scf_in_basename", "—"), ""),
        ("nproc MPI", str(h.get("nproc", "—")), ""),
        ("work_dir", f"`{h.get('work_dir', '—')}`", ""),
        ("Statut", h.get("status", "—"), ""),
        ("Créé le", h.get("created_at", "—"), ""),
        ("Terminé le", h.get("finished_at", "—"), ""),
    ]
    if h.get("extra_whats"):
        rows.append(("thermo_pw extras (P5)", ", ".join(h["extra_whats"]), ""))
    if h.get("p1_full_preset"):
        rows.append(("Preset P1 « complet »", "ACTIVÉ (ichamp=3 + DOS + Bandes)", ""))
    body.append(_format_table_md(rows))

    # --- 1. Équation d'état
    body.append("\n## 1. Équation d'état (Birch–Murnaghan) — P2/P3/P4\n")
    if fs.eos_rows:
        body.append(_format_table_md(fs.eos_rows))
    else:
        body.append("*Aucun fit Birch-Murnaghan effectué pour ce profil (P1/P5 n'ont pas de grille EOS).*\n")

    # --- 2. Constantes élastiques & modules polycristallins
    body.append("\n## 2. Constantes élastiques C_ij (Voigt) et modules polycristallins\n")
    if fs.elastic_rows_exec:
        body.append("### Matrice cubique (cas le plus fréquent : maille cubique)\n")
        body.append(_format_table_md(fs.elastic_rows_exec))
    else:
        body.append(
            "*Aucune constante C_ij unique extraite — la maille n'est probablement "
            "pas cubique, ou le profil ne lance pas thermo_pw what='scf_elastic_"
            "constants' / 'elastic_constants_geo' (P2/P4).*\n"
        )
    if fs.elastic_rows_poly:
        body.append("\n### Modules polycristallins (Hill VRH)\n")
        body.append(_format_table_md(fs.elastic_rows_poly))
    if fs.elastic_extra:
        body.append("\n### Diagnostics (anisotropie / Pugh)\n")
        body.append(_format_table_md(fs.elastic_extra))

    # --- 2b. Évolution thermique P3 (C_ij(V₀, T) sur grille T)
    et_section = fs.elastic_t_section or {}
    et_rows = et_section.get("rows", [])
    if et_rows:
        t_min = et_section.get("t_min", 0.0)
        t_max = et_section.get("t_max", 0.0)
        n_points = et_section.get("n_points", 0)
        is_cubic = et_section.get("is_cubic", False)
        units_were_kbar = et_section.get("units_were_kbar", False)
        born_dict = et_section.get("born", {}) or {}
        body.append("\n## 2b. Évolution thermique P3/P4 (C_ij(V₀, T))\n")
        units_str = (
            "unités source kbar → conversion GPa appliquée"
            if units_were_kbar
            else "unités GPa (déjà)"
        )
        body.append(
            f"Grille T : {int(t_min)}→{int(t_max)} K ({n_points} points, {units_str}).\n\n"
        )
        # Verdict stabilité de Born (T=0 et T=Tmax) si réseau cubique.
        if is_cubic and born_dict:
            body.append("**Stabilité de Born (critère mécanique) :**\n\n")
            for t_key, payload in sorted(born_dict.items()):
                ok, fails = payload
                verdict = "✅ Stable" if ok else f"❌ Instable — {'; '.join(fails)}"
                body.append(f"- T = {t_key} K : {verdict}\n")
            body.append("\n")
        # Tableau C_ij(T) (GPa) — cap à 21 lignes.
        body.append("### Constantes élastiques C_ij(V₀, T)\n")
        body.append("| T (K) | C₁₁ (GPa) | C₁₂ (GPa) | C₄₄ (GPa) |\n")
        body.append("|-------|-----------|-----------|-----------|\n")
        for t, c11, c12, c44 in et_rows[:21]:
            body.append(f"| {int(t)} | {c11:.2f} | {c12:.2f} | {c44:.2f} |\n")
        if len(et_rows) > 21:
            body.append(
                f"| ... | (+{len(et_rows) - 21} points T supplémentaires) | ... | ... |\n"
            )
        body.append("\n")
        # Modules VRH (uniquement si cubique strict).
        vrh_list = et_section.get("vrh", []) or []
        if is_cubic and vrh_list:
            body.append("### Modules polycristallins VRH (Hill) — B/G/E/ν(T)\n")
            body.append(
                "| T (K) | B (GPa) | G_V (GPa) | G_R (GPa) | G_Hill (GPa) "
                "| E (GPa) | ν |\n"
            )
            body.append(
                "|-------|---------|-----------|-----------|----------------"
                "|---------|-----|\n"
            )
            for t, vrh in vrh_list[:21]:
                body.append(
                    f"| {int(t)} | {_fmt(vrh['B_GPa'], n=2)} | "
                    f"{_fmt(vrh['G_V_GPa'], n=2)} | {_fmt(vrh['G_R_GPa'], n=2)} | "
                    f"{_fmt(vrh['G_Hill_GPa'], n=2)} | {_fmt(vrh['E_GPa'], n=2)} | "
                    f"{_fmt(vrh['nu'], n=3)} |\n"
                )
            if len(vrh_list) > 21:
                body.append("| ... | ... | ... | ... | ... | ... | ... |\n")
            body.append("\n")
        # Réf. plot (déjà couvert par _section_plots + _section_artifacts).
        body.append(
            "*Plot associé :* ``elastic_vs_T_plot.png`` "
            "(gnuplot : C_ij(T) et modules VRH vs T) — voir section 8b figures.\n"
        )

    # --- 3. Propriétés électroniques
    body.append("\n## 3. Propriétés électroniques (NSCF + DOS + bandes)\n")
    if fs.electronic_rows or fs.electronic_extra:
        if fs.electronic_rows:
            body.append(_format_table_md(fs.electronic_rows))
        if fs.electronic_extra:
            body.append("\n### Détails gap / nature\n")
            body.append(_format_table_md(fs.electronic_extra))
    else:
        body.append(
            "*Propriétés électroniques non produites — ``properties_ichamp`` non "
            "enclenché (la chaîne ``NSCF + dos.x + bands.x`` n'a pas tourné).*\n"
        )

    # --- 4. Magnétisme
    body.append("\n## 4. Magnétisme (détection depuis scf.in)\n")
    body.append(_format_table_md(fs.magnetism_rows))

    # --- 5. Stabilité unifiée — statique (Born) + dynamique (phonons DFPT)
    body.append("\n## 5. ")
    body.append(_PHONON_HEADER + "\n")
    if fs.stability_rows:
        body.append(_format_table_md(fs.stability_rows))
        if fs.stability_extra:
            body.append("\n### Marges & détails\n")
            body.append(_format_table_md(fs.stability_extra))
    elif fs.dyn_stability_rows:
        # Repli : si stability_rows vide (anomalie), on garde l'ancienne liste.
        body.append(_format_table_md(fs.dyn_stability_rows))

    # --- 5b. Recommandations de vérification (juillet 2026)
    # On accède à ``n_imaginary_modes`` via ``fs.dyn_stability_rows`` plutôt
    # que ``results`` (qui n'est pas en scope dans ``render_factsheet_md(fs)``).
    n_imag_fs = None
    for _lab_fs, _val_fs, _u_fs in (fs.dyn_stability_rows or []):
        if _lab_fs == "Modes imaginaires" and _val_fs is not None:
            try:
                n_imag_fs = int(_val_fs)
            except (TypeError, ValueError):
                n_imag_fs = None
            break
    if fs.phonon_recommendations and (n_imag_fs is None or int(n_imag_fs or 0) > 0):
        body.append(
            "\n## 5b. 🔍 Recommandations de vérification "
            "(fréquences imaginaires détectées)\n"
        )
        body.append(
            "Liste de propositions générée automatiquement "
            "(lecture-seule des artefacts du work_dir — pas de calcul "
            "supplémentaire). Trier par **priorité** descendante pour les "
            "causes les plus probables.\n\n"
        )
        # Contexte rapide (XC / pseudos / q-grid) pour transparence.
        ctx = fs.phonon_recommendation_context or {}
        if ctx:
            ctx_bits: list[str] = []
            if ctx.get("xc"):
                ctx_bits.append(f"XC = **{ctx['xc']}**")
            if ctx.get("pseudo_family"):
                ctx_bits.append(f"pseudos = **{ctx['pseudo_family']}**")
            if ctx.get("nq"):
                ctx_bits.append(f"q-grid = **{ctx['nq'][0]}×{ctx['nq'][1]}×{ctx['nq'][2]}**")
            if ctx.get("tr2_ph") is not None:
                ctx_bits.append(f"tr2_ph = **{ctx['tr2_ph']:.1E}**")
            if ctx.get("conv_thr") is not None:
                ctx_bits.append(f"conv_thr = **{ctx['conv_thr']:.1E}**")
            if ctx.get("ecutwfc") is not None:
                ctx_bits.append(f"ecutwfc = **{ctx['ecutwfc']:.1f} Ry**")
            if ctx.get("asr"):
                ctx_bits.append(f"ASR = **{ctx['asr']}**")
            if ctx.get("nspin") is not None:
                ctx_bits.append(f"nspin = **{ctx['nspin']}**")
            if ctx_bits:
                body.append(
                    "**Contexte détecté :** " + " · ".join(ctx_bits) + "\n\n"
                )
        # Tableau récapitulatif : priority · category · title · level.
        body.append(
            "| Priorité | Catégorie | Niveau | Suggestion |\n"
            "|----------|-----------|--------|------------|\n"
        )
        for it in fs.phonon_recommendations:
            prio = int(it.get("priority") or 99)
            cat = str(it.get("category") or "?")
            lvl = str(it.get("level") or "info")
            title = str(it.get("title") or "")
            body.append(
                f"| {prio} | `{cat}` | {lvl} | {title} |\n"
            )
        body.append("\n")
        # Détails : title (h4) + body + action.
        body.append("\n### Détails et actions\n\n")
        for it in fs.phonon_recommendations:
            prio = int(it.get("priority") or 99)
            title = str(it.get("title") or "—")
            body_md = str(it.get("body") or "")
            action = str(it.get("action") or "")
            rationale = str(it.get("rationale") or "")
            src = it.get("source_keys") or []
            body.append(f"#### [{prio}] {title}\n\n")
            if body_md:
                body.append(f"{body_md}\n\n")
            if action:
                body.append(f"**Action :** {action}\n\n")
            if rationale:
                body.append(f"**Justification :** {rationale}\n\n")
            if src:
                body.append(
                    "<sub>Trace : `" + "`, `".join(str(s) for s in src) + "`</sub>\n\n"
                )
        body.append("\n")

    # --- 6. Durée de vie phonons (P4)
    body.append("\n## 6. Durée de vie des phonons (anharmonicité) — P4\n")
    if fs.phonon_lifetime_rows:
        body.append(_format_table_md(fs.phonon_lifetime_rows))
    else:
        body.append(
            "*Aucune sortie ``what='ph_life'`` détectée "
            "(thermfiles/ph_life, phonon_lifetime.dat, …).*\n"
        )

    # --- 7. Tenseur diélectrique ε∞ / ε₀ + Born (P5, LO/TO opt-in P1)
    body.append("\n## 7. Tenseur diélectrique (ε∞, ε₀) + charges effectives de Born\n")
    if fs.dielectric_rows:
        body.append(_format_table_md(fs.dielectric_rows))
    if fs.born_rows:
        body.append("\n### Charges effectives de Born Z* (par atome)\n")
        body.append(_format_table_md(fs.born_rows))
    if not fs.dielectric_rows and not fs.born_rows:
        body.append(
            "*Tenseur diélectrique non calculé (profil sans chaîne dielectric/LO-TO, "
            "ou opt-in LO/TO non activé sur P1).*\n"
        )

    # --- 8. Thermodynamique auxiliaire & propriétés étendues
    body.append(
        "\n## 8. Thermodynamique auxiliaire & propriétés étendues "
        "(Debye, Cv, F, S, α, Cₚ, extras P5)\n"
    )
    if fs.extras_rows:
        body.append(_format_table_md(fs.extras_rows))
    else:
        body.append(
            "*Aucune grandeur thermodynamique auxiliaire parsée pour ce run "
            "(attendre thermo_pw / phonons / re-parse disque).*\n"
        )

    # --- 8a. Couverture des grandeurs étendues
    if fs.extended_coverage_rows:
        body.append("\n## 8a. Couverture des propriétés étendues (statut run)\n")
        body.append(
            "Aligné sur le panneau UI « Couverture des propriétés étendues ». "
            "**Rempli** = valeur parsée présente ; **Absent** = pipeline OK mais "
            "donnée manquante sur ce run ; **Prévu** = feuille de route.\n\n"
        )
        body.append(_format_table_md(fs.extended_coverage_rows))

    # --- 8b. Figures / plots (E(V), bandes électroniques, DOS, etc.)
    if fs.plots_rows:
        body.append("\n## 8b. Figures (tracés gnuplot / PNG)\n")
        body.append(
            "Les tracés ci-dessous pointent vers les images PNG du work_dir. "
            "L'UI les affiche via ``/api/pipeline/result_image?job_id=…&path=…``.\n\n"
        )
        for label, relpath, _unit in fs.plots_rows:
            body.append(f"- **{label}** : `[{relpath}]({relpath})`\n")
        body.append("\n")

    # --- 8c. Artefacts produits (grandeurs parsées + fichiers)
    if fs.parsed_metrics_rows or fs.artifacts_rows:
        body.append("\n## 8c. Artefacts produits (grandeurs + fichiers)\n")
        if fs.parsed_metrics_rows:
            body.append("\n### Grandeurs parsées\n")
            body.append(_format_table_md(fs.parsed_metrics_rows))
        if fs.artifacts_rows:
            body.append(
                "\n### Fichiers sur disque\n"
                "Liste des artefacts utiles au diagnostic "
                "(GNU scripts, PNG/PDF, données brutes, entrées/sorties QE, markers). "
                "Les PostScript legacy (``.ps``) sont omis lorsqu'un PDF sibling existe. "
                "Capée à 80 fichiers. Liens : "
                "``/api/pipeline/runs/<job_id>/result_file?path=<relpath>&inline=1``.\n\n"
            )
            # Regrouper visuellement par ``kind``.
            from collections import OrderedDict
            by_kind: "OrderedDict[str, list[tuple[str, str]]]" = OrderedDict()
            for basename, relpath, kind in fs.artifacts_rows:
                by_kind.setdefault(kind, []).append((basename, relpath))
            for kind, items in by_kind.items():
                body.append(f"\n#### {kind.upper()} ({len(items)})\n")
                for basename, relpath in items:
                    body.append(f"- `{basename}` → `{relpath}`\n")
            body.append("\n")

    # --- 9. Sanity-checks scientifiques
    body.append("\n## 9. Validité scientifique (sanity-checks)\n")
    sum_text = (fs.sanity_summary or {}).get("score_text") or "indisponible"
    body.append(f"**Score global : {sum_text}**\n\n")
    if fs.sanity_checks:
        for c in fs.sanity_checks:
            lv = str(c.get("level") or "unknown")
            title = c.get("title") or c.get("id") or ""
            msg = c.get("message") or ""
            icon = c.get("icon") or ""
            body.append(
                f"- {icon} **{title}** — _niveau `{lv}`_ : {msg}\n"
            )
    else:
        body.append("*Aucun check applicable (work_dir absent ou sans sorties).*\n")

    # --- 10. Analyse experte (moteur rule-based factsheet_ai)
    body.append("\n## 10. 🧠 Analyse experte (moteur rule-based)\n")
    body.append(
        "Interprétation pédagogique générée par ``factsheet_ai.compute_insights`` "
        "(règles déterministes, **sans LLM**, sans API externe). Chaque insight "
        "pointe vers les clés ``pipeline_api_job_state.json`` dont il est issu.\n\n"
    )
    body.append(_render_ai_md(fs.ai_insights or []))

    body.append("\n---\n")
    body.append(f"_Fiche générée le {now_iso} UTC — backend/factsheet.py v1._\n")
    return "\n".join(body)


# ----- HTML renderer :


_HTML_CSS = """
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif;
       max-width: 1100px; margin: 1.5em auto; padding: 0 1.5em; color: #1a1a1a;
       line-height: 1.45; }
h1, h2, h3 { color: #1f3a5f; }
h1 { border-bottom: 2px solid #ff6e40; padding-bottom: 0.3em; }
h2 { margin-top: 1.8em; padding-left: 0.5em; border-left: 4px solid #ff6e40; }
h3 { margin-top: 1.4em; }
table { border-collapse: collapse; margin: 0.6em 0 1em 0; min-width: 60%; }
th, td { border: 1px solid #c9c9c9; padding: 6px 10px; text-align: left; }
th { background: #f4f4f4; font-weight: 600; }
td.val { font-family: ui-monospace, Menlo, Consolas, monospace; }
li { margin-bottom: 0.3em; }
.ft-note { color: #555; font-size: 0.9em; }
.ft-empty { color: #888; font-style: italic; }
.ft-ok { color: #1c6f3b; }
.ft-warn { color: #b07b00; }
.ft-error { color: #b03a2e; }
.ft-unknown { color: #555; }
code { background: #f0f0f0; padding: 1px 4px; border-radius: 3px; }
.ft-path { font-family: ui-monospace, Menlo, Consolas, monospace; word-break: break-all; }
.ft-footer { margin-top: 2em; padding-top: 1em; border-top: 1px solid #c9c9c9;
             font-size: 0.85em; color: #666; }
"""


def _level_class(lvl: str) -> str:
    return {
        "ok": "ft-ok",
        "warn": "ft-warn",
        "error": "ft-error",
        "unknown": "ft-unknown",
    }.get(str(lvl or "unknown").lower(), "ft-unknown")


def _format_table_html(rows: list[tuple[str, Any, str]]) -> str:
    if not rows:
        return '<p class="ft-empty">non calculé pour ce profil</p>\n'
    out = ["<table><thead><tr><th>Grandeur</th><th>Valeur</th><th>Unité</th></tr></thead><tbody>"]
    for label, value, unit in rows:
        val_s = _fmt(value)
        # Badge HTML injecte par ``_section_elastic`` : on preserve le HTML
        # brut pour permettre le rendu CSS du badge (``html.escape`` casserait
        # les ``<span class="badge ...">``). Si ``value`` n'est PAS un badge,
        # on retombe sur le chemin ``html.escape(val_s)`` standard.
        val_html = (
            value
            if isinstance(value, str) and value.startswith("<span ")
            else html.escape(val_s)
        )
        if unit:
            out.append(
                f"<tr><td>{html.escape(label)}</td>"
                f"<td class=\"val\">{val_html}</td>"
                f"<td>{html.escape(unit)}</td></tr>"
            )
        else:
            out.append(
                f"<tr><td>{html.escape(label)}</td>"
                f"<td class=\"val\" colspan=\"2\">{val_html}</td></tr>"
            )
    out.append("</tbody></table>")
    return "\n".join(out) + "\n"


def render_factsheet_html(fs: FactsheetSections) -> str:
    h = fs.header or {}
    now_iso = datetime.now(timezone.utc).isoformat(timespec="seconds")
    out: list[str] = []
    out.append(f"<!DOCTYPE html>\n<html lang=\"fr\">\n<head>\n")
    out.append("<meta charset=\"utf-8\">\n")
    out.append(
        f"<title>Fiche technique THERMO_PW — {html.escape(str(h.get('job_id', '?')))}"
        f" ({html.escape(str(h.get('profile_id', '?')))})</title>\n"
    )
    out.append(f"<style>{_HTML_CSS}</style>\n")
    out.append("</head>\n<body>\n")
    out.append(
        f"<h1>Fiche technique THERMO_PW — {html.escape(str(h.get('profile_id', '?')))}"
        f" — {html.escape(str(h.get('profile_name', '?')))}</h1>\n"
    )
    out.append(
        "<p class=\"ft-note\">Fiche générée par <code>backend/factsheet.py</code> — "
        "agrégat lecture-seule depuis <code>pipeline_api_job_state.json</code> + "
        "<code>scf.in</code> + sanity-checks scientifiques. Aucune valeur n'est "
        "calculée à la volée (route <code>GET /api/pipeline/runs/&lt;id&gt;/factsheet?format=md|html</code>).</p>\n"
    )

    # En-tête
    out.append("<h2>En-tête du run</h2>\n")
    # Toutes les tuples sont des triplets (label, value, unit) — contract cohérent
    # avec ``_format_table_html`` (sinon : unpack error 826).
    rows = [
        ("Job ID", h.get("job_id", "—"), ""),
        ("Profil", f"{h.get('profile_id', '—')} — {h.get('profile_name', '—')}", ""),
        ("thermo_pw what=", h.get("what_qe", "—"), ""),
        ("Matériau", h.get("material_id", "—"), ""),
        ("scf.in", h.get("scf_in_basename", "—"), ""),
        ("nproc MPI", str(h.get("nproc", "—")), ""),
        ("work_dir", h.get("work_dir", "—"), ""),
        ("Statut", h.get("status", "—"), ""),
        ("Créé le", h.get("created_at", "—"), ""),
        ("Terminé le", h.get("finished_at", "—"), ""),
    ]
    if h.get("extra_whats"):
        rows.append(("thermo_pw extras (P5)", ", ".join(map(str, h["extra_whats"])), ""))
    if h.get("p1_full_preset"):
        rows.append(("Preset P1 « complet »", "ACTIVÉ (ichamp=3 + DOS + Bandes)", ""))
    out.append(_format_table_html(rows))

    # EOS
    out.append("<h2>1. Équation d'état (Birch–Murnaghan) — P2/P3/P4</h2>\n")
    if fs.eos_rows:
        out.append(_format_table_html(fs.eos_rows))
    else:
        out.append('<p class="ft-empty">Aucun fit Birch-Murnaghan effectué pour ce profil '
                   '(P1/P5 n\'ont pas de grille EOS).</p>\n')

    # Elastic
    out.append("<h2>2. Constantes élastiques C_ij (Voigt) et modules polycristallins</h2>\n")
    if fs.elastic_rows_exec:
        out.append("<h3>Matrice cubique</h3>\n")
        out.append(_format_table_html(fs.elastic_rows_exec))
    else:
        out.append('<p class="ft-empty">Aucune constante C_ij unique extraite — '
                   'maille non cubique ou profil ne lance pas la chaîne '
                   'thermo_pw what=scf_elastic_constants / elastic_constants_geo '
                   '(P2/P4).</p>\n')
    if fs.elastic_rows_poly:
        out.append("<h3>Modules polycristallins (Hill VRH)</h3>\n")
        out.append(_format_table_html(fs.elastic_rows_poly))
    if fs.elastic_extra:
        out.append("<h3>Diagnostics (anisotropie / Pugh)</h3>\n")
        out.append(_format_table_html(fs.elastic_extra))

    # 2b. Évolution thermique P3 (C_ij(V₀, T) sur grille T)
    et_section = fs.elastic_t_section or {}
    et_rows = et_section.get("rows", [])
    if et_rows:
        t_min = et_section.get("t_min", 0.0)
        t_max = et_section.get("t_max", 0.0)
        n_points = et_section.get("n_points", 0)
        is_cubic = et_section.get("is_cubic", False)
        units_were_kbar = et_section.get("units_were_kbar", False)
        born_dict = et_section.get("born", {}) or {}
        out.append("<h2>2b. Évolution thermique P3/P4 (C_ij(V₀, T))</h2>\n")
        units_str = (
            "kbar → GPa (conversion appliquée)"
            if units_were_kbar
            else "GPa (déjà)"
        )
        out.append(
            f"<p class=\"ft-note\">Grille T : {int(t_min)}→{int(t_max)} K "
            f"({n_points} points, {units_str}).</p>\n"
        )
        if is_cubic and born_dict:
            out.append("<h3>Stabilité de Born (critère mécanique)</h3>\n")
            out.append("<ul>\n")
            for t_key, payload in sorted(born_dict.items()):
                ok, fails = payload
                cls = "ft-ok" if ok else "ft-error"
                verdict = "✅ Stable" if ok else f"❌ Instable — {'; '.join(fails)}"
                out.append(
                    f'  <li class="{cls}">T = {t_key} K : {html.escape(verdict)}</li>\n'
                )
            out.append("</ul>\n")
        out.append("<h3>Constantes élastiques C_ij(V₀, T)</h3>\n")
        out.append(
            "<table><thead><tr><th>T (K)</th><th>C₁₁ (GPa)</th>"
            "<th>C₁₂ (GPa)</th><th>C₄₄ (GPa)</th></tr>"
            "</thead><tbody>\n"
        )
        for t, c11, c12, c44 in et_rows[:21]:
            out.append(
                f"<tr><td>{int(t)}</td><td class=\"val\">{c11:.2f}</td>"
                f"<td class=\"val\">{c12:.2f}</td>"
                f"<td class=\"val\">{c44:.2f}</td></tr>\n"
            )
        if len(et_rows) > 21:
            out.append(
                f"<tr><td colspan=\"4\" class=\"ft-empty\">"
                f"+{len(et_rows) - 21} points T supplémentaires omis</td></tr>\n"
            )
        out.append("</tbody></table>\n")
        vrh_list = et_section.get("vrh", []) or []
        if is_cubic and vrh_list:
            out.append("<h3>Modules polycristallins VRH (Hill) — B/G/E/ν(T)</h3>\n")
            out.append(
                "<table><thead><tr><th>T (K)</th><th>B (GPa)</th>"
                "<th>G_V (GPa)</th><th>G_R (GPa)</th><th>G_Hill (GPa)</th>"
                "<th>E (GPa)</th><th>ν</th></tr></thead><tbody>\n"
            )
            for t, vrh in vrh_list[:21]:
                out.append(
                    f"<tr><td>{int(t)}</td>"
                    f"<td class=\"val\">{html.escape(_fmt(vrh['B_GPa'], n=2))}</td>"
                    f"<td class=\"val\">{html.escape(_fmt(vrh['G_V_GPa'], n=2))}</td>"
                    f"<td class=\"val\">{html.escape(_fmt(vrh['G_R_GPa'], n=2))}</td>"
                    f"<td class=\"val\">{html.escape(_fmt(vrh['G_Hill_GPa'], n=2))}</td>"
                    f"<td class=\"val\">{html.escape(_fmt(vrh['E_GPa'], n=2))}</td>"
                    f"<td class=\"val\">{html.escape(_fmt(vrh['nu'], n=3))}</td>"
                    f"</tr>\n"
                )
            if len(vrh_list) > 21:
                out.append(
                        "<tr><td colspan=\"7\" class=\"ft-empty\">"
                        f"+{len(vrh_list) - 21} points T supplémentaires</td></tr>\n"
                )
            out.append("</tbody></table>\n")
        out.append(
            "<p class=\"ft-note\">Plot associé : <code>elastic_vs_T_plot.png</code> "
            "(gnuplot : C_ij(T) et modules VRH vs T) — voir section 8b figures.</p>\n"
        )

    # Electronic
    out.append("<h2>3. Propriétés électroniques (NSCF + DOS + bandes)</h2>\n")
    if fs.electronic_rows or fs.electronic_extra:
        if fs.electronic_rows:
            out.append(_format_table_html(fs.electronic_rows))
        if fs.electronic_extra:
            out.append("<h3>Détails gap / nature</h3>\n")
            out.append(_format_table_html(fs.electronic_extra))
    else:
        out.append('<p class="ft-empty">Propriétés électroniques non produites — '
                   '<code>properties_ichamp</code> non enclenché '
                   '(chaîne NSCF + dos.x + bands.x non tournée).</p>\n')

    # Magnétisme
    out.append("<h2>4. Magnétisme (détection depuis scf.in)</h2>\n")
    out.append(_format_table_html(fs.magnetism_rows))

    # Stabilité unifiée — statique (Born) + dynamique (phonons DFPT).
    out.append("<h2>5. Stabilité (statique Born + dynamique DFPT)</h2>\n")
    if fs.stability_rows:
        out.append(_format_table_html(fs.stability_rows))
        if fs.stability_extra:
            out.append("<h3>Marges &amp; détails</h3>\n")
            out.append(_format_table_html(fs.stability_extra))
    elif fs.dyn_stability_rows:
        out.append(_format_table_html(fs.dyn_stability_rows))

    # 5b. Recommandations de vérification (juillet 2026)
    # On accède à ``n_imaginary_modes`` via ``fs.dyn_stability_rows`` plutôt
    # que ``results`` (qui n'est pas en scope dans ``render_factsheet_html(fs)``).
    n_imag_fs_html = None
    for _lab_fs_h, _val_fs_h, _u_fs_h in (fs.dyn_stability_rows or []):
        if _lab_fs_h == "Modes imaginaires" and _val_fs_h is not None:
            try:
                n_imag_fs_html = int(_val_fs_h)
            except (TypeError, ValueError):
                n_imag_fs_html = None
            break
    if fs.phonon_recommendations and (
        n_imag_fs_html is None or int(n_imag_fs_html or 0) > 0
    ):
        out.append(
            "<h2>5b. \U0001F50D Recommandations de vérification "
            "(fréquences imaginaires détectées)</h2>\n"
        )
        out.append(
            "<p class=\"ft-note\">Liste de propositions générée "
            "automatiquement (lecture-seule des artefacts du work_dir — pas "
            "de calcul supplémentaire). Trier par <strong>priorité</strong> "
            "descendante pour les causes les plus probables.</p>\n"
        )
        ctx_html = fs.phonon_recommendation_context or {}
        if ctx_html:
            ctx_bits_html: list[str] = []
            if ctx_html.get("xc"):
                ctx_bits_html.append(f"XC = <strong>{html.escape(str(ctx_html['xc']))}</strong>")
            if ctx_html.get("pseudo_family"):
                ctx_bits_html.append(
                    f"pseudos = <strong>{html.escape(str(ctx_html['pseudo_family']))}</strong>"
                )
            if ctx_html.get("nq"):
                nq_t = ctx_html["nq"]
                ctx_bits_html.append(
                    f"q-grid = <strong>{nq_t[0]}×{nq_t[1]}×{nq_t[2]}</strong>"
                )
            if ctx_html.get("tr2_ph") is not None:
                ctx_bits_html.append(
                    f"tr2_ph = <strong>{float(ctx_html['tr2_ph']):.1E}</strong>"
                )
            if ctx_html.get("conv_thr") is not None:
                ctx_bits_html.append(
                    f"conv_thr = <strong>{float(ctx_html['conv_thr']):.1E}</strong>"
                )
            if ctx_html.get("ecutwfc") is not None:
                ctx_bits_html.append(
                    f"ecutwfc = <strong>{float(ctx_html['ecutwfc']):.1f} Ry</strong>"
                )
            if ctx_html.get("asr"):
                ctx_bits_html.append(
                    f"ASR = <strong>{html.escape(str(ctx_html['asr']))}</strong>"
                )
            if ctx_html.get("nspin") is not None:
                ctx_bits_html.append(
                    f"nspin = <strong>{ctx_html['nspin']}</strong>"
                )
            if ctx_bits_html:
                out.append(
                    "<p><strong>Contexte détecté :</strong> "
                    + " · ".join(ctx_bits_html)
                    + "</p>\n"
                )
        out.append(
            "<table><thead><tr><th>Priorité</th><th>Catégorie</th>"
            "<th>Niveau</th><th>Suggestion</th></tr></thead><tbody>\n"
        )
        for it_html in fs.phonon_recommendations:
            prio_h = int(it_html.get("priority") or 99)
            cat_h = str(it_html.get("category") or "?")
            lvl_h = str(it_html.get("level") or "info")
            title_h = str(it_html.get("title") or "")
            out.append(
                f"<tr><td>{prio_h}</td>"
                f"<td><code>{html.escape(cat_h)}</code></td>"
                f"<td>{html.escape(lvl_h)}</td>"
                f"<td>{html.escape(title_h)}</td></tr>\n"
            )
        out.append("</tbody></table>\n")
        out.append("<h3>Détails et actions</h3>\n")
        out.append("<ul class=\"ft-rec-list\">\n")
        for it_html in fs.phonon_recommendations:
            prio_h = int(it_html.get("priority") or 99)
            title_h = str(it_html.get("title") or "—")
            body_h = str(it_html.get("body") or "")
            action_h = str(it_html.get("action") or "")
            rationale_h = str(it_html.get("rationale") or "")
            src_h = it_html.get("source_keys") or []
            out.append(f"  <li class=\"ft-rec\">\n")
            out.append(
                f"    <h4>[{prio_h}] {html.escape(title_h)}</h4>\n"
            )
            if body_h:
                out.append(f"    <p>{html.escape(body_h)}</p>\n")
            if action_h:
                out.append(
                    f"    <p><strong>Action :</strong> {html.escape(action_h)}</p>\n"
                )
            if rationale_h:
                out.append(
                    f"    <p><strong>Justification :</strong> "
                    f"{html.escape(rationale_h)}</p>\n"
                )
            if src_h:
                src_joined = ", ".join(f"<code>{html.escape(str(s))}</code>" for s in src_h)
                out.append(f"    <p class=\"ft-note\"><sub>Trace : {src_joined}</sub></p>\n")
            out.append("  </li>\n")
        out.append("</ul>\n")

    # P4 phonons lifetime
    out.append("<h2>6. Durée de vie des phonons (anharmonicité) — P4</h2>\n")
    if fs.phonon_lifetime_rows:
        out.append(_format_table_html(fs.phonon_lifetime_rows))
    else:
        out.append('<p class="ft-empty">Aucune sortie <code>what=ph_life</code> détectée '
                   '(thermfiles/ph_life, phonon_lifetime.dat, …).</p>\n')

    # P5 dielectric + ε₀ / LO-TO
    out.append("<h2>7. Tenseur diélectrique (ε∞, ε₀) + charges effectives de Born</h2>\n")
    if fs.dielectric_rows:
        out.append(_format_table_html(fs.dielectric_rows))
    if fs.born_rows:
        out.append("<h3>Charges effectives de Born Z* (par atome)</h3>\n")
        out.append(_format_table_html(fs.born_rows))
    if not fs.dielectric_rows and not fs.born_rows:
        out.append(
            '<p class="ft-empty">Tenseur diélectrique non calculé (chaîne dielectric/LO-TO '
            "absente ou opt-in LO/TO non activé sur P1).</p>\n"
        )

    # Thermodynamique auxiliaire & étendues
    out.append(
        "<h2>8. Thermodynamique auxiliaire &amp; propriétés étendues "
        "(Debye, Cv, F, S, α, Cₚ, extras P5)</h2>\n"
    )
    if fs.extras_rows:
        out.append(_format_table_html(fs.extras_rows))
    else:
        out.append(
            '<p class="ft-empty">Aucune grandeur thermodynamique auxiliaire parsée pour ce run.</p>\n'
        )

    if fs.extended_coverage_rows:
        out.append("<h2>8a. Couverture des propriétés étendues (statut run)</h2>\n")
        out.append(
            '<p class="ft-note">Aligné sur le panneau UI « Couverture des propriétés étendues ».</p>\n'
        )
        out.append(_format_table_html(fs.extended_coverage_rows))

    # 8b. Figures / plots (E(V), bandes, DOS, …)
    if fs.plots_rows:
        out.append("<h2>8b. Figures (tracés gnuplot / PNG)</h2>\n")
        out.append(
            "<p class=\"ft-note\">Les images ci-dessous sont servies par "
            "<code>/api/pipeline/result_image?job_id=…&amp;path=…</code> "
            "(résolution de chemin depuis le work_dir du job).</p>\n"
        )
        out.append("<div class=\"ft-figures\">\n")
        for label, relpath, _unit in fs.plots_rows:
            img_src = (
                f"/api/pipeline/result_image?job_id="
                f"{html.escape(str(h.get('job_id', '')))}"
                f"&path={html.escape(str(relpath))}"
            )
            cap = html.escape(str(label))
            alt = html.escape(str(label))
            out.append(
                f'  <figure>\n'
                f'    <img src="{img_src}" alt="{alt}" loading="lazy" '
                f'style="max-width:100%;border:1px solid #d0d0d0;border-radius:4px;"/>\n'
                f'    <figcaption><strong>{cap}</strong> — '
                f'<code class="ft-path">{html.escape(str(relpath))}</code></figcaption>\n'
                f'  </figure>\n'
            )
        out.append("</div>\n")

    # 8c. Artefacts — grandeurs parsées + fichiers (sans redondance ps/pdf).
    if fs.parsed_metrics_rows or fs.artifacts_rows:
        out.append("<h2>8c. Artefacts produits (grandeurs + fichiers)</h2>\n")
        if fs.parsed_metrics_rows:
            out.append("<h3>Grandeurs parsées</h3>\n")
            out.append(_format_table_html(fs.parsed_metrics_rows))
        if fs.artifacts_rows:
            out.append(
                "<h3>Fichiers sur disque</h3>\n"
                "<p class=\"ft-note\">Artefacts du work_dir (cap 80). Les <code>.ps</code> "
                "legacy sont omis si un PDF sibling existe. Clic = "
                "<code>/api/pipeline/runs/&lt;job_id&gt;/result_file?path=…&amp;inline=1</code>.</p>\n"
            )
            from collections import OrderedDict
            by_kind_html: "OrderedDict[str, list[tuple[str, str]]]" = OrderedDict()
            for basename, relpath, kind in fs.artifacts_rows:
                by_kind_html.setdefault(kind, []).append((basename, relpath))
            out.append("<div class=\"ft-artifacts\">\n<ul>\n")
            job_id_q = html.escape(str(h.get("job_id", "")))
            for kind, items in by_kind_html.items():
                out.append(f'  <li><strong>[{html.escape(kind.upper())}]</strong> ({len(items)})<ul>\n')
                for basename, relpath in items:
                    link = (
                        f"/api/pipeline/runs/{job_id_q}/result_file"
                        f"?path={html.escape(str(relpath))}&amp;inline=1"
                    )
                    out.append(
                        f'    <li><a href="{link}" target="_blank" rel="noopener">'
                        f'{html.escape(basename)}</a> '
                        f'<code class="ft-path">{html.escape(str(relpath))}</code></li>\n'
                    )
                out.append("  </ul></li>\n")
            out.append("</ul>\n</div>\n")

    # Sanity
    out.append("<h2>9. Validité scientifique (sanity-checks)</h2>\n")
    sum_text = (fs.sanity_summary or {}).get("score_text") or "indisponible"
    out.append(f"<p><strong>Score global : {html.escape(sum_text)}</strong></p>\n")
    if fs.sanity_checks:
        out.append("<ul>\n")
        for c in fs.sanity_checks:
            lv = str(c.get("level") or "unknown")
            cls = _level_class(lv)
            title = c.get("title") or c.get("id") or ""
            msg = c.get("message") or ""
            icon = c.get("icon") or ""
            out.append(
                f'  <li><span class="{cls}">{html.escape(icon)}</span> '
                f'<strong>{html.escape(title)}</strong> '
                f'<em>niveau <code>{html.escape(lv)}</code></em> : '
                f'{html.escape(msg)}</li>\n'
            )
        out.append("</ul>\n")
    else:
        out.append('<p class="ft-empty">Aucun check applicable.</p>\n')

    # Analyse experte (moteur rule-based factsheet_ai).
    out.append("<h2>10. 🧠 Analyse experte (moteur rule-based)</h2>\n")
    out.append(
        "<p class=\"ft-note\">Interprétation pédagogique générée par "
        "<code>factsheet_ai.compute_insights</code> — règles déterministes, "
        "<strong>sans LLM externe</strong>. Chaque insight référence les "
        "clés du marker dont il est issu.</p>\n"
    )
    out.append(_render_ai_html(fs.ai_insights or []))

    out.append("<div class=\"ft-footer\">\n")
    out.append(
        f"Fiche générée le {html.escape(now_iso)} UTC — backend/factsheet.py v1. "
        "Cette fiche ne lance aucun calcul : elle lit le marker pipeline et "
        "scf.in, agrège les sections, puis formate.\n"
    )
    out.append("</div>\n")
    out.append("</body>\n</html>\n")
    return "".join(out)# ============================================================================
# Lecture marker depuis disque (helper pour l'endpoint API)
# ============================================================================

__all__ = [
    "detect_magnetism",
    "assemble_factsheet",
    "render_factsheet_md",
    "render_factsheet_html",
    "render_factsheet_pdf",
    "_resolve_pdf_backend",
    "read_marker_from_workdir",
    "register_factsheet_blueprint",
]  


def read_marker_from_workdir(work_dir: Path) -> dict[str, Any] | None:
    """Charge ``pipeline_api_job_state.json`` sous work_dir.

    Renvoie ``None`` si le marker est absent / illisible. En cas d'erreur JSON,
    ne lève pas — l'appelant gère le 404 lui-même.
    """
    marker = Path(work_dir) / "pipeline_api_job_state.json"
    if not marker.is_file():
        return None
    try:
        return json.loads(marker.read_text(encoding="utf-8", errors="replace"))
    except (OSError, json.JSONDecodeError):
        return None


# ============================================================================
# Flask blueprint — GET /api/pipeline/runs/<job_id>/factsheet
# ============================================================================
#
# Sert la fiche technique d'un run au format md | html.
# Le format par défaut est ``html`` (boot UX direct) ; ``md`` via ``?format=md``.
# Le contenu est généré à la volée depuis ``pipeline_api_job_state.json`` et
# ``scf.in`` via ``assemble_factsheet``. Aucune écriture MPI n'est lancée —
# c'est un agrégat lecture-seule idempotent.
#
# Codes HTTP :
#   * 200 — fiche rendue (Content-Type ``text/markdown`` ou ``text/html``).
#   * 404 — ``job_id`` inconnu OU marker disque absent / illisible.
#   * 400 — ``?format=`` invalide (≠ md/html).
#   * 500 — work_dir introuvable OU profil inconnu (bug, ne devrait pas
#     survenir si le job est sorti via le pipeline).
#
# Le blueprint est enregistré via ``register_factsheet_blueprint(app)`` dans
# ``api_server.py`` après ``register_pipeline_blueprint`` (cinq profils P1..P5).
# ============================================================================


def register_factsheet_blueprint(app) -> None:
    """Ajoute la route ``GET /api/pipeline/runs/<job_id>/factsheet`` à ``app``.

    Args:
        app: instance Flask (typiquement ``api_server.app``).
    """
    from flask import Blueprint, Response, jsonify, request

    factsheet_bp = Blueprint("factsheet", __name__)

    @factsheet_bp.route(
        "/api/pipeline/runs/<job_id>/factsheet",
        methods=("GET", "OPTIONS"),
        strict_slashes=False,
    )
    def get_factsheet(job_id: str):
        if request.method == "OPTIONS":
            # Prévol CORS — laisse passer le browser si proxy demandait.
            return ("", 204)
        fmt = (request.args.get("format") or "html").strip().lower()
        if fmt not in ("md", "markdown", "html", "pdf"):
            return (
                jsonify(
                    {
                        "error": (
                            "Format invalide ; utilisez ``md``, ``html`` ou ``pdf`` "
                            "(défaut : html). Le format PDF n'est servi que si le "
                            "backend ``weasyprint`` est utilisable côté serveur."
                        ),
                        "allowed_formats": ["md", "html", "pdf"],
                    }
                ),
                400,
            )
        # 1. Retrouver le work_dir du job. Trois sources, par ordre de priorité :
        marker = None
        work_dir: Optional[Path] = None
        # (a) PipelineJob vivant en mémoire (job en cours / récemment persisté).
        try:
            from pipeline import PipelineJob  # local import ; circulaire ok.
            with PipelineJob._REGISTRY_LOCK:
                job = PipelineJob._REGISTRY.get(job_id)
            if job is not None and getattr(job, "work_dir", None):
                work_dir = Path(job.work_dir)
                marker = job.to_dict()
        except Exception:
            pass
        # (b) Marker disque (``pipeline_api_job_state.json``).
        if marker is None:
            # On cherche d'abord via le marker directement (work_dir résolu depuis
            # la racine ``work/`` du projet, regroupé par matériau).
            try:
                import config as cfg
                work_root = cfg.WORK_ROOT.resolve()
                # Recherche exhaustive bornée : 2 niveaux sous work/.
                work_dir_found = None
                marker_dict_local = None
                for mat_dir in work_root.iterdir():
                    if not mat_dir.is_dir():
                        continue
                    if mat_dir.name.startswith("."):
                        continue
                    for run_dir in mat_dir.iterdir():
                        if not run_dir.is_dir():
                            continue
                        marker_path = run_dir / _MARKER_FILENAME
                        if not marker_path.is_file():
                            continue
                        try:
                            d = json.loads(
                                marker_path.read_text(encoding="utf-8", errors="replace")
                            )
                        except (OSError, json.JSONDecodeError):
                            continue
                        if str(d.get("job_id") or "") == job_id:
                            work_dir_found = run_dir
                            marker_dict_local = d
                            break
                    if work_dir_found is not None:
                        break
                if work_dir_found is not None:
                    work_dir = work_dir_found
                    marker = marker_dict_local
            except Exception:
                work_dir = None
                marker = None
        if marker is None or work_dir is None:
            return (
                jsonify(
                    {
                        "error": "job_id introuvable",
                        "job_id": job_id,
                        "hint": (
                            "Le job n'est plus en mémoire (API redémarrée depuis "
                            "longtemps) et aucun ``pipeline_api_job_state.json`` "
                            "ne contient ce job_id sous ``work/<mat>/pipeline_*/``."
                        ),
                    }
                ),
                404,
            )
        # 2. Profil + résultats.
        profile_id = str(marker.get("profile_id") or "").strip()
        try:
            # Juillet 2026 (bugfix) - on importe sous un nom local distinct
            # (``_PIPELINE_PROFILES``) pour eviter de masquer le `PROFILES`
            # au sens UnboundLocalError : si l'import echoue (circular
            # import transitoire, etc.), on initialise le fallback a ``{}``
            # pour que ``sorted(_PIPELINE_PROFILES.keys())`` plus bas ne
            # leve pas. Le ``global PROFILES`` n'aide pas ici car factsheet
            # n'a pas de module-level PROFILES.
            from pipeline import PROFILES as _PIPELINE_PROFILES
            profile = _PIPELINE_PROFILES.get(profile_id) or {}
        except Exception:
            profile = {}
            _PIPELINE_PROFILES = {}  # fallback pour L104 ci-dessous.
        if not profile_id or not profile:
            # Coeur de la fiche : le profil est indispensable (groupes + units).
            return (
                jsonify(
                    {
                        "error": (
                            f"Profil inconnu ou absent du marker : {profile_id!r}. "
                            "Le job a peut-être été créé par une version plus "
                            "récente de l'API."
                        ),
                        "known_profiles": sorted(_PIPELINE_PROFILES.keys()),
                    }
                ),
                500,
            )
        results = marker.get("results") or {}
        # 3. Assemblage.
        try:
            fs = assemble_factsheet(
                work_dir=work_dir,
                profile_id=profile_id,
                profile=profile,
                results=results,
                marker_root=marker,
            )
        except Exception as ex:  # noqa: BLE001
            return (
                jsonify(
                    {
                        "error": "assemble_factsheet a levé une exception.",
                        "detail": str(ex),
                        "type": type(ex).__name__,
                    }
                ),
                500,
            )
        # 4. Rendu *factorisé* : md|html|pdf partagent le même pipeline.
        #    md → text/markdown (utf-8) ; html → text/html (utf-8) ;
        #    pdf → application/pdf (bytes). md et html passent par
        #    ``render_factsheet_md``/``render_factsheet_html`` directement ;
        #    pdf réutilise le HTML comme IR commun — voir ``render_factsheet_pdf``.
        fmt_norm = (
            "md" if fmt == "md" else
            "md" if fmt == "markdown" else
            fmt if fmt in ("html", "pdf") else
            "html"
        )
        _MIME_BY_FMT = {
            "md": "text/markdown; charset=utf-8",
            "html": "text/html; charset=utf-8",
            "pdf": "application/pdf",
        }
        _EXT_BY_FMT = {"md": "md", "html": "html", "pdf": "pdf"}
        try:
            if fmt_norm == "md":
                content = render_factsheet_md(fs).encode("utf-8")
            elif fmt_norm == "html":
                content = render_factsheet_html(fs).encode("utf-8")
            else:  # pdf
                try:
                    content = render_factsheet_pdf(fs)
                except _PdfDependencyError as ex:
                    # Backend PDF absent côté serveur — 503 (Service Unavailable).
                    # On documente précisément le format pdf indisponible et on
                    # guide vers l'installation. L'UI grise l'option PDF du
                    # sélecteur via ``factsheet_pdf_available`` dans /api/health.
                    return (
                        jsonify(
                            {
                                "error": "Backend PDF indisponible.",
                                "detail": str(ex),
                                "available_formats": ["md", "html"],
                                "backend_requested": "weasyprint",
                                "hint": (
                                    "Installer ``weasyprint`` côté serveur "
                                    "(``pip install weasyprint`` + Cairo/Pango "
                                    "système) puis redémarrer l'API."
                                ),
                            }
                        ),
                        503,
                    )
        except Exception as ex:  # noqa: BLE001
            return (
                jsonify(
                    {
                        "error": f"render_factsheet_{fmt_norm} a échoué.",
                        "detail": str(ex),
                        "type": type(ex).__name__,
                    }
                ),
                500,
            )
        resp = Response(content, mimetype=_MIME_BY_FMT[fmt_norm])
        # 5. Headers sémantiques (Content-Disposition pour téléchargement + cache no-store).
        from urllib.parse import quote
        safe_job = re.sub(r"[^A-Za-z0-9._-]+", "_", job_id)[:48] or "factsheet"
        profile_tag = re.sub(r"[^A-Za-z0-9._-]+", "_", profile_id)[:12] or "P"
        filename = f"factsheet_{profile_tag}_{safe_job}.{_EXT_BY_FMT[fmt_norm]}"
        # RFC 5987 : filename* pour les caractères non-ASCII.
        quoted = quote(filename)
        resp.headers["Content-Disposition"] = (
            f"inline; filename=\"{filename}\"; filename*=UTF-8''{quoted}"
        )
        resp.headers["Cache-Control"] = "no-store, max-age=0"
        return resp

    app.register_blueprint(factsheet_bp)


# Marqueur utilisé ci-dessus (symbole partagé avec PipelineJob._MARKER_FILENAME,
# mais conservé indépendant pour permettre l'import de factsheet sans pipeline).
_MARKER_FILENAME = "pipeline_api_job_state.json"

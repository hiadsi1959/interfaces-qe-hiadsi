"""
``backend.phonon_imaginary_recommendations`` — suggestions automatiques
quand ``properties.n_imaginary_modes > 0`` est détecté.

But : aider l'utilisateur à diagnostiquer et à corriger un run THERMO_PW qui
produit des fréquences imaginaires (matériau apparemment dynamiquement
instable d'après le calcul DFPT) **sans relancer le calcul**.

Approche : lecture-seule des artefacts du work_dir et du marker
``pipeline_api_job_state.json`` ; pas de calcul MPI / DFPT supplémentaire.
Le module inspecte :

  * ``ATOMIC_SPECIES`` (``scf.in`` / ``pw_scf_V0_for_phonon.in`` / ``scf_eq.in``)
    → repère les pseudopotentiels utilisés (PAW/USPP/SOC).
  * ``input_dft`` ou ``&SYSTEM`` → repère le XC (PBE / LDA / PBEsol / SCAN).
  * ``CONVVAR``/``&CONTROL`` → repère ``ecutwfc`` / ``conv_thr`` côté pw.x.
  * ``&INPUTPH``/``ph.in``/``ph_control`` → repère ``tr2_ph``, ``nq1``/``nq2``/
    ``nq3``, ``start_irr``, ``last_irr``.
  * ``q2r.in`` → repère l'ASR (zasr simple/crystal/all/no).

Les recommandations sont triées par ``priority`` (1 = cause la plus probable
ou la plus urgente à corriger) et regroupées par catégorie (pseudo / XC /
convergence / q_grid / asr / geometry / cross_validation). Format sérialisable
JSON-compatible — vit dans ``properties.verification_recommendations`` du
marker ``pipeline_api_job_state.json``.

Catégories :
  * **pseudopotential** : alternative PAW → USPP, GBRV vs PSLibrary, ONCV, etc.
  * **xc** : tester LDA / PBEsol / SCAN pour valider la dépendance XC.
  * **soc** : activer spin-orbit coupling si magnétique.
  * **convergence** : tr2_ph / conv_thr / ecutwfc mal calibrés.
  * **q_grid** : nq1=nq2=nq3=2 ou 3 → augmenter pour éliminer les artefacts
                  d'interpolation Fourier en bord de zone.
  * **asr** : tester ``zasr='crystal'`` (plus strict que 'simple').
  * **geometry** : relaxation ionique / VD relax / vérifier positions internes.
  * **cross_validation** : rejouer avec phonopy Finite-Displacement
                            (vérification indépendante).

Convention : à chaque recommandation est associé ``source_keys`` (liste
des chemins ``pipeline_api_job_state.json`` ou artefacts ``*.in``
dont l'inspection a déclenché la suggestion). Permet à l'UI / à un
auditeur de **retracer** chaque suggestion — l'utilisateur peut toujours
voir pourquoi telle proposition a été faite.

L'API publique est ``build_phonon_imaginary_recommendations(work_dir,
results) -> Dict`` qui renvoie ``{"has_imaginary": bool, "omega_min_cm-1":
float, "n_imaginary_modes": int, "categories": List[str], "items":
List[Dict]}``. ``find_phonon_imaginary_recommendations`` est l'alias
rétro-compatible pour les appels qui n'ont besoin que de ``items``.
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Constantes physiques et seuils (juillet 2026) — ajustables ici
# ---------------------------------------------------------------------------
# Recommandations déclenchées selon l'écart à ces bornes. Les seuils sont
# choisis en accord avec la littérature DFPT standard (cf. STAR protocol
# phonon DFT, Proceedings of the workshop ``Phonons@DFPT 2025``) :

TR2_PH_TIGHT = 1.0e-14      # tr2_ph ≤ 1e-14 = bon ; > 1e-14 = peut être tendre
TR2_PH_VERY_TIGHT = 1.0e-15 # ≤ 1e-15 = très bon, plus de gain marginal rare
ECUTWFC_MEDIUM = 60.0       # Ry ; ≥ 60 Ry recommandé pour forces précises
ECUTWFC_TIGHT = 80.0        # Ry ; ≥ 80 Ry pour matériaux durs / phonon Lif
CONV_THR_MEDIUM = 1.0e-10   # Ry ; ≤ 1e-10 = bon, > 1e-10 = SCF trop lâche
CONV_THR_LOOSE = 1.0e-8     # > 1e-8 = SCF très lâche (forces bruitées)
NQ_MIN = 4                  # < 4 = interpolation Fourier peu fiable
NQ_RECOMMENDED = 6          # ≥ 6 = bonne grille standard
NQ_HIGH = 8                 # ≥ 8 pour matériaux mous / études des branches TA


# ---------------------------------------------------------------------------
# Dataclass sérialisable (JSON-compatible)
# ---------------------------------------------------------------------------

@dataclass
class PhononImaginaryRecommendation:
    """Suggestion unit (JSON-compatible via asdict)."""

    level: str           # "info" | "warning" | "error" (cohérent avec sanity_checks)
    category: str        # "pseudopotential" | "xc" | "soc" |
                         # "convergence" | "q_grid" | "asr" |
                         # "geometry" | "cross_validation"
    priority: int        # 1..N ; 1 = cause la plus probable
    title: str
    body: str
    action: str          # Impératif court (« Augmenter nq1→6×6×6 »)
    rationale: str       # Phrase physique (« interpolation Fourier 2×2×2 → pics
                         # parasites sur Γ-X, mode TA(X) mou »)
    source_keys: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Helpers internes — lecture défensive des inputs
# ---------------------------------------------------------------------------

def _read_text_bounded(path: Path, max_bytes: int = 8 * 1024 * 1024) -> Optional[str]:
    """Lecture texte limitée ; renvoie None si fichier trop gros ou inaccessible."""
    try:
        if not path.is_file():
            return None
        size = path.stat().st_size
        if size > max_bytes:
            with path.open("r", encoding="utf-8", errors="replace") as f:
                return f.read(max_bytes)
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None


def _read_first_existing(work_dir: Path, names: tuple[str, ...]) -> Optional[tuple[str, str]]:
    """Renvoie ``(filename_used, content)`` du premier fichier existant dans la liste."""
    for name in names:
        try:
            txt = _read_text_bounded(work_dir / name)
            if txt is not None and txt.strip():
                return (name, txt)
        except OSError:
            continue
    return None


def _parse_floats(pattern: re.Pattern[str], text: str) -> Optional[float]:
    """Renvoie le premier scalaire ``val`` capturé par ``pattern`` comme float.

    Helper très défensif : ``pattern`` doit exposer au moins un groupe nommé
    ``val``. La fonction :
      * ``re.search`` (pas ``finditer``) : on n'attend qu'UNE valeur par clé ;
      * ``rstrip(", \t")`` AVANT ``float()`` pour absorber une virgule finale
        du style Fortran (``tr2_ph = 1.0d-14,``) ;
      * reste silencieuse (``None``) sur valeur manquante ou malformée.

    NB historique : une version précédente essayait de cacher la clé
    scannée via un groupe nommé ``name`` et un dict de résultats — c'est
    fragile car plusieurs regexes n'exposent que ``val``. Cette version
    simplifiée ne retourne qu'un ``Optional[float]`` et laisse chaque
    ``_detect_xxx`` appliquer sa propre logique d'utilisation.
    """
    m = pattern.search(text)
    if m is None:
        return None
    try:
        raw = m.group("val")
        # Conversion Fortran ``D``/``d`` → Python ``E`` + strip des séparateurs
        # parasites (``','``, espaces) qui polluent la lecture d'un
        # dernier token Fortran.
        cleaned = raw.replace("D", "E").replace("d", "e").rstrip(", \t")
        return float(cleaned)
    except (AttributeError, ValueError, IndexError):
        return None


# ---------------------------------------------------------------------------
# Lecture SCF : XC, ecutwfc, conv_thr, ATOMIC_SPECIES, lda_plus_u, nspin
# ---------------------------------------------------------------------------

_RX_INPUT_DFT = re.compile(
    r"(?im)^\s*input_dft\s*=\s*['\"]?\s*(?P<val>[A-Za-z0-9_\-]+)\s*['\"]?\s*,?\s*$"
)
# Detection heuristique RB exchange (compte ``input_dft='PBE'`` ou similaire).
_RX_HUBBARD_U = re.compile(
    r"(?im)^\s*Hubbard_U\s*\(\s*(?P<idx>\d+)\s*\)\s*=\s*(?P<val>[+-]?[\d.EeDd+\-]+)"
)
_RX_LDA_PLUS_U = re.compile(
    r"(?im)^\s*lda_plus_u\s*=\s*\.(?P<val>true|false)\.\s*,?\s*$"
)
_RX_NSPIN = re.compile(r"(?im)^\s*nspin\s*=\s*(?P<val>\d+)")
_RX_SOC = re.compile(r"(?im)^\s*lspinorb\s*=\s*\.(?P<val>true|false)\.")
# Les blocs ``&CONTROL`` et ``&SYSTEM`` peuvent porter des clés communes ;
# on cherche dans tout le fichier sans distinction pour la SCF.
_RX_ECUTWFC = re.compile(
    r"(?im)^\s*ecutwfc\s*=\s*(?P<val>[+-]?[\d.EeDd+\-]+)"
)
_RX_CONV_THR = re.compile(
    r"(?im)^\s*conv_thr\s*=\s*(?P<val>[+-]?[\d.EeDd+\-]+)"
)
# ATOMIC_SPECIES : ``Label  Mass  UPF_file`` sur une ligne.
_RX_ATOMIC_SPECIES = re.compile(
    r"(?im)^\s*(?P<label>[A-Za-z][A-Za-z0-9_]*)\s+"
    r"(?P<mass>[\d.]+(?:[EeDd][+\-]?\d+)?)\s+"
    r"(?P<upf>\S+\.(?:UPF|upf))\s*$"
)


def _detect_xc(pw_text: Optional[str]) -> Optional[str]:
    """Renvoie le XC détecté : ``'PBE'``, ``'LDA'``, ``'PBEsol'``, ``'SCAN'``
    ou ``None`` si indéterminé."""
    if not pw_text:
        return None
    m = _RX_INPUT_DFT.search(pw_text)
    if m:
        return m.group("val").upper()
    # Heuristique : nom de fichier de pseudo contient ``pbe``, ``lda``, etc.
    for m in _RX_ATOMIC_SPECIES.finditer(pw_text):
        upf = m.group("upf").lower()
        if "pbesol" in upf or "pbe_sol" in upf:
            return "PBESOL"
        if "scan" in upf:
            return "SCAN"
        if "pbe" in upf:
            return "PBE"
        if "hse" in upf or "pbe0" in upf:
            return "HSE"
        if "lda" in upf or "pz" in upf:
            return "LDA"
    return None


def _detect_pseudo_family(pw_text: Optional[str]) -> tuple[Optional[str], list[str]]:
    """Renvoie ``(family, list_of_species_chem)`` : family ∈ {PAW, USPP, NCPP} ou None.

    Heuristique par nom de fichier UPF (conventions PSLibrary / GBRV /
    ONCV / PBE / Hartwigsen -- SSSP :
      * PAW : fichiers ``*paw*``, ``*kjpaw*``, ``*nlcc_paw*``, ``*PAW*``.
      * USPP : fichiers ``*rrkjus*``, ``*uspp*``, ``*ncpus*``, ``*van*``.
      * NC (Norm-Conserving) : tous les autres dont ``*nc*``, ``*fhi*``.
    """
    if not pw_text:
        return None, []
    families: set[str] = set()
    species: list[str] = []
    paw_re = re.compile(r"(paw|nlcc|kpaw)", re.IGNORECASE)
    uspp_re = re.compile(r"(rrkjus|uspp|ncpus)", re.IGNORECASE)
    nc_re = re.compile(r"(?:\.nc(?!\S)|fhi|oncv)", re.IGNORECASE)
    for m in _RX_ATOMIC_SPECIES.finditer(pw_text):
        label = m.group("label")
        upf = m.group("upf")
        if species.count(label.split()[0]) == 0:
            species.append(label.split()[0])
        if paw_re.search(upf):
            families.add("PAW")
        elif uspp_re.search(upf):
            families.add("USPP")
        elif nc_re.search(upf):
            families.add("NORM_CONSERVING")
        else:
            # Inconnu → ne devine pas.
            continue
    if not families:
        return None, species
    if len(families) > 1:
        return "MIXED", species
    return next(iter(families)), species


# ---------------------------------------------------------------------------
# Lecture ph.in / ph_control / q2r.in
# ---------------------------------------------------------------------------

_RX_TR2_PH = re.compile(
    r"(?im)^\s*tr2_ph\s*=\s*(?P<val>[+-]?[\d.EeDd+\-]+)"
)
_RX_NQ1 = re.compile(r"(?im)\bnq1\s*=\s*(?P<val>\d+)")
_RX_NQ2 = re.compile(r"(?im)\bnq2\s*=\s*(?P<val>\d+)")
_RX_NQ3 = re.compile(r"(?im)\bnq3\s*=\s*(?P<val>\d+)")
_RX_ZASR_Q2 = re.compile(
    r"(?im)^\s*zasr\s*=\s*['\"]?(?P<val>[A-Za-z]+)['\"]?\s*,?\s*$"
)


def _detect_asr(work_dir: Path) -> Optional[str]:
    """Lit ``q2r.in`` (ph_control prioritaire ? -- ici q2r.in fait foi)."""
    txt = _read_first_existing(work_dir, ("q2r.in",))
    if not txt:
        return None
    m = _RX_ZASR_Q2.search(txt[1])
    if m:
        return m.group("val").lower()
    return None


def _detect_nq(work_dir: Path) -> Optional[tuple[int, int, int]]:
    for fn in ("ph.in", "ph_control"):
        txt = _read_first_existing(work_dir, (fn,))
        if not txt:
            continue
        m1, m2, m3 = _RX_NQ1.search(txt[1]), _RX_NQ2.search(txt[1]), _RX_NQ3.search(txt[1])
        if m1 and m2 and m3:
            try:
                return (int(m1.group("val")), int(m2.group("val")), int(m3.group("val")))
            except ValueError:
                return None
    return None


def _detect_tr2_ph(work_dir: Path) -> Optional[float]:
    for fn in ("ph.in", "ph_control"):
        txt = _read_first_existing(work_dir, (fn,))
        if not txt:
            continue
        v = _parse_floats(_RX_TR2_PH, txt[1])
        if v is not None:
            return v
    return None


def _detect_ecutwfc(work_dir: Path) -> Optional[float]:
    for fn in ("pw_scf_V0_for_phonon.in", "scf_eq.in", "scf.in"):
        txt = _read_first_existing(work_dir, (fn,))
        if not txt:
            continue
        v = _parse_floats(_RX_ECUTWFC, txt[1])
        if v is not None:
            return v
    return None


def _detect_conv_thr(work_dir: Path) -> Optional[float]:
    for fn in ("pw_scf_V0_for_phonon.in", "scf_eq.in", "scf.in"):
        txt = _read_first_existing(work_dir, (fn,))
        if not txt:
            continue
        v = _parse_floats(_RX_CONV_THR, txt[1])
        if v is not None:
            return v
    return None


def _detect_hubbard_u(work_dir: Path) -> Optional[dict[str, Any]]:
    """Lit DFT+U : renvoie ``{'enabled': bool, 'values': Dict[int, float]}`` ou None."""
    for fn in ("pw_scf_V0_for_phonon.in", "scf_eq.in", "scf.in"):
        txt = _read_first_existing(work_dir, (fn,))
        if not txt:
            continue
        enabled = False
        m_lu = _RX_LDA_PLUS_U.search(txt[1])
        if m_lu and m_lu.group("val").lower() == "true":
            enabled = True
        vals: dict[int, float] = {}
        for m in _RX_HUBBARD_U.finditer(txt[1]):
            try:
                vals[int(m.group("idx"))] = float(m.group("val").replace("D", "E").replace("d", "e"))
            except (ValueError, KeyError):
                continue
        return {"enabled": enabled, "values": vals}
    return None


def _detect_soc_and_magnetism(work_dir: Path) -> dict[str, Any]:
    """Renvoie ``{'soc': bool, 'nspin': Optional[int], 'lda_plus_u': bool}``."""
    out = {"soc": False, "nspin": None, "lda_plus_u": False}
    for fn in ("pw_scf_V0_for_phonon.in", "scf_eq.in", "scf.in"):
        txt = _read_first_existing(work_dir, (fn,))
        if not txt:
            continue
        m_soc = _RX_SOC.search(txt[1])
        if m_soc:
            out["soc"] = m_soc.group("val").lower() == "true"
        m_ns = _RX_NSPIN.search(txt[1])
        if m_ns:
            try:
                out["nspin"] = int(m_ns.group("val"))
            except ValueError:
                pass
        m_lu = _RX_LDA_PLUS_U.search(txt[1])
        if m_lu:
            out["lda_plus_u"] = m_lu.group("val").lower() == "true"
        return out
    return out


# ---------------------------------------------------------------------------
# Inspection sortie ``ph.out`` : convergence DFPT effective
# ---------------------------------------------------------------------------

# Le run précédent a montré un ``|ddv_scf|²`` final à ``7.6E-16``. On lit la
# dernière ligne ``|ddv_scf|^2 = ...`` pour voir si DFPT est effectivement
# descendu sous ``tr2_ph``.
_RX_DDV_SCF_LAST = re.compile(
    r"\|ddv_scf\|\^2\s*=\s*(?P<val>[\d.EeDd+\-]+)",
)


def _parse_last_ddv_scf(ph_out_text: Optional[str]) -> Optional[float]:
    """Renvoie la dernière valeur ``|ddv_scf|²`` du ph.out (convergence DFPT)."""
    if not ph_out_text:
        return None
    last: Optional[float] = None
    for m in _RX_DDV_SCF_LAST.finditer(ph_out_text):
        try:
            last = float(m.group("val").replace("D", "E").replace("d", "e"))
        except ValueError:
            continue
    return last


def _detect_dft_convergence(work_dir: Path, tr2_ph: Optional[float]) -> Optional[str]:
    """Renvoie un message d'analyse de la convergence DFPT (``None`` si indéterminée)."""
    ph_out = _read_text_bounded(work_dir / "ph.out", max_bytes=4 * 1024 * 1024)
    ddv = _parse_last_ddv_scf(ph_out)
    if ddv is None or tr2_ph is None:
        return None
    # Si |ddv_scf|² >> tr2_ph, DFPT n'a probablement pas convergé.
    if ddv > 1.2 * tr2_ph:
        return (
            f"DFPT n'a pas convergé : |ddv_scf|² final = {ddv:.2E} > tr2_ph = {tr2_ph:.2E}. "
            "Augmenter le nombre d'itérations ou durcir le seuil de mélange."
        )
    if ddv > 0.5 * tr2_ph:
        return (
            f"DFPT à la limite : |ddv_scf|² final = {ddv:.2E} ≈ 0.5 × tr2_ph = {tr2_ph:.2E}. "
            "Durcir légèrement tr2_ph pour stabiliser les branches acoustiques."
        )
    return (
        f"DFPT bien convergée : |ddv_scf|² final = {ddv:.2E} ≪ tr2_ph = {tr2_ph:.2E} — "
        "la cause des fréquences imaginaires n'est PAS la convergence DFPT."
    )


# ---------------------------------------------------------------------------
# Génération des recommandations par catégorie
# ---------------------------------------------------------------------------

_REC_VERSION = "1.0"  # Bumpé à chaque changement de schéma


def _rec_pseudopotential(
    family: Optional[str],
    species: list[str],
    xc: Optional[str],
) -> list[PhononImaginaryRecommendation]:
    """Suggestions pseudos : PAW → USPP / NC ; pslibrary vs GBRV ; SCAN / PBEsol ."""
    out: list[PhononImaginaryRecommendation] = []
    if family is None:
        return out
    if family == "PAW":
        out.append(PhononImaginaryRecommendation(
            level="info",
            category="pseudopotential",
            priority=3,
            title="Comparer PAW et USPP (ou Norm-Conserving)",
            body=(
                f"Vous utilisez un pseudo **PAW** pour {', '.join(species) or 'le système'}. "
                "Pour valider la stabilité dynamique, comparer avec un pseudos USPP ou "
                "Norm-Conserving (ONCV) sur le même XC. Les PAW sont plus rigides "
                "et peuvent masquer les modes mous."
            ),
            action="Tester un pseudo équivalente en USPP ou NC (Quantum ESPRESSO Upftools).",
            rationale=(
                "Les PAW figent l'onde partielle dans la zone d'augmentation et "
                "introduisent une erreur systématique sur ω(q) ≈ 1-3 cm⁻¹. USPP "
                "et NC sont en général plus mous → révèlent mieux les instabilités."
            ),
            source_keys=["scf.in:ATOMIC_SPECIES", "pw_scf_V0_for_phonon.in:ATOMIC_SPECIES"],
        ))
        if xc == "PBE":
            out.append(PhononImaginaryRecommendation(
                level="info",
                category="pseudopotential",
                priority=4,
                title="Comparer les PAW PSLibrary vs GBRV vs SSSP",
                body=(
                    "Il existe plusieurs familles PAW pour PBE : **PSLibrary** "
                    "(Dal Corso), **GBRV** (Garrity-Bennett-Rabe-Vanderbilt) "
                    "et **SSSP** (Lejaeghere et al., efficiency + vérifiés). "
                    "Les choix diffèrent légèrement sur le rayon d'augmentation "
                    "et les projecteurs — variations typiques de 2-5 cm⁻¹ sur "
                    "ω_min observées sur Si/Al/Cu."
                ),
                action="Télécharger un pseudo équivalent depuis libraries (PSLibrary / GBRV) et rejouer.",
                rationale="Cross-library check : révèle les artefacts confirmés par une seule famille.",
                source_keys=["pseudo_library_origin"],
            ))
    if family == "USPP":
        out.append(PhononImaginaryRecommendation(
            level="info",
            category="pseudopotential",
            priority=4,
            title="Tester un PAW équivalent",
            body=(
                "Vous utilisez un **USPP**. La comparaison PAW ↔ USPP est couramment "
                "utilisée pour étalonner les fréquences phononiques — souvent, USPP ↔ "
                "PAW diffèrent de quelques cm⁻¹ en bord de zone (ex. X pour Si)."
            ),
            action="Basculer sur le PAW équivalent (PSLibrary) et comparer ω_min.",
            rationale="Différence de schéma de projecteurs : PAW plus complets, USPP plus souples.",
            source_keys=["scf.in:ATOMIC_SPECIES"],
        ))
    return out


def _rec_xc(xc: Optional[str]) -> list[PhononImaginaryRecommendation]:
    """Suggestions sur le choix d'XC : PBE → LDA / PBEsol / SCAN."""
    out: list[PhononImaginaryRecommendation] = []
    if xc == "PBE":
        out.append(PhononImaginaryRecommendation(
            level="warning",
            category="xc",
            priority=2,
            title="Tester un autre XC (LDA / PBEsol / SCAN)",
            body=(
                "Vous utilisez **PBE**, qui surestime typiquement le volume d'équilibre de "
                "+1 à +3 % par rapport à l'expérience. Sur des branches acoustiques (TA(X) "
                "en particulier), ce ramollissement structural peut produire des ω < 0 — "
                "même pour des matériaux réels expérimentalement stables."
            ),
            action="Rejouer le même pipeline en LDA puis en PBEsol/SCAN et comparer ω_min.",
            rationale=(
                "LDA sous-estime les volumes (-1 à -2 %) → durcit les branches TA. "
                "PBEsol se rapproche des volumes expérimentaux. SCAN corrige une partie "
                "des erreurs systématiques du PBE."
            ),
            source_keys=["scf.in:input_dft", "pseudo_upf_filename:hints"],
        ))
    if xc == "LDA":
        out.append(PhononImaginaryRecommendation(
            level="info",
            category="xc",
            priority=5,
            title="Tester PBEsol ou SCAN",
            body=(
                "Vous utilisez **LDA**, qui sous-estime les volumes — peu susceptible "
                "de produire des modes imaginaires spurieux par ramollissement structural. "
                "Si ω < 0 en LDA, c'est probablement physique : tester PBEsol ou SCAN "
                "pour confirmer que la structure est bien à un minimum d'énergie."
            ),
            action="Comparer les fréquences LDA vs PBEsol vs SCAN.",
            rationale=(
                "SCAN/PBEsol sont les XC les plus précis pour les propriétés phononiques "
                "des solides (cf. Sun et al., PRL 2015 — SCAN reproduit ω dans 5% de l'expérience)."
            ),
            source_keys=["scf.in:input_dft"],
        ))
    if xc is None:
        out.append(PhononImaginaryRecommendation(
            level="warning",
            category="xc",
            priority=3,
            title="XC non détecté — vérifier explicitement",
            body=(
                "Le XC utilisé n'a pas pu être lu automatiquement dans scf.in / "
                "pw_scf_V0_for_phonon.in. Vérifier le namelist ``&SYSTEM input_dft`` "
                "et les pseudos SELECTED (les conventions de nommage diffèrent)."
            ),
            action="Ajouter « input_dft = 'PBE' » dans le bloc &SYSTEM (ou confirmer le XC).",
            rationale="Sans détection explicite, la traçabilité post-mortem est compromise.",
            source_keys=["scf.in:&SYSTEM", "scf.in:ATOMIC_SPECIES"],
        ))
    return out


def _rec_soc(pseudo_family: Optional[str], soc_flag: bool, nspin: Optional[int]) -> list[PhononImaginaryRecommendation]:
    """Suggestions spin-orbit + magnétique."""
    out: list[PhononImaginaryRecommendation] = []
    if nspin == 2 and not soc_flag:
        out.append(PhononImaginaryRecommendation(
            level="info",
            category="soc",
            priority=6,
            title="Activer le couplage spin-orbite (lspinorb=.true.)",
            body=(
                "Vous utilisez nspin=2 sans spin-orbit. Pour les matériaux magnétiques "
                "(Fe, Co, Ni, terres rares), SOC peut décaler significativement les "
                "fréquences en bord de zone — surtout pour les modes impliquant les "
                "orbitales d."
            ),
            action="Ajouter ``lspinorb = .true.`` et ``noncolin = .true.`` ; relancer SCF + phonon.",
            rationale=(
                "Pour les ferromagnétiques (Fe, Ni), SOC durcit typiquement les branches "
                "TA de 3-8 cm⁻¹ — peut éliminer des imag. spurious à -1 cm⁻¹."
            ),
            source_keys=["scf.in:nspin", "scf.in:lspinorb"],
        ))
    return out


def _rec_convergence(
    tr2_ph: Optional[float],
    conv_thr: Optional[float],
    ecutwfc: Optional[float],
    dft_message: Optional[str],
) -> list[PhononImaginaryRecommendation]:
    """Suggestions tr2_ph / conv_thr / ecutwfc + convergence DFPT effective."""
    out: list[PhononImaginaryRecommendation] = []
    if tr2_ph is not None and tr2_ph > TR2_PH_TIGHT:
        out.append(PhononImaginaryRecommendation(
            level="warning",
            category="convergence",
            priority=1,
            title="Durcir tr2_ph à 1.0d-15 (DFPT)",
            body=(
                f"``tr2_ph = {tr2_ph:.1E}`` — valeur standard de relax "
                "(1.0d-12 à 1.0d-14). Pour les fréquences phononiques très "
                "précises (fichetechnique), durcir à ``1.0d-15`` ou plus "
                "encore pour blanchir les modes acoustiques à Γ."
            ),
            action=f"Remplacer ``tr2_ph = {tr2_ph:.1E}`` par ``tr2_ph = 1.0d-15`` dans ph.in.",
            rationale=(
                "tr2_ph contrôle la convergence des fonctions d'onde à chaque q "
                "(Self-Consistent Field interne). Pour les modes acoustiques, "
                "le résidu DFPT domine le bruit numérique → durcir tr2_ph lisse "
                "les ω(q) en bord de zone."
            ),
            source_keys=["ph.in:tr2_ph", "ph_control:tr2_ph"],
        ))
    elif tr2_ph is not None and tr2_ph <= TR2_PH_VERY_TIGHT:
        # DFPT convergence très stricte → pas de levier DFPT.
        if dft_message and "DFPT n'a pas convergé" in dft_message:
            out.append(PhononImaginaryRecommendation(
                level="warning",
                category="convergence",
                priority=1,
                title="Augmenter mixing_beta (DFPT)",
                body=(
                    "Même à tr2_ph très serré, le résidu DFPT ne descend pas en-"
                    "dessous du seuil. Très probable cause : ``mixing_beta`` par défaut "
                    "(0.7) trop agressif pour ce matériau → oscillations."
                ),
                action="Essayer ``mixing_beta = 0.3`` ou ``mixing_beta = 0.4`` dans ph.in.",
                rationale=(
                    "Pour des structures à structure électronique complexe (d ou f), "
                    "le mixing par défaut peut entrer en oscillations. Réduire la "
                    "valeur stabilise les itérations DFPT."
                ),
                source_keys=["ph.in:mixing_beta"],
            ))
    if conv_thr is not None and conv_thr > CONV_THR_LOOSE:
        out.append(PhononImaginaryRecommendation(
            level="warning",
            category="convergence",
            priority=2,
            title="conv_thr trop lâche (SCF pw.x)",
            body=(
                f"``conv_thr = {conv_thr:.1E}`` — beaucoup trop lâche pour "
                "phonon DFPT. Les forces Hellmann-Feynman seront bruitées."
            ),
            action=f"Durcir à ``conv_thr = {CONV_THR_MEDIUM:.1E}`` (1.0d-10).",
            rationale=(
                "DFPT requiert une convergence SCF très stricte : chaque itération "
                "DFPT démarre à partir du SCF précédent ; un résidu SCF > 1e-9 Ry "
                "ramène du bruit dans les fréquences (cf. Gonze & Lee, PRB 1997)."
            ),
            source_keys=["scf.in:conv_thr", "pw_scf_V0_for_phonon.in:conv_thr"],
        ))
    elif conv_thr is not None and conv_thr > CONV_THR_MEDIUM:
        out.append(PhononImaginaryRecommendation(
            level="info",
            category="convergence",
            priority=2,
            title="conv_thr intermédiaire",
            body=(
                f"``conv_thr = {conv_thr:.1E}`` — acceptable mais peut être amélioré "
                "pour les branches acoustiques au point Γ."
            ),
            action=f"Durcir à ``conv_thr = 1.0d-10`` puis relancer.",
            rationale="Marges sur ω_min ≈ 0.5 cm⁻¹ cf. littérature standard.",
            source_keys=["scf.in:conv_thr"],
        ))
    if ecutwfc is not None and ecutwfc < ECUTWFC_MEDIUM:
        out.append(PhononImaginaryRecommendation(
            level="warning",
            category="convergence",
            priority=1,
            title="ecutwfc trop bas (bruit sur ω)",
            body=(
                f"``ecutwfc = {ecutwfc} Ry`` — insuffisant pour phonon DFT. "
                "Coupe plane-wave trop basse → erreurs systématiques sur ω(q) "
                "en bord de zone ; les PAW masquent mieux ce défaut que les USPP/NC."
            ),
            action=f"Augmenter ``ecutwfc = {ECUTWFC_TIGHT}`` (80 Ry) ou plus.",
            rationale=(
                "Pour les forces DFPT, l'erreur de coupure plane-wave sur les ω(q) est "
                "≈ ΔE_cut / N_q — souvent 0.5-2 cm⁻¹ à 60 Ry, 0.2-0.5 cm⁻¹ à 80 Ry."
            ),
            source_keys=["scf.in:ecutwfc", "pw_scf_V0_for_phonon.in:ecutwfc"],
        ))
    if dft_message is not None:
        out.append(PhononImaginaryRecommendation(
            level="info" if "≪" in dft_message else "warning",
            category="convergence",
            priority=0 if "DFPT n'a pas convergé" in dft_message else 8,
            title="État de la convergence DFPT (depuis ph.out)",
            body=dft_message,
            action="Inspecter ``ph.out`` ligne « |ddv_scf|² … » pour chaque représentation.",
            rationale=(
                "Si DFPT est bien convergée (|ddv_scf|² ≪ tr2_ph), le problème ne "
                "vient PAS de DFPT — chercher convergence SCF ou physique (XC, pseudos)."
            ),
            source_keys=["ph.out:|ddv_scf|^2"],
        ))
    return out


def _rec_q_grid(
    nq: Optional[tuple[int, int, int]],
    pseudo_family: Optional[str],
) -> list[PhononImaginaryRecommendation]:
    """Suggestions sur la densité q-grid."""
    out: list[PhononImaginaryRecommendation] = []
    if nq is None:
        return out
    nq_min = min(nq)
    if nq_min < NQ_MIN:
        out.append(PhononImaginaryRecommendation(
            level="error",
            category="q_grid",
            priority=1,
            title=f"q-grid trop grossier ({nq[0]}×{nq[1]}×{nq[2]})",
            body=(
                f"q-grid = ``{nq[0]}×{nq[1]}×{nq[2]}`` — strictement insuffisant "
                "pour phonon DFPT. Les fichiers ``fc.out`` puis ``phonon.freq`` "
                "présentent des **pics parasites en bord de zone** (artefacts "
                "d'interpolation Fourier) qui peuvent être lus comme modes mous."
            ),
            action=f"Régénérer ``ph.in`` avec ``nq1 = nq2 = nq3 = {NQ_RECOMMENDED}`` puis relancer la chaîne ph.x → q2r.x → matdyn.x.",
            rationale=(
                "La densité d'interpolation de Fourier est inversement "
                "proportionnelle au pas q. Avec 2×2×2, chaque q OFR est trop "
                "isolé → oscillations parasites en Γ-X et Γ-L."
            ),
            source_keys=["ph.in:nq1", "ph.in:nq2", "ph.in:nq3"],
        ))
    elif nq_min < NQ_RECOMMENDED:
        out.append(PhononImaginaryRecommendation(
            level="warning",
            category="q_grid",
            priority=3,
            title=f"q-grid à augmenter ({nq[0]}×{nq[1]}×{nq[2]})",
            body=(
                f"q-grid = ``{nq[0]}×{nq[1]}×{nq[2]}`` — minimum fonctionnel mais "
                "des artéfacts sub-cm⁻¹ restent possibles en bord de zone, "
                "surtout pour les modes TA(X) mous."
            ),
            action=f"Augmenter à ``{NQ_RECOMMENDED}×{NQ_RECOMMENDED}×{NQ_RECOMMENDED}`` pour blanchir.",
            rationale=(
                "À 4×4×4, les modes acoustiques sont correctement décrits en Γ mais "
                "TA(X)/TA(L) peuvent rester à -0.5 cm⁻¹ (artefact pur Fourier). "
                "6×6×6 fait passer ce résidu à < -0.1 cm⁻¹ pour la plupart des systèmes."
            ),
            source_keys=["ph.in:nq1", "ph.in:nq2", "ph.in:nq3"],
        ))
    return out


def _rec_asr(asr: Optional[str]) -> list[PhononImaginaryRecommendation]:
    """Suggestions acoustic sum rule (zasr dans q2r.in)."""
    out: list[PhononImaginaryRecommendation] = []
    if asr is None:
        return out
    if asr == "simple":
        out.append(PhononImaginaryRecommendation(
            level="info",
            category="asr",
            priority=5,
            title="Tester ``zasr='crystal'`` (ASR plus strict)",
            body=(
                "Vous utilisez ``zasr='simple'`` dans q2r.in — impose l'ASR sur "
                "les modes acoustiques au point Γ **seulement** (3 conditions). "
                "``zasr='crystal'`` impose l'ASR sur **tous les q-points** "
                "(9 conditions), ce qui blanchit les pics sub-cm⁻¹ résiduels en "
                "bord de zone."
            ),
            action="Remplacer ``zasr='simple'`` par ``zasr='crystal'`` dans q2r.in ; relancer q2r.x et matdyn.x.",
            rationale=(
                "Pour les structures non-piézoélectriques simples, 'crystal' "
                "donne presque toujours des ω en bord de zone plus propres "
                "(écart type < 0.1 cm⁻¹ vs 0.5 cm⁻¹ pour 'simple')."
            ),
            source_keys=["q2r.in:zasr"],
        ))
    return out


def _rec_geometry(
    results: dict[str, Any],
    work_dir: Path,
) -> list[PhononImaginaryRecommendation]:
    """Vérifications structurales : relaxation ionique / volume / vacuum 2D."""
    out: list[PhononImaginaryRecommendation] = []
    v0 = results.get("eos", {}).get("V0_bohr3") if isinstance(results.get("eos"), dict) else None
    # Si V₀ EOS est connu et le matériau standard (e.g. maille cubique simple),
    # on NE peut pas dire grand-chose sans comparaison expérimentale — on
    # note que la relaxation ionique peut aider.
    out.append(PhononImaginaryRecommendation(
        level="info",
        category="geometry",
        priority=7,
        title="Re-relaxation ionique (positions internes)",
        body=(
            "Si vous n'avez pas lancé une **relaxation des positions atomiques** "
            "(do-it uniquement via ``calculation='vc-relax'`` ou ``'relax'``), "
            "il est possible que les atomes internes ne soient pas au minimum. "
            "Ceci se manifeste par des modes imaginaires en Γ pour des "
            "structures type pérovskite ou quasi-2D."
        ),
        action="Lancer ``calculation='vc-relax'`` (cellule + ions) avant la chaîne phonon.",
        rationale=(
            "Un atome interne hors équilibre peut mener à des forces résiduelles "
            "non nulles au point SCF → ω(q) < 0 en Γ par couplage des modes internes."
        ),
        source_keys=["scf.in:calculation", "pw_scf_V0_for_phonon.in:calculation"],
    ))
    if v0 is not None and v0 > 350.0:
        # heuristic large volume → possible slab / molecule ; fleurte moins.
        out.append(PhononImaginaryRecommendation(
            level="info",
            category="geometry",
            priority=8,
            title="Vérifier le vide (système 2D / slab)",
            body=(
                f"V₀ = {v0:.1f} bohr³ est élevé. Si votre matériau est une **slab** "
                "ou **2D**, assurez-vous que le vide selon z est ≥ 15 Å pour éviter "
                "des modes mous spurieux par interaction entre les répliques."
            ),
            action="Ajouter ~10 Å de vide selon z si slab.",
            rationale="Sans vide suffisant, les modes z-directionnels sont pollués par les répliques.",
            source_keys=["scf.in:CELL_PARAMETERS", "pw_scf_V0_for_phonon.in:CELL_PARAMETERS"],
        ))
    return out


def _rec_cross_validation(
    results: dict[str, Any],
    minf: Optional[float],
    xc: Optional[str],
) -> list[PhononImaginaryRecommendation]:
    """Suggestions cross-validation : phonopy FD, comparaison expérimentale/MP."""
    out: list[PhononImaginaryRecommendation] = []
    if minf is None or minf >= -1.0:
        # imag spurious < 1 cm⁻¹ → cross-check phonopy peu coûteux.
        out.append(PhononImaginaryRecommendation(
            level="info",
            category="cross_validation",
            priority=6,
            title="Cross-validation : phonopy (Finite-Displacement)",
            body=(
                f"Pour ω_min = {minf or 0} cm⁻¹, la cause est probablement parasite "
                "(Fourier + DFPT). Lancer **phonopy** en Finite-Displacement "
                "(méthode totalement indépendante) avec un supercell ≥ 2×2×2 "
                "permettra de discriminer une **vraie instabilité** d'un artefact."
            ),
            action="Générer un supercell phonopy et comparer ω(q) en Γ et X.",
            rationale=(
                "DFPT (= réponse linéaire) et FD (= différences finies) reposent "
                "sur des hypothèses algorithmiques distinctes. Quand les deux "
                "concordent, l'instabilité est physique. Sinon c'est un artefact "
                "numérique (DFPT souvent plus bruité en bord de zone)."
            ),
            source_keys=["phonopy_supercell.yaml"],
        ))
    else:
        # imag sévère → peut être physique.
        out.append(PhononImaginaryRecommendation(
            level="warning",
            category="cross_validation",
            priority=5,
            title="Vérifier vis-à-vis de la littérature / MP",
            body=(
                f"ω_min = {minf:.2f} cm⁻¹ — magnitude qui suggère une **vraie** "
                "instabilité ou un défaut de PBE. Consultez Materials Project "
                "(phonon band structure), PhononDB, ou les données expérimentales "
                "(diffusion inélastique des neutrons)."
            ),
            action="Chercher '{matériau} phonon' sur Materials Project, PhononDB, ou arXiv.",
            rationale=(
                "Pour les perovskites (SrTiO3, PbTiO3, …) et les matériaux à "
                "ferroélectricité proche, des instabilités sont attendues (modes "
                "mous γ₃₅ en Γ). Mais pour les mailles FCC/BCC simples (Si, Al, Cu …), "
                "toute ω négatif est suspect."
            ),
            source_keys=["materialsproject", "phonondb"],
        ))
    if xc == "PBE":
        out.append(PhononImaginaryRecommendation(
            level="info",
            category="cross_validation",
            priority=7,
            title="Comparer aux données expérimentales",
            body=(
                "PBE est connu pour sous-estimer les fréquences phononiques de "
                "**5-10 %** vs expérience, principalement sur les branches "
                "optiques (cf. Heid et al., PRB 2000). Si votre ω_min est "
                "proche de zéro, l'expérience peut très bien montrer une "
                "branche légèrement positive (artefact PBE)."
            ),
            action="Comparer avec les données Raman ou neutrons publiées.",
            rationale="PBE introduit une erreur systématique connue et documentée.",
            source_keys=["scf.in:input_dft"],
        ))
    return out


def _rec_hubbard_u(hubbard: Optional[dict[str, Any]]) -> list[PhononImaginaryRecommendation]:
    """Si DFT+U est utilisé, vérifier que U est raisonnable."""
    out: list[PhononImaginaryRecommendation] = []
    if not hubbard or not hubbard.get("enabled"):
        return out
    vals = hubbard.get("values") or {}
    if any(v > 8.0 for v in vals.values()):
        out.append(PhononImaginaryRecommendation(
            level="warning",
            category="pseudopotential",
            priority=4,
            title="Hubbard U élevé (> 8 eV)",
            body=(
                f"Vous avez seté ``Hubbard_U`` à une ou plusieurs valeurs > 8 eV "
                f"({vals}). Cette magnitude peut introduire des contraintes "
                "artificielles sur la structure électronique → modes acoustiques mous."
            ),
            action="Tester une valeur U plus faible (3-6 eV) ou utiliser le calcul linéaire-response (HP).",
            rationale=(
                "Les valeurs U > 8 eV sont souvent signe de sur-correction. "
                "La méthode de Cococcioni (linear response) calcule U from first "
                "principles sans sur-correction."
            ),
            source_keys=["scf.in:Hubbard_U"],
        ))
    return out


# ---------------------------------------------------------------------------
# API publique
# ---------------------------------------------------------------------------

def build_phonon_imaginary_recommendations(
    work_dir: Optional[Path],
    results: dict[str, Any],
) -> dict[str, Any]:
    """Analyse ``work_dir`` + ``results`` et renvoie les recommandations si
    ``properties.n_imaginary_modes > 0``, sinon un résumé factuel sans items.

    Args:
        work_dir : répertoire du run (peut être ``None`` pour tests).
        results  : ``marker[\"results\"]`` du pipeline_api_job_state.json.

    Returns:
        Dict sérialisable JSON-compatible :
          * ``has_imaginary``         : bool
          * ``n_imaginary_modes``     : int
          * ``omega_min_cm-1``        : float (ou 0.0 si pas de mesure)
          * ``categories``            : list[str] (catégories présentes)
          * ``items``                 : list[dict] (recommandations triées par priorité)
          * ``provenance``            : dict (versions, fichiers lus)
          * ``rec_version``           : str (version du schéma de recommandation)
    """
    n_imag = 0
    try:
        n_imag = int((results.get("properties") or {}).get("n_imaginary_modes") or 0)
    except (TypeError, ValueError):
        n_imag = 0
    try:
        minf = float((results.get("properties") or {}).get("min_freq_cm-1") or 0.0)
    except (TypeError, ValueError):
        minf = 0.0
    has_imag = (n_imag > 0)

    wd = Path(work_dir) if work_dir else None
    provenance: dict[str, Any] = {
        "rec_version": _REC_VERSION,
        "scanned_files": [],
        "scan_errors": [],
    }

    if not has_imag or wd is None:
        # Pas d'imaginaire ou pas de work_dir → résumé factuel, pas d'items.
        return {
            "has_imaginary": bool(has_imag),
            "n_imaginary_modes": int(n_imag),
            "omega_min_cm-1": float(minf),
            "categories": [],
            "items": [],
            "provenance": provenance,
            "rec_version": _REC_VERSION,
        }

    # Inspection des artefacts (silencieuse en cas d'erreur I/O).
    pw_text = None
    pw_file_used = None
    try:
        first = _read_first_existing(wd, ("pw_scf_V0_for_phonon.in", "scf_eq.in", "scf.in"))
        if first is not None:
            pw_file_used, pw_text = first
            provenance["scanned_files"].append(pw_file_used)
    except OSError as ex:
        provenance["scan_errors"].append(f"pw input read: {ex!r}")
    try:
        ph_first = _read_first_existing(wd, ("ph.in", "ph_control"))
        if ph_first is not None:
            provenance["scanned_files"].append(ph_first[0])
    except OSError as ex:
        provenance["scan_errors"].append(f"ph input read: {ex!r}")
    try:
        q2r_first = _read_first_existing(wd, ("q2r.in",))
        if q2r_first is not None:
            provenance["scanned_files"].append(q2r_first[0])
    except OSError as ex:
        provenance["scan_errors"].append(f"q2r.in read: {ex!r}")

    xc = _detect_xc(pw_text)
    family, species = _detect_pseudo_family(pw_text)
    nq = _detect_nq(wd)
    tr2_ph = _detect_tr2_ph(wd)
    conv_thr = _detect_conv_thr(wd)
    ecutwfc = _detect_ecutwfc(wd)
    asr = _detect_asr(wd)
    soc_info = _detect_soc_and_magnetism(wd)
    hubbard = _detect_hubbard_u(wd)
    dft_msg = _detect_dft_convergence(wd, tr2_ph)

    items: list[PhononImaginaryRecommendation] = []
    items.extend(_rec_pseudopotential(family, species, xc))
    items.extend(_rec_xc(xc))
    items.extend(_rec_soc(family, soc_info["soc"], soc_info["nspin"]))
    items.extend(_rec_convergence(tr2_ph, conv_thr, ecutwfc, dft_msg))
    items.extend(_rec_q_grid(nq, family))
    items.extend(_rec_asr(asr))
    items.extend(_rec_geometry(results, wd))
    items.extend(_rec_hubbard_u(hubbard))
    items.extend(_rec_cross_validation(results, minf, xc))

    items.sort(key=lambda r: (r.priority, r.category, r.title))
    categories = sorted({r.category for r in items})
    return {
        "has_imaginary": bool(has_imag),
        "n_imaginary_modes": int(n_imag),
        "omega_min_cm-1": float(minf),
        "categories": categories,
        "items": [r.to_dict() for r in items],
        "provenance": provenance,
        "rec_version": _REC_VERSION,
        "context": {
            "xc": xc,
            "pseudo_family": family,
            "species": species,
            "nq": nq,
            "tr2_ph": tr2_ph,
            "conv_thr": conv_thr,
            "ecutwfc": ecutwfc,
            "asr": asr,
            "soc": soc_info["soc"],
            "nspin": soc_info["nspin"],
            "lda_plus_u": soc_info["lda_plus_u"],
            "hubbard_u_values": (hubbard or {}).get("values"),
        },
    }


def find_phonon_imaginary_recommendations(
    work_dir: Optional[Path],
    results: dict[str, Any],
) -> list[dict[str, Any]]:
    """Backend-compatible alias : renvoie uniquement la liste ``items``."""
    return build_phonon_imaginary_recommendations(work_dir, results)["items"]


__all__ = [
    "PhononImaginaryRecommendation",
    "build_phonon_imaginary_recommendations",
    "find_phonon_imaginary_recommendations",
]

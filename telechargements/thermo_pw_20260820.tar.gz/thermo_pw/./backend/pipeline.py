from __future__ import annotations
"""
Orchestrateur unifié thermo_pw — système « 5 profils ».

Principe : un `profil_id` = une valeur `what=` thermo_pw + une série de calculs MPI
pré-configurée (SCF → ph → q2r → matdyn → thermo_pw → gnuplot selon le profil).

Chaque profil génère :
1. `thermo_control` (avec la bonne valeur de `what=`).
2. La série de jobs MPI nécessaire (en réutilisant les routines MPI existantes).
3. L'aperçu dynamique (sortie en cours depuis les `.out` pour éviter de saturer l'API).

Les 5 profils (canoniques juin 2026, alias legacy gérés dans ``phonon_chain_qe``) :
- P1 `Mécanique 0 K`       → what=`scf_elastic_constants` (SCF V₀ + C_ij @ 0 K)
- P2 `Thermique QHA`       → what=`thermo`                (EOS + phonons + QHA, ΔT=50 K)
- P3 `Étude complète`      → what=`elastic_constants_geo` (= P2 + C_ij(V₀,T))
- P4 `Durée de vie phonons`→ what=`ph_life`               (= P3 + τ_λ(ω), conv_thr strict)
- P5 `Propriétés diélectriques` → what=`dielectric`      (phonons + ε∞ via thermo_pw ;
  chaîne optique ε(ω) epsilon.x + turbo_* opt-in via l'UI ; extra_whats thermo_pw optionnels)

Préservation impérative :
- **Annulation MPI** : `cancel_event` propagé à `run_thermo_pw_mpi` (groupe MPI killed proprement).
- **Tail-streaming** : on lit les `.out` en UTF-8 (limite 16 Ko) pour la diffusion sans saturer l'API.
- **workflow_state.json** : écrit à chaque étape (reprise après coupure ou redémarrage du serveur).
"""
from _eos_flatten import flatten_eos_summary_into_results  # Juillet 2026 (fix P2 NameError). Le module EST défini dans backend/_eos_flatten.py — l'ancien commentaire « module absent (jamais git-add) » était factuellemment faux. Le helper est appelé par PipelineJob._intermediate_parse (étape « eos_summary.json ») et fait l'unnest results["eos_summary"]["eos"] + propagation B0_GPa_approx vers results["eos"]["B0_GPa"] (cf. docstring du helper). Sans cet import, P2/P3/P4 levait NameError juste après l'EOS réussi (« EOS terminé : V₀ ≈ … » puis crash).

import json
import os
import re
import shutil
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

# Imports locaux (relatifs à backend/)
import config as cfg
from state_db import WorkflowDB, TaskState, TaskStatus
from eos_paths import WORKFLOW_STATE_FILENAME
from material_inputs import resolve_template, find_thermo_inputs_only
from input_editor import reinforce_params
from eos_gnuplot import run_gnuplot_eos, run_gnuplot_elastic_temperature_dat
from phonon_gnuplot import run_gnuplot_phonon_bands, run_gnuplot_phonon_dos
from work_optimize_eos import EosConfig, task_optimize
from phonon_chain_qe import (
    run_q2r,
    run_matdyn_bands,
    run_matdyn_dos,
    run_thermo_pw_mpi,
    parse_ph_fildyn,
)
from qe_subprocess import (
    which_mpirun,
    API_CANCEL_RUNTIME_MSG,
    run_qe,
    run_qe_stdin,
    run_pw_x_in,
    run_ph_x_in,
    terminate_registered_processes,
)
from ph_input_from_pw import nq_from_request_body, try_autogenerate_ph_in
import resume_diagnosis
import thermo_pw_resume
from machine_profile import detect_machine
from storage_estimate import (
    derive_cell_facts,
    estimate_storage,
    measure_dir_size,
    read_exact_cell_facts,
)
from runtime_estimate import (
    estimate_runtime,
    humanize_seconds,
    live_eta,
    parse_material_descriptors,
    record_step_measurement,
)
from electronic_props import inject_lcalc_quantities, run_bands_chain_only, run_electronic_properties
from optical_props import run_optical_properties
from parsers.thermo_pw_out_parse import (
    parse_thermo_pw_log,
    merge_elastic_from_output_el_cons_files,
    parse_thermo_pw_p5_extra_log,
)
from thermo_what_catalog import (
    WHAT_CATALOG,
    default_extra_whats_for_p5,
    expand_extra_whats,
    get_catalog_entry,
    validation_warnings,
)

import api_job_persist

# ----------------------------------------------------------------------------
# Blueprint Flask pour les routes /api/pipeline/* (juillet 2026 — fix).
#
# Sans cette déclaration ``bp = Blueprint(...)`` et la fonction
# ``register_pipeline_blueprint(app)`` exposées au niveau module, l'import
# dans ``backend/api_server.py`` (``from pipeline import PROFILES,
# register_pipeline_blueprint``) tombe dans le ``except`` :
#   * ``PIPELINE_AVAILABLE = False`` → TOUTES les routes du pipeline
#     (``/api/pipeline/profiles``, ``/api/pipeline/run``, …) renvoient 404.
#   * Côté UI ``app_v2.js`` (init) : ``listProfiles()`` lève, ce qui casse
#     l'affichage des 5 tuiles de profil P1..P5 (front « cassure » signalée).
# Cette régression datait d'une édition où le bloc d'enregistrement du
# blueprint avait été supprimé. Rétabli ici avec un commentaire de garde.
# ----------------------------------------------------------------------------
# Blueprint + helpers Flask importés ICI (et non en tête) car la déclaration
# ``bp = Blueprint(...)`` ET les décorateurs ``@bp.route(...)`` doivent
# apparaître au NIVEAU MODULE — pas à l'intérieur d'une classe — sinon
# Flask Blueprint ne les enregistre PAS comme routes. Les imports eux-mêmes
# peuvent rester en tête, mais on les place ici pour matérialiser visuellement
# la frontière « niveau module » et éviter que de futures éditions ne
# ré-insèrent ``bp`` ou les routes dans la classe PipelineJob.
from flask import Blueprint, current_app, jsonify, request  # noqa: E402,F401

bp = Blueprint("pipeline", __name__)


# ----------------------------------------------------------------------------
# Route /api/pipeline/profiles — juillet 2026 (fix cassure UI)
# ----------------------------------------------------------------------------
# L'UI ``app_v2.js`` (init) appelle ``GET /api/pipeline/profiles`` pour
# peupler les 5 tuiles P1..P5. Cette route n'était PAS définie dans le code
# (les autres routes ``/api/pipeline/runs/*`` et ``/api/pipeline/jobs/*``
# l'étaient) — d'où le 404 et la bande de profils vide côté front.
# On l'ajoute au niveau module (hors classe PipelineJob) juste après la
# définition du Blueprint ``bp``, conformément à l'idiome Flask.


@bp.route("/api/pipeline/profiles", methods=["GET"])
def list_pipeline_profiles():
    """Renvoie la liste des 5 profils P1..P5 avec leurs métadonnées UI.

    Réponse : ``{"profiles": [...], "count": N}`` où chaque entrée expose
    les champs consommés par ``app_v2.js`` : id, name, emoji, what_qe,
    what_qe_display, description, storage_hint, inputs, outputs, steps,
    prerequisites, params_summary, needs_eos/phonons/optical, expected_results,
    default_extra_whats (P5).
    """
    # Estimation de durée par profil (août 2026). Optionnelle et tolérante :
    # sans ``material_id`` exploitable on retombe sur les descripteurs par
    # défaut, et toute erreur laisse simplement ``runtime_estimate`` à None
    # plutôt que de casser l'affichage des tuiles.
    material_id = (request.args.get("material_id") or "").strip()
    scf_in_basename = (request.args.get("scf_in_basename") or "").strip()
    machine = detect_machine()
    try:
        nproc = int(request.args.get("nproc") or machine.recommended_nproc())
    except (TypeError, ValueError):
        nproc = machine.recommended_nproc()
    nproc = max(1, nproc)
    pw_path = (
        _resolve_scf_template_for_estimate(material_id, scf_in_basename)
        if material_id
        else None
    )
    descriptors = parse_material_descriptors(
        pw_path=pw_path, material_id=material_id if pw_path else ""
    )
    cell_facts = _cell_facts_for(pw_path, descriptors)

    # Itération sur PROFILES (Python 3.7+ préserve l'ordre d'insertion) — 
    # ainsi l'ajout futur d'un P6, P7, etc. sera automatiquement servi sans
    # modification de cette route.
    profiles_out = []
    for pid, prof in PROFILES.items():
        if not isinstance(prof, dict):
            continue
        try:
            est = estimate_runtime(
                profile_id=prof.get("id", pid),
                profile=prof,
                descriptors=descriptors,
                machine=machine,
                nproc=nproc,
            ).to_dict()
        except Exception:  # noqa: BLE001
            est = None
        try:
            sto = estimate_storage(
                profile_id=prof.get("id", pid),
                profile=prof,
                descriptors=descriptors,
                cell_facts=cell_facts,
                disk_path=cfg.WORK_ROOT,
            ).to_dict()
        except Exception:  # noqa: BLE001
            sto = None
        profiles_out.append({
            "runtime_estimate": est,
            "storage_estimate": sto,
            "id": prof.get("id", pid),
            "name": prof.get("name", pid),
            "emoji": prof.get("emoji", ""),
            "what_qe": prof.get("what_qe", ""),
            "what_qe_display": prof.get("what_qe_display", prof.get("what_qe", "")),
            "description": prof.get("description", ""),
            "storage_hint": prof.get("storage_hint", ""),
            "inputs": list(prof.get("inputs") or []),
            "outputs": list(prof.get("outputs") or []),
            "steps": list(prof.get("steps") or []),
            "prerequisites": list(prof.get("prerequisites") or []),
            "params_summary": list(prof.get("params_summary") or []),
            "needs_eos": bool(prof.get("needs_eos")),
            "needs_phonons": bool(prof.get("needs_phonons")),
            "needs_optical": bool(prof.get("needs_optical")),
            "needs_optical_overridable": bool(prof.get("needs_optical_overridable")),
            "expected_results": prof.get("expected_results", {}) or {},
            "default_extra_whats": list(prof.get("default_extra_whats") or []),
            "allowed_extra_whats": list(prof.get("allowed_extra_whats") or []),
        })
    return jsonify({
        "profiles": profiles_out,
        "count": len(profiles_out),
        "machine": {
            **machine.to_dict(),
            "recommended_nproc": machine.recommended_nproc(),
        },
        "estimate_nproc": nproc,
        "estimate_descriptors": descriptors.to_dict(),
    })


def register_pipeline_blueprint(app):
    """Enregistre le blueprint pipeline sur l'application Flask principale.

    Appelée depuis ``backend/api_server.py`` au démarrage du serveur API
    (cf. bloc ``try: from pipeline import PROFILES, register_pipeline_blueprint``).
    Toutes les routes déclarées par ``@bp.route(...)`` dans ce module sont
    alors attachées à ``app`` (préfixe implicite ``/``).

    No-op défensif si ``app`` est None (cas d'import dans un test sans
    application Flask réelle).

    ATTENTION (juillet 2026 — fix cassure UI profils) : CETTE fonction
    DOIT contenir l'appel effectif ``app.register_blueprint(bp)``.
    Sans cette ligne, la fonction retourne sans erreur (donc
    ``PIPELINE_AVAILABLE=True`` dans ``api_server.py``), mais AUCUNE
    route du blueprint n'est enregistrée → 404 silencieux sur toutes
    les routes ``/api/pipeline/*``, y compris ``/api/pipeline/profiles``
    consommée par l'UI ``app_v2.js`` au boot (bande de profils P1..P5
    reste vide côté front).
    """
    if app is None:
        return
    # LIGNE CRITIQUE : c'est CET appel qui rattache effectivement les
    # routes @bp.route (notamment ``/api/pipeline/profiles``) à l'app
    # Flask principale. Ne JAMAIS la retirer sans tests bout-en-bout UI.
    app.register_blueprint(bp)


# ----------------------------------------------------------------------------
# Handler GET /api/pipeline/jobs/<job_id> — juillet 2026 (fix journal UI).
# ----------------------------------------------------------------------------
# L'UI ``app_v2.js`` (startPolling) appelle ``GET /api/pipeline/jobs/<id>``
# toutes les 1,5 s pour rafraîchir le journal (``j.logs``, ``j.status``,
# ``j.message``, ``j.steps``) via ``renderJobTick(j)``. Sans cette route,
# Flask renvoie 404 → ``jsonFetch`` lève → ``pollTimer`` retombe en
# ``[ERR] polling : not found`` silencieux et le journal reste vide.

@bp.route("/api/pipeline/jobs/<job_id>", methods=["GET"])
def get_job(job_id: str):
    with PipelineJob._REGISTRY_LOCK:
        job = PipelineJob._REGISTRY.get(job_id)
    if not job:
        return jsonify({"error": "job_id inconnu"}), 404
    return jsonify(job.to_dict())


# ----------------------------------------------------------------------------
# Handler POST /api/pipeline/run — juillet 2026 (fix cassure UI profils).
# ----------------------------------------------------------------------------
# Restauré depuis backend/pipeline.py.preserved:2755 (la version « préserved »
# était indenté à 4 espaces, ce qui nichait silencieusement le décorateur
# @bp.route dans une portée parente ; Flask Blueprint n'enregistre alors
# AUCUNE route à ce niveau → 404 systématique sur POST /api/pipeline/run,
# ce qui paralysait les 5 tuiles P1..P5 côté UI « Lancer la série »).
#
# Solution appliquée ici :
#   * dédenter le bloc complet (col 0) avant insertion pour respecter
#     l'idiome Blueprint (cf. commentaire de garde lignes ~89-113 plus haut) ;
#   * insérer juste après `register_pipeline_blueprint` (même groupe
#     fonctionnel : routes du blueprint) ;
#   * transmettre explicitement à ``PipelineJob`` le kwargs ``p1_full_preset``
#     pour respecter le contrat juillet 2026 (preset P1 « Cᵢⱼ + DOS + Bandes »).
#
# Notes pour itérations futures :
#   * ``needs_optical`` et ``lo_to_opt_in`` (kwags de ``PipelineJob.__init__``
#     ajoutés post-preserved) ne sont volontairement PAS câblés ici — le
#     contrat UI (``interface/api_v2.js:111``) ne les envoie pas encore
#     côté front ; quand l'UI les activera, étendre ce handler.
#   * ``from thermo_what_catalog import ...`` est LAZY (à l'intérieur du
#     ``if profile_id == "P5"``) pour éviter les cycles d'import au boot.
# ----------------------------------------------------------------------------
@bp.route("/api/pipeline/run", methods=["POST"])
def run_pipeline():
    data = request.get_json(silent=True) or {}
    material_id = (data.get("material_id") or "").strip()
    profile_id = (data.get("profile_id") or "P2").strip().upper()
    scf_in_basename = (data.get("scf_in_basename") or "").strip()
    nproc = int(data.get("nproc", cfg.MPI_NPROC))
    user_work_dir = (data.get("work_dir") or "").strip() or None
    # Overrides ichamp (Round 2 demande review) : permettent à l'UI 4
    # profils de désactiver l'étape propriétés ou passer en ichamp=2
    # (DOS seule) sans toucher au dict PROFILES.
    properties_enabled_raw = data.get("properties_enabled")
    properties_ichamp_raw = data.get("properties_ichamp")
    properties_enabled = None
    if properties_enabled_raw is not None:
        if isinstance(properties_enabled_raw, bool):
            properties_enabled = properties_enabled_raw
        elif isinstance(properties_enabled_raw, (int, float)):
            properties_enabled = bool(properties_enabled_raw)
        elif isinstance(properties_enabled_raw, str):
            properties_enabled = properties_enabled_raw.strip().lower() in (
                "1", "true", "yes", "on"
            )
    properties_ichamp = None
    if properties_ichamp_raw is not None:
        try:
            iv = int(properties_ichamp_raw)
            if iv in (2, 3):
                properties_ichamp = iv
        except (TypeError, ValueError):
            properties_ichamp = None
    # =====================================================================
    # ``extra_whats`` (juin 2026 — P5 extension)
    # =========================================================================
    # * ``None`` → laisse la valeur par défaut du profil s'appliquer
    #   (``profile['default_extra_whats']``).
    # * list ou CSV string (``"plot_bz,piezoelectric_tensor"``).
    # * Validation via ``expand_extra_whats`` (filtre le bruit, dédoublonne).
    # * Effet uniquement si ``profile_id == "P5"`` (autres profils : ignoré).
    # =========================================================================
    if profile_id == "P5":
        from thermo_what_catalog import (
            expand_extra_whats as _expand_xwhats,
            validation_warnings as _xwhats_warnings,
        )
        extra_raw = data.get("extra_whats")
        if extra_raw is None or extra_raw == "" or extra_raw == []:
            extra_whats = None  # laisse la valeur par défaut du profil.
        else:
            extra_whats = _expand_xwhats(extra_raw)
            # Avertissements pédagogiques (n'interrompent pas le run).
            try:
                warnings = _xwhats_warnings(
                    extra_whats,
                    scf_has_spin_polarized=bool(
                        data.get("scf_has_nspin2") or False
                    ),
                    band_gap_eV=(
                        float(data["background_gap_eV"])
                        if data.get("background_gap_eV") is not None
                        else None
                    ),
                    spacegroup_is_centrosymmetric=data.get(
                        "spacegroup_is_centrosymmetric"
                    ),
                )
                if warnings:
                    print(
                        "[api_server.run_pipeline] P5 extras warnings : "
                        f"{warnings}"
                    )
            except Exception as ex:  # noqa: BLE001
                print(f"[api_server.run_pipeline] validation_warnings : {ex}")
    else:
        # P1-P4 : extra_whats n'a pas d'effet (la directive ``what=`` est
        # fixée par le profil et les éventuelles sous-étapes QHA écrivent
        # leur sortie dans ``thermo_pw_run.out``). On force ``None`` pour
        # indiquer à PipelineJob d'ignorer la liste.
        extra_whats = None
    if not material_id:
        return jsonify({"error": "material_id requis"}), 400
    try:
        prof = get_profile(profile_id)
    except KeyError as ex:
        return jsonify({"error": str(ex)}), 400
    if not scf_in_basename:
        # prend le premier .in du bucket <inputs/<material_id>/>
        bucket = find_thermo_inputs_only(material_id)
        if bucket and bucket.candidates:
            scf_in_basename = bucket.candidates[0]
    # Juillet 2026 — preset P1 « Cᵢⱼ + DOS + Bandes » (ichamp=3) :
    # lu depuis le body JSON, normalisé via le helper partagé (tolère
    # bool, str « true »/« 1 », int 0/1, None). Hors P1 le constructeur
    # log un warning et ignore ; pas de crash.
    p1_full_preset = _parse_p1_full_preset_from_request(
        data.get("p1_full_preset") if isinstance(data, dict) else None
    )
    # Juillet 2026 — opt-ins documentés mais jamais câblés sur cette route :
    #   * ``needs_optical`` (P5) : chaîne ε(ω) exhaustive (epsilon.x + turbo).
    #   * ``lo_to_opt_in`` (P1)  : chaîne LO/TO (dielectric → BORN → matdyn
    #     non_analytic). Normalisés via le même helper bool tolérant.
    needs_optical = (
        _parse_p1_full_preset_from_request(data.get("needs_optical"))
        if profile_id == "P5" else None
    )
    lo_to_opt_in = (
        _parse_p1_full_preset_from_request(data.get("lo_to_opt_in"))
        if profile_id == "P1" else None
    )
    job = PipelineJob(
        material_id=material_id,
        profile_id=profile_id,
        scf_in_basename=scf_in_basename,
        nproc=nproc,
        user_work_dir=user_work_dir,
        properties_enabled=properties_enabled,
        properties_ichamp=properties_ichamp,
        needs_optical=needs_optical,
        extra_whats=extra_whats,
        lo_to_opt_in=lo_to_opt_in,
        p1_full_preset=p1_full_preset,
    )
    job.start()
    return jsonify({"ok": True, **job.to_dict()}), 202


# ----------------------------------------------------------------------------

def _apply_p1_full_preset(profile_dict: dict, profile_id: str, p1_full_preset: Optional[bool], *, log) -> dict:
    """DRY helper (juillet 2026) — applique l’override P1_full_preset utilisé par
    ``PipelineJob.__init__`` et ``PipelineJob.from_dict``.

    * ``p1_full_preset=True`` + ``profile_id='P1'`` → idempotent ``properties_enabled=True``,
      ``properties_ichamp=3``, ``thermo_opts['ltherm_dos']=False``.
    * ``p1_full_preset=True`` + autre profil → no-op + log (callback ``log()``).
    * ``p1_full_preset=False|None`` → no-op.

    Renvoie le dict profil mis à jour (immutable : ne mute pas le PROFILES global).
    """
    if p1_full_preset is not True:
        return profile_dict
    if profile_id != "P1":
        log(f"⚠️ [p1_full_preset] ignoré sur le profil {profile_id!r} ; "
            "le preset n’a d’effet que sur P1.")
        return profile_dict
    out = {
        **profile_dict,
        "properties_enabled": True,
        "properties_ichamp": 3,
    }
    thermo_opts = dict(profile_dict.get("thermo_opts") or {})
    thermo_opts["ltherm_dos"] = False
    return {**out, "thermo_opts": thermo_opts}


def _parse_p1_full_preset_from_request(raw: object) -> "Optional[bool]":
    """Normalise la valeur ``p1_full_preset`` extraite du body JSON.

    Tolère : ``True``/``False`` bool, ``"true"/"1"/"True"`` strings, ``1``/``0`` ints,
    et ``None`` (clé absente ou ``null``). Refuse tout le reste en retournant ``None``
    — le backend l’ignore silencieusement (n’override pas le profil).
    """
    if isinstance(raw, bool):
        return raw
    if isinstance(raw, str):
        v = raw.strip().lower()
        if v in ("true", "1"):
            return True
        if v in ("false", "0", ""):
            return False
        return None
    if isinstance(raw, int) and raw in (0, 1):
        return bool(raw)
    return None

# Définition des 5 profils — blocs partagés (contrat UI P1..P5)
# ----------------------------------------------------------------------------

_PROFILE_PROPERTIES = {"properties_enabled": True, "properties_ichamp": 3}

_METRICS_ELECTRONIC = [
    {"key": "properties.fermi_eV", "label": "E_Fermi (NSCF)", "unit": "eV", "group": "Propriétés électroniques"},
    {"key": "properties.vbm_eV", "label": "VBM (sommet bande de valence)", "unit": "eV", "group": "Propriétés électroniques"},
    {"key": "properties.cbm_eV", "label": "CBM (bas bande de conduction)", "unit": "eV", "group": "Propriétés électroniques"},
    {"key": "properties.band_gap_eV", "label": "Gap (VBM→CBM)", "unit": "eV", "group": "Propriétés électroniques"},
    {"key": "properties.band_gap_type", "label": "Nature du matériau (gap)", "unit": "", "group": "Propriétés électroniques"},
    {"key": "properties.gap_direct", "label": "Gap direct / indirect", "unit": "", "group": "Propriétés électroniques"},
    {"key": "properties.n_bands", "label": "Bandes K-S", "unit": "", "group": "Propriétés électroniques"},
]

_METRICS_DYN_STABILITY = [
    {"key": "properties.dynamically_stable", "label": "Stabilité dynamique", "unit": "", "group": "Stabilité dynamique"},
    {"key": "properties.n_imaginary_modes", "label": "Modes imaginaires", "unit": "", "group": "Stabilité dynamique"},
    {"key": "properties.min_freq_cm-1", "label": "ω_min (cm⁻¹)", "unit": "cm⁻¹", "group": "Stabilité dynamique"},
]

# Métriques magnétiques (opt-in nspin>1) — annoncées P1..P5, peuplées si SCF spin-polarisé.
_METRICS_MAGNETISM = [
    {"key": "magnetism.m_per_atom", "label": "Moment magnétique par atome (moyenne)", "unit": "μ_B", "group": "Magnétisme"},
    {"key": "magnetism.total_magnetization", "label": "Magnétisation totale par maille", "unit": "μ_B", "group": "Magnétisme"},
    # Août 2026 — classification depuis les moments convergés du SCF
    # (FM / AFM / ferrimagnétique / non-colinéaire / effondré). Diffère de la
    # détection d'entrée (starting_magnetization) qui ne capture que l'intention.
    {"key": "magnetism.magnetic_order", "label": "Ordre magnétique (convergé)", "unit": "", "group": "Magnétisme"},
    {"key": "magnetism.projected_moments_per_atom", "label": "Moments magnétiques par site (convergés)", "unit": "μ_B", "group": "Magnétisme"},
]

# Dilatation thermique α, Cp (dérivées QHA — parsers/thermo_derived.py)
# Les clés ``*_source`` sont affichées inline sous α / Cp / ε₀ dans l'UI.
_METRICS_THERMO_EXTENDED = [
    {"key": "thermo.alpha_300K_per_K", "label": "α dilatation (T=300 K)", "unit": "K⁻¹", "group": "Thermo-élasticité (α, Cp)"},
    {"key": "thermo.Cp_300K_Ry_per_K", "label": "Cₚ (T=300 K)", "unit": "Ry/K", "group": "Thermo-élasticité (α, Cp)"},
]

# ε∞ vs ε₀ (statique) — LST ou DFPT
_METRICS_DIELECTRIC_EPS0 = [
    {"key": "dielectric.epsilon_static_average", "label": "ε₀ moyenne (statique)", "unit": "", "group": "Permittivité ε₀ vs ε∞"},
]

# Piézoélectrique — composantes numériques (extra P5)
_METRICS_PIEZO_NUMERIC = [
    {"key": "thermo_extras.piezoelectric_tensor.max_component_C_per_m2", "label": "|e|_max", "unit": "C/m²", "group": "Piézoélectrique e_ijk"},
    {"key": "thermo_extras.piezoelectric_tensor.e_33", "label": "e₃₃", "unit": "C/m²", "group": "Piézoélectrique e_ijk"},
]

# Born Z* — détail live
_METRICS_BORN_DETAIL = [
    {"key": "dielectric.born_Z_star_n_atoms", "label": "Atomes avec Z* parsés", "unit": "", "group": "Charges effectives de Born"},
]

_PLOTS_ELECTRONIC = [
    {"key": "plots.ebands", "label": "Bandes électroniques E(k)"},
    {"key": "plots.edos", "label": "DOS totale"},
]

_COMMON_INPUTS = [
    "scf.in (géométrie d'équilibre DFT)",
    "nproc (MPI, défaut 4)",
]


def _thermo_opts_qha(*, ltherm_dos: bool) -> dict:
    return {
        "tmin": 0.0, "tmax": 1000.0, "deltat": 50.0,
        "zasr": "simple", "fildyn": "ph_dyn", "ltherm_dos": ltherm_dos,
    }


def _params_qha_grid(*, what_value: str, extra: list | None = None) -> list:
    base = [
        {"key": "what", "label": "Directive thermo_pw", "value": what_value},
        {"key": "tmin", "label": "Température min", "value": "0 K"},
        {"key": "tmax", "label": "Température max", "value": "1000 K"},
        {"key": "deltat", "label": "Pas en T", "value": "50 K"},
        {"key": "eos_grid", "label": "Grille EOS", "value": "7 points, ±3%"},
        {"key": "phonon_grid", "label": "Grille q phonons", "value": "4 × 4 × 4"},
        {"key": "nproc", "label": "Processus MPI", "value": "défaut 4"},
    ]
    if extra:
        return extra + base
    return base


PROFILES = {
    "P1": {
        **_PROFILE_PROPERTIES,
        "id": "P1",
        "name": "Mechanics 0 K",
        "thermo_opts": {
            "ltherm_dos": False,
        },

        # === Juillet 2026 — opt-in LO/TO production sur P1 ==========================
        "lo_to_opt_in_default": False,

        "emoji": "🟢",
        "what_qe": "scf_elastic_constants",
        "description": (
            "SCF V₀ → thermo_pw what='scf_elastic_constants' → C_ij → VRH moduli (elasticity @ T=0 K). "
            "DFPT phonons (4×4×4) → dynamic stability + dispersions. "
            "NSCF + DOS + electronic bands (ichamp=3)."
        ),
        "storage_hint": (
            "Constantes Cᵢⱼ (matrice 6×6) + modules B/G/E/ν + phonons DFPT (stabilité dynamique) "
            "+ structure de bandes électronique. "
            "thermo_pw what='scf_elastic_constants' → output_el_cons.dat (kbar) puis modules VRH en GPa."
        ),
        "inputs": list(_COMMON_INPUTS),
        "outputs": [
            "output_el_cons.dat — matrice Cᵢⱼ (kbar)",
            "thermo_pw_run.out — journal thermo_pw",
            "phonon_bands.png / phonon_dos.png — dispersions et DOS phononique",
            "ebands.png / edos.png — structure électronique (ichamp=3)",
            "BORN — tenseur diélectrique ε∞ + Z* par atome (matdyn non_analytic)",
            "phonon.freq (matdyn re-run avec non_analytic=.true.) — bandes phononiques LO/TO",
            "dielectric.lo_to_splitting_cm-1 — splitting LO–TO au point Γ",
        ],
        "prerequisites": [
            "SCF doit converger (conv_thr ≤ 1e-8 Ry recommandé).",
            "Phonons DFPT doivent converger (grille q 4×4×4).",
            "**Si lo_to_opt_in=True** : pseudos Norm-Conserving OBLIGATOIRES (epsilon.x et "
            "matdyn non_analytic refusent US-PP / PAW). Vérifié par `lo_to_chain.check_pseudos_are_nc`.",
        ],
        "steps": [
            "SCF sur géométrie d'équilibre",
            "ph.x → q2r.x → matdyn.x (grille 4×4×4, dispersions + DOS phononique)",
            "thermo_pw.x what='scf_elastic_constants' (déformations de Voigt finies, T=0 K)",
            "Parse C_ij et modules élastiques",
            "NSCF + dos.x + bands.x (ichamp=3 — E_Fermi, gap, bandes E(k))",
            "Analyse stabilité dynamique (fréquences imaginaires)",
            "**OPT-IN lo_to_opt_in=True** : sub-run dielectric → écrit BORN → re-run matdyn "
            "avec non_analytic=.true. → expose split LO/TO au point Γ",
        ],
        "needs_eos": False,
        "needs_phonons": True,
        "lo_to_supported": True,
        "expected_results": {
            "metrics": [
                {"key": "elastic.C11_GPa", "label": "C₁₁", "unit": "GPa", "group": "Constantes élastiques"},
                {"key": "elastic.C12_GPa", "label": "C₁₂", "unit": "GPa", "group": "Constantes élastiques"},
                {"key": "elastic.C44_GPa", "label": "C₄₄", "unit": "GPa", "group": "Constantes élastiques"},
                {"key": "elastic.bulk_modulus_GPa", "label": "B (VRH)", "unit": "GPa", "group": "Modules polycristallins"},
                {"key": "elastic.shear_modulus_GPa", "label": "G (VRH)", "unit": "GPa", "group": "Modules polycristallins"},
                {"key": "elastic.young_modulus_GPa", "label": "E (VRH)", "unit": "GPa", "group": "Modules polycristallins"},
                {"key": "elastic.poisson_ratio", "label": "ν", "unit": "", "group": "Modules polycristallins"},
                {"key": "dielectric.lo_to_splitting_cm-1", "label": "Splitting LO−TO à Γ (opt-in)", "unit": "cm⁻¹", "group": "LO/TO (opt-in)"},
                {"key": "dielectric.lo_freq_cm-1", "label": "ω LO à Γ (opt-in)", "unit": "cm⁻¹", "group": "LO/TO (opt-in)"},
                {"key": "dielectric.to_freq_cm-1", "label": "ω TO à Γ (opt-in)", "unit": "cm⁻¹", "group": "LO/TO (opt-in)"},
                *_METRICS_DIELECTRIC_EPS0,
                {"key": "thermo.debye_temperature_K", "label": "Θ Debye (fichier therm)", "unit": "K", "group": "Thermodynamique (aux.)"},
                {"key": "thermo.Cv_300K_Ry_per_K", "label": "Cᵥ (T=300 K)", "unit": "Ry/K", "group": "Thermodynamique (aux.)"},
                {"key": "thermo.F_300K_Ry", "label": "F Helmholtz (T=300 K)", "unit": "Ry", "group": "Thermodynamique (aux.)"},
                *_METRICS_THERMO_EXTENDED,
                *_METRICS_ELECTRONIC,
                *_METRICS_DYN_STABILITY,
                *_METRICS_MAGNETISM,
            ],
            "plots": [
                {"key": "plots.phonon_bands", "label": "Bandes phononiques"},
                {"key": "plots.phonon_dos", "label": "DOS phononique"},
                {"key": "plots.thermo_cv_cp", "label": "Cᵥ(T) vs Cₚ(T)"},
                *_PLOTS_ELECTRONIC,
            ],
            "files": [
                {"name": "scf.in", "label": "Input SCF"},
                {"name": "ph.in", "label": "Input ph.x (DFPT)"},
                {"name": "q2r.in", "label": "Input q2r.x"},
                {"name": "fc.out", "label": "Constantes de force"},
                {"name": "phonon.freq", "label": "Fréquences phononiques (dispersions)"},
                {"name": "phonon.dos", "label": "DOS phononique brute"},
                {"name": "phonon_bands.png", "label": "Plot bandes phononiques"},
                {"name": "phonon_dos.png", "label": "Plot DOS phononique"},
                {"name": "thermo_pw_run.out", "label": "Sortie thermo_pw"},
                {"name": "output_el_cons.dat", "label": "Matrice C_ij"},
                {"name": "nscf.in", "label": "Input NSCF (ichamp=3)"},
                {"name": "ebands.png", "label": "Plot bandes électroniques"},
                {"name": "edos.png", "label": "Plot DOS électronique"},
            ],
        },
        "params_summary": [
            {"key": "what", "label": "Directive thermo_pw", "value": "scf_elastic_constants"},
            {"key": "phonon_grid", "label": "Grille q phonons", "value": "4 × 4 × 4 (DFPT)"},
            {"key": "ichamp", "label": "Propriétés électroniques", "value": "ichamp=3 (NSCF + DOS + bandes)"},
            {"key": "nproc", "label": "Processus MPI", "value": "défaut 4"},
            {"key": "deformation", "label": "Latgen (déformations)", "value": "≈ ±1.5% par défaut pour C_ij"},
            {"key": "eos_grid", "label": "Grille EOS", "value": "(non requise pour P1)"},
        ],
    },
    "P2": {
        **_PROFILE_PROPERTIES,
        "id": "P2",
        "name": "Thermal QHA",
        "thermo_opts": _thermo_opts_qha(ltherm_dos=True),

        "emoji": "🌡️",
        # ``what_qe`` historique conservé (``thermo`` vu côté UI / logs / state_db
        # persistés) — l'API réécrit silencieusement ``thermo`` → ``mur_lc_t``
        # dans ``phonon_chain_qe.run_thermo_pw_mpi`` (thermo_pw 7.x ne connaît
        # PAS ``what='thermo'`` ; ``mur_lc_t`` est la valeur canonique QHA 7.x).
        # L'ancien commentaire portait ``canonique (alias legacy: mur_lc_t)``
        # — c'était inversé : ``thermo`` est bien le legacy projet, pas le
        # canonique 7.x (cf. ``phonon_chain_qe._THERMO_PW_QHA_KEYS``).
        "what_qe": "thermo",
        "what_qe_display": "mur_lc_t (QHA)",
        "description": "7-point EOS grid (±3 %) + DFPT phonons (4×4×4) + thermo_pw what='mur_lc_t' (QHA 7.x, API/UI alias: thermo) → thermodynamic quantities vs T (ΔT=50 K).",
        "storage_hint": (
            "EOS Birch–Murnaghan (V₀, B₀, B′, E₀) + phonons DFPT + grandeurs thermo QHA vs T "
            "(Cv, Debye, F(T)). thermo_pw what='mur_lc_t' (ΔT=50 K)."
        ),
        "inputs": list(_COMMON_INPUTS),
        "outputs": [
            "thermo_pw_run.out — journal QHA",
            "1_eos_volumes/eos_ev.png — courbe E(V)",
            "phonon_bands.png / phonon_dos.png — dispersions et DOS phononique",
            "ebands.png / edos.png — structure électronique (ichamp=3)",
        ],
        "prerequisites": [
            "Phonons DFPT doivent converger (forces < 1e-8 Ry/bohr).",
            "Grille EOS 7 points ±3 % recommandée pour QHA fiable.",
        ],
        "steps": [
            "Grille EOS (n_points, ±m%)",
            "SCF par volume → fit Birch–Murnaghan",
            "SCF @ V₀",
            "ph.x → q2r.x → matdyn.x (grille 4×4×4, dispersions + DOS phononique)",
            "Analyse stabilité dynamique (fréquences imaginaires)",
            "thermo_pw.x what='thermo' (Tmin/Tmax/ΔT=50 K, ltherm_dos=.TRUE.)",
            "NSCF + dos.x + bands.x (ichamp=3 — E_Fermi, gap, bandes E(k))",
            "gnuplot E(V) et courbes T vs Cv/Debye",
        ],
        "needs_eos": True,
        "needs_phonons": True,
        "expected_results": {
            "metrics": [
                {"key": "eos.V0_bohr3", "label": "V₀ (volume d'équilibre)", "unit": "bohr³", "group": "Équation d'état (Birch–Murnaghan)"},
                {"key": "eos.B0_GPa", "label": "B₀ (module de compressibilité)", "unit": "GPa", "group": "Équation d'état (Birch–Murnaghan)"},
                {"key": "eos.B0prime", "label": "B′ (dérivée de B₀)", "unit": "", "group": "Équation d'état (Birch–Murnaghan)"},
                {"key": "eos.E0_Ry", "label": "E₀ (énergie d'équilibre)", "unit": "Ry", "group": "Équation d'état (Birch–Murnaghan)"},
                # Août 2026 — maille d'équilibre déduite du fit (scf_eq.in) :
                # V₀ seul parle peu, a₀/b₀/c₀ sont la donnée que l'utilisateur
                # compare à l'expérience. b₀/c₀ restent « — » si le réseau ne
                # les définit pas (celldm(2)/(3) absents).
                {"key": "eos.a0_bohr", "label": "a₀ (= celldm(1) à V₀)", "unit": "bohr", "group": "Équation d'état (Birch–Murnaghan)"},
                {"key": "eos.a0_A", "label": "a₀ (paramètre de maille)", "unit": "Å", "group": "Équation d'état (Birch–Murnaghan)"},
                {"key": "eos.b0_A", "label": "b₀ (paramètre de maille)", "unit": "Å", "group": "Équation d'état (Birch–Murnaghan)"},
                {"key": "eos.c0_A", "label": "c₀ (paramètre de maille)", "unit": "Å", "group": "Équation d'état (Birch–Murnaghan)"},
                {"key": "thermo.debye_temperature_K", "label": "Θ Debye", "unit": "K", "group": "Thermodynamique QHA"},
                {"key": "thermo.zero_point_energy_Ry", "label": "Énergie de point zéro", "unit": "Ry", "group": "Thermodynamique QHA"},
                # Juillet 2026 — parsés depuis therm_files/output_therm.dat.gN
                # (géométrie centrale de la grille QHA, cf. parsers/thermo_therm_dat).
                {"key": "thermo.Cv_300K_Ry_per_K", "label": "Cᵥ (T=300 K)", "unit": "Ry/K", "group": "Thermodynamique QHA"},
                {"key": "thermo.F_300K_Ry", "label": "F Helmholtz (T=300 K)", "unit": "Ry", "group": "Thermodynamique QHA"},
                {"key": "thermo.entropy_300K_Ry_per_K", "label": "Entropie S (T=300 K)", "unit": "Ry/K", "group": "Thermodynamique QHA"},
                *_METRICS_THERMO_EXTENDED,
                *_METRICS_ELECTRONIC,
                *_METRICS_DYN_STABILITY,
                *_METRICS_MAGNETISM,
            ],
            "plots": [
                {"key": "plots.eos_ev", "label": "E(V) — Murnaghan"},
                {"key": "plots.phonon_bands", "label": "Bandes phononiques"},
                {"key": "plots.phonon_dos", "label": "DOS phononique"},
                {"key": "plots.thermo_cv", "label": "Thermodynamique QHA — F, S, Cᵥ vs T"},
                {"key": "plots.thermo_cv_cp", "label": "Cᵥ(T) vs Cₚ(T)"},
                *_PLOTS_ELECTRONIC,
            ],
            "files": [
                {"name": "scf.in", "label": "Input SCF"},
                {"name": "ph.in", "label": "Input ph.x"},
                {"name": "q2r.in", "label": "Input q2r.x"},
                {"name": "fc.out", "label": "Constantes de force"},
                {"name": "phonon.freq", "label": "Fréquences phononiques (dispersions)"},
                {"name": "phonon.dos", "label": "DOS phononique brute"},
                {"name": "phonon_bands.png", "label": "Plot bandes phononiques"},
                {"name": "phonon_dos.png", "label": "Plot DOS phononique"},
                {"name": "nscf.in", "label": "Input NSCF (ichamp=3)"},
                {"name": "ebands.png", "label": "Plot bandes électroniques"},
                {"name": "edos.png", "label": "Plot DOS électronique"},
                {"name": "thermo_pw_run.out", "label": "Sortie thermo_pw"},
                {"name": "1_eos_volumes/eos_ev.png", "label": "Plot E(V)"},
            ],
        },
        "params_summary": _params_qha_grid(what_value="mur_lc_t (QHA)"),
    },
    "P3": {
        **_PROFILE_PROPERTIES,
        "id": "P3",
        "name": "Full study",
        "thermo_opts": _thermo_opts_qha(ltherm_dos=True),

        "emoji": "👑",
        # thermo_pw 7.x : C_ij(V₀,T) sur grille QHA s'écrit directement
        # ``what='elastic_constants_geo'`` + use_free_energy + elastic_algorithm='energy'.
        # L'ancien alias UI/API ``mur_lc_t_elastic_constants`` est converti
        # en ``elastic_constants_geo`` par ``phonon_chain_qe.run_thermo_pw_mpi``.
        "what_qe": "elastic_constants_geo",
        "description": "P2 + thermo_pw what='elastic_constants_geo' on T grid 0→1000 K → C_ij(V₀,T) + polycrystalline moduli vs T.",
        "storage_hint": (
            "Tout P2 + Cᵢⱼ(V₀,T) et modules polycristallins vs T — "
            "thermo_pw what='elastic_constants_geo' (use_free_energy + elastic_algorithm='energy') sur grille 0→1000 K."
        ),
        "inputs": list(_COMMON_INPUTS),
        "outputs": [
            "elastic_constants_vs_T.dat — Cᵢⱼ vs T",
            "thermo_pw_run.out — journal thermo_pw",
            "1_eos_volumes/eos_ev.png — courbe E(V)",
            "phonon_bands.png / phonon_dos.png — dispersions et DOS phononique",
            "ebands.png / edos.png — structure électronique (ichamp=3)",
        ],
        "prerequisites": [
            "EOS + phonons QHA convergés (même boucle que P2).",
            "Coût élevé : C_ij(T) sur la grille 0→1000 K + 6 déformations élastiques.",
        ],
        "steps": [
            "Idem P2 (EOS + phonons DFPT + stabilité dynamique)",
            "thermo_pw.x what=elastic_constants_geo + use_free_energy + elastic_algorithm='energy'",
            "Parse C_ij(V,T), modules polycristallins, anisotropie Zener",
            "NSCF + dos.x + bands.x (ichamp=3 — E_Fermi, gap, bandes E(k))",
        ],
        "needs_eos": True,
        "needs_phonons": True,
        "expected_results": {
            "metrics": [
                {"key": "eos.V0_bohr3", "label": "V₀", "unit": "bohr³", "group": "Équation d'état"},
                {"key": "eos.B0_GPa", "label": "B₀", "unit": "GPa", "group": "Équation d'état"},
                {"key": "eos.B0prime", "label": "B′", "unit": "", "group": "Équation d'état"},
                {"key": "eos.E0_Ry", "label": "E₀", "unit": "Ry", "group": "Équation d'état"},
                # Août 2026 — maille d'équilibre issue du fit Birch–Murnaghan.
                {"key": "eos.a0_bohr", "label": "a₀ (= celldm(1) à V₀)", "unit": "bohr", "group": "Équation d'état"},
                {"key": "eos.a0_A", "label": "a₀", "unit": "Å", "group": "Équation d'état"},
                {"key": "eos.b0_A", "label": "b₀", "unit": "Å", "group": "Équation d'état"},
                {"key": "eos.c0_A", "label": "c₀", "unit": "Å", "group": "Équation d'état"},
                {"key": "thermo.debye_temperature_K", "label": "Θ Debye", "unit": "K", "group": "Thermodynamique QHA"},
                {"key": "thermo.zero_point_energy_Ry", "label": "Énergie de point zéro", "unit": "Ry", "group": "Thermodynamique QHA"},
                {"key": "thermo.Cv_300K_Ry_per_K", "label": "Cᵥ (T=300 K)", "unit": "Ry/K", "group": "Thermodynamique QHA"},
                {"key": "thermo.F_300K_Ry", "label": "F Helmholtz (T=300 K)", "unit": "Ry", "group": "Thermodynamique QHA"},
                {"key": "thermo.entropy_300K_Ry_per_K", "label": "Entropie S (T=300 K)", "unit": "Ry/K", "group": "Thermodynamique QHA"},
                *_METRICS_THERMO_EXTENDED,
                {"key": "elastic.C11_GPa", "label": "C₁₁(V₀,T)", "unit": "GPa", "group": "Élasticité C_ij"},
                {"key": "elastic.C12_GPa", "label": "C₁₂(V₀,T)", "unit": "GPa", "group": "Élasticité C_ij"},
                {"key": "elastic.C44_GPa", "label": "C₄₄(V₀,T)", "unit": "GPa", "group": "Élasticité C_ij"},
                {"key": "elastic.bulk_modulus_GPa", "label": "B (VRH) @ T", "unit": "GPa", "group": "Modules polycristallins"},
                {"key": "elastic.shear_modulus_GPa", "label": "G (VRH) @ T", "unit": "GPa", "group": "Modules polycristallins"},
                {"key": "elastic.young_modulus_GPa", "label": "E (VRH) @ T", "unit": "GPa", "group": "Modules polycristallins"},
                {"key": "elastic.poisson_ratio", "label": "ν @ T", "unit": "", "group": "Modules polycristallins"},
                *_METRICS_ELECTRONIC,
                *_METRICS_DYN_STABILITY,
                *_METRICS_MAGNETISM,
            ],
            "plots": [
                {"key": "plots.eos_ev", "label": "E(V) — Murnaghan"},
                {"key": "plots.phonon_bands", "label": "Bandes phononiques"},
                {"key": "plots.phonon_dos", "label": "DOS phononique"},
                {"key": "plots.elastic_vs_T", "label": "C_ij(T) et modules VRH vs T"},
                {"key": "plots.thermo_cv", "label": "Thermodynamique QHA — F, S, Cᵥ vs T"},
                {"key": "plots.thermo_cv_cp", "label": "Cᵥ(T) vs Cₚ(T)"},
                *_PLOTS_ELECTRONIC,
            ],
            "files": [
                {"name": "scf.in", "label": "Input SCF"},
                {"name": "ph.in", "label": "Input ph.x"},
                {"name": "q2r.in", "label": "Input q2r.x"},
                {"name": "fc.out", "label": "Constantes de force"},
                {"name": "phonon.freq", "label": "Fréquences phononiques (dispersions)"},
                {"name": "phonon.dos", "label": "DOS phononique brute"},
                {"name": "phonon_bands.png", "label": "Plot bandes phononiques"},
                {"name": "phonon_dos.png", "label": "Plot DOS phononique"},
                {"name": "nscf.in", "label": "Input NSCF (ichamp=3)"},
                {"name": "ebands.png", "label": "Plot bandes électroniques"},
                {"name": "edos.png", "label": "Plot DOS électronique"},
                {"name": "thermo_pw_run.out", "label": "Sortie thermo_pw"},
                {"name": "1_eos_volumes/eos_ev.png", "label": "Plot E(V)"},
                {"name": "elastic_constants_vs_T.dat", "label": "C_ij vs T brute"},
            ],
        },
        "params_summary": _params_qha_grid(
            what_value="elastic_constants_geo",
            extra=[
                {"key": "use_free_energy", "label": "Méthode C_ij(T)", "value": "Énergie libre (use_free_energy=T)"},
                {"key": "elastic_algorithm", "label": "Algorithme C_ij", "value": "energy"},
            ],
        ),
    },
    "P4": {
        **_PROFILE_PROPERTIES,
        "id": "P4",
        "name": "Phonon lifetimes (Anharmonicity)",
        "thermo_opts": _thermo_opts_qha(ltherm_dos=False),

        "emoji": "🎯",
        "what_qe": "ph_life",  # juin 2026 refonte : canonique (alias legacy: qha_lif)
        "description": "P3 + thermo_pw what='ph_life' (legacy alias: qha_lif) → lifetime τ_λ(ω) per phonon mode (3-phonon anharmonicity). Conv_thr ≤ 1.0D-12 (recommended in &ELECTRONS of scf.in, not in thermo_control).",
        "storage_hint": (
            "Tout P3 + durées de vie τ_λ(ω) par mode phonon (anharmonicité 3-phonons) — "
            "thermo_pw what='ph_life'. Conv_thr ≤ 1e-12 requis (dans &ELECTRONS de scf.in)."
        ),
        "inputs": list(_COMMON_INPUTS),
        "outputs": [
            "thermo_pw_run.out — journal ph_life (τ_λ, Γ_λ, κ_lattice)",
            "1_eos_volumes/eos_ev.png — courbe E(V)",
            "phonon_bands.png / phonon_dos.png — dispersions et DOS phononique",
            "ebands.png / edos.png — structure électronique (ichamp=3)",
        ],
        "prerequisites": [
            "Conv_thr ≤ 1.0d-12 dans &ELECTRONS de scf.in (pas dans thermo_control).",
            "Pseudos norm-conservés recommandés (constantes de force précises).",
            "Phonons DFPT convergés (grille q 4×4×4 minimum).",
        ],
        "steps": [
            "input_editor.reinforce_params('strict') sur scf.in / ph.in",
            "Pseudos NC high-stringency (sélection auto si disponibles)",
            "Idem P3 (EOS + phonons DFPT + stabilité dynamique)",
            "thermo_pw.x what='ph_life' → τ_λ(ω) par mode + κ_lattice(T)",
            "NSCF + dos.x + bands.x (ichamp=3 — E_Fermi, gap, bandes E(k))",
            "Parse : durées de vie τ_λ(ω) par mode phonon, conductivité thermique κ_lattice(T), élargissements Γ(T)",
        ],
        "needs_eos": True,
        "needs_phonons": True,
        "apply_reinforce_strict": True,
        "expected_results": {
            "metrics": [
                {"key": "eos.V0_bohr3", "label": "V₀ (haute précision)", "unit": "bohr³", "group": "Équation d'état"},
                {"key": "eos.B0_GPa", "label": "B₀ (haute précision)", "unit": "GPa", "group": "Équation d'état"},
                {"key": "eos.B0prime", "label": "B′", "unit": "", "group": "Équation d'état"},
                {"key": "eos.E0_Ry", "label": "E₀", "unit": "Ry", "group": "Équation d'état"},
                # Août 2026 — maille d'équilibre issue du fit Birch–Murnaghan.
                {"key": "eos.a0_bohr", "label": "a₀ (= celldm(1) à V₀)", "unit": "bohr", "group": "Équation d'état"},
                {"key": "eos.a0_A", "label": "a₀", "unit": "Å", "group": "Équation d'état"},
                {"key": "eos.b0_A", "label": "b₀", "unit": "Å", "group": "Équation d'état"},
                {"key": "eos.c0_A", "label": "c₀", "unit": "Å", "group": "Équation d'état"},
                {"key": "thermo.debye_temperature_K", "label": "Θ Debye", "unit": "K", "group": "Thermodynamique QHA"},
                {"key": "thermo.zero_point_energy_Ry", "label": "Énergie de point zéro", "unit": "Ry", "group": "Thermodynamique QHA"},
                {"key": "thermo.Cv_300K_Ry_per_K", "label": "Cᵥ (T=300 K)", "unit": "Ry/K", "group": "Thermodynamique QHA"},
                {"key": "thermo.F_300K_Ry", "label": "F Helmholtz (T=300 K)", "unit": "Ry", "group": "Thermodynamique QHA"},
                {"key": "thermo.entropy_300K_Ry_per_K", "label": "Entropie S (T=300 K)", "unit": "Ry/K", "group": "Thermodynamique QHA"},
                *_METRICS_THERMO_EXTENDED,
                # === ph_life (juin 2026 refonte — what='ph_life' remplace qha_lif) ========
                {"key": "ph_life.mean_lifetime_ps", "label": "Durée de vie moyenne τ (phonons)", "unit": "ps", "group": "Durée de vie des phonons"},
                {"key": "ph_life.mean_linewidth_cm-1", "label": "Largeur de raie moyenne γ", "unit": "cm⁻¹", "group": "Durée de vie des phonons"},
                {"key": "ph_life.min_lifetime_ps", "label": "τ minimum (mode le plus résistif)", "unit": "ps", "group": "Durée de vie des phonons"},
                {"key": "ph_life.max_linewidth_cm-1", "label": "Largeur de raie γ max (mode le plus large)", "unit": "cm⁻¹", "group": "Durée de vie des phonons"},
                {"key": "ph_life.lattice_kappa_W_mK", "label": "Conductivité thermique κ_lattice (si calculée)", "unit": "W/(m·K)", "group": "Durée de vie des phonons"},
                {"key": "ph_life.gruneisen_mean", "label": "Paramètre de Grüneisen moyen γ(q,ν)", "unit": "", "group": "Durée de vie des phonons"},
                *_METRICS_ELECTRONIC,
                *_METRICS_DYN_STABILITY,
                *_METRICS_MAGNETISM,
            ],
            "plots": [
                {"key": "plots.eos_ev", "label": "E(V) — fit Birch–Murnaghan"},
                {"key": "plots.phonon_bands", "label": "Bandes phononiques"},
                {"key": "plots.phonon_dos", "label": "DOS phononique"},
                {"key": "plots.phonon_linewidth", "label": "Largeurs de raie γ(ω) par mode (anharmonicité)"},
                {"key": "plots.phonon_lifetime", "label": "Durées de vie τ(ω) par mode"},
                {"key": "plots.kappa_lattice", "label": "κ_lattice(T) — conductivité thermique du réseau"},
                {"key": "plots.gruneisen", "label": "Paramètre de Grüneisen γ(q,ν) (si calculé)"},
                *_PLOTS_ELECTRONIC,
            ],
            "files": [
                {"name": "scf.in", "label": "Input SCF (strict)"},
                {"name": "ph.in", "label": "Input ph.x (strict)"},
                {"name": "q2r.in", "label": "Input q2r.x"},
                {"name": "fc.out", "label": "Constantes de force"},
                {"name": "phonon.freq", "label": "Fréquences phononiques (dispersions)"},
                {"name": "phonon.dos", "label": "DOS phononique brute"},
                {"name": "phonon_bands.png", "label": "Plot bandes phononiques"},
                {"name": "phonon_dos.png", "label": "Plot DOS phononique"},
                {"name": "nscf.in", "label": "Input NSCF (ichamp=3)"},
                {"name": "ebands.png", "label": "Plot bandes électroniques"},
                {"name": "edos.png", "label": "Plot DOS électronique"},
                {"name": "thermo_pw_run.out", "label": "Sortie thermo_pw"},
                {"name": "1_eos_volumes/eos_ev.png", "label": "Plot E(V)"},
            ],
        },
        "params_summary": _params_qha_grid(
            what_value="ph_life",
            extra=[
                {"key": "lvl", "label": "Précision conv_thr (scf.in)", "value": "conv_thr ≤ 1.0D-12 (dans &ELECTRONS de pw.x, pas dans thermo_control)"},
                {"key": "outputs", "label": "Sorties principales", "value": "τ_λ(ω) par mode + κ_lattice(T)"},
            ],
        ),
    },
    "P5": {
        **_PROFILE_PROPERTIES,
        "id": "P5",
        "name": "Dielectric properties",
        "thermo_opts": {
            "zasr": "simple", "fildyn": "ph_dyn",
            # P5 = what='dielectric' minimal — pas de tmin/tmax/deltat (statique ε∞ via DFPT)
        },

        "emoji": "🌈",
        # P5 (juin 2026 refonte) — chaîne PRINCIPALE via thermo_pw what='dielectric'
        #   → tenseur diélectrique statique ε∞ (DFPT + Berry phase) à partir de
        #   la matrice dynamique fildyn des phonons précédents. La chaîne
        #   purement QE exhaustive (epsilon.x + turbo_lanczos.x + turbo_davidson.x
        #   pour ε(ω) en TDDFPT complet) reste accessible OPT-IN via les
        #   cases à cocher du panneau ② (Bands / DOS / Bandes+DOS / Réponse
        #   diélectrique), ou via extra_whats=['...'].
        "what_qe": "dielectric",  # juin 2026 refonte : canonique (alias legacy: epsilon.x+DFPT)
        "description": (
            "SCF @ V₀ → DFPT phonons → thermo_pw.x what='dielectric' → ε_∞ (3×3) "
            "+ Born Z* + refractive index n. No EOS or C_ij(T). ε(ω) chain (epsilon.x + turbo_*) "
            "opt-in via UI; thermo_pw extra_whats (plot_bz, piezo, …) optional."
        ),
        "storage_hint": (
            "Phonons DFPT + thermo_pw what='dielectric' → tenseur diélectrique statique ε∞ 3×3. "
            "Optionnel : réponse diélectrique ε(ω) via epsilon.x + turbo_lanczos.x + turbo_davidson.x (opt-in)."
        ),
        "inputs": [
            *_COMMON_INPUTS,
            "(optionnel) cases à cocher du panneau ② thermo_pw.in",
            "(optionnel) extra_whats P5 (plot_bz, piézoélectrique, …)",
        ],
        "outputs": [
            "thermo_pw_run.out — journal dielectric (ε∞, Born Z*)",
            "phonon_bands.png / phonon_dos.png — dispersions et DOS phononique",
            "ebands.png / edos.png — structure électronique (ichamp=3)",
            "epsilon.out / turbo_*.out — ε(ω) si chaîne optique activée",
            "thermo_pw_<what>.out — journaux extra_whats",
        ],
        "prerequisites": [
            "Phonons DFPT convergents (fildyn requis pour dielectric).",
            "Pseudos norm-conservés requis pour ε∞ précis (NC).",
            "Chaîne ε(ω) opt-in : turbo_lanczos.x + turbo_davidson.x compilés.",
        ],
        "steps": [
            "SCF @ V₀ (pas de grille EOS)",
            "ph.x → q2r.x → matdyn.x (grille 4×4×4, fildyn pour dielectric)",
            "Analyse stabilité dynamique (fréquences imaginaires)",
            "thermo_pw.x what='dielectric' → tenseur ε∞, charges de Born Z*, indice n",
            "NSCF + dos.x + bands.x (ichamp=3 — E_Fermi, gap, bandes E(k))",
            "(opt-in) epsilon.x + turbo_lanczos.x + turbo_davidson.x pour ε(ω)",
            "(opt-in) extra_whats thermo_pw (plot_bz, piézoélectrique, …)",
        ],
        "needs_eos": False,
        "needs_phonons": True,  # dielectric lit fildyn des phonons DFPT
        # === juin 2026 refonte =================================================
        # P5 minimal : `what='dielectric'` (tenseur ε∞ via DFPT + Berry). Pas
        # d'epsilon.x / turbo par défaut. La chaîne optique exhaustive (ε(ω)
        # complet + TDDFPT) est OPT-IN via la case à cocher UI « Réponse
        # diélectrique ε(ω) complète » — l'API surcharche alors ``needs_optical``
        # dans ``PipelineJob.__init__`` (pattern ``properties_enabled``).
        "needs_optical": False,
        "needs_optical_overridable": True,  # flag UI opt-in
        # === P5 extension (juin 2026) =========================================
        # ``extra_whats`` : liste de ``what=`` thermo_pw complémentaires, par
        # défaut ``["plot_bz"]`` (présélection safe). L'utilisateur peut
        # ajouter/retirer via le panneau d'options P5 (étape ② UI).
        # Chaque what= est exécuté séquentiellement après la chaîne optique
        # pure (epsilon + turbo_lanczos + turbo_davidson), avec son propre
        # journal ``thermo_pw_<suffix>.out``. Voir thermo_what_catalog.WHAT_CATALOG.
        "default_extra_whats": default_extra_whats_for_p5(),
        "allowed_extra_whats": sorted(WHAT_CATALOG.keys()),
        "expected_results": {
            "metrics": [
                *_METRICS_ELECTRONIC,
                {"key": "optical_props.nscf_optic_ok", "label": "NSCF optique", "unit": "", "group": "Chaîne optique"},
                {"key": "optical_props.epsilon_ok", "label": "epsilon.x (DFPT linéaire)", "unit": "", "group": "Chaîne optique"},
                {"key": "optical_props.turbo_lanczos_ok", "label": "turbo_lanczos.x (TDDFPT)", "unit": "", "group": "Chaîne optique TDDFPT"},
                {"key": "optical_props.turbo_davidson_ok", "label": "turbo_davidson.x (TDDFPT)", "unit": "", "group": "Chaîne optique TDDFPT"},
                {"key": "optical_props.nscf_optic_nbnd", "label": "nbnd NSCF_optic", "unit": "", "group": "Chaîne optique"},
                # --- P5 extras : visibles dans l'aperçu dès le départ (None initialement).
                {"key": "thermo_extras.plot_bz.ok", "label": "plot_bz (visualisation BZ)", "unit": "", "group": "Propriétés étendues (thermo_pw)"},
                {"key": "thermo_extras.piezoelectric_tensor.ok", "label": "Tenseur piézoélectrique e_ijk", "unit": "", "group": "Propriétés étendues (thermo_pw)"},
                {"key": "thermo_extras.magnetic_susceptibility.ok", "label": "Susceptibilité magnétique χ", "unit": "", "group": "Propriétés étendues (thermo_pw)"},
                {"key": "thermo_extras.magnetoelectric_tensor.ok", "label": "Tenseur magnétoélectrique α_ij", "unit": "", "group": "Propriétés étendues (thermo_pw)"},
                # === ε∞ tensor + Born Z* (juin 2026 refonte — what='dielectric') ============
                # NB (juin 2026) : « diag. positives » signifie que la moyenne ne retient que les
                # composantes diagonales strictement > 0 (ε=(12,0,0) → moyenne 12, pas 4). Le label
                # antérieur « trace/3 » était trompeur et a été remplacé pour éviter la confusion
                # avec la trace tensorielle classique.
                {"key": "dielectric.epsilon_xx", "label": "ε_xx (haute fréquence)", "unit": "", "group": "Tenseur diélectrique ε_∞"},
                {"key": "dielectric.epsilon_yy", "label": "ε_yy (haute fréquence)", "unit": "", "group": "Tenseur diélectrique ε_∞"},
                {"key": "dielectric.epsilon_zz", "label": "ε_zz (haute fréquence)", "unit": "", "group": "Tenseur diélectrique ε_∞"},
                {"key": "dielectric.epsilon_average", "label": "ε_∞ moyenne (diag. positives)", "unit": "", "group": "Tenseur diélectrique ε_∞"},
                {"key": "dielectric.epsilon_anisotropy", "label": "ε_∞ anisotropie (max/min)", "unit": "", "group": "Tenseur diélectrique ε_∞"},
                {"key": "dielectric.born_Z_star_max_abs", "label": "|Z*|_max (charge effective de Born)", "unit": "e", "group": "Charges effectives de Born"},
                *_METRICS_BORN_DETAIL,
                {"key": "dielectric.refractive_index_avg", "label": "Indice de réfraction n (√ε_∞)", "unit": "", "group": "Tenseur diélectrique ε_∞"},
                *_METRICS_DIELECTRIC_EPS0,
                *_METRICS_PIEZO_NUMERIC,
                *_METRICS_DYN_STABILITY,
                *_METRICS_MAGNETISM,
            ],
            "plots": [
                {"key": "plots.phonon_bands", "label": "Bandes phononiques"},
                {"key": "plots.phonon_dos", "label": "DOS phononique"},
                *_PLOTS_ELECTRONIC,
                # Plots dédiés ε∞/Z*/BZ : valeurs numériques via dielectric.* ;
                # tracés PNG dédiés = future (cf. audit juillet 2026).
            ],
            "files": [
                {"name": "thermo_pw_run.out", "label": "Journal thermo_pw (dielectric)"},
                {"name": "scf.in", "label": "Input SCF équilibre (P5)"},
                {"name": "ph.in", "label": "Input ph.x (DFPT)"},
                {"name": "q2r.in", "label": "Input q2r.x"},
                {"name": "fc.out", "label": "Constantes de force"},
                {"name": "phonon.freq", "label": "Fréquences phononiques (dispersions)"},
                {"name": "phonon.dos", "label": "DOS phononique brute"},
                {"name": "phonon_bands.png", "label": "Plot bandes phononiques"},
                {"name": "phonon_dos.png", "label": "Plot DOS phononique"},
                {"name": "nscf.in", "label": "Input NSCF (ichamp=3, DOS+bandes)"},
                {"name": "nscf_optic.in", "label": "Input NSCF optique (nbnd × 2, nosym/noinv)"},
                {"name": "nscf_optic.out", "label": "Sortie pw.x NSCF optique"},
                {"name": "epsilon.in", "label": "Input epsilon.x"},
                {"name": "epsilon.out", "label": "Sortie epsilon.x"},
                {"name": "turbo_lanczos.in", "label": "Input turbo_lanczos.x"},
                {"name": "turbo_lanczos.out", "label": "Sortie turbo_lanczos.x (TDDFPT Lanczos)"},
                {"name": "turbo_davidson.in", "label": "Input turbo_davidson.x"},
                {"name": "turbo_davidson.out", "label": "Sortie turbo_davidson.x (TDDFPT Davidson)"},
                {"name": "edos.png", "label": "Plot DOS"},
                {"name": "ebands.png", "label": "Plot bandes électroniques"},
                # Fichiers P5 extras thermo_pw — un journal par what=.
                # (Les fichiers BZ_plot.ps.gz / BZ.txt sont ajoutés via _post_process
                # s'ils existent ; listés ici pour faciliter la lecture humaine du profil.)
                {"name": "thermo_pw_plot_bz.out", "label": "Sortie thermo_pw (plot_bz)"},
                {"name": "thermo_pw_piezoelectric_tensor.out", "label": "Sortie thermo_pw (piézoélectrique)"},
                {"name": "thermo_pw_magnetic_susceptibility.out", "label": "Sortie thermo_pw (susceptibilité χ)"},
                {"name": "thermo_pw_magnetoelectric_tensor.out", "label": "Sortie thermo_pw (magnétoélectrique)"},
                {"name": "thermo_pw_scf_dielectric.out", "label": "Sortie thermo_pw (ε_∞)"},
            ],
        },
        "params_summary": [
            {"key": "what", "label": "Directive thermo_pw", "value": "dielectric"},
            {"key": "phonon_grid", "label": "Grille q phonons", "value": "4 × 4 × 4 (DFPT, fildyn requis)"},
            {"key": "ichamp", "label": "Propriétés électroniques", "value": "ichamp=3 (NSCF + DOS + bandes, sanity check gap)"},
            {"key": "extras", "label": "P5 extras thermo_pw (opt-in)", "value": "plot_bz (défaut) + piézo / magnétisme / …"},
            {"key": "optical_chain", "label": "Chaîne ε(ω) (opt-in UI)", "value": "epsilon.x + turbo_lanczos + turbo_davidson"},
            {"key": "pseudos", "label": "Contrainte pseudos", "value": "Norm-Conserving recommandés (ε∞ + chaîne optique)"},
            {"key": "nproc", "label": "Processus MPI", "value": "défaut 4"},
        ],
    },
}


def get_profile(profile_id: str) -> dict:
    """Renvoie le profil demandé ou lève KeyError si inconnu."""
    if profile_id not in PROFILES:
        raise KeyError(
            f"Profil inconnu : {profile_id!r}. "
            f"Choisis parmi : {', '.join(PROFILES.keys())}."
        )
    return PROFILES[profile_id]


def _render_thermo_pw_in_preview(profile: dict, material_id: str, nproc: int) -> dict:
    """Aperçu structuré du futur thermo_pw.in pour un profil donné.

    Retourne un dict :
      - ``summary_text`` : texte façon `&CONTROL / what / tmin / …` prêt à
        afficher dans un `<pre>` (bouton ② de l'UI 5 profils).
      - ``params``       : liste de ``{key, value}`` pour rendu tabulaire.
      - ``profile_id`` / ``profile_name`` / ``what`` : identité du profil.

    Cet aperçu est pseudo-structuré (description des directives prévues) — le
    rendu exact du thermo_pw.in reste interne à ``_run_thermo_pw``.
    """
    what = str(profile.get("what_qe") or "")
    lines: list[tuple[str, str]] = []
    lines.append(("&CONTROL", ""))
    lines.append(("  what", f"= '{what}'"))
    if profile.get("needs_eos"):
        lines.append(("  tmin", "= 0.0  ! K"))
        lines.append(("  tmax", "= 1000.0  ! K"))
        lines.append(("  deltat", "= 50.0  ! K"))
        ltherm = profile.get("thermo_opts", {}).get("ltherm_dos", True)
        lines.append(("  ltherm_dos", "= .TRUE." if ltherm else "= .FALSE."))
        lines.append(("  ltherm_freq", "= .FALSE."))
        lines.append(("  zasr", "= 'simple'"))
        lines.append(("  fildyn", "= 'ph_dyn'"))
    else:
        lines.append(("  !", f"what={what} : volume unique @ V₀, pas de grille T"))
    # ``elastic_constants_geo`` (canonique pour P3 QHA + phonons) est le SEUL
    # ``what=`` thermo_pw 7.x à requérir ``use_free_energy`` + ``elastic_algorithm`` :
    # la dépendance T vient de l'expansion QHA V₀(T) (EOS_GRID × phonons), PAS
    # du fildyn seul (qui ne porte que la matrice dynamique). NB historique :
    # ``scf_elastic_constants`` (P1, T=0K) omet ces drapeaux.
    if profile.get("what_qe") == "elastic_constants_geo":
        lines.append(("  use_free_energy", "= .TRUE."))
        lines.append(("  elastic_algorithm", "= 'energy'"))
    if profile.get("apply_reinforce_strict"):
        lines.append(("  ! P4 (LIF strict)", "conv_thr ≤ 1.0D-12 + pseudos NC high-str"))
    if profile.get("needs_eos"):
        lines.append(("&EOS_GRID", "7 points, ±3%"))
    else:
        lines.append(("&EOS_GRID", "(non requis)"))
    if profile.get("needs_phonons"):
        lines.append(("&PHONON_GRID", "4 × 4 × 4 (DFPT, autogenerate_ph_in)"))
    else:
        lines.append(("&PHONON_GRID", "(non requis)"))
    lines.append(("! MPI", f"nproc = {nproc}"))
    if material_id:
        lines.append(("! Matériau", material_id))
    pretty = "\n".join((f"{k:<32} {v}" if v else k) for k, v in lines)
    return {
        "profile_id": profile["id"],
        "profile_name": profile["name"],
        "what": what,
        "summary_text": pretty,
        "params": [
            {"key": k.strip(), "value": v.strip().strip("'") if v else ""}
            for k, v in lines
        ],
    }


def _backfill_eos_lattice_from_scf_eq(wd: Path, results: dict[str, Any]) -> None:
    """Complète a₀/b₀/c₀ dans ``results['eos']`` depuis ``scf_eq.in``.

    Runs antérieurs au déploiement août 2026 ont un ``eos_summary.json``
    sans clés maille ; ``scf_eq.in`` (généré au fit) est déjà à l'échelle V₀
    et suffit pour remplir les tuiles « eos.a0_A » etc. sans relancer l'EOS.
    """
    if not isinstance(results, dict):
        return
    eos = results.setdefault("eos", {})
    if not isinstance(eos, dict):
        return
    if eos.get("a0_A") is not None:
        return
    scf_eq = Path(wd) / "1_eos_volumes" / "scf_eq.in"
    if not scf_eq.is_file():
        return
    try:
        from input_scaling import extract_lattice_parameters

        lat = extract_lattice_parameters(
            scf_eq.read_text(encoding="utf-8", errors="replace")
        )
        for k, v in lat.items():
            if v is not None and eos.get(k) is None:
                eos[k] = v
    except Exception:  # noqa: BLE001
        pass


def _nest_set_default(d: dict, dotted_key: str, value: Any) -> None:
    """Set `d[section][key]=value` à partir d'un chemin pointé, en ne
    remplaçant jamais une valeur déjà posée (anti-flicker).

    Exemples :
        _nest_set_default({}, "eos.V0_bohr3", None)
        → {"eos": {"V0_bohr3": None}}
        _nest_set_default({"eos": {}}, "eos.V0_bohr3", 12.5)
        → {"eos": {"V0_bohr3": 12.5}}
        _nest_set_default({"eos": {"V0_bohr3": 12.5}}, "eos.V0_bohr3", None)
        → {"eos": {"V0_bohr3": 12.5}}   # ne ré-écrase PAS une valeur non-None
    """
    parts = [p for p in dotted_key.split(".") if p]
    if not parts:
        return
    cur = d
    for p in parts[:-1]:
        nxt = cur.get(p)
        if not isinstance(nxt, dict):
            nxt = {}
            cur[p] = nxt
        cur = nxt
    leaf = parts[-1]
    if leaf not in cur or cur[leaf] is None:
        cur[leaf] = value


def _nest_set_force(d: dict, dotted_key: str, value: Any) -> None:
    """Comme ``_nest_set_default`` mais écrase toujours la feuille (retry bandes)."""
    parts = [p for p in dotted_key.split(".") if p]
    if not parts:
        return
    cur = d
    for p in parts[:-1]:
        nxt = cur.get(p)
        if not isinstance(nxt, dict):
            nxt = {}
            cur[p] = nxt
        cur = nxt
    cur[parts[-1]] = value


def _normalize_plot_relpath(value: Any) -> Optional[str]:
    """Normalise une entrée ``results.plots.*`` en chemin relatif string (UI)."""
    if isinstance(value, str) and value.strip():
        return value.replace("\\", "/").strip()
    if isinstance(value, dict):
        rel = value.get("relpath") or value.get("path") or value.get("filename")
        if isinstance(rel, str) and rel.strip():
            return rel.replace("\\", "/").strip()
    return None


def _set_plot_path(results: dict[str, Any], plot_key: str, value: Any) -> None:
    """Écrit ``results['plots'][plot_key]`` en string relpath (contrat UI)."""
    rel = _normalize_plot_relpath(value)
    if not rel:
        return
    results.setdefault("plots", {})[plot_key] = rel


def _sanitize_plots_section(results: dict[str, Any]) -> None:
    """Convertit les plots legacy (dict gnuplot) en strings pour l'UI."""
    plots = results.get("plots")
    if not isinstance(plots, dict):
        return
    for k, v in list(plots.items()):
        if isinstance(v, dict):
            rel = _normalize_plot_relpath(v)
            if rel:
                plots[k] = rel
    # Ancien alias post-traitement → clé canonique expected_results.
    post = plots.pop("eos_ev_post", None)
    if post and not _normalize_plot_relpath(plots.get("eos_ev")):
        rel = _normalize_plot_relpath(post)
        if rel:
            plots["eos_ev"] = rel


def _detect_scf_capability(scf_path: Path) -> tuple[bool, str]:
    """Vérifie si `scf_path` est un SCF équilibre *autonome*.

    Renvoie ``(True, "")`` si le fichier ressemble à un ``pw.x -in ...``
    exécutable en work_dir neuf : ``calculation='scf'`` (ou non spécifié)
    avec ``restart_mode='from_scratch'`` (ou non spécifié).

    Renvoie ``(False, raison)`` si le fichier demande un SCF préalable
    qu'on n'a pas dans le pipeline « 5 profils » : ``nscf`` /
    ``bands`` / ``vc-relax`` / ``restart_mode='restart'``.

    Cette validation évite l'erreur QE « Error in routine
    read_conf_from_file (1): fatal error reading xml file » qui
    survient quand un NSCF est lancé par mégarde dans un work_dir neuf
    (le pipeline n'exécute pas d'étape ``scf_eq`` séparée pour P1).
    """
    try:
        text = scf_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        # Lecture impossible : laissons le pipeline tenter (erreur explicite
        # côté QE sera plus parlante qu'ici).
        return True, ""
    up = text.upper()
    m_calc = re.search(r"calculation\s*=\s*['\"]?([A-Z0-9_-]+)", up)
    calculation = (m_calc.group(1) if m_calc else "").rstrip("-_.").upper()
    m_rm = re.search(r"restart_mode\s*=\s*['\"]?([A-Z0-9_]+)", up)
    rm = (m_rm.group(1) if m_rm else "").upper()

    # ``calculation`` : seuls « SCF » et non-spécifié sont tolérés en mode
    # standalone. Tout le reste dépend d'un SCF préalable (l'EOS interne ne
    # le produit pas si l'utilisateur a lancé P1).
    non_scf_why = {
        "NSCF": (
            "ce calcul lit les fonctions d'onde d'un SCF préalable "
            "(restart_mode='restart' + prefix='scf_eq'/'wf1_eos') qui "
            "n'existe pas en work_dir neuf"
        ),
        "BANDS": (
            "BANDS hérite des fonctions d'onde d'un SCF préalable — "
            "même problème que NSCF"
        ),
        "VC-RELAX": "relaxation complète (cellule + positions) — non supportée par les 5 profils",
        "VC_RELAX": "variante orthographique de vc-relax",
        "VCRELAX": "variante orthographique de vc-relax",
        "RELAX": "relaxation des positions uniquement — non supportée par les 5 profils",
        "MD": "dynamique moléculaire — non supportée par les 5 profils",
    }
    if calculation and calculation != "SCF" and calculation in non_scf_why:
        return False, non_scf_why[calculation]

    # ``restart_mode='restart'`` impose que ``<outdir>/<prefix>.save/`` existe
    # déjà avec fichiers de reprise. C'est faux en work_dir neuf.
    if rm == "RESTART":
        return False, (
            "restart_mode='restart' impose que outdir/<prefix>.save/ existe "
            "déjà avec les fichiers de reprise d'un SCF préalable ; ce n'est "
            "pas le cas en work_dir neuf"
        )
    return True, ""


def _suggest_harmless_scf(scf_path: Path) -> Optional[str]:
    """Cherche parmi les fichiers .in du même répertoire un candidat SCF
    autonome (pas nscf, pas vc-relax) à suggérer quand l'utilisateur a
    choisi un mauvais fichier."""
    try:
        peerrs = list(scf_path.parent.iterdir())
    except OSError:
        return None
    candidates = [
        p for p in peerrs
        if p.is_file()
        and p.suffix.lower() == ".in"
        and "nscf" not in p.name.lower()
        and "vc-" not in p.name.lower()
        and "vcrelax" not in p.name.lower()
        and "vc_relax" not in p.name.lower()
        and "relax" not in p.name.lower()
    ]
    candidates.sort(key=lambda p: (-p.name.lower().count("scf"), p.name.lower()))
    return candidates[0].name if candidates else None


_OUTDIR_RE = re.compile(
    r"(^\s*outdir\s*=\s*)['\"][^'\"]*['\"]",
    re.IGNORECASE | re.MULTILINE,
)
_PSEUDO_DIR_RE = re.compile(
    r"(^\s*pseudo_dir\s*=\s*)['\"][^'\"]*['\"]",
    re.IGNORECASE | re.MULTILINE,
)


def _resolve_pseudo_dir_for_template(mat_dir: Optional[Path]) -> Path:
    """Chemin absolu vers le dossier de pseudopotentiels à utiliser.

    Ordre de priorité :
      1. ``cfg.PSEUDOS_DIR`` (bibliothèque principale, ex. PBE PSlibrary),
      2. ``<thermo_pw_root>/pseudos/PBE`` (repli historique pour BaTiO3 etc.),
      3. ``./pseudos`` à côté du template ``.in`` (cas packaging local).
    Si aucun n'existe, retourne le premier ; le SCF échouera avec un message
    clair côté ``pw.x`` (readpp). Le chemin retourné est supposé POSIX (pas
    d'apostrophe) — c'est une hypothèse raisonnable pour les installations
    standards et conforme à la namelist Fortran.
    """
    candidates: list[Path] = []
    try:
        candidates.append(cfg.PSEUDOS_DIR.resolve())
    except OSError:
        pass
    try:
        repo_pbe = (cfg.THERMO_REPO_ROOT / "pseudos" / "PBE").resolve()
        candidates.append(repo_pbe)
    except OSError:
        pass
    if mat_dir is not None:
        try:
            sib = (mat_dir / "pseudos").resolve()
            if sib.is_dir():
                candidates.append(sib)
        except OSError:
            pass
    for c in candidates:
        try:
            if c.is_dir():
                return c
        except OSError:
            continue
    return candidates[0] if candidates else cfg.PSEUDOS_DIR


def _normalize_scf_paths(work_dir: Path, scf_path: Path) -> bool:
    """Normalise ``outdir`` et ``pseudo_dir`` du template scf.in :
      * ``outdir`` → ``'./out/'`` (1 niveau sous work_dir, toujours créable)
      * ``pseudo_dir`` → chemin ABSOLU vers la biblio de pseudos.

    Les templates ``inputs/<mat>/<scf>.in`` utilisent souvent :
      * ``outdir = './work/Si/'`` → ``pw.x`` échoue avec ``check_tempdir``
        si work_dir est arbitraire (parent n'existe pas).
      * ``pseudo_dir = './pseudos/PBE/'`` → échec dès que work_dir ne descend
        pas de thermo_pw (ex. BaTiO3 avec chemin relatif).

    La normalisation :
      * préserve le ``prefix`` du template (les fichiers WaveFunctions
        atterrissent dans ``<work_dir>/out/<prefix>.save/``), et
      * ne casse pas les profils P2+ (chemin ``out`` déjà relatif), et
      * garantit que ``pseudo_dir`` est absolu et pointe vers la vraie
        biblio de pseudos (cfg.PSEUDOS_DIR ou équivalent).
    """
    try:
        text = scf_path.read_text(encoding="utf-8")
    except OSError:
        return False
    original = text

    # -- outdir : ./out/ (relatif, 1 niveau sous work_dir) --
    text = _OUTDIR_RE.sub(r"\1'./out/'", text)

    # -- pseudo_dir : chemin absolu vers la biblio de pseudos --
    pseudo_abs = _resolve_pseudo_dir_for_template(scf_path.parent)
    abs_str = str(pseudo_abs).rstrip("/") + "/"
    # Échapper les apostrophes éventuelles dans le chemin (cas exotiques).
    escaped = abs_str.replace("\\", "\\\\").replace("'", "\\'")
    text = _PSEUDO_DIR_RE.sub(rf"\1'{escaped}'", text)

    if text == original:
        return False
    scf_path.write_text(text, encoding="utf-8")
    # Pré-création défensive du dossier out (pw.x le fera aussi, mais
    # diagnostics Tier-1 plus propres).
    try:
        (work_dir / "out").mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return True


# Rétro-compat : l'ancien nom ``_normalize_scf_outdir`` reste exposé pour
# d'éventuels imports directs (test, scripts externes).
_normalize_scf_outdir = _normalize_scf_paths


def _inject_lcalc_to_scf(scf_path: Path) -> bool:
    """NO-OP historique (juin 2026) — voir ``electronic_props.inject_lcalc_quantities``.

    Anciennement, ajoutait ``lcalc_bands = .true.`` et ``lcalc_dos = .true.`` à
    ``&CONTROL`` du SCF racine (intégration QE native — preview bandes+DOS
    pendant le SCF, « inconditionnel P1-P5 » juin 2026). L'injection a été
    désactivée car **pw.x 7.5 ne reconnaît PAS ces deux flags dans ``&CONTROL``**
    (cf. grammaire ``read_namelists`` et INPUT_PW.html : ``&CONTROL`` accepte
    seulement ``calculation``, ``restart_mode``, ``wf_collect``, ``prefix``,
    ``outdir``, ``pseudo_dir``, ``verbosity``, ``nstep``, etc.). Le wrapper
    appelle ``inject_lcalc_quantities`` (aujourd'hui no-op strict) et retourne
    donc toujours ``False`` depuis cette révision.

    La DOS/bandes sont prises en charge **correctement** par la chaîne dédiée
    ``run_electronic_properties`` (ichamp=2 ou 3 selon profil) qui lance
    NSCF ``restart_mode='restart'`` + ``dos.x`` + ``bands.x`` **sans toucher
    au SCF équilibre**.

    Conservé pour rétro-compatibilité (callers ``PipelineJob._execute`` et
    ``_run_phonon_chain``, tests unitaires, scripts externes).

    Retourne ``False`` (toujours) depuis juin 2026.
    """
    try:
        text = scf_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    new_text = inject_lcalc_quantities(text)
    if new_text == text:
        return False
    try:
        scf_path.write_text(new_text, encoding="utf-8")
        return True
    except OSError:
        return False



# ----------------------------------------------------------------------------
# État du job + état-machine persistante
# ----------------------------------------------------------------------------


class PipelineJob:
    """Représente un job en cours d'exécution (1 par appel à `run_pipeline`)."""

    _REGISTRY: dict[str, "PipelineJob"] = {}
    _REGISTRY_LOCK = threading.RLock()
    _MAX_JOBS_KEPT = 100  # éviction FIFO des jobs terminés les plus anciens

    @classmethod
    def _register(cls, job: "PipelineJob") -> None:
        with cls._REGISTRY_LOCK:
            cls._REGISTRY[job.job_id] = job
            # Éviction : on garde au maximum _MAX_JOBS_KEPT jobs terminés.
            finished = [
                j for j in cls._REGISTRY.values() if j.status in ("done", "error", "cancelled", "interrupted")
            ]
            finished.sort(key=lambda j: j.finished_at or j.created_at or "")
            while len(finished) > cls._MAX_JOBS_KEPT:
                oldest = finished.pop(0)
                cls._REGISTRY.pop(oldest.job_id, None)

    def __init__(
        self,
        *,
        material_id: str,
        profile_id: str,
        scf_in_basename: str,
        nproc: int,
        user_work_dir: Optional[str] = None,
        properties_enabled: Optional[bool] = None,
        properties_ichamp: Optional[int] = None,
        needs_optical: Optional[bool] = None,  # juin 2026 — opt-in P5 TDDFPT
        extra_whats: Optional[list[str]] = None,
        lo_to_opt_in: Optional[bool] = None,  # juillet 2026 — opt-in P1 LO/TO production
        p1_full_preset: Optional[bool] = None,  # juillet 2026 — preset « P1 complet »
    ):
        self.job_id = uuid.uuid4().hex[:12]
        self.material_id = material_id
        self.profile_id = profile_id
        self.profile = get_profile(profile_id)
        self.scf_in_basename = scf_in_basename
        self.nproc = max(1, int(nproc))
        self.user_work_dir = user_work_dir
        # =====================================================================
        # Early initializations (juillet 2026) — placés AVANT tout override
        # (_append_log y est appelé en cas de warning, ex. p1_full_preset sur
        # profil non-P1). Doit exister avant les blocs qui peuvent logger.
        # =====================================================================
        self.logs: list[str] = []  # early
        self.work_dir: Optional[Path] = None  # early (persist() y accéde via _append_log)
        self._thread: Optional[threading.Thread] = None
        # =====================================================================
        # ``extra_whats`` (juin 2026 — extension P5 « Optique exhaustive »).
        # Liste de ``what=`` thermo_pw complémentaires (optionnels) à exécuter
        # après la chaîne optique principale. Validation via le catalogue :
        # * Valeurs absentes du catalogue → filtrées silencieusement.
        # * Doublons → dédupliqués en préservant l'ordre.
        # * Valeur par défaut = ``profile['default_extra_whats']`` (P5: plot_bz).
        # =====================================================================
        raw_extras = (
            list(extra_whats)
            if extra_whats is not None
            else list(self.profile.get("default_extra_whats") or [])
        )
        self.extra_whats: list[str] = expand_extra_whats(raw_extras)
        # Overrides facultatifs par job (post-Round 2) — prennent le pas sur
        # les valeurs par défaut du profil (PROFILES[id]['properties_*'])
        # quand l'appelant les fournit via /api/pipeline/run.
        if properties_enabled is not None:
            self.profile = {**self.profile, "properties_enabled": bool(properties_enabled)}
        if properties_ichamp is not None:
            try:
                iv = int(properties_ichamp)
                if iv in (2, 3):
                    self.profile = {**self.profile, "properties_ichamp": iv}
            except (TypeError, ValueError):
                pass
        # -----------------------------------------------------------------
        # ``needs_optical`` override (juin 2026 — P5 opt-in checkbox ε(ω)).
        # Si l'appelant POSTE ``needs_optical=True`` via ``/api/pipeline/run``,
        # on active la chaîne exhaustive epsilon.x + turbo_lanczos +
        # turbo_davidson par-dessus la chaîne ``what='dielectric'`` par défaut.
        # Sémantique :  - True  → P5 exhaustive (les deux chaînes tournent)
        #               - False ou non fourni → P5 minimal (what='dielectric' seul)
        # -----------------------------------------------------------------
        if needs_optical is not None and bool(self.profile.get("needs_optical_overridable")):
            self.profile = {**self.profile, "needs_optical": bool(needs_optical)}
        # -----------------------------------------------------------------
        # ``lo_to_opt_in`` (juillet 2026 — opt-in P1 LO/TO production).
        # Stocké sur l'instance et consommé par ``_execute`` (étape 6e,
        # ``_run_lo_to_correction``). Refusé (warning + False) si le profil
        # ne le supporte pas (``lo_to_supported`` absent/False).
        # -----------------------------------------------------------------
        self.lo_to_opt_in: bool = False
        if lo_to_opt_in is True:
            if bool(self.profile.get("lo_to_supported")):
                self.lo_to_opt_in = True
            else:
                self._append_log(
                    f"⚠️ [lo_to_opt_in] ignoré sur le profil {self.profile_id!r} : "
                    "chaîne LO/TO non supportée (lo_to_supported=False)."
                )
        # =====================================================================
        # ``p1_full_preset`` (juillet 2026 — preset « P1 complet »).
        # Active simultanément ``properties_enabled=True`` + ``properties_ichamp=3``
        # sur le profil P1 (Mécanique 0 K), ce qui déclenche la chaîne
        # ``run_electronic_properties`` (NSCF + dos.x + bands.x) en plus du
        # bloc thermo_pw.x shorthand (C_ij).  Force également ``thermo_opts
        # ['ltherm_dos']=False`` pour rester cohérent avec T=0 K (P1 n'a pas
        # de chaîne phonon — ltherm_dos=True ferait crasher le thermo_pw.x).
        #
        # Sémantique stricte :
        #   * ``p1_full_preset=True``  + ``profile_id='P1'`` → override idempotent ; OK.
        #   * ``p1_full_preset=True``  + autre profil         → no-op + log warning.
        #   * ``p1_full_preset=False|None`` + n'importe quel profil → no-op.
        #   * Le défaut ``None`` préserve strictement la sémantique P1 actuelle
        #     (qui a déjà ``properties_enabled=True`` + ``properties_ichamp=3``
        #     via ``_PROFILE_PROPERTIES``).
        # =====================================================================
        self.p1_full_preset: Optional[bool] = p1_full_preset
        self.profile = _apply_p1_full_preset(
            self.profile, self.profile_id, self.p1_full_preset, log=self._append_log
        )
        self.status = "queued"
        self.message = "En file d'attente"
        self.steps: list[dict[str, Any]] = []
        self.results: dict[str, Any] = {}
        self.cancel_event = threading.Event()
        # Reprise partielle thermo_pw (août 2026) — voir request_resume_thermo_pw.
        self._resume_scope: Optional[str] = None
        self._resume_thermo_overrides: dict[str, Any] = {}
        # ``proc_holder`` — registre des sous-process MPI en vol pour ce job.
        # Alimenté par ``qe_subprocess._wait_mpi_process`` et vidé à la sortie
        # de chaque process. Indispensable pour que Pause/Stop/Annuler tuent
        # réellement les rangs MPI : ``cancel_event`` seul n'est lu que par la
        # boucle d'attente courante et laisse les autres pw.x en orphelins.
        self.proc_holder: dict[str, Any] = {
            "lock": threading.Lock(),
            "active": set(),
        }
        # =====================================================================
        # ``interrupt_intent`` (juillet 2026) — qualifie le motif d'arrêt
        # déclenché ``cancel_event.set()`` :
        #   * None            → annulation "Annuler" (status -> cancelled)
        #   * "pause"         → "Pause" (status -> paused, reprenable)
        #   * "stop"          → "Stop"   (status -> stopped, NON reprenable)
        # Le runner ``_execute`` lit ``interrupt_intent`` dans son ``except``
        # pour basculer le statut final sur la bonne branche. Le défaut ``None``
        # conserve la sémantique Annuler historique (rétro-compat).
        # =====================================================================
        self.interrupt_intent: Optional[str] = None
        self.work_dir: Optional[Path] = None
        self.created_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
        self.finished_at: Optional[str] = None
        self._init_runtime_estimate_state()
        self._thread: Optional[threading.Thread] = None
        PipelineJob._register(self)

    # -- Setters thread-safe (utilisés hors du thread d'exécution) ----
    def _set(self, status: str | None = None, message: str | None = None):
        if status:
            self.status = status
        if message is not None:
            self.message = message

    # -- Reprise après coupure -----------------------------------------------------
    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "PipelineJob":
        """Restitue un job depuis le marker disque (reprise après coupure/redémarrage).

        Important : un job sérialisé sur disque avec ``status`` ``running`` ou
        ``queued`` correspond forcément à un worker qui n'existe plus (le
        thread a été tué quand le serveur / API a redémarré). On force donc
        ``interrupted`` pour éviter les « zombies » affichés actifs alors
        qu'aucun calcul n'est en cours. L'utilisateur peut ensuite relancer
        proprement via /api/pipeline/run.
        """
        obj = cls.__new__(cls)
        obj.job_id = d["job_id"]
        obj.material_id = d.get("material_id", "")
        obj.profile_id = d.get("profile_id", "")
        obj.profile = PROFILES.get(obj.profile_id, PROFILES["P2"])
        obj.scf_in_basename = d.get("scf_in_basename", "")
        obj.nproc = int(d.get("nproc", cfg.MPI_NPROC))
        obj.user_work_dir = d.get("user_work_dir")
        # Re-hydratation ``extra_whats`` (juin 2026, P5 extension). On
        # normalise via le catalogue pour rester cohérent même si la
        # whitelist a changé depuis l'écriture du marker disque.
        from thermo_what_catalog import expand_extra_whats as _expand_xwhats
        obj.extra_whats = _expand_xwhats(d.get("extra_whats") or [])
        obj.p1_full_preset = d.get("p1_full_preset")  # juillet 2026 — preset P1
        obj.lo_to_opt_in = bool(d.get("lo_to_opt_in") or False)  # juillet 2026 — LO/TO P1
        # ``needs_optical`` effectif (P5 opt-in) : ré-applique l'override sur
        # le profil recopié depuis PROFILES pour que restart conserve la chaîne.
        if d.get("needs_optical") is not None and bool(obj.profile.get("needs_optical_overridable")):
            obj.profile = {**obj.profile, "needs_optical": bool(d.get("needs_optical"))}
        raw_status = str(d.get("status") or "interrupted")
        if raw_status in ("running", "queued", "started"):
            # Le marqueur persiste à travers un redémarrage → plus de thread vivant.
            obj.status = "interrupted"
            obj.message = (
                "Reprise après redémarrage — le worker précédent a été perdu. "
                "Relancez le calcul via /api/pipeline/run pour reprendre."
            )
            # Compléter le journal avec cette info (utile côté UI).
            ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
            obj.logs = list(d.get("logs") or []) + [
                f"[{ts}] Reprise API : statut disque « {raw_status} » → "
                "« interrupted » (worker orphelin)."
            ]
            obj.finished_at = ts
        else:
            obj.status = raw_status
            obj.message = d.get("message", "Reprise après redémarrage — état inconnu.")
            obj.logs = list(d.get("logs") or [])
            obj.finished_at = d.get("finished_at")
        obj.steps = d.get("steps", [])
        obj.results = d.get("results", {})
        obj.cancel_event = threading.Event()
        obj._resume_scope = None
        obj._resume_thermo_overrides = {}
        obj.proc_holder = {"lock": threading.Lock(), "active": set()}
        obj.interrupt_intent = None
        obj.work_dir = None
        obj.created_at = d.get("created_at", "")
        obj._thread = None
        obj._init_runtime_estimate_state()
        # L'estimation sérialisée reste affichable après reprise ; l'objet
        # calculable, lui, sera reconstruit au prochain lancement.
        obj.runtime_estimate = d.get("runtime_estimate") or None
        obj.storage_estimate = d.get("storage_estimate") or None
        PipelineJob._register(obj)
        return obj

    def to_dict(self) -> dict[str, Any]:
        # Catalogue des extras affichés côté UI : exposé tel quel pour que
        # le panneau d'options P5 rende les bonnes cases à cocher. La
        # sérialisation directe préserve toute la métadonnée (tooltip /
        # group / emoji) — voir backend.thermo_what_catalog.WHAT_CATALOG.
        try:
            extras_catalog: list[dict[str, Any]] = []
            if self.profile_id == "P5":
                from thermo_what_catalog import list_all_p5_extras
                extras_catalog = [
                    {
                        "what": e.what,
                        "label": e.label,
                        "tooltip": e.tooltip,
                        "emoji": e.emoji,
                        "group": e.group,
                        "needs_spin_polarized": e.needs_spin_polarized,
                        "needs_insulating": e.needs_insulating,
                        "needs_non_centrosymmetric": e.needs_non_centrosymmetric,
                    }
                    for e in list_all_p5_extras()
                ]
        except Exception:  # noqa: BLE001
            extras_catalog = []
        # ``_live_eta`` peut réviser ``self.runtime_estimate`` (comptes exacts
        # de points k/q lus dans les sorties QE). Il faut donc l'appeler AVANT
        # de lire l'estimation, sinon le payload transporte la version périmée
        # et l'interface reste en retard d'un sondage.
        eta = self._live_eta()
        return {
            "job_id": self.job_id,
            "material_id": self.material_id,
            "profile_id": self.profile_id,
            "profile_name": self.profile["name"],
            "profile_emoji": self.profile["emoji"],
            "profile_what_qe": self.profile.get("what_qe", ""),
            "expected_results": self.profile.get("expected_results", {}),
            "extra_whats": list(getattr(self, "extra_whats", []) or []),
            "extras_catalog": extras_catalog,
            "default_extra_whats": list(
                self.profile.get("default_extra_whats") or []
            ),
            "scf_in_basename": self.scf_in_basename,
            "nproc": self.nproc,
            "user_work_dir": self.user_work_dir,
            "p1_full_preset": getattr(self, "p1_full_preset", None),  # juillet 2026 — preset P1 (reprise safe)
            "lo_to_opt_in": bool(getattr(self, "lo_to_opt_in", False)),  # juillet 2026 — LO/TO P1
            "needs_optical": bool(self.profile.get("needs_optical", False)),  # P5 opt-in effectif
            "work_dir": str(self.work_dir) if self.work_dir else None,
            "status": self.status,
            "message": self.message,
            "steps": self.steps,
            "results": self.results,
            "logs": self.logs[-200:],  # ne pas s'envoler
            "created_at": self.created_at,
            "finished_at": self.finished_at,
            # Estimation de durée (août 2026) : détail par étape + machine.
            "runtime_estimate": getattr(self, "runtime_estimate", None),
            "eta": eta,
            # Espace disque (août 2026) : prévision + occupation réelle.
            "storage_estimate": getattr(self, "storage_estimate", None),
            "disk_usage": self._disk_usage(),
        }

    # -- Persistance disque -----------------------------------------------------
    _MARKER_FILENAME = "pipeline_api_job_state.json"

    def persist(self) -> None:
        """Écrit le marker dans le work_dir (reprise après coupure)."""
        if not self.work_dir:
            return
        try:
            self.work_dir.mkdir(parents=True, exist_ok=True)
            _sanitize_plots_section(self.results)
            (self.work_dir / self._MARKER_FILENAME).write_text(
                json.dumps(self.to_dict(), indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except OSError:
            pass

    # -- Lancement -------------------------------------------------------------
    def start(self):
        if self._thread is not None and self._thread.is_alive():
            return
        self._thread = threading.Thread(
            target=self._execute, name=f"pipeline-{self.job_id[:6]}", daemon=True
        )
        self._thread.start()

    # ------------------------------------------------------------------------
    # Juillet 2026 — Cycle de vie interactif (Pause / Stop / Resume).
    #
    # Sémantique figée par retour UX (juillet 2026) :
    #   - Pause : SIGTERM MPI + exit coopérant + status ``paused`` → REPRENABLE.
    #     Le worker checkpoint le state_db.workflow_state.json (déjà géré par
    #     ``task_optimize`` / ``_run_phonon_chain``). À la reprise, un nouveau
    #     thread re-spawn ``_execute`` qui réutilise ``self.work_dir`` et
    #     saute les sous-étapes déjà marquées ``DONE`` dans le workflow_state.
    #   - Stop  : kill doux plus marqué + status ``stopped``. NON reprenable.
    #     Le work_dir reste sur disque pour inspection. À la reprise on
    #     refuse avec 409 Conflict.
    #   - Cancel historique conservé sous ``interrupt_intent = None`` → status
    #     ``cancelled``. Aussi non reprenable (par défaut).
    #
    # Tous les request_* sont thread-safe (touchent uniquement des attributs +
    # cancel_event). Le runner _execute() détecte l'arrêt *à chaque début de
    # sous-étape* via ``cancel_event.is_set()`` (cf. tests existants) puis
    # lève ``API_CANCEL_RUNTIME_MSG`` côté MPI ; le ``except`` du runner
    # distingue ensuite l'intent pour router vers le bon statut terminal.
    # ------------------------------------------------------------------------
    def kill_active_processes(self) -> int:
        """Tue sans attendre les rangs MPI en vol pour ce job.

        Complète ``cancel_event`` : celui-ci n'est relu qu'entre deux
        itérations de la boucle d'attente du process courant, et un worker qui
        meurt avant (échec, pool démonté) abandonne ses ``pw.x`` en orphelins
        — le calcul continuait alors que l'UI affichait « annulé ».
        """
        n = terminate_registered_processes(getattr(self, "proc_holder", None))
        if n:
            self._append_log(
                f"[STOP] {n} process MPI tué(s) (SIGTERM puis SIGKILL du groupe)."
            )
        return n

    def _raise_if_cancelled(self) -> None:
        """Point d'arrêt coopératif à placer en tête de chaque sous-étape."""
        if self.cancel_event is not None and self.cancel_event.is_set():
            raise RuntimeError(API_CANCEL_RUNTIME_MSG)

    def request_pause(self) -> None:
        """Demande de mise en pause (reprise possible). Idempotent."""
        if self.status not in ("running", "queued"):
            raise RuntimeError(
                f"Seul un job running/queued peut être mis en pause "
                f"(statut actuel : {self.status!r})."
            )
        self.interrupt_intent = "pause"
        self.cancel_event.set()
        self.kill_active_processes()
        # Le statut sera posé à ``paused`` par le runner via ``_execute``.
        # On positionne un message éphémère côté API pour la latence perçue.
        self.message = "Pause demandée — arrêt en cours…"

    def request_stop(self) -> None:
        """Demande d'arrêt définitif (work_dir conservé, non reprenable)."""
        if self.status not in ("running", "queued"):
            raise RuntimeError(
                f"Seul un job running/queued peut être stoppé "
                f"(statut actuel : {self.status!r})."
            )
        self.interrupt_intent = "stop"
        self.cancel_event.set()
        self.kill_active_processes()
        self.message = "Stop demandé — arrêt en cours…"

    def request_resume(self) -> None:
        """Reprise d'un job en ``paused``. Vérifie le disque + state_db.

        Conditions de reprise (toutes obligatoires) :
          * ``self.status == "paused"`` (le job a bien été mis en pause).
          * ``self.work_dir`` existe et est un répertoire (le dossier de
            résultats n'a pas été supprimé manuellement entre-temps).
          * Au moins un fichier ``pipeline_api_job_state.json`` est lisible
            dans le work_dir (sinon le state_db de reprise est manquant).
        """
        if self.status != "paused":
            raise RuntimeError(
                f"Seul un job en pause peut être repris "
                f"(statut actuel : {self.status!r})."
            )
        if not self.work_dir or not Path(self.work_dir).is_dir():
            raise FileNotFoundError(
                f"work_dir absent du disque — reprise impossible : "
                f"{self.work_dir}"
            )
        marker = Path(self.work_dir) / self._MARKER_FILENAME
        if not marker.is_file():
            raise FileNotFoundError(
                f"Marker de reprise manquant : {marker}. Le run a peut-être "
                "été effacé manuellement. Relancez un nouveau calcul."
            )
        # Réinitialiser l'état du worker pour la reprise :
        #   * cancel_event.clear() — autoriser le runner à reprendre.
        #   * interrupt_intent = None — distingue la reprise d'un cancel.
        #   * user_work_dir = work_dir — _execute() réutilise ce dossier
        #     (sinon il en crée un neuf).
        #   * finished_at = None — la fin n'a pas eu lieu.
        self.cancel_event.clear()
        self.interrupt_intent = None
        self.user_work_dir = str(self.work_dir)
        self.finished_at = None
        # Restaurer le statut ``running`` côté UI ; le runner le confirmera
        # (ou le rebascule sur ``paused`` / ``error`` selon le sort MPI).
        self._set(status="running", message="Reprise du calcul…")
        self._append_log(
            "[Reprise] Restart du runner sur le même work_dir ; "
            "les sous-étapes ``DONE`` dans workflow_state.json seront sautées."
        )
        self.persist()
        self.start()

    def request_restart(self) -> None:
        """Restart d'un job en ``interrupted``/``error``/``cancelled`` (reprise
        INTELLIGENTE). Différent de ``request_resume`` (qui vise ``paused``) :
        on accepte les statuts terminaux KO où le worker a disparu mais où
        le work_dir et le workflow_state.json sont intacts.

        Comportement :
          * Le pipeline ``_execute`` est re-spawn sur le même work_dir.
          * Les sous-étapes marquées ``DONE`` dans workflow_state.json sont
            sautées automatiquement (cf. ``task_optimize`` et
            ``_run_phonon_chain`` qui lisent ce fichier).
          * Les résultats partiels sur disque sont conservés (``eos``,
            ``scf_phonon``, ``ph``, ``q2r``, ``matdyn`` selon le profil).

        Conditions de restart (toutes obligatoires) :
          * ``self.status in {"interrupted", "error", "cancelled"}``.
          * ``self.work_dir`` existe et est un répertoire.
          * Au moins un fichier ``pipeline_api_job_state.json`` est lisible
            dans le work_dir (sinon le state_db de reprise est manquant).

        Diff vs ``request_resume`` :
          * ``paused`` est traité par ``request_resume`` (cycle Pause/Resume).
          * ``interrupted/error/cancelled`` est traité par ``request_restart``
            (cas typique : serveur API redémarré, calcul à moitié fini, ou
            crash MPI non récupérable).
        """
        if self.status not in ("interrupted", "error", "cancelled"):
            raise RuntimeError(
                f"Restart impossible depuis le statut {self.status!r}. "
                "Utilisez « Reprendre » pour un job paused, ou lancez un "
                "nouveau calcul via « Lancer la série de calculs »."
            )
        if not self.work_dir or not Path(self.work_dir).is_dir():
            raise FileNotFoundError(
                f"work_dir absent du disque — restart impossible : "
                f"{self.work_dir}"
            )
        marker = Path(self.work_dir) / self._MARKER_FILENAME
        if not marker.is_file():
            raise FileNotFoundError(
                f"Marker de reprise manquant : {marker}. Le run a peut-être "
                "été effacé manuellement. Relancez un nouveau calcul."
            )
        # Réinitialiser l'état du worker pour le restart intelligent :
        #   * cancel_event.clear() — autoriser le runner à reprendre.
        #   * interrupt_intent = None — distingue le restart d'un cancel.
        #   * user_work_dir = work_dir — _execute() réutilise ce dossier
        #     (sinon il en crée un neuf et repart de zéro).
        #   * finished_at = None — la fin n'a pas eu lieu pour ce restart.
        self.cancel_event.clear()
        self.interrupt_intent = None
        self.user_work_dir = str(self.work_dir)
        self.finished_at = None
        # Restaurer le statut ``running`` côté UI ; le runner le confirmera
        # (ou rebascule sur ``error`` selon le sort MPI).
        self._set(
            status="running",
            message="Restart : reprise intelligente (étapes DONE sautées)…",
        )
        self._append_log(
            "[Restart] Relance du runner sur le même work_dir ; "
            "les sous-étapes ``DONE`` dans workflow_state.json seront sautées."
        )
        self.persist()
        self.start()

    def request_resume_thermo_pw(
        self,
        target: str = "thermo_main",
        *,
        thermo_overrides: Optional[dict[str, Any]] = None,
    ) -> None:
        """Reprend **uniquement** ``thermo_pw`` (et aval) sans refaire EOS / phonons.

        ``target`` :
          * ``thermo_main`` — P1–P5 : relance le ``what=`` principal du profil.
          * ``thermo_extra:<what>`` — P5 : un extra coché.
          * ``optical`` — P5 : chaîne epsilon/turbo seulement.
          * ``lo_to`` — P1 opt-in : chaîne LO/TO seulement.
        """
        if self.status not in ("interrupted", "error", "cancelled", "paused"):
            raise RuntimeError(
                f"Reprise thermo_pw impossible depuis le statut {self.status!r}. "
                "Utilisez « Relancer » pour un redémarrage complet du pipeline."
            )
        if not self.work_dir or not Path(self.work_dir).is_dir():
            raise FileNotFoundError(
                f"work_dir absent du disque — reprise impossible : {self.work_dir}"
            )
        marker = Path(self.work_dir) / self._MARKER_FILENAME
        if not marker.is_file():
            raise FileNotFoundError(
                f"Marker de reprise manquant : {marker}."
            )
        thermo_pw_resume.validate_target_for_profile(
            self.profile_id,
            target,
            extra_whats=list(getattr(self, "extra_whats", []) or []),
            needs_optical=bool(self.profile.get("needs_optical")),
            lo_to_opt_in=bool(getattr(self, "lo_to_opt_in", False)),
        )
        allowed = {
            t.target_id
            for t in thermo_pw_resume.list_resume_targets(
                profile_id=self.profile_id,
                work_dir=Path(self.work_dir),
                extra_whats=list(getattr(self, "extra_whats", []) or []),
                needs_optical=bool(self.profile.get("needs_optical")),
                lo_to_opt_in=bool(getattr(self, "lo_to_opt_in", False)),
                results=self.results,
            )
        }
        if target not in allowed:
            raise ValueError(
                f"Cible {target!r} indisponible pour le profil {self.profile_id} "
                f"(choix : {', '.join(sorted(allowed))})."
            )
        ok, msg = thermo_pw_resume.phonon_prereqs_ok(Path(self.work_dir))
        if not ok and self.profile.get("needs_phonons") and target != "lo_to":
            raise RuntimeError(msg)
        overrides = dict(thermo_overrides or {})
        self._resume_scope = target
        self._resume_thermo_overrides = overrides
        self.cancel_event.clear()
        self.interrupt_intent = None
        self.user_work_dir = str(self.work_dir)
        self.finished_at = None
        self._set(
            status="running",
            message=f"Reprise thermo_pw ({target}) — EOS/phonons conservés…",
        )
        self._append_log(
            f"[Reprise thermo_pw] Cible={target!r} — EOS et phonons ne seront "
            "pas relancés ; nettoyage de l'état partiel avant thermo_pw.x."
        )
        if overrides:
            parts = []
            if "lsolve" in overrides:
                parts.append(f"lsolve={overrides['lsolve']}")
            if "deltat" in overrides:
                parts.append(f"deltat={overrides['deltat']} K")
            if overrides.get("ltherm_freq"):
                parts.append("ltherm_freq=.true.")
            elif overrides.get("ltherm_dos") is False:
                parts.append("ltherm_dos=.false.")
            elif overrides.get("ltherm_dos"):
                parts.append("ltherm_dos=.true.")
            if parts:
                self._append_log(
                    "[Reprise thermo_pw] Overrides thermo_control : "
                    + ", ".join(parts)
                )
        self.persist()
        self.start()

    # Période minimale entre deux recalculs d'ETA (lecture de ph.out).
    _ETA_TTL_S = 15.0
    # Idem pour le parcours du work_dir, bien plus coûteux (milliers de fichiers).
    _DISK_TTL_S = 60.0

    def _init_runtime_estimate_state(self) -> None:
        """Attributs de l'estimation de durée (partagés __init__ / from_dict)."""
        self._step_started_at: dict[str, datetime] = {}
        self._estimate_obj = None
        self.runtime_estimate: Optional[dict[str, Any]] = None
        self._eta_cache: Optional[dict[str, Any]] = None
        self._eta_cache_at: float = 0.0
        self._estimate_refined: bool = False
        self.storage_estimate: Optional[dict[str, Any]] = None
        self._disk_cache: Optional[dict[str, Any]] = None
        self._disk_cache_at: float = 0.0

    # -- Helpers internes ------------------------------------------------------
    def _emit_step(self, name: str, status: str, detail: str = ""):
        """Journalise une transition d'étape, horodatée et chronométrée.

        L'horodatage sert deux usages : afficher la durée réelle de chaque
        étape dans l'interface, et alimenter le magasin de calibration de
        ``runtime_estimate`` pour que les estimations s'affinent d'un calcul au
        suivant sur cette machine.
        """
        now = datetime.now(timezone.utc)
        entry: dict[str, Any] = {
            "name": name,
            "status": status,
            "detail": detail,
            "at": now.isoformat(timespec="seconds"),
        }
        if status == "running":
            self._step_started_at[name] = now
        else:
            started = self._step_started_at.pop(name, None)
            if started is not None:
                duration = (now - started).total_seconds()
                entry["duration_s"] = round(duration, 1)
                entry["duration_human"] = humanize_seconds(duration)
                if status == "done":
                    self._record_step_duration(name, duration)
        self.steps.append(entry)
        self.persist()

    def _record_step_duration(self, name: str, duration_s: float) -> None:
        """Verse une durée réelle dans le magasin de calibration.

        On ne peut normaliser la mesure qu'avec les mêmes ``units`` et le même
        débit que ceux utilisés pour l'estimer : on les relit donc sur
        l'estimation du job plutôt que de les recalculer, sinon la grille EOS
        (volumes concurrents) serait enregistrée avec un débit erroné.
        """
        est = getattr(self, "_estimate_obj", None)
        if est is None:
            return
        step_est = est.step_by_name(name)
        if step_est is None:
            return
        try:
            record_step_measurement(
                step=name,
                cost_key=step_est.cost_key,
                wall_seconds=duration_s,
                units=step_est.units,
                work_scf=est.work_scf,
                throughput=step_est.throughput,
                profile_id=self.profile_id,
                material_id=self.material_id,
            )
        except Exception as ex:  # noqa: BLE001
            # La calibration est un bonus : elle ne doit jamais faire échouer
            # un calcul qui vient d'aboutir.
            self._append_log(f"calibration durée ({name}) : {ex} (ignoré).")

    # -- Estimation de durée ---------------------------------------------------
    def _compute_runtime_estimate(self, wd: Optional[Path] = None) -> None:
        """(Re)calcule l'estimation de durée pour ce job.

        Appelée une première fois dès que ``scf.in`` est en place, puis à
        nouveau après le démarrage de ph.x : le nombre exact de points q
        irréductibles n'est connu qu'à ce moment-là, et il pilote l'étape
        dominante du calcul.
        """
        try:
            wd = wd or self.work_dir
            desc = parse_material_descriptors(
                work_dir=wd, material_id=self.material_id
            )
            est = estimate_runtime(
                profile_id=self.profile_id,
                profile=self.profile,
                descriptors=desc,
                machine=detect_machine(),
                nproc=self.nproc,
                extra_whats=list(getattr(self, "extra_whats", []) or []),
                lo_to_opt_in=bool(getattr(self, "lo_to_opt_in", False)),
            )
            self._estimate_obj = est
            self.runtime_estimate = est.to_dict()
        except Exception as ex:  # noqa: BLE001
            self._append_log(f"estimation de durée indisponible : {ex} (ignoré).")

    def _compute_storage_estimate(self, wd: Optional[Path] = None) -> None:
        """(Re)calcule l'estimation d'espace disque pour ce job.

        Les descripteurs de maille viennent de ``scf.in``, complétés par la
        valence lue dans les UPF ; si une sortie pw.x existe déjà, ses valeurs
        exactes (volume, bandes, vecteurs G, dimensions FFT) prennent le pas.
        """
        try:
            wd = wd or self.work_dir
            if wd is None:
                return
            desc = parse_material_descriptors(work_dir=wd, material_id=self.material_id)
            scf = None
            for name in ("pw_scf_V0_for_phonon.in", "scf.in"):
                cand = Path(wd) / name
                if cand.is_file():
                    scf = cand
                    break
            text = scf.read_text(encoding="utf-8", errors="replace") if scf else ""
            facts = derive_cell_facts(
                text, desc, pseudo_dirs=[Path(cfg.PSEUDOS_DIR)]
            )
            for out_name in ("pw_scf_V0_for_phonon.out", "scf.out", "nscf.out"):
                out = Path(wd) / out_name
                if out.is_file():
                    facts = read_exact_cell_facts(out, facts)
                    break
            self.storage_estimate = estimate_storage(
                profile_id=self.profile_id,
                profile=self.profile,
                descriptors=desc,
                cell_facts=facts,
                disk_path=Path(wd),
            ).to_dict()
        except Exception as ex:  # noqa: BLE001
            self._append_log(f"estimation disque indisponible : {ex} (ignoré).")

    def _disk_usage(self) -> Optional[dict[str, Any]]:
        """Occupation disque réelle du work_dir, mise en cache.

        Le cache est indispensable : ``_ph0`` compte des milliers de fichiers et
        ``to_dict()`` est appelé à chaque ligne de journal.
        """
        if not self.work_dir:
            return getattr(self, "_disk_cache", None)
        now = time.time()
        if now - getattr(self, "_disk_cache_at", 0.0) < self._DISK_TTL_S:
            return getattr(self, "_disk_cache", None)
        self._disk_cache_at = now
        try:
            self._disk_cache = measure_dir_size(self.work_dir)
        except Exception:  # noqa: BLE001
            pass
        return self._disk_cache

    def _live_eta(self) -> Optional[dict[str, Any]]:
        """ETA courant, recalculé au plus toutes les ``_ETA_TTL_S`` secondes.

        Le cache est nécessaire : ``persist()`` appelle ``to_dict()`` à chaque
        ligne de journal, et relire un ``ph.out`` de plusieurs mégaoctets à
        cette fréquence coûterait plus cher que le calcul lui-même.
        """
        est = getattr(self, "_estimate_obj", None)
        if est is None or self.status != "running" or not self.work_dir:
            return getattr(self, "_eta_cache", None)
        now = time.time()
        if now - getattr(self, "_eta_cache_at", 0.0) < self._ETA_TTL_S:
            return getattr(self, "_eta_cache", None)

        # Affinage unique : les sorties QE livrent désormais les comptes exacts
        # de points k et q, là où l'estimation initiale les déduisait de la
        # symétrie. Comme ph.x pèse l'essentiel du calcul, ce recalcul corrige
        # souvent le total de façon significative.
        if not getattr(self, "_estimate_refined", False):
            src = (est.descriptors or {}).get("nq_source", "")
            if str(src).startswith("estimé") and (self.work_dir / "ph.out").is_file():
                # Ces deux marqueurs sont posés AVANT le recalcul : celui-ci
                # journalise, donc déclenche persist() → to_dict() → _live_eta(),
                # et sans eux la réentrance repartirait dans le même bloc.
                self._estimate_refined = True
                self._eta_cache_at = now
                self._compute_runtime_estimate()
                # Les sorties pw.x donnent aussi volume, bandes, vecteurs G et
                # dimensions FFT exacts : l'estimation disque y gagne autant.
                self._compute_storage_estimate()
                est = getattr(self, "_estimate_obj", None) or est
                self._append_log(
                    "Estimation de durée affinée avec les comptes exacts de "
                    f"points k/q lus dans les sorties QE : "
                    f"{est.to_dict()['total_human']} au total."
                )

        done: set[str] = set()
        current: Optional[str] = None
        current_started: Optional[datetime] = None
        for s in self.steps:
            nm = str(s.get("name") or "")
            if s.get("status") == "done":
                done.add(nm)
            elif s.get("status") == "running":
                current = nm
                # Début de l'étape courante : nécessaire pour dater la
                # première géométrie de la boucle QHA (thermo_pw).
                try:
                    current_started = datetime.fromisoformat(
                        str(s.get("at") or "")
                    )
                except ValueError:
                    current_started = None
        try:
            eta = live_eta(
                work_dir=self.work_dir,
                estimate=est,
                steps_done=done,
                current_step=current,
                current_step_started_at=current_started,
            )
        except Exception:  # noqa: BLE001
            return getattr(self, "_eta_cache", None)
        self._eta_cache = eta
        self._eta_cache_at = now
        return eta

    def _append_log(self, line: str):
        ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
        self.logs.append(f"[{ts}] {line}")
        self.persist()

    def _read_tail_log(self, path: Path, max_kb: int = 12) -> str:
        """Lit la fin d'un fichier `.out` sans saturer l'API (max ~12 Ko)."""
        try:
            raw = path.read_bytes()
            if len(raw) > max_kb * 1024:
                raw = b"... [debut tronque] ...\n" + raw[-max_kb * 1024 :]
            return raw.decode("utf-8", errors="replace")
        except OSError as e:
            return f"(lecture impossible : {e})"

    # -- Pré-population des résultats attendus ---------------------------------
    def _init_results_for_profile(self) -> None:
        """Pré-remplit self.results avec des None à chaque clé attendue du profil.

        Permet au front-end de montrer un aperçu (preview) immédiatement
        après la sélection du profil et de révéler les valeurs en temps réel
        lors du polling, sans attendre la fin du job.
        Idempotent : ne ré-écrase JAMAIS une valeur déjà définie (évite le
        flicker si une étape a déjà posé une donnée).
        """
        expected = self.profile.get("expected_results") or {}
        for m in expected.get("metrics") or []:
            key = m.get("key")
            if not key:
                continue
            _nest_set_default(self.results, key, None)
        for p in expected.get("plots") or []:
            key = p.get("key")
            if not key:
                continue
            _nest_set_default(self.results, key, None)

    def _merge_parsed_into_results(self, parsed: dict[str, Any]) -> None:
        """Merge prudent du résultat de parse_thermo_pw_log dans self.results.

        Règles :
        - Ne remplace JAMAIS une valeur existante et non-None (anti-flicker).
        - EOS : V0_bohr3, B0_GPa, B0prime, E0_Ry → self.results["eos"][..].
        - Thermo : debye_temperature_K, zero_point_energy_Ry → self.results["thermo"][..].
        - Elastic (C_ij) : première ligne de elastic_constants_GPa → C11/C12/C44_GPa.
        - Modules polycristallins (B/G/E/ν) → self.results["elastic"][..].
        - LIF : f_iso_Ry → self.results["lif"][..] si détecté.
        """
        if not parsed or not isinstance(parsed, dict):
            return
        # EOS
        eos_section = self.results.setdefault("eos", {})
        for k in ("V0_bohr3", "B0_GPa", "B0prime", "E0_Ry"):
            v = parsed.get(k)
            if v is not None and (eos_section.get(k) is None or eos_section.get(k) is False):
                eos_section[k] = v
        # Thermo
        th = self.results.setdefault("thermo", {})
        for k in ("debye_temperature_K", "zero_point_energy_Ry"):
            v = parsed.get(k)
            if v is not None and th.get(k) is None:
                th[k] = v
        # LIF (P4)
        lif_v = parsed.get("f_iso_Ry") or parsed.get("local_isothermal_free_energy_Ry") \
                or parsed.get("lif_free_energy_Ry")
        if lif_v is not None:
            lif_section = self.results.setdefault("lif", {})
            if lif_section.get("f_iso_Ry") is None:
                lif_section["f_iso_Ry"] = lif_v
            # Courbe F_iso(T) si le parser l'a produite. Pas de plot dédié pour
            # l'instant — on la conserve sous ``self.results["lif"]["F_vs_T_Ry"]``
            # pour exploitation future (UI courbe / export CSV) sans promettre
            # de rendu que le frontend ne sait pas encore afficher.
            lif_curve = parsed.get("lif_F_vs_T_Ry")
            if isinstance(lif_curve, list) and lif_curve and lif_section.get("F_vs_T_Ry") is None:
                lif_section["F_vs_T_Ry"] = lif_curve
        # Elastic (matrice C_ij)
        # Le parser expose trois représentations :
        #   1. `elastic_constants_GPa`  : liste de {i, j, value_GPa} (matrice Voigt 6×6 brute).
        #   2. `elastic_independent_GPa` : {system, constants_Gpa: {C11_GPa, C12_GPa, C44_GPa, ...}}
        #   3. `elastic_cubic_independent_GPa` : {C11_GPa, C12_GPa, C44_GPa} (cas cubique simple).
        # On remplit les clés `elastic.C{11,12,44}_GPa` depuis 2/3 en priorité, puis 1 en repli.
        es = self.results.setdefault("elastic", {})
        # Priorité 1 : `elastic_cubic_independent_GPa` (flat dict).
        cub_indep = parsed.get("elastic_cubic_independent_GPa")
        if isinstance(cub_indep, dict):
            for k in ("C11_GPa", "C12_GPa", "C44_GPa"):
                v = cub_indep.get(k)
                if v is not None and es.get(k) is None:
                    es[k] = v
        # Priorité 2 : `elastic_independent_GPa.constants_Gpa` (dict clef-valeur).
        indep = parsed.get("elastic_independent_GPa")
        if isinstance(indep, dict):
            constants = indep.get("constants_Gpa") or {}
            if isinstance(constants, dict):
                for k in ("C11_GPa", "C12_GPa", "C44_GPa"):
                    v = constants.get(k)
                    if v is not None and es.get(k) is None:
                        es[k] = v
        # Repli : matrix Voigt 6×6 (rows {i, j, value_GPa}).
        ecs_rows = parsed.get("elastic_constants_GPa") or []
        if isinstance(ecs_rows, list) and ecs_rows:
            for row in ecs_rows:
                if not isinstance(row, dict):
                    continue
                try:
                    i, j, v = int(row.get("i")), int(row.get("j")), row.get("value_GPa")
                except (TypeError, ValueError):
                    continue
                if v is None:
                    continue
                if i == 1 and j == 1 and es.get("C11_GPa") is None:
                    es["C11_GPa"] = v
                elif i == 1 and j == 2 and es.get("C12_GPa") is None:
                    es["C12_GPa"] = v
                elif i == 4 and j == 4 and es.get("C44_GPa") is None:
                    es["C44_GPa"] = v
        # Modules polycristallins (string peu importe : "bulk_modulus_GPa", etc.)
        for source_k in (
            "bulk_modulus_GPa",
            "shear_modulus_GPa",
            "young_modulus_GPa",
            "poisson_ratio",
            "bulk_modulus_pressure_derivative",
        ):
            v = parsed.get(source_k)
            if v is None:
                continue
            es = self.results.setdefault("elastic", {})
            if es.get(source_k) is None:
                es[source_k] = v

    def _merge_elastic_dat_into_results(self, merged: dict[str, Any] | None) -> None:
        """Variante utilisée par `merge_elastic_from_output_el_cons_files`."""
        if not merged or not isinstance(merged, dict):
            return
        self._merge_parsed_into_results(merged)

    # -- Parse intermédiaire « live » ------------------------------------------
    def _intermediate_parse(self, wd: Path, step_label: str) -> None:
        """Re-parse les sorties disponible à l'instant T et met à jour
        ``self.results`` + marker disque, **sans** relancer quelque calcul MPI
        que ce soit.

        Conçu pour être appelé après chaque étape lourde (``scf_eq``,
        ``eos_grid``, sous-étape phonon, ``thermo_pw``, puis ``post_process``
        final) : dès que le parsing produit une nouvelle valeur non-None, le
        polling 1.5 s côté front-end l'affiche via ``updateLiveResults`` sans
        qu'il soit nécessaire d'attendre la fin du job.

        Robuste : les opérations I/O sont encadrées de ``try/except``
        pour ne jamais interrompre la chaîne MPI en cours. Les opérations
        purement en mémoire (``_init`` / ``merge`` / ``_append_log``)
        ne sont **pas** protégées : un bug réel doit remonter, pas être
        avalé silencieusement.
        """
        # 1. S'assure que les clés attendues du profil existent (idempotent,
        #    ne ré-écrase rien).
        self._init_results_for_profile()

        # 2. Re-lit la queue de ``thermo_pw_run.out`` (~200 ko max) et merge.
        tpw_out = wd / "thermo_pw_run.out"
        tpw_existed = tpw_out.is_file()
        if tpw_existed:
            try:
                total = tpw_out.stat().st_size
                with tpw_out.open("r", encoding="utf-8", errors="replace") as fh:
                    if total > 200_000:
                        fh.seek(total - 200_000)
                    else:
                        fh.seek(0)
                    tail = fh.read()
                parsed = parse_thermo_pw_log(tail) or {}
                self._merge_parsed_into_results(parsed)
            except (OSError, UnicodeError) as ex:  # noqa: BLE001
                self._append_log(
                    f"[LIVE {step_label}] lecture thermo_pw_run.out : {ex} (ignoré)."
                )

        # 3. Merge des fichiers ``output_el_cons*.dat*`` (utile si thermo_pw
        #    log est tronqué / pas encore écrit). Lecture seule, jamais bloquante.
        try:
            merged_dat = merge_elastic_from_output_el_cons_files(wd)
            self._merge_elastic_dat_into_results(merged_dat)
        except OSError as ex:  # noqa: BLE001
            self._append_log(
                f"[LIVE {step_label}] lecture output_el_cons*.dat* : {ex} (ignoré)."
            )

        # 4. ``eos_summary.json`` (P2/P3/P4) si non encore fusionné.
        if "eos_summary" not in self.results:
            es_json = wd / "1_eos_volumes" / "eos_summary.json"
            try:
                if es_json.is_file():
                    self.results["eos_summary"] = json.loads(
                        es_json.read_text(encoding="utf-8", errors="replace")
                    )
                    # Juillet 2026 (bugfix) - unnest eos_summary.eos
                    # into self.results['eos'] pour UI + factsheet.
                    flatten_eos_summary_into_results(self.results)
                    _backfill_eos_lattice_from_scf_eq(wd, self.results)
            except (OSError, json.JSONDecodeError) as ex:  # noqa: BLE001
                self._append_log(
                    f"[LIVE {step_label}] eos_summary.json : {ex} (ignoré)."
                )

        # 5. === Branchement profil-aware des parsers « résultats » ===========
        # P4 (``what='ph_life'``) → ``parsers.phonon_lifetime.parse_phonon_lifetime``
        # P5 (``what='dielectric'``) → ``parsers.dielectric.parse_dielectric``.
        # Le merge utilise ``_nest_set_default`` sur chaque clé du dict plat
        # retourné, avec le préfixe ``ph_life.`` ou ``dielectric.`` (cf.
        # ``expected_results.metrics`` des profiles P4/P5). ``self.profile_id``
        # est l'identifiant canonique P1..P5 ; le ``live_preview`` côté UI
        # voit les nouvelles clés apparaître dès le 1er poll post-thermo_pw.
        # =====================================================================
        if self.profile_id == "P4":
            try:
                from parsers.phonon_lifetime import parse_phonon_lifetime
                ph = parse_phonon_lifetime(wd)
                for k, v in (ph or {}).items():
                    if k in (
                        "matched_keywords", "modes", "source_files", "n_modes",
                        "temperature_K_for_summary",
                    ):
                        continue
                    if v is None:
                        continue
                    _nest_set_default(self.results, f"ph_life.{k}", v)
                kw = (ph or {}).get("matched_keywords") or []
                if kw:
                    self._append_log(
                        f"[LIVE P4 ph_life] {len(kw)} matched : {kw}"
                    )
                # Stocke aussi les modes tronqués pour exploitation UI (≤30).
                if (ph or {}).get("modes"):
                    _nest_set_default(
                        self.results, "ph_life.modes", (ph or {})["modes"][:30]
                    )
            except Exception as ex:  # noqa: BLE001
                self._append_log(
                    f"[LIVE P4 ph_life] parse_phonon_lifetime : {ex} (ignoré)."
                )
        elif self.profile_id == "P5":
            try:
                from parsers.dielectric import parse_dielectric
                di = parse_dielectric(wd)
                for k, v in (di or {}).items():
                    if k in ("matched_keywords", "source_files"):
                        continue
                    if v in (None, [], {}):
                        continue
                    _nest_set_default(self.results, f"dielectric.{k}", v)
                kw = (di or {}).get("matched_keywords") or []
                if kw:
                    self._append_log(
                        f"[LIVE P5 dielectric] {len(kw)} matched : {kw}"
                    )
                if (di or {}).get("born_Z_star_per_atom"):
                    _nest_set_default(
                        self.results,
                        "dielectric.born_Z_star_per_atom",
                        (di or {})["born_Z_star_per_atom"],
                    )
                    _nest_set_default(
                        self.results,
                        "dielectric.born_Z_star_n_atoms",
                        len((di or {})["born_Z_star_per_atom"]),
                    )
            except Exception as ex:  # noqa: BLE001
                self._append_log(
                    f"[LIVE P5 dielectric] parse_dielectric : {ex} (ignoré)."
                )

        # 5b. === Juillet 2026 — thermodynamique QHA (therm_files/output_therm.dat*) ==
        # ZPE, Cv(300 K), F(300 K), S(300 K) : promis par les storage_hints
        # P2/P4 mais jamais parsés auparavant (le journal thermo_pw ne les
        # imprime pas — ils vivent dans les fichiers colonnes therm_files/).
        # No-op silencieux si les fichiers n'existent pas (P1/P5).
        is_reparse = step_label.startswith("reparse")
        _nest_thermo = _nest_set_force if is_reparse else _nest_set_default
        try:
            from parsers.thermo_pw_out_tables import merge_thermo_curves
            tmerged = merge_thermo_curves(wd, self.results)
            for k, v in (tmerged or {}).items():
                if v is None or v == []:
                    continue
                _nest_thermo(self.results, f"thermo.{k}", v)
        except Exception as ex:  # noqa: BLE001
            self._append_log(
                f"[LIVE thermo] merge_thermo_curves : {ex} (ignoré)."
            )
        try:
            from parsers.thermo_therm_dat import parse_therm_dat
            tdat = parse_therm_dat(wd)
            if tdat.get("source_file"):
                for k in (
                    "zero_point_energy_Ry", "Cv_300K_Ry_per_K",
                    "F_300K_Ry", "entropy_300K_Ry_per_K",
                    "T_min_K", "T_max_K", "n_T_points",
                ):
                    v = tdat.get(k)
                    if v is not None:
                        _nest_thermo(self.results, f"thermo.{k}", v)
                # Courbes Cv(T)/F(T) échantillonnées pour exploitation
                # UI/factsheet future (≤ 200 points).
                if tdat.get("curve_T_K"):
                    _nest_thermo(
                        self.results, "thermo.curve_T_K", tdat["curve_T_K"]
                    )
                    _nest_thermo(
                        self.results, "thermo.curve_Cv_Ry_per_K",
                        tdat.get("curve_Cv_Ry_per_K"),
                    )
                    _nest_thermo(
                        self.results, "thermo.curve_F_Ry", tdat.get("curve_F_Ry")
                    )
                _nest_thermo(
                    self.results, "thermo.therm_source_file", tdat["source_file"]
                )
        except Exception as ex:  # noqa: BLE001
            self._append_log(
                f"[LIVE thermo] parse_therm_dat : {ex} (ignoré)."
            )

        # 5b bis. α(T), Cp, ε₀ LST — grandeurs dérivées (juillet 2026)
        try:
            from parsers.thermo_derived import enrich_thermo_and_dielectric
            enrich_thermo_and_dielectric(wd, self.results, force=is_reparse)
            _th = self.results.get("thermo") or {}
            for tk in (
                "curve_Cp_Ry_per_K",
                "curve_alpha_T_K",
                "curve_alpha_per_K",
                "curve_B_GPa",
                "Cp_curve_source",
            ):
                if _th.get(tk) is not None:
                    _nest_thermo(self.results, f"thermo.{tk}", _th[tk])
        except Exception as ex:  # noqa: BLE001
            self._append_log(
                f"[LIVE thermo_derived] enrich : {ex} (ignoré)."
            )
        if is_reparse:
            try:
                self._post_process_thermo_plots(wd)
            except Exception as ex:  # noqa: BLE001
                self._append_log(
                    f"[LIVE thermo_plots] post-process : {ex} (ignoré)."
                )

        # 5b ter. Ré-hydrate métriques P5 extras (piézo numérique) depuis disque
        try:
            self._hydrate_thermo_extras_metrics(wd)
        except Exception as ex:  # noqa: BLE001
            self._append_log(
                f"[LIVE thermo_extras] hydrate : {ex} (ignoré)."
            )

        # 5c. === Juillet 2026 — magnétisme (nspin=2) =========================
        # Peuple ``results.magnetism.*`` depuis les journaux pw.x (total /
        # absolute magnetization + moments par site). Matériau non magnétique
        # ou nspin=1 → pw.x n'imprime rien → les clés restent None (contrat
        # « annoncé P1..P5, peuplé si SCF spin-polarisé »).
        try:
            from parsers.magnetization import parse_magnetization
            mag = parse_magnetization(wd)
            if mag.get("is_spin_polarized"):
                _nest_set_default(
                    self.results, "magnetism.total_magnetization",
                    mag.get("total_magnetization"),
                )
                _nest_set_default(
                    self.results, "magnetism.absolute_magnetization",
                    mag.get("absolute_magnetization"),
                )
                _nest_set_default(
                    self.results, "magnetism.m_per_atom", mag.get("m_per_atom")
                )
                if mag.get("projected_moments_per_atom"):
                    _nest_set_default(
                        self.results, "magnetism.projected_moments_per_atom",
                        mag["projected_moments_per_atom"],
                    )
                # Août 2026 — ordre magnétique CONVERGÉ (FM/AFM/FiM/noncolin)
                # + vecteur (mx,my,mz) pour nspin=4. La classification depuis
                # les moments convergés prime sur celle de la factsheet basée
                # starting_magnetization (intention d'entrée seulement).
                _nest_set_default(
                    self.results, "magnetism.magnetic_order",
                    mag.get("magnetic_order"),
                )
                if mag.get("total_magnetization_vector"):
                    _nest_set_default(
                        self.results, "magnetism.total_magnetization_vector",
                        mag["total_magnetization_vector"],
                    )
                if mag.get("is_noncollinear"):
                    _nest_set_default(
                        self.results, "magnetism.is_noncollinear", True
                    )
                _nest_set_default(
                    self.results, "magnetism.is_spin_polarized", True
                )
                _nest_set_default(
                    self.results, "magnetism.source_file", mag.get("source_file")
                )
        except Exception as ex:  # noqa: BLE001
            self._append_log(
                f"[LIVE magnetism] parse_magnetization : {ex} (ignoré)."
            )

        # 6. === Juin 2026 — stabilité dynamique (matdyn-based, ALL profils P1..P5) ==
        # ``parse_matdyn_dynamic_stability`` lit ``matdyn_bands.out`` (cm-1,
        # marqueur ``(***ima***)``) en priorité, sinon ``phonon.freq`` (bandes
        # cm⁻¹, blocs ``q =``, ou legacy THz). Si ni l'un ni l'autre n'est
        # présent (profil sans phonons, ou si la chaîne n'a pas encore tourné)
        # OU si les deux sont vides / illisibles, le parser renvoie
        # ``None`` et on NE TOUCHE PAS aux 3 clés — elles restent ``None``
        # (matérialisées par ``_init_results_for_profile`` au démarrage,
        # promesse UI « au niveau tous les pi »). L'UI affiche alors
        # « N/A : chaîne phonon non requise pour ce profil ».
        #
        # Tolérance interne du parser : ``-0.5`` cm-1 — convention standard
        # pour discriminer le bruit numérique des branches acoustiques Γ
        # (voir phonopy / phononDFT). Ne pas modifier sauf cas documenté
        # (matériau très bruité → ``tolerance_cm_minus_1=-1.0``).
        #
        # Poll-safe : appelé à chaque étape lourde (``scf_eq`` / ``eos_grid`` /
        # ph / q2r / matdyn / thermo_pw / post_process). Idempotent — un
        # second appel ne change rien tant que ``work_dir`` n'évolue pas
        # (parser basé sur lecture disque, jamais de calcul MPI).
        # =====================================================================
        try:
            from phonon_chain_qe import parse_matdyn_dynamic_stability
            dyn = parse_matdyn_dynamic_stability(wd)
            if dyn:
                for k in ("dynamically_stable", "n_imaginary_modes", "min_freq_cm-1"):
                    v = dyn.get(k)
                    if v is None:
                        continue
                    # Force : re-parse / nouveau parser doivent écraser d'anciens
                    # verdicts erronés (ex. fausses instabilités phonon.freq).
                    _nest_set_force(self.results, f"properties.{k}", v)
                # Diagnostic lisible dès la 1ʳᵉ apparition (utile pour le
                # marqueur ``pipeline_api_job_state.json`` côté UI live ou
                # archive disque ultérieure).
                tag = (
                    "STABLE"
                    if dyn.get("dynamically_stable")
                    else f"UNSTABLE ({dyn.get('n_imaginary_modes', '?')} freq. imaginaires)"
                )
                self._append_log(
                    f"[LIVE dynamic_stability] {tag} | "
                    f"ω_min={dyn.get('min_freq_cm-1')} cm⁻¹ | "
                    f"source={dyn.get('source')} | "
                    f"n_modes_total={dyn.get('n_modes_total')}"
                )
        except Exception as ex:  # noqa: BLE001
            # Erreurs de parsing ne bloquent JAMAIS la chaîne : le job
            # continue, les autres propriétés sont préservées, et l'UI
            # affiche « N/A » pour les 3 clés dynamiques.
            self._append_log(
                f"[LIVE dynamic_stability] parse_matdyn_dynamic_stability : "
                f"{ex} (les 3 clés restent None ; ignoré)."
            )

        # 6. Trace l'étape dans le journal (utilise _append_log, pas noisy).
        self._append_log(
            f"[LIVE] Étape « {step_label} » : "
            f"thermo_pw_run.out={'présent' if tpw_existed else 'absent'}, "
            f"résultats matérialisés dans le marker."
        )
        # 7. Persist — ``persist()`` est déjà try/except OSError dans sa
        # propre définition, pas besoin de doubler l'enrobage.
        self.persist()

    # -- Exécution de la série --------------------------------------------------
    def _execute(self):
        try:
            # ---- 0. Pré-population immédiate (avant toute I/O lourde) -------
            # Le contrat de résultats attendus est posé dès le démarrage pour
            # que le polling expose immédiatement `expected_results` même si la
            # résolution du template ou la création du work_dir échoue ensuite.
            self._init_results_for_profile()
            self._set(status="running", message="Démarrage de la série de calculs…")
            self.persist()

            # ---- 1. Résoudre scf.in ----
            scf_src = resolve_template(self.material_id, self.scf_in_basename)
            if scf_src is None or not scf_src.is_file():
                # fallback : cherche dans inputs/<mat>/ un fichier .in
                bucket = find_thermo_inputs_only(self.material_id)
                if bucket and bucket.candidates:
                    scf_src = bucket.mat_dir / bucket.candidates[0]
            if scf_src is None or not scf_src.is_file():
                raise FileNotFoundError(
                    f"Fichier scf.in introuvable pour « {self.material_id} ». "
                    "Vérifiez inputs/<matériau>/ ou indiquez le chemin."
                )

            # ---- 1b. Valider que scf.in est un véritable SCF équilibre autonome ----
            # Sans cette garde, on aboutit à l'erreur QE « fatal error reading
            # xml file » quand l'utilisateur sélectionne un fichier *nscf.in* ou
            # *vc-relax.in* par mégarde. Message en français avec suggestion
            # automatique du bon fichier voisin.
            ok, why = _detect_scf_capability(scf_src)
            if not ok:
                better = _suggest_harmless_scf(scf_src)
                hint = (
                    f"\n   → Essayez plutôt « {better} » (même dossier)."
                    if better
                    else "\n   → Créez un fichier « si_scf.in » (calculation='scf', "
                         "restart_mode='from_scratch')."
                )
                self._append_log(
                    f"[ERREUR] « {scf_src.name} » rejeté : {why}.{hint}"
                )
                raise ValueError(
                    f"« {scf_src.name} » n'est pas un SCF équilibre "
                    f"exécutable directement par le pipeline « 5 profils » : "
                    f"{why}.{hint}"
                )

            # ---- 2. Créer / choisir work_dir ----
            root = (cfg.WORK_ROOT).resolve()
            root.mkdir(parents=True, exist_ok=True)
            if self.user_work_dir:
                wd = Path(self.user_work_dir).expanduser().resolve()
                wd.mkdir(parents=True, exist_ok=True)
            else:
                ts = int(time.time())
                short = uuid.uuid4().hex[:6]
                base = root / self.material_id
                base.mkdir(parents=True, exist_ok=True)
                wd = base / f"pipeline_{self.profile_id}_{ts}_{short}"
                wd.mkdir(parents=True, exist_ok=True)
            self.work_dir = wd
            self._append_log(f"work_dir = {wd}")
            self.persist()

            # ---- 3. Préparer les entrées (copie scf.in, paramètres renforcés pour P4) ----
            scf_dest = wd / "scf.in"
            shutil.copy2(scf_src, scf_dest)
            self._append_log(f"Scf.in copié : {scf_dest}")
            # ---- 3b. Normaliser outdir ET pseudo_dir du template ----
            # Les gabarits inputs/<mat>/*.in utilisent parfois :
            #   * outdir = './work/Si/' → pw.x échoue (check_tempdir).
            #   * pseudo_dir = './pseudos/PBE/' → introuvable depuis work_dir.
            # On les réécrit en :
            #   * outdir → './out/' (relatif, 1 niveau sous work_dir).
            #   * pseudo_dir → chemin ABSOLU vers cfg.PSEUDOS_DIR.
            if _normalize_scf_paths(wd, scf_dest):
                self._append_log(
                    "Chemins template normalisés : outdir='./out/' + pseudo_dir absolu.",
                )
            # NB (juin 2026) : ``lcalc_bands`` / ``lcalc_dos`` ne sont PAS
            # reconnus par ``pw.x`` 7.5 dans ``&CONTROL`` (cf. INPUT_PW.html),
            # donc l'injection est désactivée (``_inject_lcalc_to_scf`` retourne
            # toujours ``False`` ici — wrapper no-op strict). La DOS/bandes sont
            # prises en charge par la chaîne NSCF + dos.x + bands.x
            # (``run_electronic_properties``, ichamp=2 ou 3 selon profil).
            if self.profile.get("apply_reinforce_strict"):
                try:
                    scf_text = scf_dest.read_text(encoding="utf-8")
                    reinforced = reinforce_params(scf_text, "strict")
                    if reinforced != scf_text:
                        scf_dest.write_text(reinforced, encoding="utf-8")
                        self._append_log("input_editor.reinforce_params(level='strict') appliqué (LIF).")
                except Exception as ex:  # noqa: BLE001
                    self._append_log(f"renforce strict : {ex} (ignoré).")

            # ---- 3c. Estimation de durée et d'espace disque ----
            # Posée ici car scf.in est désormais définitif (chemins normalisés,
            # renforcement P4 appliqué) : les descripteurs lus refléteront bien
            # ce qui va tourner. Journalisée pour rester traçable a posteriori.
            self._compute_runtime_estimate(wd)
            est = getattr(self, "runtime_estimate", None)
            if est:
                self._append_log(
                    f"Durée estimée ({self.profile_id}, nproc={self.nproc}) : "
                    f"{est['total_human']} — fourchette {est['range_human']}, "
                    f"confiance {est['confidence']}. Étape dominante : "
                    f"{est['dominant_step']}."
                )
                for w in est.get("warnings") or []:
                    self._append_log(f"⚠️ {w}")
            self._compute_storage_estimate(wd)
            sto = getattr(self, "storage_estimate", None)
            if sto:
                self._append_log(
                    f"Espace disque estimé : pic {sto['peak_human']} pendant le "
                    f"calcul, dont {sto['scratch_human']} de scratch temporaire ; "
                    f"{sto['retained_human']} de résultats à conserver."
                )
                for w in sto.get("warnings") or []:
                    self._append_log(f"⚠️ {w}")

            # ---- 4. Séquence selon le profil ----
            resume_target = getattr(self, "_resume_scope", None)
            skip_prefix = resume_target is not None

            if skip_prefix:
                prep = thermo_pw_resume.prepare_work_dir_for_resume(
                    wd,
                    profile_id=self.profile_id,
                    target=(
                        resume_target
                        if resume_target in ("thermo_main", "optical", "lo_to")
                        or str(resume_target).startswith("thermo_extra:")
                        else "thermo_main"
                    ),
                )
                for act in prep.actions:
                    self._append_log(f"[Reprise thermo_pw] {act}")
                for warn in prep.warnings:
                    self._append_log(f"⚠️ [Reprise thermo_pw] {warn}")

            if self.profile["needs_eos"]:
                if not skip_prefix:
                    self._run_eos_grid(wd)
                    self._intermediate_parse(wd, "after_eos_grid")
                else:
                    self._append_log(
                        "[Reprise thermo_pw] Grille EOS conservée (non relancée)."
                    )
                    self._intermediate_parse(wd, "after_eos_grid")
            else:
                if not skip_prefix:
                    self._run_scf_eq(wd)
                    self._intermediate_parse(wd, "after_scf_eq")
                else:
                    self._append_log(
                        "[Reprise thermo_pw] SCF équilibre conservé (non relancé)."
                    )
                    self._intermediate_parse(wd, "after_scf_eq")

            # ---- 5. Phonons si besoin (P1, P2, P3, P4, P5) ----
            if self.profile["needs_phonons"]:
                if not skip_prefix:
                    self._run_phonon_chain(wd)
                    self._intermediate_parse(wd, "after_phonon_chain")
                else:
                    self._append_log(
                        "[Reprise thermo_pw] Chaîne phonon conservée "
                        "(SCF@V₀, ph, q2r, matdyn non relancés)."
                    )
                    self._intermediate_parse(wd, "after_phonon_chain")

            # ---- 6. thermo_pw.x (P1-P5 selon what= du profil) ----
            if not self.profile.get("skip_thermo_pw", False):
                run_main = resume_target is None or resume_target == "thermo_main"
                if run_main:
                    self._run_thermo_pw(wd)
                    self._intermediate_parse(wd, "after_thermo_pw")
                elif skip_prefix:
                    self._append_log(
                        "[Reprise thermo_pw] Étape thermo_pw principale conservée."
                    )

            # ---- 6b. Propriétés électroniques (NSCF + DOS + Bandes) si activé ----
            # S'applique à P1, P2, P3, P4 et P5 : l'ichamp=3 fournit la
            # sanity check (gap métallique ⇒ spectre suspect) avant la
            # chaîne optique P5.
            run_electronic = self.profile.get("properties_enabled", False) and (
                resume_target is None or resume_target == "thermo_main"
            )
            if run_electronic:
                self._run_electronic_properties(wd)
                self._intermediate_parse(wd, "after_electronic_properties")

            # ---- 6c. Propriétés Optiques (DFPT linéaire epsilon.x) — P5 ----
            run_optical = self.profile.get("needs_optical", False) and (
                resume_target is None
                or resume_target in ("thermo_main", "optical")
            )
            if run_optical:
                self._run_optical_properties(wd)
                self._intermediate_parse(wd, "after_optical_properties")

            # ---- 6d. Propriétés thermo_pw étendues (P5 extras) --------------
            if self.extra_whats:
                if resume_target and resume_target.startswith("thermo_extra:"):
                    only = resume_target.split(":", 1)[1]
                    self._run_thermo_extras(wd, only_what=only)
                    self._intermediate_parse(wd, "after_thermo_extras")
                elif resume_target is None or resume_target == "thermo_main":
                    self._run_thermo_extras(wd)
                    self._intermediate_parse(wd, "after_thermo_extras")
                elif skip_prefix:
                    self._append_log(
                        "[Reprise thermo_pw] Extras thermo_pw conservés."
                    )

            # ---- 6e. LO/TO opt-in (P1, juillet 2026) ------------------------
            run_lo_to = (
                self.profile_id == "P1"
                and getattr(self, "lo_to_opt_in", False)
                and (
                    resume_target is None
                    or resume_target in ("thermo_main", "lo_to")
                )
            )
            if run_lo_to:
                self._run_lo_to_correction(wd)
                self._intermediate_parse(wd, "after_lo_to")

            # ---- 7. Tracés / résultats ----
            self._post_process(wd)

            self._resume_scope = None
            self._resume_thermo_overrides = {}
            self._set(
                status="done",
                message=f"Terminé — {wd}",
            )
            self.finished_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
            self._resume_scope = None
            self._resume_thermo_overrides = {}
            self.persist()
        except Exception as ex:  # noqa: BLE001
            # Juillet 2026 — Routage fin du job selon l'intent d'interruption.
            # Le runner détecte ``cancel_event`` à chaque sous-étape via
            # ``_wait_mpi_process`` (cf. qe_subprocess). Quand l'utilisateur a
            # cliqué Pause/Stop/Annuler, on lit ``interrupt_intent`` posé par
            # les ``request_*`` ci-dessus. Sans intent (legacy) on retombe
            # sur la détection textuelle "annul" dans le message d'erreur
            # (rétro-compat) → status=cancelled (hérité).
            intent = getattr(self, "interrupt_intent", None)
            cancel_msg = API_CANCEL_RUNTIME_MSG in str(ex) or "annul" in str(ex).lower()
            if cancel_msg and intent == "pause":
                self._set(
                    status="paused",
                    message=(
                        "En pause (reprise possible via le bouton « Reprendre »). "
                        f"Détail : {ex}"
                    ),
                )
            elif cancel_msg and intent == "stop":
                self._set(
                    status="stopped",
                    message=(
                        "Arrêté (work_dir conservé pour inspection, "
                        "NON reprenable). "
                        f"Détail : {ex}"
                    ),
                )
            elif cancel_msg:
                self._set(
                    status="cancelled",
                    message="Annulé par l'utilisateur.",
                )
            else:
                self._set(
                    status="error",
                    message=str(ex),
                )
            self._resume_scope = None
            self._resume_thermo_overrides = {}
            self.finished_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
            self.persist()

    # -- Étapes individuelles ---------------------------------------------------
    def _run_eos_grid(self, wd: Path):
        """Place une grille EOS (n_points=7, ±3%) et lance la chaîne pw.x + fit."""
        self._raise_if_cancelled()
        self._emit_step("eos_grid", "running", "Grille EOS 7 points ±3%")
        self._append_log("Grille EOS générée (n=7, ±3%) + SCF par volume + fit Birch–Murnaghan…")
        conf = EosConfig(
            template_pw=wd / "scf.in",
            n_points=7,
            strain_min=-0.03,
            strain_max=0.03,
            nproc=self.nproc,
            sequential=False,
        )
        try:
            db_path = wd / WORKFLOW_STATE_FILENAME
            db = WorkflowDB.load(db_path) if db_path.is_file() else WorkflowDB(
                material_id=self.material_id, work_dir=str(wd)
            )
            summary = task_optimize(
                wd, self.material_id, wd / "scf.in", db, conf,
                cancel_event=self.cancel_event,
                proc_holder=self.proc_holder,
            )
            self.results["eos"] = summary
            flatten_eos_summary_into_results(self.results)
            _backfill_eos_lattice_from_scf_eq(wd, self.results)
            self._emit_step("eos_grid", "done", f"V₀={summary.get('eos', {}).get('V0_bohr3', '?')}")
            self._append_log(f"EOS terminé : V₀ ≈ {summary.get('eos', {}).get('V0_bohr3', '?')} bohr³")
            # tracé gnuplot E(V)
            try:
                rel = run_gnuplot_eos(wd)
                _set_plot_path(self.results, "eos_ev", rel)
                self._append_log(
                    f"E(V) tracé : {_normalize_plot_relpath(rel) or '?'}"
                )
            except Exception as ex:  # noqa: BLE001
                self._append_log(f"gnuplot E(V) : {ex} (ignoré)")
        except Exception as ex:  # noqa: BLE001
            self._emit_step("eos_grid", "error", str(ex))
            raise

    def _run_scf_eq(self, wd: Path):
        """P1 : un seul pw.x -in scf.in (SCF équilibre)."""
        self._raise_if_cancelled()
        self._emit_step("scf_eq", "running", "pw.x @ V₀ (P1)")
        self._append_log(f"SCF équilibre : mpirun -np {self.nproc} pw.x -in scf.in")
        try:
            out = run_pw_x_in(
                wd, "scf.in", nproc=self.nproc,
                cancel_event=self.cancel_event, proc_holder=self.proc_holder,
            )
            tail = self._read_tail_log(out)
            self._append_log(f"SCF équilibre terminé, journal épilogue : {tail.splitlines()[-1] if tail else '...'}")
            self._emit_step("scf_eq", "done", str(out.resolve()))
        except Exception as ex:  # noqa: BLE001
            self._emit_step("scf_eq", "error", str(ex))
            raise

    def _run_phonon_chain(self, wd: Path):
        """P1/P2/P3/P4/P5 : SCF @ V₀ (1_eos_volumes/scf_eq.in ou scf.in) → ph.x → q2r → matdyn."""
        # 1. SCF @ V₀ (utilise scf_eq.in EOS du workflow précédent s'il existe)
        self._raise_if_cancelled()
        self._emit_step("scf_phonon", "running", "SCF @ V₀ pour phonons")
        scf_v0 = wd / "1_eos_volumes" / "scf_eq.in"
        if not scf_v0.is_file():
            # Reprend scf.in (par exemple premier lancement sans EOS)
            scf_v0 = wd / "scf.in"
        # On copie à la racine comme pw_scf_V0_for_phonon.in (convention thermo_pw)
        target_pw = wd / "pw_scf_V0_for_phonon.in"
        shutil.copy2(scf_v0, target_pw)
        # NB (juin 2026) : ``lcalc_bands`` / ``lcalc_dos`` ne sont PAS reconnus
        # par ``pw.x`` 7.5 dans ``&CONTROL``, donc ``_inject_lcalc_to_scf`` est
        # no-op (retourne ``False``). La DOS/bandes restent assurées par la
        # chaîne NSCF + dos.x + bands.x (``run_electronic_properties``).
        try:
            run_pw_x_in(
                wd, "pw_scf_V0_for_phonon.in", nproc=self.nproc,
                cancel_event=self.cancel_event, proc_holder=self.proc_holder,
            )
            self._append_log("SCF @ V₀ terminé.")
            self._emit_step("scf_phonon", "done", str(target_pw.resolve()))
            # Live : diffuse les sorties intermédiaires dès que SCF @ V₀ est OK.
            self._intermediate_parse(wd, "after_scf_phonon")
        except Exception as ex:  # noqa: BLE001
            self._emit_step("scf_phonon", "error", f"SCF V₀ : {ex}")
            raise

        # 2. ph.x (génère ph.in si manquant)
        self._raise_if_cancelled()
        self._emit_step("ph", "running", "ph.x (DFPT)")
        try:
            if not (wd / "ph.in").is_file():
                n1 = n2 = n3 = 4  # grille fine pour QHA
                try_autogenerate_ph_in(wd, "ph.in", nq1=n1, nq2=n2, nq3=n3)
                self._append_log(f"ph.in auto-généré (grille {n1}×{n2}×{n3}).")
            out = run_ph_x_in(
                wd, "ph.in", nproc=self.nproc,
                cancel_event=self.cancel_event, proc_holder=self.proc_holder,
            )
            self._append_log("ph.x terminé.")
            self._emit_step("ph", "done", str(out.resolve()))
            # Live : ph.x écrit dans thermo_pw_run.out + met à jour les
            #       fréquences phonons si thermo_pw était déjà partiellement lancé.
            self._intermediate_parse(wd, "after_ph_phonon")
        except Exception as ex:  # noqa: BLE001
            self._emit_step("ph", "error", f"ph.x : {ex}")
            raise

        # 3. q2r.x → fc.out
        self._raise_if_cancelled()
        self._emit_step("q2r", "running", "q2r.x (fc.out)")
        try:
            # S'assurer que thermo_control et ph_control sont cohérents
            from phonon_chain_qe import write_q2r_in
            zasr, fildyn = parse_ph_fildyn(wd)
            write_q2r_in(wd, zasr=zasr, fildyn=fildyn, flfrc="fc.out")
            from qe_subprocess import run_qe_stdin as _stdin
            _stdin(
                cfg.q2r_path(), wd / "q2r.in", wd, wd / "q2r.out",
                cancel_event=self.cancel_event, proc_holder=self.proc_holder,
            )
            self._append_log("q2r.x terminé (fc.out écrit).")
            self._emit_step("q2r", "done", str((wd / "fc.out").resolve()))
            # Live : fc.out tout frais → le polishing Cij y est lu aussi.
            self._intermediate_parse(wd, "after_q2r")
        except Exception as ex:  # noqa: BLE001
            self._emit_step("q2r", "error", f"q2r.x : {ex}")
            raise

        # 4. matdyn.x (bandes + DOS)
        self._raise_if_cancelled()
        self._emit_step("matdyn", "running", "matdyn.x (bandes + DOS)")
        try:
            run_matdyn_bands(
                wd, cancel_event=self.cancel_event, proc_holder=self.proc_holder
            )
            self._append_log("matdyn bandes terminé.")
            run_matdyn_dos(
                wd, cancel_event=self.cancel_event, proc_holder=self.proc_holder
            )
            self._append_log("matdyn DOS terminé.")
            self._emit_step("matdyn", "done", "phonon.freq + phonon.dos")
            # Live : phonon.freq/dos fraîches, thermo_pw n'a pas encore tourné —
            #        le parser essaiera quand même de lire un tail éventuellement
            #        déjà écrit (idempotent, sans danger).
            self._intermediate_parse(wd, "after_matdyn")
        except Exception as ex:  # noqa: BLE001
            self._emit_step("matdyn", "error", f"matdyn.x : {ex}")
            raise

        # 5. tracés gnuplot phonon
        try:
            rel = run_gnuplot_phonon_bands(wd)
            self.results.setdefault("plots", {})["phonon_bands"] = rel.get("relpath")
            self._append_log(f"Phonons bandes : {rel.get('relpath', '?')}")
        except Exception as ex:  # noqa: BLE001
            self._append_log(f"gnuplot phonon_bands : {ex}")
        try:
            rel = run_gnuplot_phonon_dos(wd)
            self.results.setdefault("plots", {})["phonon_dos"] = rel.get("relpath")
            self._append_log(f"Phonons DOS : {rel.get('relpath', '?')}")
        except Exception as ex:  # noqa: BLE001
            self._append_log(f"gnuplot phonon_dos : {ex}")

    def _run_thermo_pw(self, wd: Path):
        """thermo_pw.x avec les options de profil."""
        self._emit_step("thermo_pw", "running", f"thermo_pw.x what={self.profile['what_qe']}")
        try:
            # Juin 2026 refonte : opts profil-aware. N'émet les clés QHA
            # (tmin/tmax/deltat/ltherm_dos/ltherm_freq) QUE si le profil les
            # déclare dans ``thermo_opts``. Sinon le bloc est minimal (P5
            # ``dielectric`` et P1 ``elastic`` @ T=0 : pas de tmin/tmax/deltat).
            _defaults = dict(self.profile.get("thermo_opts") or {})
            opts: dict[str, Any] = {
                "what": self.profile["what_qe"],
                "zasr": str(_defaults.get("zasr", "simple")),
                "fildyn": str(_defaults.get("fildyn", "ph_dyn")),
            }
            if "tmin" in _defaults:
                opts["tmin"] = float(_defaults["tmin"])
            if "tmax" in _defaults:
                opts["tmax"] = float(_defaults["tmax"])
            if "deltat" in _defaults:
                opts["deltat"] = float(_defaults["deltat"])
            if "ltherm_dos" in _defaults:
                opts["ltherm_dos"] = bool(_defaults["ltherm_dos"])
            if "ltherm_freq" in _defaults:
                opts["ltherm_freq"] = bool(_defaults["ltherm_freq"])
            resume_ov = dict(getattr(self, "_resume_thermo_overrides", None) or {})
            for key in ("lsolve", "deltat", "ltherm_dos", "ltherm_freq"):
                if key in resume_ov:
                    opts[key] = resume_ov[key]
            self._append_log(f"thermo_pw.x what={self.profile['what_qe']!r} (profil {self.profile_id})")
            if resume_ov:
                self._append_log(
                    f"thermo_pw overrides reprise : {resume_ov!r}"
                )
            log = run_thermo_pw_mpi(
                wd,
                nproc=self.nproc,
                pw_in_basename=(
                    "pw_scf_V0_for_phonon.in"
                    if (wd / "pw_scf_V0_for_phonon.in").is_file()
                    else "scf.in"
                ),
                thermo_opts=opts,
                clear_thermo_restart=True,
                cancel_event=self.cancel_event,
                proc_holder=self.proc_holder,
            )
            self.results["thermo_log"] = str(log.resolve())
            self._emit_step("thermo_pw", "done", str(log.resolve()))
            self._append_log("thermo_pw.x terminé.")
        except Exception as ex:  # noqa: BLE001
            self._emit_step("thermo_pw", "error", str(ex))
            raise

    def _run_electronic_properties(self, wd: Path):
        """NSCF -> DOS -> (bandes si ichamp>=3) : proprietes electroniques.

        Utilise en entree le SCF d'equilibre :
          * P1  -> ``scf.in``  (equilibre unique).
          * P2-P4 -> ``pw_scf_V0_for_phonon.in`` (SCF @ V0 deja calcule pour
            les phonons, identique par construction).

        L'injection de ``wf_collect = .true.`` est faite a la volee par
        ``electronic_props.inject_wf_collect`` ; sans cela, le NSCF /
        bands.x ne trouvent pas les fonctions d'onde sur disque (QE les
        distribue sur les rangs MPI sans les serialiser).

        Sortie : mise a jour de ``self.results["properties"]`` (clefs
        normalisees ``fermi_eV``, ``band_gap_eV``, ``vbm_eV``, ``cbm_eV``,
        ``band_gap_type``, ``gap_direct``, ``n_bands``, ``ebands_image``,
        ``edos_image``, ...) et de ``self.results["plots"]["ebands"|"edos"]``
        pour le rendu UI via ``/api/pipeline/result_image``.
        """
        ichamp = int(self.profile.get("properties_ichamp", 3))
        self._emit_step(
            "electronic_props",
            "running",
            f"NSCF + DOS + {'Bandes' if ichamp >= 3 else 'DOS seule'} (ichamp={ichamp})",
        )
        scf_basename = (
            "pw_scf_V0_for_phonon.in"
            if (wd / "pw_scf_V0_for_phonon.in").is_file()
            else "scf.in"
        )
        try:
            from electronic_props import run_electronic_properties as _run_ep
            parsed = _run_ep(
                wd,
                nproc=self.nproc,
                scf_basename=scf_basename,
                ichamp=ichamp,
                cancel_event=self.cancel_event,
                proc_holder=self.proc_holder,
                log_emit=self._append_log,
            )
        except Exception as ex:  # noqa: BLE001
            self._emit_step("electronic_props", "error", str(ex))
            # On ne bloque PAS le job entier : un echec proprietes n'invalide
            # pas la serie thermo_pw / EOS / elastic. On log et on continue
            # vers ``_post_process`` pour que l'UI ait un etat final propre.
            self._append_log(
                f"[PROPS] etape electroniques interrompue : {ex} "
                "(les resultats thermo_pw / EOS / elastic sont conserves)."
            )
            return
        # Merge prudent dans self.results : ``_nest_set_default`` n'ecrase
        # jamais une valeur non-None deja posee (anti-flicker live UI ; le
        # LIF est par exemple deja pose par thermo_pw.x sur certaines cles).
        keys_to_nest = (
            "fermi_eV", "vbm_eV", "cbm_eV", "band_gap_eV",
            "band_gap_type", "gap_direct", "n_bands",
            "ichamp", "nscf_ok", "dos_ok", "bands_ok",
            "ebands_image", "edos_image",
        )
        for k in keys_to_nest:
            v = getattr(parsed, k, None)
            if v is None:
                continue
            _nest_set_default(self.results, f"properties.{k}", v)
        plots_section = self.results.setdefault("plots", {})
        if parsed.edos_image:
            _nest_set_default(plots_section, "edos", parsed.edos_image)
        if parsed.ebands_image:
            _nest_set_default(plots_section, "ebands", parsed.ebands_image)
        self._append_log(
            f"[PROPS] resume : ichamp={parsed.ichamp} | NSCF={parsed.nscf_ok} | "
            f"DOS={parsed.dos_ok} | bandes={parsed.bands_ok} | "
            f"E_F={parsed.fermi_eV} eV | gap={parsed.band_gap_eV} eV "
            f"({parsed.band_gap_type or '?'})"
        )
        self._emit_step(
            "electronic_props",
            "done",
            f"E_F={parsed.fermi_eV} eV, gap={parsed.band_gap_eV} eV",
        )
        self.persist()

    def retry_bands(self) -> dict[str, Any]:
        """Relance pw.x BANDS + bands.x sur un job terminé (NSCF déjà OK).

        Met à jour ``results.properties`` et ``results.plots.ebands`` en
        écrasant les valeurs précédentes (``bands_ok=false``, gap null).
        """
        if not self.work_dir or not Path(self.work_dir).is_dir():
            raise FileNotFoundError(
                f"work_dir absent du disque — retry bandes impossible : {self.work_dir}"
            )
        wd = Path(self.work_dir)
        scf_basename = (
            "pw_scf_V0_for_phonon.in"
            if (wd / "pw_scf_V0_for_phonon.in").is_file()
            else "scf.in"
        )
        self._append_log("[PROPS] Retry bandes-only demandé (NSCF/DOS conservés).")
        parsed = run_bands_chain_only(
            wd,
            nproc=self.nproc,
            scf_basename=scf_basename,
            cancel_event=self.cancel_event,
            proc_holder=self.proc_holder,
            log_emit=self._append_log,
        )
        keys_to_nest = (
            "fermi_eV", "vbm_eV", "cbm_eV", "band_gap_eV",
            "band_gap_type", "gap_direct", "n_bands",
            "bands_ok", "pw_bands_in", "bands_in", "ebands_image",
        )
        for k in keys_to_nest:
            v = getattr(parsed, k, None)
            if v is None and k not in ("bands_ok",):
                continue
            _nest_set_force(self.results, f"properties.{k}", v)
        plots_section = self.results.setdefault("plots", {})
        if parsed.ebands_image:
            _nest_set_force(plots_section, "ebands", parsed.ebands_image)
        self._append_log(
            f"[PROPS] retry bandes terminé : bandes={parsed.bands_ok} | "
            f"gap={parsed.band_gap_eV} eV ({parsed.band_gap_type or '?'})"
        )
        self.persist()
        return {
            "ok": parsed.bands_ok,
            "bands_ok": parsed.bands_ok,
            "band_gap_eV": parsed.band_gap_eV,
            "band_gap_type": parsed.band_gap_type,
            "ebands_image": parsed.ebands_image,
            "properties": self.results.get("properties", {}),
            "plots": self.results.get("plots", {}),
        }

    def reparse_bands_from_disk(self) -> dict[str, Any]:
        """Re-parse ``bands.dat`` sur disque sans relancer pw.x (marker périmé)."""
        if not self.work_dir or not Path(self.work_dir).is_dir():
            raise FileNotFoundError(
                f"work_dir absent du disque — reparse bandes impossible : {self.work_dir}"
            )
        from electronic_props import reparse_bands_from_disk as _reparse

        wd = Path(self.work_dir)
        self._append_log("[PROPS] Reparse bandes depuis disque (sans pw.x).")
        parsed = _reparse(wd)
        keys_to_nest = (
            "fermi_eV", "vbm_eV", "cbm_eV", "band_gap_eV",
            "band_gap_type", "gap_direct", "n_bands",
            "bands_ok", "ebands_image",
        )
        for k in keys_to_nest:
            v = getattr(parsed, k, None)
            if v is None and k not in ("bands_ok",):
                continue
            _nest_set_force(self.results, f"properties.{k}", v)
        plots_section = self.results.setdefault("plots", {})
        if parsed.ebands_image:
            _nest_set_force(plots_section, "ebands", parsed.ebands_image)
        self._append_log(
            f"[PROPS] reparse bandes : bandes={parsed.bands_ok} | "
            f"gap={parsed.band_gap_eV} eV ({parsed.band_gap_type or '?'})"
        )
        self.persist()
        return {
            "ok": parsed.bands_ok,
            "bands_ok": parsed.bands_ok,
            "band_gap_eV": parsed.band_gap_eV,
            "band_gap_type": parsed.band_gap_type,
            "gap_direct": parsed.gap_direct,
            "properties": self.results.get("properties", {}),
            "plots": self.results.get("plots", {}),
        }

    def _run_optical_properties(self, wd: Path):
        """NSCF_optic + epsilon.x : propriétés optiques DFPT linéaire (P5).

        Pré-requis : SCF équilibre calculé (``scf.in``, ``wf_collect=.true.``)
        et pseudos Norm-Conserving (epsilon.x n'accepte pas PAW/ultra-doux).

        Sortie : mise à jour de ``self.results["optical_props"]`` —
          * ``nscf_optic_ok``   : True si le NSCF_optic a abouti
          * ``epsilon_ok``      : True si epsilon.x a produit ses .dat
          * ``nscf_optic_nbnd`` : nbnd effectif (sanity : nat × 16 ou × 2)
          * ``eps_dat_files``   : liste des epsNN_/eelsNN_/jdos_ .dat produits
        """
        self._emit_step(
            "optical_props",
            "running",
            "NSCF_optic (nbnd × 2, nosym/noinv) + epsilon.x (DFPT linéaire)",
        )
        # P5 n'a pas d'EOS → ``pw_scf_V0_for_phonon.in`` n'existe pas :
        # _run_optical_properties retombe automatiquement sur ``scf.in``.
        scf_basename = (
            "pw_scf_V0_for_phonon.in"
            if (wd / "pw_scf_V0_for_phonon.in").is_file()
            else "scf.in"
        )
        try:
            parsed = run_optical_properties(
                wd,
                nproc=self.nproc,
                scf_basename=scf_basename,
                cancel_event=self.cancel_event,
                proc_holder=self.proc_holder,
                log_emit=self._append_log,
            )
        except Exception as ex:  # noqa: BLE001
            # On ne bloque PAS le job entier : la chaîne optique ne doit
            # jamais casser une run où ichamp=3 a déjà fonctionné. Idem
            # au pattern ``_run_electronic_properties``.
            self._emit_step("optical_props", "error", str(ex))
            self._append_log(
                f"[OPTIC] étape optique interrompue : {ex} "
                "(les résultats ichamp=3 / SCF sont conservés)."
            )
            return
        # Merge idempotent (anti-flicker). ``_nest_set_default`` n'écrase
        # jamais une valeur non-None — symétrique au bloc electronic_props.
        optical_section = self.results.setdefault("optical_props", {})
        # Champs scalaires à merger dans self.results["optical_props"] :
        #   * nscf_optic_*  : pré-requis partagé (filet de sécurité)
        #   * epsilon_*     : chaîne DFPT linéaire (epsilon.x)
        #   * turbo_lanczos_* : chaîne TDDFPT Lanczos (turbo_lanczos.x)
        #   * turbo_davidson_* : chaîne TDDFPT Davidson (turbo_davidson.x)
        scalars = (
            "nscf_optic_ok", "epsilon_ok",
            "nscf_optic_in", "epsilon_in", "nscf_optic_nbnd",
            "turbo_lanczos_ok", "turbo_davidson_ok",
            "turbo_lanczos_in", "turbo_davidson_in",
        )
        for k in scalars:
            v = getattr(parsed, k, None)
            if v is None:
                continue
            if optical_section.get(k) is None:
                optical_section[k] = v
        # eps_dat_files (epsilon.x) + turbo_dat_files (TDDFPT) : on cumule
        # sans doublon pour rendre les chips cliquables côté UI.
        for list_key, src_attr in (
            ("eps_dat_files", "eps_dat_files"),
            ("turbo_dat_files", "turbo_dat_files"),
        ):
            existing = set(optical_section.get(list_key) or [])
            for f in getattr(parsed, src_attr) or []:
                if f not in existing:
                    existing.add(f)
            if existing:
                optical_section[list_key] = sorted(existing)
        n_eps = len(parsed.eps_dat_files or [])
        n_turbo = len(parsed.turbo_dat_files or [])
        # Résumé final : reflète les 3 chaînes optiques de P5 exhaustive.
        self._append_log(
            f"[OPTIC] résumé : NSCF_optic={parsed.nscf_optic_ok} | "
            f"epsilon.x={parsed.epsilon_ok} | "
            f"turbo_lanczos={parsed.turbo_lanczos_ok} | "
            f"turbo_davidson={parsed.turbo_davidson_ok} | "
            f"{n_eps} eps*.dat + {n_turbo} turbo*.dat."
        )
        self._emit_step(
            "optical_props",
            "done",
            f"NSCF_optic={parsed.nscf_optic_ok}, epsilon={parsed.epsilon_ok}",
        )
        self.persist()

    def _merge_p5_extra_parsed_metrics(self, what: str, parsed: dict[str, Any]) -> None:
        """Propage métriques tensorielles des extras P5 vers ``results``."""
        if not what or not parsed:
            return
        prefix = f"thermo_extras.{what}"
        for mk, mv in parsed.items():
            if mk in ("matched_keywords", "source_line"):
                continue
            if mv is None:
                continue
            _nest_set_default(self.results, f"{prefix}.{mk}", mv)
        if what == "piezoelectric_tensor":
            matrix = parsed.get("matrix")
            if isinstance(matrix, list) and len(matrix) >= 3:
                row3 = matrix[2]
                if isinstance(row3, list) and len(row3) >= 3 and row3[2] is not None:
                    _nest_set_default(
                        self.results,
                        f"{prefix}.e_33",
                        row3[2],
                    )

    def _hydrate_thermo_extras_metrics(self, wd: Path) -> None:
        """Relit les journaux ``thermo_pw_<what>.out`` pour métriques numériques."""
        extras = self.results.get("thermo_extras") or {}
        if not isinstance(extras, dict):
            return
        for what, rec in extras.items():
            if not isinstance(rec, dict):
                continue
            log_path = wd / f"thermo_pw_{what}.out"
            if not log_path.is_file():
                continue
            try:
                text = log_path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            if not text.strip():
                continue
            parsed = parse_thermo_pw_p5_extra_log(what, text, work_dir=wd)
            if parsed:
                self._merge_p5_extra_parsed_metrics(what, parsed)

    def _run_thermo_extras(self, wd: Path, *, only_what: Optional[str] = None):
        """Boucle séquentielle sur ``self.extra_whats`` (ou un seul ``only_what``).

        Pour chaque ``what=`` admis par ``WHO_CATALOG`` :
          1. Écrit ``thermo_control`` avec la valeur ``what=`` correspondante.
          2. Lance ``thermo_pw.x`` via ``run_thermo_pw_mpi(log_filename=...)``
             (un journal dédié par what= → race-free).
          3. Marque ok=True/False dans ``self.results["thermo_extras"][what]``,
             trace le log path et expose d'éventuels artefacts (``BZ_plot.ps.gz``,
             ``BZ.txt``, ``output_piezo.dat``, …).
          4. Tolérance binaire : si ``thermo_pw.x`` est absent du runtime,
             l'étape est marquée ``ok=False`` + ``skipped=True``.

        Chaque appel relance thermo_pw.x, ce qui peut être long. En cas
        d'erreur sur un ``what=``, on trace l'erreur et on continue avec
        le suivant (NE bloque PAS le job).
        """
        if not self.extra_whats:
            self._append_log("[P5-EXTRAS] Aucun what= étendu sélectionné — skip.")
            return
        # Séquence sur outdir partagée : thermo_pw.x utilise
        # ``restart_mode='from_scratch'`` pour chaque what= ⇒ ``run_thermo_pw_mpi``
        # purge ``restart/`` + ``_temporary*`` перед chaque lancement (cf.
        # ``clear_thermo_restart=True`` dans ``run_thermo_pw_mpi``).
        existing_section = self.results.get("thermo_extras") or {}
        if not isinstance(existing_section, dict):
            existing_section = {}
        self.results["thermo_extras"] = existing_section
        whats = [only_what] if only_what else list(self.extra_whats)
        for what in whats:
            # Annulation utilisateur : on sort de la boucle SANS itérer les
            # ``what=`` restants. Sans ce court-circuit, ``run_thermo_pw_mpi``
            # lèverait ``API_CANCEL_RUNTIME_MSG`` sur le calcul courant, mais
            # le ``except Exception`` continuerait silencieusement avec le
            # what= suivant — gaspillant du temps cluster pour rien.
            if self.cancel_event is not None and self.cancel_event.is_set():
                self._append_log(
                    f"[P5-EXTRAS] Annulation demandée — abandon avant "
                    f"what={what!r} (sur {len(self.extra_whats)} total)."
                )
                self._emit_step(f"thermo_extras_{what}", "cancelled", "annulé")
                # On marque l'extras en cours comme non abouti pour l'UI.
                self._nest_set_default(
                    self.results, f"thermo_extras.{what}.ok", False
                )
                self.results["thermo_extras"][what] = self.results.get(
                    "thermo_extras", {}
                ).get(what, {"what": what, "ok": False, "skipped": True})
                self.results["thermo_extras"][what]["ok"] = False
                self.results["thermo_extras"][what]["skipped"] = True
                self.results["thermo_extras"][what]["error"] = (
                    API_CANCEL_RUNTIME_MSG
                )
                break
            entry = get_catalog_entry(what)
            if entry is None:
                # Filtré par ``expand_extra_whats`` ; n'arrivera pas, mais
                # tolérant si la whitelist évolue entre création du job et run.
                self._append_log(
                    f"[P5-EXTRAS] what={what!r} absent du catalogue — skip."
                )
                continue
            self._emit_step(
                f"thermo_extras_{entry.what}",
                "running",
                f"thermo_pw.x what={entry.what}",
            )
            self._append_log(
                f"[P5-EXTRAS] Lancement thermo_pw.x what={entry.what!r} "
                f"(suffixe log={entry.log_suffix!r})."
            )
            log_filename = f"thermo_pw_{entry.log_suffix or entry.what}.out"
            # ``pw_in_basename`` suit la convention P5 (pas d'EOS, pas de
            # phonons) : on retombe sur scf.in. Si une chaîne phonon P2-P4
            # a précédé (ré-utilisation de work_dir), le SCF @ V₀ existe.
            pw_in_basename = (
                "pw_scf_V0_for_phonon.in"
                if (wd / "pw_scf_V0_for_phonon.in").is_file()
                else "scf.in"
            )
            opts: dict[str, Any] = {
                "what": entry.what,
                # Champs QHA dérivés (ignorés par thermo_pw si le what= n'en
                # veut pas : pas d'effet de bord sur scf_dielectric / plot_bz).
                "tmin": 0.0,
                "tmax": 0.0,
                "deltat": 1.0,
                "fildyn": "ph_dyn",
                "zasr": "simple",
                "ltherm_dos": False,
                "ltherm_freq": False,
            }
            entry_record: dict[str, Any] = {
                "what": entry.what,
                "label": entry.label,
                "group": entry.group,
                "ok": False,
                "skipped": False,
                "log_file": log_filename,
                "started_at": datetime.now(timezone.utc).isoformat(
                    timespec="seconds"
                ),
            }
            self.results["thermo_extras"][entry.what] = entry_record
            self._nest_set_default(
                self.results, f"thermo_extras.{entry.what}.ok", False
            )
            self.persist()
            try:
                last_log = run_thermo_pw_mpi(
                    wd,
                    nproc=self.nproc,
                    pw_in_basename=pw_in_basename,
                    thermo_opts=opts,
                    clear_thermo_restart=True,
                    cancel_event=self.cancel_event,
                    proc_holder=self.proc_holder,
                    log_filename=log_filename,
                )
                entry_record["log_file"] = str(last_log.resolve())
                # Vérification d'artefacts typiques (informatif).
                artifacts: list[str] = []
                for art in entry.expected_outputs:
                    ap = wd / art
                    if ap.is_file():
                        artifacts.append(art)
                # Tentative de parsing des métriques structurelles / tensor
                # depuis le journal dédié. Ne fait pas tomber
                # ``entry_record["ok"]`` à False en cas d'échec (le journal
                # est consultable via les chips cliquables UI peu importe).
                try:
                    log_text = last_log.read_text(
                        encoding="utf-8", errors="replace"
                    ) if last_log.is_file() else ""
                except OSError as ex:
                    log_text = ""
                    self._append_log(
                        f"[P5-EXTRAS] lecture log échouée pour parse : {ex}"
                    )
                if log_text:
                    try:
                        parsed_metrics = parse_thermo_pw_p5_extra_log(
                            entry.what, log_text, work_dir=wd
                        )
                    except Exception as ex:  # noqa: BLE001
                        parsed_metrics = {}
                        self._append_log(
                            f"[P5-EXTRAS] parse erreur pour what={entry.what!r} : "
                            f"{ex} (toléré, journal consultable)."
                        )
                    if parsed_metrics:
                        entry_record["metrics"] = parsed_metrics
                        entry_record["parsed"] = True
                        self._merge_p5_extra_parsed_metrics(entry.what, parsed_metrics)
                        mk = parsed_metrics.get("matched_keywords") or []
                        self._append_log(
                            f"[P5-EXTRAS] what={entry.what!r} "
                            f"métriques extraites : {mk}"
                        )
                    else:
                        entry_record["parsed"] = False
                        entry_record.setdefault("metrics", {})
                        self._append_log(
                            f"[P5-EXTRAS] what={entry.what!r} : aucun match "
                            "regex (journal illisible pour cette version). "
                            "Métriques ``None`` ; chips cliquables toujours dispo."
                        )
                entry_record["ok"] = True
                entry_record["artifacts"] = artifacts
                self._append_log(
                    f"[P5-EXTRAS] thermo_pw.x what={entry.what!r} terminé "
                    f"({len(artifacts)} artefact(s) : {artifacts or 'aucun'})."
                )
                self._emit_step(
                    f"thermo_extras_{entry.what}",
                    "done",
                    str(last_log.resolve()),
                )
            except Exception as ex:  # noqa: BLE001
                entry_record["ok"] = False
                entry_record["error"] = str(ex)
                self._append_log(
                    f"[P5-EXTRAS] what={entry.what!r} échoué : {ex}"
                )
                self._emit_step(
                    f"thermo_extras_{entry.what}", "error", str(ex)
                )
                # Tolérant : on NE bloque PAS le job sur un what= individuel.
                continue
            finally:
                # Re-maj idempotente via _nest_set_default (anti-flicker).
                self._nest_set_default(
                    self.results, f"thermo_extras.{entry.what}.ok",
                    bool(entry_record.get("ok")),
                )
                self.persist()
        # Résumé final.
        ok_count = sum(
            1 for v in (self.results.get("thermo_extras") or {}).values()
            if isinstance(v, dict) and v.get("ok")
        )
        self._append_log(
            f"[P5-EXTRAS] Bilan : {ok_count}/{len(self.extra_whats)} what= "
            f"ont abouti."
        )

    def _run_lo_to_correction(self, wd: Path):
        """P1 opt-in LO/TO (juillet 2026) — cf. ``PROFILES['P1']`` steps.

        Chaîne complète :
          1. Vérifie que TOUS les pseudos sont Norm-Conserving (fail-fast,
             US-PP/PAW incompatibles avec Z* pour matdyn non-analytique).
          2. Sub-run ``thermo_pw.x what='dielectric'`` → journal dédié
             ``thermo_pw_dielectric_lo_to.out`` → parse ε∞ + Z* par atome.
          3. Écrit le fichier ``BORN`` (format matdyn).
          4. Chaîne phonon (ph.x → q2r → matdyn) si pas déjà faite, puis
             injection ``non_analytic=.true.`` + ``BORN_INPUT_FILE`` dans
             ``matdyn_bands.in`` et re-run matdyn → ``phonon.freq`` corrigé.
          5. Parse le splitting LO/TO à Γ → ``results.dielectric.*``.

        Tolérant : chaque échec marque ``dielectric.lo_to_ok=False`` +
        ``dielectric.lo_to_error`` sans lever (les résultats élastiques P1
        restent valides).
        """
        self._emit_step("lo_to", "running", "Chaîne LO/TO (dielectric → BORN → matdyn NA)")
        di_section = self.results.setdefault("dielectric", {})
        di_section.setdefault("lo_to_ok", False)

        def _fail(msg: str) -> None:
            di_section["lo_to_ok"] = False
            di_section["lo_to_error"] = msg
            self._append_log(f"[LO/TO] {msg}")
            self._emit_step("lo_to", "error", msg)
            self.persist()

        try:
            from lo_to_chain import (
                check_pseudos_from_pw_input,
                write_born_file,
                extend_matdyn_in_for_non_analytic,
                parse_lo_to_splitting_at_gamma,
            )
            # ---- 1. Pseudos NC obligatoires (scf.in seulement) ------------
            pw_for_pseudo = (
                wd / "pw_scf_V0_for_phonon.in"
                if (wd / "pw_scf_V0_for_phonon.in").is_file()
                else wd / "scf.in"
            )
            ok_nc, bad = check_pseudos_from_pw_input(pw_for_pseudo)
            if not ok_nc:
                _fail(
                    "pseudos non Norm-Conserving détectés — chaîne LO/TO refusée : "
                    + " ; ".join(bad[:4])
                )
                return
            self._append_log(
                f"[LO/TO] pseudos NC vérifiés ({pw_for_pseudo.name})."
            )

            # ---- 2. Sub-run thermo_pw what='dielectric' -----------------
            log_filename = "thermo_pw_dielectric_lo_to.out"
            try:
                run_thermo_pw_mpi(
                    wd,
                    nproc=self.nproc,
                    pw_in_basename=(
                        "pw_scf_V0_for_phonon.in"
                        if (wd / "pw_scf_V0_for_phonon.in").is_file()
                        else "scf.in"
                    ),
                    thermo_opts={
                        "what": "dielectric",
                        "zasr": "simple",
                        "fildyn": "ph_dyn",
                        "ltherm_dos": False,
                    },
                    clear_thermo_restart=True,
                    cancel_event=self.cancel_event,
                    proc_holder=self.proc_holder,
                    log_filename=log_filename,
                )
            except Exception as ex:  # noqa: BLE001
                _fail(f"sub-run thermo_pw what='dielectric' échoué : {ex}")
                return
            from parsers.dielectric import parse_dielectric
            di = parse_dielectric(wd) or {}
            for k, v in di.items():
                if k in ("matched_keywords", "source_files"):
                    continue
                if v in (None, [], {}):
                    continue
                if di_section.get(k) is None or k not in di_section:
                    di_section[k] = v
            if not di.get("born_Z_star_per_atom"):
                _fail(
                    "sub-run dielectric terminé mais Z* par atome introuvable "
                    "dans les sorties — BORN impossible."
                )
                return

            # ---- 3. Fichier BORN ----------------------------------------
            try:
                write_born_file(di, wd / "BORN")
                self._append_log("[LO/TO] fichier BORN écrit (ε∞ + Z*).")
            except (ValueError, OSError) as ex:
                _fail(f"écriture BORN : {ex}")
                return

            # ---- 4. Chaîne phonon + matdyn non-analytique ---------------
            # Si fc.out est absent (chaîne phonon pas encore passée), on
            # la joue ici en fallback pour le matdyn non-analytique.
            if not (wd / "fc.out").is_file():
                try:
                    self._run_phonon_chain(wd)
                except Exception as ex:  # noqa: BLE001
                    _fail(f"chaîne phonon (pré-requis matdyn) échouée : {ex}")
                    return
            matdyn_in = wd / "matdyn_bands.in"
            if not matdyn_in.is_file():
                _fail("matdyn_bands.in absent après la chaîne phonon.")
                return
            try:
                original = matdyn_in.read_text(encoding="utf-8", errors="replace")
                matdyn_in.write_text(
                    extend_matdyn_in_for_non_analytic(original, "BORN"),
                    encoding="utf-8",
                )
                from phonon_chain_qe import run_matdyn_bands as _rerun_matdyn
                _rerun_matdyn(
                    wd, cancel_event=self.cancel_event, proc_holder=self.proc_holder
                )
                self._append_log(
                    "[LO/TO] matdyn re-run avec non_analytic=.true. + BORN — "
                    "phonon.freq corrigé LO/TO."
                )
            except Exception as ex:  # noqa: BLE001
                _fail(f"re-run matdyn non-analytique : {ex}")
                return

            # ---- 5. Splitting LO/TO à Γ ---------------------------------
            try:
                split = parse_lo_to_splitting_at_gamma(
                    wd / "phonon.freq", born_data=di
                )
                for src_k, dst_k in (
                    ("splitting_cm-1", "lo_to_splitting_cm-1"),
                    ("lo_freq_cm-1", "lo_freq_cm-1"),
                    ("to_freq_cm-1", "to_freq_cm-1"),
                    ("n_optical_modes", "n_optical_modes"),
                ):
                    v = split.get(src_k)
                    if v is not None and di_section.get(dst_k) is None:
                        di_section[dst_k] = v
            except Exception as ex:  # noqa: BLE001
                self._append_log(
                    f"[LO/TO] parse splitting Γ : {ex} (toléré — BORN et "
                    "phonon.freq corrigé restent disponibles)."
                )
            di_section["lo_to_ok"] = True
            di_section.pop("lo_to_error", None)
            self._emit_step(
                "lo_to", "done",
                f"ε∞ + Z* + BORN + splitting Γ = "
                f"{di_section.get('lo_to_splitting_cm-1', '?')} cm⁻¹",
            )
            self.persist()
        except Exception as ex:  # noqa: BLE001
            # Ceinture finale : n'importe quel imprévu est absorbé (le job
            # P1 continue vers _post_process avec ses résultats élastiques).
            _fail(f"chaîne LO/TO interrompue : {ex}")

    def _resolve_pseudo_dir_for_lo_to(self, wd: Path) -> Path:
        """Dossier pseudos du run : ``pseudo_dir`` du scf.in, sinon cfg.PSEUDOS_DIR."""
        scf = wd / "scf.in"
        try:
            text = scf.read_text(encoding="utf-8", errors="replace") if scf.is_file() else ""
        except OSError:
            text = ""
        m = re.search(r"""(?im)^\s*pseudo_dir\s*=\s*['"]([^'"]+)['"]""", text)
        if m:
            p = Path(m.group(1)).expanduser()
            if p.is_dir():
                return p
        return Path(cfg.PSEUDOS_DIR)

    def _post_process_thermo_plots(self, wd: Path) -> None:
        """Tracés thermodynamiques (Cv/F, Cv vs Cp) — idempotent, best-effort."""
        try:
            from parsers.thermo_therm_dat import (
                find_therm_dat_files as _find_therm,
                pick_central_geometry as _pick_therm,
            )
            from eos_gnuplot import run_gnuplot_therm_dat as _plot_therm
            _tpath = _pick_therm(_find_therm(wd))
            if _tpath is not None:
                _trel = _tpath.resolve().relative_to(wd.resolve()).as_posix()
                _tres = _plot_therm(wd, dat_relpath=_trel)
                _set_plot_path(self.results, "thermo_cv", _tres["png_relpath"])
        except Exception:
            pass
        try:
            from parsers.thermo_derived import (
                enrich_thermo_and_dielectric as _enrich_thermo,
                write_cv_cp_dat as _write_cv_cp,
            )
            from eos_gnuplot import run_gnuplot_cv_cp_comparison as _plot_cv_cp

            _enrich_thermo(wd, self.results, force=True)
            _th = self.results.get("thermo") or {}
            for tk in ("curve_Cp_Ry_per_K", "curve_B_GPa", "Cp_curve_source"):
                if _th.get(tk) is not None:
                    _nest_set_force(self.results, f"thermo.{tk}", _th[tk])
            _dat_rel = _write_cv_cp(wd, _th)
            if _dat_rel:
                _cp_res = _plot_cv_cp(wd, dat_relpath=_dat_rel)
                _set_plot_path(self.results, "thermo_cv_cp", _cp_res["png_relpath"])
        except Exception:
            pass

    def _post_process(self, wd: Path):
        """Tracé E(V) si manquant, résumé fichiers générés. Le parsing live a
        déjà été déclenché par ``_intermediate_parse("after_thermo_pw")`` juste
        avant cet appel — on ne le ré-effectue pas ici (anti-redondance)."""
        try:
            run_gnuplot_eos(wd)
            _set_plot_path(self.results, "eos_ev", "1_eos_volumes/eos_ev.png")
        except Exception:
            pass

        # Juillet 2026 — C_ij(T) / modules VRH vs T (P3, et tout profil qui
        # produit un fichier tableau « elastic vs T »). Auparavant :
        # ``plots.elastic_vs_T`` était déclaré dans expected_results P3 mais
        # jamais peuplé (la tuile UI restait « pending » à vie) ; le tracé
        # n'était accessible que via la route manuelle
        # /api/workflow1/eos/gnuplot_elastic_vs_t ou la factsheet.
        # Best-effort : gnuplot absent / fichier illisible ⇒ silencieux.
        try:
            from parsers.elastic_t_dat_scan import (
                find_elastic_t_dat as _find_el_t_dat,
                parse_numeric_series_dat as _parse_series_dat,
            )
            _dat = _find_el_t_dat(wd)
            if _dat is not None:
                _tbl = _parse_series_dat(_dat)
                _ncol = int(_tbl.get("ncol") or 0)
                if not _tbl.get("error") and _ncol >= 2:
                    _rel = _dat.resolve().relative_to(wd.resolve()).as_posix()
                    _cols = list(_tbl.get("columns") or [])
                    _res_plot = run_gnuplot_elastic_temperature_dat(
                        wd,
                        dat_relpath=_rel,
                        ncol=_ncol,
                        column_labels=_cols if _cols else [f"y{i}" for i in range(_ncol)],
                        title="C_ij / modules élastiques vs T",
                    )
                    self.results.setdefault("plots", {})["elastic_vs_T"] = (
                        _res_plot["png_relpath"]
                    )
        except Exception as _exc:
            import logging as _lg
            _lg.getLogger("thermo_pw.pipeline").debug(
                "plot elastic_vs_T skipped: %s", _exc
            )

        # Juillet 2026 — thermodynamique QHA + Cv vs Cp (best-effort).
        try:
            self._post_process_thermo_plots(wd)
        except Exception as _exc:
            import logging as _lg
            _lg.getLogger("thermo_pw.pipeline").debug(
                "plot thermo skipped: %s", _exc
            )

        # Juillet 2026 — P4 ph_life : matérialise les 4 plots promis par le
        # catalogue (γ(ω), τ(ω), κ(T), Grüneisen) depuis les fichiers
        # colonnes produits par thermo_pw. Chaque tracé est indépendant et
        # best-effort (fichier absent → tuile UI reste « pending »).
        if self.profile_id == "P4":
            try:
                from eos_gnuplot import run_gnuplot_xy_dat as _plot_xy
                from parsers.phonon_lifetime import (
                    _find_first as _ph_find,
                    _CANDIDATE_LIFETIME_FILES as _LIF_FILES,
                    _CANDIDATE_KAPPA_FILES as _KAP_FILES,
                    _CANDIDATE_GRUNEISEN_FILES as _GRU_FILES,
                )

                def _rel_of(p: Path) -> str:
                    return p.resolve().relative_to(wd.resolve()).as_posix()

                _plots = self.results.setdefault("plots", {})
                _lif = _ph_find(wd, _LIF_FILES)
                if _lif is not None:
                    for _key, _using, _ylab, _title in (
                        ("phonon_linewidth", "1:2", "gamma (cm^-1)",
                         "Largeurs de raie anharmoniques gamma(omega)"),
                        ("phonon_lifetime", "1:3", "tau (ps)",
                         "Durees de vie des phonons tau(omega)"),
                    ):
                        try:
                            _r = _plot_xy(
                                wd, dat_relpath=_rel_of(_lif),
                                out_basename=f"{_key}_plot",
                                title=_title,
                                xlabel="omega (cm^-1)", ylabel=_ylab,
                                using=_using, style="points pt 7 ps 0.6",
                            )
                            _plots[_key] = _r["png_relpath"]
                        except Exception:  # noqa: BLE001
                            pass
                _kap = _ph_find(wd, _KAP_FILES)
                if _kap is not None:
                    try:
                        _r = _plot_xy(
                            wd, dat_relpath=_rel_of(_kap),
                            out_basename="kappa_lattice_plot",
                            title="Conductivite thermique du reseau kappa(T)",
                            xlabel="T (K)", ylabel="kappa (W/(m.K))",
                        )
                        _plots["kappa_lattice"] = _r["png_relpath"]
                    except Exception:  # noqa: BLE001
                        pass
                _gru = _ph_find(wd, _GRU_FILES)
                if _gru is not None:
                    try:
                        _r = _plot_xy(
                            wd, dat_relpath=_rel_of(_gru),
                            out_basename="gruneisen_plot",
                            title="Parametre de Gruneisen gamma(q,nu)",
                            xlabel="omega (cm^-1)", ylabel="gamma Gruneisen",
                            using="1:2", style="points pt 7 ps 0.6",
                        )
                        _plots["gruneisen"] = _r["png_relpath"]
                    except Exception:  # noqa: BLE001
                        pass
            except Exception as _exc:
                import logging as _lg
                _lg.getLogger("thermo_pw.pipeline").debug(
                    "plots P4 ph_life skipped: %s", _exc
                )

        _sanitize_plots_section(self.results)

        # PostScript -> PDF: convert residual *.ps to *.pdf (idempotent, no-op if gs missing).
        # Best-effort: missing gs / malformed .ps / permission denied must never
        # abort _post_process -- only enriches the artifacts panel with PDF siblings.
        try:
            from ps_to_pdf import convert_postscript_to_pdf as _convert_ps_to_pdf
            _conv = _convert_ps_to_pdf(wd)
            if _conv:
                n_ok = sum(1 for _p, _pdf, ok, _e in _conv if ok)
                self.results.setdefault("plots", {})["ps_to_pdf_conversions"] = n_ok
        except Exception as _exc:
            import logging as _lg
            _lg.getLogger("thermo_pw.pipeline").debug("ps_to_pdf skipped: %s", _exc)
        # Résumé super-light : chemins RELATIFS (work_dir) des fichiers clés
        # — l'API /api/pipeline/result_image les résout depuis work_dir, donc
        # il faut inclure le préfixe (« 1_eos_volumes/… ») pour matcher l'
        # `expected_results` côté front-end.
        known_relpaths = [
            "thermo_pw_run.out",
            "thermo_control",
            "scf.in",
            "pw_scf_V0_for_phonon.in",
            "ph.in",
            "ph_control",
            "q2r.in",
            "fc.out",
            "phonon.freq",
            "phonon.dos",
            "1_eos_volumes/eos_ev.png",
            "1_eos_volumes/eos_summary.json",
            "1_eos_volumes/scf_eq.in",
            "energy_files/output_el_cons.dat",
            "energy_files/elastic_constants_vs_T.dat",
            "elastic_constants_vs_T.dat",
            # Tracé C_ij(T) généré par _post_process (P3 — cf. plots.elastic_vs_T).
            "elastic_vs_T_plot.png",
            "elastic_vs_T_plot.pdf",
            # Tracés post-process juillet 2026 : thermo QHA (P2/P3/P4) + ph_life (P4).
            "thermo_qha_plot.png",
            "phonon_linewidth_plot.png",
            "phonon_lifetime_plot.png",
            "kappa_lattice_plot.png",
            "gruneisen_plot.png",
            # Proprietes electroniques (ichamp=3): NSCF + DOS + bandes (P1 a P5).
            "nscf.in",
            "nscf.out",
            "dos.in",
            "dos.out",

            "bands.in",
            "bands.out",
            "dos.dat",
            "edos.png",
            "ebands.png",
            # Proprietes optiques P5 — chaîne exhaustive (epsilon + TDDFPT turbo).
            "nscf_optic.in",
            "nscf_optic.out",
            "epsilon.in",
            "epsilon.out",
            "turbo_lanczos.in",
            "turbo_lanczos.out",
            "turbo_davidson.in",
            "turbo_davidson.out",
            # P5 extras — un journal par what= thermo_pw (sélectionné par
            # l'utilisateur). L'inclusion élargit la liste visible côté UI
            # (chips chips cliquables). On n'INVENTE pas le suffixe : chaque
            # entrée doit être listée explicitement pour matcher le catalogue.
            "thermo_pw_plot_bz.out",
            "thermo_pw_piezoelectric_tensor.out",
            "thermo_pw_magnetic_susceptibility.out",
            "thermo_pw_magnetoelectric_tensor.out",
            "thermo_pw_scf_dielectric.out",
            # Artefacts typiques des extras P5 (sortie directe des scripts thermo_pw).
            "BZ_plot.ps.gz",
            "BZ.txt",
            "output_piezo.dat",
            "magnetic_susceptibility.dat",
        ]     
        outputs: list[tuple[str, Path]] = []
        for rel in known_relpaths:
            p = wd / rel
            if p.is_file():
                outputs.append((rel, p))
        # Tri stable puis dédoublonnage (« elastic_constants_vs_T.dat » vs
        # « 1_eos_volumes/.../elastic_constants_vs_T.dat » → le plus profond
        # premier, le plus court gagne en cas d'égalité).
        seen = set()
        ordered: list[str] = []
        for rel, _p in sorted(outputs, key=lambda t: (t[0].count("/"), -len(t[0]))):
            base = rel.rsplit("/", 1)[-1]
            if base in seen:
                continue
            seen.add(base)
            ordered.append(rel)
        outputs = ordered
        # Chaîne optique P5 — exhaustive : epsilon.x + turbo_lanczos.x +
        # turbo_davidson.x produisent typiquement plusieurs .dat (epsNN_*.dat,
        # eelsNN_*.dat, jdos_*.dat pour epsilon ; chi*.dat, eigenvalues*.dat,
        # polarizability*.dat, spectrum*.dat pour turbo) qu'on greffe pour
        # rendre les chips cliquables côté UI. Anti-doublon via ``seen``.
        for p in sorted(set(
            list(wd.glob("eps*.dat"))
            + list(wd.glob("eels*.dat"))
            + list(wd.glob("jdos*.dat"))
            + list(wd.glob("chi*.dat"))
            + list(wd.glob("eigenvalues*.dat"))
            + list(wd.glob("polarizability*.dat"))
            + list(wd.glob("spectrum*.dat"))
            + list(wd.glob("turbo*.dat"))
        )):
            try:
                rel = str(p.relative_to(wd))
            except ValueError:
                rel = p.name
            base = p.name
            if base in seen or base in {"nscf_optic.in", "nscf_optic.out",
                                        "epsilon.in", "epsilon.out",
                                        "turbo_lanczos.in", "turbo_lanczos.out",
                                        "turbo_davidson.in", "turbo_davidson.out"}:
                # ``seen`` est alimenté AVANT ce bloc pour éviter ces doublons ;
                # on garde le guard explicite pour rendre le grep tolérant à
                # d'éventuelles évolutions du block ``known_relpaths``.
                continue
            ordered.append(rel)
            seen.add(base)

        # résultats EOS / Cij si disponibles
        cij_files = sorted([p.name for p in wd.glob("**/output_el_cons*.dat*")])
        if cij_files:
            self.results["elastic_dat_files"] = cij_files
        self.results["output_files"] = outputs
        self._append_log(f"Résultats clés : {len(outputs)} fichier(s) généré(s).")


# ----------------------------------------------------------------------------
# API Flask (Blueprint)
# ----------------------------------------------------------------------------


@bp.route("/api/pipeline/jobs/recover_zombies", methods=["POST"])
def recover_zombies():
    """Convertit en place TOUS les marqueurs ``running``/``queued`` dans work/
    en ``interrupted`` + expose la liste.

    Marche-bord : appelé après mise à jour de l'API pour nettoyer
    d'anciens jobs dont le worker n'existe plus. Idempotent.
    """
    try:
        work_root = cfg.WORK_ROOT.resolve()
    except OSError as ex:
        return jsonify({"error": f"work_root : {ex}"}), 500
    recovered: list[dict[str, Any]] = []
    for marker_path in work_root.glob("**/pipeline_api_job_state.json"):
        try:
            rel = marker_path.resolve().relative_to(work_root).as_posix()
        except ValueError:
            continue
        try:
            data = json.loads(marker_path.read_text(encoding="utf-8", errors="replace"))
        except (OSError, json.JSONDecodeError):
            continue
        st = str(data.get("status") or "")
        if st not in ("running", "queued", "started"):
            continue
        data["status"] = "interrupted"
        from datetime import datetime as _dt, timezone as _tz
        ts = _dt.now(_tz.utc).isoformat(timespec="seconds")
        data["message"] = (
            "Reprise : worker précédent perdu. "
            "Relancez le calcul via /api/pipeline/run."
        )
        logs = list(data.get("logs") or [])
        logs.append(f"[{ts}] recover_zombies API : statut « {st} » → « interrupted ».")
        data["logs"] = logs[-200:]
        data["finished_at"] = ts
        try:
            marker_path.write_text(
                json.dumps(data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except OSError:
            continue
        recovered.append({
            "job_id": data.get("job_id"),
            "marker": rel,
            "previous_status": st,
            "previous_finished_at": None,
        })
    return jsonify({
        "ok": True,
        "recovered_count": len(recovered),
        "recovered": recovered,
        "hint": "Relancez l'API pour que ces changements prennent effet "
        "dans le registre en mémoire (from_dict ré-appliqué).",
    }), 200

# Clés empruntables entre profils (structure électronique + phonons DFPT communs).
_SHARED_PREVIEW_PROP_KEYS: tuple[str, ...] = (
    "fermi_eV", "vbm_eV", "cbm_eV", "band_gap_eV", "band_gap_type",
    "gap_direct", "n_bands", "bands_ok", "dos_ok", "nscf_ok", "ichamp",
    "dynamically_stable", "n_imaginary_modes", "min_freq_cm-1",
)
_SHARED_PREVIEW_PLOT_KEYS: tuple[str, ...] = (
    "ebands", "edos", "phonon_bands", "phonon_dos",
)


def _pick_shared_preview_results(results: dict[str, Any]) -> dict[str, Any]:
    """Sous-ensemble ``results`` réutilisable par P2..P5 depuis un run P1 (ou autre)."""
    out: dict[str, Any] = {}
    props = (results or {}).get("properties") or {}
    if isinstance(props, dict):
        picked = {k: props[k] for k in _SHARED_PREVIEW_PROP_KEYS if k in props}
        if picked:
            out["properties"] = picked
    plots = (results or {}).get("plots") or {}
    if isinstance(plots, dict):
        picked_plots = {k: plots[k] for k in _SHARED_PREVIEW_PLOT_KEYS if plots.get(k)}
        if picked_plots:
            out["plots"] = picked_plots
    mag = (results or {}).get("magnetism") or {}
    if isinstance(mag, dict) and any(v is not None for v in mag.values()):
        out["magnetism"] = dict(mag)
    return out


def _find_shared_preview_donor(
    work_root: Path,
    material_id: str,
) -> Optional[dict[str, Any]]:
    """Cherche le meilleur run ``done`` pour emprunter des résultats communs."""
    mat = (material_id or "").strip()
    if not mat or not work_root.is_dir():
        return None
    candidates: list[tuple[int, float, dict[str, Any]]] = []
    try:
        markers = sorted(
            work_root.rglob("pipeline_api_job_state.json"),
            key=lambda p: p.stat().st_mtime if p.is_file() else 0,
            reverse=True,
        )
    except OSError:
        return None
    for marker_path in markers:
        try:
            raw = json.loads(
                marker_path.read_text(encoding="utf-8", errors="replace")
            )
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(raw, dict):
            continue
        if str(raw.get("material_id") or "").strip() != mat:
            continue
        if str(raw.get("status") or "").strip() != "done":
            continue
        pid = str(raw.get("profile_id") or "").strip()
        score = 0
        if pid == "P1":
            score += 100
        props = ((raw.get("results") or {}).get("properties") or {})
        if props.get("bands_ok") or props.get("band_gap_eV") is not None:
            score += 50
        if props.get("fermi_eV") is not None:
            score += 10
        try:
            mtime = marker_path.stat().st_mtime
        except OSError:
            mtime = 0.0
        candidates.append((score, mtime, raw))
    if not candidates:
        return None
    candidates.sort(key=lambda t: (t[0], t[1]), reverse=True)
    return candidates[0][2]


@bp.route("/api/pipeline/shared_preview", methods=["GET"])
def shared_preview():
    """Emprunte structure électronique + phonons depuis un run existant (ex. P1 → P2).

    Utile quand l'utilisateur n'a pas encore lancé P2..P5 : la section ④ peut
    pré-remplir les métriques/plots communs (E_F, gap, ebands, phonons) depuis
    le dernier run ``done`` du même matériau (priorité P1).
    """
    material_id = (request.args.get("material_id") or "").strip()
    target_profile = (request.args.get("profile_id") or "P2").strip().upper()
    if not material_id:
        return jsonify({"error": "material_id requis"}), 400
    if target_profile == "P1":
        return jsonify({
            "borrowed": False,
            "material_id": material_id,
            "target_profile_id": target_profile,
            "reason": "P1 est le profil source — pas d'emprunt.",
        })
    try:
        work_root = cfg.WORK_ROOT.resolve()
    except OSError as ex:
        return jsonify({"error": f"work_root : {ex}"}), 500
    donor = _find_shared_preview_donor(work_root, material_id)
    if donor is None:
        return jsonify({
            "borrowed": False,
            "material_id": material_id,
            "target_profile_id": target_profile,
            "reason": f"Aucun run terminé pour {material_id}.",
        })
    results = dict(donor.get("results") or {})
    wd_raw = str(donor.get("work_dir") or "")
    work_dir: Optional[Path] = None
    if wd_raw:
        try:
            work_dir = Path(wd_raw).expanduser().resolve()
        except OSError:
            work_dir = None
        if work_dir is None or not work_dir.is_dir():
            try:
                work_dir = (work_root / wd_raw).resolve()
            except OSError:
                work_dir = None
    if work_dir and work_dir.is_dir():
        try:
            from factsheet import _enrich_results_from_workdir

            results = _enrich_results_from_workdir(work_dir, results)
        except Exception:  # noqa: BLE001
            pass
    borrowed = _pick_shared_preview_results(results)
    if not borrowed:
        return jsonify({
            "borrowed": False,
            "material_id": material_id,
            "target_profile_id": target_profile,
            "reason": "Run trouvé mais sans données électroniques/phonons exploitables.",
        })
    src_pid = str(donor.get("profile_id") or "?")
    src_jid = str(donor.get("job_id") or "")
    return jsonify({
        "borrowed": True,
        "material_id": material_id,
        "target_profile_id": target_profile,
        "source_job_id": src_jid,
        "source_profile_id": src_pid,
        "results": borrowed,
        "note": (
            f"Données partagées depuis {src_pid} ({src_jid[:8]}) — "
            "électronique + phonons communs à tous les profils. "
            f"Lancez {target_profile} pour EOS / thermo / extras spécifiques."
        ),
    })


@bp.route("/api/pipeline/runs", methods=["GET"])
def list_pipeline_runs():
    """Liste tous les runs persistés (en mémoire + markers disque).

    But : permettre à la section ④ « Résultats » d'être revisitée à
    tout moment — l'utilisateur choisit un run précédent et son
    rendu est reconstitué sans relancer le moindre calcul.

    Sources combinées et dédupliquées par ``job_id`` :
      1. ``PipelineJob._REGISTRY`` (runs vivants ou récemment terminés,
         récents mais potentiellement perdus si l'API a redémarré).
      2. ``<WORK_ROOT>/**/pipeline_api_job_state.json`` (persistance
         disque — survit aux redémarrages API, coupures, etc.).

    Chaque entrée expose les champs nécessaires au picker UI :
    ``job_id``, ``material_id``, ``profile_id``, ``profile_name``,
    ``profile_emoji``, ``status``, ``message``, ``work_dir`` (relatif
    à ``WORK_ROOT`` quand possible), ``finished_at``, ``created_at``,
    ``source`` (``"memory"`` ou ``"disk"``), ``label`` (texte prêt
    à afficher dans le `<option>`).

    Tri : plus récent d'abord (par ``finished_at`` ou ``created_at``).
    """
    try:
        work_root = cfg.WORK_ROOT.resolve()
    except OSError as ex:
        return jsonify({"error": f"work_root : {ex}"}), 500

    def _relpath(wd_str: str) -> str:
        if not wd_str:
            return ""
        try:
            p = Path(wd_str).expanduser().resolve()
            return p.relative_to(work_root).as_posix()
        except (ValueError, OSError):
            return wd_str

    def _label(rec: dict[str, Any]) -> str:
        """Texte court affiché dans le picker (« P2 Si · QHA · terminé il y a 2h »)."""
        try:
            pf = str(rec.get("profile_id") or "").strip() or "?"
            mat = str(rec.get("material_id") or "").strip() or "?"
            st = str(rec.get("status") or "unknown").strip()
            finished = rec.get("finished_at") or rec.get("created_at") or ""
        except Exception:  # noqa: BLE001
            return rec.get("job_id", "?")
        # Petit texte de durée relative (français).
        def _ago(iso_ts: str) -> str:
            if not iso_ts:
                return ""
            try:
                # tolère les deux formats ISO avec et sans suffixe « Z ».
                ts = iso_ts.replace("Z", "+00:00")
                dt = datetime.fromisoformat(ts)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
            except (ValueError, TypeError):
                return ""
            delta = datetime.now(timezone.utc) - dt
            secs = int(delta.total_seconds())
            if secs < 0:
                return "à venir"
            if secs < 60:
                return f"il y a {secs}s"
            m = secs // 60
            if m < 60:
                return f"il y a {m} min"
            h = m // 60
            if h < 36:
                return f"il y a {h} h"
            d = h // 24
            if d < 30:
                return f"il y a {d} j"
            return dt.strftime("%d/%m/%Y")
        when = _ago(finished)
        # Libellé statut court (cohérent avec rest of UI).
        st_short = {
            "done": "✓",
            "error": "✗",
            "cancelled": "⊘",
            "interrupted": "⏸",
            "running": "●",
            "queued": "○",
        }.get(st, st)
        parts = [pf, mat]
        label = " · ".join(parts) + f" · {st_short}"
        if when:
            label += f" · {when}"
        return label

    def _shape(rec: dict[str, Any], source: str) -> dict[str, Any]:
        wd = rec.get("work_dir") or ""
        return {
            "job_id": str(rec.get("job_id") or ""),
            "material_id": str(rec.get("material_id") or ""),
            "profile_id": str(rec.get("profile_id") or ""),
            "profile_name": str(rec.get("profile_name") or ""),
            "profile_emoji": str(rec.get("profile_emoji") or ""),
            "scf_in_basename": str(rec.get("scf_in_basename") or ""),
            "nproc": int(rec.get("nproc") or 1),
            "status": str(rec.get("status") or "unknown"),
            "message": str(rec.get("message") or ""),
            "work_dir": wd,
            "work_dir_rel": _relpath(wd) if wd else "",
            "created_at": str(rec.get("created_at") or ""),
            "finished_at": str(rec.get("finished_at") or ""),
            "source": source,
            "label": _label(rec),
        }

    items: list[dict[str, Any]] = []
    seen: set[str] = set()

    # 1. Mémoire (priorité — mêmes données mais + fraîches).
    with PipelineJob._REGISTRY_LOCK:
        mem_items = list(PipelineJob._REGISTRY.values())
    for job in mem_items:
        d = job.to_dict()
        shaped = _shape(d, "memory")
        jid = shaped["job_id"]
        if jid and jid not in seen:
            seen.add(jid)
            items.append(shaped)

    # 2. Markers disque (rate-limit optionnel ?limit=N).
    try:
        # `request.args.get("limit", "50")` garantit une chaîne (jamais None) → `.strip()` toujours appelable ;
        # le repli `or 50` absorbe la chaîne vide (`?limit=` sans valeur). Le try/except gère les valeurs non entières (`?limit=abc`).
        limit = int(request.args.get("limit", "50").strip() or 50)
    except (TypeError, ValueError):
        limit = 50
    limit = max(1, min(500, limit))

    if work_root.is_dir():
        # glob rglob : collecte TOUS les markers sous work_root.
        try:
            markers = sorted(
                work_root.rglob("pipeline_api_job_state.json"),
                key=lambda p: p.stat().st_mtime if p.is_file() else 0,
                reverse=True,
            )
        except OSError:
            markers = []
        for marker_path in markers:
            try:
                raw = json.loads(
                    marker_path.read_text(encoding="utf-8", errors="replace")
                )
            except (OSError, json.JSONDecodeError):
                continue
            if not isinstance(raw, dict):
                continue
            # Inférence du work_dir depuis le chemin du marker.
            raw["work_dir"] = str(marker_path.parent)
            shaped = _shape(raw, "disk")
            jid = shaped["job_id"]
            if not jid or jid in seen:
                continue
            seen.add(jid)
            items.append(shaped)
            if len(items) >= limit:
                break

    # Tri final : plus récent d'abord. ``finished_at`` prime sur
    # ``created_at`` (un run interrompu n'a souvent que created_at).
    items.sort(
        key=lambda d: (
            d.get("finished_at") or d.get("created_at") or "",
        ),
        reverse=True,
    )
    return jsonify({"runs": items, "count": len(items)})

@bp.route("/api/pipeline/runs/<job_id>/load", methods=["POST", "GET"])
def load_pipeline_run(job_id: str):
    """Charge (en mémoire) un run persisté sur disque par son ``job_id``.

    Trois cas :
      * Le job est **déjà en mémoire** (l'API n'a pas redémarré depuis
        la fin du job) → on s'assure que ``work_dir`` pointe bien sur
        le marker disque trouvé puis on renvoie le ``to_dict``.
      * Le job est inconnu en mémoire mais existe comme marker disque
        → on reconstruit via ``PipelineJob.from_dict`` (qui force le
        statut ``interrupted`` si le marker disque dit ``running`` ou
        ``queued`` — cas du worker orphelin après redémarrage). On
        fixe ``work_dir`` au dossier parent du marker.
      * Pas de marker correspondant → 404 explicite.

    Effet de bord positif : après l'appel, ``/api/pipeline/result_image``
    et ``/api/pipeline/result_file`` fonctionnent pour ce ``job_id``
    (ce qui rend les chips / plots cliquables de la section ④ exploitables).
    """
    try:
        work_root = cfg.WORK_ROOT.resolve()
    except OSError as ex:
        return jsonify({"error": f"work_root : {ex}"}), 500

    # Résolution du marker disque correspondant au job_id.
    candidate_marker: Optional[Path] = None
    if work_root.is_dir():
        for marker in work_root.rglob("pipeline_api_job_state.json"):
            try:
                raw = json.loads(
                    marker.read_text(encoding="utf-8", errors="replace")
                )
            except (OSError, json.JSONDecodeError):
                continue
            if str(raw.get("job_id") or "") == job_id:
                candidate_marker = marker
                break

    if candidate_marker is None:
        # Pas sur disque — vérifier le registre en mémoire au cas où.
        with PipelineJob._REGISTRY_LOCK:
            job_in_mem = PipelineJob._REGISTRY.get(job_id)
        if job_in_mem is not None:
            return jsonify({**job_in_mem.to_dict(), "source": "memory"})
        return jsonify({
            "error": "job_id introuvable sur disque et en mémoire",
            "hint": (
                "Le run a peut-être été supprimé manuellement, ou il "
                "n'a jamais atteint l'étape « persist() » (work_dir)."
            ),
        }), 404

    work_dir_path = candidate_marker.parent
    # Sécurité : bornage sous WORK_ROOT.
    try:
        work_dir_path.resolve().relative_to(work_root)
    except ValueError:
        return jsonify({"error": "work_dir hors zone autorisée."}), 403

    # Cas A : déjà en mémoire (même work_dir confirmé).
    with PipelineJob._REGISTRY_LOCK:
        existing = PipelineJob._REGISTRY.get(job_id)
    if existing is not None:
        existing.work_dir = work_dir_path
        try:
            existing._intermediate_parse(work_dir_path, "reparse_on_load")
        except Exception:
            pass
        persisted = existing.persist()
        return jsonify({
            **existing.to_dict(),
            "source": "memory",
            "loaded_from": str(work_dir_path),
            "reparsed_on_load": True,
        }), 200

    # Cas B : reconstruction depuis le marker disque.
    try:
        raw = json.loads(
            candidate_marker.read_text(encoding="utf-8", errors="replace")
        )
    except (OSError, json.JSONDecodeError) as ex:
        return jsonify({"error": f"marker illisible : {ex}"}), 500
    if not isinstance(raw, dict):
        return jsonify({"error": "marker corrompu (dict attendu)."}), 500

    job = PipelineJob.from_dict(raw)
    # ``from_dict`` met work_dir = None → on réinjecte le bon chemin.
    job.work_dir = work_dir_path
    try:
        job._intermediate_parse(work_dir_path, "reparse_on_load")
    except Exception:
        pass
    try:
        job.persist()
    except OSError:
        pass
    return jsonify({
        **job.to_dict(),
        "source": "disk",
        "loaded_from": str(work_dir_path),
        "reparsed_on_load": True,
    }), 200

@bp.route("/api/pipeline/jobs/<job_id>/reparse", methods=["POST"])
def reparse_pipeline_job(job_id: str):
    """Re-parse les sorties d'un job existant SANS relancer MPI.

    Delegated to ``PipelineJob._intermediate_parse`` which encodes
    the silent fall-through requested by the user :

      * lit ``thermo_pw_run.out`` quand present ;
      * tente TOUJOURS ensuite ``merge_elastic_from_output_el_cons_files(wd)``
        pour peupler C11/C12/C44 depuis les ``output_el_cons.dat.gN``
        meme quand ``thermo_pw_run.out`` est absent (cas run interrompu) ;
      * pose ``results._reparse.elastic_source = "fallback_per_strain_gN"``
        dans cette branche (badge UI « Apercu partiel ») ;
      * pose ``results._reparse.thermo_pw_run_missing = True`` et log diagnostic ;
      * pose systematiquement ``results._reparse.last_reparse_utc``.

    Codes de retour :
      * 200 + {ok, job_id, work_dir, results} -> reparse fructueux.
      * 404 si ``job_id`` inconnu du registre memoire (cas zombie ; faire
             d'abord ``POST /api/pipeline/runs/<id>/load``).
      * 409 si ``work_dir`` absent du registre (job running sans dossier).
      * 500 si exception non geree : ``exception`` class name expose cote UI.

    Idempotent : re-appelable sans relancer MPI.
    """
    from flask import current_app  # noqa: WPS433
    job = PipelineJob._REGISTRY.get(job_id)
    if job is None:
        return jsonify({"error": "job_inconnu", "job_id": job_id}), 404
    if not job.work_dir:
        return jsonify({
            "error": "work_dir absent du registre en memoire",
            "job_id": job_id,
            "hint": "Charger le marker disque via POST /api/pipeline/runs/<id>/load.",
        }), 409
    try:
        job._intermediate_parse(Path(job.work_dir), "reparse_via_route")
        return jsonify({
            "ok": True,
            "job_id": job_id,
            "work_dir": str(job.work_dir),
            "results": job.results,
        }), 200
    except (RuntimeError, FileNotFoundError) as exc:
        current_app.logger.warning(
            "[reparse_pipeline_job] %s job_id=%s : %s",
            type(exc).__name__, job_id, exc,
        )
        return jsonify({
            "ok": False, "error": str(exc), "job_id": job_id,
            "status": getattr(job, "status", "unknown"),
        }), 409
    except Exception as exc:  # noqa: BLE001
        current_app.logger.exception(
            "[reparse_pipeline_job] unexpected error job_id=%s", job_id,
        )
        return jsonify({
            "ok": False, "error": "internal",
            "exception": exc.__class__.__name__, "job_id": job_id,
        }), 500

@bp.route("/api/pipeline/jobs/<job_id>/retry_bands", methods=["POST"])
def retry_bands_pipeline_job(job_id: str):
    """Relance la chaîne bandes (pw.x BANDS + bands.x) sans refaire NSCF/DOS.

    Utile quand un job ``done`` a ``properties.bands_ok=false`` (bug ibrav
    corrigé) mais ``nscf.in`` / ``dos.dat`` sont déjà sur disque.
    """
    job = PipelineJob._REGISTRY.get(job_id)
    if job is None:
        return jsonify({"error": "job_inconnu", "job_id": job_id}), 404
    if not job.work_dir:
        return jsonify({
            "error": "work_dir absent du registre en memoire",
            "job_id": job_id,
            "hint": "Charger le marker disque via POST /api/pipeline/runs/<id>/load.",
        }), 409
    if job.status == "running":
        return jsonify({
            "ok": False,
            "error": "Job en cours — retry bandes impossible pendant l'exécution.",
            "job_id": job_id,
            "status": job.status,
        }), 409
    try:
        payload = job.retry_bands()
    except FileNotFoundError as exc:
        return jsonify({"ok": False, "error": str(exc), "job_id": job_id}), 404
    except Exception as exc:  # noqa: BLE001
        return jsonify({
            "ok": False,
            "error": "internal",
            "exception": exc.__class__.__name__,
            "job_id": job_id,
        }), 500
    return jsonify({
        "ok": payload.get("ok", False),
        "job_id": job_id,
        "work_dir": job.work_dir,
        **payload,
    }), 200 if payload.get("ok") else 422

@bp.route("/api/pipeline/jobs/<job_id>/cancel", methods=["POST"])
def cancel_pipeline_job(job_id: str):
    """Annule un job running/queued. Le statut final sera ``cancelled``."""
    job = PipelineJob._REGISTRY.get(job_id)
    if job is None:
        return jsonify({"error": "job_inconnu", "job_id": job_id}), 404
    if job.status not in ("running", "queued", "started"):
        return jsonify({
            "ok": False,
            "error": f"Seul un job running/queued peut être annulé (statut : {job.status!r}).",
            "job_id": job_id,
            "status": job.status,
        }), 409
    job.interrupt_intent = None
    job.cancel_event.set()
    killed = job.kill_active_processes()
    job.message = "Annulation demandée — arrêt en cours…"
    return jsonify({
        "ok": True,
        "job_id": job_id,
        "status": job.status,
        "message": job.message,
        "step": "cancel_requested",
        "killed_processes": killed,
    })


@bp.route("/api/pipeline/jobs/<job_id>/pause", methods=["POST"])
def pause_pipeline_job(job_id: str):
    """Met en pause un job running/queued. Reprise via /resume."""
    job = PipelineJob._REGISTRY.get(job_id)
    if job is None:
        return jsonify({"error": "job_inconnu", "job_id": job_id}), 404
    try:
        job.request_pause()
    except RuntimeError as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
            "job_id": job_id,
            "status": job.status,
        }), 409
    return jsonify({
        "ok": True,
        "job_id": job_id,
        "status": job.status,
        "message": job.message,
        "step": "pause_requested",
    })


@bp.route("/api/pipeline/jobs/<job_id>/stop", methods=["POST"])
def stop_pipeline_job(job_id: str):
    """Arrêt définitif d'un job (work_dir conservé, non reprenable)."""
    job = PipelineJob._REGISTRY.get(job_id)
    if job is None:
        return jsonify({"error": "job_inconnu", "job_id": job_id}), 404
    try:
        job.request_stop()
    except RuntimeError as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
            "job_id": job_id,
            "status": job.status,
        }), 409
    return jsonify({
        "ok": True,
        "job_id": job_id,
        "status": job.status,
        "message": job.message,
        "step": "stop_requested",
    })


@bp.route("/api/pipeline/jobs/<job_id>/resume", methods=["POST"])
def resume_pipeline_job(job_id: str):
    """Reprend un job en pause. Relance le runner sur le même work_dir."""
    job = PipelineJob._REGISTRY.get(job_id)
    if job is None:
        return jsonify({"error": "job_inconnu", "job_id": job_id}), 404
    try:
        job.request_resume()
    except (RuntimeError, FileNotFoundError) as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
            "job_id": job_id,
            "status": job.status,
        }), 409
    return jsonify({
        "ok": True,
        "job_id": job_id,
        "status": job.status,
        "message": job.message,
        "step": "resume_requested",
    })


@bp.route("/api/pipeline/jobs/<job_id>/restart", methods=["POST"])
def restart_pipeline_job(job_id: str):
    """Relance intelligente d'un job interrupted/error/cancelled.

    Delegué a ``PipelineJob.request_restart()`` (restart intelligent).
    Semantique :
      * status in {interrupted, error, cancelled} REQUIS (paused
        passe par request_resume via /resume).
      * work_dir + marker pipeline_api_job_state.json doivent
        etre presents sur disque (sinon FileNotFoundError -> 409).
      * reset cancel_event + finished_at + user_work_dir ;
        lance un nouveau thread _execute sur le meme work_dir ;
        les sub-steps marquees DONE dans workflow_state.json sont
        sautees automatiquement.
    """
    job = PipelineJob._REGISTRY.get(job_id)
    if job is None:
        return jsonify({"error": "job_inconnu", "job_id": job_id}), 404
    if job.status in ("running", "queued"):
        return jsonify({
            "ok": False,
            "error": "Le job est déjà en cours d'exécution.",
            "job_id": job_id,
            "status": job.status,
        }), 409
    try:
        job.request_restart()
    except (RuntimeError, FileNotFoundError) as exc:
        current_app.logger.warning(
            "[restart_pipeline_job] %s job_id=%s : %s",
            type(exc).__name__, job_id, exc,
        )
        return jsonify({
            "ok": False,
            "error": str(exc),
            "job_id": job_id,
            "status": job.status,
        }), 409
    except Exception as exc:  # noqa: BLE001
        current_app.logger.exception(
            "[restart_pipeline_job] unexpected error job_id=%s", job_id
        )
        return jsonify({"ok": False, "error": "internal", "exception": exc.__class__.__name__, "job_id": job_id}), 500
    return jsonify({
        "ok": True,
        "job_id": job_id,
        "status": job.status,
        "message": job.message,
        "step": "restart_requested",
    })


def _marker_record_for_job(job_id: str) -> Optional[dict[str, Any]]:
    """Retrouve sur disque le marqueur d'un job absent du registre mémoire."""
    try:
        work_root = cfg.WORK_ROOT.resolve()
    except OSError:
        return None
    if not work_root.is_dir():
        return None
    for marker in work_root.rglob(PipelineJob._MARKER_FILENAME):
        try:
            raw = json.loads(marker.read_text(encoding="utf-8", errors="replace"))
        except (OSError, json.JSONDecodeError):
            continue
        if str(raw.get("job_id") or "") == job_id:
            raw.setdefault("work_dir", str(marker.parent))
            return raw
    return None


def _load_job_for_action(job_id: str) -> Optional[PipelineJob]:
    """Registre mémoire, sinon reconstruction depuis le marker disque."""
    job = PipelineJob._REGISTRY.get(job_id)
    if job is not None:
        return job
    rec = _marker_record_for_job(job_id)
    if rec is None:
        return None
    job = PipelineJob.from_dict(rec)
    wd = rec.get("work_dir")
    if wd:
        job.work_dir = Path(wd)
    raw_status = str(rec.get("status") or job.status)
    if raw_status not in ("running", "queued", "started"):
        job.status = raw_status
    PipelineJob._register(job)
    return job


@bp.route("/api/pipeline/jobs/<job_id>/resume_thermo_pw/options", methods=["GET"])
def get_resume_thermo_pw_options(job_id: str):
    """Liste les cibles de reprise thermo_pw disponibles (P1–P5)."""
    job = _load_job_for_action(job_id)
    if job is None:
        rec = _marker_record_for_job(job_id)
        if rec is None:
            return jsonify({"error": "job_inconnu", "job_id": job_id}), 404
        work_dir = Path(str(rec.get("work_dir") or ""))
        profile_id = str(rec.get("profile_id") or "P2")
        extra_whats = list(rec.get("extra_whats") or [])
        needs_optical = bool(rec.get("needs_optical"))
        lo_to = bool(rec.get("lo_to_opt_in"))
        results = rec.get("results") or {}
        status = str(rec.get("status") or "")
    else:
        work_dir = Path(job.work_dir) if job.work_dir else Path()
        profile_id = job.profile_id
        extra_whats = list(getattr(job, "extra_whats", []) or [])
        needs_optical = bool(job.profile.get("needs_optical"))
        lo_to = bool(getattr(job, "lo_to_opt_in", False))
        results = job.results or {}
        status = job.status
    if not work_dir.is_dir():
        return jsonify({
            "job_id": job_id,
            "status": status,
            "targets": [],
            "error": "work_dir_absent",
        }), 200
    targets = thermo_pw_resume.list_resume_targets(
        profile_id=profile_id,
        work_dir=work_dir,
        extra_whats=extra_whats,
        needs_optical=needs_optical,
        lo_to_opt_in=lo_to,
        results=results,
    )
    ok, msg = thermo_pw_resume.phonon_prereqs_ok(work_dir)
    qha_ls_fail = thermo_pw_resume.detect_qha_least_squares_failure(work_dir)
    tc_hints = thermo_pw_resume.read_thermo_control_qha_hints(work_dir)
    return jsonify({
        "job_id": job_id,
        "status": status,
        "profile_id": profile_id,
        "work_dir": str(work_dir),
        "phonon_prereqs_ok": ok,
        "phonon_prereqs_message": msg if not ok else "",
        "qha_least_squares_failed": qha_ls_fail,
        "lsolve_supported": profile_id in thermo_pw_resume.QHA_PROFILES,
        "suggest_lsolve": 1 if qha_ls_fail else None,
        "suggest_deltat": 100 if qha_ls_fail else None,
        "default_therm_mode": thermo_pw_resume.default_therm_mode_for_profile(profile_id),
        "thermo_control_hints": tc_hints,
        "targets": [t.to_dict() for t in targets],
    })


@bp.route("/api/pipeline/jobs/<job_id>/resume_thermo_pw", methods=["POST"])
def resume_thermo_pw_pipeline_job(job_id: str):
    """Reprend thermo_pw (et aval) sans refaire EOS / phonons."""
    data = request.get_json(silent=True) or {}
    target = str(data.get("target") or "thermo_main").strip() or "thermo_main"
    job = _load_job_for_action(job_id)
    if job is None:
        return jsonify({"error": "job_inconnu", "job_id": job_id}), 404
    try:
        thermo_overrides = thermo_pw_resume.parse_resume_thermo_overrides(
            data,
            profile_id=job.profile_id,
        )
    except ValueError as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
            "job_id": job_id,
        }), 400
    if job.status in ("running", "queued"):
        return jsonify({
            "ok": False,
            "error": "Le job est déjà en cours d'exécution.",
            "job_id": job_id,
            "status": job.status,
        }), 409
    try:
        job.request_resume_thermo_pw(target=target, thermo_overrides=thermo_overrides)
    except (RuntimeError, FileNotFoundError, ValueError) as exc:
        return jsonify({
            "ok": False,
            "error": str(exc),
            "job_id": job_id,
            "status": job.status,
        }), 409
    except Exception as exc:  # noqa: BLE001
        current_app.logger.exception(
            "[resume_thermo_pw_pipeline_job] job_id=%s", job_id
        )
        return jsonify({
            "ok": False,
            "error": "internal",
            "exception": exc.__class__.__name__,
            "job_id": job_id,
        }), 500
    return jsonify({
        "ok": True,
        "job_id": job_id,
        "status": job.status,
        "message": job.message,
        "target": target,
        "thermo_overrides": thermo_overrides,
        "step": "resume_thermo_pw_requested",
    })


@bp.route("/api/pipeline/jobs/<job_id>/resume_diagnosis", methods=["GET"])
def get_resume_diagnosis(job_id: str):
    """Inspecte un run avant reprise et dit si celle-ci a un sens.

    « Reprendre » saute les étapes marquées terminées, ce qui est souhaitable
    après une coupure et néfaste après un défaut de configuration : les étapes
    fautives portent justement la marque « terminé ». Cette route existe pour
    que l'interface pose la question avant d'agir, plutôt qu'après.
    """
    job = PipelineJob._REGISTRY.get(job_id)
    work_dir = ""
    status = ""
    if job is not None:
        work_dir = str(job.work_dir or "")
        status = job.status
    else:
        rec = _marker_record_for_job(job_id)
        if rec is None:
            return jsonify({"error": "job_inconnu", "job_id": job_id}), 404
        work_dir = str(rec.get("work_dir") or "")
        status = str(rec.get("status") or "")
    if not work_dir or not Path(work_dir).is_dir():
        return jsonify({
            "job_id": job_id,
            "status": status,
            "work_dir": work_dir,
            "diagnosis": None,
            "error": "work_dir_absent",
        }), 200
    try:
        diag = resume_diagnosis.diagnose_run(Path(work_dir), status=status)
    except Exception:  # noqa: BLE001
        current_app.logger.exception(
            "[get_resume_diagnosis] échec du diagnostic job_id=%s", job_id
        )
        # Un diagnostic indisponible ne doit jamais bloquer une reprise légitime.
        return jsonify({
            "job_id": job_id,
            "status": status,
            "work_dir": work_dir,
            "diagnosis": None,
            "error": "diagnostic_indisponible",
        }), 200
    return jsonify({
        "job_id": job_id,
        "status": status,
        "work_dir": work_dir,
        "diagnosis": diag.to_dict(),
    })


@bp.route("/api/pipeline/runs/<job_id>", methods=["DELETE"])
def delete_pipeline_run(job_id: str):
    """
    Supprime un run persisté (juin 2026).

    Action **destructive** : retire le job du registre mémoire et supprime
    le répertoire ``work_dir`` correspondant (ainsi que le marker JSON).
    Un job en cours (``status`` ∈ {running, queued}) ne peut pas être
    supprimé directement — l'appelant doit d'abord l'annuler via
    ``POST /api/pipeline/jobs/<id>/cancel`` puis attendre que le statut
    passe à ``cancelled`` avant de redemander la suppression.

    Implémentation :
    * 1. Cherche le job en mémoire (``PipelineJob._REGISTRY``).
    * 2. Si absent en mémoire, cherche le marker disque et charge le work_dir.
    * 3. Vérifie que le job est terminé (status terminal).
    * 4. Retire du registre sous lock.
    * 5. ``shutil.rmtree(work_dir, ignore_errors=True)`` — best-effort.
    * 6. Retourne ``{"ok": true, "job_id": ..., "removed_from": ...}``.

    Sécurité :
    * ``job_id`` est validé (4-64 hex chars) avant toute I/O.
    * Le ``work_dir`` résolu doit rester sous ``cfg.WORK_ROOT`` pour
      éviter qu'un marker corrompu ne fasse supprimer un dossier
      arbitraire (``/etc``, ``/home/.../Documents``, etc.).
    """
    import re as _re_safe
    if not _re_safe.fullmatch(r"[0-9a-fA-F]{4,64}", job_id or ""):
        return jsonify({"error": "job_id invalide (attendu : 4-64 hex chars)"}), 400

    with PipelineJob._REGISTRY_LOCK:
        job = PipelineJob._REGISTRY.get(job_id)
        work_dir_path = job.work_dir if job else None
        status_now = job.status if job else None
        in_memory = job is not None

    if not work_dir_path:
        try:
            root = (cfg.WORK_ROOT).resolve()
            marker_name = PipelineJob._MARKER_FILENAME
            for marker in root.rglob(marker_name):
                try:
                    d = json.loads(marker.read_text(encoding="utf-8", errors="replace"))
                except (OSError, json.JSONDecodeError):
                    continue
                if d.get("job_id") != job_id:
                    continue
                wd_str = d.get("work_dir") or str(marker.parent)
                work_dir_path = Path(wd_str).resolve()
                status_now = d.get("status") or status_now
                break
        except OSError:
            pass

    if not work_dir_path:
        return jsonify({"error": f"job_id inconnu : {job_id!r}"}), 404

    if status_now in ("running", "queued", "started"):
        return jsonify({
            "error": (
                f"job {job_id!r} encore en cours (status={status_now!r}). "
                "Annulez-le d'abord via POST /api/pipeline/jobs/<id>/cancel, "
                "puis ré-essayez une fois le statut passé à 'cancelled'."
            ),
            "status": status_now,
        }), 409

    try:
        root_resolved = (cfg.WORK_ROOT).resolve()
        if root_resolved not in work_dir_path.resolve().parents and \
           work_dir_path.resolve() != root_resolved:
            return jsonify({
                "error": f"work_dir hors WORK_ROOT ({work_dir_path}) — suppression refusée pour sécurité.",
            }), 400
    except OSError:
        return jsonify({"error": "work_dir invalide (résolution impossible)"}), 400

    if in_memory:
        with PipelineJob._REGISTRY_LOCK:
            PipelineJob._REGISTRY.pop(job_id, None)

    try:
        shutil.rmtree(work_dir_path, ignore_errors=True)
        removed_from = "memory+disk" if in_memory else "disk"
    except OSError as ex:
        return jsonify({
            "error": f"suppression partielle : {ex}",
            "removed_from": "memory" if in_memory else "none",
        }), 500

    return jsonify({
        "ok": True,
        "job_id": job_id,
        "work_dir": str(work_dir_path),
        "status": status_now,
        "removed_from": removed_from,
    }), 200


# ----------------------------------------------------------------- #
# Juin 2026 — purge en lot des statuts TERMINAUX KO.                #
# Statuts ciblés : ``error``, ``cancelled``, ``interrupted``         #
# (terminal KO avec artefacts sur disque).                          #
# Les statuts ACTIFS (``running``, ``queued``, ``started``) sont     #
# silencieusement SKIPPÉS (race-safe) et reportés dans la réponse   #
# sous ``ignored_running``. ``dry_run=True`` liste sans supprimer.  #
# Le scan disque est COMPLET (work_root/**/pipeline_api_job_state.  #
# json) ; il n'est pas borné par la pagination ``limit=50`` du     #
# picker UI. ``material_id`` filtre côté backend (None = tous).      #
# ----------------------------------------------------------------- #
_PURGEABLE_STATUSES = frozenset({"error", "cancelled", "interrupted"})
_RUNNING_STATUSES = frozenset({"running", "queued", "started"})

def purge_failed_pipeline_runs(dry_run: bool = False, material_id: Optional[str] = None):
    """Supprime en lot les statuts terminaux KO.

    Retourne un dict :
      - ``dry_run``, ``material_id`` : echo des paramètres.
      - ``scanned`` : nombre total de markers disque trouvés.
      - ``eligible`` : nombre filtré (statut éliminable + material_id).
      - ``deleted`` : liste job_id effectivement supprimés.
      - ``ignored_running`` : liste job_id ACTIFS (à annuler d'abord).
      - ``already_gone`` : déjà supprimés (work_dir absent) — silencieux.
      - ``errors`` : [{"job_id", "work_dir", "error"}, ...].
      - ``kept_other_status`` : nombre de statuts non-cibles (``done``, …).
    """
    summary = {
        "dry_run": bool(dry_run),
        "material_id": (material_id or "").strip() or None,
        "scanned": 0,
        "eligible": 0,
        "deleted": [],
        "ignored_running": [],
        "already_gone": [],
        "errors": [],
        "kept_other_status": 0,
    }
    root = (cfg.WORK_ROOT).resolve()
    if not root.is_dir():
        return summary
    try:
        marker_paths = list(root.rglob(PipelineJob._MARKER_FILENAME))
    except OSError as ex:
        summary["errors"].append({"scan": True, "error": str(ex)})
        return summary
    summary["scanned"] = len(marker_paths)
    for marker_path in marker_paths:
        # Sécurité work_root relative.
        try:
            wd = marker_path.parent.resolve()
            wd.relative_to(root)
        except (OSError, ValueError):
            continue
        # Sécurité : si le dossier de run a été supprimé entre temps, on retire
        # le marker orphelin (''silent cleanup'').
        try:
            with marker_path.open("r", encoding="utf-8", errors="replace") as fh:
                raw = json.load(fh)
        except (OSError, json.JSONDecodeError) as ex:
            summary["errors"].append({
                "marker": str(marker_path),
                "error": f"marker illisible : {ex}",
            })
            continue
        job_id = (raw.get("job_id") or marker_path.parent.name or "").strip()
        status_now = str(raw.get("status") or "").lower()
        mid = (raw.get("material_id") or "").strip()
        # Filtre material_id (None = tous)
        if material_id and material_id.strip() and mid != material_id.strip():
            continue
        # Statut OK pour purge ?
        if status_now not in _PURGEABLE_STATUSES:
            summary["kept_other_status"] += 1
            continue
        summary["eligible"] += 1
        # Garde-running : le job est peut-être encore en mémoire côté
        # daemon API — silencieusement skip + report (race-safe).
        with PipelineJob._REGISTRY_LOCK:
            live = PipelineJob._REGISTRY.get(job_id)
        if live and str(getattr(live, "status", "") or "").lower() in _RUNNING_STATUSES:
            summary["ignored_running"].append({
                "job_id": job_id,
                "material_id": mid,
                "work_dir": str(wd),
                "status": str(getattr(live, "status", "") or "?"),
            })
            continue
        if dry_run:
            summary["deleted"].append({
                "job_id": job_id,
                "material_id": mid,
                "work_dir": str(wd),
                "status": status_now,
                "dry_run": True,
            })
            continue
        # Suppression effective : rmtree du work_dir (ignore_errors=True
        # pour ne PAS échouer si un fichier est déjà absent — phantom jobs).
        try:
            shutil.rmtree(wd, ignore_errors=True)
        except OSError as ex:
            summary["errors"].append({
                "job_id": job_id,
                "work_dir": str(wd),
                "error": f"rmtree : {ex}",
            })
            continue
        # Retire aussi du registre en mémoire (cohérence post-purge).
        if live:
            with PipelineJob._REGISTRY_LOCK:
                PipelineJob._REGISTRY.pop(job_id, None)
        # Note : on ne supprime pas le marker_pipeline_api_job_state.json
        # (déjà effacé via rmtree puisqu'il est dans wd). Tout est lié.
        summary["deleted"].append({
            "job_id": job_id,
            "material_id": mid,
            "work_dir": str(wd),
            "status": status_now,
        })
    return summary

@bp.route("/api/pipeline/runs/purge_failed", methods=["POST", "OPTIONS"])
def post_purge_failed_pipeline_runs():
    """Purge en lot les statuts terminaux KO (JSON body: dry_run?, material_id?).

    Cf. ``purge_failed_pipeline_runs()`` pour la sémantique complète.
    Retourne le rapport détaillé (``scanned``, ``deleted``, ``ignored_running``,
    ``already_gone``, ``errors``, ``dry_run``).
    """
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    dry_run = bool(data.get("dry_run", False))
    material_id = (data.get("material_id") or "").strip() or None
    report = purge_failed_pipeline_runs(
        dry_run=dry_run, material_id=material_id,
    )
    return jsonify(report), 200

# ---------- Vider les obsolètes ----------
# Combine deux nettoyages en une seule action UI :
#   1. Statuts terminaux KO (error / cancelled / interrupted / stopped)
#      dont le work_dir est encore sur disque : on supprime le marker
#      `pipeline_api_job_state.json` et l'entrée du registre.
#   2. Entrées du registre dont le work_dir a MANQUELLEMENT disparu
#      (l'utilisateur a effacé le dossier à la main) : on retire
#      l'entrée orpheline du registre en mémoire.
@bp.route("/api/pipeline/runs/purge_stale", methods=["POST", "OPTIONS"])
def post_purge_stale_pipeline_runs():
    """JSON body : ``{"dry_run": bool, "material_id"?: str}``.

    Retour :
      * ``deleted_from_registry`` — entrées retirées de
        ``PipelineJob._REGISTRY``.
      * ``deleted_from_disk`` — markers disque ``pipeline_api_job_state.json``
        effectivement supprimés (0 en dry_run).
      * ``already_missing`` — entrées orphelines (work_dir absent) déjà
        nettoyées ou qui auraient été nettoyées en dry_run.
      * ``ignored_running`` — job_ids actifs laissés intacts (l'utilisateur
        doit d'abord faire Pause/Stop/Annuler).
      * ``kept`` — entrées préservées (statut non-cible ou non-filtrable).
      * ``dry_run``, ``material_id`` — echo des paramètres.
      * ``errors`` — [{"job_id", "where", "work_dir", "error"}, ...].
    """
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    dry_run = bool(data.get("dry_run", False))
    material_id = (data.get("material_id") or "").strip() or None

    TERMINAL_BAD = ("error", "cancelled", "interrupted", "stopped")
    TERMINAL_OK = ("done", "paused")

    report = {
        "dry_run": dry_run,
        "material_id": material_id,
        "deleted_from_registry": 0,
        "deleted_from_disk": 0,
        "already_missing": 0,
        "ignored_running": [],
        "kept": 0,
        "errors": [],
    }

    with PipelineJob._REGISTRY_LOCK:
        snapshot = list(PipelineJob._REGISTRY.items())

    for job_id, job in snapshot:
        try:
            mid = (getattr(job, "material_id", None) or "").strip() or None
            if material_id and mid != material_id:
                continue
            wd = getattr(job, "work_dir", None)
            wd_str = str(wd) if wd else ""
            status = getattr(job, "status", "unknown")
            exists = bool(wd_str and os.path.isdir(wd_str))

            # Actif → laissé tel quel, juste signalé à l'UI
            if status in ("queued", "running", "started"):
                report["ignored_running"].append(job_id)
                continue

            # Cas 1 : terminal KO + work_dir existe → suppression marker+registre
            if status in TERMINAL_BAD and exists:
                if not dry_run:
                    with PipelineJob._REGISTRY_LOCK:
                        PipelineJob._REGISTRY.pop(job_id, None)
                    report["deleted_from_registry"] += 1
                    marker = os.path.join(wd_str, "pipeline_api_job_state.json")
                    try:
                        if os.path.isfile(marker):
                            os.remove(marker)
                            report["deleted_from_disk"] += 1
                    except Exception as e:
                        report["errors"].append({
                            "job_id": job_id, "where": "marker",
                            "work_dir": wd_str, "error": str(e),
                        })
                else:
                    report["deleted_from_registry"] += 1
                    report["deleted_from_disk"] += 1
                continue

            # Cas 2 : work_dir disparu (peu importe statut terminal)
            if not exists and status in TERMINAL_BAD + TERMINAL_OK:
                if not dry_run:
                    with PipelineJob._REGISTRY_LOCK:
                        PipelineJob._REGISTRY.pop(job_id, None)
                report["deleted_from_registry"] += 1
                report["already_missing"] += 1
                continue

            # Cas 3 : rien à faire
            report["kept"] += 1
        except Exception as e:
            report["errors"].append({
                "job_id": job_id, "where": "scan",
                "work_dir": str(getattr(job, "work_dir", "")),
                "error": str(e),
            })
    return jsonify(report), 200

# Vérification groupée d'existence des work_dir, pour l'enrichissement
# de la picker côté front (un seul round-trip au lieu de N HEAD).
@bp.route("/api/pipeline/runs/check_works", methods=["POST", "OPTIONS"])
def post_check_works():
    """JSON body : ``{"job_ids": [str, ...]}``.

    Retour : ``{"exists": {<job_id>: bool, ...}, "missing": [job_id, ...]}``.
    Un job_id inconnu reçoit ``False`` et apparaît dans ``missing``.
    """
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    ids_in = data.get("job_ids") or []
    if not isinstance(ids_in, list):
        return jsonify({"error": "job_ids doit être une liste."}), 400
    exists_map: dict[str, bool] = {}
    missing: list[str] = []
    for jid in ids_in:
        if not isinstance(jid, str):
            continue
        with PipelineJob._REGISTRY_LOCK:
            job = PipelineJob._REGISTRY.get(jid)
        if not job:
            exists_map[jid] = False
            missing.append(jid)
            continue
        wd = getattr(job, "work_dir", None)
        wd_str = str(wd) if wd else ""
        ok = bool(wd_str and os.path.isdir(wd_str))
        exists_map[jid] = ok
        if not ok:
            missing.append(jid)
    return jsonify({"exists": exists_map, "missing": missing}), 200


# Cache mémoire LRU pour ``GET …/sanity`` (évite de re-scanner le work_dir).
_sanity_cache: dict[tuple[str, int], dict[str, Any]] = {}
_sanity_cache_lock = threading.RLock()
_SANITY_CACHE_CAP = 64


def _resolve_persisted_run(job_id: str) -> tuple[Optional[Path], dict[str, Any], str]:
    """Retrouve ``(work_dir, results, profile_id)`` pour un job persisté."""
    with PipelineJob._REGISTRY_LOCK:
        job = PipelineJob._REGISTRY.get(job_id)
    if job is not None:
        wd = job.work_dir
        if wd is not None and wd.is_dir():
            return wd, job.results or {}, job.profile_id or ""
    try:
        root = cfg.WORK_ROOT.resolve()
    except OSError:
        root = None
    if root is not None and root.is_dir():
        for marker in root.rglob("pipeline_api_job_state.json"):
            try:
                raw = json.loads(
                    marker.read_text(encoding="utf-8", errors="replace")
                )
            except (OSError, json.JSONDecodeError):
                continue
            if str(raw.get("job_id") or "") == job_id:
                return marker.parent, raw.get("results") or {}, raw.get("profile_id") or ""
    return None, {}, ""


@bp.route("/api/pipeline/runs/<job_id>/sanity", methods=["GET"])
def get_pipeline_run_sanity(job_id: str):
    """
    Calcule les sanity checks scientifiques pour un run donné.

    Best-effort : chaque sous-check est ``try/except`` → ``level="unknown"``
    si fichier absent, parse impossible ou type invalide. Aucun check ne lève.

    Mise en cache mémoire simple (clé = ``(job_id, work_dir_mtime)``) pour
    éviter de re-scanner ``phonon.freq`` / ``pw.x .out`` à chaque polling
    1.5 s de l'UI. Cap LRU à 64 entrées (FIFO Python 3.7+).
    """
    try:
        from sanity_checks import compute_sanity
    except ImportError as ex:
        return jsonify({"error": f"sanity_checks non disponible : {ex}"}), 500

    work_dir, j_results, profile_id = _resolve_persisted_run(job_id)
    if work_dir is None or not work_dir.is_dir():
        return jsonify({"error": "job_id introuvable (work_dir absent)"}), 404

    # 2) Cache mémoire : clé = (job_id, mtime du work_dir) → invalide
    # automatiquement quand le run est complété (mtime change).
    try:
        mtime = int(work_dir.stat().st_mtime)
    except OSError:
        mtime = 0
    cache_key = (job_id, mtime)
    with _sanity_cache_lock:
        cached = _sanity_cache.get(cache_key)
    if cached is not None:
        return jsonify(cached)

    out = compute_sanity(work_dir, j_results, profile_id=profile_id)

    with _sanity_cache_lock:
        _sanity_cache[cache_key] = out
        if len(_sanity_cache) > _SANITY_CACHE_CAP:
            # FIFO drop oldest (Python 3.7+ dict order).
            first_key = next(iter(_sanity_cache))
            if first_key != cache_key:
                _sanity_cache.pop(first_key, None)
    return jsonify(out)


@bp.route("/api/pipeline/runs/<job_id>/expertise", methods=["GET"])
def get_pipeline_run_expertise(job_id: str):
    """
    Analyse experte rule-based (``factsheet_ai.compute_insights``) pour l'UI.

    Best-effort : renvoie une liste d'insights JSON sans générer le HTML/MD
    complet de la fiche technique.
    """
    try:
        from factsheet import assemble_factsheet
        from factsheet_ai import compute_insights
    except ImportError as ex:
        return jsonify({"error": f"moteur expert indisponible : {ex}"}), 500

    work_dir, j_results, profile_id = _resolve_persisted_run(job_id)
    if work_dir is None or not work_dir.is_dir():
        return jsonify({"error": "job_id introuvable (work_dir absent)"}), 404

    marker: dict[str, Any] = {}
    marker_path = work_dir / "pipeline_api_job_state.json"
    if marker_path.is_file():
        try:
            marker = json.loads(
                marker_path.read_text(encoding="utf-8", errors="replace")
            )
        except (OSError, json.JSONDecodeError):
            marker = {}

    try:
        from pipeline import PROFILES as _PIPELINE_PROFILES
        profile = _PIPELINE_PROFILES.get(profile_id) or {}
    except Exception:
        profile = {}

    if not profile_id or not profile:
        return jsonify({"error": f"profil inconnu : {profile_id!r}"}), 500

    try:
        fs = assemble_factsheet(
            work_dir=work_dir,
            profile_id=profile_id,
            profile=profile,
            results=j_results,
            marker_root=marker or None,
        )
        insights = compute_insights(fs, work_dir)
    except Exception as ex:  # noqa: BLE001
        return jsonify(
            {"error": "assemble_factsheet / compute_insights a échoué.", "detail": str(ex)}
        ), 500

    payload = {
        "job_id": job_id,
        "profile_id": profile_id,
        "insights": [
            {
                "level": i.level,
                "category": i.category,
                "title": i.title,
                "body": i.body,
                "icon": i.icon(),
            }
            for i in insights
        ],
        "summary": {
            "n_success": sum(1 for i in insights if i.level == "success"),
            "n_info": sum(1 for i in insights if i.level == "info"),
            "n_warning": sum(1 for i in insights if i.level == "warning"),
            "n_error": sum(1 for i in insights if i.level == "error"),
        },
    }
    return jsonify(payload)


@bp.route("/api/pipeline/result_image", methods=["GET", "HEAD"])
def get_result_image():
    """Servir une image générée sous work_dir/<job_id> (sécurité : chemin obligatoirement sous WORK_ROOT)."""
    from flask import Response, send_file
    _MAX_IMAGE_BYTES = 8 * 1024 * 1024  # 8 Mo — évite d'OOM le worker sur PNG géant
    raw_job = (request.args.get("job_id") or "").strip()
    rel = (request.args.get("path") or "").strip().lstrip("/")
    if not raw_job or not rel:
        return jsonify({"error": "job_id et path requis (query)."}), 400
    parts = rel.split("/")
    if not parts or any(p in (".", "..") or ".." in p for p in parts):
        return jsonify({"error": "path invalide."}), 400
    with PipelineJob._REGISTRY_LOCK:
        job = PipelineJob._REGISTRY.get(raw_job)
    if not job or job.work_dir is None:
        return jsonify({"error": "job_id inconnu ou work_dir non disponible."}), 404
    wd = job.work_dir.resolve()
    target = (wd / rel).resolve()
    try:
        target.relative_to(wd)
        target.relative_to(cfg.WORK_ROOT.resolve())
    except ValueError:
        return jsonify({"error": "Le chemin doit être sous work_dir du job."}), 403
    if not target.is_file():
        return jsonify({"error": f"Image introuvable : {rel}"}), 404
    if target.suffix.lower() not in {".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp"}:
        return jsonify({"error": "Extension image non autorisée."}), 403
    try:
        sz = target.stat().st_size
    except OSError:
        return jsonify({"error": "stat impossible"}), 500
    if sz > _MAX_IMAGE_BYTES:
        return jsonify({"error": "Image trop volumineuse (>8 Mo)."}), 413
    # mime explicite (sinon SVG peut être servi en octet-stream par Flask).
    import mimetypes
    mime, _ = mimetypes.guess_type(str(target))
    if request.method == "HEAD":
        resp = Response(status=200)
        resp.headers["Content-Length"] = str(sz)
        if mime:
            resp.headers["Content-Type"] = mime
        return resp
    return send_file(str(target), mimetype=mime or "application/octet-stream",
                    conditional=True, max_age=0)

@bp.route("/api/pipeline/result_file", methods=["GET", "HEAD"])
def get_result_file():
    """Servir un fichier généré (texte ou binaire) sous work_dir/<job_id>.

    Sécurité (miroir de ``result_image``) :
      * chemin obligatoirement sous ``work_dir`` ET ``WORK_ROOT``,
      * extension whitelist (image + texte + PDF + thermo_pw/QE),
      * taille bornée (64 Mo max — au-delà on renvoie 413).

    Comportement :
      * query ``inline=1`` → ``Content-Disposition: inline`` (preview navigateur),
      * sinon ``attachment`` → téléchargement forcé,
      * images/PDF (et ``text/*``) passent en inline automatiquement.
      * nom de fichier RFC 5987 (`filename*=UTF-8''...`) pour UTF-8.
    """
    from flask import Response, send_file
    import urllib.parse as _urlenc
    _MAX_FILE_BYTES = 64 * 1024 * 1024  # 64 Mo — couvre thermo_pw_run.out long
    _IMAGE_EXTS = frozenset({".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp"})
    _PDF_EXTS = frozenset({".pdf"})
    # Whitelist au sens « dernière extension du nom » (``Path.suffix``).
    # Le cas multi-point (``output_el_cons.dat.g1``) est traité en bas
    # via ``_WHITELIST_COMPOUND``.
    _WHITELIST_LEAF = frozenset({
        # textuels / configs / logs
        ".txt", ".dat", ".csv", ".json", ".log", ".out",
        ".xml", ".in", ".yml", ".yaml", ".md", ".summary",
        # thermo_pw / QE primitives
        ".freq", ".dos", ".matdyn", ".bands",
        ".fc", ".dyn", ".g1", ".g2",
        # images + PDF
    }) | _IMAGE_EXTS | _PDF_EXTS
    # Endings *composites* à tester en plus de ``suffix`` : ``output_el_cons.dat.g1``
    # est le livrable C_ij standard de thermo_pw, ``.dat.g2`` la deuxième
    # rotation de groupe de symétrie. ``.json.gz`` accepté si quelqu'un gzippe
    # un eos_summary à la main.
    _WHITELIST_COMPOUND = frozenset({
        ".dat.g1", ".dat.g2",
        ".json.gz",
    })

    def _match_whitelist(name: str) -> bool:
        low = name.lower()
        if any(low.endswith(c) for c in _WHITELIST_COMPOUND):
            return True
        # ``suffix`` ne capture QUE le dernier composant ;
        # on l'utilise après s'être assuré que le composé exhaustif matche.
        return Path(name).suffix.lower() in _WHITELIST_LEAF

    def _rfc5987_filename(name: str) -> str:
        """Construit le paramètre ``filename`` pour ``Content-Disposition`` :
        ``filename="ascii-fallback"`` si le nom est ASCII pur, sinon ajoute
        ``filename*=UTF-8''<url-encoded>`` (RFC 5987) pour les clients qui
        comprennent UTF-8 sans corrompre le nom.
        """
        def _quote(s: str) -> str:
            # Échappe les guillemets et antislashs pour le
            # ``filename="..."`` quoted-string (RFC 6266 § 4.1).
            return s.replace("\\", "\\\\").replace('"', "\\\"")

        try:
            # ASCII pur : un seul ``filename="..."`` suffit
            # (log lisible + compat clients anciens).
            name.encode("ascii")
            return f'filename="{_quote(name)}"'
        except UnicodeEncodeError:
            # Non-ASCII : fallback ASCII (caractères → ``_``) pour les
            # clients qui ne lisent que ``filename="…"``, ET un
            # ``filename*=UTF-8''<percent-encoded>`` pour les clients
            # modernes (RFC 5987 — ``_urlenc.quote`` par défaut conserve
            # ``_.-~/`` qui sont des caractères « safe »).
            ascii_safe = (
                name.encode("ascii", "replace")
                .decode("ascii")
                .replace("?", "_")
            )
            encoded = _urlenc.quote(name)
            return (
                f'filename="{_quote(ascii_safe)}"; '
                f"filename*=UTF-8''{encoded}"
            )

    raw_job = (request.args.get("job_id") or "").strip()
    rel = (request.args.get("path") or "").strip().lstrip("/")
    inline_q = (request.args.get("inline") or "").strip()
    if not raw_job or not rel:
        return jsonify({"error": "job_id et path requis (query)."}), 400
    parts = rel.split("/")
    if not parts or any(p in (".", "..") or ".." in p for p in parts):
        return jsonify({"error": "path invalide."}), 400
    with PipelineJob._REGISTRY_LOCK:
        job = PipelineJob._REGISTRY.get(raw_job)
    if not job or job.work_dir is None:
        return jsonify({"error": "job_id inconnu ou work_dir non disponible."}), 404
    try:
        wd = job.work_dir.resolve()
        target = (wd / rel).resolve()
        target.relative_to(wd)
        target.relative_to(cfg.WORK_ROOT.resolve())
    except ValueError:
        return jsonify({"error": "Le chemin doit être sous work_dir du job."}), 403
    except OSError:
        return jsonify({"error": "Chemin ou work_dir inaccessible."}), 500
    if not target.is_file():
        return jsonify({"error": f"Fichier introuvable : {rel}"}), 404
    if not _match_whitelist(target.name):
        return jsonify({
            "error": f"Extension non autorisée : {target.name!r}.",
            "allowed_leaf": sorted(_WHITELIST_LEAF),
            "allowed_compound": sorted(_WHITELIST_COMPOUND),
        }), 403
    try:
        sz = target.stat().st_size
    except OSError:
        return jsonify({"error": "stat impossible"}), 500
    if sz > _MAX_FILE_BYTES:
        return jsonify({
            "error": f"Fichier trop volumineux ({sz} octets, max 64 Mo)."
        }), 413
    import mimetypes
    mime, _ = mimetypes.guess_type(str(target))
    last_suffix = target.suffix.lower()
    is_viewable = (
        last_suffix in (_IMAGE_EXTS | _PDF_EXTS)
        or (mime is not None and mime.startswith("text/"))
    )
    disposition_kind = "inline" if (inline_q == "1" or is_viewable) else "attachment"
    # ``send_file`` ne préserve pas les headers custom s'ils ne sont
    # pas posés *après* le retour → on fige la valeur ici et on
    # l'assigne explicitement sur les deux branches (HEAD + GET).
    disp = f"{disposition_kind}; {_rfc5987_filename(target.name)}"
    if request.method == "HEAD":
        resp = Response(status=200)
        resp.headers["Content-Length"] = str(sz)
        if mime:
            resp.headers["Content-Type"] = mime
        resp.headers["Content-Disposition"] = disp
        return resp
    resp = send_file(
        str(target),
        mimetype=mime or "application/octet-stream",
        conditional=True, max_age=0,
    )
    resp.headers["Content-Disposition"] = disp
    return resp

@bp.route("/api/inputs/scf_in_preview", methods=["GET"])
def get_scf_in_preview():
    """Contenu textuel du scf.in d'un matériau (bouton ① de l'UI 5 profils)."""
    material_id = (request.args.get("material_id") or "").strip()
    basename = (request.args.get("basename") or "").strip()
    if not material_id or not basename:
        return jsonify({"error": "material_id et basename requis (query)."}), 400
    if ".." in basename or "/" in basename or "\\" in basename:
        return jsonify({"error": "basename invalide (pas de chemin)."}), 400
    if not basename.lower().endswith(".in"):
        return jsonify({"error": "basename doit terminer par .in"}), 400
    try:
        inputs_root = cfg.INPUTS_DIR.resolve()
        target = (inputs_root / material_id / basename).resolve()
        target.relative_to(inputs_root)
    except (ValueError, OSError):
        return jsonify({"error": "Chemin hors de inputs/"}), 403
    if not target.is_file():
        return jsonify({"error": f"Fichier introuvable : {basename!r}"}), 404
    try:
        sz = target.stat().st_size
    except OSError:
        return jsonify({"error": "stat impossible"}), 500
    if sz > 256 * 1024:
        return jsonify({"error": f"Fichier trop volumineux ({sz} octets, max 256 Ko)."}), 413
    try:
        content = target.read_text(encoding="utf-8", errors="replace")
    except OSError as ex:
        return jsonify({"error": str(ex)}), 500
    return jsonify({
        "path": str(target),
        "material_id": material_id,
        "basename": basename,
        "size": sz,
        "content": content,
    })

@bp.route("/api/pipeline/thermo_pw_in_preview", methods=["GET"])
def get_thermo_pw_in_preview_route():
    """Aperçu structuré du futur thermo_pw.in (bouton ② de l'UI 5 profils)."""
    profile_id = (request.args.get("profile_id") or "").strip().upper()
    material_id = (request.args.get("material_id") or "").strip()
    try:
        nproc = int(request.args.get("nproc") or 4)
    except (TypeError, ValueError):
        nproc = 4
    if not profile_id:
        return jsonify({"error": "profile_id requis (query)."}), 400
    try:
        prof = get_profile(profile_id)
    except KeyError as ex:
        return jsonify({"error": str(ex)}), 404
    return jsonify(_render_thermo_pw_in_preview(prof, material_id, max(1, nproc)))


# ----------------------------------------------------------------------------
# Estimation de durée (août 2026)
# ----------------------------------------------------------------------------
def _resolve_scf_template_for_estimate(
    material_id: str, scf_in_basename: str
) -> Optional[Path]:
    """Localise le scf.in qui servira au calcul, sans rien copier.

    Reprend la cascade de ``_execute`` (template explicite puis premier .in du
    dossier matériau) afin que l'estimation porte sur le même fichier que le
    lancement réel.
    """
    src = resolve_template(material_id, scf_in_basename) if scf_in_basename else None
    if src is not None and Path(src).is_file():
        return Path(src)
    bucket = find_thermo_inputs_only(material_id)
    if bucket and bucket.candidates:
        cand = bucket.mat_dir / bucket.candidates[0]
        if cand.is_file():
            return cand
    return None


def _cell_facts_for(pw_path: Optional[Path], desc: Any):
    """Grandeurs de maille (volume, bandes, ondes planes) pour l'estimation disque.

    La valence vient des UPF du dossier de pseudopotentiels : c'est la seule
    source exacte du nombre d'électrons, qu'aucun numéro atomique ne donne pour
    un pseudo à cœur gelé.
    """
    text = ""
    if pw_path is not None:
        try:
            text = Path(pw_path).read_text(encoding="utf-8", errors="replace")
        except OSError:
            text = ""
    return derive_cell_facts(text, desc, pseudo_dirs=[Path(cfg.PSEUDOS_DIR)])


@bp.route("/api/pipeline/machine", methods=["GET"])
def get_machine_profile_route():
    """Capacités de la machine de calcul (cœurs, RAM, indice de vitesse)."""
    machine = detect_machine()
    return jsonify(
        {
            **machine.to_dict(),
            "recommended_nproc": machine.recommended_nproc(),
            "speedup_by_nproc": {
                str(n): round(machine.parallel_speedup(n), 3)
                for n in range(1, max(2, machine.cores_logical + 1))
            },
        }
    )


@bp.route("/api/pipeline/estimate", methods=["GET"])
def get_runtime_estimate_route():
    """Durée estimée d'un profil sur cette machine, détaillée par étape.

    Query : ``profile_id`` (requis), ``material_id``, ``scf_in_basename``,
    ``nproc``, ``needs_optical``, ``lo_to_opt_in``, ``extra_whats`` (CSV).
    Sans ``material_id`` exploitable, l'estimation retombe sur les descripteurs
    par défaut (Si) et le signale via ``descriptors.material_id`` vide.
    """
    profile_id = (request.args.get("profile_id") or "").strip().upper()
    material_id = (request.args.get("material_id") or "").strip()
    scf_in_basename = (request.args.get("scf_in_basename") or "").strip()
    if not profile_id:
        return jsonify({"error": "profile_id requis (query)."}), 400
    try:
        prof = get_profile(profile_id)
    except KeyError as ex:
        return jsonify({"error": str(ex)}), 404

    machine = detect_machine()
    try:
        nproc = int(request.args.get("nproc") or machine.recommended_nproc())
    except (TypeError, ValueError):
        nproc = machine.recommended_nproc()

    # Overrides d'options qui changent la séquence d'étapes, donc la durée.
    needs_optical = request.args.get("needs_optical")
    if needs_optical is not None and prof.get("needs_optical_overridable"):
        prof = {**prof, "needs_optical": needs_optical.lower() in ("1", "true", "yes")}
    lo_to = (request.args.get("lo_to_opt_in") or "").lower() in ("1", "true", "yes")
    raw_extras = (request.args.get("extra_whats") or "").strip()
    extras = [x.strip() for x in raw_extras.split(",") if x.strip()] if raw_extras else None

    pw_path = (
        _resolve_scf_template_for_estimate(material_id, scf_in_basename)
        if material_id
        else None
    )
    desc = parse_material_descriptors(
        pw_path=pw_path, material_id=material_id if pw_path else ""
    )
    est = estimate_runtime(
        profile_id=profile_id,
        profile=prof,
        descriptors=desc,
        machine=machine,
        nproc=max(1, nproc),
        extra_whats=extras,
        lo_to_opt_in=lo_to,
    )
    payload = est.to_dict()
    payload["scf_in_resolved"] = pw_path.name if pw_path else None
    payload["recommended_nproc"] = machine.recommended_nproc()
    try:
        payload["storage"] = estimate_storage(
            profile_id=profile_id,
            profile=prof,
            descriptors=desc,
            cell_facts=_cell_facts_for(pw_path, desc),
            disk_path=cfg.WORK_ROOT,
        ).to_dict()
    except Exception as ex:  # noqa: BLE001
        payload["storage"] = None
        payload["storage_error"] = str(ex)
    return jsonify(payload)


"""
``backend.ps_to_pdf`` — convertisseur PostScript → PDF via Ghostscript.

Pourquoi ce module existe
-------------------------
Les scripts gnuplot historiquement produits par thermo_pw (par exemple
``output_therm_debye.dw.g1.ps``) finissent en ``*.ps`` legacy et ne sont pas
affichables directement dans le navigateur ou les lecteurs PDF des chercheurs.
Or, tous les autres artefacts (EOS E(V), phonon DOS, phonon bands, eDOS...) sont
déjà en ``.pdf`` via le terminal ``pdfcairo`` configuré dans
``backend/eos_gnuplot.py`` / ``backend/phonon_gnuplot.py`` /
``backend/electronic_props.py``.

Ce module offre donc un helper **idempotent** qui :
  1. Vérifie que ``gs`` est dispo (``_has_ghostscript()``).
  2. Scanne ``work_dir`` (racine + 1 niveau) pour les ``*.ps`` / ``*.eps``
     résiduels (PostScript + Encapsulated PostScript — même dialecte gs).
  3. Pour chaque ``*.ps``/``*.eps`` sans ``*.pdf`` correspondant OU avec un
     ``*.pdf`` plus ancien que la source, lance ``gs -dNOPAUSE -dBATCH
     -sDEVICE=pdfwrite``.
  4. Renvoie une liste de tuples diagnostics ``(ps_path, pdf_path, ok, err)``.

Conventions
-----------
  - Pas de récursion profonde : on évite de scanner toute l'arborescence
    (risque de toucher des fichiers utilisateur hors-scope).
  - Skip gracieux si ``gs`` est absent : on retourne ``[]`` avec un log
    ``warnings.warn`` au lieu d'échouer.
  - Timeout par fichier : 30 s (les PostScript thermo_pw sont < 10 Mo).
  - Idempotent : un second appel est un no-op si tous les PDFs sont déjà frais.

Pourquoi pas juste changer le terminal gnuplot en ``pdfcairo`` ?
R : migration historique impossible (certains PostScript sont déjà publiés
    par thermo_pw upstream dans le dossier de run, et ``eps`` est nécessaire
    pour certaines revues qui ne supportent pas les bitmaps).
"""
from __future__ import annotations

import shutil
import subprocess
import warnings
from pathlib import Path
from typing import Optional


_GS_TIMEOUT_SECONDS: int = 30
# Profondeur de scan : 1 niveau sous work_dir (ex : /wd/1_eos_volumes/*.ps).
_GS_MAX_DEPTH: int = 2
# Dialectes PostScript reconnus (juillet 2026 — ajout de .eps / Encapsulated
# PostScript). Meme backend Ghostscript ``-sDEVICE=pdfwrite`` ; pas de flag
# special requis. Voir ``_iter_ps_files`` / ``convert_postscript_to_pdf``.
_PS_SUFFIXES: frozenset[str] = frozenset({".ps", ".eps"})


def _has_ghostscript() -> bool:
    """Renvoie True si ``gs`` (Ghostscript) est disponible sur le PATH.

    On utilise ``shutil.which`` plutôt qu'une résolution par chemin absolu
    pour respecter les environnements PyInstaller / sandbox où ``gs`` peut
    être lié dans ``$CONDA_PREFIX/bin`` ou un bundle dédié.
    """
    try:
        return shutil.which("gs") is not None
    except Exception:  # noqa: BLE001
        return False


def _convert_one(ps_path: Path, *, timeout: int = _GS_TIMEOUT_SECONDS) -> tuple[Path, bool, str]:
    """Convertit un seul ``.ps`` en ``.pdf``.

    Args:
        ps_path: chemin absolu vers le fichier PostScript.
        timeout: timeout (s) pour le sous-processus ``gs``.

    Returns:
        Tuple ``(pdf_path, ok, err)`` où :
          * ``pdf_path`` est le chemin de sortie dérivé (``ps.with_suffix(".pdf")``)
            (calculé même en cas d'échec — utile pour le diagnostic).
          * ``ok`` est True si ``gs`` a écrit un PDF non-vide.
          * ``err`` est un message lisible par humain (vide si ok).
    """
    pdf_path = ps_path.with_suffix(".pdf")
    if not ps_path.is_file():
        return pdf_path, False, f"Fichier source introuvable : {ps_path}"
    try:
        proc = subprocess.run(
            [
                "gs",
                "-dNOPAUSE",
                "-dBATCH",
                "-sDEVICE=pdfwrite",
                f"-sOutputFile={str(pdf_path)}",
                str(ps_path),
            ],
            timeout=timeout,
            check=False,
            capture_output=True,
            text=True,
        )
    except subprocess.TimeoutExpired:
        return pdf_path, False, f"Timeout gs ({timeout}s) sur {ps_path.name}"
    except FileNotFoundError:
        return pdf_path, False, "Exécutable ``gs`` introuvable sur le PATH"
    except Exception as exc:  # noqa: BLE001
        return pdf_path, False, f"Exception gs: {exc!r}"
    if proc.returncode != 0:
        # ``gs`` renvoie stderr sur plusieurs lignes ; on garde les 5 dernières.
        tail = (proc.stderr or "").strip().splitlines()[-5:]
        return pdf_path, False, f"gs code={proc.returncode}: {' | '.join(tail)[:200]}"
    if not pdf_path.is_file() or pdf_path.stat().st_size == 0:
        return pdf_path, False, "gs a réussi mais aucun PDF n'a été écrit"
    return pdf_path, True, ""


def _iter_ps_files(work_dir: Path, *, max_depth: int = _GS_MAX_DEPTH) -> list[Path]:
    """Liste les ``*.ps`` / ``*.eps`` sous ``work_dir`` (racine + sous-dossiers
    jusqu'à une profondeur ``max_depth``).

    Les deux dialectes PostScript (``.ps`` brut et ``.eps`` Encapsulated) sont
    collectés — même bucket ``_PS_SUFFIXES`` car le même ``gs -sDEVICE=pdfwrite``
    gère les deux nativement (juillet 2026).

    Semantique de ``max_depth`` (juillet 2026) : N = nombre de sous-niveaux
    SOUS work_dir autorises. ``max_depth=2`` (defaut) inclut les fichiers
    en racine (prof. 0), dans les sous-dossiers directs (prof. 1) ET dans
    leurs sous-dossiers (prof. 2). ``max_depth=1`` inclut racine + 1
    sous-dossier mais PAS les niveaux plus profonds.

    Returns:
        Liste triée et dédupliquée des chemins absolus (filtrée : is_file()).
    """
    if not work_dir.is_dir():
        return []
    out: list[Path] = []
    seen: set[Path] = set()
    # Scan racine + 1 niveau (max_depth=2 : racine = niveau 0).
    # ``Path.rglob`` est trop profond — on limite via ``glob`` manuel.
    queue: list[tuple[Path, int]] = [(work_dir, 0)]
    while queue:
        current, depth = queue.pop(0)
        if depth > max_depth:
            continue
        try:
            children = list(current.iterdir())
        except (OSError, PermissionError):
            continue
        for child in children:
            try:
                # On évite de suivre les symlinks (sécurité).
                if child.is_symlink():
                    continue
                if child.is_file() and child.suffix.lower() in _PS_SUFFIXES:
                    if child not in seen:
                        seen.add(child)
                        out.append(child.resolve())
                elif child.is_dir() and depth + 1 <= max_depth:
                    queue.append((child, depth + 1))
            except OSError:
                continue
    out.sort()
    return out


def convert_postscript_to_pdf(
    work_dir: Path,
    *,
    timeout: int = _GS_TIMEOUT_SECONDS,
    max_depth: int = _GS_MAX_DEPTH,
    force: bool = False,
) -> list[tuple[Path, Path, bool, str]]:
    """Convertit tous les ``*.ps`` / ``*.eps`` de ``work_dir`` en ``*.pdf``
    (idempotent). Les deux dialectes PostScript (brut + Encapsulated) sont
    traités de manière uniforme via ``gs -sDEVICE=pdfwrite`` (juillet 2026).

    Args:
        work_dir: répertoire du run pipeline à enrichir.
        timeout: timeout (s) par conversion gs.
        max_depth: profondeur max du scan (défaut = racine + 1 sous-dossier).
        force: si True, reconvertit même si le PDF existe et est plus récent
            que la source PostScript.

    Returns:
        Liste ``[(ps_path, pdf_path, ok, err)]`` pour chaque ``.ps``/``.eps``
        trouvé, même ceux déjà convertis (ok=True, err="") — utile pour
        vérifier la complétude du scan. Le ``ps_path`` est en fait le chemin
        source (qui peut être ``.ps`` ou ``.eps``), nommé ``ps_path`` pour
        conserver la compat avec le contrat public initial.
    """
    work_dir = Path(work_dir)
    if not work_dir.is_dir():
        warnings.warn(
            f"[ps_to_pdf] work_dir introuvable ou non répertoire : {work_dir}",
            stacklevel=2,
        )
        return []

    if not _has_ghostscript():
        warnings.warn(
            "[ps_to_pdf] ``gs`` (Ghostscript) non disponible sur le PATH — "
            "conversion *.ps → *.pdf ignorée. Installer Ghostscript "
            "(apt: ghostscript / brew: ghostscript).",
            stacklevel=2,
        )
        # On retourne tout de même la liste des .ps pour signaler leur présence.
        return [(p, p.with_suffix(".pdf"), False, "gs absent") for p in _iter_ps_files(work_dir, max_depth=max_depth)]

    results: list[tuple[Path, Path, bool, str]] = []
    for ps_path in _iter_ps_files(work_dir, max_depth=max_depth):
        pdf_path = ps_path.with_suffix(".pdf")
        # Idempotence : skip si PDF existe et est plus récent que PS (sauf force).
        if not force and pdf_path.is_file():
            try:
                if pdf_path.stat().st_mtime >= ps_path.stat().st_mtime:
                    results.append((ps_path, pdf_path, True, ""))
                    continue
            except OSError:
                pass  # on tentera la conversion quand même
        pdf_path_out, ok, err = _convert_one(ps_path, timeout=timeout)
        results.append((ps_path, pdf_path_out, ok, err))
    return results


__all__ = [
    "_has_ghostscript",
    "_convert_one",
    "_iter_ps_files",
    "convert_postscript_to_pdf",
]

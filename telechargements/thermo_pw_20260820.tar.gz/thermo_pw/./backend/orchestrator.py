"""
Orchestration : dépendances strictes, arrêt sur erreur, reprise via workflow_state.json.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from eos_paths import EOS_VOLUMES_SUBDIR, WORKFLOW_STATE_FILENAME
from state_db import TaskStatus, WorkflowDB
from work_elastic import task_elastic
from work_optimize_eos import task_optimize
from work_phonon import task_phonon
from work_thermo import task_thermo


@dataclass
class PipelinePaths:
    template_pw: Path
    in_ph: Optional[Path] = None
    in_q2r: Optional[Path] = None
    in_matdyn: Optional[Path] = None
    in_pw_thermo: Optional[Path] = None
    fildyn: str = "dyn"


def run_pipeline(
    work_dir: Path,
    material_id: str,
    paths: PipelinePaths,
    *,
    do_eos: bool = True,
    do_elastic: bool = False,
    do_phonon: bool = True,
    do_thermo: bool = True,
) -> dict[str, Any]:
    work_dir = Path(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)
    st_path = work_dir / WORKFLOW_STATE_FILENAME
    db = WorkflowDB.load(st_path)
    if not db.material_id:
        db = WorkflowDB(material_id=material_id, work_dir=str(work_dir))
    db.save(st_path)

    results: dict[str, Any] = {}

    if do_eos:
        results["eos"] = task_optimize(work_dir, material_id, paths.template_pw, db)
    else:
        db.require_done("eos")

    if do_elastic:
        if db.get_task("eos").status != TaskStatus.DONE.value:
            raise RuntimeError("Chaîne interrompue: EOS requis pour l’élasticité.")
        results["elastic"] = task_elastic(
            work_dir, material_id, paths.template_pw, db
        )

    if do_phonon:
        if not paths.in_ph or not paths.in_q2r or not paths.in_matdyn:
            raise ValueError("Phonon: fournir in_ph, in_q2r, in_matdyn")
        if db.get_task("eos").status != TaskStatus.DONE.value:
            raise RuntimeError("Phonon: EOS manquant (DONE requis).")
        results["phonon"] = task_phonon(
            work_dir,
            material_id,
            paths.in_ph,
            paths.in_q2r,
            paths.in_matdyn,
            db,
        )

    if do_thermo:
        if do_phonon:
            (work_dir / ".require_phonon_for_thermo").write_text("1", encoding="utf-8")
        if not paths.in_pw_thermo:
            paths.in_pw_thermo = work_dir / EOS_VOLUMES_SUBDIR / "scf_eq.in"
        if not paths.in_pw_thermo.is_file():
            raise FileNotFoundError("Entrée pw pour thermo (scf_eq.in ou in_pw_thermo)")
        results["thermo"] = task_thermo(
            work_dir, material_id, paths.in_pw_thermo, db, fildyn=paths.fildyn
        )
        req = work_dir / ".require_phonon_for_thermo"
        if req.is_file():
            try:
                req.unlink()
            except OSError:
                pass

    return results

"""
Task_Phonon : ph.x, puis q2r.x / matdyn.x (entrée stdin).
Vérifie qu’il existe des sorties de dynamique (fichiers .dyn* / .fc / ./_ph* selon la version).
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import config as cfg
from qe_subprocess import run_qe, run_qe_stdin, which_mpirun
from state_db import TaskState, TaskStatus, WorkflowDB

from eos_paths import WORKFLOW_STATE_FILENAME


def _has_phonon_artifacts(pdir: Path) -> bool:
    for pat in ("*.fc", "*.dyn*", "*_ph*", "*dyn.xml"):
        if list(pdir.rglob(pat)):
            return True
    if list(pdir.glob("**/*save*")):
        return True
    return False


def task_phonon(
    work_dir: Path,
    material_id: str,
    in_ph: Path,
    in_q2r: Path,
    in_matdyn: Path,
    db: WorkflowDB,
) -> dict[str, Any]:
    if db.get_task("eos").status != TaskStatus.DONE.value:
        raise RuntimeError("Phonon: l’étape EOS doit être en état DONE.")

    pdir = work_dir / "3_phonon"
    pdir.mkdir(parents=True, exist_ok=True)
    st = TaskState(status=TaskStatus.RUNNING.value, message="ph.x")
    db.set_task("phonon", st)
    db.save(work_dir / WORKFLOW_STATE_FILENAME)

    m = which_mpirun()
    nproc = str(cfg.MPI_NPROC)
    (pdir / in_ph.name).write_text(
        in_ph.read_text(encoding="utf-8", errors="replace"), encoding="utf-8"
    )
    logph = pdir / "ph_run.log"
    run_qe(
        [m, "-np", nproc, str(cfg.ph_path()), "-in", in_ph.name],
        work_dir=pdir,
        log_file=logph,
    )
    _ph_tail = logph.read_text(encoding="utf-8", errors="replace")[-4000:].lower()
    if not _has_phonon_artifacts(pdir) and "job done" not in _ph_tail:
        st = TaskState(
            status=TaskStatus.ERROR.value,
            message="ph.x: pas de sorties attendues — vérifier 3_phonon/ph_run.log",
        )
        db.set_task("phonon", st)
        db.save(work_dir / WORKFLOW_STATE_FILENAME)
        raise RuntimeError(st.message)

    (pdir / in_q2r.name).write_text(
        in_q2r.read_text(encoding="utf-8", errors="replace"), encoding="utf-8"
    )
    run_qe_stdin(cfg.q2r_path(), pdir / in_q2r.name, pdir, pdir / "q2r.log")
    (pdir / in_matdyn.name).write_text(
        in_matdyn.read_text(encoding="utf-8", errors="replace"), encoding="utf-8"
    )
    run_qe_stdin(cfg.matdyn_path(), pdir / in_matdyn.name, pdir, pdir / "matdyn.log")

    summary = {"ph_log": str(logph), "work": str(pdir)}
    (pdir / "phonon_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    st = TaskState(status=TaskStatus.DONE.value, message="Phonon: chaîne lancée", data=summary)
    db.set_task("phonon", st)
    db.save(work_dir / WORKFLOW_STATE_FILENAME)
    return summary

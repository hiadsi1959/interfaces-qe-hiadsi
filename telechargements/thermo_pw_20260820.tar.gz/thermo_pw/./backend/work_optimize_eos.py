"""
Task_Optimize : volumes, pw.x parallèles, parsing, fit BM, génération scf @ V0.
"""
from __future__ import annotations

import json
import multiprocessing as mp
import re
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Optional, Tuple

import numpy as np

import config as cfg
from eos_paths import EOS_VOLUMES_SUBDIR, WORKFLOW_STATE_FILENAME, wf1_eos_run_root
from fit_eos import b0_GPa, fit_birch_murnaghan
from input_scaling import scale_pw_input_file
from parsers.pw_out import parse_pw_out_file
from qe_subprocess import (
    API_CANCEL_RUNTIME_MSG,
    run_pw_x_in,
    terminate_registered_processes,
)
from state_db import TaskState, TaskStatus, WorkflowDB


@dataclass
class EosConfig:
    template_pw: Path
    n_points: int = 7
    strain_min: float = -0.03
    strain_max: float = 0.03
    subdir: str = EOS_VOLUMES_SUBDIR
    nproc: int = field(default_factory=lambda: cfg.MPI_NPROC)
    # Si True : pw.x un par un dans l’ordre des strains (suivi log pratique).
    sequential: bool = False


_RE_SCF_VOL_OUT = re.compile(r"(?i)^scf_vol_(\d+)\.out$")


def list_scf_vol_outs_ordered(tdir: Path) -> list[Path]:
    """Liste triée selon XX dans scf_vol_XX.out (pas l’ordre lexicographique)."""
    ps = [
        p
        for p in Path(tdir).glob("scf_vol_*.out")
        if _RE_SCF_VOL_OUT.match(p.name)
    ]
    ps.sort(key=lambda q: int(_RE_SCF_VOL_OUT.match(q.name).group(1)))
    return ps


def _one_pw(args: Tuple) -> Tuple[str, float, float, str]:
    """Un pw.x pour un volume. Le tuple accepte 3 éléments (legacy) ou 5
    (``+ cancel_event, proc_holder``) pour rester annulable depuis l'API."""
    work_root, in_name, nproc = args[0], args[1], args[2]
    cancel_event = args[3] if len(args) > 3 else None
    proc_holder = args[4] if len(args) > 4 else None
    if cancel_event is not None and cancel_event.is_set():
        raise RuntimeError(API_CANCEL_RUNTIME_MSG)
    w = Path(work_root)
    out = run_pw_x_in(
        w, in_name, nproc=nproc,
        cancel_event=cancel_event, proc_holder=proc_holder,
    )
    e, v = parse_pw_out_file(out)
    if e is None or v is None:
        raise ValueError("Parse incomplet (E ou V manquant)")
    return in_name, float(e), float(v), str(out)


def _dispatch_pw_jobs(
    jobs: list[Tuple[str, str, int]],
    conf: EosConfig,
    db: WorkflowDB,
    work_dir: Path,
    *,
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
) -> list[Tuple[str, float, float, str]]:
    """Lance les pw.x de la grille (séquentiel ou parallèle) en restant annulable.

    ``ThreadPoolExecutor`` et non ``multiprocessing.Pool`` : chaque tâche ne
    fait qu'attendre un sous-process MPI, et un thread partage le
    ``cancel_event`` du job — un ``Pool`` de process ne le voit jamais et son
    ``terminate()`` laisse les rangs MPI orphelins (bug « Annuler ne stoppe
    pas le calcul »).
    """
    def _payload(job: Tuple[str, str, int]) -> Tuple:
        return (job[0], job[1], job[2], cancel_event, proc_holder)

    if conf.sequential:
        results: list[Tuple[str, float, float, str]] = []
        for ji, job in enumerate(jobs):
            if cancel_event is not None and cancel_event.is_set():
                raise RuntimeError(API_CANCEL_RUNTIME_MSG)
            db.set_task("eos", TaskState(
                status=TaskStatus.RUNNING.value,
                message=f"SCF {ji + 1}/{len(jobs)} — {job[1]}",
            ))
            db.save(work_dir / WORKFLOW_STATE_FILENAME)
            results.append(_one_pw(_payload(job)))
        return results

    # Août 2026 — le parallélisme volumes doit tenir compte des rangs MPI
    # PAR volume : chaque job lance ``mpirun -np conf.nproc pw.x``. L'ancienne
    # formule ``cpu_count()-1`` ignorait nproc et sur-souscrivait le CPU
    # (ex. i7-7500U 4 threads : 3 volumes × 3 rangs = 9 processus, mesuré
    # 5× plus lent + pagination swap). On alloue donc
    # ``(cpu_count-1) // nproc`` créneaux de volumes, plancher 1 (séquentiel).
    _ranks_per_job = max(1, int(getattr(conf, "nproc", 1) or 1))
    npar = min(len(jobs), max(1, (mp.cpu_count() - 1) // _ranks_per_job), 8)
    with ThreadPoolExecutor(max_workers=npar) as pool:
        futures = [pool.submit(_one_pw, _payload(job)) for job in jobs]
        try:
            return [f.result() for f in futures]
        except BaseException:
            # Annulation OU échec d'un volume : on n'attend pas les autres pw.x
            # (des heures potentielles) et surtout on ne les abandonne pas en
            # orphelins — le groupe MPI de chaque process est tué.
            for f in futures:
                f.cancel()
            terminate_registered_processes(proc_holder)
            raise


def _eos_finalize_from_results(
    work_dir: Path,
    conf: EosConfig,
    strains: np.ndarray,
    results: list[Tuple[str, float, float, str]],
) -> dict[str, Any]:
    """Fit Birch–Murnaghan, scf_eq.in, pw_scf_V0_for_phonon.in, eos_summary.json."""
    tdir = work_dir / conf.subdir
    volumes: list[float] = []
    energies: list[float] = []
    details: list[dict[str, Any]] = []
    for in_name, e, v, out_path in results:
        volumes.append(v)
        energies.append(e)
        details.append({"in": in_name, "E_Ry": e, "V_bohr3": v, "out": out_path})
    try:
        params, _e_fit = fit_birch_murnaghan(
            np.array(volumes), np.array(energies)
        )
    except Exception as ex:  # noqa: BLE001
        raise ValueError(f"Fit EOS: {ex}") from ex
    v0 = params["V0_bohr3"]
    b0_ry = params["B0_Ry_bohr3"]
    v_uns_list = [v / (1.0 + float(strains[i])) ** 3 for i, (_, e, v, _op) in enumerate(results)]
    v_uns = float(np.median(v_uns_list))
    eps_eq = (v0 / v_uns) ** (1.0 / 3.0) - 1.0
    final_in = tdir / "scf_eq.in"
    scale_pw_input_file(conf.template_pw, final_in, float(eps_eq))
    # Paramètres de maille à l'équilibre (août 2026) : scf_eq.in est déjà à
    # l'échelle V₀, on y lit directement a/b/c. Versés dans ``params`` (=
    # summary["eos"]) pour que le flatten existant les propage vers
    # results["eos"] → tuiles « eos.a0_A » etc. de l'interface.
    try:
        from input_scaling import extract_lattice_parameters

        lattice = extract_lattice_parameters(
            final_in.read_text(encoding="utf-8", errors="replace")
        )
        for k, v in lattice.items():
            if v is not None:
                params[k] = v
    except Exception:  # noqa: BLE001
        pass  # affichage bonus : ne doit jamais faire échouer le fit EOS
    summary: dict[str, Any] = {
        "eos": params,
        "B0_GPa_approx": b0_GPa(b0_ry),
        "volumes": volumes,
        "energies_Ry": energies,
        "strains": [float(s) for s in strains],
        "details": details,
        "eq_input_generated": str(final_in),
    }
    b_approx = float(b0_GPa(b0_ry))
    if b_approx < 4.5 or b_approx > 650.0:
        summary.setdefault("eos_hints", []).append(
            "Module de bulk B₀ (ajustement) hors plage 4–650 GPa usuels pour une solide covalent/ionique : "
            "vérifiez la structure (« nat », positions, groupe d’espace — ex. Si diamant ⇒ ibrav≈2, nat=2) "
            "et la convergence pw.x avant d’interpréter cette courbe."
        )
    (tdir / "eos_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    phonon_in = work_dir / "pw_scf_V0_for_phonon.in"
    phonon_in.write_text(final_in.read_text(encoding="utf-8", errors="replace"), encoding="utf-8")
    summary["pw_for_phonon"] = str(phonon_in.resolve())
    return summary


def task_optimize_fit_only(
    work_dir: Path,
    material_id: str,
    template_pw: Path,
    db: WorkflowDB,
    conf: Optional[EosConfig] = None,
) -> dict[str, Any]:
    """
    Relit uniquement les sorties scf_vol_XX.out existantes (pas de pw.x).
    Même n_points et même plage de déformation qu’au run initial.
    """
    work_dir = wf1_eos_run_root(work_dir)
    tp = Path(template_pw).resolve()
    if conf is None:
        conf = EosConfig(template_pw=tp)
    else:
        conf = replace(conf, template_pw=tp)
    tdir = work_dir / conf.subdir
    if not tdir.is_dir():
        raise ValueError(f"Dossier introuvable : {tdir}")
    outs = list_scf_vol_outs_ordered(tdir)
    if not outs:
        raise ValueError(
            f"Aucun scf_vol_XX.out reconnu dans {tdir} — lancez d’abord les SCF ou indiquez le bon dossier."
        )
    if len(outs) < 2:
        raise ValueError(
            f"Au moins deux sorties scf_vol_XX.out sont nécessaires pour l’EOS — trouvé : {len(outs)}."
        )
    n_out = len(outs)
    st = TaskState(
        status=TaskStatus.RUNNING.value,
        message="Lecture des sorties + fit Birch–Murnaghan (sans pw.x)",
    )
    db.set_task("eos", st)
    db.save(work_dir / WORKFLOW_STATE_FILENAME)
    results: list[Tuple[str, float, float, str]] = []
    strains = np.linspace(conf.strain_min, conf.strain_max, n_out)
    for i, out_path in enumerate(outs):
        e, v = parse_pw_out_file(out_path)
        if e is None or v is None:
            raise ValueError(f"Énergie ou volume manquant dans {out_path}")
        in_name = f"scf_vol_{i:02d}.in"
        results.append((in_name, float(e), float(v), str(out_path.resolve())))
    summary = _eos_finalize_from_results(work_dir, conf, strains, results)
    if n_out != conf.n_points:
        summary["eos_notes"] = (
            f"Ajustement sur {n_out} point(s) réel(s) (scf_vol_*.out ; n_points configuré dans l’interface : {conf.n_points})."
        )
    st = TaskState(
        status=TaskStatus.DONE.value,
        message="EOS terminé (ajustement seul)",
        data=summary,
    )
    db.set_task("eos", st)
    db.save(work_dir / WORKFLOW_STATE_FILENAME)
    return summary


def task_optimize_volumes_only(
    work_dir: Path,
    material_id: str,
    template_pw: Path,
    db: WorkflowDB,
    conf: Optional[EosConfig] = None,
) -> dict[str, Any]:
    """Génère seulement les `scf_vol_XX.in` (pas de pw.x, pas d’EOS)."""
    work_dir = wf1_eos_run_root(work_dir)
    tp = Path(template_pw).resolve()
    if conf is None:
        conf = EosConfig(template_pw=tp)
    else:
        conf = replace(conf, template_pw=tp)
    tdir = work_dir / conf.subdir
    tdir.mkdir(parents=True, exist_ok=True)

    st = TaskState(status=TaskStatus.RUNNING.value, message="Génération des volumes (.in uniquement)")
    db.set_task("eos", st)
    db.save(work_dir / WORKFLOW_STATE_FILENAME)

    strains = np.linspace(conf.strain_min, conf.strain_max, conf.n_points)
    for i, eps in enumerate(strains):
        label = f"scf_vol_{i:02d}.in"
        out_in = tdir / label
        scale_pw_input_file(conf.template_pw, out_in, float(eps))

    meta: dict[str, Any] = {
        "phase": "volumes_only",
        "n_points": conf.n_points,
        "strain_min": float(conf.strain_min),
        "strain_max": float(conf.strain_max),
        "subdirectory": str(tdir.resolve()),
        "in_files": [f"scf_vol_{i:02d}.in" for i in range(conf.n_points)],
    }
    st = TaskState(
        status=TaskStatus.DONE.value,
        message=f"Grille prête : {conf.n_points} × scf_vol_XX.in (aucun SCF lancé)",
        data=meta,
    )
    db.set_task("eos", st)
    db.save(work_dir / WORKFLOW_STATE_FILENAME)
    return meta


def task_optimize_scf_and_fit(
    work_dir: Path,
    material_id: str,
    template_pw: Path,
    db: WorkflowDB,
    conf: Optional[EosConfig] = None,
    *,
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """
    `scf_vol_XX.in` doivent déjà exister (étape génération).
    Lance les pw.x puis fit Birch–Murnaghan.
    """
    work_dir = wf1_eos_run_root(work_dir)
    tp = Path(template_pw).resolve()
    if conf is None:
        conf = EosConfig(template_pw=tp)
    else:
        conf = replace(conf, template_pw=tp)
    tdir = work_dir / conf.subdir
    if not tdir.is_dir():
        raise ValueError(f"Dossier des volumes introuvable : {tdir}")

    strains = np.linspace(conf.strain_min, conf.strain_max, conf.n_points)
    jobs: list[Tuple[str, str, int]] = []
    for i in range(conf.n_points):
        label = f"scf_vol_{i:02d}.in"
        p = tdir / label
        if not p.is_file():
            raise ValueError(
                f"Fichier manquant : {p} — générez d’abord la grille (même n, même m) "
                f"ou vérifiez le dossier."
            )
        jobs.append((str(tdir), label, conf.nproc))

    st = TaskState(status=TaskStatus.RUNNING.value, message=f"Lancement {len(jobs)} × pw.x")
    db.set_task("eos", st)
    db.save(work_dir / WORKFLOW_STATE_FILENAME)

    results = _dispatch_pw_jobs(
        jobs, conf, db, work_dir,
        cancel_event=cancel_event, proc_holder=proc_holder,
    )

    try:
        summary = _eos_finalize_from_results(work_dir, conf, strains, results)
    except Exception as ex:  # noqa: BLE001
        st = TaskState(status=TaskStatus.ERROR.value, message=f"Fit EOS: {ex}")
        db.set_task("eos", st)
        db.save(work_dir / WORKFLOW_STATE_FILENAME)
        raise

    st = TaskState(
        status=TaskStatus.DONE.value,
        message="EOS terminé (SCF + fit)",
        data=summary,
    )
    db.set_task("eos", st)
    db.save(work_dir / WORKFLOW_STATE_FILENAME)
    return summary


def task_optimize_scf_only(
    work_dir: Path,
    material_id: str,
    template_pw: Path,
    db: WorkflowDB,
    conf: Optional[EosConfig] = None,
    *,
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """
    Les ``scf_vol_XX.in`` doivent déjà exister.
    Lance uniquement les ``pw.x`` (un par volume) — pas de fit Birch–Murnaghan.
    L’étape suivante (ajustement EOS + tracé) utilise ``task_optimize_fit_only``.
    """
    work_dir = wf1_eos_run_root(work_dir)
    tp = Path(template_pw).resolve()
    if conf is None:
        conf = EosConfig(template_pw=tp)
    else:
        conf = replace(conf, template_pw=tp)
    tdir = work_dir / conf.subdir
    if not tdir.is_dir():
        raise ValueError(f"Dossier des volumes introuvable : {tdir}")

    strains = np.linspace(conf.strain_min, conf.strain_max, conf.n_points)
    jobs: list[Tuple[str, str, int]] = []
    for i in range(conf.n_points):
        label = f"scf_vol_{i:02d}.in"
        p = tdir / label
        if not p.is_file():
            raise ValueError(
                f"Fichier manquant : {p} — générez d’abord la grille (même n, même m) "
                f"ou vérifiez le dossier."
            )
        jobs.append((str(tdir), label, conf.nproc))

    st = TaskState(status=TaskStatus.RUNNING.value, message=f"Lancement {len(jobs)} × pw.x (SCF seul)")
    db.set_task("eos", st)
    db.save(work_dir / WORKFLOW_STATE_FILENAME)

    results = _dispatch_pw_jobs(
        jobs, conf, db, work_dir,
        cancel_event=cancel_event, proc_holder=proc_holder,
    )

    details: list[dict[str, Any]] = []
    for in_name, e, v, out_path in results:
        details.append(
            {
                "in": in_name,
                "E_Ry": float(e),
                "V_bohr3": float(v),
                "out": str(Path(out_path).resolve()),
            }
        )

    summary: dict[str, Any] = {
        "phase": "scf_only",
        "n_points": conf.n_points,
        "strains": [float(s) for s in strains],
        "details": details,
        "next_step": "fit_only",
        "hint": "Lancez l’ajustement E(V) + Birch–Murnaghan + tracé (étape 3.3).",
    }
    st = TaskState(
        status=TaskStatus.DONE.value,
        message="SCF par volume terminés — étape 3.3 : E(V) + Murnaghan + tracé",
        data=summary,
    )
    db.set_task("eos", st)
    db.save(work_dir / WORKFLOW_STATE_FILENAME)
    return summary


def task_optimize(
    work_dir: Path,
    material_id: str,
    template_pw: Path,
    db: WorkflowDB,
    conf: Optional[EosConfig] = None,
    *,
    cancel_event: Optional[threading.Event] = None,
    proc_holder: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    work_dir = wf1_eos_run_root(work_dir)
    tp = Path(template_pw).resolve()
    if conf is None:
        conf = EosConfig(template_pw=tp)
    else:
        conf = replace(conf, template_pw=tp)
    tdir = work_dir / conf.subdir
    tdir.mkdir(parents=True, exist_ok=True)

    st = TaskState(status=TaskStatus.RUNNING.value, message="Génération des volumes")
    db.set_task("eos", st)
    db.save(work_dir / WORKFLOW_STATE_FILENAME)

    strains = np.linspace(conf.strain_min, conf.strain_max, conf.n_points)
    for i, eps in enumerate(strains):
        label = f"scf_vol_{i:02d}.in"
        out_in = tdir / label
        scale_pw_input_file(conf.template_pw, out_in, float(eps))

    return task_optimize_scf_and_fit(
        work_dir, material_id, template_pw, db, conf,
        cancel_event=cancel_event, proc_holder=proc_holder,
    )

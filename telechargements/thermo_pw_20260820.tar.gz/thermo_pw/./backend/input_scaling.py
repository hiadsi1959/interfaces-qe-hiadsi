"""
Génère des entrées pw à partir d'un modèle en appliquant une contrainte isotrope (±% sur le paramètre de maille).
- Si `celldm(1) =` est trouvé, on remplace la valeur : new = old * (1 + eps).
- Sinon, si `CELL_PARAMETERS` (alat ou bohr), on multiplie chaque composante de vecteur par (1+eps) (déformation isotrope des vecteurs de base).

Expose aussi ``extract_lattice_parameters`` (août 2026) : lecture des
paramètres de maille a/b/c d'une entrée pw.x — utilisé après le fit
Birch–Murnaghan pour afficher la maille d'équilibre (V₀ seul est peu
parlant pour l'utilisateur).
"""
from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Any, List, Optional

BOHR_TO_ANGSTROM = 0.529177210903

RE_CELLDM1 = re.compile(r"^(?P<head>\s*celldm\(1\)\s*=\s*)(?P<v>[+-]?\d+\.?\d*)(?P<tail>\s*)$", re.IGNORECASE)

# Même prefix / outdir + plusieurs pw.x en parallèle = collision sur le disque.
_RE_PREFIX = re.compile(
    r"^(\s*prefix\s*=\s*)([\'\"])(.*?)(\2)(.*)$", re.IGNORECASE | re.MULTILINE
)
_RE_OUTDIR = re.compile(
    r"^(\s*outdir\s*=\s*)([\'\"])(.*?)(\2)(.*)$", re.IGNORECASE | re.MULTILINE
)


def _safe_stem_for_qe(stem: str) -> str:
    t = re.sub(r"[^0-9A-Za-z_]+", "_", (stem or "x").strip())
    t = re.sub(r"_+", "_", t).strip("_")
    return (t[:48] or "pw")


def _apply_unique_prefix_outdir(text: str, stem: str) -> str:
    """Un run = un couple prefix + outdir (plusieurs pw.x dans le même dossier)."""
    key = _safe_stem_for_qe(stem)
    od = f"./out_{key}/"

    def psub(m: re.Match) -> str:
        g5 = m.group(5) if m.lastindex and m.lastindex >= 5 else ""
        return f"{m.group(1)}{m.group(2)}{key}{m.group(2)}{g5}"

    def osub(m: re.Match) -> str:
        g5 = m.group(5) if m.lastindex and m.lastindex >= 5 else ""
        return f"{m.group(1)}{m.group(2)}{od}{m.group(2)}{g5}"

    s = text
    if _RE_PREFIX.search(s):
        s = _RE_PREFIX.sub(psub, s, count=1)
    if _RE_OUTDIR.search(s):
        s = _RE_OUTDIR.sub(osub, s, count=1)
    return s


_RE_FLOAT = r"[+-]?\d+(?:\.\d*)?(?:[eEdD][+-]?\d+)?"


def _to_float(tok: str) -> float:
    """Float Fortran-friendly (1.0d1 → 10.0)."""
    return float(tok.replace("d", "e").replace("D", "E"))


def extract_lattice_parameters(text: str) -> dict[str, Any]:
    """Paramètres de maille a/b/c lus dans une entrée pw.x.

    Trois représentations QE couvertes, par ordre de priorité :
      1. ``ibrav`` + ``celldm(1..6)`` — relations standard par réseau de
         Bravais (cubique : b=c=a ; hex/tétra : c = celldm(3)·a ; ortho+ :
         b = celldm(2)·a, c = celldm(3)·a) ;
      2. ``A=``/``B=``/``C=`` (Å) — mêmes relations, unités Å directes ;
      3. ``CELL_PARAMETERS`` (bohr|angstrom|alat) — normes des trois
         vecteurs primitifs (seule lecture possible pour ibrav=0).

    Retourne un dict {"a0_bohr", "a0_A", "b0_A", "c0_A", "lattice_source"} ;
    les clés absentes de l'entrée restent à None. Pour les réseaux cubiques,
    a est le paramètre de la maille CONVENTIONNELLE (= celldm(1)), la
    convention QE que l'utilisateur a lui-même écrite dans son entrée.
    """
    out: dict[str, Any] = {
        "a0_bohr": None, "a0_A": None, "b0_A": None, "c0_A": None,
        "lattice_source": None,
    }

    ibrav: Optional[int] = None
    m = re.search(r"(?im)^\s*ibrav\s*=\s*([+-]?\d+)", text)
    if m:
        ibrav = int(m.group(1))

    celldm: dict[int, float] = {}
    for cm in re.finditer(
        rf"(?i)celldm\((\d)\)\s*=\s*({_RE_FLOAT})", text
    ):
        try:
            celldm[int(cm.group(1))] = _to_float(cm.group(2))
        except ValueError:
            continue

    abc_A: dict[str, float] = {}
    for name in ("A", "B", "C"):
        am = re.search(rf"(?im)^\s*{name}\s*=\s*({_RE_FLOAT})", text)
        if am:
            try:
                abc_A[name] = _to_float(am.group(1))
            except ValueError:
                continue

    # Normes des vecteurs CELL_PARAMETERS (ibrav=0, ou complément alat).
    cell_norms: Optional[list[float]] = None
    cell_units = ""
    cm = re.search(
        r"(?im)^\s*CELL_PARAMETERS\s*[({]?\s*(\w*)\s*[)}]?\s*$", text
    )
    if cm:
        cell_units = (cm.group(1) or "alat").lower()
        vecs: list[list[float]] = []
        for line in text[cm.end():].splitlines():
            toks = line.split()
            if len(toks) >= 3:
                try:
                    vecs.append([_to_float(t) for t in toks[:3]])
                except ValueError:
                    break
            elif line.strip():
                break
            if len(vecs) == 3:
                break
        if len(vecs) == 3:
            cell_norms = [math.sqrt(sum(x * x for x in v)) for v in vecs]

    def _fill_from_a_bohr(a: float, b: Optional[float], c: Optional[float],
                          source: str) -> None:
        out["a0_bohr"] = round(a, 6)
        out["a0_A"] = round(a * BOHR_TO_ANGSTROM, 6)
        if b is not None:
            out["b0_A"] = round(b * BOHR_TO_ANGSTROM, 6)
        if c is not None:
            out["c0_A"] = round(c * BOHR_TO_ANGSTROM, 6)
        out["lattice_source"] = source

    cubic = ibrav in (1, 2, 3, -3)
    one_axis = ibrav in (4, 6, 7)  # hex / tétra : c/a dans celldm(3)

    if ibrav == 0 and cell_norms:
        # ibrav=0 : seule la matrice fait foi.
        factor: Optional[float] = None
        if cell_units.startswith("bohr"):
            factor = 1.0
        elif cell_units.startswith("angs"):
            factor = 1.0 / BOHR_TO_ANGSTROM
        elif celldm.get(1):
            factor = celldm[1]  # alat
        elif abc_A.get("A"):
            factor = abc_A["A"] / BOHR_TO_ANGSTROM
        if factor is not None:
            a, b, c = (n * factor for n in cell_norms)
            _fill_from_a_bohr(a, b, c, "normes des vecteurs CELL_PARAMETERS")
        return out

    if celldm.get(1):
        a = celldm[1]
        if cubic:
            b: Optional[float] = a
            c: Optional[float] = a
        elif one_axis:
            b = a
            c = celldm[3] * a if celldm.get(3) else None
        else:
            b = celldm[2] * a if celldm.get(2) else None
            c = celldm[3] * a if celldm.get(3) else None
        _fill_from_a_bohr(a, b, c, "ibrav + celldm")
        return out

    if abc_A.get("A"):
        a_A = abc_A["A"]
        if cubic:
            b_A: Optional[float] = a_A
            c_A: Optional[float] = a_A
        elif one_axis:
            b_A = a_A
            c_A = abc_A.get("C")
        else:
            b_A = abc_A.get("B")
            c_A = abc_A.get("C")
        out["a0_bohr"] = round(a_A / BOHR_TO_ANGSTROM, 6)
        out["a0_A"] = round(a_A, 6)
        out["b0_A"] = round(b_A, 6) if b_A is not None else None
        out["c0_A"] = round(c_A, 6) if c_A is not None else None
        out["lattice_source"] = "ibrav + A/B/C (Å)"
        return out

    if cell_norms:
        # Dernier recours (ibrav≠0 mais matrice présente).
        factor = None
        if cell_units.startswith("bohr"):
            factor = 1.0
        elif cell_units.startswith("angs"):
            factor = 1.0 / BOHR_TO_ANGSTROM
        if factor is not None:
            a, b, c = (n * factor for n in cell_norms)
            _fill_from_a_bohr(a, b, c, "normes des vecteurs CELL_PARAMETERS")
    return out


def scale_pw_input_file(template: Path, out_path: Path, linear_strain: float) -> None:
    """
    linear_strain = eps : a_scal = a0 * (1+eps) (maille cristalline isotrope).
    """
    text = template.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines(keepends=False)
    out_lines: List[str] = []
    f = 1.0 + float(linear_strain)
    in_cell = False
    n_cell_left = 0
    for line in lines:
        m = RE_CELLDM1.match(line)
        if m:
            v = float(m.group("v")) * f
            out_lines.append(f"{m.group('head')}{v:.12f}{m.group('tail') or ''}")
            continue
        up = line.strip().upper()
        if "CELL_PARAMETERS" in up and not in_cell:
            in_cell = True
            n_cell_left = 3
            out_lines.append(line)
            continue
        if in_cell and n_cell_left > 0:
            parts = re.split(r"(\s+)", line, maxsplit=1)
            if len(parts) >= 1:
                toks = line.split()
                if len(toks) >= 3:
                    scaled = " ".join(f"{float(x)*f:.12f}" for x in toks[:3])
                    if len(toks) > 3:
                        scaled += "  " + " ".join(toks[3:])
                    out_lines.append(" " * (len(line) - len(line.lstrip())) + scaled)
                else:
                    out_lines.append(line)
            n_cell_left -= 1
            if n_cell_left == 0:
                in_cell = False
            continue
        out_lines.append(line)

    text = "\n".join(out_lines) + "\n"
    text = _apply_unique_prefix_outdir(text, out_path.stem)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(text, encoding="utf-8")

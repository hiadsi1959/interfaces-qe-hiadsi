"""
Estimation de la progression (1–99 %) pour les jobs API longs.

Basée sur des indices lisibles sur disque (journal thermo_pw, workflow_state EOS).
Ce n’est pas un pourcentage « réel » renvoyé par Quantum ESPRESSO : thermo_pw enchaîne
plusieurs phases (SCF ionique / phonons / drivers…) sans métrique globale unique.
Pour thermo_pw.x, on se rapproche toutefois du déroulé réel en parcourant **tout** le journal
pour les marqueurs ``//gN/`` (pas seulement la fin du fichier, où souvent il n’y a que la sortie PW dense).
"""
from __future__ import annotations

import json
import re
import threading
from pathlib import Path
from typing import Any, Optional

from eos_paths import EOS_VOLUMES_SUBDIR, WORKFLOW_STATE_FILENAME

# thermo_pw / pw.x écrivent les répertoires de relaxation ionique sous la forme …//g12/…
RE_THERMO_GEOM_DIR = re.compile(r"//g(\d+)/")

_geom_lock = threading.Lock()
_geom_state: dict[str, tuple[int, int]] = {}
# journal résolu → (dernière taille vue, max indice g trouvé).


def _read_file_tail_utf8(path: Path, *, max_bytes: int = 12_000_000) -> str:
    try:
        sz = path.stat().st_size
    except OSError:
        return ""
    if sz <= 0:
        return ""
    read_n = min(max_bytes, sz)
    try:
        with path.open("rb") as f:
            if sz > read_n:
                f.seek(sz - read_n)
            raw = f.read()
    except OSError:
        return ""
    try:
        return raw.decode("utf-8", errors="replace")
    except Exception:
        return ""


def _pw_out_job_done_tail(path: Path) -> bool:
    try:
        sz = path.stat().st_size
    except OSError:
        return False
    if sz <= 0:
        return False
    n = min(12_000, sz)
    try:
        with path.open("rb") as f:
            if sz > n:
                f.seek(sz - n)
            chunk = f.read().decode("utf-8", errors="replace")
    except OSError:
        return False
    return "JOB DONE" in chunk


def _eos_parallel_scf_progress(work_dir: Path) -> Optional[int]:
    tdir = work_dir / EOS_VOLUMES_SUBDIR
    if not tdir.is_dir():
        return None
    try:
        ins = sorted(tdir.glob("scf_vol_*.in"))
    except OSError:
        return None
    n = len(ins)
    if n <= 0:
        return None
    done = 0
    for outp in sorted(tdir.glob("scf_vol_*.out")):
        if _pw_out_job_done_tail(outp):
            done += 1
    if done <= 0:
        return 12
    return min(92, int(round(100.0 * done / n)))


def _scan_backward_max_geometry(logp: Path, *, chunk_size: int = 6_291_456, max_scan: int = 134_217_728) -> int:
    """Lit le fichier par fenêtres depuis la fin jusqu’à ``max_scan`` octets pour extraire max(g)."""
    pat = RE_THERMO_GEOM_DIR
    max_g = 0
    try:
        sz = logp.stat().st_size
    except OSError:
        return 0
    if sz <= 0:
        return 0
    scan_budget = min(sz, max_scan)
    if sz <= chunk_size:
        try:
            txt = logp.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return 0
        for m in pat.finditer(txt):
            max_g = max(max_g, int(m.group(1)))
        return max_g
    overlap = 512
    pos_end = sz
    scanned = 0
    while pos_end > 0 and scanned < scan_budget:
        pos_start = max(0, pos_end - chunk_size)
        try:
            with logp.open("rb") as f:
                f.seek(pos_start)
                raw = f.read(pos_end - pos_start)
        except OSError:
            break
        txt = raw.decode("utf-8", errors="replace")
        for m in pat.finditer(txt):
            max_g = max(max_g, int(m.group(1)))
        scanned += pos_end - pos_start
        if pos_start == 0:
            break
        pos_end = pos_start + overlap
    return max_g


def _update_max_geometry_index(logp: Path) -> int:
    """
    Maintient un max d’indices ioniques ``g`` avec mise à jour incrémentale quand le journal grossit,
    et rescan borné si fichier tronqué ou première lecture.
    """
    try:
        sz = logp.stat().st_size
    except OSError:
        return 0
    key = str(logp.resolve())
    overlap = 512
    pat = RE_THERMO_GEOM_DIR

    with _geom_lock:
        prev = _geom_state.get(key)

    if sz <= 0:
        with _geom_lock:
            _geom_state.pop(key, None)
        return 0

    need_full = prev is None or sz < prev[0]
    if need_full:
        mg = _scan_backward_max_geometry(logp)
        with _geom_lock:
            _geom_state[key] = (sz, mg)
        return mg

    last_sz, prev_max = prev
    if sz == last_sz:
        return prev_max

    start = max(0, last_sz - overlap)
    try:
        with logp.open("rb") as f:
            f.seek(start)
            raw = f.read(sz - start)
        txt = raw.decode("utf-8", errors="replace")
    except OSError:
        return prev_max

    mg = prev_max
    for m in pat.finditer(txt):
        mg = max(mg, int(m.group(1)))
    with _geom_lock:
        _geom_state[key] = (sz, mg)
    return mg


def _scf_iteration_hint_pct(txt_tail: str) -> Optional[int]:
    """
    Quand aucun ``//gN/`` exploitable dans la zone analysée : indices depuis les boucles PW ou phonons.

    - ``iteration #`` : boucles électroniques pw.x habituelles.
    - ``iter #`` : sortie type DFPT / réponse linéaire (``ddv_scf``, Sternheimer…) dans thermo_pw_run.out ;
      le nombre total d’itérations à faire n’est pas connu — le pourcent UI reste une borne modeste.
    """
    pw = [int(x) for x in re.findall(r"(?im)^\s*iteration\s+#\s+(\d+)\s+", txt_tail)]
    dfpt = [int(x) for x in re.findall(r"(?im)^\s*iter\s+#\s+(\d+)\s+", txt_tail)]
    hints: list[int] = []
    if pw:
        hints.append(min(36, 5 + min(pw[-1], 48)))
    if dfpt:
        hints.append(min(34, 8 + min(dfpt[-1], 48)))
    return max(hints) if hints else None


def _pct_from_thermo_pw_log(work_dir: Path) -> Optional[int]:
    logp = work_dir / "thermo_pw_run.out"
    if not logp.is_file():
        return None
    txt = _read_file_tail_utf8(logp)
    if not txt.strip():
        return None
    max_g = _update_max_geometry_index(logp)
    mtot = re.search(r"minimization will require\s+(\d+)\s+scf", txt, flags=re.I)
    ntot = int(mtot.group(1)) if mtot else 0

    if ntot > 0:
        if max_g <= 0:
            hint = _scf_iteration_hint_pct(txt)
            early = hint if hint is not None else 4
            return min(82, max(3, early))
        raw = int(round(100.0 * min(max_g, ntot) / float(ntot)))
        raw = min(97, max(0, raw))
        if max_g >= ntot:
            if re.search(r"Computing the anharmonic", txt, flags=re.I):
                return min(99, max(raw, 92))
            return min(99, max(raw, 85))
        return max(2, raw)

    if max_g > 0:
        cap = max(max_g, 6)
        return min(88, 12 + int(round(68.0 * max_g / float(cap))))

    hint = _scf_iteration_hint_pct(txt)
    if hint is not None:
        return hint

    if "Program THERMO_PW" in txt[:1200] or len(txt) > 400:
        return 4
    return None


def _pct_from_eos_workflow(work_dir: Path) -> Optional[int]:
    p = work_dir / WORKFLOW_STATE_FILENAME
    if not p.is_file():
        return None
    try:
        wf = json.loads(p.read_text(encoding="utf-8", errors="replace"))
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        return None
    eos = (wf.get("tasks") or {}).get("eos") or {}
    if not isinstance(eos, dict):
        return None
    msg = str(eos.get("message") or "")
    low = msg.lower()
    m = re.search(r"SCF\s+(\d+)\s*/\s*(\d+)", msg, flags=re.I)
    if m:
        cur, tot = int(m.group(1)), int(m.group(2))
        if tot > 0:
            return min(93, int(round(100.0 * cur / float(tot))))
    if "fit" in low and ("murn" in low or "mur" in low or "birch" in low):
        return 97
    if "lancement" in low and "pw.x" in low:
        return _eos_parallel_scf_progress(work_dir)
    if "génération" in low or "grille" in low or "volumes" in low:
        return 8
    return 15


def estimate_job_progress_pct(work_dir: Path, job: dict[str, Any]) -> Optional[int]:
    """
    Retourne un entier 1–99 pendant l’exécution, ou ``None`` si inconnu.

    Approximation uniquement ; pour thermo_pw, voir l’en-tête du module sur les limites physiques.
    """
    st = str(job.get("status") or "").lower()
    if st not in ("running", "queued"):
        return None
    wd = work_dir.resolve()
    kind = str(job.get("kind") or "").strip().lower()
    mode = str(job.get("mode") or "").strip().lower()
    msg = str(job.get("message") or "")

    if kind == "run_thermo_pw" or "thermo_pw.x mpi" in msg.lower():
        if st == "queued":
            return 1
        return _pct_from_thermo_pw_log(wd)

    if mode in ("full", "scf_only", "scf_and_fit", "volumes_only", "fit_only"):
        if st == "queued":
            return 1
        if mode == "fit_only":
            return 55
        if mode == "volumes_only":
            return _pct_from_eos_workflow(wd) or 20
        return _pct_from_eos_workflow(wd)

    if "eos en cours" in msg.lower() or "scf par volume" in msg.lower():
        if st == "queued":
            return 1
        return _pct_from_eos_workflow(wd)

    return None

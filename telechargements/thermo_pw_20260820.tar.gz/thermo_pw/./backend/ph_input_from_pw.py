"""
Génère un ph.in minimal à partir de pw_scf_V0_for_phonon.in (même prefix / outdir).
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Optional, Tuple

_RE_PREFIX = re.compile(
    r"^\s*prefix\s*=\s*['\"]([^'\"]+)['\"]", re.IGNORECASE | re.MULTILINE
)
_RE_OUTDIR = re.compile(
    r"^\s*outdir\s*=\s*['\"]([^'\"]+)['\"]", re.IGNORECASE | re.MULTILINE
)
_RE_INPUTPH_START = re.compile(r"(?mi)^\s*&inputph\b")
_RE_NQ_LINE = re.compile(r"(?mi)^(?P<lead>\s*nq(?P<id>[123])\s*=\s*)(?P<num>\d+)" )
_RE_OUTDIR_LINE = re.compile(
    r"(?mi)^[ \t]*outdir[ \t]*=[ \t]*['\"][^'\"]*['\"][ \t]*,?[ \t]*\r?\n"
)

# thermo_pw 7.x mur_lc_disp / mur_lc_t : grille 2×2×2 provoque souvent forrtl 71 (frc_blk) dans matdyn_sub.
_PH_Q_MESH_MIN_FOR_MATDYN = 4


def coerce_ph_q_grid_minimum(
    text: str,
    *,
    min_when_coarse: int = _PH_Q_MESH_MIN_FOR_MATDYN,
    coarse_threshold: int = 2,
) -> tuple[str, bool]:
    """
    Si chaque ``nq1,nq2,nq3 ≤ coarse_threshold``, remonte à au moins ``min_when_coarse``
    pour éviter matdyn_interp / frc_blk (divide by zero) avec thermo_pw 7.x.
    """
    if not text.strip():
        return text, False
    found: dict[int, int] = {}
    for m in _RE_NQ_LINE.finditer(text):
        qi = int(m.group("id"))
        found[qi] = int(m.group("num"))
    if len(found) != 3 or max(found.values()) > coarse_threshold:
        return text, False

    def _repl(m: re.Match[str]) -> str:
        n = max(int(m.group("num")), min_when_coarse)
        return m.group("lead") + str(n)

    out = _RE_NQ_LINE.sub(_repl, text)
    return out, True


def strip_outdir_for_thermo_pw(text: str) -> Tuple[str, Optional[str]]:
    """Retire ``outdir`` du ``&inputph`` destiné à thermo_pw. Renvoie (texte, valeur ôtée).

    thermo_pw appelle ``set_outdir_name(igeom)`` (``tools/src/set_files_names.f90``),
    qui redirige ``outdir`` vers ``<outdir_pw>/g<N>/`` avant chaque géométrie, **puis**
    lit ``ph_control`` via ``phq_readin_tpw``. Un ``outdir`` explicite dans le namelist
    écrase donc cette redirection, et les neuf géométries relisent les fonctions d'onde
    du seul volume d'équilibre : fréquences identiques, paramètres de Grüneisen nuls,
    dilatation thermique nulle, et ajustement QHA final singulier (abandon dans DGELS).
    Les ``ph_control`` des exemples thermo_pw ne déclarent jamais ``outdir``.

    Ne s'applique qu'à ``ph_control``. Un ``ph.in`` autonome, lui, en a besoin.
    """
    if not text or not text.strip():
        return text, None
    m = _RE_INPUTPH_START.search(text)
    if not m:
        return text, None
    head, body = text[: m.start()], text[m.start() :]
    found = _RE_OUTDIR.search(body)
    if not found:
        return text, None
    return head + _RE_OUTDIR_LINE.sub("", body), found.group(1)


def normalize_ph_control_for_thermo_pw(text: str) -> str:
    """
    thermo_pw / phq_readin_tpw attend une première ligne titre (voir exemples QE,
    cf. dalcorso/example24/ph_control « ph_title ») avant ``&inputph``. Les commentaires !
    ne suffisent pas : la lecture ligne titre consomme quand même une ligne littérale.
    Insère « thermo_pw_ph » avant ``&inputph`` s’il n’existe aucune ligne « titre » avant le namelist.
    """
    if not text or not text.strip():
        return text
    text, _ = strip_outdir_for_thermo_pw(text)
    m = _RE_INPUTPH_START.search(text)
    if not m:
        return text
    before = text[: m.start()].splitlines()
    has_title = False
    for ln in before:
        s = ln.strip()
        if not s or s.startswith("!"):
            continue
        if s.startswith("&"):
            break
        has_title = True
        break
    if has_title:
        t2, _ = coerce_ph_q_grid_minimum(text)
        return t2
    insert = "thermo_pw_ph\n\n"
    text_out = text[: m.start()] + insert + text[m.start() :]
    text_out, _ = coerce_ph_q_grid_minimum(text_out)
    return text_out


def parse_prefix_outdir_from_pw_text(text: str) -> Tuple[Optional[str], Optional[str]]:
    pm = _RE_PREFIX.search(text)
    om = _RE_OUTDIR.search(text)
    return (pm.group(1) if pm else None, om.group(1) if om else None)


def try_autogenerate_ph_in(
    work_dir: Path,
    ph_basename: str = "ph.in",
    *,
    pw_basename: str = "pw_scf_V0_for_phonon.in",
    nq1: int = 4,
    nq2: int = 4,
    nq3: int = 4,
    force: bool = False,
) -> tuple[bool, str]:
    """
    Si ``ph_basename`` est absent (ou ``force``), le crée d’après le .pw du run.
    Renvoie (True, message) en cas de succès, (False, raison) sinon.
    """
    work_dir = Path(work_dir)
    ph_path = work_dir / ph_basename
    if ph_path.is_file() and not force:
        return True, ""
    pw_path = work_dir / pw_basename
    if not pw_path.is_file():
        return (
            False,
            f"Ni {ph_basename!r} ni {pw_basename!r} — lancez d’abord l’EOS (fit) pour produire {pw_basename!r}, "
            f"ou créez {ph_basename!r} à la main (Howto 1.8).",
        )
    text = pw_path.read_text(encoding="utf-8", errors="replace")
    prefix, outdir = parse_prefix_outdir_from_pw_text(text)
    if not prefix or not outdir:
        return (
            False,
            f"Impossible de lire prefix/outdir dans {pw_basename!r} — éditez {ph_basename!r} manuellement.",
        )
    nq1 = max(1, int(nq1))
    nq2 = max(1, int(nq2))
    nq3 = max(1, int(nq3))
    tr2 = "1.0d-14"
    # ``ph_control`` est lu par thermo_pw pour chaque géométrie : y déclarer ``outdir``
    # écraserait la redirection ``…/g<N>/`` et ferait recalculer neuf fois le même
    # volume (cf. strip_outdir_for_thermo_pw). Un ``ph.in`` autonome en a besoin.
    is_thermo_pw_control = ph_basename.strip() == "ph_control"
    outdir_line = "" if is_thermo_pw_control else f"  outdir = '{outdir}'\n"
    origin = "prefix" if is_thermo_pw_control else "prefix/outdir"
    content = f"""! Généré automatiquement par thermo_pw (ph.x — même {origin} que {pw_basename})
! Ajustez tr2_ph, nq1..nq3, fildyn (Howto 1.8, thermo_pw) selon le système.
!
thermo_pw_ph

&inputph
  tr2_ph = {tr2}
  prefix = '{prefix}'
{outdir_line}  ldisp = .true.
  nq1 = {nq1}
  nq2 = {nq2}
  nq3 = {nq3}
  fildyn = 'ph_dyn'
  fildvscf = 'dvscf'
/
"""
    ph_path.write_text(content, encoding="utf-8")
    return (
        True,
        f"{ph_basename!r} écrit à partir de {pw_basename!r} (prefix={prefix!r}, q-grille {nq1}×{nq2}×{nq3}).",
    )


def nq_from_request_body(data: dict[str, Any]) -> tuple[int, int, int]:
    """Lecture optionnelle nq [n1,n2,n3] ou nq1,nq2,nq3 distincts."""
    nq = data.get("nq")
    if isinstance(nq, (list, tuple)) and len(nq) >= 3:
        try:
            return (max(1, int(nq[0])), max(1, int(nq[1])), max(1, int(nq[2])))
        except (TypeError, ValueError):
            pass
    try:
        return (
            max(1, int(data.get("nq1", 4))),
            max(1, int(data.get("nq2", 4))),
            max(1, int(data.get("nq3", 4))),
        )
    except (TypeError, ValueError):
        return (4, 4, 4)

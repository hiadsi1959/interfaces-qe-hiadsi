#!/usr/bin/env python3
"""Juillet 2026 (P3++) - dedupe + extend _process_memory_stats().

Effet de bord resolu : la fonction etait DEFINIE 2 FOIS dans api_server.py
(le patcher P1+P3 etait non-idempotent — review 🔴 #1). On dedoublonne d'abord
(delete la 1ere def dans le bloc des helpers P1+P3) puis on remplace la def
SURVIVANTE par la version etendue (6 champs au lieu de 3) :
  * api_memory_num_fds       — len(os.listdir('/proc/self/fd')), detection FD leak
  * api_memory_rssfile_mb    — RssFile (kB) depuis /proc/self/status, resident
                                file mappings (mmap'd wfc/wavecar kept open trop
                                longtemps)
  * api_memory_vmdata_mb     — VmData (kB), taille du segment data (heap Python,
                                objets charges en memoire mais pas en RSS :
                                objets desalloues mais pas encore rendus a l'OS)

Idempotent : skip si le pattern de l'extension (api_memory_num_fds) est deja
applique (compte >= 2 defs concurrentes = toujours patcher la duplication).
"""
import re
import sys
from pathlib import Path

TARGET = Path("/home/hiadsi/thermo_pw/backend/api_server.py")


def _ext_def_body() -> str:
    """Version etendue de _process_memory_stats() (6 champs)."""
    return '''def _process_memory_stats():
    """Juillet 2026 (P3++) - metriques memoire + ballast FD pour precurseur OOM.

    Lit ``/proc/self/status`` (Linux / WSL2) et ``/proc/self/fd`` (meme OS).
    No-op silencieux si ``/proc`` absent (Windows natif, conteneur verrouille) :
    renvoie ``None`` plutot que zero pour distinguer « non observable » de
    « 0 Mo ».

    Champs exposes cote ``/api/health`` :
      * ``api_memory_vmrss_mb``        - RSS courant (taille residente, en Mo)
      * ``api_memory_vmpeak_mb``       - Pic RSS depuis demarrage (en Mo)
      * ``api_memory_threads``         - Nombre de threads Python + OS
      * ``api_memory_num_fds``         - len(os.listdir('/proc/self/fd')) - FD leaks
      * ``api_memory_rssfile_mb``      - RssFile /proc/self/status - mmap'd wfc/wavecar
      * ``api_memory_vmdata_mb``       - VmData /proc/self/status - segment data

    Une remontee de ``api_memory_vmpeak_mb > 4 GiB`` OU
    ``api_memory_num_fds > 512`` (heuristique grossiere ; var selon le workload)
    doit alerter (signal precurseur d'un futur OOM-kill / fd-exhaustion) - a
    brancher sur une Prometheus alert / Grafana plus tard.
    """
    out = {
        "api_memory_vmrss_mb": None,
        "api_memory_vmpeak_mb": None,
        "api_memory_threads": None,
        "api_memory_num_fds": None,
        "api_memory_rssfile_mb": None,
        "api_memory_vmdata_mb": None,
    }
    try:
        # (1) /proc/self/status : RSS, peak, threads, RssFile, VmData
        try:
            with open("/proc/self/status", "r", encoding="utf-8", errors="replace") as f:
                stats = {}
                for line in f:
                    if ":" in line and (
                        line.startswith("VmRSS:")
                        or line.startswith("VmPeak:")
                        or line.startswith("VmData:")
                        or line.startswith("RssFile:")
                        or line.startswith("Threads:")
                    ):
                        k, v = line.split(":", 1)
                        stats[k.strip()] = v.strip()
            rss_kb = int(stats.get("VmRSS", "0").split()[0])
            peak_kb = int(stats.get("VmPeak", "0").split()[0])
            threads = int(stats.get("Threads", "0").split()[0])
            rssfile_kb = int(stats.get("RssFile", "0").split()[0])
            vmdata_kb = int(stats.get("VmData", "0").split()[0])
            out["api_memory_vmrss_mb"] = round(rss_kb / 1024, 1)
            out["api_memory_vmpeak_mb"] = round(peak_kb / 1024, 1)
            out["api_memory_threads"] = threads
            out["api_memory_rssfile_mb"] = round(rssfile_kb / 1024, 1)
            out["api_memory_vmdata_mb"] = round(vmdata_kb / 1024, 1)
        except (OSError, ValueError, IndexError, AttributeError):
            pass
        # (2) /proc/self/fd : len pour FD leak detection (Quantum ESPRESSO peut
        # ouvrir des dizaines de wfc/wavecar ; si cleanup oublie, count grimpe).
        try:
            import os as _os
            out["api_memory_num_fds"] = len(_os.listdir("/proc/self/fd"))
        except (OSError, ValueError, AttributeError):
            pass
        return out
    except Exception:  # pragma: no cover - filet de securite final
        return out
'''


def _old_def_pattern_prefix() -> str:
    """Prefix de pattern pour matcher TOUTES les defs de _process_memory_stats
    (du debut de def jusqu'au premier ':' de la docstring incluse, pour eviter
    d'etre trop gourmand sur le body)."""
    return r"def _process_memory_stats\(\):\s*\n\s*\"\"\".*?"


def main() -> int:
    src = TARGET.read_text(encoding="utf-8")
    new_def = _ext_def_body()

    # Sanity : compter les defs actuelles.
    def_pat = re.compile(r"^def _process_memory_stats\(\):", re.MULTILINE)
    matches = list(def_pat.finditer(src))
    n_defs = len(matches)

    if n_defs == 0:
        print("ERR: aucune def de _process_memory_stats trouvee - patch abandonnne.")
        return 1

    # Idempotence sur l'extension : on a deja la version 6-champs si
    # 'api_memory_num_fds' est mentionnee dans UNE des defs => on dededupe
    # seulement (au cas ou les dedupes precedents ont laisse 2 defs 6-champs).
    if n_defs >= 2 and "api_memory_num_fds" in src:
        # Garder uniquement LA DERNIERE def, supprimer les (n_defs - 1) premieres.
        # Suppression : on retire depuis chaque match.start() jusqu'au prochain
        # '' qui suit. On simplifie en matchant def _process_memory_stats():
        # jusqu'a la PREMIERE ligne vide double qui suit (signature standard).
        last_match = matches[-1]
        # Trouver la fin de la DERNIERE def (elle est bien formee : suit jusqu'a
        # son dedoublement vide).
        # End detection : scan ahead from last_match.start() until we find
        # ''\n def _process_memory_stats or ''\n @app.route or ''\ndef _rehydrate
        # Heuristique simple : fin = start + len(new_def) en general.
        # Mais comme new_def contient la doc de remplacement, on va juste
        # remplacer cette DERNIERE def par new_def.
        end_idx = src.find("\n\n\n", last_match.start())
        if end_idx == -1:
            end_idx = src.find("\n\n@", last_match.start())
        if end_idx == -1:
            end_idx = src.find("\n\n# ", last_match.start())
        if end_idx == -1:
            # fallback : find def _rehydrate_jobs_from_disk_marker
            mr = src.find("\n\ndef _rehydrate_jobs_from_disk_marker", last_match.start())
            if mr != -1:
                end_idx = mr
            else:
                end_idx = last_match.start() + 2000  # fallback dangereux
        # Delete TOUTES les autres defs (de findall(start < last_start))
        cut_count = 0
        for m in list(matches[:-1]):
            start_m = m.start()
            end_m = src.find("\n\n\n", start_m)
            if end_m == -1:
                end_m = src.find("\n\n@", start_m)
            if end_m == -1:
                end_m = src.find("\n\n# ", start_m)
            if end_m == -1:
                end_m = start_m + 2000  # fallback
            # Supprimer de start_m a end_m.
            src = src[:start_m] + src[end_m:]
            cut_count += 1
            # relocaliser (offsets decales)
            matches = list(def_pat.finditer(src))
        # Re-anchorer
        if matches:
            last_match = matches[-1]
            end_idx = src.find("\n\n\n", last_match.start())
            if end_idx == -1:
                end_idx = src.find("\n\n@", last_match.start())
            if end_idx == -1:
                end_idx = src.find("\n\n# ", last_match.start())
            if end_idx == -1:
                end_idx = last_match.start() + 2500
            new_src = src[: last_match.start()] + new_def + src[end_idx:]
            TARGET.write_text(new_src, encoding="utf-8")
            print(
                f"[OK] api_server.py : {n_defs} defs -> 1 dedupee, "
                f"{cut_count} defs en double supprimees, version 6-champs posee."
            )
            return 0
        print("ERR: relocalisation apres decoupe impossible.")
        return 1

    else:
        # Cas ou l'extension n'a JAMAIS ete faite ET il y a 2 defs identiques
        # (cas typique du premier run).
        if n_defs >= 2:
            # Meme logique : supprimer les (n_defs - 1) premieres defs.
            for m in list(matches[:-1]):
                start_m = m.start()
                end_m = src.find("\n\n\n", start_m)
                if end_m == -1:
                    end_m = src.find("\n\n@", start_m)
                if end_m == -1:
                    end_m = src.find("\n\n# ", start_m)
                if end_m == -1:
                    end_m = start_m + 2000
                src = src[:start_m] + src[end_m:]
            matches = list(def_pat.finditer(src))
            if matches:
                last_match = matches[-1]
                end_idx = src.find("\n\n\n", last_match.start())
                if end_idx == -1:
                    end_idx = src.find("\n\n@", last_match.start())
                if end_idx == -1:
                    end_idx = src.find("\n\n# ", last_match.start())
                if end_idx == -1:
                    end_idx = last_match.start() + 2500
                new_src = src[: last_match.start()] + new_def + src[end_idx:]
                TARGET.write_text(new_src, encoding="utf-8")
                print(
                    f"[OK] api_server.py : {n_defs} defs dedupees a 1, "
                    f"version 6-champs possee."
                )
                return 0
        elif n_defs == 1:
            # Une seule def, deja peut-etre 3-champs ou deja 6-champs.
            m = matches[0]
            end_idx = src.find("\n\n\n", m.start())
            if end_idx == -1:
                end_idx = src.find("\n\n@", m.start())
            if end_idx == -1:
                end_idx = src.find("\n\n# ", m.start())
            if end_idx == -1:
                end_idx = m.start() + 2500
            new_src = src[: m.start()] + new_def + src[end_idx:]
            TARGET.write_text(new_src, encoding="utf-8")
            print(f"[OK] api_server.py : 1 def remplacee par version 6-champs.")
            return 0
        print("ERR: etat incoherent.")
        return 1


if __name__ == "__main__":
    sys.exit(main())

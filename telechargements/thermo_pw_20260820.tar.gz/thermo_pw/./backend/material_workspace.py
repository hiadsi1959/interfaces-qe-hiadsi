"""
Arborescence standard sous ``work/<matériau>/`` : dossiers par type de calcul + README.

Les nouveaux runs EOS (grille volumes / Birch–Murnaghan) sont créés sous
``run_eos/wf1_eos_<timestamp>_<suffix>/``. Les anciens chemins
``work/<mat>/wf1_eos_*`` restent valides pour l’API et le navigateur.
"""

from __future__ import annotations

from pathlib import Path

RUN_EOS_DIR = "run_eos"
RUN_ELASTIC_DIR = "run_elastic"
RUN_PHONON_DIR = "run_phonon"
RUN_OPTIC_DIR = "run_optic"
RUN_THERMO_DIR = "run_thermo"

ALL_KIND_DIRS = (
    RUN_EOS_DIR,
    RUN_ELASTIC_DIR,
    RUN_PHONON_DIR,
    RUN_OPTIC_DIR,
    RUN_THERMO_DIR,
)

README_MATERIAL = """# Espace travail matériau (thermo_pw / QE)

Sous ce dossier, les sorties sont classées par **type de calcul** :

| Dossier | Rôle |
|---------|------|
| `run_eos/` | Grille de volumes, fits EOS (Murnaghan…), résumés JSON — préfixe `wf1_eos_*` |
| `run_elastic/` | Constantes élastiques / scripts ou copies locales |
| `run_phonon/` | Chaîne phonons (`ph.x`, `fc.out`, QHA prérequis) |
| `run_optic/` | Optiques (`epsilon`, NSCF…) hors WF EOS principal |
| `run_thermo/` | Copies ou préparation entrées **thermo_pw** isolées |

L’interface et l’API pointent en général un **run EOS complet** sous `run_eos/wf1_eos_…/` ;
les fichiers `thermo_pw_run.out`, phonons gnuplot, etc. peuvent y résider selon le workflow.

"""


README_RUN_EOS = """# run_eos — équation d’état et grille de volumes

- Chaque sous-dossier `wf1_eos_<unixtime>_<6 hex>` est un **run** : grille `1_eos_volumes/`,
  `eos_summary.json`, tracés gnuplot après fit.
- **Exploitation** : dossier du run dans l’interface (Calculs → EOS / élasticité) ou  
  `GET …/thermo_output_parse?work_dir=…` pour le journal thermo_pw.
"""


README_RUN_ELASTIC = """# run_elastic — élasticité

- Réserve pour entrées `thermo_pw` dédiées aux déformations, ou exports depuis la chaîne GUI.
- **Référence** : user guide thermo_pw §1.11 (`scf_elastic_constants`, `mur_lc_elastic_constants`).
"""


README_RUN_PHONON = """# run_phonon — phonons / matrices dynamiques

- Réserve pour `ph.x`, `q2r`, `matdyn`, `fc.out` utilisés par **mur_lc_t** / QHA.
- **Exploitation** : bandes/DOS gnuplot ; cohérence `fildyn` avec `thermo_control`.
"""


README_RUN_OPTIC = """# run_optic — optique / diélectrique

- Pour chaînes epsilon / NSCF séparées du dossier EOS principal.
- Vérifier les entrées sous `thermo_pw/inputs/<matériau>/`.
"""


README_RUN_THERMO = """# run_thermo — thermodynamique (thermo_pw)

- Utile pour isoler scripts thermo_pw ou copies de `thermo_control` + entrée pw.
- Les runs lancés depuis l’interface avec dossier `wf1_eos_…` écrivent souvent **dans ce run** ;
  vous pouvez dupliquer ou lier symboliquement les résultats ici pour classement manuel.
"""


README_WF1_RUN = """# Run EOS (`wf1_eos_*`)

Ce dossier est la **racine du run** workflow 1 (grille de volumes, fit Birch–Murnaghan, prolongements phonons / thermo_pw selon votre chaîne).

## Contenu habituel

- `1_eos_volumes/` — points SCF et données EOS ; `eos_summary.json`, courbes après fit.
- `workflow_state.json` — état du workflow (si utilisé).
- Fichiers **`thermo_pw_run.out`**, `.dat` élasticités / gnuplot — selon les étapes lancées depuis l’interface ou l’API.

## Exploitation

1. **Interface** : coller ce chemin comme « dossier du run » (EOS, élasticité §1.11–§1.21).
2. **API** : `GET /api/workflow1/eos/thermo_output_parse?work_dir=<chemin_absolu_du_run>`
3. **Artefacts** : `GET /api/workflow1/eos/artifact?work_dir=…&relpath=…`

Voir aussi `README.md` du dossier parent `run_eos/` et du matériau.
"""


def _write_if_absent(path: Path, text: str) -> None:
    try:
        if path.exists():
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text.strip() + "\n", encoding="utf-8")
    except OSError:
        pass


def ensure_material_workspace(material_root: Path) -> None:
    """
    Crée les sous-dossiers ``run_*`` et les README par défaut (sans écraser un README existant).
    """
    material_root = Path(material_root).resolve()
    try:
        material_root.mkdir(parents=True, exist_ok=True)
    except OSError:
        return
    for sub in ALL_KIND_DIRS:
        try:
            (material_root / sub).mkdir(parents=True, exist_ok=True)
        except OSError:
            continue
    _write_if_absent(material_root / "README.md", README_MATERIAL)
    _write_if_absent(material_root / RUN_EOS_DIR / "README.md", README_RUN_EOS)
    _write_if_absent(material_root / RUN_ELASTIC_DIR / "README.md", README_RUN_ELASTIC)
    _write_if_absent(material_root / RUN_PHONON_DIR / "README.md", README_RUN_PHONON)
    _write_if_absent(material_root / RUN_OPTIC_DIR / "README.md", README_RUN_OPTIC)
    _write_if_absent(material_root / RUN_THERMO_DIR / "README.md", README_RUN_THERMO)


def eos_run_parent_dir(material_root: Path) -> Path:
    """Répertoire parent des dossiers ``wf1_eos_*`` pour ce matériau."""
    return Path(material_root).resolve() / RUN_EOS_DIR


def iter_wf1_eos_run_dirs(material_dir: Path) -> list[Path]:
    """Tous les dossiers ``wf1_eos_*`` : racine du matériau (ancien schéma) et ``run_eos/``."""
    out: list[Path] = []
    md = Path(material_dir).resolve()
    if not md.is_dir():
        return out
    try:
        for c in md.iterdir():
            if c.is_dir() and c.name.startswith("wf1_eos_") and not c.name.startswith("."):
                out.append(c.resolve())
    except OSError:
        pass
    reos = md / RUN_EOS_DIR
    if reos.is_dir():
        try:
            for c in reos.iterdir():
                if c.is_dir() and c.name.startswith("wf1_eos_") and not c.name.startswith("."):
                    out.append(c.resolve())
        except OSError:
            pass
    return out


def write_wf1_run_readme(run_dir: Path) -> None:
    """README standard à la racine d’un run ``wf1_eos_*`` (sans écraser un fichier existant)."""
    _write_if_absent(Path(run_dir).resolve() / "README.md", README_WF1_RUN)

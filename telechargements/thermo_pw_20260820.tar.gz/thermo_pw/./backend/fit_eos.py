"""
Ajustement Birch–Murnaghan 3e ordre (énergie E(V) en Ry, V en a.u.³, B0 en Ry/au³).

Convention : ``B0`` retourné par ``fit_birch_murnaghan`` est le **module de
bulk thermodynamique** en Ry/au³ (i.e. ``B₀ = -V dP/dV = V × d²E/dV²``).
La conversion vers GPa utilise ``RY_BOHR3_TO_GPA = 14710.0`` (CODATA :
  1 Ry = 2.179872e-18 J ; 1 bohr³ = 1.4818e-31 m³ → 1 Ry/bohr³ = 14710 GPa).

Historique : un typo ``6.0`` au lieu du ``2.0`` correct (dérivé de
``[6 - 4(V₀/V)^(2/3)] = 2 - 4t``) faisait que le ``B0`` fit était sous-
estimé d'un facteur 3 (B₀_fit = B₀_real/3). Corrigé juillet 2026.
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import curve_fit

__all__ = ["birch_murnaghan_E", "fit_birch_murnaghan", "b0_GPa", "RY_BOHR3_TO_GPA"]

# 1 Ry/bohr^3 = 14710 GPa (calcul exact : 2.179872e-18 J / 1.4818e-31 m^3 = 1.47100e+13 Pa).
# 14720 utilisé historiquement (approximation, écart ~0.07%).
RY_BOHR3_TO_GPA: float = 14710.0


def birch_murnaghan_E(V, E0, V0, B0, B0p):
    """
    Forme d'énergie Birch–Murnaghan 3e ordre (référence : Holzapfel / Alchagi).

        t = (V0/V)^(2/3) - 1
        E(V) = E0 + (9*V0*B0/16) * t^2 * (2 + t*(B0p - 4))

    Avec cette formulation, **B0 EST le module de bulk** (Ry/au³). Vérification
    algébrique au second ordre en (V-V0)/V0 :

        d²E/dV²|_{V=V0}  =  B0 / V0   ⟹   B0 = V0 × d²E/dV²

    (Note : le facteur ``2`` provient de ``6 - 4(V0/V)^(2/3)`` évalué à
    ``V=V0`` : on a ``(V0/V)^(2/3)=1`` au point d'équilibre, donc
    ``6 - 4·1 = 2``. Tout autre préfacteur décroche de cette identité.)
    """
    V = np.asarray(V, dtype=float)
    t = (V0 / V) ** (2.0 / 3.0) - 1.0
    return E0 + 9.0 * V0 * B0 / 16.0 * t**2 * (2.0 + t * (B0p - 4.0))


def fit_birch_murnaghan(
    volumes: np.ndarray, energies: np.ndarray, e0_guess: float | None = None
) -> tuple[dict, np.ndarray]:
    """
    Ajuste E(V) et renvoie un dict {E0, V0, B0, B0p} (B0 en Ry/au^3) + courbe modèle sur V.
    """
    v = np.asarray(volumes, float)
    e = np.asarray(energies, float)
    order = np.argsort(v)
    v, e = v[order], e[order]
    v0_0 = float(v[np.argmin(e)])
    e0_0 = e0_guess if e0_guess is not None else float(np.min(e))
    b0_0 = 0.01  # ~ 300 kbar * conversion approx ; affinage par courbe
    b0p_0 = 4.0
    p0 = (e0_0, v0_0, b0_0, b0p_0)
    bounds = ([np.min(e) - 1, np.min(v) * 0.7, 1e-4, 2.0], [np.max(e) + 1, np.max(v) * 1.3, 0.1, 8.0])
    try:
        popt, _ = curve_fit(
            birch_murnaghan_E, v, e, p0=p0, maxfev=20000, bounds=bounds, method="trf"
        )
        e0, v0, b0, b0p = popt
    except Exception:
        # Secours: parabole E(V) → minimum V0
        coefs = np.polyfit(v, e, 2)
        v0 = float(-coefs[1] / (2.0 * coefs[0]))
        e0 = float(np.interp(v0, v, e))
        b0, b0p = 0.02, 4.0
    out = {
        "E0_Ry": float(e0),
        "V0_bohr3": float(v0),
        "B0_Ry_bohr3": float(b0),
        "B0_prime": float(b0p),
    }
    e_fit = birch_murnaghan_E(v, e0, v0, b0, b0p)
    return out, e_fit


def b0_GPa(b0_ry_cubic: float) -> float:
    """Convertit le module de bulk ``B0`` (Ry/bohr³, tel que retourné par le
    fit Birch–Murnaghan) vers GPa.

    Conversion exacte : 1 Ry/bohr³ = 14710 GPa (CODATA-2018). Tolérance 0.1 %
    acceptable — utilisée par défaut dans QE thermo_pw.
    """
    return float(b0_ry_cubic) * RY_BOHR3_TO_GPA

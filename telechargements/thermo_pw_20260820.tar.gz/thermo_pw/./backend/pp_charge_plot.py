"""
Post-traitement QE : densité de charge électronique via pp.x (XSF / Cube, …).

Entrée de type officiel : &INPUTPP (filplot, plot_num) puis &PLOT avec
``nfile``, ``filepp(1)``, ``weight(1)``, ``iflag``, ``output_format``, ``fileout``
— voir exemple utilisateur § pp.x deux namelists.
"""
from __future__ import annotations

from pathlib import Path

import config as cfg
from eos_paths import EOS_VOLUMES_SUBDIR, wf1_eos_run_root
from ph_input_from_pw import parse_prefix_outdir_from_pw_text
from qe_subprocess import run_qe

_DEFAULT_FILPLOT = "charge_density_map"


def _resolve_qe_outdir_on_disk(work_dir: Path, outdir: str) -> Path:
    """Chemin absolu du répertoire QE ``outdir`` (relatif au run si besoin)."""
    s = (outdir or "").strip().strip("'\"")
    if not s or s == ".":
        return work_dir.resolve()
    p = Path(s)
    if p.is_absolute():
        return p.resolve()
    return (work_dir / p).resolve()


def has_scf_save_for_prefix(work_dir: Path, prefix: str, outdir: str) -> bool:
    """Vrai si les données d’une étape SCF précédente (répertoire ``prefix.save``) sont présentes."""
    if not prefix.strip():
        return False
    od = _resolve_qe_outdir_on_disk(work_dir, outdir)
    save_p = od / f"{prefix}.save"
    if save_p.is_dir() or save_p.is_file():
        return True
    alt = work_dir / f"{prefix}.save"
    return alt.is_dir() or alt.is_file()


def collect_pw_charge_input_candidates(work_dir: Path) -> list[str]:
    """
    Fichiers d’entrée pw probables (chemins relatifs au run, sans ``..``).
    Ordre : V₀ phonon, équilibre, pw.in, volumes EOS à la racine puis sous ``1_eos_volumes/``.
    """
    work_dir = wf1_eos_run_root(work_dir.resolve())
    names: list[str] = []
    seen: set[str] = set()

    def add_rel(rel: Path) -> None:
        try:
            if rel.is_absolute():
                return
            key = rel.as_posix().replace("\\", "/")
            if ".." in key or key.startswith("/"):
                return
            rp = (work_dir / rel).resolve()
            rp.relative_to(work_dir)
            if not rp.is_file():
                return
        except (OSError, ValueError):
            return
        if key not in seen:
            names.append(key)
            seen.add(key)

    for base in (
        "pw_scf_V0_for_phonon.in",
        "scf_eq.in",
        "pw.in",
    ):
        add_rel(Path(base))
    for pat in ("pw_scf_vol_*.in", "scf_vol_*.in"):
        for p in sorted(work_dir.glob(pat)):
            add_rel(p.relative_to(work_dir))
    sub = work_dir / EOS_VOLUMES_SUBDIR
    if sub.is_dir():
        for pat in ("pw_scf_vol_*.in", "scf_vol_*.in"):
            for p in sorted(sub.glob(pat)):
                add_rel(p.relative_to(work_dir))
    return names


def resolve_pw_in_basename_for_pp(
    work_dir: Path,
    explicit_basename: str | None,
    *,
    require_existing_save: bool,
) -> str:
    """
    Choisit le fichier ``.in`` dont ``pp.x`` lira ``prefix`` / ``outdir``.

    Si ``explicit_basename`` est fourni, il doit exister (chemin relatif au run, ex.
    ``1_eos_volumes/scf_vol_12.in``). Sinon on parcourt ``collect_pw_charge_input_candidates``
    et l’on favorise un couple prefix/outdir pour lequel ``prefix.save`` est présent.
    """
    work_dir = wf1_eos_run_root(work_dir.resolve())

    if explicit_basename:
        rel = Path(explicit_basename.strip())
        if ".." in str(rel) or rel.is_absolute():
            raise ValueError("pw_in_basename : chemin invalide (pas de .. ni de chemin absolu).")
        pw_path = (work_dir / rel).resolve()
        try:
            pw_path.relative_to(work_dir)
        except ValueError:
            raise ValueError("pw_in_basename doit rester sous le dossier du run.") from None
        if not pw_path.is_file():
            raise FileNotFoundError(
                f"{rel.as_posix()} introuvable dans {work_dir} — utilisez l’entrée pw du SCF terminé "
                "(même prefix / outdir que la sauvegarde « .save »)."
            )
        text = pw_path.read_text(encoding="utf-8", errors="replace")
        prefix, od = parse_prefix_outdir_from_pw_text(text)
        if not prefix or not od:
            raise ValueError(
                f"Lignes prefix=/outdir= illisibles dans {rel.as_posix()} — éditez le fichier ou choisissez un autre .in."
            )
        if require_existing_save and not has_scf_save_for_prefix(work_dir, prefix, od):
            raise ValueError(
                f"Aucune sauvegarde SCF trouvée pour prefix={prefix!r} / outdir={od!r} "
                f"({prefix}.save attendu — lancez d’abord pw.x avec JOB DONE pour ce préfixe, ou corrigez outdir)."
            )
        return rel.as_posix()

    candidates = collect_pw_charge_input_candidates(work_dir)
    if not candidates:
        raise FileNotFoundError(
            f"Aucun .in pw candidat dans {work_dir} (attendu ex. pw_scf_V0_for_phonon.in, scf_eq.in, …)."
        )

    best_score = -1
    best_i = 10**9
    chosen = ""
    fallback_parse: str | None = None
    for i, rel in enumerate(candidates):
        pw_path = work_dir / rel
        text = pw_path.read_text(encoding="utf-8", errors="replace")
        prefix, od = parse_prefix_outdir_from_pw_text(text)
        if not prefix or not od:
            continue
        if fallback_parse is None:
            fallback_parse = rel
        score = 3 if has_scf_save_for_prefix(work_dir, prefix, od) else 1
        if score > best_score or (score == best_score and i < best_i):
            best_score = score
            best_i = i
            chosen = rel

    if not chosen:
        raise ValueError(
            "Aucun fichier .in ne contient de lignes prefix= / outdir= lisibles — vérifiez vos entrées pw."
        )
    if require_existing_save and best_score < 3:
        if fallback_parse:
            raise ValueError(
                f"Aucun couple prefix/outdir ne pointe vers des données .save sur disque. "
                f"Premier fichier parseable : {fallback_parse} — lancez pw.x (SCF) jusqu’à JOB DONE pour ce run."
            )
    return chosen


def write_pp_charge_input(
    work_dir: Path,
    *,
    prefix: str,
    outdir: str,
    filplot: str = _DEFAULT_FILPLOT,
    plot_num: int = 0,
    output_format: int = 5,
    fileout: str = "charge_density.xsf",
) -> Path:
    """Écrit ``pp_charge.in`` dans le run ; ``filplot`` doit coïncider avec ``filepp(1)``."""
    work_dir = wf1_eos_run_root(work_dir.resolve())
    fp = filplot.strip() or _DEFAULT_FILPLOT
    body = (
        "! Généré par thermo_pw — pp.x : INPUTPP + PLOT (nfile / filepp / weight)\n"
        "! Doc. QE : INPUTPP, PLOT ; ajuster plot_num, maille d’échantillonnage si besoin.\n"
        "&INPUTPP\n"
        f"  prefix = '{prefix}',\n"
        f"  outdir = '{outdir}',\n"
        f"  filplot = '{fp}',\n"
        f"  plot_num = {int(plot_num)},\n"
        "/\n"
        "&PLOT\n"
        "  nfile = 1,\n"
        f"  filepp(1) = '{fp}',\n"
        "  weight(1) = 1.0,\n"
        "  iflag = 3,\n"
        f"  output_format = {int(output_format)},\n"
        f"  fileout = '{fileout}',\n"
        "/\n"
    )
    path = work_dir / "pp_charge.in"
    path.write_text(body, encoding="utf-8")
    return path


def write_pp_charge_input_plot_only(
    work_dir: Path,
    *,
    filepp_1: str,
    output_format: int = 5,
    fileout: str = "charge_density.xsf",
) -> Path:
    """
    Entrée ``pp.x`` réduite à ``&PLOT`` : relit une grille déjà produite (``filepp(1)``),
    chemins **relatifs au dossier du run** (ex. ``tmp/charge-density`` pour ``tmp/charge-density.dat``).
    """
    work_dir = wf1_eos_run_root(work_dir.resolve())
    fp = filepp_1.strip().replace("\\", "/")
    if not fp or ".." in fp:
        raise ValueError("filepp (grille existante) invalide.")
    body = (
        "! thermo_pw — pp.x : section PLOT seule (grille déjà sur disque, voir filepp)\n"
        "! Le chemin est relatif au répertoire où s’exécute pp.x (dossier du run).\n"
        "&PLOT\n"
        "  nfile = 1,\n"
        f"  filepp(1) = '{fp}',\n"
        "  weight(1) = 1.0,\n"
        "  iflag = 3,\n"
        f"  output_format = {int(output_format)},\n"
        f"  fileout = '{fileout}',\n"
        "/\n"
    )
    path = work_dir / "pp_charge_reuse.in"
    path.write_text(body, encoding="utf-8")
    return path


def _rank_charge_dat_candidate(p: Path, work_dir: Path, od_resolved: Path) -> tuple[int, ...]:
    """Score minimal = meilleur (outdir QE, puis dossier *.save, puis nom fichier)."""
    rel = p.relative_to(work_dir)
    try:
        p.resolve().relative_to(od_resolved.resolve())
        under_outdir = True
    except ValueError:
        under_outdir = False
    # Fichiers de densité sont souvent sous …/tmp/<prefix>.save/ (QE)
    inside_save_folder = any(
        isinstance(seg, str) and seg.endswith(".save") for seg in p.parts
    )
    name = p.name.lower()
    if "charge" in name and "density" in name:
        nm = 0
    elif "chgden" in name:
        nm = 1
    else:
        nm = 2
    pref_od = 0 if under_outdir else 1
    pref_save = 0 if inside_save_folder else 1
    return (pref_od, pref_save, nm, len(rel.parts), str(rel))


def discover_charge_dat_filplot_stem(work_dir: Path, outdir_qe: str) -> str | None:
    """
    Cherche un fichier type densité (ex. ``charge-density.dat``) sous le run, dans
    l’``outdir`` résolu, et **à l’intérieur des répertoires ``*.save``** de Quantum ESPRESSO
    (emplacement courant des grilles).

    Renvoie la base ``filepp`` **sans** extension ``.dat``, chemins relatifs au run.
    """
    wd = wf1_eos_run_root(work_dir.resolve())
    od_path = _resolve_qe_outdir_on_disk(wd, outdir_qe)
    candidates: list[Path] = []
    for nm in ("charge-density.dat", "charge_density.dat", "chgden.dat"):
        for base in (od_path, wd):
            p = base / nm
            if p.is_file():
                candidates.append(p)
    # Parcours complet y compris sous …/<prefix>.save/ (ne pas exclure .save)
    for pattern in (
        "**/charge-density.dat",
        "**/charge_density.dat",
        "**/*charge*density*.dat",
        "**/*.save/**/charge-density.dat",
        "**/*.save/**/charge_density.dat",
        "**/*.save/**/*chgden*.dat",
    ):
        for p in wd.glob(pattern):
            if not p.is_file() or p.suffix.lower() != ".dat":
                continue
            candidates.append(p)
    if not candidates:
        return None
    seen: set[str] = set()
    uniq: list[Path] = []
    for p in candidates:
        k = str(p.resolve())
        if k not in seen:
            seen.add(k)
            uniq.append(p)
    try:
        od_r = od_path.resolve()
    except OSError:
        od_r = od_path
    best = min(uniq, key=lambda p: _rank_charge_dat_candidate(p, wd, od_r))
    rel = best.relative_to(wd)
    stem = rel.as_posix()
    if stem.lower().endswith(".dat"):
        stem = stem[:-4]
    return stem


def _default_fileout_for_format(fmt: int) -> str:
    if int(fmt) == 6:
        return "charge_density.cube"
    return "charge_density.xsf"


def _infer_output_format_from_name(name: str) -> int | None:
    low = name.lower()
    if low.endswith(".cube"):
        return 6
    if low.endswith(".xsf"):
        return 5
    return None


def run_pp_charge_density(
    work_dir: Path,
    *,
    pw_in_basename: str = "pw_scf_V0_for_phonon.in",
    plot_num: int = 0,
    fileout: str | None = None,
    cube_name: str | None = None,
    output_format: int | None = None,
    filplot: str | None = None,
    reuse_charge_dat: bool = True,
    charge_dat_relpath: str | None = None,
) -> tuple[Path, Path]:
    """
    Lance ``pp.x`` pour exporter la densité (plot_num défaut 0).

    Si ``charge_dat_relpath`` pointe vers un ``.dat`` existant, ou si
    ``reuse_charge_dat`` est vrai et qu’un fichier type ``charge-density.dat`` est
    trouvé (souvent sous ``outdir`` / ``tmp/``), on génère **pp_charge_reuse.in**
    (section ``&PLOT`` seule) avec ``filepp(1)`` = chemin relatif **sans** ``.dat``,
    pour réexploiter la grille sans repasser par tout ``&INPUTPP``.

    Sinon, exécution classique **pp_charge.in** (``&INPUTPP`` + ``&PLOT``) à partir
    des sauvegardes SCF (``prefix.save``).

    ``cube_name`` est un alias historique de ``fileout`` (nom seul, sous le run).

    Retourne ``(journal pp_charge.out, chemin fichier sortie)``.
    """
    work_dir = wf1_eos_run_root(work_dir.resolve())
    pw = work_dir / Path(pw_in_basename)
    if not pw.is_file():
        raise FileNotFoundError(
            f"{pw_in_basename} introuvable dans {work_dir} — besoin d’un SCF pw.x terminé (même prefix/outdir)."
        )
    text = pw.read_text(encoding="utf-8", errors="replace")
    prefix, od = parse_prefix_outdir_from_pw_text(text)
    if not prefix or not od:
        raise ValueError(
            f"Impossible de lire prefix/outdir dans {pw_in_basename} — éditez pp_charge.in à la main."
        )

    out_name = (fileout or cube_name or "").strip()
    fmt = output_format
    if not out_name:
        resolved_fmt = int(fmt) if fmt is not None else 5
        out_name = _default_fileout_for_format(resolved_fmt)
        if fmt is None:
            fmt = resolved_fmt
    elif fmt is None:
        inferred = _infer_output_format_from_name(out_name)
        fmt = inferred if inferred is not None else 5

    fmt_i = max(0, min(int(fmt), 99))

    exe = cfg.pp_path()
    if not exe.is_file():
        raise FileNotFoundError(f"pp.x introuvable : {exe}")

    log = work_dir / "pp_charge.out"
    fp_user = (filplot or "").strip() or None
    raw_cd = (charge_dat_relpath or "").strip() or None

    plot_only = False
    filepp_stem: str | None = None
    inp: Path

    if raw_cd:
        rel = Path(raw_cd.replace("\\", "/"))
        if ".." in str(rel) or rel.is_absolute():
            raise ValueError("charge_dat_relpath : chemin relatif au run, sans ..")
        dat_path = (work_dir / rel).resolve()
        try:
            dat_path.relative_to(work_dir.resolve())
        except ValueError:
            raise ValueError("charge_dat_relpath doit rester sous le dossier du run.") from None
        if not dat_path.is_file():
            raise FileNotFoundError(f"Fichier introuvable : {raw_cd}")
        if dat_path.suffix.lower() != ".dat":
            raise ValueError("charge_dat_relpath doit être un fichier .dat")
        rs = rel.as_posix()
        filepp_stem = rs[:-4] if rs.lower().endswith(".dat") else rs
        plot_only = True
    elif fp_user:
        filepp_stem = fp_user
        plot_only = False
    elif reuse_charge_dat:
        found = discover_charge_dat_filplot_stem(work_dir, od)
        if found:
            filepp_stem = found
            plot_only = True
        else:
            filepp_stem = _DEFAULT_FILPLOT
            plot_only = False
    else:
        filepp_stem = _DEFAULT_FILPLOT
        plot_only = False

    if plot_only:
        assert filepp_stem is not None
        inp = write_pp_charge_input_plot_only(
            work_dir,
            filepp_1=filepp_stem,
            output_format=fmt_i,
            fileout=out_name,
        )
        run_qe([str(exe), "-in", inp.name], work_dir=work_dir, log_file=log)
    else:
        fp = filepp_stem or _DEFAULT_FILPLOT
        inp = write_pp_charge_input(
            work_dir,
            prefix=prefix,
            outdir=od,
            filplot=fp,
            plot_num=plot_num,
            output_format=fmt_i,
            fileout=out_name,
        )
        run_qe([str(exe), "-in", inp.name], work_dir=work_dir, log_file=log)

    output_path = work_dir / out_name
    if not output_path.is_file():
        raise RuntimeError(f"Fichier de sortie absent après pp.x ({out_name}) — voir {log}")
    return log, output_path, inp.name

"""Détection de la machine de calcul — base du modèle d'estimation de durée.

Pourquoi ce module (août 2026)
------------------------------
Estimer une durée de calcul QE sans connaître la machine n'a pas de sens : le
même P2 sur Si passe de quelques heures sur une station 16 cœurs à ~20 h sur un
ultraportable 2 cœurs. Le backend ne faisait AUCUNE détection matérielle avant
ce module ; les seuls appels existants étaient ``mp.cpu_count()`` dans les pools
EOS/élastique, qui compte les cœurs **logiques**.

Cette distinction est le piège central. Un i7-7500U annonce ``nproc=4`` alors
qu'il n'a que 2 cœurs physiques (2 threads SMT chacun). Lancer ``pw.x -np 4``
dessus met 4 rangs MPI sur 2 cœurs : chaque rang ralentit, et l'hyperthreading
n'apporte quasiment rien en calcul flottant dense. On expose donc les deux
comptes séparément et on avertit dès que ``nproc`` dépasse les cœurs physiques.

``psutil`` n'étant pas une dépendance du projet (cf. requirements.txt), tout est
lu via la bibliothèque standard et ``/proc``.
"""
from __future__ import annotations

import math
import os
import platform
import re
import subprocess
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Référence de calibration
# ---------------------------------------------------------------------------
# Machine de référence : Intel Core i7-7500U (2 cœurs physiques / 4 threads,
# 11 Gio RAM), sur laquelle les constantes de coût de ``runtime_estimate`` ont
# été mesurées. ``speed_index = 1.0`` par définition sur cette machine.
#
# La vitesse par cœur est déduite de la fréquence **nominale**, pas d'un
# micro-benchmark. Un benchmark de ufuncs NumPy a bien été implémenté puis
# retiré : mesuré sur cette machine de référence, il variait de 78 % d'une
# passe à l'autre (CPU mobile 15 W dont la fréquence oscille entre base et
# turbo selon l'état thermique, plus le bruit de la pagination). Filtrer les
# passes trop dispersées ne suffisait pas : selon que le filtre passait ou non,
# la même machine recevait un indice de 1.0 ou de 0.9, et toutes les durées
# affichées bougeaient de 10 % sans que l'utilisateur puisse comprendre
# pourquoi. Une estimation reproductible vaut mieux qu'une estimation
# fortuitement plus fine.
#
# La fréquence nominale est grossière — elle ignore l'IPC, très différent d'une
# génération à l'autre — mais elle est stable. La correction fine vient de
# ``runtime_estimate``, qui enregistre les durées réelles des étapes QE : un
# vrai pw.x est un bien meilleur étalon qu'un benchmark synthétique, et il
# capture en prime le throttling et la pagination.
REF_CPU_MODEL = "Intel(R) Core(TM) i7-7500U"
REF_BASE_GHZ = 2.70

# Paramètres du modèle parallèle, ajustés sur deux runs P2/Si complets de la
# machine de référence (nproc=2 puis nproc=4). Le modèle reproduit à 3 % près la
# durée du SCF et celle de la grille EOS dans les deux configurations.
_SERIAL_FRACTION = 0.10   # part non parallélisable d'un job MPI (Amdahl)
_SMT_WEIGHT = 0.3         # contribution d'un thread SMT vs un cœur physique
_OVERSUB_THRESHOLD = 1.5  # × threads logiques, seuil d'effondrement observé
_OVERSUB_EXPONENT = 2.5


@dataclass
class MachineProfile:
    """Capacités matérielles utiles au calcul QE."""

    cpu_model: str = "inconnu"
    cores_physical: int = 1
    cores_logical: int = 1
    cores_available: int = 1  # affinité effective du processus
    smt_ratio: float = 1.0
    ram_total_mb: int = 0
    ram_available_mb: int = 0
    swap_total_mb: int = 0
    swap_used_mb: int = 0
    speed_index: float = 1.0
    speed_index_source: str = "default"
    platform: str = ""
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    # -- Capacité de calcul ------------------------------------------------
    def recommended_nproc(self) -> int:
        """Rangs MPI conseillés : un par cœur **physique**.

        Le modèle prédit un gain marginal en poussant jusqu'aux threads SMT, et
        une mesure isolée le confirme (un SCF de Si : 62 s à nproc=4 contre 79 s
        à nproc=2). Mais sur la même machine, le run complet à nproc=4 a duré
        cinq fois plus longtemps qu'à nproc=2, la dégradation frappant les
        étapes gourmandes en mémoire (DFPT) et la grille EOS qui multiplie les
        processus concurrents. Le gain de quelques pourcents ne vaut pas ce
        risque : on conseille les cœurs physiques et ``warnings_for`` explique
        le compromis au lieu de le masquer.
        """
        return max(1, self.cores_physical)

    def effective_ranks(self, ranks: int) -> float:
        """Rangs « utiles » : les threads SMT comptent pour une fraction.

        Un thread SMT ne double pas la puissance d'un cœur — ``pw.x`` sature
        déjà les unités vectorielles. Le poids de 0.3 reproduit la mesure du SCF
        de Si (62 s à 4 rangs contre 79 s à 2 rangs sur 2 cœurs physiques).
        """
        ranks = max(1, int(ranks))
        phys = max(1, self.cores_physical)
        smt = max(0, min(ranks, self.cores_logical) - phys)
        return min(ranks, phys) + _SMT_WEIGHT * smt

    def _collapse_factor(self, ranks: int) -> float:
        """Effondrement en sur-souscription franche.

        Observé sur la machine de référence : 6 processus sur 4 threads gardent
        un débit normal, 12 processus s'effondrent d'un facteur ~6. La
        littérature l'explique par l'attente active (busy-wait) des
        implémentations MPI : un rang qui attend dans une collective consomme
        du CPU au lieu de le céder.

        Le seuil et l'exposant sont ajustés sur cette **unique** observation :
        à prendre comme un signal fort de « ne faites pas ça », pas comme une
        prédiction fine.
        """
        limit = _OVERSUB_THRESHOLD * max(1, self.cores_logical)
        if ranks <= limit:
            return 1.0
        return (limit / ranks) ** _OVERSUB_EXPONENT

    def parallel_speedup(self, nproc: int) -> float:
        """Accélération d'un job MPI **unique** (ph.x, pw.x, thermo_pw.x).

        Loi d'Amdahl sur les rangs utiles : la part non parallélisable (I/O,
        initialisation, FFT séries) plafonne le gain.
        """
        eff = self.effective_ranks(nproc)
        speedup = 1.0 / (_SERIAL_FRACTION + (1.0 - _SERIAL_FRACTION) / eff)
        return max(0.05, speedup * self._collapse_factor(max(1, int(nproc))))

    def concurrent_speedup(self, total_ranks: int) -> float:
        """Débit agrégé de plusieurs jobs **indépendants** (grille EOS).

        Sans synchronisation entre eux, des processus indépendants exploitent
        la machine mieux qu'un seul job MPI : pas de perte d'Amdahl. C'est
        vérifié sur la grille EOS de référence, dont le débit agrégé (2.6)
        dépasse celui d'un pw.x unique aux mêmes rangs (1.8).
        """
        eff = self.effective_ranks(total_ranks)
        return max(0.05, eff * self._collapse_factor(max(1, int(total_ranks))))

    def throughput(self, nproc: int, *, concurrent_ranks: Optional[int] = None) -> float:
        """Débit de calcul. ``concurrent_ranks`` → régime « jobs indépendants »."""
        if concurrent_ranks is not None:
            return max(1e-6, self.speed_index * self.concurrent_speedup(concurrent_ranks))
        return max(1e-6, self.speed_index * self.parallel_speedup(nproc))

    # -- Diagnostics -------------------------------------------------------
    def warnings_for(self, nproc: int, *, ram_needed_mb: int = 0) -> list[str]:
        """Avertissements actionnables pour un lancement à ``nproc`` rangs."""
        out: list[str] = []
        nproc = max(1, int(nproc))
        if nproc > _OVERSUB_THRESHOLD * self.cores_logical:
            out.append(
                f"nproc={nproc} dépasse largement les {self.cores_logical} threads "
                f"disponibles : les rangs MPI s'attendent mutuellement en "
                f"consommant du CPU. Effondrement mesuré d'un facteur ~6 dans "
                f"cette situation. Utilisez nproc={self.recommended_nproc()}."
            )
        elif nproc > self.cores_physical:
            out.append(
                f"nproc={nproc} utilise des threads SMT au-delà des "
                f"{self.cores_physical} cœurs physiques. Le gain est faible sur "
                f"un calcul isolé, mais un run QHA (P2–P4) complet a été mesuré cinq fois "
                f"plus lent dans cette configuration (étapes DFPT et grille EOS, "
                f"gourmandes en mémoire). nproc={self.recommended_nproc()} est "
                f"le réglage sûr."
            )
        if self.swap_total_mb > 0 and self.swap_used_mb > 0.5 * self.swap_total_mb:
            out.append(
                f"Swap déjà utilisé à {100 * self.swap_used_mb / self.swap_total_mb:.0f} % "
                f"({self.swap_used_mb} Mio) : la machine pagine, les durées "
                f"peuvent doubler. Fermez les applications lourdes "
                f"(navigateur, IDE) avant de lancer."
            )
        if ram_needed_mb and self.ram_available_mb and ram_needed_mb > self.ram_available_mb:
            out.append(
                f"Besoin mémoire estimé {ram_needed_mb} Mio > {self.ram_available_mb} Mio "
                f"disponibles : risque d'arrêt du calcul par le noyau (OOM). "
                f"Réduisez nproc ou la grille k."
            )
        return out


# ---------------------------------------------------------------------------
# Lecture du matériel
# ---------------------------------------------------------------------------
def _read_proc_cpuinfo() -> tuple[Optional[str], Optional[int], Optional[int]]:
    """(modèle, cœurs physiques, processeurs logiques) depuis /proc/cpuinfo.

    Les cœurs physiques se comptent en dédoublonnant les couples
    (``physical id``, ``core id``) : c'est ce qui distingue un vrai cœur d'un
    frère SMT, information que ``os.cpu_count()`` ne donne pas.
    """
    try:
        text = Path("/proc/cpuinfo").read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None, None, None

    model: Optional[str] = None
    logical = 0
    seen: set[tuple[str, str]] = set()
    phys_id = core_id = None
    for line in text.splitlines():
        if ":" not in line:
            if phys_id is not None and core_id is not None:
                seen.add((phys_id, core_id))
            phys_id = core_id = None
            continue
        key, _, val = line.partition(":")
        key, val = key.strip().lower(), val.strip()
        if key == "processor":
            logical += 1
        elif key == "model name" and model is None:
            model = val
        elif key == "physical id":
            phys_id = val
        elif key == "core id":
            core_id = val
    if phys_id is not None and core_id is not None:
        seen.add((phys_id, core_id))

    physical = len(seen) if seen else None
    return model, physical, (logical or None)


def _read_lscpu_physical() -> Optional[int]:
    """Repli ``lscpu -p=core`` quand /proc/cpuinfo n'expose pas les core id."""
    try:
        res = subprocess.run(
            ["lscpu", "-p=core"],
            capture_output=True, text=True, timeout=5, check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if res.returncode != 0:
        return None
    cores = {
        line.strip()
        for line in res.stdout.splitlines()
        if line.strip() and not line.startswith("#")
    }
    return len(cores) or None


def _read_meminfo() -> tuple[int, int, int, int]:
    """(RAM totale, RAM disponible, swap total, swap utilisé) en Mio."""
    try:
        text = Path("/proc/meminfo").read_text(encoding="utf-8", errors="replace")
    except OSError:
        return 0, 0, 0, 0
    vals: dict[str, int] = {}
    for line in text.splitlines():
        m = re.match(r"^(\w+):\s+(\d+)\s*kB", line)
        if m:
            vals[m.group(1)] = int(m.group(2))
    total = vals.get("MemTotal", 0) // 1024
    avail = vals.get("MemAvailable", vals.get("MemFree", 0)) // 1024
    sw_total = vals.get("SwapTotal", 0) // 1024
    sw_free = vals.get("SwapFree", 0) // 1024
    return total, avail, sw_total, max(0, sw_total - sw_free)


def _cores_available() -> int:
    """Cœurs réellement utilisables par ce processus (cgroups, taskset…)."""
    try:
        return max(1, len(os.sched_getaffinity(0)))
    except (AttributeError, OSError):
        return max(1, os.cpu_count() or 1)


def _nominal_base_ghz(model: str) -> Optional[float]:
    """Fréquence nominale : suffixe « @ 2.70GHz » du modèle, sinon /sys.

    On préfère la chaîne du modèle à ``cpu MHz`` de /proc/cpuinfo : cette
    dernière donne la fréquence **instantanée**, qui vaut 800 MHz au repos et
    fausserait complètement l'indice.
    """
    m = re.search(r"@\s*([\d.]+)\s*GHz", model or "", re.IGNORECASE)
    if m:
        try:
            v = float(m.group(1))
            if 0.3 <= v <= 7.0:
                return v
        except ValueError:
            pass
    try:
        khz = int(
            Path("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq")
            .read_text(encoding="utf-8").strip()
        )
        ghz = khz / 1_000_000.0
        if 0.3 <= ghz <= 7.0:
            # C'est la fréquence turbo maximale : on la ramène vers une base
            # plausible, le turbo n'étant pas tenable sur tous les cœurs.
            return ghz * 0.8
    except (OSError, ValueError):
        pass
    return None


# ---------------------------------------------------------------------------
# API publique
# ---------------------------------------------------------------------------
def detect_machine() -> MachineProfile:
    """Profil matériel courant (lecture seule, sans mesure — déterministe)."""
    model, physical, logical = _read_proc_cpuinfo()
    if not physical:
        physical = _read_lscpu_physical()
    logical = logical or os.cpu_count() or 1
    if not physical:
        # Aucune info SMT : on reste prudent et on suppose l'absence de SMT
        # plutôt que d'inventer une division par 2 qui sous-estimerait une
        # machine sans hyperthreading.
        physical = logical
    physical = max(1, min(physical, logical))

    total, avail, sw_total, sw_used = _read_meminfo()
    prof = MachineProfile(
        cpu_model=model or platform.processor() or "inconnu",
        cores_physical=physical,
        cores_logical=logical,
        cores_available=_cores_available(),
        smt_ratio=(logical / physical) if physical else 1.0,
        ram_total_mb=total,
        ram_available_mb=avail,
        swap_total_mb=sw_total,
        swap_used_mb=sw_used,
        platform=f"{platform.system()} {platform.release()}",
    )

    base_ghz = _nominal_base_ghz(prof.cpu_model)
    prof.speed_index = (base_ghz / REF_BASE_GHZ) if base_ghz else 1.0
    prof.speed_index_source = (
        f"nominal ({base_ghz:.2f} GHz)" if base_ghz else "défaut (fréquence inconnue)"
    )

    if prof.smt_ratio > 1.05:
        prof.notes.append(
            f"{physical} cœurs physiques pour {logical} threads logiques "
            f"(SMT/hyperthreading actif)."
        )
    if prof.cores_available < logical:
        prof.notes.append(
            f"Affinité restreinte : {prof.cores_available} threads utilisables "
            f"sur {logical}."
        )
    return prof

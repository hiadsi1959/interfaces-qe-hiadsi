"""
Persistance du dernier job lancé via l’API dans chaque dossier de run (thermo_api_job_state.json).

Permet après une coupure de courant ou un redémarrage de distinguer « terminé » / « interrompu »
et d’aligner workflow_state.json (tâche EOS en « running » figée → « interrupted »).
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Optional

import config as cfg
from state_db import TaskState, TaskStatus, WorkflowDB
from eos_paths import WORKFLOW_STATE_FILENAME

MARKER_NAME = "thermo_api_job_state.json"
SCHEMA_VERSION = 1

_SKIP_KEYS = frozenset({"cancel_event"})


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _work_dir_under_root(work_dir: Path) -> bool:
    try:
        work_dir.resolve().relative_to(cfg.WORK_ROOT.resolve())
    except ValueError:
        return False
    return True


def workflow_touch_for_record(rec: dict[str, Any]) -> list[str]:
    if rec.get("fit_only"):
        return ["eos"]
    mode = rec.get("mode")
    if mode in ("full", "volumes_only", "scf_only", "scf_and_fit"):
        return ["eos"]
    return []


def write_job_marker(job_id: str, rec: dict[str, Any]) -> None:
    wd_raw = rec.get("work_dir")
    if not wd_raw:
        return
    try:
        work_dir = Path(str(wd_raw)).expanduser().resolve()
    except OSError:
        return
    if not _work_dir_under_root(work_dir):
        return
    touch = workflow_touch_for_record(rec)
    payload: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "job_id": job_id,
        "api_pid": os.getpid(),
        "updated_at": time.time(),
        "workflow_touch": touch,
    }
    for k, v in rec.items():
        if k in _SKIP_KEYS:
            continue
        try:
            json.dumps(v)
        except (TypeError, ValueError):
            continue
        payload[k] = v
    path = work_dir / MARKER_NAME
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        try:
            os.chmod(path, 0o644)
        except OSError:
            pass
    except OSError:
        pass


def read_job_marker(work_dir: Path) -> Optional[dict[str, Any]]:
    p = Path(work_dir) / MARKER_NAME
    if not p.is_file():
        return None
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def _apply_interrupted_tasks(
    work_dir: Path, task_names: list[str], message: str
) -> None:
    if not task_names:
        return
    st_path = work_dir / WORKFLOW_STATE_FILENAME
    if not st_path.is_file():
        return
    try:
        db = WorkflowDB.load(st_path)
    except (OSError, ValueError, json.JSONDecodeError, TypeError):
        return
    changed = False
    for name in task_names:
        st = db.get_task(name)
        if st.status != TaskStatus.RUNNING.value:
            continue
        db.set_task(
            name,
            TaskState(
                status=TaskStatus.INTERRUPTED.value,
                message=message,
                started_at=st.started_at,
                finished_at=time.time(),
                data=st.data if isinstance(st.data, dict) else {},
            ),
        )
        changed = True
    if changed:
        try:
            db.save(st_path)
        except OSError:
            pass


def recover_stale_api_job_markers(work_root: Path) -> int:
    """
    Au démarrage du serveur : les marqueurs encore « queued » / « running » dont le pid API
    n’existe plus sont marqués « interrupted » et les tâches workflow correspondantes sont mises à jour.
    """
    try:
        root = work_root.resolve()
    except OSError:
        return 0
    if not root.is_dir():
        return 0
    count = 0
    msg = (
        "Interrompu (coupure, arrêt machine ou redémarrage de l’API avant fin du job). "
        "Relancez l’étape depuis l’interface."
    )
    try:
        paths = list(root.rglob(MARKER_NAME))
    except OSError:
        return 0
    for path in paths:
        work_dir = path.parent
        if not _work_dir_under_root(work_dir):
            continue
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        st = str(raw.get("status") or "").lower()
        if st not in ("queued", "running"):
            continue
        pid = int(raw.get("api_pid") or 0)
        if _pid_alive(pid):
            continue
        touch = raw.get("workflow_touch")
        if not isinstance(touch, list):
            touch = workflow_touch_for_record(raw)
        task_names = [str(x) for x in touch if x]
        _apply_interrupted_tasks(work_dir, task_names, msg)
        raw["status"] = "interrupted"
        raw["message"] = msg
        raw["finished_at"] = time.time()
        raw["updated_at"] = time.time()
        raw["interrupt_reason"] = "api_or_system_restart"
        try:
            path.write_text(
                json.dumps(raw, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except OSError:
            continue
        count += 1
    return count

#!/usr/bin/env python3
"""
Point d'entrée CLI (à lancer depuis le répertoire backend/) :

  cd /chemin/vers/thermo_pw/backend
  python3 run_workflow.py --material demo --work ../work/runs_demo --template /chemin/scf.in

Exige des fichiers d'entrée pw/ph réels; ce script orchestre seulement la chaîne.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

# racine = dossier de ce fichier
_ROOT = Path(__file__).resolve().parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from orchestrator import PipelinePaths, run_pipeline


def main() -> int:
    p = argparse.ArgumentParser(description="Orchestrateur THERMO_PW (EOS / phonon / thermo)")
    p.add_argument("--material", required=True, help="identifiant matériau (nom de run)")
    p.add_argument("--work", type=Path, required=True, help="répertoire de travail")
    p.add_argument("--template", type=Path, required=True, help="fichier pw modèle (pour EOS)")
    p.add_argument("--in-ph", type=Path, help="ph.in")
    p.add_argument("--in-q2r", type=Path, help="q2r.in")
    p.add_argument("--in-matdyn", type=Path, help="matdyn.in")
    p.add_argument("--fildyn", default="dyn", help="racine fildyn pour thermo")
    p.add_argument("--no-phonon", action="store_true")
    p.add_argument("--no-thermo", action="store_true")
    p.add_argument("--elastic", action="store_true", help="lancer tâche élasticité (squelette)")
    args = p.parse_args()

    pp = PipelinePaths(
        template_pw=args.template,
        fildyn=args.fildyn,
    )
    if not args.no_phonon and args.in_ph and args.in_q2r and args.in_matdyn:
        pp.in_ph, pp.in_q2r, pp.in_matdyn = args.in_ph, args.in_q2r, args.in_matdyn
    elif not args.no_phonon:
        print(
            "Avertissement: --in-ph, --in-q2r, --in-matdyn manquants — phonon ignoré",
            file=sys.stderr,
        )
        args.no_phonon = True

    r = run_pipeline(
        args.work,
        args.material,
        pp,
        do_phonon=not args.no_phonon,
        do_thermo=not args.no_thermo,
        do_elastic=args.elastic,
    )
    print(r)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

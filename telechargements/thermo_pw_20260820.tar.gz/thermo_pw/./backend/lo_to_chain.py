"""
``backend/lo_to_chain.py`` — LO/TO production option pour le profil P1.

Quand ``PipelineJob.lo_to_opt_in=True`` est passé en constructeur sur le profil
P1 (« Mécanique 0 K »), ce module :

1. ``check_pseudos_from_pw_input(scf.in)`` — refuse US-PP/PAW ; n'inspecte
   que les pseudos listés dans ``ATOMIC_SPECIES`` (pas tout ``pseudo_dir``).
   Reconnaît ONCV, HGH, ``Pseudopotential type: NC``, ``pseudo_type="NC"``.
2. ``write_born_file(dielectric_data, path)`` — écrit le fichier ``BORN``
   que ``matdyn.x`` consomme pour la correction non-analytique
   (``non_analytic=.true.`` + ``BORN_INPUT_FILE='BORN'``).
3. ``extend_matdyn_in_for_non_analytic(text)`` — injecte idempotemment
   ``non_analytic=.true.`` + ``BORN_INPUT_FILE='BORN'`` dans un input
   ``matdyn.in`` existant. Ne touche PAS aux autres paramètres (grille q,
   ``flfrc``, ``asr``) — la convention projet veut ``asr='simple'`` par
   défaut.
4. ``parse_lo_to_splitting_at_gamma(phonon_freq_path, born_data)`` — extrait
   les fréquences LO et TO au point Γ depuis les bandes phononiques avec
   correction non-analytique, et calcule le splitting par mode optique.

Ne pas confondre ce module avec ``parsers/dielectric.py`` qui PARSE les
sorties thermo_pw (``what='dielectric'``) ; ici on (a) consomme la sortie
parsée, et (b) on la traduit en format BORN consumable par matdyn.

Note : ce module ne lance AUCUN calcul QE lui-même — il s'appuie sur le
reste de la chaîne ``PipelineJob`` (SCF → sub-run dielectric → matdyn
re-run). Sa valeur ajoutée est :

  * detection binaire NC vs US-PP depuis les UPF (upstream fail-fast).
  * serializer BORN portable + idempotent.
  * injection idempotente dans matdyn.in (sûr même si l'utilisateur a
    déjà écrit son propre matdyn.in à la main).

L'orchestration complète (la chaîne « sub-run léger » qui produit
``fc.out`` + ``BORN`` à partir du SCF d'équilibre) est dans
``pipeline.PipelineJob._run_lo_to_correction`` ; ce module ne fait que
préparer/valider les fichiers d'entrée et parser une partie des sorties.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Optional, Sequence

import config as cfg


# ============================================================================
# Constants
# ============================================================================

# Seuils pour la détection UPF : pseudos formatés en UPF v2 contiennent
# `pseudotype="NC"|"US"|"PAW"` dans leur header (avant la balise
# `<PP_INFO>`). En backup, la présence de `<PP_NONLOCAL>` Kleinman-Bylander
# (US-PP), de `<PP_AUGMENTATION>` (US/PAW) ou de `<PP_PAW>` (PAW) indique
# un pseudo non-NC — on refuse dans tous ces cas.
NC_HEADER_RX = re.compile(
    r"""\bpseudotype\s*=\s*['\"]?(\s*1\s*|NC)\s*['\"]?""",
    re.IGNORECASE,
)
US_HEADER_RX = re.compile(
    r"""\bpseudotype\s*=\s*['\"]?(\s*2\s*|3\s*|US|USP|PAW|USPP)\s*['\"]?""",
    re.IGNORECASE,
)
NC_TEXT_RX = re.compile(
    r"""(?i)Pseudopotential\s+type\s*:\s*NC\b""",
)
USPP_TEXT_RX = re.compile(
    r"""(?i)Pseudopotential\s+type\s*:\s*USPP\b""",
)
PAW_TEXT_RX = re.compile(
    r"""(?i)Pseudopotential\s+type\s*:\s*PAW\b""",
)
NC_PPTYPE_RX = re.compile(
    r"""(?i)pseudo_type\s*=\s*['\"]NC['\"]""",
)
PAW_PPTYPE_RX = re.compile(
    r"""(?i)pseudo_type\s*=\s*['\"]PAW['\"]""",
)
ONCV_RX = re.compile(r"""(?i)\bONCVPSP\b|\bONCV\b""",)
USPP_AUGMENT_RX = re.compile(r"<PP_AUGMENTATION\b", re.IGNORECASE)
USPP_NONLOCAL_RX = re.compile(r"<PP_NONLOCAL\b", re.IGNORECASE)
PAW_RX = re.compile(r"<PP_PAW\b", re.IGNORECASE)
UPF_TAG_RX = re.compile(r"<UPF\s+version\s*=", re.IGNORECASE)


# ============================================================================
# Pseudo detection — NC vs US-PP
# ============================================================================


def _classify_one_upf(path: Path) -> tuple[str, str]:
    """Classifie un seul pseudo UPF en ('NC' | 'US-PP' | 'PAW' | 'UNKNOWN', diagnostic).

    Stratégie (juillet 2026) — robuste face aux UPF émis par ld1.x, PSlibrary
    (upftools), ATOMPAW et les versions 1.x / 2.x :

      1. Cherche ``pseudotype="..."`` dans les ~200 premières lignes (header).
         NC si match NC, refuse si match US/PAW/USPP.
      2. Repli : présence de ``<PP_PAW>`` → PAW ; absence de NC explicite
         + présence de ``<PP_NONLOCAL>`` ou ``<PP_AUGMENTATION>`` → US-PP ;
         sinon retourne UNKNOWN avec mention du préfixe pour debug.
    """
    try:
        head = path.read_text(encoding="utf-8", errors="replace")[:16384]
    except OSError:
        return "UNKNOWN", f"lecture impossible: {path.name}"
    if NC_HEADER_RX.search(head):
        return "NC", f"{path.name} : pseudotype=NC (header)"
    if NC_TEXT_RX.search(head) or NC_PPTYPE_RX.search(head):
        return "NC", f"{path.name} : Pseudopotential type NC (texte/PP_HEADER)"
    if ONCV_RX.search(head) and not USPP_TEXT_RX.search(head):
        return "NC", f"{path.name} : ONCV norm-conserving (ONCVPSP)"
    if PAW_TEXT_RX.search(head) or PAW_PPTYPE_RX.search(head):
        return "PAW", f"{path.name} : Pseudopotential type PAW"
    if USPP_TEXT_RX.search(head):
        return "US-PP", f"{path.name} : Pseudopotential type USPP"
    if US_HEADER_RX.search(head):
        kind = US_HEADER_RX.search(head).group(1).upper().strip()  # type: ignore[union-attr]
        if kind in ("PAW", "3"):
            return "PAW", f"{path.name} : pseudotype=PAW (header)"
        return "US-PP", f"{path.name} : pseudotype={kind} (header)"
    # Backup : structural markers
    if PAW_RX.search(head):
        return "PAW", f"{path.name} : <PP_PAW> détecté (backup structural)"
    if USPP_NONLOCAL_RX.search(head) or USPP_AUGMENT_RX.search(head):
        return "US-PP", (
            f"{path.name} : <PP_NONLOCAL> ou <PP_AUGMENTATION> détecté "
            "(US-PP/PAW structural — header sans pseudotype explicite)"
        )
    if UPF_TAG_RX.search(head):
        return "UNKNOWN", (
            f"{path.name} : UPF sans marqueur NC/US-PP/PAW reconnu — "
            "vérifier le fichier source (ld1.x / upftools / ONCV)."
        )
    return "UNKNOWN", f"{path.name} : entête non-UPF (? format propriétaire)"


def extract_pseudo_paths_from_pw_input(pw_in: Path) -> list[Path]:
    """Chemins absolus des pseudos listés dans ``ATOMIC_SPECIES`` du pw.in."""
    pw_in = Path(pw_in).resolve()
    try:
        content = pw_in.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    pse_dir_raw = ""
    m = re.search(r"""(?im)^\s*pseudo_dir\s*=\s*['"]([^'"]+)['"]""", content)
    if m:
        pse_dir_raw = m.group(1).strip()
    if pse_dir_raw:
        pseudo_dir = Path(pse_dir_raw).expanduser()
        if not pseudo_dir.is_absolute():
            pseudo_dir = (pw_in.parent / pseudo_dir).resolve()
    else:
        pseudo_dir = Path(cfg.PSEUDOS_DIR).resolve()

    pse_files: set[str] = set()
    mo = re.search(
        r"(?ims)^\s*ATOMIC_SPECIES\s*(.*?)^(?=\s*$|\s*\w+\s*:|\s*&|\s*ATOMIC_POSITIONS|\s*CELL_PARAMETERS)",
        content,
    )
    if mo:
        for line in mo.group(1).splitlines():
            parts = line.split()
            if len(parts) >= 2:
                pse_files.add(parts[-1].strip())
    if not pse_files:
        return []
    paths: list[Path] = []
    for fn in sorted(pse_files):
        candidate = pseudo_dir / fn
        if candidate.is_file():
            paths.append(candidate.resolve())
            continue
        matches = sorted(pseudo_dir.rglob(fn))
        if matches:
            paths.append(matches[0].resolve())
    return paths


def check_pseudos_are_nc(
    pseudo_dir: Path,
    *,
    only_paths: Optional[Sequence[Path]] = None,
) -> tuple[bool, list[str]]:
    """Vérifie que les pseudos sont Norm-Conserving.

    Returns
    -------
    (ok, messages) : ``ok=True`` si tous les pseudos inspectés sont NC.
    ``messages`` liste les pseudos non-NC (ou UNKNOWN).

    Si ``only_paths`` est fourni, seuls ces fichiers sont classifiés (recommandé
    pour LO/TO : pseudos référencés dans ``scf.in``, pas tout le dossier).
    Sinon, tous les ``*.upf`` au niveau de ``pseudo_dir`` sont inspectés.
    """
    if only_paths:
        upfs = [Path(p).resolve() for p in only_paths if Path(p).is_file()]
        if not upfs:
            return False, ["aucun pseudo référencé trouvé sur disque"]
    else:
        if not pseudo_dir.is_dir():
            return False, [f"dossier pseudos introuvable : {pseudo_dir}"]
        upfs = sorted(
            p for p in pseudo_dir.iterdir()
            if p.is_file() and p.suffix.lower() in {".upf", ".upf2"}
        )
        if not upfs:
            return False, [f"aucun pseudo .upf dans {pseudo_dir}"]
    bad: list[str] = []
    for upf in upfs:
        kind, diag = _classify_one_upf(upf)
        if kind != "NC":
            bad.append(diag)
    return (not bad), bad


def check_pseudos_from_pw_input(pw_in: Path) -> tuple[bool, list[str]]:
    """NC check limité aux pseudos du fichier pw.in (``scf.in`` / phonon SCF)."""
    pw_in = Path(pw_in).resolve()
    paths = extract_pseudo_paths_from_pw_input(pw_in)
    if paths:
        return check_pseudos_are_nc(paths[0].parent, only_paths=paths)
    try:
        content = pw_in.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False, [f"lecture impossible : {pw_in.name}"]
    m = re.search(r"""(?im)^\s*pseudo_dir\s*=\s*['"]([^'"]+)['"]""", content)
    pseudo_dir = Path(m.group(1)).expanduser() if m else Path(cfg.PSEUDOS_DIR)
    if not pseudo_dir.is_absolute():
        pseudo_dir = (pw_in.parent / pseudo_dir).resolve()
    return check_pseudos_are_nc(pseudo_dir)


# ============================================================================
# BORN file format (matdyn non-analytic input)
# ============================================================================

# Format ``BORN`` consommé par matdyn.x (Quantum ESPRESSO >= 6.x) :
#   ligne 1 : 6 floats Voigt (epsilon_xx, epsilon_xy, epsilon_xz,
#                           epsilon_yy, epsilon_yz, epsilon_zz)
#   ligne N : 9 floats par atome (Z_star[3x3], row-major : xx xy xz yx yy yz zx zy zz)
# Séparateur : espaces. matdyn lit ce fichier via ``BORN_INPUT_FILE='BORN'``
# (l'environnement peut aussi pointer vers un chemin custom).
def write_born_file(dielectric_data: dict[str, Any], path: Path) -> Path:
    """Sérialise les données ``parsers/dielectric`` en fichier BORN pour matdyn.

    Parameters
    ----------
    dielectric_data
        Dict tel que produit par ``parsers.dielectric.parse_dielectric``
        avec, au minimum, les clés ``epsilon_xx`` / ``epsilon_yy`` /
        ``epsilon_zz`` (``epsilon_xy`` / ``epsilon_xz`` / ``epsilon_yz``
        pris à 0 si absents — convention « tenseur diagonal » par défaut).
        Optionnellement ``epsilon_xy``, ``epsilon_xz``, ``epsilon_yz``.
        Et ``born_Z_star_per_atom`` : liste de
        ``{"atom_index": int, "atom_type": str, "Z_star": [[..9 floats..]]}``.
    path
        Fichier BORN destination (typiquement ``<work_dir>/BORN``).

    Returns
    -------
    Path : le fichier écrit (pour chaînage).
    """
    ep_xx = float(dielectric_data.get("epsilon_xx", 0.0) or 0.0)
    ep_yy = float(dielectric_data.get("epsilon_yy", 0.0) or 0.0)
    ep_zz = float(dielectric_data.get("epsilon_zz", 0.0) or 0.0)
    ep_xy = float(dielectric_data.get("epsilon_xy", 0.0) or 0.0)
    ep_xz = float(dielectric_data.get("epsilon_xz", 0.0) or 0.0)
    ep_yz = float(dielectric_data.get("epsilon_yz", 0.0) or 0.0)

    lines: list[str] = [
        f"{ep_xx:20.12E} {ep_xy:20.12E} {ep_xz:20.12E} "
        f"{ep_yy:20.12E} {ep_yz:20.12E} {ep_zz:20.12E}",
    ]
    per_atom = dielectric_data.get("born_Z_star_per_atom") or []
    if not per_atom:
        raise ValueError(
            "dielectric_data manque 'born_Z_star_per_atom' — matdyn a besoin "
            "de la liste de tenseurs Z* par atome pour la correction non-analytique."
        )
    for entry in per_atom:
        tensor = entry.get("Z_star") if isinstance(entry, dict) else None
        if not isinstance(tensor, list):
            raise ValueError(
                f"Entrée bizarre dans born_Z_star_per_atom : {entry!r}. "
                f"Attendu dict avec clé 'Z_star' (liste 3x3)."
            )
        flat: list[float] = []
        for row in tensor:
            if not isinstance(row, (list, tuple)) or len(row) != 3:
                raise ValueError(
                    f"Z_star par atome doit être 3x3 : row = {row!r} (depuis {entry!r})."
                )
            flat.extend(float(v) for v in row)
        if len(flat) != 9:
            raise ValueError(
                f"Z_star d'un atome doit faire 9 floats en row-major (3x3), "
                f"got {len(flat)} : {flat!r}."
            )
        lines.append(" ".join(f"{v:20.12E}" for v in flat))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def dielectric_voigt_to_born_line(
    epsilon_xx: float, epsilon_yy: float, epsilon_zz: float,
    epsilon_xy: float = 0.0, epsilon_xz: float = 0.0, epsilon_yz: float = 0.0,
) -> str:
    """Petite helper de format : produit la ligne Voigt pour ``epsilon_xx..zz``.

    Exposé pour les tests (le test #3 vérifie le format exact ligne par ligne).
    """
    return (
        f"{float(epsilon_xx):20.12E} {float(epsilon_xy):20.12E} "
        f"{float(epsilon_xz):20.12E} {float(epsilon_yy):20.12E} "
        f"{float(epsilon_yz):20.12E} {float(epsilon_zz):20.12E}"
    )


# ============================================================================
# matdyn non-analytic input extension
# ============================================================================

# Regex pour détecter une ligne ``non_analytic`` *(déjà injectée ou non)*.
_NON_ANALYTIC_RX = re.compile(
    r"""(?im)^(\s*)non_analytic\s*=\s*['"]?\.\s*(true|false)\s*\.['"]?,?\s*$""",
)
_BORN_FILE_RX = re.compile(
    r"""(?im)^(\s*)BORN_INPUT_FILE\s*=\s*['"]([^'"]*)['"],?\s*$""",
)


def extend_matdyn_in_for_non_analytic(
    matdyn_text: str,
    born_filename: str = "BORN",
) -> str:
    """Injecte ``non_analytic=.true.`` + ``BORN_INPUT_FILE=...`` dans ``matdyn.in``.

    Idempotent : si ``non_analytic=.true.`` est DÉJÀ présent, ne double-injecte
    PAS. Si une autre valeur (``'false'``) est présente, remplace par ``'true'``
    explicitement (le but de l'opt-in LO/TO est d'avoir la correction).
    Borne le bloc : on injecte juste après la ligne ``&INPUT`` (convention matdyn).

    Le nom de fichier BORN (``born_filename``) suit la convention projet (nom
    court ``BORN`` en racine du work_dir). On ne touche PAS aux autres
    paramètres ``asr``, ``flfrc``, ``fldos`` : ils restent pilotés par le
    profil / la chaîne parente.
    """
    if not matdyn_text.lstrip().lower().startswith("&input"):
        # Pas un matdyn.in standard : on ajoute le bloc en tête (sécurité).
        header = (
            f"&INPUT\n"
            f"  non_analytic = .true.,\n"
            f"  BORN_INPUT_FILE = '{born_filename}',\n"
            f"/\n"
        )
        return header + matdyn_text
    if _NON_ANALYTIC_RX.search(matdyn_text):
        # Déjà présente — on remplace la valeur par .true. (au cas où .false.).
        matdyn_text = _NON_ANALYTIC_RX.sub(
            r"\1non_analytic = .true.,", matdyn_text, count=1,
        )
    else:
        # Injecte juste après le ``&INPUT``.
        matdyn_text = re.sub(
            r"(?im)^(\s*&INPUT\s*\n)",
            r"\1  non_analytic = .true.,\n",
            matdyn_text,
            count=1,
        )
    if _BORN_FILE_RX.search(matdyn_text):
        matdyn_text = _BORN_FILE_RX.sub(
            lambda m: f"{m.group(1)}BORN_INPUT_FILE = '{born_filename}',",
            matdyn_text, count=1,
        )
    else:
        matdyn_text = re.sub(
            r"(?im)^(\s*&INPUT\s*\n)",
            rf"\1  BORN_INPUT_FILE = '{born_filename}',\n",
            matdyn_text,
            count=1,
        )
    # S'assure qu'on a bien .true. après remplacement (au cas où override par .false.).
    matdyn_text = _NON_ANALYTIC_RX.sub(
        r"\1non_analytic = .true.,", matdyn_text, count=1,
    )
    return matdyn_text


# ============================================================================
# LO/TO splitting extraction
# ============================================================================


def parse_lo_to_splitting_at_gamma(
    phonon_freq_path: Path,
    *,
    born_data: dict[str, Any],
) -> dict[str, Any]:
    """Extrait fréquences LO/TO au point Γ + splitting depuis ``phonon.freq``.

    Lit le fichier ``phonon.freq`` au format matdyn.x standard (matdyn écrit
    une ligne par q-point ; la première ligne correspond souvent à Γ).
    Pour chaque mode optique on calcule ``ν_LO - ν_TO`` en utilisant :

        ν_LO² − ν_TO² = (4π/V) · (Σ_αβ (q·e_α) (Z*_α · u) (q·e_β) (Z*_β · u)) / ε_αβ·q·q

    Implementation simplifiée (juillet 2026) : on RENVOIE LE NOMBRE de
    modes optiques à Γ et le splitting maximal observé, suffisant pour la
    tile UI ``dielectric.lo_to_splitting_cm-1``. Le détail par mode sera
    étoffé dans un follow-up (ticket séparé).

    Returns
    -------
    Dict avec :
        ``"lo_freq_cm-1"`` : float | None   — fréquence LO max (cm⁻¹)
        ``"to_freq_cm-1"`` : float | None   — fréquence TO max (cm⁻¹)
        ``"splitting_cm-1"`` : float | None — LO - TO max (cm⁻¹)
        ``"n_optical_modes`` : int | None   — nb de modes optiques détectés
    """
    res: dict[str, Any] = {
        "lo_freq_cm-1": None,
        "to_freq_cm-1": None,
        "splitting_cm-1": None,
        "n_optical_modes": None,
    }
    if not phonon_freq_path.is_file():
        return res
    try:
        text = phonon_freq_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return res
    lines = text.splitlines()
    # Heuristique : on prend la DERNIÈRE ligne de mode (typiquement Γ en
    # q=0,001 ou label 'G' selon les versions matdyn). Pour P1 opt-in, une
    # seule q-grid grossière est utilisée (``generate_lo_to_grid``); le
    # dernier q-point analysé correspond à la maille → proche Γ.
    mode_lines = [
        ln.strip() for ln in lines
        if ln.strip() and not ln.lower().startswith(("freq", "cm-1", "thz"))
        and re.match(r"^[-+]?\d", ln)
    ]
    if not mode_lines:
        return res
    # Format attendu : freq (cm-1) par mode. Le décompte dépend de nat.
    # On prend la dernière ligne = q au plus près de Γ.
    last_line = mode_lines[-1]
    try:
        energies_cm = [
            float(t) for t in last_line.split()
            if t.replace(".", "").replace("-", "").replace("+", "").isdigit()
        ]
    except (ValueError, AttributeError):
        return res
    if not energies_cm:
        return res
    # Heuristique grossière : n_atoms_at_Γ = N modes totaux (3 nat par atome
    # en fait — 3 acoustique + 3*(nat-1) optiques). On n'a pas nat ici sans
    # scf.in. On se contente de signaler le MODE le plus haut comme LO
    # candidat + le mode le plus bas parmi les optiques comme TO. Le
    # splitting est indicatif — un parseur dédié plus tard (ticket : ``G2``).
    res["lo_freq_cm-1"] = energies_cm[-1]
    if len(energies_cm) >= 2:
        res["to_freq_cm-1"] = energies_cm[1] if len(energies_cm) > 1 else None
        res["splitting_cm-1"] = (
            energies_cm[-1] - energies_cm[1] if res["to_freq_cm-1"] is not None
            else None
        )
    res["n_optical_modes"] = len(energies_cm)
    return res

"""
Task_Elastic : déformations (Voigt), boucles pw.x, estimation C_ij par dérivées d'énergie
et modules Voigt–Reuss–Hill (squelette — compléter selon symétrie, ex. orthorhombique DyFeO3).
"""
from __future__ import annotations

import json
import multiprocessing as mp
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, List, Optional, Tuple

import numpy as np

import config as cfg
from input_scaling import scale_pw_input_file
from parsers.pw_out import parse_pw_out_file
from qe_subprocess import run_pw_x_in
from state_db import TaskState, TaskStatus, WorkflowDB

from eos_paths import WORKFLOW_STATE_FILENAME

# Tenseur métrique: déformations e1..e6 en notation Voigt (xx,yy,zz,yz,xz,xy) — 6 modes petits


@dataclass
class ElasticConfig:
    template_pw: Path
    subdir: str = "2_elastic"
    nproc: int = field(default_factory=lambda: cfg.MPI_NPROC)
    # Déformations adimensionnelles typiques
    delta_sequence: Tuple[float, ...] = (-0.01, 0.0, 0.01)


def _one_elastic(args: Tuple[str, str, int]) -> Tuple[str, float, str]:
    d, name, nproc = args
    out = run_pw_x_in(Path(d), name, nproc=nproc)
    e, _v = parse_pw_out_file(out)
    if e is None:
        raise ValueError("Énergie absente")
    return name, float(e), str(out)


def _apply_strain_mode(
    template: Path, out: Path, mode: int, h: float
) -> None:
    """
    Applique une déformation e_h sur la cellule (mode 0-5) à l'amplitude h.
    Implémentation minimale: mode 0 = dilatation isotrope (1+h)^(1/3) sur les vecteurs.
    Pour cristal basse symétrie, remplacer par la base de déformations du groupe ponctuel.
    """
    if mode == 0:
        scale_pw_input_file(template, out, h)
    else:
        # Placeholder: même scaling — à raffiner (cisaillement, etc.)
        f = 1.0 + 0.5 * h * (0.1 * mode)  # stub
        scale_pw_input_file(template, out, f - 1.0)


def task_elastic(
    work_dir: Path,
    material_id: str,
    template_pw: Path,
    db: WorkflowDB,
    conf: Optional[ElasticConfig] = None,
) -> dict[str, Any]:
    if db.get_task("eos").status != TaskStatus.DONE.value:
        raise RuntimeError("Task_Elastic: EOS doit être DONE avant l’élasticité (structure à V0).")
    conf = conf or ElasticConfig(template_pw=template_pw)
    ed = work_dir / conf.subdir
    ed.mkdir(parents=True, exist_ok=True)

    st = TaskState(status=TaskStatus.RUNNING.value, message="Préparation déformations")
    db.set_task("elastic", st)
    db.save(work_dir / WORKFLOW_STATE_FILENAME)

    jobs: List[Tuple[str, str, int]] = []
    m = 0
    for h in conf.delta_sequence:
        name = f"elastic_m{m}_h{h:+.3f}.in"
        out_in = ed / name
        _apply_strain_mode(conf.template_pw, out_in, m, float(h))
        jobs.append((str(ed), name, conf.nproc))

    npar = min(len(jobs), max(1, mp.cpu_count() - 1), 6)
    with mp.Pool(processes=npar) as pool:
        res = pool.map(_one_elastic, jobs)

    by_name = {r[0]: r[1] for r in res}
    c_ii_approx = float("nan")
    try:
        v0 = float(db.get_task("eos").data.get("eos", {}).get("V0_bohr3", 0.0))
        if v0 > 0 and len(conf.delta_sequence) >= 3:
            h0, h1, h2 = (float(x) for x in conf.delta_sequence[:3])
            n0, n1, n2 = (f"elastic_m0_h{h0:+.3f}.in", f"elastic_m0_h{h1:+.3f}.in", f"elastic_m0_h{h2:+.3f}.in")
            e0, e1, e2 = by_name.get(n0), by_name.get(n1), by_name.get(n2)
            if e0 is not None and e1 is not None and e2 is not None and abs(h0 - 2 * h1 + h2) > 1e-12:
                d2d = (e0 - 2 * e1 + e2)  # h1 au centre, pas d’uniformité ici: squelette
                c_ii_approx = (1.0 / v0) * d2d
    except Exception:
        pass

    out_js = {
        "energies": res,
        "C_00_approx_Ry": c_ii_approx,
        "note": "Remplacer par C_ij complet (symétries, 2ndes dérivées) — voir user_guide thermo_pw / elastic_constants",
    }
    (ed / "elastic_summary.json").write_text(
        json.dumps(out_js, indent=2, ensure_ascii=False, default=str), encoding="utf-8"
    )

    st = TaskState(status=TaskStatus.DONE.value, message="Élasticité (squelette) terminé", data=out_js)
    db.set_task("elastic", st)
    db.save(work_dir / WORKFLOW_STATE_FILENAME)
    return out_js

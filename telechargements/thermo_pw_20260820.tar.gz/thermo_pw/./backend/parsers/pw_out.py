"""
Extraction d'énergie et volume depuis les sorties pw.x.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional, Tuple

RE_TOTAL_ENERGY = re.compile(
    r"!\s*total energy\s*=\s*([+-]?(?:\d+\.?\d*|\d*\.?\d+)(?:[DdEe][+-]?\d+)?)\s*Ry",
    re.IGNORECASE,
)
# Ligne convergée la plus fiable
RE_UNIT_VOL = re.compile(
    r"unit-cell volume\s*=\s*([+-]?\d+\.?\d*)\s*\(a\.u\.\)\^3",
    re.IGNORECASE,
)


def parse_pw_out_text(text: str) -> Tuple[Optional[float], Optional[float]]:
    """
    Retourne (E_Ry, V_au3) en prenant la dernière occurrence cohérente.
    """
    energies = [float(m.group(1).replace("D", "E").replace("d", "e")) for m in RE_TOTAL_ENERGY.finditer(text)]
    volumes = [float(m.group(1)) for m in RE_UNIT_VOL.finditer(text)]
    e = energies[-1] if energies else None
    v = volumes[-1] if volumes else None
    return e, v


def parse_pw_out_file(path: Path) -> Tuple[Optional[float], Optional[float]]:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return parse_pw_out_text(f.read())


def job_completed_ok(out_path: Path) -> bool:
    """
    Heuristique : marqueur « job done » (insensible à la casse) dans le journal pw.x.
    Fichiers de taille modérée (jusqu'à env. 2 Mo) : lecture entière. Au-delà : dernière fenêtre 32 ko.
    """
    if not out_path.is_file():
        return False
    try:
        size = out_path.stat().st_size
        with open(out_path, "r", encoding="utf-8", errors="replace") as f:
            if size <= 2_000_000:
                text = f.read()
            else:
                f.seek(max(0, size - 32_000))
                text = f.read()
    except OSError:
        return False
    return "job done" in text.lower()


def ph_job_completed_ok(out_path: Path) -> bool:
    """
    Même heuristique que pour pw.x : fin de log « job done » (sorties ph.x, q2r, etc.).
    """
    return job_completed_ok(out_path)

"""
Extraction indicative des grandeurs depuis thermo_pw_run.out (sortie variable selon version / what).
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Optional

from eos_paths import wf1_resolve_dir_containing_thermo_log

_KBAR_TO_GPA = 0.1  # 10 kbar = 1 GPa
THERMO_PW_OUT_PARSE_REVISION = 12
_LOG_TAIL_MAX_CHARS = 420_000
_PARSE_WINDOW_CHARS = 380_000

_TPW_LOG_BUF_BYTES = max(_LOG_TAIL_MAX_CHARS, _PARSE_WINDOW_CHARS + 64_000)
_THERMO_LOG_MAX_TAIL_READ_BYTES = _TPW_LOG_BUF_BYTES + 12_288

_CIJ_TITLE_RES = (
    # variantes QE / thermo_pw (voir user_guide)
    re.compile(r"(?is)Elastic\s+constants\s+C_ij\s*\(\s*kbar\s*\)"),
    re.compile(r"(?is)Elastic\s+constants\s+C_ij\s*\(\s*k[Bb]ar\s*\)"),
    re.compile(r"(?is)Elastic\s+constants\s+C_ij\b"),
    re.compile(r"(?is)Elastic\s+constants\b.*?\(\s*k[Bb]ar\s*\)"),
    re.compile(r"(?is)Elastic\s+(?:constants|constant)\s+matrix"),
    re.compile(r"(?is)Elastic\s+constants\s*\([^)]*k[Bb]ar[^)]*\)"),
    re.compile(r"(?is)The\s+elastic\s+constants\s+C_ij\b"),
)


def _elastic_constants_nonempty(parsed: dict[str, Any]) -> bool:
    ecs = parsed.get("elastic_constants_GPa")
    return isinstance(ecs, list) and len(ecs) > 0


def _read_log_head_for_parse(log_path: Path, *, max_chars: int) -> str:
    """Premiers octets du journal — complète la lecture « queue seule » si fichier très long."""
    try:
        size = log_path.stat().st_size
    except OSError:
        return ""
    if size <= 0:
        return ""
    if size <= max_chars:
        try:
            return log_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return ""
    try:
        with log_path.open("rb") as f:
            raw = f.read(max_chars + 4096)
    except OSError:
        return ""
    txt = raw.decode("utf-8", errors="replace")
    if len(txt) > max_chars:
        txt = txt[:max_chars]
    return txt


_EL_CONS_FILENAMES = (
    "output_el_cons.dat",
    "Output_el_cons.dat",
    "OUTPUT_EL_CONS.dat",
)

# Fichiers courants après EOS / phonons / élasticités (liens artefact dans l’UI).
_RESULT_INVENTORY_REL = (
    "thermo_pw_run.out",
    "output_el_cons.dat",
    "eos_summary.json",
    "elastic_vs_T.dat",
    "elastic_vs_temperature.dat",
    "elastic_constants_vs_T.dat",
    "phonon_bands_plot.dat",
    "phonon_dos.dat",
    "1_eos_volumes/eos_points.dat",
    "1_eos_volumes/eos_curve.dat",
    "1_eos_volumes/eos_ev.png",
    "1_eos_volumes/plot_eos.gnu",
    "elastic_vs_T_plot.png",
    "phonon_bands.png",
    "phonon_dos.png",
    "energy_files/output_ev.dat",
    "energy_files/output_ev.dat_mur",
    "energy_files/output_el_cons.dat",
    "plot_phonon_bands.gnu",
)


def _qe_float(token: str) -> Optional[float]:
    """Nombre flottant sortie Fortran (accepte exponent D/d)."""
    s = str(token).strip().replace(",", ".")
    if not s:
        return None
    try:
        return float(s.replace("D", "E").replace("d", "e"))
    except ValueError:
        return None


def _parse_elastic_constants_voigt_kbar_after_title(sub: str) -> list[dict[str, Any]]:
    """Parsage matrice C_ij ligne par ligne après le titre (« … (kbar) » ou variante)."""
    ecs: list[dict[str, Any]] = []
    seen: set[tuple[int, int]] = set()
    for sl_raw in sub.splitlines():
        sls = sl_raw.strip()
        if not sls or sls.lower().startswith("elastic ") or sls.startswith("!"):
            continue
        rm = re.match(r"^(\d+)\b", sls)
        if not rm:
            continue
        row = int(rm.group(1))
        if row < 1 or row > 6:
            continue
        toks = sls[rm.end() :].split()
        if len(toks) < 6:
            continue
        vals: list[Optional[float]] = []
        for x in toks[:6]:
            fv = _qe_float(x)
            vals.append(fv)
        if any(v is None for v in vals):
            continue
        for col, vk in enumerate(vals, start=1):
            fv = vk  # narrowing
            if fv is None:
                continue
            kxy = (row, col)
            if kxy in seen:
                continue
            seen.add(kxy)
            ecs.append(
                {
                    "i": row,
                    "j": col,
                    "value_GPa": float(fv) * _KBAR_TO_GPA,
                    "line": sls[:200],
                }
            )
    return ecs


def _header_blob_suggests_elastic_gpa(head_lines: list[str]) -> bool:
    blob = "\n".join(head_lines[:60]).lower()
    if "gpa" not in blob:
        return False
    return any(
        k in blob
        for k in (
            "elastic",
            "c_ij",
            "cij",
            "constant",
            "voigt",
        )
    )


def _try_parse_voigt_numbered_row(sls: str) -> Optional[tuple[int, list[float]]]:
    sls = sls.strip()
    if not sls or sls.startswith("#"):
        return None
    rm = re.match(r"^(\d+)\b", sls)
    if not rm:
        return None
    row = int(rm.group(1))
    if row < 1 or row > 6:
        return None
    toks = sls[rm.end() :].split()
    if len(toks) < 6:
        return None
    vals: list[float] = []
    for x in toks[:6]:
        fv = _qe_float(x)
        if fv is None:
            return None
        vals.append(float(fv))
    return row, vals


def _find_first_voigt_6x6_block(lines: list[str]) -> Optional[list[tuple[int, list[float]]]]:
    raw = [ln.strip() for ln in lines if ln.strip()]
    n = len(raw)
    if n < 6:
        return None
    for i in range(0, n - 5):
        block: list[tuple[int, list[float]]] = []
        ok = True
        for k in range(6):
            parsed = _try_parse_voigt_numbered_row(raw[i + k])
            if not parsed:
                ok = False
                break
            rnum, vals = parsed
            if rnum != k + 1:
                ok = False
                break
            block.append((rnum, vals))
        if ok and len(block) == 6:
            return block
    return None


def _ecs_rows_from_voigt_block(
    block: list[tuple[int, list[float]]],
    *,
    unit_is_kbar: bool,
    source_line_stub: str,
) -> list[dict[str, Any]]:
    ecs: list[dict[str, Any]] = []
    for row, vals in block:
        for col, fv in enumerate(vals, start=1):
            gpa = fv * _KBAR_TO_GPA if unit_is_kbar else fv
            ecs.append(
                {
                    "i": row,
                    "j": col,
                    "value_GPa": gpa,
                    "line": source_line_stub,
                }
            )
    return ecs


def _parse_elastic_from_freeform_text(text: str) -> tuple[list[dict[str, Any]], bool]:
    """Retourne (ecs, ok) avec détection titre + bloc 6×6 ; valeurs traitées en kbar si GPa absent."""
    if not text or not text.strip():
        return [], False
    lines = text.splitlines()
    head_gpa = _header_blob_suggests_elastic_gpa(lines)
    unit_is_kbar = not head_gpa

    ecs_acc: list[dict[str, Any]] = []

    for rx in _CIJ_TITLE_RES:
        mcij = rx.search(text)
        if not mcij:
            continue
        sub = text[mcij.start() : mcij.start() + 14_000]
        ecs_rows = _parse_elastic_constants_voigt_kbar_after_title(sub)
        if ecs_rows:
            ecs_acc.extend(ecs_rows)
            break

    if not ecs_acc:
        blk = _find_first_voigt_6x6_block(lines)
        if blk:
            ecs_acc.extend(
                _ecs_rows_from_voigt_block(
                    blk,
                    unit_is_kbar=unit_is_kbar,
                    source_line_stub="matrix_block",
                )
            )

    seen: set[tuple[int, int]] = set()
    out: list[dict[str, Any]] = []
    for row in ecs_acc:
        try:
            i, j = int(row["i"]), int(row["j"])
            v = float(row["value_GPa"])
        except (KeyError, TypeError, ValueError):
            continue
        k = (i, j)
        if k in seen:
            continue
        seen.add(k)
        ln = row.get("line")
        entry = dict(row)
        entry["value_GPa"] = v
        if isinstance(ln, str):
            entry["line"] = ln
        else:
            entry.pop("line", None)
        out.append(entry)

    return out, bool(out)


def _try_parse_flat_kbar_voigt_6x6(body) -> tuple[list[dict[str, Any]], bool]:
    """36 premiers nombres du fichier → matrice 6×6 Voigt (thermo_pw ``output_el_cons*.dat*``), unités **kbar**.

    Défense (juillet 2026) : accepte aussi ``pathlib.Path`` (lus à la volée) en
    plus du ``str`` historique. Sans cela, ``merge_elastic_from_output_el_cons_files``
    peut passer un Path dans certaines branches d'erreur et lever une
    ``AttributeError: 'PosixPath' object has no attribute 'strip'`` silencieuse
    (try/except englobant) qui retourne ``None`` → factsheet voit ``—``.
    """
    # Fix défensif : si on reçoit un Path (au lieu du str historique), on lit
    # le contenu. Toute OSError ici est traitée comme « fichier illisible ».
    from pathlib import Path as _P
    if isinstance(body, _P):
        try:
            body = body.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return [], False
    if not body or not hasattr(body, "strip") or not body.strip():
        return [], False
    blob = body.replace("D", "E").replace("d", "e")
    nums: list[float] = []
    for tok in blob.split():
        fv = _qe_float(tok)
        if fv is None:
            continue
        nums.append(float(fv))
        if len(nums) >= 36:
            break
    if len(nums) < 36:
        return [], False
    ecs: list[dict[str, Any]] = []
    idx = 0
    for i in range(1, 7):
        for j in range(1, 7):
            gpa = nums[idx] * _KBAR_TO_GPA
            idx += 1
            ecs.append({"i": i, "j": j, "value_GPa": float(gpa), "line": "flat_token_stream_kbar"})
    return ecs, True


def merge_elastic_from_output_el_cons_files(work_dir: Path) -> Optional[dict[str, Any]]:
    """Lit output_el_cons.dat (thermo_pw) si la matrice n’est pas tombée dans le journal."""
    work_dir = Path(work_dir).resolve()
    candidates: list[Path] = []
    for fname in _EL_CONS_FILENAMES:
        p = work_dir / fname
        if p.is_file():
            candidates.append(p)
    for rel in ("energy_files/output_el_cons.dat", "energy_files/Output_el_cons.dat"):
        p = work_dir / rel
        if p.is_file():
            candidates.append(p)
    for pat in (
        "*el_cons*.dat",
        "*el_cons*.dat.*",
        "energy_files/*el_cons*.dat",
        "energy_files/*el_cons*.dat.*",
    ):
        for p in work_dir.glob(pat):
            if p.is_file():
                candidates.append(p)
    try:
        for p in work_dir.rglob("output_el_cons.dat*"):
            if p.is_file():
                candidates.append(p)
    except OSError:
        pass
    seen_res: set[str] = set()
    paths: list[Path] = []
    for p in candidates:
        try:
            key = str(p.resolve())
        except OSError:
            continue
        if key in seen_res:
            continue
        seen_res.add(key)
        paths.append(p)

    def _mtime_ns(pp: Path) -> int:
        try:
            return pp.stat().st_mtime_ns
        except OSError:
            return 0

    paths.sort(key=_mtime_ns, reverse=True)

    for p in paths:
        try:
            body = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        ecs, ok = _parse_elastic_from_freeform_text(body)
        if not ok:
            ecs, ok = _try_parse_flat_kbar_voigt_6x6(body)
        if ok:
            return {
                "elastic_constants_GPa": ecs,
                "source_relpath": p.resolve().relative_to(work_dir).as_posix(),
            }
    return None


def build_result_file_inventory(work_dir: Path) -> list[dict[str, Any]]:
    """Liste de fichiers exploitables (existants) pour liens artefact côté UI."""
    work_dir = Path(work_dir).resolve()
    out: list[dict[str, Any]] = []
    seen: set[str] = set()

    def add_if(rel: str) -> None:
        if rel in seen:
            return
        pp = work_dir / rel.replace("/", "/")
        if not pp.is_file():
            return
        try:
            st = pp.stat()
        except OSError:
            return
        seen.add(rel)
        out.append({"relpath": rel.replace("\\", "/"), "size_bytes": st.st_size})

    for rel in _RESULT_INVENTORY_REL:
        add_if(rel)
    try:
        from parsers.elastic_t_dat_scan import find_elastic_t_dat

        ed = find_elastic_t_dat(work_dir)
        if ed is not None and ed.is_file():
            rel = ed.resolve().relative_to(work_dir).as_posix()
            add_if(rel)
    except Exception:
        pass
    extra_png = ["eos_ev.png", "elastic_vs_T_plot.png", "phonon_bands.png", "phonon_dos.png"]
    for leaf in extra_png:
        add_if(leaf)
    out.sort(key=lambda x: x["relpath"].lower())
    return out


def _apply_elastic_derivatives_inplace(parsed: dict[str, Any], tail_for_infer: str) -> None:
    ecs = parsed.get("elastic_constants_GPa")
    if not isinstance(ecs, list) or not ecs:
        return
    ei = _infer_elastic_independent(ecs, tail_for_infer)
    if ei is not None:
        parsed["elastic_independent_GPa"] = ei
        if "elastic_independent_GPa" not in parsed.get("matched_keywords", []):
            parsed.setdefault("matched_keywords", []).append("elastic_independent_GPa")
        if ei.get("system") == "cubic_m3m_approx":
            c = ei.get("constants_GPa") or {}
            if "C11_GPa" in c and "C12_GPa" in c and "C44_GPa" in c:
                parsed["elastic_cubic_independent_GPa"] = {
                    "C11_GPa": c["C11_GPa"],
                    "C12_GPa": c["C12_GPa"],
                    "C44_GPa": c["C44_GPa"],
                }
    if ecs and "elastic_constants_GPa" not in parsed.get("matched_keywords", []):
        parsed.setdefault("matched_keywords", []).append("elastic_constants_GPa")


def _voigt_close(a: float, b: float, *, rtol: float = 0.015, atol: float = 0.3) -> bool:
    return abs(a - b) <= atol + rtol * max(abs(a), abs(b), 1.0)


def _cubic_derived_polycrystal_voigt(c11: float, c12: float, c44: float) -> dict[str, Any]:
    """Agrégat polycrystal approx. Voigt (+ cisaillement Hill Voigt/Reuss) à partir des C₁₁, C₁₂, C₄₄ cubiques."""
    k_bulk = (c11 + 2.0 * c12) / 3.0
    g_voigt = (c11 - c12 + 3.0 * c44) / 5.0
    denom_r = 4.0 * c44 + 3.0 * (c11 - c12)
    g_reuss: Optional[float] = None
    if abs(denom_r) > 1e-18:
        g_reuss = (5.0 * c44 * (c11 - c12)) / denom_r
    g_hill: Optional[float] = None
    if g_reuss is not None:
        g_hill = 0.5 * (g_voigt + g_reuss)

    out_d: dict[str, Any] = {
        "bulk_modulus_K_from_Cij_GPa": k_bulk,
        "shear_modulus_G_Voigt_aggregate_from_Cij_GPa": g_voigt,
    }
    if g_reuss is not None:
        out_d["shear_modulus_G_Reuss_aggregate_from_Cij_GPa"] = g_reuss
    if g_hill is not None:
        out_d["shear_modulus_G_Hill_aggregate_from_Cij_GPa"] = g_hill
        if g_hill > 1e-18:
            pugh = k_bulk / g_hill
            out_d["pugh_BG_ratio_from_Hill_G"] = pugh
            out_d["pugh_ductile_fragile_hint"] = "ductile" if pugh > 1.75 else "fragile"

    cond_c11_c12 = (c11 - c12) > 0.0
    cond_trace = (c11 + 2.0 * c12) > 0.0
    cond_c44 = c44 > 0.0
    out_d["born_stability_cubic"] = {
        "C11_minus_C12_positive": cond_c11_c12,
        "C11_plus_2C12_positive": cond_trace,
        "C44_positive": cond_c44,
        "stable": bool(cond_c11_c12 and cond_trace and cond_c44),
        "values_GPa": {
            "C11_minus_C12": float(c11 - c12),
            "C11_plus_2C12": float(c11 + 2.0 * c12),
            "C44": float(c44),
        },
    }

    denom = 3.0 * k_bulk + g_voigt
    if denom > 1e-12 and g_voigt > 1e-15 and k_bulk > -1e-6:
        e_young = 9.0 * k_bulk * g_voigt / denom
        nu_poisson = (3.0 * k_bulk - 2.0 * g_voigt) / (2.0 * denom)
        out_d["young_modulus_E_Voigt_aggregate_from_Cij_GPa"] = e_young
        out_d["poisson_ratio_nu_Voigt_aggregate_from_Cij"] = nu_poisson
    dsc = abs(c11 - c12)
    if dsc > 1e-9:
        out_d["zener_anisotropy_ratio_A"] = (2.0 * c44) / dsc
    else:
        out_d["zener_anisotropy_ratio_A"] = None
        out_d["zener_note"] = "C11 − C12 ≈ 0 : rapport A de Zener indéfini"
    return out_d


def _vv_get(vv: list[list[Optional[float]]], i: int, j: int) -> Optional[float]:
    if not (1 <= i <= 6 and 1 <= j <= 6):
        return None
    return vv[i - 1][j - 1]


def _voigt_mat_from_ecs(ecs: list[dict[str, Any]]) -> list[list[Optional[float]]]:
    vv: list[list[Optional[float]]] = [[None for _ in range(6)] for __ in range(6)]
    for e in ecs:
        try:
            i, j = int(e["i"]), int(e["j"])
            v = float(e["value_GPa"])
        except (KeyError, TypeError, ValueError):
            continue
        if not (1 <= i <= 6 and 1 <= j <= 6):
            continue
        vv[i - 1][j - 1] = v
        vv[j - 1][i - 1] = v
    return vv


def _impute_implicit_voigt_zeros(vv: list[list[Optional[float]]]) -> None:
    """Remplace les cases absentes par 0.0 là où les journaux QE omettent les zéros explicites.

    Sans cela, les couplages normaux (1–3) ↔ cisaillements (4–6) restent ``None``,
    ``_principal_elastic_zeros_ok`` échoue et une maille **cubique** retombe en liste
    Voigt générique (C₁₁, C₁₂, C₁₃, …) au lieu de C₁₁, C₁₂, C₄₄.
    """
    for i in range(1, 4):
        for j in range(4, 7):
            if _vv_get(vv, i, j) is None:
                vv[i - 1][j - 1] = 0.0
                vv[j - 1][i - 1] = 0.0
    for i in range(4, 7):
        for j in range(4, 7):
            if i >= j:
                continue
            if _vv_get(vv, i, j) is None:
                vv[i - 1][j - 1] = 0.0
                vv[j - 1][i - 1] = 0.0


def _ibrav_hint_from_tail(text: str) -> Optional[int]:
    found: list[int] = []
    for m in re.finditer(r"\bibrav\s*=\s*(-?\d+)", text, re.I):
        try:
            found.append(int(m.group(1)))
        except ValueError:
            pass
    return found[-1] if found else None


def _principal_elastic_zeros_ok(vv: list[list[Optional[float]]]) -> tuple[bool, float]:
    """Axes QE habituels : couplages nuls entre deformations/principales normales et cisaillements hors diagonale des blocs shear."""
    di = [_vv_get(vv, k, k) for k in (1, 2, 3)]
    finite = [x for x in di if x is not None]
    scale_diag = max(abs(v) for v in finite) if finite else 1.0
    tol = max(0.1, 0.006 * max(abs(scale_diag), 1.0))
    for i in range(1, 4):
        for j in range(4, 7):
            v = _vv_get(vv, i, j)
            if v is None:
                return False, scale_diag
            if abs(v) > tol:
                return False, scale_diag
    for i in range(4, 7):
        for j in range(1, 4):
            v = _vv_get(vv, i, j)
            if v is None:
                return False, scale_diag
            if abs(v) > tol:
                return False, scale_diag
    for i in range(4, 7):
        for j in range(4, 7):
            if i == j:
                continue
            v = _vv_get(vv, i, j)
            if v is None:
                return False, scale_diag
            if abs(v) > tol:
                return False, scale_diag
    return True, scale_diag


def _infer_elastic_independent(ecs: list[dict[str, Any]], tail: str) -> Optional[dict[str, Any]]:
    """Réduit la matrice symétrique 6×6 (Voigt) selon cubique → hex/tétrag → orthorhombique, sinon liste générique."""
    vv = _voigt_mat_from_ecs(ecs)
    if not any(any(x is not None for x in row) for row in vv):
        return None
    _impute_implicit_voigt_zeros(vv)

    ibrav = _ibrav_hint_from_tail(tail)
    zs_ok, _scal = _principal_elastic_zeros_ok(vv)
    voigt_note = (
        "Voigt 1–3 composantes normales ε_xx, ε_yy, ε_zz ; 4–6 cisaillements "
        "(yz, xz, xy) conformément QE / IEEE usuels."
    )

    def pack(
        system: str,
        rows: list[tuple[str, float]],
        extra: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        out_e: dict[str, Any] = {
            "system": system,
            "ibrav_hint": ibrav,
            "voigt_convention": voigt_note,
            "principal_axes_well_formed": zs_ok,
            "entries_GPa": [{"symbol": k, "value_GPa": float(v)} for k, v in rows],
            "constants_GPa": {k: float(v) for k, v in rows},
        }
        if extra:
            out_e.update(extra)
        return out_e

    def generic_voigt() -> Optional[dict[str, Any]]:
        rows: list[tuple[str, float]] = []
        for i in range(1, 7):
            for j in range(i, 7):
                v = _vv_get(vv, i, j)
                if v is None:
                    continue
                rows.append((f"C{i}_{j}_Voigt_GPa", float(v)))
        if not rows:
            return None
        return pack(
            "generic_symmetric_voigt",
            rows,
            {
                "note": (
                    "Matrice Voigt brute : symétrie cristalline non identifiée de façon sûre, "
                    "ou couplages hors blocs diagonaux (axes différentes du tableau élasticités)."
                ),
                "display_hint": (
                    "Préférer un bloc « Elastic constants C_ij » complet dans thermo_pw_run.out ; "
                    "sinon aucune liste « indépendante » n’est disponible sans hypothèse de symétrie."
                ),
            },
        )

    d1 = _vv_get(vv, 1, 1)
    d2 = _vv_get(vv, 2, 2)
    d3 = _vv_get(vv, 3, 3)
    c12 = _vv_get(vv, 1, 2)
    c13 = _vv_get(vv, 1, 3)
    c23 = _vv_get(vv, 2, 3)
    c44 = _vv_get(vv, 4, 4)
    c55 = _vv_get(vv, 5, 5)
    c66 = _vv_get(vv, 6, 6)
    need_diag = (d1, d2, d3, c12, c13, c23, c44, c55, c66)
    if any(x is None for x in need_diag):
        return generic_voigt()

    dd = (float(d1), float(d2), float(d3))
    co12 = float(c12)
    co13 = float(c13)
    co23 = float(c23)
    ss44, ss55, ss66 = float(c44), float(c55), float(c66)

    # --- Cubique
    cub = (
        zs_ok
        and _voigt_close(dd[0], dd[1])
        and _voigt_close(dd[1], dd[2])
        and _voigt_close(co12, co13)
        and _voigt_close(co13, co23)
        and _voigt_close(ss44, ss55)
        and _voigt_close(ss55, ss66)
    )
    if cub:
        c11_m = (dd[0] + dd[1] + dd[2]) / 3.0
        c12_m = (co12 + co13 + co23) / 3.0
        c44_m = (ss44 + ss55 + ss66) / 3.0
        ex: dict[str, Any] = {
            "derived_polycrystal_Voigt_from_Cij": _cubic_derived_polycrystal_voigt(c11_m, c12_m, c44_m),
        }
        if ibrav is not None and ibrav not in (-3, -2, -1, 0, 1, 2, 3):
            ex["classification_note"] = (
                "Matrice compatibles cubiques alors que les indices « ibrav » du journal pointent "
                "vers une autre classe — vérifier l’entrée PW."
            )
        return pack(
            "cubic_m3m_approx",
            [("C11_GPa", c11_m), ("C12_GPa", c12_m), ("C44_GPa", c44_m)],
            ex,
        )

    if not zs_ok:
        return generic_voigt()

    # --- Orthorhombique repère QE (C₁₁≠C₁₂ plan)
    if not _voigt_close(dd[0], dd[1]):
        return pack(
            "orthorhombic_mmm_approx",
            [
                ("C11_GPa", dd[0]),
                ("C22_GPa", dd[1]),
                ("C33_GPa", dd[2]),
                ("C12_GPa", co12),
                ("C13_GPa", co13),
                ("C23_GPa", co23),
                ("C44_GPa", ss44),
                ("C55_GPa", ss55),
                ("C66_GPa", ss66),
            ],
        )

    # --- Tetragonal hexagonal famille (axes : C₁₁=C₂₂, C₁₃=C₂₃ en plan, etc.)
    tet_hex = (
        _voigt_close(dd[0], dd[1])
        and _voigt_close(ss44, ss55)
        and _voigt_close(co13, co23)
    )

    dm = 0.5 * (dd[0] + dd[1])
    cm13 = 0.5 * (co13 + co23)
    c66_pred = 0.5 * (dm - co12)

    if tet_hex and not _voigt_close(dd[0], dd[2]):
        prefer_hex = False
        if ibrav == 6:
            prefer_hex = True
        elif ibrav == 4:
            prefer_hex = False
        else:
            prefer_hex = _voigt_close(ss66, c66_pred, rtol=0.028, atol=0.8)

        if prefer_hex:
            # Six termes usuels Voigt sous 6/mmm — C₁₁, C₁₂, C₁₃, C₃₃, C₄₄, C₆₆ ; la relation classique pour C₄₄/C₆₆ est rappelée en diagnostic.
            ex_h: dict[str, Any] = {
                "c66_theory_half_C11_minus_C12_GPa": float(c66_pred),
            }
            if not _voigt_close(ss66, c66_pred, rtol=0.03, atol=0.9):
                ex_h["hexagonal_C66_residual_note"] = (
                    "C₆₆ lisé dans la matrice diffère sensiblement de ½(C₁₁−C₁₂) sous 6/mmm strict — "
                    "vérifier point de groupe / orientation QE."
                )
            return pack(
                "hexagonal_6mmm_approx",
                [
                    ("C11_GPa", dd[0]),
                    ("C12_GPa", co12),
                    ("C13_GPa", cm13),
                    ("C33_GPa", dd[2]),
                    ("C44_GPa", ss44),
                    ("C66_GPa", ss66),
                ],
                ex_h,
            )

        return pack(
            "tetragonal_4mmm_approx",
            [
                ("C11_GPa", dm),
                ("C12_GPa", co12),
                ("C13_GPa", cm13),
                ("C33_GPa", dd[2]),
                ("C44_GPa", ss44),
                ("C66_GPa", ss66),
            ],
        )

    # --- Trigonal ibrav QE 5 ou 7 : souvent même forme bloquée mais constantes différentes
    if zs_ok and ibrav is not None and ibrav in (5, 7):
        return pack(
            "trigonal_rhombohedral_approx",
            [
                ("C11_matrix_GPa", dd[0]),
                ("C12_matrix_GPa", co12),
                ("C13_matrix_GPa", co13),
                ("C33_matrix_GPa", dd[2]),
                ("C44_matrix_GPa", ss44),
                ("C66_matrix_GPa", ss66),
            ],
            {
                "note": (
                    "Indices ibrav 5 ou 7 (trigonale / rhomboédrique QE) ; constantes tirées Voigt générique "
                    "— vérifiez groupe ponctuel et orientation dans le journal."
                )
            },
        )

    return generic_voigt()


_SCALAR_KEYS_HEAD_MERGE = (
    "debye_temperature_K",
    "bulk_modulus_GPa",
    "bulk_modulus_pressure_derivative",
    "young_modulus_GPa",
    "shear_modulus_GPa",
    "poisson_ratio",
)


# ============================================================================
# Parsers « P5 extras » (juin 2026) — miroitent le pattern de parse_thermo_pw_log
# ============================================================================
# Ces parsers sont appelés sur les journaux dédiés ``thermo_pw_<what>.out``
# emitidos par ``pipeline._run_thermo_extras`` lorsque l'utilisateur active
# les volets « Propriétés thermo_pw.x étendues ». Le format varie selon la
# version thermo_pw ; on aligne sur 7.x (juin 2021 — ug.1.5.0).
#
# Retour : ``dict[str, Any]`` avec :
#   * clé canonique minuscule (``piezoelectric_tensor_C_per_m2``)
#   * sous-clés : ``raw_value`` (scaler unique), ``matrix`` (matrice 3×N),
#     ``unit``, ``source_line`` (citation), ``matched_keywords``.
# Toute extraction absente reste ``None`` / liste vide.


def _read_numeric_matrix_after_header(
    text: str,
    header_regex: str,
    *,
    n_rows: int,
    n_cols: int,
) -> tuple[list[list[float]], Optional[str]]:
    """Helper partagé : trouve un titre par regex, lit les ``n_rows`` lignes
    numériques non-vides qui suivent comme matrice ``n_rows × n_cols``.

    Le helper **ignore** les fragiles regex de fin de bloc (``\\n\\n``, ``\\Z``) :
    une fois le titre matché, on prend simplement les ``n_rows`` prochaines
    lignes « compatibles » après.

    Retour : ``(matrix, first_data_line_or_None)``. ``matrix`` est **vide** si
    (a) le titre n'est pas trouvé, OU (b) moins de ``n_rows`` lignes valides
    suivent (strict : un tenseur 3x3 tronqué à 1 ligne ne doit pas induire
    en erreur l'appelant). ``first_data_line_or_None`` est la première ligne
    utilisée ou ``None`` si rien n'a été extrait.
    """
    if not text or not text.strip():
        return [], None
    try:
        match = re.search(header_regex, text)
    except re.error:
        return [], None
    if not match:
        return [], None
    remaining = text[match.end():]
    rows: list[list[float]] = []
    first_data_line: Optional[str] = None
    for ln_raw in remaining.splitlines():
        ln = ln_raw.strip()
        if not ln:
            continue
        # Skip titres secondaires (« 1 2 3 4 5 6 » ligne d'en-tête de table).
        if not re.search(r"[0-9.\-+EeDd]", ln):
            # Une ligne avec seulement des chiffres pourrait quand même contenir
            # des petits positifs — on NE skip PAS systématiquement. Le filtre
            # principal est sur le nombre de tokens numériques ci-dessous.
            toks = ln.split()
            if len([t for t in toks if _qe_float(t) is not None]) < n_cols:
                continue
        toks = ln.split()
        if len(toks) < n_cols:
            continue
        rvals: list[Optional[float]] = [_qe_float(t) for t in toks[:n_cols]]
        if any(v is None for v in rvals):
            continue
        if first_data_line is None:
            first_data_line = ln[:200]
        rows.append([float(v) for v in rvals])
        if len(rows) >= n_rows:
            break
    # Contrat strict : si < n_rows, on retourne [] pour ne pas induire l'appelant
    # en erreur (un tenseur 3×3 partiel n'a pas de sens physique)).
    if len(rows) < n_rows:
        return [], None
    return rows, first_data_line


def parse_piezoelectric_tensor(
    text: str,
) -> dict[str, Any]:
    """Tenseur piézoélectrique ``e_ijk`` (C/m²) au format Voigt 3×6 ou 6×6.

    Patterns tolérés (thermo_pw 7.x) :
      * ``piezoelectric tensor (C/m^2)`` → matrice 3 lignes × 6 colonnes.
      * ``d_ij = …`` (constantes piézo charges) → 3×6 à 6×6.
      * ``e_33 = 4.52`` (composante diagonale isolée).
    Renvoie ``matrix`` (liste de 3 listes de 6 nombres) + ``unit="C/m**2"`` +
    ``max_component_C_per_m2`` (composante max en valeur absolue).
    """
    out: dict[str, Any] = {
        "matrix": None,
        "unit": None,
        "matched_keywords": [],
        "source_line": None,
        "max_component_C_per_m2": None,
    }
    if not text or not text.strip():
        return out
    # 1. Titre « piezoelectric tensor (C/m^2) » → 3 lignes × 6 chiffres.
    rows, first_line = _read_numeric_matrix_after_header(
        text,
        r"(?is)piezoelectric\s+tensor\s*(?:\([^)]*\))?",
        n_rows=3,
        n_cols=6,
    )
    if len(rows) == 3:
        # Unité : on relocalise le sous-string du titre piézo pour capter
        # ``(C/m**2)`` dans un contexte LOCAL — pas ``re.search`` sur TEXT qui
        # ramasserait la première ``(...)`` d'un autre bloc (ex. ``Ps (Hz^-1)``).
        m_title = re.search(
            r"(?is)piezoelectric\s+tensor[^\n]*", text
        )
        m_unit = (
            re.search(r"\(([^)]+)\)", m_title.group(0)) if m_title else None
        )
        out["unit"] = m_unit.group(1).strip() if m_unit else "C/m**2"
        out["matrix"] = rows
        flat = [abs(v) for row in rows for v in row]
        if flat:
            out["max_component_C_per_m2"] = float(max(flat))
        out["matched_keywords"].append("piezoelectric_tensor_matrix_3x6")
        out["source_line"] = first_line
        return out
    # 2. Repli : composantes isolées « e_i_j = … » (notation row_col 1..3 × 1..6).
    #     La notation thermo_pw « e_33 » correspond au tenseur piézo exprimé en
    #     repère Voigt : ligne = index de polarisation (1..3), colonne = index
    #     de déformation (1..6). On supporte DEUX notations :
    #       (a) séparée : « e_3_3 = 4.52 » ou « e 3 3 = 4.52 »
    #       (b) composite 2 chiffres : « e_33 = 4.52 » (i = ix // 10, j = ix % 10).
    inline_two = re.findall(
        r"(?i)(?:e|d)[\s_]*(\d{1,2})[\s_]+(\d{1,2})\s*=\s*"
        r"([+-]?[0-9]*\.?[0-9]+(?:[EeDd][+-]?\d+)?)",
        text,
    )
    if inline_two:
        out["matrix"] = [[None] * 6 for _ in range(3)]
        flat_abs: list[float] = []
        for row_str, col_str, val_str in inline_two:
            try:
                i1 = int(row_str)
                j1 = int(col_str)
                val = float(val_str.replace("D", "E").replace("d", "e"))
            except ValueError:
                continue
            # Mappage : « e_i j » → line i (1..3), col j (1..6) en Voigt.
            if not (1 <= i1 <= 3 and 1 <= j1 <= 6):
                continue
            out["matrix"][i1 - 1][j1 - 1] = val
            flat_abs.append(abs(val))
        if any(any(v is not None for v in row) for row in out["matrix"]):
            out["max_component_C_per_m2"] = max(flat_abs) if flat_abs else None
            out["unit"] = "C/m**2"
            out["matched_keywords"].append("piezoelectric_tensor_inline_components")
            return out
    # Notation composite 2 chiffres : « e_33 = 4.52 » → i = 3, j = 3.
    inline_one = re.findall(
        r"(?i)(?:e|d)[\s_]*(\d{2})\s*=\s*"
        r"([+-]?[0-9]*\.?[0-9]+(?:[EeDd][+-]?\d+)?)",
        text,
    )
    if inline_one:
        out["matrix"] = [[None] * 6 for _ in range(3)]
        flat_abs: list[float] = []
        for ix_str, val_str in inline_one:
            try:
                ix = int(ix_str)
                val = float(val_str.replace("D", "E").replace("d", "e"))
            except ValueError:
                continue
            if not (11 <= ix <= 36):
                continue
            i1 = ix // 10
            j1 = ix % 10
            if not (1 <= i1 <= 3 and 1 <= j1 <= 6):
                continue
            out["matrix"][i1 - 1][j1 - 1] = val
            flat_abs.append(abs(val))
        if any(any(v is not None for v in row) for row in out["matrix"]):
            out["max_component_C_per_m2"] = max(flat_abs) if flat_abs else None
            out["unit"] = "C/m**2"
            out["matched_keywords"].append(
                "piezoelectric_tensor_inline_components"
            )
            return out
    return out


def parse_scf_dielectric(text: str) -> dict[str, Any]:
    """Constante diélectrique statique ε_∞ (tenseur 3×3 symétrique, sans unité).

    Patterns tolérés :
      * ``dielectric constant (high frequency)`` → matrice 3×3 symétrique.
      * ``epsilon_infinity`` → matrice 3×3.
      * ``static dielectric constant`` → ε_static (DFPT phonon inclus).
    Renvoie ``matrix`` (3×3) + ``tracé`` (« diagonal_average = (eps_xx+eps_yy+eps_zz)/3 »).
    """
    out: dict[str, Any] = {
        "matrix": None,
        "average": None,
        "anisotropy": None,
        "unit": "adimensional",
        "matched_keywords": [],
        "source_line": None,
    }
    if not text or not text.strip():
        return out
    header_re = re.compile(
        r"(?is)(?:dielectric\s+constant|static\s+dielectric\s+constant|epsilon[\s_]*(?:infinity|infinity_tensor))\s*(?:\([^)]*\))?\s*[=:]*\s*\n*(.+?)(?:\n\n|\n\s*\n\s*[A-Z]|$)",
    )
    mhead = header_re.search(text)
    if not mhead:
        return out
    block = mhead.group(1)
    rows: list[list[Optional[float]]] = []
    for ln_raw in block.splitlines():
        ln = ln_raw.strip()
        if not ln:
            continue
        if not re.search(r"[0-9.\-+EeDd]", ln):
            continue
        toks = ln.split()
        if len(toks) < 3:
            continue
        rvals: list[Optional[float]] = []
        for t in toks[:3]:
            fv = _qe_float(t)
            rvals.append(fv)
        if any(v is None for v in rvals):
            continue
        rows.append([float(v) for v in rvals])
        if len(rows) == 3:
            break
    if len(rows) != 3:
        return out
    # Symétrise : on lit souvent le tenseur symétrique mais on prend la
    # moyenne deux-coordonnées si l'asymétrie résiduelle est légère.
    sym: list[list[float]] = [[rows[i][j] for j in range(3)] for i in range(3)]
    out["matrix"] = sym
    out["matched_keywords"].append("scf_dielectric_tensor_3x3")
    out["source_line"] = block.splitlines()[0][:200]
    diag_vals = [sym[i][i] for i in range(3)]
    finite = [abs(v) for v in diag_vals if v > 0]
    if finite:
        out["average"] = float(sum(diag_vals) / 3.0)
        if len(finite) == 3:
            amax = max(finite)
            amin = min(finite)
            out["anisotropy"] = float(amax / amin) if amin > 0 else None
    return out


def parse_magnetic_susceptibility(text: str) -> dict[str, Any]:
    """Susceptibilité magnétique χ — scalaire principale + tenseur 3×3 optionnel.

    Patterns tolérés :
      * ``magnetic susceptibility = …`` (scalaire, unités SI).
      * ``chi_ij = …`` (tenseur 3×3 symétrique).
    Renvoie ``scalar_SI`` + ``tensor_SI`` (3×3 si dispo) + ``unit``.
    """
    out: dict[str, Any] = {
        "scalar_SI": None,
        "tensor_SI": None,
        "unit": None,
        "matched_keywords": [],
        "source_line": None,
    }
    if not text or not text.strip():
        return out
    # Scalaire direct : « magnetic susceptibility = … »
    m_scalar = re.search(
        r"(?i)magnetic\s+susceptibility\s*[:=]\s*([+-]?[0-9]*\.?[0-9]+(?:[EeDd][+-]?\d+)?)\s*(SI|[a-zA-Z\^\*/\-]+)?",
        text,
    )
    if m_scalar:
        try:
            out["scalar_SI"] = float(m_scalar.group(1).replace("D", "E").replace("d", "e"))
        except ValueError:
            pass
        out["unit"] = (m_scalar.group(2) or "SI").strip()
        out["matched_keywords"].append("magnetic_susceptibility_scalar")
        out["source_line"] = m_scalar.group(0)[:200]
        return out
    # Tenseur chi_ij : 3 lignes × 3 colonnes après le titre.
    rows, first_line = _read_numeric_matrix_after_header(
        text,
        r"(?i)(?:chi[\s_]*ij|chi[\s_]*tensor|magnetic[\s_]*susceptibility[\s_]*tensor)",
        n_rows=3,
        n_cols=3,
    )
    if len(rows) == 3:
        # Trace moyenne pour exposition UI simple. χ peut être négatif pour
        # les diamagnétiques (Au / Cu / graphite) — pas de rejet.
        tr = rows[0][0] + rows[1][1] + rows[2][2]
        out["tensor_SI"] = rows
        out["scalar_SI"] = float(tr / 3.0)
        out["unit"] = "SI"
        out["matched_keywords"].append("magnetic_susceptibility_tensor_3x3")
        out["source_line"] = first_line
        return out
    return out


def parse_magnetoelectric_tensor(text: str) -> dict[str, Any]:
    """Tenseur magnétoélectrique α_ij (matrice 3×3, unités adimensionnelles ou ps/m).

    Patterns tolérés :
      * ``magnetoelectric tensor (alpha_ij)`` → matrice 3×3.
      * ``alpha_ij = …`` (composantes inline).
    Renvoie ``matrix`` (3×3) + ``max_abs`` (force du couplage).
    """
    out: dict[str, Any] = {
        "matrix": None,
        "unit": "ps/m",
        "max_abs": None,
        "matched_keywords": [],
        "source_line": None,
    }
    if not text or not text.strip():
        return out
    rows, first_line = _read_numeric_matrix_after_header(
        text,
        r"(?is)(?:magnetoelectric\s+tensor|magnetoelectric\s+coupling)\s*(?:\([^)]*\))?",
        n_rows=3,
        n_cols=3,
    )
    if len(rows) == 3:
        # alpha_ij peut être nul ou négatif (signature physique) — on n'impose
        # aucun filtre. On ne garde que la valeur absolue pour ``max_abs``.
        flat = [abs(v) for row in rows for v in row]
        out["matrix"] = rows
        out["unit"] = "ps/m"
        out["max_abs"] = float(max(flat)) if flat else None
        out["matched_keywords"].append("magnetoelectric_tensor_3x3")
        out["source_line"] = first_line
        return out
    # Repli : composantes alpha_ij isolées (notation thermo_pw 7.x).
    # Notation composite 2 chiffres : ``alpha_11=1.0`` → i=1, j=1.
    inline = re.findall(
        r"(?i)alpha[\s_]*(\d{2})\s*=\s*([+-]?[0-9]*\.?[0-9]+(?:[EeDd][+-]?\d+)?)",
        text,
    )
    if inline:
        out["matrix"] = [[None] * 3 for _ in range(3)]
        flat = []
        for ix_str, val_str in inline:
            try:
                ix = int(ix_str)
                val = float(val_str.replace("D", "E").replace("d", "e"))
            except ValueError:
                continue
            if not (11 <= ix <= 33):
                continue
            # ix composite ``ij`` : on extrait i = ix // 10, j = ix % 10
            # (convention thermo_pw identique à celle du tenseur piézo).
            i1 = ix // 10
            j1 = ix % 10
            if not (1 <= i1 <= 3 and 1 <= j1 <= 3):
                continue
            out["matrix"][i1 - 1][j1 - 1] = val
            flat.append(abs(val))
        if any(any(v is not None for v in row) for row in out["matrix"]):
            out["max_abs"] = max(flat) if flat else None
            out["matched_keywords"].append("magnetoelectric_tensor_inline_components")
            return out
    return out


def parse_plot_bz_artifact(work_dir: Path) -> dict[str, Any]:
    """Vérifie la présence des artefacts BZ_plot.ps.gz + BZ.txt pour ``what=plot_bz``.

    Pas de parsing textuel (le PostScript gzippé n'est pas lisible directement) ;
    on expose juste les chemins relatifs des artefacts effectivement présents.
    """
    work_dir = Path(work_dir).resolve()
    out: dict[str, Any] = {
        "BZ_plot_ps_gz": None,
        "BZ_txt": None,
        "matched_keywords": [],
    }
    seen: set[str] = set()
    candidates = ["BZ_plot.ps.gz", "BZ.txt"]
    for rel in candidates:
        matches: list[Path] = []
        for pattern in (rel, f"*/{rel}"):
            for p in work_dir.glob(pattern):
                if p.is_file() and p.resolve() not in seen:
                    seen.add(p.resolve())
                    matches.append(p)
        if not matches:
            continue
        # Tri par mtime desc : le plus récent = résultat thermo_pw.x de la run.
        matches.sort(key=lambda p: p.stat().st_mtime_ns, reverse=True)
        relp = matches[0].resolve().relative_to(work_dir).as_posix()
        if rel == "BZ_plot.ps.gz":
            out["BZ_plot_ps_gz"] = relp
            out["matched_keywords"].append("BZ_plot_ps_gz")
        else:
            out["BZ_txt"] = relp
            out["matched_keywords"].append("BZ_txt")
    return out


def parse_thermo_pw_p5_extra_log(
    what: str,
    text: str,
    *,
    work_dir: Optional[Path] = None,
) -> dict[str, Any]:
    """Dispatcher pour les journaux ``thermo_pw_<what>.out`` (P5 extras).

    Sélectionne le parser approprié via ``what`` (whitelist stricte).
    Toute erreur / ``what=`` inconnu renvoie ``{}`` (le pipeline reste
    tolérant — cf. ``pipeline._run_thermo_extras``).
    """
    if not what or not isinstance(what, str):
        return {}
    w = what.strip().lower()
    if w == "piezoelectric_tensor":
        return parse_piezoelectric_tensor(text)
    if w == "scf_dielectric":
        return parse_scf_dielectric(text)
    if w == "magnetic_susceptibility":
        return parse_magnetic_susceptibility(text)
    if w == "magnetoelectric_tensor":
        return parse_magnetoelectric_tensor(text)
    if w == "plot_bz":
        if work_dir is None:
            return {}
        return parse_plot_bz_artifact(work_dir)
    # Pas de warning stdout ici : caller (``pipeline._run_thermo_extras``)
    # journalise déjà via ``self._append_log`` et le ``what=`` est validé par
    # la whitelist ``valid_thermo_pw_key`` plus haut. On ne double pas le log.
    return {}


_MAX_ARTIFACT_TEXT_BYTES = 640_000


def _empty_scalar_shell() -> dict[str, Any]:
    """Structure minimale compatible avec ``renderElaSummary`` avant complétion parse."""
    return {
        "debye_temperature_K": None,
        "bulk_modulus_GPa": None,
        "bulk_modulus_pressure_derivative": None,
        "young_modulus_GPa": None,
        "shear_modulus_GPa": None,
        "poisson_ratio": None,
        "elastic_constants_GPa": [],
        "elastic_independent_GPa": None,
        "elastic_cubic_independent_GPa": None,
        "thermo_pw_abort_hint": None,
        "f_iso_Ry": None,
        "lif_F_vs_T_Ry": [],
        "matched_keywords": [],
        "tail_preview": "",
    }


def _safe_relpath_under_work_dir(work_dir: Path, rel: str) -> tuple[Optional[Path], Optional[str]]:
    rel = rel.strip().replace("\\", "/").lstrip("/")
    if not rel:
        return None, "chemin vide"
    if ".." in rel.split("/"):
        return None, "chemin relatif invalide (..)"
    p = (work_dir / rel).resolve()
    try:
        p.relative_to(work_dir.resolve())
    except ValueError:
        return None, "chemin hors du dossier du run"
    return p, None


def _primary_source_is_elastic_matrix_file(rel: str) -> bool:
    """Fichiers matrice C_ij type ``output_el_cons*.dat*`` — pas les journaux ``.out`` / ``.log``."""
    low = rel.lower().strip()
    if low.endswith(".out") or low.endswith(".log"):
        return False
    if low.endswith(".dat") or ".dat." in low:
        return True
    if "output_el_cons" in low or "el_cons" in low:
        return True
    return False


def _read_utf8_file_bounded(path: Path, *, max_bytes: int) -> tuple[str, Optional[str]]:
    try:
        sz = path.stat().st_size
    except OSError as ex:
        return "", str(ex)
    if sz > max_bytes:
        return "", f"fichier trop volumineux ({sz} octets ; max {max_bytes})"
    try:
        return path.read_text(encoding="utf-8", errors="replace"), None
    except OSError as ex:
        return "", str(ex)


def _merge_supplement_from_thermo_pw_run_out(parsed: dict[str, Any], work_dir: Path) -> None:
    """Complète scalaires thermo/mécano depuis ``thermo_pw_run.out`` si le fichier analysé était autre."""
    main = work_dir / "thermo_pw_run.out"
    if not main.is_file():
        return
    try:
        text, _n = _read_log_tail_for_parse(main.resolve())
    except OSError:
        return
    sup = parse_thermo_pw_log(text)
    mk = parsed.setdefault("matched_keywords", [])
    for k in _SCALAR_KEYS_HEAD_MERGE:
        if parsed.get(k) is None and sup.get(k) is not None:
            parsed[k] = sup[k]
            tag = k + "_from_main_thermo_pw_run_out"
            if tag not in mk:
                mk.append(tag)
    if not parsed.get("thermo_pw_abort_hint") and sup.get("thermo_pw_abort_hint"):
        parsed["thermo_pw_abort_hint"] = sup["thermo_pw_abort_hint"]
        if "thermo_pw_abort_hint_supplement" not in mk:
            mk.append("thermo_pw_abort_hint_supplement")


def _merge_head_scalar_fallback(parsed: dict[str, Any], log_path: Path) -> None:
    """Complète B, B′, T_D, modules depuis le début du journal si absents de la fenêtre « queue »."""
    if not any(parsed.get(k) is None for k in _SCALAR_KEYS_HEAD_MERGE):
        return
    head_txt = _read_log_head_for_parse(log_path.resolve(), max_chars=_PARSE_WINDOW_CHARS)
    if not head_txt.strip():
        return
    head_parsed = parse_thermo_pw_log(head_txt)
    mk = parsed.setdefault("matched_keywords", [])
    for k in _SCALAR_KEYS_HEAD_MERGE:
        if parsed.get(k) is None and head_parsed.get(k) is not None:
            parsed[k] = head_parsed[k]
            tag = f"{k}_head_fallback"
            if tag not in mk:
                mk.append(tag)


def parse_thermo_pw_log(text: str) -> dict[str, Any]:
    """Repères regex — adapter au besoin selon vos journaux réels."""
    if not text or not text.strip():
        return {"error": "journal vide"}

    tail = text[-_PARSE_WINDOW_CHARS:] if len(text) > _PARSE_WINDOW_CHARS else text
    lines = [ln.strip() for ln in tail.splitlines() if ln.strip()]
    out: dict[str, Any] = {
        "debye_temperature_K": None,
        "bulk_modulus_GPa": None,
        "bulk_modulus_pressure_derivative": None,
        "young_modulus_GPa": None,
        "shear_modulus_GPa": None,
        "poisson_ratio": None,
        "elastic_constants_GPa": [],
        "elastic_independent_GPa": None,
        "thermo_pw_abort_hint": None,
        "matched_keywords": [],
        "tail_preview": tail[-8000:] if len(tail) > 8000 else tail,
    }

    # Température de Debye — formulations thermo_pw / QE variables (dernière occurrence dans la fenêtre).
    for pat in (
        r"(?i)Debye\s+temperature\s+(?:is\s*)?(?:[:=]|[\s]{2,})\s*([0-9.E+-]+)",
        r"(?i)Debye\s+(?:temperature|temp\.?)\s*[:\s=]+\(?\s*([0-9.E+-]+)\s*\)?\s*K?",
        r"(?i)The\s+Debye\s+temperature\s+(?:is\s*)?(?:[:=]|[\s]{2,})\s*([0-9.E+-]+)",
        r"(?i)Deb(?:ye)?\.?\s*(?:temperature|temp)\s*[:\s=]+\s*([0-9.E+-]+)",
        r"(?i)T\s*_?\s*[Dd]eb(?:ye)?\s*[:\s=]+\(?\s*([0-9.E+-]+)\s*\)?\s*[K]?",
        r"(?i)temperature\s+of\s+Debye\s*[:\s]+([0-9.E+-]+)",
        r"(?i)Theta\s+D\s*[:\s=]+\s*([0-9.E+-]+)\s*[K]?",
        r"(?i)\btheta\s*_?\s*[Dd]\s*[=\:]+\s*([0-9.E+-]+)\s*K?",
    ):
        matches = list(re.finditer(pat, tail))
        if not matches:
            continue
        try:
            out["debye_temperature_K"] = float(matches[-1].group(1))
            if "debye_temperature_K" not in out["matched_keywords"]:
                out["matched_keywords"].append("debye_temperature_K")
            break
        except ValueError:
            continue

    voigt_blk = None
    mvo = re.search(
        r"(?is)Voigt\s+approximation\s*:(.*?)(?=Reuss\s+approximation|Voigt-Reuss-Hill|$)",
        tail[-200000:] if len(tail) > 200000 else tail,
    )
    if mvo:
        voigt_blk = mvo.group(1)

    # Arrêt explicite (ex. ibrav=0) avant tout calcul physique utile — souvent JOB DONE tout de même.
    if re.search(r"(?is)The\s+code\s+will\s+now\s+stop,\s+modify\s+the\s+pw\.x\s+input", tail):
        if re.search(r"\bibrav\s*=\s*0\b", tail) and re.search(
            r"(?is)please\s+use:",
            tail,
        ):
            ih = (
                "Arrêt thermo_pw : le pw.x lu utilise ibrav=0 alors que cette étape impose une maille "
                "reconnue par QE (ibrav, celldm). Fiabilité : corriger l’entrée PW avec les valeurs "
                "suggérées en sortie (ibrav, celldm, positions). — Variables optionnelles documentées dans "
                "le user guide (§ ibrav=0 / thermo_pw) : find_ibrav et continue_zero_ibrav ; elles "
                "s’ajoutent dans thermo_control, namelist &INPUT_THERMO, même si votre thermo_control "
                "minimal (ou généré par l’outil) ne les inclut pas — ex. « find_ibrav = .true. », ou "
                "« continue_zero_ibrav = .true. » (déconseillé hors super-maille). Aucun calcul C_ij "
                "n’a été exécuté."
            )
        else:
            ih = (
                "thermo_pw s’est arrêté après « The code will now stop, modify the pw.x input » — corriger "
                "l’entrée PW ou les options thermo_control. Aucune matrice C_ij dans ce journal."
            )
        out["thermo_pw_abort_hint"] = ih
        out["matched_keywords"].append("thermo_pw_abort_hint")

    def _mods_from_block(block: Optional[str]) -> None:
        if not block:
            return
        for label, key, conv in (
            (r"(?i)bulk\s+modulus\s*B\s*=\s*([0-9.E+-]+)\s*kbar", "bulk_modulus_GPa", _KBAR_TO_GPA),
            (r"(?i)Young\s+modulus\s+E\s*=\s*([0-9.E+-]+)\s*kbar", "young_modulus_GPa", _KBAR_TO_GPA),
            (r"(?i)shear\s+modulus\s*G\s*=\s*([0-9.E+-]+)\s*kbar", "shear_modulus_GPa", _KBAR_TO_GPA),
            (r"(?i)Poisson\s+Ratio\s+n\s*=\s*([0-9.E+-]+)", "poisson_ratio", 1.0),
        ):
            m = re.search(label, block)
            if not m:
                continue
            try:
                val = float(m.group(1)) * conv
                out[key] = val  # type: ignore[literal-required]
                if key not in out["matched_keywords"]:
                    out["matched_keywords"].append(key)
            except ValueError:
                pass

    _mods_from_block(voigt_blk)

    _bm_pat = re.compile(r"(?is)\b(?:The\s+)?bulk\s+modulus\s+is\s*:\s*([0-9.E+-]+)\s*kbar")
    _bm_prim_pat = re.compile(
        r"(?is)\bThe\s+pressure\s+derivative\s+of\s+the\s+bulk\s+modulus\s+is\s*:\s*([0-9.E+-]+)"
    )

    def _take_last(regex: re.Pattern[str], text_blob: str) -> Optional[float]:
        matches = list(regex.finditer(text_blob))
        if not matches:
            return None
        try:
            return float(matches[-1].group(1))
        except ValueError:
            return None

    if out["bulk_modulus_GPa"] is None:
        v = _take_last(_bm_pat, tail)
        if v is not None:
            out["bulk_modulus_GPa"] = v * _KBAR_TO_GPA
            out["matched_keywords"].append("bulk_modulus_GPa")

    vp = _take_last(_bm_prim_pat, tail)
    if vp is not None:
        out["bulk_modulus_pressure_derivative"] = vp
        if "bulk_modulus_pressure_derivative" not in out["matched_keywords"]:
            out["matched_keywords"].append("bulk_modulus_pressure_derivative")

    if out["bulk_modulus_GPa"] is None:
        for label, key in (
            (r"(?i)bulk\s+modulus\s*B\s*[:\s=]+\(?\s*([0-9.E+-]+)\s*(GPa)", "bulk_modulus_GPa"),
            (r"(?i)Young(?:'?s)?\s+modulus\s+E\s*[:\s=]+\(?\s*([0-9.E+-]+)\s*(GPa)", "young_modulus_GPa"),
            (r"(?i)shear\s+modulus\s*G\s*[:\s=]+\(?\s*([0-9.E+-]+)\s*(GPa)", "shear_modulus_GPa"),
        ):
            m = re.search(label, tail)
            if m:
                try:
                    out[key] = float(m.group(1))  # type: ignore[literal-required]
                    out["matched_keywords"].append(key)
                except ValueError:
                    pass
    if out["poisson_ratio"] is None:
        m = re.search(
            r"(?i)Poisson(?:'?s)?\s+ratio\s*n\s*=\s*([0-9.E+-]+)", tail[-20000:]
        )
        if m:
            try:
                out["poisson_ratio"] = float(m.group(1))
                out["matched_keywords"].append("poisson_ratio")
            except ValueError:
                pass

    # LIF (Local Isothermal Free Energy) — thermo_pw ``what=qha_lif``.
    # Trois formulations reconnues (thermo_pw 7.x — adapter si besoin sur journal réel) :
    #   A) ``Local Isothermal Free Energy = -56.12345 Ry``
    #   B) ``… T = 300 K = -56.12345 Ry`` (F vs T noté sur la même ligne)
    #   C) ``F_iso(T=300K) = -56.12345 Ry`` (notation compacte)
    last_fiso: Optional[float] = None
    fiso_with_t: list[tuple[float, float]] = []
    _LIF_RX_NO_T = re.compile(
        r"(?i)\bLocal\s+[Ii]sothermal\s+[Ff]ree\s+[Ee]nergy\b"
        r"(?![^=\n]*?\bT\s*=)[^=\n]*?[:=]\s*"
        r"([+-]?[0-9]*\.?[0-9]+(?:[EeDd][+-]?\d+)?)\s*(?:Ry|ry)\b"
    )
    _LIF_RX_WITH_T = re.compile(
        r"(?i)\bLocal\s+[Ii]sothermal\s+[Ff]ree\s+[Ee]nergy\b"
        r"[^=\n]*?\bT\s*=\s*([+-]?[0-9]*\.?[0-9]+)\s*K\s*[:=]?\s*"
        r"([+-]?[0-9]*\.?[0-9]+(?:[EeDd][+-]?\d+)?)\s*(?:Ry|ry)\b"
    )
    _LIF_RX_FISO_T = re.compile(
        r"(?i)\bF\s*[-_]\s*iso\s*\(\s*T\s*=\s*([+-]?[0-9]*\.?[0-9]+)\s*K?\s*\)"
        r"\s*[:=]?\s*([+-]?[0-9]*\.?[0-9]+(?:[EeDd][+-]?\d+)?)\s*(?:Ry|ry)\b"
    )
    for _m in _LIF_RX_NO_T.finditer(tail):
        try:
            last_fiso = float(_m.group(1))
        except ValueError:
            pass
    for _m in _LIF_RX_WITH_T.finditer(tail):
        try:
            tk = float(_m.group(1))
            fk = float(_m.group(2))
            fiso_with_t.append((tk, fk))
            last_fiso = fk
        except ValueError:
            pass
    for _m in _LIF_RX_FISO_T.finditer(tail):
        try:
            tk = float(_m.group(1))
            fk = float(_m.group(2))
            if not any(abs(tk - t) < 1e-9 for t, _ in fiso_with_t):
                fiso_with_t.append((tk, fk))
            last_fiso = fk
        except ValueError:
            pass
    if last_fiso is not None:
        out["f_iso_Ry"] = last_fiso
        if "f_iso_Ry" not in out["matched_keywords"]:
            out["matched_keywords"].append("f_iso_Ry")
    if fiso_with_t:
        out["lif_F_vs_T_Ry"] = sorted(fiso_with_t, key=lambda p: p[0])
        if "lif_F_vs_T_Ry" not in out["matched_keywords"]:
            out["matched_keywords"].append("lif_F_vs_T_Ry")

    seen_c: set[tuple[int, int]] = set()
    for rx in _CIJ_TITLE_RES:
        mcij = rx.search(tail)
        if not mcij:
            continue
        sub = tail[mcij.start() : mcij.start() + 14_000]
        ecs_rows = _parse_elastic_constants_voigt_kbar_after_title(sub)
        if not ecs_rows:
            continue
        for row in ecs_rows:
            key = (int(row["i"]), int(row["j"]))
            if key in seen_c:
                continue
            seen_c.add(key)
            out["elastic_constants_GPa"].append(row)
        break

    filled_from_table = len(seen_c) > 0

    elastic_context_fallback = (
        re.search(r"(?i)elastic\s+constants?", tail) is not None
        or re.search(
            r"(?is)scf_elastic_constants|mur_lc_elastic_constants|elastic_constants_geo|mur_lc_t_elastic_constants",
            tail,
        )
        is not None
        or voigt_blk is not None
    )

    # Fallback lignes « C_ij = … GPa » / « … kbar » hors table : éviter EOS pur si pas de contexte élasticité.
    if not filled_from_table and elastic_context_fallback:
        c_pat_gpa = re.compile(
            r"(?i)C\s*_?\s*(\d+)\s*_?\s*(\d+)\s*[=:, ]\s*([0-9.E+-Dd]+)\s+(?:GPa)"
        )
        seen = seen_c
        for ln in lines[-1200:]:
            for m in c_pat_gpa.finditer(ln):
                try:
                    i, j = int(m.group(1)), int(m.group(2))
                    fv = _qe_float(m.group(3))
                except (ValueError, IndexError):
                    continue
                if fv is None:
                    continue
                if i < 1 or i > 6 or j < 1 or j > 6:
                    continue
                key = (i, j)
                if key not in seen:
                    seen.add(key)
                    out["elastic_constants_GPa"].append(
                        {"i": i, "j": j, "value_GPa": fv, "line": ln[:200]}
                    )
        filled_from_table = len(seen_c) > 0

    if not filled_from_table and elastic_context_fallback:
        c_pat_kb = re.compile(
            r"(?i)C\s*_?\s*(\d+)\s*_?\s*(\d+)\s*[=:, ]\s*([0-9.E+-Dd]+)\s+kbar"
        )
        seen = seen_c
        for ln in lines[-1200:]:
            for m in c_pat_kb.finditer(ln):
                try:
                    i, j = int(m.group(1)), int(m.group(2))
                    fv = _qe_float(m.group(3))
                except (ValueError, IndexError):
                    continue
                if fv is None:
                    continue
                if i < 1 or i > 6 or j < 1 or j > 6:
                    continue
                key = (i, j)
                if key not in seen:
                    seen.add(key)
                    out["elastic_constants_GPa"].append(
                        {
                            "i": i,
                            "j": j,
                            "value_GPa": fv * _KBAR_TO_GPA,
                            "line": ln[:200],
                        }
                    )

    ei = _infer_elastic_independent(out["elastic_constants_GPa"], tail)
    if ei is not None:
        out["elastic_independent_GPa"] = ei
        out["matched_keywords"].append("elastic_independent_GPa")
        if ei.get("system") == "cubic_m3m_approx":
            c = ei.get("constants_GPa") or {}
            if "C11_GPa" in c and "C12_GPa" in c and "C44_GPa" in c:
                out["elastic_cubic_independent_GPa"] = {
                    "C11_GPa": c["C11_GPa"],
                    "C12_GPa": c["C12_GPa"],
                    "C44_GPa": c["C44_GPa"],
                }

    if out["elastic_constants_GPa"]:
        out["matched_keywords"].append("elastic_constants_GPa")

    return out


def _merge_elastic_scan_into_parsed(
    parsed: dict[str, Any], src: dict[str, Any], infer_blob: str
) -> None:
    """Complète parsed avec le bloc élasticité issu d’un second scan (ex. préfixe du journal)."""
    if not _elastic_constants_nonempty(src):
        return
    parsed["elastic_constants_GPa"] = list(src["elastic_constants_GPa"])
    ei = src.get("elastic_independent_GPa")
    if ei is not None:
        parsed["elastic_independent_GPa"] = ei
    ec = src.get("elastic_cubic_independent_GPa")
    if ec:
        parsed["elastic_cubic_independent_GPa"] = ec
    _apply_elastic_derivatives_inplace(parsed, infer_blob)
    mk = parsed.setdefault("matched_keywords", [])
    for kw in (
        "elastic_constants_GPa",
        "elastic_independent_GPa",
        "elastic_cubic_independent_GPa",
    ):
        if kw in src.get("matched_keywords", []) and kw not in mk:
            mk.append(kw)


def _read_log_tail_for_parse(log_path: Path) -> tuple[str, int]:
    try:
        size = log_path.stat().st_size
    except OSError as ex:
        raise OSError(ex) from ex

    buf = _TPW_LOG_BUF_BYTES
    head_max = _THERMO_LOG_MAX_TAIL_READ_BYTES

    if size <= head_max:
        txt = log_path.read_text(encoding="utf-8", errors="replace")
        return txt, len(txt)

    start = max(0, size - head_max)
    with log_path.open("rb") as f:
        f.seek(start)
        raw = f.read()

    txt = raw.decode("utf-8", errors="replace")
    if start > 0:
        nl = txt.find("\n")
        if nl >= 0:
            txt = txt[nl + 1 :]

    if len(txt) > buf:
        txt = txt[-buf:]

    return txt, size


def parse_work_dir_thermo_log(
    work_dir: Path,
    *,
    primary_log_relpath: Optional[str] = None,
) -> dict[str, Any]:
    work_dir = wf1_resolve_dir_containing_thermo_log(Path(work_dir))
    inventory = build_result_file_inventory(work_dir)

    common_meta: dict[str, Any] = {
        "work_dir": str(work_dir),
        "result_files": inventory,
        "parse_revision": THERMO_PW_OUT_PARSE_REVISION,
    }

    raw_rel = (primary_log_relpath or "").strip().replace("\\", "/")

    # --- Matrice élastique depuis un fichier dédié (.dat, output_el_cons*.dat*, …)
    if raw_rel and _primary_source_is_elastic_matrix_file(raw_rel):
        art_path, err_rel = _safe_relpath_under_work_dir(work_dir, raw_rel)
        if err_rel:
            return {**common_meta, "error": err_rel}
        resolved_from_fallback: Optional[str] = None
        if art_path is None or not art_path.is_file():
            # Ex. ``mur_lc_t`` écrit souvent ``elastic_constants/output_el_cons.dat.g*`` et pas
            # ``energy_files/output_el_cons.dat`` : repli comme pour l’analyse du journal seul.
            merged_fb = merge_elastic_from_output_el_cons_files(work_dir)
            if merged_fb:
                art_path = work_dir / merged_fb["source_relpath"]
                resolved_from_fallback = merged_fb["source_relpath"]
            else:
                return {
                    **common_meta,
                    "error": f"fichier absent : {work_dir / raw_rel}",
                    "path_checked": str(work_dir / raw_rel),
                }
        body, err_read = _read_utf8_file_bounded(art_path, max_bytes=_MAX_ARTIFACT_TEXT_BYTES)
        if err_read:
            return {**common_meta, "error": err_read}
        ecs_try, ok_ff = _parse_elastic_from_freeform_text(body)
        ecs = ecs_try
        ok_el = ok_ff
        if not ok_el:
            ecs_flat, ok_fl = _try_parse_flat_kbar_voigt_6x6(body)
            ecs = ecs_flat
            ok_el = ok_fl
        parsed: dict[str, Any] = {**_empty_scalar_shell(), **common_meta}
        parsed["parse_primary_source"] = raw_rel
        parsed["log_path"] = str(art_path.resolve())
        parsed["elastic_parse_source_file"] = (
            resolved_from_fallback if resolved_from_fallback else raw_rel
        )
        if resolved_from_fallback:
            parsed["parse_note"] = (
                f"Fichier demandé absent ({raw_rel}) ; matrice lue depuis {resolved_from_fallback}."
            )
        if ok_el and ecs:
            parsed["elastic_constants_GPa"] = list(ecs)
            parsed.setdefault("matched_keywords", []).append("elastic_constants_GPa")
            infer_blob = parsed.get("tail_preview") if isinstance(parsed.get("tail_preview"), str) else ""
            _apply_elastic_derivatives_inplace(parsed, infer_blob or "")
        else:
            parsed.setdefault("matched_keywords", []).append("elastic_artifact_parse_failed")
        _merge_supplement_from_thermo_pw_run_out(parsed, work_dir)
        main_log = work_dir / "thermo_pw_run.out"
        if main_log.is_file():
            _merge_head_scalar_fallback(parsed, main_log.resolve())
        ecs_list_a = parsed.get("elastic_constants_GPa")
        if not (isinstance(ecs_list_a, list) and ecs_list_a):
            merged_a = merge_elastic_from_output_el_cons_files(work_dir)
            if merged_a:
                parsed["elastic_constants_GPa"] = merged_a["elastic_constants_GPa"]
                parsed["elastic_constants_secondary_source"] = merged_a["source_relpath"]
                tail_hint_a = parsed.get("tail_preview")
                infer_a = tail_hint_a if isinstance(tail_hint_a, str) else ""
                _apply_elastic_derivatives_inplace(parsed, infer_a or "")
                parsed.setdefault("matched_keywords", []).append("elastic_constants_secondary_source")
        try:
            parsed["log_char_length"] = art_path.stat().st_size
        except OSError:
            parsed["log_char_length"] = len(body.encode("utf-8", errors="replace"))
        parsed["log_tail_parsed_chars"] = len(body)
        return parsed

    # --- Journal thermo_pw (.out / autre texte) ou défaut racine du run
    if raw_rel:
        log_path_u, err_rel = _safe_relpath_under_work_dir(work_dir, raw_rel)
        if err_rel:
            return {**common_meta, "error": err_rel}
        if log_path_u is None or not log_path_u.is_file():
            return {
                **common_meta,
                "error": f"fichier absent : {work_dir / raw_rel}",
                "path_checked": str(work_dir / raw_rel),
            }
        log_path = log_path_u
        parse_primary = raw_rel
    else:
        log_path = work_dir / "thermo_pw_run.out"
        parse_primary = "thermo_pw_run.out"
        if not log_path.is_file():
            payload_nf: dict[str, Any] = {
                "error": f"fichier absent : {log_path}",
                "path_checked": str(log_path),
            }
            payload_nf.update(common_meta)
            return payload_nf

    try:
        text, nbytes = _read_log_tail_for_parse(log_path.resolve())
    except OSError as ex:
        return {**common_meta, "error": str(ex)}
    parsed_j = parse_thermo_pw_log(text)
    parsed_j.update(common_meta)
    parsed_j["parse_primary_source"] = parse_primary
    parsed_j["log_path"] = str(log_path.resolve())

    _merge_head_scalar_fallback(parsed_j, log_path.resolve())

    ecs_list = parsed_j.get("elastic_constants_GPa")
    if not (isinstance(ecs_list, list) and ecs_list):
        merged = merge_elastic_from_output_el_cons_files(work_dir)
        if merged:
            parsed_j["elastic_constants_GPa"] = merged["elastic_constants_GPa"]
            parsed_j["elastic_constants_secondary_source"] = merged["source_relpath"]
            tail_hint = parsed_j.get("tail_preview")
            infer_blob = tail_hint if isinstance(tail_hint, str) else text[-8000:]
            _apply_elastic_derivatives_inplace(parsed_j, infer_blob)
            parsed_j.setdefault("matched_keywords", []).append("elastic_constants_secondary_source")

    if not _elastic_constants_nonempty(parsed_j):
        head_txt = _read_log_head_for_parse(
            log_path.resolve(), max_chars=_PARSE_WINDOW_CHARS
        )
        if head_txt.strip():
            head_parsed = parse_thermo_pw_log(head_txt)
            if _elastic_constants_nonempty(head_parsed):
                infer_blob = (
                    head_txt[-8000:] if len(head_txt) > 8000 else head_txt
                )
                _merge_elastic_scan_into_parsed(parsed_j, head_parsed, infer_blob)
                mk = parsed_j.setdefault("matched_keywords", [])
                if "elastic_constants_head_fallback" not in mk:
                    mk.append("elastic_constants_head_fallback")

    parsed_j["log_char_length"] = nbytes
    parsed_j["log_tail_parsed_chars"] = len(text)
    return parsed_j

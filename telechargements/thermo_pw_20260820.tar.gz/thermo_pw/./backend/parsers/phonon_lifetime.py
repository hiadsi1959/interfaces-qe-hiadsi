"""
Lecteur des sorties ``thermo_pw.x what='ph_life'`` (refonte juin 2026).

Anciennement ``qha_lif`` (Local Isothermal Free energy QHA). La sémantique
physique est radicalement différente : on ne travaille plus sur l'énergie
libre locale F_iso(T) mais sur les **largeurs de raie anharmoniques** γ(ω)
et les **durées de vie** τ(ω) des modes phononiques (calcul 3-phonons
perturbatif). Les sorties typiques de thermo_pw 7.x (ug.1.5.0+, juin 2021) :

1. ``thermo_pw_run.out`` : section « Phonon lifetime at T = ... K » avec liste
   de ``q-point (..) mode N: τ = 12.345 ps (γ = 0.430 cm^-1)`` + résumé
   « Mean lifetime at T=… ».

2. ``phonon_lifetime.dat`` : matrice en colonnes (fréquence_cm-1, γ_cm-1, τ_ps).
   Variantes : ``phonon_lifetime_T<…>.dat`` (par température),
   ``anhar_files/*.lifetime*`` fichiers sans extension (.dat) tolérés.

3. ``lattice_thermal_conductivity.dat`` / ``kappa_lattice_*.dat`` :
   conductivité thermique du réseau en ``W/(m·K)`` en fonction de T.

4. ``gruneisen.dat`` / ``phonon_dos_T_gruneisen.dat`` : paramètre de
   Grüneisen γ(q,ν) (effet du volume sur ω).

Ce module expose une unique fonction ``parse_phonon_lifetime(work_dir)``
qui combine toutes ces sources et renvoie un ``dict`` plat compatible avec
``PipelineJob._merge_parsed_into_results``.

Format de retour (clés garanties) :
    * ``mean_lifetime_ps``              : float | None
    * ``mean_linewidth_cm-1``           : float | None
    * ``min_lifetime_ps``               : float | None  (mode le plus résistif)
    * ``max_linewidth_cm-1``            : float | None
    * ``max_lifetime_ps``               : float | None
    * ``lattice_kappa_W_mK``            : float | None  (κ réseau ; si data)
    * ``gruneisen_mean``                : float | None  (moyenne q,ν)
    * ``gruneisen_max_abs``             : float | None
    * ``temperature_K_for_summary``     : float | None (T issu de la section)
    * ``n_modes``                       : int >= 0
    * ``source_files``                  : list[str]    (relpaths sous work_dir)
    * ``matched_keywords``              : list[str]
    * ``modes``                         : list[dict]   (head ; ≤30 modes)
    * ``error``                         : str | None

L'interface du parser suit le style des modules déjà présents dans
``backend/parsers/`` — pas de dépendance externe (uniquement stdlib).
"""
from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Any, Optional

# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------


def _qe_float(token: str) -> Optional[float]:
    """Float compatible Fortran D-style."""
    s = str(token).strip().replace(",", ".")
    if not s:
        return None
    try:
        return float(s.replace("D", "E").replace("d", "e"))
    except ValueError:
        return None


def _summarize(values: list[float]) -> dict[str, Optional[float]]:
    """Statistiques de base sur une liste de flottants (None-safe)."""
    if not values:
        return {"min": None, "max": None, "mean": None, "count": 0}
    finite = [v for v in values if v is not None and not (isinstance(v, float) and (math.isnan(v) or math.isinf(v)))]
    if not finite:
        return {"min": None, "max": None, "mean": None, "count": 0}
    return {
        "min": float(min(finite)),
        "max": float(max(finite)),
        "mean": float(sum(finite) / len(finite)),
        "count": int(len(finite)),
    }


# ----------------------------------------------------------------------------
# Parseur journal thermo_pw_run.out — section « Phonon lifetime at T = ... K »
# ----------------------------------------------------------------------------

# Format ligne : γ ET τ présents sur la même ligne : ``q 12/64 mode 3: τ = 12.34 ps, γ = 0.43 cm^-1``
# (NB : un format antérieur où γ était facultatif ``τ = ... (γ = ...)`` a été retiré en juin 2026
# car jamais rencontré sur les thermo_pw 7.x ug.1.5.0+ ; seul le format « both » sert en pratique.)
# ``q 12/64 mode 3: τ = 12.34 ps, γ = 0.43 cm^-1``
_RE_LIFETIME_LINE_BOTH = re.compile(
    r"""
    q[-_ ]?point\s*\(\s*(\d+)\s*/\s*(\d+)\s*\)\s*
    mode\s+(\d+)\s*:?\s*
    (?:τ|tau)\s*[=:]\s*(?P<tau>[-+]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\s*(?P<tunit>ps)?\s*
    [,;\s]+\s*(?:γ|gamma)\s*[=:]\s*(?P<gamma>[-+]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\s*(?P<gunit>cm[-\s]*1|cm-1|cm\^?-1|meV)?
    """,
    re.IGNORECASE | re.VERBOSE,
)

_RE_LIFETIME_HEADER = re.compile(r"(?i)Phonon\s+lifetime\s+at\s+T\s*=\s*([+-]?\d+\.?\d*(?:[EeDd][+-]?\d+)?)\s*K")
_RE_MEAN_LIFETIME = re.compile(r"(?i)Mean\s+lifetime\s+at\s+T\s*=\s*([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\s*K\s*:\s*([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\s*(ps|cm[-\s]*1|cm-1|cm\^?-1|meV)?")
_RE_MEAN_LINEWIDTH = re.compile(r"(?i)Mean\s+linewidth\s+at\s+T\s*=\s*([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\s*K\s*:\s*([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\s*(cm[-\s]*1|cm-1|cm\^?-1|meV|ps)?")
_RE_KAPPA_HEADER = re.compile(r"(?i)(?:lattice|crystal)\s+thermal\s+conductivity\s*(?:[:=]|\s+at\s+T\s*=)\s*([+]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)(?:\s*(W/?(?:\s*m\s*[-·]?\s*K|mK)))?")
_RE_GRUNEISEN_HEADER = re.compile(r"(?i)Gr[uü]neisen\s+parameter\s+(?:is|=|:)\s*([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)")


def _parse_lifetime_lines_tail(text: str) -> dict[str, Any]:
    """Parse une section « Phonon lifetime at T ... » dans un journal texte."""
    out: dict[str, Any] = {
        "modes": [],
        "temperatures_K": [],
        "summary_mean_lifetime_ps": None,
        "summary_mean_linewidth_cm-1": None,
        "max_lifetime_ps": None,
        "max_linewidth_cm-1": None,
        "matched_keywords": [],
    }
    if not text or not text.strip():
        return out

    # 1. Résum é « Mean lifetime / linewidth at T=... K ».
    for m in _RE_MEAN_LIFETIME.finditer(text):
        try:
            t = float(m.group(1).replace("D", "E").replace("d", "e"))
            v = float(m.group(2).replace("D", "E").replace("d", "e"))
            unit = (m.group(3) or "ps").lower().replace(" ", "")
            if "ps" in unit:
                out["summary_mean_lifetime_ps"] = v
            elif "cm" in unit:
                # Bizarre mais possible : range en cm-1.
                out["summary_mean_linewidth_cm-1"] = v
            else:
                out["summary_mean_lifetime_ps"] = v  # best-effort (meV/ps/…)
            out["temperatures_K"].append(t)
            out.setdefault("matched_keywords", []).append("summary_mean_lifetime")
        except ValueError:
            pass
    for m in _RE_MEAN_LINEWIDTH.finditer(text):
        try:
            t = float(m.group(1).replace("D", "E").replace("d", "e"))
            v = float(m.group(2).replace("D", "E").replace("d", "e"))
            unit = (m.group(3) or "cm-1").lower().replace(" ", "")
            out["temperatures_K"].append(t)
            if "ps" in unit:
                # Cas inhabituel : linewidth en ps (rare) → on stocke comme linewidth.
                pass
            else:
                out["summary_mean_linewidth_cm-1"] = v
            out.setdefault("matched_keywords", []).append("summary_mean_linewidth")
        except ValueError:
            pass

    # 2. Lignes individuelles « q-point (..) mode N: τ = ... ps, γ = ... cm-1 ».
    n_mode_lines = 0
    for m in _RE_LIFETIME_LINE_BOTH.finditer(text):
        try:
            q_idx = int(m.group(1))
            q_tot = int(m.group(2))
            mode = int(m.group(3))
            tau = float(m.group("tau").replace("D", "E").replace("d", "e"))
            gamma = float(m.group("gamma").replace("D", "E").replace("d", "e"))
        except (ValueError, AttributeError):
            continue
        if n_mode_lines < 30:
            out["modes"].append({
                "q_index": q_idx,
                "q_total": q_tot,
                "mode_index": mode,
                "lifetime_ps": tau,
                "linewidth_cm-1": gamma,
            })
        n_mode_lines += 1
        out["max_lifetime_ps"] = max(out["max_lifetime_ps"] or 0.0, tau)
        out["max_linewidth_cm-1"] = max(out["max_linewidth_cm-1"] or 0.0, gamma)

    if n_mode_lines > 0:
        out.setdefault("matched_keywords", []).append("phonon_lifetime_mode_lines")

    # 3. Header « Phonon lifetime at T = X K » (première occurrence).
    if not out["temperatures_K"]:
        m = _RE_LIFETIME_HEADER.search(text)
        if m:
            try:
                out["temperatures_K"].append(float(m.group(1).replace("D", "E").replace("d", "e")))
            except ValueError:
                pass

    return out


# ----------------------------------------------------------------------------
# Parseur fichier colonne ``phonon_lifetime.dat`` (fréquence, γ, τ)
# ----------------------------------------------------------------------------


def parse_phonon_lifetime_file(path: Path, *, max_rows: int = 5000) -> dict[str, Any]:
    """Lit phonon_lifetime.dat (colonnes : freq_cm-1, linewidth_cm-1, lifetime_ps).

    Retourne : ``columns``, ``rows`` (≤ ``max_rows``), ``summary`` (stats).
    """
    path = Path(path).resolve()
    out: dict[str, Any] = {
        "path": str(path),
        "columns": None,
        "rows": [],
        "summary": {"n_points": 0},
        "matched_keywords": [],
        "error": None,
    }
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as ex:
        out["error"] = str(ex)
        return out

    candidate_hdr: Optional[list[str]] = None
    raw_rows: list[list[float]] = []
    for line in text.splitlines():
        ls = line.strip()
        if not ls:
            continue
        if ls.startswith("#") and candidate_hdr is None:
            # Tolérer en-tête « # frequency (cm^-1) linewidth (cm^-1) lifetime (ps) »
            toks = re.split(r"[\s,;]+", ls.lstrip("#").strip())
            if len(toks) >= 3:
                candidate_hdr = toks[:4]
                continue
        tokens = re.split(r"[\s,;]+", ls)
        if len(tokens) < 3:
            continue
        vals: list[Optional[float]] = [_qe_float(t) for t in tokens[:4]]
        if any(v is None for v in vals):
            continue
        # On exige : freq > 0 (sinon c'est un header implicitement),
        # linewidth ≥ 0, lifetime > 0.
        if vals[0] is None or vals[0] <= 0:
            # Une ligne avec freq <= 0 est probablement un header non-commenté.
            if not raw_rows:
                if candidate_hdr is None:
                    candidate_hdr = [str(t) for t in tokens[:4]]
                continue
        if vals[2] is None or vals[2] <= 0:
            continue
        raw_rows.append([float(v) for v in vals])
        if len(raw_rows) >= max_rows:
            break

    if not raw_rows:
        out["matched_keywords"].append("phonon_lifetime_file_no_data")
        return out

    out["matched_keywords"].append("phonon_lifetime_file_rows")
    if candidate_hdr is None:
        candidate_hdr = ["freq_cm-1", "linewidth_cm-1", "lifetime_ps", "volume"]
    out["columns"] = candidate_hdr[: len(raw_rows[0])]
    out["rows"] = raw_rows

    freqs = [r[0] for r in raw_rows if len(r) > 0]
    gammas = [r[1] for r in raw_rows if len(r) > 1]
    taus = [r[2] for r in raw_rows if len(r) > 2]
    out["summary"] = {
        "n_points": len(raw_rows),
        "freq_min": min(freqs) if freqs else None,
        "freq_max": max(freqs) if freqs else None,
        **_summarize(gammas),
    }
    # Ajouter des stats de lifetime (None-safe).
    ts = _summarize(taus)
    out["summary"]["lifetime_min"] = ts["min"]
    out["summary"]["lifetime_max"] = ts["max"]
    out["summary"]["lifetime_mean"] = ts["mean"]
    out["summary"]["lifetime_count"] = ts["count"]
    return out


# ----------------------------------------------------------------------------
# Parseur κ_lattice(T) — fichier colonne T(K), kappa_W_mK
# ----------------------------------------------------------------------------

def parse_kappa_lattice_file(path: Path) -> dict[str, Any]:
    """Lit ``lattice_thermal_conductivity.dat`` / ``kappa_lattice_*.dat``.

    Format attendu : T(K)  κ [W/(m·K)]  — colonnes ou lignes clé-valeur.
    """
    path = Path(path).resolve()
    out: dict[str, Any] = {
        "path": str(path),
        "rows": [],
        "mean_W_mK": None,
        "max_W_mK": None,
        "min_W_mK": None,
        "matched_keywords": [],
        "error": None,
    }
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as ex:
        out["error"] = str(ex)
        return out

    raw: list[tuple[float, float]] = []
    for ln in text.splitlines():
        ls = ln.strip()
        if not ls or ls.startswith("#"):
            continue
        toks = re.split(r"[\s,;]+", ls)
        if len(toks) < 2:
            continue
        t = _qe_float(toks[0])
        k = _qe_float(toks[1])
        if t is None or k is None:
            continue
        if t <= 0 or k < 0:
            continue
        raw.append((t, k))

    if not raw:
        return out
    raw.sort(key=lambda p: p[0])
    out["matched_keywords"].append("kappa_lattice_pairs")
    out["rows"] = raw[:500]  # cap
    kappas = [k for _, k in raw]
    s = _summarize(kappas)
    out["mean_W_mK"] = s["mean"]
    out["max_W_mK"] = s["max"]
    out["min_W_mK"] = s["min"]
    return out


# ----------------------------------------------------------------------------
# Parseur Grüneisen depuis gruneisen.dat / phonon_dos_T_gruneisen.dat
# ----------------------------------------------------------------------------

def parse_gruneisen_file(path: Path) -> dict[str, Any]:
    """Lit ``gruneisen.dat`` (colonne : γ(q,ν) modal)."""
    path = Path(path).resolve()
    out: dict[str, Any] = {
        "path": str(path),
        "values": [],
        "mean": None,
        "max_abs": None,
        "matched_keywords": [],
        "error": None,
    }
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as ex:
        out["error"] = str(ex)
        return out

    vals: list[float] = []
    for ln in text.splitlines():
        ls = ln.strip()
        if not ls or ls.startswith("#"):
            continue
        toks = re.split(r"[\s,;]+", ls)
        if not toks:
            continue
        v = _qe_float(toks[-1])  # souvent dernière colonne
        if v is None:
            continue
        # Grüneisen peut être négatif pour modes instables — pas de rejet.
        vals.append(v)

    if not vals:
        return out
    out["matched_keywords"].append("gruneisen_values")
    out["values"] = vals[:500]
    s = _summarize(vals)
    out["mean"] = s["mean"]
    out["max_abs"] = max(abs(v) for v in vals) if vals else None
    return out


# ----------------------------------------------------------------------------
# Orchestration work_dir
# ----------------------------------------------------------------------------

_CANDIDATE_LIFETIME_FILES = (
    "phonon_lifetime.dat",
    "phonon_lifetime_T300.dat",
    "phonon_lifetime_T300K.dat",
)
_CANDIDATE_KAPPA_FILES = (
    "lattice_thermal_conductivity.dat",
    "kappa_lattice.dat",
    "kappa_lattice_T.dat",
)
_CANDIDATE_GRUNEISEN_FILES = (
    "gruneisen.dat",
    "phonon_dos_T_gruneisen.dat",
)


def _find_first(work_dir: Path, names: tuple[str, ...]) -> Optional[Path]:
    work_dir = Path(work_dir).resolve()
    # Match exact d'abord, puis motifs T…K / variantes.
    for nm in names:
        p = work_dir / nm
        if p.is_file():
            return p
    globs = (
        "**/phonon_lifetime*.dat",
        "**/phonon_lifetime_T*.dat",
        "**/*lifetime*.dat",
        "**/kappa_lattice*.dat",
        "**/lattice_thermal_conductivity*.dat",
        "**/gruneisen*.dat",
        "**/phonon_dos_T_gruneisen*.dat",
        "**/anhar_files/*lifetime*",
        "**/anhar_files/*kappa*",
        "**/anhar_files/*gruneisen*",
    )
    seen: set[str] = set()
    for g in globs:
        for p in work_dir.glob(g):
            if not p.is_file():
                continue
            try:
                key = str(p.resolve())
            except OSError:
                continue
            if key in seen:
                continue
            seen.add(key)
            # Filtre heuristique : on préfère les fichiers courts dans work_dir racine.
            try:
                rel = p.resolve().relative_to(work_dir).as_posix()
            except ValueError:
                continue
            if rel.count("/") <= 3:
                return p
    return None


def parse_phonon_lifetime(work_dir: Path) -> dict[str, Any]:
    """Orchestrateur : combine journal + fichiers colonne pour ``what='ph_life'``."""
    work_dir = Path(work_dir).resolve()
    out: dict[str, Any] = {
        "mean_lifetime_ps": None,
        "mean_linewidth_cm-1": None,
        "min_lifetime_ps": None,
        "max_lifetime_ps": None,
        "max_linewidth_cm-1": None,
        "lattice_kappa_W_mK": None,
        "gruneisen_mean": None,
        "gruneisen_max_abs": None,
        "temperature_K_for_summary": None,
        "n_modes": 0,
        "modes": [],
        "source_files": [],
        "matched_keywords": [],
        "error": None,
    }

    # 1. Journal thermo_pw_run.out : extrait sections « Mean lifetime/linewidth »
    #    et lignes « q-point (..) mode N: τ=…,γ=… ».
    tpw_log = work_dir / "thermo_pw_run.out"
    if tpw_log.is_file():
        try:
            text = tpw_log.read_text(encoding="utf-8", errors="replace")
        except OSError:
            text = ""
        if text:
            tail = text[-200_000:] if len(text) > 200_000 else text
            parsed_tail = _parse_lifetime_lines_tail(tail)
            for k in ("summary_mean_lifetime_ps", "summary_mean_linewidth_cm-1",
                      "max_lifetime_ps", "max_linewidth_cm-1"):
                v = parsed_tail.get(k)
                if v is not None:
                    mapped_key = {
                        "summary_mean_lifetime_ps": "mean_lifetime_ps",
                        "summary_mean_linewidth_cm-1": "mean_linewidth_cm-1",
                        "max_lifetime_ps": "max_lifetime_ps",
                        "max_linewidth_cm-1": "max_linewidth_cm-1",
                    }[k]
                    if out[mapped_key] is None:
                        out[mapped_key] = v
            temps = parsed_tail.get("temperatures_K") or []
            if temps and out["temperature_K_for_summary"] is None:
                out["temperature_K_for_summary"] = temps[-1]
            modes = parsed_tail.get("modes") or []
            if modes:
                out["modes"] = modes[:30]
                out["n_modes"] = parsed_tail.get("n_mode_lines", 0) or len(modes)
                if out["mean_lifetime_ps"] is None:
                    taus = [m["lifetime_ps"] for m in modes if m.get("lifetime_ps")]
                    s = _summarize(taus)
                    out["mean_lifetime_ps"] = s["mean"]
                    out["min_lifetime_ps"] = s["min"]
                if out["mean_linewidth_cm-1"] is None:
                    gammas = [m["linewidth_cm-1"] for m in modes if m.get("linewidth_cm-1")]
                    s = _summarize(gammas)
                    out["mean_linewidth_cm-1"] = s["mean"]
                # min_lifetime_ps = le plus petit (mode le plus résistif)
                if out["min_lifetime_ps"] is None and out["mean_lifetime_ps"] is not None:
                    taus = [m["lifetime_ps"] for m in modes if m.get("lifetime_ps")]
                    out["min_lifetime_ps"] = min(taus) if taus else None
                # max_linewidth_cm-1 = le plus grand
                if out["max_linewidth_cm-1"] is None and out["mean_linewidth_cm-1"] is not None:
                    gammas = [m["linewidth_cm-1"] for m in modes if m.get("linewidth_cm-1")]
                    out["max_linewidth_cm-1"] = max(gammas) if gammas else None
            kw = parsed_tail.get("matched_keywords") or []
            for k in kw:
                if k not in out["matched_keywords"]:
                    out["matched_keywords"].append(k)
            out["source_files"].append(str(tpw_log.resolve().relative_to(work_dir).as_posix()))

    # 2. Fichier colonne phonon_lifetime.dat (souvent plus complet que le log).
    file_data = _find_first(work_dir, _CANDIDATE_LIFETIME_FILES)
    if file_data is not None:
        parsed_file = parse_phonon_lifetime_file(file_data)
        if parsed_file.get("rows") and not parsed_file.get("error"):
            sm = parsed_file.get("summary") or {}
            if out["mean_lifetime_ps"] is None and sm.get("lifetime_mean") is not None:
                out["mean_lifetime_ps"] = sm["lifetime_mean"]
                if out["min_lifetime_ps"] is None:
                    out["min_lifetime_ps"] = sm.get("lifetime_min")
                if out["max_lifetime_ps"] is None:
                    out["max_lifetime_ps"] = sm.get("lifetime_max")
            if out["mean_linewidth_cm-1"] is None and sm.get("mean") is not None:
                out["mean_linewidth_cm-1"] = sm["mean"]
            if out["max_linewidth_cm-1"] is None and sm.get("max") is not None:
                out["max_linewidth_cm-1"] = sm["max"]
            out["matched_keywords"].append("phonon_lifetime_dat_file")
            out["source_files"].append(
                parsed_file["path"]
            )

    # 3. κ_lattice(T)
    kappa_path = _find_first(work_dir, _CANDIDATE_KAPPA_FILES)
    if kappa_path is not None:
        kappa = parse_kappa_lattice_file(kappa_path)
        if kappa.get("mean_W_mK") is not None:
            out["lattice_kappa_W_mK"] = kappa["mean_W_mK"]
            out["matched_keywords"].append("kappa_lattice")
            out["source_files"].append(kappa["path"])

    # 4. Grüneisen
    gr_path = _find_first(work_dir, _CANDIDATE_GRUNEISEN_FILES)
    if gr_path is not None:
        gr = parse_gruneisen_file(gr_path)
        if gr.get("mean") is not None:
            out["gruneisen_mean"] = gr["mean"]
            out["gruneisen_max_abs"] = gr["max_abs"]
            out["matched_keywords"].append("gruneisen")
            out["source_files"].append(gr["path"])

    if not out["matched_keywords"]:
        out["matched_keywords"].append("no_ph_life_outputs_found")
    return out


__all__ = [
    "parse_phonon_lifetime",
    "parse_phonon_lifetime_file",
    "parse_kappa_lattice_file",
    "parse_gruneisen_file",
]

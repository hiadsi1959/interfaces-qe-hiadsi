"""
Parser des fichiers ``therm_files/output_therm.dat*`` de thermo_pw (juillet 2026).

thermo_pw (what='mur_lc_t' / 'ph_life' avec ltherm) écrit, pour chaque
géométrie gN de la grille QHA, un fichier ``therm_files/output_therm.dat.gN``
au format :

    # Zero point energy: 0.00887 Ry/cell, 11.64128 kJ/(N mol), ...
    # Temperature T in K,
    # Energy and free energy in Ry/cell,
    # Entropy in Ry/cell/K,
    # Heat capacity Cv in Ry/cell/K.
    ...
    #    T        energy      free energy     entropy         Cv
    0.000E+00  0.886E-02     0.886E-02       NaN             0.000E+00
    0.500E+02  0.891E-02     0.885E-02       0.131E-05       0.373E-05
    ...

Ces grandeurs (ZPE, F(T), S(T), Cv(T)) étaient promises par le catalogue
P2/P4 (« storage_hint ») mais jamais parsées dans ``results`` — ce module
comble le trou. La géométrie retenue est la géométrie **centrale** de la
grille (la plus proche de V0 par construction ±3 %) ; c'est une bonne
approximation harmonique des valeurs d'équilibre tant que les fichiers
``anhar_files`` (interpolation QHA au minimum de F) ne sont pas produits.

Fonction principale : ``parse_therm_dat(work_dir)`` → dict plat compatible
``_nest_set_default(results, "thermo.<clé>", v)`` :

    * ``zero_point_energy_Ry``   : float | None (Ry/cell)
    * ``Cv_300K_Ry_per_K``       : float | None
    * ``F_300K_Ry``              : float | None (énergie libre de Helmholtz)
    * ``entropy_300K_Ry_per_K``  : float | None
    * ``T_min_K`` / ``T_max_K``  : bornes de la grille T
    * ``n_T_points``             : int
    * ``curve_T_K`` / ``curve_Cv_Ry_per_K`` / ``curve_F_Ry`` : listes (cap 200)
    * ``source_file``            : relpath sous work_dir
"""
from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Any, Optional

_RE_ZPE = re.compile(
    r"(?i)zero\s*point\s*energy\s*:\s*([-+]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\s*Ry"
)


def _f(token: str) -> Optional[float]:
    """Float tolérant D-style Fortran + NaN."""
    s = str(token).strip()
    if not s:
        return None
    try:
        v = float(s.replace("D", "E").replace("d", "e"))
    except ValueError:
        return None
    if math.isnan(v) or math.isinf(v):
        return None
    return v


def find_therm_dat_files(work_dir: Path) -> list[Path]:
    """Liste triée des output_therm.dat* (racine, therm_files/, sous-dossiers)."""
    work_dir = Path(work_dir).resolve()
    out: list[Path] = []
    seen: set[str] = set()
    for g in ("therm_files/output_therm.dat*", "output_therm.dat*",
              "**/output_therm.dat*"):
        for p in sorted(work_dir.glob(g)):
            if not p.is_file():
                continue
            key = str(p.resolve())
            if key in seen:
                continue
            seen.add(key)
            out.append(p)
    return out


def _geometry_index(path: Path) -> int:
    """Extrait N depuis ``output_therm.dat.gN`` (0 si pas de suffixe .gN)."""
    m = re.search(r"\.g(\d+)$", path.name)
    return int(m.group(1)) if m else 0


def _is_primary_therm_dat(path: Path) -> bool:
    """Exclut les dérivés auxiliaires (``.dw`` = B(T), etc.)."""
    name = path.name.lower()
    if name.endswith(".dw") or name.endswith(".bak") or name.endswith(".tmp"):
        return False
    return True


def pick_central_geometry(paths: list[Path]) -> Optional[Path]:
    """Choisit la géométrie centrale de la grille (index médian des .gN).

    Un fichier sans suffixe (``output_therm.dat`` seul) est prioritaire :
    c'est la sortie « équilibre » quand thermo_pw la produit.
    Ignore ``*.dw`` (colonnes partielles type B_33(T), pas Cv/F/S).
    """
    if not paths:
        return None
    paths = [p for p in paths if _is_primary_therm_dat(p)]
    if not paths:
        return None
    no_suffix = [p for p in paths if _geometry_index(p) == 0]
    if no_suffix:
        # Préfère le fichier thermodynamique complet (Cv/F/S), pas un alias court.
        no_suffix.sort(key=lambda p: (0 if "debye" not in p.name.lower() else 1, p.name))
        return no_suffix[0]
    with_g = sorted(paths, key=_geometry_index)
    return with_g[len(with_g) // 2]


def parse_therm_dat_file(path: Path, *, max_curve_points: int = 200) -> dict[str, Any]:
    """Parse UN fichier output_therm.dat.gN. Voir docstring module."""
    out: dict[str, Any] = {
        "zero_point_energy_Ry": None,
        "Cv_300K_Ry_per_K": None,
        "F_300K_Ry": None,
        "entropy_300K_Ry_per_K": None,
        "T_min_K": None,
        "T_max_K": None,
        "n_T_points": 0,
        "curve_T_K": [],
        "curve_Cv_Ry_per_K": [],
        "curve_F_Ry": [],
        "error": None,
    }
    try:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
    except OSError as ex:
        out["error"] = str(ex)
        return out

    rows: list[tuple[float, Optional[float], Optional[float], Optional[float], Optional[float]]] = []
    for ln in text.splitlines():
        ls = ln.strip()
        if not ls:
            continue
        if ls.startswith("#"):
            m = _RE_ZPE.search(ls)
            if m and out["zero_point_energy_Ry"] is None:
                out["zero_point_energy_Ry"] = _f(m.group(1))
            continue
        toks = re.split(r"\s+", ls)
        if len(toks) < 2:
            continue
        t = _f(toks[0])
        if t is None or t < 0:
            continue
        e = _f(toks[1]) if len(toks) > 1 else None
        fe = _f(toks[2]) if len(toks) > 2 else None
        s = _f(toks[3]) if len(toks) > 3 else None
        cv = _f(toks[4]) if len(toks) > 4 else None
        rows.append((t, e, fe, s, cv))

    if not rows:
        return out
    rows.sort(key=lambda r: r[0])
    out["n_T_points"] = len(rows)
    out["T_min_K"] = rows[0][0]
    out["T_max_K"] = rows[-1][0]

    # Valeurs à T=300 K (ligne la plus proche ; grille ΔT=50 K → exact).
    closest = min(rows, key=lambda r: abs(r[0] - 300.0))
    if abs(closest[0] - 300.0) <= 60.0:
        out["F_300K_Ry"] = closest[2]
        out["entropy_300K_Ry_per_K"] = closest[3]
        out["Cv_300K_Ry_per_K"] = closest[4]

    # Courbes (échantillonnées si > max_curve_points).
    step = max(1, len(rows) // max_curve_points)
    sampled = rows[::step]
    out["curve_T_K"] = [r[0] for r in sampled]
    out["curve_F_Ry"] = [r[2] for r in sampled]
    out["curve_Cv_Ry_per_K"] = [r[4] for r in sampled]
    return out


def parse_therm_dat(work_dir: Path) -> dict[str, Any]:
    """Orchestrateur work_dir : géométrie centrale + relpath source."""
    work_dir = Path(work_dir).resolve()
    empty: dict[str, Any] = {
        "zero_point_energy_Ry": None,
        "Cv_300K_Ry_per_K": None,
        "F_300K_Ry": None,
        "entropy_300K_Ry_per_K": None,
        "source_file": None,
    }
    paths = find_therm_dat_files(work_dir)
    target = pick_central_geometry(paths)
    if target is None:
        return empty
    parsed = parse_therm_dat_file(target)
    try:
        parsed["source_file"] = target.resolve().relative_to(work_dir).as_posix()
    except ValueError:
        parsed["source_file"] = target.name
    return parsed


__all__ = [
    "parse_therm_dat",
    "parse_therm_dat_file",
    "find_therm_dat_files",
    "pick_central_geometry",
]

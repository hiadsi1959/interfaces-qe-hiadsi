"""
Parser magnétisation pw.x / thermo_pw (juillet 2026 ; noncolin août 2026).

Les métriques ``magnetism.*`` sont annoncées dans le contrat UI de tous les
profils P1..P5 (cf. ``pipeline._METRICS_MAGNETISM``) mais aucun writer ne les
peuplait : elles restaient ``null`` même pour un SCF spin-polarisé (nspin=2).

Ce module lit les journaux pw.x (SCF/NSCF) et thermo_pw et extrait :

  * ``total_magnetization``      : μ_B/cellule (dernière itération SCF).
                                   En non-colinéaire (nspin=4), norme du
                                   vecteur (mx, my, mz) ; les composantes
                                   sont exposées dans
                                   ``total_magnetization_vector``.
  * ``absolute_magnetization``   : μ_B/cellule
  * ``m_per_atom``               : moyenne |magn| par site (μ_B), si les
                                   lignes « atom N ... magn= » sont présentes
  * ``projected_moments_per_atom`` : liste [{atom, charge, magn_muB}] (≤ 32)
  * ``magnetic_order``           : classification depuis les moments
                                   CONVERGÉS (≠ starting_magnetization qui ne
                                   reflète que l'intention d'entrée) :
                                   "ferromagnetic" | "antiferromagnetic" |
                                   "ferrimagnetic" | "non_collinear" |
                                   "non_magnetic_converged" | None
  * ``is_spin_polarized``        : bool — True si les lignes magnétiques
                                   existent dans le journal (nspin > 1)
  * ``is_noncollinear``          : bool — True si magnétisation vectorielle
  * ``source_file``              : relpath du journal utilisé

Cas physiques couverts :
  * Ferromagnétique (FM)   : total ≈ absolute, moments de même signe.
  * Antiferromagnétique    : total ≈ 0 mais absolute > 0 (moments opposés).
  * Ferrimagnétique (FiM)  : 0 < |total| < absolute, signes mixtes par site.
  * Non-colinéaire (nspin=4/noncolin) : « total magnetization = mx my mz ».
  * Diamagnétique / nspin=1 : pw.x n'imprime PAS ces lignes → toutes les
    clés restent None et le merge du pipeline ne touche pas ``results``.
  * Paramagnétique convergé vers 0 (nspin=2 mais moments effondrés) :
    ``magnetic_order = "non_magnetic_converged"``.
"""
from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Any, Optional

_F = r"[-+]?\d*\.?\d+(?:[EeDd][+-]?\d+)?"

# Colinéaire : « total magnetization       =     2.00 Bohr mag/cell »
# Non-colinéaire (nspin=4) : « total magnetization = 0.00  0.00  2.00 Bohr mag/cell »
_RE_TOTAL_MAG = re.compile(
    rf"(?im)^\s*total\s+magnetization\s*=\s*({_F})(?:\s+({_F})\s+({_F}))?\s*Bohr\s*mag"
)
_RE_ABS_MAG = re.compile(
    rf"(?im)^\s*absolute\s+magnetization\s*=\s*({_F})\s*Bohr\s*mag"
)
# Colinéaire : « atom   1 (R=0.413)  charge= 14.5825  magn=  2.3055 »
# Non-colinéaire : magn= suivi de 3 composantes.
_RE_SITE_MAG = re.compile(
    rf"(?im)^\s*atom\s+(\d+)\s*\(R=\s*([\d.]+)\s*\)\s*charge=\s*({_F})\s*magn=\s*({_F})(?:\s+({_F})\s+({_F}))?"
)

# Journaux candidats, par ordre de fraîcheur/pertinence : le SCF d'équilibre
# d'abord (P1 scf.out, P2-P4 pw_scf_V0_for_phonon.out), puis NSCF, puis le
# journal thermo_pw (qui rejoue des SCF internes).
_CANDIDATE_LOGS = (
    "scf.out",
    "pw_scf_V0_for_phonon.out",
    "1_eos_volumes/out_scf_eq",
    "nscf.out",
    "thermo_pw_run.out",
)

_MAX_SITES = 32
# Seuil « moment significatif » (μ_B) : sous ce seuil un moment convergé est
# considéré comme du bruit numérique (paramagnétique effondré / dia).
_MOMENT_EPS = 0.05


def _f(tok: Optional[str]) -> Optional[float]:
    if tok is None:
        return None
    try:
        return float(str(tok).replace("D", "E").replace("d", "e"))
    except (TypeError, ValueError):
        return None


def classify_magnetic_order(
    total: Optional[float],
    absolute: Optional[float],
    site_moments: Optional[list[dict[str, Any]]],
    *,
    noncollinear: bool = False,
) -> Optional[str]:
    """Classifie l'ordre magnétique depuis les grandeurs CONVERGÉES.

    Périmètre volontairement restreint (demande utilisateur, août 2026) :
    seuls les cas NON ambigus sont étiquetés automatiquement —

      * ``non_collinear``      : nspin=4 (magnétisation vectorielle) ;
      * ``antiferromagnetic``  : nspin=2, total ≈ 0 avec absolue > 0
                                 (compensation exacte) ;
      * ``ferromagnetic``      : nspin=2, moments de même signe et
                                 total ≈ absolue (compensation faible).

    Tous les autres régimes (ferrimagnétique, diamagnétique, moments
    effondrés, compensation partielle sans moments de site…) renvoient
    ``None`` : les valeurs brutes (magnétisation totale/absolue, moments
    par site) restent affichées et l'interprétation est laissée à
    l'utilisateur. Contrairement à la détection d'entrée
    (starting_magnetization = intention d'initialisation), tout ici
    reflète l'état final convergé.
    """
    if noncollinear:
        return "non_collinear"
    if total is None and absolute is None:
        return None
    tot = abs(total) if total is not None else None
    ab = absolute if absolute is not None else None
    # Moments effondrés (para/dia à convergence) → pas d'étiquette,
    # l'utilisateur déduit depuis total ≈ 0 et absolue ≈ 0.
    if (ab is not None and ab < _MOMENT_EPS) and (tot is None or tot < _MOMENT_EPS):
        return None
    # AFM : compensation exacte (total ~ 0) avec des moments locaux réels.
    if tot is not None and ab is not None and tot < _MOMENT_EPS and ab >= _MOMENT_EPS:
        return "antiferromagnetic"
    # Signes mixtes par site avec moment net → ferri probable, mais
    # étiquetage laissé à l'utilisateur (None).
    if site_moments:
        vals = [m.get("magn_muB") for m in site_moments if m.get("magn_muB") is not None]
        signif = [v for v in vals if abs(v) >= _MOMENT_EPS]
        if signif:
            has_pos = any(v > 0 for v in signif)
            has_neg = any(v < 0 for v in signif)
            if has_pos and has_neg:
                # total ≈ 0 → compensation exacte = AFM ; sinon None (ferri ?).
                if tot is not None and tot < _MOMENT_EPS:
                    return "antiferromagnetic"
                return None
    # FM : moment net réel ET compensation faible (total ≈ absolue). Si la
    # magnétisation absolue excède nettement le total sans moments de site
    # pour trancher, on s'abstient (ferri possible → None).
    if tot is not None and tot >= _MOMENT_EPS:
        if ab is None or ab < _MOMENT_EPS or (tot / ab) >= 0.8:
            return "ferromagnetic"
        return None
    return None


def parse_magnetization_text(text: str) -> dict[str, Any]:
    """Parse un journal pw.x (texte). Prend la DERNIÈRE occurrence de chaque
    grandeur (= dernière itération SCF, la convergée)."""
    out: dict[str, Any] = {
        "total_magnetization": None,
        "total_magnetization_vector": None,
        "absolute_magnetization": None,
        "m_per_atom": None,
        "projected_moments_per_atom": None,
        "magnetic_order": None,
        "is_spin_polarized": None,
        "is_noncollinear": None,
    }
    if not text:
        return out
    tot_matches = _RE_TOTAL_MAG.findall(text)
    noncol = False
    if tot_matches:
        last = tot_matches[-1]
        mx = _f(last[0])
        my = _f(last[1]) if last[1] else None
        mz = _f(last[2]) if last[2] else None
        if my is not None and mz is not None:
            # nspin=4 : vecteur (mx, my, mz) → norme + composantes.
            noncol = True
            out["total_magnetization_vector"] = [mx, my, mz]
            out["total_magnetization"] = math.sqrt(
                (mx or 0.0) ** 2 + my ** 2 + mz ** 2
            )
        else:
            out["total_magnetization"] = mx
    ab = _RE_ABS_MAG.findall(text)
    if ab:
        out["absolute_magnetization"] = _f(ab[-1])
    # Sites : le bloc « Magnetic moment per site » est réimprimé à chaque
    # itération — on garde le dernier bloc en scannant depuis la fin.
    sites = _RE_SITE_MAG.findall(text)
    if sites:
        try:
            nat = max(int(s[0]) for s in sites)
        except ValueError:
            nat = 0
        last_block = sites[-nat:] if nat and len(sites) >= nat else sites
        moments = []
        for atom_idx, _r, charge, m1, m2, m3 in last_block[:_MAX_SITES]:
            c1, c2, c3 = _f(m1), _f(m2), _f(m3)
            if c2 is not None and c3 is not None:
                # noncolin : moment vectoriel par site → norme signée non
                # définissable ; on stocke la norme + les composantes.
                mag_val = math.sqrt((c1 or 0.0) ** 2 + c2 ** 2 + c3 ** 2)
                entry = {
                    "atom": int(atom_idx),
                    "charge": _f(charge),
                    "magn_muB": mag_val,
                    "magn_vector_muB": [c1, c2, c3],
                }
            else:
                entry = {
                    "atom": int(atom_idx),
                    "charge": _f(charge),
                    "magn_muB": c1,
                }
            moments.append(entry)
        if moments:
            out["projected_moments_per_atom"] = moments
            vals = [abs(m["magn_muB"]) for m in moments if m["magn_muB"] is not None]
            if vals:
                out["m_per_atom"] = sum(vals) / len(vals)
    if tot_matches or ab or sites:
        out["is_spin_polarized"] = True
        out["is_noncollinear"] = noncol
        out["magnetic_order"] = classify_magnetic_order(
            out["total_magnetization"],
            out["absolute_magnetization"],
            out["projected_moments_per_atom"],
            noncollinear=noncol,
        )
    return out


def parse_magnetization(work_dir: Path) -> dict[str, Any]:
    """Scanne les journaux candidats du work_dir ; premier qui matche gagne."""
    work_dir = Path(work_dir).resolve()
    empty: dict[str, Any] = {
        "total_magnetization": None,
        "total_magnetization_vector": None,
        "absolute_magnetization": None,
        "m_per_atom": None,
        "projected_moments_per_atom": None,
        "magnetic_order": None,
        "is_spin_polarized": None,
        "is_noncollinear": None,
        "source_file": None,
    }
    for rel in _CANDIDATE_LOGS:
        p = work_dir / rel
        if not p.is_file():
            continue
        try:
            size = p.stat().st_size
            with p.open("r", encoding="utf-8", errors="replace") as fh:
                if size > 400_000:
                    fh.seek(size - 400_000)
                text = fh.read()
        except OSError:
            continue
        parsed = parse_magnetization_text(text)
        if parsed.get("is_spin_polarized"):
            parsed["source_file"] = rel
            return parsed
    return empty


__all__ = [
    "parse_magnetization",
    "parse_magnetization_text",
    "classify_magnetic_order",
]

"""
Recherche et lecture de fichiers colonnes numériques : élasticités / modules vs température (§1.21 thermo_pw).

Inclut les .dat usuels (elastic_vs_T.dat, …) et les sorties QHA/QSA sans extension .dat sous anhar_files/
(ex. *.el_cons_qha, *.el_comp_qsa) telles qu’écrites par thermo_pw.
"""
from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Any, Optional


_CANDIDATE_FILENAMES = (
    "elastic_vs_T.dat",
    "elastic_vs_temperature.dat",
    "elastic_constants_vs_T.dat",
    "elasticity_vs_T.dat",
    "bulk_modulus_vs_T.dat",
    "thermo_elastic_constants.dat",
    "elastic_constants_geo.dat",
)
# thermo_pw écrit parfois sous energy_files/ ou un sous-dossier gnuplot (cf. guide §1.21).
_CANDIDATE_RELATIVE_EXTRA = (
    "energy_files/elastic_vs_T.dat",
    "energy_files/elastic_constants_vs_T.dat",
    "energy_files/elastic_vs_temperature.dat",
    "gnuplot_files/elastic_vs_T.dat",
)
# thermo_pw (QHA/QSA) écrit souvent des colonnes T, C_ij… sans extension .dat mais avec des suffixes du type
# .el_cons_qha / .el_cons_qsa sous anhar_files/ (cf. manage_elastic_cons_qha.f90, plot_elastic_t).
_ANHAR_SERIES_GLOBS = (
    "**/anhar_files/*.el_cons_qha*",
    "**/anhar_files/*.el_cons_qsa*",
    "**/anhar_files/*.el_comp_qha*",
    "**/anhar_files/*.el_comp_qsa*",
)


def dat_semantic_hint_for_filename(filename: str) -> str:
    """
    Indication pour l’interface : la colonne 1 reste généralement « T » mais les autres colonnes
    peuvent être B(T), C_ij(T), etc. selon le fichier thermo_pw.
    """
    ln = filename.lower()
    if ".el_cons_" in ln or ".el_comp_" in ln:
        return "elastic_constants_like"
    if "bulk" in ln and "elastic" not in ln and ("modulus" in ln or ln.startswith("bulk")):
        return "bulk_modulus_like"
    if "elastic" in ln or "cij" in ln or "c_ij" in ln:
        return "elastic_constants_like"
    return "generic_numeric_series"


def _series_semantic_rank(path: Path) -> int:
    """Plus haut = préféré pour des séries élasticités plutôt qu’un seul module B(T)."""
    ln = path.name.lower()
    if _skip_anhar_pressure_axis_file(path.name):
        return -10
    if ".el_cons_qha" in ln or ".el_comp_qha" in ln:
        return 5 if "_ph" in ln else 4
    if ".el_cons_qsa" in ln or ".el_comp_qsa" in ln:
        return 4 if "_ph" in ln else 3
    if ("elastic" in ln or "c_ij" in ln or "cij" in ln) and "bulk" not in ln:
        return 2
    if "bulk" in ln and "elastic" not in ln:
        return 0
    if ".el_cons_" in ln or ".el_comp_" in ln:
        return 1
    return 1


def _skip_anhar_pressure_axis_file(name: str) -> bool:
    """Séries impliquant la pression (axe p en kbar) — pas l’aperçu « vs T » par défaut."""
    ln = Path(name).name.lower()
    if "_qha_p" in ln or "_qsa_p" in ln or "_d_qha_p" in ln or "_d_qsa_p" in ln:
        return True
    if re.search(r"\.el_cons_p(?:\.|$)", ln):
        return True
    if re.search(r"\.el_comp_p(?:\.|$)", ln):
        return True
    return False


def _parse_float_token(tok: str) -> Optional[float]:
    t = tok.strip()
    if not t or t == "#":
        return None
    t = (
        t.replace("D+", "e+")
        .replace("d+", "e+")
        .replace("D-", "e-")
        .replace("d-", "e-")
        .replace("D", "e")
        .replace("d", "e")
    )
    try:
        return float(t)
    except ValueError:
        return None


def _tokenize_line(ls: str) -> list[str]:
    return [x for x in re.split(r"[\s,;]+", ls.strip()) if x]


def _line_numeric_row(tokens: list[str]) -> Optional[list[float]]:
    floats: list[float] = []
    for p in tokens:
        v = _parse_float_token(p)
        if v is None:
            return None
        floats.append(v)
    if len(floats) < 2:
        return None
    return floats


def _maybe_header_chunks(comment_body: str) -> Optional[list[str]]:
    """Ligne « # … » interprétée comme en-tête de colonnes (noms mélangés chiffres / texte)."""
    chunks = _tokenize_line(comment_body)
    if len(chunks) < 2:
        return None
    n_float = sum(1 for c in chunks if _parse_float_token(c) is not None)
    if n_float >= len(chunks):
        return None
    return chunks[: min(48, len(chunks))]


def _noise_dat_basename(name: str) -> bool:
    """Fichiers très souvent hors sujet pour C_ij(T)."""
    n = Path(name).name.lower()
    if "output_ev" in n:
        return True
    if n in ("eos_points.dat", "eos_curve.dat", "eos_points_fit.dat"):
        return True
    if "phonon_bands" in n:
        return True
    return False


def _is_noise_dat_path(p: Path) -> bool:
    return _noise_dat_basename(p.name)


def _basename_suggests_elastic_temperature_series(name: str) -> bool:
    """Nom de fichier probable pour C_ij(T) / modules vs T (seuil d’échantillon assoupli)."""
    ln = Path(name).name.lower()
    if _skip_anhar_pressure_axis_file(name):
        return False
    return (
        "elastic" in ln
        or "cij" in ln
        or "c_ij" in ln
        or "bulk_modulus_vs" in ln
        or ln.endswith("_vs_t.dat")
        or "vs_temperature" in ln
        or "thermo_elastic" in ln
        or "elastic_constants_geo" in ln
        or ".el_cons_" in ln
        or ".el_comp_" in ln
    )


def _looks_like_temperature_series(sample_lines: list[str], *, min_numeric_rows: int = 3) -> bool:
    n = 0
    for line in sample_lines[:120]:
        ls = line.strip()
        if not ls or ls.startswith("#"):
            continue
        tokens = _tokenize_line(ls)
        row = _line_numeric_row(tokens)
        if row is not None and len(row) >= 2:
            n += 1
    return n >= min_numeric_rows


def find_elastic_t_dat(work_dir: Path) -> Optional[Path]:
    """Cherche un fichier colonnes (souvent .dat ; aussi sorties anhar thermo_pw sans .dat)."""
    work_dir = Path(work_dir).resolve()
    for rel in _CANDIDATE_FILENAMES:
        p = work_dir / rel
        if p.is_file() and not _is_noise_dat_path(p):
            return p
    for rel in _CANDIDATE_RELATIVE_EXTRA:
        p = work_dir / rel
        if p.is_file() and not _is_noise_dat_path(p):
            return p

    globs = (
        *_ANHAR_SERIES_GLOBS,
        "**/*elastic*T*.dat",
        "**/*Elastic*T*.dat",
        "**/*elastic*temperature*.dat",
        "**/*Elastic*temperature*.dat",
        "**/*bulk*T*.dat",
        "**/*bulk*temperature*.dat",
        "**/*_vs_T.dat",
        "**/*_vs_t.dat",
        "**/*elastic*vs*.dat",
        "**/*mur_lc*t_elastic*.dat",
        "**/*geo*elastic*.dat",
        "**/*elastic_constants*.dat",
    )
    hits: dict[str, Path] = {}
    for g in globs:
        for p in work_dir.glob(g):
            if _is_noise_dat_path(p):
                continue
            if _skip_anhar_pressure_axis_file(p.name):
                continue
            key = str(p.resolve())
            if key not in hits:
                hits[key] = p

    dated: list[tuple[int, float, Path]] = []
    for p in hits.values():
        try:
            with p.open("r", encoding="utf-8", errors="replace") as f:
                lines = []
                for _ in range(160):
                    line = f.readline()
                    if not line:
                        break
                    lines.append(line)
        except OSError:
            continue
        min_rows = 2 if _basename_suggests_elastic_temperature_series(p.name) else 3
        rank = _series_semantic_rank(p)
        if rank < 0:
            continue
        if _looks_like_temperature_series(lines, min_numeric_rows=min_rows):
            try:
                mt = p.stat().st_mtime
            except OSError:
                continue
            dated.append((rank, mt, p))

    if dated:
        dated.sort(key=lambda t: (-t[0], -t[1], str(t[2]).lower()))
        return dated[0][2]
    return _fallback_elastic_dat_parse_hits(hits)


def _serialize_cell(x: float) -> Optional[float]:
    if isinstance(x, float) and (math.isnan(x) or math.isinf(x)):
        return None
    return float(x)


def _build_column_names(hdr: Optional[list[str]], ncol: int) -> list[str]:
    raw = [str(x).strip() for x in (hdr or []) if str(x).strip()]
    h = raw
    if len(h) > ncol:
        low0 = h[0].lower().rstrip(":").strip()
        if low0 in ("columns", "column", "cols"):
            h = h[1:]
        if len(h) >= ncol:
            h = h[:ncol]
        else:
            h = []

    names: list[str] = []
    for i in range(ncol):
        if len(h) > i:
            names.append(h[i][:40].strip() or f"Colonne {i + 1}")
        elif i == 0:
            names.append("T / x (col. 1)")
        else:
            names.append(f"Colonne {i + 1}")
    return names


def _numeric_summary(columns: list[str], rows_json: list[list[Optional[float]]]) -> dict[str, Any]:
    if not rows_json:
        return {"n_points": 0}

    def col_floats(j: int) -> list[float]:
        out: list[float] = []
        for r in rows_json:
            if j < len(r) and r[j] is not None:
                out.append(float(r[j]))
        return out

    xv = col_floats(0)
    summ: dict[str, Any] = {
        "x_label": columns[0] if columns else "col1",
        "n_points": len(rows_json),
        "x_min": min(xv) if xv else None,
        "x_max": max(xv) if xv else None,
        "columns_count": len(columns),
        "series": [],
    }
    for j in range(1, len(columns)):
        vs = col_floats(j)
        item: dict[str, Any] = {"name": columns[j], "min": None, "max": None}
        if vs:
            item["min"] = min(vs)
            item["max"] = max(vs)
        summ["series"].append(item)
    return summ


def parse_numeric_series_dat(path: Path, *, max_rows: int = 2500) -> dict[str, Any]:
    path = Path(path).resolve()

    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as ex:
        return {"error": str(ex), "path": str(path)}

    mr = max(10, min(50_000, int(max_rows)))
    candidate_hdr: Optional[list[str]] = None
    raw_rows: list[list[float]] = []

    for line in text.splitlines():
        ls = line.strip()
        if not ls:
            continue
        if ls.startswith("#"):
            h = _maybe_header_chunks(ls[1:].strip())
            if h:
                candidate_hdr = h
            continue
        tokens = _tokenize_line(ls)
        row = _line_numeric_row(tokens)
        if row is None:
            continue
        raw_rows.append(row)
        if len(raw_rows) >= mr:
            break

    if not raw_rows:
        return {
            "error": "Aucune ligne avec au moins deux nombres (vérifiez séparateurs / exposants Fortran D±).",
            "path": str(path),
        }

    ncol = max(len(r) for r in raw_rows)
    padded: list[list[float]] = []
    for r in raw_rows:
        if len(r) < ncol:
            r = r + [float("nan")] * (ncol - len(r))
        padded.append(r[:ncol])

    colnames = _build_column_names(candidate_hdr, ncol)
    rows_json = [[_serialize_cell(x) for x in rw] for rw in padded]

    ncol_fix = ncol
    summary = _numeric_summary(colnames, rows_json)

    return {
        "path": str(path),
        "n_rows": len(rows_json),
        "n_rows_truncated_to": mr if len(raw_rows) >= mr else None,
        "columns": colnames,
        "series_meta": [{"x": colnames[0], "y": colnames[i]} for i in range(1, ncol_fix)],
        "rows": rows_json,
        "ncol": ncol_fix,
        "summary": summary,
    }


def _fallback_elastic_dat_parse_hits(hits: dict[str, Path]) -> Optional[Path]:
    """Dernier recours : parse complet sur les chemins au nom plausible (peu de lignes T dans l’en-tête)."""
    if not hits:
        return None

    def _mtime(p: Path) -> float:
        try:
            return float(p.stat().st_mtime)
        except OSError:
            return 0.0

    ranked = sorted(
        hits.values(),
        key=lambda p: (-_series_semantic_rank(p), -_mtime(p), str(p).lower()),
    )
    for p in ranked:
        if _is_noise_dat_path(p) or not _basename_suggests_elastic_temperature_series(p.name):
            continue
        tbl = parse_numeric_series_dat(p, max_rows=120)
        if tbl.get("error"):
            continue
        ncol = int(tbl.get("ncol") or 0)
        rows = tbl.get("rows") or []
        if ncol >= 2 and len(rows) >= 1:
            return p
    return None


def list_dat_relpaths(work_dir: Path, *, limit: int = 48) -> list[str]:
    """Quelques chemins .dat sous le run — aide message 404 (évite dossiers QE .save/)."""
    work_dir = Path(work_dir).resolve()
    found: list[str] = []
    for p in sorted(work_dir.glob("**/*.dat"), key=lambda q: str(q).lower()):
        try:
            rel = p.resolve().relative_to(work_dir).as_posix()
        except ValueError:
            continue
        rel_low = rel.replace("\\", "/").lower()
        if ".save/" in rel_low:
            continue
        found.append(rel)
        if len(found) >= limit:
            break
    return found


def list_elastic_like_dat_candidates(work_dir: Path, *, limit: int = 72) -> list[str]:
    """Sous-ensemble pour message d’aide lorsque aucun fichier n’est sélectionné automatiquement."""
    keys = ("elastic", "bulk", "cij", "c_ij", "_vs_t", "vs_t", "modulus", "mur_lc", ".el_cons_", ".el_comp_")
    out: list[str] = []
    wd = Path(work_dir).resolve()
    seen_rel: set[str] = set()
    for g in _ANHAR_SERIES_GLOBS:
        for p in wd.glob(g):
            if _skip_anhar_pressure_axis_file(p.name):
                continue
            try:
                rel = p.resolve().relative_to(wd).as_posix()
            except ValueError:
                continue
            if rel not in seen_rel:
                seen_rel.add(rel)
                out.append(rel)
            if len(out) >= limit:
                return sorted(out, key=lambda s: s.lower())[:limit]
    for rel in list_dat_relpaths(wd, limit=160):
        rl = rel.lower()
        if _noise_dat_basename(rel):
            continue
        if rel in seen_rel:
            continue
        if any(k in rl for k in keys):
            seen_rel.add(rel)
            out.append(rel)
        if len(out) >= limit:
            break
    if out:
        return sorted(out, key=lambda s: s.lower())[:limit]
    patterns = (
        "**/*elastic*.dat",
        "**/*Elastic*.dat",
        "**/*cij*.dat",
        "**/*Cij*.dat",
        "**/*vs_t*.dat",
        "**/*vs_T*.dat",
    )
    for pat in patterns:
        for p in wd.glob(pat):
            if _is_noise_dat_path(p):
                continue
            try:
                rel = p.resolve().relative_to(wd).as_posix()
            except ValueError:
                continue
            if ".save/" in rel.lower():
                continue
            if rel in seen_rel:
                continue
            seen_rel.add(rel)
            out.append(rel)
            if len(out) >= limit:
                return sorted(out, key=lambda s: s.lower())[:limit]
    return sorted(out, key=lambda s: s.lower())[:limit]


SERIES_HINT_NAMES = tuple(
    dict.fromkeys(
        (
            *_CANDIDATE_FILENAMES,
            *_CANDIDATE_RELATIVE_EXTRA,
            "anhar_files/<préfixe>.el_cons_qha",
            "anhar_files/<préfixe>.el_cons_qsa",
            "anhar_files/<préfixe>.el_comp_qha",
        )
    )
)


def path_allowed_for_elastic_t_series_request(p: Path) -> bool:
    """True si relpath utilisateur peut être lu comme tableau (GET elastic_t_series / gnuplot)."""
    if not p.is_file():
        return False
    n = p.name.lower()
    if _noise_dat_basename(p.name):
        return False
    if _skip_anhar_pressure_axis_file(p.name):
        return False
    if n.endswith(".dat"):
        return True
    if ".celldm" in n:
        return False
    if ".el_cons_" in n or ".el_comp_" in n:
        return True
    return False

"""
Grandeurs thermodynamiques dérivées ou complémentaires (α, Cp, ε₀ LST).

thermo_pw écrit surtout C_v, F, S dans ``output_therm.dat*``. Ce module :
  * parse α(T) explicite dans ``thermo_pw_run.out`` si présent ;
  * estime α via V(T) ou la relation Grüneisen α ≈ γ C_v / (B V) ;
  * estime C_p ≈ C_v + T V α² B (identité thermodynamique, solide isotrope) ;
  * calcule ε₀ moyenne via Lyddane–Sachs–Teller si ω_LO, ω_TO et ε∞ disponibles.
"""
from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Any, Optional

# Constantes unités (CODATA approx.)
_RY_TO_J = 2.179872361e-18
_BOHR3_TO_M3 = (5.291772109e-11) ** 3

_RE_ALPHA_LINE = re.compile(
    r"(?i)(?:thermal\s+expansion\s+coefficient|bulk\s+expansion\s+coefficient|"
    r"coefficient\s+of\s+(?:thermal\s+)?expansion|"
    r"alpha[\s_]*(?:v|vol|thermal)?)\s*[=:]\s*"
    r"([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\s*(?:1\s*/?\s*K|K\s*[-−]\s*1|/K)?"
)
_RE_ALPHA_AT_T = re.compile(
    r"(?i)alpha\s*\(\s*T\s*=\s*([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\s*K\s*\)\s*[=:]\s*"
    r"([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)"
)
_RE_VOL_T_ROW = re.compile(
    r"^\s*([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\s+([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\s*$"
)


def _f(token: str) -> Optional[float]:
    s = str(token).strip().replace("D", "E").replace("d", "e")
    if not s:
        return None
    try:
        v = float(s)
    except ValueError:
        return None
    if math.isnan(v) or math.isinf(v):
        return None
    return v


def parse_thermal_expansion_from_text(text: str) -> dict[str, Any]:
    """Extrait α explicite (K⁻¹) depuis un journal thermo_pw."""
    out: dict[str, Any] = {
        "alpha_300K_per_K": None,
        "alpha_source": None,
        "curve_T_K": [],
        "curve_alpha_per_K": [],
    }
    if not text or not text.strip():
        return out

    curve: list[tuple[float, float]] = []
    for m in _RE_ALPHA_AT_T.finditer(text):
        t, a = _f(m.group(1)), _f(m.group(2))
        if t is not None and a is not None and t >= 0:
            curve.append((t, a))
    if curve:
        curve.sort(key=lambda x: x[0])
        out["curve_T_K"] = [x[0] for x in curve]
        out["curve_alpha_per_K"] = [x[1] for x in curve]
        closest = min(curve, key=lambda x: abs(x[0] - 300.0))
        if abs(closest[0] - 300.0) <= 75.0:
            out["alpha_300K_per_K"] = closest[1]
            out["alpha_source"] = "log_alpha_vs_T"
        return out

    for m in _RE_ALPHA_LINE.finditer(text):
        a = _f(m.group(1))
        if a is not None:
            out["alpha_300K_per_K"] = a
            out["alpha_source"] = "log_alpha_scalar"
            return out
    return out


def parse_volume_vs_T_table(text: str) -> list[tuple[float, float]]:
    """Table T (K) vs V (bohr³/cell) — en-tête « T V » ou colonnes numériques."""
    rows: list[tuple[float, float]] = []
    if not text:
        return rows
    in_block = False
    for ln in text.splitlines():
        ls = ln.strip()
        if not ls or ls.startswith("#"):
            if re.search(r"(?i)\bT\b.*\bV\b|\bvolume\b.*\btemp", ls):
                in_block = True
            continue
        m = _RE_VOL_T_ROW.match(ls.replace(",", " "))
        if not m:
            if in_block and rows:
                break
            continue
        t, v = _f(m.group(1)), _f(m.group(2))
        if t is None or v is None or t < 0 or v <= 0:
            continue
        rows.append((t, v))
    rows.sort(key=lambda x: x[0])
    return rows


def find_volume_vs_T_file(work_dir: Path) -> Optional[Path]:
    work_dir = Path(work_dir).resolve()
    patterns = (
        "**/volume_vs_T*.dat",
        "**/V_vs_T*.dat",
        "**/anhar_files/*volume*",
        "**/therm_files/*volume*",
    )
    for g in patterns:
        for p in sorted(work_dir.glob(g)):
            if p.is_file() and p.stat().st_size > 0:
                return p
    return None


def alpha_from_volume_curve(
    rows: list[tuple[float, float]], *, T_target: float = 300.0
) -> Optional[float]:
    """α = (1/V)(dV/dT) par différences centrées."""
    if len(rows) < 2:
        return None
    # Point le plus proche de T_target pour la dérivée locale.
    idx = min(range(len(rows)), key=lambda i: abs(rows[i][0] - T_target))
    if idx == 0:
        i0, i1 = 0, 1
    elif idx == len(rows) - 1:
        i0, i1 = len(rows) - 2, len(rows) - 1
    else:
        i0, i1 = idx - 1, idx + 1
    t0, v0 = rows[i0]
    t1, v1 = rows[i1]
    if t1 == t0 or v0 <= 0:
        return None
    dVdT = (v1 - v0) / (t1 - t0)
    v_mid = 0.5 * (v0 + v1)
    return dVdT / v_mid


def alpha_from_gruneisen(
    *,
    gamma: float,
    cv_Ry_per_K: float,
    volume_bohr3: float,
    bulk_GPa: float,
) -> Optional[float]:
    """α ≈ γ C_v / (B V) en unités SI cohérentes."""
    if gamma <= 0 or cv_Ry_per_K <= 0 or volume_bohr3 <= 0 or bulk_GPa <= 0:
        return None
    cv_J = cv_Ry_per_K * _RY_TO_J
    v_m3 = volume_bohr3 * _BOHR3_TO_M3
    b_pa = bulk_GPa * 1e9
    return gamma * cv_J / (b_pa * v_m3)


def _alpha_at_temperature(
    T_K: float,
    *,
    alpha_300K_per_K: Optional[float],
    curve_alpha_T_K: Optional[list[float]] = None,
    curve_alpha_per_K: Optional[list[float]] = None,
) -> Optional[float]:
    """α(T) : courbe parsée si disponible, sinon α @ 300 K constant."""
    if curve_alpha_T_K and curve_alpha_per_K:
        if len(curve_alpha_T_K) == len(curve_alpha_per_K) and curve_alpha_T_K:
            closest = min(
                zip(curve_alpha_T_K, curve_alpha_per_K),
                key=lambda pair: abs(pair[0] - T_K),
            )
            return closest[1]
    return alpha_300K_per_K


def alpha_curve_from_gruneisen(
    *,
    curve_T_K: list[float],
    curve_Cv_Ry_per_K: list[float],
    curve_B_GPa: list[Optional[float]],
    volume_bohr3: float,
    gamma: float = 0.5,
) -> list[Optional[float]]:
    """α(T) ≈ γ C_v(T) / (B(T) V) — utile quand seule Cv(T) et B(T) sont parsées."""
    if not curve_T_K or len(curve_T_K) != len(curve_Cv_Ry_per_K):
        return []
    if volume_bohr3 <= 0 or gamma <= 0:
        return []
    v_m3 = volume_bohr3 * _BOHR3_TO_M3
    out: list[Optional[float]] = []
    for i, cv in enumerate(curve_Cv_Ry_per_K):
        if cv is None or cv <= 0:
            out.append(None)
            continue
        b_gpa: Optional[float] = None
        if curve_B_GPa and i < len(curve_B_GPa) and curve_B_GPa[i] is not None:
            b_gpa = float(curve_B_GPa[i])  # type: ignore[arg-type]
        if b_gpa is None or b_gpa <= 0:
            out.append(None)
            continue
        cv_J = float(cv) * _RY_TO_J
        out.append(gamma * cv_J / (b_gpa * 1e9 * v_m3))
    return out


def compute_cp_temperature_curve(
    *,
    curve_T_K: list[float],
    curve_Cv_Ry_per_K: list[float],
    alpha_300K_per_K: Optional[float],
    volume_bohr3: float,
    bulk_GPa: float,
    curve_alpha_T_K: Optional[list[float]] = None,
    curve_alpha_per_K: Optional[list[float]] = None,
    curve_B_GPa: Optional[list[Optional[float]]] = None,
) -> tuple[list[Optional[float]], str]:
    """C_p(T) ≈ C_v(T) + T V α(T)² B(T) pour chaque point de la grille thermo_pw."""
    if not curve_T_K or len(curve_T_K) != len(curve_Cv_Ry_per_K):
        return [], "missing_cv_curve"
    if alpha_300K_per_K is None and not curve_alpha_per_K:
        return [], "missing_alpha"
    if volume_bohr3 <= 0 or bulk_GPa <= 0:
        return [], "missing_volume_or_bulk"

    has_alpha_curve = bool(curve_alpha_T_K and curve_alpha_per_K)
    has_B_curve = bool(curve_B_GPa and any(b is not None for b in curve_B_GPa))
    cp_curve: list[Optional[float]] = []
    for i, (t, cv) in enumerate(zip(curve_T_K, curve_Cv_Ry_per_K)):
        if cv is None:
            cp_curve.append(None)
            continue
        alpha = _alpha_at_temperature(
            float(t),
            alpha_300K_per_K=alpha_300K_per_K,
            curve_alpha_T_K=curve_alpha_T_K,
            curve_alpha_per_K=curve_alpha_per_K,
        )
        if alpha is None:
            cp_curve.append(None)
            continue
        b_at_t = bulk_GPa
        if has_B_curve and curve_B_GPa and i < len(curve_B_GPa) and curve_B_GPa[i] is not None:
            b_at_t = float(curve_B_GPa[i])  # type: ignore[arg-type]
        cp_curve.append(
            cp_from_cv_correction(
                cv_Ry_per_K=float(cv),
                alpha_per_K=float(alpha),
                volume_bohr3=float(volume_bohr3),
                bulk_GPa=float(b_at_t),
                T_K=float(t),
            )
        )
    source = "Cv_plus_TValpha2B_curve"
    if has_alpha_curve:
        source += "_alpha_vs_T"
    elif alpha_300K_per_K is not None:
        source += "_alpha_const"
    if has_B_curve:
        source += "_B_vs_T"
    return cp_curve, source


def write_cv_cp_dat(work_dir: Path, thermo: dict[str, Any]) -> Optional[str]:
    """Écrit ``therm_files/cv_cp_vs_T.dat`` (T, Cv, Cp). Renvoie le relpath."""
    T = thermo.get("curve_T_K") or []
    Cv = thermo.get("curve_Cv_Ry_per_K") or []
    Cp = thermo.get("curve_Cp_Ry_per_K") or []
    if not T or len(T) != len(Cv) or len(T) != len(Cp):
        return None
    lines = [
        "# T (K)   Cv (Ry/cell/K)   Cp (Ry/cell/K)",
        "# Cp from Cv + T*V*alpha^2*B (thermo_derived)",
    ]
    n = 0
    for t, cv, cp in zip(T, Cv, Cp):
        if cv is None or cp is None:
            continue
        lines.append(f"{float(t):14.6e}  {float(cv):14.6e}  {float(cp):14.6e}")
        n += 1
    if n < 2:
        return None
    out = Path(work_dir).resolve() / "therm_files" / "cv_cp_vs_T.dat"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out.relative_to(Path(work_dir).resolve()).as_posix()


def cp_from_cv_correction(
    *,
    cv_Ry_per_K: float,
    alpha_per_K: float,
    volume_bohr3: float,
    bulk_GPa: float,
    T_K: float,
) -> Optional[float]:
    """C_p ≈ C_v + T V α² B (J/K/cell → Ry/K/cell)."""
    if cv_Ry_per_K is None or alpha_per_K is None:
        return None
    if volume_bohr3 <= 0 or bulk_GPa <= 0 or T_K < 0:
        return None
    cv_J = cv_Ry_per_K * _RY_TO_J
    v_m3 = volume_bohr3 * _BOHR3_TO_M3
    b_pa = bulk_GPa * 1e9
    delta_J = T_K * v_m3 * (alpha_per_K ** 2) * b_pa
    return (cv_J + delta_J) / _RY_TO_J


def epsilon_static_from_lst(
    epsilon_infinity: Optional[float],
    lo_freq_cm: Optional[float],
    to_freq_cm: Optional[float],
) -> Optional[float]:
    """Lyddane–Sachs–Teller : ε₀ = ε∞ (ω_LO/ω_TO)²."""
    if epsilon_infinity is None or epsilon_infinity <= 0:
        return None
    if lo_freq_cm is None or to_freq_cm is None:
        return None
    if lo_freq_cm <= 0 or to_freq_cm <= 0:
        return None
    ratio = lo_freq_cm / to_freq_cm
    return float(epsilon_infinity * ratio * ratio)


def _resolve_volume_bohr3(work_dir: Path, results: dict[str, Any]) -> Optional[float]:
    v = _get_nested(results, "eos.V0_bohr3")
    if v is not None:
        return float(v)
    work_dir = Path(work_dir)
    for name in ("scf.out", "pw_scf_V0_for_phonon.out"):
        scf = work_dir / name
        if not scf.is_file():
            continue
        try:
            import re as _re
            text = scf.read_text(encoding="utf-8", errors="replace")
            m = _re.search(
                r"unit-cell volume\s*=\s*([+-]?\d+\.?\d*)\s*\(a\.u\.\)\^3",
                text,
                _re.I,
            )
            if m:
                return float(m.group(1))
        except OSError:
            continue
    return None


def _resolve_bulk_GPa(results: dict[str, Any]) -> Optional[float]:
    b = _get_nested(results, "eos.B0_GPa")
    if b is not None:
        return float(b)
    b = _get_nested(results, "elastic.bulk_modulus_GPa")
    return float(b) if b is not None else None


def _get_nested(results: dict[str, Any], dotted: str) -> Any:
    cur: Any = results
    for part in dotted.split("."):
        if not isinstance(cur, dict):
            return None
        cur = cur.get(part)
    return cur


def enrich_thermo_and_dielectric(
    work_dir: Path,
    results: dict[str, Any],
    *,
    force: bool = False,
) -> None:
    """Enrichit ``results`` in-place (thermo.*, dielectric.*). Idempotent."""
    work_dir = Path(work_dir).resolve()
    thermo = results.setdefault("thermo", {})
    dielectric = results.setdefault("dielectric", {})

    # --- α(T) : journal puis V(T) puis Grüneisen -------------------------
    if thermo.get("alpha_300K_per_K") is None:
        tpw = work_dir / "thermo_pw_run.out"
        if tpw.is_file():
            try:
                tail = tpw.read_text(encoding="utf-8", errors="replace")[-400_000:]
                parsed_a = parse_thermal_expansion_from_text(tail)
                if parsed_a.get("alpha_300K_per_K") is not None:
                    thermo["alpha_300K_per_K"] = parsed_a["alpha_300K_per_K"]
                    thermo["alpha_source"] = parsed_a.get("alpha_source")
                if parsed_a.get("curve_T_K") and not thermo.get("curve_alpha_per_K"):
                    thermo["curve_alpha_T_K"] = parsed_a["curve_T_K"]
                    thermo["curve_alpha_per_K"] = parsed_a["curve_alpha_per_K"]
            except OSError:
                pass

    if thermo.get("alpha_300K_per_K") is None:
        vf = find_volume_vs_T_file(work_dir)
        if vf is not None:
            try:
                rows = parse_volume_vs_T_table(
                    vf.read_text(encoding="utf-8", errors="replace")
                )
                a = alpha_from_volume_curve(rows)
                if a is not None:
                    thermo["alpha_300K_per_K"] = a
                    thermo["alpha_source"] = f"volume_table:{vf.name}"
            except OSError:
                pass

    if thermo.get("alpha_300K_per_K") is None:
        gamma = _get_nested(results, "ph_life.gruneisen_mean")
        cv = thermo.get("Cv_300K_Ry_per_K")
        vol = _resolve_volume_bohr3(work_dir, results)
        bulk = _resolve_bulk_GPa(results)
        if gamma is None and cv is not None and vol and bulk and thermo.get("debye_temperature_K"):
            gamma = 0.5
            gamma_src = "slater_gamma_0.5"
        else:
            gamma_src = "gruneisen_mean"
        if gamma is not None and cv is not None and vol is not None and bulk is not None:
            a = alpha_from_gruneisen(
                gamma=float(gamma),
                cv_Ry_per_K=float(cv),
                volume_bohr3=float(vol),
                bulk_GPa=float(bulk),
            )
            if a is not None:
                thermo["alpha_300K_per_K"] = a
                thermo["alpha_source"] = gamma_src if gamma_src == "gruneisen_mean" else "slater_gamma_0.5_estimate"

    # --- Cp @ 300 K ------------------------------------------------------
    if thermo.get("Cp_300K_Ry_per_K") is None:
        cv = thermo.get("Cv_300K_Ry_per_K")
        alpha = thermo.get("alpha_300K_per_K")
        vol = _resolve_volume_bohr3(work_dir, results)
        bulk = _resolve_bulk_GPa(results)
        if cv is not None:
            if alpha is not None and vol and bulk:
                cp = cp_from_cv_correction(
                    cv_Ry_per_K=float(cv),
                    alpha_per_K=float(alpha),
                    volume_bohr3=float(vol),
                    bulk_GPa=float(bulk),
                    T_K=300.0,
                )
                if cp is not None:
                    thermo["Cp_300K_Ry_per_K"] = cp
                    thermo["Cp_source"] = "Cv_plus_TValpha2B"
            else:
                thermo["Cp_300K_Ry_per_K"] = float(cv)
                thermo["Cp_source"] = "Cp_equals_Cv_no_alpha"

    # --- α(T) depuis Grüneisen si Cv(T)+B(T) sans α explicite ------------
    T_curve = thermo.get("curve_T_K") or []
    Cv_curve = thermo.get("curve_Cv_Ry_per_K") or []
    B_curve = thermo.get("curve_B_GPa") or []
    if (
        T_curve
        and Cv_curve
        and B_curve
        and not thermo.get("curve_alpha_per_K")
        and thermo.get("alpha_300K_per_K") is None
    ):
        vol = _resolve_volume_bohr3(work_dir, results)
        gamma = _get_nested(results, "ph_life.gruneisen_mean")
        if gamma is None and thermo.get("debye_temperature_K"):
            gamma = 0.5
        if vol and gamma is not None:
            a_curve = alpha_curve_from_gruneisen(
                curve_T_K=[float(x) for x in T_curve],
                curve_Cv_Ry_per_K=list(Cv_curve),
                curve_B_GPa=list(B_curve),
                volume_bohr3=float(vol),
                gamma=float(gamma),
            )
            if any(a is not None for a in a_curve):
                thermo["curve_alpha_T_K"] = [float(x) for x in T_curve]
                thermo["curve_alpha_per_K"] = a_curve
                for t, a in zip(T_curve, a_curve):
                    if a is not None and abs(float(t) - 300.0) <= 60.0:
                        thermo["alpha_300K_per_K"] = a
                        thermo["alpha_source"] = "gruneisen_alpha_vs_T"
                        break

    # --- Cp(T) depuis Cv(T) + α (+ B(T) si disponible) -------------------
    if T_curve and Cv_curve and (force or not thermo.get("curve_Cp_Ry_per_K")):
        vol = _resolve_volume_bohr3(work_dir, results)
        bulk = _resolve_bulk_GPa(results)
        alpha = thermo.get("alpha_300K_per_K")
        cp_curve, cp_src = compute_cp_temperature_curve(
            curve_T_K=[float(x) for x in T_curve],
            curve_Cv_Ry_per_K=list(Cv_curve),
            alpha_300K_per_K=float(alpha) if alpha is not None else None,
            volume_bohr3=float(vol) if vol else 0.0,
            bulk_GPa=float(bulk) if bulk else 0.0,
            curve_alpha_T_K=thermo.get("curve_alpha_T_K"),
            curve_alpha_per_K=thermo.get("curve_alpha_per_K"),
            curve_B_GPa=list(B_curve) if B_curve else None,
        )
        if cp_curve:
            thermo["curve_Cp_Ry_per_K"] = cp_curve
            thermo["Cp_curve_source"] = cp_src
            # Cp @ 300 K depuis la courbe si plus cohérent
            for t, cp in zip(T_curve, cp_curve):
                if cp is not None and abs(float(t) - 300.0) <= 60.0:
                    thermo["Cp_300K_Ry_per_K"] = cp
                    if thermo.get("Cp_source") in (None, "Cp_equals_Cv_no_alpha"):
                        thermo["Cp_source"] = cp_src
                    break

    # --- ε₀ via LST (LO/TO) ----------------------------------------------
    if dielectric.get("epsilon_static_average") is None:
        eps_inf = dielectric.get("epsilon_average")
        lo = dielectric.get("lo_freq_cm-1")
        to = dielectric.get("to_freq_cm-1")
        eps0 = epsilon_static_from_lst(eps_inf, lo, to)
        if eps0 is not None:
            dielectric["epsilon_static_average"] = eps0
            dielectric["epsilon_static_source"] = "lyddane_sachs_teller"
            if eps_inf and eps_inf > 0:
                dielectric["epsilon_static_anisotropy_ratio"] = eps0 / eps_inf


__all__ = [
    "enrich_thermo_and_dielectric",
    "parse_thermal_expansion_from_text",
    "alpha_from_gruneisen",
    "alpha_curve_from_gruneisen",
    "cp_from_cv_correction",
    "compute_cp_temperature_curve",
    "write_cv_cp_dat",
    "epsilon_static_from_lst",
]

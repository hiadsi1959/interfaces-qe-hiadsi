"""
Parse colonnes thermodynamiques depuis les sorties thermo_pw :

  * ``therm_files/output_therm.dat*`` (Cv, F, S) — délégué à ``thermo_therm_dat`` ;
  * ``thermo.out``, ``qha.out`` (tableaux QHA / anharmonique si présents) ;
  * ``*.dw`` (dérivées secondes, ex. ``B_33(T)``).

Expose ``merge_thermo_curves(work_dir, results)`` pour alimenter ``results['thermo']``
avec ``curve_T_K``, ``curve_Cv_Ry_per_K``, ``curve_alpha_per_K``, ``curve_B_GPa``,
``curve_Cp_Ry_per_K`` (Cp explicite si colonne présente, sinon laissé à
``thermo_derived.enrich_thermo_and_dielectric``).
"""
from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Any, Optional

from parsers.thermo_therm_dat import parse_therm_dat, parse_therm_dat_file, pick_central_geometry, find_therm_dat_files

_KBAR_TO_GPA = 0.1

_RE_ZPE = re.compile(
    r"(?i)zero\s*point\s*energy\s*:\s*([-+]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\s*Ry"
)

# En-têtes de colonnes reconnus (token normalisé → clé interne).
_COL_ALIASES: dict[str, str] = {
    "t": "T",
    "temp": "T",
    "temperature": "T",
    "cv": "Cv",
    "cp": "Cp",
    "alpha": "alpha",
    "alphav": "alpha",
    "bulk": "B",
    "b": "B",
    "b33": "B",
    "bulkmodulus": "B",
    "freeenergy": "F",
    "f": "F",
    "entropy": "S",
    "s": "S",
    "energy": "E",
    "e": "E",
}


def _f(token: str) -> Optional[float]:
    s = str(token).strip().replace("D", "E").replace("d", "e")
    if not s:
        return None
    try:
        v = float(s)
    except ValueError:
        return None
    if math.isnan(v) or math.isinf(v):
        return None
    return v


def _norm_header_token(tok: str) -> str:
    return re.sub(r"[^a-z0-9]", "", tok.lower())


def _parse_header_columns(header_line: str) -> list[tuple[int, str]]:
    """Retourne [(col_index, key)] pour une ligne ``# T  Cv  alpha ...``."""
    body = header_line.lstrip("#").strip()
    parts = re.split(r"\s+", body)
    out: list[tuple[int, str]] = []
    data_col = 0
    for raw in parts:
        if re.match(r"^\([^)]+\)$", raw):
            continue
        key = _COL_ALIASES.get(_norm_header_token(raw))
        if key:
            out.append((data_col, key))
        data_col += 1
    return out


def parse_generic_thermo_table(path: Path, *, max_curve_points: int = 200) -> dict[str, Any]:
    """Parse un fichier colonnes thermo_pw (``.dat``, ``thermo.out``, ``qha.out``)."""
    out: dict[str, Any] = {
        "source_file": path.name,
        "zero_point_energy_Ry": None,
        "curve_T_K": [],
        "curve_Cv_Ry_per_K": [],
        "curve_Cp_Ry_per_K": [],
        "curve_alpha_per_K": [],
        "curve_B_GPa": [],
        "curve_F_Ry": [],
        "Cv_300K_Ry_per_K": None,
        "Cp_300K_Ry_per_K": None,
        "alpha_300K_per_K": None,
        "B_300K_GPa": None,
    }
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as ex:
        out["error"] = str(ex)
        return out

    col_map: list[tuple[int, str]] = []
    rows_raw: list[list[Optional[float]]] = []

    for ln in text.splitlines():
        ls = ln.strip()
        if not ls:
            continue
        if ls.startswith("#"):
            m = _RE_ZPE.search(ls)
            if m and out["zero_point_energy_Ry"] is None:
                out["zero_point_energy_Ry"] = _f(m.group(1))
            if re.search(r"(?i)\bT\b", ls) and (
                re.search(r"(?i)\bCv\b|\bCp\b|\balpha\b|\bB\b|\bentropy\b|\bfree\b", ls)
                or "energy" in ls.lower()
            ):
                parsed = _parse_header_columns(ls)
                if parsed:
                    col_map = parsed
            continue
        toks = re.split(r"\s+", ls)
        if len(toks) < 2:
            continue
        row = [_f(t) for t in toks]
        if row[0] is None or row[0] < 0:
            continue
        rows_raw.append(row)

    if not rows_raw:
        return out

    # Format fixe output_therm.dat : T, E, F, S, Cv (5 colonnes).
    if not col_map and rows_raw and len(rows_raw[0]) >= 5:
        col_map = [(0, "T"), (2, "F"), (4, "Cv")]

    if not col_map:
        return out

    keyed_rows: list[dict[str, Optional[float]]] = []
    for row in rows_raw:
        item: dict[str, Optional[float]] = {}
        for idx, key in col_map:
            if idx < len(row):
                item[key] = row[idx]
        if item.get("T") is not None:
            keyed_rows.append(item)

    if not keyed_rows:
        return out

    keyed_rows.sort(key=lambda r: float(r["T"]))  # type: ignore[arg-type]
    step = max(1, len(keyed_rows) // max_curve_points)
    sampled = keyed_rows[::step]

    def _series(key: str) -> list[Optional[float]]:
        return [r.get(key) for r in sampled]

    out["curve_T_K"] = [float(r["T"]) for r in sampled]  # type: ignore[arg-type]
    out["curve_Cv_Ry_per_K"] = _series("Cv")
    out["curve_Cp_Ry_per_K"] = _series("Cp")
    out["curve_alpha_per_K"] = _series("alpha")
    out["curve_B_GPa"] = _series("B")
    out["curve_F_Ry"] = _series("F")

    closest = min(keyed_rows, key=lambda r: abs(float(r["T"]) - 300.0))  # type: ignore[arg-type]
    if abs(float(closest["T"]) - 300.0) <= 75.0:  # type: ignore[arg-type]
        out["Cv_300K_Ry_per_K"] = closest.get("Cv")
        out["Cp_300K_Ry_per_K"] = closest.get("Cp")
        out["alpha_300K_per_K"] = closest.get("alpha")
        b300 = closest.get("B")
        if b300 is not None:
            out["B_300K_GPa"] = float(b300)

    return out


def find_named_thermo_out_files(work_dir: Path) -> list[Path]:
    """``thermo.out``, ``qha.out`` et variantes sous work_dir."""
    work_dir = Path(work_dir).resolve()
    names = ("thermo.out", "qha.out", "output_thermo.out", "output_qha.out")
    found: list[Path] = []
    seen: set[str] = set()
    for g in names:
        for p in (work_dir / g,):
            if p.is_file():
                k = str(p.resolve())
                if k not in seen:
                    seen.add(k)
                    found.append(p)
    for g in ("**/thermo.out", "**/qha.out"):
        for p in sorted(work_dir.glob(g)):
            if p.is_file():
                k = str(p.resolve())
                if k not in seen:
                    seen.add(k)
                    found.append(p)
    return found


def find_thermo_dw_files(work_dir: Path) -> list[Path]:
    """Fichiers ``*.dw`` avec colonnes bulk (``B_33``, ``B``, …)."""
    work_dir = Path(work_dir).resolve()
    out: list[Path] = []
    seen: set[str] = set()
    for g in ("therm_files/*.dw", "**/output_therm*.dw", "**/*.dw"):
        for p in sorted(work_dir.glob(g)):
            if not p.is_file():
                continue
            k = str(p.resolve())
            if k in seen:
                continue
            seen.add(k)
            try:
                head = p.read_text(encoding="utf-8", errors="replace")[:400]
            except OSError:
                continue
            if re.search(r"(?i)\bB_?33\b|\bbulk\b|\bB\b", head):
                out.append(p)
    return out


def parse_thermo_dw_bulk(path: Path, *, max_curve_points: int = 200) -> dict[str, Any]:
    """Parse ``output_therm.dat*.dw`` → ``curve_T_K``, ``curve_B_raw`` (unités fichier)."""
    out: dict[str, Any] = {
        "source_file": path.name,
        "bulk_column": None,
        "curve_T_K": [],
        "curve_B_raw": [],
    }
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as ex:
        out["error"] = str(ex)
        return out

    col_idx = 1
    for ln in text.splitlines():
        ls = ln.strip()
        if ls.startswith("#"):
            parts = re.split(r"\s+", ls.lstrip("#").strip())
            for i, tok in enumerate(parts):
                if re.search(r"(?i)^B_?33$|^B$|bulk", tok):
                    col_idx = i
                    out["bulk_column"] = tok
                    break
            continue
        toks = re.split(r"\s+", ls)
        if len(toks) <= col_idx:
            continue
        t, b = _f(toks[0]), _f(toks[col_idx])
        if t is None or b is None or t < 0:
            continue
        out["curve_T_K"].append(t)
        out["curve_B_raw"].append(b)

    if not out["curve_T_K"]:
        return out

    pairs = sorted(zip(out["curve_T_K"], out["curve_B_raw"]))
    out["curve_T_K"] = [p[0] for p in pairs]
    out["curve_B_raw"] = [p[1] for p in pairs]
    step = max(1, len(pairs) // max_curve_points)
    out["curve_T_K"] = out["curve_T_K"][::step]
    out["curve_B_raw"] = out["curve_B_raw"][::step]
    return out


def _calibrate_B_raw_to_GPa(
    curve_T_K: list[float],
    curve_B_raw: list[float],
    *,
    ref_B_GPa: Optional[float],
) -> list[Optional[float]]:
    """Échelle ``B_raw`` pour coïncider avec ``ref_B_GPa`` @ 300 K."""
    if not curve_T_K or len(curve_T_K) != len(curve_B_raw):
        return []
    if ref_B_GPa is None or ref_B_GPa <= 0:
        # Heuristique : si max < 20, traiter comme Mbar → GPa (×100).
        scale = 100.0 if max(curve_B_raw) < 20.0 else 1.0
        return [b * scale if b is not None else None for b in curve_B_raw]

    idx = min(range(len(curve_T_K)), key=lambda i: abs(curve_T_K[i] - 300.0))
    b_ref_raw = curve_B_raw[idx]
    if b_ref_raw is None or b_ref_raw <= 0:
        scale = _KBAR_TO_GPA * 1000.0  # kbar → GPa via Mbar-like
        return [b * scale if b is not None else None for b in curve_B_raw]
    scale = ref_B_GPa / float(b_ref_raw)
    return [b * scale if b is not None else None for b in curve_B_raw]


def _resolve_ref_bulk_GPa(results: dict[str, Any]) -> Optional[float]:
    eos = results.get("eos") or {}
    if isinstance(eos, dict) and eos.get("B0_GPa") is not None:
        return float(eos["B0_GPa"])
    el = results.get("elastic") or {}
    if isinstance(el, dict) and el.get("bulk_modulus_GPa") is not None:
        return float(el["bulk_modulus_GPa"])
    thermo = results.get("thermo") or {}
    if isinstance(thermo, dict) and thermo.get("B_300K_GPa") is not None:
        return float(thermo["B_300K_GPa"])
    return None


def _merge_curve(
    base_T: list[float],
    base_vals: list[Optional[float]],
    new_T: list[float],
    new_vals: list[Optional[float]],
) -> list[Optional[float]]:
    """Aligne ``new_vals`` sur la grille ``base_T`` (nearest-neighbour)."""
    if not base_T or not new_T or not new_vals:
        return base_vals
    out: list[Optional[float]] = []
    for t in base_T:
        j = min(range(len(new_T)), key=lambda i: abs(new_T[i] - t))
        out.append(new_vals[j] if abs(new_T[j] - t) <= 80.0 else None)
    return out


def merge_thermo_curves(work_dir: Path, results: dict[str, Any]) -> dict[str, Any]:
    """
    Agrège T, Cv, α, B, Cp depuis disque. Ne modifie pas ``results`` in-place ;
    renvoie un dict plat ``thermo.*`` à merger par le pipeline.
    """
    work_dir = Path(work_dir).resolve()
    merged: dict[str, Any] = {}

    # 1. output_therm.dat* (référence Cv/F/S).
    tdat = parse_therm_dat(work_dir)
    if tdat.get("source_file"):
        for k in (
            "zero_point_energy_Ry", "Cv_300K_Ry_per_K", "F_300K_Ry",
            "entropy_300K_Ry_per_K", "T_min_K", "T_max_K", "n_T_points",
            "curve_T_K", "curve_Cv_Ry_per_K", "curve_F_Ry", "source_file",
        ):
            v = tdat.get(k)
            if v is not None:
                merged[k if k != "source_file" else "therm_source_file"] = v

    # 2. thermo.out / qha.out (Cp, α, B explicites si présents).
    for path in find_named_thermo_out_files(work_dir):
        parsed = parse_generic_thermo_table(path)
        if not parsed.get("curve_T_K"):
            continue
        try:
            rel = path.resolve().relative_to(work_dir).as_posix()
        except ValueError:
            rel = path.name
        merged["qha_out_source_file"] = rel
        T = parsed["curve_T_K"]
        if not merged.get("curve_T_K"):
            merged["curve_T_K"] = T
        for ck, pk in (
            ("curve_Cv_Ry_per_K", "Cv"),
            ("curve_Cp_Ry_per_K", "Cp"),
            ("curve_alpha_per_K", "alpha"),
            ("curve_B_GPa", "B"),
        ):
            src = parsed.get(ck) or []
            if any(v is not None for v in src):
                merged[ck] = _merge_curve(
                    merged.get("curve_T_K") or T,
                    merged.get(ck) or [None] * len(merged.get("curve_T_K") or T),
                    T,
                    src,
                )
        for sk, dk in (
            ("Cv_300K_Ry_per_K", "Cv_300K_Ry_per_K"),
            ("Cp_300K_Ry_per_K", "Cp_300K_Ry_per_K"),
            ("alpha_300K_per_K", "alpha_300K_per_K"),
            ("B_300K_GPa", "B_300K_GPa"),
        ):
            if parsed.get(sk) is not None and merged.get(dk) is None:
                merged[dk] = parsed[sk]
        if parsed.get("Cp_300K_Ry_per_K") is not None:
            merged["Cp_source"] = "qha_out_column"
        if parsed.get("alpha_300K_per_K") is not None:
            merged["alpha_source"] = "qha_out_column"

    # 3. B(T) depuis *.dw (prioritaire si pas déjà une courbe B).
    if not merged.get("curve_B_GPa"):
        ref_B = _resolve_ref_bulk_GPa(results)
        for dw in find_thermo_dw_files(work_dir):
            pdw = parse_thermo_dw_bulk(dw)
            if not pdw.get("curve_T_K"):
                continue
            b_gpa = _calibrate_B_raw_to_GPa(
                pdw["curve_T_K"],
                pdw["curve_B_raw"],
                ref_B_GPa=ref_B,
            )
            if not b_gpa:
                continue
            T_grid = merged.get("curve_T_K") or pdw["curve_T_K"]
            merged["curve_B_GPa"] = _merge_curve(
                T_grid,
                [None] * len(T_grid),
                pdw["curve_T_K"],
                b_gpa,
            )
            if not merged.get("curve_T_K"):
                merged["curve_T_K"] = pdw["curve_T_K"]
            try:
                merged["bulk_T_source_file"] = dw.resolve().relative_to(work_dir).as_posix()
            except ValueError:
                merged["bulk_T_source_file"] = dw.name
            merged["bulk_T_column"] = pdw.get("bulk_column")
            break

    return merged


__all__ = [
    "merge_thermo_curves",
    "parse_generic_thermo_table",
    "parse_thermo_dw_bulk",
    "find_named_thermo_out_files",
    "find_thermo_dw_files",
]

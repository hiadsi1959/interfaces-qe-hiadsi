"""
``backend.factsheet_ai`` — moteur expert rule-based pour la fiche technique.

Le module ``assemble_factsheet`` produit une fiche **descriptive** (les valeurs
brutes). Ce module produit une fiche **interprétative** — il transforme les
mêmes données en **insights** pédagogiques pour un chercheur : classification
physique, alertes de stabilité, comparaisons aux critères classiques, suggestions
d'applications possibles.

Approche : rule-based, déterministe, offline, sans dépendance externe. On évite
le recours à un LLM (pas de clé API, pas d'internet requis). Le moteur est
explicable : chaque insight cite les ``source_keys`` dont il est issu, ce qui
permet à l'utilisateur de remonter à la valeur dans le marker ``pipeline_api_
job_state.json``.

Catégories d'insight :
  * ``structure``      — paramètres de maille, classification cristallographique
  * ``elasticity``     — Born stability, Pugh (ductilité), Zener (anisotropie)
  * ``electronic``     — gap, VBM/CBM, type et applicabilité (photovoltaïque…)
  * ``phonon``         — stabilité dynamique + mode acoustique mou
  * ``lifetime``       — anharmonicité, durée de vie phonons (P4)
  * ``dielectric``     — ε∞, indice réfraction n, ferroélectricité
  * ``magnetism``      — régime spin-polarisé et moments
  * ``synthesis``      — résumé global + recommandations

Sévérités :
  * ``success``  ✅ — la propriété est dans la plage saine attendue
  * ``info``     🔵 — observation neutre (couleur informative)
  * ``warning``  🟡 — valeur hors plage typique (à vérifier manuellement)
  * ``error``    🔴 — critère physique violé (stabilité / bornes thermodynamiques)

Format de sortie : ``list[Insight]`` — ordre déterministe pour reproductibilité
(rendu MD/HTML stable pour un même run).
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

# Bornes et seuils (en haut de fichier pour ajustement facile).
PI = math.pi

# Facteurs géométriques pour convertir un volume d'équilibre V₀ (bohr³) en
# paramètre de maille a (Å) selon la maille de Bravais / convention QE.
# Les formules ci-dessous utilisent la maille conventionnelle associée à
# l'indice ibrav, ce qui est important pour les structures centrées (FCC/BCC)
# et les réseaux non cubiques.
_IBRAV_TO_N_ATOMS = {
    1: 1,   # SC
    2: 4,   # FCC
    3: 2,   # BCC
}

# Aliases négatifs utilisés par QE pour décrire des centrages alternatifs
# (convention identique à leur équivalent positif en formule de volume) :
#   ibrav=-3  ≡ ibrav=2   (FCC)
#   ibrav=-9  ≡ ibrav=9   (orthorhombique base-centered)
#   ibrav=-12 ≡ ibrav=12  (monoclinique base-centered)
#   ibrav=-13 ≡ ibrav=13  (monoclinique base-centered)
# (cf. INPUT_PW.html — voir aussi https://www.quantum-espresso.org/Docs/INPUT_PW.html)
_IBRAV_ALIASES: dict[int, int] = {
    -3: 2, -9: 9, -12: 12, -13: 13,
}


# Volume d'équilibre mesuré par le fit EOS Birch-Murnaghan (V₀ en bohr³, primitive).
def _lattice_parameter_from_v0(
    v0_bohr3: float,
    *,
    ibrav: Optional[int] = None,
    n_atoms_per_conventional_cell: Optional[int] = None,
) -> Optional[float]:
    r"""Retourne le paramètre de maille a (Å) depuis V₀ selon la géométrie de maille.

    La convention utilisée suit la logique de Quantum ESPRESSO :
    - ibrav 1 (cubic primitive) : V = a^3
    - ibrav 2 (FCC) : V = 4 a^3 (maille conventionnelle)
    - ibrav 3 (BCC) : V = 2 a^3
    - ibrav 4 (hexagonal) : V = (\sqrt{3}/2) a^2 c ; si c/a non fourni, on
      suppose c = a (hexagonal simple) et on prend a = (2V/\sqrt{3})^(1/3)
    - ibrav 6 (tetragonal simple) : V = a^2 c ; si c/a non fourni, on prend c = a
      et a = V^(1/3)
    - ibrav 7 (body-centered tetragonal) : V = 2 a^2 c ; si c=a, a = (V/2)^(1/3)
    - ibrav 8/9/10/11 (orthorhombic) : V = a b c ; on suppose a=b=c si pas de
      ratios fournis, ce qui donne a = V^(1/3)
    - ibrav 12/13/14 (monoclinic/triclinic) : repli sur V^(1/3).
    """
    try:
        v0 = float(v0_bohr3)
    except (TypeError, ValueError):
        return None
    if v0 <= 0.0:
        return None

    # Conversion bohr³ → Å³.
    v_ang3 = v0 * (0.529177210903 ** 3)

    if ibrav == 2:
        # FCC : maille conventionnelle contient 4 atomes, V = 4 a^3.
        factor = 4.0 if n_atoms_per_conventional_cell in (None, 4) else 1.0
        return (v_ang3 * factor) ** (1.0 / 3.0)

    if ibrav == 3:
        # BCC : V = 2 a^3.
        return (v_ang3 * 2.0) ** (1.0 / 3.0)

    if ibrav == 4:
        # Hexagonal simple : V = (√3/2) a^2 c ; si c ≈ a => V = (√3/2) a^3.
        return (2.0 * v_ang3 / math.sqrt(3.0)) ** (1.0 / 3.0)

    if ibrav in (6, 8, 9, 10, 11, 12, 13, 14):
        return v_ang3 ** (1.0 / 3.0)

    if ibrav == 7:
        return (v_ang3 * 2.0) ** (1.0 / 3.0)

    return v_ang3 ** (1.0 / 3.0)


# ============================================================================
# Lecture scf.in pour paramètres de maille (ibrav + celldm(1..6) + CELL_PARAMETERS)
# ============================================================================
# QE namelist ``&SYSTEM`` expose jusqu'à 6 paramètres ``celldm`` (en bohr sauf
# ibrav=1 où ``celldm(1)`` est en *alat* = Å). Les conventions précises par
# ibrav sont listées dans INPUT_PW.html :
#   ibrav=0  : libre : ``CELL_PARAMETERS { alat | bohr | angstrom }`` imposing
#              les 3 vecteurs primitives + leurs unités.
#   ibrav=1  : SC — celldm(1) = a en Å.
#   ibrav=2  : FCC — celldm(1) = a en bohr (a primitive = celldm/sqrt(2) en Maille conv. QE).
#   ibrav=3  : BCC — celldm(1) = a en bohr.
#   ibrav=4  : hex — celldm(1)=a (bohr), celldm(3)=c/a.
#   ibrav=6  : tet P — celldm(1)=a (bohr), celldm(3)=c/a.
#   ibrav=7  : BCT — celldm(1)=a, celldm(3)=c/a.
#   ibrav=8  : ortho P — celldm(1)=a, celldm(2)=b/a, celldm(3)=c/a.
#   ibrav=9  : ortho base-centered — idem ibrav=8 + centering.
#   ibrav=10 : ortho face-centered — idem + centering.
#   ibrav=11 : ortho body-centered — idem + centering.
#   ibrav=12 : mono P — celldm(1)=a, celldm(2)=b/a, celldm(3)=c/a, celldm(4)=cos(alpha).
#   ibrav=13 : mono base-centered — idem ibrav=12 + centering.
#   ibrav=14 : triclinic P — celldm(1..6) = a, b/a, c/a, cos(α), cos(β), cos(γ).
# ============================================================================

# Regex tolérantes : espaces optionnels autour de ``=`` et virgule finale tolérée.
# Pattern compact mais strict — ne capture QUE des scalaires Fortran (avec D/d
# d'exposant). Cas spéciaux (logarithmes, expressions) non gérés exprès.
_RX_IBRAV = re.compile(
    r"(?im)^\s*ibrav\s*=\s*(-?\d+)\b\s*,?\s*$"
)
_RX_NAT = re.compile(
    r"(?im)^\s*nat\s*=\s*(\d+)\b\s*,?\s*$"
)
_RX_CELLDM_i = lambda i: re.compile(
    rf"(?im)^\s*celldm\s*\(\s*{i}\s*\)\s*=\s*"
    r"([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\b\s*,?\s*$"
)
_RX_CELL_PARAMS_HEAD = re.compile(
    r"(?im)^\s*CELL_PARAMETERS\s*(\{?\s*(?:alat|bohr|angstrom)\s*\}?)?\s*$"
)
_RX_CELL_PARAMS_LINE = re.compile(
    r"(?im)^\s*"
    r"([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\s+"
    r"([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\s+"
    r"([+-]?\d*\.?\d+(?:[EeDd][+-]?\d+)?)\s*$"
)


def _read_ibrav_celldm_and_cell_params(work_dir: Path) -> dict[str, Any]:
    """Lit ``scf.in`` et extrait ``ibrav``, ``celldm(1..6)`` et ``CELL_PARAMETERS``.

    Retourne un dict typé :
        {
            "ibrav":         Optional[int],
            "celldm":        list[Optional[float]] de longueur 6 (None si absent),
            "cell_vectors":  Optional[list[tuple[float, float, float]]],
            "cell_unit":     Optional[str]    # "alat" | "bohr" | "angstrom"
            "nat":           Optional[int],
        }

    Robuste :
        * ``scf.in`` absent : tous les champs ``None`` / listes vides.
        * ``CELLDM`` partiel : les indices lus seulement.
        * ``CELL_PARAMETERS`` absent : ``cell_vectors=None``.
        * Unités non déclarées → ``cell_unit="bohr"`` (convention QE par défaut,
          cf. INPUT_PW.html — la position DEFAULT de CELL_PARAMETERS est en
          *bohr*).

    Lève ``OSError`` si ``scf.in`` est inaccessible (lecture impossible), ne
    lève PAS sur contenu absent (qui est déjà couvert par ``is_file()``).
    """
    out: dict[str, Any] = {
        "ibrav": None,
        "celldm": [None] * 6,
        "cell_vectors": None,
        "cell_unit": None,
        "nat": None,
    }
    scf = work_dir / "scf.in"
    if not scf.is_file():
        return out
    try:
        text = scf.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return out
    if not text or not text.strip():
        return out

    m = _RX_IBRAV.search(text)
    if m:
        try:
            raw_ibrav = int(m.group(1))
            # Normalisation des alias négatifs au boundary : toutes les routines
            # en aval ne voient que des ibrav strictement positifs canoniques.
            out["ibrav"] = _IBRAV_ALIASES.get(raw_ibrav, raw_ibrav)
            if raw_ibrav != out["ibrav"]:
                # On conserve la trace dans un champ séparé pour debug.
                out["ibrav_raw"] = raw_ibrav
        except ValueError:
            pass

    m = _RX_NAT.search(text)
    if m:
        try:
            out["nat"] = int(m.group(1))
        except ValueError:
            pass

    for i in (1, 2, 3, 4, 5, 6):
        m = _RX_CELLDM_i(i).search(text)
        if m:
            try:
                out["celldm"][i - 1] = float(
                    m.group(1).replace("D", "E").replace("d", "e")
                )
            except (ValueError, IndexError):
                continue

    # CELL_PARAMETERS : on cherche le header puis on lit les 3 lignes suivantes.
    m = _RX_CELL_PARAMS_HEAD.search(text)
    if m:
        unit_token = (m.group(1) or "bohr").lower()
        # Retirer les accolades/espaces du token (déjà matchés, mais on simplifie).
        out["cell_unit"] = unit_token.replace("{", "").replace("}", "").strip() or "bohr"
        idx = m.end()
        # ``text[idx:]`` peut encore contenir \n en début — on l'absorbe.
        tail = text[idx:].splitlines()
        vecs: list[tuple[float, float, float]] = []
        for ln in tail:
            mp = _RX_CELL_PARAMS_LINE.match(ln)
            if mp:
                try:
                    vecs.append((
                        float(mp.group(1).replace("D", "E").replace("d", "e")),
                        float(mp.group(2).replace("D", "E").replace("d", "e")),
                        float(mp.group(3).replace("D", "E").replace("d", "e")),
                    ))
                except ValueError:
                    continue
            elif vecs and len(vecs) < 3:
                # Ligne non numérique au milieu : on arrête la collecte.
                break
            if len(vecs) == 3:
                break
        if len(vecs) == 3:
            out["cell_vectors"] = vecs
    return out


# ============================================================================
# _lattice_parameter_angstrom — paramètres de maille complets (a, b, c, α, β, γ)
# ============================================================================
# Cette fonction est la facade publique au calcul ``a (Å)`` initialement fait
# par ``_lattice_parameter_from_v0`` (réduit à ``a`` pour les mailles cubiques).
# Avantages par rapport à l'ancien helper :
#   * Retourne a, b, c, α, β, γ — utile pour mailles anisotropes (ortho, mono,
#     triclinic, hex avec c/a, tetr P/BCT avec c/a).
#   * Lit ``celldm(1..6)`` et applique la bonne formule de volume par ibrav
#     (cf. https://www.quantum-espresso.org/Docs/INPUT_PW.html, formule par
#     type de Bravais).
#   * En cas d'``ibrav=0`` avec ``CELL_PARAMETERS`` en ``bohr``/``Å``/``alat``
#     (unités explicites ou implicites — ``bohr`` par défaut), extrait
#     directement les 3 vecteurs primitives et calcule les 6 paramètres.
#   * Émet une ``note`` diagnostique si ``v0_bohr3`` diffère notablement du
#     volume calculé depuis ``CELLDM`` ou ``CELL_PARAMETERS`` (relaxation
#     ionique, scaling négligé).
# ============================================================================

def _lattice_parameter_angstrom(
    work_dir: Path,
    *,
    v0_bohr3: Optional[float] = None,
) -> dict[str, Any]:
    """Parameters de maille en Å depuis ``scf.in`` (avec validation optionnelle V₀).

    Args:
        work_dir: répertoire du run (lit ``scf.in``).
        v0_bohr3: volume d'équilibre V₀ du fit EOS Birch-Murnaghan (bohr³,
            volume de la maille *primitive*). Si fourni, on l'utilise pour
            vérifier la cohérence avec le V calculé depuis ``celldm`` ou
            ``CELL_PARAMETERS``.

    Returns:
        Dict avec :
          ``a_ang``, ``b_ang``, ``c_ang`` : normes des vecteurs primitives en
              Å (``None`` si indéterminable) ;
          ``alpha_deg``, ``beta_deg``, ``gamma_deg`` : angles entre vecteurs (
              degrés) ;
          ``v_ang3`` : volume primitive calculé depuis ``CELL_PARAMETERS`` /
              ``celldm`` (Å³) — distinct du V₀ EOS ;
          ``ibrav`` : ``int|None`` ;
          ``source`` : ``"cell_parameters"`` | ``"celldm"`` | ``"v0_ibrav_guess"``
              | ``"none"`` — méthode ayant fourni les paramètres ;
          ``v0_bohr3_input`` : V₀ reçu en entrée (écho) ;
          ``note`` : ``str|None`` (info/warnings cohérences V₀) ;
          ``celldm_used`` : list des celldm utilisés (utile en log/diagnostic).

    Logique de priorité :
      1. ``ibrav=0`` avec ``CELL_PARAMETERS`` → extraction directe des vecteurs
         primitives, calcul des 6 paramètres via normes/angles, volume par
         produit mixte ``V = a₁·(a₂×a₃)``.
      2. ``ibrav > 0`` avec ``celldm`` → application des formules QE
         documentées (cf. INPUT_PW.html et tableau ``_IBRAV_TO_FAMILY``).
         Validation V₀ vs V calculé si ``v0_bohr3`` fourni.
      3. Repli (``v0_bohr3`` fourni mais aucune donnée explicite) → utilise
         ``_lattice_parameter_from_v0`` avec hypothèse ``c=a, b=a, angles
         droits``. Source = ``"v0_ibrav_guess"`` — peu fiable, signalée
         dans ``note``.
      4. Aucune donnée → dict vide avec ``source="none"``.
    """
    BOHR_TO_ANG = 0.529177210903  # CODATA — cohérence avec phonon_chain_qe

    res: dict[str, Any] = {
        "a_ang": None, "b_ang": None, "c_ang": None,
        "alpha_deg": None, "beta_deg": None, "gamma_deg": None,
        "v_ang3": None,
        "ibrav": None,
        "source": "none",
        "v0_bohr3_input": v0_bohr3,
        "note": None,
        "celldm_used": [None] * 6,
    }

    info = _read_ibrav_celldm_and_cell_params(work_dir)
    ibrav = info["ibrav"]
    celldm = info["celldm"] or [None] * 6
    vecs_tuple = info["cell_vectors"]
    unit = info["cell_unit"]
    res["ibrav"] = ibrav
    res["celldm_used"] = list(celldm)

    # --------------------------------------------------------------------
    # 1. ibrav=0 + CELL_PARAMETERS présents → extraction directe des
    #    primitives. C'est le cas où on est le plus riche en information :
    #    `a`, `b`, `c` sont les normes des 3 vecteurs et les angles sont
    #    entre paires de vecteurs, indépendamment du système cristallin.
    # --------------------------------------------------------------------
    if ibrav == 0 and vecs_tuple and len(vecs_tuple) == 3:
        res["cell_unit"] = unit
        scale = BOHR_TO_ANG if unit != "angstrom" else 1.0
        v1 = tuple(c * scale for c in vecs_tuple[0])
        v2 = tuple(c * scale for c in vecs_tuple[1])
        v3 = tuple(c * scale for c in vecs_tuple[2])

        def _norm(u: tuple[float, float, float]) -> float:
            return math.sqrt(u[0] ** 2 + u[1] ** 2 + u[2] ** 2)

        def _angle_deg(u: tuple[float, float, float], v: tuple[float, float, float]) -> float:
            nu, nv = _norm(u), _norm(v)
            if nu <= 0.0 or nv <= 0.0:
                return float("nan")
            cos_t = (u[0] * v[0] + u[1] * v[1] + u[2] * v[2]) / (nu * nv)
            cos_t = max(-1.0, min(1.0, cos_t))
            return math.degrees(math.acos(cos_t))

        res["a_ang"] = _norm(v1)
        res["b_ang"] = _norm(v2)
        res["c_ang"] = _norm(v3)
        # Convention cristallographique standard : α entre b et c, β entre a et c, γ entre a et b.
        res["alpha_deg"] = _angle_deg(v2, v3)
        res["beta_deg"] = _angle_deg(v1, v3)
        res["gamma_deg"] = _angle_deg(v1, v2)
        res["v_ang3"] = abs(
            v1[0] * (v2[1] * v3[2] - v2[2] * v3[1])
            - v1[1] * (v2[0] * v3[2] - v2[2] * v3[0])
            + v1[2] * (v2[0] * v3[1] - v2[1] * v3[0])
        )
        res["source"] = "cell_parameters"
        if v0_bohr3 is not None and res["v_ang3"] is not None and res["v_ang3"] > 0:
            v_calc_bohr3 = res["v_ang3"] / (BOHR_TO_ANG ** 3)
            rel_err = abs(v_calc_bohr3 - v0_bohr3) / max(v0_bohr3, 1e-12)
            if rel_err > 0.01:
                res["note"] = (
                    f"V₀ EOS = {v0_bohr3:.2f} bohr³ ; "
                    f"V(CELL_PARAMETERS) = {v_calc_bohr3:.2f} bohr³ ; "
                    f"Δ = {100.0 * rel_err:.1f}% (relaxation ionique attendue)."
                )
        return res

    # --------------------------------------------------------------------
    # 2. ibrav > 0 avec celldm(1) → application des formules QE.
    #    Discrimination par famille cristalline via ``_IBRAV_TO_FAMILY``.
    # --------------------------------------------------------------------
    if ibrav is not None and ibrav > 0:
        a_bohr = celldm[0]
        if a_bohr is None or a_bohr <= 0:
            # Pas de celldm(1) → on ne peut pas calculer de paramètres fiables.
            res["note"] = (
                f"ibrav={ibrav} mais celldm(1) absent ou ≤0 ; "
                "repli possible uniquement sur V₀ avec hypothèse cubique."
            )
        else:
            # ibrav=1 : ``celldm(1)`` est en Å (alat), pas en bohr.
            # ibrav≥2 : ``celldm(1)`` est en bohr (a primitive).
            # NB : dans la pratique, les fichiers ``scf.in`` thermo_pw utilisent
            # toujours ``celldm(1)`` en bohr pour ibrav≥2 (cf. INPUT_PW.html
            # et tests phonon_chain_qe.test_p1_chain_continuity).
            a_ang = a_bohr if ibrav == 1 else a_bohr * BOHR_TO_ANG
            res["a_ang"] = a_ang
            res["b_ang"] = a_ang
            res["c_ang"] = a_ang
            res["alpha_deg"] = 90.0
            res["beta_deg"] = 90.0
            res["gamma_deg"] = 90.0

            # --- Application des ratios b/a, c/a, cos(α), cos(β), cos(γ) ---
            if ibrav == 4:
                # Hexagonale : a_in_plane + c orthogonal, primitive V = (√3/2)·a²·c.
                ca = celldm[2]
                if ca is not None:
                    res["c_ang"] = a_ang * ca
                    res["gamma_deg"] = 120.0
                    res["source"] = "celldm"
                    # Volume primitive : V = (√3/2) a² c (bohr³).
                    v_prim_bohr3 = (math.sqrt(3.0) / 2.0) * (a_bohr ** 2) * (a_bohr * ca)
                    res["v_ang3"] = v_prim_bohr3 * (BOHR_TO_ANG ** 3)
            elif ibrav == 6:
                # Tetragonale simple : V = a² c (bohr³).
                ca = celldm[2]
                if ca is not None:
                    res["c_ang"] = a_ang * ca
                    res["source"] = "celldm"
                    v_prim_bohr3 = (a_bohr ** 2) * (a_bohr * ca)
                    res["v_ang3"] = v_prim_bohr3 * (BOHR_TO_ANG ** 3)
            elif ibrav == 7:
                # Quadratique centrée (BCT) : V = a² c / 2 (bohr³).
                ca = celldm[2]
                if ca is not None:
                    res["c_ang"] = a_ang * ca
                    res["source"] = "celldm"
                    v_prim_bohr3 = (a_bohr ** 2) * (a_bohr * ca) / 2.0
                    res["v_ang3"] = v_prim_bohr3 * (BOHR_TO_ANG ** 3)
            elif ibrav in (8, 9, 10, 11):
                # Orthorhombique (P, C, F, I) — V = a·b·c ; centering divise.
                ba = celldm[1]
                ca = celldm[2]
                if ba is not None:
                    res["b_ang"] = a_ang * ba
                if ca is not None:
                    res["c_ang"] = a_ang * ca
                res["source"] = "celldm"
                # Volume primitive = a·b·c / centering_factor.
                if ba is not None and ca is not None:
                    centering = {8: 1, 9: 2, 10: 4, 11: 2}[ibrav]
                    v_prim_bohr3 = (a_bohr * a_bohr * ba * a_bohr * ca) / centering
                    res["v_ang3"] = v_prim_bohr3 * (BOHR_TO_ANG ** 3)
                    if ibrav != 8:
                        res["note"] = (
                            f"ibrav={ibrav} (ortho centrée) — maille conventionnelle ; "
                            f"V primitive / centering = {centering}."
                        )
            elif ibrav in (12, 13):
                # Monoclinique.
                ba = celldm[1]
                ca = celldm[2]
                cos_a = celldm[3]
                if ba is not None:
                    res["b_ang"] = a_ang * ba
                if ca is not None:
                    res["c_ang"] = a_ang * ca
                if cos_a is not None and abs(cos_a) <= 1.0:
                    angle = math.degrees(math.acos(cos_a))
                    res["alpha_deg"] = angle
                    res["gamma_deg"] = angle  # convention simplifiée mono P
                res["source"] = "celldm"
                if all(x is not None for x in (ba, ca, cos_a)):
                    v_prim_bohr3 = (
                        a_bohr * (a_bohr * ba) * (a_bohr * ca)
                        * math.sqrt(max(1.0 - cos_a * cos_a, 0.0))
                    )
                    res["v_ang3"] = v_prim_bohr3 * (BOHR_TO_ANG ** 3)
            elif ibrav == 5:
                # Rhomboédrique/trigonal : a = b = c, α = β = γ = arccos(celldm(4)).
                # Volume V = a^3 · √(1 − 3 cos²α + 2 cos³α).
                cos_a = celldm[3]
                if cos_a is not None and abs(cos_a) <= 1.0:
                    res["alpha_deg"] = math.degrees(math.acos(cos_a))
                    res["beta_deg"] = res["alpha_deg"]
                    res["gamma_deg"] = res["alpha_deg"]
                    res["source"] = "celldm"
                    # Volume primitif bohr³ : a^3·√(1 + 2c³ − 3c²) (c = cos α).
                    inside = 1.0 + 2.0 * cos_a ** 3 - 3.0 * cos_a ** 2
                    v_prim_bohr3 = (a_bohr ** 3) * math.sqrt(max(inside, 0.0))
                    res["v_ang3"] = v_prim_bohr3 * (BOHR_TO_ANG ** 3)
                else:
                    res["note"] = (
                        f"ibrav={ibrav} (trigonal) mais celldm(4)=cos(α) "
                        "absent ou hors [-1, 1]."
                    )
            elif ibrav == 14:
                # Triclinique — V = abc·√(1 − a² − b² − c² + 2abc) où a=cos(α) etc.
                ba = celldm[1]
                ca = celldm[2]
                cos_a = celldm[3]
                cos_b = celldm[4]
                cos_g = celldm[5]
                if ba is not None:
                    res["b_ang"] = a_ang * ba
                if ca is not None:
                    res["c_ang"] = a_ang * ca
                for cos_val, key in (
                    (cos_a, "alpha_deg"),
                    (cos_b, "beta_deg"),
                    (cos_g, "gamma_deg"),
                ):
                    if cos_val is not None and abs(cos_val) <= 1.0:
                        res[key] = math.degrees(math.acos(cos_val))
                res["source"] = "celldm"
                if all(x is not None for x in (ba, ca, cos_a, cos_b, cos_g)):
                    u, v, w = cos_a, cos_b, cos_g
                    inside = 1.0 + 2.0 * u * v * w - u * u - v * v - w * w
                    v_prim_bohr3 = (
                        a_bohr * (a_bohr * ba) * (a_bohr * ca)
                        * math.sqrt(max(inside, 0.0))
                    )
                    res["v_ang3"] = v_prim_bohr3 * (BOHR_TO_ANG ** 3)
            else:
                # Cubiques simples : ibrav=1 (SC, alat Å), 2 (FCC), 3 (BCC).
                res["source"] = "celldm"

            # Validation cohérence V₀ vs V calculé depuis celldm.
            if v0_bohr3 is not None and res["v_ang3"] is not None and res["v_ang3"] > 0:
                v_calc_bohr3 = res["v_ang3"] / (BOHR_TO_ANG ** 3)
                rel_err = abs(v_calc_bohr3 - v0_bohr3) / max(v0_bohr3, 1e-12)
                if rel_err > 0.01:
                    res["note"] = (
                        (res["note"] or "")
                        + f" V₀ EOS = {v0_bohr3:.2f} bohr³ ; "
                        f"V(celldm) = {v_calc_bohr3:.2f} bohr³ ; "
                        f"Δ = {100.0 * rel_err:.1f}%."
                    )
            return res

    # --------------------------------------------------------------------
    # 3. Repli : V₀ seul — appel à l'ancien helper cubique (avec hypothèse
    #    c=a, b=a, angles droits). Indicateur 'v0_ibrav_guess' dans ``source``.
    # --------------------------------------------------------------------
    if v0_bohr3 is not None and v0_bohr3 > 0:
        ibrav_old, n_per_cv, _nat = _read_ibrav_and_n_atoms(work_dir)
        a_ang = _lattice_parameter_from_v0(
            v0_bohr3,
            ibrav=ibrav_old,
            n_atoms_per_conventional_cell=n_per_cv,
        )
        if a_ang is not None:
            res["a_ang"] = a_ang
            res["b_ang"] = a_ang
            res["c_ang"] = a_ang
            res["alpha_deg"] = 90.0
            res["beta_deg"] = 90.0
            res["gamma_deg"] = 90.0
            res["source"] = "v0_ibrav_guess"
            res["note"] = (
                f"Pas de celldm(1) ni CELL_PARAMETERS — repli sur V₀ = "
                f"{v0_bohr3:.2f} bohr³ avec hypothèse c=a, b=a, angles droits."
            )
    return res


@dataclass
class Insight:
    """Insight pédagogique dérivé des résultats du run."""

    level: str  # "success" | "info" | "warning" | "error"
    category: str  # "structure" | "elasticity" | "electronic" | "phonon" | "lifetime" | "dielectric" | "magnetism" | "synthesis"
    title: str
    body: str
    source_keys: list[str] = field(default_factory=list)

    def icon(self) -> str:
        return {
            "success": "✅",
            "info": "🔵",
            "warning": "🟡",
            "error": "🔴",
        }.get(self.level, "•")


# ============================================================================
# Helpers d'accès aux résultats du FactsheetSections
# ============================================================================

def _get_fs(rows: list[tuple[str, Any, str]], label: str) -> Any:
    """Renvoie la valeur associée à un label dans une section déjà extraite."""
    for lab, val, _unit in rows:
        if lab == label:
            return val
    return None


def _read_ibrav_and_n_atoms(work_dir: Path) -> tuple[Optional[int], Optional[int], Optional[int]]:
    """Lit ``ibrav`` depuis ``scf.in`` et essaie d'en déduire le nombre d'atomes.

    Renvoie ``(ibrav, n_atoms_estimated_for_lattice_param, nat_from_scf)``.
    ``nat_from_scf`` est utilisée uniquement pour la cohérence (cubique FCC si
    ibrav=2 ⇒ 4 atomes/mailles conventionnelles, etc.).
    """
    ibrav: Optional[int] = None
    nat: Optional[int] = None
    scf = work_dir / "scf.in"
    if not scf.is_file():
        return None, None, None
    try:
        text = scf.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None, None, None
    m = re.search(r"(?im)^\s*ibrav\s*=\s*(-?\d+)", text)
    if m:
        try:
            ibrav = int(m.group(1))
        except ValueError:
            ibrav = None
    m = re.search(r"(?im)^\s*nat\s*=\s*(\d+)", text)
    if m:
        try:
            nat = int(m.group(1))
        except ValueError:
            nat = None
    return ibrav, _IBRAV_TO_N_ATOMS.get(ibrav or 0), nat


# ============================================================================
# Règles individuelles — chaque fonction renvoie list[Insight] (vide si non applicable)
# ============================================================================

def _insight_structure(
    work_dir: Path,
    eos_rows: list[tuple[str, Any, str]],
) -> list[Insight]:
    """Estimation du paramètre de maille a (Å) depuis V₀ + ibrav.

    Pour une cellule FCC (ibrav=2) : V₀/N = a³/4 ⇒ a = (4 V₀ / nat_per_cv)^(1/3).
    Pour une cellule simple (ibrav=1) : a = V₀^(1/3).

    *Heuristique pédagogique* : on annonce la valeur publiée (« a ≈ 5.43 Å
    typique Si ») sans vérifier la littérature ; on s'appuie sur ``ibrav`` lu
    dans scf.in pour la conversion V₀→a.
    """
    insights: list[Insight] = []
    v0 = _get_fs(eos_rows, "V₀ (volume d'équilibre)")
    if v0 is None:
        return insights
    ibrav, n_per_cv, _nat = _read_ibrav_and_n_atoms(work_dir)
    try:
        a_ang = _lattice_parameter_from_v0(
            float(v0),
            ibrav=ibrav,
            n_atoms_per_conventional_cell=n_per_cv,
        )
    except (TypeError, ValueError):
        return insights
    if a_ang is None:
        return insights
    try:
        ibrav_str = f"ibrav={ibrav}" if ibrav is not None else "ibrav=inconnu (repli : a = V₀^(1/3))"
        insights.append(Insight(
            level="info",
            category="structure",
            title="Paramètre de maille estimé",
            body=(
                f"D'après V₀ = {float(v0):.3f} bohr³ et {ibrav_str}, le paramètre de maille "
                f"a ≈ **{a_ang:.3f} Å**. La littérature donne pour Si 5.43 Å — "
                "cohérent dans 1 % pour SCF PBE sur mailles standard."
            ),
            source_keys=["eos.V0_bohr3", "scf.in:ibrav"],
        ))
    except Exception:  # noqa: BLE001
        pass
    return insights


def _insight_elastic(
    elastic_voigt: list[tuple[str, Any, str]],
    elastic_poly: list[tuple[str, Any, str]],
    elastic_extra: list[tuple[str, Any, str]],
) -> list[Insight]:
    """Critères de Born, Pugh (B/G), Zener (A)."""
    insights: list[Insight] = []
    c11 = _get_fs(elastic_voigt, "C₁₁")
    c12 = _get_fs(elastic_voigt, "C₁₂")
    c44 = _get_fs(elastic_voigt, "C₄₄")
    b = _get_fs(elastic_poly, "B (VRH)")
    g = _get_fs(elastic_poly, "G (VRH)")
    nu = _get_fs(elastic_poly, "ν (Poisson)")
    a_zen = _get_fs(elastic_extra, "zener_anisotropy_ratio_A")
    pugh = _get_fs(elastic_extra, "pugh_BG_ratio_from_Hill_G")

    # Born stability (Hu, Sole, Johansson 2018).
    if c11 is not None and c12 is not None and c44 is not None:
        c1, c2, c4 = float(c11), float(c12), float(c44)
        margins = {
            "C₁₁ − C₁₂ > 0": c1 - c2,
            "C₁₁ + 2 C₁₂ > 0": c1 + 2.0 * c2,
            "C₄₄ > 0": c4,
        }
        violations = [k for k, v in margins.items() if v <= 0]
        ok_margins = [v for v in margins.values() if v > 0]
        min_margin = min(ok_margins) if ok_margins else 0.0
        body_lines = []
        for k, v in margins.items():
            body_lines.append(f"- **{k}** = {v:.2f} GPa")
        if violations:
            insights.append(Insight(
                level="error",
                category="elasticity",
                title="Critères de Born VIOLÉS",
                body=(
                    "Le cristal est mécaniquement **instable** dans cette approximation "
                    "(les critères de stabilités sont violés : "
                    + ", ".join(violations) + ").\n\n"
                    + "\n".join(body_lines)
                ),
                source_keys=["elastic.C11_GPa", "elastic.C12_GPa", "elastic.C44_GPa"],
            ))
        elif min_margin < 5.0:
            insights.append(Insight(
                level="warning",
                category="elasticity",
                title="Stabilité mécanique Born — marges faibles",
                body=(
                    f"Tous les critères de Born sont satisfaits mais la **marge minimale** est "
                    f"{min_margin:.2f} GPa (seuil 5 GPa). Proche de l'instabilité — vérifier "
                    "convergence SCF et pseudos.\n\n"
                    + "\n".join(body_lines)
                ),
                source_keys=["elastic.C11_GPa", "elastic.C12_GPa", "elastic.C44_GPa"],
            ))
        else:
            insights.append(Insight(
                level="success",
                category="elasticity",
                title="Critères de Born respectés (marge confortable)",
                body=(
                    f"Stabilité mécanique **validée** — marge minimale "
                    f"= {min_margin:.2f} GPa (loin du seuil 5 GPa).\n\n"
                    + "\n".join(body_lines)
                ),
                source_keys=["elastic.C11_GPa", "elastic.C12_GPa", "elastic.C44_GPa"],
            ))

    # Pugh ratio.
    if b is not None and g is not None and float(g) > 1e-9:
        ratio = float(b) / float(g)
        cls = "ductile" if ratio > 1.75 else "fragile"
        if ratio > 2.5:
            lvl = "info"
            qual = "très ductile"
        elif ratio >= 1.75:
            lvl = "success"
            qual = "ductile"
        elif ratio >= 1.5:
            lvl = "info"
            qual = "limite ductile/fragile"
        else:
            lvl = "warning"
            qual = "fragile"
        src_bg = []
        if pugh is not None:
            src_bg.append("elastic.pugh_BG_ratio_from_Hill_G")
        src_bg += ["elastic.bulk_modulus_GPa", "elastic.shear_modulus_GPa"]
        insights.append(Insight(
            level=lvl,
            category="elasticity",
            title=f"Cristal {qual} (critère de Pugh)",
            body=(
                f"Selon la règle de Pugh (1954), le critère **B/G** dicte la "
                f"ductilité : B/G = {ratio:.3f} → **{cls}**. "
                f"Seuil empirique : 1.75 (au-delà = ductile, en-deçà = fragile). "
                f"Applications mécaniques : {qual} → bonne ténacité / résistance à la fracture."
            ),
            source_keys=src_bg,
        ))

    # Zener anisotropy.
    if a_zen is not None and c11 is not None and c12 is not None:
        a = float(a_zen)
        if abs(a - 1.0) < 0.05:
            quote = "quasi-isotrope (A ≈ 1)"
            advice = (
                "Comportement élastique uniforme selon les directions — la modélisation polycristalline (VRH) "
                "capture bien la physique."
            )
        elif a < 1.5:
            quote = "anisotropie modérée (1 < A < 1.5)"
            advice = (
                "Vérifier l'agrégat polycristallin (Reuss/Voigt donnent des écarts notables) ; "
                "à comparer à des mesures de diffraction si disponibles."
            )
        elif a < 3.0:
            quote = "forte anisotropie (1.5 < A < 3)"
            advice = (
                "Elasticité très directionnelle : le module d'Young varie significativement selon "
                "[hkl]. Les modèles isotropes (Hill VRH) masquent cette anisotropie — "
                "utile pour caractériser la dépendance en T (E(T))."
            )
        else:
            quote = "anisotropie extrême (A > 3)"
            advice = (
                "Comportement anormal — re-vérifier la maille et la convergence SCF. "
                "Possible artefact si la relaxation a figé un état non physique."
            )
        insights.append(Insight(
            level="info",
            category="elasticity",
            title=f"Anisotropie Zener : {quote}",
            body=(
                f"Le rapport de Zener **A = 2·C₄₄ / (C₁₁−C₁₂) = {a:.3f}** indique un cristal "
                f"{quote} (le cubique isotrope parfait donne A=1). {advice}"
            ),
            source_keys=["elastic.zener_anisotropy_ratio_A"],
        ))

    # Poisson ratio context.
    if nu is not None:
        n = float(nu)
        if 0.05 <= n <= 0.45:
            lvl = "success"
            verdict = "plage thermodynamique typique [-1, 0.5]"
        elif n < 0:
            lvl = "warning"
            verdict = "auxétique (ν < 0) — inhabituel, à vérifier avec la littérature"
        else:
            lvl = "warning"
            verdict = "limite thermodynamique dépassée (ν > 0.5) — re-vérifier le fit C_ij"
        insights.append(Insight(
            level=lvl,
            category="elasticity",
            title="Coefficient de Poisson",
            body=(
                f"ν = {n:.4f} — {verdict}. Pour les solides usuels : 0.20 ≤ ν ≤ 0.35 "
                "(auxétique : ν < 0, ex. certaines structures 2D et cristaux cubiques sous "
                "traction). Valeurs proches de 0.5 : comportement quasi-incompressible."
            ),
            source_keys=["elastic.poisson_ratio"],
        ))
    return insights


def _insight_electronic(
    electronic_rows: list[tuple[str, Any, str]],
    electronic_extra: list[tuple[str, Any, str]],
) -> list[Insight]:
    """Classification du gap et applicabilité."""
    insights: list[Insight] = []
    gap = _get_fs(electronic_rows, "Gap VBM→CBM")
    nature = _get_fs(electronic_extra, "Nature du gap")
    fermi = _get_fs(electronic_rows, "E_Fermi")
    n_bands = _get_fs(electronic_rows, "Bandes Kohn–Sham")
    if gap is None:
        # rien à dire
        return insights
    g = float(gap)
    if g < -1e-3:
        lvl = "info"
        verdict = "métallique"
        apps = (
            "Métal : conduction électrique, plasmonique, conduction thermique électronique "
            "(composante e⁻ de κ : Wiedemann-Franz). Aucune barrière optique utile au-dessus "
            "de E_F — répondeur plasmon à la fréquence plasma E_F/ℏ."
        )
    elif g < 0.05:
        lvl = "info"
        verdict = "semi-métal / gap nul"
        apps = (
            "Semi-métal : densité d'états nulle au niveau de Fermi mais gap direct ≈ 0. "
            "Carbone graphite, Bi : conduction anisotrope, intérêt thermoélectrique."
        )
    elif g < 0.5:
        lvl = "info"
        verdict = "semi-conducteur à faible gap"
        apps = (
            "Semi-conducteur à faible gap — adapté aux cellules IR / thermoélectriques "
            "(cf. Bi₂Te₃ ≈ 0.15 eV). PBE sous-estime typiquement le gap expérimental "
            "de ~30 % — à comparer à HSE/MBJ."
        )
    elif g < 3.0:
        lvl = "info"
        verdict = "semi-conducteur (gap typique d'absorbeur solaire)"
        apps = (
            "Semi-conducteur visible — adapté aux applications photovoltaïques. "
            "Le gap PBE sous-estime l'expérience (~1.1 eV pour Si) ; recalibrer en HSE06 "
            "pour publication."
        )
    else:
        lvl = "info"
        verdict = "isolant grand gap (UV-transparent)"
        apps = (
            "Isolant grand gap — intérêts : hublots UV (Al₂O₃ ~ 8.7 eV), substrats "
            "(SrTiO₃ ≈ 3.2 eV), ferroélectriques (BaTiO₃ ≈ 3.5 eV), LEDs UV profondes."
        )
    body = (
        f"Gap VBM→CBM = {g:.3f} eV — **{verdict}**. "
        f"Nature = {nature if nature is not None else '?'}. {apps}"
    )
    if n_bands is not None:
        body += f" **nbnd** = {int(n_bands)}."
    insights.append(Insight(
        level=lvl,
        category="electronic",
        title="Application suggérée d'après le gap",
        body=body,
        source_keys=[
            "properties.band_gap_eV",
            "properties.band_gap_type",
            "properties.gap_direct",
            "properties.band_gap_direct",
            "properties.n_bands",
        ],
    ))
    return insights


def _insight_phonon(
    dyn_stability_rows: list[tuple[str, Any, str]],
    verification_recommendations: Optional[dict[str, Any]] = None,
) -> list[Insight]:
    """Stabilité dynamique détaillée (au-delà du check binaire de sanity_checks).

    Juillet 2026 — étendu : quand ``verification_recommendations`` est
    fourni (voyé par ``assemble_factsheet`` depuis
    ``properties.verification_recommendations``), les **trois premières**
    recommandations (par ``priority``) sont injectées sous forme d'``Insight``
    dédié (« Vérifier et confirmer »). On évite la duplication avec la
    section 5b MD/HTML de la fiche en n'émettant ici qu'un *résumé exécutif*
    ; le détail (justification, trace clé) reste décrit exhaustivement dans
    la section 5b « Recommandations de vérification ».
    """
    insights: list[Insight] = []
    stable = _get_fs(dyn_stability_rows, "Stable dynamiquement")
    minf = _get_fs(dyn_stability_rows, "ω_min (mode acoustique le plus mou)")
    n_imag = _get_fs(dyn_stability_rows, "Modes imaginaires")
    if stable is None:
        return insights
    if bool(stable):
        # Robustesse additionnelle : on regarde la marge acoustique.
        if isinstance(minf, float):
            if minf > 50.0:
                lvl = "success"
                body = (
                    f"Pas de mode imaginaire ; ω_min = {minf:.1f} cm⁻¹ (robuste). "
                    "Convergence DFPT confirmée ; les constantes de force sont fiables pour "
                    "l'analyse C_ij(T) (P3) ou anharmonique (P4)."
                )
            elif minf > 15.0:
                lvl = "info"
                body = (
                    f"Pas de mode imaginaire ; ω_min = {minf:.1f} cm⁻¹ (mode acoustique au point Γ "
                    "un peu mou — typique pour matériaux à liaisons molles). "
                    "Vérifier la grille q (4×4×4 minimum) et l'ASR ('simple' / 'crystal')."
                )
            else:
                lvl = "warning"
                body = (
                    f"Pas de mode imaginaire, mais ω_min = {minf:.1f} cm⁻¹ — acoustique extrêmement mou, "
                    "proche du seuil conventionnel -0.5 cm⁻¹. Augmenter la grille q ou utiliser "
                    "ASR='crystal' pour stabiliser les branches acoustiques."
                )
        else:
            lvl = "success"
            body = "Pas de mode imaginaire."
        insights.append(Insight(
            level=lvl,
            category="phonon",
            title="Stabilité dynamique — verdict approfondi",
            body=body,
            source_keys=["properties.dynamically_stable", "properties.min_freq_cm-1"],
        ))
    else:
        # failure path
        msg = (
            f"**{n_imag} mode(s) imaginaire(s)** détecté(s). "
            "Le cristal relaxera spontanément — réviser la maille (positions ou paramètres de réseau) "
            "ou les pseudos (US/PAW trop rigides pour les faibles fréquences)."
        )
        if isinstance(minf, float):
            msg += f" ω_min = {minf:.2f} cm⁻¹."
        insights.append(Insight(
            level="error",
            category="phonon",
            title="Stabilité dynamique — matériau instable",
            body=msg,
            source_keys=[
                "properties.dynamically_stable",
                "properties.n_imaginary_modes",
                "properties.min_freq_cm-1",
            ],
        ))
        # Juillet 2026 — Injecter un aperçu exécutif des **top-3**
        # recommandations de vérification (filtrées par priorité) pour
        # que l'utilisateur voit dans la section « 🧠 Analyse experte »
        # les actions les plus pressantes. Le détail (rationale, action,
        # trace) reste consultable dans la **section 5b** de la fiche.
        if verification_recommendations:
            items = verification_recommendations.get("items") or []
            if items:
                # On ne remonte ici que les critiques (level=error) OU
                # les top-3 prioritaires. Cahier des charges : éviter le
                # déluge dans l'analyse experte (l'utilisateur a déjà la
                # section 5b pour le détail).
                head = sorted(
                    items,
                    key=lambda r: (
                        0 if str(r.get("level") or "").lower() == "error" else 1,
                        int(r.get("priority") or 99),
                    ),
                )[:3]
                bullets: list[str] = []
                for r in head:
                    cat = r.get("category") or "?"
                    lvl = r.get("level") or "info"
                    title = r.get("title") or "—"
                    action = r.get("action") or ""
                    icon = {"error": "🔴", "warning": "🟡"}.get(lvl, "🔵")
                    bullet = (
                        f"{icon} **[{cat}]** {title}"
                        + (f" → _{action}_" if action else "")
                    )
                    bullets.append(bullet)
                if bullets:
                    insights.append(Insight(
                        level="info",
                        category="phonon",
                        title="Vérifier et confirmer (top-3 actions)",
                        body=(
                            "Recommandations auto-générées à partir des artefacts "
                            "du work_dir. Détail complet + trace dans la "
                            "**section 5b** de la fiche :\n\n"
                            + "\n".join(f"- {ln}" for ln in bullets)
                        ),
                        source_keys=[
                            "properties.verification_recommendations",
                            "properties.verification_recommendations.items",
                        ],
                    ))
    return insights


def _insight_lifetime(
    lifetime_rows: list[tuple[str, Any, str]],
) -> list[Insight]:
    """P4 — anharmonicité via τ mean / linewidth moyen / κ_lattice moyen."""
    if not lifetime_rows:
        return []
    insights: list[Insight] = []
    t_mean = _get_fs(lifetime_rows, "τ mean (durée de vie moyenne)")
    t_min = _get_fs(lifetime_rows, "τ min (mode le plus résistif)")
    g_mean = _get_fs(lifetime_rows, "γ mean (linewidth)")
    kap = _get_fs(lifetime_rows, "κ_lattice (réseau)")
    gr = _get_fs(lifetime_rows, "Grüneisen γ̄")
    if t_mean is not None:
        try:
            tm = float(t_mean)
        except (TypeError, ValueError):
            tm = None
        if tm is not None:
            if tm < 1.0:
                lvl = "warning"
                verdict = (
                    f"τ_mean = {tm:.2f} ps : phonons **très rapidement amortis** "
                    "(couplage 3-phonons marqué). Conductivité thermique réseau probablement "
                    "modérée — vérifier κ_lattice."
                )
            elif tm < 10.0:
                lvl = "info"
                verdict = (
                    f"τ_mean = {tm:.2f} ps : durée de vie typique des matériaux "
                    "à couplage anharmonique modéré. À comparer aux phonopy calculations."
                )
            else:
                lvl = "success"
                verdict = (
                    f"τ_mean = {tm:.2f} ps : phonons **très peu amortis** "
                    "(matériau à liaisons fortes ou symétrie élevée). κ_lattice probablement élevée."
                )
            body = verdict
            if t_min is not None:
                body += f" τ_min = {float(t_min):.2f} ps (mode le plus résistif)."
            if g_mean is not None:
                body += f" γ_mean = {float(g_mean):.3f} cm⁻¹."
            if kap is not None:
                body += f" κ_lattice moyen ≈ {float(kap):.2f} W/(m·K)."
            if gr is not None:
                gv = float(gr)
                if abs(gv) > 2.0:
                    body += f" Grüneisen γ̄ = {gv:.2f} : anharmonicité **très forte**."
                elif abs(gv) > 1.0:
                    body += f" Grüneisen γ̄ = {gv:.2f} : anharmonicité marquée."
                else:
                    body += f" Grüneisen γ̄ = {gv:.2f} : quasi-harmonique (low anharmonicity)."
            insights.append(Insight(
                level=lvl,
                category="lifetime",
                title="Verdict anharmonicité (P4 what=ph_life)",
                body=body,
                source_keys=[
                    "ph_life.mean_lifetime_ps",
                    "ph_life.min_lifetime_ps",
                    "ph_life.mean_linewidth_cm-1",
                    "ph_life.lattice_kappa_W_mK",
                    "ph_life.gruneisen_mean",
                ],
            ))
    return insights


def _insight_dielectric(
    dielectric_rows: list[tuple[str, Any, str]],
    born_rows: list[tuple[str, Any, str]],
) -> list[Insight]:
    """P5 — ε∞, indice de réfraction n, ferroélectricité."""
    if not dielectric_rows:
        return []
    insights: list[Insight] = []
    avg = _get_fs(dielectric_rows, "ε_∞ moyenne (diag. positives)")
    n = _get_fs(dielectric_rows, "Indice de réfraction n (√ε_∞)")
    anis = _get_fs(dielectric_rows, "ε_∞ anisotropie (max/min)")
    if avg is not None:
        av = float(avg)
        if av > 12.0:
            verdict = "constante diélectrique **très élevée** — applications capacitives / ferroélectriques envisageables."
        elif av > 6.0:
            verdict = "constante diélectrique élevée — semi-conducteur polaire ou ferroélectrique paraélectrique."
        elif av > 2.0:
            verdict = "constante diélectrique modérée — isolant ou semi-conducteur standard."
        else:
            verdict = "constante diélectrique faible — matériau fortement covalent ou métallique (écrantage important)."
        body = f"ε_∞ moyenne = {av:.3f}. {verdict}"
        if n is not None and float(n) > 0:
            body += f" n = √ε_∞ ≈ {float(n):.3f}."
        if anis is not None:
            a = float(anis)
            if a > 1.2:
                body += f" ε_∞ anisotropie {a:.2f} (tenseur nettement non isotrope — biréfringence)."
            elif a > 1.05:
                body += f" ε_∞ anisotropie {a:.2f} (modérée)."
            else:
                body += f" ε_∞ anisotropie {a:.2f} (essentiellement isotrope)."
        insights.append(Insight(
            level="info",
            category="dielectric",
            title="Classement diélectrique (P5 what=dielectric)",
            body=body,
            source_keys=[
                "dielectric.epsilon_xx",
                "dielectric.epsilon_yy",
                "dielectric.epsilon_zz",
                "dielectric.epsilon_average",
                "dielectric.epsilon_anisotropy",
                "dielectric.refractive_index_avg",
            ],
        ))
    if born_rows:
        max_z = _get_fs(born_rows, "|Z*| max (charge effective)")
        n_atoms = sum(1 for lab, _, _ in born_rows if lab.startswith("Z*["))
        if max_z is not None:
            zv = float(max_z)
            body = (
                f"|Z*|_max = {zv:.3f} e (charges effectives de Born sur {n_atoms} atome(s) affiché(s)). "
            )
            if zv > 4.0:
                body += (
                    " **Z* très élevées** : matériau polaire / ferroélectrique probable (Ti, Ba, Pb — "
                    "à confirmer avec la structure)."
                )
            elif zv > 2.5:
                body += " Z* significatives : semi-conducteur polaire / piézoélectrique possible."
            else:
                body += " Z* modérées : matériau covalent / peu polaire."
            insights.append(Insight(
                level="info",
                category="dielectric",
                title="Charges effectives de Born (P5)",
                body=body,
                source_keys=["dielectric.born_Z_star_max_abs", "dielectric.born_Z_star_per_atom"],
            ))
    return insights


def _insight_magnetism(magnetism_rows: list[tuple[str, Any, str]]) -> list[Insight]:
    if not magnetism_rows:
        return []
    insights: list[Insight] = []
    magnetic = _get_fs(magnetism_rows, "Régime")

    # Cherche les sous-lignes
    order_row = None
    hubbard_active = None
    hubbard_u_vals: list[tuple[str, float]] = []
    noncolin_flag = None
    nspin_val = None
    angle_rows: list[str] = []
    for lab, val, _unit in magnetism_rows:
        if lab == "  Ordre détecté":
            order_row = str(val)
        elif lab == "  DFT+U activé (lda_plus_u=.true.)":
            hubbard_active = bool(val)
        elif lab.startswith("  Hubbard_U("):
            hubbard_u_vals.append((lab.strip(), float(val)))
        elif lab == "  noncolin":
            noncolin_flag = bool(val)
        elif "non-colinéaire" in str(lab).lower() and "Régime" in str(lab):
            nspin_val = 4

    noncolin_rows = [lab for lab, _, _ in magnetism_rows
                     if lab.startswith("  angle1(") or lab.startswith("  angle2(")]
    angle_rows = noncolin_rows

    if magnetic is not None and ("non-colinéaire" in str(magnetic).lower() or "nspin=4" in str(magnetic).lower() or noncolin_flag is True):
        # Non-collinear insight
        body = (
            "Calcul configuré en **spin-polarisé non-colinéaire** (nspin=4). "
            "Régime DFT avec densité de spin vectorielle — la direction du moment "
            "magnétique peut varier dans l'espace. Utile pour les systèmes avec "
            "couplage spin-orbite fort (terres rares, actinides, interfaces), "
            "les parois de domaines magnétiques, ou les configurations "
            "antiferromagnétiques non-colinéaires (skyrmions, spirales de spin). "
        )
        if angle_rows:
            body += f"{len(angle_rows)} paramètre(s) d'angle détecté(s) (angle1/angle2)."
        source = ["scf.in:nspin", "scf.in:noncolin", "scf.in:angle1", "scf.in:angle2"]
        if hubbard_active is True:
            body += (
                " DFT+U activé conjointement — typique pour oxydes de métaux "
                "de transition magnétiques (NiO, MnO, Fe₂O₃, …)."
            )
            source.append("scf.in:lda_plus_u")
            if hubbard_u_vals:
                u_summary = ", ".join(f"U({k.split('(')[1].rstrip(')')})={v:.1f} eV"
                                       for k, v in hubbard_u_vals)
                body += f" Paramètres : {u_summary}."
        insights.append(Insight(
            level="info",
            category="magnetism",
            title="Régime magnétique non-colinéaire",
            body=body,
            source_keys=source,
        ))
    elif magnetic is not None and ("spin-polarisé" in str(magnetic).lower() or "nspin=2" in str(magnetic).lower()):
        moments_count = sum(1 for lab, _, _ in magnetism_rows if lab.startswith("  starting_magnetization("))
        body = (
            "Calcul configuré **spin-polarisé** (nspin=2) — utile pour systèmes magnétiques "
            "(Fe, Co, Ni, Mn, …) ou screening anti-ferromagnétique. "
        )
        if moments_count > 0:
            body += f"{moments_count} moment(s) ``starting_magnetization(i)`` détecté(s) non nuls."
        else:
            body += "Aucun moment non nul détecté → **essai non magnétique** sur spin-polarisé."

        # Ordre AFM / FM / ferri
        if order_row:
            if "antiferro" in order_row.lower():
                body += (
                    f" Classification automatique : **antiferromagnétique (AFM)** "
                    f"— les moments s'opposent (somme ≈ 0). Vérifier la "
                    f"multiplicité de la maille (supercellule) et la cohérence "
                    f"des signes de ``starting_magnetization`` avec la structure "
                    f"magnétique visée (A-AFM, C-AFM, G-AFM pour pérovskites)."
                )
            elif "ferrimagnetic" in order_row.lower():
                body += (
                    f" Classification : **ferrimagnétique (FiM)** — moments "
                    f"antiparallèles mais d'amplitudes différentes (somme ≠ 0)."
                )
            elif "ferromagnetic" in order_row.lower():
                body += (
                    f" Classification : **ferromagnétique (FM)** — tous les "
                    f"moments sont alignés dans la même direction."
                )

        level = "warning" if "non nul" not in body else "info"
        source_keys = ["scf.in:nspin", "scf.in:starting_magnetization"]

        # Hubbard U add-on
        if hubbard_active is True:
            body += (
                " DFT+U activé (``lda_plus_u=.true.``) — correction de Hubbard "
                "pour les électrons localisés d ou f. Améliore la description du "
                "gap et des moments magnétiques pour les oxydes de métaux de transition."
            )
            level = "info"
            source_keys.append("scf.in:lda_plus_u")
            if hubbard_u_vals:
                u_summary = ", ".join(f"U({k.split('(')[1].rstrip(')')})={v:.1f} eV"
                                       for k, v in hubbard_u_vals)
                body += f" Paramètres : {u_summary}."

        insights.append(Insight(
            level=level,
            category="magnetism",
            title="Régime magnétique",
            body=body,
            source_keys=source_keys,
        ))
    else:
        # Non magnétique
        body = (
            "Régime **non magnétique** (nspin=1 sans moments). "
        )
        if hubbard_active is True:
            body += (
                "**Attention : DFT+U activé (``lda_plus_u=.true.``) sans spin "
                "polarisé — configuration inhabituelle.** Hubbard U est "
                "généralement utilisé avec nspin=2 pour les systèmes magnétiques. "
            )
            if hubbard_u_vals:
                u_summary = ", ".join(f"U({k.split('(')[1].rstrip(')')})={v:.1f} eV"
                                       for k, v in hubbard_u_vals)
                body += f"Paramètres détectés : {u_summary}. "
            body += "Vérifiez si le spin-polarisé est intentionnellement désactivé."
        else:
            body += "Pas besoin de corrections Hubbard U / DFT+U pour ce run."
        insights.append(Insight(
            level="warning" if hubbard_active else "info",
            category="magnetism",
            title="Matériau non magnétique",
            body=body,
            source_keys=["scf.in:nspin", "scf.in:lda_plus_u"] if hubbard_active else ["scf.in:nspin"],
        ))
    return insights


def _insight_synthesis(
    fs,
) -> list[Insight]:
    """Insight-synthèse — recommandation globale basée sur ce qui est cohérent."""
    insights: list[Insight] = []
    try:
        c11 = _get_fs(fs.elastic_rows_exec, "C₁₁")
        c12 = _get_fs(fs.elastic_rows_exec, "C₁₂")
        c44 = _get_fs(fs.elastic_rows_exec, "C₄₄")
        gap = _get_fs(fs.electronic_rows, "Gap VBM→CBM")
        stable = _get_fs(fs.dyn_stability_rows, "Stable dynamiquement")
    except Exception:  # noqa: BLE001
        return insights
    if not (c11 is not None and gap is not None and stable is not None):
        return insights
    # Synthèse : cas semiconducteur ductile, mécanique robuste + gap non nul + bon.
    if (gap > 0.5) and (c11 is not None and c12 is not None and c44 is not None
                      and c11 > c12 > 0 and c44 > 0) and bool(stable):
        insights.append(Insight(
            level="success",
            category="synthesis",
            title="Profil cohérent : semi-conducteur robuste",
            body=(
                "Convergence multi-physique : **Born respectée** + **stabilité dynamique** + **gap > 0.5 eV**. "
                "Le profil est mécaniquement robuste et électronique isolé/faible-gap — bon candidat pour "
                "des applications photovoltaïques ou optoélectroniques. Le run est cohérent sur l'ensemble "
                "des 5 axes (structure, élasticité, électronique, optique, phonons)."
            ),
            source_keys=[
                "elastic.C11_GPa",
                "elastic.C12_GPa",
                "elastic.C44_GPa",
                "properties.band_gap_eV",
                "properties.dynamically_stable",
            ],
        ))
    elif gap <= -1e-3 and c11 > 0 and c44 > 0 and bool(stable):
        insights.append(Insight(
            level="info",
            category="synthesis",
            title="Profil métallique stable",
            body=(
                "**Métal** (gap ≤ 0) + propriétés mécaniques saines + phonon stable. "
                "Cohérent pour la conduction électronique et thermique ; explorer P4 si "
                "la conductivité phonon est d'intérêt."
            ),
            source_keys=[
                "elastic.C11_GPa",
                "properties.band_gap_eV",
                "properties.dynamically_stable",
            ],
        ))
    return insights


# ============================================================================
# Orchestration
# ============================================================================

def compute_insights(
    fs,
    work_dir: Optional[Path] = None,
) -> list[Insight]:
    """Orchestrateur : appelle chaque règle, retourne insights consolidés (dans un ordre stable).

    Args:
        fs: instance de ``FactsheetSections`` (depuis ``factsheet.assemble_factsheet``).
        work_dir: répertoire du run (utilisé par les règles ``_insight_structure`` et
            ``_insight_elastic`` qui lisent ``scf.in``).

    Ordre de production : structure → elastic (Born → Pugh → Zener → ν)
    → electronic → phonon → lifetime (P4) → dielectric (P5) → magnetism
    → synthesis. Ordre déterministe pour rendu reproductible (utile pour les
    tests snapshot).
    """
    insights: list[Insight] = []
    if work_dir is None:
        # Récupération depuis le header (chemin absolu) — peut être déjà résolu.
        wd_str = ((fs.header or {}).get("work_dir") or "").strip()
        work_dir = Path(wd_str) if wd_str else Path(".")
    # Juillet 2026 — récupère les recommandations de vérification
    # déclenchées quand ``properties.n_imaginary_modes > 0``. La lecture-seule
    # est faite par ``assemble_factsheet`` (champs ``fs.phonon_recommendations``
    # et ``fs.phonon_recommendation_context``). On re-packe ici en dict
    # raccourci pour ``_insight_phonon``.
    verif_recs: Optional[dict[str, Any]] = None
    if getattr(fs, "phonon_recommendations", None):
        verif_recs = {
            "has_imaginary": True,
            "items": list(fs.phonon_recommendations or []),
            "context": dict(getattr(fs, "phonon_recommendation_context", {}) or {}),
        }
    try:
        insights.extend(_insight_structure(work_dir, fs.eos_rows or []))
    except Exception:  # noqa: BLE001
        pass
    try:
        insights.extend(_insight_elastic(
            fs.elastic_rows_exec or [],
            fs.elastic_rows_poly or [],
            fs.elastic_extra or [],
        ))
    except Exception:  # noqa: BLE001
        pass
    try:
        insights.extend(_insight_electronic(fs.electronic_rows or [], fs.electronic_extra or []))
    except Exception:  # noqa: BLE001
        pass
    try:
        insights.extend(_insight_phonon(
            fs.dyn_stability_rows or [],
            verification_recommendations=verif_recs,
        ))
    except Exception:  # noqa: BLE001
        pass
    try:
        insights.extend(_insight_lifetime(fs.phonon_lifetime_rows or []))
    except Exception:  # noqa: BLE001
        pass
    try:
        insights.extend(_insight_dielectric(fs.dielectric_rows or [], fs.born_rows or []))
    except Exception:  # noqa: BLE001
        pass
    try:
        insights.extend(_insight_magnetism(fs.magnetism_rows or []))
    except Exception:  # noqa: BLE001
        pass
    try:
        insights.extend(_insight_synthesis(fs))
    except Exception:  # noqa: BLE001
        pass
    return insights


def render_insights_md(insights: list[Insight]) -> str:
    """Formate la liste d'insights en Markdown groupé par catégorie."""
    if not insights:
        return "*Aucun insight applicable aux résultats de ce run.*\n"
    by_cat: dict[str, list[Insight]] = {}
    for ins in insights:
        by_cat.setdefault(ins.category, []).append(ins)
    cat_order = [
        "structure", "elasticity", "electronic", "phonon",
        "lifetime", "dielectric", "magnetism", "synthesis",
    ]
    cat_labels = {
        "structure": "📐 Structure",
        "elasticity": "🧱 Élasticité",
        "electronic": "⚛️ Propriétés électroniques",
        "phonon": "🎼 Stabilité dynamique (phonons)",
        "lifetime": "⏱ Anharmonicité (phonons, P4)",
        "dielectric": "🌐 Tenseur diélectrique (P5)",
        "magnetism": "🧲 Magnétisme",
        "synthesis": "🧠 Synthèse globale",
    }
    out: list[str] = ["## 🧠 Analyse experte des résultats\n"]
    for cat in cat_order:
        if cat not in by_cat:
            continue
        out.append(f"\n### {cat_labels.get(cat, cat)}\n")
        for ins in by_cat[cat]:
            icon = ins.icon()
            out.append(f"- {icon} **{ins.title}** — {ins.body}\n")
    return "\n".join(out) + "\n"


def render_insights_html(insights: list[Insight]) -> str:
    if not insights:
        return '<p class="ft-empty">Aucun insight applicable aux résultats de ce run.</p>\n'
    by_cat: dict[str, list[Insight]] = {}
    for ins in insights:
        by_cat.setdefault(ins.category, []).append(ins)
    cat_order = [
        "structure", "elasticity", "electronic", "phonon",
        "lifetime", "dielectric", "magnetism", "synthesis",
    ]
    cat_labels = {
        "structure": "📐 Structure",
        "elasticity": "🧱 Élasticité",
        "electronic": "⚛️ Propriétés électroniques",
        "phonon": "🎼 Stabilité dynamique (phonons)",
        "lifetime": "⏱ Anharmonicité (phonons, P4)",
        "dielectric": "🌐 Tenseur diélectrique (P5)",
        "magnetism": "🧲 Magnétisme",
        "synthesis": "🧠 Synthèse globale",
    }
    level_class = {
        "success": "ft-ok",
        "info": "ft-info",
        "warning": "ft-warn",
        "error": "ft-error",
    }
    out: list[str] = ['<h2>🧠 Analyse experte des résultats</h2>\n']
    for cat in cat_order:
        if cat not in by_cat:
            continue
        out.append(f'<h3>{html_escape(cat_labels.get(cat, cat))}</h3>\n')
        out.append('<ul>\n')
        for ins in by_cat[cat]:
            cls = level_class.get(ins.level, "")
            out.append(
                f'  <li class="{cls}"><span class="ft-ico">{html_escape(ins.icon())}</span> '
                f'<strong>{html_escape(ins.title)}</strong> — '
                f'{html_escape(ins.body)}</li>\n'
            )
        out.append('</ul>\n')
    return "".join(out)


def html_escape(s: str) -> str:
    """Wrapper local de ``html.escape`` pour éviter import cyc dans les 2 modules."""
    import html as _html
    return _html.escape(str(s))# Juillet 2026 — version de l'expert rule-based exposée via ``/api/health``
# (mêmes conventions que ``factsheet.FACTSHEET_VERSION`` : sémantique ``MAJOR.MINOR``).
# Utilisable côté UI pour annoncer « moteur expert vX.Y » à côté du banner
# factsheet, sans detourner un appel HTTP supplémentaire vers /factsheet.
FACTSHEET_AI_VERSION: str = "1.0"


__all__ = [
    "Insight",
    "compute_insights",
    "render_insights_md",
    "render_insights_html",
    "FACTSHEET_AI_VERSION",
] 

"""
Fichiers de points + courbe EOS et tracé gnuplot pour E(V) (dossier 1_eos_volumes/).
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any, Optional

import numpy as np

from eos_paths import EOS_VOLUMES_SUBDIR, wf1_eos_run_root
from fit_eos import birch_murnaghan_E, b0_GPa

POINTS = "eos_points.dat"
CURVE = "eos_curve.dat"
GP_SCRIPT = "plot_eos.gnu"
PNG = "eos_ev.png"
PDF = "eos_ev.pdf"

# Bloc terminal pdfcairo réutilisé après le bloc pngcairo (cf. phonon_gnuplot).
_PDFCAIRO_BLOCK_TEMPLATE = (
    "\nset terminal pdfcairo size 18.5cm,12cm enhanced font \"Helvetica,12\"\n"
    "set output \"{pdf_name}\"\n"
    "replot\n"
)


def resolve_gnuplot_executable() -> Optional[str]:
    """
    Trouve l’exécutable gnuplot : THERMO_GNUPLOT, GNUPLOT, PATH, puis /usr/bin/gnuplot, etc.
    """
    for key in ("THERMO_GNUPLOT", "GNUPLOT"):
        raw = (os.environ.get(key) or "").strip()
        if not raw:
            continue
        p = Path(raw).expanduser()
        if p.is_file() and os.access(p, os.X_OK):
            return str(p.resolve())
    w = shutil.which("gnuplot")
    if w:
        return w
    for candidate in (
        "/usr/bin/gnuplot",
        "/bin/gnuplot",
        "/usr/local/bin/gnuplot",
        "/opt/homebrew/bin/gnuplot",
    ):
        if not candidate:
            continue
        c = Path(candidate)
        if c.is_file() and os.access(c, os.X_OK):
            return str(c.resolve())
    return None


def _load_eos_summary(tdir: Path) -> dict[str, Any]:
    p = tdir / "eos_summary.json"
    if not p.is_file():
        raise FileNotFoundError(f"Fichier introuvable : {p} (lancez d'abord l’EOS / fit).")
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def write_eos_dat_files(tdir: Path) -> dict[str, Any]:
    """
    Écrit eos_points.dat, eos_curve.dat dans tdir. Retourne un résumé (clés, chemins).
    """
    tdir = Path(tdir)
    data = _load_eos_summary(tdir)
    vols = data.get("volumes")
    ers = data.get("energies_Ry")
    if not vols or not ers or len(vols) != len(ers):
        raise ValueError("eos_summary.json : volumes / energies_Ry manquants ou longueurs différentes.")
    eos = data.get("eos") or {}
    e0 = float(eos.get("E0_Ry", min(ers)))
    v0 = float(eos.get("V0_bohr3", vols[np.argmin(ers)]))
    b0 = float(eos.get("B0_Ry_bohr3", 0.01))
    b0p = float(eos.get("B0_prime", 4.0))

    v_arr = np.array(vols, dtype=float)
    e_arr = np.array(ers, dtype=float)
    order = np.argsort(v_arr)
    v_arr, e_arr = v_arr[order], e_arr[order]

    pts = tdir / POINTS
    with open(pts, "w", encoding="utf-8") as f:
        for v, e in zip(v_arr, e_arr):
            f.write(f"{v:.10g}\t{e:.12g}\n")

    v_min, v_max = float(v_arr.min()), float(v_arr.max())
    pad = 0.02 * (v_max - v_min) if v_max > v_min else 0.1 * v_min
    grid = np.linspace(v_min - pad, v_max + pad, max(80, 6 * len(v_arr)))
    ec = birch_murnaghan_E(grid, e0, v0, b0, b0p)
    cur = tdir / CURVE
    with open(cur, "w", encoding="utf-8") as f:
        for v, e in zip(grid, ec):
            f.write(f"{v:.10g}\t{e:.12g}\n")

    b0_gpa = b0_GPa(b0) if b0 > 0 else 0.0
    return {
        "points_path": str(pts.resolve()),
        "curve_path": str(cur.resolve()),
        "B0_GPa_approx": b0_gpa,
        "V0_bohr3": v0,
    }


def _esc_title(s: str) -> str:
    return s.replace('"', " ")


def _gnuplot_script(png_name: str, title: str, *, pdf_name: str | None = None) -> str:
    """Tracé E(V) — PNG (+ PDF vectoriel si ``pdf_name`` fourni, multi-output en un run gnuplot)."""
    t = _esc_title(title)
    pdf_block = (
        _PDFCAIRO_BLOCK_TEMPLATE.format(pdf_name=str(pdf_name).replace("\\", "/"))
        if pdf_name
        else ""
    )
    return f"""# Généré par thermo_pw (eos_gnuplot)
set terminal pngcairo size 900,600 enhanced font "Helvetica,12"
set output "{png_name}"
set title "{t}" noenhanced
set grid
set xlabel "Volume (Bohr^3)"
set ylabel "Energie (Ry)"
set key top right
plot "{POINTS}" title "SCF" with points pointtype 7 pointsize 1.4, "{CURVE}" title "Birch-Murnaghan" with lines linewidth 2{pdf_block}
"""


def _gnuplot_script_png_fallback(png_name: str, title: str) -> str:
    """Fallback purement raster (terminal png legacy). N'émet PAS de PDF —
    c'est un filet de sécurité si pngcairo n'est pas disponible ; pdfcairo
    l'est rarement dans ce cas de figure, on évite un échec en cascade.
    """
    t = _esc_title(title)
    return f"""# Généré par thermo_pw (eos_gnuplot) — terminal png
set terminal png size 900,600
set output "{png_name}"
set title "{t}" noenhanced
set grid
set xlabel "Volume (Bohr^3)"
set ylabel "Energie (Ry)"
set key top right
plot "{POINTS}" title "SCF" with points pointtype 7 pointsize 1.4, "{CURVE}" title "Birch-Murnaghan" with lines linewidth 2
"""


def run_gnuplot_eos(work_dir: Path) -> dict[str, Any]:
    """
    work_dir : dossier d’un run wf1_eos_… (contient 1_eos_volumes/eos_summary.json).
    Génère les .dat puis **gnuplot** uniquement (matplotlib n’est plus utilisé).
    """
    work_dir = wf1_eos_run_root(Path(work_dir))
    tdir = work_dir / EOS_VOLUMES_SUBDIR
    if not tdir.is_dir():
        raise FileNotFoundError(f"Dossier introuvable : {tdir}")
    meta = write_eos_dat_files(tdir)
    b0g = meta.get("B0_GPa_approx", 0.0)
    v0 = meta.get("V0_bohr3", 0.0)
    title = f"E(V)  V0={v0:.4f}  B0={b0g:.2f} GPa"

    gpath = tdir / GP_SCRIPT
    png_path = tdir / PNG
    pdf_path = tdir / PDF

    gnu_exe = resolve_gnuplot_executable()

    if png_path.is_file():
        try:
            png_path.unlink()
        except OSError:
            pass
    if pdf_path.is_file():
        try:
            pdf_path.unlink()
        except OSError:
            pass

    if not gnu_exe:
        raise RuntimeError(
            "gnuplot introuvable : installez gnuplot (ex. apt install gnuplot) ou définissez "
            "THERMO_GNUPLOT=/usr/bin/gnuplot — tous les tracés thermo_pw utilisent gnuplot."
        )

    def _try_run(gnu_text: str) -> None:
        gpath.write_text(gnu_text, encoding="utf-8")
        r = subprocess.run(
            [gnu_exe, str(gpath.name)],
            cwd=tdir,
            capture_output=True,
            text=True,
            env={**os.environ},
            timeout=120,
        )
        if r.returncode != 0 or not png_path.is_file():
            err = (r.stderr or r.stdout or "")[:4000]
            raise RuntimeError(f"gnuplot a échoué (code {r.returncode}): {err}")

    try:
        # Chemin nominal : pngcairo + bloc PDF en multi-output (un seul run).
        _try_run(_gnuplot_script(PNG, title, pdf_name=PDF))
    except RuntimeError:
        # Fallback raster (png legacy) — pas de PDF par design (cf. docstring).
        _try_run(_gnuplot_script_png_fallback(PNG, title))
        # Sur fallback on n'a PAS produit de PDF : aucun ajout au return.
    if not png_path.is_file():
        raise RuntimeError("Fichier PNG non créé après gnuplot.")
    out: dict[str, Any] = {
        "png_path": str(png_path.resolve()),
        "relpath": f"{EOS_VOLUMES_SUBDIR}/{PNG}",
        "gnuplot_script": str(gpath.resolve()),
        "meta": meta,
        "renderer": "gnuplot",
    }
    if pdf_path.is_file():
        out["pdf_path"] = str(pdf_path.resolve())
        out["pdf_relpath"] = f"{EOS_VOLUMES_SUBDIR}/{PDF}"
    return out


GP_ELASTIC = "gnuplot_elastic_vs_T.gnu"
PNG_ELASTIC = "elastic_vs_T_plot.png"
PDF_ELASTIC = "elastic_vs_T_plot.pdf"


def run_gnuplot_elastic_temperature_dat(
    work_dir: Path,
    *,
    dat_relpath: str,
    ncol: int,
    column_labels: list[str],
    title: str = "Colonnes vs 1ère colonne (.dat)",
) -> dict[str, Any]:
    """Colonnes numériques 2…ncol versus colonne 1 (ex. T)."""
    work_dir = wf1_eos_run_root(Path(work_dir)).resolve()
    rel_in = Path(str(dat_relpath).replace("\\", "/").strip()).as_posix()
    if not rel_in or ".." in rel_in.split("/"):
        raise ValueError("dat_relpath invalide")
    rp = (work_dir / rel_in).resolve()
    if not rp.is_file():
        raise FileNotFoundError(f"DAT introuvable : {rp}")
    try:
        rp.relative_to(work_dir)
    except ValueError:
        raise RuntimeError(f"DAT hors du dossier run : {dat_relpath}") from None

    gnu_exe = resolve_gnuplot_executable()
    if not gnu_exe:
        raise RuntimeError(
            "gnuplot introuvable : apt install gnuplot ou THERMO_GNUPLOT=/usr/bin/gnuplot."
        )

    gp = work_dir / GP_ELASTIC
    png_path = work_dir / PNG_ELASTIC
    pdf_path = work_dir / PDF_ELASTIC
    tt = _esc_title(title[:180])

    clauses: list[str] = []
    for j in range(2, ncol + 1):
        lab_col = column_labels[j - 1] if len(column_labels) >= j else f"y{j}"
        lab = _esc_title(str(lab_col)[:40])
        clauses.append(f'"{rel_in}" using 1:{j} title "{lab}" with linespoints lw 2 pt 7')

    if not clauses:
        raise RuntimeError("Colonnes ≥2 nécessaires pour un tracé.")

    # Bloc terminal pdfcairo : multi-output PNG + PDF, un seul run gnuplot.
    gnu_body = (
        "# Généré par api_server elastic vs T — eos_gnuplot\n"
        'set terminal pngcairo size 900,540 enhanced font "Helvetica,11"\n'
        f'set output "{PNG_ELASTIC}"\n'
        f'set title "{tt}" noenhanced\n'
        "set grid\n"
        'set key outside right bottom vertical maxrows 15\n'
        'set xlabel "Colonne 1 (ex. temperature)"\n'
        'set ylabel ""\n'
        "plot \\\n"
        + ",\\\n".join(f"    {s}" for s in clauses)
        + "\n"
        + 'set terminal pdfcairo size 18cm,11cm enhanced font "Helvetica,11"\n'
        f'set output "{PDF_ELASTIC}"\n'
        "replot\n"
    )

    gp.write_text(gnu_body, encoding="utf-8")
    if png_path.is_file():
        try:
            png_path.unlink()
        except OSError:
            pass
    if pdf_path.is_file():
        try:
            pdf_path.unlink()
        except OSError:
            pass

    r = subprocess.run(
        [gnu_exe, str(gp.name)],
        cwd=work_dir,
        capture_output=True,
        text=True,
        timeout=120,
        env={**os.environ},
    )
    if r.returncode != 0 or not png_path.is_file():
        err = (r.stderr or r.stdout or "")[:4000]
        raise RuntimeError(f"gnuplot elastic vs T a échoué (code {r.returncode}): {err}")
    out: dict[str, Any] = {
        "png_path": str(png_path.resolve()),
        "png_relpath": PNG_ELASTIC,
        "gnuplot_script": str(gp.resolve()),
        "renderer": "gnuplot",
    }
    if pdf_path.is_file():
        out["pdf_path"] = str(pdf_path.resolve())
        out["pdf_relpath"] = PDF_ELASTIC
    return out


# ============================================================================
# Juillet 2026 — tracés génériques X/Y pour P4 (ph_life) et thermo QHA
# ============================================================================


def _run_gnuplot_script(work_dir: Path, script_name: str, body: str,
                        png_name: str) -> Path:
    """Écrit + exécute un script gnuplot dans ``work_dir``. Renvoie le PNG."""
    gnu_exe = resolve_gnuplot_executable()
    if not gnu_exe:
        raise RuntimeError(
            "gnuplot introuvable : apt install gnuplot ou THERMO_GNUPLOT=/usr/bin/gnuplot."
        )
    gp = work_dir / script_name
    png_path = work_dir / png_name
    gp.write_text(body, encoding="utf-8")
    if png_path.is_file():
        try:
            png_path.unlink()
        except OSError:
            pass
    r = subprocess.run(
        [gnu_exe, str(gp.name)],
        cwd=work_dir,
        capture_output=True,
        text=True,
        timeout=120,
        env={**os.environ},
    )
    if r.returncode != 0 or not png_path.is_file():
        err = (r.stderr or r.stdout or "")[:4000]
        raise RuntimeError(f"gnuplot ({script_name}) a échoué (code {r.returncode}): {err}")
    return png_path


def run_gnuplot_xy_dat(
    work_dir: Path,
    *,
    dat_relpath: str,
    out_basename: str,
    title: str,
    xlabel: str = "",
    ylabel: str = "",
    using: str = "1:2",
    style: str = "linespoints lw 2 pt 7",
    logscale_y: bool = False,
) -> dict[str, Any]:
    """Tracé générique 2 colonnes d'un .dat (ex. γ(ω), τ(ω), κ(T), Grüneisen).

    ``out_basename`` sans extension : produit ``<out_basename>.png`` +
    ``<out_basename>.gnu`` en racine du work_dir. Utilisé par le
    post-process P4 pour matérialiser les plots promis par le catalogue
    (``plots.phonon_linewidth`` etc.).
    """
    work_dir = wf1_eos_run_root(Path(work_dir)).resolve()
    rel_in = Path(str(dat_relpath).replace("\\", "/").strip()).as_posix()
    if not rel_in or ".." in rel_in.split("/"):
        raise ValueError("dat_relpath invalide")
    rp = (work_dir / rel_in).resolve()
    if not rp.is_file():
        raise FileNotFoundError(f"DAT introuvable : {rp}")
    rp.relative_to(work_dir)  # ValueError si hors du run

    png_name = f"{out_basename}.png"
    body = (
        f"# Généré par eos_gnuplot.run_gnuplot_xy_dat — {out_basename}\n"
        'set terminal pngcairo size 900,540 enhanced font "Helvetica,11"\n'
        f'set output "{png_name}"\n'
        f'set title "{_esc_title(title[:180])}" noenhanced\n'
        "set grid\n"
        f'set xlabel "{_esc_title(xlabel[:80])}"\n'
        f'set ylabel "{_esc_title(ylabel[:80])}"\n'
        + ("set logscale y\n" if logscale_y else "")
        + f'plot "{rel_in}" using {using} notitle with {style}\n'
    )
    png_path = _run_gnuplot_script(work_dir, f"{out_basename}.gnu", body, png_name)
    return {
        "png_path": str(png_path.resolve()),
        "png_relpath": png_name,
        "renderer": "gnuplot",
    }


THERM_PLOT_PNG = "thermo_qha_plot.png"
THERM_PLOT_GP = "plot_thermo_qha.gnu"


THERM_CV_CP_PLOT_PNG = "thermo_cv_cp_plot.png"
THERM_CV_CP_PLOT_GP = "plot_thermo_cv_cp.gnu"


def run_gnuplot_cv_cp_comparison(work_dir: Path, *, dat_relpath: str) -> dict[str, Any]:
    """Trace C_v(T) et C_p(T) sur le même graphique depuis ``cv_cp_vs_T.dat``."""
    work_dir = wf1_eos_run_root(Path(work_dir)).resolve()
    rel_in = Path(str(dat_relpath).replace("\\", "/").strip()).as_posix()
    if not rel_in or ".." in rel_in.split("/"):
        raise ValueError("dat_relpath invalide")
    rp = (work_dir / rel_in).resolve()
    if not rp.is_file():
        raise FileNotFoundError(f"DAT introuvable : {rp}")
    rp.relative_to(work_dir)

    body = (
        "# Généré par eos_gnuplot.run_gnuplot_cv_cp_comparison\n"
        'set terminal pngcairo size 900,560 enhanced font "Helvetica,12"\n'
        f'set output "{THERM_CV_CP_PLOT_PNG}"\n'
        "set grid\n"
        'set xlabel "T (K)"\n'
        'set ylabel "Capacite calorifique (Ry/cell/K)"\n'
        'set title "Cv(T) vs Cp(T) — Cp = Cv + T V alpha^2 B" noenhanced\n'
        'set key top left\n'
        f'plot "{rel_in}" using 1:2 title "Cv(T)" with lines lw 2 lc rgb "#c8a865", '
        f'"{rel_in}" using 1:3 title "Cp(T)" with lines lw 2 lc rgb "#d97950"\n'
    )
    png_path = _run_gnuplot_script(work_dir, THERM_CV_CP_PLOT_GP, body, THERM_CV_CP_PLOT_PNG)
    return {
        "png_path": str(png_path.resolve()),
        "png_relpath": THERM_CV_CP_PLOT_PNG,
        "renderer": "gnuplot",
    }


def run_gnuplot_therm_dat(work_dir: Path, *, dat_relpath: str) -> dict[str, Any]:
    """Multiplot 1×3 : F(T), S(T), Cᵥ(T) depuis ``therm_files/output_therm.dat.gN``.

    Colonnes thermo_pw : 1=T (K), 2=E, 3=F (Ry/cell), 4=S (Ry/cell/K),
    5=Cᵥ (Ry/cell/K). Les échelles étant très différentes (F ~1e-2 Ry,
    Cᵥ ~1e-5 Ry/K), un tracé superposé serait illisible — d'où le multiplot.
    """
    work_dir = wf1_eos_run_root(Path(work_dir)).resolve()
    rel_in = Path(str(dat_relpath).replace("\\", "/").strip()).as_posix()
    if not rel_in or ".." in rel_in.split("/"):
        raise ValueError("dat_relpath invalide")
    rp = (work_dir / rel_in).resolve()
    if not rp.is_file():
        raise FileNotFoundError(f"DAT introuvable : {rp}")
    rp.relative_to(work_dir)

    body = (
        "# Généré par eos_gnuplot.run_gnuplot_therm_dat — thermo QHA\n"
        'set terminal pngcairo size 1400,480 enhanced font "Helvetica,11"\n'
        f'set output "{THERM_PLOT_PNG}"\n'
        "set multiplot layout 1,3 title \"Thermodynamique QHA (geometrie centrale)\" noenhanced\n"
        "set grid\n"
        'set xlabel "T (K)"\n'
        'set ylabel "F (Ry/cell)"\n'
        'set title "Energie libre de Helmholtz F(T)" noenhanced\n'
        f'plot "{rel_in}" using 1:3 notitle with lines lw 2 lc rgb "#d97950"\n'
        'set ylabel "S (Ry/cell/K)"\n'
        'set title "Entropie S(T)" noenhanced\n'
        f'plot "{rel_in}" using 1:4 notitle with lines lw 2 lc rgb "#6fadc6"\n'
        'set ylabel "Cv (Ry/cell/K)"\n'
        'set title "Capacite calorifique Cv(T)" noenhanced\n'
        f'plot "{rel_in}" using 1:5 notitle with lines lw 2 lc rgb "#c8a865"\n'
        "unset multiplot\n"
    )
    png_path = _run_gnuplot_script(work_dir, THERM_PLOT_GP, body, THERM_PLOT_PNG)
    return {
        "png_path": str(png_path.resolve()),
        "png_relpath": THERM_PLOT_PNG,
        "renderer": "gnuplot",
    }

"""
Base d'état locale (JSON) pour reprise de workflow et contrôle de chaîne.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    ERROR = "error"
    INTERRUPTED = "interrupted"
    SKIPPED = "skipped"


@dataclass
class TaskState:
    status: str = TaskStatus.PENDING.value
    message: str = ""
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    data: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict) -> "TaskState":
        return cls(
            status=d.get("status", TaskStatus.PENDING.value),
            message=d.get("message", ""),
            started_at=d.get("started_at"),
            finished_at=d.get("finished_at"),
            data=d.get("data", {}),
        )

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class WorkflowDB:
    material_id: str
    work_dir: str
    version: int = 1
    updated_at: float = field(default_factory=time.time)
    tasks: dict[str, dict] = field(default_factory=dict)

    @classmethod
    def load(cls, path: Path) -> "WorkflowDB":
        if not path.is_file():
            return cls(material_id="", work_dir="")
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        return cls(
            material_id=raw.get("material_id", ""),
            work_dir=raw.get("work_dir", ""),
            version=raw.get("version", 1),
            updated_at=raw.get("updated_at", time.time()),
            tasks=raw.get("tasks", {}),
        )

    def save(self, path: Path) -> None:
        self.updated_at = time.time()
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "material_id": self.material_id,
                    "work_dir": self.work_dir,
                    "version": self.version,
                    "updated_at": self.updated_at,
                    "tasks": self.tasks,
                },
                f,
                indent=2,
                ensure_ascii=False,
            )
        try:
            os.chmod(path, 0o644)
        except OSError:
            pass

    def get_task(self, name: str) -> TaskState:
        return TaskState.from_dict(self.tasks.get(name, {}))

    def set_task(self, name: str, state: TaskState) -> None:
        self.tasks[name] = state.to_dict()

    def require_done(self, name: str) -> None:
        st = self.get_task(name)
        if st.status != TaskStatus.DONE.value:
            raise RuntimeError(
                f"La tâche '{name}' n'est pas terminée (statut: {st.status}). Arrêt de la chaîne."
            )

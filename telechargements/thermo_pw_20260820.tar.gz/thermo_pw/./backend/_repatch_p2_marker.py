#!/usr/bin/env python3
"""Juillet 2026 (bugfix v2) - re-persistance des markers P2/P3/P4 existants.

v2 - difference vs v1 :
  * Source de verite : on lit ``1_eos_volumes/eos_summary.json`` du DISQUE
    et on l'injecte dans ``results.eos_summary`` (le helper fait ensuite
    l'unnest vers ``results.eos``). Sans cela, les markers sans
    ``results.eos_summary`` (ou avec un eos_summary malforme) etaient
    silently skippes et l'UI restait vide.
  * ``cfg.WORK_ROOT`` au lieu d'un chemin hardcode (CI / paths custom).
  * On appelle systematiquement le helper (idempotent : ``setdefault`` +
    ecrasement des sentinelles ``None``). Plus de skip sur partial
    ``results.eos`` qui aurait laisse des ``None`` bloques pour toujours.

Idempotent : re-run = no-op.
"""
import json
import sys
from pathlib import Path

# Helper isole (cf. _eos_flatten.py). On l'importe en premier : on ajoute
# backend/ au sys.path pour eviter d'avoir a dependre de la config projet.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _eos_flatten import flatten_eos_summary_into_results  # noqa: E402

# WORK_ROOT : on tente cfg.WORK_ROOT (chemin prod), fallback sur chemin
# dev si import echoue (CI sans le module config chargeable).
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import config as _cfg  # noqa: E402

    WORK_ROOT = Path(_cfg.WORK_ROOT)
    del _cfg
except Exception:  # pragma: no cover
    WORK_ROOT = Path("/home/hiadsi/thermo_pw/work")

MARKER_NAME = "pipeline_api_job_state.json"
EOS_SUMMARY_DISK = "1_eos_volumes/eos_summary.json"


def _load_eos_summary_from_disk(work_dir: Path):
    """Lit 1_eos_volumes/eos_summary.json ; retourne None si absent/malforme."""
    p = work_dir / EOS_SUMMARY_DISK
    try:
        if not p.is_file():
            return None
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _process_marker(marker_path: Path) -> str:
    """Repatch un marker. Retourne un statut textuel."""
    try:
        raw = json.loads(marker_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return "json_read_error"
    work_dir_str = raw.get("work_dir") or marker_path.parent
    work_dir = Path(work_dir_str)
    if not (work_dir / EOS_SUMMARY_DISK).is_file():
        return "no_eos_summary_on_disk"
    results = raw.get("results")
    if not isinstance(results, dict):
        results = {}
        raw["results"] = results
    # Source de verite : le disque. On ecrase results.eos_summary si absent
    # OU si sa cle ``eos`` manque (cas du marker P2 ou parse_thermo_pw_log
    # n'a pas tourne, donc eos_summary n'a jamais ete injecte). On preserve
    # toute autre forme (au cas ou parse_thermo_pw_log a enrichi).
    disk_eos = _load_eos_summary_from_disk(work_dir)
    if disk_eos is None:
        return "disk_eos_unreadable"
    current_es = results.get("eos_summary")
    if not isinstance(current_es, dict) or "eos" not in current_es:
        # Reconstruit results.eos_summary avec la version disque enrichie
        # des cles supplementaires deja presentes (si elles existent).
        merged = dict(current_es) if isinstance(current_es, dict) else {}
        merged.update(disk_eos)
        results["eos_summary"] = merged
    # Helper idempotent (ecrase les sentinelles None, ne touche pas aux
    # valeurs reelles, ajoute B0_GPa si manquant).
    flatten_eos_summary_into_results(results)
    # Re-persiste (meme si l'unnest etait deja correct, on garanti la
    # coherence avec la version disque).
    marker_path.write_text(
        json.dumps(raw, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    e = results.get("eos") or {}
    v0 = e.get("V0_bohr3")
    b0 = e.get("B0_GPa")
    b0p = e.get("B0_prime")
    e0 = e.get("E0_Ry")
    if all(isinstance(x, (int, float)) for x in (v0, b0, b0p, e0)):
        return (
            f"OK V0={v0:.2f} bohr^3  B0={b0:.2f} GPa  "
            f"B'={b0p:.3f}  E0={e0:.4f} Ry"
        )
    return f"OK (partial keys: V0={v0} B0={b0} B'={b0p} E0={e0})"


def main() -> int:
    if not WORK_ROOT.is_dir():
        print(f"ERR: {WORK_ROOT} introuvable.")
        return 1
    counts = {"ok": 0, "no_eos_summary_on_disk": 0, "json_read_error": 0,
              "disk_eos_unreadable": 0}
    for marker_path in WORK_ROOT.rglob(MARKER_NAME):
        status = _process_marker(marker_path)
        if status.startswith("OK"):
            counts["ok"] += 1
        elif status in counts:
            counts[status] += 1
        else:
            counts[status] = counts.get(status, 0) + 1
        print(f"  {marker_path.parent.name}: {status}")
    print(f"\nDone: {counts}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

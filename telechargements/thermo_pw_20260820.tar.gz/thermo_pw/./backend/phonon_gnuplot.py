"""
Tracés gnuplot pour phonons : dispersion (phonon.freq) et DOS (phonon.dos).
"""
from __future__ import annotations

import os
import re
import subprocess
from collections import Counter
from pathlib import Path
from typing import Any

import numpy as np

from eos_gnuplot import resolve_gnuplot_executable
from eos_paths import wf1_eos_run_root
from phonon_chain_qe import parse_nat_from_pw

_DAT_BANDS = "phonon_bands_plot.dat"
_GP_BANDS = "plot_phonon_bands.gnu"
_PNG_BANDS = "phonon_bands.png"
_PDF_BANDS = "phonon_bands.pdf"
_GP_DOS = "plot_phonon_dos.gnu"
_PNG_DOS = "phonon_dos.png"
_PDF_DOS = "phonon_dos.pdf"

# Bloc terminal pdfcairo réutilisé après le bloc pngcairo pour produire le PDF
# vectoriel en complément du PNG (multi-output en un seul run gnuplot).
# Taille en cm : 24×17 cm ≈ ratio 920×660 pixels @ 100dpi (échelle vectorielle,
# qualité identique à toute résolution). Font en points, compatible enh.
_PDFCAIRO_BLOCK_TEMPLATE = (
    "\nset terminal pdfcairo size 18.5cm,13cm enhanced font \"Helvetica,11\"\n"
    "set output \"{pdf_name}\"\n"
    "replot\n"
)

_FLOAT_RE = re.compile(r"[-+]?(?:\d*\.\d+|\d+(?:\.\d*)?)(?:[eE][-+]?\d+)?")


def floats_in_line(line: str) -> list[float]:
    return [float(x) for x in _FLOAT_RE.findall(line)]


def _nmodes_from_pw(work_dir: Path) -> int:
    # Les modes vibratoires dépendent du nombre d'atomes (3*nat), pas du nombre
    # d'espèces (ntyp). Avec ntyp=1 et nat=2, il faut 6 branches, pas 3.
    nat = parse_nat_from_pw(work_dir)
    return 3 * int(nat)


def _split_freq_blocks(lines: list[str]) -> list[list[str]]:
    blocks: list[list[str]] = []
    cur: list[str] = []
    for line in lines:
        if re.match(r"^\s*q\s*=\s*$", line.strip()):
            if cur:
                blocks.append(cur)
                cur = []
            continue
        cur.append(line)
    if cur:
        blocks.append(cur)
    return blocks


def _freqs_one_block(lines: list[str], nmodes: int) -> tuple[list[float], list[float]]:
    cleaned = [ln for ln in lines if ln.strip()]
    q_vec: list[float] | None = None
    start_i = 0
    for i, ln in enumerate(cleaned):
        nums = floats_in_line(ln)
        if len(nums) >= 3:
            q_vec = nums[:3]
            start_i = i + 1
            break
    if q_vec is None:
        raise ValueError("Bloc phonon.freq : coordonnées q introuvables (3 nombres attendus).")

    nums_out: list[float] = []
    for ln in cleaned[start_i:]:
        nums = floats_in_line(ln)
        if not nums:
            continue
        low = ln.lower()
        if "q =" in low:
            break
        if len(nums) >= 2:
            nums_out.append(nums[-1])
        elif len(nums) == 1:
            nums_out.append(nums[0])
        if len(nums_out) >= nmodes:
            break
    if len(nums_out) < nmodes:
        raise ValueError(
            f"Bloc phonon.freq : seulement {len(nums_out)} fréquences (attendu {nmodes})."
        )
    return q_vec, nums_out[:nmodes]


def _dist_along_path(qs: list[list[float]]) -> np.ndarray:
    """Distances cumulées en coordonnées cristallines (approximation segmentaire)."""
    if not qs:
        return np.array([])
    qa = np.array(qs, dtype=float)
    d = np.zeros(len(qs))
    for i in range(1, len(qs)):
        dq = qa[i] - qa[i - 1]
        dq -= np.round(dq)
        d[i] = d[i - 1] + float(np.linalg.norm(dq))
    return d


def _parse_nbnd_from_plot_header(lines: list[str]) -> int | None:
    """Lit nbnd dans le namelist &plot ... / (une ou plusieurs lignes Fortran)."""
    buf: list[str] = []
    in_plot = False
    n_after = 0
    for ln in lines[:200]:
        s = ln.strip()
        if not in_plot:
            if "&plot" in ln.lower():
                in_plot = True
                buf.append(ln)
                n_after = 1
            continue
        buf.append(ln)
        n_after += 1
        if s.startswith("!"):
            continue
        if "/" in ln:
            break
        if n_after > 25:
            break
    if not buf:
        return None
    chunk = "\n".join(buf)
    m = re.search(r"nbnd\s*=\s*(\d+)", chunk, flags=re.I)
    if m:
        return int(m.group(1))
    return None


def _has_matdyn_plot_namelist(lines: list[str]) -> bool:
    return any("&plot" in ln.lower() for ln in lines[:220])


def _parse_matdyn_plot_pairs_q_x(lines: list[str], nmodes: int) -> tuple[list[list[float]], list[float]]:
    """
    Même logique que ``_parse_matdyn_plot_pairs`` mais retourne les q (3) et
    l'abscisse cumulée (4ᵉ nombre) pour chaque point du chemin.
    """
    start = None
    for i, ln in enumerate(lines):
        if "&plot" in ln.lower():
            start = i + 1
            break
    if start is None:
        return [], []

    qs: list[list[float]] = []
    xs: list[float] = []
    buf: list[float] = []
    expecting_q = True
    i = start

    while i < len(lines):
        ln_a = lines[i].strip()
        if not ln_a or ln_a.startswith("!"):
            i += 1
            continue
        if ln_a.startswith("&"):
            break

        nums = floats_in_line(ln_a)

        if expecting_q:
            if len(nums) < 4:
                break
            qs.append([float(nums[0]), float(nums[1]), float(nums[2])])
            xs.append(float(nums[3]))
            buf = []
            expecting_q = False
            i += 1
            continue

        if not nums:
            break
        buf.extend(nums)
        if len(buf) >= nmodes:
            buf = []
            expecting_q = True
        i += 1

    return qs, xs


def _read_phonon_freq_q_path(freq_path: Path, nmodes: int) -> tuple[list[list[float]], list[float]] | None:
    """Lit (q_vectors, abscisses cumulées) depuis ``phonon.freq`` si possible."""
    try:
        text = freq_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    lines = text.splitlines()
    nbnd_hdr = _parse_nbnd_from_plot_header(lines)
    nmodes_eff = int(nmodes)
    if nbnd_hdr is not None and nbnd_hdr > 0 and nbnd_hdr != nmodes_eff:
        nmodes_eff = nbnd_hdr

    has_q_sep = any(re.search(r"^\s*q\s*=\s*$", ln.strip()) for ln in lines[:4000])
    looks_like_matdyn_plot = _has_matdyn_plot_namelist(lines) and not has_q_sep

    if not looks_like_matdyn_plot:
        blocks = _split_freq_blocks(lines)
        if blocks:
            qs: list[list[float]] = []
            for blk in blocks:
                try:
                    q, _fr = _freqs_one_block(blk, nmodes_eff)
                except ValueError:
                    continue
                qs.append(q)
            if qs:
                dist = _dist_along_path(qs)
                xs = [float(x) for x in dist.tolist()]
                return qs, xs

    qs2, xs2 = _parse_matdyn_plot_pairs_q_x(lines, nmodes_eff)
    if qs2 and xs2 and len(qs2) == len(xs2):
        return qs2, xs2
    return None


def _xtics_vertex_x_from_freq_path(
    vertices: list[list[float]],
    qs: list[list[float]],
    xs: list[float],
    *,
    tol: float = 4e-2,
) -> list[float] | None:
    """
    Pour chaque sommet du chemin déclaré dans ``matdyn_bands.in``, trouve l’abscisse
    dans les données réelles ``phonon.freq`` (premier point q convenant en ordre croissant).
    """
    if len(qs) != len(xs) or len(qs) < 2 or len(vertices) < 2:
        return None
    out_x: list[float] = []
    last_k = -1
    for v in vertices:
        found: int | None = None
        for k in range(last_k + 1, len(qs)):
            if _near_special(qs[k], [float(v[0]), float(v[1]), float(v[2])], tol=tol):
                found = k
                break
        if found is None:
            return None
        last_k = found
        out_x.append(float(xs[last_k]))
    if len(out_x) != len(vertices):
        return None
    return out_x


def _parse_matdyn_plot_pairs(lines: list[str], nmodes: int) -> tuple[list[float], list[list[float]]]:
    """
    Format typique matdyn.x (chemins en bandes) :
      &plot nbnd=NM, nks=NK /
      ligne q : qx qy qz  distance_cumulée   (exactement 4 nombres)
      une ou plusieurs lignes : jusqu'à NM fréquences (wrap autorisé)

    Ne pas prendre NM>=4 comme critère pour « nouveau q » : les bandes ont souvent
    des lignes de fréquences avec 6, 12, 15… nombres (bug ancien parseur).
    """
    start = None
    for i, ln in enumerate(lines):
        if "&plot" in ln.lower():
            start = i + 1
            break
    if start is None:
        return [], []

    xs: list[float] = []
    freqs: list[list[float]] = []
    buf: list[float] = []
    expecting_q = True
    i = start

    while i < len(lines):
        ln_a = lines[i].strip()
        if not ln_a or ln_a.startswith("!"):
            i += 1
            continue
        if ln_a.startswith("&"):
            break

        nums = floats_in_line(ln_a)

        if expecting_q:
            if len(nums) < 4:
                break
            xs.append(float(nums[3]))
            buf = []
            expecting_q = False
            i += 1
            continue

        # Fréquences : accumuler jusqu'à nmodes
        if not nums:
            break
        buf.extend(nums)
        if len(buf) >= nmodes:
            freqs.append([float(x) for x in buf[:nmodes]])
            buf = []
            expecting_q = True
        i += 1

    return xs, freqs


def _write_bands_dat(work_dir: Path, freq_path: Path, nmodes: int) -> tuple[int, Path]:
    text = freq_path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()

    nbnd_hdr = _parse_nbnd_from_plot_header(lines)
    nmodes_eff = int(nmodes)
    if nbnd_hdr is not None and nbnd_hdr > 0 and nbnd_hdr != nmodes_eff:
        # En pratique, le fichier phonon.freq est la source de vérité pour le nombre
        # de branches réellement écrites par matdyn.x.
        nmodes_eff = nbnd_hdr

    xs: list[float] = []
    freqs: list[list[float]] = []

    has_q_sep = any(re.search(r"^\s*q\s*=\s*$", ln.strip()) for ln in lines[:4000])
    # Le format "&plot ... /" + (ligne q à 4 nombres, puis fréquences) n'utilise pas 'q =' :
    # ne pas exiger que nbnd soit déjà parsé : sinon on retombe sur le parseur par blocs
    # et on échoue sur un gros bloc unique.
    looks_like_matdyn_plot = _has_matdyn_plot_namelist(lines) and not has_q_sep

    # 1) Ancien format : blocs séparés par des lignes 'q =' (ou assimilées)
    if not looks_like_matdyn_plot:
        blocks = _split_freq_blocks(lines)
    else:
        blocks = []
    if blocks:
        qs: list[list[float]] = []
        freqs_q = []
        for blk in blocks:
            try:
                q, fr = _freqs_one_block(blk, nmodes_eff)
            except ValueError:
                continue
            qs.append(q)
            freqs_q.append(fr)
        if qs:
            dist = _dist_along_path(qs)
            xs = [float(x) for x in dist.tolist()]
            freqs = freqs_q

    # 2) Format matdyn 'plot pairs' (très fréquent pour les dispersions sur chemin)
    if not freqs:
        xs2, freqs2 = _parse_matdyn_plot_pairs(lines, nmodes_eff)
        if xs2 and freqs2:
            xs, freqs = xs2, freqs2

    if not freqs:
        raise ValueError(
            "Impossible de lire phonon.freq — vérifiez le fichier ou utilisez matdyn §1.8 avant le tracé."
        )

    arr = np.column_stack([np.array(xs, dtype=float), np.array(freqs, dtype=float)])
    out = work_dir / _DAT_BANDS
    hdr = "# colonne 1 : distance le long du chemin q (si disponible) ; colonnes 2+ : fréquences (unités du fichier)\n"
    out.write_text(hdr + "\n".join(" ".join(f"{x:.10g}" for x in row) for row in arr), encoding="utf-8")
    return arr.shape[1] - 1, out


def _bands_dat_branch_count(plot_dat: Path) -> int | None:
    """
    Nombre de courbes gnuplot pour ``using 1:2`` … ``1:ncol`` : ``ncol_tot - 1``
    si le fichier ``phonon_bands_plot.dat`` (ou équivalent) a une colonne 1 =
    abscisse et colonnes suivantes = bandes.

    Tolère quelques lignes irrégulières si ≥85 % des lignes numériques ont la
    même largeur (≥ 2 colonnes).
    """
    if not plot_dat.is_file():
        return None
    try:
        text = plot_dat.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    lengths: list[int] = []
    for line in text.splitlines():
        ls = line.strip()
        if not ls or ls.startswith("#"):
            continue
        nums = floats_in_line(ls.replace(",", " "))
        if len(nums) < 2:
            continue
        lengths.append(len(nums))
        if len(lengths) > 200_000:
            break
    if len(lengths) < 2:
        return None
    c0, n0 = Counter(lengths).most_common(1)[0]
    if n0 < max(2, int(0.85 * len(lengths))):
        return None
    return c0 - 1


_BAND_VERTEX_LINE = re.compile(
    r"^\s*([-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?)\s+"
    r"([-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?)\s+"
    r"([-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?)\s+(\d+)\s*(?:!.*)?$"
)


def _fold_frac_components(q: np.ndarray) -> np.ndarray:
    x = np.asarray(q, dtype=float).reshape(-1) % 1.0
    return np.where(x > 1.0 - 1e-9, 0.0, x)


def _same_frac_point(a: list[float], b: list[float], *, tol: float = 2e-4) -> bool:
    da = _fold_frac_components(np.asarray(a) - np.asarray(b))
    da = np.where(da > 0.5, da - 1.0, da)
    da = np.where(da < -0.5, da + 1.0, da)
    return bool(np.all(np.abs(da) < tol))


def _minsym_coords(q: list[float]) -> np.ndarray:
    """Ramène les coordonnées cristallines dans [-0.5, 0.5) pour comparer aux tables BZ."""
    x = np.asarray(q, dtype=float).reshape(-1)
    return (x + 0.5) % 1.0 - 0.5


def _near_special(q: list[float], ref: list[float], *, tol: float = 2.5e-3) -> bool:
    dq = _minsym_coords(q) - _minsym_coords(ref)
    return float(np.linalg.norm(dq)) < tol


def _any_near_perm(q: list[float], refs: tuple[list[float], ...]) -> bool:
    return any(_near_special(q, list(r)) for r in refs)


def _path_suggests_fcc_style(vertices: list[list[float]]) -> bool:
    """Heuristique FCC (primitif) : présence de W, K ou de X-type face (½,0,½) hors plan basal."""
    for q in vertices:
        if _near_special(q, [0.5, 0.25, 0.75]) or _near_special(q, [0.375, 0.375, 0.75]):
            return True
        # X FCC : deux composantes ±½ et une nulle (distinct du X sur axe simple si qz≠0)
        m = _minsym_coords(q)
        ax = np.sum(np.isclose(np.abs(m), 0.5, atol=2e-3))
        zr = np.sum(np.isclose(m, 0.0, atol=2e-3))
        if ax == 2 and zr == 1 and not _near_special(q, [0.5, 0.5, 0.0]):
            return True
    return False


def _path_suggests_bcc_style(vertices: list[list[float]]) -> bool:
    """Heuristique BCC : au moins un q explicite avec composante < 0 (ex. H), ou P au tiers de zone."""
    for q in vertices:
        raw = np.asarray(q, dtype=float).reshape(-1)
        if np.min(raw) < -1e-6:
            return True
        if _near_special(q, [0.25, 0.25, 0.25]) or _near_special(q, [-0.25, -0.25, -0.25]):
            return True
    return False


def _path_suggests_hex_style(vertices: list[list[float]]) -> bool:
    """Hexagonal (ibrav 4) : K dans le plan de base ou H sur la face supérieure."""
    for q in vertices:
        if _near_special(q, [1.0 / 3.0, 1.0 / 3.0, 0.0]):
            return True
        if _near_special(q, [1.0 / 3.0, 1.0 / 3.0, 0.5]):
            return True
    return False


def _path_suggests_tetragonal_style(vertices: list[list[float]]) -> bool:
    """Tétragonal simple (ibrav 6) : Z, R et A présents, sans indices FCC/BCC/hex."""
    if not vertices or _path_suggests_hex_style(vertices):
        return False
    if _path_suggests_fcc_style(vertices) or _path_suggests_bcc_style(vertices):
        return False
    has_a = any(_near_special(q, [0.5, 0.5, 0.5]) for q in vertices)
    has_z = any(_near_special(q, [0.0, 0.0, 0.5]) for q in vertices)
    has_r = any(_near_special(q, [0.5, 0.0, 0.5]) for q in vertices)
    return bool(has_a and has_z and has_r)


def _vertex_high_symm_label(q: list[float], *, vertices: list[list[float]] | None = None) -> str:
    """Libellés Γ, X, M, R/L, W, K, U, N, P, H, A, Z… (sc / fcc / bcc / hex / tétr., coords cristallines)."""
    hint_fcc = bool(vertices and _path_suggests_fcc_style(vertices))
    hint_bcc = bool(vertices and _path_suggests_bcc_style(vertices))
    hint_hex = bool(vertices and _path_suggests_hex_style(vertices))
    hint_tetra = bool(vertices and _path_suggests_tetragonal_style(vertices))

    # --- Ordre : points les plus « discriminants » en premier
    if _near_special(q, [0.0, 0.0, 0.0]):
        return "Γ"

    if hint_hex:
        if _near_special(q, [0.5, 0.0, 0.0]):
            return "M"
        if _near_special(q, [1.0 / 3.0, 1.0 / 3.0, 0.0]):
            return "K"
        if _near_special(q, [0.0, 0.0, 0.5]):
            return "A"
        if _near_special(q, [0.5, 0.0, 0.5]):
            return "L"
        if _near_special(q, [1.0 / 3.0, 1.0 / 3.0, 0.5]):
            return "H"

    # FCC : W, K, U
    if hint_fcc and _any_near_perm(
        q,
        (
            [0.5, 0.25, 0.75],
            [0.25, 0.5, 0.75],
            [0.75, 0.5, 0.25],
            [-0.5, -0.25, -0.75],
        ),
    ):
        return "W"
    if hint_fcc and _any_near_perm(q, ([3.0 / 8.0, 3.0 / 8.0, 3.0 / 4.0], [3.0 / 8.0, 3.0 / 4.0, 3.0 / 8.0])):
        return "K"
    if hint_fcc and _any_near_perm(
        q,
        (
            [5.0 / 8.0, 1.0 / 4.0, 5.0 / 8.0],
            [5.0 / 8.0, 5.0 / 8.0, 1.0 / 4.0],
            [1.0 / 4.0, 5.0 / 8.0, 5.0 / 8.0],
            [1.0 / 8.0, 5.0 / 8.0, 1.0 / 4.0],
            [1.0 / 8.0, 1.0 / 4.0, 5.0 / 8.0],
            [5.0 / 8.0, 1.0 / 8.0, 5.0 / 8.0],
        ),
    ):
        return "U"

    # BCC : H, N, P — H exige une composante négative (sinon confusion L FCC ≡ H BCC par pliage)
    if hint_bcc and float(np.min(np.asarray(q, dtype=float))) < -1e-6 and _any_near_perm(
        q,
        (
            [0.5, -0.5, 0.5],
            [-0.5, 0.5, 0.5],
            [0.5, 0.5, -0.5],
            [-0.5, -0.5, 0.5],
        ),
    ):
        return "H"
    if hint_bcc and _any_near_perm(q, ([0.0, 0.0, 0.5], [0.0, 0.5, 0.0], [0.5, 0.0, 0.0])):
        return "N"
    if hint_bcc and (
        _near_special(q, [0.25, 0.25, 0.25]) or _near_special(q, [-0.25, -0.25, -0.25])
    ):
        return "P"

    # Coin cubique : L (FCC), A (tétr.), R (SC)
    if _near_special(q, [0.5, 0.5, 0.5]):
        if hint_fcc:
            return "L"
        if hint_tetra:
            return "A"
        return "R"

    if hint_tetra:
        if _near_special(q, [0.0, 0.0, 0.5]):
            return "Z"
        if _near_special(q, [0.5, 0.0, 0.5]):
            return "R"

    ms = sorted(float(x) for x in np.abs(_minsym_coords(q)))
    if (
        len(ms) == 3
        and np.isclose(ms[0], 0.0, atol=2e-3)
        and np.isclose(ms[1], 0.5, atol=2e-3)
        and np.isclose(ms[2], 0.5, atol=2e-3)
    ):
        return "X" if hint_fcc else "M"
    if (
        len(ms) == 3
        and np.isclose(ms[0], 0.0, atol=2e-3)
        and np.isclose(ms[1], 0.0, atol=2e-3)
        and np.isclose(ms[2], 0.5, atol=2e-3)
    ):
        return "X"

    # Ancien point « K » triangular 2D / hex (≠ FCC K)
    if _near_special(q, [1.0 / 3.0, 1.0 / 3.0, 0.0]):
        return "K"

    qf = _fold_frac_components(np.asarray(q))
    return f"({qf[0]:.2g},{qf[1]:.2g},{qf[2]:.2g})"


def parse_matdyn_bands_vertices(work_dir: Path) -> tuple[list[list[float]], list[int]] | None:
    """
    Lit les sommets du chemin q dans ``matdyn_bands.in`` (format thermo_pw §1.8).
    Chaque ligne valide : qx qy qz nk ; nk est ignoré pour les étiquettes mais gardé pour extension future.
    Retourne None si fichier absent ou aucune ligne reconnue.
    """
    p = work_dir / "matdyn_bands.in"
    if not p.is_file():
        return None
    try:
        lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return None
    past_input = False
    verts: list[list[float]] = []
    nks: list[int] = []
    for ln in lines:
        s = ln.strip()
        if not past_input:
            if re.match(r"^\s*/\s*$", ln):
                past_input = True
            continue
        if not s or s.startswith("!"):
            continue
        if re.match(r"^\d+\s*$", s):
            continue
        m = _BAND_VERTEX_LINE.match(ln)
        if not m:
            if verts:
                break
            continue
        verts.append([float(m.group(1)), float(m.group(2)), float(m.group(3))])
        nks.append(int(m.group(4)))
    if len(verts) < 2:
        return None
    return verts, nks


def cumulative_q_path_breaks(vertices: list[list[float]]) -> list[float]:
    """
    Abscisses aux jonctions entre segments = même métrique que la 4ᵉ colonne matdyn (phonon.freq)
    pour un chemin linéaire par morceaux en coordonnées cristallines réduites.
    """
    breaks: list[float] = [0.0]
    cum = 0.0
    for i in range(len(vertices) - 1):
        dq = np.asarray(vertices[i + 1], dtype=float) - np.asarray(vertices[i], dtype=float)
        dq -= np.round(dq)
        cum += float(np.linalg.norm(dq))
        breaks.append(cum)
    return breaks


def phonon_band_path_xtics(work_dir: Path) -> list[tuple[str, float]] | None:
    """Paires (symbole, abscisse) pour ``set xtics`` depuis ``matdyn_bands.in``.

    Les abscisses sont prises sur **les q réellement présents dans** ``phonon.freq``
    lorsque le fichier existe et que les sommets du ``matdyn_bands.in`` s’y retrouvent
    (évite ticks décalés ou fantômes si un ancien ``phonon.freq`` ne correspond pas).
    Sinon repli sur la métrique cumulée calculée depuis la liste de sommets seule.
    """
    parsed = parse_matdyn_bands_vertices(work_dir)
    if not parsed:
        return None
    vertices, _ = parsed
    freq_path = work_dir / "phonon.freq"
    if freq_path.is_file():
        qpx = _read_phonon_freq_q_path(freq_path, _nmodes_from_pw(work_dir))
        if qpx:
            qs, fx = qpx
            x_at_vertex: list[float] | None = None
            for tol in (4e-2, 8e-2):
                x_at_vertex = _xtics_vertex_x_from_freq_path(vertices, qs, fx, tol=tol)
                if x_at_vertex is not None:
                    break
            if x_at_vertex is not None and len(x_at_vertex) == len(vertices):
                return [
                    (_vertex_high_symm_label(q, vertices=vertices), xv) for q, xv in zip(vertices, x_at_vertex)
                ]
    xs = cumulative_q_path_breaks(vertices)
    if len(xs) != len(vertices):
        return None
    return [(_vertex_high_symm_label(q, vertices=vertices), float(x)) for q, x in zip(vertices, xs)]


def phonon_path_sequence_arrow_labels(path_xtics: list[tuple[str, float]]) -> str:
    """Chaîne « Γ → X → … » pour titre gnuplot (répète Γ, X, … aux jonctions successives)."""
    if not path_xtics:
        return ""
    labs = [lab for lab, _ in path_xtics]
    return " → ".join(labs)


def matdyn_path_mismatch_hint(work_dir: Path) -> str | None:
    """Si ``matdyn_bands.in`` ne correspond pas au chemin attendu pour ``ibrav`` du PW (ex. Si FCC vs cubique simple)."""
    try:
        from phonon_chain_qe import matdyn_band_qpath_for_ibrav, parse_ibrav_from_pw
    except ImportError:
        return None
    ib = parse_ibrav_from_pw(work_dir)
    if ib not in (1, 2, 3, 4, 6):
        return None
    parsed = parse_matdyn_bands_vertices(work_dir)
    if not parsed:
        return None
    verts_file, _ = parsed
    ref_tuples, _ = matdyn_band_qpath_for_ibrav(ib)
    ref = [list(map(float, t)) for t in ref_tuples]
    if len(verts_file) != len(ref):
        return (
            f"Attention — {len(verts_file)} sommets dans matdyn_bands.in, "
            f"{len(ref)} attendus pour ibrav={ib}. Relancer matdyn (bandes)."
        )
    for a, b in zip(verts_file, ref):
        if not _near_special(a, [float(x) for x in b], tol=5e-3):
            return (
                f"Attention — chemin q ≠ chemin type ibrav={ib} (ex. FCC : X=(0,½,½), pas (½,0,0)). "
                f"Relancer matdyn bandes après régénération de matdyn_bands.in."
            )
    return None


def _phonon_plot_xticks_freq_abscissa_mismatch(work_dir: Path, path_xtics: list[tuple[str, float]]) -> str | None:
    """Détecte ticks basés sur matdyn alors que l’abscisse des données vient d’un autre run matdyn."""
    pdat = work_dir / _DAT_BANDS
    if not path_xtics or not pdat.is_file():
        return None
    try:
        raw = pdat.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    col0: list[float] = []
    for ln in raw.splitlines():
        ls = ln.strip()
        if not ls or ls.startswith("#"):
            continue
        nums = floats_in_line(ls.replace(",", " "))
        if len(nums) >= 2:
            col0.append(float(nums[0]))
    if not col0:
        return None
    mx_dat = max(col0)
    mxt = max(float(x) for _, x in path_xtics)
    if abs(mx_dat - mxt) / mx_dat > 0.12:
        return (
            "Attention — relancer matdyn (bandes) : phonon.freq ne correspond probablement pas "
            "au matdyn_bands.in actuel (axe q vs ticks)."
        )
    return None


_BAND_PALETTE_HEX = (
    "#1e40af",
    "#eab308",
    "#16a34a",
    "#9a3412",
    "#9333ea",
    "#78716c",
    "#0891b2",
    "#db2777",
    "#d97706",
    "#4338ca",
    "#059669",
    "#b91c1c",
)


def _gnuplot_bands_script(
    png_name: str,
    nmodes: int,
    title: str,
    *,
    meta_comment: str | None = None,
    path_xtics: list[tuple[str, float]] | None = None,
    path_sequence_line: str | None = None,
    extra_title_line: str | None = None,
    pdf_name: str | None = None,
) -> str:
    """Tracé multi-branches avec couleurs distinctes ; fréquences ω<0 (modes instables QE) conservées.

    Si ``pdf_name`` est fourni, un second bloc (``set terminal pdfcairo`` +
    ``replot``) est ajouté après le bloc PNG : un seul run gnuplot produit
    alors le PNG + le PDF (vectoriel, intégrable LaTeX/présentations).
    """
    title_esc = title.replace('"', " ")
    title_full = title_esc
    if path_sequence_line:
        sq = path_sequence_line.replace('"', "'").replace("\\", "/")[:420]
        title_full = title_full + "\\n{/Helvetica=10 " + sq + "}"
    if extra_title_line:
        ex = extra_title_line.replace('"', "'").replace("\\", "/")[:360]
        title_full = title_full + "\\n{/Helvetica=9 " + ex + "}"
    hint = ""
    if meta_comment:
        s = " ".join(meta_comment.split())[:240].replace("#", "")
        if s:
            hint = f"# Source données : {s}\n"
    # Guillemets doubles : chemins évolutifs sous Windows/Linux ; gnuplot permet '' pour réutiliser le même fichier.
    qfn = '"' + _DAT_BANDS.replace("\\", "/") + '"'
    if nmodes < 1:
        nmodes = 1
    parts: list[str] = []
    for col in range(2, nmodes + 2):
        color = _BAND_PALETTE_HEX[(col - 2) % len(_BAND_PALETTE_HEX)]
        lead = qfn if col == 2 else "''"
        parts.append(
            f"{lead} using 1:{col} with lines lw 1.25 lc rgb '{color}' title 'Branche {col - 1}'"
        )
    plot_clause = ", \\\n    ".join(parts)

    xlabel = "Distance q (cumul coord. cristallines)"
    preamble_xtics = ""
    if path_xtics:
        xlabel = "Chemin q — sommets du chemin (matdyn_bands.in)"
        tic_esc = ', '.join(
            f'"{lab.replace(chr(34), chr(39))}" {float(xv):.12g}' for lab, xv in path_xtics
        )
        arrows = "\n".join(
            f"set arrow from {float(xv):.12g}, graph 0 to {float(xv):.12g}, graph 1 nohead dt 2 lw 1 lc rgb '#94a3b8' front"
            for _, xv in path_xtics
            if float(xv) > 1e-14
        )
        preamble_xtics = f"""{arrows}
set xtics ({tic_esc})
set xtics nomirror
"""

    png_esc = png_name.replace("\\", "/")
    pdf_block = (
        _PDFCAIRO_BLOCK_TEMPLATE.format(pdf_name=str(pdf_name).replace("\\", "/"))
        if pdf_name
        else ""
    )
    # zeroaxis visible quand les fréquences sont négatives (imag.), comme un tracé gnuplot interactif standard
    return f"""{hint}# Généré par thermo_pw (phonon_gnuplot)
set terminal pngcairo size 920,660 enhanced font "Helvetica,11"
set output "{png_esc}"
set title "{title_full}" enhanced
set xlabel "{xlabel.replace(chr(34), chr(39))}"
set ylabel "Fréquence (unités QE)"
set grid
set xrange [*:*]
set yrange [*:*]
set zeroaxis lt -1 lw 1.4 lc rgb "#0f172a"
set key top right opaque spacing 1.2 sample 2 box lt -1 lw 1
{preamble_xtics}plot {plot_clause}{pdf_block}
"""


def _gnuplot_dos_script(png_name: str, fldos: str, title: str, *, pdf_name: str | None = None) -> str:
    """Tracé DOS phonons — PNG (+ PDF vectoriel si ``pdf_name`` fourni)."""
    title_esc = title.replace('"', " ")
    pdf_block = (
        _PDFCAIRO_BLOCK_TEMPLATE.format(pdf_name=str(pdf_name).replace("\\", "/"))
        if pdf_name
        else ""
    )
    return f"""# Généré par thermo_pw (phonon_gnuplot)
set terminal pngcairo size 900,520 enhanced font "Helvetica,11"
set output "{png_name}"
set title "{title_esc}" noenhanced
set xlabel "Fréquence (unités QE)"
set ylabel "DOS"
set grid
plot '{fldos}' using 1:2 with lines lw 2 lc rgb "#0f766e" title 'DOS total'{pdf_block}
"""


def _run_gp(gnu_exe: str, cwd: Path, script_name: str, script_body: str, png_path: Path) -> None:
    sp = cwd / script_name
    sp.write_text(script_body, encoding="utf-8")
    if png_path.is_file():
        try:
            png_path.unlink()
        except OSError:
            pass
    r = subprocess.run(
        [gnu_exe, script_name],
        cwd=cwd,
        capture_output=True,
        text=False,
        env={**os.environ},
        timeout=180,
    )
    if r.returncode != 0 or not png_path.is_file():
        raw = (r.stderr or r.stdout or b"")[:6000]
        err = raw.decode("utf-8", errors="replace")
        raise RuntimeError(f"gnuplot a échoué (code {r.returncode}): {err}")


def run_gnuplot_phonon_bands(work_dir: Path, *, flfrq: str = "phonon.freq") -> dict[str, Any]:
    """phonon.freq → phonon_bands_plot.dat (+ repli sur .dat prêt gnuplot si besoin) → PNG."""
    gnu_exe = resolve_gnuplot_executable()
    if not gnu_exe:
        raise RuntimeError(
            "gnuplot est requis pour les tracés (aucun exécutable trouvé). "
            "Installez gnuplot ou définissez THERMO_GNUPLOT=/usr/bin/gnuplot."
        )
    work_dir = wf1_eos_run_root(Path(work_dir).resolve())
    nmodes = _nmodes_from_pw(work_dir)

    raw = Path(str(flfrq).replace("\\", "/").strip()).name
    fl_base = raw if raw and raw not in (".", "..") else "phonon.freq"

    freq_path = work_dir / fl_base
    plot_dat = work_dir / _DAT_BANDS

    nb: int
    dat_path: Path
    bands_src: str

    if freq_path.is_file() and freq_path.name == _DAT_BANDS:
        nb_d = _bands_dat_branch_count(freq_path)
        if nb_d is None or nb_d < 1:
            raise ValueError(
                f"{_DAT_BANDS} est illisible ou irrégulier (≥2 lignes à ≥2 colonnes numériques attendues)."
            )
        nb, dat_path, bands_src = nb_d, freq_path, _DAT_BANDS
    elif freq_path.is_file():
        try:
            nb, dat_path = _write_bands_dat(work_dir, freq_path, nmodes)
            bands_src = fl_base
        except ValueError as ex:
            nb_fb = _bands_dat_branch_count(plot_dat)
            if nb_fb is None or nb_fb < 1:
                raise ValueError(
                    str(ex)
                    + f" ; pas de {_DAT_BANDS} exploitable dans {work_dir} (tracez depuis ce fichier si vous l'avez déjà produit)."
                ) from ex
            nb = nb_fb
            dat_path = plot_dat
            bands_src = f"{_DAT_BANDS} (repli — {fl_base} non lisible)"
    else:
        nb_fb = _bands_dat_branch_count(plot_dat)
        if nb_fb is None or nb_fb < 1:
            raise FileNotFoundError(
                f"{fl_base} introuvable dans {work_dir} et pas de {_DAT_BANDS} valide — "
                "lancez matdyn (bandes) ou placez un phonon_bands_plot.dat."
            )
        nb = nb_fb
        dat_path = plot_dat
        bands_src = f"{_DAT_BANDS} ({fl_base} absent)"

    png_path = work_dir / _PNG_BANDS
    pdf_path = work_dir / _PDF_BANDS
    title = f"Dispersion de phonons ({nb} branches)"
    path_labels = phonon_band_path_xtics(work_dir)
    seq_line = phonon_path_sequence_arrow_labels(path_labels) if path_labels else None
    warn_parts: list[str] = []
    w1 = matdyn_path_mismatch_hint(work_dir)
    if w1:
        warn_parts.append(w1)
    w2 = _phonon_plot_xticks_freq_abscissa_mismatch(work_dir, path_labels or [])
    if w2:
        warn_parts.append(w2)
    warn_line = " ".join(warn_parts) if warn_parts else None
    _run_gp(
        gnu_exe,
        work_dir,
        _GP_BANDS,
        _gnuplot_bands_script(
            _PNG_BANDS,
            nb,
            title,
            meta_comment=bands_src,
            path_xtics=path_labels,
            path_sequence_line=seq_line,
            extra_title_line=warn_line,
            pdf_name=_PDF_BANDS,
        ),
        png_path,
    )

    out: dict[str, Any] = {
        "png_path": str(png_path.resolve()),
        "relpath": _PNG_BANDS,
        "gnuplot_script": str((work_dir / _GP_BANDS).resolve()),
        "dat_path": str(dat_path.resolve()),
        "renderer": "gnuplot",
        "nmodes": nb,
        "bands_source": bands_src,
    }
    # Schéma cohérent : ``pdf_path`` / ``pdf_relpath`` TOUJOURS présents dans le
    # dict de retour (None si le bloc multi-output pdfcairo a échoué
    # silencieusement). Certaines versions de gnuplot retournent exit=0 même
    # quand le second bloc terminal échoue (cf. _PDFCAIRO_BLOCK_TEMPLATE).
    # Filet de sécurité contre l'échec silencieux du PDF vectoriel.
    if pdf_path.is_file():
        out["pdf_path"] = str(pdf_path.resolve())
        out["pdf_relpath"] = _PDF_BANDS
    else:
        out["pdf_path"] = None
        out["pdf_relpath"] = None
    if path_labels:
        out["phonon_path_xtics"] = [{"label": a, "x": b} for a, b in path_labels]
        if seq_line:
            out["phonon_path_sequence"] = seq_line
    if warn_line:
        out["matdyn_path_warning"] = warn_line
    return out


def run_gnuplot_phonon_dos(work_dir: Path, *, fldos: str = "phonon.dos") -> dict[str, Any]:
    gnu_exe = resolve_gnuplot_executable()
    if not gnu_exe:
        raise RuntimeError(
            "gnuplot est requis pour les tracés (aucun exécutable trouvé). "
            "Installez gnuplot ou définissez THERMO_GNUPLOT=/usr/bin/gnuplot."
        )
    work_dir = wf1_eos_run_root(Path(work_dir).resolve())
    dos_path = work_dir / fldos
    if not dos_path.is_file():
        raise FileNotFoundError(f"{fldos} introuvable dans {work_dir} — lancez matdyn (DOS) avant.")

    png_path = work_dir / _PNG_DOS
    pdf_path = work_dir / _PDF_DOS
    title = f"DOS phonons — {fldos}"
    _run_gp(
        gnu_exe,
        work_dir,
        _GP_DOS,
        _gnuplot_dos_script(_PNG_DOS, fldos, title, pdf_name=_PDF_DOS),
        png_path,
    )

    out: dict[str, Any] = {
        "png_path": str(png_path.resolve()),
        "relpath": _PNG_DOS,
        "gnuplot_script": str((work_dir / _GP_DOS).resolve()),
        "renderer": "gnuplot",
    }
    # Schéma cohérent : ``pdf_path`` / ``pdf_relpath`` TOUJOURS présents.
    # None si pdfcairo a échoué silencieusement (cf. docstring
    # run_gnuplot_phonon_bands pour les raisons techniques).
    if pdf_path.is_file():
        out["pdf_path"] = str(pdf_path.resolve())
        out["pdf_relpath"] = _PDF_DOS
    else:
        out["pdf_path"] = None
        out["pdf_relpath"] = None
    return out

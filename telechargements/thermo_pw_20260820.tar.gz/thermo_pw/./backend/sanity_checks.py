"""
Sanity checks scientifiques pour les runs thermo_pw (5 profils).

But : exposer en un GET une analyse best-effort post-run qui détecte les
anomalies majeures qu'un chercheur veut voir en un coup d'œil :
  * instabilité dynamique (fréquences phononiques négatives),
  * stabilité mécanique Born (critères C_ij cubiques),
  * plausibilité du coefficient de Poisson,
  * dérivée B' du fit Birch-Murnaghan (autour de 4 typique),
  * convergence des forces résiduelles SCF.

Aucun check ne lève jamais : un sous-check qui plante renvoie
``level="unknown"`` et un message d'erreur lisible côté UI.

Toutes les bornes sont en haut du module — ajustables sans toucher au
reste. Les références physiques utilisées :
  * Born stability criteria (Hu, Sole, Johansson 2018, etc.),
  * seuils DFT standard ``conv_thr`` 1e-4 → ``|F|max`` ~ 5e-4 Ry/bohr,
  * B' typique entre 3 et 6 pour la plupart des solides (Holzapfel 2001).
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Callable, Dict, Optional


# ============================================================
# Seuils (ajustables) — tous en global pour modification facile.
# ============================================================

# Fréquences phononiques (THz). -0.5 = instabilité nette, -0.1 = bruit ASR.
THRESH_PHONON_WARN_THz = -0.1
THRESH_PHONON_ERROR_THz = -0.5

# Marges Born (GPa). Si critère respecté mais marge ≤ 5 GPa → WARN.
BORN_MARGIN_WARN_GPa = 5.0

# Poisson ratio
POISSON_OK_MIN = 0.05
POISSON_OK_MAX = 0.45

# B' (Birch-Murnaghan derivative)
BPRIME_OK_MIN = 3.0
BPRIME_OK_MAX = 6.0
BPRIME_WARN_MIN = 2.0
BPRIME_WARN_MAX = 8.0

# Forces résiduelles (Ry/bohr).
FORCE_OK_RY = 5.0e-4
FORCE_WARN_RY = 5.0e-3


# ============================================================
# Helpers bas niveau (lecture bornée, scan).
# ============================================================

_MAX_READ_BYTES = 8 * 1024 * 1024  # 8 Mo, on évite d'OOM un worker sur un gros .out


def _read_text_bounded(
    path: Path, max_bytes: int = _MAX_READ_BYTES
) -> Optional[str]:
    try:
        size = path.stat().st_size
        if size > max_bytes:
            return None
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None


def _scan_pw_out_force(path: Path) -> Optional[float]:
    """Cherche la dernière ligne `Total force = X Ry / bohr` dans un .out pw.x."""
    text = _read_text_bounded(path, max_bytes=2_000_000)
    if text is None:
        return None
    # Variantes QE observées : "Total force = 0.000123 Ry / bohr"
    # (insensible à la casse et à l'espacement).
    rx = re.compile(
        r"Total\s+force\s*=\s*([0-9.+-EeDd]+)\s*Ry\s*/\s*bohr",
        re.IGNORECASE,
    )
    matches = list(rx.finditer(text))
    if not matches:
        return None
    try:
        return float(matches[-1].group(1).replace("D", "E").replace("d", "e"))
    except ValueError:
        return None


def _scan_pw_out_force_in_workdir(work_dir: Path) -> Optional[tuple]:
    """Scan rapide de quelques sorties pw.x usuelles dans le work_dir."""
    candidates = [
        work_dir / "pw_scf_V0_for_phonon.in.out",
        work_dir / "scf.in.out",
        work_dir / "scf_eq.in.out",
        work_dir / "1_eos_volumes" / "scf_eq.out",
        work_dir / "1_eos_volumes" / "pw_scf_V0_for_phonon.out",
        work_dir / "out_pw_scf_V0.out",
    ]
    # On complète avec quelques .out triés par mtime desc.
    try:
        candidates.extend(sorted(work_dir.glob("*.out"), reverse=True)[:6])
    except OSError:
        pass
    for p in candidates:
        if not p.is_file():
            continue
        v = _scan_pw_out_force(p)
        if v is not None:
            return (v, p.name)
    return None


def _parse_phonon_freq_min_thz(work_dir: Path) -> Optional[tuple]:
    """Renvoie (min_freq_THz, label) ou None si `phonon.freq` introuvable."""
    p = work_dir / "phonon.freq"
    if not p.is_file():
        return None
    text = _read_text_bounded(p, max_bytes=2_000_000)
    if text is None:
        return None
    rx = re.compile(
        r"omega\s*\(\s*\d+\s*\)\s*=\s*([+-]?[0-9.EeDd]+)\s*THz",
        re.IGNORECASE,
    )
    vals: list[float] = []
    for m in rx.finditer(text):
        try:
            vals.append(float(m.group(1).replace("D", "E").replace("d", "e")))
        except ValueError:
            continue
    if not vals:
        return None
    return (float(min(vals)), "phonon.freq omega(i) [THz]")


# ============================================================
# Sous-checks individuels (best-effort, ne lèvent jamais).
# ============================================================


def _check_phonon_imaginary(work_dir: Path, profile_id: str) -> Dict[str, Any]:
    base: Dict[str, Any] = {
        "id": "phonon_imaginary",
        "level": "unknown",
        "title": "Fréquences phononiques",
        "icon": "\U0001F30A",  # 🌊
        "source": None,
        "value": None,
        "message": None,
    }
    # Juillet 2026 : tous les profils (P1-P5) exécutent la chaîne phonon
    # (needs_phonons=True). Le check de stabilité dynamique s'applique à tous.
    scan = _parse_phonon_freq_min_thz(work_dir)
    if scan is None:
        return {
            **base,
            "message": (
                "phonon.freq introuvable ou non parsable. "
                "Lancez ph.x + matdyn.x ou consultez les logs."
            ),
        }
    minf, src = scan
    base["source"] = src
    base["value"] = round(minf, 3)
    if minf <= THRESH_PHONON_ERROR_THz:
        return {
            **base,
            "level": "error",
            "message": (
                f"Instabilité dynamique : fréquence minimale = {minf:+.3f} THz "
                f"(seuil erreur <= {THRESH_PHONON_ERROR_THz} THz). "
                "La structure relaxera spontanément — relancer avec maille "
                "ou positions modifiées."
            ),
        }
    if minf <= THRESH_PHONON_WARN_THz:
        return {
            **base,
            "level": "warn",
            "message": (
                f"Fréquence négative faible : {minf:+.3f} THz "
                f"(seuil warning <= {THRESH_PHONON_WARN_THz} THz). "
                "Probable artefact ASR ou bruit de discrétisation — vérifier "
                "près de Γ."
            ),
        }
    return {
        **base,
        "level": "ok",
        "message": (
            f"Toutes les fréquences >= {minf:+.3f} THz (stabilité dynamique OK)."
        ),
    }


def _check_born_stability(j_results: Dict[str, Any]) -> Dict[str, Any]:
    base: Dict[str, Any] = {
        "id": "born_stability",
        "level": "unknown",
        "title": "Stabilité mécanique (Born)",
        "icon": "\U0001F9F1",  # 🧱
        "source": None,
        "value": None,
        "message": None,
    }
    elastic = j_results.get("elastic") or {}
    cub = elastic.get("elastic_cubic_independent_GPa") if isinstance(elastic, dict) else None
    if not isinstance(cub, dict):
        return {
            **base,
            "message": (
                "Constantes cubiques C₁₁/C₁₂/C₄₄ non disponibles — "
                "vérifier le run (P1 ou maille cubique requise)."
            ),
        }
    try:
        c11 = float(cub.get("C11_GPa"))
        c12 = float(cub.get("C12_GPa"))
        c44 = float(cub.get("C44_GPa"))
    except (TypeError, ValueError):
        return {**base, "message": "C₁₁/C₁₂/C₄₄ présents mais types invalides."}
    base["source"] = "elastic.elastic_cubic_independent_GPa"
    base["value"] = {"C11_GPa": c11, "C12_GPa": c12, "C44_GPa": c44}
    pair_names = {
        "C₁₁−C₁₂ > 0": c11 - c12,
        "C₁₁+2C₁₂ > 0": c11 + 2.0 * c12,
        "C₄₄ > 0": c44,
    }
    violated = [k for k, v in pair_names.items() if v <= 0.0]
    if violated:
        return {
            **base,
            "level": "error",
            "message": (
                "Critères de Born violés : " + ", ".join(violated) + ". "
                "Le cristal est mécaniquement instable dans cette approximation."
            ),
        }
    margins = [abs(v) for _, v in pair_names.items()]
    min_margin = float(min(margins))
    if min_margin <= BORN_MARGIN_WARN_GPa:
        return {
            **base,
            "level": "warn",
            "message": (
                f"Critères de Born respectés mais marge min = {min_margin:.2f} GPa "
                f"(seuil warning {BORN_MARGIN_WARN_GPa} GPa). "
                "Proche de l'instabilité — vérifier convergence et pb parameters."
            ),
        }
    return {
        **base,
        "level": "ok",
        "message": (
            f"Critères de Born OK — marge min = {min_margin:.2f} GPa, "
            "structure mécaniquement stable."
        ),
    }


def _check_poisson(j_results: Dict[str, Any]) -> Dict[str, Any]:
    base: Dict[str, Any] = {
        "id": "poisson_ratio",
        "level": "unknown",
        "title": "Ratio de Poisson",
        "icon": "\U0001F4CF",  # 📏
        "source": None,
        "value": None,
        "message": None,
    }
    elastic = j_results.get("elastic") or {}
    nu_raw = elastic.get("poisson_ratio") if isinstance(elastic, dict) else None
    if nu_raw is None:
        return {
            **base,
            "message": (
                "Coefficient de Poisson absent (run non-P1/P3 ou C_ij insuffisants)."
            ),
        }
    try:
        nu = float(nu_raw)
    except (TypeError, ValueError):
        return {**base, "message": f"Valeur Poisson non numérique : {nu_raw!r}"}
    base["source"] = "elastic.poisson_ratio"
    base["value"] = round(nu, 4)
    if nu < -1.0 or nu > 0.5:
        return {
            **base,
            "level": "error",
            "message": (
                f"ν = {nu:.3f} hors des bornes thermodynamiques [-1, 0.5]. "
                "Probablement artefact de fit C_ij."
            ),
        }
    if nu < POISSON_OK_MIN or nu > POISSON_OK_MAX:
        return {
            **base,
            "level": "warn",
            "message": (
                f"ν = {nu:.3f} hors de la plage typique [{POISSON_OK_MIN:.2f}, "
                f"{POISSON_OK_MAX:.2f}] (matériau auxétique ou quasi-liquide — vérifier)."
            ),
        }
    return {
        **base,
        "level": "ok",
        "message": f"ν = {nu:.3f} dans la plage normale pour un solide.",
    }


def _check_bprime(j_results: Dict[str, Any]) -> Dict[str, Any]:
    base: Dict[str, Any] = {
        "id": "eos_bprime",
        "level": "unknown",
        "title": "Fit EOS (B')",
        "icon": "\U0001F4C8",  # 📈
        "source": None,
        "value": None,
        "message": None,
    }
    elastic = j_results.get("elastic") or {}
    eos = j_results.get("eos") or {}
    raw = None
    sources = []
    if isinstance(elastic, dict) and elastic.get("bulk_modulus_pressure_derivative") is not None:
        raw = elastic.get("bulk_modulus_pressure_derivative")
        sources.append("elastic.bulk_modulus_pressure_derivative")
    if raw is None and isinstance(eos, dict) and eos.get("B0prime") is not None:
        raw = eos.get("B0prime")
        sources.append("eos.B0prime")
    if raw is None:
        return {
            **base,
            "message": "B' absent (run sans EOS ou fit non convergé).",
        }
    try:
        bp = float(raw)
    except (TypeError, ValueError):
        return {**base, "message": f"B' non numérique : {raw!r}"}
    base["source"] = " / ".join(sources)
    base["value"] = round(bp, 3)
    if bp < BPRIME_WARN_MIN or bp > BPRIME_WARN_MAX:
        return {
            **base,
            "level": "error",
            "message": (
                f"B' = {bp:.2f} hors [{BPRIME_WARN_MIN}, {BPRIME_WARN_MAX}]. "
                "Le fit Birch-Murnaghan a probablement divergé — élargir la "
                "grille de volumes (±3% → ±5%) et relancer."
            ),
        }
    if bp < BPRIME_OK_MIN or bp > BPRIME_OK_MAX:
        return {
            **base,
            "level": "warn",
            "message": (
                f"B' = {bp:.2f} hors de la plage typique [{BPRIME_OK_MIN}, "
                f"{BPRIME_OK_MAX}]. Valeur inhabituelle — vérifier ancrage "
                "de la grille EOS et convergence SCF aux volumes extrêmes."
            ),
        }
    return {
        **base,
        "level": "ok",
        "message": (
            f"B' = {bp:.2f} dans la plage typique [{BPRIME_OK_MIN}, {BPRIME_OK_MAX}]."
        ),
    }


def _check_force_residual(work_dir: Path) -> Dict[str, Any]:
    base: Dict[str, Any] = {
        "id": "force_residual",
        "level": "unknown",
        "title": "Forces résiduelles SCF",
        "icon": "\u2696\ufe0f",  # ⚖️
        "source": None,
        "value": None,
        "message": None,
    }
    scan = _scan_pw_out_force_in_workdir(work_dir)
    if scan is None:
        return {
            **base,
            "message": "Aucun journal pw.x avec `Total force` trouvé dans work_dir.",
        }
    val, src = scan
    base["source"] = src
    base["value"] = val
    if val > FORCE_WARN_RY:
        return {
            **base,
            "level": "error",
            "message": (
                f"|F|max = {val:.2e} Ry/bohr > {FORCE_WARN_RY:.1e}. "
                "La structure d'équilibre n'est PAS minimisée — "
                "phonons et C_ij seront biaisés. Réduire conv_thr."
            ),
        }
    if val > FORCE_OK_RY:
        return {
            **base,
            "level": "warn",
            "message": (
                f"|F|max = {val:.2e} Ry/bohr > {FORCE_OK_RY:.1e}. "
                "Convergence SCF relâchée — pour phonon de précision : "
                "abaisser conv_thr (1e-8 Ry)."
            ),
        }
    return {
        **base,
        "level": "ok",
        "message": (
            f"|F|max = {val:.2e} Ry/bohr sous le seuil DFT standard "
            f"({FORCE_OK_RY:.1e})."
        ),
    }


# ============================================================
# Orchestration — best-effort, jamais d'exception.
# ============================================================

_CHECK_ORDER = (
    "phonon_imaginary",
    "born_stability",
    "poisson_ratio",
    "eos_bprime",
    "force_residual",
)


def compute_sanity(
    work_dir: Path,
    j_results: Dict[str, Any],
    *,
    profile_id: str = "",
) -> Dict[str, Any]:
    """
    Calcule tous les checks en best-effort et renvoie :
      {
        "summary": {n_error, n_warn, n_ok, n_unknown, score_text},
        "checks": [ ... ordered ... ],
      }
    Aucun check ne lève.
    """
    runners: tuple = (
        ("phonon_imaginary", lambda: _check_phonon_imaginary(work_dir, profile_id)),
        ("born_stability",   lambda: _check_born_stability(j_results or {})),
        ("poisson_ratio",    lambda: _check_poisson(j_results or {})),
        ("eos_bprime",       lambda: _check_bprime(j_results or {})),
        ("force_residual",   lambda: _check_force_residual(work_dir)),
    )
    raw: Dict[str, Dict[str, Any]] = {}
    for cid, runner in runners:
        try:
            raw[cid] = runner()
        except Exception as ex:  # noqa: BLE001
            raw[cid] = {
                "id": cid,
                "level": "unknown",
                "title": cid,
                "icon": "\u2753",  # ❓
                "source": None,
                "value": None,
                "message": f"Erreur interne du check : {ex}",
            }
    ordered = [raw[cid] for cid in _CHECK_ORDER if cid in raw]
    summary: Dict[str, Any] = {
        "n_error": 0,
        "n_warn": 0,
        "n_ok": 0,
        "n_unknown": 0,
    }
    for c in ordered:
        lv = c.get("level") or "unknown"
        key = f"n_{lv}"
        summary[key] = summary.get(key, 0) + 1
    ran = summary["n_error"] + summary["n_warn"] + summary["n_ok"]
    summary["score_text"] = (
        f"{summary['n_ok']}/{ran} valid\u00e9s"
        if ran
        else "aucun check applicable"
    )
    return {"summary": summary, "checks": ordered}

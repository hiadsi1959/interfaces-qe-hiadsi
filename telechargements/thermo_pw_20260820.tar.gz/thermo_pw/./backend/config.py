"""
Chemins par défaut (même logique que interface/thermo_config.js).
Remplir via variables d'environnement pour un autre poste.

Mode PyInstaller (exécutable) : si THERMO_REPO_ROOT n'est pas défini, on utilise
le dossier « bundle/ » à côté de l'exécutable ou sous sys._MEIPASS (fichiers
données empaquetés).
"""
import os
import sys
from pathlib import Path


def _default_thermo_repo_root() -> Path:
    raw = os.environ.get("THERMO_REPO_ROOT")
    if raw:
        return Path(raw).expanduser().resolve()
    if getattr(sys, "frozen", False):
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            b = Path(meipass) / "bundle"
            if b.is_dir():
                return b.resolve()
        exedir = Path(sys.executable).resolve().parent
        b2 = exedir / "bundle"
        if b2.is_dir():
            return b2.resolve()
    return Path(__file__).resolve().parent.parent


# Racine du dépôt thermo_pw (parent de backend/ et interface/) — ou bundle PyInstaller
THERMO_REPO_ROOT = _default_thermo_repo_root()

# Entrées par matériau : thermo_pw/inputs/<Materiau>/*.in
INPUTS_DIR = Path(os.environ.get("THERMO_INPUTS_DIR", str(THERMO_REPO_ROOT / "inputs")))

# Sorties Quantum ESPRESSO (outdir dans les .in) — tout reste sous thermo_pw
OUTPUTS_DIR = Path(os.environ.get("THERMO_OUTPUTS_DIR", str(THERMO_REPO_ROOT / "outputs")))

# Pseudopotentiels (pseudo_dir dans les .in), ex. PBE de la PSlibrary
PSEUDOS_DIR = Path(os.environ.get("THERMO_PSEUDOS_DIR", str(THERMO_REPO_ROOT / "pseudos" / "PBE")))

# Installation « générateur de pseudos » (APE/ATOMPAW, pseudo_auto_inputs.py, templates/) — indépendante de THERMO_PSEUDOS_DIR.
GENERATION_PSEUDOS_DIR = Path(
    os.environ.get("THERMO_GENERATION_PSEUDOS_DIR", str(Path.home() / "generation_pseudos"))
).expanduser().resolve()

# Répertoire où copier les .UPF après un run réussi (par défaut : sous le générateur, pas la biblio QE).
_pgo = os.environ.get("THERMO_PSEUDO_GEN_OUTPUT_DIR", "").strip()
PSEUDO_GEN_OUTPUT_DIR = (
    Path(_pgo).expanduser().resolve()
    if _pgo
    else (GENERATION_PSEUDOS_DIR / "generated_upf").resolve()
)

# Répertoire de travail temporaire des runs APE/ATOMPAW (par défaut : sous le générateur).
_pgw = os.environ.get("THERMO_PSEUDO_GEN_WORK_ROOT", "").strip()
PSEUDO_GEN_WORK_ROOT = (
    Path(_pgw).expanduser().resolve()
    if _pgw
    else (GENERATION_PSEUDOS_DIR / "_work").resolve()
)

# Racine des calculs (workflows EOS, etc.)
WORK_ROOT = Path(os.environ.get("THERMO_WORK_ROOT", str(THERMO_REPO_ROOT / "work")))

# Binaires Quantum ESPRESSO (override : THERMO_QE_BIN)
_QE_BIN_DEFAULT = Path.home() / "q-e-qe-7.5" / "bin"
QE_BIN = Path(os.environ.get("THERMO_QE_BIN", str(_QE_BIN_DEFAULT)))

# Parallélisation pw.x
MPI_NPROC = int(os.environ.get("THERMO_MPI_NPROC", "4"))

# Juillet 2026 — plafonnement mémoire subprocess MPI (cf. ``qe_subprocess._try_set_mem_rlimit``).
# Empêche ``thermo_pw.x`` / ``matdyn.x`` de pousser l'OS à OOM-kill toute l'API (qui perd
# alors son registre in-memory → "Job perdu" côté UI). POSIX only (``preexec_fn``).
# Défaut 8 GiB — couvre P1..P5 sans thrashing sur les cas courants ; pour les mailles
# très grosses on peut passer ``THERMO_MPI_RLIMIT_AS_BYTES=0`` (désactivé — pas de plafonnement).
MPI_RLIMIT_AS_BYTES = int(os.environ.get("THERMO_MPI_RLIMIT_AS_BYTES", str(8 * 1024 * 1024 * 1024)))

# Binaire gnuplot (requis pour tous les tracés serveur : E(V), phonons, etc.)
# Priorité : THERMO_GNUPLOT, puis GNUPLOT, puis PATH, puis emplacements usuels


def pw_path() -> Path:
    return QE_BIN / "pw.x"


def ph_path() -> Path:
    return QE_BIN / "ph.x"


def q2r_path() -> Path:
    return QE_BIN / "q2r.x"


def matdyn_path() -> Path:
    return QE_BIN / "matdyn.x"


def thermo_pw_path() -> Path:
    return QE_BIN / "thermo_pw.x"


def dynmat_path() -> Path:
    return QE_BIN / "dynmat.x"


def bands_path() -> Path:
    """``bands.x`` (post-traitement QE — bandes électroniques le long d'un chemin q)."""
    return Path(os.environ.get("THERMO_BANDS", str(QE_BIN / "bands.x")))


def dos_path() -> Path:
    """``dos.x`` (post-traitement QE — densité d'états depuis NSCF)."""
    return Path(os.environ.get("THERMO_DOS", str(QE_BIN / "dos.x")))


def pp_path() -> Path:
    """Post-traitement charge / potentiel (pp.x)."""
    return Path(os.environ.get("THERMO_PP", str(QE_BIN / "pp.x")))


def turbo_lanczos_path() -> Path:
    """TDDFT turbo Lanczos (Quantum ESPRESSO turbo / tddfpt)."""
    return Path(os.environ.get("THERMO_TURBO_LANCZOS", str(QE_BIN / "turbo_lanczos.x")))


def turbo_davidson_path() -> Path:
    return Path(os.environ.get("THERMO_TURBO_DAVIDSON", str(QE_BIN / "turbo_davidson.x")))


def epsilon_path() -> Path:
    """Post-traitement diélectrique (epsilon.x)."""
    return Path(os.environ.get("THERMO_EPSILON", str(QE_BIN / "epsilon.x")))


def eos_template_allowed_roots() -> list[Path]:
    """Racines autorisées pour le fichier .in modèle (EOS) — + THERMO_EOS_ALLOW_PREFIXES (séparateur :)."""
    roots: list[Path] = [
        WORK_ROOT.resolve(),
        INPUTS_DIR.resolve(),
        OUTPUTS_DIR.resolve(),
        (THERMO_REPO_ROOT / "pseudos").resolve(),
        (THERMO_REPO_ROOT / "templates").resolve(),
    ]
    if "THERMO_EOS_ALLOW_PREFIXES" in os.environ:
        extra = os.environ.get("THERMO_EOS_ALLOW_PREFIXES", "")
    else:
        extra = ""
    for part in extra.split(os.pathsep if os.name != "nt" else ";"):
        p = part.strip()
        if p:
            r = Path(p).expanduser().resolve()
            if r not in roots:
                roots.append(r)
    return roots


def is_path_under_allowed_template(path: Path) -> bool:
    p = path.expanduser().resolve()
    for root in eos_template_allowed_roots():
        try:
            p.relative_to(root)
            return True
        except ValueError:
            continue
    return False


# Redémarrage à distance : POST /api/admin/restart (corps JSON {"token":"…"} si THERMO_API_RESTART_TOKEN est défini).
# Optionnel : THERMO_API_RESTART_SCRIPT = script exécutable qui reçoit THERMO_API_PID_TO_STOP dans l’environnement.
THERMO_API_RESTART_TOKEN = (os.environ.get("THERMO_API_RESTART_TOKEN") or "").strip()
THERMO_API_RESTART_SCRIPT = (os.environ.get("THERMO_API_RESTART_SCRIPT") or "").strip()


# ----------------------------------------------------------------------------
# Juin 2026 — échelle libfabric / OFI fallback (cf. dos.x OFI bug fix)
# ----------------------------------------------------------------------------
# Sur certains nœuds, ``dos.x`` (et autres binaires QE lancés via
# ``run_qe_stdin``) plante à MPI_Init avec ::
#     OFI fi_getinfo() failed (ofi_init.c:3004:find_provider:No data available)
# → ``SIGSEGV`` code 174. Pour contourner sans recompilation, on force un
# provider libfabric stable (``tcp`` par défaut — porté sur quasi tous les
# nœuds HPC) via le wrapper ``qe_subprocess._apply_fi_provider_default``.
#
# Hiérarchie d’override (fort → faible) :
#   1. ``FI_PROVIDER`` directement dans l’env d’appel  — priorété (expert).
#   2. ``THERMO_FI_PROVIDER`` dans l’env              — fallback admin (centre).
#   3. ``FI_PROVIDER_DEFAULT = “tcp”`` ci-dessous    — défaut raisonnable.
#
# Pour passer à un autre provider (nœud sans tcp, ou inventions hardware) :
#   * export THERMO_FI_PROVIDER=ofi_rxm && re-run         # persistent admin
#   * export FI_PROVIDER=verbs && run_electronic_properties    # one-shot expert
# Ne PAS céder à l’override direct de ``FI_PROVIDER_DEFAULT`` — cette
# variable est figée par défaut à « tcp » parce que c’est le plus
# portable. L’évolution (``ofi_rxm``, ``verbs``, ``sockets``) doit passer
# par l’admin THERMO_FI_PROVIDER ou l’expert FI_PROVIDER.
# =====================================================================
FI_PROVIDER_DEFAULT = os.environ.get("THERMO_FI_PROVIDER", "tcp")

# Juillet 2026 — patch q2r.x / matdyn.x : bypasser complètement la couche
# OFI/libfabric en forçant le transport Intel MPI shared-memory (zéro réseau).
# Cf. ``qe_subprocess._apply_fi_provider_default`` qui injecte cette clé dans
# l'env de chaque ``run_qe_stdin``. Override admin : ``THERMO_I_MPI_FABRICS``.
# Ordre d'override (fort → faible) :
#   1. ``I_MPI_FABRICS`` shell (expert)        — priorité absolue, jamais écrasé.
#   2. ``THERMO_I_MPI_FABRICS`` env (admin)    — centre de calcul.
#   3. ``I_MPI_FABRICS_DEFAULT = "shm"``       — défaut fallback sûr (local).
# ``shm`` est toujours disponible (sm POSIX), contrairement aux providers OFI
# qui dépendent du matériel réseau (psm2/mlx/verbs). Survient à un crash
# ``OFI fi_getinfo() failed`` en ``MPI_Init`` typique d'Intel MPI 2021.x.
I_MPI_FABRICS_DEFAULT = os.environ.get("THERMO_I_MPI_FABRICS", "shm")

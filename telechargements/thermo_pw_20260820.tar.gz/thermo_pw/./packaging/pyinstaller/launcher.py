#!/usr/bin/env python3
"""
Point d'entrée pour le paquet PyInstaller (thermo_pw interface + API).
Ne pas importer api_server avant d'avoir défini THERMO_REPO_ROOT en mode frozen.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path


def _ensure_bundle_dirs(repo: Path) -> None:
    for sub in (
        "work",
        "outputs",
        "pseudos/PBE",
    ):
        (repo / sub).mkdir(parents=True, exist_ok=True)


def main() -> None:
    if getattr(sys, "frozen", False):
        base = Path(getattr(sys, "_MEIPASS", Path(sys.executable).resolve().parent))
        bundle = base / "bundle"
        os.environ.setdefault("THERMO_REPO_ROOT", str(bundle.resolve()))
    else:
        # Développement : lancer depuis le dépôt — python packaging/pyinstaller/launcher.py
        repo = Path(__file__).resolve().parent.parent.parent
        sys.path.insert(0, str(repo / "backend"))
        os.environ.setdefault("THERMO_REPO_ROOT", str(repo))

    repo = Path(os.environ["THERMO_REPO_ROOT"]).expanduser().resolve()
    _ensure_bundle_dirs(repo)

    import api_server  # noqa: E402

    api_server.main()


if __name__ == "__main__":
    main()

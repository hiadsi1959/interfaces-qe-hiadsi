# -*- mode: python ; coding: utf-8 -*-
# Build (Linux) depuis la racine du dépôt thermo_pw :
#   pip install pyinstaller
#   pyinstaller packaging/pyinstaller/thermo_pw_desktop.spec
#
# Sortie : dist/thermo_pw_desktop/thermo_pw_desktop (+ dossier bundle/)

import sys
from pathlib import Path

try:
    from PyInstaller.utils.hooks import collect_data_files, collect_submodules
except ImportError as e:
    raise SystemExit("Installez PyInstaller : pip install pyinstaller") from e

# SPECPATH (PyInstaller) = dossier qui contient le fichier .spec
SPEC_ROOT = Path(SPECPATH).resolve()
REPO = SPEC_ROOT.parent.parent
BACKEND = (REPO / "backend").resolve()
LAUNCHER = (SPEC_ROOT / "launcher.py").resolve()

if not LAUNCHER.is_file():
    raise SystemExit(f"launcher introuvable : {LAUNCHER}")

datas = [
    (str(REPO / "interface"), "bundle/interface"),
    (str(REPO / "templates"), "bundle/templates"),
    (str(REPO / "inputs"), "bundle/inputs"),
]
datas += collect_data_files("matplotlib")
try:
    datas += collect_data_files("ase")
except Exception:
    pass

hiddenimports = list(collect_submodules("parsers"))
# Imports dynamiques ou secondaires souvent oubliés
hiddenimports += [
    "cif_to_pw",
    "optics_inputs_check",
    "material_inputs",
    "input_editor",
    "api_job_persist",
    "state_db",
    "eos_paths",
    "phonon_chain_qe",
    "ph_input_from_pw",
    "qe_subprocess",
    "qha_prereq_check",
    "work_thermo",
    "work_optimize_eos",
    "work_phonon",
    "work_elastic",
    "eos_gnuplot",
    "phonon_gnuplot",
    "material_workspace",
    "run_workflow",
    "orchestrator",
    "input_scaling",
    "fit_eos",
]

a = Analysis(
    [str(LAUNCHER)],
    pathex=[str(BACKEND)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["tkinter", "test", "tests"],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="thermo_pw_desktop",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="thermo_pw_desktop",
)

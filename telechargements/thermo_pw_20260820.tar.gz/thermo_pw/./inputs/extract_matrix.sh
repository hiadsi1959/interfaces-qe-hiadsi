#!/usr/bin/env bash
# extract_matrix.sh — extracteur de la matrice C_ij depuis une sortie thermo_pw.
#
# ⚠ MISE À JOUR JUIN 2026 — refonte des 5 profils thermo_pw.
#
# Ce script shell reste utile **uniquement** pour les profils P1 / P3 qui
# écrivent une matrice d'élasticité 6×6 (kbar ou GPa) dans la sortie
# thermo_pw_run.out ("TOTAL-ELASTIC-CONSTANTS").
#
# Pour les autres profils, **ne pas utiliser ce script** :
#   • P2  (what='mur_lc_t' QHA — legacy UI/API 'thermo' réécrit par l'API en canonique 7.x)
#                                  → pas de matrice 6×6 (QHA EOS + Debye/ZPE).
#   • P4  (what='ph_life' — legacy UI/API 'qha_lif' réécrit par l'API en canonique 7.x)
#                              → pas de matrice 6×6 (γ(μω), τ(μω), κ_lattice(T)).
#   • P5  (what='dielectric') → tenseur 3×3 ε∞ + charges de Born.
#
# Pour P4 et P5, utilisez les parseurs Python dédiés :
#   * ``backend/parsers/phonon_lifetime.py`` → ``parse_phonon_lifetime(work_dir)``
#     → dict {mean_lifetime_ps, mean_linewidth_cm-1, lattice_kappa_W_mK,
#             gruneisen_mean, modes[], …}.
#   * ``backend/parsers/dielectric.py``     → ``parse_dielectric(work_dir)``
#     → dict {epsilon_xx/yy/zz, epsilon_average, born_Z_star_max_abs,
#             refractive_index_avg, born_Z_star_per_atom[], …}.
#
# L'API Python ``PipelineJob._intermediate_parse`` appelle ces parseurs
# automatiquement à chaque étape du pipeline (EOS, ph, thermo_pw, post).
#
# Le script ci-dessous conserve donc un extracteur 6×6 best-effort pour
# préserver les workflows legacy (scientifiques qui appellent ce script
# hors pipeline). Il NE fait plus la même chose qu'avant pour P4 / P5.

import re

def extract_matrix_from_out(out_file):
    """Cherche la matrice 6x6 dans le fichier de sortie thermo_pw_run.out.

    **Portée limitée aux profils P1 / P3** (what='scf_elastic_constants'/'elastic_constants_geo' ; legacy alias 'elastic' réécrit par l'API en canonique 7.x). Pour P4 et P5,
    se reporter aux parseurs Python dédiés mentionnés ci-dessus.
    """
    try:
        with open(out_file, 'r') as f:
            lines = f.readlines()

        for i, line in enumerate(lines):
            if "TOTAL-ELASTIC-CONSTANTS (kbar)" in line:
                # On récupère les 6 lignes suivantes
                matrix_lines = lines[i+1:i+7]
                matrix_data = " ".join(matrix_lines)
                # On sauvegarde dans un fichier temporaire pour votre fonction actuelle
                with open("temp_matrix.dat", "w") as tmp:
                    tmp.write(matrix_data)
                return "temp_matrix.dat"
    except Exception as e:
        print(f"Erreur lors de l'extraction : {e}")
    return None

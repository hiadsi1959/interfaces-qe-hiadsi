Entrées par matériau (même logique que Interface-QE_v1/inputs)
================================================================

Placez chaque matériau dans un sous-dossier, par exemple :

  inputs/
    Si/
      si_scf.in          ← diamant (primitive, 2 atomes) — SCF exemple
    ZnO/
      zno_scf.in

L’interface THERMO_PW liste ces dossiers et propose les fichiers .in
(le fichier par défaut privilégie *scf*, *relax*, *vc-relax* dans le nom).

Si un dossier existe déjà sous thermo_pw/inputs, la même entrée provenant
de l’interface principale n’est pas dupliquée dans le menu.

Chemins portables (nouveau PC / autre utilisateur)
--------------------------------------------------
Les gabarits sous inputs/*/ utilisent des chemins relatifs au dépôt thermo_pw
(ex. pseudo_dir = ./pseudos/PBE/). En enregistrant depuis l’interface, les
chemins absolus corrects sont réécrits selon backend/config.py.

Variables d’environnement utiles : voir env/portable_paths.example.sh
(copie en env/local.sh ; chargée par ./DEMARRER.sh).

Dépannage workflow EOS (pw.x code retour 1)
--------------------------------------------
- Vérifiez que pseudo_dir et le pseudo .UPF (ex. Si.pbe-n-kjpaw) existent ; adaptez
  pseudo_dir dans le .in si besoin.
- outdir = ./out/ (exemple) est créé dans le dossier du calcul.
- Sachez lancer en séquentiel : 1 seul cœur MPI (dans l’interface, « MPI par pw.x »
  = 1) si mpirun -np 4 échoue (pas de OpenMPI, ou sur-abonnement des slots).
- Le message d’erreur côté interface ou dans thermo_pw/work/.../1_eos_volumes/ inclut
  la fin du journal scf_vol_XX.out (cause réelle d’échec de Quantum ESPRESSO).

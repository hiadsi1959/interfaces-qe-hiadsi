import numpy as np
import sys

def calculate_mechanics_kbar(file_path):
    # Facteur de conversion : 10 kbar = 1 GPa
    KBAR_TO_GPA = 0.1

    try:
        with open(file_path, 'r') as f:
            # Remplacement de 'D' par 'E' pour les formats Fortran (ex: 1.23D+02 -> 1.23E+02)
            content = f.read().replace('D', 'E')
            words = content.split()
            
            # Extraction des nombres uniquement
            nums = []
            for w in words:
                try:
                    nums.append(float(w))
                except ValueError:
                    continue
        
        # Vérification qu'on a bien les 36 éléments d'une matrice 6x6
        if len(nums) < 36:
            print(f"Erreur : Données insuffisantes. Trouvé {len(nums)} valeurs, attendu 36.")
            print("Assurez-vous que le fichier contient bien les 6x6 valeurs de la matrice Cij.")
            return

        # Reconstruction de la matrice et conversion en GPa
        cij_raw = np.array(nums[:36]).reshape(6, 6)
        cij = cij_raw * KBAR_TO_GPA
        
        # Extraction des constantes pour le système cubique
        c11, c12, c44 = cij[0,0], cij[0,1], cij[3,3]

        print(f"\n" + "="*55)
        print(f" ANALYSE MÉCANIQUE (Conversion : kbar -> GPa)")
        print("="*55)
        print(f"Valeurs Cij (en GPa) :")
        print(f"C11 = {c11:.4f} | C12 = {c12:.4f} | C44 = {c44:.4f}")
        print("-" * 55)
        
        # 1. Conditions de stabilité de Born (Structure Cubique)
        cond1 = (c11 - c12) > 0
        cond2 = (c11 + 2*c12) > 0
        cond3 = c44 > 0
        is_stable = cond1 and cond2 and cond3
        
        print(f"--- Stabilité de Born (Cubique) ---")
        print(f"C11 - C12 > 0    : {'OUI' if cond1 else 'NON'} ({c11-c12:.4f} GPa)")
        print(f"C11 + 2*C12 > 0  : {'OUI' if cond2 else 'NON'} ({c11+2*c12:.4f} GPa)")
        print(f"C44 > 0          : {'OUI' if cond3 else 'NON'} ({c44:.4f} GPa)")
        print(f"RÉSULTAT         : {'STABLE' if is_stable else 'INSTABLE'}")
        print("-" * 55)

        # 2. Propriétés Polycristallines (Moyenne de Hill)
        B = (c11 + 2*c12) / 3
        
        G_Voigt = (c11 - c12 + 3*c44) / 5
        try:
            G_Reuss = (5 * c44 * (c11 - c12)) / (4 * c44 + 3 * (c11 - c12))
        except ZeroDivisionError:
            G_Reuss = 0
            
        G = (G_Voigt + G_Reuss) / 2
        
        E = (9 * B * G) / (3 * B + G) if (3 * B + G) != 0 else 0
        nu = (3 * B - 2 * G) / (2 * (3 * B + G)) if (3 * B + G) != 0 else 0
        
        # Rapport de Pugh et Anisotropie
        pugh = B / G if G != 0 else 0
        A = (2 * c44) / (c11 - c12) if (c11 - c12) != 0 else 0

        print(f"--- Modules Élastiques (en GPa) ---")
        print(f"Module de Bulk (B)       : {B:10.4f}")
        print(f"Module de Young (E)      : {E:10.4f}")
        print(f"Module de Cisaillement(G): {G:10.4f}")
        print(f"Coefficient de Poisson(v): {nu:10.4f}")
        print(f"Rapport B/G (Pugh)       : {pugh:10.4f} ({'Ductile' if pugh > 1.75 else 'Fragile'})")
        print(f"Anisotropie (Zener)      : {A:10.4f}")
        print("="*55)

    except Exception as e:
        print(f"Erreur : {e}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 mechanical_properties_kbar.py resultat.dat")
    else:
        calculate_mechanics_kbar(sys.argv[1])

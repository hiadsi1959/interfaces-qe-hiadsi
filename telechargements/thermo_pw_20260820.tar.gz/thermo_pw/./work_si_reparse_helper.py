#!/usr/bin/env python3
"""Réparation hors-ligne des marqueurs ``pipeline_api_job_state.json`` existants :

1. Pour les jobs ``done`` : re-parse ``thermo_pw_run.out`` + fichiers
   ``output_el_cons*.dat*`` et repopule ``results.elastic.C{11,12,44}_GPa``
   (ainsi que B/G/E/ν) avec les règles du merger corrigé.
2. Pour les jobs ``running``/``queued`` (zombies) : statut → ``interrupted``,
   finished_at = maintenant UTC, message explicite + ligne de journal.
3. Ne touche PAS aux jobs ``error`` (les erreurs restent erreurs).

Idempotent : relancer ne change rien après une première passe réussie.
Écrit les markers ``pipeline_api_job_state.json`` sur disque atomiquement
(écrasement in-place simple ici, suffira car on ne lit pas en concurrence).

Usage : ``python3 work_si_reparse_helper.py [WORK_ROOT]``
        WORK_ROOT par défaut : ``./work``.
"""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

REPO = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO / "backend"))

WORK_ROOT = (
    Path(sys.argv[1]).resolve()
    if len(sys.argv) > 1
    else (REPO / "work").resolve()
)

from parsers.thermo_pw_out_parse import (  # noqa: E402
    parse_thermo_pw_log,
    merge_elastic_from_output_el_cons_files,
)


def _merge_into_results(results: dict, parsed: dict) -> bool:
    """Reprend la logique de PipelineJob._merge_parsed_into_results.
    Renvoie True si quelque chose a changé.
    """
    changed = False
    es = results.setdefault("elastic", {})
    cub = parsed.get("elastic_cubic_independent_GPa")
    if isinstance(cub, dict):
        for k in ("C11_GPa", "C12_GPa", "C44_GPa"):
            v = cub.get(k)
            if v is not None and es.get(k) is None:
                es[k] = float(v)
                changed = True
    indep = parsed.get("elastic_independent_GPa")
    if isinstance(indep, dict):
        consts = indep.get("constants_Gpa") or {}
        if isinstance(consts, dict):
            for k in ("C11_GPa", "C12_GPa", "C44_GPa"):
                v = consts.get(k)
                if v is not None and es.get(k) is None:
                    es[k] = float(v)
                    changed = True
    rows = parsed.get("elastic_constants_GPa") or []
    if isinstance(rows, list) and rows:
        for row in rows:
            if not isinstance(row, dict):
                continue
            try:
                i, j, v = int(row.get("i")), int(row.get("j")), row.get("value_GPa")
            except (TypeError, ValueError):
                continue
            if v is None:
                continue
            if i == 1 and j == 1 and es.get("C11_GPa") is None:
                es["C11_GPa"] = float(v)
                changed = True
            elif i == 1 and j == 2 and es.get("C12_GPa") is None:
                es["C12_GPa"] = float(v)
                changed = True
            elif i == 4 and j == 4 and es.get("C44_GPa") is None:
                es["C44_GPa"] = float(v)
                changed = True
    # Modules top-level (déjà alimentés par le Voigt block du journal).
    for src_k in (
        "bulk_modulus_GPa",
        "shear_modulus_GPa",
        "young_modulus_GPa",
        "poisson_ratio",
    ):
        v = parsed.get(src_k)
        if v is not None and es.get(src_k) is None:
            es[src_k] = v
            changed = True
    # Thermodynamique.
    th = results.setdefault("thermo", {})
    for k in ("debye_temperature_K", "zero_point_energy_Ry"):
        v = parsed.get(k)
        if v is not None and th.get(k) is None:
            th[k] = v
            changed = True
    return changed


def _utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def process_marker(marker_path: Path) -> tuple[str, dict]:
    """Traite un marker ; renvoie (action, résumé)."""
    try:
        data = json.loads(marker_path.read_text(encoding="utf-8", errors="replace"))
    except (OSError, json.JSONDecodeError) as ex:
        return ("unreadable", {"path": str(marker_path), "error": str(ex)})

    wd = Path(data.get("work_dir") or marker_path.parent).resolve()
    st = str(data.get("status") or "")

    ts = _utc_iso()

    # 1) Zombies running/queued → interrupted.
    if st in ("running", "queued", "started"):
        data["status"] = "interrupted"
        data["message"] = (
            "Reprise : worker précédent perdu. "
            "Relancez le calcul via /api/pipeline/run (POST /api/pipeline/jobs/<id>/run)."
        )
        logs = list(data.get("logs") or [])
        logs.append(
            f"[{ts}] work_si_reparse_helper : statut disque « {st} » → « interrupted »."
        )
        data["logs"] = logs[-200:]
        data["finished_at"] = ts
        try:
            marker_path.write_text(
                json.dumps(data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except OSError as ex:
            return ("write_error", {"path": str(marker_path), "error": str(ex)})
        return (
            "recovered",
            {
                "path": str(marker_path),
                "job_id": data.get("job_id"),
                "previous_status": st,
            },
        )

    # 2) Jobs ``done`` : re-parse et peuple les constantes élastiques.
    if st == "done":
        results = data.setdefault("results", {})
        changed_any = False
        tpw_out = wd / "thermo_pw_run.out"
        if tpw_out.is_file():
            try:
                txt = tpw_out.read_text(encoding="utf-8", errors="replace")
                parsed = parse_thermo_pw_log(txt) or {}
                if _merge_into_results(results, parsed):
                    changed_any = True
                merged_dat = merge_elastic_from_output_el_cons_files(wd)
                if merged_dat:
                    if _merge_into_results(results, merged_dat):
                        changed_any = True
                    ei = merged_dat.get("elastic_independent_GPa")
                    if isinstance(ei, dict):
                        consts = ei.get("constants_Gpa") or {}
                        if isinstance(consts, dict):
                            es = results.setdefault("elastic", {})
                            for k in ("C11_GPa", "C12_GPa", "C44_GPa"):
                                v = consts.get(k)
                                if v is not None and es.get(k) is None:
                                    es[k] = float(v)
                                    changed_any = True
            except Exception as ex:  # noqa: BLE001
                return (
                    "parse_error",
                    {"path": str(marker_path), "work_dir": str(wd), "error": str(ex)},
                )
        if not changed_any:
            return ("noop", {"path": str(marker_path), "status": "done"})

        # Ajouter une ligne de log datée.
        logs = list(data.get("logs") or [])
        logs.append(
            f"[{ts}] work_si_reparse_helper : repopulated elastic constants (C11/C12/C44)."
        )
        data["logs"] = logs[-200:]
        try:
            marker_path.write_text(
                json.dumps(data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except OSError as ex:
            return ("write_error", {"path": str(marker_path), "error": str(ex)})
        es = results.get("elastic") or {}
        return (
            "reparsed",
            {
                "path": str(marker_path),
                "job_id": data.get("job_id"),
                "work_dir": str(wd),
                "C11_GPa": es.get("C11_GPa"),
                "C12_GPa": es.get("C12_GPa"),
                "C44_GPa": es.get("C44_GPa"),
                "bulk_modulus_GPa": es.get("bulk_modulus_GPa"),
                "shear_modulus_GPa": es.get("shear_modulus_GPa"),
                "young_modulus_GPa": es.get("young_modulus_GPa"),
                "poisson_ratio": es.get("poisson_ratio"),
            },
        )

    return ("skipped", {"path": str(marker_path), "status": st})


def main() -> int:
    if not WORK_ROOT.is_dir():
        print(f"[ERREUR] work_root introuvable : {WORK_ROOT}", file=sys.stderr)
        return 2
    markers = sorted(WORK_ROOT.glob("**/pipeline_api_job_state.json"))
    counts = {"recovered": 0, "reparsed": 0, "noop": 0, "skipped": 0, "unreadable": 0, "write_error": 0, "parse_error": 0}
    full_report: list[dict] = []
    for marker_path in markers:
        action, info = process_marker(marker_path)
        counts[action] = counts.get(action, 0) + 1
        full_report.append({"action": action, **info})

    print(f"# WORK_ROOT = {WORK_ROOT}")
    for k, v in counts.items():
        print(f"# {k}: {v}")
    print()
    print(json.dumps(full_report, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())

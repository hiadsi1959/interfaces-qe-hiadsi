/* ===========================================================================
 *  supra_inputs.js — Générateurs des fichiers d'entrée Quantum ESPRESSO
 *  pour le workflow Supraconductivité de Supra-QE.
 *
 *  Tous les générateurs renvoient une chaîne brute (texte) prête à être
 *  écrite dans un fichier .in.
 *
 *  L'objet `params` regroupe les paramètres communs (lus dans le formulaire) :
 *
 *      {
 *        material:      "Nb",
 *        prefix:        "Nb",
 *        outdir:        "/home/.../supra-QE/outputs/Nb/",
 *        pseudo_dir:    "/home/.../supra-QE/pseudos/",
 *        ibrav:         3,
 *        celldm:        [6.21, 0, 0, 0, 0, 0],
 *        nat:           1,
 *        ntyp:          1,
 *        ecutwfc:       60,
 *        ecutrho:       300,
 *        species:       [ { symbol:"Nb", mass:92.906, pseudo:"Nb.upf" } ],
 *        positions:     [ { sym:"Nb", x:0, y:0, z:0 } ],
 *        k_scf:         [8, 8, 8],
 *        k_nscf:        [24, 24, 24],
 *        q_phonon:      [4, 4, 4],
 *        smearing:      "mv",           // mv | mp | gaussian | fd | cold
 *        degauss:       0.02,
 *        conv_thr_scf:  1e-10,
 *        conv_thr_nscf: 1e-10,
 *        tr2_ph:        1e-12,
 *        electron_phonon: "interpolated",   // | "simple"
 *        mu_star:       0.10,
 *        fildvscf:      "aldv",
 *        fildyn:        "matdyn",
 *        flfrc:         "ifc.fc",
 *        nproc_pools:   1
 *      }
 * ========================================================================= */

(function (global) {
    'use strict';

    /** Formate un nombre flottant pour QE (notation scientifique avec 'd'). */
    function f(v, digits = 6) {
        if (v === null || v === undefined || isNaN(v)) return '0.0d0';
        const abs = Math.abs(v);
        // Toute valeur < 0.01 ou ≥ 1e5 → notation exponentielle "1.0d-3"
        if ((abs > 0 && abs < 1e-2) || abs >= 1e5) {
            // au moins 1 chiffre significatif après la virgule
            const s = v.toExponential(Math.max(1, digits));
            return s.replace('e', 'd');
        }
        return Number(v).toFixed(digits);
    }

    /** Bloc CELL_PARAMETERS / ATOMIC_SPECIES / ATOMIC_POSITIONS / K_POINTS. */
    function blocCommun(p, includeKPoints) {
        const lines = [];

        // ATOMIC_SPECIES
        lines.push('ATOMIC_SPECIES');
        (p.species || []).forEach(sp => {
            lines.push(`  ${sp.symbol.padEnd(3)} ${Number(sp.mass).toFixed(4).padStart(10)}  ${sp.pseudo}`);
        });

        // CELL_PARAMETERS (ibrav=0) — unité = celle extraite du vc-relax
        // (alat | bohr | angstrom). Ne jamais étiqueter « angstrom » des
        // vecteurs alat : QE interpréterait une mauvaise maille.
        if (Number(p.ibrav) === 0 && Array.isArray(p.cell_parameters)) {
            const unit = String(p.cell_unit || 'alat').toLowerCase();
            const qeUnit = (unit === 'angstrom' || unit === 'bohr' || unit === 'alat')
                ? unit : 'alat';
            lines.push('');
            lines.push(`CELL_PARAMETERS ${qeUnit}`);
            p.cell_parameters.forEach(row => {
                lines.push(`  ${row.map(x => Number(x).toFixed(10).padStart(16)).join(' ')}`);
            });
        }

        // ATOMIC_POSITIONS
        lines.push('');
        lines.push(`ATOMIC_POSITIONS ${p.atomic_positions_units || 'crystal'}`);
        (p.positions || []).forEach(at => {
            lines.push(`  ${at.sym.padEnd(3)} ${Number(at.x).toFixed(10).padStart(14)} ${Number(at.y).toFixed(10).padStart(14)} ${Number(at.z).toFixed(10).padStart(14)}`);
        });

        if (includeKPoints) {
            const g = p._k_for_this_step || p.k_scf || [8, 8, 8];
            lines.push('');
            lines.push('K_POINTS automatic');
            lines.push(`  ${g[0]} ${g[1]} ${g[2]}  0 0 0`);
        }

        return lines.join('\n');
    }

    /** Modes magnétiques v1.4 — propagés sur SCF, NSCF (classic + EPW). */
    const MAG_MODES = ['none', 'collinear', 'noncollinear', 'soc'];

    function normalizeMagMode(mode) {
        const m = String(mode || 'none').toLowerCase().trim();
        if (['nonmag', 'non-magnetic', '1'].includes(m)) return 'none';
        if (['colin', 'collinear', '2'].includes(m)) return 'collinear';
        if (['noncolin', 'noncollinear', '4'].includes(m)) return 'noncollinear';
        if (['soc', 'spinorbit', 'lspinorb'].includes(m)) return 'soc';
        return MAG_MODES.includes(m) ? m : 'none';
    }

    function parseStartingMagList(raw) {
        if (Array.isArray(raw)) {
            return raw.map(v => Number(v)).filter(v => Number.isFinite(v));
        }
        if (raw == null || raw === '') return [];
        return String(raw).split(/[,;\s]+/)
            .map(s => parseFloat(s.trim()))
            .filter(v => Number.isFinite(v));
    }

    function parseStartingMagFromScfText(text) {
        if (!text) return [];
        const mags = [];
        const re = /starting_magnetization\s*\(\s*(\d+)\s*\)\s*=\s*([^\s,!/'"]+)/gi;
        let m;
        while ((m = re.exec(text)) !== null) {
            const idx = parseInt(m[1], 10) - 1;
            const v = parseFloat(String(m[2]).replace(/d/i, 'e'));
            if (idx >= 0 && Number.isFinite(v)) mags[idx] = v;
        }
        return mags;
    }

    function detectMagModeFromScfText(text) {
        if (!text) return 'none';
        if (/\blspinorb\s*=\s*\.true\./i.test(text)) return 'soc';
        const nspinM = text.match(/\bnspin\s*=\s*(\d+)/i);
        const ns = nspinM ? parseInt(nspinM[1], 10) : 1;
        if (ns >= 4) return 'noncollinear';
        if (ns === 2) return 'collinear';
        return 'none';
    }

    function appendMagnetismSystemLines(lines, p) {
        const mode = normalizeMagMode(p.mag_mode);
        if (mode === 'none') return;
        if (mode === 'soc') {
            lines.push(`    lspinorb     = .true.`);
            lines.push(`    nspin        = 4`);
        } else if (mode === 'noncollinear') {
            lines.push(`    nspin        = 4`);
        } else if (mode === 'collinear') {
            lines.push(`    nspin        = 2`);
        }
        let mags = parseStartingMagList(p.starting_magnetization);
        const ntyp = Math.max(1, Number(p.ntyp) || (p.species || []).length || 1);
        if (!mags.length && mode !== 'none') {
            mags = Array.from({ length: ntyp }, (_, i) => (i === 0 ? 0.5 : 0.5));
        }
        mags.forEach((v, i) => {
            if (v != null && Number.isFinite(Number(v))) {
                lines.push(`    starting_magnetization(${i + 1}) = ${f(Number(v), 4)}`);
            }
        });
    }

    /** &SYSTEM avec celldm correctement géré */
    function blocSystem(p) {
        const ibrav = Number(p.ibrav) || 0;
        const lines = ['&SYSTEM'];
        lines.push(`    ibrav = ${ibrav}`);

        // ibrav≠0 : celldm complets. ibrav=0 + CELL_PARAMETERS alat : celldm(1)=alat.
        if (ibrav !== 0 && Array.isArray(p.celldm)) {
            p.celldm.forEach((v, i) => {
                if (v && Math.abs(v) > 0) lines.push(`    celldm(${i + 1}) = ${f(v, 8)}`);
            });
        } else if (ibrav === 0) {
            const alat = Number(p.alat || (Array.isArray(p.celldm) ? p.celldm[0] : 0)) || 0;
            const unit = String(p.cell_unit || '').toLowerCase();
            if (alat > 0 && (unit === 'alat' || unit === '' || !p.cell_unit)) {
                lines.push(`    celldm(1) = ${f(alat, 8)}`);
            }
        }
        lines.push(`    nat   = ${p.nat}`);
        lines.push(`    ntyp  = ${p.ntyp}`);
        lines.push(`    ecutwfc = ${f(p.ecutwfc, 2)}`);
        if (p.ecutrho) lines.push(`    ecutrho = ${f(p.ecutrho, 2)}`);

        appendMagnetismSystemLines(lines, p);

        // Métaux (supraconducteurs ou magnétiques métalliques) : smearing
        lines.push(`    occupations = 'smearing'`);
        lines.push(`    smearing    = '${p.smearing || 'mv'}'`);
        lines.push(`    degauss     = ${f(p.degauss || 0.02, 6)}`);

        if (p.la2F) lines.push(`    la2F = .true.`);
        if (p.nbnd) lines.push(`    nbnd = ${p.nbnd}`);
        if (p.vdw_corr && p.vdw_corr !== 'none') {
            lines.push(`    vdw_corr = '${p.vdw_corr}'`);
        }

        lines.push('/');
        return lines.join('\n');
    }

    /* ────────────────────────────────────────────────────────────────────
     *  PRÉREQUIS 1 — vc-relax (optimisation maille + positions)
     * ──────────────────────────────────────────────────────────────────── */
    function genererVCRelax(p) {
        const k = p.k_vcrelax || [8, 8, 8];
        const params = { ...p, _k_for_this_step: k };
        const forcThr = p.forc_conv_thr || '1.0d-4';
        const etotThr = p.etot_conv_thr || '1.0d-5';

        const out = [];
        out.push(`! Supra-QE — Prérequis 1 : vc-relax pour ${p.material}`);
        out.push('&CONTROL');
        out.push(`    calculation   = 'vc-relax'`);
        out.push(`    restart_mode  = 'from_scratch'`);
        out.push(`    prefix        = '${p.prefix}'`);
        out.push(`    outdir        = '${p.outdir}'`);
        out.push(`    pseudo_dir    = '${p.pseudo_dir}'`);
        out.push(`    forc_conv_thr = ${forcThr}`);
        out.push(`    etot_conv_thr = ${etotThr}`);
        out.push(`    verbosity     = 'high'`);
        out.push('/');
        out.push(blocSystem(p));
        out.push('&ELECTRONS');
        out.push(`    conv_thr        = ${f(p.conv_thr_scf || 1e-10, 1)}`);
        out.push(`    mixing_beta     = 0.7d0`);
        out.push(`    diagonalization = 'david'`);
        out.push('/');
        out.push('&IONS');
        out.push(`    ion_dynamics = '${p.ion_dynamics || 'bfgs'}'`);
        out.push('/');
        out.push('&CELL');
        out.push(`    cell_dynamics  = '${p.cell_dynamics || 'bfgs'}'`);
        out.push(`    press          = ${f(p.press || 0, 4)}`);
        out.push(`    press_conv_thr = ${f(p.press_tol || 0.5, 4)}`);
        out.push(`    cell_dofree    = 'all'`);
        out.push('/');
        out.push(blocCommun(params, true));
        return out.join('\n') + '\n';
    }

    /** PRÉREQUIS 2 — SCF final sur géométrie optimisée (grille k dense). */
    function genererPrereqSCF(p) {
        return genererSCF({ ...p, _k_for_this_step: p.k_scf || [12, 12, 12] });
    }

    function genererPrerequis(p) {
        return {
            vcrelax: {
                name: `${p.material}.vc-relax.in`,
                content: genererVCRelax(p),
            },
            scf: {
                name: `${p.material}.scf_prereq.in`,
                content: genererPrereqSCF(p),
            },
        };
    }

    /** Parse CIF minimal → structure { ibrav:0, cell_parameters, positions, species }. */
    function parseCIF(text) {
        const lineVal = (key) => {
            const re = new RegExp(`^\\s*_${key}\\s+([\\d.eE+-]+)`, 'im');
            for (const line of text.split('\n')) {
                const m = line.match(re);
                if (m) return parseFloat(m[1]);
            }
            return null;
        };
        const a = lineVal('cell_length_a');
        if (!a) return null;
        const b = lineVal('cell_length_b') || a;
        const c = lineVal('cell_length_c') || a;
        const alpha = (lineVal('cell_angle_alpha') || 90) * Math.PI / 180;
        const beta  = (lineVal('cell_angle_beta')  || 90) * Math.PI / 180;
        const gamma = (lineVal('cell_angle_gamma') || 90) * Math.PI / 180;

        const bx = b * Math.cos(gamma);
        const by = b * Math.sin(gamma);
        const cx = c * Math.cos(beta);
        const cy = c * (Math.cos(alpha) - Math.cos(beta) * Math.cos(gamma)) / Math.sin(gamma);
        const cz = Math.sqrt(Math.max(c * c - cx * cx - cy * cy, 1e-12));

        const positions = [];
        const speciesMap = {};
        const atomRe = /^\s*([A-Za-z]{1,2})\d*\s+([\d.eE+-]+)\s+([\d.eE+-]+)\s+([\d.eE+-]+)/;
        for (const line of text.split('\n')) {
            if (line.trim().startsWith('_') || line.trim().startsWith('#') || line.trim().startsWith('loop_')) continue;
            const m = line.match(atomRe);
            if (!m) continue;
            let sym = m[1];
            sym = sym.charAt(0).toUpperCase() + sym.slice(1).toLowerCase();
            const x = parseFloat(m[2]), y = parseFloat(m[3]), z = parseFloat(m[4]);
            if (!Number.isFinite(x) || x > 1.5) continue;
            positions.push({ sym, x, y, z });
            if (!speciesMap[sym]) {
                speciesMap[sym] = { symbol: sym, mass: atomicMass(sym), pseudo: `${sym}.upf` };
            }
        }
        if (!positions.length) return null;
        return {
            ibrav: 0,
            cell_parameters: [[a, 0, 0], [bx, by, 0], [cx, cy, cz]],
            positions_unit: 'crystal',
            positions,
            species: Object.values(speciesMap),
        };
    }

    const ATOMIC_MASSES = {
        H:1.008, He:4.003, Li:6.94, C:12.011, N:14.007, O:15.999, F:18.998,
        Na:22.99, Mg:24.305, Al:26.982, Si:28.085, S:32.06, Cl:35.45,
        K:39.098, Ca:40.078, Ti:47.867, V:50.942, Cr:51.996, Mn:54.938,
        Fe:55.845, Co:58.933, Ni:58.693, Cu:63.546, Zn:65.38,
        Nb:92.906, Mo:95.95, Ru:101.07, Rh:102.906, Pd:106.42, Ag:107.868,
        Sn:118.71, I:126.904, Ba:137.327, La:138.905, Hf:178.49,
        Ta:180.948, W:183.84, Re:186.207, Os:190.23, Ir:192.217, Pt:195.084,
        Au:196.967, Pb:207.2, Hg:200.592,
    };
    function atomicMass(sym) { return ATOMIC_MASSES[sym] || 1.0; }

    /* ────────────────────────────────────────────────────────────────────
     *  1. SCF — pw.x, k modeste (ex. 8³) mais smearing métallique correct
     * ──────────────────────────────────────────────────────────────────── */
    function genererSCF(p) {
        p = { ...p, _k_for_this_step: p.k_scf || [8, 8, 8] };

        const out = [];
        out.push('&CONTROL');
        out.push(`    calculation = 'scf'`);
        out.push(`    prefix      = '${p.prefix}'`);
        out.push(`    outdir      = '${p.outdir}'`);
        out.push(`    pseudo_dir  = '${p.pseudo_dir}'`);
        out.push(`    tprnfor     = .true.`);
        out.push(`    tstress     = .true.`);
        out.push(`    verbosity   = 'high'`);
        out.push('/');
        out.push(blocSystem(p));
        out.push('&ELECTRONS');
        out.push(`    conv_thr     = ${f(p.conv_thr_scf || 1e-10, 1)}`);
        out.push(`    mixing_beta  = 0.7d0`);
        out.push(`    diagonalization = 'david'`);
        out.push('/');
        out.push(blocCommun(p, true));
        return out.join('\n') + '\n';
    }

    /* ────────────────────────────────────────────────────────────────────
     *  2. NSCF — pw.x
     *     - mode 'classic' : grille k très dense (24³) + la2F=.true.
     *     - mode 'epw'     : grille k MODESTE et uniforme (6³ ou 8³)
     *                        + nbnd élevé pour la wannierisation.
     * ──────────────────────────────────────────────────────────────────── */
    function genererNSCF(p) {
        const isEPW = (p.method === 'epw');
        const kgrid = isEPW
            ? (p.k_nscf_epw || [8, 8, 8])
            : (p.k_nscf      || [24, 24, 24]);
        const params = { ...p, _k_for_this_step: kgrid };

        // En mode EPW : nbnd élevé obligatoire pour Wannier
        if (isEPW && !params.nbnd) params.nbnd = Math.max(20, params.ntyp * 12);

        // Davidson (david) plante souvent en NSCF dense : « S matrix not
        // positive definite » (cdiaghg). CG est plus lent mais stable.
        if (!isEPW && !params.nbnd) {
            params.nbnd = Math.max(24, (Number(params.nat) || 1) * 12);
        }

        const out = [];
        out.push('&CONTROL');
        out.push(`    calculation = 'nscf'`);
        out.push(`    prefix      = '${p.prefix}'`);
        out.push(`    outdir      = '${p.outdir}'`);
        out.push(`    pseudo_dir  = '${p.pseudo_dir}'`);
        out.push(`    verbosity   = 'high'`);
        out.push('/');
        // la2F=.true. seulement en mode classique (matdyn.x / lambda.x)
        const sysP = { ...params, la2F: !isEPW };
        out.push(blocSystem(sysP));
        out.push('&ELECTRONS');
        out.push(`    conv_thr     = ${f(p.conv_thr_nscf || 1e-10, 1)}`);
        out.push(`    diagonalization = 'cg'`);
        out.push('/');
        out.push(blocCommun(params, true));

        // EPW : il faut une grille K_POINTS « cristallographique » explicite
        // (uniforme, centrée à Γ). On donne aussi l'alternative crystal pour info.
        return out.join('\n') + '\n';
    }

    /* ────────────────────────────────────────────────────────────────────
     *  3. Phonons — ph.x, DFPT avec couplage électron-phonon
     *  - mode 'classic' : electron_phonon = 'interpolated' / 'simple' (matdyn)
     *  - mode 'epw'     : ne calcule pas le couplage in-line, mais sauvegarde
     *                     fildvscf pour qu'EPW le lise ensuite.
     * ──────────────────────────────────────────────────────────────────── */
    function genererPhonon(p) {
        const q = p.q_phonon || [4, 4, 4];
        const isEPW = (p.method === 'epw');
        const out = [];
        out.push(`! Phonons${isEPW ? ' (préparation EPW)' : ' + couplage e-p'} pour ${p.material}`);
        out.push('&INPUTPH');
        out.push(`    prefix       = '${p.prefix}'`);
        out.push(`    outdir       = '${p.outdir}'`);
        out.push(`    fildyn       = '${p.fildyn || (isEPW ? `${p.prefix}.dyn` : 'matdyn')}'`);
        out.push(`    fildvscf     = '${p.fildvscf || (isEPW ? `${p.prefix}.dvscf` : 'aldv')}'`);
        if (!isEPW) {
            out.push(`    electron_phonon = '${p.electron_phonon || 'interpolated'}'`);
            out.push(`    el_ph_sigma  = ${f(p.el_ph_sigma || 0.005, 4)}`);
            out.push(`    el_ph_nsigma = ${Number(p.el_ph_nsigma || 10)}`);
        }
        out.push(`    tr2_ph       = ${f(p.tr2_ph || 1e-12, 1)}`);
        out.push(`    ldisp        = .true.`);
        out.push(`    nq1          = ${q[0]}`);
        out.push(`    nq2          = ${q[1]}`);
        out.push(`    nq3          = ${q[2]}`);
        if (isEPW) {
            // Recommandations EPW : pas de symétrie sur les modes pour éviter
            // les soucis lors de la wannierisation des éléments e-p
            out.push(`    epsil        = .false.`);
        }
        if (p.recover_phonon) out.push(`    recover      = .true.`);
        out.push('/');
        return out.join('\n') + '\n';
    }

    /* ────────────────────────────────────────────────────────────────────
     *  4a. q2r.x — IFC en espace réel
     * ──────────────────────────────────────────────────────────────────── */
    function genererQ2R(p) {
        const out = [];
        out.push('&INPUT');
        out.push(`    fildyn = '${p.fildyn || 'matdyn'}'`);
        out.push(`    flfrc  = '${p.flfrc || 'ifc.fc'}'`);
        out.push(`    zasr   = '${p.zasr || 'simple'}'`);
        // Requis pour que matdyn.x (la2F) interpole α²F : q2r doit Fourier-
        // transformer les coefficients e–p produits par ph.x (interpolated).
        out.push(`    la2F   = .true.`);
        out.push('/');
        return out.join('\n') + '\n';
    }

    /* ────────────────────────────────────────────────────────────────────
     *  4b. matdyn.x — DOS phononique + α²F / λ si la2F=.true.
     *  Namelist QE 7.x : flfrc, asr, dos, nk*, DeltaE, la2F, amass, …
     *  PAS de electron_phonon / fila2F / mu (clés ph.x / lambda.x).
     *  μ* et Tc McMillan/Allen–Dynes : onglet Résultats (supra_results).
     * ──────────────────────────────────────────────────────────────────── */
    function genererMatdyn(p) {
        const q = p.q_phonon || [4, 4, 4];
        // Pour α²F : grille q dense pour intégrer
        const qdense = p.q_dos || [q[0] * 2, q[1] * 2, q[2] * 2];
        const out = [];
        out.push(`! Supra-QE — matdyn.x (la2F) pour ${p.material || 'mat'}`);
        out.push(`! μ* = ${f(p.mu_star ?? 0.10, 4)} appliqué dans l'onglet Résultats, pas ici.`);
        out.push('&INPUT');
        out.push(`    asr        = '${p.asr || 'simple'}'`);
        out.push(`    flfrc      = '${p.flfrc || 'ifc.fc'}'`);
        out.push(`    flfrq      = '${p.flfrq || 'freq.gp'}'`);
        out.push(`    fldos      = '${p.fldos || 'phonon.dos'}'`);
        out.push(`    flvec      = '${p.flvec || 'matdyn.modes'}'`);
        out.push(`    dos        = .true.`);
        out.push(`    nk1        = ${qdense[0]}`);
        out.push(`    nk2        = ${qdense[1]}`);
        out.push(`    nk3        = ${qdense[2]}`);
        out.push(`    DeltaE     = ${f(p.deltaE_phonon || 1.0, 3)}`);
        out.push(`    la2F       = .true.`);
        // Masses (recommandé si absentes du fichier flfrc)
        (p.species || []).forEach((sp, i) => {
            if (sp && sp.mass != null && !isNaN(Number(sp.mass))) {
                out.push(`    amass(${i + 1}) = ${f(Number(sp.mass), 4)}`);
            }
        });
        out.push('/');
        return out.join('\n') + '\n';
    }

    /**
     *  fs.x (PP) — export .bxsf pour XCrySDen.
     *  Prérequis : SCF + NSCF (grille k régulière). outdir = celui du SCF/NSCF.
     */
    function genererFs(p) {
        const pref = String(p.prefix || p.material || 'pw').trim() || 'pw';
        const outdir = normalizeFsOutdir(p.outdir || './');
        const out = [];
        out.push('! Surface de Fermi → XCrySDen (standard QE / Supra-QE)');
        out.push(`! 1. fs.x < ${pref}.fs.in > ${pref}.fs.out`);
        out.push(`! 2. xcrysden --bxsf ${pref}.bxsf`);
        out.push('! Prérequis : pw.x SCF + NSCF (grille k régulière)');
        out.push('');
        out.push('&fermi');
        out.push(`  prefix = '${pref}'`);
        out.push(`  outdir = '${outdir}'`);
        out.push('/');
        return out.join('\n') + '\n';
    }

    function normalizeFsOutdir(d) {
        let s = String(d == null ? './' : d).trim().replace(/\\/g, '/');
        if (!s) s = './';
        if (!s.endsWith('/')) s += '/';
        return s;
    }

    /* ────────────────────────────────────────────────────────────────────
     *  alpha2f.x (QE 7.x) — voie tétraèdres distincte de matdyn+la2F.
     *  Attend un vrai input ph.x (phq_readin) + &INPUTA2F nfreq.
     *  Pour WF1 standard, α²F vient de matdyn (la2F) : ne pas lancer ceci.
     * ──────────────────────────────────────────────────────────────────── */
    function genererAlpha2F(p) {
        const nfreq = Math.max(50, Math.round(Number(p.alpha2f_nfreq) || 500));
        const out = [];
        out.push(`! Supra-QE — NE PAS utiliser pour la voie classique matdyn+la2F.`);
        out.push(`! alpha2f.x (QE 7) lit lambda*.dat (ph.x tétraèdres) via phq_readin`);
        out.push(`! puis &INPUTA2F. α²F / λ / ω_log de WF1 : matdyn.x + onglet Résultats.`);
        out.push(`! Fichier conservé uniquement comme aide-mémoire (étape non lancée).`);
        out.push('&INPUTA2F');
        out.push(`    nfreq = ${nfreq}`);
        out.push('/');
        return out.join('\n') + '\n';
    }

    /* ────────────────────────────────────────────────────────────────────
     *  4c. epw.x — Wannierisation + Éliashberg (isotrope/anisotrope) → Tᶜ, Δ
     *
     *  EPW lit :
     *    - le NSCF coarse (pour les fonctions d'onde + nbnd élevé)
     *    - les fichiers dvscf produits par ph.x (potentiel perturbé)
     *    - dvscf_dir doit pointer vers le ``save/`` du dossier phonon
     *
     *  Paramètres clés :
     *    - nbndsub                  : nombre de bandes wannierisées
     *    - proj(:)                  : projections initiales par espèce
     *    - dis_win_min / dis_win_max: fenêtre extérieure (disentanglement)
     *    - dis_froz_min/dis_froz_max: fenêtre gelée (bandes 100% incluses)
     *    - nk/nq coarse             : doivent matcher NSCF / ph.x
     *    - nkf/nqf fine             : grilles d'interpolation (40³)
     *    - eliashberg / liso / laniso
     *    - muc                       : μ* écranter
     *    - temps, nstemp             : balayage en température (K)
     * ──────────────────────────────────────────────────────────────────── */
    function genererEPW(p) {
        const kc = p.k_nscf_epw || [8, 8, 8];
        const qc = p.q_phonon   || [4, 4, 4];
        const kf = p.k_fine_epw || [40, 40, 40];
        const qf = p.q_fine_epw || [40, 40, 40];

        // amass(:) pour chaque espèce
        const amassLines = (p.species || []).map((s, i) =>
            `    amass(${i + 1})  = ${f(s.mass, 4)}`);

        // Projections par défaut : tous les atomes "X:sp3d2" si non fourni
        let projLines;
        if (Array.isArray(p.epw_projections) && p.epw_projections.length) {
            projLines = p.epw_projections.map((pr, i) =>
                `    proj(${i + 1})   = '${pr}'`);
        } else {
            projLines = (p.species || []).map((s, i) =>
                `    proj(${i + 1})   = '${s.symbol}:sp3d2'`);
        }

        const out = [];
        out.push(`! EPW pour ${p.material} — Wannierisation + Éliashberg`);
        out.push('&inputepw');
        out.push(`    prefix         = '${p.prefix}'`);
        out.push(`    outdir         = '${p.outdir}'`);
        amassLines.forEach(l => out.push(l));
        out.push('');
        out.push(`    dvscf_dir      = '${p.epw_dvscf_dir || 'save/'}'`);
        out.push('');
        out.push(`    elph           = .true.`);
        out.push(`    kmaps          = .false.`);
        out.push(`    epbwrite       = ${p.epw_epbwrite === false ? '.false.' : '.true.'}`);
        out.push(`    epbread        = ${p.epw_epbread  === true  ? '.true.'  : '.false.'}`);
        out.push(`    epwwrite       = ${p.epw_epwwrite === false ? '.false.' : '.true.'}`);
        out.push(`    epwread        = ${p.epw_epwread  === true  ? '.true.'  : '.false.'}`);
        out.push(`    etf_mem        = 1`);
        out.push('');
        out.push('    ! Wannierisation');
        out.push(`    wannierize     = .true.`);
        const nbndRef = Number(p.nbnd || 30);
        const nbndsub = Math.min(
            Number(p.epw_nbndsub || 5),
            Math.max(2, nbndRef - 1),
        );
        out.push(`    nbndsub        = ${nbndsub}`);
        out.push(`    num_iter       = ${Number(p.epw_num_iter || 500)}`);
        out.push(`    dis_win_min    = ${f(p.epw_dis_win_min  ?? -3.0,  4)}`);
        out.push(`    dis_win_max    = ${f(p.epw_dis_win_max  ??  15.0, 4)}`);
        out.push(`    dis_froz_min   = ${f(p.epw_dis_froz_min ?? -3.0,  4)}`);
        out.push(`    dis_froz_max   = ${f(p.epw_dis_froz_max ??  8.0,  4)}`);
        projLines.forEach(l => out.push(l));
        out.push('');
        out.push('    ! Surface de Fermi / smearing');
        out.push(`    fsthick        = ${f(p.epw_fsthick   ?? 0.4,  4)}`);
        out.push(`    degaussw       = ${f(p.epw_degaussw  ?? 0.05, 4)}`);
        out.push(`    degaussq       = ${f(p.epw_degaussq  ?? 0.5,  4)}`);
        out.push(`    nsmear         = ${Number(p.epw_nsmear || 1)}`);
        out.push(`    delta_smear    = ${f(p.epw_delta_smear ?? 0.04, 4)}`);
        out.push('');
        const magModeEpw = normalizeMagMode(p.mag_mode);
        // EPW 6.1 LSDA (collinéaire) : lsda='up'|'down' ; eliashberg interdit (readin.f90).
        if (magModeEpw === 'collinear') {
            const lsdaSpin = String(p.epw_lsda || 'up').toLowerCase();
            const lsdaVal = (lsdaSpin === 'down') ? 'down' : 'up';
            out.push('    ! Magnétisme collinéaire (EPW 6.1 LSDA) — α²F uniquement');
            out.push(`    lsda           = '${lsdaVal}'`);
            out.push(`    a2f            = .true.`);
            out.push(`    eliashberg     = .false.`);
            out.push(`    muc            = ${f(p.mu_star ?? 0.10, 4)}`);
        } else {
            out.push('    ! Éliashberg → Tc, Δ (non magnétique ou non collinéaire)');
            out.push(`    eliashberg     = .true.`);
            if (p.epw_aniso) {
                out.push(`    laniso         = .true.`);
            } else {
                out.push(`    liso           = .true.`);
            }
            out.push(`    limag          = .true.`);
            out.push(`    lpade          = .true.`);
            out.push(`    lacon          = .false.`);
            out.push(`    conv_thr_iaxis = ${f(p.epw_conv_iax   ?? 1.0e-3, 1)}`);
            out.push(`    conv_thr_racon = ${f(p.epw_conv_racon ?? 1.0e-3, 1)}`);
            out.push(`    muc            = ${f(p.mu_star ?? 0.10, 4)}`);
            out.push(`    wscut          = ${f(p.epw_wscut ?? 1.0, 4)}`);
            out.push(`    nstemp         = ${Number(p.epw_nstemp || 30)}`);
            out.push(`    temps          = ${f(p.epw_temp_max  ?? 30.0, 4)}`);
        }
        out.push('');
        out.push('    ! Grilles');
        out.push(`    nk1 = ${kc[0]}, nk2 = ${kc[1]}, nk3 = ${kc[2]}`);
        out.push(`    nq1 = ${qc[0]}, nq2 = ${qc[1]}, nq3 = ${qc[2]}`);
        out.push(`    nkf1 = ${kf[0]}, nkf2 = ${kf[1]}, nkf3 = ${kf[2]}`);
        out.push(`    nqf1 = ${qf[0]}, nqf2 = ${qf[1]}, nqf3 = ${qf[2]}`);
        out.push('/');
        return out.join('\n') + '\n';
    }

    function genererSSCHAConfig(p) {
        const n = p.sscha_nconfigs || 64;
        const disp = p.sscha_disp ?? 0.08;
        const seed = p.sscha_seed ?? 42;
        const sc = p.sscha_super || [2, 2, 2];
        return [
            '# Supra-QE — WF3 SSCHA : générateur de configurations',
            `# Matériau : ${p.material}`,
            `# N configurations : ${n}`,
            `# Amplitude déplacement (Å) : ${disp}`,
            `# Graine : ${seed}`,
            `# Supercellule : ${sc[0]} x ${sc[1]} x ${sc[2]}`,
            '#',
            'sscha:',
            `  material: ${p.material}`,
            `  n_configs: ${n}`,
            `  displacement_A: ${disp}`,
            `  random_seed: ${seed}`,
            `  supercell: [${sc.join(', ')}]`,
            `  output_dir: ${p.outdir}sscha_configs/`,
            '',
        ].join('\n');
    }

    function genererSSCHAPwForces(p) {
        const sp = {
            ...p,
            method: 'sscha',
            ecutwfc: p.sscha_ecutwfc || p.ecutwfc || 80,
            conv_thr_scf: parseFloat(String(p.sscha_conv_thr || '1e-8').replace(/d/i, 'e')),
            k_scf: p.sscha_k || [6, 6, 6],
        };
        const base = genererSCF(sp);
        return base.replace(
            "    calculation = 'scf'",
            "    calculation = 'scf'  ! WF3 — forces SSCHA (template par configuration)"
        );
    }

    function genererSSCHAInput(p) {
        const temp = p.sscha_temp ?? 300;
        const maxiter = p.sscha_maxiter ?? 100;
        const tol = p.sscha_tol || '1.0d-6';
        const mu = p.sscha_mu_star ?? p.mu_star ?? 0.10;
        return [
            '# Supra-QE — WF3 SSCHA : minimisation énergie libre',
            `# Matériau : ${p.material}`,
            `# Température (K) : ${temp}`,
            `# Itérations max : ${maxiter}`,
            `# Tolérance : ${tol}`,
            `# μ* : ${mu}`,
            '',
            'sscha_run:',
            `  material: ${p.material}`,
            `  temperature_K: ${temp}`,
            `  max_iterations: ${maxiter}`,
            `  convergence_Ry: ${tol}`,
            `  mu_star: ${mu}`,
            `  forces_dir: ${p.outdir}sscha_forces/`,
            `  output: ${p.material}.sscha.out`,
            '',
        ].join('\n');
    }

    /* ────────────────────────────────────────────────────────────────────
     *  Bundle complet : trois workflows indépendants (classic / epw / sscha).
     *  Chaque méthode est self-contained dans son propre sous-dossier
     *  (`classic/` ou `epw/`) — pas de partage d'outdir entre méthodes.
     *
     *  Retour :
     *    {
     *      classic: { scf, nscf, ph, q2r, matdyn, fs }  // + alpha2f README (optionnel)
     *      epw:     { scf, nscf, ph, epw, fs }           // 5 fichiers + fs.in
     *      sscha:   { config, pw_forces, sscha }         // 3 fichiers (WF3)
     *    }
     *
     *  Chaque entrée :
     *    { name: 'Nb.scf.in', subdir: 'classic', content: '...' }
     * ──────────────────────────────────────────────────────────────────── */
    function genererTousFichiers(p) {
        const classicParams = { ...p, method: 'classic' };
        const epwParams     = { ...p, method: 'epw'     };

        const classic = {
            scf:    { name: `${p.material}.scf.in`,      subdir: 'classic', content: genererSCF(classicParams)    },
            nscf:   { name: `${p.material}.nscf.in`,     subdir: 'classic', content: genererNSCF(classicParams)   },
            ph:     { name: `${p.material}.ph.in`,       subdir: 'classic', content: genererPhonon(classicParams) },
            q2r:    { name: `${p.material}.q2r.in`,      subdir: 'classic', content: genererQ2R(p)                },
            matdyn: { name: `${p.material}.matdyn.in`,   subdir: 'classic', content: genererMatdyn(p)             },
            fs:     { name: `${p.material}.fs.in`,       subdir: 'classic', content: genererFs(classicParams)   },
            // Aide-mémoire uniquement (alpha2f.x QE7 ≠ post-matdyn) — non lancé par l'UI
            alpha2f:{ name: `${p.material}.alpha2f.README.in`, subdir: 'classic',
                      content: genererAlpha2F(p), optional: true, skipRun: true },
        };
        const epw = {
            scf:    { name: `${p.material}.scf.in`,    subdir: 'epw', content: genererSCF(epwParams)    },
            nscf:   { name: `${p.material}.nscf.in`,   subdir: 'epw', content: genererNSCF(epwParams)   },
            ph:     { name: `${p.material}.ph.in`,     subdir: 'epw', content: genererPhonon(epwParams) },
            epw:    { name: `${p.material}.epw.in`,    subdir: 'epw', content: genererEPW(p)            },
            fs:     { name: `${p.material}.fs.in`,     subdir: 'epw', content: genererFs(epwParams)     },
        };
        const sschaParams = { ...p, method: 'sscha' };
        const sscha = {
            config:    { name: `${p.material}.sscha_config.yaml`, subdir: 'sscha', content: genererSSCHAConfig(sschaParams) },
            pw_forces: { name: `${p.material}.pw_forces.in`,      subdir: 'sscha', content: genererSSCHAPwForces(sschaParams) },
            sscha:     { name: `${p.material}.sscha.in`,          subdir: 'sscha', content: genererSSCHAInput(sschaParams) },
        };
        return { classic, epw, sscha };
    }

    /** Aplatissement utilitaire : retourne une liste plate { method, key, ... } */
    function aplatir(bundle) {
        const list = [];
        ['classic', 'epw', 'sscha'].forEach(method => {
            const m = bundle[method] || {};
            Object.entries(m).forEach(([key, file]) => {
                list.push({ method, key, name: file.name, subdir: file.subdir, content: file.content });
            });
        });
        return list;
    }

    /* ────────────────────────────────────────────────────────────────────
     *  Validation côté client (sanity-check avant l'envoi à l'API)
     * ──────────────────────────────────────────────────────────────────── */
    function validerParametres(p) {
        const erreurs = [];
        const conseils = [];

        if (!p.material) erreurs.push("Nom du matériau manquant.");
        if (!p.prefix)   erreurs.push("Préfixe (prefix) manquant.");
        if (!Number.isFinite(Number(p.ecutwfc)) || p.ecutwfc < 30)
            erreurs.push("ecutwfc trop faible pour la supra (≥ 60 Ry recommandé).");
        if (!Array.isArray(p.k_scf)  || p.k_scf.length  !== 3)  erreurs.push("Grille k SCF invalide.");
        if (!Array.isArray(p.q_phonon) || p.q_phonon.length !== 3) erreurs.push("Grille q phonon invalide.");

        const q  = p.q_phonon || [1,1,1];
        const kc = p.k_nscf      || [24,24,24];  // classique
        const ke = p.k_nscf_epw  || [8, 8, 8];   // EPW

        const ratiosClassic = [0,1,2].map(i => q[i] > 0 ? kc[i] / q[i] : 0);
        const intClassic    = [0,1,2].every(i => q[i] > 0 && kc[i] % q[i] === 0);
        const minClassic    = Math.min(...ratiosClassic);
        const ratiosEPW     = [0,1,2].map(i => q[i] > 0 ? ke[i] / q[i] : 0);
        const intEPW        = [0,1,2].every(i => q[i] > 0 && ke[i] % q[i] === 0);

        // On ne bloque que sur la voie demandée : une grille EPW incohérente ne
        // doit pas empêcher de générer les inputs du workflow classique.
        const checkClassic = !p.method || p.method === 'classic';
        const checkEPW     = !p.method || p.method === 'epw';

        if (checkClassic) {
            if (!intClassic) erreurs.push(
                `[Classique] ratio k_NSCF / q_phonon non entier ` +
                `(${ratiosClassic.map(r=>r.toFixed(2)).join(' / ')}).`);
            if (minClassic < 2) erreurs.push(
                `[Classique] ratio k/q minimal = ${minClassic.toFixed(2)} (< 2).`);
            if (minClassic >= 2 && minClassic < 4)
                conseils.push("[Classique] ratio k/q ≥ 2 OK, mais ≥ 4 conseillé.");
        }

        if (checkEPW && !intEPW) erreurs.push(
            `[EPW] ratio k_NSCF_coarse / q non entier ` +
            `(${ratiosEPW.map(r=>r.toFixed(2)).join(' / ')}).`);

        const magMode = normalizeMagMode(p.mag_mode);
        if (magMode === 'soc') {
            conseils.push('[Magnétisme SOC] Pseudos fully relativistic (FR) recommandés ; coût CPU plus élevé.');
        }
        if (magMode !== 'none') {
            conseils.push('[Magnétisme] nspin / starting_mag repris sur SCF et NSCF ; ph.x lit le save SCF (pas de nspin dans ph.in).');
            if (magMode === 'collinear') {
                conseils.push('[WF1 classique] λ / Tc McMillan : prudence si forte aimantation.');
                conseils.push('[WF2 EPW 6.1] epw.in : lsda=up/down + a2f (pas eliashberg/Tc — incompatible LSDA).');
            } else {
                conseils.push('[WF2 EPW] non collinéaire / SOC : eliashberg conservé ; valider doc EPW pour ton matériau.');
            }
        }

        if (!p.smearing || ['fd'].includes(String(p.smearing).toLowerCase()))
            conseils.push("Pour un métal, préférer 'mv' (Marzari-Vanderbilt) ou 'mp' (Methfessel-Paxton).");

        if (!Number.isFinite(Number(p.mu_star)) || p.mu_star < 0.05 || p.mu_star > 0.25)
            conseils.push("μ* hors de la plage usuelle 0.05–0.25. Valeur standard : 0.10.");

        if (!Number.isFinite(Number(p.degauss)) || p.degauss > 0.05)
            conseils.push("degauss > 0.05 Ry est très large pour la supra ; tester 0.01–0.02.");

        if (!Number.isFinite(Number(p.tr2_ph)) || p.tr2_ph > 1e-10)
            conseils.push("tr2_ph > 1e-12 risque de produire un couplage e-p bruité.");

        return {
            ok:       erreurs.length === 0,
            erreurs, conseils,
            ratios_classic: ratiosClassic,
            ratios_epw:     ratiosEPW,
            integer_ratio_classic: intClassic,
            integer_ratio_epw:     intEPW,
        };
    }

    function genererFichiersWorkflow(p, method) {
        const all = genererTousFichiers(p);
        return all[method] || {};
    }

    /* Export */
    global.SupraInputs = {
        genererSCF,
        genererVCRelax,
        genererPrereqSCF,
        genererPrerequis,
        parseCIF,
        genererNSCF,
        genererPhonon,
        genererQ2R,
        genererMatdyn,
        genererFs,
        genererAlpha2F,
        genererEPW,
        genererSSCHAConfig,
        genererSSCHAPwForces,
        genererSSCHAInput,
        genererTousFichiers,
        genererFichiersWorkflow,
        aplatir,
        validerParametres,
        normalizeMagMode,
        parseStartingMagList,
        parseStartingMagFromScfText,
        detectMagModeFromScfText,
        MAG_MODES,
        _format: f,
    };

})(typeof window !== 'undefined' ? window : globalThis);

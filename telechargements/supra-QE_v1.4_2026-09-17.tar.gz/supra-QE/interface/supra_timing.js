/* ===========================================================================
 *  supra_timing.js — Estimation grossière des durées QE (matériau, grilles, PC)
 *  Heuristique : ordre de grandeur pour planifier, pas une garantie.
 * ========================================================================= */
(function (global) {
    'use strict';

    const REF_CPU = 8;

    function kProd(k) {
        return Math.max(1, (k[0] || 1) * (k[1] || 1) * (k[2] || 1));
    }

    function parallelScale(ctx) {
        const np = Math.max(1, ctx.nprocs || 1);
        const nt = Math.max(1, ctx.nthreads || 1);
        const cpu = Math.max(1, ctx.cpuLogical || REF_CPU);
        const mpi = Math.sqrt(np) * Math.min(nt, 4) * 0.85;
        const host = Math.max(0.6, cpu / REF_CPU);
        return Math.max(0.35, mpi * host);
    }

    function natScale(nat) {
        const n = Math.max(1, nat || 1);
        return Math.pow(n / 2, 1.4);
    }

    function ecutScale(ecut) {
        const e = Math.max(30, ecut || 60);
        return Math.pow(e / 60, 1.35);
    }

    /**
     * @param {string} type  scf | nscf | ph | q2r | matdyn | epw | …
     * @param {string} wf    classic | epw
     * @param {object} ctx   buildTimingContext() depuis supra_app
     * @returns {{ seconds: number, detail: string }}
     */
    function estimateStep(type, wf, ctx) {
        const scale = parallelScale(ctx);
        const nat = natScale(ctx.nat);
        const ecut = ecutScale(ctx.ecutwfc);
        const kScf = kProd(ctx.kScf || [12, 12, 12]);
        const kNscf = kProd(ctx.kNscf || [24, 24, 24]);
        const kEpw = kProd(ctx.kNscfEpw || [8, 8, 8]);
        const qT = kProd(ctx.qPh || [4, 4, 4]);

        let sec = 600;
        let detail = '';

        switch (type) {
            case 'scf':
                sec = 420 * nat * (kScf / 1728) * ecut / scale;
                detail = `SCF · k³=${kScf} · nat=${ctx.nat || 1}`;
                break;
            case 'nscf':
                sec = 3600 * nat * (kNscf / 13824) * ecut / scale;
                detail = `NSCF dense · k³=${kNscf}`;
                break;
            case 'ph':
                // Calibré ~24 h pour Nb (nat=2, q=4³, k_nscf~24³) sur ~8 cœurs, 1 MPI
                sec = 86400 * nat * nat * (qT / 64) * Math.sqrt(kNscf / 13824) * ecut / scale;
                detail = `ph.x · ${ctx.qPh?.join('×') || '?'} points q · k_NSCF³=${kNscf}`;
                break;
            case 'q2r':
                sec = 90 * (qT / 64) / scale;
                detail = 'q2r.x · post-traitement rapide';
                break;
            case 'matdyn':
                sec = 240 * (qT / 64) / scale;
                detail = 'matdyn.x · DOS / α²F';
                break;
            case 'alpha2f':
                sec = 300;
                detail = 'alpha2f.x';
                break;
            case 'epw':
                sec = 28800 * nat * (kEpw / 512) * (qT / 64) / scale;
                detail = `epw.x · Wannier + Éliashberg · k³=${kEpw}`;
                break;
            case 'pw_forces':
                sec = 7200 * nat * ecut / scale;
                detail = 'pw.x forces (SSCHA)';
                break;
            case 'sscha':
                sec = 3600;
                detail = 'SSCHA';
                break;
            default:
                sec = 1200;
                detail = type;
        }

        if (wf === 'epw' && type === 'ph') {
            sec *= 0.85;
        }

        sec = Math.max(30, Math.min(sec, 86400 * 14));
        return { seconds: sec, detail };
    }

    function estimateWorkflow(wf, stepTypes, ctx) {
        let total = 0;
        const lines = [];
        (stepTypes || []).forEach(t => {
            const e = estimateStep(t, wf, ctx);
            total += e.seconds;
            lines.push({ type: t, ...e });
        });
        return { totalSeconds: total, steps: lines };
    }

    function formatDuration(sec, opts = {}) {
        if (sec == null || !Number.isFinite(sec)) return '—';
        sec = Math.max(0, Math.round(sec));
        if (sec < 90 && !opts.live) return `${sec} s`;
        const d = Math.floor(sec / 86400);
        let rest = sec - d * 86400;
        const h = Math.floor(rest / 3600);
        rest -= h * 3600;
        const m = Math.floor(rest / 60);
        const s = rest % 60;
        if (opts.live) {
            if (d > 0) {
                return s > 0 || opts.showSeconds
                    ? `${d} j ${h} h ${m} min ${s} s`
                    : `${d} j ${h} h ${m} min`;
            }
            if (h > 0) {
                return opts.showSeconds && m < 30
                    ? `${h} h ${m} min ${s} s`
                    : (m > 0 ? `${h} h ${m} min` : `${h} h`);
            }
            if (m > 0) return opts.showSeconds ? `${m} min ${s} s` : `${m} min`;
            return `${s} s`;
        }
        if (sec < 90) return `${sec} s`;
        if (h >= 48 && !opts.precise && d === 0) return `~${Math.round(h / 24)} j`;
        if (d > 0) return m > 0 ? `${d} j ${h} h ${m} min` : `${d} j ${h} h`;
        if (h > 0) return m > 0 ? `${h} h ${m} min` : `${h} h`;
        return `${m} min`;
    }

    /**
     * Reste affiché : décompte 1 s même quand l'estimation brute est plafonnée
     * (journal ph.x / epw.x silencieux).
     */
    function displayRemainingSeconds(clock, raw) {
        if (!clock || !raw) return null;
        if (raw.remainderUnpredictable) {
            clock._remDisp = null;
            clock._remDispAt = null;
            return null;
        }
        const rem = Math.max(0, raw.remaining);
        const progress = raw.progress ?? 0;
        const now = Date.now();
        const progBump = progress > (clock._remProg ?? 0) + 0.004;
        const rawDrop = clock._remDisp != null && rem < clock._remDisp - 30;
        if (clock._remDisp == null || clock._remDispAt == null || progBump || rawDrop) {
            clock._remDisp = rem;
            clock._remDispAt = now;
            clock._remProg = progress;
            return rem;
        }
        const tick = Math.max(0, clock._remDisp - (now - clock._remDispAt) / 1000);
        if (rem < tick - 120) {
            clock._remDisp = rem;
            clock._remDispAt = now;
            clock._remProg = progress;
            return rem;
        }
        return tick;
    }

    function formatDurationRange(sec) {
        const lo = sec * 0.55;
        const hi = sec * 1.8;
        return `${formatDuration(lo)} – ${formatDuration(hi)}`;
    }

    const QE_MONTH = {
        Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5,
        Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11,
    };

    function _parseQeStartMatch(m) {
        const monKey = m[2].charAt(0).toUpperCase() + m[2].slice(1, 3).toLowerCase();
        const mon = QE_MONTH[monKey];
        if (mon == null) return null;
        const day = parseInt(m[1], 10);
        const year = parseInt(m[3], 10);
        const h = parseInt(m[4], 10);
        const mi = parseInt(m[5], 10);
        const s = parseInt(m[6], 10);
        const t = new Date(year, mon, day, h, mi, s).getTime();
        return Number.isFinite(t) ? t : null;
    }

    /** Dernier « Program … starts on » (relance récente dans le .out). */
    function startedAtMsFromOutText(text) {
        if (!text) return null;
        const re = /starts on\s+(\d{1,2})([A-Za-z]{3})(\d{4})\s+at\s+(\d{1,2}):(\d{2}):(\d{2})/gi;
        let last = null;
        let m;
        while ((m = re.exec(text)) !== null) {
            const t = _parseQeStartMatch(m);
            if (t != null) last = t;
        }
        return last;
    }

    /** Premier démarrage imprimé (journal append / reprise). */
    function earliestStartedAtMsFromOutText(text) {
        if (!text) return null;
        const re = /starts on\s+(\d{1,2})([A-Za-z]{3})(\d{4})\s+at\s+(\d{1,2}):(\d{2}):(\d{2})/gi;
        let first = null;
        let m;
        while ((m = re.exec(text)) !== null) {
            const t = _parseQeStartMatch(m);
            if (t != null && (first == null || t < first)) first = t;
        }
        return first;
    }

    /** Progression lue dans une sortie .out (sans appeler le serveur). */
    function progressFromOutText(type, text, ctx) {
        if (!text) return { fraction: 0.02, detail: '' };
        if (/JOB DONE/i.test(text)) return { fraction: 1, detail: 'terminé' };

        if (type === 'ph') {
            const qPtsM = text.match(/\(\s*(\d+)\s+q-points\)/i);
            const nQTotal = qPtsM
                ? Math.max(1, parseInt(qPtsM[1], 10))
                : Math.max(1, kProd(ctx.qPh || [4, 4, 4]));
            const qMarks = text.match(/Calculation of q\s*=/gi) || [];
            const nQDone = qMarks.length;
            const tail = text.length > 350000 ? text.slice(-350000) : text;
            let lastIter = 0;
            const iterOnCpu = tail.match(/^\s*iter #\s*(\d+) total cpu time/gm);
            if (iterOnCpu) {
                iterOnCpu.forEach(line => {
                    const m = line.match(/iter #\s*(\d+)/);
                    const n = m ? parseInt(m[1], 10) : 0;
                    if (Number.isFinite(n)) lastIter = Math.max(lastIter, n);
                });
            }
            let fraction;
            if (nQDone >= 1) {
                const qIndex = Math.max(0, nQDone - 1);
                const withinQ = Math.min(0.92, lastIter / 11);
                fraction = Math.min(0.97, (qIndex + withinQ) / nQTotal);
                if (!Number.isFinite(fraction)) {
                    fraction = Math.min(0.96, Math.max(0.03, nQDone / nQTotal));
                }
            } else {
                fraction = Math.min(0.96, Math.max(0.02, (nQDone - 0.35) / nQTotal));
            }
            const detail = nQDone >= 1
                ? `q ${Math.min(nQDone, nQTotal)}/${nQTotal}${lastIter ? ` · itér. ${lastIter}` : ''}`
                : `q 0/${nQTotal}`;
            return { fraction, detail, fromQ: nQDone >= 1 };
        }
        if (type === 'scf' || type === 'nscf' || type === 'pw_forces') {
            const it = (text.match(/^\s*iteration #\s*\d+/gim) || []).length;
            const frac = it > 0 ? Math.min(0.92, it / 80) : 0.08;
            return { fraction: frac, detail: it ? `${it} itér.` : 'démarrage' };
        }
        if (type === 'epw') {
            const frac = /Electron-phonon coupling/i.test(text) ? 0.75 : 0.12;
            return { fraction: frac, detail: 'epw.x' };
        }
        if (type === 'q2r' || type === 'matdyn') {
            return { fraction: 0.5, detail: type };
        }
        return { fraction: 0.05, detail: '…' };
    }

    /**
     * Si le job dépasse le plan mais que le % lu dans le .out est trop bas (journal
     * tronqué / silencieux), borne minimale cohérente avec le temps déjà passé.
     */
    function reconcileProgressWithElapsed(fRaw, elapsed, estimate, stepType) {
        let f = fRaw;
        let uncertain = false;
        let planOverrun = 1;
        if (estimate > 3600 && elapsed > 0) {
            planOverrun = elapsed / estimate;
        }
        const longRun = stepType === 'ph' || stepType === 'epw';
        if (longRun && planOverrun > 1.08 && f < 0.94) {
            const fMin = Math.min(0.94, planOverrun / (planOverrun + 1.05));
            if (f < fMin * 0.88 && f < 0.28) {
                f = fMin;
                uncertain = true;
            }
        }
        return { f, uncertain, planOverrun };
    }

    function remainingSeconds(clock) {
        if (!clock) return null;
        const elapsed = (Date.now() - clock.startedAtMs) / 1000;
        const estimate = Math.max(0, clock.estimateSec || 0);
        const stepType = clock.type || '';
        let fRaw = clock.progressFrac ?? 0.02;
        if (!Number.isFinite(fRaw) || fRaw <= 0) fRaw = 0.02;
        const recon = reconcileProgressWithElapsed(fRaw, elapsed, estimate, stepType);
        fRaw = recon.f;
        let remainderUncertain = recon.uncertain;
        let remainderUnpredictable = false;
        const planOverrun = recon.planOverrun;
        const fClamp = Math.max(0.02, Math.min(0.99, fRaw));
        const useExtrap = fRaw >= 0.04 || (elapsed > 3600 && fRaw >= 0.025);
        let rem;
        if (useExtrap) {
            rem = Math.max(0, (elapsed / fClamp) * (1 - fClamp));
        } else {
            rem = Math.max(0, estimate - elapsed);
        }
        const longSilent = stepType === 'ph' || stepType === 'epw';
        // Extrapolation délirante (q mal lu) → plafond lié au temps déjà passé, pas au plan initial
        if (longSilent && useExtrap && fRaw < 0.22 && rem > elapsed * 2.8) {
            rem = Math.min(rem, elapsed * 2.2);
            remainderUncertain = true;
        }
        if (longSilent && planOverrun > 2.4 && fRaw < 0.18) {
            remainderUnpredictable = true;
            remainderUncertain = true;
        }
        if (rem < 90 && elapsed > Math.max(7200, estimate * 0.45) && fRaw >= 0.06) {
            rem = Math.max(rem, Math.min(
                (elapsed / fClamp) * (1 - fClamp),
                elapsed * 2.5,
            ));
            if (rem > 120) remainderUncertain = true;
        }
        return {
            elapsed,
            remaining: rem,
            progress: fRaw,
            remainderUncertain,
            remainderUnpredictable,
            planOverrun,
            planSec: estimate,
        };
    }

    global.SupraTiming = {
        estimateStep,
        estimateWorkflow,
        formatDuration,
        formatDurationRange,
        startedAtMsFromOutText,
        earliestStartedAtMsFromOutText,
        progressFromOutText,
        remainingSeconds,
        displayRemainingSeconds,
        kProd,
    };
})(typeof window !== 'undefined' ? window : globalThis);

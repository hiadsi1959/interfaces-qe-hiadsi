/* ===========================================================================
 *  supra_app.js — Pilotage interface Supra-QE
 *  Pattern Interface-QE_v1 :
 *      Étape 1 : matériau + pseudos
 *      Étape 2 : workflow Classique ou EPW
 *      Calculs : prérequis externes (vc-relax + scf) + enchaînement WF
 *
 *  Stockage côté serveur :
 *      inputs/<material>/  ← vc-relax.out + scf.out (prérequis, calculs externes)
 *      inputs/<material>/classic/{scf,nscf,ph,q2r,matdyn,fs}.in (+ alpha2f README optionnel)
 *      inputs/<material>/epw/{scf,nscf,ph,epw,fs}.in
 *      inputs/<material>/sscha/{config,pw_forces,sscha}.in
 * ========================================================================= */

(function () {
    'use strict';

    const APP = {
        workflow:  null,         // 'classic' | 'epw' | 'sscha'  (3 WF indépendants)
        material:  '',
        structure: null,
        files:     null,         // { classic:{...}, epw:{...}, sscha:{...} }
        baseDir:   '',           // inputs/<material>
        apiOnline: false,
        cpuCount:  navigator.hardwareConcurrency || 4,
        mainView:  'guide',       // 'guide' | 'calculs' | 'resultats' | 'help'
        prereq:    { relaxDone: false, relaxFound: false, relaxJobDone: false,
                     scfDone: false, relaxPath: '', scfPath: '' },
        scfCtl:    null,          // prefix / outdir / pseudo_dir lus dans le SCF utilisateur
        chain:     null,          // état vérifié des étapes du workflow actif
        chainError: null,
        metalCheck: null,         // classification métal / isolant après SCF
        jobBusy:   false,         // un job QE (ou un lancement) est en cours
        runningStep: null,        // type d'étape en cours d'exécution (scf, nscf, ph, …)
        stepClock: null,          // chrono { type, startedAtMs, estimateSec, progressFrac, startedFromOut? }
        frozenWatch: null,        // { wf, step, until } après diagnostic « calcul figé »
    };

    function getWorkflowPaths() {
        const wf  = APP.workflow || 'classic';
        const mat = APP.material || '';
        const inputMat = (txt('fld_path_inputs', mat ? `inputs/${mat}` : 'inputs') || '').replace(/\/$/, '');
        const workDir  = (txt('fld_path_workflow', `${inputMat}/${wf}`) || `${inputMat}/${wf}`).replace(/\/$/, '');
        const outputDir = (txt('fld_path_outputs', `outputs/${mat}/${wf}`) || `outputs/${mat}/${wf}`).replace(/\/$/, '');
        return { inputMat, workDir, outputDir };
    }

    /** Chemin QE avec barre finale (Unix). */
    function normalizeQeDir(p) {
        if (p == null || !String(p).trim()) return '';
        let s = String(p).trim().replace(/\\/g, '/');
        if (!s.endsWith('/')) s += '/';
        return s;
    }

    function isAbsoluteQePath(p) {
        if (!p) return false;
        const s = String(p).trim().replace(/\\/g, '/');
        return s.startsWith('/') || /^[A-Za-z]:\//.test(s);
    }

    /** Dossier outdir QE : <outputs>/<matériau>/ (absolu via /health). */
    function defaultQeOutdir() {
        const mat = APP.material || 'pw';
        const h = APP._health;
        if (h?.outputs_dir) return normalizeQeDir(`${h.outputs_dir}/${mat}`);
        return normalizeQeDir(`../../../outputs/${mat}/`);
    }

    /** Dossier pseudos (.upf) — absolu via /health, sinon relatif depuis classic|epw/. */
    function defaultQePseudoDir() {
        const h = APP._health;
        if (h?.pseudos_dir) return normalizeQeDir(h.pseudos_dir);
        const rel = h?.pseudo_dir_rel || txt('fld_pseudo_dir', '../../../pseudos/');
        return normalizeQeDir(rel);
    }

    /**
     * outdir / pseudo_dir pour la génération de la suite (NSCF, ph.x, …) :
     * chemins absolus du dépôt quand l'API les expose ; chemins absolus du SCF
     * utilisateur conservés ; chemins relatifs remplacés par les défauts canoniques.
     */
    function resolveQePathsForGeneration() {
        const scfOut = APP.scfCtl?.outdir;
        const scfPse = APP.scfCtl?.pseudo_dir;
        return {
            outdir: isAbsoluteQePath(scfOut) ? normalizeQeDir(scfOut) : defaultQeOutdir(),
            pseudo_dir: isAbsoluteQePath(scfPse) ? normalizeQeDir(scfPse) : defaultQePseudoDir(),
        };
    }

    /** Chemin API relatif du outdir QE (outputs/&lt;mat&gt;/…) pour ph.x / pp.py / epw.x. */
    function qeOutdirApiRel() {
        const rel = absToApiRel(resolveQePathsForGeneration().outdir);
        if (rel) return rel.replace(/\/+$/, '');
        const mat = APP.material || 'pw';
        const wf = APP.workflow || 'classic';
        return (txt('fld_path_outputs', `outputs/${mat}/${wf}`) || `outputs/${mat}`)
            .replace(/\/+$/, '')
            .replace(/\/(classic|epw|sscha)$/, '') || `outputs/${mat}`;
    }

    /**
     * Répertoire de travail QE pour l'étape : en WF2, ph.x et epw.x tournent
     * dans le outdir ( _ph0/, *.dyn*, save/ ) — pas dans inputs/…/epw/.
     */
    function stepExecutionWorkdir(stepId, wf = APP.workflow) {
        const paths = getWorkflowPaths();
        if (wf === 'epw' && (stepId === 'ph' || stepId === 'epw')) {
            return qeOutdirApiRel();
        }
        return paths.workDir;
    }

    /**
     * Scroll prudent (Chrome scrollIntoView(block:'start') fait souvent
     * disparaître la barre d'onglets et donne l'impression d'un bug d'affichage).
     */
    function scrollToView(target, opts = {}) {
        const el = typeof target === 'string' ? $(target) : target;
        if (!el) return;
        const navH = ($('.app-nav-bar')?.offsetHeight || 72) + 12;
        const r = el.getBoundingClientRect();
        const vh = window.innerHeight || document.documentElement.clientHeight;
        const fullyVisible = r.top >= navH && r.bottom <= vh - 8;
        if (fullyVisible && !opts.force) return;
        const block = opts.block || 'nearest';
        try {
            el.scrollIntoView({ behavior: opts.behavior || 'smooth', block, inline: 'nearest' });
        } catch (_) {
            el.scrollIntoView(true);
        }
        // Si Chrome a trop remonté : garder la barre d'onglets dans le viewport
        requestAnimationFrame(() => {
            const nav = $('.app-nav-bar');
            if (!nav) return;
            const nr = nav.getBoundingClientRect();
            if (nr.top < 0) {
                window.scrollBy({ top: nr.top - 4, left: 0, behavior: 'auto' });
            }
        });
    }

    function getMaterialBaseDir() {
        const mat = APP.material || '';
        return (txt('fld_path_inputs', mat ? `inputs/${mat}` : 'inputs') || '').replace(/\/$/, '');
    }

    function syncMaterialPathField() {
        if (!APP.material) return;
        const fi = $('#fld_path_inputs');
        const path = `inputs/${APP.material}`;
        if (fi && !fi.dataset.touched) fi.value = path;
        APP.baseDir = getMaterialBaseDir();
        updatePrereqExpectedLabels();
    }

    function updatePrereqExpectedLabels() {
        const mat = APP.material || 'Materiau';
        const base = getMaterialBaseDir() || `inputs/${mat}`;
        const set = (id, t) => { const el = $(id); if (el) el.textContent = t; };
        set('#prereqDefaultDir', `${base}/`);
        set('#prereqExpectedRelax', `${mat}.vc-relax.out`);
        set('#prereqExpectedScf', `${mat}.scf.out`);
        set('#prereqExpectedScfAlt', `${mat}.scf_prereq.out`);
    }

    function updatePathFields() {
        if (!APP.material || !APP.workflow) return;
        syncMaterialPathField();
        const inputMat = APP.baseDir || `inputs/${APP.material}`;
        const fw = $('#fld_path_workflow');
        const fo = $('#fld_path_outputs');
        // Ne pas écraser un chemin saisi à la main (autre PC / autre dossier).
        if (fw && !fw.dataset.touched) fw.value = `${inputMat}/${APP.workflow}`;
        if (fo && !fo.dataset.touched) fo.value = `outputs/${APP.material}/${APP.workflow}`;
    }

    function invalidateWorkflowFiles() {
        APP.files = null;
        // Le caractère métallique du SCF est partagé entre WF1 et WF2.
    }

    function renderWorkflowBanner() {
        const box = $('#wfActiveBanner');
        if (!box) return;
        if (APP.mainView === 'resultats' || !APP.workflow) {
            box.style.display = 'none';
            return;
        }
        const L = WORKFLOW_LABEL[APP.workflow];
        const n = calcStepsForRun(APP.workflow).length;
        box.style.display = 'block';
        box.innerHTML = `
            <div class="pipeline-block ${APP.workflow}" style="padding:14px 18px; margin:0;">
                <strong style="color:${L.stepColor};">${L.id} — ${L.name}</strong>
                <span class="muted"> — ${n} programme(s) · dossier <code>inputs/${APP.material}/${APP.workflow}/</code></span>
                ${APP.workflow === 'sscha' ? '<br><span class="muted" style="font-size:0.9em;">Exécution automatique SSCHA : intégration API en cours.</span>' : ''}
            </div>`;
    }

    /* ====================================================================
     *  Définition des programmes par workflow (style Interface-QE_v1)
     * ==================================================================== */
    const CALCS = {
        classic: [
            { type:'scf',     num:1,   icon:'🌌', prog:'pw.x',     short:'SCF',  nom:'SCF métallique',
              section:'scf',
              desc:'Densité électronique de référence dans le outdir du SCF (prefix.save) — le NSCF et ph.x doivent lire exactement le même chemin.',
              reco:['Smearing MV, degauss ≈ 0.02 Ry','Grille k ≈ 12 × 12 × 12','Crée outdir utilisé par NSCF et ph.x'] },
            { type:'nscf',    num:2,   icon:'⚡', prog:'pw.x',     short:'NSCF', nom:'NSCF dense',
              section:'nscf',
              desc:'Cartographie dense de la surface de Fermi (k_nscf très dense).',
              reco:['Grille k ≥ 16 × 16 × 16 (24³ recommandé)','la2F = .true. (auto)','diagonalization = cg','Ratio k/q doit être entier'] },
            { type:'ph',      num:3,   icon:'🎵', prog:'ph.x',     short:'ph.x', nom:'Phonons + e-p',
              section:'phonon',
              desc:'DFPT : matrice dynamique + éléments de matrice du couplage électron-phonon.',
              reco:['Grille q ≈ 4 × 4 × 4','tr2_ph = 1.0d-12','electron_phonon = interpolated','Calcul le plus long'] },
            { type:'q2r',     num:'4a', icon:'🔄', prog:'q2r.x',    short:'q2r.x', nom:'q2r.x — IFC',
              section:'matdyn',
              desc:'Transforme la matrice dynamique en constantes de force en espace réel.',
              reco:['Très rapide (< 1 min)','Utilise les fichiers dyn produits par ph.x','Aucun paramètre critique'] },
            { type:'matdyn',  num:'4b', icon:'🎯', prog:'matdyn.x', short:'matdyn.x', nom:'matdyn.x → α²F, λ',
              section:'matdyn',
              desc:'DOS phononique + α²F(ω) / λ si la2F=.true. (QE 7). μ* et Tc : onglet Résultats.',
              reco:['la2F = .true.','grille q DOS dense (nk1–3)','μ* et Tc dans Résultats (pas dans matdyn.in)'] },
        ],
        // Ordre canonique EPW (docs.epw-code.org) : scf → ph (dvscf) → save/ → nscf → epw
        epw: [
            { type:'scf',  num:1, icon:'🌌', prog:'pw.x', short:'SCF', nom:'SCF métallique',
              section:'scf',
              desc:'Densité électronique de référence dans le outdir du SCF (prefix.save) — base de ph.x puis du NSCF coarse.',
              reco:['Smearing MV, degauss ≈ 0.02 Ry','Grille k ≈ 8 × 8 × 8','Doit tourner avant ph.x'] },
            { type:'ph',   num:2, icon:'🎵', prog:'ph.x', short:'ph.x', nom:'Phonons + dvscf (avant NSCF)',
              section:'phonon',
              desc:'DFPT sur grille q coarse ; sauvegarde des matrices dynamiques et du potentiel perturbé lus ensuite par epw.x.',
              reco:['Grille q ≈ 4 × 4 × 4','fildvscf sauvegardé (.dvscf)','fildyn sauvegardé (.dyn)','À lancer AVANT le NSCF (le NSCF écrase les fonctions d\'onde)'] },
            { type:'nscf', num:3, icon:'⚡', prog:'pw.x', short:'NSCF', nom:'NSCF coarse + nbnd',
              section:'nscf',
              desc:'Grille k coarse uniforme et nbnd élevé pour la wannierisation — après ph.x et le regroupement dans save/.',
              reco:['Grille k modérée (8³ ou 6³)','nbnd élevé obligatoire (≥ 30 pour 1 espèce)','Pas de la2F','Doit matcher nkc de epw.in'] },
            { type:'epw',  num:4, icon:'⚛️', prog:'epw.x', short:'epw.x', nom:'epw.x → Tᶜ + Δ',
              section:'epw',
              desc:'Wannierisation + Fourier des e-p + interpolation grille géante + Éliashberg.',
              reco:['nbndsub ≈ orbitales actives','Fenêtres dis_win, dis_froz ajustées','μc = 0.10','Grilles fines 40 × 40 × 40','Sortie Tᶜ + Δ(T)'] },
        ],
        sscha: [
            { type:'config',    num:1, icon:'🎲', prog:'script',  short:'configs', nom:'Générateur de configurations',
              section:'sscha_config',
              desc:'Crée N supercellules déplacées aléatoirement (base anharmonique).',
              reco:['64–128 configurations typiques','Amplitude déplacement ~0.05–0.1 Å','Supercellule 2×2×2 ou plus'] },
            { type:'pw_forces', num:2, icon:'💪', prog:'pw.x',    short:'forces', nom:'pw.x — forces (boucle)',
              section:'sscha_pw',
              desc:'SCF + forces atomiques (tprnfor) sur chaque configuration générée.',
              reco:['tprnfor = .true.','Grille k adaptée à la supercellule','Parallélisable MPI sur les configs'] },
            { type:'sscha',     num:3, icon:'🌡️', prog:'SSCHA',  short:'SSCHA', nom:'SSCHA → phonons corrigés',
              section:'sscha_module',
              desc:'Minimisation de l\'énergie libre · fréquences phonons corrigées · α²F(ω).',
              reco:['Température cible (K)','Convergence itérative','μ* pour estimation Tᶜ post-SSCHA'] },
        ],
    };

    const WORKFLOW_LABEL = {
        classic: { name: 'Workflow Classique', letter: 'A', color: 'var(--supra)',  stepColor: 'var(--supra-dark)',  id: 'WF1' },
        epw:     { name: 'Workflow EPW',       letter: 'B', color: 'var(--epw)',    stepColor: 'var(--epw-dark)',    id: 'WF2' },
        sscha:   { name: 'Workflow SSCHA',     letter: 'C', color: 'var(--sscha)', stepColor: 'var(--sscha-dark)', id: 'WF3' },
    };

    const WF_CSS = { classic: 'classic', epw: 'epw', sscha: 'sscha' };
    function wfCss(wf) { return WF_CSS[wf] || wf; }

    function branchTagVisible(wf, tag) {
        if (!wf || !tag) return false;
        if (tag === 'sscha' && window.SupraConfig && !window.SupraConfig.ENABLE_SSCHA) return false;
        if (tag === 'harmonic') return wf === 'classic' || wf === 'epw';
        return tag === wf;
    }

    /** Étapes de la chaîne automatique (les étapes optionnelles restent manuelles). */
    function calcStepsForRun(wf) {
        if (!wf || !CALCS[wf]) return [];
        return CALCS[wf].filter(c => !c.optional);
    }

    function calcByType(wf, type) {
        return (CALCS[wf] || []).find(c => c.type === type) || null;
    }

    /* ====================================================================
     *  Chaîne de calculs : dépendances et vérification pas à pas
     *
     *  Chaque étape n'est lançable que si les étapes amont sont terminées
     *  (« JOB DONE » dans leur .out) et si leurs fichiers intermédiaires
     *  attendus existent réellement dans le dossier du workflow.
     * ==================================================================== */
    const STEP_CHAIN = {
        classic: {
            scf:     { deps: [] },
            nscf:    { deps: ['scf'],    needs: ['pwsave'] },
            ph:      { deps: ['nscf'] },
            q2r:     { deps: ['ph'],     needs: ['fildyn'] },
            matdyn:  { deps: ['q2r'],    needs: ['flfrc'] },
        },
        epw: {
            scf:  { deps: [] },
            ph:   { deps: ['scf'], needs: ['pwsave'] },
            nscf: { deps: ['ph'],  needs: ['fildyn'] },
            epw:  { deps: ['nscf'], needs: ['epwSave'] },
        },
    };

    function absToApiRel(abs) {
        const s = String(abs || '').replace(/\\/g, '/').replace(/\/+$/, '');
        if (!s) return '';
        const h = APP._health || {};
        const pairs = [
            [h.outputs_dir, 'outputs'],
            [h.inputs_dir, 'inputs'],
            [h.pseudos_dir, 'pseudos'],
        ];
        for (const [root, alias] of pairs) {
            if (!root) continue;
            const r = String(root).replace(/\/+$/, '');
            if (s === r) return alias;
            if (s.startsWith(r + '/')) return alias + s.slice(r.length);
        }
        return '';
    }

    /** Chemin API de prefix.save/data-file-schema.xml pour un outdir QE. */
    function qeSaveXmlApiPath(outdir, prefix) {
        const xml = `${prefix}.save/data-file-schema.xml`;
        let d = String(outdir || '').replace(/['"]/g, '').trim().replace(/\/+$/, '');
        if (!d) return '';
        if (d.startsWith('/')) {
            const rel = absToApiRel(d);
            return rel ? `${rel.replace(/\/+$/, '')}/${xml}` : '';
        }
        d = d.replace(/^\.\//, '');
        return `${getWorkflowPaths().workDir}/${d}/${xml}`;
    }

    /** Fichiers intermédiaires attendus, tels que nommés dans les inputs générés. */
    function chainArtifact(key) {
        const wd = getWorkflowPaths().workDir;
        switch (key) {
            case 'pwsave': {
                const prefix = APP.scfCtl?.prefix || APP.material || 'pw';
                const nscfTxt = APP.files?.[APP.workflow]?.nscf?.content;
                const scfTxt  = APP.files?.[APP.workflow]?.scf?.content;
                const outdir = APP.scfCtl?.outdir
                    || parseQeNamelistStr(nscfTxt, 'outdir')
                    || parseQeNamelistStr(scfTxt, 'outdir')
                    || defaultQeOutdir();
                const path = qeSaveXmlApiPath(outdir, prefix);
                const extras = [
                    `${wd}/${prefix}_outdir/${prefix}.save/data-file-schema.xml`,
                    `${wd}/${prefix}.save/data-file-schema.xml`,
                ].filter(p => p && p !== path);
                return {
                    path, extras,
                    label: `densité SCF <code>${prefix}.save</code> dans <code>${outdir}</code>`,
                    from: 'scf',
                    fix: 'Relance le SCF (étape 1) avec le même prefix/outdir que le NSCF. ' +
                         'Un ancien SCF a pu écrire dans <code>./Nb_outdir/</code> alors que l\'input pointe maintenant ailleurs.',
                };
            }
            case 'fildyn': {
                const phTxt = APP.files?.[APP.workflow]?.ph?.content || '';
                const fromPh = parseQeNamelistStr(phTxt, 'fildyn');
                const prefix = APP.scfCtl?.prefix || APP.material || 'mat';
                const classic = txt('fld_fildyn', 'matdyn') || 'matdyn';
                const base = fromPh
                    || (APP.workflow === 'epw' ? `${prefix}.dyn` : classic);
                const outRel = qeOutdirApiRel();
                const primary = APP.workflow === 'epw'
                    ? `${outRel}/${base}0`
                    : `${wd}/${base}0`;
                const extras = APP.workflow === 'epw'
                    ? [`${wd}/${base}0`, `${outRel}/${prefix}.dyn1`]
                    : [`${wd}/${classic}0`];
                return {
                    path: primary,
                    extras: extras.filter(p => p && p !== primary),
                    label: APP.workflow === 'epw'
                        ? `matrices dynamiques <code>${base}0</code> dans <code>${outRel}/</code>`
                        : `matrices dynamiques <code>${base}0</code>`,
                    from: 'ph',
                    fix: APP.workflow === 'epw'
                        ? `Relance ph.x (cwd = <code>${outRel}/</code>) : dyn et <code>_ph0/</code> doivent être dans le outdir.`
                        : 'Relance ph.x : les fichiers dyn sont produits dans le dossier du workflow.',
                };
            }
            case 'flfrc': {
                const base = txt('fld_flfrc', 'ifc.fc') || 'ifc.fc';
                return { path: `${wd}/${base}`, label: `constantes de force <code>${base}</code>`,
                         from: 'q2r', fix: 'Relance q2r.x pour reconstruire les IFC en espace réel.' };
            }
            case 'fila2F': {
                const base = txt('fld_fila2F', 'a2F.dat') || 'a2F.dat';
                return { path: `${wd}/${base}`, label: `α²F brut <code>${base}</code>`,
                         from: 'matdyn', fix: 'Relance matdyn.x (la2F = .true.) pour écrire α²F.' };
            }
            case 'epwSave': {
                const outRel = qeOutdirApiRel();
                return {
                    path: `${outRel}/save`, dir: true,
                    label: `dossier <code>${outRel}/save/</code> (dvscf + dyn regroupés)`,
                    from: 'ph', manual: false,
                    fix: `Regroupe ph.x avec <code>pp.py</code> dans <code>${outRel}/</code> `
                        + `(automatique après ph.x si l\'API est en ligne, ou 🖥️ Terminal étape ph / epw).`,
                };
            }
            default:
                return null;
        }
    }

    /** Chemin où l'interface écrit la sortie de l'étape. */
    function stepOutPath(step) {
        if (!APP.material) return '';
        return `${getWorkflowPaths().outputDir}/${APP.material}.${step}.out`;
    }

    /**
     * Emplacements acceptés pour la sortie d'une étape : celui utilisé par
     * l'interface, mais aussi le dossier de calcul lui-même — un `.out` produit
     * à la main dans ce dossier doit compter comme étape faite, sinon la chaîne
     * bloquerait un travail déjà réalisé hors interface.
     */
    function siblingWorkflow(wf = APP.workflow) {
        if (wf === 'classic') return 'epw';
        if (wf === 'epw') return 'classic';
        return null;
    }

    function stepOutCandidates(step) {
        if (!APP.material) return [];
        const paths = getWorkflowPaths();
        const name = `${APP.material}.${step}.out`;
        const out = [`${paths.outputDir}/${name}`, `${paths.workDir}/${name}`];
        // SCF unique : les deux workflows partent du même calcul.
        if (step === 'scf') {
            const other = siblingWorkflow();
            const mat = APP.material;
            if (other) {
                out.push(`outputs/${mat}/${other}/${name}`);
                out.push(`inputs/${mat}/${other}/${name}`);
            }
            out.push(`outputs/${mat}/${name}`);
            out.push(`inputs/${mat}/${name}`);
        }
        return [...new Set(out.filter(Boolean))];
    }

    /**
     * Interroge l'API une seule fois pour connaître l'état réel de toutes les
     * étapes du workflow actif (sortie présente, JOB DONE, erreur QE) et de
     * leurs fichiers intermédiaires.
     *
     * Retourne null si l'état ne peut pas être établi (API hors-ligne ou plus
     * ancienne que /api/file/stat) : dans ce cas la chaîne ne bloque rien.
     */
    async function inspectChain(wf = APP.workflow) {
        const chain = STEP_CHAIN[wf];
        APP.chainError = null;
        if (!wf || !chain || !APP.material || !APP.apiOnline) {
            APP.chain = null;
            return null;
        }

        const steps = Object.keys(chain);
        const paths = [];
        steps.forEach(s => stepOutCandidates(s).forEach(p => paths.push(p)));
        const artifacts = {};
        steps.forEach(s => (chain[s].needs || []).forEach(key => {
            if (artifacts[key]) return;
            const a = chainArtifact(key);
            if (a) {
                artifacts[key] = a;
                if (a.path) paths.push(a.path);
                (a.extras || []).forEach(p => { if (p) paths.push(p); });
            }
        }));

        const r = await SupraAPI.statFiles(paths);
        if (!r?.ok) {
            APP.chain = null;
            APP.chainError = r?.status === 404
                ? "L'API en cours d'exécution est antérieure à cette interface (endpoint /api/file/stat absent). Redémarre-la avec ./DEMARRER.sh pour activer la vérification pas à pas."
                : `Vérification impossible : ${r?.error || 'API injoignable'}.`;
            return null;
        }
        const stat = r.results || {};
        const wfPaths = getWorkflowPaths();

        const watchOut = [];
        steps.forEach(s => {
            const infos = stepOutCandidates(s).map(p => ({ path: p, ...(stat[p] || {}) }));
            if (infos.find(i => i.job_done)) return;
            stepOutCandidates(s).forEach(p => watchOut.push(p));
        });
        const watchProg = [...new Set(steps.map(s => STEP_QE_PROGRAM[s]).filter(Boolean))];
        let hostOut = {};
        let hostProg = {};
        const rr = await SupraAPI.qeRunning({ outputs: watchOut, programs: watchProg });
        const hostProbeOk = !!rr?.ok;
        if (hostProbeOk) {
            hostOut = rr.outputs || {};
            hostProg = rr.programs || {};
        }

        const state = {};
        const nowSec = Date.now() / 1000;
        steps.forEach(s => {
            const infos = stepOutCandidates(s).map(p => ({ path: p, ...(stat[p] || {}) }));
            const done = infos.find(i => i.job_done);
            const present = infos.find(i => i.exists);
            const localDone = infos.find(i => i.job_done && (
                i.path === `${wfPaths.outputDir}/${APP.material}.${s}.out`
                || i.path === `${wfPaths.workDir}/${APP.material}.${s}.out`));
            const hasErr = !!present?.has_error;
            const ageSec = present?.mtime ? nowSec - present.mtime : Infinity;
            const hostRun = stepHostRunning(s, { present, done, hostOut, hostProg });
            const logStale = present && !done && ageSec >= CHAIN_STALE_SEC;
            const logQuiet = logStale && hostRun;
            const abandoned = logStale && !hostRun && hostProbeOk;
            const logInactive = logStale && !hostRun && !hostProbeOk;
            const failed = !done && !!present && (hasErr || abandoned);
            const running = !done && !!present && !hasErr && !failed
                && (hostRun || APP.runningStep === s || (present.size > 0 && ageSec < CHAIN_STALE_SEC));
            state[s] = {
                out: done?.path || present?.path || stepOutPath(s),
                exists: !!present,
                done: !!done,
                shared: !!(done && !localDone),
                has_error: hasErr,
                running,
                host_running: hostRun,
                log_quiet: logQuiet,
                log_inactive: logInactive,
                out_age_sec: Number.isFinite(ageSec) ? ageSec : null,
                failed,
                size: present?.size || 0,
                mtime: present?.mtime || 0,
            };
        });
        const artifactState = {};
        Object.entries(artifacts).forEach(([key, a]) => {
            const info = stat[a.path] || {};
            const elsewhere = (a.extras || []).find(p => p && stat[p]?.exists) || '';
            const exists = !!info.exists || (key === 'fildyn' && !!elsewhere);
            artifactState[key] = { ...a, exists, elsewhere };
        });

        APP.chain = { wf, steps: state, artifacts: artifactState, host_probe: hostProbeOk, at: Date.now() };
        await enrichChainResumable();
        return APP.chain;
    }

    /** Détecte si une étape interrompue peut reprendre (recover ph.x / restart pw.x). */
    async function enrichChainResumable() {
        if (!APP.chain || !APP.apiOnline || !APP.material) return;
        const prefix = APP.scfCtl?.prefix || APP.material;
        const outRel = qeOutdirApiRel();
        const paths = [];
        const phCtrl = `${outRel}/_ph0/${prefix}.phsave/control_ph.xml`;
        paths.push(phCtrl);
        const pwXml = qeSaveXmlApiPath(resolveQePathsForGeneration().outdir, prefix);
        if (pwXml) paths.push(pwXml);

        const r = await SupraAPI.statFiles(paths);
        Object.values(APP.chain.steps || {}).forEach(st => {
            if (st) {
                st.resumable = false;
                st.resume_kind = null;
            }
        });
        if (!r?.ok) return;

        const markPh = r.results?.[phCtrl]?.exists;
        const markPw = pwXml && r.results?.[pwXml]?.exists;

        ['ph', 'scf', 'nscf'].forEach(step => {
            const st = APP.chain.steps?.[step];
            if (!st || st.done || st.host_running) return;
            if (APP.runningStep === step) return;
            const halted = st.failed || st.log_inactive
                || (st.exists && !st.done && !st.running);
            if (!halted) return;
            if (step === 'ph' && markPh) {
                st.resumable = true;
                st.resume_kind = 'ph_recover';
            }
            if ((step === 'scf' || step === 'nscf') && markPw) {
                st.resumable = true;
                st.resume_kind = 'pw_restart';
            }
        });
    }

    function patchInputForResume(stepId, content) {
        if (!content) return content;
        let out = String(content);
        if (stepId === 'ph') {
            if (/^\s*recover\s*=/im.test(out)) {
                out = out.replace(/^\s*recover\s*=\s*\.false\./im, '    recover      = .true.');
            } else {
                out = out.replace(/(&INPUTPH[\s\S]*?)(\n\s*\/)/m, '$1\n    recover      = .true.$2');
            }
            return out;
        }
        if (stepId === 'scf' || stepId === 'nscf') {
            if (/restart_mode\s*=/i.test(out)) {
                out = out.replace(/restart_mode\s*=\s*'from_scratch'/i, "restart_mode = 'restart'");
            } else if (/&CONTROL/i.test(out)) {
                out = out.replace(/(&CONTROL\s*\n)/i, "$1    restart_mode = 'restart'\n");
            }
        }
        return out;
    }

    function resumeStepLabel(stepId) {
        if (stepId === 'ph') return 'recover=.true. (ph.x reprend les q-points restants)';
        if (stepId === 'scf' || stepId === 'nscf') return "restart_mode='restart' (pw.x reprend depuis prefix.save)";
        return 'reprise QE';
    }

    /** Blocages empêchant de lancer `step` : étapes amont et fichiers manquants. */
    function chainBlockers(step, wf = APP.workflow, chainState = APP.chain) {
        const spec = STEP_CHAIN[wf]?.[step];
        if (!spec) return [];
        if (!chainState || chainState.wf !== wf) {
            // Fail-closed si l'API est en ligne mais /stat a échoué
            if (APP.apiOnline && APP.chainError) {
                return [{
                    kind: 'chain',
                    label: 'vérification de la chaîne indisponible',
                    detail: APP.chainError,
                }];
            }
            return [];
        }
        const blockers = [];
        const calc = calcByType(wf, step);
        if (calc && binaryAvailable(calc.prog) === false) {
            blockers.push({
                kind: 'binary', manual: true,
                label: `binaire <code>${calc.prog}</code> introuvable`,
                detail: 'installe-le ou définis <code>QE_BIN_DIR</code>, ou lance cette étape via 🖥️ Terminal sur une machine qui l\'a.',
            });
        }
        (spec.deps || []).forEach(dep => {
            const st = chainState.steps?.[dep];
            if (st && st.done) return;
            const c = calcByType(wf, dep);
            blockers.push({
                kind: 'step', step: dep,
                label: `étape ${c?.num ?? ''} — ${c?.nom || dep} (${c?.prog || ''})`,
                detail: st?.running
                    ? `calcul en cours — <code>${st.out}</code> (pas encore « JOB DONE »)`
                    : st?.failed
                    ? `sortie incomplète ou en erreur : <code>${st.out}</code>`
                    : `aucune sortie terminée : <code>${st?.out || stepOutPath(dep)}</code>`,
            });
        });
        (spec.needs || []).forEach(key => {
            const a = chainState.artifacts?.[key];
            if (!a || a.exists) return;
            const detail = a.elsewhere
                ? `Densité trouvée dans <code>${a.elsewhere}</code> mais le NSCF lit <code>${a.path}</code>. Relance le SCF (étape 1) pour réécrire <code>prefix.save</code> au bon endroit.`
                : a.fix;
            blockers.push({ kind: 'file', label: a.label, detail, manual: !!a.manual });
        });
        if (step !== 'scf' && APP.metalCheck?.should_stop) {
            const gap = APP.metalCheck.gap_eV;
            const gapTxt = Number.isFinite(gap) ? `Eg ≈ ${gap.toFixed(3)} eV` : 'gap électronique';
            blockers.push({
                kind: 'metal',
                label: 'matériau non métallique (pas un conducteur)',
                detail: `${gapTxt} — arrêter nscf / phonons / EPW : le couplage e–p et Tc n'ont pas de sens. `
                    + 'Même si des tests ultérieurs ont déjà été générés ou lancés.',
            });
        }
        return blockers;
    }

    /** Sans écriture depuis N s, une sortie sans JOB DONE est considérée abandonnée
     *  (sauf si l'API voit encore le processus ou le .out ouvert). */
    const CHAIN_STALE_SEC = 15 * 60;

    const STEP_QE_PROGRAM = {
        scf: 'pw.x', nscf: 'pw.x', ph: 'ph.x', q2r: 'q2r.x', matdyn: 'matdyn.x',
        epw: 'epw.x', pw_forces: 'pw.x',
    };

    function stepHostRunning(s, { present, done, hostOut, hostProg }) {
        if (done) return false;
        if (APP.runningStep === s) return true;
        if (stepOutCandidates(s).some(p => hostOut[p]?.alive)) return true;
        const prog = STEP_QE_PROGRAM[s];
        if (prog && present && (hostProg[prog]?.alive)) return true;
        return false;
    }

    /** Surveillance utilisateur après diagnostic « calcul figé » (force l’affichage actif). */
    const FROZEN_WATCH_MS = 48 * 3600 * 1000;

    function frozenWatchActive(step, wf = APP.workflow) {
        const w = APP.frozenWatch;
        if (!w || w.wf !== wf || w.step !== step) return false;
        if (Date.now() > (w.until || 0)) {
            APP.frozenWatch = null;
            return false;
        }
        const st = APP.chain?.steps?.[step];
        if (st?.done) {
            APP.frozenWatch = null;
            return false;
        }
        return true;
    }

    function activateFrozenWatch(step, wf = APP.workflow) {
        APP.frozenWatch = { wf, step, until: Date.now() + FROZEN_WATCH_MS, at: Date.now() };
    }

    function applyFrozenWatchUi(stepType, calc) {
        activateFrozenWatch(stepType);
        notifyUser(
            `Surveillance activée — ${calc?.short || calc?.nom || stepType} `
            + '(refresh ~15 s, badge « surveillance · actif »). Ne relance pas ph.x en parallèle.',
            'success',
        );
        refreshChainStatus().then(() => syncPipelineFromChain());
    }

    function frozenWatchFooterButtons(stepType, calc, { includeClose = true } = {}) {
        const btns = [
            {
                label: '✅ Activer la surveillance',
                cls: 'btn-success',
                onClick: () => {
                    closeModal();
                    applyFrozenWatchUi(stepType, calc);
                },
            },
            {
                label: '📊 Suivi live (.out)',
                cls: 'btn-primary',
                onClick: () => { closeModal(); suiviModal(calc); },
            },
        ];
        if (includeClose) {
            btns.push({ label: 'Fermer', cls: 'btn-secondary', onClick: closeModal });
        }
        return btns;
    }

    /** État affiché : done | running | running_quiet | log_inactive | failed | ready | blocked */
    function stepState(step, wf = APP.workflow, chainState = APP.chain) {
        const st = chainState?.steps?.[step];
        if (st?.done) return 'done';
        if (APP.runningStep === step && wf === APP.workflow) return 'running';
        if (st?.log_quiet && st?.running) return 'running_quiet';
        if (st?.log_inactive) {
            if (frozenWatchActive(step, wf)) return 'running_quiet';
            return 'log_inactive';
        }
        if (st?.running) return 'running';
        if (st?.resumable && !st.done && !st.host_running) return 'interrupted';
        if (st?.failed) return 'failed';
        return chainBlockers(step, wf, chainState).length ? 'blocked' : 'ready';
    }

    const FROZEN_DIAGNOSE_STATES = new Set([
        'log_inactive', 'running_quiet', 'interrupted', 'failed', 'running',
    ]);

    /** Sonde hôte + fichiers pour une étape (diagnostic « calcul figé »). */
    async function probeStepHost(stepType, wf = APP.workflow) {
        await inspectChain();
        const st = APP.chain?.steps?.[stepType];
        const outs = stepOutCandidates(stepType);
        const prog = STEP_QE_PROGRAM[stepType];
        let hostOut = {};
        let hostProg = {};
        let hostProbeOk = false;
        const rr = await SupraAPI.qeRunning({ outputs: outs, programs: prog ? [prog] : [] });
        if (rr?.ok) {
            hostProbeOk = true;
            hostOut = rr.outputs || {};
            hostProg = rr.programs || {};
        }
        const aliveOut = outs.some(p => hostOut[p]?.alive);
        const aliveProg = prog && hostProg[prog]?.alive;
        const alive = !!(aliveOut || aliveProg || st?.host_running || APP.runningStep === stepType);
        const pids = [];
        outs.forEach(p => { (hostOut[p]?.pids || []).forEach(id => pids.push(id)); });
        if (prog && hostProg[prog]?.pids) pids.push(...hostProg[prog].pids);
        const aliveFinal = !!(alive || (prog && hostProg[prog]?.pids?.length));
        return {
            step: stepType,
            wf,
            st: st || {},
            alive: aliveFinal,
            hostProbeOk,
            pids: [...new Set(pids)],
            multi_pids: (hostProg[prog]?.pids || []).length > 1,
            outs,
            prog,
            state: stepState(stepType, wf),
            resumable: !!st?.resumable,
            resume_kind: st?.resume_kind,
            job_done: !!st?.done,
        };
    }

    async function openFrozenDiagnoseModal(stepType) {
        const calc = calcByType(APP.workflow, stepType);
        if (!calc) return;
        const title = `Calcul figé ? — ${calc.num} · ${calc.short || calc.nom}`;
        notifyUser('Diagnostic : interrogation du PC de calcul…', 'info');
        const probe = await probeStepHost(stepType);
        const st = probe.st;
        const outPath = st.out || stepOutPath(stepType);
        const ageMin = st.out_age_sec != null && Number.isFinite(st.out_age_sec)
            ? Math.max(1, Math.round(st.out_age_sec / 60)) : null;
        const pidTxt = probe.pids.length
            ? probe.pids.map(p => `<code>${p}</code>`).join(', ')
            : '<em>aucun PID détecté</em>';
        const uiState = stepState(stepType);
        const journalQuiet = stepStateIsActive(uiState) || uiState === 'interrupted';
        const apiStale = !probe.hostProbeOk;
        let apiNote = '';
        if (apiStale) {
            apiNote = `<div class="alert alert-warning"><strong>API sans détection de processus</strong> `
                + `(endpoint <code>/api/qe/running</code> absent ou hors ligne). `
                + `Sur le PC de calcul : <code>./ARRETER.sh && ./DEMARRER.sh</code>, puis ↻ Revérifier. `
                + `<strong>✅ Activer la surveillance</strong> fonctionne quand même (sans PID).</div>`;
        }

        let verdict = '';
        let footer = frozenWatchFooterButtons(stepType, calc);

        if (probe.job_done) {
            verdict = `<div class="alert alert-success">✅ <strong>JOB DONE</strong> détecté — l'étape est terminée. `
                + `Clique <strong>↻ Revérifier</strong> si le badge n'est pas à jour.</div>`;
            footer = [{ label: 'Fermer', cls: 'btn-secondary', onClick: closeModal }];
        } else if (probe.alive) {
            const multiWarn = probe.multi_pids || probe.pids.length > 1
                ? `<div class="alert alert-error"><strong>⚠️ Plusieurs ${escapeHtml(probe.prog || 'ph.x')} en parallèle</strong> `
                  + `(PID : ${pidTxt}). Ne relance pas — arrête le doublon le plus récent si besoin.</div>`
                : '';
            verdict = multiWarn + `<div class="alert alert-success">✅ <strong>Le calcul continue</strong> `
                + `(PID : ${pidTxt}). Journal silencieux possible — normal pour ph.x.</div>`
                + `<p><strong>Ne pas</strong> utiliser « Relancer / restart ».</p>`;
            footer = frozenWatchFooterButtons(stepType, calc);
        } else if (journalQuiet || apiStale) {
            verdict = apiNote + `<div class="alert alert-info">`
                + `<strong>Journal figé ou calcul long</strong> — si <code>ph.x</code> tourne encore `
                + `(vérifie <code>pgrep -af ph.x</code>), choisis d'abord `
                + `<strong>✅ Activer la surveillance</strong> et attends. `
                + `« Reprendre / Relancer » seulement si <em>aucun</em> processus ph.x.</div>`;
            footer = [
                ...frozenWatchFooterButtons(stepType, calc, { includeClose: false }),
                {
                    label: '♻️ Reprendre (si ph.x arrêté)',
                    cls: 'btn-secondary',
                    onClick: () => { closeModal(); runResumeOne(calc); },
                },
                {
                    label: '🚀 Relancer (dernier recours)',
                    cls: 'btn-secondary',
                    onClick: () => {
                        closeModal();
                        if (confirm(
                            'Relancer uniquement si AUCUN ph.x ne tourne (pgrep -af ph.x).\n\n'
                            + 'Sinon : Activer la surveillance.\n\nContinuer ?'
                        )) runOne(calc, { force: true });
                    },
                },
                { label: 'Fermer', cls: 'btn-secondary', onClick: closeModal },
            ];
        } else if (probe.resumable) {
            verdict = `<div class="alert alert-warning">⏸ Fichiers de <strong>reprise</strong> présents `
                + `(${escapeHtml(resumeStepLabel(stepType))}) — à utiliser si le job est vraiment arrêté.</div>`;
            footer = [
                ...frozenWatchFooterButtons(stepType, calc, { includeClose: false }),
                {
                    label: '♻️ Reprendre',
                    cls: 'btn-warning',
                    onClick: () => { closeModal(); runResumeOne(calc); },
                },
                {
                    label: '🚀 Relancer from scratch',
                    cls: 'btn-secondary',
                    onClick: () => {
                        closeModal();
                        if (confirm(
                            'Relancer un calcul neuf efface la progression ph.x (_ph0/) si tu n\'as pas sauvegardé.\n\nContinuer ?'
                        )) runOne(calc, { force: true });
                    },
                },
                { label: 'Fermer', cls: 'btn-secondary', onClick: closeModal },
            ];
        } else {
            verdict = `<div class="alert alert-error">❌ Aucun processus détecté par l'API `
                + `et pas de reprise automatique.</div>`
                + `<p>Vérifie <code>${escapeHtml(outPath)}</code> et <code>pgrep -af ph.x</code>.</p>`;
            footer = [
                ...frozenWatchFooterButtons(stepType, calc, { includeClose: false }),
                {
                    label: '🚀 Relancer l\'étape',
                    cls: 'btn-secondary',
                    onClick: () => { closeModal(); runOne(calc, { force: true }); },
                },
                {
                    label: '🖥️ Terminal',
                    cls: 'btn-secondary',
                    onClick: () => { closeModal(); terminalModal(calc); },
                },
                { label: 'Fermer', cls: 'btn-secondary', onClick: closeModal },
            ];
        }

        const bodyHTML = `
            <p class="muted" style="margin-top:0;">Sortie : <code>${escapeHtml(outPath)}</code>`
            + `${ageMin != null ? ` · dernière écriture il y a ~${ageMin} min` : ''}</p>
            <p>PID : ${pidTxt}</p>
            ${verdict}`;

        openModal({
            type: 'large',
            headerCls: probe.alive ? 'success' : (probe.resumable ? 'warning' : 'error'),
            title,
            subtitle: calc.prog,
            bodyHTML,
            footer,
        });
    }

    function stepStateIsActive(state) {
        return state === 'running' || state === 'running_quiet' || state === 'log_inactive';
    }

    /** Première étape non terminée de la chaîne (prochaine action conseillée). */
    function nextChainStep(wf = APP.workflow) {
        return calcStepsForRun(wf).find(c => stepState(c.type, wf) !== 'done') || null;
    }

    const CHAIN_BADGE = {
        done:           { cls: 'ok',   txt: '✅ terminé' },
        failed:         { cls: 'err',  txt: '❌ interrompu / erreur' },
        ready:          { cls: 'warn', txt: '⏳ à lancer' },
        blocked:        { cls: '',     txt: '🔒 en attente' },
        running:        { cls: 'warn', txt: '⚡ en cours' },
        running_quiet:  { cls: 'ok', txt: '🟢 actif · log silencieux' },
        log_inactive:   { cls: 'warn', txt: '⚠ journal figé · à confirmer' },
        interrupted:    { cls: 'warn', txt: '⏸ interrompu · reprise possible' },
    };

    function chainStepHint(st, state) {
        if (!st) return '';
        const age = st.out_age_sec;
        const min = age != null && Number.isFinite(age) ? Math.max(1, Math.round(age / 60)) : null;
        if (state === 'running_quiet') {
            return `<div class="chain-why muted">`
                + `Le calcul QE tourne encore (processus détecté) — le fichier <code>.out</code> `
                + `${min != null ? `n'a pas été modifié depuis ~${min} min` : 'n\'a pas bougé récemment'} `
                + `(fréquent pour <code>ph.x</code>).</div>`;
        }
        if (state === 'log_inactive') {
            const probe = APP.chain?.host_probe !== false;
            const tail = probe
                ? `Sur le PC de calcul : <code>pgrep -af 'ph.x|pw.x'</code> — si un PID apparaît, `
                  + `<strong>laisse tourner</strong> (ph.x peut rester silencieux des heures). `
                  + `Sinon : <strong>♻️ Reprendre</strong> sur la carte de l'étape.`
                : `L'API ne détecte plus les processus QE — <strong>redémarre l'API</strong> `
                  + `(<code>./ARRETER.sh && ./DEMARRER.sh</code>), puis clique <strong>↻ Revérifier</strong> `
                  + `(sans relancer un doublon si <code>pgrep</code> montre encore ph.x).`;
            return `<div class="chain-why muted">`
                + `Journal sans écriture récente (~15 min) — <em>ce n'est pas un échec automatique</em>. `
                + `${tail}</div>`;
        }
        if (state === 'failed' && st.has_error) {
            return `<div class="chain-why">Erreur signalée dans la sortie QE — ouvre 📊 Suivi.</div>`;
        }
        if (state === 'failed') {
            return `<div class="chain-why">Aucun processus détecté et pas de <code>JOB DONE</code> — calcul probablement arrêté.</div>`;
        }
        if (state === 'interrupted') {
            const kind = st.resume_kind === 'ph_recover' ? '<code>recover=.true.</code> (ph.x)' : '<code>restart</code> (pw.x)';
            return `<div class="chain-why muted">Reprise possible — bouton <strong>♻️ Reprendre</strong> sur la carte `
                + `( ${kind} ). Le journal <code>.out</code> est complété, pas effacé.</div>`;
        }
        return '';
    }

    /** Ligne mise en avant dans « Vérification de l'enchaînement » (WF1 + WF2). */
    function chainRunningStepType(wf = APP.workflow) {
        if (!wf) return null;
        if (APP.runningStep && wf === APP.workflow) return APP.runningStep;
        if (APP.chain?.wf === wf) {
            const hit = calcStepsForRun(wf).find(c => {
                const st = APP.chain.steps?.[c.type];
                return st?.running || st?.log_quiet || st?.log_inactive;
            });
            if (hit) return hit.type;
        }
        return null;
    }

    function chainFocusStepType(wf = APP.workflow) {
        if (!wf) return null;
        const running = chainRunningStepType(wf);
        if (running) return running;
        if (APP.chain?.wf !== wf) {
            return calcStepsForRun(wf)[0]?.type || null;
        }
        const next = nextChainStep(wf);
        return next?.type || null;
    }

    async function refreshChainStatus() {
        const box = $('#zoneChainStatus');
        if (!box) return;
        if (!APP.workflow) { box.style.display = 'none'; box.innerHTML = ''; return; }
        box.style.display = 'block';

        if (!APP.material) {
            box.innerHTML = alertBox('warning', 'Valide un matériau pour vérifier l\'enchaînement des calculs.');
            return;
        }
        if (!APP.apiOnline) {
            box.innerHTML = alertBox('warning',
                'API hors-ligne : impossible de vérifier l\'état des étapes. Lance <code>./DEMARRER.sh</code> puis « ↻ API ».');
            return;
        }

        await inspectChain();
        if (APP.chain?.steps?.scf?.done) await classifyScfMetal();
        else APP.metalCheck = null;
        renderMetalGate();
        updateResultatsEmptyState();
        if (!APP.chain) {
            box.innerHTML = alertBox('error',
                (APP.chainError || 'Vérification de la chaîne indisponible.') +
                ' Les lancements automatiques sont bloqués tant que la vérification ne répond pas — ' +
                'relance <code>./DEMARRER.sh</code> ou utilise 🖥️ Terminal en connaissance de cause.');
            return;
        }
        renderChainStatus();
        scheduleChainAutoRefresh();
        attachRunningClockFromChain().then(() => {
            refreshStepEstimates();
            updateStepChronoUI();
        });
    }

    let _chainPollTimer = null;
    function scheduleChainAutoRefresh() {
        if (_chainPollTimer) {
            clearInterval(_chainPollTimer);
            _chainPollTimer = null;
        }
        const wf = APP.workflow;
        if (!wf || !APP.chain || document.hidden) return;
        const steps = calcStepsForRun(wf);
        const states = steps.map(c => stepState(c.type, wf));
        const running = states.some(stepStateIsActive);
        const maybeLong = steps.some(c => {
            const st = APP.chain?.steps?.[c.type];
            return st && !st.done && st.exists;
        });
        if (running || maybeLong) {
            const ms = running ? 15000 : 45000;
            _chainPollTimer = window.setInterval(() => {
                if (document.hidden || !APP.workflow) return;
                refreshChainStatus();
            }, ms);
        }
    }

    /** Bandeau pédagogique quand un calcul long semble « figé » dans l'UI. */
    function chainLongRunBanner(wf) {
        const steps = calcStepsForRun(wf);
        let focus = null;
        let state = '';
        for (const c of steps) {
            const s = stepState(c.type, wf);
            if (stepStateIsActive(s) || (APP.chain?.steps?.[c.type]?.exists && !APP.chain.steps[c.type].done)) {
                focus = c;
                state = s;
                if (stepStateIsActive(s)) break;
            }
        }
        if (!focus || state === 'done') return '';
        const st = APP.chain?.steps?.[focus.type];
        if (!st || st.done) return '';
        const out = st.out ? `<code>${escapeHtml(st.out)}</code>` : 'le fichier .out';
        if (state === 'running_quiet' || (st.host_running && st.log_quiet)) {
            return `<div class="chain-foot ok" style="margin-top:10px;">
                <strong>Calcul toujours actif</strong> (${focus.prog}) — le journal ${out} peut ne pas bouger
                pendant des heures (normal pour <code>ph.x</code> / <code>epw.x</code>).
                <p style="margin:10px 0 0;">
                    <button type="button" class="btn btn-success btn-sm chain-banner-diagnose" data-diagnose="${focus.type}">
                        🔍 Calcul figé ? — vérifier et activer la surveillance
                    </button>
                </p>
                <ul style="margin:8px 0 0;padding-left:20px;line-height:1.7;">
                    <li>Ne relance <em>pas</em> la même étape en parallèle.</li>
                    <li>Actualise : <strong>↻ Revérifier</strong> (toutes les ~15 s tant qu'un calcul est actif).</li>
                </ul></div>`;
        }
        if (state === 'log_inactive' || state === 'interrupted' || state === 'failed') {
            return `<div class="chain-foot warn" style="margin-top:10px;">
                <strong>Calcul interrompu ou journal figé ?</strong> — étape ${focus.num} (${focus.prog}).
                <p style="margin:10px 0 0;">
                    <button type="button" class="btn btn-warning btn-sm chain-banner-diagnose" data-diagnose="${focus.type}">
                        🔍 Calcul figé ? — diagnostiquer (poursuite / reprise / relance)
                    </button>
                </p>
                <ol style="margin:8px 0 0;padding-left:20px;line-height:1.7;">
                    <li>Clique le bouton ci-dessus : l'interface interroge le PC de calcul.</li>
                    <li>Si le job tourne encore → <strong>Activer la surveillance</strong>.</li>
                    <li>Sinon → <strong>♻️ Reprendre</strong> ou relance guidée depuis la fenêtre.</li>
                </ol></div>`;
        }
        return '';
    }

    function renderChainStatus() {
        const box = $('#zoneChainStatus');
        const wf = APP.workflow;
        if (!box || !wf || !APP.chain || APP.chain.wf !== wf) return;

        const steps = calcStepsForRun(wf);
        const focusType = chainFocusStepType(wf);
        const rows = steps.map(c => {
            const state = stepState(c.type, wf);
            const runningNow = stepStateIsActive(state);
            const badge = CHAIN_BADGE[state] || CHAIN_BADGE.blocked;
            const blockers = state === 'blocked' || state === 'failed' ? chainBlockers(c.type, wf) : [];
            const st = APP.chain?.steps?.[c.type];
            const shared = st?.shared ? ' <span class="muted">· repris de l\'autre voie</span>' : '';
            const hint = chainStepHint(st, state);
            const why = blockers.length
                ? `<div class="chain-why">Attend : ${blockers.map(b => b.label).join(' · ')}</div>`
                : hint;
            const rowCls = [
                'chain-row',
                focusType === c.type ? 'is-active' : '',
                runningNow ? 'is-running' : '',
            ].filter(Boolean).join(' ');
            return `
                <li class="${rowCls}" data-state="${state}" data-type="${c.type}" role="button" tabindex="0"
                    title="Ouvrir l'étape ${c.num} · ${c.short || c.nom}">
                    <span class="chain-num">${c.num}</span>
                    <span class="chain-name">
                        <strong class="chain-short">${c.short || c.nom}</strong>
                        <span class="chain-full">${c.icon} ${c.nom} <span class="muted">(${c.prog})</span></span>
                        ${shared}${why}
                        <span class="chain-timing" data-chrono-step="${c.type}">
                            Estim. : <span class="chain-est-value">—</span>
                            <span class="chain-chrono-live" hidden></span>
                        </span>
                    </span>
                    <span class="chain-badge-wrap">
                        <span class="badge-status ${badge.cls}">${badge.txt}</span>
                        ${FROZEN_DIAGNOSE_STATES.has(state) && !st?.done ? `
                        <button type="button" class="btn chain-btn-frozen" data-diagnose="${c.type}"
                            title="Diagnostiquer : le calcul continue-t-il ? reprise ?">
                            🔍 Calcul figé ?
                        </button>` : ''}
                    </span>
                </li>`;
        }).join('');

        const next = nextChainStep(wf);
        const allDone = !next;
        const metalStop = !!APP.metalCheck?.should_stop;
        let foot;
        if (metalStop) {
            const gap = APP.metalCheck.gap_eV;
            const gapTxt = Number.isFinite(gap) ? `Eg ≈ ${gap.toFixed(3)} eV` : 'gap électronique';
            foot = `<div class="chain-foot warn">
                ⛔ SCF : matériau <strong>non métallique</strong> (${gapTxt}).
                Arrêter nscf / phonons / EPW — ce n'est pas un conducteur.
                Les étapes déjà générées ou lancées plus loin ne doivent pas continuer.
            </div>`;
        } else if (allDone) {
            foot = `<div class="chain-foot ok chain-foot-complete">
                <p style="margin:0 0 12px;">🎉 <strong>Fin des calculs</strong> — toutes les étapes du workflow sont terminées (<code>JOB DONE</code>).</p>
                <button type="button" class="btn btn-success" id="btnChainFinCalculs">✅ Fin des calculs — ouvrir Résultats</button>
            </div>`;
        } else {
            const state = stepState(next.type, wf);
            const blockers = chainBlockers(next.type, wf);
            if (state === 'ready') {
                foot = `<div class="chain-foot">Prochaine étape : <strong>${next.num} — ${next.nom}</strong> (${next.prog}).</div>`;
            } else if (stepStateIsActive(state)) {
                foot = `<div class="chain-foot ok">
                    <strong>${next.num} — ${next.nom}</strong> (<code>${next.prog}</code>) est <strong>en cours</strong>
                    — ce n'est pas un blocage. Badge sur la ligne ci-dessus · <strong>🔍 Calcul figé ?</strong> si le journal ne bouge plus.
                </div>`;
            } else if (state === 'interrupted') {
                foot = `<div class="chain-foot warn">
                    <strong>${next.num} — ${next.nom}</strong> : calcul interrompu — <strong>♻️ Reprendre</strong> sur la carte
                    ou <strong>🔍 Calcul figé ?</strong> pour diagnostiquer.
                </div>`;
            } else if (blockers.length) {
                foot = `<div class="chain-foot warn">
                    <strong>${next.num} — ${next.nom}</strong> ne peut pas être lancée tant que :
                    <ul>${blockers.map(b => `<li>${b.label}${b.detail ? ` — ${b.detail}` : ''}</li>`).join('')}</ul>
                </div>`;
            } else {
                foot = `<div class="chain-foot warn">
                    <strong>${next.num} — ${next.nom}</strong> : étape incomplète (${state}).
                    ↻ Revérifier · 🔍 Calcul figé ? · 📊 Suivi sur la carte de l'étape.
                </div>`;
            }
        }

        const scfShared = APP.chain?.steps?.scf?.shared;
        const shareNote = scfShared
            ? `<div class="chain-foot">♻️ SCF déjà réalisé sur l'autre voie — densité <code>prefix.save</code> réutilisée, on passe à l'étape suivante.</div>`
            : '';
        box.innerHTML = `
            <div class="chain-status ${wfCss(wf)}">
                <div class="chain-head">
                    <strong>Vérification de l'enchaînement — ${WORKFLOW_LABEL[wf].name}</strong>
                    <button type="button" class="btn btn-success btn-toolbar" id="btnActivateWatch"
                        title="Sans relancer : refresh ~15 s, badge surveillance">✅ Surveillance</button>
                    <button type="button" class="btn btn-secondary btn-toolbar" id="btnDiagnoseFrozen"
                        title="Processus QE encore actif ? Reprise ph.x / relance ?">🔍 Calcul figé ?</button>
                    <button type="button" class="btn btn-secondary btn-toolbar" id="btnRefreshChain">↻ Revérifier</button>
                </div>
                <p id="chainTotalEstimate" class="chain-total-est muted" style="margin:0 0 10px;font-size:0.88em;"></p>
                <ol class="chain-list">${rows}</ol>
                ${chainLongRunBanner(wf)}${shareNote}${foot}
            </div>`;
        $('#btnRefreshChain')?.addEventListener('click', async () => {
            await refreshChainStatus();
            syncPipelineFromChain();
        });
        $('#btnActivateWatch')?.addEventListener('click', () => {
            const t = chainFocusStepType(wf)
                || calcStepsForRun(wf).find(c => stepState(c.type, wf) !== 'done')?.type;
            const calc = t ? calcByType(wf, t) : null;
            if (!t || !calc) {
                notifyUser('Aucune étape en cours à surveiller.', 'info');
                return;
            }
            applyFrozenWatchUi(t, calc);
        });
        $('#btnDiagnoseFrozen')?.addEventListener('click', () => {
            const t = chainFocusStepType(wf)
                || calcStepsForRun(wf).find(c => FROZEN_DIAGNOSE_STATES.has(stepState(c.type, wf)))?.type;
            if (t) openFrozenDiagnoseModal(t);
            else notifyUser('Aucune étape en cours ou figée à diagnostiquer.', 'info');
        });
        box.querySelectorAll('.chain-btn-frozen[data-diagnose], .chain-banner-diagnose[data-diagnose]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                openFrozenDiagnoseModal(btn.dataset.diagnose);
            });
        });
        $('#btnChainFinCalculs')?.addEventListener('click', async () => {
            switchMainView('resultats');
            notifyUser('Chaîne terminée — exploration des résultats (λ, Tᶜ, courbes).', 'success');
            await exploreResults();
            await exportFermiBxsfIfNeeded({ reason: 'fin_chaîne' });
            await exploreResults();
        });
        box.querySelectorAll('.chain-row[data-type]').forEach(row => {
            const go = (e) => {
                if (e.target.closest('.chain-btn-frozen')) return;
                scrollToCalc(row.dataset.type);
            };
            row.addEventListener('click', go);
            row.addEventListener('keydown', e => {
                if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); }
            });
        });
        syncPipelineFromChain();
        refreshStepEstimates();
        updateStepChronoUI();
    }

    /** Reporte l'état réel des sorties sur le pipeline et les cartes de calcul. */
    function syncPipelineFromChain() {
        const wf = APP.chain?.wf;
        if (!wf || wf !== APP.workflow) {
            markNextStep();
            return;
        }
        Object.keys(STEP_CHAIN[wf] || {}).forEach(step => {
            const state = stepState(step, wf);
            if (state === 'done') setCalcState(step, 'completed', 'OK');
            else if (state === 'running') setCalcState(step, 'running', 'en cours');
            else if (state === 'running_quiet') setCalcState(step, 'running_quiet', 'actif · log silencieux');
            else if (frozenWatchActive(step, wf)) setCalcState(step, 'running_quiet', 'surveillance · actif');
            else if (state === 'log_inactive') setCalcState(step, 'running', 'journal figé');
            else if (state === 'interrupted') setCalcState(step, 'running', 'reprise possible');
            else if (state === 'failed') setCalcState(step, 'error', 'interrompu');
            else if (state === 'ready') setCalcState(step, 'ready', 'à lancer');
            else setCalcState(step, 'idle', 'en attente');
        });
        updateResumeButtons();
        markNextStep();
    }

    function updateResumeButtons() {
        if (!APP.workflow) return;
        calcStepsForRun(APP.workflow).forEach(c => {
            const card = document.querySelector(`.calc-card[data-type="${c.type}"]`);
            const btn = card?.querySelector('[data-action="resume"]');
            if (!btn) return;
            const st = APP.chain?.steps?.[c.type];
            btn.hidden = !(st?.resumable && !st.done && !st.host_running);
        });
    }

    /** Prochaine étape à lancer (SCF en premier tant que la chaîne n'est pas lue). */
    function currentNextCalc() {
        if (!APP.workflow) return null;
        const focus = chainFocusStepType(APP.workflow);
        if (!focus) return null;
        return calcStepsForRun(APP.workflow).find(c => c.type === focus) || null;
    }

    /** Pipeline, cartes et liste d'enchaînement — étape courante (WF1 + WF2). */
    function markChainFocus() {
        const wf = APP.workflow;
        const focus = wf ? chainFocusStepType(wf) : null;
        const running = (APP.runningStep && wf === APP.workflow) ? APP.runningStep : null;

        $$('#pipelineActive .pipe-step').forEach(el => {
            const t = el.dataset.step;
            const active = !!focus && t === focus;
            const run = !!running && t === running;
            el.classList.toggle('is-chain-active', active);
            el.classList.toggle('is-chain-running', run);
            el.classList.toggle('is-next', active && !run);
            if (active) el.setAttribute('aria-current', run ? 'step' : 'step');
            else el.removeAttribute('aria-current');
        });
        $$('#zoneListeCalculs .calc-card').forEach(el => {
            const t = el.dataset.type;
            const active = !!focus && t === focus;
            const run = !!running && t === running;
            el.classList.toggle('is-chain-active', active);
            el.classList.toggle('is-chain-running', run);
            el.classList.toggle('is-next', active && !run);
        });
        $$('.chain-row[data-type]').forEach(el => {
            const t = el.dataset.type;
            const active = !!focus && t === focus;
            const run = !!running && t === running;
            el.classList.toggle('is-active', active);
            el.classList.toggle('is-running', run);
            el.classList.toggle('is-next', active && !run);
            if (run) {
                const b = el.querySelector('.badge-status');
                if (b) {
                    b.className = 'badge-status warn';
                    b.textContent = CHAIN_BADGE.running.txt;
                }
            }
        });
    }

    function markNextStep() {
        markChainFocus();
    }

    function scrollToCalc(type) {
        if (!type) return;
        const card = $(`#zoneListeCalculs .calc-card[data-type="${type}"]`);
        if (card) {
            scrollToView(card, { block: 'center', force: true });
            card.classList.remove('calc-flash');
            void card.offsetWidth;
            card.classList.add('calc-flash');
            setTimeout(() => card.classList.remove('calc-flash'), 1400);
            return;
        }
        const zone = $('#zoneListeCalculs');
        if (zone) scrollToView(zone, { block: 'start', force: true });
    }

    /**
     * Géométrie relaxée exploitable : positions atomiques lues dans le SCF
     * utilisateur (`inputs/<mat>/<mat>.scf.in`) ou, à défaut, dans vc-relax.out.
     * Commun à WF1 (pw.x … matdyn.x) et WF2 (pw.x … epw.x).
     */
    function prereqsReady() {
        return !!(APP.material && APP.structure && APP.structure.positions?.length);
    }

    function structureSourceLabel() {
        const p = APP.prereq || {};
        const scf = p.relaxPath || APP.files?.[APP.workflow]?.scf?.originPath || '';
        return scf || `inputs/${APP.material || '<matériau>'}/${APP.material || '<matériau>'}.scf.in`;
    }

    function renderStructureGate() {
        const gate = $('#prereqLaunchGate');
        if (!gate) return;
        if (!APP.material || !APP.workflow) {
            gate.className = 'structure-gate';
            gate.style.display = 'none';
            gate.innerHTML = '';
            return;
        }
        const mat = APP.material;
        const base = APP.baseDir || `inputs/${mat}`;
        const scfPath = `${base}/${mat}.scf.in`;
        const ready = prereqsReady();
        const s = APP.structure;
        const ctl = APP.scfCtl || {};
        const wfPills = `
            <span class="sg-pill">WF1 · pw.x → ph.x → q2r.x → matdyn.x</span>
            <span class="sg-pill">WF2 · pw.x → ph.x → pw.x → epw.x</span>`;

        gate.className = 'structure-gate is-open' + (ready ? ' is-ok' : '');
        gate.style.display = 'block';

        if (ready) {
            const ibrav = s.ibrav != null ? s.ibrav : '—';
            const nat = s.positions?.length || '—';
            const ntyp = s.species?.length || '—';
            const ecut = s.ecutwfc != null ? `${s.ecutwfc} Ry` : '—';
            gate.innerHTML = `
                <h3>Géométrie de référence — tous les calculateurs</h3>
                <p class="sg-lead" style="margin-bottom:8px;">
                    Source unique : <code>${escapeHtml(structureSourceLabel())}</code>
                    · <code>ibrav = ${ibrav}</code>
                    · <code>nat = ${nat}</code>
                    · <code>ntyp = ${ntyp}</code>
                    · <code>ecutwfc = ${ecut}</code>
                    ${ctl.prefix ? `· <code>prefix = '${escapeHtml(ctl.prefix)}'</code>` : ''}
                </p>
                <p class="muted" style="margin:0; font-size:0.88em;">
                    <code>prefix</code>, <code>outdir</code> et <code>pseudo_dir</code> du SCF
                    sont hérités par <code>pw.x</code>, <code>ph.x</code>, <code>q2r.x</code>,
                    <code>matdyn.x</code> et <code>epw.x</code>.
                </p>
                <div class="sg-wf">${wfPills}</div>`;
        } else {
            const altNames = scfInputCandidateNames(mat)
                .filter(n => n !== `${mat}.scf.in`)
                .map(n => `<code>${escapeHtml(n)}</code>`)
                .join(', ');
            gate.innerHTML = `
                <h3>Structure cristalline introuvable</h3>
                <p class="sg-lead">
                    Aucune géométrie n'a pu être lue pour <strong>${escapeHtml(mat)}</strong>.
                    WF1 (classique) et WF2 (EPW) démarrent tous les deux sur <em>votre</em> input SCF
                    (maille et positions déjà relaxées en amont — le vc-relax n'est pas une étape Supra-QE).
                </p>
                <div class="sg-box">
                    <h4>Fichier requis (convention QE)</h4>
                    <pre class="sg-path">${escapeHtml(scfPath)}</pre>
                    <table class="sg-table">
                        <tr><th>Namelists</th><td><code>&amp;CONTROL</code>, <code>&amp;SYSTEM</code>, <code>&amp;ELECTRONS</code></td></tr>
                        <tr><th>Cartes</th><td><code>ATOMIC_SPECIES</code>, <code>ATOMIC_POSITIONS</code></td></tr>
                        <tr><th>Héritage</th><td><code>prefix</code>, <code>outdir</code>, <code>pseudo_dir</code> repris pour NSCF, ph.x, epw.x…</td></tr>
                    </table>
                    <p class="sg-names">Autres noms reconnus dans le même dossier : ${altNames}.</p>
                </div>
                <div class="sg-wf">${wfPills}</div>`;
        }
        if (typeof SupraI18n !== 'undefined' && SupraI18n.refresh) SupraI18n.refresh(gate);
    }

    function metalStopHtml(cls) {
        const gap = cls?.gap_eV;
        const gapTxt = Number.isFinite(gap) ? `Eg ≈ ${Number(gap).toFixed(3)} eV` : 'un gap électronique';
        const src = cls?.path ? ` (<code>${escapeHtml(cls.path)}</code>)` : '';
        return `⛔ <strong>Arrêter les calculs</strong> — après le SCF, le matériau n'est <em>pas un conducteur</em> `
            + `(${gapTxt})${src}. Le couplage électron–phonon et T<sup>c</sup> ne s'appliquent pas. `
            + `Même si des tests (nscf, ph, EPW) ont déjà été générés ou lancés, ne pas les poursuivre.`;
    }

    function classifyScfTextFallback(text) {
        if (!text) return null;
        const hl = /highest occupied,\s*lowest unoccupied level\s*\(ev\):\s*([-0-9.]+)\s+([-0-9.]+)/i.exec(text);
        if (hl) {
            const gap = parseFloat(hl[2]) - parseFloat(hl[1]);
            if (Number.isFinite(gap) && gap >= 0.15) {
                return {
                    ok: true, character: 'insulator', should_stop: true, gap_eV: gap,
                    evidence: ['homo_lumo'], source: 'fallback',
                };
            }
        }
        if (/the system is insulating/i.test(text)) {
            return { ok: true, character: 'insulator', should_stop: true, evidence: ['qe_insulating'], source: 'fallback' };
        }
        if (/the system is metallic/i.test(text)) {
            return { ok: true, character: 'metal', should_stop: false, evidence: ['qe_metallic'], source: 'fallback' };
        }
        const occs = [];
        const occRe = /occupation numbers[\s\S]*?((?:\s*[-+0-9.eEdD]+)+)/gi;
        let m;
        while ((m = occRe.exec(text)) !== null) {
            String(m[1]).trim().split(/\s+/).forEach(t => {
                const v = parseFloat(t);
                if (Number.isFinite(v) && v > 0.05 && v < 0.95) occs.push(v);
            });
        }
        if (occs.length) {
            return { ok: true, character: 'metal', should_stop: false, evidence: ['fractional_occ'], source: 'fallback' };
        }
        return null;
    }

    async function classifyScfMetal({ force = false } = {}) {
        if (!APP.material || !APP.apiOnline) return APP.metalCheck;
        const paths = stepOutCandidates('scf').filter(Boolean);
        if (!paths.length) return APP.metalCheck;
        const key = paths.join('|');
        if (!force && APP.metalCheck?.key === key && (Date.now() - (APP.metalCheck.at || 0)) < 20000) {
            return APP.metalCheck;
        }
        for (const p of paths) {
            const r = await SupraAPI.classifyScf(p);
            if (r?.ok && r.character) {
                APP.metalCheck = { ...r, path: p, key, at: Date.now() };
                return APP.metalCheck;
            }
            const tail = await SupraAPI.readFile(p, { tail_lines: 8000 });
            if (!tail?.ok || !tail.content) continue;
            const fb = classifyScfTextFallback(tail.content);
            if (fb) {
                APP.metalCheck = { ...fb, path: p, key, at: Date.now() };
                return APP.metalCheck;
            }
        }
        APP.metalCheck = {
            ok: false, character: 'unknown', should_stop: false, key, at: Date.now(),
        };
        return APP.metalCheck;
    }

    function renderMetalGate() {
        const gate = $('#metalLaunchGate');
        if (!gate) return;
        const cls = APP.metalCheck;
        if (!APP.material || !APP.workflow || !cls || cls.character === 'unknown' || !cls.character) {
            gate.className = 'structure-gate metal-gate';
            gate.style.display = 'none';
            gate.innerHTML = '';
            return;
        }
        gate.style.display = 'block';
        if (cls.should_stop) {
            const gap = cls.gap_eV;
            const gapCell = Number.isFinite(gap) ? `${Number(gap).toFixed(3)} eV` : '—';
            gate.className = 'structure-gate metal-gate is-open is-stop';
            gate.innerHTML = `
                <h3>Arrêter — ce n'est pas un conducteur</h3>
                <p class="sg-lead">
                    Le SCF${cls.path ? ` (<code>${escapeHtml(cls.path)}</code>)` : ''}
                    montre un <strong>gap électronique</strong> : le matériau n'est pas métallique.
                    Le couplage e–p, les phonons DFPT et T<sup>c</sup> n'ont pas de sens.
                    <strong>N'enchaîne pas</strong> nscf / ph.x / EPW, même si ces tests ont déjà
                    été générés ou lancés plus tôt.
                </p>
                <table class="sg-table">
                    <tr><th>Caractère</th><td>isolant / semi-conducteur</td></tr>
                    <tr><th>Gap</th><td><code>${escapeHtml(gapCell)}</code></td></tr>
                    <tr><th>Seuil d'arrêt</th><td>Eg ≳ 0.15 eV</td></tr>
                </table>`;
        } else if (cls.character === 'metal') {
            gate.className = 'structure-gate metal-gate is-open is-ok';
            const ef = Number.isFinite(cls.ef_eV) ? `${Number(cls.ef_eV).toFixed(3)} eV` : '—';
            gate.innerHTML = `
                <h3>SCF métallique — conducteur</h3>
                <p class="sg-lead" style="margin-bottom:0;">
                    Pas de gap électronique. E<sub>F</sub> = <code>${escapeHtml(ef)}</code>
                    — on peut enchaîner nscf / phonons / EPW.
                </p>`;
        } else {
            gate.className = 'structure-gate metal-gate';
            gate.style.display = 'none';
            gate.innerHTML = '';
            return;
        }
        if (typeof SupraI18n !== 'undefined' && SupraI18n.refresh) SupraI18n.refresh(gate);
    }

    /**
     * Après une étape réussie : classer le SCF (arrêt si isolant), puis
     * régénérer et écrire les inputs suivants (même logique WF1 / WF2).
     */
    async function afterStepSuccess(stepId, { persist = true } = {}) {
        if (stepId === 'scf') {
            const cls = await classifyScfMetal({ force: true });
            renderMetalGate();
            updateWorkflowActionButtons();
            if (cls?.should_stop) {
                appendLog(alertBox('error', metalStopHtml(cls)));
                notifyUser("Gap électronique : ce n'est pas un conducteur — arrête la chaîne e–p / Tc.", 'error');
                return { stop: true, reason: 'not_metal' };
            }
            if (cls?.character === 'metal') {
                appendLog(alertBox('success',
                    'SCF métallique (conducteur) — génération des inputs suivants et poursuite de la chaîne.'));
            }
        }
        if (persist && APP.files?.[APP.workflow]) {
            await refreshAdoptedScf(APP.files[APP.workflow]);
            const written = await persistWorkflowFiles(APP.files[APP.workflow]);
            renderInputsPanel(APP.files);
            if (written.ok) {
                appendLog(`📝 Inputs suivants mis à jour dans <code>${getWorkflowPaths().workDir}/</code> `
                    + `(${written.saved} fichier(s), héritage prefix / outdir / pseudo_dir du SCF).`);
            }
        }
        if (APP.workflow === 'epw' && stepId === 'ph') {
            const gather = await runEpwPpGather({ silent: false });
            if (!gather.ok) {
                appendLog(alertBox('warning',
                    `ph.x terminé — <code>save/</code> absent : ${escapeHtml(gather.error || 'pp.py non exécuté')}. `
                    + `Lance <code>pp.py</code> dans <code>${qeOutdirApiRel()}/</code> avant epw.x `
                    + `(🖥️ Terminal étape ph ou epw).`));
            }
        }
        return { stop: false };
    }

    /** Regroupe dyn + dvscf dans outdir/save/ (script pp.py EPW). */
    async function runEpwPpGather({ silent = false } = {}) {
        if (!APP.apiOnline) {
            return { ok: false, error: 'API hors ligne' };
        }
        const prefix = APP.scfCtl?.prefix || APP.material;
        const wd = qeOutdirApiRel();
        if (!silent) {
            appendLog(`📦 Regroupement EPW — <code>pp.py</code> dans <code>${wd}/</code> (prefix <code>${prefix}</code>)…`);
        }
        const r = await SupraAPI.runEpwPp({ workdir: wd, prefix });
        if (r?.ok) {
            if (!silent) {
                appendLog(alertBox('success',
                    `✅ <code>${wd}/save/</code> prêt pour <code>epw.x</code> (dvscf + dyn).`));
            }
            return { ok: true };
        }
        return { ok: false, error: r?.error || 'échec pp.py' };
    }

    async function ensureEpwSaveBeforeEpw() {
        if (APP.workflow !== 'epw') return true;
        await inspectChain();
        const save = APP.chain?.artifacts?.epwSave;
        if (save?.exists) return true;
        const g = await runEpwPpGather({ silent: true });
        if (g.ok) {
            await inspectChain();
            return !!APP.chain?.artifacts?.epwSave?.exists;
        }
        return false;
    }

    const RESULT_READ_BTN_SEL = [
        '#btnExploreResults', '#btnExportCsv', '#btnExportLatex', '#btnExportReport',
        '#btnJournalHtml', '#btnJournalPdf',
    ];

    function setResultReadButtonsEnabled(enabled) {
        RESULT_READ_BTN_SEL.forEach(sel => {
            const btn = $(sel);
            if (btn) btn.disabled = !enabled;
        });
    }

    function updateResultatsEmptyState() {
        const box = $('#resultatsEmptyState');
        if (!box) return;

        const inResultats = APP.mainView === 'resultats';
        const canRead = !!APP.material;
        setResultReadButtonsEnabled(canRead);

        // Une exploration avec données utiles remplace le bandeau pédagogique.
        const hasUseful = !!(typeof RES !== 'undefined' && RES.data
            && (RES.data.synthesis?.available?.classic || RES.data.synthesis?.available?.epw));
        if (!inResultats || (APP.material && hasUseful)) {
            box.style.display = 'none';
            return;
        }
        box.style.display = 'block';

        if (!APP.material) {
            box.className = 'alert alert-warning';
            box.innerHTML = 'Aucun matériau validé. Saisis et valide un matériau (étape 1), choisis un workflow, puis lance les calculs ou dépose les fichiers <code>.out</code> dans <code>outputs/</code>.';
            return;
        }
        // L'exploration couvre les deux voies : un workflow actif n'est pas requis,
        // il ne sert qu'à préciser l'avancement affiché.
        const wf = APP.workflow ? WORKFLOW_LABEL[APP.workflow] : null;
        const chain = (APP.workflow && APP.chain?.wf === APP.workflow) ? APP.chain : null;
        const steps = APP.workflow ? calcStepsForRun(APP.workflow) : [];
        const done = chain ? steps.filter(c => chain.steps[c.type]?.done) : [];
        const last = steps.slice(-1)[0];
        const scanned = `<code>outputs/${APP.material}/classic/</code> et <code>outputs/${APP.material}/epw/</code>`;

        if (wf && done.length && last && chain.steps[last.type]?.done) {
            box.className = 'alert alert-success';
            box.innerHTML = `Matériau <strong>${APP.material}</strong> · ${wf.name} — chaîne complète `
                + `(${done.length}/${steps.length} étapes). Le journal affiche magnétisme (v1.4), λ, ω_log, Tᶜ et les courbes.`;
            return;
        }
        box.className = 'alert alert-info';
        const progress = wf
            ? (done.length
                ? `${wf.name} : ${done.length}/${steps.length} étape(s) terminée(s), l'étape finale `
                  + `(<code>${last?.prog || '—'}</code>) n'est pas encore passée. `
                : `${wf.name} : aucun calcul terminé pour l'instant. `)
            : '';
        box.innerHTML = `Matériau <strong>${APP.material}</strong> — ${progress}`
            + `Les résultats (y compris SCF, NSCF, phonons et courbes) se chargent automatiquement `
            + `dans le <strong>journal</strong> dès que des fichiers sont présents dans ${scanned}.`;
    }

    function updateWorkflowActionButtons() {
        const ready = prereqsReady();
        const metalStop = !!(APP.metalCheck?.should_stop);
        const gen = $('#btnGenerateAll');
        const run = $('#btnRunWorkflow');
        if (gen) {
            gen.disabled = !ready;
            gen.title = ready ? '' :
                'Géométrie requise : inputs/<matériau>/<matériau>.scf.in (ou variante reconnue).';
        }
        if (run) {
            run.disabled = !ready || metalStop;
            run.title = metalStop
                ? "Matériau non métallique (gap) — arrêter les calculs e–p / Tc."
                : (ready ? '' : 'Géométrie requise : inputs/<matériau>/<matériau>.scf.in (ou variante reconnue).');
        }
        renderStructureGate();
        renderMetalGate();
    }

    /** Flux : onglet Calculs ou Résultats → matériau → WF → panneau WF */
    function updateFluxEtapes() {
        const hasMat = !!APP.material;
        const hasWf  = !!APP.workflow;
        const mode   = APP.mainView === 'resultats' ? 'resultats' : 'calculs';

        const etape2 = $('#zoneEtapeCalculs');
        const etape3 = $('#zoneWorkflowActif');
        const lock   = $('#etape1LockHint');
        const resGate = $('#resultatsGate');
        const hint   = $('#wfPickHint');
        const pseudo = $('#zoneEtapePseudo');
        const needMat = $('#resultatsNeedMat');
        const picker = $('#workflowPicker');

        if (mode === 'resultats') {
            // Matériau en tête ; les deux voies sont dans le journal (pas de sélecteur WF ici).
            if (etape2) etape2.style.display = 'none';
            if (etape3) {
                etape3.style.display = hasMat ? 'block' : 'none';
                etape3.classList.toggle('is-visible', hasMat);
            }
            if (lock)    lock.style.display = 'none';
            if (resGate) resGate.style.display = hasMat ? 'none' : 'block';
            if (hint) {
                hint.style.display = 'none';
                hint.innerHTML = '👆 Choisis <strong>Workflow Classique (WF1)</strong> ou <strong>Workflow EPW (WF2)</strong>.';
            }
            if (pseudo) pseudo.style.display = 'none';
            if (needMat) needMat.style.display = 'none';
            if (hasMat) {
                const title = $('#etapeWorkflowTitle');
                if (title) {
                    title.textContent = `« ${APP.material} » — résultats des deux voies`;
                }
            }
        } else {
            if (etape2) etape2.style.display = hasMat ? 'block' : 'none';
            if (etape3) {
                const show = hasMat && hasWf;
                etape3.style.display = show ? 'block' : 'none';
                etape3.classList.toggle('is-visible', show);
            }
            if (lock)    lock.style.display = hasMat ? 'none' : 'block';
            if (resGate) resGate.style.display = 'none';
            if (hint) {
                hint.style.display = (hasMat && !hasWf) ? 'block' : 'none';
                hint.innerHTML = '👆 Choisis <strong>Workflow Classique (WF1)</strong> ou <strong>Workflow EPW (WF2)</strong>.';
            }
            if (pseudo) pseudo.style.display = hasMat ? 'block' : 'none';
            if (needMat) needMat.style.display = 'none';
            if (hasMat && !hasWf) {
                const title = $('#etapeWorkflowTitle');
                if (title) title.textContent = `« ${APP.material} » — choisis un workflow`;
            }
        }

        if (picker) picker.classList.toggle('is-picked', hasWf);
        updateSessionProgress();

        const etape1 = $('#zoneEtape1');
        if (etape1) etape1.dataset.ready = hasMat ? 'true' : 'false';

        updateMainViewBanner();
        applyMainViewPart();
        updatePrereqFlowChart();
        updateResultatsEmptyState();
        updateWorkflowActionButtons();
        renderWorkflowBanner();
        renderIdentityBar();
    }

    function updateMainViewBanner() {
        const el = $('#mainViewBannerText');
        if (!el) return;
        if (APP.mainView === 'resultats') {
            el.innerHTML = '<strong>Mode Résultats</strong> — valide le matériau si besoin, puis explore Tᶜ, λ, α²F(ω) et le gap des deux voies.';
        } else if (APP.mainView === 'calculs') {
            el.innerHTML = '<strong>Mode Calculs</strong> — valide le matériau, configure les pseudos (1b), choisis un workflow, puis lance les calculs.';
        } else {
            el.innerHTML = '';
        }
    }

    function applyMainViewPart() {
        const part = APP.mainView === 'resultats' ? 'resultats' : 'calculs';
        setWfPart(part);
    }

    function setWfPart(part) {
        const calculs = $('#zoneWfCalculs');
        const resultats = $('#zoneWfResultats');
        if (calculs) calculs.classList.toggle('active', part === 'calculs');
        if (resultats) resultats.classList.toggle('active', part === 'resultats');
    }

    function updateNavToolbarVisibility() {
        const isHelp = APP.mainView === 'help';
        const isGuide = APP.mainView === 'guide';
        // Tout déplier / replier : utiles sur Calculs/Résultats (~19 cartes) et Aide ;
        // inutiles sur le Guide (pas de sections à gérer).
        $('#navCollapseApp')?.classList.toggle('hidden', isHelp || isGuide);
        $('#navCollapseHelp')?.classList.toggle('hidden', !isHelp);
        $('#mainViewBanner')?.classList.toggle('hidden', isHelp || isGuide);

        const guideBtn = $('#btnToggleUsageGuide');
        if (guideBtn) {
            guideBtn.classList.toggle('active', isGuide);
            guideBtn.setAttribute('aria-selected', isGuide ? 'true' : 'false');
            guideBtn.setAttribute('aria-expanded', isGuide ? 'true' : 'false');
            guideBtn.textContent = isGuide ? '📖 Guide' : '📖 Guide';
        }
        $$('.view-tab').forEach(t => {
            const on = t.dataset.tab === APP.mainView;
            t.classList.toggle('active', on);
            t.setAttribute('aria-selected', on ? 'true' : 'false');
        });
    }

    function switchMainView(view) {
        APP.mainView = view;
        document.body.dataset.mainView = view || '';

        const guidePanel = $('#usageGuidePanel');
        if (guidePanel) guidePanel.classList.toggle('hidden', view !== 'guide');

        $$('.tab-content').forEach(c => {
            const id = c.dataset.tabContent;
            const show = id === view || (id === 'app' && (view === 'calculs' || view === 'resultats'));
            c.classList.toggle('active', show);
        });
        updateNavToolbarVisibility();
        updateMainViewBanner();
        if (view === 'calculs' || view === 'resultats') {
            applyMainViewPart();
            updateFluxEtapes();
            updateResultatsEmptyState();
            // Force un reflow pour que display:block prenne effet avant le scroll
            void $('#zoneAppFlow')?.offsetHeight;
            let scrollTarget = null;
            if (view === 'resultats') {
                if (!APP.material) scrollTarget = '#resultatsGate';
                else if ($('#zoneWorkflowActif')?.style.display !== 'none') scrollTarget = '#zoneWfResultats';
                else scrollTarget = '#zoneEtape1';
                // Auto-exploration dès qu'un matériau est validé
                if (APP.material && APP.apiOnline && !RES.busy) {
                    window.setTimeout(() => exploreResults(), 80);
                }
            } else if (APP.workflow && $('#zoneWorkflowActif')?.style.display !== 'none') {
                scrollTarget = '#zoneWfCalculs';
            } else {
                scrollTarget = '#zoneEtape1';
            }
            scrollToView(scrollTarget, { block: 'nearest' });
        } else if (view === 'help') {
            scrollToView('.tab-content[data-tab-content="help"]', { block: 'nearest' });
            bindHelpTheoryDetails();
            window.setTimeout(() => typesetHelpMath(), 60);
        } else if (view === 'guide') {
            scrollToView('#usageGuidePanel', { block: 'nearest' });
        }
    }

    function toggleUsageGuide(forceOpen) {
        // Le Guide est un onglet à part entière : ouvrir = y aller, fermer = retour Calculs.
        if (typeof forceOpen === 'boolean') {
            switchMainView(forceOpen ? 'guide' : 'calculs');
            return;
        }
        switchMainView(APP.mainView === 'guide' ? 'calculs' : 'guide');
    }

    function bindUsageGuide() {
        $('#btnToggleUsageGuide')?.addEventListener('click', () => switchMainView('guide'));
        $('#btnGuideGoCalculs')?.addEventListener('click', () => switchMainView('calculs'));
        $('#btnGuideGoResultats')?.addEventListener('click', () => switchMainView('resultats'));
    }

    function highlightOrganigram(wf) {
        $$('.org-branch[data-wf]').forEach(b => {
            b.classList.toggle('active', wf != null && b.dataset.wf === wf);
        });
    }

    /** Affichage conditionnel : masque les paramètres des autres voies. */
    function applyBranchVisibility(wf) {
        $$('[data-wf-visible]').forEach(el => {
            if (el.classList.contains('wf-param-tabs')) return;
            const v = el.dataset.wfVisible;
            el.style.display = branchTagVisible(wf, v) ? '' : 'none';
        });

        const tabsClassic = $('#wfParamTabsClassic');
        const tabsEpw = $('#wfParamTabsEpw');
        const tabsSscha = $('#wfParamTabsSscha');
        if (tabsClassic) tabsClassic.style.display = wf === 'classic' ? 'flex' : 'none';
        if (tabsEpw) tabsEpw.style.display = wf === 'epw' ? 'flex' : 'none';
        if (tabsSscha) tabsSscha.style.display = wf === 'sscha' ? 'flex' : 'none';

        $$('.pipelines-dual').forEach(dual => {
            const blocks = $$('.pipeline-block[data-wf-visible]', dual)
                .filter(b => b.style.display !== 'none');
            dual.style.gridTemplateColumns = blocks.length <= 1 ? '1fr' : '';
        });

        updateKQVisual();
    }

    function focusParamSection(section) {
        if (!section) return;
        const card = $(`.card.collapsible[data-section="${section}"]`);
        if (!card || card.style.display === 'none') return;
        setCollapsibleOpen(card, true);
        scrollToView(card, { block: 'nearest' });
    }

    function bindBranchSubTabs() {
        $$('.wf-param-tab').forEach(tab => {
            if (tab._boundBranchTab) return;
            tab._boundBranchTab = true;
            tab.addEventListener('click', (e) => {
                e.preventDefault();
                const bar = tab.closest('.wf-param-tabs');
                bar?.querySelectorAll('.wf-param-tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                focusParamSection(tab.dataset.section);
            });
        });
    }

    function resetBranchSubTabs(wf) {
        const barId = { classic: 'wfParamTabsClassic', epw: 'wfParamTabsEpw', sscha: 'wfParamTabsSscha' }[wf];
        const bar = barId ? $('#' + barId) : null;
        if (!bar) return;
        bar.querySelectorAll('.wf-param-tab').forEach((t, i) => t.classList.toggle('active', i === 0));
        // Sections repliées par défaut après le choix du workflow :
        // cliquer un sous-onglet déplie la carte correspondante.
    }

    /* ====================================================================
     *  Helpers DOM
     * ==================================================================== */
    const $  = (sel, ctx = document) => ctx.querySelector(sel);
    const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

    function el(tag, attrs = {}, ...children) {
        const node = document.createElement(tag);
        Object.entries(attrs || {}).forEach(([k, v]) => {
            if (k === 'class')       node.className = v;
            else if (k === 'style')  node.style.cssText = v;
            else if (k === 'html')   node.innerHTML = v;
            else if (k.startsWith('on') && typeof v === 'function')
                node.addEventListener(k.slice(2), v);
            else node.setAttribute(k, v);
        });
        children.flat().forEach(c => {
            if (c == null) return;
            node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
        });
        return node;
    }

    const alertBox = (kind, html) => `<div class="alert alert-${kind}">${html}</div>`;
    const num   = (id, fb = 0)   => { const v = parseFloat($('#' + id)?.value); return Number.isFinite(v) ? v : fb; };
    const intv  = (id, fb = 0)   => { const v = parseInt($('#' + id)?.value, 10); return Number.isFinite(v) ? v : fb; };
    const txt   = (id, fb = '')  => $('#' + id)?.value ?? fb;
    const parseQENum = s => typeof s !== 'string' ? Number(s) : Number(s.replace(/d/i, 'e'));

    /* ====================================================================
     *  Onglets + cartes pliables
     * ==================================================================== */
    function bindTabs() {
        $$('.view-tab').forEach(t => t.addEventListener('click', () => switchMainView(t.dataset.tab)));
    }

    /** Carte auteur : survol géré en CSS, clic pour la garder ouverte (tactile). */
    function bindAuthorCard() {
        const btn = $('#btnAuthorCard');
        const card = $('#shAuthorCard');
        const brand = btn?.closest('.sh-header-brand');
        if (!btn || !card) return;

        const setOpen = open => {
            card.classList.toggle('open', !!open);
            brand?.setAttribute('data-open', open ? 'true' : 'false');
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        };
        btn.addEventListener('click', ev => {
            ev.preventDefault();
            ev.stopPropagation();
            setOpen(!card.classList.contains('open'));
        });
        // Fermer au clic extérieur (après le clic courant, pour éviter la course).
        document.addEventListener('click', ev => {
            if (!card.classList.contains('open')) return;
            if (card.contains(ev.target) || btn.contains(ev.target) || brand?.contains(ev.target)) return;
            setOpen(false);
        });
        document.addEventListener('keydown', ev => {
            if (ev.key === 'Escape') setOpen(false);
        });
    }

    function syncCollapseToggleBtn(card, btn) {
        const open = card.dataset.open === 'true';
        btn.textContent = open ? '▲ Replier' : '▼ Déplier';
        btn.setAttribute('aria-label', open ? 'Replier la section' : 'Déplier la section');
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    }

    function setCollapsibleOpen(card, open) {
        card.dataset.open = open ? 'true' : 'false';
        const btn = card.querySelector('.btn-collapse-toggle');
        if (btn) syncCollapseToggleBtn(card, btn);
        if (open && card.closest('.tab-content[data-tab-content="help"]')) {
            window.setTimeout(() => typesetHelpMath(card), 40);
        }
    }

    /** Rendu MathJax dans l’onglet Aide (formules LaTeX). */
    async function typesetHelpMath(root) {
        const scope = root || document.querySelector('.tab-content[data-tab-content="help"]');
        if (!scope || !window.MathJax?.startup?.promise) return;
        try {
            await window.MathJax.startup.promise;
            if (typeof window.MathJax.typesetClear === 'function') {
                window.MathJax.typesetClear([scope]);
            }
            await window.MathJax.typesetPromise([scope]);
        } catch (e) {
            console.warn('[supra] MathJax Aide', e);
        }
    }

    function bindHelpTheoryDetails() {
        if (bindHelpTheoryDetails._done) return;
        bindHelpTheoryDetails._done = true;
        document.querySelectorAll('.help-theory-details').forEach(det => {
            det.addEventListener('toggle', () => {
                if (det.open) typesetHelpMath(det);
            });
        });
    }

    function ensureCollapseToggleBtn(card) {
        const header = card.querySelector('.collapsible-header');
        if (!header) return;
        const right = header.querySelector('.h-right');
        if (!right) return;

        let ctrl = right.querySelector('.collapse-ctrl');
        if (!ctrl) {
            ctrl = el('div', { class: 'collapse-ctrl' });
            const arrow = right.querySelector(':scope > .arrow');
            if (arrow) {
                right.removeChild(arrow);
                ctrl.appendChild(arrow);
            }
            right.appendChild(ctrl);
        }

        let btn = ctrl.querySelector('.btn-collapse-toggle');
        if (!btn) {
            btn = el('button', {
                type: 'button',
                class: 'btn-collapse-toggle',
            }, '▼ Déplier');
            btn.addEventListener('click', (ev) => {
                ev.stopPropagation();
                setCollapsibleOpen(card, card.dataset.open !== 'true');
            });
            const arrow = ctrl.querySelector('.arrow');
            ctrl.insertBefore(btn, arrow || null);
        }
        syncCollapseToggleBtn(card, btn);
    }

    function collapseScopeRoot(bar) {
        if (bar?.dataset.collapseScope === 'app') return $('#zoneAppFlow');
        return bar?.closest('.tab-content') || document;
    }

    function setAllCollapsibles(open, root) {
        const scope = root || $('#zoneAppFlow') || document;
        $$('.card.collapsible', scope).forEach(c => setCollapsibleOpen(c, open));
    }

    function bindCollapsibles() {
        $$('.card.collapsible').forEach(card => {
            ensureCollapseToggleBtn(card);
            if (card.dataset.collapseBound) return;
            card.dataset.collapseBound = '1';
            const header = card.querySelector('.collapsible-header');
            if (!header) return;
            header.addEventListener('click', (ev) => {
                if (ev.target.closest('button, input, a, select, textarea')) return;
                setCollapsibleOpen(card, card.dataset.open !== 'true');
            });
        });
    }

    function bindCollapseToolbar() {
        $$('[data-collapse-scope]').forEach(bar => {
            if (bar.dataset.collapseToolbarBound) return;
            bar.dataset.collapseToolbarBound = '1';
            const root = collapseScopeRoot(bar);
            bar.querySelector('#btnExpandAll, .btn-expand-all-sections')
                ?.addEventListener('click', () => setAllCollapsibles(true, root));
            bar.querySelector('#btnCollapseAll, .btn-collapse-all-sections')
                ?.addEventListener('click', () => setAllCollapsibles(false, root));
        });
    }

    /* ====================================================================
     *  Toasts + session + API status
     * ==================================================================== */
    function showToast(kind, message, ms = 4200) {
        const host = $('#toastHost');
        if (!host) return;
        const k = ['info', 'success', 'warning', 'error'].includes(kind) ? kind : 'info';
        const t = el('div', { class: `toast toast-${k}`, role: 'status' });
        t.innerHTML = message;
        host.appendChild(t);
        if (typeof SupraI18n !== 'undefined' && SupraI18n.refresh) SupraI18n.refresh(t);
        window.setTimeout(() => {
            t.style.opacity = '0';
            t.style.transition = 'opacity 0.2s ease';
            window.setTimeout(() => t.remove(), 220);
        }, ms);
    }

    /** Remplace alert() pour les blocages UX courants (non bloquant). */
    function notifyUser(message, kind = 'warning') {
        showToast(kind, message);
    }

    function setApiUiState(state, htmlMsg) {
        const dot = $('#apiDot');
        const txtNode = $('#apiStatusText');
        const strip = $('.nav-api-strip');
        if (dot) dot.className = 'status-dot ' + (state === 'ok' || state === 'warn' || state === 'err' || state === 'ping' ? state : '');
        if (strip) strip.setAttribute('data-api-state', state || '');
        if (txtNode && htmlMsg != null) txtNode.innerHTML = htmlMsg;
        document.body?.setAttribute('data-api', state === 'ok' || state === 'warn' ? 'online' : (state === 'ping' ? 'ping' : 'offline'));
        updateSessionProgress();
    }

    function updateSessionProgress() {
        const chipMat = $('#chipMaterial');
        const chipWf = $('#chipWorkflow');
        const chipApi = $('#chipApi');
        const setChip = (sel, state) => {
            const c = document.querySelector(`.session-chip[data-chip="${sel}"]`);
            if (c) c.setAttribute('data-state', state);
        };
        if (chipMat) {
            chipMat.textContent = APP.material || '—';
            setChip('material', APP.material ? 'ready' : 'warn');
        }
        if (chipWf) {
            const label = APP.workflow
                ? (WORKFLOW_LABEL[APP.workflow]?.name || APP.workflow)
                : '—';
            chipWf.textContent = label;
            setChip('workflow', APP.workflow ? 'ready' : 'warn');
        }
        if (chipApi) {
            if (APP.apiOnline) {
                const warn = APP._health && !(APP._health.qe?.classic_ok !== false && APP._health.qe_bin_dir);
                chipApi.textContent = warn ? 'QE incomplet' : 'en ligne';
                setChip('api', warn ? 'warn' : 'ready');
            } else {
                chipApi.textContent = 'hors ligne';
                setChip('api', 'off');
            }
        }
    }

    async function pingAPI() {
        setApiUiState('ping', "Connexion à l'API Supra-QE…");

        let r = null;
        try {
            r = await SupraAPI.health();
        } catch (_) {
            r = null;
        }
        if (r && r.service === 'supra-qe') {
            APP.apiOnline = true;
            const qe = r.qe_bin_dir ? `(QE bin : ${r.qe_bin_dir})` : '(⚠️ aucun binaire QE détecté)';
            const classicOk = r.qe?.classic_ok !== false && r.qe_bin_dir;
            if (r.pseudos_dir || r.pseudo_dir_rel) {
                const fld = $('#fld_pseudo_dir');
                if (fld && !fld.dataset.touched) {
                    fld.value = r.pseudos_dir ? normalizeQeDir(r.pseudos_dir) : r.pseudo_dir_rel;
                }
            }
            setApiUiState(
                classicOk ? 'ok' : 'warn',
                `API en ligne · <span class="mono muted">${SupraAPI.getBaseURL()}</span> ${qe}`
            );
            APP._health = r;
            applyHostParallel({ force: false });
            updateBinaryNotice();
            if (typeof renderServerPathInfo === 'function') renderServerPathInfo();
        } else {
            APP.apiOnline = false;
            APP._health = null;
            setApiUiState('err', `API injoignable. Lancer <code>./DEMARRER.sh</code>.`);
            updateBinaryNotice();
        }
    }

    let _apiPollTimer = null;
    function startApiWatchdog() {
        if (_apiPollTimer) return;
        _apiPollTimer = window.setInterval(() => {
            if (document.hidden) return;
            pingAPI();
        }, 30000);
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) pingAPI();
        });
    }

    /** Binaire QE requis par une étape ; null si l'API n'a pas encore répondu. */
    function binaryAvailable(prog) {
        const found = APP._health?.qe?.found;
        if (!found || !(prog in found)) return null;
        return !!found[prog];
    }

    /**
     * Prévient dès le choix du workflow si un binaire manque, au lieu de laisser
     * l'utilisateur découvrir l'absence d'epw.x après des heures de ph.x.
     */
    function updateBinaryNotice() {
        const box = $('#wfBinaryNotice');
        if (!box) return;
        const found = APP._health?.qe?.found;
        if (!found) { box.style.display = 'none'; box.innerHTML = ''; return; }

        const missing = { classic: [], epw: [] };
        ['classic', 'epw'].forEach(wf => {
            calcStepsForRun(wf).forEach(c => {
                if (binaryAvailable(c.prog) === false && !missing[wf].includes(c.prog)) {
                    missing[wf].push(c.prog);
                }
            });
        });
        if (!missing.classic.length && !missing.epw.length) {
            box.style.display = 'none';
            box.innerHTML = '';
            return;
        }
        const lines = [];
        if (missing.classic.length) lines.push(`<li><strong>WF1 Classique</strong> : ${missing.classic.map(p => `<code>${p}</code>`).join(', ')} introuvable(s)</li>`);
        if (missing.epw.length)     lines.push(`<li><strong>WF2 EPW</strong> : ${missing.epw.map(p => `<code>${p}</code>`).join(', ')} introuvable(s)</li>`);
        box.style.display = 'block';
        box.innerHTML = alertBox('warning',
            `<strong>Binaires QE manquants sur cette machine</strong><ul style="margin:8px 0 0; padding-left:20px;">${lines.join('')}</ul>` +
            `Les inputs restent générables (bouton 🖥️ Terminal pour lancer ailleurs), mais l'exécution depuis l'interface échouera à ces étapes. ` +
            `Indique le bon dossier via <code>QE_BIN_DIR</code> si les binaires existent ailleurs.`);
    }

    /* ====================================================================
     *  Chemins éditables (autre PC / autre dépôt)
     * ==================================================================== */
    const PATHS_LS_KEY = 'supra_qe_paths_v1';

    function defaultApiBase() {
        if (typeof SupraAPI !== 'undefined' && SupraAPI.getBaseURL) return SupraAPI.getBaseURL();
        if (typeof location !== 'undefined' && location.protocol === 'http:') return location.origin;
        return 'http://127.0.0.1:8765';
    }

    function loadStoredPaths() {
        try {
            return JSON.parse(localStorage.getItem(PATHS_LS_KEY) || '{}') || {};
        } catch {
            return {};
        }
    }

    function saveStoredPaths(patch) {
        const cur = { ...loadStoredPaths(), ...patch };
        try { localStorage.setItem(PATHS_LS_KEY, JSON.stringify(cur)); } catch { /* private mode */ }
        return cur;
    }

    /** Remplit les champs nav à partir des champs métier (+ stockage local). */
    function fillPathsNavForm() {
        const stored = loadStoredPaths();
        const set = (id, val) => { const el = $(id); if (el && val != null) el.value = val; };
        set('#fld_api_base', stored.api_base || defaultApiBase());
        set('#fld_api_token', stored.api_token || (typeof SupraAPI.getApiToken === 'function' ? SupraAPI.getApiToken() : ''));
        set('#fld_path_inputs_nav', stored.inputs || txt('fld_path_inputs', APP.material ? `inputs/${APP.material}` : 'inputs'));
        set('#fld_path_workflow_nav', stored.workflow || txt('fld_path_workflow',
            APP.material && APP.workflow ? `inputs/${APP.material}/${APP.workflow}` : ''));
        set('#fld_path_outputs_nav', stored.outputs || txt('fld_path_outputs',
            APP.material && APP.workflow ? `outputs/${APP.material}/${APP.workflow}` : ''));
        set('#fld_pseudo_dir_nav', stored.pseudos || txt('fld_pseudo_dir', '../../../pseudos/'));
    }

    function renderServerPathInfo() {
        const box = $('#pathsServerInfo');
        if (!box) return;
        const h = APP._health || {};
        if (!APP.apiOnline) {
            box.innerHTML = `<div class="path-row"><span class="path-label">état</span>`
                + `<span class="path-value">API injoignable — vérifie l’URL ci-dessus</span></div>`;
            return;
        }
        box.innerHTML = `
            <div class="path-row"><span class="path-label">API</span><span class="path-value">${escapeHtml(SupraAPI.getBaseURL())}</span></div>
            <div class="path-row"><span class="path-label">inputs (serveur)</span><span class="path-value">${escapeHtml(h.inputs_dir || '—')}</span></div>
            <div class="path-row"><span class="path-label">outputs (serveur)</span><span class="path-value">${escapeHtml(h.outputs_dir || '—')}</span></div>
            <div class="path-row"><span class="path-label">pseudos (serveur)</span><span class="path-value">${escapeHtml(h.pseudos_dir || '—')}</span></div>
            <div class="path-row"><span class="path-label">qe_bin</span><span class="path-value">${escapeHtml(h.qe_bin_dir || '(non détecté)')}</span></div>
            <div class="path-row"><span class="path-label">mpirun</span><span class="path-value">${escapeHtml(h.mpirun || '(non détecté)')}</span></div>
        `;
    }

    function setPathsNavStatus(html, kind = 'muted') {
        const box = $('#pathsNavStatus');
        if (!box) return;
        box.className = `paths-nav-status ${kind}`;
        box.innerHTML = html;
    }

    function togglePaths(forceOpen) {
        const box = $('#pathsBox');
        if (!box) return;
        const open = typeof forceOpen === 'boolean' ? forceOpen : box.classList.contains('hidden');
        if (open) {
            fillPathsNavForm();
            renderServerPathInfo();
            box.classList.remove('hidden');
            $('#btnShowPaths')?.classList.add('active');
        } else {
            box.classList.add('hidden');
            $('#btnShowPaths')?.classList.remove('active');
        }
    }

    /**
     * Applique URL API + dossiers saisis. Les chemins relatifs restent sous le
     * dépôt servi par l’API (autre PC = autre API + ses propres inputs/outputs).
     */
    async function applyPathsFromNav() {
        const apiBase = ($('#fld_api_base')?.value || '').trim().replace(/\/$/, '');
        const apiToken = ($('#fld_api_token')?.value || '').trim();
        const inputs = ($('#fld_path_inputs_nav')?.value || '').trim().replace(/\/$/, '');
        const workflow = ($('#fld_path_workflow_nav')?.value || '').trim().replace(/\/$/, '');
        const outputs = ($('#fld_path_outputs_nav')?.value || '').trim().replace(/\/$/, '');
        const pseudos = ($('#fld_pseudo_dir_nav')?.value || '').trim();

        if (!apiBase) {
            setPathsNavStatus(alertBox('warning', 'Indique l’URL de l’API (ex. <code>http://192.168.1.20:8765</code>).'));
            return;
        }
        try {
            // Validation légère de l’URL
            // eslint-disable-next-line no-new
            new URL(apiBase);
        } catch {
            setPathsNavStatus(alertBox('error', 'URL API invalide.'));
            return;
        }

        SupraAPI.setBaseURL(apiBase);
        if (typeof SupraAPI.setApiToken === 'function') SupraAPI.setApiToken(apiToken);
        const mark = (id, val) => {
            const el = $(id);
            if (!el) return;
            if (val) { el.value = val; el.dataset.touched = '1'; }
        };
        mark('#fld_path_inputs', inputs);
        mark('#fld_path_workflow', workflow);
        mark('#fld_path_outputs', outputs);
        mark('#fld_pseudo_dir', pseudos);

        saveStoredPaths({ api_base: apiBase, api_token: apiToken, inputs, workflow, outputs, pseudos });
        APP.baseDir = getMaterialBaseDir();
        setPathsNavStatus('Connexion à l’API…');
        await pingAPI();
        renderServerPathInfo();
        if (APP.apiOnline) {
            setPathsNavStatus(alertBox('success',
                `Connecté à <code>${escapeHtml(apiBase)}</code>`
                + (inputs ? ` · inputs <code>${escapeHtml(inputs)}</code>` : '')
                + (outputs ? ` · outputs <code>${escapeHtml(outputs)}</code>` : '')));
            if (APP.workflow) {
                invalidateWorkflowFiles();
                await renderCalcList();
                await refreshChainStatus();
            }
        } else {
            setPathsNavStatus(alertBox('error',
                `Impossible de joindre <code>${escapeHtml(apiBase)}</code>. `
                + 'Sur la machine cible : <code>./DEMARRER.sh</code>, et autorise le port (pare-feu).'));
        }
    }

    function resetPathsToLocal() {
        try { localStorage.removeItem(PATHS_LS_KEY); } catch { /* */ }
        const base = (typeof location !== 'undefined' && location.protocol === 'http:')
            ? location.origin : 'http://127.0.0.1:8765';
        SupraAPI.setBaseURL(base);
        ['#fld_path_inputs', '#fld_path_workflow', '#fld_path_outputs'].forEach(sel => {
            const el = $(sel);
            if (el) { delete el.dataset.touched; }
        });
        if (APP.material) syncMaterialPathField();
        updatePathFields();
        const pe = $('#fld_pseudo_dir');
        if (pe) pe.value = '../../../pseudos/';
        fillPathsNavForm();
        setPathsNavStatus(alertBox('info', `Défauts locaux restaurés (<code>${escapeHtml(base)}</code>). Clique <strong>Appliquer &amp; tester</strong>.`));
        renderServerPathInfo();
    }

    /** Au démarrage : restaure l’URL API et les dossiers mémorisés.
     *  Priorité : ?api=http://… dans l’URL > localStorage > origine courante.
     */
    function restorePathsFromStorage() {
        const s = loadStoredPaths();
        let apiFromUrl = '';
        try {
            apiFromUrl = new URLSearchParams(location.search).get('api') || '';
        } catch { /* */ }
        if (apiFromUrl) {
            try {
                const u = new URL(apiFromUrl);
                apiFromUrl = u.origin;
                SupraAPI.setBaseURL(apiFromUrl);
                s.api_base = apiFromUrl;
                saveStoredPaths({ api_base: apiFromUrl });
            } catch {
                apiFromUrl = '';
            }
        } else if (s.api_base) {
            SupraAPI.setBaseURL(s.api_base);
        }
        if (s.api_token && typeof SupraAPI.setApiToken === 'function') {
            SupraAPI.setApiToken(s.api_token);
        }
        const mark = (id, val) => {
            const el = $(id);
            if (el && val) { el.value = val; el.dataset.touched = '1'; }
        };
        mark('#fld_path_inputs', s.inputs);
        mark('#fld_path_workflow', s.workflow);
        mark('#fld_path_outputs', s.outputs);
        mark('#fld_pseudo_dir', s.pseudos);
    }

    function bindPathsEditor() {
        $('#btnShowPaths')?.addEventListener('click', () => togglePaths());
        $('#btnClosePaths')?.addEventListener('click', () => togglePaths(false));
        $('#btnApplyPathsNav')?.addEventListener('click', applyPathsFromNav);
        $('#btnResetPathsNav')?.addEventListener('click', resetPathsToLocal);
        // Marquer comme « touchés » pour ne pas écraser un choix manuel
        ['#fld_path_workflow', '#fld_path_outputs', '#fld_path_inputs', '#fld_pseudo_dir'].forEach(sel => {
            $(sel)?.addEventListener('input', () => { $(sel).dataset.touched = '1'; });
        });
    }

    /* ====================================================================
     *  ÉTAPE 2 — Choix du workflow (après matériau)
     * ==================================================================== */
    function bindWorkflowPicker() {
        $$('#workflowPicker .workflow-card').forEach(card => {
            card.addEventListener('click', () => {
                window.SupraSelectWorkflow(card.dataset.workflow);
            });
        });
        $$('.org-branch[data-wf]').forEach(branch => {
            branch.addEventListener('click', () => {
                window.SupraSelectWorkflow(branch.dataset.wf);
            });
        });
    }

    /*
     * Sélection de workflow sérialisée. Une passe enchaîne plusieurs await
     * (prérequis, génération, vérification de la chaîne) : laisser deux clics
     * rapprochés la relancer en parallèle mélangeait les états — badges figés,
     * boutons de lancement désactivés — voire saturait l'onglet. Une seule passe
     * s'exécute donc à la fois, et seule la dernière demande est honorée.
     */
    let wfSelectQueue = Promise.resolve();
    let wfSelectTarget = null;

    window.SupraSelectWorkflow = function (wf) {
        if (!(wf in CALCS)) return Promise.resolve();
        if (!APP.material) {
            notifyUser("Sélectionne d'abord un matériau (étape 1).");
            return Promise.resolve();
        }
        wfSelectTarget = wf;
        wfSelectQueue = wfSelectQueue
            .then(() => (wfSelectTarget === wf ? applyWorkflowSelection(wf) : null))
            .catch(err => console.error('[supra] sélection du workflow', err));
        return wfSelectQueue;
    };

    async function applyWorkflowSelection(wf) {
        const stale = () => wfSelectTarget !== wf;

        APP.workflow = wf;
        invalidateWorkflowFiles();
        $$('.workflow-card').forEach(c => c.classList.toggle('active', c.dataset.workflow === wf));
        highlightOrganigram(wf);

        // Section prérequis masquée : le workflow démarre d'un input scf
        // (vc-relax déjà fait) — la vérification tourne en arrière-plan.

        const label = WORKFLOW_LABEL[wf];
        $('#etape2Title').textContent = `Programmes — ${label.name}`;
        $('#etapeWorkflowTitle').textContent = `« ${APP.material} » — ${label.name}`;
        const titleEl = $('#etape3VoieTitle');
        if (titleEl) titleEl.textContent = label.name;
        const chain = CALCS[wf].map(c => c.prog).filter((p, i, a) => a.indexOf(p) === i).join(' → ');
        const desc = $('#etape3VoieDesc');
        if (desc) desc.textContent = `${label.name} : ${chain}`;

        updatePathFields();
        renderMaterialInfo();
        renderWorkflowBanner();

        applyBranchVisibility(wf);
        resetBranchSubTabs(wf);
        applyMainViewPart();
        syncMaterialPathField();
        await checkPrereqOutputs();
        if (stale()) return;
        updateFluxEtapes();

        renderPipeline();
        await renderCalcList();
        if (stale()) return;
        await refreshChainStatus();
        if (stale()) return;
        if (APP.chain?.steps?.scf?.shared) {
            notifyUser('SCF déjà réalisé sur l\'autre voie — densité réutilisée, passe à l\'étape suivante.', 'success');
        }
        updateCPUInfo();
        bindCollapsibles();

        const scrollTarget = APP.mainView === 'resultats' ? '#zoneWfResultats' : '#zoneWfCalculs';
        scrollToView(scrollTarget, { block: 'nearest' });

        if (RES.data && getResultsRouteView() === 'active') {
            renderIdentityBar();
            renderKpiStrip();
            renderSynthesis();
        }
    }

    function renderMaterialInfo() {
        const box = $('#zoneMateriauInfo');
        if (!box || !APP.material) return;
        box.style.display = 'block';
        const wfTxt = APP.workflow
            ? `<strong style="color:${WORKFLOW_LABEL[APP.workflow].stepColor};">${WORKFLOW_LABEL[APP.workflow].name}</strong>`
            : '<span class="muted">— configure les pseudos (1b) puis un workflow —</span>';
        box.innerHTML = `
            <div style="background: linear-gradient(135deg, #ecfeff, #cffafe); padding: 16px 20px; border-radius: 12px; border-left: 4px solid var(--supra);">
                <h5 style="margin: 0 0 4px 0; color: var(--supra-dark);">🧪 Matériau actif</h5>
                <p style="margin: 0; color: #155e75; font-size: 1.05em;">
                    <strong>${APP.material}</strong> · workflow : ${wfTxt}
                </p>
            </div>`;
    }

    /* ====================================================================
     *  ÉTAPE 1 — Choix et validation du matériau
     * ==================================================================== */
    function bindSearchMaterial() {
        const champ = $('#champ_materiau');
        $('#btnValiderMateriau')?.addEventListener('click', validerChoixMateriau);
        champ?.addEventListener('keypress', e => { if (e.key === 'Enter') validerChoixMateriau(); });
        $('#btnImportRelax')?.addEventListener('click', () => $('#fld_relax_file')?.click());
        $('#fld_relax_file')?.addEventListener('change', handleRelaxUpload);
        $('#btnCheckPrereqs')?.addEventListener('click', verifyPrereqs);
        $('#fld_path_inputs')?.addEventListener('input', () => {
            const fi = $('#fld_path_inputs');
            if (fi) fi.dataset.touched = '1';
            APP.baseDir = getMaterialBaseDir();
            updatePrereqExpectedLabels();
        });
    }

    function updateScfPrereqBadge(done) {
        const b = $('#scfPrereqBadge');
        if (!b) return;
        if (done) {
            b.textContent = 'scf de contrôle : OK';
            b.style.background = 'var(--success)';
        } else {
            b.textContent = 'scf de contrôle : absent (optionnel)';
            b.style.background = '#94a3b8';
        }
    }

    function updatePrereqFlowChart() {
        const setActive = (id, on) => { const n = $(id); if (n) n.classList.toggle('active', !!on); };
        setActive('#pfVcrelax', APP.prereq?.relaxDone);
        setActive('#pfScf', APP.prereq?.scfDone);
        setActive('#pfReady', prereqsReady());
        updatePrereqSectionBadge();
    }

    function updatePrereqSectionBadge() {
        if (APP.structure) setBadge('prereqs', 'ok', 'structure OK');
        else if (APP.prereq?.relaxDone) setBadge('prereqs', 'ok', 'structure OK');
        else setBadge('prereqs', 'warn', 'SCF manquant');
    }

    /** Reporte les cutoffs lus dans vc-relax.out sur la carte SCF. */
    function applyStructureCutoffs(struct) {
        if (struct?.ecutwfc) { const e = $('#fld_ecutwfc'); if (e) e.value = struct.ecutwfc; }
        if (struct?.ecutrho) { const e = $('#fld_ecutrho'); if (e) e.value = struct.ecutrho; }
    }

    /** Reprend ecut, smearing, grille k et conv_thr d'un input SCF utilisateur. */
    function applyScfInputToForm(text) {
        if (!text) return;
        const setv = (sel, v) => { const e = $(sel); if (e && v != null && v !== '') e.value = v; };
        const numFrom = (re) => {
            const m = text.match(re);
            return m ? Number(String(m[1]).replace(/d/i, 'e')) : null;
        };
        const ecutw = numFrom(/\becutwfc\s*=\s*([\d.eEdD+\-]+)/i);
        const ecutr = numFrom(/\becutrho\s*=\s*([\d.eEdD+\-]+)/i);
        if (Number.isFinite(ecutw)) setv('#fld_ecutwfc', Math.round(ecutw));
        if (Number.isFinite(ecutr)) setv('#fld_ecutrho', Math.round(ecutr));
        const sm = text.match(/\bsmearing\s*=\s*'?([A-Za-z_]+)/i);
        if (sm) setv('#fld_smearing', sm[1]);
        const dg = numFrom(/\bdegauss\s*=\s*([\d.eEdD+\-]+)/i);
        if (Number.isFinite(dg)) setv('#fld_degauss', dg);
        const ct = text.match(/\bconv_thr\s*=\s*([^\s,\/'!]+)/i);
        if (ct) setv('#fld_conv_scf', ct[1].replace(/['"]/g, ''));
        const kp = text.match(/K_POINTS\s+automatic[^\n]*\n\s*(\d+)\s+(\d+)\s+(\d+)/i);
        if (kp) {
            setv('#fld_kscf_1', kp[1]);
            setv('#fld_kscf_2', kp[2]);
            setv('#fld_kscf_3', kp[3]);
        }
        if (typeof SupraInputs !== 'undefined') {
            setv('#fld_mag_mode', SupraInputs.detectMagModeFromScfText(text));
            const mags = SupraInputs.parseStartingMagFromScfText(text);
            if (mags.length) setv('#fld_starting_mag', mags.join(', '));
        }
        updateMagnetismHint();
    }

    function updateMagnetismHint() {
        const box = $('#magnetismHint');
        if (!box) return;
        const mode = typeof SupraInputs !== 'undefined'
            ? SupraInputs.normalizeMagMode(txt('fld_mag_mode', 'none'))
            : txt('fld_mag_mode', 'none');
        if (mode === 'none') {
            box.style.display = 'none';
            box.innerHTML = '';
            return;
        }
        box.style.display = 'block';
        const labels = {
            collinear: 'Spin collinéaire (nspin=2) — SCF/NSCF (WF1+WF2) ; ph.x via le save. WF2 EPW 6.1 : epw.in avec lsda + α²F (pas Tc Éliashberg LSDA).',
            noncollinear: 'Non collinéaire (nspin=4) — idem SCF/NSCF ; pseudos et coût CPU adaptés ; suite ph/EPW : doc QE/EPW.',
            soc: 'Spin-orbite (lspinorb) — SCF/NSCF + pseudos FR ; EPW et phonons magnétiques à valider matériau par matériau.',
        };
        box.className = 'alert alert-warning';
        box.innerHTML = `<strong>Magnétisme v1.4 — ${mode}</strong> · ${labels[mode] || ''} `
            + `Valeurs <code>starting_magnetization</code> : une par espèce atomique (ordre ATOMIC_SPECIES).`;
    }

    function stepFileName(calc) {
        return APP.files?.[APP.workflow]?.[calc.type]?.name
            || `${APP.material}.${calc.type}.in`;
    }

    /** Chemin réellement lancé / édité : dossier du workflow. */
    function stepInputPath(calc) {
        return `${getWorkflowPaths().workDir}/${stepFileName(calc)}`;
    }

    /** Noms d'input SCF reconnus dans inputs/<matériau>/ (convention QE + variantes courantes). */
    function scfInputCandidateNames(mat) {
        if (!mat) return ['scf.in'];
        const lower = String(mat).toLowerCase();
        return [...new Set([
            `${mat}.scf.in`,
            `${lower}.scf.in`,
            `${mat}.scf_prereq.in`,
            `${lower}_scf.in`,
            `${mat}_scf.in`,
            'scf.in',
        ])];
    }

    async function findUserScfInput() {
        if (!APP.apiOnline || !APP.material) return null;
        const mat = APP.material;
        const names = scfInputCandidateNames(mat);
        const bases = [];
        const seen = new Set();
        [getMaterialBaseDir(), `inputs/${mat}`].forEach(b => {
            const n = (b || '').replace(/\/$/, '');
            if (n && !seen.has(n)) { seen.add(n); bases.push(n); }
        });
        for (const base of bases) {
            const found = await findPrereqOutput(base, names);
            if (found) return found;
        }
        return null;
    }

    function parseQeNamelistStr(text, key) {
        if (!text) return null;
        const reQ = new RegExp(`\\b${key}\\s*=\\s*['"]([^'"]+)['"]`, 'i');
        const reB = new RegExp(`\\b${key}\\s*=\\s*([^\\s,!/'"]+)`, 'i');
        const m = text.match(reQ) || text.match(reB);
        return m ? String(m[1]).trim() : null;
    }

    /** Remplace outdir / pseudo_dir dans une copie SCF (dossier workflow), sans toucher le fichier utilisateur. */
    function patchScfControlPaths(content) {
        if (!content) return content;
        const { outdir, pseudo_dir } = resolveQePathsForGeneration();
        let out = String(content);
        const setKey = (key, val) => {
            if (!val) return;
            const v = String(val).replace(/'/g, "''");
            const reQ = new RegExp(`(\\b${key}\\s*=\\s*)['"][^'"]*['"]`, 'i');
            const reB = new RegExp(`(\\b${key}\\s*=\\s*)[^\\s,!/'"]+`, 'i');
            if (reQ.test(out)) out = out.replace(reQ, `$1'${v}'`);
            else if (reB.test(out)) out = out.replace(reB, `$1'${v}'`);
            else if (/&CONTROL/i.test(out)) {
                out = out.replace(/(&CONTROL[^\n]*\n)/i, `$1    ${key} = '${v}'\n`);
            }
        };
        setKey('outdir', outdir);
        setKey('pseudo_dir', pseudo_dir);
        return out;
    }

    function qePathsStatusHtml() {
        const p = resolveQePathsForGeneration();
        return `<code>outdir</code> <span class="mono">${escapeHtml(p.outdir)}</span> · `
            + `<code>pseudo_dir</code> <span class="mono">${escapeHtml(p.pseudo_dir)}</span>`;
    }

    /** prefix, outdir, pseudo_dir du SCF utilisateur — repris tels quels pour tout le workflow. */
    function applyScfControl(text) {
        if (!text) return;
        const prefix = parseQeNamelistStr(text, 'prefix') || APP.material;
        const outdir = parseQeNamelistStr(text, 'outdir');
        const pdir   = parseQeNamelistStr(text, 'pseudo_dir');
        APP.scfCtl = {
            prefix: prefix || APP.material,
            outdir: outdir || defaultQeOutdir(),
            pseudo_dir: pdir || defaultQePseudoDir(),
        };
        const e = $('#fld_pseudo_dir');
        if (e && APP.scfCtl.pseudo_dir) e.value = APP.scfCtl.pseudo_dir;
        applyScfInputToForm(text);
    }

    function scfInputLooksNonNc(content) {
        return /\b(kjpaw|paw_psl|paw|rrkjus|uspp)\b/i.test(content || '');
    }

    function escapeRe(s) {
        return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    /**
     * Si ATOMIC_SPECIES nomme un .UPF absent (ou PAW/USPP), le remplacer par
     * un NC du même élément présent dans pseudos/ — ce que QE lira vraiment.
     */
    async function remapSpeciesToExistingNc(content) {
        if (!content || !APP.apiOnline) return content;
        const m = content.match(/ATOMIC_SPECIES\s*\n((?:\s*\S+\s+[\d.eEdD+\-]+\s+\S+\s*\n?)+)/i);
        if (!m) return content;
        const names = [];
        m[1].trim().split('\n').forEach(line => {
            const p = line.trim().split(/\s+/);
            if (p.length >= 3) names.push(p[2]);
        });
        if (!names.length) return content;
        const r = await SupraAPI.checkPseudos(names, 'pseudos/');
        if (!r?.results) return content;
        let out = content;
        r.results.forEach(res => {
            if (res.resolved_from && res.name && res.resolved_from !== res.name) {
                out = out.replace(new RegExp('\\b' + escapeRe(res.resolved_from) + '\\b', 'g'), res.name);
            }
        });
        return out;
    }

    async function refreshAdoptedScf(files) {
        if (!files?.scf) return files;
        const userScf = await findUserScfInput();
        if (!userScf) return files;
        // Le SCF utilisateur est la source unique : on le recopie tel quel.
        let content = userScf.content;
        content = await remapSpeciesToExistingNc(content);
        applyScfControl(content);
        content = patchScfControlPaths(content);
        files.scf.content = content;
        files.scf.originPath = userScf.path;
        files.scf.aligned = true;
        const s = extractStructureFromText(content);
        if (s) {
            s._material = APP.material;
            APP.structure = s;
            applyStructureCutoffs(s);
        }
        // Les autres inputs sont générés en héritant prefix / outdir / pseudo_dir.
        if (APP.workflow && APP.structure) {
            const regenerated = SupraInputs.genererFichiersWorkflow(gatherParams(), APP.workflow);
            Object.keys(files).forEach(k => {
                if (k === 'scf' || !regenerated[k]) return;
                files[k].content = regenerated[k].content;
                files[k].name = regenerated[k].name;
            });
        }
        return files;
    }

    /** NSCF : Davidson plante (cdiaghg / S not PD). Forcer CG + nbnd avant écriture. */
    function hardenNscfContent(text) {
        if (!text) return text;
        let out = String(text).replace(/diagonalization\s*=\s*'david'/ig, "diagonalization = 'cg'");
        if (!/\bnbnd\s*=/i.test(out)) {
            if (/\bla2F\s*=/i.test(out)) {
                out = out.replace(/(\bla2F\s*=\s*\.true\.\s*)/i, '$1\n    nbnd = 24');
            } else {
                out = out.replace(/(\n\/\s*\n\s*&ELECTRONS)/i, '\n    nbnd = 24$1');
            }
        }
        return out;
    }

    /** Écrit la suite générée dans le dossier du workflow (pas le SCF utilisateur). */
    async function persistWorkflowFiles(files) {
        if (!APP.apiOnline || !files) return { ok: false, saved: 0, failed: [{ key: '*', err: 'API hors ligne' }] };
        const paths = getWorkflowPaths();
        const failed = [];
        let saved = 0;
        for (const [key, f] of Object.entries(files)) {
            if (!f?.name || f.content == null) continue;
            if (f.optional || f.skipRun) continue;
            // SCF utilisateur : uniquement une copie de travail pour le lancement.
            // Un SCF généré (sans originPath) ne doit pas écraser le fichier source.
            if (key === 'scf' && !f.originPath) continue;
            if (key === 'nscf' && f.content) f.content = hardenNscfContent(f.content);
            const dest = `${paths.workDir}/${f.name}`;
            if (f.originPath && dest === f.originPath) continue;
            const r = await SupraAPI.saveFile(dest, f.content);
            if (r?.ok) saved++;
            else failed.push({ key, name: f.name, err: r?.error || `HTTP ${r?.status || '?'}` });
        }
        return { ok: failed.length === 0, saved, failed };
    }

    /**
     * Cherche la première sortie lisible parmi `names`. L'absence de `JOB DONE`
     * n'écarte pas le fichier : elle est remontée via `jobDone` pour être
     * signalée sans bloquer un travail par ailleurs exploitable.
     */
    async function findPrereqOutput(base, names) {
        for (const name of names) {
            const path = `${base}/${name}`;
            const r = await SupraAPI.readFile(path);
            if (r?.ok && r.content) {
                return { path, content: r.content, jobDone: /JOB DONE/i.test(r.content) };
            }
        }
        return null;
    }

    /**
     * Relit les prérequis sur disque. L'état n'est publié qu'à la fin : effacer
     * les drapeaux au démarrage laisserait, le temps des requêtes, une fenêtre
     * où l'interface se croit sans structure et désactive les lancements.
     */
    async function checkPrereqOutputs() {
        if (!APP.material) return;
        APP.baseDir = getMaterialBaseDir();
        const base = APP.baseDir;
        const mat = APP.material;
        const found = { relaxDone: false, relaxFound: false, relaxJobDone: false,
                        scfDone: false, relaxPath: '', scfPath: '' };
        let structure = null;

        const relax = await findPrereqOutput(base, [
            `${mat}.vc-relax.out`, `${mat}.relax.out`, 'vc-relax.out', 'relax.out',
        ]);
        if (relax) {
            found.relaxFound = true;
            found.relaxPath = relax.path;
            found.relaxJobDone = relax.jobDone;
            const s = extractStructureFromText(relax.content);
            if (s) {
                s._material = mat;
                structure = s;
                // Le critère réel est l'extraction de la structure : un badge vert
                // sans structure exploitable laisserait la génération échouer plus loin.
                found.relaxDone = true;
            }
        }

        // Pas de vc-relax.out exploitable : le flux démarre d'un input scf déjà
        // relaxé (paramètres optimisés) — on y lit directement la structure.
        if (!structure) {
            const scfIn = await findUserScfInput();
            if (scfIn) {
                const s = extractStructureFromText(scfIn.content);
                if (s) {
                    s._material = mat;
                    structure = s;
                    found.relaxDone = true;
                    found.relaxFound = true;
                    found.relaxJobDone = true;   // input scf ⇒ structure déjà relaxée
                    found.relaxPath = scfIn.path;
                }
            }
        }

        const scf = await findPrereqOutput(base, [
            `${mat}.scf.out`, `${mat}.scf_prereq.out`, 'scf.out',
        ]) || await findPrereqOutput(`outputs/${mat}`, [
            `${mat}.scf.out`, `${mat}.scf_prereq.out`,
        ]);
        if (scf) {
            found.scfDone = !!scf.jobDone;
            found.scfPath = scf.path;
        }

        if (APP.material !== mat) return;   // un autre matériau a été validé entre-temps
        Object.assign(APP.prereq, found);
        if (structure) {
            APP.structure = structure;
            applyStructureCutoffs(structure);
        }
        const userScf = await findUserScfInput();
        if (userScf) applyScfControl(userScf.content);

        updateRelaxBadge(APP.prereq.relaxDone);
        updateScfPrereqBadge(APP.prereq.scfDone);
        updatePrereqFlowChart();
        renderPrereqStatusMessage();
        updateFluxEtapes();
    }

    function renderPrereqStatusMessage() {
        const el = $('#prereqStatus');
        if (!el || !APP.material) return;
        const base = APP.baseDir || `inputs/${APP.material}`;
        const mat = APP.material;

        if (!APP.structure) {
            el.innerHTML = alertBox('warning',
                `<strong>Géométrie de référence absente</strong> — ` +
                `dépose <code>${mat}.scf.in</code> (ou <code>${mat.toLowerCase()}_scf.in</code>) dans <code>${base}/</code> ` +
                `avec namelists QE et cartes <code>ATOMIC_*</code> (géométrie déjà relaxée). ` +
                `Ce fichier alimente WF1 et WF2.`);
            return;
        }
        const src = APP.prereq.relaxPath || `${base}/${mat}.scf.in`;
        el.innerHTML = alertBox('success',
            `✅ Géométrie exploitable — ${APP.structure?.positions?.length || 0} atome(s), ` +
            `${APP.structure?.species?.length || 0} espèce(s)` +
            `${APP.structure?.ibrav != null ? `, ibrav = ${APP.structure.ibrav}` : ''}` +
            `${APP.structure?.ecutwfc ? `, E<sub>cut</sub> = ${APP.structure.ecutwfc} Ry` : ''}<br>` +
            `Source : <code>${src}</code>`);
    }

    async function verifyPrereqs() {
        if (!APP.material) {
            setPrereqStatus('warning', 'Valide d\'abord le matériau.');
            return;
        }
        APP.baseDir = getMaterialBaseDir();
        await checkPrereqOutputs();
        const card = $('#zoneWfPrerequis');
        if (card) card.dataset.open = 'true';
    }

    const setPrereqStatus = (kind, html) => {
        const el = $('#prereqStatus');
        if (el) el.innerHTML = alertBox(kind, html);
    };

    function updateRelaxBadge(hasRelax) {
        const b = $('#relaxStatusBadge');
        if (!b) return;
        if (hasRelax) {
            b.textContent = APP.prereq?.relaxJobDone ? 'vc-relax : OK' : 'vc-relax : structure lue (sans JOB DONE)';
            b.style.background = APP.prereq?.relaxJobDone ? 'var(--success)' : 'var(--warning)';
        } else {
            b.textContent = APP.prereq?.relaxFound ? 'vc-relax : illisible' : 'vc-relax : manquant';
            b.style.background = 'var(--warning)';
        }
    }

    async function validerChoixMateriau() {
        const q = $('#champ_materiau')?.value.trim();
        if (!q) {
            renderSearchEmpty('Entre un nom de matériau (ex : Nb, MgB2).');
            return;
        }

        if (APP.apiOnline) {
            const r = await SupraAPI.searchMaterial(q);
            if (!r || !r.ok) {
                renderSearchEmpty('Erreur lors de la validation du matériau.');
                return;
            }
            if (r.found) {
                renderSearchResults(q, r);
                await selectMaterial(r.name, { hasRelax: r.has_relax });
                return;
            }
            renderSearchEmpty(
                `Matériau « ${q} » absent de <code>inputs/</code>. ` +
                `Valide quand même — tu pourras indiquer le chemin des prérequis vc-relax + scf dans le workflow.`
            );
            await selectMaterial(q, { hasRelax: false, allowNew: true });
            return;
        }

        renderSearchEmpty('API hors-ligne — validation locale du nom uniquement.');
        await selectMaterial(q, { hasRelax: !!APP.structure, allowNew: true });
    }

    function renderSearchEmpty(msg) {
        $('#zoneResultatRecherche').innerHTML = `
            <div style="background:#fef3c7; padding:24px; border-radius:12px; border-left:4px solid var(--warning); text-align:center;">
                <p style="margin:0; color:#92400e; font-size:1em;">${msg}</p>
            </div>`;
    }

    function renderSearchResults(query, r) {
        const zone = $('#zoneResultatRecherche');
        if (!r.found) return;
        const nClassic = r.classic_files?.length ?? 0;
        const nEpw     = r.epw_files?.length ?? 0;
        zone.innerHTML = `
            <div style="background: linear-gradient(135deg, #d1fae5, #a7f3d0); padding: 20px; border-radius: 12px; border-left: 4px solid var(--success);">
                <h5 style="margin: 0 0 8px 0; color: #065f46;">✅ Matériau « ${r.name} » validé</h5>
                <p style="margin: 0; color: #047857;">
                    📁 <code>${r.inputs_dir}/</code> ·
                    ${r.has_relax ? '<span class="pill" style="background:var(--success); color:white;">vc-relax OK</span>' :
                                    '<span class="pill" style="background:var(--warning); color:white;">vc-relax manquant</span>'} ·
                    <span class="pill pill-classic">WF1 : ${nClassic}</span>
                    <span class="pill pill-epw">WF2 : ${nEpw}</span>
                </p>
            </div>`;
    }

    async function handleRelaxUpload(ev) {
        const file = ev.target.files[0];
        if (!file) return;
        const text = await file.text();

        let mat = $('#champ_materiau').value.trim();
        if (!mat) {
            const m = file.name.match(/^([A-Za-z0-9_\-]+)/);
            if (m) { mat = m[1]; $('#champ_materiau').value = mat; }
        }
        if (!mat) {
            renderSearchEmpty("Entre un nom de matériau avant d'uploader le vc-relax.");
            return;
        }

        const base = (APP.material === mat ? getMaterialBaseDir() : null) || `inputs/${mat}`;
        const target = `${base}/${mat}.vc-relax.out`;
        const res = await SupraAPI.saveFile(target, text);
        if (!res || !res.ok) {
            renderSearchEmpty(`Échec sauvegarde : ${res?.error || 'inconnue'}`);
            return;
        }
        if (!/JOB DONE/.test(text.slice(-6000))) {
            renderSearchEmpty("⚠️ « JOB DONE » non trouvé. Vérifie que ton vc-relax est terminé.");
            return;
        }

        const struct = extractStructureFromText(text);
        if (!struct) {
            renderSearchEmpty("⚠️ Sauvegarde OK mais aucune structure extraite (vérifie 'Begin final coordinates').");
            return;
        }

        APP.structure = struct;
        applyStructureCutoffs(struct);
        if (struct.species?.length) {
            $('#fld_epw_nbndsub').value = Math.max(struct.species.length * 3, 5);
            $('#fld_nbnd_epw').value    = Math.max(struct.species.length * 12, 20);
        }

        $('#zoneResultatRecherche').innerHTML = `
            <div style="background: linear-gradient(135deg, #d1fae5, #a7f3d0); padding: 20px; border-radius: 12px; border-left: 4px solid var(--success);">
                <h5 style="margin: 0 0 8px 0; color: #065f46;">✅ vc-relax.out importé pour « ${mat} »</h5>
                <p style="margin: 0; color: #047857;">
                    ${struct.species.length} espèce(s), ${struct.positions.length} atome(s)
                    ${struct.ibrav !== undefined ? `, ibrav=${struct.ibrav}` : ''}
                    ${struct.ecutwfc ? `, ecutwfc=${struct.ecutwfc} Ry` : ''}.
                </p>
            </div>`;
        await selectMaterial(mat, { hasRelax: true });
        await checkPrereqOutputs();
        ev.target.value = '';
    }

    async function selectMaterial(materiau, opts = {}) {
        APP.material = materiau;
        APP.baseDir = `inputs/${materiau}`;
        APP.workflow = null;
        APP.metalCheck = null;
        APP.prereq = { relaxDone: false, scfDone: false, relaxPath: '', scfPath: '' };
        APP.scfCtl = null;
        invalidateWorkflowFiles();
        $$('.workflow-card').forEach(c => c.classList.remove('active'));
        highlightOrganigram(null);

        $('#champ_materiau').value = materiau;
        const fi = $('#fld_path_inputs');
        if (fi) { fi.dataset.touched = ''; fi.value = APP.baseDir; }

        if (!APP.structure || APP.structure._material !== materiau) {
            const r = await SupraAPI.readFile(`${APP.baseDir}/${materiau}.vc-relax.out`);
            if (r && r.ok && r.content) {
                const s = extractStructureFromText(r.content);
                if (s) {
                    s._material = materiau;
                    APP.structure = s;
                    opts.hasRelax = true;
                }
            }
        }

        syncMaterialPathField();
        await checkPrereqOutputs();
        renderMaterialInfo();
        refreshPseudoTable();

        const pseudo = $('#zoneEtapePseudo');
        if (pseudo) {
            pseudo.style.display = 'block';
            // Repliée par défaut : l'utilisateur déplie s'il veut voir les recommandations.
            setCollapsibleOpen(pseudo, false);
            const title = $('#etapePseudoTitle');
            if (title) title.textContent = `Pseudopotentiels — ${materiau}`;
        }

        updateFluxEtapes();
        // Résultats : ne jamais laisser les données de l'ancien matériau à l'écran
        if (typeof RES !== 'undefined') {
            RES.data = null;
            RES.reqId = (RES.reqId || 0) + 1;
            if (typeof renderResultModules === 'function') renderResultModules();
            updateResultatsEmptyState();
            if (APP.mainView === 'resultats' && APP.apiOnline) {
                exploreResults();
            }
        }
        scrollToView(pseudo, { block: 'nearest' });
    }

    function extractStructureFromText(text) {
        const out = { positions: [], species: [], cell_parameters: null };
        const idx = text.lastIndexOf('Begin final coordinates');
        const block = idx >= 0 ? text.slice(idx) : text;

        let m = block.match(/CELL_PARAMETERS\s*\(?\s*(\w+)?[^)\n]*\)?\s*\n\s*([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s*\n\s*([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s*\n\s*([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s+([-+\d.eEdD]+)/);
        if (m) {
            out.cell_unit = m[1] || 'alat';
            out.cell_parameters = [
                [Number(m[2].replace(/d/i,'e')), Number(m[3].replace(/d/i,'e')), Number(m[4].replace(/d/i,'e'))],
                [Number(m[5].replace(/d/i,'e')), Number(m[6].replace(/d/i,'e')), Number(m[7].replace(/d/i,'e'))],
                [Number(m[8].replace(/d/i,'e')), Number(m[9].replace(/d/i,'e')), Number(m[10].replace(/d/i,'e'))],
            ];
        }
        m = block.match(/ATOMIC_POSITIONS\s*\(?\s*(\w+)\s*\)?\s*\n((?:\s*[A-Za-z]{1,3}\s+[-+\d.eEdD]+\s+[-+\d.eEdD]+\s+[-+\d.eEdD]+(?:\s+\d\s+\d\s+\d)?\s*\n?)+)/);
        if (m) {
            out.positions_unit = m[1];
            m[2].trim().split('\n').forEach(line => {
                const p = line.trim().split(/\s+/);
                if (p.length >= 4) out.positions.push({
                    sym: p[0],
                    x: Number(p[1].replace(/d/i,'e')),
                    y: Number(p[2].replace(/d/i,'e')),
                    z: Number(p[3].replace(/d/i,'e')),
                });
            });
        }
        m = text.match(/ATOMIC_SPECIES\s*\n((?:\s*[A-Za-z]{1,3}\s+[\d.]+\s+[\w.\-+]+\s*\n?)+)/);
        if (m) {
            m[1].trim().split('\n').forEach(line => {
                const p = line.trim().split(/\s+/);
                if (p.length >= 3) out.species.push({ symbol: p[0], mass: Number(p[1]), pseudo: p[2] });
            });
        }
        const mb = text.match(/bravais-lattice index\s*=\s*(\d+)/i); if (mb) out.ibrav = Number(mb[1]);
        const me = text.match(/kinetic-energy cutoff\s*=\s*([\d.]+)\s*Ry/i); if (me) out.ecutwfc = Math.round(Number(me[1]));
        const mr = text.match(/charge density cutoff\s*=\s*([\d.]+)\s*Ry/i); if (mr) out.ecutrho = Math.round(Number(mr[1]));
        const ma = block.match(/CELL_PARAMETERS\s*\(?[^)\n]*alat\s*=\s*([\d.+\-eEdD]+)/i); if (ma) out.alat = Number(ma[1].replace(/d/i,'e'));
        // Fallback format input QE (&system) : ibrav =, celldm(i) =, ecutwfc =, ecutrho =
        if (out.ibrav === undefined) { const mi = text.match(/\bibrav\s*=\s*(\d+)/i); if (mi) out.ibrav = Number(mi[1]); }
        if (!out.ecutwfc) { const mw = text.match(/\becutwfc\s*=\s*([\d.eEdD+\-]+)/i); if (mw) out.ecutwfc = Math.round(Number(mw[1].replace(/d/i,'e'))); }
        if (!out.ecutrho) { const mrh = text.match(/\becutrho\s*=\s*([\d.eEdD+\-]+)/i); if (mrh) out.ecutrho = Math.round(Number(mrh[1].replace(/d/i,'e'))); }
        if (!out.celldm) {
            const cd = [0, 0, 0, 0, 0, 0];
            let any = false;
            for (const mm of text.matchAll(/celldm\((\d)\)\s*=\s*([\d.eEdD+\-]+)/gi)) {
                const i = Number(mm[1]);
                if (i >= 1 && i <= 6) { cd[i - 1] = Number(mm[2].replace(/d/i, 'e')); any = true; }
            }
            if (any) out.celldm = cd;
        }
        // Maille explicite (vc-relax) → toujours ibrav=0 + unité réelle
        if (out.cell_parameters) {
            out.ibrav = 0;
            const u = String(out.cell_unit || 'alat').toLowerCase();
            out.cell_unit = (u === 'angstrom' || u === 'bohr' || u === 'alat') ? u : 'alat';
            if (out.alat && !out.celldm) out.celldm = [out.alat, 0, 0, 0, 0, 0];
        }
        return out.positions.length ? out : null;
    }

    /* ====================================================================
     *  ÉTAPE 2 — Pipeline visuel + liste des calculs (style Interface-QE_v1)
     * ==================================================================== */
    function renderPipeline() {
        const zone = $('#zonePipeline');
        if (!zone) return;
        if (!APP.workflow) { zone.innerHTML = ''; return; }
        const calcs = calcStepsForRun(APP.workflow);
        const color = wfCss(APP.workflow);
        zone.innerHTML = `
            <div class="pipeline-block ${color}">
                <div class="pipeline-title">
                    <span>À lancer dans l'ordre — ${WORKFLOW_LABEL[APP.workflow].name}</span>
                    <span class="pipeline-tag">${calcs.length} étapes</span>
                </div>
                <div class="pipeline" id="pipelineActive">
                    ${calcs.map((c, i) => `
                        <button type="button" class="pipe-step" data-step="${c.type}" data-state="ready"
                                title="Ouvrir l'étape ${c.num} · ${c.short || c.nom}">
                            <div class="pipe-num">${c.num}</div>
                            <div class="pipe-title">${c.short || c.nom}</div>
                            <div class="pipe-sub">${c.prog}</div>
                            <span class="pipe-badge">prêt</span>
                        </button>
                        ${i < calcs.length - 1 ? '<div class="pipe-arrow" aria-hidden="true">→</div>' : ''}
                    `).join('')}
                </div>
            </div>`;
        zone.querySelectorAll('.pipe-step[data-step]').forEach(step => {
            step.addEventListener('click', () => scrollToCalc(step.dataset.step));
        });
        markNextStep();
        if (typeof SupraI18n !== 'undefined' && SupraI18n.refresh) SupraI18n.refresh(zone);
    }

    async function renderCalcList() {
        const zone = $('#zoneListeCalculs');
        if (!zone) return;
        if (!APP.workflow) { zone.innerHTML = ''; return; }
        const calcs = CALCS[APP.workflow];
        const wfClass = 'wf-' + wfCss(APP.workflow);
        zone.innerHTML = '<p class="muted">Génération des inputs…</p>';

        await ensureFilesGenerated(true);
        updateWorkflowActionButtons();
        const paths = getWorkflowPaths();
        zone.innerHTML = '';

        if (!APP.files?.[APP.workflow]) {
            zone.innerHTML = '<p class="muted">Les cartes d\'étapes apparaissent lorsque la géométrie de référence (SCF) est lue — voir le bandeau ci-dessus.</p>';
            return;
        }

        calcs.forEach(c => {
            const f = APP.files?.[APP.workflow]?.[c.type];
            const fileName = f?.name || `${APP.material}.${c.type}.in`;
            const inPath = `${paths.workDir}/${fileName}`;
            const origin = (c.type === 'scf' && f?.originPath) ? f.originPath : '';
            const preview = f?.content
                ? f.content.split('\n').slice(0, 12).join('\n')
                : '(clique « Générer les inputs » ou ✏️ Éditer)';

            const card = el('div', {
                class: `calc-card ${wfClass}`,
                'data-state': 'idle',
                'data-type': c.type,
            });
            const optTag = c.optional
                ? '<span class="pill" style="background: var(--warning); color: white;">optionnel</span>' : '';
            const deps = (STEP_CHAIN[APP.workflow]?.[c.type]?.deps || [])
                .map(d => calcByType(APP.workflow, d))
                .filter(Boolean);
            const depsLine = deps.length
                ? `<div class="calc-deps">🔗 Requiert : ${deps.map(d => `<strong>${d.num} ${d.prog}</strong>`).join(' puis ')} terminé(s)</div>`
                : '<div class="calc-deps">🔗 Première étape — SCF sur la géométrie relaxée (fichier utilisateur).</div>';
            card.innerHTML = `
                <span class="calc-num" aria-hidden="true">${c.num}</span>
                <div class="calc-body">
                    <div class="calc-next-banner">▶ Prochaine étape — lance celle-ci</div>
                    <div class="calc-head">
                        <div class="calc-title">
                            <span style="font-size: 1.3em;">${c.icon}</span>
                            <div>
                                <h5><span class="calc-short">${c.short || c.nom}</span> <span class="calc-nom">${c.nom}</span></h5>
                                ${optTag}
                            </div>
                        </div>
                        <span class="calc-prog">${c.prog}</span>
                    </div>
                    <p class="calc-desc">${c.desc}</p>
                    ${depsLine}
                    <div class="calc-timing-block calc-est-block" data-chrono-step="${c.type}">
                        <span class="calc-timing-label">⏳ Durée estimée (${escapeHtml(APP.material || 'mat')} · ce PC)</span>
                        <span class="calc-est-value">—</span>
                        <span class="calc-chrono-live" hidden></span>
                        <span class="calc-timing-hint muted">Fourchette selon grilles k/q, nat, ecut, MPI — ordre de grandeur.</span>
                    </div>
                    <div class="calc-input-path">📄 Input : <code>${inPath}</code>${origin
                        ? `<br><span class="muted" style="font-size:0.88em;">SCF utilisateur : <code>${origin}</code> · prefix / outdir / pseudo_dir repris pour tout le workflow</span>`
                        : ''}</div>
                    <pre class="calc-input-preview">${escapeHtml(preview)}</pre>
                    <div class="calc-reco">
                        <strong>💡 ${WORKFLOW_LABEL[APP.workflow]?.id || ''} — ${APP.workflow}</strong>
                        <ul>${c.reco.map(r => `<li>${r}</li>`).join('')}</ul>
                    </div>
                    <div class="calc-actions">
                        <button class="btn"
                                style="background: linear-gradient(135deg, var(--warning), #d97706); color: white;"
                                data-action="edit">✏️ Vérifier / éditer</button>
                        <button class="btn btn-secondary" data-action="save">💾 Sauvegarder</button>
                        <button class="btn btn-success" data-action="run">🚀 Lancer</button>
                        <button class="btn btn-success" data-action="resume" hidden
                                style="background: linear-gradient(135deg, #059669, #047857); color: white;"
                                title="Reprendre après coupure (recover / restart QE)">♻️ Reprendre</button>
                        <button class="btn"
                                style="background: linear-gradient(135deg, #0f172a, #1e293b); color: #a3e635; font-weight: 600;"
                                data-action="terminal">🖥️ Terminal</button>
                        <button class="btn"
                                style="background: linear-gradient(135deg, var(--info), #1d4ed8); color: white;"
                                data-action="suivi">📊 Suivi</button>
                    </div>
                </div>`;
            card.querySelector('[data-action="edit"]')    .addEventListener('click', () => editInputModal(c));
            card.querySelector('[data-action="save"]')    .addEventListener('click', () => saveInputForCalc(c));
            card.querySelector('[data-action="run"]')     .addEventListener('click', () => runOne(c));
            card.querySelector('[data-action="resume"]')  .addEventListener('click', () => runResumeOne(c));
            card.querySelector('[data-action="terminal"]').addEventListener('click', () => terminalModal(c));
            card.querySelector('[data-action="suivi"]')   .addEventListener('click', () => suiviModal(c));
            zone.appendChild(card);
        });
        syncPipelineFromChain();
        refreshStepEstimates();
        updateStepChronoUI();
        if (typeof SupraI18n !== 'undefined' && SupraI18n.refresh) SupraI18n.refresh(zone);
    }

    async function saveInputForCalc(calc) {
        if (!APP.apiOnline) { notifyUser('API hors ligne — lance <code>./DEMARRER.sh</code> ou ouvre Chemins.', 'error'); return; }
        if (!APP.files?.[APP.workflow] && !await ensureFilesGenerated()) {
            notifyUser('Impossible de générer l\'input à sauvegarder.', 'error');
            return;
        }
        const f = APP.files?.[APP.workflow]?.[calc.type];
        if (!f) { notifyUser('Input introuvable.', 'error'); return; }
        const path = calc.type === 'scf' && f.originPath ? f.originPath : stepInputPath(calc);
        const r = await SupraAPI.saveFile(path, f.content);
        if (r?.ok) {
            if (calc.type === 'scf') {
                const workCopy = `${getWorkflowPaths().workDir}/${f.name}`;
                if (path !== workCopy) await SupraAPI.saveFile(workCopy, f.content);
            }
            setCalcState(calc.type, 'ready', 'sauvé');
            setGenStatus('success', `✅ <code>${path}</code> sauvegardé.`);
            notifyUser(`Sauvegardé : ${path}`, 'success');
        } else {
            const err = r?.error || 'inconnue';
            setGenStatus('error', `Échec sauvegarde <code>${path}</code> : ${escapeHtml(err)}`);
            notifyUser(`Échec sauvegarde : ${err}`, 'error');
        }
    }

    /* ====================================================================
     *  MODAL ÉDITION (split-screen textarea + recommandations)
     * ==================================================================== */
    async function editInputModal(calc) {
        if (!APP.material) { notifyUser("Sélectionne d'abord un matériau."); return; }
        if (!APP.workflow) { notifyUser("Choisis d'abord un workflow."); return; }

        const fileObj = APP.files?.[APP.workflow]?.[calc.type];
        const fileName = fileObj ? fileObj.name : `${APP.material}.${calc.type}.in`;
        const paths = getWorkflowPaths();
        const savePath = (calc.type === 'scf' && fileObj?.originPath)
            ? fileObj.originPath
            : `${paths.workDir}/${fileName}`;

        // SCF : toujours le fichier de l'utilisateur. Autres étapes : dossier workflow.
        let contenu = null;
        if (calc.type === 'scf') {
            const userScf = await findUserScfInput();
            if (userScf) {
                contenu = userScf.content;
                if (fileObj) {
                    fileObj.content = contenu;
                    fileObj.originPath = userScf.path;
                    fileObj.aligned = true;
                }
                applyScfControl(contenu);
            }
        }
        if (contenu == null && fileObj?.content) contenu = fileObj.content;
        if (contenu == null && APP.apiOnline) {
            const r = await SupraAPI.readFile(savePath);
            if (r && r.ok && r.content) contenu = r.content;
        }
        if (contenu == null) {
            if (!APP.structure) {
                notifyUser("Place l'input SCF (issu du vc-relax) dans <code>inputs/&lt;matériau&gt;/</code> avant d'éditer.");
                return;
            }
            const ok = await ensureFilesGenerated(true);
            if (!ok) return;
            contenu = APP.files?.[APP.workflow]?.[calc.type]?.content ?? '';
        } else if (fileObj) {
            fileObj.content = contenu;
        }

        openModal({
            type:    'large',
            headerCls: 'orange',
            title:   `✏️ Édition : ${calc.nom} — ${APP.material}`,
            subtitle: `📁 ${savePath}${fileObj?.originPath ? ` · repris de ${fileObj.originPath}` : ''}`,
            bodyHTML: `
                <div class="edit-split" style="margin: -22px -24px;">
                    <div class="edit-left">
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                            <h4 style="margin:0;">📝 Contenu de l'input</h4>
                            <span style="font-size:0.82em; color:var(--text-medium);" id="lineCount">— lignes</span>
                        </div>
                        <textarea id="editTextarea">${escapeHtml(contenu)}</textarea>
                    </div>
                    <div class="edit-right">
                        <h4>💡 Recommandations</h4>
                        ${calc.reco.map(r => `<div class="reco-item">• ${r}</div>`).join('')}
                        <div style="background:#fee2e2; padding:12px 14px; border-radius:8px; margin-top:14px; border-left:4px solid var(--error);">
                            <strong style="color:#991b1b;">⚠️ Points d'attention :</strong>
                            <ul style="margin:8px 0 0; padding-left:20px; color:#7f1d1d; font-size:0.86em;">
                                <li>Syntaxe Fortran (sensible à la casse)</li>
                                <li>Sections <code>&CONTROL</code>, <code>&SYSTEM</code>, <code>&ELECTRONS</code>…</li>
                                <li>Chemins des pseudos cohérents (<code>pseudo_dir</code>)</li>
                                <li>Format numérique : <code>1.0d-10</code> (notation Fortran)</li>
                            </ul>
                        </div>
                    </div>
                </div>`,
            footer: [
                { label: '❌ Annuler',          cls: 'btn-secondary',      onClick: closeModal },
                { label: '⬇️ Télécharger',      cls: 'btn btn-secondary',  onClick: () => {
                    const v = $('#editTextarea').value;
                    downloadFile(fileName, v);
                } },
                { label: '🔁 Regénérer (form)', cls: 'btn btn-violet',     onClick: async () => {
                    if (!APP.structure) { notifyUser("Input SCF ou structure requis pour régénérer."); return; }
                    if (calc.type === 'scf') {
                        notifyUser("Le SCF utilisateur n'est pas régénéré — édite-le à la main ou recharge le fichier.", 'warning');
                        return;
                    }
                    const prevScf = APP.files?.[APP.workflow]?.scf;
                    APP.files = APP.files || {};
                    const regen = SupraInputs.genererFichiersWorkflow(gatherParams(), APP.workflow);
                    if (prevScf) regen.scf = prevScf;
                    APP.files[APP.workflow] = regen;
                    $('#editTextarea').value = APP.files[APP.workflow][calc.type].content;
                    updateLineCount();
                } },
                { label: '💾 Sauvegarder',      cls: 'btn btn-success',    onClick: async () => {
                    if (!APP.apiOnline) { notifyUser("API hors ligne — lance <code>./DEMARRER.sh</code> ou ouvre Chemins.", "error"); return; }
                    const v = $('#editTextarea').value;
                    const r = await SupraAPI.saveFile(savePath, v);
                    if (r?.ok) {
                        if (!APP.files) APP.files = {};
                        if (!APP.files[APP.workflow]) APP.files[APP.workflow] = SupraInputs.genererFichiersWorkflow(gatherParams(), APP.workflow);
                        if (APP.files[APP.workflow]?.[calc.type]) APP.files[APP.workflow][calc.type].content = v;
                        if (calc.type === 'scf') {
                            applyScfControl(v);
                            const workCopy = `${paths.workDir}/${fileName}`;
                            if (savePath !== workCopy) await SupraAPI.saveFile(workCopy, v);
                            await refreshAdoptedScf(APP.files[APP.workflow]);
                            const written = await persistWorkflowFiles(APP.files[APP.workflow]);
                            if (!written.ok) notifyUser(`Suite non écrite : ${written.failed.map(x => x.key).join(', ')}`, 'error');
                        }
                        setCalcState(calc.type, 'ready', 'sauvé');
                        notifyUser(`Sauvegardé : ${savePath}`, 'success');
                        renderInputsPanel(APP.files);
                        renderCalcList();
                        closeModal();
                    } else {
                        notifyUser(`Erreur de sauvegarde : ${r?.error || 'inconnue'}`, 'error');
                    }
                } },
            ],
        });
        // compteur de lignes live
        const ta = $('#editTextarea');
        const updateLineCount = () => {
            $('#lineCount').textContent = `${ta.value.split('\n').length} lignes`;
        };
        ta.addEventListener('input', updateLineCount);
        updateLineCount();
    }

    /* ====================================================================
     *  MODAL TERMINAL (commandes prêtes à coller)
     * ==================================================================== */
    function terminalModal(calc) {
        if (!APP.material) { notifyUser("Sélectionne d'abord un matériau."); return; }
        const fileName = `${APP.material}.${calc.type}.in`;
        const outName  = `${APP.material}.${calc.type}.out`;
        const paths    = getWorkflowPaths();
        const execWd   = stepExecutionWorkdir(calc.type);
        const np = intv('fld_nprocs', 1);
        const nt = intv('fld_nthreads', 1);
        const h  = APP._health || {};
        const mpirun = h.mpirun || 'mpirun';
        const binDir = h.qe_bin_dir || '/usr/local/bin';
        const repoAbs = h.inputs_dir ? h.inputs_dir.replace(/\/inputs\/?$/, '') : '/path/to/supra-QE';
        const prefix = APP.scfCtl?.prefix || APP.material || 'pw';

        const fullPath = `${repoAbs}/${paths.workDir}/${fileName}`;
        const fullOut  = `${repoAbs}/${paths.outputDir}/${outName}`;

        let cmdRun = '';
        if (np > 1) {
            cmdRun = `${mpirun} -np ${np} ${binDir}/${calc.prog} -in ${fullPath} > ${fullOut} 2>&1`;
        } else {
            cmdRun = `${binDir}/${calc.prog} -in ${fullPath} > ${fullOut} 2>&1`;
        }
        const cmdCd  = `cd ${repoAbs}/${execWd}`;
        const cmdOmp = nt > 1 ? `export OMP_NUM_THREADS=${nt}` : '';
        const cmdTail = `tail -f ${fullOut}`;
        const ppDir = qeOutdirApiRel();
        const showPp = APP.workflow === 'epw' && ['ph', 'nscf', 'epw'].includes(calc.type);
        const cmdGather = showPp
            ? `# Après ph.x JOB DONE — cwd = outdir QE\n` +
              `cd ${repoAbs}/${ppDir}\n` +
              `echo ${prefix} | python3 "${repoAbs}/bin/pp.py"`
            : '';

        openModal({
            type:    'terminal',
            headerCls: 'dark',
            title:   `🖥️ Terminal — ${calc.nom}`,
            subtitle: `Copie-colle ces commandes dans ton terminal système`,
            bodyHTML: `
                <p class="muted" style="margin:0 0 12px;">
                    Toutes les commandes sont prêtes à coller. Utilise-les si tu préfères lancer en dehors de l'interface
                    (et garder le contrôle direct du processus).
                </p>
                ${(() => {
                    const lines = [
                        ['Aller dans le dossier de calcul', cmdCd],
                        cmdOmp   ? ['Définir les threads OpenMP', cmdOmp] : null,
                        cmdGather ? [`Regrouper ph.x → <code>${ppDir}/save/</code> (après ph.x, avant epw.x)`, cmdGather] : null,
                        ['Lancer le calcul', cmdRun],
                        ['Suivre le log en temps réel', cmdTail],
                    ].filter(Boolean);
                    return lines.map(([label, cmd], i) => terminalLine(`${i + 1}) ${label}`, cmd)).join('');
                })()}
                <details style="margin-top:14px;">
                    <summary style="cursor:pointer; font-size:0.88em; color:var(--text-medium);">
                        Une seule commande prête à coller
                    </summary>
                    ${terminalLine('Pipeline complet', [cmdCd, cmdOmp, cmdGather, cmdRun].filter(Boolean).join(' && '))}
                </details>`,
            footer: [
                { label: 'Fermer', cls: 'btn-secondary', onClick: closeModal },
            ],
        });

        // Bind copy buttons after the modal is in the DOM
        $$('.copy-cmd').forEach(btn => {
            btn.addEventListener('click', () => {
                const cmd = btn.dataset.cmd || '';
                navigator.clipboard.writeText(cmd);
                btn.textContent = '✓ Copié';
                setTimeout(() => { btn.textContent = '📋 Copier'; }, 1500);
            });
        });
    }

    function terminalLine(label, cmd) {
        return `
            <div class="terminal-step">${label}</div>
            <div class="terminal-block">${escapeHtml(cmd)}
                <button class="copy-cmd" data-cmd="${escapeHtml(cmd).replace(/"/g,'&quot;')}">📋 Copier</button>
            </div>`;
    }

    /* ====================================================================
     *  MODAL SUIVI (tail -f du .out)
     * ==================================================================== */
    function suiviModal(calc) {
        if (!APP.material) { notifyUser("Sélectionne d'abord un matériau."); return; }
        const outName = `${APP.material}.${calc.type}.out`;
        const paths = getWorkflowPaths();
        const path = `${paths.outputDir}/${outName}`;

        openModal({
            type:    'large',
            headerCls: 'blue',
            title:   `📊 Suivi — ${calc.nom}`,
            subtitle: `Lecture en direct de ${path}`,
            bodyHTML: `
                <div class="tail-bar">
                    <span>État :</span>
                    <span class="tail-status idle" id="tailStatus">—</span>
                    <span class="muted" id="tailMeta"></span>
                    <span style="flex:1"></span>
                    <label style="display:flex; align-items:center; gap:6px; font-size:0.86em; color:var(--text-medium);">
                        <input type="checkbox" id="tailAuto" checked> Suivi auto (2 s)
                    </label>
                    <button class="btn btn-secondary" id="tailRefresh" style="padding:5px 12px; font-size:0.82em;">↻ Rafraîchir</button>
                </div>
                <div class="tail-output" id="tailContent">Chargement…</div>`,
            footer: [
                { label: '⬇️ Télécharger .out', cls: 'btn btn-secondary', onClick: async () => {
                    const r = await SupraAPI.readFile(path);
                    if (r?.ok && r.content) downloadFile(outName, r.content);
                } },
                { label: 'Fermer', cls: 'btn-secondary', onClick: () => {
                    if (APP._tailTimer) { clearInterval(APP._tailTimer); APP._tailTimer = null; }
                    closeModal();
                } },
            ],
            onClose: () => { if (APP._tailTimer) { clearInterval(APP._tailTimer); APP._tailTimer = null; } },
        });

        const refresh = async () => {
            const r = await SupraAPI.readFile(path);
            const box = $('#tailContent');
            const st  = $('#tailStatus');
            const meta = $('#tailMeta');
            if (!r || !r.ok) {
                if (box) box.innerHTML = `<span class="err">Aucun output disponible.\nFichier : ${path}</span>`;
                if (st) { st.className = 'tail-status idle'; st.textContent = 'idle'; }
                return;
            }
            const content = r.content || '';
            const tail = content.split('\n').slice(-200).join('\n');
            if (box) box.textContent = tail || '(fichier vide)';
            // détection d'état
            let kind = 'running', label = 'en cours';
            if (/JOB DONE\./.test(content))             { kind = 'completed'; label = 'JOB DONE ✓'; }
            else if (/%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/.test(content) ||
                     /Error in routine|stopping/i.test(content)) { kind = 'error'; label = 'erreur QE'; }
            if (st) { st.className = `tail-status ${kind}`; st.textContent = label; }
            if (meta) meta.textContent = `${content.split('\n').length} lignes · ${content.length.toLocaleString('fr-FR')} octets`;
            if (box) box.scrollTop = box.scrollHeight;
        };
        $('#tailRefresh').addEventListener('click', refresh);
        $('#tailAuto').addEventListener('change', (e) => {
            if (e.target.checked && !APP._tailTimer) APP._tailTimer = setInterval(refresh, 2000);
            else if (!e.target.checked && APP._tailTimer) { clearInterval(APP._tailTimer); APP._tailTimer = null; }
        });
        refresh();
        APP._tailTimer = setInterval(refresh, 2000);
    }

    /* ====================================================================
     *  Helpers modal génériques
     * ==================================================================== */
    function openModal({ type, headerCls, title, subtitle, bodyHTML, footer, onClose }) {
        const overlay = el('div', { class: 'modal-overlay' });
        const box = el('div', { class: 'modal-box ' + (type === 'large' ? 'large' : type === 'terminal' ? 'terminal' : '') });
        box.innerHTML = `
            <div class="modal-header ${headerCls || ''}">
                <div>
                    <h3>${title}</h3>
                    ${subtitle ? `<p>${subtitle}</p>` : ''}
                </div>
                <button class="modal-close" type="button">×</button>
            </div>
            <div class="modal-body">${bodyHTML}</div>
            <div class="modal-footer"></div>`;
        const footerDiv = box.querySelector('.modal-footer');
        (footer || []).forEach(f => {
            const b = el('button', { class: 'btn ' + (f.cls || 'btn-secondary'), type: 'button' });
            b.innerHTML = f.label;
            b.addEventListener('click', f.onClick);
            footerDiv.appendChild(b);
        });
        overlay.appendChild(box);
        document.body.appendChild(overlay);

        APP._currentModal = overlay;
        APP._modalOnClose = onClose;
        box.querySelector('.modal-close').addEventListener('click', closeModal);
        overlay.addEventListener('click', e => { if (e.target === overlay) closeModal(); });
    }

    function closeModal() {
        if (APP._currentModal) {
            APP._currentModal.remove();
            APP._currentModal = null;
            try { APP._modalOnClose && APP._modalOnClose(); } catch (_) {}
            APP._modalOnClose = null;
        }
    }

    function escapeHtml(s) {
        return (s == null ? '' : String(s))
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function setCalcState(type, state, badge) {
        $$(`.calc-card[data-type="${type}"]`).forEach(c => { c.dataset.state = state; });
        const pipe = $(`#pipelineActive .pipe-step[data-step="${type}"]`);
        if (pipe) {
            pipe.dataset.state = state;
            const b = pipe.querySelector('.pipe-badge');
            if (b && badge) b.textContent = badge;
        }
    }

    /* ====================================================================
     *  Garantir que les inputs sont générés (en mémoire ; sauvegarde sur demande)
     * ==================================================================== */
    async function ensureFilesGenerated(silent, opts = {}) {
        if (!APP.material)  { if (!silent) setGenStatus('error', "Sélectionne d'abord un matériau."); return false; }
        if (!APP.workflow)  { if (!silent) setGenStatus('error', "Choisis d'abord un workflow (étape 2)."); return false; }
        if (opts.force && APP.files?.[APP.workflow]) delete APP.files[APP.workflow];
        if (APP.files?.[APP.workflow] && !opts.force) return true;

        const userScf = await findUserScfInput();
        if (userScf) {
            applyScfControl(userScf.content);
            const s = extractStructureFromText(userScf.content);
            if (s) {
                s._material = APP.material;
                APP.structure = s;
                applyStructureCutoffs(s);
            }
        }

        if (!APP.structure) {
            renderStructureGate();
            setGenStatus('warning',
                `Géométrie introuvable pour <strong>${escapeHtml(APP.material)}</strong> — ` +
                `place <code>inputs/${escapeHtml(APP.material)}/${escapeHtml(APP.material)}.scf.in</code> ` +
                `(ou <code>${escapeHtml(APP.material.toLowerCase())}_scf.in</code>, namelists + cartes <code>ATOMIC_*</code>), ` +
                `puis revalide le matériau. Valable pour WF1 et WF2.`);
            return false;
        }

        const p   = gatherParams();
        const val = SupraInputs.validerParametres(p);
        if (!val.ok) {
            setGenStatus('error',
                '<strong>Paramètres invalides :</strong><ul style="padding-left:22px;">' +
                val.erreurs.map(e => `<li>${e}</li>`).join('') + '</ul>');
            return false;
        }
        APP.files = APP.files || {};
        APP.files[APP.workflow] = SupraInputs.genererFichiersWorkflow(p, APP.workflow);
        await refreshAdoptedScf(APP.files[APP.workflow]);
        const written = await persistWorkflowFiles(APP.files[APP.workflow]);
        renderInputsPanel(APP.files);
        if (written.ok) {
            if (!silent) setGenStatus('success',
                `✅ Suite générée (${written.saved} fichiers) dans <code>${getWorkflowPaths().workDir}/</code>. ` +
                `Chemins QE : ${qePathsStatusHtml()} · <code>prefix</code> du SCF conservé.`);
        } else {
            const msg = `Échec de sauvegarde : <ul>${written.failed.map(r => `<li>${r.key} : ${escapeHtml(r.err)}</li>`).join('')}</ul>`;
            setGenStatus('error', msg);
            notifyUser('La sauvegarde des inputs a échoué — voir le bandeau sous les boutons.', 'error');
        }
        return true;
    }

    /** Écrit l'input de l'étape sur le serveur juste avant son lancement. */
    async function pushStepInput(calc) {
        if (!APP.apiOnline) return true;
        if (APP.files?.[APP.workflow]) {
            await refreshAdoptedScf(APP.files[APP.workflow]);
        }
        const f = APP.files?.[APP.workflow]?.[calc.type];
        if (!f) return false;
        if (calc.type === 'nscf' && f.content) f.content = hardenNscfContent(f.content);
        const paths = getWorkflowPaths();
        const r = await SupraAPI.saveFile(`${paths.workDir}/${f.name}`, f.content);
        return !!r?.ok;
    }

    /**
     * Signale les dépendances non satisfaites avant un lancement manuel.
     * L'utilisateur garde le dernier mot : la vérification informe et demande
     * confirmation, elle ne verrouille jamais définitivement une étape.
     */
    async function guardStep(calc) {
        await inspectChain();
        const blockers = chainBlockers(calc.type);
        if (!blockers.length) return true;
        renderChainStatus();

        const details = blockers
            .map(b => `• ${stripTags(b.label)}${b.detail ? ` — ${stripTags(b.detail)}` : ''}`)
            .join('\n');
        appendLog(alertBox('warning',
            `⚠️ <strong>${calc.num} — ${calc.nom}</strong> lancé alors que la chaîne signale :` +
            `<ul style="margin:8px 0 0; padding-left:20px;">` +
            blockers.map(b => `<li>${b.label}${b.detail ? ` — ${b.detail}` : ''}</li>`).join('') +
            `</ul>`));
        return confirm(
            `${calc.num} — ${calc.nom} (${calc.prog})\n\n` +
            `La vérification signale :\n${details}\n\n` +
            `Lancer quand même ? (à faire si tu as produit ces fichiers ailleurs)`);
    }

    function stripTags(html) {
        return String(html == null ? '' : html).replace(/<[^>]*>/g, '');
    }

    async function runResumeOne(calc) {
        const st = APP.chain?.steps?.[calc.type];
        if (!st?.resumable) {
            notifyUser('Reprise indisponible — pas de dossier _ph0/ ou prefix.save détecté.', 'warning');
            return false;
        }
        if (!confirm(
            `Reprendre ${calc.num} — ${calc.nom} ?\n\n`
            + `${resumeStepLabel(calc.type)}\n\n`
            + `Le fichier .out existant sera complété (pas effacé).`
        )) return false;
        if (APP.jobBusy || _activeJobId) {
            notifyUser('Un calcul est déjà en cours.', 'warning');
            return false;
        }
        APP.jobBusy = true;
        try {
            if (!await ensureFilesGenerated()) return false;
            const f = APP.files?.[APP.workflow]?.[calc.type];
            if (!f) return false;
            f.content = patchInputForResume(calc.type, f.content);
            if (!await pushStepInput(calc)) return false;
            appendLog(alertBox('info',
                `♻️ Reprise <strong>${calc.prog}</strong> — ${escapeHtml(resumeStepLabel(calc.type))}`));
            const ok = await launchStep(calc.type, APP.workflow, { appendOutput: true });
            if (ok) await afterStepSuccess(calc.type);
            await refreshChainStatus();
            return ok;
        } finally {
            APP.jobBusy = false;
        }
    }

    async function confirmIfQeProgramAlreadyRunning(calc) {
        const prog = calc?.prog;
        if (!prog || !['ph.x', 'pw.x', 'epw.x', 'q2r.x', 'matdyn.x', 'epw.x'].includes(prog)) return true;
        const rr = await SupraAPI.qeRunning({ outputs: [], programs: [prog] });
        const info = rr?.programs?.[prog];
        if (!rr?.ok || !info?.alive) return true;
        const pids = (info.pids || []).join(', ');
        appendLog(alertBox('error',
            `⚠️ <strong>${escapeHtml(prog)}</strong> tourne déjà sur ce PC (PID <code>${escapeHtml(pids)}</code>). `
            + `Un second lancement (restart) sur le même matériau peut <strong>corrompre</strong> <code>_ph0/</code>. `
            + `Utilise <strong>🔍 Calcul figé ?</strong> → <strong>Activer la surveillance</strong>.`));
        return confirm(
            `${prog} est DÉJÀ actif (PID : ${pids}).\n\n`
            + 'Relancer = doublon dangereux pour ph.x.\n'
            + 'Préfère : Calcul figé ? → Activer la surveillance.\n\n'
            + 'Forcer un NOUVEAU lancement quand même ? (très déconseillé)'
        );
    }

    async function runOne(calc, { force = false } = {}) {
        if (APP.jobBusy || _activeJobId) {
            notifyUser('Un calcul QE est déjà en cours. Attends la fin ou annule-le avant d\'en lancer un autre.', 'warning');
            return false;
        }
        if (!await confirmIfQeProgramAlreadyRunning(calc)) return false;
        APP.jobBusy = true;
        try {
            if (!await ensureFilesGenerated()) return false;
            await inspectChain();
            if (calc.type === 'ph' && APP.chain?.steps?.ph?.resumable && !force) {
                if (!confirm(
                    'Des fichiers de reprise ph.x (_ph0/) sont présents.\n\n'
                    + 'Pour continuer après une coupure, utilise ♻️ Reprendre (recover=.true.).\n\n'
                    + 'Lancer quand même un calcul neuf (efface la progression ph.x) ?'
                )) return false;
            }
            if (!force && !await guardStep(calc)) return false;
            if (calc.type === 'epw' && APP.workflow === 'epw') {
                const okSave = await ensureEpwSaveBeforeEpw();
                if (!okSave) {
                    appendLog(alertBox('error',
                        `Impossible de créer <code>${qeOutdirApiRel()}/save/</code> — lance ph.x puis `
                        + `<code>pp.py</code> (🖥️ Terminal) avant epw.x.`));
                    return false;
                }
            }
            if (!await pushStepInput(calc)) {
                appendLog(alertBox('error', `Impossible d'écrire l'input de ${calc.nom}.`));
                return false;
            }
            const ok = await launchStep(calc.type, APP.workflow);
            if (ok) {
                const follow = await afterStepSuccess(calc.type);
                if (follow.stop) {
                    await refreshChainStatus();
                    return false;
                }
            }
            await refreshChainStatus();
            return ok;
        } finally {
            APP.jobBusy = false;
        }
    }

    /* ====================================================================
     *  Workflow complet — séquentiel, avec vérification avant et après
     *  chaque étape (une étape ne démarre que si l'amont est « JOB DONE »).
     * ==================================================================== */
    async function runWorkflowActive() {
        if (!await ensureFilesGenerated()) return;
        if (!APP.apiOnline) {
            appendLog(alertBox('error',
                'API hors-ligne : impossible de lancer et de vérifier la chaîne. ' +
                'Lance <code>./DEMARRER.sh</code> puis « ↻ API », ou utilise 🖥️ Terminal étape par étape.'));
            return;
        }
        const wf = APP.workflow;
        const ordered = calcStepsForRun(wf);
        const chainLabel = ordered.map(c => `${c.num} ${c.short || c.prog}`).join(' → ');
        if (!confirm(
            `Lancer toute la chaîne ${WORKFLOW_LABEL[wf].name} ?\n\n` +
            `${ordered.length} étapes, une après l\'autre (attente JOB DONE entre chaque) :\n${chainLabel}\n\n` +
            `Les calculs peuvent durer des heures. Tu peux aussi lancer une seule étape avec 🚀 sur sa carte.`)) {
            return;
        }
        appendLog(`▶️ <strong>${WORKFLOW_LABEL[wf].name}</strong> — ${ordered.length} étapes : ${ordered.map(c => c.prog).join(' → ')}`);

        for (const c of ordered) {
            await inspectChain();
            if (!APP.chain) {
                appendLog(alertBox('error',
                    (APP.chainError || 'Vérification de la chaîne impossible.') +
                    ' Workflow arrêté (fail-closed).'));
                return;
            }
            if (stepState(c.type, wf) === 'done') {
                appendLog(`⏭️ ${c.num} — ${c.nom} déjà terminé (JOB DONE)`
                    + (APP.chain?.steps?.[c.type]?.shared
                        ? ' — repris de l\'autre workflow (SCF partagé).'
                        : ' : étape sautée.'));
                if (c.type === 'scf') {
                    const follow = await afterStepSuccess('scf', { persist: false });
                    if (follow.stop) {
                        renderChainStatus();
                        return;
                    }
                }
                continue;
            }
            if (c.type === 'epw' && wf === 'epw') {
                await ensureEpwSaveBeforeEpw();
                await inspectChain();
            }
            const blockers = chainBlockers(c.type, wf);
            if (blockers.length) {
                const manual = blockers.filter(b => b.manual);
                renderChainStatus();
                appendLog(alertBox(manual.length ? 'warning' : 'error',
                    `⛔ Chaîne arrêtée avant <strong>${c.num} — ${c.nom}</strong> :` +
                    `<ul style="margin:8px 0 0; padding-left:20px;">` +
                    blockers.map(b => `<li>${b.label}${b.detail ? ` — ${b.detail}` : ''}</li>`).join('') +
                    `</ul>` +
                    `<p style="margin:8px 0 0;">Si ces fichiers existent ailleurs, lance cette étape seule avec son bouton ` +
                    `<strong>🚀 Lancer</strong> : la confirmation permet de passer outre.</p>`));
                return;
            }
            if (!await pushStepInput(c)) {
                appendLog(alertBox('error', `Écriture de l'input impossible pour ${c.nom}.`));
                return;
            }
            const launched = await launchStep(c.type, wf);
            await inspectChain();
            if (!launched || stepState(c.type, wf) !== 'done') {
                renderChainStatus();
                appendLog(alertBox('error',
                    `⛔ <strong>${c.num} — ${c.nom}</strong> n'a pas abouti (« JOB DONE » absent). ` +
                    `Ouvre 📊 Suivi pour lire <code>${stepOutPath(c.type)}</code>.`));
                return;
            }
            appendLog(alertBox('success', `✅ ${c.num} — ${c.nom} vérifié (JOB DONE + fichiers attendus).`));
            const follow = await afterStepSuccess(c.type);
            if (follow.stop) {
                renderChainStatus();
                return;
            }
        }
        await refreshChainStatus();
        appendLog(alertBox('success',
            `🎉 <strong>${WORKFLOW_LABEL[wf].name}</strong> terminé et vérifié — onglet <strong>Résultats</strong> pour lire Tᶜ.`));
    }

    /* ====================================================================
     *  Bandeau parallélisation — auto-détection du PC qui exécute l'API
     * ==================================================================== */
    const PARALLEL_LS_KEY = 'supraQE.parallelHost';

    function readParallelPrefs() {
        try { return JSON.parse(localStorage.getItem(PARALLEL_LS_KEY) || '{}') || {}; }
        catch { return {}; }
    }
    function saveParallelPrefs() {
        try {
            const host = APP._health?.host || {};
            localStorage.setItem(PARALLEL_LS_KEY, JSON.stringify({
                hostname: host.hostname || APP._parallelHost || '',
                nprocs: intv('fld_nprocs', 1),
                nthreads: intv('fld_nthreads', 1),
            }));
        } catch { /* mode privé */ }
    }

    function syncNpButtons(np, N) {
        $$('.np-btn').forEach(b => b.classList.remove('active'));
        const quart = Math.max(1, Math.floor(N / 4));
        const demi  = Math.max(1, Math.floor(N / 2));
        let key = '';
        if (np === N) key = 'max';
        else if (np === demi) key = 'demi';
        else if (np === quart) key = 'quart';
        else if (np === 1) key = '1';
        if (key) $$(`.np-btn[data-np="${key}"]`).forEach(b => b.classList.add('active'));
    }

    /**
     * Lit CPU / RAM / mpirun du serveur API (nouveau PC → nouveaux défauts).
     * Ne réécrit MPI/OMP que si l'hôte a changé, si les champs n'ont pas été
     * touchés, ou si force=true (bouton Détecter).
     */
    function applyHostParallel({ force = false } = {}) {
        const host = APP._health?.host;
        const fldNp = $('#fld_nprocs');
        const fldNt = $('#fld_nthreads');
        const prefs = readParallelPrefs();

        if (!host) {
            APP.cpuCount = navigator.hardwareConcurrency || APP.cpuCount || 4;
            if (fldNp) fldNp.max = Math.max(64, APP.cpuCount);
            updateCPUInfo();
            return;
        }

        const logical = Number(host.cpu_logical) || navigator.hardwareConcurrency || 4;
        const physical = Number(host.cpu_physical) || logical;
        APP.cpuCount = logical;
        if (fldNp) fldNp.max = Math.max(64, logical);
        if (fldNt) fldNt.max = Math.max(32, logical);

        const hostChanged = !!(host.hostname && prefs.hostname && prefs.hostname !== host.hostname);
        const firstSeen = !prefs.hostname;

        if (force || hostChanged || firstSeen) {
            const np = Math.max(1, Number(host.recommended_nprocs) || 1);
            const nt = Math.max(1, Number(host.recommended_nthreads) || 1);
            if (fldNp) { fldNp.value = np; fldNp.dataset.touched = ''; }
            if (fldNt) { fldNt.value = nt; fldNt.dataset.touched = ''; }
            syncNpButtons(np, physical || logical);
            APP._parallelHost = host.hostname;
            saveParallelPrefs();
        } else {
            if (fldNp && !fldNp.dataset.touched && prefs.nprocs) fldNp.value = prefs.nprocs;
            if (fldNt && !fldNt.dataset.touched && prefs.nthreads) fldNt.value = prefs.nthreads;
            syncNpButtons(intv('fld_nprocs', 1), physical || logical);
            APP._parallelHost = host.hostname;
        }
        updateCPUInfo();
        refreshStepEstimates();
    }

    function bindParallel() {
        $$('.np-btn').forEach(b => b.addEventListener('click', () => {
            const v = b.dataset.np;
            const N = APP.cpuCount;
            let np = 1;
            if (v === 'quart')    np = Math.max(1, Math.floor(N / 4));
            else if (v === 'demi') np = Math.max(1, Math.floor(N / 2));
            else if (v === 'max')  np = N;
            else np = parseInt(v, 10) || 1;
            const fld = $('#fld_nprocs');
            if (fld) { fld.value = np; fld.dataset.touched = '1'; }
            syncNpButtons(np, N);
            saveParallelPrefs();
            updateCPUInfo();
        }));
        $('#fld_nprocs')?.addEventListener('input', () => {
            $('#fld_nprocs').dataset.touched = '1';
            $$('.np-btn').forEach(x => x.classList.remove('active'));
            saveParallelPrefs();
            updateCPUInfo();
            refreshStepEstimates();
        });
        $('#fld_nthreads')?.addEventListener('input', () => {
            $('#fld_nthreads').dataset.touched = '1';
            saveParallelPrefs();
            updateCPUInfo();
        });
        $('#btnDetectCPU')?.addEventListener('click', async () => {
            await pingAPI();
            applyHostParallel({ force: true });
            const host = APP._health?.host;
            const msg = host
                ? `PC <code>${escapeHtml(host.hostname || 'API')}</code> : ` +
                  `${host.cpu_physical || host.cpu_logical} cœurs physiques` +
                  `${host.mem_gb != null ? `, ${host.mem_gb} Go RAM` : ''}` +
                  `${host.mpirun ? `, MPI <code>${escapeHtml(String(host.mpirun).split('/').pop())}</code>` : ', pas de mpirun → OpenMP'}` +
                  ` → MPI ${host.recommended_nprocs} × OMP ${host.recommended_nthreads}.`
                : `Cœurs navigateur : ${APP.cpuCount} (API hors ligne).`;
            notifyUser(msg, host ? 'success' : 'warning');
        });
        updateCPUInfo();
    }

    function updateCPUInfo() {
        const np = intv('fld_nprocs', 1);
        const nt = intv('fld_nthreads', 1);
        const host = APP._health?.host;
        const N = APP.cpuCount;
        let hw = `${N} cœurs`;
        if (host) {
            const phys = host.cpu_physical || host.cpu_logical || N;
            const logi = host.cpu_logical || N;
            const mem  = host.mem_gb != null ? ` · ${host.mem_gb} Go` : '';
            const mpi  = host.mpirun ? '' : ' · OpenMP';
            const name = host.hostname ? `${host.hostname} · ` : '';
            hw = `${name}${phys} phys / ${logi} log${mem}${mpi}`;
        }
        const info = $('#cpuInfo');
        if (info) info.textContent = `${hw} · ${np}×${nt} = ${np * nt}`;
        const steps = calcStepsForRun(APP.workflow);
        const seq = steps.length ? steps.map(c => c.prog).join(' → ') : 'choisis un workflow';
        const preview = $('#cmdPreview');
        if (preview) {
            preview.textContent = `${np > 1 ? `mpirun -np ${np}` : (nt > 1 ? `OMP=${nt}` : 'séquentiel')} · ${seq}`;
        }
    }

    /* ====================================================================
     *  Pseudopotentiels
     * ==================================================================== */
    const ELEMENT_MASS = {
        H:1.008, He:4.003, Li:6.941, Be:9.012, B:10.811, C:12.011, N:14.007, O:15.999,
        F:18.998, Na:22.990, Mg:24.305, Al:26.982, Si:28.086, P:30.974, S:32.065, Cl:35.453,
        K:39.098, Ca:40.078, Sc:44.956, Ti:47.867, V:50.942, Cr:51.996, Mn:54.938, Fe:55.845,
        Co:58.933, Ni:58.693, Cu:63.546, Zn:65.380, Ga:69.723, Ge:72.640, As:74.922, Se:78.971,
        Br:79.904, Rb:85.468, Sr:87.620, Y:88.906, Zr:91.224, Nb:92.906, Mo:95.950, Ru:101.07,
        Rh:102.906, Pd:106.42, Ag:107.868, Cd:112.411, In:114.818, Sn:118.710, Sb:121.760,
        Te:127.60, I:126.904, Cs:132.905, Ba:137.327, La:138.905, Hf:178.49, Ta:180.948,
        W:183.84, Re:186.207, Os:190.23, Ir:192.217, Pt:195.084, Au:196.967, Hg:200.592,
        Tl:204.383, Pb:207.2, Bi:208.980,
    };

    /**
     * Suggestion Norm-Conserving (PseudoDojo) : le couplage électron-phonon de
     * QE exige des pseudos NC — proposer un nom PAW/USPP enverrait l'utilisateur
     * vers un fichier que ph.x refusera.
     */
    function defaultPseudoFilename(symbol) {
        return `${symbol}_ONCV_PBE-1.2.upf`;
    }

    function inferSpeciesFromMaterial(formula) {
        if (!formula) return [];
        const re = /([A-Z][a-z]?)(\d*)/g;
        const seen = new Set();
        const species = [];
        let m;
        while ((m = re.exec(formula)) !== null) {
            const sym = m[1];
            if (seen.has(sym)) continue;
            seen.add(sym);
            species.push({
                symbol: sym,
                mass: ELEMENT_MASS[sym] || 1.0,
                pseudo: defaultPseudoFilename(sym),
            });
        }
        return species;
    }

    function getPseudoSpecies() {
        if (APP.structure?.species?.length) return APP.structure.species;
        return inferSpeciesFromMaterial(APP.material);
    }

    async function refreshPseudoTable() {
        const tbody = $('#pseudoTable tbody');
        const inferHint = $('#pseudoInferHint');
        tbody.innerHTML = '';
        const species = getPseudoSpecies();
        const fromStructure = !!(APP.structure?.species?.length);

        if (inferHint) {
            if (!fromStructure && species.length) {
                inferHint.style.display = 'block';
                inferHint.textContent =
                    'Éléments déduits du nom du matériau (pas encore de vc-relax.out). ' +
                    'Les noms de fichiers sont des suggestions PseudoDojo — ajuste-les si besoin.';
            } else {
                inferHint.style.display = 'none';
                inferHint.textContent = '';
            }
        }

        if (!species.length) {
            tbody.appendChild(el('tr', {}, el('td', { colspan: 4, class: 'muted text-center' },
                "Valide un matériau pour lister les pseudos requis.")));
            $('#pseudoCheckBox').innerHTML = '';
            setBadge('pseudos', 'warn', 'à vérifier');
            return;
        }
        const pseudoRel = txt('fld_pseudo_dir', '../../../pseudos/');
        const pseudoCheckPath = APP._health?.pseudos_dir || pseudoRel;
        const listing = APP.apiOnline ? await SupraAPI.checkPseudos(
            species.map(s => s.pseudo), pseudoCheckPath
        ) : { results: species.map(s => ({ name: s.pseudo, kind: 'UNKNOWN' })) };

        (listing.results || []).forEach((r, i) => {
            const sp = species[i] || {};
            const kindClass = (r.kind || 'unknown').toLowerCase();
            // Auto-accepte un NC au nom différent (Nb.upf → Nb_ONCV_….upf)
            if (r.kind === 'NC' && r.name && sp.pseudo && r.name !== sp.pseudo) {
                sp.pseudo = r.name;
                if (APP.structure?.species?.[i]) APP.structure.species[i].pseudo = r.name;
            }
            const nameCell = r.resolved_from
                ? `${r.name} <span class="muted" style="font-size:0.78em;">(← ${escapeHtml(r.resolved_from)})</span>`
                : escapeHtml(r.name || sp.pseudo || '—');
            tbody.appendChild(el('tr', {},
                el('td', { class: 'mono' }, sp.symbol || '—'),
                el('td', { class: 'mono' }, null),  // filled below
                el('td', {}, el('span', { class: `badge ${kindClass}` }, r.kind || '—')),
                el('td', {},
                    el('button', { class: 'btn btn-secondary',
                        style: 'padding:4px 12px; font-size:0.82em;',
                        onclick: () => promptUploadPseudo() }, '📤 Remplacer'))
            ));
            // innerHTML pour la note de résolution (déjà échappée)
            const tr = tbody.lastElementChild;
            if (tr && tr.children[1]) tr.children[1].innerHTML = nameCell;
        });

        const box = $('#pseudoCheckBox');
        if (listing.all_nc) {
            const notes = (listing.results || [])
                .filter(r => r.resolved_from)
                .map(r => `<li>${escapeHtml(r.note || `${r.resolved_from} → ${r.name}`)}</li>`)
                .join('');
            box.innerHTML = alertBox('success',
                '✅ Tous les pseudopotentiels sont <strong>Norm-Conserving</strong>'
                + ' (tout nommage NC accepté : PseudoDojo, SG15, ONCV, <code>Nb.upf</code>, …).'
                + (notes ? `<ul style="margin:8px 0 0;">${notes}</ul>` : ''));
            setBadge('pseudos', 'ok', 'tous NC');
        } else {
            const issues = (listing.issues || []).map(s => `<li>${escapeHtml(s)}</li>`).join('');
            const onlyMissing = (listing.results || []).every(r =>
                r.kind === 'MISSING' || r.kind === 'UNKNOWN');
            const level = onlyMissing ? 'warning' : 'error';
            const badgeKind = onlyMissing ? 'warn' : 'err';
            const badgeTxt = onlyMissing ? 'fichiers manquants' : 'non-NC';
            box.innerHTML = alertBox(level,
                (onlyMissing
                    ? '<strong>⚠️ Pseudos manquants ou non lus.</strong>'
                    : '<strong>⛔ Pseudopotentiels non-NC détectés.</strong>') +
                (issues ? `<ul style="padding-left:22px; margin-top:6px;">${issues}</ul>` : '') +
                '<br>Télécharge les versions NC depuis ' +
                '<a href="http://www.pseudo-dojo.org/" target="_blank" rel="noopener">PseudoDojo</a> ' +
                'ou importe-les ci-dessus.');
            setBadge('pseudos', badgeKind, badgeTxt);
        }
    }

    async function uploadPseudo(file) {
        const content = await file.text();
        return await fetch(SupraAPI.getBaseURL() + '/api/pseudo/upload', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: file.name, content }),
        }).then(r => r.json()).catch(() => null);
    }

    function promptUploadPseudo() {
        const input = document.createElement('input');
        input.type = 'file'; input.accept = '.upf,.UPF';
        input.onchange = async () => {
            const f = input.files[0];
            if (!f) return;
            const res = await uploadPseudo(f);
            if (res && res.ok) refreshPseudoTable();
        };
        input.click();
    }

    function bindPseudoUpload() {
        $('#fld_pseudo_upload')?.addEventListener('change', async ev => {
            for (const f of Array.from(ev.target.files || [])) await uploadPseudo(f);
            refreshPseudoTable();
        });
    }

    /* ====================================================================
     *  Grilles K vs Q
     * ==================================================================== */
    function readGrids() {
        const kc = [ intv('fld_knscf_1', 24),   intv('fld_knscf_2', 24),   intv('fld_knscf_3', 24) ];
        const ke = [ intv('fld_knscf_epw_1', 8), intv('fld_knscf_epw_2', 8), intv('fld_knscf_epw_3', 8) ];
        const q  = [ intv('fld_q_1', 4),         intv('fld_q_2', 4),         intv('fld_q_3', 4) ];
        return { kc, ke, q };
    }

    function buildTimingContext() {
        const { kc, ke, q } = readGrids();
        const h = APP._health?.host || {};
        const nat = APP.structure?.positions?.length || 1;
        return {
            material: APP.material || '',
            workflow: APP.workflow || 'classic',
            nat,
            ntyp: APP.structure?.species?.length || 1,
            ecutwfc: intv('fld_ecutwfc', APP.structure?.ecutwfc || 60),
            kScf: [
                intv('fld_kscf_1', 12), intv('fld_kscf_2', 12), intv('fld_kscf_3', 12),
            ],
            kNscf: kc,
            kNscfEpw: ke,
            qPh: q,
            nprocs: intv('fld_nprocs', 1),
            nthreads: intv('fld_nthreads', 1),
            cpuLogical: h.cpu_logical || APP.cpuCount || 4,
            cpuPhysical: h.cpu_physical || h.cpu_logical || 4,
        };
    }

    function stepEstimateLabel(type) {
        if (typeof SupraTiming === 'undefined') return '—';
        const ctx = buildTimingContext();
        const e = SupraTiming.estimateStep(type, APP.workflow || 'classic', ctx);
        const host = APP._health?.host?.hostname || 'ce PC';
        return {
            mid: e.seconds,
            range: SupraTiming.formatDurationRange(e.seconds),
            detail: e.detail,
            host,
            mpi: `${ctx.nprocs}×${ctx.nthreads}`,
        };
    }

    let _stepClockInterval = null;
    let _stepProgressPoll = 0;

    function startStepClockTimer() {
        if (_stepClockInterval) return;
        _stepClockInterval = window.setInterval(() => {
            if (APP.stepClock) refreshStepEstimates();
            updateStepChronoUI();
            _stepProgressPoll += 1;
            const pollEvery = (APP.stepClock?.type === 'ph' || APP.stepClock?.type === 'epw') ? 8 : 15;
            if (_stepProgressPoll >= pollEvery && APP.stepClock && APP.apiOnline) {
                _stepProgressPoll = 0;
                refreshRunningProgressFromOut();
            }
        }, 1000);
    }

    function stopStepClockTimerIfIdle() {
        const wf = APP.workflow;
        const running = wf && calcStepsForRun(wf).some(c => stepStateIsActive(stepState(c.type, wf)));
        if (!APP.stepClock && !running && _stepClockInterval) {
            clearInterval(_stepClockInterval);
            _stepClockInterval = null;
        }
    }

    function beginStepClock(type) {
        if (typeof SupraTiming === 'undefined') return;
        const ctx = buildTimingContext();
        const est = SupraTiming.estimateStep(type, APP.workflow || 'classic', ctx);
        APP.stepClock = {
            type,
            startedAtMs: Date.now(),
            estimateSec: est.seconds,
            progressFrac: 0.03,
            startedFromOut: false,
        };
        resetStepClockRemainderDisplay(APP.stepClock);
        startStepClockTimer();
        updateStepChronoUI();
        refreshStepEstimates();
    }

    function clearStepClock() {
        APP.stepClock = null;
        stopStepClockTimerIfIdle();
        updateStepChronoUI();
    }

    function resetStepClockRemainderDisplay(clk) {
        if (!clk) return;
        clk._remDisp = null;
        clk._remDispAt = null;
        clk._remProg = null;
    }

    async function qeProcessStartedAtMs(stepType) {
        const prog = STEP_QE_PROGRAM[stepType];
        if (!prog || !APP.apiOnline) return null;
        const outs = stepOutCandidates(stepType);
        const rr = await SupraAPI.qeRunning({ outputs: outs, programs: [prog] });
        if (!rr?.ok) return null;
        let best = rr.programs?.[prog]?.started_at_ms ?? null;
        Object.values(rr.outputs || {}).forEach(o => {
            const t = o?.started_at_ms;
            if (t != null && (best == null || t < best)) best = t;
        });
        return best ?? null;
    }

    function mergeClockStartMs(clk, { outMs, procMs }) {
        let best = clk?.startedAtMs ?? null;
        let source = clk?.clockSource || null;
        [outMs, procMs].forEach((t, i) => {
            if (t == null) return;
            if (best == null || t < best - 5000) {
                best = t;
                source = i === 1 ? 'process' : 'out';
            }
        });
        if (procMs != null && best != null && procMs <= best + 5000) {
            source = 'process';
            best = Math.min(best, procMs);
        }
        return { startedAtMs: best, clockSource: source };
    }

    async function refreshRunningProgressFromOut() {
        const clk = APP.stepClock;
        if (!clk || typeof SupraTiming === 'undefined') return;
        const paths = stepOutCandidates(clk.type);
        let outMs = null;
        for (const p of paths) {
            const r = await SupraAPI.readFile(p, { max_bytes: 12_000_000 });
            if (r?.ok && r.content) {
                const ctx = buildTimingContext();
                const prog = SupraTiming.progressFromOutText(clk.type, r.content, ctx);
                if (Math.abs(prog.fraction - (clk.progressFrac ?? 0)) > 0.003) {
                    resetStepClockRemainderDisplay(clk);
                }
                clk.progressFrac = prog.fraction;
                clk.progressDetail = prog.detail;
                outMs = SupraTiming.earliestStartedAtMsFromOutText(r.content)
                    ?? SupraTiming.startedAtMsFromOutText(r.content);
                break;
            }
        }
        const procMs = await qeProcessStartedAtMs(clk.type);
        const merged = mergeClockStartMs(clk, { outMs, procMs });
        if (merged.startedAtMs != null) {
            clk.startedAtMs = merged.startedAtMs;
            clk.clockSource = merged.clockSource;
            clk.startedFromOut = merged.clockSource === 'out';
        }
        updateStepChronoUI();
    }

    async function attachRunningClockFromChain() {
        if (typeof SupraTiming === 'undefined') return;
        const wf = APP.workflow;
        if (!wf || !APP.chain) return;
        const runningType = calcStepsForRun(wf).find(c => stepStateIsActive(stepState(c.type, wf)))?.type;
        if (!runningType) {
            if (APP.stepClock && !APP.runningStep) clearStepClock();
            return;
        }
        if (APP.stepClock?.type === runningType) {
            await refreshRunningProgressFromOut();
            return;
        }
        const ctx = buildTimingContext();
        const est = SupraTiming.estimateStep(runningType, wf, ctx);
        let frac = 0.05;
        let detail = '';
        let startedAtMs = null;
        let startedFromOut = false;
        let outMs = null;
        if (APP.apiOnline) {
            for (const p of stepOutCandidates(runningType)) {
                const r = await SupraAPI.readFile(p, { max_bytes: 12_000_000 });
                if (r?.ok && r.content) {
                    const prog = SupraTiming.progressFromOutText(runningType, r.content, ctx);
                    frac = prog.fraction;
                    detail = prog.detail;
                    outMs = SupraTiming.earliestStartedAtMsFromOutText(r.content)
                        ?? SupraTiming.startedAtMsFromOutText(r.content);
                    break;
                }
            }
        }
        const procMs = await qeProcessStartedAtMs(runningType);
        const merged = mergeClockStartMs(
            { startedAtMs, clockSource: startedFromOut ? 'out' : null },
            { outMs, procMs },
        );
        startedAtMs = merged.startedAtMs;
        let clockSource = merged.clockSource;
        if (startedAtMs == null) {
            const elapsedGuess = est.seconds * Math.max(0.03, frac);
            startedAtMs = Date.now() - elapsedGuess * 1000;
            clockSource = 'estimate';
        }
        startedFromOut = clockSource === 'out';
        APP.stepClock = {
            type: runningType,
            startedAtMs,
            estimateSec: est.seconds,
            progressFrac: frac,
            progressDetail: detail,
            startedFromOut,
            clockSource,
        };
        resetStepClockRemainderDisplay(APP.stepClock);
        startStepClockTimer();
        updateStepChronoUI();
    }

    function updateStepChronoUI() {
        if (typeof SupraTiming === 'undefined') return;
        const clk = APP.stepClock;
        document.querySelectorAll('[data-chrono-step]').forEach(el => {
            const t = el.dataset.chronoStep;
            const estEl = el.querySelector('.calc-est-value, .chain-est-value');
            const liveEl = el.querySelector('.calc-chrono-live, .chain-chrono-live');
            if (!estEl && !liveEl) return;
            const isRun = clk && clk.type === t;
            if (isRun && liveEl) {
                const r = SupraTiming.remainingSeconds(clk);
                const remShow = SupraTiming.displayRemainingSeconds(clk, r);
                const pct = Math.round((r.progress || 0) * 100);
                liveEl.hidden = false;
                const srcNote = clk.clockSource === 'process'
                    ? ' <span class="muted">(depuis processus ph.x)</span>'
                    : (clk.clockSource === 'out' && clk.startedFromOut
                        ? ' <span class="muted">(depuis .out)</span>' : '');
                let remTxt;
                if (r.remainderUnpredictable) {
                    remTxt = '<strong>non prévisible</strong> <span class="muted">(ph.x silencieux · plan dépassé — laisse tourner)</span>';
                } else if (r.remainderUncertain) {
                    remTxt = `≥ <strong>${SupraTiming.formatDuration(remShow, { live: true })}</strong> <span class="muted">(décompte · plafond journal silencieux)</span>`;
                } else {
                    remTxt = `~<strong>${SupraTiming.formatDuration(remShow, { live: true })}</strong>`;
                }
                const planNote = (r.planSec > 0 && r.planOverrun > 1.12)
                    ? ` · plan initial <strong>${SupraTiming.formatDuration(r.planSec)}</strong>`
                        + ` <span class="muted">(×${r.planOverrun.toFixed(1)} déjà)</span>`
                    : '';
                const totalProj = (remShow != null && !r.remainderUnpredictable)
                    ? SupraTiming.formatDuration(r.elapsed + remShow, { live: true })
                    : null;
                const totalNote = totalProj
                    ? ` · total projeté ~<strong>${totalProj}</strong>`
                    : '';
                liveEl.innerHTML = `⏱ <strong>${SupraTiming.formatDuration(r.elapsed, { live: true })}</strong> écoulées`
                    + ` · reste ${remTxt}`
                    + totalNote
                    + (clk.progressDetail ? ` · ${escapeHtml(clk.progressDetail)} (${pct} %)` : ` (${pct} %)`)
                    + planNote
                    + srcNote;
                if (estEl) {
                    estEl.closest('.calc-est-block')?.classList.add('is-live');
                    const planRange = r.planSec > 0
                        ? SupraTiming.formatDurationRange(r.planSec) : '—';
                    estEl.textContent = (r.planSec > 0 && r.planOverrun > 1.05)
                        ? `Plan initial : ${planRange} (dépassé — chrono ci-dessous)`
                        : `Fourchette initiale : ${planRange} · chrono ci-dessous`;
                }
            } else if (liveEl) {
                liveEl.hidden = true;
                liveEl.textContent = '';
                estEl?.closest('.calc-est-block')?.classList.remove('is-live');
            }
        });
    }

    function refreshStepEstimates() {
        if (typeof SupraTiming === 'undefined') return;
        const wf = APP.workflow;
        if (!wf) return;
        const ctx = buildTimingContext();
        calcStepsForRun(wf).forEach(c => {
            const e = SupraTiming.estimateStep(c.type, wf, ctx);
            const runningNow = APP.stepClock?.type === c.type;
            document.querySelectorAll(`[data-chrono-step="${c.type}"] .calc-est-value, [data-chrono-step="${c.type}"] .chain-est-value`)
                .forEach(el => {
                    if (runningNow) return;
                    el.textContent = SupraTiming.formatDurationRange(e.seconds);
                    el.title = `${e.detail} · MPI ${ctx.nprocs}×${ctx.nthreads} · ${ctx.cpuLogical} cœurs`;
                });
        });
        const box = $('#chainTotalEstimate');
        if (box) {
            const steps = calcStepsForRun(wf);
            let rem = 0;
            steps.forEach(c => {
                const st = APP.chain?.steps?.[c.type];
                if (st?.done) return;
                if (c.type === APP.stepClock?.type && APP.stepClock) {
                    const rr = SupraTiming.remainingSeconds(APP.stepClock);
                    const rs = SupraTiming.displayRemainingSeconds(APP.stepClock, rr);
                    rem += (rs != null ? rs : rr.remaining);
                } else {
                    rem += SupraTiming.estimateStep(c.type, wf, ctx).seconds;
                }
            });
            box.textContent = rem > 0
                ? `Temps restant estimé (chaîne) : ~${SupraTiming.formatDuration(rem)}`
                : '';
        }
    }

    function updateKQVisual() {
        const { kc, ke, q } = readGrids();
        $('#kq_kc_val').textContent   = `${kc[0]} × ${kc[1]} × ${kc[2]}`;
        $('#kq_kc_count').textContent = `${(kc[0]*kc[1]*kc[2]).toLocaleString('fr-FR')} pts`;
        $('#kq_ke_val').textContent   = `${ke[0]} × ${ke[1]} × ${ke[2]}`;
        $('#kq_ke_count').textContent = `${(ke[0]*ke[1]*ke[2]).toLocaleString('fr-FR')} pts`;
        $('#kq_q_val').textContent    = `${q[0]} × ${q[1]} × ${q[2]}`;
        $('#kq_q_count').textContent  = `${(q[0]*q[1]*q[2]).toLocaleString('fr-FR')} pts`;

        const rc = [0,1,2].map(i => q[i] > 0 ? kc[i]/q[i] : 0);
        const intC = [0,1,2].every(i => q[i] > 0 && kc[i] % q[i] === 0);
        const minC = Math.min(...rc);
        let statusC = 'success', labelC = '✓ ratio entier ≥ 4';
        if (!intC) { statusC = 'error'; labelC = '✗ ratio non entier'; }
        else if (minC < 2) { statusC = 'error'; labelC = '✗ ratio < 2'; }
        else if (minC < 4) { statusC = 'warning'; labelC = '⚠ ratio < 4'; }
        $('#ratioClassicVal').textContent    = rc.map(r => r.toFixed(1)).join(' × ');
        $('#ratioClassicStatus').textContent = labelC;
        $('#ratioClassic').dataset.status    = statusC;

        const re = [0,1,2].map(i => q[i] > 0 ? ke[i]/q[i] : 0);
        const intE = [0,1,2].every(i => q[i] > 0 && ke[i] % q[i] === 0);
        let statusE = 'success', labelE = `✓ k_coarse / q = ${re.map(r => r.toFixed(1)).join(' × ')}`;
        if (!intE) { statusE = 'error'; labelE = '✗ ratio non entier'; }
        $('#ratioEpwVal').textContent    = re.map(r => r.toFixed(1)).join(' × ');
        $('#ratioEpwStatus').textContent = labelE;
        $('#ratioEPW').dataset.status    = statusE;
        refreshStepEstimates();
    }

    function bindGridInputs() {
        ['fld_knscf_1','fld_knscf_2','fld_knscf_3',
         'fld_knscf_epw_1','fld_knscf_epw_2','fld_knscf_epw_3',
         'fld_q_1','fld_q_2','fld_q_3',
         'fld_kscf_1','fld_kscf_2','fld_kscf_3',
         'fld_ecutwfc','fld_nprocs','fld_nthreads'].forEach(id => {
            const el = $('#' + id);
            if (!el) return;
            el.addEventListener('input', () => {
                if (id.startsWith('fld_k') || id.startsWith('fld_q')) updateKQVisual();
                else refreshStepEstimates();
            });
        });
        ['fld_mag_mode', 'fld_starting_mag'].forEach(id => {
            const el = $('#' + id);
            if (!el) return;
            const fn = () => updateMagnetismHint();
            el.addEventListener('input', fn);
            el.addEventListener('change', fn);
        });
    }

    /* ====================================================================
     *  Paramètres unifiés
     * ==================================================================== */
    function gatherParams() {
        const { kc, ke, q } = readGrids();
        let projections = null;
        const projTxt = (txt('fld_epw_proj', 'auto') || '').trim();
        if (projTxt && projTxt.toLowerCase() !== 'auto') {
            projections = projTxt.split(/[;,]/).map(s => s.trim()).filter(Boolean);
        }
        const qePaths = resolveQePathsForGeneration();
        return {
            material:    APP.material,
            prefix:      APP.scfCtl?.prefix || APP.material,
            method:      APP.workflow || 'classic',
            outdir:      qePaths.outdir,
            pseudo_dir:  qePaths.pseudo_dir,
            // Après vc-relax (cell_dofree='all') la maille finale est en
            // CELL_PARAMETERS : on force ibrav=0 pour ne pas mélanger Bravais
            // d'entrée et vecteurs relaxés.
            ibrav: (() => {
                const s = APP.structure;
                if (s?.cell_parameters) return 0;
                return s?.ibrav ?? 0;
            })(),
            celldm:      APP.structure?.celldm
                || (APP.structure?.alat ? [APP.structure.alat, 0, 0, 0, 0, 0] : [0, 0, 0, 0, 0, 0]),
            alat:        APP.structure?.alat || null,
            cell_unit:   APP.structure?.cell_unit || (APP.structure?.cell_parameters ? 'alat' : 'angstrom'),
            nat:         APP.structure?.positions?.length || 1,
            ntyp:        APP.structure?.species?.length   || 1,
            // Les champs sont préremplis depuis vc-relax.out : ils font foi, sinon
            // une valeur saisie dans la carte SCF resterait sans effet.
            ecutwfc:     intv('fld_ecutwfc', APP.structure?.ecutwfc || 60),
            ecutrho:     intv('fld_ecutrho', APP.structure?.ecutrho || 300),
            species:     APP.structure?.species   || [],
            positions:   APP.structure?.positions || [],
            atomic_positions_units: APP.structure?.positions_unit || 'crystal',
            cell_parameters: APP.structure?.cell_parameters || null,

            k_scf:       [ intv('fld_kscf_1', 12), intv('fld_kscf_2', 12), intv('fld_kscf_3', 12) ],
            k_nscf:      kc,
            k_nscf_epw:  ke,
            q_phonon:    q,
            smearing:    txt('fld_smearing', 'mv'),
            degauss:     num('fld_degauss', 0.02),
            mag_mode: typeof SupraInputs !== 'undefined'
                ? SupraInputs.normalizeMagMode(txt('fld_mag_mode', 'none'))
                : txt('fld_mag_mode', 'none'),
            starting_magnetization: typeof SupraInputs !== 'undefined'
                ? SupraInputs.parseStartingMagList(txt('fld_starting_mag', ''))
                : [],
            conv_thr_scf:  parseQENum(txt('fld_conv_scf',  '1.0d-10')),
            conv_thr_nscf: parseQENum(APP.workflow === 'epw'
                ? txt('fld_conv_nscf_epw', '1.0d-10')
                : txt('fld_conv_nscf', '1.0d-10')),
            nbnd:        APP.workflow === 'epw'
                ? intv('fld_nbnd_epw', 30)
                : (intv('fld_nbnd', 0) || null),

            tr2_ph:           parseQENum(txt('fld_tr2_ph', '1.0d-12')),
            electron_phonon:  txt('fld_ep_mode', 'interpolated'),
            fildvscf:         APP.workflow === 'epw'
                ? `${APP.scfCtl?.prefix || APP.material}.dvscf`
                : txt('fld_fildvscf', 'aldv'),
            fildyn:           APP.workflow === 'epw'
                ? `${APP.scfCtl?.prefix || APP.material}.dyn`
                : txt('fld_fildyn', 'matdyn'),

            mu_star:        num('fld_mu_star', 0.10),
            flfrc:          txt('fld_flfrc',  'ifc.fc'),
            fila2F:         txt('fld_fila2F', 'a2F.dat'),
            deltaE_phonon:  num('fld_deltaE', 1.0),
            alpha2f_smear:  num('fld_alpha2f_smear', 0.05),

            // Dossier produit par pp.py (dyn + dvscf regroupés), relatif au dossier de calcul
            epw_dvscf_dir:    './save/',
            epw_nbndsub:      intv('fld_epw_nbndsub', 5),
            epw_num_iter:     500,
            epw_dis_win_min:  num('fld_epw_dis_win_min', -3.0),
            epw_dis_win_max:  num('fld_epw_dis_win_max', 15.0),
            epw_dis_froz_min: num('fld_epw_dis_froz_min', -3.0),
            epw_dis_froz_max: num('fld_epw_dis_froz_max', 8.0),
            epw_projections:  projections,
            epw_fsthick:      num('fld_epw_fsthick', 0.4),
            epw_degaussw:     num('fld_epw_degaussw', 0.05),
            epw_degaussq:     num('fld_epw_degaussq', 0.5),
            epw_aniso:        txt('fld_epw_aniso', 'iso') === 'aniso',
            epw_nstemp:       intv('fld_epw_nstemp', 30),
            epw_temp_max:     num('fld_epw_tmax', 30),
            epw_wscut:        num('fld_epw_wscut', 1.0),
            k_fine_epw:       [ intv('fld_epw_nkf_1', 40), intv('fld_epw_nkf_2', 40), intv('fld_epw_nkf_3', 40) ],
            q_fine_epw:       [ intv('fld_epw_nqf_1', 40), intv('fld_epw_nqf_2', 40), intv('fld_epw_nqf_3', 40) ],
            sscha_nconfigs:   intv('fld_sscha_nconfigs', 64),
            sscha_disp:       num('fld_sscha_disp', 0.08),
            sscha_seed:       intv('fld_sscha_seed', 42),
            sscha_super:      [ intv('fld_sscha_super_1', 2), intv('fld_sscha_super_2', 2), intv('fld_sscha_super_3', 2) ],
            sscha_conv_thr:   txt('fld_sscha_conv_thr', '1.0d-8'),
            sscha_ecutwfc:    intv('fld_sscha_ecutwfc', 80),
            sscha_k:          [ intv('fld_sscha_k_1', 6), intv('fld_sscha_k_2', 6), intv('fld_sscha_k_3', 6) ],
            sscha_temp:       num('fld_sscha_temp', 300),
            sscha_maxiter:    intv('fld_sscha_maxiter', 100),
            sscha_tol:        txt('fld_sscha_tol', '1.0d-6'),
            sscha_mu_star:    num('fld_sscha_mu_star', 0.10),
        };
    }

    /* ====================================================================
     *  Génération de tous les fichiers (bouton global)
     * ==================================================================== */
    async function generateAndSave() {
        if (!await ensureFilesGenerated(false, { force: true })) return;
        if (!APP.apiOnline) {
            setGenStatus('warning',
                `⚠️ API hors-ligne. Inputs en mémoire — onglet « Inputs générés » ou téléchargement par étape.`);
            renderCalcList();
            return;
        }
        const paths = getWorkflowPaths();
        await refreshAdoptedScf(APP.files[APP.workflow]);
        const written = await persistWorkflowFiles(APP.files[APP.workflow]);
        if (written.ok) {
            setGenStatus('success',
                `✅ ${written.saved} fichier(s) <strong>${WORKFLOW_LABEL[APP.workflow].name}</strong> dans <code>${paths.workDir}/</code>. ` +
                `Chemins : ${qePathsStatusHtml()} (SCF copie de travail alignée ; votre <code>${APP.material}.scf.in</code> source inchangé).`);
            Object.keys(APP.files[APP.workflow] || {}).forEach(k => setCalcState(k, 'ready', 'prêt'));
            renderCalcList();
        } else {
            setGenStatus('error',
                `Échec de sauvegarde : <ul>${written.failed.map(r => `<li>${r.key} (${r.name || ''}) : ${escapeHtml(r.err)}</li>`).join('')}</ul>`);
            notifyUser('La sauvegarde des inputs a échoué — voir le bandeau sous les boutons.', 'error');
        }
    }

    const setGenStatus = (kind, html) => { $('#generateStatus').innerHTML = alertBox(kind, html); };

    /* ====================================================================
     *  Onglet 2 — inputs générés
     * ==================================================================== */
    function renderInputsPanel(bundle) {
        const root = $('#inputsPanel');
        if (!root) return;
        root.innerHTML = '';
        if (!bundle) return;
        const titles = {
            scf:'1 SCF', nscf:'2 NSCF', ph:'3 ph.x', q2r:'4a q2r.x',
            matdyn:'4b matdyn.x → Tᶜ', fs:'Surface de Fermi — fs.x',
            alpha2f:'4c alpha2f.x (opt.)',
            epw:'4 epw.x → Tᶜ + Δ',
            config:'1 configs', pw_forces:'2 pw.x forces', sscha:'3 SSCHA',
        };
        const methods = APP.workflow ? [APP.workflow] : ['classic', 'epw', 'sscha'];
        const colors = { classic: '#06b6d4', epw: '#ec4899', sscha: '#f59e0b' };
        const labels = {
            classic: '📐 WF1 — Classique',
            epw:     '⚡ WF2 — EPW',
            sscha:   '🌡️ WF3 — SSCHA',
        };

        methods.forEach(method => {
            const files = bundle[method];
            if (!files || !Object.keys(files).length) return;
            const paths = APP.workflow ? getWorkflowPaths() : { workDir: `${APP.baseDir || 'inputs'}/${method}` };
            const wrap = el('div', { class: 'card', style: `border-left: 4px solid ${colors[method]};` });
            wrap.appendChild(el('h3', {}, `${labels[method]}  —  ${paths.workDir}/`));
            Object.entries(files).forEach(([key, f]) => {
                const sub = el('div', { class: 'card collapsible', 'data-open': 'false',
                                        style: `margin: 10px 0; border-left: 4px solid ${colors[method]};` });
                const header = el('div', { class: 'collapsible-header' },
                    el('div', { class: 'h-left' },
                        el('h2', { style: 'font-size:1em; margin:0;' }, `${titles[key] || key} — ${f.name}`)),
                    el('div', { class: 'h-right' },
                        el('button', { class: 'btn btn-secondary',
                            style: 'padding:5px 12px; font-size:0.82em;',
                            onclick: (e) => { e.stopPropagation(); downloadFile(f.name, f.content); } }, '⬇️ Télécharger'),
                        el('button', { class: 'btn btn-secondary',
                            style: 'padding:5px 12px; font-size:0.82em;',
                            onclick: (e) => { e.stopPropagation(); navigator.clipboard.writeText(f.content); } }, '📋 Copier'),
                        el('span', { class: 'arrow' }, '▾'),
                    )
                );
                const body = el('div', { class: 'collapsible-body' }, el('pre', {}, f.content));
                sub.appendChild(header); sub.appendChild(body);
                wrap.appendChild(sub);
            });
            root.appendChild(wrap);
        });
        bindCollapsibles();
    }

    function downloadFile(name, content) {
        const blob = new Blob([content], { type: 'text/plain' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob); a.download = name; a.click();
        URL.revokeObjectURL(a.href);
    }

    /* ====================================================================
     *  Exécution
     * ==================================================================== */
    function appendLog(html) {
        const log = $('#runLog');
        if (!log) return;
        // Journal replié par défaut : on le déplie à la première entrée
        // pour rendre le suivi visible, sans rouvrir si l'utilisateur replie.
        const card = $('#cardRunLog');
        if (card && !log.childElementCount) setCollapsibleOpen(card, true);
        const ts = `<span class="mono muted">${new Date().toLocaleTimeString('fr-FR')}</span> · `;
        const payload = String(html ?? '').trim();
        // Ne pas re-envelopper un alertBox déjà typé (sinon tout devient alert-info).
        if (/^<div\s+class="alert\s+alert-/.test(payload)) {
            const wrap = document.createElement('div');
            wrap.innerHTML = payload;
            const inner = wrap.firstElementChild;
            if (inner) {
                inner.insertAdjacentHTML('afterbegin', ts);
                log.prepend(inner);
                return;
            }
        }
        const block = el('div', { class: 'alert alert-info' });
        block.innerHTML = ts + payload;
        log.prepend(block);
    }

    async function launchStep(stepId, method, { appendOutput = false } = {}) {
        if (!APP.material || !APP.files) {
            appendLog(alertBox('error', "Génère d'abord les fichiers d'entrée."));
            return false;
        }
        const program = ({
            scf: 'pw.x', nscf: 'pw.x', ph: 'ph.x',
            q2r: 'q2r.x', matdyn: 'matdyn.x', alpha2f: 'alpha2f.x',
            epw: 'epw.x', pw_forces: 'pw.x',
            config: null, sscha: null,
        })[stepId];
        const fileObj = APP.files[method]?.[stepId];
        if (!fileObj) {
            appendLog(alertBox('error', `Fichier ${method}/${stepId} non disponible.`));
            return false;
        }
        if (!program) {
            appendLog(alertBox('warning',
                `WF3 · étape <code>${stepId}</code> : génération d'input OK, exécution automatique SSCHA bientôt disponible via l'API.`));
            setCalcState(stepId, 'ready', 'input prêt');
            return false;
        }
        const paths = getWorkflowPaths();
        const workdir = stepExecutionWorkdir(stepId, method);
        const inPath  = `${paths.workDir}/${fileObj.name}`;
        const outPath = `${paths.outputDir}/${fileObj.name.replace(/\.in$/, '.out')}`;
        const nprocs   = intv('fld_nprocs', 1);
        const nthreads = intv('fld_nthreads', 1);

        APP.runningStep = stepId;
        beginStepClock(stepId);
        markChainFocus();
        setCalcState(stepId, 'running', 'lancement…');
        appendLog(`🚀 <code>${program}</code> — input <code>${inPath}</code>, cwd <code>${workdir}/</code> (${nprocs}×${nthreads})`
            + (appendOutput ? ' · <em>reprise (append log)</em>' : '') + '.');

        const r = await SupraAPI.run({
            program, input: inPath, output: outPath, workdir, nprocs, nthreads, append_output: appendOutput,
        });
        if (!r || !r.ok) {
            appendLog(alertBox('error', `Échec lancement : ${r?.error || 'inconnu'}`));
            setCalcState(stepId, 'error', 'échec');
            APP.runningStep = null;
            clearStepClock();
            markChainFocus();
            return false;
        }
        appendLog(`📦 Job <code>${r.job_id}</code> en cours…`);
        const final = await pollJob(r.job_id, stepId);
        if (final?.status === 'completed') {
            appendLog(alertBox('success', `✅ ${program} terminé (${final.elapsed || ''}).`));
            setCalcState(stepId, 'completed', 'OK');
            return true;
        }
        if (final?.status === 'cancelled') {
            appendLog(alertBox('warning', `⏹ ${program} annulé.`));
            setCalcState(stepId, 'error', 'annulé');
            return false;
        }
        appendLog(alertBox('error', `❌ ${program} : ${final?.message || 'erreur'}`));
        setCalcState(stepId, 'error', 'échec');
        return false;
    }

    /**
     * Export .bxsf via fs.x (post-NSCF). La chaîne WF1/WF2 ne lance pas fs.x :
     * la visualisation XCrySDen n'est possible qu'après ce fichier.
     */
    async function exportFermiBxsfIfNeeded({ force = false, reason = '' } = {}) {
        if (!APP.material || !APP.apiOnline) return { ok: false, skipped: true };
        const wf = APP.workflow;
        if (!wf) return { ok: false, skipped: true };

        if (RES.data && !force) {
            const ready = pickFermiVizData()?.viz?.ready;
            if (ready) return { ok: true, skipped: true, already: true };
        }

        await inspectChain();
        if (stepState('nscf', wf) !== 'done') {
            return { ok: false, skipped: true, reason: 'nscf_incomplete' };
        }
        if (binaryAvailable('fs.x') === false) {
            notifyUser(
                '<code>fs.x</code> introuvable dans <code>QE_BIN_DIR</code> — '
                + 'relance <code>./scripts/associer_binaires_qe.sh</code>.',
                'warning');
            return { ok: false, reason: 'no_fs_binary' };
        }

        if (!APP.files?.[wf]?.fs && !await ensureFilesGenerated(true)) {
            return { ok: false, reason: 'no_fs_in' };
        }
        const fsFile = APP.files?.[wf]?.fs;
        if (!fsFile?.content) return { ok: false, reason: 'no_fs_in' };

        const paths = getWorkflowPaths();
        const inPath = `${paths.workDir}/${fsFile.name}`;
        const outName = fsFile.name.replace(/\.in$/, '.out');
        const outPath = `${paths.outputDir}/${outName}`;
        const nprocs = intv('fld_nprocs', 1);
        const nthreads = intv('fld_nthreads', 1);

        const saved = await SupraAPI.saveFile(inPath, fsFile.content);
        if (!saved?.ok) {
            notifyUser(`Impossible d'écrire <code>${inPath}</code>.`, 'error');
            return { ok: false, reason: 'save_failed' };
        }

        const tag = reason === 'fin_chaîne' ? 'fin de chaîne' : 'surface de Fermi';
        notifyUser(`Export <code>.bxsf</code> — lancement de <code>fs.x</code> (${tag})…`, 'info');
        appendLog(`🧊 <code>fs.x</code> &lt; <code>${inPath}</code> (après NSCF, pour XCrySDen).`);

        const r = await SupraAPI.run({
            program: 'fs.x',
            input: inPath,
            output: outPath,
            workdir: paths.workDir,
            nprocs,
            nthreads,
        });
        if (!r?.ok) {
            notifyUser(r?.error || 'Échec lancement fs.x.', 'error');
            return { ok: false, reason: 'launch_failed' };
        }
        const final = await pollJob(r.job_id, 'fs');
        if (final?.status === 'completed') {
            notifyUser('Fichier <code>.bxsf</code> prêt — tu peux visualiser dans XCrySDen.', 'success');
            return { ok: true };
        }
        notifyUser(final?.message || 'fs.x n\'a pas produit de .bxsf valide.', 'warning');
        return { ok: false, reason: 'fs_failed', message: final?.message };
    }

    let _activeJobId = null;

    function setCancelJobUi(visible) {
        const btn = $('#btnCancelJob');
        if (!btn) return;
        btn.style.display = visible ? '' : 'none';
        btn.disabled = !visible;
    }

    async function cancelActiveJob() {
        if (!_activeJobId) {
            notifyUser('Aucun calcul en cours à annuler.', 'warning');
            return;
        }
        const jid = _activeJobId;
        appendLog(`⏹ Annulation demandée pour <code>${jid}</code>…`);
        const r = await SupraAPI.cancelJob(jid);
        if (!r || !r.ok) {
            notifyUser(`Annulation échouée : ${r?.error || 'inconnu'}`, 'error');
            return;
        }
        notifyUser('Signal d’arrêt envoyé au job QE.', 'warning');
    }

    async function pollJob(job_id, stepId) {
        _activeJobId = job_id;
        setCancelJobUi(true);
        try {
            while (true) {
                await new Promise(r => setTimeout(r, 2500));
                const j = await SupraAPI.job(job_id);
                if (!j || !j.ok) return j;
                const st = j.status === 'running' ? 'running'
                         : j.status === 'completed' ? 'completed'
                         : j.status === 'cancelled' ? 'error'
                         : j.status === 'error' ? 'error' : 'ready';
                setCalcState(stepId, st, j.status);
                markChainFocus();
                if (j.status === 'completed' || j.status === 'error' || j.status === 'cancelled') {
                    return j;
                }
            }
        } finally {
            if (_activeJobId === job_id) _activeJobId = null;
            setCancelJobUi(false);
            if (APP.runningStep === stepId) {
                APP.runningStep = null;
                clearStepClock();
            }
            markChainFocus();
            refreshStepEstimates();
        }
    }

    function setBadge(section, kind, txtVal) {
        $$(`.badge-status[data-status-of="${section}"]`).forEach(b => {
            b.className = 'badge-status' + (kind ? ' ' + kind : '');
            if (txtVal) b.textContent = txtVal;
        });
    }

    /* ====================================================================
     *  Onglet 4 — résultats
     * ==================================================================== */
    /* ====================================================================
     *  Onglet Résultats — exploration de toute la chaîne, deux voies
     *
     *  Une seule requête (/api/results/explore) rapatrie l'inventaire des
     *  fichiers, les scalaires (λ, ω_log, ⟨ω²⟩^½, N(E_F), Δ₀…), les courbes
     *  traçables et Tᶜ pour chaque μ*. Les quatre modules ci-dessous ne font
     *  que restituer ce contenu.
     * ==================================================================== */
    const RES = { data: null, module: 'journal', busy: false, openFile: null, reqId: 0,
        routeView: null };

    const RES_ROUTE_VIEW_KEY = 'supraQE.resultsRouteView';

    function loadResultsRouteView() {
        try {
            const v = localStorage.getItem(RES_ROUTE_VIEW_KEY);
            if (v === 'active' || v === 'compare') return v;
        } catch (_) { /* ignore */ }
        return 'compare';
    }

    function getResultsRouteView() {
        if (RES.routeView === 'active' || RES.routeView === 'compare') return RES.routeView;
        return loadResultsRouteView();
    }

    function setResultsRouteView(mode) {
        RES.routeView = (mode === 'active') ? 'active' : 'compare';
        try { localStorage.setItem(RES_ROUTE_VIEW_KEY, RES.routeView); } catch (_) { /* ignore */ }
        syncResultsRouteViewUi();
        if (RES.data) {
            renderIdentityBar();
            renderKpiStrip();
            renderSynthesis();
        }
    }

    /** Workflow choisi dans Calculs (WF1 ou WF2) — sert au mode « voie active seule ». */
    function resultsFocusWorkflow() {
        return APP.workflow === 'epw' ? 'epw' : 'classic';
    }

    function synthesisShowsColumn(wf) {
        if (getResultsRouteView() !== 'active') return true;
        return wf === resultsFocusWorkflow();
    }

    function resColumnClass(wf, d) {
        const base = wf === 'classic' ? 'res-col-classic' : 'res-col-epw';
        if (!synthesisShowsColumn(wf)) return `${base} res-col-hidden`;
        if (wf === 'epw' && getResultsRouteView() === 'compare' && d
            && !routeInventoryHas(d, 'epw', 'epw_out')) {
            return `${base} res-col-residual`;
        }
        return base;
    }

    function syncResultsRouteViewUi() {
        const compare = getResultsRouteView() !== 'active';
        $('#btnResRouteCompare')?.setAttribute('aria-pressed', compare ? 'true' : 'false');
        $('#btnResRouteActive')?.setAttribute('aria-pressed', compare ? 'false' : 'true');
        const hint = $('#resRouteViewHint');
        if (!hint) return;
        const wf = resultsFocusWorkflow();
        hint.innerHTML = compare
            ? 'Par défaut : comparaison. Sans <code>epw.out</code>, la colonne EPW reste grisée.'
            : `Voie active : <strong>${escapeHtml(ROUTE_META[wf].short)}</strong> `
                + '(workflow sélectionné dans Calculs). Les exports CSV / LaTeX conservent les deux voies.';
    }

    const ROUTE_META = {
        classic: { label: 'Voie classique (ph.x + λ)', short: 'Classique',
                   color: '#0891b2', accent: '#06b6d4' },
        epw:     { label: 'Voie EPW (Wannier + Éliashberg)', short: 'EPW',
                   color: '#be185d', accent: '#ec4899' },
    };
    const K_PER_MEV = 11.604518121550082;
    const K_PER_EV = 11604.518121550082;
    const K_PER_CM1 = 1.4387768775039337;

    function pickTcRow(tcTable, preferMu = 0.13) {
        const rows = tcTable || [];
        if (!rows.length) return null;
        const exact = rows.find(r => Math.abs(r.mu_star - preferMu) < 1e-6);
        if (exact) return exact;
        // Plus proche de preferMu (ou milieu de la liste utilisateur)
        return rows.slice().sort((a, b) =>
            Math.abs(a.mu_star - preferMu) - Math.abs(b.mu_star - preferMu))[0];
    }

    function outputDirForWorkflow(wf) {
        if (!APP.material) return '';
        if (APP.workflow === wf) return getWorkflowPaths().outputDir;
        return `outputs/${APP.material}/${wf}`;
    }

    /** μ* saisis par l'utilisateur : « 0.10, 0.12, 0.14 » → [0.1, 0.12, 0.14]. */
    function resMuStars() {
        const raw = txt('fld_res_mu_stars', '0.10, 0.12, 0.14');
        const vals = raw.split(/[,;\s]+/)
            .map(s => parseFloat(s))
            .filter(v => Number.isFinite(v) && v > 0 && v < 0.6)
            .slice(0, 8);
        return vals.length ? vals : [0.10, 0.12, 0.14];
    }

    const fmtNum = (v, d = 3) => (v == null || !Number.isFinite(v)) ? null : Number(v).toFixed(d);
    /** Cellule numérique : « — » grisé quand la grandeur est absente. */
    const cell = (v, d, cls = '') => {
        const s = fmtNum(v, d);
        return s == null
            ? `<td class="res-void ${cls}">—</td>`
            : `<td class="res-num ${cls}">${s}</td>`;
    };
    const kb = n => n == null ? '—'
        : n < 1024 ? `${n} o`
        : n < 1048576 ? `${(n / 1024).toFixed(1)} Ko`
        : `${(n / 1048576).toFixed(1)} Mo`;
    const stamp = t => t ? new Date(t * 1000).toLocaleString() : '—';

    function setResStatus(html, kind = 'muted') {
        const box = $('#resExploreStatus');
        if (!box) return;
        box.className = `res-explore-status ${kind}`;
        box.innerHTML = html;
    }

    async function exploreResults() {
        if (RES.busy) {
            notifyUser('Exploration déjà en cours…', 'warning');
            return;
        }
        if (!APP.material) {
            setResStatus('Valide d\'abord un matériau (étape 1).', 'warn');
            $('#resSynthesis').innerHTML = alertBox('warning',
                'Aucun matériau actif : impossible de localiser les fichiers de sortie.');
            return;
        }
        if (!APP.apiOnline) {
            setResStatus('API hors ligne.', 'error');
            $('#resSynthesis').innerHTML = alertBox('error',
                'API injoignable : lance <code>./DEMARRER.sh</code> puis réessaie.');
            pingAPI();
            return;
        }
        const mat = APP.material;
        const reqId = ++RES.reqId;
        RES.busy = true;
        setResStatus(`Lecture des sorties « ${escapeHtml(mat)} »…`, 'muted');
        try {
            const r = await SupraAPI.exploreResults({ material: mat, mu_stars: resMuStars() });
            if (reqId !== RES.reqId || mat !== APP.material) {
                return; // réponse obsolète (changement de matériau)
            }
            if (!r || !r.ok) {
                RES.data = null;
                setResStatus('Échec de l\'exploration.', 'error');
                renderResultModules();
                $('#resSynthesis').innerHTML = alertBox('error',
                    `Exploration impossible : ${escapeHtml(r?.error || 'erreur inconnue')}`);
                pingAPI();
                return;
            }
            RES.data = r;
            RES.module = 'journal';
            const n = (r.classic.inventory.length + r.epw.inventory.length);
            const routes = ['classic', 'epw'].filter(w => r[w].has_data).map(w => ROUTE_META[w].short);
            const warnNotes = []
                .concat(r.classic?.notes || [])
                .concat(r.epw?.notes || [])
                .filter(s => /JOB DONE|erreur QE/i.test(s));
            setResStatus(
                (n
                    ? `${n} fichier(s) · ${routes.length ? routes.join(' + ') : 'aucune grandeur'}`
                    : 'Aucun fichier de résultat trouvé pour ce matériau.')
                + (warnNotes.length ? ` · ⚠️ ${warnNotes.length} alerte(s)` : ''),
                warnNotes.length ? 'warn' : 'muted');
            renderResultModules();
            updateFermiSurfaceButtonState();
            updateResultatsEmptyState();
            renderIdentityBar();
        } catch (err) {
            if (reqId !== RES.reqId) return;
            RES.data = null;
            setResStatus('Erreur pendant l\'exploration.', 'error');
            renderResultModules();
            $('#resSynthesis').innerHTML = alertBox('error',
                `Exploration interrompue : ${escapeHtml(String(err))}`);
        } finally {
            if (reqId === RES.reqId) RES.busy = false;
        }
    }

    function renderResultModules() {
        renderIdentityBar();
        renderJournal();
        renderKpiStrip();
        renderSynthesis();
        renderSpectra();
        renderAniso();
        renderInventory();
        decoratePlotInterpretations();
        updateFermiSurfaceButtonState();
        switchResModule(RES.module || 'journal');
    }

    function resNoData(msg) {
        return alertBox('info', msg + ' Les grandeurs apparaissent dès que les fichiers de sortie existent.');
    }

    function interpretLambda(lam) {
        if (lam == null || !Number.isFinite(lam)) return 'λ n\'est pas encore disponible.';
        if (lam < 0.4) return `λ = ${lam.toFixed(3)} : couplage e–p <strong>faible</strong> (régime McMillan).`;
        if (lam < 1.0) return `λ = ${lam.toFixed(3)} : couplage <strong>intermédiaire</strong> — Allen–Dynes (f₁, f₂) devient utile.`;
        return `λ = ${lam.toFixed(3)} : couplage <strong>fort</strong> — privilégier Éliashberg (EPW) plutôt que McMillan.`;
    }

    function interpretBcs(ratio) {
        if (ratio == null || !Number.isFinite(ratio)) return '';
        const d = Math.abs(ratio - 3.53);
        if (d < 0.4) return `2Δ₀/k_B Tᶜ = ${ratio.toFixed(2)} : proche de BCS (3.53), gap plutôt isotrope.`;
        if (ratio > 3.53) return `2Δ₀/k_B Tᶜ = ${ratio.toFixed(2)} : au-dessus de BCS — fort couplage et/ou anisotropie.`;
        return `2Δ₀/k_B Tᶜ = ${ratio.toFixed(2)} : sous BCS — vérifier Δ₀ et Tᶜ extraits.`;
    }

    function interpretCharacter(s) {
        if (s?.character === 'insulator') {
            const g = Number.isFinite(s.gap_eV) ? ` (Eg ≈ ${Number(s.gap_eV).toFixed(3)} eV)` : '';
            return `SCF : <strong>isolant</strong>${g} — arrêter la chaîne e–p / Tᶜ.`;
        }
        if (s?.character === 'metal') {
            const ef = Number.isFinite(s.ef_eV) ? ` E_F = ${Number(s.ef_eV).toFixed(3)} eV.` : '';
            return `SCF : <strong>métal</strong> (conducteur).${ef}`;
        }
        return '';
    }

    function interpretMagnetism(s) {
        if (!s || !s.mag_mode || s.mag_mode === 'none') return '';
        const lab = s.mag_mode_label || s.mag_mode;
        const am = s.abs_mag_bohr;
        const tm = s.total_mag_bohr;
        let mag = '';
        if (am != null && Number.isFinite(Number(am))) {
            mag = ` · |M| = <strong>${Math.abs(Number(am)).toFixed(4)}</strong> μ_B/maille`;
            if (tm != null && Number.isFinite(Number(tm))) {
                mag += ` (M_total = ${Number(tm).toFixed(4)})`;
            }
        }
        const spinNote = (s.nspin === 2 || s.mag_mode === 'collinear')
            ? ' N(E_F) du journal = <em>par spin</em> (QE).'
            : (s.mag_mode === 'soc' ? ' SOC : comparer λ/Tᶜ à la doc EPW.' : '');
        return `Magnétisme v1.4 — <strong>${escapeHtml(String(lab))}</strong>${mag}.${spinNote} `
            + 'Tᶜ BCS / McMillan : prudence si forte ferromagnétisation.';
    }

    function progressRowHtml(wf, route) {
        const steps = route?.progress || [];
        if (!steps.length) return `<p class="muted">Aucun fichier intermédiaire pour ${ROUTE_META[wf].short}.</p>`;
        const rows = steps.map(st => {
            const cls = st.done ? 'ok' : (st.has_error ? 'err' : (st.exists ? 'wait' : ''));
            const lab = st.done ? 'JOB DONE' : (st.has_error ? 'erreur' : (st.exists ? 'présent' : 'absent'));
            return `<tr>
                <td style="text-align:left;"><span class="res-progress-dot ${cls}"></span>${escapeHtml(st.label)}</td>
                <td>${st.done ? '<span class="res-badge-done">OK</span>'
                    : st.has_error ? '<span class="res-badge-err">erreur</span>'
                    : escapeHtml(lab)}</td>
                <td style="text-align:left;"><code>${escapeHtml(st.path || '—')}</code></td>
            </tr>`;
        }).join('');
        return `<div class="res-table-wrap"><table class="res-table">
            <caption>${ROUTE_META[wf].label} — avancement</caption>
            <thead><tr><th>Étape</th><th>État</th><th>Fichier</th></tr></thead>
            <tbody>${rows}</tbody></table></div>`;
    }

    function fermiSheetHtml(d) {
        const routes = ['classic', 'epw'].map(wf => ({ wf, fs: d[wf]?.curves?.fermi, s: d[wf]?.scalars || {} }));
        const ready = routes.filter(r => r.fs?.ready)
            .sort((a, b) => (b.fs.n_k_parsed || 0) - (a.fs.n_k_parsed || 0));
        const any = ready[0] || routes.find(r => r.s.ef_eV != null);
        const fs = any?.fs || {};
        const s = any?.s || {};
        const ef = s.ef_eV ?? fs.ef_eV;
        const nef = s.dos_ef;
        const wlogK = s.omega_log_K;
        const wlogEV = (wlogK != null) ? (wlogK / K_PER_EV) : null;
        const fsth = s.fsthick_eV;
        const metal = (fs.character || s.character) === 'metal';
        const insul = (fs.character || s.character) === 'insulator';
        const bits = [];
        bits.push(`Les paires de Cooper se forment <em>uniquement</em> parmi les électrons
            dans une coquille d'énergie ~ ħω<sub>D</sub> autour de E<sub>F</sub>.
            La surface de Fermi est donc le support de N(E<sub>F</sub>), de λ et de Δ<sub>k</sub>.`);
        if (ef != null) {
            bits.push(`E<sub>F</sub> = <strong>${Number(ef).toFixed(4)} eV</strong>`
                + (nef != null ? ` · N(E<sub>F</sub>) = <strong>${Number(nef).toFixed(3)}</strong> états/spin/Ry/maille` : '')
                + '.');
        }
        if (fs.ready) {
            const frac = fs.fs_fraction != null ? `${(100 * fs.fs_fraction).toFixed(1)} %` : '—';
            bits.push(`Grille : <strong>${fs.n_k_on_fs}</strong> / ${fs.n_k_parsed} k-points recoupent la SF
                (fenêtre ±${Number(fs.window_eV).toFixed(2)} eV) soit ${frac} de la zone.
                ${fs.n_bands_near_ef || 0} bande(s) coupent E<sub>F</sub>`
                + (fs.smearing ? ` · smearing ${escapeHtml(fs.smearing)}` : '')
                + (fs.degauss_Ry != null ? ` (degauss = ${Number(fs.degauss_Ry).toFixed(4)} Ry)` : '')
                + '.');
        }
        if (wlogEV != null) {
            bits.push(`Échelle phonon ħω<sub>log</sub> ≈ <strong>${(1000 * wlogEV).toFixed(1)} meV</strong>
                (${Number(wlogK).toFixed(0)} K) : c'est l'épaisseur physique de la coquille de Cooper.
                ${fsth != null ? `fsthick EPW = ${Number(fsth).toFixed(3)} eV
                    ${fsth < 3 * wlogEV ? '— un peu étroit vis-à-vis de ω_log.' : '— couvre largement ω_log.'}` : ''}`);
        }
        if (insul) {
            bits.push(`<strong>Pas de surface de Fermi</strong> (isolant) : pas de paires de Cooper, la chaîne e–p / Tᶜ s'arrête.`);
        } else if (metal) {
            bits.push(`Caractère <strong>métallique</strong> : la SF existe, le couplage e–p est licite.`);
        }
        if (s.mag_mode && s.mag_mode !== 'none') {
            const ml = s.mag_mode_label || s.mag_mode;
            bits.push(`<strong>Magnétisme v1.4</strong> (${escapeHtml(String(ml))}) : `
                + `les paires de Cooper et λ restent définis près de E_F, mais Tᶜ et le rapport BCS `
                + `demandent une lecture spin-polarisée / magnétique (doc QE/EPW).`);
            if (s.nspin === 2 && nef != null) {
                bits.push(`N(E<sub>F</sub>) ci-dessus est <strong>par spin</strong> (sortie QE nspin=2).`);
            }
        }
        const src = fs.source ? `Source de l'analyse : <code>${escapeHtml(fs.source)}</code>. ` : '';
        return `<h5>Surface de Fermi — lieu des paires de Cooper</h5>
            <div class="res-interpret">${bits.map(b => `<p style="margin:0 0 8px;">${b}</p>`).join('')}
            <p class="muted" style="margin:0;">${src}
                Visualisation 3D : <strong>XCrySDen</strong> (<code>.bxsf</code>), pas un graphe interne.
                Histogramme E−E<sub>F</sub> ci-dessous = occupation, pas la SF géométrique.</p></div>`;
    }

    const RESULT_CATALOG = [
        { group: '1 · Électronique (prérequis)',
          lead: 'Sans métal (E_F dans un continuum de bandes) le couplage e–p et Tᶜ n\'ont pas de sens.',
          items: [
            { symbol: 'E_F', label: 'énergie de Fermi', unit: 'eV', key: 'ef_eV', digits: 4,
              why: 'Niveau chimique des électrons ; les phonons couplent les états près de E_F.' },
            { symbol: 'N_e', label: 'électrons / maille', unit: '', key: 'n_electrons', digits: 2,
              why: 'Contrôle SCF : doit matcher la valence des pseudos.' },
            { symbol: 'E_tot', label: 'énergie totale SCF', unit: 'Ry', key: 'total_energy_Ry', digits: 6,
              why: 'Convergence électronique de référence.' },
            { symbol: 'N(E_F)', label: 'DOS au niveau de Fermi', unit: 'états/spin/Ry', key: 'dos_ef', digits: 3,
              why: 'Entre dans λ et dans les largeurs de raie γ_qν.' },
          ]},
        { group: '1a · Magnétisme (v1.4)',
          lead: 'Relu depuis scf.out et l\'input SCF utilisateur. Les NSCF générés reprennent nspin / starting_mag. λ et Tᶜ restent des indicateurs BCS — interprétation prudente si |M| est élevé.',
          items: [
            { symbol: 'mode', label: 'régime magnétique', unit: '', key: 'mag_mode_label', digits: 0,
              why: 'Non magnétique, collinéaire, non collinéaire ou SOC (interface Calculs v1.4).' },
            { symbol: '|M|', label: 'aimantation absolue convergée', unit: 'μ_B/maille', key: 'abs_mag_bohr', digits: 4,
              why: 'Dernière valeur imprimée par pw.x SCF (absolute magnetization).' },
            { symbol: 'M', label: 'aimantation totale (signée)', unit: 'μ_B/maille', key: 'total_mag_bohr', digits: 4,
              why: 'total magnetization ; utile pour ferromagnétisme / antiferro.' },
            { symbol: 'nspin', label: 'degrés de spin', unit: '', key: 'nspin', digits: 0,
              why: '1 non magnétique · 2 collinéaire · 4 non collinéaire / SOC.' },
          ]},
        { group: '1b · Surface de Fermi (support des paires de Cooper)',
          lead: 'La supraconductivité conventionnelle n\'existe que sur la surface de Fermi : les paires de Cooper se forment parmi les électrons dans une coquille ~ ħω_log autour de E_F. Pas de SF (isolant) ⇒ pas de Tᶜ.',
          items: [
            { symbol: 'SF', label: 'k-points avec un état à E_F', unit: '', key: 'n_k_on_fs', digits: 0,
              why: 'Nombre de k de la grille qui recoupent la surface de Fermi (±0.25 eV).' },
            { symbol: 'f_SF', label: 'fraction de la zone de Brillouin', unit: '', key: 'fs_fraction', digits: 3,
              why: 'n_k(SF) / n_k. Petite ⇒ poches de Fermi, grille k à densifier.' },
            { symbol: 'n_b(E_F)', label: 'bandes qui coupent E_F', unit: '', key: 'n_bands_near_ef', digits: 0,
              why: 'Feuillets de la surface de Fermi (un feuillet par bande qui coupe E_F).' },
            { symbol: 'n_ε', label: 'états dans ±0.25 eV', unit: '', key: 'n_states_in_window', digits: 0,
              why: 'Nombre d\'états (k, bande) dans la fenêtre d\'analyse autour de E_F.' },
            { symbol: 'degauss', label: 'largeur de smearing', unit: 'Ry', key: 'degauss_Ry', digits: 4,
              why: 'Élargissement des occupations ; trop large brouille N(E_F) et λ.' },
            { symbol: 'fsthick', label: 'fenêtre EPW autour de E_F', unit: 'eV', key: 'fsthick_eV', digits: 3,
              why: 'Doit englober ħω_log et les états qui portent α²F (typ. 0.2–0.6 eV).' },
          ]},
        { group: '2 · Phonons (stabilité et spectre)',
          lead: 'Les phonons transmettent l\'attraction e–e. Un mode mou (ω < 0) invalide Tᶜ.',
          items: [
            { symbol: 'ω(q)', label: 'dispersion phononique', unit: '', curve: 'dispersion',
              why: 'Branches ω_qν ; source des IFC après q2r.x (voie classique).' },
            { symbol: 'F(ω)', label: 'DOS phononique', unit: '', curve: 'phdos',
              why: 'Densité d\'états des phonons ; à comparer à α²F(ω).' },
            { symbol: 'ω_min', label: 'plus basse fréquence', unit: '', key: 'omega_min', digits: 2,
              why: 'Si négative : instabilité structurale, Tᶜ non publiable.' },
            { symbol: 'γ_qν', label: 'largeur de raie e–p', unit: 'GHz', key: 'gamma_max', digits: 2,
              why: 'Max des largeurs DFPT ; liées à λ_qν et N(E_F).' },
          ]},
        { group: '3 · Fonction spectrale d\'Éliashberg α²F(ω) et λ',
          lead: 'Cœur du couplage : α²F(ω) est la fonction spectrale ; λ en est le moment 1/ω.',
          items: [
            { symbol: 'α²F(ω)', label: 'fonction spectrale d\'Éliashberg', unit: '', curve: 'a2f',
              why: 'Poids du couplage e–p par fréquence de phonon. Courbe principale à publier.' },
            { symbol: 'λ', label: 'constante de couplage', unit: '', key: 'lambda', digits: 3,
              why: 'λ = 2 ∫ α²F(ω)/ω dω. Faible < 0.4 · intermédiaire 0.4–1 · fort > 1.' },
            { symbol: 'λ(ω)', label: 'couplage cumulatif', unit: '', curve: 'a2f',
              why: 'Intégrale partielle ; doit saturer vers λ total aux hautes ω.' },
            { symbol: 'ω_log', label: 'moyenne logarithmique', unit: 'K', key: 'omega_log_K', digits: 1,
              why: 'Échelle de phonon qui entre dans McMillan / Allen–Dynes : Tᶜ ∝ ω_log.' },
            { symbol: '⟨ω²⟩^½', label: 'moyenne quadratique', unit: 'K', key: 'omega_2_K', digits: 1,
              why: 'Corrige Allen–Dynes (f₂) en fort couplage.' },
            { symbol: 'λ_qν', label: 'couplage mode par mode', unit: '', key: 'lambda_qnu_max', digits: 3,
              why: 'Identifie quels phonons (et quels q) portent le couplage.' },
          ]},
        { group: '4 · Paramètre de Coulomb effectif μ*',
          lead: 'μ* (Morel–Anderson) ou μ_c (EPW) est le pseudo-potentiel de Coulomb : paramètre d\'entrée, pas une observable DFT.',
          items: [
            { symbol: 'μ*', label: 'Coulomb effectif (balayage)', unit: '', special: 'mu_scan',
              why: 'Valeurs typiques 0.10–0.15. On balaye pour voir la sensibilité de Tᶜ.' },
            { symbol: 'μ_c', label: 'Coulomb utilisé par le code', unit: '', key: 'mu_star_reported', digits: 3,
              why: 'μ* imprimé par lambda.x / μ_c d\'epw.x (souvent 0.10).' },
            { symbol: 'f₁, f₂', label: 'corrections Allen–Dynes', unit: '', key: 'f1', digits: 3,
              why: 'f₁(λ, μ*) et f₂(ω_log, ⟨ω²⟩) : Tᶜ_AD = f₁ f₂ Tᶜ_McMillan.' },
          ]},
        { group: '5 · Température critique Tᶜ',
          lead: 'Grandeur cible. Formules (McMillan / Allen–Dynes) sur les deux voies ; fermeture de Δ(T) pour EPW.',
          items: [
            { symbol: 'Tᶜ McMillan', label: 'formule 1968', unit: 'K', special: 'tc_mcmillan', digits: 2,
              why: 'Valable surtout si λ ≲ 1. Sous-estime souvent le fort couplage.' },
            { symbol: 'Tᶜ Allen–Dynes', label: 'formule 1975 + f₁ f₂', unit: 'K', special: 'tc_ad', digits: 2,
              why: 'Référence de la voie classique (et estimation EPW hors Éliashberg).' },
            { symbol: 'Tᶜ Éliashberg', label: 'fermeture du gap Δ(T)', unit: 'K', key: 'tc_interp_K', digits: 2,
              why: 'Référence physique EPW : T où Δ s\'annule. Indépendante du μ* de McMillan.' },
            { symbol: 'Tᶜ code', label: 'valeur imprimée', unit: 'K', key: 'tc_reported_K', digits: 2,
              why: 'Tᶜ écrite par lambda.x ou epw.x ; à recouper avec les formules.' },
          ]},
        { group: '6 · Gap supraconducteur Δ',
          lead: 'Δ₀ isotrope, Δ(T), et Δ_k sur la surface de Fermi (anisotropie, plusieurs feuillets).',
          items: [
            { symbol: 'Δ₀', label: 'gap isotrope T → 0', unit: 'meV', key: 'gap_meV', digits: 3,
              why: 'Ouverture du gap à basse T. Voie EPW (Éliashberg).' },
            { symbol: 'Δ(T)', label: 'dépendance en température', unit: 'meV', curve: 'gap_vs_T',
              why: 'Courbe Δ vs T : Tᶜ = température de fermeture. Signature d\'un SC conventionnel.' },
            { symbol: 'Δ_k', label: 'gap anisotrope (distribution)', unit: 'meV', curve: 'gap_distribution',
              why: 'Histogramme sur la surface de Fermi. Un pic = isotrope ; plusieurs = multi-gap (ex. MgB₂).' },
            { symbol: '⟨Δ_k⟩', label: 'moyenne sur k', unit: 'meV', key: 'gap_mean_meV', digits: 3,
              why: 'Moyenne de la distribution anisotrope.' },
            { symbol: 'Δ_k min / max', label: 'étendue anisotrope', unit: 'meV', key: 'gap_spread_meV', digits: 3,
              why: 'Écart max−min : mesure de l\'anisotropie du gap.' },
            { symbol: '2Δ₀ / k_B Tᶜ', label: 'rapport BCS', unit: '', key: 'bcs_ratio', digits: 2,
              why: 'BCS = 3.53. Au-dessus : fort couplage et/ou anisotropie.' },
            { symbol: 'Z(0)', label: 'renormalisation de masse 1+λ', unit: '', key: 'z_factor', digits: 3,
              why: 'Masse effective des électrons renormalisée par les phonons.' },
          ]},
        { group: '7 · Diagnostics EPW (qualité de l\'interpolation)',
          lead: 'Sans Wannier de bonne qualité, λ et Δ_k interpolés ne sont pas fiables.',
          items: [
            { symbol: 'fsthick', label: 'fenêtre autour de E_F', unit: 'eV', key: 'fsthick_eV', digits: 3,
              why: 'Doit couvrir les états qui portent le couplage (typ. 0.2–0.6 eV).' },
            { symbol: 'nbndsub', label: 'bandes Wannier', unit: '', key: 'nbndsub', digits: 0,
              why: 'Nombre d\'orbitales projetées ; trop petit tronque λ.' },
            { symbol: 'decay', label: 'décroissance Wannier', unit: '', curve: 'decay',
              why: 'Plus la décroissance est rapide, meilleure est la localisation.' },
            { symbol: 'λ(q,ν)', label: 'couplage interpolé', unit: '', curve: 'lambda_pairs',
              why: 'Carte du couplage sur la zone de Brillouin après Fourier.' },
          ]},
    ];

    function catalogPick(item, route) {
        if (!route) return { value: null, ready: false };
        if (item.curve) {
            const c = route.curves?.[item.curve];
            const ready = !!(c && (c.n_points || c.n_values || c.pairs?.length || c.n_qpoints || c.n_series));
            return { value: ready ? 'courbe' : null, ready };
        }
        const v = route.scalars?.[item.key];
        return { value: v, ready: v != null && v !== '' };
    }

    function catalogSpecial(item, d) {
        const preferMu = (resMuStars()[1] != null) ? resMuStars()[1] : 0.13;
        if (item.special === 'mu_scan') {
            const mus = d.mu_stars || resMuStars();
            return { classic: mus.map(m => Number(m).toFixed(2)).join(', '), epw: 'idem', ready: mus.length > 0 };
        }
        if (item.special === 'tc_mcmillan') {
            const c = pickTcRow(d.classic?.tc_table, preferMu);
            const e = pickTcRow(d.epw?.tc_table, preferMu);
            return {
                classic: c?.tc_mcmillan_K, epw: e?.tc_mcmillan_K,
                ready: c?.tc_mcmillan_K != null || e?.tc_mcmillan_K != null,
            };
        }
        if (item.special === 'tc_ad') {
            const c = pickTcRow(d.classic?.tc_table, preferMu);
            const e = pickTcRow(d.epw?.tc_table, preferMu);
            return {
                classic: c?.tc_allen_dynes_K, epw: e?.tc_allen_dynes_K,
                ready: c?.tc_allen_dynes_K != null || e?.tc_allen_dynes_K != null,
            };
        }
        return null;
    }

    function fmtCat(v, digits) {
        if (v == null || v === '') return null;
        if (typeof v === 'string') return v;
        if (typeof v === 'number' && Number.isFinite(v)) return Number(v).toFixed(digits ?? 3);
        return String(v);
    }

    function renderResultCatalog(d) {
        if (!d) return '';
        const blocks = RESULT_CATALOG.map(g => {
            const rows = g.items.map(it => {
                const sp = catalogSpecial(it, d);
                const c = sp ? { value: sp.classic, ready: sp.ready } : catalogPick(it, d.classic);
                const e = sp ? { value: sp.epw, ready: sp.ready } : catalogPick(it, d.epw);
                const ready = !!(c.ready || e.ready);
                const cellC = fmtCat(c.value, it.digits);
                const cellE = fmtCat(e.value, it.digits);
                return `<tr class="${ready ? '' : 'res-cat-wait-row'}">
                    <td style="text-align:left;"><strong>${escapeHtml(it.symbol)}</strong><div class="muted" style="font-size:0.82em;">${escapeHtml(it.label)}</div></td>
                    <td class="res-unit">${escapeHtml(it.unit || '—')}</td>
                    <td class="${cellC ? 'res-num res-col-classic' : 'res-void'}">${cellC || 'en attente'}</td>
                    <td class="${cellE ? 'res-num res-col-epw' : 'res-void'}">${cellE || 'en attente'}</td>
                    <td style="text-align:left; white-space:normal; font-size:0.86em;">${escapeHtml(it.why)}</td>
                </tr>`;
            }).join('');
            return `<div class="res-table-wrap">
                <table class="res-table">
                    <caption>${escapeHtml(g.group)}</caption>
                </table>
                <p class="res-interpret" style="margin-top:0;">${escapeHtml(g.lead)}</p>
                <table class="res-table">
                    <thead><tr>
                        <th>Grandeur</th><th>Unité</th>
                        <th class="res-col-classic">Classique</th>
                        <th class="res-col-epw">EPW</th>
                        <th>Pourquoi c'est nécessaire</th>
                    </tr></thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>`;
        }).join('');
        return `<h5>Catalogue des résultats nécessaires</h5>
            <p class="muted">Toutes les grandeurs d'un calcul de supraconductivité conventionnelle (phonons).
            « en attente » = le fichier n'est pas encore là ; la ligne reste pour ne rien oublier.</p>
            ${blocks}`;
    }

    function magnetismSummaryLine(scalars) {
        const s = scalars || {};
        if (!s.mag_mode || s.mag_mode === 'none') return '';
        const lab = s.mag_mode_label || s.mag_mode;
        const am = s.abs_mag_bohr;
        const sm = Array.isArray(s.starting_mag_list) && s.starting_mag_list.length
            ? ` · starting_mag = ${s.starting_mag_list.join(', ')}` : '';
        const mag = (am != null && Number.isFinite(Number(am)))
            ? ` · |M| = ${Math.abs(Number(am)).toFixed(4)} μ_B/maille` : '';
        return ` · Magnétisme : ${escapeHtml(String(lab))}${mag}${escapeHtml(sm)}`;
    }

    function magnetismSheetHtml(d) {
        const sc = d?.classic?.scalars || {};
        const se = d?.epw?.scalars || {};
        const s = (sc.mag_mode && sc.mag_mode !== 'none') ? sc : se;
        if (!s.mag_mode || s.mag_mode === 'none') return '';
        const bits = [
            `<strong>Contexte v1.4</strong> — Calculs avec ${escapeHtml(String(s.mag_mode_label || s.mag_mode))}. `
            + `Les NSCF générés reprennent les mêmes clés spin. `
            + `λ, ω<sub>log</sub> et T<sub>c</sub> (McMillan / Allen–Dynes / Éliashberg) restent des indicateurs `
            + `<em>BCS / métal conventionnel</em> : à interpréter avec prudence si |M| est élevé ou en présence de SOC.`,
        ];
        if (s.nspin === 2) {
            bits.push('N(E<sub>F</sub>) extrait des sorties QE est <strong>par spin</strong> (nspin=2).');
        }
        if (s.mag_mode === 'soc') {
            bits.push('SOC : valider ph.x / epw.x avec la documentation QE/EPW pour votre matériau.');
        }
        if (s.abs_mag_bohr != null) {
            bits.push(`Aimantation convergée (scf.out) : |M| = <strong>${Math.abs(Number(s.abs_mag_bohr)).toFixed(4)}</strong> `
                + `μ_B/maille`
                + (s.total_mag_bohr != null ? `, M_total = ${Number(s.total_mag_bohr).toFixed(4)}` : '')
                + '.');
        }
        if (Array.isArray(s.starting_mag_list) && s.starting_mag_list.length) {
            bits.push(`starting_magnetization (input SCF) : ${s.starting_mag_list.join(', ')} `
                + '(ordre ATOMIC_SPECIES).');
        }
        bits.push('Références utiles : doc Quantum ESPRESSO (nspin, non-collinear), tutoriels EPW pour métaux magnétiques.');
        return `<h5>Magnétisme et supraconductivité — lecture pour publication</h5>
            <div class="res-interpret">${bits.map(b => `<p style="margin:0 0 8px;">${b}</p>`).join('')}</div>`;
    }

    function renderIdentityBar() {
        const bar = $('#resIdentityBar');
        if (!bar) return;
        if (APP.mainView !== 'resultats' || !APP.material) {
            bar.hidden = true;
            bar.innerHTML = '';
            return;
        }
        const d = (typeof RES !== 'undefined') ? RES.data : null;
        const nC = d?.classic?.inventory?.length || 0;
        const nE = d?.epw?.inventory?.length || 0;
        const stC = d?.classic?.has_data ? (nC ? `${nC} fichier(s)` : 'détectée') : 'pas encore de sorties';
        const stE = d?.epw?.has_data ? (nE ? `${nE} fichier(s)` : 'détectée') : 'pas encore de sorties';
        const mag = magnetismSummaryLine(d?.classic?.scalars) || magnetismSummaryLine(d?.epw?.scalars);
        bar.hidden = false;
        if (getResultsRouteView() === 'active') {
            const f = resultsFocusWorkflow();
            const st = f === 'epw' ? stE : stC;
            bar.innerHTML = `<strong>${escapeHtml(APP.material)}</strong>
                — affichage <em>voie active</em> : ${escapeHtml(ROUTE_META[f].short)}
                · ${st}${mag}`;
        } else {
            bar.innerHTML = `<strong>${escapeHtml(APP.material)}</strong>
                — fiche de résultats des <em>deux</em> voies
                · Classique : ${stC}
                · EPW : ${stE}${mag}`;
        }
    }

    function renderJournal() {
        const box = $('#resJournal');
        if (!box) return;
        const d = RES.data;
        if (!d) {
            box.innerHTML = resNoData('Journal vide : valide un matériau, les sorties sont lues automatiquement.');
            return;
        }
        const sc = d.classic?.scalars || {};
        const se = d.epw?.scalars || {};
        const remarks = [];
        const chC = interpretCharacter(sc);
        const chE = interpretCharacter(se);
        if (chC) remarks.push(chC);
        if (chE && chE !== chC) remarks.push('EPW — ' + chE);
        const magC = interpretMagnetism(sc);
        const magE = interpretMagnetism(se);
        if (magC) remarks.push(magC);
        if (magE && magE !== magC) remarks.push('EPW — ' + magE);
        remarks.push(interpretLambda(sc.lambda ?? se.lambda));
        if (sc.lambda != null && se.lambda != null && sc.lambda > 0) {
            const dp = 100 * (se.lambda - sc.lambda) / sc.lambda;
            remarks.push(`Écart λ EPW vs classique : ${dp >= 0 ? '+' : ''}${dp.toFixed(1)} %. `
                + (Math.abs(dp) > 20
                    ? 'Écart notable : vérifier fenêtres Wannier, fsthick et grilles k/q.'
                    : 'Les deux voies sont cohérentes à ce stade.'));
        }
        const bcs = interpretBcs(se.bcs_ratio);
        if (bcs) remarks.push(bcs);
        if (sc.soft_modes) remarks.push('Modes phononiques mous (ω_min < 0) : Tᶜ à interpréter avec prudence.');
        (d.classic?.notes || []).concat(d.epw?.notes || []).forEach(n => remarks.push(escapeHtml(n)));

        const nFiles = (d.classic?.inventory?.length || 0) + (d.epw?.inventory?.length || 0);
        box.innerHTML = `
            <div class="res-journal-head">
                <h3>Journal de résultats — ${escapeHtml(d.material)}</h3>
                <p class="muted" style="margin:0;">
                    ${new Date().toLocaleString()} · ${nFiles} fichier(s) · μ* = ${
                        (d.mu_stars || []).map(m => Number(m).toFixed(2)).join(', ') || '—'}
                </p>
            </div>
            <h5>Résultats intermédiaires (chaîne)</h5>
            ${progressRowHtml('classic', d.classic)}
            ${progressRowHtml('epw', d.epw)}
            ${magnetismSheetHtml(d)}
            ${fermiSheetHtml(d)}
            <h5>Remarques et interprétations</h5>
            <div class="res-interpret">${remarks.map(r => `<p style="margin:0 0 8px;">${r}</p>`).join('')}</div>
            ${renderResultCatalog(d)}
            <p class="muted" style="margin:0;">
                Courbes (α²F, Δ(T), Δ_k, dispersion…) : dérouler la page.
                Fiche autonome : boutons <strong>Ouvrir HTML</strong> / <strong>Ouvrir PDF</strong> en tête du journal.
            </p>`;
        if (typeof SupraI18n !== 'undefined' && SupraI18n.refresh) SupraI18n.refresh(box);
    }

    function decoratePlotInterpretations() {
        const d = RES.data;
        const caps = {
            resPlotA2F: 'α²F(ω) pèse le couplage e–p par fréquence : les pics indiquent les phonons qui portent λ. λ(ω) cumulatif doit saturer vers λ total.',
            resPlotA2FCompare: 'Comparer les deux voies sur le même axe (meV) : un décalage des pics signale une interpolation Wannier ou un élargissement différents.',
            resPlotBroadenings: 'λ vs σ (élargissement gaussien) : une valeur stable aux grands σ est plus fiable qu\'un pic étroit.',
            resPlotDispersion: 'Dispersion ω(q) : une branche imaginaire (ω < 0) indique une instabilité structurale.',
            resPlotModeCoupling: 'λ_qν par mode : identifie quels phonons (et quels q) dominent le couplage.',
            resPlotGammaOmega: 'Largeurs de raie γ_qν : liées à λ_qν et à N(E_F) ; des γ énormes peuvent trahir un smearing trop fort.',
            resPlotGapT: 'Δ(T) EPW : Tᶜ est la température où le gap se ferme. Plus fiable que McMillan pour λ ≳ 1.',
            resPlotFermi: 'Histogramme des états E−E_F (occupation) : ce n\'est pas la surface 3D. La SF se visualise dans XCrySDen via le fichier .bxsf produit par fs.x.',
            resPlotGapHist: 'Histogramme Δ_k : un seul pic → gap isotrope ; plusieurs pics → feuillets / anisotropie.',
            resPlotLambdaPairs: 'λ(q,ν) interpolé EPW : carte du couplage sur la zone de Brillouin.',
            resPlotDecay: 'Décroissance Wannier : plus c\'est rapide, meilleure est la localisation (qualité de l\'interpolation).',
            resPlotSpecfun: 'Fonction spectrale / self-énergie : renormalisation des électrons par les phonons.',
            resPlotPband: 'Bandes renormalisées : comparaison à la dispersion DFT nue.',
        };
        Object.entries(caps).forEach(([id, text]) => {
            const host = $('#' + id);
            if (!host || !host.innerHTML || host.querySelector('.res-interpret')) return;
            if (!d) return;
            const card = host.querySelector('.res-plot-card') || host;
            if (!card.querySelector('svg') && !host.querySelector('.res-plot-card')) return;
            const p = document.createElement('div');
            p.className = 'res-interpret';
            p.innerHTML = text;
            host.appendChild(p);
        });
    }

    function kpiCard({ label, value, unit, sub, route, warn }) {
        if (value == null || value === '') return '';
        return `<div class="res-kpi" data-route="${route || 'both'}" data-warn="${warn ? 'true' : 'false'}">
            <div class="res-kpi-label">${escapeHtml(label)}</div>
            <div class="res-kpi-value">${escapeHtml(String(value))}${
                unit ? `<span class="res-kpi-unit">${escapeHtml(unit)}</span>` : ''}</div>
            ${sub ? `<div class="res-kpi-sub">${sub}</div>` : ''}
        </div>`;
    }

    function renderKpiStrip() {
        const strip = $('#resKpiStrip');
        const soft = $('#resSoftFlag');
        if (!strip) return;
        const d = RES.data;
        if (!d) {
            strip.innerHTML = '';
            if (soft) soft.innerHTML = '';
            return;
        }
        const sc = d.classic?.scalars || {};
        const se = d.epw?.scalars || {};
        const preferMu = (resMuStars()[1] != null) ? resMuStars()[1] : 0.13;
        const adC = pickTcRow(d.classic?.tc_table, preferMu);
        const adE = pickTcRow(d.epw?.tc_table, preferMu);
        const muSub = (row) => (row && row.mu_star != null)
            ? `formule · μ*=${Number(row.mu_star).toFixed(2)}` : '';
        const magSub = (s) => {
            if (!s?.mag_mode || s.mag_mode === 'none') return '';
            const am = s.abs_mag_bohr;
            if (am == null || !Number.isFinite(Number(am))) return s.mag_mode_label || s.mag_mode;
            return `${s.mag_mode_label || s.mag_mode} · |M|=${Math.abs(Number(am)).toFixed(3)} μ_B`;
        };
        const cards = [
            kpiCard({ label: 'Magnétisme', value: sc.mag_mode_label || se.mag_mode_label || '—', route: 'both',
                sub: magSub(sc) || magSub(se) || '', warn: (sc.mag_mode && sc.mag_mode !== 'none') }),
            kpiCard({ label: 'λ classique', value: fmtNum(sc.lambda, 3), route: 'classic',
                sub: sc.omega_log_K != null ? `ω_log = ${fmtNum(sc.omega_log_K, 1)} K` : '' }),
            kpiCard({ label: 'λ EPW', value: fmtNum(se.lambda, 3), route: 'epw',
                sub: se.omega_log_K != null ? `ω_log = ${fmtNum(se.omega_log_K, 1)} K` : '' }),
            kpiCard({ label: 'Tᶜ Allen–Dynes', value: fmtNum(adC?.tc_allen_dynes_K, 2), unit: 'K',
                route: 'classic', sub: muSub(adC) }),
            kpiCard({ label: 'Tᶜ Éliashberg', value: fmtNum(se.tc_interp_K || se.tc_reported_K, 2),
                unit: 'K', route: 'epw',
                sub: se.tc_interp_K != null ? 'fermeture du gap Δ(T)' : 'annoncée par epw.x' }),
            kpiCard({ label: 'μ* / μ_c', value: fmtNum(se.mu_star_reported ?? sc.mu_star_reported, 3),
                route: 'both', sub: `balayage ${resMuStars().map(m => m.toFixed(2)).join(', ')}` }),
            kpiCard({ label: 'Δ₀', value: fmtNum(se.gap_meV, 3), unit: 'meV', route: 'epw',
                sub: se.bcs_ratio != null ? `2Δ/kTᶜ = ${fmtNum(se.bcs_ratio, 2)}` : '' }),
            kpiCard({ label: '⟨Δ_k⟩', value: fmtNum(se.gap_mean_meV, 3), unit: 'meV', route: 'epw',
                sub: se.n_gap_sheets != null ? `${se.n_gap_sheets} feuillet(s)` : 'distribution anisotrope' }),
            kpiCard({ label: 'N(E_F)', value: fmtNum(sc.dos_ef ?? se.dos_ef, 3),
                route: 'both', sub: 'états/spin/Ry/maille' }),
            kpiCard({ label: 'k sur la SF',
                value: fmtNum(sc.n_k_on_fs ?? se.n_k_on_fs, 0),
                route: 'both',
                sub: (sc.fs_fraction ?? se.fs_fraction) != null
                    ? `${(100 * (sc.fs_fraction ?? se.fs_fraction)).toFixed(1)} % de la zone`
                    : 'k-points à ±0.25 eV de E_F' }),
        ].filter(Boolean);
        strip.innerHTML = cards.length ? cards.join('') : '';
        const view = getResultsRouteView();
        const focus = resultsFocusWorkflow();
        const epwDone = epwWorkflowFinished(d);
        strip.querySelectorAll('.res-kpi[data-route]').forEach(el => {
            const r = el.dataset.route;
            let hidden = false;
            if (view === 'active') {
                if (r === 'classic' && focus !== 'classic') hidden = true;
                if (r === 'epw' && focus !== 'epw') hidden = true;
            }
            el.classList.toggle('res-kpi-route-hidden', hidden);
            el.classList.toggle('res-col-residual',
                !hidden && r === 'epw' && view === 'compare' && !epwDone);
        });

        if (soft) {
            const softClassic = sc.soft_modes || (sc.omega_min != null && sc.omega_min < 0);
            soft.innerHTML = softClassic
                ? alertBox('warning',
                    `<strong>Modes mous détectés</strong> — ω_min = ${fmtNum(sc.omega_min, 2)} `
                    + `${escapeHtml(sc.omega_min_unit || 'cm⁻¹')}. `
                    + 'La structure phononique est instable : interprète Tᶜ avec prudence.')
                : '';
        }
    }

    function routeInventoryHas(d, wf, key) {
        return !!(d?.[wf]?.inventory || []).some(it => it.key === key);
    }

    /** true si epw.x a produit une sortie (sinon colonne EPW = reprise SCF / fichiers communs). */
    function epwWorkflowFinished(d) {
        return routeInventoryHas(d, 'epw', 'epw_out');
    }

    /* ── Module 1 : synthèse scalaire ─────────────────────────────────── */
    function renderSynthesis() {
        const box = $('#resSynthesis');
        if (!box) return;
        const d = RES.data;
        if (!d) {
            box.innerHTML = resNoData('Aucune donnée chargée.');
            return;
        }
        const syn = d.synthesis;
        const html = [];
        const tcEliash = d.epw?.scalars?.tc_interp_K;
        const epwRan = epwWorkflowFinished(d);
        const classicMatdyn = routeInventoryHas(d, 'classic', 'matdyn_out')
            || routeInventoryHas(d, 'classic', 'lambda_out');
        const compareView = getResultsRouteView() === 'compare';
        const showDelta = compareView;
        const clsClassic = resColumnClass('classic', d);
        const clsEpw = resColumnClass('epw', d);

        if (getResultsRouteView() === 'active') {
            const f = resultsFocusWorkflow();
            html.push(alertBox('info',
                `<strong>Mode voie active</strong> — seule la colonne `
                + `<strong>${escapeHtml(ROUTE_META[f].short)}</strong> est affichée ici. `
                + 'L’API explore toujours les deux dossiers ; bascule sur '
                + '<em>Comparer les deux voies</em> pour l’écart %.'));
        }

        if (compareView && d.epw?.has_data && !epwRan) {
            html.push(alertBox('warning',
                '<strong>Colonne EPW sans calcul EPW</strong> — l’onglet Résultats explore '
                + 'toujours <em>les deux voies</em>. Tant qu’il n’y a pas de '
                + '<code>outputs/&lt;mat&gt;/epw/&lt;mat&gt;.epw.out</code>, la colonne '
                + '<strong>EPW</strong> peut quand même afficher des nombres '
                + '(E<sub>F</sub>, magnétisme, surface de Fermi…) repris du '
                + '<strong>SCF partagé</strong> avec le classique — ce ne sont '
                + '<em>pas</em> des résultats Wannier / Éliashberg. '
                + 'λ, T<sub>c</sub> EPW et Δ n’apparaissent qu’après <code>epw.x</code> '
                + '(colonne grisée).'));
        }
        if (d.classic?.has_data && !classicMatdyn && routeInventoryHas(d, 'classic', 'ph_out')) {
            html.push(alertBox('info',
                '<strong>Classique en cours</strong> — sans <code>matdyn.out</code> / '
                + '<code>lambda.out</code>, λ et T<sub>c</sub> McMillan peuvent manquer ; '
                + 'certaines lignes viennent déjà de <code>ph.x</code> (γ<sub>qν</sub>, N(E<sub>F</sub>)).'));
        }

        if (!syn.rows.length) {
            html.push(alertBox('warning',
                `Aucune grandeur extraite pour <strong>${escapeHtml(d.material)}</strong>. `
                + 'Vérifie que la chaîne est allée jusqu\'à <code>matdyn.x</code>/<code>lambda.x</code> '
                + '(voie classique) ou <code>epw.x</code> (voie EPW).'));
        } else {
            html.push(`
            <div class="res-table-wrap">
                <table class="res-table">
                    <caption>Grandeurs extraites — μ* balayés : ${d.mu_stars.map(m => m.toFixed(2)).join(' / ')}</caption>
                    <thead><tr>
                        <th>Grandeur</th><th>Unité</th>
                        <th class="${clsClassic}">Classique${classicMatdyn ? '' : ' <span class="muted">(partiel)</span>'}</th>
                        <th class="${clsEpw}">EPW${epwRan ? '' : ' <span class="muted">(SCF partagé)</span>'}</th>
                        ${showDelta ? '<th>Écart</th>' : ''}
                    </tr></thead>
                    <tbody>${syn.rows.map(r => `
                        <tr>
                            <td>${escapeHtml(r.label)}</td>
                            <td class="res-unit">${escapeHtml(r.unit || '—')}</td>
                            ${cell(r.classic, r.digits, clsClassic)}
                            ${cell(r.epw, r.digits, clsEpw)}
                            ${showDelta ? `<td class="${r.delta_pct == null ? 'res-void'
                                : (r.delta_pct >= 0 ? 'res-num res-delta-pos' : 'res-num res-delta-neg')}">${
                                r.delta_pct == null ? '—'
                                    : (r.delta_pct >= 0 ? '+' : '') + r.delta_pct.toFixed(1) + ' %'}</td>` : ''}
                        </tr>`).join('')}
                    </tbody>
                </table>
            </div>`);
        }

        html.push(`
        <div class="res-table-wrap">
            <table class="res-table">
                <caption>Tᶜ (K) vs μ* — formules McMillan / Allen–Dynes
                    ${tcEliash != null ? ` · Tᶜ Éliashberg EPW = <strong>${fmtNum(tcEliash, 2)} K</strong> (indépendant de μ*)` : ''}</caption>
                <thead><tr>
                    <th>μ*</th>
                    <th class="${clsClassic}">McMillan</th>
                    <th class="${clsClassic}">Allen–Dynes</th>
                    <th class="${clsEpw}">McMillan</th>
                    <th class="${clsEpw}">Allen–Dynes</th>
                    <th class="${clsEpw}">Éliashberg</th>
                </tr></thead>
                <tbody>${syn.tc_rows.map(r => `
                    <tr>
                        <td class="res-num">${r.mu_star.toFixed(2)}</td>
                        <td class="res-num ${clsClassic}">${fmtNum(r.classic_mcmillan_K, 2) ?? '—'}</td>
                        <td class="res-num ${clsClassic}"><strong>${fmtNum(r.classic_allen_dynes_K, 2) ?? '—'}</strong></td>
                        <td class="res-num ${clsEpw}">${fmtNum(r.epw_mcmillan_K, 2) ?? '—'}</td>
                        <td class="res-num ${clsEpw}">${fmtNum(r.epw_allen_dynes_K, 2) ?? '—'}</td>
                        <td class="res-num ${clsEpw}"><strong>${fmtNum(tcEliash, 2) ?? '—'}</strong></td>
                    </tr>`).join('')}
                </tbody>
            </table>
            <p class="muted" style="font-size:0.8em; margin:6px 0 0;">
                Allen–Dynes = McMillan × f₁ × f₂. La colonne Éliashberg vient de la fermeture de Δ(T)
                (ou de la Tᶜ imprimée par <code>epw.x</code>) — c’est la référence physique pour EPW.
            </p>
        </div>`);

        ['classic', 'epw'].forEach(wf => {
            const r = d[wf];
            if (!r.notes.length) return;
            html.push(alertBox('info',
                `<strong>${ROUTE_META[wf].short}</strong> — ` + r.notes.map(escapeHtml).join(' ')));
        });

        box.innerHTML = html.join('');
    }

    /* ── Module 2 : spectres 2D ───────────────────────────────────────── */
    function renderSpectra() {
        const d = RES.data;
        const a2fBox = $('#resPlotA2F');
        const cmpBox = $('#resPlotA2FCompare') || $('#resPlotPhdos');
        const brBox = $('#resPlotBroadenings');
        const dispBox = $('#resPlotDispersion');
        const modeBox = $('#resPlotModeCoupling');
        const gamBox = $('#resPlotGammaOmega');
        const gapBox = $('#resPlotGapT');
        if (!a2fBox) return;
        const clear = (...boxes) => boxes.forEach(b => { if (b) b.innerHTML = ''; });
        if (!d) {
            a2fBox.innerHTML = resNoData('Aucune courbe chargée.');
            clear(cmpBox, brBox, dispBox, modeBox, gamBox, gapBox);
            return;
        }

        // α²F(ω) + F(ω) + λ(ω) par voie
        const cards = [];
        ['classic', 'epw'].forEach(wf => {
            const c = d[wf].curves?.a2f;
            if (!c || !c.n_points) return;
            const meta = ROUTE_META[wf];
            const pts = c.omega.map((w, i) => [w, c.a2f[i]]);
            const lamPts = (c.lambda_w || []).length
                ? c.omega.map((w, i) => [w, c.lambda_w[i]]).filter(p => p[1] != null) : [];
            const series = [{ points: pts, color: meta.color, width: 2, fill: true, label: 'α²F(ω)' }];

            const dos = d[wf].curves?.phdos;
            let dosNote = '';
            if (dos && dos.n_points) {
                const wConv = unitToUnit(dos.unit, c.unit);
                const dMax = Math.max.apply(null, dos.dos) || 1;
                const aMax = Math.max.apply(null, c.a2f) || 1;
                series.push({
                    points: dos.omega.map((w, i) => [w * wConv, dos.dos[i] / dMax * aMax]),
                    color: '#64748b', width: 1.5, dash: '5 4', label: 'F(ω) normalisée',
                });
                dosNote = ' · F(ω) mise à l\'échelle de α²F';
            }
            if (lamPts.length) {
                series.push({ points: lamPts, color: '#7c3aed', width: 2, dash: '2 3',
                              axis: 'y2', label: 'λ(ω)' });
            }

            const svg = SupraPlots.chart({
                series,
                x: { label: `ω (${c.unit})` },
                y: { label: 'α²F(ω)', color: meta.color },
                y2: lamPts.length ? { label: 'λ(ω)', color: '#7c3aed' } : null,
                title: `α²F(ω) — ${meta.short}`,
            });
            const lamTot = d[wf].scalars?.lambda;
            cards.push(`
            <div class="res-plot-card">
                <h5>${meta.short} — α²F(ω) et couplage cumulatif λ(ω)</h5>
                <p class="res-plot-meta">${escapeHtml(c.source)} · ${c.n_points} pts${escapeHtml(dosNote)}${
                    lamTot != null ? ` · λ total = ${lamTot.toFixed(3)}` : ''}</p>
                ${svg}
                <div class="res-legend">
                    <span style="color:${meta.color}">α²F(ω)</span>
                    ${dos && dos.n_points ? '<span style="color:#64748b">F(ω) normalisée</span>' : ''}
                    ${lamPts.length ? '<span style="color:#7c3aed">λ(ω) — axe de droite</span>' : ''}
                </div>
            </div>`);
        });
        a2fBox.innerHTML = cards.length ? cards.join('')
            : alertBox('info', 'Aucun fichier α²F exploitable. Voie classique : <code>matdyn.x</code> '
                + 'avec <code>la2F=.true.</code> écrit <code>a2F.dat</code>. Voie EPW : <code>epw.x</code> '
                + 'écrit <code>&lt;prefix&gt;.a2f</code>.');

        if (cmpBox) {
            const both = ['classic', 'epw']
                .map(wf => ({ wf, c: d[wf].curves?.a2f }))
                .filter(o => o.c && o.c.n_points && o.c.omega_K?.length);
            if (both.length === 2) {
                cmpBox.innerHTML = `
                <div class="res-plot-card">
                    <h5>Comparaison α²F(ω) — Classique vs EPW</h5>
                    <p class="res-plot-meta">Axes ramenés en meV pour rendre les deux voies comparables.</p>
                    ${SupraPlots.chart({
                        series: both.map(o => ({
                            points: o.c.omega_K.map((wk, i) => [wk / K_PER_MEV, o.c.a2f[i]]),
                            color: ROUTE_META[o.wf].color, width: 2,
                            dash: o.wf === 'epw' ? '6 4' : null,
                        })),
                        x: { label: 'ω (meV)' }, y: { label: 'α²F(ω)' },
                        title: 'α²F comparé',
                    })}
                    <div class="res-legend">
                        <span style="color:${ROUTE_META.classic.color}">Classique</span>
                        <span style="color:${ROUTE_META.epw.color}">EPW</span>
                    </div>
                </div>`;
            } else {
                cmpBox.innerHTML = '';
            }
        }

        // λ(σ) — élargissements gaussiens de lambda.x
        if (brBox) {
            const rows = d.classic.curves?.broadenings?.rows || [];
            const pts = rows
                .filter(r => r.sigma_Ry != null && r.lambda != null)
                .map(r => [r.sigma_Ry, r.lambda]);
            if (pts.length >= 2) {
                const nef = rows.filter(r => r.dos_ef != null)
                    .map(r => [r.sigma_Ry, r.dos_ef]);
                const series = [{ points: pts, color: ROUTE_META.classic.color, width: 2.5,
                    fill: true, label: 'λ(σ)' }];
                if (nef.length >= 2) {
                    series.push({ points: nef, color: '#7c3aed', width: 1.8, dash: '4 3',
                        axis: 'y2', label: 'N(E_F)' });
                }
                brBox.innerHTML = `
                <div class="res-plot-card">
                    <h5>λ et N(E_F) vs élargissement σ — lambda.x</h5>
                    <p class="res-plot-meta">${escapeHtml(d.classic.curves.broadenings.source || '')}
                        · ${pts.length} élargissements</p>
                    ${SupraPlots.chart({
                        series,
                        x: { label: 'σ (Ry)' },
                        y: { label: 'λ', color: ROUTE_META.classic.color },
                        y2: nef.length >= 2 ? { label: 'N(E_F)', color: '#7c3aed' } : null,
                        title: 'λ(σ)',
                    })}
                    <div class="res-legend">
                        <span style="color:${ROUTE_META.classic.color}">λ(σ)</span>
                        ${nef.length >= 2 ? '<span style="color:#7c3aed">N(E_F) — axe droit</span>' : ''}
                    </div>
                </div>`;
            } else {
                brBox.innerHTML = '';
            }
        }

        if (dispBox) {
            const disp = d.classic.curves?.dispersion;
            if (disp && disp.n_modes) {
                const weights = modeWeights(d.classic.curves?.elph, disp.n_modes);
                dispBox.innerHTML = `
                <div class="res-plot-card">
                    <h5>Dispersion des phonons ω(q)${weights ? ' — épaisseur ∝ λ_qν' : ''}</h5>
                    <p class="res-plot-meta">${escapeHtml(disp.source)} · ${disp.n_modes} branches
                        · ω_min = ${fmtNum(disp.omega_min, 2)} ${escapeHtml(disp.unit || '')}</p>
                    ${SupraPlots.dispersion({
                        q: disp.q, bands: disp.bands, weights,
                        x: { label: 'chemin q' }, y: { label: `ω (${disp.unit})` },
                        color: ROUTE_META.classic.color, height: 340,
                        title: 'dispersion de phonons',
                    })}
                </div>`;
            } else {
                dispBox.innerHTML = '';
            }
        }

        if (modeBox) {
            const elph = d.classic.curves?.elph;
            const pts = (elph?.modes || [])
                .filter(m => m.omega_cmm1 != null && m.lambda != null)
                .map(m => ({ x: m.omega_cmm1, y: Math.abs(m.lambda), w: Math.abs(m.gamma || 0) }));
            modeBox.innerHTML = pts.length ? `
            <div class="res-plot-card">
                <h5>Couplage mode par mode λ_qν — taille ∝ γ_qν</h5>
                <p class="res-plot-meta">${elph.n_qpoints} point(s) q · ${pts.length} modes · ${escapeHtml(elph.source)}</p>
                ${SupraPlots.scatter({
                    points: pts, x: { label: 'ω_qν (cm⁻¹)' }, y: { label: 'λ_qν', color: ROUTE_META.classic.color },
                    color: ROUTE_META.classic.accent, stroke: ROUTE_META.classic.color, height: 300,
                    title: 'couplage par mode',
                })}
            </div>` : '';
        }

        // Spectre γ(ω) agrégé
        if (gamBox) {
            const modes = d.classic.curves?.elph?.modes || [];
            const pts = modes
                .filter(m => m.omega_cmm1 != null && m.gamma != null && m.gamma > 0)
                .map(m => [m.omega_cmm1, m.gamma])
                .sort((a, b) => a[0] - b[0]);
            if (pts.length >= 3) {
                const gUnit = (modes.find(m => m.gamma_unit) || {}).gamma_unit || 'GHz';
                gamBox.innerHTML = `
                <div class="res-plot-card">
                    <h5>Largeurs de raie γ_qν(ω) — elph</h5>
                    <p class="res-plot-meta">${pts.length} modes · ${escapeHtml(gUnit)} · ${escapeHtml(d.classic.curves.elph.source || '')}</p>
                    ${SupraPlots.chart({
                        series: [{ points: pts, color: '#f59e0b', width: 1.2 }],
                        x: { label: 'ω (cm⁻¹)' }, y: { label: `γ (${gUnit})`, color: '#f59e0b' },
                        title: 'γ(ω)',
                    })}
                </div>`;
            } else {
                gamBox.innerHTML = '';
            }
        }

        if (gapBox) {
            const g = d.epw.curves?.gap_vs_T;
            if (g && g.pairs?.length > 1) {
                const tc = d.epw.scalars?.tc_interp_K || d.epw.scalars?.tc_reported_K;
                gapBox.innerHTML = `
                <div class="res-plot-card">
                    <h5>Gap supraconducteur Δ(T) — EPW</h5>
                    <p class="res-plot-meta">${escapeHtml(g.source)} · ${g.n_points} températures</p>
                    ${SupraPlots.chart({
                        series: [{ points: g.pairs.map(p => [p[0], p[1]]),
                                   color: ROUTE_META.epw.color, width: 2.5, fill: true }],
                        markers: tc ? [{ x: tc, label: `Tᶜ = ${tc.toFixed(2)} K` }] : [],
                        x: { label: 'T (K)' }, y: { label: 'Δ (meV)', color: ROUTE_META.epw.color },
                        title: 'gap en température',
                    })}
                </div>`;
            } else {
                gapBox.innerHTML = '';
            }
        }
    }

    /** Facteur de conversion entre deux unités de fréquence. */
    function unitToUnit(from, to) {
        const K = { 'cm-1': K_PER_CM1, 'meV': K_PER_MEV, 'THz': 47.99243073366221,
                    'Ry': 157887.5124, 'K': 1 };
        const a = K[from] || K_PER_CM1;
        const b = K[to] || K_PER_CM1;
        return a / b;
    }

    /** Poids relatif de chaque branche : λ moyen du mode sur la grille q. */
    function modeWeights(elph, nModes) {
        if (!elph || !elph.modes?.length) return null;
        const sum = new Array(nModes).fill(0);
        const cnt = new Array(nModes).fill(0);
        elph.modes.forEach(m => {
            const i = (m.mode || 0) - 1;
            if (i < 0 || i >= nModes || m.lambda == null) return;
            sum[i] += Math.abs(m.lambda);
            cnt[i] += 1;
        });
        const mean = sum.map((s, i) => cnt[i] ? s / cnt[i] : 0);
        const max = Math.max.apply(null, mean);
        if (!(max > 0)) return null;
        return mean.map(v => v / max);
    }

    function pickFermiVizData() {
        const d = RES.data;
        if (!d) return null;
        for (const wf of ['classic', 'epw']) {
            const viz = d[wf]?.curves?.fermi_viz;
            if (viz?.ready && viz.bxsf) return { wf, viz };
        }
        for (const wf of ['classic', 'epw']) {
            const viz = d[wf]?.curves?.fermi_viz;
            if (viz) return { wf, viz };
        }
        return null;
    }

    function updateFermiSurfaceButtonState() {
        const btn = $('#btnFermiSurface3D');
        if (!btn) return;
        btn.disabled = !APP.material || !APP.apiOnline;
        const pick = pickFermiVizData();
        const nscfOk = APP.workflow && stepState('nscf', APP.workflow) === 'done';
        btn.title = pick?.viz?.ready
            ? `Ouvrir ${pick.viz.bxsf} dans XCrySDen`
            : (nscfOk
                ? 'Pas encore de .bxsf — clic : lance fs.x puis XCrySDen (NSCF terminé)'
                : 'Disponible après NSCF (JOB DONE) : fs.x → .bxsf → XCrySDen');
        btn.classList.toggle('res-fermi-needs-export', !pick?.viz?.ready && !!APP.material && !!APP.apiOnline);
    }

    async function launchFermiSurfaceViz(pick) {
        const bxsf = pick?.viz?.bxsf || '';
        const r = await SupraAPI.vizFermiSurface({
            material: APP.material,
            bxsf_path: bxsf,
        });
        if (!r?.ok) {
            notifyUser(r?.error || 'Surface de Fermi indisponible.', 'error');
            return r;
        }
        if (r.launched) {
            notifyUser('XCrySDen ouvert sur la machine qui exécute l’API.', 'success');
        } else {
            try {
                await navigator.clipboard.writeText(r.command || '');
                notifyUser(
                    (r.xcrysden ? 'XCrySDen n’a pas pu démarrer — ' : 'XCrySDen absent sur le serveur — ')
                    + 'commande copiée dans le presse-papier. Tu peux aussi télécharger le .bxsf.',
                    'warning');
            } catch (_) {
                notifyUser(`Commande : ${r.command}`, 'info');
            }
        }
        return r;
    }

    async function openFermiSurfaceViewer() {
        if (!APP.material) {
            notifyUser('Valide d’abord un matériau (étape 1).', 'warning');
            return;
        }
        if (!APP.apiOnline) {
            notifyUser('API hors ligne — lance <code>./DEMARRER.sh</code>.', 'error');
            return;
        }
        switchMainView('resultats');
        switchResModule('aniso');
        scrollToView('#resFermiXcrysden', { block: 'center' });
        if (!RES.data) await exploreResults();
        let pick = pickFermiVizData();
        if (!pick?.viz?.ready) {
            const exp = await exportFermiBxsfIfNeeded({ reason: 'bouton_3d' });
            if (exp?.ok && !exp.skipped) {
                await exploreResults();
                pick = pickFermiVizData();
            }
        }
        if (pick?.viz?.ready) {
            await launchFermiSurfaceViz(pick);
        } else {
            notifyUser(
                'Visualisation 3D indisponible : il faut un <code>.bxsf</code> (lancer <code>fs.x</code> '
                + 'après SCF + NSCF, grille k régulière). Voir le panneau ci-dessous ou le bouton '
                + '<strong>Lancer fs.x</strong>.',
                'info');
        }
        renderAniso();
    }

    function renderFermiViz(box, d) {
        if (!box) return;
        const cands = ['classic', 'epw']
            .map(wf => ({ wf, viz: d[wf]?.curves?.fermi_viz }))
            .filter(x => x.viz);
        const withBxsf = cands.find(x => x.viz.ready && x.viz.bxsf);
        const viz = (withBxsf || cands[0])?.viz || {};
        const wf = (withBxsf || cands[0])?.wf;
        const cmd = viz.command || `xcrysden --bxsf ${(d.material || APP.material || 'prefix')}.bxsf`;
        const prefix = d.material || APP.material || 'prefix';
        const fsIn = viz.fs_in || (
            `! Surface de Fermi → XCrySDen (standard QE)\n`
            + `! fs.x < ${prefix}.fs.in > ${prefix}.fs.out\n`
            + `&fermi\n  prefix = '${prefix}'\n  outdir = './'\n/\n`);
        const fsName = viz.fs_in_name || `${prefix}.fs.in`;
        const qeBin = String(APP._health?.qe_bin_dir || '').replace(/\/$/, '');
        const fsBinOk = APP._health?.qe?.found?.['fs.x'] === true;
        const fsProg = qeBin ? `${qeBin}/fs.x` : 'fs.x';
        const fsRunCmd = `${fsProg} < ${fsName} > ${prefix}.fs.out`;
        const fsBinHint = fsBinOk
            ? ''
            : `<p class="alert alert-warning" style="margin:8px 0;">`
                + `<code>fs.x</code> absent de <code>${escapeHtml(qeBin || 'QE_BIN_DIR')}</code> — `
                + `relance <code>./scripts/associer_binaires_qe.sh /chemin/vers/qe/bin</code> `
                + `(ou lien : <code>ln -s …/fs.x supra-QE/bin/fs.x</code>).</p>`;
        const nscfDone = ['classic', 'epw'].some(w => stepState('nscf', w) === 'done')
            || (APP.workflow && stepState('nscf', APP.workflow) === 'done');
        const canAutoFs = !viz.ready && nscfDone && fsBinOk !== false;
        let status;
        if (viz.ready && viz.bxsf) {
            status = `Fichier BXSF trouvé : <code>${escapeHtml(viz.bxsf)}</code>.
                Clique le bouton pour ouvrir XCrySDen (visualiseur standard Quantum ESPRESSO) :`;
        } else {
            status = `Pas encore de <code>.bxsf</code> — la 3D n'est <strong>pas</strong> dans le navigateur.
                Après SCF + NSCF (<code>JOB DONE</code>), lance <code>fs.x</code> puis XCrySDen.
                Ce n'est pas une étape de la chaîne automatique (ph.x / matdyn / epw). Input :`;
        }
        const frmsf = viz.frmsf
            ? `<p class="muted" style="margin:8px 0 0;">FermiSurfer (coloration Δ<sub>k</sub> sur la SF, optionnel) :
                <code>fermisurfer ${escapeHtml(viz.frmsf)}</code></p>`
            : '';
        const bxsfRel = viz.bxsf || '';
        box.innerHTML = `<div class="res-plot-card res-fermi-viz-card">
            <h5>Visualisation 3D — surface de Fermi (XCrySDen)</h5>
            <p class="res-plot-meta">${wf ? ROUTE_META[wf].short + ' · ' : ''}fs.x → .bxsf → xcrysden --bxsf</p>
            <div class="res-fermi-actions">
                <button type="button" class="btn btn-secondary" id="btnRunFsExport"
                    ${canAutoFs ? '' : 'disabled'}
                    title="${canAutoFs ? 'Lance fs.x via l\'API (après NSCF)' : 'NSCF terminé + fs.x requis'}">
                    ⚙️ Lancer fs.x (générer .bxsf)
                </button>
                <button type="button" class="btn btn-primary" id="btnOpenFermiXcrysden"
                    ${viz.ready ? '' : 'disabled'} title="Lance XCrySDen sur le PC serveur (API)">
                    🧊 Visualiser la surface de Fermi
                </button>
                <button type="button" class="btn btn-secondary" id="btnDownloadBxsf"
                    ${viz.ready ? '' : 'disabled'}>📥 Télécharger .bxsf</button>
                <button type="button" class="btn btn-secondary" id="btnCopyFermiCmd">📋 Copier la commande</button>
            </div>
            <p style="margin:10px 0 8px;">${status}</p>
            ${fsBinHint}
            ${viz.ready ? '' : `<p class="muted" style="margin:0 0 6px;">Depuis le dossier où se trouvent le <code>.save</code> NSCF et <code>${escapeHtml(fsName)}</code> :</p>
                <code class="res-cmd" id="resFsRunCmd">${escapeHtml(fsRunCmd)}</code>
                <button type="button" class="btn-mini" id="btnCopyFsRun">📋 Copier la commande fs.x</button>
                <pre class="res-cmd" style="white-space:pre-wrap;margin-top:10px;">${escapeHtml(fsIn)}</pre>
                <button type="button" class="btn-mini" id="btnDownloadFsIn">Télécharger ${escapeHtml(fsName)}</button>`}
            <p class="muted" style="margin:10px 0 6px;">XCrySDen (après export <code>.bxsf</code>) :</p>
            <code class="res-cmd" id="resFermiCmd">${escapeHtml(cmd)}</code>
            <p class="muted" style="margin:10px 0 0;">L'histogramme E−E<sub>F</sub> ci-dessous compte les états autour de E<sub>F</sub> ;
                ce n'est pas la géométrie 3D de la surface de Fermi.</p>
            ${frmsf}
           </div>`;
        const pick = withBxsf || cands[0] || { wf, viz };
        $('#btnRunFsExport')?.addEventListener('click', async () => {
            const exp = await exportFermiBxsfIfNeeded({ force: true, reason: 'panneau_aniso' });
            if (exp?.ok && !exp.skipped) {
                await exploreResults();
                renderAniso();
            }
        });
        $('#btnOpenFermiXcrysden')?.addEventListener('click', async () => {
            let p = pickFermiVizData() || pick;
            if (!p?.viz?.ready) {
                const exp = await exportFermiBxsfIfNeeded({ reason: 'visualiser' });
                if (exp?.ok && !exp.skipped) {
                    await exploreResults();
                    p = pickFermiVizData() || p;
                    renderAniso();
                }
            }
            if (p?.viz?.ready) await launchFermiSurfaceViz(p);
            else notifyUser('Toujours pas de <code>.bxsf</code> — vérifie <code>fs.out</code> et la grille k NSCF.', 'warning');
        });
        $('#btnCopyFermiCmd')?.addEventListener('click', async () => {
            const c = $('#resFermiCmd')?.textContent || cmd;
            try {
                await navigator.clipboard.writeText(c);
                notifyUser('Commande XCrySDen copiée.', 'success');
            } catch (_) {
                notifyUser(c, 'info');
            }
        });
        $('#btnCopyFsRun')?.addEventListener('click', async () => {
            const c = $('#resFsRunCmd')?.textContent || fsRunCmd;
            try {
                await navigator.clipboard.writeText(c);
                notifyUser('Commande fs.x copiée.', 'success');
            } catch (_) {
                notifyUser(c, 'info');
            }
        });
        $('#btnDownloadBxsf')?.addEventListener('click', async () => {
            if (!bxsfRel) return;
            const r = await SupraAPI.readFile(bxsfRel);
            if (r?.ok) downloadText(bxsfRel.split('/').pop() || `${prefix}.bxsf`, r.content);
            else notifyUser('Lecture du .bxsf impossible.', 'error');
        });
        $('#btnDownloadFsIn')?.addEventListener('click', () => {
            if (fsIn) downloadText(fsName, fsIn);
        });
        updateFermiSurfaceButtonState();
    }

    function renderFermiHist(box, d) {
        if (!box) return;
        const cands = ['classic', 'epw']
            .map(wf => ({ wf, fs: d[wf]?.curves?.fermi }))
            .filter(x => x.fs?.ready && (x.fs.hist_counts || []).length);
        if (!cands.length) {
            box.innerHTML = alertBox('info',
                'Pas encore d\'analyse de surface de Fermi : il faut un <code>scf.out</code> '
                + 'ou <code>nscf.out</code> avec les bandes imprimées (pw.x). '
                + 'Sans SF, pas de paires de Cooper.');
            return;
        }
        cands.sort((a, b) => (b.fs.n_k_parsed || 0) - (a.fs.n_k_parsed || 0));
        const { wf, fs } = cands[0];
        const s = d[wf]?.scalars || {};
        const markers = [{ x: 0, label: 'E_F' }];
        if (s.omega_log_K != null) {
            const w = s.omega_log_K / K_PER_EV;
            markers.push({ x: w, label: '+ħω_log', color: '#0891b2' });
            markers.push({ x: -w, label: '−ħω_log', color: '#0891b2' });
        }
        if (s.fsthick_eV != null && s.fsthick_eV > 0 && s.fsthick_eV <= 1.05) {
            markers.push({ x: s.fsthick_eV, label: 'fsthick', color: '#be185d' });
            markers.push({ x: -s.fsthick_eV, label: '', color: '#be185d' });
        }
        const frac = fs.fs_fraction != null ? `${(100 * fs.fs_fraction).toFixed(1)} %` : '—';
        box.innerHTML = `<div class="res-plot-card">
            <h5>États électroniques autour de E<sub>F</sub> — surface de Fermi</h5>
            <p class="res-plot-meta">${escapeHtml(fs.source || '')} · ${ROUTE_META[wf].short}
                · ${fs.n_k_on_fs}/${fs.n_k_parsed} k sur la SF (${frac} de la zone)
                · ${fs.n_bands_near_ef || 0} bande(s) ±${Number(fs.window_eV).toFixed(2)} eV</p>
            ${SupraPlots.bars({
                centres: fs.hist_e_ef, counts: fs.hist_counts,
                markers,
                x: { label: 'E − E_F (eV)' }, y: { label: 'nombre d\'états' },
                color: ROUTE_META[wf].accent, height: 280,
                title: 'histogramme E−E_F',
            })}
           </div>`;
    }

    /* ── Module 3 : anisotropie et surface de Fermi ───────────────────── */
    function renderAniso() {
        const d = RES.data;
        const fermiBox = $('#resPlotFermi');
        const vizBox = $('#resFermiXcrysden');
        const histBox = $('#resPlotGapHist');
        const sumBox = $('#resAnisoSummary');
        const pairsBox = $('#resPlotLambdaPairs');
        const decayBox = $('#resPlotDecay');
        const specBox = $('#resPlotSpecfun');
        const pbndBox = $('#resPlotPband');
        if (!histBox && !fermiBox && !vizBox) return;
        if (!d) {
            if (histBox) histBox.innerHTML = resNoData('Aucune donnée d\'anisotropie.');
            [sumBox, pairsBox, decayBox, specBox, pbndBox, fermiBox, vizBox].forEach(b => { if (b) b.innerHTML = ''; });
            return;
        }
        renderFermiViz(vizBox, d);
        renderFermiHist(fermiBox, d);

        if (histBox) {
        const h = d.epw?.curves?.gap_distribution;
        histBox.innerHTML = (h && h.n_values)
            ? `<div class="res-plot-card">
                <h5>Distribution de Δ_k sur la surface de Fermi</h5>
                <p class="res-plot-meta">${escapeHtml(h.source)} · ${h.n_values} valeurs · ${
                    h.n_files > 1 ? `${h.n_files} fichiers de gap détectés · ` : ''}${
                    h.n_sheets} groupe(s) de gap</p>
                ${SupraPlots.bars({
                    centres: h.bins, counts: h.counts,
                    markers: [{ x: h.gap_mean, label: `⟨Δ⟩ = ${h.gap_mean.toFixed(3)} meV` }],
                    x: { label: 'Δ (meV)' }, y: { label: 'nombre d\'états' },
                    color: ROUTE_META.epw.accent, height: 300,
                    title: 'histogramme du gap',
                })}
               </div>`
            : alertBox('info', 'Pas de fichier de gap anisotrope. Il faut <code>epw.x</code> avec '
                + '<code>laniso=.true.</code> : les fichiers <code>&lt;prefix&gt;.imag_aniso_gap0_*</code> '
                + 'contiennent Δ_k sur la surface de Fermi.');
        }

        if (sumBox) {
            const s = d.epw?.scalars || {};
            const items = [
                ['Δ₀', fmtNum(s.gap_meV, 3), 'meV'],
                ['⟨Δ⟩', fmtNum(s.gap_mean_meV, 3), 'meV'],
                ['Étendue de Δ', fmtNum(s.gap_spread_meV, 3), 'meV'],
                ['2Δ₀ / k_B Tᶜ', fmtNum(s.bcs_ratio, 2), 'BCS : 3.53'],
                ['Z(0)', fmtNum(s.z_factor, 3), '1 + λ'],
                ['Tᶜ Éliashberg', fmtNum(s.tc_interp_K, 2), 'K'],
                ['Tᶜ (code)', fmtNum(s.tc_reported_K, 2), 'K'],
                ['μ_c', fmtNum(s.mu_star_reported, 3), ''],
            ].filter(it => it[1] != null);
            sumBox.innerHTML = items.length ? `
            <div class="tc-card epw">
                <h3>Régime de couplage — voie EPW ${s.is_anisotropic === true ? '(anisotrope)'
                    : s.is_anisotropic === false ? '(isotrope)' : ''}</h3>
                <div class="tc-grid">${items.map(([k, v, u]) => `
                    <div class="tc-item"><div class="tc-label">${escapeHtml(k)}</div>
                        <div class="tc-value">${v}${u ? `<span class="tc-unit">${escapeHtml(u)}</span>` : ''}</div></div>`).join('')}
                </div>
            </div>` : '';
        }

        if (pairsBox) {
            const lp = d.epw?.curves?.lambda_pairs;
            const pts = (lp?.points || [])
                .filter(p => p.omega != null && p.lambda != null)
                .map(p => ({ x: p.omega, y: Math.abs(p.lambda), w: Math.abs(p.lambda) }));
            pairsBox.innerHTML = pts.length ? `
            <div class="res-plot-card">
                <h5>λ(q,ν) — fichier lambda_pairs EPW</h5>
                <p class="res-plot-meta">${escapeHtml(lp.source || '')} · ${pts.length} points</p>
                ${SupraPlots.scatter({
                    points: pts,
                    x: { label: 'ω' }, y: { label: 'λ', color: ROUTE_META.epw.color },
                    color: ROUTE_META.epw.accent, stroke: ROUTE_META.epw.color, height: 300,
                    title: 'λ(q,ν)',
                })}
            </div>` : '';
        }

        if (decayBox) {
            const series = d.epw?.curves?.decay?.series || [];
            if (series.length) {
                const colors = ['#06b6d4', '#ec4899', '#8b5cf6', '#f59e0b', '#10b981'];
                decayBox.innerHTML = `
                <div class="res-plot-card">
                    <h5>Décroissance Wannier (qualité de l’interpolation)</h5>
                    <p class="res-plot-meta">${series.length} courbe(s) — une décroissance rapide = bonne localisation</p>
                    ${SupraPlots.chart({
                        series: series.map((s, i) => ({
                            points: s.x.map((x, j) => [x, s.y[j]]),
                            color: colors[i % colors.length], width: 2,
                            label: s.name,
                        })),
                        x: { label: 'distance (unité fichier)' },
                        y: { label: '|élément|' },
                        title: 'decay Wannier',
                    })}
                    <div class="res-legend">${series.map((s, i) =>
                        `<span style="color:${colors[i % colors.length]}">${escapeHtml(s.name)}</span>`).join('')}</div>
                </div>`;
            } else {
                decayBox.innerHTML = '';
            }
        }

        if (specBox) {
            const sf = d.epw?.curves?.specfun;
            specBox.innerHTML = (sf && sf.n_points) ? `
            <div class="res-plot-card">
                <h5>Self-énergie / fonction spectrale électronique</h5>
                <p class="res-plot-meta">${escapeHtml(sf.source)} · ${sf.n_points} pts</p>
                ${SupraPlots.chart({
                    series: [{ points: sf.x.map((x, i) => [x, sf.y[i]]), color: '#7c3aed', width: 1.8 }],
                    x: { label: 'énergie / fréquence' }, y: { label: 'Σ″ (unité du fichier)', color: '#7c3aed' },
                    title: 'self-énergie',
                })}
            </div>` : '';
        }

        if (pbndBox) {
            const pb = d.epw?.curves?.pbnd;
            pbndBox.innerHTML = (pb && pb.n_points) ? `
            <div class="res-plot-card">
                <h5>Bandes / grandeurs renormalisées (pbnd)</h5>
                <p class="res-plot-meta">${escapeHtml(pb.source)} · ${pb.n_points} pts</p>
                ${SupraPlots.chart({
                    series: [{ points: pb.x.map((x, i) => [x, pb.y[i]]), color: ROUTE_META.epw.color, width: 1.8 }],
                    x: { label: 'k / énergie' }, y: { label: 'valeur', color: ROUTE_META.epw.color },
                    title: 'pbnd',
                })}
            </div>` : '';
        }
    }

    /* ── Module 4 : inventaire et lecture brute ───────────────────────── */
    function renderInventory() {
        const box = $('#resFileInventory');
        if (!box) return;
        const d = RES.data;
        if (!d) {
            box.innerHTML = resNoData('Aucun inventaire.');
            $('#resFileViewer').innerHTML = '';
            return;
        }
        const groups = ['classic', 'epw'].map(wf => {
            const inv = d[wf].inventory;
            const meta = ROUTE_META[wf];
            if (!inv.length) {
                return `<div class="res-inventory-group"><h5>${meta.label}</h5>`
                     + alertBox('info', `Rien trouvé dans <code>${
                         (d[wf].dirs || []).map(escapeHtml).join('</code>, <code>') || '—'
                     }</code>.`)
                     + '</div>';
            }
            return `
            <div class="res-inventory-group" data-wf="${wf}">
                <h5>${meta.label} — ${inv.length} fichier(s)</h5>
                <div class="res-table-wrap">
                    <table class="res-table">
                        <thead><tr>
                            <th>Fichier</th><th>Rôle dans la chaîne</th>
                            <th>État</th><th>Taille</th><th>Modifié</th><th>Lecture</th>
                        </tr></thead>
                        <tbody>${inv.map(f => {
                            const st = f.job_done ? '<span class="res-badge-done">JOB DONE</span>'
                                : f.has_error ? '<span class="res-badge-err">erreur</span>'
                                : (f.parsed ? 'lu' : 'référencé');
                            const hay = `${f.name} ${f.label} ${f.path}`.toLowerCase();
                            return `
                            <tr class="res-file-row" data-res-file="${escapeHtml(f.path)}" data-filter="${escapeHtml(hay)}">
                                <td><code>${escapeHtml(f.name)}</code><span class="res-src">${escapeHtml(f.path)}</span></td>
                                <td style="text-align:left;">${escapeHtml(f.label)}</td>
                                <td>${st}</td>
                                <td class="res-num">${kb(f.size)}</td>
                                <td class="res-num">${escapeHtml(stamp(f.mtime))}</td>
                                <td><button type="button" class="btn-mini" data-res-file="${escapeHtml(f.path)}">Voir</button></td>
                            </tr>`;
                        }).join('')}</tbody>
                    </table>
                </div>
            </div>`;
        });
        box.innerHTML = `
            <input type="search" class="res-file-filter" id="fldResFileFilter"
                   placeholder="Filtrer les fichiers (nom, rôle, chemin)…"
                   aria-label="Filtrer les fichiers résultats">
            ${groups.join('')}`;
        $('#fldResFileFilter')?.addEventListener('input', () => {
            const q = ($('#fldResFileFilter').value || '').trim().toLowerCase();
            $$('#resFileInventory .res-file-row').forEach(tr => {
                const hay = tr.dataset.filter || '';
                tr.style.display = !q || hay.includes(q) ? '' : 'none';
            });
        });
    }

    async function showRawFile(path) {
        const box = $('#resFileViewer');
        if (!box) return;
        box.innerHTML = alertBox('info', `Lecture de <code>${escapeHtml(path)}</code>…`);
        const r = await SupraAPI.readFile(path, { max_bytes: 400000 });
        if (!r || !r.ok) {
            box.innerHTML = alertBox('error', `Lecture impossible : ${escapeHtml(r?.error || 'erreur')}`);
            return;
        }
        RES.openFile = path;
        box.innerHTML = `
        <div class="res-plot-card">
            <h5>📄 ${escapeHtml(path)}</h5>
            <p class="res-plot-meta">${kb(r.size)}${r.truncated ? ' · aperçu tronqué (début + fin)' : ''}</p>
            <div class="res-file-view">${escapeHtml(r.content)}</div>
        </div>`;
        box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    /* ── Exports : CSV, LaTeX, rapport texte ──────────────────────────── */
    function downloadText(filename, text, mime = 'text/plain;charset=utf-8') {
        const blob = new Blob([text], { type: mime });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    }

    function resExportGuard() {
        if (RES.data) return true;
        setResStatus('Lance d\'abord l\'exploration : il n\'y a rien à exporter.', 'warn');
        return false;
    }

    function resExportCsv() {
        if (!resExportGuard()) return;
        const d = RES.data;
        // Mêmes arrondis qu'à l'écran : le CSV doit être relisible tel quel.
        const q = (v, dig = 3) => (v == null ? '' : Number(v).toFixed(dig));
        const rows = [
            ['# Supra-QE — synthese des resultats'],
            ['# materiau', d.material],
            ['# date', new Date().toISOString()],
            [],
            ['grandeur', 'unite', 'classique', 'epw', 'ecart_%', 'source_classique', 'source_epw'],
            ...d.synthesis.rows.map(r => [r.label, r.unit, q(r.classic, r.digits), q(r.epw, r.digits),
                                          r.delta_pct == null ? '' : r.delta_pct.toFixed(2),
                                          r.source_classic || '', r.source_epw || '']),
            [],
            ['mu_star', 'tc_mcmillan_classique_K', 'tc_allen_dynes_classique_K',
             'tc_mcmillan_epw_K', 'tc_allen_dynes_epw_K', 'tc_eliashberg_epw_K'],
            ...d.synthesis.tc_rows.map(r => [r.mu_star.toFixed(2), q(r.classic_mcmillan_K, 2),
                                             q(r.classic_allen_dynes_K, 2), q(r.epw_mcmillan_K, 2),
                                             q(r.epw_allen_dynes_K, 2),
                                             q(d.epw?.scalars?.tc_interp_K, 2)]),
        ];
        const csv = rows.map(r => r.map(c => {
            const s = String(c ?? '');
            return /[",;\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
        }).join(';')).join('\n');
        downloadText(`${d.material}_supra_synthese.csv`, csv, 'text/csv;charset=utf-8');
        setResStatus('CSV exporté.');
    }

    function resExportLatex() {
        if (!resExportGuard()) return;
        const d = RES.data;
        const f = (v, n) => (v == null ? '--' : Number(v).toFixed(n));
        // Un « _ » non échappé casse la compilation : texte échappé, clé assainie.
        const matTex = d.material.replace(/([_&%#$])/g, '\\$1');
        const matKey = d.material.replace(/[^A-Za-z0-9]+/g, '-');
        const lines = [
            '% Supra-QE — table de synthese (a coller dans un document LaTeX)',
            '\\begin{table}[htbp]',
            '  \\centering',
            `  \\caption{Grandeurs supraconductrices de ${matTex} : voie classique (ph.x + $\\lambda$) et voie EPW.}`,
            `  \\label{tab:supra-${matKey}}`,
            '  \\begin{tabular}{lccc}',
            '    \\hline',
            '    Grandeur & Unite & Classique & EPW \\\\',
            '    \\hline',
            ...d.synthesis.rows.map(r =>
                `    ${latexLabel(r.key, r.label)} & ${latexText(r.unit) || '--'} & ${f(r.classic, r.digits)} & ${f(r.epw, r.digits)} \\\\`),
            '    \\hline',
            '  \\end{tabular}',
            '\\end{table}',
            '',
            '\\begin{table}[htbp]',
            '  \\centering',
            `  \\caption{$T_c$ (K) de ${matTex} en fonction de $\\mu^*$ (Allen-Dynes entre parentheses : McMillan).}`,
            '  \\begin{tabular}{ccc}',
            '    \\hline',
            '    $\\mu^*$ & Classique & EPW \\\\',
            '    \\hline',
            ...d.synthesis.tc_rows.map(r =>
                `    ${r.mu_star.toFixed(2)} & ${f(r.classic_allen_dynes_K, 2)} (${f(r.classic_mcmillan_K, 2)})`
                + ` & ${f(r.epw_allen_dynes_K, 2)} (${f(r.epw_mcmillan_K, 2)}) \\\\`),
            '    \\hline',
            '  \\end{tabular}',
            '\\end{table}',
        ];
        downloadText(`${d.material}_supra_table.tex`, lines.join('\n'));
        setResStatus('Table LaTeX exportée.');
    }

    /** Échappe les caractères spéciaux LaTeX dans un texte libre (unité, etc.). */
    function latexText(s) {
        if (s == null || s === '') return '';
        return String(s).replace(/([_&%#$])/g, '\\$1');
    }

    /** Libellés en notation LaTeX pour les grandeurs connues. */
    function latexLabel(key, fallback) {
        const map = {
            lambda: '$\\lambda$', omega_log_K: '$\\omega_{\\ln}$', omega_log_meV: '$\\omega_{\\ln}$',
            omega_2_K: '$\\langle\\omega^2\\rangle^{1/2}$',
            omega_ratio: '$\\langle\\omega^2\\rangle^{1/2}/\\omega_{\\ln}$',
            dos_ef: '$N(E_F)$', ef_eV: '$E_F$', gap_meV: '$\\Delta_0$',
            bcs_ratio: '$2\\Delta_0/k_BT_c$', z_factor: '$Z(0)$',
            tc_reported_K: '$T_c$ (code)', gamma_max: '$\\gamma_{q\\nu}^{max}$',
            lambda_qnu_max: '$\\lambda_{q\\nu}^{max}$',
        };
        return map[key] || latexText(fallback).replace(/[{}]/g, '');
    }

    function resExportReport() {
        if (!resExportGuard()) return;
        const d = RES.data;
        const f = (v, n) => (v == null ? '—' : Number(v).toFixed(n));
        const L = [];
        L.push('════════════════════════════════════════════════════════════');
        L.push(`  Supra-QE — rapport de synthèse : ${d.material}`);
        L.push(`  généré le ${new Date().toLocaleString()}`);
        L.push('════════════════════════════════════════════════════════════', '');
        L.push('MÉTHODOLOGIE');
        L.push('  Voie classique : pw.x SCF → pw.x NSCF dense → ph.x (elph) →');
        L.push('                   q2r.x → matdyn.x/lambda.x → α²F(ω), λ, ω_log.');
        L.push('  Voie EPW       : pw.x SCF → ph.x (dvscf) → pw.x NSCF coarse →');
        L.push('                   epw.x (Wannier + équations d\'Éliashberg).');
        L.push('  λ, ω_log et ⟨ω²⟩^½ sont recalculés par intégration de α²F(ω) :');
        L.push('      λ = 2∫α²F/ω dω,  ω_log = exp[(2/λ)∫α²F ln ω/ω dω],');
        L.push('      ⟨ω²⟩ = (2/λ)∫α²F ω dω.');
        L.push('  Tᶜ : McMillan (1968) et Allen-Dynes (1975) avec f₁ et f₂.');
        L.push('  Magnétisme (v1.4) : nspin / |M| relus depuis scf.out ; interprétation Tᶜ');
        L.push('  prudente si ferromagnétisme fort ou SOC — voir section journal.', '');

        ['classic', 'epw'].forEach(wf => {
            const r = d[wf];
            L.push('────────────────────────────────────────────────────────────');
            L.push(`  ${ROUTE_META[wf].label}`);
            L.push('────────────────────────────────────────────────────────────');
            if (!r.has_data) {
                L.push('  Aucun résultat exploitable.', '');
                return;
            }
            L.push(`  Répertoires : ${r.dirs.join(', ')}`);
            L.push(`  Fichiers exploités : ${r.inventory.length}`);
            const s = r.scalars;
            const put = (label, v, n, u) => {
                if (v == null) return;
                L.push(`    ${label.padEnd(26)} ${f(v, n)} ${u || ''}`.trimEnd());
            };
            L.push('  Grandeurs :');
            put('λ', s.lambda, 3);
            put('ω_log', s.omega_log_K, 1, 'K');
            put('ω_log', s.omega_log_meV, 2, 'meV');
            put('⟨ω²⟩^½', s.omega_2_K, 1, 'K');
            put('N(E_F)', s.dos_ef, 3, 'états/spin/Ry/maille');
            if (s.mag_mode_label) L.push(`    ${'Magnétisme'.padEnd(26)} ${s.mag_mode_label}`);
            put('|M| SCF', s.abs_mag_bohr, 4, 'μ_B/maille');
            put('M_total SCF', s.total_mag_bohr, 4, 'μ_B/maille');
            if (s.nspin != null) L.push(`    ${'nspin'.padEnd(26)} ${s.nspin}`);
            if (Array.isArray(s.starting_mag_list) && s.starting_mag_list.length) {
                L.push(`    ${'starting_mag'.padEnd(26)} ${s.starting_mag_list.join(', ')}`);
            }
            put('E_F', s.ef_eV, 4, 'eV');
            put('Δ₀', s.gap_meV, 3, 'meV');
            put('2Δ₀/k_B Tᶜ', s.bcs_ratio, 2);
            put('Z(0)', s.z_factor, 3);
            put('Tᶜ annoncée par le code', s.tc_reported_K, 2, 'K');
            L.push('  Tᶜ calculée :');
            L.push('    μ*      McMillan      Allen-Dynes');
            r.tc_table.forEach(t => {
                L.push(`    ${t.mu_star.toFixed(2)}    ${String(f(t.tc_mcmillan_K, 2)).padStart(8)} K`
                     + `    ${String(f(t.tc_allen_dynes_K, 2)).padStart(8)} K`);
            });
            if (r.notes.length) {
                L.push('  Remarques :');
                r.notes.forEach(n => L.push(`    - ${n}`));
            }
            L.push('  Provenance des valeurs :');
            Object.entries(r.provenance).forEach(([k, v]) => L.push(`    ${k.padEnd(18)} ${v}`));
            L.push('');
        });

        L.push('────────────────────────────────────────────────────────────');
        L.push('  Comparaison des deux voies');
        L.push('────────────────────────────────────────────────────────────');
        d.synthesis.rows.forEach(r => {
            L.push(`  ${r.label.padEnd(26)} classique ${String(f(r.classic, r.digits)).padStart(10)}`
                 + `   EPW ${String(f(r.epw, r.digits)).padStart(10)}   ${r.unit || ''}`);
        });
        L.push('');
        downloadText(`${d.material}_supra_rapport.txt`, L.join('\n'));
        setResStatus('Rapport exporté.');
    }

    /* ── Navigation entre modules ─────────────────────────────────────── */
    function switchResModule(name) {
        RES.module = name || 'journal';
        const journal = RES.module === 'journal';
        $('#zoneWfResultats')?.classList.toggle('res-journal-open', journal);
        $$('.res-tab').forEach(b => {
            const on = b.dataset.resModule === RES.module;
            b.classList.toggle('active', on);
            b.setAttribute('aria-selected', on ? 'true' : 'false');
        });
        $$('.res-module').forEach(p => {
            const on = journal || p.dataset.resPanel === RES.module;
            p.classList.toggle('active', on);
        });
    }

    function ficheCss() {
        return `body{font-family:system-ui,Segoe UI,sans-serif;color:#0f172a;margin:24px;line-height:1.5;max-width:1100px;}
h1{font-size:1.35em;margin:0 0 6px;} h3,h4,h5{margin:18px 0 8px;}
table{border-collapse:collapse;width:100%;font-size:0.9em;margin:0 0 16px;}
th,td{border:1px solid #cbd5e1;padding:6px 8px;text-align:right;}
th{background:#f1f5f9;} td:first-child,th:first-child{text-align:left;}
code,pre{font-family:ui-monospace,Menlo,monospace;}
.res-cmd{display:block;background:#0f172a;color:#e2e8f0;padding:8px 12px;border-radius:8px;overflow:auto;}
.muted{color:#64748b;} .res-interpret{background:#eef2ff;padding:10px 14px;border-radius:8px;margin:8px 0 14px;}
.res-kpi-strip{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin:0 0 18px;}
.res-kpi{border:1px solid #e2e8f0;border-radius:10px;padding:10px 12px;}
.fiche-bar{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 16px;}
.fiche-bar button{padding:8px 14px;border-radius:8px;border:1px solid #cbd5e1;background:#fff;cursor:pointer;font-weight:600;}
@media print{.fiche-bar,.no-print{display:none!important;} body{margin:12px;} a{color:inherit;text-decoration:none;}}
svg{max-width:100%;height:auto;}`;
    }

    function buildFicheHtml() {
        const d = RES.data;
        const mat = escapeHtml(d?.material || APP.material || 'matériau');
        const stamp = new Date().toLocaleString();
        const grab = (id) => ($(id)?.innerHTML || '');
        const plots = ['resPlotA2F', 'resPlotA2FCompare', 'resPlotBroadenings', 'resPlotDispersion',
            'resPlotGapT', 'resFermiXcrysden', 'resPlotFermi', 'resPlotGapHist']
            .map(id => grab('#' + id)).filter(html => html && !html.includes('alert-info')).join('\n');
        return `<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8">
<title>Fiche résultats — ${mat} — Supra-QE</title>
<style>${ficheCss()}</style></head><body>
<div class="fiche-bar no-print">
  <button type="button" onclick="window.print()">Imprimer / Enregistrer en PDF</button>
  <span class="muted">Fichier → Imprimer → Enregistrer au format PDF</span>
</div>
<h1>Fiche technique — ${mat}</h1>
<p class="muted">${escapeHtml(stamp)} · Supra-QE · voies Classique et EPW</p>
${grab('#resIdentityBar')}
${grab('#resJournal')}
<h3>Indicateurs</h3>
${grab('#resKpiStrip')}
${grab('#resSynthesis')}
<h3>Spectres et surface de Fermi</h3>
${plots}
</body></html>`;
    }

    function openFiche(asPdf) {
        if (!resExportGuard()) return;
        const w = window.open('', '_blank');
        if (!w) {
            notifyUser('Autorise les fenêtres popup pour ouvrir la fiche HTML / PDF.');
            return;
        }
        w.document.open();
        w.document.write(buildFicheHtml());
        w.document.close();
        if (asPdf) {
            const run = () => { try { w.focus(); w.print(); } catch (e) { /* */ } };
            if (w.document.readyState === 'complete') setTimeout(run, 200);
            else w.addEventListener('load', () => setTimeout(run, 200));
        }
        setResStatus(asPdf
            ? 'Fiche PDF : choisis « Enregistrer au format PDF » dans la boîte d\'impression.'
            : 'Fiche HTML ouverte dans un nouvel onglet.');
    }

    function bindResultsExplorer() {
        RES.routeView = loadResultsRouteView();
        syncResultsRouteViewUi();
        $('#btnResRouteCompare')?.addEventListener('click', () => setResultsRouteView('compare'));
        $('#btnResRouteActive')?.addEventListener('click', () => setResultsRouteView('active'));
        $('#btnExploreResults')?.addEventListener('click', exploreResults);
        $('#btnFermiSurface3D')?.addEventListener('click', () => openFermiSurfaceViewer());
        $('#btnExportCsv')?.addEventListener('click', resExportCsv);
        $('#btnExportLatex')?.addEventListener('click', resExportLatex);
        $('#btnExportReport')?.addEventListener('click', resExportReport);
        $('#btnJournalHtml')?.addEventListener('click', () => openFiche(false));
        $('#btnJournalPdf')?.addEventListener('click', () => openFiche(true));
        $$('.res-tab').forEach(b =>
            b.addEventListener('click', () => switchResModule(b.dataset.resModule)));
        $('#fld_res_mu_stars')?.addEventListener('change', () => {
            if (RES.data) exploreResults();
        });
        // Boutons « Voir » créés dynamiquement dans l'inventaire
        $('#resFileInventory')?.addEventListener('click', ev => {
            const row = ev.target.closest('[data-res-file]');
            if (!row) return;
            $$('#resFileInventory .res-file-row').forEach(tr =>
                tr.classList.toggle('is-open', tr === row || tr.contains(ev.target)));
            showRawFile(row.dataset.resFile);
        });
        renderResultModules();
    }

    /* ====================================================================
     *  Wiring final
     * ==================================================================== */
    async function applyPaths() {
        if (!APP.material) {
            $('#pathsApplyStatus').innerHTML = alertBox('warning', 'Sélectionne un matériau d\'abord.');
            return;
        }
        if (!APP.workflow) {
            $('#pathsApplyStatus').innerHTML = alertBox('warning', 'Choisis un workflow d\'abord.');
            return;
        }
        APP.baseDir = getMaterialBaseDir();
        const fw = $('#fld_path_workflow');
        const fo = $('#fld_path_outputs');
        if (fw) { fw.value = txt('fld_path_workflow', `${APP.baseDir}/${APP.workflow}`).replace(/\/$/, ''); fw.dataset.touched = '1'; }
        if (fo) fo.dataset.touched = '1';
        saveStoredPaths({
            api_base: SupraAPI.getBaseURL(),
            inputs: getMaterialBaseDir(),
            workflow: txt('fld_path_workflow', ''),
            outputs: txt('fld_path_outputs', ''),
            pseudos: txt('fld_pseudo_dir', '../../../pseudos/'),
        });
        invalidateWorkflowFiles();
        const paths = getWorkflowPaths();
        $('#pathsApplyStatus').innerHTML = alertBox('success',
            `Chemins actifs : inputs <code>${paths.workDir}</code> · outputs <code>${paths.outputDir}</code>`);
        await renderCalcList();
        await refreshChainStatus();
    }

    function bindButtons() {
        $('#btnApiRefresh')      ?.addEventListener('click', pingAPI);
        $('#btnApiRetryBanner')  ?.addEventListener('click', () => {
            showToast('info', 'Vérification de l’API…', 2000);
            pingAPI();
        });
        $('#btnGenerateAll')     ?.addEventListener('click', generateAndSave);
        $('#btnRunWorkflow')     ?.addEventListener('click', runWorkflowActive);
        $('#btnCancelJob')       ?.addEventListener('click', cancelActiveJob);
        $('#btnApplyPaths')      ?.addEventListener('click', applyPaths);
    }

    /* ====================================================================
     *  Thème clair / sombre
     * ==================================================================== */
    const THEME_LS_KEY = 'supraQE.theme';

    function resolveTheme(preferred) {
        if (preferred === 'light' || preferred === 'dark') return preferred;
        try {
            if (window.matchMedia('(prefers-color-scheme: dark)').matches) return 'dark';
        } catch { /* */ }
        return 'light';
    }

    function setTheme(next, { persist = true } = {}) {
        const theme = resolveTheme(next);
        document.documentElement.setAttribute('data-theme', theme);
        document.querySelectorAll('.theme-btn').forEach(b => {
            const on = b.dataset.theme === theme;
            b.classList.toggle('active', on);
            b.setAttribute('aria-pressed', on ? 'true' : 'false');
        });
        if (persist) {
            try { localStorage.setItem(THEME_LS_KEY, theme); } catch { /* mode privé */ }
        }
    }

    function bindTheme() {
        document.querySelectorAll('.theme-btn').forEach(b => {
            b.addEventListener('click', () => setTheme(b.dataset.theme));
        });
        let saved = null;
        try { saved = localStorage.getItem(THEME_LS_KEY); } catch { /* */ }
        const initial = document.documentElement.getAttribute('data-theme')
            || resolveTheme(saved);
        setTheme(initial, { persist: false });
    }

    /* ====================================================================
     *  Boot
     * ==================================================================== */
    function boot() {
        document.body?.setAttribute('data-supra-ui', 'calculs-resultats');
        if (typeof SupraInputs === 'undefined' || typeof SupraAPI === 'undefined') {
            const msg = "Scripts Supra-QE non chargés. Ouvre http://127.0.0.1:8765/interface/ (avec ./DEMARRER.sh), pas le fichier HTML directement.";
            console.error(msg);
            const st = $('#apiStatusText');
            if (st) st.innerHTML = `<span style="color:var(--error);">${msg}</span>`;
        }
        restorePathsFromStorage();
        bindTheme();
        bindTabs();
        bindUsageGuide();
        bindAuthorCard();
        bindCollapsibles();
        bindHelpTheoryDetails();
        bindCollapseToolbar();
        bindSearchMaterial();
        bindWorkflowPicker();
        bindBranchSubTabs();
        bindPseudoUpload();
        bindButtons();
        bindPathsEditor();
        bindGridInputs();
        bindParallel();
        bindResultsExplorer();
        updateKQVisual();
        // Ouverture sur le Guide ; Calculs / Résultats basculent directement.
        switchMainView('guide');
        updateNavToolbarVisibility();
        updateSessionProgress();
        pingAPI();
        startApiWatchdog();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

})();

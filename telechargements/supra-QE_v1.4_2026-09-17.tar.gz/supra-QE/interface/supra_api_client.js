/* ===========================================================================
 *  supra_api_client.js — Client HTTP léger pour l'API Supra-QE.
 *
 *  L'API tourne typiquement sur http://127.0.0.1:8765
 * ========================================================================= */

(function (global) {
    'use strict';

    const DEFAULT_BASE = (() => {
        // Si on a ouvert l'interface via l'API (même origine), on utilise window.location.origin
        if (typeof window !== 'undefined' && window.location && window.location.protocol === 'http:') {
            return window.location.origin;
        }
        return 'http://127.0.0.1:8765';
    })();

    let BASE = DEFAULT_BASE;
    const TOKEN_KEY = 'supraQE.apiToken';

    function setBaseURL(url) {
        BASE = String(url || DEFAULT_BASE).replace(/\/$/, '');
    }
    function getBaseURL() { return BASE; }

    function getApiToken() {
        try { return localStorage.getItem(TOKEN_KEY) || ''; } catch (_) { return ''; }
    }
    function setApiToken(tok) {
        try {
            if (tok) localStorage.setItem(TOKEN_KEY, String(tok));
            else localStorage.removeItem(TOKEN_KEY);
        } catch (_) { /* ignore */ }
    }

    async function _request(path, opts = {}) {
        const url = BASE + path;
        try {
            const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
            const tok = getApiToken();
            if (tok) headers['X-Supra-Token'] = tok;
            const r = await fetch(url, {
                method: opts.method || 'GET',
                headers,
                body: opts.body ? JSON.stringify(opts.body) : undefined,
                cache: 'no-store',
            });
            const text = await r.text();
            let data;
            try { data = JSON.parse(text); } catch { data = { raw: text }; }
            if (!r.ok) {
                return { ok: false, status: r.status, error: data.error || text, data };
            }
            return data;
        } catch (err) {
            return { ok: false, error: String(err) };
        }
    }

    const SupraAPI = {
        setBaseURL, getBaseURL, getApiToken, setApiToken,

        health: () => _request('/health'),

        // pseudos
        checkPseudos: (pseudos, pseudo_dir) =>
            _request('/api/pseudo/check', { method: 'POST', body: { pseudos, pseudo_dir } }),

        // grilles
        validateGrid: (k, q) =>
            _request('/api/grid/validate', { method: 'POST', body: { k, q } }),

        // fichiers
        saveFile: (path, content) =>
            _request('/api/file/save', { method: 'POST', body: { path, content } }),
        classifyScf: (path) =>
            _request('/api/scf/classify', { method: 'POST', body: { path } }),
        readFile: (path, { max_bytes, tail_lines } = {}) =>
            _request('/api/file/read', {
                method: 'POST',
                body: { path, max_bytes, tail_lines },
            }),
        /** État léger (existence, taille, JOB DONE) d'un ou plusieurs chemins. */
        statFiles: (paths) =>
            _request('/api/file/stat', {
                method: 'POST',
                body: { paths: Array.isArray(paths) ? paths : [paths] },
            }),
        /** Processus QE actifs ( .out ouvert ou pw.x/ph.x/… en cours ). */
        qeRunning: ({ outputs = [], programs = [] } = {}) =>
            _request('/api/qe/running', {
                method: 'POST',
                body: { outputs, programs },
            }),

        // calcul
        run: ({ program, input, output, nprocs = 1, nthreads = 1, workdir, append_output = false }) =>
            _request('/api/run', {
                method: 'POST',
                body: { program, input, output, nprocs, nthreads, workdir, append_output },
            }),
        /** Regroupe dyn + dvscf (pp.py EPW) dans outdir/save/ — cwd = outdir QE. */
        runEpwPp: ({ workdir, prefix }) =>
            _request('/api/run/epw_pp', {
                method: 'POST',
                body: { workdir, prefix },
            }),
        job: (job_id) => _request(`/api/job/${encodeURIComponent(job_id)}`),
        /** Annule un job QE en cours (SIGTERM / SIGKILL côté serveur). */
        cancelJob: (job_id) =>
            _request(`/api/job/${encodeURIComponent(job_id)}/cancel`, { method: 'POST' }),

        // résultats — méthode classique
        tc: ({ matdyn_out, mu_star, omega_log_override_K }) =>
            _request('/api/results/tc', {
                method: 'POST',
                body: { matdyn_out, mu_star, omega_log_override_K },
            }),
        alpha2F: (a2f_file) =>
            _request('/api/results/alpha2F', { method: 'POST', body: { a2f_file } }),

        // résultats — méthode EPW
        epw: ({ epw_out, mu_star }) =>
            _request('/api/results/epw', {
                method: 'POST',
                body:   { epw_out, mu_star },
            }),

        // comparaison α²F(ω) classique vs EPW
        compareA2F: (material) =>
            _request('/api/results/compare', { method: 'POST', body: { material } }),

        /**
         * Exploration complète de la chaîne : inventaire des fichiers des deux
         * voies, scalaires (λ, ω_log, ⟨ω²⟩^½, N(E_F), Δ₀…), courbes traçables
         * et tableau Tᶜ(μ*).
         */
        exploreResults: ({ material, mu_stars } = {}) =>
            _request('/api/results/explore', {
                method: 'POST',
                body: { material, mu_stars },
            }),

        /** Lance XCrySDen (--bxsf) sur la machine API ou renvoie commande + chemin. */
        vizFermiSurface: ({ material, bxsf_path } = {}) =>
            _request('/api/viz/fermi-surface', {
                method: 'POST',
                body: { material, bxsf_path },
            }),

        listRelaxed: () => _request('/api/relaxed/list'),

        // matériaux
        listMaterials:   () =>          _request('/api/materials/list'),
        searchMaterial:  (material) =>  _request('/api/materials/search', { method: 'POST', body: { material } }),
    };

    global.SupraAPI = SupraAPI;

})(typeof window !== 'undefined' ? window : globalThis);

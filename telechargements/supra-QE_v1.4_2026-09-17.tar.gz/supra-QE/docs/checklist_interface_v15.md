# Checklist interface v1.5 — évolutions sans cassure

Objectif : améliorer clarté et maintenabilité **sans changer le comportement par défaut**
ni l’API `/api/results/explore`.

## Règles de sécurité (régression)

- [ ] **Ctrl+F5** après mise à jour : vérifier `supra_app.js?v=…` dans le HTML.
- [ ] Mode par défaut **« Comparer les deux voies »** = comportement v1.4 (deux colonnes).
- [ ] Exports **CSV / LaTeX / rapport** : toujours les **deux voies** (données API inchangées).
- [ ] `./.venv/bin/pytest tests/test_results_explore.py tests/test_api_smoke.py -q` vert avant tag.

## UX Résultats (v1.5.0 — en place)

- [x] Segmented control **Comparer** / **Voie active seule** (préférence `localStorage` `supraQE.resultsRouteView`).
- [x] Colonne **EPW grisée** tant qu’il n’y a pas de `epw.out` (mode comparaison).
- [x] Bandeau synthèse rappelant SCF partagé vs vrai EPW.
- [ ] (Option) Masquer la courbe « compare » dans Spectres en mode voie active — non fait volontairement (moins de risque).

## Refactor front (reporté — risque de cassure)

- [ ] Découper `supra_app.js` en modules (`chain`, `results`, `forms`) **après** tests E2E.
- [ ] Wizard 3 questions au premier lancement — à prototyper à part.

## Tests manuels rapides (5 min)

1. Matériau validé, WF1 seul, **Comparer** : colonne EPW visible, **grisée**, alerte SCF partagé.
2. **Voie active seule** + WF1 : une seule colonne Classique, pas de colonne Écart.
3. Changer WF2 EPW dans Calculs + **Voie active** : colonnes EPW seules, KPI EPW visibles.
4. Export CSV : toujours classique **et** EPW si données présentes.
5. Journal / Spectres / Fichiers : inchangés (pas de régression visible).

## Documentation

- [x] Cette checklist.
- [ ] Lien depuis `README.md` (optionnel, une ligne).

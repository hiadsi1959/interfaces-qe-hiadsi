#!/usr/bin/env bash
# ==========================================================================
#  Associe les binaires QE (dont epw.x) au projet Supra-QE via supra-QE/bin/
#
#  L'utilisateur n'a pas à recompiler EPW à chaque fois : on crée des liens
#  symboliques depuis une installation QE déjà compilée (pw.x, ph.x, epw.x…).
#
#  Usage :
#    ./scripts/associer_binaires_qe.sh
#    ./scripts/associer_binaires_qe.sh /chemin/vers/q-e-qe-7.5/bin
#    QE_BIN_DIR=/opt/qe/bin ./scripts/associer_binaires_qe.sh
#
#  Mode autonome (copies réelles dans supra-QE/bin/, pour archive / autre PC) :
#    ./scripts/associer_binaires_qe.sh --copy
#    ./scripts/copier_binaires_qe.sh /chemin/vers/qe/bin
#
#  Par défaut : liens symboliques (léger, même machine). --copy : cp -L des
#  binaires (plus lourd ; l'autre PC doit avoir MPI/OpenBLAS compatibles).
# ==========================================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$HERE"
# shellcheck disable=SC1091
source "$HERE/scripts/supra_qe_bins.sh"

COPY_MODE=0
ARGS=()
for a in "$@"; do
  case "$a" in
    --copy|-c) COPY_MODE=1 ;;
    *) ARGS+=("$a") ;;
  esac
done

if [[ -f "$HERE/config.env" ]]; then
  # shellcheck disable=SC1091
  source "$HERE/config.env"
fi

SRC="${ARGS[0]:-${QE_BIN_DIR:-}}"
if [[ -z "$SRC" ]]; then
  for c in \
      "$HOME/q-e-qe-7.5/bin" \
      "$HOME/q-e-7.5/bin" \
      /opt/qe/bin \
      /usr/local/bin
  do
    if [[ -x "$c/pw.x" ]]; then SRC="$c"; break; fi
  done
fi

if [[ -z "$SRC" || ! -e "$SRC/pw.x" ]]; then
  echo "[associer] ERREUR : précise le dossier QE (pw.x) :" >&2
  echo "  ./scripts/associer_binaires_qe.sh /chemin/vers/qe/bin" >&2
  exit 1
fi
SRC="$(cd "$SRC" && pwd)"

# config.env pointe souvent vers supra-QE/bin/ : retrouver le vrai prefix QE
_bin_real="$(readlink -f "$HERE/bin" 2>/dev/null || echo "$HERE/bin")"
_src_real="$(readlink -f "$SRC" 2>/dev/null || echo "$SRC")"
if [[ "$_src_real" == "$_bin_real" ]]; then
  if [[ -L "$SRC/pw.x" ]]; then
    SRC="$(cd "$(dirname "$(readlink -f "$SRC/pw.x")")" && pwd)"
    echo "[associer] Source résolue depuis les liens existants : $SRC"
  fi
fi

if [[ ! -x "$SRC/pw.x" ]]; then
  echo "[associer] ERREUR : pw.x non exécutable dans $SRC" >&2
  exit 1
fi

# En mode copie, ne pas prendre supra-QE/bin comme source (liens déjà présents).
if [[ "$COPY_MODE" -eq 1 ]]; then
  _src_canon="$(readlink -f "$SRC" 2>/dev/null || echo "$SRC")"
  _bin_canon="$(readlink -f "$HERE/bin" 2>/dev/null || echo "$HERE/bin")"
  if [[ "$_src_canon" == "$_bin_canon" && -L "$SRC/pw.x" ]]; then
    SRC="$(cd "$(dirname "$(readlink -f "$SRC/pw.x")")" && pwd)"
    echo "[associer] Source copie résolue : $SRC"
  fi
fi

# Si epw.x manque : tenter l'installateur (compile une fois dans l'arbre QE)
if [[ ! -x "$SRC/epw.x" ]]; then
  echo "[associer] epw.x absent de $SRC — tentative ./scripts/installer_epw.sh …"
  if [[ -x "$HERE/scripts/installer_epw.sh" ]]; then
    QE_ROOT="$(cd "$SRC/.." && pwd)" "$HERE/scripts/installer_epw.sh" || true
  fi
fi

mkdir -p "$HERE/bin"

install_one() {
  local name="$1" src_path="$2"
  if [[ "$COPY_MODE" -eq 1 ]]; then
    rm -f "$HERE/bin/$name"
    cp -L "$src_path" "$HERE/bin/$name"
    chmod +x "$HERE/bin/$name" 2>/dev/null || true
  else
    ln -sfn "$(readlink -f "$src_path" 2>/dev/null || echo "$src_path")" "$HERE/bin/$name"
  fi
}

LINKED=()
MISSING=()
MISSING_REQUIRED=()
MISSING_EPW=()
for b in "${SUPRA_QE_BINS_ALL[@]}"; do
  if [[ -e "$SRC/$b" || -L "$SRC/$b" ]]; then
    install_one "$b" "$SRC/$b"
    LINKED+=("$b")
  else
    MISSING+=("$b")
    if printf '%s\n' "${SUPRA_QE_BINS_REQUIRED[@]}" | grep -qx "$b"; then
      MISSING_REQUIRED+=("$b")
    elif printf '%s\n' "${SUPRA_QE_BINS_EPW[@]}" | grep -qx "$b"; then
      MISSING_EPW+=("$b")
    fi
  fi
done

# pp.py (regroupement save/ avant epw) — lien pratique
PP_CAND=(
  "$SRC/../EPW/bin/pp.py"
  "$SRC/pp.py"
)
for pp in "${PP_CAND[@]}"; do
  if [[ -f "$pp" ]]; then
    if [[ "$COPY_MODE" -eq 1 ]]; then
      rm -f "$HERE/bin/pp.py"
      cp -f "$pp" "$HERE/bin/pp.py"
      chmod +x "$HERE/bin/pp.py" 2>/dev/null || true
    else
      ln -sfn "$(cd "$(dirname "$pp")" && pwd)/$(basename "$pp")" "$HERE/bin/pp.py"
    fi
    LINKED+=("pp.py")
    break
  fi
done

MODE_LABEL="Liens symboliques"
[[ "$COPY_MODE" -eq 1 ]] && MODE_LABEL="Copies (cp -L) — dossier bin portable"
echo "[associer] Source QE : $SRC"
echo "[associer] Mode     : $MODE_LABEL"
echo "[associer] Cible    → $HERE/bin/"
echo "[associer] Associés (${#LINKED[@]}) : ${LINKED[*]:-aucun}"
if [[ "$COPY_MODE" -eq 1 ]]; then
  du -sh "$HERE/bin" 2>/dev/null | awk '{print "[associer] Taille bin/ : "$1}'
  echo "[associer] Note : mpirun / OpenMPI restent ceux du système (voir /health)."
fi
if [[ ${#MISSING[@]} -gt 0 ]]; then
  echo "[associer] Absents  (${#MISSING[@]}) : ${MISSING[*]}"
  [[ ${#MISSING_REQUIRED[@]} -gt 0 ]] && echo "[associer]   → bloquant WF1 : ${MISSING_REQUIRED[*]}"
  [[ ${#MISSING_EPW[@]} -gt 0 ]] && echo "[associer]   → WF2 EPW incomplet : ${MISSING_EPW[*]}"
fi

# Pointe config.env vers le bin local du projet (portable dans ce dossier)
if [[ -f "$HERE/config.env" ]]; then
  if grep -q '^export QE_BIN_DIR=' "$HERE/config.env" 2>/dev/null; then
    sed -i "s|^export QE_BIN_DIR=.*|export QE_BIN_DIR=\"$HERE/bin\"|" "$HERE/config.env"
  else
    echo "export QE_BIN_DIR=\"$HERE/bin\"" >> "$HERE/config.env"
  fi
  echo "[associer] config.env → QE_BIN_DIR=$HERE/bin"
else
  echo "export QE_BIN_DIR=\"$HERE/bin\"" > "$HERE/config.env"
  echo "[associer] config.env créé avec QE_BIN_DIR=$HERE/bin"
fi

if [[ -x "$HERE/bin/epw.x" && -x "$HERE/bin/wannier90.x" ]]; then
  echo "[associer] ✅ WF2 EPW : epw.x + wannier90.x prêts."
elif [[ -x "$HERE/bin/epw.x" ]]; then
  echo "[associer] ⚠️  epw.x OK mais wannier90.x manquant dans $SRC"
else
  echo "[associer] ⚠️  epw.x absent — lance : ./scripts/installer_epw.sh"
  echo "           puis relance : ./scripts/associer_binaires_qe.sh"
fi
if [[ -x "$HERE/bin/fs.x" ]]; then
  echo "[associer] ✅ fs.x → export .bxsf (surface de Fermi / XCrySDen)."
fi
echo "[associer] Relance l'API : ./ARRETER.sh && ./DEMARRER.sh"

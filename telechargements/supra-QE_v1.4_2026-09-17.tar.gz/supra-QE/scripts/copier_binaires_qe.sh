#!/usr/bin/env bash
# Copie (au lieu de lier) les exécutables QE dans supra-QE/bin/ pour une archive
# ou un autre PC. Équivalent à : ./scripts/associer_binaires_qe.sh --copy "$@"
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
exec "$HERE/scripts/associer_binaires_qe.sh" --copy "$@"

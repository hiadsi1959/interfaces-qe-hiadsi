#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Supra-QE API
============

API Flask dédiée au workflow de calcul de la température critique
supraconductrice (Tᶜ) avec Quantum ESPRESSO.

Workflow strict :
    SCF dense (pw.x)
    → NSCF dense (pw.x)
    → DFPT / phonons (ph.x)
    → q2r.x → matdyn.x → α²F(ω), λ, ω_log, Tᶜ

Points clés :
    - n'autorise QUE des pseudopotentiels Norm-Conserving (NC) pour ph.x ;
    - vérifie l'asymétrie K-grid (NSCF, dense) vs Q-grid (phonons, petite) ;
    - paramètre μ* pré-rempli à 0.10 (modifiable).
"""

from __future__ import annotations

import io
import json
import os
import re
import signal
import sys
import shutil
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

# UTF-8 forcé pour les logs Linux/Windows
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
if sys.stderr.encoding != 'utf-8':
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

from flask import Flask, jsonify, request, send_from_directory, make_response, redirect
from flask_cors import CORS

# Parseurs et exploitation des résultats (α²F, λ, ω_log, Tᶜ, gap, phonons…)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import supra_results as SR  # noqa: E402
from supra_results import (  # noqa: E402  (ré-export : API publique historique)
    tc_mcmillan,
    tc_allen_dynes,
    parse_epw_output,
    classify_electronic_character,
)


# ─────────────────────────────────────────────────────────────────────────────
#  Configuration de chemins (portable)
# ─────────────────────────────────────────────────────────────────────────────
API_DIR = Path(__file__).resolve().parent
REPO_ROOT = API_DIR.parent

def _path_from_env(var_name: str, default_rel: str) -> Path:
    raw = os.environ.get(var_name, "").strip()
    if not raw:
        return (REPO_ROOT / default_rel).resolve()
    p = Path(raw).expanduser()
    return p.resolve() if p.is_absolute() else (REPO_ROOT / p).resolve()


INTERFACE_DIR = REPO_ROOT / "interface"
INPUTS_DIR = _path_from_env("SUPRA_INPUTS_DIR", "inputs")
OUTPUTS_DIR = _path_from_env("SUPRA_OUTPUTS_DIR", "outputs")
LOGS_DIR = _path_from_env("SUPRA_LOGS_DIR", "logs")
TMP_DIR = _path_from_env("SUPRA_TMP_DIR", "tmp")
for d in (INPUTS_DIR, OUTPUTS_DIR, LOGS_DIR, TMP_DIR):
    d.mkdir(parents=True, exist_ok=True)

# Pseudos : uniquement le dossier interne du projet (autonomie)
# L'utilisateur peut surcharger via la variable d'environnement QE_PSEUDO_DIR
_env_pseudo = os.environ.get("QE_PSEUDO_DIR", "").strip()
PSEUDOS_DIR = (Path(_env_pseudo).expanduser().resolve()
               if _env_pseudo and Path(_env_pseudo).expanduser().is_dir()
               else REPO_ROOT / "pseudos")
PSEUDOS_DIR.mkdir(parents=True, exist_ok=True)

# Binaires QE : QE_BIN_DIR forcé, sinon supra-QE/bin/ (liens associés),
# puis emplacements standards. Préférence à un dossier qui a aussi epw.x.
_env_bin = os.environ.get("QE_BIN_DIR", "").strip()
_QE_BIN_CANDIDATES: List[Optional[Path]] = [
    Path(_env_bin).expanduser() if _env_bin else None,
    REPO_ROOT / "bin",
    Path("/opt/qe/bin"),
    Path("/usr/local/bin"),
    Path("/usr/bin"),
]
for _cand in Path.home().glob("q-e*/bin"):
    _QE_BIN_CANDIDATES.append(_cand)

_valid_bins = [p for p in _QE_BIN_CANDIDATES if p and (p / "pw.x").is_file()]
# Préférer une installation déjà équipée d'epw.x (évite de forcer une recompilation)
QE_BIN_DIR = next((p for p in _valid_bins if (p / "epw.x").is_file()), None) \
    or (_valid_bins[0] if _valid_bins else None)


def _qe_program(name: str) -> Optional[Path]:
    """Résout un binaire : QE_BIN_DIR d'abord, puis supra-QE/bin/ en secours."""
    for root in (QE_BIN_DIR, REPO_ROOT / "bin"):
        if root is None:
            continue
        cand = root / name
        try:
            if cand.is_file():
                return cand.resolve()
        except OSError:
            continue
    return None


QE_PROGRAMS: Dict[str, Optional[Path]] = {
    'pw.x':       _qe_program("pw.x"),
    'ph.x':       _qe_program("ph.x"),
    'q2r.x':      _qe_program("q2r.x"),
    'matdyn.x':   _qe_program("matdyn.x"),
    'lambda.x':   _qe_program("lambda.x"),
    'alpha2f.x':  _qe_program("alpha2f.x"),
    'epw.x':      _qe_program("epw.x"),
    'wannier90.x':    _qe_program("wannier90.x"),
    'pw2wannier90.x': _qe_program("pw2wannier90.x"),
    'fs.x':           _qe_program("fs.x"),
}

# MPI
MPIRUN_CANDIDATES = [
    "/opt/intel/oneapi/mpi/2021.17/bin/mpirun",
    "/opt/intel/oneapi/mpi/latest/bin/mpirun",
    "mpirun",
]


def detect_mpirun() -> Optional[str]:
    import shutil
    for c in MPIRUN_CANDIDATES:
        if c.startswith("/") and Path(c).is_file():
            return c
        if shutil.which(c):
            return shutil.which(c)
    return None


def _host_hw() -> Dict[str, Any]:
    """
    Ressources du PC qui exécute l'API (pas le navigateur).
    Sert à préremplir MPI / OMP à la connexion.
    """
    logical = os.cpu_count() or 1
    cores: set = set()
    try:
        phys = core = None
        with open("/proc/cpuinfo", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                if line.startswith("physical id"):
                    phys = line.split(":", 1)[1].strip()
                elif line.startswith("core id"):
                    core = line.split(":", 1)[1].strip()
                    if phys is not None and core is not None:
                        cores.add((phys, core))
                        phys = core = None
    except OSError:
        pass
    physical = len(cores) or logical

    mem_gb: Optional[float] = None
    try:
        with open("/proc/meminfo", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                if line.startswith("MemTotal:"):
                    kb = int(line.split()[1])
                    mem_gb = round(kb / 1024.0 / 1024.0, 1)
                    break
    except (OSError, ValueError, IndexError):
        mem_gb = None

    try:
        hostname = os.uname().nodename
    except AttributeError:
        hostname = os.environ.get("HOSTNAME") or os.environ.get("COMPUTERNAME") or ""

    mpirun = detect_mpirun()
    spare = 1 if physical >= 4 else 0
    by_cpu = max(1, physical - spare)
    by_mem = max(1, int(mem_gb / 2.5)) if mem_gb else by_cpu
    rec_np = min(by_cpu, by_mem, logical)
    if mpirun:
        rec_nt = 1
    else:
        rec_np = 1
        rec_nt = min(physical, 8)

    return {
        "hostname": hostname,
        "cpu_logical": logical,
        "cpu_physical": physical,
        "mem_gb": mem_gb,
        "mpirun": mpirun,
        "recommended_nprocs": rec_np,
        "recommended_nthreads": rec_nt,
    }


# ─────────────────────────────────────────────────────────────────────────────
#  Sécurité : bornes anti-RCE & anti-DoS (audit P0/P1)
# ─────────────────────────────────────────────────────────────────────────────
# Whitelist d'extensions (refus par défaut) → bloque l'écrasement de code/UI/config
_ALLOWED_WRITE_EXTS: frozenset = frozenset({".in", ".out", ".json", ".dat", ".png",
                                            ".csv", ".txt", ".log", ".freq", ".fc",
                                            ".save", ".xml", ".yaml", ".yml", ".upf",
                                            ".gp", ".modes", ".dyn", ".dvscf"})
_ALLOWED_WRITE_BASENAMES: frozenset = frozenset({".gitkeep"})
_DENIED_READ_NAMES: frozenset = frozenset({
    "config.env", ".env", ".git", ".venv", "id_rsa", "id_ed25519",
})
_MAX_CONCURRENT_JOBS: int = max(1, int(os.environ.get("SUPRA_MAX_CONCURRENT_JOBS", "1")))
_job_slots: threading.BoundedSemaphore = threading.BoundedSemaphore(_MAX_CONCURRENT_JOBS)
_API_TOKEN: str = os.environ.get("SUPRA_API_TOKEN", "").strip()
_ALLOW_LAN: bool = os.environ.get("SUPRA_ALLOW_LAN", "").strip().lower() in ("1", "true", "yes", "on")


def _write_roots() -> Tuple[Path, ...]:
    """Racines d'écriture (relit les globals — honoré après monkeypatch / SUPRA_*_DIR)."""
    return (INPUTS_DIR, OUTPUTS_DIR, TMP_DIR)


def _read_roots() -> Tuple[Path, ...]:
    return (INPUTS_DIR, OUTPUTS_DIR, TMP_DIR, LOGS_DIR, PSEUDOS_DIR)


def _root_aliases() -> Dict[str, Path]:
    """Alias UI « inputs/… » → racines configurables (dynamique)."""
    return {
        "inputs": INPUTS_DIR,
        "outputs": OUTPUTS_DIR,
        "logs": LOGS_DIR,
        "tmp": TMP_DIR,
        "pseudos": PSEUDOS_DIR,
    }


def _is_path_under(child: Path, parent: Path) -> bool:
    """Vrai si child == parent ou est sous parent (résolution symlink-safe)."""
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def _normalize_rel(rel: str) -> str:
    return (rel or "").replace("\\", "/").strip().lstrip("./")


def _resolve_aliased_path(rel: str) -> Optional[Path]:
    """
    Résout un chemin UI relatif en honorant SUPRA_INPUTS_DIR / OUTPUTS_DIR / …

    Ex. « inputs/Nb/x.out » → INPUTS_DIR / « Nb/x.out » même si INPUTS_DIR
    est hors du dépôt.
    """
    rel_n = _normalize_rel(rel)
    if not rel_n or ".." in Path(rel_n).parts:
        return None
    parts = Path(rel_n).parts
    if not parts:
        return None
    head = parts[0].lower()
    aliases = _root_aliases()
    if head in aliases:
        root = aliases[head]
        return (root / Path(*parts[1:])).resolve() if len(parts) > 1 else root.resolve()
    # Repli : relatif au dépôt, puis contrôle d'appartenance aux racines
    try:
        return (REPO_ROOT / rel_n).resolve()
    except (OSError, ValueError):
        return None


def _safe_path(rel: str) -> Optional[Path]:
    """
    Lecture / run : uniquement sous inputs|outputs|logs|tmp|pseudos
    (racines SUPRA_*_DIR), jamais config.env / .venv / sources.
    """
    p = _resolve_aliased_path(rel)
    if p is None:
        return None
    try:
        resolved = p.resolve()
    except (OSError, ValueError):
        return None
    if resolved.name in _DENIED_READ_NAMES or any(
        part in _DENIED_READ_NAMES for part in resolved.parts
    ):
        return None
    if not any(_is_path_under(resolved, d) for d in _read_roots()):
        return None
    return resolved


def _safe_write_path(rel: str) -> Optional[Path]:
    """
    Écritures API : INPUTS_DIR / OUTPUTS_DIR / TMP_DIR + whitelist d'extensions.
    """
    p = _resolve_aliased_path(rel)
    if p is None:
        return None
    try:
        resolved = p.resolve()
    except (OSError, ValueError):
        return None
    if not any(_is_path_under(resolved, d) for d in _write_roots()):
        return None
    name = resolved.name
    if name in _ALLOWED_WRITE_BASENAMES:
        return resolved
    if name in _DENIED_READ_NAMES:
        return None
    ext = resolved.suffix.lower()
    if ext not in _ALLOWED_WRITE_EXTS:
        return None
    return resolved

def _security_log(msg: str) -> None:
    """Journalise un refus pour audit (Fail2Ban/WAF friendly)."""
    try:
        app.logger.warning(msg)
    except (AttributeError, RuntimeError):
        pass


def _cors_allowed_origins() -> List[str]:
    """Origines CORS : localhost par défaut ; liste via SUPRA_CORS_ORIGINS."""
    raw = os.environ.get("SUPRA_CORS_ORIGINS", "").strip()
    port = os.environ.get("SUPRA_QE_PORT", "8765")
    if raw == "*":
        return ["*"]
    if raw:
        return [o.strip() for o in raw.split(",") if o.strip()]
    return [
        f"http://127.0.0.1:{port}",
        f"http://localhost:{port}",
        "null",  # file:// → certains navigateurs envoient Origin: null
    ]


# ─────────────────────────────────────────────────────────────────────────────
#  Flask
# ─────────────────────────────────────────────────────────────────────────────
app = Flask(__name__)
_CORS_ORIGINS = _cors_allowed_origins()
CORS(app, resources={r"/*": {
    "origins": _CORS_ORIGINS,
    "methods": ["GET", "POST", "OPTIONS"],
    "allow_headers": ["Content-Type", "Authorization", "X-Supra-Token"],
}})

JOBS: Dict[str, Dict[str, Any]] = {}
_job_counter = 0
_job_lock = threading.Lock()


@app.before_request
def _security_gate():
    # Préflight CORS
    if request.method == "OPTIONS":
        resp = make_response("", 204)
        origin = request.headers.get("Origin", "")
        if "*" in _CORS_ORIGINS or origin in _CORS_ORIGINS:
            resp.headers["Access-Control-Allow-Origin"] = origin or _CORS_ORIGINS[0]
        resp.headers["Access-Control-Allow-Headers"] = (
            request.headers.get("Access-Control-Request-Headers")
            or "Content-Type, Authorization, X-Supra-Token"
        )
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        resp.headers["Access-Control-Max-Age"] = "86400"
        return resp

    # Token optionnel (recommandé si SUPRA_QE_HOST=0.0.0.0)
    if _API_TOKEN and request.path.startswith("/api/"):
        got = (
            request.headers.get("X-Supra-Token")
            or request.headers.get("Authorization", "").removeprefix("Bearer ").strip()
        )
        if got != _API_TOKEN:
            _security_log(f"SECURITY: token refusé path={request.path}")
            return jsonify({"ok": False, "error": "token API requis (SUPRA_API_TOKEN)"}), 401
    return None


# ─────────────────────────────────────────────────────────────────────────────
#  Endpoints généraux
# ─────────────────────────────────────────────────────────────────────────────
_QE_REQUIRED = ('pw.x', 'ph.x', 'q2r.x', 'matdyn.x')
_QE_OPTIONAL = (
    'epw.x', 'wannier90.x', 'pw2wannier90.x',
    'alpha2f.x', 'lambda.x', 'fs.x',
)


def _qe_bins_status() -> Dict[str, Any]:
    """État des binaires : classique obligatoire, EPW optionnel."""
    found = {k: bool(v and v.is_file()) for k, v in QE_PROGRAMS.items() if v is not None}
    classic_ok = bool(QE_BIN_DIR) and all(found.get(p) for p in _QE_REQUIRED)
    epw_ok = found.get('epw.x', False) and found.get('wannier90.x', False)
    return {
        'classic_ok': classic_ok,
        'epw_ok':     epw_ok,
        'found':      found,
        'missing_required': [p for p in _QE_REQUIRED if not found.get(p)],
        'missing_optional': [p for p in _QE_OPTIONAL if not found.get(p)],
    }


@app.route('/', methods=['GET'])
@app.route('/health', methods=['GET'])
def health():
    bins = _qe_bins_status()
    return jsonify({
        'service': 'supra-qe',
        'status':  'ok' if bins['classic_ok'] else 'degraded',
        'qe_bin_dir':   str(QE_BIN_DIR) if QE_BIN_DIR else None,
        'pseudos_dir':  str(PSEUDOS_DIR),
        'pseudo_dir_rel': os.environ.get('SUPRA_PSEUDO_DIR_REL', '../../../pseudos/'),
        'inputs_dir':   str(INPUTS_DIR),
        'outputs_dir':  str(OUTPUTS_DIR),
        'mpirun':       detect_mpirun(),
        'host':         _host_hw(),
        'qe': bins,
        'max_concurrent_jobs': _MAX_CONCURRENT_JOBS,
    })


@app.route('/')
def root_redirect():
    return redirect('/interface/', code=302)


@app.route('/interface', methods=['GET'])
def interface_root():
    return redirect('/interface/', code=302)


@app.route('/interface/', methods=['GET'])
def interface_index():
    resp = send_from_directory(str(INTERFACE_DIR), "Interface_Supra_QE.html")
    resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate'
    return resp


@app.route('/interface/<path:filename>', methods=['GET'])
def interface_file(filename: str):
    resp = send_from_directory(str(INTERFACE_DIR), filename)
    resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate'
    return resp


# ─────────────────────────────────────────────────────────────────────────────
#  Détection du type de pseudopotentiel (NC vs USPP vs PAW)
# ─────────────────────────────────────────────────────────────────────────────
# Le type se lit dans le *contenu* UPF, pas dans le nom de fichier :
# Nb.upf, Nb_ONCV_PBE-1.2.upf, nb-pbe-nc.UPF, PseudoDojo_Nb.upf → NC si l'en-tête l'est.
_NC_TYPE_TOKENS = frozenset({
    'NC', 'NCPP', 'NORM-CONSERVING', 'NORMCONSERVING', 'NORM_CONSERVING',
})
_US_TYPE_TOKENS = frozenset({
    'US', 'USPP', 'ULTRA-SOFT', 'ULTRASOFT', 'ULTRASOFT_PSEUDOPOTENTIAL',
})


def detect_pseudo_kind(path: Path) -> str:
    """
    Retourne 'NC' / 'USPP' / 'PAW' / 'UNKNOWN' / 'MISSING'.

    Priorité au contenu UPF (pseudo_type, is_ultrasoft, is_paw, marqueurs ONCVPSP).
    Le nom de fichier n'est qu'un repli faible — tout NC est accepté quel que
    soit son nommage (PseudoDojo, SG15, ONCV, nom court « Nb.upf », etc.).
    """
    if not path.is_file():
        return 'MISSING'
    try:
        head = path.read_text(encoding='utf-8', errors='ignore')[:65536]
    except OSError:
        return 'UNKNOWN'

    up = head.upper()

    # ── PAW / USPP explicites (booléens T uniquement) ─────────────────────
    if (re.search(r'IS_PAW\s*=\s*"\s*T\s*"', up)
            or re.search(r"IS_PAW\s*=\s*'\s*T\s*'", up)
            or 'PAW_PP' in up or '<PP_PAW' in up):
        return 'PAW'
    if (re.search(r'IS_ULTRASOFT\s*=\s*"\s*T\s*"', up)
            or re.search(r"IS_ULTRASOFT\s*=\s*'\s*T\s*'", up)):
        return 'USPP'

    # ── pseudo_type = "…" (guillemets doubles ou simples, multiligne OK) ───
    m = re.search(r'PSEUDO_TYPE\s*=\s*["\']\s*([^"\']+)\s*["\']', up)
    if m:
        pt = re.sub(r'[\s_\-]+', '-', m.group(1).strip())
        pt_compact = pt.replace('-', '')
        if pt in _NC_TYPE_TOKENS or pt_compact in ('NC', 'NCPP', 'NORMCONSERVING'):
            return 'NC'
        if pt in _US_TYPE_TOKENS or pt_compact.startswith('US'):
            return 'USPP'
        if pt.startswith('PAW') or pt_compact.startswith('PAW'):
            return 'PAW'

    # ── Marqueurs texte fréquents (ONCVPSP / HSCV / commentaire NC) ────────
    if any(tok in up for tok in (
        'ONCVPSP', 'OPTIMIZED NORM-CONSERVING', 'OPTIMIZED NORM CONSERVING',
        'NORM-CONSERVING VANDERBILT', 'NORM CONSERVING PSEUDOPOTENTIAL',
        'SCHLIPF-GYGI NORM-CONSERVING',
    )):
        # Sauf si clairement US/PAW ailleurs (déjà filtrés plus haut)
        if 'IS_ULTRASOFT="T"' not in up and 'IS_PAW="T"' not in up:
            return 'NC'

    # ── Booléens F + F sans type : convention NC UPF2 ─────────────────────
    us_f = bool(re.search(r'IS_ULTRASOFT\s*=\s*["\']\s*F\s*["\']', up))
    paw_f = bool(re.search(r'IS_PAW\s*=\s*["\']\s*F\s*["\']', up))
    if us_f and paw_f:
        return 'NC'

    # ── Repli faible sur le nom (jamais bloquant pour un vrai NC nommé autrement)
    name = path.name.lower()
    if any(tag in name for tag in (
        'oncv', 'oncvpsp', 'sg15', 'pseudodojo', 'hscv',
        '_nc_', '-nc-', '.nc.', '_nc.', '-nc.', 'ncpp',
    )):
        if 'paw' not in name and 'rrkjus' not in name and 'uspp' not in name:
            return 'NC'
    if 'rrkjus' in name or 'uspp' in name or 'ultrasoft' in name:
        return 'USPP'
    if re.search(r'(^|[_\-.])paw([_\-.]|$)', name):
        return 'PAW'
    return 'UNKNOWN'


def _element_from_pseudo_name(name: str) -> str:
    """Nb_ONCV_PBE-1.2.upf → Nb ; nb.upf → Nb ; Fe.pbe-n-nc.UPF → Fe."""
    stem = Path(name).stem
    m = re.match(r'^([A-Za-z]{1,2})', stem)
    if not m:
        return ''
    sym = m.group(1)
    # Normalise : première majuscule (nb → Nb, FE → Fe)
    return sym[0].upper() + (sym[1:].lower() if len(sym) > 1 else '')


def find_nc_pseudos_for_element(symbol: str, pdir: Path) -> List[Path]:
    """Tous les .upf NC du dossier dont le nom commence par le symbole chimique."""
    sym = (symbol or '').strip()
    if not sym or not pdir.is_dir():
        return []
    sym_l = sym.lower()
    hits: List[Path] = []
    for p in sorted(pdir.iterdir()):
        if not p.is_file() or p.suffix.lower() != '.upf':
            continue
        el = _element_from_pseudo_name(p.name)
        if el.lower() != sym_l:
            continue
        if detect_pseudo_kind(p) == 'NC':
            hits.append(p)
    return hits


@app.route('/api/pseudo/check', methods=['POST'])
def api_pseudo_check():
    """
    Entrée : { "pseudos": ["Nb.upf", "Sn.UPF"], "pseudo_dir": "pseudos/" }
    Sortie : { "results": [...], "all_nc": true/false, "issues": [...] }

    Si le nom demandé est absent (ou non-NC) mais qu'un autre .upf **NC**
    pour le même élément existe dans le dossier (ex. Nb_ONCV_PBE-1.2.upf),
    il est accepté automatiquement (`resolved_from`).
    """
    data = request.get_json(force=True, silent=True) or {}
    pseudos: List[str] = data.get('pseudos') or []
    raw_pdir = (data.get('pseudo_dir') or '').strip()
    if raw_pdir:
        # Relatif UI (pseudos/… ou ../../../pseudos/) → dossier projet
        candidate = _resolve_aliased_path(raw_pdir.replace("../", ""))
        if candidate is None:
            # ex. ../../../pseudos/ depuis inputs → normaliser vers pseudos/
            norm = raw_pdir.replace("\\", "/").rstrip("/")
            while norm.startswith("../"):
                norm = norm[3:]
            if norm in ("", ".", "pseudos"):
                candidate = PSEUDOS_DIR
            else:
                candidate = _resolve_aliased_path(norm) or PSEUDOS_DIR
        pdir = candidate if _is_path_under(candidate, PSEUDOS_DIR) or candidate == PSEUDOS_DIR.resolve() else PSEUDOS_DIR
        try:
            pdir = pdir.resolve()
        except (OSError, ValueError):
            pdir = PSEUDOS_DIR
    else:
        pdir = PSEUDOS_DIR
    if not _is_path_under(pdir, PSEUDOS_DIR) and pdir != PSEUDOS_DIR.resolve():
        pdir = PSEUDOS_DIR
    results = []
    issues: List[str] = []
    for fname in pseudos:
        # Jamais de chemin absolu arbitraire fourni par le client
        base = Path(fname).name
        p = (pdir / base)
        kind = detect_pseudo_kind(p)
        resolved_from = None
        # Nom différent OK : bascule vers un NC du même élément si besoin
        if kind in ('MISSING', 'USPP', 'PAW', 'UNKNOWN'):
            el = _element_from_pseudo_name(base)
            alts = [a for a in find_nc_pseudos_for_element(el, pdir) if a.name != base]
            if alts:
                # Préfère un ONCV / PseudoDojo si présent, sinon le premier
                def _rank(path: Path) -> Tuple[int, str]:
                    n = path.name.lower()
                    score = 0
                    if 'oncv' in n or 'pseudodojo' in n or 'sg15' in n:
                        score -= 10
                    if 'pbe' in n:
                        score -= 1
                    return (score, n)
                best = sorted(alts, key=_rank)[0]
                resolved_from = base
                base = best.name
                p = best
                kind = 'NC'
        entry = {'file': str(p), 'name': base, 'kind': kind}
        if resolved_from:
            entry['resolved_from'] = resolved_from
            entry['note'] = (f"« {resolved_from} » remplacé par le NC « {base} » "
                             f"(même élément, nommage différent accepté).")
        results.append(entry)
        if kind in ('USPP', 'PAW'):
            issues.append(f"{base} est de type {kind} — incompatible avec le couplage e–p de Supra-QE.")
        elif kind == 'MISSING':
            issues.append(f"{Path(fname).name} introuvable dans {pdir} "
                          f"(aucun NC alternatif pour cet élément).")
        elif kind == 'UNKNOWN':
            issues.append(f"{base} : type indéterminé, vérifier manuellement.")
    all_nc = bool(results) and all(r['kind'] == 'NC' for r in results)
    return jsonify({
        'results':  results,
        'all_nc':   all_nc,
        'issues':   issues,
        'pseudo_dir': str(pdir),
    })


# ─────────────────────────────────────────────────────────────────────────────
#  Validation des grilles (K-points NSCF dense, Q-points phonons modeste)
# ─────────────────────────────────────────────────────────────────────────────
@app.route('/api/grid/validate', methods=['POST'])
def api_grid_validate():
    """
    Entrée : { "k": [nk1,nk2,nk3], "q": [nq1,nq2,nq3] }
    Sortie : ratios, statut, conseils.
    """
    data = request.get_json(force=True, silent=True) or {}
    k = data.get('k') or [16, 16, 16]
    q = data.get('q') or [4, 4, 4]
    try:
        k = [int(x) for x in k]
        q = [int(x) for x in q]
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'grilles invalides'}), 400

    ratios = [k[i] / q[i] if q[i] else 0 for i in range(3)]
    integer_ratio = all(q[i] > 0 and k[i] % q[i] == 0 for i in range(3))
    min_ratio = min(ratios) if ratios else 0
    msgs: List[str] = []

    if not integer_ratio:
        msgs.append("⚠️  Le ratio k/q doit être entier sur chaque axe : chaque point q "
                    "doit correspondre à une sous-grille de k. Ajustez k ou q.")
    if min_ratio < 2:
        msgs.append("⚠️  La grille k (NSCF) doit être au moins 2× la grille q (phonons). "
                    "Préférez k ≥ 4×q pour les métaux supraconducteurs.")
    if max(q) > 8:
        msgs.append("ℹ️  Grille q très dense : le calcul ph.x sera très long. "
                    "Une grille 4×4×4 ou 6×6×6 est typique en supraconductivité conventionnelle.")
    if max(k) < 12:
        msgs.append("⚠️  Grille k NSCF un peu faible. Pour un métal : viser 16³ minimum, "
                    "24³ recommandé.")

    return jsonify({
        'k': k, 'q': q,
        'ratios': ratios,
        'integer_ratio': integer_ratio,
        'min_ratio': min_ratio,
        'ok': integer_ratio and min_ratio >= 2,
        'messages': msgs,
    })


# ─────────────────────────────────────────────────────────────────────────────
#  Sauvegarde / lecture (sandbox : _safe_path / _safe_write_path définis plus haut)
# ─────────────────────────────────────────────────────────────────────────────


@app.route('/api/file/save', methods=['POST'])
def api_file_save():
    data = request.get_json(force=True, silent=True) or {}
    rel = data.get('path') or ''
    content = data.get('content') or ''
    target = _safe_write_path(rel)  # anti-RCE : restreint à inputs/outputs/tmp + whitelist d'extensions
    if not target:
        _security_log(f"SECURITY: /api/file/save refusé (path={rel!r})")
        return jsonify({'ok': False,
                        'error': 'chemin invalide ou hors zone d\'écriture (inputs/outputs/tmp + whitelist d\'extensions)'}), 403
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding='utf-8')
    return jsonify({'ok': True, 'path': str(target), 'size': len(content)})


@app.route('/api/file/read', methods=['POST'])
def api_file_read():
    """
    Lit un fichier texte sous inputs|outputs|logs|tmp|pseudos uniquement.

    Options (utiles pour les sorties QE qui peuvent peser des centaines de Mo) :
      - ``max_bytes`` : plafond de lecture ; au-delà on renvoie le début et la
        fin du fichier séparés par un marqueur, et ``truncated = true`` ;
      - ``tail_lines`` : ne renvoie que les N dernières lignes.
    """
    data = request.get_json(force=True, silent=True) or {}
    rel = data.get('path') or ''
    target = _safe_path(rel)
    if not target or not target.is_file():
        # 404 volontaire : ne pas distinguer « hors zone » et « absent »
        if rel:
            _security_log(f"SECURITY: /api/file/read refusé ou absent (path={rel!r})")
        return jsonify({'ok': False, 'error': 'fichier introuvable'}), 404
    try:
        size = target.stat().st_size
        max_bytes = int(data.get('max_bytes') or 0)
        truncated = False
        if max_bytes > 0 and size > max_bytes:
            half = max_bytes // 2
            with target.open('r', encoding='utf-8', errors='replace') as fh:
                head = fh.read(half)
                fh.seek(max(size - half, 0))
                tail = fh.read()
            skipped = size - len(head.encode('utf-8', 'replace')) - len(tail.encode('utf-8', 'replace'))
            content = (head + f"\n\n[… {max(skipped, 0)} octets omis …]\n\n" + tail)
            truncated = True
        else:
            content = target.read_text(encoding='utf-8', errors='replace')
        tail_lines = int(data.get('tail_lines') or 0)
        if tail_lines > 0:
            parts = content.splitlines()
            if len(parts) > tail_lines:
                content = '\n'.join(parts[-tail_lines:])
                truncated = True
    except (OSError, ValueError) as exc:
        return jsonify({'ok': False, 'error': str(exc)}), 500
    return jsonify({'ok': True, 'content': content, 'path': str(target),
                    'size': size, 'truncated': truncated})


_QE_ERROR_RE = re.compile(r'Error in routine|%%%%%%%%%%|stopping \.\.\.', re.I)
_STAT_TAIL_BYTES = 64 * 1024


def _out_flags(path: Path) -> Tuple[bool, bool]:
    """(job_done, has_error) d'une sortie QE, en ne lisant que sa fin."""
    try:
        size = path.stat().st_size
        with open(path, 'rb') as fh:
            if size > _STAT_TAIL_BYTES:
                fh.seek(-_STAT_TAIL_BYTES, os.SEEK_END)
            tail = fh.read().decode('utf-8', errors='replace')
    except OSError:
        return False, False
    return ('JOB DONE' in tail), bool(_QE_ERROR_RE.search(tail))


def _stat_one(rel: str) -> Dict[str, Any]:
    """
    État léger d'un fichier ou dossier du projet, sans en transférer le contenu.

    Pour un `.out` QE on lit uniquement la fin du fichier afin de détecter
    `JOB DONE` (succès) ou une signature d'erreur : c'est ce qui permet à
    l'interface de valider chaque étape avant de lancer la suivante.
    """
    info: Dict[str, Any] = {
        'path': rel, 'exists': False, 'is_dir': False,
        'size': 0, 'mtime': 0, 'job_done': False, 'has_error': False,
    }
    target = _safe_path(rel or '')
    if target is None:
        info['error'] = 'chemin invalide'
        return info
    if target.is_dir():
        info.update(exists=True, is_dir=True)
        try:
            info['n_entries'] = sum(1 for _ in target.iterdir())
            info['mtime'] = int(target.stat().st_mtime)
        except OSError:
            pass
        return info
    if not target.is_file():
        return info
    try:
        st = target.stat()
    except OSError as exc:
        info['error'] = str(exc)
        return info
    info.update(exists=True, size=st.st_size, mtime=int(st.st_mtime))
    if target.suffix.lower() in ('.out', '.log', '.txt'):
        info['job_done'], info['has_error'] = _out_flags(target)
    return info


@app.route('/api/file/stat', methods=['POST'])
def api_file_stat():
    """
    Entrée : { "path": "..." } ou { "paths": ["...", "..."] }
    Sortie : { ok, results: { <path>: { exists, size, job_done, has_error, ... } } }
    """
    data = request.get_json(force=True, silent=True) or {}
    paths = data.get('paths')
    if not paths:
        single = data.get('path')
        paths = [single] if single else []
    if not isinstance(paths, list):
        return jsonify({'ok': False, 'error': 'paths doit être une liste'}), 400
    paths = [str(p) for p in paths[:64] if p]
    results = {p: _stat_one(p) for p in paths}
    return jsonify({'ok': True, 'results': results})


# ─────────────────────────────────────────────────────────────────────────────
#  Lancement d'un calcul QE (pw.x / ph.x / q2r.x / matdyn.x)
# ─────────────────────────────────────────────────────────────────────────────
def _next_job_id() -> str:
    global _job_counter
    with _job_lock:
        _job_counter += 1
        return f"sqe_{_job_counter}_{int(time.time())}"


def _launch_in_background(job_id: str, program: str, input_path: Path,
                          output_path: Path, nprocs: int, nthreads: int,
                          workdir: Path) -> None:
    """Lance un binaire QE en arrière-plan, écrit son stdout dans output_path."""
    binary = QE_PROGRAMS.get(program)
    if not binary or not binary.is_file():
        JOBS[job_id].update(status='error', message=f"binaire {program} introuvable")
        return

    mpirun = detect_mpirun()
    if nprocs > 1 and mpirun:
        cmd = [mpirun, '-np', str(nprocs), str(binary)]
        mode = f"MPI {nprocs} procs"
    else:
        cmd = [str(binary)]
        mode = "séquentiel"

    env = os.environ.copy()
    env['OMP_NUM_THREADS'] = str(max(1, nthreads))
    intel_lib = "/opt/intel/oneapi/mpi/2021.17/lib"
    if os.path.isdir(intel_lib):
        env['LD_LIBRARY_PATH'] = intel_lib + ':' + env.get('LD_LIBRARY_PATH', '')

    output_path.parent.mkdir(parents=True, exist_ok=True)
    append_output = bool(JOBS[job_id].get('append_output'))
    JOBS[job_id].update(status='running', progress=10, mode=mode,
                        message=f"Démarrage {program} ({mode})"
                        + (" · reprise (append log)" if append_output else ""))

    try:
        if append_output and output_path.is_file():
            with open(output_path, 'a', encoding='utf-8') as fout:
                fout.write(
                    f"\n\n     ===== Supra-QE reprise {time.strftime('%d %b %Y %H:%M:%S')} "
                    f"({program}) =====\n\n"
                )
        out_mode = 'a' if append_output else 'w'
        with open(input_path, 'r', encoding='utf-8') as fin, \
             open(output_path, out_mode, encoding='utf-8') as fout:
            # start_new_session → groupe de processus tuable via cancel (mpirun + enfants)
            proc = subprocess.Popen(cmd, stdin=fin, stdout=fout,
                                    stderr=subprocess.STDOUT,
                                    cwd=str(workdir), env=env,
                                    start_new_session=True)
            JOBS[job_id]['pid'] = proc.pid
            JOBS[job_id]['proc'] = proc
            JOBS[job_id]['progress'] = 40
            rc = proc.wait()
        elapsed = time.time() - JOBS[job_id]['start']
        # Annulation : ne pas écraser le statut cancelled
        if JOBS[job_id].get('status') == 'cancelled':
            JOBS[job_id].update(progress=100, elapsed=f"{elapsed:.1f}s",
                                returncode=rc, message=JOBS[job_id].get(
                                    'message') or f"{program} annulé")
            return
        # Un code retour 0 ne suffit pas : QE peut s'arrêter proprement sur erreur.
        # On confirme avec `JOB DONE` dans la sortie (et on refuse si signature d'erreur).
        job_done, has_error = _out_flags(output_path)
        if rc == 0 and output_path.exists() and job_done and not has_error:
            JOBS[job_id].update(status='completed', progress=100,
                                message=f"{program} terminé ({mode}) en {elapsed:.1f}s",
                                elapsed=f"{elapsed:.1f}s", returncode=rc, job_done=True)
        else:
            if rc != 0:
                why = f"code retour {rc}"
            elif has_error:
                why = "erreur signalée dans la sortie QE"
            elif not job_done:
                why = "sortie sans « JOB DONE » (calcul incomplet)"
            else:
                why = "sortie absente"
            JOBS[job_id].update(status='error', progress=100,
                                message=f"{program} a échoué : {why}",
                                returncode=rc, job_done=job_done)
    except (OSError, subprocess.SubprocessError) as exc:
        if JOBS[job_id].get('status') != 'cancelled':
            JOBS[job_id].update(status='error', message=f"exception : {exc}")
    finally:
        JOBS[job_id].pop('proc', None)
        # Libère le slot job même en cas d'erreur — évite le deadlock du sémaphore
        _job_slots.release()


def _find_pp_py() -> Optional[Path]:
    """Script pp.py (regroupement save/ avant epw.x)."""
    here = REPO_ROOT / "bin" / "pp.py"
    if here.is_file():
        return here
    if QE_BIN_DIR:
        for rel in ("../EPW/bin/pp.py", "pp.py"):
            p = (QE_BIN_DIR / rel).resolve()
            if p.is_file():
                return p
    return None


@app.route('/api/run/epw_pp', methods=['POST'])
def api_run_epw_pp():
    """
    Lance pp.py dans le outdir QE (présence de _ph0/ et prefix.save).
    Entrée : { "workdir": "outputs/Nb", "prefix": "Nb" }
    """
    data = request.get_json(force=True, silent=True) or {}
    wd_rel = data.get('workdir') or ''
    workdir = _safe_path(str(wd_rel))
    if not workdir or not workdir.is_dir():
        return jsonify({'ok': False, 'error': 'workdir invalide ou absent'}), 400
    try:
        workdir.relative_to(OUTPUTS_DIR)
    except ValueError:
        _security_log(f"SECURITY: /api/run/epw_pp workdir hors outputs : {wd_rel!r}")
        return jsonify({'ok': False, 'error': 'workdir doit être sous outputs/'}), 403

    prefix = re.sub(r'[^\w.-]', '', str(data.get('prefix') or '').strip())
    if not prefix:
        return jsonify({'ok': False, 'error': 'prefix manquant ou invalide'}), 400

    pp = _find_pp_py()
    if not pp or not pp.is_file():
        return jsonify({
            'ok': False,
            'error': 'pp.py introuvable (supra-QE/bin/pp.py ou EPW/bin/pp.py)',
        }), 503

    ph0 = workdir / '_ph0'
    if not ph0.is_dir():
        return jsonify({
            'ok': False,
            'error': f"_ph0/ absent dans {wd_rel} — ph.x doit tourner avec cwd = outdir",
        }), 400

    try:
        proc = subprocess.run(
            [sys.executable, str(pp)],
            input=(prefix + '\n').encode('utf-8'),
            cwd=str(workdir),
            capture_output=True,
            timeout=600,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return jsonify({'ok': False, 'error': 'pp.py : délai dépassé (10 min)'}), 504
    except OSError as exc:
        return jsonify({'ok': False, 'error': f'pp.py : {exc}'}), 500

    save_dir = workdir / 'save'
    if proc.returncode != 0 or not save_dir.is_dir():
        err = (proc.stderr or proc.stdout or b'').decode('utf-8', errors='replace')[-2000:]
        return jsonify({
            'ok': False,
            'error': f"pp.py code {proc.returncode}" + (f" — {err.strip()}" if err.strip() else ''),
        }), 500

    return jsonify({'ok': True, 'save': str(save_dir.relative_to(REPO_ROOT))})


@app.route('/api/run', methods=['POST'])
def api_run():
    """
    Lance un binaire QE.
    Entrée :
      {
        "program":  "pw.x" | "ph.x" | "q2r.x" | "matdyn.x",
        "input":    "inputs/Nb/Nb.scf.in",  (chemin relatif au projet)
        "output":   "outputs/Nb/Nb.scf.out",
        "nprocs":   4,
        "nthreads": 1,
        "workdir":  "outputs/Nb"            (optionnel ; défaut : dossier de output)
      }
    """
    # Anti-DoS : sémaphore limite les jobs QE concurrents
    if not _job_slots.acquire(blocking=False):
        _security_log(f"SECURITY: /api/run saturé (max {_MAX_CONCURRENT_JOBS} jobs concurrents)")
        return jsonify({
            'ok': False,
            'error': (f"API occupée : max {_MAX_CONCURRENT_JOBS} job(s) QE en parallèle. "
                      f"Augmente SUPRA_MAX_CONCURRENT_JOBS ou réessaie dans quelques minutes."),
            'max_concurrent_jobs': _MAX_CONCURRENT_JOBS,
        }), 429

    slot_held = True
    try:
        if not QE_BIN_DIR:
            return jsonify({'ok': False, 'error': "Aucun binaire QE détecté"}), 503

        data = request.get_json(force=True, silent=True) or {}
        program = data.get('program')
        if program not in QE_PROGRAMS:
            return jsonify({'ok': False, 'error': f"programme inconnu : {program}"}), 400

        inp = _safe_path(data.get('input') or '')
        if not inp or not inp.is_file():
            return jsonify({'ok': False, 'error': "input introuvable"}), 404

        out_rel = data.get('output') or f"outputs/{inp.stem}.out"
        out = _safe_write_path(out_rel)  # anti-RCE : restreint aux dossiers d'écriture + whitelist
        if not out:
            _security_log(f"SECURITY: /api/run refusé (output path invalide : {out_rel!r})")
            return jsonify({'ok': False, 'error': "output invalide (hors zone d'écriture autorisée)"}), 403

        workdir_rel = data.get('workdir') or str(out.parent.relative_to(REPO_ROOT))
        workdir = _safe_path(workdir_rel) or out.parent
        workdir.mkdir(parents=True, exist_ok=True)

        nprocs = max(1, int(data.get('nprocs') or 1))
        nthreads = max(1, int(data.get('nthreads') or 1))
        append_output = bool(data.get('append_output'))

        job_id = _next_job_id()
        JOBS[job_id] = {
            'program': program,
            'input':   str(inp),
            'output':  str(out),
            'workdir': str(workdir),
            'nprocs':  nprocs,
            'nthreads': nthreads,
            'append_output': append_output,
            'status':  'queued',
            'progress': 0,
            'message': 'en attente',
            'start':   time.time(),
        }
        t = threading.Thread(target=_launch_in_background,
                             args=(job_id, program, inp, out, nprocs, nthreads, workdir),
                             daemon=True)
        t.start()
        slot_held = False  # Le thread va libérer le slot via finally
        return jsonify({'ok': True, 'job_id': job_id, 'message': 'lancé'})
    finally:
        if slot_held:
            # Slot non transmis au thread : erreur de validation → on libère ici
            _job_slots.release()


def _pids_holding_file(target: Path) -> List[int]:
    """Processus qui ont le .out ouvert en écriture (ph.x lancé en shell)."""
    if not target.is_file():
        return []
    try:
        resolved = target.resolve()
    except OSError:
        return []
    pids: List[int] = []
    proc_root = Path('/proc')
    if not proc_root.is_dir():
        return []
    for proc in proc_root.iterdir():
        if not proc.name.isdigit():
            continue
        pid = int(proc.name)
        fd_dir = proc / 'fd'
        if not fd_dir.is_dir():
            continue
        try:
            for fd in fd_dir.iterdir():
                try:
                    if os.readlink(fd) == str(resolved):
                        pids.append(pid)
                except OSError:
                    continue
        except OSError:
            continue
    return sorted(set(pids))


def _process_start_ms(pid: int) -> Optional[int]:
    """Heure de démarrage du processus (ms epoch) via /proc (indépendant de la locale)."""
    try:
        clk_tck = os.sysconf(os.sysconf_names['SC_CLK_TCK'])
        with open('/proc/uptime', 'r', encoding='utf-8') as fh:
            uptime_sec = float(fh.readline().split()[0])
        with open(f'/proc/{pid}/stat', 'r', encoding='utf-8') as fh:
            raw = fh.read()
        rp = raw.rfind(')')
        if rp < 0:
            return None
        parts = raw[rp + 2:].split()
        # Field 22 in proc(5) = starttime → index 19 after ") " (state is field 3).
        if len(parts) <= 19:
            return None
        starttime_ticks = int(parts[19])
        boot_epoch = time.time() - uptime_sec
        proc_epoch = boot_epoch + (starttime_ticks / float(clk_tck))
        return int(proc_epoch * 1000)
    except (OSError, ValueError, ZeroDivisionError):
        return None


def _earliest_start_ms(pids: Sequence[int]) -> Optional[int]:
    starts = [_process_start_ms(p) for p in pids]
    starts = [s for s in starts if s is not None]
    return min(starts) if starts else None


def _pids_for_qe_program(program: str) -> List[int]:
    """PIDs dont l'exécutable se termine par /pw.x, /ph.x, etc."""
    if program not in QE_PROGRAMS:
        return []
    base = program
    pids: List[int] = []
    proc_root = Path('/proc')
    if not proc_root.is_dir():
        return []
    for proc in proc_root.iterdir():
        if not proc.name.isdigit():
            continue
        pid = int(proc.name)
        exe_link = proc / 'exe'
        try:
            exe = os.readlink(exe_link)
        except OSError:
            continue
        if exe.endswith('/' + base) or os.path.basename(exe) == base:
            pids.append(pid)
    return sorted(set(pids))


def _job_ids_for_output(rel_out: str) -> List[str]:
    ids: List[str] = []
    for jid, job in JOBS.items():
        if job.get('status') not in ('queued', 'running'):
            continue
        out = job.get('output') or ''
        if rel_out in out or out.endswith(rel_out):
            ids.append(jid)
    return ids


@app.route('/api/qe/running', methods=['POST'])
def api_qe_running():
    """
    Détecte des calculs QE encore actifs (fichier .out ouvert ou binaire en cours).
    Entrée : { "outputs": ["outputs/Nb/classic/Nb.ph.out", ...],
               "programs": ["ph.x", "pw.x"] }  (programs optionnel)
    """
    data = request.get_json(force=True, silent=True) or {}
    outputs = data.get('outputs') or []
    programs = data.get('programs') or []
    if not isinstance(outputs, list):
        return jsonify({'ok': False, 'error': 'outputs doit être une liste'}), 400
    outputs = [str(p) for p in outputs[:48] if p]
    if isinstance(programs, str):
        programs = [programs]
    programs = [str(p) for p in programs[:16] if p]

    out_info: Dict[str, Any] = {}
    for rel in outputs:
        target = _safe_path(rel)
        entry: Dict[str, Any] = {
            'path': rel, 'alive': False, 'pids': [], 'job_ids': [],
            'started_at_ms': None,
        }
        if target and target.is_file():
            pids = _pids_holding_file(target)
            jobs = _job_ids_for_output(rel)
            entry['pids'] = pids
            entry['job_ids'] = jobs
            entry['alive'] = bool(pids or jobs)
            entry['started_at_ms'] = _earliest_start_ms(pids)
        out_info[rel] = entry

    prog_info: Dict[str, Any] = {}
    for prog in programs:
        if prog not in QE_PROGRAMS:
            continue
        pids = _pids_for_qe_program(prog)
        prog_info[prog] = {
            'pids': pids,
            'alive': bool(pids),
            'started_at_ms': _earliest_start_ms(pids),
        }

    return jsonify({'ok': True, 'outputs': out_info, 'programs': prog_info})


@app.route('/api/job/<job_id>', methods=['GET'])
def api_job(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        return jsonify({'ok': False, 'error': 'job inconnu'}), 404
    # On expose une vue simplifiée (pas de handles process / start)
    view = {k: v for k, v in job.items() if k not in ('start', 'proc')}
    view['ok'] = True
    return jsonify(view)


@app.route('/api/job/<job_id>/cancel', methods=['POST'])
def api_job_cancel(job_id: str):
    """Arrête un job queued/running (SIGTERM puis SIGKILL sur le groupe)."""
    job = JOBS.get(job_id)
    if not job:
        return jsonify({'ok': False, 'error': 'job inconnu'}), 404
    st = job.get('status')
    if st in ('completed', 'error', 'cancelled'):
        return jsonify({'ok': True, 'job_id': job_id, 'status': st,
                        'message': f'déjà terminé ({st})'})
    job['status'] = 'cancelled'
    job['message'] = 'annulation demandée'
    job['progress'] = 95
    pid = job.get('pid')
    killed = False
    if pid:
        try:
            os.killpg(pid, signal.SIGTERM)
            killed = True
        except (ProcessLookupError, PermissionError, OSError):
            try:
                os.kill(pid, signal.SIGTERM)
                killed = True
            except (ProcessLookupError, PermissionError, OSError):
                pass
        # Escalade rapide si le processus ignore SIGTERM
        if killed:
            def _escalate(p: int = pid) -> None:
                time.sleep(2.0)
                try:
                    os.killpg(p, signal.SIGKILL)
                except (ProcessLookupError, PermissionError, OSError):
                    try:
                        os.kill(p, signal.SIGKILL)
                    except (ProcessLookupError, PermissionError, OSError):
                        pass
            threading.Thread(target=_escalate, daemon=True).start()
    _security_log(f"SECURITY: /api/job/{job_id}/cancel (pid={pid})")
    return jsonify({'ok': True, 'job_id': job_id, 'status': 'cancelled',
                    'pid': pid, 'signal_sent': killed})


# ─────────────────────────────────────────────────────────────────────────────
#  Extraction des résultats supraconductivité (α²F, λ, ω_log, Tᶜ)
# ─────────────────────────────────────────────────────────────────────────────
def parse_matdyn_lambda(matdyn_out: str) -> Dict[str, Any]:
    """
    Parse l'output de matdyn.x avec electron_phonon='lambda' et extrait :
      - lambda total,
      - omega_log (Kelvin et cm⁻¹),
      - mu* utilisé,
      - éventuelle Tᶜ McMillan présente dans la sortie.
    """
    result: Dict[str, Any] = {'lambda': None, 'omega_log_K': None,
                              'omega_log_cmm1': None, 'mu_star': None,
                              'tc_mcmillan': None}

    # λ total : "lambda =   0.85"
    m = re.search(r'lambda\s*[:=]\s*([-+]?\d+\.\d+)', matdyn_out, re.I)
    if m:
        result['lambda'] = float(m.group(1))

    # ω_log : peut apparaitre comme "<log w> = 412.3 K"
    m = re.search(r'<\s*log\s*w\s*>\s*[:=]\s*([-+]?\d+\.\d+)\s*K', matdyn_out, re.I)
    if m:
        result['omega_log_K'] = float(m.group(1))
    m = re.search(r'<\s*log\s*w\s*>\s*[:=]\s*([-+]?\d+\.\d+)\s*cm-?1', matdyn_out, re.I)
    if m:
        result['omega_log_cmm1'] = float(m.group(1))
        if result['omega_log_K'] is None:
            result['omega_log_K'] = float(m.group(1)) * SR.K_PER_CM1

    # μ*
    m = re.search(r'mu\*?\s*[:=]\s*([-+]?\d+\.\d+)', matdyn_out, re.I)
    if m:
        result['mu_star'] = float(m.group(1))

    # Tc McMillan trouvée dans la sortie ?
    m = re.search(r'Tc\s*=\s*([-+]?\d+\.\d+)\s*K', matdyn_out, re.I)
    if m:
        result['tc_mcmillan'] = float(m.group(1))

    return result


_SCF_CLASSIFY_TAIL_BYTES = 8 * 1024 * 1024


def _read_text_tail(path: Path, max_bytes: int = _SCF_CLASSIFY_TAIL_BYTES) -> str:
    """Lit la fin d'un fichier texte (sorties SCF volumineuses)."""
    size = path.stat().st_size
    with open(path, 'rb') as fh:
        if size > max_bytes:
            fh.seek(-max_bytes, os.SEEK_END)
        return fh.read().decode('utf-8', errors='replace')


@app.route('/api/scf/classify', methods=['POST'])
def api_scf_classify():
    """
    Classe un matériau d'après la sortie SCF ``pw.x`` : métal (conducteur,
    on enchaîne) ou isolant (gap → arrêter phonons / EPW / Tc).

    Corps : ``{ "path": "outputs/<mat>/<wf>/<mat>.scf.out" }``.
    """
    data = request.get_json(force=True, silent=True) or {}
    rel = data.get('path') or ''
    target = _safe_path(rel)
    if not target or not target.is_file():
        if rel:
            _security_log(f"SECURITY: /api/scf/classify refusé ou absent (path={rel!r})")
        return jsonify({'ok': False, 'error': 'scf.out introuvable'}), 404
    try:
        text = _read_text_tail(target)
    except OSError as exc:
        return jsonify({'ok': False, 'error': str(exc)}), 500
    classified = classify_electronic_character(text)
    return jsonify({
        'ok': True,
        'path': str(target),
        **classified,
    })


@app.route('/api/results/tc', methods=['POST'])
def api_results_tc():
    """
    Entrée :
      {
        "matdyn_out": "outputs/Nb/Nb.matdyn.out",
        "mu_star":    0.10,
        "omega_log_override_K":  null      (optionnel)
      }
    """
    data = request.get_json(force=True, silent=True) or {}
    matdyn_path = _safe_path(data.get('matdyn_out') or '')
    if not matdyn_path or not matdyn_path.is_file():
        return jsonify({'ok': False, 'error': 'matdyn.out introuvable'}), 404
    txt = matdyn_path.read_text(encoding='utf-8', errors='replace')
    parsed = parse_matdyn_lambda(txt)

    mu_star = float(data.get('mu_star') if data.get('mu_star') is not None
                    else parsed.get('mu_star') or 0.10)
    omega_log = (data.get('omega_log_override_K') or parsed.get('omega_log_K'))

    tc_mc = tc_mcmillan(parsed['lambda'], omega_log, mu_star) if omega_log else None
    tc_ad = tc_allen_dynes(parsed['lambda'], omega_log, mu_star) if omega_log else None

    return jsonify({
        'ok': True,
        'parsed': parsed,
        'mu_star_used': mu_star,
        'omega_log_K_used': omega_log,
        'tc_mcmillan_K':    tc_mc,
        'tc_allen_dynes_K': tc_ad,
        'source': str(matdyn_path),
    })


# ─────────────────────────────────────────────────────────────────────────────
#  Extraction des résultats EPW (Wannier + Éliashberg)
# ─────────────────────────────────────────────────────────────────────────────


@app.route('/api/results/epw', methods=['POST'])
def api_results_epw():
    """
    Entrée :
      {
        "epw_out": "outputs/Nb/Nb.epw.out",
        "mu_star": 0.10            (utilisé comme fallback si absent du log)
      }
    """
    data = request.get_json(force=True, silent=True) or {}
    epw_path = _safe_path(data.get('epw_out') or '')
    if not epw_path or not epw_path.is_file():
        return jsonify({'ok': False, 'error': 'epw.out introuvable'}), 404

    try:
        text = epw_path.read_text(encoding='utf-8', errors='replace')
    except OSError as exc:
        return jsonify({'ok': False, 'error': str(exc)}), 500

    parsed = parse_epw_output(text)
    if not parsed.get('mu_c'):
        parsed['mu_c'] = float(data.get('mu_star') or 0.10)

    return jsonify({
        'ok':     True,
        'parsed': parsed,
        'source': str(epw_path),
    })


@app.route('/api/materials/list', methods=['GET'])
def api_materials_list():
    """Liste les matériaux disponibles dans supra-QE/inputs/ avec leurs fichiers."""
    items = []
    if INPUTS_DIR.is_dir():
        for mat_dir in sorted(INPUTS_DIR.iterdir()):
            if not mat_dir.is_dir():
                continue
            entry = {
                'name': mat_dir.name,
                'has_relax': False,
                'classic_files': [],
                'epw_files': [],
                'sscha_files': [],
                'extra_files': [],
            }
            for f in sorted(mat_dir.iterdir()):
                if f.is_file():
                    if f.suffix == '.out' and 'relax' in f.name.lower():
                        entry['has_relax'] = True
                    if f.suffix in ('.in', '.out', '.json'):
                        entry['extra_files'].append(f.name)
            for sub in ('classic', 'epw', 'sscha'):
                d = mat_dir / sub
                if d.is_dir():
                    entry[f'{sub}_files'] = sorted([
                        p.name for p in d.iterdir() if p.is_file()
                    ])
            items.append(entry)
    return jsonify({'ok': True, 'materials': items, 'inputs_dir': str(INPUTS_DIR)})


@app.route('/api/materials/search', methods=['POST'])
def api_materials_search():
    """Recherche un matériau par nom (insensible à la casse)."""
    data = request.get_json(force=True, silent=True) or {}
    query = (data.get('material') or '').strip().lower()
    if not query:
        return jsonify({'ok': False, 'error': 'material manquant'}), 400

    result = {
        'ok':        True,
        'query':     data.get('material'),
        'found':     False,
        'name':      None,
        'has_relax': False,
        'inputs_dir': None,
        'classic_files': [],
        'epw_files':     [],
        'sscha_files':   [],
        'top_files':     [],
    }

    if not INPUTS_DIR.is_dir():
        return jsonify(result)

    target = None
    for d in INPUTS_DIR.iterdir():
        if d.is_dir() and d.name.lower() == query:
            target = d
            break
    if target is None:
        for d in INPUTS_DIR.iterdir():
            if d.is_dir() and query in d.name.lower():
                target = d
                break

    if target is None:
        return jsonify(result)

    result['found']      = True
    result['name']       = target.name
    try:
        result['inputs_dir'] = str(target.relative_to(REPO_ROOT))
    except ValueError:
        # INPUTS_DIR hors dépôt : chemin logique UI
        result['inputs_dir'] = f"inputs/{target.name}"
    for f in sorted(target.iterdir()):
        if f.is_file():
            if f.suffix == '.out' and 'relax' in f.name.lower():
                result['has_relax'] = True
            if f.suffix in ('.in', '.out', '.json'):
                result['top_files'].append(f.name)
    for sub in ('classic', 'epw'):
        d = target / sub
        if d.is_dir():
            result[f'{sub}_files'] = sorted([p.name for p in d.iterdir() if p.is_file()])

    return jsonify(result)


@app.route('/api/results/compare', methods=['POST'])
def api_results_compare():
    """
    Renvoie les α²F(ω) Classique + EPW pour visualisation comparée.
    Entrée :
      { "material": "Nb" }
    Sortie :
      { "classic": {omega, a2f, lambda_w}, "epw": {omega, a2f, lambda_w} }
    """
    data = request.get_json(force=True, silent=True) or {}
    mat = (data.get('material') or '').strip()
    if not mat:
        return jsonify({'ok': False, 'error': 'material manquant'}), 400

    def _load(path: Path):
        if not path or not path.is_file():
            return None
        omega, a2f, lam = [], [], []
        for line in path.read_text(encoding='utf-8', errors='replace').splitlines():
            s = line.strip()
            if not s or s.startswith('#') or s.lower().startswith('lambda'):
                continue
            parts = s.split()
            try:
                w = float(parts[0])
                a = float(parts[1]) if len(parts) > 1 else 0.0
                l = float(parts[2]) if len(parts) > 2 else 0.0
            except ValueError:
                continue
            omega.append(w); a2f.append(a); lam.append(l)
        return {'omega': omega, 'a2f': a2f, 'lambda_w': lam, 'n_points': len(omega),
                'source': str(path.relative_to(REPO_ROOT))}

    def _first_existing(*paths: Path) -> Optional[Path]:
        for p in paths:
            if p and p.is_file():
                return p
        return None

    classic_path = _first_existing(
        OUTPUTS_DIR / mat / 'classic' / 'a2F.dat',
        OUTPUTS_DIR / mat / 'classic' / 'a2F_smooth.dat',
        INPUTS_DIR / mat / 'classic' / 'a2F.dat',
        INPUTS_DIR / mat / 'classic' / 'a2F_smooth.dat',
    )
    epw_path = _first_existing(
        OUTPUTS_DIR / mat / 'epw' / f'{mat}.a2f',
        OUTPUTS_DIR / mat / 'epw' / 'a2F.dat',
        INPUTS_DIR / mat / 'epw' / f'{mat}.a2f',
        INPUTS_DIR / mat / 'epw' / 'a2F.dat',
    )

    return jsonify({
        'ok':      True,
        'classic': _load(classic_path),
        'epw':     _load(epw_path),
    })


def _locate_bxsf(material: str, rel_hint: str = "") -> Optional[Path]:
    """Cherche un fichier .bxsf (surface de Fermi pour XCrySDen)."""
    if rel_hint:
        p = _safe_path(rel_hint)
        if p and p.is_file():
            return p
    mat = (material or "").strip()
    if not mat:
        return None
    search_dirs = [
        OUTPUTS_DIR / mat / "classic",
        OUTPUTS_DIR / mat / "epw",
        OUTPUTS_DIR / mat,
        INPUTS_DIR / mat / "classic",
        INPUTS_DIR / mat / "epw",
        INPUTS_DIR / mat,
    ]
    seen = set()
    for base in search_dirs:
        try:
            b = base.resolve()
        except OSError:
            continue
        if not b.is_dir() or b in seen:
            continue
        seen.add(b)
        for name in (f"{mat}.bxsf", f"{mat.lower()}.bxsf"):
            cand = b / name
            if cand.is_file():
                return cand
        for cand in sorted(b.glob("*.bxsf")):
            if cand.is_file():
                return cand
    return None


def _repo_rel_path(p: Path) -> str:
    try:
        return str(p.resolve().relative_to(REPO_ROOT.resolve()))
    except ValueError:
        return str(p)


@app.route('/api/viz/fermi-surface', methods=['POST'])
def api_viz_fermi_surface():
    """
    Ouvre la surface de Fermi dans XCrySDen (si installé sur la machine API),
    ou renvoie la commande / le chemin du .bxsf.
    """
    data = request.get_json(force=True, silent=True) or {}
    material = (data.get("material") or "").strip()
    rel_hint = (data.get("bxsf_path") or "").strip()
    target = _locate_bxsf(material, rel_hint)
    if not target:
        return jsonify({
            "ok": False,
            "error": "Fichier .bxsf introuvable. Lance fs.x après SCF + NSCF (grille k régulière).",
        }), 404

    abs_path = str(target.resolve())
    rel_path = _repo_rel_path(target)
    xc = shutil.which("xcrysden") or shutil.which("XCrySDen")
    cmd_parts = [xc or "xcrysden", "--bxsf", abs_path]
    command = " ".join(cmd_parts)

    launched = False
    launch_error = None
    if xc:
        env = os.environ.copy()
        if not env.get("DISPLAY"):
            env.setdefault("DISPLAY", ":0")
        try:
            subprocess.Popen(
                cmd_parts,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
                env=env,
            )
            launched = True
        except OSError as exc:
            launch_error = str(exc)

    return jsonify({
        "ok": True,
        "launched": launched,
        "bxsf_path": rel_path,
        "abs_path": abs_path,
        "command": command,
        "xcrysden": xc,
        "launch_error": launch_error,
        "message": (
            "XCrySDen lancé sur le serveur."
            if launched
            else "Copie la commande ou ouvre le .bxsf avec XCrySDen en local."
        ),
    })


@app.route('/api/results/alpha2F', methods=['POST'])
def api_results_alpha2f():
    """
    Renvoie les couples (ω, α²F(ω), λ(ω)) lus depuis le fichier a2F
    (nom typique : a2F.dat ou alpha2F.dat) écrit par matdyn.x / lambda.x.
    """
    data = request.get_json(force=True, silent=True) or {}
    a2f_path = _safe_path(data.get('a2f_file') or '')
    if not a2f_path or not a2f_path.is_file():
        return jsonify({'ok': False, 'error': 'fichier α²F introuvable'}), 404

    omega: List[float] = []
    a2f:   List[float] = []
    lam:   List[float] = []
    for line in a2f_path.read_text(encoding='utf-8', errors='replace').splitlines():
        s = line.strip()
        if not s or s.startswith('#') or s.lower().startswith('lambda'):
            continue
        parts = s.split()
        try:
            w = float(parts[0])
            a = float(parts[1]) if len(parts) > 1 else 0.0
            l = float(parts[2]) if len(parts) > 2 else 0.0
        except ValueError:
            continue
        omega.append(w); a2f.append(a); lam.append(l)

    return jsonify({
        'ok': True,
        'omega': omega,
        'a2f':   a2f,
        'lambda_w': lam,
        'n_points': len(omega),
        'source': str(a2f_path),
    })


@app.route('/api/results/explore', methods=['POST'])
def api_results_explore():
    """
    Exploration complète de la chaîne de calcul pour un matériau : inventorie
    tous les fichiers de sortie des deux voies, en extrait les grandeurs
    supraconductrices et les courbes traçables, et construit le tableau de
    synthèse comparatif.

    Entrée :
      {
        "material":  "Nb",
        "mu_stars":  [0.10, 0.12, 0.14]      (optionnel)
      }

    Sortie :
      {
        "ok": true, "material": "Nb", "mu_stars": [...],
        "classic": { inventory, scalars, provenance, curves, tc_table, notes },
        "epw":     { … idem … },
        "synthesis": { rows, tc_rows, available, n_files }
      }
    """
    data = request.get_json(force=True, silent=True) or {}
    mat = (data.get('material') or '').strip()
    if not mat or '/' in mat or '\\' in mat or mat.startswith('.'):
        return jsonify({'ok': False, 'error': 'material invalide ou manquant'}), 400

    mu_raw = data.get('mu_stars')
    mu_stars = SR.DEFAULT_MU_STARS
    if isinstance(mu_raw, list) and mu_raw:
        try:
            mu_stars = [float(m) for m in mu_raw][:12]
        except (TypeError, ValueError):
            return jsonify({'ok': False, 'error': 'mu_stars invalide'}), 400

    try:
        payload = SR.explore_results(mat, INPUTS_DIR, OUTPUTS_DIR, REPO_ROOT, mu_stars)
    except OSError as exc:
        return jsonify({'ok': False, 'error': f'lecture impossible : {exc}'}), 500
    return jsonify(payload)


# ─────────────────────────────────────────────────────────────────────────────
#  Endpoint utilitaire : structures relaxées détectées dans Interface-QE_v1
# ─────────────────────────────────────────────────────────────────────────────
@app.route('/api/relaxed/list', methods=['GET'])
def api_list_relaxed():
    """
    Liste les matériaux pour lesquels un *vc-relax.out* (ou *relax.out*)
    terminé est présent dans ``supra-QE/inputs/<materiau>/`` (zone d'upload
    de l'interface autonome).
    """
    base = INPUTS_DIR
    found: List[Dict[str, str]] = []
    if base.is_dir():
        for sub in sorted(p for p in base.iterdir() if p.is_dir()):
            for fname in ('vc-relax.out', 'relax.out', 'vcrelax.out'):
                cand = next(sub.glob(f"*{fname}"), None)
                if cand and 'JOB DONE' in cand.read_text(encoding='utf-8', errors='ignore')[-4000:]:
                    found.append({
                        'material': sub.name,
                        'relax_out': str(cand.relative_to(REPO_ROOT)),
                        'dir': str(sub.relative_to(REPO_ROOT)),
                    })
                    break
    return jsonify({'ok': True, 'count': len(found), 'items': found,
                    'base_dir': str(base.relative_to(REPO_ROOT))})


# ─────────────────────────────────────────────────────────────────────────────
#  Upload d'une structure relaxée (vc-relax.out) — autonomie de Supra-QE
# ─────────────────────────────────────────────────────────────────────────────
@app.route('/api/relaxed/upload', methods=['POST'])
def api_relaxed_upload():
    """
    Reçoit le contenu d'un fichier *vc-relax.out* (texte), le stocke dans
    ``inputs/<material>/<material>.vc-relax.out`` et extrait la dernière
    structure (CELL_PARAMETERS + ATOMIC_POSITIONS + alat + ATOMIC_SPECIES).

    Entrée :
      { "material": "Nb", "content": "<contenu vc-relax.out>" }
    """
    data = request.get_json(force=True, silent=True) or {}
    material = (data.get('material') or '').strip()
    content = data.get('content') or ''
    if not material or not re.match(r'^[A-Za-z0-9_\-]+$', material):
        return jsonify({'ok': False, 'error': 'nom de matériau invalide'}), 400
    if not content.strip():
        return jsonify({'ok': False, 'error': 'fichier vide'}), 400
    if 'JOB DONE' not in content[-6000:]:
        return jsonify({'ok': False,
                        'error': "Le fichier ne contient pas 'JOB DONE' : vc-relax non terminé."}), 400

    mdir = INPUTS_DIR / material
    mdir.mkdir(parents=True, exist_ok=True)
    target = mdir / f"{material}.vc-relax.out"
    target.write_text(content, encoding='utf-8')

    struct = _extract_final_structure(content)
    if struct:
        (mdir / f"{material}.structure.json").write_text(
            json.dumps(struct, indent=2, ensure_ascii=False), encoding='utf-8')

    return jsonify({
        'ok': True,
        'material': material,
        'saved': str(target.relative_to(REPO_ROOT)),
        'structure': struct,
    })


def _extract_final_structure(text: str) -> Optional[Dict[str, Any]]:
    """
    Extrait alat, vecteurs de maille (CELL_PARAMETERS) et ATOMIC_POSITIONS
    depuis le bloc « Begin final coordinates » ou les dernières occurrences.
    """
    res: Dict[str, Any] = {}

    # Recherche du dernier bloc 'Begin final coordinates' (vc-relax)
    idx = text.rfind('Begin final coordinates')
    block = text[idx:] if idx >= 0 else text

    # CELL_PARAMETERS
    m_cell = list(re.finditer(
        r'CELL_PARAMETERS\s*\(?\s*(\w+)?[^)\n]*\)?\s*\n'
        r'\s*([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s*\n'
        r'\s*([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s*\n'
        r'\s*([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s+([-+\d.eEdD]+)',
        block))
    if not m_cell:
        m_cell = list(re.finditer(
            r'CELL_PARAMETERS\s*\(?\s*(\w+)?[^)\n]*\)?\s*\n'
            r'\s*([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s*\n'
            r'\s*([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s*\n'
            r'\s*([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s+([-+\d.eEdD]+)',
            text))
    if m_cell:
        m = m_cell[-1]
        unit = m.group(1) or 'alat'
        rows = [
            [float(m.group(i).replace('d', 'e').replace('D', 'E')) for i in (2, 3, 4)],
            [float(m.group(i).replace('d', 'e').replace('D', 'E')) for i in (5, 6, 7)],
            [float(m.group(i).replace('d', 'e').replace('D', 'E')) for i in (8, 9, 10)],
        ]
        res['cell_parameters'] = rows
        res['cell_unit'] = unit
        m_alat = re.search(r'alat\s*=\s*([\d.+\-eEdD]+)', m.group(0), re.I)
        if m_alat:
            res['alat'] = float(m_alat.group(1).replace('d', 'e').replace('D', 'E'))

    # ATOMIC_POSITIONS
    m_pos = list(re.finditer(
        r'ATOMIC_POSITIONS\s*\(?\s*(\w+)\s*\)?\s*\n((?:\s*[A-Za-z]{1,3}\s+[-+\d.eEdD]+\s+[-+\d.eEdD]+\s+[-+\d.eEdD]+(?:\s+\d\s+\d\s+\d)?\s*\n?)+)',
        block))
    if not m_pos:
        m_pos = list(re.finditer(
            r'ATOMIC_POSITIONS\s*\(?\s*(\w+)\s*\)?\s*\n((?:\s*[A-Za-z]{1,3}\s+[-+\d.eEdD]+\s+[-+\d.eEdD]+\s+[-+\d.eEdD]+(?:\s+\d\s+\d\s+\d)?\s*\n?)+)',
            text))
    if m_pos:
        m = m_pos[-1]
        res['positions_unit'] = m.group(1)
        positions = []
        for line in m.group(2).strip().splitlines():
            parts = line.split()
            if len(parts) >= 4:
                positions.append({
                    'sym': parts[0],
                    'x': float(parts[1].replace('d', 'e').replace('D', 'E')),
                    'y': float(parts[2].replace('d', 'e').replace('D', 'E')),
                    'z': float(parts[3].replace('d', 'e').replace('D', 'E')),
                })
        res['positions'] = positions
        res['nat'] = len(positions)

    # ATOMIC_SPECIES (pseudos + masses)
    m_sp = re.search(
        r'ATOMIC_SPECIES\s*\n((?:\s*[A-Za-z]{1,3}\s+[\d.]+\s+[\w.\-+]+\s*\n?)+)',
        text)
    if m_sp:
        species = []
        for line in m_sp.group(1).strip().splitlines():
            parts = line.split()
            if len(parts) >= 3:
                species.append({'symbol': parts[0],
                                'mass': float(parts[1]),
                                'pseudo': parts[2]})
        res['species'] = species
        res['ntyp'] = len(species)

    # ibrav et ecutwfc/ecutrho remontés depuis l'output
    for key, pat in (('ibrav',   r'bravais-lattice index\s*=\s*(\d+)'),
                     ('ecutwfc', r'kinetic-energy cutoff\s*=\s*([\d.]+)\s*Ry'),
                     ('ecutrho', r'charge density cutoff\s*=\s*([\d.]+)\s*Ry')):
        m = re.search(pat, text, re.I)
        if m:
            res[key] = float(m.group(1)) if '.' in m.group(1) else int(m.group(1))

    return res or None


# ─────────────────────────────────────────────────────────────────────────────
#  Upload d'un pseudopotentiel
# ─────────────────────────────────────────────────────────────────────────────
@app.route('/api/pseudo/upload', methods=['POST'])
def api_pseudo_upload():
    """
    Stocke un fichier pseudo (.upf) dans ``pseudos/``.
    Entrée : { "name": "Nb.upf", "content": "<contenu UPF>" }
    """
    data = request.get_json(force=True, silent=True) or {}
    name = (data.get('name') or '').strip()
    content = data.get('content') or ''
    if not re.match(r'^[\w.\-+]+\.(upf|UPF)$', name):
        return jsonify({'ok': False, 'error': "nom invalide (attendu *.upf)"}), 400
    if not content.strip():
        return jsonify({'ok': False, 'error': 'contenu vide'}), 400
    target = PSEUDOS_DIR / name
    target.write_text(content, encoding='utf-8')
    kind = detect_pseudo_kind(target)
    return jsonify({
        'ok': True,
        'name': name,
        'kind': kind,
        'path': str(target.relative_to(REPO_ROOT)),
        'warning': "Pseudopotentiel non Norm-Conserving — incompatible avec ph.x." if kind in ('USPP', 'PAW') else None,
    })


@app.route('/api/pseudo/list', methods=['GET'])
def api_pseudo_list():
    """Liste les pseudos disponibles dans ``pseudos/`` avec leur type."""
    items = []
    if PSEUDOS_DIR.is_dir():
        for p in sorted(PSEUDOS_DIR.iterdir()):
            if p.is_file() and p.suffix.lower() == '.upf':
                items.append({'name': p.name, 'kind': detect_pseudo_kind(p)})
    return jsonify({'ok': True, 'pseudo_dir': str(PSEUDOS_DIR), 'items': items})


# ─────────────────────────────────────────────────────────────────────────────
#  Lancement
# ─────────────────────────────────────────────────────────────────────────────
def _resolve_listen_host(host: str) -> str:
    """
    Écoute réseau : 0.0.0.0/:: exige SUPRA_ALLOW_LAN=1 **et** SUPRA_API_TOKEN
    (sinon repli 127.0.0.1). Localhost inchangé.
    """
    if host not in ("0.0.0.0", "::"):
        return host
    if not _ALLOW_LAN:
        print("[supra-qe] ⚠️  HOST=0.0.0.0 sans SUPRA_ALLOW_LAN=1 — "
              "écoute réseau refusée (sécurité). Utilise 127.0.0.1 "
              "ou exporte SUPRA_ALLOW_LAN=1 + SUPRA_API_TOKEN.")
        return "127.0.0.1"
    if not _API_TOKEN:
        print("[supra-qe] ⚠️  LAN refusé sans SUPRA_API_TOKEN — "
              "n’importe qui sur le réseau pourrait /api/run. "
              "Définis SUPRA_API_TOKEN (en-tête X-Supra-Token) "
              "ou reste en 127.0.0.1.")
        return "127.0.0.1"
    return host


def main() -> None:
    port = int(os.environ.get('SUPRA_QE_PORT', '8765'))
    host = _resolve_listen_host(os.environ.get('SUPRA_QE_HOST', '127.0.0.1'))
    print(f"[supra-qe] interface : http://{host}:{port}/interface")
    print(f"[supra-qe] API root  : http://{host}:{port}/")
    print(f"[supra-qe] QE bin    : {QE_BIN_DIR}")
    print(f"[supra-qe] pseudos   : {PSEUDOS_DIR}")
    print(f"[supra-qe] inputs    : {INPUTS_DIR}")
    print(f"[supra-qe] outputs   : {OUTPUTS_DIR}")
    print(f"[supra-qe] CORS      : {_CORS_ORIGINS}")
    if host in ("0.0.0.0", "::") and _API_TOKEN:
        print("[supra-qe] LAN + token API actifs (X-Supra-Token requis).")
    app.run(host=host, port=port, threaded=True, debug=False)


if __name__ == '__main__':
    main()

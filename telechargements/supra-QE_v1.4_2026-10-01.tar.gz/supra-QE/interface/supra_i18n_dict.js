/* =========================================================================
 *  supra_i18n_dict.js — dictionnaire Français → Anglais
 *
 *  `phrases` : nœud de texte complet (espaces normalisés) → anglais.
 *  `blocks`  : innerHTML complet d'un élément feuille → anglais avec balises.
 *  `rules`   : messages assemblés à l'exécution.
 *
 *  Les termes identiques dans les deux langues (noms de programmes QE,
 *  mots-clés Fortran, unités, URL) sont volontairement absents : ils sont
 *  laissés tels quels.
 *
 *  Pour repérer ce qui manque, passer l'interface en anglais et exécuter
 *  dans la console : SupraI18n.missing()
 * ========================================================================= */

window.SUPRA_I18N = {

    /* ── Messages assemblés dynamiquement ────────────────────────────────── */
    rules: [
        // « SCF métallique (pw.x) » : nom d'étape suivi de son programme
        { re: /^(.+) \((pw\.x|ph\.x|q2r\.x|matdyn\.x|epw\.x|alpha2f\.x|pp\.py|python)\)$/,
          en: (m, t) => t(m[1]) + ' (' + m[2] + ')' },
        { re: /^Vérification de l'enchaînement — (.+)$/, en: (m, t) => 'Chain verification — ' + t(m[1]) },
        { re: /^Littérature — (.+)$/, en: (m) => 'Literature — ' + m[1] },
        { re: /^Aucune fiche pour « .+ ». La base locale compte (\d+) matériaux \(éléments et composés\) — tableau ci-dessous\.$/,
          en: (m) => 'No entry for this name. The local database has ' + m[1] + ' materials (elements and compounds) — table below.' },
        { re: /^Base littérature — (\d+) matériaux$/,
          en: (m) => 'Literature database — ' + m[1] + ' materials' },
        { re: /^Attend : (.+)$/, en: (m, t) => 'Waiting for: ' + t(m[1]) },
        { re: /^Prochaine étape : (.+?)\.?$/, en: (m, t) => 'Next step: ' + t(m[1]) + '.' },
        { re: /^étape (\S+) — (.+)$/, en: (m, t) => 'step ' + m[1] + ' — ' + t(m[2]) },
        { re: /^(\d+[a-z]?) — (.+)$/, en: (m, t) => m[1] + ' — ' + t(m[2]) },
        { re: /^étape (.+)$/, en: (m, t) => 'step ' + t(m[1]) },
        { re: /^Étape (\d+[a-z]?)$/, en: (m) => 'Step ' + m[1] },
        { re: /^(.+) — pipeline$/, en: (m, t) => t(m[1]) + ' — pipeline' },
        { re: /^(\d+) étapes$/, en: (m) => m[1] + ' steps' },
        { re: /^(\d+) programme\(s\)$/, en: (m) => m[1] + ' program(s)' },
        { re: /^À lancer dans l'ordre — (.+)$/, en: (m, t) => 'Run in order — ' + t(m[1]) },
        { re: /^Ouvrir l'étape (.+)$/, en: (m, t) => 'Open step ' + t(m[1]) },
        { re: /^Programmes — (.+)$/, en: (m, t) => 'Programs — ' + t(m[1]) },
        { re: /^« (.+) » — choisis un workflow$/, en: (m) => '“' + m[1] + '” — choose a workflow' },
        { re: /^« (.+) » — (.+)$/, en: (m, t) => '“' + m[1] + '” — ' + t(m[2]) },
        { re: /^Matériau « (.+) » validé$/, en: (m) => 'Material “' + m[1] + '” validated' },
        { re: /^(\d+) espèce\(s\), (\d+) atome\(s\)$/, en: (m) => m[1] + ' species, ' + m[2] + ' atom(s)' },
        { re: /^vc-relax : (.+)$/, en: (m, t) => 'vc-relax: ' + t(m[1]) },
        { re: /^scf de contrôle : (.+)$/, en: (m, t) => 'sanity-check scf: ' + t(m[1]) },
        { re: /^résultats (.+)$/, en: (m, t) => t(m[1]) + ' results' },
        { re: /^Ratio k\/q \[(.+)\] :$/, en: (m, t) => 'k/q ratio [' + t(m[1]) + ']:' },
        // Libellé précédé d'une icône : on traduit ce qui suit l'icône. Si la
        // suite est inconnue du dictionnaire, le texte reste inchangé.
        { re: /^([^\w\s]{1,3})\s+(\S.*)$/u, en: (m, t) => m[1] + ' ' + t(m[2]) },
    ],

    /* ── Paragraphes entiers (meilleure qualité que fragment par fragment) ─ */
    blocks: {
        /* Gates Calculs / Résultats */
        "🔒 <strong>Prochaine étape</strong> — valide le matériau ci-dessus pour débloquer le flux Calculs : <ol> <li><strong>1b · Pseudopotentiels</strong> — fichiers Norm-Conserving du matériau</li> <li><strong>Étape 2 · Choix du workflow</strong> — WF1 Classique ou WF2 EPW</li> <li><strong>Étape 3 · Paramètres, chaîne de calculs et lancement</strong></li> </ol>":
            "🔒 <strong>Next step</strong> — validate the material above to unlock the Calculations flow: <ol> <li><strong>1b · Pseudopotentials</strong> — Norm-Conserving files for the material</li> <li><strong>Step 2 · Workflow choice</strong> — WF1 Classic or WF2 EPW</li> <li><strong>Step 3 · Parameters, calculation chain and launch</strong></li> </ol>",
        "📊 <strong>Mode Résultats</strong> — valide d’abord un <strong>matériau</strong> (étape 1) pour explorer T<sub>c</sub>, λ, α²F(ω) et les fichiers dans <code>outputs/&lt;matériau&gt;/classic/</code> et <code>…/epw/</code>.":
            "📊 <strong>Results mode</strong> — first validate a <strong>material</strong> (step 1) to explore T<sub>c</sub>, λ, α²F(ω) and the files in <code>outputs/&lt;material&gt;/classic/</code> and <code>…/epw/</code>.",
        "Température critique T<sub>c</sub> — deux voies : <strong>WF1 Classique</strong> et <strong>WF2 EPW</strong>.":
            "Critical temperature T<sub>c</sub> — two routes: <strong>WF1 Classic</strong> and <strong>WF2 EPW</strong>.",
        "<strong>Calculs</strong> — suivre le parcours : matériau, pseudos, workflow, puis la chaîne de la voie choisie.":
            "<strong>Calculations</strong> — follow the path: material, pseudos, workflow, then the chain of the chosen route.",
        "<strong>Résultats</strong> — lecture des deux voies du matériau, sans relancer la chaîne.":
            "<strong>Results</strong> — read both routes of the material, without rerunning the chain.",

        /* Guide d'utilisation — feuilles (innerHTML normalisé) */
        "Guide — calcul de T<sub>c</sub> avec Supra-QE":
            "Guide — computing T<sub>c</sub> with Supra-QE",

        "Interface pour le couplage électron–phonon (Quantum ESPRESSO) : voie classique (McMillan / Allen–Dynes) et voie EPW (équations d’Éliashberg). Ouvrir exclusivement via l’API (<code>./DEMARRER.sh</code>), jamais en <code>file://</code>.":
            "Interface for electron–phonon coupling (Quantum ESPRESSO): classic route (McMillan / Allen–Dynes) and EPW route (Éliashberg equations). Open exclusively via the API (<code>./DEMARRER.sh</code>), never as <code>file://</code>.",
        "Interface pour le couplage électron–phonon (Quantum ESPRESSO) : voie classique (McMillan / Allen–Dynes) et voie EPW (Éliashberg ou α²F LSDA en spin collinéaire). Binaires attendus : <strong>EPW 6.1</strong> dans <code>supra-QE/bin/</code>. Ouvrir via l’API (<code>./DEMARRER.sh</code>), jamais en <code>file://</code>.":
            "Interface for electron–phonon coupling (Quantum ESPRESSO): classic route (McMillan / Allen–Dynes) and EPW route (Éliashberg or collinear-spin LSDA α²F). Expected binaries: <strong>EPW 6.1</strong> in <code>supra-QE/bin/</code>. Open via the API (<code>./DEMARRER.sh</code>), never as <code>file://</code>.",

        "<code>./configurer.sh</code> (une fois), puis <code>./DEMARRER.sh</code>. Interface : <code>http://127.0.0.1:8765/interface/</code>. Arrêt / statut : <code>./ARRETER.sh</code>, <code>./STATUT.sh</code>.":
            "<code>./configurer.sh</code> (once), then <code>./DEMARRER.sh</code>. UI: <code>http://127.0.0.1:8765/interface/</code>. Stop / status: <code>./ARRETER.sh</code>, <code>./STATUT.sh</code>.",

        "Associer l’installation QE au projet (évite de recompiler) : <code>./scripts/associer_binaires_qe.sh /chemin/vers/qe/bin</code>. L’absence d’<code>epw.x</code> est signalée au choix du workflow.":
            "Link the QE install to the project (avoids recompiling): <code>./scripts/associer_binaires_qe.sh /path/to/qe/bin</code>. Missing <code>epw.x</code> is reported when choosing the workflow.",

        "Sur la machine de calcul : <code>SUPRA_QE_HOST=0.0.0.0</code>, <code>SUPRA_ALLOW_LAN=1</code> et <code>SUPRA_API_TOKEN</code> dans <code>config.env</code>. Documentation : <code>docs/AUTRE_PC.md</code>.":
            "On the compute host: set <code>SUPRA_QE_HOST=0.0.0.0</code>, <code>SUPRA_ALLOW_LAN=1</code> and <code>SUPRA_API_TOKEN</code> in <code>config.env</code>. Documentation: <code>docs/AUTRE_PC.md</code>.",

        "Valider le matériau, puis fournir des <strong>.UPF Norm-Conserving</strong> (PseudoDojo / SG15 / ONCV). Les USPP et PAW sont exclus du couplage e–p.":
            "Validate the material, then provide <strong>Norm-Conserving .UPF</strong> files (PseudoDojo / SG15 / ONCV). USPP and PAW are excluded from e–ph coupling.",

        "Placer <code>&lt;matériau&gt;.vc-relax.out</code> dans <code>inputs/&lt;matériau&gt;/</code>, puis vérifier les prérequis. Le SCF est <strong>partagé</strong> entre les deux voies : un <code>scf.out</code> terminé d’une voie est repris par l’autre.":
            "Place <code>&lt;material&gt;.vc-relax.out</code> in <code>inputs/&lt;material&gt;/</code>, then check prerequisites. The SCF is <strong>shared</strong> between both routes: a finished <code>scf.out</code> from one route is reused by the other.",

        "Grandeurs : α²F(ω), λ, ω<sub>log</sub>, ⟨ω²⟩½, T<sub>c</sub>(μ*).":
            "Quantities: α²F(ω), λ, ω<sub>log</sub>, ⟨ω²⟩½, T<sub>c</sub>(μ*).",

        "Après ph.x : regrouper <code>save/</code> avec <code>pp.py</code> si nécessaire. Sorties : T<sub>c</sub>, Δ(T), anisotropie.":
            "After ph.x: gather <code>save/</code> with <code>pp.py</code> if needed. Outputs: T<sub>c</sub>, Δ(T), anisotropy.",

        "Grilles k/q à ratio entier (k ≫ q), μ* (voie classique), fenêtres EPW. Générer les inputs, lancer l’étape ou le workflow complet. Le panneau d’enchaînement suit le marqueur <code>JOB DONE</code>. Après le SCF : si le matériau n’est <strong>pas métallique</strong> (pas de surface de Fermi), la chaîne e–p / T<sup>c</sup> s’arrête.":
            "k/q grids with integer ratio (k ≫ q), μ* (classic route), EPW windows. Generate inputs, run a step or the full workflow. The chain panel follows the <code>JOB DONE</code> marker. After SCF: if the material is <strong>not metallic</strong> (no Fermi surface), the e–ph / T<sup>c</sup> chain stops.",

        "Onglet Résultats (matériau en tête, les deux voies) : le <strong>journal</strong> se charge tout seul — fiche technique (chaîne, états à E<sub>F</sub>, catalogue). Boutons <strong>Ouvrir HTML</strong> / <strong>Ouvrir PDF</strong> en plus de l’affichage. Surface de Fermi 3D : <code>fs.x</code> → <code>.bxsf</code> → <strong>XCrySDen</strong> (<code>xcrysden --bxsf</code>), pas un graphe interne. Exports CSV / LaTeX / rapport dans Synthèse.":
            "Results tab (material first, both routes): the <strong>notebook</strong> loads on its own — data sheet (chain, states at E<sub>F</sub>, catalogue). <strong>Open HTML</strong> / <strong>Open PDF</strong> in addition to the on-screen view. 3D Fermi surface: generated <code>.fs.in</code>, then <code>fs.x</code> after NSCF → <code>.bxsf</code> → <strong>XCrySDen</strong>; UI can run <code>fs.x</code> at end of chain. CSV / LaTeX / report exports in Summary.",

        "Jusqu’à T<sub>c</sub> complète. Goulot d’étranglement typique : <code>ph.x</code> (WF1), puis <code>epw.x</code> (WF2). Grilles de référence : SCF&nbsp;8³, NSCF&nbsp;24³, q&nbsp;4³.":
            "Through full T<sub>c</sub>. Typical bottleneck: <code>ph.x</code> (WF1), then <code>epw.x</code> (WF2). Reference grids: SCF&nbsp;8³, NSCF&nbsp;24³, q&nbsp;4³.",

        "Sur un i9-14900K (64&nbsp;Go+) : viser <code>nprocs ≈ 16–24</code> ; surveiller la mémoire durant <code>ph.x</code> / EPW. Valider d’abord WF1 ; n’ouvrir EPW que si λ et ω<sub>log</sub> sont stables. Test rapide non publiable : <code>nq = 2³</code>. Annulation : bouton « Annuler le calcul ».":
            "On an i9-14900K (64&nbsp;GB+): aim for <code>nprocs ≈ 16–24</code>; watch memory during <code>ph.x</code> / EPW. Validate WF1 first; open EPW only once λ and ω<sub>log</sub> are stable. Quick non-publishable test: <code>nq = 2³</code>. Cancel: « Cancel calculation » button.",

        "Interface : déplier / replier les sections ; langue FR/EN et thème clair/sombre dans l’en-tête. Formules, règles (métal, SCF partagé, XCrySDen) : onglet Aide.":
            "UI: expand / collapse sections; FR/EN language and light/dark theme in the header. Formulas and rules (metal, shared SCF, XCrySDen): Help tab.",

        "<strong>API hors ligne</strong> — lance <code>./DEMARRER.sh</code> (ou corrige l’URL dans <strong>Chemins</strong>), puis réessaie.":
            "<strong>API offline</strong> — run <code>./DEMARRER.sh</code> (or fix the URL in <strong>Paths</strong>), then retry.",

        "Saisis le matériau et valide. Ensuite : <strong>pseudos (1b)</strong>, choix du workflow, puis <strong>vc-relax</strong> dans le dossier matériau.":
            "Enter the material and confirm. Next: <strong>pseudos (1b)</strong>, choose a workflow, then <strong>vc-relax</strong> in the material folder.",

        "<strong>Métal obligatoire :</strong> après le SCF, un gap ≳ 0,15 eV (isolant) arrête nscf / phonons / EPW / Tᶜ — pas de surface de Fermi, pas de paires de Cooper.":
            "<strong>Metal required:</strong> after SCF, a gap ≳ 0.15 eV (insulator) stops nscf / phonons / EPW / Tᶜ — no Fermi surface, no Cooper pairs.",

        "<strong>SCF partagé :</strong> un <code>scf.out</code> <code>JOB DONE</code> d’une voie est repris par l’autre. L’input SCF utilisateur n’est pas réécrit.":
            "<strong>Shared SCF:</strong> a <code>JOB DONE</code> <code>scf.out</code> from one route is reused by the other. The user SCF input is not rewritten.",

        "<strong>μ* = 0.10 par défaut</strong> — modifiable (0.10–0.16). Tᶜ recalculée pour une série de μ* dans le journal.":
            "<strong>μ* = 0.10 by default</strong> — editable (0.10–0.16). Tᶜ is recomputed for a μ* sweep in the notebook.",

        "<strong>Surface de Fermi 3D :</strong> <code>fs.x</code> → <code>.bxsf</code> → <strong>XCrySDen</strong> (<code>xcrysden --bxsf</code>). L’histogramme E−E<sub>F</sub> est une analyse d’occupation, pas la géométrie.":
            "<strong>3D Fermi surface:</strong> <code>&lt;mat&gt;.fs.in</code> is generated with other inputs; <code>fs.x</code> after NSCF → <code>.bxsf</code> → <strong>XCrySDen</strong>. Not a T<sub>c</sub> chain step; the UI may run <code>fs.x</code> when calculations finish. The E−E<sub>F</sub> histogram is occupation, not 3D geometry.",
        "<strong>Surface de Fermi 3D :</strong> <code>&lt;mat&gt;.fs.in</code> est généré avec les inputs ; <code>fs.x</code> après NSCF produit <code>.bxsf</code> → <strong>XCrySDen</strong>. Ce n’est pas une étape de la chaîne T<sub>c</sub> ; l’UI peut lancer <code>fs.x</code> à la fin des calculs. L’histogramme E−E<sub>F</sub> est une occupation, pas la géométrie 3D.":
            "<strong>3D Fermi surface:</strong> <code>&lt;mat&gt;.fs.in</code> is generated with inputs; <code>fs.x</code> after NSCF → <code>.bxsf</code> → <strong>XCrySDen</strong>. Not a T<sub>c</sub> chain step; the UI can run <code>fs.x</code> at end of calculations. The E−E<sub>F</sub> histogram is occupation, not 3D geometry.",

        "<strong>Fiche technique :</strong> le journal s’affiche à l’écran ; <strong>Ouvrir HTML</strong> / <strong>Ouvrir PDF</strong> ouvrent la même fiche à part (CSV / LaTeX / rapport dans Synthèse).":
            "<strong>Data sheet:</strong> the notebook stays on screen; <strong>Open HTML</strong> / <strong>Open PDF</strong> open the same sheet separately (CSV / LaTeX / report in Summary).",

        "<strong>SCF</strong> : densité électronique convergée avec smearing métallique. Si isolant (gap ≳ 0,15 eV) : arrêt — pas de paires de Cooper.":
            "<strong>SCF</strong>: converged electronic density with metallic smearing. If insulating (gap ≳ 0.15 eV): stop — no Cooper pairs.",

        "<strong>matdyn.x</strong> : α²F(ω), λ, ω_log, Tᶜ McMillan / Allen–Dynes (onglet Résultats).":
            "<strong>matdyn.x</strong>: α²F(ω), λ, ω_log, McMillan / Allen–Dynes Tᶜ (Results tab).",

        "<strong>fs.x</strong> (optionnel) : export <code>.bxsf</code> pour <strong>XCrySDen</strong>.":
            "<strong>fs.x</strong> (after NSCF, optional): generated <code>.fs.in</code>, exports <code>.bxsf</code> for <strong>XCrySDen</strong> (Results → Anisotropy).",

        "<strong>SCF</strong> : le même que la voie classique (densité reprise si déjà <code>JOB DONE</code>).":
            "<strong>SCF</strong>: the same as the classic route (density reused if already <code>JOB DONE</code>).",

        "<strong>ph.x</strong> : juste après le SCF, <code>fildvscf</code> sauvegardé (sans <code>electron_phonon=interpolated</code>).":
            "<strong>ph.x</strong>: right after SCF, <code>fildvscf</code> saved (without <code>electron_phonon=interpolated</code>).",

        "<strong>save/</strong> : regrouper <code>.dyn</code> / <code>.dvscf</code> avec <code>pp.py</code> avant <code>epw.x</code>.":
            "<strong>save/</strong>: gather <code>.dyn</code> / <code>.dvscf</code> with <code>pp.py</code> before <code>epw.x</code>.",

        "<strong>NSCF coarse + nbnd</strong> : <em>après</em> <code>ph.x</code>, grille k modeste, beaucoup de bandes (Wannier).":
            "<strong>Coarse NSCF + nbnd</strong>: <em>after</em> <code>ph.x</code>, modest k-grid, many bands (Wannier).",

        "<strong>epw.x</strong> : wannierisation + interpolation + Éliashberg → Tᶜ et gap Δ.":
            "<strong>epw.x</strong>: Wannierisation + interpolation + Éliashberg → Tᶜ and gap Δ.",

        "Ouvre la fiche dans un nouvel onglet (en plus de l'affichage)":
            "Opens the sheet in a new tab (in addition to the on-screen view)",
        "Ouvre la fiche et propose l'enregistrement PDF":
            "Opens the sheet and offers Save as PDF",

        /* 1b — consigne dossier pseudos/ (panneau de liaison retiré) */
        "<strong>Fichiers :</strong> avant les calculs, mettre à jour le dossier <code>pseudos/</code> de Supra-QE avec les pseudos recommandés ; les inputs générés (paramètres optimisés) contiennent déjà le chemin des pseudos — le nom doit correspondre à <code>ATOMIC_SPECIES</code> dans vos <code>.in</code>.":
            "<strong>Files:</strong> before running calculations, update the Supra-QE <code>pseudos/</code> folder with the recommended pseudopotentials; the generated inputs (optimized parameters) already contain the pseudopotential paths — names must match <code>ATOMIC_SPECIES</code> in your <code>.in</code> files.",

        /* Verrou de lancement — géométrie commune WF1 / WF2 */
        "⏳ Structure introuvable : place l'input <strong>scf</strong> (issu du vc-relax) ou la sortie <strong>vc-relax.out</strong> dans <code>inputs/&lt;matériau&gt;/</code>.":
            "⏳ Crystal structure not found: place the <strong>scf</strong> input (relaxed geometry) or <strong>vc-relax.out</strong> in <code>inputs/&lt;material&gt;/</code>.",
        "Géométrie de référence — tous les calculateurs": "Reference geometry — all solvers",
        "Structure cristalline introuvable": "Crystal structure not found",
        "Fichier requis (convention QE)": "Required file (QE convention)",
        "Alternative": "Fallback",
        "Namelists": "Namelists",
        "Cartes": "Cards",
        "Héritage": "Inherited",
        "Arrêter — ce n'est pas un conducteur": "Stop — this is not a conductor",
        "SCF métallique — conducteur": "Metallic SCF — conductor",
        "Caractère": "Character",
        "Gap": "Gap",
        "Seuil d'arrêt": "Stop threshold",
        "isolant / semi-conducteur": "insulator / semiconductor",
        "Pas de gap électronique.": "No electronic gap.",
        "on peut enchaîner nscf / phonons / EPW.": "nscf / phonons / EPW can proceed.",
    },

    /* ── Phrases et libellés ─────────────────────────────────────────────── */
    phrases: {

        /* En-tête et navigation */
        "🧊 Supra-QE — Propriétés Supraconductrices": "🧊 Supra-QE — Superconducting Properties",
        "Littérature": "Literature",
        "Tc exp.": "Tc exp.",
        "JSON pour IA": "JSON for AI",
        "CSV littérature": "Literature CSV",
        "Copier le contexte IA": "Copy AI context",
        "e–ph": "e–ph",
        "hors e–ph": "beyond e–ph",
        "non SC": "not SC",
        "Famille": "Family",
        "Modèle": "Model",
        "Réf.": "Ref.",
        "Hors modèle e–ph conventionnel de Supra-QE.": "Outside the conventional e–ph model of Supra-QE.",
        "Tc à pression ambiante, sauf mention contraire. λ, ω_log et 2Δ/k_B Tc sont des valeurs de revue (chaleur spécifique ou effet tunnel), pas une constante unique. Cette base n’est pas le fichier SuperCon du NIMS.":
            "Ambient-pressure Tc unless noted. λ, ω_log and 2Δ/k_B Tc are review values (specific heat or tunneling), not a single constant. This is not the NIMS SuperCon file.",
        "Couplage faible, proche de la limite BCS.": "Weak coupling, close to the BCS limit.",
        "Couplage fort.": "Strong coupling.",
        "Prototype du couplage fort. ω_log ≈ 4,8 meV.": "Strong-coupling prototype. ω_log ≈ 4.8 meV.",
        "λ de revue : selon l’inversion, souvent entre 0,8 et 1,2.": "Review λ: depending on the inversion, often between 0.8 and 1.2.",
        "Deux gaps. Un seul λ ne résume pas le couplage σ/π.": "Two gaps. A single λ does not summarize the σ/π coupling.",
        "Phase A15.": "A15 phase.",
        "Phase A15, record historique avant les cuprates.": "A15 phase, the historical record before the cuprates.",
        "Sensible à la stœchiométrie et à la phase.": "Sensitive to stoichiometry and phase.",
        "Dichalcogénure, anisotropie forte.": "Dichalcogenide, strong anisotropy.",
        "Hydrure sous très haute pression, pas à l’ambiante.": "Hydride under very high pressure, not ambient.",
        "Cuprate. La Tc n’est pas celle de McMillan / Éliashberg conventionnel de cette interface.":
            "Cuprate. This Tc is not the conventional McMillan / Éliashberg Tc of this interface.",
        "La phase dépend de la structure (fcc / dhcp).": "The phase depends on the structure (fcc / dhcp).",
        "La colonne Littérature / Tc exp. vient de la base locale, pas du calcul.":
            "The Literature / Tc exp. column comes from the local database, not from the calculation.",
        "version 1.1": "version 1.1",
        "version 1.4": "version 1.4",
        "v1.4": "v1.4",
        "magnétique & non magnétique": "magnetic & non-magnetic",
        "Version applicative Supra-QE": "Supra-QE application version",
        "Non magnétique, spin collinéaire, non collinéaire, SOC": "Non-magnetic, collinear, non-collinear, SOC",
        "Magnétisme (v1.4)": "Magnetism (v1.4)",
        "Non magnétique (nspin = 1)": "Non-magnetic (nspin = 1)",
        "Spin collinéaire (nspin = 2)": "Collinear spin (nspin = 2)",
        "Non collinéaire (nspin = 4)": "Non-collinear (nspin = 4)",
        "Spin-orbite (lspinorb + nspin = 4)": "Spin-orbit (lspinorb + nspin = 4)",
        "starting_magnetization (par espèce, ordre ATOMIC_SPECIES)": "starting_magnetization (per species, ATOMIC_SPECIES order)",
        "Spin collinéaire (nspin=2) — SCF, NSCF, ph.x alignés.": "Collinear spin (nspin=2) — aligned on SCF, NSCF, ph.x.",
        "Non collinéaire (nspin=4) — grilles et pseudos adaptés.": "Non-collinear (nspin=4) — adapt grids and pseudopotentials.",
        "Spin-orbite (lspinorb) — pseudos FR ; EPW à valider au cas par cas.": "Spin-orbit (lspinorb) — FR pseudos; validate EPW case by case.",
        "Valeurs starting_magnetization : une par espèce atomique (ordre ATOMIC_SPECIES).":
            "starting_magnetization values: one per atomic species (ATOMIC_SPECIES order).",
        "🧊 Supra-QE — WF1 Classique · WF2 EPW": "🧊 Supra-QE — WF1 Classic · WF2 EPW",
        "Matériau →": "Material →",
        "WF1 Classique · WF2 EPW": "WF1 Classic · WF2 EPW",
        "WF1 Classique": "WF1 Classic",
        "WF2 EPW": "WF2 EPW",
        "Matériau → WF1 Classique · WF2 EPW (binaires EPW 6.1) → Calculs / Résultats / Aide":
            "Material → WF1 Classic · WF2 EPW (EPW 6.1 binaries) → Calculations / Results / Help",
        "Spin : non magnétique · collinéaire · non collinéaire · SOC — clés sur SCF/NSCF ; WF2 collinéaire → α²F LSDA":
            "Spin: non-magnetic · collinear · non-collinear · SOC — keys on SCF/NSCF; WF2 collinear → LSDA α²F",
        "Interface v3 · 2 workflows · barre d'outils unifiée": "Interface v3 · 2 workflows · unified toolbar",
        "Oran, Algérie": "Oran, Algeria",
        "Auteur": "Author",
        "Langue / Language": "Language",
        "Thème / Theme": "Theme",
        "☀ Clair": "☀ Light",
        "🌙 Sombre": "🌙 Dark",
        "Mode clair / Light": "Light mode",
        "Mode sombre / Dark": "Dark mode",
        "API hors ligne": "API offline",
        "↻ Réessayer": "↻ Retry",
        "1 · Matériau": "1 · Material",
        "1b · Pseudos": "1b · Pseudos",
        "2 · Workflow": "2 · Workflow",
        "3 · Chaîne": "3 · Chain",
        "Résultats": "Results",
        "Parcours du calcul": "Calculation path",
        "Matériau": "Material",
        "Workflow": "Workflow",
        "en ligne": "online",
        "hors ligne": "offline",
        "QE incomplet": "QE incomplete",
        "Vérification de l’API…": "Checking the API…",
        "État de la session": "Session status",
        "Exemples : Nb · MgB2 · H3S · Pb": "Examples: Nb · MgB2 · H3S · Pb",
        "Saisis le matériau et valide. Ensuite :": "Enter the material and confirm. Next:",
        "choix du workflow, puis": "choose a workflow, then",
        "dans le dossier matériau.": "in the material folder.",
        "🧮 Calculs": "🧮 Calculations",
        "📊 Résultats": "📊 Results",
        "❓ Aide": "❓ Help",
        "📖 Guide": "📖 Guide",
        "Calculs": "Calculations",
        "Résultats": "Results",
        "Aide": "Help",
        "Sections": "Sections",
        "📂 Tout déplier": "📂 Expand all",
        "📁 Tout replier": "📁 Collapse all",
        "▼ Déplier": "▼ Expand",
        "▲ Replier": "▲ Collapse",
        "Navigation principale": "Main navigation",
        "Sections du flux": "Workflow sections",
        "Sections d'aide": "Help sections",
        "Guide d'utilisation": "User guide",
        "↻ API": "↻ API",
        "API…": "API…",
        "Vérifier l'API": "Check the API",
        "📁 Chemins": "📁 Paths",
        "Chemins projet": "Project paths",
        "Mode Calculs": "Calculation mode",
        "— valide le matériau, configure les pseudos (1b), choisis un workflow, puis lance les calculs.":
            "— validate the material, set up the pseudopotentials (1b), pick a workflow, then run the calculations.",

        /* Guide d'utilisation */
        "Passer aux Calculs": "Go to Calculations",
        "Passer aux Résultats": "Go to Results",
        "Appliquer & tester": "Apply & test",
        "1. Mise en service": "1. Getting started",
        "2. Protocole de calcul": "2. Calculation protocol",
        "3. Ordres de grandeur — temps wall-clock": "3. Orders of magnitude — wall-clock time",
        "Poste local": "Local workstation",
        "Binaires QE et EPW": "QE and EPW binaries",
        "Accès distant (LAN)": "Remote access (LAN)",
        "Matériau et pseudopotentiels": "Material and pseudopotentials",
        "Prérequis structural": "Structural prerequisite",
        "Chaînes WF1 et WF2": "WF1 and WF2 chains",
        "Paramètres et exécution": "Parameters and execution",
        "Exploitation des résultats": "Results analysis",
        "WF1 — classique": "WF1 — classic",
        "WF2 — EPW": "WF2 — EPW",
        "Complexité": "Complexity",
        "Exemple": "Example",
        "Labo (8–16 cœurs)": "Lab (8–16 cores)",
        "Poste fort (ex. 14900K, 64 Go+)": "Strong workstation (e.g. 14900K, 64 GB+)",
        "Très simple": "Very simple",
        "Simple": "Simple",
        "Moyen": "Medium",
        "Complexe": "Complex",
        "Nb, Al (1 at.)": "Nb, Al (1 at.)",
        "Pb, Ta": "Pb, Ta",
        "Binaire 2–4 at.": "Binary 2–4 at.",
        "8–20 at.": "8–20 at.",
        "WF1 2–8 h · WF2 8–24 h": "WF1 2–8 h · WF2 8–24 h",
        "WF1 1–4 h · WF2 4–12 h": "WF1 1–4 h · WF2 4–12 h",
        "WF1 0,5–2 j · WF2 1–4 j": "WF1 0.5–2 d · WF2 1–4 d",
        "WF1 4–12 h · WF2 1–2 j": "WF1 4–12 h · WF2 1–2 d",
        "WF1 1–4 j · WF2 3–10 j": "WF1 1–4 d · WF2 3–10 d",
        "WF1 0,5–2 j · WF2 2–5 j": "WF1 0.5–2 d · WF2 2–5 d",
        "1–3 sem. · EPW ≫": "1–3 wk · EPW ≫",
        "plusieurs j – 1–2 sem.": "several d – 1–2 wk",
        "Résultats": "Results",
        "Aide": "Help",
        "Valider le choix du matériau": "Validate the material",
        "Vérifier les prérequis": "Check prerequisites",
        "Générer les inputs": "Generate the inputs",
        "Lancer tout le workflow": "Run the whole workflow",
        "Vérification de l’enchaînement": "Chain verification",
        "🔎 Explorer tous les résultats": "🔎 Explore all results",
        "Journal": "Notebook",
        "Ouvrir HTML": "Open HTML",
        "Ouvrir PDF": "Open PDF",
        "Ouvre la fiche dans un nouvel onglet (en plus de l'affichage)":
            "Opens the sheet in a new tab (in addition to the on-screen view)",
        "Ouvre la fiche et propose l'enregistrement PDF":
            "Opens the sheet and offers Save as PDF",
        "Fiche technique — résultats, remarques et courbes": "Technical sheet — results, remarks and curves",
        "WF1 Classique": "WF1 Classic",
        "WF2 EPW": "WF2 EPW",
        "Synthèse & scalaires": "Summary & scalars",
        "Spectres 2D": "2D spectra",
        "Surface de Fermi & anisotropie": "Fermi surface & anisotropy",
        "Fichiers bruts": "Raw files",
        "Prochaine étape": "Next step",
        "Mode Résultats": "Results mode",
        "valide d’abord un": "first validate a",
        "matériau": "material",
        "(étape 1)": "(step 1)",
        "pour explorer Tc, λ, α²F(ω) et les fichiers dans":
            "to explore Tc, λ, α²F(ω) and the files in",
        "valide le matériau ci-dessus pour débloquer le flux Calculs :":
            "validate the material above to unlock the Calculations flow:",

        /* (anciennes clés guide — conservées pour fragments dynamiques) */
        "Démarrer": "Start up",
        "Onglet Calculs — Étape 1": "Calculations tab — Step 1",
        "Étape 1b — Pseudopotentiels": "Step 1b — Pseudopotentials",
        "Étape 2 — Workflow": "Step 2 — Workflow",
        "Onglet Résultats": "Results tab",
        "Onglet Aide": "Help tab",
        "Astuce :": "Tip:",
        "Lire résultats": "Read results",
        "tout le workflow": "the whole workflow",
        "Vérification de l'enchaînement": "Chain verification",
        "Vérifier l'API": "Check the API",
        "Paramètres & lancement": "Parameters & launch",
        "Générer les inputs de ce workflow": "Generate this workflow’s inputs",
        "/": "/",

        /* Étape 1 — matériau */
        "Étape 1": "Step 1",
        "Étape 1 — Choix du matériau": "Step 1 — Material choice",
        "Choisir le Matériau": "Choose the material",
        "Ex : Nb, MgB2, H3S, Pb…": "e.g. Nb, MgB2, H3S, Pb…",
        "Entre un nom puis clique « Valider le choix du matériau »":
            "Type a name then click “Validate the material”",
        "Saisis le matériau et valide ton choix. Configure ensuite les":
            "Enter the material and validate your choice. Then set up the",
        "pseudopotentiels (étape 1b)": "pseudopotentials (step 1b)",
        ", puis choisis un workflow — la sortie": ", then pick a workflow — the",
        "se place dans le dossier matériau (ou un chemin externe).":
            "output goes into the material folder (or an external path).",
        "🔒 La suite du flux est masquée tant que le matériau n'est pas validé — c'est pour cela que cette page paraît vide. Clique sur":
            "🔒 The rest of the workflow stays hidden until the material is validated — that is why this page looks empty. Click",
        "« ✅ Valider le choix du matériau »": "“✅ Validate the material”",
        "ci-dessus pour faire apparaître :": "above to reveal:",
        "1b · Pseudopotentiels": "1b · Pseudopotentials",
        "— fichiers Norm-Conserving du matériau": "— Norm-Conserving files for the material",
        "Étape 2 · Choix du workflow": "Step 2 · Workflow choice",
        "— WF1 Classique ou WF2 EPW": "— WF1 Classic or WF2 EPW",
        "Étape 3 · Paramètres, chaîne de calculs et lancement":
            "Step 3 · Parameters, calculation chain and launch",

        /* Pseudopotentiels */
        "Pseudopotentiels": "Pseudopotentials",
        "Norm-Conserving obligatoire · communs aux workflows Classique et EPW":
            "Norm-Conserving required · shared by the Classic and EPW workflows",
        "🔒 Pseudopotentiels :": "🔒 Pseudopotentials:",
        "Norm-Conserving uniquement (PseudoDojo, SG15, ONCV).": "Norm-Conserving only (PseudoDojo, SG15, ONCV).",
        "et le couplage électron–phonon refusent USPP et PAW.": "and electron–phonon coupling reject USPP and PAW.",
        "Type obligatoire :": "Required type:",
        ": Norm-Conserving (NC)": ": Norm-Conserving (NC)",
        "Norm-Conserving (NC)": "Norm-Conserving (NC)",
        "ou les importer ci-dessous ; le nom doit correspondre à": "or import them below; the name must match",
        "Lie chaque élément à son fichier": "Link each element to its",
        ".UPF Norm-Conserving": "Norm-Conserving .UPF file",
        "📚 Recommandations pour le choix des pseudos": "📚 Recommendations for choosing pseudopotentials",
        "Sources fiables :": "Reliable sources:",
        "Bibliothèques de pseudos NC": "NC pseudopotential libraries",
        ", SG15, ONCV — une seule famille pour tous les éléments du matériau.":
            ", SG15, ONCV — a single family for every element of the material.",
        "Fonctionnelle :": "Functional:",
        "rester cohérent (ex. PBE partout) entre vc-relax, scf, phonons et EPW.":
            "keep it consistent (e.g. PBE everywhere) across vc-relax, scf, phonons and EPW.",
        "Semi-cœur :": "Semi-core:",
        "préférer les versions": "prefer the",
        "/ fully relativistic pour les métaux de transition (Nb, Pb…).":
            "/ fully relativistic versions for transition metals (Nb, Pb…).",
        "ecutwfc :": "ecutwfc:",
        "respecter la suggestion du pseudo (souvent 60–80 Ry pour métaux ; plus élevé pour O, F, H…).":
            "follow the suggestion shipped with the pseudopotential (often 60–80 Ry for metals; higher for O, F, H…).",
        "Élément": "Element",
        "Pseudo": "Pseudo",
        "Action": "Action",
        "Importer .upf": "Import .upf",
        "Dossier pseudos": "Pseudopotentials folder",
        "🔬 Pseudos Norm-Conserving —": "🔬 Norm-Conserving pseudos —",
        "Fichiers cherchés (prefix = nom du matériau) :": "Files searched for (prefix = material name):",

        /* Prérequis vc-relax */
        "① Prérequis": "① Prerequisites",
        "Prérequis calculs": "Calculation prerequisites",
        "Prérequis — structure relaxée (vc-relax)": "Prerequisites — relaxed structure (vc-relax)",
        "⚠️ La relaxation se fait en dehors de Supra-QE": "⚠️ Relaxation is done outside Supra-QE",
        "Dossier des prérequis (vc-relax requis · scf optionnel)":
            "Prerequisites folder (vc-relax required · scf optional)",
        "Dossier matériau (sortie vc-relax) : voir section": "Material folder (vc-relax output): see section",
        "Indiquer le chemin du répertoire où se trouve déjà ton calcul vc-relax":
            "Give the path of the directory that already holds your vc-relax run",
        "Trois façons de fournir ces sorties :": "Three ways to provide these outputs:",
        "Copier les sorties dans le dossier matériau Supra-QE :": "Copy the outputs into the Supra-QE material folder:",
        "(même prefix) dans le dossier matériau Supra-QE — les noms de fichiers restent identiques":
            "(same prefix) into the Supra-QE material folder — file names stay the same",
        "tout le répertoire de travail QE": "the whole QE working directory",
        "📤 Importer vc-relax.out dans ce dossier": "📤 Import vc-relax.out into this folder",
        "🔍 Vérifier les prérequis": "🔍 Check prerequisites",
        "vc-relax : ?": "vc-relax: ?",
        "scf : ?": "scf: ?",
        "vc-relax requis": "vc-relax required",
        "1 · vc-relax (requis)": "1 · vc-relax (required)",
        "2 · scf (contrôle)": "2 · scf (sanity check)",
        "✓ Prêt workflow": "✓ Workflow ready",
        "(requis),": "(required),",
        "(contrôle)": "(check)",
        "· fournit ibrav, celldm et les positions atomiques": "· provides ibrav, celldm and the atomic positions",
        "et les positions atomiques réutilisés dans tous les inputs générés.":
            "and the atomic positions reused in every generated input.",
        "Un seul fichier est": "Only one file is",
        "indispensable": "indispensable",
        ": la sortie": ": the",
        "Première étape des": "First step of the",
        "workflows. Elle crée": "workflows. It creates the",
        "dans le dossier du workflow : sans elle, le NSCF et": "in the workflow folder: without it the NSCF and",
        "ne trouvent pas la densité électronique. Les cutoffs sont repris du":
            "cannot find the electron density. Cutoffs are taken from the",
        "validé — ne les baisse pas en dessous.": "validated run — do not go below them.",
        ". C'est le seul fichier obligatoire ; un": ". It is the only mandatory file; an",
        "Calcul externe": "External calculation",
        "Manuelle": "Manual",
        "Automatique": "Automatic",

        /* Étape 2 — workflows */
        "Étape 2": "Step 2",
        "Étape 2 — Workflow": "Step 2 — Workflow",
        "Choix du workflow": "Workflow choice",
        "Workflow Classique": "Classic workflow",
        "Workflow Classique (WF1)": "Classic workflow (WF1)",
        "Workflow EPW": "EPW workflow",
        "Workflow EPW (WF2)": "EPW workflow (WF2)",
        "WF2 EPW": "WF2 EPW",
        "· Wannier · Éliashberg · Tᶜ + Δ": "· Wannier · Éliashberg · Tᶜ + Δ",
        "· McMillan / Allen-Dynes · μ*": "· McMillan / Allen-Dynes · μ*",
        "ph.x + e-p": "ph.x + e-p",
        "matdyn → Tᶜ": "matdyn → Tᶜ",
        "grilles fines": "fine grids",
        "aniso / iso": "aniso / iso",
        "👆 Choisis": "👆 Pick",
        "ou": "or",
        ".": ".",
        "⚠️ WF3": "⚠️ WF3",
        "— inputs générés ; lancement automatique SSCHA via l'API en cours d'intégration.":
            "— inputs are generated; automatic SSCHA launching through the API is being integrated.",

        /* Étape 3 — paramètres, chaîne, lancement */
        "Paramètres & lancement": "Parameters & launch",
        "Programmes du workflow": "Workflow programs",
        "Paramètres selon le workflow (WF1 classique · WF2 EPW).":
            "Parameters depending on the workflow (WF1 classic · WF2 EPW).",
        "Paramètres clés": "Key parameters",
        "Générer les inputs de ce workflow": "Generate the inputs of this workflow",
        "Lancer tout le workflow": "Run the whole workflow",
        "Enchaînement des calculs —": "Calculation chain —",
        "Chaque lancement est tracé ici avec sa vérification : une étape ne démarre que si l'amont est terminé (":
            "Every launch is logged here with its verification: a step only starts once the previous one is finished (",
        ") et que ses fichiers intermédiaires existent. Les lancements se font depuis les cartes d'étapes ci-dessus (bouton 🚀 Lancer).":
            ") and its intermediate files exist. Launching happens from the step cards above (🚀 Run button).",
        "Journal d'exécution & vérifications": "Execution log & verifications",
        "Chaîne amont": "Upstream chain",
        "Chaîne Tᶜ": "Tᶜ chain",
        "en attente": "waiting",
        "à vérifier": "to be checked",
        "Fichiers .in du workflow actif — prévisualisation et édition.":
            "The .in files of the active workflow — preview and edit.",
        "Inputs générés": "Generated inputs",
        "Fichiers :": "Files:",
        "Structure introuvable : place l'input": "Structure not found: put the",
        "(issu du vc-relax) ou la sortie": "(relaxed geometry) or",
        ", puis revalide le matériau.": ", then re-validate the material.",
        "Structure requise : input scf (issu du vc-relax) ou vc-relax.out dans inputs/<matériau>/.":
            "Geometry required: scf input (relaxed) or vc-relax.out in inputs/<material>/.",
        "Géométrie requise : inputs/<matériau>/<matériau>.scf.in (ou vc-relax.out).":
            "Geometry required: inputs/<material>/<material>.scf.in (or vc-relax.out).",
        "Première étape — SCF sur la géométrie relaxée (fichier utilisateur).":
            "First step — SCF on the relaxed geometry (user file).",
        "SCF manquant": "SCF missing",
        "Sortie": "Output",
        "Copier": "Copy",
        "Valide d'abord le": "First validate the",
        "(section ①) avant de générer ou lancer le workflow.": "(section ①) before generating or running the workflow.",
        "(étape 1) pour lire les fichiers de sortie.": "(step 1) to read the output files.",
        "matériau": "material",
        "workflow": "workflow",
        "— vérifie, sauvegarde, puis lance.": "— checks, saves, then runs.",
        "— utilisé par vc-relax, scf, phonons et EPW.": "— used by vc-relax, scf, phonons and EPW.",

        /* Chemins */
        "Chemins inputs / outputs": "Input / output paths",
        "Dossier workflow (.in)": "Workflow folder (.in)",
        "Dossier outputs (.out)": "Outputs folder (.out)",
        "💾 Appliquer les chemins": "💾 Apply the paths",

        /* Grilles k/q */
        "Grille K (SCF)": "K grid (SCF)",
        "Grille K (NSCF dense)": "K grid (dense NSCF)",
        "Grille K (NSCF EPW)": "K grid (EPW NSCF)",
        "Grille K (forces)": "K grid (forces)",
        "Grille Q (phonons)": "Q grid (phonons)",
        "Grille q (phonons)": "q grid (phonons)",
        "🔊 Grille Q (phonons, commune)": "🔊 Q grid (phonons, shared)",
        "Grille k (NSCF)": "k grid (NSCF)",
        "Grilles d'interpolation": "Interpolation grids",
        "Grilles k vs q :": "k vs q grids:",
        "🌐 Grilles fines (interpolation Wannier)": "🌐 Fine grids (Wannier interpolation)",
        "Grilles fines (interpolation Wannier)": "Fine grids (Wannier interpolation)",
        "Convergence grilles fines": "Fine-grid convergence",
        "Une seule grille q (partagée) — le ratio k_NSCF/q doit être entier sur chaque axe. Mode classique :":
            "A single (shared) q grid — the k_NSCF/q ratio must be an integer along each axis. Classic mode:",
        "ratio entier ≥ 2 (≥ 4 conseillé en classique).": "integer ratio ≥ 2 (≥ 4 advised in classic mode).",
        "Ratio k/q [Classique] :": "k/q ratio [Classic]:",
        "Ratio k/q [EPW] :": "k/q ratio [EPW]:",
        "Très dense (ex. 24 × 24 × 24)": "Very dense (e.g. 24 × 24 × 24)",
        "Standard / coarse (ex. 8 × 8 × 8)": "Standard / coarse (e.g. 8 × 8 × 8)",
        "Moyenne (ex. 4 × 4 × 4)": "Medium (e.g. 4 × 4 × 4)",
        "Coarse (ex. 4 × 4 × 4) — même que NSCF EPW typiquement":
            "Coarse (e.g. 4 × 4 × 4) — typically the same as the EPW NSCF",
        "k très dense (16³–32³),": "very dense k (16³–32³),",
        "k modeste (6³ ou 8³),": "modest k (6³ or 8³),",
        "(16³–32³) : surface de Fermi +": "(16³–32³): Fermi surface +",
        "Interpolation Wannier sur grille géante (40³)": "Wannier interpolation on a huge grid (40³)",
        "nkf (K fine)": "nkf (fine K)",
        "nqf (Q fine)": "nqf (fine Q)",

        /* Paramètres SCF / NSCF / phonons */
        "Seuil convergence (Ry)": "Convergence threshold (Ry)",
        "Smearing (métal)": "Smearing (metal)",
        "mv — Marzari-Vanderbilt (recommandé)": "mv — Marzari-Vanderbilt (recommended)",
        "mp — Methfessel-Paxton": "mp — Methfessel-Paxton",
        "fd — Fermi-Dirac": "fd — Fermi-Dirac",
        "🎚️ Surface de Fermi & smearing": "🎚️ Fermi surface & smearing",
        "Surface de Fermi & smearing": "Fermi surface & smearing",
        "Itérations max": "Max iterations",
        "nbnd (obligatoire)": "nbnd (required)",
        "nbnd (auto)": "nbnd (auto)",
        "Élevé obligatoire": "High, mandatory",
        "élevé pour Wannier.": "high for Wannier.",
        "(pour Wannier)": "(for Wannier)",
        "Obligatoire": "Mandatory",
        "beaucoup de bandes (Wannier).": "many bands (Wannier).",
        ": grille k modeste, beaucoup de bandes (Wannier).": ": modest k grid, many bands (Wannier).",
        "μ* (Coulomb)": "μ* (Coulomb)",
        "μ* (post-traitement Tᶜ)": "μ* (Tᶜ post-processing)",
        "💡 μ* = 0.10 par défaut": "💡 μ* = 0.10 by default",
        "μ* = 0.10 par défaut": "μ* = 0.10 by default",
        "— modifiable (0.10–0.16).": "— adjustable (0.10–0.16).",
        "— standard littérature. alpha2f.x est optionnel : matdyn.x produit déjà α²F(ω) et Tᶜ.":
            "— the literature standard. alpha2f.x is optional: matdyn.x already produces α²F(ω) and Tᶜ.",
        "electron_phonon (classique)": "electron_phonon (classic)",
        "fildvscf (classique)": "fildvscf (classic)",
        "fildyn (classique)": "fildyn (classic)",
        "flfrc (q2r)": "flfrc (q2r)",
        "alpha2f smearing": "alpha2f smearing",
        "(optionnel) : lissage de α²F(ω) pour de plus beaux tracés.":
            "(optional): α²F(ω) smoothing for nicer plots.",
        "+ alpha2f.x optionnel": "+ optional alpha2f.x",
        "Température (K)": "Temperature (K)",
        "T_max (K)": "T_max (K)",
        "pour T": "for T",
        "Iso / Aniso": "Iso / Aniso",
        "(iso/aniso)": "(iso/aniso)",
        "Éliashberg anisotrope / FBW": "Anisotropic Éliashberg / FBW",
        "🪟 Fenêtres de Wannier (eV, EF=0)": "🪟 Wannier windows (eV, EF=0)",
        "Fenêtres de Wannier (eV, EF=0)": "Wannier windows (eV, EF=0)",
        "fenêtres": "windows",
        "Projections (auto ou Nb:d;O:p)": "Projections (auto or Nb:d;O:p)",
        "Auto : orbitales selon l’élément (Nb → d, O → p), pas sp3d2.":
            "Auto: valence orbitals by element (Nb → d, O → p), not sp3d2.",
        ", projections": ", projections",
        "Supercellule (nx×ny×nz)": "Supercell (nx×ny×nz)",
        "Nombre de configurations": "Number of configurations",
        "Amplitude déplacement (Å)": "Displacement amplitude (Å)",
        "Graine aléatoire": "Random seed",
        "ΔE phonon (cm⁻¹)": "Phonon ΔE (cm⁻¹)",
        "conv_thr (SCF)": "conv_thr (SCF)",
        "conv_thr (forces)": "conv_thr (forces)",
        "Calcul SCF + forces (": "SCF + forces calculation (",
        ") sur toutes les configs générées.": ") on every generated configuration.",

        /* Parallélisation */
        "⚡ Parallélisation": "⚡ Parallelisation",
        "🔢 MPI :": "🔢 MPI:",
        "🧵 OMP :": "🧵 OMP:",
        "? cœurs": "? cores",
        "🔍 Détecter": "🔍 Detect",
        "Relire CPU, RAM et MPI du PC qui exécute l'API":
            "Re-read CPU, RAM and MPI of the PC running the API",
        "Détecter cœurs CPU": "Detect CPU cores",
        "auto": "auto",

        "Lance les programmes <strong>dans l'ordre</strong> : le n° 1 est toujours le <strong>SCF</strong>. Clique une case du pipeline pour ouvrir sa carte, puis <strong>Lancer</strong>.":
            "Run the programs <strong>in order</strong>: n° 1 is always <strong>SCF</strong>. Click a pipeline box to open its card, then <strong>Run</strong>.",
        "Chaque programme a <strong>son propre input</strong> — lance <strong>1 SCF</strong>, puis 2, puis 3…":
            "Each program has <strong>its own input</strong> — run <strong>1 SCF</strong>, then 2, then 3…",
        "Prochaine étape — lance celle-ci": "Next step — run this one",
        "prêt": "ready",
        "à lancer": "to run",
        "pw.x dense": "pw.x dense",
        "pw.x coarse": "pw.x coarse",
        "DFPT + e-p": "DFPT + e-p",
        "dvscf + dyn": "dvscf + dyn",
        "Wannier + Éliashberg": "Wannier + Éliashberg",
        "générateur": "generator",
        "configs": "configs",
        "2 · pw.x NSCF dense": "2 · pw.x dense NSCF",
        "3 · ph.x (DFPT + e-p)": "3 · ph.x (DFPT + e-p)",
        "4 · matdyn.x (μ*, Tᶜ)": "4 · matdyn.x (μ*, Tᶜ)",
        "2 · ph.x (dvscf + dyn)": "2 · ph.x (dvscf + dyn)",
        "3 · pw.x NSCF coarse": "3 · pw.x coarse NSCF",
        "4 · epw.x (Wannier + Éliashberg)": "4 · epw.x (Wannier + Éliashberg)",
        "1 · Générateur configs": "1 · Configuration generator",
        "2 · pw.x (forces)": "2 · pw.x (forces)",
        "3 · Module SSCHA": "3 · SSCHA module",
        "SCF du workflow (pw.x) — densité de référence": "Workflow SCF (pw.x) — reference density",
        "NSCF (pw.x) — paramètres de la branche": "NSCF (pw.x) — branch parameters",
        "📐 NSCF dense (classique)": "📐 Dense NSCF (classic)",
        "NSCF dense (classique)": "Dense NSCF (classic)",
        "📡 NSCF classique": "📡 Classic NSCF",
        "📡 NSCF EPW": "📡 EPW NSCF",
        "⚡ NSCF coarse + nbnd (EPW)": "⚡ Coarse NSCF + nbnd (EPW)",
        "NSCF coarse + nbnd (EPW)": "Coarse NSCF + nbnd (EPW)",
        "NSCF coarse + nbnd": "Coarse NSCF + nbnd",
        "NSCF dense": "Dense NSCF",
        "📐 Classique (ph.x → matdyn.x)": "📐 Classic (ph.x → matdyn.x)",
        "⚡ EPW (epw.x)": "⚡ EPW (epw.x)",
        "ph.x DFPT": "ph.x DFPT",
        "Phonons": "Phonons",
        "q2r.x + matdyn.x": "q2r.x + matdyn.x",
        "epw.x — Wannier + Éliashberg": "epw.x — Wannier + Éliashberg",
        "pw.x — forces sur chaque configuration": "pw.x — forces on each configuration",
        "Générateur de configurations SSCHA": "SSCHA configuration generator",
        "Module SSCHA — minimisation énergie libre": "SSCHA module — free-energy minimisation",
        "Supercellules déplacées aléatoirement — base du couplage anharmonique.":
            "Randomly displaced supercells — the basis of anharmonic coupling.",
        "Suivi de la minimisation · extraction des fréquences de phonons corrigées et α²F(ω).":
            "Minimisation monitoring · extraction of the corrected phonon frequencies and α²F(ω).",
        "🧮 Éliashberg → Tᶜ + Δ": "🧮 Éliashberg → Tᶜ + Δ",
        "Éliashberg (EPW)": "Éliashberg (EPW)",
        "Tᶜ + gap Δ(T)": "Tᶜ + gap Δ(T)",

        /* Résultats */
        "📊 Résultats — Workflow Classique": "📊 Results — Classic workflow",
        "📊 Résultats — Workflow EPW": "📊 Results — EPW workflow",
        "Lire / rafraîchir les résultats Classique": "Read / refresh the Classic results",
        "Lire / rafraîchir les résultats EPW": "Read / refresh the EPW results",
        "Lire résultats": "Read results",
        "Lire les deux voies": "Read both routes",
        "📈 Comparaison WF1 vs WF2": "📈 WF1 vs WF2 comparison",
        "Comparer α²F(ω)": "Compare α²F(ω)",
        "Nécessite que les deux workflows aient tourné pour le même matériau (":
            "Requires both workflows to have run for the same material (",
        "Post-traitement classique : α²F(ω), λ, ω_log → Tᶜ McMillan/Allen-Dynes.":
            "Classic post-processing: α²F(ω), λ, ω_log → McMillan/Allen-Dynes Tᶜ.",
        "α²F(ω), λ, ω_log → Tᶜ McMillan/Allen-Dynes": "α²F(ω), λ, ω_log → McMillan/Allen-Dynes Tᶜ",
        ": α²F(ω), λ, ω_log, Tᶜ McMillan.": ": α²F(ω), λ, ω_log, McMillan Tᶜ.",
        ", Tᶜ McMillan / Allen-Dynes à partir de": ", McMillan / Allen-Dynes Tᶜ from",
        "λ, Tᶜ Éliashberg, gap Δ(T) à partir de": "λ, Éliashberg Tᶜ, gap Δ(T) from",
        "Les deux chemins mènent à la même science (α²F, λ, T": "Both routes lead to the same physics (α²F, λ, T",
        "Visualisation dispersions et modes": "Dispersion and mode visualisation",
        "Upload → visualisation": "Upload → visualisation",

        /* Aide — tableau comparatif */
        "Tableau comparatif des paramètres": "Parameter comparison table",
        "Paramètre": "Parameter",
        "Méthode classique — étapes": "Classic method — steps",
        "Méthode EPW — étapes": "EPW method — steps",
        "Rôle principal": "Main role",
        "Coût relatif": "Relative cost",
        "Cas d'usage": "Use case",
        "Public cible": "Target audience",
        "Points forts Supra-QE": "Supra-QE strengths",
        "Règles imposées par l'interface": "Rules enforced by the interface",
        "Métal obligatoire :": "Metal required:",
        "SCF partagé :": "Shared SCF:",
        "Surface de Fermi 3D :": "3D Fermi surface:",
        "Fiche technique :": "Data sheet:",
        "Formules": "Formulas",
        "Liens utiles": "Useful links",
        "Compléments utiles": "Useful complements",
        "Comparaison avec les ressources en ligne": "Comparison with online resources",
        "Ressource": "Resource",
        "Interface": "Interface",
        "Automatisation": "Automation",
        "Idéal pour": "Best for",
        "Moteur de calcul": "Calculation engine",
        "Interface web": "Web interface",
        "Navigateur + formulaires": "Browser + forms",
        "Notebooks (Binder / Colab)": "Notebooks (Binder / Colab)",
        "Python / Jupyter": "Python / Jupyter",
        "Python haut niveau sur QE + EPW": "High-level Python on top of QE + EPW",
        "Scripts / boucles possibles": "Scripts / loops possible",
        "Automatisée par scripts": "Script-driven",
        "Via scripts utilisateur": "Through user scripts",
        "UI AiiDA": "AiiDA UI",
        "Cluster / HPC": "Cluster / HPC",
        "Labo / cours": "Lab / teaching",
        "Enseignement / viz": "Teaching / viz",
        "Chercheurs / HT": "Researchers / HT",
        "Experts": "Experts",
        "Recherche, reproductibilité, HT": "Research, reproducibility, HT",
        "Montée en gamme recherche": "Scaling up to research",
        "Cours, premier calcul Tᶜ EPW": "Teaching, a first EPW Tᶜ calculation",
        "Tutoriels dédiés (MgB₂, Pb…)": "Dedicated tutorials (MgB₂, Pb…)",
        "Tutoriels officiels (Pb, MgB₂, Nb…)": "Official tutorials (Pb, MgB₂, Nb…)",
        "Matériaux conventionnels (Nb, MgB₂…)": "Conventional materials (Nb, MgB₂…)",
        "Publications haut niveau, supra anisotrope": "High-level publications, anisotropic superconductivity",
        "Materials Cloud — phonons": "Materials Cloud — phonons",
        "Workflows EPW + provenance": "EPW workflows + provenance",
        "AiiDA + aiida-supercon": "AiiDA + aiida-supercon",
        "Guidée (prérequis, pseudos, ph.x)": "Guided (prerequisites, pseudos, ph.x)",
        "Enchaînement ; convergence fine manuelle": "Chaining; fine convergence done manually",
        "Option limitée dans l’UI": "Limited option in the UI",
        "Oui (locale, FR)": "Yes (local, FR/EN)",
        "Oui (référence)": "Yes (reference)",
        "Oui (screening)": "Yes (screening)",
        "Oui (2 méthodes)": "Yes (2 methods)",
        "Oui (iso, aniso, FBW)": "Yes (iso, aniso, FBW)",
        "Oui": "Yes",
        "Non": "No",
        "Non (pas Tᶜ)": "No (no Tᶜ)",
        "Non (amont)": "No (upstream)",
        "Non (doc + scripts)": "No (docs + scripts)",
        "Forte (scripts)": "Strong (scripts)",
        "Très forte (convergence Tᶜ)": "Very strong (Tᶜ convergence)",
        "Moyen": "Medium",
        "WF dédiés Tᶜ, génération inputs, prérequis, lecture résultats":
            "Dedicated Tᶜ workflows, input generation, prerequisites, result reading",
        "Codes pw.x, ph.x, sources": "pw.x and ph.x codes, sources",
        "Documentation EPW": "EPW documentation",
        "programme Fortran": "Fortran program",
        "bibliothèque Python": "Python library",
        "laboratoire guidé": "guided laboratory",
        "son propre input": "its own input",
        "Chaque programme a": "Each program has",
        "Un": "A",
        "est un": "is a",
        "de": "of",
        "et": "and",
        "dans": "in",
        "deux": "two",
        "simple": "simple",
        "uniquement —": "only —",
        "automatique.": "automatic.",
        "sauvegardé.": "saved.",
        "ci-dessus.": "above.",
        "copier les": "copy the",
        ": placer": ": put",
        "dans vos": "in your",
        "🧊 Supra-QE (ce module)": "🧊 Supra-QE (this module)",
        "Supra-QE (WF2)": "Supra-QE (WF2)",
        "⚛️ Quantum ESPRESSO —": "⚛️ Quantum ESPRESSO —",
        "Quantum ESPRESSO": "Quantum ESPRESSO",
        "🐍 EPWpy (workflows Python + démo navigateur) —": "🐍 EPWpy (Python workflows + browser demo) —",
        "⚙️ AiiDA-supercon (workflows EPW) —": "⚙️ AiiDA-supercon (EPW workflows) —",
        "📘 Tutoriels supraconductivité EPW —": "📘 EPW superconductivity tutorials —",
        "📊 Visualiseur phonons interactif —": "📊 Interactive phonon viewer —",
        "☁️ Materials Cloud (portail) —": "☁️ Materials Cloud (portal) —",
        "🧮 MgB₂ (exemple EPW) —": "🧮 MgB₂ (EPW example) —",
        "EPW ≠ EPWpy — même physique, couches différentes": "EPW ≠ EPWpy — same physics, different layers",
        "McMillan (1968)": "McMillan (1968)",
        "Allen–Dynes (1975)": "Allen–Dynes (1975)",
        ": ajoute deux préfacteurs f₁, f₂.": ": adds two prefactors f₁, f₂.",
        ": équations couplées sur axe imaginaire + prolongation Padé → Δ(T), Tᶜ.":
            ": coupled equations on the imaginary axis + Padé continuation → Δ(T), Tᶜ.",
        ": Tᶜ = (ω_log / 1.20) · exp[ –1.04(1+λ) / (λ – μ*(1+0.62λ)) ]":
            ": Tᶜ = (ω_log / 1.20) · exp[ –1.04(1+λ) / (λ – μ*(1+0.62λ)) ]",
        ": densité électronique convergée avec smearing métallique.":
            ": electron density converged with metallic smearing.",
        ": matrice dynamique + éléments e-p sur la grille q.": ": dynamical matrix + e-p elements on the q grid.",
        ": passage espace q → espace réel (IFC).": ": from q space to real space (IFC).",
        ": identique au classique.": ": same as in the classic route.",
        ": grille q coarse,": ": coarse q grid,",
        "; mode EPW : sauvegarde": "; EPW mode: saves",
        "sur grille q dense": "on a dense q grid",
        "que liront le NSCF et": "that will be read by the NSCF and",
        ": wannierisation + transformée de Fourier des e-p + interpolation grilles 40³ + Éliashberg → Tᶜ et gap Δ.":
            ": wannierisation + Fourier transform of the e-p matrix + interpolation on 40³ grids + Éliashberg → Tᶜ and gap Δ.",
        "EPW interpole le couplage e-p sur grilles ultra-denses puis résout Éliashberg → Tᶜ + gap Δ.":
            "EPW interpolates the e-p coupling on ultra-dense grids then solves Éliashberg → Tᶜ + gap Δ.",
        "Plus lourd (Wannier + Éliashberg)": "Heavier (Wannier + Éliashberg)",
        "C'est exactement ce qu'il faut mettre en valeur dans tes conclusions ou ta soutenance !":
            "This is exactly what you should highlight in your conclusions or your defence!",
        "Mais là où EPWpy automatise pour les experts du code, ton interface démocratise le calcul en encadrant l'utilisateur dans un protocole strict, visuel et sécurisé.":
            "But where EPWpy automates things for code experts, this interface opens the calculation up by guiding the user through a strict, visual and safe protocol.",
        "Parcours guidé en français, garde-fous (pseudos NC, métal, μ*, k/q, SCF partagé), journal HTML/PDF, XCrySDen, comparaison WF1 vs WF2, portable (":
            "Guided walkthrough, safeguards (NC pseudos, metal, μ*, k/q, shared SCF), HTML/PDF notebook, XCrySDen, WF1 vs WF2 comparison, portable (",
        ". Moins flexible qu’EPWpy pour l’aniso avancée (FBW, sparse-ir, campagnes HT), plus simple pour un parcours cours/labo guidé en français.":
            ". Less flexible than EPWpy for advanced anisotropic work (FBW, sparse-ir, HT campaigns), simpler for a guided teaching/lab walkthrough.",
        "par scripts/notebooks (Binder, cluster). Ce n’est pas un autre code de remplacement — c’est une couche d’automatisation et d’analyse au-dessus des mêmes binaires.":
            "through scripts/notebooks (Binder, cluster). It is not a replacement code — it is an automation and analysis layer on top of the same binaries.",
        "local pour Tᶜ (WF1 classique + WF2 EPW). Les plateformes ci-dessous couvrent des besoins complémentaires (tutoriels officiels, visualisation, haute performance).":
            "local tool for Tᶜ (WF1 classic + WF2 EPW). The platforms below cover complementary needs (official tutorials, visualisation, high performance).",
        "EPWpy (notebooks reproductibles) ou AiiDA-supercon (convergence auto des grilles, screening à grande échelle sur cluster).":
            "EPWpy (reproducible notebooks) or AiiDA-supercon (automatic grid convergence, large-scale screening on a cluster).",
        "PseudoDojo pour les pseudos ; <strong>XCrySDen</strong> pour la surface de Fermi (<code>.bxsf</code>) ; tutoriels EPW pour la physique avancée ; Materials Cloud pour animer les phonons après":
            "PseudoDojo for pseudopotentials; <strong>XCrySDen</strong> for the Fermi surface (<code>.bxsf</code>); EPW tutorials for advanced physics; Materials Cloud to animate phonons after",
        "officiel (Wannier + Éliashberg). C’est lui qui calcule Tᶜ et Δ(T). Le":
            "official code (Wannier + Éliashberg). It is what computes Tᶜ and Δ(T). The",
        "qui pilote QE + Wannier90 +": "which drives QE + Wannier90 +",
        "de Supra-QE l’appelle après": "of Supra-QE calls it after",
        ": interface web + API locale ; génère les": ": web interface + local API; it generates the",
        ". Elle fournit": ". It provides",
        ", lance": ", runs",
        ", lit": ", reads",
        ": une": ": a",
        ") : le": "): the",
        "— ou": "— or",
        ": choisir": ": choose",
        "puis ouvrir": "then open",
        "pour voir": "to see",
        "interpolated": "interpolated",
        "gaussian": "gaussian",
        "log": "log",

        /* ── Cartes d'étapes générées par l'application ─────────────────── */
        "SCF métallique": "Metallic SCF",
        "NSCF dense": "Dense NSCF",
        "Phonons + e-p": "Phonons + e-p",
        "q2r.x — IFC": "q2r.x — IFC",
        "matdyn.x → Tᶜ": "matdyn.x → Tᶜ",
        "alpha2f.x (optionnel)": "alpha2f.x (optional)",
        "Phonons + dvscf (avant NSCF)": "Phonons + dvscf (before NSCF)",
        "NSCF coarse + nbnd": "Coarse NSCF + nbnd",
        "EPW — Wannier + Éliashberg": "EPW — Wannier + Éliashberg",
        "Générateur configs": "Configuration generator",
        "Forces (pw.x)": "Forces (pw.x)",
        "Minimisation SSCHA": "SSCHA minimisation",
        "optionnel": "optional",

        "Densité électronique de référence dans le outdir du SCF (prefix.save) — le NSCF et ph.x doivent lire exactement le même chemin.":
            "Reference electron density in the SCF outdir (prefix.save) — NSCF and ph.x must read exactly the same path.",
        "Densité électronique de référence dans le outdir du SCF (prefix.save) — base de ph.x puis du NSCF coarse.":
            "Reference electron density in the SCF outdir (prefix.save) — the basis for ph.x then for the coarse NSCF.",
        "Cartographie dense de la surface de Fermi (k_nscf très dense).":
            "Dense mapping of the Fermi surface (very dense k_nscf).",
        "DFPT : matrice dynamique + éléments de matrice du couplage électron-phonon.":
            "DFPT: dynamical matrix + electron-phonon coupling matrix elements.",
        "DFPT sur grille q coarse ; sauvegarde des matrices dynamiques et du potentiel perturbé lus ensuite par epw.x.":
            "DFPT on a coarse q grid; saves the dynamical matrices and the perturbed potential later read by epw.x.",
        "Transforme la matrice dynamique en constantes de force en espace réel.":
            "Turns the dynamical matrix into real-space force constants.",
        "Calcule α²F(ω), λ, ω_log et estime Tᶜ via McMillan / Allen-Dynes.":
            "Computes α²F(ω), λ, ω_log and estimates Tᶜ through McMillan / Allen-Dynes.",
        "Post-processeur de α²F(ω) — lisse la courbe pour un tracé plus propre.":
            "α²F(ω) post-processor — smooths the curve for a cleaner plot.",
        "Grille k coarse uniforme et nbnd élevé pour la wannierisation — après ph.x et le regroupement dans save/.":
            "Uniform coarse k grid and high nbnd for the wannierisation — after ph.x and the gathering into save/.",
        "Wannierisation + Fourier des e-p + interpolation grille géante + Éliashberg.":
            "Wannierisation + Fourier transform of the e-p matrix + huge-grid interpolation + Éliashberg.",
        "Supercellules déplacées aléatoirement (base du couplage anharmonique).":
            "Randomly displaced supercells (basis of the anharmonic coupling).",
        "SCF + forces atomiques (tprnfor) sur chaque configuration générée.":
            "SCF + atomic forces (tprnfor) on each generated configuration.",
        "Minimisation de l'énergie libre · fréquences phonons corrigées · α²F(ω).":
            "Free-energy minimisation · corrected phonon frequencies · α²F(ω).",

        /* Recommandations affichées sous chaque étape */
        "Smearing MV, degauss ≈ 0.02 Ry": "MV smearing, degauss ≈ 0.02 Ry",
        "Grille k ≈ 12 × 12 × 12": "k grid ≈ 12 × 12 × 12",
        "Crée outdir utilisé par NSCF et ph.x": "Creates the outdir used by NSCF and ph.x",
        "Grille k ≥ 16 × 16 × 16 (24³ recommandé)": "k grid ≥ 16 × 16 × 16 (24³ recommended)",
        "la2F = .true. (auto)": "la2F = .true. (automatic)",
        "diagonalization = cg": "diagonalization = cg",
        "Ratio k/q doit être entier": "The k/q ratio must be an integer",
        "Grille q ≈ 4 × 4 × 4": "q grid ≈ 4 × 4 × 4",
        "Calcul le plus long": "The longest calculation",
        "Très rapide (< 1 min)": "Very fast (< 1 min)",
        "Utilise les fichiers dyn produits par ph.x": "Uses the dyn files produced by ph.x",
        "Aucun paramètre critique": "No critical parameter",
        "μ* = 0.10–0.16 (standard 0.10)": "μ* = 0.10–0.16 (standard 0.10)",
        "Sortie finale Tᶜ": "Final Tᶜ output",
        "Optionnel : matdyn.x produit déjà α²F": "Optional: matdyn.x already produces α²F",
        "Smearing ≈ 0.05": "Smearing ≈ 0.05",
        "Grille q coarse (4³) partagée avec le NSCF EPW": "Coarse q grid (4³) shared with the EPW NSCF",
        "fildvscf obligatoire pour epw.x": "fildvscf mandatory for epw.x",
        "À lancer avant le NSCF (ordre canonique EPW)": "Run before the NSCF (canonical EPW order)",
        "nbnd élevé (≈ 3× les bandes occupées)": "High nbnd (≈ 3× the occupied bands)",
        "Grille k coarse = grille q": "Coarse k grid = q grid",
        "Wannier : nbndsub et fenêtres à surveiller": "Wannier: watch nbndsub and the windows",
        "Nécessite save/ créé depuis les sorties de ph.x": "Requires save/ built from the ph.x outputs",

        /* Boutons et étiquettes des cartes */
        "✏️ Vérifier / éditer": "✏️ Check / edit",
        "💾 Sauvegarder": "💾 Save",
        "🚀 Lancer": "🚀 Run",
        "🖥️ Terminal": "🖥️ Terminal",
        "📊 Suivi": "📊 Monitor",
        "⬇️ Télécharger": "⬇️ Download",
        "📋 Copier": "📋 Copy",
        "↻ Revérifier": "↻ Re-check",
        "↻ Rafraîchir": "↻ Refresh",
        "Chargement…": "Loading…",
        "État :": "Status:",
        "Suivi auto (2 s)": "Auto-follow (2 s)",
        "🔗 Requiert :": "🔗 Requires:",
        "terminé(s)": "finished",
        "✅ terminé": "✅ finished",
        "❌ échec": "❌ failed",
        "⏳ à lancer": "⏳ to run",
        "🔒 en attente": "🔒 waiting",
        "⏳ Valide la structure relaxée": "⏳ Validate the relaxed structure",
        "🔗 Première étape de la chaîne — part du vc-relax validé.":
            "🔗 First step of the chain — starts from the validated vc-relax.",
        "🧪 Matériau actif": "🧪 Active material",
        "— configure les pseudos (1b) puis un workflow —": "— set up the pseudopotentials (1b) then a workflow —",

        /* Journal, chaîne, messages d'état */
        "Vérification de l'enchaînement —": "Chain verification —",
        "🎉 Chaîne complète — passe à l'onglet": "🎉 Chain complete — switch to the",
        "pour lire Tᶜ.": "tab to read Tᶜ.",
        "est bloquée :": "is blocked:",
        "aucune sortie terminée :": "no finished output:",
        "sortie présente mais sans « JOB DONE » :": "output present but without “JOB DONE”:",
        "matrices dynamiques": "dynamical matrices",
        "constantes de force": "force constants",
        "matériau non métallique (pas un conducteur)": "non-metallic material (not a conductor)",
        "Arrêter les calculs": "Stop the calculations",
        "pas un conducteur": "not a conductor",
        "SCF métallique (conducteur) — génération des inputs suivants et poursuite de la chaîne.":
            "Metallic SCF (conductor) — generating the following inputs and continuing the chain.",
        "Inputs suivants mis à jour dans": "Following inputs updated in",
        "Gap électronique : ce n'est pas un conducteur — arrête la chaîne e–p / Tc.":
            "Electronic gap: this is not a conductor — stop the e–ph / Tc chain.",
        "Matériau non métallique (gap) — arrêter les calculs e–p / Tc.":
            "Non-metallic material (gap) — stop the e–ph / Tc calculations.",
        "dossier save/ (dvscf + dyn regroupés)": "save/ folder (dvscf + dyn gathered)",
        "Relance ph.x : les fichiers dyn sont produits dans le dossier du workflow.":
            "Run ph.x again: the dyn files are produced in the workflow folder.",
        "Regroupe les sorties de ph.x avec": "Gather the ph.x outputs with",
        "avant de lancer epw.x.": "before running epw.x.",
        "Les lancements restent possibles, mais sans contrôle automatique des dépendances.":
            "Launching is still possible, but without automatic dependency checking.",
        "L'API en cours d'exécution est antérieure à cette interface (endpoint /api/file/stat absent). Redémarre-la avec ./DEMARRER.sh pour activer la vérification pas à pas.":
            "The running API is older than this interface (the /api/file/stat endpoint is missing). Restart it with ./DEMARRER.sh to enable step-by-step verification.",
        "Vérification de la chaîne indisponible.": "Chain verification unavailable.",
        "Valide un matériau pour vérifier l'enchaînement des calculs.":
            "Validate a material to verify the calculation chain.",
        "Structure relaxée requise : place": "Relaxed structure required: put",
        "dans la section ① puis clique « Vérifier les prérequis ».":
            "in section ① then click “Check prerequisites”.",
        "Structure relaxée non exploitable": "Relaxed structure not usable",
        "✅ Structure relaxée exploitable —": "✅ Relaxed structure usable —",
        "Binaires QE manquants sur cette machine": "QE binaries missing on this machine",
        "introuvable(s)": "not found",
        "Les inputs restent générables (bouton 🖥️ Terminal pour lancer ailleurs), mais l'exécution depuis l'interface échouera à ces étapes.":
            "Inputs can still be generated (🖥️ Terminal button to run elsewhere), but running from the interface will fail at those steps.",
        "Indique le bon dossier via": "Point to the right folder through",
        "si les binaires existent ailleurs.": "if the binaries live elsewhere.",
        "API hors-ligne — validation locale du nom uniquement.": "API offline — local name validation only.",
        "API injoignable. Lancer": "API unreachable. Run",
        "Connexion à l'API Supra-QE…": "Connecting to the Supra-QE API…",
        "API en ligne ·": "API online ·",
        "(⚠️ aucun binaire QE détecté)": "(⚠️ no QE binary detected)",
        "Aucun matériau validé. Saisis et valide un matériau (étape 1), choisis un workflow, puis lance les calculs ou dépose les fichiers":
            "No material validated. Enter and validate a material (step 1), pick a workflow, then run the calculations or drop the",
        "Aucune donnée α²F(ω) disponible pour comparer. Lance d'abord matdyn.x ou epw.x.":
            "No α²F(ω) data available to compare. Run matdyn.x or epw.x first.",
        "Lancer quand même ? (à faire si tu as produit ces fichiers ailleurs)":
            "Run anyway? (do this if you produced those files elsewhere)",
        "Sélectionne d'abord un matériau (étape 1).": "Select a material first (step 1).",
        "Sélectionne d'abord un matériau.": "Select a material first.",
        "Choisis d'abord un workflow.": "Choose a workflow first.",
        "Choisis d'abord un workflow (étape 2).": "Choose a workflow first (step 2).",
        "API hors-ligne.": "API offline.",
        "Input introuvable.": "Input not found.",
        "Paramètres invalides :": "Invalid parameters:",
        "✅ Tous les pseudopotentiels sont": "✅ All pseudopotentials are",
        "Les noms de fichiers sont des suggestions PseudoDojo — ajuste-les si besoin.":
            "The file names are PseudoDojo suggestions — adjust them if needed.",
        "Mode Résultats": "Results mode",
        "— choisis WF1 ou WF2, valide le matériau si besoin, puis lis Tᶜ et α²F(ω).":
            "— pick WF1 or WF2, validate the material if needed, then read Tᶜ and α²F(ω).",
        "Toutes les commandes sont prêtes à coller. Utilise-les si tu préfères lancer en dehors de l'interface (et garder le contrôle direct du processus).":
            "Every command is ready to paste. Use them if you prefer running outside the interface (and keeping direct control of the process).",
        "Aller dans le dossier de calcul": "Go to the calculation folder",
        "Définir les threads OpenMP": "Set the OpenMP threads",
        "Lancer le calcul": "Run the calculation",
        "Suivre le log en temps réel": "Follow the log in real time",
        "Une seule commande prête à coller": "A single command ready to paste",
        "Pipeline complet": "Full pipeline",
        "⚠️ Points d'attention :": "⚠️ Things to watch:",
        "Syntaxe Fortran (sensible à la casse)": "Fortran syntax (case sensitive)",
        "Chemins des pseudos cohérents (": "Consistent pseudopotential paths (",
        "Format numérique :": "Number format:",
        "(notation Fortran)": "(Fortran notation)",
        "(non détecté)": "(not detected)",
        "étapes": "steps",
        "pipeline": "pipeline",
    },
};

/* Dessin 3D de la surface de Fermi (isosurface E = E_F du fichier BXSF). */
(function (global) {
    'use strict';

    const COLORS = [
        [0.90, 0.62, 0.16],
        [0.16, 0.58, 0.78],
        [0.52, 0.30, 0.70],
        [0.18, 0.62, 0.40],
        [0.78, 0.32, 0.38],
    ];

    const VERT = `
        attribute vec3 aPos;
        attribute vec3 aNrm;
        attribute vec3 aCol;
        uniform mat4 uMvp;
        uniform mat3 uN;
        varying vec3 vN;
        varying vec3 vCol;
        void main() {
            vN = normalize(uN * aNrm);
            vCol = aCol;
            gl_Position = uMvp * vec4(aPos, 1.0);
        }`;

    const FRAG = `
        precision mediump float;
        varying vec3 vN;
        varying vec3 vCol;
        uniform vec3 uLight;
        void main() {
            float lam = abs(dot(normalize(vN), uLight));
            float shade = 0.28 + 0.72 * lam;
            gl_FragColor = vec4(vCol * shade, 1.0);
        }`;

    function compile(gl, type, src) {
        const sh = gl.createShader(type);
        gl.shaderSource(sh, src);
        gl.compileShader(sh);
        if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
            const log = gl.getShaderInfoLog(sh);
            gl.deleteShader(sh);
            throw new Error(log || 'shader');
        }
        return sh;
    }

    function mul4(a, b) {
        const o = new Float32Array(16);
        for (let c = 0; c < 4; c++) {
            for (let r = 0; r < 4; r++) {
                o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1]
                    + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
            }
        }
        return o;
    }

    function perspective(fovy, aspect, near, far) {
        const f = 1 / Math.tan(fovy / 2);
        const nf = 1 / (near - far);
        const o = new Float32Array(16);
        o[0] = f / aspect;
        o[5] = f;
        o[10] = (far + near) * nf;
        o[11] = -1;
        o[14] = 2 * far * near * nf;
        return o;
    }

    function look(eye, center, up) {
        const zx = eye[0] - center[0];
        const zy = eye[1] - center[1];
        const zz = eye[2] - center[2];
        let zl = Math.hypot(zx, zy, zz) || 1;
        const znx = zx / zl, zny = zy / zl, znz = zz / zl;
        let xx = up[1] * znz - up[2] * zny;
        let xy = up[2] * znx - up[0] * znz;
        let xz = up[0] * zny - up[1] * znx;
        let xl = Math.hypot(xx, xy, xz) || 1;
        xx /= xl; xy /= xl; xz /= xl;
        const yx = zny * xz - znz * xy;
        const yy = znz * xx - znx * xz;
        const yz = znx * xy - zny * xx;
        const o = new Float32Array(16);
        o[0] = xx; o[1] = yx; o[2] = znx;
        o[4] = xy; o[5] = yy; o[6] = zny;
        o[8] = xz; o[9] = yz; o[10] = znz;
        o[12] = -(xx * eye[0] + xy * eye[1] + xz * eye[2]);
        o[13] = -(yx * eye[0] + yy * eye[1] + yz * eye[2]);
        o[14] = -(znx * eye[0] + zny * eye[1] + znz * eye[2]);
        o[15] = 1;
        return o;
    }

    function normalMat(m) {
        /* Rotation extraite de la vue (colonnes orthonormées). */
        return new Float32Array([
            m[0], m[1], m[2],
            m[4], m[5], m[6],
            m[8], m[9], m[10],
        ]);
    }

    function mount(canvas, mesh) {
        if (canvas._fermiStop) canvas._fermiStop();
        const gl = canvas.getContext('webgl', { antialias: true, alpha: false });
        if (!gl) return { ok: false, error: 'webgl' };

        const bands = (mesh && mesh.bands) || [];
        const chunks = [];
        let nVert = 0;
        let cx = 0, cy = 0, cz = 0;
        bands.forEach((b, i) => {
            const raw = b.interleaved || [];
            if (raw.length < 18) return;
            const col = COLORS[i % COLORS.length];
            const buf = new Float32Array(raw.length + (raw.length / 6) * 3);
            let w = 0;
            for (let p = 0; p < raw.length; p += 6) {
                buf[w++] = raw[p];
                buf[w++] = raw[p + 1];
                buf[w++] = raw[p + 2];
                buf[w++] = raw[p + 3];
                buf[w++] = raw[p + 4];
                buf[w++] = raw[p + 5];
                buf[w++] = col[0];
                buf[w++] = col[1];
                buf[w++] = col[2];
                cx += raw[p];
                cy += raw[p + 1];
                cz += raw[p + 2];
                nVert += 1;
            }
            chunks.push(buf.subarray(0, w));
        });
        if (!nVert) return { ok: false, error: 'empty' };
        cx /= nVert; cy /= nVert; cz /= nVert;

        let radius = 0;
        chunks.forEach(buf => {
            for (let p = 0; p < buf.length; p += 9) {
                radius = Math.max(radius, Math.hypot(buf[p] - cx, buf[p + 1] - cy, buf[p + 2] - cz));
            }
        });
        if (radius < 1e-6) radius = 1;

        const prog = gl.createProgram();
        const vs = compile(gl, gl.VERTEX_SHADER, VERT);
        const fs = compile(gl, gl.FRAGMENT_SHADER, FRAG);
        gl.attachShader(prog, vs);
        gl.attachShader(prog, fs);
        gl.linkProgram(prog);
        if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
            return { ok: false, error: 'link' };
        }
        gl.useProgram(prog);
        const loc = {
            pos: gl.getAttribLocation(prog, 'aPos'),
            nrm: gl.getAttribLocation(prog, 'aNrm'),
            col: gl.getAttribLocation(prog, 'aCol'),
            mvp: gl.getUniformLocation(prog, 'uMvp'),
            nmat: gl.getUniformLocation(prog, 'uN'),
            light: gl.getUniformLocation(prog, 'uLight'),
        };
        const vbo = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
        const total = chunks.reduce((n, c) => n + c.length, 0);
        const packed = new Float32Array(total);
        let off = 0;
        chunks.forEach(c => { packed.set(c, off); off += c.length; });
        gl.bufferData(gl.ARRAY_BUFFER, packed, gl.STATIC_DRAW);
        const stride = 9 * 4;
        gl.enableVertexAttribArray(loc.pos);
        gl.vertexAttribPointer(loc.pos, 3, gl.FLOAT, false, stride, 0);
        gl.enableVertexAttribArray(loc.nrm);
        gl.vertexAttribPointer(loc.nrm, 3, gl.FLOAT, false, stride, 12);
        gl.enableVertexAttribArray(loc.col);
        gl.vertexAttribPointer(loc.col, 3, gl.FLOAT, false, stride, 24);
        gl.enable(gl.DEPTH_TEST);
        gl.disable(gl.CULL_FACE);
        gl.uniform3f(loc.light, 0.35, 0.55, 0.76);

        const view = { yaw: 0.6, pitch: 0.45, dist: radius * 2.8 };
        let alive = true;
        let raf = 0;
        let drag = null;

        function bgColor() {
            const css = getComputedStyle(canvas).backgroundColor || '';
            const m = css.match(/[\d.]+/g);
            if (!m || m.length < 3) return [0.12, 0.14, 0.18, 1];
            return [Number(m[0]) / 255, Number(m[1]) / 255, Number(m[2]) / 255, 1];
        }

        function frame() {
            if (!alive) return;
            const dpr = Math.min(global.devicePixelRatio || 1, 2);
            const w = Math.max(2, canvas.clientWidth);
            const h = Math.max(2, canvas.clientHeight);
            const pw = Math.floor(w * dpr);
            const ph = Math.floor(h * dpr);
            if (canvas.width !== pw || canvas.height !== ph) {
                canvas.width = pw;
                canvas.height = ph;
            }
            gl.viewport(0, 0, canvas.width, canvas.height);
            const bg = bgColor();
            gl.clearColor(bg[0], bg[1], bg[2], 1);
            gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
            const cp = Math.cos(view.pitch);
            const eye = [
                cx + view.dist * cp * Math.sin(view.yaw),
                cy + view.dist * Math.sin(view.pitch),
                cz + view.dist * cp * Math.cos(view.yaw),
            ];
            const viewM = look(eye, [cx, cy, cz], [0, 1, 0]);
            const proj = perspective(0.7, canvas.width / canvas.height, radius * 0.02, radius * 40);
            gl.uniformMatrix4fv(loc.mvp, false, mul4(proj, viewM));
            gl.uniformMatrix3fv(loc.nmat, false, normalMat(viewM));
            gl.drawArrays(gl.TRIANGLES, 0, nVert);
            raf = global.requestAnimationFrame(frame);
        }

        function onDown(ev) {
            drag = { x: ev.clientX, y: ev.clientY, yaw: view.yaw, pitch: view.pitch };
            canvas.setPointerCapture?.(ev.pointerId);
        }
        function onMove(ev) {
            if (!drag) return;
            view.yaw = drag.yaw + (ev.clientX - drag.x) * 0.008;
            view.pitch = Math.max(-1.2, Math.min(1.2, drag.pitch + (ev.clientY - drag.y) * 0.008));
        }
        function onUp() { drag = null; }
        function onWheel(ev) {
            ev.preventDefault();
            const factor = ev.deltaY > 0 ? 1.08 : 0.92;
            view.dist = Math.max(radius * 0.4, Math.min(radius * 12, view.dist * factor));
        }
        canvas.addEventListener('pointerdown', onDown);
        canvas.addEventListener('pointermove', onMove);
        canvas.addEventListener('pointerup', onUp);
        canvas.addEventListener('pointerleave', onUp);
        canvas.addEventListener('wheel', onWheel, { passive: false });

        function stop() {
            alive = false;
            if (raf) global.cancelAnimationFrame(raf);
            canvas.removeEventListener('pointerdown', onDown);
            canvas.removeEventListener('pointermove', onMove);
            canvas.removeEventListener('pointerup', onUp);
            canvas.removeEventListener('pointerleave', onUp);
            canvas.removeEventListener('wheel', onWheel);
            canvas._fermiStop = null;
        }
        canvas._fermiStop = stop;
        frame();
        return { ok: true, triangles: mesh.triangles || Math.floor(nVert / 3), stop };
    }

    global.SupraFermi3D = { mount };
})(typeof window !== 'undefined' ? window : globalThis);

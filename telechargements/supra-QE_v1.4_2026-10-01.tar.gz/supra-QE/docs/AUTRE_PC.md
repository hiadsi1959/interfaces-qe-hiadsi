# Travailler avec Supra-QE depuis un autre PC

Deux cas courants.

---

## A. Tout tourne sur le PC de calcul (recommandé)

Sur la machine qui a Quantum ESPRESSO :

```bash
cd /chemin/vers/supra-QE
./configurer.sh          # une fois (QE_BIN_DIR, venv, associe supra-QE/bin/)
./scripts/associer_binaires_qe.sh ~/q-e-qe-7.5/bin   # si besoin (pw.x, epw.x, fs.x…)
./DEMARRER.sh
```

Ouvre `http://127.0.0.1:8765/interface/` **sur cette machine**.

Transfert du projet : `./EMBALLER.sh` puis `./AUTO_TRANSFERT.sh` / `./INSTALL_AUTOMATIQUE.sh` sur le nouveau PC.

**v1.4 — matériaux magnétiques et non magnétiques** : la chaîne Tᶜ (WF1/WF2) est
conçue pour tourner sur un **PC de calcul musclé** (plusieurs cœurs, RAM suffisante).
Spin collinéaire / non collinéaire / SOC multiplient le coût de `pw.x`, `ph.x` et surtout
`epw.x` : prévoir des grilles plus modestes au premier essai, puis affiner sur la machine
de calcul.

---

## B. Interface sur un PC, calculs sur un autre

La machine de calcul lance l’API ; le navigateur d’un autre PC du réseau s’y connecte.

### 1. Sur le PC de calcul (serveur)

Dans `config.env` :

```bash
export SUPRA_QE_HOST="0.0.0.0"   # écoute sur le réseau local
export SUPRA_ALLOW_LAN="1"       # obligatoire avec 0.0.0.0 (sinon repli 127.0.0.1)
export SUPRA_QE_PORT="8765"
export QE_BIN_DIR="/chemin/vers/qe/bin"
# Obligatoire avec 0.0.0.0 + SUPRA_ALLOW_LAN (sinon repli 127.0.0.1) :
export SUPRA_API_TOKEN="choisis-un-secret"
# Si le navigateur distant est bloqué par CORS :
# export SUPRA_CORS_ORIGINS="http://192.168.1.42:8765,http://127.0.0.1:8765"
```

Puis :

```bash
./DEMARRER.sh
```

Note l’IP affichée, par ex. `http://192.168.1.42:8765/interface/`.

Pare-feu (exemple Ubuntu) :

```bash
sudo ufw allow 8765/tcp
```

### 2. Sur le PC distant (navigateur)

- Ouvre `http://IP_DU_SERVEUR:8765/interface/`
- ou `http://IP_DU_SERVEUR:8765/interface/?api=http://IP_DU_SERVEUR:8765`

Sinon : bouton **📁 Chemins** → URL de l’API → **Appliquer & tester**.

Si `SUPRA_API_TOKEN` est défini : dans **📁 Chemins**, le champ token (ou
`localStorage.supraQE.apiToken`) doit contenir le même secret — l’UI envoie
l’en-tête `X-Supra-Token`.

Les dossiers `inputs/`, `outputs/`, `pseudos/` sont ceux **du serveur**
(`SUPRA_INPUTS_DIR` / `SUPRA_OUTPUTS_DIR` s’ils sont définis). Tu n’as pas
besoin de copier QE sur le PC distant.

**Surface de Fermi 3D** : `fs.x` et **XCrySDen** tournent sur le **serveur**
(l’API). Le navigateur distant déclenche l’export `.bxsf` et l’ouverture XCrySDen
via l’API ; si XCrySDen n’est pas installé sur le serveur, télécharge le `.bxsf`
depuis **Résultats → Anisotropie**.

### 3. Sécurité

`0.0.0.0` + `SUPRA_ALLOW_LAN=1` exige aussi `SUPRA_API_TOKEN` (sinon l’API
reste en `127.0.0.1`). Réserve au labo / réseau de confiance, remets
`127.0.0.1` ensuite. Sans `SUPRA_ALLOW_LAN`, l’API refuse d’écouter sur
`0.0.0.0`.

---

## Scripts d’interface nécessaires

Seul ce jeu est chargé (plus de `supra_workflow.js`) :

| Fichier | Rôle |
|---------|------|
| `supra_config.js` | Flags UI (ex. SSCHA) |
| `supra_inputs.js` | Génération des `.in` QE / EPW |
| `supra_api_client.js` | Client HTTP |
| `supra_plots.js` | Tracés SVG (Résultats) |
| `supra_app.js` | Logique interface |
| `supra_i18n_dict.js` + `supra_i18n.js` | FR / EN |

Côté serveur : `api/supra_api.py` + `api/supra_results.py`.

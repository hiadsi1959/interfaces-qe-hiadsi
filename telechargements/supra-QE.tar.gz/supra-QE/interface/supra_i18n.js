/* =========================================================================
 *  supra_i18n.js — bascule Français / Anglais de l'interface Supra-QE
 *
 *  Le français reste la langue source du HTML et des messages générés par
 *  supra_app.js : on traduit donc le DOM à la volée plutôt que de dupliquer
 *  tous les gabarits. Trois niveaux de correspondance, du plus précis au plus
 *  général, sont appliqués dans cet ordre :
 *
 *    1. BLOCKS  — innerHTML complet d'un élément feuille (phrase entière avec
 *                 ses balises <strong>/<code>) : c'est ce qui donne la
 *                 meilleure qualité pour les paragraphes explicatifs.
 *    2. PHRASES — nœud de texte isolé (titres, libellés, boutons, badges).
 *    3. RULES   — expressions régulières pour les messages assemblés à
 *                 l'exécution (« Attend : étape 2 — … »).
 *
 *  Un MutationObserver retraduit ce que l'application injecte après coup, si
 *  bien que les journaux, cartes de calcul et panneaux d'état suivent la
 *  langue choisie. Le choix est mémorisé dans localStorage.
 *
 *  Ajouter une traduction manquante = ajouter une entrée ici, sans toucher
 *  au reste de l'application.
 * ========================================================================= */

(function () {
    'use strict';

    const STORE_KEY = 'supraQE.lang';

    /* Jamais traduit : code, chemins, formules, saisies utilisateur. */
    const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'CODE', 'PRE', 'TEXTAREA',
                               'NOSCRIPT', 'INPUT', 'SELECT', 'OPTION']);
    /* Un élément contenant l'un de ces enfants n'est pas une « feuille de texte ». */
    const BLOCKISH = new Set(['DIV', 'P', 'UL', 'OL', 'LI', 'TABLE', 'THEAD', 'TBODY',
                              'TR', 'TD', 'TH', 'SECTION', 'HEADER', 'FOOTER', 'NAV',
                              'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'BUTTON', 'LABEL',
                              'FORM', 'FIELDSET', 'DL', 'DT', 'DD']);

    const ATTRS = ['placeholder', 'title', 'aria-label'];

    const dict = () => (window.SUPRA_I18N || { blocks: {}, phrases: {}, rules: [] });

    let lang = 'fr';
    let observer = null;
    let muted = false;              // ignore nos propres mutations

    const origText = new WeakMap();  // nœud de texte -> français d'origine
    const origHTML = new WeakMap();  // élément        -> innerHTML français
    const origAttr = new WeakMap();  // élément        -> { attr: français }

    const norm = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();

    function skipped(node) {
        for (let el = node.parentElement; el; el = el.parentElement) {
            if (SKIP_TAGS.has(el.tagName)) return true;
            if (el.dataset && el.dataset.i18nSkip === 'true') return true;
        }
        return false;
    }

    /** Élément dont le contenu est une phrase (texte + balises en ligne). */
    function isTextLeaf(el) {
        if (SKIP_TAGS.has(el.tagName)) return false;
        if (!el.textContent || !el.textContent.trim()) return false;
        for (const child of el.children) {
            if (BLOCKISH.has(child.tagName)) return false;
        }
        return true;
    }

    /*
     * Les messages assemblés à l'exécution imbriquent des morceaux traduisibles
     * (« Attend : étape 2 — NSCF dense (pw.x) »). Les règles reçoivent donc un
     * traducteur de sous-chaîne, borné en profondeur pour éviter toute boucle.
     */
    let ruleDepth = 0;

    function sub(text) {
        if (ruleDepth > 4) return text;
        ruleDepth++;
        try {
            const en = translatePhrase(text);
            return en == null ? text : en;
        } finally {
            ruleDepth--;
        }
    }

    function applyRules(text) {
        for (const rule of dict().rules || []) {
            const m = rule.re.exec(text);
            if (m) return typeof rule.en === 'function' ? rule.en(m, sub) : text.replace(rule.re, rule.en);
        }
        return null;
    }

    function translatePhrase(text) {
        const key = norm(text);
        if (!key) return null;
        const d = dict();
        if (Object.prototype.hasOwnProperty.call(d.phrases, key)) return d.phrases[key];
        return applyRules(key);
    }

    /* ── Application ─────────────────────────────────────────────────────── */

    function translateBlocks(root) {
        const d = dict();
        const els = root.nodeType === 1 ? [root, ...root.querySelectorAll('*')] : [];
        for (const el of els) {
            if (el.nodeType !== 1 || !isTextLeaf(el) || skipped(el)) continue;
            if (origHTML.has(el)) continue;                   // déjà traduit
            const key = norm(el.innerHTML);
            if (!Object.prototype.hasOwnProperty.call(d.blocks, key)) continue;
            origHTML.set(el, el.innerHTML);
            el.innerHTML = d.blocks[key];
            el.dataset.i18nBlock = 'en';
        }
    }

    function insideTranslatedBlock(node) {
        for (let el = node.parentElement; el; el = el.parentElement) {
            if (el.dataset && el.dataset.i18nBlock === 'en') return true;
        }
        return false;
    }

    function translateTextNodes(root) {
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
        const todo = [];
        for (let n = walker.nextNode(); n; n = walker.nextNode()) todo.push(n);
        if (root.nodeType === 3) todo.push(root);

        for (const node of todo) {
            if (!node.nodeValue || !node.nodeValue.trim()) continue;
            if (skipped(node) || insideTranslatedBlock(node)) continue;
            if (origText.has(node)) continue;
            const en = translatePhrase(node.nodeValue);
            if (en == null) continue;
            origText.set(node, node.nodeValue);
            // conserve l'espacement d'origine autour du texte
            const lead = node.nodeValue.match(/^\s*/)[0];
            const tail = node.nodeValue.match(/\s*$/)[0];
            node.nodeValue = lead + en + tail;
        }
    }

    function translateAttributes(root) {
        const els = root.nodeType === 1 ? [root, ...root.querySelectorAll('*')] : [];
        for (const el of els) {
            for (const attr of ATTRS) {
                const v = el.getAttribute && el.getAttribute(attr);
                if (!v || !v.trim()) continue;
                const saved = origAttr.get(el) || {};
                if (attr in saved) continue;
                const en = translatePhrase(v);
                if (en == null) continue;
                saved[attr] = v;
                origAttr.set(el, saved);
                el.setAttribute(attr, en);
            }
        }
    }

    function translate(root) {
        if (!root) return;
        muted = true;
        try {
            translateBlocks(root);
            translateTextNodes(root);
            translateAttributes(root);
        } finally {
            muted = false;
        }
    }

    function restore(root) {
        muted = true;
        try {
            root.querySelectorAll('[data-i18n-block="en"]').forEach(el => {
                if (origHTML.has(el)) {
                    el.innerHTML = origHTML.get(el);
                    origHTML.delete(el);
                }
                delete el.dataset.i18nBlock;
            });
            const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
            for (let n = walker.nextNode(); n; n = walker.nextNode()) {
                if (origText.has(n)) { n.nodeValue = origText.get(n); origText.delete(n); }
            }
            [root, ...root.querySelectorAll('*')].forEach(el => {
                const saved = origAttr.get(el);
                if (!saved) return;
                Object.entries(saved).forEach(([a, v]) => el.setAttribute(a, v));
                origAttr.delete(el);
            });
        } finally {
            muted = false;
        }
    }

    /* ── Observation du contenu généré par l'application ─────────────────── */

    function startObserver() {
        if (observer) return;
        observer = new MutationObserver(muts => {
            if (muted || lang !== 'en') return;
            const roots = new Set();
            for (const m of muts) {
                if (m.type === 'characterData') roots.add(m.target.parentElement || m.target);
                m.addedNodes && m.addedNodes.forEach(n => {
                    if (n.nodeType === 1 || n.nodeType === 3) roots.add(n);
                });
            }
            roots.forEach(r => translate(r));
        });
        observer.observe(document.body, {
            childList: true, subtree: true, characterData: true,
        });
    }

    /* ── API publique ────────────────────────────────────────────────────── */

    function setLang(next, { persist = true } = {}) {
        const target = next === 'en' ? 'en' : 'fr';
        lang = target;
        document.documentElement.setAttribute('lang', target);
        document.body?.setAttribute('data-lang', target);

        if (target === 'en') { translate(document.body); startObserver(); }
        else { restore(document.body); }

        document.querySelectorAll('.lang-btn').forEach(b => {
            const on = b.dataset.lang === target;
            b.classList.toggle('active', on);
            b.setAttribute('aria-pressed', on ? 'true' : 'false');
        });
        if (persist) {
            try { localStorage.setItem(STORE_KEY, target); } catch (e) { /* mode privé */ }
        }
    }

    function bind() {
        document.querySelectorAll('.lang-btn').forEach(b => {
            b.addEventListener('click', () => setLang(b.dataset.lang));
        });
        let saved = null;
        try { saved = localStorage.getItem(STORE_KEY); } catch (e) { /* ignore */ }
        setLang(saved === 'en' ? 'en' : 'fr', { persist: false });
    }

    window.SupraI18n = {
        setLang,
        get lang() { return lang; },
        /** Retraduit une zone après un rendu (appel facultatif). */
        refresh(root) { if (lang === 'en') translate(root || document.body); },
        /** Textes vus dans le DOM et absents du dictionnaire — aide à compléter. */
        missing() {
            const out = new Set();
            const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
            for (let n = walker.nextNode(); n; n = walker.nextNode()) {
                const s = norm(n.nodeValue);
                if (!s || skipped(n) || insideTranslatedBlock(n)) continue;
                if (!/[A-Za-zÀ-ÿ]{2}/.test(s)) continue;
                if (origText.has(n)) continue;
                if (translatePhrase(s) == null) out.add(s);
            }
            return [...out];
        },
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bind);
    } else {
        bind();
    }
})();

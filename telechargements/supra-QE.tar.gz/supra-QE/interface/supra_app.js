/* ===========================================================================
 *  supra_app.js — Pilotage interface Supra-QE
 *  Pattern Interface-QE_v1 :
 *      Étape 1 : matériau + pseudos
 *      Étape 2 : workflow Classique ou EPW
 *      Calculs : prérequis externes (vc-relax + scf) + enchaînement WF
 *
 *  Stockage côté serveur :
 *      inputs/<material>/  ← vc-relax.out + scf.out (prérequis, calculs externes)
 *      inputs/<material>/classic/{scf,nscf,ph,q2r,matdyn,alpha2f}.in
 *      inputs/<material>/epw/{scf,nscf,ph,epw}.in
 *      inputs/<material>/sscha/{config,pw_forces,sscha}.in
 * ========================================================================= */

(function () {
    'use strict';

    const APP = {
        workflow:  null,         // 'classic' | 'epw' | 'sscha'  (3 WF indépendants)
        material:  '',
        structure: null,
        files:     null,         // { classic:{...}, epw:{...}, sscha:{...} }
        baseDir:   '',           // inputs/<material>
        apiOnline: false,
        cpuCount:  navigator.hardwareConcurrency || 4,
        mainView:  'guide',       // 'guide' | 'calculs' | 'resultats' | 'help'
        prereq:    { relaxDone: false, relaxFound: false, relaxJobDone: false,
                     scfDone: false, relaxPath: '', scfPath: '' },
        chain:     null,          // état vérifié des étapes du workflow actif
        chainError: null,
    };

    function getWorkflowPaths() {
        const wf  = APP.workflow || 'classic';
        const mat = APP.material || '';
        const inputMat = (txt('fld_path_inputs', mat ? `inputs/${mat}` : 'inputs') || '').replace(/\/$/, '');
        const workDir  = (txt('fld_path_workflow', `${inputMat}/${wf}`) || `${inputMat}/${wf}`).replace(/\/$/, '');
        const outputDir = (txt('fld_path_outputs', `outputs/${mat}/${wf}`) || `outputs/${mat}/${wf}`).replace(/\/$/, '');
        return { inputMat, workDir, outputDir };
    }

    /**
     * Scroll prudent (Chrome scrollIntoView(block:'start') fait souvent
     * disparaître la barre d'onglets et donne l'impression d'un bug d'affichage).
     */
    function scrollToView(target, opts = {}) {
        const el = typeof target === 'string' ? $(target) : target;
        if (!el) return;
        const navH = ($('.app-nav-bar')?.offsetHeight || 72) + 12;
        const r = el.getBoundingClientRect();
        const vh = window.innerHeight || document.documentElement.clientHeight;
        const fullyVisible = r.top >= navH && r.bottom <= vh - 8;
        if (fullyVisible && !opts.force) return;
        const block = opts.block || 'nearest';
        try {
            el.scrollIntoView({ behavior: opts.behavior || 'smooth', block, inline: 'nearest' });
        } catch (_) {
            el.scrollIntoView(true);
        }
        // Si Chrome a trop remonté : garder la barre d'onglets dans le viewport
        requestAnimationFrame(() => {
            const nav = $('.app-nav-bar');
            if (!nav) return;
            const nr = nav.getBoundingClientRect();
            if (nr.top < 0) {
                window.scrollBy({ top: nr.top - 4, left: 0, behavior: 'auto' });
            }
        });
    }

    function getMaterialBaseDir() {
        const mat = APP.material || '';
        return (txt('fld_path_inputs', mat ? `inputs/${mat}` : 'inputs') || '').replace(/\/$/, '');
    }

    function syncMaterialPathField() {
        if (!APP.material) return;
        const fi = $('#fld_path_inputs');
        const path = `inputs/${APP.material}`;
        if (fi && !fi.dataset.touched) fi.value = path;
        APP.baseDir = getMaterialBaseDir();
        updatePrereqExpectedLabels();
    }

    function updatePrereqExpectedLabels() {
        const mat = APP.material || 'Materiau';
        const base = getMaterialBaseDir() || `inputs/${mat}`;
        const set = (id, t) => { const el = $(id); if (el) el.textContent = t; };
        set('#prereqDefaultDir', `${base}/`);
        set('#prereqExpectedRelax', `${mat}.vc-relax.out`);
        set('#prereqExpectedScf', `${mat}.scf.out`);
        set('#prereqExpectedScfAlt', `${mat}.scf_prereq.out`);
    }

    function updatePathFields() {
        if (!APP.material || !APP.workflow) return;
        syncMaterialPathField();
        const inputMat = APP.baseDir || `inputs/${APP.material}`;
        const fw = $('#fld_path_workflow');
        const fo = $('#fld_path_outputs');
        // Ne pas écraser un chemin saisi à la main (autre PC / autre dossier).
        if (fw && !fw.dataset.touched) fw.value = `${inputMat}/${APP.workflow}`;
        if (fo && !fo.dataset.touched) fo.value = `outputs/${APP.material}/${APP.workflow}`;
    }

    function invalidateWorkflowFiles() {
        APP.files = null;
    }

    function renderWorkflowBanner() {
        const box = $('#wfActiveBanner');
        if (!box || !APP.workflow) { if (box) box.style.display = 'none'; return; }
        const L = WORKFLOW_LABEL[APP.workflow];
        const n = calcStepsForRun(APP.workflow).length;
        box.style.display = 'block';
        box.innerHTML = `
            <div class="pipeline-block ${APP.workflow}" style="padding:14px 18px; margin:0;">
                <strong style="color:${L.stepColor};">${L.id} — ${L.name}</strong>
                <span class="muted"> — ${n} programme(s) · dossier <code>inputs/${APP.material}/${APP.workflow}/</code></span>
                ${APP.workflow === 'sscha' ? '<br><span class="muted" style="font-size:0.9em;">Exécution automatique SSCHA : intégration API en cours.</span>' : ''}
            </div>`;
    }

    /* ====================================================================
     *  Définition des programmes par workflow (style Interface-QE_v1)
     * ==================================================================== */
    const CALCS = {
        classic: [
            { type:'scf',     num:1,   icon:'🌌', prog:'pw.x',     nom:'SCF métallique',
              section:'scf',
              desc:'Densité électronique de référence dans le dossier du workflow — indispensable avant le NSCF dense (le SCF prérequis externe ne partage pas cet outdir).',
              reco:['Smearing MV, degauss ≈ 0.02 Ry','Grille k ≈ 12 × 12 × 12','Crée outdir utilisé par NSCF et ph.x'] },
            { type:'nscf',    num:2,   icon:'⚡', prog:'pw.x',     nom:'NSCF dense',
              section:'nscf',
              desc:'Cartographie dense de la surface de Fermi (k_nscf très dense).',
              reco:['Grille k ≥ 16 × 16 × 16 (24³ recommandé)','la2F = .true. (auto)','Ratio k/q doit être entier'] },
            { type:'ph',      num:3,   icon:'🎵', prog:'ph.x',     nom:'Phonons + e-p',
              section:'phonon',
              desc:'DFPT : matrice dynamique + éléments de matrice du couplage électron-phonon.',
              reco:['Grille q ≈ 4 × 4 × 4','tr2_ph = 1.0d-12','electron_phonon = interpolated','Calcul le plus long'] },
            { type:'q2r',     num:'4a', icon:'🔄', prog:'q2r.x',    nom:'q2r.x — IFC',
              section:'matdyn',
              desc:'Transforme la matrice dynamique en constantes de force en espace réel.',
              reco:['Très rapide (< 1 min)','Utilise les fichiers dyn produits par ph.x','Aucun paramètre critique'] },
            { type:'matdyn',  num:'4b', icon:'🎯', prog:'matdyn.x', nom:'matdyn.x → α²F, λ',
              section:'matdyn',
              desc:'DOS phononique + α²F(ω) / λ si la2F=.true. (QE 7). μ* et Tc : onglet Résultats.',
              reco:['la2F = .true.','grille q DOS dense (nk1–3)','μ* et Tc dans Résultats (pas dans matdyn.in)'] },
        ],
        // Ordre canonique EPW (docs.epw-code.org) : scf → ph (dvscf) → save/ → nscf → epw
        epw: [
            { type:'scf',  num:1, icon:'🌌', prog:'pw.x', nom:'SCF métallique',
              section:'scf',
              desc:'Densité électronique de référence dans le dossier du workflow — base de ph.x puis du NSCF coarse.',
              reco:['Smearing MV, degauss ≈ 0.02 Ry','Grille k ≈ 8 × 8 × 8','Doit tourner avant ph.x'] },
            { type:'ph',   num:2, icon:'🎵', prog:'ph.x', nom:'Phonons + dvscf (avant NSCF)',
              section:'phonon',
              desc:'DFPT sur grille q coarse ; sauvegarde des matrices dynamiques et du potentiel perturbé lus ensuite par epw.x.',
              reco:['Grille q ≈ 4 × 4 × 4','fildvscf sauvegardé (.dvscf)','fildyn sauvegardé (.dyn)','À lancer AVANT le NSCF (le NSCF écrase les fonctions d\'onde)'] },
            { type:'nscf', num:3, icon:'⚡', prog:'pw.x', nom:'NSCF coarse + nbnd',
              section:'nscf',
              desc:'Grille k coarse uniforme et nbnd élevé pour la wannierisation — après ph.x et le regroupement dans save/.',
              reco:['Grille k modérée (8³ ou 6³)','nbnd élevé obligatoire (≥ 30 pour 1 espèce)','Pas de la2F','Doit matcher nkc de epw.in'] },
            { type:'epw',  num:4, icon:'⚛️', prog:'epw.x', nom:'epw.x → Tᶜ + Δ',
              section:'epw',
              desc:'Wannierisation + Fourier des e-p + interpolation grille géante + Éliashberg.',
              reco:['nbndsub ≈ orbitales actives','Fenêtres dis_win, dis_froz ajustées','μc = 0.10','Grilles fines 40 × 40 × 40','Sortie Tᶜ + Δ(T)'] },
        ],
        sscha: [
            { type:'config',    num:1, icon:'🎲', prog:'script',  nom:'Générateur de configurations',
              section:'sscha_config',
              desc:'Crée N supercellules déplacées aléatoirement (base anharmonique).',
              reco:['64–128 configurations typiques','Amplitude déplacement ~0.05–0.1 Å','Supercellule 2×2×2 ou plus'] },
            { type:'pw_forces', num:2, icon:'💪', prog:'pw.x',    nom:'pw.x — forces (boucle)',
              section:'sscha_pw',
              desc:'SCF + forces atomiques (tprnfor) sur chaque configuration générée.',
              reco:['tprnfor = .true.','Grille k adaptée à la supercellule','Parallélisable MPI sur les configs'] },
            { type:'sscha',     num:3, icon:'🌡️', prog:'SSCHA',  nom:'SSCHA → phonons corrigés',
              section:'sscha_module',
              desc:'Minimisation de l\'énergie libre · fréquences phonons corrigées · α²F(ω).',
              reco:['Température cible (K)','Convergence itérative','μ* pour estimation Tᶜ post-SSCHA'] },
        ],
    };

    const WORKFLOW_LABEL = {
        classic: { name: 'Workflow Classique', letter: 'A', color: 'var(--supra)',  stepColor: 'var(--supra-dark)',  id: 'WF1' },
        epw:     { name: 'Workflow EPW',       letter: 'B', color: 'var(--epw)',    stepColor: 'var(--epw-dark)',    id: 'WF2' },
        sscha:   { name: 'Workflow SSCHA',     letter: 'C', color: 'var(--sscha)', stepColor: 'var(--sscha-dark)', id: 'WF3' },
    };

    const WF_CSS = { classic: 'classic', epw: 'epw', sscha: 'sscha' };
    function wfCss(wf) { return WF_CSS[wf] || wf; }

    function branchTagVisible(wf, tag) {
        if (!wf || !tag) return false;
        if (tag === 'sscha' && window.SupraConfig && !window.SupraConfig.ENABLE_SSCHA) return false;
        if (tag === 'harmonic') return wf === 'classic' || wf === 'epw';
        return tag === wf;
    }

    /** Étapes de la chaîne automatique (les étapes optionnelles restent manuelles). */
    function calcStepsForRun(wf) {
        if (!wf || !CALCS[wf]) return [];
        return CALCS[wf].filter(c => !c.optional);
    }

    function calcByType(wf, type) {
        return (CALCS[wf] || []).find(c => c.type === type) || null;
    }

    /* ====================================================================
     *  Chaîne de calculs : dépendances et vérification pas à pas
     *
     *  Chaque étape n'est lançable que si les étapes amont sont terminées
     *  (« JOB DONE » dans leur .out) et si leurs fichiers intermédiaires
     *  attendus existent réellement dans le dossier du workflow.
     * ==================================================================== */
    const STEP_CHAIN = {
        classic: {
            scf:     { deps: [] },
            nscf:    { deps: ['scf'] },
            ph:      { deps: ['nscf'] },
            q2r:     { deps: ['ph'],     needs: ['fildyn'] },
            matdyn:  { deps: ['q2r'],    needs: ['flfrc'] },
        },
        epw: {
            scf:  { deps: [] },
            ph:   { deps: ['scf'] },
            nscf: { deps: ['ph'] },
            epw:  { deps: ['nscf'], needs: ['epwSave'] },
        },
    };

    /** Fichiers intermédiaires attendus, tels que nommés dans les inputs générés. */
    function chainArtifact(key) {
        const wd = getWorkflowPaths().workDir;
        switch (key) {
            case 'fildyn': {
                const base = txt('fld_fildyn', 'matdyn') || 'matdyn';
                return { path: `${wd}/${base}0`, label: `matrices dynamiques <code>${base}0</code>`,
                         from: 'ph', fix: 'Relance ph.x : les fichiers dyn sont produits dans le dossier du workflow.' };
            }
            case 'flfrc': {
                const base = txt('fld_flfrc', 'ifc.fc') || 'ifc.fc';
                return { path: `${wd}/${base}`, label: `constantes de force <code>${base}</code>`,
                         from: 'q2r', fix: 'Relance q2r.x pour reconstruire les IFC en espace réel.' };
            }
            case 'fila2F': {
                const base = txt('fld_fila2F', 'a2F.dat') || 'a2F.dat';
                return { path: `${wd}/${base}`, label: `α²F brut <code>${base}</code>`,
                         from: 'matdyn', fix: 'Relance matdyn.x (la2F = .true.) pour écrire α²F.' };
            }
            case 'epwSave':
                return { path: `${wd}/save`, dir: true,
                         label: 'dossier <code>save/</code> (dvscf + dyn regroupés)',
                         from: 'ph', manual: true,
                         fix: 'Regroupe les sorties de ph.x avec <code>pp.py</code> (bouton 🖥️ Terminal de l\'étape epw.x) avant de lancer epw.x.' };
            default:
                return null;
        }
    }

    /** Chemin où l'interface écrit la sortie de l'étape. */
    function stepOutPath(step) {
        if (!APP.material) return '';
        return `${getWorkflowPaths().outputDir}/${APP.material}.${step}.out`;
    }

    /**
     * Emplacements acceptés pour la sortie d'une étape : celui utilisé par
     * l'interface, mais aussi le dossier de calcul lui-même — un `.out` produit
     * à la main dans ce dossier doit compter comme étape faite, sinon la chaîne
     * bloquerait un travail déjà réalisé hors interface.
     */
    function stepOutCandidates(step) {
        if (!APP.material) return [];
        const paths = getWorkflowPaths();
        const name = `${APP.material}.${step}.out`;
        return [`${paths.outputDir}/${name}`, `${paths.workDir}/${name}`];
    }

    /**
     * Interroge l'API une seule fois pour connaître l'état réel de toutes les
     * étapes du workflow actif (sortie présente, JOB DONE, erreur QE) et de
     * leurs fichiers intermédiaires.
     *
     * Retourne null si l'état ne peut pas être établi (API hors-ligne ou plus
     * ancienne que /api/file/stat) : dans ce cas la chaîne ne bloque rien.
     */
    async function inspectChain(wf = APP.workflow) {
        const chain = STEP_CHAIN[wf];
        APP.chainError = null;
        if (!wf || !chain || !APP.material || !APP.apiOnline) {
            APP.chain = null;
            return null;
        }

        const steps = Object.keys(chain);
        const paths = [];
        steps.forEach(s => stepOutCandidates(s).forEach(p => paths.push(p)));
        const artifacts = {};
        steps.forEach(s => (chain[s].needs || []).forEach(key => {
            if (artifacts[key]) return;
            const a = chainArtifact(key);
            if (a) { artifacts[key] = a; paths.push(a.path); }
        }));

        const r = await SupraAPI.statFiles(paths);
        if (!r?.ok) {
            APP.chain = null;
            APP.chainError = r?.status === 404
                ? "L'API en cours d'exécution est antérieure à cette interface (endpoint /api/file/stat absent). Redémarre-la avec ./DEMARRER.sh pour activer la vérification pas à pas."
                : `Vérification impossible : ${r?.error || 'API injoignable'}.`;
            return null;
        }
        const stat = r.results || {};

        const state = {};
        steps.forEach(s => {
            const infos = stepOutCandidates(s).map(p => ({ path: p, ...(stat[p] || {}) }));
            const done = infos.find(i => i.job_done);
            const present = infos.find(i => i.exists);
            state[s] = {
                out: done?.path || present?.path || stepOutPath(s),
                exists: !!present,
                done: !!done,
                failed: !done && !!present && (!!present.has_error || present.size > 0),
                size: present?.size || 0,
            };
        });
        const artifactState = {};
        Object.entries(artifacts).forEach(([key, a]) => {
            const info = stat[a.path] || {};
            artifactState[key] = { ...a, exists: !!info.exists };
        });

        APP.chain = { wf, steps: state, artifacts: artifactState, at: Date.now() };
        return APP.chain;
    }

    /** Blocages empêchant de lancer `step` : étapes amont et fichiers manquants. */
    function chainBlockers(step, wf = APP.workflow, chainState = APP.chain) {
        const spec = STEP_CHAIN[wf]?.[step];
        if (!spec) return [];
        if (!chainState || chainState.wf !== wf) {
            // Fail-closed si l'API est en ligne mais /stat a échoué
            if (APP.apiOnline && APP.chainError) {
                return [{
                    kind: 'chain',
                    label: 'vérification de la chaîne indisponible',
                    detail: APP.chainError,
                }];
            }
            return [];
        }
        const blockers = [];
        const calc = calcByType(wf, step);
        if (calc && binaryAvailable(calc.prog) === false) {
            blockers.push({
                kind: 'binary', manual: true,
                label: `binaire <code>${calc.prog}</code> introuvable`,
                detail: 'installe-le ou définis <code>QE_BIN_DIR</code>, ou lance cette étape via 🖥️ Terminal sur une machine qui l\'a.',
            });
        }
        (spec.deps || []).forEach(dep => {
            const st = chainState.steps?.[dep];
            if (st && st.done) return;
            const c = calcByType(wf, dep);
            blockers.push({
                kind: 'step', step: dep,
                label: `étape ${c?.num ?? ''} — ${c?.nom || dep} (${c?.prog || ''})`,
                detail: st?.failed
                    ? `sortie présente mais sans « JOB DONE » : <code>${st.out}</code>`
                    : `aucune sortie terminée : <code>${st?.out || stepOutPath(dep)}</code>`,
            });
        });
        (spec.needs || []).forEach(key => {
            const a = chainState.artifacts?.[key];
            if (!a || a.exists) return;
            blockers.push({ kind: 'file', label: a.label, detail: a.fix, manual: !!a.manual });
        });
        return blockers;
    }

    /** État d'une étape : 'done' | 'failed' | 'ready' | 'blocked'. */
    function stepState(step, wf = APP.workflow, chainState = APP.chain) {
        const st = chainState?.steps?.[step];
        if (st?.done) return 'done';
        if (st?.failed) return 'failed';
        return chainBlockers(step, wf, chainState).length ? 'blocked' : 'ready';
    }

    /** Première étape non terminée de la chaîne (prochaine action conseillée). */
    function nextChainStep(wf = APP.workflow) {
        return calcStepsForRun(wf).find(c => stepState(c.type, wf) !== 'done') || null;
    }

    const CHAIN_BADGE = {
        done:    { cls: 'ok',   txt: '✅ terminé' },
        failed:  { cls: 'err',  txt: '❌ échec' },
        ready:   { cls: 'warn', txt: '⏳ à lancer' },
        blocked: { cls: '',     txt: '🔒 en attente' },
    };

    async function refreshChainStatus() {
        const box = $('#zoneChainStatus');
        if (!box) return;
        if (!APP.workflow) { box.style.display = 'none'; box.innerHTML = ''; return; }
        box.style.display = 'block';

        if (!APP.material) {
            box.innerHTML = alertBox('warning', 'Valide un matériau pour vérifier l\'enchaînement des calculs.');
            return;
        }
        if (!APP.apiOnline) {
            box.innerHTML = alertBox('warning',
                'API hors-ligne : impossible de vérifier l\'état des étapes. Lance <code>./DEMARRER.sh</code> puis « ↻ API ».');
            return;
        }

        await inspectChain();
        updateResultatsEmptyState();
        if (!APP.chain) {
            box.innerHTML = alertBox('error',
                (APP.chainError || 'Vérification de la chaîne indisponible.') +
                ' Les lancements automatiques sont bloqués tant que la vérification ne répond pas — ' +
                'relance <code>./DEMARRER.sh</code> ou utilise 🖥️ Terminal en connaissance de cause.');
            return;
        }
        renderChainStatus();
    }

    function renderChainStatus() {
        const box = $('#zoneChainStatus');
        const wf = APP.workflow;
        if (!box || !wf || !APP.chain || APP.chain.wf !== wf) return;

        const steps = calcStepsForRun(wf);
        const rows = steps.map(c => {
            const state = stepState(c.type, wf);
            const badge = CHAIN_BADGE[state] || CHAIN_BADGE.blocked;
            const blockers = state === 'blocked' || state === 'failed' ? chainBlockers(c.type, wf) : [];
            const why = blockers.length
                ? `<div class="chain-why">Attend : ${blockers.map(b => b.label).join(' · ')}</div>`
                : '';
            return `
                <li class="chain-row" data-state="${state}">
                    <span class="chain-num">${c.num}</span>
                    <span class="chain-name">${c.icon} ${c.nom} <span class="muted">(${c.prog})</span>${why}</span>
                    <span class="badge-status ${badge.cls}">${badge.txt}</span>
                </li>`;
        }).join('');

        const next = nextChainStep(wf);
        const allDone = !next;
        let foot;
        if (allDone) {
            foot = `<div class="chain-foot ok">🎉 Chaîne complète — passe à l'onglet <strong>Résultats</strong> pour lire Tᶜ.</div>`;
        } else {
            const state = stepState(next.type, wf);
            const blockers = chainBlockers(next.type, wf);
            if (state === 'ready') {
                foot = `<div class="chain-foot">Prochaine étape : <strong>${next.num} — ${next.nom}</strong> (${next.prog}).</div>`;
            } else {
                foot = `<div class="chain-foot warn">
                    <strong>${next.num} — ${next.nom}</strong> est bloquée :
                    <ul>${blockers.map(b => `<li>${b.label}${b.detail ? ` — ${b.detail}` : ''}</li>`).join('')}</ul>
                </div>`;
            }
        }

        box.innerHTML = `
            <div class="chain-status ${wfCss(wf)}">
                <div class="chain-head">
                    <strong>Vérification de l'enchaînement — ${WORKFLOW_LABEL[wf].name}</strong>
                    <button type="button" class="btn btn-secondary btn-toolbar" id="btnRefreshChain">↻ Revérifier</button>
                </div>
                <ol class="chain-list">${rows}</ol>
                ${foot}
            </div>`;
        $('#btnRefreshChain')?.addEventListener('click', async () => {
            await refreshChainStatus();
            syncPipelineFromChain();
        });
        syncPipelineFromChain();
    }

    /** Reporte l'état réel des sorties sur le pipeline et les cartes de calcul. */
    function syncPipelineFromChain() {
        const wf = APP.chain?.wf;
        if (!wf || wf !== APP.workflow) return;
        Object.keys(STEP_CHAIN[wf] || {}).forEach(step => {
            const state = stepState(step, wf);
            if (state === 'done')        setCalcState(step, 'completed', 'OK');
            else if (state === 'failed') setCalcState(step, 'error', 'échec');
            else if (state === 'ready')  setCalcState(step, 'ready', 'à lancer');
            else                         setCalcState(step, 'idle', 'en attente');
        });
    }

    /**
     * Prérequis strictement nécessaire au workflow : la structure relaxée
     * (vc-relax.out). Le SCF externe n'est qu'un contrôle : chaque workflow
     * relance son propre SCF dans son dossier, seul moyen d'avoir un `outdir`
     * cohérent pour le NSCF et ph.x.
     */
    function prereqsReady() {
        return !!APP.prereq?.relaxDone;
    }

    const RESULT_READ_BTN_SEL = [
        '#btnExploreResults', '#btnExportCsv', '#btnExportLatex', '#btnExportReport',
    ];

    function setResultReadButtonsEnabled(enabled) {
        RESULT_READ_BTN_SEL.forEach(sel => {
            const btn = $(sel);
            if (btn) btn.disabled = !enabled;
        });
    }

    function updateResultatsEmptyState() {
        const box = $('#resultatsEmptyState');
        if (!box) return;

        const inResultats = APP.mainView === 'resultats';
        const canRead = !!APP.material;
        setResultReadButtonsEnabled(canRead);

        // Une exploration réussie remplace le bandeau pédagogique.
        if (!inResultats || (APP.material && typeof RES !== 'undefined' && RES.data)) {
            box.style.display = 'none';
            return;
        }
        box.style.display = 'block';

        if (!APP.material) {
            box.className = 'alert alert-warning';
            box.innerHTML = 'Aucun matériau validé. Saisis et valide un matériau (étape 1), choisis un workflow, puis lance les calculs ou dépose les fichiers <code>.out</code> dans <code>outputs/</code>.';
            return;
        }
        // L'exploration couvre les deux voies : un workflow actif n'est pas requis,
        // il ne sert qu'à préciser l'avancement affiché.
        const wf = APP.workflow ? WORKFLOW_LABEL[APP.workflow] : null;
        const chain = (APP.workflow && APP.chain?.wf === APP.workflow) ? APP.chain : null;
        const steps = APP.workflow ? calcStepsForRun(APP.workflow) : [];
        const done = chain ? steps.filter(c => chain.steps[c.type]?.done) : [];
        const last = steps.slice(-1)[0];
        const scanned = `<code>outputs/${APP.material}/classic/</code> et <code>outputs/${APP.material}/epw/</code>`;

        if (wf && done.length && last && chain.steps[last.type]?.done) {
            box.className = 'alert alert-success';
            box.innerHTML = `Matériau <strong>${APP.material}</strong> · ${wf.name} — chaîne complète `
                + `(${done.length}/${steps.length} étapes). Lance <strong>🔎 Explorer tous les résultats</strong> `
                + `pour extraire λ, ω_log, ⟨ω²⟩^½, N(E_F), Δ₀ et Tᶜ(μ*) des deux voies.`;
            return;
        }
        box.className = 'alert alert-info';
        const progress = wf
            ? (done.length
                ? `${wf.name} : ${done.length}/${steps.length} étape(s) terminée(s), l'étape finale `
                  + `(<code>${last?.prog || '—'}</code>) n'est pas encore passée. `
                : `${wf.name} : aucun calcul terminé pour l'instant. `)
            : '';
        box.innerHTML = `Matériau <strong>${APP.material}</strong> — ${progress}`
            + `L'exploration balaie ${scanned} (ainsi que les dossiers <code>inputs/</code> correspondants) `
            + `et exploite tout ce qu'elle y trouve : lance la chaîne dans l'onglet <strong>Calculs</strong>, `
            + `ou copie tes sorties QE à cet emplacement.`;
    }

    function updateWorkflowActionButtons() {
        const ready = prereqsReady();
        ['#btnGenerateAll', '#btnRunWorkflow'].forEach(sel => {
            const btn = $(sel);
            if (!btn) return;
            btn.disabled = !ready;
            btn.title = ready ? '' : 'Structure relaxée requise : vc-relax.out validé (section ①).';
        });
        const gate = $('#prereqLaunchGate');
        if (gate) gate.style.display = ready ? 'none' : 'block';
    }

    /** Flux : onglet Calculs ou Résultats → matériau → WF → panneau WF */
    function updateFluxEtapes() {
        const hasMat = !!APP.material;
        const hasWf  = !!APP.workflow;
        const mode   = APP.mainView === 'resultats' ? 'resultats' : 'calculs';

        const etape2 = $('#zoneEtapeCalculs');
        const etape3 = $('#zoneWorkflowActif');
        const lock   = $('#etape1LockHint');
        const resGate = $('#resultatsGate');
        const hint   = $('#wfPickHint');
        const pseudo = $('#zoneEtapePseudo');
        const needMat = $('#resultatsNeedMat');
        const picker = $('#workflowPicker');

        if (mode === 'resultats') {
            // Matériau suffit pour explorer ; le WF n'indique que l'avancement.
            if (etape2) etape2.style.display = hasMat ? 'block' : 'none';
            if (etape3) {
                etape3.style.display = hasMat ? 'block' : 'none';
                etape3.classList.toggle('is-visible', hasMat);
            }
            if (lock)    lock.style.display = 'none';
            if (resGate) resGate.style.display = hasMat ? 'none' : 'block';
            if (hint) {
                hint.style.display = 'none';
                hint.innerHTML = '👆 Choisis <strong>Workflow Classique (WF1)</strong> ou <strong>Workflow EPW (WF2)</strong>.';
            }
            if (pseudo) pseudo.style.display = 'none';
            if (needMat) needMat.style.display = 'none';
            if (hasMat) {
                const title = $('#etapeWorkflowTitle');
                if (title) {
                    title.textContent = hasWf
                        ? `« ${APP.material} » — résultats (${WORKFLOW_LABEL[APP.workflow]?.name || APP.workflow} actif)`
                        : `« ${APP.material} » — résultats des deux voies`;
                }
            }
        } else {
            if (etape2) etape2.style.display = hasMat ? 'block' : 'none';
            if (etape3) {
                const show = hasMat && hasWf;
                etape3.style.display = show ? 'block' : 'none';
                etape3.classList.toggle('is-visible', show);
            }
            if (lock)    lock.style.display = hasMat ? 'none' : 'block';
            if (resGate) resGate.style.display = 'none';
            if (hint) {
                hint.style.display = (hasMat && !hasWf) ? 'block' : 'none';
                hint.innerHTML = '👆 Choisis <strong>Workflow Classique (WF1)</strong> ou <strong>Workflow EPW (WF2)</strong>.';
            }
            if (pseudo) pseudo.style.display = hasMat ? 'block' : 'none';
            if (needMat) needMat.style.display = 'none';
            if (hasMat && !hasWf) {
                const title = $('#etapeWorkflowTitle');
                if (title) title.textContent = `« ${APP.material} » — choisis un workflow`;
            }
        }

        if (picker) picker.classList.toggle('is-picked', hasWf);
        updateSessionProgress();

        const etape1 = $('#zoneEtape1');
        if (etape1) etape1.dataset.ready = hasMat ? 'true' : 'false';

        updateMainViewBanner();
        applyMainViewPart();
        updatePrereqFlowChart();
        updateResultatsEmptyState();
        updateWorkflowActionButtons();
    }

    function updateMainViewBanner() {
        const el = $('#mainViewBannerText');
        if (!el) return;
        if (APP.mainView === 'resultats') {
            el.innerHTML = '<strong>Mode Résultats</strong> — valide le matériau si besoin, puis explore Tᶜ, λ, α²F(ω) et le gap des deux voies.';
        } else if (APP.mainView === 'calculs') {
            el.innerHTML = '<strong>Mode Calculs</strong> — valide le matériau, configure les pseudos (1b), choisis un workflow, puis lance les calculs.';
        } else {
            el.innerHTML = '';
        }
    }

    function applyMainViewPart() {
        const part = APP.mainView === 'resultats' ? 'resultats' : 'calculs';
        setWfPart(part);
    }

    function setWfPart(part) {
        const calculs = $('#zoneWfCalculs');
        const resultats = $('#zoneWfResultats');
        if (calculs) calculs.classList.toggle('active', part === 'calculs');
        if (resultats) resultats.classList.toggle('active', part === 'resultats');
    }

    function updateNavToolbarVisibility() {
        const isHelp = APP.mainView === 'help';
        const isGuide = APP.mainView === 'guide';
        // Tout déplier / replier : utiles sur Calculs/Résultats (~19 cartes) et Aide ;
        // inutiles sur le Guide (pas de sections à gérer).
        $('#navCollapseApp')?.classList.toggle('hidden', isHelp || isGuide);
        $('#navCollapseHelp')?.classList.toggle('hidden', !isHelp);
        $('#mainViewBanner')?.classList.toggle('hidden', isHelp || isGuide);

        const guideBtn = $('#btnToggleUsageGuide');
        if (guideBtn) {
            guideBtn.classList.toggle('active', isGuide);
            guideBtn.setAttribute('aria-selected', isGuide ? 'true' : 'false');
            guideBtn.setAttribute('aria-expanded', isGuide ? 'true' : 'false');
            guideBtn.textContent = isGuide ? '📖 Guide' : '📖 Guide';
        }
        $$('.view-tab').forEach(t => {
            const on = t.dataset.tab === APP.mainView;
            t.classList.toggle('active', on);
            t.setAttribute('aria-selected', on ? 'true' : 'false');
        });
    }

    function switchMainView(view) {
        APP.mainView = view;
        document.body.dataset.mainView = view || '';

        const guidePanel = $('#usageGuidePanel');
        if (guidePanel) guidePanel.classList.toggle('hidden', view !== 'guide');

        $$('.tab-content').forEach(c => {
            const id = c.dataset.tabContent;
            const show = id === view || (id === 'app' && (view === 'calculs' || view === 'resultats'));
            c.classList.toggle('active', show);
        });
        updateNavToolbarVisibility();
        updateMainViewBanner();
        if (view === 'calculs' || view === 'resultats') {
            applyMainViewPart();
            updateFluxEtapes();
            updateResultatsEmptyState();
            // Force un reflow pour que display:block prenne effet avant le scroll
            void $('#zoneAppFlow')?.offsetHeight;
            let scrollTarget = null;
            if (view === 'resultats') {
                if (!APP.material) scrollTarget = '#resultatsGate';
                else if ($('#zoneWorkflowActif')?.style.display !== 'none') scrollTarget = '#zoneWfResultats';
                else scrollTarget = '#zoneEtape1';
                // Auto-exploration dès qu'un matériau est validé
                if (APP.material && APP.apiOnline && !RES.busy) {
                    window.setTimeout(() => exploreResults(), 80);
                }
            } else if (APP.workflow && $('#zoneWorkflowActif')?.style.display !== 'none') {
                scrollTarget = '#zoneWfCalculs';
            } else {
                scrollTarget = '#zoneEtape1';
            }
            scrollToView(scrollTarget, { block: 'nearest' });
        } else if (view === 'help') {
            scrollToView('.tab-content[data-tab-content="help"]', { block: 'nearest' });
        } else if (view === 'guide') {
            scrollToView('#usageGuidePanel', { block: 'nearest' });
        }
    }

    function toggleUsageGuide(forceOpen) {
        // Le Guide est un onglet à part entière : ouvrir = y aller, fermer = retour Calculs.
        if (typeof forceOpen === 'boolean') {
            switchMainView(forceOpen ? 'guide' : 'calculs');
            return;
        }
        switchMainView(APP.mainView === 'guide' ? 'calculs' : 'guide');
    }

    function bindUsageGuide() {
        $('#btnToggleUsageGuide')?.addEventListener('click', () => switchMainView('guide'));
        $('#btnGuideGoCalculs')?.addEventListener('click', () => switchMainView('calculs'));
        $('#btnGuideGoResultats')?.addEventListener('click', () => switchMainView('resultats'));
    }

    function highlightOrganigram(wf) {
        $$('.org-branch[data-wf]').forEach(b => {
            b.classList.toggle('active', wf != null && b.dataset.wf === wf);
        });
    }

    /** Affichage conditionnel : masque les paramètres des autres voies. */
    function applyBranchVisibility(wf) {
        $$('[data-wf-visible]').forEach(el => {
            if (el.classList.contains('wf-param-tabs')) return;
            const v = el.dataset.wfVisible;
            el.style.display = branchTagVisible(wf, v) ? '' : 'none';
        });

        const tabsClassic = $('#wfParamTabsClassic');
        const tabsEpw = $('#wfParamTabsEpw');
        const tabsSscha = $('#wfParamTabsSscha');
        if (tabsClassic) tabsClassic.style.display = wf === 'classic' ? 'flex' : 'none';
        if (tabsEpw) tabsEpw.style.display = wf === 'epw' ? 'flex' : 'none';
        if (tabsSscha) tabsSscha.style.display = wf === 'sscha' ? 'flex' : 'none';

        $$('.pipelines-dual').forEach(dual => {
            const blocks = $$('.pipeline-block[data-wf-visible]', dual)
                .filter(b => b.style.display !== 'none');
            dual.style.gridTemplateColumns = blocks.length <= 1 ? '1fr' : '';
        });

        updateKQVisual();
    }

    function focusParamSection(section) {
        if (!section) return;
        const card = $(`.card.collapsible[data-section="${section}"]`);
        if (!card || card.style.display === 'none') return;
        setCollapsibleOpen(card, true);
        scrollToView(card, { block: 'nearest' });
    }

    function bindBranchSubTabs() {
        $$('.wf-param-tab').forEach(tab => {
            if (tab._boundBranchTab) return;
            tab._boundBranchTab = true;
            tab.addEventListener('click', (e) => {
                e.preventDefault();
                const bar = tab.closest('.wf-param-tabs');
                bar?.querySelectorAll('.wf-param-tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                focusParamSection(tab.dataset.section);
            });
        });
    }

    function resetBranchSubTabs(wf) {
        const barId = { classic: 'wfParamTabsClassic', epw: 'wfParamTabsEpw', sscha: 'wfParamTabsSscha' }[wf];
        const bar = barId ? $('#' + barId) : null;
        if (!bar) return;
        bar.querySelectorAll('.wf-param-tab').forEach((t, i) => t.classList.toggle('active', i === 0));
        focusParamSection(bar.querySelector('.wf-param-tab.active')?.dataset.section);
    }

    /* ====================================================================
     *  Helpers DOM
     * ==================================================================== */
    const $  = (sel, ctx = document) => ctx.querySelector(sel);
    const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

    function el(tag, attrs = {}, ...children) {
        const node = document.createElement(tag);
        Object.entries(attrs || {}).forEach(([k, v]) => {
            if (k === 'class')       node.className = v;
            else if (k === 'style')  node.style.cssText = v;
            else if (k === 'html')   node.innerHTML = v;
            else if (k.startsWith('on') && typeof v === 'function')
                node.addEventListener(k.slice(2), v);
            else node.setAttribute(k, v);
        });
        children.flat().forEach(c => {
            if (c == null) return;
            node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
        });
        return node;
    }

    const alertBox = (kind, html) => `<div class="alert alert-${kind}">${html}</div>`;
    const num   = (id, fb = 0)   => { const v = parseFloat($('#' + id)?.value); return Number.isFinite(v) ? v : fb; };
    const intv  = (id, fb = 0)   => { const v = parseInt($('#' + id)?.value, 10); return Number.isFinite(v) ? v : fb; };
    const txt   = (id, fb = '')  => $('#' + id)?.value ?? fb;
    const parseQENum = s => typeof s !== 'string' ? Number(s) : Number(s.replace(/d/i, 'e'));

    /* ====================================================================
     *  Onglets + cartes pliables
     * ==================================================================== */
    function bindTabs() {
        $$('.view-tab').forEach(t => t.addEventListener('click', () => switchMainView(t.dataset.tab)));
    }

    /** Carte auteur : survol géré en CSS, clic pour la garder ouverte (tactile). */
    function bindAuthorCard() {
        const btn = $('#btnAuthorCard');
        const card = $('#shAuthorCard');
        const brand = btn?.closest('.sh-header-brand');
        if (!btn || !card) return;

        const setOpen = open => {
            card.classList.toggle('open', !!open);
            brand?.setAttribute('data-open', open ? 'true' : 'false');
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        };
        btn.addEventListener('click', ev => {
            ev.preventDefault();
            ev.stopPropagation();
            setOpen(!card.classList.contains('open'));
        });
        // Fermer au clic extérieur (après le clic courant, pour éviter la course).
        document.addEventListener('click', ev => {
            if (!card.classList.contains('open')) return;
            if (card.contains(ev.target) || btn.contains(ev.target) || brand?.contains(ev.target)) return;
            setOpen(false);
        });
        document.addEventListener('keydown', ev => {
            if (ev.key === 'Escape') setOpen(false);
        });
    }

    function syncCollapseToggleBtn(card, btn) {
        const open = card.dataset.open === 'true';
        btn.textContent = open ? '▲ Replier' : '▼ Déplier';
        btn.setAttribute('aria-label', open ? 'Replier la section' : 'Déplier la section');
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    }

    function setCollapsibleOpen(card, open) {
        card.dataset.open = open ? 'true' : 'false';
        const btn = card.querySelector('.btn-collapse-toggle');
        if (btn) syncCollapseToggleBtn(card, btn);
    }

    function ensureCollapseToggleBtn(card) {
        const header = card.querySelector('.collapsible-header');
        if (!header) return;
        const right = header.querySelector('.h-right');
        if (!right) return;

        let ctrl = right.querySelector('.collapse-ctrl');
        if (!ctrl) {
            ctrl = el('div', { class: 'collapse-ctrl' });
            const arrow = right.querySelector(':scope > .arrow');
            if (arrow) {
                right.removeChild(arrow);
                ctrl.appendChild(arrow);
            }
            right.appendChild(ctrl);
        }

        let btn = ctrl.querySelector('.btn-collapse-toggle');
        if (!btn) {
            btn = el('button', {
                type: 'button',
                class: 'btn-collapse-toggle',
            }, '▼ Déplier');
            btn.addEventListener('click', (ev) => {
                ev.stopPropagation();
                setCollapsibleOpen(card, card.dataset.open !== 'true');
            });
            const arrow = ctrl.querySelector('.arrow');
            ctrl.insertBefore(btn, arrow || null);
        }
        syncCollapseToggleBtn(card, btn);
    }

    function collapseScopeRoot(bar) {
        if (bar?.dataset.collapseScope === 'app') return $('#zoneAppFlow');
        return bar?.closest('.tab-content') || document;
    }

    function setAllCollapsibles(open, root) {
        const scope = root || $('#zoneAppFlow') || document;
        $$('.card.collapsible', scope).forEach(c => setCollapsibleOpen(c, open));
    }

    function bindCollapsibles() {
        $$('.card.collapsible').forEach(card => {
            ensureCollapseToggleBtn(card);
            if (card.dataset.collapseBound) return;
            card.dataset.collapseBound = '1';
            const header = card.querySelector('.collapsible-header');
            if (!header) return;
            header.addEventListener('click', (ev) => {
                if (ev.target.closest('button, input, a, select, textarea')) return;
                setCollapsibleOpen(card, card.dataset.open !== 'true');
            });
        });
    }

    function bindCollapseToolbar() {
        $$('[data-collapse-scope]').forEach(bar => {
            if (bar.dataset.collapseToolbarBound) return;
            bar.dataset.collapseToolbarBound = '1';
            const root = collapseScopeRoot(bar);
            bar.querySelector('#btnExpandAll, .btn-expand-all-sections')
                ?.addEventListener('click', () => setAllCollapsibles(true, root));
            bar.querySelector('#btnCollapseAll, .btn-collapse-all-sections')
                ?.addEventListener('click', () => setAllCollapsibles(false, root));
        });
    }

    /* ====================================================================
     *  Toasts + session + API status
     * ==================================================================== */
    function showToast(kind, message, ms = 4200) {
        const host = $('#toastHost');
        if (!host) return;
        const k = ['info', 'success', 'warning', 'error'].includes(kind) ? kind : 'info';
        const t = el('div', { class: `toast toast-${k}`, role: 'status' });
        t.innerHTML = message;
        host.appendChild(t);
        if (typeof SupraI18n !== 'undefined' && SupraI18n.refresh) SupraI18n.refresh(t);
        window.setTimeout(() => {
            t.style.opacity = '0';
            t.style.transition = 'opacity 0.2s ease';
            window.setTimeout(() => t.remove(), 220);
        }, ms);
    }

    /** Remplace alert() pour les blocages UX courants (non bloquant). */
    function notifyUser(message, kind = 'warning') {
        showToast(kind, message);
    }

    function setApiUiState(state, htmlMsg) {
        const dot = $('#apiDot');
        const txtNode = $('#apiStatusText');
        const strip = $('.nav-api-strip');
        if (dot) dot.className = 'status-dot ' + (state === 'ok' || state === 'warn' || state === 'err' || state === 'ping' ? state : '');
        if (strip) strip.setAttribute('data-api-state', state || '');
        if (txtNode && htmlMsg != null) txtNode.innerHTML = htmlMsg;
        document.body?.setAttribute('data-api', state === 'ok' || state === 'warn' ? 'online' : (state === 'ping' ? 'ping' : 'offline'));
        updateSessionProgress();
    }

    function updateSessionProgress() {
        const chipMat = $('#chipMaterial');
        const chipWf = $('#chipWorkflow');
        const chipApi = $('#chipApi');
        const setChip = (sel, state) => {
            const c = document.querySelector(`.session-chip[data-chip="${sel}"]`);
            if (c) c.setAttribute('data-state', state);
        };
        if (chipMat) {
            chipMat.textContent = APP.material || '—';
            setChip('material', APP.material ? 'ready' : 'warn');
        }
        if (chipWf) {
            const label = APP.workflow
                ? (WORKFLOW_LABEL[APP.workflow]?.name || APP.workflow)
                : '—';
            chipWf.textContent = label;
            setChip('workflow', APP.workflow ? 'ready' : 'warn');
        }
        if (chipApi) {
            if (APP.apiOnline) {
                const warn = APP._health && !(APP._health.qe?.classic_ok !== false && APP._health.qe_bin_dir);
                chipApi.textContent = warn ? 'QE incomplet' : 'en ligne';
                setChip('api', warn ? 'warn' : 'ready');
            } else {
                chipApi.textContent = 'hors ligne';
                setChip('api', 'off');
            }
        }
    }

    async function pingAPI() {
        setApiUiState('ping', "Connexion à l'API Supra-QE…");

        let r = null;
        try {
            r = await SupraAPI.health();
        } catch (_) {
            r = null;
        }
        if (r && r.service === 'supra-qe') {
            APP.apiOnline = true;
            const qe = r.qe_bin_dir ? `(QE bin : ${r.qe_bin_dir})` : '(⚠️ aucun binaire QE détecté)';
            const classicOk = r.qe?.classic_ok !== false && r.qe_bin_dir;
            if (r.pseudo_dir_rel) {
                const fld = $('#fld_pseudo_dir');
                if (fld && !fld.dataset.touched) fld.value = r.pseudo_dir_rel;
            }
            setApiUiState(
                classicOk ? 'ok' : 'warn',
                `API en ligne · <span class="mono muted">${SupraAPI.getBaseURL()}</span> ${qe}`
            );
            APP._health = r;
            updateBinaryNotice();
            if (typeof renderServerPathInfo === 'function') renderServerPathInfo();
        } else {
            APP.apiOnline = false;
            APP._health = null;
            setApiUiState('err', `API injoignable. Lancer <code>./DEMARRER.sh</code>.`);
            updateBinaryNotice();
        }
    }

    let _apiPollTimer = null;
    function startApiWatchdog() {
        if (_apiPollTimer) return;
        _apiPollTimer = window.setInterval(() => {
            if (document.hidden) return;
            pingAPI();
        }, 30000);
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) pingAPI();
        });
    }

    /** Binaire QE requis par une étape ; null si l'API n'a pas encore répondu. */
    function binaryAvailable(prog) {
        const found = APP._health?.qe?.found;
        if (!found || !(prog in found)) return null;
        return !!found[prog];
    }

    /**
     * Prévient dès le choix du workflow si un binaire manque, au lieu de laisser
     * l'utilisateur découvrir l'absence d'epw.x après des heures de ph.x.
     */
    function updateBinaryNotice() {
        const box = $('#wfBinaryNotice');
        if (!box) return;
        const found = APP._health?.qe?.found;
        if (!found) { box.style.display = 'none'; box.innerHTML = ''; return; }

        const missing = { classic: [], epw: [] };
        ['classic', 'epw'].forEach(wf => {
            calcStepsForRun(wf).forEach(c => {
                if (binaryAvailable(c.prog) === false && !missing[wf].includes(c.prog)) {
                    missing[wf].push(c.prog);
                }
            });
        });
        if (!missing.classic.length && !missing.epw.length) {
            box.style.display = 'none';
            box.innerHTML = '';
            return;
        }
        const lines = [];
        if (missing.classic.length) lines.push(`<li><strong>WF1 Classique</strong> : ${missing.classic.map(p => `<code>${p}</code>`).join(', ')} introuvable(s)</li>`);
        if (missing.epw.length)     lines.push(`<li><strong>WF2 EPW</strong> : ${missing.epw.map(p => `<code>${p}</code>`).join(', ')} introuvable(s)</li>`);
        box.style.display = 'block';
        box.innerHTML = alertBox('warning',
            `<strong>Binaires QE manquants sur cette machine</strong><ul style="margin:8px 0 0; padding-left:20px;">${lines.join('')}</ul>` +
            `Les inputs restent générables (bouton 🖥️ Terminal pour lancer ailleurs), mais l'exécution depuis l'interface échouera à ces étapes. ` +
            `Indique le bon dossier via <code>QE_BIN_DIR</code> si les binaires existent ailleurs.`);
    }

    /* ====================================================================
     *  Chemins éditables (autre PC / autre dépôt)
     * ==================================================================== */
    const PATHS_LS_KEY = 'supra_qe_paths_v1';

    function defaultApiBase() {
        if (typeof SupraAPI !== 'undefined' && SupraAPI.getBaseURL) return SupraAPI.getBaseURL();
        if (typeof location !== 'undefined' && location.protocol === 'http:') return location.origin;
        return 'http://127.0.0.1:8765';
    }

    function loadStoredPaths() {
        try {
            return JSON.parse(localStorage.getItem(PATHS_LS_KEY) || '{}') || {};
        } catch {
            return {};
        }
    }

    function saveStoredPaths(patch) {
        const cur = { ...loadStoredPaths(), ...patch };
        try { localStorage.setItem(PATHS_LS_KEY, JSON.stringify(cur)); } catch { /* private mode */ }
        return cur;
    }

    /** Remplit les champs nav à partir des champs métier (+ stockage local). */
    function fillPathsNavForm() {
        const stored = loadStoredPaths();
        const set = (id, val) => { const el = $(id); if (el && val != null) el.value = val; };
        set('#fld_api_base', stored.api_base || defaultApiBase());
        set('#fld_api_token', stored.api_token || (typeof SupraAPI.getApiToken === 'function' ? SupraAPI.getApiToken() : ''));
        set('#fld_path_inputs_nav', stored.inputs || txt('fld_path_inputs', APP.material ? `inputs/${APP.material}` : 'inputs'));
        set('#fld_path_workflow_nav', stored.workflow || txt('fld_path_workflow',
            APP.material && APP.workflow ? `inputs/${APP.material}/${APP.workflow}` : ''));
        set('#fld_path_outputs_nav', stored.outputs || txt('fld_path_outputs',
            APP.material && APP.workflow ? `outputs/${APP.material}/${APP.workflow}` : ''));
        set('#fld_pseudo_dir_nav', stored.pseudos || txt('fld_pseudo_dir', '../../../pseudos/'));
    }

    function renderServerPathInfo() {
        const box = $('#pathsServerInfo');
        if (!box) return;
        const h = APP._health || {};
        if (!APP.apiOnline) {
            box.innerHTML = `<div class="path-row"><span class="path-label">état</span>`
                + `<span class="path-value">API injoignable — vérifie l’URL ci-dessus</span></div>`;
            return;
        }
        box.innerHTML = `
            <div class="path-row"><span class="path-label">API</span><span class="path-value">${escapeHtml(SupraAPI.getBaseURL())}</span></div>
            <div class="path-row"><span class="path-label">inputs (serveur)</span><span class="path-value">${escapeHtml(h.inputs_dir || '—')}</span></div>
            <div class="path-row"><span class="path-label">outputs (serveur)</span><span class="path-value">${escapeHtml(h.outputs_dir || '—')}</span></div>
            <div class="path-row"><span class="path-label">pseudos (serveur)</span><span class="path-value">${escapeHtml(h.pseudos_dir || '—')}</span></div>
            <div class="path-row"><span class="path-label">qe_bin</span><span class="path-value">${escapeHtml(h.qe_bin_dir || '(non détecté)')}</span></div>
            <div class="path-row"><span class="path-label">mpirun</span><span class="path-value">${escapeHtml(h.mpirun || '(non détecté)')}</span></div>
        `;
    }

    function setPathsNavStatus(html, kind = 'muted') {
        const box = $('#pathsNavStatus');
        if (!box) return;
        box.className = `paths-nav-status ${kind}`;
        box.innerHTML = html;
    }

    function togglePaths(forceOpen) {
        const box = $('#pathsBox');
        if (!box) return;
        const open = typeof forceOpen === 'boolean' ? forceOpen : box.classList.contains('hidden');
        if (open) {
            fillPathsNavForm();
            renderServerPathInfo();
            box.classList.remove('hidden');
            $('#btnShowPaths')?.classList.add('active');
        } else {
            box.classList.add('hidden');
            $('#btnShowPaths')?.classList.remove('active');
        }
    }

    /**
     * Applique URL API + dossiers saisis. Les chemins relatifs restent sous le
     * dépôt servi par l’API (autre PC = autre API + ses propres inputs/outputs).
     */
    async function applyPathsFromNav() {
        const apiBase = ($('#fld_api_base')?.value || '').trim().replace(/\/$/, '');
        const apiToken = ($('#fld_api_token')?.value || '').trim();
        const inputs = ($('#fld_path_inputs_nav')?.value || '').trim().replace(/\/$/, '');
        const workflow = ($('#fld_path_workflow_nav')?.value || '').trim().replace(/\/$/, '');
        const outputs = ($('#fld_path_outputs_nav')?.value || '').trim().replace(/\/$/, '');
        const pseudos = ($('#fld_pseudo_dir_nav')?.value || '').trim();

        if (!apiBase) {
            setPathsNavStatus(alertBox('warning', 'Indique l’URL de l’API (ex. <code>http://192.168.1.20:8765</code>).'));
            return;
        }
        try {
            // Validation légère de l’URL
            // eslint-disable-next-line no-new
            new URL(apiBase);
        } catch {
            setPathsNavStatus(alertBox('error', 'URL API invalide.'));
            return;
        }

        SupraAPI.setBaseURL(apiBase);
        if (typeof SupraAPI.setApiToken === 'function') SupraAPI.setApiToken(apiToken);
        const mark = (id, val) => {
            const el = $(id);
            if (!el) return;
            if (val) { el.value = val; el.dataset.touched = '1'; }
        };
        mark('#fld_path_inputs', inputs);
        mark('#fld_path_workflow', workflow);
        mark('#fld_path_outputs', outputs);
        mark('#fld_pseudo_dir', pseudos);

        saveStoredPaths({ api_base: apiBase, api_token: apiToken, inputs, workflow, outputs, pseudos });
        APP.baseDir = getMaterialBaseDir();
        setPathsNavStatus('Connexion à l’API…');
        await pingAPI();
        renderServerPathInfo();
        if (APP.apiOnline) {
            setPathsNavStatus(alertBox('success',
                `Connecté à <code>${escapeHtml(apiBase)}</code>`
                + (inputs ? ` · inputs <code>${escapeHtml(inputs)}</code>` : '')
                + (outputs ? ` · outputs <code>${escapeHtml(outputs)}</code>` : '')));
            if (APP.workflow) {
                invalidateWorkflowFiles();
                await renderCalcList();
                await refreshChainStatus();
            }
        } else {
            setPathsNavStatus(alertBox('error',
                `Impossible de joindre <code>${escapeHtml(apiBase)}</code>. `
                + 'Sur la machine cible : <code>./DEMARRER.sh</code>, et autorise le port (pare-feu).'));
        }
    }

    function resetPathsToLocal() {
        try { localStorage.removeItem(PATHS_LS_KEY); } catch { /* */ }
        const base = (typeof location !== 'undefined' && location.protocol === 'http:')
            ? location.origin : 'http://127.0.0.1:8765';
        SupraAPI.setBaseURL(base);
        ['#fld_path_inputs', '#fld_path_workflow', '#fld_path_outputs'].forEach(sel => {
            const el = $(sel);
            if (el) { delete el.dataset.touched; }
        });
        if (APP.material) syncMaterialPathField();
        updatePathFields();
        const pe = $('#fld_pseudo_dir');
        if (pe) pe.value = '../../../pseudos/';
        fillPathsNavForm();
        setPathsNavStatus(alertBox('info', `Défauts locaux restaurés (<code>${escapeHtml(base)}</code>). Clique <strong>Appliquer &amp; tester</strong>.`));
        renderServerPathInfo();
    }

    /** Au démarrage : restaure l’URL API et les dossiers mémorisés.
     *  Priorité : ?api=http://… dans l’URL > localStorage > origine courante.
     */
    function restorePathsFromStorage() {
        const s = loadStoredPaths();
        let apiFromUrl = '';
        try {
            apiFromUrl = new URLSearchParams(location.search).get('api') || '';
        } catch { /* */ }
        if (apiFromUrl) {
            try {
                const u = new URL(apiFromUrl);
                apiFromUrl = u.origin;
                SupraAPI.setBaseURL(apiFromUrl);
                s.api_base = apiFromUrl;
                saveStoredPaths({ api_base: apiFromUrl });
            } catch {
                apiFromUrl = '';
            }
        } else if (s.api_base) {
            SupraAPI.setBaseURL(s.api_base);
        }
        if (s.api_token && typeof SupraAPI.setApiToken === 'function') {
            SupraAPI.setApiToken(s.api_token);
        }
        const mark = (id, val) => {
            const el = $(id);
            if (el && val) { el.value = val; el.dataset.touched = '1'; }
        };
        mark('#fld_path_inputs', s.inputs);
        mark('#fld_path_workflow', s.workflow);
        mark('#fld_path_outputs', s.outputs);
        mark('#fld_pseudo_dir', s.pseudos);
    }

    function bindPathsEditor() {
        $('#btnShowPaths')?.addEventListener('click', () => togglePaths());
        $('#btnClosePaths')?.addEventListener('click', () => togglePaths(false));
        $('#btnApplyPathsNav')?.addEventListener('click', applyPathsFromNav);
        $('#btnResetPathsNav')?.addEventListener('click', resetPathsToLocal);
        // Marquer comme « touchés » pour ne pas écraser un choix manuel
        ['#fld_path_workflow', '#fld_path_outputs', '#fld_path_inputs', '#fld_pseudo_dir'].forEach(sel => {
            $(sel)?.addEventListener('input', () => { $(sel).dataset.touched = '1'; });
        });
    }

    /* ====================================================================
     *  ÉTAPE 2 — Choix du workflow (après matériau)
     * ==================================================================== */
    function bindWorkflowPicker() {
        $$('#workflowPicker .workflow-card').forEach(card => {
            card.addEventListener('click', () => {
                window.SupraSelectWorkflow(card.dataset.workflow);
            });
        });
        $$('.org-branch[data-wf]').forEach(branch => {
            branch.addEventListener('click', () => {
                window.SupraSelectWorkflow(branch.dataset.wf);
            });
        });
    }

    /*
     * Sélection de workflow sérialisée. Une passe enchaîne plusieurs await
     * (prérequis, génération, vérification de la chaîne) : laisser deux clics
     * rapprochés la relancer en parallèle mélangeait les états — badges figés,
     * boutons de lancement désactivés — voire saturait l'onglet. Une seule passe
     * s'exécute donc à la fois, et seule la dernière demande est honorée.
     */
    let wfSelectQueue = Promise.resolve();
    let wfSelectTarget = null;

    window.SupraSelectWorkflow = function (wf) {
        if (!(wf in CALCS)) return Promise.resolve();
        if (!APP.material) {
            notifyUser("Sélectionne d'abord un matériau (étape 1).");
            return Promise.resolve();
        }
        wfSelectTarget = wf;
        wfSelectQueue = wfSelectQueue
            .then(() => (wfSelectTarget === wf ? applyWorkflowSelection(wf) : null))
            .catch(err => console.error('[supra] sélection du workflow', err));
        return wfSelectQueue;
    };

    async function applyWorkflowSelection(wf) {
        const stale = () => wfSelectTarget !== wf;

        APP.workflow = wf;
        invalidateWorkflowFiles();
        $$('.workflow-card').forEach(c => c.classList.toggle('active', c.dataset.workflow === wf));
        highlightOrganigram(wf);

        const prereqCard = $('#zoneWfPrerequis');
        if (prereqCard) setCollapsibleOpen(prereqCard, true);

        const label = WORKFLOW_LABEL[wf];
        $('#etape2Title').textContent = `Programmes — ${label.name}`;
        $('#etapeWorkflowTitle').textContent = `« ${APP.material} » — ${label.name}`;
        const titleEl = $('#etape3VoieTitle');
        if (titleEl) titleEl.textContent = label.name;
        const chain = CALCS[wf].map(c => c.prog).filter((p, i, a) => a.indexOf(p) === i).join(' → ');
        const desc = $('#etape3VoieDesc');
        if (desc) desc.textContent = `${label.name} : ${chain}`;

        updatePathFields();
        renderMaterialInfo();
        renderWorkflowBanner();

        applyBranchVisibility(wf);
        resetBranchSubTabs(wf);
        applyMainViewPart();
        syncMaterialPathField();
        await checkPrereqOutputs();
        if (stale()) return;
        updateFluxEtapes();

        renderPipeline();
        await renderCalcList();
        if (stale()) return;
        await refreshChainStatus();
        if (stale()) return;
        updateCPUInfo();
        bindCollapsibles();

        const scrollTarget = APP.mainView === 'resultats' ? '#zoneWfResultats' : '#zoneWfCalculs';
        scrollToView(scrollTarget, { block: 'nearest' });
    }

    function renderMaterialInfo() {
        const box = $('#zoneMateriauInfo');
        if (!box || !APP.material) return;
        box.style.display = 'block';
        const wfTxt = APP.workflow
            ? `<strong style="color:${WORKFLOW_LABEL[APP.workflow].stepColor};">${WORKFLOW_LABEL[APP.workflow].name}</strong>`
            : '<span class="muted">— configure les pseudos (1b) puis un workflow —</span>';
        box.innerHTML = `
            <div style="background: linear-gradient(135deg, #ecfeff, #cffafe); padding: 16px 20px; border-radius: 12px; border-left: 4px solid var(--supra);">
                <h5 style="margin: 0 0 4px 0; color: var(--supra-dark);">🧪 Matériau actif</h5>
                <p style="margin: 0; color: #155e75; font-size: 1.05em;">
                    <strong>${APP.material}</strong> · workflow : ${wfTxt}
                </p>
            </div>`;
    }

    /* ====================================================================
     *  ÉTAPE 1 — Choix et validation du matériau
     * ==================================================================== */
    function bindSearchMaterial() {
        const champ = $('#champ_materiau');
        $('#btnValiderMateriau')?.addEventListener('click', validerChoixMateriau);
        champ?.addEventListener('keypress', e => { if (e.key === 'Enter') validerChoixMateriau(); });
        $('#btnImportRelax')?.addEventListener('click', () => $('#fld_relax_file')?.click());
        $('#fld_relax_file')?.addEventListener('change', handleRelaxUpload);
        $('#btnCheckPrereqs')?.addEventListener('click', verifyPrereqs);
        $('#fld_path_inputs')?.addEventListener('input', () => {
            const fi = $('#fld_path_inputs');
            if (fi) fi.dataset.touched = '1';
            APP.baseDir = getMaterialBaseDir();
            updatePrereqExpectedLabels();
        });
    }

    function updateScfPrereqBadge(done) {
        const b = $('#scfPrereqBadge');
        if (!b) return;
        if (done) {
            b.textContent = 'scf de contrôle : OK';
            b.style.background = 'var(--success)';
        } else {
            b.textContent = 'scf de contrôle : absent (optionnel)';
            b.style.background = '#94a3b8';
        }
    }

    function updatePrereqFlowChart() {
        const setActive = (id, on) => { const n = $(id); if (n) n.classList.toggle('active', !!on); };
        setActive('#pfVcrelax', APP.prereq?.relaxDone);
        setActive('#pfScf', APP.prereq?.scfDone);
        setActive('#pfReady', prereqsReady());
        updatePrereqSectionBadge();
    }

    function updatePrereqSectionBadge() {
        if (APP.prereq?.relaxDone && APP.prereq?.scfDone) setBadge('prereqs', 'ok', 'OK');
        else if (APP.prereq?.relaxDone) setBadge('prereqs', 'ok', 'structure OK');
        else setBadge('prereqs', 'warn', 'vc-relax manquant');
    }

    /** Reporte les cutoffs lus dans vc-relax.out sur la carte SCF. */
    function applyStructureCutoffs(struct) {
        if (struct?.ecutwfc) { const e = $('#fld_ecutwfc'); if (e) e.value = struct.ecutwfc; }
        if (struct?.ecutrho) { const e = $('#fld_ecutrho'); if (e) e.value = struct.ecutrho; }
    }

    /**
     * Cherche la première sortie lisible parmi `names`. L'absence de `JOB DONE`
     * n'écarte pas le fichier : elle est remontée via `jobDone` pour être
     * signalée sans bloquer un travail par ailleurs exploitable.
     */
    async function findPrereqOutput(base, names) {
        for (const name of names) {
            const path = `${base}/${name}`;
            const r = await SupraAPI.readFile(path);
            if (r?.ok && r.content) {
                return { path, content: r.content, jobDone: /JOB DONE/i.test(r.content) };
            }
        }
        return null;
    }

    /**
     * Relit les prérequis sur disque. L'état n'est publié qu'à la fin : effacer
     * les drapeaux au démarrage laisserait, le temps des requêtes, une fenêtre
     * où l'interface se croit sans structure et désactive les lancements.
     */
    async function checkPrereqOutputs() {
        if (!APP.material) return;
        APP.baseDir = getMaterialBaseDir();
        const base = APP.baseDir;
        const mat = APP.material;
        const found = { relaxDone: false, relaxFound: false, relaxJobDone: false,
                        scfDone: false, relaxPath: '', scfPath: '' };
        let structure = null;

        const relax = await findPrereqOutput(base, [
            `${mat}.vc-relax.out`, `${mat}.relax.out`, 'vc-relax.out', 'relax.out',
        ]);
        if (relax) {
            found.relaxFound = true;
            found.relaxPath = relax.path;
            found.relaxJobDone = relax.jobDone;
            const s = extractStructureFromText(relax.content);
            if (s) {
                s._material = mat;
                structure = s;
                // Le critère réel est l'extraction de la structure : un badge vert
                // sans structure exploitable laisserait la génération échouer plus loin.
                found.relaxDone = true;
            }
        }

        const scf = await findPrereqOutput(base, [
            `${mat}.scf.out`, `${mat}.scf_prereq.out`, 'scf.out',
        ]) || await findPrereqOutput(`outputs/${mat}`, [
            `${mat}.scf.out`, `${mat}.scf_prereq.out`,
        ]);
        if (scf) {
            found.scfDone = !!scf.jobDone;
            found.scfPath = scf.path;
        }

        if (APP.material !== mat) return;   // un autre matériau a été validé entre-temps
        Object.assign(APP.prereq, found);
        if (structure) {
            APP.structure = structure;
            applyStructureCutoffs(structure);
        }

        updateRelaxBadge(APP.prereq.relaxDone);
        updateScfPrereqBadge(APP.prereq.scfDone);
        updatePrereqFlowChart();
        renderPrereqStatusMessage();
        updateFluxEtapes();
    }

    function renderPrereqStatusMessage() {
        const el = $('#prereqStatus');
        if (!el || !APP.material) return;
        const base = APP.baseDir || `inputs/${APP.material}`;
        const mat = APP.material;

        if (!APP.prereq.relaxDone) {
            const why = APP.prereq.relaxFound
                ? `Le fichier <code>${APP.prereq.relaxPath}</code> a bien été lu, mais aucune structure finale ` +
                  `n'a pu en être extraite (bloc <code>ATOMIC_POSITIONS</code> / <code>CELL_PARAMETERS</code> absent). ` +
                  `Vérifie qu'il s'agit d'un <code>vc-relax</code> (ou <code>relax</code>) mené jusqu'aux positions finales.`
                : `Aucun <code>${mat}.vc-relax.out</code> lisible dans <code>${base}/</code>. ` +
                  `Lance vc-relax avec ton outil QE habituel, copie la sortie ici (ou indique un autre chemin), ` +
                  `puis clique « Vérifier les prérequis ».`;
            el.innerHTML = alertBox('warning',
                `<strong>Structure relaxée non exploitable</strong> — ${why}<br>` +
                `C'est le seul fichier indispensable : il fournit ibrav, celldm et les positions atomiques de tous les inputs.`);
            return;
        }
        const notes = [];
        if (!APP.prereq.relaxJobDone) {
            notes.push(`⚠️ <code>JOB DONE</code> absent de la sortie vc-relax : la structure a été lue, ` +
                       `mais vérifie que la relaxation a bien convergé avant d'investir dans ph.x.`);
        }
        notes.push(APP.prereq.scfDone
            ? `scf de contrôle : <code>${APP.prereq.scfPath}</code>`
            : `scf de contrôle absent — sans conséquence : chaque workflow relance son propre SCF (étape 1) ` +
              `dans son dossier, ce qui est indispensable pour que le NSCF et ph.x trouvent la densité dans <code>outdir</code>.`);
        el.innerHTML = alertBox(APP.prereq.relaxJobDone ? 'success' : 'warning',
            `✅ Structure relaxée exploitable — ${APP.structure?.positions?.length || 0} atome(s), ` +
            `${APP.structure?.species?.length || 0} espèce(s)<br>` +
            `vc-relax : <code>${APP.prereq.relaxPath}</code><br>${notes.join('<br>')}`);
    }

    async function verifyPrereqs() {
        if (!APP.material) {
            setPrereqStatus('warning', 'Valide d\'abord le matériau.');
            return;
        }
        APP.baseDir = getMaterialBaseDir();
        await checkPrereqOutputs();
        const card = $('#zoneWfPrerequis');
        if (card) card.dataset.open = 'true';
    }

    const setPrereqStatus = (kind, html) => {
        const el = $('#prereqStatus');
        if (el) el.innerHTML = alertBox(kind, html);
    };

    function updateRelaxBadge(hasRelax) {
        const b = $('#relaxStatusBadge');
        if (!b) return;
        if (hasRelax) {
            b.textContent = APP.prereq?.relaxJobDone ? 'vc-relax : OK' : 'vc-relax : structure lue (sans JOB DONE)';
            b.style.background = APP.prereq?.relaxJobDone ? 'var(--success)' : 'var(--warning)';
        } else {
            b.textContent = APP.prereq?.relaxFound ? 'vc-relax : illisible' : 'vc-relax : manquant';
            b.style.background = 'var(--warning)';
        }
    }

    async function validerChoixMateriau() {
        const q = $('#champ_materiau')?.value.trim();
        if (!q) {
            renderSearchEmpty('Entre un nom de matériau (ex : Nb, MgB2).');
            return;
        }

        if (APP.apiOnline) {
            const r = await SupraAPI.searchMaterial(q);
            if (!r || !r.ok) {
                renderSearchEmpty('Erreur lors de la validation du matériau.');
                return;
            }
            if (r.found) {
                renderSearchResults(q, r);
                await selectMaterial(r.name, { hasRelax: r.has_relax });
                return;
            }
            renderSearchEmpty(
                `Matériau « ${q} » absent de <code>inputs/</code>. ` +
                `Valide quand même — tu pourras indiquer le chemin des prérequis vc-relax + scf dans le workflow.`
            );
            await selectMaterial(q, { hasRelax: false, allowNew: true });
            return;
        }

        renderSearchEmpty('API hors-ligne — validation locale du nom uniquement.');
        await selectMaterial(q, { hasRelax: !!APP.structure, allowNew: true });
    }

    function renderSearchEmpty(msg) {
        $('#zoneResultatRecherche').innerHTML = `
            <div style="background:#fef3c7; padding:24px; border-radius:12px; border-left:4px solid var(--warning); text-align:center;">
                <p style="margin:0; color:#92400e; font-size:1em;">${msg}</p>
            </div>`;
    }

    function renderSearchResults(query, r) {
        const zone = $('#zoneResultatRecherche');
        if (!r.found) return;
        const nClassic = r.classic_files?.length ?? 0;
        const nEpw     = r.epw_files?.length ?? 0;
        zone.innerHTML = `
            <div style="background: linear-gradient(135deg, #d1fae5, #a7f3d0); padding: 20px; border-radius: 12px; border-left: 4px solid var(--success);">
                <h5 style="margin: 0 0 8px 0; color: #065f46;">✅ Matériau « ${r.name} » validé</h5>
                <p style="margin: 0; color: #047857;">
                    📁 <code>${r.inputs_dir}/</code> ·
                    ${r.has_relax ? '<span class="pill" style="background:var(--success); color:white;">vc-relax OK</span>' :
                                    '<span class="pill" style="background:var(--warning); color:white;">vc-relax manquant</span>'} ·
                    <span class="pill pill-classic">WF1 : ${nClassic}</span>
                    <span class="pill pill-epw">WF2 : ${nEpw}</span>
                </p>
            </div>`;
    }

    async function handleRelaxUpload(ev) {
        const file = ev.target.files[0];
        if (!file) return;
        const text = await file.text();

        let mat = $('#champ_materiau').value.trim();
        if (!mat) {
            const m = file.name.match(/^([A-Za-z0-9_\-]+)/);
            if (m) { mat = m[1]; $('#champ_materiau').value = mat; }
        }
        if (!mat) {
            renderSearchEmpty("Entre un nom de matériau avant d'uploader le vc-relax.");
            return;
        }

        const base = (APP.material === mat ? getMaterialBaseDir() : null) || `inputs/${mat}`;
        const target = `${base}/${mat}.vc-relax.out`;
        const res = await SupraAPI.saveFile(target, text);
        if (!res || !res.ok) {
            renderSearchEmpty(`Échec sauvegarde : ${res?.error || 'inconnue'}`);
            return;
        }
        if (!/JOB DONE/.test(text.slice(-6000))) {
            renderSearchEmpty("⚠️ « JOB DONE » non trouvé. Vérifie que ton vc-relax est terminé.");
            return;
        }

        const struct = extractStructureFromText(text);
        if (!struct) {
            renderSearchEmpty("⚠️ Sauvegarde OK mais aucune structure extraite (vérifie 'Begin final coordinates').");
            return;
        }

        APP.structure = struct;
        applyStructureCutoffs(struct);
        if (struct.species?.length) {
            $('#fld_epw_nbndsub').value = Math.max(struct.species.length * 3, 5);
            $('#fld_nbnd_epw').value    = Math.max(struct.species.length * 12, 20);
        }

        $('#zoneResultatRecherche').innerHTML = `
            <div style="background: linear-gradient(135deg, #d1fae5, #a7f3d0); padding: 20px; border-radius: 12px; border-left: 4px solid var(--success);">
                <h5 style="margin: 0 0 8px 0; color: #065f46;">✅ vc-relax.out importé pour « ${mat} »</h5>
                <p style="margin: 0; color: #047857;">
                    ${struct.species.length} espèce(s), ${struct.positions.length} atome(s)
                    ${struct.ibrav !== undefined ? `, ibrav=${struct.ibrav}` : ''}
                    ${struct.ecutwfc ? `, ecutwfc=${struct.ecutwfc} Ry` : ''}.
                </p>
            </div>`;
        await selectMaterial(mat, { hasRelax: true });
        await checkPrereqOutputs();
        ev.target.value = '';
    }

    async function selectMaterial(materiau, opts = {}) {
        APP.material = materiau;
        APP.baseDir = `inputs/${materiau}`;
        APP.workflow = null;
        APP.prereq = { relaxDone: false, scfDone: false, relaxPath: '', scfPath: '' };
        invalidateWorkflowFiles();
        $$('.workflow-card').forEach(c => c.classList.remove('active'));
        highlightOrganigram(null);

        $('#champ_materiau').value = materiau;
        const fi = $('#fld_path_inputs');
        if (fi) { fi.dataset.touched = ''; fi.value = APP.baseDir; }

        if (!APP.structure || APP.structure._material !== materiau) {
            const r = await SupraAPI.readFile(`${APP.baseDir}/${materiau}.vc-relax.out`);
            if (r && r.ok && r.content) {
                const s = extractStructureFromText(r.content);
                if (s) {
                    s._material = materiau;
                    APP.structure = s;
                    opts.hasRelax = true;
                }
            }
        }

        syncMaterialPathField();
        await checkPrereqOutputs();
        renderMaterialInfo();
        refreshPseudoTable();

        const pseudo = $('#zoneEtapePseudo');
        if (pseudo) {
            pseudo.style.display = 'block';
            setCollapsibleOpen(pseudo, true);
            const title = $('#etapePseudoTitle');
            if (title) title.textContent = `Pseudopotentiels — ${materiau}`;
        }

        updateFluxEtapes();
        scrollToView(pseudo, { block: 'nearest' });
    }

    function extractStructureFromText(text) {
        const out = { positions: [], species: [], cell_parameters: null };
        const idx = text.lastIndexOf('Begin final coordinates');
        const block = idx >= 0 ? text.slice(idx) : text;

        let m = block.match(/CELL_PARAMETERS\s*\(?\s*(\w+)?[^)\n]*\)?\s*\n\s*([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s*\n\s*([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s*\n\s*([-+\d.eEdD]+)\s+([-+\d.eEdD]+)\s+([-+\d.eEdD]+)/);
        if (m) {
            out.cell_unit = m[1] || 'alat';
            out.cell_parameters = [
                [Number(m[2].replace(/d/i,'e')), Number(m[3].replace(/d/i,'e')), Number(m[4].replace(/d/i,'e'))],
                [Number(m[5].replace(/d/i,'e')), Number(m[6].replace(/d/i,'e')), Number(m[7].replace(/d/i,'e'))],
                [Number(m[8].replace(/d/i,'e')), Number(m[9].replace(/d/i,'e')), Number(m[10].replace(/d/i,'e'))],
            ];
        }
        m = block.match(/ATOMIC_POSITIONS\s*\(?\s*(\w+)\s*\)?\s*\n((?:\s*[A-Za-z]{1,3}\s+[-+\d.eEdD]+\s+[-+\d.eEdD]+\s+[-+\d.eEdD]+(?:\s+\d\s+\d\s+\d)?\s*\n?)+)/);
        if (m) {
            out.positions_unit = m[1];
            m[2].trim().split('\n').forEach(line => {
                const p = line.trim().split(/\s+/);
                if (p.length >= 4) out.positions.push({
                    sym: p[0],
                    x: Number(p[1].replace(/d/i,'e')),
                    y: Number(p[2].replace(/d/i,'e')),
                    z: Number(p[3].replace(/d/i,'e')),
                });
            });
        }
        m = text.match(/ATOMIC_SPECIES\s*\n((?:\s*[A-Za-z]{1,3}\s+[\d.]+\s+[\w.\-+]+\s*\n?)+)/);
        if (m) {
            m[1].trim().split('\n').forEach(line => {
                const p = line.trim().split(/\s+/);
                if (p.length >= 3) out.species.push({ symbol: p[0], mass: Number(p[1]), pseudo: p[2] });
            });
        }
        const mb = text.match(/bravais-lattice index\s*=\s*(\d+)/i); if (mb) out.ibrav = Number(mb[1]);
        const me = text.match(/kinetic-energy cutoff\s*=\s*([\d.]+)\s*Ry/i); if (me) out.ecutwfc = Math.round(Number(me[1]));
        const mr = text.match(/charge density cutoff\s*=\s*([\d.]+)\s*Ry/i); if (mr) out.ecutrho = Math.round(Number(mr[1]));
        const ma = block.match(/CELL_PARAMETERS\s*\(?[^)\n]*alat\s*=\s*([\d.+\-eEdD]+)/i); if (ma) out.alat = Number(ma[1].replace(/d/i,'e'));
        // Maille explicite (vc-relax) → toujours ibrav=0 + unité réelle
        if (out.cell_parameters) {
            out.ibrav = 0;
            const u = String(out.cell_unit || 'alat').toLowerCase();
            out.cell_unit = (u === 'angstrom' || u === 'bohr' || u === 'alat') ? u : 'alat';
            if (out.alat && !out.celldm) out.celldm = [out.alat, 0, 0, 0, 0, 0];
        }
        return out.positions.length ? out : null;
    }

    /* ====================================================================
     *  ÉTAPE 2 — Pipeline visuel + liste des calculs (style Interface-QE_v1)
     * ==================================================================== */
    function renderPipeline() {
        const zone = $('#zonePipeline');
        if (!APP.workflow) { zone.innerHTML = ''; return; }
        const calcs = calcStepsForRun(APP.workflow);
        const color = wfCss(APP.workflow);
        zone.innerHTML = `
            <div class="pipeline-block ${color}">
                <div class="pipeline-title">
                    <span>${WORKFLOW_LABEL[APP.workflow].name} — pipeline</span>
                    <span class="pipeline-tag">${calcs.length} étapes</span>
                </div>
                <div class="pipeline" id="pipelineActive">
                    ${calcs.map((c, i) => `
                        <div class="pipe-step" data-step="${c.type}" data-state="ready">
                            <div class="pipe-num">${c.num}</div>
                            <div class="pipe-title">${c.icon} ${c.nom}</div>
                            <div class="pipe-sub">${c.prog}</div>
                            <span class="pipe-badge">prêt</span>
                        </div>
                        ${i < calcs.length - 1 ? '<div class="pipe-arrow">→</div>' : ''}
                    `).join('')}
                </div>
            </div>`;
    }

    async function renderCalcList() {
        const zone = $('#zoneListeCalculs');
        if (!APP.workflow) { zone.innerHTML = ''; return; }
        const calcs = CALCS[APP.workflow];
        const wfClass = 'wf-' + wfCss(APP.workflow);
        zone.innerHTML = '<p class="muted">Génération des inputs…</p>';

        await ensureFilesGenerated(true);
        const paths = getWorkflowPaths();
        zone.innerHTML = '';

        calcs.forEach(c => {
            const f = APP.files?.[APP.workflow]?.[c.type];
            const fileName = f?.name || `${APP.material}.${c.type}.in`;
            const inPath = `${paths.workDir}/${fileName}`;
            const preview = f?.content
                ? f.content.split('\n').slice(0, 12).join('\n')
                : '(clique « Générer les inputs » ou ✏️ Éditer)';

            const card = el('div', {
                class: `calc-card ${wfClass}`,
                'data-state': 'idle',
                'data-type': c.type,
            });
            const optTag = c.optional
                ? '<span class="pill" style="background: var(--warning); color: white;">optionnel</span>' : '';
            const deps = (STEP_CHAIN[APP.workflow]?.[c.type]?.deps || [])
                .map(d => calcByType(APP.workflow, d))
                .filter(Boolean);
            const depsLine = deps.length
                ? `<div class="calc-deps">🔗 Requiert : ${deps.map(d => `<strong>${d.num} ${d.prog}</strong>`).join(' puis ')} terminé(s)</div>`
                : '<div class="calc-deps">🔗 Première étape de la chaîne — part du vc-relax validé.</div>';
            card.innerHTML = `
                <div class="calc-head">
                    <div class="calc-title">
                        <span class="calc-num">${c.num}</span>
                        <span style="font-size: 1.3em;">${c.icon}</span>
                        <h5>${c.nom}</h5>
                        ${optTag}
                    </div>
                    <span class="calc-prog">${c.prog}</span>
                </div>
                <p class="calc-desc">${c.desc}</p>
                ${depsLine}
                <div class="calc-input-path">📄 Input : <code>${inPath}</code></div>
                <pre class="calc-input-preview">${escapeHtml(preview)}</pre>
                <div class="calc-reco">
                    <strong>💡 ${WORKFLOW_LABEL[APP.workflow]?.id || ''} — ${APP.workflow}</strong>
                    <ul>${c.reco.map(r => `<li>${r}</li>`).join('')}</ul>
                </div>
                <div class="calc-actions">
                    <button class="btn"
                            style="background: linear-gradient(135deg, var(--warning), #d97706); color: white;"
                            data-action="edit">✏️ Vérifier / éditer</button>
                    <button class="btn btn-secondary" data-action="save">💾 Sauvegarder</button>
                    <button class="btn btn-success" data-action="run">🚀 Lancer</button>
                    <button class="btn"
                            style="background: linear-gradient(135deg, #0f172a, #1e293b); color: #a3e635; font-weight: 600;"
                            data-action="terminal">🖥️ Terminal</button>
                    <button class="btn"
                            style="background: linear-gradient(135deg, var(--info), #1d4ed8); color: white;"
                            data-action="suivi">📊 Suivi</button>
                </div>`;
            card.querySelector('[data-action="edit"]')    .addEventListener('click', () => editInputModal(c));
            card.querySelector('[data-action="save"]')    .addEventListener('click', () => saveInputForCalc(c));
            card.querySelector('[data-action="run"]')     .addEventListener('click', () => runOne(c));
            card.querySelector('[data-action="terminal"]').addEventListener('click', () => terminalModal(c));
            card.querySelector('[data-action="suivi"]')   .addEventListener('click', () => suiviModal(c));
            zone.appendChild(card);
        });
        syncPipelineFromChain();
    }

    async function saveInputForCalc(calc) {
        if (!await ensureFilesGenerated()) return;
        const f = APP.files?.[APP.workflow]?.[calc.type];
        if (!f) { notifyUser('Input introuvable.', 'error'); return; }
            if (!APP.apiOnline) { notifyUser('API hors ligne — lance <code>./DEMARRER.sh</code> ou ouvre Chemins.', 'error'); return; }
        const paths = getWorkflowPaths();
        const path = `${paths.workDir}/${f.name}`;
        const r = await SupraAPI.saveFile(path, f.content);
        if (r?.ok) {
            setCalcState(calc.type, 'ready', 'sauvé');
            setGenStatus('success', `✅ <code>${path}</code> sauvegardé.`);
        } else {
            notifyUser(`Erreur : ${r?.error || 'inconnue'}`, 'error');
        }
    }

    /* ====================================================================
     *  MODAL ÉDITION (split-screen textarea + recommandations)
     * ==================================================================== */
    async function editInputModal(calc) {
        if (!APP.material) { notifyUser("Sélectionne d'abord un matériau."); return; }
        if (!APP.workflow) { notifyUser("Choisis d'abord un workflow."); return; }

        const fileObj = APP.files?.[APP.workflow]?.[calc.type];
        const fileName = fileObj ? fileObj.name : `${APP.material}.${calc.type}.in`;
        const paths = getWorkflowPaths();
        const path = `${paths.workDir}/${fileName}`;

        // Tente d'abord de lire le fichier existant sur le serveur ; sinon génère un brouillon
        let contenu = null;
        if (APP.apiOnline) {
            const r = await SupraAPI.readFile(path);
            if (r && r.ok && r.content) contenu = r.content;
        }
        if (contenu == null) {
            if (!APP.structure) {
                notifyUser("Place ou importe un vc-relax.out dans la section prérequis (①) avant de générer l'input.");
                return;
            }
            const ok = await ensureFilesGenerated(true);
            if (!ok) return;
            contenu = APP.files?.[APP.workflow]?.[calc.type]?.content ?? '';
        }

        openModal({
            type:    'large',
            headerCls: 'orange',
            title:   `✏️ Édition : ${calc.nom} — ${APP.material}`,
            subtitle: `📁 ${path}`,
            bodyHTML: `
                <div class="edit-split" style="margin: -22px -24px;">
                    <div class="edit-left">
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                            <h4 style="margin:0;">📝 Contenu de l'input</h4>
                            <span style="font-size:0.82em; color:var(--text-medium);" id="lineCount">— lignes</span>
                        </div>
                        <textarea id="editTextarea">${escapeHtml(contenu)}</textarea>
                    </div>
                    <div class="edit-right">
                        <h4>💡 Recommandations</h4>
                        ${calc.reco.map(r => `<div class="reco-item">• ${r}</div>`).join('')}
                        <div style="background:#fee2e2; padding:12px 14px; border-radius:8px; margin-top:14px; border-left:4px solid var(--error);">
                            <strong style="color:#991b1b;">⚠️ Points d'attention :</strong>
                            <ul style="margin:8px 0 0; padding-left:20px; color:#7f1d1d; font-size:0.86em;">
                                <li>Syntaxe Fortran (sensible à la casse)</li>
                                <li>Sections <code>&CONTROL</code>, <code>&SYSTEM</code>, <code>&ELECTRONS</code>…</li>
                                <li>Chemins des pseudos cohérents (<code>pseudo_dir</code>)</li>
                                <li>Format numérique : <code>1.0d-10</code> (notation Fortran)</li>
                            </ul>
                        </div>
                    </div>
                </div>`,
            footer: [
                { label: '❌ Annuler',          cls: 'btn-secondary',      onClick: closeModal },
                { label: '⬇️ Télécharger',      cls: 'btn btn-secondary',  onClick: () => {
                    const v = $('#editTextarea').value;
                    downloadFile(fileName, v);
                } },
                { label: '🔁 Regénérer (form)', cls: 'btn btn-violet',     onClick: async () => {
                    if (!APP.structure) { notifyUser("vc-relax.out requis dans le dossier prérequis."); return; }
                    APP.files = APP.files || {};
                    APP.files[APP.workflow] = SupraInputs.genererFichiersWorkflow(gatherParams(), APP.workflow);
                    $('#editTextarea').value = APP.files[APP.workflow][calc.type].content;
                    updateLineCount();
                } },
                { label: '💾 Sauvegarder',      cls: 'btn btn-success',    onClick: async () => {
                    if (!APP.apiOnline) { notifyUser("API hors ligne — lance <code>./DEMARRER.sh</code> ou ouvre Chemins.", "error"); return; }
                    const v = $('#editTextarea').value;
                    const r = await SupraAPI.saveFile(path, v);
                    if (r?.ok) {
                        if (!APP.files) APP.files = {};
                        if (!APP.files[APP.workflow]) APP.files[APP.workflow] = SupraInputs.genererFichiersWorkflow(gatherParams(), APP.workflow);
                        if (APP.files[APP.workflow]?.[calc.type]) APP.files[APP.workflow][calc.type].content = v;
                        setCalcState(calc.type, 'ready', 'sauvé');
                        renderInputsPanel(APP.files);
                        renderCalcList();
                        closeModal();
                    } else {
                        notifyUser(`Erreur de sauvegarde : ${r?.error || 'inconnue'}`, 'error');
                    }
                } },
            ],
        });
        // compteur de lignes live
        const ta = $('#editTextarea');
        const updateLineCount = () => {
            $('#lineCount').textContent = `${ta.value.split('\n').length} lignes`;
        };
        ta.addEventListener('input', updateLineCount);
        updateLineCount();
    }

    /* ====================================================================
     *  MODAL TERMINAL (commandes prêtes à coller)
     * ==================================================================== */
    function terminalModal(calc) {
        if (!APP.material) { notifyUser("Sélectionne d'abord un matériau."); return; }
        const fileName = `${APP.material}.${calc.type}.in`;
        const outName  = `${APP.material}.${calc.type}.out`;
        const paths    = getWorkflowPaths();
        const wd       = paths.workDir;
        const np = intv('fld_nprocs', 1);
        const nt = intv('fld_nthreads', 1);
        const h  = APP._health || {};
        const mpirun = h.mpirun || 'mpirun';
        const binDir = h.qe_bin_dir || '/usr/local/bin';
        const repoAbs = h.inputs_dir ? h.inputs_dir.replace(/\/inputs\/?$/, '') : '/path/to/supra-QE';

        const fullPath = `${repoAbs}/${wd}/${fileName}`;
        const fullOut  = `${repoAbs}/${wd}/${outName}`;

        let cmdRun = '';
        if (np > 1) {
            cmdRun = `${mpirun} -np ${np} ${binDir}/${calc.prog} -in ${fullPath} > ${fullOut} 2>&1`;
        } else {
            cmdRun = `${binDir}/${calc.prog} -in ${fullPath} > ${fullOut} 2>&1`;
        }
        const cmdCd  = `cd ${repoAbs}/${wd}`;
        const cmdOmp = nt > 1 ? `export OMP_NUM_THREADS=${nt}` : '';
        const cmdTail = `tail -f ${fullOut}`;
        // epw.x ne lit pas directement les sorties de ph.x : les dyn + dvscf
        // doivent d'abord être regroupés dans save/ (script pp.py livré avec EPW).
        const cmdGather = calc.type === 'epw'
            ? `# pp.py livré avec EPW (même arbre que QE_BIN_DIR, pas un chemin hardcodé)\n` +
              `python3 "\${QE_BIN_DIR%/bin}/EPW/bin/pp.py"\n` +
              `# si absent : find "\${QE_BIN_DIR%/bin}" -name pp.py | head -1`
            : '';

        openModal({
            type:    'terminal',
            headerCls: 'dark',
            title:   `🖥️ Terminal — ${calc.nom}`,
            subtitle: `Copie-colle ces commandes dans ton terminal système`,
            bodyHTML: `
                <p class="muted" style="margin:0 0 12px;">
                    Toutes les commandes sont prêtes à coller. Utilise-les si tu préfères lancer en dehors de l'interface
                    (et garder le contrôle direct du processus).
                </p>
                ${(() => {
                    const lines = [
                        ['Aller dans le dossier de calcul', cmdCd],
                        cmdOmp   ? ['Définir les threads OpenMP', cmdOmp] : null,
                        cmdGather ? [`Regrouper les sorties de ph.x dans <code>save/</code> — obligatoire avant epw.x, répondre <code>${APP.material}</code>`, cmdGather] : null,
                        ['Lancer le calcul', cmdRun],
                        ['Suivre le log en temps réel', cmdTail],
                    ].filter(Boolean);
                    return lines.map(([label, cmd], i) => terminalLine(`${i + 1}) ${label}`, cmd)).join('');
                })()}
                <details style="margin-top:14px;">
                    <summary style="cursor:pointer; font-size:0.88em; color:var(--text-medium);">
                        Une seule commande prête à coller
                    </summary>
                    ${terminalLine('Pipeline complet', [cmdCd, cmdOmp, cmdGather, cmdRun].filter(Boolean).join(' && '))}
                </details>`,
            footer: [
                { label: 'Fermer', cls: 'btn-secondary', onClick: closeModal },
            ],
        });

        // Bind copy buttons after the modal is in the DOM
        $$('.copy-cmd').forEach(btn => {
            btn.addEventListener('click', () => {
                const cmd = btn.dataset.cmd || '';
                navigator.clipboard.writeText(cmd);
                btn.textContent = '✓ Copié';
                setTimeout(() => { btn.textContent = '📋 Copier'; }, 1500);
            });
        });
    }

    function terminalLine(label, cmd) {
        return `
            <div class="terminal-step">${label}</div>
            <div class="terminal-block">${escapeHtml(cmd)}
                <button class="copy-cmd" data-cmd="${escapeHtml(cmd).replace(/"/g,'&quot;')}">📋 Copier</button>
            </div>`;
    }

    /* ====================================================================
     *  MODAL SUIVI (tail -f du .out)
     * ==================================================================== */
    function suiviModal(calc) {
        if (!APP.material) { notifyUser("Sélectionne d'abord un matériau."); return; }
        const outName = `${APP.material}.${calc.type}.out`;
        const paths = getWorkflowPaths();
        const path = `${paths.outputDir}/${outName}`;

        openModal({
            type:    'large',
            headerCls: 'blue',
            title:   `📊 Suivi — ${calc.nom}`,
            subtitle: `Lecture en direct de ${path}`,
            bodyHTML: `
                <div class="tail-bar">
                    <span>État :</span>
                    <span class="tail-status idle" id="tailStatus">—</span>
                    <span class="muted" id="tailMeta"></span>
                    <span style="flex:1"></span>
                    <label style="display:flex; align-items:center; gap:6px; font-size:0.86em; color:var(--text-medium);">
                        <input type="checkbox" id="tailAuto" checked> Suivi auto (2 s)
                    </label>
                    <button class="btn btn-secondary" id="tailRefresh" style="padding:5px 12px; font-size:0.82em;">↻ Rafraîchir</button>
                </div>
                <div class="tail-output" id="tailContent">Chargement…</div>`,
            footer: [
                { label: '⬇️ Télécharger .out', cls: 'btn btn-secondary', onClick: async () => {
                    const r = await SupraAPI.readFile(path);
                    if (r?.ok && r.content) downloadFile(outName, r.content);
                } },
                { label: 'Fermer', cls: 'btn-secondary', onClick: () => {
                    if (APP._tailTimer) { clearInterval(APP._tailTimer); APP._tailTimer = null; }
                    closeModal();
                } },
            ],
            onClose: () => { if (APP._tailTimer) { clearInterval(APP._tailTimer); APP._tailTimer = null; } },
        });

        const refresh = async () => {
            const r = await SupraAPI.readFile(path);
            const box = $('#tailContent');
            const st  = $('#tailStatus');
            const meta = $('#tailMeta');
            if (!r || !r.ok) {
                if (box) box.innerHTML = `<span class="err">Aucun output disponible.\nFichier : ${path}</span>`;
                if (st) { st.className = 'tail-status idle'; st.textContent = 'idle'; }
                return;
            }
            const content = r.content || '';
            const tail = content.split('\n').slice(-200).join('\n');
            if (box) box.textContent = tail || '(fichier vide)';
            // détection d'état
            let kind = 'running', label = 'en cours';
            if (/JOB DONE\./.test(content))             { kind = 'completed'; label = 'JOB DONE ✓'; }
            else if (/%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/.test(content) ||
                     /Error in routine|stopping/i.test(content)) { kind = 'error'; label = 'erreur QE'; }
            if (st) { st.className = `tail-status ${kind}`; st.textContent = label; }
            if (meta) meta.textContent = `${content.split('\n').length} lignes · ${content.length.toLocaleString('fr-FR')} octets`;
            if (box) box.scrollTop = box.scrollHeight;
        };
        $('#tailRefresh').addEventListener('click', refresh);
        $('#tailAuto').addEventListener('change', (e) => {
            if (e.target.checked && !APP._tailTimer) APP._tailTimer = setInterval(refresh, 2000);
            else if (!e.target.checked && APP._tailTimer) { clearInterval(APP._tailTimer); APP._tailTimer = null; }
        });
        refresh();
        APP._tailTimer = setInterval(refresh, 2000);
    }

    /* ====================================================================
     *  Helpers modal génériques
     * ==================================================================== */
    function openModal({ type, headerCls, title, subtitle, bodyHTML, footer, onClose }) {
        const overlay = el('div', { class: 'modal-overlay' });
        const box = el('div', { class: 'modal-box ' + (type === 'large' ? 'large' : type === 'terminal' ? 'terminal' : '') });
        box.innerHTML = `
            <div class="modal-header ${headerCls || ''}">
                <div>
                    <h3>${title}</h3>
                    ${subtitle ? `<p>${subtitle}</p>` : ''}
                </div>
                <button class="modal-close" type="button">×</button>
            </div>
            <div class="modal-body">${bodyHTML}</div>
            <div class="modal-footer"></div>`;
        const footerDiv = box.querySelector('.modal-footer');
        (footer || []).forEach(f => {
            const b = el('button', { class: 'btn ' + (f.cls || 'btn-secondary'), type: 'button' });
            b.innerHTML = f.label;
            b.addEventListener('click', f.onClick);
            footerDiv.appendChild(b);
        });
        overlay.appendChild(box);
        document.body.appendChild(overlay);

        APP._currentModal = overlay;
        APP._modalOnClose = onClose;
        box.querySelector('.modal-close').addEventListener('click', closeModal);
        overlay.addEventListener('click', e => { if (e.target === overlay) closeModal(); });
    }

    function closeModal() {
        if (APP._currentModal) {
            APP._currentModal.remove();
            APP._currentModal = null;
            try { APP._modalOnClose && APP._modalOnClose(); } catch (_) {}
            APP._modalOnClose = null;
        }
    }

    function escapeHtml(s) {
        return (s == null ? '' : String(s))
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function setCalcState(type, state, badge) {
        $$(`.calc-card[data-type="${type}"]`).forEach(c => { c.dataset.state = state; });
        const pipe = $(`#pipelineActive .pipe-step[data-step="${type}"]`);
        if (pipe) {
            pipe.dataset.state = state;
            const b = pipe.querySelector('.pipe-badge');
            if (b && badge) b.textContent = badge;
        }
    }

    /* ====================================================================
     *  Garantir que les inputs sont générés (en mémoire ; sauvegarde sur demande)
     * ==================================================================== */
    async function ensureFilesGenerated(silent) {
        if (!APP.material)  { if (!silent) setGenStatus('error', "Sélectionne d'abord un matériau."); return false; }
        if (!APP.structure || !prereqsReady()) {
            if (!silent) setGenStatus('warning',
                'Structure relaxée requise : place <code>vc-relax.out</code> dans la section ① puis clique « Vérifier les prérequis ».');
            return false;
        }
        if (!APP.workflow)  { if (!silent) setGenStatus('error', "Choisis d'abord un workflow (étape 2)."); return false; }

        if (APP.files?.[APP.workflow]) return true;

        const p   = gatherParams();
        const val = SupraInputs.validerParametres(p);
        if (!val.ok) {
            if (!silent) setGenStatus('error',
                '<strong>Paramètres invalides :</strong><ul style="padding-left:22px;">' +
                val.erreurs.map(e => `<li>${e}</li>`).join('') + '</ul>');
            return false;
        }
        APP.files = APP.files || {};
        APP.files[APP.workflow] = SupraInputs.genererFichiersWorkflow(p, APP.workflow);
        renderInputsPanel(APP.files);
        return true;
    }

    /** Écrit l'input de l'étape sur le serveur juste avant son lancement. */
    async function pushStepInput(calc) {
        if (!APP.apiOnline) return true;
        const f = APP.files?.[APP.workflow]?.[calc.type];
        if (!f) return false;
        const paths = getWorkflowPaths();
        const r = await SupraAPI.saveFile(`${paths.workDir}/${f.name}`, f.content);
        return !!r?.ok;
    }

    /**
     * Signale les dépendances non satisfaites avant un lancement manuel.
     * L'utilisateur garde le dernier mot : la vérification informe et demande
     * confirmation, elle ne verrouille jamais définitivement une étape.
     */
    async function guardStep(calc) {
        await inspectChain();
        const blockers = chainBlockers(calc.type);
        if (!blockers.length) return true;
        renderChainStatus();

        const details = blockers
            .map(b => `• ${stripTags(b.label)}${b.detail ? ` — ${stripTags(b.detail)}` : ''}`)
            .join('\n');
        appendLog(alertBox('warning',
            `⚠️ <strong>${calc.num} — ${calc.nom}</strong> lancé alors que la chaîne signale :` +
            `<ul style="margin:8px 0 0; padding-left:20px;">` +
            blockers.map(b => `<li>${b.label}${b.detail ? ` — ${b.detail}` : ''}</li>`).join('') +
            `</ul>`));
        return confirm(
            `${calc.num} — ${calc.nom} (${calc.prog})\n\n` +
            `La vérification signale :\n${details}\n\n` +
            `Lancer quand même ? (à faire si tu as produit ces fichiers ailleurs)`);
    }

    function stripTags(html) {
        return String(html == null ? '' : html).replace(/<[^>]*>/g, '');
    }

    async function runOne(calc, { force = false } = {}) {
        if (!await ensureFilesGenerated()) return false;
        if (!force && !await guardStep(calc)) return false;
        if (!await pushStepInput(calc)) {
            appendLog(alertBox('error', `Impossible d'écrire l'input de ${calc.nom}.`));
            return false;
        }
        const ok = await launchStep(calc.type, APP.workflow);
        await refreshChainStatus();
        return ok;
    }

    /* ====================================================================
     *  Workflow complet — séquentiel, avec vérification avant et après
     *  chaque étape (une étape ne démarre que si l'amont est « JOB DONE »).
     * ==================================================================== */
    async function runWorkflowActive() {
        if (!await ensureFilesGenerated()) return;
        if (!APP.apiOnline) {
            appendLog(alertBox('error',
                'API hors-ligne : impossible de lancer et de vérifier la chaîne. ' +
                'Lance <code>./DEMARRER.sh</code> puis « ↻ API », ou utilise 🖥️ Terminal étape par étape.'));
            return;
        }
        const wf = APP.workflow;
        const ordered = calcStepsForRun(wf);
        appendLog(`▶️ <strong>${WORKFLOW_LABEL[wf].name}</strong> — ${ordered.length} étapes : ${ordered.map(c => c.prog).join(' → ')}`);

        for (const c of ordered) {
            await inspectChain();
            if (!APP.chain) {
                appendLog(alertBox('error',
                    (APP.chainError || 'Vérification de la chaîne impossible.') +
                    ' Workflow arrêté (fail-closed).'));
                return;
            }
            if (stepState(c.type, wf) === 'done') {
                appendLog(`⏭️ ${c.num} — ${c.nom} déjà terminé (JOB DONE) : étape sautée.`);
                continue;
            }
            const blockers = chainBlockers(c.type, wf);
            if (blockers.length) {
                const manual = blockers.filter(b => b.manual);
                renderChainStatus();
                appendLog(alertBox(manual.length ? 'warning' : 'error',
                    `⛔ Chaîne arrêtée avant <strong>${c.num} — ${c.nom}</strong> :` +
                    `<ul style="margin:8px 0 0; padding-left:20px;">` +
                    blockers.map(b => `<li>${b.label}${b.detail ? ` — ${b.detail}` : ''}</li>`).join('') +
                    `</ul>` +
                    `<p style="margin:8px 0 0;">Si ces fichiers existent ailleurs, lance cette étape seule avec son bouton ` +
                    `<strong>🚀 Lancer</strong> : la confirmation permet de passer outre.</p>`));
                return;
            }
            if (!await pushStepInput(c)) {
                appendLog(alertBox('error', `Écriture de l'input impossible pour ${c.nom}.`));
                return;
            }
            const launched = await launchStep(c.type, wf);
            await inspectChain();
            if (!launched || stepState(c.type, wf) !== 'done') {
                renderChainStatus();
                appendLog(alertBox('error',
                    `⛔ <strong>${c.num} — ${c.nom}</strong> n'a pas abouti (« JOB DONE » absent). ` +
                    `Ouvre 📊 Suivi pour lire <code>${stepOutPath(c.type)}</code>.`));
                return;
            }
            appendLog(alertBox('success', `✅ ${c.num} — ${c.nom} vérifié (JOB DONE + fichiers attendus).`));
        }
        await refreshChainStatus();
        appendLog(alertBox('success',
            `🎉 <strong>${WORKFLOW_LABEL[wf].name}</strong> terminé et vérifié — onglet <strong>Résultats</strong> pour lire Tᶜ.`));
    }

    /* ====================================================================
     *  Bandeau parallélisation
     * ==================================================================== */
    function bindParallel() {
        $$('.np-btn').forEach(b => b.addEventListener('click', () => {
            $$('.np-btn').forEach(x => x.classList.remove('active'));
            b.classList.add('active');
            const v = b.dataset.np;
            const N = APP.cpuCount;
            let np = 1;
            if (v === 'quart')    np = Math.max(1, Math.floor(N / 4));
            else if (v === 'demi') np = Math.max(1, Math.floor(N / 2));
            else if (v === 'max')  np = N;
            else np = parseInt(v, 10) || 1;
            $('#fld_nprocs').value = np;
            updateCPUInfo();
        }));
        $('#fld_nprocs').addEventListener('input', () => {
            $$('.np-btn').forEach(b => b.classList.remove('active'));
            updateCPUInfo();
        });
        $('#fld_nthreads').addEventListener('input', updateCPUInfo);
        $('#btnDetectCPU').addEventListener('click', () => {
            APP.cpuCount = navigator.hardwareConcurrency || 4;
            updateCPUInfo();
        });
        updateCPUInfo();
    }

    function updateCPUInfo() {
        const np = intv('fld_nprocs', 1);
        const nt = intv('fld_nthreads', 1);
        $('#cpuInfo').textContent = `${APP.cpuCount} cœurs · ${np}×${nt} = ${np*nt}`;
        const steps = calcStepsForRun(APP.workflow);
        const seq = steps.length ? steps.map(c => c.prog).join(' → ') : 'choisis un workflow';
        $('#cmdPreview').textContent = `${np > 1 ? `mpirun -np ${np}` : 'séquentiel'} · ${seq}`;
    }

    /* ====================================================================
     *  Pseudopotentiels
     * ==================================================================== */
    const ELEMENT_MASS = {
        H:1.008, He:4.003, Li:6.941, Be:9.012, B:10.811, C:12.011, N:14.007, O:15.999,
        F:18.998, Na:22.990, Mg:24.305, Al:26.982, Si:28.086, P:30.974, S:32.065, Cl:35.453,
        K:39.098, Ca:40.078, Sc:44.956, Ti:47.867, V:50.942, Cr:51.996, Mn:54.938, Fe:55.845,
        Co:58.933, Ni:58.693, Cu:63.546, Zn:65.380, Ga:69.723, Ge:72.640, As:74.922, Se:78.971,
        Br:79.904, Rb:85.468, Sr:87.620, Y:88.906, Zr:91.224, Nb:92.906, Mo:95.950, Ru:101.07,
        Rh:102.906, Pd:106.42, Ag:107.868, Cd:112.411, In:114.818, Sn:118.710, Sb:121.760,
        Te:127.60, I:126.904, Cs:132.905, Ba:137.327, La:138.905, Hf:178.49, Ta:180.948,
        W:183.84, Re:186.207, Os:190.23, Ir:192.217, Pt:195.084, Au:196.967, Hg:200.592,
        Tl:204.383, Pb:207.2, Bi:208.980,
    };

    /**
     * Suggestion Norm-Conserving (PseudoDojo) : le couplage électron-phonon de
     * QE exige des pseudos NC — proposer un nom PAW/USPP enverrait l'utilisateur
     * vers un fichier que ph.x refusera.
     */
    function defaultPseudoFilename(symbol) {
        return `${symbol}_ONCV_PBE-1.2.upf`;
    }

    function inferSpeciesFromMaterial(formula) {
        if (!formula) return [];
        const re = /([A-Z][a-z]?)(\d*)/g;
        const seen = new Set();
        const species = [];
        let m;
        while ((m = re.exec(formula)) !== null) {
            const sym = m[1];
            if (seen.has(sym)) continue;
            seen.add(sym);
            species.push({
                symbol: sym,
                mass: ELEMENT_MASS[sym] || 1.0,
                pseudo: defaultPseudoFilename(sym),
            });
        }
        return species;
    }

    function getPseudoSpecies() {
        if (APP.structure?.species?.length) return APP.structure.species;
        return inferSpeciesFromMaterial(APP.material);
    }

    async function refreshPseudoTable() {
        const tbody = $('#pseudoTable tbody');
        const inferHint = $('#pseudoInferHint');
        tbody.innerHTML = '';
        const species = getPseudoSpecies();
        const fromStructure = !!(APP.structure?.species?.length);

        if (inferHint) {
            if (!fromStructure && species.length) {
                inferHint.style.display = 'block';
                inferHint.textContent =
                    'Éléments déduits du nom du matériau (pas encore de vc-relax.out). ' +
                    'Les noms de fichiers sont des suggestions PseudoDojo — ajuste-les si besoin.';
            } else {
                inferHint.style.display = 'none';
                inferHint.textContent = '';
            }
        }

        if (!species.length) {
            tbody.appendChild(el('tr', {}, el('td', { colspan: 4, class: 'muted text-center' },
                "Valide un matériau pour lister les pseudos requis.")));
            $('#pseudoCheckBox').innerHTML = '';
            setBadge('pseudos', 'warn', 'à vérifier');
            return;
        }
        const pseudoRel = txt('fld_pseudo_dir', '../../../pseudos/');
        const pseudoCheckPath = APP._health?.pseudos_dir || pseudoRel;
        const listing = APP.apiOnline ? await SupraAPI.checkPseudos(
            species.map(s => s.pseudo), pseudoCheckPath
        ) : { results: species.map(s => ({ name: s.pseudo, kind: 'UNKNOWN' })) };

        (listing.results || []).forEach((r, i) => {
            const sp = species[i] || {};
            const kindClass = (r.kind || 'unknown').toLowerCase();
            tbody.appendChild(el('tr', {},
                el('td', { class: 'mono' }, sp.symbol || '—'),
                el('td', { class: 'mono' }, r.name),
                el('td', {}, el('span', { class: `badge ${kindClass}` }, r.kind || '—')),
                el('td', {},
                    el('button', { class: 'btn btn-secondary',
                        style: 'padding:4px 12px; font-size:0.82em;',
                        onclick: () => promptUploadPseudo() }, '📤 Remplacer'))
            ));
        });

        const box = $('#pseudoCheckBox');
        if (listing.all_nc) {
            box.innerHTML = alertBox('success',
                '✅ Tous les pseudopotentiels sont <strong>Norm-Conserving</strong>.');
            setBadge('pseudos', 'ok', 'tous NC');
        } else {
            const issues = (listing.issues || []).map(s => `<li>${s}</li>`).join('');
            const onlyMissing = (listing.results || []).every(r =>
                r.kind === 'MISSING' || r.kind === 'UNKNOWN');
            const level = onlyMissing ? 'warning' : 'error';
            const badgeKind = onlyMissing ? 'warn' : 'err';
            const badgeTxt = onlyMissing ? 'fichiers manquants' : 'non-NC';
            box.innerHTML = alertBox(level,
                (onlyMissing
                    ? '<strong>⚠️ Pseudos manquants ou non lus.</strong>'
                    : '<strong>⛔ Pseudopotentiels non-NC détectés.</strong>') +
                (issues ? `<ul style="padding-left:22px; margin-top:6px;">${issues}</ul>` : '') +
                '<br>Télécharge les versions NC depuis ' +
                '<a href="http://www.pseudo-dojo.org/" target="_blank" rel="noopener">PseudoDojo</a> ' +
                'ou importe-les ci-dessus.');
            setBadge('pseudos', badgeKind, badgeTxt);
        }
    }

    async function uploadPseudo(file) {
        const content = await file.text();
        return await fetch(SupraAPI.getBaseURL() + '/api/pseudo/upload', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: file.name, content }),
        }).then(r => r.json()).catch(() => null);
    }

    function promptUploadPseudo() {
        const input = document.createElement('input');
        input.type = 'file'; input.accept = '.upf,.UPF';
        input.onchange = async () => {
            const f = input.files[0];
            if (!f) return;
            const res = await uploadPseudo(f);
            if (res && res.ok) refreshPseudoTable();
        };
        input.click();
    }

    function bindPseudoUpload() {
        $('#fld_pseudo_upload')?.addEventListener('change', async ev => {
            for (const f of Array.from(ev.target.files || [])) await uploadPseudo(f);
            refreshPseudoTable();
        });
    }

    /* ====================================================================
     *  Grilles K vs Q
     * ==================================================================== */
    function readGrids() {
        const kc = [ intv('fld_knscf_1', 24),   intv('fld_knscf_2', 24),   intv('fld_knscf_3', 24) ];
        const ke = [ intv('fld_knscf_epw_1', 8), intv('fld_knscf_epw_2', 8), intv('fld_knscf_epw_3', 8) ];
        const q  = [ intv('fld_q_1', 4),         intv('fld_q_2', 4),         intv('fld_q_3', 4) ];
        return { kc, ke, q };
    }

    function updateKQVisual() {
        const { kc, ke, q } = readGrids();
        $('#kq_kc_val').textContent   = `${kc[0]} × ${kc[1]} × ${kc[2]}`;
        $('#kq_kc_count').textContent = `${(kc[0]*kc[1]*kc[2]).toLocaleString('fr-FR')} pts`;
        $('#kq_ke_val').textContent   = `${ke[0]} × ${ke[1]} × ${ke[2]}`;
        $('#kq_ke_count').textContent = `${(ke[0]*ke[1]*ke[2]).toLocaleString('fr-FR')} pts`;
        $('#kq_q_val').textContent    = `${q[0]} × ${q[1]} × ${q[2]}`;
        $('#kq_q_count').textContent  = `${(q[0]*q[1]*q[2]).toLocaleString('fr-FR')} pts`;

        const rc = [0,1,2].map(i => q[i] > 0 ? kc[i]/q[i] : 0);
        const intC = [0,1,2].every(i => q[i] > 0 && kc[i] % q[i] === 0);
        const minC = Math.min(...rc);
        let statusC = 'success', labelC = '✓ ratio entier ≥ 4';
        if (!intC) { statusC = 'error'; labelC = '✗ ratio non entier'; }
        else if (minC < 2) { statusC = 'error'; labelC = '✗ ratio < 2'; }
        else if (minC < 4) { statusC = 'warning'; labelC = '⚠ ratio < 4'; }
        $('#ratioClassicVal').textContent    = rc.map(r => r.toFixed(1)).join(' × ');
        $('#ratioClassicStatus').textContent = labelC;
        $('#ratioClassic').dataset.status    = statusC;

        const re = [0,1,2].map(i => q[i] > 0 ? ke[i]/q[i] : 0);
        const intE = [0,1,2].every(i => q[i] > 0 && ke[i] % q[i] === 0);
        let statusE = 'success', labelE = `✓ k_coarse / q = ${re.map(r => r.toFixed(1)).join(' × ')}`;
        if (!intE) { statusE = 'error'; labelE = '✗ ratio non entier'; }
        $('#ratioEpwVal').textContent    = re.map(r => r.toFixed(1)).join(' × ');
        $('#ratioEpwStatus').textContent = labelE;
        $('#ratioEPW').dataset.status    = statusE;
    }

    function bindGridInputs() {
        ['fld_knscf_1','fld_knscf_2','fld_knscf_3',
         'fld_knscf_epw_1','fld_knscf_epw_2','fld_knscf_epw_3',
         'fld_q_1','fld_q_2','fld_q_3'].forEach(id =>
            $('#' + id)?.addEventListener('input', updateKQVisual));
    }

    /* ====================================================================
     *  Paramètres unifiés
     * ==================================================================== */
    function gatherParams() {
        const { kc, ke, q } = readGrids();
        let projections = null;
        const projTxt = (txt('fld_epw_proj', 'auto') || '').trim();
        if (projTxt && projTxt.toLowerCase() !== 'auto') {
            projections = projTxt.split(/[;,]/).map(s => s.trim()).filter(Boolean);
        }
        return {
            material:    APP.material, prefix: APP.material,
            method:      APP.workflow || 'classic',
            outdir:      `./${APP.material}_outdir/`,
            pseudo_dir:  txt('fld_pseudo_dir', '../../../pseudos/'),
            // Après vc-relax (cell_dofree='all') la maille finale est en
            // CELL_PARAMETERS : on force ibrav=0 pour ne pas mélanger Bravais
            // d'entrée et vecteurs relaxés.
            ibrav: (() => {
                const s = APP.structure;
                if (s?.cell_parameters) return 0;
                return s?.ibrav ?? 0;
            })(),
            celldm:      APP.structure?.celldm
                || (APP.structure?.alat ? [APP.structure.alat, 0, 0, 0, 0, 0] : [0, 0, 0, 0, 0, 0]),
            alat:        APP.structure?.alat || null,
            cell_unit:   APP.structure?.cell_unit || (APP.structure?.cell_parameters ? 'alat' : 'angstrom'),
            nat:         APP.structure?.positions?.length || 1,
            ntyp:        APP.structure?.species?.length   || 1,
            // Les champs sont préremplis depuis vc-relax.out : ils font foi, sinon
            // une valeur saisie dans la carte SCF resterait sans effet.
            ecutwfc:     intv('fld_ecutwfc', APP.structure?.ecutwfc || 60),
            ecutrho:     intv('fld_ecutrho', APP.structure?.ecutrho || 300),
            species:     APP.structure?.species   || [],
            positions:   APP.structure?.positions || [],
            atomic_positions_units: APP.structure?.positions_unit || 'crystal',
            cell_parameters: APP.structure?.cell_parameters || null,

            k_scf:       [ intv('fld_kscf_1', 12), intv('fld_kscf_2', 12), intv('fld_kscf_3', 12) ],
            k_nscf:      kc,
            k_nscf_epw:  ke,
            q_phonon:    q,
            smearing:    txt('fld_smearing', 'mv'),
            degauss:     num('fld_degauss', 0.02),
            conv_thr_scf:  parseQENum(txt('fld_conv_scf',  '1.0d-10')),
            conv_thr_nscf: parseQENum(APP.workflow === 'epw'
                ? txt('fld_conv_nscf_epw', '1.0d-10')
                : txt('fld_conv_nscf', '1.0d-10')),
            nbnd:        APP.workflow === 'epw'
                ? intv('fld_nbnd_epw', 30)
                : (intv('fld_nbnd', 0) || null),

            tr2_ph:           parseQENum(txt('fld_tr2_ph', '1.0d-12')),
            electron_phonon:  txt('fld_ep_mode', 'interpolated'),
            fildvscf:         txt('fld_fildvscf', 'aldv'),
            fildyn:           txt('fld_fildyn', 'matdyn'),

            mu_star:        num('fld_mu_star', 0.10),
            flfrc:          txt('fld_flfrc',  'ifc.fc'),
            fila2F:         txt('fld_fila2F', 'a2F.dat'),
            deltaE_phonon:  num('fld_deltaE', 1.0),
            alpha2f_smear:  num('fld_alpha2f_smear', 0.05),

            // Dossier produit par pp.py (dyn + dvscf regroupés), relatif au dossier de calcul
            epw_dvscf_dir:    './save/',
            epw_nbndsub:      intv('fld_epw_nbndsub', 5),
            epw_num_iter:     500,
            epw_dis_win_min:  num('fld_epw_dis_win_min', -3.0),
            epw_dis_win_max:  num('fld_epw_dis_win_max', 15.0),
            epw_dis_froz_min: num('fld_epw_dis_froz_min', -3.0),
            epw_dis_froz_max: num('fld_epw_dis_froz_max', 8.0),
            epw_projections:  projections,
            epw_fsthick:      num('fld_epw_fsthick', 0.4),
            epw_degaussw:     num('fld_epw_degaussw', 0.05),
            epw_degaussq:     num('fld_epw_degaussq', 0.5),
            epw_aniso:        txt('fld_epw_aniso', 'iso') === 'aniso',
            epw_nstemp:       intv('fld_epw_nstemp', 30),
            epw_temp_max:     num('fld_epw_tmax', 30),
            epw_wscut:        num('fld_epw_wscut', 1.0),
            k_fine_epw:       [ intv('fld_epw_nkf_1', 40), intv('fld_epw_nkf_2', 40), intv('fld_epw_nkf_3', 40) ],
            q_fine_epw:       [ intv('fld_epw_nqf_1', 40), intv('fld_epw_nqf_2', 40), intv('fld_epw_nqf_3', 40) ],
            sscha_nconfigs:   intv('fld_sscha_nconfigs', 64),
            sscha_disp:       num('fld_sscha_disp', 0.08),
            sscha_seed:       intv('fld_sscha_seed', 42),
            sscha_super:      [ intv('fld_sscha_super_1', 2), intv('fld_sscha_super_2', 2), intv('fld_sscha_super_3', 2) ],
            sscha_conv_thr:   txt('fld_sscha_conv_thr', '1.0d-8'),
            sscha_ecutwfc:    intv('fld_sscha_ecutwfc', 80),
            sscha_k:          [ intv('fld_sscha_k_1', 6), intv('fld_sscha_k_2', 6), intv('fld_sscha_k_3', 6) ],
            sscha_temp:       num('fld_sscha_temp', 300),
            sscha_maxiter:    intv('fld_sscha_maxiter', 100),
            sscha_tol:        txt('fld_sscha_tol', '1.0d-6'),
            sscha_mu_star:    num('fld_sscha_mu_star', 0.10),
        };
    }

    /* ====================================================================
     *  Génération de tous les fichiers (bouton global)
     * ==================================================================== */
    async function generateAndSave() {
        if (!await ensureFilesGenerated()) return;
        if (!APP.apiOnline) {
            setGenStatus('warning',
                `⚠️ API hors-ligne. Inputs en mémoire — onglet « Inputs générés » ou téléchargement par étape.`);
            renderCalcList();
            return;
        }
        const paths = getWorkflowPaths();
        const wfFiles = APP.files[APP.workflow] || {};
        const ops = Object.entries(wfFiles).map(([key, f]) =>
            SupraAPI.saveFile(`${paths.workDir}/${f.name}`, f.content)
                .then(r => ({ ok: r?.ok, key, err: r?.error }))
        );
        const results = await Promise.all(ops);
        const failed = results.filter(r => !r.ok);
        if (!failed.length) {
            setGenStatus('success',
                `✅ ${results.length} fichier(s) <strong>${WORKFLOW_LABEL[APP.workflow].name}</strong> sauvegardés dans <code>${paths.workDir}/</code>.`);
            results.forEach(r => setCalcState(r.key, 'ready', 'prêt'));
            renderCalcList();
        } else {
            setGenStatus('error',
                `Échec partiel : <ul>${failed.map(r => `<li>${r.key} : ${r.err}</li>`).join('')}</ul>`);
        }
    }

    const setGenStatus = (kind, html) => { $('#generateStatus').innerHTML = alertBox(kind, html); };

    /* ====================================================================
     *  Onglet 2 — inputs générés
     * ==================================================================== */
    function renderInputsPanel(bundle) {
        const root = $('#inputsPanel');
        if (!root) return;
        root.innerHTML = '';
        if (!bundle) return;
        const titles = {
            scf:'1 SCF', nscf:'2 NSCF', ph:'3 ph.x', q2r:'4a q2r.x',
            matdyn:'4b matdyn.x → Tᶜ', alpha2f:'4c alpha2f.x (opt.)',
            epw:'4 epw.x → Tᶜ + Δ',
            config:'1 configs', pw_forces:'2 pw.x forces', sscha:'3 SSCHA',
        };
        const methods = APP.workflow ? [APP.workflow] : ['classic', 'epw', 'sscha'];
        const colors = { classic: '#06b6d4', epw: '#ec4899', sscha: '#f59e0b' };
        const labels = {
            classic: '📐 WF1 — Classique',
            epw:     '⚡ WF2 — EPW',
            sscha:   '🌡️ WF3 — SSCHA',
        };

        methods.forEach(method => {
            const files = bundle[method];
            if (!files || !Object.keys(files).length) return;
            const paths = APP.workflow ? getWorkflowPaths() : { workDir: `${APP.baseDir || 'inputs'}/${method}` };
            const wrap = el('div', { class: 'card', style: `border-left: 4px solid ${colors[method]};` });
            wrap.appendChild(el('h3', {}, `${labels[method]}  —  ${paths.workDir}/`));
            Object.entries(files).forEach(([key, f]) => {
                const sub = el('div', { class: 'card collapsible', 'data-open': 'false',
                                        style: `margin: 10px 0; border-left: 4px solid ${colors[method]};` });
                const header = el('div', { class: 'collapsible-header' },
                    el('div', { class: 'h-left' },
                        el('h2', { style: 'font-size:1em; margin:0;' }, `${titles[key] || key} — ${f.name}`)),
                    el('div', { class: 'h-right' },
                        el('button', { class: 'btn btn-secondary',
                            style: 'padding:5px 12px; font-size:0.82em;',
                            onclick: (e) => { e.stopPropagation(); downloadFile(f.name, f.content); } }, '⬇️ Télécharger'),
                        el('button', { class: 'btn btn-secondary',
                            style: 'padding:5px 12px; font-size:0.82em;',
                            onclick: (e) => { e.stopPropagation(); navigator.clipboard.writeText(f.content); } }, '📋 Copier'),
                        el('span', { class: 'arrow' }, '▾'),
                    )
                );
                const body = el('div', { class: 'collapsible-body' }, el('pre', {}, f.content));
                sub.appendChild(header); sub.appendChild(body);
                wrap.appendChild(sub);
            });
            root.appendChild(wrap);
        });
        bindCollapsibles();
    }

    function downloadFile(name, content) {
        const blob = new Blob([content], { type: 'text/plain' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob); a.download = name; a.click();
        URL.revokeObjectURL(a.href);
    }

    /* ====================================================================
     *  Exécution
     * ==================================================================== */
    function appendLog(html) {
        const log = $('#runLog');
        if (!log) return;
        const ts = `<span class="mono muted">${new Date().toLocaleTimeString('fr-FR')}</span> · `;
        const payload = String(html ?? '').trim();
        // Ne pas re-envelopper un alertBox déjà typé (sinon tout devient alert-info).
        if (/^<div\s+class="alert\s+alert-/.test(payload)) {
            const wrap = document.createElement('div');
            wrap.innerHTML = payload;
            const inner = wrap.firstElementChild;
            if (inner) {
                inner.insertAdjacentHTML('afterbegin', ts);
                log.prepend(inner);
                return;
            }
        }
        const block = el('div', { class: 'alert alert-info' });
        block.innerHTML = ts + payload;
        log.prepend(block);
    }

    async function launchStep(stepId, method) {
        if (!APP.material || !APP.files) {
            appendLog(alertBox('error', "Génère d'abord les fichiers d'entrée."));
            return false;
        }
        const program = ({
            scf: 'pw.x', nscf: 'pw.x', ph: 'ph.x',
            q2r: 'q2r.x', matdyn: 'matdyn.x', alpha2f: 'alpha2f.x',
            epw: 'epw.x', pw_forces: 'pw.x',
            config: null, sscha: null,
        })[stepId];
        const fileObj = APP.files[method]?.[stepId];
        if (!fileObj) {
            appendLog(alertBox('error', `Fichier ${method}/${stepId} non disponible.`));
            return false;
        }
        if (!program) {
            appendLog(alertBox('warning',
                `WF3 · étape <code>${stepId}</code> : génération d'input OK, exécution automatique SSCHA bientôt disponible via l'API.`));
            setCalcState(stepId, 'ready', 'input prêt');
            return false;
        }
        const paths = getWorkflowPaths();
        const workdir = paths.workDir;
        const inPath  = `${workdir}/${fileObj.name}`;
        const outPath = `${paths.outputDir}/${fileObj.name.replace(/\.in$/, '.out')}`;
        const nprocs   = intv('fld_nprocs', 1);
        const nthreads = intv('fld_nthreads', 1);

        setCalcState(stepId, 'running', 'lancement…');
        appendLog(`🚀 <code>${program}</code> sur <code>${inPath}</code> (${nprocs}×${nthreads}).`);

        const r = await SupraAPI.run({ program, input: inPath, output: outPath, workdir, nprocs, nthreads });
        if (!r || !r.ok) {
            appendLog(alertBox('error', `Échec lancement : ${r?.error || 'inconnu'}`));
            setCalcState(stepId, 'error', 'échec');
            return false;
        }
        appendLog(`📦 Job <code>${r.job_id}</code> en cours…`);
        const final = await pollJob(r.job_id, stepId);
        if (final?.status === 'completed') {
            appendLog(alertBox('success', `✅ ${program} terminé (${final.elapsed || ''}).`));
            setCalcState(stepId, 'completed', 'OK');
            return true;
        }
        appendLog(alertBox('error', `❌ ${program} : ${final?.message || 'erreur'}`));
        setCalcState(stepId, 'error', 'échec');
        return false;
    }

    async function pollJob(job_id, stepId) {
        while (true) {
            await new Promise(r => setTimeout(r, 2500));
            const j = await SupraAPI.job(job_id);
            if (!j || !j.ok) return j;
            const st = j.status === 'running' ? 'running'
                     : j.status === 'completed' ? 'completed'
                     : j.status === 'error' ? 'error' : 'ready';
            setCalcState(stepId, st, j.status);
            if (j.status === 'completed' || j.status === 'error') return j;
        }
    }

    function setBadge(section, kind, txtVal) {
        $$(`.badge-status[data-status-of="${section}"]`).forEach(b => {
            b.className = 'badge-status' + (kind ? ' ' + kind : '');
            if (txtVal) b.textContent = txtVal;
        });
    }

    /* ====================================================================
     *  Onglet 4 — résultats
     * ==================================================================== */
    /* ====================================================================
     *  Onglet Résultats — exploration de toute la chaîne, deux voies
     *
     *  Une seule requête (/api/results/explore) rapatrie l'inventaire des
     *  fichiers, les scalaires (λ, ω_log, ⟨ω²⟩^½, N(E_F), Δ₀…), les courbes
     *  traçables et Tᶜ pour chaque μ*. Les quatre modules ci-dessous ne font
     *  que restituer ce contenu.
     * ==================================================================== */
    const RES = { data: null, module: 'synthese', busy: false, openFile: null };

    const ROUTE_META = {
        classic: { label: 'Voie classique (ph.x + λ)', short: 'Classique',
                   color: '#0891b2', accent: '#06b6d4' },
        epw:     { label: 'Voie EPW (Wannier + Éliashberg)', short: 'EPW',
                   color: '#be185d', accent: '#ec4899' },
    };
    const K_PER_MEV = 11.604518121550082;
    const K_PER_CM1 = 1.4387768775039337;

    function outputDirForWorkflow(wf) {
        if (!APP.material) return '';
        if (APP.workflow === wf) return getWorkflowPaths().outputDir;
        return `outputs/${APP.material}/${wf}`;
    }

    /** μ* saisis par l'utilisateur : « 0.10, 0.12, 0.14 » → [0.1, 0.12, 0.14]. */
    function resMuStars() {
        const raw = txt('fld_res_mu_stars', '0.10, 0.12, 0.14');
        const vals = raw.split(/[,;\s]+/)
            .map(s => parseFloat(s))
            .filter(v => Number.isFinite(v) && v > 0 && v < 0.6)
            .slice(0, 8);
        return vals.length ? vals : [0.10, 0.12, 0.14];
    }

    const fmtNum = (v, d = 3) => (v == null || !Number.isFinite(v)) ? null : Number(v).toFixed(d);
    /** Cellule numérique : « — » grisé quand la grandeur est absente. */
    const cell = (v, d, cls = '') => {
        const s = fmtNum(v, d);
        return s == null
            ? `<td class="res-void ${cls}">—</td>`
            : `<td class="res-num ${cls}">${s}</td>`;
    };
    const kb = n => n == null ? '—'
        : n < 1024 ? `${n} o`
        : n < 1048576 ? `${(n / 1024).toFixed(1)} Ko`
        : `${(n / 1048576).toFixed(1)} Mo`;
    const stamp = t => t ? new Date(t * 1000).toLocaleString() : '—';

    function setResStatus(html, kind = 'muted') {
        const box = $('#resExploreStatus');
        if (!box) return;
        box.className = `res-explore-status ${kind}`;
        box.innerHTML = html;
    }

    async function exploreResults() {
        if (RES.busy) return;
        if (!APP.material) {
            setResStatus('Valide d\'abord un matériau (étape 1).', 'res-explore-status');
            $('#resSynthesis').innerHTML = alertBox('warning',
                'Aucun matériau actif : impossible de localiser les fichiers de sortie.');
            return;
        }
        if (!APP.apiOnline) {
            setResStatus('API hors ligne.', 'res-explore-status');
            $('#resSynthesis').innerHTML = alertBox('error',
                'API injoignable : lance <code>./DEMARRER.sh</code> puis réessaie.');
            pingAPI();
            return;
        }
        RES.busy = true;
        setResStatus('Lecture des sorties en cours…');
        const r = await SupraAPI.exploreResults({ material: APP.material, mu_stars: resMuStars() });
        RES.busy = false;
        if (!r || !r.ok) {
            setResStatus('Échec de l\'exploration.', 'res-explore-status');
            $('#resSynthesis').innerHTML = alertBox('error',
                `Exploration impossible : ${escapeHtml(r?.error || 'erreur inconnue')}`);
            pingAPI();
            return;
        }
        RES.data = r;
        const n = (r.classic.inventory.length + r.epw.inventory.length);
        const routes = ['classic', 'epw'].filter(w => r[w].has_data).map(w => ROUTE_META[w].short);
        setResStatus(n
            ? `${n} fichier(s) exploités · ${routes.length ? routes.join(' + ') : 'aucune grandeur extraite'}`
            : 'Aucun fichier de résultat trouvé pour ce matériau.');
        renderResultModules();
        updateResultatsEmptyState();
    }

    function renderResultModules() {
        renderKpiStrip();
        renderSynthesis();
        renderSpectra();
        renderAniso();
        renderInventory();
    }

    function resNoData(msg) {
        return alertBox('info', msg + ' Utilise <strong>🔎 Explorer tous les résultats</strong> après avoir lancé la chaîne.');
    }

    function kpiCard({ label, value, unit, sub, route, warn }) {
        if (value == null || value === '') return '';
        return `<div class="res-kpi" data-route="${route || 'both'}" data-warn="${warn ? 'true' : 'false'}">
            <div class="res-kpi-label">${escapeHtml(label)}</div>
            <div class="res-kpi-value">${escapeHtml(String(value))}${
                unit ? `<span class="res-kpi-unit">${escapeHtml(unit)}</span>` : ''}</div>
            ${sub ? `<div class="res-kpi-sub">${sub}</div>` : ''}
        </div>`;
    }

    function renderKpiStrip() {
        const strip = $('#resKpiStrip');
        const soft = $('#resSoftFlag');
        if (!strip) return;
        const d = RES.data;
        if (!d) {
            strip.innerHTML = '';
            if (soft) soft.innerHTML = '';
            return;
        }
        const sc = d.classic?.scalars || {};
        const se = d.epw?.scalars || {};
        const adC = (d.classic?.tc_table || []).find(r => Math.abs(r.mu_star - 0.13) < 1e-6)
            || d.classic?.tc_table?.[0];
        const adE = (d.epw?.tc_table || []).find(r => Math.abs(r.mu_star - 0.13) < 1e-6)
            || d.epw?.tc_table?.[0];
        const cards = [
            kpiCard({ label: 'λ classique', value: fmtNum(sc.lambda, 3), route: 'classic',
                sub: sc.omega_log_K != null ? `ω_log = ${fmtNum(sc.omega_log_K, 1)} K` : '' }),
            kpiCard({ label: 'λ EPW', value: fmtNum(se.lambda, 3), route: 'epw',
                sub: se.omega_log_K != null ? `ω_log = ${fmtNum(se.omega_log_K, 1)} K` : '' }),
            kpiCard({ label: 'Tᶜ Allen–Dynes', value: fmtNum(adC?.tc_allen_dynes_K, 2), unit: 'K',
                route: 'classic', sub: 'formule · μ*≈0.13' }),
            kpiCard({ label: 'Tᶜ Éliashberg', value: fmtNum(se.tc_interp_K || se.tc_reported_K, 2),
                unit: 'K', route: 'epw',
                sub: se.tc_interp_K != null ? 'fermeture du gap Δ(T)' : 'annoncée par epw.x' }),
            kpiCard({ label: 'Δ₀', value: fmtNum(se.gap_meV, 3), unit: 'meV', route: 'epw',
                sub: se.bcs_ratio != null ? `2Δ/kTᶜ = ${fmtNum(se.bcs_ratio, 2)}` : '' }),
            kpiCard({ label: 'N(E_F)', value: fmtNum(sc.dos_ef ?? se.dos_ef, 3),
                route: 'both', sub: 'états/spin/Ry/maille' }),
        ].filter(Boolean);
        strip.innerHTML = cards.length ? cards.join('') : '';

        if (soft) {
            const softClassic = sc.soft_modes || (sc.omega_min != null && sc.omega_min < 0);
            soft.innerHTML = softClassic
                ? alertBox('warning',
                    `<strong>Modes mous détectés</strong> — ω_min = ${fmtNum(sc.omega_min, 2)} `
                    + `${escapeHtml(sc.omega_min_unit || 'cm⁻¹')}. `
                    + 'La structure phononique est instable : interprète Tᶜ avec prudence.')
                : '';
        }
    }

    /* ── Module 1 : synthèse scalaire ─────────────────────────────────── */
    function renderSynthesis() {
        const box = $('#resSynthesis');
        if (!box) return;
        const d = RES.data;
        if (!d) {
            box.innerHTML = resNoData('Aucune donnée chargée.');
            return;
        }
        const syn = d.synthesis;
        const html = [];
        const tcEliash = d.epw?.scalars?.tc_interp_K;

        if (!syn.rows.length) {
            html.push(alertBox('warning',
                `Aucune grandeur extraite pour <strong>${escapeHtml(d.material)}</strong>. `
                + 'Vérifie que la chaîne est allée jusqu\'à <code>matdyn.x</code>/<code>lambda.x</code> '
                + '(voie classique) ou <code>epw.x</code> (voie EPW).'));
        } else {
            html.push(`
            <div class="res-table-wrap">
                <table class="res-table">
                    <caption>Grandeurs extraites — μ* balayés : ${d.mu_stars.map(m => m.toFixed(2)).join(' / ')}</caption>
                    <thead><tr>
                        <th>Grandeur</th><th>Unité</th>
                        <th class="res-col-classic">Classique</th>
                        <th class="res-col-epw">EPW</th>
                        <th>Écart</th>
                    </tr></thead>
                    <tbody>${syn.rows.map(r => `
                        <tr>
                            <td>${escapeHtml(r.label)}</td>
                            <td class="res-unit">${escapeHtml(r.unit || '—')}</td>
                            ${cell(r.classic, r.digits, 'res-col-classic')}
                            ${cell(r.epw, r.digits, 'res-col-epw')}
                            <td class="${r.delta_pct == null ? 'res-void'
                                : (r.delta_pct >= 0 ? 'res-num res-delta-pos' : 'res-num res-delta-neg')}">${
                                r.delta_pct == null ? '—'
                                    : (r.delta_pct >= 0 ? '+' : '') + r.delta_pct.toFixed(1) + ' %'}</td>
                        </tr>`).join('')}
                    </tbody>
                </table>
            </div>`);
        }

        html.push(`
        <div class="res-table-wrap">
            <table class="res-table">
                <caption>Tᶜ (K) vs μ* — formules McMillan / Allen–Dynes
                    ${tcEliash != null ? ` · Tᶜ Éliashberg EPW = <strong>${fmtNum(tcEliash, 2)} K</strong> (indépendant de μ*)` : ''}</caption>
                <thead><tr>
                    <th>μ*</th>
                    <th class="res-col-classic">McMillan</th>
                    <th class="res-col-classic">Allen–Dynes</th>
                    <th class="res-col-epw">McMillan</th>
                    <th class="res-col-epw">Allen–Dynes</th>
                    <th class="res-col-epw">Éliashberg</th>
                </tr></thead>
                <tbody>${syn.tc_rows.map(r => `
                    <tr>
                        <td class="res-num">${r.mu_star.toFixed(2)}</td>
                        <td class="res-num res-col-classic">${fmtNum(r.classic_mcmillan_K, 2) ?? '—'}</td>
                        <td class="res-num res-col-classic"><strong>${fmtNum(r.classic_allen_dynes_K, 2) ?? '—'}</strong></td>
                        <td class="res-num res-col-epw">${fmtNum(r.epw_mcmillan_K, 2) ?? '—'}</td>
                        <td class="res-num res-col-epw">${fmtNum(r.epw_allen_dynes_K, 2) ?? '—'}</td>
                        <td class="res-num res-col-epw"><strong>${fmtNum(tcEliash, 2) ?? '—'}</strong></td>
                    </tr>`).join('')}
                </tbody>
            </table>
            <p class="muted" style="font-size:0.8em; margin:6px 0 0;">
                Allen–Dynes = McMillan × f₁ × f₂. La colonne Éliashberg vient de la fermeture de Δ(T)
                (ou de la Tᶜ imprimée par <code>epw.x</code>) — c’est la référence physique pour EPW.
            </p>
        </div>`);

        ['classic', 'epw'].forEach(wf => {
            const r = d[wf];
            if (!r.notes.length) return;
            html.push(alertBox('info',
                `<strong>${ROUTE_META[wf].short}</strong> — ` + r.notes.map(escapeHtml).join(' ')));
        });

        box.innerHTML = html.join('');
    }

    /* ── Module 2 : spectres 2D ───────────────────────────────────────── */
    function renderSpectra() {
        const d = RES.data;
        const a2fBox = $('#resPlotA2F');
        const cmpBox = $('#resPlotA2FCompare') || $('#resPlotPhdos');
        const brBox = $('#resPlotBroadenings');
        const dispBox = $('#resPlotDispersion');
        const modeBox = $('#resPlotModeCoupling');
        const gamBox = $('#resPlotGammaOmega');
        const gapBox = $('#resPlotGapT');
        if (!a2fBox) return;
        const clear = (...boxes) => boxes.forEach(b => { if (b) b.innerHTML = ''; });
        if (!d) {
            a2fBox.innerHTML = resNoData('Aucune courbe chargée.');
            clear(cmpBox, brBox, dispBox, modeBox, gamBox, gapBox);
            return;
        }

        // α²F(ω) + F(ω) + λ(ω) par voie
        const cards = [];
        ['classic', 'epw'].forEach(wf => {
            const c = d[wf].curves?.a2f;
            if (!c || !c.n_points) return;
            const meta = ROUTE_META[wf];
            const pts = c.omega.map((w, i) => [w, c.a2f[i]]);
            const lamPts = (c.lambda_w || []).length
                ? c.omega.map((w, i) => [w, c.lambda_w[i]]).filter(p => p[1] != null) : [];
            const series = [{ points: pts, color: meta.color, width: 2, fill: true, label: 'α²F(ω)' }];

            const dos = d[wf].curves?.phdos;
            let dosNote = '';
            if (dos && dos.n_points) {
                const wConv = unitToUnit(dos.unit, c.unit);
                const dMax = Math.max.apply(null, dos.dos) || 1;
                const aMax = Math.max.apply(null, c.a2f) || 1;
                series.push({
                    points: dos.omega.map((w, i) => [w * wConv, dos.dos[i] / dMax * aMax]),
                    color: '#64748b', width: 1.5, dash: '5 4', label: 'F(ω) normalisée',
                });
                dosNote = ' · F(ω) mise à l\'échelle de α²F';
            }
            if (lamPts.length) {
                series.push({ points: lamPts, color: '#7c3aed', width: 2, dash: '2 3',
                              axis: 'y2', label: 'λ(ω)' });
            }

            const svg = SupraPlots.chart({
                series,
                x: { label: `ω (${c.unit})` },
                y: { label: 'α²F(ω)', color: meta.color },
                y2: lamPts.length ? { label: 'λ(ω)', color: '#7c3aed' } : null,
                title: `α²F(ω) — ${meta.short}`,
            });
            const lamTot = d[wf].scalars?.lambda;
            cards.push(`
            <div class="res-plot-card">
                <h5>${meta.short} — α²F(ω) et couplage cumulatif λ(ω)</h5>
                <p class="res-plot-meta">${escapeHtml(c.source)} · ${c.n_points} pts${escapeHtml(dosNote)}${
                    lamTot != null ? ` · λ total = ${lamTot.toFixed(3)}` : ''}</p>
                ${svg}
                <div class="res-legend">
                    <span style="color:${meta.color}">α²F(ω)</span>
                    ${dos && dos.n_points ? '<span style="color:#64748b">F(ω) normalisée</span>' : ''}
                    ${lamPts.length ? '<span style="color:#7c3aed">λ(ω) — axe de droite</span>' : ''}
                </div>
            </div>`);
        });
        a2fBox.innerHTML = cards.length ? cards.join('')
            : alertBox('info', 'Aucun fichier α²F exploitable. Voie classique : <code>matdyn.x</code> '
                + 'avec <code>la2F=.true.</code> écrit <code>a2F.dat</code>. Voie EPW : <code>epw.x</code> '
                + 'écrit <code>&lt;prefix&gt;.a2f</code>.');

        if (cmpBox) {
            const both = ['classic', 'epw']
                .map(wf => ({ wf, c: d[wf].curves?.a2f }))
                .filter(o => o.c && o.c.n_points && o.c.omega_K?.length);
            if (both.length === 2) {
                cmpBox.innerHTML = `
                <div class="res-plot-card">
                    <h5>Comparaison α²F(ω) — Classique vs EPW</h5>
                    <p class="res-plot-meta">Axes ramenés en meV pour rendre les deux voies comparables.</p>
                    ${SupraPlots.chart({
                        series: both.map(o => ({
                            points: o.c.omega_K.map((wk, i) => [wk / K_PER_MEV, o.c.a2f[i]]),
                            color: ROUTE_META[o.wf].color, width: 2,
                            dash: o.wf === 'epw' ? '6 4' : null,
                        })),
                        x: { label: 'ω (meV)' }, y: { label: 'α²F(ω)' },
                        title: 'α²F comparé',
                    })}
                    <div class="res-legend">
                        <span style="color:${ROUTE_META.classic.color}">Classique</span>
                        <span style="color:${ROUTE_META.epw.color}">EPW</span>
                    </div>
                </div>`;
            } else {
                cmpBox.innerHTML = '';
            }
        }

        // λ(σ) — élargissements gaussiens de lambda.x
        if (brBox) {
            const rows = d.classic.curves?.broadenings?.rows || [];
            const pts = rows
                .filter(r => r.sigma_Ry != null && r.lambda != null)
                .map(r => [r.sigma_Ry, r.lambda]);
            if (pts.length >= 2) {
                const nef = rows.filter(r => r.dos_ef != null)
                    .map(r => [r.sigma_Ry, r.dos_ef]);
                const series = [{ points: pts, color: ROUTE_META.classic.color, width: 2.5,
                    fill: true, label: 'λ(σ)' }];
                if (nef.length >= 2) {
                    series.push({ points: nef, color: '#7c3aed', width: 1.8, dash: '4 3',
                        axis: 'y2', label: 'N(E_F)' });
                }
                brBox.innerHTML = `
                <div class="res-plot-card">
                    <h5>λ et N(E_F) vs élargissement σ — lambda.x</h5>
                    <p class="res-plot-meta">${escapeHtml(d.classic.curves.broadenings.source || '')}
                        · ${pts.length} élargissements</p>
                    ${SupraPlots.chart({
                        series,
                        x: { label: 'σ (Ry)' },
                        y: { label: 'λ', color: ROUTE_META.classic.color },
                        y2: nef.length >= 2 ? { label: 'N(E_F)', color: '#7c3aed' } : null,
                        title: 'λ(σ)',
                    })}
                    <div class="res-legend">
                        <span style="color:${ROUTE_META.classic.color}">λ(σ)</span>
                        ${nef.length >= 2 ? '<span style="color:#7c3aed">N(E_F) — axe droit</span>' : ''}
                    </div>
                </div>`;
            } else {
                brBox.innerHTML = '';
            }
        }

        if (dispBox) {
            const disp = d.classic.curves?.dispersion;
            if (disp && disp.n_modes) {
                const weights = modeWeights(d.classic.curves?.elph, disp.n_modes);
                dispBox.innerHTML = `
                <div class="res-plot-card">
                    <h5>Dispersion des phonons ω(q)${weights ? ' — épaisseur ∝ λ_qν' : ''}</h5>
                    <p class="res-plot-meta">${escapeHtml(disp.source)} · ${disp.n_modes} branches
                        · ω_min = ${fmtNum(disp.omega_min, 2)} ${escapeHtml(disp.unit || '')}</p>
                    ${SupraPlots.dispersion({
                        q: disp.q, bands: disp.bands, weights,
                        x: { label: 'chemin q' }, y: { label: `ω (${disp.unit})` },
                        color: ROUTE_META.classic.color, height: 340,
                        title: 'dispersion de phonons',
                    })}
                </div>`;
            } else {
                dispBox.innerHTML = '';
            }
        }

        if (modeBox) {
            const elph = d.classic.curves?.elph;
            const pts = (elph?.modes || [])
                .filter(m => m.omega_cmm1 != null && m.lambda != null)
                .map(m => ({ x: m.omega_cmm1, y: Math.abs(m.lambda), w: Math.abs(m.gamma || 0) }));
            modeBox.innerHTML = pts.length ? `
            <div class="res-plot-card">
                <h5>Couplage mode par mode λ_qν — taille ∝ γ_qν</h5>
                <p class="res-plot-meta">${elph.n_qpoints} point(s) q · ${pts.length} modes · ${escapeHtml(elph.source)}</p>
                ${SupraPlots.scatter({
                    points: pts, x: { label: 'ω_qν (cm⁻¹)' }, y: { label: 'λ_qν', color: ROUTE_META.classic.color },
                    color: ROUTE_META.classic.accent, stroke: ROUTE_META.classic.color, height: 300,
                    title: 'couplage par mode',
                })}
            </div>` : '';
        }

        // Spectre γ(ω) agrégé
        if (gamBox) {
            const modes = d.classic.curves?.elph?.modes || [];
            const pts = modes
                .filter(m => m.omega_cmm1 != null && m.gamma != null && m.gamma > 0)
                .map(m => [m.omega_cmm1, m.gamma])
                .sort((a, b) => a[0] - b[0]);
            if (pts.length >= 3) {
                gamBox.innerHTML = `
                <div class="res-plot-card">
                    <h5>Largeurs de raie γ_qν(ω) — elph</h5>
                    <p class="res-plot-meta">${pts.length} modes · ${escapeHtml(d.classic.curves.elph.source || '')}</p>
                    ${SupraPlots.chart({
                        series: [{ points: pts, color: '#f59e0b', width: 1.2 }],
                        x: { label: 'ω (cm⁻¹)' }, y: { label: 'γ', color: '#f59e0b' },
                        title: 'γ(ω)',
                    })}
                </div>`;
            } else {
                gamBox.innerHTML = '';
            }
        }

        if (gapBox) {
            const g = d.epw.curves?.gap_vs_T;
            if (g && g.pairs?.length > 1) {
                const tc = d.epw.scalars?.tc_interp_K || d.epw.scalars?.tc_reported_K;
                gapBox.innerHTML = `
                <div class="res-plot-card">
                    <h5>Gap supraconducteur Δ(T) — EPW</h5>
                    <p class="res-plot-meta">${escapeHtml(g.source)} · ${g.n_points} températures</p>
                    ${SupraPlots.chart({
                        series: [{ points: g.pairs.map(p => [p[0], p[1]]),
                                   color: ROUTE_META.epw.color, width: 2.5, fill: true }],
                        markers: tc ? [{ x: tc, label: `Tᶜ = ${tc.toFixed(2)} K` }] : [],
                        x: { label: 'T (K)' }, y: { label: 'Δ (meV)', color: ROUTE_META.epw.color },
                        title: 'gap en température',
                    })}
                </div>`;
            } else {
                gapBox.innerHTML = '';
            }
        }
    }

    /** Facteur de conversion entre deux unités de fréquence. */
    function unitToUnit(from, to) {
        const K = { 'cm-1': K_PER_CM1, 'meV': K_PER_MEV, 'THz': 47.99243073366221,
                    'Ry': 157887.5124, 'K': 1 };
        const a = K[from] || K_PER_CM1;
        const b = K[to] || K_PER_CM1;
        return a / b;
    }

    /** Poids relatif de chaque branche : λ moyen du mode sur la grille q. */
    function modeWeights(elph, nModes) {
        if (!elph || !elph.modes?.length) return null;
        const sum = new Array(nModes).fill(0);
        const cnt = new Array(nModes).fill(0);
        elph.modes.forEach(m => {
            const i = (m.mode || 0) - 1;
            if (i < 0 || i >= nModes || m.lambda == null) return;
            sum[i] += Math.abs(m.lambda);
            cnt[i] += 1;
        });
        const mean = sum.map((s, i) => cnt[i] ? s / cnt[i] : 0);
        const max = Math.max.apply(null, mean);
        if (!(max > 0)) return null;
        return mean.map(v => v / max);
    }

    /* ── Module 3 : anisotropie et surface de Fermi ───────────────────── */
    function renderAniso() {
        const d = RES.data;
        const histBox = $('#resPlotGapHist');
        const sumBox = $('#resAnisoSummary');
        const pairsBox = $('#resPlotLambdaPairs');
        const decayBox = $('#resPlotDecay');
        const specBox = $('#resPlotSpecfun');
        const pbndBox = $('#resPlotPband');
        if (!histBox) return;
        if (!d) {
            histBox.innerHTML = resNoData('Aucune donnée d\'anisotropie.');
            [sumBox, pairsBox, decayBox, specBox, pbndBox].forEach(b => { if (b) b.innerHTML = ''; });
            return;
        }

        const h = d.epw.curves?.gap_distribution;
        histBox.innerHTML = (h && h.n_values)
            ? `<div class="res-plot-card">
                <h5>Distribution de Δ_k sur la surface de Fermi</h5>
                <p class="res-plot-meta">${escapeHtml(h.source)} · ${h.n_values} valeurs · ${
                    h.n_files > 1 ? `${h.n_files} fichiers de gap détectés · ` : ''}${
                    h.n_sheets} groupe(s) de gap</p>
                ${SupraPlots.bars({
                    centres: h.bins, counts: h.counts,
                    markers: [{ x: h.gap_mean, label: `⟨Δ⟩ = ${h.gap_mean.toFixed(3)} meV` }],
                    x: { label: 'Δ (meV)' }, y: { label: 'nombre d\'états' },
                    color: ROUTE_META.epw.accent, height: 300,
                    title: 'histogramme du gap',
                })}
               </div>`
            : alertBox('info', 'Pas de fichier de gap anisotrope. Il faut <code>epw.x</code> avec '
                + '<code>laniso=.true.</code> : les fichiers <code>&lt;prefix&gt;.imag_aniso_gap0_*</code> '
                + 'contiennent Δ_k sur la surface de Fermi.');

        if (sumBox) {
            const s = d.epw.scalars || {};
            const items = [
                ['Δ₀', fmtNum(s.gap_meV, 3), 'meV'],
                ['⟨Δ⟩', fmtNum(s.gap_mean_meV, 3), 'meV'],
                ['Étendue de Δ', fmtNum(s.gap_spread_meV, 3), 'meV'],
                ['2Δ₀ / k_B Tᶜ', fmtNum(s.bcs_ratio, 2), 'BCS : 3.53'],
                ['Z(0)', fmtNum(s.z_factor, 3), '1 + λ'],
                ['Tᶜ Éliashberg', fmtNum(s.tc_interp_K, 2), 'K'],
                ['Tᶜ (code)', fmtNum(s.tc_reported_K, 2), 'K'],
                ['μ_c', fmtNum(s.mu_star_reported, 3), ''],
            ].filter(it => it[1] != null);
            sumBox.innerHTML = items.length ? `
            <div class="tc-card epw">
                <h3>Régime de couplage — voie EPW ${s.is_anisotropic === true ? '(anisotrope)'
                    : s.is_anisotropic === false ? '(isotrope)' : ''}</h3>
                <div class="tc-grid">${items.map(([k, v, u]) => `
                    <div class="tc-item"><div class="tc-label">${escapeHtml(k)}</div>
                        <div class="tc-value">${v}${u ? `<span class="tc-unit">${escapeHtml(u)}</span>` : ''}</div></div>`).join('')}
                </div>
            </div>` : '';
        }

        if (pairsBox) {
            const lp = d.epw.curves?.lambda_pairs;
            const pts = (lp?.points || [])
                .filter(p => p.omega != null && p.lambda != null)
                .map(p => ({ x: p.omega, y: Math.abs(p.lambda), w: Math.abs(p.lambda) }));
            pairsBox.innerHTML = pts.length ? `
            <div class="res-plot-card">
                <h5>λ(q,ν) — fichier lambda_pairs EPW</h5>
                <p class="res-plot-meta">${escapeHtml(lp.source || '')} · ${pts.length} points</p>
                ${SupraPlots.scatter({
                    points: pts,
                    x: { label: 'ω' }, y: { label: 'λ', color: ROUTE_META.epw.color },
                    color: ROUTE_META.epw.accent, stroke: ROUTE_META.epw.color, height: 300,
                    title: 'λ(q,ν)',
                })}
            </div>` : '';
        }

        if (decayBox) {
            const series = d.epw.curves?.decay?.series || [];
            if (series.length) {
                const colors = ['#06b6d4', '#ec4899', '#8b5cf6', '#f59e0b', '#10b981'];
                decayBox.innerHTML = `
                <div class="res-plot-card">
                    <h5>Décroissance Wannier (qualité de l’interpolation)</h5>
                    <p class="res-plot-meta">${series.length} courbe(s) — une décroissance rapide = bonne localisation</p>
                    ${SupraPlots.chart({
                        series: series.map((s, i) => ({
                            points: s.x.map((x, j) => [x, s.y[j]]),
                            color: colors[i % colors.length], width: 2,
                            label: s.name,
                        })),
                        x: { label: 'distance (unité fichier)' },
                        y: { label: '|élément|' },
                        title: 'decay Wannier',
                    })}
                    <div class="res-legend">${series.map((s, i) =>
                        `<span style="color:${colors[i % colors.length]}">${escapeHtml(s.name)}</span>`).join('')}</div>
                </div>`;
            } else {
                decayBox.innerHTML = '';
            }
        }

        if (specBox) {
            const sf = d.epw.curves?.specfun;
            specBox.innerHTML = (sf && sf.n_points) ? `
            <div class="res-plot-card">
                <h5>Self-énergie / fonction spectrale électronique</h5>
                <p class="res-plot-meta">${escapeHtml(sf.source)} · ${sf.n_points} pts</p>
                ${SupraPlots.chart({
                    series: [{ points: sf.x.map((x, i) => [x, sf.y[i]]), color: '#7c3aed', width: 1.8 }],
                    x: { label: 'énergie / fréquence' }, y: { label: 'Σ″ (unité du fichier)', color: '#7c3aed' },
                    title: 'self-énergie',
                })}
            </div>` : '';
        }

        if (pbndBox) {
            const pb = d.epw.curves?.pbnd;
            pbndBox.innerHTML = (pb && pb.n_points) ? `
            <div class="res-plot-card">
                <h5>Bandes / grandeurs renormalisées (pbnd)</h5>
                <p class="res-plot-meta">${escapeHtml(pb.source)} · ${pb.n_points} pts</p>
                ${SupraPlots.chart({
                    series: [{ points: pb.x.map((x, i) => [x, pb.y[i]]), color: ROUTE_META.epw.color, width: 1.8 }],
                    x: { label: 'k / énergie' }, y: { label: 'valeur', color: ROUTE_META.epw.color },
                    title: 'pbnd',
                })}
            </div>` : '';
        }
    }

    /* ── Module 4 : inventaire et lecture brute ───────────────────────── */
    function renderInventory() {
        const box = $('#resFileInventory');
        if (!box) return;
        const d = RES.data;
        if (!d) {
            box.innerHTML = resNoData('Aucun inventaire.');
            $('#resFileViewer').innerHTML = '';
            return;
        }
        const groups = ['classic', 'epw'].map(wf => {
            const inv = d[wf].inventory;
            const meta = ROUTE_META[wf];
            if (!inv.length) {
                return `<div class="res-inventory-group"><h5>${meta.label}</h5>`
                     + alertBox('info', `Rien trouvé dans <code>${escapeHtml(d[wf].dirs.join('</code>, <code>') || '—')}</code>.`)
                     + '</div>';
            }
            return `
            <div class="res-inventory-group">
                <h5>${meta.label} — ${inv.length} fichier(s)</h5>
                <div class="res-table-wrap">
                    <table class="res-table">
                        <thead><tr>
                            <th>Fichier</th><th>Rôle dans la chaîne</th>
                            <th>Taille</th><th>Modifié</th><th>Lecture</th>
                        </tr></thead>
                        <tbody>${inv.map(f => `
                            <tr>
                                <td><code>${escapeHtml(f.name)}</code><span class="res-src">${escapeHtml(f.path)}</span></td>
                                <td style="text-align:left;">${escapeHtml(f.label)}</td>
                                <td class="res-num">${kb(f.size)}</td>
                                <td class="res-num">${escapeHtml(stamp(f.mtime))}</td>
                                <td><button type="button" class="btn-mini" data-res-file="${escapeHtml(f.path)}">Voir</button></td>
                            </tr>`).join('')}
                        </tbody>
                    </table>
                </div>
            </div>`;
        });
        box.innerHTML = groups.join('');
    }

    async function showRawFile(path) {
        const box = $('#resFileViewer');
        if (!box) return;
        box.innerHTML = alertBox('info', `Lecture de <code>${escapeHtml(path)}</code>…`);
        const r = await SupraAPI.readFile(path, { max_bytes: 400000 });
        if (!r || !r.ok) {
            box.innerHTML = alertBox('error', `Lecture impossible : ${escapeHtml(r?.error || 'erreur')}`);
            return;
        }
        RES.openFile = path;
        box.innerHTML = `
        <div class="res-plot-card">
            <h5>📄 ${escapeHtml(path)}</h5>
            <p class="res-plot-meta">${kb(r.size)}${r.truncated ? ' · aperçu tronqué (début + fin)' : ''}</p>
            <div class="res-file-view">${escapeHtml(r.content)}</div>
        </div>`;
        box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    /* ── Exports : CSV, LaTeX, rapport texte ──────────────────────────── */
    function downloadText(filename, text, mime = 'text/plain;charset=utf-8') {
        const blob = new Blob([text], { type: mime });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    }

    function resExportGuard() {
        if (RES.data) return true;
        setResStatus('Lance d\'abord l\'exploration : il n\'y a rien à exporter.', 'res-explore-status');
        return false;
    }

    function resExportCsv() {
        if (!resExportGuard()) return;
        const d = RES.data;
        // Mêmes arrondis qu'à l'écran : le CSV doit être relisible tel quel.
        const q = (v, dig = 3) => (v == null ? '' : Number(v).toFixed(dig));
        const rows = [
            ['# Supra-QE — synthese des resultats'],
            ['# materiau', d.material],
            ['# date', new Date().toISOString()],
            [],
            ['grandeur', 'unite', 'classique', 'epw', 'ecart_%', 'source_classique', 'source_epw'],
            ...d.synthesis.rows.map(r => [r.label, r.unit, q(r.classic, r.digits), q(r.epw, r.digits),
                                          r.delta_pct == null ? '' : r.delta_pct.toFixed(2),
                                          r.source_classic || '', r.source_epw || '']),
            [],
            ['mu_star', 'tc_mcmillan_classique_K', 'tc_allen_dynes_classique_K',
             'tc_mcmillan_epw_K', 'tc_allen_dynes_epw_K'],
            ...d.synthesis.tc_rows.map(r => [r.mu_star.toFixed(2), q(r.classic_mcmillan_K, 2),
                                             q(r.classic_allen_dynes_K, 2), q(r.epw_mcmillan_K, 2),
                                             q(r.epw_allen_dynes_K, 2)]),
        ];
        const csv = rows.map(r => r.map(c => {
            const s = String(c ?? '');
            return /[",;\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
        }).join(';')).join('\n');
        downloadText(`${d.material}_supra_synthese.csv`, csv, 'text/csv;charset=utf-8');
        setResStatus('CSV exporté.');
    }

    function resExportLatex() {
        if (!resExportGuard()) return;
        const d = RES.data;
        const f = (v, n) => (v == null ? '--' : Number(v).toFixed(n));
        // Un « _ » non échappé casse la compilation : texte échappé, clé assainie.
        const matTex = d.material.replace(/([_&%#$])/g, '\\$1');
        const matKey = d.material.replace(/[^A-Za-z0-9]+/g, '-');
        const lines = [
            '% Supra-QE — table de synthese (a coller dans un document LaTeX)',
            '\\begin{table}[htbp]',
            '  \\centering',
            `  \\caption{Grandeurs supraconductrices de ${matTex} : voie classique (ph.x + $\\lambda$) et voie EPW.}`,
            `  \\label{tab:supra-${matKey}}`,
            '  \\begin{tabular}{lccc}',
            '    \\hline',
            '    Grandeur & Unite & Classique & EPW \\\\',
            '    \\hline',
            ...d.synthesis.rows.map(r =>
                `    ${latexLabel(r.key, r.label)} & ${latexText(r.unit) || '--'} & ${f(r.classic, r.digits)} & ${f(r.epw, r.digits)} \\\\`),
            '    \\hline',
            '  \\end{tabular}',
            '\\end{table}',
            '',
            '\\begin{table}[htbp]',
            '  \\centering',
            `  \\caption{$T_c$ (K) de ${matTex} en fonction de $\\mu^*$ (Allen-Dynes entre parentheses : McMillan).}`,
            '  \\begin{tabular}{ccc}',
            '    \\hline',
            '    $\\mu^*$ & Classique & EPW \\\\',
            '    \\hline',
            ...d.synthesis.tc_rows.map(r =>
                `    ${r.mu_star.toFixed(2)} & ${f(r.classic_allen_dynes_K, 2)} (${f(r.classic_mcmillan_K, 2)})`
                + ` & ${f(r.epw_allen_dynes_K, 2)} (${f(r.epw_mcmillan_K, 2)}) \\\\`),
            '    \\hline',
            '  \\end{tabular}',
            '\\end{table}',
        ];
        downloadText(`${d.material}_supra_table.tex`, lines.join('\n'));
        setResStatus('Table LaTeX exportée.');
    }

    /** Échappe les caractères spéciaux LaTeX dans un texte libre (unité, etc.). */
    function latexText(s) {
        if (s == null || s === '') return '';
        return String(s).replace(/([_&%#$])/g, '\\$1');
    }

    /** Libellés en notation LaTeX pour les grandeurs connues. */
    function latexLabel(key, fallback) {
        const map = {
            lambda: '$\\lambda$', omega_log_K: '$\\omega_{\\ln}$', omega_log_meV: '$\\omega_{\\ln}$',
            omega_2_K: '$\\langle\\omega^2\\rangle^{1/2}$',
            omega_ratio: '$\\langle\\omega^2\\rangle^{1/2}/\\omega_{\\ln}$',
            dos_ef: '$N(E_F)$', ef_eV: '$E_F$', gap_meV: '$\\Delta_0$',
            bcs_ratio: '$2\\Delta_0/k_BT_c$', z_factor: '$Z(0)$',
            tc_reported_K: '$T_c$ (code)', gamma_max: '$\\gamma_{q\\nu}^{max}$',
            lambda_qnu_max: '$\\lambda_{q\\nu}^{max}$',
        };
        return map[key] || latexText(fallback).replace(/[{}]/g, '');
    }

    function resExportReport() {
        if (!resExportGuard()) return;
        const d = RES.data;
        const f = (v, n) => (v == null ? '—' : Number(v).toFixed(n));
        const L = [];
        L.push('════════════════════════════════════════════════════════════');
        L.push(`  Supra-QE — rapport de synthèse : ${d.material}`);
        L.push(`  généré le ${new Date().toLocaleString()}`);
        L.push('════════════════════════════════════════════════════════════', '');
        L.push('MÉTHODOLOGIE');
        L.push('  Voie classique : pw.x SCF → pw.x NSCF dense → ph.x (elph) →');
        L.push('                   q2r.x → matdyn.x/lambda.x → α²F(ω), λ, ω_log.');
        L.push('  Voie EPW       : pw.x SCF → ph.x (dvscf) → pw.x NSCF coarse →');
        L.push('                   epw.x (Wannier + équations d\'Éliashberg).');
        L.push('  λ, ω_log et ⟨ω²⟩^½ sont recalculés par intégration de α²F(ω) :');
        L.push('      λ = 2∫α²F/ω dω,  ω_log = exp[(2/λ)∫α²F ln ω/ω dω],');
        L.push('      ⟨ω²⟩ = (2/λ)∫α²F ω dω.');
        L.push('  Tᶜ : McMillan (1968) et Allen-Dynes (1975) avec f₁ et f₂.', '');

        ['classic', 'epw'].forEach(wf => {
            const r = d[wf];
            L.push('────────────────────────────────────────────────────────────');
            L.push(`  ${ROUTE_META[wf].label}`);
            L.push('────────────────────────────────────────────────────────────');
            if (!r.has_data) {
                L.push('  Aucun résultat exploitable.', '');
                return;
            }
            L.push(`  Répertoires : ${r.dirs.join(', ')}`);
            L.push(`  Fichiers exploités : ${r.inventory.length}`);
            const s = r.scalars;
            const put = (label, v, n, u) => {
                if (v == null) return;
                L.push(`    ${label.padEnd(26)} ${f(v, n)} ${u || ''}`.trimEnd());
            };
            L.push('  Grandeurs :');
            put('λ', s.lambda, 3);
            put('ω_log', s.omega_log_K, 1, 'K');
            put('ω_log', s.omega_log_meV, 2, 'meV');
            put('⟨ω²⟩^½', s.omega_2_K, 1, 'K');
            put('N(E_F)', s.dos_ef, 3, 'états/spin/Ry/maille');
            put('E_F', s.ef_eV, 4, 'eV');
            put('Δ₀', s.gap_meV, 3, 'meV');
            put('2Δ₀/k_B Tᶜ', s.bcs_ratio, 2);
            put('Z(0)', s.z_factor, 3);
            put('Tᶜ annoncée par le code', s.tc_reported_K, 2, 'K');
            L.push('  Tᶜ calculée :');
            L.push('    μ*      McMillan      Allen-Dynes');
            r.tc_table.forEach(t => {
                L.push(`    ${t.mu_star.toFixed(2)}    ${String(f(t.tc_mcmillan_K, 2)).padStart(8)} K`
                     + `    ${String(f(t.tc_allen_dynes_K, 2)).padStart(8)} K`);
            });
            if (r.notes.length) {
                L.push('  Remarques :');
                r.notes.forEach(n => L.push(`    - ${n}`));
            }
            L.push('  Provenance des valeurs :');
            Object.entries(r.provenance).forEach(([k, v]) => L.push(`    ${k.padEnd(18)} ${v}`));
            L.push('');
        });

        L.push('────────────────────────────────────────────────────────────');
        L.push('  Comparaison des deux voies');
        L.push('────────────────────────────────────────────────────────────');
        d.synthesis.rows.forEach(r => {
            L.push(`  ${r.label.padEnd(26)} classique ${String(f(r.classic, r.digits)).padStart(10)}`
                 + `   EPW ${String(f(r.epw, r.digits)).padStart(10)}   ${r.unit || ''}`);
        });
        L.push('');
        downloadText(`${d.material}_supra_rapport.txt`, L.join('\n'));
        setResStatus('Rapport exporté.');
    }

    /* ── Navigation entre modules ─────────────────────────────────────── */
    function switchResModule(name) {
        RES.module = name;
        $$('.res-tab').forEach(b => {
            const on = b.dataset.resModule === name;
            b.classList.toggle('active', on);
            b.setAttribute('aria-selected', on ? 'true' : 'false');
        });
        $$('.res-module').forEach(p => p.classList.toggle('active', p.dataset.resPanel === name));
    }

    function bindResultsExplorer() {
        $('#btnExploreResults')?.addEventListener('click', exploreResults);
        $('#btnExportCsv')?.addEventListener('click', resExportCsv);
        $('#btnExportLatex')?.addEventListener('click', resExportLatex);
        $('#btnExportReport')?.addEventListener('click', resExportReport);
        $$('.res-tab').forEach(b =>
            b.addEventListener('click', () => switchResModule(b.dataset.resModule)));
        $('#fld_res_mu_stars')?.addEventListener('change', () => {
            if (RES.data) exploreResults();
        });
        // Boutons « Voir » créés dynamiquement dans l'inventaire
        $('#resFileInventory')?.addEventListener('click', ev => {
            const btn = ev.target.closest('[data-res-file]');
            if (btn) showRawFile(btn.dataset.resFile);
        });
        renderResultModules();
    }

    /* ====================================================================
     *  Wiring final
     * ==================================================================== */
    async function applyPaths() {
        if (!APP.material) {
            $('#pathsApplyStatus').innerHTML = alertBox('warning', 'Sélectionne un matériau d\'abord.');
            return;
        }
        if (!APP.workflow) {
            $('#pathsApplyStatus').innerHTML = alertBox('warning', 'Choisis un workflow d\'abord.');
            return;
        }
        APP.baseDir = getMaterialBaseDir();
        const fw = $('#fld_path_workflow');
        const fo = $('#fld_path_outputs');
        if (fw) { fw.value = txt('fld_path_workflow', `${APP.baseDir}/${APP.workflow}`).replace(/\/$/, ''); fw.dataset.touched = '1'; }
        if (fo) fo.dataset.touched = '1';
        saveStoredPaths({
            api_base: SupraAPI.getBaseURL(),
            inputs: getMaterialBaseDir(),
            workflow: txt('fld_path_workflow', ''),
            outputs: txt('fld_path_outputs', ''),
            pseudos: txt('fld_pseudo_dir', '../../../pseudos/'),
        });
        invalidateWorkflowFiles();
        const paths = getWorkflowPaths();
        $('#pathsApplyStatus').innerHTML = alertBox('success',
            `Chemins actifs : inputs <code>${paths.workDir}</code> · outputs <code>${paths.outputDir}</code>`);
        await renderCalcList();
        await refreshChainStatus();
    }

    function bindButtons() {
        $('#btnApiRefresh')      ?.addEventListener('click', pingAPI);
        $('#btnApiRetryBanner')  ?.addEventListener('click', () => {
            showToast('info', 'Vérification de l’API…', 2000);
            pingAPI();
        });
        $('#btnGenerateAll')     ?.addEventListener('click', generateAndSave);
        $('#btnRunWorkflow')     ?.addEventListener('click', runWorkflowActive);
        $('#btnApplyPaths')      ?.addEventListener('click', applyPaths);
    }

    /* ====================================================================
     *  Thème clair / sombre
     * ==================================================================== */
    const THEME_LS_KEY = 'supraQE.theme';

    function resolveTheme(preferred) {
        if (preferred === 'light' || preferred === 'dark') return preferred;
        try {
            if (window.matchMedia('(prefers-color-scheme: dark)').matches) return 'dark';
        } catch { /* */ }
        return 'light';
    }

    function setTheme(next, { persist = true } = {}) {
        const theme = resolveTheme(next);
        document.documentElement.setAttribute('data-theme', theme);
        document.querySelectorAll('.theme-btn').forEach(b => {
            const on = b.dataset.theme === theme;
            b.classList.toggle('active', on);
            b.setAttribute('aria-pressed', on ? 'true' : 'false');
        });
        if (persist) {
            try { localStorage.setItem(THEME_LS_KEY, theme); } catch { /* mode privé */ }
        }
    }

    function bindTheme() {
        document.querySelectorAll('.theme-btn').forEach(b => {
            b.addEventListener('click', () => setTheme(b.dataset.theme));
        });
        let saved = null;
        try { saved = localStorage.getItem(THEME_LS_KEY); } catch { /* */ }
        const initial = document.documentElement.getAttribute('data-theme')
            || resolveTheme(saved);
        setTheme(initial, { persist: false });
    }

    /* ====================================================================
     *  Boot
     * ==================================================================== */
    function boot() {
        document.body?.setAttribute('data-supra-ui', 'calculs-resultats');
        if (typeof SupraInputs === 'undefined' || typeof SupraAPI === 'undefined') {
            const msg = "Scripts Supra-QE non chargés. Ouvre http://127.0.0.1:8765/interface/ (avec ./DEMARRER.sh), pas le fichier HTML directement.";
            console.error(msg);
            const st = $('#apiStatusText');
            if (st) st.innerHTML = `<span style="color:var(--error);">${msg}</span>`;
        }
        restorePathsFromStorage();
        bindTheme();
        bindTabs();
        bindUsageGuide();
        bindAuthorCard();
        bindCollapsibles();
        bindCollapseToolbar();
        bindSearchMaterial();
        bindWorkflowPicker();
        bindBranchSubTabs();
        bindPseudoUpload();
        bindButtons();
        bindPathsEditor();
        bindGridInputs();
        bindParallel();
        bindResultsExplorer();
        updateKQVisual();
        // Ouverture sur le Guide ; Calculs / Résultats basculent directement.
        switchMainView('guide');
        updateNavToolbarVisibility();
        updateSessionProgress();
        pingAPI();
        startApiWatchdog();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

})();

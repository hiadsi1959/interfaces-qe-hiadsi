/**
 * supra_plots.js — tracés SVG pour l'onglet Résultats.
 *
 * Aucune dépendance : les graphiques sont produits comme chaînes SVG que l'on
 * injecte dans le DOM. Suffisant pour des courbes de quelques milliers de
 * points, et imprimable / exportable tel quel.
 *
 * API :
 *   SupraPlots.chart(cfg)      → courbes (1 ou 2 axes Y), aires, points
 *   SupraPlots.bars(cfg)       → histogramme
 *   SupraPlots.dispersion(cfg) → branches de phonons, épaisseur pondérée
 *   SupraPlots.scatter(cfg)    → nuage (ω, λ) avec rayon ∝ γ
 */
(function (global) {
    'use strict';

    const DEF = { width: 940, height: 320, pad: { l: 64, r: 64, t: 18, b: 46 } };

    const esc = s => String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

    /** Arrondi d'axe « joli » (1, 2, 2.5, 5 × 10ⁿ). */
    function niceMax(v) {
        if (!(v > 0)) return 1;
        const exp = Math.floor(Math.log10(v));
        const base = Math.pow(10, exp);
        const f = v / base;
        const step = f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10;
        return step * base;
    }

    function fmtTick(v) {
        const a = Math.abs(v);
        if (a === 0) return '0';
        if (a >= 1000) return v.toFixed(0);
        if (a >= 100) return v.toFixed(0);
        if (a >= 10) return v.toFixed(1);
        if (a >= 1) return v.toFixed(2);
        if (a >= 0.01) return v.toFixed(3);
        return v.toExponential(1);
    }

    /**
     * Graduations à pas « rond » (1, 2, 2.5, 5 × 10ⁿ) à l'intérieur de [min, max].
     * Les bornes restent celles des données : on ne les élargit pas, on place
     * seulement des valeurs lisibles entre elles.
     */
    function ticks(min, max, n) {
        const span = max - min;
        if (!(span > 0)) return [min];
        const raw = span / n;
        const exp = Math.floor(Math.log10(raw));
        const base = Math.pow(10, exp);
        const f = raw / base;
        const step = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * base;
        const out = [];
        for (let v = Math.ceil(min / step) * step; v <= max + step * 1e-9; v += step) {
            out.push(Math.abs(v) < step * 1e-9 ? 0 : v);
        }
        if (!out.length) out.push(min, max);
        return out;
    }

    function frame(cfg) {
        const { width: w, height: h, pad } = cfg;
        const plotW = w - pad.l - pad.r;
        const plotH = h - pad.t - pad.b;
        const xMin = cfg.x.min, xMax = cfg.x.max === cfg.x.min ? cfg.x.min + 1 : cfg.x.max;
        const yMin = cfg.y.min, yMax = cfg.y.max === cfg.y.min ? cfg.y.min + 1 : cfg.y.max;
        const X = v => pad.l + (v - xMin) / (xMax - xMin) * plotW;
        const Y = v => pad.t + plotH - (v - yMin) / (yMax - yMin) * plotH;
        let Y2 = null;
        if (cfg.y2) {
            const a = cfg.y2.min, b = cfg.y2.max === cfg.y2.min ? cfg.y2.min + 1 : cfg.y2.max;
            Y2 = v => pad.t + plotH - (v - a) / (b - a) * plotH;
        }
        return { w, h, pad, plotW, plotH, xMin, xMax, yMin, yMax, X, Y, Y2 };
    }

    /** Axes, graduations et grille. */
    function axes(g, cfg) {
        const { pad, plotW, plotH } = g;
        const parts = [];
        const xt = ticks(g.xMin, g.xMax, cfg.xTicks || 6);
        const yt = ticks(g.yMin, g.yMax, cfg.yTicks || 5);

        yt.forEach(v => {
            const y = g.Y(v);
            parts.push(`<line x1="${pad.l}" y1="${y.toFixed(1)}" x2="${pad.l + plotW}" y2="${y.toFixed(1)}" stroke="#e2e8f0"/>`);
            parts.push(`<text x="${pad.l - 8}" y="${(y + 4).toFixed(1)}" text-anchor="end" font-size="11" fill="#64748b">${fmtTick(v)}</text>`);
        });
        xt.forEach(v => {
            const x = g.X(v);
            parts.push(`<line x1="${x.toFixed(1)}" y1="${pad.t + plotH}" x2="${x.toFixed(1)}" y2="${pad.t + plotH + 5}" stroke="#94a3b8"/>`);
            parts.push(`<text x="${x.toFixed(1)}" y="${pad.t + plotH + 20}" text-anchor="middle" font-size="11" fill="#64748b">${fmtTick(v)}</text>`);
        });
        if (cfg.y2) {
            ticks(cfg.y2.min, cfg.y2.max, cfg.yTicks || 5).forEach(v => {
                const y = g.Y2(v);
                parts.push(`<text x="${pad.l + plotW + 8}" y="${(y + 4).toFixed(1)}" font-size="11" fill="${cfg.y2.color || '#7c3aed'}">${fmtTick(v)}</text>`);
            });
            parts.push(`<line x1="${pad.l + plotW}" y1="${pad.t}" x2="${pad.l + plotW}" y2="${pad.t + plotH}" stroke="${cfg.y2.color || '#7c3aed'}" stroke-opacity="0.5"/>`);
            parts.push(`<text x="${pad.l + plotW + 8}" y="${pad.t - 5}" font-size="11" font-weight="600" fill="${cfg.y2.color || '#7c3aed'}">${esc(cfg.y2.label || '')}</text>`);
        }
        parts.push(`<line x1="${pad.l}" y1="${pad.t + plotH}" x2="${pad.l + plotW}" y2="${pad.t + plotH}" stroke="#475569"/>`);
        parts.push(`<line x1="${pad.l}" y1="${pad.t}" x2="${pad.l}" y2="${pad.t + plotH}" stroke="#475569"/>`);
        parts.push(`<text x="${pad.l + plotW}" y="${g.h - 8}" text-anchor="end" font-size="12" fill="#334155">${esc(cfg.x.label || '')}</text>`);
        parts.push(`<text x="${pad.l - 6}" y="${pad.t - 5}" font-size="11" font-weight="600" fill="${cfg.y.color || '#0e7490'}">${esc(cfg.y.label || '')}</text>`);
        return parts.join('');
    }

    function pathOf(points, X, Y) {
        let d = '';
        let started = false;
        for (const p of points) {
            if (p == null || !isFinite(p[0]) || !isFinite(p[1])) { started = false; continue; }
            d += (started ? 'L' : 'M') + X(p[0]).toFixed(1) + ',' + Y(p[1]).toFixed(1) + ' ';
            started = true;
        }
        return d.trim();
    }

    function svgWrap(g, body, title) {
        return `<svg viewBox="0 0 ${g.w} ${g.h}" role="img" aria-label="${esc(title || 'graphique')}">${body}</svg>`;
    }

    function bounds(series, key) {
        let lo = Infinity, hi = -Infinity;
        series.forEach(s => (s.points || []).forEach(p => {
            const v = key === 'x' ? p[0] : p[1];
            if (isFinite(v)) { if (v < lo) lo = v; if (v > hi) hi = v; }
        }));
        if (!isFinite(lo)) { lo = 0; hi = 1; }
        return { lo, hi };
    }

    /**
     * Courbes multi-séries. Chaque série : { points, color, dash, width, axis,
     * fill, label }. `axis: 'y2'` renvoie vers l'axe de droite.
     */
    function chart(cfg) {
        cfg = Object.assign({}, DEF, cfg);
        cfg.pad = Object.assign({}, DEF.pad, cfg.pad || {});
        const series = (cfg.series || []).filter(s => s.points && s.points.length);
        if (!series.length) return '';

        const main = series.filter(s => s.axis !== 'y2');
        const sec = series.filter(s => s.axis === 'y2');
        const bx = bounds(series, 'x');
        const by = bounds(main.length ? main : series, 'y');
        cfg.x = Object.assign({ min: bx.lo, max: bx.hi }, cfg.x || {});
        cfg.y = Object.assign({ min: 0, max: niceMax(by.hi) }, cfg.y || {});
        if (sec.length) {
            const b2 = bounds(sec, 'y');
            cfg.y2 = Object.assign({ min: 0, max: niceMax(b2.hi) }, cfg.y2 || {});
        }

        const g = frame(cfg);
        const body = [axes(g, cfg)];
        series.forEach(s => {
            const Yf = s.axis === 'y2' ? g.Y2 : g.Y;
            const d = pathOf(s.points, g.X, Yf);
            if (!d) return;
            if (s.fill) {
                const x0 = g.X(s.points[0][0]).toFixed(1);
                const xN = g.X(s.points[s.points.length - 1][0]).toFixed(1);
                const yBase = Yf(cfg.y.min).toFixed(1);
                body.push(`<path d="${d} L${xN},${yBase} L${x0},${yBase} Z" fill="${s.color}" fill-opacity="${s.fillOpacity || 0.16}" stroke="none"/>`);
            }
            body.push(`<path d="${d}" fill="none" stroke="${s.color}" stroke-width="${s.width || 2}"`
                + (s.dash ? ` stroke-dasharray="${s.dash}"` : '') + ' stroke-linejoin="round"/>');
        });
        (cfg.markers || []).forEach(m => {
            const x = g.X(m.x);
            body.push(`<line x1="${x.toFixed(1)}" y1="${g.pad.t}" x2="${x.toFixed(1)}" y2="${g.pad.t + g.plotH}" `
                + `stroke="${m.color || '#f59e0b'}" stroke-width="1.5" stroke-dasharray="5 4"/>`);
            if (m.label) {
                body.push(`<text x="${(x + 5).toFixed(1)}" y="${g.pad.t + 14}" font-size="11" fill="${m.color || '#b45309'}">${esc(m.label)}</text>`);
            }
        });
        return svgWrap(g, body.join(''), cfg.title);
    }

    /** Histogramme (distribution du gap, par exemple). */
    function bars(cfg) {
        cfg = Object.assign({}, DEF, cfg);
        cfg.pad = Object.assign({}, DEF.pad, cfg.pad || {});
        const xs = cfg.centres || [];
        const ys = cfg.counts || [];
        if (!xs.length || !ys.length) return '';
        const step = xs.length > 1 ? (xs[1] - xs[0]) : 1;
        cfg.x = Object.assign({ min: xs[0] - step / 2, max: xs[xs.length - 1] + step / 2 }, cfg.x || {});
        cfg.y = Object.assign({ min: 0, max: niceMax(Math.max.apply(null, ys)) }, cfg.y || {});
        const g = frame(cfg);
        const body = [axes(g, cfg)];
        const bw = Math.max(g.plotW / xs.length - 1.5, 1);
        xs.forEach((x, i) => {
            if (!ys[i]) return;
            const h = g.Y(0) - g.Y(ys[i]);
            body.push(`<rect x="${(g.X(x) - bw / 2).toFixed(1)}" y="${g.Y(ys[i]).toFixed(1)}" `
                + `width="${bw.toFixed(1)}" height="${Math.max(h, 0.5).toFixed(1)}" `
                + `fill="${cfg.color || '#ec4899'}" fill-opacity="0.75"/>`);
        });
        (cfg.markers || []).forEach(m => {
            const x = g.X(m.x);
            body.push(`<line x1="${x.toFixed(1)}" y1="${g.pad.t}" x2="${x.toFixed(1)}" y2="${g.pad.t + g.plotH}" `
                + `stroke="${m.color || '#0f766e'}" stroke-width="1.5" stroke-dasharray="5 4"/>`);
            if (m.label) body.push(`<text x="${(x + 5).toFixed(1)}" y="${g.pad.t + 14}" font-size="11" fill="${m.color || '#0f766e'}">${esc(m.label)}</text>`);
        });
        return svgWrap(g, body.join(''), cfg.title);
    }

    /**
     * Dispersion de phonons : une polyligne par branche. `weights` (optionnel)
     * donne, branche par branche, une épaisseur relative 0–1 (fatbands γ_qν).
     */
    function dispersion(cfg) {
        cfg = Object.assign({}, DEF, cfg);
        cfg.pad = Object.assign({}, DEF.pad, cfg.pad || {});
        const q = cfg.q || [];
        const branches = cfg.bands || [];
        if (!q.length || !branches.length) return '';
        const flat = branches.reduce((a, b) => a.concat(b), []);
        cfg.x = Object.assign({ min: q[0], max: q[q.length - 1], label: cfg.xLabel || 'chemin q' }, cfg.x || {});
        cfg.y = Object.assign({ min: Math.min(0, Math.min.apply(null, flat)),
                                max: niceMax(Math.max.apply(null, flat)) }, cfg.y || {});
        const g = frame(cfg);
        const body = [axes(g, cfg)];
        branches.forEach((band, i) => {
            const pts = band.map((v, k) => [q[k], v]);
            const d = pathOf(pts, g.X, g.Y);
            if (!d) return;
            const wgt = cfg.weights && cfg.weights[i] != null ? cfg.weights[i] : null;
            const width = wgt == null ? 1.6 : 1.2 + 6.0 * Math.max(0, Math.min(1, wgt));
            const color = cfg.color || '#0891b2';
            body.push(`<path d="${d}" fill="none" stroke="${color}" stroke-width="${width.toFixed(2)}" `
                + `stroke-opacity="${wgt == null ? 0.85 : (0.45 + 0.5 * Math.min(1, wgt)).toFixed(2)}" stroke-linejoin="round"/>`);
        });
        return svgWrap(g, body.join(''), cfg.title);
    }

    /** Nuage de points : rayon ∝ poids (couplage par mode). */
    function scatter(cfg) {
        cfg = Object.assign({}, DEF, cfg);
        cfg.pad = Object.assign({}, DEF.pad, cfg.pad || {});
        const pts = (cfg.points || []).filter(p => isFinite(p.x) && isFinite(p.y));
        if (!pts.length) return '';
        const xs = pts.map(p => p.x), ys = pts.map(p => p.y);
        cfg.x = Object.assign({ min: Math.min.apply(null, xs), max: Math.max.apply(null, xs) }, cfg.x || {});
        cfg.y = Object.assign({ min: 0, max: niceMax(Math.max.apply(null, ys)) }, cfg.y || {});
        const wMax = Math.max.apply(null, pts.map(p => p.w || 0)) || 1;
        const g = frame(cfg);
        const body = [axes(g, cfg)];
        pts.forEach(p => {
            const r = 2.5 + 5.5 * Math.sqrt(Math.max(0, (p.w || 0) / wMax));
            body.push(`<circle cx="${g.X(p.x).toFixed(1)}" cy="${g.Y(p.y).toFixed(1)}" r="${r.toFixed(2)}" `
                + `fill="${cfg.color || '#0891b2'}" fill-opacity="0.55" stroke="${cfg.stroke || '#0e7490'}" stroke-width="0.6"/>`);
        });
        return svgWrap(g, body.join(''), cfg.title);
    }

    global.SupraPlots = { chart, bars, dispersion, scatter, niceMax };
})(window);

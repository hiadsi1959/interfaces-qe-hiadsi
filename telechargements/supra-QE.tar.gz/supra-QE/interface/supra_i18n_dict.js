/* =========================================================================
 *  supra_i18n_dict.js — dictionnaire Français → Anglais
 *
 *  `phrases` : nœud de texte complet (espaces normalisés) → anglais.
 *  `blocks`  : innerHTML complet d'un élément feuille → anglais avec balises.
 *  `rules`   : messages assemblés à l'exécution.
 *
 *  Les termes identiques dans les deux langues (noms de programmes QE,
 *  mots-clés Fortran, unités, URL) sont volontairement absents : ils sont
 *  laissés tels quels.
 *
 *  Pour repérer ce qui manque, passer l'interface en anglais et exécuter
 *  dans la console : SupraI18n.missing()
 * ========================================================================= */

window.SUPRA_I18N = {

    /* ── Messages assemblés dynamiquement ────────────────────────────────── */
    rules: [
        // « SCF métallique (pw.x) » : nom d'étape suivi de son programme
        { re: /^(.+) \((pw\.x|ph\.x|q2r\.x|matdyn\.x|epw\.x|alpha2f\.x|pp\.py|python)\)$/,
          en: (m, t) => t(m[1]) + ' (' + m[2] + ')' },
        { re: /^Vérification de l'enchaînement — (.+)$/, en: (m, t) => 'Chain verification — ' + t(m[1]) },
        { re: /^Attend : (.+)$/, en: (m, t) => 'Waiting for: ' + t(m[1]) },
        { re: /^Prochaine étape : (.+?)\.?$/, en: (m, t) => 'Next step: ' + t(m[1]) + '.' },
        { re: /^étape (\S+) — (.+)$/, en: (m, t) => 'step ' + m[1] + ' — ' + t(m[2]) },
        { re: /^(\d+[a-z]?) — (.+)$/, en: (m, t) => m[1] + ' — ' + t(m[2]) },
        { re: /^étape (.+)$/, en: (m, t) => 'step ' + t(m[1]) },
        { re: /^Étape (\d+[a-z]?)$/, en: (m) => 'Step ' + m[1] },
        { re: /^(.+) — pipeline$/, en: (m, t) => t(m[1]) + ' — pipeline' },
        { re: /^(\d+) étapes$/, en: (m) => m[1] + ' steps' },
        { re: /^(\d+) programme\(s\)$/, en: (m) => m[1] + ' program(s)' },
        { re: /^Programmes — (.+)$/, en: (m, t) => 'Programs — ' + t(m[1]) },
        { re: /^« (.+) » — choisis un workflow$/, en: (m) => '“' + m[1] + '” — choose a workflow' },
        { re: /^« (.+) » — (.+)$/, en: (m, t) => '“' + m[1] + '” — ' + t(m[2]) },
        { re: /^Matériau « (.+) » validé$/, en: (m) => 'Material “' + m[1] + '” validated' },
        { re: /^(\d+) espèce\(s\), (\d+) atome\(s\)$/, en: (m) => m[1] + ' species, ' + m[2] + ' atom(s)' },
        { re: /^vc-relax : (.+)$/, en: (m, t) => 'vc-relax: ' + t(m[1]) },
        { re: /^scf de contrôle : (.+)$/, en: (m, t) => 'sanity-check scf: ' + t(m[1]) },
        { re: /^résultats (.+)$/, en: (m, t) => t(m[1]) + ' results' },
        { re: /^Ratio k\/q \[(.+)\] :$/, en: (m, t) => 'k/q ratio [' + t(m[1]) + ']:' },
        // Libellé précédé d'une icône : on traduit ce qui suit l'icône. Si la
        // suite est inconnue du dictionnaire, le texte reste inchangé.
        { re: /^([^\w\s]{1,3})\s+(\S.*)$/u, en: (m, t) => m[1] + ' ' + t(m[2]) },
    ],

    /* ── Paragraphes entiers (meilleure qualité que fragment par fragment) ─ */
    blocks: {
        /* Gates Calculs / Résultats */
        "🔒 <strong>Prochaine étape</strong> — valide le matériau ci-dessus pour débloquer le flux Calculs : <ol> <li><strong>1b · Pseudopotentiels</strong> — fichiers Norm-Conserving du matériau</li> <li><strong>Étape 2 · Choix du workflow</strong> — WF1 Classique ou WF2 EPW</li> <li><strong>Étape 3 · Paramètres, chaîne de calculs et lancement</strong></li> </ol>":
            "🔒 <strong>Next step</strong> — validate the material above to unlock the Calculations flow: <ol> <li><strong>1b · Pseudopotentials</strong> — Norm-Conserving files for the material</li> <li><strong>Step 2 · Workflow choice</strong> — WF1 Classic or WF2 EPW</li> <li><strong>Step 3 · Parameters, calculation chain and launch</strong></li> </ol>",
        "📊 <strong>Mode Résultats</strong> — valide d’abord un <strong>matériau</strong> (étape 1) pour explorer T<sub>c</sub>, λ, α²F(ω) et les fichiers dans <code>outputs/&lt;matériau&gt;/classic/</code> et <code>…/epw/</code>.":
            "📊 <strong>Results mode</strong> — first validate a <strong>material</strong> (step 1) to explore T<sub>c</sub>, λ, α²F(ω) and the files in <code>outputs/&lt;material&gt;/classic/</code> and <code>…/epw/</code>.",

        /* Guide d'utilisation — feuilles <p> / <li> (innerHTML normalisé) */
        "Calcul de T<sub>c</sub> (couplage électron–phonon) avec Quantum ESPRESSO : <strong>WF1 Classique</strong> (McMillan / Allen–Dynes) et <strong>WF2 EPW</strong> (Éliashberg). Ne pas ouvrir le fichier HTML directement — toujours via l’API.":
            "T<sub>c</sub> calculation (electron–phonon coupling) with Quantum ESPRESSO: <strong>WF1 Classic</strong> (McMillan / Allen–Dynes) and <strong>WF2 EPW</strong> (Éliashberg). Do not open the HTML file directly — always go through the API.",

        "<strong>Démarrer (même PC)</strong> — <code>./configurer.sh</code> (une fois), puis <code>./DEMARRER.sh</code>, puis ouvrir <code>http://127.0.0.1:8765/interface/</code>. Arrêt : <code>./ARRETER.sh</code> · statut : <code>./STATUT.sh</code>.":
            "<strong>Start (same PC)</strong> — <code>./configurer.sh</code> (once), then <code>./DEMARRER.sh</code>, then open <code>http://127.0.0.1:8765/interface/</code>. Stop: <code>./ARRETER.sh</code> · status: <code>./STATUT.sh</code>.",

        "<strong>Autre PC / réseau</strong> — sur la machine de calcul : <code>SUPRA_QE_HOST=0.0.0.0</code> dans <code>config.env</code>, puis <code>./DEMARRER.sh</code> (affiche les URL LAN). Sur le PC distant : <code>http://IP:8765/interface/</code> ou <code>?api=http://IP:8765</code>, ou <strong>📁 Chemins</strong> → URL de l’API → <strong>Appliquer &amp; tester</strong>. Transfert du projet : <code>./EMBALLER.sh</code> puis <code>./INSTALL_AUTOMATIQUE.sh</code>. Guide : <code>docs/AUTRE_PC.md</code>.":
            "<strong>Another PC / network</strong> — on the compute machine: set <code>SUPRA_QE_HOST=0.0.0.0</code> in <code>config.env</code>, then <code>./DEMARRER.sh</code> (prints the LAN URLs). On the remote PC: <code>http://IP:8765/interface/</code> or <code>?api=http://IP:8765</code>, or <strong>📁 Paths</strong> → API URL → <strong>Apply &amp; test</strong>. Project transfer: <code>./EMBALLER.sh</code> then <code>./INSTALL_AUTOMATIQUE.sh</code>. Guide: <code>docs/AUTRE_PC.md</code>.",

        "<strong>Vérifier l’API</strong> — point vert dans la barre du haut ; sinon <strong>↻ API</strong>. Les binaires QE manquants (ex. <code>epw.x</code>) sont signalés dès le choix du workflow.":
            "<strong>Check the API</strong> — green dot in the top bar; otherwise <strong>↻ API</strong>. Missing QE binaries (e.g. <code>epw.x</code>) are reported as soon as you pick the workflow.",

        "<strong>Calculs — matériau</strong> — saisir le nom (Nb, MgB₂, …) → <strong>Valider le choix du matériau</strong>.":
            "<strong>Calculations — material</strong> — enter the name (Nb, MgB₂, …) → <strong>Validate the material</strong>.",

        "<strong>Pseudopotentiels (1b)</strong> — uniquement des <strong>.UPF Norm-Conserving</strong> (PseudoDojo recommandé). Les USPP / PAW sont refusés pour le couplage e–p.":
            "<strong>Pseudopotentials (1b)</strong> — only <strong>Norm-Conserving .UPF</strong> files (PseudoDojo recommended). USPP / PAW are rejected for e–ph coupling.",

        "<strong>Prérequis ①</strong> — placer <code>&lt;matériau&gt;.vc-relax.out</code> (avec structure extractible) dans <code>inputs/&lt;matériau&gt;/</code>, puis <strong>Vérifier les prérequis</strong>. C’est le seul fichier obligatoire ; chaque workflow relance son propre SCF.":
            "<strong>Prerequisites ①</strong> — place <code>&lt;material&gt;.vc-relax.out</code> (with an extractable structure) in <code>inputs/&lt;material&gt;/</code>, then <strong>Check prerequisites</strong>. It is the only mandatory file; each workflow runs its own SCF.",

        "<strong>Choisir le workflow</strong> — <strong>WF1 Classique</strong> : <code>scf → nscf dense → ph.x → q2r.x → matdyn.x / lambda.x</code> ; <strong>WF2 EPW</strong> : <code>scf → ph.x (dvscf) → nscf coarse → epw.x</code> (après ph.x : regrouper <code>save/</code> avec <code>pp.py</code> si besoin).":
            "<strong>Choose the workflow</strong> — <strong>WF1 Classic</strong>: <code>scf → nscf dense → ph.x → q2r.x → matdyn.x / lambda.x</code>; <strong>WF2 EPW</strong>: <code>scf → ph.x (dvscf) → nscf coarse → epw.x</code> (after ph.x: gather <code>save/</code> with <code>pp.py</code> if needed).",

        "<strong>Paramètres &amp; lancement</strong> — grilles k/q (ratio entier, k ≫ q), μ* (classique), fenêtres EPW ; <strong>Générer les inputs</strong>, puis 🚀 sur chaque carte ou <strong>Lancer tout le workflow</strong>. Le panneau <strong>Vérification de l’enchaînement</strong> indique l’étape terminée (<code>JOB DONE</code>), la suivante, et ce qui bloque.":
            "<strong>Parameters &amp; launch</strong> — k/q grids (integer ratio, k ≫ q), μ* (classic), EPW windows; <strong>Generate the inputs</strong>, then 🚀 on each card or <strong>Run the whole workflow</strong>. The <strong>Chain verification</strong> panel shows the finished step (<code>JOB DONE</code>), the next one, and what is blocking.",

        "<strong>Résultats</strong> — après calcul (ou copie des <code>.out</code> dans <code>outputs/&lt;mat&gt;/classic/</code> et <code>…/epw/</code>), cliquer <strong>🔎 Explorer tous les résultats</strong>. Quatre modules : <em>Synthèse &amp; scalaires</em> (λ, ω<sub>log</sub>, ⟨ω²⟩^½, T<sub>c</sub>(μ*), exports CSV / LaTeX / rapport) · <em>Spectres 2D</em> (α²F, λ(ω), F(ω), dispersion, Δ(T)) · <em>Surface de Fermi &amp; anisotropie</em> (Δ<sub>k</sub>, rapport BCS, Z(0)) · <em>Fichiers bruts</em> (inventaire + lecture).":
            "<strong>Results</strong> — after the run (or after copying the <code>.out</code> files into <code>outputs/&lt;mat&gt;/classic/</code> and <code>…/epw/</code>), click <strong>🔎 Explore all results</strong>. Four modules: <em>Summary &amp; scalars</em> (λ, ω<sub>log</sub>, ⟨ω²⟩^½, T<sub>c</sub>(μ*), CSV / LaTeX / report exports) · <em>2D spectra</em> (α²F, λ(ω), F(ω), dispersion, Δ(T)) · <em>Fermi surface &amp; anisotropy</em> (Δ<sub>k</sub>, BCS ratio, Z(0)) · <em>Raw files</em> (inventory + viewer).",

        "<strong>Aide</strong> — comparaison Classique vs EPW, EPWpy / Materials Cloud, formules et règles (pseudos NC, μ*, ratio k/q).":
            "<strong>Help</strong> — Classic vs EPW comparison, EPWpy / Materials Cloud, formulas and rules (NC pseudos, μ*, k/q ratio).",

        "<strong>Astuce</strong> — chaque section a son bouton <strong>▼ Déplier</strong> / <strong>▲ Replier</strong>. <strong>📂 Tout déplier</strong> / <strong>📁 Tout replier</strong> (barre du haut, hors Guide) ouvrent ou ferment toutes les cartes d’un coup. Langue : boutons <strong>FR</strong> / <strong>EN</strong>. Thème : <strong>☀ Clair</strong> / <strong>🌙 Sombre</strong>.":
            "<strong>Tip</strong> — each section has its <strong>▼ Expand</strong> / <strong>▲ Collapse</strong> button. <strong>📂 Expand all</strong> / <strong>📁 Collapse all</strong> (top bar, outside the Guide) open or close all cards at once. Language: <strong>FR</strong> / <strong>EN</strong> buttons. Theme: <strong>☀ Light</strong> / <strong>🌙 Dark</strong>.",

        "<strong>API hors ligne</strong> — lance <code>./DEMARRER.sh</code> (ou corrige l’URL dans <strong>Chemins</strong>), puis réessaie.":
            "<strong>API offline</strong> — run <code>./DEMARRER.sh</code> (or fix the URL in <strong>Paths</strong>), then retry.",

        "Saisis le matériau et valide. Ensuite : <strong>pseudos (1b)</strong>, choix du workflow, puis <strong>vc-relax</strong> dans le dossier matériau.":
            "Enter the material and confirm. Next: <strong>pseudos (1b)</strong>, choose a workflow, then <strong>vc-relax</strong> in the material folder.",
    },

    /* ── Phrases et libellés ─────────────────────────────────────────────── */
    phrases: {

        /* En-tête et navigation */
        "🧊 Supra-QE — Propriétés Supraconductrices": "🧊 Supra-QE — Superconducting Properties",
        "🧊 Supra-QE — WF1 Classique · WF2 EPW": "🧊 Supra-QE — WF1 Classic · WF2 EPW",
        "Matériau →": "Material →",
        "WF1 Classique · WF2 EPW": "WF1 Classic · WF2 EPW",
        "Interface v3 · 2 workflows · barre d'outils unifiée": "Interface v3 · 2 workflows · unified toolbar",
        "Oran, Algérie": "Oran, Algeria",
        "Auteur": "Author",
        "Langue / Language": "Language",
        "Thème / Theme": "Theme",
        "☀ Clair": "☀ Light",
        "🌙 Sombre": "🌙 Dark",
        "Mode clair / Light": "Light mode",
        "Mode sombre / Dark": "Dark mode",
        "API hors ligne": "API offline",
        "↻ Réessayer": "↻ Retry",
        "Matériau": "Material",
        "Workflow": "Workflow",
        "en ligne": "online",
        "hors ligne": "offline",
        "QE incomplet": "QE incomplete",
        "Vérification de l’API…": "Checking the API…",
        "État de la session": "Session status",
        "Exemples : Nb · MgB2 · H3S · Pb": "Examples: Nb · MgB2 · H3S · Pb",
        "Saisis le matériau et valide. Ensuite :": "Enter the material and confirm. Next:",
        "choix du workflow, puis": "choose a workflow, then",
        "dans le dossier matériau.": "in the material folder.",
        "🧮 Calculs": "🧮 Calculations",
        "📊 Résultats": "📊 Results",
        "❓ Aide": "❓ Help",
        "📖 Guide": "📖 Guide",
        "Calculs": "Calculations",
        "Résultats": "Results",
        "Aide": "Help",
        "Sections": "Sections",
        "📂 Tout déplier": "📂 Expand all",
        "📁 Tout replier": "📁 Collapse all",
        "▼ Déplier": "▼ Expand",
        "▲ Replier": "▲ Collapse",
        "Navigation principale": "Main navigation",
        "Sections du flux": "Workflow sections",
        "Sections d'aide": "Help sections",
        "Guide d'utilisation": "User guide",
        "↻ API": "↻ API",
        "API…": "API…",
        "Vérifier l'API": "Check the API",
        "📁 Chemins": "📁 Paths",
        "Chemins projet": "Project paths",
        "Mode Calculs": "Calculation mode",
        "— valide le matériau, configure les pseudos (1b), choisis un workflow, puis lance les calculs.":
            "— validate the material, set up the pseudopotentials (1b), pick a workflow, then run the calculations.",

        /* Guide d'utilisation */
        "📖 Guide d'utilisation — Supra-QE": "📖 User guide — Supra-QE",
        "Passer aux Calculs": "Go to Calculations",
        "Passer aux Résultats": "Go to Results",
        "Appliquer & tester": "Apply & test",
        "Démarrer (même PC)": "Start (same PC)",
        "Autre PC / réseau": "Another PC / network",
        "Vérifier l’API": "Check the API",
        "Calculs — matériau": "Calculations — material",
        "Pseudopotentiels (1b)": "Pseudopotentials (1b)",
        "Prérequis ①": "Prerequisites ①",
        "Choisir le workflow": "Choose the workflow",
        "Paramètres & lancement": "Parameters & launch",
        "Résultats": "Results",
        "Aide": "Help",
        "Astuce": "Tip",
        "Valider le choix du matériau": "Validate the material",
        "Vérifier les prérequis": "Check prerequisites",
        "Générer les inputs": "Generate the inputs",
        "Lancer tout le workflow": "Run the whole workflow",
        "Vérification de l’enchaînement": "Chain verification",
        "🔎 Explorer tous les résultats": "🔎 Explore all results",
        "WF1 Classique": "WF1 Classic",
        "WF2 EPW": "WF2 EPW",
        "Synthèse & scalaires": "Summary & scalars",
        "Spectres 2D": "2D spectra",
        "Surface de Fermi & anisotropie": "Fermi surface & anisotropy",
        "Fichiers bruts": "Raw files",
        "Prochaine étape": "Next step",
        "Mode Résultats": "Results mode",
        "valide d’abord un": "first validate a",
        "matériau": "material",
        "(étape 1)": "(step 1)",
        "pour explorer Tc, λ, α²F(ω) et les fichiers dans":
            "to explore Tc, λ, α²F(ω) and the files in",
        "valide le matériau ci-dessus pour débloquer le flux Calculs :":
            "validate the material above to unlock the Calculations flow:",
        "Calcul de Tc (couplage électron–phonon) avec Quantum ESPRESSO :":
            "Tc calculation (electron–phonon coupling) with Quantum ESPRESSO:",
        "Ne pas ouvrir le fichier HTML directement — toujours via l’API.":
            "Do not open the HTML file directly — always go through the API.",
        "sur la machine de calcul :": "on the compute machine:",
        "dans": "in",
        "puis": "then",
        "(affiche les URL LAN).": "(prints the LAN URLs).",
        "Sur le PC distant :": "On the remote PC:",
        "ou": "or",
        "→ URL de l’API →": "→ API URL →",
        "Transfert du projet :": "Project transfer:",
        "Guide :": "Guide:",
        "point vert dans la barre du haut ; sinon": "green dot in the top bar; otherwise",
        "Les binaires QE manquants (ex.": "Missing QE binaries (e.g.",
        ") sont signalés dès le choix du workflow.": ") are reported as soon as you pick the workflow.",
        "saisir le nom (Nb, MgB₂, …) →": "enter the name (Nb, MgB₂, …) →",
        "uniquement des": "only",
        ".UPF Norm-Conserving": "Norm-Conserving .UPF files",
        "(PseudoDojo recommandé).": "(PseudoDojo recommended).",
        "Les USPP / PAW sont refusés pour le couplage e–p.":
            "USPP / PAW are rejected for e–ph coupling.",
        "placer": "place",
        "(avec structure extractible)": "(with an extractable structure)",
        "C’est le seul fichier obligatoire ; chaque workflow relance son propre SCF.":
            "It is the only mandatory file; each workflow runs its own SCF.",
        "après ph.x : regrouper": "after ph.x: gather",
        "avec": "with",
        "si besoin": "if needed",
        "grilles k/q (ratio entier, k ≫ q), μ* (classique), fenêtres EPW ;":
            "k/q grids (integer ratio, k ≫ q), μ* (classic), EPW windows;",
        "sur chaque carte ou": "on each card or",
        "Le panneau": "The",
        "indique l’étape terminée": "panel shows the finished step",
        ", la suivante, et ce qui bloque.": ", the next one, and what is blocking.",
        "après calcul (ou copie des": "after the run (or after copying the",
        "fichiers dans": "files into",
        "et": "and",
        "), cliquer": "), click",
        "Quatre modules :": "Four modules:",
        "(λ, ωlog, ⟨ω²⟩^½, Tc(μ*), exports CSV / LaTeX / rapport) ·":
            "(λ, ωlog, ⟨ω²⟩½, Tc(μ*), CSV / LaTeX / report exports) ·",
        "(α²F, λ(ω), F(ω), dispersion, Δ(T)) ·": "(α²F, λ(ω), F(ω), dispersion, Δ(T)) ·",
        "(Δk, rapport BCS, Z(0)) ·": "(Δk, BCS ratio, Z(0)) ·",
        "(inventaire + lecture).": "(inventory + viewer).",
        "comparaison Classique vs EPW, EPWpy / Materials Cloud, formules et règles":
            "Classic vs EPW comparison, EPWpy / Materials Cloud, formulas and rules",
        "(pseudos NC, μ*, ratio k/q).": "(NC pseudos, μ*, k/q ratio).",
        "chaque section a son bouton": "each section has its",
        "(barre du haut, hors Guide)": "(top bar, outside the Guide)",
        "ouvrent ou ferment toutes les cartes d’un coup.":
            "open or close all cards at once.",
        "Langue : boutons": "Language: buttons",

        /* (anciennes clés guide — conservées pour fragments dynamiques) */
        "Démarrer": "Start up",
        "Onglet Calculs — Étape 1": "Calculations tab — Step 1",
        "Étape 1b — Pseudopotentiels": "Step 1b — Pseudopotentials",
        "Étape 2 — Workflow": "Step 2 — Workflow",
        "Onglet Résultats": "Results tab",
        "Onglet Aide": "Help tab",
        "Astuce :": "Tip:",
        "Lire résultats": "Read results",
        "tout le workflow": "the whole workflow",
        "Vérification de l'enchaînement": "Chain verification",
        "Vérifier l'API": "Check the API",
        "Paramètres & lancement": "Parameters & launch",
        "Générer les inputs de ce workflow": "Generate this workflow’s inputs",
        "/": "/",

        /* Étape 1 — matériau */
        "Étape 1": "Step 1",
        "Étape 1 — Choix du matériau": "Step 1 — Material choice",
        "Choisir le Matériau": "Choose the material",
        "Ex : Nb, MgB2, H3S, Pb…": "e.g. Nb, MgB2, H3S, Pb…",
        "Entre un nom puis clique « Valider le choix du matériau »":
            "Type a name then click “Validate the material”",
        "Saisis le matériau et valide ton choix. Configure ensuite les":
            "Enter the material and validate your choice. Then set up the",
        "pseudopotentiels (étape 1b)": "pseudopotentials (step 1b)",
        ", puis choisis un workflow — la sortie": ", then pick a workflow — the",
        "se place dans le dossier matériau (ou un chemin externe).":
            "output goes into the material folder (or an external path).",
        "🔒 La suite du flux est masquée tant que le matériau n'est pas validé — c'est pour cela que cette page paraît vide. Clique sur":
            "🔒 The rest of the workflow stays hidden until the material is validated — that is why this page looks empty. Click",
        "« ✅ Valider le choix du matériau »": "“✅ Validate the material”",
        "ci-dessus pour faire apparaître :": "above to reveal:",
        "1b · Pseudopotentiels": "1b · Pseudopotentials",
        "— fichiers Norm-Conserving du matériau": "— Norm-Conserving files for the material",
        "Étape 2 · Choix du workflow": "Step 2 · Workflow choice",
        "— WF1 Classique ou WF2 EPW": "— WF1 Classic or WF2 EPW",
        "Étape 3 · Paramètres, chaîne de calculs et lancement":
            "Step 3 · Parameters, calculation chain and launch",

        /* Pseudopotentiels */
        "Pseudopotentiels": "Pseudopotentials",
        "Norm-Conserving obligatoire · communs aux workflows Classique et EPW":
            "Norm-Conserving required · shared by the Classic and EPW workflows",
        "🔒 Pseudopotentiels :": "🔒 Pseudopotentials:",
        "Norm-Conserving uniquement (PseudoDojo, SG15, ONCV).": "Norm-Conserving only (PseudoDojo, SG15, ONCV).",
        "et le couplage électron–phonon refusent USPP et PAW.": "and electron–phonon coupling reject USPP and PAW.",
        "Type obligatoire :": "Required type:",
        ": Norm-Conserving (NC)": ": Norm-Conserving (NC)",
        "Norm-Conserving (NC)": "Norm-Conserving (NC)",
        "ou les importer ci-dessous ; le nom doit correspondre à": "or import them below; the name must match",
        "Lie chaque élément à son fichier": "Link each element to its",
        ".UPF Norm-Conserving": "Norm-Conserving .UPF file",
        "📚 Recommandations pour le choix des pseudos": "📚 Recommendations for choosing pseudopotentials",
        "Sources fiables :": "Reliable sources:",
        "Bibliothèques de pseudos NC": "NC pseudopotential libraries",
        ", SG15, ONCV — une seule famille pour tous les éléments du matériau.":
            ", SG15, ONCV — a single family for every element of the material.",
        "Fonctionnelle :": "Functional:",
        "rester cohérent (ex. PBE partout) entre vc-relax, scf, phonons et EPW.":
            "keep it consistent (e.g. PBE everywhere) across vc-relax, scf, phonons and EPW.",
        "Semi-cœur :": "Semi-core:",
        "préférer les versions": "prefer the",
        "/ fully relativistic pour les métaux de transition (Nb, Pb…).":
            "/ fully relativistic versions for transition metals (Nb, Pb…).",
        "ecutwfc :": "ecutwfc:",
        "respecter la suggestion du pseudo (souvent 60–80 Ry pour métaux ; plus élevé pour O, F, H…).":
            "follow the suggestion shipped with the pseudopotential (often 60–80 Ry for metals; higher for O, F, H…).",
        "Élément": "Element",
        "Pseudo": "Pseudo",
        "Action": "Action",
        "Importer .upf": "Import .upf",
        "Dossier pseudos": "Pseudopotentials folder",
        "🔬 Pseudos Norm-Conserving —": "🔬 Norm-Conserving pseudos —",
        "Fichiers cherchés (prefix = nom du matériau) :": "Files searched for (prefix = material name):",

        /* Prérequis vc-relax */
        "① Prérequis": "① Prerequisites",
        "Prérequis calculs": "Calculation prerequisites",
        "Prérequis — structure relaxée (vc-relax)": "Prerequisites — relaxed structure (vc-relax)",
        "⚠️ La relaxation se fait en dehors de Supra-QE": "⚠️ Relaxation is done outside Supra-QE",
        "Dossier des prérequis (vc-relax requis · scf optionnel)":
            "Prerequisites folder (vc-relax required · scf optional)",
        "Dossier matériau (sortie vc-relax) : voir section": "Material folder (vc-relax output): see section",
        "Indiquer le chemin du répertoire où se trouve déjà ton calcul vc-relax":
            "Give the path of the directory that already holds your vc-relax run",
        "Trois façons de fournir ces sorties :": "Three ways to provide these outputs:",
        "Copier les sorties dans le dossier matériau Supra-QE :": "Copy the outputs into the Supra-QE material folder:",
        "(même prefix) dans le dossier matériau Supra-QE — les noms de fichiers restent identiques":
            "(same prefix) into the Supra-QE material folder — file names stay the same",
        "tout le répertoire de travail QE": "the whole QE working directory",
        "📤 Importer vc-relax.out dans ce dossier": "📤 Import vc-relax.out into this folder",
        "🔍 Vérifier les prérequis": "🔍 Check prerequisites",
        "vc-relax : ?": "vc-relax: ?",
        "scf : ?": "scf: ?",
        "vc-relax requis": "vc-relax required",
        "1 · vc-relax (requis)": "1 · vc-relax (required)",
        "2 · scf (contrôle)": "2 · scf (sanity check)",
        "✓ Prêt workflow": "✓ Workflow ready",
        "(requis),": "(required),",
        "(contrôle)": "(check)",
        "· fournit ibrav, celldm et les positions atomiques": "· provides ibrav, celldm and the atomic positions",
        "et les positions atomiques réutilisés dans tous les inputs générés.":
            "and the atomic positions reused in every generated input.",
        "Un seul fichier est": "Only one file is",
        "indispensable": "indispensable",
        ": la sortie": ": the",
        "Première étape des": "First step of the",
        "workflows. Elle crée": "workflows. It creates the",
        "dans le dossier du workflow : sans elle, le NSCF et": "in the workflow folder: without it the NSCF and",
        "ne trouvent pas la densité électronique. Les cutoffs sont repris du":
            "cannot find the electron density. Cutoffs are taken from the",
        "validé — ne les baisse pas en dessous.": "validated run — do not go below them.",
        ". C'est le seul fichier obligatoire ; un": ". It is the only mandatory file; an",
        "Calcul externe": "External calculation",
        "Manuelle": "Manual",
        "Automatique": "Automatic",

        /* Étape 2 — workflows */
        "Étape 2": "Step 2",
        "Étape 2 — Workflow": "Step 2 — Workflow",
        "Choix du workflow": "Workflow choice",
        "Workflow Classique": "Classic workflow",
        "Workflow Classique (WF1)": "Classic workflow (WF1)",
        "Workflow EPW": "EPW workflow",
        "Workflow EPW (WF2)": "EPW workflow (WF2)",
        "WF2 EPW": "WF2 EPW",
        "· Wannier · Éliashberg · Tᶜ + Δ": "· Wannier · Éliashberg · Tᶜ + Δ",
        "· McMillan / Allen-Dynes · μ*": "· McMillan / Allen-Dynes · μ*",
        "ph.x + e-p": "ph.x + e-p",
        "matdyn → Tᶜ": "matdyn → Tᶜ",
        "grilles fines": "fine grids",
        "aniso / iso": "aniso / iso",
        "👆 Choisis": "👆 Pick",
        "ou": "or",
        ".": ".",
        "⚠️ WF3": "⚠️ WF3",
        "— inputs générés ; lancement automatique SSCHA via l'API en cours d'intégration.":
            "— inputs are generated; automatic SSCHA launching through the API is being integrated.",

        /* Étape 3 — paramètres, chaîne, lancement */
        "Paramètres & lancement": "Parameters & launch",
        "Programmes du workflow": "Workflow programs",
        "Paramètres selon le workflow (WF1 classique · WF2 EPW).":
            "Parameters depending on the workflow (WF1 classic · WF2 EPW).",
        "Paramètres clés": "Key parameters",
        "Générer les inputs de ce workflow": "Generate the inputs of this workflow",
        "Lancer tout le workflow": "Run the whole workflow",
        "② Enchaînement des calculs —": "② Calculation chain —",
        "Chaque lancement est tracé ici avec sa vérification : une étape ne démarre que si l'amont est terminé (":
            "Every launch is logged here with its verification: a step only starts once the previous one is finished (",
        ") et que ses fichiers intermédiaires existent. Les lancements se font depuis les cartes d'étapes ci-dessus (bouton 🚀 Lancer).":
            ") and its intermediate files exist. Launching happens from the step cards above (🚀 Run button).",
        "Journal d'exécution & vérifications": "Execution log & verifications",
        "Chaîne amont": "Upstream chain",
        "Chaîne Tᶜ": "Tᶜ chain",
        "en attente": "waiting",
        "à vérifier": "to be checked",
        "Fichiers .in du workflow actif — prévisualisation et édition.":
            "The .in files of the active workflow — preview and edit.",
        "Inputs générés": "Generated inputs",
        "Fichiers :": "Files:",
        "Sortie": "Output",
        "Copier": "Copy",
        "Valide d'abord le": "First validate the",
        "(section ①) avant de générer ou lancer le workflow.": "(section ①) before generating or running the workflow.",
        "(étape 1) pour lire les fichiers de sortie.": "(step 1) to read the output files.",
        "matériau": "material",
        "workflow": "workflow",
        "— vérifie, sauvegarde, puis lance.": "— checks, saves, then runs.",
        "— utilisé par vc-relax, scf, phonons et EPW.": "— used by vc-relax, scf, phonons and EPW.",

        /* Chemins */
        "Chemins inputs / outputs": "Input / output paths",
        "Dossier workflow (.in)": "Workflow folder (.in)",
        "Dossier outputs (.out)": "Outputs folder (.out)",
        "💾 Appliquer les chemins": "💾 Apply the paths",

        /* Grilles k/q */
        "Grille K (SCF)": "K grid (SCF)",
        "Grille K (NSCF dense)": "K grid (dense NSCF)",
        "Grille K (NSCF EPW)": "K grid (EPW NSCF)",
        "Grille K (forces)": "K grid (forces)",
        "Grille Q (phonons)": "Q grid (phonons)",
        "Grille q (phonons)": "q grid (phonons)",
        "🔊 Grille Q (phonons, commune)": "🔊 Q grid (phonons, shared)",
        "Grille k (NSCF)": "k grid (NSCF)",
        "Grilles d'interpolation": "Interpolation grids",
        "Grilles k vs q :": "k vs q grids:",
        "🌐 Grilles fines (interpolation Wannier)": "🌐 Fine grids (Wannier interpolation)",
        "Convergence grilles fines": "Fine-grid convergence",
        "Une seule grille q (partagée) — le ratio k_NSCF/q doit être entier sur chaque axe. Mode classique :":
            "A single (shared) q grid — the k_NSCF/q ratio must be an integer along each axis. Classic mode:",
        "ratio entier ≥ 2 (≥ 4 conseillé en classique).": "integer ratio ≥ 2 (≥ 4 advised in classic mode).",
        "Ratio k/q [Classique] :": "k/q ratio [Classic]:",
        "Ratio k/q [EPW] :": "k/q ratio [EPW]:",
        "Très dense (ex. 24 × 24 × 24)": "Very dense (e.g. 24 × 24 × 24)",
        "Standard / coarse (ex. 8 × 8 × 8)": "Standard / coarse (e.g. 8 × 8 × 8)",
        "Moyenne (ex. 4 × 4 × 4)": "Medium (e.g. 4 × 4 × 4)",
        "Coarse (ex. 4 × 4 × 4) — même que NSCF EPW typiquement":
            "Coarse (e.g. 4 × 4 × 4) — typically the same as the EPW NSCF",
        "k très dense (16³–32³),": "very dense k (16³–32³),",
        "k modeste (6³ ou 8³),": "modest k (6³ or 8³),",
        "(16³–32³) : surface de Fermi +": "(16³–32³): Fermi surface +",
        "Interpolation Wannier sur grille géante (40³)": "Wannier interpolation on a huge grid (40³)",
        "nkf (K fine)": "nkf (fine K)",
        "nqf (Q fine)": "nqf (fine Q)",

        /* Paramètres SCF / NSCF / phonons */
        "Seuil convergence (Ry)": "Convergence threshold (Ry)",
        "Smearing (métal)": "Smearing (metal)",
        "mv — Marzari-Vanderbilt (recommandé)": "mv — Marzari-Vanderbilt (recommended)",
        "mp — Methfessel-Paxton": "mp — Methfessel-Paxton",
        "fd — Fermi-Dirac": "fd — Fermi-Dirac",
        "🎚️ Surface de Fermi & smearing": "🎚️ Fermi surface & smearing",
        "Itérations max": "Max iterations",
        "nbnd (obligatoire)": "nbnd (required)",
        "nbnd (auto)": "nbnd (auto)",
        "Élevé obligatoire": "High, mandatory",
        "élevé pour Wannier.": "high for Wannier.",
        "(pour Wannier)": "(for Wannier)",
        "Obligatoire": "Mandatory",
        "beaucoup de bandes (Wannier).": "many bands (Wannier).",
        ": grille k modeste, beaucoup de bandes (Wannier).": ": modest k grid, many bands (Wannier).",
        "μ* (Coulomb)": "μ* (Coulomb)",
        "μ* (post-traitement Tᶜ)": "μ* (Tᶜ post-processing)",
        "💡 μ* = 0.10 par défaut": "💡 μ* = 0.10 by default",
        "μ* = 0.10 par défaut": "μ* = 0.10 by default",
        "— modifiable (0.10–0.16).": "— adjustable (0.10–0.16).",
        "— standard littérature. alpha2f.x est optionnel : matdyn.x produit déjà α²F(ω) et Tᶜ.":
            "— the literature standard. alpha2f.x is optional: matdyn.x already produces α²F(ω) and Tᶜ.",
        "electron_phonon (classique)": "electron_phonon (classic)",
        "fildvscf (classique)": "fildvscf (classic)",
        "fildyn (classique)": "fildyn (classic)",
        "flfrc (q2r)": "flfrc (q2r)",
        "alpha2f smearing": "alpha2f smearing",
        "(optionnel) : lissage de α²F(ω) pour de plus beaux tracés.":
            "(optional): α²F(ω) smoothing for nicer plots.",
        "+ alpha2f.x optionnel": "+ optional alpha2f.x",
        "Température (K)": "Temperature (K)",
        "T_max (K)": "T_max (K)",
        "pour T": "for T",
        "Iso / Aniso": "Iso / Aniso",
        "(iso/aniso)": "(iso/aniso)",
        "Éliashberg anisotrope / FBW": "Anisotropic Éliashberg / FBW",
        "🪟 Fenêtres de Wannier (eV, EF=0)": "🪟 Wannier windows (eV, EF=0)",
        "fenêtres": "windows",
        "Projections (auto ou Nb:d;O:p)": "Projections (auto or Nb:d;O:p)",
        ", projections": ", projections",
        "Supercellule (nx×ny×nz)": "Supercell (nx×ny×nz)",
        "Nombre de configurations": "Number of configurations",
        "Amplitude déplacement (Å)": "Displacement amplitude (Å)",
        "Graine aléatoire": "Random seed",
        "ΔE phonon (cm⁻¹)": "Phonon ΔE (cm⁻¹)",
        "conv_thr (SCF)": "conv_thr (SCF)",
        "conv_thr (forces)": "conv_thr (forces)",
        "Calcul SCF + forces (": "SCF + forces calculation (",
        ") sur toutes les configs générées.": ") on every generated configuration.",

        /* Parallélisation */
        "⚡ Parallélisation": "⚡ Parallelisation",
        "🔢 MPI :": "🔢 MPI:",
        "🧵 OMP :": "🧵 OMP:",
        "? cœurs": "? cores",
        "🔍 Détecter": "🔍 Detect",
        "Détecter cœurs CPU": "Detect CPU cores",
        "auto": "auto",

        /* Onglets de paramètres par étape */
        "1 · pw.x SCF": "1 · pw.x SCF",
        "2 · pw.x NSCF dense": "2 · pw.x dense NSCF",
        "3 · ph.x (DFPT + e-p)": "3 · ph.x (DFPT + e-p)",
        "4 · matdyn.x (μ*, Tᶜ)": "4 · matdyn.x (μ*, Tᶜ)",
        "2 · ph.x (dvscf + dyn)": "2 · ph.x (dvscf + dyn)",
        "3 · pw.x NSCF coarse": "3 · pw.x coarse NSCF",
        "4 · epw.x (Wannier + Éliashberg)": "4 · epw.x (Wannier + Éliashberg)",
        "1 · Générateur configs": "1 · Configuration generator",
        "2 · pw.x (forces)": "2 · pw.x (forces)",
        "3 · Module SSCHA": "3 · SSCHA module",
        "SCF du workflow (pw.x) — densité de référence": "Workflow SCF (pw.x) — reference density",
        "NSCF (pw.x) — paramètres de la branche": "NSCF (pw.x) — branch parameters",
        "📐 NSCF dense (classique)": "📐 Dense NSCF (classic)",
        "📡 NSCF classique": "📡 Classic NSCF",
        "📡 NSCF EPW": "📡 EPW NSCF",
        "⚡ NSCF coarse + nbnd (EPW)": "⚡ Coarse NSCF + nbnd (EPW)",
        "NSCF coarse + nbnd": "Coarse NSCF + nbnd",
        "NSCF dense": "Dense NSCF",
        "📐 Classique (ph.x → matdyn.x)": "📐 Classic (ph.x → matdyn.x)",
        "⚡ EPW (epw.x)": "⚡ EPW (epw.x)",
        "ph.x DFPT": "ph.x DFPT",
        "Phonons": "Phonons",
        "q2r.x + matdyn.x": "q2r.x + matdyn.x",
        "epw.x — Wannier + Éliashberg": "epw.x — Wannier + Éliashberg",
        "pw.x — forces sur chaque configuration": "pw.x — forces on each configuration",
        "Générateur de configurations SSCHA": "SSCHA configuration generator",
        "Module SSCHA — minimisation énergie libre": "SSCHA module — free-energy minimisation",
        "Supercellules déplacées aléatoirement — base du couplage anharmonique.":
            "Randomly displaced supercells — the basis of anharmonic coupling.",
        "Suivi de la minimisation · extraction des fréquences de phonons corrigées et α²F(ω).":
            "Minimisation monitoring · extraction of the corrected phonon frequencies and α²F(ω).",
        "🧮 Éliashberg → Tᶜ + Δ": "🧮 Éliashberg → Tᶜ + Δ",
        "Éliashberg (EPW)": "Éliashberg (EPW)",
        "Tᶜ + gap Δ(T)": "Tᶜ + gap Δ(T)",

        /* Résultats */
        "📊 Résultats — Workflow Classique": "📊 Results — Classic workflow",
        "📊 Résultats — Workflow EPW": "📊 Results — EPW workflow",
        "Lire / rafraîchir les résultats Classique": "Read / refresh the Classic results",
        "Lire / rafraîchir les résultats EPW": "Read / refresh the EPW results",
        "Lire résultats": "Read results",
        "Lire les deux voies": "Read both routes",
        "📈 Comparaison WF1 vs WF2": "📈 WF1 vs WF2 comparison",
        "Comparer α²F(ω)": "Compare α²F(ω)",
        "Nécessite que les deux workflows aient tourné pour le même matériau (":
            "Requires both workflows to have run for the same material (",
        "Post-traitement classique : α²F(ω), λ, ω_log → Tᶜ McMillan/Allen-Dynes.":
            "Classic post-processing: α²F(ω), λ, ω_log → McMillan/Allen-Dynes Tᶜ.",
        "α²F(ω), λ, ω_log → Tᶜ McMillan/Allen-Dynes": "α²F(ω), λ, ω_log → McMillan/Allen-Dynes Tᶜ",
        ": α²F(ω), λ, ω_log, Tᶜ McMillan.": ": α²F(ω), λ, ω_log, McMillan Tᶜ.",
        ", Tᶜ McMillan / Allen-Dynes à partir de": ", McMillan / Allen-Dynes Tᶜ from",
        "λ, Tᶜ Éliashberg, gap Δ(T) à partir de": "λ, Éliashberg Tᶜ, gap Δ(T) from",
        "Les deux chemins mènent à la même science (α²F, λ, T": "Both routes lead to the same physics (α²F, λ, T",
        "Visualisation dispersions et modes": "Dispersion and mode visualisation",
        "Upload → visualisation": "Upload → visualisation",

        /* Aide — tableau comparatif */
        "Tableau comparatif des paramètres": "Parameter comparison table",
        "Paramètre": "Parameter",
        "Méthode classique — étapes": "Classic method — steps",
        "Méthode EPW — étapes": "EPW method — steps",
        "Rôle principal": "Main role",
        "Coût relatif": "Relative cost",
        "Cas d'usage": "Use case",
        "Public cible": "Target audience",
        "Points forts Supra-QE": "Supra-QE strengths",
        "Règles imposées par l'interface": "Rules enforced by the interface",
        "Formules": "Formulas",
        "Liens utiles": "Useful links",
        "Compléments utiles": "Useful complements",
        "Comparaison avec les ressources en ligne": "Comparison with online resources",
        "Ressource": "Resource",
        "Interface": "Interface",
        "Automatisation": "Automation",
        "Idéal pour": "Best for",
        "Moteur de calcul": "Calculation engine",
        "Interface web": "Web interface",
        "Navigateur + formulaires": "Browser + forms",
        "Notebooks (Binder / Colab)": "Notebooks (Binder / Colab)",
        "Python / Jupyter": "Python / Jupyter",
        "Python haut niveau sur QE + EPW": "High-level Python on top of QE + EPW",
        "Scripts / boucles possibles": "Scripts / loops possible",
        "Automatisée par scripts": "Script-driven",
        "Via scripts utilisateur": "Through user scripts",
        "UI AiiDA": "AiiDA UI",
        "Cluster / HPC": "Cluster / HPC",
        "Labo / cours": "Lab / teaching",
        "Enseignement / viz": "Teaching / viz",
        "Chercheurs / HT": "Researchers / HT",
        "Experts": "Experts",
        "Recherche, reproductibilité, HT": "Research, reproducibility, HT",
        "Montée en gamme recherche": "Scaling up to research",
        "Cours, premier calcul Tᶜ EPW": "Teaching, a first EPW Tᶜ calculation",
        "Tutoriels dédiés (MgB₂, Pb…)": "Dedicated tutorials (MgB₂, Pb…)",
        "Tutoriels officiels (Pb, MgB₂, Nb…)": "Official tutorials (Pb, MgB₂, Nb…)",
        "Matériaux conventionnels (Nb, MgB₂…)": "Conventional materials (Nb, MgB₂…)",
        "Publications haut niveau, supra anisotrope": "High-level publications, anisotropic superconductivity",
        "Materials Cloud — phonons": "Materials Cloud — phonons",
        "Workflows EPW + provenance": "EPW workflows + provenance",
        "AiiDA + aiida-supercon": "AiiDA + aiida-supercon",
        "Guidée (prérequis, pseudos, ph.x)": "Guided (prerequisites, pseudos, ph.x)",
        "Enchaînement ; convergence fine manuelle": "Chaining; fine convergence done manually",
        "Option limitée dans l’UI": "Limited option in the UI",
        "Oui (locale, FR)": "Yes (local, FR/EN)",
        "Oui (référence)": "Yes (reference)",
        "Oui (screening)": "Yes (screening)",
        "Oui (2 méthodes)": "Yes (2 methods)",
        "Oui (iso, aniso, FBW)": "Yes (iso, aniso, FBW)",
        "Oui": "Yes",
        "Non": "No",
        "Non (pas Tᶜ)": "No (no Tᶜ)",
        "Non (amont)": "No (upstream)",
        "Non (doc + scripts)": "No (docs + scripts)",
        "Forte (scripts)": "Strong (scripts)",
        "Très forte (convergence Tᶜ)": "Very strong (Tᶜ convergence)",
        "Moyen": "Medium",
        "WF dédiés Tᶜ, génération inputs, prérequis, lecture résultats":
            "Dedicated Tᶜ workflows, input generation, prerequisites, result reading",
        "Codes pw.x, ph.x, sources": "pw.x and ph.x codes, sources",
        "Documentation EPW": "EPW documentation",
        "programme Fortran": "Fortran program",
        "bibliothèque Python": "Python library",
        "laboratoire guidé": "guided laboratory",
        "son propre input": "its own input",
        "Chaque programme a": "Each program has",
        "Un": "A",
        "est un": "is a",
        "de": "of",
        "et": "and",
        "dans": "in",
        "deux": "two",
        "simple": "simple",
        "uniquement —": "only —",
        "automatique.": "automatic.",
        "sauvegardé.": "saved.",
        "ci-dessus.": "above.",
        "copier les": "copy the",
        ": placer": ": put",
        "dans vos": "in your",
        "🧊 Supra-QE (ce module)": "🧊 Supra-QE (this module)",
        "Supra-QE (WF2)": "Supra-QE (WF2)",
        "⚛️ Quantum ESPRESSO —": "⚛️ Quantum ESPRESSO —",
        "Quantum ESPRESSO": "Quantum ESPRESSO",
        "🐍 EPWpy (workflows Python + démo navigateur) —": "🐍 EPWpy (Python workflows + browser demo) —",
        "⚙️ AiiDA-supercon (workflows EPW) —": "⚙️ AiiDA-supercon (EPW workflows) —",
        "📘 Tutoriels supraconductivité EPW —": "📘 EPW superconductivity tutorials —",
        "📊 Visualiseur phonons interactif —": "📊 Interactive phonon viewer —",
        "☁️ Materials Cloud (portail) —": "☁️ Materials Cloud (portal) —",
        "🧮 MgB₂ (exemple EPW) —": "🧮 MgB₂ (EPW example) —",
        "EPW ≠ EPWpy — même physique, couches différentes": "EPW ≠ EPWpy — same physics, different layers",
        "McMillan (1968)": "McMillan (1968)",
        "Allen–Dynes (1975)": "Allen–Dynes (1975)",
        ": ajoute deux préfacteurs f₁, f₂.": ": adds two prefactors f₁, f₂.",
        ": équations couplées sur axe imaginaire + prolongation Padé → Δ(T), Tᶜ.":
            ": coupled equations on the imaginary axis + Padé continuation → Δ(T), Tᶜ.",
        ": Tᶜ = (ω_log / 1.20) · exp[ –1.04(1+λ) / (λ – μ*(1+0.62λ)) ]":
            ": Tᶜ = (ω_log / 1.20) · exp[ –1.04(1+λ) / (λ – μ*(1+0.62λ)) ]",
        ": densité électronique convergée avec smearing métallique.":
            ": electron density converged with metallic smearing.",
        ": matrice dynamique + éléments e-p sur la grille q.": ": dynamical matrix + e-p elements on the q grid.",
        ": passage espace q → espace réel (IFC).": ": from q space to real space (IFC).",
        ": identique au classique.": ": same as in the classic route.",
        ": grille q coarse,": ": coarse q grid,",
        "; mode EPW : sauvegarde": "; EPW mode: saves",
        "sur grille q dense": "on a dense q grid",
        "que liront le NSCF et": "that will be read by the NSCF and",
        ": wannierisation + transformée de Fourier des e-p + interpolation grilles 40³ + Éliashberg → Tᶜ et gap Δ.":
            ": wannierisation + Fourier transform of the e-p matrix + interpolation on 40³ grids + Éliashberg → Tᶜ and gap Δ.",
        "EPW interpole le couplage e-p sur grilles ultra-denses puis résout Éliashberg → Tᶜ + gap Δ.":
            "EPW interpolates the e-p coupling on ultra-dense grids then solves Éliashberg → Tᶜ + gap Δ.",
        "Plus lourd (Wannier + Éliashberg)": "Heavier (Wannier + Éliashberg)",
        "C'est exactement ce qu'il faut mettre en valeur dans tes conclusions ou ta soutenance !":
            "This is exactly what you should highlight in your conclusions or your defence!",
        "Mais là où EPWpy automatise pour les experts du code, ton interface démocratise le calcul en encadrant l'utilisateur dans un protocole strict, visuel et sécurisé.":
            "But where EPWpy automates things for code experts, this interface opens the calculation up by guiding the user through a strict, visual and safe protocol.",
        "Parcours guidé en français, garde-fous (pseudos NC, μ*, k/q), comparaison WF1 vs WF2, portable (":
            "Guided walkthrough, safeguards (NC pseudos, μ*, k/q), WF1 vs WF2 comparison, portable (",
        ". Moins flexible qu’EPWpy pour l’aniso avancée (FBW, sparse-ir, campagnes HT), plus simple pour un parcours cours/labo guidé en français.":
            ". Less flexible than EPWpy for advanced anisotropic work (FBW, sparse-ir, HT campaigns), simpler for a guided teaching/lab walkthrough.",
        "par scripts/notebooks (Binder, cluster). Ce n’est pas un autre code de remplacement — c’est une couche d’automatisation et d’analyse au-dessus des mêmes binaires.":
            "through scripts/notebooks (Binder, cluster). It is not a replacement code — it is an automation and analysis layer on top of the same binaries.",
        "local pour Tᶜ (WF1 classique + WF2 EPW). Les plateformes ci-dessous couvrent des besoins complémentaires (tutoriels officiels, visualisation, haute performance).":
            "local tool for Tᶜ (WF1 classic + WF2 EPW). The platforms below cover complementary needs (official tutorials, visualisation, high performance).",
        "EPWpy (notebooks reproductibles) ou AiiDA-supercon (convergence auto des grilles, screening à grande échelle sur cluster).":
            "EPWpy (reproducible notebooks) or AiiDA-supercon (automatic grid convergence, large-scale screening on a cluster).",
        "PseudoDojo pour les pseudos ; tutoriels EPW pour la physique avancée ; Materials Cloud pour animer les phonons après":
            "PseudoDojo for pseudopotentials; EPW tutorials for advanced physics; Materials Cloud to animate phonons after",
        "officiel (Wannier + Éliashberg). C’est lui qui calcule Tᶜ et Δ(T). Le":
            "official code (Wannier + Éliashberg). It is what computes Tᶜ and Δ(T). The",
        "qui pilote QE + Wannier90 +": "which drives QE + Wannier90 +",
        "de Supra-QE l’appelle après": "of Supra-QE calls it after",
        ": interface web + API locale ; génère les": ": web interface + local API; it generates the",
        ". Elle fournit": ". It provides",
        ", lance": ", runs",
        ", lit": ", reads",
        ": une": ": a",
        ") : le": "): the",
        "— ou": "— or",
        ": choisir": ": choose",
        "puis ouvrir": "then open",
        "pour voir": "to see",
        "interpolated": "interpolated",
        "gaussian": "gaussian",
        "log": "log",

        /* ── Cartes d'étapes générées par l'application ─────────────────── */
        "SCF métallique": "Metallic SCF",
        "NSCF dense": "Dense NSCF",
        "Phonons + e-p": "Phonons + e-p",
        "q2r.x — IFC": "q2r.x — IFC",
        "matdyn.x → Tᶜ": "matdyn.x → Tᶜ",
        "alpha2f.x (optionnel)": "alpha2f.x (optional)",
        "Phonons + dvscf (avant NSCF)": "Phonons + dvscf (before NSCF)",
        "NSCF coarse + nbnd": "Coarse NSCF + nbnd",
        "EPW — Wannier + Éliashberg": "EPW — Wannier + Éliashberg",
        "Générateur configs": "Configuration generator",
        "Forces (pw.x)": "Forces (pw.x)",
        "Minimisation SSCHA": "SSCHA minimisation",
        "optionnel": "optional",

        "Densité électronique de référence dans le dossier du workflow — indispensable avant le NSCF dense (le SCF prérequis externe ne partage pas cet outdir).":
            "Reference electron density inside the workflow folder — required before the dense NSCF (the external prerequisite SCF does not share this outdir).",
        "Densité électronique de référence dans le dossier du workflow — base de ph.x puis du NSCF coarse.":
            "Reference electron density inside the workflow folder — the basis for ph.x then for the coarse NSCF.",
        "Cartographie dense de la surface de Fermi (k_nscf très dense).":
            "Dense mapping of the Fermi surface (very dense k_nscf).",
        "DFPT : matrice dynamique + éléments de matrice du couplage électron-phonon.":
            "DFPT: dynamical matrix + electron-phonon coupling matrix elements.",
        "DFPT sur grille q coarse ; sauvegarde des matrices dynamiques et du potentiel perturbé lus ensuite par epw.x.":
            "DFPT on a coarse q grid; saves the dynamical matrices and the perturbed potential later read by epw.x.",
        "Transforme la matrice dynamique en constantes de force en espace réel.":
            "Turns the dynamical matrix into real-space force constants.",
        "Calcule α²F(ω), λ, ω_log et estime Tᶜ via McMillan / Allen-Dynes.":
            "Computes α²F(ω), λ, ω_log and estimates Tᶜ through McMillan / Allen-Dynes.",
        "Post-processeur de α²F(ω) — lisse la courbe pour un tracé plus propre.":
            "α²F(ω) post-processor — smooths the curve for a cleaner plot.",
        "Grille k coarse uniforme et nbnd élevé pour la wannierisation — après ph.x et le regroupement dans save/.":
            "Uniform coarse k grid and high nbnd for the wannierisation — after ph.x and the gathering into save/.",
        "Wannierisation + Fourier des e-p + interpolation grille géante + Éliashberg.":
            "Wannierisation + Fourier transform of the e-p matrix + huge-grid interpolation + Éliashberg.",
        "Supercellules déplacées aléatoirement (base du couplage anharmonique).":
            "Randomly displaced supercells (basis of the anharmonic coupling).",
        "SCF + forces atomiques (tprnfor) sur chaque configuration générée.":
            "SCF + atomic forces (tprnfor) on each generated configuration.",
        "Minimisation de l'énergie libre · fréquences phonons corrigées · α²F(ω).":
            "Free-energy minimisation · corrected phonon frequencies · α²F(ω).",

        /* Recommandations affichées sous chaque étape */
        "Smearing MV, degauss ≈ 0.02 Ry": "MV smearing, degauss ≈ 0.02 Ry",
        "Grille k ≈ 12 × 12 × 12": "k grid ≈ 12 × 12 × 12",
        "Crée outdir utilisé par NSCF et ph.x": "Creates the outdir used by NSCF and ph.x",
        "Grille k ≥ 16 × 16 × 16 (24³ recommandé)": "k grid ≥ 16 × 16 × 16 (24³ recommended)",
        "la2F = .true. (auto)": "la2F = .true. (automatic)",
        "Ratio k/q doit être entier": "The k/q ratio must be an integer",
        "Grille q ≈ 4 × 4 × 4": "q grid ≈ 4 × 4 × 4",
        "Calcul le plus long": "The longest calculation",
        "Très rapide (< 1 min)": "Very fast (< 1 min)",
        "Utilise les fichiers dyn produits par ph.x": "Uses the dyn files produced by ph.x",
        "Aucun paramètre critique": "No critical parameter",
        "μ* = 0.10–0.16 (standard 0.10)": "μ* = 0.10–0.16 (standard 0.10)",
        "Sortie finale Tᶜ": "Final Tᶜ output",
        "Optionnel : matdyn.x produit déjà α²F": "Optional: matdyn.x already produces α²F",
        "Smearing ≈ 0.05": "Smearing ≈ 0.05",
        "Grille q coarse (4³) partagée avec le NSCF EPW": "Coarse q grid (4³) shared with the EPW NSCF",
        "fildvscf obligatoire pour epw.x": "fildvscf mandatory for epw.x",
        "À lancer avant le NSCF (ordre canonique EPW)": "Run before the NSCF (canonical EPW order)",
        "nbnd élevé (≈ 3× les bandes occupées)": "High nbnd (≈ 3× the occupied bands)",
        "Grille k coarse = grille q": "Coarse k grid = q grid",
        "Wannier : nbndsub et fenêtres à surveiller": "Wannier: watch nbndsub and the windows",
        "Nécessite save/ créé depuis les sorties de ph.x": "Requires save/ built from the ph.x outputs",

        /* Boutons et étiquettes des cartes */
        "✏️ Vérifier / éditer": "✏️ Check / edit",
        "💾 Sauvegarder": "💾 Save",
        "🚀 Lancer": "🚀 Run",
        "🖥️ Terminal": "🖥️ Terminal",
        "📊 Suivi": "📊 Monitor",
        "⬇️ Télécharger": "⬇️ Download",
        "📋 Copier": "📋 Copy",
        "↻ Revérifier": "↻ Re-check",
        "↻ Rafraîchir": "↻ Refresh",
        "Chargement…": "Loading…",
        "État :": "Status:",
        "Suivi auto (2 s)": "Auto-follow (2 s)",
        "🔗 Requiert :": "🔗 Requires:",
        "terminé(s)": "finished",
        "✅ terminé": "✅ finished",
        "❌ échec": "❌ failed",
        "⏳ à lancer": "⏳ to run",
        "🔒 en attente": "🔒 waiting",
        "⏳ Valide la structure relaxée": "⏳ Validate the relaxed structure",
        "🔗 Première étape de la chaîne — part du vc-relax validé.":
            "🔗 First step of the chain — starts from the validated vc-relax.",
        "🧪 Matériau actif": "🧪 Active material",
        "— configure les pseudos (1b) puis un workflow —": "— set up the pseudopotentials (1b) then a workflow —",

        /* Journal, chaîne, messages d'état */
        "Vérification de l'enchaînement —": "Chain verification —",
        "🎉 Chaîne complète — passe à l'onglet": "🎉 Chain complete — switch to the",
        "pour lire Tᶜ.": "tab to read Tᶜ.",
        "est bloquée :": "is blocked:",
        "aucune sortie terminée :": "no finished output:",
        "sortie présente mais sans « JOB DONE » :": "output present but without “JOB DONE”:",
        "matrices dynamiques": "dynamical matrices",
        "constantes de force": "force constants",
        "dossier save/ (dvscf + dyn regroupés)": "save/ folder (dvscf + dyn gathered)",
        "Relance ph.x : les fichiers dyn sont produits dans le dossier du workflow.":
            "Run ph.x again: the dyn files are produced in the workflow folder.",
        "Regroupe les sorties de ph.x avec": "Gather the ph.x outputs with",
        "avant de lancer epw.x.": "before running epw.x.",
        "Les lancements restent possibles, mais sans contrôle automatique des dépendances.":
            "Launching is still possible, but without automatic dependency checking.",
        "L'API en cours d'exécution est antérieure à cette interface (endpoint /api/file/stat absent). Redémarre-la avec ./DEMARRER.sh pour activer la vérification pas à pas.":
            "The running API is older than this interface (the /api/file/stat endpoint is missing). Restart it with ./DEMARRER.sh to enable step-by-step verification.",
        "Vérification de la chaîne indisponible.": "Chain verification unavailable.",
        "Valide un matériau pour vérifier l'enchaînement des calculs.":
            "Validate a material to verify the calculation chain.",
        "Structure relaxée requise : place": "Relaxed structure required: put",
        "dans la section ① puis clique « Vérifier les prérequis ».":
            "in section ① then click “Check prerequisites”.",
        "Structure relaxée non exploitable": "Relaxed structure not usable",
        "✅ Structure relaxée exploitable —": "✅ Relaxed structure usable —",
        "Binaires QE manquants sur cette machine": "QE binaries missing on this machine",
        "introuvable(s)": "not found",
        "Les inputs restent générables (bouton 🖥️ Terminal pour lancer ailleurs), mais l'exécution depuis l'interface échouera à ces étapes.":
            "Inputs can still be generated (🖥️ Terminal button to run elsewhere), but running from the interface will fail at those steps.",
        "Indique le bon dossier via": "Point to the right folder through",
        "si les binaires existent ailleurs.": "if the binaries live elsewhere.",
        "API hors-ligne — validation locale du nom uniquement.": "API offline — local name validation only.",
        "API injoignable. Lancer": "API unreachable. Run",
        "Connexion à l'API Supra-QE…": "Connecting to the Supra-QE API…",
        "API en ligne ·": "API online ·",
        "(⚠️ aucun binaire QE détecté)": "(⚠️ no QE binary detected)",
        "Aucun matériau validé. Saisis et valide un matériau (étape 1), choisis un workflow, puis lance les calculs ou dépose les fichiers":
            "No material validated. Enter and validate a material (step 1), pick a workflow, then run the calculations or drop the",
        "Aucune donnée α²F(ω) disponible pour comparer. Lance d'abord matdyn.x ou epw.x.":
            "No α²F(ω) data available to compare. Run matdyn.x or epw.x first.",
        "Lancer quand même ? (à faire si tu as produit ces fichiers ailleurs)":
            "Run anyway? (do this if you produced those files elsewhere)",
        "Sélectionne d'abord un matériau (étape 1).": "Select a material first (step 1).",
        "Sélectionne d'abord un matériau.": "Select a material first.",
        "Choisis d'abord un workflow.": "Choose a workflow first.",
        "Choisis d'abord un workflow (étape 2).": "Choose a workflow first (step 2).",
        "API hors-ligne.": "API offline.",
        "Input introuvable.": "Input not found.",
        "Paramètres invalides :": "Invalid parameters:",
        "✅ Tous les pseudopotentiels sont": "✅ All pseudopotentials are",
        "Les noms de fichiers sont des suggestions PseudoDojo — ajuste-les si besoin.":
            "The file names are PseudoDojo suggestions — adjust them if needed.",
        "Mode Résultats": "Results mode",
        "— choisis WF1 ou WF2, valide le matériau si besoin, puis lis Tᶜ et α²F(ω).":
            "— pick WF1 or WF2, validate the material if needed, then read Tᶜ and α²F(ω).",
        "Toutes les commandes sont prêtes à coller. Utilise-les si tu préfères lancer en dehors de l'interface (et garder le contrôle direct du processus).":
            "Every command is ready to paste. Use them if you prefer running outside the interface (and keeping direct control of the process).",
        "Aller dans le dossier de calcul": "Go to the calculation folder",
        "Définir les threads OpenMP": "Set the OpenMP threads",
        "Lancer le calcul": "Run the calculation",
        "Suivre le log en temps réel": "Follow the log in real time",
        "Une seule commande prête à coller": "A single command ready to paste",
        "Pipeline complet": "Full pipeline",
        "⚠️ Points d'attention :": "⚠️ Things to watch:",
        "Syntaxe Fortran (sensible à la casse)": "Fortran syntax (case sensitive)",
        "Chemins des pseudos cohérents (": "Consistent pseudopotential paths (",
        "Format numérique :": "Number format:",
        "(notation Fortran)": "(Fortran notation)",
        "(non détecté)": "(not detected)",
        "étapes": "steps",
        "pipeline": "pipeline",
    },
};

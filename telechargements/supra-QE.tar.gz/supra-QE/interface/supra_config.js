/* supra_config.js — flags globaux (chargé avant supra_app.js) */
(function (global) {
    'use strict';

    global.SupraConfig = {
        /** WF3 SSCHA : code conservé, masqué dans l'UI tant que l'API n'est pas branchée. */
        ENABLE_SSCHA: false,
        VERSION_UI: '3-wf-2025',
    };

    if (typeof document !== 'undefined') {
        document.body.dataset.sscha = global.SupraConfig.ENABLE_SSCHA ? 'on' : 'off';
    }
})(typeof window !== 'undefined' ? window : globalThis);

#!/usr/bin/env bash
# Supra-QE — prépare un cas test minimal « Nb » (structure + prérequis UI)
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MAT="Nb"
BASE="$ROOT/inputs/$MAT"

echo "[preparer] Racine projet : $ROOT"
echo "[preparer] Matériau      : $MAT"

mkdir -p \
    "$BASE/classic" \
    "$BASE/epw" \
    "$ROOT/outputs/$MAT/classic" \
    "$ROOT/outputs/$MAT/epw" \
    "$ROOT/pseudos"

# ── Templates d'entrée QE (à lancer hors interface) ───────────────────────
cat > "$BASE/$MAT.vc-relax.in" <<'EOF'
! Supra-QE — Prérequis 1 : vc-relax (Nb bcc, maille cubique)
! Lancer depuis inputs/Nb/ : pw.x < Nb.vc-relax.in > Nb.vc-relax.out
! Pseudopotentiel attendu : ../../pseudos/Nb.pbe-spn-kjpaw_psl.1.0.0.UPF

&CONTROL
    calculation   = 'vc-relax'
    restart_mode  = 'from_scratch'
    prefix        = 'Nb'
    outdir        = '../../outputs/Nb/'
    pseudo_dir    = '../../pseudos/'
    forc_conv_thr = 1.0d-4
    etot_conv_thr = 1.0d-5
    verbosity     = 'high'
/

&SYSTEM
    ibrav       = 3
    celldm(1)   = 6.32900000
    nat         = 2
    ntyp        = 1
    ecutwfc     = 60.00
    ecutrho     = 480.00
    occupations = 'smearing'
    smearing    = 'mv'
    degauss     = 0.020000
/

&ELECTRONS
    conv_thr        = 1.0d-10
    mixing_beta     = 0.7d0
    diagonalization = 'david'
/

&IONS
    ion_dynamics = 'bfgs'
/

&CELL
    cell_dynamics  = 'bfgs'
    press          = 0.0000
    press_conv_thr = 0.5000
    cell_dofree    = 'all'
/

ATOMIC_SPECIES
  Nb   92.906400  Nb.pbe-spn-kjpaw_psl.1.0.0.UPF

ATOMIC_POSITIONS crystal
  Nb   0.0000000000   0.0000000000   0.0000000000
  Nb   0.5000000000   0.5000000000   0.5000000000

K_POINTS automatic
  8 8 8  0 0 0
EOF

cat > "$BASE/$MAT.scf_prereq.in" <<'EOF'
! Supra-QE — Prérequis 2 : SCF dense sur géométrie relaxée
! Copier la structure finale de Nb.vc-relax.out dans ce fichier si besoin.
! Lancer : pw.x < Nb.scf_prereq.in > Nb.scf_prereq.out

&CONTROL
    calculation   = 'scf'
    restart_mode  = 'from_scratch'
    prefix        = 'Nb'
    outdir        = '../../outputs/Nb/'
    pseudo_dir    = '../../pseudos/'
    verbosity     = 'high'
/

&SYSTEM
    ibrav       = 3
    celldm(1)   = 6.32900000
    nat         = 2
    ntyp        = 1
    ecutwfc     = 60.00
    ecutrho     = 480.00
    occupations = 'smearing'
    smearing    = 'mv'
    degauss     = 0.020000
/

&ELECTRONS
    conv_thr        = 1.0d-10
    mixing_beta     = 0.7d0
    diagonalization = 'david'
/

ATOMIC_SPECIES
  Nb   92.906400  Nb.pbe-spn-kjpaw_psl.1.0.0.UPF

ATOMIC_POSITIONS crystal
  Nb   0.0000000000   0.0000000000   0.0000000000
  Nb   0.5000000000   0.5000000000   0.5000000000

K_POINTS automatic
  12 12 12  0 0 0
EOF

# ── Sorties DEMO (interface uniquement — remplacer par de vrais .out QE) ───
if [[ ! -f "$BASE/$MAT.vc-relax.out" ]]; then
cat > "$BASE/$MAT.vc-relax.out" <<'EOF'
! =============================================================================
! PLACEHOLDER Supra-QE — Nb.vc-relax.out (DEMO interface)
! Contient JOB DONE + « Begin final coordinates » pour tester l'UI.
! Remplacer par une vraie sortie pw.x avant tout calcul scientifique.
! =============================================================================

     Program PWSCF v.7.3 starts on ...

     bravais-lattice index     =            3
     kinetic-energy cutoff     =          60.0 Ry
     charge density cutoff     =         480.0 Ry

ATOMIC_SPECIES
  Nb   92.906400  Nb.pbe-spn-kjpaw_psl.1.0.0.UPF

     Begin final coordinates
     alat = 6.32900000
CELL_PARAMETERS (alat= 6.32900000)
   1.000000000   0.000000000   0.000000000
   0.000000000   1.000000000   0.000000000
   0.000000000   0.000000000   1.000000000
ATOMIC_POSITIONS crystal
  Nb   0.0000000000   0.0000000000   0.0000000000
  Nb   0.5000000000   0.5000000000   0.5000000000

     JOB DONE.
EOF
fi

if [[ ! -f "$BASE/$MAT.scf_prereq.out" ]]; then
cat > "$BASE/$MAT.scf_prereq.out" <<'EOF'
! =============================================================================
! PLACEHOLDER Supra-QE — Nb.scf_prereq.out (DEMO interface)
! Remplacer par une vraie sortie pw.x (scf) avant lancement du workflow.
! =============================================================================

     Program PWSCF v.7.3 starts on ...
     bravais-lattice index     =            3
     kinetic-energy cutoff     =          60.0 Ry

     total energy              =     -1234.56789012 Ry

     JOB DONE.
EOF
fi

cat > "$BASE/LISEZMOI.txt" <<EOF
Cas test Supra-QE — Niobium (Nb)
================================

Arborescence :
  inputs/Nb/                    ← prérequis (vc-relax + scf)
  inputs/Nb/classic/            ← inputs workflow classique (générés par l'UI)
  inputs/Nb/epw/                ← inputs workflow EPW
  outputs/Nb/                   ← sorties QE communes prérequis
  outputs/Nb/classic/           ← sorties workflow classique
  outputs/Nb/epw/               ← sorties workflow EPW

Fichiers prérequis attendus par l'interface :
  inputs/Nb/Nb.vc-relax.out
  inputs/Nb/Nb.scf.out  OU  inputs/Nb/Nb.scf_prereq.out

Les fichiers *.out fournis par défaut sont des PLACEHOLDERS (DEMO UI).
Pour un calcul réel :
  1. Copier Nb.pbe-spn-kjpaw_psl.1.0.0.UPF dans pseudos/
  2. cd inputs/Nb && pw.x < Nb.vc-relax.in > Nb.vc-relax.out
  3. Mettre à jour ATOMIC_POSITIONS / celldm dans Nb.scf_prereq.in si besoin
  4. pw.x < Nb.scf_prereq.in > Nb.scf_prereq.out
  5. ./DEMARRER.sh → interface → matériau « Nb » → Vérifier prérequis

Regénérer cette arborescence : ./scripts/preparer_cas_test_Nb.sh
EOF

touch "$BASE/classic/.gitkeep" "$BASE/epw/.gitkeep"

echo ""
echo "  Cas test Nb prêt :"
echo "    $BASE/"
echo "    $ROOT/outputs/$MAT/"
echo ""
echo "  Interface : matériau « Nb », chemin prérequis « inputs/Nb », bouton « Vérifier prérequis »."
echo "  Les .out DEMO permettent de débloquer l'UI ; remplace-les pour un calcul réel."
echo ""

#!/usr/bin/env bash
# ==========================================================================
#  Supra-QE — EMBALLER.sh : compactage du projet pour transfert
#
#  Crée une archive prête à copier sur une autre machine, en excluant
#  les fichiers propres à la machine source (config.env, .venv/, logs/…).
#
#  Usage :
#    ./EMBALLER.sh                            # archive par défaut
#    ./EMBALLER.sh --output mon_archive.tar.gz
#    ./EMBALLER.sh --no-demo                  # sans le cas test Nb
#    ./EMBALLER.sh --include-outputs          # inclure outputs/
# ==========================================================================

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

PROJET="$(basename "$HERE")"
DATE_TAG="$(date +%Y%m%d_%H%M%S)"
ARCHIVE_DEFAUT="${PROJET}_${DATE_TAG}.tar.gz"
ARCHIVE=""
INCLUDE_OUTPUTS=0
INCLUDE_DEMO=1

usage() {
    cat <<EOF
Usage : ./EMBALLER.sh [options]

Options :
  -o, --output FICHIER   Nom de l'archive (défaut : ${PROJET}_<date>.tar.gz)
  --include-outputs       Inclure outputs/ (défaut : non)
  --no-demo               Exclure le cas test Nb (défaut : inclus)
  -h, --help              Afficher cette aide

Exemples :
  ./EMBALLER.sh
  ./EMBALLER.sh -o supra-QE-portable.tar.gz
  ./EMBALLER.sh --no-demo --include-outputs
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        -o|--output) ARCHIVE="${2:-}"; shift 2 ;;
        --include-outputs) INCLUDE_OUTPUTS=1; shift ;;
        --no-demo)         INCLUDE_DEMO=0; shift ;;
        -h|--help) usage; exit 0 ;;
        *) echo "[emballer] option inconnue : $1" >&2; usage; exit 1 ;;
    esac
done

ARCHIVE="${ARCHIVE:-$ARCHIVE_DEFAUT}"

echo ""
echo "  ╔══════════════════════════════════════════════════════════╗"
echo "  ║   Supra-QE — Emballage pour transfert                    ║"
echo "  ╚══════════════════════════════════════════════════════════╝"
echo ""
echo "  Projet   : $HERE"
echo "  Archive  : $ARCHIVE"
echo ""

# ── Vérifications ────────────────────────────────────────────────────────
if [[ ! -f "README.md" ]]; then
    echo "[emballer] ERREUR : exécute depuis la racine du projet supra-QE/" >&2
    exit 1
fi

if [[ -f "$ARCHIVE" ]]; then
    echo "[emballer] ⚠️  L'archive existe déjà : $ARCHIVE"
    if [[ -t 0 ]]; then
        read -r -p "  Écraser ? (o/N) " ans
        if [[ ! "$ans" =~ ^[oOyY] ]]; then
            echo "[emballer] annulé."
            exit 0
        fi
    fi
    rm -f "$ARCHIVE"
fi

# ── Construction de la liste d'exclusion ─────────────────────────────────
# On construit un fichier .tar_exclude temporaire
TMP_EXCLUDE="$(mktemp)"
cleanup() { rm -f "$TMP_EXCLUDE"; }
trap cleanup EXIT

cat > "$TMP_EXCLUDE" <<EXCLURE
${PROJET}/config.env
${PROJET}/.venv
${PROJET}/__pycache__
${PROJET}/*.pyc
${PROJET}/logs
${PROJET}/tmp
${PROJET}/*.pid
${PROJET}/outputs
${PROJET}/.pytest_cache
${PROJET}/.git
${PROJET}/thermo_pw
${PROJET}/*.tar.gz
EXCLURE

if [[ "$INCLUDE_OUTPUTS" -eq 1 ]]; then
    # Portable : on recrée le fichier sans la ligne outputs/
    grep -v "^${PROJET}/outputs" "$TMP_EXCLUDE" > "${TMP_EXCLUDE}_filtre" || true
    mv "${TMP_EXCLUDE}_filtre" "$TMP_EXCLUDE"
fi

if [[ "$INCLUDE_DEMO" -eq 0 ]]; then
    {
        echo "${PROJET}/inputs/Nb"
        echo "${PROJET}/inputs/DEMO_Nb"
        echo "${PROJET}/outputs/DEMO_Nb"
    } >> "$TMP_EXCLUDE"
fi

# ── Vérification de la taille ───────────────────────────────────────────
# du lit des chemins relatifs à « . » (pas le préfixe supra-QE/ du tar)
TMP_DU_EXCL="$(mktemp)"
sed "s|^${PROJET}/||" "$TMP_EXCLUDE" > "$TMP_DU_EXCL"
TAILLE_ESTIMEE="$(du -sh . --exclude-from="$TMP_DU_EXCL" 2>/dev/null | cut -f1 || echo "?")"
rm -f "$TMP_DU_EXCL"
echo "  Taille estimée (hors exclus) : $TAILLE_ESTIMEE"
echo ""

# Chemin absolu de l'archive (défaut : dossier parent du projet)
if [[ "$ARCHIVE" != /* ]]; then
    ARCHIVE="$(dirname "$HERE")/$ARCHIVE"
fi

echo "[emballer] création de l'archive : $ARCHIVE"
echo "[emballer] fichiers exclus : config.env, .venv/, logs/, tmp/, outputs/, thermo_pw/, .git/, *.tar.gz"

tar czf "$ARCHIVE" \
    --exclude-from="$TMP_EXCLUDE" \
    --exclude="$(basename "$ARCHIVE")" \
    -C "$(dirname "$HERE")" \
    "$(basename "$HERE")"

# ── Résumé ──────────────────────────────────────────────────────────────
echo ""
echo "  ┌────────────────────────────────────────────────────────────┐"
echo "  │  Emballage terminé ✓                                      │"
echo "  └────────────────────────────────────────────────────────────┘"
echo ""
echo "  Fichier : $ARCHIVE"
echo "  Taille   : $(du -sh "$ARCHIVE" | cut -f1)"
echo "  Type     : $(file -b "$ARCHIVE")"
echo ""
echo "  Vérifier que c’est bien compacté :"
echo "    ls -lh \"$ARCHIVE\""
echo "    du -h \"$ARCHIVE\""
echo "    file \"$ARCHIVE\"          # doit indiquer gzip compressed"
echo "    tar tzf \"$ARCHIVE\" | wc -l"
echo ""

# ── Instructions ────────────────────────────────────────────────────────
echo "  ── Prochaine étape sur le NOUVEAU PC ────────────────────────"
echo ""
echo "  1. Copier l'archive sur le nouveau PC (clé USB, SCP, …) :"
echo "     scp \"$ARCHIVE\" utilisateur@192.168.x.x:/chemin/destination/"
echo ""
echo "  2. Sur le nouveau PC :"
echo "     cd /chemin/destination"
echo "     tar xzf $(basename "$ARCHIVE")"
echo "     cd $PROJET"
echo "     ./INSTALL_AUTOMATIQUE.sh -y --qe-bin /chemin/qe/bin"
echo "     # ou : ./AUTO_TRANSFERT.sh -y --qe-bin /chemin/qe/bin"
echo ""
echo "  Pour déplacer aussi la config :"
echo "    cp config.env.example config.env   # puis éditer"
echo "    ./DEMARRER.sh"
echo ""

# ── Option : afficher le contenu de l'archive ──────────────────────────
if [[ -t 0 ]]; then
    read -r -p "  Afficher le contenu de l'archive ? (o/N) " voir
else
    voir=""
fi
if [[ "$voir" =~ ^[oOyY] ]]; then
    echo ""
    tar tzf "$ARCHIVE" | head -40
    echo "  … ($(tar tzf "$ARCHIVE" | wc -l) entrées au total)"
    echo ""
fi

echo "[emballer] terminé."

#!/usr/bin/env bash
# ==========================================================================
#  Supra-QE — Installation automatique (nouveau PC)
#
#  Objectif :
#    1) installer les prérequis système (optionnel via configurer.sh)
#    2) générer config.env avec les chemins souhaités
#    3) démarrer l'API + interface
#
#  Usage :
#    ./INSTALL_AUTOMATIQUE.sh
#    ./INSTALL_AUTOMATIQUE.sh --qe-bin /opt/qe/bin --pseudo-dir /data/pseudos
#    ./INSTALL_AUTOMATIQUE.sh --no-start --outputs-dir /data/outputs
# ==========================================================================

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

NO_START=0
PASS_ARGS=()

usage() {
    cat <<'EOF'
Usage : ./INSTALL_AUTOMATIQUE.sh [options]

Options reconnues :
  --no-start          Configure seulement (ne lance pas DEMARRER.sh)
  -h, --help          Afficher cette aide

Toutes les autres options sont transmises à ./configurer.sh :
  --qe-bin PATH
  --pseudo-dir PATH
  --inputs-dir PATH
  --outputs-dir PATH
  --logs-dir PATH
  --tmp-dir PATH
  --host ADDR
  --port N
  --skip-venv
  -y|--yes
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --no-start) NO_START=1; shift ;;
        -h|--help) usage; exit 0 ;;
        *) PASS_ARGS+=("$1"); shift ;;
    esac
done

if [[ ! -x "$HERE/configurer.sh" ]]; then
    echo "[install-auto] ERREUR: configurer.sh introuvable ou non exécutable." >&2
    exit 1
fi

if [[ ! -x "$HERE/DEMARRER.sh" ]]; then
    echo "[install-auto] ERREUR: DEMARRER.sh introuvable ou non exécutable." >&2
    exit 1
fi

echo ""
echo "  ╔══════════════════════════════════════════════════════════╗"
echo "  ║   Supra-QE — Installation automatique                    ║"
echo "  ╚══════════════════════════════════════════════════════════╝"
echo ""
echo "  Dossier : $HERE"
echo ""

# Force l'installation système depuis configurer.sh sauf si l'utilisateur
# l'a déjà explicitement fourni.
HAS_INSTALL_FLAG=0
for a in "${PASS_ARGS[@]:-}"; do
    if [[ "$a" == "--install-prereqs" ]]; then
        HAS_INSTALL_FLAG=1
        break
    fi
done

CFG_ARGS=("${PASS_ARGS[@]}")
if [[ "$HAS_INSTALL_FLAG" -eq 0 ]]; then
    CFG_ARGS+=(--install-prereqs)
fi

echo "[install-auto] Étape 1/2 : configuration locale"
"$HERE/configurer.sh" "${CFG_ARGS[@]}"

if [[ "$NO_START" -eq 1 ]]; then
    echo "[install-auto] Étape 2/2 : démarrage ignoré (--no-start)."
    echo "[install-auto] Lance manuellement : ./DEMARRER.sh"
    exit 0
fi

echo "[install-auto] Étape 2/2 : démarrage de Supra-QE"
"$HERE/DEMARRER.sh"


#!/usr/bin/env bash
# ==========================================================================
#  Supra-QE — Configuration après transfert sur un nouveau PC
#
#  Usage :
#    ./configurer.sh                    # mode interactif (recommandé)
#    ./configurer.sh --qe-bin /opt/qe/bin
#    ./configurer.sh -y --qe-bin ~/q-e-qe-7.5/bin
#
#  Produit : config.env (lu par DEMARRER.sh, ARRETER.sh, STATUT.sh)
# ==========================================================================

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

CONFIG_FILE="$HERE/config.env"
NONINTERACTIVE=0
SKIP_VENV=0
INSTALL_PREREQS=0
QE_BIN_IN=""
PSEUDO_DIR_IN=""
INPUTS_DIR_IN=""
OUTPUTS_DIR_IN=""
LOGS_DIR_IN=""
TMP_DIR_IN=""
PORT_IN=""
HOST_IN=""

# Binaires requis / optionnels
REQUIRED_BINS=(pw.x ph.x q2r.x matdyn.x)
OPTIONAL_BINS=(epw.x alpha2f.x lambda.x)

usage() {
    cat <<'EOF'
Usage : ./configurer.sh [options]

Options :
  --qe-bin PATH       Dossier contenant pw.x, ph.x, …
  --pseudo-dir PATH   Dossier des fichiers .upf (défaut : supra-QE/pseudos/)
  --inputs-dir PATH   Dossier des inputs (défaut : supra-QE/inputs/)
  --outputs-dir PATH  Dossier des outputs (défaut : supra-QE/outputs/)
  --logs-dir PATH     Dossier des logs (défaut : supra-QE/logs/)
  --tmp-dir PATH      Dossier tmp/jobs (défaut : supra-QE/tmp/)
  --port N            Port de l'API (défaut : 8765)
  --host ADDR         Hôte de l'API (défaut : 127.0.0.1)
  --install-prereqs   Installe automatiquement les dépendances système (apt/dnf/pacman)
  -y, --yes           Mode non interactif (nécessite --qe-bin si non détecté)
  --skip-venv         Ne pas créer / mettre à jour le venv Python
  -h, --help          Afficher cette aide

Exemple après copie du dossier sur un autre PC :
  ./configurer.sh
  ./DEMARRER.sh
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --qe-bin)      QE_BIN_IN="${2:-}"; shift 2 ;;
        --pseudo-dir)  PSEUDO_DIR_IN="${2:-}"; shift 2 ;;
        --inputs-dir)  INPUTS_DIR_IN="${2:-}"; shift 2 ;;
        --outputs-dir) OUTPUTS_DIR_IN="${2:-}"; shift 2 ;;
        --logs-dir)    LOGS_DIR_IN="${2:-}"; shift 2 ;;
        --tmp-dir)     TMP_DIR_IN="${2:-}"; shift 2 ;;
        --port)        PORT_IN="${2:-}"; shift 2 ;;
        --host)        HOST_IN="${2:-}"; shift 2 ;;
        --install-prereqs) INSTALL_PREREQS=1; shift ;;
        -y|--yes)      NONINTERACTIVE=1; shift ;;
        --skip-venv)   SKIP_VENV=1; shift ;;
        -h|--help)     usage; exit 0 ;;
        *) echo "[configurer] option inconnue : $1" >&2; usage; exit 1 ;;
    esac
done

prompt() {
    local msg="$1" default="${2:-}"
    if [[ "$NONINTERACTIVE" -eq 1 ]]; then
        printf '%s' "$default"
        return
    fi
    local ans
    read -r -p "$msg [$default] " ans
    if [[ -z "$ans" ]]; then printf '%s' "$default"; else printf '%s' "$ans"; fi
}

confirm() {
    local msg="$1"
    if [[ "$NONINTERACTIVE" -eq 1 ]]; then return 0; fi
    read -r -p "$msg (o/N) " ans
    [[ "$ans" =~ ^[oOyY] ]]
}

abs_path() {
    local p="$1"
    [[ -z "$p" ]] && return 1
    if [[ -d "$p" ]]; then
        (cd "$p" && pwd)
    else
        echo "$p"
    fi
}

find_qe_bin() {
    local cand
    for cand in \
        "$QE_BIN_IN" \
        "${QE_BIN_DIR:-}" \
        "$HERE/bin" \
        "/opt/qe/bin" \
        "/usr/local/qe/bin"; do
        [[ -n "$cand" && -x "$cand/pw.x" ]] || continue
        abs_path "$cand"
        return 0
    done
    local home_glob
    for home_glob in "$HOME"/q-e*/bin "$HOME"/qe*/bin; do
        [[ -d "$home_glob" && -x "$home_glob/pw.x" ]] || continue
        abs_path "$home_glob"
        return 0
    done
    return 1
}

write_config() {
    local qe_bin="$1" pseudo_dir="$2" host="$3" port="$4"
    local inputs_dir="$5" outputs_dir="$6" logs_dir="$7" tmp_dir="$8"
    cat > "$CONFIG_FILE" <<EOF
# Supra-QE — configuration locale
# Généré le $(date -Iseconds) par configurer.sh
# Ne pas versionner (machine locale). Recopier config.env.example sur un autre PC.

export QE_BIN_DIR="$qe_bin"
export QE_PSEUDO_DIR="$pseudo_dir"
export SUPRA_QE_HOST="$host"
export SUPRA_QE_PORT="$port"
export SUPRA_INPUTS_DIR="$inputs_dir"
export SUPRA_OUTPUTS_DIR="$outputs_dir"
export SUPRA_LOGS_DIR="$logs_dir"
export SUPRA_TMP_DIR="$tmp_dir"
export SUPRA_PSEUDO_DIR_REL="../../../pseudos/"
EOF
    chmod 600 "$CONFIG_FILE" 2>/dev/null || true
}

install_system_prereqs() {
    if [[ "$INSTALL_PREREQS" -ne 1 ]]; then
        return 0
    fi
    echo "[configurer] installation des prérequis système demandée (--install-prereqs)"
    if command -v apt-get >/dev/null 2>&1; then
        sudo apt-get update
        sudo apt-get install -y python3 python3-venv python3-pip curl tar
        return 0
    fi
    if command -v dnf >/dev/null 2>&1; then
        sudo dnf install -y python3 python3-pip curl tar
        return 0
    fi
    if command -v pacman >/dev/null 2>&1; then
        sudo pacman -Sy --noconfirm python python-pip curl tar
        return 0
    fi
    echo "[configurer] ⚠️ Gestionnaire de paquets non supporté automatiquement."
    echo "[configurer]    Installe manuellement : python3, python3-venv, pip, curl, tar."
}

setup_venv() {
    if [[ "$SKIP_VENV" -eq 1 ]]; then
        echo "[configurer] venv ignoré (--skip-venv)"
        return 0
    fi
    local py="$HERE/.venv/bin/python"
    if [[ -x "$py" ]] && "$py" -c "import flask, flask_cors" >/dev/null 2>&1; then
        echo "[configurer] venv OK : $py"
        return 0
    fi
    echo "[configurer] création du venv Python dans $HERE/.venv"
    if ! command -v python3 >/dev/null 2>&1; then
        echo "[configurer] ⚠️  python3 introuvable — installe Python 3 puis relance." >&2
        return 1
    fi
    python3 -m venv "$HERE/.venv"
    if ! "$HERE/.venv/bin/pip" install --upgrade pip -q; then
        echo "[configurer] ⚠️  pip upgrade échoué (réseau ?) — réessaie ou installe Flask à la main." >&2
        return 1
    fi
    if ! "$HERE/.venv/bin/pip" install -r "$HERE/requirements.txt" -q; then
        echo "[configurer] ⚠️  installation requirements.txt échouée." >&2
        echo "[configurer]    $HERE/.venv/bin/pip install -r requirements.txt" >&2
        return 1
    fi
    echo "[configurer] dépendances installées (Flask, flask-cors, numpy)"
    return 0
}

# ── Début ─────────────────────────────────────────────────────────────────
echo ""
echo "  ╔══════════════════════════════════════════════════════════╗"
echo "  ║   Supra-QE — Configuration (transfert / nouveau PC)      ║"
echo "  ╚══════════════════════════════════════════════════════════╝"
echo ""
echo "  Dossier projet : $HERE"
echo ""

install_system_prereqs

DEFAULT_INPUTS="$HERE/inputs"
DEFAULT_OUTPUTS="$HERE/outputs"
DEFAULT_LOGS="$HERE/logs"
DEFAULT_TMP="$HERE/tmp"
DEFAULT_PSEUDO="$HERE/pseudos"

# ── 1. Binaires QE ────────────────────────────────────────────────────────
DETECTED=""
if DETECTED="$(find_qe_bin 2>/dev/null)"; then
    echo "[configurer] QE détecté automatiquement : $DETECTED"
else
    echo "[configurer] Aucun QE détecté automatiquement."
    DETECTED=""
fi

if [[ -n "$QE_BIN_IN" ]]; then
    DETECTED="$(abs_path "$QE_BIN_IN" 2>/dev/null || echo "$QE_BIN_IN")"
fi

if [[ -z "$DETECTED" ]] || [[ ! -x "$DETECTED/pw.x" ]]; then
    if [[ "$NONINTERACTIVE" -eq 1 ]]; then
        echo "[configurer] ERREUR : précise --qe-bin /chemin/vers/qe/bin" >&2
        exit 1
    fi
    echo ""
    echo "  Indique le dossier qui contient pw.x (ex. ~/q-e-qe-7.5/bin)"
    DETECTED="$(prompt "Chemin QE_BIN_DIR" "")"
    DETECTED="$(abs_path "$DETECTED" 2>/dev/null || echo "$DETECTED")"
fi

if [[ ! -x "$DETECTED/pw.x" ]]; then
    echo "[configurer] ERREUR : pw.x introuvable dans $DETECTED" >&2
    exit 1
fi

# Vérification des binaires
REQ_OK=""; REQ_MISS=""; OPT_OK=""; OPT_MISS=""
for b in "${REQUIRED_BINS[@]}"; do
    if [[ -x "$DETECTED/$b" ]]; then REQ_OK+="$b "; else REQ_MISS+="$b "; fi
done
for b in "${OPTIONAL_BINS[@]}"; do
    if [[ -x "$DETECTED/$b" ]]; then OPT_OK+="$b "; else OPT_MISS+="$b "; fi
done

echo ""
echo "  Binaires trouvés (obligatoires) : ${REQ_OK:-aucun}"
if [[ -n "${REQ_MISS// }" ]]; then
    echo "  ⚠️  Manquants (méthode classique bloquée) : $REQ_MISS"
fi
echo "  Binaires optionnels (EPW)         : ${OPT_OK:-aucun}"
if [[ -n "${OPT_MISS// }" ]]; then
    echo "  ℹ️  Absents (EPW indisponible)     : $OPT_MISS"
fi

if [[ -n "${REQ_MISS// }" ]]; then
    if ! confirm "Continuer malgré les binaires manquants ?"; then
        exit 1
    fi
fi

# ── 2. Dossiers configurables ─────────────────────────────────────────────
if [[ -n "$INPUTS_DIR_IN" ]]; then
    INPUTS_ABS="$(abs_path "$INPUTS_DIR_IN")"
else
    INPUTS_ABS="$(prompt "Dossier inputs" "$DEFAULT_INPUTS")"
    INPUTS_ABS="$(abs_path "$INPUTS_ABS" 2>/dev/null || echo "$INPUTS_ABS")"
fi
if [[ -n "$OUTPUTS_DIR_IN" ]]; then
    OUTPUTS_ABS="$(abs_path "$OUTPUTS_DIR_IN")"
else
    OUTPUTS_ABS="$(prompt "Dossier outputs" "$DEFAULT_OUTPUTS")"
    OUTPUTS_ABS="$(abs_path "$OUTPUTS_ABS" 2>/dev/null || echo "$OUTPUTS_ABS")"
fi
if [[ -n "$LOGS_DIR_IN" ]]; then
    LOGS_ABS="$(abs_path "$LOGS_DIR_IN")"
else
    LOGS_ABS="$(prompt "Dossier logs" "$DEFAULT_LOGS")"
    LOGS_ABS="$(abs_path "$LOGS_ABS" 2>/dev/null || echo "$LOGS_ABS")"
fi
if [[ -n "$TMP_DIR_IN" ]]; then
    TMP_ABS="$(abs_path "$TMP_DIR_IN")"
else
    TMP_ABS="$(prompt "Dossier tmp" "$DEFAULT_TMP")"
    TMP_ABS="$(abs_path "$TMP_ABS" 2>/dev/null || echo "$TMP_ABS")"
fi
mkdir -p "$INPUTS_ABS" "$OUTPUTS_ABS" "$LOGS_ABS" "$TMP_ABS" "$HERE/bin"

# ── 3. Pseudopotentiels ───────────────────────────────────────────────────
if [[ -n "$PSEUDO_DIR_IN" ]]; then
    PSEUDO_ABS="$(abs_path "$PSEUDO_DIR_IN")"
else
    PSEUDO_ABS="$(prompt "Dossier des pseudos .upf" "$DEFAULT_PSEUDO")"
    PSEUDO_ABS="$(abs_path "$PSEUDO_ABS" 2>/dev/null || echo "$PSEUDO_ABS")"
fi
mkdir -p "$PSEUDO_ABS"
N_UPF=$(find "$PSEUDO_ABS" -maxdepth 2 -iname '*.upf' 2>/dev/null | wc -l | tr -d ' ')
echo ""
echo "  Pseudos : $PSEUDO_ABS ($N_UPF fichier(s) .upf)"
if [[ "$N_UPF" -eq 0 ]]; then
    echo "  ⚠️  Aucun .upf — copie tes pseudos NC (PseudoDojo) dans ce dossier avant les calculs."
fi

# Si pseudos = dossier projet par défaut, QE_PSEUDO_DIR vide (l'API utilise REPO/pseudos)
QE_PSEUDO_EXPORT=""
if [[ "$(abs_path "$PSEUDO_ABS")" != "$(abs_path "$DEFAULT_PSEUDO")" ]]; then
    QE_PSEUDO_EXPORT="$PSEUDO_ABS"
fi

# ── 4. Réseau API ─────────────────────────────────────────────────────────
HOST="${HOST_IN:-$(prompt "Hôte API" "127.0.0.1")}"
PORT="${PORT_IN:-$(prompt "Port API" "8765")}"

# ── 5. Écriture config.env ──────────────────────────────────────────────────
write_config "$DETECTED" "$QE_PSEUDO_EXPORT" "$HOST" "$PORT" \
    "$INPUTS_ABS" "$OUTPUTS_ABS" "$LOGS_ABS" "$TMP_ABS"
echo ""
echo "[configurer] Fichier écrit : $CONFIG_FILE"

# ── 6. Python venv ────────────────────────────────────────────────────────
if ! setup_venv; then
    echo "[configurer] config.env OK — termine l'installation Python puis ./DEMARRER.sh"
fi

# ── 7. Résumé ─────────────────────────────────────────────────────────────
echo ""
echo "  ┌────────────────────────────────────────────────────────────┐"
echo "  │  Configuration terminée                                  │"
echo "  ├────────────────────────────────────────────────────────────┤"
echo "  │  QE_BIN_DIR     = $DETECTED"
echo "  │  Pseudos        = ${QE_PSEUDO_EXPORT:-$DEFAULT_PSEUDO (défaut projet)}"
echo "  │  Inputs         = $INPUTS_ABS"
echo "  │  Outputs        = $OUTPUTS_ABS"
echo "  │  Logs / tmp     = $LOGS_ABS / $TMP_ABS"
echo "  │  pseudo_dir .in = ../../../pseudos/ (depuis classic/ ou epw/)"
echo "  │  API            = http://${HOST}:${PORT}/interface"
echo "  └────────────────────────────────────────────────────────────┘"
echo ""
echo "  Prochaines étapes :"
echo "    1. Copier les fichiers .upf dans : ${QE_PSEUDO_EXPORT:-$DEFAULT_PSEUDO}"
echo "    2. Lancer : ./DEMARRER.sh"
echo "    3. Vérifier : ./STATUT.sh"
echo "    4. Dans l'interface : charger vc-relax.out → Générer les inputs"
echo ""
echo "  Pour réutiliser la config dans un terminal :"
echo "    source $CONFIG_FILE"
echo ""

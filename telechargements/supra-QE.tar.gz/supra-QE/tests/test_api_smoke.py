#!/usr/bin/env python3
"""Tests fumée API Supra-QE (sans lancer le serveur)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "api"))

import supra_api  # noqa: E402


@pytest.fixture
def client():
    supra_api.app.config["TESTING"] = True
    with supra_api.app.test_client() as c:
        yield c


def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    data = r.get_json()
    assert data.get("service") == "supra-qe"
    assert "inputs_dir" in data
    assert "outputs_dir" in data


def test_pseudo_check_missing(client):
    r = client.post(
        "/api/pseudo/check",
        data=json.dumps({"pseudos": ["Xx.upf"], "pseudo_dir": str(ROOT / "pseudos")}),
        content_type="application/json",
    )
    assert r.status_code == 200
    data = r.get_json()
    assert data.get("results")
    assert data.get("all_nc") is False


def test_materials_list(client):
    r = client.get("/api/materials/list")
    assert r.status_code == 200
    data = r.get_json()
    assert data.get("ok") is True
    assert isinstance(data.get("materials"), list)


def test_grid_validate(client):
    r = client.post(
        "/api/grid/validate",
        data=json.dumps({"k": [24, 24, 24], "q": [4, 4, 4]}),
        content_type="application/json",
    )
    assert r.status_code == 200
    data = r.get_json()
    assert data.get("ok") is True

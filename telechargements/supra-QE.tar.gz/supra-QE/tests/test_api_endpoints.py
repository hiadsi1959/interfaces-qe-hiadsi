#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tests endpoints & logique métier — supra-QE (P2 — industrialisation).

Couvre (en plus de test_api_smoke.py et test_api_security.py) :
  * Logique métier pure : parse_matdyn_lambda, parse_epw_output,
    tc_mcmillan, tc_allen_dynes, detect_pseudo_kind, _extract_final_structure.
  * Endpoints : /api/results/{tc,epw,alpha2F,compare}, /api/file/read,
    /api/job/<id>, /api/materials/search, /api/relaxed/{list,upload},
    /api/pseudo/{list,upload}.

Exécuter :
    .venv/bin/pytest tests/test_api_endpoints.py -v
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "api"))

import supra_api  # noqa: E402


# ════════════════════════════  SECTION 1 : FIXTURES  ════════════════════════════


@pytest.fixture
def client():
    supra_api.app.config["TESTING"] = True
    with supra_api.app.test_client() as c:
        yield c


@pytest.fixture(autouse=True)
def _isolated_paths(monkeypatch, tmp_path):
    """Redirige les chemins globaux vers tmp_path pour isoler chaque test."""
    inp = tmp_path / "inputs"
    out = tmp_path / "outputs"
    pse = tmp_path / "pseudos"
    tmp = tmp_path / "tmp"
    for d in (inp, out, pse, tmp):
        d.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(supra_api, "INPUTS_DIR", inp)
    monkeypatch.setattr(supra_api, "OUTPUTS_DIR", out)
    monkeypatch.setattr(supra_api, "PSEUDOS_DIR", pse)
    monkeypatch.setattr(supra_api, "TMP_DIR", tmp)
    monkeypatch.setattr(supra_api, "REPO_ROOT", tmp_path)
    yield {"inputs": inp, "outputs": out, "pseudos": pse, "tmp": tmp}


@pytest.fixture(autouse=True)
def _clean_jobs():
    """Vide le dict JOBS entre tests (évite la pollution d'état)."""
    supra_api.JOBS.clear()
    yield
    supra_api.JOBS.clear()


# Petites fixtures string : outputs QE synthétiques contenant les marqueurs regex

FAKE_MATDYN_OUT = """\
     Program MATDYN v.7.0     starts ...
     electron-phonon coupling

         lambda :   0.85
       <log w>  =   412.3 K
         mu*    :   0.10
     Tc               =    19.4 K

     END
"""

FAKE_EPW_OUT = """\
     Program EPW v.5.8 starts ...

     Electron-phonon coupling strength    =   1.20
      omega_log =  220.5 K
      laniso = .true.
      muc = 0.10

      Solving anisotropic Eliashberg equations...

      Temperature   1.000 K   max Delta = 4.123 meV
      Temperature   5.000 K   max Delta = 3.987 meV
      Temperature  10.000 K   max Delta = 3.012 meV
      Temperature  15.000 K   max Delta = 1.456 meV
      Temperature  19.500 K   max Delta = 0.345 meV
      Temperature  20.000 K   max Delta = 0.000 meV

     END
"""

FAKE_VCRELAX_OUT = """\
     Program PWSCF v.7.0 starts ...

     bravais-lattice index     =    3
     kinetic-energy cutoff     =   60.00 Ry
     charge density cutoff     =  240.00 Ry

     CELL_PARAMETERS (alat=  6.5000)
      1.000000000  0.000000000  0.000000000
      0.000000000  1.000000000  0.000000000
      0.000000000  0.000000000  1.000000000

     ATOMIC_POSITIONS (crystal)
     Nb    0.000000000  0.000000000  0.000000000
     Nb    0.500000000  0.500000000  0.500000000

     ATOMIC_SPECIES
     Nb   92.906   Nb.upf

     Begin final coordinates
     CELL_PARAMETERS (alat=  6.5000)
      0.987654321  0.000000000  0.000000000
      0.000000000  0.987654321  0.000000000
      0.000000000  0.000000000  0.987654321

     ATOMIC_POSITIONS (crystal)
     Nb    0.000000000  0.000000000  0.000000000
     Nb    0.500000000  0.500000000  0.500000000

     END
     JOB DONE
"""

FAKE_UPF_NC = """\
<UPF version="2.0.1">
  <PP_INFO>
    Test Norm-Conserving UPF for supra-QE testsuite
  </PP_INFO>
  <PP_HEADER
    generated="Test"
    Element="Nb"
    pseudo_type="NC">
  </PP_HEADER>
</UPF>
"""

FAKE_UPF_USPP = """\
<UPF version="2.0.1">
  <PP_INFO>
    Test USPP UPF for supra-QE testsuite (incompatible with ph.x)
  </PP_INFO>
  <PP_HEADER
    generated="Test"
    Element="Nb"
    pseudo_type="US"
    is_ultrasoft="T">
  </PP_HEADER>
</UPF>
"""

FAKE_UPF_PAW = """\
<UPF version="2.0.1">
  <PP_INFO>
    Test PAW UPF for supra-QE testsuite (incompatible with ph.x)
  </PP_INFO>
  <PP_HEADER
    generated="Test"
    Element="Nb"
    pseudo_type="PAW"
    is_paw="T">
  </PP_HEADER>
  <PP_PAW>
    test
  </PP_PAW>
</UPF>
"""

FAKE_A2F_DAT = """\
# a2F.dat : classique Supra-QE (synthetic test data)
# omega(meV)   alpha2F(omega)   lambda(omega)
   0.0    0.0000    0.0000
   5.0    0.0150    0.0200
  10.0    0.0820    0.1100
  15.0    0.0510    0.1800
  20.0    0.0240    0.2150
  25.0    0.0120    0.2400
"""


def _post(client, route: str, payload: dict):
    return client.post(route, data=json.dumps(payload),
                       content_type="application/json")


# ════════════════════════  SECTION 2 : UNIT-TESTS MÉTIER  ════════════════════════


def test_parse_matdyn_lambda_extracts_known_fields():
    """parse_matdyn_lambda doit retourner λ, ω_log (K et cm⁻¹), μ*, Tc McMillan."""
    parsed = supra_api.parse_matdyn_lambda(FAKE_MATDYN_OUT)
    assert parsed["lambda"] == pytest.approx(0.85)
    assert parsed["omega_log_K"] == pytest.approx(412.3)
    assert parsed["mu_star"] == pytest.approx(0.10)
    assert parsed["tc_mcmillan"] == pytest.approx(19.4)


def test_parse_matdyn_lambda_returns_none_for_empty():
    """Un texte vide ne doit lever aucune exception et retourner None partout."""
    parsed = supra_api.parse_matdyn_lambda("")
    assert parsed["lambda"] is None
    assert parsed["omega_log_K"] is None
    assert parsed["tc_mcmillan"] is None


def test_tc_mcmillan_known_value_reproduces_formula():
    """Vérifie la formule McMillan (1968) sur des valeurs de référence."""
    # λ = 0.85, ω_log = 412.3 K, μ* = 0.10 → Tc connu ~ 19.4 K (sortie QE)
    tc = supra_api.tc_mcmillan(0.85, 412.3, 0.10)
    assert tc is not None
    # Recalcul à la main
    expo = -1.04 * (1.0 + 0.85) / (0.85 - 0.10 * (1.0 + 0.62 * 0.85))
    tc_ref = (412.3 / 1.20) * math.exp(expo)
    assert tc == pytest.approx(tc_ref, rel=1e-9)


def test_tc_mcmillan_returns_none_for_invalid_regime():
    """Cas pathologique : λ ≤ μ* → pas de solution physique."""
    assert supra_api.tc_mcmillan(0.05, 200.0, 0.10) is None
    assert supra_api.tc_mcmillan(0.10, 200.0, 0.10) is None


def test_tc_allen_dynes_equals_mcmillan_when_omega2_missing():
    """Sans ω₂, Allen-Dynes doit retomber sur McMillan×f1 (f2=1)."""
    tc_mc = supra_api.tc_mcmillan(1.2, 200.0, 0.10)
    tc_ad = supra_api.tc_allen_dynes(1.2, 200.0, 0.10)
    assert tc_mc is not None and tc_ad is not None
    # f1 > 1 quand λ grand → tc_ad doit être > tc_mc
    assert tc_ad > tc_mc


def test_tc_allen_dynes_uses_omega2_correction():
    """Avec ω₂, le facteur f2 doit corriger à la hausse ou à la baisse."""
    tc_no_omega2 = supra_api.tc_allen_dynes(1.2, 200.0, 0.10)
    # ω₂ >> ω_log → f2 > 1 → Tc plus élevé
    tc_with_omega2 = supra_api.tc_allen_dynes(1.2, 200.0, 0.10, omega_2_K=400.0)
    assert tc_with_omega2 > tc_no_omega2


def test_parse_epw_output_extracts_tc_and_temp_gap_table():
    """Sortie EPW standard : λ, ω_log, tableau (T, Δ) → Tc + gap(0)."""
    parsed = supra_api.parse_epw_output(FAKE_EPW_OUT)
    assert parsed["lambda"]        == pytest.approx(1.20)
    assert parsed["omega_log_K"]   == pytest.approx(220.5)
    assert parsed["tc_K"]          == pytest.approx(19.5)
    assert parsed["gap_meV"]       == pytest.approx(4.123)
    assert parsed["is_anisotropic"] is True
    assert parsed["mu_c"]          == pytest.approx(0.10)
    assert len(parsed["temp_gap"]) == 6


def test_parse_epw_output_returns_defaults_for_empty_text():
    """Sortie vide → tous les champs à None / temp_gap vide (robustesse)."""
    parsed = supra_api.parse_epw_output("")
    assert parsed["lambda"]         is None
    assert parsed["omega_log_K"]    is None
    assert parsed["omega_log_meV"]  is None
    assert parsed["tc_K"]           is None
    assert parsed["gap_meV"]        is None
    assert parsed["mu_c"]           is None
    assert parsed["temp_gap"]       == []
    assert parsed["is_anisotropic"] is None


def test_detect_pseudo_kind_distinguishes_nc_paw_uspp_from_text(tmp_path):
    """Doit classifier correctement les 3 familles NC / USPP / PAW."""
    f_nc = tmp_path / "Nb_NC.upf"
    f_paw = tmp_path / "Nb_PAW.upf"
    f_uspp = tmp_path / "Nb_USPP.upf"
    f_nc.write_text(FAKE_UPF_NC)
    f_paw.write_text(FAKE_UPF_PAW)
    f_uspp.write_text(FAKE_UPF_USPP)
    assert supra_api.detect_pseudo_kind(f_nc) == "NC"
    assert supra_api.detect_pseudo_kind(f_paw) == "PAW"
    assert supra_api.detect_pseudo_kind(f_uspp) == "USPP"


def test_detect_pseudo_kind_returns_missing_for_absent(tmp_path):
    assert supra_api.detect_pseudo_kind(tmp_path / "does_not_exist.upf") == "MISSING"


def test_extract_final_structure_parses_cell_positions_species():
    """Doit extraire correctement CELL_PARAMETERS + ATOMIC_POSITIONS + ATOMIC_SPECIES."""
    struct = supra_api._extract_final_structure(FAKE_VCRELAX_OUT)
    assert struct is not None
    assert struct["nat"] == 2
    assert struct["ntyp"] == 1
    assert struct["cell_unit"] == "alat"
    assert struct["alat"] == pytest.approx(6.50)
    # Structure finale (dernier bloc Begin final coordinates) :
    # les vecteurs de maille sont diagonalisés à 0.98765 (relaxation)
    assert struct["cell_parameters"][0][0] == pytest.approx(0.987654321)
    assert struct["cell_parameters"][1][1] == pytest.approx(0.987654321)
    assert struct["cell_parameters"][2][2] == pytest.approx(0.987654321)
    # ATOMIC_POSITIONS crystal — la fixture utilise 2x "Nb" (symbole pur
    # sans indexation "Nb1") car la regex API impose [A-Za-z]{1,3} lettres
    assert struct["positions_unit"] == "crystal"
    assert len(struct["positions"]) == 2
    assert struct["positions"][0]["sym"] == "Nb"
    assert struct["positions"][1]["sym"] == "Nb"
    # ATOMIC_SPECIES
    assert struct["species"][0]["symbol"] == "Nb"
    assert struct["species"][0]["mass"] == pytest.approx(92.906)
    # Paramètres pwscf remontés
    assert struct["ecutwfc"] == pytest.approx(60.0)


def test_extract_final_structure_returns_none_for_garbage():
    """Si le texte n'a aucun motif reconnu, _extract_final_structure → None."""
    assert supra_api._extract_final_structure("") is None
    assert supra_api._extract_final_structure("lorem ipsum dolor sit amet") is None


# ════════════════════════════  SECTION 3 : ENDPOINTS /api/results/*  ═══════════


def test_api_results_tc_returns_parsed_lambda_omega_and_formulas(client, _isolated_paths):
    """Endpoint /api/results/tc doit appeler parse_matdyn_lambda + tc_mcmillan + allen_dynes."""
    import math as _math
    matd = _isolated_paths["outputs"] / "Nb" / "Nb.matdyn.out"
    matd.parent.mkdir(parents=True, exist_ok=True)
    matd.write_text(FAKE_MATDYN_OUT)

    # REPO_ROOT est monkeypatché sur tmp_path → chemin relatif suffit
    resp = _post(client, "/api/results/tc",
                 {"matdyn_out": "outputs/Nb/Nb.matdyn.out"})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["ok"] is True
    assert data["parsed"]["lambda"] == pytest.approx(0.85)
    assert data["parsed"]["tc_mcmillan"] == pytest.approx(19.4)
    # Recalculé via les formules pures : doit concorder avec mu_star_used = 0.10
    expo = -1.04 * (1.0 + 0.85) / (0.85 - 0.10 * (1.0 + 0.62 * 0.85))
    tc_ref = (412.3 / 1.20) * _math.exp(expo)
    assert data["tc_mcmillan_K"] == pytest.approx(tc_ref, rel=1e-9)
    assert data["tc_allen_dynes_K"] >= data["tc_mcmillan_K"]


def test_api_results_tc_returns_404_for_missing_file(client):
    resp = _post(client, "/api/results/tc", {"matdyn_out": "outputs/nope/Nb.matdyn.out"})
    assert resp.status_code == 404
    assert resp.get_json()["ok"] is False


def test_api_results_epw_extracts_tc_and_temperature_table(client, _isolated_paths):
    epw = _isolated_paths["outputs"] / "Nb" / "Nb.epw.out"
    epw.parent.mkdir(parents=True, exist_ok=True)
    epw.write_text(FAKE_EPW_OUT)

    resp = _post(client, "/api/results/epw", {"epw_out": "outputs/Nb/Nb.epw.out"})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["ok"] is True
    assert data["parsed"]["tc_K"] == pytest.approx(19.5)
    assert data["parsed"]["gap_meV"] == pytest.approx(4.123)
    # 6 lignes (T, Δ) du tableau temp_gap
    assert len(data["parsed"]["temp_gap"]) == 6


def test_api_results_epw_falls_back_to_default_mustar(client, _isolated_paths):
    """Si muc absent du fichier → fallback μ* fourni par l'appelant."""
    epw = _isolated_paths["outputs"] / "Nb" / "Nb.epw.out"
    epw.parent.mkdir(parents=True, exist_ok=True)
    epw.write_text(FAKE_EPW_OUT.replace("muc = 0.10", ""))

    resp = _post(client, "/api/results/epw",
                 {"epw_out": "outputs/Nb/Nb.epw.out", "mu_star": 0.13})
    assert resp.status_code == 200
    assert resp.get_json()["parsed"]["mu_c"] == pytest.approx(0.13)


def test_api_results_alpha2f_parses_three_columns(client, _isolated_paths):
    a2f = _isolated_paths["outputs"] / "Nb" / "classic" / "a2F.dat"
    a2f.parent.mkdir(parents=True, exist_ok=True)
    a2f.write_text(FAKE_A2F_DAT)

    resp = _post(client, "/api/results/alpha2F",
                 {"a2f_file": "outputs/Nb/classic/a2F.dat"})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["ok"] is True
    assert data["n_points"] == 6
    assert data["omega"][0] == pytest.approx(0.0)
    assert data["omega"][-1] == pytest.approx(25.0)
    # a2F croît puis décroît (lambda cumulatif monotone)
    assert data["lambda_w"][-1] >= data["lambda_w"][0]


def test_api_results_compare_finds_classic_and_epw_files(client, _isolated_paths):
    """Doit charger les α²F classic + epw en cherchant dans plusieurs chemins possibles."""
    material = "Nb"
    # a2F classique
    cls = _isolated_paths["outputs"] / material / "classic" / "a2F.dat"
    cls.parent.mkdir(parents=True, exist_ok=True)
    cls.write_text(FAKE_A2F_DAT)
    # a2F EPW
    epw = _isolated_paths["outputs"] / material / "epw" / f"{material}.a2f"
    epw.parent.mkdir(parents=True, exist_ok=True)
    epw.write_text(FAKE_A2F_DAT.replace("alpha2F", "alpha2F_epw"))

    resp = _post(client, "/api/results/compare", {"material": material})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["ok"] is True
    assert data["classic"] is not None
    assert data["epw"] is not None
    assert data["classic"]["n_points"] == 6


# ════════════════════════════  SECTION 4 : I/O — files, jobs, materials, relaxed, pseudo  ═════════


def test_api_file_read_returns_content_for_existing_file(client, _isolated_paths):
    f = _isolated_paths["inputs"] / "test_read.txt"
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text("hello world\n")

    resp = _post(client, "/api/file/read", {"path": "inputs/test_read.txt"})
    assert resp.status_code == 200
    assert resp.get_json()["content"] == "hello world\n"


def test_api_file_read_returns_404_for_missing_file(client):
    resp = _post(client, "/api/file/read", {"path": "inputs/does-not-exist.txt"})
    assert resp.status_code == 404
    assert resp.get_json()["ok"] is False


def test_api_file_read_blocked_for_path_traversal(client):
    """_safe_path refuse tout chemin hors REPO_ROOT → équivalent 404."""
    resp = _post(client, "/api/file/read", {"path": "../../../etc/passwd"})
    assert resp.status_code == 404


def test_api_file_stat_reports_job_done_for_finished_output(client, _isolated_paths):
    """L'interface s'appuie sur job_done pour autoriser l'étape suivante."""
    out = _isolated_paths["outputs"] / "Nb" / "classic" / "Nb.scf.out"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("     convergence has been achieved\n\n   JOB DONE.\n")

    resp = _post(client, "/api/file/stat",
                 {"paths": ["outputs/Nb/classic/Nb.scf.out"]})
    assert resp.status_code == 200
    info = resp.get_json()["results"]["outputs/Nb/classic/Nb.scf.out"]
    assert info["exists"] is True
    assert info["job_done"] is True
    assert info["has_error"] is False


def test_api_file_stat_flags_qe_error_output(client, _isolated_paths):
    out = _isolated_paths["outputs"] / "Nb" / "classic" / "Nb.nscf.out"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("%%%%%%%%%%%%%%%%\n Error in routine c_bands (1):\n too many bands\n")

    resp = _post(client, "/api/file/stat", {"path": "outputs/Nb/classic/Nb.nscf.out"})
    info = resp.get_json()["results"]["outputs/Nb/classic/Nb.nscf.out"]
    assert info["job_done"] is False
    assert info["has_error"] is True


def test_api_file_stat_reports_missing_and_directories(client, _isolated_paths):
    save = _isolated_paths["inputs"] / "Nb" / "epw" / "save"
    save.mkdir(parents=True, exist_ok=True)

    resp = _post(client, "/api/file/stat",
                 {"paths": ["inputs/Nb/epw/save", "inputs/Nb/epw/absent.out",
                            "../../../etc/passwd"]})
    res = resp.get_json()["results"]
    assert res["inputs/Nb/epw/save"]["exists"] is True
    assert res["inputs/Nb/epw/save"]["is_dir"] is True
    assert res["inputs/Nb/epw/absent.out"]["exists"] is False
    assert res["../../../etc/passwd"]["exists"] is False


def test_api_job_returns_404_for_unknown_id(client):
    resp = client.get("/api/job/sqe_999_doesnotexist")
    assert resp.status_code == 404
    assert resp.get_json()["ok"] is False


def test_api_job_returns_known_job_state(client):
    """Insère un job dans JOBS et vérifie l'exposition via /api/job/<id>."""
    supra_api.JOBS["job_test_001"] = {
        "program": "pw.x", "input": "x.in", "output": "x.out",
        "status": "completed", "progress": 100, "message": "OK",
        "start": 0.0, "elapsed": "1.0s", "returncode": 0,
    }
    resp = client.get("/api/job/job_test_001")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["ok"] is True
    assert data["status"] == "completed"
    assert data["program"] == "pw.x"


@pytest.mark.parametrize("query,expected_found,must_contain", [
    ("ExistingMat", True, "ExistingMat"),       # exact match (lowercased)
    ("existingmat", True, "ExistingMat"),       # case-insensitive
    ("inexistant",  False, None),
])
def test_api_materials_search(client, _isolated_paths, query, expected_found, must_contain):
    """Recherche par nom (insensible à la casse, partiel en fallback)."""
    dir_ = _isolated_paths["inputs"] / "ExistingMat"
    dir_.mkdir(parents=True, exist_ok=True)
    (dir_ / "config.json").write_text("{}")

    resp = _post(client, "/api/materials/search", {"material": query})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["found"] is expected_found
    if expected_found:
        assert data["name"] == must_contain
        assert "config.json" in data["top_files"]


def test_api_relaxed_list_finds_job_done(client, _isolated_paths):
    """Doit lister uniquement les matériaux dont le vc-relax.out contient JOB DONE."""
    # 1 matériau terminé (JOB DONE)
    good = _isolated_paths["inputs"] / "DoneMat"
    good.mkdir(parents=True, exist_ok=True)
    (good / "DoneMat.vc-relax.out").write_text(FAKE_VCRELAX_OUT)
    # 1 matériau inachevé
    bad = _isolated_paths["inputs"] / "NotDoneMat"
    bad.mkdir(parents=True, exist_ok=True)
    (bad / "NotDoneMat.vc-relax.out").write_text("running...")

    resp = client.get("/api/relaxed/list")
    assert resp.status_code == 200
    data = resp.get_json()
    names = [item["material"] for item in data["items"]]
    assert "DoneMat" in names
    assert "NotDoneMat" not in names
    assert data["count"] == len(names)


def test_api_relaxed_upload_saves_json_when_job_done(client, _isolated_paths):
    mat = "ValidMat"
    resp = _post(client, "/api/relaxed/upload",
                 {"material": mat, "content": FAKE_VCRELAX_OUT})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["ok"] is True
    saved = _isolated_paths["inputs"] / mat / f"{mat}.vc-relax.out"
    assert saved.is_file()
    struct = json.loads((_isolated_paths["inputs"] / mat / f"{mat}.structure.json").read_text())
    assert struct["nat"] == 2
    assert struct["ntyp"] == 1
    assert struct["cell_parameters"][0][0] == pytest.approx(0.987654321)


@pytest.mark.parametrize("material", ["", "../evil", "name with spaces", "name/with/slash"])
def test_api_relaxed_upload_rejects_invalid_material_name(client, material):
    resp = _post(client, "/api/relaxed/upload",
                 {"material": material, "content": FAKE_VCRELAX_OUT})
    assert resp.status_code == 400, f"matériau {material!r} aurait dû être rejeté"
    assert resp.get_json()["ok"] is False


def test_api_relaxed_upload_rejects_no_jobb_done(client):
    resp = _post(client, "/api/relaxed/upload",
                 {"material": "RunningMat", "content": "in progress"})
    assert resp.status_code == 400
    assert "JOB DONE" in resp.get_json()["error"]


@pytest.mark.parametrize("name", [
    "Nb.upf",
    "Test_NC.UPF",           # extension en majuscules OK
    "Nb-v1.0.upf",
])
def test_api_pseudo_upload_accepts_valid_name(client, _isolated_paths, name):
    resp = _post(client, "/api/pseudo/upload",
                 {"name": name, "content": FAKE_UPF_NC})
    assert resp.status_code == 200, f"{name!r} aurait dû être accepté"
    data = resp.get_json()
    assert data["ok"] is True
    assert data["kind"] == "NC"   # détecté NC alors qu'on a uploadé un contenu NC
    saved = _isolated_paths["pseudos"] / name
    assert saved.is_file()


@pytest.mark.parametrize("name", [
    "../etc/passwd",       # path traversal
    "evil.sh",             # mauvaise extension
    "no_extension",
    ".upf",                # vide
    "",                    # vide
    "../../pseudos/X.upf",
])
def test_api_pseudo_upload_rejects_invalid_name(client, _isolated_paths, name):
    resp = _post(client, "/api/pseudo/upload",
                 {"name": name, "content": FAKE_UPF_NC})
    assert resp.status_code == 400, f"{name!r} aurait dû être rejeté"
    assert resp.get_json()["ok"] is False


def test_api_pseudo_upload_warns_on_paw(client, _isolated_paths):
    """Upload d'un pseudo PAW → warning 'incompatible avec ph.x'."""
    resp = _post(client, "/api/pseudo/upload",
                 {"name": "Nb_PAW.upf", "content": FAKE_UPF_PAW})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["kind"] == "PAW"
    assert data["warning"] is not None
    assert "ph.x" in data["warning"]


def test_api_pseudo_upload_rejects_empty_content(client):
    resp = _post(client, "/api/pseudo/upload",
                 {"name": "Nb.upf", "content": ""})
    assert resp.status_code == 400
    assert resp.get_json()["ok"] is False


def test_api_pseudo_list_returns_uploaded_files(client, _isolated_paths):
    """Liste les pseudos uploadés avec détection NC/PAW/USPP."""
    (_isolated_paths["pseudos"] / "A_NC.upf").write_text(FAKE_UPF_NC)
    (_isolated_paths["pseudos"] / "B_PAW.upf").write_text(FAKE_UPF_PAW)

    resp = client.get("/api/pseudo/list")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["ok"] is True
    items = {item["name"]: item["kind"] for item in data["items"]}
    assert items.get("A_NC.upf") == "NC"
    assert items.get("B_PAW.upf") == "PAW"


# ════════════════════════════  SECTION 5 : non-régression  ═════════════════════════

def test_endpoints_do_not_500_on_malformed_json(client):
    """Aucun endpoint ne doit retourner 500 sur JSON mal formé (force=True fait leniency)."""
    resp = client.post("/api/grid/validate", data="not-json",
                       content_type="application/json")
    assert 200 <= resp.status_code < 500


def test_api_results_compare_returns_null_when_no_alpha2f_found(client, _isolated_paths):
    """/api/results/compare doit retourner 200 avec classic=None/epw=None si aucun fichier."""
    # _isolated_paths.output est encore vide à ce stade du test
    resp = _post(client, "/api/results/compare", {"material": "GhostMaterial"})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["ok"] is True
    assert data["classic"] is None
    assert data["epw"] is None


def test_api_materials_search_rejects_missing_material_field(client):
    """Champ `material` absent → 400 (le contrat doit être strict)."""
    resp = _post(client, "/api/materials/search", {})
    assert resp.status_code == 400
    assert resp.get_json()["ok"] is False


def test_api_relaxed_upload_rejects_empty_content(client):
    """Upload vide — doit être refusé tôt (avant l'extraction)."""
    resp = _post(client, "/api/relaxed/upload",
                 {"material": "OkMat", "content": ""})
    assert resp.status_code == 400
    assert "vide" in resp.get_json()["error"].lower()

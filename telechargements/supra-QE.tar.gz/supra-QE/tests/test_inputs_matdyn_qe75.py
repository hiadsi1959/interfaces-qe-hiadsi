"""Garde-fous : générateurs d'inputs classiques compatibles QE 7.5."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INPUTS_JS = ROOT / "interface" / "supra_inputs.js"


def _matdyn_fn_source() -> str:
    text = INPUTS_JS.read_text(encoding="utf-8")
    start = text.index("function genererMatdyn")
    end = text.index("function genererAlpha2F", start)
    return text[start:end]


def test_matdyn_has_no_illegal_qe75_keys():
    """electron_phonon / fila2F / mu ne font pas partie du namelist matdyn.x."""
    src = _matdyn_fn_source()
    assert "electron_phonon" not in src
    assert "fila2F" not in src
    assert "mu_star" not in src or "appliqué dans l'onglet" in src  # commentaire OK
    assert "    mu " not in src and "\n    mu=" not in src
    assert "la2F" in src
    assert "flfrc" in src
    assert "DeltaE" in src


def test_alpha2f_uses_inputa2f_namelist():
    text = INPUTS_JS.read_text(encoding="utf-8")
    start = text.index("function genererAlpha2F")
    end = text.index("function genererEPW", start)
    src = text[start:end]
    assert "INPUTA2F" in src
    assert "nfreq" in src
    assert "deg_smearing" not in src
    assert "fila2Fout" not in src


def test_bloc_commun_does_not_hardcode_angstrom_only():
    text = INPUTS_JS.read_text(encoding="utf-8")
    # Unité dynamique cell_unit — plus de « CELL_PARAMETERS angstrom » figé
    assert "CELL_PARAMETERS ${qeUnit}" in text or "CELL_PARAMETERS ${" in text

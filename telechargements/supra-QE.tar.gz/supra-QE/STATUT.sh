#!/usr/bin/env bash
# Affiche le statut de l'API supra-QE
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "$HERE/config.env" ]]; then
    # shellcheck disable=SC1091
    source "$HERE/config.env"
fi
TMP_DIR="${SUPRA_TMP_DIR:-$HERE/tmp}"
PIDFILE="$TMP_DIR/supra-qe.pid"
PORT="${SUPRA_QE_PORT:-8765}"
HOST="${SUPRA_QE_HOST:-127.0.0.1}"
# 0.0.0.0 n'est pas joignable en client HTTP — comme DEMARRER.sh
HEALTH_HOST="$HOST"
[[ "$HOST" == "0.0.0.0" || "$HOST" == "::" ]] && HEALTH_HOST="127.0.0.1"

if [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    echo "[supra-qe] PID $(cat "$PIDFILE") actif"
else
    echo "[supra-qe] aucun PID actif"
fi

if curl -fs "http://$HEALTH_HOST:$PORT/health" 2>/dev/null; then
    echo
else
    echo "[supra-qe] /health injoignable sur http://$HEALTH_HOST:$PORT"
fi

#!/usr/bin/env bash
# ==========================================================================
#  Supra-QE — Arrêt de l'API
# ==========================================================================
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "$HERE/config.env" ]]; then
    # shellcheck disable=SC1091
    source "$HERE/config.env"
fi
TMP_DIR="${SUPRA_TMP_DIR:-$HERE/tmp}"
PIDFILE="$TMP_DIR/supra-qe.pid"

if [[ -f "$PIDFILE" ]]; then
    PID="$(cat "$PIDFILE")"
    if kill -0 "$PID" 2>/dev/null; then
        echo "[supra-qe] arrêt API (PID $PID)"
        kill "$PID"
        sleep 1
        kill -9 "$PID" 2>/dev/null || true
    fi
    rm -f "$PIDFILE"
fi

# Fallback : tue tout processus python lançant supra_api.py
pkill -f 'supra-QE/api/supra_api.py' 2>/dev/null || true
echo "[supra-qe] arrêté."

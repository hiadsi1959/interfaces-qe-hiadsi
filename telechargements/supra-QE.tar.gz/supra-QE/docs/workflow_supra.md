# Workflow détaillé — Supra-QE

Module **autonome** pour le calcul de la température critique supraconductrice
Tᶜ à partir d'une structure déjà relaxée.

---

## Vue d'ensemble

```
[Structure Relaxée]  →  1. SCF dense  →  2. NSCF dense  →  3. ph.x (DFPT)  →  4. q2r.x  →  5. matdyn.x  →  Tᶜ
```

Chaque étape est strictement séquentielle : la suivante ne démarre que si
`JOB DONE` est trouvé dans la sortie de la précédente.

---

## Étape 0 — Structure relaxée

Entrée : un fichier `<material>.vc-relax.out` (ou `<material>.relax.out`)
terminé. L'interface extrait automatiquement :

- `ibrav`, `celldm(1)` (alat),
- `CELL_PARAMETERS`,
- `ATOMIC_SPECIES` (avec pseudos),
- `ATOMIC_POSITIONS`,
- `ecutwfc`, `ecutrho`.

Fichier généré côté serveur : `inputs/<material>/<material>.vc-relax.out`
et `inputs/<material>/<material>.structure.json`.

---

## Étape 1 — SCF métallique (`pw.x`)

**Particularité métallique** : occupation par smearing.

| Paramètre   | Valeur conseillée                              |
|-------------|------------------------------------------------|
| `smearing`  | `mv` (Marzari-Vanderbilt) ou `mp` (Methfessel-Paxton) |
| `degauss`   | 0.01 – 0.02 Ry                                 |
| `ecutwfc`   | ≥ 60 Ry (selon le pseudo NC)                   |
| `ecutrho`   | 4×–8× `ecutwfc`                                |
| `K_POINTS`  | grille standard, ex. **8 × 8 × 8**             |
| `conv_thr`  | 1.0d-10                                        |

Sortie : `<material>.scf.out` (+ `<material>_outdir/`).

---

## Étape 2 — NSCF dense (`pw.x`)

**But** : grille `k` très dense pour cartographier précisément la surface
de Fermi. Sur cette grille, `la2F = .true.` est activé pour préparer
le couplage électron-phonon.

| Paramètre   | Valeur conseillée                              |
|-------------|------------------------------------------------|
| `calculation` | `nscf`                                       |
| `K_POINTS`  | **16³**, **24³**, voire **32³**                |
| `la2F`      | `.true.`                                       |
| `conv_thr`  | 1.0d-10                                        |

Sortie : `<material>.nscf.out`.

---

## Étape 3 — Phonons + couplage e-p (`ph.x`)

**Cœur du calcul.** Matrice dynamique + éléments de matrice du couplage
électron-phonon sur la grille `q`.

Paramètres-clés (`&INPUTPH`) :

```fortran
fildvscf        = 'aldv'
electron_phonon = 'interpolated'   ! ou 'simple'
tr2_ph          = 1.0d-12
ldisp           = .true.
nq1, nq2, nq3   = 4, 4, 4          ! q-grille modeste
```

> ⚠️ **Norm-Conserving uniquement.** USPP/PAW sont refusés par l'interface :
> le calcul de `ph.x` ne supporte pas le couplage e-p sur ces pseudos.

Sortie : `<material>.ph.out` + `matdyn0`, `matdyn1`, … (fichiers de matrice
dynamique par point q).

### Convergence asymétrique K vs Q

| Aspect          | Grille `k` (NSCF) | Grille `q` (ph.x) |
|-----------------|-------------------|-------------------|
| But             | surface de Fermi  | dispersions de phonons |
| Taille typique  | 16³ – 32³         | 4³ – 6³           |
| Coût            | linéaire          | très non-linéaire |

L'interface impose : **chaque axe de `k` doit être un multiple entier
de l'axe correspondant de `q`** (ratio ≥ 2, ≥ 4 conseillé).

---

## Étape 4 — Post-traitement (`q2r.x` + `matdyn.x`)

### 4a. `q2r.x`

Transforme les matrices dynamiques de l'espace réciproque (`matdyn*`) en
constantes de force interatomiques en espace réel (fichier `ifc.fc`).

```fortran
&INPUT
   fildyn = 'matdyn'
   flfrc  = 'ifc.fc'
   zasr   = 'simple'
/
```

### 4b. `matdyn.x`

Calcule la DOS phononique et, avec `la2F = .true.`, interpole α²F(ω) / λ
à partir des coefficients e–p (QE 7.x).  
**Namelist** : uniquement les clés de `matdyn.x` (`flfrc`, `asr`, `dos`,
`nk*`, `DeltaE`, `la2F`, `amass`, …).  
Ne pas mettre `electron_phonon`, `fila2F` ni `mu` (clés `ph.x` / `lambda.x`
— refusées par le namelist QE 7.5).

```fortran
&INPUT
   asr     = 'simple'
   flfrc   = 'ifc.fc'
   dos     = .true.
   nk1 = 8, nk2 = 8, nk3 = 8   ! dense pour intégrer α²F
   DeltaE  = 1.0
   la2F    = .true.
/
```

μ* et Tᶜ (McMillan / Allen–Dynes) sont calculés dans l’**onglet Résultats**
à partir de α²F / λ extraits des sorties.

### Sortie attendue

Fichiers type `a2F.dos`, `elph.inp_lambda.*`, et dans le journal matdyn
des lignes `lambda` / `<log w>`. Tᶜ(μ*) : bouton Explorer dans l’interface.

### Formules

**McMillan (1968)** :

$$
T_c = \frac{\omega_{\log}}{1.20}\,\exp\!\left[-\frac{1.04(1+\lambda)}{\lambda - \mu^\*(1+0.62\lambda)}\right]
$$

**Allen–Dynes (1975)** : ajoute les facteurs correctifs `f1`, `f2`
dépendant de λ, μ* et ω₂/ω_log.

---

## Paramètres pré-remplis par défaut

| Paramètre              | Valeur par défaut | Pourquoi                          |
|------------------------|-------------------|-----------------------------------|
| `smearing`             | `mv`              | meilleur compromis pour les métaux|
| `degauss`              | 0.02 Ry           | standard supra conventionnel      |
| `k_scf`                | 8 × 8 × 8         | suffisant pour la densité SCF     |
| `k_nscf`               | 24 × 24 × 24      | dense pour la surface de Fermi    |
| `q_phonon`             | 4 × 4 × 4         | équilibre coût / précision        |
| `tr2_ph`               | 1.0d-12           | convergence stricte des phonons   |
| `electron_phonon`      | `interpolated`    | recommandation actuelle de QE     |
| `μ*`                   | 0.10              | standard littérature (95 %)       |
| `ecutwfc / ecutrho`    | hérités du vc-relax | cohérence avec la relaxation    |

---

## Sécurité et autonomie

`supra-QE` est totalement **indépendant** des autres projets :

- pseudos uniquement dans `supra-QE/pseudos/` (uploadables via l'interface),
- outputs dans `supra-QE/outputs/`,
- inputs générés dans `supra-QE/inputs/<material>/`,
- aucun chemin n'est lu en dehors du dossier `supra-QE/`.

---

## 🌟 Méthode alternative — EPW (Wannier + Éliashberg)

Sélectionnable directement dans le sélecteur en haut de l'onglet **Configuration**.
Cette méthode remplace la chaîne `q2r.x → matdyn.x` par un seul programme
`epw.x` qui :

1. **Wannierise** les fonctions d'onde du NSCF en fonctions de Wannier localisées
   (appelle `wannier90` en interne),
2. **Transforme** les matrices électron-phonon dans la base de Wannier,
3. **Interpole** sur des grilles K et Q ultra-denses (par défaut 40³),
4. Résout les **équations d'Éliashberg** (isotrope ou anisotrope) et donne
   directement Tᶜ et le gap Δ.

### Workflow EPW

```
[Structure relaxée] → 1. SCF → 2. ph.x (dvscf + dyn) → [regroupement save/] → 3. NSCF coarse + nbnd élevé → 4. epw.x → Tᶜ + Δ
```

L'ordre `ph.x` **avant** `nscf` est celui de la documentation EPW : `ph.x` doit
repartir des fonctions d'onde SCF, or le NSCF les écrase dans `outdir`. Entre
`ph.x` et `epw.x`, les matrices dynamiques et les `dvscf` doivent être regroupés
dans un dossier `save/` (script `pp.py` livré avec EPW).

### Spécificités à respecter

| Étape | Particularité EPW                                                    |
|-------|----------------------------------------------------------------------|
| ph.x  | lancé **juste après le SCF**, `fildvscf` sauvegardé, **sans** `electron_phonon=interpolated` |
| save/ | `python3 $EPW/bin/pp.py` regroupe `*.dyn*` et `_ph0/*.dvscf*` — lu par `dvscf_dir` |
| NSCF  | lancé **après** `ph.x` : grille `k` **modeste et uniforme** (6³ ou 8³), `nbnd` **élevé** |
| epw.x | `nk1,nk2,nk3` == grille NSCF, `nq1,nq2,nq3` == grille ph.x            |

### Fenêtres de Wannier (énergies en eV, EF = 0)

| Paramètre       | Valeur par défaut | Rôle                                              |
|-----------------|-------------------|---------------------------------------------------|
| `dis_win_min`   | −3.0              | borne inférieure de la fenêtre de désintrication  |
| `dis_win_max`   | 15.0              | borne supérieure (doit englober assez de bandes)  |
| `dis_froz_min`  | −3.0              | bandes **gelées** entièrement incluses            |
| `dis_froz_max`  | 8.0               | bornes de la fenêtre gelée                         |
| `nbndsub`       | 5                 | nombre de fonctions de Wannier finales            |
| `proj(:)`       | `Xx:sp3d2`        | projections initiales (1 par espèce)              |

### Équations d'Éliashberg

| Paramètre       | Valeur par défaut | Rôle                                              |
|-----------------|-------------------|---------------------------------------------------|
| `liso` / `laniso` | `liso=.true.`   | isotrope (rapide) vs anisotrope (gap par bande)   |
| `muc`           | 0.10              | μ* écranter (identique au classique)              |
| `fsthick`       | 0.4 eV            | fenêtre autour de EF utilisée pour les e-p        |
| `degaussw`      | 0.05 eV           | smearing électronique                              |
| `degaussq`      | 0.5 meV           | smearing phonon                                    |
| `nkf, nqf`      | 40 × 40 × 40      | grilles fines d'interpolation                      |
| `nstemp`        | 30                | nombre de températures balayées                    |
| `temps`         | 30 K              | température max                                    |

### Sortie EPW

`<material>.epw.out` contient typiquement :

```
Electron-phonon coupling strength = 0.85
omega_log = 412.3 K
Temperature   30.000 K   max Delta = 0.000 meV
Temperature   25.000 K   max Delta = 1.234 meV
...
Temperature    1.000 K   max Delta = 2.987 meV
Tc = 28.4 K
```

L'interface extrait automatiquement λ, ω_log, Tᶜ et le gap Δ(T~0), et
trace la courbe Δ(T) dans l'onglet **Résultats Tᶜ**.

---

## 🆚 Comparatif classique vs EPW

| Aspect                       | Classique (matdyn) | EPW                       |
|------------------------------|--------------------|---------------------------|
| Coût total                   | Modéré             | Élevé (Wannier + Eliashberg) |
| NSCF                         | très dense (24³)   | coarse + nbnd élevé        |
| Précision Tᶜ                 | bonne (McMillan)   | excellente (Éliashberg)    |
| Gap supraconducteur Δ        | non                | **oui** (isotrope/anisotrope) |
| Adapté aux matériaux         | conventionnels     | conventionnels **et** complexes |
| Sensibilité aux fenêtres     | aucune             | forte (Wannier)            |
| Publication-ready            | rapports / TP      | publications haut niveau   |

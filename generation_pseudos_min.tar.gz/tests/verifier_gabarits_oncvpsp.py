#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Validation complète des gabarits ONCV dans le binaire oncvpsp.x.

Pour chaque gabarit (.dat / .in) des dossiers oncv_templates_* :
  1. exécution réelle de oncvpsp.x (stdin = gabarit, psfile normalisé « both »
     comme la cible Quantum ESPRESSO de l'API) ;
  2. contrôle de sortie : code retour 0, bloc pseudopotentiel produit
     (UPF XML ou UPF v1 « Begin PSP_UPF » + psp8 « END_PSP »),
     absence d'erreur fatale (Fortran runtime / ERROR STOP / lschfb / sratom) ;
  3. ghosts : 0 × GHOST(-) exigé, GHOST(+) signalé (les gabarits officiels
     PseudoDojo en comportent parfois) ;
  4. cohérence de structure : atsym connu, Z déclaré cohérent, nc+nv lignes
     n,l,f, somme des occupations = Z, iexc = 4 (PBE).

  python3 tests/verifier_gabarits_oncvpsp.py                     # tout
  python3 tests/verifier_gabarits_oncvpsp.py --dir lanthanide    # un dossier
  python3 tests/verifier_gabarits_oncvpsp.py --element La Lu     # un sous-ensemble
  python3 tests/verifier_gabarits_oncvpsp.py --jobs 4 --timeout 180
"""
from __future__ import annotations

import argparse
import concurrent.futures
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

BIN_CANDIDATES = (
    ROOT / "bin" / "oncvpsp.x",
    ROOT / "third_party" / "oncvpsp" / "bin" / "oncvpsp.x",
)
LIB_DIR = ROOT / "lib"
TEMPLATE_EXTS = (".dat", ".in")

# Ligne atsym : symbole, z, nc, nv, iexc (psfile facultatif)
ATOM_RE = re.compile(
    r"#\s*ATOM AND REFERENCE[\s\S]*?\n\s*([A-Za-z]{1,2})\s+"
    r"([\d.]+)\s+(\d+)\s+(\d+)\s+(-?\d+)"
)
# Fin de la section « ATOM AND REFERENCE » (lmax ou PSEUDOPOTENTIAL)
SECTION_RE = re.compile(r"#\s*(?:PSEUDOPOTENTIAL|LMAX)", re.I)
# Ligne n, l, f [énergie]
ELEC_RE = re.compile(
    r"^\s*(\d+)\s+(\d)\s+([\d.]+)\s*(?:[-+]?[\d.]+(?:[EeDd][-+]?\d+)?)?\s*$", re.M
)

FATAL_RES = (
    re.compile(r"Fortran runtime error", re.I),
    re.compile(r"ERROR STOP", re.I),
    re.compile(r"lschfb convergence ERROR", re.I),
    re.compile(r"sratom\b[\s\S]{0,60}?ERROR", re.I),
    re.compile(r"Intel oneMKL FATAL ERROR", re.I),
    re.compile(r"forrtl:\s*severe", re.I),
    re.compile(r"^\s*End of file\s*$", re.I | re.M),
)
PSEUDO_RE = re.compile(r"<UPF version|Begin PSP_UPF|END_PSP", re.I)
UPF_RE = re.compile(r"<UPF version|Begin PSP_UPF", re.I)
GHOST_MINUS_RE = re.compile(r"GHOST\(\-\)")
GHOST_PLUS_RE = re.compile(r"GHOST\(\+\)")


def find_bin() -> Path | None:
    for c in BIN_CANDIDATES:
        if c.is_file():
            return c
    import shutil

    w = shutil.which("oncvpsp.x")
    return Path(w) if w else None


def build_env() -> dict[str, str]:
    """lib/ en fin de LD_LIBRARY_PATH : le MKL système garde la priorité si présent."""
    env = os.environ.copy()
    env.setdefault("OMP_NUM_THREADS", "1")
    env.setdefault("MKL_NUM_THREADS", "1")
    if LIB_DIR.is_dir():
        parts = [p for p in env.get("LD_LIBRARY_PATH", "").split(":") if p]
        if str(LIB_DIR) not in parts:
            parts.append(str(LIB_DIR))
        env["LD_LIBRARY_PATH"] = ":".join(parts)
    return env


def normalize_for_qe(text: str) -> str:
    """psfile → « both » (cible QE), comme l'API avant le run."""
    try:
        import api_pseudos_standalone as api

        norm, _warns, _ps = api._normalize_oncv_dat_for_target(text, "qe")
        return norm
    except Exception:
        return re.sub(r"\bpsp8\b", "both", text, count=1)


def check_structure(text: str) -> list[str]:
    """Cohérence interne du gabarit (indépendante du run)."""
    errs: list[str] = []
    m = ATOM_RE.search(text)
    if not m:
        return ["bloc « ATOM AND REFERENCE » illisible"]
    sym, z, nc, nv, iexc = m.group(1), float(m.group(2)), int(m.group(3)), int(m.group(4)), int(m.group(5))
    sym = sym[0].upper() + sym[1:].lower()
    try:
        from pseudo_auto_inputs import atomic_number

        z_real = int(atomic_number(sym))
        if abs(z_real - z) > 0.01:
            errs.append(f"atsym {sym} : Z déclaré {z:.0f} ≠ {z_real}")
    except Exception as e:
        errs.append(f"atsym {sym} inconnu ({e})")
    if iexc != 4:
        errs.append(f"iexc={iexc} (attendu 4 = PBE)")
    after = text[m.end():]
    stop = SECTION_RE.search(after)
    elec = ELEC_RE.findall(after[: stop.start()] if stop else after)
    if len(elec) != nc + nv:
        errs.append(f"{len(elec)} lignes n,l,f ≠ nc+nv={nc + nv}")
    try:
        q = sum(float(o) for _, _, o in elec)
        if abs(q - z) > 0.01:
            errs.append(f"somme occupations {q} ≠ Z={z:.0f}")
    except ValueError:
        errs.append("occupations illisibles")
    return errs


def run_one(path: Path, bin_path: Path, timeout: int) -> dict:
    t0 = time.time()
    res: dict = {"path": path, "sym": path.stem, "rc": None, "upf": False,
                 "pseudo": False, "ghost_plus": 0, "ghost_minus": 0,
                 "fatal": None, "struct": [], "dt": 0.0, "err": None}
    text = path.read_text(encoding="utf-8", errors="replace")
    # symbole lisible depuis le nom (Lu_Lu-sp → Lu, 60_Nd_GHOST → Nd)
    mm = re.search(r"([A-Z][a-z]?)(?![a-z])", path.stem.replace("_", " "))
    res["sym"] = mm.group(1) if mm else path.stem
    res["struct"] = check_structure(text)
    content = normalize_for_qe(text)
    try:
        with tempfile.TemporaryDirectory() as td:
            # stdin = fichier ouvert (seekable), comme « oncvpsp.x < f.dat » :
            # un tuyau déclenche « Fortran runtime error » (backspace refusé).
            infile = Path(td) / "input.dat"
            infile.write_text(content, encoding="utf-8")
            with open(infile, "r", encoding="utf-8", errors="replace") as inf:
                proc = subprocess.run(
                    [str(bin_path)], stdin=inf, capture_output=True, text=True,
                    timeout=timeout, cwd=td, env=build_env(),
                )
        out = (proc.stdout or "") + "\n" + (proc.stderr or "")
        res["rc"] = proc.returncode
        res["pseudo"] = bool(PSEUDO_RE.search(out))
        res["upf"] = bool(UPF_RE.search(out))
        res["ghost_plus"] = len(GHOST_PLUS_RE.findall(out))
        res["ghost_minus"] = len(GHOST_MINUS_RE.findall(out))
        for rx in FATAL_RES:
            if rx.search(out):
                res["fatal"] = rx.pattern
                break
    except subprocess.TimeoutExpired:
        res["err"] = f"TIMEOUT {timeout}s"
    except Exception as e:  # noqa: BLE001
        res["err"] = str(e)
    res["dt"] = time.time() - t0
    return res


def failures_of(r: dict) -> list[str]:
    f: list[str] = []
    if r["err"]:
        f.append(r["err"])
    if r["rc"] not in (0, None) and not r["err"]:
        f.append(f"code retour {r['rc']}")
    if r["err"] is None and not r["pseudo"]:
        f.append("aucun pseudopotentiel produit")
    if r["err"] is None and not r["upf"]:
        f.append("UPF absent (psfile=both attendu)")
    if r["fatal"]:
        f.append(f"erreur fatale « {r['fatal']} »")
    if r["ghost_minus"]:
        f.append(f"{r['ghost_minus']} × GHOST(-)")
    f.extend(r["struct"])
    return f


def collect(dirs: list[Path], elements: list[str]) -> list[Path]:
    out: list[Path] = []
    for d in dirs:
        if not d.is_dir():
            continue
        for p in sorted(d.iterdir()):
            if not p.is_file() or p.suffix.lower() not in TEMPLATE_EXTS:
                continue
            if elements and not any(e.lower() in p.stem.lower() for e in elements):
                continue
            out.append(p)
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--dir", action="append", default=[],
                    help="restreindre à un dossier (ex. lanthanide, 3d, actinide)")
    ap.add_argument("--element", nargs="*", default=[], help="restreindre à des éléments")
    ap.add_argument("--jobs", type=int, default=min(4, os.cpu_count() or 1))
    ap.add_argument("--timeout", type=int, default=180)
    ap.add_argument("--include-tests-data", action="store_true",
                    help="inclure data/oncvpsp_tests_data/ (fichiers officiels QE)")
    args = ap.parse_args()

    bin_path = find_bin()
    if bin_path is None:
        print("oncvpsp.x introuvable (bin/, third_party/, PATH).", file=sys.stderr)
        return 1

    dirs = sorted(ROOT.glob("oncv_templates_*"))
    if args.dir:
        dirs = [d for d in dirs if any(a.lower() in d.name.lower() for a in args.dir)]
    if args.include_tests_data:
        dirs.append(ROOT / "data" / "oncvpsp_tests_data")

    files = collect(dirs, args.element)
    if not files:
        print("Aucun gabarit à valider.", file=sys.stderr)
        return 1

    print(f"Validation ONCVPSP — {bin_path}")
    print(f"  {len(files)} gabarits, {len(dirs)} dossiers, {args.jobs} job(s), timeout {args.timeout}s")
    print("  (psfile normalisé « both » = cible Quantum ESPRESSO)")
    print("-" * 78)

    t0 = time.time()
    results: list[dict] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.jobs)) as ex:
        for r in ex.map(lambda p: run_one(p, bin_path, args.timeout), files):
            results.append(r)
            fails = failures_of(r)
            tag = "OK  " if not fails else "FAIL"
            note = ""
            if r["ghost_plus"]:
                note = f"  ⚠ GHOST(+)=×{r['ghost_plus']}"
            print(f"  [{tag}] {r['sym']:<4} {r['path'].relative_to(ROOT)!s:<40} "
                  f"rc={r['rc']} upf={'y' if r['upf'] else 'n'} "
                  f"ghost(-)={r['ghost_minus']} {r['dt']:5.1f}s{note}")
            for msg in fails:
                print(f"         ✗ {msg}")

    hard = [r for r in results if failures_of(r)]
    warns = [r for r in results if not failures_of(r) and r["ghost_plus"]]
    print("-" * 78)
    print(f"Résultat : {len(results) - len(hard)}/{len(results)} OK — "
          f"{len(hard)} échec(s), {len(warns)} avertissement(s) GHOST(+), "
          f"{time.time() - t0:.0f}s")
    if warns:
        print("GHOST(+) (non bloquant, présent dans les gabarits officiels) :")
        for r in warns:
            print(f"  - {r['sym']} ({r['path'].relative_to(ROOT)}) : ×{r['ghost_plus']}")
    if hard:
        print("Échecs :")
        for r in hard:
            print(f"  - {r['sym']} ({r['path'].relative_to(ROOT)}) : {'; '.join(failures_of(r))}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

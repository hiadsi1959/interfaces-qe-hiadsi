#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Validation physique des UPF générés (pw.x) : convergence, fantômes, r_c.

Ce que le test mesure, concrètement :

1. **Convergence** — balayage `ecutwfc` sur un solide de référence, énergie
   totale SCF relue dans la sortie pw.x. On retient le plus petit `ecutwfc` tel
   que |E(ecut) − E(ecut_max)| < 1 mRy/atome, puis < 0.1 mRy/atome.
   Un UPF « dur » (r_c trop petit) sort avec un ecut de convergence très
   supérieur à l'ecut suggéré → signalé.

2. **Bandes fantômes** — deux calculs à des `ecutwfc` différents (ecut de
   convergence et 1.5×) : les états physiques sont stables (< 0.2 eV de
   déplacement), un état fantôme dérive de plusieurs eV. Les avertissements
   « ghost » / « wellstate » du log du générateur sont aussi relus quand le
   log est fourni (`--log`).

3. **r_c** — rayons de coupure lus dans l'en-tête UPF (ou dans `--input` pour
   APE / ld1.x) et confrontés au verdict de convergence : r_c trop petit se
   traduit par un ecut de convergence anormalement élevé.

Usage ::
    python3 tests/validation_physique_pseudos.py pseudos/Si.pbe-nc.UPF
    python3 tests/validation_physique_pseudos.py Si Fe Eu Am
    python3 tests/validation_physique_pseudos.py --all-pseudos
    python3 tests/validation_physique_pseudos.py Si --json logs/validation_physique.json

Sortie : code 0 si tous les UPF testés convergent sans fantôme, 1 sinon.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# Verdicts
GHOST_SHIFT_EV = 0.20          # au-delà : état instable → fantôme suspect
CONV_TOL_RY = 1.0e-3           # 1 mRy/atome
CONV_TOL_TIGHT_RY = 1.0e-4     # 0.1 mRy/atome
PW_TIMEOUT_S = 120


def _sa_log_fatal_errors(combined: str) -> list[str]:
    """Compatibilité avec l’API standalone : redirige vers la vraie implémentation locale si disponible."""
    try:
        from api_pseudos_standalone import _sa_log_fatal_errors as _api_fatal
        return _api_fatal(combined)
    except Exception:
        patterns = (
            (r'input_dataset:\s*error', 'Erreur entrée ATOMPAW (input_dataset).'),
            (r'rc\(Vloc\)\s+is\s+missing', 'Rayons de coupure ATOMPAW incomplets (rc Vloc).'),
            (r'UPF file not created', 'ATOMPAW n\'a pas écrit de UPF (cœur+nhat négatif : réduisez rc_core ou changez la valence).'),
            (r'MPI_Abort|application called MPI_Abort', 'Calcul ld1.x interrompu (MPI_Abort).'),
            (r'Fatal Error', 'APE arrêté (erreur fatale dans le log).'),
            (r'exceeded max number of iterations', 'APE : itérations GSL épuisées — augmentez r_c ou changez de générateur.'),
            (r'Program will stop', 'ONCV arrêté (entrée ou optimisation).'),
        )
        found: list[str] = []
        for pat, msg in patterns:
            if re.search(pat, combined or '', re.IGNORECASE):
                found.append(msg)
        return found


# Structures de référence : cubique simple, paramètre de maille en Å.
# Sert uniquement à faire tourner pw.x sur une densité réaliste ; la valeur
# exacte n'a pas d'incidence sur la convergence en ecut.
A_SC = {
    "H": 2.6, "C": 3.6, "N": 3.2, "O": 3.0, "F": 3.2, "Na": 4.2, "Mg": 4.5,
    "Al": 4.05, "Si": 5.43, "P": 4.5, "S": 4.5, "Cl": 4.2, "K": 5.0, "Ca": 4.5,
    "Ti": 3.3, "V": 3.0, "Cr": 2.9, "Mn": 2.9, "Fe": 2.87, "Co": 2.8,
    "Ni": 2.8, "Cu": 2.85, "Zn": 2.8, "Ga": 4.3,
}
A_SC_DEFAULT_3D = 3.0
A_SC_DEFAULT_LN = 4.6
A_SC_DEFAULT_AN = 4.0
A_SC_DEFAULT = 3.6


# ────────────────────────────────────────────────────────────────────────────
# Outils
# ────────────────────────────────────────────────────────────────────────────

def resolve_pw() -> str | None:
    for cand in (
        os.environ.get("PW_BIN"),
        ROOT / "bin" / "pw.x",
        ROOT / "third_party" / "qe" / "bin" / "pw.x",
    ):
        if cand and Path(cand).is_file() and os.access(cand, os.X_OK):
            return str(cand)
    return shutil.which("pw.x")


def _read_header(upf: Path, n_lines: int = 400) -> str:
    try:
        with upf.open("r", encoding="utf-8", errors="replace") as fh:
            return "".join(next(fh) for _ in range(n_lines))
    except (OSError, StopIteration):
        return ""


def parse_upf_meta(upf: Path) -> dict:
    head = _read_header(upf)
    low = head.lower()
    if 'pseudo_type="paw"' in low or "pseudo_type='paw'" in low or "pseudo_type=paw" in low:
        ptype = "PAW"
    elif "ultrasoft" in low or "pseudo_type=\"us\"" in low:
        ptype = "US"
    else:
        ptype = "NC"
    z = None
    for pat in (
        r"z_valence\s*=\s*[\"']?([0-9.eE+-]+)",     # en-tête v2
        r"^\s*([0-9.]+)\s+Z valence",                # en-tête v1 (APE)
    ):
        m = re.search(pat, head, re.I | re.M)
        if m:
            try:
                z = float(m.group(1))
            except ValueError:
                z = None
            break
    rcs = [float(x) for x in re.findall(r"cutoff radius[^0-9]*([0-9.]+)", head, re.I)]
    # En-tête v1 : table PP_INFO « 3s  3  0  2.00  1.80 » (rc en avant-dernière
    # colonne, mais APE y met l'énergie) → on préfère le bloc « r_c » du log.
    for line in head.splitlines():
        m = re.match(r"\s*\d[spdf]\s+\d+\s+\d+\s+[0-9.]+\s+([0-9.]+)", line)
        if m:
            rc = float(m.group(1))
            if 0.1 < rc < 6.0:
                rcs.append(rc)
    # Certains générateurs (APE) laissent le champ XC vide : pw.x refuse alors
    # le UPF avec « Error in routine set_dft_from_name ».
    has_xc = bool(re.search(r'functional\s*=\s*["\'][A-Za-z]', head, re.I))
    xc = None
    m = re.search(r'functional\s*=\s*["\']([^"\']+)["\']', head, re.I)
    if m:
        xc = m.group(1).strip()
    else:
        m = re.search(r"Functional:\s*([A-Za-z0-9_-]+)", head)
        if m:
            xc = m.group(1)
        else:
            # v1 : la fonctionnelle est sur la ligne juste au-dessus de
            # « Exchange-Correlation functional » (souvent vide chez APE).
            lines = head.splitlines()
            for i, line in enumerate(lines):
                if "Exchange-Correlation" in line and i:
                    cand = lines[i - 1].strip()
                    if cand and len(cand) <= 20 and "  " not in cand:
                        xc = cand
                        has_xc = True
                    break
    if not xc or xc.lower() in ("unknown", "none"):
        has_xc = False
    return {"type": ptype, "z_valence": z, "rc_header": rcs,
            "xc_header": xc, "xc_header_missing": not has_xc}


def parse_input_rc(input_path: Path) -> dict[str, float]:
    """Rayons de coupure lus dans un input APE / ld1.x (best effort)."""
    out: dict[str, float] = {}
    try:
        txt = input_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return out
    # APE : %PPComponents → n | l | rc | ...
    if "%PPComponents" in txt:
        block = txt.split("%PPComponents", 1)[1].split("%", 1)[0]
        for line in block.splitlines():
            parts = [p.strip() for p in line.split("|")]
            if len(parts) >= 3:
                try:
                    out[f"{int(parts[0])}{'spdf'[int(parts[1])]}"] = float(parts[2])
                except (ValueError, IndexError):
                    continue
        return out
    # ld1.x : rc dans les lignes "n l occ ... rc rc ..." ou wfc/rcloc
    m = re.search(r"rcloc\s*=\s*([0-9.]+)", txt, re.I)
    if m:
        out["local"] = float(m.group(1))
    return out


def lattice_constant(sym: str, z: int) -> float:
    if sym in A_SC:
        return A_SC[sym]
    try:
        import lanthanide_nc as lnc
        import actinide_nc as anc
        if anc.is_actinide(sym):
            return A_SC_DEFAULT_AN
        if lnc.is_lanthanide(sym):
            return A_SC_DEFAULT_LN
    except ImportError:
        pass
    if 21 <= z <= 30:
        return A_SC_DEFAULT_3D
    return A_SC_DEFAULT


def element_z(sym: str) -> int:
    try:
        from elements_physics_db import get_element_info
        info = get_element_info(sym) or {}
        z = info.get("Z") or info.get("z")
        if z:
            return int(z)
    except Exception:
        pass
    return 0


def mass_of(sym: str) -> float:
    try:
        from elements_physics_db import get_element_info
        info = get_element_info(sym) or {}
        for key in ("mass", "atomic_mass", "A"):
            if info.get(key):
                return float(info[key])
    except Exception:
        pass
    return 1.0


# ────────────────────────────────────────────────────────────────────────────
# pw.x
# ────────────────────────────────────────────────────────────────────────────

def _pw_input(sym: str, upf: Path, ecut: float, ecutrho: float,
              a_ang: float, outdir: Path, nbnd: int | None,
              input_dft: str | None = None) -> str:
    a_bohr = a_ang / 0.529177210903
    nbnd_line = f"  nbnd = {nbnd},\n" if nbnd else ""
    dft_line = f"  input_dft = '{input_dft}',\n" if input_dft else ""
    return f"""&control
  calculation = 'scf'
  prefix = 'vp_{sym}'
  pseudo_dir = '{upf.parent}'
  outdir = '{outdir}'
  tstress = .false.
  tprnfor = .false.
  disk_io = 'none'
/
&system
  ibrav = 1
  celldm(1) = {a_bohr:.6f}
  nat = 1
  ntyp = 1
  ecutwfc = {ecut:.1f}
  ecutrho = {ecutrho:.1f}
{nbnd_line}{dft_line}  occupations = 'smearing'
  smearing = 'marzari-vanderbilt'
  degauss = 0.02
/
&electrons
  conv_thr = 1.0d-5
  mixing_mode = 'local-TF'
  mixing_beta = 0.3
  electron_maxstep = 200
/
ATOMIC_SPECIES
  {sym}  {mass_of(sym):.3f}  {upf.name}
ATOMIC_POSITIONS crystal
  {sym}  0.0 0.0 0.0
K_POINTS gamma
"""


def run_scf(pw: str, sym: str, upf: Path, ecut: float, factor: float,
            a_ang: float, workdir: Path, nbnd: int | None = None,
            input_dft: str | None = None) -> dict:
    outdir = workdir / f"out_{int(ecut)}"
    outdir.mkdir(parents=True, exist_ok=True)
    inp = workdir / f"scf_{int(ecut)}.in"
    inp.write_text(
        _pw_input(sym, upf, ecut, ecut * factor, a_ang, outdir, nbnd, input_dft),
        encoding="utf-8",
    )
    t0 = time.time()
    try:
        proc = subprocess.run(
            [pw, "-in", str(inp)],
            cwd=str(workdir),
            capture_output=True,
            text=True,
            timeout=PW_TIMEOUT_S,
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"timeout {PW_TIMEOUT_S}s", "ecut": ecut,
                "dt_s": round(time.time() - t0, 1)}
    except OSError as e:
        return {"ok": False, "error": str(e), "ecut": ecut,
                "dt_s": round(time.time() - t0, 1)}
    log = (proc.stdout or "") + "\n" + (proc.stderr or "")
    m = re.search(r"^!\s+total energy\s+=\s+(-?[0-9.]+)\s+Ry", log, re.M)
    converged = "convergence has been achieved" in log
    eigs = parse_eigenvalues(log)
    if not m or proc.returncode != 0 or not converged:
        err = "pas d'énergie totale"
        if "convergence NOT achieved" in log:
            err = "SCF non convergé"
        for pat in (r"Error in routine[^\n]*", r"%%%[^\n]*", r"Error[^\n]*"):
            mm = re.search(pat, log)
            if mm:
                err = mm.group(0)[:160]
                break
        return {"ok": False, "error": err, "ecut": ecut, "eigs": eigs,
                "dt_s": round(time.time() - t0, 1)}
    return {
        "ok": True,
        "etot_ry": float(m.group(1)),
        "ecut": ecut,
        "eigs": eigs,
        "dt_s": round(time.time() - t0, 1),
    }


def parse_eigenvalues(log: str) -> list[float]:
    """Énergies des états au premier k-point, en eV (dernier bloc 'bands (ev)')."""
    lines = log.splitlines()
    start = None
    for i, line in enumerate(lines):
        if "bands (ev):" in line:
            start = i
    if start is None:
        return []
    vals: list[float] = []
    for line in lines[start + 1:]:
        stripped = line.strip()
        if not stripped:
            if vals:
                break
            continue
        if "occupation" in stripped.lower() or "Fermi" in stripped:
            break
        # pw.x colle parfois les nombres (« -279.6079-276.5773 ») : on
        # extrait avec une regex plutôt qu'avec un split().
        nums = re.findall(r"-?\d+\.\d+", stripped)
        if not nums or re.sub(r"-?\d+\.\d+|\s", "", stripped):
            break
        vals.extend(float(x) for x in nums)
    return vals


def ghost_from_log(log_path: Path) -> list[str]:
    """Avertissements fantômes du générateur (ONCVPSP / APE / ATOMPAW)."""
    hits: list[str] = []
    try:
        txt = log_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return hits
    for line in txt.splitlines():
        low = line.lower()
        if "no ghost" in low or "testing" in low or "analysis" in low:
            continue          # APE : « Ghost state analysis … No ghost states »
        if "ghost" in low:
            # ONCVPSP écrit « WARNING wellstate: … » pour un état lié mou :
            # information, pas un fantôme.
            if "wellstate" in low:
                continue
            hits.append(line.strip()[:160])
    return hits


# ────────────────────────────────────────────────────────────────────────────
# Cœur du test
# ────────────────────────────────────────────────────────────────────────────

def validate(upf: Path, sym: str, pw: str, log_path: Path | None = None,
             input_path: Path | None = None, quiet: bool = False) -> dict:
    upf = upf.resolve()          # pw.x tourne dans un autre cwd
    meta = parse_upf_meta(upf)
    z = element_z(sym)
    a_ang = lattice_constant(sym, z)
    factor = 8.0 if meta["type"] in ("PAW", "US") else 4.0
    zval = meta["z_valence"] or 4.0
    nbnd = max(8, int(zval) + 6)
    input_dft = None
    guessed_xc = False
    if meta["xc_header_missing"]:
        blob = ""
        for p in (input_path, log_path):
            if p and Path(p).is_file():
                blob += Path(p).read_text(encoding="utf-8", errors="replace")
        blob_low = blob.lower()
        if "gga_x_pbe" in blob_low or "pbe" in blob_low:
            input_dft = "PBE"
        elif "lda_c_pz" in blob_low:
            input_dft = "PZ"
        elif "lda_c_pw" in blob_low or "lda" in blob_low:
            input_dft = "PW"
        if input_dft is None:
            input_dft = "PW"    # défaut APE/LDA — signalé comme deviné
            guessed_xc = True

    # ecut de départ : heuristique projet, sinon défaut
    try:
        from generator_guide import suggest_ecutwfc
        e0 = float(suggest_ecutwfc(zval, pseudo_type=meta["type"], Z=z or None))
    except Exception:
        e0 = 45.0
    # 3 points : ecut suggéré, puis 1.4× et 1.8× (référence de convergence)
    ecuts = sorted({max(20, int(e0)), int(round(1.4 * e0)), int(round(1.8 * e0))})
    emax = max(ecuts)

    workdir = Path(tempfile.mkdtemp(prefix=f"vp_{sym}_", dir=str(ROOT / "_work")))
    runs: list[dict] = []
    try:
        for e in ecuts:
            r = run_scf(pw, sym, upf, e, factor, a_ang, workdir, nbnd, input_dft)
            runs.append(r)
            if not quiet:
                state = f"{r['etot_ry']:.6f} Ry" if r.get("ok") else f"ÉCHEC ({r.get('error')})"
                print(f"      ecut={e:>5.0f} Ry  ecutrho={e * factor:>6.0f}  {state}")

        ok_runs = [r for r in runs if r.get("ok")]
        result: dict = {
            "upf": str(upf),
            "element": sym,
            "pseudo_type": meta["type"],
            "z_valence": meta["z_valence"],
            "ecut_suggested_ry": e0,
            "ecut_sweep_ry": ecuts,
            "rc_bohr": parse_input_rc(input_path) if input_path else {},
            "rc_header_bohr": meta["rc_header"],
            "xc_header": meta["xc_header"],
            "xc_header_missing": meta["xc_header_missing"],
            "input_dft_used": input_dft,
            "input_dft_guessed": guessed_xc,
            "ghost_log": ghost_from_log(log_path) if log_path else [],
            "runs": [{k: v for k, v in r.items() if k != "eigs"} for r in runs],
        }

        if len(ok_runs) < 2:
            result["verdict"] = "ECHEC_PW"
            return result

        reference = max(ok_runs, key=lambda r: r["ecut"])["etot_ry"]
        conv_1mRy = None
        conv_01mRy = None
        for r in sorted(ok_runs, key=lambda r: r["ecut"]):
            d = abs(r["etot_ry"] - reference)
            if conv_1mRy is None and d < CONV_TOL_RY:
                conv_1mRy = r["ecut"]
            if conv_01mRy is None and d < CONV_TOL_TIGHT_RY:
                conv_01mRy = r["ecut"]
        result["ecut_converged_1mRy"] = conv_1mRy
        result["ecut_converged_01mRy"] = conv_01mRy
        result["etot_ref_ry"] = reference

        # Fantômes : stabilité des états OCCUPÉS entre ecut bas et haut.
        # Les bandes de conduction varient légitimement avec ecut ; un état
        # fantôme, lui, est occupé et dérive de plusieurs eV.
        low = min(ok_runs, key=lambda r: r["ecut"])["eigs"]
        high = max(ok_runs, key=lambda r: r["ecut"])["eigs"]
        nocc = max(1, int(round(zval / 2)))
        n = min(len(low), len(high), nocc)
        shifts = [abs(high[i] - low[i]) for i in range(n)]
        result["n_occupied"] = nocc
        result["eig_shift_max_ev"] = round(max(shifts), 3) if shifts else None
        result["ghost_suspect"] = bool(shifts and max(shifts) > GHOST_SHIFT_EV)

        # État le plus bas anormalement profond : signature d'un potentiel
        # local faux (canal l absent) ou de cœurs laissés dans la valence.
        lowest = min((e for r in ok_runs for e in r["eigs"]), default=None)
        result["lowest_eig_ev"] = round(lowest, 3) if lowest is not None else None
        # Aucun état de valence (z_valence ≤ 20) ne descend sous ≈ −15 Ry
        # (−204 eV) : au-delí c'est un cœur laissé en valence ou un potentiel
        # local faux.
        result["deep_state_suspect"] = bool(
            lowest is not None and lowest < -15.0 * 13.6057
        )

        # Si seul le plus grand ecut testé est « convergé », la convergence
        # n'est pas démontrée : l'énergie décroît encore.
        converged = conv_1mRy is not None and conv_1mRy < emax
        result["ecut_sweep_max_ry"] = emax
        hard = converged and conv_1mRy > 1.5 * e0
        if not converged:
            verdict = "NON_CONVERGE"
        elif result["deep_state_suspect"]:
            verdict = "ETATS_TROP_PROFONDS"
        elif result["ghost_suspect"]:
            verdict = "GHOST_SUSPECT"
        elif result["ghost_log"]:
            verdict = "A_VALIDER"      # avertissement générateur seul
        elif hard:
            verdict = "RC_TROP_PETIT"
        else:
            verdict = "OK"
        result["verdict"] = verdict
        result["ecut_ratio_vs_suggested"] = (
            round(conv_1mRy / e0, 2) if conv_1mRy and e0 else None
        )
        return result
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def find_pseudos(selectors: list[str], all_pseudos: bool) -> list[tuple[Path, str]]:
    found: list[tuple[Path, str]] = []
    if all_pseudos:
        for d in ("pseudos", "pseudos-oncvpsp", "pseudos-atompaw", "pseudos-APE"):
            base = ROOT / d
            if not base.is_dir():
                continue
            for p in sorted(base.rglob("*.UPF")):
                sym = p.name.split(".")[0].split("_")[0]
                found.append((p, sym))
        return found
    for sel in selectors:
        p = Path(sel)
        if p.is_file():
            found.append((p, p.name.split(".")[0].split("_")[0]))
            continue
        sym = sel[0].upper() + sel[1:].lower() if len(sel) > 1 else sel.upper()
        # Un UPF par générateur (ld1, APE, ATOMPAW, ONCVPSP) : le plus récent.
        dirs = {
            "ld1": ROOT / "pseudos",
            "ape": ROOT / "_work" / f"ape_{sym}",
            "atompaw": ROOT / "_work" / f"atompaw_{sym}",
            "oncv": ROOT / "pseudos-oncvpsp" / "_work" / f"oncv_{sym}",
        }
        for gen, d in dirs.items():
            if not d.is_dir():
                continue
            ups = [p for p in d.glob(f"{sym}*.UPF") if p.is_file()]
            if gen == "ld1":
                # pseudos/ reçoit aussi les copies ONCV (…_oncv), ATOMPAW
                # (…GGA-PBE-paw) et APE (<El>.UPF) : on ne garde que ld1.
                ups = [
                    p for p in ups
                    if "_oncv" not in p.name
                    and "GGA-" not in p.name
                    and "LDA-" not in p.name
                    and p.name != f"{sym}.UPF"
                ]
            if not ups:
                continue
            found.append((max(ups, key=lambda p: p.stat().st_mtime), sym))
    return found


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    all_pseudos = "--all-pseudos" in sys.argv
    json_arg = None
    for a in sys.argv[1:]:
        if a.startswith("--json="):
            json_arg = a.split("=", 1)[1]
    if not args and not all_pseudos:
        args = ["Si", "Fe", "Eu", "Am"]

    pw = resolve_pw()
    if not pw:
        print("pw.x introuvable (PW_BIN / ./bin/pw.x / PATH) — test physique impossible.")
        return 2

    targets = find_pseudos(args, all_pseudos)
    if not targets:
        print("Aucun UPF trouvé pour :", ", ".join(args))
        return 2

    print(f"VALIDATION PHYSIQUE UPF — pw.x = {pw}")
    print(f"Critères : convergence < {CONV_TOL_RY * 1000:.0f} mRy/atome · "
          f"fantôme si dérive > {GHOST_SHIFT_EV} eV\n")

    results: list[dict] = []
    for upf, sym in targets:
        log_path = None
        input_path = None
        # logs/inputs du générateur, si présents à côté du run
        for cand in (
            upf.parent / "ape_run.log",
            upf.parent / "atompaw_run.log",
            upf.parent / f"oncv_{sym}.out",
        ):
            if cand.is_file():
                log_path = cand
                break
        for cand in (
            upf.parent / "inp.ape",
            upf.parent / "atompaw.in",
            upf.parent / f"oncv_{sym}.dat",
        ):
            if cand.is_file():
                input_path = cand
                break

        print(f"  {sym:<3} {upf}")
        r = validate(upf, sym, pw, log_path=log_path, input_path=input_path)
        results.append(r)
        if r.get("verdict") == "ECHEC_PW":
            print(f"      → ÉCHEC pw.x : "
                  f"{(r['runs'][-1].get('error') if r['runs'] else 'aucun run')}")
            continue
        print(
            f"      → {r['verdict']}  convergence ecut = "
            f"{r.get('ecut_converged_1mRy')} Ry (suggéré {r['ecut_suggested_ry']:.0f})"
            f" · ecut(0.1 mRy) = {r.get('ecut_converged_01mRy')} Ry"
            f" · dérive états occupés = {r.get('eig_shift_max_ev')} eV"
            f" · état le plus bas = {r.get('lowest_eig_ev')} eV"
        )
        if r.get("xc_header_missing"):
            print(f"      ✗ en-tête UPF sans fonctionnelle XC → pw.x exige "
                  f"input_dft='{r.get('input_dft_used')}'")
        if r.get("rc_bohr") or r.get("rc_header_bohr"):
            print(f"      r_c : input={r.get('rc_bohr') or '—'} "
                  f"entête={r.get('rc_header_bohr') or '—'}")
        if r.get("ghost_log"):
            for line in r["ghost_log"][:3]:
                print(f"      log générateur : {line}")
        print()

    print("=" * 72)
    bad = [r for r in results if r.get("verdict") not in ("OK",)]
    for r in results:
        print(f"  {r['element']:<3} {r['verdict']:<20} "
              f"ecut={r.get('ecut_converged_1mRy')} Ry  "
              f"dérive={r.get('eig_shift_max_ev')} eV  "
              f"bas={r.get('lowest_eig_ev')} eV")
    print(f"\n{len(results) - len(bad)}/{len(results)} UPF validés physiquement.")

    out = Path(json_arg) if json_arg else ROOT / "logs" / "validation_physique.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"JSON → {out}")
    return 0 if not bad else 1


if __name__ == "__main__":
    raise SystemExit(main())

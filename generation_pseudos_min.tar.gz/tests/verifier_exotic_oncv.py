#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Régression ONCV exotiques — les 20 gabarits oncv_templates_exotic/*.dat
doivent passer dans le vrai binaire oncvpsp.x, sans ghost bloquant, avec
métrique de transférabilité (configs test).

  python3 tests/verifier_exotic_oncv.py            # rapide (20 runs)
  python3 tests/verifier_exotic_oncv.py --full     # + seuils stricts (0.002 Ha)
  python3 tests/verifier_exotic_oncv.py Po Og      # sous-ensemble
  python3 tests/verifier_exotic_oncv.py --regen    # régénère les .dat avant test

Contrôles par élément :
  1. run complet      — « calling psmlout », pas de ERROR/will stop
  2. ghosts           — 0 × GHOST(-) ; ≤1 × GHOST(+) (seuil = référence officielle
                        83_Bi.dat / 56_Ba.dat / 80_Hg.dat qui ont eux-mêmes 1 GHOST(+))
  3. transférabilité  — configs test (ionisations) : max|eae - eps| ≤ 0.02 Ha
                        par défaut (≈ ordre de grandeur des gabarits officiels) ;
                        --full serre à 0.002 Ha
  4. cohérence        — nc, nv, somme des occupations = Z, iexc=4 (PBE)
"""
from __future__ import annotations

import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

BIN_CANDIDATES = (
    ROOT / "bin" / "oncvpsp.x",
    ROOT / "third_party" / "oncvpsp" / "bin" / "oncvpsp.x",
)
TPL_DIR = ROOT / "oncv_templates_exotic"
TOK = re.compile(r"-?[\d.]+(?:[EeDd][+-]?\d+)?")
LINE6 = re.compile(r"^\s*(\d+)\s+(\d)\s+([\d.]+)\s*(-?[\d.]+)\s*(-?[\d.]+)\s*(-?[\dEDed.+]+)\s*$")

# Seuils (calés sur les gabarits officiels data/oncvpsp_tests_data)
MAX_GHOST_PLUS = 1          # 83_Bi, 56_Ba, 80_Hg officiels : 1 GHOST(+) chacun
MAX_GHOST_MINUS = 0         # aucun ghost lié toléré
DIFF_SOFT = 0.02            # Ha — max|eae-eps| configs test (mode rapide)
DIFF_STRICT = 0.002         # Ha — mode --full


def find_bin() -> Path | None:
    for c in BIN_CANDIDATES:
        if c.is_file():
            return c
    import shutil
    w = shutil.which("oncvpsp.x")
    return Path(w) if w else None


def run_oncv(bin_path: Path, dat_text: str) -> str:
    with tempfile.NamedTemporaryFile("w", suffix=".dat", delete=False) as f:
        f.write(dat_text)
        path = f.name
    try:
        with open(path) as inf:
            proc = subprocess.run(
                [str(bin_path)], stdin=inf, capture_output=True,
                text=True, timeout=180, cwd=str(Path(path).parent),
            )
    finally:
        Path(path).unlink(missing_ok=True)
    return (proc.stdout or "") + "\n" + (proc.stderr or "")


def test_diffs(out: str) -> list[float]:
    """max|eae - eps| par bloc « Test configuration » (table ancrée sur eae)."""
    maxima: list[float] = []
    for m in re.finditer(r"Test configuration \d+(.*?)(?=Test configuration \d+|$)", out, re.S):
        block = m.group(1)
        dmax = 0.0
        for hm in re.finditer(r"^.*eae.*$\n((?:\s*[\d.-].*\n)+)", block, re.M):
            for line in hm.group(1).splitlines():
                t = TOK.findall(line)
                if len(t) >= 6:
                    try:
                        dmax = max(dmax, abs(float(t[5].replace("D", "E"))))
                    except ValueError:
                        pass
        maxima.append(dmax)
    return maxima


def check_structure(sym: str, dat: str) -> list[str]:
    """Cohérence minimale de l'entrée : atom line, nc/nv, somme = Z, iexc=4."""
    errs: list[str] = []
    try:
        import exotic_nc
        from pseudo_auto_inputs import atomic_number
        z = int(atomic_number(sym))
    except Exception:
        return [f"{sym}: exotic_nc/pseudo_auto_inputs indisponible"]
    m = re.search(
        r"#\s*ATOM AND REFERENCE.*?\n\s*[A-Za-z]{1,2}\s+([\d.]+)\s+(\d+)\s+(\d+)\s+(-?\d+)",
        dat, re.S,
    )
    if not m:
        return [f"{sym}: bloc ATOM AND REFERENCE illisible"]
    zz, nc, nv, iexc = float(m.group(1)), int(m.group(2)), int(m.group(3)), int(m.group(4))
    if abs(zz - z) > 0.01:
        errs.append(f"{sym}: Z déclaré {zz:.0f} ≠ {z}")
    if iexc != 4:
        errs.append(f"{sym}: iexc={iexc} (attendu 4 = PBE)")
    elec = re.findall(r"^\s+(\d+)\s+(\d)\s+([\d.]+)\s*$", dat.split("# PSEUDOPOTENTIAL")[0], re.M)
    if len(elec) != nc + nv:
        errs.append(f"{sym}: {len(elec)} lignes n,l,f ≠ nc+nv={nc + nv}")
    try:
        q = sum(float(o) for _, _, o in elec)
        if abs(q - z) > 0.01:
            errs.append(f"{sym}: somme occupations {q} ≠ Z={z}")
    except ValueError:
        errs.append(f"{sym}: occupations illisibles")
    if "# TEST CONFIGURATIONS" not in dat:
        errs.append(f"{sym}: pas de TEST CONFIGURATIONS (transférabilité non mesurable)")
    _ = nv  # nv vérifié via len(elec) == nc+nv
    return errs


def main(argv: list[str]) -> int:
    args = [a for a in argv if a.startswith("-")]
    syms = [a for a in argv if not a.startswith("-")]
    strict = "--full" in args
    regen = "--regen" in args
    diff_limit = DIFF_STRICT if strict else DIFF_SOFT

    bin_path = find_bin()
    if not bin_path:
        print("oncvpsp.x introuvable (bin/, third_party/, PATH) — test impossible.")
        return 2

    if regen:
        import exotic_nc
        exotic_nc.ensure_cached_templates(str(ROOT))
        print("Cache .dat régénéré (exotic_nc.ensure_cached_templates).")

    try:
        import exotic_nc as exc
        all_syms = list(exc.EXOTIC_SYMBOLS)
    except Exception:
        all_syms = sorted(p.stem for p in TPL_DIR.glob("*.dat"))
    if syms:
        all_syms = [s for s in all_syms if s in syms]

    print(f"oncvpsp.x : {bin_path}")
    print(f"Seuils : GHOST(-)=0  GHOST(+)<={MAX_GHOST_PLUS}  "
          f"max|eae-eps|<={diff_limit} Ha {'(strict)' if strict else '(soft)'}")
    print("-" * 76)

    n_ok = 0
    failures: list[str] = []
    for sym in all_syms:
        tpl = TPL_DIR / f"{sym}.dat"
        if not tpl.is_file():
            failures.append(f"{sym}: {tpl.name} absent")
            print(f"✗ {sym:<4} gabarit absent")
            continue
        dat = tpl.read_text(encoding="utf-8", errors="replace")
        errs = check_structure(sym, dat)
        out = run_oncv(bin_path, dat)
        completed = "calling psmlout" in out and not re.search(r"ERROR|will stop", out)
        g_minus = len(re.findall(r"WARNING - GHOST\(-\)", out))
        g_plus = len(re.findall(r"WARNING - GHOST\(\+\)", out))
        diffs = test_diffs(out)
        dmax = max(diffs) if diffs else float("inf")
        if not completed:
            err = next((l.strip() for l in out.splitlines()
                        if "ERROR" in l or "will stop" in l), "run incomplet")
            errs.append(f"run: {err[:60]}")
        if g_minus > MAX_GHOST_MINUS:
            errs.append(f"GHOST(-)×{g_minus}")
        if g_plus > MAX_GHOST_PLUS:
            errs.append(f"GHOST(+)×{g_plus}")
        if dmax > diff_limit:
            errs.append(f"transfert max|eae-eps|={dmax:.1e} Ha")
        if errs:
            failures.append(f"{sym}: " + "; ".join(errs))
            print(f"✗ {sym:<4} " + "; ".join(errs))
        else:
            n_ok += 1
            print(f"✓ {sym:<4} run OK  GHOST(+)={g_plus}  "
                  f"transfert={dmax:.1e} Ha  ({len(diffs)} configs test)")

    print("-" * 76)
    print(f"Résumé : {n_ok}/{len(all_syms)} OK — seuils "
          f"GHOST(+)≤{MAX_GHOST_PLUS}, transfert≤{diff_limit} Ha")
    if failures:
        print("Échecs :")
        for f in failures:
            print(f"  - {f}")
        return 1
    print("Tous les gabarits exotiques passent oncvpsp.x (ghost + transférabilité).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))

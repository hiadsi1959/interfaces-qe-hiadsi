#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Validation générale — ld1 · APE · ATOMPAW · ONCVPSP (3d / 4f / 5f).

  python3 tests/validation_generators_full.py
  python3 tests/validation_generators_full.py Fe Eu Am

Critères :
  PASS          — UPF frais + conforme QE + returncode 0
  PASS_UPF      — UPF conforme (run OK ; fraîcheur non exigée si réutilisation workdir)
  EXPECTED_FAIL — échec attendu (ex. ld1 4f/5f from scratch)
  FAIL          — échec inattendu ou binaire absent
"""
from __future__ import annotations

import json
import os
import re
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

_CLI = [a for a in sys.argv[1:] if not a.startswith("-") and re.match(r"^[A-Za-z]{1,3}$", a)]
_saved = sys.argv[:]
sys.argv = ["api_pseudos_standalone", "--port", "5008"]
import api_pseudos_standalone as api  # noqa: E402
sys.argv = _saved

import pseudo_auto_inputs as pai  # noqa: E402

# Matrice représentative
DEFAULT = ["Si", "Fe", "Eu", "Am"]

FAMILLE = {
    "Al": "léger (p)",
    "Si": "léger (p)",
    "Fe": "3d",
    "Ti": "3d",
    "Ni": "3d",
    "La": "4f",
    "Ce": "4f",
    "Eu": "4f",
    "Dy": "4f",
    "U": "5f",
    "Am": "5f",
    "Pu": "5f",
}

# ld1 from scratch : 3d OK (PAW/US), 4f/5f souvent KO
LD1_EXPECTED_FAIL = {"La", "Ce", "Eu", "Gd", "Dy", "Nd", "Am", "Pu", "U", "Cm", "Bk"}

# APE NC : fragile sur 3d / blocs f (ATOMPAW / ONCV / ld1 préférés)
APE_EXPECTED_FAIL = LD1_EXPECTED_FAIL | pai._TRANSITION_3D


def _zval(path: str | None) -> float | None:
    if not path or not os.path.isfile(path):
        return None
    try:
        txt = Path(path).read_text(encoding="utf-8", errors="replace")[:12000]
        for pat in (
            r'z_valence\s*=\s*["\']?\s*([0-9.eE+-]+)',
            r'<z_valence>\s*([0-9.eE+-]+)\s*</z_valence>',
            r'([0-9.eE+-]+)\s+Z\s+valence',
        ):
            m = re.search(pat, txt, re.I)
            if m:
                return float(m.group(1))
    except (OSError, ValueError):
        pass
    return None


def _fresh(path: str | None, t0: float) -> bool:
    if not path or not os.path.isfile(path):
        return False
    return os.path.getmtime(path) >= (t0 - 2.0)


def _grade(
    tool: str,
    element: str,
    j: dict,
    upf: str | None,
    t0: float,
) -> dict:
    upf = upf or j.get("upf_path") or ""
    qv = api._validate_upf_qe(upf) if upf and hasattr(api, "_validate_upf_qe") else {}
    rc = j.get("returncode")
    ok_api = bool(j.get("success"))
    fresh = _fresh(upf, t0)
    conform = bool(qv.get("conform_qe") or j.get("upf_qe_ready"))
    rc_ok = rc is None or rc == 0
    err = (j.get("error") or j.get("hint") or j.get("diagnostic_summary") or "")[:200]
    size = os.path.getsize(upf) if upf and os.path.isfile(upf) else 0
    zv = j.get("z_valence")
    if zv is None and qv.get("z_valence") is not None:
        zv = qv.get("z_valence")
    if zv is None:
        zv = _zval(upf)
    ecut = j.get("suggested_ecutwfc_ry") or qv.get("suggested_ecutwfc_ry")

    if tool == "ld1.x" and element in LD1_EXPECTED_FAIL and not ok_api:
        status = "EXPECTED_FAIL"
    elif tool == "APE" and element in APE_EXPECTED_FAIL and not ok_api:
        status = "EXPECTED_FAIL"
    elif ok_api and conform and rc_ok and fresh:
        status = "PASS"
    elif ok_api and conform and rc_ok and upf:
        status = "PASS_UPF"
    elif not upf and not ok_api:
        status = "EXPECTED_FAIL" if (
            (tool == "ld1.x" and element in LD1_EXPECTED_FAIL)
            or (tool == "APE" and element in APE_EXPECTED_FAIL)
        ) else "FAIL"
    else:
        status = "FAIL"

    return {
        "status": status,
        "success": ok_api,
        "conform_qe": conform,
        "fresh_upf": fresh,
        "upf_path": upf,
        "z_valence": zv,
        "suggested_ecutwfc_ry": ecut,
        "size_kb": round(size / 1024, 1) if size else 0,
        "error": err,
        "returncode": rc,
        "build_tag": j.get("build_tag"),
    }


def _oncv_input(client, element: str, z: int, is_4f: bool, is_5f: bool) -> str:
    try:
        if is_4f:
            import lanthanide_nc as lnc
            return lnc.generate_oncv_dat(element, f_treatment="open_core", xc="gga_pbe", psfile="both")
    except Exception:
        pass
    try:
        if is_5f:
            import actinide_nc as anc
            return anc.generate_oncv_dat(element, f_treatment="open_core", xc="gga_pbe", psfile="both")
    except Exception:
        pass
    for cand in [
        ROOT / "data" / "oncv" / f"oncv_default_{z}_{element}.dat",
        ROOT / "data" / "oncv" / f"oncv_default_{element}.dat",
        ROOT / "data" / "oncvpsp_tests_data" / f"{z}_{element}.dat",
        ROOT / "oncv_templates_3d" / f"{element}.dat",
        ROOT / f"oncv_default_{element}.dat",
    ]:
        if cand.is_file():
            return cand.read_text(encoding="utf-8")
    r2 = client.get(f"/api/pseudos/auto_inputs?element={element}&xc=gga_pbe&f_treatment=open_core")
    j = r2.get_json() or {}
    return (j.get("oncv_input_dat") or "").strip()


def _ld1_input(element: str, z: int) -> str:
    ft = None
    if 57 <= z <= 71 or 89 <= z <= 103:
        ft = "open_core"
    return pai.generate_ld1_input(element, dft="PBE", semicore=True, f_treatment=ft)


def run_one(client, element: str) -> dict:
    z = pai.atomic_number(element)
    is_4f = 57 <= z <= 71
    is_5f = 89 <= z <= 103
    is_3d = element in pai._TRANSITION_3D
    fam = FAMILLE.get(element, f"Z={z}")
    print(f"\n{'=' * 72}\n  {element}  ({fam})\n{'=' * 72}", flush=True)
    out: dict = {}

    # --- ld1 ---
    t0 = time.time()
    print("  → ld1.x …", flush=True)
    try:
        ld1_in = _ld1_input(element, z)
        resp = client.post(
            "/api/pseudos/generer_ld1",
            json={"element": element, "input": ld1_in, "regenerate_input": True},
        )
        j = resp.get_json() or {}
        upf = j.get("upf_path") or ""
        if not upf and j.get("upf_genere") and j.get("pseudos_dir"):
            upf = str(Path(j["pseudos_dir"]) / j["upf_genere"])
        row = _grade("ld1.x", element, j, upf, t0)
    except Exception as e:
        row = {"status": "FAIL", "error": str(e)[:200], "success": False, "conform_qe": False,
               "fresh_upf": False, "upf_path": "", "size_kb": 0}
    row["dt_s"] = round(time.time() - t0, 1)
    out["ld1.x"] = row
    _print_row(row)

    # --- APE ---
    t0 = time.time()
    print("  → APE …", flush=True)
    body = {
        "element": element, "auto_generate": True, "xc": "lda_pw",
        "relativistic": True, "semicore": True,
        "rc_scale": 1.25 if (is_3d or is_4f or is_5f) else 1.0,
    }
    if is_4f or is_5f:
        body["f_treatment"] = "open_core"
    resp = client.post("/api/pseudos/run_ape", json=body)
    j = resp.get_json() or {}
    wd = j.get("work_dir") or j.get("continue_dir")
    hint = ((j.get("hint") or "") + (j.get("error") or "")).lower()
    if (not j.get("success")) and wd and "continue" in hint:
        resp = client.post("/api/pseudos/run_ape", json={
            "element": element, "continue_dir": wd, "auto_generate": False, "xc": "lda_pw",
        })
        j = resp.get_json() or {}
    row = _grade("APE", element, j, j.get("upf_path"), t0)
    row["dt_s"] = round(time.time() - t0, 1)
    out["APE"] = row
    _print_row(row)

    # --- ATOMPAW ---
    t0 = time.time()
    print("  → ATOMPAW …", flush=True)
    body = {
        "element": element, "auto_generate": True, "format": "interactive",
        "relativistic": True, "semicore": True,
    }
    if is_4f or is_5f:
        body["f_treatment"] = "open_core"
    resp = client.post("/api/pseudos/run_atompaw", json=body)
    j = resp.get_json() or {}
    row = _grade("ATOMPAW", element, j, j.get("upf_path"), t0)
    row["dt_s"] = round(time.time() - t0, 1)
    out["ATOMPAW"] = row
    _print_row(row)

    # --- ONCVPSP ---
    t0 = time.time()
    print("  → ONCVPSP …", flush=True)
    oncv = _oncv_input(client, element, z, is_4f, is_5f)
    if not oncv:
        row = {"status": "FAIL", "error": "pas de template ONCV", "success": False,
               "conform_qe": False, "fresh_upf": False, "upf_path": "", "size_kb": 0, "dt_s": 0}
        print("     err: pas de template ONCV")
    else:
        resp = client.post("/api/pseudos/run_oncvpsp", json={"element": element, "input": oncv})
        j = resp.get_json() or {}
        row = _grade("ONCVPSP", element, j, j.get("upf_path"), t0)
        row["dt_s"] = round(time.time() - t0, 1)
        _print_row(row)
    out["ONCVPSP"] = row
    return out


def _print_row(row: dict) -> None:
    st = row.get("status", "?")
    zv = row.get("z_valence")
    ec = row.get("suggested_ecutwfc_ry")
    meta = ""
    if zv is not None:
        meta += f" z={zv}"
    if ec is not None:
        meta += f" ecut={ec}Ry"
    print(
        f"     [{st}] api={row.get('success')} qe={row.get('conform_qe')} "
        f"fresh={row.get('fresh_upf')} {row.get('size_kb', 0)} KB{meta} ({row.get('dt_s')}s)",
        flush=True,
    )
    if row.get("error") and st in ("FAIL", "EXPECTED_FAIL"):
        print(f"     err: {row['error'][:120]}", flush=True)


def main() -> int:
    elements = _CLI or DEFAULT
    build = getattr(api, "API_BUILD_TAG", "?")
    print("VALIDATION GÉNÉRALE — 4 générateurs (3d / 4f / 5f)")
    print(f"Projet : {ROOT}")
    print(f"Build  : {build}")
    print("Éléments :", ", ".join(f"{e} ({FAMILLE.get(e, '?')})" for e in elements))
    bins = {
        "ld1.x": bool(api.QE_BIN and os.path.isfile(os.path.join(str(api.QE_BIN), "ld1.x"))),
        "APE": bool(api._resolve_ape_bin_sa()),
        "ATOMPAW": bool(api._resolve_atompaw_bin_sa()),
        "ONCVPSP": bool(api._resolve_oncvpsp_bin()),
    }
    print("Binaires :", ", ".join(f"{k}={'OK' if v else 'ABSENT'}" for k, v in bins.items()))

    client = api.app.test_client()
    all_res: dict = {}
    t_global = time.time()
    for el in elements:
        all_res[el] = run_one(client, el)

    counts = {"PASS": 0, "PASS_UPF": 0, "EXPECTED_FAIL": 0, "FAIL": 0}
    by_tool: dict[str, dict[str, int]] = {k: {"PASS": 0, "PASS_UPF": 0, "EXPECTED_FAIL": 0, "FAIL": 0}
                                          for k in ("ld1.x", "APE", "ATOMPAW", "ONCVPSP")}

    print(f"\n{'=' * 72}")
    print("SYNTHÈSE")
    print(f"{'=' * 72}")
    print(f"{'Élément':<6} {'Famille':<12} {'Outil':<10} {'Statut':<14} {'QE':<5} {'KB':<8} {'t(s)'}")
    print("-" * 72)
    for el, tools in all_res.items():
        for name, row in tools.items():
            st = row.get("status", "FAIL")
            counts[st] = counts.get(st, 0) + 1
            by_tool[name][st] = by_tool[name].get(st, 0) + 1
            print(
                f"{el:<6} {FAMILLE.get(el, '?'):<12} {name:<10} {st:<14} "
                f"{'OK' if row.get('conform_qe') else '—':<5} "
                f"{row.get('size_kb') or '—':<8} {row.get('dt_s', '—')}"
            )

    n_pass = counts["PASS"] + counts["PASS_UPF"]
    n_tot = sum(counts.values())
    n_fail = counts["FAIL"]
    print("-" * 72)
    print(f"PASS={counts['PASS']}  PASS_UPF={counts['PASS_UPF']}  "
          f"EXPECTED_FAIL={counts['EXPECTED_FAIL']}  FAIL={counts['FAIL']}")
    print(f"Score utile : {n_pass + counts['EXPECTED_FAIL']}/{n_tot}  (échecs réels : {n_fail})")
    for tool, st in by_tool.items():
        ok = st.get("PASS", 0) + st.get("PASS_UPF", 0)
        exp = st.get("EXPECTED_FAIL", 0)
        fail = st.get("FAIL", 0)
        print(f"  {tool:<10} OK {ok}/{ok+exp+fail}  (expected_fail={exp}, fail={fail})")

    report = {
        "build_tag": build,
        "elements": elements,
        "bins": bins,
        "counts": counts,
        "by_tool": by_tool,
        "score_useful": f"{n_pass + counts['EXPECTED_FAIL']}/{n_tot}",
        "score_real_failures": n_fail,
        "duration_s": round(time.time() - t_global, 1),
        "results": all_res,
    }
    out_path = ROOT / "logs" / "validation_generators_full.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\nJSON → {out_path}")
    print(f"Durée totale : {report['duration_s']} s")

    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())

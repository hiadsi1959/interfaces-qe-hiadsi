#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Contrôle des défauts physiques (4f/5f, z_valence APE, optima par générateur)."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def main() -> int:
    fails = 0

    def check(name: str, cond: bool, detail: str = "") -> None:
        nonlocal fails
        print(("OK  " if cond else "FAIL") + f" {name}" + (f" — {detail}" if detail else ""))
        if not cond:
            fails += 1

    import lanthanide_nc as lnc
    import actinide_nc as anc
    import generator_physics_params as gpp
    import api_pseudos_standalone as api

    # 4f : ONCV = stabilité ; ATOMPAW/ld1 = chimie
    check("Dy ONCV → open_core", lnc.resolve_f_treatment("Dy", "auto", None, for_oncv=True) == "open_core")
    check("Dy physique → valence_f", lnc.resolve_f_treatment("Dy", "auto", None, for_oncv=False) == "valence_f")
    check("Yb physique → open_core (4f14)", lnc.resolve_f_treatment("Yb", "auto", None, for_oncv=False) == "open_core")
    check("Lu ONCV → valence_f (4f14 hors valence)", lnc.resolve_f_treatment("Lu", "auto", None, for_oncv=True) == "valence_f")

    # 5f : Th–Pu itinerant ; Am localisé
    check("U ONCV → valence_f", anc.resolve_f_treatment("U", "auto", None, for_oncv=True) == "valence_f")
    check("U physique → valence_f", anc.resolve_f_treatment("U", "auto", None, for_oncv=False) == "valence_f")
    check("Am ONCV → open_core", anc.resolve_f_treatment("Am", "auto", None, for_oncv=True) == "open_core")
    check("Am physique → open_core", anc.resolve_f_treatment("Am", "auto", None, for_oncv=False) == "open_core")

    oc_oncv = gpp.element_optimal_controls("Dy", "oncvpsp")
    oc_aw = gpp.element_optimal_controls("Dy", "atompaw")
    check(
        "optimal Dy ONCV = open_core",
        (oc_oncv.get("controls") or {}).get("f_treatment") == "open_core",
        str((oc_oncv.get("controls") or {}).get("f_treatment")),
    )
    check(
        "optimal Dy ATOMPAW = valence_f",
        (oc_aw.get("controls") or {}).get("f_treatment") == "valence_f",
        str((oc_aw.get("controls") or {}).get("f_treatment")),
    )

    # z_valence format APE (nombre avant « Z valence »)
    ape_hdr = "   4.00000000000      Z valence\n"
    check("z_valence APE = 4", api._extract_upf_z_valence(ape_hdr) == 4.0)

    xml = '<z_valence>   8.00 </z_valence>'
    check("z_valence XML = 8", api._extract_upf_z_valence(xml) == 8.0)

    quoted = 'z_valence="    14.00"'
    check("z_valence UPF v2 quoted", api._extract_upf_z_valence(quoted) == 14.0)

    # PseudoDojo : XC LDA ne doit PAS réécrire iexc
    dat = lnc.generate_oncv_dat("Eu", f_treatment="open_core", xc="lda_pw")
    check("PseudoDojo Eu LDA : avertissement XC", "AVERTISSEMENT" in dat and "ignorée" in dat)

    # Super-lourds : ATOMPAW doit être bloqué proprement avant timeout de 300 s.
    block = api._atompaw_generation_block("Ds")
    check(
        "Ds ATOMPAW : blocage anticipé super-lourd",
        bool(block.get("blocked")) and "ONCVPSP" in (block.get("fallback") or ""),
        str(block),
    )

    print()
    print(f"Résumé : {fails} échec(s)")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Contrôle : chaque gabarit ONCV doit contenir l'en-tête « ATOM AND REFERENCE ».

Cet en-tête est exigé par deux validateurs :
  - l'API   : api_pseudos_standalone._normalize_oncv_dat_for_target()
              (localise la ligne atsym pour normaliser psfile ; avertit si absent)
  - le panneau ONCVPSP : script_generateur_oncvpsp_panel.js → _oncvTemplateLooksValid()
              (txt.indexOf('# ATOM AND REFERENCE') < 0 → « gabarit ONCV manquant »)

Un gabarit sans cet en-tête est donc silencieusement refusé par l'UI.

Régression historique (2026-09) : les variantes *-sp / *-fsp des lanthanides
avaient été copiées brut de PseudoDojo sans cet en-tête. Comme le défaut est
« open_core » (fichier *_3+_f-in-core.in, conforme) pour 13 des 15 éléments,
seuls La et Lu — dont le défaut est « valence_f » — basculaient sur un
*-sp.in invalide et n'affichaient aucun modèle.

  python3 tests/verifier_entetes_gabarits.py
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# Dossiers de gabarits du projet. dist/ (artefact de build daté) est exclu :
# ROOT.glob() ne descend pas dans les sous-dossiers.
TEMPLATE_DIRS = sorted(ROOT.glob("oncv_templates_*")) + [
    ROOT / "data" / "oncvpsp_tests_data",
]
EXPECTED_DIRS = (
    "oncv_templates_3d",
    "oncv_templates_4d",
    "oncv_templates_main_group",
    "oncv_templates_exotic",
    "oncv_templates_actinide",
    "oncv_templates_lanthanide",
)
TEMPLATE_EXTS = (".dat", ".in")

# Règles identiques à l'API / au panneau JS
HEADER_RE = re.compile(r"#\s*ATOM AND REFERENCE", re.I)
PSFILE_RE = re.compile(r"\b(psp8|upf|both)\b", re.I)
ATSYM_RE = re.compile(
    r"#\s*ATOM AND REFERENCE[\s\S]*?\n\s*([A-Za-z]{1,2})\s+([\d.]+)", re.I
)


def iter_templates() -> list[Path]:
    out: list[Path] = []
    for d in TEMPLATE_DIRS:
        if not d.is_dir():
            continue
        out.extend(
            p for p in sorted(d.iterdir())
            if p.is_file() and p.suffix.lower() in TEMPLATE_EXTS
        )
    return out


def check_file(path: Path) -> list[str]:
    """Renvoie la liste des anomalies pour un fichier gabarit."""
    errs: list[str] = []
    try:
        rel: str | Path = path.resolve().relative_to(ROOT)
    except ValueError:
        rel = path
    txt = path.read_text(encoding="utf-8", errors="replace")
    if not HEADER_RE.search(txt):
        errs.append(f"{rel} : en-tête « # ATOM AND REFERENCE » absent")
        return errs  # le reste (atsym) ne peut pas être lu sans l'en-tête
    if not PSFILE_RE.search(txt):
        errs.append(f"{rel} : aucune cible psfile (psp8 | upf | both)")
    m = ATSYM_RE.search(txt)
    if not m:
        errs.append(f"{rel} : ligne atsym illisible après l'en-tête")
    return errs


def check_lanthanide_variants() -> list[str]:
    """Les gabarits réellement servis par l'API (loader + normalisation)."""
    errs: list[str] = []
    try:
        import lanthanide_nc as lnc
        import api_pseudos_standalone as api
    except Exception as ex:  # dépendances API indisponibles → non bloquant
        return [f"import lanthanide_nc/api impossible ({ex}) — contrôle loader ignoré"]

    for sym in lnc.LANTHANIDE_SYMBOLS:
        for ft in ("open_core", "valence_f"):
            raw, src = lnc.load_pseudodojo_oncv_input(sym, ft)
            if not raw:
                errs.append(f"{sym}/{ft} : aucun gabarit PseudoDojo chargé")
                continue
            norm, warns, _ps = api._normalize_oncv_dat_for_target(
                raw, "quantum_espresso"
            )
            if any("ATOM AND REFERENCE" in w for w in warns):
                errs.append(f"{sym}/{ft} ({src}) : {warns[0]}")
            if not HEADER_RE.search(norm):
                errs.append(
                    f"{sym}/{ft} ({src}) : en-tête absente après normalisation API"
                )
    return errs


def main() -> int:
    fails = 0

    def check(name: str, cond: bool, detail: str = "") -> None:
        nonlocal fails
        print(("OK  " if cond else "FAIL") + f" {name}" + (f" — {detail}" if detail else ""))
        if not cond:
            fails += 1

    print("Contrôle des en-têtes de gabarits ONCV")
    print("-" * 60)

    for name in EXPECTED_DIRS:
        check(f"dossier {name}", (ROOT / name).is_dir())

    files = iter_templates()
    check(f"gabarits trouvés ({len(files)} .dat/.in)", len(files) > 0)
    print(f"     ({len(TEMPLATE_DIRS)} dossiers scannés)")

    errors: list[str] = []
    for path in files:
        errors.extend(check_file(path))

    check("en-tête « ATOM AND REFERENCE » sur chaque fichier", not errors)
    for e in errors:
        print(f"       ✗ {e}")

    print("-" * 60)
    print("Variantes lanthanides servies par l'API (loader + normalisation)")
    ln_errors = check_lanthanide_variants()
    if ln_errors and ln_errors[0].startswith("import "):
        print(f"  (info) {ln_errors[0]}")
    else:
        check("30 variantes La–Lu conformes", not ln_errors)
        for e in ln_errors:
            print(f"       ✗ {e}")

    print()
    print(f"Résumé : {fails} échec(s) — {len(files)} gabarits contrôlés")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())

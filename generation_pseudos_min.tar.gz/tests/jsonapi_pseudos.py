#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tests unitaires des générateurs (API pseudos) : ld1.x · APE · ATOMPAW · ONCVPSP.

Ce fichier est fait pour être exécuté **sans serveur Flask démarré** : il se
branche sur l'app Flask directement via l'objet `app.test_client()` de
`api_pseudos_standalone`.

Usage ::
    python3 tests/jsonapi_pseudos.py
    python3 tests/jsonapi_pseudos.py Si Fe Eu Am
    python3 tests/jsonapi_pseudos.py --bins
    python3 tests/jsonapi_pseudos.py Si --show-errors

Critères d'un « test OK » pour une exécution :
  - la route ne 500 pas ;
  - success == True dans la réponse JSON ;
  - upf_path renseigné et conform_qe == True ;
  - returncode == 0 (quand la clé est présente).

Les runs réels lancent les binaires externes. Si un générateur est indisponible
ou si un élément est un cas connu d'échec attendu (ex. ld1 4f/5f from scratch,
APE 3d/f fragile), le test doit être marqué EXPECTED_FAIL au lieu de FAIL.
"""
from __future__ import annotations

import json
import os
import re
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

CLI = [a for a in sys.argv[1:] if not a.startswith("-")]
SHOW_ERRORS = "--show-errors" in sys.argv
ONLY_BINS = {"--bins", "-b"} & set(sys.argv)

_saved_argv = sys.argv[:]
sys.argv = ["api_pseudos_standalone", "--port", "5008"]
import api_pseudos_standalone as api  # noqa: E402
sys.argv = _saved_argv

# ══════════════════════════════════════════════════════════════════════════════
# Matrice cible
# ══════════════════════════════════════════════════════════════════════════════

DEFAULT_ELEMENTS = ["Si", "Fe", "Eu", "Am"]

EXPLETION = {
    "Si": "léger (p)",
    "Fe": "3d",
    "Eu": "4f",
    "Am": "5f",
}

# Cas d'échec “attendu” selon la logique déjà utilisée par le projet.
# ld1.x : 4f/5f from scratch c'est souvent KO.
LD1_EXPECTED_FAIL = {
    "La", "Ce", "Eu", "Gd", "Dy", "Nd", "Am", "Pu", "U", "Cm", "Bk",
}
APE_EXPECTED_FAIL = LD1_EXPECTED_FAIL | {
    "Ti", "V", "Cr", "Mn", "Co", "Ni", "Cu", "Zn",
}

TEST_TIMEOUT_S = 300


# ══════════════════════════════════════════════════════════════════════════════
# Petit helpers de notation
# ══════════════════════════════════════════════════════════════════════════════

def _z_valence(path: str | None) -> float | None:
    if not path or not os.path.isfile(path):
        return None
    try:
        txt = Path(path).read_text(encoding="utf-8", errors="replace")[:20000]
    except OSError:
        return None
    m = re.search(r'z_valence\s*=\s*["\']?([0-9.eE+-]+)', txt, re.I)
    return float(m.group(1)) if m else None


def _grade_ld1(row: dict, t0: float, element: str = "") -> dict:
    upf = row.get("upf_path") or row.get("upf_genere") or ""
    qv = row.get("qe_validation") or {}
    ok_api = bool(row.get("success"))
    rc_ok = row.get("returncode") in (0, None)
    fresh = os.path.isfile(upf) and os.path.getmtime(upf) >= (t0 - 2.0)
    conform = bool(qv.get("conform_qe") or row.get("upf_qe_ready"))
    err = (row.get("error") or row.get("diagnostic_summary") or
           (qv.get("errors") or [""])[0] or "")[:200]

    el = row.get("element") or element or "?"
    if not ok_api and not rc_ok and el in LD1_EXPECTED_FAIL and not fresh:
        status = "EXPECTED_FAIL"
    elif ok_api and conform and rc_ok and fresh:
        status = "PASS"
    elif ok_api and conform and rc_ok and upf:
        status = "PASS_UPF"
    elif not upf and not ok_api:
        status = "EXPECTED_FAIL" if el in LD1_EXPECTED_FAIL else "FAIL"
    else:
        status = "FAIL"

    return {
        "status": status,
        "success": ok_api,
        "conform_qe": conform,
        "fresh_upf": fresh,
        "upf_path": upf,
        "z_valence": _z_valence(upf) or qv.get("z_valence") or row.get("z_valence"),
        "suggested_ecutwfc_ry": qv.get("suggested_ecutwfc_ry") or row.get("suggested_ecutwfc_ry"),
        "size_kb": round(os.path.getsize(upf) / 1024, 1) if upf and os.path.isfile(upf) else 0,
        "error": err,
        "returncode": row.get("returncode"),
        "dt_s": round(time.time() - t0, 1),
    }


def _grade_non_ld1(row: dict, t0: float, expected_fail: set[str], element: str = "") -> dict:
    upf = row.get("upf_path") or row.get("upf_genere") or row.get("upf_file_detected") or ""
    if upf and not os.path.isabs(upf):
        upf = str(Path(row.get("pseudos_dir", "") or "").parent / upf) if False else upf
    qv = row.get("qe_validation") or {}
    ok_api = bool(row.get("success"))
    rc = row.get("returncode")
    rc_ok = rc in (0, None)
    fresh = os.path.isfile(upf) and os.path.getmtime(upf) >= (t0 - 2.0)
    conform = bool(qv.get("conform_qe") or row.get("upf_qe_ready"))
    err = (row.get("error") or row.get("hint") or
           (qv.get("errors") or [""])[0] or "")[:200]
    el = row.get("element") or element or "?"

    if not ok_api and el in expected_fail and not fresh:
        status = "EXPECTED_FAIL"
    elif ok_api and conform and rc_ok and fresh:
        status = "PASS"
    elif ok_api and conform and rc_ok and upf:
        status = "PASS_UPF"
    elif not upf and not ok_api:
        status = "EXPECTED_FAIL" if el in expected_fail else "FAIL"
    else:
        status = "FAIL"

    return {
        "status": status,
        "success": ok_api,
        "conform_qe": conform,
        "fresh_upf": fresh,
        "upf_path": upf,
        "z_valence": _z_valence(upf) or qv.get("z_valence") or row.get("z_valence"),
        "suggested_ecutwfc_ry": qv.get("suggested_ecutwfc_ry") or row.get("suggested_ecutwfc_ry"),
        "size_kb": round(os.path.getsize(upf) / 1024, 1) if upf and os.path.isfile(upf) else 0,
        "error": err,
        "returncode": rc,
        "dt_s": round(time.time() - t0, 1),
    }


def _print_row(name: str, row: dict) -> None:
    st = row.get("status", "?")
    zv = row.get("z_valence")
    ec = row.get("suggested_ecutwfc_ry")
    meta = ""
    if zv is not None:
        meta += f" z={zv}"
    if ec is not None:
        meta += f" ecut={ec}Ry"
    print(
        f"  [{st}] {name}  api={row.get('success')} qe={row.get('conform_qe')} "
        f"fresh={row.get('fresh_upf')} {row.get('size_kb', 0)} KB{meta} "
        f"({row.get('dt_s')}s)"
    )
    if SHOW_ERRORS and row.get("error") and st in ("FAIL", "EXPECTED_FAIL"):
        print(f"       err: {row['error'][:140]}")


# ══════════════════════════════════════════════════════════════════════════════
# Inputs de test
# ══════════════════════════════════════════════════════════════════════════════


LD1_INPUTS = {
    "Si": """ &input
    title='Si',
    zed=14.0,
    rel=0,
    config='[Ne] 3s2 3p2',
    iswitch=3,
    dft='PBE'
 /
 &inputp
   pseudotype=1,
   file_pseudopw='Si.pbe-nc.UPF',
   author='jsonapi_test',
   lloc=-1,
   rcloc=1.8,
   new_core_ps=.true.,
   rho0=0.001,
   tm=.true.
 /
 3
 3  0  2  0.00  0.00  1.8  1.8  0.0
 3  1  2  0.00  0.00  1.8  1.8  0.0
 3  2  0  0.00  0.00  1.8  1.8  0.0
""",
    "Fe": """ &input
    title='Fe',
    zed=26.0,
    rel=1,
    config='[Ar] 3d6 4s2',
    iswitch=3,
    dft='PBE'
 /
 &inputp
   pseudotype=2,
   file_pseudopw='Fe.pbe-us.UPF',
   author='jsonapi_test',
   lloc=-1,
   rcloc=2.2,
   new_core_ps=.true.,
   tm=.true.
 /
 4
 3  2  6  0.00  0.00  2.0  2.0  0.0
 4  0  2  0.00  0.00  2.2  2.2  0.0
 3  1  0  0.00  0.00  2.0  2.0  0.0
 3  0  0  0.00  0.00  2.0  2.0  0.0
 &test
   nconf=1
   file_pseudo='Fe.pbe-us.UPF'
   configts(1)='3d6 4s2'
 /
""",
}


def _issue_ld1_input(client, element: str, z_expected: int) -> str:
    """Utilise l'API d'entrée ld1 quand un gabarit dédié n'est pas fourni."""
    r = client.get(f"/api/pseudos/auto_inputs?element={element}&dft=PBE")
    auto = r.get_json() or {}
    ld1 = (auto.get("ld1_input") or "").strip()
    if ld1 and _looks_like_ld1(ld1):
        return ld1
    return ""


def _looks_like_ld1(text: str) -> bool:
    return bool(re.search(r"^\s*&\s*input\b", text, re.M | re.I))


def _oncv_input(client, element: str, z_expected: int) -> str:
    """Gabarit ONCV dédié : cache local > auto_input > template API."""
    candidates = [
        ROOT / "oncv_templates_3d" / f"{element}.dat",
        ROOT / f"oncv_default_{element}.dat",
        ROOT / "data" / "oncv" / f"oncv_default_{element}.dat",
        ROOT / "data" / "oncvpsp_tests_data" / f"{z_expected:02d}_{element}.dat",
    ]
    for c in candidates:
        if c.is_file():
            txt = c.read_text(encoding="utf-8", errors="replace")
            head = "\n".join(txt.splitlines()[:10]).lower()
            if element.lower() in head or f"{z_expected}." in c.name or f"{z_expected}_" in c.name:
                return txt
    r = client.get(f"/api/pseudos/auto_inputs?element={element}&xc=gga_pbe&f_treatment=open_core")
    j = r.get_json() or {}
    oncv = (j.get("oncv_input_dat") or "").strip()
    if oncv and "# ATOM AND REFERENCE" in oncv:
        return oncv
    r2 = client.get(f"/api/pseudos/oncv_input_template?element={element}&z={z_expected}")
    if r2.status_code == 200:
        tpl = r2.get_data(as_text=True) or ""
        if "# ATOM AND REFERENCE" in tpl:
            head = "\n".join(tpl.splitlines()[:12]).lower()
            if re.search(rf"\b{element.lower()}\b", head):
                return tpl
    return ""


# ══════════════════════════════════════════════════════════════════════════════
# Un run par générateur
# ══════════════════════════════════════════════════════════════════════════════


def run_ld1(client, element: str) -> dict:
    t0 = time.time()
    try:
        ld1_in = LD1_INPUTS.get(element) or _issue_ld1_input(client, element, 14)
        if not ld1_in:
            return {
                "status": "FAIL",
                "error": "pas d'entrée ld1 pour cet élément",
                "dt_s": round(time.time() - t0, 1),
            }
        resp = client.post(
            "/api/pseudos/generer_ld1",
            json={"element": element, "input": ld1_in, "regenerate_input": True},
        )
        j = resp.get_json() or {}
        row = _grade_ld1(j, t0, element)
    except Exception as e:
        row = {
            "status": "FAIL",
            "error": str(e)[:200],
            "success": False,
            "conform_qe": False,
            "fresh_upf": False,
            "upf_path": "",
            "size_kb": 0,
        }
        row["dt_s"] = round(time.time() - t0, 1)
    return row


def run_ape(client, element: str) -> dict:
    t0 = time.time()
    expected_fail = APE_EXPECTED_FAIL
    try:
        body = {
            "element": element,
            "auto_generate": True,
            "xc": "lda_pw",
            "relativistic": True,
            "semicore": True,
            "rc_scale": 1.25 if element in ("Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn") or element in LD1_EXPECTED_FAIL else 1.0,
        }
        if element in LD1_EXPECTED_FAIL:
            body["f_treatment"] = "open_core"
        resp = client.post("/api/pseudos/run_ape", json=body)
        j = resp.get_json() or {}
        row = _grade_non_ld1(j, t0, expected_fail, element)

        # APE est souvent en 2 étapes (ae puis pp). Si échec avec continue_dir,
        # on tente la continuation automatique.
        if not j.get("success") and j.get("work_dir") and "continue" in (
            (j.get("hint") or "") + (j.get("error") or "")
        ).lower():
            try:
                resp2 = client.post(
                    "/api/pseudos/run_ape",
                    json={
                        "element": element,
                        "continue_dir": j["work_dir"],
                        "auto_generate": False,
                        "xc": "lda_pw",
                    },
                )
                j2 = resp2.get_json() or {}
                if j2.get("success"):
                    row = _grade_non_ld1(j2, t0, expected_fail, element)
            except Exception:
                pass
    except Exception as e:
        row = {
            "status": "FAIL",
            "error": str(e)[:200],
            "success": False,
            "conform_qe": False,
            "fresh_upf": False,
            "upf_path": "",
            "size_kb": 0,
        }
        row["dt_s"] = round(time.time() - t0, 1)
    return row


def run_atompaw(client, element: str) -> dict:
    t0 = time.time()
    try:
        body = {
            "element": element,
            "auto_generate": True,
            "format": "interactive",
            "relativistic": True,
            "semicore": True,
            "xc": "gga_pbe",
            "pp_type": "hamann",
        }
        if element in LD1_EXPECTED_FAIL:
            body["f_treatment"] = "open_core"
        resp = client.post("/api/pseudos/run_atompaw", json=body)
        j = resp.get_json() or {}
        row = _grade_non_ld1(j, t0, set(), element)
    except Exception as e:
        row = {
            "status": "FAIL",
            "error": str(e)[:200],
            "success": False,
            "conform_qe": False,
            "fresh_upf": False,
            "upf_path": "",
            "size_kb": 0,
        }
        row["dt_s"] = round(time.time() - t0, 1)
    return row


def run_oncvpsp(client, element: str) -> dict:
    t0 = time.time()
    try:
        oncv = _oncv_input(client, element, 14)
        if not oncv:
            return {
                "status": "FAIL",
                "error": "pas de gabarit ONCV pour cet élément",
                "success": False,
                "conform_qe": False,
                "fresh_upf": False,
                "upf_path": "",
                "size_kb": 0,
                "dt_s": round(time.time() - t0, 1),
            }
        resp = client.post(
            "/api/pseudos/run_oncvpsp",
            json={"element": element, "input": oncv},
        )
        j = resp.get_json() or {}
        row = _grade_non_ld1(j, t0, set(), element)
    except Exception as e:
        row = {
            "status": "FAIL",
            "error": str(e)[:200],
            "success": False,
            "conform_qe": False,
            "fresh_upf": False,
            "upf_path": "",
            "size_kb": 0,
        }
        row["dt_s"] = round(time.time() - t0, 1)
    return row


# ══════════════════════════════════════════════════════════════════════════════
# Bins + metadata
# ══════════════════════════════════════════════════════════════════════════════


def bins_status() -> dict[str, dict]:
    try:
        client = api.app.test_client()
    except Exception:
        return {}
    bins = {
        "ld1.x": {"env": bool(api._resolve_ld1_bin()), "route": None},
        "APE": {"env": bool(api._resolve_ape_bin_sa()), "route": "/api/pseudos/ape_status"},
        "ATOMPAW": {"env": bool(api._resolve_atompaw_bin_sa()), "route": "/api/pseudos/atompaw_status"},
        "ONCVPSP": {"env": bool(api._resolve_oncvpsp_bin()), "route": "/api/pseudos/oncv_status"},
    }
    for gen, info in bins.items():
        if info["route"]:
            try:
                r = client.get(info["route"])
                j = r.get_json() or {}
                info["available"] = bool(j.get("available"))
                info["path"] = j.get("path") or info.get("path")
            except Exception:
                info["available"] = False
    return bins


# ══════════════════════════════════════════════════════════════════════════════
# Point d'entrée
# ══════════════════════════════════════════════════════════════════════════════


def main() -> int:
    elements = CLI or DEFAULT_ELEMENTS
    print("TESTS GÉNÉRATORS (jsonapi_pseudos.py)")
    print(f"Projet : {ROOT}")
    print(f"Build  : {getattr(api, 'API_BUILD_TAG', '?')}")
    print("Éléments :", ", ".join(f"{e} ({EXPLETION.get(e, '?')})" for e in elements))

    bins = bins_status()
    if ONLY_BINS:
        print("\nBINAIRES")
        for name, info in bins.items():
            ok = info.get("available", info.get("env", False))
            print(f"  {name:<10} {'OK' if ok else 'ABSENT'}  {info.get('path') or info.get('env')}")
        return 0

    print("\nBINAIRES")
    for name, info in bins.items():
        ok = info.get("available", info.get("env", False))
        print(f"  {name:<10} {'OK' if ok else 'ABSENT'}  {info.get('path') or info.get('env')}")

    client = api.app.test_client()
    tout = {el: {} for el in elements}
    fails: list[str] = []
    passes: list[str] = []

    print()
    for el in elements:
        print(f"\n{'=' * 72}\n  {el}  ({EXPLETION.get(el, '?')})\n{'=' * 72}")

        row_ld1 = run_ld1(client, el)
        tout[el]["ld1.x"] = row_ld1
        _print_row("ld1.x", row_ld1)

        row_ape = run_ape(client, el)
        tout[el]["APE"] = row_ape
        _print_row("APE", row_ape)

        row_aw = run_atompaw(client, el)
        tout[el]["ATOMPAW"] = row_aw
        _print_row("ATOMPAW", row_aw)

        row_oncv = run_oncvpsp(client, el)
        tout[el]["ONCVPSP"] = row_oncv
        _print_row("ONCVPSP", row_oncv)

    print(f"\n{'=' * 72}\nSYNTHÈSE\n{'=' * 72}")
    counts = {"PASS": 0, "PASS_UPF": 0, "EXPECTED_FAIL": 0, "FAIL": 0}
    by_tool: dict[str, dict[str, int]] = {
        k: {"PASS": 0, "PASS_UPF": 0, "EXPECTED_FAIL": 0, "FAIL": 0}
        for k in ("ld1.x", "APE", "ATOMPAW", "ONCVPSP")
    }
    for el, tools in tout.items():
        for name, row in tools.items():
            st = row.get("status", "FAIL")
            counts[st] = counts.get(st, 0) + 1
            by_tool[name][st] = by_tool[name].get(st, 0) + 1
            print(
                f"  {el:<5} {EXPLETION.get(el, '?'):<12} {name:<10} "
                f"{st:<14} {'OK' if row.get('conform_qe') else '—':<4} "
                f"{row.get('size_kb', 0) or '—':<6} {row.get('dt_s', '—')}"
            )

    n_pass = counts["PASS"] + counts["PASS_UPF"]
    n_tot = sum(counts.values())
    n_fail = counts["FAIL"]
    print("\n" + "—" * 72)
    print(
        f"PASS={counts['PASS']}  PASS_UPF={counts['PASS_UPF']}  "
        f"EXPECTED_FAIL={counts['EXPECTED_FAIL']}  FAIL={counts['FAIL']}"
    )
    print(f"Score utile : {n_pass + counts['EXPECTED_FAIL']}/{n_tot}  "
          f"(échecs réels : {n_fail})")
    for tool, st in by_tool.items():
        ok = st.get("PASS", 0) + st.get("PASS_UPF", 0)
        exp = st.get("EXPECTED_FAIL", 0)
        fail = st.get("FAIL", 0)
        print(f"  {tool:<10} OK {ok}/{ok+exp+fail}  "
              f"(expected_fail={exp}, fail={fail})")

    if counts["FAIL"] > 0:
        print("\nÉCHECS INATTENDUS (FAIL) :")
        for el, tools in tout.items():
            for name, row in tools.items():
                if row.get("status") == "FAIL":
                    fails.append(f"{el}/{name}")
                    print(f"  FAIL {el}/{name}  {row.get('error') or ''}")

        for el, tools in tout.items():
            for name, row in tools.items():
                if row.get("status") == "PASS_UPF":
                    print(f"  PASS_UPF (pas frais) {el}/{name}  {row.get('upf_path')}")

    out_path = ROOT / "logs" / "jsonapi_pseudos.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(
            {
                "build_tag": getattr(api, "API_BUILD_TAG", "?"),
                "bins": {k: dict(v) for k, v in bins.items()},
                "elements": elements,
                "counts": counts,
                "by_tool": by_tool,
                "score_useful": f"{n_pass + counts['EXPECTED_FAIL']}/{n_tot}",
                "real_failures": n_fail,
                "results": tout,
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    print(f"\nJSON → {out_path}")

    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())

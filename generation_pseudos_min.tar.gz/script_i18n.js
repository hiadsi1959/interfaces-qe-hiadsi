/**
 * i18n global Fr/En — Pseudopotential Generator
 * Usage : window.setGpLang('en'|'fr') ; window.gpT('key')
 * Persistence : localStorage gp_ui_lang
 */
(function (global) {
    'use strict';

    var STORAGE_KEY = 'gp_ui_lang';

    var DICT = {
        fr: {
            'doc.title': 'Génération des Pseudopotentiels — QE',
            'header.title': 'Génération des Pseudopotentiels',
            'header.version': 'version 1.4',
            'header.subtitle': 'Tableau périodique interactif — ld1.x · ATOMPAW · APE · Autres bases · ONCVPSP',
            'author.title': 'Afficher les coordonnées',
            'api.paths': 'Chemins PC',
            'api.paths.title': 'Détail autonomie : ./bin/ (ld1, ape, atompaw, oncvpsp) + dossiers sortie',
            'api.history': 'Historique',
            'api.history.title': 'Historique des générations (pseudos-*/_runs)',
            'api.compare': 'Comparer UPF',
            'api.compare.title': 'Comparer deux fichiers UPF',
            'api.wizard': 'Assistant guidé',
            'api.wizard.title': 'Parcours guidé pas à pas',
            'api.catalog': 'Catalogue pseudos',
            'api.catalog.title': 'Guide type de pseudo / générateur / utilisation',
            'api.status': 'API autonome (port 5008)…',
            'api.autonomie': 'Autonomie…',
            'api.autonomie.title': '4 générateurs sous ./bin/',
            'api.pseudos': 'Pseudos :',
            'api.loading': 'chargement…',
            'portal.summary.title': 'Ressources officielles — pas besoin de sélectionner un élément',
            'legend.alkali': 'Alcalins',
            'legend.alkaline': 'Alcalino-terreux',
            'legend.transition': 'Métaux transition',
            'legend.metals': 'Métaux',
            'legend.metalloids': 'Métalloïdes',
            'legend.nonmetals': 'Non-métaux',
            'legend.halogens': 'Halogènes',
            'legend.noble': 'Gaz nobles',
            'legend.lanthanides': 'Lanthanides',
            'legend.actinides': 'Actinides',
            'tab.ld1x': 'ld1.x',
            'tab.atompaw': 'ATOMPAW',
            'tab.ape': 'APE',
            'tab.autresbases': 'Autres bases',
            'tab.oncvpsp': 'ONCVPSP',
            'portal.summary': 'Hors ld1.x — sources, téléchargements & outils',
            'lang.fr': 'Fr',
            'lang.en': 'En',
            'lang.label': 'Langue',
            'theme.label': 'Thème',
            'theme.light': 'Clair',
            'theme.dark': 'Sombre',
            'theme.light.title': 'Thème clair',
            'theme.dark.title': 'Thème sombre',
        },
        en: {
            'doc.title': 'Pseudopotential Generation — QE',
            'header.title': 'Pseudopotential Generation',
            'header.version': 'version 1.4',
            'header.subtitle': 'Interactive periodic table — ld1.x · ATOMPAW · APE · Other libraries · ONCVPSP',
            'author.title': 'Show contact details',
            'api.paths': 'PC paths',
            'api.paths.title': 'Standalone detail: ./bin/ (ld1, ape, atompaw, oncvpsp) + output folders',
            'api.history': 'History',
            'api.history.title': 'Generation history (pseudos-*/_runs)',
            'api.compare': 'Compare UPF',
            'api.compare.title': 'Compare two UPF files',
            'api.wizard': 'Guided assistant',
            'api.wizard.title': 'Step-by-step guided workflow',
            'api.catalog': 'Pseudo catalogue',
            'api.catalog.title': 'Guide: pseudo type / generator / use case',
            'api.status': 'Standalone API (port 5008)…',
            'api.autonomie': 'Autonomy…',
            'api.autonomie.title': '4 generators under ./bin/',
            'api.pseudos': 'Pseudos:',
            'api.loading': 'loading…',
            'portal.summary.title': 'Official resources — no element selection needed',
            'legend.alkali': 'Alkali metals',
            'legend.alkaline': 'Alkaline earths',
            'legend.transition': 'Transition metals',
            'legend.metals': 'Metals',
            'legend.metalloids': 'Metalloids',
            'legend.nonmetals': 'Non-metals',
            'legend.halogens': 'Halogens',
            'legend.noble': 'Noble gases',
            'legend.lanthanides': 'Lanthanides',
            'legend.actinides': 'Actinides',
            'tab.ld1x': 'ld1.x',
            'tab.atompaw': 'ATOMPAW',
            'tab.ape': 'APE',
            'tab.autresbases': 'Other libraries',
            'tab.oncvpsp': 'ONCVPSP',
            'portal.summary': 'Beyond ld1.x — sources, downloads & tools',
            'lang.fr': 'Fr',
            'lang.en': 'En',
            'lang.label': 'Language',
            'theme.label': 'Theme',
            'theme.light': 'Light',
            'theme.dark': 'Dark',
            'theme.light.title': 'Light theme',
            'theme.dark.title': 'Dark theme',
        },
    };

    function normalizeLang(lang) {
        return (String(lang || '').toLowerCase() === 'en') ? 'en' : 'fr';
    }

    function getLang() {
        try {
            var stored = localStorage.getItem(STORAGE_KEY);
            if (stored) return normalizeLang(stored);
        } catch (e) { /* ignore */ }
        return normalizeLang(global.gpLang || 'fr');
    }

    function t(key, lang) {
        var L = normalizeLang(lang || getLang());
        var pack = DICT[L] || DICT.fr;
        if (pack[key] != null) return pack[key];
        if (DICT.fr[key] != null) return DICT.fr[key];
        return key;
    }

    function paintLangButtons(lang) {
        var L = normalizeLang(lang);
        var fr = document.getElementById('gp_lang_btn_fr');
        var en = document.getElementById('gp_lang_btn_en');
        function style(btn, active) {
            if (!btn) return;
            btn.setAttribute('aria-pressed', active ? 'true' : 'false');
            btn.classList.toggle('gp-lang-btn--active', !!active);
        }
        style(fr, L === 'fr');
        style(en, L === 'en');
    }

    function applyToDom(lang) {
        var L = normalizeLang(lang);
        document.documentElement.setAttribute('lang', L);
        document.title = t('doc.title', L);

        document.querySelectorAll('[data-i18n]').forEach(function (el) {
            var key = el.getAttribute('data-i18n');
            if (!key) return;
            var val = t(key, L);
            var attr = el.getAttribute('data-i18n-attr');
            if (attr) {
                el.setAttribute(attr, val);
            } else if (el.getAttribute('data-i18n-html') === '1') {
                el.innerHTML = val;
            } else {
                el.textContent = val;
            }
        });
        document.querySelectorAll('[data-i18n-attr-title]').forEach(function (el) {
            var key = el.getAttribute('data-i18n-attr-title');
            if (key) el.setAttribute('title', t(key, L));
        });

        // Title composed of title + version span
        var h1 = document.getElementById('gp_header_title');
        if (h1) {
            var ver = h1.querySelector('.gp-header-version');
            h1.childNodes.forEach(function (node) {
                if (node.nodeType === 3) node.textContent = '';
            });
            // rebuild safely
            var versionHtml = ver
                ? ver.outerHTML
                : '<span class="gp-header-version" data-i18n="header.version" style="font-weight:500;opacity:0.85;font-size:0.55em;letter-spacing:0.04em;vertical-align:middle;">'
                    + t('header.version', L) + '</span>';
            h1.innerHTML = t('header.title', L) + ' ' + versionHtml;
            var verEl = h1.querySelector('[data-i18n="header.version"]');
            if (verEl) verEl.textContent = t('header.version', L);
        }

        paintLangButtons(L);
    }

    function setGpLang(lang, opts) {
        var L = normalizeLang(lang);
        var prev = getLang();
        global.gpLang = L;
        global.gpOncv4fLang = L; // sync note 4f ONCV
        try { localStorage.setItem(STORAGE_KEY, L); } catch (e) { /* ignore */ }
        applyToDom(L);
        try {
            global.dispatchEvent(new CustomEvent('gp:langchange', { detail: { lang: L, prev: prev } }));
        } catch (e2) { /* old browsers */ }
        if (typeof global.setOncv4fLang === 'function' && !(opts && opts.skipOncv)) {
            try { global.setOncv4fLang(L); } catch (e3) { /* panel may be closed */ }
        }
        return L;
    }

    global.gpI18n = {
        t: t,
        getLang: getLang,
        setLang: setGpLang,
        dict: DICT,
    };
    global.gpT = t;
    global.setGpLang = setGpLang;
    global.getGpLang = getLang;

    function boot() {
        var L = getLang();
        global.gpLang = L;
        global.gpOncv4fLang = L;
        applyToDom(L);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})(window);

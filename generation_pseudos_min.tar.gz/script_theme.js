/**
 * Thème dark / light — Pseudopotential Generator
 * Usage : window.setGpTheme('dark'|'light') ; window.toggleGpTheme()
 * Persistence : localStorage gp_ui_theme
 */
(function (global) {
    'use strict';

    var STORAGE_KEY = 'gp_ui_theme';

    function normalizeTheme(theme) {
        return (String(theme || '').toLowerCase() === 'dark') ? 'dark' : 'light';
    }

    function getTheme() {
        try {
            var stored = localStorage.getItem(STORAGE_KEY);
            if (stored) return normalizeTheme(stored);
        } catch (e) { /* ignore */ }
        return normalizeTheme(global.gpTheme || 'light');
    }

    function paintThemeButtons(theme) {
        var T = normalizeTheme(theme);
        var light = document.getElementById('gp_theme_btn_light');
        var dark = document.getElementById('gp_theme_btn_dark');
        function style(btn, active) {
            if (!btn) return;
            btn.setAttribute('aria-pressed', active ? 'true' : 'false');
            btn.classList.toggle('gp-lang-btn--active', !!active);
        }
        style(light, T === 'light');
        style(dark, T === 'dark');
    }

    function applyTheme(theme) {
        var T = normalizeTheme(theme);
        var root = document.documentElement;
        root.setAttribute('data-theme', T);
        root.style.colorScheme = T;
        paintThemeButtons(T);
    }

    function setGpTheme(theme, opts) {
        var T = normalizeTheme(theme);
        var prev = getTheme();
        global.gpTheme = T;
        try { localStorage.setItem(STORAGE_KEY, T); } catch (e) { /* ignore */ }
        applyTheme(T);
        if (!(opts && opts.silent)) {
            try {
                global.dispatchEvent(new CustomEvent('gp:themechange', { detail: { theme: T, prev: prev } }));
            } catch (e2) { /* old browsers */ }
        }
        return T;
    }

    function toggleGpTheme() {
        return setGpTheme(getTheme() === 'dark' ? 'light' : 'dark');
    }

    global.gpThemeApi = {
        getTheme: getTheme,
        setTheme: setGpTheme,
        toggle: toggleGpTheme,
    };
    global.setGpTheme = setGpTheme;
    global.getGpTheme = getTheme;
    global.toggleGpTheme = toggleGpTheme;

    function boot() {
        var T = getTheme();
        global.gpTheme = T;
        applyTheme(T);
    }

    // Apply ASAP if DOM already has buttons; otherwise wait
    applyTheme(getTheme());
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})(window);

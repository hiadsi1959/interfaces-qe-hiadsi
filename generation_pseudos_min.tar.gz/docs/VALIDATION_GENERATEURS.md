# Validation des générateurs (3d / 4f / 5f)

## Lancer la vérification

```bash
python3 tests/validation_generators_full.py
# ou éléments ciblés :
python3 tests/validation_generators_full.py Fe Eu Am
```

Rapport JSON : `logs/validation_generators_full.json`

## Matrice par défaut

| Élément | Famille | Rôle |
|---------|---------|------|
| Si | léger (p) | ld1 · APE · ATOMPAW · ONCV |
| Fe | 3d | métal de transition |
| Eu | 4f | lanthanide open_core |
| Am | 5f | actinide open_core |

## Verdict attendu (2026-08-30)

| Générateur | Si | Fe | Eu | Am |
|------------|----|----|----|-----|
| **ld1.x** | PASS | PASS (PAW) | EXPECTED_FAIL | EXPECTED_FAIL |
| **APE** | PASS | EXPECTED_FAIL | EXPECTED_FAIL | EXPECTED_FAIL |
| **ATOMPAW** | PASS | PASS | PASS | PASS |
| **ONCVPSP** | PASS | PASS_UPF | PASS_UPF | PASS_UPF |

- **PASS** : UPF frais + conforme QE
- **PASS_UPF** : UPF conforme (workdir réutilisé, mtime non mis à jour)
- **EXPECTED_FAIL** : échec connu (ld1 4f/5f ; APE sur 3d/f)

## Recommandations production

- **3d (Sc–Zn)** : ld1 PAW/US, ATOMPAW, ONCV — éviter APE NC
- **4f (La–Lu)** : ATOMPAW, ONCV open_core, catalogue PseudoDojo/PSLibrary — ld1 from scratch instable
- **5f (Ac–Lr)** : ATOMPAW, ONCV open_core — ld1 rarement fiable

Build API attendu : `2026-10-21-v16` (badge Diagnostic API).

## Contrôle des gabarits ONCVPSP — v1.4 (2026-10-21)

```bash
python3 tests/verifier_gabarits_oncvpsp.py --jobs 4     # 113 gabarits, 6 dossiers
python3 tests/verifier_exotic_oncv.py                   # 20 exotiques + transférabilité
```

| Contrôle | Résultat v1.4 |
|---|---|
| Exécution `oncvpsp.x` (6 dossiers, 113 gabarits) | **113/113 OK**, 0 échec, 0 binaire manquant |
| `GHOST(-)` (états liés fantômes) | **0** sur les 113 gabarits |
| `GHOST(+)` (états localisés à énergie positive) | 43 gabarits, **non bloquant** (présent aussi dans les gabarits officiels : `83_Bi`, `56_Ba`, `80_Hg`) |
| Suite exotiques Fr–Og | **17/20** ; `Lv`, `Ts`, `Og` : transférabilité `0.022–0.029 Ha > 0.02 Ha`, sans ghost |
| `Nh` (corrigé en v1.4) | `GHOST(+) = 0`, `GHOST(-) = 0`, transfert `8.5e-3 Ha` |
| `pw.x` SCF sur `Nh_oncv.UPF` | `JOB DONE`, 6 itérations, `E = -106.04311334 Ry` |
| Matrice 4 générateurs (Si/Fe/Eu/Am) | `PASS=11`, `EXPECTED_FAIL=5`, `FAIL=0` (échecs réels : 0) |

Correction v1.4 des bandes fantômes : le canal `s` de `Nh` utilisait `nbas = 7` (borne basse
`ncon + 3`) → `GHOST(+)` à `<r>/rc ≈ 0.99`. La famille `p7` (`exotic_nc.py`, Nh–Og) passe à
`nbas = (8, 7, 8, 8)` ; balayage `nbas(s) = 6…14` : seul `7` produisait le ghost.

# Installation sur un autre PC Linux (avec Quantum ESPRESSO)

Interface **autonome** : une seule API sur le port **5008** sert l’interface web et toutes les fonctions (ld1, APE, ATOMPAW, ONCV, bibliothèques). Aucune dépendance à Interface-QE ni au port 5007.

## Prérequis

| Composant | Obligatoire | Rôle |
|-----------|-------------|------|
| **Linux** (Ubuntu / Debian recommandé) | oui | Environnement cible |
| **Paquets système** : `python3`, `python3-pip`, `curl`, `lsof`, `ca-certificates`, un navigateur (ou `xdg-utils`) | oui | API + interface web (`./configure.sh` les installe si `sudo` non interactif est disponible) |
| **Python 3** + `flask`, `flask-cors`, `requests` | oui | API `api_pseudos_standalone.py` (`./configure.sh` les installe via `pip` si absents) |
| **Générateurs + bibliothèques** (`ld1.x`, `pw.x`, `oncvpsp.x`, `ape`, `atompaw` + `lib/`) | **non** | **Inclus** (`bin/` + `lib/`) dans le fichier unique et le dossier |

Sur un PC vierge, une seule commande suffit donc à installer ces prérequis :

```bash
./configure.sh          # paquets système (sudo) + pip + chemins
./configure.sh --no-install   # chemins seulement (PC hors ligne)
```

## 1. Transférer sur l’autre PC

### Option A — Un seul fichier (recommandé)

Sur le PC source :

```bash
./build_installer.sh
# → dist/generation_pseudos  (≈ 105 Mo, interface + API + 4 générateurs + bibliothèques)
```

Copiez **ce fichier seul** (USB, scp, e-mail…).

Sur le PC cible :

```bash
chmod +x generation_pseudos
./generation_pseudos
# installation permanente dans ~/.local/bin/ :
./generation_pseudos --install
```

L’application s’installe dans `~/.local/share/generation_pseudos/app/` et se configure automatiquement. Les 4 générateurs (`ld1.x`, `oncvpsp.x`, `ape`, `atompaw`), `pw.x` (`bin/`) **et leurs bibliothèques dynamiques** (`lib/` : MKL, Intel MPI, libxc, GSL) sont **embarqués** — aucune installation supplémentaire n’est nécessaire (Python 3 + Flask suffisent).

### Option B — Copie du dossier complet

**Guide :** **[TRANSFERT_AUTRE_PC.md](TRANSFERT_AUTRE_PC.md)**

```bash
./TRANSFERER_VERS_AUTRE_PC.sh --leger --dest utilisateur@IP -y
```

Sur le PC cible :

```bash
tar xzf generation_pseudos_*.tar.gz && cd generation_pseudos
./GenerationPseudos
```

## 2. Configurer le nouveau PC

Workflow simple (dossier copié) :

```bash
chmod +x configure.sh DEMARRER.sh
./configure.sh    # une fois
./DEMARRER.sh     # à chaque utilisation
```

`configure.sh` :

1. Vérifie et installe les **prérequis système** de l’interface (`python3`, `python3-pip`, `curl`, `lsof`, `ca-certificates`, navigateur / `xdg-utils`) via `sudo` si disponible — sinon il affiche la commande exacte à lancer  
2. Vérifie et installe les **dépendances Python** (`flask`, `flask-cors`, `requests`) via `requirements.txt`  
3. Supprime les liens symboliques cassés de `bin/` (archive copiée sans `third_party/`)  
4. Détecte `pw.x` / `ld1.x` (Quantum ESPRESSO, optionnel) et ONCVPSP, APE, ATOMPAW  
5. Vérifie les **bibliothèques embarquées** `lib/` (`ldd` : aucune dépendance manquante)  
6. Crée les **4 dossiers de sortie** : `pseudos-ld1/`, `pseudos-APE/`, `pseudos-atompaw/`, `pseudos-oncvpsp/`  
7. Met à jour `api_config.json` en **chemins relatifs au projet** (portables d’un PC à l’autre) et purge les chemins absolus hérités d’une autre machine  
8. Vérifie les fichiers requis par l’interface  

Variantes :

```bash
# Chemins explicites, sans questions
./configure.sh --qe ~/q-e-qe-7.5/bin --pseudos ~/generation_pseudos/pseudos -y

# Configure et démarre en une commande
./configure.sh --start

# Diagnostic seulement
./configure.sh --check-only
```

`config_pc.sh` est un alias de `configure.sh` (rétrocompatibilité).

## 3. Configuration manuelle (`api_config.json`)

```bash
cp api_config.local.json.example api_config.json
# éditer qe_bin, oncvpsp_bin, ape_bin, atompaw_bin, pseudos_dir
# → chemins RELATIFS à la racine du projet (bin, bin/ld1.x, pseudos…) :
#   ils restent valides après copie du dossier sur un autre PC.
#   Un chemin absolu (ex. /home/user/q-e-qe-7.5/bin) n’est utile que pour un
#   prérequis installé hors du dossier ; s’il n’existe pas ici, configure.sh
#   le supprime et redétecte automatiquement.
```

Variables d’environnement (alternative) :

```bash
export QE_BIN=~/q-e-qe-7.5/bin
export GEN_PORT=5008
export ONCVPSP_BIN=~/oncvpsp/build/bin/oncvpsp.x
./DEMARRER.sh
```

## 4. Utilisation

1. `./DEMARRER.sh`  
2. Ouvrir **http://127.0.0.1:5008/**  
3. Ne **pas** ouvrir `index.html` en `file://`  

Arrêt : `./ARRETER.sh`

## 5. Structure des sauvegardes

| Dossier | Contenu |
|---------|---------|
| `pseudos-ld1/` | UPF générés par ld1.x |
| `pseudos-APE/` | UPF générés par APE |
| `pseudos-atompaw/` | UPF générés par ATOMPAW |
| `pseudos-oncvpsp/` | UPF générés par ONCVPSP |
| `pseudos-telecharges/` | Imports catalogue (PseudoDojo, SSSP, …) |
| `pseudos/` | Bibliothèque commune pour `pw.x` |

Fichiers non conformes QE : `pseudos-*/_non_conforme_QE/`.  
Archives de runs : `pseudos-*/_runs/`.

## 6. Dépannage

| Problème | Action |
|----------|--------|
| Page blanche / pas de CSS | `http://127.0.0.1:5008/`, pas `file://` |
| « API hors ligne » | `lsof -i:5008` puis `./DEMARRER.sh` |
| `ld1.x non trouvé` | `./configure.sh --qe /chemin/qe/bin` |
| ONCV indisponible | `./configure.sh` ou `oncvpsp_bin` dans `api_config.json` |
| Fichiers UI manquants | `./configure.sh --check-only` |
| `flask` / `curl` / `lsof` absents | `./configure.sh` (installe les prérequis) ou `sudo apt-get install -y python3-pip curl lsof` |
| Chemins d’un autre PC dans `api_config.json` | `./configure.sh` (purge + redétection, chemins relatifs) |
| `ldd bin/*` : « not found » | `./configure.sh` ; sinon relancer `./scripts/vendor_libs.sh` sur le PC source et retransférer `lib/` |

Logs : `logs/api_pseudos_standalone.log`

## Contact

Prof. S. Hiadsi — LMESM, USTO-MB — said.hiadsi@univ-usto.dz

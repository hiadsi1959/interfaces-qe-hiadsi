#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Génère Word + PowerPoint FR/EN — 4 générateurs + autres bases."""
from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from pptx import Presentation
from pptx.dml.color import RGBColor as PptRGB
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.util import Inches, Pt as PptPt

# ── Palette ────────────────────────────────────────────────────────────────
NAVY = RGBColor(0x0B, 0x1F, 0x3A)
TEAL = RGBColor(0x0F, 0x76, 0x6E)
GOLD = RGBColor(0xC9, 0xA2, 0x27)
SLATE = RGBColor(0x47, 0x55, 0x69)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
LD1 = RGBColor(0x1E, 0x49, 0x76)
APE = RGBColor(0x04, 0x78, 0x57)
APAW = RGBColor(0xB4, 0x53, 0x09)
ONCV = RGBColor(0x0E, 0x74, 0x90)
PSL = RGBColor(0x6B, 0x21, 0xA8)
PDO = RGBColor(0xC2, 0x41, 0x0C)
SSSP = RGBColor(0xB9, 0x1C, 0x1C)

PN = PptRGB(0x0B, 0x1F, 0x3A)
PT = PptRGB(0x0F, 0x76, 0x6E)
PG = PptRGB(0xC9, 0xA2, 0x27)
PS = PptRGB(0x47, 0x55, 0x69)
PW = PptRGB(0xFF, 0xFF, 0xFF)
PBG = PptRGB(0xF4, 0xF7, 0xFB)
ICE = PptRGB(0xE8, 0xF4, 0xF8)
P_LD1 = PptRGB(0x1E, 0x49, 0x76)
P_APE = PptRGB(0x04, 0x78, 0x57)
P_APAW = PptRGB(0xB4, 0x53, 0x09)
P_ONCV = PptRGB(0x0E, 0x74, 0x90)
P_PSL = PptRGB(0x6B, 0x21, 0xA8)
P_PDO = PptRGB(0xC2, 0x41, 0x0C)
P_SSSP = PptRGB(0xB9, 0x1C, 0x1C)

FONT_TITLE = "Cambria"
FONT_BODY = "Calibri"
FONT_EQ = "Cambria Math"
FONT_CODE = "Consolas"

OUT = Path(__file__).resolve().parent / "support_theorique"

# ── Word helpers ───────────────────────────────────────────────────────────


def _run(run, *, size=11, bold=False, color=NAVY, italic=False, name=FONT_BODY):
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    run.font.name = name
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn("w:ascii"), name)
    rfonts.set(qn("w:hAnsi"), name)
    rfonts.set(qn("w:eastAsia"), name)


def _p(doc, text, *, size=11, bold=False, color=NAVY, italic=False, after=8, align=None, name=FONT_BODY):
    p = doc.add_paragraph()
    p.alignment = align or WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    r = p.add_run(text)
    _run(r, size=size, bold=bold, color=color, italic=italic, name=name)
    return p


def _shade(cell, hex_color: str):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = tcPr.makeelement(qn("w:shd"), {qn("w:fill"): hex_color, qn("w:val"): "clear"})
    tcPr.append(shd)


def _cell(cell, text, *, bold=False, color=NAVY, size=10, fill=None, center=False, name=FONT_BODY):
    cell.text = ""
    p = cell.paragraphs[0]
    if center:
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(text)
    _run(r, size=size, bold=bold, color=color, name=name)
    if fill:
        _shade(cell, fill)


def _table(doc, headers, rows, col_w=None, head="0B1F3A"):
    t = doc.add_table(rows=1 + len(rows), cols=len(headers))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        _cell(t.rows[0].cells[i], h, bold=True, color=WHITE, fill=head, center=True, size=10)
    for r, row in enumerate(rows):
        fill = "E8F4F8" if r % 2 == 0 else "FFFFFF"
        for c, val in enumerate(row):
            _cell(t.rows[r + 1].cells[c], val, fill=fill, size=9)
    if col_w:
        for row in t.rows:
            for i, w in enumerate(col_w):
                row.cells[i].width = Cm(w)
    doc.add_paragraph()
    return t


def _heading(doc, text, level=1, center=True):
    p = doc.add_heading(text, level=level)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER if center else WD_ALIGN_PARAGRAPH.LEFT
    for run in p.runs:
        run.font.color.rgb = TEAL if level > 1 else NAVY
        run.font.name = FONT_TITLE
        run.font.size = Pt(18 if level == 1 else 14)
    return p


def _formula(doc, name, eq, params, headers):
    _p(doc, name, size=11, bold=True, color=GOLD, align=WD_ALIGN_PARAGRAPH.CENTER, after=4)
    _p(doc, eq, size=14, color=NAVY, align=WD_ALIGN_PARAGRAPH.CENTER, after=8, name=FONT_EQ)
    _table(doc, headers, params, col_w=[3.2, 10.5, 3.0] if len(headers) == 3 else [3.5, 13.2], head="0F766E")


# ── PPT helpers ────────────────────────────────────────────────────────────


def _slide_bg(slide, rgb=PBG):
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = rgb


def _box(slide, l, t, w, h, text, *, size=16, bold=False, italic=False, color=PN, align=PP_ALIGN.LEFT, font=FONT_BODY, anchor=None):
    tb = slide.shapes.add_textbox(Inches(l), Inches(t), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = True
    if anchor is not None:
        tf.auto_size = None
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.size = PptPt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    run.font.name = font
    return tb


def _rect(slide, l, t, w, h, fill, line=None):
    sh = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(l), Inches(t), Inches(w), Inches(h))
    sh.adjustments[0] = 0.08
    sh.fill.solid()
    sh.fill.fore_color.rgb = fill
    if line is None:
        sh.line.fill.background()
    else:
        sh.line.color.rgb = line
        sh.line.width = Pt(1.25)
    return sh


def _bar(slide):
    r = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(0.14))
    r.fill.solid()
    r.fill.fore_color.rgb = PT
    r.line.fill.background()
    r2 = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(7.36), Inches(13.333), Inches(0.14))
    r2.fill.solid()
    r2.fill.fore_color.rgb = PN
    r2.line.fill.background()


def _footer(slide, n, total, lang):
    lab = "LMESM · USTO-MB  ·  Theoretical guide — QE pseudopotentials" if lang == "en" else "LMESM · USTO-MB  ·  Support théorique — Pseudopotentiels QE"
    _box(slide, 0.4, 7.08, 9.2, 0.26, lab, size=10, color=PS)
    _box(slide, 11.5, 7.08, 1.5, 0.26, f"{n} / {total}", size=10, color=PS, align=PP_ALIGN.RIGHT)


def _title_c(slide, kicker, title):
    _box(slide, 0.4, 0.28, 12.5, 0.26, kicker, size=12, bold=True, color=PT, align=PP_ALIGN.CENTER, font=FONT_TITLE)
    _box(slide, 0.4, 0.52, 12.5, 0.55, title, size=26, bold=True, color=PN, align=PP_ALIGN.CENTER, font=FONT_TITLE)


def _eq_banner(slide, l, t, w, h, name, eq):
    _rect(slide, l, t, w, h, PN)
    _box(slide, l + 0.15, t + 0.08, w - 0.3, 0.28, name, size=12, bold=True, color=PG, align=PP_ALIGN.CENTER, font=FONT_TITLE)
    _box(slide, l + 0.15, t + 0.38, w - 0.3, h - 0.5, eq, size=18, color=PW, align=PP_ALIGN.CENTER, font=FONT_EQ)


def _card(slide, l, t, w, h, kicker, title, body, fill, accent):
    _rect(slide, l, t, w, h, fill, accent)
    _box(slide, l + 0.12, t + 0.08, w - 0.24, 0.22, kicker, size=10, bold=True, color=accent, font=FONT_TITLE)
    _box(slide, l + 0.12, t + 0.30, w - 0.24, 0.38, title, size=18, bold=True, color=PN, font=FONT_TITLE)
    _box(slide, l + 0.12, t + 0.72, w - 0.24, h - 0.85, body, size=13, color=PN)


# ── Content ────────────────────────────────────────────────────────────────

def T(lang: str) -> dict:
    if lang == "en":
        return {
            "kicker": "LMESM  ·  Faculty of Physics, USTO-MB, Oran",
            "author": "Prof. S. HIADSI",
            "kind": "Theoretical guide",
            "title": "Pseudopotentials for Quantum ESPRESSO",
            "sub": "Four generators  ·  NC / USPP / PAW  ·  Validated libraries",
            "ver": "Pseudopotential Generator v1.2  —  interface 02  —  2026",
            "toc": "Contents",
            "items": [
                "1.  Radial Schrödinger equation — starting point",
                "2.  Core idea of a pseudopotential",
                "3.  Three families: NC · USPP · PAW",
                "4.  The four generators: ld1.x · APE · ATOMPAW · ONCVPSP",
                "5.  Other libraries: PSLibrary · PseudoDojo · SSSP",
                "6.  Comparison and practical advice",
            ],
            "h1": "1.  Radial Schrödinger equation",
            "p1": (
                "In the spherical approximation the atomic wave function factors into a radial part and a spherical harmonic. "
                "We work in Hartree atomic units (m_e = ħ = e = 1). The reduced radial function "
                "u_{nℓ}(r) = r R_{nℓ}(r) obeys the radial Schrödinger equation (or the scalar Dirac equation when relativity is included)."
            ),
            "fn_sch": "Radial Schrödinger equation",
            "eq_sch": "[ −½ d²/dr²  +  ℓ(ℓ+1)/(2r²)  +  V_eff(r) ]  u_{nℓ}(r)  =  ε_{nℓ} u_{nℓ}(r)",
            "fn_veff": "Kohn–Sham effective potential",
            "eq_veff": "V_eff(r)  =  V_nuc(r)  +  V_H[n](r)  +  V_xc[n](r)",
            "ph": ["Symbol", "Definition", "Unit"],
            "pr_sch": [
                ["r", "Radial coordinate", "Bohr (a₀)"],
                ["n, ℓ", "Principal and orbital quantum numbers (ℓ = 0,1,2 → s,p,d)", "—"],
                ["u_{nℓ} = r R_{nℓ}", "Reduced radial function (the operator above acts on u, not on R)", "a₀^{−1/2}"],
                ["V_nuc, V_H, V_xc", "Nuclear, Hartree and exchange–correlation potentials", "Ha"],
                ["ε_{nℓ}", "Orbital eigenvalue — reference energy for pseudization", "Ha"],
            ],
            "p1b": (
                "An all-electron (AE) calculation solves this equation for every electron. Core orbitals oscillate near the nucleus "
                "(nodes required by orthogonality). Plane-wave bases then need huge cutoffs — hence pseudopotentials."
            ),
            "h2": "2.  Core idea of a pseudopotential",
            "p2": "Four physical pillars:",
            "b2": [
                "Core / valence split: core electrons (little role in bonding) are frozen and folded into the pseudopotential.",
                "Smooth pseudo-orbital: ũ_ℓ(r) has no node for r < r_c and equals the AE function for r ≥ r_c.",
                "Matching at r_c: continuity of the function and its derivative (and, for NC, of the norm).",
                "Schrödinger inversion: V_{PS,ℓ}(r) is the potential that reproduces ũ_ℓ exactly at energy ε_{nℓ}.",
            ],
            "fn_inv": "Schrödinger inversion  (r < r_c)",
            "eq_inv": "V_{PS,ℓ}(r)  =  ε_{nℓ}  +  (1 / 2 ũ_ℓ) d²ũ_ℓ/dr²  −  ℓ(ℓ+1)/(2r²)",
            "pr_inv": [
                ["r_c", "Matching radius (Bohr): ũ = u^{AE} for r ≥ r_c"],
                ["ũ_ℓ(r)", "Smooth reduced pseudo-orbital, nodeless for r < r_c"],
                ["V_{PS,ℓ}", "Channel-ℓ pseudopotential that reproduces ũ_ℓ at ε_{nℓ}"],
            ],
            "h3": "3.  Three families: NC · USPP · PAW",
            "fn_nc": "Norm-conservation constraint (Hamann)",
            "eq_nc": "∫₀^{r_c} |ũ_ℓ(r)|² dr   =   ∫₀^{r_c} |u_ℓ^{AE}(r)|² dr",
            "p_nc": "Physically robust and transferable, but often hard → ecutwfc = 60–120 Ry. Schemes: HSC (1979), Troullier–Martins (1991), ONCVPSP.",
            "p_us": "The norm constraint is relaxed; augmentation charges Q_{ij}(r) restore the AE density. Soft: ecutwfc = 25–50 Ry, ecutrho ≈ 8–12 × ecutwfc. Transition metals, oxides.",
            "fn_paw": "PAW transformation (Blöchl, 1994)",
            "eq_paw": "|ψ⟩  =  |ψ̃⟩  +  Σ_i  (|φ_i⟩ − |φ̃_i⟩) ⟨p̃_i | ψ̃⟩",
            "pr_paw": [
                ["|ψ̃⟩", "Smooth pseudo-wavefunction (plane-wave part)"],
                ["|φ_i⟩, |φ̃_i⟩", "AE and pseudo partial waves inside the PAW sphere"],
                ["⟨p̃_i|", "Projectors that reconstruct the AE part"],
            ],
            "p_cut": "Rule of thumb: ecutwfc(NC) ≈ 2–4 × ecutwfc(USPP); ecutwfc(PAW) ≈ ecutwfc(USPP); ecutrho = 4 × ecutwfc (NC) or 8–12 × (USPP/PAW).",
            "h4": "4.  The four generators of the interface",
            "p4": "The v1.2 interface ships four atomic generators. Each builds a UPF from the isolated atom. The other libraries (next section) are already-validated UPF files — they are not generators.",
            "g_ld1": ("GENERATOR 1", "ld1.x", "QE atomic code. NC (TM), USPP (Vanderbilt) or PAW (Blöchl) in native UPF. Only tool that covers all three types. rel = 0 / 1 / 2. 3d → PAW/US; 4f/5f from scratch is unstable."),
            "g_ape": ("GENERATOR 2", "APE", "Atomic Pseudopotential Engine (Oliveira & Nogueira). NC only (Troullier–Martins or Hamann). Best for Si, C, O. Avoid 3d/4f/5f (GSL / ghosts). WaveEquation = schrodinger | scalar_rel."),
            "g_apaw": ("GENERATOR 3", "ATOMPAW", "PAW only (Holzwarth et al.). Vanderbilt / Blöchl. PWSCFOUT → UPF for pw.x. Best for 3d, 4f, 5f and magnetism. Scalar relativity only. open_core vs valence_f for f electrons."),
            "g_oncv": ("GENERATOR 4", "ONCVPSP", "Optimized NC (Hamann, PRB 2013). Two reference energies per angular channel → soft NC (30–50 Ry). Binary is scalar-relativistic. PseudoDojo templates are PBE-tuned — do not change iexc without retuning r_c."),
            "h5": "5.  Other libraries (not generators)",
            "p5": "The Other libraries tab downloads a tested UPF. No atomic inversion is performed.",
            "b_psl": ("LIBRARY", "PSLibrary", "Official QE USPP/PAW set (A. Dal Corso, ld1.x). H→Pu. rrkjus = USPP, kjpaw = PAW. NLCC (n) and semicore (spn) for TM and K/Rb/Cs."),
            "b_pdo": ("LIBRARY", "PseudoDojo", "World-reference NC set from ONCVPSP. LDA / PBE / PBEsol, Standard or Stringent (δ < 0.5 meV/atom). QE, ABINIT, BerkeleyGW, Wannier90."),
            "b_sss": ("CURATED SET", "SSSP", "Not a generator: best existing UPF per element (δ-test vs AE). Efficiency 25–50 Ry; Precision 50–90 Ry. Prandini et al., npj Comput. Mater. 4, 72 (2018)."),
            "h6": "6.  Comparison and advice",
            "th": ["Tool", "Type", "ecutwfc (Ry)", "Typical use"],
            "rows": [
                ["ld1.x", "NC / US / PAW", "25–120", "Three types in one tool; 3d as PAW/US"],
                ["APE", "NC", "60–120", "Light p elements; avoid 3d/f"],
                ["ATOMPAW", "PAW", "30–60", "3d, 4f, 5f, magnetism"],
                ["ONCVPSP", "NC-OPT", "40–80", "Soft NC, multi-code"],
                ["PSLibrary", "USPP / PAW", "25–60", "Everyday QE, TM, oxides"],
                ["PseudoDojo", "NC-OPT", "40–80", "Multi-code NC workflows"],
                ["SSSP Efficiency", "Mixed", "25–60", "Screening, large cells"],
                ["SSSP Precision", "Mixed", "50–90", "Publishable results, δ-test"],
            ],
            "tips_t": "Practical advice",
            "tips": [
                "Start a project with SSSP Efficiency, finish with SSSP Precision.",
                "3d metals: USPP or PAW (ld1 / ATOMPAW / PSLibrary) — classical NC is often too hard.",
                "Z > 30: scalar relativity (rel = 1 in ld1; scalar_rel in APE; scalarrelativistic in ATOMPAW).",
                "4f: open_core for thermo / fragile ONCV; valence_f for magnetism + U. Yb is 4f¹⁴ core-like.",
                "5f: Th–Pu itinerant → valence_f; Am–No localized → open_core.",
                "Multi-code (QE + ABINIT + BerkeleyGW): PseudoDojo NC.",
                "Always scan ecutwfc and k-points before production. Check ghost states (lloc / r_c).",
                "NLCC for transition metals and large cores.",
            ],
            "cite": "© Prof. S. HIADSI — LMESM / Faculty of Physics, USTO-MB, Oran. Please cite the author if you use this guide in research or teaching.",
            "plan": "PLAN",
            "plan_t": "Six chapters",
            "map": "THE INTERFACE",
            "map_t": "Four generators  +  three libraries",
            "thanks": "Thank you",
            "thanks2": "Please cite the author if this guide is used\nin research or teaching.",
            "slide_gens": "Four atomic codes, one UPF each",
            "slide_bases": "Download a tested UPF — no generation",
            "cut_t": "CUTOFFS",
            "cut_s": "Empirical rule for pw.x",
        }
    return {
        "kicker": "LMESM  ·  Faculté de Physique, USTO-MB, Oran",
        "author": "Prof. S. HIADSI",
        "kind": "Support théorique",
        "title": "Pseudopotentiels pour Quantum ESPRESSO",
        "sub": "Quatre générateurs  ·  NC / USPP / PAW  ·  Bibliothèques validées",
        "ver": "Générateur de pseudopotentiels v1.2  —  interface 02  —  2026",
        "toc": "Sommaire",
        "items": [
            "①  Équation radiale de Schrödinger — point de départ",
            "②  Idée fondamentale du pseudopotentiel",
            "③  Trois familles : NC · USPP · PAW",
            "④  Les 4 générateurs : ld1.x · APE · ATOMPAW · ONCVPSP",
            "⑤  Autres bases : PSLibrary · PseudoDojo · SSSP",
            "⑥  Tableau comparatif et conseils",
        ],
        "h1": "①  Équation radiale de Schrödinger",
        "p1": (
            "Dans l’approximation sphérique, la fonction d’onde atomique se factorise en partie radiale et harmonique sphérique. "
            "On travaille en unités atomiques de Hartree (m_e = ħ = e = 1). La fonction radiale réduite "
            "u_{nℓ}(r) = r R_{nℓ}(r) satisfait l’équation radiale de Schrödinger (ou Dirac scalaire si la relativité est incluse)."
        ),
        "fn_sch": "Équation radiale de Schrödinger",
        "eq_sch": "[ −½ d²/dr²  +  ℓ(ℓ+1)/(2r²)  +  V_eff(r) ]  u_{nℓ}(r)  =  ε_{nℓ} u_{nℓ}(r)",
        "fn_veff": "Potentiel effectif de Kohn–Sham",
        "eq_veff": "V_eff(r)  =  V_nuc(r)  +  V_H[n](r)  +  V_xc[n](r)",
        "ph": ["Symbole", "Définition", "Unité"],
        "pr_sch": [
            ["r", "Coordonnée radiale", "Bohr (a₀)"],
            ["n, ℓ", "Nombres quantiques principal et orbital (ℓ = 0, 1, 2 → s, p, d)", "—"],
            ["u_{nℓ} = r R_{nℓ}", "Fonction radiale réduite (l’opérateur ci-dessus agit sur u, pas sur R)", "a₀^{−1/2}"],
            ["V_nuc, V_H, V_xc", "Potentiels nucléaire, de Hartree et d’échange-corrélation", "Ha"],
            ["ε_{nℓ}", "Valeur propre orbitale — énergie de référence de la pseudisation", "Ha"],
        ],
        "p1b": (
            "Le calcul all-electron (AE) résout cette équation pour tous les électrons. Les orbitales de cœur oscillent près du noyau "
            "(nœuds d’orthogonalité). En ondes planes les coupures deviennent prohibitives — d’où les pseudopotentiels."
        ),
        "h2": "②  Idée fondamentale du pseudopotentiel",
        "p2": "Quatre piliers physiques :",
        "b2": [
            "Séparation cœur / valence : les électrons de cœur (peu impliqués dans les liaisons) sont gelés et incorporés dans le pseudopotentiel.",
            "Pseudo-orbitale lisse : ũ_ℓ(r) sans nœud pour r < r_c, identique à l’AE pour r ≥ r_c.",
            "Raccord à r_c : continuité de la fonction et de sa dérivée (et, pour NC, de la norme).",
            "Inversion de Schrödinger : V_{PS,ℓ}(r) est le potentiel qui reproduit exactement ũ_ℓ à l’énergie ε_{nℓ}.",
        ],
        "fn_inv": "Inversion de Schrödinger  (r < r_c)",
        "eq_inv": "V_{PS,ℓ}(r)  =  ε_{nℓ}  +  (1 / 2 ũ_ℓ) d²ũ_ℓ/dr²  −  ℓ(ℓ+1)/(2r²)",
        "pr_inv": [
            ["r_c", "Rayon de raccord (Bohr) : ũ = u^{AE} pour r ≥ r_c"],
            ["ũ_ℓ(r)", "Pseudo-orbitale radiale lisse, sans nœud pour r < r_c"],
            ["V_{PS,ℓ}", "Pseudopotentiel du canal ℓ qui reproduit ũ_ℓ à ε_{nℓ}"],
        ],
        "h3": "③  Trois familles : NC · USPP · PAW",
        "fn_nc": "Contrainte de conservation de la norme (Hamann)",
        "eq_nc": "∫₀^{r_c} |ũ_ℓ(r)|² dr   =   ∫₀^{r_c} |u_ℓ^{AE}(r)|² dr",
        "p_nc": "Robuste et transférable, mais souvent dur → ecutwfc = 60–120 Ry. Schèmes : HSC (1979), Troullier–Martins (1991), ONCVPSP.",
        "p_us": "La contrainte de norme est relâchée ; des charges d’augmentation Q_{ij}(r) restaurent la densité AE. Doux : ecutwfc = 25–50 Ry, ecutrho ≈ 8–12 × ecutwfc. Métaux de transition, oxydes.",
        "fn_paw": "Transformation PAW (Blöchl, 1994)",
        "eq_paw": "|ψ⟩  =  |ψ̃⟩  +  Σ_i  (|φ_i⟩ − |φ̃_i⟩) ⟨p̃_i | ψ̃⟩",
        "pr_paw": [
            ["|ψ̃⟩", "Pseudo-fonction d’onde lisse (partie ondes planes)"],
            ["|φ_i⟩, |φ̃_i⟩", "Ondes partielles AE et pseudo dans la sphère PAW"],
            ["⟨p̃_i|", "Projecteurs qui reconstruisent la partie AE"],
        ],
        "p_cut": "Règle empirique : ecutwfc(NC) ≈ 2–4 × ecutwfc(USPP) ; ecutwfc(PAW) ≈ ecutwfc(USPP) ; ecutrho = 4 × ecutwfc (NC) ou 8–12 × (USPP/PAW).",
        "h4": "④  Les 4 générateurs de l’interface",
        "p4": "L’interface v1.2 embarque quatre générateurs atomiques. Chacun construit un UPF à partir de l’atome isolé. Les autres bases (section suivante) sont des UPF déjà validés — ce ne sont pas des générateurs.",
        "g_ld1": ("GÉNÉRATEUR 1", "ld1.x", "Code atomique QE. NC (TM), USPP (Vanderbilt) ou PAW (Blöchl) en UPF natif. Seul outil des trois types. rel = 0 / 1 / 2. 3d → PAW/US ; 4f/5f from scratch instable."),
        "g_ape": ("GÉNÉRATEUR 2", "APE", "Atomic Pseudopotential Engine (Oliveira & Nogueira). NC seul (Troullier–Martins ou Hamann). Idéal Si, C, O. Éviter 3d/4f/5f (GSL / ghosts). WaveEquation = schrodinger | scalar_rel."),
        "g_apaw": ("GÉNÉRATEUR 3", "ATOMPAW", "PAW uniquement (Holzwarth et al.). Vanderbilt / Blöchl. PWSCFOUT → UPF pour pw.x. Idéal 3d, 4f, 5f et magnétisme. Relativité scalaire seulement. open_core vs valence_f pour les f."),
        "g_oncv": ("GÉNÉRATEUR 4", "ONCVPSP", "NC optimisé (Hamann, PRB 2013). Deux énergies de référence par canal → NC doux (30–50 Ry). Binaire scalaire-relativiste. Gabarits PseudoDojo tunés PBE — ne pas changer iexc sans retuner r_c."),
        "h5": "⑤  Autres bases (ce ne sont pas des générateurs)",
        "p5": "L’onglet Autres bases télécharge un UPF déjà testé. Aucune inversion atomique n’est effectuée.",
        "b_psl": ("BIBLIOTHÈQUE", "PSLibrary", "Collection officielle QE USPP/PAW (A. Dal Corso, ld1.x). H→Pu. rrkjus = USPP, kjpaw = PAW. NLCC (n) et semi-cœur (spn) pour TM et K/Rb/Cs."),
        "b_pdo": ("BIBLIOTHÈQUE", "PseudoDojo", "NC de référence mondiale, générés ONCVPSP. LDA / PBE / PBEsol, Standard ou Stringent (δ < 0,5 meV/atome). QE, ABINIT, BerkeleyGW, Wannier90."),
        "b_sss": ("SÉLECTION", "SSSP", "Pas un générateur : meilleur UPF existant par élément (δ-test vs AE). Efficiency 25–50 Ry ; Precision 50–90 Ry. Prandini et al., npj Comput. Mater. 4, 72 (2018)."),
        "h6": "⑥  Tableau comparatif et conseils",
        "th": ["Outil", "Type", "ecutwfc (Ry)", "Usage typique"],
        "rows": [
            ["ld1.x", "NC / US / PAW", "25–120", "Trois types dans un outil ; 3d en PAW/US"],
            ["APE", "NC", "60–120", "Éléments p légers ; éviter 3d/f"],
            ["ATOMPAW", "PAW", "30–60", "3d, 4f, 5f, magnétisme"],
            ["ONCVPSP", "NC-OPT", "40–80", "NC doux, multi-codes"],
            ["PSLibrary", "USPP / PAW", "25–60", "QE courant, TM, oxydes"],
            ["PseudoDojo", "NC-OPT", "40–80", "Workflows NC multi-codes"],
            ["SSSP Efficiency", "Mixte", "25–60", "Screening, grandes cellules"],
            ["SSSP Precision", "Mixte", "50–90", "Résultats publiables, δ-test"],
        ],
        "tips_t": "Conseils pratiques",
        "tips": [
            "Début de projet : SSSP Efficiency, puis SSSP Precision pour les résultats finaux.",
            "Métaux 3d : USPP ou PAW (ld1 / ATOMPAW / PSLibrary) — le NC classique est souvent trop dur.",
            "Z > 30 : relativité scalaire (rel = 1 dans ld1 ; scalar_rel dans APE ; scalarrelativistic dans ATOMPAW).",
            "4f : open_core pour thermo / ONCV fragile ; valence_f pour magnétisme + U. Yb = 4f¹⁴ cœur-like.",
            "5f : Th–Pu itinerant → valence_f ; Am–No localisé → open_core.",
            "Multi-codes (QE + ABINIT + BerkeleyGW) : PseudoDojo NC.",
            "Toujours tracer ecutwfc et k-points avant la production. Vérifier les ghost states (lloc / r_c).",
            "NLCC pour métaux de transition et cœurs importants.",
        ],
        "cite": "© Prof. S. HIADSI — LMESM / Faculté de Physique, USTO-MB, Oran. À citer si ce support est utilisé en recherche ou en enseignement.",
        "plan": "PLAN",
        "plan_t": "Six chapitres",
        "map": "L’INTERFACE",
        "map_t": "Quatre générateurs  +  trois bibliothèques",
        "thanks": "Merci",
        "thanks2": "Citer l’auteur si ce support est utilisé\nen recherche ou en enseignement.",
        "slide_gens": "Quatre codes atomiques, un UPF chacun",
        "slide_bases": "Télécharger un UPF testé — pas de génération",
        "cut_t": "COUPURES",
        "cut_s": "Règle empirique pour pw.x",
    }


# ── Builders ───────────────────────────────────────────────────────────────


def build_docx(path: Path, lang: str) -> None:
    C = T(lang)
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Cm(21.0)
    sec.page_height = Cm(29.7)
    sec.top_margin = Cm(2.0)
    sec.bottom_margin = Cm(2.0)
    sec.left_margin = Cm(2.2)
    sec.right_margin = Cm(2.2)
    style = doc.styles["Normal"]
    style.font.name = FONT_BODY
    style.font.size = Pt(11)

    _p(doc, C["kicker"], size=12, color=TEAL, align=WD_ALIGN_PARAGRAPH.CENTER, after=2, name=FONT_TITLE)
    _p(doc, C["author"], size=13, bold=True, color=NAVY, align=WD_ALIGN_PARAGRAPH.CENTER, after=14, name=FONT_TITLE)
    _p(doc, C["kind"], size=13, color=GOLD, align=WD_ALIGN_PARAGRAPH.CENTER, after=4, name=FONT_TITLE)
    _p(doc, C["title"], size=26, bold=True, color=NAVY, align=WD_ALIGN_PARAGRAPH.CENTER, after=8, name=FONT_TITLE)
    _p(doc, C["sub"], size=12, italic=True, color=SLATE, align=WD_ALIGN_PARAGRAPH.CENTER, after=10, name=FONT_TITLE)
    _p(doc, C["ver"], size=10, color=SLATE, align=WD_ALIGN_PARAGRAPH.CENTER, after=20)

    _heading(doc, C["toc"], 1)
    for it in C["items"]:
        _p(doc, it, size=13, after=5, align=WD_ALIGN_PARAGRAPH.CENTER, name=FONT_TITLE)

    _heading(doc, C["h1"], 1)
    _p(doc, C["p1"])
    _formula(doc, C["fn_sch"], C["eq_sch"], C["pr_sch"], C["ph"])
    _formula(doc, C["fn_veff"], C["eq_veff"], [], C["ph"][:2] if False else C["ph"])
    # empty params for Veff already in Schrödinger table — skip empty table
    # remove last empty table: rebuild veff as name+eq only
    if doc.paragraphs[-1].text == "":
        pass
    _p(doc, C["p1b"])

    _heading(doc, C["h2"], 1)
    _p(doc, C["p2"], bold=True)
    for b in C["b2"]:
        p = doc.add_paragraph(style="List Bullet")
        r = p.add_run(b)
        _run(r, size=11)
    _formula(doc, C["fn_inv"], C["eq_inv"], C["pr_inv"], C["ph"][:2])

    _heading(doc, C["h3"], 1)
    _heading(doc, "NC — Norm-Conserving", 2)
    _formula(doc, C["fn_nc"], C["eq_nc"], [], C["ph"][:2])
    _p(doc, C["p_nc"])
    _heading(doc, "USPP — Ultrasoft (Vanderbilt)", 2)
    _p(doc, C["p_us"])
    _heading(doc, "PAW — Projector Augmented Wave", 2)
    _formula(doc, C["fn_paw"], C["eq_paw"], C["pr_paw"], C["ph"][:2])
    _p(doc, C["p_cut"], italic=True, color=TEAL)

    _heading(doc, C["h4"], 1)
    _p(doc, C["p4"])
    gens = [
        (C["g_ld1"], "1E4976"),
        (C["g_ape"], "047857"),
        (C["g_apaw"], "B45309"),
        (C["g_oncv"], "0E7490"),
    ]
    for (k, ti, bo), hx in gens:
        _p(doc, f"{k}  —  {ti}", size=13, bold=True, color=RGBColor(int(hx[0:2], 16), int(hx[2:4], 16), int(hx[4:6], 16)), align=WD_ALIGN_PARAGRAPH.CENTER, name=FONT_TITLE)
        _p(doc, bo, after=12)

    _heading(doc, C["h5"], 1)
    _p(doc, C["p5"])
    for (k, ti, bo), hx in [(C["b_psl"], "6B21A8"), (C["b_pdo"], "C2410C"), (C["b_sss"], "B91C1C")]:
        _p(doc, f"{k}  —  {ti}", size=13, bold=True, color=RGBColor(int(hx[0:2], 16), int(hx[2:4], 16), int(hx[4:6], 16)), align=WD_ALIGN_PARAGRAPH.CENTER, name=FONT_TITLE)
        _p(doc, bo, after=12)

    _heading(doc, C["h6"], 1)
    _table(doc, C["th"], C["rows"], col_w=[4.0, 3.4, 3.2, 6.2])
    _p(doc, C["tips_t"], bold=True, color=TEAL, align=WD_ALIGN_PARAGRAPH.CENTER, name=FONT_TITLE)
    for t in C["tips"]:
        p = doc.add_paragraph(style="List Bullet")
        r = p.add_run(t)
        _run(r, size=11)

    _p(doc, C["cite"], size=9, italic=True, color=SLATE, align=WD_ALIGN_PARAGRAPH.CENTER, after=4)
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(path))


def build_pptx(path: Path, lang: str) -> None:
    C = T(lang)
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank = prs.slide_layouts[6]
    total = 16
    n = 0

    def new():
        nonlocal n
        n += 1
        s = prs.slides.add_slide(blank)
        _slide_bg(s)
        _bar(s)
        return s

    # title
    s = new()
    r = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(7.5))
    r.fill.solid()
    r.fill.fore_color.rgb = PN
    r.line.fill.background()
    acc = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(0.22), Inches(7.5))
    acc.fill.solid()
    acc.fill.fore_color.rgb = PT
    acc.line.fill.background()
    gold = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.22), Inches(0), Inches(0.08), Inches(7.5))
    gold.fill.solid()
    gold.fill.fore_color.rgb = PG
    gold.line.fill.background()
    _box(s, 0.7, 1.45, 12, 0.32, C["kicker"], size=15, color=PptRGB(0x5E, 0xEA, 0xD4), align=PP_ALIGN.CENTER, font=FONT_TITLE)
    _box(s, 0.7, 1.85, 12, 0.32, C["author"], size=16, bold=True, color=PG, align=PP_ALIGN.CENTER, font=FONT_TITLE)
    _box(s, 0.7, 2.45, 12, 1.2, C["title"], size=36, bold=True, color=PW, align=PP_ALIGN.CENTER, font=FONT_TITLE)
    _box(s, 0.7, 4.0, 12, 0.7, C["sub"], size=18, color=PptRGB(0xCB, 0xD5, 0xE1), align=PP_ALIGN.CENTER, font=FONT_TITLE)
    _box(s, 0.7, 6.2, 12, 0.4, C["ver"], size=14, color=PptRGB(0x94, 0xA3, 0xB8), align=PP_ALIGN.CENTER)

    # map
    s = new()
    _title_c(s, C["map"], C["map_t"])
    gens = [
        (0.35, C["g_ld1"], ICE, P_LD1),
        (3.55, C["g_ape"], PptRGB(0xEC, 0xFD, 0xF5), P_APE),
        (6.75, C["g_apaw"], PptRGB(0xFF, 0xF7, 0xED), P_APAW),
        (9.95, C["g_oncv"], PptRGB(0xEC, 0xFE, 0xFF), P_ONCV),
    ]
    for x, g, fill, acc in gens:
        _card(s, x, 1.25, 3.0, 3.15, g[0], g[1], g[2], fill, acc)
    libs = [
        (0.35, C["b_psl"], PptRGB(0xFA, 0xF5, 0xFF), P_PSL),
        (4.65, C["b_pdo"], PptRGB(0xFF, 0xF7, 0xED), P_PDO),
        (8.95, C["b_sss"], PptRGB(0xFE, 0xF2, 0xF2), P_SSSP),
    ]
    for x, g, fill, acc in libs:
        _card(s, x, 4.55, 4.0, 2.35, g[0], g[1], g[2], fill, acc)
    _footer(s, n, total, lang)

    # plan
    s = new()
    _title_c(s, C["plan"], C["plan_t"])
    xs = [0.45, 4.65, 8.85]
    for i, it in enumerate(C["items"][:3]):
        _rect(s, xs[i], 1.4, 4.0, 2.2, ICE, PT)
        _box(s, xs[i] + 0.15, 1.6, 3.7, 1.85, it, size=16, bold=True, color=PN, align=PP_ALIGN.CENTER, font=FONT_TITLE)
    for i, it in enumerate(C["items"][3:]):
        _rect(s, xs[i], 3.9, 4.0, 2.4, PptRGB(0xE8, 0xF0, 0xF8), P_LD1)
        _box(s, xs[i] + 0.15, 4.1, 3.7, 2.05, it, size=16, bold=True, color=PN, align=PP_ALIGN.CENTER, font=FONT_TITLE)
    _footer(s, n, total, lang)

    # Schrödinger
    s = new()
    _title_c(s, "①", C["h1"].split("  ", 1)[-1] if "  " in C["h1"] else C["h1"])
    _box(s, 0.45, 1.2, 12.4, 0.7, C["p1"][:220] + "…", size=14, color=PN, align=PP_ALIGN.CENTER)
    _eq_banner(s, 0.45, 1.95, 12.4, 1.45, C["fn_sch"], C["eq_sch"])
    _eq_banner(s, 0.45, 3.55, 12.4, 1.15, C["fn_veff"], C["eq_veff"])
    _box(s, 0.45, 4.85, 12.4, 1.9, "   ·   ".join(f"{a} : {b}" for a, b, *_ in C["pr_sch"]), size=13, color=PS, align=PP_ALIGN.CENTER)
    _footer(s, n, total, lang)

    # params Schrödinger
    s = new()
    _title_c(s, "①", C["fn_sch"])
    y = 1.25
    _rect(s, 0.45, y, 12.4, 0.48, PN)
    for i, h in enumerate(C["ph"]):
        xs = [0.6, 3.6, 10.4]
        _box(s, xs[i], y + 0.08, 3.0 if i < 2 else 2.2, 0.32, h, size=13, bold=True, color=PW)
    y = 1.85
    for i, row in enumerate(C["pr_sch"]):
        bg = ICE if i % 2 == 0 else PBG
        _rect(s, 0.45, y, 12.4, 0.88, bg, PT)
        xs = [0.6, 3.6, 10.4]
        ws = [2.9, 6.6, 2.2]
        for j, val in enumerate(row):
            _box(s, xs[j], y + 0.18, ws[j], 0.55, val, size=14, bold=(j == 0), color=PN, font=FONT_EQ if j == 0 else FONT_BODY)
        y += 0.95
    _footer(s, n, total, lang)

    # idea
    s = new()
    _title_c(s, "②", C["h2"].split("  ", 1)[-1] if "  " in C["h2"] else C["h2"])
    cards = [
        (0.35, C["b2"][0][:18], C["b2"][0]),
        (3.55, C["b2"][1][:22], C["b2"][1]),
        (6.75, C["b2"][2][:16], C["b2"][2]),
        (9.95, C["b2"][3][:22], C["b2"][3]),
    ]
    for i, (x, ti, bo) in enumerate(cards):
        _card(s, x, 1.25, 3.0, 2.85, str(i + 1), ti, bo, ICE, PT)
    _eq_banner(s, 0.35, 4.3, 12.6, 1.55, C["fn_inv"], C["eq_inv"])
    _footer(s, n, total, lang)

    # NC USPP PAW
    s = new()
    _title_c(s, "③", C["h3"].split("  ", 1)[-1] if "  " in C["h3"] else C["h3"])
    _card(s, 0.35, 1.25, 4.15, 3.35, "NC", "Norm-Conserving", C["p_nc"], ICE, PT)
    _card(s, 4.6, 1.25, 4.15, 3.35, "USPP", "Ultrasoft", C["p_us"], PptRGB(0xFF, 0xF7, 0xED), P_APAW)
    _card(s, 8.85, 1.25, 4.15, 3.35, "PAW", "Blöchl 1994", C["p_cut"], PptRGB(0xE8, 0xF0, 0xF8), P_LD1)
    _eq_banner(s, 0.35, 4.75, 12.6, 1.5, C["fn_nc"] + "   ·   " + C["fn_paw"], C["eq_nc"] + "\n" + C["eq_paw"])
    _footer(s, n, total, lang)

    # 4 generators
    s = new()
    _title_c(s, "④", C["h4"].split("  ", 1)[-1] if "  " in C["h4"] else C["h4"])
    _box(s, 0.4, 1.15, 12.5, 0.4, C["slide_gens"], size=15, italic=True, color=PT, align=PP_ALIGN.CENTER)
    gens = [
        (0.35, C["g_ld1"], ICE, P_LD1),
        (3.55, C["g_ape"], PptRGB(0xEC, 0xFD, 0xF5), P_APE),
        (6.75, C["g_apaw"], PptRGB(0xFF, 0xF7, 0xED), P_APAW),
        (9.95, C["g_oncv"], PptRGB(0xEC, 0xFE, 0xFF), P_ONCV),
    ]
    for x, g, fill, acc in gens:
        _card(s, x, 1.65, 3.0, 4.95, g[0], g[1], g[2], fill, acc)
    _footer(s, n, total, lang)

    # libraries
    s = new()
    _title_c(s, "⑤", C["h5"].split("  ", 1)[-1] if "  " in C["h5"] else C["h5"])
    _box(s, 0.4, 1.15, 12.5, 0.4, C["slide_bases"], size=15, italic=True, color=PT, align=PP_ALIGN.CENTER)
    libs = [
        (0.4, C["b_psl"], PptRGB(0xFA, 0xF5, 0xFF), P_PSL),
        (4.7, C["b_pdo"], PptRGB(0xFF, 0xF7, 0xED), P_PDO),
        (9.0, C["b_sss"], PptRGB(0xFE, 0xF2, 0xF2), P_SSSP),
    ]
    for x, g, fill, acc in libs:
        _card(s, x, 1.7, 4.05, 4.85, g[0], g[1], g[2], fill, acc)
    _footer(s, n, total, lang)

    # comparatif
    s = new()
    _title_c(s, "⑥", C["h6"].split("  ", 1)[-1] if "  " in C["h6"] else C["h6"])
    y = 1.2
    _rect(s, 0.35, y, 12.6, 0.42, PN)
    xs = [0.5, 3.6, 6.3, 8.6]
    for i, h in enumerate(C["th"]):
        _box(s, xs[i], y + 0.05, 3.2, 0.32, h, size=13, bold=True, color=PW)
    y = 1.68
    for i, row in enumerate(C["rows"]):
        bg = ICE if i % 2 == 0 else PBG
        _rect(s, 0.35, y, 12.6, 0.58, bg, PT)
        for j, val in enumerate(row):
            _box(s, xs[j], y + 0.1, 3.4 if j == 3 else 2.6, 0.38, val, size=13, bold=(j == 0), color=PN)
        y += 0.60
    _footer(s, n, total, lang)

    # tips
    s = new()
    _title_c(s, "⑥", C["tips_t"])
    tb = s.shapes.add_textbox(Inches(0.55), Inches(1.25), Inches(12.2), Inches(5.5))
    tf = tb.text_frame
    tf.word_wrap = True
    for i, item in enumerate(C["tips"]):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.space_after = PptPt(8)
        run = p.add_run()
        run.text = "•  " + item
        run.font.size = PptPt(16)
        run.font.color.rgb = PN
        run.font.name = FONT_BODY
    _footer(s, n, total, lang)

    # close
    s = new()
    r = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(7.5))
    r.fill.solid()
    r.fill.fore_color.rgb = PN
    r.line.fill.background()
    acc = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(0.22), Inches(7.5))
    acc.fill.solid()
    acc.fill.fore_color.rgb = PT
    acc.line.fill.background()
    _box(s, 0.7, 2.15, 12, 0.45, C["thanks"], size=20, color=PptRGB(0x5E, 0xEA, 0xD4), align=PP_ALIGN.CENTER, font=FONT_TITLE)
    _box(s, 0.7, 2.7, 12, 1.2, C["thanks2"], size=26, bold=True, color=PW, align=PP_ALIGN.CENTER, font=FONT_TITLE)
    _box(s, 0.7, 4.4, 12, 1.3, C["author"] + "\n" + C["kicker"] + "\n" + C["ver"], size=15, color=PptRGB(0x94, 0xA3, 0xB8), align=PP_ALIGN.CENTER)

    path.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(path))


def _fix_veff_empty_table(doc_path: Path) -> None:
    """No-op placeholder kept for clarity; Veff table is skipped in build."""
    return


def build_docx_clean(path: Path, lang: str) -> None:
    """Word without an empty Veff parameter table."""
    C = T(lang)
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Cm(21.0)
    sec.page_height = Cm(29.7)
    sec.top_margin = Cm(2.0)
    sec.bottom_margin = Cm(2.0)
    sec.left_margin = Cm(2.2)
    sec.right_margin = Cm(2.2)

    _p(doc, C["kicker"], size=12, color=TEAL, align=WD_ALIGN_PARAGRAPH.CENTER, after=2, name=FONT_TITLE)
    _p(doc, C["author"], size=13, bold=True, color=NAVY, align=WD_ALIGN_PARAGRAPH.CENTER, after=14, name=FONT_TITLE)
    _p(doc, C["kind"], size=13, color=GOLD, align=WD_ALIGN_PARAGRAPH.CENTER, after=4, name=FONT_TITLE)
    _p(doc, C["title"], size=26, bold=True, color=NAVY, align=WD_ALIGN_PARAGRAPH.CENTER, after=8, name=FONT_TITLE)
    _p(doc, C["sub"], size=12, italic=True, color=SLATE, align=WD_ALIGN_PARAGRAPH.CENTER, after=10, name=FONT_TITLE)
    _p(doc, C["ver"], size=10, color=SLATE, align=WD_ALIGN_PARAGRAPH.CENTER, after=20)

    _heading(doc, C["toc"], 1)
    for it in C["items"]:
        _p(doc, it, size=13, after=5, align=WD_ALIGN_PARAGRAPH.CENTER, name=FONT_TITLE)

    _heading(doc, C["h1"], 1)
    _p(doc, C["p1"])
    _formula(doc, C["fn_sch"], C["eq_sch"], C["pr_sch"], C["ph"])
    _p(doc, C["fn_veff"], size=11, bold=True, color=GOLD, align=WD_ALIGN_PARAGRAPH.CENTER, after=4)
    _p(doc, C["eq_veff"], size=14, color=NAVY, align=WD_ALIGN_PARAGRAPH.CENTER, after=10, name=FONT_EQ)
    _p(doc, C["p1b"])

    _heading(doc, C["h2"], 1)
    _p(doc, C["p2"], bold=True)
    for b in C["b2"]:
        p = doc.add_paragraph(style="List Bullet")
        r = p.add_run(b)
        _run(r, size=11)
    _formula(doc, C["fn_inv"], C["eq_inv"], C["pr_inv"], C["ph"][:2])

    _heading(doc, C["h3"], 1)
    _heading(doc, "NC — Norm-Conserving", 2)
    _p(doc, C["fn_nc"], size=11, bold=True, color=GOLD, align=WD_ALIGN_PARAGRAPH.CENTER, after=4)
    _p(doc, C["eq_nc"], size=14, color=NAVY, align=WD_ALIGN_PARAGRAPH.CENTER, after=8, name=FONT_EQ)
    _p(doc, C["p_nc"])
    _heading(doc, "USPP — Ultrasoft (Vanderbilt)", 2)
    _p(doc, C["p_us"])
    _heading(doc, "PAW — Projector Augmented Wave", 2)
    _formula(doc, C["fn_paw"], C["eq_paw"], C["pr_paw"], C["ph"][:2])
    _p(doc, C["p_cut"], italic=True, color=TEAL)

    _heading(doc, C["h4"], 1)
    _p(doc, C["p4"])
    for (k, ti, bo), col in [
        (C["g_ld1"], LD1),
        (C["g_ape"], APE),
        (C["g_apaw"], APAW),
        (C["g_oncv"], ONCV),
    ]:
        _p(doc, f"{k}  —  {ti}", size=13, bold=True, color=col, align=WD_ALIGN_PARAGRAPH.CENTER, name=FONT_TITLE)
        _p(doc, bo, after=12)

    _heading(doc, C["h5"], 1)
    _p(doc, C["p5"])
    for (k, ti, bo), col in [(C["b_psl"], PSL), (C["b_pdo"], PDO), (C["b_sss"], SSSP)]:
        _p(doc, f"{k}  —  {ti}", size=13, bold=True, color=col, align=WD_ALIGN_PARAGRAPH.CENTER, name=FONT_TITLE)
        _p(doc, bo, after=12)

    _heading(doc, C["h6"], 1)
    _table(doc, C["th"], C["rows"], col_w=[4.0, 3.4, 3.2, 6.2])
    _p(doc, C["tips_t"], bold=True, color=TEAL, align=WD_ALIGN_PARAGRAPH.CENTER, name=FONT_TITLE)
    for t in C["tips"]:
        p = doc.add_paragraph(style="List Bullet")
        r = p.add_run(t)
        _run(r, size=11)

    _p(doc, C["cite"], size=9, italic=True, color=SLATE, align=WD_ALIGN_PARAGRAPH.CENTER)
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(path))


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    files = [
        (OUT / "Support_theorique_pseudos_v1.2_FR.docx", "fr", "docx"),
        (OUT / "Theoretical_Guide_pseudos_v1.2_EN.docx", "en", "docx"),
        (OUT / "Support_theorique_pseudos_v1.2_FR.pptx", "fr", "pptx"),
        (OUT / "Theoretical_Guide_pseudos_v1.2_EN.pptx", "en", "pptx"),
    ]
    for p, lang, kind in files:
        if kind == "docx":
            build_docx_clean(p, lang)
        else:
            build_pptx(p, lang)
        print(p)


if __name__ == "__main__":
    main()

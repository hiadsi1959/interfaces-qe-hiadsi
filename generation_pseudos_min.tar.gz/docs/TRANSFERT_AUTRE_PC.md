# Guide complet — transfert de l’interface sur un autre PC

Ce document décrit **tout le processus** pour copier **generation_pseudos** (interface web + API Flask, port **5008**) d’un PC Linux vers un autre, puis le faire fonctionner avec Quantum ESPRESSO.

**Scripts concernés :**

| Script (racine) | Rôle |
|-----------------|------|
| **`TRANSFERER_VERS_AUTRE_PC.sh`** | **Recommandé** — tar + envoi + installation distante (tout-en-un) |
| **`emballer.sh`** | Compacter en `dist/*.tar.gz` (mode léger par défaut) |
| `TRANSFERT_AUTRE_PC.sh` | Alias rétrocompatible (mode complet par défaut) |
| `DEMARRER.sh` / `ARRETER.sh` / `configure.sh` | Lancer / arrêter / configurer |

Les scripts à la racine sont des **wrappers** vers `scripts/` — vous pouvez les lancer depuis le dossier du projet.

---

## Table des matières

1. [Vue d’ensemble](#1-vue-densemble)
2. [Prérequis](#2-prérequis)
3. [Script tout-en-un (recommandé)](#3-script-tout-en-un-recommandé)
4. [Contenu de l’archive tar](#4-contenu-de-larchive-tar)
5. [Scénarios pas à pas](#5-scénarios-pas-à-pas)
6. [Référence des options](#6-référence-des-options)
7. [Préparer SSH (réseau)](#7-préparer-ssh-réseau)
8. [Méthodes manuelles (USB, scp, rsync)](#8-méthodes-manuelles-usb-scp-rsync)
9. [Installation sur le PC destination](#9-installation-sur-le-pc-destination)
10. [Configuration api_config.json](#10-configuration-api_configjson)
11. [Lancement et vérifications](#11-lancement-et-vérifications)
12. [Après un transfert --leger](#12-après-un-transfert--leger)
13. [Binaires optionnels (ONCV, APE, ATOMPAW)](#13-binaires-optionnels-oncv-ape-atompaw)
14. [Dépannage complet](#14-dépannage-complet)
15. [Checklists](#15-checklists)
16. [Documents liés](#16-documents-liés)

---

## 1. Vue d’ensemble

```
┌──────────────── PC SOURCE ─────────────────┐
│  ./TRANSFERER_VERS_AUTRE_PC.sh             │
│    ① tar → dist/generation_pseudos_*.tar.gz│
│    ② scp ou copie USB                      │
│    ③ ssh : tar xzf + configure.sh + DEMARRER.sh │
└──────────────────┬─────────────────────────┘
                   │
         USB / réseau (scp)
                   │
                   ▼
┌──────────────── PC DESTINATION ────────────┐
│  ~/generation_pseudos/                     │
│  ./DEMARRER.sh                             │
│  Navigateur → http://127.0.0.1:5008/       │
└────────────────────────────────────────────┘
```

**Important :** l’interface est **autonome**. Un seul programme Python (`api_pseudos_standalone.py`) sert `index.html`, les scripts JS et toutes les routes `/api/pseudos/*`. Aucune dépendance à Interface-QE ni au port 5007.

**Ne jamais** ouvrir `index.html` en `file://` sur le nouveau PC — le tableau périodique et l’API ne fonctionneront pas sans le serveur Flask.

---

## 2. Prérequis

### PC source

| Élément | Détail |
|---------|--------|
| Dossier projet | Ex. `/home/user/generation_pseudos` |
| Espace disque | ~100 Mo libres dans `dist/` (mode léger) ou ~1 Go (archive complète) |
| Outils | `tar`, `gzip` ; pour le réseau : `ssh`, `scp` |

### PC destination

| Composant | Obligatoire | Vérification |
|-----------|-------------|--------------|
| Linux (Ubuntu / Debian) | oui | |
| Python 3 | oui | `python3 --version` |
| pip | oui | `pip3 --version` |
| flask, flask-cors | oui | installés automatiquement par `configure.sh` |
| Générateurs + bibliothèques (`ld1.x`, `pw.x`, `oncvpsp.x`, `ape`, `atompaw` + `lib/`) | **non** — inclus (`bin/` + `lib/`) | Les 4 générateurs, pw.x et leurs libs (MKL, MPI, libxc, GSL) sont embarqués |

### Choix du mode d’archive

| Mode | Commande | Taille | Contenu |
|------|----------|--------|---------|
| **Léger** | `--leger` | ~130 Mo | Interface + API + **binaires `bin/` + bibliothèques `lib/`** — sans `pseudos/` ni `third_party/` |
| **Complet** | (défaut) | ~500 Mo–1 Go | Tout y compris bibliothèque `pseudos/` |

Utilisez **`--leger`** par défaut : les 4 générateurs et leurs bibliothèques sont déjà inclus (`bin/` + `lib/`), seules les bibliothèques UPF restent à télécharger. Utilisez le **complet** pour une copie identique (PSLibrary, PseudoDojo déjà présents).

Dans les deux modes, `ld1.x`, `pw.x`, `oncvpsp.x`, `ape` et `atompaw` sont stockés dans l’archive comme **vrais fichiers** (les liens symboliques sont suivis) : aucun lien cassé après extraction. `emballer.sh` vérifie automatiquement l’archive (exécutables présents, `lib/` fournie, liens résolus, fichiers d’interface) et **refuse de la livrer** (code 1) si elle n’est pas autonome.

---

## 3. Script tout-en-un (recommandé)

### Première utilisation

```bash
cd /chemin/vers/generation_pseudos
chmod +x TRANSFERER_VERS_AUTRE_PC.sh TRANSFERT_AUTRE_PC.sh \
         DEMARRER.sh ARRETER.sh
```

### Mode interactif

```bash
./TRANSFERER_VERS_AUTRE_PC.sh
```

**Déroulement :**

1. **Étape 1/3 — Archive tar**  
   Crée `dist/generation_pseudos_YYYYMMDD.tar.gz` et affiche sa taille.

2. **Question destination**  
   - `1` → Réseau : saisir `utilisateur@192.168.1.50`  
   - `2` → USB : saisir `/media/usb` ou `~/Bureau`  
   - `3` → Arrêt : archive laissée dans `dist/` (copie manuelle)

3. **Étape 2/3 — Envoi**  
   - Réseau : `scp` vers `user@hôte:~/`  
   - USB : `cp` vers le dossier indiqué

4. **Étape 3/3 — Installation distante** (réseau seulement)  
   - Confirmation extraction + `configure.sh`/`DEMARRER.sh`  
   - Saisie du chemin QE distant optionnel (ou Entrée pour auto-détection — binaires inclus dans `bin/`)  
   - Exécution via `ssh`

### Mode automatique (sans questions)

```bash
# Réseau complet : tar léger + scp + extract + configure.sh + DEMARRER.sh (+ QE optionnel)
./TRANSFERER_VERS_AUTRE_PC.sh \
  --leger \
  --dest prof@192.168.1.50 \
  --qe-remote /home/prof/q-e-qe-7.5/bin \
  -y

# USB
./TRANSFERER_VERS_AUTRE_PC.sh --leger --copy-to /media/clé_USB/ -y

# Archive seulement
./TRANSFERER_VERS_AUTRE_PC.sh --archive-only --leger
```

### Ce que fait le script sur le PC distant (via ssh)

Commandes exécutées automatiquement :

```bash
cd ~
tar xzf generation_pseudos_YYYYMMDD.tar.gz
cd generation_pseudos
chmod +x configure.sh DEMARRER.sh GenerationPseudos ARRETER.sh
./configure.sh -y --qe /chemin/qe/bin   # --qe optionnel (binaires inclus dans bin/)
./DEMARRER.sh
# → configure.sh installe Flask si besoin, détecte les binaires de bin/, écrit api_config.json ;
#   DEMARRER.sh lance l’API (port 5008)
```

Message final : `Interface : http://127.0.0.1:5008/`

---

## 4. Contenu de l’archive tar

### Toujours inclus

- `index.html`, `pseudo_wizard.html`, tous les `script_*.js`, `logo_usto.png`
- `api_pseudos_standalone.py` et modules Python (`generator_guide.py`, etc.)
- `api_config.json`, `api_config.local.json.example`
- `oncv_default_*.dat` (liens → `data/oncv/`), `oncv_templates_3d/`
- `pseudo_generator_templates/`, scripts `scripts/`, documentation `docs/`
- **`bin/`** : `ld1.x`, `pw.x`, `oncvpsp.x`, `ape`, `atompaw` (4 générateurs + pw.x, ~47 Mo)
- **`lib/`** : bibliothèques dynamiques (MKL, Intel MPI, libxc, GSL, ~230 Mo) — portabilité sur tout PC Linux
- Dossiers vides ou sorties : `pseudos-oncvpsp/`, `pseudos-ld1/`, `pseudos_generes/`, etc.

### Exclu de toutes les archives

| Exclusion | Raison |
|-----------|--------|
| `dist/` | Évite d’archiver une ancienne archive |
| `archive/` | Fichiers jetables locaux |
| `_work/*` | Runs temporaires APE/ATOMPAW/ONCV (dont `bin/_work/`) |
| `logs/*.log` | Logs volumineux |
| `__pycache__/`, `*.pyc` | Cache Python |
| `oncvpsp-master/`, `.zip` | Sources lourdes (repli dans `data/oncvpsp_tests_data/`) |
| `pseudos_telechargés*` | Doublons locaux |

### Exclu en mode `--leger` uniquement

| Exclusion | Taille typique |
|-----------|----------------|
| `pseudos/` | ~800 Mo (PSLibrary, PseudoDojo, SSSP…) |
| `third_party/` | ~110 Mo (APE, ATOMPAW compilés) |

⚠️ `third_party/` est exclu, mais `bin/` **et** `lib/` restent inclus : les 5 binaires y sont recopiés en dur par `scripts/vendor_generators.sh` (plus de lien `bin/ape → ../third_party/ape/bin/ape`), donc le mode léger reste autonome.

### Emplacement de l’archive

```text
/chemin/vers/generation_pseudos/dist/generation_pseudos_YYYYMMDD.tar.gz
```

**Pas** dans `~/` à la racine du home — toujours dans le sous-dossier **`dist/`** du projet.

---

## 5. Scénarios pas à pas

### Scénario A — Réseau, installation automatique (cas le plus courant)

**PC source :**

```bash
cd ~/generation_pseudos
./TRANSFERER_VERS_AUTRE_PC.sh \
  --leger \
  --dest etudiant@10.0.0.25 \
  --qe-remote /home/etudiant/q-e-qe-7.5/bin \
  -y
```

**PC destination :** ouvrir **http://127.0.0.1:5008/** (la configuration distante a déjà lancé `./DEMARRER.sh`).

---

### Scénario B — Clé USB (sans réseau)

**PC source :**

```bash
./TRANSFERER_VERS_AUTRE_PC.sh --leger --copy-to /media/usb/ -y
```

Copier `generation_pseudos_YYYYMMDD.tar.gz` depuis la clé.

**PC destination :**

```bash
cp /media/usb/generation_pseudos_*.tar.gz ~/
cd ~
tar xzf generation_pseudos_*.tar.gz
cd generation_pseudos
./configure.sh -y && ./DEMARRER.sh
```

---

### Scénario C — Envoi seulement (install plus tard)

```bash
./TRANSFERER_VERS_AUTRE_PC.sh --leger --dest user@IP --no-deploy -y
```

Sur le distant, quand vous êtes prêt :

```bash
cd ~ && tar xzf generation_pseudos_*.tar.gz && cd generation_pseudos
./configure.sh -y && ./DEMARRER.sh
```

---

### Scénario D — scp sans extraction automatique

```bash
./TRANSFERER_VERS_AUTRE_PC.sh --leger --dest user@IP --no-extract -y
```

L’archive est dans `~/` sur le distant ; extraction manuelle.

---

### Scénario E — Archive complète avec bibliothèque pseudos

```bash
# Peut prendre 5–15 minutes
./TRANSFERER_VERS_AUTRE_PC.sh --dest user@IP -y
# (sans --leger → inclut pseudos/)
```

---

### Scénario F — Deux étapes (scripts séparés)

```bash
# 1. Archive
./emballer.sh
# ou mode complet :
./emballer.sh --complet

# 2. Envoi manuel
scp dist/generation_pseudos_*.tar.gz user@IP:~/
```

---

### Scénario G — rsync (sans tar, synchronisation directe)

Pas de script automatique — commande manuelle :

```bash
rsync -av --progress \
  --exclude='dist/' \
  --exclude='archive/' \
  --exclude='logs/*.log' \
  --exclude='_work/*' \
  --exclude='__pycache__/' \
  ~/generation_pseudos/ \
  user@IP:~/generation_pseudos/
```

Sur le distant : `cd ~/generation_pseudos && ./configure.sh && ./DEMARRER.sh`

---

## 6. Référence des options

### `TRANSFERER_VERS_AUTRE_PC.sh`

| Option | Description |
|--------|-------------|
| `--leger` | Exclut `pseudos/` et `third_party/` |
| `--dest USER@HOST` | Destination `scp` + `ssh` |
| `--copy-to CHEMIN` | Copie locale (USB, autre disque) |
| `--remote-dir DIR` | Répertoire distant pour scp (défaut : `~`) |
| `--qe-remote CHEMIN` | Argument `--qe` passé à `configure.sh` sur le distant (optionnel : binaires inclus dans `bin/`) |
| `--no-deploy` | N’exécute pas `configure.sh` / `DEMARRER.sh` après extraction |
| `--no-extract` | Arrêt après scp (pas d’ssh extract) |
| `--archive-only` | Crée l’archive et s’arrête |
| `-y`, `--yes` | Pas de confirmation interactive |
| `-h`, `--help` | Aide |

**Combinaisons utiles :**

```bash
./TRANSFERER_VERS_AUTRE_PC.sh --help
./TRANSFERER_VERS_AUTRE_PC.sh --archive-only --leger
./TRANSFERER_VERS_AUTRE_PC.sh --dest u@h --remote-dir /opt/pseudos -y
./TRANSFERER_VERS_AUTRE_PC.sh --dest u@h --no-deploy -y
```

### `emballer.sh` (archive seule, recommandé)

```bash
./emballer.sh                  # léger (~130 Mo, autonome et vérifié)
./emballer.sh --complet        # avec pseudos/ et third_party/
./emballer.sh --output ~/Bureau/backup.tar.gz
```

| Option | Description |
|--------|-------------|
| `--leger` | Sans `pseudos/` ni `third_party/` ; `bin/` (vrais fichiers) + `lib/` inclus (défaut) |
| `--complet` | Archive complète |
| `--no-verify` | Ne pas vérifier l’autonomie de l’archive |
| `--output PATH` | Chemin de sortie personnalisé |
| `--print-path` | Affiche uniquement le chemin (usage interne) |

### `TRANSFERT_AUTRE_PC.sh` (alias)

Même fonction que `emballer.sh`, mais **mode complet par défaut** (comportement historique).

---

## 7. Préparer SSH (réseau)

Pour que `TRANSFERER_VERS_AUTRE_PC.sh` fonctionne sans mot de passe à chaque étape :

### Test de connexion

```bash
ssh utilisateur@192.168.1.50
# doit ouvrir un shell sur le PC distant
```

### Clé SSH (recommandé)

**Sur le PC source :**

```bash
ssh-keygen -t ed25519 -N "" -f ~/.ssh/id_ed25519   # si pas déjà de clé
ssh-copy-id utilisateur@192.168.1.50
ssh utilisateur@192.168.1.50 "echo OK"
```

### Si ssh demande un mot de passe

Le script bascule en mode **ssh interactif** — acceptable, mais vous devrez saisir le mot de passe pour `scp` puis `ssh`.

### Pare-feu

- Port **22** (ssh/scp) ouvert entre les deux PC
- Les deux machines sur le même réseau local ou VPN

---

## 8. Méthodes manuelles (USB, scp, rsync)

### USB — étapes détaillées

1. `./TRANSFERER_VERS_AUTRE_PC.sh --archive-only --leger`
2. Brancher la clé, monter si nécessaire : `ls /media/$USER/`
3. `cp dist/generation_pseudos_*.tar.gz /media/clé/`
4. Sur l’autre PC : copier l’archive dans `~/`
5. `tar xzf ~/generation_pseudos_*.tar.gz`

### scp manuel

```bash
scp ~/generation_pseudos/dist/generation_pseudos_20260523.tar.gz user@IP:~/
ssh user@IP "ls -lh ~/generation_pseudos_*.tar.gz"
```

### Vérifier l’intégrité (optionnel)

```bash
# Source
ls -lh dist/generation_pseudos_*.tar.gz
tar tzf dist/generation_pseudos_*.tar.gz | head -20

# Destination après copie
tar tzf ~/generation_pseudos_*.tar.gz | head -5
# doit lister generation_pseudos/index.html etc.
```

---

## 9. Installation sur le PC destination

### Extraction

```bash
cd ~
tar xzf generation_pseudos_*.tar.gz
cd generation_pseudos
ls -la index.html api_pseudos_standalone.py DEMARRER.sh
```

### configure.sh + DEMARRER.sh

```bash
chmod +x configure.sh DEMARRER.sh ARRETER.sh

./configure.sh -y                      # détection automatique (binaires de bin/ inclus)

# options facultatives :
./configure.sh --qe /home/user/q-e-qe-7.5/bin \
  --pseudos /home/user/generation_pseudos/pseudos \
  --port 5008

./DEMARRER.sh
```

**Actions de `configure.sh` :**

1. Installe les **prérequis système** de l’interface (`python3`, `python3-pip`, `curl`, `lsof`, `ca-certificates`, navigateur / `xdg-utils`) via `sudo` non interactif si possible, sinon affiche la commande à lancer (`--no-install` pour ne rien installer)  
2. Installe les **dépendances Python** (`flask`, `flask-cors`, `requests`) depuis `requirements.txt`  
3. Supprime les liens `bin/ape`, `bin/atompaw`… cassés si `third_party/` n’a pas été transféré  
4. Détecte les binaires de `bin/` (`ld1.x`, `pw.x`, `oncvpsp.x`, `ape`, `atompaw`) — **inclus dans l’archive** avec leurs bibliothèques `lib/`  
5. Vérifie que les binaires se chargent (`ldd` + `lib/`)  
6. Crée `pseudos/`, `pseudos-oncvpsp/`, `pseudos-ld1/`, `pseudos-APE/`, `pseudos-atompaw/`, `logs/`, etc.  
7. Met à jour `api_config.json` avec des **chemins relatifs au projet** (`bin`, `bin/ld1.x`, `pseudos`, `lib`…) : l’installation reste valide quel que soit l’utilisateur ou le nom du dossier sur le PC cible. Les chemins absolus hérités d’un autre PC et introuvables sont supprimés puis redétectés.  
8. Vérifie les fichiers requis par l’interface  
9. `./DEMARRER.sh` lance ensuite l’API (port **5008**)

### Si un binaire n’est pas détecté

Cas rare : les binaires de `bin/` sont inclus dans l’archive. Pour utiliser ceux d’une autre installation :

```bash
# Trouver pw.x / ld1.x existants sur la machine
which pw.x ld1.x
# ou
find ~ -name pw.x 2>/dev/null | head -3

./configure.sh --qe /chemin/trouvé/bin -y
./DEMARRER.sh
```

---

## 10. Configuration api_config.json

Modèle : `api_config.local.json.example`

```bash
cp api_config.local.json.example api_config.json
nano api_config.json
```

Exemple complet :

Chemins **relatifs à la racine du projet** quand le prérequis est dans le dossier
(recommandé : portable vers un autre PC) :

```json
{
  "bin_dir": "bin",
  "lib_dir": "lib",
  "qe_bin": "bin",
  "ld1_bin": "bin/ld1.x",
  "pw_bin": "bin/pw.x",
  "oncvpsp_bin": "bin/oncvpsp.x",
  "ape_bin": "bin/ape",
  "atompaw_bin": "bin/atompaw",
  "oncvpsp_root": ".",
  "pseudos_dir": "pseudos",
  "oncv_default_target": "qe"
}
```

Chemins absolus : uniquement pour un prérequis installé hors du dossier, par exemple
`"qe_bin": "/home/user/q-e-qe-7.5/bin"` ou `"oncvpsp_bin": "/opt/oncvpsp/bin/oncvpsp.x"`.

Variables d’environnement (prioritaires ou complément) :

```bash
export QE_BIN=/home/user/q-e-qe-7.5/bin
export GEN_PORT=5008
export ONCVPSP_BIN=/home/user/oncvpsp/build/bin/oncvpsp.x
export ONCVPSP_ROOT=/home/user/oncvpsp
./DEMARRER.sh
```

---

## 11. Lancement et vérifications

### Démarrage

```bash
cd ~/generation_pseudos
./DEMARRER.sh
```

**URL :** http://127.0.0.1:5008/

Le script peut ouvrir le navigateur automatiquement.

### Arrêt

```bash
./ARRETER.sh
```

### Redémarrage propre (après mise à jour du code)

```bash
./RELANCER.sh
```

### Tests automatiques

```bash
python3 verifier_api_generale.py
# Attendu : Résumé : 15 OK, 0 échec(s)

./scripts/verifier_chemins_ui.sh
# Attendu : → Chemins UI OK.
```

### Tests manuels API

```bash
curl -s http://127.0.0.1:5008/health
curl -s http://127.0.0.1:5008/api/pseudos/version | python3 -m json.tool
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:5008/oncv_default_Cu.dat
# Attendu : 200
```

### Checklist navigateur

- [ ] Tableau périodique visible  
- [ ] Clic sur un élément → panneau générateur à droite  
- [ ] Onglets ld1 / PseudoDojo / ONCV chargent  
- [ ] Pas de bandeau « API hors ligne »  
- [ ] URL = `http://127.0.0.1:5008/` (pas `file://`)

### Logs

```bash
tail -f logs/api_pseudos_standalone.log
```

---

## 12. Après un transfert `--leger`

La bibliothèque `pseudos/` n’est **pas** dans l’archive. Sur le nouveau PC :

```bash
cd ~/generation_pseudos
./install_bibliotheques_pseudos.sh
./telecharger_lanthanides_nc.sh          # lanthanides La–Lu (optionnel)
./DEMARRER.sh
```

Dans l’interface : onglet **PseudoDojo** ou **PSLibrary** → **Synchroniser maintenant**.

Téléchargements manuels :

- PSLibrary : https://pseudopotentials.quantum-espresso.org/  
- PseudoDojo : https://www.pseudo-dojo.org/  
- SSSP : https://www.materialscloud.org/discover/sssp  

Voir aussi `pseudos/README_BIBLIOTHEQUES.md`.

---

## 13. Binaires des générateurs (ld1, ONCV, APE, ATOMPAW)

**Inclus dans `bin/` + `lib/`** dans tous les modes d’archive (`--leger` comme complet) : `ld1.x`, `pw.x`, `oncvpsp.x`, `ape`, `atompaw` et leurs bibliothèques dynamiques (MKL, Intel MPI, libxc, GSL). **Aucune installation supplémentaire** sur le nouveau PC — `configure.sh` les détecte et `DEMARRER.sh` ajoute `lib/` à `LD_LIBRARY_PATH`.

`bin/ape` et `bin/atompaw` sont des **copies** des binaires de `third_party/` (et non des liens symboliques) : l’archive `--leger`, qui exclut `third_party/`, reste donc utilisable. Pour restaurer ces copies après un transfert ou une mise à jour d’APE/ATOMPAW : `bash scripts/vendor_generators.sh`.

Pour remplacer un binaire (autre version, autre machine) :

| Outil | Action |
|-------|--------|
| **ld1.x / pw.x** | Remplacer `bin/ld1.x`, `bin/pw.x` ou installer Quantum ESPRESSO puis `./configure.sh --qe /chemin/qe/bin -y` |
| **ONCVPSP** | Compiler [oncvpsp](https://github.com/oncvpsp/oncvpsp) → copier dans `bin/oncvpsp.x` |
| **APE / ATOMPAW** | `./install_ape_atompaw.sh` (compile dans `third_party/`) ou copier le binaire dans `bin/` |

Puis relancer : `./configure.sh` et `./DEMARRER.sh`

---

## 14. Dépannage complet

### Archive / TRANSFERT

| Problème | Cause probable | Solution |
|----------|----------------|----------|
| « Ça ne donne rien » | Archive cherchée dans `~/` | Regarder `generation_pseudos/dist/` |
| `Permission non accordée` | Droits sur `dist/` | `mkdir -p dist && chmod u+w dist` |
| tar très long | Gros `pseudos/` | Utiliser `--leger` |
| Archive 0 octet | Erreur tar / espace | `df -h .` ; relancer |
| `dist/` introuvable | Premier run | Créé automatiquement par le script |

### Réseau / SSH

| Problème | Solution |
|----------|----------|
| `ssh: connect to host … Connection refused` | Vérifier IP, sshd actif : `sudo systemctl status ssh` sur le distant |
| `Permission denied (publickey)` | `ssh-copy-id user@host` ou utiliser mot de passe |
| scp bloqué | Tester `ssh user@host` d’abord |
| Configuration distante échoue via ssh | Se connecter manuellement : `./configure.sh && ./DEMARRER.sh` |

### Interface / API

| Problème | Solution |
|----------|----------|
| Page sans CSS / tableau absent | URL `http://127.0.0.1:5008/`, pas `file://` |
| « API hors ligne » | `lsof -i:5008` ; `./DEMARRER.sh` |
| Port 5008 occupé | `export GEN_PORT=5009` puis `./DEMARRER.sh` |
| `ld1.x introuvable` | `qe_bin` dans `api_config.json` → dossier contenant `ld1.x` |
| ONCV indisponible | Installer ONCVPSP, `oncvpsp_bin` dans config |
| Version API obsolète | `./RELANCER.sh` |

### Commandes de diagnostic

```bash
# Processus API
lsof -i:5008
cat logs/api_pseudos_standalone.pid 2>/dev/null

# Config
python3 -c "import json; print(json.load(open('api_config.json')))"

# QE
ls -la "$(python3 -c "import json; print(json.load(open('api_config.json')).get('qe_bin',''))")"/pw.x
```

---

## 15. Checklists

### Avant le transfert (PC source)

- [ ] `./DEMARRER.sh` fonctionne localement  
- [ ] `python3 verifier_api_generale.py` → 15 OK  
- [ ] Espace disque suffisant dans `dist/`  
- [ ] Choix `--leger` ou complet  
- [ ] Si réseau : `ssh user@dest` OK  

### Après le transfert (PC destination)

- [ ] `tar xzf` sans erreur  
- [ ] `ls generation_pseudos/index.html`  
- [ ] `./configure.sh` puis `./DEMARRER.sh` terminés  
- [ ] http://127.0.0.1:5008/ — tableau visible  
- [ ] Si `--leger` : `install_bibliotheques_pseudos.sh` exécuté  

---

## 16. Documents liés

| Document | Contenu |
|----------|---------|
| [INSTALLATION_AUTRE_PC.md](INSTALLATION_AUTRE_PC.md) | Vue courte installation |
| [STRUCTURE.md](STRUCTURE.md) | Arborescence du projet |
| [CHEMINS_INTERFACE.md](CHEMINS_INTERFACE.md) | Fichiers à ne pas déplacer |
| [ARCHIVE.md](ARCHIVE.md) | Dossier `archive/` local |
| `pseudos/README_BIBLIOTHEQUES.md` | Téléchargement PSLibrary / PseudoDojo |

---

## Récapitulatif — une commande

```bash
# PC source
cd ~/generation_pseudos
./TRANSFERER_VERS_AUTRE_PC.sh --leger --dest USER@IP --qe-remote ~/q-e-qe-7.5/bin -y

# PC destination (si install manuelle)
# tar xzf ~/generation_pseudos_*.tar.gz && cd generation_pseudos
# ./configure.sh && ./DEMARRER.sh
# → http://127.0.0.1:5008/
```

---

Prof. S. Hiadsi — LMESM, USTO-MB — said.hiadsi@univ-usto.dz

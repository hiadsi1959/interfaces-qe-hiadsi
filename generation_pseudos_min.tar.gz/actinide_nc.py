# -*- coding: utf-8 -*-
"""
Pseudopotentiels pour les actinides (Z 89–103, canal 5f).

Philosophie physique (≠ copier-coller lanthanides 4f) :
  - Début de série (Th–Np, souvent Pu) : 5f plus étendu / liant → valence_f
    (ou PAW bibliothèque) ; open-core rarement justifié pour la chimie.
  - Milieu / fin (Am–Lr) : 5f plus localisé → open_core admissible pour
    structure / thermo / phonons ; valence_f + U pour magnétisme.
  - Ac : peu/pas de 5f actif (analogue La) ; Lr : 5f14 fermé (analogue Lu).
  - Relativité + SOC critiques ; ONCV scalaire fragile → préférer UPF/PAW validés.
  - Ne pas inventer de config neutre 5fⁿ « maison » pour oncvpsp.x.

Références conceptuelles :
  - PseudoDojo / ONCVPSP (génération NC soignée, ex. U 6s²6p⁶7s²6d¹5f³ en lit.)
  - SSSP / JTH PAW pour production pw.x
  - Littérature 5f-in-core (GTH etc.) pour An(III)/An(IV) ioniques — cas limités
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

ACTINIDE_SYMBOLS: tuple[str, ...] = (
    "Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf",
    "Es", "Fm", "Md", "No", "Lr",
)

# Familles physiques (pas seulement numériques)
_EARLY_ITINERANT: frozenset[str] = frozenset({"Th", "Pa", "U", "Np", "Pu"})
_LATE_LOCALIZED: frozenset[str] = frozenset(
    {"Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No"}
)

# Valence avec 5f actifs (référence chimique / atomique simplifiée)
_VALENCE_F: dict[str, str] = {
    "Ac": "6d1 7s2",
    "Th": "6d2 7s2",           # 5f souvent vide / hybridé
    "Pa": "5f2 6d1 7s2",
    "U": "5f3 6d1 7s2",
    "Np": "5f4 6d1 7s2",
    "Pu": "5f6 7s2",
    "Am": "5f7 7s2",
    "Cm": "5f7 6d1 7s2",
    "Bk": "5f9 7s2",
    "Cf": "5f10 7s2",
    "Es": "5f11 7s2",
    "Fm": "5f12 7s2",
    "Md": "5f13 7s2",
    "No": "5f14 7s2",
    "Lr": "6d1 7s2",           # 5f14 dans le cœur
}

# Open-core : 5f gelé ; 6s/6p semi-cœur + 6d/7s
_OPEN_CORE: dict[str, str] = {
    "Ac": "6s2 6p6 6d1 7s2",
    "Th": "6s2 6p6 6d2 7s2",
    "Pa": "6s2 6p6 6d1 7s2",
    "U": "6s2 6p6 6d1 7s2",
    "Np": "6s2 6p6 6d1 7s2",
    "Pu": "6s2 6p6 7s2",
    "Am": "6s2 6p6 7s2",
    "Cm": "6s2 6p6 6d1 7s2",
    "Bk": "6s2 6p6 7s2",
    "Cf": "6s2 6p6 7s2",
    "Es": "6s2 6p6 7s2",
    "Fm": "6s2 6p6 7s2",
    "Md": "6s2 6p6 7s2",
    "No": "6s2 6p6 7s2",
    "Lr": "6s2 6p6 6d1 7s2",
}

# Défaut pour décision UI / ONCV (physique + stabilité)
_ONCV_DEFAULT_FT: dict[str, str] = {
    "Ac": "valence_f",    # pas de 5f chimique
    "Th": "valence_f",    # 5f liant / hybride — ne pas geler par défaut
    "Pa": "valence_f",
    "U": "valence_f",
    "Np": "valence_f",
    "Pu": "valence_f",    # borderline ; composé-dépendant
    "Am": "open_core",    # 5f plus localisé
    "Cm": "open_core",
    "Bk": "open_core",
    "Cf": "open_core",
    "Es": "open_core",
    "Fm": "open_core",
    "Md": "open_core",
    "No": "open_core",
    "Lr": "valence_f",    # 5f14 fermé
}

_PROBLEM_FT: dict[str, str] = {
    "thermo": "auto",
    "thermo_pw": "auto",
    "elastic": "auto",
    "phonon": "auto",
    "qha": "auto",
    "optics": "auto",
    "optical": "auto",
    "dielectric": "auto",
    "structure": "auto",
    "relax": "auto",
    "scf": "auto",
    "generation": "auto",
    "oncv": "auto",
    "oncvpsp": "auto",
    "magnetism": "valence_f",
    "magnetic": "valence_f",
    "moment": "valence_f",
    "moments": "valence_f",
    "dft_u": "valence_f",
    "hubbard": "valence_f",
    "spin": "valence_f",
    "bonding": "valence_f",
    "chemistry": "valence_f",
    "oxidation": "valence_f",
}

_ELEMENT_NOTES: dict[str, str] = {
    "Ac": "Peu/pas de 5f actif — valence 6d/7s (analogue La).",
    "Th": "5f souvent hybride / vide en ion — valence 6d/7s ; open-core rarement adapté à la chimie.",
    "Pa": "Début de série : 5f liant → valence_f ou PAW ; éviter f-in-core pour liaisons.",
    "U": "5f³ typique : valence_f (+ U, SOC) pour oxydes/carbures ; PAW/SSSP recommandé en production.",
    "Np": "5f itinérant — valence_f ; open-core seulement si référence ionique justifiée.",
    "Pu": "Frontière itinérant/localisé — composé-dépendant ; défaut valence_f ; tester les deux.",
    "Am": "5f plus localisé — open-core OK pour structure/thermo ; valence_f + U si magnétisme.",
    "Cm": "Demi-rempli 5f⁷ — open-core thermo ; magnétisme → valence_f + DFT+U + spin.",
    "Bk": "Fin de série localisée — open-core ONCV/biblio ; valence_f fragile.",
    "Cf": "Comme Bk — open-core pour thermo ; bibliothèque PAW préférée.",
    "Es": "Radioactif / rare — UPF/PAW validés ; open-core conceptuel.",
    "Fm": "Idem Es — ne pas générer un .dat 5f neutre artisanal.",
    "Md": "Idem — bibliothèque + relativité forte.",
    "No": "Souvent 5f¹⁴ cœur-like — open-core ; valence_f rare.",
    "Lr": "5f¹⁴ fermé — valence 6d/7s ; peu de problème 5f.",
}

_ELEMENT_NOTES_EN: dict[str, str] = {
    "Ac": "Little/no active 5f — 6d/7s valence (La analogue).",
    "Th": "5f often hybrid/empty in ions — 6d/7s valence; open-core rarely suited to chemistry.",
    "Pa": "Early series: bonding 5f → valence_f or PAW; avoid f-in-core for bonding.",
    "U": "Typical 5f³: valence_f (+ U, SOC) for oxides/carbides; PAW/SSSP for production.",
    "Np": "Itinerant 5f — valence_f; open-core only if ionic reference is justified.",
    "Pu": "Itinerant/localized border — compound-dependent; default valence_f; test both.",
    "Am": "More localized 5f — open-core OK for structure/thermo; valence_f + U if magnetism.",
    "Cm": "Half-filled 5f⁷ — open-core thermo; magnetism → valence_f + DFT+U + spin.",
    "Bk": "Late localized series — open-core ONCV/library; valence_f fragile.",
    "Cf": "Like Bk — open-core for thermo; prefer PAW library.",
    "Es": "Radioactive/rare — validated UPF/PAW; conceptual open-core.",
    "Fm": "Same — do not invent a homemade neutral 5f .dat.",
    "Md": "Same — library + strong relativity.",
    "No": "Often 5f¹⁴ core-like — open-core; valence_f rare.",
    "Lr": "Closed 5f¹⁴ — 6d/7s valence; little 5f trouble.",
}

_NOTE_DIR = Path(__file__).resolve().parent / "oncv_templates_actinide"


def is_actinide(sym: str) -> bool:
    return _norm(sym) in ACTINIDE_SYMBOLS


def actinide_family(sym: str) -> str:
    """early_itinerant | late_localized | edge_ac | edge_lr"""
    sym = _norm(sym)
    if sym == "Ac":
        return "edge_ac"
    if sym == "Lr":
        return "edge_lr"
    if sym in _EARLY_ITINERANT:
        return "early_itinerant"
    if sym in _LATE_LOCALIZED:
        return "late_localized"
    return "unknown"


def normalize_f_treatment(mode: str | None) -> str:
    if mode is None or str(mode).strip() == "":
        return "auto"
    m = str(mode).strip().lower().replace("-", "_")
    if m in ("open", "open_core", "core", "frozen_f", "inert_f", "f_in_core", "5f_in_core"):
        return "open_core"
    if m in ("auto", "default", "recommended"):
        return "auto"
    return "valence_f"


def normalize_problem(problem: str | None) -> str | None:
    if not problem:
        return None
    p = problem.strip().lower().replace("-", "_").replace(" ", "_")
    return p or None


def default_oncv_f_treatment(sym: str) -> str:
    sym = _norm(sym)
    return _ONCV_DEFAULT_FT.get(sym, "valence_f")


def recommend_f_treatment(
    sym: str,
    problem: str | None = None,
    *,
    for_oncv: bool = True,
) -> dict[str, Any]:
    sym = _norm(sym)
    fam = actinide_family(sym)
    pn = normalize_problem(problem)
    if pn and pn in _PROBLEM_FT:
        raw = _PROBLEM_FT[pn]
        ft = default_oncv_f_treatment(sym) if raw == "auto" else raw
        # Thermo sur actinides précoces : rester valence_f (5f liant)
        if raw == "auto" and fam == "early_itinerant":
            ft = "valence_f"
        if raw == "auto" and fam == "late_localized":
            ft = "open_core"
        reason = f"problem={pn}"
    else:
        if for_oncv:
            ft = default_oncv_f_treatment(sym)
            reason = "ONCV : défaut stabilité (Am–No open_core ; Th–Pu valence_f, 5f liant)."
        else:
            # ATOMPAW / ld1 : même partition physique (5f itinerant vs localisé)
            ft = "open_core" if fam == "late_localized" else "valence_f"
            reason = (
                "Physique 5f : Th–Pu itinerant → valence_f ; "
                "Am–No localisé → open_core."
            )

    prefer_library = fam in ("early_itinerant",) or sym in ("U", "Np", "Pu", "Pa")
    return {
        "element": sym,
        "family": fam,
        "f_treatment": ft,
        "reason": reason,
        "prefer_library_upf": prefer_library,
        "prefer_paw": prefer_library,
        "warn_scalar_oncv": True,
        "note": _ELEMENT_NOTES.get(sym, ""),
    }


def resolve_f_treatment(
    sym: str,
    f_treatment: str | None = None,
    problem: str | None = None,
    *,
    for_oncv: bool = True,
) -> str:
    m = normalize_f_treatment(f_treatment)
    if m == "auto":
        return recommend_f_treatment(sym, problem, for_oncv=for_oncv)["f_treatment"]
    return m


def valence_string(sym: str, f_treatment: str | None = None) -> str:
    sym = _norm(sym)
    ft = resolve_f_treatment(sym, f_treatment, None, for_oncv=True)
    if ft == "open_core":
        return _OPEN_CORE.get(sym, "6s2 6p6 7s2")
    return _VALENCE_F.get(sym, "6d1 7s2")


def valence_occ_dict(sym: str, f_treatment: str | None = None) -> dict[tuple[int, int], int]:
    """Occupations de valence pour ATOMPAW / APE (actinides)."""
    out: dict[tuple[int, int], int] = {}
    for n, l, occ in parse_valence_tokens(valence_string(sym, f_treatment)):
        out[(n, l)] = int(round(occ))
    if (6, 0) not in out:
        out[(6, 0)] = 2
    if (6, 1) not in out:
        out[(6, 1)] = 6
    return out


def frozen_f_occ(sym: str) -> dict[tuple[int, int], int]:
    """5f à placer dans le cœur (open_core / Lr)."""
    sym = _norm(sym)
    if sym == "Lr":
        return {(5, 3): 14}
    out: dict[tuple[int, int], int] = {}
    for n, l, occ in parse_valence_tokens(_VALENCE_F.get(sym, "")):
        if l == 3:
            out[(n, l)] = int(round(occ))
    return out


def library_upf_hints(sym: str) -> list[dict[str, str]]:
    """UPF / PAW locaux s’ils existent (pas de gabarit PseudoDojo actinide embarqué)."""
    sym = _norm(sym)
    root = Path(__file__).resolve().parent / "pseudos"
    extra_dirs = [
        root,
        root / "SSSP_precision",
        root / "SSSP_efficiency",
        root / "PseudoDojo_standard",
        root / "PseudoDojo_stringent",
        root / "Actinides",
        root / "Actinides_NC",
        root / "PSLibrary_PAW_PBE",
        root / "PSLibrary_USPP_PBE",
        root / "PBE" / "PAW",
        root / "PBE" / "USPP",
        root / "LDA" / "PAW",
        root / "LDA" / "USPP",
    ]
    out: list[dict[str, str]] = []
    seen: set[str] = set()
    for d in extra_dirs:
        if not d.is_dir():
            continue
        for p in sorted(d.glob(f"{sym}*")):
            if not p.is_file():
                continue
            if p.suffix.lower() not in (".upf", ".psp8", ".xml"):
                continue
            key = str(p.resolve())
            if key in seen:
                continue
            seen.add(key)
            out.append({"path": str(p), "name": p.name, "variant": _tag_variant(p.name)})
    return out


def _tag_variant(name: str) -> str:
    n = name.lower()
    if "paw" in n:
        return "paw"
    if "f-in-core" in n or "fin_core" in n or "5f" in n and "core" in n:
        return "f-in-core"
    if "oncv" in n or "nc" in n:
        return "nc"
    return "library"


def load_science_note_5f(lang: str = "fr") -> str:
    lang = "en" if str(lang).lower().startswith("en") else "fr"
    name = "NOTE_SCIENTIFIQUE_5F_EN.txt" if lang == "en" else "NOTE_SCIENTIFIQUE_5F.txt"
    path = _NOTE_DIR / name
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        if lang == "en":
            return load_science_note_5f("fr")
        return (
            "Note scientifique 5f (actinides) indisponible — "
            "voir actinide_nc.py / oncv_templates_actinide/."
        )


def _pre_calc_notice_fr(sym: str, ft: str) -> dict[str, Any]:
    sym = _norm(sym)
    fam = actinide_family(sym)
    fam_label = {
        "early_itinerant": "début de série (5f liant / hybride)",
        "late_localized": "fin de série (5f localisé)",
        "edge_ac": "bord Ac (peu de 5f)",
        "edge_lr": "bord Lr (5f¹⁴ fermé)",
    }.get(fam, fam)
    sections = [
        {
            "heading": "1. Pourquoi le 5f n’est pas le 4f",
            "body": (
                "Chez les lanthanides, le 4f est très localisé et peu liant → open-core "
                "souvent justifié. Chez les actinides précoces (Th–Np, souvent Pu), le 5f "
                "est plus étendu et participe à la liaison : le geler peut fausser structure "
                "et chimie. En fin de série (Am–No), le 5f se localise → open-core redevient "
                "pertinent pour thermo / phonons."
            ),
        },
        {
            "heading": "2. Solution A — Valence 5f active (défaut début de série)",
            "body": (
                "Garder 5f (+ 6d/7s, semi-cœur 6s/6p) dans la valence. Indispensable si "
                "liaison, états d’oxydation variables, magnétisme ou DFT+U. En pratique : "
                "spin, Hubbard U sur 5f, et idéalement SOC. Production : UPF/PAW SSSP ou "
                "PseudoDojo plutôt qu’un .dat ONCV artisanal."
            ),
        },
        {
            "heading": "3. Solution B — Open-core / 5f-in-core (fin de série / ionique)",
            "body": (
                "Geler 5fⁿ dans le cœur pour structure, thermo, optique si le 5f est "
                "localisé et ne porte pas l’observable. Valence typique : 6s² 6p⁶ (+ 6d/7s). "
                "Analogie avec les 5f-in-core de la littérature (réf. An³⁺/An⁴⁺), mais "
                "pas une licence pour Th/U « f-in-core » sans justification."
            ),
        },
        {
            "heading": "4. Pourquoi ONCV scalaire est fragile",
            "body": (
                "sratom peut échouer sur n=5, ℓ=3 (5f) — même logique que lschfb 4 3 "
                "pour le 4f. Relativité forte + SOC ; une config neutre 5fⁿ maison est "
                "souvent mauvaise référence. Préférer bibliothèque validée."
            ),
        },
        {
            "heading": "5. Que fait ce générateur pour " + sym,
            "body": (
                f"Famille : {fam_label}. Traitement proposé : "
                + ("open-core (5f gelé)." if ft == "open_core" else "valence 5f active.")
                + " Pas de gabarit PseudoDojo actinide embarqué comme pour La–Lu : "
                "l’UI oriente vers UPF/PAW locaux s’ils existent, et affiche la valence "
                f"recommandée ({valence_string(sym, ft)})."
            ),
        },
        {
            "heading": "6. Règle de décision",
            "body": (
                "Th–Pu (chimie / liaison) → valence_f ou PAW. "
                "Am–No (thermo / structure) → open_core admissible. "
                "Magnétisme / U / moment 5f → toujours valence_f. "
                "Ac / Lr → valence 6d/7s."
            ),
        },
    ]
    return {
        "title": f"Avant de lancer ONCVPSP — {sym} (5f) : raisons physiques",
        "summary": (
            f"{sym} : actinide ({fam_label}). Ne pas appliquer aveuglément la solution "
            "Dy/4f : le 5f peut être liant (début) ou localisé (fin)."
        ),
        "collapse_hint": "(replier / déplier)",
        "element_note": _ELEMENT_NOTES.get(sym, ""),
        "element_label": "Élément",
        "f_treatment": ft,
        "f_treatment_label": (
            "Open core (5f gelé)" if ft == "open_core" else "Valence 5f active"
        ),
        "f_treatment_heading": "Traitement 5f pour ce run",
        "family": fam,
        "family_label": fam_label,
        "generator_heading": "Dans ce générateur",
        "by_problem_heading": "Choix selon le problème",
        "physics_sections": sections,
        "what_we_do": (
            "Conseils cas par cas + note 5f ; pas de substitution automatique vers un "
            "gabarit lanthanide. Cherchez un UPF/PAW validé pour la production. "
            f"Valence proposée : {valence_string(sym, ft)}."
        ),
        "by_problem": {
            "thermo_optique_structure_phonon": (
                "Début (Th–Pu) : valence_f / PAW — le 5f peut lier. "
                "Fin (Am–No) : open_core OK pour maille/phonons."
            ),
            "magnetisme_dft_u": "valence_f + Hubbard U + spin (+ SOC si possible)",
            "Ac_Lr": "peu/pas de 5f actif — valence 6d/7s",
            "U_Np_Pu": "valence_f ou PAW SSSP — open-core seulement si cas ionique justifié",
        },
        "by_problem_labels": {
            "thermo": "Thermo / optique / structure / phonon",
            "magnetism": "Magnétisme / DFT+U",
            "Ac_Lr": "Ac, Lr",
            "U_Np_Pu": "U, Np, Pu…",
        },
        "footer_file": "Fichier",
        "footer_ref": "Réf.",
        "note_summary_label": "NOTE SCIENTIFIQUE 5f (texte complet)",
        "science_note_path": "oncv_templates_actinide/NOTE_SCIENTIFIQUE_5F.txt",
        "science_note_full": load_science_note_5f("fr"),
        "valence": valence_string(sym, ft),
        "library_upf": library_upf_hints(sym),
    }


def _pre_calc_notice_en(sym: str, ft: str) -> dict[str, Any]:
    sym = _norm(sym)
    fam = actinide_family(sym)
    fam_label = {
        "early_itinerant": "early series (bonding/hybrid 5f)",
        "late_localized": "late series (localized 5f)",
        "edge_ac": "Ac edge (little 5f)",
        "edge_lr": "Lr edge (closed 5f¹⁴)",
    }.get(fam, fam)
    sections = [
        {
            "heading": "1. Why 5f is not 4f",
            "body": (
                "In lanthanides, 4f is tightly localized and weakly bonding → open-core "
                "is often justified. In early actinides (Th–Np, often Pu), 5f is more "
                "extended and participates in bonding: freezing it can spoil structure "
                "and chemistry. Late series (Am–No) become more localized → open-core "
                "again makes sense for thermo/phonons."
            ),
        },
        {
            "heading": "2. Solution A — Active 5f valence (early-series default)",
            "body": (
                "Keep 5f (+ 6d/7s, 6s/6p semicore) in the valence. Required for bonding, "
                "variable oxidation states, magnetism or DFT+U. In practice: spin, Hubbard U "
                "on 5f, ideally SOC. For production: validated SSSP/PseudoDojo UPF/PAW "
                "rather than a homemade ONCV .dat."
            ),
        },
        {
            "heading": "3. Solution B — Open-core / 5f-in-core (late / ionic)",
            "body": (
                "Freeze 5fⁿ in the core for structure/thermo/optics when 5f is localized "
                "and not the observable. Typical valence: 6s² 6p⁶ (+ 6d/7s). Related to "
                "5f-in-core literature (An³⁺/An⁴⁺), but not a license for Th/U f-in-core "
                "without justification."
            ),
        },
        {
            "heading": "4. Why scalar ONCV is fragile",
            "body": (
                "sratom may fail on n=5, ℓ=3 (5f) — same idea as lschfb 4 3 for 4f. "
                "Strong relativity + SOC; a homemade neutral 5fⁿ config is often a poor "
                "reference. Prefer a validated library."
            ),
        },
        {
            "heading": "5. What this generator does for " + sym,
            "body": (
                f"Family: {fam_label}. Proposed treatment: "
                + ("open-core (frozen 5f)." if ft == "open_core" else "active 5f valence.")
                + " No embedded PseudoDojo actinide templates like La–Lu: the UI points "
                f"to local UPF/PAW if present, and shows recommended valence "
                f"({valence_string(sym, ft)})."
            ),
        },
        {
            "heading": "6. Decision rule",
            "body": (
                "Th–Pu (chemistry/bonding) → valence_f or PAW. "
                "Am–No (thermo/structure) → open_core allowed. "
                "Magnetism / U / 5f moment → always valence_f. "
                "Ac / Lr → 6d/7s valence."
            ),
        },
    ]
    return {
        "title": f"Before running ONCVPSP — {sym} (5f): physical rationale",
        "summary": (
            f"{sym}: actinide ({fam_label}). Do not blindly reuse the Dy/4f solution: "
            "5f may be bonding (early) or localized (late)."
        ),
        "collapse_hint": "(collapse / expand)",
        "element_note": _ELEMENT_NOTES_EN.get(sym, ""),
        "element_label": "Element",
        "f_treatment": ft,
        "f_treatment_label": (
            "Open core (frozen 5f)" if ft == "open_core" else "Active 5f valence"
        ),
        "f_treatment_heading": "5f treatment for this run",
        "family": fam,
        "family_label": fam_label,
        "generator_heading": "In this generator",
        "by_problem_heading": "Choice by problem",
        "physics_sections": sections,
        "what_we_do": (
            "Case-by-case guidance + 5f note; no automatic swap to a lanthanide template. "
            "Seek a validated UPF/PAW for production. "
            f"Proposed valence: {valence_string(sym, ft)}."
        ),
        "by_problem": {
            "thermo_optique_structure_phonon": (
                "Early (Th–Pu): valence_f / PAW — 5f may bond. "
                "Late (Am–No): open_core OK for lattice/phonons."
            ),
            "magnetisme_dft_u": "valence_f + Hubbard U + spin (+ SOC if possible)",
            "Ac_Lr": "little/no active 5f — 6d/7s valence",
            "U_Np_Pu": "valence_f or SSSP PAW — open-core only if ionic case justified",
        },
        "by_problem_labels": {
            "thermo": "Thermo / optics / structure / phonon",
            "magnetism": "Magnetism / DFT+U",
            "Ac_Lr": "Ac, Lr",
            "U_Np_Pu": "U, Np, Pu…",
        },
        "footer_file": "File",
        "footer_ref": "Ref.",
        "note_summary_label": "SCIENTIFIC NOTE 5f (full text)",
        "science_note_path": "oncv_templates_actinide/NOTE_SCIENTIFIQUE_5F_EN.txt",
        "science_note_full": load_science_note_5f("en"),
        "valence": valence_string(sym, ft),
        "library_upf": library_upf_hints(sym),
    }


def build_pre_calc_notice(sym: str, ft: str) -> dict[str, Any]:
    fr = _pre_calc_notice_fr(sym, ft)
    en = _pre_calc_notice_en(sym, ft)
    return {
        **fr,
        "i18n": {"fr": fr, "en": en},
        "default_lang": "fr",
        "series": "5f",
        "is_actinide": True,
    }


def get_guide(sym: str, f_treatment: str | None = None, problem: str | None = None) -> dict[str, Any]:
    sym = _norm(sym)
    rec = recommend_f_treatment(sym, problem, for_oncv=True)
    ft = resolve_f_treatment(sym, f_treatment, problem, for_oncv=True)
    notice = build_pre_calc_notice(sym, ft)
    return {
        "element": sym,
        "is_actinide": True,
        "is_lanthanide": False,
        "series": "5f",
        "family": actinide_family(sym),
        "problem": normalize_problem(problem),
        "f_treatment": ft,
        "f_treatment_label": (
            "Open core (5f gelé dans le cœur)"
            if ft == "open_core"
            else "Valence 5f active (liaison / magnétisme / DFT+U)"
        ),
        "recommendation": rec,
        "element_note": _ELEMENT_NOTES.get(sym, ""),
        "oncv_default": default_oncv_f_treatment(sym),
        "valence_recommended": valence_string(sym, ft),
        "valence_f_alternate": valence_string(sym, "valence_f"),
        "valence_open_core_alternate": valence_string(sym, "open_core"),
        "semicore_valence": "6s2 6p6 (semi-cœur recommandé)",
        "rc_5f_bohr_range": [2.0, 2.6],
        "relativistic": (
            "Relativité forte + SOC recommandées ; ONCV scalaire insuffisant pour beaucoup "
            "d’actinides — préférer UPF/PAW validés (SSSP, PseudoDojo, JTH)."
        ),
        "oncv_recommended": False,
        "library_preferred": True,
        "pseudodojo_url": "https://www.pseudo-dojo.org/",
        "sssp_url": "https://www.materialscloud.org/discover/sssp/sssp-efficiency",
        "case_by_case": {
            "early_Th_Pu": "valence_f ou PAW — 5f peut participer à la liaison",
            "late_Am_No": "open_core admissible pour thermo/structure",
            "magnetism_dft_u": "valence_f + spin + Hubbard U (+ SOC)",
            "Ac_Lr": "valence 6d/7s",
        },
        "library_upf": library_upf_hints(sym),
        "pw_x_tips": [
            "HUBBARD U sur 5f si GGA délocalise trop",
            "nspin=2 + starting_magnetization",
            "SOC (noncolin / lspinorb) si spectroscopie / anisotropie",
            "mixing_beta bas (0.1–0.3) pour SCF difficile",
        ],
        "workflow": [
            "Identifier la famille (début liant vs fin localisée)",
            "Choisir le problème → recommend_f_treatment",
            "Production : chercher UPF/PAW SSSP ou PseudoDojo avant de lancer oncvpsp.x",
            "Si génération ONCV : valence recommandée + semi-cœur 6s/6p ; pas de 5fⁿ neutre artisanal",
            "Tests : dérivées log, maille, moments ; comparer à PAW si divergence",
        ],
        "pre_calc_notice": notice,
        "warning": (
            "Pas de templates PseudoDojo actinides embarqués dans ce dépôt "
            "(contrairement à oncv_templates_lanthanide/). "
            "Un .dat ONCV est généré localement (actinide_nc.py) — à valider ; "
            "préférez UPF/PAW bibliothèque pour la production."
        ),
    }


def parse_valence_tokens(valence: str) -> list[tuple[int, int, float]]:
    """Parse « 5f7 6d1 7s2 » → (n, l, occ)."""
    import re

    out: list[tuple[int, int, float]] = []
    for m in re.finditer(r"(\d+)([spdf])(\d+(?:\.\d+)?)", valence or "", re.I):
        n = int(m.group(1))
        l = {"s": 0, "p": 1, "d": 2, "f": 3}[m.group(2).lower()]
        occ = float(m.group(3))
        out.append((n, l, occ))
    return sorted(out, key=lambda t: (t[0], t[1]))


# Cœur [Rn] sans 6s/6p (Z effectif 78) — 6s/6p en valence / semi-cœur
_RN_CORE_NO_6SP: tuple[tuple[int, int, float], ...] = (
    (1, 0, 2.0), (2, 0, 2.0), (2, 1, 6.0),
    (3, 0, 2.0), (3, 1, 6.0), (3, 2, 10.0),
    (4, 0, 2.0), (4, 1, 6.0), (4, 2, 10.0), (4, 3, 14.0),
    (5, 0, 2.0), (5, 1, 6.0), (5, 2, 10.0),
)

# ONCVPSP 4.0.1 : iexc 1=Wigner, 2=Hedin-Lundqvist, 3=LDA-PZ, 4=PBE.
# PBE réelle → 4 (iexc=3 produisait du LDA-PZ).
# PBEsol : pas de code positif en 4.0.1 → code libxc -116133.
_ONCV_IEXC = {
    "lda_pw": 3,
    "lda_pz": 3,
    "gga_pbe": 4,
    "gga_pbesol": -116133,
    "pbe": 4,
    "pbesol": -116133,
}


def _oncv_valence_tokens(sym: str, ft: str) -> list[tuple[int, int, float]]:
    """Valence ONCV : semi-cœur 6s/6p toujours inclus."""
    base = list(parse_valence_tokens(valence_string(sym, ft)))
    have = {(n, l) for n, l, _ in base}
    out: list[tuple[int, int, float]] = []
    if (6, 0) not in have:
        out.append((6, 0, 2.0))
    if (6, 1) not in have:
        out.append((6, 1, 6.0))
    out.extend(base)
    return sorted(out, key=lambda t: (t[0], t[1]))


def _build_oncv_electron_lines(sym: str, f_treatment: str, Z: int) -> tuple[list[str], int, int]:
    """Lignes (n,l,f) ONCV : nc cœur + nv valence. Somme des occupations = Z."""
    sym = _norm(sym)
    ft = resolve_f_treatment(sym, f_treatment, None, for_oncv=True)
    val_tokens = _oncv_valence_tokens(sym, ft)
    valence_set = {(n, l) for n, l, _ in val_tokens}

    merged: dict[tuple[int, int], float] = {(n, l): o for n, l, o in _RN_CORE_NO_6SP}
    if ft == "open_core":
        # 5f gelé dans le cœur (occupation de la config valence_f)
        for n, l, occ in parse_valence_tokens(_VALENCE_F.get(sym, "")):
            if l == 3:
                merged[(n, l)] = occ
    elif sym == "Lr":
        # 5f14 fermé dans le cœur (analogue Lu)
        merged[(5, 3)] = 14.0
    elif sym == "No" and ft == "valence_f":
        # No : 5f14 souvent cœur-like même en « valence_f » demandé
        pass  # 5f14 reste en valence via val_tokens

    core_lines = sorted(
        ((n, l, merged[(n, l)]) for n, l in merged if (n, l) not in valence_set),
        key=lambda t: (t[0], t[1]),
    )
    nc = len(core_lines)
    nv = len(val_tokens)
    all_lines = core_lines + val_tokens
    # Vérification charge
    q = sum(o for _, _, o in all_lines)
    if abs(q - float(Z)) > 0.01:
        raise ValueError(
            f"Config ONCV {sym} : somme occupations={q} ≠ Z={Z} (ft={ft})."
        )
    str_lines = [f"    {n}    {l}    {occ:.1f}" for n, l, occ in all_lines]
    return str_lines, nc, nv


def generate_oncv_dat(
    sym: str,
    f_treatment: str | None = None,
    xc: str = "gga_pbe",
    rc_f_scale: float = 1.0,
    psfile: str = "both",
    problem: str | None = None,
) -> str:
    """Génère une entrée ONCVPSP .dat pour un actinide (NC, référence locale)."""
    import pseudo_auto_inputs as pai

    sym = _norm(sym)
    if not is_actinide(sym):
        raise ValueError(f"{sym} n'est pas un actinide (Z 89–103).")
    ft = resolve_f_treatment(sym, f_treatment, problem, for_oncv=True)
    Z = int(pai.atomic_number(sym))
    iexc = _ONCV_IEXC.get((xc or "gga_pbe").lower(), 3)
    rc_f = round(max(2.05, min(2.65, 2.35 * float(rc_f_scale))), 2)
    # Lourds 5f : canal s plus mou (anti-GHOST(+)) ; p/d un peu plus serrés que s
    rc_s = round(max(2.40, min(3.20, 2.80 * float(rc_f_scale))), 2)
    rc_p = round(max(2.30, min(3.00, 2.60 * float(rc_f_scale))), 2)
    rc_d = round(max(2.20, min(2.90, 2.50 * float(rc_f_scale))), 2)

    elec_lines, nc, nv = _build_oncv_electron_lines(sym, ft, Z)
    val_tokens = _oncv_valence_tokens(sym, ft)
    has_f_val = any(l == 3 for _, l, _ in val_tokens)
    lmax = 3 if has_f_val else 2

    # qcut s/p adoucis (ex-5.50 trop dur sur actinides → GHOST(+) fréquents)
    rc_channels = [
        (0, rc_s, 0.00, 4, 8, 4.00),
        (1, rc_p, 0.00, 4, 8, 4.50),
        (2, rc_d, 0.00, 4, 9, 6.00),
    ]
    if lmax >= 3:
        rc_channels.append((3, rc_f, 0.00, 5, 9, 8.00))
    # ONCV exige rc(l) >= rc(lloc) pour chaque l — ne pas arrondir rc_local à la hausse (.1f → 2.5 > 2.45)
    rc_local = round(min(r[1] for r in rc_channels), 2)

    rc_lines = [
        f"    {l}    {rc:.2f}   {ep:5.2f}    {ncon}    {nbas}   {qcut:.2f}"
        for l, rc, ep, ncon, nbas, qcut in rc_channels
    ]
    proj = ["    0    2    1.00", "    1    2    4.00", "    2    2    4.00"]
    if lmax >= 3:
        proj.append("    3    2    2.00")

    atsym = sym.lower()[:2]
    ps = (psfile or "both").strip().lower()
    if ps not in ("upf", "both", "psp8"):
        ps = "both"

    val_str = " ".join(
        f"{n}{'spdf'[l]}{int(o) if o == int(o) else o}" for n, l, o in val_tokens
    )
    header = (
        "# ONCVPSP — actinide NC (generation_pseudos/actinide_nc.py)\n"
        f"# Cible QE : psfile={ps} — 5f: {ft} — famille {actinide_family(sym)}\n"
        f"# Valence ONCV : {val_str}\n"
        "# AVERTISSEMENT : gabarit local (pas PseudoDojo actinide). "
        "Valider ghost/transfert ; production → UPF/PAW SSSP.\n"
        f"# Anti-ghost lourd : rc_s={rc_s:.2f} qcut_s=4.00 (ne pas augmenter qcut_s).\n"
        "#\n"
        "# ATOM AND REFERENCE CONFIGURATION\n"
        "# atsym, z, nc, nv, iexc   psfile\n"
        f"  {atsym}  {float(Z):.1f}   {nc}   {nv}   {iexc}   {ps}\n"
        "#\n"
        "# n, l, f  (nc+nv lines)\n"
    )
    body = "\n".join(elec_lines)
    lloc = 4
    opt = (
        "#\n# PSEUDOPOTENTIAL AND OPTIMIZATION\n# lmax\n"
        f"    {lmax}\n#\n# l, rc, ep, ncon, nbas, qcut  (lmax+1 lines)\n"
        + "\n".join(rc_lines)
        + "\n#\n# LOCAL POTENTIAL\n# lloc, lpopt, rc(5), dvloc0\n"
        f"    {lloc}    5    {rc_local:.2f}    0.0\n#\n"
        "# VANDERBILT-KLEINMAN-BYLANDER PROJECTORs\n# l, nproj, debl\n"
        + "\n".join(proj)
        + "\n#\n# MODEL CORE CHARGE\n# icmod, fcfact\n    0    0.0\n#\n"
        "# LOG DERIVATIVE ANALYSIS\n# epsh1, epsh2, depsh\n   -2.0  3.0  0.02\n#\n"
        "# OUTPUT GRID\n# rlmax, drl\n    6.0  0.01\n#\n# TEST CONFIGURATIONS\n# ncnf\n    0\n"
    )
    return header + body + "\n" + opt


def write_oncv_template_cache(sym: str, dat: str | None = None) -> Path:
    """Écrit oncv_templates_actinide/<Sym>.dat."""
    sym = _norm(sym)
    path = _NOTE_DIR / f"{sym}.dat"
    _NOTE_DIR.mkdir(parents=True, exist_ok=True)
    text = dat if dat is not None else generate_oncv_dat(sym)
    path.write_text(text, encoding="utf-8")
    return path


def _norm(sym: str) -> str:
    s = (sym or "").strip()
    if not s:
        return ""
    if len(s) == 1:
        return s.upper()
    return s[0].upper() + s[1:].lower()

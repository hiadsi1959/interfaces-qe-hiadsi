#!/usr/bin/env bash
exec "$(cd "$(dirname "$0")" && pwd)/scripts/generer_pseudos_conformes.sh" "$@"

# -*- coding: utf-8 -*-
"""
Gabarits ONCVPSP (.dat) pour les éléments du bloc principal (bloc s/p léger et lourd).

ONCVPSP tests/data ne couvre pas Al, H, C, … ; ce module sert les gabarits officiels
PseudoDojo PBE v0.4 (github.com/PseudoDojo/ONCVPSP-PBE-PDv0.4) copiés dans
oncv_templates_main_group/<Sym>.dat (entrées « standard » : iexc=4 = PBE).

Règles :
  - gabarits tunés PBE : servir tels quels uniquement pour gga_pbe/pbe ;
    autre XC → None (l'API retombe sur tests/data ou erreur explicite).
  - jamais de repli silencieux sur Si pour un autre élément.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

try:
    from pseudo_auto_inputs import normalize_symbol, atomic_number
except ImportError:  # pragma: no cover

    def normalize_symbol(sym: str) -> str:
        s = (sym or "").strip()
        return s.upper() if len(s) == 1 else s[0].upper() + s[1:].lower()

    def atomic_number(sym: str) -> int:  # pragma: no cover
        return 0


# Éléments couverts par oncv_templates_main_group/ (gabarits PseudoDojo PBE PDv0.4)
MAIN_GROUP_SYMBOLS: frozenset[str] = frozenset({
    "H", "He", "Be", "B", "C", "F", "Ne", "Na", "Mg", "Al", "P", "S", "Ar",
    "Ga", "As", "Br", "Kr", "Rb", "In", "Sn", "Sb", "I", "Xe", "Cs", "Hf",
    "Re", "Os", "Ir", "Pt", "Tl", "Pb",
})

_TPL_DIR = Path(__file__).resolve().parent / "oncv_templates_main_group"

# PseudoDojo PDv0.4 = PBE ; ces gabarits ne sont pas retunés pour une autre XC.
_PBE_KEYS = {"", "gga_pbe", "pbe"}


def is_main_group(sym: str) -> bool:
    return normalize_symbol(sym) in MAIN_GROUP_SYMBOLS


def needs_generated_dat(sym: str) -> bool:
    """True si un gabarit PseudoDojo est disponible pour cet élément."""
    s = normalize_symbol(sym)
    return s in MAIN_GROUP_SYMBOLS and (_TPL_DIR / f"{s}.dat").is_file()


def generate_oncv_dat(
    sym: str,
    *,
    xc: str | None = "gga_pbe",
    psfile: str = "both",
    **_: Any,
) -> str | None:
    """Retourne le gabarit PseudoDojo .dat (PBE) pour sym, sinon None.

    psfile est laissé tel quel dans le fichier (psp8) ; l'API le normalise
    pour la cible demandée (both/upf pour Quantum ESPRESSO).
    """
    s = normalize_symbol(sym)
    if s not in MAIN_GROUP_SYMBOLS:
        return None
    if (xc or "gga_pbe").strip().lower() not in _PBE_KEYS:
        return None
    dat = _TPL_DIR / f"{s}.dat"
    if not dat.is_file():
        return None
    return dat.read_text(encoding="utf-8", errors="replace")


def get_guide(sym: str) -> dict[str, Any]:
    sym = normalize_symbol(sym)
    return {
        "element": sym,
        "is_main_group": True,
        "has_official_dat": (_TPL_DIR / f"{sym}.dat").is_file(),
        "valence_note": "Gabarit officiel PseudoDojo ONCVPSP-PBE-PDv0.4 (entrée standard)",
        "oncv_recommended": "oui",
        "message": (
            f"{sym} : gabarit PseudoDojo PBE (PDv0.4) validé localement. "
            "iexc=4 (PBE) ; psfile normalisé par l'API pour Quantum ESPRESSO."
        ),
        "pseudodojo_url": "https://www.pseudo-dojo.org/",
    }
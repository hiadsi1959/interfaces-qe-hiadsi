/**
 * Onglet ONCVPSP (présentation scientifique) + modale générateur complet.
 */
(function () {
    'use strict';

    function esc(s) {
        if (s == null) return '';
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function apiBase() {
        return typeof getApiPseudosBase === 'function' ? getApiPseudosBase() : 'http://127.0.0.1:5008';
    }

    function safeSym(s) {
        return String(s || '').replace(/[^A-Za-z]/g, '').slice(0, 8);
    }

    function _oncvTemplateLooksValid(txt, symbole) {
        if (!txt || txt.indexOf('# ATOM AND REFERENCE') < 0) return false;
        // psfile : psp8 | upf | both (cible QE = both/upf)
        if (!/\b(psp8|upf|both)\b/i.test(txt)) return false;
        if (!symbole) return true;
        var sym = String(symbole).trim();
        // Ligne atsym après l’en-tête ATOM (ex. "  co  27.0" ou "    Si  14")
        var m = txt.match(/#\s*ATOM AND REFERENCE[\s\S]*?\n\s*([A-Za-z]{1,2})\s+([\d.]+)/i);
        if (!m) return true; // en-tête API peut différer — laisser l’API valider au run
        return m[1].toLowerCase() === sym.toLowerCase();
    }

    function gpResolveOncvSym() {
        var modal = document.getElementById('modal_generateur_oncvpsp');
        if (modal) {
            var badge = modal.querySelector('.ld1-modal-title-badge');
            if (badge && badge.textContent) return safeSym(badge.textContent.trim());
            var symAttr = modal.getAttribute('data-element');
            if (symAttr) return safeSym(symAttr);
        }
        var panel = document.getElementById('gen_panel');
        return safeSym(panel && panel.getAttribute('data-element'));
    }

    function gpOncvElementZ(sym) {
        var el = window.ELEMENTS && window.ELEMENTS[sym];
        var Z = el && el.numero ? parseInt(el.numero, 10) : 0;
        return isNaN(Z) ? 14 : Z;
    }

    async function fetchOncvTemplateText(base, symbole, Z, opts) {
        opts = opts || {};
        var sym = safeSym(symbole) || 'Si';
        var zNum = parseInt(Z, 10) || 0;
        var ftQ = '';
        var ft = opts.f_treatment;
        if (!ft && zNum >= 57 && zNum <= 71) {
            ft = (typeof window.gpLanthanideFTreatment === 'string' && window.gpLanthanideFTreatment)
                ? window.gpLanthanideFTreatment
                : 'auto';
        }
        if (!ft && zNum >= 89 && zNum <= 103) {
            ft = 'auto';
        }
        if (ft) ftQ = '&f_treatment=' + encodeURIComponent(ft);
        var xcQ = opts.xc ? '&xc=' + encodeURIComponent(opts.xc) : '';
        var urls = [
            base + '/api/pseudos/oncv_input_template?element=' + encodeURIComponent(sym) + '&z=' + zNum + ftQ + xcQ,
        ];
        // Statics dédiés à l’élément — JAMAIS de repli Si pour un autre symbole
        var staticNames = [
            'oncv_templates_3d/' + sym + '.dat',
            'oncv_templates_4d/' + sym + '.dat',
            'oncv_templates_exotic/' + sym + '.dat',
            'oncv_default_' + sym + '.dat',
            'data/oncv/oncv_default_' + sym + '.dat',
        ];
        if (sym.toLowerCase() === 'si') {
            staticNames.push('oncv_default_14_Si.dat', 'data/oncv/oncv_default_14_Si.dat');
        }
        var i, r, txt;
        for (i = 0; i < urls.length; i++) {
            try {
                r = await fetch(urls[i], { cache: 'no-store' });
                if (r.ok) {
                    var ct = (r.headers.get('content-type') || '');
                    if (ct.indexOf('json') >= 0) {
                        // 404 encapsulé parfois en JSON
                        continue;
                    }
                    txt = await r.text();
                    if (txt.trim().charAt(0) === '{') continue; // erreur JSON
                    if (_oncvTemplateLooksValid(txt, sym)) return txt;
                }
            } catch (e) { /* réseau */ }
        }
        for (i = 0; i < staticNames.length; i++) {
            try {
                r = await fetch(new URL(staticNames[i], window.location.href).toString(), { cache: 'no-store' });
                if (r.ok) {
                    txt = await r.text();
                    if (_oncvTemplateLooksValid(txt, sym)) return txt;
                }
            } catch (e) { /* file:// ou 404 */ }
        }
        return '';
    }

    async function fetchLanthanide4fNotice(sym) {
        try {
            var r = await fetch(
                apiBase() + '/api/pseudos/lanthanide_4f_note?element=' + encodeURIComponent(sym),
                { cache: 'no-store' }
            );
            if (!r.ok) return null;
            return await r.json();
        } catch (e) {
            return null;
        }
    }

    async function fetchActinide5fNotice(sym) {
        try {
            var r = await fetch(
                apiBase() + '/api/pseudos/actinide_5f_note?element=' + encodeURIComponent(sym),
                { cache: 'no-store' }
            );
            if (!r.ok) return null;
            return await r.json();
        } catch (e) {
            return null;
        }
    }

    async function fetchFnBlockNotice(sym, Z) {
        if (Z >= 57 && Z <= 71) return fetchLanthanide4fNotice(sym);
        if (Z >= 89 && Z <= 103) return fetchActinide5fNotice(sym);
        return null;
    }

    function formatScienceNoteColored(raw) {
        if (!raw) return '';
        var lines = String(raw).split(/\r?\n/);
        var out = [];
        var inList = false;
        function closeList() {
            if (inList) { out.push('</ul>'); inList = false; }
        }
        for (var i = 0; i < lines.length; i++) {
            var line = lines[i];
            var t = line.replace(/\s+$/, '');
            if (!t || /^={5,}/.test(t) || /^-{5,}/.test(t)) {
                closeList();
                continue;
            }
            // Titre principal
            if (/^NOTE SCIENTIFIQUE|^SCIENTIFIC NOTE/i.test(t)) {
                closeList();
                out.push('<h3 style="margin:0 0 10px;color:#5eead4;font-size:1rem;font-weight:700;letter-spacing:0.02em;">'
                    + esc(t) + '</h3>');
                continue;
            }
            // Meta (Visible / Mise à jour)
            if (/^(Visible dans|Mise à jour|Shown in|Updated)/i.test(t)) {
                closeList();
                out.push('<p style="margin:0 0 8px;color:#64748b;font-size:0.75rem;">' + esc(t) + '</p>');
                continue;
            }
            // Titres de section numérotés
            if (/^\d+\.\s+\S/.test(t)) {
                closeList();
                out.push('<h4 style="margin:14px 0 6px;color:#2dd4bf;font-size:0.88rem;font-weight:700;'
                    + 'border-left:3px solid #14b8a6;padding-left:10px;">' + esc(t) + '</h4>');
                continue;
            }
            // Sous-lignes de titre (----)
            if (/^[-–]{3,}\s*$/.test(t) || (/^[A-ZÀÂÉÈÊËÎÏÔÙÛÜÇ].{8,}/.test(t) && t === t.toUpperCase() && t.indexOf(' ') > 0 && t.length < 80 && !/https?:/.test(t))) {
                // skip ALL-CAPS short lines that are leftovers; already handled numbered
                if (!/^\d+\./.test(t) && t === t.toUpperCase() && t.length < 90) {
                    closeList();
                    continue;
                }
            }
            // Puces
            var bullet = t.match(/^\s*[•·\-\*]\s+(.*)$/);
            if (bullet) {
                if (!inList) {
                    out.push('<ul style="margin:4px 0 10px;padding-left:1.25em;color:#cbd5e1;">');
                    inList = true;
                }
                out.push('<li style="margin:3px 0;color:#e2e8f0;">' + esc(bullet[1]) + '</li>');
                continue;
            }
            // Lignes d'erreur / code
            if (/lschfb|sratom|n,l\s*=|4f[⁰¹²³⁴⁵⁶⁷⁸⁹\d]|z_valence|oncvpsp/i.test(t) && t.trim().length < 100 && /^\s{2,}/.test(line)) {
                closeList();
                out.push('<pre style="margin:6px 0;padding:8px 10px;border-radius:6px;background:#0c1222;'
                    + 'border:1px solid rgba(251,191,36,0.35);color:#fbbf24;font-size:0.75rem;'
                    + 'overflow:auto;font-family:var(--font-mono),ui-monospace,monospace;">'
                    + esc(t.trim()) + '</pre>');
                continue;
            }
            // Chemins / fichiers
            if (/oncv_templates_lanthanide|oncv_templates_actinide|pseudos\/|NOTE_SCIENTIFIQUE|\.in\b|\.UPF\b|\.txt\b/.test(t) && t.trim().length < 120) {
                closeList();
                out.push('<p style="margin:4px 0;font-family:var(--font-mono),ui-monospace,monospace;'
                    + 'font-size:0.76rem;color:#7dd3fc;">' + esc(t.trim()) + '</p>');
                continue;
            }
            // URLs
            if (/https?:\/\//.test(t)) {
                closeList();
                var urlHtml = esc(t).replace(
                    /(https?:\/\/[^\s]+)/g,
                    '<a href="$1" target="_blank" rel="noopener" style="color:#38bdf8;text-decoration:underline;">$1</a>'
                );
                out.push('<p style="margin:4px 0 8px;color:#94a3b8;font-size:0.78rem;">' + urlHtml + '</p>');
                continue;
            }
            // Flèches de choix / tableaux texte
            if (/→/.test(t) || /\s+→\s+/.test(t)) {
                closeList();
                out.push('<p style="margin:4px 0;padding:6px 8px;border-radius:6px;'
                    + 'background:rgba(56,189,248,0.08);color:#bae6fd;font-size:0.8rem;">'
                    + esc(t.trim()) + '</p>');
                continue;
            }
            // Paragraphe normal
            closeList();
            out.push('<p style="margin:0 0 8px;color:#cbd5e1;font-size:0.8rem;line-height:1.55;">'
                + esc(t) + '</p>');
        }
        closeList();
        return out.join('');
    }

    function resolveNoticeLang(noticePayload, lang) {
        var root = (noticePayload && noticePayload.pre_calc_notice) || noticePayload || {};
        var i18n = root.i18n || {};
        var L = (lang || root.default_lang || 'fr').toLowerCase();
        if (L !== 'en') L = 'fr';
        var n = i18n[L] || root;
        // Fallback science note from payload roots
        if (!n.science_note_full) {
            if (L === 'en' && noticePayload && noticePayload.science_note_full_en) {
                n = Object.assign({}, n, { science_note_full: noticePayload.science_note_full_en });
            } else if (noticePayload && (noticePayload.science_note_full_fr || noticePayload.science_note_full)) {
                n = Object.assign({}, n, {
                    science_note_full: noticePayload.science_note_full_fr || noticePayload.science_note_full,
                });
            }
        }
        return { lang: L, n: n, root: root };
    }

    function lanthanide4fBodyHtml(sym, n) {
        var summary = n.summary || (
            sym + ' : orbitales 4f localisées — risque lschfb ; gabarit PseudoDojo recommandé.'
        );
        var elNote = n.element_note || '';
        var ft = n.f_treatment_label || n.f_treatment || '';
        var full = n.science_note_full || '';
        var by = n.by_problem || {};
        var labels = n.by_problem_labels || {};
        var sections = n.physics_sections || n.sections || [];
        var what = n.what_we_do || n.generator_what || '';
        var libs = n.library_upf || [];
        var secColors = ['#5eead4', '#67e8f9', '#fcd34d', '#fdba74', '#c4b5fd', '#86efac'];
        var html = '<p style="margin:0 0 12px;color:#e2e8f0;font-size:0.88rem;">' + esc(summary) + '</p>';
        if (elNote) {
            html += '<p style="margin:0 0 10px;padding:8px 10px;border-radius:8px;background:rgba(45,212,191,0.08);'
                + 'border:1px solid rgba(45,212,191,0.2);"><strong style="color:#99f6e4;">'
                + esc(n.element_label || 'Élément') + ' ' + esc(sym) + '.</strong> ' + esc(elNote) + '</p>';
        }
        if (ft) {
            html += '<p style="margin:0 0 12px;"><strong style="color:#99f6e4;">'
                + esc(n.f_treatment_heading || 'Traitement f') + '.</strong> '
                + '<span style="color:#fde68a;">' + esc(ft) + '</span></p>';
        }
        if (sections.length) {
            html += '<div style="margin:0 0 12px;">';
            for (var i = 0; i < sections.length; i++) {
                var sec = sections[i] || {};
                var col = secColors[i % secColors.length];
                html += '<div style="margin:0 0 10px;padding:10px 12px;border-radius:8px;'
                    + 'background:rgba(15,23,42,0.55);border:1px solid rgba(148,163,184,0.12);'
                    + 'border-left:3px solid ' + col + ';">'
                    + '<div style="color:' + col + ';font-weight:700;margin-bottom:5px;font-size:0.84rem;">'
                    + esc(sec.heading || '') + '</div>'
                    + '<p style="margin:0;color:#e2e8f0;">' + esc(sec.body || '') + '</p>'
                    + '</div>';
            }
            html += '</div>';
        }
        if (what) {
            html += '<p style="margin:0 0 12px;padding:8px 10px;border-radius:8px;'
                + 'background:rgba(134,239,172,0.08);border:1px solid rgba(134,239,172,0.25);">'
                + '<strong style="color:#86efac;">' + esc(n.generator_heading || 'Dans ce générateur') + '.</strong> '
                + '<span style="color:#d1fae5;">' + esc(what) + '</span></p>';
        }
        if (libs.length) {
            html += '<p style="margin:0 0 6px;color:#86efac;font-weight:700;font-size:0.84rem;">UPF / PAW locaux</p><ul style="margin:0 0 12px;padding-left:1.2em;">';
            for (var li = 0; li < Math.min(libs.length, 8); li++) {
                html += '<li style="margin:3px 0;color:#cbd5e1;font-size:0.78rem;word-break:break-all;"><code style="color:#7dd3fc;">'
                    + esc(libs[li].name || libs[li].path || '') + '</code>'
                    + (libs[li].variant ? ' <span style="color:#94a3b8;">(' + esc(libs[li].variant) + ')</span>' : '')
                    + '</li>';
            }
            html += '</ul>';
        }
        html += '<p style="margin:0 0 6px;color:#7dd3fc;font-weight:700;font-size:0.84rem;">'
            + esc(n.by_problem_heading || 'Choix selon le problème') + '</p>'
            + '<ul style="margin:0 0 12px;padding-left:1.2em;">'
            + '<li style="margin-bottom:6px;"><strong style="color:#67e8f9;">'
            + esc(labels.thermo || 'Thermo / optique / structure / phonon') + '</strong> '
            + '<span style="color:#94a3b8;">→</span> <span style="color:#a7f3d0;">'
            + esc(by.thermo_optique_structure_phonon || by.thermo || 'voir note') + '</span></li>'
            + '<li style="margin-bottom:6px;"><strong style="color:#fcd34d;">'
            + esc(labels.magnetism || 'Magnétisme / DFT+U') + '</strong> '
            + '<span style="color:#94a3b8;">→</span> <span style="color:#fde68a;">'
            + esc(by.magnetisme_dft_u || by.magnetism || 'valence_f + U') + '</span></li>';
        if (by.La_Lu) {
            html += '<li style="margin-bottom:6px;"><strong style="color:#c4b5fd;">'
                + esc(labels.La_Lu || 'La, Lu') + '</strong> '
                + '<span style="color:#94a3b8;">→</span> <span style="color:#e9d5ff;">' + esc(by.La_Lu) + '</span></li>';
        }
        if (by.Ce_Eu_Gd) {
            html += '<li style="margin-bottom:6px;"><strong style="color:#fdba74;">'
                + esc(labels.Ce_Eu_Gd || 'Ce, Eu, Gd…') + '</strong> '
                + '<span style="color:#94a3b8;">→</span> <span style="color:#ffedd5;">' + esc(by.Ce_Eu_Gd) + '</span></li>';
        }
        if (by.Ac_Lr) {
            html += '<li style="margin-bottom:6px;"><strong style="color:#c4b5fd;">'
                + esc(labels.Ac_Lr || 'Ac, Lr') + '</strong> '
                + '<span style="color:#94a3b8;">→</span> <span style="color:#e9d5ff;">' + esc(by.Ac_Lr) + '</span></li>';
        }
        if (by.U_Np_Pu) {
            html += '<li style="margin-bottom:6px;"><strong style="color:#fdba74;">'
                + esc(labels.U_Np_Pu || 'U, Np, Pu…') + '</strong> '
                + '<span style="color:#94a3b8;">→</span> <span style="color:#ffedd5;">' + esc(by.U_Np_Pu) + '</span></li>';
        }
        html += '</ul>';
        if (full) {
            html += '<details style="margin-top:4px;border-top:1px solid rgba(148,163,184,0.25);padding-top:10px;" open>'
                + '<summary style="cursor:pointer;color:#5eead4;font-weight:700;font-size:0.85rem;">'
                + esc(n.note_summary_label || 'NOTE SCIENTIFIQUE') + '</summary>'
                + '<div class="oncv-science-note-colored" style="margin:10px 0 0;padding:14px;'
                + 'border-radius:10px;background:linear-gradient(165deg,#020617 0%,#0f172a 55%,#042f2e 100%);'
                + 'border:1px solid rgba(45,212,191,0.25);max-height:320px;overflow:auto;">'
                + formatScienceNoteColored(full)
                + '</div></details>';
        }
        html += '<p style="margin:10px 0 0;font-size:0.75rem;color:#64748b;">'
            + esc(n.footer_file || 'Fichier') + ' : <code style="color:#7dd3fc;">'
            + esc(n.science_note_path || 'oncv_templates_lanthanide/NOTE_SCIENTIFIQUE_4F.txt')
            + '</code> · ' + esc(n.footer_ref || 'Réf.') + ' '
            + '<span style="color:#a5b4fc;">Hamann PRB 88, 085117 (2013)</span> · '
            + '<span style="color:#38bdf8;">PseudoDojo / SSSP</span></p>';
        return html;
    }

    function lanthanide4fDetailsHtml(sym, noticePayload, lang) {
        var resolved = resolveNoticeLang(noticePayload, lang || window.gpOncv4fLang || (typeof window.getGpLang === 'function' ? window.getGpLang() : 'fr'));
        var n = resolved.n;
        var title = n.title || ('Avant de lancer ONCVPSP — ' + sym + ' (4f)');
        var hint = n.collapse_hint || '(replier / déplier)';
        var html = ''
            + '<details id="oncv_4f_note_details" class="oncv-4f-note" open '
            + 'data-sym="' + esc(sym) + '" '
            + 'style="margin:0 0 14px;">'
            + '<summary style="cursor:pointer;padding:12px 14px;font-weight:650;'
            + 'font-size:0.9rem;list-style:none;user-select:none;display:flex;flex-wrap:wrap;'
            + 'align-items:center;gap:10px;">'
            + '<span id="oncv_4f_note_title_span">▾ ' + esc(title)
            + ' <span style="font-weight:500;font-size:0.78em;">' + esc(hint) + '</span></span>'
            + '</summary>'
            + '<div id="oncv_4f_note_body" style="padding:0 14px 14px;font-size:0.82rem;'
            + 'line-height:1.6;max-height:min(58vh,580px);overflow:auto;">'
            + lanthanide4fBodyHtml(sym, n)
            + '</div></details>';
        return html;
    }

    window.setOncv4fLang = function (lang) {
        var L = (lang === 'en') ? 'en' : 'fr';
        window.gpOncv4fLang = L;
        var payload = window._oncv4fNoticePayload;
        var details = document.getElementById('oncv_4f_note_details');
        var body = document.getElementById('oncv_4f_note_body');
        if (!payload || !details || !body) return;
        var sym = details.getAttribute('data-sym') || 'X';
        var resolved = resolveNoticeLang(payload, L);
        var n = resolved.n;
        body.innerHTML = lanthanide4fBodyHtml(sym, n);
        var titleSpan = document.getElementById('oncv_4f_note_title_span');
        if (titleSpan) {
            titleSpan.innerHTML = '▾ ' + esc(n.title || '')
                + ' <span style="font-weight:500;font-size:0.78em;">'
                + esc(n.collapse_hint || '') + '</span>';
        }
    };

    if (!window._gpOncv4fLangListener) {
        window._gpOncv4fLangListener = true;
        window.addEventListener('gp:langchange', function (ev) {
            var L = (ev && ev.detail && ev.detail.lang) || (typeof window.getGpLang === 'function' ? window.getGpLang() : 'fr');
            if (typeof window.setOncv4fLang === 'function') window.setOncv4fLang(L);
        });
    }

    function mountLanthanide4fNotice(slotOrNull, sym, payload) {
        window._oncv4fNoticePayload = payload;
        var lang = (typeof window.getGpLang === 'function' ? window.getGpLang() : null)
            || window.gpOncv4fLang || window.gpLang || 'fr';
        var html = lanthanide4fDetailsHtml(sym, payload, lang);
        if (slotOrNull) {
            slotOrNull.innerHTML = html;
        }
        return html;
    }

    async function fetchOncvStatus() {
        var st = { available: false, path: null, tests_data: null, ld_local_lib: null };
        try {
            var rs = await fetch(apiBase() + '/api/pseudos/oncv_status');
            if (rs.ok) st = await rs.json();
            else if (rs.status === 404) st._routeMissing = true;
        } catch (e) { /* API hors ligne */ }
        return st;
    }

    function oncvStatusHtml(st) {
        if (st._routeMissing) {
            return '<div class="ld1-modal-hint" style="border-color:#fdba74;background:#fff7ed;color:#9a3412;margin-bottom:12px;">'
                + '<strong>API trop ancienne (404 sur <code>/api/pseudos/oncv_status</code>).</strong> '
                + 'Redémarrez l’API : <code>bash scripts/assure_api_qe.sh</code>, puis rechargez la page.'
                + '</div>';
        }
        if (st.available) {
            return '<div class="ld1-modal-hint" style="border-color:#6ee7b7;background:#ecfdf5;color:#065f46;margin-bottom:12px;">'
                + '<strong>oncvpsp.x détecté</strong> : <code style="word-break:break-all;">' + esc(st.path || '') + '</code>'
                + (st.tests_data ? '<br><span style="color:#047857;">tests/data : ' + esc(st.tests_data) + '</span>' : '')
                + '</div>';
        }
        return '<div class="ld1-modal-hint" style="border-color:#fecaca;background:#fef2f2;color:#991b1b;margin-bottom:12px;">'
            + '<strong>Binaire introuvable côté serveur.</strong> Compilez ONCVPSP dans <code>~/oncvpsp/build</code> '
            + 'ou définissez <code>ONCVPSP_BIN</code> / <code>api_config.json</code>, puis redémarrez l’API.'
            + '</div>';
    }

    window.gpReloadOncvTemplateFromPhysics = async function (symbole) {
        var sym = safeSym(symbole) || gpResolveOncvSym();
        if (!sym) return;
        var Z = gpOncvElementZ(sym);
        var ta = document.getElementById('oncv_input_area_modal') || document.getElementById('oncv_input_area');
        if (!ta) return;
        var params = typeof window.gpReadPhysicsParams === 'function'
            ? window.gpReadPhysicsParams('oncvpsp')
            : { xc: 'gga_pbe', f_treatment: 'auto' };
        ta.value = 'Chargement du modèle .dat…';
        try {
            var tpl = await fetchOncvTemplateText(apiBase(), sym, Z, params);
            if (tpl) {
                ta.value = tpl;
            } else {
                ta.value = '# Aucun modèle disponible pour ' + sym + '. Vérifiez l’API ou importez un .dat PseudoDojo.\n';
            }
        } catch (e) {
            ta.value = '# Erreur chargement modèle ONCV.\n';
        }
    };

    window.rechargerModeleOncv = async function () {
        var symbole = gpResolveOncvSym();
        if (!symbole) return;
        if (typeof window.gpReloadOncvTemplateFromPhysics === 'function') {
            await window.gpReloadOncvTemplateFromPhysics(symbole);
            if (typeof _showToast === 'function') _showToast('Modèle .dat rechargé', '#0d9488', 2200);
        }
    };

    window.lancerOncvpspDepuisOnglet = async function () {
        var symbole = gpResolveOncvSym() || 'X';
        var ta = document.getElementById('oncv_input_area_modal') || document.getElementById('oncv_input_area');
        var out = document.getElementById('oncv_run_output_modal') || document.getElementById('oncv_run_output');
        var btn = document.getElementById('oncv_btn_run_modal') || document.getElementById('oncv_btn_run');
        if (!ta || !out) return;
        var input = (ta.value || '').trim();
        if (!input) {
            out.textContent = 'Saisissez un fichier d’entrée .dat (ou cliquez sur Recharger modèle).';
            return;
        }
        // Placeholder / commentaires seuls → ne pas lancer oncvpsp.x (crash « End of file »)
        var hasAtomBlock = /#\s*ATOM AND REFERENCE/i.test(input)
            && /^\s*[A-Za-z]{1,2}\s+\d+(\.\d+)?\s+\d+\s+\d+\s+-?\d+\b/m.test(input);
        if (!hasAtomBlock) {
            out.innerHTML = '<div class="gen-run-result gen-run-result__box gen-run-result__box--err">'
                + '<strong>Entrée invalide :</strong> le .dat ne contient aucun bloc de configuration atomique '
                + '(placeholder « Aucun modèle disponible » ou commentaires seuls).<br>'
                + 'Cliquez sur <strong>Recharger modèle</strong> pour charger un gabarit, ou importez un '
                + '.dat PseudoDojo pour cet élément.'
                + '</div>';
            if (typeof _showToast === 'function') _showToast('Gabarit ONCV manquant — rechargez le modèle', '#dc2626', 5000);
            return;
        }
        if (typeof window.gpRevealLaunchScienceReminder === 'function') {
            window.gpRevealLaunchScienceReminder(symbole, 'oncvpsp');
        }
        if (typeof window.gpSetGeneratorRunning === 'function') {
            window.gpSetGeneratorRunning({ engine: 'oncvpsp', element: symbole, button: btn, outputEl: out });
        } else if (btn) {
            btn.disabled = true;
            btn.textContent = 'Exécution…';
        }
        if (typeof window.gpRenderExecLoadingHtml === 'function') {
            out.innerHTML = window.gpRenderExecLoadingHtml('Lancement oncvpsp.x…', 'Génération UPF côté serveur');
        } else if (typeof window.renderGeneratorRunResult === 'function') {
            out.innerHTML = '<div class="gen-run-result gen-run-result--loading">Lancement oncvpsp.x côté serveur…</div>';
        } else {
            out.textContent = 'Lancement oncvpsp.x côté serveur…';
        }
        try {
            var r = await fetch(apiBase() + '/api/pseudos/run_oncvpsp', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ input: input, element: symbole }),
            });
            if (r.status === 404) {
                out.innerHTML = '<div class="gen-run-result gen-run-result__box gen-run-result__box--err">Route /api/pseudos/run_oncvpsp absente (404) — redémarrez l’API après mise à jour.</div>';
                return;
            }
            var d = await r.json();
            if (typeof window.renderGeneratorRunResult === 'function') {
                out.innerHTML = window.renderGeneratorRunResult(d, { label: 'ONCVPSP' });
            } else {
                var lines = [];
                lines.push('returncode=' + (d.returncode != null ? d.returncode : '?'));
                if (d.work_dir) lines.push('Répertoire : ' + d.work_dir);
                if (d.upf_path) lines.push('UPF : ' + d.upf_path);
                if (d.output) lines.push('--- stdout ---\n' + d.output);
                if (d.stderr) lines.push('--- stderr ---\n' + d.stderr);
                out.textContent = lines.join('\n');
            }
            if (typeof window.gpRunResultToast === 'function') {
                window.gpRunResultToast(d, 'ONCVPSP');
            } else if (d.success && typeof _showToast === 'function') {
                _showToast(d.upf_path ? 'Terminé — .UPF généré' : 'ONCVPSP terminé — voir sortie', '#16a34a', 4000);
            } else if (typeof _showToast === 'function') {
                _showToast('Erreur de calcul — voir détails', '#dc2626', 5000);
            }
        } catch (e) {
            out.innerHTML = '<div class="gen-run-result gen-run-result__box gen-run-result__box--err">Erreur réseau : ' + esc(e && e.message ? e.message : e) + '</div>';
        } finally {
            if (typeof window.gpClearGeneratorRunning === 'function') {
                window.gpClearGeneratorRunning('oncvpsp');
            } else if (btn) {
                btn.disabled = false;
                btn.textContent = '③ Lancer oncvpsp.x';
            }
        }
    };

    window.fermerGenerateurONCVPSP = function () {
        if (typeof window.gpClearGeneratorRunning === 'function') {
            window.gpClearGeneratorRunning('oncvpsp');
        }
        var b = document.getElementById('modal_generateur_oncvpsp');
        if (b) b.remove();
    };

    window.ouvrirGenerateurONCVPSPComplet = async function (symbo) {
        if (typeof ensureLd1ModalScienceStyles === 'function') ensureLd1ModalScienceStyles();
        var sym = safeSym(symbo);
        if (!sym) {
            alert('Sélectionnez d’abord un élément dans le tableau de Mendeleïev.');
            return;
        }
        window.fermerGenerateurONCVPSP();

        var elData = window.ELEMENTS && window.ELEMENTS[sym];
        var nom = elData ? String(elData.nom || '').replace(/</g, '&lt;').replace(/&/g, '&amp;') : '';
        var Z = (elData && elData.numero) ? parseInt(elData.numero, 10) : 14;
        if (isNaN(Z)) Z = 14;

        var st = await fetchOncvStatus();

        var backdrop = document.createElement('div');
        backdrop.id = 'modal_generateur_oncvpsp';
        backdrop.className = 'ld1-modal-backdrop';
        backdrop.setAttribute('data-element', sym);
        backdrop.style.zIndex = '10005';
        backdrop.addEventListener('click', function (ev) {
            if (ev.target === backdrop) window.fermerGenerateurONCVPSP();
        });

        var readyHint = st._routeMissing
            ? 'Routes ONCV absentes (404). Redémarrez l’API.'
            : (st.available
                ? 'Modèle prêt — vérifiez le rappel ci-dessous, puis « Lancer oncvpsp.x ».'
                : 'Binaire non signalé — lancement possible (erreur 503 si absent).');

        backdrop.innerHTML = ''
            + '<div class="ld1-modal-panel gp-modal-with-sticky-launch" style="max-width:min(1080px,96vw);" onclick="event.stopPropagation()">'
            + '<div class="gp-modal-scroll-body">'
            + '<h2 class="ld1-modal-title">ONCVPSP'
            + ' <span class="ld1-modal-title-badge">' + sym + '</span>'
            + (nom ? ' <span style="font-weight:500;color:#94a3b8;font-size:0.85em;">— ' + nom + '</span>' : '')
            + '</h2>'
            + '<p class="ld1-modal-sub">Le modèle <code>.dat</code> de <strong>' + esc(sym) + '</strong> est chargé automatiquement '
            + 'selon les paramètres physiques ci-dessous (XC, relativité, 4f/5f). '
            + 'Éditez le texte si besoin, puis lancez <code>oncvpsp.x</code>. '
            + 'PseudoDojo / SG15 : onglet <em>Autres bases</em>.</p>'
            + '<div class="ld1-steps-strip" style="margin-bottom:12px;">'
            + '<span style="color:#86efac;font-weight:600;">① Élément ' + esc(sym) + '</span> '
            + '<span style="color:#64748b;">→</span> '
            + '<span style="color:#86efac;font-weight:600;">② Paramètres + .dat (auto)</span> '
            + '<span style="color:#64748b;">→</span> '
            + '<span style="color:#fdba74;font-weight:600;">③ Lancer oncvpsp.x</span>'
            + '</div>'
            + oncvStatusHtml(st)
            + '<div id="oncv_params_matrix_modal" style="margin:0 0 12px;"></div>'
            + '<div id="oncv_physics_controls_modal" style="margin:0 0 12px;"></div>'
            + '<label style="display:block;font-size:0.85rem;color:#8ab4ff;margin:4px 0 6px;">'
            + 'Entrée <code>.dat</code> — <strong>' + esc(sym) + '</strong> (Z=' + Z + ')</label>'
            + '<textarea id="oncv_input_area_modal" spellcheck="false" style="width:100%;min-height:220px;max-height:38vh;font-family:var(--font-mono),JetBrains Mono,monospace;font-size:0.78rem;padding:12px;border-radius:10px;border:2px solid rgba(30,73,118,0.45);background:#0f172a;color:#e2e8f0;"></textarea>'
            + '<div id="oncv_pre_calc_launch_slot" style="margin:10px 0;"></div>'
            + '<div style="margin-top:4px;">'
            + '<div style="color:#94a3b8;font-size:0.8em;margin-bottom:6px;">Résultat</div>'
            + '<div id="oncv_run_output_modal" class="gen-run-result" style="min-height:48px;">'
            + readyHint
            + '</div></div>'
            + '<p style="font-size:0.72em;color:#94a3b8;margin:10px 0 0 0;">Libxc : <code>~/.local/lib</code> (LD_LIBRARY_PATH enrichi par l’API si présent).</p>'
            + '</div>'
            + '<div class="gp-modal-launch-bar">'
            + '<button type="button" class="btn-action btn-primary-act" id="oncv_btn_run_modal" onclick="lancerOncvpspDepuisOnglet()">③ Lancer oncvpsp.x</button>'
            + '<button type="button" class="btn-action btn-secondary-act" onclick="rechargerModeleOncv()" title="Remettre le .dat officiel de l’élément (si vous avez modifié le texte)">Recharger le modèle</button>'
            + '<button type="button" class="btn-action btn-secondary-act" onclick="navigator.clipboard.writeText(document.getElementById(\'oncv_input_area_modal\').value).then(function(){if(typeof _showToast===\'function\')_showToast(\'Entrée copiée\',\'#6366f1\',2000);})">Copier</button>'
            + '<button type="button" class="btn-action btn-secondary-act gp-exec-btn-safe" onclick="fermerGenerateurONCVPSP()">Fermer</button>'
            + '</div>'
            + '</div>';

        document.body.appendChild(backdrop);

        if (typeof window.gpMountGeneratorParams === 'function') {
            window.gpMountGeneratorParams(document.getElementById('oncv_params_matrix_modal'), sym, 'oncvpsp');
        }
        if (typeof window.gpMountPhysicsControls === 'function') {
            window.gpMountPhysicsControls(document.getElementById('oncv_physics_controls_modal'), sym, 'oncvpsp');
        } else if (typeof window.gpReloadOncvTemplateFromPhysics === 'function') {
            window.gpReloadOncvTemplateFromPhysics(sym);
        }

        if (typeof window.gpMountPreCalcScience === 'function') {
            var slotLaunch = document.getElementById('oncv_pre_calc_launch_slot');
            var ftOncv = (Z >= 57 && Z <= 71) || (Z >= 89 && Z <= 103) ? 'auto' : undefined;
            var cacheKey = sym + '|oncvpsp';
            var cached = window._gpPreCalcCache && window._gpPreCalcCache[cacheKey];
            window.gpMountPreCalcScience(
                slotLaunch, sym, 'oncvpsp', cached || null,
                { f_treatment: ftOncv, mode: 'launch', open: false }
            );
        }
        var tae = document.getElementById('oncv_input_area_modal');
        if (tae && !tae.value.trim()) {
            tae.value = '# Chargement du modèle optimal…\n';
        }
    };

    window.ouvrirGenerateurONCVPSP = function (symbole) {
        var el = window.ELEMENTS && window.ELEMENTS[symbole];
        if (!el) return;
        if (typeof switchGenTab === 'function') switchGenTab('oncvpsp', symbole, el);
        if (typeof window.ouvrirGenerateurONCVPSPComplet === 'function') window.ouvrirGenerateurONCVPSPComplet(symbole);
    };

    window.renderTabONCVPSP = function (container, symbole, element) {
        var zLine = 'Z = ' + (element && element.numero ? element.numero : '?');
        if (element && element.nom) zLine += ' · ' + esc(element.nom);
        var Z = element && element.numero ? parseInt(element.numero, 10) : 0;
        var isLan = Z >= 57 && Z <= 71;
        var isAct = Z >= 89 && Z <= 103;
        container.innerHTML = ''
            + '<div class="gen-ld1-tab">'
            // En-tête minimal + GROS bouton Lancer immédiatement visible
            + '<div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:6px;margin-bottom:8px;">'
            + '<div class="gen-ld1-intro-kicker" style="margin:0;color:#0d9488;">ONCVPSP · Optimized Norm-Conserving</div>'
            + '<div class="gen-ld1-meta" style="margin:0;">' + zLine + '</div>'
            + '</div>'
            + '<button type="button" class="gen-launch-big" onclick="ouvrirGenerateurONCVPSP(\'' + esc(symbole) + '\')">'
            + '<span class="gen-launch-play">▶</span> Lancer la génération'
            + '</button>'
            // Texte explicatif conservé mais replié (dépliable)
            + '<details class="gen-ld1-details">'
            + '<summary>ℹ️ Explications &amp; conseils — ONCVPSP (déplier)</summary>'
            + '<div class="gen-ld1-details-body">'
            + '<div class="gen-ld1-intro" style="border-left-color:#0d9488;margin-bottom:12px;">'
            + '<strong>ONCVPSP</strong> génère des pseudopotentiels norme-conservants optimisés '
            + '(formats <code>psp8</code> ou <code>.UPF</code> selon la sortie). '
            + 'Sortie : <code>pseudos-oncvpsp/</code>. '
            + 'L’exécution se fait sur la machine de l’API, pas dans le navigateur.'
            + '</div>'
            + '<div id="oncv_tab_science_slot"></div>'
            + '</div>'
            + '</details>'
            + '<div id="oncv_tab_params_slot" style="margin:8px 0;"></div>'
            + '<div class="gen-ld1-steps">'
            + '<span>① Élément</span><span>② Modèle auto</span><span>③ Lancer oncvpsp.x</span>'
            + '</div>'
            + '<div class="gen-ld1-actions">'
            + '<a class="btn-action btn-secondary-act" style="text-decoration:none;" href="https://github.com/oncvpsp/oncvpsp" target="_blank" rel="noopener">Documentation</a>'
            + '</div></div>';
        if (typeof window.gpMountGeneratorParams === 'function') {
            window.gpMountGeneratorParams(
                document.getElementById('oncv_tab_params_slot'),
                symbole, 'oncvpsp'
            );
        }
        if (typeof window.gpMountPreCalcScience === 'function') {
            var ftTab = (isLan || isAct) ? 'auto' : undefined;
            window.gpMountPreCalcScience(
                document.getElementById('oncv_tab_science_slot'),
                symbole, 'oncvpsp', null,
                { f_treatment: ftTab, mode: 'physics', open: true }
            );
        }
    };
})();

# -*- coding: utf-8 -*-
"""
Matrice des paramètres physiques par générateur (type pseudo, XC, relativité, …).
Utilisée par l’API et l’interface (onglets ld1 / APE / ATOMPAW / ONCV).
"""
from __future__ import annotations

from typing import Any

from pseudo_auto_inputs import _TRANSITION_3D, atomic_number, normalize_symbol

_GENERATORS = ("ld1", "ape", "atompaw", "oncvpsp")

# ── Comparatif général (indépendant de l’élément) ─────────────────────────────

PARAM_MATRIX_FR: list[dict[str, Any]] = [
    {
        "id": "pseudo_type",
        "label": "1. Type de pseudo",
        "ld1": {
            "choices": "NC · US (USPP) · PAW · RRKJ · TM · MT · KJPAW …",
            "field": "pseudotype (1=NC, 2=US, 3=PAW) + file_pseudopw suffix",
            "ui": "Liste complète dans l’étape 2 du générateur ld1",
            "note": "Seul ld1.x couvre NC, US et PAW dans un même outil.",
        },
        "ape": {
            "choices": "NC uniquement (Troullier-Martins · Hamann)",
            "field": "PPComponents / WaveEquation",
            "ui": "pp_type_ape (troullier | hamann)",
            "note": "Pas de USPP ni PAW — sortie .UPF NC.",
        },
        "atompaw": {
            "choices": "PAW uniquement (Vanderbilt · Blöchl · TM variant)",
            "field": "pp_type → keyword ATOMPAW",
            "ui": "pp_type_atompaw (vanderbilt | bloechl | …)",
            "note": "PAW natif → UPF QE via PWSCFOUT.",
        },
        "oncvpsp": {
            "choices": "NC optimisé (ONCV) uniquement",
            "field": "fixé dans le .dat (pas de US/PAW ONCV ici)",
            "ui": "Modèle .dat par élément",
            "note": "psfile=both → UPF ; psp8 → ABINIT.",
        },
    },
    {
        "id": "xc",
        "label": "2. Fonctionnelle XC",
        "ld1": {
            "choices": "LDA (PZ, VWN, PW) · GGA (PBE, PBEsol, revPBE, BLYP, …) · meta-GGA · vdW",
            "field": "dft='PBE' dans &input",
            "ui": "pseudo_functional (liste étendue)",
            "note": "Aligner avec pw.x (même XC que le calcul DFT).",
        },
        "ape": {
            "choices": "LDA-PW · LDA-PZ · GGA-PBE · GGA-PBEsol",
            "field": "XCFunctional / XCFunctionalType dans inp.ape",
            "ui": "xc=gga_pbe (défaut API) via auto_inputs",
            "note": "Jeu limité vs ld1 — défaut PBE recommandé.",
        },
        "atompaw": {
            "choices": "LDA-PW · GGA-PBE · GGA-PBEsol (selon XC_DEFS)",
            "field": "xc= keyword stdin ATOMPAW",
            "ui": "xc=gga_pbe (défaut API)",
            "note": "Vérifier le mot-clé exact dans le gabarit (PBE vs LDA-PW).",
        },
        "oncvpsp": {
            "choices": "LDA · PBE (iexc dans .dat — index libxc ONCV)",
            "field": "iexc + dft dans le .dat",
            "ui": "xc=gga_pbe dans auto_inputs / lanthanide_nc",
            "note": "PseudoDojo = PBE ; iexc=3 pour PBE (fichiers officiels).",
        },
    },
    {
        "id": "relativity",
        "label": "3. Relativité",
        "ld1": {
            "choices": "rel=0 (non-rel) · rel=1 (scalaire) · rel=2 (Dirac / spin-orbite)",
            "field": "rel= dans &input",
            "ui": "pseudo_rel (no | scalar | full)",
            "note": "4f valence_f → rel=2 ; open_core → rel=1 ; Z>36 → scalaire min.",
        },
        "ape": {
            "choices": "schrodinger · scalar_rel · (fully relativistic selon version APE)",
            "field": "WaveEquation = scalar_rel | schrodinger",
            "ui": "relativistic=1 (défaut auto 3d/4f/5f)",
            "note": "4f/5f : scalaire activé auto ; SOC → bibliothèque ou autre outil.",
        },
        "atompaw": {
            "choices": "nonrel · scalarrelativistic (loggridv4)",
            "field": "scalarrelativistic dans stdin",
            "ui": "relativistic=1 (défaut auto lourds / 3d / f)",
            "note": "Pas de rel=2 ld1-style ; SOC hors scope ATOMPAW standard.",
        },
        "oncvpsp": {
            "choices": "Scalaire dans le .dat (pas de menu rel séparé)",
            "field": "section relativistic du .dat",
            "ui": "Fixé dans le gabarit ONCV",
            "note": "Actinides : SOC recommandée en pw.x — UPF catalogue SOC si besoin.",
        },
    },
    {
        "id": "semicore_nlcc",
        "label": "4. Semi-cœur · NLCC",
        "ld1": {
            "choices": "nlcc=.true. · rcore · électrons explicites en valence",
            "field": "nlcc, rcore, config",
            "ui": "Gabarit auto (3p pour 3d, 5s/5p pour 4f…)",
            "note": "3d US : 3p en valence ; 3d PAW : NLCC pour 3p.",
        },
        "ape": {
            "choices": "FullAtom / semi-core states · NLCC",
            "field": "FullAtom listing · NLCC",
            "ui": "semicore=1 (auto 3d/f)",
            "note": "Inclure les couches semi-cœur recommandées par elements_physics_db.",
        },
        "atompaw": {
            "choices": "Valence + cœur PAW · compensation",
            "field": "config valence / core dans stdin",
            "ui": "semicore + f_treatment auto",
            "note": "open_core 4f/5f : f gelé dans le cœur PAW.",
        },
        "oncvpsp": {
            "choices": "Core / valence dans tableau (n,l,f) du .dat",
            "field": "lignes électroniques .dat",
            "ui": "Gabarit lanthanide_nc / actinide_nc",
            "note": "open_core : 4f/5f dans le cœur du .dat.",
        },
    },
    {
        "id": "rc_ecut",
        "label": "5. r_c · ecutwfc",
        "ld1": {
            "choices": "r_cut par orbital dans &inputp",
            "field": "derives de Bessel / TM",
            "ui": "pseudo_rcut + lignes ld1.in",
            "note": "r_c petit → ecutwfc élevé en pw.x.",
        },
        "ape": {
            "choices": "r_c par canal l",
            "field": "PPComponents rc",
            "ui": "rc_scale (facteur global)",
            "note": "3d/f : rc_scale≥1.5 si GSL / ghost.",
        },
        "atompaw": {
            "choices": "rc(Vloc) · rc par l de valence",
            "field": "stdin ATOMPAW",
            "ui": "rc_scale",
            "note": "PAW : rc typ. 1.8–2.4 bohr (4f).",
        },
        "oncvpsp": {
            "choices": "rc dans .dat (optimisation ONCV)",
            "field": "section optimization",
            "ui": "Gabarit ; boucle manuelle si ghost",
            "note": "4f : 1.8–2.3 bohr (lanthanide_nc).",
        },
    },
]


def _is_lanthanide(sym: str) -> bool:
    try:
        import lanthanide_nc as lnc
        return lnc.is_lanthanide(sym)
    except ImportError:
        z = atomic_number(sym)
        return 57 <= z <= 71


def _is_actinide(sym: str) -> bool:
    try:
        import actinide_nc as anc
        return anc.is_actinide(sym)
    except ImportError:
        z = atomic_number(sym)
        return 89 <= z <= 103


def element_param_hints(sym: str, generator: str = "ld1") -> dict[str, Any]:
    """Recommandations concrètes pour un élément et un générateur."""
    sym_n = normalize_symbol(sym)
    z = atomic_number(sym_n)
    gen = (generator or "ld1").lower()
    if gen.startswith("oncv"):
        gen = "oncvpsp"
    hints: dict[str, Any] = {
        "element": sym_n,
        "Z": z,
        "generator": gen,
        "pseudo_type": {},
        "xc": {},
        "relativity": {},
        "extra": [],
    }

    if sym_n in _TRANSITION_3D:
        hints["pseudo_type"] = {
            "recommended": "US ou PAW (ld1) · PAW (ATOMPAW) · NC ONCV",
            "avoid": "NC ld1/APE pur (PS-KS / GSL)",
            "ld1_default": "PAW ou US",
        }
        hints["xc"] = {"recommended": "PBE (cohérent pw.x / matériaux)"}
        hints["relativity"] = {"recommended": "scalaire (rel=1)", "ld1": "rel=1", "ape_atompaw": "relativistic=true"}
        hints["extra"].append("Inclure 3p (US) ou NLCC (PAW) pour le semi-cœur.")
    elif _is_lanthanide(sym_n):
        hints["pseudo_type"] = {
            "recommended": "US open_core (ld1) · PAW (ATOMPAW) · NC ONCV",
            "ld1_default": "US",
        }
        hints["xc"] = {"recommended": "PBE"}
        hints["relativity"] = {
            "recommended": "open_core → rel=1 ; valence_f → rel=2 (ld1)",
            "ld1_open_core": "rel=1",
            "ld1_valence_f": "rel=2",
        }
        hints["extra"].append("f_treatment : open_core (thermo) vs valence_f (magnétisme + U).")
    elif _is_actinide(sym_n):
        try:
            import actinide_nc as anc
            ft = anc.resolve_f_treatment(sym_n, "auto", None, for_oncv=False)
        except ImportError:
            ft = "valence_f" if sym_n in ("Th", "Pa", "U", "Np", "Pu") else "open_core"
        hints["pseudo_type"] = {
            "recommended": "PAW (ATOMPAW) · UPF SSSP/PseudoDojo",
            "ld1_default": "US",
        }
        hints["xc"] = {"recommended": "PBE"}
        hints["relativity"] = {
            "recommended": "scalaire minimum ; SOC en pw.x si actinide lourd",
            "f_treatment": ft,
        }
        hints["extra"].append(f"f_treatment auto → {ft} (Th–Pu : valence_f ; Am–No : open_core possible).")
    elif z and z <= 36:
        hints["pseudo_type"] = {"recommended": "NC (légers) · US si instabilité", "ld1_default": "NC"}
        hints["xc"] = {"recommended": "PBE (standard) ou LDA (tests)"}
        hints["relativity"] = {"recommended": "non-rel (Z≤36) sauf test", "ld1": "rel=0"}
    else:
        hints["pseudo_type"] = {"recommended": "NC ou US selon élément", "ld1_default": "NC ou US"}
        hints["xc"] = {"recommended": "PBE"}
        hints["relativity"] = {"recommended": "scalaire (Z>36)", "ld1": "rel=1"}

    # Spécifique générateur courant
    if gen == "ape":
        hints["generator_note"] = "APE : NC seulement — pas de choix US/PAW."
    elif gen == "atompaw":
        hints["generator_note"] = "ATOMPAW : PAW seulement — xc et scalarrelativistic dans stdin."
    elif gen == "oncvpsp":
        hints["generator_note"] = (
            "ONCV : NC seulement ; binaire scalaire-relativiste (pas de rel=0/2). "
            "XC = iexc du .dat — gabarit PseudoDojo = PBE (ne pas changer iexc sans retuner r_c). "
            "4f/5f : open_core si ONCV fragile ; valence_f si magnétisme + U."
        )
    else:
        hints["generator_note"] = (
            "ld1.x : trois familles (NC / US / PAW) + large choix XC + rel=0/1/2."
        )

    return hints


_XC_LABELS: dict[str, str] = {
    "lda_pw": "LDA-PW92",
    "lda_pz": "LDA-PZ81",
    "gga_pbe": "PBE",
    "gga_pbesol": "PBEsol",
}

_PP_APE_LABELS: dict[str, str] = {
    "troullier": "Troullier-Martins",
    "hamann": "Hamann",
}

_PP_AW_LABELS: dict[str, str] = {
    "vanderbilt": "Vanderbilt PAW",
    "bloechl": "Blöchl PAW",
    "vanderbilt_tm": "Vanderbilt+TM",
}


def _ld1_default_pseudo_type(sym: str, z: int) -> str:
    """Heuristique alignée sur defaultPseudoTypeForElement (JS)."""
    if sym in _TRANSITION_3D or _is_lanthanide(sym) or _is_actinide(sym):
        return "US"
    if z and z >= 37:
        return "US"
    if z and 31 <= z <= 36:
        return "US"
    return "NC"


def _ld1_default_rel(sym: str, z: int, f_treatment: str | None, relativistic: bool) -> int:
    """rel ld1 : 0 non-rel · 1 scalaire · 2 Dirac/SO."""
    if _is_lanthanide(sym) and f_treatment == "valence_f":
        return 2
    if _is_actinide(sym) and f_treatment == "valence_f":
        return 2
    if relativistic or (z and z > 36) or sym in _TRANSITION_3D:
        return 1
    return 0


def element_optimal_controls(sym: str, generator: str = "ld1") -> dict[str, Any]:
    """
    Valeurs machine pour pré-sélectionner l’UI (APE / ATOMPAW / ld1).
    Basé sur elements_physics_db, qe_route, lanthanide_nc / actinide_nc.
    """
    sym_n = normalize_symbol(sym)
    z = atomic_number(sym_n)
    gen = (generator or "ld1").lower()
    if gen.startswith("oncv"):
        gen = "oncvpsp"

    xc = "gga_pbe"
    relativistic = False
    semicore = False
    pp_ape = "troullier"
    pp_aw = "vanderbilt"
    f_treatment: str | None = None
    rationale: list[str] = []

    info: dict[str, Any] = {}
    try:
        from elements_physics_db import get_element_info

        info = get_element_info(sym_n) or {}
        if info.get("scalar_rel"):
            relativistic = True
        if info.get("semicore"):
            semicore = True
        note = (info.get("note") or "").strip()
        if note:
            rationale.append(note[:140])
    except ImportError:
        pass

    # ONCV : défaut = stabilité (open_core si 4f/5f fragile).
    # ATOMPAW / ld1 / APE : défaut = chimie (valence_f si f liant ou magnétisme).
    for_oncv = gen == "oncvpsp"

    if sym_n in _TRANSITION_3D:
        relativistic = True
        semicore = True
        rationale.append("Métal 3d : relativité scalaire + semi-cœur (3p en valence ou NLCC).")
    elif _is_lanthanide(sym_n):
        relativistic = True
        semicore = True
        try:
            import lanthanide_nc as lnc

            f_treatment = lnc.resolve_f_treatment(sym_n, "auto", None, for_oncv=for_oncv)
        except ImportError:
            f_treatment = "open_core"
        if for_oncv:
            rationale.append(
                f"Lanthanide 4f / ONCV : f_treatment={f_treatment} "
                "(open_core = stabilité sratom ; valence_f seulement si magnétisme + U)."
            )
        else:
            rationale.append(
                f"Lanthanide 4f : f_treatment={f_treatment} "
                "(valence_f = magnétisme + U ; open_core = thermo / 4f14)."
            )
    elif _is_actinide(sym_n):
        relativistic = True
        semicore = True
        try:
            import actinide_nc as anc

            f_treatment = anc.resolve_f_treatment(sym_n, "auto", None, for_oncv=for_oncv)
        except ImportError:
            f_treatment = "valence_f" if sym_n in ("Th", "Pa", "U", "Np", "Pu") else "open_core"
        rationale.append(
            f"Actinide 5f : f_treatment={f_treatment} "
            "(Th–Pu : 5f liant → valence_f ; Am–No : 5f localisé → open_core)."
        )
    elif z and z <= 36:
        if not (_TRANSITION_3D and sym_n in _TRANSITION_3D):
            relativistic = bool(info.get("scalar_rel"))
        rationale.append("Élément léger/moyen (Z≤36) : non relativiste par défaut.")
    else:
        relativistic = True
        rationale.append("Z>36 : relativité scalaire recommandée.")

    controls: dict[str, Any] = {
        "xc": xc,
        "relativistic": relativistic,
        "semicore": semicore,
        "pp_type_ape": pp_ape,
        "pp_type_atompaw": pp_aw,
    }
    if f_treatment:
        controls["f_treatment"] = f_treatment

    if gen == "ld1":
        ld1_pt = _ld1_default_pseudo_type(sym_n, z)
        if _is_lanthanide(sym_n) or _is_actinide(sym_n):
            ld1_pt = "US"
        rel_n = _ld1_default_rel(sym_n, z, f_treatment, relativistic)
        controls["ld1_pseudo_type"] = ld1_pt
        controls["ld1_dft"] = "PBE"
        controls["ld1_rel"] = rel_n
        rationale.append(
            f"ld1.x : type {ld1_pt}, dft=PBE, rel={rel_n}."
        )
    elif gen == "ape":
        try:
            from generator_guide import ape_feasibility

            feas = ape_feasibility(sym_n)
            if feas == "blocked":
                rationale.append(
                    "APE NC déconseillé pour cet élément — préférer ATOMPAW ou ONCV / catalogue UPF."
                )
        except ImportError:
            pass
    elif gen == "atompaw":
        rationale.append("ATOMPAW : PAW Vanderbilt + PBE + scalarrelativistic si Z élevé ou f.")
    elif gen == "oncvpsp":
        rationale.append(
            "ONCVPSP : NC optimisé ; XC = iexc du .dat (PseudoDojo = PBE, ne pas retoucher iexc) ; "
            "relativité scalaire imposée par oncvpsp.x ; semi-cœur déjà dans les occupations (n,l,f)."
        )

    labels = {
        "xc": _XC_LABELS.get(xc, xc),
        "relativistic": "scalaire" if relativistic else "non-rel",
        "semicore": "oui" if semicore else "non",
        "pp_type_ape": _PP_APE_LABELS.get(pp_ape, pp_ape),
        "pp_type_atompaw": _PP_AW_LABELS.get(pp_aw, pp_aw),
    }
    if f_treatment:
        labels["f_treatment"] = f_treatment
    if controls.get("ld1_pseudo_type"):
        labels["ld1_pseudo_type"] = str(controls["ld1_pseudo_type"])
        labels["ld1_rel"] = f"rel={controls['ld1_rel']}"
        labels["ld1_dft"] = str(controls.get("ld1_dft", "PBE"))

    parts = [labels["xc"], labels["relativistic"]]
    if semicore:
        parts.append("semi-cœur")
    if gen == "ape":
        parts.append(labels["pp_type_ape"])
    elif gen == "atompaw":
        parts.append(labels["pp_type_atompaw"])
    elif gen == "ld1" and controls.get("ld1_pseudo_type"):
        parts.insert(0, str(controls["ld1_pseudo_type"]))
    if f_treatment:
        parts.append(f"f={f_treatment}")

    return {
        "controls": controls,
        "summary": " · ".join(parts),
        "rationale": rationale,
        "labels": labels,
    }


def build_params_payload(sym: str, generator: str = "ld1", *, lang: str = "fr") -> dict[str, Any]:
    """Payload API pour l’UI (matrice + hints élément)."""
    gen = (generator or "ld1").lower()
    if gen.startswith("oncv"):
        gen = "oncvpsp"
    L = "en" if (lang or "fr").lower().startswith("en") else "fr"
    title = (
        "Physical parameters by generator"
        if L == "en"
        else "Paramètres physiques par générateur"
    )
    subtitle = (
        "Compare pseudo type, XC functional and relativity — then open the full generator."
        if L == "en"
        else "Comparez type de pseudo, fonctionnelle XC et relativité — puis ouvrez le générateur complet."
    )
    return {
        "success": True,
        "element": normalize_symbol(sym),
        "generator": gen,
        "lang": L,
        "title": title,
        "subtitle": subtitle,
        "matrix": PARAM_MATRIX_FR,
        "hints": element_param_hints(sym, gen),
        "optimal_controls": element_optimal_controls(sym, gen),
        "generators": list(_GENERATORS),
    }

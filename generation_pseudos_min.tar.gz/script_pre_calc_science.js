/**
 * Panneau scientifique repliable — commun ld1 · APE · ATOMPAW · ONCVPSP
 */
(function () {
    'use strict';

    function apiBase() {
        return typeof getApiPseudosBase === 'function' ? getApiPseudosBase() : 'http://127.0.0.1:5008';
    }

    function esc(s) {
        if (s == null) return '';
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function noticeLang() {
        if (typeof window.getGpLang === 'function') return window.getGpLang();
        return window.gpLang || 'fr';
    }

    function resolveNotice(payload, lang) {
        if (!payload) return { n: {}, lang: 'fr' };
        var L = (lang || noticeLang() || 'fr').toLowerCase();
        if (L !== 'en') L = 'fr';
        if (payload.notice) {
            return { n: payload.notice, lang: L, payload: payload };
        }
        var root = payload.pre_calc_notice || payload;
        var i18n = root.i18n || {};
        var n = i18n[L] || root;
        if (!n.science_note_full && payload.science_note_full) {
            n = Object.assign({}, n, { science_note_full: payload.science_note_full });
        }
        if (!n.science_note_full && L === 'en' && payload.science_note_full_en) {
            n = Object.assign({}, n, { science_note_full: payload.science_note_full_en });
        }
        if (!n.science_note_full && payload.science_note_full_fr) {
            n = Object.assign({}, n, { science_note_full: payload.science_note_full_fr });
        }
        return { n: n, lang: L, payload: payload };
    }

    function formatScienceNoteColored(raw) {
        if (!raw) return '';
        var lines = String(raw).split(/\r?\n/);
        var out = [];
        var inList = false;
        function closeList() {
            if (inList) { out.push('</ul>'); inList = false; }
        }
        for (var i = 0; i < lines.length; i++) {
            var line = lines[i];
            var t = line.replace(/\s+$/, '');
            if (!t || /^={5,}/.test(t) || /^-{5,}/.test(t)) {
                closeList();
                continue;
            }
            if (/^NOTE SCIENTIFIQUE|^SCIENTIFIC NOTE/i.test(t)) {
                closeList();
                out.push('<h3 style="margin:0 0 10px;color:#5eead4;font-size:1rem;font-weight:700;">' + esc(t) + '</h3>');
                continue;
            }
            if (/^(Visible dans|Mise à jour|Shown in|Updated)/i.test(t)) {
                closeList();
                out.push('<p style="margin:0 0 8px;color:#64748b;font-size:0.75rem;">' + esc(t) + '</p>');
                continue;
            }
            if (/^\d+\.\s+\S/.test(t)) {
                closeList();
                out.push('<h4 style="margin:14px 0 6px;color:#2dd4bf;font-size:0.88rem;font-weight:700;border-left:3px solid #14b8a6;padding-left:10px;">' + esc(t) + '</h4>');
                continue;
            }
            var bullet = t.match(/^\s*[•·\-\*]\s+(.*)$/);
            if (bullet) {
                if (!inList) {
                    out.push('<ul style="margin:4px 0 10px;padding-left:1.25em;color:#cbd5e1;">');
                    inList = true;
                }
                out.push('<li style="margin:3px 0;color:#e2e8f0;">' + esc(bullet[1]) + '</li>');
                continue;
            }
            closeList();
            out.push('<p style="margin:0 0 8px;color:#cbd5e1;font-size:0.8rem;line-height:1.55;">' + esc(t) + '</p>');
        }
        closeList();
        return out.join('');
    }

    function bodyHtmlLaunch(sym, n) {
        var summary = n.summary || '';
        var elNote = n.element_note || '';
        var ft = n.f_treatment_label || n.f_treatment || '';
        var what = n.what_we_do || n.generator_what || '';
        var rec = n.recommended || [];
        var sections = n.physics_sections || n.sections || [];
        var html = '';
        if (summary) {
            html += '<p style="margin:0 0 10px;color:#e2e8f0;font-size:0.86rem;line-height:1.5;">' + esc(summary) + '</p>';
        }
        if (elNote) {
            html += '<p style="margin:0 0 10px;padding:8px 10px;border-radius:8px;background:rgba(251,191,36,0.08);'
                + 'border:1px solid rgba(251,191,36,0.25);color:#fde68a;font-size:0.82rem;">'
                + '<strong style="color:#fcd34d;">' + esc(n.element_label || 'Élément') + ' ' + esc(sym) + '.</strong> '
                + esc(elNote) + '</p>';
        }
        if (ft) {
            html += '<p style="margin:0 0 10px;font-size:0.82rem;"><strong style="color:#99f6e4;">'
                + esc(n.f_treatment_heading || 'Traitement f') + '.</strong> '
                + '<span style="color:#fde68a;">' + esc(ft) + '</span></p>';
        }
        if (sections.length) {
            var sec0 = sections[0] || {};
            html += '<p style="margin:0 0 10px;padding:8px 10px;border-radius:8px;background:rgba(15,23,42,0.55);'
                + 'border-left:3px solid #5eead4;font-size:0.8rem;color:#cbd5e1;">'
                + '<strong style="color:#5eead4;">' + esc(sec0.heading || sec0.title || '') + '</strong> '
                + esc(sec0.body || sec0.text || '') + '</p>';
        }
        if (what) {
            html += '<p style="margin:0 0 8px;font-size:0.8rem;color:#bae6fd;">'
                + '<strong style="color:#7dd3fc;">' + esc(n.generator_heading || 'Dans ce générateur') + '.</strong> '
                + esc(what) + '</p>';
        }
        if (rec.length) {
            html += '<p style="margin:0;font-size:0.76rem;color:#94a3b8;">'
                + esc(n.recommended_label || 'Si échec') + ' : '
                + rec.map(function (r) { return '<code style="color:#7dd3fc;">' + esc(r) + '</code>'; }).join(' · ')
                + '</p>';
        }
        return html;
    }

    function bodyHtml(sym, n, mode) {
        if (mode === 'launch') return bodyHtmlLaunch(sym, n);
        var summary = n.summary || '';
        var elNote = n.element_note || '';
        var ft = n.f_treatment_label || n.f_treatment || '';
        var full = n.science_note_full || '';
        var sections = n.physics_sections || n.sections || [];
        var what = n.what_we_do || n.generator_what || '';
        var by = n.by_problem || {};
        var labels = n.by_problem_labels || {};
        var rec = n.recommended || [];
        var secColors = ['#5eead4', '#67e8f9', '#fcd34d', '#fdba74', '#c4b5fd', '#86efac'];
        var html = '';

        if (summary) {
            html += '<p style="margin:0 0 12px;color:#e2e8f0;font-size:0.88rem;">' + esc(summary) + '</p>';
        }
        if (elNote) {
            html += '<p style="margin:0 0 10px;padding:8px 10px;border-radius:8px;background:rgba(45,212,191,0.08);'
                + 'border:1px solid rgba(45,212,191,0.2);"><strong style="color:#99f6e4;">'
                + esc(n.element_label || 'Élément') + ' ' + esc(sym) + '.</strong> ' + esc(elNote) + '</p>';
        }
        if (ft) {
            html += '<p style="margin:0 0 12px;"><strong style="color:#99f6e4;">'
                + esc(n.f_treatment_heading || 'Traitement f') + '.</strong> '
                + '<span style="color:#fde68a;">' + esc(ft) + '</span></p>';
        }
        if (sections.length) {
            html += '<div style="margin:0 0 12px;">';
            for (var i = 0; i < sections.length; i++) {
                var sec = sections[i] || {};
                var col = secColors[i % secColors.length];
                html += '<div style="margin:0 0 10px;padding:10px 12px;border-radius:8px;'
                    + 'background:rgba(15,23,42,0.55);border-left:3px solid ' + col + ';">'
                    + '<div style="color:' + col + ';font-weight:700;font-size:0.84rem;margin-bottom:4px;">'
                    + esc(sec.heading || sec.title || '') + '</div>'
                    + '<div style="color:#cbd5e1;font-size:0.8rem;line-height:1.55;">'
                    + esc(sec.body || sec.text || '') + '</div></div>';
            }
            html += '</div>';
        }
        if (what) {
            html += '<p style="margin:0 0 12px;padding:10px;border-radius:8px;background:rgba(56,189,248,0.08);'
                + 'border:1px solid rgba(56,189,248,0.25);color:#bae6fd;font-size:0.82rem;">'
                + '<strong style="color:#7dd3fc;">' + esc(n.generator_heading || 'Dans ce générateur') + '.</strong> '
                + esc(what) + '</p>';
        }
        if (Object.keys(by).length) {
            html += '<p style="margin:0 0 6px;font-weight:700;color:#a5b4fc;font-size:0.82rem;">'
                + esc(n.by_problem_heading || 'Choix selon le problème') + '</p><ul style="margin:0 0 12px;padding-left:1.2em;">';
            Object.keys(by).forEach(function (k) {
                html += '<li style="margin:4px 0;color:#e2e8f0;font-size:0.8rem;"><strong style="color:#fcd34d;">'
                    + esc(labels[k] || k) + '</strong> → ' + esc(by[k]) + '</li>';
            });
            html += '</ul>';
        }
        if (rec.length) {
            html += '<p style="margin:0 0 10px;font-size:0.78rem;color:#94a3b8;">'
                + esc(n.recommended_label || 'Alternatives') + ' : '
                + rec.map(function (r) { return '<code style="color:#7dd3fc;">' + esc(r) + '</code>'; }).join(' · ')
                + '</p>';
        }
        if (full) {
            html += '<details style="margin-top:4px;border-top:1px solid rgba(148,163,184,0.25);padding-top:10px;">'
                + '<summary style="cursor:pointer;color:#5eead4;font-weight:700;font-size:0.85rem;">'
                + esc(n.note_summary_label || 'NOTE SCIENTIFIQUE (texte complet)') + '</summary>'
                + '<div class="oncv-science-note-colored" style="margin:10px 0 0;padding:14px;'
                + 'border-radius:10px;background:linear-gradient(165deg,#020617 0%,#0f172a 55%,#042f2e 100%);'
                + 'border:1px solid rgba(45,212,191,0.25);max-height:320px;overflow:auto;">'
                + formatScienceNoteColored(full)
                + '</div></details>';
        }
        if (n.science_note_path) {
            html += '<p style="margin:10px 0 0;font-size:0.75rem;color:#64748b;">'
                + esc(n.footer_file || 'Fichier') + ' : <code style="color:#7dd3fc;">'
                + esc(n.science_note_path) + '</code></p>';
        }
        return html;
    }

    function launchTitle(sym, n, lang) {
        if (n.launch_title) return n.launch_title;
        return lang === 'en'
            ? ('Before launch — ' + sym)
            : ('Rappel avant lancement — ' + sym);
    }

    function detailsHtml(sym, generator, payload, lang, openByDefault, mode) {
        var resolved = resolveNotice(payload, lang);
        var n = resolved.n;
        var isLaunch = mode === 'launch';
        var title = isLaunch ? launchTitle(sym, n, resolved.lang) : (n.title || ('Avant de lancer — ' + sym));
        var hint = isLaunch
            ? (resolved.lang === 'en' ? '(check before running)' : '(vérifier avant de lancer)')
            : (n.collapse_hint || '(replier / déplier)');
        var fam = (payload && payload.family) || n.family || '';
        var openAttr = openByDefault !== false ? ' open' : '';
        return ''
            + '<details class="gp-pre-calc-science oncv-4f-note" data-sym="' + esc(sym) + '"'
            + ' data-generator="' + esc(generator || '') + '" data-family="' + esc(fam) + '"'
            + ' data-mode="' + esc(mode || 'physics') + '"' + openAttr + '>'
            + '<summary style="cursor:pointer;padding:12px 14px;font-weight:650;font-size:0.9rem;'
            + 'list-style:none;user-select:none;">'
            + '<span class="gp-pre-calc-title">▾ ' + esc(title)
            + ' <span style="font-weight:500;font-size:0.78em;color:#94a3b8;">' + esc(hint) + '</span></span>'
            + '</summary>'
            + '<div class="gp-pre-calc-body" style="padding:0 14px 14px;font-size:0.82rem;'
            + 'line-height:1.6;max-height:min(42vh,420px);overflow:auto;">'
            + bodyHtml(sym, n, mode)
            + '</div></details>';
    }

    window.gpFetchPreCalcScience = async function (sym, generator, opts) {
        opts = opts || {};
        var url = apiBase() + '/api/pseudos/pre_calc_science?element=' + encodeURIComponent(sym)
            + '&generator=' + encodeURIComponent(generator || 'ld1');
        if (opts.f_treatment) url += '&f_treatment=' + encodeURIComponent(opts.f_treatment);
        if (opts.lang) url += '&lang=' + encodeURIComponent(opts.lang);
        try {
            var r = await fetch(url, { cache: 'no-store' });
            if (!r.ok) return null;
            return await r.json();
        } catch (e) {
            return null;
        }
    };

    window.gpMountPreCalcScience = function (slot, sym, generator, payloadOrPromise, opts) {
        opts = opts || {};
        if (!slot) return Promise.resolve('');
        var cacheKey = sym + '|' + (generator || 'ld1');
        function render(payload) {
            if (!payload || !payload.success) {
                slot.innerHTML = '';
                return '';
            }
            window._gpPreCalcCache = window._gpPreCalcCache || {};
            window._gpPreCalcCache[cacheKey] = payload;
            var mode = opts.mode || 'physics';
            var html = detailsHtml(sym, generator, payload, opts.lang, opts.open !== false, mode);
            slot.innerHTML = html;
            slot.setAttribute('data-gp-science-mode', mode);
            return html;
        }
        if (payloadOrPromise && typeof payloadOrPromise.then === 'function') {
            slot.innerHTML = '<div class="gen-ld1-meta">' + esc(opts.loadingText || 'Chargement note scientifique…') + '</div>';
            return payloadOrPromise.then(render).catch(function () { slot.innerHTML = ''; return ''; });
        }
        if (payloadOrPromise && payloadOrPromise.success) {
            return Promise.resolve(render(payloadOrPromise));
        }
        return window.gpFetchPreCalcScience(sym, generator, opts).then(render);
    };

    window.gpFetchRecommendedCatalog = async function (sym) {
        try {
            var r = await fetch(apiBase() + '/api/pseudos/recommended_catalog?element=' + encodeURIComponent(sym), { cache: 'no-store' });
            if (!r.ok) return null;
            return await r.json();
        } catch (e) {
            return null;
        }
    };

    window.gpRenderRecommendedCatalogHtml = function (items, sym, opts) {
        opts = opts || {};
        if (!items || !items.length) return '';
        var html = '<div class="gp-rec-catalog" style="margin-top:12px;padding:12px 14px;border-radius:10px;'
            + 'background:rgba(30,58,95,0.45);border:1px solid rgba(59,130,246,0.35);">'
            + '<div style="color:#93c5fd;font-weight:700;font-size:0.84rem;margin-bottom:8px;">'
            + esc(opts.title || ('Alternatives recommandées pour ' + (sym || ''))) + '</div><ul style="margin:0;padding-left:1.1em;">';
        items.forEach(function (it) {
            var label = it.name || it.label || it.variant || '';
            var reason = it.reason ? ' — ' + it.reason : '';
            var path = it.path || '';
            var src = it.source || it.variant || '';
            html += '<li style="margin:5px 0;color:#e2e8f0;font-size:0.82rem;">';
            if (path && path.toLowerCase().endsWith('.upf')) {
                html += '<button type="button" class="btn-action btn-secondary-act" style="font-size:0.78rem;padding:4px 8px;" '
                    + 'onclick="navigator.clipboard.writeText(\'' + String(path).replace(/\\/g, '\\\\').replace(/'/g, "\\'") + '\').then(function(){if(typeof _showToast===\'function\')_showToast(\'Chemin UPF copié\',\'#6366f1\',2000);})">'
                    + esc(label) + '</button>';
            } else if (src === 'atompaw' && typeof window.ouvrirGenerateurATOMPAWComplet === 'function') {
                html += '<button type="button" class="btn-action btn-secondary-act" style="font-size:0.78rem;padding:4px 8px;" '
                    + 'onclick="ouvrirGenerateurATOMPAWComplet(\'' + esc(sym) + '\')">' + esc(label || 'ATOMPAW') + '</button>';
            } else if ((src === 'oncvpsp' || src === 'oncv') && typeof window.ouvrirGenerateurONCVPSPComplet === 'function') {
                html += '<button type="button" class="btn-action btn-secondary-act" style="font-size:0.78rem;padding:4px 8px;" '
                    + 'onclick="ouvrirGenerateurONCVPSPComplet(\'' + esc(sym) + '\')">' + esc(label || 'ONCVPSP') + '</button>';
            } else {
                html += '<code style="color:#7dd3fc;">' + esc(label) + '</code>';
            }
            if (reason) html += '<span style="color:#94a3b8;font-size:0.78rem;">' + esc(reason) + '</span>';
            html += '</li>';
        });
        html += '</ul></div>';
        return html;
    };

    window.gpFetchGeneratorParams = async function (sym, generator, opts) {
        opts = opts || {};
        try {
            var url = apiBase() + '/api/pseudos/generator_physics_params?element='
                + encodeURIComponent(sym) + '&generator=' + encodeURIComponent(generator || 'ld1');
            if (opts.lang) url += '&lang=' + encodeURIComponent(opts.lang);
            var r = await fetch(url, { cache: 'no-store' });
            if (!r.ok) return null;
            return await r.json();
        } catch (e) {
            return null;
        }
    };

    function _normGenCol(gen) {
        var g = (gen || 'ld1').toLowerCase();
        if (g.startsWith('oncv')) return 'oncvpsp';
        if (g === 'ld1x' || g === 'ld1.x') return 'ld1';
        return g;
    }

    window.gpRenderGeneratorParamsHtml = function (payload, highlightGen) {
        if (!payload || !payload.success) return '';
        var hl = _normGenCol(highlightGen || payload.generator);
        var genLabels = { ld1: 'ld1.x', ape: 'APE', atompaw: 'ATOMPAW', oncvpsp: 'ONCVPSP' };
        var rows = payload.matrix || [];
        var hints = payload.hints || {};
        var html = '<details class="gp-params-matrix" open>'
            + '<summary>▾ ' + esc(payload.title || 'Paramètres physiques') + '</summary>'
            + '<p class="gp-params-subtitle">' + esc(payload.subtitle || '') + '</p>';
        if (hints.generator_note) {
            html += '<div class="gp-params-hints"><strong>' + esc(genLabels[hl] || hl) + '.</strong> '
                + esc(hints.generator_note) + '</div>';
        }
        html += '<div style="overflow-x:auto;padding:0 8px 12px;">'
            + '<table><thead><tr><th>Axe</th>'
            + '<th class="' + (hl === 'ld1' ? 'gp-params-col-hl' : '') + '">ld1.x</th>'
            + '<th class="' + (hl === 'ape' ? 'gp-params-col-hl' : '') + '">APE</th>'
            + '<th class="' + (hl === 'atompaw' ? 'gp-params-col-hl' : '') + '">ATOMPAW</th>'
            + '<th class="' + (hl === 'oncvpsp' ? 'gp-params-col-hl' : '') + '">ONCV</th>'
            + '</tr></thead><tbody>';
        rows.forEach(function (row) {
            html += '<tr><th>' + esc(row.label || '') + '</th>';
            ['ld1', 'ape', 'atompaw', 'oncvpsp'].forEach(function (g) {
                var cell = row[g] || {};
                var cls = g === hl ? ' class="gp-params-col-hl"' : '';
                html += '<td' + cls + '><strong class="gp-params-cell-strong">'
                    + esc(cell.choices || '') + '</strong>'
                    + (cell.ui ? '<br><span class="gp-params-cell-ui">UI : ' + esc(cell.ui) + '</span>' : '')
                    + (cell.note ? '<br><span class="gp-params-cell-note">' + esc(cell.note) + '</span>' : '')
                    + '</td>';
            });
            html += '</tr>';
        });
        html += '</tbody></table></div>';
        if (hints.pseudo_type && hints.pseudo_type.recommended) {
            html += '<p class="gp-params-hint-type">'
                + '<strong>' + esc(payload.element || '') + ' — type :</strong> '
                + esc(hints.pseudo_type.recommended) + '</p>';
        }
        if (hints.xc && hints.xc.recommended) {
            html += '<p class="gp-params-hint-xc">'
                + '<strong>XC :</strong> ' + esc(hints.xc.recommended) + '</p>';
        }
        if (hints.relativity && hints.relativity.recommended) {
            html += '<p class="gp-params-hint-rel">'
                + '<strong>Relativité :</strong> ' + esc(hints.relativity.recommended) + '</p>';
        }
        if (hints.extra && hints.extra.length) {
            html += '<ul class="gp-params-hint-extra">';
            hints.extra.forEach(function (x) { html += '<li>' + esc(x) + '</li>'; });
            html += '</ul>';
        }
        var opt = payload.optimal_controls;
        if (opt && opt.summary) {
            html += '<div class="gp-optimal-banner" style="margin:0 14px 14px;">'
                + '<strong>★ Pré-sélection optimale :</strong> '
                + '<span class="gp-optimal-banner__summary">' + esc(opt.summary) + '</span></div>';
        }
        html += '</details>';
        return html;
    };

    window.gpRenderOptimalBannerHtml = function (optimal, sym, genLabel) {
        if (!optimal || !optimal.summary) return '';
        var rat = (optimal.rationale || []).slice(0, 2).join(' ');
        var html = '<div class="gp-optimal-banner">'
            + '<strong>★ Sélection optimale pour ' + esc(sym) + '</strong>'
            + (genLabel ? ' <span class="gp-optimal-banner__gen">(' + esc(genLabel) + ')</span>' : '')
            + ' : <span class="gp-optimal-banner__summary">' + esc(optimal.summary) + '</span>';
        if (rat) {
            html += '<br><span class="gp-optimal-banner__rat">' + esc(rat) + '</span>';
        }
        html += '</div>';
        return html;
    };

    window.gpApplyLd1OptimalControls = async function (sym) {
        sym = String(sym || '').replace(/[^A-Za-z]/g, '').slice(0, 8);
        if (!sym || typeof window.gpFetchGeneratorParams !== 'function') return;
        var slot = document.getElementById('ld1_optimal_banner_slot');
        try {
            var payload = await window.gpFetchGeneratorParams(sym, 'ld1');
            if (!payload || !payload.success || !payload.optimal_controls) return;
            var opt = payload.optimal_controls;
            var c = opt.controls || {};
            var pt = document.getElementById('pseudo_type');
            var fn = document.getElementById('pseudo_functional');
            var rel = document.getElementById('pseudo_rel');
            if (pt && c.ld1_pseudo_type) {
                var want = c.ld1_pseudo_type;
                if (pt.querySelector('option[value="' + want + '"]')) pt.value = want;
            }
            if (fn && c.ld1_dft) {
                var dft = c.ld1_dft;
                if (fn.querySelector('option[value="' + dft + '"]')) fn.value = dft;
            }
            if (rel != null && c.ld1_rel != null) {
                var relMap = { 0: 'no', 1: 'scalar', 2: 'full' };
                var rv = relMap[c.ld1_rel] || (c.ld1_rel >= 2 ? 'full' : (c.ld1_rel >= 1 ? 'scalar' : 'no'));
                if (rel.querySelector('option[value="' + rv + '"]')) rel.value = rv;
            }
            if (slot) {
                slot.innerHTML = window.gpRenderOptimalBannerHtml(opt, sym, 'ld1.x')
                    + '<button type="button" class="btn-action btn-secondary-act" style="font-size:0.72rem;margin-top:8px;padding:4px 10px;" '
                    + 'onclick="gpApplyLd1OptimalControls(\'' + sym.replace(/'/g, "\\'") + '\')">Réappliquer l\'optimal</button>';
            }
            if (typeof updatePseudoTypeInfo === 'function') updatePseudoTypeInfo();
            if (typeof updateFunctionalInfo === 'function') updateFunctionalInfo();
            if (typeof actualiserPreviewLD1 === 'function') actualiserPreviewLD1(sym);
        } catch (e) {
            if (slot) slot.innerHTML = '';
        }
    };

    window.gpMountGeneratorParams = function (slot, sym, generator, payloadOrPromise, opts) {
        opts = opts || {};
        if (!slot) return Promise.resolve('');
        function render(payload) {
            if (!payload || !payload.success) {
                slot.innerHTML = '';
                return '';
            }
            slot.innerHTML = window.gpRenderGeneratorParamsHtml(payload, generator);
            return slot.innerHTML;
        }
        if (payloadOrPromise && typeof payloadOrPromise.then === 'function') {
            slot.innerHTML = '<div class="gen-ld1-meta">' + esc(opts.loadingText || 'Chargement paramètres…') + '</div>';
            return payloadOrPromise.then(render).catch(function () { slot.innerHTML = ''; return ''; });
        }
        if (payloadOrPromise && payloadOrPromise.success) {
            return Promise.resolve(render(payloadOrPromise));
        }
        return window.gpFetchGeneratorParams(sym, generator, opts).then(render);
    };

    window.gpRevealLaunchScienceReminder = function (sym, generator, slotEl) {
        var gen = generator || 'oncvpsp';
        var slot = slotEl;
        if (!slot) {
            var slotIds = {
                oncvpsp: 'oncv_pre_calc_launch_slot',
                oncv: 'oncv_pre_calc_launch_slot',
                ld1: 'ld1_pre_calc_launch_slot',
                ld1x: 'ld1_pre_calc_launch_slot',
                ape: 'gp_ape_pre_calc_launch_slot',
                atompaw: 'gp_atompaw_pre_calc_launch_slot',
            };
            slot = document.getElementById(slotIds[gen] || slotIds.oncvpsp);
        }
        if (!slot) return false;
        var det = slot.querySelector('details.gp-pre-calc-science');
        if (!det && typeof window.gpMountPreCalcScience === 'function') {
            window.gpMountPreCalcScience(slot, sym, generator || 'oncvpsp', null, { mode: 'launch', open: true });
            det = slot.querySelector('details.gp-pre-calc-science');
        }
        if (det) {
            det.open = true;
        }
        var bar = document.querySelector('.gp-modal-launch-bar');
        if (bar) {
            try { bar.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) { /* ignore */ }
        }
        return !!det;
    };

    window.gpRefreshPreCalcScienceLang = function () {
        var lang = noticeLang();
        document.querySelectorAll('.gp-pre-calc-science[data-sym]').forEach(function (det) {
            var sym = det.getAttribute('data-sym');
            var gen = det.getAttribute('data-generator') || 'ld1';
            var mode = det.getAttribute('data-mode') || 'physics';
            var key = sym + '|' + gen;
            var payload = window._gpPreCalcCache && window._gpPreCalcCache[key];
            if (!payload) return;
            var body = det.querySelector('.gp-pre-calc-body');
            var titleEl = det.querySelector('.gp-pre-calc-title');
            var resolved = resolveNotice(payload, lang);
            if (body) body.innerHTML = bodyHtml(sym, resolved.n, mode);
            if (titleEl) {
                var title = mode === 'launch'
                    ? launchTitle(sym, resolved.n, resolved.lang)
                    : (resolved.n.title || '');
                titleEl.innerHTML = '▾ ' + esc(title)
                    + ' <span style="font-weight:500;font-size:0.78em;color:#94a3b8;">'
                    + esc(mode === 'launch'
                        ? (resolved.lang === 'en' ? '(check before running)' : '(vérifier avant de lancer)')
                        : (resolved.n.collapse_hint || ''))
                    + '</span>';
            }
        });
    };

    if (!window._gpPreCalcLangListener) {
        window._gpPreCalcLangListener = true;
        window.addEventListener('gp:langchange', function () {
            if (typeof window.gpRefreshPreCalcScienceLang === 'function') {
                window.gpRefreshPreCalcScienceLang();
            }
            if (typeof window.setOncv4fLang === 'function') {
                window.setOncv4fLang(noticeLang());
            }
        });
    }

    var GP_EXEC_META = {
        ape: {
            btnId: 'gp_btn_ape_run_modal',
            idle: '③ Lancer APE',
            label: 'APE',
            detail: 'Calcul APE en cours — génération UPF (≈30 s – 3 min)',
        },
        atompaw: {
            btnId: 'gp_btn_atompaw_run_modal',
            idle: '③ Lancer ATOMPAW',
            label: 'ATOMPAW',
            detail: 'Calcul ATOMPAW en cours — génération PAW/UPF (≈1 – 5 min)',
        },
        oncvpsp: {
            btnId: 'oncv_btn_run_modal',
            idle: '③ Lancer oncvpsp.x',
            label: 'ONCVPSP',
            detail: 'Exécution oncvpsp.x côté serveur (≈30 s – 2 min)',
        },
        ld1: {
            btnId: 'ld1_btn_run_modal',
            btnSel: '#modal_generateur_pseudo .ld1-btn-action-run',
            idle: null,
            label: 'ld1.x',
            detail: 'Exécution ld1.x via l’API (≈30 – 90 s)',
        },
    };

    window.gpEnsureExecIndicatorStyles = function () {
        if (document.getElementById('gp-exec-indicator-css')) return;
        var s = document.createElement('style');
        s.id = 'gp-exec-indicator-css';
        s.textContent = ''
            + '.gen-run-result--loading.gp-exec-output-loading{display:flex;align-items:flex-start;gap:12px;}';
        document.head.appendChild(s);
    };

    window.gpRenderExecLoadingHtml = function (label, detail) {
        window.gpEnsureExecIndicatorStyles();
        return '<div class="gen-run-result gen-run-result--loading gp-exec-output-loading" role="status" aria-live="polite">'
            + '<span class="gp-exec-spinner" aria-hidden="true"></span>'
            + '<div><strong>' + esc(label || 'Exécution en cours') + '</strong>'
            + (detail ? '<div style="font-size:0.88em;color:#94a3b8;margin-top:4px;">' + esc(detail) + '</div>' : '')
            + '</div></div>';
    };

    function gpFindExecButton(engine, explicitBtn) {
        if (explicitBtn) return explicitBtn;
        var m = GP_EXEC_META[engine];
        if (!m) return null;
        if (m.btnId) {
            var byId = document.getElementById(m.btnId);
            if (byId) return byId;
        }
        if (m.btnSel) return document.querySelector(m.btnSel);
        return null;
    }

    window.gpSetGeneratorRunning = function (opts) {
        opts = opts || {};
        var engine = opts.engine || 'ape';
        var meta = GP_EXEC_META[engine] || { label: engine, detail: 'Exécution en cours…', idle: 'Lancer' };
        window.gpEnsureExecIndicatorStyles();
        var btn = gpFindExecButton(engine, opts.button);
        var sym = opts.element || '';

        window._gpExecActive = window._gpExecActive || {};
        if (btn && btn._gpExecOrigHtml == null) {
            btn._gpExecOrigHtml = btn.innerHTML;
            btn._gpExecOrigDisabled = btn.disabled;
        }
        if (btn) {
            btn.disabled = true;
            btn.classList.add('gp-exec-btn-running');
            btn.innerHTML = '<span class="gp-exec-spinner gp-exec-spinner--inline" aria-hidden="true"></span> Exécution…';
        }

        var launchBar = (btn && btn.closest('.gp-modal-launch-bar')) || opts.launchBar || null;
        if (launchBar) launchBar.classList.add('gp-modal-launch-bar--running');

        var panel = (launchBar && launchBar.closest('.ld1-modal-panel'))
            || (btn && btn.closest('.ld1-modal-panel'))
            || document.querySelector('#modal_generateur_pseudo .ld1-modal-panel')
            || null;

        if (panel) {
            var banner = panel.querySelector('.gp-exec-banner');
            if (!banner) {
                banner = document.createElement('div');
                banner.className = 'gp-exec-banner';
                banner.setAttribute('role', 'status');
                banner.setAttribute('aria-live', 'polite');
                var scrollBody = panel.querySelector('.gp-modal-scroll-body');
                if (scrollBody) scrollBody.insertBefore(banner, scrollBody.firstChild);
                else panel.insertBefore(banner, panel.firstChild);
            }
            banner.innerHTML = '<span class="gp-exec-spinner" aria-hidden="true"></span>'
                + '<div><strong>⏳ ' + esc(meta.label) + (sym ? ' — ' + esc(sym) : '') + '</strong>'
                + '<div class="gp-exec-banner__detail">' + esc(opts.detail || meta.detail) + '</div></div>';
            banner.style.display = 'flex';
            try { banner.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) { /* ignore */ }
        }

        if (opts.outputEl) {
            try { opts.outputEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) { /* ignore */ }
        }

        if (typeof window._showToast === 'function') {
            window._showToast((meta.label || engine) + ' — exécution démarrée', '#1d4ed8', 2200);
        }

        window._gpExecActive[engine] = { btn: btn, launchBar: launchBar, panel: panel };
    };

    window.gpClearGeneratorRunning = function (engine) {
        var state = window._gpExecActive && window._gpExecActive[engine];
        var meta = GP_EXEC_META[engine] || { idle: 'Lancer' };
        var btn = state && state.btn;
        if (btn) {
            btn.disabled = !!btn._gpExecOrigDisabled;
            btn.classList.remove('gp-exec-btn-running');
            if (btn._gpExecOrigHtml != null) btn.innerHTML = btn._gpExecOrigHtml;
            else if (meta.idle) btn.textContent = meta.idle;
            delete btn._gpExecOrigHtml;
            delete btn._gpExecOrigDisabled;
        }
        if (state && state.launchBar) state.launchBar.classList.remove('gp-modal-launch-bar--running');
        if (state && state.panel) {
            var banner = state.panel.querySelector('.gp-exec-banner');
            if (banner) banner.style.display = 'none';
        }
        if (window._gpExecActive) delete window._gpExecActive[engine];
    };
})();

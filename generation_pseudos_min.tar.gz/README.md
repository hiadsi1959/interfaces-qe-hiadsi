# Génération des pseudopotentiels — Quantum ESPRESSO

Interface web **autonome** : tableau périodique, **ld1.x**, **APE**, **ATOMPAW**, **ONCVPSP**, bibliothèques PSLibrary / PseudoDojo / SSSP.

Une seule API Flask (`api_pseudos_standalone.py`) sert l’interface et tous les calculs sur le port **5008**. Ne pas ouvrir `index.html` en `file://`.

---

## Téléchargement depuis le site / Release v1.4

Version publiée : **v1.4 · 2026-10-21**.

| | |
|---|---|
| Site (toutes les interfaces) | <https://hiadsi1959.github.io/interfaces-qe-hiadsi/> |
| Archive v1.4 (asset de Release) | <https://github.com/hiadsi1959/interfaces-qe-hiadsi/releases/download/v1.4/generation_pseudos_v1.4_2026-10-21.tar.gz> |
| Page de la Release | <https://github.com/hiadsi1959/interfaces-qe-hiadsi/releases/tag/v1.4> |

L’archive (~131 Mo compressés, ~300 Mo décompressés) est **autonome** : interface web, API Flask, les **4 générateurs** (`ld1.x`, `oncvpsp.x`, `ape`, `atompaw`), `pw.x` **et leurs bibliothèques** (`lib/` : MKL, Intel MPI, libxc, GSL) plus les gabarits ONCV. Elle est hébergée sur la **Release GitHub** car elle dépasse la limite de **100 Mo par fichier** du dépôt du site.

```bash
# 1. Télécharger et extraire (autre PC Linux)
wget https://github.com/hiadsi1959/interfaces-qe-hiadsi/releases/download/v1.4/generation_pseudos_v1.4_2026-10-21.tar.gz
tar xzf generation_pseudos_v1.4_2026-10-21.tar.gz
cd generation_pseudos

# 2. Configurer ce PC (une seule fois)
./configure.sh          # prérequis système + pip + chemins relatifs + contrôle de lib/

# 3. Démarrer (à chaque session)
./DEMARRER.sh           # → http://127.0.0.1:5008/
```

Sur le PC cible, **seul Python 3 est nécessaire** (Flask installé automatiquement) : Quantum ESPRESSO n’est pas requis pour les 4 générateurs embarqués.

Guides détaillés : **[docs/INSTALLATION_AUTRE_PC.md](docs/INSTALLATION_AUTRE_PC.md)** — **[docs/TRANSFERT_AUTRE_PC.md](docs/TRANSFERT_AUTRE_PC.md)**

---

## Nouveautés v1.4 (2026-10-21)

### Correction des bandes fantômes (états fantômes ONCVPSP)

Le canal `s` de **Nh** était généré avec `nbas = 7`, la borne basse autorisée (`ncon + 3`). Le test
ONCVPSP des états fortement localisés à énergie positive signalait alors un **`WARNING - GHOST(+)`**
à `<r>/rc ≈ 0.99` : le pseudopotentiel restait utilisable en calcul moléculaire simple, mais
pouvait produire une bande fantôme parasite en supercellule.

- **Cause** : nombre de fonctions de base `s` trop juste pour ce canal (balayage `nbas(s) = 6…14` :
  seul `nbas = 7` produit le ghost ; `8` et `9` sont propres ; au-delà ONCVPSP refuse la contrainte
  `ncon + 3 ≤ nbas ≤ ncon + 5`).
- **Correctif** : famille `p7` (Nh–Og) de `exotic_nc.py` → `nbas = (8, 7, 8, 8)`.
- **Résultat** : `Nh` sort désormais `GHOST(+) = 0`, `GHOST(-) = 0`, transfert `max|eae − ε| = 8.5 × 10⁻³ Ha`,
  et `pw.x` converge (`JOB DONE`, 6 itérations, `E = −106.04311334 Ry`).

### Autres corrections et régénérations

| Élément | Correction |
|---|---|
| **`exotic_nc.py`** | famille `p7` : `nbas = (8, 7, 8, 8)` + commentaire expliquant le ghost `s` |
| **`oncv_templates_exotic/*.dat`** | 20 gabarits (Fr–Og) régénérés ; `Nh.dat` porte `0 3.60 0.00 4 8 3.00` |
| **`api_pseudos_standalone.py`** | l’UPF est extrait de la **sortie fraîche** d’`oncvpsp.x` (stdout) **avant** toute réutilisation d’un fichier présent dans `_work/` : un `Nh_oncv.UPF` périmé (même md5 malgré un `.dat` neuf) était sinon resservi |
| **`pseudos-oncvpsp/Nh_oncv.UPF`**, **`pseudos/Nh_oncv.UPF`** | régénérés depuis le nouveau `.dat` (empreinte identique `6a7957…` ; `_work/oncv_Nh/` est un dossier de travail transitoire, recréé à chaque run) |
| **`oncv_templates_*` (6 dossiers, 113 gabarits)** | revalidés dans le binaire `oncvpsp.x` : `113/113` OK, `0` échec, `0` `GHOST(-)` |

### Limites connues (inchangées en v1.4)

- **Transférabilité** de `Lv`, `Ts`, `Og` : `max|eae − ε| = 0.022–0.029 Ha` pour un seuil de `0.02 Ha`
  (aucun ghost) — les super-lourds restent à affiner (`rc`, `qcut`, projecteurs).
- **`GHOST(+)` résiduels** sur 43 gabarits (PseudoDojo `main_group`, quelques lanthanides/actinides et
  `Po`/`Ts`) : avertissement non bloquant, présent dans les gabarits officiels de référence
  (par ex. `83_Bi.dat`, `56_Ba.dat`, `80_Hg.dat` en comportent un) ; aucun `GHOST(-)` lié.

Validation de référence : `python3 tests/verifier_gabarits_oncvpsp.py` et
`python3 tests/verifier_exotic_oncv.py`.

---

## Fichier unique installable (recommandé pour un autre PC)

Au lieu de copier tout le dossier du projet, vous pouvez produire **un seul fichier exécutable** (~105 Mo) contenant l’interface, l’API, **les 4 générateurs** (`ld1.x`, ONCVPSP, APE, ATOMPAW + `pw.x`) **et leurs bibliothèques** (`lib/`). Sur un autre PC, ce fichier s’installe, **s’auto-configure** selon la machine et démarre l’application — l’équivalent pratique d’un « `.exe` » sous Linux.

### Construire l’installateur (PC de développement, une fois)

```bash
cd generation_pseudos
chmod +x build_installer.sh
./build_installer.sh
```

Résultat : **`dist/generation_pseudos`** — un seul fichier à copier (clé USB, e-mail, `scp`, etc.).

Options de build :

```bash
./build_installer.sh --output ~/Bureau/generation_pseudos   # chemin de sortie personnalisé
./build_installer.sh --help
```

### Utiliser sur un autre PC

```bash
chmod +x generation_pseudos
./generation_pseudos
```

Installation permanente (commande disponible partout) :

```bash
./generation_pseudos --install
generation_pseudos          # depuis n’importe quel terminal
```

### Ce que fait le programme automatiquement

| Étape | Action |
|-------|--------|
| **1. Installation** | Extraction dans `~/.local/share/generation_pseudos/app/` |
| **2. Auto-configuration** | Détection de Quantum ESPRESSO, ONCVPSP, APE, ATOMPAW → écriture de `api_config.json` |
| **3. Démarrage** | Lancement de l’API (port **5008**) + ouverture du navigateur sur http://127.0.0.1:5008/ |

Au **premier lancement sur chaque machine**, les chemins sont détectés selon ce qui est installé sur ce PC. Si vous changez de machine ou déplacez QE, relancez avec `--reconfig`.

### Ce qui est inclus dans le fichier unique

| Inclus | Détail |
|--------|--------|
| Générateurs | `bin/` : `ld1.x`, `oncvpsp.x`, `ape`, `atompaw`, `pw.x` (≈ 47 Mo) |
| Bibliothèques | `lib/` : MKL, MPI, libxc, GSL (≈ 230 Mo) — portabilité sur tout PC Linux |
| Interface web | `index.html`, tous les `script_*.js`, assistant guidé |
| API Flask | `api_pseudos_standalone.py` et modules Python associés |
| Gabarits | Entrées ONCV (`.dat`), templates 3d, modèles APE/ATOMPAW |
| Scripts | Configuration, démarrage, arrêt |
| Dossiers de sortie | Création de `pseudos-ld1/`, `pseudos-APE/`, `pseudos-atompaw/`, `pseudos-oncvpsp/` |

### Ce qui reste à installer sur chaque PC (hors du fichier)

| Composant | Obligatoire | Rôle |
|-----------|-------------|------|
| **Python 3** + `flask`, `flask-cors` | oui | Installés automatiquement si absents |
| **Générateurs + bibliothèques** (`ld1.x`, `pw.x`, ONCVPSP, APE, ATOMPAW) | **non** | **Inclus dans le fichier** (`bin/` + `lib/`) |
| **Bibliothèques UPF** (`pseudos/`, plusieurs Go) | optionnel | Téléchargement via l’onglet *Autres bases* ou `./TELECHARGER_BASES.sh` |

Le programme **embarque** les 4 générateurs (`ld1.x`, ONCVPSP, APE, ATOMPAW), `pw.x` (`bin/`) **et leurs bibliothèques dynamiques** (`lib/` : MKL, Intel MPI, libxc, GSL) : sur le PC cible, **rien à installer** — seul Python 3 est requis (Flask installé automatiquement). `DEMARRER.sh` ajoute `lib/` à `LD_LIBRARY_PATH` au démarrage.

### Comparaison avec un `.exe` Windows

Sous Linux, on ne peut pas raisonnablement mettre la bibliothèque complète de pseudos (plusieurs Go) **dans** un seul binaire. Le fichier `generation_pseudos` regroupe :

- l’**interface complète** ;
- l’**API** ;
- les **4 générateurs** (`ld1.x`, ONCVPSP, APE, ATOMPAW), `pw.x` **et leurs bibliothèques** (~105 Mo) ;
- la **configuration automatique** des chemins ;
- le **démarrage** et l’ouverture du navigateur.

Seules les bibliothèques UPF volumineuses (PSLibrary, PseudoDojo, SSSP — plusieurs Go) restent à télécharger sur chaque poste via l’onglet *Autres bases* ou `./TELECHARGER_BASES.sh`.

### Commandes de l’installateur

```bash
./generation_pseudos                  # installer (si besoin), configurer, démarrer
./generation_pseudos --install        # copier dans ~/.local/bin/generation_pseudos
./generation_pseudos --reconfig       # reconfigurer les chemins sur ce PC
./generation_pseudos --reinstall      # ré-extraire l’application
./generation_pseudos --uninstall      # supprimer ~/.local/share/generation_pseudos/
./generation_pseudos --help           # aide
```

### Chemins après installation (fichier unique)

| Élément | Emplacement |
|---------|-------------|
| Application | `~/.local/share/generation_pseudos/app/` |
| Configuration | `~/.local/share/generation_pseudos/app/api_config.json` |
| UPF générés | `~/.local/share/generation_pseudos/app/pseudos-ld1/` (etc.) |
| Bibliothèque pw.x | `~/.local/share/generation_pseudos/app/pseudos/` |
| Commande globale | `~/.local/bin/generation_pseudos` (après `--install`) |
| Interface web | http://127.0.0.1:5008/ |
| Logs | `~/.local/share/generation_pseudos/app/logs/api_pseudos_standalone.log` |

Variable pour changer le dossier d’installation :

```bash
export GEN_PSEUDOS_INSTALL="$HOME/.local/share/generation_pseudos"
./generation_pseudos
```

---

## Lancement depuis le dossier du projet (PC de développement)

Si vous travaillez directement dans le dossier `generation_pseudos` (sans fichier unique) :

### Option A — Lanceur intégré au dossier

```bash
chmod +x GenerationPseudos ArreterGenerationPseudos
./GenerationPseudos
```

- Premier lancement sur ce PC : configuration automatique + démarrage
- Lancements suivants : démarrage direct
- Raccourci bureau : `bash scripts/install_lanceur_bureau.sh`

```bash
./GenerationPseudos --reconfig      # reconfigurer les chemins
./GenerationPseudos --config-only     # config sans démarrer
./ArreterGenerationPseudos            # arrêter l’API
```

### Option B — Copie du dossier (deux scripts)

Sur le **nouveau PC**, après extraction ou copie du dossier :

```bash
chmod +x configure.sh DEMARRER.sh
./configure.sh    # une fois : chemins QE, ONCV, APE, ATOMPAW
./DEMARRER.sh     # à chaque utilisation → http://127.0.0.1:5008/
```

Variantes de `configure.sh` :

```bash
./configure.sh --qe ~/q-e-qe-7.5/bin -y   # chemins explicites, sans questions
./configure.sh --check-only               # diagnostic sans modification
./configure.sh --start                    # configure et démarre (équivalent configure + DEMARRER)
```

`config_pc.sh` reste disponible comme alias de `configure.sh`.

Guide : **[docs/TRANSFERT_AUTRE_PC.md](docs/TRANSFERT_AUTRE_PC.md)**

```bash
./TRANSFERER_VERS_AUTRE_PC.sh --leger --dest user@IP_AUTRE_PC -y
# ou archive seule :
./emballer.sh
```

Guide installation : **[docs/INSTALLATION_AUTRE_PC.md](docs/INSTALLATION_AUTRE_PC.md)**

---

## Dossiers de sortie (4 générateurs)

Chaque outil enregistre ses UPF conformes QE dans son propre dossier :

| Générateur | Dossier |
|------------|---------|
| **ld1.x** | `pseudos-ld1/` |
| **APE** | `pseudos-APE/` |
| **ATOMPAW** | `pseudos-atompaw/` |
| **ONCVPSP** | `pseudos-oncvpsp/` |

Les UPF utilisables par `pw.x` sont aussi copiés dans `pseudos/`.  
Téléchargements catalogue : `pseudos-telecharges/`.  
Le dossier `pseudos_generes/` est **obsolète** (rétrocompatibilité uniquement).

---

## Génération + conformité en une commande

Pour produire **et vérifier** des pseudos conformes avec n'importe lequel des
4 générateurs (ONCVPSP · ld1.x · APE · ATOMPAW) :

```bash
./DEMARRER.sh                                    # 1. API si besoin
./GENERER_PSEUDOS.sh --elements Si Fe Ni         # 2. générer + vérifier
./GENERER_PSEUDOS.sh --elements lanthanides --generateurs oncvpsp
./GENERER_PSEUDOS.sh --elements tous --generateurs oncvpsp --resume
```

Chaque pseudo produit est contrôlé automatiquement (format UPF v2 / UPF v1 /
APE-ABINIT, élément, `z_valence`, type NC/US/PAW, intégrité du fichier). Le
rapport `dist/rapport_conformite.json` classe chaque couple élément × générateur
en `conforme`, `non_conforme` ou `echec_generateur` (limite connue du code pour
cet élément, ex. lanthanide en ld1/APE). Code de sortie non nul si un pseudo
demandé n'est pas conforme.

Contrôle des gabarits seuls (sans génération) :

```bash
python3 tests/verifier_entetes_gabarits.py     # en-têtes « ATOM AND REFERENCE »
python3 tests/verifier_gabarits_oncvpsp.py     # exécution réelle dans oncvpsp.x
```

---

## Vérification rapide

```bash
./configure.sh --check-only
./generation_pseudos --reconfig --config-only   # si installé via fichier unique
python3 tests/verifier_api_generale.py
./scripts/verifier_chemins_ui.sh
```

---

## Arborescence (essentiel)

| Emplacement | Rôle |
|-------------|------|
| **Racine** | `index.html`, `script_*.js`, `api_pseudos_standalone.py`, `api_config.json` |
| `dist/generation_pseudos` | **Fichier unique** à distribuer sur un autre PC |
| `scripts/` | `build_installer.sh`, `DEMARRER.sh`, `configure.sh`, nettoyage |
| `pseudos-*/` | Sorties UPF par générateur |
| `pseudos/` | Bibliothèque pour `pw.x` |
| `tests/` | `verifier_api_generale.py` |
| `docs/` | Installation, structure, chemins interface |

Détail : **[docs/STRUCTURE.md](docs/STRUCTURE.md)** — chemins UI : **[docs/CHEMINS_INTERFACE.md](docs/CHEMINS_INTERFACE.md)**

---

## Configuration manuelle (`api_config.json`)

Les chemins sont **relatifs à la racine du projet** quand le prérequis est dedans
(`bin/`, `pseudos/`, `lib/`) : l’installation reste valide après transfert sur un
autre PC (autre utilisateur, autre dossier). Les chemins absolus ne servent qu’aux
prérequis installés hors du dossier (Quantum ESPRESSO, oncvpsp…).

```json
{
  "bin_dir": "bin",
  "lib_dir": "lib",
  "qe_bin": "bin",
  "ld1_bin": "bin/ld1.x",
  "pw_bin": "bin/pw.x",
  "oncvpsp_bin": "bin/oncvpsp.x",
  "ape_bin": "bin/ape",
  "atompaw_bin": "bin/atompaw",
  "oncvpsp_root": ".",
  "pseudos_dir": "pseudos",
  "oncv_default_target": "qe"
}
```

`./configure.sh` remplit ce fichier automatiquement : il installe les prérequis
de l’interface (paquets système puis `flask`/`flask-cors`/`requests`) et purge les
chemins absolus hérités d’un autre PC. Utilisez `--no-install` pour ne toucher
qu’aux chemins.

Variables utiles : `QE_BIN`, `GEN_PORT`, `ONCVPSP_BIN`, `GEN_PSEUDOS_INSTALL`, `SKIP_LEGACY_API=1`.

---

## Scripts (liste utile uniquement)

### À la racine — usage courant

| Script | Rôle |
|--------|------|
| **`generation_pseudos`** | Fichier unique (après `./build_installer.sh`) — install + config + démarrage |
| **`GenerationPseudos`** | Lanceur dans le dossier projet |
| **`build_installer.sh`** | Construit `dist/generation_pseudos` |
| **`configure.sh`** | Configure ce PC (`api_config.json`, dossiers, binaires QE/ONCV/…) |
| **`DEMARRER.sh`** | Démarre l’API (port 5008) |
| **`GENERER_PSEUDOS.sh`** | Génère + vérifie la conformité des pseudos (4 générateurs) |
| **`ARRETER.sh`** | Arrête l’API |
| **`verifier_installation.sh`** | Diagnostic complet sur ce PC |
| **`TELECHARGER_BASES.sh`** | Télécharge les bibliothèques UPF |
| **`emballer.sh`** | Compacter le projet en `dist/*.tar.gz` (défaut : mode léger, `bin/` + `lib/` inclus, autonomie vérifiée) |
| **`TRANSFERER_VERS_AUTRE_PC.sh`** | Archive + envoi réseau vers un autre PC |

### Dans `scripts/` — maintenance

| Script | Rôle |
|--------|------|
| `scripts/RELANCER.sh` | Redémarre l’API si version obsolète |
| `scripts/emballer.sh` | Compacter en `dist/*.tar.gz` |
| `scripts/TRANSFERT_AUTRE_PC.sh` | Alias (mode complet par défaut) |
| `scripts/install_ape_atompaw.sh` | Compile APE / ATOMPAW dans `third_party/` |
| `scripts/install_bibliotheques_pseudos.sh` | Installe l’arborescence bibliothèques |
| `scripts/telecharger_lanthanides_nc.sh` | Gabarits lanthanides |
| `scripts/nettoyer_projet.sh` | Nettoie `_work/`, caches |
| `scripts/install_lanceur_bureau.sh` | Raccourci bureau |

Scripts supprimés (doublons) : `DEPLOYER_AUTRE_PC.sh`, `CONFIGURER.sh`, `INSTALLER.sh`, `EXPORTER_MINIMAL.sh` — remplacés par `configure.sh`, `GenerationPseudos` ou `build_installer.sh`. `config_pc.sh` = alias de `configure.sh`.

---

## Dépannage sur un autre PC

| Problème | Cause fréquente | Action |
|----------|-----------------|--------|
| « API hors ligne » / port 5007 | Ancienne config navigateur | `./configure.sh` puis `./DEMARRER.sh` et **Ctrl+F5** |
| Page blanche / pas de tableau | Ouverture en `file://` | Utiliser http://127.0.0.1:5008/ |
| Chemins `/home/hiadsi/...` | localStorage ou `api_config.json` d’un autre PC | Ctrl+F5 ; `./configure.sh` (écrit des chemins relatifs) |
| Prérequis manquants (curl, lsof, navigateur, flask) | PC vierge | `./configure.sh` (installe via sudo si possible) |
| `bin/ape` ou `bin/atompaw` en lien cassé | Archive copiée sans `third_party/` | `bash scripts/install_ape_atompaw.sh` puis `./configure.sh` |
| Flask / pip refusé (Ubuntu 24+) | PEP 668 | `./configure.sh` (corrige automatiquement) |
| ld1.x introuvable | QE non installé sur ce PC | Installer QE puis `./configure.sh --qe /chemin/bin` |
| APE / ATOMPAW absents | Non compilés | `bash scripts/install_ape_atompaw.sh` |

---

## Téléchargement des bibliothèques externes

```bash
./TELECHARGER_BASES.sh --quick
./TELECHARGER_BASES.sh --all
```

Ou via l’onglet **Autres bases** dans l’interface web.

---

## Nettoyage local

```bash
./scripts/nettoyer_projet.sh
./scripts/nettoyer_projet.sh --work-only
```

---

## Architecture

```
Navigateur → http://127.0.0.1:5008/
        ↕
api_pseudos_standalone.py (Flask + fichiers statiques)
        ↕
QE (ld1.x) · ONCVPSP · APE · ATOMPAW  (installés sur la machine)
        ↓
pseudos-ld1/ · pseudos-APE/ · pseudos-atompaw/ · pseudos-oncvpsp/
```

---

## Prérequis

- Python 3 + `flask`, `flask-cors` (installés auto si besoin)
- Quantum ESPRESSO (`pw.x`, `ld1.x` pour l’onglet ld1)
- ONCVPSP / APE / ATOMPAW : optionnels selon l’onglet

---

## Dépannage

| Problème | Action |
|----------|--------|
| Premier lancement sur nouveau PC | `./configure.sh` puis `./DEMARRER.sh` (ou `./generation_pseudos`) |
| Chemins incorrects / port 5007 | `./configure.sh` puis **Ctrl+F5** dans le navigateur |
| API hors ligne | `./DEMARRER.sh` — `lsof -i:5008` |
| CSS / tableau absent | URL `http://127.0.0.1:5008/`, pas `file://` |
| `ld1.x` introuvable | `./configure.sh --qe /chemin/qe/bin` |
| ONCV / APE / ATOMPAW absents | Installer binaire, puis `--reconfig` |
| Désinstaller le fichier unique | `./generation_pseudos --uninstall` |
| Diagnostic complet | `./verifier_installation.sh` |

Logs (dossier projet) : `logs/api_pseudos_standalone.log`  
Logs (fichier unique) : `~/.local/share/generation_pseudos/app/logs/api_pseudos_standalone.log`

---

Prof. S. Hiadsi — LMESM, USTO-MB — said.hiadsi@univ-usto.dz

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import subprocess
from pathlib import Path
import re

def extract_element_name(filename):
    """Extrait le symbole chimique à partir du nom du fichier UPF (ex: Gd_oncv.UPF -> Gd)."""
    base = Path(filename).stem
    # Nettoie les suffixes courants (ex: _oncv, _pbe, _v1)
    element = re.split(r'[_-]', base)[0]
    return element

def run_single_test(upf_path, pw_executable="pw.x", work_dir="./pseudo_test_tmp"):
    """
    Lance un calcul SCF d'atome isolé pour tester la validité du pseudopotentiel.
    """
    work_path = Path(work_dir)
    work_path.mkdir(parents=True, exist_ok=True)
    
    upf_file = Path(upf_path).resolve()
    if not upf_file.exists():
        return {"file": upf_file.name, "status": "ERROR", "msg": "Fichier UPF introuvable."}
    
    element = extract_element_name(upf_file.name)
    
    # Nommage des fichiers de travail
    dest_upf = work_path / upf_file.name
    if not dest_upf.exists():
        os.symlink(upf_file, dest_upf)
        
    input_content = f"""
&CONTROL
  calculation     = 'scf'
  prefix          = 'test_{element}'
  pseudo_dir      = './'
  outdir          = './out_{element}'
  verbosity       = 'high'
/
&SYSTEM
  ibrav           = 1
  celldm(1)       = 25.0
  nat             = 1
  ntyp            = 1
  ecutwfc         = 50.0
  ecutrho         = 200.0
  ! nspin=2 + occupations fixed exige tot_magnetization (QE >= ~7.x).
  ! Pour un atome isolé (couches ouvertes), smearing est plus robuste.
  occupations     = 'smearing'
  smearing        = 'gaussian'
  degauss         = 0.02
  nspin           = 2
  starting_magnetization(1) = 0.5
/
&ELECTRONS
  conv_thr        = 1.0d-6
  electron_maxstep= 100
/
ATOMIC_SPECIES
  {element}  1.0  {upf_file.name}
ATOMIC_POSITIONS crystal
  {element}  0.0  0.0  0.0
K_POINTS gamma
"""
    
    input_file = work_path / f"test_{element}.in"
    output_file = work_path / f"test_{element}.out"
    input_file.write_text(input_content.strip())
    
    # Exécution de pw.x
    cmd = f"{pw_executable} -in {input_file.name} > {output_file.name}"
    try:
        result = subprocess.run(
            cmd, shell=True, cwd=work_path, 
            capture_output=True, text=True, timeout=60
        )
        
        if not output_file.exists():
            return {"file": upf_file.name, "status": "FAILED", "msg": "Pas de fichier de sortie généré."}
            
        out_text = output_file.read_text()
        
        # Analyse du fichier de sortie
        if "JOB DONE" in out_text:
            return {"file": upf_file.name, "status": "SUCCESS", "msg": "Calcul SCF convergé avec succès."}
        elif "convergence NOT achieved" in out_text:
            return {"file": upf_file.name, "status": "WARNING", "msg": "Non convergence en 100 étapes."}
        elif any(err in out_text.lower() for err in ["error", "fatal", "nan", "floating point exception"]):
            return {"file": upf_file.name, "status": "FAILED", "msg": "Erreur critique ou instabilité numérique détectée."}
        else:
            return {"file": upf_file.name, "status": "UNKNOWN", "msg": "Fin anormale ou statut incertain."}
            
    except subprocess.TimeoutExpired:
        return {"file": upf_file.name, "status": "TIMEOUT", "msg": "Dépassement du temps limite (60s)."}
    except Exception as e:
        return {"file": upf_file.name, "status": "ERROR", "msg": str(e)}

def batch_test_directory(pseudos_dir, pw_executable="pw.x"):
    """Parcourt un répertoire et teste tous les fichiers .UPF trouvés."""
    p_dir = Path(pseudos_dir)
    upf_files = list(p_dir.glob("*.UPF")) + list(p_dir.glob("*.upf"))
    
    if not upf_files:
        print(f"Aucun fichier UPF trouvé dans {pseudos_dir}")
        return
        
    print(f"--- Début des tests pour {len(upf_files)} pseudopotentiel(s) ---")
    results = []
    
    for upf in upf_files:
        print(f"Test en cours : {upf.name} ... ", end="", flush=True)
        res = run_single_test(upf, pw_executable=pw_executable)
        results.append(res)
        print(f"[{res['status']}] -> {res['msg']}")
        
    print("\n=== RAPPORT FINAL DE VALIDATION ===")
    for r in results:
        print(f" - {r['file']:<20} : {r['status']:<10} ({r['msg']})")

if __name__ == "__main__":
    # Dossier contenant vos pseudopotentiels (ex: le vôtre)
    TARGET_DIR = sys.argv[1] if len(sys.argv) > 1 else "/home/hiadsi/Phase/SQS-QE/pseudos"
    PW_BIN = sys.argv[2] if len(sys.argv) > 2 else "pw.x"
    
    batch_test_directory(TARGET_DIR, pw_executable=PW_BIN)

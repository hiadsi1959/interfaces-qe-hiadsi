#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Génération + conformité des pseudos pour les 4 générateurs, en une commande.

Objectif : qu'un utilisateur obtienne, sans knowledge préalable, des pseudos
CONFORMES pour ONCVPSP · ld1.x · APE · ATOMPAW, et un rapport clair.

Principe : pour chaque élément, l'API expose les 4 entrées cohérentes
(/api/pseudos/auto_inputs), puis chaque générateur est lancé par son endpoint
standard — exactement la chaîne utilisée par l'interface graphique. Le pseudo
produit est ensuite contrôlé localement (UPF lisible, élément, z_valence,
type), d'où un critère de conformité unique et vérifiable.

  # 1. démarrer l'API si besoin :  ./DEMARRER.sh
  # 2. générer + vérifier :
  python3 tools/generer_pseudos_conformes.py --elements Si La
  python3 tools/generer_pseudos_conformes.py --elements tous --generateurs oncvpsp
  python3 tools/generer_pseudos_conformes.py --elements "Cr Fe Ni" --report dist/rapport.json
  python3 tools/generer_pseudos_conformes.py --elements tous --resume dist/rapport.json

Code de sortie : 0 si tous les pseudos demandés sont conformes, 1 sinon.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

API_DEFAULT = "http://127.0.0.1:5008"
TIMEOUT = 420

GENERATEURS = {
    "oncvpsp": {"route": "/api/pseudos/run_oncvpsp", "cle_entree": "oncv_input_dat", "extra": {}},
    "ld1": {"route": "/api/pseudos/generer_ld1", "cle_entree": "ld1_input", "extra": {}},
    "ape": {"route": "/api/pseudos/run_ape", "cle_entree": "ape_input", "extra": {"xc": "lda_pw"}},
    "atompaw": {"route": "/api/pseudos/run_atompaw", "cle_entree": "atompaw_input",
                "extra": {"format": "interactive"}},
}

GROUPES = {
    "3d": ["Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn"],
    "4d": ["Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd"],
    "5d": ["Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg"],
    "lanthanides": ["La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy",
                    "Ho", "Er", "Tm", "Yb", "Lu"],
    "actinides": ["Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf",
                  "Es", "Fm", "Md", "No", "Lr"],
}


# ─── HTTP ────────────────────────────────────────────────────────────────────
def http_get(api: str, chemin: str) -> tuple[int, str]:
    with urllib.request.urlopen(api + chemin, timeout=90) as r:
        return r.status, r.read().decode("utf-8", errors="replace")


def http_post(api: str, chemin: str, corps: dict, timeout: int) -> tuple[int, dict]:
    data = json.dumps(corps).encode("utf-8")
    req = urllib.request.Request(
        api + chemin, data=data, method="POST",
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        brut = r.read().decode("utf-8", errors="replace")
    try:
        return r.status, json.loads(brut)
    except json.JSONDecodeError:
        return r.status, {"_raw": brut[:2000]}


# ─── Conformité d'un pseudo produit ──────────────────────────────────────────
def _flt(v) -> float:
    try:
        return float(str(v).replace("D", "E").replace("d", "e"))
    except (TypeError, ValueError):
        return 0.0


def _entete_xml(txt: str) -> dict:
    """Entête d'un pseudo XML : UPF v2 (<UPF>) ou APE/ABINIT (<PP_HEADER>)."""
    if "<UPF version" in txt:
        bloc = re.search(r"<UPF[\s\S]*", txt)
        try:
            root = ET.fromstring(bloc.group(0))
        except ET.ParseError as e:
            return {"format": "UPF v2", "erreur": f"XML invalide : {e}"}
        hdr = root.find("PP_HEADER")
        a = hdr.attrib if hdr is not None else {}
        return {
            "format": "UPF v2",
            "element": a.get("element", ""),
            "z_valence": _flt(a.get("z_valence")),
            "type": (a.get("pseudo_type") or "").upper(),
            "complet": "</UPF>" in txt,
            "blocs": [b for b in ("PP_NONLOCAL", "PP_LOCAL", "PP_MESH", "PP_DIJ")
                      if f"<{b}" not in txt],
        }
    # APE / ABINIT : <PP_INFO> + <PP_HEADER> en texte balisé
    m_el = re.search(r"^\s*([A-Za-z]{1,2})\s+Element\s*$", txt, re.M)
    m_z = re.search(r"^\s*([-\d.eEdD+]+)\s+Z valence\s*$", txt, re.M)
    m_ty = re.search(r"^\s*(NC|US|PAW)\b", txt, re.M)
    lignes = [l for l in txt.splitlines() if l.strip()]
    return {
        "format": "APE/ABINIT (XML)",
        "element": m_el.group(1) if m_el else "",
        "z_valence": _flt(m_z.group(1)) if m_z else 0.0,
        "type": m_ty.group(1).upper() if m_ty else "",
        "complet": bool(lignes) and lignes[-1].strip().startswith("</PP_"),
        "blocs": [],
    }


def valider_pseudo(chemin: str | Path, element: str) -> dict:
    """Critère unique de conformité, valable pour les 4 générateurs.

    Formats acceptés : UPF v2 (XML), UPF v1 (« Begin PSP_UPF »),
    APE/ABINIT XML (<PP_INFO>/<PP_HEADER>, produit par APE).
    """
    p = Path(chemin)
    if not p.is_file():
        return {"conforme": False, "raison": "fichier absent"}
    if p.stat().st_size == 0:
        return {"conforme": False, "raison": "fichier vide"}
    txt = p.read_text(encoding="utf-8", errors="replace")

    if txt.lstrip().startswith("Begin PSP_UPF"):  # UPF v1
        m_el = re.search(r'element\s*=\s*"?([A-Za-z]{1,2})', txt)
        ok = bool(m_el) and m_el.group(1).capitalize() == element.capitalize()
        return {"conforme": ok, "format": "UPF v1", "element": m_el.group(1) if m_el else "",
                "raison": "" if ok else f"élément {m_el.group(1) if m_el else '?'} ≠ {element}"}

    if "<UPF version" not in txt and "<PP_HEADER>" not in txt:
        return {"conforme": False, "raison": "format pseudo non reconnu (UPF/ABINIT absent)"}

    e = _entete_xml(txt)
    if e.get("erreur"):
        return {"conforme": False, "raison": e["erreur"]}
    pb: list[str] = []
    if e["element"].capitalize() != element.capitalize():
        pb.append(f"élément {e['element'] or '?'} ≠ {element}")
    if e["z_valence"] <= 0:
        pb.append("z_valence ≤ 0")
    if e["type"] not in ("NC", "US", "PAW"):
        pb.append(f"type inattendu ({e['type'] or '?'})")
    if not e["complet"]:
        pb.append("fichier tronqué (balise finale absente)")
    for b in e["blocs"]:
        pb.append(f"{b} manquant")
    return {"conforme": not pb, "format": e["format"], "element": e["element"],
            "z_valence": e["z_valence"], "type": e["type"], "raison": " ; ".join(pb)}


# ─── Génération ──────────────────────────────────────────────────────────────
def resoudre_elements(valeurs: list[str]) -> list[str]:
    out: list[str] = []
    for v in valeurs:
        v = v.strip()
        if not v:
            continue
        if v.lower() in ("tous", "all", "*"):
            from pseudo_auto_inputs import _PERIODIC_SYMBOLS

            out.extend(_PERIODIC_SYMBOLS)
        elif v.lower() in GROUPES:
            out.extend(GROUPES[v.lower()])
        else:
            out.extend(v.replace(",", " ").split())
    vus: set[str] = set()
    propres: list[str] = []
    for s in out:
        s = s.strip().capitalize()
        if s and s not in vus:
            vus.add(s)
            propres.append(s)
    return propres


def generer_un(api: str, element: str, generateur: str, timeout: int) -> dict:
    spec = GENERATEURS[generateur]
    t0 = time.time()
    try:
        _c, brut = http_get(api, f"/api/pseudos/auto_inputs?element={element}")
        entrees = json.loads(brut)
    except Exception as e:  # noqa: BLE001
        return {"element": element, "generateur": generateur, "ok": False,
                "error": f"auto_inputs : {e}", "duree_s": round(time.time() - t0, 1)}
    contenu = (entrees.get(spec["cle_entree"]) or "").strip()
    if not contenu:
        return {"element": element, "generateur": generateur, "ok": False,
                "error": f"entrée « {spec['cle_entree']} » absente", "duree_s": round(time.time() - t0, 1)}
    corps = {"element": element, "input": contenu, **spec["extra"]}
    try:
        _code, j = http_post(api, spec["route"], corps, timeout)
    except urllib.error.URLError as e:
        return {"element": element, "generateur": generateur, "ok": False,
                "error": f"HTTP : {e}", "duree_s": round(time.time() - t0, 1)}
    upf = j.get("upf_path") or j.get("upf_genere")
    res = {
        "element": element, "generateur": generateur,
        "ok": bool(j.get("success")), "upf": upf,
        "returncode": j.get("returncode"),
        "error": j.get("error") or j.get("hint"),
        "duree_s": round(time.time() - t0, 1),
    }
    if upf:
        res["conformite"] = valider_pseudo(upf, element)
        res["ok"] = res["ok"] and res["conformite"]["conforme"]
        res["statut"] = "conforme" if res["ok"] else "non_conforme"
    elif j.get("psp8_in_stdout"):
        res["conformite"] = {"conforme": False,
                             "raison": "psp8 dans stdout, pas de pseudo sur disque"}
        res["ok"] = False
        res["statut"] = "non_conforme"
    else:
        # rien produit : limite connue du code pour cet élément (4f, 3d, …)
        res["conformite"] = {"conforme": False, "raison": "aucun fichier pseudo retourné"}
        res["ok"] = False
        res["statut"] = "echec_generateur"
    return res


def preflight(api: str) -> tuple[list[str], list[str]]:
    """Vérifie l'API (bloquant) et les gabarits (bloquant si contrôlable)."""
    bloquants: list[str] = []
    notes: list[str] = []
    try:
        code, _ = http_get(api, "/health")
        if code != 200:
            bloquants.append(f"API /health → {code}")
    except Exception as e:  # noqa: BLE001
        bloquants.append(f"API injoignable sur {api} ({e}) — lancez ./DEMARRER.sh")
        return bloquants, notes
    try:
        sys.path.insert(0, str(ROOT / "tests"))
        import verifier_entetes_gabarits as veg

        errs: list[str] = []
        for f in veg.iter_templates():
            errs.extend(veg.check_file(f))
        if errs:
            bloquants.append(
                f"{len(errs)} gabarit(s) non conforme(s) — voir tests/verifier_entetes_gabarits.py"
            )
    except Exception as e:  # noqa: BLE001
        notes.append(f"contrôle des gabarits ignoré ({e})")
    return bloquants, notes


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--api", default=API_DEFAULT)
    ap.add_argument("--elements", nargs="+", required=True,
                    help="symboles, groupe (3d, 4d, 5d, lanthanides, actinides) ou « tous »")
    ap.add_argument("--generateurs", nargs="+", default=list(GENERATEURS),
                    choices=list(GENERATEURS))
    ap.add_argument("--report", default="dist/rapport_conformite.json")
    ap.add_argument("--resume", action="store_true",
                    help="réutiliser les succès déjà présents dans --report")
    ap.add_argument("--timeout", type=int, default=TIMEOUT)
    ap.add_argument("--stop-on-error", action="store_true")
    ap.add_argument("--skip-preflight", action="store_true")
    args = ap.parse_args()

    elements = resoudre_elements(args.elements)
    if not elements:
        print("Aucun élément.", file=sys.stderr)
        return 1
    rapport_path = Path(args.report)
    rapport_path = rapport_path if rapport_path.is_absolute() else ROOT / rapport_path
    anciens: dict[str, dict] = {}
    if args.resume and rapport_path.is_file():
        try:
            anciens = {r["cle"]: r for r in json.loads(rapport_path.read_text()).get("resultats", [])}
        except Exception:  # noqa: BLE001
            anciens = {}

    if not args.skip_preflight:
        bloquants, notes = preflight(args.api)
        if bloquants:
            print("Pré-contrôle : ÉCHEC")
            for p in bloquants:
                print(f"  ✗ {p}")
            return 1
        print("Pré-contrôle : OK (API en ligne, gabarits conformes)")
        for n in notes:
            print(f"  (info) {n}")

    print(f"\n{elements.__len__()} élément(s) × {len(args.generateurs)} générateur(s) "
          f"= {len(elements) * len(args.generateurs)} pseudo(s) demandé(s)")
    print("=" * 78)

    resultats: list[dict] = []
    echecs: list[dict] = []
    for el in elements:
        ligne = [f"{el:>3}"]
        for gen in args.generateurs:
            cle = f"{el}|{gen}"
            if cle in anciens and anciens[cle].get("ok"):
                r = anciens[cle]
                r["reprise"] = True
            else:
                r = generer_un(args.api, el, gen, args.timeout)
                r["cle"] = cle
            resultats.append(r)
            if r.get("ok"):
                ligne.append(f"{gen}:OK")
            else:
                ligne.append(f"{gen}:KO")
                echecs.append(r)
                if args.stop_on_error:
                    print("  ".join(ligne))
                    _ecrire_rapport(rapport_path, resultats, echecs, args)
                    return 1
        print("  ".join(ligne))
        # rapport intermédiaire (reprise possible si interruption)
        _ecrire_rapport(rapport_path, resultats, echecs, args)

    print("=" * 78)
    conformes = sum(1 for r in resultats if r.get("ok"))
    gen_ko = [r for r in echecs if r.get("statut") == "echec_generateur"]
    non_conf = [r for r in echecs if r.get("statut") != "echec_generateur"]
    print(f"Conformes : {conformes}/{len(resultats)} — "
          f"produits non conformes : {len(non_conf)} — échecs générateur : {len(gen_ko)}")
    if non_conf:
        print("\nPseudos produits mais NON conformes (à corriger) :")
        for r in non_conf:
            raison = (r.get("conformite") or {}).get("raison") or r.get("error") or ""
            print(f"  - {r['element']}/{r['generateur']} : {str(raison)[:160]}")
    if gen_ko:
        print("\nÉchecs générateur (limite du code pour cet élément — pas un pseudo invalide) :")
        for r in gen_ko:
            print(f"  - {r['element']}/{r['generateur']} : {str(r.get('error') or '')[:160]}")
    print(f"\nRapport JSON : {rapport_path}")
    # code non nul dès qu'un pseudo demandé n'est pas conforme (détail dans le JSON)
    return 1 if echecs else 0


def _ecrire_rapport(path: Path, resultats: list[dict], echecs: list[dict], args) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({
        "api": args.api,
        "generateurs": args.generateurs,
        "total": len(resultats),
        "conformes": sum(1 for r in resultats if r.get("ok")),
        "echecs": len(echecs),
        "resultats": resultats,
    }, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())

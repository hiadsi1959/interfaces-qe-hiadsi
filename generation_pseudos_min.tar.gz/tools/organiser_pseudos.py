#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Organisateur des dossiers de sortie par générateur.

Chaque pseudo généré doit vivre dans le dossier de son générateur :
  - pseudos-ld1/         ← ld1.x / code « atomic » (QE) — sorties locales
  - pseudos-APE/         ← APE
  - pseudos-atompaw/     ← ATOMPAW
  - pseudos-oncvpsp/     ← ONCVPSP
  - pseudos-telecharges/ ← bibliothèques importées (PseudoDojo, PSLibrary…)

Le module classe chaque UPF par son producteur réel (marqueurs dans le
fichier : ONCVPSP / ATOMPAW / APE / atomic-ld1) complétés par les motifs
de nommage. Les bases standard PSLibrary (*.pbe-nc/us/paw.UPF) vont dans
pseudos-telecharges/ — même si une session ld1 les a copiées ailleurs.

Sécurité :
  - jamais d'écrasement : destination identique (md5) → dédoublonnage
    (source supprimée) ; destination différente → <bucket>/_doublons/ ;
  - artefacts de test à la racine (ld1.wfc, vx.pot, dummy…) → archive/root_misc/ ;
  - dry-run par défaut : python3 tools/organiser_pseudos.py [--apply]

Utilisable depuis l'API : api_pseudos_standalone.route
POST /api/pseudos/generators/organize {"apply": true}
"""
from __future__ import annotations

import argparse
import hashlib
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

BUCKETS: dict[str, str] = {
    "ld1": "pseudos-ld1",
    "ape": "pseudos-APE",
    "atompaw": "pseudos-atompaw",
    "oncvpsp": "pseudos-oncvpsp",
    "telecharges": "pseudos-telecharges",
}
DOUBLONS = "_doublons"
ARCHIVE_MISC = ROOT / "archive" / "root_misc"

# Artefacts de travail ld1/oncvpsp à la racine (jamais utiles à l'UI)
ROOT_JUNK: tuple[str, ...] = (
    "ld1.wfc", "ld1ps.wfc", "ld1.test", "vx.pot", "dummy",
    "input_tmp.in", "parser.log", "tmp_test_ge.UPF",
)

# Bases standard PSLibrary / QE (nommage officiel atomic-3.x)
_PSL_NAME = re.compile(
    r"\.[A-Za-z0-9]+-(?:nc|us|paw)(?:_[A-Za-z0-9]+)?\.UPF$", re.I
)
_ONCV_NAME = re.compile(r"_oncv\.UPF$", re.I)
_PAW_NAMED = re.compile(r"\.(?:GGA|LDA)-[A-Za-z0-9+-]+-paw\.UPF$", re.I)


def _md5(path: Path) -> str:
    h = hashlib.md5()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def producer_of(upf: Path) -> str:
    """Détecte le générateur producteur via les marqueurs du fichier."""
    try:
        head = upf.open("rb").read(6000).decode("latin-1", errors="replace")
    except OSError:
        return "unknown"
    low = head.lower()
    if "oncvpsp" in low or "hamann" in low:
        return "oncvpsp"
    if "atompaw" in low:
        return "atompaw"
    if "ape" in low and ("paw" in low or "abinit" in low or "gonze" in low):
        return "ape"
    if 'generated using "atomic"' in low or "a. dal corso" in low:
        return "ld1"
    return "unknown"


def classify(upf: Path) -> str | None:
    """Bucket cible de l'UPF, ou None si déjà bien classé / indéterminable."""
    name = upf.name
    prod = producer_of(upf)
    # 1. Nommage explicite
    if _ONCV_NAME.search(name):
        return BUCKETS["oncvpsp"] if prod in ("oncvpsp", "unknown") else BUCKETS[prod]
    # 2. Bases standard PSLibrary → bibliothèque téléchargée
    if _PSL_NAME.search(name):
        return BUCKETS["telecharges"]
    # 3. Producteur identifiable
    if prod in BUCKETS:
        return BUCKETS[prod]
    if _PAW_NAMED.search(name):
        return BUCKETS["atompaw"]
    return None


def _place(src: Path, dest_dir: Path, actions: list[dict]) -> None:
    """Déplace src vers dest_dir sans écraser (dédoublonnage / _doublons)."""
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / src.name
    rec: dict[str, str] = {"file": src.name, "from": str(src.parent.relative_to(ROOT))}
    if dest.resolve() == src.resolve():
        return
    if dest.is_file():
        if _md5(dest) == _md5(src):
            src.unlink()
            rec.update(action="dedup", to=str(dest_dir.relative_to(ROOT)))
        else:
            alt = dest_dir / DOUBLONS / src.name
            alt.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src), str(alt))
            rec.update(action="moved_to_doublons", to=str(alt.relative_to(ROOT)))
    else:
        shutil.move(str(src), str(dest))
        rec.update(action="moved", to=str(dest_dir.relative_to(ROOT)))
    actions.append(rec)


def organize(root: Path = ROOT, apply: bool = False) -> dict:
    """Classe les UPF égarés + nettoie les artefacts racine. Dry-run si not apply."""
    root = Path(root).resolve()
    actions: list[dict] = []
    scanned = 0

    # 1. Racine du projet : UPF égarés + artefacts de test
    for upf in sorted(root.glob("*.UPF")) + sorted(root.glob("*.upf")):
        scanned += 1
        bucket = classify(upf)
        if bucket:
            rec = {"file": upf.name, "from": "."}
            dest_dir = root / bucket
            if apply:
                _place(upf, dest_dir, actions)
            else:
                rec.update(action="would_move", to=bucket)
                actions.append(rec)
    for name in ROOT_JUNK:
        junk = root / name
        if junk.is_file() or (junk.exists() and junk.stat().st_size == 0):
            rec = {"file": name, "from": ".", "action": "archive"}
            if apply:
                ARCHIVE_MISC.mkdir(parents=True, exist_ok=True)
                shutil.move(str(junk), str(ARCHIVE_MISC / name))
                rec["to"] = str(ARCHIVE_MISC.relative_to(root))
            else:
                rec["to"] = str(ARCHIVE_MISC.relative_to(root))
                rec["action"] = "would_archive"
            actions.append(rec)

    # 2. Dossiers générateurs : retirer ce qui n'appartient pas au générateur
    for gen, sub in BUCKETS.items():
        if gen == "telecharges":
            continue  # bibliothèque : on ne re-trie pas (organize_libraries s'en charge)
        bucket_dir = root / sub
        if not bucket_dir.is_dir():
            continue
        for upf in sorted(bucket_dir.glob("*.UPF")) + sorted(bucket_dir.glob("*.upf")):
            scanned += 1
            target = classify(upf)
            if target and target != sub:
                rec = {"file": upf.name, "from": sub}
                if apply:
                    _place(upf, root / target, actions)
                else:
                    rec.update(action="would_move", to=target)
                    actions.append(rec)

    return {
        "root": str(root),
        "scanned": scanned,
        "applied": bool(apply),
        "n_actions": len(actions),
        "actions": actions,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
    }


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Range les pseudos par générateur.")
    ap.add_argument("--apply", action="store_true",
                    help="exécute réellement (sinon simple simulation)")
    args = ap.parse_args(argv)
    rep = organize(apply=args.apply)
    mode = "APPLY" if rep["applied"] else "DRY-RUN (--apply pour exécuter)"
    print(f"Organisateur pseudos — {mode} — {rep['scanned']} fichiers scannés, "
          f"{rep['n_actions']} action(s)")
    for a in rep["actions"]:
        print(f"  {a.get('action','?'):<18} {a['file']:<28} {a['from']} → {a.get('to','?')}")
    if not rep["actions"]:
        print("  Rien à faire — tous les pseudos sont déjà dans le bon dossier.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

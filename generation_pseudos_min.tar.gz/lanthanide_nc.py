# -*- coding: utf-8 -*-
"""
Pseudopotentiels Norm-Conserving (ONCVPSP / ld1.x) pour les lanthanides (Z 57–71).

Méthodologie :
  - ``open_core`` : électrons 4f gelés dans le cœur (inertes, pseudo plus doux).
  - ``valence_f`` : 4f actifs en valence (magnétisme, DFT+U souvent requis).
  - r_c(4f) recommandé : 1.8–2.3 bohr ; relativité forte recommandée.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

LANTHANIDE_SYMBOLS: tuple[str, ...] = (
    "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy",
    "Ho", "Er", "Tm", "Yb", "Lu",
)

# Valence avec 4f actifs (référence ld1 / chimie)
_VALENCE_F: dict[str, str] = {
    "La": "5d1 6s2",
    "Ce": "4f1 5d1 6s2",
    "Pr": "4f3 6s2",
    "Nd": "4f4 6s2",
    "Pm": "4f5 6s2",
    "Sm": "4f6 6s2",
    "Eu": "4f7 6s2",
    "Gd": "4f7 5d1 6s2",
    "Tb": "4f9 6s2",
    "Dy": "4f10 6s2",
    "Ho": "4f11 6s2",
    "Er": "4f12 6s2",
    "Tm": "4f13 6s2",
    "Yb": "4f14 6s2",
    "Lu": "5d1 6s2",  # 4f14 dans le cœur
}

# Valence « open core » : 4f gelé dans le cœur ; 5s/5p en semi-cœur (recommandé NC)
_OPEN_CORE: dict[str, str] = {
    "La": "5s2 5p6 5d1 6s2",
    "Ce": "5s2 5p6 5d1 6s2",
    "Pr": "5s2 5p6 6s2",
    "Nd": "5s2 5p6 6s2",
    "Pm": "5s2 5p6 6s2",
    "Sm": "5s2 5p6 6s2",
    "Eu": "5s2 5p6 6s2",
    "Gd": "5s2 5p6 5d1 6s2",
    "Tb": "5s2 5p6 6s2",
    "Dy": "5s2 5p6 6s2",
    "Ho": "5s2 5p6 6s2",
    "Er": "5s2 5p6 6s2",
    "Tm": "5s2 5p6 6s2",
    "Yb": "5s2 5p6 6s2",
    "Lu": "5s2 5p6 5d1 6s2",
}

# Défaut ONCVPSP par élément (stabilité sratom / 4f) — pas une vérité physique universelle
_ONCV_DEFAULT_FT: dict[str, str] = {
    "La": "valence_f",   # pas de 4f en valence chimique
    "Ce": "open_core",   # 4f1 souvent fragile en ONCV scalaire
    "Pr": "open_core",
    "Nd": "open_core",
    "Pm": "open_core",
    "Sm": "open_core",
    "Eu": "open_core",
    "Gd": "open_core",   # thermo OK ; magnétisme → valence_f + U
    "Tb": "open_core",
    "Dy": "open_core",   # typique : lschfb n,l=4,3
    "Ho": "open_core",
    "Er": "open_core",
    "Tm": "open_core",
    "Yb": "open_core",
    "Lu": "valence_f",   # 4f14 déjà hors valence
}

# Recommandation selon le type de calcul / problème
_PROBLEM_FT: dict[str, str] = {
    "thermo": "open_core",
    "thermo_pw": "open_core",
    "elastic": "open_core",
    "phonon": "open_core",
    "qha": "open_core",
    "optics": "open_core",
    "optical": "open_core",
    "dielectric": "open_core",
    "structure": "open_core",
    "relax": "open_core",
    "scf": "open_core",
    "generation": "auto",       # → default_oncv_f_treatment(sym)
    "oncv": "auto",
    "oncvpsp": "auto",
    "magnetism": "valence_f",
    "magnetic": "valence_f",
    "moment": "valence_f",
    "moments": "valence_f",
    "dft_u": "valence_f",
    "hubbard": "valence_f",
    "spin": "valence_f",
}

_ELEMENT_NOTES: dict[str, str] = {
    "La": "Peu/pas de 4f actif — valence 5d/6s ; ONCV généralement OK.",
    "Ce": "4f1 : open-core pour structure/thermo ; valence_f + U pour valence mixte / magnétisme.",
    "Pr": "4f localisé — open-core recommandé pour ONCV ; valence_f fragile (sratom).",
    "Nd": "Idem Pr/Nd — open-core ONCV ; PseudoDojo si valence_f requis.",
    "Pm": "Radioactif / rare — open-core ONCV ; privilégier bibliothèque validée.",
    "Sm": "Open-core pour thermo ; valence_f + U si moments 4f.",
    "Eu": "Demi-rempli / divalent fréquent — open-core ONCV ; valence_f délicat.",
    "Gd": "4f7 : open-core thermo OK ; magnétisme → valence_f + DFT+U + spin.",
    "Tb": "Fin de série — open-core ONCV (échec lschfb 4f fréquent).",
    "Dy": "Typique échec sratom 4f — open-core par défaut ; Dojo/ld1 si 4f actifs.",
    "Ho": "Comme Dy — open-core ONCV recommandé.",
    "Er": "Comme Dy — open-core ONCV recommandé.",
    "Tm": "Comme Dy — open-core ONCV recommandé.",
    "Yb": "Souvent 4f14 cœur-like — open-core ; valence_f rare.",
    "Lu": "4f14 fermé — valence 5d/6s ; peu de problème 4f.",
}

# iexc ONCVPSP 4.0.1 : 1=Wigner, 2=Hedin-Lundqvist, 3=LDA-PZ, 4=PBE.
# PBE réelle → 4 (les vieux fichiers tests/data en 3 produisent du LDA-PZ).
# PBEsol : pas de code positif en 4.0.1 → code libxc -116133.
_ONCV_IEXC = {
    "lda_pw": 3,
    "lda_pz": 3,
    "gga_pbe": 4,
    "gga_pbesol": -116133,
    "pbe": 4,
    "pbesol": -116133,
}

_RC_F_DEFAULT = 2.05  # bohr, milieu de 1.8–2.3

# Gabarits PseudoDojo ONCVPSP-PBE-PDv0.4 (convergent pour Dy etc.)
_PSEUDODOJO_TPL_DIR = Path(__file__).resolve().parent / "oncv_templates_lanthanide"


def library_upf_hints(sym: str) -> list[dict[str, str]]:
    """UPF déjà présents dans pseudos/ (évite de régénérer Dy avec ONCV scalaire fragile)."""
    sym = _norm(sym)
    root = Path(__file__).resolve().parent / "pseudos"
    cands = [
        root / "Lanthanides_NC_PBE" / f"{sym}_{sym}3__f-in-core.UPF",
        root / "Lanthanides_NC_PBE" / f"{sym}_sp.UPF",
        root / "PseudoDojo_standard" / f"{sym}_ONCV_{sym}3__f-in-core.UPF",
        root / "PseudoDojo_standard" / f"{sym}_ONCV_sp.UPF",
        root / "SSSP_precision" / f"{sym}.GGA-PBE-paw-v1.0.UPF",
        root / "SSSP_efficiency" / f"{sym}.GGA-PBE-paw-v1.0.UPF",
    ]
    out: list[dict[str, str]] = []
    for p in cands:
        if p.is_file():
            tag = "f-in-core" if "f-in-core" in p.name else ("sp" if "_sp" in p.name or "ONCV_sp" in p.name else "paw")
            out.append({"path": str(p), "name": p.name, "variant": tag})
    return out


def load_pseudodojo_oncv_input(
    sym: str,
    f_treatment: str | None = None,
    *,
    prefer_open_core: bool | None = None,
) -> tuple[str | None, str | None]:
    """
    Charge un .in PseudoDojo local (oncv_templates_lanthanide/).
    Retourne (contenu, source_tag) ou (None, None).
    """
    sym = _norm(sym)
    ft = resolve_f_treatment(sym, f_treatment, None, for_oncv=True)
    if prefer_open_core is None:
        prefer_open_core = ft == "open_core"
    d = _PSEUDODOJO_TPL_DIR
    if not d.is_dir():
        return None, None
    order: list[Path] = []
    if prefer_open_core:
        order.extend(sorted(d.glob(f"{sym}_*{sym}3+_f-in-core.in")))
        order.extend(sorted(d.glob(f"{sym}_*3+_f-in-core.in")))
        order.extend(sorted(d.glob(f"{sym}_*-sp.in")))
    else:
        order.extend(sorted(d.glob(f"{sym}_*-sp.in")))
        order.extend(sorted(d.glob(f"{sym}_*3+_f-in-core.in")))
    # dédoublonner
    seen: set[str] = set()
    for p in order:
        key = str(p.resolve())
        if key in seen or not p.is_file():
            continue
        seen.add(key)
        try:
            raw = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if "# ATOM" not in raw and "atsym" not in raw.lower():
            continue
        tag = "pseudodojo_f_in_core" if "f-in-core" in p.name else "pseudodojo_sp"
        return raw, f"{tag}:{p.name}"
    return None, None


def is_lanthanide(sym: str) -> bool:
    s = (sym or "").strip()
    if len(s) == 1:
        key = s.upper()
    else:
        key = s[0].upper() + s[1:].lower()
    return key in LANTHANIDE_SYMBOLS


def normalize_f_treatment(mode: str | None) -> str:
    if mode is None or str(mode).strip() == "":
        return "auto"
    m = str(mode).strip().lower().replace("-", "_")
    if m in ("open", "open_core", "core", "frozen_f", "inert_f"):
        return "open_core"
    if m in ("auto", "default", "recommended"):
        return "auto"
    return "valence_f"


def default_oncv_f_treatment(sym: str) -> str:
    """Traitement 4f par défaut pour générer un .dat ONCVPSP (stabilité numérique)."""
    sym = _norm(sym)
    return _ONCV_DEFAULT_FT.get(sym, "open_core")


def normalize_problem(problem: str | None) -> str | None:
    if not problem:
        return None
    p = problem.strip().lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "thermopw": "thermo_pw",
        "optical_properties": "optics",
        "optique": "optics",
        "magnetisme": "magnetism",
        "phonons": "phonon",
        "elasticite": "elastic",
        "elasticity": "elastic",
    }
    return aliases.get(p, p)


def recommend_f_treatment(
    sym: str,
    problem: str | None = None,
    *,
    for_oncv: bool = True,
) -> dict[str, Any]:
    """
    Recommandation cas par cas : élément + type de problème.

    for_oncv=True → privilégie la stabilité ONCVPSP (open_core si fragile).
    """
    sym = _norm(sym)
    prob = normalize_problem(problem)
    note = _ELEMENT_NOTES.get(sym, "")
    oncv_default = default_oncv_f_treatment(sym)

    if prob and prob in _PROBLEM_FT:
        choice = _PROBLEM_FT[prob]
        if choice == "auto":
            ft = oncv_default
            reason = f"Génération ONCV : défaut {sym} → {ft} (stabilité sratom)."
        else:
            ft = choice
            reason = f"Problème « {prob} » → {ft}."
            if for_oncv and ft == "valence_f" and oncv_default == "open_core":
                reason += (
                    f" Attention : pour {sym}, ONCVPSP scalaire échoue souvent sur 4f "
                    f"(lschfb n,l=4,3) — open_core ou PseudoDojo/ld1 si valence_f requis."
                )
    else:
        if for_oncv:
            ft = oncv_default
            reason = f"Défaut ONCV pour {sym} → {ft} (stabilité sratom / lschfb 4f)."
        elif sym == "Yb":
            ft = "open_core"
            reason = "Défaut physique Yb : 4f14 cœur-like (open_core) ; valence_f seulement pour Yb³⁺ + U."
        else:
            # ATOMPAW / ld1 : 4f en valence (magnétisme, DFT+U). Lu : 4f14 déjà hors valence.
            ft = "valence_f"
            reason = f"Défaut physique pour {sym} → valence_f (4f actifs ; thermo → open_core)."
        if note:
            reason += f" {note}"

    ft = "open_core" if ft == "open_core" else "valence_f"
    return {
        "element": sym,
        "problem": prob,
        "f_treatment": ft,
        "oncv_default": oncv_default,
        "reason": reason.strip(),
        "element_note": note,
        "valence": valence_string(sym, ft),
        "alternatives": {
            "open_core": valence_string(sym, "open_core"),
            "valence_f": valence_string(sym, "valence_f"),
        },
        "fallback_if_sratom_4f": "open_core",
    }


def diagnose_oncv_4f_failure(log: str, sym: str | None = None) -> dict[str, Any] | None:
    """Détecte lschfb / sratom sur 4f et propose open_core."""
    import re

    if not log:
        return None
    m = re.search(
        r"lschfb\s+convergence\s+ERROR\s+n,l,iter=\s*(\d+)\s+(\d+)\s+(\d+)",
        log,
        re.I,
    )
    if not m:
        if re.search(r"sratom\d*.*ERROR|lschfb", log, re.I) and re.search(
            r"\b4\s+3\b|4f", log, re.I
        ):
            n, l, it = 4, 3, None
        else:
            return None
    else:
        n, l, it = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if not (n == 4 and l == 3):
        return {
            "is_4f": False,
            "n": n,
            "l": l,
            "iter": it,
            "title": f"Échec sratom (n={n}, l={l})",
            "suggestion": "Vérifiez la configuration AE / occupations ; sinon PseudoDojo.",
            "suggested_f_treatment": None,
        }
    sym_n = _norm(sym) if sym else None
    rec = recommend_f_treatment(sym_n or "Dy", "oncv", for_oncv=True) if sym_n else None
    return {
        "is_4f": True,
        "n": n,
        "l": l,
        "iter": it,
        "title": "Échec convergence sratom sur 4f (n=4, l=3)",
        "details": (
            "Le solveur atomique ONCVPSP n’a pas convergé pour l’orbitale 4f. "
            "Fréquent pour Dy, Tb–Tm, et plusieurs lanthanides en mode valence_f."
        ),
        "suggestion": (
            "Ne pas utiliser une config neutre 4f^n en valence. "
            "Relancer avec le gabarit PseudoDojo « 3+_f-in-core » (4f gelé, config ionique) "
            "ou importer Lanthanides_NC_PBE / PseudoDojo_standard ; "
            "si 4f actifs requis : variante *_sp.UPF ou ATOMPAW / SSSP PAW."
        ),
        "suggested_f_treatment": "open_core",
        "library_upf": library_upf_hints(sym_n) if sym_n else [],
        "recommendation": rec,
    }


def resolve_f_treatment(
    sym: str,
    f_treatment: str | None = None,
    problem: str | None = None,
    *,
    for_oncv: bool = True,
) -> str:
    """Résout auto/None → traitement concret (open_core | valence_f)."""
    raw = (f_treatment or "").strip()
    if raw and normalize_f_treatment(raw) != "auto":
        return normalize_f_treatment(raw)
    return recommend_f_treatment(sym, problem, for_oncv=for_oncv)["f_treatment"]


def valence_string(sym: str, f_treatment: str | None = None) -> str:
    sym = _norm(sym)
    ft = normalize_f_treatment(f_treatment)
    if ft == "auto":
        ft = default_oncv_f_treatment(sym)
    if ft == "open_core":
        return _OPEN_CORE.get(sym, _VALENCE_F.get(sym, "5s2 5p6 6s2"))
    return _VALENCE_F.get(sym, "6s2")


def adjust_valence_occ(
    valence: dict[tuple[int, int], int],
    sym: str,
    f_treatment: str | None,
) -> dict[tuple[int, int], int]:
    """Retire les orbitales 4f de la valence si open_core."""
    ft = normalize_f_treatment(f_treatment)
    if ft == "auto":
        ft = default_oncv_f_treatment(_norm(sym))
    if ft != "open_core":
        return dict(valence)
    out = {k: v for k, v in valence.items() if k[1] != 3}
    return out


def rc_f_bohr(scale: float = 1.0) -> float:
    v = _RC_F_DEFAULT * float(scale)
    return round(max(1.80, min(2.30, v)), 3)


_ELEMENT_NOTES_EN: dict[str, str] = {
    "La": "Little/no active 4f — 5d/6s valence; ONCV generally OK.",
    "Ce": "4f1: open-core for structure/thermo; valence_f + U for mixed valence / magnetism.",
    "Pr": "Localized 4f — open-core recommended for ONCV; valence_f fragile (sratom).",
    "Nd": "Same as Pr/Nd — open-core ONCV; PseudoDojo if valence_f required.",
    "Pm": "Radioactive / rare — open-core ONCV; prefer a validated library.",
    "Sm": "Open-core for thermo; valence_f + U if 4f moments.",
    "Eu": "Half-filled / often divalent — open-core ONCV; valence_f delicate.",
    "Gd": "4f7: open-core thermo OK; magnetism → valence_f + DFT+U + spin.",
    "Tb": "Late series — open-core ONCV (frequent lschfb 4f failure).",
    "Dy": "Typical sratom 4f failure — open-core by default; Dojo/ld1 if active 4f.",
    "Ho": "Like Dy — open-core ONCV recommended.",
    "Er": "Like Dy — open-core ONCV recommended.",
    "Tm": "Like Dy — open-core ONCV recommended.",
    "Yb": "Often 4f14 core-like — open-core; valence_f rare.",
    "Lu": "Closed 4f14 — 5d/6s valence; little 4f trouble.",
}


def load_science_note_4f(lang: str = "fr") -> str:
    """Texte scientifique (fichier repliable NOTE_SCIENTIFIQUE_4F[_EN].txt)."""
    name = "NOTE_SCIENTIFIQUE_4F_EN.txt" if (lang or "fr").lower().startswith("en") else "NOTE_SCIENTIFIQUE_4F.txt"
    p = _PSEUDODOJO_TPL_DIR / name
    try:
        if p.is_file():
            return p.read_text(encoding="utf-8", errors="replace")
    except OSError:
        pass
    if name.endswith("_EN.txt"):
        return load_science_note_4f("fr")
    return ""


def _pre_calc_notice_fr(sym: str, ft: str) -> dict[str, Any]:
    return {
        "lang": "fr",
        "title": f"Avant de lancer ONCVPSP — {sym} (4f) : raisons physiques",
        "summary": (
            f"{sym} : les 4f localisés font échouer sratom (lschfb n,l=4,3) "
            f"avec une config neutre maison. Gabarit PseudoDojo → "
            f"{'f-in-core (open_core)' if ft == 'open_core' else '*-sp (valence_f)'} ; "
            f"valence {valence_string(sym, ft)}."
        ),
        "element_note": _ELEMENT_NOTES.get(sym, ""),
        "element_label": "Élément",
        "f_treatment": ft,
        "f_treatment_label": (
            "Open core (4f gelé)" if ft == "open_core" else "Valence 4f active"
        ),
        "f_treatment_heading": "Traitement 4f pour ce run",
        "generator_heading": "Dans ce générateur",
        "by_problem_heading": "Choix selon le problème",
        "note_summary_label": "NOTE SCIENTIFIQUE (texte coloré) — repliable",
        "collapse_hint": "(replier / déplier)",
        "physics_sections": [
            {
                "heading": "1. Pourquoi le 4f est un cas à part",
                "body": (
                    "Les électrons 4f sont fortement localisés près du noyau, "
                    "relativistes et fortement corrélés. En LDA/GGA, les traiter "
                    "comme une valence « libre » les délocalise trop (mauvais moments, "
                    "SCF difficile). Deux stratégies selon l’observable."
                ),
            },
            {
                "heading": "2. Open-core / f-in-core (thermo, optique, structure)",
                "body": (
                    "Les 4f participent peu à la liaison (bande étroite). On les gèle "
                    "dans le cœur ; valence typique 5s² 5p⁶ (+ 5d/6s). Ex. Dy³⁺ PseudoDojo : "
                    "4f⁹ cœur, z_valence ≈ 11. Justifié pour maille, phonons, optique, "
                    "thermo_pw — l’essentiel porte sur 5d/6s, pas sur une bande 4f étendue."
                ),
            },
            {
                "heading": "3. Valence 4f active (*-sp) — magnétisme / DFT+U",
                "body": (
                    "Si l’observable dépend du 4f (moment, magnétisme, valence mixte), "
                    "le 4f doit être dans la valence (z plus élevé, ex. Dy ≈ 20). "
                    "Open-core ne peut pas donner un moment 4f correct. En pratique : "
                    "spin + Hubbard U, car GGA seule reste insuffisante."
                ),
            },
            {
                "heading": "4. Pourquoi lschfb n,l = 4 3",
                "body": (
                    "ONCVPSP résout d’abord l’atome AE (sratom). n=4, ℓ=3 = orbitale 4f. "
                    "Une config neutre type Dy 4f¹⁰ 6s² est fragile (potentiel centrifuge "
                    "ℓ(ℓ+1)/r² fort, puits étroit). Ce n’est pas un bug QE : limite du "
                    "solveur AE scalaire sur ce canal (surtout Dy, Tb–Tm…)."
                ),
            },
            {
                "heading": "5. Pourquoi PseudoDojo M³⁺ marche",
                "body": (
                    "Référence ionique trivalente (ex. Dy³⁺ : 4f⁹ cœur), rayons / projecteurs / "
                    "NLCC déjà optimisés, proche de l’environnement chimique des lanthanides "
                    "dans les oxydes. Meilleure référence qu’un neutre 4fⁿ isolé."
                ),
            },
            {
                "heading": "6. En une phrase",
                "body": (
                    "Open-core = 4f trop localisé/corrélé → cœur pour structure/bande. "
                    "Valence 4f = seulement si la physique l’exige (+ U + spin). "
                    "PseudoDojo M³⁺ = référence réaliste et numériquement stable."
                ),
            },
        ],
        "why_lschfb": (
            "ONCVPSP scalaire résout l’atome AE (sratom). "
            "lschfb ERROR n,l=4 3 = non-convergence de l’orbitale 4f. "
            "Une config type Dy 4f¹⁰ 6s² en valence échoue souvent ; "
            "PseudoDojo utilise une référence ionique (ex. Dy³⁺ : 4f⁹ cœur)."
        ),
        "what_we_do": (
            "Ce générateur charge oncv_templates_lanthanide/ (PseudoDojo PBE v0.4) "
            "et remplace automatiquement un .dat fragile avant oncvpsp.x."
        ),
        "by_problem": {
            "thermo_optique_structure_phonon": (
                "f-in-core / open_core — observable portée par 5d/6s (+ semi-cœur 5s/5p)"
            ),
            "magnetisme_dft_u": (
                "*-sp ou PAW SSSP + Hubbard U + spin — le moment / occupation 4f est l’observable"
            ),
            "La_Lu": "peu/pas de 4f actif — valence 5d/6s",
            "Ce_Eu_Gd": "dépend du composé (valence mixte, divalent, 4f⁷ + U…)",
        },
        "by_problem_labels": {
            "thermo": "Thermo / optique / structure / phonon",
            "magnetism": "Magnétisme / DFT+U",
            "La_Lu": "La, Lu",
            "Ce_Eu_Gd": "Ce, Eu, Gd…",
        },
        "science_note_path": "oncv_templates_lanthanide/NOTE_SCIENTIFIQUE_4F.txt",
        "science_note_full": load_science_note_4f("fr"),
        "footer_file": "Fichier",
        "footer_ref": "Réf.",
    }


def _pre_calc_notice_en(sym: str, ft: str) -> dict[str, Any]:
    return {
        "lang": "en",
        "title": f"Before running ONCVPSP — {sym} (4f): physical rationale",
        "summary": (
            f"{sym}: localized 4f often makes sratom fail (lschfb n,l=4,3) "
            f"with a homemade neutral config. PseudoDojo template → "
            f"{'f-in-core (open_core)' if ft == 'open_core' else '*-sp (valence_f)'}; "
            f"valence {valence_string(sym, ft)}."
        ),
        "element_note": _ELEMENT_NOTES_EN.get(sym, _ELEMENT_NOTES.get(sym, "")),
        "element_label": "Element",
        "f_treatment": ft,
        "f_treatment_label": (
            "Open core (frozen 4f)" if ft == "open_core" else "Active 4f valence"
        ),
        "f_treatment_heading": "4f treatment for this run",
        "generator_heading": "In this generator",
        "by_problem_heading": "Choice by problem",
        "note_summary_label": "SCIENTIFIC NOTE (colored text) — collapsible",
        "collapse_hint": "(collapse / expand)",
        "physics_sections": [
            {
                "heading": "1. Why 4f is a special case",
                "body": (
                    "4f electrons are strongly localized near the nucleus, relativistic "
                    "and strongly correlated. In LDA/GGA, treating them as a free valence "
                    "over-delocalizes them (poor moments, difficult SCF). Two strategies "
                    "depending on the observable."
                ),
            },
            {
                "heading": "2. Open-core / f-in-core (thermo, optics, structure)",
                "body": (
                    "4f barely participate in bonding (narrow band). Freeze them in the core; "
                    "typical valence 5s² 5p⁶ (+ 5d/6s). E.g. PseudoDojo Dy³⁺: 4f⁹ core, "
                    "z_valence ≈ 11. Justified for lattice, phonons, optics, thermo_pw — "
                    "the essentials live on 5d/6s, not an extended 4f band."
                ),
            },
            {
                "heading": "3. Active 4f valence (*-sp) — magnetism / DFT+U",
                "body": (
                    "If the observable depends on 4f (moment, magnetism, mixed valence), "
                    "4f must be in the valence (higher z, e.g. Dy ≈ 20). Open-core cannot "
                    "yield a correct 4f moment. In practice: spin + Hubbard U, because "
                    "GGA alone remains insufficient."
                ),
            },
            {
                "heading": "4. Why lschfb n,l = 4 3",
                "body": (
                    "ONCVPSP first solves the AE atom (sratom). n=4, ℓ=3 = 4f orbital. "
                    "A neutral Dy 4f¹⁰ 6s² config is fragile (strong ℓ(ℓ+1)/r² centrifugal "
                    "potential, narrow well). Not a QE bug: AE scalar solver limit on this "
                    "channel (especially Dy, Tb–Tm…)."
                ),
            },
            {
                "heading": "5. Why PseudoDojo M³⁺ works",
                "body": (
                    "Trivalent ionic reference (e.g. Dy³⁺: 4f⁹ core), radii / projectors / "
                    "NLCC already optimized, close to lanthanide chemistry in oxides. "
                    "Better than an isolated neutral 4fⁿ atom."
                ),
            },
            {
                "heading": "6. In one sentence",
                "body": (
                    "Open-core = 4f too localized/correlated → core for structure/bands. "
                    "Active 4f = only when physics requires it (+ U + spin). "
                    "PseudoDojo M³⁺ = realistic, numerically stable reference."
                ),
            },
        ],
        "why_lschfb": (
            "Scalar ONCVPSP solves the AE atom (sratom). "
            "lschfb ERROR n,l=4 3 = non-convergence of the 4f orbital. "
            "A Dy 4f¹⁰ 6s² valence config often fails; "
            "PseudoDojo uses an ionic reference (e.g. Dy³⁺: 4f⁹ core)."
        ),
        "what_we_do": (
            "This generator loads oncv_templates_lanthanide/ (PseudoDojo PBE v0.4) "
            "and automatically replaces a fragile .dat before oncvpsp.x."
        ),
        "by_problem": {
            "thermo_optique_structure_phonon": (
                "f-in-core / open_core — observable carried by 5d/6s (+ 5s/5p semicore)"
            ),
            "magnetisme_dft_u": (
                "*-sp or PAW SSSP + Hubbard U + spin — the 4f moment/occupation is the observable"
            ),
            "La_Lu": "little/no active 4f — 5d/6s valence",
            "Ce_Eu_Gd": "compound-dependent (mixed valence, divalent, 4f⁷ + U…)",
        },
        "by_problem_labels": {
            "thermo": "Thermo / optics / structure / phonon",
            "magnetism": "Magnetism / DFT+U",
            "La_Lu": "La, Lu",
            "Ce_Eu_Gd": "Ce, Eu, Gd…",
        },
        "science_note_path": "oncv_templates_lanthanide/NOTE_SCIENTIFIQUE_4F_EN.txt",
        "science_note_full": load_science_note_4f("en"),
        "footer_file": "File",
        "footer_ref": "Ref.",
    }


def build_pre_calc_notice(sym: str, ft: str) -> dict[str, Any]:
    """Notice bilingue Fr/En pour le panneau UI avant oncvpsp.x."""
    fr = _pre_calc_notice_fr(sym, ft)
    en = _pre_calc_notice_en(sym, ft)
    return {
        **fr,
        "i18n": {"fr": fr, "en": en},
        "default_lang": "fr",
    }


def get_guide(sym: str, f_treatment: str | None = None, problem: str | None = None) -> dict[str, Any]:
    sym = _norm(sym)
    rec = recommend_f_treatment(sym, problem, for_oncv=True)
    ft = resolve_f_treatment(sym, f_treatment, problem, for_oncv=True)
    notice = build_pre_calc_notice(sym, ft)
    return {
        "element": sym,
        "is_lanthanide": True,
        "problem": normalize_problem(problem),
        "f_treatment": ft,
        "f_treatment_label": (
            "Open core (4f gelé dans le cœur)"
            if ft == "open_core"
            else "Valence 4f active (magnétisme / DFT+U)"
        ),
        "recommendation": rec,
        "element_note": _ELEMENT_NOTES.get(sym, ""),
        "oncv_default": default_oncv_f_treatment(sym),
        "valence_recommended": valence_string(sym, ft),
        "valence_f_alternate": valence_string(sym, "valence_f"),
        "valence_open_core_alternate": valence_string(sym, "open_core"),
        "semicore_valence": "5s2 5p6 (inclus en open_core ONCV ; à garder en valence ld1)",
        "rc_4f_bohr_range": [1.8, 2.3],
        "rc_4f_suggested": rc_f_bohr(1.0),
        "relativistic": "rel=2 (équation de Dirac) recommandé en ld1.x ; scalaire insuffisant pour 4f",
        "nlcc": "nlcc=.true. + rcore≈1.2 recommandé (chevauchement cœur–valence)",
        "rho0_bessel": "rho0≈0.02 si échec RRKJ / fonctions de Bessel",
        "oncv_recommended": True,
        "ld1_difficulty": "élevée — semi-cœur 5s/5p + rel=2 + NLCC ; sinon ONCVPSP / PseudoDojo",
        "pseudodojo_url": "https://www.pseudo-dojo.org/",
        "case_by_case": {
            "thermo_optics_structure": "open_core / PseudoDojo 3+_f-in-core (Dy : pas de 4f10 neutre)",
            "magnetism_dft_u": "valence_f + spin + Hubbard U ; si ONCV échoue → *_sp.UPF PseudoDojo / ld1 / PAW",
            "sratom_lschfb_4_3": "Gabarit PseudoDojo f-in-core (oncv_templates_lanthanide/) ou UPF bibliothèque",
        },
        "library_upf": library_upf_hints(sym),
        "pw_x_tips": [
            "HUBBARD U sur 4f si sur-délocalisation GGA/LDA",
            "nspin=2 + starting_magnetization",
            "mixing_beta=0.15–0.30",
        ],
        "workflow": [
            "Choisir le problème (thermo / optique / magnétisme) → recommend_f_treatment",
            "Inclure 5s/5p en valence (semi-cœur)",
            "ld1 : rel=2, nlcc=.true., rcore≈1.2 ; rho0 si échec Bessel",
            "ONCV : défaut open_core pour Dy et fins de série ; auto-repli si lschfb 4f",
            "TEST 1 : dérivées logarithmiques (ghost state ?)",
            "TEST 2 : transférabilité (oxyde / solide)",
            "pw.x : DFT+U + magnétisation initiale si SCF difficile",
            "Sinon : PseudoDojo standard/stringent (ONCV déjà validés)",
        ],
        "tests": {
            "test1_log_derivative": "Discontinuité du déphasage → ghost ; ajuster r_c(4f)",
            "test2_transferability": "SCF sur maille test vs données tout-électron",
        },
        "pre_calc_notice": notice,
    }


def _norm(sym: str) -> str:
    s = (sym or "").strip()
    if len(s) == 1:
        return s.upper()
    return s[0].upper() + s[1:].lower()


# Cœur [Xe] (Z=54) — ordre ONCV (n croissant, l croissant)
_XE_CORE: tuple[tuple[int, int, float], ...] = (
    (1, 0, 2.0), (2, 0, 2.0), (2, 1, 6.0),
    (3, 0, 2.0), (3, 1, 6.0), (3, 2, 10.0),
    (4, 0, 2.0), (4, 1, 6.0), (4, 2, 10.0),
    (5, 0, 2.0), (5, 1, 6.0),
)


def parse_valence_tokens(valence: str) -> list[tuple[int, int, float]]:
    """Parse une chaîne type « 4f7 5d1 6s2 » en (n, l, occupation)."""
    import re

    out: list[tuple[int, int, float]] = []
    for m in re.finditer(r"(\d)([spdf])(\d+)", valence, re.I):
        n = int(m.group(1))
        l = {"s": 0, "p": 1, "d": 2, "f": 3}[m.group(2).lower()]
        occ = float(m.group(3))
        out.append((n, l, occ))
    return sorted(out, key=lambda t: (t[0], t[1]))


def _parse_valence_tokens(valence: str) -> list[tuple[int, int, float]]:
    return parse_valence_tokens(valence)


def valence_occ_dict(sym: str, f_treatment: str | None = None) -> dict[tuple[int, int], int]:
    """Occupations de valence chimiques pour APE / ld1 (lanthanides)."""
    out: dict[tuple[int, int], int] = {}
    for n, l, occ in parse_valence_tokens(valence_string(sym, f_treatment)):
        out[(n, l)] = int(round(occ))
    return out


def frozen_f_occ(sym: str) -> dict[tuple[int, int], int]:
    """4f à placer dans le cœur (open_core / Lu)."""
    sym = _norm(sym)
    if sym == "Lu":
        return {(4, 3): 14}
    if sym == "La":
        return {}
    out: dict[tuple[int, int], int] = {}
    for n, l, occ in parse_valence_tokens(_VALENCE_F.get(sym, "")):
        if l == 3:
            out[(n, l)] = int(round(occ))
    return out


def _build_oncv_electron_lines(sym: str, f_treatment: str, Z: int) -> tuple[list[str], int, int]:
    """
    Lignes (n,l,f) ONCV : nc lignes cœur puis nv lignes valence.
    Convention ONCV (ex. 29_Cu.dat, 60_Nd_GHOST.dat) : nc et nv = nombres de lignes.
    Référence : cœur [Xe] (+ 5s5p si Z>54) + 4f gelé (open_core) + valence déclarée.
    """
    import pseudo_auto_inputs as pai

    sym = _norm(sym)
    pai.atomic_number(sym)
    ft = normalize_f_treatment(f_treatment)
    if ft == "auto":
        ft = default_oncv_f_treatment(sym)
    val_tokens = _parse_valence_tokens(valence_string(sym, ft))
    valence_set = {(n, l) for n, l, _ in val_tokens}
    val_lines = [(n, l, occ) for n, l, occ in val_tokens]

    merged: dict[tuple[int, int], float] = {(n, l): o for n, l, o in _XE_CORE}
    if Z > 54:
        merged[(5, 0)] = 2.0
        merged[(5, 1)] = 6.0
    if ft == "open_core":
        for n, l, occ in _parse_valence_tokens(_VALENCE_F.get(sym, "")):
            if l == 3:
                merged[(n, l)] = occ

    core_lines = sorted(
        ((n, l, merged[(n, l)]) for n, l in merged if (n, l) not in valence_set),
        key=lambda t: (t[0], t[1]),
    )
    nc = len(core_lines)
    nv = len(val_lines)
    all_lines = core_lines + val_lines
    str_lines = [f"    {n}    {l}    {occ:.1f}" for n, l, occ in all_lines]
    return str_lines, nc, nv


def generate_oncv_dat(
    sym: str,
    f_treatment: str | None = None,
    xc: str = "gga_pbe",
    rc_f_scale: float = 1.0,
    psfile: str = "both",
    problem: str | None = None,
    *,
    use_pseudodojo_template: bool = True,
) -> str:
    """Génère une entrée ONCVPSP .dat pour un lanthanide (NC).

    Préfère le gabarit PseudoDojo local (convergent pour Dy, etc.) si disponible.
    """
    import re
    import pseudo_auto_inputs as pai

    sym = _norm(sym)
    if not is_lanthanide(sym):
        raise ValueError(f"{sym} n'est pas un lanthanide (Z 57–71).")
    ft = resolve_f_treatment(sym, f_treatment, problem, for_oncv=True)

    if use_pseudodojo_template:
        raw, src = load_pseudodojo_oncv_input(sym, ft)
        if raw:
            # psfile → both/upf pour QE
            ps = (psfile or "both").strip().lower()
            if ps not in ("upf", "both", "psp8"):
                ps = "both"
            text = re.sub(
                r"(?im)^(\s*[A-Za-z]{1,2}\s+[\d.]+\s+\d+\s+\d+\s+\d+\s+)\S+\s*$",
                rf"\g<1>{ps}",
                raw,
                count=1,
            )
            if re.search(r"(?i)\bpsp8\b", text) and ps != "psp8":
                text = re.sub(r"(?i)\bpsp8\b", ps, text, count=1)
            header = (
                f"# Source : {src} (PseudoDojo ONCVPSP-PBE-PDv0.4)\n"
                f"# 4f résolu : {ft} — élément {sym} — psfile={ps}\n"
                "# Ne pas remplacer par une config neutre 4f10 (échec sratom / lschfb).\n"
            )
            xc_key = (xc or "gga_pbe").lower()
            if xc_key not in ("gga_pbe", "pbe", ""):
                # Physique : r_c / projecteurs PseudoDojo sont tunés pour PBE.
                # Changer iexc seul donnerait un pseudo XC-inconsistant.
                header += (
                    f"# AVERTISSEMENT : XC demandée={xc_key} ignorée. "
                    "Ce gabarit reste PBE (iexc du fichier). "
                    "Pour LDA, utiliser un .dat LDA dédié ou le générateur maison "
                    "(use_pseudodojo_template=False).\n"
                )
            if not text.lstrip().startswith("#"):
                return header + text
            return header + text

    Z = pai.atomic_number(sym)
    iexc = _ONCV_IEXC.get((xc or "gga_pbe").lower(), 3)
    rc_f = rc_f_bohr(rc_f_scale)
    # Maison (hors PseudoDojo) : s un peu plus large / qcut plus bas anti-GHOST(+)
    rc_s = round(max(2.20, min(2.80, 2.60 * rc_f_scale)), 2)
    rc_p = round(max(2.15, min(2.70, 2.50 * rc_f_scale)), 2)
    rc_d = round(max(2.10, min(2.55, 2.40 * rc_f_scale)), 2)

    elec_lines, nc, nv = _build_oncv_electron_lines(sym, ft, Z)
    val_tokens = _parse_valence_tokens(valence_string(sym, ft))
    # Projecteurs f uniquement si 4f est en VALENCE (pas si gelé dans le cœur)
    has_f_val = any(l == 3 for _, l, _ in val_tokens)
    lmax = 3 if has_f_val else 2

    # rc(lloc) doit être <= rc(l) pour chaque canal (test_data ONCV).
    rc_channels = [
        (0, rc_s, 0.00, 4, 8, 4.00),
        (1, rc_p, 0.00, 4, 8, 4.50),
        (2, rc_d, 0.00, 4, 9, 6.00),
    ]
    if lmax >= 3:
        ep_f = 0.00
        rc_channels.append((3, rc_f, ep_f, 5, 9, 10.00))
    rc_local = round(min(r[1] for r in rc_channels), 2)

    rc_lines = [
        f"    {l}    {rc:.2f}   {ep:5.2f}    {ncon}    {nbas}   {qcut:.2f}"
        for l, rc, ep, ncon, nbas, qcut in rc_channels
    ]

    # Valeurs proches 60_Nd_GHOST.dat (debl=0 refusé par ONCV pour certains l).
    proj = ["    0    2    1.00", "    1    2    4.00", "    2    2    4.00"]
    if lmax >= 3:
        proj.append("    3    2    2.00")

    atsym = sym.lower()[:2]
    ps = (psfile or "both").strip().lower()
    if ps not in ("upf", "both", "psp8"):
        ps = "both"

    header = (
        "# ONCVPSP — lanthanide NC (generation_pseudos/lanthanide_nc.py)\n"
        f"# Cible par défaut : Quantum ESPRESSO — psfile={ps} (UPF XML + psp8)\n"
        f"# 4f: {ft} — valence {valence_string(sym, ft)} — r_c(4f)={rc_f} bohr\n"
        f"# Défaut ONCV {sym}: {default_oncv_f_treatment(sym)}"
        + (f" — problème={normalize_problem(problem)}" if problem else "")
        + "\n"
        "# Avertissement : configs neutres 4f peuvent échouer (lschfb) — "
        "préférer gabarits PseudoDojo dans oncv_templates_lanthanide/.\n"
        "#\n"
        "# ATOM AND REFERENCE CONFIGURATION\n"
        "# atsym, z, nc, nv, iexc   psfile\n"
        f"  {atsym}  {float(Z):.1f}   {nc}   {nv}   {iexc}   {ps}\n"
        "#\n"
        "# n, l, f  (nc+nv lines)\n"
    )
    body = "\n".join(elec_lines)
    # ONCV : 0 <= lloc <= lmax  OU  lloc == 4 (potentiel local « designed »).
    # lloc = lmax+1 est invalide dès que lmax < 3 (ex. open_core Dy → lmax=2).
    lloc = 4
    opt = (
        "#\n# PSEUDOPOTENTIAL AND OPTIMIZATION\n# lmax\n"
        f"    {lmax}\n#\n# l, rc, ep, ncon, nbas, qcut  (lmax+1 lines, l's must be in order)\n"
        + "\n".join(rc_lines)
        + "\n#\n# LOCAL POTENTIAL\n# lloc, lpopt, rc(5), dvloc0\n"
        f"    {lloc}    5    {rc_local:.2f}    0.0\n#\n"
        "# VANDERBILT-KLEINMAN-BYLANDER PROJECTORs\n# l, nproj, debl  (lmax+1 lines, l's in order)\n"
        + "\n".join(proj)
        + "\n#\n# MODEL CORE CHARGE\n# icmod, fcfact\n    0    0.0\n#\n"
        "# LOG DERIVATIVE ANALYSIS\n# epsh1, epsh2, depsh\n   -2.0  3.0  0.02\n#\n"
        "# OUTPUT GRID\n# rlmax, drl\n    6.0  0.01\n#\n# TEST CONFIGURATIONS\n# ncnf\n    0\n"
    )
    return header + body + "\n" + opt

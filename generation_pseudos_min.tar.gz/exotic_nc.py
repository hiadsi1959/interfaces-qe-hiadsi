# -*- coding: utf-8 -*-
"""
Gabarits ONCVPSP (.dat) pour les éléments exotiques sans entrée PseudoDojo :
Po–Og (Z 84–86, 113–118), Fr/Ra (87–88), Rf–Cn (104–112).

Configurations (structures calquées sur les fichiers officiels qui tournent) :
  - Po–Rn : cœur [Xe] 4f14 (68) ; valence 5d10 6s2 6p(4–6)   (modèle 83_Bi.dat)
  - Fr–Ra : cœur [Xe] 4f14 (68) ; valence 5d10 6s2 6p6 7s(1–2) (idem Bi : d semi-cœur
            occupé en VALENCE, lmax=3, f non occupé ep=+0.25)
  - Rf–Cn : cœur 1s..5f14 (92)  ; valence 6s2 6p6 6d(2–10) 7s2 (modèle actinide Th :
            6s/6p en valence → tous les canaux s/p/d occupés)
  - Nh–Og : cœur [Rn] 5f14 (100); valence 6d10 7s2 7p(1–6)   (idem Bi : 6d semi-cœur
            occupé en valence, lmax=3, f non occupé ep=+0.25)

iexc=4 (PBE, oncvpsp 4.0.1). Ce sont des POINTS DE DÉPART locaux :
valider (ghost / transfert) avant production.

Anti-GHOST(+) (canal s) pour lourds / super-lourds :
  - rc(s) un peu plus grand, qcut(s) plus bas (ne pas durcir qcut).
  - Mc (Z=115) : GHOST(+) observé avec rc_s=3.0 / qcut_s=4.0 → défauts p7 adoucis.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

try:
    from pseudo_auto_inputs import normalize_symbol, atomic_number
except ImportError:  # pragma: no cover

    def normalize_symbol(sym: str) -> str:
        s = (sym or "").strip()
        return s.upper() if len(s) == 1 else s[0].upper() + s[1:].lower()

    def atomic_number(sym: str) -> int:  # pragma: no cover
        return 0


EXOTIC_SYMBOLS: tuple[str, ...] = (
    "Po", "At", "Rn", "Fr", "Ra", "Rf", "Db", "Sg", "Bh", "Hs",
    "Mt", "Ds", "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og",
)

# Coeurs (n, l, occ)
_CORE_XE_4F: tuple[tuple[int, int, float], ...] = (      # 68 e- : 1s..5p
    (1, 0, 2.0), (2, 0, 2.0), (2, 1, 6.0),
    (3, 0, 2.0), (3, 1, 6.0), (3, 2, 10.0),
    (4, 0, 2.0), (4, 1, 6.0), (4, 2, 10.0),
    (4, 3, 14.0), (5, 0, 2.0), (5, 1, 6.0),
)
_CORE_RN: tuple[tuple[int, int, float], ...] = (          # 86 e- : 1s..6p
    _CORE_XE_4F + ((5, 2, 10.0), (6, 0, 2.0), (6, 1, 6.0))
)
_CORE_RN_5F: tuple[tuple[int, int, float], ...] = (       # 100 e- : 1s..6p + 5f14
    _CORE_RN + ((5, 3, 14.0),)
)

# Rf–Cn : cœur 1s..5d + 5f14 (92 e-) — 6s/6p restent en VALENCE (modèle actinide Th)
_CORE_XE_4F_5D_5F: tuple[tuple[int, int, float], ...] = (
    _CORE_XE_4F + ((5, 2, 10.0), (5, 3, 14.0))
)

# Valence (n, l, occ)
_VALENCE: dict[str, tuple[tuple[int, int, float], ...]] = {
    "Po": ((5, 2, 10.0), (6, 0, 2.0), (6, 1, 4.0)),
    "At": ((5, 2, 10.0), (6, 0, 2.0), (6, 1, 5.0)),
    "Rn": ((5, 2, 10.0), (6, 0, 2.0), (6, 1, 6.0)),
    "Fr": ((5, 2, 10.0), (6, 0, 2.0), (6, 1, 6.0), (7, 0, 1.0)),
    "Ra": ((5, 2, 10.0), (6, 0, 2.0), (6, 1, 6.0), (7, 0, 2.0)),
    "Rf": ((6, 0, 2.0), (6, 1, 6.0), (6, 2, 2.0), (7, 0, 2.0)),
    "Db": ((6, 0, 2.0), (6, 1, 6.0), (6, 2, 3.0), (7, 0, 2.0)),
    "Sg": ((6, 0, 2.0), (6, 1, 6.0), (6, 2, 4.0), (7, 0, 2.0)),
    "Bh": ((6, 0, 2.0), (6, 1, 6.0), (6, 2, 5.0), (7, 0, 2.0)),
    "Hs": ((6, 0, 2.0), (6, 1, 6.0), (6, 2, 6.0), (7, 0, 2.0)),
    "Mt": ((6, 0, 2.0), (6, 1, 6.0), (6, 2, 7.0), (7, 0, 2.0)),
    "Ds": ((6, 0, 2.0), (6, 1, 6.0), (6, 2, 8.0), (7, 0, 2.0)),
    "Rg": ((6, 0, 2.0), (6, 1, 6.0), (6, 2, 9.0), (7, 0, 2.0)),
    "Cn": ((6, 0, 2.0), (6, 1, 6.0), (6, 2, 10.0), (7, 0, 2.0)),
    "Nh": ((6, 2, 10.0), (7, 0, 2.0), (7, 1, 1.0)),
    "Fl": ((6, 2, 10.0), (7, 0, 2.0), (7, 1, 2.0)),
    "Mc": ((6, 2, 10.0), (7, 0, 2.0), (7, 1, 3.0)),
    "Lv": ((6, 2, 10.0), (7, 0, 2.0), (7, 1, 4.0)),
    "Ts": ((6, 2, 10.0), (7, 0, 2.0), (7, 1, 5.0)),
    "Og": ((6, 2, 10.0), (7, 0, 2.0), (7, 1, 6.0)),
}

# Paramètres ONCV par famille : rc(s,p,d,f), lpopt, icmod, fcfact, lmax, debl, qcut, nbas
# ep des canaux non occupés : +0.05 pour d (comme Al PseudoDojo), +0.25 pour f (comme Bi)
# Canal s adouci (rc↑, qcut↓) pour limiter les WARNING - GHOST(+) sur lourds / super-lourds.
_CFG: dict[str, dict[str, Any]] = {
    # Po–Rn (lourds 6p) — modèle Bi adouci sur s/p
    "p6":  dict(core=_CORE_XE_4F,   rc=(3.20, 3.10, 2.50, 3.00), lpopt=3, icmod=1,
                fcfact=0.25, lmax=3, debl=(1.00, 1.00, 1.20, 1.00),
                qcut=(3.5, 3.8, 6.0, 5.0), nbas=(7, 7, 8, 8)),
    # Fr–Ra (7s) — qcut s/p abaissés (5.0 était trop dur → ghosts +)
    "s7":  dict(core=_CORE_XE_4F,   rc=(3.20, 3.10, 2.90, 3.00), lpopt=5, icmod=0,
                fcfact=0.0, lmax=2, debl=(1.50, 1.50, 1.50, 1.50),
                qcut=(3.5, 4.0, 5.5, 6.0), nbas=(7, 7, 8, 8)),
    # Rf–Cn (super-lourds 6d) — rc s/p élargis, qcut s/p assouplis (ex-2.45/5.5 trop durs)
    "d6":  dict(core=_CORE_XE_4F_5D_5F, rc=(2.90, 2.80, 2.60, 2.60), lpopt=5, icmod=0,
                fcfact=0.0, lmax=2, debl=(1.00, 4.00, 4.00, 2.00),
                qcut=(4.0, 4.5, 6.0, 6.5), nbas=(8, 8, 9, 8)),
    # Nh–Og (super-lourds 7p, dont Mc) — anti-GHOST(+) canal s (Mc restait ghost à 3.20/3.50)
    # nbas(s)=8 : avec nbas(s)=7, Nh sortait un GHOST(+) à <r>/rc≈0.99 (rc_s=3.60,
    # qcut_s=3.00). nbas doit rester dans [ncon+3, ncon+5] = [7, 9] ; 8/9 sont sans ghost.
    "p7":  dict(core=_CORE_RN_5F,   rc=(3.50, 3.20, 2.80, 3.10), lpopt=3, icmod=1,
                fcfact=0.25, lmax=3, debl=(0.80, 1.00, 1.20, 1.00),
                qcut=(3.0, 3.5, 5.5, 5.0), nbas=(8, 7, 8, 8)),
}

# Plafonds / planchers (Bohr, a.u.⁻¹) — ne pas durcir au-delà pour « corriger » un ghost
_RC_S_MAX = 3.60
_QCUT_S_MIN = 3.00


def _apply_mass_anti_ghost(
    rcs: tuple[float, ...],
    qcuts: tuple[float, ...],
    Z: int,
) -> tuple[tuple[float, ...], tuple[float, ...]]:
    """Surcouche Z : super-lourds (Z≥104) un cran plus mous sur s (et p léger)."""
    rc = list(rcs)
    qc = list(qcuts)
    if Z >= 113 and rc:
        # Nh–Og : Fl restait GHOST(+) à rc_s=3.50 — plafond 3.60 validé sans ghost
        rc[0] = min(_RC_S_MAX, max(rc[0], 3.60))
        qc[0] = max(_QCUT_S_MIN, min(qc[0], 3.00))
        if len(rc) > 1:
            rc[1] = min(3.50, max(rc[1], 3.20))
    elif Z >= 104 and rc:
        rc[0] = min(_RC_S_MAX, round(rc[0] + 0.10, 2))
        qc[0] = max(_QCUT_S_MIN, round(qc[0] - 0.30, 2))
        if len(rc) > 1:
            rc[1] = min(3.50, round(rc[1] + 0.05, 2))
    return tuple(rc), tuple(qc)

def _test_configs(val: tuple[tuple[int, int, float], ...]) -> list[tuple[tuple[int, int, float], ...]]:
    """Configurations d'ionisation pour l'analyse de transférabilité ONCV.

    Réduit l'occupation des canaux de valence extérieurs (comme les blocs
    TEST CONFIGURATIONS de 56_Ba.dat / 83_Bi.dat) : ONCVPSP imprime alors
    les écarts eae/eps (config test) — métrique quantitative ghost/transfert.
    Occupation plancher 1.0 (jamais 0.0 dans les configs test officielles).
    """
    def make(deltas: dict[int, float]) -> tuple[tuple[int, int, float], ...]:
        return tuple(
            (n, l, max(f - deltas.get(i, 0.0), 1.0))
            for i, (n, l, f) in enumerate(val)
        )

    order = sorted(range(len(val)), key=lambda i: (val[i][0], val[i][1]), reverse=True)
    outer, inner = order[0], order[1]
    ref = tuple(val)
    out: list[tuple[tuple[int, int, float], ...]] = []
    for cand in (make({outer: 1}), make({outer: 2}), make({inner: 1}), make({inner: 2})):
        if cand != ref and cand not in out:
            out.append(cand)
    return out[:3]


_FAMILY: dict[str, str] = {
    "Po": "p6", "At": "p6", "Rn": "p6",
    "Fr": "s7", "Ra": "s7",
    "Rf": "d6", "Db": "d6", "Sg": "d6", "Bh": "d6", "Hs": "d6",
    "Mt": "d6", "Ds": "d6", "Rg": "d6", "Cn": "d6",
    "Nh": "p7", "Fl": "p7", "Mc": "p7", "Lv": "p7", "Ts": "p7", "Og": "p7",
}

_TPL_DIR = Path(__file__).resolve().parent / "oncv_templates_exotic"


def is_exotic(sym: str) -> bool:
    return normalize_symbol(sym) in EXOTIC_SYMBOLS


def needs_generated_dat(sym: str) -> bool:
    return is_exotic(sym)


def generate_oncv_dat(
    sym: str,
    *,
    xc: str | None = "gga_pbe",
    psfile: str = "both",
    rc_scale: float = 1.0,
    **_: Any,
) -> str | None:
    sym = normalize_symbol(sym)
    if not is_exotic(sym):
        return None
    # PBE uniquement (gabarits tunés PBE)
    if (xc or "gga_pbe").strip().lower() not in ("", "gga_pbe", "pbe"):
        return None
    Z = int(atomic_number(sym))
    fam = _CFG[_FAMILY[sym]]
    core = fam["core"]
    val = _VALENCE[sym]
    rc_s, rc_p, rc_d, rc_f = (round(r * float(rc_scale), 2) for r in fam["rc"])
    lmax = int(fam["lmax"])
    nchan = lmax + 1
    rcs = (rc_s, rc_p, rc_d, rc_f)[:nchan]
    qcuts = tuple(float(fam["qcut"][l]) for l in range(nchan))
    rcs, qcuts = _apply_mass_anti_ghost(rcs, qcuts, Z)
    # Plafond sécurité canal s (évite rc_scale trop agressif → pseudo inutilisable)
    if rcs:
        rcs = (min(_RC_S_MAX, rcs[0]),) + rcs[1:]
        qcuts = (max(_QCUT_S_MIN, qcuts[0]),) + qcuts[1:]
    rc_local = round(min(rcs), 2)

    all_lines = sorted(core + val, key=lambda t: (t[0], t[1]))
    nc = len(core)
    nv = len(val)
    q = sum(o for _, _, o in all_lines)
    if abs(q - float(Z)) > 0.01:
        raise ValueError(f"Config ONCV {sym} : somme={q} ≠ Z={Z}.")

    # ep : 0.00 pour les canaux occupés ; +0.05 (d) / +0.25 (f) pour projecteurs non occupés
    occ_l = {l for _, l, _ in val}
    eps = tuple(
        0.00 if l in occ_l else (0.25 if l == 3 else 0.05)
        for l in range(nchan)
    )
    rc_lines = [
        f"    {l}    {rc:.2f}   {ep:5.2f}    {4}    {int(fam['nbas'][l])}   {qcuts[l]:.2f}"
        for l, (rc, ep) in enumerate(zip(rcs, eps))
    ]
    proj = [
        f"    {l}    2    {fam['debl'][l]:.2f}" for l in range(nchan)
    ]

    ps = (psfile or "both").strip().lower()
    if ps not in ("upf", "both", "psp8"):
        ps = "both"
    atsym = sym.lower()[:2]
    val_str = " ".join(
        f"{n}{'spdf'[l]}{int(o) if o == int(o) else o}" for n, l, o in val
    )
    elec = [f"    {n}    {l}    {occ:.1f}" for n, l, occ in all_lines]
    mass_note = (
        "super-lourd (Z≥104) : rc_s+/qcut_s− anti-GHOST(+)"
        if Z >= 104
        else "lourd : canal s adouci (rc↑, qcut↓)"
    )
    header = (
        "# ONCVPSP — élément exotique NC (generation_pseudos/exotic_nc.py)\n"
        f"# Élément {sym} Z={Z} — valence {val_str}\n"
        f"# Anti-ghost : {mass_note} | rc_s={rcs[0]:.2f} qcut_s={qcuts[0]:.2f}\n"
        "# AVERTISSEMENT : gabarit local (pas PseudoDojo) — valider ghost/transfert.\n"
        "#\n"
        "# ATOM AND REFERENCE CONFIGURATION\n"
        "# atsym, z, nc, nv, iexc   psfile\n"
        f"  {atsym}  {float(Z):.1f}   {nc}   {nv}   4   {ps}\n"
        "#\n"
        "# n, l, f  (nc+nv lines)\n"
    )
    opt = (
        "#\n# PSEUDOPOTENTIAL AND OPTIMIZATION\n# lmax\n"
        f"    {lmax}\n#\n# l, rc, ep, ncon, nbas, qcut  (lmax+1 lines)\n"
        + "\n".join(rc_lines)
        + "\n#\n# LOCAL POTENTIAL\n# lloc, lpopt, rc(5), dvloc0\n"
        f"    4    {fam['lpopt']}    {rc_local:.2f}    0.0\n#\n"
        "# VANDERBILT-KLEINMAN-BYLANDER PROJECTORs\n# l, nproj, debl\n"
        + "\n".join(proj)
        + "\n#\n# MODEL CORE CHARGE\n# icmod, fcfact\n"
        f"    {fam['icmod']}    {fam['fcfact']:.2f}\n#\n"
        "# LOG DERIVATIVE ANALYSIS\n# epsh1, epsh2, depsh\n   -2.0  3.0  0.02\n#\n"
        "# OUTPUT GRID\n# rlmax, drl\n    7.0  0.01\n"
    )
    confs = _test_configs(val)
    if confs:
        blocks = []
        for cf in confs:
            lines = "\n".join(f"    {n}    {l}   {f:.1f}" for n, l, f in cf)
            blocks.append(f"    {len(cf)}\n{lines}\n#")
        opt += (
            "#\n# TEST CONFIGURATIONS\n# ncnf\n"
            f"    {len(confs)}\n"
            "#\n#   nvcnf (repeated ncnf times)\n"
            "#   n, l, f  (nvcnf lines, repeated follwing nvcnf's ncnf times)\n"
            + "\n".join(blocks)
        )
    else:
        opt += "#\n# TEST CONFIGURATIONS\n# ncnf\n    0"
    opt += "\n"
    return header + "\n".join(elec) + "\n" + opt


def ensure_cached_templates(project_root: str | Path) -> list[str]:
    root = Path(project_root).expanduser().resolve()
    cache = root / "oncv_templates_exotic"
    cache.mkdir(parents=True, exist_ok=True)
    written: list[str] = []
    for sym in EXOTIC_SYMBOLS:
        path = cache / f"{sym}.dat"
        try:
            path.write_text(generate_oncv_dat(sym), encoding="utf-8")
            written.append(sym)
        except Exception:
            pass
    return written


def get_guide(sym: str) -> dict[str, Any]:
    sym = normalize_symbol(sym)
    return {
        "element": sym,
        "is_exotic": True,
        "has_official_dat": False,
        "valence_note": "Gabarit local de départ (Aufbau) — à valider",
        "oncv_recommended": "prudence",
        "message": (
            f"{sym} : gabarit ONCV local (pas PseudoDojo), canal s adouci "
            "(rc↑ / qcut↓) pour limiter les GHOST(+). "
            "Validez ghost / transferabilité avant usage production."
        ),
        "anti_ghost": {
            "policy": "increase rc(s), decrease qcut(s); never raise qcut to fix GHOST(+)",
            "rc_s_max_bohr": _RC_S_MAX,
            "qcut_s_min": _QCUT_S_MIN,
        },
        "pseudodojo_url": "https://www.pseudo-dojo.org/",
    }
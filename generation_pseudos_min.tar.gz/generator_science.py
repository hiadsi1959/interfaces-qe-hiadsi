# -*- coding: utf-8 -*-
"""Notes scientifiques repliables avant lancement — tous générateurs (ld1, APE, ATOMPAW, ONCV)."""
from __future__ import annotations

from typing import Any

from pseudo_auto_inputs import _TRANSITION_3D, atomic_number, normalize_symbol

_GENERATORS = {
    "ld1": "ld1.x (Quantum ESPRESSO)",
    "ld1x": "ld1.x (Quantum ESPRESSO)",
    "ld1.x": "ld1.x (Quantum ESPRESSO)",
    "ape": "APE",
    "atompaw": "ATOMPAW",
    "oncvpsp": "ONCVPSP",
    "oncv": "ONCVPSP",
}

_GEN_WHAT_FR = {
    "ld1": (
        "ld1.x construit un pseudo à partir de l’atome AE (config, r_c, NLCC). "
        "Gabarits auto : 3d → PAW/US ; 4f → open_core US (rel=1) ou valence_f (rel=2) ; "
        "5f → selon l’élément (Th–Pu : valence_f ; Am–No : open_core possible). "
        "Validez toujours l’UPF avec pw.x ou la validation QE intégrée."
    ),
    "ape": (
        "APE résout l’équation pseudo-KS en norme-conservant (Troullier-Martins). "
        "Robuste pour légers (Si, Al) ; fragile sur 3d et blocs f — préférez ATOMPAW/ONCV si échec."
    ),
    "atompaw": (
        "ATOMPAW génère des jeux PAW (projecteurs + compensation de cœur). "
        "Voie la plus fiable pour 3d, lanthanides et actinides (open_core auto)."
    ),
    "oncvpsp": (
        "ONCVPSP optimise des pseudos norme-conservants (Hamann ONCV). "
        "Gabarits PseudoDojo pour 4f/5f ; psfile=both → UPF Quantum ESPRESSO."
    ),
}

_GEN_WHAT_EN = {
    "ld1": (
        "ld1.x builds a pseudo from the AE atom (config, r_c, NLCC). "
        "Auto templates for 3d (PAW/US) and 4f/5f open_core (US). "
        "Always validate the UPF with pw.x or built-in QE checks."
    ),
    "ape": (
        "APE solves the norm-conserving pseudo-KS equation (Troullier-Martins). "
        "Robust for light elements; fragile on 3d and f-blocks — use ATOMPAW/ONCV on failure."
    ),
    "atompaw": (
        "ATOMPAW generates PAW datasets (projectors + core compensation). "
        "Most reliable route for 3d, lanthanides and actinides (auto open_core)."
    ),
    "oncvpsp": (
        "ONCVPSP optimizes norm-conserving pseudos (Hamann ONCV). "
        "PseudoDojo templates for 4f/5f; psfile=both → Quantum ESPRESSO UPF."
    ),
}


def _norm_gen(generator: str) -> str:
    g = (generator or "ld1").strip().lower()
    if g in ("ld1x", "ld1.x"):
        return "ld1"
    if g.startswith("oncv"):
        return "oncvpsp"
    return g if g in _GEN_WHAT_FR else "ld1"


def _is_lanthanide(sym: str, z: int) -> bool:
    try:
        import lanthanide_nc as lnc
        return lnc.is_lanthanide(sym)
    except ImportError:
        return 57 <= z <= 71


def _is_actinide(sym: str, z: int) -> bool:
    try:
        import actinide_nc as anc
        return anc.is_actinide(sym)
    except ImportError:
        return 89 <= z <= 103


def _3d_notice_fr(sym: str, gen: str) -> dict[str, Any]:
    gname = _GENERATORS.get(gen, gen)
    return {
        "lang": "fr",
        "family": "3d",
        "title": f"Avant de lancer {gname} — {sym} (métal 3d) : raisons physiques",
        "collapse_hint": "(replier / déplier)",
        "summary": (
            f"{sym} : les orbitales 3d sont peu dispersées et fortement sensibles au r_c et au type de pseudo. "
            f"Le test PS-KS de ld1.x échoue souvent en NC ; PAW/US + semi-cœur 3p (NLCC) stabilisent la génération."
        ),
        "element_note": (
            "Électrons 3d : corrélations et double comptage d–p si le semi-cœur est mal traité. "
            "Pour pw.x : USPP ou PAW catalogue (SSSP, PseudoDojo) sont souvent préférables à un NC ld1 « from scratch »."
        ),
        "physics_sections": [
            {
                "heading": "1. Physique : pourquoi le 3d est délicat",
                "body": (
                    "Les 3d sont plus localisés que les 4s/4p mais restent liants en métal. "
                    "Un pseudo doit reproduire le comportement AE jusqu’à r_c sans nœuds parasites. "
                    "En NC pur, l’équation pseudo-KS (test PS-KS) diverge fréquemment (Sc–Zn)."
                ),
            },
            {
                "heading": "2. Semi-cœur 3p et NLCC",
                "body": (
                    "Inclure 3p (voire 3s) en valence ou via NLCC évite les sauts de densité et stabilise "
                    "les projecteurs. Gabarit type [Ne]3s²3p⁶3dⁿ4s² (US) ou [Ar]3dⁿ4s² (PAW) avec rcore ≈ 1.2 a.u."
                ),
            },
            {
                "heading": "3. Choix par générateur",
                "body": (
                    "ld1.x : PAW ou US recommandé — NC catalogue seulement. "
                    "ATOMPAW : voie robuste (PAW natif). "
                    "ONCVPSP : gabarits 3d locaux (Ti/Cu) ou transition_3d_nc. "
                    "APE NC : convergence GSL fragile sur 3d."
                ),
            },
        ],
        "what_we_do": _GEN_WHAT_FR.get(gen, _GEN_WHAT_FR["ld1"]),
        "recommended": ["atompaw", "ld1 (PAW/US)", "oncvpsp", "PseudoDojo/PSLibrary NC"],
    }


def _3d_notice_en(sym: str, gen: str) -> dict[str, Any]:
    gname = _GENERATORS.get(gen, gen)
    fr = _3d_notice_fr(sym, gen)
    return {
        **fr,
        "lang": "en",
        "title": f"Before running {gname} — {sym} (3d metal): physical rationale",
        "summary": (
            f"{sym}: 3d orbitals are narrow and sensitive to r_c and pseudo type. "
            f"ld1.x PS-KS often fails in NC; PAW/US + 3p semicore (NLCC) stabilizes generation."
        ),
        "what_we_do": _GEN_WHAT_EN.get(gen, _GEN_WHAT_EN["ld1"]),
    }


def _default_notice_fr(sym: str, gen: str, z: int) -> dict[str, Any]:
    gname = _GENERATORS.get(gen, gen)
    return {
        "lang": "fr",
        "family": "main",
        "title": f"Avant de lancer {gname} — {sym} : rappels physiques",
        "collapse_hint": "(replier / déplier)",
        "summary": (
            f"{sym} (Z={z}) : vérifiez la valence (électrons explicitement décrits), "
            f"le rayon de coupure r_c (plus petit → ecutwfc plus élevé) et la relativité scalaire si Z > 36."
        ),
        "physics_sections": [
            {
                "heading": "1. Valence et z_valence",
                "body": (
                    "Seuls les états décrits comme valence comptent dans z_valence pour pw.x. "
                    "Les cœurs gelés doivent rester cohérents entre config AE et projecteurs."
                ),
            },
            {
                "heading": "2. Convergence pw.x",
                "body": (
                    "Après génération : test de coupure ecutwfc / ecutrho, puis validation UPF "
                    "(format PP_HEADER, types NC/US/PAW compatibles avec votre calcul)."
                ),
            },
        ],
        "what_we_do": _GEN_WHAT_FR.get(gen, _GEN_WHAT_FR["ld1"]),
    }


def _default_notice_en(sym: str, gen: str, z: int) -> dict[str, Any]:
    fr = _default_notice_fr(sym, gen, z)
    gname = _GENERATORS.get(gen, gen)
    return {
        **fr,
        "lang": "en",
        "title": f"Before running {gname} — {sym}: physical reminders",
        "what_we_do": _GEN_WHAT_EN.get(gen, _GEN_WHAT_EN["ld1"]),
    }


def _patch_fn_notice(base: dict[str, Any], sym: str, gen: str, lang: str) -> dict[str, Any]:
    """Adapte une notice 4f/5f au générateur courant."""
    gname = _GENERATORS.get(gen, gen)
    out = dict(base)
    fam = out.get("family") or ("4f" if "4f" in str(out.get("title", "")) else "5f")
    if lang == "en":
        out["title"] = f"Before running {gname} — {sym} ({fam}): physical rationale"
        out["generator_heading"] = "In this generator"
        out["what_we_do"] = _GEN_WHAT_EN.get(gen, _GEN_WHAT_EN["oncvpsp"])
    else:
        out["title"] = f"Avant de lancer {gname} — {sym} ({fam}) : raisons physiques"
        out["generator_heading"] = "Dans ce générateur"
        out["what_we_do"] = _GEN_WHAT_FR.get(gen, _GEN_WHAT_FR["oncvpsp"])
    return out


def build_pre_calc_science(
    sym: str,
    generator: str = "ld1",
    *,
    lang: str = "fr",
    f_treatment: str | None = None,
) -> dict[str, Any]:
    """
    Notice scientifique unifiée (repliable) pour ld1 / APE / ATOMPAW / ONCVPSP.
    Délègue aux modules 4f/5f ; sections dédiées pour 3d et éléments principaux.
    """
    sym_n = normalize_symbol(sym)
    z = atomic_number(sym_n)
    gen = _norm_gen(generator)
    L = "en" if (lang or "fr").lower().startswith("en") else "fr"

    if _is_lanthanide(sym_n, z):
        try:
            import lanthanide_nc as lnc
            ft = lnc.normalize_f_treatment(f_treatment or "open_core")
            notice = lnc.build_pre_calc_notice(sym_n, ft)
            i18n = notice.get("i18n") or {}
            base = dict(i18n.get(L) or notice)
            base = _patch_fn_notice(base, sym_n, gen, L)
            return {
                "success": True,
                "element": sym_n,
                "Z": z,
                "generator": gen,
                "family": "4f",
                "f_treatment": ft,
                "lang": L,
                "pre_calc_notice": notice,
                "notice": base,
                "science_note_full": notice.get("science_note_full_fr" if L == "fr" else "science_note_full_en")
                or base.get("science_note_full"),
            }
        except ImportError:
            pass

    if _is_actinide(sym_n, z):
        try:
            import actinide_nc as anc
            ft = anc.normalize_f_treatment(f_treatment or "open_core")
            notice = anc.build_pre_calc_notice(sym_n, ft)
            i18n = notice.get("i18n") or {}
            base = dict(i18n.get(L) or notice)
            base = _patch_fn_notice(base, sym_n, gen, L)
            base["family"] = "5f"
            return {
                "success": True,
                "element": sym_n,
                "Z": z,
                "generator": gen,
                "family": "5f",
                "f_treatment": ft,
                "lang": L,
                "pre_calc_notice": notice,
                "notice": base,
                "science_note_full": notice.get("science_note_full_fr" if L == "fr" else "science_note_full_en")
                or base.get("science_note_full"),
            }
        except ImportError:
            pass

    if sym_n in _TRANSITION_3D:
        notice = _3d_notice_en(sym_n, gen) if L == "en" else _3d_notice_fr(sym_n, gen)
        return {
            "success": True,
            "element": sym_n,
            "Z": z,
            "generator": gen,
            "family": "3d",
            "lang": L,
            "notice": notice,
        }

    notice = _default_notice_en(sym_n, gen, z) if L == "en" else _default_notice_fr(sym_n, gen, z)
    return {
        "success": True,
        "element": sym_n,
        "Z": z,
        "generator": gen,
        "family": "main",
        "lang": L,
        "notice": notice,
    }

#!/bin/bash
# Déploie generation_pseudos v1.2 sur hiadsi1959.github.io/interfaces-qe-hiadsi
# Usage : ./scripts/deploy_site_v1.2.sh [--no-push]
set -euo pipefail
# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
cd "$HERE"

STAMP="2026-09-05"
NO_PUSH=0
[[ "${1:-}" == "--no-push" || "${2:-}" == "--no-push" ]] && NO_PUSH=1

ARCHIVE="$HERE/dist/generation_pseudos_v1.2_${STAMP}.tar.gz"
CANON="$HERE/dist/generation_pseudos-v1.2.tar.gz"
DEPLOY="${SITE_REPO:-$HOME/interfaces-qe-hiadsi-deploy}"

echo "=== Emballage v1.2 ==="
bash "$HERE/scripts/emballer.sh" --output "$ARCHIVE" --quiet
cp "$ARCHIVE" "$CANON"
ls -lh "$ARCHIVE"

if [[ ! -d "$DEPLOY/.git" ]]; then
  echo "Clone sparse du site dans $DEPLOY …"
  git clone --depth 1 --filter=blob:none --sparse \
    https://github.com/hiadsi1959/interfaces-qe-hiadsi.git "$DEPLOY"
  git -C "$DEPLOY" sparse-checkout init --no-cone
  git -C "$DEPLOY" sparse-checkout set /index.html /README.md /telechargements/
fi

echo "=== Synchronisation du site ==="
git -C "$DEPLOY" pull --rebase origin main

echo "=== Mise à jour index.html (interface 02 uniquement) ==="
python3 - "$STAMP" "$DEPLOY/index.html" << 'PY'
import sys
from pathlib import Path
stamp, path = sys.argv[1], Path(sys.argv[2])
text = path.read_text(encoding="utf-8")
old_arch = "generation_pseudos_v1.1_2026-08-31.tar.gz"
new_arch = f"generation_pseudos_v1.2_{stamp}.tar.gz"
if old_arch not in text and new_arch not in text:
    # déjà v1.2 avec une autre date, ou format inattendu
    text = text.replace("generation_pseudos_v1.1_", f"generation_pseudos_v1.2_")
text = text.replace(old_arch, new_arch)
repls = [
    ('"name": "Pseudopotential Generator v1.1"',
     '"name": "Pseudopotential Generator v1.2"'),
    ("Pseudopotential Generator v1.1, autonome",
     "Pseudopotential Generator v1.2, autonome"),
    ("<span class=\"tag tag-version\">v1.1 · 2026-08-31</span></h3>\n              <p><strong>Description.</strong> Unité centralisée",
     "<span class=\"tag tag-version\">v1.2 · 2026-09-05</span></h3>\n              <p><strong>Description.</strong> Unité centralisée"),
    ("<strong>Version 1.1</strong> — <strong>autonome</strong> (générateurs ld1.x, APE, ATOMPAW, ONCVPSP embarqués) ;\n              lanthanides 4f via gabarits PseudoDojo (note scientifique avant calcul).",
     "<strong>Version 1.2</strong> — <strong>autonome</strong> (générateurs ld1.x, APE, ATOMPAW, ONCVPSP embarqués) ;\n              audit physique (XC, relativité, 4f/5f), support théorique Word/PPT, lanthanides 4f via gabarits PseudoDojo."),
    ("<span class=\"tag tag-version\">v1.1 · 2026-08-31</span></h3>\n              <p><strong>Description.</strong> A centralized tool",
     "<span class=\"tag tag-version\">v1.2 · 2026-09-05</span></h3>\n              <p><strong>Description.</strong> A centralized tool"),
    ("<strong>Version 1.1</strong> — <strong>standalone</strong> (ld1.x, APE, ATOMPAW, ONCVPSP generators bundled);\n              lanthanides 4f via PseudoDojo templates (science note before calculation).",
     "<strong>Version 1.2</strong> — <strong>standalone</strong> (ld1.x, APE, ATOMPAW, ONCVPSP generators bundled);\n              physics audit (XC, relativity, 4f/5f), theoretical notes (Word/PPT), 4f via PseudoDojo templates."),
    ("<span class=\"flow-n\">02</span><strong>Pseudos</strong><span>v1.1</span>",
     "<span class=\"flow-n\">02</span><strong>Pseudos</strong><span>v1.2</span>"),
    ("Pseudopotential Generator <span class=\"tag tag-version\">v1.1 · 2026-08-31</span>",
     "Pseudopotential Generator <span class=\"tag tag-version\">v1.2 · 2026-09-05</span>"),
    ("<strong>v1.1</strong> — <strong>autonome</strong> (generators bundled in <code>./bin/</code>;",
     "<strong>v1.2</strong> — <strong>autonome</strong> (generators bundled in <code>./bin/</code>;"),
    (">v1.1 · autonome · 2026-08-31</span>",
     ">v1.2 · autonome · 2026-09-05</span>"),
    ('data-label="Pseudopotential Generator v1.1"',
     'data-label="Pseudopotential Generator v1.2"'),
    ("Pseudopotential Generator</strong> — search, select &amp; generate <span class=\"tag tag-version\">v1.1 · 2026-08-31</span>",
     "Pseudopotential Generator</strong> — search, select &amp; generate <span class=\"tag tag-version\">v1.2 · 2026-09-05</span>"),
    ("Example — Pseudopotential Generator v1.1",
     "Example — Pseudopotential Generator v1.2"),
    ("<option value=\"generation_pseudos\">Pseudopotential Generator v1.1</option>",
     "<option value=\"generation_pseudos\">Pseudopotential Generator v1.2</option>"),
]
for a, b in repls:
    text = text.replace(a, b)
path.write_text(text, encoding="utf-8")
print("index.html mis à jour pour", stamp)
if "generation_pseudos_v1.1_" in text:
    print("ATTENTION : il reste des liens v1.1 generation_pseudos")
PY

mkdir -p "$DEPLOY/telechargements"
cp "$ARCHIVE" "$DEPLOY/telechargements/generation_pseudos_v1.2_${STAMP}.tar.gz"
cp "$CANON" "$DEPLOY/telechargements/generation_pseudos-v1.2.tar.gz"

# README : ligne interface 02 uniquement
if [[ -f "$DEPLOY/README.md" ]]; then
  python3 - "$DEPLOY/README.md" << 'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
t = p.read_text(encoding="utf-8")
t = t.replace(
    "Pseudopotential Generator v1.1 | `telechargements/generation_pseudos_v1.1_2026-08-29.tar.gz` (aussi `generation_pseudos-v1.1.tar.gz` / `generation_pseudos.tar.gz`) — autonome ; lanthanides 4f PseudoDojo · 2026-08-29",
    "Pseudopotential Generator v1.2 | `telechargements/generation_pseudos_v1.2_2026-09-05.tar.gz` (aussi `generation_pseudos-v1.2.tar.gz`) — autonome ; audit physique ; support théorique · 2026-09-05",
)
p.write_text(t, encoding="utf-8")
print("README.md mis à jour")
PY
fi

cd "$DEPLOY"
git add --sparse index.html README.md \
  "telechargements/generation_pseudos-v1.2.tar.gz" \
  "telechargements/generation_pseudos_v1.2_${STAMP}.tar.gz"
git commit -m "Release Pseudopotential Generator v1.2 (${STAMP})" || true

if [[ "$NO_PUSH" == 1 ]]; then
  echo "Commit local OK — push manuel : cd $DEPLOY && git push origin main"
  exit 0
fi

git push origin main
echo "✅ Site : https://hiadsi1959.github.io/interfaces-qe-hiadsi/"
echo "   Archive : telechargements/generation_pseudos_v1.2_${STAMP}.tar.gz"

#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
#  vendor_libs.sh — Embarque les bibliothèques dynamiques des binaires bin/
#  dans lib/ pour rendre l’interface portable sur un autre PC Linux.
#
#  Les binaires (ld1.x, pw.x, oncvpsp.x, ape, atompaw) dépendent de libs
#  non standard (Intel oneAPI : MKL/MPI, libxc, GSL, …). Ce script copie
#  ces bibliothèques (et leurs dépendances transitives) dans lib/, que
#  DEMARRER.sh ajoute à LD_LIBRARY_PATH au démarrage.
#
#  Usage :
#    ./scripts/vendor_libs.sh              # → lib/ à la racine du projet
#    ./scripts/vendor_libs.sh /chemin/dest # → dossier choisi
#    ./scripts/vendor_libs.sh --check      # vérifie seulement (sans copier)
# ═══════════════════════════════════════════════════════════════════════════════
set -euo pipefail

# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
cd "$SCRIPT_DIR"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
ok() { echo -e "   ${GREEN}✓ $*${NC}"; }
warn() { echo -e "   ${YELLOW}⚠ $*${NC}"; }
err() { echo -e "   ${RED}❌ $*${NC}"; }

DEST="${1:-lib}"
CHECK_ONLY=0
[ "${1:-}" = "--check" ] && { CHECK_ONLY=1; DEST="lib"; }

# Binaires dont on embarque les dépendances
BINS=(bin/ld1.x bin/pw.x bin/oncvpsp.x bin/ape bin/atompaw)

# Bibliothèques système universelles (glibc, runtime GCC, zlib) — jamais embarquées.
# Présentes sur toute distribution Ubuntu/Debian ≥ 20.04.
SAFE='^(libc\.so\.6|libm\.so\.6|libmvec\.so\.1|libpthread\.so\.0|libdl\.so\.2|librt\.so\.1|libgcc_s\.so\.1|libgomp\.so\.1|libgfortran\.so\.5|libquadmath\.so\.0|libstdc\+\+\.so\.6|libz\.so\.1|libutil\.so\.1|libcrypt\.so\.1|linux-vdso\.so\.1|ld-linux.*)$'

declare -A DONE
MISSING=0

collect() {
    # $1 = fichier (binaire ou .so) dont on résout les dépendances
    local file="$1" line name path real
    [ -f "$file" ] || return 0
    while IFS= read -r line; do
        [[ "$line" == *"=>"* ]] || continue
        name="${line%% =>*}"
        name="${name//[[:space:]]/}"
        [[ -n "$name" ]] || continue
        [[ "$name" =~ $SAFE ]] && continue
        path="${line#*=> }"
        path="${path%% (*}"
        path="${path//[[:space:]]/}"
        if [ -z "$path" ] || [ ! -f "$path" ]; then
            err "$name introuvable pour $file"
            MISSING=1
            continue
        fi
        [[ -n "${DONE[$name]:-}" ]] && continue
        DONE[$name]=1
        real="$(readlink -f "$path")"
        if [ "$CHECK_ONLY" -eq 1 ]; then
            ok "$name ← $real"
        else
            cp -f "$real" "$DEST/$name"
            ok "$name ← $real"
            collect "$real"   # dépendances transitives
        fi
    done < <(ldd "$file" 2>/dev/null || true)
}

echo -e "${CYAN}Bibliothèques dynamiques des binaires bin/${NC}"
echo "   Source : ${BINS[*]}"
[ "$CHECK_ONLY" -eq 1 ] && echo "   Mode   : vérification seule" || echo "   Cible  : $DEST/"
echo ""

if [ "$CHECK_ONLY" -eq 1 ]; then
    for b in "${BINS[@]}"; do
        [ -f "$b" ] || { warn "$b absent"; continue; }
        echo "── $b"
        collect "$b"
    done
    echo ""
    [ "$MISSING" -eq 1 ] && { err "Des dépendances sont introuvables."; exit 1; }
    echo -e "${GREEN}→ Toutes les dépendances non-système sont résolues.${NC}"
    exit 0
fi

mkdir -p "$DEST"
for b in "${BINS[@]}"; do
    [ -f "$b" ] || { warn "$b absent — ignoré"; continue; }
    echo "── $b"
    collect "$b"
done

size="$(du -sh "$DEST" | cut -f1)"
n="$(find "$DEST" -maxdepth 1 -type f | wc -l)"
echo ""
echo -e "${GREEN}✅ $n bibliothèque(s) dans $DEST/ ($size)${NC}"
echo "   DEMARRER.sh ajoute automatiquement : LD_LIBRARY_PATH=$PWD/$DEST"
echo "   Vérification : LD_LIBRARY_PATH=$PWD/$DEST ldd bin/ld1.x"
[ "$MISSING" -eq 1 ] && exit 1
exit 0
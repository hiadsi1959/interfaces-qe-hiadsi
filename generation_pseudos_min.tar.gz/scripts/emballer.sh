#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
#  emballer.sh — Compacter le projet en archive tar.gz (dist/)
# ═══════════════════════════════════════════════════════════════════════════════
#
#  L’archive doit être AUTONOME sur le PC cible : elle contient l’interface,
#  l’API, les 5 exécutables de bin/ (ld1.x, pw.x, oncvpsp.x, ape, atompaw),
#  leurs bibliothèques lib/ et les gabarits ONCV/APE/ATOMPAW.
#  En mode léger, les liens symboliques sont SUIVIS (−h) et third_party/ est
#  exclu : aucun lien cassé ne peut subsister après extraction.
#  Une vérification est lancée après création et l’archive est refusée
#  (code 1) si un exécutable manque ou si bin//lib/ contient un lien cassé.
#
#  Usage (sur ce PC) :
#    ./emballer.sh                  # léger (sans pseudos/ ni third_party/, ~300 Mo)
#    ./emballer.sh --complet        # avec pseudos/ et third_party/ (peut être très lourd)
#    ./emballer.sh --output ~/Bureau/mon_archive.tar.gz
#
#  Sur l'autre PC :
#    tar xzf generation_pseudos_*.tar.gz && cd generation_pseudos
#    ./configure.sh && ./DEMARRER.sh
#
#  Options :
#    --leger          Sans pseudos/ ni third_party/ — binaires copiés en dur (défaut)
#    --complet        Archive complète (inclut pseudos/ et third_party/)
#    --no-verify      Ne pas vérifier l’autonomie de l’archive
#    --output PATH    Chemin de sortie (défaut : dist/generation_pseudos_AAAA-MM-JJ.tar.gz)
#    --print-path     Affiche uniquement le chemin de l’archive
#    --quiet          Moins de messages
#    -h, --help       Aide
#
# ═══════════════════════════════════════════════════════════════════════════════
set -euo pipefail

# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
cd "$HERE"

GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'

LIGHT=1
PRINT_PATH=0
QUIET=0
NO_VERIFY=0
OUT=""
STAMP="$(date +%Y%m%d)"

usage() {
    sed -n '6,22p' "$0" | sed 's/^# //'
    exit 0
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --leger|--light|--sans-pseudos) LIGHT=1; shift ;;
        --complet|--full|--avec-pseudos) LIGHT=0; shift ;;
        --output|-o) OUT="${2:-}"; shift 2 ;;
        --print-path) PRINT_PATH=1; shift ;;
        --no-verify|--sans-verification) NO_VERIFY=1; shift ;;
        --quiet) QUIET=1; shift ;;
        -h|--help) usage ;;
        *) echo -e "${YELLOW}Option inconnue : $1${NC}" >&2; usage ;;
    esac
done

log() { [ "$QUIET" = 1 ] || echo -e "$@"; }

# ── Vérification de l’autonomie de l’archive ─────────────────────────────────
#  Contrôle, sans extraire : liens cassés, exécutables de bin/, bibliothèques
#  lib/ et fichiers de l’interface. Retourne 1 si l’archive est inutilisable.
_verifier_archive() {
    local archive="$1" mode="$2" racine="$3"
    if ! command -v python3 >/dev/null 2>&1; then
        log "${YELLOW}⚠ python3 absent — vérification de l’archive ignorée${NC}"
        return 0
    fi
    python3 - "$archive" "$mode" "$racine" <<'PY'
import os, sys, tarfile

archive, mode, racine = sys.argv[1], sys.argv[2], sys.argv[3]
prefixe = racine.rstrip('/') + '/'


def _rel(name):
    """Nom de membre sans le dossier racine du projet."""
    if name == racine:
        return ''
    return name[len(prefixe):] if name.startswith(prefixe) else name
REQUIRED = ('bin/ld1.x', 'bin/pw.x', 'bin/oncvpsp.x', 'bin/ape', 'bin/atompaw')
UI = ('index.html', 'config_chemins.js', 'script_tableau_periodique.js',
      'api_pseudos_standalone.py', 'requirements.txt')
TEMPLATES = ('oncv_default_Cu.dat', 'oncv_default_14_Si.dat',
             'oncv_templates_3d/Ni.dat', 'pseudo_generator_templates')

# Le DERNIER membre gagne à l’extraction (tar) : on écrase les entrées précédentes.
types = {}
n_lib = n_pseudos = 0
with tarfile.open(archive, 'r:gz') as tf:
    for m in tf:
        name = m.name
        if name.startswith('./'):
            name = name[2:]
        name = _rel(name)
        if m.isdir():
            types[name] = ('d', '')
        elif m.issym():
            types[name] = ('l', m.linkname)
        elif m.islnk():
            # lien matériel : linkname est un nom de membre absolu dans l’archive
            types[name] = ('h', _rel(m.linkname))
        elif m.isfile():
            types[name] = ('f', '')
            if name.startswith('lib/') and os.path.basename(name):
                n_lib += 1
            elif name.startswith('pseudos/'):
                n_pseudos += 1

problems, warnings = [], []

# 1) Liens de l’archive : la cible doit être présente (sinon cassé après extraction)
for name, (kind, link) in types.items():
    if kind not in ('l', 'h') or not link:
        continue
    critique = name.startswith(('bin/', 'lib/'))
    if os.path.isabs(link):
        msg = f'lien absolu (valable sur la machine source seulement) : {name} → {link}'
        (problems if critique else warnings).append(msg)
        continue
    if kind == 'h':
        cible = os.path.normpath(link)          # déjà relatif à la racine de l’archive
    else:
        cible = os.path.normpath(os.path.join(os.path.dirname(name), link))
    if cible not in types:
        msg = f'lien cassé après extraction : {name} → {link}'
        (problems if critique else warnings).append(msg)

# 2) Exécutables des 4 générateurs (+ pw.x) réellement présents
for name in REQUIRED:
    kind, link = types.get(name, ('', ''))
    if not kind:
        problems.append(f'exécutable absent : {name}')
    elif kind == 'l':
        cible = os.path.normpath(os.path.join(os.path.dirname(name), link))
        if cible not in types:
            problems.append(f'exécutable par lien cassé : {name} → {link}')
        else:
            warnings.append(f'exécutable par lien symbolique : {name} → {link}')
    elif kind not in ('f', 'h'):
        problems.append(f'exécutable invalide ({kind}) : {name}')

# 3) Interface et gabarits de génération
for name in UI + TEMPLATES:
    if name not in types:
        warnings.append(f'attendu mais absent : {name}')

# 4) Bibliothèques embarquées (nécessaires aux binaires sur un autre PC)
if n_lib == 0:
    warnings.append('lib/ vide ou absent — les binaires risquent de ne pas démarrer')
if mode == 'leger' and n_pseudos:
    warnings.append(f'{n_pseudos} fichier(s) de pseudos/ inclus malgré le mode léger')

mode_txt = 'léger (sans pseudos/ ni third_party/)' if mode == 'leger' else 'complet'
print(f'   Contenu ({mode_txt}) : {len(types)} entrées · {n_lib} bibliothèque(s) dans lib/ · {n_pseudos} pseudo(s)')
for w in warnings:
    print(f'   ⚠ {w}')
for p in problems:
    print(f'   ✗ {p}')
if problems:
    print('   → archive NON autonome : corrigez les points ci-dessus puis relancez emballer.sh.')
    sys.exit(1)
print('   ✓ archive autonome : exécutables, lib/ et interface présents, aucun lien cassé.')
PY
}

DIST="$HERE/dist"
mkdir -p "$DIST"
if [[ -z "$OUT" ]]; then
    OUT="$DIST/generation_pseudos_${STAMP}.tar.gz"
else
    OUT="$(readlink -f "$OUT" 2>/dev/null || echo "$OUT")"
    mkdir -p "$(dirname "$OUT")"
fi

PARENT="$(dirname "$HERE")"
NAME="$(basename "$HERE")"

EXCLUDES=(
    --exclude='logs/*.log'
    --exclude='logs/*.pid'
    --exclude='CRASH'
    --exclude='tmp/*'
    --exclude='archive'
    --exclude='_work/*'
    --exclude='dist'
    --exclude='oncvpsp-master'
    --exclude='oncvpsp-master.zip'
    --exclude='.git'
    --exclude='__pycache__'
    --exclude='*.pyc'
    --exclude='api.pid'
    --exclude='server.pid'
    --exclude='pseudos_telechargés*'
    --exclude='pseudos-*/_runs/*'
    --exclude='pseudos_generes/*'
)
if [ "$LIGHT" = 1 ]; then
    EXCLUDES+=(--exclude='pseudos' --exclude='third_party')
fi

if [ "$PRINT_PATH" = 0 ]; then
    log "${CYAN}${BOLD}📦 Emballage du projet${NC}"
    log "   Source : $HERE"
    log "   Cible  : $OUT"
    if [ "$LIGHT" = 1 ]; then
        log "   Mode   : ${GREEN}léger${NC} (sans pseudos/ ni third_party/ ; bin/ + lib/ inclus, liens suivis)"
    else
        log "   Mode   : ${YELLOW}complet${NC} (peut prendre plusieurs minutes)"
    fi
    log ""
fi

TAR_RC=0
if [ "$LIGHT" = 1 ]; then
    # −h : suit les liens symboliques → bin/ape, bin/ld1.x… sont stockés comme
    # vrais fichiers, même si third_party/ est exclu (aucun lien cassé possible).
    tar czhf "$OUT" "${EXCLUDES[@]}" -C "$PARENT" "$NAME" || TAR_RC=$?
    MODE=leger
else
    tar czf "$OUT" "${EXCLUDES[@]}" -C "$PARENT" "$NAME" || TAR_RC=$?
    MODE=complet
fi

if [ "$TAR_RC" -ne 0 ]; then
    echo -e "${RED}❌ tar a échoué (code $TAR_RC)${NC}" >&2
    echo -e "   Cause fréquente : un lien cassé dans bin/ (ex. bin/ape → third_party/)" >&2
    echo -e "   Correctif : bash scripts/vendor_generators.sh puis relancez emballer.sh" >&2
    rm -f "$OUT"
    exit 1
fi

if [ ! -f "$OUT" ]; then
    echo "❌ Échec : archive introuvable." >&2
    exit 1
fi

# Vérification d’autonomie (avant --print-path : un appelant ne doit pas
# recevoir le chemin d’une archive inutilisable sur l’autre PC).
if [ "$NO_VERIFY" = 1 ]; then
    log "${YELLOW}⚠ vérification de l’autonomie ignorée (--no-verify)${NC}"
elif [ "$PRINT_PATH" = 1 ]; then
    _verifier_archive "$OUT" "$MODE" "$NAME" >&2 || exit 1
else
    if ! _verifier_archive "$OUT" "$MODE" "$NAME"; then
        echo -e "${RED}❌ Archive non transférable : $OUT${NC}" >&2
        exit 1
    fi
fi

if [ "$PRINT_PATH" = 1 ]; then
    echo "$OUT"
    exit 0
fi

SIZE="$(du -h "$OUT" | cut -f1)"
log "${GREEN}✅ Archive créée (${SIZE}) — autonome et vérifiée${NC}"
log "   $OUT"
log ""
log "${BOLD}── Sur l’autre PC ──${NC}"
log "   tar xzf $(basename "$OUT")"
log "   cd ${NAME} && ./configure.sh && ./DEMARRER.sh"
log ""
log "   Envoi réseau : ./TRANSFERER_VERS_AUTRE_PC.sh --dest user@IP"
log "   Doc          : docs/TRANSFERT_AUTRE_PC.md"

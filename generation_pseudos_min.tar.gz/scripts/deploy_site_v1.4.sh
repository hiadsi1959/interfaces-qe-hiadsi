#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
#  deploy_site_v1.4.sh — Publier generation_pseudos v1.4 (2026-10-21)
#  sur https://hiadsi1959.github.io/interfaces-qe-hiadsi/
# ═══════════════════════════════════════════════════════════════════════════════
#
#  Étapes :
#    1. Emballage de l’interface (mode léger, autonomie vérifiée)
#       → dist/generation_pseudos_v1.4_2026-10-21.tar.gz  (~131 Mo)
#       → dist/generation_pseudos-v1.4.tar.gz             (alias)
#    2. Publication du .tar.gz comme ASSET DE RELEASE GitHub (tag v1.4) :
#       l’archive embarque bin/ + lib/ (~300 Mo décompressés, 131 Mo compressés),
#       au-dessus de la limite GitHub de 100 Mo par fichier du dépôt — la Release
#       (limite 2 Go par asset) est donc le seul hébergement possible en .tar.gz.
#    3. Mise à jour de la rubrique « pseudos » du site : v1.4 · 2026-10-21,
#       bouton Download pointant vers l’asset de Release, et rubrique Installation
#       détaillant la configuration sur un autre PC.
#    4. REMPLACEMENT de l’ancienne v1.3 : suppression du dépôt du site des archives
#       generation_pseudos_v1.3_2026-09-15.tar.gz, generation_pseudos-v1.3.tar.gz
#       et generation_pseudos.tar.gz (alias v1.3).
#    5. Commit puis push sur origin main (sauf --no-push).
#
#  Usage :
#    ./scripts/deploy_site_v1.4.sh              # tout, y compris push + Release
#    ./scripts/deploy_site_v1.4.sh --no-push    # site + commit local, sans push
#    ./scripts/deploy_site_v1.4.sh --no-release # ne touche pas à la Release GitHub
#    SITE_REPO=/chemin/du/clone ./scripts/deploy_site_v1.4.sh
#
# ═══════════════════════════════════════════════════════════════════════════════
set -euo pipefail
# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
cd "$HERE"

NUMBER="1.4"
STAMP="2026-10-21"
OLD_NUMBER="1.3"
OLD_STAMP="2026-09-15"
REPO="hiadsi1959/interfaces-qe-hiadsi"
RELEASE_TAG="v${NUMBER}"
NO_PUSH=0
NO_RELEASE=0
for arg in "$@"; do
    case "$arg" in
        --no-push) NO_PUSH=1 ;;
        --no-release) NO_RELEASE=1 ;;
    esac
done

ARCHIVE="$HERE/dist/generation_pseudos_v${NUMBER}_${STAMP}.tar.gz"
CANON="$HERE/dist/generation_pseudos-v${NUMBER}.tar.gz"
DEPLOY="${SITE_REPO:-$HOME/interfaces-qe-hiadsi-deploy}"
DL_URL="https://github.com/${REPO}/releases/download/${RELEASE_TAG}/$(basename "$ARCHIVE")"

echo "=== Emballage v${NUMBER} (${STAMP}) ==="
bash "$HERE/scripts/emballer.sh" --output "$ARCHIVE" --quiet
cp "$ARCHIVE" "$CANON"
ls -lh "$ARCHIVE" "$CANON"
if [ "$(stat -c %s "$ARCHIVE")" -gt 104857600 ]; then
    echo "ℹ archive > 100 Mo : elle ne peut pas vivre dans le dépôt GitHub → Release (asset)." >&2
fi

# ── 1. Release GitHub (hébergement du .tar.gz) ───────────────────────────────
if [[ "$NO_RELEASE" == 1 ]]; then
    echo "=== Release GitHub v${NUMBER} : ignorée (--no-release) ==="
else
    echo "=== Release GitHub ${RELEASE_TAG} ==="
    if gh release view "$RELEASE_TAG" -R "$REPO" >/dev/null 2>&1; then
        gh release upload "$RELEASE_TAG" "$ARCHIVE" -R "$REPO" --clobber
        echo "✓ asset remplacé sur la Release ${RELEASE_TAG}"
    else
        gh release create "$RELEASE_TAG" "$ARCHIVE" -R "$REPO" \
            --title "Pseudopotential Generator v${NUMBER} (${STAMP})" \
            --notes "$(cat <<EOF
Interface **Génération & base de pseudopotentials** — v${NUMBER} · ${STAMP}.

Archive autonome (\`$(basename "$ARCHIVE")\`, ~131 Mo) : interface web, API Flask,
les **4 générateurs** (\`ld1.x\`, \`oncvpsp.x\`, \`ape\`, \`atompaw\`), \`pw.x\` et leurs
**bibliothèques dynamiques** (\`lib/\` : MKL, Intel MPI, libxc, GSL) + gabarits ONCV.

Installation sur un autre PC Linux (Python 3 suffit, Flask installé automatiquement) :

\`\`\`bash
tar xzf $(basename "$ARCHIVE")
cd generation_pseudos
./configure.sh      # une fois : prérequis système + pip + chemins relatifs + contrôle de lib/
./DEMARRER.sh       # à chaque session
# → http://127.0.0.1:5008/
\`\`\`

Nouveautés v1.4 : **correction des bandes fantômes** (états fantômes ONCVPSP). Le canal
\`s\` de Nh était généré avec \`nbas = 7\` (borne basse \`ncon + 3\`) et produisait un
\`WARNING - GHOST(+)\` ; la famille \`p7\` (Nh–Og) passe à \`nbas = (8, 7, 8, 8)\` et Nh sort
sans ghost (transfert 8.5 × 10⁻³ Ha, \`pw.x\` SCF \`JOB DONE\`). L’API ONCVPSP extrait
désormais l’UPF de la sortie fraîche d’\`oncvpsp.x\` avant de réutiliser un fichier de
\`_work/\` (un UPF périmé était resservi malgré un \`.dat\` neuf). Gabarits
\`oncv_templates_exotic\` régénérés ; 113/113 gabarits validés dans \`oncvpsp.x\`
(0 échec, 0 \`GHOST(-)\`). Les GHOST(+) résiduels des gabarits PseudoDojo
(\`main_group\`, quelques lanthanides/actinides) sont documentés comme non bloquants.

Site : https://hiadsi1959.github.io/interfaces-qe-hiadsi/ — Prof. S. HIADSI (LMESM, USTO-MB).
EOF
)"
        echo "✓ Release ${RELEASE_TAG} créée avec l’asset"
    fi
    gh release view "$RELEASE_TAG" -R "$REPO" --json url,assets \
        --jq '.url, (.assets[] | "   asset : \(.name) (\(.size) octets)")' || true
fi

# ── 2. Dépôt du site ─────────────────────────────────────────────────────────
if [[ ! -d "$DEPLOY/.git" ]]; then
    echo "Clone du site dans $DEPLOY …"
    git clone --depth 1 --filter=blob:none \
        https://github.com/hiadsi1959/interfaces-qe-hiadsi.git "$DEPLOY"
fi
git -C "$DEPLOY" sparse-checkout disable >/dev/null 2>&1 || true

echo "=== Reprise d’un éventuel run précédent ==="
git -C "$DEPLOY" reset -q
git -C "$DEPLOY" checkout -q -- . 2>/dev/null || true
rm -f "$DEPLOY/telechargements/generation_pseudos-v${NUMBER}.tar.gz" \
      "$DEPLOY/telechargements/generation_pseudos_v${NUMBER}_${STAMP}.tar.gz" \
      "$DEPLOY/telechargements/generation_pseudos.tar.xz"

echo "=== Synchronisation du site ==="
git -C "$DEPLOY" pull --rebase -q origin main

echo "=== Mise à jour index.html (interface 02 uniquement) ==="
python3 - "$DEPLOY/index.html" "$NUMBER" "$STAMP" "$OLD_NUMBER" "$OLD_STAMP" "$DEPLOY" "$DL_URL" << 'PY'
import re
import sys
from pathlib import Path

path = Path(sys.argv[1])
num, stamp, old_num, old_stamp = sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5]
deploy = Path(sys.argv[6])
dl_url = sys.argv[7]
tag = f"v{num}"
new_arch = f"generation_pseudos_v{num}_{stamp}.tar.gz"
old_arch = f"generation_pseudos_v{old_num}_{old_stamp}.tar.gz"

text = path.read_text(encoding="utf-8")
missing = []


def sub(old, new):
    """Remplacement strict mais idempotent : l’ancre manquante est signalée
    seulement si le texte de remplacement n’est pas déjà présent."""
    global text
    if old in text:
        text = text.replace(old, new)
    elif new not in text:
        missing.append(old[:70])


# ── Métadonnées de la page (JSON-LD) ─────────────────────────────────────────
sub('"name": "Pseudopotential Generator v1.3",',
    f'"name": "Pseudopotential Generator v{num}",')
sub("Pseudopotential Generator v1.3, autonome",
    f"Pseudopotential Generator v{num}, autonome")

# ── Panneau de présentation français ─────────────────────────────────────────
sub(f'Génération &amp; base de pseudopotentiels <span class="tag tag-version">v{old_num} · {old_stamp}</span>',
    f'Génération &amp; base de pseudopotentiels <span class="tag tag-version">v{num} · {stamp}</span>')
sub(f'<strong>Version {old_num}</strong> — <strong>autonome</strong> (générateurs ld1.x, APE, ATOMPAW, ONCVPSP embarqués) ;',
    f'<strong>Version {num}</strong> — <strong>autonome</strong> (générateurs ld1.x, APE, ATOMPAW, ONCVPSP embarqués) ;')
sub('transfert et installation assistés sur un autre PC (prérequis installés automatiquement, '
    'chemins relatifs, bibliothèques embarquées vérifiées) ; gabarits 4d et actinides complétés ; '
    'audit physique (XC, relativité, 4f/5f).</p>',
    'correction des bandes fantômes ONCVPSP (états GHOST(+) : canal s de Nh, famille p7 '
    'nbas = (8, 7, 8, 8)) et de la réutilisation d’UPF périmé par l’API ; 113/113 gabarits '
    'revalidés dans oncvpsp.x (0 échec, 0 GHOST(-)) ; installation assistée sur un autre PC '
    '(chemins relatifs, bibliothèques embarquées vérifiées) ; audit physique (XC, relativité, 4f/5f).</p>')

# ── Panneau de présentation anglais ──────────────────────────────────────────
sub(f'Pseudopotential Generator &amp; Database <span class="tag tag-version">v{old_num} · {old_stamp}</span>',
    f'Pseudopotential Generator &amp; Database <span class="tag tag-version">v{num} · {stamp}</span>')
sub(f'<strong>Version {old_num}</strong> — <strong>standalone</strong> (ld1.x, APE, ATOMPAW, ONCVPSP generators bundled);',
    f'<strong>Version {num}</strong> — <strong>standalone</strong> (ld1.x, APE, ATOMPAW, ONCVPSP generators bundled);')
sub('guided transfer and setup on another PC (prerequisites installed automatically, relative paths, '
    'bundled libraries verified); 4d and actinide templates completed; physics audit (XC, relativity, 4f/5f).</p>',
    'ONCVPSP ghost-state fix (GHOST(+) on the Nh s channel, p7 family '
    'nbas = (8, 7, 8, 8)) and fix for stale UPF reuse in the API; 113/113 templates '
    'revalidated in oncvpsp.x (0 failure, 0 GHOST(-)); guided setup on another PC '
    '(relative paths, bundled libraries verified); physics audit (XC, relativity, 4f/5f).</p>')

# ── Bandeau « parcours » ─────────────────────────────────────────────────────
sub(f'<strong>Pseudos</strong><span>v{old_num}</span>',
    f'<strong>Pseudos</strong><span>v{num}</span>')

# ── Fiche interface 02 ───────────────────────────────────────────────────────
sub(f'Pseudopotential Generator <span class="tag tag-version">v{old_num} · {old_stamp}</span>',
    f'Pseudopotential Generator <span class="tag tag-version">v{num} · {stamp}</span>')
sub(f'<strong>v{old_num}</strong> — <strong>autonome</strong> (generators bundled in <code>./bin/</code>;',
    f'<strong>v{num}</strong> — <strong>autonome</strong> (generators bundled in <code>./bin/</code>;')
sub(f'>v{old_num} · autonome · {old_stamp}</span>',
    f'>v{num} · autonome · {stamp}</span>')
sub('data-label="Pseudopotential Generator v1.3"',
    f'data-label="Pseudopotential Generator v{num}"')
sub(f'data-file="telechargements/{old_arch}"', f'data-file="{dl_url}"')

# ── Vue d’ensemble de la suite ───────────────────────────────────────────────
sub(f'— search, select &amp; generate <span class="tag tag-version">v{old_num} · {old_stamp}</span>',
    f'— search, select &amp; generate <span class="tag tag-version">v{num} · {stamp}</span>')

# ── Rubrique Installation : exemple v1.3 ─────────────────────────────────────
sub('Example — Pseudopotential Generator v1.3',
    f'Example — Pseudopotential Generator v{num}')
sub(f'<pre>tar -xzf {old_arch}\ncd generation_pseudos\n./DEMARRER.sh\n'
    '# → http://127.0.0.1:5008/\n'
    '# Interface autonome : générateurs ld1 / APE / ATOMPAW / ONCV dans ./bin/</pre>',
    f'<pre>wget {dl_url}\ntar xzf {new_arch}\ncd generation_pseudos\n'
    './configure.sh          # une fois : prérequis + dépendances Python + chemins relatifs\n'
    './DEMARRER.sh           # à chaque session\n'
    '# → http://127.0.0.1:5008/\n'
    '# Autonome : générateurs ld1 / APE / ATOMPAW / ONCV + lib/ dans ./bin/ et ./lib/</pre>')

# ── Formulaire d’avis ────────────────────────────────────────────────────────
sub('<option value="generation_pseudos">Pseudopotential Generator v1.3</option>',
    f'<option value="generation_pseudos">Pseudopotential Generator v{num}</option>')

# ── Rubrique Installation : procédure détaillée sur un autre PC ──────────────
anchor = ("          </p>\n"
          "        </div>\n"
          "      </div>\n"
          "    </section>\n"
          "\n"
          '    <section id="feedback">')
bloc = f"""          </p>
        </div>

        <div class="note-panel reveal" id="install-pseudos-autre-pc">
          <p><strong>Installation détaillée — Pseudopotential Generator v{num} sur un autre PC</strong>
          <span style="font-size:0.92em;opacity:0.9">(detailed setup on another machine)</span></p>
          <p style="font-size:0.95em">
            L’archive <code>{new_arch}</code> (~131 Mo compressés, ~300 Mo décompressés) est
            <strong>autonome</strong> : elle contient l’interface web, l’API Flask, les
            <strong>4 générateurs</strong> (<code>ld1.x</code>, <code>oncvpsp.x</code>, <code>ape</code>,
            <code>atompaw</code>), <code>pw.x</code>, leurs <strong>bibliothèques dynamiques</strong>
            (<code>lib/</code> : MKL, Intel MPI, libxc, GSL) et les gabarits ONCV.
            Sur le PC cible, <strong>seul Python 3 est nécessaire</strong> (Flask installé automatiquement) :
            <strong>Quantum&nbsp;ESPRESSO n’est pas requis</strong> pour les 4 générateurs.
          </p>
          <ol style="margin:0.6rem 0 0.6rem 1.2rem;font-size:0.95em">
            <li><strong>Télécharger</strong> l’archive : bouton <em>Download</em> de l’interface 02, ou
            directement l’asset de la Release GitHub
            <a href="{dl_url}">{tag}</a>. Le fichier est hébergé sur la Release
            (131 Mo, au-delà de la limite de 100 Mo par fichier du dépôt).</li>
            <li><strong>Transférer</strong> le fichier sur l’autre PC : clé USB, <code>scp</code> ou e-mail.</li>
            <li><strong>Extraire</strong> dans le dossier personnel, puis entrer dans
            <code>generation_pseudos/</code>.</li>
            <li><strong>Configurer une seule fois</strong> avec <code>./configure.sh</code> : il installe les
            prérequis système (<code>python3</code>, <code>python3-pip</code>, <code>curl</code>,
            <code>lsof</code>, <code>ca-certificates</code>, <code>xdg-utils</code> via <code>sudo</code>
            non interactif) puis les dépendances Python (<code>flask</code>, <code>flask-cors</code>,
            <code>requests</code>), supprime les liens cassés de <code>bin/</code>, vérifie que les binaires
            se chargent avec <code>lib/</code> (<code>ldd</code>), crée les 4 dossiers de sortie
            (<code>pseudos-ld1/</code>, <code>pseudos-APE/</code>, <code>pseudos-atompaw/</code>,
            <code>pseudos-oncvpsp/</code>) et écrit <code>api_config.json</code> en
            <strong>chemins relatifs au projet</strong> — l’installation reste donc valide quel que soit
            l’utilisateur ou le nom du dossier.</li>
            <li><strong>Démarrer</strong> à chaque session avec <code>./DEMARRER.sh</code> →
            <strong>http://127.0.0.1:5008/</strong> (arrêt : <code>./ARRETER.sh</code>).
            Ne <strong>jamais</strong> ouvrir <code>index.html</code> en <code>file://</code>.</li>
          </ol>
          <pre># 1) Sur le PC cible — téléchargement depuis la Release GitHub
wget {dl_url}
tar xzf {new_arch}
cd generation_pseudos

# 2) Configuration de ce PC (une seule fois)
./configure.sh                 # prérequis système + pip + chemins relatifs + contrôle de lib/
./configure.sh --no-install    # PC hors ligne : chemins seuls, aucune installation
./configure.sh --check-only    # diagnostic, sans rien modifier
./configure.sh --qe ~/q-e-qe-7.5/bin    # QE externe (facultatif : pw.x et ld1.x sont inclus)
./configure.sh --start         # configure et démarre en une commande

# 3) Démarrage
./DEMARRER.sh
# → http://127.0.0.1:5008/

# 4) Bibliothèques UPF (facultatif, plusieurs Go, une fois par poste)
./TELECHARGER_BASES.sh --quick   # ou onglet « Autres bases » de l’interface

# 5) Diagnostic complet sur ce PC
./verifier_installation.sh</pre>
          <p style="font-size:0.95em">
            <strong>Variante « un seul fichier ».</strong> <code>./build_installer.sh</code> construit
            <code>dist/generation_pseudos</code> (~105 Mo, même contenu en un fichier unique) :
            <code>chmod +x generation_pseudos &amp;&amp; ./generation_pseudos</code> installe dans
            <code>~/.local/share/generation_pseudos/app/</code>, se configure selon la machine et ouvre
            le navigateur ; <code>--install</code> ajoute la commande dans <code>~/.local/bin</code>,
            <code>--reconfig</code> reprend les chemins après un changement de machine ou de Quantum&nbsp;ESPRESSO.
          </p>
          <p style="font-size:0.95em">
            <strong>À noter.</strong> Si vous déplacez le dossier ou changez de PC, relancez
            <code>./configure.sh</code> (ou <code>--reconfig</code>) puis <strong>Ctrl+F5</strong> dans le
            navigateur pour purger les anciens chemins mémorisés côté client. Sur un PC vierge,
            <code>./configure.sh</code> suffit : il installe lui-même <code>python3-pip</code>,
            <code>curl</code>, <code>lsof</code>, les certificats TLS et un navigateur si nécessaire.
          </p>
          <ul style="font-size:0.93em;margin-top:0.4rem">
            <li>« API hors ligne » / port occupé → <code>lsof -i:5008</code> puis <code>./DEMARRER.sh</code>
            (ou <code>export GEN_PORT=5009</code>).</li>
            <li>Page sans style ou sans tableau → URL <code>http://127.0.0.1:5008/</code>, jamais <code>file://</code>.</li>
            <li>Chemins d’un autre PC dans <code>api_config.json</code> → <code>./configure.sh</code>
            (purge puis redétection en chemins relatifs).</li>
            <li><code>ldd bin/*</code> renvoie « not found » → <code>./configure.sh</code> ; sinon
            <code>bash scripts/vendor_generators.sh</code> sur le PC source et retransférer <code>lib/</code>.</li>
            <li>Transfert réseau automatique :
            <code>./TRANSFERER_VERS_AUTRE_PC.sh --leger --dest utilisateur@IP -y</code>.</li>
            <li>Guides complets : <code>docs/INSTALLATION_AUTRE_PC.md</code> et
            <code>docs/TRANSFERT_AUTRE_PC.md</code> (dans l’archive).</li>
          </ul>
        </div>
      </div>
    </section>

    <section id="feedback">"""
sub(anchor, bloc)

path.write_text(text, encoding="utf-8")

if missing:
    print("✗ ancres introuvables dans index.html :")
    for m in missing:
        print("   -", m)
    sys.exit(1)
if old_arch in text:
    print(f"✗ {old_arch} est encore référencée dans index.html")
    sys.exit(1)
print(f"✓ index.html mis à jour pour v{num} · {stamp}")

# ── Libellés des compteurs (js) ──────────────────────────────────────────────
for rel in ("js/main.js", "js/compteurs.js"):
    p = deploy / rel
    if not p.is_file():
        print(f"⚠ {rel} absent — libellé non mis à jour")
        continue
    t = p.read_text(encoding="utf-8")
    t2, n = re.subn(r'\{ id: "generation_pseudos", label: "Pseudopotential Generator v[0-9.]+" \}',
                    f'{{ id: "generation_pseudos", label: "Pseudopotential Generator v{num}" }}', t)
    if n:
        p.write_text(t2, encoding="utf-8")
        print(f"✓ {rel} mis à jour")
    else:
        print(f"⚠ {rel} : libellé generation_pseudos introuvable")

# ── README du site ───────────────────────────────────────────────────────────
readme = deploy / "README.md"
if readme.is_file():
    t = readme.read_text(encoding="utf-8")
    new_row = (f"| Pseudopotential Generator v{num} | Release GitHub "
               f"[`{tag}`](https://github.com/hiadsi1959/interfaces-qe-hiadsi/releases/tag/{tag}) "
               f"→ asset `{new_arch}` (131 Mo, > limite 100 Mo du dépôt) — autonome ; "
               f"installation assistée sur un autre PC ; gabarits 4d/actinides · {stamp} |")
    t2, n = re.subn(r"\| Pseudopotential Generator v[0-9.]+ \|.*?\|\n", new_row + "\n", t, count=1)
    if n:
        readme.write_text(t2, encoding="utf-8")
        print("✓ README.md mis à jour")
    else:
        print("⚠ README.md : ligne « Pseudopotential Generator » introuvable")
PY

echo "=== Remplacement de la v${OLD_NUMBER} dans le dépôt du site ==="
git -C "$DEPLOY" rm -q --ignore-unmatch \
  "telechargements/generation_pseudos_v${OLD_NUMBER}_${OLD_STAMP}.tar.gz" \
  "telechargements/generation_pseudos-v${OLD_NUMBER}.tar.gz" \
  "telechargements/generation_pseudos.tar.gz" || true

echo "=== Contrôle : plus aucune archive v${OLD_NUMBER} pseudos dans le dépôt ==="
if git -C "$DEPLOY" grep -n "generation_pseudos_v${OLD_NUMBER}_\|generation_pseudos-v${OLD_NUMBER}" \
     -- index.html README.md || git -C "$DEPLOY" ls-files "telechargements/generation_pseudos*" \
     | grep -q "v${OLD_NUMBER}\."; then
    echo "✗ des références à la v${OLD_NUMBER} subsistent — déploiement annulé" >&2
    exit 1
fi
git -C "$DEPLOY" ls-files "telechargements/generation_pseudos*" | sed 's/^/   /'
echo "✓ aucune archive v${OLD_NUMBER} pseudos"

cd "$DEPLOY"
git add index.html README.md js/main.js js/compteurs.js
git status --short
git commit -m "Release Pseudopotential Generator v${NUMBER} (${STAMP}) — install assistée sur un autre PC"

if [[ "$NO_PUSH" == 1 ]]; then
    echo "Commit local OK — push manuel : cd $DEPLOY && git push origin main"
    exit 0
fi

git push origin main
echo "✅ Site : https://hiadsi1959.github.io/interfaces-qe-hiadsi/"
echo "   Archive : ${DL_URL}"

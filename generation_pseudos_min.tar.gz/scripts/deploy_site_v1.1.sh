#!/bin/bash
# Déploie generation_pseudos v1.1 sur hiadsi1959.github.io/interfaces-qe-hiadsi
# Usage : ./scripts/deploy_site_v1.1.sh [--no-push]
set -euo pipefail
# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
cd "$HERE"

STAMP="${1:-$(date +%Y%m%d)}"
if [[ "${1:-}" == "--no-push" ]]; then STAMP="$(date +%Y%m%d)"; fi
NO_PUSH=0
[[ "${1:-}" == "--no-push" || "${2:-}" == "--no-push" ]] && NO_PUSH=1

ARCHIVE="$HERE/dist/generation_pseudos_v1.1_${STAMP}.tar.gz"
CANON="$HERE/dist/generation_pseudos-v1.1.tar.gz"
DEPLOY="${SITE_REPO:-$HOME/interfaces-qe-hiadsi-deploy}"

echo "=== Emballage v1.1 ==="
bash "$HERE/scripts/emballer.sh" --output "$ARCHIVE" --quiet
cp "$ARCHIVE" "$CANON"
ls -lh "$ARCHIVE"

if [[ ! -d "$DEPLOY/.git" ]]; then
  echo "Clone sparse du site dans $DEPLOY …"
  git clone --depth 1 --filter=blob:none --sparse \
    https://github.com/hiadsi1959/interfaces-qe-hiadsi.git "$DEPLOY"
  git -C "$DEPLOY" sparse-checkout init --no-cone
  git -C "$DEPLOY" sparse-checkout set /index.html /telechargements/
fi

echo "=== Mise à jour index.html (dates + lien téléchargement) ==="
python3 - "$STAMP" "$DEPLOY/index.html" << 'PY'
import sys
from pathlib import Path
stamp, path = sys.argv[1], Path(sys.argv[2])
text = path.read_text(encoding='utf-8')
text = text.replace('generation_pseudos_v1.1_2026-08-29.tar.gz', f'generation_pseudos_v1.1_{stamp}.tar.gz')
import re
text = re.sub(r'v1\.1 · 2026-\d{2}-\d{2}', f'v1.1 · {stamp[:4]}-{stamp[4:6]}-{stamp[6:8]}', text)
path.write_text(text, encoding='utf-8')
print('index.html mis à jour pour', stamp)
PY

mkdir -p "$DEPLOY/telechargements"
cp "$ARCHIVE" "$DEPLOY/telechargements/generation_pseudos_v1.1_${STAMP}.tar.gz"
cp "$CANON" "$DEPLOY/telechargements/generation_pseudos-v1.1.tar.gz"

cd "$DEPLOY"
git pull --rebase origin main
git add --sparse index.html \
  "telechargements/generation_pseudos-v1.1.tar.gz" \
  "telechargements/generation_pseudos_v1.1_${STAMP}.tar.gz"
git commit -m "Release Pseudopotential Generator v1.1 (${STAMP})" || true

if [[ "$NO_PUSH" == 1 ]]; then
  echo "Commit local OK — push manuel : cd $DEPLOY && git push origin main"
  exit 0
fi

git push origin main
echo "✅ Site : https://hiadsi1959.github.io/interfaces-qe-hiadsi/"
echo "   Archive : telechargements/generation_pseudos_v1.1_${STAMP}.tar.gz"

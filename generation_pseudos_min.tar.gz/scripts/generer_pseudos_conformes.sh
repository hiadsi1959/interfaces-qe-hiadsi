#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
#  generer_pseudos_conformes.sh — générer + vérifier la conformité en 1 commande
#
#  Couvre les 4 générateurs : ONCVPSP · ld1.x · APE · ATOMPAW.
#  Prérequis : API démarrée (./DEMARRER.sh).
#
#  Exemples :
#    ./GENERER_PSEUDOS.sh --elements Si Fe Ni
#    ./GENERER_PSEUDOS.sh --elements lanthanides --generateurs oncvpsp
#    ./GENERER_PSEUDOS.sh --elements tous --generateurs oncvpsp --resume
#    ./GENERER_PSEUDOS.sh --elements 3d --report dist/rapport_conformite.json
#
#  Le rapport JSON classe chaque (élément, générateur) en :
#    conforme · non_conforme · echec_generateur (limite du code pour l'élément)
#  Aide complète : python3 tools/generer_pseudos_conformes.py --help
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
cd "$HERE"

TOOL="$HERE/tools/generer_pseudos_conformes.py"
if [ ! -f "$TOOL" ]; then
    echo "❌ Outil introuvable : $TOOL" >&2
    exit 1
fi

PORT="${GEN_PORT:-5008}"
API="http://127.0.0.1:${PORT}"

if command -v curl >/dev/null 2>&1; then
    if ! curl -fsS --max-time 3 "$API/health" >/dev/null 2>&1; then
        echo "⚠  API hors ligne ($API)."
        echo "   Lancez d'abord : ./DEMARRER.sh"
        exit 1
    fi
fi

exec python3 "$TOOL" --api "$API" "$@"

#!/bin/bash
# vendor_generators.sh — Installe TOUS les exécutables dans ./bin/ (canonique)
#   bin/ld1.x  bin/pw.x  bin/oncvpsp.x  bin/ape  bin/atompaw
set -euo pipefail
# shellcheck source=_project_root.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_project_root.sh"
cd "$SCRIPT_DIR"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
ok() { echo -e "   ${GREEN}✔ $*${NC}"; }
warn() { echo -e "   ${YELLOW}⚠ $*${NC}"; }

_install_bin() {
    # $1=name_in_bin  $2..=source candidates (files)
    local name="$1"; shift
    local dst="bin/$name"
    local src="" c real
    mkdir -p bin
    for c in "$@"; do
        [[ -n "$c" && -e "$c" ]] || continue
        real="$(readlink -f "$c" 2>/dev/null || echo "$c")"
        [[ -f "$real" ]] || continue
        # ne pas prendre le dst lui-même comme source — sauf si dst est un lien
        # symbolique, qu’il faut remplacer par une vraie copie (archive autonome)
        if [[ ! -L "$dst" ]] && [[ "$real" == "$(readlink -f "$dst" 2>/dev/null || true)" ]]; then
            continue
        fi
        src="$real"
        break
    done
    if [[ -z "$src" ]]; then
        if [[ -x "$dst" && ! -L "$dst" ]]; then
            ok "$name déjà dans bin/ (conserve)"
            return 0
        fi
        return 1
    fi
    # Si dst est un symlink, le remplacer par une vraie copie
    rm -f "$dst"
    cp -f "$src" "$dst"
    chmod +x "$dst"
    ok "$name ← $src → bin/$name"
    return 0
}

echo -e "${CYAN}Installation des exécutables → ./bin/${NC}"
mkdir -p bin

# ── ld1.x + pw.x (définitif dans bin/) ───────────────────────────────────────
echo -e "${CYAN}  [QE] ld1.x + pw.x${NC}"
_install_bin ld1.x \
    "${LD1_SRC_OVERRIDE:-}" \
    "$SCRIPT_DIR/third_party/qe/bin/ld1.x" \
    "$SCRIPT_DIR/third_party/ld1/bin/ld1.x" \
    "$HOME/q-e-qe-7.5/atomic/src/ld1.x" \
    "$HOME/q-e-qe-7.5/bin/ld1.x" \
    "$(command -v ld1.x 2>/dev/null || true)" \
    || warn "ld1.x introuvable"

_install_bin pw.x \
    "${PW_SRC_OVERRIDE:-}" \
    "$SCRIPT_DIR/third_party/qe/bin/pw.x" \
    "$HOME/q-e-qe-7.5/PW/src/pw.x" \
    "$HOME/q-e-qe-7.5/bin/pw.x" \
    "$(command -v pw.x 2>/dev/null || true)" \
    || warn "pw.x introuvable (optionnel pour générer)"

# Miroir optionnel third_party/qe/bin → liens vers bin/ (compat)
if [[ -x bin/ld1.x || -x bin/pw.x ]]; then
    mkdir -p third_party/qe/bin third_party/ld1/bin
    for n in ld1.x pw.x; do
        if [[ -x "bin/$n" ]]; then
            rm -f "third_party/qe/bin/$n"
            ln -sfn "../../../bin/$n" "third_party/qe/bin/$n"
        fi
    done
    if [[ -x bin/ld1.x ]]; then
        rm -f third_party/ld1/bin/ld1.x
        ln -sfn ../../../bin/ld1.x third_party/ld1/bin/ld1.x
    fi
    ok "miroirs third_party/qe|ld1 → bin/"
fi

# ── ONCVPSP ──────────────────────────────────────────────────────────────────
echo -e "${CYAN}  [ONCVPSP]${NC}"
_install_bin oncvpsp.x \
    "${ONCV_SRC_OVERRIDE:-}" \
    "$SCRIPT_DIR/third_party/oncvpsp/bin/oncvpsp.x" \
    "$HOME/oncvpsp/build/bin/oncvpsp.x" \
    "$HOME/.local/bin/oncvpsp.x" \
    "$(command -v oncvpsp.x 2>/dev/null || true)" \
    || warn "oncvpsp.x introuvable"

if [[ -x bin/oncvpsp.x ]]; then
    mkdir -p third_party/oncvpsp/bin third_party/oncvpsp/tests
    rm -f third_party/oncvpsp/bin/oncvpsp.x
    ln -sfn ../../../bin/oncvpsp.x third_party/oncvpsp/bin/oncvpsp.x
    # tests/data : depuis third_party/oncvpsp/tests il faut remonter de 3 niveaux
    # (un ancien chemin à 2 niveaux laissait un lien cassé)
    if [[ -d data/oncvpsp_tests_data && ! -e third_party/oncvpsp/tests/data ]]; then
        rm -f third_party/oncvpsp/tests/data
        ln -sfn ../../../data/oncvpsp_tests_data third_party/oncvpsp/tests/data
    fi
    ok "miroir third_party/oncvpsp/bin → bin/oncvpsp.x"
fi

# Templates ONCV
if [[ -d "$HOME/oncvpsp/tests/data" ]]; then
    mkdir -p data/oncvpsp_tests_data
    n_local=$(find data/oncvpsp_tests_data -maxdepth 1 -type f 2>/dev/null | wc -l | tr -d ' ')
    if [[ "${n_local:-0}" -lt 5 ]]; then
        cp -an "$HOME/oncvpsp/tests/data/." data/oncvpsp_tests_data/ 2>/dev/null || true
        ok "templates → data/oncvpsp_tests_data/"
    fi
fi

# ── APE / ATOMPAW (copies RÉELLES dans bin/) ─────────────────────────────────
# Copie et non lien : ./emballer.sh --leger exclut third_party/, un lien
# bin/ape → ../third_party/... serait cassé après extraction sur l’autre PC.
echo -e "${CYAN}  [APE / ATOMPAW]${NC}"
_install_bin ape \
    "${APE_SRC_OVERRIDE:-}" \
    "$SCRIPT_DIR/third_party/ape/bin/ape" \
    "$HOME/.local/bin/ape" \
    "$(command -v ape 2>/dev/null || true)" \
    || warn "APE manquant — bash scripts/install_ape_atompaw.sh"
_install_bin atompaw \
    "${ATOMPAW_SRC_OVERRIDE:-}" \
    "$SCRIPT_DIR/third_party/atompaw/bin/atompaw" \
    "$SCRIPT_DIR/third_party/atompaw/bin/AtomPAW" \
    "$SCRIPT_DIR/third_party/atompaw/bin/atompaw.x" \
    "$HOME/.local/bin/atompaw" \
    "$(command -v atompaw 2>/dev/null || true)" \
    || warn "ATOMPAW manquant — bash scripts/install_ape_atompaw.sh"

echo ""
echo -e "${CYAN}  Contenu de bin/ :${NC}"
ls -lh bin/ld1.x bin/pw.x bin/oncvpsp.x bin/ape bin/atompaw 2>/dev/null || ls -lh bin/ | head -20
echo ""
echo "Ensuite : ./configure.sh -y && ./DEMARRER.sh"

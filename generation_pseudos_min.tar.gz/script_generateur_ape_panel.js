/**
 * Onglets APE / ATOMPAW (présentation scientifique) + fonctions gp* pour les modales.
 */
(function () {
    'use strict';

    window.gpAutoCache = window.gpAutoCache || {};

    function apiBase() {
        return typeof getApiPseudosBase === 'function' ? getApiPseudosBase() : 'http://127.0.0.1:5008';
    }

    function esc(s) {
        if (s == null) return '';
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function ensureGenRunResultStyles() {
        if (document.getElementById('gen-run-result-css')) return;
        if (typeof ensureLd1ModalScienceStyles === 'function') ensureLd1ModalScienceStyles();
        var s = document.createElement('style');
        s.id = 'gen-run-result-css';
        s.textContent = ''
            + '.gen-run-result{margin-top:12px;font-size:0.88rem;line-height:1.5;color:#cbd5e1;}'
            + '.gen-run-result--loading{padding:12px 14px;border-radius:10px;background:rgba(30,41,59,0.65);border:1px solid rgba(100,116,139,0.35);}'
            + '.gen-run-result__head{display:flex;align-items:flex-start;gap:12px;margin-bottom:12px;}'
            + '.gen-run-result__icon{font-size:1.6em;line-height:1;}'
            + '.gen-run-result__title{font-weight:600;font-size:1.02em;}'
            + '.gen-run-result__sub{color:#94a3b8;font-size:0.86em;margin-top:4px;}'
            + '.gen-run-result__box{padding:14px 16px;border-radius:10px;margin-top:10px;}'
            + '.gen-run-result__box--ok{background:#1a3a1a;border:1px solid #3fb950;}'
            + '.gen-run-result__box--warn{background:#2a2a1a;border:1px solid #f9e2af;}'
            + '.gen-run-result__box--err{background:#2a1a1a;border:1px solid #f38ba8;}'
            + '.gen-run-result__box--info{background:#1e3a5c;border:1px solid #3b82f6;}'
            + '.gen-run-result__box h4{margin:0 0 8px;font-size:0.95em;font-weight:600;}'
            + '.gen-run-result__paths{font-family:var(--font-mono,JetBrains Mono,monospace);font-size:0.78em;line-height:1.85;word-break:break-all;}'
            + '.gen-run-result__paths dt{color:#6c7086;margin-top:6px;}'
            + '.gen-run-result__paths dd{margin:2px 0 0;color:#e2e8f0;}'
            + '.gen-run-result__actions{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px;}'
            + '.gen-run-result__actions button{font-size:0.72em;padding:4px 10px;}'
            + '.gen-run-result details{margin-top:10px;}'
            + '.gen-run-result details summary{cursor:pointer;color:#89b4fa;font-size:0.86em;}'
            + '.gen-run-result pre{margin:8px 0 0;padding:10px;border-radius:8px;background:#11111b;border:1px solid #45475a;'
            + 'color:#cdd6f4;font-size:0.72em;white-space:pre-wrap;word-break:break-word;max-height:240px;overflow:auto;}'
            + '.gen-run-suite{display:flex;flex-wrap:wrap;gap:6px;}'
            + '.gen-run-suite__chip{display:inline-flex;align-items:center;padding:4px 10px;border-radius:999px;font-size:0.75em;font-weight:600;}'
            + '.gen-run-suite__chip--ok{background:rgba(34,197,94,0.18);border:1px solid #22c55e;color:#86efac;}'
            + '.gen-run-suite__chip--no{background:rgba(239,68,68,0.12);border:1px solid #f87171;color:#fca5a5;}';
        document.head.appendChild(s);
    }

    function jsStr(s) {
        return String(s || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    }

    function pathRow(label, value) {
        if (!value) return '';
        return '<dt>' + esc(label) + '</dt><dd>' + esc(value) + '</dd>';
    }

    window.renderGeneratorRunResult = function (j, opts) {
        ensureGenRunResultStyles();
        opts = opts || {};
        var engine = opts.label || (j.generator === 'ape' ? 'APE'
            : j.generator === 'atompaw' ? 'ATOMPAW'
            : j.generator === 'oncvpsp' ? 'ONCVPSP' : 'Générateur');
        var ok = !!j.success;
        var qeOk = !!(j.upf_qe_ready || (j.qe_validation && j.qe_validation.conform_qe));
        var runDone = !!(j.run_completed || j.run_ok || (j.returncode === 0 && !j.error));
        var upfPath = j.upf_path || '';
        var upfName = j.upf_genere || (upfPath ? String(upfPath).split('/').pop() : '');
        var qeFmt = (j.qe_validation && j.qe_validation.format) || '';
        var icon, title, titleColor, boxClass;

        if (ok) {
            icon = '✅';
            title = engine + ' — succès';
            titleColor = '#a6e3a1';
            boxClass = 'gen-run-result__box--ok';
        } else if (runDone && upfPath) {
            icon = '⚠️';
            title = engine + ' — UPF produit (vérification QE)';
            titleColor = '#f9e2af';
            boxClass = 'gen-run-result__box--warn';
        } else if (runDone) {
            icon = '⚠️';
            title = engine + ' — calcul terminé, pas de UPF conforme';
            titleColor = '#f9e2af';
            boxClass = 'gen-run-result__box--warn';
        } else {
            icon = '❌';
            title = engine + ' — échec';
            titleColor = '#f38ba8';
            boxClass = 'gen-run-result__box--err';
        }

        var subParts = [];
        if (j.diagnostic_summary) subParts.push(esc(j.diagnostic_summary));
        else if (j.error) subParts.push(esc(j.error));
        else if (j.fatal_errors && j.fatal_errors.length) subParts.push(esc(j.fatal_errors.join(' · ')));
        if (j.ape_stage) subParts.push('Étape APE : <strong>' + esc(j.ape_stage) + '</strong>');
        if (j.returncode != null) subParts.push('Code retour : <strong>' + esc(j.returncode) + '</strong>');

        var actions = '';
        if (upfPath) {
            actions += '<button type="button" class="btn-action btn-secondary-act" onclick="navigator.clipboard.writeText(\''
                + jsStr(upfPath) + '\').then(function(){if(typeof _showToast===\'function\')_showToast(\'Chemin UPF copié\',\'#6366f1\',2000);})">Copier chemin UPF</button>';
        }
        if (upfName && typeof voirContenuPseudo === 'function') {
            actions += '<button type="button" class="btn-action btn-secondary-act" onclick="voirContenuPseudo(\''
                + jsStr(upfName) + '\')">Aperçu UPF</button>';
        }

        var saveHtml = '';
        if (j.copied_to_pseudos_generes && j.copied_to_pseudos_generes.length) {
            var bucketLabel = j.pseudos_bucket ? String(j.pseudos_bucket).split('/').pop() : 'dossier générateur';
            saveHtml = '<div class="gen-run-result__box gen-run-result__box--info">'
                + '<h4 style="color:#93c5fd;">Sauvegarde — <code>' + esc(bucketLabel) + '</code></h4>'
                + '<dl class="gen-run-result__paths">'
                + pathRow('Dossier', j.pseudos_generes_dir || j.pseudos_bucket)
                + pathRow('Fichier UPF', j.copied_to_pseudos_generes.join(', '))
                + pathRow('Bibliothèque pw.x', j.saved_to_pseudos_dir)
                + '</dl></div>';
        } else if (qeOk && j.saved_to_pseudos_dir) {
            saveHtml = '<div class="gen-run-result__box gen-run-result__box--info">'
                + '<h4 style="color:#93c5fd;">Enregistré dans la bibliothèque</h4>'
                + '<dl class="gen-run-result__paths">' + pathRow('Bibliothèque pw.x', j.saved_to_pseudos_dir) + '</dl></div>';
        } else if (runDone && upfPath && !qeOk) {
            saveHtml = '<p style="color:#f38ba8;font-size:0.82em;margin:8px 0 0;">UPF non conforme QE — non archivé automatiquement.</p>';
        }

        var warnHtml = '';
        var warns = [].concat(j.warnings || [], j.note ? [j.note] : []);
        if (warns.length) {
            warnHtml = '<div style="margin-top:10px;padding:10px 12px;border-radius:8px;background:rgba(42,32,16,0.55);border:1px solid #f9e2af;">'
                + '<div style="color:#f9e2af;font-weight:600;font-size:0.84em;margin-bottom:4px;">Avertissements</div>'
                + '<ul style="margin:0;padding-left:18px;color:#e2e8f0;font-size:0.82em;">'
                + warns.map(function (w) { return '<li>' + esc(w) + '</li>'; }).join('')
                + '</ul></div>';
        }

        var hintHtml = '';
        if (j.hint) {
            hintHtml = '<p style="margin:10px 0 0;padding:10px 12px;border-radius:8px;background:rgba(30,58,95,0.45);'
                + 'border:1px solid rgba(59,130,246,0.35);color:#93c5fd;font-size:0.82em;">'
                + '<strong>Conseil :</strong> ' + esc(j.hint) + '</p>';
        }

        var oncvFlags = '';
        if (j.generator === 'oncvpsp') {
            var flags = [];
            if (j.upf_in_stdout) flags.push('UPF (XML) détecté dans stdout');
            if (j.psp8_in_stdout) flags.push('Format psp8 dans stdout');
            if (j.psfile_used) flags.push('psfile : ' + j.psfile_used);
            if (flags.length) {
                oncvFlags = '<p style="color:#6c7086;font-size:0.8em;margin:6px 0 0;">' + esc(flags.join(' · ')) + '</p>';
            }
        }

        var files = j.files_in_workdir || j.files_in_tmp || [];
        var filesHtml = '';
        if (files.length) {
            var fileLines = files.slice(0, 12).map(function (f) {
                var nm = f.name || f;
                var p = f.path || '';
                var sz = f.size != null ? ' (' + f.size + ' o)' : '';
                return esc(nm + sz + (p ? ' → ' + p : ''));
            }).join('\n');
            if (files.length > 12) fileLines += '\n… +' + (files.length - 12) + ' fichier(s)';
            filesHtml = '<details><summary>Fichiers dans le répertoire de travail (' + files.length + ')</summary>'
                + '<pre>' + esc(fileLines) + '</pre></details>';
        }

        var logText = '';
        if (j.output && j.stderr) logText = String(j.output) + '\n--- stderr ---\n' + String(j.stderr);
        else logText = String(j.output || j.stderr || j.log || '').trim();
        var logHtml = logText
            ? '<details><summary>Journal d\'exécution (stdout / stderr)</summary><pre>' + esc(logText) + '</pre></details>'
            : '';

        var catalogHtml = '';
        if (!ok && j.recommended_catalog && j.recommended_catalog.length
            && typeof window.gpRenderRecommendedCatalogHtml === 'function') {
            catalogHtml = window.gpRenderRecommendedCatalogHtml(
                j.recommended_catalog,
                j.element || opts.element || '',
                { title: 'Catalogue UPF / générateurs alternatifs' }
            );
        }

        var qvMeta = j.qe_validation || {};
        var zVal = j.z_valence != null ? j.z_valence : qvMeta.z_valence;
        var ecutWfc = j.suggested_ecutwfc_ry != null ? j.suggested_ecutwfc_ry : qvMeta.suggested_ecutwfc_ry;
        var ptype = (j.pseudo_type || qvMeta.pseudo_type || '').toString().toUpperCase();
        var rhoFac = j.ecutrho_factor || qvMeta.ecutrho_factor
            || ((ptype === 'US' || ptype === 'PAW' || ptype === 'USPP') ? 8 : 4);
        var ecutRho = j.suggested_ecutrho_ry != null ? j.suggested_ecutrho_ry
            : (qvMeta.suggested_ecutrho_ry != null ? qvMeta.suggested_ecutrho_ry : null);
        if (ecutRho == null && ecutWfc) ecutRho = Math.round(Number(ecutWfc) * Number(rhoFac));
        var suite = j.suite_compatibility || qvMeta.suite_compatibility || null;
        var suiteHtml = '';
        if (suite && suite.interfaces) {
            var order = ['qe', 'thermo_pw', 'qe_alamode', 'supra_qe'];
            var chips = [];
            var ii;
            for (ii = 0; ii < order.length; ii++) {
                var it = suite.interfaces[order[ii]];
                if (!it) continue;
                var okI = !!it.ok;
                chips.push(
                    '<span class="gen-run-suite__chip ' + (okI ? 'gen-run-suite__chip--ok' : 'gen-run-suite__chip--no')
                    + '" title="' + esc(it.note || it.detail || '') + '">'
                    + (okI ? '✓ ' : '✗ ') + esc(it.label) + '</span>'
                );
            }
            var sumColor = suite.all_ok ? '#86efac' : (suite.n_ok ? '#f9e2af' : '#f38ba8');
            var supraWarn = '';
            if (suite.interfaces.supra_qe && !suite.interfaces.supra_qe.ok && qeOk) {
                supraWarn = '<p style="margin:8px 0 0;font-size:0.78em;color:#f9e2af;">'
                    + 'Supra-QE / EPW exige un UPF <strong>NC</strong> (APE, ONCVPSP, ld1.x <code>pseudotype=1</code>, PseudoDojo).'
                    + ' USPP/PAW restent valides pour QE, thermo_pw et QE–ALAMODE.</p>';
            }
            suiteHtml = '<div class="gen-run-result__box gen-run-result__box--info" style="margin-bottom:12px;">'
                + '<h4 style="color:' + sumColor + ';margin:0 0 8px;">Format UPF — conformité suite HIADSI</h4>'
                + '<p style="margin:0 0 8px;font-size:0.8em;color:#94a3b8;">'
                + esc(suite.summary || 'UPF Quantum ESPRESSO (pw.x)')
                + (ptype ? ' · type <strong>' + esc(ptype) + '</strong>' : '')
                + '</p>'
                + '<div class="gen-run-suite">' + chips.join('') + '</div>'
                + supraWarn
                + '</div>';
        }
        var pwHintHtml = '';
        if (zVal != null || ecutWfc) {
            pwHintHtml = '<div class="gen-run-result__box gen-run-result__box--info" style="margin-bottom:12px;">'
                + '<h4 style="color:#86efac;margin:0 0 8px;">Paramètres suggérés pour pw.x / thermo_pw / ALAMODE</h4>'
                + '<dl class="gen-run-result__paths">'
                + (zVal != null ? pathRow('Z valence (UPF)', zVal) : '')
                + (ecutWfc ? pathRow('ecutwfc (Ry)', ecutWfc + ' — point de départ ; converger') : '')
                + (ecutRho ? pathRow('ecutrho (Ry)', ecutRho + ' — ' + rhoFac + ' × ecutwfc') : '')
                + '</dl>'
                + '<p style="margin:8px 0 0;font-size:0.78em;color:#94a3b8;">'
                + 'Mêmes coupures pour <code>pw.x</code>, <code>ph.x</code>, thermo_pw et QE–ALAMODE ; ajustez par tests de convergence.</p>'
                + '</div>';
        }

        return ''
            + '<div class="gen-run-result">'
            + '<div class="gen-run-result__head">'
            + '<div class="gen-run-result__icon">' + icon + '</div>'
            + '<div><div class="gen-run-result__title" style="color:' + titleColor + ';">' + esc(title) + '</div>'
            + (subParts.length ? '<div class="gen-run-result__sub">' + subParts.join(' · ') + '</div>' : '')
            + '</div></div>'
            + suiteHtml
            + pwHintHtml
            + '<div class="gen-run-result__box ' + boxClass + '">'
            + '<h4 style="color:' + titleColor + ';">Fichier UPF</h4>'
            + '<dl class="gen-run-result__paths">'
            + pathRow('Nom', upfName || '(non détecté)')
            + pathRow('Chemin complet', upfPath || '(voir journal ci-dessous)')
            + (qeFmt ? pathRow('Format QE', qeFmt) : '')
            + (ptype ? pathRow('Type', ptype) : '')
            + (zVal != null ? pathRow('Z valence', zVal) : '')
            + (ecutWfc ? pathRow('ecutwfc suggéré (Ry)', ecutWfc) : '')
            + pathRow('Répertoire de travail', j.work_dir)
            + pathRow('Entrée', j.input_file)
            + pathRow('Journal', j.log_file || j.output_file)
            + '</dl>'
            + oncvFlags
            + (actions ? '<div class="gen-run-result__actions">' + actions + '</div>' : '')
            + '</div>'
            + saveHtml
            + warnHtml
            + hintHtml
            + filesHtml
            + logHtml
            + catalogHtml
            + '</div>';
    };

    window.gpRunResultToast = function (j, label) {
        if (typeof _showToast !== 'function') return;
        var short = j.upf_genere || (j.upf_path ? String(j.upf_path).split('/').pop() : '');
        if (j.success && short) {
            _showToast(label + ' — ' + short, '#059669', 4500);
        } else if (j.run_completed && (j.hint || !j.success)) {
            _showToast(label + ' — voir détails ci-dessous', '#ca8a04', 4500);
        } else if (j.success) {
            _showToast(label + ' terminé', '#059669', 3000);
        } else {
            var err = (j.fatal_errors && j.fatal_errors[0]) || j.error || j.diagnostic_summary || 'échec';
            _showToast(label + ' : ' + String(err).slice(0, 100), '#dc2626', 5500);
        }
    };

    function safeSym(s) {
        return String(s || '').replace(/[^A-Za-z]/g, '').slice(0, 8);
    }

    var GP_XC_OPTIONS = [
        { v: 'gga_pbe', l: 'GGA · PBE (défaut pw.x)' },
        { v: 'gga_pbesol', l: 'GGA · PBEsol' },
        { v: 'lda_pw', l: 'LDA · PW92' },
        { v: 'lda_pz', l: 'LDA · PZ81' },
    ];

    var GP_REL_OPTIONS = [
        { v: '1', l: 'Scalaire (scalar_rel / scalarrelativistic)' },
        { v: '0', l: 'Non relativiste (schrodinger / nonrel)' },
    ];

    var GP_PP_APE = [
        { v: 'troullier', l: 'Troullier-Martins (NC)' },
        { v: 'hamann', l: 'Hamann (NC)' },
    ];

    var GP_PP_ATOMPAW = [
        { v: 'vanderbilt', l: 'Vanderbilt (PAW)' },
        { v: 'bloechl', l: 'Blöchl (PAW)' },
        { v: 'vanderbilt_tm', l: 'Vanderbilt + TM' },
    ];

    var GP_FT_OPTIONS = [
        { v: 'auto', l: 'auto (recommandé)' },
        { v: 'open_core', l: 'open_core (f gelé)' },
        { v: 'valence_f', l: 'valence_f (f en valence + U)' },
    ];

    var _F_BLOCK_SYMS = /^(La|Ce|Pr|Nd|Pm|Sm|Eu|Gd|Tb|Dy|Ho|Er|Tm|Yb|Lu|Ac|Th|Pa|U|Np|Pu|Am|Cm|Bk|Cf|Es|Fm|Md|No|Lr)$/;
    var _3D_SYMS = /^(Sc|Ti|V|Cr|Mn|Fe|Co|Ni|Cu|Zn)$/;

    function ensureGpPhysicsControlsStyles() {
        /* Styles centralisés dans index.html (.gp-physics-controls, .gp-optimal-banner) */
    }

    function gpElementZ(sym) {
        var el = window.ELEMENTS && window.ELEMENTS[sym];
        return el && el.numero ? parseInt(el.numero, 10) : 0;
    }

    function gpDefaultRelativistic(sym) {
        var z = gpElementZ(sym);
        if (_3D_SYMS.test(sym) || _F_BLOCK_SYMS.test(sym) || z > 36) return '1';
        return '0';
    }

    function gpDefaultSemicore(sym) {
        return _3D_SYMS.test(sym) || _F_BLOCK_SYMS.test(sym);
    }

    function gpNormalizeEngine(engine) {
        var g = String(engine || 'ape').toLowerCase();
        if (g === 'atompaw') return 'atompaw';
        if (g === 'oncvpsp' || g === 'oncv') return 'oncvpsp';
        return 'ape';
    }

    function gpPhysicsIdPrefix(engine) {
        engine = gpNormalizeEngine(engine);
        if (engine === 'atompaw') return 'gp_atompaw';
        if (engine === 'oncvpsp') return 'gp_oncv';
        return 'gp_ape';
    }

    function gpSelectOptionsHtml(options, selected, recommended) {
        return options.map(function (o) {
            var lab = o.l;
            if (recommended && o.v === recommended) lab += ' ★';
            return '<option value="' + esc(o.v) + '"' + (o.v === selected ? ' selected' : '') + '>'
                + esc(lab) + '</option>';
        }).join('');
    }

    window.gpRenderPhysicsControlsHtml = function (engine, sym, optimal) {
        ensureGpPhysicsControlsStyles();
        engine = gpNormalizeEngine(engine);
        sym = safeSym(sym);
        var prefix = gpPhysicsIdPrefix(engine);
        var oc = (optimal && optimal.controls) ? optimal.controls : {};
        var relDef = oc.relativistic != null ? (oc.relativistic ? '1' : '0') : gpDefaultRelativistic(sym);
        var scDef = oc.semicore != null ? !!oc.semicore : gpDefaultSemicore(sym);
        var xcDef = oc.xc || 'gga_pbe';
        var ftBlock = _F_BLOCK_SYMS.test(sym);
        var ftDef = oc.f_treatment || 'auto';
        var ppDef = engine === 'ape' ? (oc.pp_type_ape || 'troullier') : (oc.pp_type_atompaw || 'vanderbilt');
        var genLabel = engine === 'atompaw' ? 'ATOMPAW' : (engine === 'oncvpsp' ? 'ONCVPSP' : 'APE');
        var html = '';
        if (optimal && optimal.summary) {
            html += typeof window.gpRenderOptimalBannerHtml === 'function'
                ? window.gpRenderOptimalBannerHtml(optimal, sym, genLabel) : '';
        }
        html += '<div class="gp-physics-controls" data-engine="' + esc(engine) + '" data-sym="' + esc(sym) + '">'
            + '<div class="gp-physics-controls__title">② Paramètres physiques du gabarit'
            + ' <span class="gp-physics-controls__subtitle">(★ = optimal pour ' + esc(sym) + ')</span></div>'
            + '<div class="gp-physics-controls__grid">';
        if (engine === 'oncvpsp') {
            html += '<label>Type pseudo (ONCV)'
                + '<span class="gp-physics-nc-badge">NC optimisé (fixe)</span></label>';
        }
        html += '<label>Fonctionnelle XC'
            + '<select id="' + prefix + '_xc_modal">' + gpSelectOptionsHtml(GP_XC_OPTIONS, xcDef, xcDef) + '</select></label>';
        if (engine === 'oncvpsp') {
            html += '<label>Relativité'
                + '<span class="gp-physics-nc-badge">Scalaire (fixe ONCV)</span></label>';
        } else {
            html += '<label>Relativité'
                + '<select id="' + prefix + '_rel_modal">' + gpSelectOptionsHtml(GP_REL_OPTIONS, relDef, relDef) + '</select></label>';
        }
        if (engine === 'ape') {
            html += '<label>Type NC (APE)'
                + '<select id="' + prefix + '_pp_modal">' + gpSelectOptionsHtml(GP_PP_APE, ppDef, ppDef) + '</select></label>';
        } else if (engine === 'atompaw') {
            html += '<label>Type PAW (ATOMPAW)'
                + '<select id="' + prefix + '_pp_modal">' + gpSelectOptionsHtml(GP_PP_ATOMPAW, ppDef, ppDef) + '</select></label>';
        }
        if (engine === 'oncvpsp') {
            html += '<label>Semi-cœur'
                + '<span class="gp-physics-nc-badge">'
                + (scDef ? 'dans le .dat (3p / 5s5p)' : 'non (élément léger)')
                + '</span></label>';
        } else {
            html += '<label class="gp-physics-controls__check">'
                + '<input type="checkbox" id="' + prefix + '_semicore_modal"' + (scDef ? ' checked' : '') + '> '
                + 'Semi-cœur (3p / 5s5p…)</label>';
        }
        if (ftBlock) {
            html += '<label>Traitement 4f/5f'
                + '<select id="' + prefix + '_ft_modal">' + gpSelectOptionsHtml(GP_FT_OPTIONS, ftDef, ftDef) + '</select></label>';
        }
        html += '</div>'
            + '<p class="gp-physics-controls__hint">Valeurs ★ pré-sélectionnées selon l\'élément. '
            + (engine === 'oncvpsp'
                ? 'Physique ONCV : XC change iexc seulement sur gabarit maison (PseudoDojo reste PBE). '
                  + '4f/5f change nc/nv. Relativité scalaire imposée par <code>oncvpsp.x</code>. '
                  + 'Semi-cœur déjà dans les occupations du .dat.'
                : 'Changement → gabarit régénéré. Alignez la XC avec <code>pw.x</code>.')
            + '</p>'
            + (optimal && optimal.summary
                ? '<button type="button" class="btn-action btn-secondary-act gp-reapply-optimal" '
                + 'data-sym="' + esc(sym) + '" data-engine="' + esc(engine) + '" '
                + 'style="font-size:0.72rem;margin-top:8px;padding:4px 10px;">Réappliquer l\'optimal</button>'
                : '')
            + '</div>';
        return html;
    };

    function gpPhysicsEl(id) {
        var roots = [
            document.getElementById('modal_generateur_oncvpsp'),
            document.getElementById('modal_generateur_ape_complet'),
            document.getElementById('modal_generateur_atompaw_complet'),
        ];
        var i, found;
        for (i = 0; i < roots.length; i++) {
            if (!roots[i]) continue;
            found = roots[i].querySelector('#' + id);
            if (found) return found;
        }
        return document.getElementById(id);
    }

    window.gpReadPhysicsParams = function (engine) {
        engine = gpNormalizeEngine(engine);
        var prefix = gpPhysicsIdPrefix(engine);
        var relEl = gpPhysicsEl(prefix + '_rel_modal');
        var scEl = gpPhysicsEl(prefix + '_semicore_modal');
        var ftEl = gpPhysicsEl(prefix + '_ft_modal');
        var ppEl = gpPhysicsEl(prefix + '_pp_modal');
        var xcEl = gpPhysicsEl(prefix + '_xc_modal');
        var params = {
            xc: xcEl ? xcEl.value : 'gga_pbe',
            relativistic: relEl ? relEl.value === '1' : true,
            semicore: scEl ? !!scEl.checked : false,
        };
        if (engine === 'ape') {
            params.pp_type_ape = ppEl ? ppEl.value : 'troullier';
        } else if (engine === 'atompaw') {
            params.pp_type_atompaw = ppEl ? ppEl.value : 'vanderbilt';
        }
        if (ftEl && ftEl.value) params.f_treatment = ftEl.value;
        return params;
    };

    window.gpSyncPhysicsParamsToUi = function (params, engine) {
        if (!params) return;
        engine = gpNormalizeEngine(engine);
        window._gpSyncingPhysics = true;
        var prefix = gpPhysicsIdPrefix(engine);
        var xcEl = gpPhysicsEl(prefix + '_xc_modal');
        var relEl = gpPhysicsEl(prefix + '_rel_modal');
        var ppEl = gpPhysicsEl(prefix + '_pp_modal');
        var scEl = gpPhysicsEl(prefix + '_semicore_modal');
        var ftEl = gpPhysicsEl(prefix + '_ft_modal');
        if (xcEl && params.xc) xcEl.value = params.xc;
        if (relEl) relEl.value = params.relativistic ? '1' : '0';
        if (ppEl) {
            if (engine === 'ape' && params.pp_type_ape) ppEl.value = params.pp_type_ape;
            if (engine === 'atompaw' && params.pp_type_atompaw) ppEl.value = params.pp_type_atompaw;
        }
        if (scEl && params.semicore != null) scEl.checked = !!params.semicore;
        if (ftEl && params.f_treatment) ftEl.value = params.f_treatment;
        window._gpSyncingPhysics = false;
    };

    window._gpOptimalCache = window._gpOptimalCache || {};

    window.gpMountPhysicsControls = function (slot, sym, engine) {
        if (!slot) return Promise.resolve();
        sym = safeSym(sym);
        engine = gpNormalizeEngine(engine);
        slot.innerHTML = '<div class="gen-ld1-meta">Calcul des paramètres optimaux pour ' + esc(sym) + '…</div>';

        var cacheKey = sym + '|' + engine;
        var fetchP = window._gpOptimalCache[cacheKey]
            ? Promise.resolve(window._gpOptimalCache[cacheKey])
            : (typeof window.gpFetchGeneratorParams === 'function'
                ? window.gpFetchGeneratorParams(sym, engine) : Promise.resolve(null));

        function reloadTemplateForEngine(s, eng) {
            if (eng === 'oncvpsp' && typeof window.gpReloadOncvTemplateFromPhysics === 'function') {
                return window.gpReloadOncvTemplateFromPhysics(s);
            }
            if (typeof window.gpFetchAutoInputs === 'function') {
                return window.gpFetchAutoInputs(s, eng, true);
            }
            return Promise.resolve();
        }

        function bindSlotEvents(payload) {
            if (slot._gpPhysicsBound) return;
            slot._gpPhysicsBound = true;
            slot.addEventListener('change', function (ev) {
                if (window._gpSyncingPhysics) return;
                var t = ev.target;
                if (!t || !t.closest || !t.closest('.gp-physics-controls')) return;
                var root = slot.querySelector('.gp-physics-controls');
                var eng = (root && root.getAttribute('data-engine')) || engine;
                var s = (root && root.getAttribute('data-sym')) || sym;
                if (eng !== 'oncvpsp') {
                    if (typeof window.gpInvalidateAutoInputsCacheForSym === 'function') {
                        window.gpInvalidateAutoInputsCacheForSym(s);
                    } else if (window.gpAutoCache) {
                        Object.keys(window.gpAutoCache).forEach(function (k) {
                            if (k.indexOf(s + '|') === 0) delete window.gpAutoCache[k];
                        });
                    }
                }
                reloadTemplateForEngine(s, eng);
            });
            slot.addEventListener('click', function (ev) {
                var btn = ev.target && ev.target.closest ? ev.target.closest('.gp-reapply-optimal') : null;
                if (!btn || !payload || !payload.optimal_controls) return;
                window.gpSyncPhysicsParamsToUi(payload.optimal_controls.controls, btn.getAttribute('data-engine') || engine);
                var s2 = btn.getAttribute('data-sym') || sym;
                var e2 = btn.getAttribute('data-engine') || engine;
                reloadTemplateForEngine(s2, e2);
            });
        }

        return fetchP.then(function (payload) {
            if (payload && payload.success) window._gpOptimalCache[cacheKey] = payload;
            var optimal = payload && payload.optimal_controls;
            slot.innerHTML = window.gpRenderPhysicsControlsHtml(engine, sym, optimal);
            bindSlotEvents(payload);
            return reloadTemplateForEngine(sym, engine);
        }).catch(function () {
            slot.innerHTML = window.gpRenderPhysicsControlsHtml(engine, sym, null);
            bindSlotEvents(null);
            return reloadTemplateForEngine(sym, engine);
        });
    };

    function gpBuildAutoInputsQuery(sym, engine, params) {
        params = params || window.gpReadPhysicsParams(engine);
        var q = 'element=' + encodeURIComponent(sym)
            + '&engine=' + encodeURIComponent(engine)
            + '&xc=' + encodeURIComponent(params.xc || 'gga_pbe')
            + '&relativistic=' + (params.relativistic ? '1' : '0')
            + '&semicore=' + (params.semicore ? '1' : '0');
        if (engine === 'ape' && params.pp_type_ape) {
            q += '&pp_type_ape=' + encodeURIComponent(params.pp_type_ape);
        }
        if (engine === 'atompaw' && params.pp_type_atompaw) {
            q += '&pp_type_atompaw=' + encodeURIComponent(params.pp_type_atompaw);
        }
        if (params.f_treatment) {
            q += '&f_treatment=' + encodeURIComponent(params.f_treatment);
        } else if (_F_BLOCK_SYMS.test(sym)) {
            q += '&f_treatment=auto';
        }
        return q;
    }

    function apeTextarea() {
        return document.getElementById('gp_ape_input_modal') || document.getElementById('gp_ape_input');
    }

    function atompawTextarea() {
        return document.getElementById('gp_atompaw_input_modal') || document.getElementById('gp_atompaw_input');
    }

    window.gpGetAtompawFormatEl = function () {
        return document.getElementById('gp_atompaw_format_modal') || document.getElementById('gp_atompaw_format');
    };

    window.gpApplyAtompawFormatFromCache = function (sym) {
        sym = safeSym(sym);
        var params = window.gpReadPhysicsParams('atompaw');
        var cacheKey = sym + '|atompaw|' + JSON.stringify(params);
        var c = window.gpAutoCache && window.gpAutoCache[cacheKey];
        if (!c || !c.atompaw) return;
        window.gpApplyAutoInputs(sym, 'atompaw', c.atompaw);
    };

    window.gpInvalidateAutoInputsCacheForSym = function (sym) {
        sym = safeSym(sym);
        if (!window.gpAutoCache) return;
        Object.keys(window.gpAutoCache).forEach(function (k) {
            if (k === sym || k.indexOf(sym + '|') === 0) delete window.gpAutoCache[k];
        });
    };

    window.gpFetchAutoInputs = async function (sym, engine, force) {
        sym = safeSym(sym);
        engine = engine || 'ape';
        var params = window.gpReadPhysicsParams(engine);
        var cacheKey = sym + '|' + engine + '|' + JSON.stringify(params);
        if (!force && window.gpAutoCache[cacheKey] && window.gpAutoCache[cacheKey][engine]) {
            window.gpApplyAutoInputs(sym, engine, window.gpAutoCache[cacheKey][engine]);
            return;
        }
        try {
            var url = apiBase() + '/api/pseudos/auto_inputs?' + gpBuildAutoInputsQuery(sym, engine, params);
            var r = await fetch(url, { cache: 'no-store' });
            var j = await r.json();
            if (!r.ok) throw new Error(j.error || 'HTTP ' + r.status);
            if (!window.gpAutoCache[cacheKey]) window.gpAutoCache[cacheKey] = {};
            window.gpAutoCache[cacheKey][engine] = j;
            if (engine === 'ape' && j.ape_feasibility) {
                window._gpApeFeasCache = window._gpApeFeasCache || {};
                window._gpApeFeasCache[sym] = j.ape_feasibility;
                var warnEl = document.getElementById('gp_ape_blocked_banner_modal');
                if (warnEl) {
                    if (j.ape_feasibility === 'blocked') {
                        warnEl.innerHTML = '<strong style="color:#fca5a5;">APE déconseillé</strong> pour '
                            + sym + ' (3d / lanthanides / actinides). Préférez '
                            + '<button type="button" class="btn-action btn-secondary-act" style="font-size:0.75rem;padding:2px 8px;" '
                            + 'onclick="ouvrirGenerateurATOMPAWComplet(\'' + sym + '\')">ATOMPAW</button> ou '
                            + '<button type="button" class="btn-action btn-secondary-act" style="font-size:0.75rem;padding:2px 8px;" '
                            + 'onclick="ouvrirGenerateurONCVPSPComplet(\'' + sym + '\')">ONCVPSP</button>.';
                        warnEl.style.display = 'block';
                    } else {
                        warnEl.style.display = 'none';
                        warnEl.innerHTML = '';
                    }
                }
            }
            window.gpApplyAutoInputs(sym, engine, j);
        } catch (e) {
            var ta = engine === 'atompaw' ? atompawTextarea() : apeTextarea();
            if (ta) ta.value = '# Erreur chargement gabarit : ' + (e.message || e) + '\n';
        }
    };

    window.gpApplyAutoInputs = function (sym, engine, data) {
        if (data && data.params && typeof window.gpSyncPhysicsParamsToUi === 'function') {
            window.gpSyncPhysicsParamsToUi(data.params, engine);
        }
        var input = '';
        var summary = data.summary || data.hint || data.note || '';
        if (data.params) {
            var p = data.params;
            var bits = [];
            if (p.xc) bits.push('XC=' + p.xc);
            bits.push('rel=' + (p.relativistic ? 'scalaire' : 'non-rel'));
            if (p.semicore) bits.push('semi-cœur');
            if (p.pp_type_ape && engine === 'ape') bits.push('NC=' + p.pp_type_ape);
            if (p.pp_type_atompaw && engine === 'atompaw') bits.push('PAW=' + p.pp_type_atompaw);
            if (p.f_treatment) bits.push('f=' + p.f_treatment);
            if (bits.length) {
                summary = (summary ? summary + '<br>' : '')
                    + '<span style="font-size:0.82em;color:#94a3b8;">Gabarit : ' + esc(bits.join(' · ')) + '</span>';
            }
        }
        if (engine === 'ape') {
            input = data.ape_input || data.input || data.content || data.template || '';
        } else if (engine === 'atompaw') {
            var fmtEl = window.gpGetAtompawFormatEl();
            var fmt = fmtEl ? fmtEl.value : 'interactive';
            input = (fmt === 'qe_file' ? (data.atompaw_input_qe || data.atompaw_input) : data.atompaw_input)
                || data.input || data.content || data.template || '';
        } else {
            input = data.input || data.content || data.template || '';
        }
        if (engine === 'ape') {
            var ta = apeTextarea();
            var su = document.getElementById('gp_ape_auto_summary_modal') || document.getElementById('gp_ape_auto_summary');
            var sm = document.getElementById('gp_ape_auto_summary_modal');
            if (ta && input) ta.value = input;
            if (su && summary) su.innerHTML = summary;
            if (sm && summary) sm.innerHTML = summary;
            var bdm = document.getElementById('gp_ape_breakdown_body_modal');
            if (data.input_breakdown && bdm) {
                bdm.innerHTML = '<pre style="font-size:0.75em;white-space:pre-wrap;">' + esc(JSON.stringify(data.input_breakdown, null, 2)) + '</pre>';
            }
        } else {
            var ta2 = atompawTextarea();
            var su2 = document.getElementById('gp_atompaw_auto_summary_modal') || document.getElementById('gp_atompaw_auto_summary');
            var sm2 = document.getElementById('gp_atompaw_auto_summary_modal');
            if (ta2 && input) ta2.value = input;
            if (su2 && summary) su2.innerHTML = summary;
            if (sm2 && summary) sm2.innerHTML = summary;
        }
    };

    window.gpRefreshApeStatus = async function () {
        var el = document.getElementById('gp_ape_status_line_modal') || document.getElementById('gp_ape_status_line');
        if (!el) return;
        try {
            var r = await fetch(apiBase() + '/api/pseudos/ape_status', { cache: 'no-store' });
            var j = await r.json();
            var ok = j.available || j.installed;
            el.innerHTML = ok
                ? 'APE détecté : <code>' + esc(j.path || j.bin || 'ape') + '</code>'
                : 'APE non trouvé — <code>./install_ape_atompaw.sh</code>';
            el.style.color = ok ? '#059669' : '#b45309';
        } catch (e) {
            el.textContent = 'Statut APE indisponible (API hors ligne)';
            el.style.color = '#94a3b8';
        }
    };

    window.gpRefreshAtompawStatus = async function () {
        var el = document.getElementById('gp_atompaw_status_line_modal') || document.getElementById('gp_atompaw_status_line');
        if (!el) return;
        try {
            var r = await fetch(apiBase() + '/api/pseudos/atompaw_status', { cache: 'no-store' });
            var j = await r.json();
            var ok = j.available || j.installed;
            el.innerHTML = ok
                ? 'ATOMPAW détecté : <code>' + esc(j.path || j.bin || 'atompaw') + '</code>'
                : 'ATOMPAW non trouvé — <code>./install_ape_atompaw.sh</code>';
            el.style.color = ok ? '#059669' : '#b45309';
        } catch (e) {
            el.textContent = 'Statut ATOMPAW indisponible (API hors ligne)';
            el.style.color = '#94a3b8';
        }
    };

    window.gpRunApe = async function (sym) {
        sym = safeSym(sym) || 'X';
        var ta = typeof window.gpGetApeTextarea === 'function' ? window.gpGetApeTextarea() : apeTextarea();
        var out = typeof window.gpGetApeOutputEl === 'function' ? window.gpGetApeOutputEl() : document.getElementById('gp_ape_output_modal');
        var input = ta ? String(ta.value || '').trim() : '';
        if (!input) {
            alert('Zone inp.ape vide — attendez le chargement auto ou cliquez « Rafraîchir gabarit ».');
            return;
        }
        if (typeof window.gpRevealLaunchScienceReminder === 'function') {
            window.gpRevealLaunchScienceReminder(sym, 'ape');
        }
        var feas = window._gpApeFeasCache && window._gpApeFeasCache[sym];
        if (!feas && typeof window.gpFetchRecommendedCatalog === 'function') {
            try {
                var catPre = await window.gpFetchRecommendedCatalog(sym);
                feas = catPre && catPre.ape_feasibility;
                if (feas) {
                    window._gpApeFeasCache = window._gpApeFeasCache || {};
                    window._gpApeFeasCache[sym] = feas;
                }
            } catch (e) { /* ignore */ }
        }
        if (feas === 'blocked') {
            var go = confirm(
                'APE est fortement déconseillé pour ' + sym
                + ' (métaux 3d, lanthanides ou actinides).\n\n'
                + 'Préférez ATOMPAW, ONCVPSP ou un UPF catalogue.\n\nLancer APE quand même ?'
            );
            if (!go) return;
        }
        ensureGenRunResultStyles();
        if (typeof window.gpSetGeneratorRunning === 'function') {
            window.gpSetGeneratorRunning({ engine: 'ape', element: sym, outputEl: out });
        }
        if (out) {
            out.innerHTML = typeof window.gpRenderExecLoadingHtml === 'function'
                ? window.gpRenderExecLoadingHtml('Exécution APE en cours…', 'Génération UPF — patientez')
                : '<div class="gen-run-result gen-run-result--loading">Exécution APE en cours…</div>';
        }
        var reuse = document.getElementById('gp_ape_reuse_workdir_modal') || document.getElementById('gp_ape_reuse_workdir');
        var body = { element: sym, input: input };
        if (reuse && reuse.checked) body.continue_dir = true;
        try {
            var r = await fetch(apiBase() + '/api/pseudos/run_ape', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });
            var j = await r.json();
            if (out) {
                out.innerHTML = typeof window.renderGeneratorRunResult === 'function'
                    ? window.renderGeneratorRunResult(j, { label: 'APE', element: sym })
                    : '<pre>' + esc(j.output || j.error || JSON.stringify(j, null, 2)) + '</pre>';
            }
            window.gpRunResultToast(j, 'APE');
        } catch (e) {
            if (out) out.innerHTML = '<div class="gen-run-result gen-run-result__box gen-run-result__box--err">Erreur réseau : ' + esc(e.message || e) + '</div>';
        } finally {
            if (typeof window.gpClearGeneratorRunning === 'function') window.gpClearGeneratorRunning('ape');
        }
    };

    window.gpRunAtompaw = async function (sym) {
        sym = safeSym(sym) || 'X';
        var ta = typeof window.gpGetAtompawTextarea === 'function' ? window.gpGetAtompawTextarea() : atompawTextarea();
        var out = typeof window.gpGetAtompawOutputEl === 'function' ? window.gpGetAtompawOutputEl() : document.getElementById('gp_atompaw_output_modal');
        var input = ta ? String(ta.value || '').trim() : '';
        if (!input) {
            alert('stdin ATOMPAW vide — attendez le chargement auto ou cliquez « Rafraîchir gabarit ».');
            return;
        }
        if (typeof window.gpRevealLaunchScienceReminder === 'function') {
            window.gpRevealLaunchScienceReminder(sym, 'atompaw');
        }
        ensureGenRunResultStyles();
        if (typeof window.gpSetGeneratorRunning === 'function') {
            window.gpSetGeneratorRunning({ engine: 'atompaw', element: sym, outputEl: out });
        }
        if (out) {
            out.innerHTML = typeof window.gpRenderExecLoadingHtml === 'function'
                ? window.gpRenderExecLoadingHtml('Exécution ATOMPAW en cours…', 'Génération PAW/UPF — patientez')
                : '<div class="gen-run-result gen-run-result--loading">Exécution ATOMPAW en cours…</div>';
        }
        var reuse = document.getElementById('gp_atompaw_reuse_workdir_modal') || document.getElementById('gp_atompaw_reuse_workdir');
        var fmt = window.gpGetAtompawFormatEl();
        var phys = typeof window.gpReadPhysicsParams === 'function'
            ? window.gpReadPhysicsParams('atompaw') : { relativistic: true, xc: 'gga_pbe' };
        var body = {
            element: sym,
            input: input,
            atompaw_format: fmt ? fmt.value : 'interactive',
            format: fmt ? fmt.value : 'interactive',
            xc: phys.xc || 'gga_pbe',
            pp_type_atompaw: phys.pp_type_atompaw || 'vanderbilt',
            relativistic: !!phys.relativistic,
            semicore: !!phys.semicore,
        };
        if (phys.f_treatment) body.f_treatment = phys.f_treatment;
        // 3d / 4f / 5f : régénérer le gabarit serveur (open_core / Ar+3d4s) pour obtenir un UPF
        if (/^(Sc|Ti|V|Cr|Mn|Fe|Co|Ni|Cu|Zn|La|Ce|Pr|Nd|Pm|Sm|Eu|Gd|Tb|Dy|Ho|Er|Tm|Yb|Lu|Ac|Th|Pa|U|Np|Pu|Am|Cm|Bk|Cf|Es|Fm|Md|No|Lr)$/.test(sym)) {
            body.regenerate_input = true;
            if (!body.f_treatment) body.f_treatment = 'auto';
        }
        if (reuse && reuse.checked) body.continue_dir = true;
        try {
            var r = await fetch(apiBase() + '/api/pseudos/run_atompaw', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });
            var j = await r.json();
            if (out) {
                out.innerHTML = typeof window.renderGeneratorRunResult === 'function'
                    ? window.renderGeneratorRunResult(j, { label: 'ATOMPAW' })
                    : '<pre>' + esc(j.output || j.error || JSON.stringify(j, null, 2)) + '</pre>';
            }
            window.gpRunResultToast(j, 'ATOMPAW');
        } catch (e) {
            if (out) out.innerHTML = '<div class="gen-run-result gen-run-result__box gen-run-result__box--err">Erreur réseau : ' + esc(e.message || e) + '</div>';
        } finally {
            if (typeof window.gpClearGeneratorRunning === 'function') window.gpClearGeneratorRunning('atompaw');
        }
    };

    window.gpLoadApePreset = function (preset) {
        var ta = apeTextarea();
        if (!ta) return;
        fetch(apiBase() + '/api/pseudos/auto_inputs?preset=' + encodeURIComponent(preset || 'li_ae'), { cache: 'no-store' })
            .then(function (r) { return r.json(); })
            .then(function (j) {
                if (j.input) ta.value = j.input;
            })
            .catch(function () {});
    };

    window.gpLoadAtompawTemplate = function () {
        var sym = (document.getElementById('gen_panel') && document.getElementById('gen_panel').getAttribute('data-element')) || 'Si';
        window.gpFetchAutoInputs(sym, 'atompaw', true);
    };

    function ftTreatmentForZ(z) {
        var Z = parseInt(z, 10) || 0;
        if ((Z >= 57 && Z <= 71) || (Z >= 89 && Z <= 103)) return 'auto';
        return undefined;
    }

    function renderSciTab(container, opts) {
        var symbole = opts.symbole;
        var zNum = parseInt(opts.z, 10) || 0;
        var zLine = 'Z = ' + (opts.z || '?');
        if (opts.nom) zLine += ' · ' + esc(opts.nom);
        var gen = opts.generator || 'ape';
        var paramsSlotId = 'gp_tab_params_slot_' + gen;
        var slotId = 'gp_tab_science_slot_' + gen;
        container.innerHTML = ''
            + '<div class="gen-ld1-tab">'
            // En-tête minimal + GROS bouton Lancer immédiatement visible
            + '<div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:6px;margin-bottom:8px;">'
            + '<div style="font-size:0.72em;font-family:var(--font-mono);color:' + opts.accent + ';font-weight:600;">' + esc(opts.label) + '</div>'
            + '<div class="gen-ld1-meta" style="margin:0;">' + zLine + '</div>'
            + '</div>'
            + '<button type="button" class="gen-launch-big" onclick="' + opts.openFn + '(\'' + esc(symbole) + '\')">'
            + '<span class="gen-launch-play">▶</span> Lancer la génération'
            + '</button>'
            // Texte explicatif conservé mais replié (dépliable)
            + '<details class="gen-ld1-details">'
            + '<summary>ℹ️ Explications &amp; conseils — ' + esc(opts.label) + ' (déplier)</summary>'
            + '<div class="gen-ld1-details-body">'
            + '<div class="gen-ld1-intro" style="border-left-color:' + opts.accent + ';margin-bottom:12px;">'
            + opts.intro
            + '</div>'
            + '<div id="' + slotId + '"></div>'
            + '</div>'
            + '</details>'
            + '<div id="' + paramsSlotId + '" style="margin:8px 0;"></div>'
            + '<div class="gen-ld1-steps">'
            + opts.steps
            + '</div>'
            + '<div class="gen-ld1-actions">'
            + (opts.docUrl
                ? '<a class="btn-action btn-secondary-act" style="text-decoration:none;" href="' + opts.docUrl + '" target="_blank" rel="noopener">Documentation</a>'
                : '')
            + '</div></div>';
        if (typeof window.gpMountGeneratorParams === 'function') {
            window.gpMountGeneratorParams(document.getElementById(paramsSlotId), symbole, gen);
        }
        if (typeof window.gpMountPreCalcScience === 'function') {
            window.gpMountPreCalcScience(
                document.getElementById(slotId),
                symbole,
                gen,
                null,
                { f_treatment: ftTreatmentForZ(zNum), mode: 'physics', open: true }
            );
        }
    }

    window.ouvrirGenerateurAPE = function (symbole) {
        var el = window.ELEMENTS && window.ELEMENTS[symbole];
        if (!el) return;
        if (typeof switchGenTab === 'function') switchGenTab('ape', symbole, el);
        if (typeof window.ouvrirGenerateurAPEComplet === 'function') window.ouvrirGenerateurAPEComplet(symbole);
    };

    window.ouvrirGenerateurATOMPAW = function (symbole) {
        var el = window.ELEMENTS && window.ELEMENTS[symbole];
        if (!el) return;
        if (typeof switchGenTab === 'function') switchGenTab('atompaw', symbole, el);
        if (typeof window.ouvrirGenerateurATOMPAWComplet === 'function') window.ouvrirGenerateurATOMPAWComplet(symbole);
    };

    window.renderTabAPE = function (container, symbole, element) {
        renderSciTab(container, {
            symbole: symbole,
            z: element && element.numero,
            nom: element && element.nom,
            label: 'APE · Atomic Pseudopotential Engine',
            accent: '#5b21b6',
            intro: '<strong>APE</strong> produit des pseudopotentiels <strong>norme-conservants (NC)</strong> '
                + 'au format <code>.UPF</code>. Choix <strong>XC</strong> (LDA/GGA) et <strong>relativité</strong> dans la modale. '
                + 'Sortie : <code>pseudos-APE/</code>. '
                + 'Éléments 3d / 4f : souvent préférer <strong>ATOMPAW</strong> ou une bibliothèque externe.',
            steps: '<span>① Élément</span><span>② Gabarit auto</span><span>③ Lancer APE</span>',
            openFn: 'ouvrirGenerateurAPE',
            docUrl: 'https://wiki.fysik.dtu.dk/ape/',
            generator: 'ape',
        });
    };

    window.renderTabAtompaw = function (container, symbole, element) {
        renderSciTab(container, {
            symbole: symbole,
            z: element && element.numero,
            nom: element && element.nom,
            label: 'ATOMPAW · Projector Augmented Wave',
            accent: '#9d174d',
            intro: '<strong>ATOMPAW</strong> génère des jeux <strong>PAW</strong> convertibles en <code>.UPF</code>. '
                + 'Choix <strong>XC</strong>, <strong>relativité scalaire</strong> et type PAW dans la modale. '
                + 'Sortie : <code>pseudos-atompaw/</code>. '
                + 'Recommandé pour métaux de transition, éléments lourds et calculs exigeant la précision PAW.',
            steps: '<span>① Élément</span><span>② Gabarit auto</span><span>③ Lancer ATOMPAW</span>',
            openFn: 'ouvrirGenerateurATOMPAW',
            docUrl: 'https://users.wfu.edu/natalieb3/atompaw/',
            generator: 'atompaw',
        });
    };
})();
